Nx.GuideData["Death Knight Trainer"] = {
     ["Mode"] = 32,
     [502] = "0,51.08,27.57|0,47.48,26.56|0,46.7,31.93",
}
