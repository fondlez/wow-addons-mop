local Loc = LibStub("AceLocale-3.0"):NewLocale("Details_Threat", "ptBR")

if (not Loc) then
	return
end

Loc ["STRING_PLUGIN_NAME"] = "Mini Ameaca"
