local L = LibStub("AceLocale-3.0"):NewLocale("Details_ChartViewer", "zhTW")
if not L then return end

L["STRING_ADDEDOKAY"] = "成功加入。"
L["STRING_CONFIRM"] = "確認"
L["STRING_NEWTAB"] = "新標籤"
L["STRING_OPTIONS"] = "圖表查看器選項"
L["STRING_OPTIONS_SHOWICON"] = "顯示圖示"
L["STRING_OPTIONS_WINDOWSCALE"] = "視窗縮放"
L["STRING_PLUGIN_DESC"] = "使用簡單的線條圖表查看Details!收集的數據。"
L["STRING_PLUGIN_NAME"] = "圖表查看器"
L["STRING_TOOLTIP"] = "開啟圖表查看器"
L["STRING_TOOSHORTNAME"] = "名稱太短。"

