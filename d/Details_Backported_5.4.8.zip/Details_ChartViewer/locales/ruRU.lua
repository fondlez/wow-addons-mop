local L = LibStub("AceLocale-3.0"):NewLocale("Details_ChartViewer", "ruRU")
if not L then return end

L["STRING_ADDEDOKAY"] = "Успешно добавлено."
L["STRING_CONFIRM"] = "Подтвердить"
L["STRING_NEWTAB"] = "Новая вкладка"
L["STRING_OPTIONS"] = "Параметры просмотра диаграмм"
L["STRING_OPTIONS_SHOWICON"] = "Показать значок"
L["STRING_OPTIONS_WINDOWSCALE"] = "Масштаб Окна"
L["STRING_PLUGIN_DESC"] = "Просмотр данных, собранных в деталях! На простых линейных графиках."
L["STRING_PLUGIN_NAME"] = "Просмотр Диаграммы"
L["STRING_TOOLTIP"] = "Открыть просмотр диаграммы"
L["STRING_TOOSHORTNAME"] = "Название слишком короткое."

