NPC Silencer
from X�mena/Elflein (on Nethersturm-EU) 

Currently are NOT all npc's addet!!!

SORRY for my bad english but im german and my last english writing/speaking is twenty years ago :( I hope u understand all.

Get the latest updates via SVN here: http://code.google.com/p/npc-silencer/source/list

1.) What does this addon do?
With this addon you silence the says and shouts from many npcs. So u don't see the npc texts in your chatwindow. Npc's how tell u about a quest with /say or /yell will be shown in ur chatwindow.

The most annoying npc's are silenced. Other missing npc's will follow when i find it or an user will report it.
Actually are over 4.000 npc's addet.

2.) How do i use this addon?
Extracte the archiv in the directory "*WoW-Dir*/Interface/Addons" and start WoW. Thats all

3.) How can i help?
Please let an comment on the addonpage so i can add them to the next update.
Please tell us the city and npcname like 'Topper McNapp in Stormwind'

4.) Wishlist:
- all npc's addet
- single activation for zones or npc's (configuration)

5.) History
-> 50400.257
	- Npc's updated

-> 50400.256
	- Npc's updated

-> 50400.255
	- Npc's updated

-> 50400.254
	- Npc's updated

-> 50400.253
	- Npc's updated

-> 50400.250 - .252
	- Npc's updated

-> 50400.249
	- Npc's updated

-> 50400.248
	- Npc's updated

-> 50400.247
	- Npc's updated

-> 50400.246
	- Please delete the old npc-silencer.lua in your WTF-Folder
	- The amount of blocked npc's will be saved at savedvariables
	- The amount of blocked npc's will be shown at the stats
	- Raidboss Emotes and Raidboss Whisper added

-> 50400.245
	- Slashcommands optimized. Use /npc for help

-> 50400.244
	- Npc's updated
	- Slashcommand for (de)activating added. Thanks to Tim
	- use /npc or /silencer to (de)activate the addon

-> 50400.243
	- Npc's updated

-> 50400.242
	- Npc's updated

-> 50400.241
	- Npc's updated
	- .toc update for patch 5.4

-> 50300.236 - .240
	- Npc's updated

-> 50300.235
	- Before update please delete the old NPC-Silencer folder!!!
	- Due to crying players was the complete minimap function deletet
	- Npc's updated

-> 50300.234
	- Npc's updated

-> 50300.233
	- Npc's updated

-> 50300.232
	- Npc's updated
	- .toc update for patch 5.3

-> 50200.231
	- Bugfix

-> 50200.230
	- Npc's updated

-> 50200.229
	- Npc's updated

-> 50200.228
	- Npc's updated

-> 50200.227
	- Npc's updated

-> 50200.226
	- Npc's updated

-> 50200.225
	- many Npc's updated
	- .toc update for patch 5.2

-> 50100.224
	- many Npc's updated

-> 50100.223
	- many Npc's updated

-> 50100.222
	- .toc update for patch 5.01

-> 50001.221
	- Blackrock, Hellfire Citadel, The Underbog, Scarlet Monastery, Valley of the four Winds, The Jade Forrest, Dread Wastes, Vale of eternal Blossoms, Krasarang Wilds updated

-> 50001.220
	- Dragonblight, Storm Peaks, Stratholme, Mount Hyjal, Twillight Highlands, Valley of the four Winds, Kun-Lai Summit, Krasarang Wilds, Siege of Niuazo Temple, Uldum, Vashj'ir, Stormwind, Vashj'ir, Scarlet Monastery updated
	- Utgarde Keep, Nexus, Drak'Tharon Keep, The Violet Hold, Gundrak, Ahn'kahet, Mogu'shan Palace addet

-> 50001.219
	- Stratholme, Burning Steppes, Vale of eternal Blossoms, Peak of Serenity, Old Hillsbrad Foothills, Hellfire Citadel, Zangarmarsh, Shadowmoon Valley updated
	- Zul'Farrak, Swamp of Sorrows, Blackrock, The Underbog, Sethekk Halls addet

-> 50001.218
	- Duskwood, Stranglethorn Vale, Scholomance, Eastern Plaguelands updated
	- The Stockade, Gnomeregan, Scarlet Monastery, Uldaman, Dire Maul, Stratholme, Razorfen Kraul added

-> 50001.217
	- Uldum, Stormwind, Westfall updated
	- Wandering Isle, Helloween event, Ragefire Chasm, Shadowfang Keep, Peak of Serenity, The Deadmines addet

-> 50001.216
	- Kun-Lai Summit, Shado-pan Monastery, Tonlong Steppes, The Jade Forrest, Scenarios, Dread Wastes, Valley of the four Winds, Stormwind updated
	- Brewfest, Gate of the setting sun, Scarlet halls, Scholomance, Siege of Niuazo Temple addet

-> 50001.215
	- Valley of the four Winds, Kun-Lai Summit, Duskwood, The Jade Forrest, Dread Wastes updated

-> 50001.214 
	- The Jade Forrest, Valley of the four Winds updated

-> 50001.213
	- Dread Wastes, Kun-Lai Summit, Dun Morogh, The Jade Forrest, Stormwind updated

-> 50001.212
	- Instances, Westfall, Krasarang Wilds updated
	- Titan compatibility and ingame (de)activation addet. Thanks to Vladinator for this GREAT help!!!

-> 50001.211
	- The Ancient Passage updated
	- Scenarios addet
	- first work for Titan compatibility and ingame (de)activation

-> 50001.210
	- Zul'Drak, Dread Wastes updated

-> 50001.209
	- Krasarang Wilds, Kun-Lai Summit, Vale of eternal Blossoms updated
	- The Ancient Passage addet

-> 50001.208
	- Krasarang Wilds updated
	- Shado-pan Monastery addet

-> 50001.207
	- Valley of the four Winds, Krasarang Wilds updated
	
-> 50001.206
	- The Jade Forrest, Borean Tundra, Westfall, Grizzly Hills, Valley of the four Winds updated
	- Azjol-Nerub addet

-> 50001.205
	- The Jade Forrest, Stormwind, Twillight Highlands updated

-> 50001.204
	- The Jade Forrest, Howling Fjord updated

-> 50001.203
	- Mana-Tombs, Blade's Edge Mountains, Elwynn Forest, Borean Tundra, Krasarang Wilds updated

-> 50001.201 - .202
	- svn cleanup

-> 50001.200
	- Stormwind, Redridge Mountains, Hellfire Peninsula, Zangarmarsh, Nagrand updated
	- The Blasted Lands, Old Hillsbrad Foothills addet

-> 50001.199
	- Bugfix
	- Burning Steppes updated

-> 50001.198
	- Badlands, Valley of the four Winds, Tonlong Steppes, Darkmoon Island, Elwynn Forest, Vale of eternal Blossoms, Searing Gorge updated
	- Dread Wastes, Burning Steppes addet

-> 50001.197
	- Kun-Lai Summit updated
	- Tonlong Steppes addet

-> 50001.196
	- Kun-Lai Summit updated
	- litte codechange to get userhelp (chatmessage on login)

-> 50001.195
	- Valley of the four Winds, Vale of eternal Blossoms, Kun-Lai Summit addet

-> 50001.194
	- Badlands, Krasarang Wilds addet
	- Eastern Plaguelands updated
	- updated for WoW 5

-> 40300.193
	- Testfile deleted

-> 40300.192
	- Western Plaguelands, Eastern Plaguelands updated

-> 40300.191
	- bugfix... Sorry ;(

-> 40300.190
	- archiv/directory fixed

-> 40300.189
	- Ironforge, Loch Modan, Westfall, Duskwood, Stranglethorn Vale updated

-> 40300.188
	- Deepholm, Ironforge, Dun Morogh, Winterspring, Twillight Highlands updated

-> 40300.187
	- Error in FrameXML.log fixed

-> 40300.182 - .186
	- Npc update

-> 40300.171 - .181
	- Test for Curse SVN

-> 40300.170
	- Npc update

-> 40300.167
	- Npc update

-> 40300.163 - .166
	- Test for Curse SVN

-> 40300.162
	- Npc update

-> 40300.161
	- Test for Curse SVN

-> 40300.160
	- Npc update

-> 40300.156
	- Darkmoon Island updated
	- little codechange
	- update for patch 4.03

-> 40200.150
	- Terokkar Forest, Winterspring, Zangarmarsh, Zul'Drak addet

-> 40200.148
	- Lost Isles, Darkmoon Island, Westfall, Western Plaguelands, Elwynn Forest addet

-> 40200.146
	- Stormwind and Dustwallow marsh updated
	- Ulduar, Uldum, Lost Isles, Vashj'ir addet

-> 40200.144
	- Stormwind updated
	- Thousand Needles, Hillsbrad Foothills, Storm Peaks, Wetlands, Tanaris, Wintergrasp, Teldrassil, Felwood, Deepholm, Tirisfal Glades addet
	
-> 40200.142
	- Sholazar Basin, Silithus, Slave Pens, Stonetalon Mountains and Stormwind addet
 