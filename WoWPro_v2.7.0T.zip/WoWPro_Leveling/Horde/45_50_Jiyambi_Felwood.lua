
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_felwood_horde
-- Date: 2013-01-13 19:48
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3258/revisions/24955/view
-- Date: 2012-02-13 23:34
-- Who: Crackerhead22
-- Log: ?

-- URL: http://wow-pro.com/node/3258/revisions/24547/view
-- Date: 2011-06-12 13:03
-- Who: Crackerhead22
-- Log: Added sticky step for "Is Your Oil Running" via a suggestion by Skully0815.

-- URL: http://wow-pro.com/node/3258/revisions/24543/view
-- Date: 2011-06-11 17:37
-- Who: Crackerhead22
-- Log: Added more changes suggested by Skully0815. Added note on "The Demon Prince" accept step about either logging out and back in, or re-zoning.

-- URL: http://wow-pro.com/node/3258/revisions/24540/view
-- Date: 2011-06-10 19:48
-- Who: Crackerhead22
-- Log: Removed [b][color=red]No guide yet written.[/color][/b] from the page.

-- URL: http://wow-pro.com/node/3258/revisions/24539/view
-- Date: 2011-06-10 19:47
-- Who: Crackerhead22
-- Log: Fixed issues mentioned by Skully815. Fixed order of quests so certain quests will show.

-- URL: http://wow-pro.com/node/3258/revisions/23398/view
-- Date: 2010-12-03 11:46
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3258/revisions/23397/view
-- Date: 2010-12-03 11:45
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('JiyFel4550', 'Felwood', 'Jiyambi', '45', '50', 'JiyWin5055', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
