
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_shadowmoon_valley_horde
-- Date: 2013-01-13 19:12
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3286/revisions/25318/view
-- Date: 2013-01-09 22:51
-- Who: Ludovicus Maior
-- Log: Added CN tag

-- URL: http://wow-pro.com/node/3286/revisions/25155/view
-- Date: 2012-10-23 20:25
-- Who: Fluclo
-- Log: Adding min Level tag, and at Level 67, you "auto-learn" location of Shadowmoon Village

-- URL: http://wow-pro.com/node/3286/revisions/24676/view
-- Date: 2011-07-11 22:35
-- Who: Ludovicus Maior
-- Log: Numeric Rep Tags

-- URL: http://wow-pro.com/node/3286/revisions/24604/view
-- Date: 2011-06-25 02:31
-- Who: Crackerhead22
-- Log: Fixed the ton of QID errors caused by the recorder.

-- URL: http://wow-pro.com/node/3286/revisions/24387/view
-- Date: 2011-05-15 18:15
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3286/revisions/24384/view
-- Date: 2011-05-15 01:45
-- Who: Crackerhead22
-- Log: Added source code!!!!!

-- URL: http://wow-pro.com/node/3286/revisions/23463/view
-- Date: 2010-12-03 21:59
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3286/revisions/23462/view
-- Date: 2010-12-03 21:58
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('CraSha7070H', 'Shadowmoon Valley', 'Crackerhead22', '69', '70', 'JamBor7173', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
