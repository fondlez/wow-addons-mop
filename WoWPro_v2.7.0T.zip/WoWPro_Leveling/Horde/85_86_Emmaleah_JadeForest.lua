
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_jade_forest_horde
-- Date: 2013-06-18 00:46
-- Who: Ludovicus Maior
-- Log: Bad Y coordinate 31.95,13.21., 1/1 in guide EmmJad8586, line [C Regroup!].

-- URL: http://wow-pro.com/node/3487/revisions/25576/view
-- Date: 2013-03-23 19:01
-- Who: Ludovicus Maior
-- Log: Quest name corrections and a missing | char.

-- URL: http://wow-pro.com/node/3487/revisions/25575/view
-- Date: 2013-03-23 18:59
-- Who: Ludovicus Maior
-- Log: quest name tweak

-- URL: http://wow-pro.com/node/3487/revisions/25491/view
-- Date: 2013-01-13 23:50
-- Who: Ludovicus Maior
-- Log: Added CS tag

-- URL: http://wow-pro.com/node/3487/revisions/25314/view
-- Date: 2013-01-09 22:43
-- Who: Ludovicus Maior
-- Log: Added two CS tags

-- URL: http://wow-pro.com/node/3487/revisions/25231/view
-- Date: 2012-12-02 19:06
-- Who: Emmaleah
-- Log: 2 Dec 2012 - Emmaleah - Bliz fixed the phasing bug with the pandaran teapot in 5.1 - editing guide to reflect that.

-- URL: http://wow-pro.com/node/3487/revisions/25196/view
-- Date: 2012-11-11 00:02
-- Who: Emmaleah
-- Log: Emmaleah - 10 Nov 2012 - Added in the "one time" lost treasure items(I left out the 2 in alliance territory), some minor changes when comparing the affected areas between horde and alliance.

-- URL: http://wow-pro.com/node/3487/revisions/25190/view
-- Date: 2012-11-08 20:16
-- Who: Emmaleah
-- Log: added coords for use boots on missed me by that much

-- URL: http://wow-pro.com/node/3487/revisions/25188/view
-- Date: 2012-11-08 18:54
-- Who: Emmaleah

-- URL: http://wow-pro.com/node/3487/revisions/25180/view
-- Date: 2012-11-04 21:22
-- Who: Emmaleah
-- Log: changed CC in R Nectarbreeze to CS

-- URL: http://wow-pro.com/node/3487/revisions/25129/view
-- Date: 2012-10-08 19:49
-- Who: Ludovicus Maior
-- Log: As per  Emmaleah, Use Captain's Jack's head to get the quest.

-- URL: http://wow-pro.com/node/3487/revisions/25100/view
-- Date: 2012-10-02 01:55
-- Who: Ludovicus Maior
-- Log: Emmaleah: edited with Play test on live 9/30/12 -- many many changes
--	Ludovicus: No editing on my part!  Have not yet done this on horde.

-- URL: http://wow-pro.com/node/3487/revisions/25052/view
-- Date: 2012-08-28 19:06
-- Who: Ludovicus Maior
-- Log: correct urls

-- URL: http://wow-pro.com/node/3487/revisions/25051/view
-- Date: 2012-08-28 19:05
-- Who: Ludovicus Maior
-- Log: Submitted by Emmaleah on Sat, 2012-08-18 15:07. 

WoWPro.Leveling:RegisterGuide('EmmJad8586', 'The Jade Forest', 'Emmaleah', '85', '86', 'EmmVal8688', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
