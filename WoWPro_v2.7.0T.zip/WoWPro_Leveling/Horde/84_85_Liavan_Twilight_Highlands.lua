
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_twilight_highlands_horde
-- Date: 2011-06-01 00:16
-- Who: Crackerhead22
-- Log: Removed |Z|The Maw of Madness, as it was unneeded.

-- URL: http://wow-pro.com/node/3312/revisions/24285/view
-- Date: 2011-04-28 15:12
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24284/view
-- Date: 2011-04-28 12:56
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24283/view
-- Date: 2011-04-27 12:44
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24281/view
-- Date: 2011-04-27 12:21
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24255/view
-- Date: 2011-04-23 21:22
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24254/view
-- Date: 2011-04-23 20:11
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24247/view
-- Date: 2011-04-22 19:48
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24246/view
-- Date: 2011-04-22 19:13
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24245/view
-- Date: 2011-04-22 18:11
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/24244/view
-- Date: 2011-04-22 17:56
-- Who: Chrisser000

-- URL: http://wow-pro.com/node/3312/revisions/23519/view
-- Date: 2010-12-03 23:31
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3312/revisions/23518/view
-- Date: 2010-12-03 23:30
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('LiaTwi8485', 'Twilight Highlands', 'Liavan', '84', '85', nil, 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
