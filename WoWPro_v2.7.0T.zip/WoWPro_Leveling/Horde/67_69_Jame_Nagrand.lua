
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_nagrand_horde
-- Date: 2013-01-13 19:17
-- Who: Ludovicus Maior
-- Log: Added CN tag

-- URL: http://wow-pro.com/node/3280/revisions/25319/view
-- Date: 2013-01-09 22:55
-- Who: Ludovicus Maior
-- Log: Added CN and CS tags

-- URL: http://wow-pro.com/node/3280/revisions/24913/view
-- Date: 2012-01-20 21:15
-- Who: Crackerhead22
-- Log: Added REP tags to certain Consortium quests.

-- URL: http://wow-pro.com/node/3280/revisions/24882/view
-- Date: 2012-01-03 15:25
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3280/revisions/24839/view
-- Date: 2011-12-07 18:19
-- Who: Crackerhead22
-- Log: 4.3 updates plus Altruis the Sufferer quest lines

-- URL: http://wow-pro.com/node/3280/revisions/24340/view
-- Date: 2011-04-29 16:44
-- Who: Ludovicus Maior
-- Log: Line 26 for step A has unknown tag [71.5,40.5]

-- URL: http://wow-pro.com/node/3280/revisions/23449/view
-- Date: 2010-12-03 21:35
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3280/revisions/23448/view
-- Date: 2010-12-03 21:35
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamNag6769", "Nagrand", "Jame", "67", "69", "JamBla6970", "Horde", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
