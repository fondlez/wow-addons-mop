
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_thousand_needles_horde
-- Date: 2013-08-16 19:46
-- Who: Ludovicus Maior
-- Log: Minor QID fixes.

-- URL: http://wow-pro.com/node/3254/revisions/25468/view
-- Date: 2013-01-13 19:17
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3254/revisions/24944/view
-- Date: 2012-02-11 17:39
-- Who: Crackerhead22
-- Log: ?

-- URL: http://wow-pro.com/node/3254/revisions/24333/view
-- Date: 2011-04-29 16:28
-- Who: Ludovicus Maior
-- Log: Line 48 for step A has unknown tag [From Razzeric.], Line 163 for step A has 1 M coords, Line 199 for step A has 1 M coords.

-- URL: http://wow-pro.com/node/3254/revisions/23672/view
-- Date: 2010-12-07 04:52
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3254/revisions/23431/view
-- Date: 2010-12-03 12:14
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3254/revisions/23389/view
-- Date: 2010-12-03 11:39
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3254/revisions/23388/view
-- Date: 2010-12-03 11:38
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('JiyTho4045', 'Thousand Needles', 'Jiyambi', '40', '45', 'JiyTan4550', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
