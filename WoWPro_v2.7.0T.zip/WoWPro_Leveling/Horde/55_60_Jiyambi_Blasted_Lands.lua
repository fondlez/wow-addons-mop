
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_blasted_lands_horde
-- Date: 2013-08-03 07:56
-- Who: Emmaleah
-- Log: Change QID 25685 The First Step to CS (from CC)

-- URL: http://wow-pro.com/node/3268/revisions/25492/view
-- Date: 2013-01-13 23:52
-- Who: Ludovicus Maior
-- Log: Added CC tag

-- URL: http://wow-pro.com/node/3268/revisions/25472/view
-- Date: 2013-01-13 19:27
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3268/revisions/24863/view
-- Date: 2011-12-12 20:14
-- Who: Crackerhead22
-- Log: Added missing notes, added a few QO steps...?

-- URL: http://wow-pro.com/node/3268/revisions/24431/view
-- Date: 2011-05-28 04:21
-- Who: Crackerhead22
-- Log: Added in "Warchief's Command: Blasted Lands!" and "Blasted Lands: The Other Side of the World" turn-ins. Put optional tags on the turn-ins for the breadcrumb quests.

-- URL: http://wow-pro.com/node/3268/revisions/24338/view
-- Date: 2011-04-29 16:38
-- Who: Ludovicus Maior
-- Log: Line ** for step * has unknown tag [If you didn't

-- URL: http://wow-pro.com/node/3268/revisions/23418/view
-- Date: 2010-12-03 12:02
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3268/revisions/23417/view
-- Date: 2010-12-03 12:02
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('JiyBla5560', 'Blasted Lands', 'Jiyambi', '55', '60', 'JamHel6063', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
