
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_blade039s_edge_mountains_horde
-- Date: 2013-08-16 19:48
-- Who: Ludovicus Maior
-- Log: Corrected the quests that Tor'chunk Twoclaws gives.  Added a few coords.

-- URL: http://wow-pro.com/node/3282/revisions/25453/view
-- Date: 2013-01-13 17:52
-- Who: Ludovicus Maior
-- Log: Added CN and CS tags

-- URL: http://wow-pro.com/node/3282/revisions/25046/view
-- Date: 2012-08-13 02:06
-- Who: Laotseu
-- Log: Minor fixes, mostly N steps that were converted to C with |NC|+|QO| and a few missing |T|.

-- URL: http://wow-pro.com/node/3282/revisions/24883/view
-- Date: 2012-01-04 16:23
-- Who: Crackerhead22
-- Log: Added notes, cords, sticky steps.

-- URL: http://wow-pro.com/node/3282/revisions/24848/view
-- Date: 2011-12-08 18:02
-- Who: Crackerhead22
-- Log: 4.3 updates plus added in quest for zone quest achievment

-- URL: http://wow-pro.com/node/3282/revisions/24341/view
-- Date: 2011-04-29 16:46
-- Who: Ludovicus Maior
-- Log: Line 301, for step A non-decimal PRE

-- URL: http://wow-pro.com/node/3282/revisions/23453/view
-- Date: 2010-12-03 21:38
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3282/revisions/23452/view
-- Date: 2010-12-03 21:37
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamBla6970", "Blade's Edge Mountains", "Jame", "65", "68", "JamHow7071", "Horde", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
