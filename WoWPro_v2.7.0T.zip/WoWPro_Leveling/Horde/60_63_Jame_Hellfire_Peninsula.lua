
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_hellfire_peninsula_horde
-- Date: 2013-06-23 11:16
-- Who: Emmaleah
-- Log: 6/22/13 by Emmaleah - added changes for new CHAT tag, changed some N steps to C steps with NC tag, few other minor adjustments.

-- URL: http://wow-pro.com/node/3272/revisions/25288/view
-- Date: 2013-01-09 01:23
-- Who: Ludovicus Maior
-- Log: Touchups as I run my DK through.

-- URL: http://wow-pro.com/node/3272/revisions/25045/view
-- Date: 2012-08-13 01:54
-- Who: Laotseu
-- Log: Minor fixes found while play testing the guide including few quests with typos that prevented the auto-turnins from working properly.

-- URL: http://wow-pro.com/node/3272/revisions/25040/view
-- Date: 2012-08-05 03:21
-- Who: Laotseu
-- Log: Some fix to the guide after play testing it. Mostly quest name typos, missing coordinates and coordinate refining.

-- URL: http://wow-pro.com/node/3272/revisions/24864/view
-- Date: 2011-12-13 04:24
-- Who: Crackerhead22
-- Log: Added missing cords, missing notes, added missing quest, added QO steps...?

-- URL: http://wow-pro.com/node/3272/revisions/24828/view
-- Date: 2011-12-01 13:00
-- Who: Crackerhead22
-- Log: Added in "Checking up" quest.

-- URL: http://wow-pro.com/node/3272/revisions/24824/view
-- Date: 2011-11-30 19:39
-- Who: Crackerhead22
-- Log: Updated for 4.3.

-- URL: http://wow-pro.com/node/3272/revisions/23426/view
-- Date: 2010-12-03 12:10
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3272/revisions/23425/view
-- Date: 2010-12-03 12:10
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamHel6063", "Hellfire Peninsula", "Jame", "60", "63", "JamZan6365", "Horde", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
