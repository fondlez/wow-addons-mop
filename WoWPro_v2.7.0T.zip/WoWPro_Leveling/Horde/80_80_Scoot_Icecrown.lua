
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_icecrown_horde
-- Date: 2013-03-23 18:53
-- Who: Ludovicus Maior
-- Log: Many quest name corrections, a 2 QID corrections.

-- URL: http://wow-pro.com/node/3302/revisions/24347/view
-- Date: 2011-04-29 17:06
-- Who: Ludovicus Maior
-- Log: Line 103 for step C Bad coord , Line 315 for step T has 3 M coords, Line 412 for step C Bad coord 1 at a ti, Line 519 for step C Bad coord  .....

-- URL: http://wow-pro.com/node/3302/revisions/24209/view
-- Date: 2011-04-05 23:13
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3302/revisions/23496/view
-- Date: 2010-12-03 22:43
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3302/revisions/23495/view
-- Date: 2010-12-03 22:37
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("ScoIce8080", "Icecrown", "Scoot", "78", "80", "AriVasH8082", "Horde", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
