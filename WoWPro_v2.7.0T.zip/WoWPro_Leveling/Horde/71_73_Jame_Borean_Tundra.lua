
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_borean_tundra_horde
-- Date: 2013-03-23 19:14
-- Who: Ludovicus Maior
-- Log: quest name tweaks

-- URL: http://wow-pro.com/node/3290/revisions/25483/view
-- Date: 2013-01-13 19:54
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3290/revisions/24915/view
-- Date: 2012-01-22 08:24
-- Who: Crackerhead22
-- Log: Added missing notes, cords.  Added QO steps, sticky steps, ?

-- URL: http://wow-pro.com/node/3290/revisions/24855/view
-- Date: 2011-12-10 15:27
-- Who: Crackerhead22
-- Log: 4.3 updates

-- URL: http://wow-pro.com/node/3290/revisions/24605/view
-- Date: 2011-06-25 02:37
-- Who: Crackerhead22
-- Log: ! Duplicate T step for qid 11576 - Quest "Abduction" C and T steps had QID 11576 instead of 11590

-- URL: http://wow-pro.com/node/3290/revisions/24368/view
-- Date: 2011-05-06 03:12
-- Who: TwoToad
-- Log: Updated the Warsong Farm Outpost to use stickies. Updated location of Shadowstalker Getry (it was off a little).

-- URL: http://wow-pro.com/node/3290/revisions/24365/view
-- Date: 2011-05-05 03:10
-- Who: TwoToad
-- Log: Updated a section to use stickies, instead of the old method.

-- URL: http://wow-pro.com/node/3290/revisions/24343/view
-- Date: 2011-04-29 16:51
-- Who: Ludovicus Maior
-- Log: Line 62 for step f has unknown tag [40.4,51.4], Line 340, for step A non-decimal PRE.

-- URL: http://wow-pro.com/node/3290/revisions/23472/view
-- Date: 2010-12-03 22:17
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3290/revisions/23471/view
-- Date: 2010-12-03 22:17
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3290/revisions/23470/view
-- Date: 2010-12-03 22:16
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamBor7173", "Borean Tundra", "Jame", "71", "73", "JamDra7375", "Horde", function()
--> Original guides written/designed by [Jame]
-->
--> Addon written by [Black Cat] 2/14/2009
--> Last modified by [Jiyambi] 4/20/2009
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
