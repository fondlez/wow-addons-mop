
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_badlands_horde
-- Date: 2013-01-13 19:35
-- Who: Ludovicus Maior
-- Log: Added CC tag

-- URL: http://wow-pro.com/node/3248/revisions/25345/view
-- Date: 2013-01-11 23:32
-- Who: Ludovicus Maior
-- Log: Added CN tags

-- URL: http://wow-pro.com/node/3248/revisions/24887/view
-- Date: 2012-01-16 17:21
-- Who: Crackerhead22
-- Log: Added the QID for the "The Sentinel's Game" quest.

-- URL: http://wow-pro.com/node/3248/revisions/24390/view
-- Date: 2011-05-17 00:56
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3248/revisions/24334/view
-- Date: 2011-04-29 16:29
-- Who: Ludovicus Maior
-- Log: Line 22 for step A has 3 M coords, Line 124 for step A has unknown tag [From Gargal]

-- URL: http://wow-pro.com/node/3248/revisions/24047/view
-- Date: 2011-01-24 10:34
-- Who: Crackerhead22
-- Log: Added notes.

-- URL: http://wow-pro.com/node/3248/revisions/23561/view
-- Date: 2010-12-04 16:02
-- Who: Liavan
-- Log: this is just very basic the recorder completely bugged out on me maybe i should have updated it before i tried recording but this should be a very basic of this zone.

-- URL: http://wow-pro.com/node/3248/revisions/23377/view
-- Date: 2010-12-03 11:29
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3248/revisions/23376/view
-- Date: 2010-12-03 11:29
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('LiaBad4548', 'Badlands', 'Liavan', '45', '48', 'CraSea4850', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
