
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_zangarmarsh_horde
-- Date: 2013-03-23 18:57
-- Who: Ludovicus Maior
-- Log: Corrected name of [Keep Thornfang Hill Clear!]

-- URL: http://wow-pro.com/node/3274/revisions/25467/view
-- Date: 2013-01-13 19:14
-- Who: Ludovicus Maior
-- Log: Added CN tag

-- URL: http://wow-pro.com/node/3274/revisions/24867/view
-- Date: 2011-12-14 00:51
-- Who: Crackerhead22
-- Log: ?

-- URL: http://wow-pro.com/node/3274/revisions/24835/view
-- Date: 2011-12-04 16:07
-- Who: Crackerhead22
-- Log: 4.3 updates

-- URL: http://wow-pro.com/node/3274/revisions/24241/view
-- Date: 2011-04-20 18:59
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3274/revisions/23430/view
-- Date: 2010-12-03 12:13
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3274/revisions/23429/view
-- Date: 2010-12-03 12:13
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamZan6365", "Zangarmarsh", "Jame", "63", "65", "JamTer6567", "Horde", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
