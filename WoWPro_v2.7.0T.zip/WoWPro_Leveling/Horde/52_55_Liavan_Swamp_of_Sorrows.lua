
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_swamp_sorrows_horde
-- Date: 2013-01-13 17:34
-- Who: Ludovicus Maior
-- Log: Added CN tags

-- URL: http://wow-pro.com/node/3250/revisions/25320/view
-- Date: 2013-01-09 22:58
-- Who: Ludovicus Maior
-- Log: Added CS steps

-- URL: http://wow-pro.com/node/3250/revisions/24603/view
-- Date: 2011-06-25 01:55
-- Who: Crackerhead22
-- Log: ! Duplicate A step for qid 27598 - Removed line.
--	! Duplicate A step for qid 27600 - Removed line.

-- URL: http://wow-pro.com/node/3250/revisions/24337/view
-- Date: 2011-04-29 16:35
-- Who: Ludovicus Maior
-- Log: Line 69 for step C has 1 M coords

-- URL: http://wow-pro.com/node/3250/revisions/23626/view
-- Date: 2010-12-06 05:51
-- Who: Liavan

-- URL: http://wow-pro.com/node/3250/revisions/23381/view
-- Date: 2010-12-03 11:32
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3250/revisions/23380/view
-- Date: 2010-12-03 11:31
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('LiaSwa5255', 'Swamp of Sorrows', 'Liavan', '52', '55', 'JiyBla5560', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
