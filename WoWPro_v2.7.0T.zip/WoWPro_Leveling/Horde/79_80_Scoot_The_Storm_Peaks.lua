
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_storm_peaks_horde
-- Date: 2013-03-23 19:04
-- Who: Ludovicus Maior
-- Log: quest name tweak

-- URL: http://wow-pro.com/node/3300/revisions/24609/view
-- Date: 2011-06-25 02:55
-- Who: Crackerhead22
-- Log:  T step for qid 12907 - QID for "A Certain Prisoner" was wrong.
--	! Missing A step for step C qid 12954 - Fixed, was wrong QID for C step.

-- URL: http://wow-pro.com/node/3300/revisions/24353/view
-- Date: 2011-04-29 18:14
-- Who: Ludovicus Maior
-- Log: ! Line 187 for step A has unknown tag [To the left. (24.01, 61.74)]: [A Valkyrion Must Burn |QID|12953| To the left. (24.01, 61.74)|M|24.0,61.8|]
--	! Line 223 for step C Bad coord : [C Battling the Elements |QID|12967| |N|Get on Snorri's Back.  Pick up the Snowdrifts  and throw Snowballs (2) at Seething Revenants.|M|1,|]
--	! Line 226 for step T has unknown tag [(63.17,63.21)]: [T Forging an Alliance |QID|12924|(63.17,63.21)|M|63.2,63.2|]

-- URL: http://wow-pro.com/node/3300/revisions/23492/view
-- Date: 2010-12-03 22:34
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3300/revisions/23491/view
-- Date: 2010-12-03 22:33
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("ScoSto7980", "The Storm Peaks", "Scoot", "79", "80", "ScoIce8080", "Horde", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
