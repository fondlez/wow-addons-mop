
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_grizzly_hills_horde
-- Date: 2013-06-18 08:35
-- Who: Emmaleah
-- Log: added missing |Z| in first line of guide

-- URL: http://wow-pro.com/node/3294/revisions/25316/view
-- Date: 2013-01-09 22:47
-- Who: Ludovicus Maior
-- Log: Added CS and CN tags

-- URL: http://wow-pro.com/node/3294/revisions/24921/view
-- Date: 2012-01-24 13:36
-- Who: Crackerhead22
-- Log: Added notes, cords, missing quest(s?)...?

-- URL: http://wow-pro.com/node/3294/revisions/24761/view
-- Date: 2011-10-11 04:21
-- Who: Gethe
-- Log: Updated "Vial of Visions", uses Crystal Vials now not Imbued Vials.

-- URL: http://wow-pro.com/node/3294/revisions/24760/view
-- Date: 2011-10-10 23:55
-- Who: Gethe

-- URL: http://wow-pro.com/node/3294/revisions/24755/view
-- Date: 2011-10-10 03:32
-- Who: Gethe

-- URL: http://wow-pro.com/node/3294/revisions/24607/view
-- Date: 2011-06-25 02:48
-- Who: Crackerhead22
-- Log: ! Quest 12164 has an A step and no T - Added in turn in step.

-- URL: http://wow-pro.com/node/3294/revisions/24344/view
-- Date: 2011-04-29 16:52
-- Who: Ludovicus Maior
-- Log: Line 285 for step C has unknown tag [NGo northwest to ...]

-- URL: http://wow-pro.com/node/3294/revisions/24211/view
-- Date: 2011-04-05 23:15
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3294/revisions/24163/view
-- Date: 2011-03-12 18:29
-- Who: Ludovicus Maior
-- Log: Make Guide ID unique

-- URL: http://wow-pro.com/node/3294/revisions/23480/view
-- Date: 2010-12-03 22:26
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3294/revisions/23479/view
-- Date: 2010-12-03 22:26
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamGriH7577", "Grizzly Hills", "Jame", "75", "77", "ScoZul7778", "Horde", function()
--Original guide written/designed by Jame
--Addon Version: Last Modified 7/14/2010
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
