
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_krasarang_wilds_horde
-- Date: 2013-06-24 18:47
-- Who: Twists
-- Log: Update coordinates

-- URL: http://wow-pro.com/node/3489/revisions/25731/view
-- Date: 2013-06-24 18:46
-- Who: Twists
-- Log: Fixed { in mapping and || for a QID

-- URL: http://wow-pro.com/node/3489/revisions/25709/view
-- Date: 2013-06-18 00:40
-- Who: Ludovicus Maior
-- Log: Bad X coordinate S, 1/1 in guide EmmKra8788, line [C Materia Medica].
--	Bad X coordinate US, 1/1 in guide EmmKra8788, line [C Materia Medica].

-- URL: http://wow-pro.com/node/3489/revisions/25465/view
-- Date: 2013-01-13 19:10
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3489/revisions/25313/view
-- Date: 2013-01-09 22:41
-- Who: Ludovicus Maior
-- Log: Added CS and CN tag

-- URL: http://wow-pro.com/node/3489/revisions/25199/view
-- Date: 2012-11-11 00:44
-- Who: Emmaleah
-- Log: missed a missing |

-- URL: http://wow-pro.com/node/3489/revisions/25198/view
-- Date: 2012-11-11 00:33
-- Who: Emmaleah
-- Log: Emmaleah 10 Nov 2012 - Added "one time" treasure items.

-- URL: http://wow-pro.com/node/3489/revisions/25123/view
-- Date: 2012-10-07 23:14
-- Who: Ludovicus Maior
-- Log: Merged https://github.com/Emmaleah/WoW-Pro-Guides/blob/master/WoWPro_Leveling/Horde/87_88_Emmaleah_KrasarangWilds.lua and tweaks by Ludo

-- URL: http://wow-pro.com/node/3489/revisions/25056/view
-- Date: 2012-08-28 19:16
-- Who: Ludovicus Maior
-- Log: Correct URLS

-- URL: http://wow-pro.com/node/3489/revisions/25055/view
-- Date: 2012-08-28 19:14
-- Who: Ludovicus Maior
-- Log: Submitted by Emmaleah on Sat, 2012-08-18 15:07. 

WoWPro.Leveling:RegisterGuide('EmmKra8788', 'Krasarang Wilds', 'Emmaleah', '87', '88', 'EmmKun8889', 'Horde', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
