
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_kunlai_summit_neutral
-- Date: 2013-05-14 19:29
-- Who: Ludovicus Maior
-- Log: Got rid of stray M tags

-- URL: http://wow-pro.com/node/3490/revisions/25595/view
-- Date: 2013-03-23 20:35
-- Who: Ludovicus Maior
-- Log: Bad quest name

-- URL: http://wow-pro.com/node/3490/revisions/25482/view
-- Date: 2013-01-13 19:50
-- Who: Ludovicus Maior
-- Log: Added CN tags

-- URL: http://wow-pro.com/node/3490/revisions/25305/view
-- Date: 2013-01-09 22:27
-- Who: Ludovicus Maior
-- Log: Added CS/CN tags

-- URL: http://wow-pro.com/node/3490/revisions/25254/view
-- Date: 2012-12-18 17:15
-- Who: Ludovicus Maior
-- Log: OK, my last cleanup of Winter's Blossom, coords tweaks, and a few QO's.

-- URL: http://wow-pro.com/node/3490/revisions/25252/view
-- Date: 2012-12-16 19:49
-- Who: Ludovicus Maior
-- Log: Coordinate edits and a |S| step.

-- URL: http://wow-pro.com/node/3490/revisions/25248/view
-- Date: 2012-12-15 21:08
-- Who: Emmaleah

-- URL: http://wow-pro.com/node/3490/revisions/25247/view
-- Date: 2012-12-15 17:40
-- Who: Ludovicus Maior
-- Log: Expanded [A Witness to History] for both Horde and Alliance.
--	Coords are coarse for Horde.

-- URL: http://wow-pro.com/node/3490/revisions/25230/view
-- Date: 2012-12-02 15:30
-- Who: Ludovicus Maior
-- Log: Add S for "Unleash The Yeti!"

-- URL: http://wow-pro.com/node/3490/revisions/25226/view
-- Date: 2012-12-02 01:48
-- Who: Emmaleah
-- Log: 1 Dec 2012 - Emmaleah - Moved Zouchin Strand chain (when Bliz added the ride from Mishi, it felt awkward there).  Few other changes from finishing going thru the zone again.

-- URL: http://wow-pro.com/node/3490/revisions/25220/view
-- Date: 2012-11-30 13:17
-- Who: Ludovicus Maior
-- Log: Added more QIDS to steps missing them so they do not show up again on guide reset.
--	Coord update for Zouchin Strand, Burlap Trail, Knucklethump Hole, The Dooker Dome, and the start of the Burlap trail.  Need to add sticky steps for The Dooker Dome.

-- URL: http://wow-pro.com/node/3490/revisions/25217/view
-- Date: 2012-11-27 18:46
-- Who: Emmaleah
-- Log:  added NC) Added to check off manually on the rare "lost" items.

-- URL: http://wow-pro.com/node/3490/revisions/25215/view
-- Date: 2012-11-25 22:21
-- Who: Ludovicus Maior
-- Log: Lots of tweaks up to Zouchin Village.   Played through on two toons.

-- URL: http://wow-pro.com/node/3490/revisions/25178/view
-- Date: 2012-11-03 18:47
-- Who: Emmaleah
-- Log: 3 Nov 2012 - Emmaleah - changed coords/note for C Do a Barrel Roll, added change log.
--	TO DO: I notice the loot grey items worth gold/xp arent autochecking off. (when there in no item (doh!) going to try adding CC tags. will update if that works.  Anyone else have any other ideas?
--	

-- URL: http://wow-pro.com/node/3490/revisions/25177/view
-- Date: 2012-11-02 04:12
-- Who: JamesL85
-- Log: Working my way through and had 2 Sticky steps for Blue Dwarf Needs Food Badly and a T step for the quest that wasn't complete.  Changed the second S step to US.  Not sure if this is correct or not.

-- URL: http://wow-pro.com/node/3490/revisions/25176/view
-- Date: 2012-11-02 03:56
-- Who: JamesL85
-- Log: After the *R Mogujia* step, everything with that quest was Moguija.  I changed the spelling and hopefully it will auto-complete now.

-- URL: http://wow-pro.com/node/3490/revisions/25173/view
-- Date: 2012-10-28 01:06
-- Who: Ludovicus Maior
-- Log: Inkgill Mere touchups

-- URL: http://wow-pro.com/node/3490/revisions/25150/view
-- Date: 2012-10-22 20:04
-- Who: Emmaleah
-- Log: corrected the guide number (from 3487) so it linked to the correct page.

-- URL: http://wow-pro.com/node/3490/revisions/25149/view
-- Date: 2012-10-22 20:00
-- Who: Emmaleah
-- Log: -- Date: 23 Oct 2012
--	-- Who: Emmaleah
--	-- Log: added in comments about the blue "once per" items (and I think a couple of more grey ones too)
--	I hope I did this right as its the first one I've editted directly on the site. (looks like snowflake came to visit and gave me more privledges.)

-- URL: http://wow-pro.com/node/3490/revisions/25144/view
-- Date: 2012-10-18 23:12
-- Who: Ludovicus Maior
-- Log: Update from https://github.com/Emmaleah/WoW-Pro-Guides/blob/master/WoWPro_Leveling/Neutral/88_89_Emmaleah_KunLaiSummit.lua as of 10/18 5PM

-- URL: http://wow-pro.com/node/3490/revisions/25102/view
-- Date: 2012-10-02 12:02
-- Who: Ludovicus Maior
-- Log: Namour of Llane, Emmaleah : Move Knucklethump Hole

-- URL: http://wow-pro.com/node/3490/revisions/25098/view
-- Date: 2012-10-02 00:52
-- Who: Ludovicus Maior
-- Log: Emmaleah: Made various changes per comments on Wow-pro.com, including quest order and changing several |N|step, especially not counting on the h to tell people to reset their hearthstone, but including it in the |N| 9/28

-- URL: http://wow-pro.com/node/3490/revisions/25087/view
-- Date: 2012-09-25 00:51
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3490/revisions/25067/view
-- Date: 2012-09-15 19:39
-- Who: Ludovicus Maior
-- Log: Applied https://github.com/Emmaleah/WoW-Pro-Guides/blob/master/WoWPro_Leveling/Neutral/88_89_Emmaleah_KunLaiSummit.lua

-- URL: http://wow-pro.com/node/3490/revisions/25065/view
-- Date: 2012-09-08 06:24
-- Who: Laotseu

-- URL: http://wow-pro.com/node/3490/revisions/25064/view
-- Date: 2012-09-08 05:49
-- Who: Laotseu
-- Log: Play tested using an Alliance toon. Didn't touch the Horde only quests.

-- URL: http://wow-pro.com/node/3490/revisions/25057/view
-- Date: 2012-08-28 19:31
-- Who: Ludovicus Maior
-- Log: Submitted by Emmaleah on Sat, 2012-08-18 15:07. 

WoWPro.Leveling:RegisterGuide('EmmKun8889', 'Kun-Lai Summit', 'Emmaleah', '88', '89', 'EmmTow8990|EmmTow8990', 'Neutral', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
