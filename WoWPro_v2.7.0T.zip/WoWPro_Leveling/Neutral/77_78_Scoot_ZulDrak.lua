
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_zul039drak_neutral
-- Date: 2013-03-23 19:09
-- Who: Ludovicus Maior
-- Log: quest name tweaks

-- URL: http://wow-pro.com/node/3295/revisions/25444/view
-- Date: 2013-01-13 16:24
-- Who: Ludovicus Maior
-- Log: Added CN tag

-- URL: http://wow-pro.com/node/3295/revisions/25381/view
-- Date: 2013-01-12 20:43
-- Who: Emmaleah
-- Log: fixes for multi coordinates

-- URL: http://wow-pro.com/node/3295/revisions/25311/view
-- Date: 2013-01-09 22:37
-- Who: Ludovicus Maior
-- Log: Added CN and CS tags

-- URL: http://wow-pro.com/node/3295/revisions/24992/view
-- Date: 2012-05-27 18:58
-- Who: Ludovicus Maior
-- Log: Missing coord for Ha'wana.

-- URL: http://wow-pro.com/node/3295/revisions/24923/view
-- Date: 2012-01-25 21:01
-- Who: Ludovicus Maior
-- Log: Followon guide is now ScoSho7879 for both factions.

-- URL: http://wow-pro.com/node/3295/revisions/24850/view
-- Date: 2011-12-10 03:50
-- Who: Crackerhead22
-- Log: Minor tweaking, plus 4.3 updates.

-- URL: http://wow-pro.com/node/3295/revisions/24758/view
-- Date: 2011-10-10 23:49
-- Who: Gethe

-- URL: http://wow-pro.com/node/3295/revisions/24757/view
-- Date: 2011-10-10 17:34
-- Who: Crackerhead22
-- Log: Created neutral guide, credit to Gethe. 

-- URL: http://wow-pro.com/node/3295/revisions/24750/view
-- Date: 2011-09-21 08:37
-- Who: Crackerhead22
-- Log: Added sticky steps, added missing notes, added missing cords, changed a couple of notes.

-- URL: http://wow-pro.com/node/3295/revisions/24327/view
-- Date: 2011-04-29 16:06
-- Who: Ludovicus Maior
-- Log: Line 40 for step A has 3 M coords, Line 182 for step A has unknown tag [12740].

-- URL: http://wow-pro.com/node/3295/revisions/24203/view
-- Date: 2011-04-02 19:18
-- Who: Ludovicus Maior
-- Log: OK, this is a HUGE update. Added From/To notes to most quests.   Added [The Amphitheater of Anguish] series.  Eliminated LightSpeed advice dependencies and added some notes and QO tags.

-- URL: http://wow-pro.com/node/3295/revisions/24166/view
-- Date: 2011-03-12 18:33
-- Who: Ludovicus Maior
-- Log: Make guide IDs unique

-- URL: http://wow-pro.com/node/3295/revisions/23482/view
-- Date: 2010-12-03 22:28
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3295/revisions/23481/view
-- Date: 2010-12-03 22:28
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("ScoZul7778", "Zul'Drak", "Scoot", "77", "78", "ScoSho7879|ScoSho7879", "Neutral", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
