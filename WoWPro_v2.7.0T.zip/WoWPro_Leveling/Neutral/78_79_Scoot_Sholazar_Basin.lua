
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_sholazar_basin_neutral
-- Date: 2013-03-23 18:33
-- Who: Ludovicus Maior
-- Log: In guide ScoSho7879, quest 12699's name [An Embarassing Incident] does not match Grail's database [An Embarrassing Incident].
--	In guide ScoSho7879, quest 12559's name [Powering the Waygate - The Maker's Perch] does not match Grail's database [Powering the Waygate - The Makers' Perch].
--	In guide ScoSho7879, quest 12613's name [Powering the Waygate - The Maker's Overlook] does not match Grail's database [Powering the Waygate - The Makers' Overlook].

-- URL: http://wow-pro.com/node/3297/revisions/25441/view
-- Date: 2013-01-13 16:16
-- Who: Ludovicus Maior
-- Log: Added CN tag

-- URL: http://wow-pro.com/node/3297/revisions/25310/view
-- Date: 2013-01-09 22:35
-- Who: Ludovicus Maior
-- Log: Added CS and CN tags

-- URL: http://wow-pro.com/node/3297/revisions/25273/view
-- Date: 2012-12-27 18:46
-- Who: Ludovicus Maior
-- Log: Whoops, the Archmage is in Dalaran.

-- URL: http://wow-pro.com/node/3297/revisions/25039/view
-- Date: 2012-08-02 11:16
-- Who: Fluclo

-- URL: http://wow-pro.com/node/3297/revisions/24916/view
-- Date: 2012-01-23 06:06
-- Who: Crackerhead22
-- Log: Converted to Neutral.

-- URL: http://wow-pro.com/node/3297/revisions/24379/view
-- Date: 2011-05-11 18:39
-- Who: Crackerhead22
-- Log: Syntax errors fixed.

-- URL: http://wow-pro.com/node/3297/revisions/24370/view
-- Date: 2011-05-07 10:24
-- Who: Crackerhead22
-- Log: Added in notes, QO steps, fixed a few steps, added sticky steps.

-- URL: http://wow-pro.com/node/3297/revisions/24310/view
-- Date: 2011-04-29 15:07
-- Who: Ludovicus Maior
-- Log: Line 31 for step T Bad coord 58.65. ,  Line 221 for step C has unknown tag [Kill Frenzyhearts in the area.], Line 327 for step K has 1 M coords.

-- URL: http://wow-pro.com/node/3297/revisions/24216/view
-- Date: 2011-04-05 23:26
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3297/revisions/24204/view
-- Date: 2011-04-02 19:30
-- Who: Ludovicus Maior
-- Log: A Major update, adding From/To Notes, tweaking coordinates, adding QO tags and adding ingame advice for some kills instead of referring to LightSpeed.

-- URL: http://wow-pro.com/node/3297/revisions/24168/view
-- Date: 2011-03-12 18:35
-- Who: Ludovicus Maior
-- Log: Unique Guide IDs

-- URL: http://wow-pro.com/node/3297/revisions/23486/view
-- Date: 2010-12-03 22:30
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3297/revisions/23485/view
-- Date: 2010-12-03 22:30
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("ScoSho7879", "Sholazar Basin", "Scoot", "78", "79", "EstIce7985|ScoSto7980", "Neutral", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
