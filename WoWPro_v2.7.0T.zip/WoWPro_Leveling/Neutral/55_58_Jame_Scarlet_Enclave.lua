
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_scarlet_enclave
-- Date: 2011-12-12 04:38
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3369/revisions/24491/view
-- Date: 2011-06-02 05:17
-- Who: Crackerhead22
-- Log: Added notes, fixed a couple of cords, added in the turn-ins for the quests "Where Kings Walk" and "Warchief's Blessing." Changed Map ID to "ScarletEnclave (Death Knight)" as "ScarletEnclave - Death Knight" was giving me a map can not be found error. Added a few steps to get Death Knights to Blasted Lands.

-- URL: http://wow-pro.com/node/3369/revisions/24469/view
-- Date: 2011-05-31 21:09
-- Who: Ludovicus Maior
-- Log: ScarletEnclave is the zone name!

-- URL: http://wow-pro.com/node/3369/revisions/24118/view
-- Date: 2011-02-18 18:16
-- Who: wkjezz

-- URL: http://wow-pro.com/node/3369/revisions/24104/view
-- Date: 2011-02-08 03:05
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3369/revisions/24102/view
-- Date: 2011-02-07 11:53
-- Who: Gylin
-- Log: title typo fix

-- URL: http://wow-pro.com/node/3369/revisions/24101/view
-- Date: 2011-02-05 21:26
-- Who: Ludovicus Maior
-- Log: Initial Create

WoWPro.Leveling:RegisterGuide("JamScar5558", "ScarletEnclave (Death Knight)", "Jame", "55", "58", "CraBla5458|JiyBla5560", "Neutral", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
