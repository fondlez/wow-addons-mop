
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_townlong_steppes_neutral
-- Date: 2013-05-28 12:19
-- Who: Ludovicus Maior
-- Log: Corrected coords, quids, and some extra CC's that were preventing R step completion.

-- URL: http://wow-pro.com/node/3492/revisions/25612/view
-- Date: 2013-05-09 22:11
-- Who: Ludovicus Maior
-- Log: Corrected T|Kill Voress'thalik|

-- URL: http://wow-pro.com/node/3492/revisions/25519/view
-- Date: 2013-02-06 20:15
-- Who: Ludovicus Maior
-- Log: Coord fixes through  Rensai's Watchpost.

-- URL: http://wow-pro.com/node/3492/revisions/25406/view
-- Date: 2013-01-13 01:26
-- Who: Ludovicus Maior
-- Log: Added a CS tag

-- URL: http://wow-pro.com/node/3492/revisions/25201/view
-- Date: 2012-11-11 03:04
-- Who: Ludovicus Maior
-- Log: Hatred's Vice Cooord Corrections.

-- URL: http://wow-pro.com/node/3492/revisions/25194/view
-- Date: 2012-11-10 01:59
-- Who: JamesL85
-- Log: C step for The Taking of Dusklight had a 4 in front of the QID.  Also changed the T step coords.

-- URL: http://wow-pro.com/node/3492/revisions/25193/view
-- Date: 2012-11-10 01:33
-- Who: JamesL85
-- Log: Changed the R step for Dusklight Bridge.  They were set to the coords for the previous A step.

-- URL: http://wow-pro.com/node/3492/revisions/25151/view
-- Date: 2012-10-22 20:10
-- Who: Ludovicus Maior
-- Log: Merged https://github.com/Emmaleah/WoW-Pro-Guides/blob/master/WoWPro_Leveling/Neutral/89_90_Emmaleah_Townlong_Steppes.lua on 10/22/2012 14:09 EST.

-- URL: http://wow-pro.com/node/3492/revisions/25086/view
-- Date: 2012-09-25 00:51
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3492/revisions/25081/view
-- Date: 2012-09-24 22:46
-- Who: Ludovicus Maior
-- Log: Merged https://github.com/Emmaleah/WoW-Pro-Guides/blob/b143e2b68171017e6df091ec22315a977a43e4c6/WoWPro_Leveling/Neutral/89_90_Emmaleah_Townlong_Steppes.lua

-- URL: http://wow-pro.com/node/3492/revisions/25070/view
-- Date: 2012-09-15 20:00
-- Who: Ludovicus Maior
-- Log: Applied https://github.com/Laotseu/WoW-Pro-Guides/blob/master/WoWPro_Leveling/Neutral/89_90_Emmaleah_TownlongSteppes.lua

-- URL: http://wow-pro.com/node/3492/revisions/25069/view
-- Date: 2012-09-15 19:57
-- Who: Ludovicus Maior
-- Log: Corrected URLs.

-- URL: http://wow-pro.com/node/3492/revisions/25068/view
-- Date: 2012-09-15 19:56
-- Who: Ludovicus Maior
-- Log: Original from Emmaleah

WoWPro.Leveling:RegisterGuide('EmmTow8990', 'Townlong Steppes', 'Emmaleah', '89', '90', 'EmmDre8990|EmmDre8990', 'Neutral', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
