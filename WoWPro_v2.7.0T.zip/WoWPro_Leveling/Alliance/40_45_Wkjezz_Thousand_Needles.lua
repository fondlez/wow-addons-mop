
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_thousand_needles_alliance
-- Date: 2013-03-23 20:31
-- Who: Ludovicus Maior
-- Log: Quest name tweak

-- URL: http://wow-pro.com/node/3253/revisions/25427/view
-- Date: 2013-01-13 15:09
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3253/revisions/24593/view
-- Date: 2011-06-25 01:14
-- Who: Crackerhead22
-- Log: ! Duplicate A step for qid 25486 - Removed line.
--	! Duplicate T step for qid 25488 - Removed line.
--	! Duplicate A step for qid 25488 - Removed line.
--	! Duplicate T step for qid 25488 - Removed line.
--	! Duplicate A step for qid 25835 - Removed line.

-- URL: http://wow-pro.com/node/3253/revisions/24459/view
-- Date: 2011-05-30 17:57
-- Who: Ludovicus Maior
-- Log: ! Line 129 for step R has 1 M coords: [R The Admiral's Den|M|25627|M|92.02,83.23|N|Head to the cave that is The Admiral's Den.|]

-- URL: http://wow-pro.com/node/3253/revisions/24423/view
-- Date: 2011-05-26 14:21
-- Who: Crackerhead22
-- Log: Added notes, fixed a cord or two, removed the static |QID|99999|s.

-- URL: http://wow-pro.com/node/3253/revisions/24302/view
-- Date: 2011-04-29 14:43
-- Who: Ludovicus Maior
-- Log: Line 78 for step C has unknown tag [Collect Rocket Car Parts from the ground.], Line 82 for step C has unknown tag [Collect Rocket Car Parts from the ground.], Line 89 for step A has unknown tag [Heads-up Accept].

-- URL: http://wow-pro.com/node/3253/revisions/24086/view
-- Date: 2011-01-30 19:37
-- Who: Ludovicus Maior
-- Log: Corrected RegisterGuide line to match GIT

-- URL: http://wow-pro.com/node/3253/revisions/23974/view
-- Date: 2011-01-10 11:35
-- Who: Fluclo

-- URL: http://wow-pro.com/node/3253/revisions/23973/view
-- Date: 2011-01-10 11:33
-- Who: Fluclo
-- Log: Various updates to log to improve flow

-- URL: http://wow-pro.com/node/3253/revisions/23952/view
-- Date: 2011-01-07 23:57
-- Who: Fluclo
-- Log: Corrected and improved In the Outhouse quest

-- URL: http://wow-pro.com/node/3253/revisions/23951/view
-- Date: 2011-01-07 23:45
-- Who: Fluclo
-- Log: Corrected the starting note for In the Outhouse

-- URL: http://wow-pro.com/node/3253/revisions/23949/view
-- Date: 2011-01-07 23:42
-- Who: Fluclo
-- Log: Added a seperate step to buy a bottle of grog for Bar Fight, fixed typo on note

-- URL: http://wow-pro.com/node/3253/revisions/23947/view
-- Date: 2011-01-07 23:35
-- Who: Fluclo
-- Log: Added starting information on how to get there, the three optional breadcrumb quests, corrected turnin QID for The Grimtotem are Coming and added a note of warning for quest Two If By Boat.

-- URL: http://wow-pro.com/node/3253/revisions/23603/view
-- Date: 2010-12-05 07:59
-- Who: wkjezz

-- URL: http://wow-pro.com/node/3253/revisions/23602/view
-- Date: 2010-12-05 07:58
-- Who: wkjezz

-- URL: http://wow-pro.com/node/3253/revisions/23387/view
-- Date: 2010-12-03 11:37
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3253/revisions/23386/view
-- Date: 2010-12-03 11:36
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('WkjTho4045', 'Thousand Needles', 'Wkjezz', '40', '45', 'WkjTan4550', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
