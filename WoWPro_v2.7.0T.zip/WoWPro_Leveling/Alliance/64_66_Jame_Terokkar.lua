
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_terokkar_forest_alliance
-- Date: 2013-08-15 23:23
-- Who: Ludovicus Maior
-- Log: Add missing coords around [Terokkarantula] quests.

-- URL: http://wow-pro.com/node/3277/revisions/25400/view
-- Date: 2013-01-13 01:12
-- Who: Ludovicus Maior
-- Log: Some CN tags

-- URL: http://wow-pro.com/node/3277/revisions/24890/view
-- Date: 2012-01-18 22:02
-- Who: Ludovicus Maior
-- Log: Add coords for [ Taken in the Night], [Auchindoun] and [Skywing].

-- URL: http://wow-pro.com/node/3277/revisions/24836/view
-- Date: 2011-12-05 13:28
-- Who: Crackerhead22
-- Log: 4.3 updates

-- URL: http://wow-pro.com/node/3277/revisions/24677/view
-- Date: 2011-07-11 22:37
-- Who: Ludovicus Maior
-- Log: Add numeric REP tags

-- URL: http://wow-pro.com/node/3277/revisions/24470/view
-- Date: 2011-05-31 21:41
-- Who: Crackerhead22
-- Log: Fixed typos found by andyarnolduk.

-- URL: http://wow-pro.com/node/3277/revisions/24424/view
-- Date: 2011-05-27 02:13
-- Who: Crackerhead22
-- Log: Fixed typo on step "N Northern Altar|QID|10021|N|Right-click the northern altar here.|M|50.70,16.60|QO|Northern Altar: 1/1|REP|Aldor|" and fixed flight point grab for Allerian Stronghold.

-- URL: http://wow-pro.com/node/3277/revisions/24306/view
-- Date: 2011-04-29 14:51
-- Who: Ludovicus Maior
-- Log: Line 55 for step N has 3 M coords, Line 248 for step C has unknown tag [52.00,58.00], Line 273 for step C has unknown tag [52.00,58.00], Line 289 for step T has unknown tag [To Magistriz Fyalenn.].

-- URL: http://wow-pro.com/node/3277/revisions/24208/view
-- Date: 2011-04-05 11:02
-- Who: Crackerhead22
-- Log: Fixed REP tag so it would work, fixed notes, fixed cords.  Added O tags, added couple of sticky steps.

-- URL: http://wow-pro.com/node/3277/revisions/24122/view
-- Date: 2011-02-21 00:07
-- Who: Crackerhead22
-- Log: Added missing zone tag.

-- URL: http://wow-pro.com/node/3277/revisions/24119/view
-- Date: 2011-02-20 17:24
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3277/revisions/24004/view
-- Date: 2011-01-17 03:49
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3277/revisions/24003/view
-- Date: 2011-01-17 03:25
-- Who: Crackerhead22
-- Log: Updated source code for so it includes |Rep| tags.

-- URL: http://wow-pro.com/node/3277/revisions/23953/view
-- Date: 2011-01-08 10:35
-- Who: Crackerhead22
-- Log: Fixed setting hearth step not auto-completing, fixed a couple missing |Z| tag issue.

-- URL: http://wow-pro.com/node/3277/revisions/23731/view
-- Date: 2010-12-11 02:36
-- Who: Crackerhead22
-- Log: Updated source code for Aldor and Scryers.  Added in |Z| where needed, added sticky steps, removed an outdated quest.

-- URL: http://wow-pro.com/node/3277/revisions/23445/view
-- Date: 2010-12-03 21:32
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3277/revisions/23442/view
-- Date: 2010-12-03 21:22
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3277/revisions/23441/view
-- Date: 2010-12-03 21:21
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamTer6466", "Terokkar Forest", "Jame", "64", "66", "JamNag6668", "Alliance", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
