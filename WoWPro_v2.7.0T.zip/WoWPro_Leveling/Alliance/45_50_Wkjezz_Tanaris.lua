
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_tanaris_alliance
-- Date: 2013-01-12 19:08
-- Who: Ludovicus Maior
-- Log: Added CN and CS tags

-- URL: http://wow-pro.com/node/3259/revisions/25030/view
-- Date: 2012-07-06 21:07
-- Who: Ludovicus Maior
-- Log: Corrected quest [Tropical Paradise Beckons] to Flinn and his coords as per wowmanus, with more bits of coordinate accuracy from Ludo :-).

-- URL: http://wow-pro.com/node/3259/revisions/24873/view
-- Date: 2011-12-23 07:41
-- Who: Fluclo
-- Log: Added minimum level guide; At Level 44, you don't have the Flightpoint to Thousand Needles, so added info on getting there; You have the flightplan to Gadgetzan when you are in Speedbarge regardless of not previously using the route, so added this as your method of travel to avoid swimming/running.

-- URL: http://wow-pro.com/node/3259/revisions/24461/view
-- Date: 2011-05-30 18:00
-- Who: Ludovicus Maior
-- Log: ! Line 84 for step C Bad coord 7288: [C To The Ground!|QID|25053|U|51547|M|7288,46.09|N|The last building to torch is here.|]

-- URL: http://wow-pro.com/node/3259/revisions/24426/view
-- Date: 2011-05-27 09:23
-- Who: Crackerhead22
-- Log: Added in "Tropical Paradise Beckons", the quest that leads you into Un'Goro Crater.

-- URL: http://wow-pro.com/node/3259/revisions/24425/view
-- Date: 2011-05-27 08:33
-- Who: Crackerhead22
-- Log: Added notes...

-- URL: http://wow-pro.com/node/3259/revisions/24417/view
-- Date: 2011-05-24 22:10
-- Who: Crackerhead22
-- Log: Removed the line "h Gadgetzan|QID|12650|M|52.60,27.02|N|At Innkeeper Fizzgrimble.|" as it was redundant.

-- URL: http://wow-pro.com/node/3259/revisions/24392/view
-- Date: 2011-05-17 01:03
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3259/revisions/24188/view
-- Date: 2011-03-20 20:27
-- Who: Ludovicus Maior
-- Log: Tepes had found duplicated A lines too!

-- URL: http://wow-pro.com/node/3259/revisions/24187/view
-- Date: 2011-03-20 20:23
-- Who: Ludovicus Maior
-- Log: Removed spurious 'A'steps for [Rocket Rescue] and [Scavengers Scavenged] and another spelin error.

-- URL: http://wow-pro.com/node/3259/revisions/24085/view
-- Date: 2011-01-30 19:36
-- Who: Ludovicus Maior
-- Log: Corrected RegisterGuide line to match GIT

-- URL: http://wow-pro.com/node/3259/revisions/23612/view
-- Date: 2010-12-05 18:57
-- Who: wkjezz

-- URL: http://wow-pro.com/node/3259/revisions/23400/view
-- Date: 2010-12-03 11:48
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3259/revisions/23399/view
-- Date: 2010-12-03 11:48
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('WkjTan4550', 'Tanaris', 'Wkjezz', '45', '50', 'JiyUng5055', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
