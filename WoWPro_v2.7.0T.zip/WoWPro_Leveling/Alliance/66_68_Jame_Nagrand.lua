
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_nagrand_alliance
-- Date: 2013-05-01 19:01
-- Who: Twists

-- URL: http://wow-pro.com/node/3279/revisions/25592/view
-- Date: 2013-03-23 20:27
-- Who: Ludovicus Maior
-- Log: Quest name cleanups

-- URL: http://wow-pro.com/node/3279/revisions/25403/view
-- Date: 2013-01-13 01:20
-- Who: Ludovicus Maior
-- Log: Lots of CN tags and a CS tag

-- URL: http://wow-pro.com/node/3279/revisions/25335/view
-- Date: 2013-01-11 20:04
-- Who: Emmaleah
-- Log: fix syntax for multi coordinates

-- URL: http://wow-pro.com/node/3279/revisions/24947/view
-- Date: 2012-02-13 00:40
-- Who: Crackerhead22
-- Log: Fixed line for "C Agitated Spirits of Skysong|" via Hendo72's suggestions.

-- URL: http://wow-pro.com/node/3279/revisions/24912/view
-- Date: 2012-01-20 21:13
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3279/revisions/24911/view
-- Date: 2012-01-20 21:11
-- Who: Crackerhead22
-- Log: Added REP tags to certain Consortium quests.

-- URL: http://wow-pro.com/node/3279/revisions/24880/view
-- Date: 2012-01-02 06:21
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3279/revisions/24840/view
-- Date: 2011-12-07 18:19
-- Who: Crackerhead22
-- Log: 4.3 updates

-- URL: http://wow-pro.com/node/3279/revisions/24567/view
-- Date: 2011-06-20 23:03
-- Who: ikiboun
-- Log: edit note and modified coord for Zorbo location

-- URL: http://wow-pro.com/node/3279/revisions/24559/view
-- Date: 2011-06-19 02:20
-- Who: Crackerhead22
-- Log: Cord fixed for the turn-in for "Crackin' Some Skulls" and the accept for "It's Just That Easy?"

-- URL: http://wow-pro.com/node/3279/revisions/24307/view
-- Date: 2011-04-29 14:56
-- Who: Ludovicus Maior
-- Log: Line 133 for step N has too short a title, Line 174 for step N has too short a title, Line 239 for step A has unknown tag [From Corki.], Line 305 for step C has 1 M coords.

-- URL: http://wow-pro.com/node/3279/revisions/24229/view
-- Date: 2011-04-06 14:49
-- Who: Crackerhead22
-- Log: Added in missing notes on "The Master Planner" and "Patience and Understanding".

-- URL: http://wow-pro.com/node/3279/revisions/24228/view
-- Date: 2011-04-06 14:45
-- Who: Crackerhead22
-- Log: Re-arranged steps, added sticky steps, fixed few notes, fixed a few cords, added in the rest of Altruis the Sufferer's quests.

-- URL: http://wow-pro.com/node/3279/revisions/23824/view
-- Date: 2010-12-24 01:53
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3279/revisions/23823/view
-- Date: 2010-12-24 00:55
-- Who: Crackerhead22
-- Log: Fixed from notes via tepes had made.

-- URL: http://wow-pro.com/node/3279/revisions/23809/view
-- Date: 2010-12-21 21:53
-- Who: Crackerhead22
-- Log: Added |M| tags, NPC and step notes, added |QO| tags to a few steps, added Sticky steps, added missing quest steps.

-- URL: http://wow-pro.com/node/3279/revisions/23447/view
-- Date: 2010-12-03 21:34
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3279/revisions/23446/view
-- Date: 2010-12-03 21:34
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamNag6668", "Nagrand", "Jame", "66", "68", "JamBla6870", "Alliance", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
