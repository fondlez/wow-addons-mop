
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_shadowmoon_valley_alliance
-- Date: 2013-01-12 20:44
-- Who: Emmaleah
-- Log: fixes for multi coordinates

-- URL: http://wow-pro.com/node/3285/revisions/25336/view
-- Date: 2013-01-11 20:27
-- Who: Emmaleah
-- Log: fix syntax for multi coordinates

-- URL: http://wow-pro.com/node/3285/revisions/25088/view
-- Date: 2012-09-25 00:53
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3285/revisions/24675/view
-- Date: 2011-07-11 22:34
-- Who: Ludovicus Maior
-- Log: Cgange to Numeric REP tags

-- URL: http://wow-pro.com/node/3285/revisions/24576/view
-- Date: 2011-06-22 02:14
-- Who: Ludovicus Maior
-- Log: # Checking ../WoWPro_Leveling/Alliance/70_70_Crackerhead22_Shadowmoon.lua
--	! Line 150 for step A has unknown tag [From Stormer Ewan Wildwing.]: [A Minions of the Shadow Council|QID|10582|M|40.43,41.36|From Stormer Ewan Wildwing.|]

-- URL: http://wow-pro.com/node/3285/revisions/24565/view
-- Date: 2011-06-20 03:10
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3285/revisions/24386/view
-- Date: 2011-05-15 18:13
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3285/revisions/24383/view
-- Date: 2011-05-15 01:21
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3285/revisions/24382/view
-- Date: 2011-05-14 22:36
-- Who: Crackerhead22
-- Log: Added missing Scryer quest accept and flight point.

-- URL: http://wow-pro.com/node/3285/revisions/24221/view
-- Date: 2011-04-05 23:34
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3285/revisions/24190/view
-- Date: 2011-03-20 20:39
-- Who: Ludovicus Maior
-- Log: Major update; lots of coord updates, missing quests for scryers, missing 'C' lines, added waypoints.

-- URL: http://wow-pro.com/node/3285/revisions/24027/view
-- Date: 2011-01-21 21:02
-- Who: Crackerhead22
-- Log: Changed reputation tags to the way Twists asked them to be.

-- URL: http://wow-pro.com/node/3285/revisions/24007/view
-- Date: 2011-01-17 04:07
-- Who: Crackerhead22
-- Log: Added note about group quests.

-- URL: http://wow-pro.com/node/3285/revisions/24006/view
-- Date: 2011-01-17 03:53
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3285/revisions/24005/view
-- Date: 2011-01-17 03:50
-- Who: Crackerhead22
-- Log: Updated source code for so it includes |Rep| tags

-- URL: http://wow-pro.com/node/3285/revisions/23798/view
-- Date: 2010-12-20 14:06
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3285/revisions/23796/view
-- Date: 2010-12-19 12:07
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3285/revisions/23795/view
-- Date: 2010-12-19 11:43
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3285/revisions/23794/view
-- Date: 2010-12-19 11:42
-- Who: Crackerhead22
-- Log: Added in Aldor source code

-- URL: http://wow-pro.com/node/3285/revisions/23461/view
-- Date: 2010-12-03 21:58
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3285/revisions/23460/view
-- Date: 2010-12-03 21:57
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3285/revisions/23459/view
-- Date: 2010-12-03 21:57
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('CraSha7070A', 'Shadowmoon Valley', 'Crackerhead22', '69', '70', 'JamBor6872', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
