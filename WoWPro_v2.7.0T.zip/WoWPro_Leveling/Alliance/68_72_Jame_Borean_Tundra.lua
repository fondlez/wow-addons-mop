
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_borean_tundra_alliance
-- Date: 2013-05-14 15:40
-- Who: Ludovicus Maior
-- Log: Corrected name of [Military?  What Military?]

-- URL: http://wow-pro.com/node/3289/revisions/25366/view
-- Date: 2013-01-12 18:59
-- Who: Ludovicus Maior
-- Log: Added CN and CC tags

-- URL: http://wow-pro.com/node/3289/revisions/25038/view
-- Date: 2012-07-27 19:27
-- Who: Estelyen
-- Log: Rewrite of the guide to allow for starting Northrend at level 68

-- URL: http://wow-pro.com/node/3289/revisions/25002/view
-- Date: 2012-06-08 14:12
-- Who: Ludovicus Maior
-- Log: Correct P tag for cooking quest note.

-- URL: http://wow-pro.com/node/3289/revisions/24938/view
-- Date: 2012-02-05 14:40
-- Who: Ludovicus Maior
-- Log: Quest name corrections

-- URL: http://wow-pro.com/node/3289/revisions/24856/view
-- Date: 2011-12-10 15:28
-- Who: Crackerhead22
-- Log: 4.3 updates

-- URL: http://wow-pro.com/node/3289/revisions/24665/view
-- Date: 2011-07-06 14:37
-- Who: Crackerhead22
-- Log: Added notes in the "The Hunt is On" steps about talking to the cultists.

-- URL: http://wow-pro.com/node/3289/revisions/24595/view
-- Date: 2011-06-25 01:24
-- Who: Crackerhead22
-- Log: Removed "This quest needs to be manually clicked off because there is no turnin." from the line of "A A Mission Statement |QID|11864|N|From Arch Druid Lathorius.|M|57.06,44.30|"

-- URL: http://wow-pro.com/node/3289/revisions/24364/view
-- Date: 2011-05-04 09:35
-- Who: Crackerhead22
-- Log: Added |P| tag for cooking quest line.

-- URL: http://wow-pro.com/node/3289/revisions/24258/view
-- Date: 2011-04-24 00:31
-- Who: Crackerhead22
-- Log: Fixed line-! Line 363 for step A has unknown tag [3]: [A Surrounded! |QID|11944|N|From Corporal Venn.|M|82.02,46.42|3]
--	Fixed line-! Line 502 for step F Bad coord 334.14: [F Amber Ledge |QID|11704|N|Fly to Amber Ledge or take a free teleport from Librarian Tiare.|M|33.28,334.14|]

-- URL: http://wow-pro.com/node/3289/revisions/24015/view
-- Date: 2011-01-18 19:23
-- Who: Fluclo
-- Log: Added NonCombat tag to quest Khu'nok Will Know 

-- URL: http://wow-pro.com/node/3289/revisions/24014/view
-- Date: 2011-01-18 19:04
-- Who: Fluclo
-- Log: Added QID to Flying so that it doesn't show each time the guide is reset

-- URL: http://wow-pro.com/node/3289/revisions/24013/view
-- Date: 2011-01-18 18:58
-- Who: Fluclo
-- Log: Changed Overcharged Capacity to Buy instead of Note

-- URL: http://wow-pro.com/node/3289/revisions/24012/view
-- Date: 2011-01-18 18:52
-- Who: Fluclo
-- Log: Added more info for Overcharged Capacitor step

-- URL: http://wow-pro.com/node/3289/revisions/23975/view
-- Date: 2011-01-10 15:07
-- Who: Crackerhead22
-- Log: ;

-- URL: http://wow-pro.com/node/3289/revisions/23946/view
-- Date: 2011-01-07 22:46
-- Who: Crackerhead22
-- Log: Cleaned up(condensed) code, added quest accept and turn-in of "Hero's Call: Northrend!" and added note about purchasing Cold Weather Flying.

-- URL: http://wow-pro.com/node/3289/revisions/23860/view
-- Date: 2010-12-30 03:47
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3289/revisions/23469/view
-- Date: 2010-12-03 22:16
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3289/revisions/23468/view
-- Date: 2010-12-03 22:13
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamBor6872", "Borean Tundra", "Jame", "68", "72", "JamHow7274", "Alliance", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
