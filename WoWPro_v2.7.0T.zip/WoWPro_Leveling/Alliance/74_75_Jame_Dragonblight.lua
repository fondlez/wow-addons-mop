
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_dragonblight_alliance
-- Date: 2013-05-14 15:39
-- Who: Ludovicus Maior
-- Log: Bad M coords!

-- URL: http://wow-pro.com/node/3291/revisions/25414/view
-- Date: 2013-01-13 14:37
-- Who: Ludovicus Maior
-- Log: Added CC tag

-- URL: http://wow-pro.com/node/3291/revisions/25365/view
-- Date: 2013-01-12 18:52
-- Who: Ludovicus Maior
-- Log: Added CN and CS tags

-- URL: http://wow-pro.com/node/3291/revisions/24990/view
-- Date: 2012-05-27 18:53
-- Who: Ludovicus Maior
-- Log: Noted some missing quests, corrected some coords.

-- URL: http://wow-pro.com/node/3291/revisions/24860/view
-- Date: 2011-12-10 17:13
-- Who: Crackerhead22
-- Log: 4.3 updates

-- URL: http://wow-pro.com/node/3291/revisions/24749/view
-- Date: 2011-09-18 08:36
-- Who: Crackerhead22
-- Log: Added missing notes, cords. Fixed a couple of notes and cords.

-- URL: http://wow-pro.com/node/3291/revisions/24309/view
-- Date: 2011-04-29 15:01
-- Who: Ludovicus Maior
-- Log: Line 299 for step N has 1 M coords:

-- URL: http://wow-pro.com/node/3291/revisions/24261/view
-- Date: 2011-04-24 00:42
-- Who: Crackerhead22
-- Log: Fixed line-! Line 65 for step C has unknown tag [Kill Vengeful Geists to free the Trapped Wintergarde Villagers.]: [C Rescue from Town Square|QID|12253|S|QO|N|Kill Vengeful Geists to free the Trapped Wintergarde Villagers.|]
--	Fixed line-! Line 67 for step C has unknown tag [Now just go from one building to another, killing Vengeful Geists to free the Trapped Wintergarde Villagers.]: [C Rescue from Town Square|QID|12253|US|QO|N|Now just go from one building to another, killing Vengeful Geists to free the Trapped Wintergarde Villagers.|]
--	Fixed line-! Line 79 for step C has unknown tag [Q]: [C The Bleeding Ore |QID|12272| |Q|The Bleeding Ore|S|N|Mine the Strange Ore nodes.|M|80.4,45.1|]
--	Fixed line-! Line 88 for step C has unknown tag [Q]: [C The Bleeding Ore |QID|12272|US|Q|The Bleeding Ore|N|Finish getting the ore you need.|M|80.4,45.1|]
--	Fixed line-! Line 152 for step T has unknown tag [To the Image of Archmage Modera.]: [T Rifle the Bodies |QID|12000| |N|N|To the Image of Archmage Modera.|M|29.00,55.50|]
--	Fixed line-! Line 223 for step A has unknown tag [From Elder Mana'loa.]: [A Conversing With the Depths |QID|12032|M|36.62,64.98|From Elder Mana'loa.|]
--	Fixed line-! Line 288 for step N has 1 M coords: [N Plague Wagons Sabotaged|QID|12326|M||Get near a Plaue Wagon and use Ability #3, defend the Gnome until you get a quest update. Do this 6 times.|QO|Plague Wagon Sabotaged: 6/6|]

-- URL: http://wow-pro.com/node/3291/revisions/24234/view
-- Date: 2011-04-19 03:14
-- Who: Crackerhead22
-- Log: Added a lot of notes, added sticky steps.

-- URL: http://wow-pro.com/node/3291/revisions/24164/view
-- Date: 2011-03-12 18:30
-- Who: Ludovicus Maior
-- Log: Grizz changed ID

-- URL: http://wow-pro.com/node/3291/revisions/24138/view
-- Date: 2011-02-28 20:48
-- Who: Ludovicus Maior
-- Log: Eliminated sequence [Reborn From The Ashes], [Fate, Up Against Your Will],
--	 [A Royal Coup], [The Killing Time], [The Battle For The Undercity].
--	
--	Kudos to Dez, seeyabye91, and exace for being persistent.

-- URL: http://wow-pro.com/node/3291/revisions/23474/view
-- Date: 2010-12-03 22:19
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3291/revisions/23473/view
-- Date: 2010-12-03 22:18
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamDra7475", "Dragonblight", "Jame", "74", "75", "JamGriA7577", "Alliance", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
