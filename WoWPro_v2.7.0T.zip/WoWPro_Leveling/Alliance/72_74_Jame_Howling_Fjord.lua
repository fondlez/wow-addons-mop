
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_howling_fjord_alliance
-- Date: 2013-03-23 20:40
-- Who: Ludovicus Maior
-- Log: quest name tweaks

-- URL: http://wow-pro.com/node/3287/revisions/25439/view
-- Date: 2013-01-13 16:12
-- Who: Ludovicus Maior
-- Log: Added CN tags

-- URL: http://wow-pro.com/node/3287/revisions/24989/view
-- Date: 2012-05-27 18:46
-- Who: Ludovicus Maior
-- Log: Added a few U and T tags, corrected quest name.

-- URL: http://wow-pro.com/node/3287/revisions/24857/view
-- Date: 2011-12-10 15:57
-- Who: Crackerhead22
-- Log: 4.3 update

-- URL: http://wow-pro.com/node/3287/revisions/24260/view
-- Date: 2011-04-24 00:35
-- Who: Crackerhead22
-- Log: Fixed line-! Line 285 for step T has unknown tag [Zeh'gehn.]: [T A Carver and a Croaker |QID|11476|M|35.6,80.6|Zeh'gehn.|]

-- URL: http://wow-pro.com/node/3287/revisions/24062/view
-- Date: 2011-01-27 12:43
-- Who: Fluclo
-- Log: Added coords for eggs

-- URL: http://wow-pro.com/node/3287/revisions/23989/view
-- Date: 2011-01-15 18:38
-- Who: Crackerhead22
-- Log: Added notes, fixed notes. Added cords, fixed cords. Added sticky steps.

-- URL: http://wow-pro.com/node/3287/revisions/23465/view
-- Date: 2010-12-03 22:08
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3287/revisions/23464/view
-- Date: 2010-12-03 22:07
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamHow7274", "Howling Fjord", "Jame", "72", "74", "JamDra7475", "Alliance", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
