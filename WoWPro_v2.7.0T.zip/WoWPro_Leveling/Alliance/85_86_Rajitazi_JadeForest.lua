
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_jade_forest_alliance
-- Date: 2013-06-20 13:25
-- Who: Kaboca
-- Log: +Added some lorewalkers exploration/reputation related lines. Also corrected coordinates for Elder Lusshan, he is on the hill.

-- URL: http://wow-pro.com/node/3486/revisions/25394/view
-- Date: 2013-01-12 22:38
-- Who: Ludovicus Maior
-- Log: Added CS tags

-- URL: http://wow-pro.com/node/3486/revisions/25339/view
-- Date: 2013-01-11 20:36
-- Who: Emmaleah
-- Log: fix syntax for multi coordinates

-- URL: http://wow-pro.com/node/3486/revisions/25204/view
-- Date: 2012-11-12 23:17
-- Who: Ludovicus Maior
-- Log: Tweak Zhi-Zhi fight and turnin.

-- URL: http://wow-pro.com/node/3486/revisions/25197/view
-- Date: 2012-11-11 00:03
-- Who: Emmaleah
-- Log: 10 Nov 2012 - Emmaleah - added change log, header, rtn line, and most of the "one time" treasure items. (see comments in change log)
--	

-- URL: http://wow-pro.com/node/3486/revisions/25175/view
-- Date: 2012-11-01 17:15
-- Who: Fluclo

-- URL: http://wow-pro.com/node/3486/revisions/25146/view
-- Date: 2012-10-20 22:49
-- Who: Ludovicus Maior
-- Log: More coord tweaks, spelling corrections, more QO's and glitch warnings.

-- URL: http://wow-pro.com/node/3486/revisions/25141/view
-- Date: 2012-10-13 21:44
-- Who: Ludovicus Maior
-- Log: Lots of coord edits, paths to places and a few spell/quest corrections.
--	Added more QO tags and corrected a few syntax errors.

-- URL: http://wow-pro.com/node/3486/revisions/25139/view
-- Date: 2012-10-12 05:50
-- Who: JamesL85
-- Log: The F step to fly to the Temple of the Jade Serpent did not auto-complete.  The map says Temple of the Jade Serpent, not The Temple of the Jade Serpent.  I took "The" out.  Will try again on the next toon.

-- URL: http://wow-pro.com/node/3486/revisions/25108/view
-- Date: 2012-10-07 00:18
-- Who: JamesL85
-- Log: The K tag for Zhi-Zhi didn't have the QO tag for it to auto-complete.

-- URL: http://wow-pro.com/node/3486/revisions/25107/view
-- Date: 2012-10-06 22:06
-- Who: JamesL85
-- Log: Added T step for Calamity Jade.

-- URL: http://wow-pro.com/node/3486/revisions/25106/view
-- Date: 2012-10-06 21:35
-- Who: JamesL85
-- Log: A step of An Air of Worry was 27376.  Changed it to 27576.  The T step was correct.

-- URL: http://wow-pro.com/node/3486/revisions/25104/view
-- Date: 2012-10-03 20:39
-- Who: Ludovicus Maior
-- Log: Change the start of the guide to add proper coords; tweak a few comments in the harbor; switch around the completions for Twinspire Towers to make it easier to complete.  Oh, and spelling errors.

-- URL: http://wow-pro.com/node/3486/revisions/25099/view
-- Date: 2012-10-02 01:49
-- Who: Ludovicus Maior
-- Log: Emmaleah: added quest A An error of worry, and lots of tweaks
--	Ludovicus: edited corrections to eliminate syntax errors and odd spellings. Manual merge.

-- URL: http://wow-pro.com/node/3486/revisions/25097/view
-- Date: 2012-10-02 00:47
-- Who: Ludovicus Maior
-- Log: Ennakeah: Added quest per comments.

-- URL: http://wow-pro.com/node/3486/revisions/25095/view
-- Date: 2012-09-28 00:40
-- Who: Laotseu
-- Log: Typos correction to make the autocompletion work.
--	Missing T steps for Pages of History and Lighting Up the Sky.
--	Fix some coordinated.
--	Reordered some steps.

-- URL: http://wow-pro.com/node/3486/revisions/25094/view
-- Date: 2012-09-27 10:07
-- Who: Estelyen
-- Log: Two minor fixes, turning in Down Kitty! makes more sense after collecting the silk as the questgiver is no longer following the player. Also the step to accept An Air of Worry was missing.

-- URL: http://wow-pro.com/node/3486/revisions/25089/view
-- Date: 2012-09-25 00:55
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3486/revisions/25084/view
-- Date: 2012-09-24 23:54
-- Who: Ludovicus Maior
-- Log: Twinspire Keep is not a valid zone. Green is not spelt gree!

-- URL: http://wow-pro.com/node/3486/revisions/25058/view
-- Date: 2012-08-28 19:44
-- Who: Ludovicus Maior
-- Log: Laotseu 6 days ago Play testing the Alliance The Jade Forest guide. 

-- URL: http://wow-pro.com/node/3486/revisions/25050/view
-- Date: 2012-08-28 19:03
-- Who: Ludovicus Maior
-- Log: Fix url references.

-- URL: http://wow-pro.com/node/3486/revisions/25049/view
-- Date: 2012-08-28 19:00
-- Who: Ludovicus Maior
-- Log: Initial Version Submitted by Emmaleah on Sat, 2012-08-18 15:07. 

WoWPro.Leveling:RegisterGuide('RajJad8586', 'The Jade Forest', 'Rajitazi', '85', '86', 'EmmVal8688', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
