
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_grizzly_hills_alliance
-- Date: 2013-05-16 21:03
-- Who: Fluclo
-- Log: Wolfsbane Root is to destroy not collect.

-- URL: http://wow-pro.com/node/3293/revisions/25665/view
-- Date: 2013-05-16 21:00
-- Who: Fluclo
-- Log: With a collection and killing quest, the killing should be stickied since you will likely kill when collecting.  Swapped Northern Hospitality to Sticky and Wolfsbane Root to main quest, and also added |NC| to the collect part of quest.

-- URL: http://wow-pro.com/node/3293/revisions/25649/view
-- Date: 2013-05-14 19:26
-- Who: Ludovicus Maior
-- Log: MIssing QID on T Fate and Coincidence 

-- URL: http://wow-pro.com/node/3293/revisions/25620/view
-- Date: 2013-05-14 11:45
-- Who: Fluclo
-- Log: -Added |NC| to Just Passing Through, Local Support, Doing Your Duty, Truce
--	-Added additional notes to Taking Their Rear, Just Passing Through, Local Support, Closing the Deal, Secrets of the Flamebinders, Talk to Budd, Filling the Cages, Seared Scourge.
--	-Added extra note and |NC| to Scourgekabob
--	-Added an extra loot step to Truce
--	-Added |QO| steps, updated titles, added |NC| for the Vial of Visions quest

-- URL: http://wow-pro.com/node/3293/revisions/25432/view
-- Date: 2013-01-13 15:18
-- Who: Ludovicus Maior
-- Log: Added CN tag

-- URL: http://wow-pro.com/node/3293/revisions/25337/view
-- Date: 2013-01-11 20:29
-- Who: Emmaleah
-- Log: fix syntax for multi coordinates

-- URL: http://wow-pro.com/node/3293/revisions/24759/view
-- Date: 2011-10-10 23:55
-- Who: Gethe

-- URL: http://wow-pro.com/node/3293/revisions/24754/view
-- Date: 2011-10-10 03:31
-- Who: Gethe

-- URL: http://wow-pro.com/node/3293/revisions/24629/view
-- Date: 2011-06-30 04:50
-- Who: Crackerhead22
-- Log: Fixed accept line of "Troll Season" per Bloodlusted's catch.

-- URL: http://wow-pro.com/node/3293/revisions/24257/view
-- Date: 2011-04-24 00:24
-- Who: Crackerhead22
-- Log: Fixed line-T Riding the Red Rocket|QID|12437|O|N|To Commander Howser.|M|M|14.8,86.6|
--	Fixed line-A The Captive Prospectors |QID|12180|N|From Mountaineer Kilian.|M|77.00,48.50|

-- URL: http://wow-pro.com/node/3293/revisions/24243/view
-- Date: 2011-04-20 23:13
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3293/revisions/24240/view
-- Date: 2011-04-19 23:49
-- Who: Crackerhead22

-- URL: http://wow-pro.com/node/3293/revisions/24235/view
-- Date: 2011-04-19 08:09
-- Who: Crackerhead22
-- Log: A lot of note updates, and added a few sticky steps.

-- URL: http://wow-pro.com/node/3293/revisions/24202/view
-- Date: 2011-04-02 19:09
-- Who: Ludovicus Maior
-- Log: Fixed bad U/QID tag on [Vordrassil's Sapling], corrected location text for [Hour of the Worg ] and added a tip for killing Goremaw.

-- URL: http://wow-pro.com/node/3293/revisions/24162/view
-- Date: 2011-03-12 18:29
-- Who: Ludovicus Maior
-- Log: Make guide id unique

-- URL: http://wow-pro.com/node/3293/revisions/23750/view
-- Date: 2010-12-12 07:35
-- Who: Bitsem
-- Log: I think I removed all the | |. If they were there for a reason, please revert it. lol.

-- URL: http://wow-pro.com/node/3293/revisions/23749/view
-- Date: 2010-12-12 07:26
-- Who: Bitsem
-- Log: For some reason there were a bunch of | | in the latter half of this guide. Removed them. From the quest "Truce" on. Lua errors reported by fourthand1.

-- URL: http://wow-pro.com/node/3293/revisions/23729/view
-- Date: 2010-12-10 21:54
-- Who: Crackerhead22
-- Log: Fixed "C Truce?" via Silvann's suggestion.

-- URL: http://wow-pro.com/node/3293/revisions/23478/view
-- Date: 2010-12-03 22:25
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3293/revisions/23477/view
-- Date: 2010-12-03 22:24
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide("JamGriA7577", "Grizzly Hills", "Jame", "75", "77", "ScoZul7778", "Alliance", function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]
end)
