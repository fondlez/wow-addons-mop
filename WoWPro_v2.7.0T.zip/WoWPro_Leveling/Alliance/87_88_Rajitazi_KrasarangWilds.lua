
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_krasarang_wilds_alliance
-- Date: 2013-06-18 01:08
-- Who: Ludovicus Maior
-- Log: quest 31410's name [Booties] does not match Grail's database [Equipment Locker].

-- URL: http://wow-pro.com/node/3488/revisions/25671/view
-- Date: 2013-05-17 19:21
-- Who: Ludovicus Maior
-- Log: Misplaced |M| on Materia Medica.

-- URL: http://wow-pro.com/node/3488/revisions/25391/view
-- Date: 2013-01-12 21:27
-- Who: Emmaleah
-- Log: fixes for multi coordinates

-- URL: http://wow-pro.com/node/3488/revisions/25340/view
-- Date: 2013-01-11 20:38
-- Who: Emmaleah
-- Log: fix syntax for multi coordinates

-- URL: http://wow-pro.com/node/3488/revisions/25238/view
-- Date: 2012-12-03 14:25
-- Who: Fluclo
-- Log: Added a finish collecting fangs step for Why So Serious?

-- URL: http://wow-pro.com/node/3488/revisions/25237/view
-- Date: 2012-12-03 14:17
-- Who: Fluclo
-- Log: Added a bit to get to the cave, and corrected a bad symbol on Jar of Pigment

-- URL: http://wow-pro.com/node/3488/revisions/25236/view
-- Date: 2012-12-03 14:13
-- Who: Fluclo
-- Log: Correct coords of Memorial Flame of Po

-- URL: http://wow-pro.com/node/3488/revisions/25214/view
-- Date: 2012-11-24 21:41
-- Who: Ludovicus Maior
-- Log: Played through and tweaked all over.  One toon found the bugs, the second tested the fixes!

-- URL: http://wow-pro.com/node/3488/revisions/25200/view
-- Date: 2012-11-11 00:52
-- Who: Emmaleah
-- Log: Emmaleah - 10 Nov 2012 - Added the "one time" treasure items. *and this change log*

-- URL: http://wow-pro.com/node/3488/revisions/25172/view
-- Date: 2012-10-27 20:54
-- Who: Ludovicus Maior
-- Log: OK, next set of coordinate corrections, text mods, et al

-- URL: http://wow-pro.com/node/3488/revisions/25171/view
-- Date: 2012-10-27 16:00
-- Who: Ludovicus Maior
-- Log: Coord fine tuning and occasional syntax fixes and duplicate step removals.

-- URL: http://wow-pro.com/node/3488/revisions/25122/view
-- Date: 2012-10-07 23:11
-- Who: Ludovicus Maior
-- Log: Merged https://github.com/Emmaleah/WoW-Pro-Guides/blob/master/WoWPro_Leveling/Alliance/87_88_Rajitazi_KrasarangWilds.lua with minor tweaks by ludo

-- URL: http://wow-pro.com/node/3488/revisions/25079/view
-- Date: 2012-09-24 22:34
-- Who: Ludovicus Maior
-- Log: Merged https://github.com/Emmaleah/WoW-Pro-Guides/blob/f25104bceccdf3d7adfe58ec2beaffdbabe4af07/WoWPro_Leveling/Alliance/87_88_Rajitazi_KrasarangWilds.lua 

-- URL: http://wow-pro.com/node/3488/revisions/25062/view
-- Date: 2012-09-02 02:12
-- Who: Laotseu
-- Log: Play tested Alliance's Krasarang Wilds. Many changes mostly to do with stickies, K steps, |NS| and |T| tags.

-- URL: http://wow-pro.com/node/3488/revisions/25054/view
-- Date: 2012-08-28 19:11
-- Who: Ludovicus Maior
-- Log: update urls

-- URL: http://wow-pro.com/node/3488/revisions/25053/view
-- Date: 2012-08-28 19:10
-- Who: Ludovicus Maior
-- Log: Submitted by Emmaleah on Sat, 2012-08-18 15:07. 

WoWPro.Leveling:RegisterGuide('RajKra8788', 'Krasarang Wilds', 'Rajitazi', '87', '88', 'EmmKun8889', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
