
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_swamp_sorrows_alliance
-- Date: 2013-01-13 14:47
-- Who: Ludovicus Maior
-- Log: Added C* tags

-- URL: http://wow-pro.com/node/3249/revisions/25333/view
-- Date: 2013-01-11 19:57
-- Who: Emmaleah
-- Log: fix syntax for multi coordinates

-- URL: http://wow-pro.com/node/3249/revisions/24545/view
-- Date: 2011-06-11 22:13
-- Who: Crackerhead22
-- Log: Removed the "Hero's Call" steps since they are not really needed.

-- URL: http://wow-pro.com/node/3249/revisions/24414/view
-- Date: 2011-05-23 18:15
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3249/revisions/24231/view
-- Date: 2011-04-14 14:41
-- Who: Crackerhead22
-- Log: "C In With a Bang" waypoint set to where "Lil' Crazy Jerry" is for the cannon.

-- URL: http://wow-pro.com/node/3249/revisions/23932/view
-- Date: 2011-01-05 10:59
-- Who: Crackerhead22
-- Log: Added notes, sticky steps. Fixed several waypoint issues, notes and sticky steps.

-- URL: http://wow-pro.com/node/3249/revisions/23924/view
-- Date: 2011-01-04 07:26
-- Who: Crackerhead22
-- Log: Fixed a few errors via gargonfog's suggestions.

-- URL: http://wow-pro.com/node/3249/revisions/23439/view
-- Date: 2010-12-03 21:10
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3249/revisions/23379/view
-- Date: 2010-12-03 11:31
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3249/revisions/23378/view
-- Date: 2010-12-03 11:30
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('CraSwa5254', 'Swamp of Sorrows', 'Crackerhead22', '52', '54', 'CraBla5458', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
