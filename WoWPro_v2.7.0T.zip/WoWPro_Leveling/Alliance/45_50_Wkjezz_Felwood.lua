
-- WoWPro Guides by "The WoW-Pro Community" are licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
-- Based on a work at github.com.
-- Permissions beyond the scope of this license may be available at http://www.wow-pro.com/License.

-- URL: http://wow-pro.com/wiki/source_code_felwood_alliance
-- Date: 2013-03-23 20:00
-- Who: Ludovicus Maior
-- Log: quest name tweak

-- URL: http://wow-pro.com/node/3257/revisions/24460/view
-- Date: 2011-05-30 17:58
-- Who: Ludovicus Maior
-- Log: ! Line 39 for step R has 1 M coords: [R Emerald Sanctuary|QID|28100|M|51.41.79.79|N|Run to Emerald Sanctuary.|]

-- URL: http://wow-pro.com/node/3257/revisions/24432/view
-- Date: 2011-05-28 06:51
-- Who: Crackerhead22
-- Log: Removed static 99999 QIDs, added notes, fixed a couple notes, fixed a couple cords. Added in steps for Deadwood Headdress Feathers (1 step) and Deadwood Ritual Totem (3 steps).

-- URL: http://wow-pro.com/node/3257/revisions/24391/view
-- Date: 2011-05-17 01:02
-- Who: Ludovicus Maior

-- URL: http://wow-pro.com/node/3257/revisions/24186/view
-- Date: 2011-03-20 20:18
-- Who: Ludovicus Maior
-- Log: Corrections around [Crying Violet] and quests shifted to "Andalar Shadevale".  Speling corrections and addition comments.

-- URL: http://wow-pro.com/node/3257/revisions/24082/view
-- Date: 2011-01-30 19:24
-- Who: Ludovicus Maior
-- Log: Corrected Register guide to match GIT.

-- URL: http://wow-pro.com/node/3257/revisions/23618/view
-- Date: 2010-12-06 01:03
-- Who: wkjezz

-- URL: http://wow-pro.com/node/3257/revisions/23396/view
-- Date: 2010-12-03 11:45
-- Who: Jiyambi

-- URL: http://wow-pro.com/node/3257/revisions/23395/view
-- Date: 2010-12-03 11:44
-- Who: Jiyambi

WoWPro.Leveling:RegisterGuide('WkjFel4550', 'Felwood', 'Wkjezz', '45', '50', 'JiyWin5055', 'Alliance', function()
return [[
N Download Full Version for More Guides!|QID|999999|N|Looks like you are using a trial version of WoW-Pro Guides! Our Full Version is still 100% FREE, but you'll need to download it from our website at www.wow-pro.com .|
]]

end)
