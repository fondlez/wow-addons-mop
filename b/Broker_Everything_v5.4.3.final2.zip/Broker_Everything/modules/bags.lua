
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Bags"
local tooltip = nil
local ContainerIDToInventoryID,GetInventoryItemLink = ContainerIDToInventoryID,GetInventoryItemLink
local GetItemInfo,GetContainerNumSlots,GetContainerNumFreeSlots = GetItemInfo,GetContainerNumSlots,GetContainerNumFreeSlots


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show total, free and filled amount of bag space."],
	icon = "Interface\\Addons\\"..addon.."\\media\\INV_Misc_Bag_08",
	events = {
		"PLAYER_LOGIN",
		"BAG_UPDATE",
		"UNIT_INVENTORY_CHANGED"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------

-- Function to determine the total number of bag slots and the number of free bag slots.
local function BagsFreeUsed()
	local t = GetContainerNumSlots(0)
	local f = GetContainerNumFreeSlots(0)

	for i=1,NUM_BAG_SLOTS do
		local idtoinv = ContainerIDToInventoryID(i)
		local il = GetInventoryItemLink("player", idtoinv)
		if il then
			local st = select(7, GetItemInfo(il))
			if st ~= "Soul Bag"
					and st ~= "Ammo Pouch"
					and st ~= "Quiver" then
				t = t + GetContainerNumSlots(i)
				f = f + GetContainerNumFreeSlots(i)
			end
		end
	end
	return f, t
end


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name].freespace == nil then
		Broker_EverythingDB[name].freespace = true
	end
end

ns.modules[name].onevent = function(self,event,msg)
	local f, t = BagsFreeUsed()
	local u = t - f
	local txt = u .. "/" .. t
	local c = "white"

	if Broker_EverythingDB[name].freespace == false then
		txt = u .. "/" .. t
	elseif Broker_EverythingDB[name].freespace == true then
		txt = (t - u) .. " ".. L["free"]
	end

	if (u / t) > 0.9 then
		c = "red"
	elseif (u / t) > 0.7 then
		c = "dkyellow"
	end

	-- self.obj.text = c (txt)
	(self.obj or ns.LDB:GetDataObjectByName(name)).text = C(c,txt)
end

--[[ ns.modules[name].onupdate =  function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local f, total = BagsFreeUsed()
	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")
	tooltip:AddDoubleLine(C("ltyellow",L["Free slots remaining"] .. " :"), C("white",f))
	tooltip:AddDoubleLine(C("ltyellow",L["Total Bag slots"] .. " :"), C("white",total))

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to open bags."]))
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to switch display mode."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	if button == "RightButton" then
		if Broker_EverythingDB[name].freespace == false then
			Broker_EverythingDB[name].freespace  = true
		else
			Broker_EverythingDB[name].freespace = false
		end
		ns.modules[name].onevent(self)
	else
		ToggleBackpack()
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

