
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "FPS"
local tooltip = nil
local GetFramerate = GetFramerate
local _, playerClass = UnitClass("player")
local icon = "Interface\\Addons\\"..addon.."\\media\\fps"

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show your frames per second."],
	icon = icon,
	events = {},
	updateinterval = 2,
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------
--[[ ns.modules[name].init = function(obj) end ]]

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

ns.modules[name].onupdate = function(self)
	local f = floor(GetFramerate())
	local suffix = C("suffix","fps")
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)

	if f < 20 then
		dataobj.icon = icon.."_red"
		dataobj.text = C("brtred",f) .. suffix
	elseif f < 30 then
		dataobj.icon = icon.."_yellow"
		dataobj.text = C("dkyellow",f) .. suffix
	elseif f < 100 then -- 60, 80 or 100 ?
		dataobj.icon = icon.."_green"
		dataobj.text = C("green",f) .. suffix
	else
		dataobj.icon = icon
		dataobj.text = C("ltblue",f) .. suffix
	end
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].ontooltip = function(tooltip) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
end

--[[ ns.modules[name].onleave = function(self) end ]]

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]
