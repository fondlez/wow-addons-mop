
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Speed"
local tooltip = nil
local string,GetUnitSpeed,UnitInVehicle = string,GetUnitSpeed,UnitInVehicle


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["How fast are you swimming, walking, riding or flying."],
	icon = "Interface\\Icons\\Ability_Rogue_Sprint",
	events = {},
	updateinterval = false, -- false or integer
	config = {
		height = 62,
		elements = {
			{
				type = "slider",
				name = "precision",
				label = L["Precision"],
				desc = L["..."],
				minText = "0",
				maxText = "3",
				minValue = 0,
				maxValue = 3,
				default = 0,
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "BOTTOMLEFT",
					x = 0,
					y = -10
				}
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name].precision == nil then
		Broker_EverythingDB[name].precision = 0
	end
end

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

ns.modules[name].onupdate = function(self)
	local obj = self.obj or ns.LDB:GetDataObjectByName(name)

	unit = "player"
	if UnitInVehicle("player") then unit = "vehicle" end

	local speed = ("%."..Broker_EverythingDB[name].precision.."f"):format(GetUnitSpeed(unit) / 7 * 100 ) .. "%"

	obj.text = speed
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].ontooltip = function(tooltip) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
end

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	if not PetJournalParent then PetJournal_LoadUI() end
	ToggleFrame(PetJournalParent)
	--[[
		it is not possible to choose direct the MountJournal.
		I've got on all ways the IsDisabledParentalControls Error i found.
		thanks at blizz dev.
	]]
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

