
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Guild"
local tooltip = nil
local ttColumns = 5
local ttColumns_preInit = ttColumns
local guildUpdateFreq = 300
local displayProfessions = false
local displayOfficerNotes = false
local menu

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show guild information. Guild members currently online, MOTD, guild xp etc."],
	icon = GetItemIcon(5976),
	events = {
		"PLAYER_LOGIN",
		"GUILD_ROSTER_UPDATE",
		"PLAYER_ENTERING_WORLD",
		"GUILD_XP_UPDATE",
		"CHAT_MSG_SYSTEM"
	},
	updateinterval = 5,
	config = 	{
		height = 52,
		elements = {
			{
				type = "check",
				name = "showXP",
				label = L["Show Guild XP"],
				desc = L["Enable/Disable the display of Guild XP in the Guild data broker tooltip."],
			},
			{
				type = "check",
				name = "showMOTD",
				label = L["Show Guild MotD"],
				desc = L["Show Guild Message of the Day in tooltip"],
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 180,
					y = 0
				}
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------
local function makeMenu(parent)
	local menuTable = {
		{text = L["Tooltip display options"], isTitle = true },
		{text = L[ Broker_EverythingDB[name].showMOTD and "Hide motd" or "View motd"], func = function()
			if Broker_EverythingDB[name].showMOTD == true then
				Broker_EverythingDB[name].showMOTD = false
			else
				Broker_EverythingDB[name].showMOTD = true
			end
		end },
		{text = L[ Broker_EverythingDB[name].showXP and "Hide xp/rep" or "View xp/rep" ], func = function()
			if Broker_EverythingDB[name].showXP == true then 
				Broker_EverythingDB[name].showXP = false
			else
				Broker_EverythingDB[name].showXP = true
			end
		end },
		{text = L[ Broker_EverythingDB[name].showMobileChatter and "Hide mobile chatter in tooltip" or "View mobile chatter in tooltip"], func = function()
			if Broker_EverythingDB[name].showMobileChatter == true then 
				Broker_EverythingDB[name].showMobileChatter = false
			else
				Broker_EverythingDB[name].showMobileChatter = true
			end
		end },
--		{text = L["View/Hide offliner in tooltip"], func = function()
--			if Broker_EverythingDB[name].showOffliner == true then 
--				Broker_EverythingDB[name].showOffliner = false
--			else
--				Broker_EverythingDB[name].showOffliner = true
--			end
--		end }
	}
	menu = CreateFrame("Frame",name.."_Dropdown", parent or UIParent, "UIDropDownMenuTemplate")
	EasyMenu(menuTable,menu,parent or "cursor",0,0)
end


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name].showXP == nil then
		Broker_EverythingDB[name].showXP = true
	end
	if Broker_EverythingDB[name].showMOTD == nil then
		Broker_EverythingDB[name].showMOTD = true
	end
	if Broker_EverythingDB[name].showMobileChatter == nil then
		Broker_EverythingDB[name].showMobileChatter = true
	end
	if Broker_EverythingDB[name].splitTables == nil then
		Broker_EverythingDB[name].splitTables = false
	end
	if Broker_EverythingDB[name].showOffliner == nil then
		Broker_EverythingDB[name].showOffliner = false
	end
end

ns.modules[name].onevent = function(self,event,msg)
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)
	if not IsInGuild() then
		dataobj.text = L["No Guild"]
		return
	end

	if CanViewOfficerNote() then displayOfficerNotes = true end

	if displayOfficerNotes then ttColumns = ttColumns_preInit + 1 end
	if displayProfessions then ttColumns = ttColumns + 1 end

	if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
		ns.modules[name].onupdate()
	end

	if event == "CHAT_MSG_SYSTEM" then
		if string.find(msg, L["has come online"]) or string.find(msg, L["has gone offline"]) then
			local totalGuildMembers, membersOnline = GetNumGuildMembers()
			dataobj.text = membersOnline .. "/" .. totalGuildMembers
		end
	end

	if event == "GUILD_ROSTER_UPDATE" or event == "GUILD_XP_UPDATE" then
		local totalGuildMembers, membersOnline = GetNumGuildMembers()
		dataobj.text = membersOnline .. "/" .. totalGuildMembers
	end
end

ns.modules[name].onupdate = function(self)
	if IsInGuild() then 
		GuildRoster()
		QueryGuildXP()
	end
end

ns.modules[name].ontooltip = function(tooltip)

	tooltip:Clear()

	if not IsInGuild() then
		tooltip:AddHeader(L[name])
		tooltip:AddSeparator()
		tooltip:AddLine(L["No Guild"])
		return
	end
	-- XP & Reputation

	local currentXP, nextLevelXP, dailyXP, maxDailyXP, unitWeeklyXP, unitTotalXP = UnitGetGuildXP("player");

	local guildName, description, standingID, barMin, barMax, barValue = GetGuildFactionInfo()
	local factionStandingtext = GetText("FACTION_STANDING_LABEL"..standingID)

	local guildName = GetGuildInfo("player")
	local guildLevel = GetGuildLevel()
	local gMOTD = GetGuildRosterMOTD()

	local line, column = tooltip:AddHeader()
	tooltip:SetCell(line, 1, C("dkyellow",L[name]) .. "  " .. C("green",string.format("%s / Lvl: %d / XP: %.2f%%",guildName,guildLevel, (currentXP / ((currentXP + nextLevelXP) / 100) ) )), nil, nil, ttColumns)

	tooltip:AddSeparator(1,0,0,0,0)

	if Broker_EverythingDB[name].showMOTD then
		if gMOTD:len() > 100 then
			gMOTD = ns.splitTextToHalf(gMOTD," ")
		end

		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("ltblue",L["MotD"])..":", nil, nil, 1)
		tooltip:SetCell(line, 2, C("ltgreen",gMOTD), nil, nil, ttColumns-1)
	end

	if Broker_EverythingDB[name].showXP then
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, string.format("%s:", C("ltblue",L["XP"])))
		tooltip:SetCell(line, 2, string.format("%s/%s", currentXP, currentXP + nextLevelXP),nil, nil, ttColumns - 1)
		
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, string.format("%s:", C("ltblue",L["Rep"])))
		tooltip:SetCell(line, 2, string.format("%s: (%d/%d)", factionStandingtext, barValue, barMax), nil, nil, ttColumns - 1)
	end


	if Broker_EverythingDB[name].showMOTD or Broker_EverythingDB[name].showXP then
		tooltip:AddSeparator(1,0,0,0,0)
	end

	line, column = tooltip:AddLine()
	local cell = 1
	tooltip:SetCell(line, cell, C("ltyellow",L["Level"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
	tooltip:SetCell(line, cell, C("ltyellow",L["Online"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
	tooltip:SetCell(line, cell, C("ltyellow",L["Zone"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
	tooltip:SetCell(line, cell, C("ltyellow",L["Notes"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1

	if displayOfficerNotes then 
		tooltip:SetCell(line, cell, C("ltyellow",L["Officer's Notes"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
	end

	tooltip:SetCell(line, cell, C("ltyellow",L["Rank"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1

	if displayProfessions then
		tooltip:SetCell(line, cell, C("ltyellow",L["Professions"]), nil, nil, 1, ns.LQT.LabelProvider, 0, 10) cell = cell + 1
	end

	tooltip:AddSeparator()
	local y = GetNumGuildMembers(true)  -- GetNumGuildMembers(true)
	local iArmory,Armory = 0,{}
	for i = 1, y do
		local rc = "white"
		local n, r, ri, l, c, z, no, ono, o, s, ec, a, ar, im = GetGuildRosterInfo(i)
		if o then
			local n2 = n
			if ns.player.name == n then rc = "gray"end
			if s==1 then s = C("gold","[AFK] ") elseif s==2 then s = C("ltred","[DND] ") else s = "" end

			local cell = 1
			line, column = tooltip:AddLine()
			tooltip:SetCell(line, cell, l, nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
			tooltip:SetCell(line, cell, s .. C(ec,n), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
			tooltip:SetCell(line, cell,  z or "", nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
			tooltip:SetCell(line, cell, no or "", nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1

			if displayOfficerNotes then
				tooltip:SetCell(line, cell, ono or "" , nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
			end

			tooltip:SetCell(line, cell, C(rc,r), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1

			if displayProfessions then
				tooltip:SetCell(line, cell, "?", nil, nil, 1, ns.LQT.LabelProvider, 0, 10) cell = cell + 1
			end

			tooltip:SetLineScript(line, "OnMouseUp", function(self) if IsAltKeyDown() then InviteUnit(n) else SetItemRef("player:"..n, "|Hplayer:"..n.."|h["..n.."|h", "LeftButton") end end, n)
			tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
			tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
		elseif im then
			iArmory = iArmory + 1
			Armory[iArmory] = {GetGuildRosterInfo(i)}
		end
	end

	if Broker_EverythingDB[name].showMobileChatter == true and iArmory > 0 then
		if Broker_EverythingDB[name].splitTables == true then
			tooltip:AddLine(" ")
			line,column = tooltip:AddLine()
			tooltip:SetCell(line, 1, C("ltyellow",L["MobileChat:"]), nil, nil, ttColumns)
			tooltip:AddSeparator()
		end

		for i,v in pairs(Armory) do
			local rc = "white"
			local n, r, ri, l, c, z, no, ono, o, s, ec, a, ar, im = unpack(v)
			if im then
				if ns.player.name == n then rc = "gray" end
				if s==1 then s = C("gold","[AFK] ") elseif s==2 then s = C("ltred","[DND] ") else s = "" end

				local cell = 1
				line, column = tooltip:AddLine()
				tooltip:SetCell(line, cell, l, nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
				tooltip:SetCell(line, cell, s .. C(ec,n), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
				tooltip:SetCell(line, cell, C("ltblue",L["MobileChat"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
				tooltip:SetCell(line, cell, no or "", nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1

				if displayOfficerNotes then
					tooltip:SetCell(line, cell, ono or "" , nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1
				end

				tooltip:SetCell(line, cell, C(rc,r), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10) cell = cell + 1

				if displayProfessions then
					tooltip:SetCell(line, cell, "?", nil, nil, 1, ns.LQT.LabelProvider, 0, 10) cell = cell + 1
				end

				tooltip:SetLineScript(line, "OnMouseUp", function(self) if IsAltKeyDown() then InviteUnit(n) else SetItemRef("player:"..n, "|Hplayer:"..n.."|h["..n.."|h", "LeftButton") end end, n)
				tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
				tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
			end
		end
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")

		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1,
			C("copper",L["Left-click"]).." "..C("green",L["to open the guild roster."])
			.." "..
			C("copper",L["Click"]).." "..C("green",L["on a guild member to whisper."])
			.."|n"..
			C("copper",L["Alt + Click"]).." "..C("green",L["on a guild member to invite."])
			.." "..
			C("copper",L["Right-click"]).." "..C("green",L["to open menu."])
			, nil, nil, ttColumns)
	end

	line, column = nil, nil
end

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", ttColumns,"LEFT", "LEFT", "CENTER", "LEFT", "LEFT", "LEFT", "LEFT")
	tooltip:Clear()
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
	if button == "RightButton" then 
		if menu==nil then
			makeMenu(self)
		else
			menu:Hide()
			menu = nil
		end
	elseif GUILockDown == nil then 
		ToggleGuildFrame()
	elseif GUILockDown == 1 then 
		return 
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

