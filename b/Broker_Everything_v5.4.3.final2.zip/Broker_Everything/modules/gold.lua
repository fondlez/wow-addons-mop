
-- saved variables
goldDB = {}

----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Gold"
local tooltip = nil
local login_money = nil
local current_money = 0
local goldInit = false
local goldLoaded = false
local faction = UnitFactionGroup("Player")
local _GetCoinTextureString = GetCoinTextureString


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show gold information. Shows gold amounts for characters on the same ns.realm and faction and the amount made or lost for the session."],
	icon = "Interface\\Minimap\\TRACKING\\Auctioneer",
	events = {
		"PLAYER_LOGIN",
		"PLAYER_MONEY",
		"PLAYER_TRADE_MONEY",
		"TRADE_MONEY_CHANGED",
		"PLAYER_ENTERING_WORLD",
--		"ADDON_LOADED",
		"NEUTRAL_FACTION_SELECT_RESULT"
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "goldColor",
				label = L["Gold coloring"],
				desc = L["Use colors instead of icons for gold, silver and copper"],
				event = true
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------
local function GetCoinTextureString(amount,sep)
	if Broker_EverythingDB[name].goldColor then
		if (not sep) then sep = "." end
		local gold, silver, copper = tostring(math.floor(amount / 10000)), tostring(mod(math.floor(amount / 100), 100)), tostring(mod(amount, 100))
		local t, i = {}, 1
		if gold~="0" then
			t[i], silver, i = C("gold",gold), string.format("%02d",silver), i + 1
		end
		if silver~="0" then
			t[i], copper, i = C("silver",silver), string.format("%02d",copper), i + 1
		end
		t[i] = C("copper",copper)
		return table.concat(t,sep)
	else
		return _GetCoinTextureString(amount)
	end
end

------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)

	if Broker_EverythingDB[name].goldColor == nil then
		Broker_EverythingDB[name].goldColor = false
	end

	if not goldDB[faction] then
		goldDB[faction] = {
			[ns.realm]={
				[ns.player.name] = 0
			}
		}
	elseif not goldDB[faction][ns.realm] then
		goldDB[faction][ns.realm] = {
			[ns.player.name] = 0
		}
	end
	
end

ns.modules[name].onevent = function(self,event,msg)
	current_money = GetMoney()
	goldDB[faction][ns.realm][ns.player.name] = current_money

	if event == "PLAYER_LOGIN" then
		login_money = current_money
	end

	if event == "NEUTRAL_FACTION_SELECT_RESULT" then
		faction = UnitFactionGroup("Player")
		ns.modules[name].init(self)
		goldDB[faction][ns.realm][ns.player.name] = current_money
		goldDB["Neutral"][ns.realm][ns.player.name] = nil
	end

	(self.obj or ns.LDB:GetDataObjectByName(name)).text = GetCoinTextureString(current_money)
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local totalGold = 0
	local diff_money

	tooltip:Clear()

	tooltip:AddHeader(C("dkyellow",L["Gold Information"]))
	tooltip:AddSeparator()

	for k,v in ns.pairsByKeys(goldDB[faction][ns.realm]) do
		--local line, column = tooltip:AddLine(k, GetCoinTextureString(v)) 
		local line, column = tooltip:AddLine(k, GetCoinTextureString(v))
		tooltip:SetLineScript(line, "OnMouseUp", function(self) 
			if IsShiftKeyDown() then 
				goldDB[faction][ns.realm][k] = nil 
				tooltip:Clear()
				drawGoldTip()
			end 
		end)			
		tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
		tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
		totalGold = totalGold + v
		line, column = nil, nil
	end

	tooltip:AddSeparator()
	tooltip:AddLine(L["Total Gold"], GetCoinTextureString(totalGold))
	tooltip:AddSeparator(3,0,0,0,0)

	if current_money == login_money then
		tooltip:AddLine(L["Session profit"], GetCoinTextureString(0))
	elseif current_money > login_money then
		tooltip:AddLine(C("ltgreen",L["Session profit"]), "+ " .. GetCoinTextureString(current_money - login_money))
	else
		tooltip:AddLine(C("ltred",L["Session profit"]), "- " .. GetCoinTextureString(login_money - current_money))
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddSeparator(3,0,0,0,0)
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Left-click"]).." "..C("green",L["to show the currency tab."]), nil, nil, 2)
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Shift + Left-click"]).." "..C("green",L[" to remove entry."]), nil, nil, 2)
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 2, "LEFT", "RIGHT")
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then 
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
	ToggleCharacter("TokenFrame")
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]
