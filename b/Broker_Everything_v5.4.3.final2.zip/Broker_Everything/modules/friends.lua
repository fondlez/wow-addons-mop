
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Friends"
local tooltip = nil
local totalOnline = 0
local totalFriends = 0
local friends = {}
local unknownGameError = false
local DSw, DSh =  0,  0
local ULx, ULy =  0,  0
local LLx, LLy = 32, 32
local URx, URy =  9, 23
local LRx, LRy =  9, 23
local gameIconPos = setmetatable({},{ __index = function(t,k) return format("%s:%s:%s:%s:%s:%s:%s:%s:%s:%s",DSw,DSh,ULx,ULy,LLx,LLy,URx,URy,LRx,LRy) end})
local gameShortcut = setmetatable({ [BNET_CLIENT_WTCG] = "HS", [BNET_CLIENT_SC2] = "Sc2"},{ __index = function(t, k) return k end })
local _BNet_GetClientTexture = BNet_GetClientTexture
friendsDB = {}

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show you which friends are online."],
	icon = "Interface\\Addons\\"..addon.."\\media\\friends",
	events = {
		"PLAYER_LOGIN",
		"FRIENDLIST_UPDATE",
		"PLAYER_ENTERING_WORLD",
		"BN_FRIEND_ACCOUNT_ONLINE",
		"BN_FRIEND_ACCOUNT_OFFLINE",
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "disableGameIcons",
				label = L["Disable game icons"],
				desc = L["Disable displaying game icons and use game shortcut instead of"]
			},
			{
				type = "check",
				name = "splitFriends",
				label = L["Split Chars and bnetFriends"],
				desc = L["Split displaying Characters and BattleNet-Friends on Broker Button"],
				event = true,
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 150,
					y = 0
				}
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------
local function BNet_GetClientTexture(game)
	if Broker_EverythingDB[name].disableGameIcons then
		return gameShortcut[game]
	else
		local icon = _BNet_GetClientTexture(game)
		return format("|T%s:%s|t",icon,gameIconPos[game])
	end
end

local function grabFriends(self)
	local numBNFriends, numOnlineBNFriends = BNGetNumFriends()
	local numFriends, friendsOnline = GetNumFriends()
--	local server = GetCVar("realmName")
	local server = GetRealmName()
	local englishFaction, localizedFaction = UnitFactionGroup("player")
	friends = wipe(friends)

	-- all friends from battlenet
	if numOnlineBNFriends >0 then
		for i = 1, numBNFriends, 1 do
			local presenceID, presenceName, battleTag, isBattleTagPresence, toonName, toonID, game, isOnline, lastOnline, isAFK, isDND, broadcastText, noteText, isFriend, broadcastTime, canSoR = BNGetFriendInfo(i)

			if isOnline == true then
				local _, _, _, realmName, realmID, faction, race, class, guild, area, level, gameText = BNGetToonInfo(presenceID)
				local status_text, status_color = "",""
				if isAFK == true then
					status_text = "[AFK]"
					status_color = "gold"
				elseif isDND == true then 
					status_text = "[DND]"
					status_color = "ltred"
				end
				
				if toonName == nil or (not toonName) then
					toonName = presenceName
				end 

				friends[toonName] = {
					["battleNet"] = true,
					["presenceName"] = presenceName,
					["presenceID"] = presenceID,
					["battleTag"] = battleTag,
					["toonID"] = toonID,
					["client"] = client,
					["status_text"] = status_text,
					["status_color"] = status_color,
					["game"] = BNet_GetClientTexture(game),
					["realm"] = realmName,
					["faction"] = L[faction],
					["class"] = strupper(class),
					["zone"] = area,
					["level"] = level,
					["notes"] = noteText or "",
					["online"] = isOnline,
				}
			end
		end
	end
	
	-- all chars on your realm that you have added to friendlist
	if numFriends > 0 then
		for i = 1, numFriends, 1 do
			local name, level, class, area, connected, status, note = GetFriendInfo(i)
			local status_text, status_color = "",""
			if isAFK == true then
				status_text = "[AFK]"
				status_color = "gold"
			elseif isDND == true then 
				status_text = "[DND]"
				status_color = "ltred"
			end
			
			if ((friends[name] == nil) or (not friends[name])) and name ~= nil then
				if connected == 1 then
					connected = true
				else
					connected = false
				end
				
				friends[name] = {
					["battleNet"] = false,
					["status_text"] = status_text,
					["status_color"] = status_color,
					["game"] = BNet_GetClientTexture(BNET_CLIENT_WOW),
					["faction"] = localizedFaction or englishFaction,
					["realm"] = server,
					["class"] = strupper(class),
					["zone"]  = area,
					["level"] = level,
					["notes"] = note or " ",
					["online"] = connected,
				}
			end
		end
	end
end


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(self)
	if Broker_EverythingDB[name].splitFriends == nil then
		Broker_EverythingDB[name].splitFriends = true
	end
	if Broker_EverythingDB[name].disableGameIcons == nil then
		Broker_EverythingDB[name].disableGameIcons = false
	end
end

ns.modules[name].onevent = function(self,event,msg)
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name) 
	local numBNFriends, numOnlineBNFriends = BNGetNumFriends()
	local numFriends, friendsOnline = GetNumFriends()
	grabFriends()

	totalOnline = numOnlineBNFriends + friendsOnline
	totalFriends = numBNFriends + numFriends

	if Broker_EverythingDB[name].splitFriends then
--		dataobj.text = format("%s %s [%s %s]",friendsOnline, C("ltblue",numOnlineBNFriends), numFriends, C("ltblue",numBNFriends))
		dataobj.text = format("%s/%s "..C("ltblue","%s/%s"),friendsOnline, numFriends, numOnlineBNFriends, numBNFriends)
	else
		dataobj.text = totalOnline .. "/" .. totalFriends
	end

end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	grabFriends()
	local line, column
	tooltip:Clear()
	tooltip:AddHeader(C("dkyellow",L[name]))

	if totalOnline == 0 then
		tooltip:AddLine(L["No Friends Online."])
		if Broker_EverythingDB.showHints then
			line, column = tooltip:AddLine()
			tooltip:SetCell(line, 1, C("copper",L["Left-click"]).." "..C("green",L["to open the friends roster."]), nil, nil, 6)
		end
		return
	end
	-- RealId	Status Character	Level	Zone	Game	Realm	Notes

	tooltip:AddLine(
		C("ltyellow",L["Real ID"]),
		C("ltyellow",L["BattleTag"]),
		C("ltyellow",L["Character"]),
		C("ltyellow",L["Level"]),
		C("ltyellow",L["Zone"]),
		C("ltyellow",L["Game"]),
		C("ltyellow",L["Realm"]),
		C("ltyellow",L["Faction"]),
		C("ltyellow",L["Notes"])
	)
	tooltip:AddSeparator()
	
	for k,v in ns.pairsByKeys(friends) do
		if v.online == true  then
			local name 
			if v.battleNet then 
				line, column = tooltip:AddLine(
					C("ltblue",v.presenceName),
					C("ltblue",v.battleTag or " "),
					C(v.status_color,v.status_text)..C(v.class,k),
					C("white",v.level),
					C("white",v.zone),
					v.game,
					C("white",v.realm),
					C("white",v.faction),
					C("white",v.notes or " ")
				)
				tooltip:SetLineScript(line, "OnMouseUp", function(self) if IsAltKeyDown() then BNInviteFriend(v.toonID) else ChatFrame_SendSmartTell(v.presenceName) end end, n)
			else
				line, column = tooltip:AddLine(
					" ",
					" ",
					C(v.status_color,v.status_text)..C(v.class,k),
					C("white",v.level),
					C("white",v.zone),
					C("white",v.game),
					C("white",v.realm),
					C("white",v.faction),
					C("white",v.notes or " ")
				)
				tooltip:SetLineScript(line, "OnMouseUp", function(self) if IsAltKeyDown() then InviteUnit(k) else ChatFrame_SendTell(k) end end, n)
			end
			tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
			tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
		end
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, 
			C("copper",L["Left-click"]).." "..C("green",L["to open the friends roster."])
			.." "..
			C("copper",L["Click"]).." "..C("green",L["on a friend to whisper."])
			.." "..
			C("copper",L["Alt + Click"]).." "..C("green",L["on a friend to invite."]),
			nil, nil, 9)
	end

	line, column = nil, nil
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 9 , "LEFT", "LEFT", "LEFT", "CENTER", "CENTER", "CENTER", "CENTER", "LEFT", "LEFT" ) 
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
-- Disabled argument usage because addon block messages from blizz.
--	ToggleFriendsFrame(1)
	ToggleFriendsFrame()
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]
