
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Mail"
local tooltip = nil


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to alert you if you have mail."],
	icon = "Interface\\Addons\\"..addon.."\\media\\mail_none",
	events = {
		"UPDATE_PENDING_MAIL",
		"MAIL_INBOX_UPDATE",
		"MAIL_CLOSED",
		"PLAYER_LOGIN",
		"PLAYER_ENTERING_WORLD",
		"MAIL_SHOW"
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "playsound",
				label = L["Play sound on new mail"],
				desc = L["Enable to play a sound on receiving a new mail message. Default is off"],
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------



------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	MiniMapMailFrame:Hide()
	MiniMapMailFrame.Show = dummyFunc

	if Broker_EverythingDB[name].playsound == nil then
		Broker_EverythingDB[name].playsound = false
	end
end

ns.modules[name].onevent = function(self,event,msg)
	local dataobj = self.obj  or ns.LDB:GetDataObjectByName(name)
	local newMail = false
	
	if event == "UPDATE_PENDING_MAIL" or event == "PLAYER_ENTERING_WORLD" or event =="PLAYER_LOGIN" then
--		local sender1, sender2, sender3 = GetLatestThreeSenders()
		newMail = HasNewMail() 
		
		if unreadMail ~= newMail then
			if newMail and Broker_EverythingDB[name].playsound == true then
				PlaySoundFile("Interface\\Addons\\"..addon.."\\media\\mailalert.mp3", "Master")
			end
			unreadMail = newMail
		end
	
		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
		self:UnregisterEvent("PLAYER_LOGIN")
	end
	
	if event == "MAIL_INBOX_UPDATE" or event == "MAIL_SHOW" or event == "MAIL_CLOSED" then
		for i = 1, GetInboxNumItems() do
			local _, _, _, _, _, _, _, _, wasRead = GetInboxHeaderInfo(i);
			if( not wasRead ) then
				newMail = true;
				break;
			end
		end
	end
	
	if newMail then
		dataobj.text = C("green",L["New Mail"])
		dataobj.icon = "Interface\\Addons\\"..addon.."\\media\\mail_new"
	else
		dataobj.text = L["No Mail"]
		dataobj.icon = "Interface\\Addons\\"..addon.."\\media\\mail_none"
	end
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local sender1, sender2, sender3 = GetLatestThreeSenders()
	tooltip:AddLine(L[name])

	tooltip:AddLine(" ")
	if not sender1 then
		tooltip:AddLine(L["No Mail"])
		return
	end

	tooltip:AddLine(L["Mail From"])
	tooltip:AddLine(sender1)

	if sender2 then tooltip:AddLine(sender2) end
	if sender3 then tooltip:AddLine(sender3) end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]


