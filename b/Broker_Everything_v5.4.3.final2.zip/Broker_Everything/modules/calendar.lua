
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Calendar"
local tooltip = nil


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show if you have any current invitations."],
	icon = "Interface\\Addons\\"..addon.."\\media\\calendar",
	events = {
		"CALENDAR_UPDATE_PENDING_INVITES",
		"PLAYER_LOGIN",
		"PLAYER_ENTERING_WORLD"
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "hideMinimapCalendar",
				label = L["hide calendar button"],
				desc = L["hide the calendar button on the minimap"]
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------



------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name].hideMinimapCalendar == nil then
		Broker_EverythingDB[name].hideMinimapCalendar = false
	end
	if Broker_EverythingDB[name].hideMinimapCalendar == true then
		GameTimeFrame:Hide()
		GameTimeFrame.Show = dummyFunc
	end
end

ns.modules[name].onevent = function(self,event,msg)
	self.obj = self.obj or ns.LDB:GetDataObjectByName(name)
	if CalendarGetNumPendingInvites() > 0 then
		self.obj.text = C("green",L["Pending Invites"])
	else
		self.obj.text = L["No Invites"]
	end
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local x = CalendarGetNumPendingInvites()
	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")
	if x == 0 then
		tooltip:AddLine(C("white",L["There are no pending Invitations."]))
	else
		tooltip:AddLine(C("white",string.format("%d %s.", x, L["invitations"])))
	end
	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to open the calendar."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = ToggleCalendar -- function(self,button) end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

