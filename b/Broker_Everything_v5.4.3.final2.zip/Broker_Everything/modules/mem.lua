
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Memory"
local tooltip = nil
local GetNumAddOns,GetAddOnMemoryUsage,GetAddOnInfo = GetNumAddOns,GetAddOnMemoryUsage,GetAddOnInfo


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show you your addon memory usage."],
	icon = "Interface\\Addons\\"..addon.."\\media\\memory",
	events = {
		"PLAYER_ENTERING_WORLD"
	},
	updateinterval = 10,
	config = {
		height = 62,
		elements = {
			{
				type = "slider",
				name = "mem_max_addons",
				label = "",
				desc = L["Select the maximum number of addons to display, otherwise drag to 'All'."],
				minText = L["All"],
				maxText = '100',
				minValue = -1,
				maxValue = 100,
				default = -1,
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "BOTTOMLEFT",
					x = 0,
					y = -10
				}
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------
local function updateMemoryData(sumOnly)
	local total, all = 0, {}
	UpdateAddOnMemoryUsage()
	for i = 1, GetNumAddOns() do
		local u = GetAddOnMemoryUsage(i)
		total = total + u
		if not sumOnly then
			local n = select (1, GetAddOnInfo(i))
			all[i] = {name = n, mem = floor(u * 100) / 100}
		end
	end
	return total, all
end


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(self)
	if not self then
		if not Broker_EverythingDB[name].mem_max_addons then 
			Broker_EverythingDB[name].mem_max_addons = -1
		end
	end
end

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

ns.modules[name].onupdate = function(self)
	local obj = self.obj or ns.LDB:GetDataObjectByName(name)
	local total, all = updateMemoryData(true)

	local unit = "kb"
	if total > 1000 then
		total = total / 1000
		unit = "mb"
	end

	obj.text = string.format ("%.2f", total) .. C("suffix",unit)
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local unit
	local total, all = updateMemoryData(false)
	local cnt = tonumber(Broker_EverythingDB[name].mem_max_addons)

	tooltip:Clear()

	if cnt > 0 then
		tooltip:AddHeader(string.format("%s ( %s %d )", C("dkyellow",L[name]), L["Top"], Broker_EverythingDB[name].mem_max_addons))
	else
		tooltip:AddHeader(L[name])
		cnt = 1000
	end

	table.sort(all, function (x, y) return x.mem > y.mem end)

	tooltip:AddLine(C("ltgreen",string.format("%s:", L["Addon"])), C("ltgreen",string.format("%s:", L["Memory Usage"])))
	tooltip:AddSeparator()
	for _, v in pairs (all) do
		if v.mem > 0 then
			unit = "kb"
			if v.mem > 1000 then
				v.mem = v.mem / 1000
				unit = "mb"
			end

			tooltip:AddLine(v.name, string.format("%.2f %s", v.mem, C("suffix",unit)))
			cnt = cnt - 1

			if cnt == 0 then
				break
			end
		end
	end
	tooltip:AddSeparator()

	unit = "kb"
	if total > 1000 then
		total = total / 1000
		unit = "mb"
	end
	unit = C("suffix",unit)

	tooltip:AddLine(string.format("%s:",L["Total Memory usage"]), string.format ("%.2f %s", total, unit))

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")

		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Left-click"]).." "..C("green",L["to open interface options."]),nil, nil, 2)

		if IsAddOnLoaded("OptionHouse") then
			line, column = tooltip:AddLine()
			tooltip:SetCell(line, 1, C("copper",L["Right-click"]).." "..C("green",L["to open OptionHouse"]), nil, nil, 2)
		elseif IsAddOnLoaded("ACP") then
			line, column = tooltip:AddLine()
			tooltip:SetCell(line, 1, C("copper",L["Right-click"]).." "..C("green",L["to open Addon Control Panel"]), nil, nil, 2)
		elseif IsAddOnLoaded("stAddonManager") then
			line, column = tooltip:AddLine()
			tooltip:SetCell(line, 1, C("copper",L["Right-click"]).." "..C("green",L["to open stAddonManager"]), nil, nil, 2)
		end

		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Shift + Right-click"]).." "..C("green",L["to collect garbage."]), nil, nil, 2)
	end	
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 2, "LEFT", "RIGHT")
	tooltip:Clear()
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
	local shift = IsShiftKeyDown()
	
	if button == "RightButton" and shift then
		print(L["Collecting Garbage..."])
		collectgarbage("collect")
	elseif button == "LeftButton" and not shift then
		InterfaceOptionsFrame_OpenToCategory(ns.OP.brokerPanel)
		InterfaceOptionsFrame_OpenToCategory(ns.OP.brokerPanel);
	elseif button == "RightButton" and not shift then
		if IsAddOnLoaded("OptionHouse") then
			OptionHouse:Open(1)
		elseif IsAddOnLoaded("ACP") then
			ACP:ToggleUI()
		elseif IsAddOnLoaded("Ampere") then
			InterfaceOptionsFrame_OpenToCategory("Ampere")
		elseif IsAddOnLoaded("stAddonManager") then
			stAddonManager:LoadWindow()
		else
			print(L["No addon manager found. Tried OptionHouse, ACP, stAddonManager and Ampere."])
		end
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

