
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Nameplates"
local tooltip = nil
local GetCVar,RegisterCVar = GetCVar,RegisterCVar
local nameplateStatus = {
		[L["Friendly Players"]] = "UnitNameFriendlyPlayerName", 
		[L["Friendly Pets"]] = "UnitNameFriendlyPetName",
		[L["Friendly Creations"]] = "UnitNameFriendlyCreationName",
		[L["Friendly Everyone"]] = "nameplateShowFriends",
		[L["Hostile Players"]] = "UnitNameEnemyPlayerName",
		[L["Hostile Pets"]] = "UnitNameEnemyPetName",
		[L["Hostile Creations"]] = "UnitNameEnemyCreationName",
		[L["Hostile Everyone"]] = "nameplateShowEnemies",
		[L["Companion Names"]] = "UnitNameCompanionName",
		[L["Your Own Name"]] = "UnitNameOwn",
		[L["Player Titles"]] = "UnitNamePlayerPVPTitle",
		[L["Guild Names"]]	 = 	"UnitNamePlayerGuild",
		[L["NPC Names"]]	=	"UnitNameNPC"
}


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to allow you to toggle the various nameplates. Eg, friendly or hostile."],
	icon = "Interface\\Addons\\"..addon.."\\media\\nameplates",
	events = {
		"VARIABLES_LOADED"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------


-- Function to get the Nameplate CVar status
local function getCVarSettings(cVarName)
		local shown
		local toggle
		if GetCVar(cVarName) == "1" then
			shown = C("white",L["Shown"])
			toggle = 0
		elseif GetCVar(cVarName) == nil then
			RegisterCVar(cVarName, 0)
			shown = C("grey",L["Hidden"])
		else
			shown = C("grey",L["Hidden"])
			toggle = 1
		end
		return shown, toggle
end



------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if not obj then return end

	obj = obj.obj or ns.LDB:GetDataObjectByName(name) 
	

	
end

ns.modules[name].onevent = function(self,event,msg)
	local dataobj = ns.LDB:GetDataObjectByName(name) 
	local allFriends, friends = GetCVar("nameplateShowFriends"), GetCVar("UnitNameFriendlyPlayerName")
	local allEnemies, enemy = GetCVar("nameplateShowEnemies"), GetCVar("UnitNameEnemyPlayerName")

	if (friends == "1" or allFriends == "1") and (enemy == "1" or allEnemies == "1") then
		dataobj.text = L["Friend"] .. " & " .. L["Enemy"]
	elseif (friends == "1" or allFriends == "1") then
		dataobj.text = L["Friend"]
	elseif (enemy == "1" or allEnemies == "1") then
		dataobj.text = L["Enemy"]
	else
		dataobj.text = L["None"]
	end
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	tooltip:Clear()
	local line, column = tooltip:AddHeader(C("dkyellow",L[name]))
	
	line, column = tooltip:AddLine(" ")
		
	line, column = tooltip:AddLine(C("ltyellow",L[name]), C("ltyellow",L["Current Status"]))
	tooltip:AddSeparator()

	for key, value in ns.pairsByKeys(nameplateStatus) do
		local shown, toggle = getCVarSettings(value)
		line, column = tooltip:AddLine(L[key] .. ":", shown)
		tooltip:SetLineScript(line, "OnMouseUp", function(self) 
			SetCVar(value, toggle, true) 
			tooltip:Clear()
			ns.modules[name].ontooltip(tooltip)
		end)			
		tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
		tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")

		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Click"]).." "..C("green",L["on an option to toggle the Nameplates on or off."]), nil, nil, 2)
	end
	line, column = nil, nil
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 2, "LEFT", "RIGHT") 
	ns.createTooltip(self,tooltip)
	ns.modules[name].ontooltip(tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

