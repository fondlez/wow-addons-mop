
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Dualspec"
local tooltip = nil
local unspent = 0
local specs = {}

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show your currently selected spec. If you have a second spec, it is shown in the tool tip, and can be swapped to using this broker."],
	icon = GetItemIcon(7516),
	events = {
		"PLAYER_LOGIN",
		"ACTIVE_TALENT_GROUP_CHANGED",
		"PLAYER_ENTERING_WORLD",
		"SKILL_LINES_CHANGED",
		"CHARACTER_POINTS_CHANGED",
		"PLAYER_TALENT_UPDATE",
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------



------------------------------------
-- module (BE internal) functions --
------------------------------------
--[[ ns.modules[name].init = function(obj) end ]]

ns.modules[name].onevent = function(self,event,msg)
	local specName = L["No Spec!"]
	local icon = GetItemIcon(7516)
	local spec = GetSpecialization()
	local _ = nil
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)
	unspent = GetNumUnspentTalents()

	if spec ~= nil then
		 _, specName, _, icon, _, _ = GetSpecializationInfo(spec)
	end

	dataobj.icon = icon

	if unspent~=0 then
		dataobj.text = C("ltred",string.format(L["Unspent talents: %d"],unspent))
	else
		dataobj.text = specName
	end

end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

ns.modules[name].ontooltip = function(tooltip)
	tooltip:AddLine(L["Talents"])

	local activeSpec = GetSpecialization()
	local numberSpecs = GetNumSpecGroups()
	local specs = { }
		
	for i=1, numberSpecs do
		specs["spec" .. i] = GetSpecialization(false,false,i)
	end

	if specs.spec1 == nil and specs.spec2 == nil then
		tooltip:AddLine(L["You have not trained a specialisation."])
	else
		for k, v in pairs(specs) do
			local _, specName, _, icon, _, _ = GetSpecializationInfo(v)
			if v == activeSpec then
				tooltip:AddDoubleLine(specName, L["Active"])
			else
				tooltip:AddDoubleLine(specName, "")
			end

			tooltip:AddTexture(icon)
		end
	end

	if unspent ~= 0 then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("ltred",string.format(unspent==1 and L["You have %d unspent talent."] or L["You have %d unspent talents."],unspent)))
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to show the talents pane."]))
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to switch talents."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	if button == "RightButton" then
		SetActiveSpecGroup(abs(GetActiveSpecGroup()-3))
	else
		--ToggleTalentFrame()
		-- Code from Silverwind to solve glyph frame taint.
		UIParentLoadAddOn("Blizzard_TalentUI")
		ToggleFrame(PlayerTalentFrame)
		if PlayerTalentFrame:IsShown() and PlayerTalentFrame.selectedTab ~= 1 then
			PlayerTalentFrameTab1:GetScript("OnClick")(PlayerTalentFrameTab1,"LeftButton")
		end
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

