
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Tracking"
local tooltip = nil
local GetNumTrackingTypes,GetTrackingInfo = GetNumTrackingTypes,GetTrackingInfo


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show what you are currently tracking. You can also change the tracking types from this broker."],
	icon = "Interface\\Addons\\"..addon.."\\media\\tracking",
	events = {
		"MINIMAP_UPDATE_TRACKING",
		"PLAYER_LOGIN",
		"PLAYER_ENTERING_WORLD"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------
local function updateTracking()
	local tActive = 0
	local n = {}

	for i = 1, GetNumTrackingTypes() do
		local name, tex, active, category = GetTrackingInfo(i)
		if active == 1 then
			tActive = tActive + 1
			n[tActive] = {["Name"] = name, ["Texture"] = tex}
		end
	end

	return tActive, n
end 


------------------------------------
-- module (BE internal) functions --
------------------------------------
--[[ ns.modules[name].init = function(obj) end ]]

ns.modules[name].onevent = function(self,event,msg)
	local numActive, trackActive = updateTracking()
	local n = ""
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)

	if numActive == 0 then 
		n = "None"
	else
		for i = 1, numActive, 1 do
			n = trackActive[i]["Name"]
		end
	end

	dataobj.text = n
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local numActive, trackActive = updateTracking()
	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")

	if numActive == 0 then
		tooltip:AddLine(C("white",L["No tracking currently active."]))
	else
		for i = 1, numActive do 
			tooltip:AddDoubleLine(C("white",trackActive[i]["Name"]))
			tooltip:AddTexture(trackActive[i]["Texture"])
		end
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to choose tracking skill."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	if button == "LeftButton" then 
		ToggleDropDownMenu(1, nil, MiniMapTrackingDropDown, self, 0, 0)
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

