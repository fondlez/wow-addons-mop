
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Latency"
local tooltip = nil
local GetNetStats = GetNetStats
local suffix = "ms"
local latency = { Home = 0, World = 0 }


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show your current latency. Can be configured to show both Home and/or World latency."],
	icon = "Interface\\Addons\\"..addon.."\\media\\latency",
	events = {
		"PLAYER_ENTERING_WORLD"
	},
	updateinterval = 5,
	config = 	{
		height = 52,
		elements = {
			{
				type = "check",
				name = "showHome",
				label = L["show home"],
				desc = L["Enable/Disable the display of the latency to the home realm"],
			},
			{
				type = "check",
				name = "showWorld",
				label = L["show world"],
				desc = L["Enable/Disable the display of the latency to the world realms"],
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 130,
					y = 0
				 }
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name] == nil then
		Broker_EverythingDB[name] = {
			enabled = true,
			showHome = true,
			showWorld = true,
		}
	else
		if Broker_EverythingDB[name].showWorld == nil then
			Broker_EverythingDB[name].showWorld = true
		end
		if Broker_EverythingDB[name].showHome == nil then
			Broker_EverythingDB[name].showHome = true
		end
	end
end

ns.modules[name].onevent = function(self,event,msg)
	ns.modules[name].onupdate(self)
end

ns.modules[name].onupdate = function(self)
	local _, _, lHome, lWorld = GetNetStats()
	local text = ""
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)
	local suffix = C("suffix",suffix)

	latency.Home = lHome
	latency.World = lWorld
	
	 -- Colour the latencies
	for k, v in pairs(latency) do
		if v <= 250 then 
			latency[k] = C("green",v)
		elseif v > 250 and v <= 400 then
			latency[k] = C("dkyellow",v)
		elseif v > 400 then
			latency[k] = C("red",v)
		end		
	end

	local showHome, showWorld  = Broker_EverythingDB[name].showHome, Broker_EverythingDB[name].showWorld
	if (showWorld and not showHome) or not (showWorld and showHome) then
		text = string.format("%s%s", latency.World, suffix)
	elseif showHome and not showWorld then
		text = string.format("%s%s", latency.Home, suffix)
	elseif showHome and showWorld then
		text = string.format("%s%s%s %s%s%s", C("white","H:"), latency.Home, suffix, C("white","W:"), latency.World, suffix)
	end

	dataobj.text = text
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

ns.modules[name].ontooltip = function(tooltip)
	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")
	tooltip:AddDoubleLine(C("white",L["Home"] .. " :"), latency.Home .. suffix)
	tooltip:AddDoubleLine(C("white",L["World"] .. " :"), latency.World .. suffix)

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to toggle class coloring of the suffix."]))
		tooltip:AddLine(C("copper",L["Alt + Right-click"]).." "..C("green",L["to toggle showing Home Latency."]))
		tooltip:AddLine(C("copper",L["Ctrl + Right-click"]).." "..C("green",L["to toggle showing World Latency."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	if button == "RightButton" then
		if IsControlKeyDown() then
			if Broker_EverythingDB[name].showWorld then
				Broker_EverythingDB[name].showWorld = false
			else
				Broker_EverythingDB[name].showWorld = true
			end
		elseif IsAltKeyDown() then
			if Broker_EverythingDB[name].showHome then
				Broker_EverythingDB[name].showHome = false
			else
				Broker_EverythingDB[name].showHome = true
			end		
		else
			if Broker_EverythingDB.suffixColour then
				Broker_EverythingDB.suffixColour = false
			else
				Broker_EverythingDB.suffixColour = true
			end
		end
		ns.modules[name].onupdate(self)
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

