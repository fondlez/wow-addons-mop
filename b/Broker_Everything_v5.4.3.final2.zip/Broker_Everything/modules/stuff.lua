
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Stuff"
local tooltip = nil
local last_click = 0


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to allow you to do...Stuff! Switch to windowed mode, reload ui, logout and quit."],
	icon = "Interface\\Addons\\"..addon.."\\media\\stuff",
	events = {},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------
StaticPopupDialogs["CONFIRM"] = {
	text = L["Are you sure you want to Reload the UI?"],
	button1 = ACCEPT,
	button2 = CANCEL,
	OnAccept = function()
		ReloadUI()
	end,
	timeout = 20,
	whileDead = true,
	hideOnEscape = true,
	preferredIndex = 5,
}


------------------------------------
-- module (BE internal) functions --
------------------------------------

ns.modules[name].init = function(obj)
	if not obj then return end

	obj = obj.obj or ns.LDB:GetDataObjectByName(name) 

end

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local line, column
	
	tooltip:Clear()
	tooltip:AddHeader(C("dkyellow",L[name])) 
	tooltip:AddLine (" ")
	
	line, column = tooltip:AddLine(L["Toggle Windowed Mode"])
	tooltip:SetLineScript(line, "OnMouseUp", function(self) 
		SetCVar("gxWindow", 1 - tonumber(GetCVar("gxWindow")))
		RestartGx()
	end)			
	tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
	tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
	
	line, column = tooltip:AddLine(L["Reload UI"])
	--tooltip:SetLineScript(line, "OnMouseUp", function(self) ReloadUI(); end)			
	tooltip:SetLineScript(line, "OnMouseUp", function(self)	StaticPopup_Show("CONFIRM")	end) -- Use static Popup to avoid taint.
	tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
	tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
	
	line, column = tooltip:AddLine(L["Logout"])
	tooltip:SetLineScript(line, "OnMouseUp", function(self) Logout() end)			
	tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
	tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
	
	line, column = tooltip:AddLine(L["Quit Game"])
	tooltip:SetLineScript(line, "OnMouseUp", function(self) Quit() end)			
	tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
	tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
	
	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		line, column = nil, nil
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["Left-click to logout."]).." "..C("copper",L["Right-click"]).." "..C("green",L["to quit WoW."]))
		tooltip:AddLine(C("copper",L["Shift + Left-click"]).." "..C("green",L["to switch between windowed and|nfullscreen mode."]).. " "..C("copper",L["Shift + Right-click"]).." "..C("green",L["to reload UI."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 1, "LEFT") 
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then 
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
	local shift = IsShiftKeyDown() or -1
	local cv = 0

	if button == "RightButton" then
		cv = 1 * shift
	elseif button == "LeftButton" then
		cv = 2 * shift
	end

	if last_click ~= cv then
		last_click = cv
		return
	end

	-- only for windowed mode switching...
	last_click = 0

	if button == "RightButton" and shift > 0 then
		ReloadUI()
	elseif button == "RightButton" and shift < 0 then
		Quit()
	elseif button == "LeftButton" and shift > 0 then
		SetCVar("gxWindow", 1 - GetCVar("gxWindow"))
		RestartGx()
	elseif button == "LeftButton" and shift < 0 then
		Logout()
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

