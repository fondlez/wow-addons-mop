
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Clock"
local tooltip = nil
local GetGameTime = GetGameTime


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show realm or local time."],
	icon = "Interface\\Addons\\"..addon.."\\media\\clock",
	events = {},
	updateinterval = 5,
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "format24",
				label = L["24 Hour Time"],
				desc = L["Enable to display the time in 24 hour format; Disable to show as AM/PM"],
			},
			{
				type = "check",
				name = "clockLocal",
				label = L["Show Local Time"],
				desc = L["Enable to display the local time. Disable to show the realm time."],
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 130,
					y = 0
				 }
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name].enabled == nil then
		Broker_EverythingDB[name] = {
			enabled = true,
			timeLocal = true,
			format24 = true,
		}
	else
		if Broker_EverythingDB[name].format24 == nil then
			Broker_EverythingDB[name].format24 = true
		end
		if Broker_EverythingDB[name].timeLocal == nil then
			Broker_EverythingDB[name].timeLocal = true
		end
	end
end

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].onupdate = function(self)
	local h, m
	if not self then self = {} end
	self.obj = self.obj or ns.LDB:GetDataObjectByName(name)

	if Broker_EverythingDB[name].timeLocal == false then
		h, m = GetGameTime()
		if Broker_EverythingDB[name].format24 == true then
			self.obj.text = string.format ("%02d:%02d", h, m)
		else
			local a = "AM"
			if h >= 12 then
				h = h - 12
				a = "PM"
			end
			if h == 0 then h = 12 end
			self.obj.text = string.format ("%02d:%02d %s", h, m, a)
		end
	else
		if Broker_EverythingDB[name].format24 == true then
			self.obj.text = date("%H:%M")
		else
			self.obj.text = date("%I:%M %p")
		end
	end
end

ns.modules[name].ontooltip = function(tooltip)
	local h, m = GetGameTime()

	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")
	tooltip:AddDoubleLine(C("white",L["Server Time"]), C("white",string.format ("%02d:%02d", h, m)))
	tooltip:AddDoubleLine(C("white",L["Local Time"]), C("white",date("%H:%M")))

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to open the Time manager."]))
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to switch between local and server time."]))
		tooltip:AddLine(C("copper",L["Shift + Right-click"]).." "..C("green",L["to open calendar."]))
		tooltip:AddLine(C("copper",L["Shift + Left-click"]).." "..C("green",L["to switch between 12 & 24 hour time."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	local shift = IsShiftKeyDown()
	if button == "RightButton" and not shift then
		if Broker_EverythingDB[name].timeLocal == true then
			Broker_EverythingDB[name].timeLocal = false
		else
			Broker_EverythingDB[name].timeLocal = true
		end
		ns.modules[name].onupdate(self)
	elseif button == "RightButton" and shift then
		ToggleCalendar()
	elseif button == "LeftButton" and shift then 
		if Broker_EverythingDB[name].format24 == true then
			Broker_EverythingDB[name].format24 = false
		else
			Broker_EverythingDB[name].format24 = true
		end
		ns.modules[name].onupdate(self)
	else
		ToggleTimeManager()
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]
