
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Volume"
local tooltip = nil
local icon = "Interface\\AddOns\\"..addon.."\\media\\volume_"
local volume = {}


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Change Volumes and toogle some audio options."],
	icon = icon.."100",
	iconCoords = {0,1,0,1},
	events = {
		"ADDON_LOADED"
	},
	updateinterval = 1,
	config = {
	height = 62,
	elements = {
			{
				type = "check",
				name = "useWheel",
				label = L["Use MouseWheel"],
				desc = L["Use the MouseWheel to change the volume"]
			},
			{
				type = "slider",
				name = "steps",
				label = L["Steps"],
				desc = L["Change the steps of volume changes by using the mouse wheel."],
				minText = "1",
				maxText = "100",
				minValue = 1,
				maxValue = 100,
				default = 10,
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 140,
					y = 0
				}
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------
local function updateBrokerButton(self)
	volume.master = tonumber(GetCVar("Sound_MasterVolume"))
	local obj = self.obj or ns.LDB:GetDataObjectByName(name)
--	if volume.master == 1 then
--		obj.icon = icon.."100"
--	elseif volume.master > .66 then
--		obj.icon = icon.."66"
--	elseif volume.master > .33 then
--		obj.icon = icon.."33"
--	else
--		obj.icon = icon.."0"
--	end
	obj.text = ceil(volume.master*100).."%"
end


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(self)
	-- first init before LDB registration
	if not self then
		if Broker_EverythingDB[name].useWheel == nil then
			Broker_EverythingDB[name].useWheel = false
		end
		if Broker_EverythingDB[name].steps == nil then
			Broker_EverythingDB[name].steps = 1
		end
	else
	-- second init after LDB registration and obj contains the ldb registrated object...
		updateBrokerButton(self)
	end
end

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

ns.modules[name].onupdate = function(self)
	updateBrokerButton(self)
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

ns.modules[name].onmousewheel = function(self,direction)
	if not Broker_EverythingDB[name].useWheel then return end
	if (direction==-1 and volume.master == 0) or (direction==1 and volume.master == 1) then return end

	volume.master = volume.master + (direction * Broker_EverythingDB[name].steps / 100)
	if volume.master > 1 then
		volume.master = 1
	elseif volume.master < 0 then
		volume.master = 0
	end

--	SetCVar("Sound_MasterVolume",volume.master)
	BlizzardOptionsPanel_SetCVarSafe("Sound_MasterVolume",volume.master)
	updateBrokerButton(self)
end


ns.modules[name].ontooltip = function(tooltip)

	tooltip:Clear()
	tooltip:AddHeader(C("dkyellow",L[name]))
	
--	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to toggle volume up."]))
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to toggle volume down."]))
--	end

end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 1, "LEFT") 
	tooltip:Clear()
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
	ns.onenterRegMouseWheel(self,ns.modules[name].onmousewheel)
end

ns.modules[name].onleave = function(self)
	if tooltip then 
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
	if button == "LeftButton" then
		if volume.master == 1 then return end
		volume.master = volume.master + (Broker_EverythingDB[name].steps / 100)
		if volume.master > 1 then volume.master = 1 elseif volume.master < 0 then volume.master = 0 end
		BlizzardOptionsPanel_SetCVarSafe("Sound_MasterVolume",volume.master)
		updateBrokerButton(self)
	elseif button == "RightButton" then
		if volume.master == 0 then return end
		volume.master = volume.master - (Broker_EverythingDB[name].steps / 100)
		if volume.master > 1 then volume.master = 1 elseif volume.master < 0 then volume.master = 0 end
		BlizzardOptionsPanel_SetCVarSafe("Sound_MasterVolume",volume.master)
		updateBrokerButton(self)
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]





--[[

MasterVolume = 

self:SetOrientation('VERTICAL');
self:SetMinMaxValues(-1, 0);
self:SetValue((0-(MasterVolume/100)));
self:Show();

--DEFAULT_CHAT_FRAME:AddMessage("MasterVolume: "..MasterVolume);







self.value = abs(value);

if (self.value > .66) then
self.icon:SetTexCoord(.75, 1, 0, .25);
elseif (self.value > .33) then
self.icon:SetTexCoord(.50, .75, 0, .25);
elseif (self.value > 0) then
self.icon:SetTexCoord(.25, .50, 0, .25);
else
self.icon:SetTexCoord(0, .25, 0, .25);
end

self.label:SetText(tostring(ceil(self.value * 100)).."%");

SetCVar("Sound_MasterVolume", self.value);



]]