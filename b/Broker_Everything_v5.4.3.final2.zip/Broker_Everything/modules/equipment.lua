
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Equipment"
local tooltip = nil
local equipPending = nil


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show your Equipment Sets. Also allows deleting, equiping and saving of sets."],
	icon = "Interface\\Addons\\"..addon.."\\media\\equip",
	events = {
		"UNIT_INVENTORY_CHANGED",
		"EQUIPMENT_SETS_CHANGED",
		"PLAYER_LOGIN",
		"PLAYER_REGEN_ENABLED",
		"UNIT_INVENTORY_CHANGED",
		"EQUIPMENT_SETS_CHANGED"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------



------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if Broker_EverythingDB[name].enabled == nil then 
		Broker_EverythingDB[name] = { 
			enabled = true
		}
	end
end

ns.modules[name].onevent = function(self,event,...)
	if event == "PLAYER_REGEN_ENABLED" then
		if equipPending ~= nil then
			UseEquipmentSet(equipPending)
			equipPending = nil
		end
	end

	if event == "PLAYER_LOGIN" then -- ?
		self:UnregisterEvent("PLAYER_LOGIN")
	end

	if event == "UNIT_INVENTORY_CHANGED" then
		local unit = ...
		if unit ~= "player" then return end
	end

	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)

	local numEquipSets = GetNumEquipmentSets()

	if numEquipSets >= 1 then 
		for i = 1, GetNumEquipmentSets() do 
			local equipName, icon, _, isEquipped, _, _, _, numMissing = GetEquipmentSetInfo(i)
			if isEquipped then 
				dataobj.icon = icon
				dataobj.text = equipName
				return
			else 
				dataobj.icon = "Interface\\Addons\\"..addon.."\\media\\equip.tga"
				dataobj.text = L["Unknown Set"]
			end
		end
	else
		dataobj.text = L["No Sets found"]
	end
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local line, column
	tooltip:Clear()
	tooltip:AddHeader(C("dkyellow",L[name]))
	tooltip:AddSeparator()
	if not CanUseEquipmentSets() then
		tooltip:AddLine(L["Equipment Manager is not enabled."])
		tooltip:AddLine(L["Enable Equipment Manager from the Character pane."])
		return
	end

	local numEquipSets = GetNumEquipmentSets()

	if numEquipSets < 1 then
		tooltip:AddLine(L["You do not have any Equipment Sets."])
		line, column = tooltip:AddLine(C("copper",L["Click"]).." "..C("green",L["here to open Equipment Manager."]))
		tooltip:SetLineScript(line, "OnMouseUp", function(self) ToggleCharacter("PaperDollFrame") end)
		tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
		tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)

		line, column = nil, nil
		return
	end

	for i = 1, numEquipSets do 
		local name, icon, _, isEquipped, _, _, _, numMissing = GetEquipmentSetInfo(i)
		local formatName = ((numMissing > 0) and C("red",name)) or (isEquipped and C("ltyellow",name)) or name

		line, column = tooltip:AddLine()
		--		tooltip:SetCell(line, 1, C("ltyellow",L["Level"]), nil, nil, 1, ns.LQT.LabelProvidor, 0, 10)
		tooltip:SetCell(line, 1, formatName, nil, nil, 1, ns.LQT.LabelProvidor, 0, 5)
		tooltip:SetCell(line, 2, " |T"..icon..":16|t", nil, nil, 1)
		tooltip:SetLineScript(line, "OnMouseUp", function(self) 
			if IsShiftKeyDown() then 
				local dialog = StaticPopup_Show('CONFIRM_SAVE_EQUIPMENT_SET', name)
				dialog.data = name 
			elseif IsControlKeyDown() then
				local dialog = StaticPopup_Show('CONFIRM_DELETE_EQUIPMENT_SET', name)
				dialog.data = name				
			else
				if InCombatLockdown() then 
					equipPending = name
				else
					UseEquipmentSet(name)
				end
			end 
		end)			
		tooltip:SetLineScript(line, "OnEnter", function(self) tooltip:SetLineColor(line, 1,192/255, 90/255, 0.3) end )
		tooltip:SetLineScript(line, "OnLeave", function(self) tooltip:SetLineColor(line, 0,0,0,0) end)
	end

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Click"]).." "..C("green",L["to equip a set."]), nil, nil, 2)
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Shift + Click"]).." "..C("green",L["to update or save a set."]), nil, nil, 2)
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Ctrl + Click"]).." "..C("green",L["to delete a set"]), nil, nil, 2)
	end

	line, column = nil, nil
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 2, "LEFT", "RIGHT")
	tooltip:Clear()
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then 
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

