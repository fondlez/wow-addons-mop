
--[[
	Little description to this 3 in 1 module.
	it register 4 modules. the first (name0) is only for configuration.
	all config variables in name0 are used in the other modules.
]]


----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name0 = "GPS / Location / ZoneText"
local name1 = "GPS"
local name2 = "Location"
local name3 = "ZoneText"
local tooltip1 = nil
local tooltip2 = nil
local tooltip3 = nil
local gpsLoc = {
	zone = " ",
	color = "white",
	pvp = "contested",
}
--[[
local teleports = ns.player.faction == "horde" and {3563,3566,3567,32272,49358,35715,53140,88344,132627}    or {3561,3562,3565,32271,49359,33690,53140,88342,132621}
local portals   = ns.player.faction == "horde" and {11418,11420,11417,32267,49361,35717,53142,88346,132626} or {10059,11416,11419,32266,49360,33691,53142,88345,132620}
local items_for_menu = {18984,18986,21711,30542,30544,32757,35230,37863,40585,40586,43824,44934,44935,45688,45689,45690,45691,46874,48933,48954,48955,48956,48957,50287,51557,51558,51559,51560,52251,58487,63206,63207,63352,63353,63378,63379,64457,65274,65360,87215,95050,95051,95567,95568}
local item_replacements = {64488,28585,6948,44315,44314,37118}
]]

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name0] = {
	noBroker = true,
	desc = "",
	icon = "",
	events = {
		"PLAYER_LOGIN",
		"PLAYER_ENTERING_WORLD",
		"ADDON_LOADED",
		"ZONE_CHANGED",
		"ZONE_CHANGED_INDOORS",
		"ZONE_CHANGED_NEW_AREA",
	},
	updateinterval = nil,
	config = {
		height = 62,
		elements = {
			{
				type		= "slider",
				name		= "precision",
				label		= L["Precision"],
				desc		= L["..."],
				minText		= "0",
				maxText		= "3",
				minValue	= 0,
				maxValue	= 3,
				default		= 0,
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "BOTTOMLEFT",
					x = 0,
					y = -10
				}
			},
			{
				type	= "dropdown",
				name	= "format",
				label	= L["Co-ordination format"],
				desc	= L["How would you like to view co-ordinations."],
				values	= {
					["%s, %s"]     = "10.3, 25.4",
					["%s / %s"]    = "10.3 / 25.4",
					["%s/%s"]      = "10.3/25.4",
					["%s | %s"]    = "10.3 | 25.4",
					["%s||%s"]     = "10.3||25.4"
				},
				default = "%s, %s",
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 20,
					y = 0
				}
			}
		}
	}
}

ns.modules[name1] = {
	desc = L["Broker to show the name of the current Zone and the co-ordinates."],
	icon = "Interface\\Addons\\"..addon.."\\media\\gps",
	events = {
		"ZONE_CHANGED",
		"ZONE_CHANGED_INDOORS",
		"ZONE_CHANGED_NEW_AREA"
	},
	updateinterval = false,
	config = nil -- {}
}

ns.modules[name2] = {
	desc = L["Broker to show your current co-ordinates within the zone."],
	icon = "Interface\\Addons\\"..addon.."\\media\\gps",
	enabled = false,
	events = {},
	updateinterval = false,
}

ns.modules[name3] = {
	desc = L["Broker to show the name of the current zone."],
	icon = GetItemIcon(11105),
	enabled = false,
	events = {
		"PLAYER_LOGIN",
		"PLAYER_ENTERING_WORLD",
		"ADDON_LOADED",
		"ZONE_CHANGED",
		"ZONE_CHANGED_INDOORS",
		"ZONE_CHANGED_NEW_AREA"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------
local function position(precision,_format)
	if not precision then precision = 0 end
	local precision_format = "%."..precision.."f"
	if not _format then _format = "%s, %s" end
	local x, y = GetPlayerMapPosition("player")
	if x ~= 0 and y ~= 0 then
		return string.format(
			_format,
			string.format(precision_format, (x * 100)),
			string.format(precision_format, (y * 100))
		)
	else
		return string.format(_format, "?.??", "?.??" )
	end
end

local function zone()
	local subZone = GetSubZoneText() or ""
	local zone = GetRealZoneText() or ""

	if subZone == nil  or subZone == "" then
		return zone
	else
		return subZone
	end
end

local function zoneColor()
	local p, _, f = GetZonePVPInfo()
	local color = "white"

	if p == "combat" or p == "arena" or p == "hostile" then
		color = "red"
	elseif p == "contested" or p == nil then
		color = "dkyellow"
		p = "contested"
	elseif p == "friendly" then
		color = "ltgreen"
	elseif p == "sanctuary" then
		color = "ltblue"
	end

	return p, color
end

local function getMenu(parent)
	local menuTable = {}
	local _, i = nil, 1
	local class, faction = ns.player.class:lower(), ns.player.faction:lower()

	local function makeMenuEntry(id,idType)
		if idType=="spell" then
			local sName,_,sIcon = GetSpellInfo(id)
			return { text = "|T"..sIcon..":0:0:0:0|t "..sName, func = function() securecall(CastSpell,id,"spell") end }
		else
			return {}
		end
	end

	if class=="mage" or class=="deathknight" or class=="druid" or class=="shaman" then
		menuTable[i] = { text = L["Class specifics"], isTitle = true }
		i = i + 1
	end

	if class == "mage" then
		menuTable[i] = { text = L["Teleportations"], hasArrow = true, menuList = {} }
		for I, v in pairs(teleports) do
			menuTable[i].menuList[I] = makeMenuEntry(v,"spell")
		end
		i = i + 1
		menuTable[i] = { text = L["Portals"], hasArrow = true, menuList = {} }
		for I, v in pairs(portals) do
			menuTable[i].menuList[I] = makeMenuEntry(v,"spell")
		end
		i = i + 1
	elseif class == "deathknight" then
		menuTable[i] = makeMenuEntry(50977,"spell")
		i = i + 1
	elseif class == "druid" then
		menuTable[i] = makeMenuEntry(18960,"spell")
		i = i + 1
	elseif class == "shaman" then
		menuTable[i] = makeMenuEntry(556,"spell")
		i = i + 1
	end

	

	if parent then
		local menu = CreateFrame("Frame",name2.."_Dropdown", parent, "UIDropDownMenuTemplate")
		EasyMenu(menuTable,menu,parent,0,0,"MENU")
	else
		local menu = CreateFrame("Frame",name2.."_Dropdown", UIParent, "UIDropDownMenuTemplate")
		EasyMenu(menuTable,menu,"cursor",0,0,"MENU")
	end
end


-- shared tooltip for modules Location, GPS and ZoneText
local function gpsTooltip(self,tooltip,modName)
	local pvp, color = zoneColor()
	pvp = gsub(pvp,"^%l", string.upper)

	tooltip:Clear()

	tooltip:AddHeader(C("dkyellow",L[modName]))
	tooltip:AddSeparator()
	tooltip:AddLine(C("ltyellow",L["Zone"] .. ":"), GetRealZoneText())
	tooltip:AddLine(C("ltyellow",L["Sub-Zone"] .. ":"), GetSubZoneText())
	tooltip:AddLine(C("ltyellow",L["PVP Flag"] .. ":"), C(color,L[pvp]))
	tooltip:AddLine(C("ltyellow",L["Co-ordinates"] .. ":"), position(Broker_EverythingDB[name0].precision,Broker_EverythingDB[name0].format))
	tooltip:AddLine(C("ltyellow",L["Inn"]..":"), GetBindLocation())

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, C("copper",L["Click"]).." "..C("green",L["to open the World Map."]), nil, nil, 2)
	end
end

local function onclick(self,button)
--	if button == "LeftButton" then
		if GUILockDown == nil then 
			ToggleFrame(WorldMapFrame)
		elseif GUILockDown == 1 then 
			return 
		end
--	elseif button == "RightButton" then
--		getMenu(self)
--	end
end


------------------------------------
-- module (BE internal) functions --
------------------------------------

ns.modules[name0].init = function(self)
	if Broker_EverythingDB[name0].precision == nil then
		Broker_EverythingDB[name0].precision = 1
	end
	if Broker_EverythingDB[name0].format == nil then
		Broker_EverythingDB[name0].format = "%s, %s"
	end
end

--[[ ns.modules[name1].init = function(self) end ]]

--[[ ns.modules[name2].init = function(self) end ]]

--[[ ns.modules[name3].init = function(self) end ]]

ns.modules[name0].onevent = function(self,event,msg)
	local obj = self.obj or ns.LDB:GetDataObjectByName(name1)
	gpsLoc.zone = zone()
	gpsLoc.pvp, gpsLoc.color = zoneColor()
end

--[[ ns.modules[name1].onevent = function(self,event,msg) end ]]

--[[ ns.modules[name2].onevent = function(self,event,msg) end ]]

ns.modules[name3].onevent = function(self,event,msg)
	(self.obj or ns.LDB:GetDataObjectByName(name3)).text = C(gpsLoc.color,gpsLoc.zone)
end

--[[ ns.modules[name0].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name1].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name2].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name3].onmousewheel = function(self,direction) end ]]


--[[ ns.modules[name0].onupdate = function(self) end ]]

ns.modules[name1].onupdate = function(self)
	(self.obj or ns.LDB:GetDataObjectByName(name1)).text = C(gpsLoc.color,string.format("%s (%s)", gpsLoc.zone, position(Broker_EverythingDB[name0].precision,Broker_EverythingDB[name0].format)))
end

ns.modules[name2].onupdate = function(self)
	(self.obj or ns.LDB:GetDataObjectByName(name2)).text = position(Broker_EverythingDB[name0].precision,Broker_EverythingDB[name0].format)
end

--[[ ns.modules[name3].onupdate = function(self) end ]]

--[[ ns.modules[name0].optionspanel = function(panel) end ]]

--[[ ns.modules[name1].optionspanel = function(panel) end ]]

--[[ ns.modules[name2].optionspanel = function(panel) end ]]

--[[ ns.modules[name3].optionspanel = function(panel) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name1].onenter = function(self)
	tooltip1 = ns.LQT:Acquire(name1.."TT", 2, "LEFT", "RIGHT")
	gpsTooltip(self,tooltip1,name1)
	ns.createTooltip(self,tooltip1)
end

ns.modules[name2].onenter = function(self)
	tooltip2 = ns.LQT:Acquire(name2.."TT", 2, "LEFT", "RIGHT")
	gpsTooltip(self,tooltip2,name2)
	ns.createTooltip(self,tooltip2)
end

ns.modules[name3].onenter = function(self)
	tooltip3 = ns.LQT:Acquire(name3.."TT", 2, "LEFT", "RIGHT")
	gpsTooltip(self,tooltip3,name3)
	ns.createTooltip(self,tooltip3)
end

ns.modules[name1].onleave = function()
	if tooltip1 then
		if MouseIsOver(tooltip1) then
			ns.advHideTooltip(tooltip1)
			tooltip1:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip1)
		end
	end
end

ns.modules[name2].onleave = function()
	if tooltip2 then
		if MouseIsOver(tooltip2) then
			ns.advHideTooltip(tooltip2)
			tooltip2:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip2)
		end
	end
end

ns.modules[name3].onleave = function()
	if tooltip3 then
		if MouseIsOver(tooltip3) then
			ns.advHideTooltip(tooltip3)
			tooltip3:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip3)
		end
	end
end

ns.modules[name1].onclick = onclick

ns.modules[name2].onclick = onclick

ns.modules[name3].onclick = onclick

--[[ ns.modules[name1].ondblclick = function(self,button) end ]]

--[[ ns.modules[name2].ondblclick = function(self,button) end ]]

--[[ ns.modules[name3].ondblclick = function(self,button) end ]]
