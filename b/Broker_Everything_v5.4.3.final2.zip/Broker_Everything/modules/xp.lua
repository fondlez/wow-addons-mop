
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "XP"
local tooltip = nil
local string = string


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show your xp. Can be shown either as a percentage, or as values."],
	icon = "Interface\\Addons\\"..addon.."\\media\\xp",
	events = {
		"PLAYER_XP_UPDATE",
		"PLAYER_LOGIN",
		"DISABLE_XP_GAIN",
		"ENABLE_XP_GAIN"
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "display",
				label = L["Display XP as Absolute Value"],
				desc = L["Select to show XP as an absolute value; Deselected will show it as a percentage."],
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	if not Broker_EverythingDB[name] then
		Broker_EverythingDB[name] = {
			enabled = true,
			display = 0
		}
	end
	if Broker_EverythingDB[name].display == nil then
		Broker_EverythingDB[name].display = 0
	elseif Broker_EverythingDB[name].display==true then
		Broker_EverythingDB[name].display = 1
	elseif Broker_EverythingDB[name].display==false then
		Broker_EverythingDB[name].display = 0
	end
end

ns.modules[name].onevent = function(self,event,msg)
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)
	if IsXPUserDisabled() then
		dataobj.text = C("orange",L["XP gain disabled!"])
	elseif Broker_EverythingDB[name].display == 0 then
		dataobj.text = math.floor((UnitXP("player") / UnitXPMax("player")) * 100) .. "%"
	elseif Broker_EverythingDB[name].display == 1 then
		dataobj.text = UnitXP("player") .. "/" ..  UnitXPMax("player")
	elseif Broker_EverythingDB[name].display == 2 then
		dataobj.text = (UnitXPMax("player") - UnitXP("player"))
	end
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local e, m = UnitXP("player"), UnitXPMax("player")
	local r = GetXPExhaustion()

	if not r then
		r = "0%"
	else
		r = floor((r / m) * 100) .. "%"
	end

	if IsXPUserDisabled() then
		tooltip:AddLine(C("orange",L["XP gain disabled!"]))
	else
		tooltip:AddLine(L[name])
	end

	tooltip:AddLine(" ")
	tooltip:AddDoubleLine(C("ltyellow",string.format("%s:", L[name])), C("white",string.format("%d/%d", e, m)))
	tooltip:AddDoubleLine(C("ltyellow",string.format("%s:", L["Til Next Level"])), C("white",m - e))
	tooltip:AddDoubleLine(C("ltyellow",string.format("%s:", L["Rest"])), C("white",r))

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to switch display mode."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

ns.modules[name].onclick = function(self,button)
	if button == "RightButton" then
		if type(Broker_EverythingDB[name].display)=="boolean" then
			Broker_EverythingDB[name].display = 0
		end
		if Broker_EverythingDB[name].display == 2  then
			Broker_EverythingDB[name].display = 0
		else
			Broker_EverythingDB[name].display = Broker_EverythingDB[name].display + 1
		end
		ns.modules[name].onevent(self)
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

