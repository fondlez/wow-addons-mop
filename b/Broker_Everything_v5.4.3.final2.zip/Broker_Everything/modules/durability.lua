
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Durability"
local tooltip = nil
local hiddenTooltip = nil
local atMerchant = nil
local _GetCoinTextureString = GetCoinTextureString


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show durability of your gear and estimated repair total."],
	icon = "Interface\\Minimap\\TRACKING\\Repair",
	events = {
		"PLAYER_LOGIN",
		"PLAYER_DEAD",
		"MERCHANT_CLOSED",
		"PLAYER_REGEN_ENABLED",
		"PLAYER_ENTERING_WORLD",
		"MERCHANT_SHOW"
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "goldColor",
				label = L["Gold coloring"],
				desc = L["Use colors instead of icons for gold, silver and copper"],
				event = true
			},
			{
				type = "check",
				name = "costsInButton",
				label = L["Rep. costs in button"],
				desc = L["Display the repair costs in broker button instead of the durability in percent."],
				event = true,
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 130,
					y = 0
				}
			}
		}
	}

}


--------------------------
-- some local functions --
--------------------------
local function GetCoinTextureString(amount,sep)
	if Broker_EverythingDB[name].goldColor then
		if (not sep) then sep = "." end
		local gold, silver, copper = tostring(math.floor(amount / 10000)), tostring(mod(math.floor(amount / 100), 100)), tostring(mod(amount, 100))
		local t, i = {}, 1
		if gold~="0" then
			t[i], silver, i = C("gold",gold), string.format("%02d",silver), i + 1
		end
		if silver~="0" then
			t[i], copper, i = C("silver",silver), string.format("%02d",copper), i + 1
		end
		t[i] = C("copper",copper)
		return table.concat(t,sep)
	else
		return _GetCoinTextureString(amount)
	end
end

local function getRepairCosts()
	local total = 0
	local slots = {
		"Head",
		"Shoulder", 
		"Chest", 
		"Waist", 
		"Legs", 
		"Feet", 
		"Wrist", 
		"Hands", 
		"MainHand", 
		"SecondaryHand"
	}

	for _, slot in ipairs(slots) do
		local id = GetInventorySlotInfo(slot .. "Slot")
	
		local hasItem, _ ,cost = hiddenTooltip:SetInventoryItem("player", id)
		
		total = total + cost
	end
	return total
end

-- Function to remove the reputation discounts if at a vendor.
local function removeRepDiscounts(total)
	if not atMerchant then return end

	local reputation = UnitReaction("npc", "player")
	if reputation == 5 then
		--total = total * 100 / 95
		total = total  / 0.95
	elseif reputation == 6 then
		total = total / 0.9
	elseif reputation == 7 then
		total = total / 0.85
	elseif reputation == 8 then
		total = total / 0.8
	end
	return total
end

local function durabilityPercent()
	local d = 1
	for slotId = 1, 18 do
		if GetInventoryItemLink("player", slotId) then
			local x, y = GetInventoryItemDurability(slotId)
			if x and y > 0 then
				if x / y < d then
					d = x / y
				end
			end
		end
	end

	return floor(d * 100)
end


------------------------------------
-- module (BE internal) functions --
------------------------------------

ns.modules[name].init = function(obj)
	hiddenTooltip = CreateFrame("GameTooltip", "BasicBrokerScanTip", nil, "GameTooltipTemplate")
	hiddenTooltip:SetOwner(UIParent, "ANCHOR_NONE")
end

ns.modules[name].onevent = function(self,event,msg)
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name) 

	if event == "MERCHANT_SHOW" then atMerchant = "yes" end

	if event == "MERCHANT_CLOSED" then atMerchant = nil end

	if Broker_EverythingDB[name].costsInButton then
		dataobj.text = GetCoinTextureString(getRepairCosts())
	else
		local c,d = "dkyellow",durabilityPercent()
		if d < 20 then
			c = "red"
		elseif d < 40 then
			c = "orange"
		elseif d == 100 then
			c = "green"
		end
		dataobj.text = C(c,d.."%")
	end
end

ns.modules[name].onclick = function(self,button)
	ToggleCharacter("PaperDollFrame")
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

ns.modules[name].ontooltip = function(tooltip)
	local repairCost = getRepairCosts()
	if atMerchant then 
		repairCost = removeRepDiscounts(repairCost)
	end

	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")
	tooltip:AddDoubleLine(C("dkyellow",L["Repair Cost"]), GetCoinTextureString(repairCost))
	tooltip:AddLine(" ")
	tooltip:AddLine(C("ltblue",L["Reputation discounts"]))
	tooltip:AddDoubleLine(C("white",L["Neutral"]), GetCoinTextureString(repairCost))
	tooltip:AddDoubleLine(C("white",L["Friendly"]), GetCoinTextureString(repairCost * 0.95))
	tooltip:AddDoubleLine(C("white",L["Honoured"]), GetCoinTextureString(repairCost * 0.90))
	tooltip:AddDoubleLine(C("white",L["Revered"]), GetCoinTextureString(repairCost * 0.85))
	tooltip:AddDoubleLine(C("white",L["Exalted"]), GetCoinTextureString(repairCost * 0.80))

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to show character info."]))
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

