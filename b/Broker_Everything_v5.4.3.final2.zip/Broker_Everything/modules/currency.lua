
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Currency"
local tooltip = nil
local tooltip2 = nil
local currencies = {}
local currenciesName2Id = {}
local menu = nil
local tt2positions = {
	["BOTTOM"] = {edgeSelf = "TOP",    edgeParent = "BOTTOM", x =  0, y = -2},
	["LEFT"]   = {edgeSelf = "RIGHT",  edgeParent = "LEFT",   x = -2, y =  0},
	["RIGHT"]  = {edgeSelf = "LEFT",   edgeParent = "RIGHT",  x =  2, y =  0},
	["TOP"]    = {edgeSelf = "BOTTOM", edgeParent = "TOP",    x =  0, y =  2}
}

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show your different currencies."],
	icon = "Interface\\Addons\\"..addon.."\\media\\icon-Neutral",
	events = {
		"PLAYER_ENTERING_WORLD",
		"KNOWN_CURRENCY_TYPES_UPDATE",
		"CURRENCY_DISPLAY_UPDATE"
	},
	updateinterval = nil, -- 10
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "shortTT",
				label = L["short Tooltip"],
				desc = L["display the content of the tooltip shorter"]
			},
			{
				type	= "dropdown",
				name	= "subTTposition",
				label	= L["Second tooltip"],
				desc	= L["Where does the second tooltip for a single currency are displayed from the first tooltip"],
				values	= {
					["TOP"]     = L["Over"],
					["LEFT"]    = L["Left"],
					["RIGHT"]   = L["Right"],
					["BOTTOM"]  = L["Under"]
				},
				default = "BOTTOM",
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 100,
					y = 0
				}
			}
		}
	}
}


--------------------------
-- some local functions --
--------------------------
local function collectData() -- collect currency data
	local byName = {}
	for i=0, GetCurrencyListSize() do
		local itemname, isHeader, isExpanded, isUnused, isWatched, count, icon = GetCurrencyListInfo(i)

		currencies[i] = {
			["name"] = itemname,
			["isHeader"] = isHeader,
			["isUnused"] = isUnused,
			["count"] = count,
			["maxCount"] = nil,
			["maxWeekly"] = nil,
			["icon"] = icon
		}
		if itemname then
			currenciesName2Id[itemname] = i
		end
	end
end

local function updateTitle()
	local title = {}
	for i, v in pairs(Broker_EverythingDB[name].currenciesInTitle) do
		if v and currenciesName2Id[v] and currencies[currenciesName2Id[v]] then
			local d = currencies[currenciesName2Id[v]]
			if d.icon then
				table.insert(title, d.count .. "|T" .. d.icon .. ":0|t")
			end
		end
	end
	local obj = ns.LDB:GetDataObjectByName(name)
	if #title==0 then
		obj.text = L[name]
	else
		obj.text = table.concat(title," ")
	end
end

local function setInTitle(titlePlace, currencyName)
	if Broker_EverythingDB[name].currenciesInTitle[titlePlace] ~= currencyName then
		for i, v in pairs(Broker_EverythingDB[name].currenciesInTitle) do
			if titlePlace~=i and Broker_EverythingDB[name].currenciesInTitle[i]==currencyName then return end
		end
		Broker_EverythingDB[name].currenciesInTitle[titlePlace] = currencyName
	else
		Broker_EverythingDB[name].currenciesInTitle[titlePlace] = false
	end
	updateTitle()
	ns.hideTooltip(tooltip) -- shared.lua
end

local function makeMenu(parent)
	local menuTable = {{text = L["Currencies in Title"], isTitle = true }}
	local i = 2
	local inTitle = setmetatable({},{__index=function() return false end})
	menu = CreateFrame("Frame",name.."_Dropdown", parent or UIParent, "UIDropDownMenuTemplate")

	for place=1, 4 do
		if Broker_EverythingDB[name].currenciesInTitle[place] then
			inTitle[Broker_EverythingDB[name].currenciesInTitle[place]] = true
		end
	end

	for place=1, 4 do
		menuTable[i],i = {text = " ", isTitle = true },i+1
		menuTable[i],i = {text = C("white",L["Place"].." "..place), isTitle = true },i+1
		local doing = L["Add a currency"]
		if Broker_EverythingDB[name].currenciesInTitle[place] then
			local id = currenciesName2Id[Broker_EverythingDB[name].currenciesInTitle[place]]
			local d = currencies[id]
			if d~=nil then
				menuTable[i],i = { text = L["Remove"].." "..C("ltblue",d.name), func = function() setInTitle(place,d.name); menu:Hide(); menu = nil end },i+1
				doing = L["Replace the curreny"]
			end
		end
		menuTable[i] = { text = doing, hasArrow = true, menuList = {} }
		local I = 1
		for k,v in pairs(currencies) do
			if v.name and not inTitle[v.name] then
				if v.isHeader then
					menuTable[i].menuList[I],I = {text = C("ltblue",v.name), isTitle = true},I+1
				else
					menuTable[i].menuList[I],I = {text = C("ltyellow",v.name), func = function() setInTitle(place,v.name); menu:Hide(); menu = nil end},I+1
				end
			end
		end
		i=i+1
	end

	EasyMenu(menuTable,menu,parent or "cursor",0,0)
end



------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(self)
	-- pre LDB init
	if not self then
		if Broker_EverythingDB[name].currenciesInTitle==nil then
			Broker_EverythingDB[name].currenciesInTitle = {["1"]=false,["2"]=false,["3"]=false,["4"]=false}
		end

		if Broker_EverythingDB[name].shortTT == nil then
			Broker_EverythingDB[name].shortTT = false
		end

		if Broker_EverythingDB[name].subTTposition == nil then
			Broker_EverythingDB[name].subTTposition = "BOTTOM"
		end
	else
		-- post LDB init
		updateTitle()
	end
end

ns.modules[name].onevent = function(self,event,msg)
	local obj = ns.LDB:GetDataObjectByName(name)
	if UnitFactionGroup("player") ~= "Neutral" then
		obj.icon = [[Interface\PVPFrame\PVP-Currency-]]..UnitFactionGroup( "player" )
	end
	collectData()
	updateTitle()
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name].ontooltip = function(tooltip)

	tooltip:Clear()
	tooltip:AddHeader(C("dkyellow",L[name]))
	if Broker_EverythingDB[name].shortTT == true then
		tooltip:AddSeparator()
	end

	for i,v in ipairs(currencies) do
		if not v.isUnused then
			if v.isHeader then
				if Broker_EverythingDB[name].shortTT == false then
					local l,c = tooltip:AddLine(" ")
					tooltip.lines[l]:SetHeight(1.6) -- reduce height of the blank line
					tooltip:AddLine(C("ltblue",v.name))
					tooltip:AddSeparator()
				end
			else
				local line, column = tooltip:AddLine(C("ltyellow",v.name),v.count.."  |T"..v.icon..":0|t")
				local lineObj = tooltip.lines[line]
				lineObj.currencyIndex = i

				tooltip:SetLineScript(line, "OnEnter",function(self)
					if not tooltip2 then
						tooltip2 = GameTooltip
					end
					tooltip2:SetOwner(tooltip,"ANCHOR_NONE")
					local pos = tt2positions[Broker_EverythingDB[name].subTTposition]
					tooltip2:SetPoint(pos.edgeSelf,tooltip,pos.edgeParent, pos.x , pos.y)
					-- changes for user choosen direction
					tooltip2:ClearLines()
					tooltip2:SetCurrencyToken(self.currencyIndex) -- tokenId / the same index number if needed by GetCurrencyListInfo
					tooltip2:Show()
				end)

				tooltip:SetLineScript(line, "OnLeave", function(self)
					tooltip2:Hide()
				end)
			end
		end
	end

	local l,c = tooltip:AddLine(" ")
	tooltip.lines[l]:SetHeight(2.2) -- reduce height of the blank line

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to open currency pane"]))
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to open the 'place in title' menu"]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 2, "LEFT", "RIGHT", "RIGHT")
	tooltip:Clear()
	ns.modules[name].ontooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then
		if MouseIsOver(tooltip) then
			ns.advHideTooltip(tooltip)
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.modules[name].onclick = function(self,button)
	if button == "LeftButton" then
		ToggleCharacter("TokenFrame")
	else
		if menu==nil then
			makeMenu(self)
		else
			menu:Hide()
			menu = nil
		end
	end
end

--[[ ns.modules[name].ondblclick = function(self,button) end ]]




--[[
IDEAS:
* get max count and weekly max count of a currency for displaying caped counts in red.
* Ctrl-clicks to set custom caps.
]]

