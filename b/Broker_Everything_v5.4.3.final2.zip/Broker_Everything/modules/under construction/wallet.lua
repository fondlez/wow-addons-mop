
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name0 = "Wallet / Gold / Currency"
local name1 = "Wallet"
local name2 = "Gold"
local name3 = "Currency"

local tooltip = nil
local tooltip2 = nil

local currencies = {}
local currencies_inTitle = {}

local current_money = 0
local goldInit = false
local goldLoaded = false
local faction = UnitFactionGroup("Player")
local GetCoinTextureString = ns.GetCoinString


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name0] = {
	noBroker = true,
	desc = "",
	icon = "",
	events = {
		"PLAYER_ENTERING_WORLD",
		"KNOWN_CURRENCY_TYPES_UPDATE",
		"CURRENCY_DISPLAY_UPDATE"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}

ns.modules[name1] = {
	desc = L[""],
	icon = "",
	events = {},
	updateinterval = nil,
	config = nil
}
ns.modules[name2] = {
	desc = L[""],
	icon = "",
	events = {},
	updateinterval = nil,
	config = nil
}
ns.modules[name3] = {
	desc = L[""],
	icon = "",
	events = {},
	updateinterval = nil,
	config = nil
}


------------------------------------
-- module (BE internal) functions --
------------------------------------
--[[ ns.modules[name].init = function(obj) end ]]

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].ontooltip = function(tooltip) end ]]


---------------------------------
-- module (external) functions --
---------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]
	--self:EnableMouseWheel(1) 
	--self:SetScript("OnMouseWheel", OnMouseWheel)

--[[ ns.modules[name].onleave = function(self) end ]]

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]





--[[
		if Broker_EverythingDB.goldColour == nil then
			Broker_EverythingDB.goldColour = false
		end

	panel.goldColoring = makeCheck(L["gold colouring"], L["Enable/Disable colouring all coints instead of using icons representing gold, silver or copper."], "nil", "goldColour")
]]