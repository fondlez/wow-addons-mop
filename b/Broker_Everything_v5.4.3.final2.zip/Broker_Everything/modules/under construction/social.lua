
--[[
	Info:
	This modules is currently under construction.
	This module will be a merge of guild and friends into a single broker.
	It is planned to merge contents of social, friends and guild later into a 3 in 1 module file like gps.
	It is also planned to set friends and guild as optional loaded after merge into 3in1 file.
]]

----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Social"
local form = "%d/%d"
local tooltip = nil
local friends = {on=0,sum=0}
local bnetfriends = {on=0,sum=0,off=false}
local guild = {on=0,sum=0,no=false,xp=0,motd="",officer=false}
local misc = {}
local lists = {}
local DSw, DSh =  0,  0
local ULx, ULy =  0,  0
local LLx, LLy = 32, 32
local URx, URy =  9, 23
local LRx, LRy =  9, 23
local gameIconPos = setmetatable({},{ __index = function(t,k) return format("%s:%s:%s:%s:%s:%s:%s:%s:%s:%s",DSw,DSh,ULx,ULy,LLx,LLy,URx,URy,LRx,LRy) end})
local gameShortcut = setmetatable({ [BNET_CLIENT_WTCG] = "HS", [BNET_CLIENT_SC2] = "Sc2"},{ __index = function(t, k) return k end })
local _BNet_GetClientTexture = BNet_GetClientTexture

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Displayed you friends and guild in one broker."],
	icon = "Interface\\Addons\\"..addon.."\\media\\friends",
	events = {
		"BN_FRIEND_ACCOUNT_OFFLINE",
		"BN_FRIEND_ACCOUNT_ONLINE",
		"FRIENDLIST_UPDATE",
		"GUILD_ROSTER_UPDATE",
		"GUILD_XP_UPDATE",
		"PLAYER_ENTERING_WORLD",
		"BN_CONNECTED",
		"BN_DISCONNECTED"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------
local function BNet_GetClientTexture(game)
	if Broker_EverythingDB[name].disableGameIcons then
		return gameShortcut[game]
	else
		local icon = _BNet_GetClientTexture(game)
		return format("|T%s:%s|t",icon,gameIconPos[game])
	end
end

local function miscData()
	misc.server = GetRealmName()
	misc.factionE, misc.factionL = UnitFactionGroup("player")
end

local function checkFriends()
	friends.sum, friends.on = GetNumFriends()
	lists.friends = {}
	if friends.sum ~= 0 then
		for i = 1, friends.sum do
			local toonName, level, class, area, connected, status, note = GetFriendInfo(i)

			local status_text, status_color = "",""
			if isAFK == true then
				status_text,status_color = "[AFK]","gold"
			elseif isDND == true then 
				status_text,status_color = "[DND]","ltred"
			end

			if toonName == nil or (not toonName) then
				toonName = "unknown"..i
			end

			if type(connected)~="boolean" then
				connected = (connected==1)
			end

			lists.friends[toonName] = {
				["battleNet"] = false,
				["status_text"] = status_text,
				["status_color"] = status_color,
				["game"] = BNet_GetClientTexture(BNET_CLIENT_WOW),
				["faction"] = misc.factionL or misc.factionE,
				["realm"] = misc.server,
				["class"] = class:upper(),
				["zone"]  = area,
				["level"] = level,
				["notes"] = note or " ",
				["online"] = connected,
			}

		end
	end
end

local function checkBnetFriends()
	if BNConnected() then
		bnetfriends.off = false
	else
		bnetfriends.off = true
		return
	end

	bnetfriends.sum, bnetfriends.on = BNGetNumFriends()

	lists.bnetfriends = {}
	for i = 1, bnetfriends.sum do
		local presenceID, presenceName, battleTag, _, toonName, _, game, isOnline, lastOnline, isAFK, isDND, broadcastText, noteText, isRealID, broadcastTime, canSoR = BNGetFriendInfo(i)
		local realmName, faction, race, class, guild, zoneName, level, gameText = "", "", "", "", "", "", "", ""
		local status_text, status_color = "",""
		if presenceID then
			local _, _, _, realmName, _, faction, race, class, guild, zoneName, level, gameText, _, _, _, _ = BNGetToonInfo(presenceID)
			status_text, status_color = "",""
			if isAFK == true then
				status_text,status_color = "[AFK]","gold"
			elseif isDND == true then 
				status_text,status_color = "[DND]","ltred"
			end
		end
		if toonName == nil or (not toonName) then
			toonName = presenceName
		end
		lists.bnetfriends[toonName] = {
			["presenceName"] = presenceName,
			["battleTag"]    = battleTag,
			["status_text"]  = status_text,
			["status_color"] = status_color,
			["game"]         = BNet_GetClientTexture(game),
			["realm"]        = realmName,
			["faction"]      = L[faction],
			["class"]        = class:upper(),
			["zone"]         = zoneName,
			["level"]        = level,
			["notes"]        = noteText or "",
			["online"]       = isOnline,
			["bcText"]       = broadcastText,
			["bcTime"]       = broadcastTime
		}
	end
end

local function checkGuild()
	if (not IsInGuild()) then guild.no = true return end
	guild.sum, guild.on = GetNumGuildMembers()
	guild.officer = CanViewOfficerNote()
	lists.guild = {}
end

local function friendsTooltip(tooltip,merge)
	if (not lists.friends) or lists.friends == nil or friends.sum==0 then return end
	local offliner = Broker_EverythingDB[name].friendsOffliner
	for toonName,data in pairs(lists.friends) do
		if data.online or (offliner and (not data.online) ) then
			local _status=""
			if data.status_text~="" then
				_status = C(data.status_color,data.status_text)
			elseif not data.online then
				_status = C("gray","[OFF]")
			end
			tooltip:AddLine(
				data.level or "-",
				_status..C(data.class,toonName),
				" ",
				data.zone,
				data.notes,
				data.game .." ".. data.realm
			)
		end
	end
end

local function bnetfriendsTooltip(tooltip,merge)
	if (not lists.bnetfriends) or lists.bnetfriends == nil or bnetfriends.sum==0 then return end

	local offliner = Broker_EverythingDB[name].bnetOffliner
	for toonName, data in pairs(lists.bnetfriends) do
		if data.online or (offliner and (not data.online) ) then
			local _status=""
			if data.status_text~="" then
				_status = C(data.status_color,data.status_text)
			elseif not data.online then
				_status = C("gray","[OFF]")
			end
			if (not data.online) and toonName == data.presenceName then
				toonName = ""
			end
			tooltip:AddLine(
				data.level,
				_status..C(data.class,toonName),
				data.presenceName,
				data.zone,
				data.notes,
				data.game .." ".. data.realm
			)
		end
	end
end

local function guildTooltip(tooltip,merge)
	if (not lists.guild) or lists.guild == nil or guild.sum==0 then return end

	local offliner = Broker_EverythingDB[name].guildOffliner
	for toonName,data in pairs(lists.guild) do
	end
end

--Social
--RIGHT, LEFT,   LEFT, LEFT,   LEFT,       LEFT
--Level, Char,   Rank, Zone, Notes+,      Prof.
--Level, Char,   Rank, Zone, Notes+,      Prof.
--Level, Char, RealID, Zone, Notes+, Game+Realm
local function mergedTooltip(tooltip)
	local cHead = "ltyellow"
	tooltip:AddHeader(L[name])
	tooltip:AddSeparator(1,0,0,0,0)
	tooltip:AddLine(
		C(cHead,"|n"..L["Level"]),
		C(cHead,"|n"..L["Name"]),
		C(cHead,("%s /|n%s"):format(L["Guild rank"],L["RealName"])),
		C(cHead,"|n"..L["Zone"]),
		C(cHead,"|n"..L["Notes"]),
		C(cHead,("%s /|n%s+%s"):format(L["Professions"],L["Game"],L["Realm"]))
	)
	tooltip:AddSeparator()
	if not guild.no then
		guildTooltip(tooltip,true)
	end
	bnetfriendsTooltip(tooltip,true)
	friendsTooltip(tooltip,true)
end

local function updateBroker(self)
	if not self then self = {} end
	local obj = self.obj or ns.LDB:GetDataObjectByName(name)
	local text = {form:format(friends.on,friends.sum)}
	if bnetfriends.off then
		text[2] = C("red","?/?")
	else
		text[2] = C("ltblue",form:format(bnetfriends.on,bnetfriends.sum))
	end
	if guild.no == false then
		text[3] = C("green",form:format(guild.on,guild.sum))
	end
	obj.text = table.concat(text," ")
end

------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
	local cfg = Broker_EverythingDB[name]
	if cfg.shortTooltip == nil then
		cfg.shortTooltip = false
	end
	if cfg.disableGameIcons == nil then
		cfg.disableGameIcons = false
	end
	if cfg.splitFriendsInBroker == nil then
		cfg.splitFriendsInBroker = true
	end
	if cfg.viewMobileChatter == nil then
		cfg.viewMobileChatter = true
	end
	if cfg.bnetOffliner == nil then
		cfg.bnetOffliner = false
	end
	if cfg.friendsOffliner == nil then
		cfg.friendsOffliner = false
	end
	if cfg.guildOffliner == nil then
		cfg.guildOffliner = false
	end
	miscData()
end

ns.modules[name].onevent = function(self,event,msg,...)
	if event=="PLAYER_ENTERING_WORLD" then
		checkFriends()
		checkBnetFriends()
		checkGuild()
		updateBroker(self)
		return
	end

	if event=="BN_FRIEND_ACCOUNT_OFFLINE" or event=="BN_FRIEND_ACCOUNT_ONLINE" or event=="BN_CONNECTED" or event=="BN_DISCONNECTED" then
		checkBnetFriends()
		updateBroker(self)
		return
	end

	if event=="FRIENDLIST_UPDATE" then
		checkFriends()
		updateBroker(self)
		return
	end

	if event=="GUILD_ROSTER_UPDATE" or event=="GUILD_XP_UPDATE" then
		checkGuild()
		updateBroker(self)
		return
	end

end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].ontooltip = function(tooltip) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self)
	tooltip = ns.LQT:Acquire(name.."TT", 6 , "RIGHT", "LEFT", "LEFT", "LEFT", "LEFT", "LEFT")
	tooltip:Clear()
	mergedTooltip(tooltip)
	ns.createTooltip(self,tooltip)
end

ns.modules[name].onleave = function(self)
	if tooltip then
		if MouseIsOver(tooltip) then
			tooltip:SetScript('OnLeave', ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]



-- onenter
	--self:EnableMouseWheel(1) 
	--self:SetScript("OnMouseWheel", OnMouseWheel)
