
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "framenames"
local tooltip = nil
local string = string


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Broker to show names of frames under the mouse."],
	icon = "Interface\\Addons\\"..addon.."\\media\\equip",
	enabled = false,
	events = {},
	updateinterval = false, -- 10
	config = nil
}


--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------

ns.modules[name].init = function(self)
	if self then
		local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)
		dataobj.text = L[name]
	end
end


--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

ns.modules[name].onupdate = function(self)
	local dataobj = self.obj or ns.LDB:GetDataObjectByName(name)
	local f = GetMouseFocus()
	if (not f) then
		if dataobj.text~=L["Unknown"] then
			dataobj.text = L["Unknown"]
		end
	else
		f = f:GetName()
		if f == nil then f = "nil" end
		if dataobj.text ~= f then
			dataobj.text = f
		end
	end
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].ontooltip = function(tooltip) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
ns.modules[name].onenter = function(self) end -- prevent displaying tooltip

--[[ ns.modules[name].onleave = function(self) end ]]

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]

