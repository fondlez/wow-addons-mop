
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name0 = "Time manager / clock / calendar"
local name1 = "Time manager"
local name2 = "Clock"
local name3 = "Calendar"
local GetGameTime = GetGameTime


---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	noBroker = true,
	desc = false,
	icon = false,
	events = {
		"CALENDAR_UPDATE_PENDING_INVITES",
		"PLAYER_LOGIN",
		"PLAYER_ENTERING_WORLD"
	},
	updateinterval = 5,
	config = {
		height = 52,
		elements = {
			{
				type = "check",
				name = "format24",
				label = L["24 Hour Time"],
				desc = L["Enable to display the time in 24 hour format; Disable to show as AM/PM"],
			},
			{
				type = "check",
				name = "clockLocal",
				label = L["Show Local Time"],
				desc = L["Enable to display the local time. Disable to show the realm time."],
				points = {
					edgeSelf = "TOPLEFT",
					edgeSibling = "TOPRIGHT",
					x = 130,
					y = 0
				}
			}
		}
	}
}

ns.modules[name1] = {
	desc = L[""],
	icon = "",
	events = {},
	updateinterval = nil, -- 10
	config = nil -- {}
}
ns.modules[name2] = {
	desc = L["Broker to show realm or local time."],
	icon = "Interface\\Addons\\"..addon.."\\media\\clock",
	events = {},
	updateinterval = nil, -- 10
	config = nil -- {}
}
ns.modules[name3] = {
	desc = L["Broker to show if you have any current invitations."],
	icon = "Interface\\Addons\\"..addon.."\\media\\calendar",
	events = {},
	updateinterval = nil, -- 10
	config = nil -- {}
}


--------------------------
-- some local functions --
--------------------------
local function formatTime(h,m)
	local a = "AM"
	if (not Broker_EverythingDB[name0].format24) then
		if h >= 12 then h, a = h - 12, "PM" end
		if h == 0 then h = 12 then
		return string.format("%02d:%02d %s", h, m, a)
	end
	return string.format("%02d:%0d2", h, m)
end


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name0].init = function(obj)
	if Broker_EverythingDB[name].format24 == nil then
		Broker_EverythingDB[name].format24 = true
	end
	if Broker_EverythingDB[name].timeLocal == nil then
		Broker_EverythingDB[name].timeLocal = true
	end
	GameTimeFrame:Hide()
	GameTimeFrame.Show = dummyFunc
end

--[[ ns.modules[name].onevent = function(self,event,msg) end ]]

ns.modules[name0].onupdate = function(self)
	-- clock
	local h, m, obj1, obj2, obj3
	if Broker_EverythingDB[name1].enabled then
		obj1 = self.obj or ns.LDB:GetDataObjectByName(name1)
	end
	if Broker_EverythingDB[name2].enabled then
		obj2 = self.obj or ns.LDB:GetDataObjectByName(name2)
	end
	if Broker_EverythingDB[name3].enabled then
		obj3 = self.obj or ns.LDB:GetDataObjectByName(name3)
	end
	
	if Broker_EverythingDB[name].timeLocal == false then
		h, m = GetGameTime()
	else
		h, m = date("%H"), date("%M")
	end

	self.obj.text = formatTime(h, m)
end

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

ns.modules[name2].ontooltip = function(tooltip)
	local h, m = GetGameTime()

	tooltip:AddLine(L[name])
	tooltip:AddLine(" ")
	tooltip:AddDoubleLine(C("white",L["Server Time"]), C("white",formatTime(h, m)))
	tooltip:AddDoubleLine(C("white",L["Local Time"]), C("white",formatTime(date("%H"),date("%M"))))

	if Broker_EverythingDB.showHints then
		tooltip:AddLine(" ")
		tooltip:AddLine(C("copper",L["Left-click"]).." "..C("green",L["to open the Time manager."]))
		tooltip:AddLine(C("copper",L["Right-click"]).." "..C("green",L["to switch between local and server time."]))
		tooltip:AddLine(C("copper",L["Shift + Right-click"]).." "..C("green",L["to open calendar."]))
		tooltip:AddLine(C("copper",L["Shift + Left-click"]).." "..C("green",L["to switch between 12 & 24 hour time."]))
	end
end


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]


ns.modules[name2].onclick = function(self,button)
	local shift = IsShiftKeyDown()
	if button == "RightButton" and not shift then
		if Broker_EverythingDB[name].timeLocal == true then
			Broker_EverythingDB[name].timeLocal = false
		else
			Broker_EverythingDB[name].timeLocal = true
		end
		ns.modules[name].onupdate(self)
	elseif button == "RightButton" and shift then
		ToggleCalendar()
	elseif button == "LeftButton" and shift then 
		if Broker_EverythingDB[name].format24 == true then
			Broker_EverythingDB[name].format24 = false
		else
			Broker_EverythingDB[name].format24 = true
		end
		ns.modules[name].onupdate(self)
	else
		ToggleTimeManager()
	end
end


--[[ ns.modules[name].ondblclick = function(self,button) end ]]



-- onenter
	--self:EnableMouseWheel(1) 
	--self:SetScript("OnMouseWheel", OnMouseWheel)
