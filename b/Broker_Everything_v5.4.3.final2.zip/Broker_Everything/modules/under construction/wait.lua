
----------------------------------
-- module independent variables --
----------------------------------
local addon, ns = ...
local C, L = ns.color, ns.L


-----------------------------------------------------------
-- module own local variables and local cached functions --
-----------------------------------------------------------
local name = "Wait"
local media = "Interface\\Addons\\"..addon.."\\media\\"
local icons = {
	off = media.."",
	pvp = media.."",
	rg = media.."",
	both = media..""
}
local queues = {
	Raid=false,
	Group=false,
	PvP=false
}

---------------------------------------
-- module variables for registration --
---------------------------------------
ns.modules[name] = {
	desc = L["Display informations about the usage of group, raid and battlefield finder..."],
	icon = icons.off,
	events = {
		"LFG_UPDATE",
		"LFG_QUEUE_STATUS_UPDATE",
		"LFG_PROPOSAL_UPDATE",
		"LFG_PROPOSAL_SUCCEEDED",
		"PARTY_MEMBERS_CHANGED",
--		"UPDATE_BATTLEFIELD_STATUS"
	},
	updateinterval = nil, -- 10
	config = nil -- {}
}



--------------------------
-- some local functions --
--------------------------


------------------------------------
-- module (BE internal) functions --
------------------------------------
ns.modules[name].init = function(obj)
--	if Broker_EverythingDB[name].showNumbers == nil then
--		Broker_EveryThingDB[name].showNumbers = true
--	end
end

ns.modules[name].onevent = function(self,event,msg)
	if event == "UPDATE_BATTLEFIELD_STATUS" then
		
	else
		local mode, submode = GetLFGMode()

--		if not submode then submode = "nil" end

		if not mode or mode == "abandonedInDungeon" then
			-- nothing
		elseif mode == "lfgparty" then
			-- wait for queue
		elseif mode == "proposal" then
			-- ready check
		elseif mode == "queued" then
			-- in queue
			local hasData, leaderNeeds, tankNeeds, healerNeeds, dpsNeeds, instanceType, instanceName, averageWait, tankWait, healerWait, damageWait, myWait, queuedTime = GetLFGQueueStats()
			if queue[1] then
				
			else
				
			end
		end
	end
end

--[[ ns.modules[name].onupdate = function(self) end ]]

--[[ ns.modules[name].optionspanel = function(panel) end ]]

--[[ ns.modules[name].onmousewheel = function(self,direction) end ]]

--[[ ns.modules[name].ontooltip = function(tooltip) end ]]


-------------------------------------------
-- module functions for LDB registration --
-------------------------------------------
--[[ ns.modules[name].onenter = function(self) end ]]

--[[ ns.modules[name].onleave = function(self) end ]]

--[[ ns.modules[name].onclick = function(self,button) end ]]

--[[ ns.modules[name].ondblclick = function(self,button) end ]]



-- onenter
	--self:EnableMouseWheel(1) 
	--self:SetScript("OnMouseWheel", OnMouseWheel)
