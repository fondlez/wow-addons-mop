local addon, ns = ...

-- ------------------------------- --
-- modules table and init function --
-- ~Hizuro                         --
-- ------------------------------- --
ns.modules = {}
ns.updateList = {}

ns.moduleInit = function(name,data)
	if data==nil and ns.modules[name]~=nil then
		data = ns.modules[name]
	end

	if data==nil then return end

	if data.onupdate then
		ns.updateList[name] = {
			firstUpdate = false,
			func = data.onupdate,
			interval = data.updateinterval
		}
	end
	
	-- pre LDB init
	if data.init then
		data.init()
	end

	if not data.noBroker then

		if (not data.onenter) and data.ontooltip then
			data.ontooltipshow = data.ontooltip
		end

		data.obj = ns.LDB:NewDataObject(name, {
			-- button data
			type          = "data source",
			label         = data.label,
			icon          = data.icon,
			staticIcon    = data.icon,
			iconCoords    = data.iconCoords or {0.05, 0.95, 0.05, 0.95},
			-- button event functions
			OnEnter       = data.onenter or nil,
			OnLeave       = data.onleave or nil,
			OnClick       = data.onclick or nil,
			OnDoubleClick = data.ondblclick or nil,
			OnTooltipShow = data.ontooltipshow or nil
		})
	end

	-- event handler registration
	if data.onevent then
		data.event = CreateFrame("frame")
		for _, e in pairs(data.events) do
			data.event:RegisterEvent(e)
		end
		data.event:SetScript("OnEvent",data.onevent)
	end

	-- post LDB init
	if data.init then
		data.init(data)
	end
end

