
-- ====================================== --
-- Shared Functions for Broker_Everything --
-- ====================================== --

local addon, ns = ...
local upper,format,type = upper,format,type
local GetPlayerMapPosition,GetRealZoneText,GetSubZoneText = GetPlayerMapPosition,GetRealZoneText,GetSubZoneText
local GetZonePVPInfo,GetBindLocation = GetZonePVPInfo,GetBindLocation
local L = ns.L
local _

ns.LDB = LibStub("LibDataBroker-1.1")
ns.LQT = LibStub("LibQTip-1.0")
--ns.LSO = LibStub("LibSimpleOptions-1.0")
ns.LSO = LibStub("LibSimpleOptions-1.0-be_mod")

-- ---------------------------------- --
-- realm dependent data and functions --
-- ~Hizuro                            --
-- ---------------------------------- --
ns.realm = GetRealmName()

-- ----------------------------------- --
-- player dependent data and functions --
-- ~Hizuro                             --
-- ----------------------------------- --
ns.player = {}
ns.player.name = UnitName("player")
_, ns.player.class = UnitClass("player")
ns.player.faction = select(1,UnitFactionGroup("player"))

-- -------------------------- --
-- nice little print function --
-- ~Hizuro                    --
-- -------------------------- --
ns.Print = function (msgType, ...)
	print("|cFFFF3333"..addon..":|r|cFF00FF00 ", msgType, ":|r ", ...)
end

-- ----------------------------------- --
-- Helpful function for extra tooltips --
-- ----------------------------------- --

ns.onleaveTooltip = function(tooltip)
	if tooltip.tooltip then
		tooltip = tooltip.tooltip
	end
	if tooltip then
		if MouseIsOver(tooltip) then
			tooltip:SetScript("OnLeave", ns.hideTooltip)
		else
			ns.hideTooltip(tooltip)
		end
	end
end

ns.createTooltip = function(frame, tooltip)
	if Broker_EverythingDB.tooltipScale == false then 
		tooltip:SetScale(1)
	else 
		tooltip:SetScale(tonumber(GetCVar("uiScale")))
	end
	if frame then
		tooltip:SmartAnchorTo(frame)
	end
	tooltip:SetScript("OnLeave",ns.onleaveTooltip)
	tooltip:UpdateScrolling()
	tooltip:Show()
end

ns.advHideTooltip = function(tooltip)
	tooltip:SetScript("OnUpdate",function(self)
		if GetMouseFocus()=="worldFrame" then
			ns.LQT:Release(tooltip)
			tooltip = nil
		end
	end)
end

ns.hideTooltip = function(tooltip)
	if MouseIsOver(tooltip) then return end
	tooltip:SetScript('OnLeave', nil)
	ns.LQT:Release(tooltip)
	tooltip = nil
end

ns.onleaveButton = function(self)
	if self.tooltip then
		if MouseIsOver(self.tooltip) then return end
		ns.hideTooltip(self.tooltip)
	end
end

ns.onenterRegMouseWheel = function(self,func)
	self:EnableMouseWheel(1) 
	self:SetScript("OnMouseWheel", func)
end

-- ---------------------- --
-- text coloring function --
-- ---------------------- --

-- -------------------------------------------------- --
-- a collection of color names and codes and a single --
-- function to return a text with a colorcode         --
-- ~Hizuro                                            --
-- -------------------------------------------------- --
--[[
	usage: ns.color2( <color> [, <string>] )
	<color> can be:
		colornames like red, green or so.
		colorcode like ffffff (google: html color hex)
		classnames like mage. localized or english. this function can both.

	if string nil this fucuntion
]]

do 
	local CbyN = { -- colors by names
		["yellow"]		= "ffffff00",
		["ltyellow"]	= "fffff569",
		["dkyellow"]	= "ffffcc00",
		["orange"]		= "ffff7d0a",
		["ltorange"]	= "ffff9d6a",
		["dkorange"]	= "ff905d0a",
		["red"]			= "ffc41f3b",
		["brtred"]		= "ffff0000", -- ?
		["ltred"]		= "ffff8080",
		["dkred"]		= "ff800000",
		["violet"]		= "fff000f0",
		["ltviolet"]	= "fff060f0",
		["dkviolet"]	= "ff800080",
		["blue"]		= "ff0000ff",
		["ltblue"]		= "ff69ccf0",
		["dkblue"]		= "ff000088",
		["cyan"]		= "ff00ffff",
		["ltcyan"]		= "ff80ffff",
		["dkcyan"]		= "ff008080",
		["green"]		= "ff00ff00",
		["ltgreen"]		= "ff80ff80",
		["dkgreen"]		= "ff00aa00",
		["gray"]		= "ff808080",
		["grey"]		= "ff808080",
		["white"]		= "ffffffff",
		["black"]		= "ff000000",

		["gold"]		= "ffffd700",
		["silver"]		= "ffeeeeef",
		["copper"]		= "fff0a55f",

	}

	-- add class names to CbyN table plus localized names
	for n, c in pairs(CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS) do CbyN[n:lower()] = c.colorStr end
	for k, v in pairs(_G.LOCALIZED_CLASS_NAMES_MALE) do CbyN[v:lower()] = CbyN[k:lower()] end
	for k, v in pairs(_G.LOCALIZED_CLASS_NAMES_FEMALE) do CbyN[v:lower()] = CbyN[k:lower()] end

	ns.color = function(color, str)
		assert( type(color)=="string", "argument #1 must be a string. ("..type(color).." given)")
		color = color:lower()

		if color=="suffix" and Broker_EverythingDB.suffixColour then
			color = ns.player.class:lower()
		end

		if CbyN[color] then
			color = CbyN[color]
		elseif string.match(color, "^%x$") then
			if color:len()==6 then
				color = "ff"..color
			end
		else
			color = "ffffffff"
		end

		if not str then
			return color
		else
			return string.format("|c%s%s|r",color, str)
		end
	end
end

-- -------------------------------------------------- --
-- Function to Sort a table by the keys               --
-- Sort function fom http://www.lua.org/pil/19.3.html --
-- -------------------------------------------------- --
ns.pairsByKeys = function(t, f)
	local a = {}
	for n in pairs(t) do
		table.insert(a, n)
	end
	table.sort(a, f)
	local i = 0      -- iterator variable
	local iter = function ()   -- iterator function
		i = i + 1
		if a[i] == nil then
			return nil
		else
			return a[i], t[a[i]]
		end
	end
	return iter
end

-- ---------------------------------------- --
-- Function to append an element to a table --
-- and optional limit his max entries       --
-- ~Hizuro                                  --
-- ---------------------------------------- --
ns.insertAppend = function(old_table,elem,max_entries)
	local new = {elem}
	for _, e in pairs(old_table) do
		new[#new] = e
		if max_entries ~= nil and #new == max_entries then return new end
	end
	return new
end

-- -------------------------------------------------------------- --
-- Function to split a string                                     --
-- http://stackoverflow.com/questions/1426954/split-string-in-lua --
-- Because mucking around with strings makes my head hurt.        --
-- -------------------------------------------------------------- --
ns.splitText = function(inputstr, sep)
	if sep == nil then
		sep = "%s"
	end
	local t={}
	local i = 1
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		t[i] = strtrim(str) .. sep
		i=i+1
	end
	return table.concat(t, "|n")
end

ns.splitTextToHalf = function(inputstr, sep)
	local t = {}
	local i = 1
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		t[i] =strtrim(str) .. " "
		i=i+1
	end
	local h,a,b = ceil(i/2),"",""
	for i, v in pairs(t) do
		if i < h then a = a .. v else b = b .. v end
	end
	return a.."|n"..b
end

ns.split = function(iStr,splitBy,opts)
	-- escapes sollten temporär ersetzt werden...
	if splitBy=="length" then
		assert(type(opts.length)=="number","opts.length must be a number, "..type(opts.length).."given.")
	elseif splitBy=="half" then
	elseif splitBy=="sepcount" then
		assert(type(opts.count)=="number","opts.count must be a number, "..type(opts.count).."given.")
	elseif splitBy=="sep" then
		
	end
end
