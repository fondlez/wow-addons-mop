
-- some usefull namespace to locals
local addon, ns = ...
local C, L = ns.color, ns.L

--
-- Chat command handler
--

SlashCmdList["BROKER_EVERYTHING"] = function(cmd)
	local cmd, arg = strsplit(" ", cmd:lower(), 2)

	if cmd=="" then
		ns.Print(L["Info"], L["Chat command list for /be & /broker_everything"])
		ns.Print(L["Info"], "broker"     .. " - " .. L["Open the option panel - broker"])
		ns.Print(L["Info"], "options"    .. " - " .. L["Open the option panel - options"])
--		ns.Print(L["Info"], "labels"     .. " - " .. L["?"])
		ns.Print(L["Info"], "max_addons" .. " - " .. L["Change count of displayed addons in module memory."])
		ns.Print(L["Info"], "reset"      .. " - " .. L["Reset all module settings."])
		ns.Print(L["Info"], "global"     .. " - " .. L["Switch between global and per character saved settings."])
		ns.Print(L["Info"], "list"       .. " - " .. L["List of available ns.modules with his status."])
		ns.Print(L["Info"], "tooltip"    .. " - " .. L["Enable/disable tooltip scaling."])
		return
	end

	if cmd == "broker" then
		InterfaceOptionsFrame_OpenToCategory(ns.OP.brokerPanel);
		InterfaceOptionsFrame_OpenToCategory(ns.OP.brokerPanel); -- double call. Thanks blizz for ignoring direct open custom option panels on first try.
		return
	end

	if cmd == "config" or cmd == "options" then
		InterfaceOptionsFrame_OpenToCategory(ns.OP.configPanel);
		InterfaceOptionsFrame_OpenToCategory(ns.OP.configPanel); -- double call. Thanks blizz for ignoring direct open custom option panels on first try.
		return
	end

	if cmd == "labels" then
		if Broker_EverythingDB.labels == true then
			Broker_EverythingDB.labels = false
			ns.Print(L["Cfg"], L["Labels disabled after reload."])
		else
			Broker_EverythingDB.labels = true
			ns.Print(L["Cfg"], L["Labels enabled after reload."])
		end
		return
	end

	if cmd == "max_addons" then
		Broker_EverythingDB["Memory"].max_addons = tonumber(arg)
		if Broker_EverythingDB["Memory"].max_addons > 0 then
			ns.Print(L["Cfg"], L["Showing a maximum of %d addons."]:format(Broker_EverythingDB["Memory"].mem_max_addons))
		else
			ns.Print(L["Cfg"], L["Showing all addons."])
		end
		return
	end

	if cmd == "reset" then
		Broker_EverythingDB.reset = true
		ReloadUI()
	end

	if cmd == "global" then
		if not Broker_EverythingGlobalDB.global or Broker_EverythingGlobalDB.global == false then
			if Broker_EverythingGlobalDB["Clock"] == nil then
				Broker_EverythingGlobalDB = Broker_EverythingDB
			end			
			Broker_EverythingGlobalDB.global = true
		else
			Broker_EverythingGlobalDB.global = false
		end 
		ns.Print(L["Cfg"], L["Broker_Everything will use the new setting on next reload."])
	end

	if cmd == "list" then
		ns.Print(L["Cfg"], L["Data feeds:"])
		for k, v in pairs(Broker_EverythingDB) do
			if not (v == true or v == false or v == 1 or v == 0) then
				if Broker_EverythingDB[k].enabled == true then
					ns.Print(L["Cfg"],  k .. " (" .. C("green",L["Enabled"]) .. ")")
				elseif Broker_EverythingDB[k].enabled == false then
					ns.Print(L["Cfg"],  k .. " (" .. C("red",L["Disabled"]) .. ")")
				end
			end
		end
		return
	end	

	if cmd == "tooltip" then
		if Broker_EverythingDB.tooltipScale == true then
			Broker_EverythingDB.tooltipScale = false
		else
			Broker_EverythingDB.tooltipScale = true
		end
	end
	
	cmd = cmd:gsub("^%l", string.upper)
	for k, v in pairs(Broker_EverythingDB) do
		if k == cmd then
			local x = Broker_EverythingDB[cmd].enabled
			print(tostring(x))
			if x == true then
				Broker_EverythingDB[cmd].enabled = false
				print(tostring(Broker_EverythingDB[cmd].enabled))
					ns.Print(L["Cfg"], L["Disabling %s on next reload."]:format(cmd)) -- cmd
				else
					Broker_EverythingDB[cmd].enabled = true
					ns.Print(L["Cfg"], L["Enabling %s on next reload."]:format(cmd)) -- cmd
			end
		end
	end

end


SLASH_BROKER_EVERYTHING1 = "/broker_everything"
SLASH_BROKER_EVERYTHING2 = "/be"

