
--[[ core localizations and module independent localizations  ]]

-- slashcmd
L["Chat command list for /be & /broker_everything"] = ""
L["Open the option panel"] = ""
L["Change count of displayed addons in module memory."] = ""
L["Reset all module settings."] = ""
L["Switch between global and per character saved settings."] = ""
L["List of available modules with his status."] = ""
L["Enable/disable tooltip scaling."] = ""
L["Labels disabled after reload."] = ""
L["Labels enabled after reload."] = ""
L["Showing a maximum of %d addons."] = ""
L["Showing all addons."] = ""
L["Broker_Everything will use the new setting on next reload."] = ""
L["Disabling %s on next reload."] = ""
L["Enabling %s on next reload."] = ""

-- option panels
L["Select the listed broker to enable/disable. You must Reload UI for any changes to apply."] = ""
L["Reloads the UI. You must do this to apply any changes in module activation."] = ""
L["Allows you to adjust the display options."] = ""
L["General Options"] = ""
L["Resets the Broker_Everything Defaults and Reloads the UI."] = ""
L["Suffix Colouring"] = ""
L["Enable/Disable Class colouring of the information display suffixes. (eg, ms, fps etc)"] = ""
L["Show Broker Labels"] = ""
L["Enable/Disable the showing of the data broker labels."] = ""
L["Use global profile"] = ""
L["Enable/Disable the showing of a global Broker_Everything profile across all of your characters."] = ""
L["Tooltip Scaling"] = ""
L["Scale the tooltips with your UIScale. Default is off"] = ""
L["Module Options"] = ""
L["saved variables have been reset. Sorry for the inconvenience!"] = ""
L["Select none"] = ""
L["Remove all selections from modules"] = ""
L["Select all"] = ""
L["Select all modules"] = ""


-- misc
L["Hint:"] = ""
L["Addon"] = ""
L["All"] = ""
L["BattleTag"] = ""
L["Cfg"] = ""
L["Character"] = ""
L["Disable"] = ""
L["Disabled"] = ""
L["Disabling"] = ""
L["Enable"] = ""
L["Enabled"] = ""
L["Enabling"] = ""
L["Enemy"] = ""
L["Exalted"] = ""
L["Faction"] = ""
L["Friend"] = ""
L["Friendly"] = ""
L["Game"] = ""
L["Hidden"] = ""
L["Home"] = ""
L["Honoured"] = ""
L["Info"] = ""
L["Inn"] = ""
L["Level"] = ""
L["Logout"] = ""
L["Neutral"] = ""
L["None"] = ""
L["Notes"] = ""
L["Online"] = ""
L["Options"] = ""
L["PVP Flag"] = ""
L["Quit Game"] = ""
L["Rank"] = ""
L["Real ID"] = ""
L["Realm"] = ""
L["Reload UI"] = ""
L["Reset"] = ""
L["Revered"] = ""
L["Shown"] = ""
L["Sub-Zone"] = ""
L["Warning"] = ""
L["World"] = ""
L["Zone"] = ""


--[[ modules localizations only ]]

-- module: bags
L["Bags"] = ""
L["Broker to show total, free and filled amount of bag space."] = ""
L["Free slots remaining"] = ""
L["Total Bag slots"] = ""
L["Left-click to open bags."] = ""
L["Right-click to switch display mode."] = ""


-- module: calendar
L["Calendar"] = ""
L["Broker to show if you have any current invitations."] = ""
L["Pending Invites"] = ""
L["No Invites"] = ""
L["There are no pending Invitations."] = ""
L["invitations"] = ""
L["Left-click to open the calendar."] = ""


-- module: clock
L["Clock"] = ""
L["Broker to show realm or local time."] = ""
L["Server Time"] = ""
L["Local Time"] = ""
L["Left-click to open the Time manager."] = ""
L["Right-click to switch between local and server time."] = ""
L["Shift + Right-click to open calendar."] = ""
L["Shift + Left-click to switch between 12 & 24 hour time."] = ""
L["24 Hour Time"] = ""
L["Enable to display the time in 24 hour format; Disable to show as AM/PM"] = ""
L["Show Local Time"] = ""
L["Enable to display the local time. Disable to show the realm time."] = ""


-- module: currency
L["Currency"] = ""
L["Broker to show if you the amount of different currencies."] = ""
L["To view or remove a currency in title use:"] = ""
L["Left-Click (1), Shift-Left-Click (3)"] = ""
L["Right-Click (2), Shift-Right-Click (4)"] = ""


-- module: dualspec
L["Dualspec"] = ""
L["Broker to show your currently selected spec. If you have a second spec, it is shown in the tool tip, and can be swapped to using this broker."] = ""
L["Talents"] = ""
L["You have not trained a specialisation."] = ""
L["Left-click to show the talents pane."] = ""
L["Right-click to switch talents."] = ""


-- module: durability
L["Durability"] = ""
L["Broker to show durability of your gear and estimated repair total."] = ""
L["Repair Cost"] = ""
L["Reputation discounts"] = ""
L["Left-click to show character info."] = ""


-- module: equipment
L["Equipment"] = ""
L["Broker to show your Equipment Sets. Also allows deleting, equiping and saving of sets."] = ""
L["Unknown Equipment Set"] = ""
L["Equipment Manager is not enabled."] = ""
L["Enable Equipment Manager from the Character pane."] = ""
L["You do not have any Equipment Sets."] = ""
L["Click here to open Equipment Manager."] = ""
L["Click to equip a set."] = ""
L["Shift-Click to update or save a set."] = ""
L["Cntrl-Click to delete a set"] = ""


-- module: fps
L["FPS"] = ""
L["Broker to show your frames per second."] = ""


-- module: friends
L["Friends"] = ""
L["Broker to show you which friends are online."] = ""
L["No Friends Online."] = ""
L["Left-click to open the friends roster."] = ""
L["Click a friend to whisper."] = ""
L["Alt + Click a friend to invite."] = ""
L["Alliance"] = "Allianz" -- workaround for missing localizated faction string from BNetToonInfo()
L["Horde"] = "" -- workaround for missing localizated faction string from BNetToonInfo()


-- module: gold
L["Gold"] = ""
L["Broker to show gold information. Shows gold amounts for characters on the same realm and faction and the amount made or lost for the session."] = ""
L["Gold Information"] = ""
L["Total Gold on"] = ""
L["Total Gold"] = ""
L["Session Statistics"] = ""
L["Starting Amount"] = ""
L["Current Amount"] = ""
L["Profit / Loss this session"] = ""
L["Left-click to show the currency tab."] = ""
L["Shift-Click to remove entry."] = ""


-- module: gps
L["GPS"] = ""
L["Broker to show the name of the current Zone and the co-ordinates."] = ""
L["Location Information"] = ""
L["Co-ordinates"] = ""
L["Click to open the World Map."] = ""


-- module: guild
L["Guild"] = ""
L["Broker to show guild information. Guild members currently online, MOTD, guild xp etc."] = ""
L["No Guild"] = ""
L["has come online"] = ""
L["has gone offline"] = ""
L["No Guild"] = ""
L["Message of the Day"] = ""
L["Officer's Notes"] = ""
L["Left-click icon to open the guild roster."] = ""
L["Click guild member to whisper."] = ""
L["Alt + Click guild member to invite."] = ""
L["Right-click to hide/show the guild xp details."] = ""
L["Show Guild XP"] = ""
L["Enable/Disable the display of Guild XP in the Guild data broker tooltip."] = ""


-- module: latency
L["Latency"] = ""
L["Broker to show your current latency. Can be configured to show both Home and/or World latency."] = ""
L["Right-click to toggle class coloring of the suffix."] = ""
L["Alt + Right-click to toggle showing Home Latency."] = ""
L["Cntrl + Right-click to toggle showing World Latency."] = ""
L["show home"] = ""
L["Enable/Disable the display of the latency to the home realm"] = ""
L["show world"] = ""
L["Enable/Disable the display of the latency to the world realms"] = ""


-- module: location
L["Location"] = ""
L["Broker to show your current co-ordinates within the zone."] = ""
L["Location Information"] = ""
L["Click to open the World Map."] = ""


-- module: mail
L["Mail"] = ""
L["Broker to alert you if you have mail."] = ""
L["New Mail"] = ""
L["No Mail"] = ""
L["Mail From"] = ""
L["Play sound on new mail"] = ""
L["Enable to play a sound on receiving a new mail message. Default is off"] = ""


-- module: mem
L["Memory"] = ""
L["Broker to show you your addon memory usage."] = ""
L["Collecting Garbage..."] = ""
L["No addon manager found. Tried OptionHouse, ACP, stAddonManager and Ampere."] = ""
L["Showing top"] = ""
L["Memory Usage"] = ""
L["Total Memory in use by Addons"] = ""
L["Left-click to open interface options."] = ""
L["Right-click to open"] = ""
L["Shift + Right-click to collect garbage."] = ""
L["Select the maximum number of addons to display, otherwise drag to 'All'."] = ""


-- module: nameplates
L["Nameplates"] = ""
L["Broker to allow you to toggle the various nameplates. Eg, friendly or hostile."] = ""
L["Friendly Players"] = ""
L["Friendly Pets"] = ""
L["Friendly Creations"] = ""
L["Friendly Everyone"] = ""
L["Hostile Players"] = ""
L["Hostile Pets"] = ""
L["Hostile Creations"] = ""
L["Hostile Everyone"] = ""
L["Companion Names"] = ""
L["Your Own Name"] = ""
L["Player Titles"] = ""
L["Guild Names"] = ""
L["NPC Names"] = ""
L["Current Status"] = ""
L["Click on an option to toggle the Nameplates on or off."] = ""


-- module: stuff
L["Stuff"] = ""
L["Broker to allow you to do...Stuff! Switch to windowed mode, reload ui, logout and quit."] = ""
L["Are you sure you want to Reload the UI?"] = ""
L["Toggle Windowed Mode"] = ""
L["Shift + Left-click to switch between windowed and fullscreen mode."] = ""
L["Shift + Right-click to reload UI."] = ""
L["Left-click to logout."] = ""
L["Right-click to quit WoW."] = ""
L["You have to do the same click TWICE for anything to happen!"] = ""
L["Left-click to logout."] = ""
L["Right-click to quit WoW."] = ""
L["Shift + Left-click to switch between windowed and fullscreen mode."] = ""
L["Shift + Right-click to reload UI."] = ""


-- module: tracking
L["Tracking"] = ""
L["Broker to show what you are currently tracking. You can also change the tracking types from this broker."] = ""
L["No tracking currently active."] = ""
L["Left click to choose tracking skill."] = ""


-- module: xp
L["XP"] = ""
L["Broker to show your xp. Can be shown either as a percentage, or as values."] = ""
L["Til Next Level"] = ""
L["Rest"] = ""
L["Right-click to switch display mode."] = ""
L["Display XP as Absolute Value"] = ""
L["Select to show XP as an absolute value; Deselected will show it as a percentage."] = ""


-- module: zonetext
L["ZoneText"] = ""
L["Broker to show the name of the current zone."] = ""
L["Location Information"] = ""
L["Click to open the World Map."] = ""

