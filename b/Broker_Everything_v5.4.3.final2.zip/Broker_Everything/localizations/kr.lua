local _, ns = ...
local L = ns.L
if ns.LOCALE == "koKR" then
	-- Korean translations go here
	L["Hello!"] = "?????!"
end
