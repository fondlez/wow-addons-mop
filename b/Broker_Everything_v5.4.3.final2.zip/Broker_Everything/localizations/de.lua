local _, ns = ...
local L = ns.L

if ns.LOCALE == "deDE" then
	L["Hello!"] = "Hallo!"

--[[ core localizations and module independent localizations  ]]

	-- slashcmd
	L["Chat command list for /be & /broker_everything"] = "Chat Befehlesliste für /be & /broker_everything"
	L["Open the option panel"] = "Öffnet das Fenster Interface"
	L["Change count of displayed addons in module memory."] = "Ändert die Anzahl anzuzeigender Addons im Modul Speicher."
	L["Reset all module settings."] = "Setzt alle Moduleinstellungen."
	L["Switch between global and per character saved settings."] = "Wechselt zwischen globalen und pro Charakter gespeicherten Einstellen."
	L["List of available modules with his status."] = "Liste zur Verfügung stehender Module mit ihrem Status."
	L["Enable/disable tooltip scaling."] = "Aktiviere/Deaktiviere Skalierung des Tooltips."
--	L["Labels disabled after reload."] = ""
--	L["Labels enabled after reload."] = ""
	L["Showing a maximum of %d addons."] = "Zeigt maximal %d Addons."
	L["Showing all addons."] = "Zeigt alle Addons."
	L["Broker_Everything will use the new setting on next reload."] = "Broker_Everything wird die neuen Einstellungen nach dem nächsten Neuladen nutzen."
	L["Disabling %s on next reload."] = "Deaktiviere %s nach dem nächsten Neuladen."
	L["Enabling %s on next reload."] = "Aktiviere %s nach dem nächsten Neuladen."

	-- optionspanel
	L["Select the listed broker to enable/disable. You must Reload UI for any changes to apply."] = "Wähle die gelisteten Broker zu aktivieren/deaktieren aus. Du musst zum übernehmen der Anderungen das UI neuladen."
	L["Reloads the UI. You must do this to apply any changes in module activation."] = "Läd das UI neu. Du musst das machen um die Einstellen der Module zu aktivieren."
	L["Allows you to adjust the display options."] = "Erlaubt dir die Veränderung der Anzeigen Optionen."
	L["General Options"] = "Allgemeine Optionen"
	L["Resets the Broker_Everything Defaults and Reloads the UI."] = "Setzt die Einstellungen von Broker_Everything zurück und läd das UI neu."
	L["Suffix Colouring"] = "Nachsilbenfärbung"
	L["Enable/Disable Class colouring of the information display suffixes. (eg, ms, fps etc)"] = "Aktiviere/Deaktiviere Nachsilbenfärbung in Klassenfarben. (eg, ms, fps etc)"
	L["Show Broker Labels"] = "Zeige Broker Name"
--	L["Enable/Disable the showing of the data broker labels."] = "Aktiviere/Deaktiviere "
	L["Use global profile"] = "Nutze globales Profil"
--	L["Enable/Disable the showing of a global Broker_Everything profile across all of your characters."] = "Aktiviere/Deaktiviere "
	L["Tooltip Scaling"] = "Tooltip Skalierung"
	L["Scale the tooltips with your UIScale. Default is off"] = "Skaliere den Tooltip mit der UI Skalierung. Standard ist Aus."
	L["Show hints"] = "Zeige Tipps"
	L["Show hints in tooltips."] = "Zeige Tipps in Tooltips an."
	L["Module Options"] = "Modul Optionen"
	L["saved variables have been reset. Sorry for the inconvenience!"] = "Die gespeicherten Daten wurden zurückgesetzt. Tut uns leid für die Unannehmlichkeiten"
	L["Select none"] = "Keines auswählen"
	L["Remove all selections from modules"] = "Entfernt Auswahl von allen Modulen"
	L["Select all"] = "Alle auswählen"
	L["Select all modules"] = "Wählt alle Module aus."

	-- misc
	L["Hint:"] = "Tipp:"
	L["Addon"] = "Addon"
	L["All"] = "Alle"
	L["Alliance"] = "Allianz" -- workaround for missing localizated faction string from BNetToonInfo() and others
	L["Horde"] = "Horde"
	L["BattleTag"] = "BattleTag"
	L["Cfg"] = "Einstellung"
	L["Character"] = "Charakter"
	L["Disable"] = "Inaktiv"
	L["Disabled"] = "Deaktiviert"
	L["Disabling"] = "Deaktivieren"
	L["Enable"] = "Aktiv"
	L["Enabled"] = "Aktiviert"
	L["Enabling"] = "Akivieren"
	L["Enemy"] = "Feind"
	L["Exalted"] = "Ehrfüchtig"
	L["Faction"] = "Fraktion"
	L["Friend"] = "Freund"
	L["Friendly"] = "Freundlich"
	L["Game"] = "Spiel"
	L["Hidden"] = "Versteckt"
	L["Home"] = "Zuhause"
	L["Honoured"] = "Wohlwollend"
	L["Info"] = "Info"
	L["Inn"] = "Gasthaus"
	L["Level"] = "Stufe"
	L["Logout"] = "Abmelden"
	L["Neutral"] = "Neutral"
	L["None"] = "Nichts"
	L["Notes"] = "Notizen"
	L["Online"] = "Online"
	L["Options"] = "Optionen"
	L["PVP Flag"] = "PVP Markierung"
	L["Quit Game"] = "Spiel verlassen"
	L["Rank"] = "Rang"
	L["Real ID"] = "Reale ID"
	L["Realm"] = "Realm"
	L["Reload UI"] = "UI Neuladen"
	L["Reset"] = "Zurücksetzen"
	L["Revered"] = "Respektvoll"
	L["Shown"] = "Gezeigt"
	L["Sub-Zone"] = "Unterzone"
	L["Warning"] = "Warnung"
	L["World"] = "Welt"
	L["Zone"] = "Gebiet"
	L["Click"] = "Klick"
	L["Left-click"] = "Links-Klick"
	L["Right-click"] = "Rechts-Klick"
	L["Shift + Click"] = "Umschalt + Klick"
	L["Shift + Left-click"] = "Umschalt + Links-Klick"
	L["Shift + Right-click"] = "Umschalt + Rechts-Klick"
	L["Ctrl + Click"] = "Strg + Klick"
	L["Ctrl + Left-click"] = "Strg + Links-Klick"
	L["Ctrl + Right-click"] = "Strg + Rechts-Klick"
	L["Alt + Click"] = "Alt + Klick"
	L["Alt + Left-click"] = "Alt + Links-Klick"
	L["Alt + Right-click"] = "Alt + Rechts-Klick"
	L["Active"] = "Aktiv"

--[[ modules localizations only ]]

	-- module: bags
	L["Bags"] = "Taschen"
	L["Broker to show total, free and filled amount of bag space."] = "Broker zur Anzeige insgesamt, freier und belegter Anzahl an Taschenplätzen."
	L["Free slots remaining"] = "Freie Plätze verfügbar"
	L["Total Bag slots"] = "Taschenplätze insgesamt"
	L["to open bags."] = "zum öffnen der Taschen."
	L["to switch display mode."] = "zum wechseln des Anzeigemodus."
	L["free"] = "frei"

	-- module: calendar
	L["Calendar"] = "Kalender"
	L["Broker to show if you have any current invitations."] = "Broker zur Anzeige aller aktuellen Einladungen."
	L["Pending Invites"] = "Ausstehende Einladungen"
	L["No Invites"] = "Keine Einladungen"
	L["There are no pending Invitations."] = "Es gibt keine ausstehenden Einladungen"
	L["invitations"] = "Einladungen"
	L["to open the calendar."] = "zum öffnen des Kalenders."


	-- module: clock
	L["Clock"] = "Uhr"
--	L["Broker to show realm or local time."] = ""
	L["Server Time"] = "Server Zeit"
	L["Local Time"] = "Lokale Zeit"
	L["to open the Time manager."] = "zum öffnen des Zeitplaners."
	L["to switch between local and server time."] = "zum wechseln zwischen Lokaler und Server Uhrzeit."
	L["to open calendar."] = "zum öffnen des Kalenders."
	L["to switch between 12 & 24 hour time."] = "um zwischen 12 und 24 Stunden zu wechseln."
	L["24 Hour Time"] = "24 Stunden Zeit"
--	L["Enable to display the time in 24 hour format; Disable to show as AM/PM"] = ""
	L["Show Local Time"] = "Zeige lokale Zeit"
--	L["Enable to display the local time. Disable to show the realm time."] = ""


	-- module: currency
	L["Currency"] = "Abzeichen"
--	L["Broker to show if you the amount of different currencies."] = ""
--	L["To view or remove a currency in title use:"] = ""
--	L["Left-Click (1), Shift-Left-Click (3)"] = ""
--	L["Right-Click (2), Shift-Right-Click (4)"] = ""


	-- module: dualspec
	L["Dualspec"] = "Duale Spezialisierung"
--	L["Broker to show your currently selected spec. If you have a second spec, it is shown in the tool tip, and can be swapped to using this broker."] = ""
	L["Talents"] = "Talente"
	L["You have not trained a specialisation."] = "Du hast keine Spezialisierung erlernt."
	L["to show the talents pane."] = "zum öffnen des Talente-Fensters."
	L["to switch talents."] = "zum wechseln des Talents."
	L["You have %d unspent talents."] = "Du hast %d unverbrauchte Talente."
	L["You have %d unspent talent."] = "Du hast %d unverbrauchtes Talent."
	L["Unspent talents: %d"] = "Unverbr. Talente: %d"


	-- module: durability
	L["Durability"] = "Haltbarkeit"
--	L["Broker to show durability of your gear and estimated repair total."] = ""
	L["Repair Cost"] = "Reparaturkosten"
	L["Reputation discounts"] = "Ruf Rabatt"
	L["to show character info."] = "zum öffnen des Charakter-Fensters."


	-- module: equipment
	L["Equipment"] = "Ausrüstung"
--	L["Broker to show your Equipment Sets. Also allows deleting, equiping and saving of sets."] = ""
	L["Unknown Set"] = "Unbek. Set"
	L["Equipment Manager is not enabled."] = "Ausrüstungsmanager ist nicht aktiv."
	L["Enable Equipment Manager from the Character pane."] = "Aktiviere Ausrüstungsmanager im Charakterfenster."
	L["You do not have any Equipment Sets."] = "Du hast keine Ausrüstungssets."
	L["here to open Equipment Manager."] = "hier zum öffnen des Ausrüstungsmanagers."
	L["to equip a set."] = "um ein Set anzuziehen."
	L["to update or save a set."] = "zum auffrischen oder speichern des Sets."
	L["to delete a set"] = "zum löschen eines Sets"
	L["No Sets found"] = "Keine Sets gef."

	-- module: fps
--	L["FPS"] = ""
	L["Broker to show your frames per second."] = "Broker zur Anzeige deiner Bilder pro Sekunden."


	-- module: friends
	L["Friends"] = "Freunde"
	L["Broker to show you which friends are online."] = "Broker zur Anzeige welche deiner Freunde online sind."
	L["No Friends Online."] = "Keine Freunde anwesend"
	L["to open the friends roster."] = "Links-Kick zum öffnen des Kontakte-Fensters."
	L["a friend to whisper."] = "einen Freund an zum flüstern."
	L["a friend to invite."] = "um einen Freund einzuladen."

	-- module: gold
--	L["Gold"] = ""
--	L["Broker to show gold information. Shows gold amounts for characters on the same realm and faction and the amount made or lost for the session."] = ""
	L["Gold Information"] = "Gold Informationen"
	L["Total Gold on"] = "Gesamtes Gold"
	L["Total Gold"] = "Gesamt Gold"
	L["Session Statistics"] = "Sitzungsstatistiken"
	L["Starting Amount"] = "Startmenge"
	L["Current Amount"] = "Aktuelle Menge"
	L["Profit / Loss this session"] = "Profit / Verlust dieser Sitzung"
	L["to show the currency tab."] = "zum öffnen des Abzeichen-Fensters."
	L["to remove entry."] = "zum enfernen des Eintrags."


	-- module: gps / location / zonetext
--	L["GPS"] = ""
	L["Location"] = "Standort"
	L["ZoneText"] = "Gebietstext"
	L["Co-ordinates"] = "Koordinaten"
	L["Location Information"] = "Standortinformationen"
--	L["Broker to show the name of the current Zone and the co-ordinates."] = ""
--	L["Broker to show your current co-ordinates within the zone."] = ""
	L["Broker to show the name of the current zone."] = "Broker zur Anzeige des aktuellen Zonennamens."
	L["to open the World Map."] = "um die Weltkarte zu öffnen."
	L["friendly"] = "Freundlich"
	L["combat"] = "Kampf"
	L["arena"] = "Arena"
	L["hostile"] = "Feindlich"
	L["contested"] = "Umkämpft"
	L["sanctuary"] = "Schutzgebiet"


	-- module: guild
	L["Guild"] = "Gilde"
--	L["Broker to show guild information. Guild members currently online, MOTD, guild xp etc."] = ""
	L["No Guild"] = "Keine Gilde"
	L["has come online"] = "ist online gekommen"
	L["has gone offline"] = "ist offline gegangen"
	L["No Guild"] = "Keine Gilde"
	L["Message of the Day"] = "Nachricht des Tages"
	L["Officer's Notes"] = "Offiziers Notizen"
	L["icon to open the guild roster."] = "auf das Symbol zum öffnen des Gildenfensters."
	L["guild member to whisper."] = "ein Gildenmitglied an zum flüstern."
	L["guild member to invite."] = "um ein Gildenmitglied einzuladen"
	L["to hide/show the guild xp details."] = "zum anzeigen/verstecken der Gildenerfahrungsdetails."
	L["Show Guild XP"] = "Zeige Gilden Erfahrung"
--	L["Enable/Disable the display of Guild XP in the Guild data broker tooltip."] = ""


	-- module: latency
	L["Latency"] = "Latenz"
--	L["Broker to show your current latency. Can be configured to show both Home and/or World latency."] = ""
	L["to toggle class coloring of the suffix."] = "zum wechseln um die Nachsilbe in Klassenfarbe zu zeigen."
	L["to toggle showing Home Latency."] = "zum anzeigen der localen Latenz"
	L["to toggle showing World Latency."] = "zum anzeigen der Welt Latenz"
	L["show home"] = "Zeige Heimat"
--	L["Enable/Disable the display of the latency to the home realm"] = ""
	L["show world"] = "Zeige Welt"
--	L["Enable/Disable the display of the latency to the world realms"] = ""




	-- module: mail
	L["Mail"] = "Post"
--	L["Broker to alert you if you have mail."] = ""
	L["New Mail"] = "Neue Post"
	L["No Mail"] = "Keine Post"
	L["Mail From"] = "Post von"
	L["Play sound on new mail"] = "Spiele Klang bei neuer Post"
	L["Enable to play a sound on receiving a new mail message. Default is off"] = "Aktiviert das abspielen eines Klangs bei empfang neuer Post. Standard ist Aus."


	-- module: mem
	L["Memory"] = "Speicher"
--	L["Broker to show you your addon memory usage."] = ""
	L["Collecting Garbage..."] = "Sammle Abfall..."
	L["No addon manager found. Tried OptionHouse, ACP, stAddonManager and Ampere."] = "Kein Addon Manager gefunden. Versuchte OptionHouse, ACP, stAddonManager und Ampere."
--	L["Showing top"] = ""
	L["Memory Usage"] = "Speichernutzung"
	L["Total Memory in use by Addons"] = "Gesamtere Speichernutzung von Addons"
	L["to open interface options."] = "zum öffnen des Interfaces."
	L["to open"] = "zum öffnen."
	L["to collect garbage."] = "zum sammeln des Abfalls."
	L["to open"] = "zum öffnen von"
--	L["Select the maximum number of addons to display, otherwise drag to 'All'."] = ""


	-- module: nameplates
	L["Nameplates"] = "Namesschilder"
--	L["Broker to allow you to toggle the various nameplates. Eg, friendly or hostile."] = ""
	L["Friendly Players"] = "Freundlicher Spieler"
	L["Friendly Pets"] = "Freundliches Tier"
	L["Friendly Creations"] = "Freundliche Erzeugnisse"
	L["Friendly Everyone"] = "Jeden freundlichen"
	L["Hostile Players"] = "Feindliche Spieler"
	L["Hostile Pets"] = "Feindliche Tiere"
	L["Hostile Creations"] = "Feindliche Einstellung"
	L["Hostile Everyone"] = "Feindlich Jeden"
	L["Companion Names"] = "Begleiternamen"
	L["Your Own Name"] = "Dein eigener Name"
	L["Player Titles"] = "Spieler Titel"
	L["Guild Names"] = "Gildennamen"
	L["NPC Names"] = "NSC Namen"
	L["Current Status"] = "Aktueller Status"
	L["on an option to toggle the Nameplates on or off."] = "auf eine Option um die Namensschilder an oder ab zu schalten."

	-- module: speed
	L["Speed"] = "Tempo"
	L["How fast are you swimming, walking, riding or flying."] = "Wie schnell bist du im schwimmen, laufen, reiten oder fliegen."

	-- module: stuff
	L["Stuff"] = "Zeug"
--	L["Broker to allow you to do...Stuff! Switch to windowed mode, reload ui, logout and quit."] = ""
--	L["Are you sure you want to Reload the UI?"] = ""
	L["Toggle Windowed Mode"] = "wechsel Fenstermodus"
	L["to switch between windowed and fullscreen mode."] = "Umschalt + Links um zwischen Fenster- und Vollbildmodus zu wechseln."
	L["to reload UI."] = "zum neuladen der Benutzeroberfläche."
	L["to logout."] = "um ausloggen."
	L["to quit WoW."] = "zum beenden von WoW."
--	L["You have to do the same click TWICE for anything to happen!"] = ""
	L["to logout."] = "um ausloggen."
	L["to quit WoW."] = "zum beenden von WoW."
	L["to switch between windowed and fullscreen mode."] = "um zwischen Fenster- und Vollbildmodus zu wechseln."
	L["to reload UI."] = "zum neuladen der Benutzeroberfläche."


	-- module: tracking
	L["Tracking"] = "Aufspüren"
--	L["Broker to show what you are currently tracking. You can also change the tracking types from this broker."] = ""
--	L["No tracking currently active."] = ""
	L["to choose tracking skill."] = "um ein Fehigkeit zu verfolgen."


	-- module: xp
--	L["XP"] = ""
--	L["Broker to show your xp. Can be shown either as a percentage, or as values."] = ""
	L["Til Next Level"] = "Bis nächste Stufe"
	L["Rest"] = "Ausgeruht"
	L["to switch display mode."] = "zum ändern des Anzeigemodus."
--	L["Display XP as Absolute Value"] = ""
--	L["Select to show XP as an absolute value; Deselected will show it as a percentage."] = ""
	L["XP gain disabled!"] = "XP erhalt deaktiviert!"

end

