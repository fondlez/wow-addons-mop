local _, ns = ...
local L = ns.L
if ns.LOCALE == "zhTW" then
	-- Traditional Chinese translations go here
	L["Hello!"] = "??!"
end
