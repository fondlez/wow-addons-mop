local _, ns = ...
local L = ns.L
if ns.LOCALE == "zhCN" then
	-- Simplified Chinese translations go here
	L["Hello!"] = "??!"
end
