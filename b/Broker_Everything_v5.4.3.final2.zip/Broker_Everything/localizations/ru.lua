local _, ns = ...
local L = ns.L
if ns.LOCALE == "ruRU" then
	-- Russian translations go here
	L["Hello!"] = "??????!"
end
