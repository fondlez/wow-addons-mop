local _, ns = ...
local L = ns.L
if ns.LOCALE == "ptBR" then
	-- Brazilian Portuguese translations go here
	L["Hello!"] = "Olá!"
end
