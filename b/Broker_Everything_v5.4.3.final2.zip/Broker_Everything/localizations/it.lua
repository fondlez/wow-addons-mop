local _, ns = ...
local L = ns.L
if ns.LOCALE == "itIT" then
	-- French translations go here
	L["Hello!"] = ""
end
