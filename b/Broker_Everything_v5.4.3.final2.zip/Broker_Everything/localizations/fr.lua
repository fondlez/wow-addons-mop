local _, ns = ...
local L = ns.L
if ns.LOCALE == "frFR" then
	-- French translations go here
	L["Hello!"] = "Bonjour!"
end
