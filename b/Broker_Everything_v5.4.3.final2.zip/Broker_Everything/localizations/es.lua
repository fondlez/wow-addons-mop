local _, ns = ...
local L = ns.L
if ns.LOCALE == "esES" or ns.LOCALE == "esMX" then
	-- Spanish translations go here
	L["Hello!"] = "¡Hola!"
end
