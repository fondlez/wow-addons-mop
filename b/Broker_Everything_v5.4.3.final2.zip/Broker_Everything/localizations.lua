
local addon, ns = ...
ns.LOCALE = GetLocale()

-- ----------------------------------------------------------------- --
-- Localization metatable function                                   --
-- Instructions for Non-Ace3 method taken from Phanx at WowInterface --
-- http://www.wowinterface.com/portal.php?&id=224&pageid=250         --
-- ----------------------------------------------------------------- --

ns.L = setmetatable({ }, { __index = function(t, k)
	local v = tostring(k)
	rawset(t, k, v)
	return v
end })

