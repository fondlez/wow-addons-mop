
-- saved variables
Broker_EverythingDB = {}
Broker_EverythingGlobalDB = {}

-- some usefull namespace to locals
local addon, ns = ...
local C, L = ns.color, ns.L

local Broker_Everything = CreateFrame("Frame")

-- OnUpdate event handler
Broker_Everything.updateCounter = 0
Broker_Everything:SetScript("OnUpdate",function(self,elapsed)
	-- update function execution without defined interval in seconds
	for name, update in pairs(ns.updateList) do
		if update.interval == false or update.firstUpdate == false then
			update.func(ns.modules[name])
			update.firstUpdate = true
		end
	end

	self.updateCounter = self.updateCounter + elapsed
	if self.updateCounter < 1 then
		return
	end
	self.updateCounter = 0

	-- update function execution with defined interval in seconds
	for name,update in pairs(ns.updateList) do
		if type(update.interval)=="number" then
			if not update.elapsed then
				update.elapsed = 1
			else
				update.elapsed = update.elapsed + 1
			end
			if update.elapsed > update.interval then
				update.elapsed = update.elapsed - update.interval
				update.func(ns.modules[name])
			end
		end
	end
end)

function Broker_Everything.resetDefaults()
	Broker_EverythingDB = {}
	Broker_EverythingGlobalDB = {}
	Broker_EverythingGlobalDB.global = false

	for name, v in ipairs(ns.modules) do
		if name then
			if Broker_EverythingDB[name] == nil then
				Broker_EverythingDB[name] = {
					enabled = true,
				}
			end
		end
	end
end

Broker_Everything:SetScript("OnEvent", function (self, event, addonName)
	if event == "ADDON_LOADED" and addonName == addon then

		if Broker_EverythingDB.reset == true then
			self.resetDefaults()
			Broker_EverythingDB["reset"] = false
			ns.Print(L["Warning"], L["saved variables have been reset. Sorry for the inconvenience!"])
		end

		if Broker_EverythingGlobalDB.global == true then
			Broker_EverythingDB = Broker_EverythingGlobalDB
		end

		-- Added by Ekaterina to allow for suffix colouring choice,
		if Broker_EverythingDB.suffixColour == nil then
			Broker_EverythingDB.suffixColour = true
		end

		if Broker_EverythingDB.tooltipScale == nil then
			Broker_EverythingDB.tooltipScale = false
		end

		if Broker_EverythingDB.showHints == nil then
			Broker_EverythingDB.showHints = true
		end

		-- modules
		for name, data in pairs(ns.modules) do
			if data.enabled==nil then
				data.enabled = true
			end

			if Broker_EverythingDB[name] == nil then
				Broker_EverythingDB[name] = {enabled = data.enabled}
			end

			if type(Broker_EverythingDB[name].enabled)~="boolean" then
				Broker_EverythingDB[name].enabled = data.enabled
			end

			if Broker_EverythingDB[name].enabled == true then
				ns.moduleInit(name,data)
			end
		end

		-- panels for single modules
		for name, data in pairs(ns.modules) do
			if data.optionpanel then
				ns.OP[name.."Subpanel"] = ns.LSO.AddSuboptionsPanel(addon, data.label, data.optionspanel)
			end
		end

		self:UnregisterEvent("ADDON_LOADED")
	end
	if event == "PLAYER_ENTERING_WORLD" then

		-- panels for broker and config
		ns.OP.brokerPanel = ns.LSO.AddOptionsPanel(addon, ns.OP.createBrokerPanel)
		ns.OP.configPanel = ns.LSO.AddSuboptionsPanel(addon, L["Options"], ns.OP.createConfigPanel)

		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
	end
end)

Broker_Everything:RegisterEvent("ADDON_LOADED")
Broker_Everything:RegisterEvent("PLAYER_ENTERING_WORLD")
