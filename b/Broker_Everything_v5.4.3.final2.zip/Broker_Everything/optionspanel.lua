
local addon, ns = ...
local C, L = ns.color, ns.L

ns.OP = CreateFrame("frame") -- OP / optionspanel

local function setPoints(element, sibling, points)
	if not points then
		points = {
			edgeSelf = "TOPLEFT",
			edgeSibling = "BOTTOMLEFT",
			x = 10,
			y = -3
		}
	end
	element:SetPoint(points.edgeSelf,sibling.elem,points.edgeSibling,points.x,points.y)
end

-- ----------------------------------------------------- --
-- Option panel 1 - brokerPanel - enable/disable modules --
-- ----------------------------------------------------- --

ns.OP.createBrokerPanel = function(panel)
	local controls = {}	

	local function makeToggle(varname, name, desc)
		return panel:MakeToggle(
			"name", name, 
			"description", desc, 
			"default", Broker_EverythingDB[varname].enabled,
			"getFunc", function() return Broker_EverythingDB[varname].enabled end, 
			"setFunc", function(value)
				if value==true and ns.LDB:GetDataObjectByName(varname)==nil then
					ns.moduleInit(varname)
				end
				Broker_EverythingDB[varname].enabled = value
			end
		)
	end

	panel.title, panel.subText = panel:MakeTitleTextAndSubText(
		"Broker_Everything - Broker", L["Select the listed broker to enable/disable. You must Reload UI for any changes to apply."])

	for k, v in pairs(ns.modules) do 
		if not v.noBroker then
			panel[k] = makeToggle(k, L[k], ns.modules[k].desc)
			table.insert(controls, panel[k])
		end
	end

	panel.reload = panel:MakeButton(
		'name', L["Reload UI"],
		'description', L["Reloads the UI. You must do this to apply any changes in module activation."],
		'func', function() ReloadUI() end
	)

	panel.selectnone = panel:MakeButton(
		'name', L["Select none"],
		'description', L["Remove all selections from ns.modules"],
		'func', function()
			for i,v in pairs(ns.modules) do
				Broker_EverythingDB[i].enabled = false
			end
			InterfaceOptionsFrame_OpenToCategory(brokerPanel);
		end
	)

	panel.selectall = panel:MakeButton(
		'name', L["Select all"],
		'description', L["Select all ns.modules"],
		'func', function()
			for i,v in pairs(ns.modules) do
				Broker_EverythingDB[i].enabled = true
			end
			InterfaceOptionsFrame_OpenToCategory(brokerPanel);
		end
	)

	local c,fromTop,pos,last = 1,-10,{0,200,400},0
	
	for i, frame in ipairs(controls) do
		frame:SetPoint("TOPLEFT",panel.subText,"BOTTOMLEFT",pos[c],fromTop)
		c, last = c+1, fromTop
		if c==4 then c, fromTop = 1, fromTop - 25 end
	end

	last = last - 40
	panel.reload:SetPoint(    "TOPLEFT",panel.subText,"BOTTOMLEFT",0,last)
	panel.selectall:SetPoint( "TOPLEFT",panel.subText,"BOTTOMLEFT",200,last)
	panel.selectnone:SetPoint("TOPLEFT",panel.subText,"BOTTOMLEFT",400,last)

end


-- ----------------------------------------------------- --
-- Option panel 2 - general settings and module settings --
-- ----------------------------------------------------- --

ns.OP.createConfigPanel = function(panel)
	local controls = {}	

    local function makeCheck(name, desc, module, option)
        return panel:MakeToggle(
            "name", name, 
            "description", desc,
            "default", false, 
            "getFunc", function() 
				if module == "nil" or module == nil then
					return Broker_EverythingDB[option]
				else
					return Broker_EverythingDB[module][option]
				end
			end, 
            "setFunc", function(value)
				if module == "nil" or module == nil then
					Broker_EverythingDB[option] = value
				else
					Broker_EverythingDB[module][option] = value
				end
			end
        )
    end

	local function getTitle(text, tType)
		local title
		if tType == "group" then
			title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalMed3")
		else
			title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		end
		title:SetText(text)
		title:SetJustifyH("LEFT")
		title:SetJustifyV("CENTER")
		title:SetHeight(20)
		return title
	end

	local function getDivider(parent)
		if not parent then parent = panel end
		local div = CreateFrame("Frame", nil, parent)
		div:SetSize(panel:GetParent():GetWidth() - 30, 2)
		local tex = div:CreateTexture(nil, "BACKGROUND")
		tex:SetHeight(8)
		tex:SetPoint("LEFT",-3, 0)
		tex:SetPoint("RIGHT",0, 0)
		tex:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
		tex:SetTexCoord(0.81, 0.94, 0.5, 1)
		return div
	end
	
	-- ------------------------------- --
	-- general settings in configPanel --
	-- ------------------------------- --

	panel.title, panel.subText = panel:MakeTitleTextAndSubText("Broker_Everything - "..L["Options"], L["Allows you to adjust the display options."])
	
	panel.generalTitle = getTitle(L["General Options"], "group")
	panel.generalDivide = getDivider()

	-- reset button
	panel.reset = panel:MakeButton(
		'name', L["Reset"],
		'description', L["Resets the Broker_Everything Defaults and Reloads the UI."],
		'func', function() Broker_EverythingDB.reset = true ReloadUI() end
	)

	panel.suffixColoring = makeCheck(L["Suffix Colouring"], L["Enable/Disable Class colouring of the information display suffixes. (eg, ms, fps etc)"], nil, "suffixColour")
	panel.global = panel:MakeToggle(
			"name", L["Use global profile"], 
			"description", L["Enable/Disable the showing of a global Broker_Everything profile across all of your characters."],
			"default", false, 
			"getFunc", function() return Broker_EverythingDB.global end, 
			"setFunc", function(value) 
				if value == true and Broker_EverythingGlobalDB["Clock"] == nil then
					Broker_EverythingGlobalDB = Broker_EverythingDB
				end
				Broker_EverythingGlobalDB.global = value
			end
		)
	panel.tooltipScale = makeCheck(L["Tooltip Scaling"], L["Scale the tooltips with your UIScale. Default is off"], "nil", "tooltipScale")
	panel.showhints = makeCheck(L["Show hints"], L["Show hints in tooltips."], "nil", "showHints")

	panel.generalTitle:SetPoint("TOPLEFT", panel.subText, "BOTTOMLEFT", 0, -10)
	panel.reset:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -10, -15)

	panel.generalDivide:SetPoint(	"TOPLEFT", panel.generalTitle, "BOTTOMLEFT", 0, 0)

	panel.suffixColoring:SetPoint(	"TOPLEFT", panel.generalDivide, "BOTTOMLEFT",   0, -3)
	panel.global:SetPoint(			"TOPLEFT", panel.generalDivide, "BOTTOMLEFT", 200, -3)
	panel.tooltipScale:SetPoint(	"TOPLEFT", panel.generalDivide, "BOTTOMLEFT", 400, 0)

	panel.showhints:SetPoint(		"TOPLEFT", panel.suffixColoring, "BOTTOMLEFT",  0, 0)

	-- ------------------------------ --
	-- module settings in configPanel --
	-- ------------------------------ --

	panel.moduleOptionsTitle = getTitle(L["Module Options"], "group")
	panel.moduleOptionsTitle:SetPoint("TOPLEFT", panel.showhints, "BOTTOMLEFT", 0, -5)

	-- scrollframe & scrollchild
	local scrollFrame = CreateFrame("ScrollFrame",addon.."ns.modulesScrollFrame",panel,"UIPanelScrollFrameTemplate")
	scrollFrame:SetWidth(panel:GetParent():GetWidth() - 55)
	scrollFrame:SetFrameLevel(scrollFrame:GetFrameLevel() + 1)
	scrollFrame:SetHeight(395)
	scrollFrame:SetPoint("TOPLEFT",panel.moduleOptionsTitle,"BOTTOMLEFT", 0, 0)
	scrollFrame:SetBackdrop({
		edgeFile = [=[Interface\Tooltips\UI-Tooltip-Border]=],
		tile = true, tileSize = 16, edgeSize = 16,
		insets = { left = 0, right = 0, top = 0, bottom = 0 }
	})

	scrollFrame.child = CreateFrame("Frame", scrollFrame:GetName().."_Child", scrollFrame)
	scrollFrame.child:SetWidth(scrollFrame:GetWidth()-10)
	scrollFrame.child:SetHeight(1)
	scrollFrame:SetScrollChild(scrollFrame.child)
	scrollFrame:SetHitRectInsets( 0, 0, 7, 7)

	local height = 0
	local width = scrollFrame.child:GetWidth()-10
	local prev = scrollFrame.child
	local rowBackdrop = { bgFile = [=[Interface\Tooltips\UI-Tooltip-Background]=], insets = { left = 0, right = 0, top = 0, bottom = 0 } }
	local row = nil

	for modName, modData in pairs(ns.modules) do

		if modData.config then

			local name = "mod_"..modName.."Title"

			if row~=nil then
				row = getDivider()
				row:SetParent(scrollFrame.child)
				row:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 1, -2)
				row:SetWidth(width)
				height = height + row:GetHeight()
				prev = row
			end

			-- create frame for module options
			row = CreateFrame("Frame",name,scrollFrame.child)
			row:SetWidth(width)
			row:SetHeight(modData.config.height)
			row:SetBackdrop(rowBackdrop)
			row:SetBackdropColor(0,0,0,.6)

			if prev ~= scrollFrame.child then
				row:SetPoint("TOPLEFT",prev,"BOTTOMLEFT",-1, -2)
			else
				row:SetPoint("TOPLEFT",prev,"TOPLEFT",10,-10)
			end

			-- module name as title
			local title = getTitle(C("green",L[modName]))
			title:SetParent(row)
			title:SetPoint("TOPLEFT",row,"TOPLEFT",5,0)

			if type(modData.config.elements) == "table" then
				-- walk through option table and create all elements
				local first_in_row
				local sibling = {elem = title, realWidth = 0}
				for num, objData in pairs(modData.config.elements) do
					if not objData or type(objData)~="table" or type(objData.type)~="string" then
					elseif objData.type == "next_row" then
						local dot = CreateFrame("frame")
						dot:SetWidth(1) dot:SetHeight(1)
						dot:SetPoint("TOPLEFT",first_in_row,"BOTTOMLEFT",0,0)
						first_in_row = nil
						sibling.elem = dot
					elseif objData.type == "check" then
						local check = panel:MakeToggle(
							'name',			objData.label,
							'description',	objData.desc,
							'default',		false,
							'getFunc',		function() return Broker_EverythingDB[modName][objData.name] end,
							'setFunc',		function(value)
								Broker_EverythingDB[modName][objData.name] = value
								if objData.event then
									if objData.event==true then objData.event = "BE_OPTION_CHANGED" end
									ns.modules[modName].onevent({},objData.event,nil)
								end
							end
						)
						check:SetParent(row)
						setPoints(check,sibling,objData.points or nil)
						sibling.elem = check
						sibling.realWidth = check.realWidth
					elseif objData.type == "slider" then
						--[[
						--	objData = {
						--		type         string     
						--		name         string     
						--		label        string     
						--		desc         string     
						--		minText      string     
						--		maxText      string     
						--		minValue     integer    
						--		maxValue     integer    
						--		step         integer    
						--		default      string     
						--	}
						--]]
						local slider = panel:MakeSlider(
							'name',				objData.label,
							'description',		objData.desc,
							'minText',			objData.minText,
							'maxText',			objData.maxText,
							'minValue',			objData.minValue,
							'maxValue',			objData.maxValue,
							'step', 			objData.step or 1,
							'default',			objData.default,
							'setFunc',			function(value) Broker_EverythingDB[modName][objData.name] = ("%.0f"):format(value) end,
							'getFunc',			function() return Broker_EverythingDB[modName][objData.name] or 0 end,
							'currentTextFunc',	function(value) return ("%.0f"):format(value~=nil and tonumber(value) or 0) end
						)
						slider:SetParent(row)
						setPoints(slider,sibling,objData.points or nil)
						sibling.elem = slider
						sibling.realWith = slider:GetWidth()
					elseif objData.type == "dropdown" then
						--[[
						--	objData = {
						--		type         string     
						--		name         string     
						--		label        string     
						--		desc         string     
						--		values       table      
						--		default      string     
						--		setFunc      function   [optional]
						--	}
						--]]
						if not objData.setFunc then
							objData.setFunc = function(value) Broker_EverythingDB[modName][objData.name] = value end
						end
						local dropdown = panel:MakeDropDown(
							'name',			objData.label,
							'description',	objData.desc,
							'values',		objData.values,
							'default',		objData.default,
							'current',		Broker_EverythingDB[modName][objData.name],
							'setFunc',		objData.setFunc
						)
						dropdown:SetParent(row)
						setPoints(dropdown,sibling,objData.points or nil)
						sibling.elem = dropdown
						sibling.realWith = dropdown:GetWidth()
					elseif objData.type == "_button" then
						--[[
						--	objData = {
						--		type      string      
						--		label     string      
						--		desc      string      
						--		func      function    [optional]
						--	}
						--]]
						if not objData.func then
							objData.func = function() Broker_EverythingDB[modName][objData.name] = Broker_EverythingDB[modName][objData.name]==1 and 0 or 1 end
						end
						local button = panel:MakeButton(
							'name',			objData.label,
							'description',	objData.desc,
							'func',			objData.func
						)
						button:SetParent(row)
						setPoints(button,sibling,objData.points or nil)
						sibling.elem = button
						sibling.realWith = button:GetWidth()
					end

					if not first_in_row then
						first_in_row = sibling.elem
					end
					title = nil
				end
			end
			prev = row
		end
	end

	-- empty last row for a better look
	if prev ~= scrollFrame.child then
		local row = CreateFrame("Frame",nil,prev)
		row:SetWidth(1)
		row:SetHeight(14)
		row:SetPoint("TOPLEFT",prev,"BOTTOMLEFT",0,0)
		height = height + row:GetHeight()
	end

end
