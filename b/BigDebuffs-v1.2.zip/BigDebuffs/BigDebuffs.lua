
-- BigDebuffs by Jordon

LoadAddOn("Blizzard_CompactRaidFrames")

-- Debuffs to make bigger, higher numbers take precedence regardless of duration
local DispelList = {
	[33786]  = 90, -- Cyclone
	[76577]  = 60, -- Smoke Bomb
	[44572]  = 50, -- Deep Freeze
	[47476]  = 30, -- Strangulate
	[108194] = 30, -- Asphyxiate
	[91800]  = 30, -- Gnaw
	[91797]  = 30, -- Monstrous Blow
	[5211]   = 30, -- Mighty Bash
	[2637]   = 30, -- Hibernate
	[22570]  = 30, -- Maim
	[9005]   = 30, -- Pounce
	[102546] = 30, -- Pounce
	[99]     = 30, -- Disorienting Roar
	[19503]  = 30, -- Scatter Shot
	[19386]  = 30, -- Wyvern Sting
	[3355]   = 30, -- Freezing Trap
	[117526] = 30, -- Binding Shot
	[24394]  = 30, -- Intimidation
	[90337]  = 30, -- Bad Manner (Monkey)
	[50519]  = 30, -- Sonic Blast (Bat)
	[1513]   = 30, -- Scare Beast
	[34490]  = 30, -- Silencing Shot
	[118]    = 30, -- Polymorph
	[61305]  = 30, -- Polymorph Black Cat
	[28272]  = 30, -- Polymorph Pig
	[61721]  = 30, -- Polymorph Rabbit
	[61780]  = 30, -- Polymorph Turkey
	[28271]  = 30, -- Polymorph Turtle
	[82691]  = 30, -- Ring of Frost
	[31661]  = 30, -- Dragon's Breath
	[118271] = 30, -- Combustion
	[102051] = 30, -- Frostjaw
	[55021]  = 30, -- Silenced - Improved Counterspell
	[119392] = 30, -- Charging Ox Wave
	[119381] = 30, -- Leg Sweep
	[122242] = 30, -- Clash
	[120086] = 30, -- Fists of Fury
	[115078] = 30, -- Paralysis
	[116709] = 30, -- Spear Hand Strike
	[853]    = 30, -- Hammer of Justice
	[105593] = 30, -- Fist of Justice
	[10326]  = 30, -- Turn Evil
	[20066]  = 30, -- Repentance
	[119072] = 30, -- Holy Wrath
	[31935]  = 30, -- Avengers Shield
	[105421] = 30, -- Blinding Light
	[8122]   = 30, -- Psychic Scream
	[9484]   = 30, -- Shackle Undead
	[605]    = 30, -- Dominate Mind (Mind Control)
	[15487]  = 30, -- Silence
	[64044]  = 30, -- Psychic Horror
	[113792] = 30, -- Psychic Terror
	[131556] = 30, -- Sin and Punishment
	[6770]   = 30, -- Sap
	[408]    = 30, -- Kidney Shot
	[2094]   = 30, -- Blind
	[1833]   = 30, -- Cheap Shot
	[13953]  = 30, -- Paralysis
	[51722]  = 30, -- Dismantle
	[1776]   = 30, -- Gouge
	[703]    = 30, -- Garrote
	[51514]  = 30, -- Hex
	[118905] = 30, -- Static Charge (Capacitor Totem)
	[77505]  = 30, -- Earthquake
	[118699] = 30, -- Fear
	[5484]   = 30, -- Howl of Terror
	[30283]  = 30, -- Shadowfury
	[103131] = 30, -- Felguard: Axe Toss
	[6358]   = 30, -- Seduction
	[115268] = 30, -- Mesmerize
	[22703]  = 30, -- Infernal Awakening
	[6789]   = 30, -- Mortal Coil
	[24259]  = 30, -- Spell Lock
	[115782] = 30, -- Optical Blast
	[710]    = 30, -- Banish
	[5246]   = 30, -- Initmidating Shout
	[132168] = 30, -- Shockwave
	[107570] = 30, -- Storm Bolt
	[100]    = 30, -- Charge
	[20549]  = 30, -- War Stomp
	[129597] = 30, -- Arcane Torrent
	[107079] = 30, -- Quaking Palm
	[113506] = 90, -- Cyclone
	[126449] = 30, -- Clash
	[110698] = 30, -- Hammer of Justice
	[113004] = 30, -- Intimidating Roar
	[126246] = 30, -- Lullaby
	[111397] = 30, -- Blood Horror
	[2944]   = 10, -- Devouring Plague
	[78675]  = 10, -- Solar Beam
	[114866] = 10, -- Soul Reaper
	[130736] = 10, -- Soul Reaper
	[130735] = 10, -- Soul Reaper
	[10326]  = 10, -- Turn Evil
}

local MAX_BIG_DEBUFFS = 2

-- Make sure we always see these debuffs, but don't make them bigger
local PriorityDebuffs = {
	30108, -- Unstable Affliction
	34914, -- Vampiric Touch
	770,   -- Faerie Fire
}

-- Show these when a big debuff is displayed
local AdditionalDebuffs = {
	76577, -- Smoke Bomb
	30108, -- Unstable Affliction
	34914, -- Vampiric Touch
}

local function IsPriorityDebuff(id)
	for i = 1, #PriorityDebuffs do
		if id == PriorityDebuffs[i] then
			return true
		end
	end
end

local function HideBigDebuffs(frame)
	if not frame.BigDebuffs then return end
	for i = 1, MAX_BIG_DEBUFFS do
		frame.BigDebuffs[i]:Hide()
	end
end

hooksecurefunc("CompactUnitFrame_HideAllDebuffs", HideBigDebuffs)

local function ShowBigDebuffs(frame)

	if not frame.BigDebuffs then return end

	if not UnitIsPlayer(frame.displayedUnit) then
		return
	end	

	HideBigDebuffs(frame)

	local offset, duration, priority, debuff = 1, 0, 0
	for i = 1, 40 do
		local _,_,_,_,_,_, time, _,_,_, id =UnitDebuff(frame.displayedUnit, i)
		if id then
			local p = DispelList[id]
			if frame.debuffFrames and p and p >= priority then
				local now = GetTime()
				if not time or time - now > duration then
					duration = time - now
					debuff = i
					priority = p
				end
			end
		end
		
	end

	if debuff then

		CompactUnitFrame_HideAllDebuffs(frame)

		for i = 1, 40 do
			local id = select(11, UnitDebuff(frame.displayedUnit, i))
			if id then
				for j = 1, #AdditionalDebuffs do
					if id == AdditionalDebuffs[j] then
						CompactUnitFrame_UtilSetDebuff(frame.BigDebuffs[offset], frame.displayedUnit, i, nil, false, false)
						offset = offset + 1
						break
					end
				end
			end
			if offset == MAX_BIG_DEBUFFS then
				break
			end
		end

		CompactUnitFrame_UtilSetDebuff(frame.BigDebuffs[offset], frame.displayedUnit, debuff, nil, false, false)
	end

end

-- We need to copy the entire function to avoid taint
hooksecurefunc("CompactUnitFrame_UpdateDebuffs", function(frame)
	if ( not frame.optionTable.displayDebuffs ) then
		CompactUnitFrame_HideAllDebuffs(frame);
		return;
	end
	
	local index = 1;
	local frameNum = 1;
	local filter = nil;
	local maxDebuffs = frame.maxDebuffs;
	--Show both Boss buffs & debuffs in the debuff location
	--First, we go through all the debuffs looking for any boss flagged ones.
	while ( frameNum <= maxDebuffs ) do
		local debuffName = UnitDebuff(frame.displayedUnit, index, filter);
		if ( debuffName ) then
			if ( CompactUnitFrame_UtilIsBossAura(frame.displayedUnit, index, filter, false) ) then
				local debuffFrame = frame.debuffFrames[frameNum];
				CompactUnitFrame_UtilSetDebuff(debuffFrame, frame.displayedUnit, index, filter, true, false);
				frameNum = frameNum + 1;
				--Boss debuffs are about twice as big as normal debuffs, so display one less.
				local bossDebuffScale = (debuffFrame.baseSize + BOSS_DEBUFF_SIZE_INCREASE)/debuffFrame.baseSize
				maxDebuffs = maxDebuffs - (bossDebuffScale - 1);
			end
		else
			break;
		end
		index = index + 1;
	end
	--Then we go through all the buffs looking for any boss flagged ones.
	index = 1;
	while ( frameNum <= maxDebuffs ) do
		local debuffName = UnitBuff(frame.displayedUnit, index, filter);
		if ( debuffName ) then
			if ( CompactUnitFrame_UtilIsBossAura(frame.displayedUnit, index, filter, true) ) then
				local debuffFrame = frame.debuffFrames[frameNum];
				CompactUnitFrame_UtilSetDebuff(debuffFrame, frame.displayedUnit, index, filter, true, true);
				frameNum = frameNum + 1;
				--Boss debuffs are about twice as big as normal debuffs, so display one less.
				local bossDebuffScale = (debuffFrame.baseSize + BOSS_DEBUFF_SIZE_INCREASE)/debuffFrame.baseSize
				maxDebuffs = maxDebuffs - (bossDebuffScale - 1);
			end
		else
			break;
		end
		index = index + 1;
	end
	
	--Now we go through the debuffs with a priority (e.g. Weakened Soul and Forbearance)
	index = 1;
	while ( frameNum <= maxDebuffs ) do
		local debuffName, _,_,_,_,_,_,_,_,_, id = UnitDebuff(frame.displayedUnit, index, filter);
		if ( debuffName ) then
			if ( CompactUnitFrame_UtilIsPriorityDebuff(frame.displayedUnit, index, filter) or IsPriorityDebuff(id)) then
				local debuffFrame = frame.debuffFrames[frameNum];
				CompactUnitFrame_UtilSetDebuff(debuffFrame, frame.displayedUnit, index, filter, false, false);
				frameNum = frameNum + 1;
			end
		else
			break;
		end
		index = index + 1;
	end
	
	if ( frame.optionTable.displayOnlyDispellableDebuffs ) then
		filter = "RAID";
	end
	
	index = 1;
	--Now, we display all normal debuffs.
	if ( frame.optionTable.displayNonBossDebuffs ) then
	while ( frameNum <= maxDebuffs ) do
		local debuffName, _,_,_,_,_,_,_,_,_, id = UnitDebuff(frame.displayedUnit, index, filter);
		if ( debuffName ) then
			if ( CompactUnitFrame_UtilShouldDisplayDebuff(frame.displayedUnit, index, filter) and not CompactUnitFrame_UtilIsBossAura(frame.displayedUnit, index, filter, false) and
				not CompactUnitFrame_UtilIsPriorityDebuff(frame.displayedUnit, index, filter) and not IsPriorityDebuff(id)) then
				local debuffFrame = frame.debuffFrames[frameNum];
				CompactUnitFrame_UtilSetDebuff(debuffFrame, frame.displayedUnit, index, filter, false, false);
				frameNum = frameNum + 1;
			end
		else
			break;
		end
		index = index + 1;
	end
	end
	
	for i=frameNum, frame.maxDebuffs do
		local debuffFrame = frame.debuffFrames[i];
		debuffFrame:Hide();
	end

	ShowBigDebuffs(frame)
end)

hooksecurefunc("DefaultCompactUnitFrameSetup", function(frame)
	local baseSize = frame:GetHeight() * 0.6
	frame.BigDebuffs = frame.BigDebuffs or {}
	for i = 1, MAX_BIG_DEBUFFS do
		local big = frame.BigDebuffs[i] or CreateFrame("Button", nil, frame, "CompactDebuffTemplate")
		big:ClearAllPoints()
		big.baseSize = baseSize
		if i > 1 then
			big:SetPoint("BOTTOMLEFT", frame.BigDebuffs[i-1], "BOTTOMRIGHT", 0, 0)
		else
			big:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 2, 2)
		end
		big:SetFrameStrata("MEDIUM")
		frame.BigDebuffs[i] = big
	end
end)
