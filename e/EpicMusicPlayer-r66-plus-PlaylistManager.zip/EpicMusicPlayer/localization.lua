--by yess
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("EpicMusicPlayer", "enUS", true)
if not L then return end

if L then
	L["Set the click behaviour for the minimap, the title in the GUI and the data broker plugin."] = true
	L["Add Game Music"] = true
	L["Adds playlists with game music (reload required)."] = true
	L["Lock GUI"] = true
	L["Prevent accidentally moving the GUI."] = true

	L["Copied song %s to List %s."] = true
	L["Playlist %s already exists."] = true
	L["Why are some playlists grey?"] = true
	L["Playlist %s not found."] = true
	L["Really remove playlist %s?"] = true
	L["Playlist %s removed."] = true
	L["Playlists created with the playlist generator or addedy by the game music module are locked for editing."] = true
	L["You can only remove playlists created ingame or with the playlist manager (not the playlist generator)!"] = true


	L["Shuffle Cross Playlist"] = true
	L["Hide Artist in Playlist"] = true
	L["Show Update Info"]= true
	L["Layout & Skin"] = true
	L["Select a question from the left."] = true
	L["EpicMusicPlayer Update Info"] = true

	L["Read the FAQ for more info about this."] = true		
	L["Reset GUI Position"] = true
	L["Reset the GUI window position"] = true
	L["Playlist font"] = true
	L["Change the playlist font. Requires relog to take effect."] = true
	L["Test"] = true
	L["Plays a test song."] = true
	L["Playlist Scale"] = true
	L["Adjust the scale of the playlist"] = true
	L["Frame strata"] = true
	L["MusicDancer"] = true 
	L["Show Dancer"] = true
	L["Toggle show model."] = true
	L["Random Model"] = true
	L["Show a random model when playing a new song."] = true
	L["Set Model"] = true
	L["Select a model"] = true
	L["Model Size"] = true
	L["Adjust the size of the model frame"] = true
	L["Lock"] = true
	L["Unlock to allow moving the model. Moving will release the model from the GUI. Use reset to reattach."] = true
	L["Show Background"] = true
	L["Enable Mouse"] = true
	L["Click me or scroll me. I won\'t bite. 8==8"] = true
	L["Show Pedestal"] = true
	L["Show Tooltip"] = true
	L["Reset Position"] = true
	L["This will set the model to the default size and attach it to the GUI."] = true
	L["Toggle with GUI"] = true
	L["Showing/hiding the GUI will show/hide the dancer."] = true
	L['Show Artist'] = true
	L['Toggle show Artist'] = true
	L["Left click"] = true
	L["Middle click"] = true
	L["Right click"] = true
	L["Alt click"] = true
	L["Shift click"] = true
	L["Ctrl click"] = true 

	L["List"] = true
	L['Show List/Song Numbers'] = true
	L['Show playlist and song number'] = true
						
	L['Show Title'] = true
	L['Toggle show title'] = true

	L["Show time"] = true
	L["Toggle show time"] = true

	L["Max song text length"] = true
	L["The maximum text length of the song displayed in the Panel."] = true

	L["Music volume: "] = true
	L["Effects volume: "] = true
	L["Stopped"] = true

	L["Artist"] = true
	L["Song"] = true
	L["Album"] = true
	L["Length"] = true

	L["Use scroll wheel - adjust music volume"] = true
	L["Ctrl + use scroll wheel - adjust effects volume"] = true
	L["Alt + use scroll wheel - fine adjust volume"] = true

	L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = true 

	L["GUI Layout"] = true
	L["Help - FAQ"] = true
	L["Frequently Asked Questions"] = true

	L["Current will be moved on playing next song."] = true
	L["Playing song from history."] = true

	L["Font"] = true
	L["Font & Colors"] = true
	L["Music off"] = true
	L["Game Music"] = true
	L["Scroll GUI Text"] = true

	L["How do I add music to the player?"] = true
	L["FAQ-Text1"] = [[
1. Exit Wow if running!
  Double click the "PlaylistManager.exe" in the Playlistmanger folder of the Addon.

2. Click File > Add Music Folder, select a folder with your music and click open.
  OR
  Just drag and drop some mp3 music files/folders into the Playlist-Manager.

3. Close EMP-Playlist-Manager (be sure to click "Yes" Save Playlist.)
  Start WoW and enjoy your music while farming:)
]]


	L["Do I have to copy all of my music files to the wow folder?"] = true
	L["FAQ-Text2"] = [[ 
No. The Playlist Manager can create links (inside the wow folder) that point to your original music folder. That way wow thinks the files are in the wow folder.

You can enable this by:
Windows Vista:
Just go to "Tools > Options" and change copy to create links.

Windows XP:
Download junction.exe from microsoft: http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx and put it into the junction folder of the playlist manager.

You should also install "ntfslink" (http://elsdoerfer.name/=ntfslink ) To make the use of the links (junctions) save with windos xp. See http://en.wikipedia.org/wiki/NTFS_junction_point#Windows_XP_Professional for more information.

And now go to "Tools > Options" and change copy to create links. 
]]

	L["Why is the song playing from the beginning after a loading screen?"] = true
	L["This is a wow bug since patch 2.4.3. I only could fix this so far that the song starts from start instead playing the game music. I have reported this in the eu forums but unless someone with an us account finally reports this in the us ui-forum blizzard developers will never fix this."] = true


	L["Where the hell is the playlist?"] = true
	L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = true

	L["Why is there no pause button?"] = true
	L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = true


	L["Current will be moved on playing next song."] = true
	L["Moved song %s from list %s to list %s."] = true

	L["Playing song from history."] = true

	L["Font"] = true
	L["Font & Colours"] = true
	L["Music off"] = true
	L["Game Music"] = true
	L["Scroll GUI Text"] = true

	L["Colours"] = true
	L["Artist color"] = true
	L["Title color"] = true
	L["Background color"] = true
	L["Border color"] = true
	L["Button color"] = true
	L["Use artist color"] = true
	L["Use artist color as button color"] = true
	L["Frame strata"] = true

	L["Copy song to"] = true
	L["Copied song"] = true
	L["Console Controls"] = true
	L["Play Next Song"] = true
	L["Play Last Song"] = true
	L["Play/Stop"] = true

	L["Drop Down Menu"] = true
	L["Spam to default channel"] = true

	L["Mouse Setup"] = true
	L["Left Click"] = true
	L["Right Click"] = true
	L["Middle Click"] = true
	L["Button4"] = true
	L["Button5"] = true
	L["Alt+Click"] = true
	L["Shift+Click"] = true
	L["Control+Click"] = true
	L["Alt+Control+Click"] = true

	L["Controls"] = true
	L["Next"] = true
	L["Plays the next song."] = true
	L["Last"] = true
	L["Plays the last song."] = true
	L["Play"] = true
	L["Play the Music"] = true
	L["Stop"] = true
	L["Stop playing."] = true
	L["Playlist"] = true
	L["Show the Music."] = true

	L["Spam Link"] = true
	L["Add a youtube link to chat spam."] = true

	L["Shuffle"] = true
	L["Toggle shuffle"] = true

	L["Console"] = true
	L["Show console commands"] = true
						
	L["Mute"] = true
	L["Mute / unmute music sound."] = true

	L["Show Info"] = true
	L["Show song and artist on new song"] = true
						
	L["Autoplay"] = true
	L["Toggles auto play on load."] = true

	L["Show Song In Chat"] = true
	L["Show message in your chat when playing a new song."] = true
						
	L["Disable WoW Music"] = true
	L["Disable WoW Music when not Playing."] = true
						
	L["Show GUI"] = true
	L["Toggle show GUI"] = true

	L["Minimap Button"] = true
	L["Toggle show minimap button"] = true
						   
	L["Loop Playlist"] = true
	L["Playing the last song of a list will not switch to the next list."] = true
						
	L["Remove Song"] = true
	L["Remove the playing song from list"] = true
						   
	L["Add Playlist"] = true
	L["Add Playlist"] = true
	L["Remove Playlist"] = true


	L["Default Channel"] = true
	L["Select the default channel to spam on ctrl+click"] = true

	L["Loop Song"] = true
	L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = true

	L["General"] = true
	L["Favorites List"] = true
	L["Move song to favorite list"] = true

	L["GUI Size"] = true
	L["Adjust the size of the GUI"] = true

	L["Playlist not found."] = true
	L["Read the install file in the addon directory"] = true
	L["GUI not found"] = true
	L["Playlist error oO Playlist maybe empty."] = true
	L["No Target"] = true
	L["Last playlist can not be removed."] = true
	L["[~mymusic~] "] = true
	L["Song is already in that list."] = true
	L["Added playlist %s."] = true
	L["Right click and drag to move this button"] = true

	L["Search..."] = true
	L["No Match"] = true
	L["Artist"] = true
	L["Playlists"] = true
	L["Close"] = true
	L["Clear"] = true

	L["GUI"] = true
	L["Guild"] = true
	L["Party"] = true
	L["Say"] = true
	L["To target"] = true
	L["Whisper to"] = true
	L["Raid"] = true

	L["Config"] = true
	L["Play last"] = true
	L["Show Dancer"] = true
	L["Move song to"] = true
	L["Spam to"] = true

	L["Music volume: "] = true
	L["Effects vol.: "] = true
	L["Stopped"] = true

	L["Play/Stop"] = true
	L["Play Next Song"] = true
	L["Play Last Song"] = true
	L["Show/Hide Playlist"] = true
	L["Toggle Mute"] = true
	L["Remove Song"] = true
	L["Show Controls and Options"] = true
end


local L = AceLocale:NewLocale("EpicMusicPlayer", "deDE")
if L then 
	L["Add a youtube link to chat spam."] = "Youtube Link zu Chat Spam anhängen."
L["Added playlist %s."] = "Playlist %s hinzugefügt."
L["Add Playlist"] = "Liste hinzufügen"
L["Adjust the scale of the playlist"] = "Skalierung der Wiedergabeliste anpassen."
L["Adjust the size of the GUI"] = "Skalierung des GUI anpassen."
L["Adjust the size of the model frame"] = "Skalierung des Models anpassen"
L["Album"] = "Album"
L["Alt click"] = "Alt klick"
L["Alt+Click"] = "Alt+Klick"
L["Alt+Control+Click"] = "Alt+Strg+Klick"
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + Mausrad - Feineinstellung Lautstärke"
L["Artist"] = "Interpret"
L["Artist color"] = "Interpretenfarbe"
L["Autoplay"] = "Autowiedergabe"
L["Background color"] = "Hintergrundfarbe"
L["Border color"] = "Rahmenfarbe"
L["Button4"] = "Taste4"
L["Button5"] = "Taste5"
L["Button color"] = "Tastenfarbe"
L["Change the playlist font. Requires relog to take effect."] = "Zeichensatz der Wiedergabeliste ändern, erfordert einen Neustart."
L["Clear"] = "entfernen"
L["Click me or scroll me. I won't bite. 8==8"] = "Klick mich oder verschiebe mich, ich beiße nicht. 8==8"
L["Close"] = "Schließen"
L["Colours"] = "Farben"
L["Config"] = "Einstellungen"
L["Console"] = "Konsole"
L["Console Controls"] = "Konsolensteuerung"
L["Control+Click"] = "Strg+Klick"
L["Controls"] = "Steuerung"
L["Copied song"] = "Titel"
L["Copied song %s to List %s."] = "Song %s zu Liste %s kopiert."
L["Copy song to"] = "Kopieren nach"
L["Ctrl click"] = "Strg+klick"
L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = "Schreibe Interpret und Titel zum Standart Chat."
L["Ctrl + use scroll wheel - adjust effects volume"] = "Strg + Mausrad - verstellt die Lautstärke"
L["Current will be moved on playing next song."] = "Momentaner Song wird abgelöst vom nächsten Song"
L["Default Channel"] = "Standardkanal"
L["Disable WoW Music"] = "WoW-Musik ausschalten"
L["Disable WoW Music when not Playing."] = "Musik abschalten bei Wiedergabestopp"
L["Do I have to copy all of my music files to the wow folder?"] = "Muß ich meine ganze Musik in den Wow Ordner kopieren?"
L["Drop Down Menu"] = "DropDown-Menü"
L["Effects vol.: "] = "Sound Lautst.: "
L["Effects volume: "] = "Sound Lautst.: "
L["Enable Mouse"] = "Klickbar"
L["EpicMusicPlayer Update Info"] = "EpicMusicPlayer Update Info"
L["FAQ-Text1"] = [=[1. Verlasse Wow, falls es läuft!
    Doppelklick auf "PlaylistManager.exe"; im Playlist_Manager Ordner des Addons.

2. Klicke auf "Add Music File" / "Add Music Folder", wähle ein File/einen Ordner mit 
    deiner Musik aus und klicke auf "öffnen". Erstes  Fenster "Add Music" reicht auch.
    ODER
    Ziehe einfach ein paar MP3 Dateien/Ordner in den Playlist-Manager.

3. Schließe EMP-Playlist-Manager (paß auf das du "Ja" "Save Playlist" anklickst beim 
    schließen). Starte WoW und genieße deine Musik während du farmst:)
]=]
L["FAQ-Text2"] = [=[Nein.
Denn der PlaylistManager kann Links erzeugen (innerhalb des Wow Ordners) die zu 
deinen Original Musik Ordnern zeigen. Das ist der Weg um Wow denken zu lassen die Dateien wären im Wow Ordner.

Dies solltest du tun bei:
Windows Vista:
Gehe im PlaylistManager-Menü auf Tools > Options und ändere von "copy folder and songs" auf 
"create links (NTFS Junctions) to original folder".

Windows XP:
Download "junction.exe"; von microsoft: "http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx"; 
und lege die Datei in den junction Ordner vom PlaylistManager.

Du solltest "ntfslink" (http://elsdoerfer.name/=ntfslink ) installiert haben, damit du die Links benutzen kannst,
die du mit Junction auf Windows XP gespeichert hast. Siehe hier "http://en.wikipedia.org/wiki/NTFS_junction_point#Windows_XP_Professional"; für weiterführende Informationen.

Und dann gehst du im PlayManager-Menü auf "Tools > Options" und änderst von "copy folder and songs" auf
"create links (NTFS Junctions) to original folder.
]=]
L["Favorites List"] = "Favoriten-Liste"
L["Font"] = "Schrift"
L["Font & Colors"] = "Zeichensatz und Farbe"
L["Font & Colours"] = "Schrift & Farben"
L["Frame strata"] = "Rahmenverlauf"
L["Frequently Asked Questions"] = "Häufig gestellte Fragen"
L["Game Music"] = "Spielmusik"
L["General"] = "Allgemein"
L["GUI"] = "GUI"
L["GUI Layout"] = "GUI Aufmachung"
L["Guild"] = "Gilde"
L["GUI not found"] = "GUI nicht gefunden"
L["GUI Size"] = "GUI Größe"
L["Help - FAQ"] = "Hilfe - FAQ"
L["Hide Artist in Playlist"] = "Verstecke Künstler in der Playlist"
L["How do I add music to the player?"] = "Wie füge ich Musik zum Player hinzu?"
L["Last"] = "Zurück"
L["Last playlist can not be removed."] = "Die letze Liste kann nicht entfernt werden."
L["Layout & Skin"] = "Aufmachung & Erscheinungsbild"
L["Left click"] = "Linksklick"
L["Left Click"] = "Linksklick"
L["Length"] = "Länge"
L["List"] = "Liste"
L["Lock"] = "Sperren"
L["Loop Playlist"] = "Liste wiederholen"
L["Loop Song"] = "Titel wiederholen"
L["Max song text length"] = "Maximale Titel Länge"
L["Middle click"] = "Mittelklick"
L["Middle Click"] = "Mittelklick"
L["Minimap Button"] = "Minimap Button"
L["Model Size"] = "Model Größe."
L["Mouse Setup"] = "Maus Einstellungen"
L["Moved song %s from list %s to list %s."] = "Song %s von Liste %s zu %s kopiert."
L["Move song to"] = "Lied verschieben nach"
L["Move song to favorite list"] = "Titel zu Favoriten verschieben."
L["MusicDancer"] = "MusikTänzer"
L["Music off"] = "Musik aus"
L["Music volume: "] = "Musik Lautst.: "
L["Mute"] = "Stumm"
L["Mute / unmute music sound."] = "Stummschalten an/aus"
L["[~mymusic~] "] = "[~meinemusik~] "
L["Next"] = "Weiter"
L["No Match"] = "Keine Treffer"
L["No Target"] = "Kein Ziel"
L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = "Ist mit Wow nicht möglich. Ein Addon kann Wow nur zum spielen oder stoppen eines Liedes bewegen das ist alles"
L["Party"] = "Gruppe"
L["Play"] = "Wiedergabe"
L["Playing song from history."] = "Spiele Lied aus der History"
L["Playing the last song of a list will not switch to the next list."] = "Am Ende einer Liste diese von vorn beginnen."
L["Play last"] = "Vorheriger Titel"
L["Play Last Song"] = "Vorherigen Titel spielen"
L["Playlist"] = "Liste"
L["Playlist error oO Playlist maybe empty."] = "Fehler in der Wiedergabeliste oO Liste vielleicht leer."
L["Playlist font"] = "Wiedergabeliste Zeichensatz"
L["Playlist not found."] = "Wiedergabeliste nicht gefunden."
L["Playlists"] = "Wiedergabelisten"
L["Playlist %s already exists."] = "Playlist %s existiert bereits."
L["Playlist Scale"] = "Skaliere Wiedergabeliste"
L["Playlists created with the playlist generator or addedy by the game music module are locked for editing."] = "Playlisten, die mit dem Playlist-Generator oder durch das Spielmusik-Modul hinzugefügt wurden, sind zum Bearbeiten gesperrt."
L["Playlist %s not found."] = "Playlist %s wurde nicht gefunden."
L["Playlist %s removed."] = "Playlist %s wurde entfernt."
L["Play Next Song"] = "Nächsten Titel spielen"
L["Plays a test song."] = "Spielt ein Testlied. "
L["Plays the last song."] = "Vorherigen Titel spielen"
L["Plays the next song."] = "Spielt nächstes Lied"
L["Play/Stop"] = "Wiedergabe/Stopp"
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "Den aktuellen Titel immer wieder und wieder spielen... bis der Kopf explodiert. Ein Klick auf nächstes Lied unterbricht dies."
L["Play the Music"] = "Musikwiedergabe starten."
L["Raid"] = "Schlachtzug"
L["Random Model"] = "Zufälliges Model"
L["Read the FAQ for more info about this."] = "Lies die FAQ für Einzelheiten"
L["Read the install file in the addon directory"] = "Bitte die Install-de.txt im Addonverzeichnis lesen."
L["Really remove playlist %s?"] = "Wirklich Playlist %s entfernen?"
L["Remove Playlist"] = "Liste entfernen"
L["Remove Song"] = "Lied entfernen"
L["Remove the playing song from list"] = "Das aktuelle Lied aus der Liste entfernen"
L["Reset GUI Position"] = "Standart GUI Position"
L["Reset Position"] = "Position rücksetzen"
L["Reset the GUI window position"] = "Zurücksetzen der GUI Fenster Position"
L["Right click"] = "Rechtsklick"
L["Right Click"] = "Rechtsklick"
L["Right click and drag to move this button"] = "Rechts Klick und ziehen um die Taste zu verschieben."
L["Say"] = "Sagen"
L["Scroll GUI Text"] = "Laufschrift im GUI"
L["Search..."] = "Suchen..."
L["Select a model"] = "Figur wählen"
L["Select a question from the left."] = "Wähle eine Frage von links"
L["Select the default channel to spam on ctrl+click"] = "Spam-Channel für strg+click auswählen"
L["Set Model"] = "Figur wählen"
L["Shift click"] = "Shift+klick"
L["Shift+Click"] = "Umschalt+Klick"
L["Show a random model when playing a new song."] = "Bei jedem neuen Titel zufälliges Model anzeigen."
L["Show Artist"] = "Interpret anzeigen"
L["Show Background"] = "Hintergrund anzeigen"
L["Show console commands"] = "Konsolenbefehle anzeigen"
L["Show Controls and Options"] = "Optionen anzeigen"
L["Show Dancer"] = "Tänzer Anzeigen"
L["Show GUI"] = "Zeige GUI"
L["Show/Hide Playlist"] = "Wiedergabeliste anzeigen/verstecken"
L["Show Info"] = "Info Fenster"
L["Showing/hiding the GUI will show/hide the dancer."] = "Zeigen/verstecken im GUI zeigt/versteckt auch Tänzer."
L["Show List/Song Numbers"] = "Liste/Titel Nr."
L["Show message in your chat when playing a new song."] = "Bei neuem Lied, Titel und Interpret im eigenen Chat anzeigen"
L["Show Pedestal"] = "Podest zeigen"
L["Show playlist and song number"] = "Liste und Titelnummer anzeigen"
L["Show song and artist on new song"] = "Bei neuem Lied Titel und Interpret anzeigen"
L["Show Song In Chat"] = "Titel im Chat anzeigen."
L["Show the Music."] = "Musikliste anzeigen."
L["Show time"] = "Zeit anzeigen"
L["Show Title"] = "Titel anzeigen"
L["Show Tooltip"] = "ToolTip anzeigen"
L["Show Update Info"] = "Zeige Update-Info"
L["Shuffle"] = "Zufällig"
L["Shuffle Cross Playlist"] = "Playlist mischen"
L["Song"] = "Titel"
L["Song is already in that list."] = "Das Lied ist bereits in dieser Liste."
L["Spam Link"] = "Lied Info Link"
L["Spam to"] = "Spam nach"
L["Spam to default channel"] = "An standart Channel spammen"
L["Stop"] = "Stopp"
L["Stopped"] = "Gestoppt"
L["Stop playing."] = "Musik anhalten"
L["Test"] = "Test"
L["The maximum text length of the song displayed in the Panel."] = "Maximale Länge des Song Titels in der Leiste."
L["This is a wow bug since patch 2.4.3. I only could fix this so far that the song starts from start instead playing the game music. I have reported this in the eu forums but unless someone with an us account finally reports this in the us ui-forum blizzard developers will never fix this."] = "Dies ist ein Wow Fehler seit Patch 2.4.3. Ich konnte es nur dahingehend ändern das der Song von vorne spielt statt die Spielmusik. Laut Aussage eines anderen Benutzers aus dem US Forum wird Blizzard diesen Fehler niemals beheben."
L["This will set the model to the default size and attach it to the GUI."] = "Dies setzt das Model zu der Standart Größe und verankert es am GUI"
L["Title color"] = "Titelfarbe"
L["Toggle Mute"] = "Stummschalten an/aus"
L["Toggles auto play on load."] = "Beim Einloggen Wiedergabe starten"
L["Toggle show Artist"] = "Interpret anzeigen an/aus"
L["Toggle show GUI"] = "GUI anzeigen an/aus"
L["Toggle show minimap button"] = "Minimap Button anzeigen an/aus"
L["Toggle show model."] = "Tänzer anzeigen an/aus"
L["Toggle show time"] = "Zeit anzeigen an/aus"
L["Toggle show title"] = "Titel anzeigen an/aus"
L["Toggle shuffle"] = "Zufallswiedergabe an/aus"
L["Toggle with GUI"] = "An/aus mit GUI"
L["To target"] = "Zu Ziel"
L["Unlock to allow moving the model. Moving will release the model from the GUI. Use reset to reattach."] = "Entsperren um das Model zu bewegen. Bewegen löst das Model vom GUI. Benutze reset zum wiederverankern."
L["Use artist color"] = "Benutze Interpretfarbe"
L["Use artist color as button color"] = "Benutze Interpretfarbe als Tastenfarbe"
L["Use scroll wheel - adjust music volume"] = "Benutze Mausrad - Einstellung der Musik Lautstärke"
L["Where the hell is the playlist?"] = "Wo zur Hölle ist die Wiedergabeliste?"
L["Whisper to"] = "Flüstern zu"
L["Why are some playlists grey?"] = "Warum sind manche Playlisten grau?"
L["Why is there no pause button?"] = "Warum gibt es keine Pausetaste"
L["Why is the song playing from the beginning after a loading screen?"] = "Warum spielt das Lied nach einem Ladebildschirm wieder von Anfang ?"
L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = "..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"
L["You can only remove playlists created ingame or with the playlist manager (not the playlist generator)!"] = "Du kannst nur Playlisten, die ingame erstellt wurden, entfernen oder mit dem Playlist-Manager (nicht der Playlist-Generator)!"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "frFR")
if L then
	L["Add a youtube link to chat spam."] = "Ajouter un lien Youtube au ChatSpam"
L["Added playlist %s."] = "Playlist ajoutée %s." -- Needs review
L["Add Playlist"] = "Ajouter une playlist" -- Needs review
L["Adjust the scale of the playlist"] = "Ajuster l’échelle de la playlist"
L["Adjust the size of the GUI"] = "Ajuster la taille de l'interface"
L["Adjust the size of the model frame"] = "Ajuste la taille du cadre" -- Needs review
L["Album"] = "Album"
L["Alt click"] = "Alt clic" -- Needs review
L["Alt+Click"] = "Alt+Clic" -- Needs review
L["Alt+Control+Click"] = "Alt+Control+Clic" -- Needs review
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + molette - Ajuster le volume"
L["Artist"] = "Artiste"
L["Artist color"] = "Couleur associée à l'artiste"
L["Autoplay"] = "Autoplay"
L["Background color"] = "Couleur d'arrière plan"
L["Border color"] = "Couleur de la bordure"
L["Button4"] = "Bouton4"
L["Button5"] = "Bouton5"
L["Button color"] = "Couleur des boutons"
L["Change the playlist font. Requires relog to take effect."] = "Change la police de la playlist. Nécessite un redémarrage du jeu pour prendre effet."
L["Clear"] = "Effacer"
L["Click me or scroll me. I won't bite. 8==8"] = "Clique ou déroule moi ... Je ne mords pas. ! Zap !" -- Needs review
L["Close"] = "Fermer"
L["Colours"] = "Couleurs"
L["Config"] = "Configuration"
L["Console"] = "Console"
L["Console Controls"] = "Contrôles de la console"
L["Control+Click"] = "Control+Clic" -- Needs review
L["Controls"] = "Contrôles "
L["Copied song"] = "Titre copié"
L["Copied song %s to List %s."] = "Chanson copiée de %s vers la list %s." -- Needs review
L["Copy song to"] = "Copier le titre vers" -- Needs review
L["Ctrl click"] = "Ctrl clic" -- Needs review
L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = "Ctrl Clic - Ecrit l'artiste et le nom du morceau sur le canal par défaut (Guilde, groupe ...)" -- Needs review
L["Ctrl + use scroll wheel - adjust effects volume"] = "Ctrl + molette - Ajuster le volume des effets"
L["Current will be moved on playing next song."] = "Le titre actuel sera déplacé lors de la lecture du prochain titre."
L["Default Channel"] = "Canal par défaut"
L["Disable WoW Music"] = "Désactiver la musique WoW"
L["Disable WoW Music when not Playing."] = "Désactiver la musique WoW quand je ne joue pas."
L["Do I have to copy all of my music files to the wow folder?"] = "Est-ce que je dois copier tous mes fichiers musicaux dans mon répertoire wow ?"
L["Drop Down Menu"] = "Menu déroulant"
L["Effects vol.: "] = "Volume des effets :"
L["Effects volume: "] = "Volume des effets :"
L["Enable Mouse"] = "Activer la souris"
L["EpicMusicPlayer Update Info"] = "EpicMusicPlayer Infos de mise à jour"
L["FAQ-Text1"] = [=[1. Fermer Wow s'il tourne !
Double cliquer sur "PlaylistManager.exe" dans le répertoire Playlistmanager de l'addon.

2. Cliquer sur File > Add Music Folder, choisir le répertoire avec votre musique et cliquer sur ouvrir.
OU
Glisser-déplacer vos mp3 ou vos dossiers dans el Playlist-Manager.

3. Fermer EMP-Playlist-Manager (assurez vous de cliquer sur "Oui" sauvegarder les playlist.)
Lancer Wow and appréciez votre musique pendant votre farming :)]=]
L["FAQ-Text2"] = [=[ 
No. The Playlist Manager can create links (inside the wow folder) that point to your original music folder. That way wow thinks the files are in the wow folder.

You can enable this by:
Windows Vista:
Just go to "Tools > Options" and change copy to create links.

Windows XP:
Download junction.exe from microsoft: http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx and put it into the junction folder of the playlist manager.

You should also install "ntfslink" (http://elsdoerfer.name/=ntfslink ) To make the use of the links (junctions) save with windos xp. See http://en.wikipedia.org/wiki/NTFS_junction_point#Windows_XP_Professional for more information.

And now go to "Tools > Options" and change copy to create links. 
]=]
L["Favorites List"] = "Liste des favoris" -- Needs review
L["Font"] = "Police"
L["Font & Colors"] = "Police et couleurs"
L["Font & Colours"] = "Police et couleurs"
L["Frame strata"] = "Couche du cadre" -- Needs review
L["Frequently Asked Questions"] = "FAQ"
L["Game Music"] = "Musiques du jeu" -- Needs review
L["General"] = "Général"
L["GUI"] = "Interface"
L["GUI Layout"] = "Aspect de l'interface"
L["Guild"] = "Guilde"
L["GUI not found"] = "Interface non trouvée"
L["GUI Size"] = "Taille de l'interface"
L["Help - FAQ"] = "Aide - FAQ"
L["Hide Artist in Playlist"] = "Cacher l'artiste dans la playlist" -- Needs review
L["How do I add music to the player?"] = "Comment ajouter de la musique au Player ?"
L["Last"] = "Dernier"
L["Last playlist can not be removed."] = "La dernière playlist ne peut pas être supprimée"
L["Layout & Skin"] = "Apparence & Skin"
L["Left click"] = "Clique gauche"
L["Left Click"] = "Clique gauche"
L["Length"] = "Durée"
L["List"] = "Liste"
L["Lock"] = "Vérrouiller" -- Needs review
L["Loop Playlist"] = "Rejouer la Playlist"
L["Loop Song"] = "Rejouer le titre"
L["Max song text length"] = "Taille maximale du texte du titre"
L["Middle click"] = "Clic molette" -- Needs review
L["Middle Click"] = "Clique molette"
L["Minimap Button"] = "Bouton de la minimap"
L["Model Size"] = "Taille du modèle"
L["Mouse Setup"] = "Configuration de la souris"
L["Moved song %s from list %s to list %s."] = "Chanson déplacé %s de la liste %s vers la liste %s." -- Needs review
L["Move song to"] = "Déplacer le titre vers"
L["Move song to favorite list"] = "Déplacer le titre vers les favoris"
L["MusicDancer"] = "DanseurMusical" -- Needs review
L["Music off"] = "Musique désactivée"
L["Music volume: "] = "Volume musique :"
L["Mute"] = "Muet"
L["Mute / unmute music sound."] = "Activer / désactiver "
L["[~mymusic~] "] = "[~mamusique~] " -- Needs review
L["Next"] = "Suivant"
L["No Match"] = "Aucune correspondance"
L["No Target"] = "Pas de cible"
L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = "Impossible avec WoW. Lorsqu'il joue un titre spécifique, un addon peut uniquement lui dire de lancer ou stopper le titre, c'est tout !"
L["Party"] = "Groupe"
L["Play"] = "Jouer"
L["Playing song from history."] = "Jouer un titre depuis l'historique"
L["Playing the last song of a list will not switch to the next list."] = "Jouer le dernier titre d'une liste ne fera pas passer à la liste suivante."
L["Play last"] = "Jouer le dernier"
L["Play Last Song"] = "Jouer le titre précédent"
L["Playlist"] = "Playlist"
L["Playlist error oO Playlist maybe empty."] = "Erreur de Playlist oO Peut-être est-elle vide." -- Needs review
L["Playlist font"] = "Police de la playlist"
L["Playlist not found."] = "Playlist non trouvée." -- Needs review
L["Playlists"] = "Playlists"
L["Playlist %s already exists."] = "La playlist %s existe déjà." -- Needs review
L["Playlist Scale"] = "Echelle de la playlist"
L["Playlists created with the playlist generator or addedy by the game music module are locked for editing."] = "Les playlists créées avec le générateur de playlist ou ajoutées avec le module du jeu sont vérrouillées pour l'édition." -- Needs review
L["Playlist %s not found."] = "Playlist %s non trouvée." -- Needs review
L["Playlist %s removed."] = "Playlist %s effacée." -- Needs review
L["Play Next Song"] = "Jouer le titre suivant"
L["Plays a test song."] = "Joue un morceau test."
L["Plays the last song."] = "Lance le dernier titre."
L["Plays the next song."] = "Lance le titre suivant"
L["Play/Stop"] = "Jouer/Arrêter"
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "Jouer le titre en cours encore et encore et encore .... jusqu'à ce que votre tête explose. Un clique sur le titre suivant désactive cette fonctionnalité."
L["Play the Music"] = "Jouer la musique"
L["Raid"] = "Raid"
L["Random Model"] = "Modèle aléatoire"
L["Read the FAQ for more info about this."] = "Lire la FAQ pour plus d'informations à ce sujet."
L["Read the install file in the addon directory"] = "Lisez le fichier d'installation dans le répertoire de l'addon"
L["Really remove playlist %s?"] = "Voulez-vous vraiment effacer la playlist %s?" -- Needs review
L["Remove Playlist"] = "Retirer de la Playlist"
L["Remove Song"] = "Supprimer le titre"
L["Remove the playing song from list"] = "Retirer le titre en cours de la liste"
L["Reset GUI Position"] = "Réinitialise la position de l'interface." -- Needs review
L["Reset Position"] = "Réinitialiser la position" -- Needs review
L["Reset the GUI window position"] = "Réinitialise la position de la fenêtre d'interface." -- Needs review
L["Right click"] = "Clique droit"
L["Right Click"] = "Clique droit"
L["Right click and drag to move this button"] = "Clique droit et glissez pour bouger ce bouton"
L["Say"] = "Dire"
L["Scroll GUI Text"] = "Déroule le texte de l'interface"
L["Search..."] = "Chercher..." -- Needs review
L["Select a model"] = "Choisir un modèle"
L["Select a question from the left."] = "Choisir une question sur la gauche."
L["Select the default channel to spam on ctrl+click"] = "Sélectionner le canal par défaut pour spammer en faisant Ctrl+Clic" -- Needs review
L["Set Model"] = "Définir le modèle"
L["Shift click"] = "Shift clic" -- Needs review
L["Shift+Click"] = "Shift+Clic" -- Needs review
L["Show a random model when playing a new song."] = "Montrer un modèle différent à chaque titre."
L["Show Artist"] = "Voir l'artiste"
L["Show Background"] = "Voir le fond"
L["Show console commands"] = "Montrer les commandes console"
L["Show Controls and Options"] = "Montrer les contrôles et les options"
L["Show Dancer"] = "Montrer le danceur"
L["Show GUI"] = "Montre l'interface"
L["Show/Hide Playlist"] = "Montrer/cacher la Playlist"
L["Show Info"] = "Montrer les infos"
L["Showing/hiding the GUI will show/hide the dancer."] = "Montrer/cacher l'interface Montrera/cachera le danseur."
L["Show List/Song Numbers"] = "Montrer le nombre de Listes/Titres"
L["Show message in your chat when playing a new song."] = "Affiche un message dans votre chat lorsqu'une nouvelle chanson est jouée." -- Needs review
L["Show Pedestal"] = "Voir le piedestal"
L["Show playlist and song number"] = "Montrer la playlist et le numéro du titre"
L["Show song and artist on new song"] = "Montrer le titre et l'artiste à chaque nouveau titre"
L["Show Song In Chat"] = "Montrer le titre dans le Chat"
L["Show the Music."] = "Montrer la musique."
L["Show time"] = "Montrer le temps"
L["Show Title"] = "Montrer le Morceau"
L["Show Tooltip"] = "Voir l'infobulle"
L["Show Update Info"] = "Afficher les informations de la mise à jour" -- Needs review
L["Shuffle"] = "Aléatoire"
L["Shuffle Cross Playlist"] = "Playlist aléatoire" -- Needs review
L["Song"] = "Titre"
L["Song is already in that list."] = "Le titre est déjà dans cette liste."
L["Spam Link"] = "Lien de spam"
L["Spam to"] = "Spam à"
L["Spam to default channel"] = "Spam le canal par défaut"
L["Stop"] = "Stop"
L["Stopped"] = "Arrêté"
L["Stop playing."] = "Arrêter la lecture" -- Needs review
L["Test"] = "Test"
L["The maximum text length of the song displayed in the Panel."] = "La taille maximale du titre du morceau montré dans l'interface."
L["This is a wow bug since patch 2.4.3. I only could fix this so far that the song starts from start instead playing the game music. I have reported this in the eu forums but unless someone with an us account finally reports this in the us ui-forum blizzard developers will never fix this."] = "C'est un bug depuis le patch 2.4.3. Je peux seulement faire en sorte que la musique soit lancée à la place d'une musique du jeu. J'ai déjà reporté ce soucis sur les forums EU mais tant qu'aucun joueur US n'aura reporté ce soucis, les développeurs Blizzard ne travailleront pas à le résoudre."
L["This will set the model to the default size and attach it to the GUI."] = "Définit la taille du modèle à celle par défaut et l'attache à l'interface."
L["Title color"] = "Couleur du titre."
L["Toggle Mute"] = "Activer/désactiver le mode muet"
L["Toggles auto play on load."] = "Active/désactive la lecture automatique au lancement"
L["Toggle show Artist"] = "Activer/désactiver l'affichage de l'artiste"
L["Toggle show GUI"] = "Affiche/cache l'interface"
L["Toggle show minimap button"] = "Montre/cache le bouton de la minimap"
L["Toggle show model."] = "Activer/désactiver l'affichage du modèle"
L["Toggle show time"] = "Activer/désactiver l'affichage du temps"
L["Toggle show title"] = "Activer/désactiver l'affichage du Morceau"
L["Toggle shuffle"] = "Active/désactive le mode aléatoire"
L["Toggle with GUI"] = "Affiche/cache l'interface"
L["To target"] = "À la cible" -- Needs review
L["Unlock to allow moving the model. Moving will release the model from the GUI. Use reset to reattach."] = "Déverrouiller pour permettre de bouger le modèle. Le bouger libère le modèle de l'interface. Utiliser Réinitialiser pour le réattacher." -- Needs review
L["Use artist color"] = "Utiliser la couleur de l'artiste"
L["Use artist color as button color"] = "Utiliser la couleur de l'artiste comme couleur de bouton"
L["Use scroll wheel - adjust music volume"] = "Utiliser la molette - Ajuster le volume de la musique"
L["Where the hell is the playlist?"] = "Mais où est cette satanée playlist ?" -- Needs review
L["Whisper to"] = "Chuchoter à"
L["Why are some playlists grey?"] = "Pourquoi des playlists sont grises ?" -- Needs review
L["Why is there no pause button?"] = "Pourquoi n'y a t'il pas de bouton pause ?!" -- Needs review
L["Why is the song playing from the beginning after a loading screen?"] = "Pourquoi le titre se relance dès le début aprés un écran de chargement ?" -- Needs review
L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = "..\\World of Warcraft\\WTF\\Account\\REDOOLZISANOOB\\SavedVariables\\EpicMusicPlayer.lua"
L["You can only remove playlists created ingame or with the playlist manager (not the playlist generator)!"] = "Vous ne pouvez effacer les playlists créées que dans le jeu ou avec le playlist manager" -- Needs review

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "koKR")
if L then
	L["Add a youtube link to chat spam."] = "Add a youtube link to chat spam."
L["Add Playlist"] = "재생 목록에 추가"
L["Adjust the scale of the playlist"] = "재생 목록의 크기를 조정"
L["Adjust the size of the GUI"] = "GUl의 크기 조정"
L["Adjust the size of the model frame"] = "모델 프레임 크기 조정"
L["Album"] = "앨범"
L["Alt click"] = "Alt click"
L["Alt+Click"] = "Alt+Click"
L["Alt+Control+Click"] = "Alt+Control+Click"
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + 휠스크롤 - 볼륨 조절"
L["Artist"] = "가수"
L["Artist color"] = "Artist color" -- Needs review
L["Autoplay"] = "자동 재생"
L["Background color"] = "배경 색상"
L["Border color"] = "테두리 색상"
L["Button4"] = "Button4"
L["Button5"] = "Button5"
L["Button color"] = "버튼 색상"
L["Click me or scroll me. I won't bite. 8==8"] = "날 클릭하거나 스크롤 할수있습니다. 난 물지 않아!.8==8"
L["Close"] = "닫기"
L["Colours"] = "색상"
L["Config"] = "설정"
L["Console"] = "콘솔"
L["Control+Click"] = "Control+Click"
L["Controls"] = "Controls"
L["Copied song"] = "복사한 노래"
L["Copy song to"] = "노래 복사"
L["Ctrl click"] = "Ctrl 클릭"
L["Ctrl + use scroll wheel - adjust effects volume"] = "Ctrl +휠스크롤 - 음량 효과 조절"
L["Current will be moved on playing next song."] = "다음 곡을 연주 이동됩니다."
L["Default Channel"] = "기본 채널"
L["Disable WoW Music"] = "비활성 와우 음악"
L["Do I have to copy all of my music files to the wow folder?"] = "와우 폴더로 음악 파일을 모두 복사해야하나요?"
L["Drop Down Menu"] = "드롭 다운 메뉴"
L["Effects vol.: "] = "효과 볼륨:"
L["Effects volume: "] = "볼륨 효과:"
L["Enable Mouse"] = "마우스 사용"
L["EpicMusicPlayer Update Info"] = "EpicMusicPlayer 업데이트 정보"
L["FAQ-Text1"] = [=[
1. 우선 와우를 종료합니다.
AddOns\EpicMusicPlayer\Playlistmanager 안에 있는 PlaylistManager.exe 를 실행

2. 실행하고 동의 후 File > Add Music Folder를 클릭  원하는 폴더를 누른후 열기 누름
또는 음악 파일 또는 폴더를 Playlist-Manager로 드래그 하십시요
3. EMP-Playlist-Manager를 닫기하시면 Save Playlist나옵니다 Yes클릭합니다.
와우를 시작해서 음악을 들으면 됩니다.]=]
L["Favorites List"] = "즐겨찾기 목록"
L["Font"] = "글꼴"
L["Font & Colors"] = "글꼴 & 색상"
L["Font & Colours"] = "글꼴 & 색상"
L["Frequently Asked Questions"] = "자주 묻는 질문"
L["Game Music"] = "게임 음악"
L["General"] = "일반"
L["GUI Layout"] = "GUl 레이아웃"
L["Guild"] = "길드"
L["Help - FAQ"] = "도움말 - FAQ"
L["How do I add music to the player?"] = "플레이어에 음악을 추가하려면 어떻게합니까?"
L["Last"] = "마지막곡"
L["Last playlist can not be removed."] = "마지막임으로 재생 목록을 제거할 수 없습니다."
L["Left click"] = "왼쪽 클릭"
L["Left Click"] = "왼쪽 클릭"
L["Length"] = "길이"
L["List"] = "목록"
L["Lock"] = "잠금"
L["Loop Playlist"] = "Loop 재생목록"
L["Loop Song"] = "Loop Song"
L["Max song text length"] = "노래 텍스트 길이"
L["Middle click"] = "가운데 클릭"
L["Middle Click"] = "가운데 클릭"
L["Minimap Button"] = "미니맵 버튼"
L["Model Size"] = "모델 사이즈"
L["Mouse Setup"] = "마우스 설정"
L["Move song to"] = "노래 이동"
L["Move song to favorite list"] = "즐겨찾기 목록으로 노래 이동"
L["MusicDancer"] = "음악댄서"
L["Music off"] = "음악 끔"
L["Music volume: "] = "음악 볼륨:"
L["Mute"] = "음소거"
L["Mute / unmute music sound."] = "음소거 / 음소거 해제 음악 소리."
L["[~mymusic~] "] = "[~mymusic~] "
L["Next"] = "다음곡"
L["No Target"] = "대상 없음"
L["Party"] = "파티"
L["Play"] = "재생"
L["Playing song from history."] = "history 노래 재생"
L["Play Last Song"] = "재생 마지막 노래"
L["Playlist"] = "재생목록"
L["Playlist error oO Playlist maybe empty."] = "재생  목록 오류oO 재생 목록이 없습니다."
L["Playlist font"] = "재생 목록 글꼴"
L["Playlist not found."] = "재생 목록이 없습니다."
L["Playlists"] = "재생목록"
L["Playlist Scale"] = "재생 목록 크기"
L["Play Next Song"] = "다음 노래 재생"
L["Plays the last song."] = "마지막 노래를 재생합니다."
L["Plays the next song."] = "다음 노래를 재생합니다."
L["Play/Stop"] = "재생/정지"
L["Play the Music"] = "음악 재생"
L["Raid"] = "레이드"
L["Random Model"] = "랜덤 모델"
L["Read the FAQ for more info about this."] = "이것에 대해 자세한 내용은 FAQ를 참조하십시오."
L["Read the install file in the addon directory"] = "애드온 폴더에서 설치 파일 읽기"
L["Remove Playlist"] = "재생 목록 제거"
L["Remove Song"] = "노래 삭제"
L["Remove the playing song from list"] = "재생 목록에서 노래를 제거"
L["Reset Position"] = "위치 재설정"
L["Right click"] = "오른쪽 클릭"
L["Right Click"] = "오른쪽 클릭"
L["Right click and drag to move this button"] = "마우스 오른쪽 버튼으로 클릭하고  드래그로 이동"
L["Scroll GUI Text"] = "Scroll GUI Text"
L["Search..."] = "검색"
L["Select a model"] = "모델 선택"
L["Select a question from the left."] = "왼쪽에서 질문을 선택합니다."
L["Set Model"] = "모델 세트"
L["Shift click"] = "Shift 클릭"
L["Shift+Click"] = "Shift+Click"
L["Show a random model when playing a new song."] = "새 노래를 재생할 때 임의의 모델을 표시합니다."
L["Show Artist"] = "가수 보기"
L["Show Background"] = "배경 표시"
L["Show console commands"] = "콘솔 명령 보기"
L["Show Dancer"] = "댄서 보기"
L["Show GUI"] = "GUl 보기"
L["Show Info"] = "표시 정보"
L["Show List/Song Numbers"] = "목록 표시 / 노래 번호"
L["Show message in your chat when playing a new song."] = "새 노래를 재생할때 채팅창에 메시지 표시"
L["Show song and artist on new song"] = "새 노래 제목과 가수 표시"
L["Show Song In Chat"] = "노래 채팅에 표시"
L["Show the Music."] = "음악을 표시합니다."
L["Show time"] = "시간 표시"
L["Show Title"] = "제목 보기"
L["Show Tooltip"] = "툴팁 보기"
L["Shuffle"] = "셔플"
L["Song"] = "노래"
L["Song is already in that list."] = "노래가 이미 목록에 있습니다."
L["Stop"] = "정지"
L["Stopped"] = "정지"
L["Stop playing."] = "재생 그만"
L["The maximum text length of the song displayed in the Panel."] = "노래의 최대 문자 길이는 패널에 표시됩니다."
L["This will set the model to the default size and attach it to the GUI."] = "이것이 기본 크기로 모델을 설정하고 GUI에 그것을 첨부합니다."
L["Title color"] = "제목 색상"
L["Toggle show minimap button"] = "미니맵에 버튼 표시"
L["Use scroll wheel - adjust music volume"] = "휠 스크롤 사용- 음악 볼륨 조절"
L["Where the hell is the playlist?"] = "대체 재생 목록이 무엇입니까?"
L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = "..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "zhTW")
if L then
	L["Add a youtube link to chat spam."] = "添加一個Youtube鏈結到聊天資訊中."
L["Add Playlist"] = "添加播放列表"
L["Adjust the scale of the playlist"] = "調整播放清單大小"
L["Adjust the size of the GUI"] = "調整圖形介面尺寸"
L["Adjust the size of the model frame"] = "控制模型的大小"
L["Album"] = "專輯"
L["Alt click"] = "Alt+單擊"
L["Alt+Click"] = "Alt+點擊"
L["Alt+Control+Click"] = "Alt+Ctrl+點擊"
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + 中間滾動來控制主音量"
L["Artist"] = "歌手"
L["Artist color"] = "歌手顏色"
L["Autoplay"] = "自動播放"
L["Background color"] = "背景顏色"
L["Border color"] = "邊緣顏色"
L["Button4"] = "按鈕4"
L["Button5"] = "按鈕5"
L["Button color"] = "按鈕顏色"
L["Change the playlist font. Requires relog to take effect."] = "更改播放清單字體。需要relog生效。" -- Needs review
L["Clear"] = "清除"
L["Click me or scroll me. I won't bite. 8==8"] = "點擊我或者滑動我. . 8==8"
L["Close"] = "關閉"
L["Colours"] = "顏色"
L["Config"] = "設置"
L["Console"] = "控制"
L["Console Controls"] = "控制"
L["Control+Click"] = "ctrl單擊"
L["Controls"] = "控制"
L["Copied song"] = "已複製歌曲"
L["Copy song to"] = "複製歌曲到"
L["Ctrl click"] = "Ctrl+單擊"
L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = "Ctrl 點擊 - 寫入歌手和標題到預設的頻道。(公會、隊伍 等)"
L["Ctrl + use scroll wheel - adjust effects volume"] = "Ctrl + 中鍵滾動來控制音效音量"
L["Default Channel"] = "默認頻道"
L["Disable WoW Music"] = "關閉WOW聲音"
L["Disable WoW Music when not Playing."] = "不播放時關閉WOW的聲音"
L["Drop Down Menu"] = "降低菜單"
L["Effects vol.: "] = "音效音量.: "
L["Effects volume: "] = "音效音量: "
L["Enable Mouse"] = "啟用鼠標"
L["EpicMusicPlayer Update Info"] = "EpicMusicPlayer 更新訊息"
L["FAQ-Text1"] = [=[
1. 退出遊戲!
  雙擊開啟 "PlaylistManager.exe" 在Addon裡的Playlistmanger資料夾中。

2. 點擊 File > Add Music Folder, 選擇你的音樂資料夾,然後打開。
  或
  只需拖放mp3文件/資料夾到Playlist-Manager。

3. 關閉 EMP-Playlist-Manager (一定要點擊 "Yes" 儲存播放列表。)
  開啟魔獸世界然後享受它:)
]=] -- Needs review
L["Favorites List"] = "歌曲紅名單"
L["Font"] = "字體"
L["Font & Colors"] = "字體 & 顏色"
L["Font & Colours"] = "字體 & 顏色"
L["Frame strata"] = "層"
L["Frequently Asked Questions"] = "常見問題"
L["Game Music"] = "遊戲音樂"
L["General"] = "綜合"
L["GUI"] = "圖形介面"
L["GUI Layout"] = "圖形佈局"
L["Guild"] = "公會"
L["GUI not found"] = "圖形介面未發現"
L["GUI Size"] = "圖形介面大小"
L["Help - FAQ"] = "說明 - FAQ"
L["How do I add music to the player?"] = "我該如何新增音樂到播放器?"
L["Last"] = "上一曲"
L["Last playlist can not be removed."] = "上一個列表不能刪除."
L["Layout & Skin"] = "佈置 & 介面"
L["Left click"] = "左鍵單擊"
L["Left Click"] = "左鍵單擊"
L["Length"] = "長度"
L["List"] = "列表"
L["Lock"] = "鎖定"
L["Loop Playlist"] = "迴圈播放列表"
L["Loop Song"] = "單曲迴圈"
L["Max song text length"] = "歌名文本最大長度"
L["Middle click"] = "中鍵單擊"
L["Middle Click"] = "中鍵單擊"
L["Minimap Button"] = "小地圖按鈕"
L["Model Size"] = "模型大小"
L["Mouse Setup"] = "滑鼠控制"
L["Move song to"] = "移動歌曲到"
L["Move song to favorite list"] = "移動到歌曲紅名單."
L["MusicDancer"] = "舞者"
L["Music off"] = "音樂關閉"
L["Music volume: "] = "音樂音量: "
L["Mute"] = "靜音"
L["Mute / unmute music sound."] = "打開關閉音樂聲音"
L["[~mymusic~] "] = "[~我的音樂~] "
L["Next"] = "下一曲"
L["No Match"] = "不匹配"
L["No Target"] = "無目標"
L["Party"] = "小隊"
L["Play"] = "播放"
L["Playing song from history."] = "從歷史紀錄播放歌曲。"
L["Playing the last song of a list will not switch to the next list."] = "播放列表最後一首歌曲時是否切換到下一列表."
L["Play last"] = "播放上一個"
L["Play Last Song"] = "上一曲"
L["Playlist"] = "播放列表"
L["Playlist error oO Playlist maybe empty."] = "播放列表錯誤，可能列表無檔."
L["Playlist font"] = "播放列表字體"
L["Playlist not found."] = "播放列表未找到."
L["Playlists"] = "播放列表"
L["Playlist Scale"] = "播放列表縮放"
L["Play Next Song"] = "下一曲"
L["Plays a test song."] = "播放測試歌曲"
L["Plays the last song."] = "播放上一曲"
L["Plays the next song."] = "播放下一首歌"
L["Play/Stop"] = "播放/停止"
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "單曲迴圈，迴圈到你頭痛為止，單擊另一首歌曲會取消單曲迴圈."
L["Play the Music"] = "播放音樂."
L["Raid"] = "團隊"
L["Random Model"] = "隨機模型"
L["Read the FAQ for more info about this."] = "閱讀FAQ獲得關於這方面更多的資訊。"
L["Read the install file in the addon directory"] = "請查看插件文件夾的install文件說明."
L["Remove Playlist"] = "刪除播放列表"
L["Remove Song"] = "刪除歌曲"
L["Remove the playing song from list"] = "從播放列表中刪除歌曲"
L["Reset GUI Position"] = "重置圖形介面位置"
L["Reset Position"] = "重置位置"
L["Reset the GUI window position"] = "重置圖形介面視窗位置"
L["Right click"] = "右鍵單擊"
L["Right Click"] = "右鍵單擊"
L["Right click and drag to move this button"] = "右鍵單擊拖動這個按鈕."
L["Say"] = "說"
L["Scroll GUI Text"] = "滾動圖形介面文字"
L["Search..."] = "搜索..."
L["Select a model"] = "選擇模型"
L["Select the default channel to spam on ctrl+click"] = "選擇播放資訊發送的頻道"
L["Set Model"] = "設置模型"
L["Shift click"] = "Shift+單擊"
L["Shift+Click"] = "shift單擊"
L["Show a random model when playing a new song."] = "播放一首新的歌曲時隨機模型."
L["Show Artist"] = "顯示歌手"
L["Show Background"] = "顯示背景"
L["Show console commands"] = "顯示控制命令"
L["Show Controls and Options"] = "設置"
L["Show Dancer"] = "顯示舞者"
L["Show GUI"] = "顯示圖形介面"
L["Show/Hide Playlist"] = "是否顯示列表"
L["Show Info"] = "顯示資訊"
L["Showing/hiding the GUI will show/hide the dancer."] = "顯示/隱藏 圖形介面 顯示/隱藏 舞者。"
L["Show List/Song Numbers"] = "顯示列表/歌曲編號"
L["Show message in your chat when playing a new song."] = "在你播放一首新的歌曲時在聊天視窗中顯示"
L["Show Pedestal"] = "顯示台座"
L["Show playlist and song number"] = "顯示列表/歌曲編號"
L["Show song and artist on new song"] = "顯示歌曲名和歌手"
L["Show Song In Chat"] = "聊天中顯示歌名."
L["Show the Music."] = "顯示音樂列表."
L["Show time"] = "顯示時間"
L["Show Title"] = "顯示歌曲名"
L["Show Tooltip"] = "顯示tip"
L["Shuffle"] = "隨機播放"
L["Song"] = "歌名"
L["Song is already in that list."] = "那個列表已經有這個歌曲了."
L["Spam Link"] = "信息鏈結"
L["Spam to"] = "發送資訊到"
L["Spam to default channel"] = "播放資訊到默認頻道"
L["Stop"] = "停止"
L["Stopped"] = "已停止"
L["Stop playing."] = "停止播放"
L["Test"] = "測試"
L["The maximum text length of the song displayed in the Panel."] = "Titan面板上能顯示的最大歌曲名字數."
L["Title color"] = "標題顏色"
L["Toggle Mute"] = "靜音"
L["Toggles auto play on load."] = "控制是否在介面載入後就自動播放"
L["Toggle show Artist"] = "切換顯示歌手"
L["Toggle show GUI"] = "切換顯示圖形介面"
L["Toggle show minimap button"] = "是否顯示小地圖按鈕"
L["Toggle show model."] = "是否顯示舞者模型."
L["Toggle show time"] = "是否顯示時間"
L["Toggle show title"] = "是否顯示歌曲名"
L["Toggle shuffle"] = "控制是否開啟隨機播放"
L["Toggle with GUI"] = "切換圖形介面"
L["To target"] = "對目標"
L["Use artist color"] = "使用歌手顏色"
L["Use artist color as button color"] = "使用像按鈕顏色的歌手顏色"
L["Use scroll wheel - adjust music volume"] = "使用鼠標中鍵滾動來控制音樂音量"
L["Whisper to"] = "密語"
L["Why is there no pause button?"] = "為什麼沒有暫停按鈕?"
L["Why is the song playing from the beginning after a loading screen?"] = "為什麼播放歌曲後，從一開始就載入畫面?"
L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = "..\\World of Warcraft\\WTF\\Account\\帳號名稱\\SavedVariables\\EpicMusicPlayer.lua"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "zhCN")
if L then
	L["Add a youtube link to chat spam."] = "添加一个Youtube链接到聊天信息中."
L["Added playlist %s."] = "增加播放列表 %s." -- Needs review
L["Add Playlist"] = "添加播放列表"
L["Adjust the scale of the playlist"] = "调整播放列表的缩放" -- Needs review
L["Adjust the size of the GUI"] = "调整图形界面的大小" -- Needs review
L["Adjust the size of the model frame"] = "控制模型的大小"
L["Album"] = "专辑"
L["Alt click"] = "Alt+单击"
L["Alt+Click"] = "Alt单击"
L["Alt+Control+Click"] = "Alt+Ctrl+单击"
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + 中间滚动来控制主音量"
L["Artist"] = "歌手"
L["Artist color"] = "歌手颜色"
L["Autoplay"] = "自动播放"
L["Background color"] = "背景颜色"
L["Border color"] = "边缘颜色"
L["Button4"] = "按钮4"
L["Button5"] = "按钮5"
L["Button color"] = "按钮颜色"
L["Change the playlist font. Requires relog to take effect."] = "修改播放列表的字体.需要重新登录以生效." -- Needs review
L["Clear"] = "清除"
L["Click me or scroll me. I won't bite. 8==8"] = "点击我或者滑动我. . 8==8"
L["Close"] = "关闭"
L["Colours"] = "颜色"
L["Config"] = "设置"
L["Console"] = "控制"
L["Console Controls"] = "控制"
L["Control+Click"] = "ctrl单击"
L["Controls"] = "控制"
L["Copied song"] = "已复制歌曲"
L["Copied song %s to List %s."] = "复制音乐  %s 到列表 %s. " -- Needs review
L["Copy song to"] = "复制歌曲到"
L["Ctrl click"] = "Ctrl+单击"
L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = "Ctrl - 点击 - 发送艺术家和标题到默认聊天频道.(公会,小队,等等.)" -- Needs review
L["Ctrl + use scroll wheel - adjust effects volume"] = "Ctrl + 中键滚动来控制音效音量"
L["Current will be moved on playing next song."] = "当前的将被移动到播放下一首音乐." -- Needs review
L["Default Channel"] = "默认频道"
L["Disable WoW Music"] = "关闭WOW声音"
L["Disable WoW Music when not Playing."] = "不播放时关闭WOW的声音"
L["Do I have to copy all of my music files to the wow folder?"] = "如何将自己的音乐文件放入wow文件夹"
L["Drop Down Menu"] = "降低菜单"
L["Effects vol.: "] = "音效音量.: "
L["Effects volume: "] = "音效音量: "
L["Enable Mouse"] = "启用鼠标"
L["EpicMusicPlayer Update Info"] = "EpicMusicPlayer 更新信息" -- Needs review
L["FAQ-Text1"] = [=[1. 退出游戏！

 在插件目录下双击“PlaylistManager.exe ” 

2.点击 File> Add Music Folder,选择你要添加的音乐 

 或者 

 将mp3文件或文件目录直接拖入 PlaylistManager内]=]
L["FAQ-Text2"] = [=[不能直接加。Playlist Manager 可以创建指针（必须在wow文件目录内），使程序将你的个人音乐当做游戏内置音乐来播放。

你可以按如下方式操作：
Vista：Tool>Option 内直接创建

XP：
在微软官网上下载Junction.exe 放在playlist manager的junction目录下

安装ntfslink使XP链接生效

然后在tools>Options内复制粘贴创建链接 ]=]
L["Favorites List"] = "歌曲红名单"
L["Font"] = "字体" -- Needs review
L["Font & Colors"] = "字体t & 颜色" -- Needs review
L["Font & Colours"] = "字体 & 颜色" -- Needs review
L["Frame strata"] = "层"
L["Frequently Asked Questions"] = "FAQ" -- Needs review
L["Game Music"] = "游戏音乐" -- Needs review
L["General"] = "综合"
L["GUI"] = "图形界面" -- Needs review
L["GUI Layout"] = "图形界面布局" -- Needs review
L["Guild"] = "公会"
L["GUI not found"] = "未找到图形界面" -- Needs review
L["GUI Size"] = "图形界面大小" -- Needs review
L["Help - FAQ"] = "帮助 - FAQ" -- Needs review
L["Hide Artist in Playlist"] = "在播放列表中隐藏艺术家" -- Needs review
L["How do I add music to the player?"] = "如何增加音乐文件"
L["Last"] = "上一曲"
L["Last playlist can not be removed."] = "上一个列表不能删除."
L["Layout & Skin"] = "布局  & 皮肤" -- Needs review
L["Left click"] = "左键单击"
L["Left Click"] = "左键单击"
L["Length"] = "长度"
L["List"] = "列表"
L["Lock"] = "锁定"
L["Loop Playlist"] = "循环播放列表"
L["Loop Song"] = "单曲循环"
L["Max song text length"] = "歌名文本最大长度"
L["Middle click"] = "中键单击"
L["Middle Click"] = "中键单击"
L["Minimap Button"] = "小地图按钮"
L["Model Size"] = "模型大小"
L["Mouse Setup"] = "鼠标控制"
L["Moved song %s from list %s to list %s."] = "移除音乐 %s 自列表  %s 到列表  %s." -- Needs review
L["Move song to"] = "移动歌曲到"
L["Move song to favorite list"] = "移动到歌曲红名单."
L["MusicDancer"] = "舞者"
L["Music off"] = "音乐关" -- Needs review
L["Music volume: "] = "音乐音量: "
L["Mute"] = "静音"
L["Mute / unmute music sound."] = "打开关闭音乐声音"
L["[~mymusic~] "] = "[~我的音乐~] "
L["Next"] = "下一曲"
L["No Match"] = "不匹配"
L["No Target"] = "无目标"
L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = "wow不支持此功能，插件只能做到播放/停止播放，无法记录播放时长"
L["Party"] = "小队"
L["Play"] = "播放"
L["Playing song from history."] = "从历史记录中播放音乐." -- Needs review
L["Playing the last song of a list will not switch to the next list."] = "播放列表最后一首歌曲时是否切换到下一列表."
L["Play last"] = "播放上一个"
L["Play Last Song"] = "上一曲"
L["Playlist"] = "播放列表"
L["Playlist error oO Playlist maybe empty."] = "播放列表错误，可能列表无文件."
L["Playlist font"] = "播放列表字体" -- Needs review
L["Playlist not found."] = "播放列表未找到."
L["Playlists"] = "播放列表"
L["Playlist %s already exists."] = "播放列表 %s 已存在." -- Needs review
L["Playlist Scale"] = "播放列表缩放" -- Needs review
L["Playlists created with the playlist generator or addedy by the game music module are locked for editing."] = "播放列表生成器及游戏音乐模组已锁定，无法编辑"
L["Playlist %s not found."] = "播放列表 %s 未找到." -- Needs review
L["Playlist %s removed."] = "播放列表 %s 已移除." -- Needs review
L["Play Next Song"] = "下一曲"
L["Plays a test song."] = "播放一个测试音乐." -- Needs review
L["Plays the last song."] = "播放上一曲"
L["Plays the next song."] = "播放下一首音乐." -- Needs review
L["Play/Stop"] = "播放/停止"
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "单曲循环，循环到你头痛为止，单击另一首歌曲会取消单曲循环."
L["Play the Music"] = "播放音乐"
L["Raid"] = "团队"
L["Random Model"] = "随机模式"
L["Read the FAQ for more info about this."] = "阅读FAQ以获取更多帮助信息"
L["Read the install file in the addon directory"] = "请查看插件文件夹的install文件说明."
L["Really remove playlist %s?"] = "真的要移除播放列表 %s?" -- Needs review
L["Remove Playlist"] = "删除播放列表"
L["Remove Song"] = "删除歌曲"
L["Remove the playing song from list"] = "从播放列表中删除歌曲"
L["Reset GUI Position"] = "重置图形界面位置" -- Needs review
L["Reset Position"] = "重置位置"
L["Reset the GUI window position"] = "重置图形界面位置" -- Needs review
L["Right click"] = "右键单击"
L["Right Click"] = "右键单击"
L["Right click and drag to move this button"] = "右键单击拖动这个按钮."
L["Say"] = "说"
L["Scroll GUI Text"] = "滚动图形文本"
L["Search..."] = "搜索..."
L["Select a model"] = "选择模型"
L["Select a question from the left."] = "在左边选择一个问题"
L["Select the default channel to spam on ctrl+click"] = "选择播放信息发送的频道"
L["Set Model"] = "设置模型"
L["Shift click"] = "Shift+单击"
L["Shift+Click"] = "shift单击"
L["Show a random model when playing a new song."] = "播放一首新的歌曲时随机模型."
L["Show Artist"] = "显示艺术家" -- Needs review
L["Show Background"] = "显示背景"
L["Show console commands"] = "显示控制命令"
L["Show Controls and Options"] = "设置"
L["Show Dancer"] = "显示舞者"
L["Show GUI"] = "显示图形界面" -- Needs review
L["Show/Hide Playlist"] = "是否显示列表"
L["Show Info"] = "显示信息"
L["Showing/hiding the GUI will show/hide the dancer."] = "显示/隐藏图形界面将显示/隐藏舞者." -- Needs review
L["Show List/Song Numbers"] = "显示列表/歌曲编号"
L["Show message in your chat when playing a new song."] = "在你播放一首新的歌曲时在聊天窗口中显示"
L["Show Pedestal"] = "显示台座"
L["Show playlist and song number"] = "显示列表/歌曲编号"
L["Show song and artist on new song"] = "显示歌曲名和歌手"
L["Show Song In Chat"] = "聊天中显示歌名."
L["Show the Music."] = "显示音乐列表."
L["Show time"] = "显示时间"
L["Show Title"] = "显示歌曲名"
L["Show Tooltip"] = "显示提示信息"
L["Show Update Info"] = "显示更新信息" -- Needs review
L["Shuffle"] = "随机播放"
L["Shuffle Cross Playlist"] = "在不同列表内随机播放"
L["Song"] = "歌名"
L["Song is already in that list."] = "那个列表已经有这个歌曲了."
L["Spam Link"] = "信息链结"
L["Spam to"] = "发送信息到"
L["Spam to default channel"] = "播放信息到默认频道"
L["Stop"] = "停止"
L["Stopped"] = "已停止"
L["Stop playing."] = "停止播放"
L["Test"] = "测试" -- Needs review
L["The maximum text length of the song displayed in the Panel."] = "Titan面板上能显示的最大歌曲名字数."
L["This is a wow bug since patch 2.4.3. I only could fix this so far that the song starts from start instead playing the game music. I have reported this in the eu forums but unless someone with an us account finally reports this in the us ui-forum blizzard developers will never fix this."] = "这是一个自2.4.3就开始存在的bug。我已尽量修改此BUG，使其能够从头播放音乐文件。我已在欧服论坛汇报过bug，但是要修复此bug必须汇报至美服论坛。"
L["This will set the model to the default size and attach it to the GUI."] = "这个将设置模型为默认大小并吸附到图形界面." -- Needs review
L["Title color"] = "标题颜色"
L["Toggle Mute"] = "静音"
L["Toggles auto play on load."] = "控制是否在界面载入后就自动播放"
L["Toggle show Artist"] = "开启/关闭显示艺术家" -- Needs review
L["Toggle show GUI"] = "显示/隐藏图形界面" -- Needs review
L["Toggle show minimap button"] = "是否显示小地图按钮"
L["Toggle show model."] = "是否显示舞者模型."
L["Toggle show time"] = "是否显示时间"
L["Toggle show title"] = "是否显示歌曲名"
L["Toggle shuffle"] = "控制是否开启随机播放"
L["Toggle with GUI"] = "和图形界面一起启用/禁用" -- Needs review
L["To target"] = "对目标"
L["Unlock to allow moving the model. Moving will release the model from the GUI. Use reset to reattach."] = "解锁来允许移动模型. " -- Needs review
L["Use artist color"] = "使用艺术家颜色" -- Needs review
L["Use artist color as button color"] = "使用艺术家颜色为按钮颜色" -- Needs review
L["Use scroll wheel - adjust music volume"] = "使用鼠标中键滚动来控制音乐音量"
L["Where the hell is the playlist?"] = "播放列表究竟在哪？"
L["Whisper to"] = "密语"
L["Why are some playlists grey?"] = "为何有的曲目是灰色的"
L["Why is there no pause button?"] = "为何没有暂停键"
L["Why is the song playing from the beginning after a loading screen?"] = "为何重载界面后歌曲又会从头播放"
L["You can only remove playlists created ingame or with the playlist manager (not the playlist generator)!"] = "你只能移除在游戏内创建或播放列表管理器的播放列表（非播放列表生成器）"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "ruRU")
if L then
	L["Add a youtube link to chat spam."] = "Добавить ссылку для вывода в чат."
L["Added playlist %s."] = "Добавлен список %s."
L["Add Game Music"] = "Добавить игр. музыку"
L["Add Playlist"] = "Добавить список"
L["Adds playlists with game music (reload required)."] = "Добавляет списки воспроизведения с игровой музыкой (требуется перезагрузка)."
L["Adjust the scale of the playlist"] = "Регулировка масштаба списка воспроизведения."
L["Adjust the size of the GUI"] = "Регулировка размера интерфейса"
L["Adjust the size of the model frame"] = "Регулировка размера фрейма модели"
L["Album"] = "Альбом"
L["Alt click"] = "[Alt клик]"
L["Alt+Click"] = "[Alt+Клик]"
L["Alt+Control+Click"] = "[Alt+Control+Клик]"
L["Alt + use scroll wheel - fine adjust volume"] = "[Alt + колёсик мыши] - регулирует громкость"
L["Artist"] = "Исполнитель"
L["Artist color"] = "Цвет исполнителя"
L["Autoplay"] = "Авто-воспроизведение"
L["Background color"] = "Цвет фона"
L["Border color"] = "Цвет краев"
L["Button4"] = "Кнопка4"
L["Button5"] = "Кнопка5"
L["Button color"] = "Цвет кнопки"
L["Change the playlist font. Requires relog to take effect."] = "Изменение шрифта списка воспроизведений. Требуется перезагрузка UI."
L["Clear"] = "Очистить"
L["Click me or scroll me. I won't bite. 8==8"] = "Кликай по мне или прокручивай меня. Я не укушу. 8==8"
L["Close"] = "Закрыть"
L["Colours"] = "Окраска"
L["Config"] = "Настройка"
L["Console"] = "Консоль"
L["Console Controls"] = "Консольные средства управления"
L["Control+Click"] = "[Control+Клик]"
L["Controls"] = "Средства управления"
L["Copied song"] = "Копируемая композиция"
L["Copied song %s to List %s."] = "Песня %s, скопирована в список %s."
L["Copy song to"] = "Копировать композицию в"
L["Ctrl click"] = "[Ctrl клик]"
L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = "[Ctrl клик] - выводит исполнителя и название в чат по умолчанию. (гильдии,группы и т.д.)"
L["Ctrl + use scroll wheel - adjust effects volume"] = "[Ctrl + колёсик мыши] - регулирует громкость эффектов"
L["Current will be moved on playing next song."] = "Текущий будет перемещен для воспр. после след. песни."
L["Default Channel"] = "Канал по умолчанию"
L["Disable WoW Music"] = "Отключить WoW музыку"
L["Disable WoW Music when not Playing."] = "Отключить музыку WoW когда ничего не играет."
L["Do I have to copy all of my music files to the wow folder?"] = "Должен ли я скопировать все мои музыкальные файлы в папке WoW?"
L["Drop Down Menu"] = "Всплывающее меню"
L["Effects vol.: "] = "Громкость эфф.: "
L["Effects volume: "] = "Громкость эффектов: "
L["Enable Mouse"] = "Включить мышь"
L["EpicMusicPlayer Update Info"] = "Инфо обновления EpicMusicPlayer"
L["FAQ-Text1"] = [=[
1. Выйдите из Wow (если он запущен)!
  Дважды кликните по "create_playlist.bat" в папке Playlistmanger.
  (или попробуйте "EMP_Playlist_Manager.jar" / "PlaylistManager.exe")

2. Нажмите File > Add Music Folder, выберите папку с вашей музыкой и нажмите Open.
  ИЛИ
  Или просто перетащите несколько mp3 файла/папок в Playlist-Manager.

3. Закройте EMP-Playlist-Manager (Необхадимо нажать на "Yes" в окне Save Playlist (для сохранения).)
  Запустите WoW и наслаждайтесь вашей музыкой:)
]=]
L["FAQ-Text2"] = [=[ 
Нет. Playlist Manager может создавать ссылки (внутри папки WoW), которые указывают на ваш исходный каталог музыки. Таким образом, wow думает что файлы в папке WoW.

Вы можете включить это:
Windows Vista:
Перейдите в "Tools > Options" and change copy to create links.

Windows XP:
Скачайте junction.exe с microsoft: http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx и поместите в папку junction, playlist manager.

You should also install "ntfslink" (http://elsdoerfer.name/=ntfslink ) To make the use of the links (junctions) save with windos xp. See http://en.wikipedia.org/wiki/NTFS_junction_point#Windows_XP_Professional for more information.

And now go to "Tools > Options" and change copy to create links. 
]=]
L["Favorites List"] = "Список избранного"
L["Font"] = "Шрифт"
L["Font & Colors"] = "Шрифт и окраска"
L["Font & Colours"] = "Шрифт и окраска"
L["Frame strata"] = "Слой фрейма"
L["Frequently Asked Questions"] = "Часто задаваемые вопросы"
L["Game Music"] = "Игровая музыка"
L["General"] = "Основное"
L["GUI"] = "GUI"
L["GUI Layout"] = "Слой GUI"
L["Guild"] = "Гильдия"
L["GUI not found"] = "GUI не найден"
L["GUI Size"] = "Размер GUI"
L["Help - FAQ"] = "Справка - ЧАВО"
L["Hide Artist in Playlist"] = "Скрыть артиста в списке"
L["How do I add music to the player?"] = "Как я могу добавить музыку в плеер?"
L["Last"] = "Предыдуая"
L["Last playlist can not be removed."] = "Невозможно удалить последний список воспроизведении."
L["Layout & Skin"] = "Слои и шкурка"
L["Left click"] = "[Левый клик]"
L["Left Click"] = "[Левый клик]"
L["Length"] = "Длина"
L["List"] = "Список"
L["Lock"] = "Закрепить"
L["Lock GUI"] = "Закрепить GUI"
L["Loop Playlist"] = "Повтор списка воспроизведении"
L["Loop Song"] = "Повторять композицию"
L["Max song text length"] = "Макс длина текста композиции"
L["Middle click"] = "[Средний клик]"
L["Middle Click"] = "[Средний клик]"
L["Minimap Button"] = "Кнопка у мини-карты"
L["Model Size"] = "Размер модели"
L["Mouse Setup"] = "Установки мышы"
L["Moved song %s from list %s to list %s."] = "Перемещение песни %s с списка %s в %s."
L["Move song to"] = "Переместить композицию в"
L["Move song to favorite list"] = "Переместить песню в список избранных"
L["MusicDancer"] = "MusicDancer"
L["Music off"] = "Музыка -выкл"
L["Music volume: "] = "Громкость музыки: "
L["Mute"] = "Выкл звук"
L["Mute / unmute music sound."] = "Выкл / вкл звук музыки."
L["[~mymusic~] "] = "[~моямузыка~] "
L["Next"] = "Следующая"
L["No Match"] = "Нет совпадений"
L["No Target"] = "Нет цели"
L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = "Не представляется возможным с WoW. Как и воспроизводить песню с определенного места. Аддон может только сказать wow, проиграть и остановить песню, вот и все."
L["Party"] = "Группа"
L["Play"] = "Воспроизвести"
L["Playing song from history."] = "Проигрывание произведения из истории."
L["Playing the last song of a list will not switch to the next list."] = "Воспроизведение последней композиции в списке, смена на следующий список не будет."
L["Play last"] = "Воспроизвести предыдущую"
L["Play Last Song"] = "Воспроизвести пред. песню"
L["Playlist"] = "Список воспроизведении"
L["Playlist error oO Playlist maybe empty."] = "Ошибка списка воспроизведений оО, возможно он пуст."
L["Playlist font"] = "Шрифт списка воспр."
L["Playlist not found."] = "Список воспроизведении не найден."
L["Playlists"] = "Списки"
L["Playlist %s already exists."] = "Список %s уже существует."
L["Playlist Scale"] = "Масштаб списка воспр."
L["Playlists created with the playlist generator or addedy by the game music module are locked for editing."] = "Списки воспроизведения, созданные с генератором списков или добавлены модулем игровой музыки, невозможно редактировать."
L["Playlist %s not found."] = "Список %s не найден."
L["Playlist %s removed."] = "Список %s удален."
L["Play Next Song"] = "Воспроизвести след. песню"
L["Plays a test song."] = "Проиграет пробное произведение."
L["Plays the last song."] = "Воспроизвести последнюю песню."
L["Plays the next song."] = "Воспроизвести следующую песню."
L["Play/Stop"] = "Воспроизвести/Остановить"
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "Воспроизведение текущей песни снова и снова и снова ...До тех пор, пока ваша голова не взорваться. Чтобы отключить это, кликните на следующую композицию."
L["Play the Music"] = "Воспроизвести музыку"
L["Prevent accidentally moving the GUI."] = "Предотвращает случайное перемещение графического интерфейса пользователя (GUI)."
L["Raid"] = "Рейд"
L["Random Model"] = "Случайная модель"
L["Read the FAQ for more info about this."] = "Для получения дополнительной информации читайте FAQ."
L["Read the install file in the addon directory"] = "Прочитайте файл установки в директории аддона"
L["Really remove playlist %s?"] = "Действительно удалить список %s?"
L["Remove Playlist"] = "Удалить список"
L["Remove Song"] = "Удалить песню"
L["Remove the playing song from list"] = "Удалить воспроизводимую песню из списка"
L["Reset GUI Position"] = "Сброс позиции GUI"
L["Reset Position"] = "Сброс позиции"
L["Reset the GUI window position"] = "Сброс расположения окна GUI"
L["Right click"] = "[Правый клик]"
L["Right Click"] = "[Правый клик]"
L["Right click and drag to move this button"] = "[Удерживая правый клик], вы можете перемещать кнопку"
L["Say"] = "Сказать"
L["Scroll GUI Text"] = "Прокрутить текста GUI"
L["Search..."] = "Поиск..."
L["Select a model"] = "Выберите модель"
L["Select a question from the left."] = "Выберите вопрос с левой стороны."
L["Select the default channel to spam on ctrl+click"] = "Выберите канал по умолчанию для вывода по нажатию [ctrl+клик]"
L["Set Model"] = "Модель"
L["Shift click"] = "[Shift клик]"
L["Shift+Click"] = "[Shift+Клик]"
L["Show a random model when playing a new song."] = "Показывать случайную модель при воспроизведении новой композиции."
L["Show Artist"] = "Показать исполнителя"
L["Show Background"] = "Показать фон"
L["Show console commands"] = "Показать консольные команды"
L["Show Controls and Options"] = "Открыть настройки"
L["Show Dancer"] = "Показать танцора"
L["Show GUI"] = "Показать GUI"
L["Show/Hide Playlist"] = "Показать/Скрыть список воспр."
L["Show Info"] = "Показать информацию"
L["Showing/hiding the GUI will show/hide the dancer."] = "Показывать/скрывать танцора синхронно с показом/скрытием интерфейса."
L["Show List/Song Numbers"] = "Показать список/номер композиции"
L["Show message in your chat when playing a new song."] = "Выводить сообщение в ваш чат когда воспроизводится новая композиция."
L["Show Pedestal"] = "Показать пьедестал"
L["Show playlist and song number"] = "Показать список воспроизведении и номер композиции"
L["Show song and artist on new song"] = "Показать название и исполнителя новой песни"
L["Show Song In Chat"] = "Сообщить о песне в чат"
L["Show the Music."] = "Показать музыку."
L["Show time"] = "Показать время"
L["Show Title"] = "Показать название"
L["Show Tooltip"] = "Показать подсказку"
L["Show Update Info"] = "Показать инфо обновления"
L["Shuffle"] = "В случайном порядке"
L["Shuffle Cross Playlist"] = "Случайные мелодии из плей-листа"
L["Song"] = "Композиция"
L["Song is already in that list."] = "Композиция уже присутствует в данном списке."
L["Spam Link"] = "Вывести ссылку"
L["Spam to"] = "Вывод в"
L["Spam to default channel"] = "Вывод в канал по умолчанию"
L["Stop"] = "Остановить"
L["Stopped"] = "Остановлен"
L["Stop playing."] = "Остановить воспроизведение."
L["Test"] = "Тест"
L["The maximum text length of the song displayed in the Panel."] = "Максимальная длина названия текста композиции, на панели."
L["This is a wow bug since patch 2.4.3. I only could fix this so far that the song starts from start instead playing the game music. I have reported this in the eu forums but unless someone with an us account finally reports this in the us ui-forum blizzard developers will never fix this."] = "Это ошибка WoW с патча 2.4.3."
L["This will set the model to the default size and attach it to the GUI."] = "Сброс модели к стандартному размеру и прикрепит её к интерфейсу."
L["Title color"] = "Цвет названия"
L["Toggle Mute"] = "Вкл/выкл звук"
L["Toggles auto play on load."] = "Переключение автоматического воспроизведения при загрузке."
L["Toggle show Artist"] = "Переключение отображения исполнителя"
L["Toggle show GUI"] = "Открыть / закрыть GUI"
L["Toggle show minimap button"] = "Переключение отображения кнопки у мини-карты"
L["Toggle show model."] = "Переключение отображения модели."
L["Toggle show time"] = "Переключение отображения времени"
L["Toggle show title"] = "Переключение отображения названия"
L["Toggle shuffle"] = "Переключение воспроизведения в случайном порядке"
L["Toggle with GUI"] = "Переключать с интерфейсом"
L["To target"] = "Цели:"
L["Unlock to allow moving the model. Moving will release the model from the GUI. Use reset to reattach."] = "Сняв галку, вы сможете двигать модель. Перемещение может отделить модель от окна интерфейcа. Воспользуйтесь сбросом, для восстановления позиции."
L["Use artist color"] = "Цвет исполнителя"
L["Use artist color as button color"] = "Цвет исполнителя как цыет кнопки"
L["Use scroll wheel - adjust music volume"] = "[Колёсик мыши] - регулирует громкость музыки"
L["Where the hell is the playlist?"] = "Где, черт возьми, список воспроизведения?"
L["Whisper to"] = "Шепнуть:"
L["Why are some playlists grey?"] = "Почему некоторые списки серые?"
L["Why is there no pause button?"] = "Почему нет кнопки паузы?"
L["Why is the song playing from the beginning after a loading screen?"] = "Почему песня играет с самого начала после экрана загрузки?"
L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = "..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"
L["You can only remove playlists created ingame or with the playlist manager (not the playlist generator)!"] = "Вы можете удалять только те списки воспроизведения, которые созданные в игре или с помощью менеджером списков (не генератором списков)!"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "esES")
if L then
	L["Add a youtube link to chat spam."] = "Añadir un enlace de youtube al chat"
L["Add Playlist"] = "Añadir lista de reproducción"
L["Adjust the size of the model frame"] = "Ajustar el tamaño del marco de modelo" -- Needs review
L["Album"] = "Album" -- Needs review
L["Alt click"] = "Alt click" -- Needs review
L["Alt+Click"] = "Alt+Click"
L["Alt+Control+Click"] = "Alt+Control+Click"
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + usa rueda de desplazamiento - ajusta el volumen" -- Needs review
L["Artist"] = "Artista"
L["Artist color"] = "Color del Artista"
L["Autoplay"] = "Autoreproducir"
L["Background color"] = "Color de fondo"
L["Border color"] = "Color del borde"
L["Button4"] = "Botón4" -- Needs review
L["Button5"] = "Botón5" -- Needs review
L["Button color"] = "Color del botón"
L["Clear"] = "Limpiar" -- Needs review
L["Click me or scroll me. I won't bite. 8==8"] = "Hazme click o arrastrame. No muerdo. 8==8" -- Needs review
L["Close"] = "Cerrar" -- Needs review
L["Colours"] = "Colores" -- Needs review
L["Config"] = "Configurar" -- Needs review
L["Console"] = "Consola" -- Needs review
L["Console Controls"] = "Controles de la Consola" -- Needs review
L["Control+Click"] = "Control+Click" -- Needs review
L["Controls"] = "Controles" -- Needs review
L["Copied song"] = "Canción copiada" -- Needs review
L["Copy song to"] = "Copiar canción a" -- Needs review
L["Ctrl click"] = "Ctrl click" -- Needs review
L["Ctrl + use scroll wheel - adjust effects volume"] = "Control + usa la rueda de desplazamiento - ajusta los efectos de volumen" -- Needs review
L["Default Channel"] = "Canal por defecto" -- Needs review
L["Disable WoW Music"] = "Deshabilitar Música del WoW" -- Needs review
L["Disable WoW Music when not Playing."] = "Deshabilitar Música del WoW cuando se está reproduciendo." -- Needs review
L["Drop Down Menu"] = "Menu desplegable" -- Needs review
L["Effects vol.: "] = "Vol. de Efectos:" -- Needs review
L["Effects volume: "] = "Efectos de volumen" -- Needs review
L["Enable Mouse"] = "Activar ratón" -- Needs review
L["Favorites List"] = "Lista de Favoritos" -- Needs review
L["Font"] = "Tipo de letra" -- Needs review
L["Font & Colours"] = "Tipo de letra y colores" -- Needs review
L["Frequently Asked Questions"] = "Preguntas Frecuentes" -- Needs review
L["Game Music"] = "Música del Juego" -- Needs review
L["General"] = "General" -- Needs review
L["GUI Layout"] = "Interfaz de usuario grafica" -- Needs review
L["Guild"] = "Hermandad" -- Needs review
L["Help - FAQ"] = "Ayuda - FAQ" -- Needs review
L["Last"] = "Ultimo" -- Needs review
L["Last playlist can not be removed."] = "Ultima lista de reproducción no puede ser eliminada" -- Needs review
L["Left click"] = "Click izquiedo" -- Needs review
L["Left Click"] = "Click Izquierdo" -- Needs review
L["Lock"] = "Bloquear" -- Needs review
L["Loop Playlist"] = "Repetir Lista de reproducción" -- Needs review
L["Loop Song"] = "Repetir Canción" -- Needs review
L["Middle click"] = "Boton central" -- Needs review
L["Middle Click"] = "Click del medio" -- Needs review
L["Minimap Button"] = "Botón del Minimapa" -- Needs review
L["Model Size"] = "Tamaño del modelo" -- Needs review
L["Mouse Setup"] = "Configuración del mouse" -- Needs review
L["Move song to"] = "Mover canción a" -- Needs review
L["Move song to favorite list"] = "Mover canción a lista de favoritos" -- Needs review
L["MusicDancer"] = "Bailarin" -- Needs review
L["Music off"] = "Apagar Música" -- Needs review
L["Music volume: "] = "Volumen de la Música" -- Needs review
L["Mute"] = "Silencio" -- Needs review
L["Mute / unmute music sound."] = "Silenciar/Escuchar sonido de la música" -- Needs review
L["[~mymusic~] "] = "[~mimusica~]" -- Needs review
L["Next"] = "Siguiente" -- Needs review
L["No Match"] = "No concuerda" -- Needs review
L["No Target"] = "Sin objetivo" -- Needs review
L["Party"] = "Grupo" -- Needs review
L["Play"] = "Reproducir" -- Needs review
L["Play last"] = "Reproducir ultimo" -- Needs review
L["Play Last Song"] = "Reproducir ultima canción" -- Needs review
L["Play Next Song"] = "Reproducir siguiente canción" -- Needs review
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "Reproducir cancion actual una vez, y otra y otra... hasta que tu cabeza explote. Un click en 'siguiente cancion' desabilita esto." -- Needs review
L["Play the Music"] = "Reproducir" -- Needs review
L["Random Model"] = "Modelo aleatorio" -- Needs review
L["Reset Position"] = "Reiniciar posicion" -- Needs review
L["Right click"] = "Click derecho" -- Needs review
L["Select a model"] = "Elige un modelo" -- Needs review
L["Set Model"] = "Fijar modelo" -- Needs review
L["Shift click"] = "Shift click" -- Needs review
L["Show a random model when playing a new song."] = "Mostrar un modelo aleatorio cuando reproduces una nueva cancion" -- Needs review
L["Show Artist"] = "Mostrar artista" -- Needs review
L["Show Background"] = "Mostrar fondo" -- Needs review
L["Show console commands"] = "Mostrar comandos de la consola" -- Needs review
L["Show Info"] = "Mostrar informacion" -- Needs review
L["Show message in your chat when playing a new song."] = "Mostrar mensaje en el chat cuando reproduces una nueva cancion" -- Needs review
L["Show Pedestal"] = "Mostrar peana" -- Needs review
L["Show song and artist on new song"] = "mostrar cancion y artista en una nueva cancion" -- Needs review
L["Show Song In Chat"] = "Mostrar cancion en el chat" -- Needs review
L["Show the Music."] = "Mostrar la musica." -- Needs review
L["Show Tooltip"] = "Mostrar tooltip" -- Needs review
L["Shuffle"] = "Aleatorio" -- Needs review
L["Song is already in that list."] = "La cancion ya esta en esa lista" -- Needs review
L["Stop"] = "Detener" -- Needs review
L["Stopped"] = "Detenido" -- Needs review
L["Stop playing."] = "Detener reproduccion" -- Needs review
L["Title color"] = "Color del titulo" -- Needs review
L["Toggles auto play on load."] = "Activar 'auto-reproducir' al cargar" -- Needs review
L["Toggle show Artist"] = "Activar 'mostrar artista'" -- Needs review
L["Toggle show minimap button"] = "Habilitar boton del minimapa" -- Needs review
L["Toggle show model."] = "Activar 'mostrar modelo'" -- Needs review
L["Toggle shuffle"] = "Activar aleatorio" -- Needs review
L["To target"] = "Al objetivo" -- Needs review
L["Whisper to"] = "Susurrar a" -- Needs review

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "esMX")
if L then
	L["Add Playlist"] = "Agregar lista de reproducción"
L["Alt+Click"] = "Alt+Click"
L["Alt+Control+Click"] = "Alt+Control+Click"
L["Artist"] = "Artista"
L["Autoplay"] = "Autoreproducción"
L["Background color"] = "Color en segundo plano"
L["Border color"] = "Color del borde"
L["Button4"] = "botón4"
L["Button5"] = "botón5"
L["Button color"] = "Color del botón"
L["Clear"] = "Limpiar"
L["Close"] = "Cerrar"
L["Colours"] = "Colores"
L["Config"] = "Configuración"
L["Console"] = "Consola"
L["Console Controls"] = "Control de la Consola"
L["Control+Click"] = "Control+click"
L["Controls"] = "Controles"
L["Copied song"] = "Canción Copiada"
L["Copy song to"] = "Copiar cancion a"
L["Default Channel"] = "Canal estandar" -- Needs review
L["Disable WoW Music"] = "Desactivar Musica del WoW"
L["Disable WoW Music when not Playing."] = "Desactivar musica del WoW cuando no se está reproduciendo musica"
L["Drop Down Menu"] = "Desplazar menú hacia  abajo"
L["Effects vol.: "] = "Volumen de efectos"
L["Favorites List"] = "Lista de favoritos"
L["Font"] = "Tipo de Letras" -- Needs review
L["Font & Colours"] = "Tipo de letras y colores"
L["Frequently Asked Questions"] = "Preguntas frecuentes"
L["Game Music"] = "Musica del Juego"
L["General"] = "General"
L["Guild"] = "Hermandad"
L["Help - FAQ"] = "Ayuda - FAQ"
L["Last"] = "Ultima"
L["Last playlist can not be removed."] = "La ultima lista de reproducción no puede ser borrada"
L["Left Click"] = "Click izquierdo"
L["Middle Click"] = "Click Medio"
L["Minimap Button"] = "Icono del Minimapa"
L["Mouse Setup"] = "Configuración del ratón"
L["Move song to"] = "Mover la canción a"
L["Move song to favorite list"] = "Mover la cancion a la lista de favoritos"
L["Music off"] = "Musica off"
L["Music volume: "] = "Volume de la música"
L["Mute"] = "Silencio"
L["Mute / unmute music sound."] = "Silenciar / desactivar silencio en el sonido de la musica"
L["Next"] = "Siguiente"
L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = "No es posible con el WoW, ya que como está reproduciendo una cancion en una posición especifica, el addon solo le puede decir a wow que reprodusca musica o que pare de reproducir."
L["Where the hell is the playlist?"] = "Donde diablos esta la lista de reproduccion D:?"
L["Whisper to"] = "Susurrar a"
L["Why is there no pause button?"] = "Por qué no hay un botón de pausa?"
L["Why is the song playing from the beginning after a loading screen?"] = "Por qué la canción empieza desde el principio despues de haber cargado la pantalla?"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "ptBR")
if L then
	L["Add a youtube link to chat spam."] = "Adicionar um link do youtube no spam de chat"
L["Added playlist %s."] = "Adicionada a playlist %s."
L["Add Playlist"] = "Adicionar Lista de Reprodução"
L["Adjust the scale of the playlist"] = "Ajustar a escala da lista de reprodução"
L["Adjust the size of the GUI"] = "Ajustar o tamanho do GUI"
L["Adjust the size of the model frame"] = "Ajustar o tamanho do quadro de modelo"
L["Album"] = "Álbum"
L["Alt click"] = "Alt clique"
L["Alt+Click"] = "Alt+Clique"
L["Alt+Control+Click"] = "Alt+Ctrl+Clique"
L["Alt + use scroll wheel - fine adjust volume"] = "Alt + use o scroll - ajuste fino de volume"
L["Artist"] = "Artista"
L["Artist color"] = "Cor do artista"
L["Autoplay"] = "Auto-executar"
L["Background color"] = "Cor de fundo"
L["Border color"] = "Cor da borda"
L["Button4"] = "Botão4"
L["Button5"] = "Botão5"
L["Button color"] = "Cor do botão"
L["Change the playlist font. Requires relog to take effect."] = "Alterar a fonte da lista. Requer relogar para fazer efeito."
L["Clear"] = "Limpar"
L["Click me or scroll me. I won't bite. 8==8"] = "Clique em mim ou use o scroll. Não mordo. 8==8"
L["Close"] = "Fechar"
L["Colours"] = "Cores"
L["Config"] = "Configurar"
L["Console"] = "Console"
L["Console Controls"] = "Controles de Console"
L["Control+Click"] = "Ctrl+Clique"
L["Controls"] = "Controles"
L["Copied song"] = "Música copiada"
L["Copied song %s to List %s."] = "Música %s copiada para a Lista %s."
L["Copy song to"] = "Copiar música para"
L["Ctrl click"] = "Ctrl clique"
L["Ctrl click - Write artist and title to default chat. (Guild,party etc.)"] = "Ctrl clique - Mostrar artista e título no chat padrão. (Guilda, grupo etc.)"
L["Ctrl + use scroll wheel - adjust effects volume"] = "Ctrl + use o scroll - ajustar volume dos efeitos"
L["Current will be moved on playing next song."] = "O atual será movido ao tocar a próxima música."
L["Default Channel"] = "Canal Padrão"
L["Disable WoW Music"] = "Desabilitar Música do WoW"
L["Disable WoW Music when not Playing."] = "Desabilitar Musica do WoW quando não estivar Tocando."
L["Do I have to copy all of my music files to the wow folder?"] = "Tenho que copiar todas as minhas músicas para a pasta do WoW?"
L["Drop Down Menu"] = "Menu"
L["Effects vol.: "] = "Vol. dos Efeitos"
L["Effects volume: "] = "Volume dos efeitos:"
L["Enable Mouse"] = "Habilitar Mouse"
L["EpicMusicPlayer Update Info"] = "Informação de atualização do EpicMusicPlayer"
L["FAQ-Text1"] = [=[1. Saia do Wow se estiver aberto!
  Clique duplo no "PlaylistaManager.exe" dentro da pasta Playlistmanager do Addon.
2. Clique em "File > Add Music Folder", selecione uma pasta com suas músicas e clique em "open".
   OU
   Apenas arraste e solte alguns arquivos ou pastas MP3 dentro do Playlist-Manager.
3. Feche o EMP-Playlist-Manager (tenha certeza de clicar antes em "Yes" para salvar a lista de reprodução).
    Inicie o WoW e aproveite sua música enquanto farma. :)]=]
L["FAQ-Text2"] = [=[Não. O Playlist Manager pode criar ligações (dentro da pasta do wow) que apontam para a sua pasta original. Dessa forma o WoW pensa que esses arquivos estão dentro da própria pasta.

Você pode ativar isso através:
Windows Vista:
Apenas vá em "Ferramentas > Opções" e mude para copiar criar ligações.

Windows XP:
Faça um download do junction.exe da Microsoft: http://technet.microsoft.com/en-us/sysinternals/bb896768.aspx e coloque-o na pasta "junction" do playlist manager.

Você pode também instalar o "ntfslink" (http://elsdoerfer.name/=ntfslink) Para poder usar as ligações (junções) salvos no Windows XP. Veja http://en.wikipedia.org/wiki/NTFS_junction_point#Windows_XP para mais informações (Em inglês).

Agora vá em "Ferramentas > Opções" e mude copiar para criar ligações.]=]
L["Favorites List"] = "Lista de Favoritos"
L["Font"] = "Fonte"
L["Font & Colors"] = "Fonte & Cores"
L["Font & Colours"] = "Fonte & Cores"
L["Frame strata"] = "Prioridade do quadro"
L["Frequently Asked Questions"] = "Perguntas Mais Frequentes"
L["Game Music"] = "Música do Jogo"
L["General"] = "Geral"
L["GUI"] = "GUI"
L["GUI Layout"] = "Interface Gráfica (GUI)"
L["Guild"] = "Guilda"
L["GUI not found"] = "GUI não encontrado"
L["GUI Size"] = "Tam. do GUI"
L["Help - FAQ"] = "Ajuda - FAQ"
L["Hide Artist in Playlist"] = "Esconder Artista na Lista de Reprodução"
L["How do I add music to the player?"] = "Como eu adiciono música ao tocador?"
L["Last"] = "Última"
L["Last playlist can not be removed."] = "A última lista de reproduçãoi não pode ser removida."
L["Layout & Skin"] = "Skins e Disposições"
L["Left click"] = "Botão esquerdo"
L["Left Click"] = "Botão Esquerdo"
L["Length"] = "Duração"
L["List"] = "Lista"
L["Lock"] = "Travar"
L["Loop Playlist"] = "Repetir Lista de Reprodução"
L["Loop Song"] = "Repetir música"
L["Max song text length"] = "Duração máxima da música"
L["Middle click"] = "Botão do meio"
L["Middle Click"] = "Botão do Meio"
L["Minimap Button"] = "Botão do Mini-mapa"
L["Model Size"] = "Tamanho do Modelo"
L["Mouse Setup"] = "Configuração do Mouse"
L["Moved song %s from list %s to list %s."] = "Música %s movida da lista %s para %s."
L["Move song to"] = "Mover música para"
L["Move song to favorite list"] = "Mover música para a lista dos favoritos"
L["MusicDancer"] = "DançarinoMusical"
L["Music off"] = "Música desligada"
L["Music volume: "] = "Volume da música:"
L["Mute"] = "Mudo"
L["Mute / unmute music sound."] = "Mutar / desmutar som das músicas."
L["[~mymusic~] "] = "[~minhamusica~]"
L["Next"] = "Próximo"
L["No Match"] = "Não Encontrado"
L["No Target"] = "Nenhum Alvo"
L["Not possible with wow. As is playing a song at a specific position. An addon can only tell wow to play and stop a song that's it."] = "Não é possível no wow, saber em que parte da música está no momento. Um addon só pode dizer ao wow para reproduzir e parar uma música."
L["Party"] = "Grupo"
L["Play"] = "Reproduzir"
L["Playing song from history."] = "Tocar música do histórico."
L["Playing the last song of a list will not switch to the next list."] = "Tocar a última música de uma lista não irá passar para a próxima lista."
L["Play last"] = "Reproduzir última"
L["Play Last Song"] = "Reproduzir Última Música"
L["Playlist"] = "Lista de Reprodução"
L["Playlist error oO Playlist maybe empty."] = "Erro na Lista de Reprodução oO Ela deve estar vazia."
L["Playlist font"] = "Fonte da Lista de Reprodução."
L["Playlist not found."] = "Lista de Reprodução não encontrada."
L["Playlists"] = "Listas de Reprodução"
L["Playlist %s already exists."] = "A lista %s já existe."
L["Playlist Scale"] = "Escala da Lista de Reprodução"
L["Playlists created with the playlist generator or addedy by the game music module are locked for editing."] = "As listas de reprodução criadas com o \"playlist generator\" ou adicionadas pelas músicas do jogo estão travadas para edição."
L["Playlist %s not found."] = "A lista %s não foi encontrada."
L["Playlist %s removed."] = "A lista %s foi removida."
L["Play Next Song"] = "Reproduzir Próxima Música"
L["Plays a test song."] = "Tocar uma música de teste."
L["Plays the last song."] = "Reproduz a última música."
L["Plays the next song."] = "Reproduz a próxima música."
L["Play/Stop"] = "Reproduzir/Parar"
L["Play the current song again and again and again...until your head will explode. A click on next song will disable this."] = "Reproduzir a música atual denovo e denovo e denovo... até sua cabeça explodir. Trocar de música irá desabilitar isso."
L["Play the Music"] = "Reproduzir a Música"
L["Raid"] = "Raide"
L["Random Model"] = "Modelo Aleatório"
L["Read the FAQ for more info about this."] = "Leia o FAQ para mais informação nisso."
L["Read the install file in the addon directory"] = "Leia o arquivo de instalação na pasta do addon"
L["Really remove playlist %s?"] = "Realmente remover a lista %s?"
L["Remove Playlist"] = "Remover Lista de Reprodução"
L["Remove Song"] = "Remover Música"
L["Remove the playing song from list"] = "Remover a música atual da lista"
L["Reset GUI Position"] = "Resetar posição do GUI"
L["Reset Position"] = "Resetar Posição"
L["Reset the GUI window position"] = "Resetar posição da janela do GUI"
L["Right click"] = "Botão da direita"
L["Right Click"] = "Botão Direito"
L["Right click and drag to move this button"] = "Clique com o botão direito e arraste para mover este botão"
L["Say"] = "Dizer"
L["Scroll GUI Text"] = "Rolar texto do GUI"
L["Search..."] = "Buscar..."
L["Select a model"] = "Selecione um modelo"
L["Select a question from the left."] = "Selecione uma dúvida na esquerda."
L["Select the default channel to spam on ctrl+click"] = "Selecione o canal padrão para spamar com ctrl+clique"
L["Set Model"] = "Setar Modelo"
L["Shift click"] = "Shift clique"
L["Shift+Click"] = "Shift+Clique"
L["Show a random model when playing a new song."] = "Mostrar um modelo aleatório quando tocar uma nova música."
L["Show Artist"] = "Mostrar Artista"
L["Show Background"] = "Mostrar Plano de Fundo"
L["Show console commands"] = "Mostrar comandos de console"
L["Show Controls and Options"] = "Mostrar Controles e Opções"
L["Show Dancer"] = "Mostrar Dançarino"
L["Show GUI"] = "Mostrar GUI"
L["Show/Hide Playlist"] = "Mostrar/Esconder Lista de Reprodução"
L["Show Info"] = "Mostrar Info"
L["Showing/hiding the GUI will show/hide the dancer."] = "Mostrando/escondendo o GUI irá mostrar/esconder o dançarino."
L["Show List/Song Numbers"] = "Mostrar número da Lista/Música"
L["Show message in your chat when playing a new song."] = "Mostrar uma mensagem no seu chat quando tocar uma nova música."
L["Show Pedestal"] = "Mostrar Pedestal"
L["Show playlist and song number"] = "Mostrar número da lista e música"
L["Show song and artist on new song"] = "Mostrar música e artista em uma nova música"
L["Show Song In Chat"] = "Mostrar Música no Chat"
L["Show the Music."] = "Mostrar a Música."
L["Show time"] = "Mostrar tempo"
L["Show Title"] = "Mostrar Título"
L["Show Tooltip"] = "Mostrar Tooltip"
L["Show Update Info"] = "Mostrar info de Atualização"
L["Shuffle"] = "Aleatório"
L["Shuffle Cross Playlist"] = "Aleatório entre Listas"
L["Song"] = "Música"
L["Song is already in that list."] = "A musica já está nessa lista."
L["Spam Link"] = " Link"
L["Spam to"] = "Spamar para"
L["Spam to default channel"] = "Spamar para o canal padrão"
L["Stop"] = "Parar"
L["Stopped"] = "Parado"
L["Stop playing."] = "Para de reproduzir."
L["Test"] = "Teste."
L["The maximum text length of the song displayed in the Panel."] = "O tamanho máximo do texto da música mostrada no painel."
L["This is a wow bug since patch 2.4.3. I only could fix this so far that the song starts from start instead playing the game music. I have reported this in the eu forums but unless someone with an us account finally reports this in the us ui-forum blizzard developers will never fix this."] = "Isso é um bug no WoW desde o patch 2.4.3. Eu só posso fazer com que a música volte ao inicio ao invés de tocar a música do jogo. Eu reportei isso nos fórums EU mas a não ser que alguém com uma conta US reporte isso no fórum de UI lá os desenvolvedores nunca irão consertar isso."
L["This will set the model to the default size and attach it to the GUI."] = "Isso vai setar o modelo pro tamanho padrão e prendê-lo ao GUI."
L["Title color"] = "Cor do título"
L["Toggle Mute"] = "Alternar Mudo"
L["Toggles auto play on load."] = "Alterna auto-reprodução ao carregar"
L["Toggle show Artist"] = "Alternar mostrar Artista"
L["Toggle show GUI"] = "Alternar mostrar GUI"
L["Toggle show minimap button"] = "Botão de alternar visibilidade no mini-mapa"
L["Toggle show model."] = "Alternar mostrar modelo."
L["Toggle show time"] = "Alternar mostrar tempo"
L["Toggle show title"] = "Alternar mostrar título"
L["Toggle shuffle"] = "Alternar modo aleatório"
L["Toggle with GUI"] = "Alternar com GUI"
L["To target"] = "Nenhum alvo"
L["Unlock to allow moving the model. Moving will release the model from the GUI. Use reset to reattach."] = "Destrave para poder mover o modelo. Mover vai desprender o modelo do GUI. Use o Resetar para voltar."
L["Use artist color"] = "Usar cor do artista"
L["Use artist color as button color"] = "Usar a cor do artista como cor do botão"
L["Use scroll wheel - adjust music volume"] = "Use o scroll - ajustar o volume da música"
L["Where the hell is the playlist?"] = "Onde diabos é a lista de reprodução?"
L["Whisper to"] = "Sussurrar para"
L["Why are some playlists grey?"] = "Por que algumas listas estão cinza?"
L["Why is there no pause button?"] = "Por que não tem botão de pausar?"
L["Why is the song playing from the beginning after a loading screen?"] = "Por que a música volta pro começo depois de uma tela de carregamento?"
L["..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"] = "..\\World of Warcraft\\WTF\\Account\\ACCOUNTNAME\\SavedVariables\\EpicMusicPlayer.lua"
L["You can only remove playlists created ingame or with the playlist manager (not the playlist generator)!"] = "Você só pode remover listas de reprodução criadas no jogo ou com o playlist manager (não o playlist generator)!"

	return
end

local L = AceLocale:NewLocale("EpicMusicPlayer", "itIT")
if L then
	
	return
end