EngBags
--
Current Autor:  Lars Kiesow
Original Autor: UniRing, Requital
Homepage:       http://www.larskiesow.de/
                http://wow.curseforge.com/projects/engbags-continued/
                http://wow.curse.com/downloads/wow-addons/details/engbags-continued.aspx
Version:        81024
--
--
Changelog:
=== 81019 - 81024 ===
* ToolTip bug fixed
* DropDownMenu bug fixed
* SetFocus bug fixed (hook removed)
* Interface version changed
* Changelog started
* Hador (Lars Kiesow) took over the project

...