﻿PatternLocale.esMX = PatternLocale.esES
DisplayLocale.esMX = DisplayLocale.esES
