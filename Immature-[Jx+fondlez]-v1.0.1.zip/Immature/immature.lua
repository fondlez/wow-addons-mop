local FilterOff = CreateFrame("Frame")
function SetFilterOff()
  -- FIX(@fondlez): prevent error messages when BNet is not connected.
  ---[[
  -- BNSetMatureLanguageFilter(false)
	pcall(BNSetMatureLanguageFilter, false)
  --]]
end
FilterOff:SetScript("OnEvent", SetFilterOff)
FilterOff:RegisterEvent("PLAYER_ENTERING_WORLD")