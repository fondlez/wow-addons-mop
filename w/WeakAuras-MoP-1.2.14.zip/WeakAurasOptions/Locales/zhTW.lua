if not WeakAuras.IsCorrectVersion() then return end

if not(GetLocale() == "zhTW") then
  return
end

local L = WeakAuras.L

--@localization(locale="zhTW", format="lua_additive_table", namespace="WeakAuras / Options")@
