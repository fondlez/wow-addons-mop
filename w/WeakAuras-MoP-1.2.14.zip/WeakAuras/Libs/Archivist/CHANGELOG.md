# Archivist

## [v1.0.4](https://github.com/emptyrivers/Archivist/tree/v1.0.4) (2020-02-08)
[Full Changelog](https://github.com/emptyrivers/Archivist/compare/v1.0.3...v1.0.4)

- oops  
