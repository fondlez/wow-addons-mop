if not(GetLocale() == "zhCN") then
  return
end

local L = WeakAuras.L

--@localization(locale="zhCN", format="lua_additive_table", namespace="WeakAuras", handle-subnamespaces="none")@
