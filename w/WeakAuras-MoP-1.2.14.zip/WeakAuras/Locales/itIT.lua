if not(GetLocale() == "itIT") then
  return
end

local L = WeakAuras.L

--@localization(locale="itIT", format="lua_additive_table", namespace="WeakAuras", handle-subnamespaces="none")@
