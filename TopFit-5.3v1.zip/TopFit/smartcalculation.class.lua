local addonName, ns, _ = ...

local SmartCalculation = ns.class(ns.Calculation)
ns.SmartCalculation = SmartCalculation