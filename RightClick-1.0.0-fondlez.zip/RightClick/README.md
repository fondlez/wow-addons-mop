# RightClick Addon for WoW
Disables right click attack on enemy players. \
Disables right click targeting if an enemy is selected.
