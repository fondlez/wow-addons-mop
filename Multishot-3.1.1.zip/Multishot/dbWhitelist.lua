Multishot_dbWhitelist = {
  [4949]	= true, -- For The Alliance! - Thrall
  [10181]	= true, -- For The Alliance! - Lady Sylvanas Windrunner
  [3057]	= true, -- For The Alliance! - Cairne Bloodhoof
  [16802]	= true, -- For The Alliance! - Lor'themar Theron
  [29611]	= true, -- For The Horde! - King Varian Wrynn
  [7999]	= true, -- For The Horde! - Tyrande Whisperwind
  [2784]	= true, -- For The Horde! - King Magni Bronzebeard
  [17468]	= true, -- For The Horde! - Prophet Velen
  [448]		= true, -- For The Luls! - Hogger
}