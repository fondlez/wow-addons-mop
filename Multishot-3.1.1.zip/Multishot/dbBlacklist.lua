Multishot_dbBlacklist = {
  [16803] = true, -- Naxxramas: DeathKnight Understudy (Razuvious "adds")
  [15930] = true, -- Naxxramas: Feugen (Thaddius pre-event)
  [15929] = true, -- Naxxramas: Stalagg (Thaddius pre-event)
  [32933] = true, -- Ulduar: Left Arm (Kologarn's arms)
  [32934] = true, -- Ulduar: Right Arm (Kologarn's arms)
  [33136] = true, -- Ulduar: Guardian of Yogg-Saron
  [37217] = true, -- Icecrown Citadel: Precious (Festergut/Rotface "pets")
  [37025] = true, -- Icecrown Citadel: Stinky (Festergut/Rotface "pets")
  [36477] = true, -- Pit of Saron: Ick (bug report, commentid: 238028)
}