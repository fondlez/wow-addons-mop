﻿if (GetLocale() == "deDE") then

	XPERL_RAID_MONITOR_TITLE				= "Casting-Monitor |c00A04040(BETA)|r"
	XPERL_RAID_MONITOR_TOTALS				= "Anzeige zwischen Gesamt und Statistik umschalten"

	XPERL_RAID_MONITOR_STATS_RAID_MANA		= "Schlachtzug Mana"
	XPERL_RAID_MONITOR_STATS_HIGH_MANA		= "Hohes Mana"
	XPERL_RAID_MONITOR_STATS_LOW_MANA		= "Wenig Mana"
	XPERL_RAID_MONITOR_STATS_RAID_HEALTH	= "Schlachtzug Gesundheit"

	XPERL_MONITOR_LEFTCLICK					= "|c00FFFFFFLinks-Klick|r, f\195\188r %s"
	XPERL_MONITOR_RIGHTCLICK				= "|c00FFFFFFRechts-Klick|r, f\195\188r %s"
	XPERL_MONITOR_CLICKCAST					= "zauber |c0000FF00%s|r"
	XPERL_MONITOR_CLICKTARGET				= "|c00FFFF80ziel|r"

	XPERL_MONITOR_INNERVATE					= "Anregen"
	XPERL_MONITOR_MANATIDE					= "Totem der Manaflut"

	XPERL_LOC_OOR							= "n/a"

end
