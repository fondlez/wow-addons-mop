RarityNames = { [0]="|cff9d9d9dDisabled|r", [2]="|cff1eff00Uncommon|r", [3]="|cff0070ddRare|r", [4]="|cffa335eeEpic|r" }

ClothNames = { [0]="|cff9d9d9dDisabled|r", [5]="Linen", [15]="Wool", [30]="Silk", [40]="Mageweave", [50]="Runecloth", [60]="Netherweave", [70]="Frostweave", [81]="Embersilk", [86]="Windwool" }
ClothLevels = { [54440]=85,[41593]=80,[41594]=80,[41595]=80,[21845]=70,[24271]=70,[24272]=70,[21842]=66,[41511]=75,[4339]=45,[4338]=40,[8343]=40,[10285]=40,[4305]=35,[4337]=35,[4291]=30,[4306]=30,[2997]=25,[2321]=20,[3182]=20,[2592]=15,[2996]=10,[2320]=5,[2589]=5,[14341]=50,[14256]=50,[53010]=81,[53643]=81,[42253]=75,[21844]=70,[33470]=70,[38426]=70,[41510]=70,[21840]=60,[21877]=60,[21881]=60,[14048]=55,[14342]=55,[14047]=50,[14227]=50,[52341]=81,[72988]=86 }

IsArchaeology = { ["Troll Archaeology Fragment"]=true, ["Draenei Archaeology Fragment"]=true, ["Dwarf Archaeology Fragment"]=true, ["Fossil Archaeology Fragment"]=true, ["Nerubian Archaeology Fragment"]=true, ["Night Elf Archaeology Fragment"]=true, ["Orc Archaeology Fragment"]=true, ["Tol'vir Archaeology Fragment"]=true, ["Vrycul Archaeology Fragment"]=true, ["Pandaren Archaeology Fragment"]=true, ["Mogu Archaeology Fragment"]=true }

IsDisenchanting = { [74247]=1,[80824]=1,[74248]=1,[82981]=1,[74250]=1,[74251]=1,[74252]=1,[74249]=1,[52723]=1,[52721]=1,[52720]=1,[52722]=1,[52719]=1,[52555]=1,[52718]=1,[44452]=1,[49640]=1,[89738]=1,[34053]=1,[34052]=1,[34057]=1,[25845]=1,[34055]=1,[41741]=1,[41745]=1,[25844]=1,[34054]=1,[34056]=1,[22449]=1,[22450]=1,[22446]=1,[22448]=1,[22463]=1,[22462]=1,[22461]=1,[25843]=1,[22445]=1,[22447]=1,[20725]=1,[16207]=1,[16206]=1,[16204]=1,[16203]=1,[14344]=1,[16202]=1,[14343]=1,[11176]=1,[11175]=1,[11178]=1,[11144]=1,[11174]=1,[11145]=1,[11177]=1,[11137]=1,[11135]=1,[11139]=1,[11128]=1,[11134]=1,[11138]=1,[11130]=1,[11083]=1,[11082]=1,[11084]=1,[6338]=1,[6374]=1,[10998]=1,[10978]=1,[6339]=1,[10939]=1,[10940]=1,[10938]=1,[6217]=1,[6218]=1 }
IsCloth = { [82441]=1,[82447]=1,[72988]=1,[54440]=1,[53643]=1,[53010]=1,[52341]=1,[41593]=1,[41594]=1,[41595]=1,[42253]=1,[41511]=1,[21844]=1,[33470]=1,[38426]=1,[41510]=1,[21845]=1,[24272]=1,[24271]=1,[21842]=1,[21881]=1,[21877]=1,[21840]=1,[14048]=1,[14342]=1,[14341]=1,[14256]=1,[14227]=1,[14047]=1,[4339]=1,[4338]=1,[8343]=1,[10285]=1,[4337]=1,[4305]=1,[4291]=1,[4306]=1,[2997]=1,[3182]=1,[2321]=1,[2592]=1,[2996]=1,[2320]=1,[2589]=1 }
IsLeather = { [72201]=1,[72163]=1,[79101]=1,[80221]=1,[72175]=1,[72174]=1,[72164]=1,[72162]=1,[72120]=1,[72165]=1,[52981]=1,[52982]=1,[52979]=1,[52980]=1,[56516]=1,[52976]=1,[38425]=1,[52977]=1,[38561]=1,[38557]=1,[44128]=1,[38558]=1,[25707]=1,[33567]=1,[33568]=1,[23793]=1,[20381]=1,[29548]=1,[29547]=1,[29539]=1,[25708]=1,[25700]=1,[25699]=1,[25649]=1,[21887]=1,[19768]=1,[19767]=1,[17012]=1,[15414]=1,[15410]=1,[17967]=1,[15416]=1,[15408]=1,[12810]=1,[15419]=1,[15417]=1,[15415]=1,[15412]=1,[15409]=1,[15407]=1,[8171]=1,[8170]=1,[8168]=1,[8165]=1,[8154]=1,[4304]=1,[8150]=1,[8169]=1,[8172]=1,[5785]=1,[8167]=1,[4461]=1,[4236]=1,[4234]=1,[4235]=1,[2319]=1,[4232]=1,[4233]=1,[5784]=1,[5082]=1,[4289]=1,[4231]=1,[2318]=1,[783]=1,[2934]=1,[5116]=1,[6470]=1,[6471]=1,[7286]=1,[7392]=1 }
IsMining = { [72094]=1,[72103]=1,[72095]=1,[87416]=1,[87415]=1,[72097]=1,[72093]=1,[87414]=1,[72104]=1,[80431]=1,[72092]=1,[72096]=1,[80432]=1,[58480]=1,[51950]=1,[52183]=1,[52184]=1,[52185]=1,[52187]=1,[53039]=1,[52186]=1,[54849]=1,[53038]=1,[65365]=1,[36913]=1,[37706]=1,[41163]=1,[37663]=1,[36915]=1,[36910]=1,[36914]=1,[36912]=1,[36909]=1,[36916]=1,[23427]=1,[23449]=1,[23426]=1,[23447]=1,[35128]=1,[23425]=1,[23446]=1,[23573]=1,[18567]=1,[23424]=1,[23445]=1,[12809]=1,[23448]=1,[17203]=1,[18562]=1,[17771]=1,[12655]=1,[12360]=1,[12359]=1,[11371]=1,[11370]=1,[6037]=1,[12365]=1,[12644]=1,[3858]=1,[3860]=1,[10620]=1,[7911]=1,[3859]=1,[7912]=1,[7966]=1,[3575]=1,[3857]=1,[2772]=1,[3577]=1,[2838]=1,[3486]=1,[2776]=1,[3478]=1,[3576]=1,[2841]=1,[2771]=1,[2836]=1,[3470]=1,[2840]=1,[2770]=1,[2775]=1,[2842]=1,[2835]=1,[22202]=1,[22203]=1 }
IsStone = { [12365]=1, [7912]=1, [2838]=1, [2836]=1, [2835]=1 }
IsHerb = { [72238]=1,[79011]=1,[79010]=1,[72235]=1,[52987]=1,[52989]=1,[72234]=1,[72237]=1,[52988]=1,[52986]=1,[52984]=1,[52985]=1,[52983]=1,[36905]=1,[36906]=1,[36908]=1,[36903]=1,[36902]=1,[39970]=1,[36904]=1,[37921]=1,[36907]=1,[36901]=1,[22791]=1,[22792]=1,[22793]=1,[22797]=1,[22794]=1,[22790]=1,[22788]=1,[22787]=1,[19726]=1,[22789]=1,[22786]=1,[22785]=1,[13468]=1,[19727]=1,[13467]=1,[13466]=1,[13465]=1,[13463]=1,[13464]=1,[8846]=1,[8845]=1,[8839]=1,[8838]=1,[8836]=1,[8831]=1,[4625]=1,[8153]=1,[3819]=1,[3358]=1,[3821]=1,[3818]=1,[3357]=1,[3356]=1,[3355]=1,[3369]=1,[2453]=1,[3820]=1,[2450]=1,[2452]=1,[2449]=1,[785]=1,[765]=1,[2447]=1,[22710]=1 }
IsRogueBox = { [63349]=1,[43575]=1,[31952]=1,[29569]=1,[20768]=1,[4638]=1,[16884]=1,[20767]=1,[16883]=1,[20766]=1,[16882]=1,[5373]=1,[67495]=1,[63300]=1,[88165]=1,[88567]=1,[68729]=1,[45986]=1,[43624]=1,[43622]=1,[31952]=1,[5760]=1,[5759]=1,[5758]=1,[4638]=1,[4637]=1,[4636]=1,[4634]=1,[4633]=1,[4632]=1 }
IsElemental = { [80816]=1,[76061]=1,[90636]=1,[76060]=1,[76059]=1,[76058]=1,[76057]=1,[90637]=1,[89112]=1,[52332]=1,[52334]=1,[52335]=1,[52337]=1,[52336]=1,[52333]=1,[52330]=1,[52328]=1,[52327]=1,[52325]=1,[52329]=1,[52326]=1,[54464]=1,[40248]=1,[37700]=1,[37705]=1,[37704]=1,[37703]=1,[37701]=1,[37702]=1,[35625]=1,[35624]=1,[35623]=1,[35622]=1,[35627]=1,[36860]=1,[22573]=1,[22572]=1,[22578]=1,[22577]=1,[22576]=1,[22575]=1,[22574]=1,[22451]=1,[22452]=1,[21885]=1,[22457]=1,[21884]=1,[22456]=1,[21886]=1,[23571]=1,[7076]=1,[12808]=1,[12803]=1,[7082]=1,[7080]=1,[7078]=1,[10286]=1,[7972]=1,[7081]=1,[7077]=1,[7075]=1,[7079]=1,[7067]=1,[7068]=1,[7069]=1,[7070]=1 }
IsInscription = { [79251]=1,[79253]=1,[61979]=1,[43109]=1,[39343]=1,[43108]=1,[39342]=1,[43107]=1,[39341]=1,[43106]=1,[39340]=1,[43105]=1,[39339]=1,[43104]=1,[39338]=1,[43103]=1,[39334]=1,[39151]=1,[87828]=1 }
Specials = { [93962]=1,[87903]=1,[76337]=1,[76334]=1,[76335]=1,[75275]=1,[75276]=1,[75256]=1,[75258]=1,[75259]=1,[76298]=1,[76297]=1,[93668]=1,[93731]=1,[93733]=1,[93734]=1,[94130]=1,[94233]=1,[94288]=1,[94295]=1,[94918]=1,[95350]=1,[95374]=1,[95408]=1,[95409]=1,[95410]=1,[95411]=1,[95412]=1,[95491]=90,[95497]=1 }

throwAway = {};
CrapTable = {};
NotCrapTable = {};
CrapCount=0;
NotCrapCount=0;

DefaultGrindLootOptions = {};
DefaultGrindLootOptions["Version"]=9;
DefaultGrindLootOptions["Enabled"]=true;
DefaultGrindLootOptions["MiningMode"]=false;
DefaultGrindLootOptions["SkinningMode"]=false;
DefaultGrindLootOptions["FishingMode"]=false;
DefaultGrindLootOptions["FishingModeNoJunk"]=false;
DefaultGrindLootOptions["LootValuable"]=true;
DefaultGrindLootOptions["MinimumValue"]=19999;
DefaultGrindLootOptions["MinimumRarity"]=2;
DefaultGrindLootOptions["MinimumCloth"]=86;
DefaultGrindLootOptions["CloseLootWindow"]=false;
DefaultGrindLootOptions["Wanted"]={ [28513]=28513 };
DefaultGrindLootOptions["Discard"]={};
DefaultGrindLootOptions["AutoConfirm"]=false;
DefaultGrindLootOptions["NewBlip"]=false;

GrindLootOptionsTemp={};
GrindLootDebug=false;
nodbwarn=true;

function GMessage(message)
	DEFAULT_CHAT_FRAME:AddMessage("|cff00e0ff[GrindLoot]|r: "..message)
end

local events = CreateFrame("Frame"), {};

OriginalLoot=LootSlot;
function AutoConfirmBoP_LootSlot(slot)
	OriginalLoot(slot);
	ConfirmLootSlot(slot);
end

function events:LOOT_OPENED(arg1)
	LootIt(arg1)
end
function events:ADDON_LOADED(arg1)
	if(arg1=="GrindLoot") then
		GMessage("v 9.12 Loaded");

		SLASH_GLOOT1 = "/grindloot";
		SLASH_GLOOT2 = "/gloot";

		if(GrindLootOptions==nil) then
			for k, v in pairs(DefaultGrindLootOptions) do GrindLootOptions[k]=v; end
			LootSlot=OriginalLoot;
			return;			
		end

		if (GrindLootOptions["Version"]==nil) then
			for k, v in pairs(DefaultGrindLootOptions) do GrindLootOptions[k]=v; end
			if GrindLootOptions["NotCrap"] then
				for k,v in pairs(GrindLootOptions["NotCrap"]) do 
					local Id=tonumber(k);
					GrindLootOptions["Wanted"][Id]=Id;
				end
			end
			if GrindLootOptions["Crap"] then
				for k,v in pairs(GrindLootOptions["Crap"]) do 
					local Id=tonumber(k);
					GrindLootOptions["Discard"][Id]=Id;
				end
			end
			GMessage("Old options detected - they have been set to default values");
			LootSlot=OriginalLoot;
		else 
			if (GrindLootOptions["Version"]~=9) then
				for k, v in pairs(DefaultGrindLootOptions) do GrindLootOptions[k]=v; end
				if GrindLootOptions["NotCrap"] then
					for k,v in pairs(GrindLootOptions["NotCrap"]) do 
						local Id=tonumber(k);
						GrindLootOptions["Wanted"][Id]=Id;
					end
				end
				if GrindLootOptions["Crap"] then
					for k,v in pairs(GrindLootOptions["Crap"]) do 
						local Id=tonumber(k);
						GrindLootOptions["Discard"][Id]=Id;
					end
				end
				GMessage("Old options detected - they have been set to default values");
				LootSlot=OriginalLoot;			
			end
		end
		
		for k, v in pairs(GrindLootOptions) do
	 		if DefaultGrindLootOptions[k]==nil then GrindLootOptions[k]=nil; end
		end

		for k, v in pairs(DefaultGrindLootOptions) do
	 		if (GrindLootOptions[k]==nil) or (GrindLootOptions[k]=='') then GrindLootOptions[k]=v; end
		end
		
		if GrindLootOptions["LootValuable"] then
			if GrindLootOptions["MinimumValue"]==nil then GrindLootOptions["MinimumValue"]=DefaultGrindLootOptions["MinimumValue"] end
			if GrindLootOptions["MinimumValue"]==0 then GrindLootOptions["MinimumValue"]=DefaultGrindLootOptions["MinimumValue"] end
		end
		if(GrindLootOptions["AutoConfirm"]==true)then
			LootSlot=AutoConfirmBoP_LootSlot;
		else
			GrindLootOptions["AutoConfirm"]=false;
		end
		if (GrindLootOptions["NewBlip"]) and (GrindLootOptions["NewBlip"]==true) then
			Minimap:SetBlipTexture("Interface\\Addons\\GrindLoot\\MMOIconsG.tga");
		else
			Minimap:SetBlipTexture("Interface\\Minimap\\ObjectIcons");
		end
	end
end

function lines(str)
  local t = {}
  local function helper(line) table.insert(t, line) return "" end
  helper((str:gsub("(.-) ", helper)))
  return t
end


function SlashCmdList.GLOOT(msg, editbox)
	local cmd,cmod,itm=msg:match("^(%S*)%s*(%S*)%s*(.-)$");
	
	if (string.upper(msg)=="DEBUG") or (string.upper(cmd)=="DEBUG") then
		GrindLootDebug=not GrindLootDebug;
		if (string.upper(cmod)=="ON") then GrindLootDebug=true; end
		if (string.upper(cmod)=="OFF") then GrindLootDebug=false; end
		if GrindLootDebug then
			GMessage("Debug mode is ON");
		else
			GMessage("Debug mode is OFF");
		end
		return;
	end
	if (string.upper(msg)=="OFF") or (string.upper(cmd)=="OFF") then
		GrindLootOptions["Enabled"]=false;
		GMessage("Functionality Disabled");
		SetCVar("autoLootDefault",1);
		GMessage("Blizzard AutoLoot is now Enabled");
		if(GrindLootOptions["AutoConfirm"]==true)then
			LootSlot=OriginalLoot;
			GMessage("Autoconfirm BoP is now disabled");
		end
		return;
	end
	if (string.upper(msg)=="ON") or (string.upper(cmd)=="ON") then
		GrindLootOptions["Enabled"]=true;
		GMessage("Functionality Enabled");
		SetCVar( "autoLootDefault",0);
		GMessage("Blizzard AutoLoot is now Disabled");
		if(GrindLootOptions["AutoConfirm"]==true)then
			LootSlot=AutoConfirmBoP_LootSlot;
			GMessage("Autoconfirm BoP is now enabled");
		end

		return;
	end
	if (string.upper(msg)=="DEFAULTS") or (string.upper(cmd)=="DEFAULTS") then
		for k, v in pairs(DefaultGrindLootOptions) do GrindLootOptions[k]=v; end
		GMessage("Options set to default values");
		LootSlot=OriginalLoot;
		return;
	end

	if cmd and (string.upper(cmd)=="WHITELIST") then
		if ((cmod==nil) or ((string.upper(cmod)~="ADD") and (string.upper(cmod)~="DEL") and (string.upper(cmod)~="CLEAR") and (string.upper(cmod)~="SHOW"))) then
			GMessage("WHITELIST MANAGEMENT: \n|cff00e0ff/gloot whitelist add <itemLink>|r to add a item to allways loot list\n|cff00e0ff/gloot whitelist del <itemLink>|r to delete a item from the allways loot list\n|cff00e0ff/gloot whitelist clear|r to delete all items from the allways loot list\n|cff00e0ff/gloot whitelist show|r to display a list of all items from the allways loot list");
			return;
		end
		if (string.upper(cmod)=="ADD") and (itm~=nil) then
			local itemName,itemLink=GetItemInfo(itm);
			if(itemLink~=nil)then
				local _, _, Color, Ltype, Id, Enchant, Gem1, Gem2, Gem3, Gem4, Suffix, Unique, LinkLvl, Name = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
				Id=tonumber(Id);
				GrindLootOptions["Wanted"][Id]=Id;
				GMessage("Whitelist: added "..itemLink);
			else
				GrindLootOptions["Wanted"][itm]=itm;
				GMessage("Whitelist: added "..itm.." as string");
			end
			
		end
		if (string.upper(cmod)=="DEL") and (itm~=nil) then
			local itemName,itemLink=GetItemInfo(itm);
			if(itemLink~=nil)then
				local _, _, Color, Ltype, Id, Enchant, Gem1, Gem2, Gem3, Gem4, Suffix, Unique, LinkLvl, Name = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
				Id=tonumber(Id);
				GrindLootOptions["Wanted"][Id]=nil;
				GMessage("Whitelist: deleted "..itemLink);
			else
				GrindLootOptions["Wanted"][itm]=nil;
				GMessage("Whitelist: deleted "..itm.." as string");
			end		
		end
		if (string.upper(cmod)=="CLEAR") then
			GrindLootOptions["Wanted"]={};
			GMessage("Whitelist: is now empty");
		end
		if (string.upper(cmod)=="SHOW") then
			GMessage("Whitelist contents");
			for k,v in pairs(GrindLootOptions["Wanted"]) do 
				if (type(k)=="string") then 
					print(k);
				else
					local itemName,itemLink=GetItemInfo(k);
					print(itemLink);
				end
			end
		end
		
		return;
	end
	if cmd and (string.upper(cmd)=="BLACKLIST") then
		if ((cmod==nil) or ((string.upper(cmod)~="ADD") and (string.upper(cmod)~="DEL") and (string.upper(cmod)~="CLEAR") and (string.upper(cmod)~="SHOW"))) then
			GMessage("BLACKLIST MANAGEMENT: \n|cff00e0ff/gloot blacklist add <itemLink>|r to add a item to the list of items you dont want to loot\n|cff00e0ff/gloot blacklist del <itemLink>|r to delete a item from the 'bad loot' list\n|cff00e0ff/gloot blacklist clear|r to delete all items from the blacklist\n|cff00e0ff/gloot blacklist show|r to display a list of all items from the never loot list");
			return;
		end
		if (string.upper(cmod)=="ADD") and (itm~=nil) then
			local itemName,itemLink=GetItemInfo(itm);
			if(itemLink~=nil)then
				local _, _, Color, Ltype, Id, Enchant, Gem1, Gem2, Gem3, Gem4, Suffix, Unique, LinkLvl, Name = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
				Id=tonumber(Id);
				GrindLootOptions["Discard"][Id]=Id;
				GMessage("Blacklist: added "..itemLink);
			else
				GrindLootOptions["Discard"][itm]=itm;
				GMessage("Blacklist: added "..itm.." as string");
			end
		end
		if (string.upper(cmod)=="DEL") and (itm~=nil) then
			local itemName,itemLink=GetItemInfo(itm);
			if(itemLink~=nil)then
				local _, _, Color, Ltype, Id, Enchant, Gem1, Gem2, Gem3, Gem4, Suffix, Unique, LinkLvl, Name = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
				Id=tonumber(Id);
				GrindLootOptions["Discard"][Id]=nil;
				GMessage("Blacklist: deleted "..itemLink);
			else
				GrindLootOptions["Discard"][itm]=itm;
				GMessage("Blacklist: deleted "..itm.." as string");
			end		
		end
		if (string.upper(cmod)=="CLEAR") then
				GrindLootOptions["Discard"]={};
				GMessage("Blacklist: is now empty");
		end
		if (string.upper(cmod)=="SHOW") then
			GMessage("Blacklist contents");
			for k,v in pairs(GrindLootOptions["Discard"]) do 
				if (type(k)=="string") then 
					print(k);
				else
					local itemName,itemLink=GetItemInfo(k);
					print(itemLink);
				end
			end
		end
		
		return;
	end
	if msg~='' then
		GMessage("useful command line parameters are: debug, on, off, defaults, whitelist, blacklist\nUsing no parameters will display the options tab... as we are going to do now");
	end

	InterfaceOptionsFrame_OpenToCategory("GrindLoot");
end

function GrindLootOptionsPanelShow(a)
	MoneyInputFrame_SetCopper(GUIMinimumValue,0);
	MoneyInputFrame_SetCopper(GUIMinimumValue,1);
	if(GrindLootOptions["Wanted"]==nil) then GrindLootOptions["Wanted"]={}; end;
	if(GrindLootOptions["Discard"]==nil) then GrindLootOptions["Discard"]={}; end;	
	if(GrindLootOptions["Wanted"]==false) then GrindLootOptions["Wanted"]={}; end;
	if(GrindLootOptions["Discard"]==false) then GrindLootOptions["Discard"]={}; end;	
	for k, v in pairs(GrindLootOptions) do GrindLootOptionsTemp[k]=v; end

	GUIMinimumRarityClick(nil,GrindLootOptionsTemp["MinimumRarity"]);
	GUIMinimumClothClick(nil,GrindLootOptionsTemp["MinimumCloth"]);

	GUIGrindLootEnabled:SetChecked(GrindLootOptionsTemp["Enabled"]);

	GUIMiningMode:SetChecked(GrindLootOptionsTemp["MiningMode"]);
	GUISkinningMode:SetChecked(GrindLootOptionsTemp["SkinningMode"]);
	GUIFishingMode:SetChecked(GrindLootOptionsTemp["FishingMode"]);
	GUIAutoBOPMode:SetChecked(GrindLootOptionsTemp["AutoConfirm"]);
	GUINewBlipMode:SetChecked(GrindLootOptionsTemp["NewBlip"]);


	GUILootValuable:SetChecked(GrindLootOptionsTemp["LootValuable"]);
	GUICloseLootWindow:SetChecked(GrindLootOptionsTemp["CloseLootWindow"]);

	if (GrindLootOptionsTemp["MinimumValue"]==0) and (GrindLootOptionsTemp["LootValuable"]) then
		GrindLootOptionsTemp["MinimumValue"]=DefaultGrindLootOptions["MinimumValue"];
		GrindLootOptions["MinimumValue"]=DefaultGrindLootOptions["MinimumValue"];
	end
	MoneyInputFrame_SetCopper(GUIMinimumValue,GrindLootOptionsTemp["MinimumValue"]);
	
end

function GrindLootOptionsPanelHide()

end

function GUIMinimumRarityClick(self,arg1)
	GrindLootOptionsTemp["MinimumRarity"]=arg1;
	UIDropDownMenu_SetSelectedValue(GUIMinimumRarity,GrindLootOptionsTemp["MinimumRarity"]);
	UIDropDownMenu_SetText(GUIMinimumRarity,RarityNames[GrindLootOptionsTemp["MinimumRarity"]]);
end
function GUIMinimumClothClick(self,arg1)
	GrindLootOptionsTemp["MinimumCloth"]=arg1;
	UIDropDownMenu_SetSelectedValue(GUIMinimumCloth,GrindLootOptionsTemp["MinimumCloth"]);
	UIDropDownMenu_SetText(GUIMinimumCloth,ClothNames[GrindLootOptionsTemp["MinimumCloth"]]);
end

function MiningClick()
	GrindLootOptionsTemp["MiningMode"]=(GUIMiningMode:GetChecked()==1);
end

function SkinningClick()
	GrindLootOptionsTemp["SkinningMode"]=(GUISkinningMode:GetChecked()==1);
end

function FishingClick()
	GrindLootOptionsTemp["FishingMode"]=(GUIFishingMode:GetChecked()==1);
end

function EnabledClick()
	GrindLootOptionsTemp["Enabled"]=(GUIGrindLootEnabled:GetChecked()==1);
end

function ValuableClick()
	GrindLootOptionsTemp["LootValuable"]=(GUILootValuable:GetChecked()==1);
end

function CloseLootClick()
	GrindLootOptionsTemp["CloseLootWindow"]=(GUICloseLootWindow:GetChecked()==1);
end

function AutoBoPClick()
	GrindLootOptionsTemp["AutoConfirm"]=(GUIAutoBOPMode:GetChecked()==1);
end

function NewBlipClick()
	GrindLootOptionsTemp["NewBlip"]=(GUINewBlipMode:GetChecked()==1);

	if (GrindLootOptionsTemp["NewBlip"]) and (GrindLootOptionsTemp["NewBlip"]==true) then
		Minimap:SetBlipTexture("Interface\\Addons\\GrindLoot\\MMOIconsG.tga");
	else
		Minimap:SetBlipTexture("Interface\\Minimap\\ObjectIcons");
	end

end

function GrindLootOptionsOK()
	for k, v in pairs(GrindLootOptionsTemp) do GrindLootOptions[k]=v; end
	GrindLootOptions["MinimumValue"]=MoneyInputFrame_GetCopper(GUIMinimumValue);
	if(GrindLootOptions["AutoConfirm"]==true)then
		LootSlot=AutoConfirmBoP_LootSlot;
	else
		LootSlot=OriginalLoot;
	end
	if (GrindLootOptions["NewBlip"]) and (GrindLootOptions["NewBlip"]==true) then
		Minimap:SetBlipTexture("Interface\\Addons\\GrindLoot\\MMOIconsG.tga");
	else
		Minimap:SetBlipTexture("Interface\\Minimap\\ObjectIcons");
	end

end

function GrindLootOptionsCancel()
	for k, v in pairs(GrindLootOptions) do GrindLootOptionsTemp[k]=v; end
	if(GrindLootOptions["AutoConfirm"]==true)then
		LootSlot=AutoConfirmBoP_LootSlot;
	else
		LootSlot=OriginalLoot;
	end
	if (GrindLootOptions["NewBlip"]) and (GrindLootOptions["NewBlip"]==true) then
		Minimap:SetBlipTexture("Interface\\Addons\\GrindLoot\\MMOIconsG.tga");
	else
		Minimap:SetBlipTexture("Interface\\Minimap\\ObjectIcons");
	end
end

function GrindLootOptionsDefault()
	for k, v in pairs(DefaultGrindLootOptions) do GrindLootOptions[k]=v; end
	GrindLootOptionsPanelShow();
	LootSlot=OriginalLoot;
	Minimap:SetBlipTexture("Interface\\Minimap\\ObjectIcons");
end

Options = {};
Options.panel = CreateFrame( "Frame", "GrindLootOptions", UIParent );
Options.panel.name = "GrindLoot";
Options.panel.okay = GrindLootOptionsOK;
Options.panel.cancel = GrindLootOptionsCancel;
Options.panel.default = GrindLootOptionsDefault;
InterfaceOptions_AddCategory(Options.panel);

Options.panel:SetScript("OnShow", GrindLootOptionsPanelShow);
Options.panel:SetScript("OnHide", GrindLootOptionsPanelHide);
Options.panel:SetScript("OnEvent", function(self, event, ...)
 events[event](self, ...);
end);
for k, v in pairs(events) do
 Options.panel:RegisterEvent(k);
end

GUIinfoHeader=Options.panel:CreateFontString("infoHeader","OVERLAY");
GUIinfoText=Options.panel:CreateFontString("InfoText","OVERLAY");
GUIGrindLootEnabled=CreateFrame("CheckButton", "GrindLootCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUIMiningMode=CreateFrame("CheckButton", "MiningCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUISkinningMode=CreateFrame("CheckButton", "SkinningCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUIFishingMode=CreateFrame("CheckButton", "FishingCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUILootValuable=CreateFrame("CheckButton", "ValuableCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUIMinimumValue=CreateFrame("Frame", "MinimumValue", Options.panel, "MoneyInputFrameTemplate");
GUIMinimumRarityHeader=Options.panel:CreateFontString("RarityHeader","OVERLAY");
GUIMinimumRarity=CreateFrame("Frame", "RarityDropDown", Options.panel, "UIDropDownMenuTemplate");
GUIMinimumClothHeader=Options.panel:CreateFontString("ClothHeader","OVERLAY");
GUIMinimumCloth=CreateFrame("Frame", "ClothDropDown", Options.panel, "UIDropDownMenuTemplate");
GUICloseLootWindow=CreateFrame("CheckButton", "CloseCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUIAutoBOPMode=CreateFrame("CheckButton", "AutoConfirmCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");
GUINewBlipMode=CreateFrame("CheckButton", "NewBlipCheckBox", Options.panel, "ChatConfigCheckButtonTemplate");

function MakeRarityButton(info,MenuValue)
	info.text=RarityNames[MenuValue];
	info.value=MenuValue;
	info.func=GUIMinimumRarityClick;
	info.arg1=MenuValue;
	info.tooltipTitle=RarityNames[MenuValue];
	if MenuValue==0 then
		info.tooltipText="As the name suggests: looting based on rarity is "..RarityNames[MenuValue]..".";
	else
		info.tooltipText="Loot items if "..RarityNames[MenuValue].." or better.";
	end
	UIDropDownMenu_AddButton(info);
end

function GUIMinimumRarity_Initialize(self)
	local info=UIDropDownMenu_CreateInfo();
	info.notCheckable=true;
	local MenuValue=0;MakeRarityButton(info,MenuValue);
	MenuValue=2;MakeRarityButton(info,MenuValue);
	MenuValue=3;MakeRarityButton(info,MenuValue);
	MenuValue=4;MakeRarityButton(info,MenuValue);
end

function MakeClothButton(info,MenuValue)
	info.text=ClothNames[MenuValue];
	info.value=MenuValue;
	info.func=GUIMinimumClothClick;
	info.arg1=MenuValue;
	info.tooltipTitle=ClothNames[MenuValue];
	if MenuValue==0 then
		info.tooltipText="As the name suggests: looting cloth is "..ClothNames[MenuValue]..".";
	else
		info.tooltipText="Loot only "..ClothNames[MenuValue].." or better.";
	end
	UIDropDownMenu_AddButton(info);
end

function GUIMinimumCloth_Initialize(self)
	local info=UIDropDownMenu_CreateInfo();
	info.notCheckable=true;
	local MenuValue=0;MakeClothButton(info,MenuValue);
	MenuValue=5;MakeClothButton(info,MenuValue);
	MenuValue=15;MakeClothButton(info,MenuValue);
	MenuValue=30;MakeClothButton(info,MenuValue);
	MenuValue=40;MakeClothButton(info,MenuValue);
	MenuValue=50;MakeClothButton(info,MenuValue);
	MenuValue=60;MakeClothButton(info,MenuValue);
	MenuValue=70;MakeClothButton(info,MenuValue);
	MenuValue=81;MakeClothButton(info,MenuValue);
	MenuValue=86;MakeClothButton(info,MenuValue);	
end


UIDropDownMenu_Initialize(GUIMinimumRarity, GUIMinimumRarity_Initialize);
UIDropDownMenu_Initialize(GUIMinimumCloth, GUIMinimumCloth_Initialize);

GUIinfoHeader:SetFontObject("OptionsFontLarge");
GUIinfoHeader:SetText("GrindLoot v9.12 Options");
GUIinfoHeader:SetPoint("TOPLEFT",25,-20);

GUIinfoText:SetFontObject("OptionsFontHighlightSmall");
GUIinfoText:SetText("Here you can set up your desired loot quality, type, value ... behaviour. Please keep in mind that this is by no means a addon designed for casual play or leveling. It can be useful, but you want this when youre going on a mining spree, collecting leather, leveling fishing, gathering silk cloth and dont want wool.");
GUIinfoText:SetPoint("TOPLEFT",35,-40);
GUIinfoText:SetWidth(370);
GUIinfoText:SetJustifyH("LEFT");

GrindLootCheckBoxText:SetText("GrindLoot Enabled");
GUIGrindLootEnabled.tooltip = "Enable or disable GrindLoot.";
GUIGrindLootEnabled:SetScript("OnClick", EnabledClick);

MiningCheckBoxText:SetText("Mining Mode");
GUIMiningMode.tooltip = "Loot EVERYTHING but throw away rocks.";
GUIMiningMode:SetScript("OnClick", MiningClick);

SkinningCheckBoxText:SetText("Skinning Mode");
GUISkinningMode.tooltip = "Loot EVERYTHING but on next loot throw away poor quality stuff.";
GUISkinningMode:SetScript("OnClick", SkinningClick);

FishingCheckBoxText:SetText("Fishing Mode");
GUIFishingMode.tooltip = "Loot only high level fish if it's fishing loot.";
GUIFishingMode:SetScript("OnClick", FishingClick);

ValuableCheckBoxText:SetText("I-Want-Money Mode");
GUILootValuable.tooltip = "If a stack has a higher value. I want it...";
GUILootValuable:SetScript("OnClick", ValuableClick);

CloseCheckBoxText:SetText("Autoclose loot");
GUICloseLootWindow.tooltip = "It will automatically close the loot window - after processing the stuff - regardless of it's remaining contents.";
GUICloseLootWindow:SetScript("OnClick", CloseLootClick);

AutoConfirmCheckBoxText:SetText("Automatically confirm Bind on Pickup items");
GUIAutoBOPMode.tooltip = "It will automatically confirm the bind on pickup items. Only applicable in groups really. You should be grinding alone tho and even in a group a BoP Confirm window i see as a good thing, to think a bit to the other player needs.";
GUIAutoBOPMode:SetScript("OnClick", AutoBoPClick);

NewBlipCheckBoxText:SetText("Use the GrindLoot resource blip");
GUINewBlipMode.tooltip = "Resource nodes (Ore/Herbs/Fishing) will appear on the minimap using a different (more visible i hope) icon.";
GUINewBlipMode:SetScript("OnClick", NewBlipClick);

GUIMinimumRarityHeader:SetFontObject("OptionsFontLarge");
GUIMinimumRarityHeader:SetText("Rarity Looting");
GUIMinimumRarityHeader:SetPoint("TOPLEFT",25,-130);

GUIMinimumClothHeader:SetFontObject("OptionsFontLarge");
GUIMinimumClothHeader:SetText("Cloth Looting");
GUIMinimumClothHeader:SetPoint("TOPLEFT",265,-130);

GUIMinimumRarity:SetPoint("TOPLEFT",10,-150);
GUIMinimumCloth:SetPoint("TOPLEFT",250,-150);

GUIGrindLootEnabled:SetPoint("TOPLEFT",140,-100);
GUIMiningMode:SetPoint("TOPLEFT",25,-200);
GUISkinningMode:SetPoint("TOPLEFT",25,-230);
GUIFishingMode:SetPoint("TOPLEFT",25,-260);

GUILootValuable:SetPoint("TOPLEFT",25,-300);
GUIMinimumValue:SetPoint("TOPLEFT",200,-300);

GUICloseLootWindow:SetPoint("TOPLEFT",25,-330);
GUIAutoBOPMode:SetPoint("TOPLEFT",25,-360);
GUINewBlipMode:SetPoint("TOPLEFT",25,-390);

MoneyInputFrame_SetCopper(GUIMinimumValue,0);

local function GetLootId( slot )
	local itemId = 0
	local link = GetLootSlotLink( slot )
	if link then
		local _, _, idCode = string.find(link, "|Hitem:(%d+):(%d+):(%d+):")
		itemId = tonumber( idCode or 0 )
	end
	return itemId
end

function LootIt(self)
	
	if GrindLootDebug then GMessage("Start Looting"); end

	if  not GrindLootOptions["MinimumValue"] then
		GrindLootOptions["MinimumValue"]=19999;
	end
	
	if(GrindLootOptions["Enabled"])then

		if not GetSellValue and nodbwarn then
			GMessage("Vendor prices database not found. Items will not be looted based on stack value.");
			nodbwarn=false;
		end

		SetCVar( "autoLootDefault",0);

		local cnt = GetNumLootItems();
		if cnt==0 then
			GMessage("Empty loot!");
			CloseLoot();
			return;
		end

		local bagID=0;
		local bagItemID=false;
		local bagCount=0;
		local isinbag={};

		if next(throwAway) ~= nil then
			GMessage("Discarding unwanted stuff");
			for bagID=0,NUM_BAG_SLOTS do
				bagCount=GetContainerNumSlots(bagID);
				if bagCount>0 then
					for slotID=1,bagCount do
						bagItemID=GetContainerItemID(bagID, slotID);
						if bagItemID ~= nil then
							if throwAway[bagItemID] then
								if GrindLootDebug then GMessage("Deleting item ID "..bagItemID); end
								PickupContainerItem(bagID,slotID);
								DeleteCursorItem();
							end
						end
					end
				end
			end
			throwAway={};
		end

		local WantedShortList={};
		for k,v in pairs(GrindLootOptions["Wanted"]) do 
			if (type(k)=="string") then 
				WantedShortList[k]=k;
			end
		end
		local UnWantedShortList={};
		for k,v in pairs(GrindLootOptions["Discard"]) do 
			if (type(k)=="string") then 
				UnWantedShortList[k]=k;
			end
		end
		
		
		for bagID=0,NUM_BAG_SLOTS do
			bagCount=GetContainerNumSlots(bagID);
			if bagCount>0 then
				for slotID=1,bagCount do
					bagItemID=GetContainerItemID(bagID, slotID);
					if bagItemID ~= nil then
						isinbag[bagItemID]=true;
					end
				end
			end
		end

		for lootSlot=1,cnt do
			local canloot = false;

			local texture, itemName, quantity, quality = GetLootSlotInfo(lootSlot)
			local itemID = GetLootId(lootSlot)
			local itemName2, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc = GetItemInfo(itemID)

			if itemRarity==nil then itemRarity=0; end
			if itemID==nil then itemID=0; end
			if itemLink==nil then itemLink="ID:"..itemID; end
			if GrindLootDebug then GMessage("Processing "..itemLink); end

			local sellToVendorPrice=0;
			if GetSellValue then
				sellToVendorPrice = GetSellValue(itemID);
			end	
			
			if GrindLootOptions["LootValuable"] and sellToVendorPrice and itemStackCount and ((itemStackCount*sellToVendorPrice)>GrindLootOptions["MinimumValue"]) then
				canloot=true;
				if GrindLootDebug then GMessage("Value loot "..itemLink); end
			end

			if (GetLootSlotType(lootSlot)==LOOT_SLOT_MONEY) or (GetLootSlotType(lootSlot)==LOOT_SLOT_CURRENCY) then
				canloot=true;
				if GrindLootDebug then GMessage("This is money ... or other currency!"); end
			end
			if isinbag[itemID] then
				canloot=true;
				if GrindLootDebug then GMessage("Is in bag allready "..itemLink); end
			end
			if IsDisenchanting[itemID] or (itemType=="Quest") or (itemType=="Key") or IsElemental[itemID] or IsArchaeology[itemName] or IsHerb[itemID] or IsRogueBox[itemID] then
				canloot=true;
				if GrindLootDebug then GMessage("Allways loot (Quest/Key/DE/Elemental/Archeology/Herb/RogueBoxes/Desired) "..itemLink); end
			end			
			if IsCloth[itemID] and (GrindLootOptions["MinimumCloth"]>0) and (itemLevel>=GrindLootOptions["MinimumCloth"]) then
				canloot=true;
				if GrindLootDebug then GMessage("Cloth loot "..itemLink); end
			end
			if (GrindLootOptions["MinimumRarity"]>0) and (itemRarity>=GrindLootOptions["MinimumRarity"]) then
				canloot=true;
				if GrindLootDebug then GMessage("Rarity loot "..itemLink); end
			end
			if IsFishingLoot() and GrindLootOptions["FishingMode"] and ( (itemLevel>=81) or (string.find(itemName," Coin") ~= nil) ) then
				canloot=true;
				if GrindLootDebug then GMessage("Fishing loot "..itemLink); end
			end
			
			if IsMining[itemID] and GrindLootOptions["MiningMode"] then
				canloot=true;
				if GrindLootDebug then GMessage("Mining loot "..itemLink); end
				if IsStone[itemID] then
					throwAway[itemID]=true;
					if GrindLootDebug then GMessage("Discard stone on next loot "..itemLink); end
				end
			end

			if IsLeather[itemID] then
				canloot=true;
				if GrindLootDebug then GMessage("Leather loot "..itemLink); end
			end

			if (Specials[itemID]) then
				canloot=true;
				if GrindLootDebug then GMessage("Will loot from special list "..itemLink); end
			end
			
			
			if (GrindLootOptions["Wanted"][itemID]) then
				canloot=true;
				if GrindLootDebug then GMessage("Will loot from wanted list "..itemLink); end
			end
			if (GrindLootOptions["Discard"][itemID]) then
				canloot=false;
				if GrindLootDebug then GMessage("Deny loot of unwanted "..itemLink); end
			end

			for k,v in pairs(WantedShortList) do 
				if(string.find(itemName,k) ~= nil)then
					canloot=true;
					if GrindLootDebug then GMessage("Will loot from wanted list "..itemLink); end
					break;
				end
			end
			for k,v in pairs(UnWantedShortList) do 
				if(string.find(itemName,k) ~= nil)then
					canloot=false;
					if GrindLootDebug then GMessage("Deny loot of unwanted "..itemLink); end
					break;
				end
			end
			
			if GrindLootOptions["SkinningMode"] then
				if not canloot then
					throwAway[itemID]=true;
					if GrindLootDebug then GMessage("Discard unwanted loot for skin "..itemLink); end
				end
				canloot=true;
			end			
			
			if canloot then
				LootSlot(lootSlot);
			end
		end
		if GrindLootOptions["CloseLootWindow"] then
			CloseLoot();
		end
	else
		if GrindLootDebug then GMessage("is Disabled"); end
	end
end

