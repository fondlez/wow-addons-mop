-- Constants
local ADDON_NAME = "GearGrinder"
local VALOR_CURRENCY_ID = 396
local JUSTICE_CURRENCY_ID = 395
local HONOR_CURRENCY_ID = 392
local CONQUEST_CURRENCY_ID = 390
local ELDER_CHARM_CURRENCY_ID = 697
local LESSER_CHARM_CURRENCY_ID = 738
local MOGU_CHARM_CURRENCY_ID = 752
local TIMELESS_CHARM_CURRENCY_ID = 777
local WARSEAL_CHARM_CURRENCY_ID = 776

local WHITE_BRIGHT_COLOR = "|cffFFFFFF"
local YELLOW_NEON_COLOR = "|cffFFFF00"
local RED_NEON_COLOR = "|cffFF0000"
local ORANGE_NEON_COLOR = "|cffEE6622"
local GREEN_NEON_COLOR = "|cff00FF00"
local GREY_COLOR = "|cff9d9d9d"
local END_COLOR = FONT_COLOR_CODE_CLOSE
local INFO_COLOR = "|cFFFFCC00"

-- list of dungeonIDs of interest to the addon
--/script for i=1, GetNumRFDungeons() do local a,b,_,_,_,_,_,_,_,c = GetRFDungeonInfo(i); print(i, a, b, c) end
--/script for i=656, 1000 do local a,b,c = GetDungeonInfo(i); if a == nil then else print(i, a, b, c) end end
--/script local t=GetQuestsCompleted();print('32919 .. ', t[32919]);
--/script local t=GetQuestsCompleted();print('32922 .. ', t[32922]);
--/script local t=GetQuestsCompleted();print('32923 .. ', t[32923]);
--/script local t=GetQuestsCompleted();print('32924 .. ', t[32924]);
--/script local t=GetQuestsCompleted();print('33117 .. ', t[33117]);
--/script local t=GetQuestsCompleted();print('33118 .. ', t[33118]);
--/script local t=GetQuestsCompleted();print('33225 .. ', t[33225]);
--/script local t=GetQuestsCompleted();print('33226 .. ', t[33226]);

--[[
	Dungeon IDs
[14:50:16] 1 Wailing Caverns WAILINGCAVERNS [Wailing Caverns]
[14:50:16] 2 Scholomance SCHOLOMANCE [Scholomance]
[14:50:16] 4 Ragefire Chasm RAGEFIRECHASM [Ragefire Chasm]
[14:50:16] 6 Deadmines DEADMINES [Deadmines]
[14:50:16] 8 Shadowfang Keep SHADOWFANGKEEP [Shadowfang Keep]
[14:50:16] 10 Blackfathom Deeps BLACKFATHOMDEEPS [Blackfathom Deeps]
[14:50:16] 12 Stormwind Stockade STORMWINDSTOCKADES [The Stockade]
[14:50:16] 14 Gnomeregan GNOMEREGAN [Gnomeregan]
[14:50:16] 16 Razorfen Kraul RAZORFENKRAUL [Razorfen Kraul]
[14:50:16] 20 Razorfen Downs RAZORFENDOWNS [Razorfen Downs]
[14:50:16] 22 Uldaman ULDAMAN [Uldaman]
[14:50:16] 24 Zul'Farrak ZULFARAK [Zul'Farrak]
[14:50:16] 26 Maraudon - Foulspore Cavern MARAUDON [Maraudon]
[14:50:16] 28 Sunken Temple SUNKENTEMPLE [The Temple of Atal'hakkar]
[14:50:16] 30 Blackrock Depths - Detention Block BLACKROCKDEPTHS [Blackrock Depths]
[14:50:16] 32 Lower Blackrock Spire BLACKROCKSPIRE [Blackrock Spire]
[14:50:16] 34 Dire Maul - Warpwood Quarter DIREMAUL [Dire Maul]
[14:50:16] 36 Dire Maul - Capital Gardens DIREMAUL [Dire Maul]
[14:50:16] 38 Dire Maul - Gordok Commons DIREMAUL [Dire Maul]
[14:50:16] 40 Stratholme - Main Gate STRATHOLME [Stratholme]
[14:50:16] 46 Onyxia's Lair ONYXIAENCOUNTER nil
[14:50:16] 48 Molten Core MOLTENCORE nil
[14:50:16] 50 Blackwing Lair BLACKWINGLAIR nil
[14:52:11] 136 Hellfire Ramparts HELLFIRECITADEL [Hellfire Ramparts]
[14:52:11] 137 Blood Furnace HELLFIRECITADEL [The Blood Furnace]
[14:52:11] 138 Shattered Halls HELLFIRECITADEL [The Shattered Halls]
[14:52:11] 140 Slave Pens COILFANG [The Slave Pens]
[14:52:11] 146 Underbog COILFANG [The Underbog]
[14:52:11] 147 The Steamvault COILFANG [The Steamvault]
[14:52:11] 148 Mana-Tombs AUCHINDOUN [Mana-Tombs]
[14:52:11] 149 Auchenai Crypts AUCHINDOUN [Auchenai Crypts]
[14:52:11] 150 Sethekk Halls AUCHINDOUN [Sethekk Halls]
[14:52:11] 151 Shadow Labyrinth AUCHINDOUN [Shadow Labyrinth]
[14:52:11] 159 Naxxramas NAXXRAMAS nil
[14:52:11] 160 Ahn'Qiraj Ruins AQRUINS nil
[14:52:11] 161 Ahn'Qiraj Temple AQTEMPLE nil
[14:52:11] 163 Scarlet Halls SCARLETMONASTERY [Scarlet Halls]
[14:52:11] 164 Scarlet Monastery SCARLETMONASTERY [Scarlet Monastery]
[14:52:11] 170 The Escape From Durnholde CAVERNSOFTIME [Old Hillsbrad Foothills]
[14:52:11] 171 Opening of the Dark Portal CAVERNSOFTIME [The Black Morass]
[14:52:11] 172 The Mechanar TEMPESTKEEP [The Mechanar]
[14:52:11] 173 The Botanica TEMPESTKEEP [The Botanica]
[14:52:11] 174 The Arcatraz TEMPESTKEEP [The Arcatraz]
[14:52:11] 175 Karazhan KARAZHAN nil
[14:52:11] 176 Magtheridon's Lair HELLFIRECITADELRAID nil
[14:52:11] 177 Gruul's Lair GRUULSLAIR nil
[14:52:11] 178 Auchenai Crypts AUCHINDOUN [Auchenai Crypts]
[14:52:11] 179 Mana-Tombs AUCHINDOUN [Mana-Tombs]
[14:52:11] 180 Sethekk Halls AUCHINDOUN [Sethekk Halls]
[14:52:11] 181 Shadow Labyrinth AUCHINDOUN [Shadow Labyrinth]
[14:52:11] 182 Opening of the Dark Portal CAVERNSOFTIME [The Black Morass]
[14:52:11] 183 The Escape From Durnholde CAVERNSOFTIME [Old Hillsbrad Foothills]
[14:52:11] 184 Slave Pens COILFANG [The Slave Pens]
[14:52:11] 185 The Steamvault COILFANG [The Steamvault]
[14:52:11] 186 Underbog COILFANG [The Underbog]
[14:52:11] 187 Blood Furnace HELLFIRECITADEL [The Blood Furnace]
[14:52:11] 188 Hellfire Ramparts HELLFIRECITADEL [Hellfire Ramparts]
[14:52:11] 189 Shattered Halls HELLFIRECITADEL [The Shattered Halls]
[14:52:11] 190 The Arcatraz TEMPESTKEEP [The Arcatraz]
[14:52:11] 191 The Botanica TEMPESTKEEP [The Botanica]
[14:52:11] 192 The Mechanar TEMPESTKEEP [The Mechanar]
[14:52:11] 193 Tempest Keep TEMPESTKEEP nil
[14:52:11] 194 Serpentshrine Cavern SERPENTSHRINECAVERN nil
[14:52:11] 195 Hyjal Past HYJALPAST nil
[14:52:11] 196 Black Temple BLACKTEMPLE nil
[14:52:11] 198 Magisters' Terrace MAGISTERSTERRACE [Magisters' Terrace]
[14:52:11] 199 The Sunwell SUNWELL nil
[14:53:41] 201 Magisters' Terrace MAGISTERSTERRACE [Magisters' Terrace]
[14:53:41] 202 Utgarde Keep UTGARDE [Utgarde Keep]
[14:53:41] 203 Utgarde Pinnacle UTGARDEPINNACLE [Utgarde Pinnacle]
[14:53:41] 204 Azjol-Nerub AZJOLNERUB [Azjol-Nerub]
[14:53:41] 205 Utgarde Pinnacle UTGARDEPINNACLE [Utgarde Pinnacle]
[14:53:41] 206 The Oculus THEOCULUS [The Oculus]
[14:53:41] 207 Halls of Lightning HALLSOFLIGHTNING [Halls of Lightning]
[14:53:41] 208 Halls of Stone HALLSOFSTONE [Halls of Stone]
[14:53:41] 209 The Culling of Stratholme CAVERNSOFTIME [The Culling of Stratholme]
[14:53:41] 210 The Culling of Stratholme CAVERNSOFTIME [The Culling of Stratholme]
[14:53:41] 211 The Oculus THEOCULUS [The Oculus]
[14:53:41] 212 Halls of Lightning HALLSOFLIGHTNING [Halls of Lightning]
[14:53:41] 213 Halls of Stone HALLSOFSTONE [Halls of Stone]
[14:53:41] 214 Drak'Tharon Keep DRAKTHARON [Drak'Tharon Keep]
[14:53:41] 215 Drak'Tharon Keep DRAKTHARON [Drak'Tharon Keep]
[14:53:41] 216 Gundrak GUNDRAK [Gundrak]
[14:53:41] 217 Gundrak GUNDRAK [Gundrak]
[14:53:41] 218 Ahn'kahet: The Old Kingdom AHNKALET [Ahn'kahet: The Old Kingdom]
[14:53:41] 219 Ahn'kahet: The Old Kingdom AHNKALET [Ahn'kahet: The Old Kingdom]
[14:53:41] 220 Violet Hold THEVIOLETHOLD [The Violet Hold]
[14:53:41] 221 Violet Hold THEVIOLETHOLD [The Violet Hold]
[14:53:41] 223 The Eye of Eternity MALYGOS nil
[14:53:41] 224 The Obsidian Sanctum CHAMBEROFASPECTS nil
[14:53:41] 225 The Nexus THENEXUS [The Nexus]
[14:53:41] 226 The Nexus THENEXUS [The Nexus]
[14:53:41] 227 Naxxramas NAXXRAMAS nil
[14:53:41] 237 The Eye of Eternity MALYGOS nil
[14:53:41] 238 The Obsidian Sanctum CHAMBEROFASPECTS nil
[14:53:41] 239 Vault of Archavon VAULTOFARCHAVON nil
[14:53:41] 240 Vault of Archavon VAULTOFARCHAVON nil
[14:53:41] 241 Azjol-Nerub AZJOLNERUB [Azjol-Nerub]
[14:53:41] 242 Utgarde Keep UTGARDE [Utgarde Keep]
[14:53:41] 243 Ulduar ULDUAR nil
[14:53:41] 244 Ulduar ULDUAR nil
[14:53:41] 245 Trial of the Champion ARGENTDUNGEON [Trial of the Champion]
[14:53:41] 246 Trial of the Crusader ARGENTRAID nil
[14:53:41] 247 Trial of the Grand Crusader ARGENTRAID nil
[14:53:41] 248 Trial of the Crusader ARGENTRAID nil
[14:53:41] 249 Trial of the Champion ARGENTDUNGEON [Trial of the Champion]
[14:53:41] 250 Trial of the Grand Crusader ARGENTRAID nil
[14:53:41] 251 The Forge of Souls THEFORGEOFSOULS [The Forge of Souls]
[14:53:41] 252 The Forge of Souls THEFORGEOFSOULS [The Forge of Souls]
[14:53:41] 253 Pit of Saron PITOFSARON [Pit of Saron]
[14:53:41] 254 Pit of Saron PITOFSARON [Pit of Saron]
[14:53:41] 255 Halls of Reflection HALLSOFREFLECTION [Halls of Reflection]
[14:53:41] 256 Halls of Reflection HALLSOFREFLECTION [Halls of Reflection]
[14:53:41] 257 Onyxia's Lair ONYXIAENCOUNTER nil
[14:53:41] 272 Maraudon - The Wicked Grotto MARAUDON [Maraudon]
[14:53:41] 273 Maraudon - Earth Song Falls MARAUDON [Maraudon]
[14:53:41] 274 Stratholme - Service Entrance STRATHOLME [Stratholme]
[14:53:41] 276 Blackrock Depths - Upper City BLACKROCKDEPTHS [Blackrock Depths]
[14:53:41] 279 Icecrown Citadel ICECROWNCITADEL nil
[14:53:41] 280 Icecrown Citadel ICECROWNCITADEL nil
[14:53:41] 285 The Headless Horseman HALLOWEEN [Scarlet Monastery]
[14:53:41] 286 The Frost Lord Ahune SUMMER [The Slave Pens]
[14:53:41] 287 Coren Direbrew BREW [Blackrock Depths]
[14:53:41] 288 The Crown Chemical Co. LOVE [Shadowfang Keep]
[14:53:41] 293 Ruby Sanctum RUBYSANCTUM nil
[14:53:41] 294 Ruby Sanctum RUBYSANCTUM nil
[14:53:41] 296 Grand Ambassador Flamelash CATAEVENTFLAMELASH [Blackrock Depths]
[14:53:41] 297 Crown Princess Theradras CATAEVENTTHERADRAS [Maraudon]
[14:53:41] 298 Kai'ju Gahz'rilla CATAEVENTKAIJUGAHZRILLA [Zul'Farrak]
[14:53:41] 299 Prince Sarsarun CATAEVENTSARSARUN nil
[14:55:38] 302 Throne of the Tides THRONEOFTHETIDES [Throne of the Tides]
[14:55:38] 303 Blackrock Caverns BLACKROCKCAVERNS [Blackrock Caverns]
[14:55:38] 304 Grim Batol GRIMBATOL [Grim Batol]
[14:55:38] 305 Halls of Origination HALLSOFORIGINATION [Halls of Origination]
[14:55:38] 306 Kai'ju Gahz'rilla CATAEVENTKAIJUGAHZRILLA [Zul'Farrak]
[14:55:38] 307 The Stonecore THESTONECORE [The Stonecore]
[14:55:38] 308 Grand Ambassador Flamelash CATAEVENTFLAMELASH [Blackrock Depths]
[14:55:38] 309 Crown Princess Theradras CATAEVENTTHERADRAS [Maraudon]
[14:55:38] 310 Prince Sarsarun CATAEVENTSARSARUN nil
[14:55:38] 311 The Vortex Pinnacle THEVORTEXPINNACLE [The Vortex Pinnacle]
[14:55:38] 312 Lost City of the Tol'vir LOSTCITYOFTOLVIR [Lost City of the Tol'vir]
[14:55:38] 313 Blackwing Descent BLACKWINGDESCENTRAID [Blackwing Descent]
[14:55:38] 314 Blackwing Descent BLACKWINGDESCENTRAID [Blackwing Descent]
[14:55:38] 315 The Bastion of Twilight GRIMBATOLRAID [The Bastion of Twilight]
[14:55:38] 316 The Bastion of Twilight GRIMBATOLRAID [The Bastion of Twilight]
[14:55:38] 317 Throne of the Four Winds THRONEOFTHEFOURWINDS [Throne of the Four Winds]
[14:55:38] 318 Throne of the Four Winds THRONEOFTHEFOURWINDS [Throne of the Four Winds]
[14:55:38] 319 The Vortex Pinnacle THEVORTEXPINNACLE [The Vortex Pinnacle]
[14:55:38] 320 The Stonecore THESTONECORE [The Stonecore]
[14:55:38] 321 Halls of Origination HALLSOFORIGINATION [Halls of Origination]
[14:55:38] 322 Grim Batol GRIMBATOL [Grim Batol]
[14:55:38] 323 Blackrock Caverns BLACKROCKCAVERNS [Blackrock Caverns]
[14:55:38] 324 Throne of the Tides THRONEOFTHETIDES [Throne of the Tides]
[14:55:38] 325 Lost City of the Tol'vir LOSTCITYOFTOLVIR [Lost City of the Tol'vir]
[14:55:38] 326 Deadmines DEADMINES [Deadmines]
[14:55:38] 327 Shadowfang Keep SHADOWFANGKEEP [Shadowfang Keep]
[14:55:38] 328 Baradin Hold BARADINHOLD [Baradin Hold]
[14:55:38] 329 Baradin Hold BARADINHOLD [Baradin Hold]
[14:55:38] 330 Upper Blackrock Spire BLACKROCKSPIRE [Blackrock Spire]
[14:55:38] 334 Zul'Gurub ZULGURUB [Zul'Gurub]
[14:55:38] 340 Zul'Aman ZULAMAN [Zul'Aman]
[14:55:38] 358 10v10 Rated Battleground WARSONGGULCH nil
[14:55:38] 361 Firelands FIRELANDS [Firelands]
[14:55:38] 362 Firelands FIRELANDS [Firelands]
[14:56:35] 416 The Siege of Wyrmrest Temple SIEGEOFWYRMRESTTEMPLE [Dragon Soul]
[14:56:35] 417 Fall of Deathwing FALLOFDEATHWING [Dragon Soul]
[14:56:35] 435 End Time ENDTIME [End Time]
[14:56:35] 437 Well of Eternity WELLOFETERNITY [Well of Eternity]
[14:56:35] 439 Hour of Twilight HOUROFTWILIGHT [Hour of Twilight]
[14:56:35] 447 Dragon Soul DRAGONSOUL [Dragon Soul]
[14:56:35] 448 Dragon Soul DRAGONSOUL [Dragon Soul]
[14:56:35] 464 Temple of the Jade Serpent TEMPLEOFTHEJADESERPENT [Temple of the Jade Serpent]
[14:56:35] 465 Stormstout Brewery STORMSTOUTBREWERY [Stormstout Brewery]
[14:56:35] 466 Shado-Pan Monastery SHADOWPANMONASTERY [Shado-Pan Monastery]
[14:56:35] 467 Mogu'shan Palace MOGUSHANPALACE [Mogu'shan Palace]
[14:56:35] 468 Temple of the Jade Serpent TEMPLEOFTHEJADESERPENT [Temple of the Jade Serpent]
[14:56:35] 469 Stormstout Brewery STORMSTOUTBREWERY [Stormstout Brewery]
[14:56:35] 470 Shado-Pan Monastery SHADOWPANMONASTERY [Shado-Pan Monastery]
[14:56:35] 471 Gate of the Setting Sun GATEOFTHESETTINGSUN [Gate of the Setting Sun]
[14:56:35] 472 Scholomance SCHOLOMANCE [Scholomance]
[14:56:35] 473 Scarlet Halls SCARLETHALLS [Scarlet Halls]
[14:56:35] 474 Scarlet Monastery SCARLETMONASTERY [Scarlet Monastery]
[14:56:35] 492 Greenstone Village QUEST nil
[14:56:35] 499 Unga Ingoo QUEST nil
[14:57:24] 504 Crypt of Forgotten Kings QUEST nil
[14:57:24] 511 Arena of Annihilation QUEST nil
[14:57:24] 517 A Brewing Storm QUEST nil
[14:57:24] 519 Mogu'shan Palace MOGUSHANPALACE [Mogu'shan Palace]
[14:57:24] 526 Terrace of Endless Spring ENDLESSSPRING [Terrace of Endless Spring]
[14:57:24] 527 Guardians of Mogu'shan GUARDIANSOFMOGUSHAN [Mogu'shan Vaults]
[14:57:24] 528 The Vault of Mysteries THEVAULTOFMYSTERIES [Mogu'shan Vaults]
[14:57:24] 529 The Dread Approach THEDREADAPPROACH [Heart of Fear]
[14:57:24] 530 Nightmare of Shek'zeer NIGHTMAREOFSHEKZEER [Heart of Fear]
[14:57:24] 531 Mogu'shan Vaults MOGUSHANVAULTS [Mogu'shan Vaults]
[14:57:24] 532 Mogu'shan Vaults MOGUSHANVAULTS [Mogu'shan Vaults]
[14:57:24] 533 Heart of Fear HEARTOFFEAR [Heart of Fear]
[14:57:24] 534 Heart of Fear HEARTOFFEAR [Heart of Fear]
[14:57:24] 535 Terrace of Endless Spring TERRACEOFTHEENDLESSSPRING [Terrace of Endless Spring]
[14:57:24] 536 Terrace of Endless Spring TERRACEOFTHEENDLESSSPRING [Terrace of Endless Spring]
[14:57:24] 537 Assault on Zan'vess QUEST nil
[14:57:24] 539 Brewmoon Festival QUEST nil
[14:57:24] 540 Temple of Kotmogu QUEST nil
[14:57:24] 541 Test Scenario PS QUEST nil
[14:57:24] 542 Theramore's Fall QUEST nil
[14:57:24] 543 Theramore's Fall QUEST nil
[14:57:24] 554 Siege of Niuzao Temple SIEGEOFNIZAOTEMPLE [Siege of Niuzao Temple]
[14:57:24] 566 Theramore's Fall QUEST nil
[14:57:24] 567 Theramore's Fall QUEST nil
[14:57:24] 586 Dagger in the Dark QUEST nil
[14:57:24] 588 Battle on the High Seas QUEST nil
[14:57:24] 589 A Little Patience QUEST nil
[14:57:24] 590 Lion's Landing QUEST nil
[14:57:24] 593 Assault on Zan'vess QUEST nil
[14:57:24] 594 Pursuing the Black Harvest BLACKTEMPLE nil
[14:57:24] 595 Domination Point QUEST nil
[14:58:20] 602 Tear Down This Wall! QUEST nil
[14:58:20] 603 Stormsea Landing QUEST nil
[14:58:20] 604 Assault on Zeb'tula QUEST nil
[14:58:20] 606 To the Skies!  nil
[14:58:20] 607 The Fall of Shan Bu QUEST nil
[14:58:20] 608 Tear Down This Wall! QUEST nil
[14:58:20] 610 Last Stand of the Zandalari THUNDERLASTSTAND [Throne of Thunder]
[14:58:20] 611 Forgotten Depths THUNDERFORGOTTEN [Throne of Thunder]
[14:58:20] 612 Halls of Flesh-Shaping THUNDERHALLS [Throne of Thunder]
[14:58:20] 613 Pinnacle of Storms THUNDERPINNACLE [Throne of Thunder]
[14:58:20] 615 The Thunder Forge QUEST nil
[14:58:20] 616 Dagger in the Dark QUEST nil
[14:58:20] 617 Assault on Shaol'mara QUEST nil
[14:58:20] 618 To the Skies!  nil
[14:58:20] 619 A Little Patience QUEST nil
[14:58:20] 620 Troves of the Thunder King QUEST nil
[14:58:20] 621 The Fall of Shan Bu QUEST nil
[14:58:20] 624 Dark Heart of Pandaria QUEST nil
[14:58:20] 625 The Secrets of Ragefire QUEST nil
[14:58:20] 630 Siege of Niuzao Temple SIEGEOFNIZAOTEMPLE [Siege of Niuzao Temple]
[14:58:20] 631 Gate of the Setting Sun GATEOFTHESETTINGSUN [Gate of the Setting Sun]
[14:58:20] 633 Throne of Thunder THUNDERPINNACLE [Throne of Thunder]
[14:58:20] 634 Throne of Thunder THUNDERPINNACLE [Throne of Thunder]
[14:58:20] 637 Blood in the Snow QUEST nil
[14:58:20] 639 A Brewing Storm QUEST nil
[14:58:20] 645 Greenstone Village QUEST nil
[14:58:20] 646 Blood in the Snow QUEST nil
[14:58:20] 647 Dark Heart of Pandaria QUEST nil
[14:58:20] 648 Crypt of Forgotten Kings QUEST nil
[14:58:20] 649 The Secrets of Ragefire QUEST nil
[14:58:20] 652 Battle on the High Seas QUEST nil
[14:58:20] 654 Battle on the High Seas QUEST nil
[14:58:20] 655 Battle on the High Seas QUEST nil
[17:32:58] 658 Proving Grounds QUEST nil
[17:32:58] 697 Prototype Scenario QUEST nil
[17:32:58] 699 Crafty Test QUEST nil
[17:32:58] 701 Celestial Tournament QUEST nil
[17:32:58] 714 Siege of Orgrimmar ORGRIMMARGATES [Siege of Orgrimmar]
[17:32:58] 715 Siege of Orgrimmar ORGRIMMARGATES [Siege of Orgrimmar]
[17:32:58] 716 Vale of Eternal Sorrows ORGRIMMARVALE [Siege of Orgrimmar]
[17:32:58] 717 Gates of Retribution ORGRIMMARGATES [Siege of Orgrimmar]
[17:32:58] 724 The Underhold ORGRIMMARUNDERHOLD [Siege of Orgrimmar]
[17:32:58] 725 Downfall ORGRIMMARDOWNFALL [Siege of Orgrimmar]
[17:32:58] 726 Vale of Eternal Sorrows ORGRIMMARVALE [Siege of Orgrimmar]
[17:32:58] 728 Gates of Retribution ORGRIMMARGATES [Siege of Orgrimmar]
[17:32:58] 729 The Underhold ORGRIMMARUNDERHOLD [Siege of Orgrimmar]
[17:32:58] 730 Downfall ORGRIMMARDOWNFALL [Siege of Orgrimmar]
[17:32:58] 745 Finding the Secret Ingredient QUEST nil
[17:32:58] 749 Noodle Time QUEST nil
]]


local LFR_DUNGEONIDS = {
				MVa = 527,
				MVb = 528,
				HoFa = 529,
				HoFb = 530,
				ToES = 526,
				ToTa = 610,
				ToTb = 611,
				ToTc = 612,
				ToTd = 613,
				SoOa = 716,
				SoOb = 717,
				SoOc = 724,
				SoOd = 725,
				SoOaF = 726, -- must ignore this in GetLFRTotals
				SoObF = 728, -- must ignore this in GetLFRTotals
				SoOcF = 729, -- must ignore this in GetLFRTotals
				SoOdF = 730, -- must ignore this in GetLFRTotals
				H = 462,  	-- must ignore this in GetLFRTotals
				S = 493,	-- must ignore this in GetLFRTotals
				HS = 641	-- must ignore this in GetLFRTotals
			}; 

local RAID_DUNGEONIDS = {
				MV = 531,
				HoF = 533,
				ToES = 535,
				ToT = 633,
				SoO = 714,
			};

local RAID_NAMES = nil;				
				
local LFR_STARTER_DUNGEON = 527;
				
local LFR_CELL_A_DUNGEONS = {
				MVa = 527,
				MVb = 528
			};

local LFR_CELL_B_DUNGEONS = {
				HoFa = 529,
				HoFb = 530
			};

local LFR_CELL_C_DUNGEONS = {
				ToES = 526
			};
				
local LFR_CELL_D_DUNGEONS = {
				ToTa = 610,
				ToTb = 611,
				ToTc = 612,
				ToTd = 613
			};
			
local LFR_CELL_E_DUNGEONS = {
				SoOa = 716,
				SoOb = 717,
				SoOc = 724,
				SoOd = 725,
			};
			
local LFR_CELL_F_DUNGEONS = {
				SoOa = 726,
				SoOb = 728,
				SoOc = 729,
				SoOd = 730,
			};
			
local WORLD_BOSSES = {
				aSha = {ID = 32099, func = function() return GG:GetBossSha() end, avail = function(q) return true end,},
				bGalleon = {ID = 32098, func = function() return GG:GetBossGalleon() end, avail = function(q) return true end,}, 
				cNalak = {ID = 32518, func = function() return GG:GetBossNalak() end, avail = function(q) return true end,}, 
				dOondasta = {ID = 32519, func = function() return GG:GetBossOondasta() end, avail = function(q) return true end,}, 
				eCelestial = {ID = 33117, func = function() return GG:GetBossCelestial() end, avail = function(q) return true end,}, 
				fOrdos = {ID = 33118, func = function() return GG:GetBossOrdos() end, avail = function(q) if q == nil then return false else return q end end,}, 
				--xxxPossibles =  32919, 32922, 32923, 32924, 33118, 33225, 33226
			};
	
local QUESTS = {
				aWarSeal = 33133,  -- Warforged Seals
				hWarSeal = 33134,  -- Warforged Seals
				tKey = 32626, -- Loot Room Key Tracking Quest
				aCTK = 32640, -- Champions of the Thunder King (Alliance)
				hCTK = 32641, -- Champions of the Thunder King (Horde)
				tPB = 32863, -- What We've Been Training For (Pet Battles Account Weekly)
				tEH = 33338, -- Empowering the Hourglass
				tPM = 33374, -- Path of the Mistwalker
				hC1 = 31528, -- A Worthy Challenge: Darkmaster Gandling (Horde)
				hC2 = 31526, -- A Worthy Challenge: Durand (Horde)
				hC3 = 31527, -- A Worthy Challenge: Flameweaver Koegler (Horde)
				hC4 = 31524, -- A Worthy Challenge: Raigonn (Horde)
				hC5 = 31520, -- A Worthy Challenge: Sha of Doubt (Horde)
				hC6 = 31522, -- A Worthy Challenge: Sha of Hatred (Horde)
				hC7 = 31525, -- A Worthy Challenge: Wing Leader Ner'onok (Horde)
				hC8 = 31519, -- A Worthy Challenge: Yan-zhu the Uncasked (Horde)
				hC9 = 31523, -- A Worthy Challenge: Xin the Weaponmaster (Horde)
				aC1 = 32007, -- A Worthy Challenge: Darkmaster Gandling (Alliance)
				aC2 = 32005, -- A Worthy Challenge: Durand (Alliance)
				aC3 = 32006, -- A Worthy Challenge: Flameweaver Koegler (Alliance
				aC4 = 32003, -- A Worthy Challenge: Raigonn (Alliance)
				aC5 = 31998, -- A Worthy Challenge: Sha of Doubt (Alliance)
				aC6 = 32001, -- A Worthy Challenge: Sha of Hatred (Alliance)
				aC7 = 32004, -- A Worthy Challenge: Wing Leader Ner'onok (Alliance)
				aC8 = 32002, -- A Worthy Challenge: Xin the Weaponmaster (Alliance)
				aC9 = 32000, -- A Worthy Challenge: Yan-zhu the Uncasked (Alliance)
				tTom = 32962, -- "Tom" Bone Apart - Tracking Quest (Daily)
				farm4 = 30256, -- Learn and Grow IV: Harvesting
				farm8 = 30516, -- Growing the Farm I: A Little Problem
				farm12 = 30524, -- Growing the Farm II: Knock on Wood
				farm16 = 30529, -- Growing the Farm III: The Mossy Boulder
				tLCape = 33104, -- Legendary quest "A Pandaren Legend"
			};

local L = LibStub("AceLocale-3.0"):GetLocale(ADDON_NAME, false)
			
local TRADE_SKILLS_ORDER = {
				a = "Transmute: Living Steel",
				b = "Lightning Steel Ingot",
				c = "Balanced Trillium Ingot",
				d = "Imperial Silk",
				e = "Celestial Cloth",
				f = "Sha Crystal",  
				g = "Scroll of Wisdom",
				h = "Wild Jade",
				i = "Serpent's Heart",
				j = "Magnificence of Leather",
				k = "Hardened Magnificent Hide",
				l = "Jard's Peculiar Energy Source",
			};
			
local TRADE_SKILLS = {
				["Transmute: Living Steel"] = { func = function() return GG:GetProfAlc() end, Text = L.core.ProfAlcText, },
				["Lightning Steel Ingot"] = { func = function() return GG:GetProfBS() end, Text = L.core.ProfBSText, },
				["Balanced Trillium Ingot"] = { func = function() return GG:GetProfBS2() end, Text = L.core.ProfBS2Text, },
				["Imperial Silk"] = { func = function() return GG:GetProfTailor() end, Text = L.core.ProfTailorText, },
				["Celestial Cloth"] = { func = function() return GG:GetProfTailor2() end, Text = L.core.ProfTailor2Text, },
				["Sha Crystal"] = { func = function() return GG:GetProfEnch() end, Text = L.core.ProfEnchText, },
				["Scroll of Wisdom"] = { func = function() return GG:GetProfScribe() end, Text = L.core.ProfScribeText, },
				["Wild Jade"] = { func = function() return GG:GetProfJCGem() end, Text = L.core.ProfJCGemText, },  -- just needed to pick one of them
				["Serpent's Heart"] = { func = function() return GG:GetProfJCHeart() end, Text = L.core.ProfJCHeartText, },
				["Magnificence of Leather"] = { func = function() return GG:GetProfLW() end, Text = L.core.ProfLWText, },
				["Hardened Magnificent Hide"] = { func = function() return GG:GetProfLW2() end, Text = L.core.ProfLW2Text, },
				["Jard's Peculiar Energy Source"] = { func = function() return GG:GetProfEng() end, Text = L.core.ProfEngText, },
			};
				
local FARM_SPELL_ACTION = {
				[111102] = "Sow", -- Plant Green Cabbage
				[123361] = "Sow", -- Plant Juicycrunch Carrot
				[123388] = "Sow", -- Plant Scallions
				[123485] = "Sow", -- Plant Mogu Pumpkin
				[123535] = "Sow", -- Plant Red Blossom Leek
				[123565] = "Sow", -- Plant Pink Turnip
				[123568] = "Sow", -- Plant White Turnip
				[123771] = "Sow", -- Plant Golden Seed
				[123772] = "Sow", -- Plant Seed of Harmony
				[123773] = "Sow", -- Plant Snakeroot Seed
				[123774] = "Sow", -- Plant Enigma Seed
				[123775] = "Sow", -- Plant Magebulb Seed
				[123776] = "Sow", -- Plant Soybean Seed
				[123777] = "Sow", -- Plant Ominous Seed
				[123892] = "Sow", -- Plant Autumn Blossom Sapling
				[123893] = "Sow", -- Plant Spring Blossom Seed
				[123894] = "Sow", -- Plant Winter Blossom Sapling
				[123895] = "Sow", -- Plant Kyparite Seed
				[129623] = "Sow", -- Plant Windshear Cactus Seed
				[129628] = "Sow", -- Plant Raptorleaf Seed
				[129863] = "Sow", -- Plant Songbell Seed
				[129974] = "Sow", -- Plant Witchberries
				[129976] = "Sow", -- Plant Jade Squash
				[129978] = "Sow", -- Plant Striped Melon
				[130170] = "Sow", -- Plant Spring Blossom Sapling
				[133036] = "Sow", -- Plant Unstable Portal Shard
				[116356] = "Sow4", -- Throw Green Cabbage Seeds
				[123362] = "Sow4", -- Throw Juicycrunch Carrot Seeds
				[123389] = "Sow4", -- Throw Scallion Seeds
				[123486] = "Sow4", -- Throw Mogu Pumpkin Seeds
				[123537] = "Sow4", -- Throw Red Blossom Leek Seeds
				[123566] = "Sow4", -- Throw Pink Turnip Seeds
				[123567] = "Sow4", -- Throw White Turnip Seeds
				[131093] = "Sow4", -- Throw Witchberry Seeds
				[131094] = "Sow4", -- Throw Jade Squash Seeds
				[131095] = "Sow4", -- Throw Striped Melon Seeds
				[139975] = "Sow4", -- Throw Songbell Seeds
				[139977] = "Sow4", -- Throw Snakeroot Seeds
				[139978] = "Sow4", -- Throw Enigma Seeds
				[139981] = "Sow4", -- Throw Magebulb Seeds
				[139983] = "Sow4", -- Throw Windshear Cactus Seeds
				[139986] = "Sow4", -- Throw Raptorleaf Seeds				
				[111123] = "Harvest", -- Harvest Green Cabbage
				[115063] = "Harvest", -- Harvest EZ-Gro Green Cabbage
				[123353] = "Harvest", -- Harvest Juicycrunch Carrot
				[123355] = "Harvest", -- Harvest Plump Green Cabbage
				[123356] = "Harvest", -- Harvest Plump Juicycrunch Carrot
				[123375] = "Harvest", -- Harvest Scallions
				[123380] = "Harvest", -- Harvest Plump Scallions
				[123445] = "Harvest", -- Harvest Mogu Pumpkin
				[123451] = "Harvest", -- Harvest Plump Mogu Pumpkin
				[123516] = "Harvest", -- Harvest Winter Blossom Tree
				[123522] = "Harvest", -- Harvest Plump Red Blossom Leek
				[123524] = "Harvest", -- Harvest Red Blossom Leek
				[123548] = "Harvest", -- Harvest Pink Turnip
				[123549] = "Harvest", -- Harvest Plump Pink Turnip
				[123570] = "Harvest", -- Harvest White Turnip
				[123571] = "Harvest", -- Harvest Plump White Turnip
				[129673] = "Harvest", -- Harvest Golden Lotus
				[129674] = "Harvest", -- Harvest Fool\'s Cap
				[129675] = "Harvest", -- Harvest Snow Lily
				[129676] = "Harvest", -- Harvest Silkweed
				[129687] = "Harvest", -- Harvest Green Tea Leaf
				[129705] = "Harvest", -- Harvest Rain Poppy
				[129757] = "Harvest", -- Harvest Snakeroot
				[129796] = "Harvest", -- Harvest Magebulb
				[129814] = "Harvest", -- Harvest Windshear Cactus
				[129843] = "Harvest", -- Harvest Raptorleaf
				[129887] = "Harvest", -- Harvest Songbell
				[129983] = "Harvest", -- Harvest Witchberries
				[129984] = "Harvest", -- Harvest Plump Witchberries
				[130025] = "Harvest", -- Harvest Jade Squash
				[130026] = "Harvest", -- Harvest Plump Jade Squash
				[130042] = "Harvest", -- Harvest Striped Melon
				[130043] = "Harvest", -- Harvest Plump Striped Melon
				[130109] = "Harvest", -- Harvest Terrible Turnip
				[130140] = "Harvest", -- Harvest Autumn Blossom Tree
				[130168] = "Harvest", -- Harvest Spring Blossom Tree
				[133106] = "Harvest", -- Harvest Portal Shard
			}

local CLASS_COLOR = {
	DEATHKNIGHT = "|cFFC41F3B",
	DRUID = "|cFFFF7D0A",
	HUNTER = "|cFFABD473",
	MAGE = "|cFF69CCF0",
	MONK = "|cFF00FF96",
	PALADIN = "|cFFF58CBA",
	PRIEST = "|cFFFFFFFF",
	ROGUE = "|cFFFFF569",
	SHAMAN = "|cFF0070DE",
	WARLOCK = "|cFF9482C9",
	WARRIOR = "|cFFC79C6E"
}

-- Start Titan VP Cap Progress
GG = LibStub("AceAddon-3.0"):NewAddon(ADDON_NAME, "AceEvent-3.0", "AceConsole-3.0", "AceTimer-3.0")
GG.version = GetAddOnMetadata(ADDON_NAME, "Version")
GG.category = GetAddOnMetadata(ADDON_NAME, "X-Category")
GG.versionMajor = 1;    -- Used for DB versioning

-- Load Libs
GG.LSM = LibStub:GetLibrary("LibSharedMedia-3.0")
GG.aceConfig = LibStub:GetLibrary("AceConfig-3.0")
GG.aceConfigDialog = LibStub:GetLibrary("AceConfigDialog-3.0")
GG.QTip = LibStub("LibQTip-1.0")
GG.LDB = LibStub("LibDataBroker-1.1")
GG.LDBIcon = LibStub("LibDBIcon-1.0")
GG.CBH = LibStub("CallbackHandler-1.0"):New(GG)

GG.currentPlayer = UnitName('player')	-- name of the logged-in character.
GG.currentRealm = GetRealmName()		-- current Realm we're on.
_, GG.currentClass = UnitClass("player") -- class of the current character.
GG.menu = false       -- Menu frame
GG.menuItems = {       -- Table for the dropdown menu
    top = {},
    middle = {},
    bottom = {},
}
GG.periodMaxVP = -1
GG.periodMaxCP = -1
GG.maxJP = -1
GG.maxCP = -1
GG.maxHP = -1
GG.maxVP = -1
GG.timezone = time({year=1970, month=1, day=2, hour=0})-86400

GG.LDBObj = {
    type = "data source",
		icon = "Interface\\Icons\\pvecurrency-valor",
		iconCoords = { 0.075, 0.925, 0.075, 0.925 },
    label = L.core.buttonLabel,
    text = 'n/a',
    category = GG.category,
    version = GG.version,
		OnEnter = function(frame)
  		-- if disabled during combat then don't show anything
      if InCombatLockdown() ~= nil and InCombatLockdown() == 1 and not GG:GetShowCombat() then return end
      GG:SetTooltipText(frame)
		end,
		OnLeave = function(frame) 
		end,
		OnClick = function(frame, button)
			if button == "RightButton" then
				GG:ShowOptions()
			end

      if button == "LeftButton" then
        if not GG:GetLDBDisplayLock() then GG:RotateButtonText() end
      end
		end
	}
	
-- OnLoad
function GG:OnInitialize()

    -- Make sure everything is ok with the db
    if not GG_Storage or type(GG_Storage) ~= 'table' then GG_Storage = {} end
    
    -- Tell the player we are being loaded
	self:Print(format(L.core.load, self.version))
        
    -- Load settings
    self.db = LibStub("AceDB-3.0"):New("GG_Settings", GG_Defaults, true)
	self:UpdateSettings()

	-- Set back to a launcher if text is off
	if not self:GetLDB() then
		self.LDBObj.type = 'launcher'
		self.LDBObj.text = ''
	end
        -- Start LDB
	self.LDBObj = self.LDB:NewDataObject(ADDON_NAME, self.LDBObj)

	-- Start the minimap icon
	self.LDBIcon:Register(ADDON_NAME, self.LDBObj, self.db.global.minimap)
    
    -- Register Options
	--GG_Options.args.purge.desc = format(L.core.options.purgeDesc, self:GetPurge() / 24)
	self.aceConfig:RegisterOptionsTable(L.core.name, GG_Options, {"GG", "GearGrinder"})
	--self.aceConfigDialog:AddToBlizOptions(L.core.name)
	
	self.optionsFrames = {}
	self.optionsFrames.GG = self.aceConfigDialog:AddToBlizOptions(L.core.name, L.core.name,nil, "general")
	self.optionsFrames.ttToon	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "Character Details", L.core.name, "ttToons")
	self.optionsFrames.ttCharms	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "Bonus Roll Tokens", L.core.name, "ttCharms")
	self.optionsFrames.ttBoss	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "World Bosses", L.core.name, "ttBoss")
	self.optionsFrames.ttRaids	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "Raids", L.core.name, "ttRaids")
	self.optionsFrames.ttActivities	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "Activities", L.core.name, "ttActivities")
	self.optionsFrames.ttProfs	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "Professions", L.core.name, "ttProfs")
	self.optionsFrames.ldbOpt	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "LDB", L.core.name, "ldbOpt")
	self.optionsFrames.Background	= self.aceConfigDialog:AddToBlizOptions(L.core.name, "Background", L.core.name, "Background")
	
	
    -- Events
	self:RegisterEvent("MERCHANT_CLOSED", function() GG:SaveData("MERCHANT_CLOSED"); GG:UpdateLDB(true) end)
	self:RegisterEvent("PLAYER_ENTERING_WORLD", function() GG:SaveData("PLAYER_ENTERING_WORLD"); GG:UpdateLDB(true) end)
	self:RegisterEvent("UPDATE_INSTANCE_INFO", function() GG:SaveDungeonData("UPDATE_INSTANCE_INFO"); GG:UpdateLDB(true) end)
	self:RegisterEvent("PLAYER_LEAVING_WORLD", function() GG:SaveData("PLAYER_LEAVING_WORLD"); GG:UpdateLDB(true) end)
	self:RegisterEvent("LFG_COMPLETION_REWARD", function() GG:SaveDungeonData("LFG_COMPLETION_REWARD"); GG:SaveCurrencyData("LFG_COMPLETION_REWARD"); GG:UpdateLDB(true) end)
	self:RegisterEvent("PLAYER_REGEN_ENABLED", function() GG:SaveData("PLAYER_REGEN_ENABLED"); GG.InCombat = false; GG:UpdateLDB(true) end)
	self:RegisterEvent("PLAYER_REGEN_DISABLED", function() GG.InCombat = true end)
    self:RegisterEvent("CURRENCY_DISPLAY_UPDATE", function() GG:SaveCurrencyData("CURRENCY_DISPLAY_UPDATE"); GG:UpdateLDB(true) end)
    self:RegisterEvent("LOOT_CLOSED", function() GG:SaveData("LOOT_CLOSED"); GG:UpdateLDB(true) end)
	self:RegisterEvent("BAG_UPDATE", function() GG:SaveData("BAG_UPDATE"); GG:UpdateLDB(true) end)
	self:RegisterEvent("QUEST_FINISHED", function() GG:SaveQuestData("QUEST_FINISHED"); GG:SaveCurrencyData("QUEST_FINISHED"); GG:UpdateLDB(true) end)
	self:RegisterEvent("TRADE_SKILL_SHOW", function() GG:SaveTradeData("TRADE_SKILL_SHOW"); GG:UpdateLDB(true) end)
	self:RegisterEvent("TRADE_SKILL_UPDATE", function() GG:SaveTradeData("TRADE_SKILL_UPDATE"); GG:UpdateLDB(true) end)
	self:RegisterEvent("COMBAT_LOG_EVENT", function(self, eventTime, ...) GG:CheckCombat(self, eventTime, ...) end)
	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
	
	--self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", function(self, eventTime, ...) GG:CheckCombat(self, eventTime, ...) end)
	
    -- Add to Paperdoll
    table.insert(PAPERDOLL_STATCATEGORIES["GENERAL"].stats, L.core.PDVPText);
	table.insert(PAPERDOLL_STATCATEGORIES["GENERAL"].stats, L.core.PDVPCapText);
	table.insert(PAPERDOLL_STATCATEGORIES["GENERAL"].stats, L.core.PDJPText);
	
	if self:GetVPPaperdoll() then
		PAPERDOLL_STATINFO[L.core.PDVPText] = { updateFunc = function(...) GG:UpdateVPPaperDollFrame(...); end };
	else
		PAPERDOLL_STATINFO[L.core.PDVPText] = nil;
	end

	if self:GetVPCapPaperdoll() then
		PAPERDOLL_STATINFO[L.core.PDVPCapText] = { updateFunc = function(...) GG:UpdateVPCapPaperDollFrame(...); end };
	else
		PAPERDOLL_STATINFO[L.core.PDVPCapText] = nil;
	end

	if self:GetJPPaperdoll() then
		PAPERDOLL_STATINFO[L.core.PDJPText] = { updateFunc = function(...) GG:UpdateJPPaperDollFrame(...); end };
	else
		PAPERDOLL_STATINFO[L.core.PDJPText] = nil;
	end
	
    -- Build the menu
    --self:MenuInitialize();
    
    -- Get working on a score for the player
    --self:UpdateLDB(); -- This may cause excesive loading time...
    --GGHelpFrame:Hide()
end

local bgFrame = {insets = {}}
function GG:UpdateBackdrop(tt)
	bgFrame.bgFile = self.LSM:Fetch("background", self.db.global.Background.Texture)
	bgFrame.edgeFile = self.LSM:Fetch("border", self.db.global.Background.BorderTexture)
	bgFrame.tile = self.db.global.Background.Tile
	bgFrame.tileSize = self.db.global.Background.TileSize
	bgFrame.edgeSize = self.db.global.Background.EdgeSize
	local inset = floor(self.db.global.Background.EdgeSize / 4)
	bgFrame.insets.left = inset
	bgFrame.insets.right = inset
	bgFrame.insets.top = inset
	bgFrame.insets.bottom = inset
	tt:SetBackdrop(bgFrame)

	local c = self.db.global.Background.Color
	tt:SetBackdropColor(c.r, c.g, c.b, c.a)

	c = self.db.global.Background.BorderColor
	tt:SetBackdropBorderColor(c.r, c.g, c.b, c.a)
	--tt:SetBackdropBorderColor(100, 100, 100, 100)
end

function GG:SetTooltipText(f)
    -- Tooltip title
	local val = format(L.core.menuText, format(L.core.versionText, self.version));
	local num_columns, line = self:GetTooltipColumns(), 0;
	
	if num_columns == 1 then num_columns = 2 end -- number of columns must be >= 2
	
	if self.LDBtip then self.QTip:Release(self.LDBtip) end
	self.LDBtip = self.QTip:Acquire(ADDON_NAME .. "TT", num_columns)
	tt = self.LDBtip
	tt.anchorframe = f
	tt:EnableMouse()
	tt:SetScale(self:GetTTScale())
	tt:SetAutoHideDelay(0.1, f)
	tt:SmartAnchorTo(f)
	--tt:SetAutoHideDelay(0.1, f)	
	tt:Clear()
	
	GG:UpdateBackdrop(tt)
	
	line = tt:AddHeader(".")
	tt:SetCell(line, 1, val, "CENTER", num_columns)
	--tt:SetText(val, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);

	-- calculate the time remaining.
	local sec = time()
	local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})

	local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
	if dtPrev > sec then
	  dtPrev = dtPrev - (7 * 24 * 60 * 60)
	end
	local dtNext = dtPrev + 7 * 24 * 60 * 60
 	local timeRemaining = dtNext - sec

	line = tt:AddSeparator()
	
	line = tt:AddLine("" .. L.core.cooldownInfoText, ".")
	val = WHITE_BRIGHT_COLOR .. self:GetRemainingTimeText(timeRemaining) .. END_COLOR
	tt:SetCell(line, 2, val, "LEFT", num_columns-1)
	
	if self:GetDebug() then
		line = tt:AddLine("Now: " .. WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", time()) .. "   " .. time() .. END_COLOR)
		--tt:AddLine("  Last Reset: " .. WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", dtPrev) .. "   " .. dtPrev .. END_COLOR);
		--tt:AddLine("  Date: " .. WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", dtDate) .. "   " .. dtDate .. END_COLOR);
		--tt:AddLine("  Time: " .. WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", sec) .. "   " .. sec .. END_COLOR);
		--tt:AddLine("  Resets: " .. WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", dtNext) .. "   " .. dtNext .. END_COLOR);
	end
	line = tt:AddLine("" .. L.core.cooldownInfoLastText, ".")
	val = WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", dtPrev) .. END_COLOR
	tt:SetCell(line, 2, val, "LEFT", num_columns-1)
	
	line = tt:AddLine("" .. L.core.cooldownInfoNextText, ".");
	val = WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", dtNext) .. END_COLOR
	tt:SetCell(line, 2, val, "LEFT", num_columns-1)
	
	--tt:AddLine("  Date: " .. WHITE_BRIGHT_COLOR  .. date("%d-%b-%Y %I:%M %p", dtDate) .. "   " .. dtDate .. END_COLOR);
	line = tt:AddLine(" ")
	--tt:AddSeparator();
	
	if self:GetWorldBoss() then
		self:LoadAltBoss(tt)
		tt:AddLine(" ")
	end
	
	if self:GetLFR() then
		self:LoadAltLFR(tt)
		tt:AddLine(" ")
	end
	
	self:LoadAlt(tt)

	-- add the info lines at the end
	-- add the "Toggle the display of <toon>" line at the end
	
	if self:GetFiltering() then
		line = tt:AddLine(" ")
		line = tt:AddLine(".", ".")
		tt:SetCell(line, 1, INFO_COLOR .. "Click to toggle the display of " .. CLASS_COLOR[self.currentClass] .. self.currentPlayer .. END_COLOR, "CENTER", num_columns)
		tt:SetCellScript(line, 1, "OnMouseUp", function(frame) GG:ToggleToonFilter(); GG.LDBtip:Hide() end)
	end
	
	--[[if self:GetInstruction() then
		--line = tt:AddLine(" ")
		line = tt:AddLine(".", ".")
		tt:SetCell(line, 1, INFO_COLOR .. "Click for instructions" .. END_COLOR, "CENTER", num_columns)
		tt:SetCellScript(line, 1, "OnMouseUp", function(frame) GG.LDBtip:Hide(); GG:ShowInstruction() end)
	end
	]]

	tt:Show()	

end

function GG:GetTooltipColumns()
	local nBoss, nRaid, nToon = 0, 0, 0 -- Columns for each section
	
	-- Boss Count
	if self:GetWorldBoss() then
		if self:GetBossSha() then nBoss = nBoss + 1 end
		if self:GetBossGalleon() then nBoss = nBoss + 1 end
		if self:GetBossNalak() then nBoss = nBoss + 1 end
		if self:GetBossOondasta() then nBoss = nBoss + 1 end
		if self:GetBossCelestial() then nBoss = nBoss + 1 end
		if self:GetBossOrdos() then nBoss = nBoss + 1 end
	end
	
	-- Raid Count
	if self:GetLFR() then
		if self:GetRaidMV() then nRaid = nRaid + 1 end
		if self:GetRaidHoF() then nRaid = nRaid + 1 end
		if self:GetRaidToES() then nRaid = nRaid + 1 end
		if self:GetRaidToT() then nRaid = nRaid + 1 end
		if self:GetRaidSoO() then nRaid = nRaid + 1 end
		if self:GetRaidSoO() and self:GetLFRFlex() then nRaid = nRaid + 1 end
	end
	
	-- Toon Count
	if self:GetTooniELevel() then nToon = nToon + 1 end
	if self:GetTooniLevel() then nToon = nToon + 1 end
	if self:GetToonVPCap() then nToon = nToon + 1 end
	if self:GetToonVP() then nToon = nToon + 1 end
	if self:GetToonJP() then nToon = nToon + 1 end
	if self:GetToonHP() then nToon = nToon + 1 end
	if self:GetToonCP() then nToon = nToon + 1 end
	if self:GetToonCPCap() then nToon = nToon + 1 end
	if self:GetToonTimeless() then nToon = nToon + 1 end
	if self:GetToonActivity() then nToon = nToon + 1 end
	if self:GetToonCharms() then nToon = nToon + 1 end
	if self:GetToonFarm() then nToon = nToon + 1 end
	if self:GetToonProfCD() then nToon = nToon + 1 end

	-- Get the max of the values
	x = (nBoss + nRaid + abs(nBoss - nRaid)) / 2
	return ((x + nToon + abs(x - nToon)) / 2) + 1
	
end

function GG:LoadAltBoss(tt)
	local sortorder;
	local col = 2
	
	line = tt:AddHeader(L.core.BossTitle);	
	if self:GetBossSha() then
		tt:SetCell(line, col, L.core.BossShaOfAngerShort, "CENTER")
		col = col + 1
	end
	if self:GetBossGalleon() then
		tt:SetCell(line, col, L.core.BossGalleonShort, "CENTER")
		col = col + 1
	end
	if self:GetBossNalak() then
		tt:SetCell(line, col, L.core.BossNalakShort, "CENTER")
		col = col + 1
	end
	if self:GetBossOondasta() then
		tt:SetCell(line, col, L.core.BossOondastaShort, "CENTER")
		col = col + 1
	end
	if self:GetBossCelestial() then
		tt:SetCell(line, col, L.core.BossCelestialShort, "CENTER")
		col = col + 1
	end
	if self:GetBossOrdos() then
		tt:SetCell(line, col, L.core.BossOrdosShort, "CENTER")
		col = col + 1
	end
	
	sortorder = self:GetSortOrder();
	
	if sortorder == 1 then  -- Unsorted
	
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do
			self:ShowAltBoss(toonname, alt, tt)
		end
	
	elseif sortorder == 2 then  -- Alphabetical
		for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
			self:ShowAltBoss(toonname, alt, tt)
		end
	
	elseif sortorder == 3 then  -- Class
		for class in orderedPairs(CLASS_COLOR) do
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.class == class then
					self:ShowAltBoss(toonname, alt, tt)
				end
			end
		end
	
	elseif sortorder == 4 then  -- Valor Points
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyVP) then
				table.insert(tmp, alt.qtyVP)
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(G_Storage[self.currentRealm]) do
				if alt.qtyVP == v then
					self:ShowAltBoss(toonname, alt, tt);
				end
			end
		end
		
	elseif sortorder == 5 then  -- iLevel
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.iLvl) then
				table.insert(tmp, alt.iLvl);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.iLvl == v then
					self:ShowAltBoss(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 6 then  -- Justice Points
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyJP) then
				table.insert(tmp, alt.qtyJP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyJP == v then
					self:ShowAltBoss(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 7 then  -- Charms
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyLCharm) then
				table.insert(tmp, alt.qtyLCharm);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyLCharm == v then
					self:ShowAltBoss(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 8 then  -- VP Cap Progress
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.periodEarnVP) then
				table.insert(tmp, alt.periodEarnVP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.periodEarnVP == v then
					self:ShowAltBoss(toonname, alt, tt);
				end
			end
		end

	end
	
end

function GG:ShowAltBoss(toon, alt, tt)
	local toonColor, toonText = "", ""
	local line, cell = 0, 0
	local sec = time()
	local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})
	local boss = {}
	local showtoon
	local valQLCape = false
	local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
	
	if dtPrev > sec then
	  dtPrev = dtPrev - (7 * 24 * 60 * 60)
	end
	
	if alt.active == nil then alt.active = true end
	if self:GetFiltering() and alt.active == false then return end  -- exit function if the toon is not active
	
	if alt.qtyJP == nil then alt.qtyJP = 0 end
	if alt.qtyVP == nil then alt.qtyVP = 0 end
	
	-- by default the toon will not show
	showtoon = false

	-- setup the boss values
	if dtPrev < alt.savingTime then
		for i, v in pairs(WORLD_BOSSES) do
			boss[v.ID] = alt.boss[v.ID]
			-- if a boss has been killed then show the line
			if boss[v.ID] and v.func() == true then showtoon = true end
		end
	end

	-- determine if the legendary quest for the cape has been completed.
	valQLCape = alt.quest[QUESTS["tLCape"]]
	
	-- if the toon can't do the first raid then ignore
	if not showtoon 
	   and alt.dungeon  
	   and alt.dungeon[LFR_STARTER_DUNGEON] 
	   and alt.dungeon[LFR_STARTER_DUNGEON].isAvailable 
	   and alt.dungeon[LFR_STARTER_DUNGEON].isAvailable == 1 then showtoon = true end
	
	-- if there is a value for any of the currencies then show the line
	if showtoon or self:GetDebug() then	
		
		-- determine the class color
		toonColor = CLASS_COLOR[alt.class]
		toonText = toonColor .. " " .. toon .. END_COLOR;
		
		line = tt:AddLine(toonText)
		cell = 2
		for i, v in orderedPairs(WORLD_BOSSES) do
			if v.func() then  -- should it be shown
				if boss[v.ID] then 
					bossText = RED_NEON_COLOR .. L.core.BossLooted .. END_COLOR
				else 
					if v.avail(valQLCape) then -- is the boss available
						bossText = GREEN_NEON_COLOR .. L.core.BossNotLooted .. END_COLOR 
					else
						bossText = GREY_COLOR .. L.core.BossNotLooted .. END_COLOR 
					end
				end
				tt:SetCell(line, cell, bossText, "CENTER");
				cell = cell + 1
			end
		end
	end
	
end

function GG:LoadAltLFR(tt)
	local sortorder;
	local col;

	line = tt:AddHeader(L.core.LFRTitle);	
	col = 2
	if self:GetRaidMV() then
		tt:SetCell(line, col, L.core.LFR_MV, "CENTER")
		col = col + 1
	end
	if self:GetRaidHoF() then
		tt:SetCell(line, col, L.core.LFR_HoF, "CENTER")
		col = col + 1
	end
	if self:GetRaidToES() then
		tt:SetCell(line, col, L.core.LFR_ToES, "CENTER")
		col = col + 1
	end
	if self:GetRaidToT() then
		tt:SetCell(line, col, L.core.LFR_ToT, "CENTER")
		col = col + 1
	end
	if self:GetRaidSoO() then
		tt:SetCell(line, col, L.core.LFR_SoO, "CENTER")
		col = col + 1
	end
	if self:GetRaidSoO() and self:GetLFRFlex() then
		tt:SetCell(line, col, L.core.LFR_SoOFlex, "CENTER")
		col = col + 1
	end
	
	sortorder = self:GetSortOrder();
	
	if sortorder == 1 then  -- Unsorted
	
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do
			self:ShowAltLFR(toonname, alt, tt);
		end
	
	elseif sortorder == 2 then  -- Alphabetical
		for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
			self:ShowAltLFR(toonname, alt, tt);
		end
	
	elseif sortorder == 3 then  -- Class
		for class in orderedPairs(CLASS_COLOR) do
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.class == class then
					self:ShowAltLFR(toonname, alt, tt);
				end
			end
		end
	
	elseif sortorder == 4 then  -- Valor Points
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyVP) then
				table.insert(tmp, alt.qtyVP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyVP == v then
					self:ShowAltLFR(toonname, alt, tt);
				end
			end
		end
		
	elseif sortorder == 5 then  -- iLevel
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.iLvl) then
				table.insert(tmp, alt.iLvl);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.iLvl == v then
					self:ShowAltLFR(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 6 then  -- Justice Points
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyJP) then
				table.insert(tmp, alt.qtyJP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyJP == v then
					self:ShowAltLFR(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 7 then  -- Charms
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyLCharm) then
				table.insert(tmp, alt.qtyLCharm);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyLCharm == v then
					self:ShowAltLFR(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 8 then  -- VP Cap Progress
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.periodEarnVP) then
				table.insert(tmp, alt.periodEarnVP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.periodEarnVP == v then
					self:ShowAltLFR(toonname, alt, tt);
				end
			end
		end

	end
	
end

function GG:ShowAltLFR(toon, alt, tt)
	local toonColor, toonText = "", "";
	local cellText = "";
	local col = 0;
	
	local dungeons = {};
	local saves = {};
	
	local sec = time();
	local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0});
	
	local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
	if dtPrev > sec then
	  dtPrev = dtPrev - (7 * 24 * 60 * 60);
	end
	
	self:PopulateRAIDNAMES()
	
	if alt.active == nil then alt.active = true end
	if self:GetFiltering() and alt.active == false then return end  -- exit function if the toon is not active
	
	-- if the data has not been saved then ignore
	if alt.dungeon == nil then return end
	
	-- if the toon can't do the first raid then ignore
	if alt.dungeon[LFR_STARTER_DUNGEON] == nil then return end
	if alt.dungeon[LFR_STARTER_DUNGEON].isAvailable == nil then return end
	if alt.dungeon[LFR_STARTER_DUNGEON].isAvailable <= 0 then return end
	
	-- determine the class color
	toonColor = CLASS_COLOR[alt.class]
	toonText = toonColor .. " " .. toon .. END_COLOR;

	-- check the reset time and initialise accordingly
	if dtPrev < alt.savingTime then
		-- use the data in the database
		dungeons = alt.dungeon
	else
		--ignore the data in the database
		for i, v in pairs(alt.dungeon) do
			dungeons[i] = {}
			dungeons[i].isComplete = 0
			dungeons[i].qtyLooted = 0
			dungeons[i].isAvailable = v.isAvailable
		end
	end

	-- check the reset time on the instances and reset accordingly
	for i, v in pairs(alt.saves) do
		if v.resetTime > time() then
			saves[i] = {}
			saves[i].numKilled = v.numKilled
			saves[i].numBoss = v.numBoss
			saves[i].resetTime = v.resetTime
		end
	end

	line = tt:AddLine(toonText);
	col = 2
	if self:GetRaidMV() then
		GG:SetLFRCell(tt, LFR_CELL_A_DUNGEONS, "MV", dungeons, saves, line, col)
		col = col + 1
	end
	if self:GetRaidHoF() then
		GG:SetLFRCell(tt, LFR_CELL_B_DUNGEONS, "HoF", dungeons, saves, line, col)
		col = col + 1
	end
	if self:GetRaidToES() then
		GG:SetLFRCell(tt, LFR_CELL_C_DUNGEONS, "ToES", dungeons, saves, line, col)
		col = col + 1
	end
	if self:GetRaidToT() then
		GG:SetLFRCell(tt, LFR_CELL_D_DUNGEONS, "ToT", dungeons, saves, line, col)
		col = col + 1
	end
	if self:GetRaidSoO() then
		GG:SetLFRCell(tt, LFR_CELL_E_DUNGEONS, "SoO", dungeons, saves, line, col)
		col = col + 1
	end
	
	if self:GetRaidSoO() and self:GetLFRFlex() then
		--GG:SetLFRCell(tt, LFR_CELL_E_DUNGEONS, "SoO", dungeons, saves, line, 7, true)
		GG:SetLFRCell(tt, LFR_CELL_F_DUNGEONS, "SoO Flex", dungeons, saves, line, col, 1)
		col = col + 1
	end
	
end

function GG:LoadAlt(tt)

	local sortorder;
	local col = 2
	
	line = tt:AddHeader(L.core.PDCharTextShort);
	if self:GetTooniELevel() then
		tt:SetCell(line, col, L.core.PDiELvlTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetTooniLevel() then
		tt:SetCell(line, col, L.core.PDiLvlTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonVPCap() then
		tt:SetCell(line, col, L.core.PDVPCapTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonVP() then
		tt:SetCell(line, col, L.core.PDVPTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonJP() then
		tt:SetCell(line, col, L.core.PDJPTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonCPCap() then
		tt:SetCell(line, col, L.core.PDCPCapTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonCP() then
		tt:SetCell(line, col, L.core.PDCPTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonHP() then
		tt:SetCell(line, col, L.core.PDHPTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonTimeless() then 
		tt:SetCell(line, col, L.core.PDTimelessTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonCharms() then 
		tt:SetCell(line, col, L.core.PDCharmTextShort, "RIGHT")
		col = col + 1
	end
	if self:GetToonActivity() then 
		tt:SetCell(line, col, L.core.PDActivityTextShort, "CENTER")
		col = col + 1
	end
	if self:GetToonProfCD() then
		tt:SetCell(line, col, L.core.PDProfCDTextShort, "CENTER")
		col = col + 1
	end
	if self:GetToonFarm() then
		tt:SetCell(line, col, "Farm", "CENTER")
		col = col + 1
	end
	
	sortorder = self:GetSortOrder();
	
	if sortorder == 1 then  -- Unsorted
	
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do
			self:ShowAlt(toonname, alt, tt);
		end
	
	elseif sortorder == 2 then  -- Alphabetical
		for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
			self:ShowAlt(toonname, alt, tt);
		end
	
	elseif sortorder == 3 then  -- Class
		for class in orderedPairs(CLASS_COLOR) do
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.class == class then
					self:ShowAlt(toonname, alt, tt);
				end
			end
		end
	
	elseif sortorder == 4 then  -- Valor Points
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyVP) then
				table.insert(tmp, alt.qtyVP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyVP == v then
					self:ShowAlt(toonname, alt, tt);
				end
			end
		end
		
		
	elseif sortorder == 5 then  -- iLevel
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.iLvl) then
				table.insert(tmp, alt.iLvl);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.iLvl == v then
					self:ShowAlt(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 6 then  -- Justice Points
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyJP) then
				table.insert(tmp, alt.qtyJP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyJP == v then
					self:ShowAlt(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 7 then  -- Charms
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.qtyLCharm) then
				table.insert(tmp, alt.qtyLCharm);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.qtyLCharm == v then
					self:ShowAlt(toonname, alt, tt);
				end
			end
		end

	elseif sortorder == 8 then  -- VP Cap Progress
		tmp = {};
		for toonname, alt in pairs(GG_Storage[self.currentRealm]) do 
			if not table.contains(tmp, alt.periodEarnVP) then
				table.insert(tmp, alt.periodEarnVP);
			end
		end
		table.sort(tmp, function(a,b) return a>b end);	
		for i, v in ipairs(tmp) do 
			for toonname, alt in orderedPairs(GG_Storage[self.currentRealm]) do
				if alt.periodEarnVP == v then
					self:ShowAlt(toonname, alt, tt);
				end
			end
		end

	end
	
end

function GG:ShowAlt(toon, alt, tt)
	local toonColor, toonText, valCapColor, valVPColor, valJPColor, valECharmColor, valCapText, valCharmText, valCharmColor, valECharmColor = "", "", "", "", "", "", "", "", "", "", ""
	local valWCharmColor = ""
	local valSColor, valHColor, valHSColor, valCColor, valPBColor, valCTKColor, valPMColor, valEHColor = GREEN_NEON_COLOR, GREEN_NEON_COLOR, GREEN_NEON_COLOR, GREEN_NEON_COLOR, GREEN_NEON_COLOR, GREEN_NEON_COLOR, GREEN_NEON_COLOR, GREEN_NEON_COLOR
	local valTomColor = GREEN_NEON_COLOR
	local valVP, valJP, valCap, valiLvl, valiELvl, valECharm, valLCharm, valMCharm, valWCharm, valQWarSeal, valQKey = 0,0,0,0,0,0,0,0,0, false, false
	local valQBB, valQPB, valQCTK, valQEH = false, false, false, false -- weekly quests
	local valQS, valQH, valQHS, valQC, valQPM, valQTom = false, false, false, false, false, false -- daily groups
	local valActivityText = ""
	local valVPCap, valCPCap = 0, 0
	
	local sec = time()
	local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})

	local line, col = 0, 2
	
	local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
	if dtPrev > sec then
	  dtPrev = dtPrev - (7 * 24 * 60 * 60)
	end

	-- get the last dailies reset time
	local dtDailyPrev = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=self:GetDailyResetHour()})
	if dtDailyPrev > sec then
		dtDailyPrev = dtDailyPrev - (24 * 60 * 60)
	end
	
	if alt.active == nil then alt.active = true end
	if self:GetFiltering() and alt.active == false then return end  -- exit function if the toon is not active
	
	-- Valor
	if alt.qtyMaxVP == nil then
		alt.qtyMaxVP = self.db.global.VPStandardMax
	elseif alt.qtyMaxVP <= 0 then
		alt.qtyMaxVP = self.db.global.VPStandardMax
	end 

	-- Valor Cap
	if alt.periodMaxVP == nil then
		alt.periodMaxVP = self.db.global.VPStandardCapMax
	elseif alt.periodMaxVP <= 0 then
		alt.periodMaxVP = self.db.global.VPStandardCapMax
	end 

	-- Conquest Cap
	if alt.periodMaxCP == nil then
		alt.periodMaxCP = self.db.global.CPStandardCapMax
	elseif alt.periodMaxCP <= 0 then
		alt.periodMaxCP = self.db.global.CPStandardCapMax
	end 

	-- Justice
	if alt.qtyMaxJP == nil then
		alt.qtyMaxJP = self.db.global.JPStandardMax
	elseif alt.qtyMaxJP <= 0 then
		alt.qtyMaxJP = self.db.global.JPStandardMax
	end 

	-- Honor
	if alt.qtyMaxHP == nil then
		alt.qtyMaxHP = self.db.global.HPStandardMax
	elseif alt.qtyMaxHP <= 0 then
		alt.qtyMaxHP = self.db.global.HPStandardMax
	end 
	
	if alt.iLvl == nil then alt.iLvl = 0 end
	if alt.iELvl == nil then alt.iELvl = 0 end		
	if alt.qtyECharm == nil then alt.qtyECharm = 0 end
	if alt.qtyLCharm == nil then alt.qtyLCharm = 0 end
	if alt.qtyMCharm == nil then alt.qtyMCharm = 0 end
	if alt.qtyTimeless == nil then alt.qtyTimeless = 0 end
	if alt.qtyWCharm == nil then alt.qtyWCharm = 0 end
	if alt.qtyCP == nil then alt.qtyCP = 0 end
	if alt.qtyHP == nil then alt.qtyHP = 0 end

	self:Debug("VP Max Cap: " .. alt.qtyMaxVP)

	-- determine the class color
	toonColor = CLASS_COLOR[alt.class]
	--local off_left, off_right, off_top, off_bottom = unpack(CLASS_ICON_TCOORDS[alt.class]);
	--local x = off_left .. ":" .. off_top .. ":" .. off_right - off_left+1 .. ":" .. off_bottom-off_top+1;
	--toonText = "|TInterface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes:16:16:" .. x .. "|t" .. toonColor .. toon .. END_COLOR;
	toonText = toonColor .. toon .. END_COLOR;
	
	-- weekly values
	if dtPrev < alt.savingTime then 
		valVPCap = alt.periodEarnVP -- VP Cap resets
		valCPCap = alt.periodEarnCP -- CP Cap resets
		valQWarSeal = (alt.quest[QUESTS["hWarSeal"]] or alt.quest[QUESTS["aWarSeal"]])  -- weekly quest resets
		valQKey = alt.quest[QUESTS["tKey"]]  -- weekly quest resets
		valQEH = alt.quest[QUESTS["tEH"]]
		valQCTK = (alt.quest[QUESTS["hCTK"]] or alt.quest[QUESTS["aCTK"]])  -- weekly quest resets
	end

	-- daily values
	if dtDailyPrev < alt.savingTime then
		valQS = alt.dungeon[LFR_DUNGEONIDS["S"]].isComplete
		valQH = alt.dungeon[LFR_DUNGEONIDS["H"]].isComplete
		valQHS = alt.dungeon[LFR_DUNGEONIDS["HS"]].isComplete
		valQPM = alt.quest[QUESTS["tPM"]]
		valQTom = alt.quest[QUESTS["tTom"]]
		valQC = (alt.quest[QUESTS["hC1"]] or alt.quest[QUESTS["hC2"]] or alt.quest[QUESTS["hC3"]] or alt.quest[QUESTS["hC4"]] or alt.quest[QUESTS["hC5"]] or alt.quest[QUESTS["hC6"]] or alt.quest[QUESTS["hC7"]] or alt.quest[QUESTS["hC8"]] or alt.quest[QUESTS["hC9"]])
		if valQC == false then
			valQC = (alt.quest[QUESTS["aC1"]] or alt.quest[QUESTS["aC2"]] or alt.quest[QUESTS["aC3"]] or alt.quest[QUESTS["aC4"]] or alt.quest[QUESTS["aC5"]] or alt.quest[QUESTS["aC6"]] or alt.quest[QUESTS["aC7"]] or alt.quest[QUESTS["aC8"]] or alt.quest[QUESTS["aC9"]])
		end
	end
	
	-- Add the line
	line = tt:AddLine(" " .. toonText)
	
	-- Equipped Item Level
	if self:GetTooniELevel() then
		txt = alt.iELvl
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end
	
	-- Maximum Item Level
	if self:GetTooniLevel() then
		txt = alt.iLvl
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end
	
	-- VP Cap Progress
	if self:GetToonVPCap() then
		valColor = self:GetProgressColor(valVPCap, alt.periodMaxVP)
		txt = valColor .. valVPCap .. END_COLOR -- .. "/" .. alt.periodMaxVP .. END_COLOR
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1	
	end
	
	-- Valor Points
	if self:GetToonVP() then
		valVP = alt.qtyVP
		valColor = self:GetProgressColor(valVP, alt.qtyMaxVP)
		txt = valColor .. valVP .. END_COLOR 
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1	
	end
	
	-- Justice Points
	if self:GetToonJP() then
		valJP = alt.qtyJP
		valColor = self:GetProgressColor(valJP, alt.qtyMaxJP)
		txt = valColor .. valJP .. END_COLOR 
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end
	
	-- CP Cap Progress
	if self:GetToonCPCap() then
		valColor = self:GetProgressColor(valCPCap, alt.periodMaxCP)
		txt = valColor .. valCPCap .. END_COLOR -- .. "/" .. alt.periodMaxVP .. END_COLOR
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1	
	end
	
	-- Conquest Points
	if self:GetToonCP() then
		valCP = alt.qtyCP
		valColor = GREEN_NEON_COLOR
		--valCPCapColor = self:GetProgressColor(valCPCap, alt.periodMaxCP)
		txt = valColor .. valCP .. END_COLOR 
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end

	-- Honor Points
	if self:GetToonHP() then
		valHP = alt.qtyHP
		valColor = GREEN_NEON_COLOR
		--valHPColor = self:GetProgressColor(valHP, alt.qtyMaxHP)
		txt = valColor .. valHP .. END_COLOR 
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end
	
	-- Timeless Coins
	if self:GetToonTimeless() then
		valTimeless = alt.qtyTimeless
		valColor = GREEN_NEON_COLOR
		--valHPColor = self:GetProgressColor(valHP, alt.qtyMaxHP)
		txt = valColor .. valTimeless .. END_COLOR 
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end
	
	-- Charms
	if self:GetToonCharms() then
		valLCharm = alt.qtyLCharm
		valECharm = alt.qtyECharm
		valMCharm = alt.qtyMCharm
		valWCharm = alt.qtyWCharm
		
		txt = ""
		
		-- Lesser Charms
		if self:GetCharmLesser() then
			valColor = GREEN_NEON_COLOR
			txt = txt .. valColor .. valLCharm .. " "
		end
		
		-- Elder Charms
		if self:GetCharmElder() then
			if valQKey then
				-- red Elder value
				valColor = RED_NEON_COLOR
			else
				valColor = GREEN_NEON_COLOR
			end
			txt = txt .. valColor .. valECharm .. " "
		end
		
		-- Mogu Runes
		if self:GetCharmMogu() then
			valColor = GREEN_NEON_COLOR
			txt = txt .. valColor .. valMCharm .. " "
		end
		
		-- Warforged Seal
		if self:GetCharmWarSeal() then
			if valQWarSeal then
				-- red Elder value
				valColor = RED_NEON_COLOR
			else
				valColor = GREEN_NEON_COLOR
			end
			txt = txt .. valColor .. valWCharm .. " "
		end
		
		tt:SetCell(line, col, txt, "RIGHT")
		col = col + 1
	end
	
	-- Activity Details.
	if self:GetToonActivity() then
		-- setup the colors
		if alt.dungeon[LFR_DUNGEONIDS["S"]].isAvailable == 1 then
			if valQS == 1 then valSColor = RED_NEON_COLOR end
		else
			valSColor = GREY_COLOR
			valCColor = GREY_COLOR
			valEHColor = GREY_COLOR
			valPMColor = GREY_COLOR
			valTomColor = GREY_COLOR
		end
		
		if alt.dungeon[LFR_DUNGEONIDS["H"]].isAvailable == 1 then
			if valQH == 1 then valHColor = RED_NEON_COLOR end
		else
			valHColor = GREY_COLOR
		end
		
		if alt.dungeon[LFR_DUNGEONIDS["HS"]].isAvailable == 1 then
			if valQHS == 1 then valHSColor = RED_NEON_COLOR end
		else
			valHSColor = GREY_COLOR
		end
		
		if valQC == true then valCColor = RED_NEON_COLOR end
		if valQPB == true then valPBColor = RED_NEON_COLOR end
		if valQPM == true then valPMColor = RED_NEON_COLOR end
		if valQEH == true then valEHColor = RED_NEON_COLOR end
		
		if alt.dungeon[LFR_DUNGEONIDS["S"]].isAvailable == 1 then
			if valQCTK == true then valCTKColor = RED_NEON_COLOR end
		else
			valCTKColor = GREY_COLOR
		end
		
		txt = ""
		if self:GetActivityS() then
			txt = txt .. valSColor .. "S "
		end
		
		if self:GetActivityH() then
			txt = txt .. valHColor .. "H "
		end
		
		if self:GetActivityHS() then
			txt = txt .. valHSColor .. "HS "
		end
		
		if self:GetActivityC() then
			txt = txt .. valCColor .. "C "
		end
		
		if self:GetActivityCoTK() then
			txt = txt .. valCTKColor .. "CTK "
		end
		
		if self:GetActivityPM() then
			txt = txt .. valPMColor .. "PM "
		end
		
		if self:GetActivityEH() then
			txt = txt .. valEHColor .. "EH "
		end

		txt = txt .. END_COLOR
		
		tt:SetCell(line, col, txt, "CENTER")
		col = col + 1
	end
	
	-- Profession Cooldowns
	if self:GetToonProfCD() then
		txt = ""
		if alt.trade ~= nil then 
			for i, a in orderedPairs(TRADE_SKILLS_ORDER) do
				if TRADE_SKILLS[a] and alt.trade[a] then
					if TRADE_SKILLS[a].func() then -- should the value be visible?
						if alt.trade[a] <= time() then
							txt = txt .. GREEN_NEON_COLOR
						else
							txt = txt .. RED_NEON_COLOR
						end
						txt = txt .. TRADE_SKILLS[a].Text .. " "
					end
				end
			end
			if txt ~= "" then txt = txt .. END_COLOR end
		end
		
		tt:SetCell(line, col, txt, "CENTER")
		col = col + 1
	end
		
	-- Farming
	if self:GetToonFarm() then
		txt = ""
		if alt.farmSize and alt.farmSize > 0 then
			-- setup the numbers for display.
			-- consider a reset from when data was last saved.
			if alt.farmTime <= dtDailyPrev then
				farmSow = 0
				farmHarvest = alt.farmHarvest + alt.farmSow
				if farmHarvest > alt.farmSize then farmHarvest = alt.farmSize end
			else
				farmSow = alt.farmSow
				farmHarvest = alt.farmHarvest
			end
			farmToDo = alt.farmSize - farmHarvest - farmSow
		
			txt = YELLOW_NEON_COLOR .. farmToDo .. " " .. RED_NEON_COLOR .. farmSow .. " " .. GREEN_NEON_COLOR .. farmHarvest .. END_COLOR
		end
		tt:SetCell(line, col, txt, "CENTER")
		col = col + 1
	end
		
end

function GG:SetLFRCell(tt, dungeonList, savesID, data, saves, line, cellID, flexDifficulty)

	self:PopulateRAIDNAMES()
	
	cellText = ""
	for i, v in orderedPairs(dungeonList) do
		if cellText ~= "" then cellText = cellText .. " " end
		if data[v] ~= nil and data[v].isAvailable ~= nil then
			if data[v].isAvailable == 1 then
				if data[v].isComplete == 1 then
					-- red text
					cellText = cellText .. RED_NEON_COLOR
				else
					-- green text
					cellText = cellText .. GREEN_NEON_COLOR
				end
			else
				-- orange text
				cellText = cellText .. GREY_COLOR
			end
			cellText = cellText .. data[v].qtyLooted 
		end
	end
	
	-- show the Non-LFR stuff if required.
	if self:GetLFRNormal() and flexDifficulty == nil then
		x = RAID_NAMES[savesID]
		--f = RAID_DUNGEONIDS_FLEX[x]
		if x ~= nil then x = saves[x] end
		if x == nil then
			cellText = cellText .. GREEN_NEON_COLOR .. " [0]" .. END_COLOR
		else
			if x.numBoss then
				if x.numBoss == x.numKilled then
					txtN = RED_NEON_COLOR
				else
					txtN = GREEN_NEON_COLOR
				end
				txtN = txtN .. x.numKilled
			else
				txtN = GREEN_NEON_COLOR .. "0"
			end
			
			cellText = cellText .. GREEN_NEON_COLOR .. " [" .. txtN .. GREEN_NEON_COLOR .. "]" .. END_COLOR
		end
	end
	
	tt:SetCell(line, cellID, cellText, "CENTER");

end

function GG:GetProgressColor(val, maxval)
	if val >= maxval then 
		return RED_NEON_COLOR;
	elseif val > (maxval - self.db.global.progress_orange) then 
		return ORANGE_NEON_COLOR;
	elseif val > (maxval - self.db.global.progress_yellow) then 
		return YELLOW_NEON_COLOR;
	else 
		return GREEN_NEON_COLOR;
	end
	return GREEN_NEON_COLOR;
end

-- Save the data to the database.
function GG:SaveData(evt)

	local iLvl, iELvl
	local data

	-- make sure the current values are set.
	if self.currentPlayer == nil then self.currentPlayer = UnitName('player') end
	if self.currentRealm == nil then self.currentRealm = GetRealmName() end
	if self.currentClass == nil then _, self.currentClass = UnitClass("player") end

	self:Debug("Saving Gear Grinder...")
	self:Debug("Current Player " .. self.currentPlayer)
	self:Debug("Current Realm " .. self.currentRealm)
	
	if GG_Storage == nil then
		GG_Storage = {}
	end
	if GG_Storage[self.currentRealm] == nil then
		GG_Storage[self.currentRealm] = {}
	end	
	if GG_Storage[self.currentRealm][self.currentPlayer] == nil then
		GG_Storage[self.currentRealm][self.currentPlayer] = {}
		data = GG_Storage[self.currentRealm][self.currentPlayer]
		local playerClass, englishClass = UnitClass("player")
		data.class = englishClass
		data.savingTime = 1
	else 
		data = GG_Storage[self.currentRealm][self.currentPlayer]
	end
	
	GG_Storage[self.currentRealm]["__orderedIndex"] = nil
	
	-- cater for the first time the toon is created.
	if data.savingTime == nil then data.savingTime = 1 end
	
	-- check if the data needs to be reset first.
	local sec = time()
	local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})
	local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
	if dtPrev > sec then dtPrev = dtPrev - (7 * 24 * 60 * 60) end
	if dtPrev >= data.savingTime then self:ResetData(data) end
	
	-- save the time
	data.savingTime = time()

	-- Don't do the Ilvl stuff when leaving the game
	if evt ~= "PLAYER_LEAVING_WORLD" then
		-- Item Level data saving
		iLvl, iELvl = GetAverageItemLevel()
		
		iLvl = floor(iLvl)
		iELvl = floor(iELvl)
		
		if iLvl ~= 0 then
			data.iLvl = iLvl
		end
		
		if iELvl ~= 0 then
			data.iELvl = iELvl
		end
	end
	
	-- setup the filtered value
	if data.active == nil then data.active = true end
	
	-- Save the rest of the data
	self:SaveCurrencyData(evt, data)
	self:SaveDungeonData(evt, data)
	self:SaveQuestData(evt, data)
	
end

function GG:SaveCurrencyData(evt, data) 

	local qtyVP, qtyMaxVP, wk_earnVP, wk_MaxVP
	local qtyCP, qtyMaxCP, wk_earnCP, wk_MaxCP
	local qtyJP, wk_earnJP, qtyMaxJP
	local qtyHP, wk_earnHP, qtyMaxHP
	local qtyECharm, qtyLCharm, qtyMCharm, qtyTCharm, qtyWCharm

	if GG_Storage == nil then
		self:SaveData(evt)
	end

	if data == nil then
		if GG_Storage[self.currentRealm][self.currentPlayer] == nil then
			self:SaveData(evt)
		end
		data = GG_Storage[self.currentRealm][self.currentPlayer]

		-- check if the data needs to be reset first.
		local sec = time()
		local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})
		local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
		if dtPrev > sec then dtPrev = dtPrev - (7 * 24 * 60 * 60) end
		if dtPrev >= data.savingTime then self:ResetData(data) end
		
	end

	_, qtyVP, _, wk_earnVP, wk_MaxVP, qtyMaxVP = GetCurrencyInfo(VALOR_CURRENCY_ID)
	_, qtyJP, _, wk_earnJP, _, qtyMaxJP = GetCurrencyInfo(JUSTICE_CURRENCY_ID)
	_, qtyCP, _, wk_earnCP, wk_MaxCP, qtyMaxCP = GetCurrencyInfo(CONQUEST_CURRENCY_ID)
	_, qtyHP, _, wk_earnHP, _, qtyMaxHP = GetCurrencyInfo(HONOR_CURRENCY_ID)
	_, qtyECharm = GetCurrencyInfo(ELDER_CHARM_CURRENCY_ID)
	_, qtyLCharm = GetCurrencyInfo(LESSER_CHARM_CURRENCY_ID)
	_, qtyMCharm = GetCurrencyInfo(MOGU_CHARM_CURRENCY_ID)
	_, qtyTimeless = GetCurrencyInfo(TIMELESS_CHARM_CURRENCY_ID)
	_, qtyWCharm = GetCurrencyInfo(WARSEAL_CHARM_CURRENCY_ID)
	
	wk_MaxVP = floor(wk_MaxVP/100)
	wk_MaxCP = wk_MaxCP --floor(wk_MaxCP/100)
	qtyMaxVP = floor(qtyMaxVP/100)
	qtyMaxCP = floor(qtyMaxCP/100)
	qtyMaxJP = floor(qtyMaxJP/100)
	qtyMaxHP = floor(qtyMaxHP/100)
	
	-- save data 
	-- New values that are recorded.
	-- Valor
	data.qtyVP = qtyVP
	data.qtyMaxVP = qtyMaxVP
	data.periodEarnVP = wk_earnVP
	data.periodMaxVP = wk_MaxVP

	-- Conquest
	data.qtyCP = qtyCP
	data.qtyMaxCP = qtyMaxCP
	data.periodEarnCP = wk_earnCP
	data.periodMaxCP = wk_MaxCP
	
	-- Justice
	data.qtyJP = qtyJP
	data.periodEarnJP = wk_earnJP
	data.qtyMaxJP = qtyMaxJP
	
	-- Honor
	data.qtyHP = qtyHP
	data.periodEarnHP = wk_earnHP
	data.qtyMaxHP = qtyMaxHP
	
	-- charms
	data.qtyECharm = qtyECharm
	data.qtyLCharm = qtyLCharm
	data.qtyMCharm = qtyMCharm
	data.qtyTimeless = qtyTimeless
	data.qtyWCharm = qtyWCharm

end

function GG:SaveTradeData(evt, data) 

	if GG_Storage == nil then
		self:SaveData(evt)
	end

	if data == nil then
		if GG_Storage[self.currentRealm][self.currentPlayer] == nil then
			self:SaveData(evt)
		end
		data = GG_Storage[self.currentRealm][self.currentPlayer]
	end
	
	-- ignore if the tradeskill is linked
	if IsTradeSkillLinked() ~= nil then return end
	
	-- save off the tradeskill data
	if data.trade == nil then data.trade = {} end
	
	-- get the professions
	prof1, prof2 = "", ""
	p1, p2 = GetProfessions()
	if p1 then prof1 = GetProfessionInfo(p1) end
	if p2 then prof2 = GetProfessionInfo(p2) end
	
	-- if professions have changed then reset the trade cooldown data
	if data.prof1 ~= nil then
		if data.prof1 ~= prof1 then
			-- reset the trade data, profs have been changed
			data.trade = {}
			data.prof1 = prof1
		end
	else
		data.prof1 = prof1
	end
	
	if data.prof2 ~= nil then
		if data.prof2 ~= prof2 then
			-- reset the trade data, profs have been changed
			data.trade = {}
			data.prof2 = prof2
		end
	else
		data.prof2 = prof2
	end
	
	-- save the profession cooldown data
	for i=1, GetNumTradeSkills() do
		local name = GetTradeSkillInfo(i)
		local cooldown = GetTradeSkillCooldown(i)
		if TRADE_SKILLS[name] ~= nil then 
			if cooldown then
				-- time of the reset is fk'ed in wow.  need to overwrite it.
				-- time begin used is the hour of the Weekly Reset.  DODGY BLIZZARD!!!!
				local sec = time()
				local nextReset = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=self:GetResetHour()})
				if nextReset < sec then
					nextReset = nextReset + (24 * 60 * 60)
				end
				
				data.trade[name] = nextReset
				--data.trade[name] = time() + cooldown  -- save the time it will reset.
			else
				data.trade[name] = 0  -- ability available.
			end
		end
	end

end

function GG:SaveDungeonData(evt, data)

	if GG_Storage == nil then
		self:SaveData(evt)
	end

	if data == nil then
		if GG_Storage[self.currentRealm][self.currentPlayer] == nil then
			self:SaveData(evt)
		end
		data = GG_Storage[self.currentRealm][self.currentPlayer]
		
		-- check if the data needs to be reset first.
		local sec = time()
		local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})
		local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
		if dtPrev > sec then dtPrev = dtPrev - (7 * 24 * 60 * 60) end
		if dtPrev >= data.savingTime then self:ResetData(data) end
		
	end

	-- save off the LFR Raid saves/completions
	for i, v in pairs(LFR_DUNGEONIDS) do
		_, numKilled = GetLFGDungeonNumEncounters(v); 
		_, _, raidCompleted, raidAvailable = GetLFGDungeonRewardCapInfo(v);
	
		if data.dungeon == nil then data.dungeon = {} end
		if data.dungeon[v] == nil then data.dungeon[v] = {} end
		data.dungeon[v].qtyLooted = numKilled
		data.dungeon[v].isComplete = raidCompleted
		data.dungeon[v].isAvailable = raidAvailable
	end

	self:PopulateRAIDNAMES()
	
	-- Save off the Saved Instances.
	local instanceName, test, numBoss, instanceReset = "", "", 0, 0
	data.saves = {}
	for i = 1, GetNumSavedInstances() do
		instanceName, _, instanceReset, instanceDifficulty, _, _, _, _, _, _, numBoss, numKilled  = GetSavedInstanceInfo(i)
		test = RAID_NAMES[instanceName]

		if test ~= nil then
			-- we have a match
			data.saves[instanceName] = {}
			data.saves[instanceName].resetTime = time() + instanceReset
			
			-- test if it's Flex mode
			if instanceDifficulty > 4 then
				--data.saves[instanceName].numFlexBoss = numBoss
				--data.saves[instanceName].numFlexKilled = numKilled
			else
				data.saves[instanceName].numBoss = numBoss
				data.saves[instanceName].numKilled = numKilled
			end
		end
	end
	
	
end

function GG:SaveFarmData(evt, action)  	-- valid actions = Harvest, Sow, Sow4
	local data, diff
	
	-- verify the storage.
	if GG_Storage == nil then
		self:SaveData(evt)
	end
	if GG_Storage[self.currentRealm][self.currentPlayer] == nil then
		self:SaveData(evt)
	end
	data = GG_Storage[self.currentRealm][self.currentPlayer]

	self:UpdateFarmSize(data)
	
	-- initialise if needed
	if data.farmTime == nil then data.farmTime = time() end
	if data.farmSow == nil then data.farmSow = 0 end
	if data.farmHarvest == nil then data.farmHarvest = 0 end
	
	-- calculate the previous reset time
	local sec = time()
	local dtDailyPrev = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=self:GetDailyResetHour()})
	if dtDailyPrev > sec then
		dtDailyPrev = dtDailyPrev - (24 * 60 * 60)
	end

	-- check reset time.
	-- if farm has matured then update harvest qty
	if data.farmTime <= dtDailyPrev then
		data.farmHarvest = data.farmHarvest + data.farmSow
		if data.farmHarvest > data.farmSize then data.farmHarvest = data.farmSize end  -- Test the Harvest has not exceeded the farm size
		
		data.farmSow = 0
	end
	
	-- save the time the farm was last processed
	data.farmTime = time()
	
	-- process the action but don't exceed the min/max
	if action == "Sow" or action == "Sow4" then 
		if action == "Sow4" then diff = 4 else diff = 1 end
		data.farmSow = data.farmSow + diff
	end
	if action == "Harvest" then 
		data.farmHarvest = data.farmHarvest - 1
	end
	
	-- check totals and adjust if needed
	if data.farmSow < 0 then data.farmSow = 0 end
	if data.farmSow > data.farmSize then data.farmSow = data.farmSize end
	
	if data.farmHarvest < 0 then data.farmHarvest = 0 end
	if data.farmHarvest > data.farmSize then data.farmHarvest = data.farmSize end

end

function GG:PopulateRAIDNAMES()
	
	local instanceName = ""
	-- Populate the RAID_NAMES
	if RAID_NAMES == nil then
		RAID_NAMES = {}
		for i, v in pairs(RAID_DUNGEONIDS) do
			instanceName = GetDungeonInfo(v)
			RAID_NAMES[instanceName] = i
			RAID_NAMES[i] = instanceName
			RAID_NAMES[v] = instanceName
		end
	end
	
end

function GG:SaveQuestData(evt, data)

	local t
	
	if GG_Storage == nil then
		self:SaveData(evt)
	end

	if data == nil then
		if GG_Storage[self.currentRealm][self.currentPlayer] == nil then
			self:SaveData(evt)
		end
		data = GG_Storage[self.currentRealm][self.currentPlayer]
		
		-- check if the data needs to be reset first.
		local sec = time()
		local dtDate = time({year=date('%Y',sec),month=date('%m',sec),day=date('%d',sec),hour=0})
		local dtPrev = dtDate - (((date("%w", dtDate) - self:GetResetDayOfWeek()) % 7) ) * 86400 + (self:GetResetHour() * 60 * 60)
		if dtPrev > sec then dtPrev = dtPrev - (7 * 24 * 60 * 60) end
		if dtPrev >= data.savingTime then self:ResetData(data) end
		
	end

	
	
	t = GetQuestsCompleted()
	
	-- save off the world boss kills
	if data.boss == nil then data.boss = {} end
	for i, v in pairs(WORLD_BOSSES) do
		--if v ~= 32519 then  -- have to fake an oondasta quest kill detection
			data.boss[v.ID] = t[v.ID]
		--end	
		if data.boss[v.ID] == nil then data.boss[v.ID] = false end
	end
	
	-- save off the quest tracking
	if data.quest == nil then data.quest = {} end
	for i, v in pairs(QUESTS) do
		data.quest[v] = t[v]
		if data.quest[v] == nil then data.quest[v] = false end
	end
	
	self:UpdateFarmSize(data)
	
end

function GG:ResetData(data)

	-- data is mandatory.  must be called from one of the Save Data functions
	if data == nil then return end

	if data.active == nil then data.active = true end
	if data.qtyJP == nil then data.qtyJP = 0 end
	if data.qtyVP == nil then data.qtyVP = 0 end
	if data.qtyCP == nil then data.qtyCP = 0 end
	if data.qtyHP == nil then data.qtyHP = 0 end
	
	-- reset the resettables
	data.periodEarnVP = 0
	data.periodEarnJP = 0
	data.periodEarnCP = 0
	data.periodEarnHP = 0
		
	-- reset the LFR data
	if data.dungeon == nil then data.dungeon = {} end
	for i, v in pairs(LFR_DUNGEONIDS) do
		if data.dungeon[v] == nil then data.dungeon[v] = {} end
		data.dungeon[v].qtyLooted = 0
		data.dungeon[v].isComplete = 0
	end

	-- reset the world boss kills
	if data.boss == nil then data.boss = {} end
	for i, v in pairs(WORLD_BOSSES) do
		data.boss[v.ID] = false
	end
	
	-- reset the quest tracking
	if data.quest == nil then data.quest = {} end
	for i, v in pairs(QUESTS) do
		data.quest[v] = false
	end
	
	-- reset the saves
	data.saves = {}
	
	-- dont' reset trade data.  it get's reset as needed.
	--data.trade = {}
	
	-- initialise the farm values
	if data.farmSize == nil then data.farmSize = 0 end
	if data.farmTime == nil then data.farmTime = 0 end
	if data.farmHarvest == nil then data.farmHarvest = 0 end
	if data.farmSow == nil then data.farmSow = 0 end
	
end

function GG:SaveFakeQuestKill(q)

	local data = GG_Storage[self.currentRealm][self.currentPlayer]
	if data.boss == nil then data.boss = {} end
	data.boss[q] = true

end

function GG:UpdateFarmSize(data)
	
	-- will always be called with a value for the parameter
	if data == nil then return end
	
	-- setup the farm size 
	data.farmSize = 0
	if data.quest[QUESTS.farm4] and data.quest[QUESTS.farm4] == true then data.farmSize = 4 end
	if data.quest[QUESTS.farm8] and data.quest[QUESTS.farm8] == true then data.farmSize = 8 end
	if data.quest[QUESTS.farm12] and data.quest[QUESTS.farm12] == true then data.farmSize = 12 end
	if data.quest[QUESTS.farm16] and data.quest[QUESTS.farm16] == true then data.farmSize = 16 end
	
	-- set the farm data to 0 so the tooltip works with the reset code.
	if data.farmTime == nil then data.farmTime = 0 end
	if data.farmHarvest == nil then data.farmHarvest = 0 end
	if data.farmSow == nil then data.farmSow = 0 end
	
end

-- Make sure the database is the latest version
function GG:UpdateSettings()
    
    if self.db.global.version == self.versionMajor then
        -- Same version
    end
    
    -- Update version information
    self.db.global.version = self.versionMajor;

	for r, toons in pairs(GG_Storage) do
		for t, alt in pairs(GG_Storage[r]) do

			-- setup the boss tracking
			if alt.boss == nil then
				alt.boss = {}
			end
			for i, v in pairs(WORLD_BOSSES) do
				if alt.boss[v.ID] == nil then
					alt.boss[v.ID] = false
				end
			end
			alt.boss1, alt.boss2, alt.boss3, alt.boss4 = nil,nil,nil,nil

			
			if alt.iLvl == nil then alt.iLvl = 0 end
			if alt.iELvl == nil then alt.iELvl = 0 end
			
			-- setup the dungeon tracking
			if alt.dungeon == nil then
				alt.dungeon = {}
			end
			for i, v in pairs(LFR_DUNGEONIDS) do
				if alt.dungeon[v] == nil then 
					alt.dungeon[v] = {}
					alt.dungeon[v].qtyLooted = 0
					alt.dungeon[v].isComplete = 0
					alt.dungeon[v].isAvailable = 0
				end
			end


			-- setup the quest tracking
			if alt.quest == nil then
				alt.quest = {}
			end
			for i, v in pairs(QUESTS) do
				if alt.quest[v] == nil then
					alt.quest[v] = false
				end
			end

			if alt.saves == nil then alt.saves = {} end
			
			if alt.active == nil then alt.active = true end

		end
	end
		
	
end

-- Purge the Database
function GG:PurgeDB()

	GG_Storage = nil;
	
	self:SaveData("PURGEDB");

end

--[[

    Setters, Getter and Togglers

]]

-- Set
function GG:SetShowCombat(v) self.db.global.combat = v; end

function GG:SetToonCharms(v) self.db.global.ToonCharms = v; end
function GG:SetToonActivity(v) self.db.global.ToonActivity = v; end
function GG:SetTooniLevel(v) self.db.global.TooniLevel = v; end
function GG:SetTooniELevel(v) self.db.global.TooniELevel = v; end
function GG:SetToonFarm(v) self.db.global.ToonFarm = v; end
function GG:SetToonProfCD(v) self.db.global.ToonProfCD = v; end
function GG:SetToonVPCap(v) self.db.global.ToonVPCap = v; end
function GG:SetToonCPCap(v) self.db.global.ToonCPCap = v; end
function GG:SetToonVP(v) self.db.global.ToonVP = v; end
function GG:SetToonJP(v) self.db.global.ToonJP = v; end
function GG:SetToonHP(v) self.db.global.ToonHP = v; end
function GG:SetToonCP(v) self.db.global.ToonCP = v; end
function GG:SetToonTimeless(v) self.db.global.ToonTimeless = v; end

function GG:SetActivityPM(v) self.db.global.ActivityPM = v; end
function GG:SetActivityEH(v) self.db.global.ActivityEH = v; end
function GG:SetActivityH(v) self.db.global.ActivityH = v; end
function GG:SetActivityHS(v) self.db.global.ActivityHS = v; end
function GG:SetActivityS(v) self.db.global.ActivityS = v; end
function GG:SetActivityC(v) self.db.global.ActivityC = v; end
function GG:SetActivityCoTK(v) self.db.global.ActivityCoTK = v; end
function GG:SetActivityTom(v) self.db.global.ActivityTom = v; end

function GG:SetSortOrder(v) self.db.global.sortOrder = v; end

function GG:SetLFR(v) self.db.global.lfr = v; end
function GG:SetLFRFlex(v) self.db.global.lfrFlex = v; end
function GG:SetLFRNormal(v) self.db.global.lfrNormal = v; end

function GG:SetCharmLesser(v) self.db.global.charmLesser = v; end
function GG:SetCharmElder(v) self.db.global.charmElder = v; end
function GG:SetCharmMogu(v) self.db.global.charmMogu = v; end
function GG:SetCharmWarSeal(v) self.db.global.charmWarSeal = v; end

function GG:SetRaidMV(v) self.db.global.RaidMV = v; end
function GG:SetRaidHoF(v) self.db.global.RaidHoF = v; end
function GG:SetRaidToES(v) self.db.global.RaidToES = v; end
function GG:SetRaidToT(v) self.db.global.RaidToT = v; end
function GG:SetRaidSoO(v) self.db.global.RaidSoO = v; end

function GG:SetWorldBoss(v) self.db.global.worldBoss = v; end
function GG:SetBossSha(v) self.db.global.BossSha = v; end
function GG:SetBossGalleon(v) self.db.global.BossGalleon = v; end
function GG:SetBossNalak(v) self.db.global.BossNalak = v; end
function GG:SetBossOondasta(v) self.db.global.BossOondasta = v; end
function GG:SetBossCelestial(v) self.db.global.BossCelestial = v; end
function GG:SetBossOrdos(v) self.db.global.BossOrdos = v; end

function GG:SetProfAlc(v) self.db.global.ProfAlc = v; end
function GG:SetProfBS(v) self.db.global.ProfBS = v; end
function GG:SetProfBS2(v) self.db.global.ProfBS2 = v; end
function GG:SetProfEnch(v) self.db.global.ProfEnch = v; end
function GG:SetProfTailor(v) self.db.global.ProfTailor = v; end
function GG:SetProfTailor2(v) self.db.global.ProfTailor2 = v; end
function GG:SetProfScribe(v) self.db.global.ProfScribe = v; end
function GG:SetProfJCGem(v) self.db.global.ProfJCGem = v; end
function GG:SetProfJCHeart(v) self.db.global.ProfJCHeart = v; end
function GG:SetProfLW(v) self.db.global.ProfLW = v; end
function GG:SetProfLW2(v) self.db.global.ProfLW2 = v; end
function GG:SetProfEng(v) self.db.global.ProfEng = v; end

function GG:SetTTScale(v) self.db.global.ttScale = v; end
function GG:SetFiltering(v) self.db.global.filtering = v; end
function GG:SetBGGeneric(i, v) self.db.global.Background[ i[#i] ] = v end
function GG:SetLabel(v) self.db.global.showLabel = v; self:UpdateLDB(true); end

function GG:SetLDBlabel(v) self.db.global.ldbLabel = v; self:UpdateLDB(true); end
function GG:SetLDBTextColor(v) self.db.global.ldbTextColor = v; self:UpdateLDB(true); end
function GG:SetLDBDisplay(v) self.db.global.ldbDisplay = v; self:UpdateLDB(true); end
function GG:SetLDBDisplayLock(v) self.db.global.ldbDisplayLock = v; end

-- Get
function GG:GetMinimap() return not self.db.global.minimap.hide; end
function GG:GetVPPaperdoll() return self.db.global.cinfoVP; end
function GG:GetVPCapPaperdoll() return self.db.global.cinfoVPCap; end
function GG:GetJPPaperdoll() return self.db.global.cinfoJP; end
function GG:GetDebug() return self.db.char.debug; end
function GG:GetShowCombat() return self.db.global.combat; end
function GG:GetSortOrder() return self.db.global.sortOrder; end
function GG:GetBGGeneric(i) return self.db.global.Background[ i[#i] ] end
function GG:GetBGTile() return self.db.global.Background.Tile end
function GG:GetTTScale() return self.db.global.ttScale end
function GG:GetFiltering() return self.db.global.filtering end

function GG:GetLabel() return self.db.global.showLabel; end
function GG:GetLDB() return self.db.global.ldbText; end
function GG:GetLDBTextColor() return self.db.global.ldbTextColor; end
function GG:GetLDBlabel() return self.db.global.ldbLabel; end
function GG:GetLDBDisplay() return self.db.global.ldbDisplay end
function GG:GetLDBDisplayLock() return self.db.global.ldbDisplayLock end

function GG:GetToonCharms() return self.db.global.ToonCharms; end
function GG:GetToonActivity() return self.db.global.ToonActivity; end
function GG:GetTooniLevel() return self.db.global.TooniLevel; end
function GG:GetTooniELevel() return self.db.global.TooniELevel; end
function GG:GetToonFarm() return self.db.global.ToonFarm end
function GG:GetToonProfCD() return self.db.global.ToonProfCD end
function GG:GetToonVPCap() return self.db.global.ToonVPCap end
function GG:GetToonVP() return self.db.global.ToonVP end
function GG:GetToonJP() return self.db.global.ToonJP end
function GG:GetToonHP() return self.db.global.ToonHP end
function GG:GetToonCP() return self.db.global.ToonCP end
function GG:GetToonCPCap() return self.db.global.ToonCPCap end
function GG:GetToonTimeless() return self.db.global.ToonTimeless end

function GG:GetActivityPM() return self.db.global.ActivityPM; end
function GG:GetActivityEH() return self.db.global.ActivityEH; end
function GG:GetActivityH() return self.db.global.ActivityH; end
function GG:GetActivityHS() return self.db.global.ActivityHS; end
function GG:GetActivityS() return self.db.global.ActivityS; end
function GG:GetActivityC() return self.db.global.ActivityC; end
function GG:GetActivityCoTK() return self.db.global.ActivityCoTK; end
function GG:GetActivityTom() return self.db.global.ActivityTom; end

function GG:GetLFR() return self.db.global.lfr end
function GG:GetLFRFlex() return self.db.global.lfrFlex end
function GG:GetLFRNormal() return self.db.global.lfrNormal end

function GG:GetCharmLesser() return self.db.global.charmLesser end
function GG:GetCharmElder() return self.db.global.charmElder end
function GG:GetCharmMogu() return self.db.global.charmMogu end
function GG:GetCharmWarSeal() return self.db.global.charmWarSeal end

function GG:GetRaidMV() return self.db.global.RaidMV end
function GG:GetRaidHoF() return self.db.global.RaidHoF end
function GG:GetRaidToES() return self.db.global.RaidToES end
function GG:GetRaidToT() return self.db.global.RaidToT end
function GG:GetRaidSoO() return self.db.global.RaidSoO end

function GG:GetWorldBoss() return self.db.global.worldBoss; end
function GG:GetBossSha() return self.db.global.BossSha end
function GG:GetBossGalleon() return self.db.global.BossGalleon end
function GG:GetBossNalak() return self.db.global.BossNalak end
function GG:GetBossOondasta() return self.db.global.BossOondasta end
function GG:GetBossCelestial() return self.db.global.BossCelestial end
function GG:GetBossOrdos() return self.db.global.BossOrdos end

function GG:GetProfAlc() return self.db.global.ProfAlc end
function GG:GetProfBS() return self.db.global.ProfBS end
function GG:GetProfBS2() return self.db.global.ProfBS2 end
function GG:GetProfTailor() return self.db.global.ProfTailor end
function GG:GetProfTailor2() return self.db.global.ProfTailor2 end
function GG:GetProfEnch() return self.db.global.ProfEnch end
function GG:GetProfScribe() return self.db.global.ProfScribe end
function GG:GetProfJCGem() return self.db.global.ProfJCGem end
function GG:GetProfJCHeart() return self.db.global.ProfJCHeart end
function GG:GetProfLW() return self.db.global.ProfLW end
function GG:GetProfLW2() return self.db.global.ProfLW2 end
function GG:GetProfEng() return self.db.global.ProfEng end


-- Toggle
--[[
function GG:ToggleMinimap() self:SetMinimap(not self:GetMinimap()); end
function GG:ToggleCharms() self:SetCharms(not self:GetToonCharms()); end
function GG:ToggleActivity() self:SetToonActivity(not self:GetToonActivity()); end
function GG:TogglePM() self:SetPM(not self:GetPM()); end
function GG:ToggleEH() self:SetEH(not self:GetEH()); end
function GG:ToggleH() self:SetH(not self:GetH()); end
function GG:ToggleHS() self:SetHS(not self:GetHS()); end
function GG:ToggleS() self:SetS(not self:GetS()); end
function GG:ToggleC() self:SetC(not self:GetC()); end
function GG:ToggleCoTK() self:SetCoTK(not self:GetCoTK()); end
function GG:ToggleBB() self:SetBB(not self:GetBB()); end
function GG:ToggleShowCombat() self:SetShowCombat(not self:GetShowCombat()); end
function GG:ToggleiLevel() self:SetiLevel(not self:GetTooniLevel()); end
function GG:ToggleWorldBoss() self:SetWorldBoss(not self:GetWorldBoss()); end
function GG:ToggleSortOrder() self:SetSortOrder(not self:GetSortOrder()); end
function GG:ToggleVPPaperdoll() self:SetVPPaperdoll(not self:GetVPPaperdoll()); end
function GG:ToggleVPCapPaperdoll() self:SetVPCapPaperdoll(not self:GetVPCapPaperdoll()); end
function GG:ToggleJPPaperdoll() self:SetJPPaperdoll(not self:GetJPPaperdoll()); end
function GG:ToggleLabel() self:SetLabel(not self:GetLabel()); end
function GG:ToggleLDBlabel() self:SetLDBlabel(not self:GetLDBlabel()); end
function GG:ToggleLDBTextColor() self:SetLDBTextColor(not self:GetLDBTextColor()); end
function GG:ToggleLFR() self:SetLFR(not self:GetLFR()); end
function GG:ToggleNonLFR() self:SetNonLFR(not self:GetLFRNormal()); end
function GG:ToggleFiltering() self:SetFiltering(not self:GetFiltering()); end
function GG:ToggleFarm() self:SetFarm(not self:GetToonFarm()); end
function GG:ToggleProfCD() self:SetProfCD(not self:GetToonProfCD()); end
function GG:ToggleLDBDisplayLock() self:SetLDBDisplayLock(not self:GetLDBDisplayLock()); end
]]
function GG:ToggleToonFilter() self:SetToonFilter(not self:GetToonFilter()); end

-- Advanced Gets
function GG:GetBGColor(i)
	local t = self.db.global.Background.Color
	return t.r, t.g, t.b, t.a
end

function GG:GetBGBorderColor(i)
	local x = self.db.global.Background.BorderColor
	return x.r, x.g, x.b, x.a
end

function GG:GetRemainingTimeText(seconds)
	local days = floor(seconds / 86400);
	seconds = seconds - days * 86400;
	local hours = floor(seconds / 3600);
	seconds = seconds - hours * 3600;
	local minutes = floor(seconds / 60);
	seconds = seconds - minutes * 60;
	local TIME_COLOR = "";
	local TIME_TEXT = "";
	local timeStr = "";		-- one space just to pad slightly vs being too close to raid/instance name string.
	
	-- compact view's colors.
	-- moved "Reset in" text so that it's now above lockout time.
	TIME_COLOR = WHITE_BRIGHT_COLOR ;
	TIME_TEXT = WHITE_BRIGHT_COLOR ;
	
	if days > 0 then
		timeStr = timeStr .. TIME_COLOR .. days .. TIME_TEXT .. " " .. L.core.cooldownInfoDay .. END_COLOR .. " ";
	end
	
	if hours > 0 then
		timeStr = timeStr .. TIME_COLOR .. hours .. TIME_TEXT .. " " .. L.core.cooldownInfoHr .. END_COLOR .. " ";
	end

	if minutes then 
		timeStr = timeStr .. TIME_COLOR .. minutes .. TIME_TEXT .. " " .. L.core.cooldownInfoMin .. END_COLOR .. " ";
	end


	return timeStr;
end

function GG:RotateButtonText()

  -- increase the display value (rotate it to min value if at max)
  x = self:GetLDBDisplay()

  if x == 10 then x = 1 else x = x + 1 end

  self:SetLDBDisplay(x)

end

function GG:GetButtonText()
	local a, displaytype = "", self:GetLDBDisplay()
	local vpcapText, vpText, lfrText, jpText, finalText = "", "", "", "", ""
	local lfrDone, lfrTotal = 0, 0
	
	if GG_Storage == nil then self:SaveData("INIT") end
	if GG_Storage[self.currentRealm] == nil then self:SaveData("INIT") end
	
	local data = GG_Storage[self.currentRealm][self.currentPlayer]
	if data == nil then self:SaveData("INIT") end
	data = GG_Storage[self.currentRealm][self.currentPlayer]
	local earnVP, qtyVP, qtyJP = data.periodEarnVP, data.qtyVP, data.qtyJP
	
--[[
						[1] = "VP Cap (VP) <JP> [LFR]",
						[2] = "VP Cap (VP) [LFR]",
						[3] = "VP Cap (VP) <JP>",
						[4] = "VP Cap (VP)",
						[5] = "VP Cap [LFR]", 
						[6] = "VP Cap",
						[7] = "VP <JP> [LFR]",
						[8] = "VP <JP>",
						[9] = "VP [LFR]",
						[10] = "LFR",
]]
						
	-- Determine the VPCap text to display
	if displaytype >= 1 and displaytype <= 6 then
		if self:GetPeriodMaxVP() <= 0 then
			vpcapText = "N/A";
		else
			vpcapText = earnVP .. "/" .. self:GetPeriodMaxVP()
		end

		if self:GetLDBTextColor() then
			if earnVP >= self:GetPeriodMaxVP() then 
				a = RED_NEON_COLOR
			elseif earnVP > (self:GetPeriodMaxVP() - self.db.global.progress_orange) then 
				a = ORANGE_NEON_COLOR
			elseif earnVP > (self:GetPeriodMaxVP() - self.db.global.progress_yellow) then 
				a = YELLOW_NEON_COLOR
			else
				a = GREEN_NEON_COLOR
			end
			vpcapText = a .. vpcapText .. END_COLOR
		end
	end
	
	-- Determine the VP text to display
	if (displaytype >= 1 and displaytype <= 4) or (displaytype >= 7 and displaytype <= 9) then
		if self:GetMaxVP() <= 0 then
			vpText = "N/A";
		else
			vpText = qtyVP
		end

		if self:GetLDBTextColor() then
			if qtyVP >= self:GetMaxVP() then 
				a = RED_NEON_COLOR
			elseif qtyVP > (self:GetMaxVP() - self.db.global.progress_orange) then 
				a = ORANGE_NEON_COLOR
			elseif qtyVP > (self:GetMaxVP() - self.db.global.progress_yellow) then 
				a = YELLOW_NEON_COLOR
			else
				a = GREEN_NEON_COLOR
			end
			vpText = a .. vpText .. END_COLOR
		end
	end
	
	-- Determine the JP text to display
	if displaytype == 1 or displaytype == 3 or displaytype == 7 or displaytype == 8 then
		if self:GetMaxJP() <= 0 then
			jpText = "N/A";
		else
			jpText = qtyJP
		end

		if self:GetLDBTextColor() then
			if qtyJP >= self:GetMaxJP() then 
				a = RED_NEON_COLOR
			elseif qtyJP > (self:GetMaxJP() - self.db.global.progress_orange) then 
				a = ORANGE_NEON_COLOR
			elseif qtyJP > (self:GetMaxJP() - self.db.global.progress_yellow) then 
				a = YELLOW_NEON_COLOR
			else
				a = GREEN_NEON_COLOR
			end
			jpText = a .. jpText .. END_COLOR
		end
	end
	
	-- Determine the LFR text to display
	if displaytype == 1 or displaytype == 2 or displaytype == 5 or displaytype == 7 or displaytype >= 9 then
		lfrDone, lfrTotal = self:GetLFRTotals(data.dungeon)
		
		if lfrTotal <= 0 then
			lfrText = "N/A";
		else
			lfrText = lfrDone .. "/" .. lfrTotal
		end

		if self:GetLDBTextColor() then
			a = GREEN_NEON_COLOR
			lfrText = a .. lfrText .. END_COLOR
		end
	end
	
	-- Join it all together now
	finalText = vpcapText
	
	if vpText ~= "" then
		closeit = false
		if finalText ~= "" then 
			finalText = finalText .. " (" 
			closeit = true
		end
		finalText = finalText .. vpText
		if closeit then finalText = finalText .. ")" end
	end
	
	if jpText ~= "" then
		closeit = false
		if finalText ~= "" then 
			finalText = finalText .. " <" 
			closeit = true
		end
		finalText = finalText .. jpText
		if closeit then finalText = finalText .. ">" end
	end
	
	if lfrText ~= "" then
		closeit = false
		if finalText ~= "" then 
			finalText = finalText .. " [" 
			closeit = true
		end
		finalText = finalText .. lfrText
		if closeit then finalText = finalText .. "]" end
	end
	
--print("what should be displayed on the LDB Text button .. " .. finalText)
	return " " .. finalText
end

function GG:GetLFRTotals(dungeons)
	
	local cntDone, cnt = 0, 0
	
	for i,v in pairs(dungeons) do
		if i == LFR_DUNGEONIDS.H or i == LFR_DUNGEONIDS.S or i == LFR_DUNGEONIDS.HS or (i >= LFR_DUNGEONIDS.SoOaF and i <= LFR_DUNGEONIDS.SoOdF) then
			-- ignore these ones.
		else
	
			if v.isAvailable and v.isAvailable >= 1 then
				cnt = cnt + 1
			end
			if v.isComplete and v.isComplete >= 1 then
				cntDone = cntDone + 1
			end
		end
	end

	return cntDone, cnt
	
end

function GG:GetToonFilter() 
	
	local data = GG_Storage[self.currentRealm][self.currentPlayer]
	
	if data.active == nil then data.active = true end
	
	return data.active
end

function GG:GetMaxVP()
	if self.maxVP > 0 then
		return self.maxVP;
	else
		_, _, _, _, self.periodMaxVP, self.maxVP = GetCurrencyInfo(VALOR_CURRENCY_ID);
		self.periodMaxVP = floor(self.periodMaxVP / 100);
		self.maxVP = floor(self.maxVP/100);
		return self.maxVP;
	end

end

function GG:GetMaxJP()
	if self.maxJP > 0 then
		return self.maxJP;
	else
		_, _, _, _, _, self.maxJP = GetCurrencyInfo(JUSTICE_CURRENCY_ID);
		self.maxJP = floor(self.maxJP/100);
		return self.maxJP;
	end

end

function GG:GetPeriodMaxVP()
	if self.periodMaxVP > 0 then
		return self.periodMaxVP;
	else
		_, _, _, _, self.periodMaxVP, self.maxVP = GetCurrencyInfo(VALOR_CURRENCY_ID);
		self.periodMaxVP = floor(self.periodMaxVP / 100);
		self.maxVP = floor(self.maxVP/100);
		
		return self.periodMaxVP;
	end

end

function GG:GetResetHour() 
	if self.db.global.reset_hour < 0 or self.db.global.reset_hour > 23 then
		self.db.global.reset_hour = GG_Defaults.global.reset_hour;
	end
	
	return self.db.global.reset_hour; 
	
end

function GG:GetDailyResetHour() 
	if self.db.global.daily_reset_hour < 0 or self.db.global.daily_reset_hour > 23 then
		self.db.global.daily_reset_hour = GG_Defaults.global.daily_reset_hour;
	end
	
	return self.db.global.daily_reset_hour; 
	
end

function GG:GetResetDayOfWeek() 
	if self.db.global.reset_dayofweek < 1 or self.db.global.reset_dayofweek > 7 then
		self.db.global.reset_dayofweek = GG_Defaults.global.reset_dayofweek;
	end
	
	return self.db.global.reset_dayofweek; 

end


-- Advanced sets
function GG:SetBGColor(r, g, b, a)
	local t = self.db.global.Background.Color
	t.r, t.g, t.b, t.a = r, g, b, a
end

function GG:SetBGBorderColor(r, g, b, a)
	local x = self.db.global.Background.BorderColor
	x.r, x.g, x.b, x.a = r, g, b, a
end

function GG:SetMinimap(v) 
    self.db.global.minimap.hide = not v;
	
	if not v then
		self.LDBIcon:Hide(ADDON_NAME);
	else
		self.LDBIcon:Show(ADDON_NAME);
	end
end

function GG:SetResetHour(v) 
	if v < 0 or v > 23 then
		self.db.global.reset_hour = GG_Defaults.global.reset_hour;
	else
		self.db.global.reset_hour = v; 
	end
	
end

function GG:SetDailyResetHour(v) 
	if v < 0 or v > 23 then
		self.db.global.daily_reset_hour = GG_Defaults.global.daily_reset_hour;
	else
		self.db.global.daily_reset_hour = v; 
	end
	
end

function GG:SetResetDayOfWeek(v) 
	if v < 1 or v > 7 then
		self.db.global.reset_dayofweek = GG_Defaults.global.reset_dayofweek
	else
		self.db.global.reset_dayofweek = v
	end 

end

function GG:SetDebug(v) 

	self.db.char.debug = v
	
	if v then 
		self:Print("Entering debug mode")
	else 
		self:Print("Leaving debug mode")
	end

end

function GG:SetLDB(v)
	self.db.global.ldbText = v
	
	if v then
		self.LDBObj.type = 'data source'
	else
		self.LDBObj.type = 'launcher'
		self.LDBObj.text = 'n/a'
	end
	
	self:UpdateLDB(true);
end

function GG:SetVPPaperdoll(v)
	self.db.global.cinfoVP = v
	
	if v then
		PAPERDOLL_STATINFO[L.core.PDVPText] = { updateFunc = function(...) GG:UpdateVPPaperDollFrame(...); end }
	else
		PAPERDOLL_STATINFO[L.core.PDVPText] = nil
	end
end

function GG:SetVPCapPaperdoll(v)
	self.db.global.cinfoVPCap = v
	
	if v then
		PAPERDOLL_STATINFO[L.core.PDVPCapText] = { updateFunc = function(...) GG:UpdateVPCapPaperDollFrame(...); end }
	else
		PAPERDOLL_STATINFO[L.core.PDVPCapText] = nil
	end
end

function GG:SetJPPaperdoll(v)
	self.db.global.cinfoJP = v
	
	if v then
		PAPERDOLL_STATINFO[L.core.PDJPText] = { updateFunc = function(...) GG:UpdateJPPaperDollFrame(...); end }
	else
		PAPERDOLL_STATINFO[L.core.PDJPText] = nil
	end
end

function GG:SetToonFilter(v)

	local data = GG_Storage[self.currentRealm][self.currentPlayer]
	
	if v == nil then 
		data.active = true
	else 
		data.active = v
	end

end

-- Advanced Updates
function GG:UpdateLDB(force, auto)
	
	if self:GetLDB() then
		local label = UnitName('player')
		
		-- Do we really need to update LDB?
		--if force or label ~= self.ldbLabel then
            
            local t = self:GetButtonText()
			if t == nil then t = 'n/a' end
			self:UpdateLDBText(label, t)

			--end
	else
		self.LDBObj.type = 'launcher'
		self.LDBObj.text = 'n/a'
	end
end

function GG:UpdateLDBText(label, txt)
	if not self:GetLDB() then return false end
    
    -- Add the label
    if self:GetLDBlabel() then
        txt = label .. ": " .. txt
    end
    
	self.LDBObj.text = txt
end

function GG:UpdateVPPaperDollFrame(statFrame, unit)
    
	local formatted
	
	--self:SaveData("INIT")
	
	PaperDollFrame_SetLabelAndText(statFrame, L.core.PDVPText, GG_Storage[self.currentRealm][self.currentPlayer].qtyVP, false)
    statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE..L.core.PDVPText..FONT_COLOR_CODE_CLOSE
    if self:GetMaxVP() > 0 then
	  formatted = L.core.PDVPTooltip .. "\n" .. format(L.core.PDVPTooltipMax, self:GetMaxVP())
	else
	  formatted = L.core.PDVPTooltip
    end
    statFrame.tooltip2 = formatted
	
    statFrame:Show()
end

function GG:UpdateVPCapPaperDollFrame(statFrame, unit)
    
	local formatted;
	
	if self:GetPeriodMaxVP() > 0 then
	  formatted = GG_Storage[self.currentRealm][self.currentPlayer].periodEarnVP .. "/" .. self:GetPeriodMaxVP();
	else
	  formatted = GG_Storage[self.currentRealm][self.currentPlayer].periodEarnVP
	end
	
    PaperDollFrame_SetLabelAndText(statFrame, L.core.PDVPCapText, formatted, false)
    statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE..L.core.PDVPCapText..FONT_COLOR_CODE_CLOSE
    if self:GetPeriodMaxVP() > 0 then
	  formatted = L.core.PDVPCapTooltip .. "\n" .. format(L.core.PDVPCapTooltipMax, self:GetPeriodMaxVP())
	else
	  formatted = L.core.PDVPCapTooltip
    end
    statFrame.tooltip2 = formatted
    
    statFrame:Show()
end

function GG:UpdateJPPaperDollFrame(statFrame, unit)
    	
    PaperDollFrame_SetLabelAndText(statFrame, L.core.PDJPText, GG_Storage[self.currentRealm][self.currentPlayer].qtyJP, false);
    statFrame.tooltip = HIGHLIGHT_FONT_COLOR_CODE..L.core.PDJPText..FONT_COLOR_CODE_CLOSE;
    if self:GetMaxJP() > 0 then
	  formatted = L.core.PDJPTooltip .. "\n" .. format(L.core.PDJPTooltipMax, self:GetMaxJP());
	else
	  formatted = L.core.PDJPTooltip;
    end
    statFrame.tooltip2 = formatted;
	
    statFrame:Show();
end

-- Debug function
function GG:Debug(...)
	if self:GetDebug() then
		print('|cFFFF0000GearGrinder Debug:|r ', ...);
	end
end

-- Open the options window
function GG:ShowOptions()
    -- Not using this until a paramiter is added to open expanded
    -- InterfaceOptionsFrame_OpenToCategory(L.core.name);
    
	self:SaveData("INIT");
	
    for i,element in pairs(INTERFACEOPTIONS_ADDONCATEGORIES) do 
        if element.name == L.core.name then
            if not InterfaceOptionsFrame:IsShown() then
                InterfaceOptionsFrame_Show();
                InterfaceOptionsFrameTab2:Click();
            end

            for i,button in pairs(InterfaceOptionsFrameAddOns.buttons) do
                if button.element == element then
                    InterfaceOptionsListButton_OnClick(button);
                    
                    -- Expand
                    if element.hasChildren and element.collapsed then
                        OptionsListButtonToggle_OnClick(button.toggle);
                    end
                
                -- Hide anything else that is open
                elseif button.element and type(button.element.collapsed) == 'boolean' and not button.element.collapsed then
                    OptionsListButtonToggle_OnClick(button.toggle);
                end
            end
        end
    end
end

function GG:CheckCombat(self, eventTime, ...)

	local event, _, _, sourceName, _, _, _, destName = select(1, ...)

	if (GG.InCombat and event == 'UNIT_DIED' and destName == 'Oondasta') then
		--GG:SaveFakeQuestKill(32519)
	end

end

-- Spell cast processing
-- UNIT_SPELLCAST_SUCCEEDED(event, unitID, spellName, rank, lineID, spellID)
function GG:UNIT_SPELLCAST_SUCCEEDED(event, unitID, spellName, rank, lineID, spellID)
  
	-- must be current player
	if unitID ~= "player" then return end
  
	x = FARM_SPELL_ACTION[spellID] 
	if x ~= nil then
		self:SaveFarmData("UNIT_SPELLCAST_SUCCEEDED", x)
	end
end



function GG:ShowHelp()

	GGHelpFrame:Show()

end