-- misc.lua
--


--[[
TODO:


]]

local ADDON_NAME = "GearGrinder";

local L = LibStub("AceLocale-3.0"):GetLocale(ADDON_NAME, true);

function GG:MenuInitialize()
    if not self.GGmenu then
		self.GGmenu = CreateFrame("Frame", "GGMenu")
	end
    
    self.GGmenu.initialize = function(...) GG:MenuShow(...) end;
    
    
    -- Minimap
    self:AddMenuItems('middle', {
        text = L.core.options.minimap,
        func = function() GG:ToggleMinimap(); end,
        checked = function() return GG:GetMinimap(); end,
    }, 1);
    
    -- LDB Text
    self:AddMenuItems('middle', {
        text = L.core.options.ldbSource,
        func = function() GG:ToggleLDBlabel(); end,
        checked = function() return GG:GetLDBlabel(); end,
    }, 1);
end

function GG:MenuOpen()
    local x,y = GetCursorPosition(UIParent);
	ToggleDropDownMenu(1, nil, self.GGmenu, "UIParent", x / UIParent:GetEffectiveScale() , y / UIParent:GetEffectiveScale());
end

function GG:MenuShow(s, level)
    if not level or not tonumber(level) then return end
    
    local info = {};
    local spacer = { disabled = 1, notCheckable = 1 };
    
    if level == 1 then
    
        -- Title / Version
        info.isTitle = 1;
        info.text = L.core.name..' '..GG.version;
        info.notCheckable = 1;
        UIDropDownMenu_AddButton(info, level);
        
        -- Spacer
        UIDropDownMenu_AddButton(spacer, level);
        
        -- Top
        if self:MenuRunItem('top', level) then
            UIDropDownMenu_AddButton(spacer, level);
        end
        
        -- Middle
        if self:MenuRunItem('middle', level) then
            UIDropDownMenu_AddButton(spacer, level);
        end
        
        -- Bottom
        if self:MenuRunItem('bottom', level) then
            UIDropDownMenu_AddButton(spacer, level);
        end   
        
        -- Options
--        wipe(info);
--        info.text = L.core.options.open;
--        info.func = function() GG:ShowOptions(); end;
--        info.notCheckable = 1;
--        UIDropDownMenu_AddButton(info, level);
        
        -- My Score
--        wipe(info);
--        local score, age, items = self:GetScoreTarget('player', true);
--        info.text = format(L.core.scoreYour, GG:FormatScore(score, items));
--        info.notClickable = 1;
--        info.notCheckable = 1;
--        UIDropDownMenu_AddButton(info, level);
        
    elseif tonumber(level) and UIDROPDOWNMENU_MENU_VALUE then
        
        -- Top
        if self:MenuRunItem('top', level, UIDROPDOWNMENU_MENU_VALUE) then
            UIDropDownMenu_AddButton(spacer, level);
        end
        
        if self:MenuRunItem('middle', level, UIDROPDOWNMENU_MENU_VALUE) then
            UIDropDownMenu_AddButton(spacer, level);
        end
        
        self:MenuRunItem('bottom', level, UIDROPDOWNMENU_MENU_VALUE);
    end
end

function GG:MenuRunItem(where, level, parent)
    where = strlower(where);
    local lev = level;
    
    if level and parent then
        level = level..'-'..parent;
    end
    
    local foundSomething = false;
    
    if self.menuItems[where] and self.menuItems[where][level] then
        for a,info in pairs(self.menuItems[where][level]) do
            
            -- Run functions for a name
            if info.textFunc and type(info.textFunc) == 'function' then
                info.text = info.textFunc(where, lev, parent);
            end
            
            local enabled = true;
            
            if info.enabled and type(info.enabled) == 'function' then
                enabled = info.enabled();
            end
            
            if enabled then
                UIDropDownMenu_AddButton(info, lev);
                foundSomething = true;
            end
        end
    end
    
    return foundSomething;
end

--[[ 
    For what info is see "List of button attributes"
    - http://wowprogramming.com/utils/xmlbrowser/live/FrameXML/UIDropDownMenu.lua
    
    Additional Options:
    info.textFunc = function(where, level, parent); this is ran to update info.text when the menu is shown
    info.enabled = function(where, level, parent); this is backwards, but if enabled is present then it is ran to see if the item should be shown
]]
function GG:AddMenuItems(where, info, level, parent)
    if not where and not info and not self.menuItems[where] and type(info) ~= 'table' then return end;
    where = strlower(where);
    level = level or 1;
    
    if parent then
        level = level..'-'..parent;
    end
    
    if not self.menuItems[where][level] then
        self.menuItems[where][level] = {};
    end
    
    table.insert(self.menuItems[where][level], info);
end

--[[
        Random Methods
]]
-- from http://www.wowpedia.org/Round
function GG:Round(number, decimals)
    return (("%%.%df"):format(decimals)):format(number);
end

-- from http://www.wowpedia.org/RGBPercToHex
function GG:RGBtoHex(r, g, b)
	r = r <= 1 and r >= 0 and r or 0
	g = g <= 1 and g >= 0 and g or 0
	b = b <= 1 and b >= 0 and b or 0
	return string.format("%02x%02x%02x", r*255, g*255, b*255)
end


function GG:CanOfficerChat()
	GuildControlSetRank(select(3,GetGuildInfo("player")));
	local flags = self:Flags2Table(GuildControlGetRankFlags());
	return flags[4];
end

function GG:Flags2Table(...)
	local ret = {}
	for i = 1, select("#", ...) do
		if (select(i, ...)) then
			ret[i] = true;
		else
			ret[i] = false;
		end
	end
	return ret;
end

-- Play around with to test how color changes will work
function GG:ColorTest(l,h)
	for i = l,h do
		self:Print(self:FormatScore(i));
	end
end

-- Sorted Table Functions
--[[
Ordered table iterator, allow to iterate on the natural order of the keys of a
table.

Example:
]]

function __genOrderedIndex( t )
    local orderedIndex = {}
    for key in pairs(t) do
        table.insert( orderedIndex, key )
    end
    table.sort( orderedIndex )
    return orderedIndex
end

function orderedNext(t, state)
    -- Equivalent of the next function, but returns the keys in the alphabetic
    -- order. We use a temporary ordered key table that is stored in the
    -- table being iterated.

    --print("orderedNext: state = "..tostring(state) )
    if state == nil then
        -- the first time, generate the index
        t.__orderedIndex = __genOrderedIndex( t )
        key = t.__orderedIndex[1]
        return key, t[key]
    end
    -- fetch the next value
    key = nil
    for i = 1,table.getn(t.__orderedIndex) do
        if t.__orderedIndex[i] == state then
            key = t.__orderedIndex[i+1]
        end
    end

    if key then
        return key, t[key]
    end

    -- no more value to return, cleanup
    t.__orderedIndex = nil
    return
end

function orderedPairs(t)
    -- Equivalent of the pairs() function on tables. Allows to iterate
    -- in order
    return orderedNext, t, nil
end


function table.set(t) -- set of list
  local u = { }
  for _, v in ipairs(t) do u[v] = true end
  return u
end

function table.find(f, l) -- find element v of l satisfying f(v)
  for _, v in ipairs(l) do
    if f(v) then
      return v
    end
  end
  return nil
end

function table.contains(t, e)
  for _, v in pairs(t) do
    if v == e then
      return true
    end
  end
  return false
end

function pairsByKeys (t, f)
  local a = {}
  for n in pairs(t) do table.insert(a, n) end
  table.sort(a, f)
  local i = 0      -- iterator variable
  local iter = function ()   -- iterator function
	i = i + 1
	if a[i] == nil then return nil
	else return a[i], t[a[i]]
	end
  end
  return iter
end


