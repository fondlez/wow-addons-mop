-- Geist, by Cidrei (Jazrei of Zangarmarsh-US)

-- Local Table
local aName, aTable = ...

-- OnEvent
function aTable.OnEvent(self, event, ...)
	if ( event == "ADDON_LOADED" ) then
		local addonName = ...
		if ( not addonName or (addonName and addonName ~= "Geist") ) then
			return;
		end
		SLASH_GEIST1 = "/geist"
		SLASH_GEIST2 = "/gbm" -- Legacy commands ftw.
		SlashCmdList["GEIST"] = aTable.ChatCommandHandler

		aTable.SavedVars()
		aTable.Create()
		aTable.SetScale(Geist["Scale"])
		aTable.DisplayGuide()
	elseif ( event == "PLAYER_LOGIN" ) then
		aTable.Masque()
	end
end

-- Saved variables
function aTable.SavedVars()
	if Geist == nil then
		Geist = {}
	end

	if Geist["Scale"] == nil then
		Geist["Scale"] = 1
	end

	if Geist["ButtonIDs"] == nil then
		Geist["ButtonIDs"] = {}
		local _, class = UnitClass("player")

		if class == "DRUID" then
			Geist["ButtonIDs"] = aTable.ButtonIDs["DRUID"]
		elseif class == "WARRIOR" or class == "MONK" then
			Geist["ButtonIDs"] = aTable.ButtonIDs["WARRIOR"]
		else
			Geist["ButtonIDs"] = aTable.ButtonIDs["DEFAULT"]
		end
	end

	if Geist["Buttons"] == nil then
		Geist["Buttons"] = 25
	end

end

-- Masque
function aTable.Masque()
	local Masque = LibStub('Masque', true)
	if Masque then
		myGroup = Masque:Group("Geist", "Buttons")
		for i = 1, Geist["Buttons"] do
			myGroup:AddButton(aTable.Buttons[i])
		end
	end
end

-- Guide
function aTable.DisplayGuide()
	for i = 1, Geist["Buttons"] do
		if Geist["Guide"] then
			aTable.Buttons[i].title:Show()
		else
			aTable.Buttons[i].title:Hide()
		end
	end
end

-- Scale
function aTable.SetScale(scale)
	if GeistHeader then
		GeistHeader:SetScale(scale)
		Geist["Scale"] = scale
	else
		return
	end
end

function aTable.ResetScale()
	if(GetCVar("useUiScale") == "0") then	
		Geist["Scale"] = 1
	else
		Geist["Scale"] = GetCVar("uiscale")
		GeistHeader:SetScale(GetCVar("uiscale"))
	end
end

-- Toggle
function aTable.ToggleOn()
	GeistHeader:RegisterForClicks("AnyDown")
	GeistHeader:SetAttribute("_onclick", [[
		self:SetPoint("CENTER", "$cursor")

		if self:IsVisible() then
			self:Hide()
		else
			self:Show()
		end]]
	)
end

function aTable.ToggleOff()
	GeistHeader:Hide()
	GeistHeader:RegisterForClicks("AnyDown","AnyUp")
	GeistHeader:SetAttribute("_onclick", [[
		self:SetPoint("CENTER", "$cursor")

		if down then
			self:Show()
		else
			self:Hide()
		end]]
	)
end

-- Chat output
function aTable.Print(msg) 
	if not DEFAULT_CHAT_FRAME then
		return
	end

	DEFAULT_CHAT_FRAME:AddMessage(msg)
end

-- Local event frame
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", aTable.OnEvent)
