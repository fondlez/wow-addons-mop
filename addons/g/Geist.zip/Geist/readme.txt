Geist - Quick mouse access for up to 25 buttons.
by Cidrei (Jazrei of Zangarmarsh-US)
---

How to use:
-- Bind a key to Geist. Geist will display whenever that key is pressed with the cursor over the center button.

Code Credit:
-- Tepel, for most of the toggle command code.
-- Hannesz, for providing the deDE locale file. First ever translation!
-- Alestane and Iriel for information and examples on the new secure frames.
-- All the mod authors whose code I've learned and borrowed from. I've looked through a lot of addons, and they've really helped.
-- www.wowpedia.org, for the excellent documentation of the WoW API.

Recognition:
-- oofnish (Chase Grund), the author of Ghost Bar. There wouldn't have been a GhostBarMod or Geist without the original.