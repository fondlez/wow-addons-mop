# MoP-GnomishVendorShrinker
GnomishVendorShrinker for Mists of Pandaria 5.4.8

Official Version 5.0.1.15 by Tekkub, few minor issues fixed by me.

Original link: https://www.curseforge.com/wow/addons/gnomishvendorshrinker

![image](https://user-images.githubusercontent.com/17107410/148385828-2b03e550-c8e4-41e8-86e9-5da2d8ac61bf.png)
