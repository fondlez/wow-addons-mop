local _, Sequences = ... -- Don't touch this

----
-- Rename this file to Sequences.lua before you get started, it uses a different file name so as not to overwrite your existing file with a future update.
-- Every entry in the Sequences table defines a single sequence of macros which behave similarly to /castsequence.
-- Sequence names must be unique and contain no more than 16 characters.
-- To use a macro sequence, create a blank macro in-game with the same name you picked for the sequence here and it will overwrite it.
----

----
-- Here's a large demonstration sequence documenting the format:
Sequences["GnomeExample1"] = {
	-- StepFunction optionally defines how the step is incremented when pressing the button.
	-- This example increments the step in the following order: 1 12 123 1234 etc. until it reaches the end and starts over
	-- DO NOT DEFINE A STEP FUNCTION UNLESS YOU THINK YOU KNOW WHAT YOU'RE DOING
	StepFunction = [[
		limit = limit or 1
		if step == limit then
			limit = limit % #macros + 1
			step = 1
		else
			step = step % #macros + 1
		end
	]],
	
	-- PreMacro is optional macro text that you want executed before every single button press.
	-- This is if you want to add something like /startattack or /stopcasting before all of the macros in the sequence.
	PreMacro = [[
/run print("-- PreMacro Script --")
/startattack	
	]],
	
	-- PostMacro is optional macro text that you want executed after every single button press.
	-- I don't know what you would need this for, but it's here anyway.
	PostMacro = [[
/run print("-- PostMacro Script --")
	]],
	
	-- Macro 1
	[[
/run print("Executing macro 1!")
/cast SpellName1
	]],
	
	-- Macro 2
	[[
/run print("Executing macro 2!")
/cast SpellName2
	]],
	
	-- Macro 3
	[[
/run print("Executing macro 3!")
/cast SpellName3
	]],
}

----
-- Here is a short example which is what most sequences will look like
Sequences["GnomeExample2"] = {	
	-- Macro 1
	[[
/run print("Executing macro 1!")
/cast SpellName1
	]],
	
	-- Macro 2
	[[
/run print("Executing macro 2!")
/cast SpellName2
	]],
	
	-- Macro 3
	[[
/run print("Executing macro 3!")
/cast SpellName3
	]],
}

Sequences["Arms"] = {
StepFunction = [[
	limit = limit or 1
	if step == limit then
		limit = limit % #macros + 1
		step = 1
	else
		step = step % #macros + 1
	end
]],
PreMacro = [[
/targetenemy [noharm][dead]
/cast Charge
/cast avatar
]],
    '/cast [nochanneling] Slam',        
    '/cast [nochanneling] Mortal strike',
    '/cast [nochanneling] Overpower',
    '/cast [nochanneling] !colossus smash',
    '/castsequence [nochanneling]reset=3/target Cleave,Whirlwind',   
PostMacro = [[
/startattack
/cast [combat] Battle Cry
/run UIErrorsFrame:Clear()
]],
}

Sequences['ENLegion'] = {
PreMacro = [[
/targetenemy [noharm][dead]
/startattack
/petattack
/console Sound_EnableSFX 0
]],
	'/castsequence [nochanneling]!Rockbiter,!Lava Lash,!frostbrand,!Lava Lash,!frostbrand',
	'/castsequence [nochanneling]reset=6/target !Crash Lightning',
	'/castsequence [nochanneling]reset=8.2/target Lightning Bolt',
	'/castsequence [nochanneling]reset=11/target !Flametongue',
	'/castsequence [nochanneling]reset=15/target !Stormstrike',
	'/castsequence [nochanneling]reset=45/target !windsong',
	'/castsequence [nochanneling]reset=120/target !Feral Spirit',
	'/castsequence [nochanneling]reset=300/target !ascendance',
	'/cast !stormstrike',
PostMacro = [[
/cast [combat] Blood Fury
/run UIErrorsFrame:Hide()
/console Sound_EnableSFX 1
]],
}

Sequences['enhST'] = {
	StepFunction = [[
		stepa = "12123123412345"

		limit = string.len(stepa) or 1
		if stepc == nil then
			stepc = 1
		end
		if stepc >= limit then
			stepc = 1
		else
			stepc = stepc + 1
		end
		step = tonumber(strsub (stepa, stepc, stepc))
	]],
PreMacro = [[
/targetenemy [noharm][dead]
/run sfx=GetCVar("Sound_EnableSFX");
/console Sound_EnableSFX 0
]],
	'/castsequence Boulderfist',
	'/cast Stormstrike',
	'/cast Crash Lightning', 
	'/castsequence Flametongue',
	'/cast Feral Spirit',
PostMacro = [[
/startattack
/use [combat] 11
/use [combat] 12
/cast [combat] Doom Winds
/cast [combat] Astral Shift
/run UIErrorsFrame:Clear()
/script UIErrorsFrame:Hide();
/console Sound_EnableSFX 1
]],
}

Sequences['MMboss'] = {
author = "Kirr",
helpTxt = "Talent: 1113121",
StepFunction =  [[
	limit = limit or 1
	if step == limit then
		limit = limit % #macros + 1
		step = 1
	else
		step = step % #macros + 1
	end
]], 
PreMacro = [[
/targetenemy [noharm][dead]
/cast [combat,nochanneling] !Blood Fury
/console Sound_EnableSFX 0
]],
        '/cast [nochanneling] Sidewinders',
	'/cast [nochanneling] Marked Shot',
	'/cast [nochanneling] Aimed Shot',
PostMacro = [[
/startattack
/script UIErrorsFrame:Clear();
/console Sound_EnableSFX 1
]],
}