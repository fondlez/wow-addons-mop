local GearingGuide = LibStub("AceAddon-3.0"):GetAddon("Gearing Guide")

function GearingGuide:PriorityTable ()
	local tablePrio = {}
	tablePrio = {
	{class = "Death Knight", spec = "Blood", Stamina = 5, Strength = 5, Agility = -5, Intellect = -5, mastery = 2, critical = -3, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = 1, parry = 1, prio = 0},
	{class = "Death Knight", spec = "Frost DW", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 2, critical = 1, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Death Knight", spec = "Frost 2H", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = 2, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},	
	{class = "Death Knight", spec = "Unholy", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = 2, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},

	{class = "Druid", spec = "Balance", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 0, critical = 1, haste = 2, hit = 1, expertise = 0, spirit = 1, dodge = -10, parry = -10, prio = 0},
	{class = "Druid", spec = "Feral", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 2, critical = 1, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Druid", spec = "Guardian", Stamina = 5, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = 1, parry = 0, prio = 0},
	{class = "Druid", spec = "Restoration", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 1, critical = 0, haste = 2, hit = 0, expertise = 0, spirit = 2, dodge = -10, parry = -10, prio = 0},
	
	{class = "Hunter", spec = "Beast Mastery", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Hunter", spec = "Marksman", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Hunter", spec = "Survival", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	
	{class = "Mage", spec = "Arcane", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 2, critical = 0, haste = 1, hit = 1, expertise = 0, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Mage", spec = "Fire", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 0, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Mage", spec = "Frost", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 1, critical = 0, haste = 2, hit = 1, expertise = 0, spirit = -10, dodge = -10, parry = -10, prio = 0},	
	
	{class = "Monk", spec = "Brewmaster", Stamina = 5, Strength = -5, Agility = 3, Intellect = -5, mastery = 2, critical = 1, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = 1, parry = 1, prio = 0},
	{class = "Monk", spec = "Mistweaver", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 0, critical = 1, haste = 2, hit = 0, expertise = 0, spirit = 2, dodge = -10, parry = -10, prio = 0},
	{class = "Monk", spec = "Windwalker DW", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Monk", spec = "Windwalker 2H", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 2, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	
	{class = "Paladin", spec = "Holy", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 2, critical = 0, haste = 1, hit = 0, expertise = 0, spirit = 2, dodge = -10, parry = -10, prio = 0},
	{class = "Paladin", spec = "Protection", Stamina = 5, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = -3, haste = 2, hit = 1, expertise = 1, spirit = -10, dodge = 1, parry = 1, prio = 0},
	{class = "Paladin", spec = "Retribution", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = 0, haste = 2, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	
	{class = "Priest", spec = "Discipline", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 1, critical = 2, haste = 0, hit = 0, expertise = 0, spirit = 2, dodge = -10, parry = -10, prio = 0},
	{class = "Priest", spec = "Holy", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 2, critical = 1, haste = 0, hit = 0, expertise = 0, spirit = 2, dodge = -10, parry = -10, prio = 0},
	{class = "Priest", spec = "Shadow", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 1, critical = 1, haste = 2, hit = 1, expertise = 0, spirit = 1, dodge = -10, parry = -10, prio = 0},	
	
	{class = "Rogue", spec = "Assassination", Stamina = 0, Strength = -5, Agility = 5, Intellect = 0, mastery = 2, critical = 0, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},	
	{class = "Rogue", spec = "Combat", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 1, critical = 1, haste = 2, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Rogue", spec = "Subtlety", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 0, critical = 1, haste = 2, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	
	{class = "Shaman", spec = "Elemental", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 2, critical = 0, haste = 1, hit = 1, expertise = 0, spirit = 1, dodge = -10, parry = -10, prio = 0},
	{class = "Shaman", spec = "Enhancement", Stamina = 0, Strength = -5, Agility = 5, Intellect = -5, mastery = 2, critical = 0, haste = 1, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Shaman", spec = "Restoration", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 0, critical = 1, haste = 2, hit = 0, expertise = 0, spirit = 2, dodge = -10, parry = -10, prio = 0},
	
	{class = "Warlock", spec = "Affliction", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 2, critical = 0, haste = 1, hit = 1, expertise = 0, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Warlock", spec = "Demonology", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 1, critical = 1, haste = 2, hit = 1, expertise = 0, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Warlock", spec = "Destruction", Stamina = 0, Strength = -5, Agility = -5, Intellect = 5, mastery = 2, critical = 0, haste = 1, hit = 1, expertise = 0, spirit = -10, dodge = -10, parry = -10, prio = 0},

	{class = "Warrior", spec = "Arms", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = 2, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Warrior", spec = "Fury 1H", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = 2, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Warrior", spec = "Fury 2H", Stamina = 0, Strength = 5, Agility = -5, Intellect = -5, mastery = 1, critical = 2, haste = 0, hit = 1, expertise = 1, spirit = -10, dodge = -10, parry = -10, prio = 0},
	{class = "Warrior", spec = "Protection", Stamina = 5, Strength = 5, Agility = -5, Intellect = -5, mastery = 0, critical = -3, haste = -3, hit = 1, expertise = 1, spirit = -10, dodge = 1, parry = 2, prio = 0}
	}

	return tablePrio
end