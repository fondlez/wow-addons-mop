GearingGuide = LibStub("AceAddon-3.0"):NewAddon("Gearing Guide", "AceEvent-3.0", "AceConsole-3.0", "AceComm-3.0")

AceGUI = LibStub("AceGUI-3.0")
local TipHooker = LibStub("LibTipHooker-1.1")

local libS = LibStub:GetLibrary("AceSerializer-3.0")
local libC = LibStub:GetLibrary("LibCompress")
local libCE = libC:GetAddonEncodeTable()

local epgpEnable
local groupEnable
local masterlootEnable

myOptions = {
  name = "Global Options",
  type = "group",
  args = {
	wish = {
	  name = "Wish List",
	  desc = "Opens the Wish List, to set up the list of items to look out for",
	  type = "execute",
	  func = function() WishListFrame() end
	},
	enable = {
		name = "Addon",
		desc = "Enables / Disables the addon",
		type = "toggle",
		set = function(info,val) if (val) then GearingGuide:Enable() else GearingGuide:Disable() end GearingGuide.enabled = val end,
		get = function(info) return GearingGuide.enabled end
	},
	group = {
		name = "Groups",
		desc = "Enables / Disables the addon for groups",
		type = "toggle",
		set = function(info,val) GearingGuide.db.profile.groupEnable = val end,
		get = function(info) return GearingGuide.db.profile.groupEnable end
	},
	masterloot = {
		name = "MasterLooter",
		desc = "Enables / Disables the addon for Master Looter tracking",
		type = "toggle",
		set = function(info,val) GearingGuide.db.profile.masterlootEnable = val end,
		get = function(info) return GearingGuide.db.profile.masterlootEnable end
	},
	green = {
		name = "Uncommon Drops",
		desc = "Enables / Disables uncommon loot from showing at max level",
		type = "toggle",
		set = function(info,val) GearingGuide.db.profile.greens = val end,
		get = function(info) return GearingGuide.db.profile.greens end
	},
	showself = {
		name = "Compare only player",
		desc = "Shows only players class and specs for the item",
		type = "toggle",
		set = function(info,val) if (val) then GearingGuide.db.profile.classShow = "self" end end,
		get = function(info) if (GearingGuide.db.profile.classShow == "self") then return true end end
	},
	showall = {
		name = "Compare all Classes",
		desc = "Shows every class and spec for the item",
		type = "toggle",
		set = function(info,val) if (val) then GearingGuide.db.profile.classShow = "all" end end,
		get = function(info) if (GearingGuide.db.profile.classShow == "all") then return true end end
	},
	epgpprices = {
		name = "Settings",
		type = "group",
		args = {
			customValues = {
				name = "Custom Values",
				desc = "Enables / Disables the addon using Custom Values",
				type = "toggle",
				set = function(info,val) GearingGuide.db.profile.inGuild = val end,
				get = function(info) return GearingGuide.db.profile.inGuild end
			},
			customName = {
				name = "Enter Loot System Name",
				desc = "Enter the name of the Loot system you use with a Fixed Price System",
				type = "input",
				set = function(info,val) GearingGuide.db.profile.system = val end,
				get = function(info) return GearingGuide.db.profile.system end
			},
			epgp = {
			  name = "EPGP Prices",
			  desc = "Enables / Disables the addon showing the EPGP Prices according to the EPGP wiki",
			  type = "toggle",
			  set = function(info,val) GearingGuide.db.profile.epgpEnable = val end,
			  get = function(info) return GearingGuide.db.profile.epgpEnable end
			},
			values = {
				name = "Custom Prices",
				type = "group",
				args = {
					helm = {
						name = "Helmet Price",
						desc = "Input the custom Helmet Price (including Tokens)",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.HelmGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.HelmGP) end
					},
					neck = {
						name = "Neck Price",
						desc = "Input the custom Neck Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.NeckGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.NeckGP) end
					},
					shoulder = {
						name = "Shoulders Price",
						desc = "Input the custom Shoulders Price (including Tokens)",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.ShouldersGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.ShouldersGP) end
					},
					cloak = {
						name = "Cloak Price",
						desc = "Input the custom Cloak Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.CloakGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.CloakGP) end
					},
					chest = {
						name = "Chest Piece Price",
						desc = "Input the custom Chest Piece Price (including Tokens)",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.ChestGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.ChestGP) end
					},
					wrist = {
						name = "Wrist Price",
						desc = "Input the custom Wrist Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.WristGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.WristGP) end
					},
					glove = {
						name = "Gloves Price",
						desc = "Input the custom Gloves Price (including Tokens)",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.GlovesGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.GlovesGP) end
					},
					waist = {
						name = "Waist Price",
						desc = "Input the custom Waist Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.WaistGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.WaistGP) end
					},
					legs = {
						name = "Leg Piece Price",
						desc = "Input the custom Legs Piece Price (including Tokens)",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.LegsGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.LegsGP) end
					},
					boots = {
						name = "Boots Price",
						desc = "Input the custom Boots Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.BootsGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.BootsGP) end
					},
					ring = {
						name = "Ring Price",
						desc = "Input the custom Ring Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.RingGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.RingGP) end
					},
					trinket = {
						name = "Trinket Price",
						desc = "Input the custom Trinket Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.TrinketGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.TrinketGP) end
					},
					mainhand = {
						name = "Mainhand Weapon Price",
						desc = "Input the custom Mainhand Weapon Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.MainhandGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.MainhandGP) end
					},
					offhand = {
						name = "Offhand Price",
						desc = "Input the custom Offhand (Weapons/Shields) Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.OffhandGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.OffhandGP) end
					},
					twohand = {
						name = "Two Handed Weapon Price",
						desc = "Input the custom Two Handed Weapon Price",
						type = "input",
						set = function(info,val) GearingGuide.db.profile.custom.WeaponGP = val end,
						get = function(info) return tostring(GearingGuide.db.profile.custom.WeaponGP) end
					},
				},
			},
		},
	},
  }
}

local AceConfig = LibStub("AceConfig-3.0")
AceConfig:RegisterOptionsTable("Gearing Guide", myOptions)
LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Gearing Guide")

local VERSION = "1.3.43"
local MaxLevel = 90
local frame
local slotID
local sName
local sLink
local iRarity
local iLevel = 0
local dropppediLevel
local sType
local sSubType
local sEquip
local sTexture
local RsName
local RsLink
local RiRarity
local RiLevel
local RdropppediLevel
local RsType
local RsSubType
local RsEquip
local RsTexture
local statsTable = {}
local tablePrio = {}
local iEPGPCost
local primaryStat
local stats = {}
local comparing = false
local compareGroup
local typeOfItem
local typeOfItem1
local isLockbox = false
local MLEPGPCost
local LootSystem
local droppedItems = {}
local droppedIDs = {}
local numberDrops = 0
local tab
local MLTablePrio = {}
local lineAdded = false
local MLsTexture
local isOpen = false
local wishText
local dropID
local classesTable = {}
local isRaidLooter = false
local isPreLevel40 = false
local tooltipPrios = {}

local defaults = {
  profile = {
	droppedItemLink = "",
	isOpen = false,
	inGuild = false,
	system = "EPGP",
	groupEnable = true,
	masterlootEnable = true,
	epgpEnable = false,
	point = "CENTER",
	relPoint = "CENTER",
	x = 0,
	y = 0,
	greens = true,
	classShow = "self",
		epgp = {
			HelmGP = 1,
			NeckGP = 0.55,
			ShouldersGP = 0.777,
			CloakGP = 0.55,
			ChestGP = 1,
			WristGP = 0.777,
			GlovesGP = 0.777,
			WaistGP = 0.777,
			LegsGP = 1,
			BootsGP = 0.777,
			RingGP = 0.55,
			TrinketGP = 0.7,
			MainhandGP = 0.42,
			OffhandGP = 0.55,
			WeaponGP = 1,
		},
		custom = {
			HelmGP = 2250,
			NeckGP = 1250,
			ShouldersGP = 1750,
			CloakGP = 1250,
			ChestGP = 2250,
			WristGP = 1250,
			GlovesGP = 1750,
			WaistGP = 1750,
			LegsGP = 2250,
			BootsGP = 1750,
			RingGP = 1250,
			TrinketGP = 1750,
			MainhandGP = 2450,
			OffhandGP = 950,
			WeaponGP = 3400,
		},
		wishlist = {
			items = {},
		},
	}
}

function GearingGuide:OnInitialize()
	GearingGuide.enabled = true
	local guildName = GetGuildInfo(UnitName("player"))
	droppedIDs = {}
	self.db = LibStub("AceDB-3.0"):New("GearingGuideDB1", defaults)
	
	GearingGuide.db.profile.isOpen = false

	GearingGuide:RegisterChatCommand("", "ChatCommand")

	tooltipPrios = {}
	--GearingGuide:RegisterEvent("PLAYER_ENTERING_WORLD", test)
end

	local LOOT_SELF_REGEX = gsub(LOOT_ITEM_SELF, "%%s", "(.+)")
	local LOOT_REGEX = gsub(LOOT_ITEM, "%%s", "(.+)")

function GearingGuide:OnEnable()
	if (GearingGuide.db.profile.groupEnable) then
		GearingGuide:RegisterEvent("START_LOOT_ROLL")
	end
	if (GearingGuide.db.profile.masterlootEnable) then		
		GearingGuide:RegisterEvent("OPEN_MASTER_LOOT_LIST")
	end
	GearingGuide:RegisterComm("LootingGuideNI")
	
	Pre_WoW_Rollonloot = RollOnLoot
	RollOnLoot = LootRoll
end

function GearingGuide:ChatCommand(input)
	if not input or input:trim() == "" then
		LibStub("AceConfigDialog-3.0"):Open("Gearing Guide")
	elseif input == "enable" then
		GearingGuide:Enable()
		GearingGuide:Print("Gearing Guide is now Enabled")
	elseif input == "disable" then
		GearingGuide:Disable()
		GearingGuide:Print("Gearing Guide is now Disabled")
	end
end

function GearingGuide.START_LOOT_ROLL(_,_,id)
	MLsTexture = nil 
	MLEPGPCost = nil
	local droppedItemID = GetLootRollItemLink(id)	
	sName, sLink, iRarity, dropppediLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(droppedItemID)

	CreateGuide(droppedItemID)
end

function GearingGuide.OPEN_MASTER_LOOT_LIST()
	local droppedItemID = GetLootSlotLink(LootFrame.selectedSlot)
	
	sName, sLink, iRarity, dropppediLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(droppedItemID)
	isRaidLooter = true
	CreateGuide (droppedItemID)
	isRaidLooter = false
end

function GearingGuide.OnTooltipSetItem(tooltip, ...)
	local _, linkTool = tooltip:GetItem()
	if (IsEquippableItem(linkTool) ~= nil) then
		sName, sLink, iRarity, dropppediLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(linkTool)

		if (tablelength(tooltipPrios) > 0) then
			table.wipe(tablePrio)
			for _, v in ipairs(tooltipPrios) do				
				if (v.Link == sLink) then
					table.insert(tablePrio, {class = v.class, spec = v.spec, Stamina = v.Stamina, Strength = v.Strength, Agility = v.Agility, Intellect = v.Intellect, mastery = v.mastery, critical = v.critical, haste = v.haste, hit = v.hit, expertise = v.expertise, spirit = v.spirit, dodge = v.dodge, parry = v.parry, prio = v.prio})
				end
			end

			if (tablelength(tablePrio) > 0) then
				AddTooltip(tooltip)
			else
				NewTooltip(tooltip)	
			end
		else
			NewTooltip(tooltip)	
		end

	end
end

function NewTooltip(tooltip)
	ToolTipScanner(true)
	tablePrio = GearingGuide:PriorityTable()			
	stats = GetItemStats(sLink, statsTable)
	WorkoutPrimary()
	iLevel = dropppediLevel
	EquipPrioSelf()
	sort(tablePrio, function(a,b) return a.prio > b.prio end)

	local minusPrio = 0
	for i, value in ipairs(tablePrio) do
		if ( value.prio > 14  and minusPrio == 0) then
			minusPrio = value.prio - 14
		end
		if ( minusPrio > 0 ) then
			value.prio = value.prio - minusPrio
		end
	end

	table.wipe(tooltipPrios)
	for _, v in ipairs(tablePrio) do
		if (v.prio > 4) then		
			table.insert(tooltipPrios, {Link = sLink, class = v.class, spec = v.spec, Stamina = v.Stamina, Strength = v.Strength, Agility = v.Agility, Intellect = v.Intellect, mastery = v.mastery, critical = v.critical, haste = v.haste, hit = v.hit, expertise = v.expertise, spirit = v.spirit, dodge = v.dodge, parry = v.parry, prio = v.prio})
		end
	end

	AddTooltip(tooltip)

	table.wipe(classesTable)
	table.wipe(stats)
	table.wipe(tablePrio)
end

function AddTooltip(tooltip)
	local setColorR = 0
	local setColorG = 0
	local setColorB = 0
	for _, v in ipairs(tablePrio) do				
		if (v.prio > 4) then
			if (v.prio > 13) then
				setColorR = 1.0
			elseif (v.prio == 13) then
				setColorR = 1.0
				setColorG = 0.2
			elseif (v.prio == 12) then
				setColorR = 1.0
				setColorG = 0.4
			elseif (v.prio == 11) then
				setColorR = 1.0
				setColorG = 0.6
			elseif (v.prio == 10) then
				setColorR = 1.0
				setColorG = 0.8
			elseif (v.prio == 9) then
				setColorR = 1.0
				setColorG = 1.0
			elseif (v.prio == 8) then
				setColorR = 0.2
				setColorG = 1.0
			elseif (v.prio == 7) then
				setColorG = 1.0					
				setColorB = 0.2
			elseif (v.prio == 6) then
				setColorG = 1.0
				setColorB = 0.4
			elseif (v.prio == 5) then
				setColorG = 1.0
				setColorB = 0.6
			end

			if( setColorR == 0 and setColorG == 0 and setColorB == 0 ) then
				setColorR = 1
				setColorG = 1
				setColorB = 1
			end

			tooltip:AddLine("Gearing Guide: "..v.prio.." - "..v.spec.." "..v.class, setColorR, setColorG, setColorB)					
			--  Thank You Rating Buster for the next code, I couldn't get it in the tooltip without this

			local tipTextLeft = tooltip:GetName().."TextLeft"
			tooltip:Show()
			for i = 2, tooltip:NumLines() do
				local fontString = _G[tipTextLeft..i] 
				_, relativeTo, _, xOfs, _ = fontString:GetPoint(0)
				fontString:ClearAllPoints()
				fontString:SetPoint("TOPLEFT",relativeTo, "BOTTOMLEFT", xOfs, -2)
			end
		end
	end
end

TipHooker:Hook(GearingGuide.OnTooltipSetItem, "item")

function LootRoll(Rollid, roll)
	if GearingGuide.db.profile.isOpen then
		numberDrops = numberDrops - 1
		if (numberDrops == 0) then
			SaveFramePosition()
			GearingGuide.db.profile.isOpen = false
			ClearTables()
			 
			AceGUI:Release(frame)					
		end
	end
	Pre_WoW_Rollonloot(Rollid, roll)
end

function GearingGuide:CHAT_MSG_LOOT(n, lootmsg)
    if GearingGuide.db.profile.isOpen then
		local _, _, sPlayer, ditemlink = string.find(lootmsg, LOOT_REGEX)
		if not sPlayer then _, _, ditemlink = string.find(lootmsg, LOOT_SELF_REGEX) end
		if not ditemlink then return end
		if (ditemlink == GearingGuide.db.profile.droppedItemLink) then
			SaveFramePosition()
			GearingGuide.db.profile.isOpen = false
			ClearTables()
			
			MLsTexture = nil
			MLEPGPCost = nil
			AceGUI:Release(frame)						
		end
	end
end

function ClearTables()
	if (GearingGuide.db.profile.isOpen == false) then
		table.wipe(droppedIDs)
		table.wipe(droppedItems)
		table.wipe(tablePrio)
	end
end

function test()
	--local id = 95139
	local id = 81136
	GearingGuide:Print(GearingGuide.db.profile.classShow);		
	sName, sLink, iRarity, dropppediLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(id)
	CreateGuide(id)
end

function CreateGuide(droppedItemID)
	if ((iRarity == 2 and GearingGuide.db.profile.greens) or (UnitLevel("player") ~= MaxLevel) or iRarity > 2) then
		if (sType == "Armor" or sType == "Weapon" or (sType == "Miscellaneous" and sSubType == "Junk" and dropppediLevel > 69)) then
			local a, b = strsplit(" ", sName, 2)
			if (b == "Lockbox" or b == "Iron Lockbox") then
				isLockbox = true
			end
			if (isLockbox == false) then
				table.insert(droppedIDs, sLink)
				local i = tablelength(droppedItems)
				table.insert(droppedItems, {value = i, text = sName})
				GearingGuide.db.profile.droppedItemLink = droppedItemID
				ItemSelect(droppedItemID)
				WorkOutEPGP()
				WorkoutPrimary()
				local count = 0

				if (isRaidLooter) then
					local table = libS:Serialize(tablePrio)
					local data = GearingGuide.db.profile.system.."/"..iEPGPCost.."/"..sName.."/"..sLink.."/"..iRarity.."/"..dropppediLevel.."/"..sType.."/"..sSubType.."/"..sEquip.."/"..sTexture.."/"..table
					local serial = libS:Serialize(data)
					local compress = libC:Compress(serial)
					local sendMessage = libCE:Encode(compress)
					GearingGuide:SendCommMessage("LootingGuideNI", sendMessage, "RAID")
				end

				if (GearingGuide.db.profile.classShow == "self") then 
					EquipPrioSelf()
					for _, v in ipairs(tablePrio) do
						if (v.prio > 4) then
							count = count + 1
							ActivatePrint()
							tab:SelectTab(0)
							GearingGuide:RegisterEvent("CHAT_MSG_LOOT")
						end
					end
					if (count == 0 and GearingGuide.db.profile.isOpen ~= true) then
						ClearTables()
					end 
				else
					ActivatePrint()
					tab:SelectTab(0)
					GearingGuide:RegisterEvent("CHAT_MSG_LOOT")
					ClearTables()	
				end						
			else
				isLockbox = false
			end		
		else
			slotID = nil
		end	
	end
end

function GearingGuide:OnCommReceived(prefix, message, distribution, sender)
	local playerName = UnitName("player")
	if (sender ~= playerName) then
		if (prefix == "LootingGuideNI") then
			local decode = libCE:Decode(message)
			local decompress, errMess = libC:Decompress(decode)
			
			if(not decompress) then
				GearingGuide:Print("Error decompressing: " ..errMess)
				return
			end

			local success, final = libS:Deserialize(decompress)
			if(not success) then
				GearingGuide:Print("Error deserializing: " ..final)
				return
			end

			local rTable
			LootSystem, MLEPGPCost, RsName, RsLink, RiRarity, RdILvl, RsType, RsSubType, RsEquip, RsTexture, rTable = strsplit("/", final)
			RdILvl = tonumber(RdILvl)
			RiRarity = tonumber(RiRarity)
			sName, sLink, iRarity, dropppediLevel, sType, sSubType, sEquip, MLsTexture = RsName, RsLink, RiRarity, RdILvl, RsType, RsSubType, RsEquip, RsTexture

			local success, sTable = libS:Deserialize(rTable)
			if(not success) then
				GearingGuide:Print("Error deserializing: " ..sTable)
				return
			end
			
			if ((iRarity == 2 and GearingGuide.db.profile.greens) or (UnitLevel("player") ~= MaxLevel) or iRarity > 2) then
				
				MLTablePrio = sTable
				GearingGuide.db.profile.droppedItemLink = sLink
				table.insert(droppedIDs, GearingGuide.db.profile.droppedItemLink)
				local i = tablelength(droppedItems)
				table.insert(droppedItems, {value = i, text = sName})
				ItemSelect(GearingGuide.db.profile.droppedItemLink)
				if (MLEPGPCost ~= nil)	then
					tablePrio = MLTablePrio
				end
				WorkOutEPGP()
				local count = 0

				if (GearingGuide.db.profile.classShow == "self") then 
					EquipPrioSelf()
					for _, v in ipairs(tablePrio) do
						if (v.prio > 4) then
							count = count + 1
							ActivatePrint()
							tab:SelectTab(0)
							GearingGuide:RegisterEvent("CHAT_MSG_LOOT")
						end
					end
					if (count == 0 and GearingGuide.db.profile.isOpen ~= true) then
						table.wipe(droppedIDs)
						table.wipe(droppedItems)
						table.wipe(tablePrio)
					end 
				else
					ActivatePrint()
					tab:SelectTab(0)
					GearingGuide:RegisterEvent("CHAT_MSG_LOOT")
				end		
			end
		end
	end
end

function ActivatePrint()
	if (GearingGuide.db.profile.isOpen ~= true) then
		GearingGuide.db.profile.isOpen = true
				
		frame = AceGUI:Create("Frame")

		LoadFramePosition()

		frame:SetTitle("Gearing Guide")
		frame:SetCallback("OnClose", function(frame) SaveFramePosition() GearingGuide.db.profile.isOpen = false table.wipe(droppedIDs) table.wipe(droppedItems) MLsTexture = nil MLEPGPCost = nil AceGUI:Release(frame) end)			
		frame:SetLayout("Fill")
		frame:SetWidth(250)
		frame:SetStatusText("v"..VERSION)
		local i = tablelength(droppedItems)
		i = i - 1
		local height = 375 + (18 * i)
		frame:SetHeight(height)
		frame:EnableResize(Hide)

		tab = AceGUI:Create("TabGroup")
		tab:SetLayout("Flow")
		tab:SetTabs(droppedItems)
		tab:SetCallback("OnGroupSelected", SelectGroup)
		tab:SelectTab(0)

		frame:AddChild(tab)	
	else
		local i = tablelength(droppedItems)
		i = i - 1
		local height = 375 + (18 * i)
		frame:SetHeight(height)
	end
end

function SelectGroup(container, event, group)
	container:ReleaseChildren()
	typeOfItem1 = nil
	SaveFramePosition()
	local index = group + 1
	if (comparing == false) then
		if (MLEPGPCost == nil)	then
			ItemSelect(droppedIDs[index])
			WorkoutPrimary()
			if (GearingGuide.db.profile.classShow == "self") then 
				EquipPrioSelf()
			end
		end
		WorkOutEPGP()
		DrawGroup(container)
	else
		comparing = false
		ItemSelect(droppedIDs[index])
		GearingGuide.db.profile.isOpen = false
		AceGUI:Release(frame)		
		ActivatePrint()
		tab:SelectTab(group)
	end	
end

function ItemSelect(id)
	if (MLsTexture == nil) then
		sName, sLink, iRarity, dropppediLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(id)
		tablePrio = GearingGuide:PriorityTable()
		stats = GetItemStats(sLink, statsTable)
	else
		sName, sLink, iRarity, dropppediLevel, sType, sSubType, sEquip, MLsTexture = RsName, RsLink, RiRarity, RdILvl, RsType, RsSubType, RsEquip, RsTexture
	end
		
	GearingGuide.db.profile.droppedItemLink = sLink
	ToolTipScanner(true)
end

function DrawGroup(container)			
	local itemGroup = AceGUI:Create("InlineGroup")
	itemGroup:SetTitle("Dropped Item")
	itemGroup:SetWidth(197)
	itemGroup:SetFullHeight(true)
	itemGroup:SetLayout("List")
	container:AddChild(itemGroup)

	local pic = AceGUI:Create("Icon")
	if (MLsTexture ~= nil) then
		pic:SetImage(MLsTexture)
	else
		pic:SetImage(sTexture)
	end
	
	pic:SetWidth(165)
	pic:SetImageSize(40, 40)
	pic:SetCallback("OnEnter", function(pic) GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR") GameTooltip:SetHyperlink(GearingGuide.db.profile.droppedItemLink) if isOpen == true then  wishText:SetText(GearingGuide.db.profile.droppedItemLink) end end)
	pic:SetCallback("OnLeave", function(pic) GameTooltip:Hide() end)
	itemGroup:AddChild(pic)

	local linebreak = AceGUI:Create("Label")
	linebreak:SetText(" ")
	itemGroup:AddChild(linebreak)
	
	local wishLabel = AceGUI:Create("Label")
	wishLabel:SetFullWidth(true)
	wishLabel:SetColor(1,0.8,0)
	itemGroup:AddChild(wishLabel)

	if (GearingGuide.db.profile.epgpEnable or MLEPGPCost ~= nil) then
		local epgp = AceGUI:Create("Label")
			 
		if (MLEPGPCost ~= nil) then
			epgp:SetText("             "..LootSystem.." Cost: "..MLEPGPCost)
		elseif (GearingGuide.db.profile.epgpEnable)  then
			LootSystem = GearingGuide.db.profile.system
			epgp:SetText("             "..LootSystem.." Cost: "..iEPGPCost)
		else
			epgp:SetText(" ")
		end
		itemGroup:AddChild(epgp)
	end

	local linebreak = AceGUI:Create("Label")
	linebreak:SetText(" ")
	itemGroup:AddChild(linebreak)
	
	local group = AceGUI:Create("InlineGroup")	
	group:SetTitle("Priorities")
	group:SetFullWidth(itemGroup)
	group:SetHeight(45)
	
	group:SetLayout("Fill")
	itemGroup:AddChild(group)

	scroll = AceGUI:Create("ScrollFrame")
	scroll:SetLayout("Flow")
	group:AddChild(scroll)

	if (tablelength(classesTable) > 0 ) then
		if( sSubType == "Junk" ) then
			tablePrio = {}
			for i, value in ipairs(classesTable) do
				table.insert(tablePrio, {class = value.class, spec = "", prio = 14})
			end
		end
		table.wipe(classesTable)
	end

	RemoveUnderPrio()

	sort(tablePrio, function(a,b) return a.prio > b.prio end)

	local minusPrio = 0
	for i, value in ipairs(tablePrio) do
		if ( value.prio > 14  and minusPrio == 0) then
			minusPrio = value.prio - 14
		end

		if ( minusPrio > 0 ) then
			value.prio = value.prio - minusPrio
		end
	end

	local setColorR = 0
	local setColorG = 0
	local setColorB = 0
	
	local count = 0
		
	for _, v in ipairs(tablePrio) do
		if (v.prio > 4) then
			count = count + 1
			local itemPrio = AceGUI:Create("Label")
			if (v.prio > 13) then
				setColorR = 1.0
			elseif (v.prio == 13) then
				setColorR = 1.0
				setColorG = 0.2
			elseif (v.prio == 12) then
				setColorR = 1.0
				setColorG = 0.4
			elseif (v.prio == 11) then
				setColorR = 1.0
				setColorG = 0.6
			elseif (v.prio == 10) then
				setColorR = 1.0
				setColorG = 0.8
			elseif (v.prio == 9) then
				setColorR = 1.0
				setColorG = 1.0
			elseif (v.prio == 8) then
				setColorR = 0.2
				setColorG = 1.0
			elseif (v.prio == 7) then
				setColorG = 1.0					
				setColorB = 0.2
			elseif (v.prio == 6) then
				setColorG = 1.0
				setColorB = 0.4
			end

			if( setColorR == 0 and setColorG == 0 and setColorB == 0 ) then
				setColorR = 1
				setColorG = 1
				setColorB = 1
			end
			itemPrio:SetColor(setColorR,setColorG,setColorB)
			itemPrio:SetText(v.prio.." - "..v.spec.." "..v.class)
			scroll:AddChild(itemPrio)
		end
	end
	if (count == 0) then
		local itemPrio = AceGUI:Create("Label")
		
		itemPrio:SetText("This item is useless")
		scroll:AddChild(itemPrio)
		local itemPrio = AceGUI:Create("Label")
		scroll:AddChild(itemPrio)
	end
					
	table.wipe(stats)
	table.wipe(statsTable)

	local compareBtn = AceGUI:Create("Button")
	compareBtn:SetText("Compare Item")
	compareBtn:SetCallback("OnClick", compareItem)
	compareBtn:SetFullWidth(itemGroup)
	itemGroup:AddChild(compareBtn)

	_, _, dropID = string.find(GearingGuide.db.profile.droppedItemLink, "item:(%d+):")

	for _, v in ipairs(GearingGuide.db.profile.wishlist.items) do
		local _, _, ID = string.find(v.name, "item:(%d+):")
		if ( ID == dropID ) then
			wishLabel:SetText("     On Wish List for: " ..v.use)
			return
		end
	end		
end

function compareItem()
	if (comparing == false) then
		comparing = true

		tablePrio = GearingGuide:PriorityTable()

		local i = tablelength(droppedItems)
		i = i - 2
		local height = 375 + (10 * i)

		frame:SetHeight(height)

		local slotId, texture, checkRelic = GetInventorySlotInfo(typeOfItem)

		local equipItem = GetInventoryItemLink("player", slotId)
		sName, sLink, _, iLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(equipItem)
		stats = GetItemStats(sLink, statsTable)
		
		compareGroup = AceGUI:Create("InlineGroup")
		compareGroup:SetTitle("Currently Equipped")
		compareGroup:SetWidth(190)
		compareGroup:SetLayout("List")
		tab:AddChild(compareGroup)
		
		local link = sLink

		local pic = AceGUI:Create("Icon")
		pic:SetImage(sTexture)
		pic:SetWidth(155)
		pic:SetImageSize(40, 40)
		pic:SetCallback("OnEnter", function(pic) GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR") GameTooltip:SetHyperlink(link) end)
		pic:SetCallback("OnLeave", function(pic) GameTooltip:Hide() end)
		compareGroup:AddChild(pic)

		local label = AceGUI:Create("Label")
		label:SetText(sName)
		label:SetFullWidth(compareGroup)
		label:SetFontObject(GameFontNormalSmall)
		compareGroup:AddChild(label)
		
		WorkoutPrimary()
		EquipPrioSelf()
		iLevelModifier()

		local linebreak = AceGUI:Create("Label")
		linebreak:SetText(" ")
		compareGroup:AddChild(linebreak)

		local group = AceGUI:Create("InlineGroup")
		group:SetTitle("Priorities")
		group:SetFullWidth(compareGroup)
		group:SetLayout("Fill")
		group:SetHeight(70)
		compareGroup:AddChild(group)

		scroll = AceGUI:Create("ScrollFrame")
		scroll:SetLayout("Flow")
		group:AddChild(scroll)

		local setColorR = 0
		local setColorG = 0
		local setColorB = 0

		sort(tablePrio, function(a,b) return a.prio > b.prio end)
		for _, v in ipairs(tablePrio) do
			if (v.prio > 4) then
				local itemPrio = AceGUI:Create("Label")
				if (v.prio > 13) then
					setColorR = 1.0
				elseif (v.prio == 13) then
					setColorR = 1.0
					setColorG = 0.2
				elseif (v.prio == 12) then
					setColorR = 1.0
					setColorG = 0.4
				elseif (v.prio == 11) then
					setColorR = 1.0
					setColorG = 0.6
				elseif (v.prio == 10) then
					setColorR = 1.0
					setColorG = 0.8
				elseif (v.prio == 9) then
					setColorR = 1.0
					setColorG = 1.0
				elseif (v.prio == 8) then
					setColorR = 0.2
					setColorG = 1.0
				elseif (v.prio == 7) then
					setColorG = 1.0					
					setColorB = 0.2
				elseif (v.prio == 6) then
					setColorG = 1.0
					setColorB = 0.4
				end

				if( setColorR == 0 and setColorG == 0 and setColorB == 0 ) then
					setColorR = 1
					setColorG = 1
					setColorB = 1
				end
				itemPrio:SetColor(setColorR, setColorG, setColorB)
				itemPrio:SetText(v.prio.." - "..v.spec.." "..v.class)
				scroll:AddChild(itemPrio)
			end
		end

		table.wipe(tablePrio)
		table.wipe(stats)
		 
		if (typeOfItem1 ~= nil) then
			frame:SetWidth(634)
			compareItem1()
		else
			frame:SetWidth(444)
		end
	else
		comparing = false			
		ItemSelect(droppedIDs[1])
		GearingGuide.db.profile.isOpen = false
		AceGUI:Release(frame)
		if (MLEPGPCost ~= nil)	then
			tablePrio = MLTablePrio
		end
		ActivatePrint()
		tab:SelectTab(0)
	end
end

function compareItem1()	
	tablePrio = GearingGuide:PriorityTable()

	local i = tablelength(droppedItems)
	i = i - 2
	local height = 375 + (8 * i)

	frame:SetHeight(height)
	
	local slotId, texture, checkRelic = GetInventorySlotInfo(typeOfItem1)

	local equipIem = GetInventoryItemLink("player", slotId)
	sName, sLink, _, iLevel, _, sType, sSubType, _, sEquip, sTexture = GetItemInfo(equipIem)
	stats = GetItemStats(sLink, statsTable)
		
	compareGroup = AceGUI:Create("InlineGroup")
	compareGroup:SetTitle("Currently Equipped")
	compareGroup:SetWidth(190)
	compareGroup:SetLayout("List")
	tab:AddChild(compareGroup)
	
	local link = sLink

	local pic = AceGUI:Create("Icon")
	pic:SetImage(sTexture)
	pic:SetWidth(155)
	pic:SetImageSize(40, 40)
	pic:SetCallback("OnEnter", function(pic) GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR") GameTooltip:SetHyperlink(link) end)
	pic:SetCallback("OnLeave", function(pic) GameTooltip:Hide() end)
	compareGroup:AddChild(pic)

	local label = AceGUI:Create("Label")
	label:SetText(sName)
	label:SetFullWidth(compareGroup)
	label:SetFontObject(GameFontNormalSmall)
	compareGroup:AddChild(label)
		
	WorkoutPrimary()
	EquipPrioSelf()
	iLevelModifier()

	local linebreak = AceGUI:Create("Label")
	linebreak:SetText(" ")
	compareGroup:AddChild(linebreak)

	local group = AceGUI:Create("InlineGroup")
	group:SetTitle("Priorities")
	group:SetFullWidth(compareGroup)
	group:SetLayout("Fill")
	group:SetHeight(70)
	compareGroup:AddChild(group)

	scroll = AceGUI:Create("ScrollFrame")
	scroll:SetLayout("Flow")
	group:AddChild(scroll)

	local setColorR = 0
	local setColorG = 0
	local setColorB = 0

	sort(tablePrio, function(a,b) return a.prio > b.prio end)
	for _, v in ipairs(tablePrio) do
		if (v.prio > 4) then
			local itemPrio = AceGUI:Create("Label")
			if (v.prio > 13) then
				setColorR = 1.0
			elseif (v.prio == 13) then
				setColorR = 1.0
				setColorG = 0.2
			elseif (v.prio == 12) then
				setColorR = 1.0
				setColorG = 0.4
			elseif (v.prio == 11) then
				setColorR = 1.0
				setColorG = 0.6
			elseif (v.prio == 10) then
				setColorR = 1.0
				setColorG = 0.8
			elseif (v.prio == 9) then
				setColorR = 1.0
				setColorG = 1.0
			elseif (v.prio == 8) then
				setColorR = 0.2
				setColorG = 1.0
			elseif (v.prio == 7) then
				setColorG = 1.0					
				setColorB = 0.2
			elseif (v.prio == 6) then
				setColorG = 1.0
				setColorB = 0.4
			end
			
			if( setColorR == 0 and setColorG == 0 and setColorB == 0 ) then
				setColorR = 1
				setColorG = 1
				setColorB = 1
			end
			itemPrio:SetColor(setColorR,setColorG,setColorB)
			itemPrio:SetText(v.prio.." - "..v.spec.." "..v.class)
			scroll:AddChild(itemPrio)
		end
	end

	table.wipe(tablePrio)
	table.wipe(stats)
	 
end

function WorkoutPrimary()
	primaryStat = nil
	for stat, value in pairs(stats) do
		if (_G[stat] == "Agility") then
			primaryStat = "Agility"				
		elseif (_G[stat] == "Intellect") then
			primaryStat = "Intellect"
		elseif (_G[stat] == "Strength") then
			primaryStat = "Strength"
		end
	end

	if (primaryStat == nil) then
		for stat, value in pairs(stats) do
			if (_G[stat] == "Stamina") then
				primaryStat = "Stamina"
			end
		end
	end
		
	WorkoutStats()
end

function EquipPrioSelf()
	local class = UnitClass("player")
	for i, v in pairs(tablePrio) do
		if (v.class ~= class) then
			v.prio = 0
		end
	end
end

function iLevelModifier()
	for i, v in pairs(tablePrio) do
		if (iLevel > dropppediLevel) then
			v.prio = v.prio + 1
		elseif (iLevel < dropppediLevel) then
			v.prio = v.prio - 1
		end
	end
end

function WorkoutStats()		
	for stat, value in pairs(stats) do			
		if (_G[stat] == "Agility") then
			MainStat("Agility")				
		elseif (_G[stat] == "Intellect") then
			MainStat("Intellect")
		elseif (_G[stat] == "Strength") then
			MainStat("Strength")
		end

		if (_G[stat] == "Critical Strike" or _G[stat] == "Critical Strike Rating") then
			SecondaryStat("Crit")
		end

		if (_G[stat] == "Haste" or _G[stat] == "Haste Rating") then
			SecondaryStat("Haste")
		end

		if (_G[stat] == "Mastery" or _G[stat] == "Mastery Rating") then
			SecondaryStat("Mastery")
		end

		if (_G[stat] == "Hit" or _G[stat] == "Hit Rating") then
			SecondaryStat("Hit")
		end

		if (_G[stat] == "Expertise" or _G[stat] == "Expertise Rating") then
			SecondaryStat("Expertise")
		end

		if (_G[stat] == "Parry" or _G[stat] == "Parry Rating") then
			SecondaryStat("Parry")
		end

		if (_G[stat] == "Dodge" or _G[stat] == "Dodge Rating") then
			SecondaryStat("Dodge")
		end
		
		if (_G[stat] == "Spirit") then
			SecondaryStat("Spirit")
		end
	end

	if (sType == "Armor") then
		Armour()
	elseif (sType == "Weapon") then
		Weapon()
	elseif (sType == "Miscellaneous") then
		Misc()
	end
end

function Armour()
	ToolTipScanner("Check")
	if ( (sEquip == "INVTYPE_CLOAK") or (sSubType == "Miscellaneous") or (sEquip == "INVTYPE_TRINKET")) then
		if( primaryStat ~= nil) then
			MainStat(primaryStat)
		else
			for stat, value in pairs(stats) do
				if (_G[stat] == "Stamina") then
					MainStat("Stamina")
				end
			end
		end

		if (sEquip == "INVTYPE_TRINKET") then
			ToolTipScanner(false)
		end
	elseif (sSubType == "Plate") then
		if (primaryStat == "Intellect") then
			for _, value in ipairs(tablePrio) do
				if ( value.class == "Paladin" and value.spec == "Holy") then
					value.prio = value.prio + 5
				else
					value.prio = -50
				end  
			end
		else
			for _, value in ipairs(tablePrio) do
				if ( value.class == "Death Knight" or value.spec == "Retribution" or (value.class == "Paladin" and value.spec == "Protection") or value.class == "Warrior") then
					value.prio = value.prio + 5
				else
					value.prio = -50
				end  
			end
		end
	elseif (sSubType == "Mail") then
		if (primaryStat == "Intellect") then
			for _, value in ipairs(tablePrio) do
				if ( value.spec == "Elemental" or (value.class == "Shaman" and value.spec == "Restoration") or (isPreLevel40 and (value.class == "Paladin" and value.spec == "Holy"))) then
					value.prio = value.prio + 5
				else
					value.prio = -50
				end  
			end
		else
			for _, value in ipairs(tablePrio) do
				if ( value.class == "Hunter" or value.spec == "Enhancement" or (isPreLevel40 and ( value.class == "Death Knight" or value.spec == "Retribution" or (value.class == "Paladin" and value.spec == "Protection") or value.class == "Warrior"))) then
					value.prio = value.prio + 5
				else
					value.prio = -50
				end  
			end	
		end
	elseif (sSubType == "Leather") then
		if (primaryStat == "Intellect") then
			for _, value in ipairs(tablePrio) do
				if ( (value.class == "Druid" and value.spec == "Restoration") or value.spec == "Balance" or value.spec == "Mistweaver" or (isPreLevel40 and ( value.spec == "Elemental" or (value.class == "Shaman" and value.spec == "Restoration")))) then
					value.prio = value.prio + 5
				else
					value.prio = -50
				end  
			end
		else
			for _, value in ipairs(tablePrio) do
				if (value.spec == "Feral" or value.spec == "Guardian" or value.class == "Rogue" or value.spec == "Windwalker DW" or value.spec == "Windwalker 2H" or value.spec == "Brewmaster" or (isPreLevel40 and ( value.class == "Hunter" or value.spec == "Enhancement"))) then
					value.prio = value.prio + 5
				else
					value.prio = -50
				end  
			end
		end
	elseif (sSubType == "Cloth") then
		for _, value in ipairs(tablePrio) do
			if ( value.class == "Mage" or value.class == "Priest" or value.class == "Warlock") then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Shields") then
		for _, value in ipairs(tablePrio) do
			if (value.spec == "Protection" or value.spec == "Elemental" or (value.class == "Shaman" and value.spec == "Restoration") or (value.class == "Paladin" and value.spec == "Holy")) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end		
	end
	isPreLevel40 = false
end

function Weapon()
	ToolTipScanner(false)
	if (sSubType == "Bows") then
		for _, value in ipairs(tablePrio) do
			if ( value.class == "Hunter") then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Crossbows") then
		for _, value in ipairs(tablePrio) do
			if (value.class == "Hunter") then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Daggers") then
		for _, value in ipairs(tablePrio) do
			if (value.class == "Druid" or value.class == "Mage" or value.class == "Priest" or value.class == "Rogue"  or value.class == "Shaman" or value.class == "Warlock") then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Guns") then
		for _, value in ipairs(tablePrio) do
			if ( value.class == "Hunter") then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Fist Weapons") then
		for _, value in ipairs(tablePrio) do
			if ( value.class == "Druid" or value.class == "Monk" or value.class == "Rogue"  or value.class == "Shaman" or (value.class == "Warrior" and (value.spec == "Fury 1H" or value.spec == "Protection"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "One-Handed Axes") then
		for _, value in ipairs(tablePrio) do
			if ( (value.class == "Death Knight" and value.spec == "Frost DW") or value.class == "Monk" or value.class == "Paladin" or value.class == "Rogue"  or value.class == "Shaman" or (value.class == "Warrior" and (value.spec == "Fury 1H" or value.spec == "Protection"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end						
	elseif (sSubType == "One-Handed Maces") then
		for _, value in ipairs(tablePrio) do
			if ( (value.class == "Death Knight" and value.class == "Frost DW") or value.class == "Druid" or value.class == "Monk" or value.class == "Paladin" or value.class == "Priest" or value.class == "Rogue"  or value.class == "Shaman" or (value.class == "Warrior" and (value.spec == "Fury 1H" or value.spec == "Protection"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "One-Handed Swords") then
		for _, value in ipairs(tablePrio) do
			if ( (value.class == "Death Knight" and value.class == "Frost DW") or value.class == "Mage" or value.class == "Monk" or value.class == "Paladin" or value.class == "Rogue"  or value.class == "Warlock" or (value.class == "Warrior" and (value.spec == "Fury 1H" or value.spec == "Protection"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end	
	elseif (sSubType == "Polearms") then
		for _, value in ipairs(tablePrio) do
			if ( (value.class == "Death Knight" and value.spec ~= "Frost DW") or value.class == "Druid" or value.class == "Monk" or value.class == "Paladin" or value.class == "Shaman" or (value.class == "Warrior" and (value.spec ~= "Protection" and value.spec ~= "Fury 1H"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end			
	elseif (sSubType == "Staves") then
		for _, value in ipairs(tablePrio) do
			if (value.class == "Druid" or value.class == "Mage" or value.class == "Monk" or value.class == "Priest" or value.class == "Shaman" or value.class == "Warlock" or (value.class == "Warrior"  and (value.spec ~= "Protection" and value.spec ~= "Fury 1H"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end  
	elseif (sSubType == "Two-Handed Axes") then
		for _, value in ipairs(tablePrio) do
			if (value.class == "Death Knight" or (value.class == "Paladin" and value.spec ~= "Protection") or (value.class == "Warrior" and (value.spec ~= "Protection" and value.spec ~= "Fury 1H"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Two-Handed Maces") then
		for _, value in ipairs(tablePrio) do
			if ((value.class == "Death Knight" and value.spec ~= "Frost DW") or (value.class == "Paladin" and value.spec ~= "Protection") or (value.class == "Warrior" and (value.spec ~= "Protection" and value.spec ~= "Fury 1H"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end	
	elseif (sSubType == "Two-Handed Swords") then
		for _, value in ipairs(tablePrio) do
			if ((value.class == "Death Knight" and value.spec ~= "Frost DW") or (value.class == "Paladin" and value.spec ~= "Protection") or (value.class == "Warrior" and (value.spec ~= "Protection" and value.spec ~= "Fury 1H"))) then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	elseif (sSubType == "Wands") then
		for _, value in ipairs(tablePrio) do
			if (value.class == "Mage" or value.class == "Priest" or value.class == "Warlock") then
				value.prio = value.prio + 5
			else
				value.prio = -50
			end  
		end
	end
end

function Misc()
	for _, value in ipairs(tablePrio) do
		value.prio = 14
	end
end

function MainStat(Mstat)
	for _, value in ipairs(tablePrio) do
		if Mstat == "Stamina" then
			value.prio = value.prio + value.Stamina
		elseif Mstat == "Strength" then
			value.prio = value.prio + value.Strength
		elseif Mstat == "Agility" then
			value.prio = value.prio + value.Agility
		elseif Mstat == "Intellect" then
			value.prio = value.prio + value.Intellect
		end
	end
end

function SecondaryStat(Sstat)
	for _, value in ipairs(tablePrio) do
		if Sstat == "Crit" then
			value.prio = value.prio + value.critical
		elseif Sstat == "Haste" then
			value.prio = value.prio + value.haste
		elseif Sstat == "Mastery" then
			value.prio = value.prio + value.mastery
		elseif Sstat == "Hit" then
			value.prio = value.prio + value.hit
		elseif Sstat == "Expertise" then
			value.prio = value.prio + value.expertise
		elseif Sstat == "Spirit" then
			value.prio = value.prio + value.spirit
		elseif Sstat == "Dodge" then
			value.prio = value.prio + value.dodge
		elseif Sstat == "Parry" then
			value.prio = value.prio + value.parry
		end
	end
end

function ToolTipScanner(lockCheck)	
	CreateFrame( "GameTooltip", "GearingTooltip", nil, "GameTooltipTemplate" ); -- Tooltip name cannot be nil
	GearingTooltip:SetOwner( WorldFrame, "ANCHOR_NONE" );
	GearingTooltip:ClearLines()
	GearingTooltip:SetHyperlink(sLink)
	
	if (lockCheck == "check") then
		CheckLevel(GearingTooltip:GetRegions())
	elseif( lockCheck ) then
		EnumerateTooltipLines_helperToken(GearingTooltip:GetRegions())
	else
		EnumerateTooltipLines_helper(GearingTooltip:GetRegions())
	end	
end

function EnumerateTooltipLines_helperToken(...)
	for i = 1, select("#", ...) do
        local region = select(i, ...)
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText() -- string or nil
			if (text ~= nil) then
				local startPos, endPos, firstWord, restOfString = string.find( text, "(%w+)[%s%p]*(.*)")
				
				if (firstWord == "Classes") then
					classesTable = {}
					
					local foundWord = string.find(restOfString, "Death Knight")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Death Knight"})
					end

					local foundWord = string.find(restOfString, "Druid")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Druid"})
					end

					local foundWord = string.find(restOfString, "Hunter")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Hunter"})
					end

					local foundWord = string.find(restOfString, "Mage")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Mage"})
					end

					local foundWord = string.find(restOfString, "Monk")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Monk"})
					end

					local foundWord = string.find(restOfString, "Paladin")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Paladin"})
					end

					local foundWord = string.find(restOfString, "Priest")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Priest"})
					end

					local foundWord = string.find(restOfString, "Rogue")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Rogue"})
					end

					local foundWord = string.find(restOfString, "Shaman")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Shaman"})
					end

					local foundWord = string.find(restOfString, "Warlock")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Warlock"})
					end

					local foundWord = string.find(restOfString, "Warrior")
					if (foundWord ~= nil) then
						table.insert(classesTable, {class = "Warrior"})
					end
				end
			end
		end
	end
end

function CheckLevel(...)
    for i = 1, select("#", ...) do
        local region = select(i, ...)
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText() -- string or nil
			if (text ~= nil) then
				local startPos, endPos, firstWord, restOfString = string.find( text, "(%w+)[%s%p]*(.*)")
				
				if (dropppediLevel < 45) then
					isPreLevel40 = true
				end

				if (firstWord == "Requires") then
					foundWord = string.find(restOfString, "Level")
					if (foundWord ~= nil) then
						local level = strsub( restOfString, -2)
						
						if ( tonumber(level) < 40) then
							isPreLevel40 = true
						end						
					end
				end
			end
		end
	end
end

function EnumerateTooltipLines_helper(...)
    for i = 1, select("#", ...) do
        local region = select(i, ...)
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText() -- string or nil
			if (text ~= nil) then
				local startPos, endPos, firstWord, restOfString = string.find( text, "(%w+)[%s%p]*(.*)")
				
				local count = 0
				
				if ((firstWord == "Equip") or (firstWord == "Use")) then
					if (sType ~= "Weapon") then
						local foundWord = string.find(restOfString, "spell power")
						if (foundWord ~= nil) then
							MainStat("Intellect")
						end
					end
					
					foundWord = string.find(restOfString, "spells")
					if (foundWord ~= nil) then
						foundWord = string.find(restOfString, "harmful")
						local fw = string.find(restOfString, "damage")
						if (foundWord ~= nil or fw ~= nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.Intellect > 0 and value.spirit ~= 2) then
									if (value.prio > 9) then
										value.prio = value.prio + 2
									else
										value.prio = value.prio + 5
									end	
								else
									value.prio = value.prio - 5
								end
							end
						end

						foundWord = string.find(restOfString, "healing and damaging")
						if (foundWord ~= nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.Intellect > 0) then
									if (value.prio > 5) then
										value.prio = value.prio + 2
									else
										value.prio = value.prio + 5
									end	
								else
									value.prio = value.prio - 15
								end
							end
						else
							foundWord = string.find(restOfString, "damaging")
							if (foundWord ~= nil) then
								for _, value in ipairs(tablePrio) do						
									if (value.Intellect > 0 and value.spirit ~= 2) then
										if (value.prio > 9) then
											value.prio = value.prio + 2
										else
											value.prio = value.prio + 5
										end	
									else
										value.prio = value.prio - 5
									end
								end
							end

							foundWord = string.find(restOfString, "healing")
							if (foundWord ~= nil) then
								for _, value in ipairs(tablePrio) do						
									if (value.Intellect > 0 and value.spirit == 2) then
										if (value.prio > 9) then
											value.prio = value.prio + 2
										else
											value.prio = value.prio + 5
										end	
									else
										value.prio = value.prio - 5
									end
								end
							end

							foundWord = string.find(restOfString, "dealing damage")
							if (foundWord ~= nil) then
								for _, value in ipairs(tablePrio) do						
									if (value.Intellect > 0 and value.spirit ~= 2) then
										if (value.prio > 9) then
											value.prio = value.prio + 2
										else
											value.prio = value.prio + 5
										end	
									else
										value.prio = value.prio - 5
									end
								end
							end
						end
					else
						findStat = string.find(restOfString, "heal")
						if (findStat ~= nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.spirit == 2) then
									if (value.prio > 9) then
										value.prio = value.prio + 2
									else
										value.prio = value.prio + 5
									end
								elseif (value.dodge > 0) then
									value.prio = value.prio + value.dodge
								end
							end
						end					
					end

					foundWord = string.find(restOfString, "harmful spellcasts")
					if (foundWord ~= nil) then
						for _, value in ipairs(tablePrio) do
							if (value.Intellect > 0 and value.spirit ~= 2) then
								value.prio = value.prio + 5
							else
								value.prio = value.prio - 5
							end
						end
					end
					
					foundWord = string.find(restOfString, "melee and ranged attacks")
					if (foundWord ~= nil) then
						for _, value in ipairs(tablePrio) do					
							if (value.spirit == 2) then
								value.prio = value.prio - 5
							elseif (value.Intellect < 0) then							
								if (value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end						
							else
								value.prio = value.prio - 5
							end
						end
					else
						foundWord = string.find(restOfString, "attacks")
						if (foundWord ~= nil) then
							for _, value in ipairs(tablePrio) do					
								if (value.spirit == 2) then
									value.prio = value.prio - 5
								else
									if (value.prio > 9) then
										value.prio = value.prio + 2
									else
										value.prio = value.prio + 5
									end						
								end
							end
						end
					end

					foundWord = string.find(restOfString, "maximum health")
					if (foundWord ~= nil) then
						for _, value in ipairs(tablePrio) do					
							if (value.dodge ~= 0) then
								if (value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end	
							else
								value.prio = value.prio - 5						
							end
						end
					end

					foundWord = string.find(restOfString, "physical absorb shield")
					if (foundWord ~= nil) then
						for _, value in ipairs(tablePrio) do					
							if (value.dodge ~= 0) then
								if (value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end	
							else
								value.prio = value.prio - 5						
							end
						end
					end

					if (sType ~= "Weapon") then
						foundWord = string.find(restOfString, "parry")
						if (foundWord ~= nil) then
							SecondaryStat("Parry")
						end

						foundWord = string.find(restOfString, "dodge")
						if (foundWord ~= nil) then
							for _, value in ipairs(tablePrio) do					
								if (value.dodge > 0) then
									if (value.prio > 9) then
										value.prio = value.prio + 2
									else
										value.prio = value.prio + 5
									end	
								else
									value.prio = value.prio - 5						
								end
							end
						end
					end

					foundWord = string.find(restOfString, "mana")
					if (foundWord ~= nil) then
						for _, value in ipairs(tablePrio) do						
							if (value.spirit == 2) then
								if (value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end	
							end
						end
						SecondaryStat("Spirit")
					end

					local findStat = string.find(restOfString, "haste")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.haste > 0) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Haste")
					end

					findStat = string.find(restOfString, "critical")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.critical > 0) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Crit")
					end

					findStat = string.find(restOfString, "mastery")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.mastery > 0) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Mastery")
					end

					findStat = string.find(restOfString, "spirit")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.spirit == 2) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Spirit")
					end

					findStat = string.find(restOfString, "Spirit")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.spirit == 2) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Spirit")
					end

					findStat = string.find(restOfString, "dodge")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.dodge == 2) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Dodge")
					end
					
					findStat = string.find(restOfString, "parry")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.parry == 2) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Parry")
					end

					findStat = string.find(restOfString, "expertise")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.expertise > 0) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Expertise")
					end

					findStat = string.find(restOfString, "hit")
					if (findStat ~= nil) then
						if (sType ~= "Weapon" and primaryStat == nil) then
							for _, value in ipairs(tablePrio) do						
								if (value.spirit ~= 2) then
									value.prio = value.prio + 2
								end
							end
						end
						SecondaryStat("Hit")
					end

					if (sType ~= "Weapon") then
						findStat = string.find(restOfString, "Intellect")
						if (findStat ~= nil) then							
							for _, value in ipairs(tablePrio) do
								if (value.Intellect > 0 and value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end
							end
							MainStat("Intellect")
						end

						findStat = string.find(restOfString, "Strength")
						if (findStat ~= nil) then
							for _, value in ipairs(tablePrio) do
								if (value.Strength > 0 and value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end
							end
							MainStat("Strength")
						end

						findStat = string.find(restOfString, "Agility")
						if (findStat ~= nil) then							
							for _, value in ipairs(tablePrio) do
								if (value.Agility > 0 and value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end
							end
							MainStat("Agility")
						end

						findStat = string.find(restOfString, "Stamina")
						if (findStat ~= nil) then							
							for _, value in ipairs(tablePrio) do
								if (value.Stamina > 0 and value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end
							end
							MainStat("Stamina")
						end
					end
					
					findStat = string.find(restOfString, "potions")
					if (findStat ~= nil) then
						for _, value in ipairs(tablePrio) do
							if (value.spirit == 2) then
								value.prio = value.prio - 5							
							end
						end
					end

					findStat = string.find(restOfString, "deal damage")
					if (findStat ~= nil) then
						for _, value in ipairs(tablePrio) do
							if (value.spirit == 2) then
								value.prio = value.prio - 5
							else
								if (value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end
							end
						end
					end

					findStat = string.find(restOfString, "damage dealing")
					if (findStat ~= nil) then
						for _, value in ipairs(tablePrio) do
							if (value.spirit == 2) then
								value.prio = value.prio - 5
							else
								if (value.prio > 9) then
									value.prio = value.prio + 2
								else
									value.prio = value.prio + 5
								end
							end
						end
					end
				end
			end
        end
    end
end

function WorkOutEPGP()
	if (GearingGuide.db.profile.inGuild == true) then
		if (sType == "Miscellaneous") then
			local name, left = strsplit(" ", sName, 2)
			if (name == "Gauntlets") then
				typeOfItem = "HandsSlot"
				iEPGPCost = GearingGuide.db.profile.custom.GlovesGP
			elseif (name == "Pauldrons" or name == "Mantle" or name == "Shoulders") then
				typeOfItem = "ShoulderSlot"
				iEPGPCost = GearingGuide.db.profile.custom.ShouldersGP
			elseif (name == "Chestguard" or name == "Chest") then
				typeOfItem = "ChestSlot"
				iEPGPCost = GearingGuide.db.profile.custom.ChestGP	
			elseif (name == "Leggings") then
				typeOfItem = "LegsSlot"
				iEPGPCost = GearingGuide.db.profile.custom.LegsGP	
			elseif (name == "Crown" or name == "Helm") then
				typeOfItem = "HeadSlot"
				iEPGPCost = GearingGuide.db.profile.custom.HelmGP
			else
				iEPGPCost = 0		
			end
		elseif (sEquip == "INVTYPE_HEAD") then
			typeOfItem = "HeadSlot"
			iEPGPCost = GearingGuide.db.profile.custom.HelmGP
		elseif (sEquip == "INVTYPE_LEGS") then
			typeOfItem = "LegsSlot"
			iEPGPCost = GearingGuide.db.profile.custom.LegsGP	
		elseif (sEquip == "INVTYPE_CHEST" or sEquip == "INVTYPE_ROBE") then
			typeOfItem = "ChestSlot"
			iEPGPCost = GearingGuide.db.profile.custom.ChestGP
		elseif (sEquip == "INVTYPE_NECK") then
			typeOfItem = "NeckSlot"
			iEPGPCost = GearingGuide.db.profile.custom.NeckGP
		elseif (sEquip == "INVTYPE_CLOAK") then
			typeOfItem = "BackSlot"
			iEPGPCost = GearingGuide.db.profile.custom.CloakGP
		elseif (sEquip == "INVTYPE_WRIST") then
			typeOfItem = "WristSlot"
			iEPGPCost = GearingGuide.db.profile.custom.WristGP
		elseif (sEquip == "INVTYPE_FINGER") then
			typeOfItem = "Finger0Slot"
			typeOfItem1 = "Finger1Slot"
			iEPGPCost = GearingGuide.db.profile.custom.RingGP
		elseif (sEquip == "INVTYPE_SHOULDER") then
			typeOfItem = "ShoulderSlot"
			iEPGPCost = GearingGuide.db.profile.custom.ShouldersGP
		elseif (sEquip == "INVTYPE_HAND") then
			typeOfItem = "HandsSlot"
			iEPGPCost = GearingGuide.db.profile.custom.GlovesGP
		elseif (sEquip == "INVTYPE_WAIST") then
			typeOfItem = "WaistSlot"
			iEPGPCost = GearingGuide.db.profile.custom.WaistGP
		elseif (sEquip == "INVTYPE_FEET") then
			typeOfItem = "FeetSlot"
			iEPGPCost = GearingGuide.db.profile.custom.BootsGP
		elseif (sEquip == "INVTYPE_TRINKET") then
			typeOfItem = "Trinket0Slot"
			typeOfItem1 = "Trinket1Slot"
			iEPGPCost = GearingGuide.db.profile.custom.TrinketGP
		elseif (sEquip == "INVTYPE_SHIELD" or sEquip == "INVTYPE_WEAPONOFFHAND" or sEquip == "INVTYPE_HOLDABLE") then
			typeOfItem = "SecondaryHandSlot"
			iEPGPCost = GearingGuide.db.profile.custom.OffhandGP
		elseif (sEquip == "INVTYPE_2HWEAPON" or sEquip == "INVTYPE_RANGED") then
			typeOfItem = "MainHandSlot"
			iEPGPCost = GearingGuide.db.profile.custom.WeaponGP
		elseif (sEquip == "INVTYPE_WEAPONMAINHAND" or sEquip == "INVTYPE_WEAPON" or sEquip == "INVTYPE_RANGEDRIGHT") then
			typeOfItem = "MainHandSlot"
			iEPGPCost = GearingGuide.db.profile.custom.MainhandGP
		else
			iEPGPCost = 0
		end
	else
		local gpCost = 0
		if (iRarity == 4) then
			gpCost = (dropppediLevel - 1.3) / 1.3
		elseif (iRarity == 3) then
			gpCost = (dropppediLevel - 1.84) / 1.6
		elseif (iRarity == 2) then
			gpCost = (dropppediLevel - 4) / 2
		end
		gpCost = (gpCost * gpCost) * 0.04
		if (sType == "Miscellaneous") then
			local name, left = strsplit(" ", sName, 2)
			if (name == "Gauntlets") then
				typeOfItem = "HandsSlot"
				iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.GlovesGP)
			elseif (name == "Pauldrons" or name == "Mantle" or name == "Shoulders") then
				typeOfItem = "ShoulderSlot"
				iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.ShouldersGP)
			elseif (name == "Chestguard" or name == "Chest") then
				typeOfItem = "ChestSlot"
				iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.ChestGP)	
			elseif (name == "Leggings") then
				typeOfItem = "LegsSlot"
				iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.LegsGP)	
			elseif (name == "Crown" or name == "Helm") then
				typeOfItem = "HeadSlot"
				iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.HelmGP)		
			end
		elseif (sEquip == "INVTYPE_HEAD") then
			typeOfItem = "HeadSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.HelmGP)
		elseif (sEquip == "INVTYPE_LEGS") then
			typeOfItem = "LegsSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.LegsGP)	
		elseif (sEquip == "INVTYPE_CHEST" or sEquip == "INVTYPE_ROBE") then
			typeOfItem = "ChestSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.ChestGP)
		elseif (sEquip == "INVTYPE_NECK") then
			typeOfItem = "NeckSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.NeckGP)
		elseif (sEquip == "INVTYPE_CLOAK") then
			typeOfItem = "BackSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.CloakGP)
		elseif (sEquip == "INVTYPE_WRIST") then
			typeOfItem = "WristSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.WristGP)
		elseif (sEquip == "INVTYPE_FINGER") then
			typeOfItem = "Finger0Slot"
			typeOfItem1 = "Finger1Slot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.RingGP)
		elseif (sEquip == "INVTYPE_SHOULDER") then
			typeOfItem = "ShoulderSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.ShouldersGP)
		elseif (sEquip == "INVTYPE_HAND") then
			typeOfItem = "HandsSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.GlovesGP)
		elseif (sEquip == "INVTYPE_WAIST") then
			typeOfItem = "WaistSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.WaistGP)
		elseif (sEquip == "INVTYPE_FEET") then
			typeOfItem = "FeetSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.BootsGP)
		elseif (sEquip == "INVTYPE_TRINKET") then
			typeOfItem = "Trinket0Slot"
			typeOfItem1 = "Trinket1Slot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.TrinketGP)
		elseif (sEquip == "INVTYPE_SHIELD" or sEquip == "INVTYPE_WEAPONOFFHAND" or sEquip == "INVTYPE_HOLDABLE") then
			typeOfItem = "SecondaryHandSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.OffhandGP)
		elseif (sEquip == "INVTYPE_2HWEAPON" or sEquip == "INVTYPE_RANGED") then
			typeOfItem = "MainHandSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.WeaponGP)
		elseif (sEquip == "INVTYPE_WEAPONMAINHAND" or sEquip == "INVTYPE_WEAPON" or sEquip == "INVTYPE_RANGEDRIGHT") then
			typeOfItem = "MainHandSlot"
			iEPGPCost = floor(gpCost * GearingGuide.db.profile.epgp.MainhandGP)
		else
			iEPGPCost = 0
		end
	end
end

function LoadFramePosition()
	GearingGuide.db = LibStub("AceDB-3.0"):New("GearingGuideDB1", defaults)
	frame:ClearAllPoints()
	frame:SetPoint(GearingGuide.db.profile.point, UIParent, GearingGuide.db.profile.relPoint, GearingGuide.db.profile.x, GearingGuide.db.profile.y)
end

function SaveFramePosition()
	local point, _, relativePoint, xOffset, yOffset = frame:GetPoint()
	if (GearingGuide.db.profile.x ~= xOffset) or (GearingGuide.db.profile.y ~= yOffset) then
		GearingGuide.db.profile.point = point
		GearingGuide.db.profile.relPoint = relativePoint
		GearingGuide.db.profile.x = xOffset
		GearingGuide.db.profile.y = yOffset
	end
end

function tablelength(T) 
	local c = 0 
	for _ in pairs(T) do c = c + 1 end 
	return c 
end

function WishListFrame()
	isOpen = true				
	local wishFrame = AceGUI:Create("Frame")
	firstcheck = false 

	wishFrame:SetTitle("Wish List")
	wishFrame:SetCallback("OnClose", function(frame) isOpen = false AceGUI:Release(wishFrame) end)			
	wishFrame:SetLayout("Flow")
	wishFrame:SetWidth(400)
	wishFrame:SetHeight(500)
	wishFrame:EnableResize(Hide)
	
	wishText = AceGUI:Create("EditBox")
	wishText:SetLabel("Enter Item:")
	wishFrame:AddChild(wishText)

	local useList = {["choice1"] = "Main Spec", ["choice2"] = "Off Spec", ["choice3"] ="Transmog"}

	local wishDrop = AceGUI:Create("Dropdown")
	wishDrop:SetLabel("What would you like the item for:")
	wishDrop:SetList(useList)
	wishDrop:SetValue("choice1")
	wishFrame:AddChild(wishDrop)

	local wishGroup = AceGUI:Create("InlineGroup")
	wishGroup:SetTitle("Wish List Items")
	wishGroup:SetFullWidth(wishFrame)
	wishGroup:SetFullHeight(true)
	wishGroup:SetLayout("Fill")
	wishFrame:AddChild(wishGroup)
	
	wishText:SetCallback("OnEnterPressed", function(wishText)
	local name, link = GetItemInfo(wishText:GetText())
	if ( name ~= nil ) then
		if (IsEquippableItem(link) ~= nil) then 
			table.insert(GearingGuide.db.profile.wishlist.items, {name = link, use = useList[wishDrop:GetValue()]})
			wishText:SetText("")
			wishFrame:SetStatusText("") 
			ItemList(wishFrame, wishGroup)
			droppedText = ""
		else
			wishFrame:SetStatusText("You can't use this item")
		end
	else
		wishFrame:SetStatusText("Item doesn't exist")
	end 
	end)

	if (tablelength(GearingGuide.db.profile.wishlist.items) > 0) then
		ItemList(wishFrame, wishGroup)
	end
end

function ItemList(wishframe, container)	
	container:ReleaseChildren()

	local scrollList = AceGUI:Create("ScrollFrame")
	scrollList:SetLayout("Flow")
	container:AddChild(scrollList)

	for i, v in pairs(GearingGuide.db.profile.wishlist.items) do
		local itemList = AceGUI:Create("InteractiveLabel")
		itemList:SetText(v.name)
		itemList:SetFullWidth(true)
		itemList:SetFontObject(GameFontNormal)
		itemList:SetCallback("OnClick", function(button) GearingGuide:Print("Deleted this: "..v.name) table.remove(GearingGuide.db.profile.wishlist.items, i) GameTooltip:Hide() ItemList(wishframe, container) end)
		itemList:SetCallback("OnEnter", function(itemList) GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR") GameTooltip:SetHyperlink(v.name) end)
		itemList:SetCallback("OnLeave", function(itemList) GameTooltip:Hide() end)
		scrollList:AddChild(itemList)

		local itemSpacer = AceGUI:Create("Label")
		itemSpacer:SetText(v.use)
		scrollList:AddChild(itemSpacer)
	end
end

function RemoveUnderPrio()
	for i, v in ipairs(tablePrio) do
		if (v.prio < 5) then
			table.remove(tablePrio, i)
			RemoveUnderPrio()
			break			
		end
	end
end
