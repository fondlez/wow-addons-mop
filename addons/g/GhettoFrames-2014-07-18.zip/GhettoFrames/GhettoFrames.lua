local frame = CreateFrame("FRAME")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("PLAYER_FOCUS_CHANGED")
frame:RegisterEvent("UNIT_FACTION")
LoadAddOn("Blizzard_ArenaUI")



local function eventHandler(self, event, ...)
    TargetFrameNameBackground:SetVertexColor(0, 0, 0, 0.0)
	TargetFrameNameBackground:SetHeight(18)
	FocusFrameNameBackground:SetVertexColor(0, 0, 0, 0.0)
	FocusFrameNameBackground:SetHeight(18)       
	TargetFrameBackground:SetHeight(41)
	FocusFrameBackground:SetHeight(41)
end

frame:SetScript("OnEvent", eventHandler)
PlayerFrameTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame")
hooksecurefunc ("TargetFrame_CheckClassification", function (self, forceNormalTexture)
    local classification = UnitClassification(self.unit);
	--[[
    self.nameBackground:Show();
    self.manabar:Show();
    self.manabar.TextString:Show();
    self.threatIndicator:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Flash");
	]]--
    if ( forceNormalTexture ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame");
    elseif ( classification == "minus" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame-Minus");
        self.nameBackground:Hide();
        self.manabar:Hide();
        self.manabar.TextString:Hide();
        forceNormalTexture = true;
    elseif ( classification == "worldboss" or classification == "elite" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame-Elite");
    elseif ( classification == "rareelite" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame-Rare-Elite");
    elseif ( classification == "rare" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame-Rare");
    else
        self.borderTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-TargetingFrame");
        forceNormalTexture = true;
    end
end)

--TEST Pet
hooksecurefunc("PetFrame_Update", function(self, override)
	if ( (not PlayerFrame.animating) or (override) ) then
        if ( UnitIsVisible(self.unit) and PetUsesPetFrame() and not PlayerFrame.vehicleHidesPet ) then
            if ( self:IsShown() ) then
                UnitFrame_Update(self);
            else
                self:Show();
            end
            --self.flashState = 1;
            --self.flashTimer = PET_FLASH_ON_TIME;
            if ( UnitPowerMax(self.unit) == 0 ) then
                PetFrameTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-SmallTargetingFramex-NoMana");
                PetFrameManaBarText:Hide();
            else
                PetFrameTexture:SetTexture("Interface\\AddOns\\GhettoFrames\\TargetingFrame\\UI-SmallTargetingFramex");
            end
            PetAttackModeTexture:Hide();
 
            RefreshDebuffs(self, self.unit, nil, nil, true);
        else
            self:Hide();
        end
    end
end)



 



--castbar
--[[
CastingBarFrame:ClearAllPoints()
CastingBarFrame:SetPoint("CENTER",UIParent,"CENTER", 0, -250)
CastingBarFrame.SetPoint = function() end
]]--
--Hideshit

PetName:ClearAllPoints()
PetName:SetPoint("CENTER", PetFrame, "CENTER", 14, 19)
PetName.SetPoint = function() end

PlayerPVPIcon:SetAlpha(0)
TargetFrameTextureFramePVPIcon:SetAlpha(0)
FocusFrameTextureFramePVPIcon:SetAlpha(0)

hooksecurefunc(PlayerPVPTimerText, "SetFormattedText", function(self)
     self.timeLeft = nil
     self:Hide()
end)

local noop = function() return end
for _, objname in ipairs({
	"PlayerAttackGlow",
	"PetAttackModeTexture",
	"PlayerRestGlow",
	"PlayerRestIcon",
	"PlayerStatusGlow",
	"PlayerStatusTexture",
	"PlayerAttackBackground",
	"PlayerFrameGroupIndicator",	
	"PlayerFrameFlash",
	"TargetFrameFlash",
	"FocusFrameFlash",
	"PetFrameFlash",
	"PlayerFrameRoleIcon",
	
}) do
	local obj = _G[objname]
	if obj then
		obj:Hide()
		obj.Show = noop
	end
end

--ToT move
TargetFrameToT:ClearAllPoints()
TargetFrameToT:SetPoint("CENTER", TargetFrame, "CENTER", 60, -45)

FocusFrameToT:ClearAllPoints()
FocusFrameToT:SetPoint("CENTER", FocusFrame, "CENTER", 60, -45)


--Names
TargetFrame.name:ClearAllPoints()
TargetFrame.name:SetPoint("CENTER", TargetFrame, "CENTER", -50, 35)
TargetFrame.name.SetPoint = function() end
FocusFrame.name:ClearAllPoints()
FocusFrame.name:SetPoint("CENTER", FocusFrame, "CENTER", -45, 35)
FocusFrame.name.SetPoint = function() end


--bars
--Player bars
PlayerFrameHealthBar:SetHeight(27)
PlayerFrameHealthBar:ClearAllPoints()
PlayerFrameHealthBar:SetPoint("CENTER", PlayerFrame, "CENTER", 50, 14)
PlayerFrameHealthBar.SetPoint = function() end

PlayerFrameManaBar:ClearAllPoints()
PlayerFrameManaBar:SetPoint("CENTER", PlayerFrame, "CENTER", 51, -7)
PlayerFrameManaBar.SetPoint = function() end

--Player Pet bars
PetFrameHealthBar:SetHeight(13)
PetFrameHealthBar:ClearAllPoints()
PetFrameHealthBar:SetPoint("CENTER", PetFrame, "CENTER", 16, 5)
PetFrameHealthBar.SetPoint = function() end

PetFrameManaBar:ClearAllPoints()
PetFrameManaBar:SetPoint("CENTER", PetFrame, "CENTER", 16, -7)
PetFrameManaBar.SetPoint = function() end


PetFrameHealthBar.TextString:ClearAllPoints()
PetFrameHealthBar.TextString:SetPoint("CENTER", PetFrameHealthBar, "CENTER", 0, 0)
PetFrameHealthBar.TextString.SetPoint = function() end
PetFrameManaBar.TextString:ClearAllPoints()
PetFrameManaBar.TextString:SetPoint("CENTER", PetFrameManaBar, "CENTER", 0, 0)
PetFrameManaBar.TextString.SetPoint = function() end

--Target bars
TargetFrameHealthBar:SetHeight(27)
TargetFrameHealthBar:ClearAllPoints()
TargetFrameHealthBar:SetPoint("CENTER", TargetFrame, "CENTER", -50, 14)
TargetFrameHealthBar.SetPoint = function() end

TargetFrameTextureFrameDeadText:ClearAllPoints()
TargetFrameTextureFrameDeadText:SetPoint("CENTER", TargetFrameHealthBar, "CENTER", 0, 0)
TargetFrameTextureFrameDeadText.SetPoint = function() end

TargetFrameManaBar:ClearAllPoints()
TargetFrameManaBar:SetPoint("CENTER", TargetFrame, "CENTER", -51, -7)
TargetFrameManaBar.SetPoint = function() end

TargetFrameNumericalThreat:SetScale(0.9)
TargetFrameNumericalThreat:ClearAllPoints()
TargetFrameNumericalThreat:SetPoint("CENTER", TargetFrame, "CENTER", 44, 48)
TargetFrameNumericalThreat.SetPoint = function() end

--Focus bars
FocusFrameHealthBar:SetHeight(27)
FocusFrameHealthBar:ClearAllPoints()
FocusFrameHealthBar:SetPoint("CENTER", FocusFrame, "CENTER", -50, 14)
FocusFrameHealthBar.SetPoint = function() end

FocusFrameTextureFrameDeadText:ClearAllPoints()
FocusFrameTextureFrameDeadText:SetPoint("CENTER", FocusFrameHealthBar, "CENTER", 0, 0)
FocusFrameTextureFrameDeadText.SetPoint = function() end

FocusFrameManaBar:ClearAllPoints()
FocusFrameManaBar:SetPoint("CENTER", FocusFrame, "CENTER", -51, -7)
FocusFrameManaBar.SetPoint = function() end

FocusFrameNumericalThreat:ClearAllPoints()
FocusFrameNumericalThreat:SetPoint("CENTER", FocusFrame, "CENTER", 44, 48)
FocusFrameNumericalThreat.SetPoint = function() end





--Textstrings
--Fonts
PlayerFrameHealthBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
TargetFrameHealthBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
FocusFrameHealthBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
TargetFrameManaBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
PlayerFrameManaBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
FocusFrameManaBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")

TargetFrameHealthBar.TextString:ClearAllPoints()
TargetFrameHealthBar.TextString:SetPoint("CENTER", TargetFrame, "CENTER", -53, 12)
TargetFrameHealthBar.TextString.SetPoint = function() end

PlayerFrameHealthBar.TextString:ClearAllPoints()
PlayerFrameHealthBar.TextString:SetPoint("CENTER", PlayerFrame, "CENTER", 53, 12)
PlayerFrameHealthBar.TextString.SetPoint = function() end

FocusFrameHealthBar.TextString:ClearAllPoints()
FocusFrameHealthBar.TextString:SetPoint("CENTER", FocusFrame, "CENTER", -53, 12)
FocusFrameHealthBar.TextString.SetPoint = function() end

PlayerFrameManaBar.TextString:ClearAllPoints()
PlayerFrameManaBar.TextString:SetPoint("CENTER", PlayerFrame, "CENTER", 53, -7)
PlayerFrameManaBar.TextString.SetPoint = function() end

TargetFrameManaBar.TextString:ClearAllPoints()
TargetFrameManaBar.TextString:SetPoint("CENTER", TargetFrame, "CENTER", -50, -7)
TargetFrameManaBar.TextString.SetPoint = function() end

FocusFrameManaBar.TextString:ClearAllPoints()
FocusFrameManaBar.TextString:SetPoint("CENTER", FocusFrame, "CENTER", -50, -7)
FocusFrameManaBar.TextString.SetPoint = function() end




--Resource Format
FrameList = {"Target", "Focus", "Player"}
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", function(statusFrame, textString, value, valueMin, valueMax)	 
	for i = 1, select("#", unpack(FrameList)) do
		local FrameName = (select(i, unpack(FrameList)))
		if (UnitPowerType(FrameName)==0) then --mana
			_G[FrameName.."FrameManaBar"].TextString:SetText(string.format("%.0f%%",(UnitMana(FrameName)/UnitManaMax(FrameName))*100))
		elseif (UnitPowerType(FrameName)==1 or UnitPowerType(FrameName)==2 or UnitPowerType(FrameName)==3 or UnitPowerType(FrameName)==6) then 
			_G[FrameName.."FrameManaBar"].TextString:SetText(AbbreviateLargeNumbers(UnitMana(FrameName)))
		end
		if (UnitManaMax(FrameName)==0) then
		_G[FrameName.."FrameManaBar"].TextString:SetText(" ")
	end
	end
	
end)




GhettoFrames = {};
 GhettoFrames.panel = CreateFrame( "Frame", "GhettoFrames", UIParent );
GhettoFrames.panel.name = "GhettoFrames";
InterfaceOptions_AddCategory(GhettoFrames.panel);
 
GhettoFrames.childpanel = CreateFrame( "Frame", "General",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "General";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);

GhettoFrames.childpanel = CreateFrame( "Frame", "GhettoPlayerFrame",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "Player Frame Settings";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);
	
GhettoFrames.childpanel = CreateFrame( "Frame", "TargetCastbar",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "Target Frame Settings";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);
 
GhettoFrames.childpanel = CreateFrame( "Frame", "GhettoFocusFrame",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "Focus Frame Settings";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);

GhettoFrames.childpanel = CreateFrame( "Frame", "GhettoPetFrame",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "Pet Frame Settings";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);

GhettoFrames.childpanel = CreateFrame( "Frame", "GhettoArenaFrame",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "Arena Frames Settings";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);

GhettoFrames.childpanel = CreateFrame( "Frame", "GhettoPartyFrame",  GhettoFrames.panel);
GhettoFrames.childpanel.name = "Party Frames Settings";
GhettoFrames.childpanel.parent = GhettoFrames.panel.name;
InterfaceOptions_AddCategory(GhettoFrames.childpanel);








	

	SlashCmdList.GhettoFrames = function()
		InterfaceOptionsFrame_OpenToCategory(GhettoFrames.panel)
		InterfaceOptionsFrame_OpenToCategory(GhettoFrames.panel)
	end
	SLASH_GhettoFrames1 = "/ghettoframes"
	SLASH_GhettoFrames1 = "/gf"




-----------------------------
---##ADDON RELATED STUFF##---
-----------------------------

GhettoFramesSaveX = {
	["castby"] = 55,
	["fcastbx"] = -195,
	["palaspecialx"] = 0,
	["targetoffocus"] = 1,
	["classcolorttot"] = 1,
	["classcolorftot"] = 1,
	["castbx"] = -15,
	["classcolorparty"] = 1,
	["playername"] = 1,
	["palaspecialy"] = 0,
	["fcastby"] = 0,
	["classcolortarget"] = 1,
	["framescaletarget"] = 1.176947474479675,
	["specialx"] = 0,
	["framescalefocus"] = 1.176947474479675,
	["classcolorFocus"] = 1,
	["specialy"] = 0,
	["monkspecialx"] = 0,
	["framescaleplayer"] = 1.176947474479675,
	["targetoftarget"] = 1,
	["classcolorarena"] = 1,
	["monkspecialy"] = 0,
	["classcolor"] = 1,
	["playerspecialbar"] = 1,
	["classportraits"] = 0,
	["playerhitindi"] = 1,
	["bartex"] = 4,
	["classcolorplayer"] = 1,
	["darkentextures"] = 0.9,
	["hformat"] = 5,
}
	
	GhettoFramesSaveX.darkentextures=0.9;
	
unserAddon = {}

-- function to initialize when addon has loaded
function unserAddon:Init(event, addon)

if (event == "ADDON_LOADED" and addon == "GhettoFrames") then
	
print("|cff71C671GhettoFrames|cffbbbbbb loaded. Options: |cff71C671/gf")

	unserAddon:CreateGUI(unserFrameAddon)
	if (GhettoFramesSaveX.castbx~=0 or GhettoFramesSaveX.castby~=0) then 
		TargetFrameSpellBar:ClearAllPoints()
		TargetFrameSpellBar:SetPoint("CENTER", TargetFrame, "CENTER", GhettoFramesSaveX.castbx,GhettoFramesSaveX.castby)
		TargetFrameSpellBar.SetPoint = function() end
	end
	if (GhettoFramesSaveX.framescaletarget and GhettoFramesSaveX.framescaletarget~=1) then
		TargetFrame:SetScale(GhettoFramesSaveX.framescaletarget)
	end
	if (GhettoFramesSaveX.framescalefocus and GhettoFramesSaveX.framescalefocus~=1) then
		FocusFrame:SetScale(GhettoFramesSaveX.framescalefocus)
	end
	if (GhettoFramesSaveX.framescaleplayer and GhettoFramesSaveX.framescaleplayer~=1) then
		PlayerFrame:SetScale(GhettoFramesSaveX.framescaleplayer)
	end
	if (GhettoFramesSaveX.darkentextures and GhettoFramesSaveX.darkentextures~=1) then
	
		for i, v in pairs({PlayerFrameTexture, TargetFrameTextureFrameTexture, PetFrameTexture, PartyMemberFrame1Texture, PartyMemberFrame2Texture, PartyMemberFrame3Texture, PartyMemberFrame4Texture,
                        PartyMemberFrame1PetFrameTexture, PartyMemberFrame2PetFrameTexture, PartyMemberFrame3PetFrameTexture, PartyMemberFrame4PetFrameTexture, FocusFrameTextureFrameTexture,
                        TargetFrameToTTextureFrameTexture, FocusFrameToTTextureFrameTexture
	}) do
                        v:SetVertexColor(GhettoFramesSaveX.darkentextures, GhettoFramesSaveX.darkentextures, GhettoFramesSaveX.darkentextures)
    end
	end
	
	if (GhettoFramesSaveX.fcastbx~=0 or GhettoFramesSaveX.fcastby~=0) then 
		FocusFrameSpellBar:ClearAllPoints()
		FocusFrameSpellBar:SetPoint("CENTER", FocusFrame, "CENTER", GhettoFramesSaveX.fcastbx,GhettoFramesSaveX.fcastby)
		FocusFrameSpellBar.SetPoint = function() end
	end
	if (GhettoFramesSaveX.specialx~=0 or GhettoFramesSaveX.specialy~=0 or GhettoFramesSaveX.monkspecialy~=0 or GhettoFramesSaveX.monkspecialx~=0 or GhettoFramesSaveX.palaspecialy~=0 or GhettoFramesSaveX.palaspecialx~=0) then 
		--[[ShardBarFrame:ClearAllPoints()
		ShardBarFrame:SetPoint("CENTER", PlayerFrame, "CENTER", GhettoFramesSaveX.specialx,GhettoFramesSaveX.specialy)
		ShardBarFrame.SetPoint = function() end
		PriestBarFrame:ClearAllPoints()
		PriestBarFrame:SetPoint("CENTER", PlayerFrame, "CENTER", GhettoFramesSaveX.monkspecialx,GhettoFramesSaveX.specialy)
		PriestBarFrame.SetPoint = function() end
		MonkHarmonyBar:ClearAllPoints()
		MonkHarmonyBar:SetPoint("CENTER", PlayerFrame, "CENTER", GhettoFramesSaveX.monkspecialx,GhettoFramesSaveX.monkspecialy)
		MonkHarmonyBar.SetPoint = function() end
		PaladinPowerBar:ClearAllPoints()
		PaladinPowerBar:SetPoint("CENTER", PlayerFrame, "CENTER", GhettoFramesSaveX.palaspecialx,GhettoFramesSaveX.palaspecialy)
		PaladinPowerBar.SetPoint = function() end
		--]]
		
		PetFrame:ClearAllPoints()
        PetFrame:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 80, -65);
		PetFrame.SetPoint = function() end
		PlayerName:ClearAllPoints()
		PlayerName:SetPoint("CENTER", PlayerFrame, "CENTER", 45, 60)
		PlayerName.SetPoint = function() end
		-- Following part is taken from Spyro_'s "ResourcesOnTop"
		local function yOffset(Frame, Offset)
			local P = { Frame:GetPoint() }
			Frame:SetPoint(P[1], P[2], P[3], P[4], Offset)
		end
		local function yInvertTexture(Texture)
			local Left, Top, _, Bottom, Right = Texture:GetTexCoord()
			Texture:SetTexCoord(Left, Right, Bottom, Top) -- Swapping parameters 3 & 4 (top & bottom)
		end
		local function yInvertAllTextures(Frame)
			for _, Region in pairs({ Frame:GetRegions() }) do
				if Region:GetObjectType() == "Texture" then yInvertTexture(Region) end
			end
		end

		-- Evento PLAYER_LOGIN
		-- Fires after PLAYER_ENTERING_WORLD after logging in and after /reloadui.

		-- Paladin Holy Power
		yOffset(PaladinPowerBar, 111)
		yOffset(PaladinPowerBarRune1, -5)
		yOffset(PaladinPowerBarRune4, 3)
		yOffset(PaladinPowerBarRune5, 3)
		yOffset(PaladinPowerBarBankBG, 7)
		yInvertAllTextures(PaladinPowerBar)
		yInvertTexture(PaladinPowerBarGlowBGTexture)
		for i = 1, 5 do yInvertTexture(_G["PaladinPowerBarRune"..i.."Texture"]) end

		-- Priest Shadow Orbs
		yOffset(PriestBarFrame, 131)
		yOffset(PriestBarFrameOrb1, -16)
		yInvertAllTextures(PriestBarFrame)
		for i = 1, 3 do
			yInvertAllTextures(_G["PriestBarFrameOrb"..i])
			yOffset(_G["PriestBarFrameOrb"..i].highlight, 8)
		end

		-- Warlock Shards
		yOffset(ShardBarFrame, 69)
		for i = 1, 4 do
			yInvertAllTextures(_G["ShardBarFrameShard"..i])
			yOffset(_G["ShardBarFrameShard"..i].shardFill, -5)
		end

		-- Warlock Burning Embers
		yOffset(BurningEmbersBarFrame, 63)
		yOffset(BurningEmbersBarFrameEmber1, 14)
		yInvertTexture(BurningEmbersBarFrame.background)
		for i = 1, 4 do yInvertAllTextures(_G["BurningEmbersBarFrameEmber"..i]) end

		-- Warlock Demonic Fury
		yOffset(DemonicFuryBarFrame, 82)

		-- DK Runes
		yOffset(RuneFrame, 99)

		-- Druid Eclipse
		yOffset(EclipseBarFrame, 108)

		-- Druid/Monk AlternatePowerBar
		yInvertAllTextures(PlayerFrameAlternateManaBar)
		yOffset(PlayerFrameAlternateManaBar, 79)
		yOffset(PlayerFrameAlternateManaBar.DefaultBorder, 4)
		yOffset(PlayerFrameAlternateManaBar.MonkBorder, 4)
		yOffset(PlayerFrameAlternateManaBar.MonkBackground, 4)
		local Offset = 79
		if MonkHarmonyBar:IsShown() then Offset = 100 end
		hooksecurefunc(PlayerFrameAlternateManaBar, "SetPoint", function(Bar) yOffset(Bar, Offset) end)

		-- Monk Chi
		yOffset(MonkHarmonyBar, 20)
		yInvertAllTextures(MonkHarmonyBar)
		for i = 1, 4 do yInvertAllTextures(_G["MonkHarmonyBarLightEnergy"..i]) end

		-- Monk Stagger Bar
		yOffset(MonkStaggerBarText, -4)
		yInvertAllTextures(MonkStaggerBar)
		hooksecurefunc(MonkStaggerBar, "SetPoint", function(Bar) yOffset(Bar, 104) end)

		-- Shaman Totems / Warrior Banners
		yOffset(TotemFrame, 112)
		for i = 1, 4 do
			yOffset(_G["TotemFrameTotem"..i.."Duration"], 44)
			yInvertTexture(select(2, _G["TotemFrameTotem"..i]:GetChildren()):GetRegions())
		end
		else 
		PlayerName:ClearAllPoints()
		PlayerName:SetPoint("CENTER", PlayerFrame, "CENTER", 50, 35)
		PlayerName.SetPoint = function() end
	end
	
	
	
	
	if (GhettoFramesSaveX.percentcolorplayer==1) then
			PlayerPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolortarget==1) then
			TargetPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolorfocus==1) then
			FocusPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolorarena==1) then
			ArenaPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolorparty==1) then
			PartyPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolorpet==1) then
			PetPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolortargettot==1) then
			TargetToTPercentcolorcheck:SetChecked()
	end
	if (GhettoFramesSaveX.percentcolorfocustot==1) then
			FocusToTPercentcolorcheck:SetChecked()
	end
	
	if (GhettoFramesSaveX.classcolor~=nil) then
		classcolorcheck:SetChecked()
		
		local function colour(statusbar, unit)
		if (unit~=mouseover) then
			local _, class, c
			
				local value = UnitHealth(unit);
				local min, max = statusbar:GetMinMaxValues();
			
				local r, g, b;
				
				if ( (value < min) or (value > max) ) then
					return;
				end
				if ( (max - min) > 0 ) then
					value = (value - min) / (max - min);
				else
					value = 0;
				end
				if(value > 0.5) then
					r = (1.0 - value) * 2;
					g = 1.0;
				else
					r = 1.0;
					g = value * 2;
				end
				b = 0.0;
			
			
			
		
				
				
				
		
		if (UnitIsPlayer(unit) and UnitIsConnected(unit) and unit == statusbar.unit and UnitClass(unit)) then
		
			_, class = UnitClass(unit)
			c = CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[class] or RAID_CLASS_COLORS[class]
			statusbar:SetStatusBarColor(c.r, c.g, c.b)
			if (GhettoFramesSaveX.classcolortarget==nil) then
				if (GhettoFramesSaveX.percentcolortarget==1) then
					if (statusbar==TargetFrameHealthBar) then
						TargetFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==TargetFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						TargetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						TargetFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						TargetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						TargetFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
			else 
				targetclasscolorcheck:SetChecked()
			end
			if (GhettoFramesSaveX.classcolorplayer==nil) then
				if (GhettoFramesSaveX.percentcolorplayer==1) then
					
					if (statusbar==PlayerFrameHealthBar) then
						PlayerFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
					if (statusbar==PlayerFrameHealthBar) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						PlayerFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						PlayerFrameHealthBar:SetStatusBarColor(0,1,0)
					end
					end
				end
				
				
			else 
				PlayerClasscolorcheck:SetChecked()
			end
			
			if (GhettoFramesSaveX.classcolorFocus==nil) then
				if (GhettoFramesSaveX.percentcolorfocus==1) then
				
					if (statusbar==FocusFrameHealthBar) then
						FocusFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==FocusFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						FocusFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						FocusFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						FocusFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						FocusFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
			else 
				focusclasscolorcheck:SetChecked()
			end
			if (GhettoFramesSaveX.classcolorarena==nil) then
				if (GhettoFramesSaveX.percentcolorarena==1) then
				
					if (statusbar==ArenaEnemyFrame1HealthBar) then
						ArenaEnemyFrame1HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame2HealthBar) then
						ArenaEnemyFrame2HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame3HealthBar) then
						ArenaEnemyFrame3HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame4HealthBar) then
						ArenaEnemyFrame4HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame5HealthBar) then
						ArenaEnemyFrame5HealthBar:SetStatusBarColor(r, g, b);
					end
					
				else
				if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						if (statusbar==ArenaEnemyFrame1HealthBar) then
						ArenaEnemyFrame1HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame2HealthBar) then
						ArenaEnemyFrame2HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame3HealthBar) then
						ArenaEnemyFrame3HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame4HealthBar) then
						ArenaEnemyFrame4HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame5HealthBar) then
						ArenaEnemyFrame5HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
					else
						if (statusbar==ArenaEnemyFrame1HealthBar) then
						ArenaEnemyFrame1HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame2HealthBar) then
						ArenaEnemyFrame2HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame3HealthBar) then
						ArenaEnemyFrame3HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame4HealthBar) then
						ArenaEnemyFrame4HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame5HealthBar) then
						ArenaEnemyFrame5HealthBar:SetStatusBarColor(1,0,0)
						end
				end
				end
			else 
				arenaclasscolorcheck:SetChecked()
			end
			
			if (GhettoFramesSaveX.classcolorparty==nil) then
				if (GhettoFramesSaveX.percentcolorparty==1) then
				
					if (statusbar==PartyMemberFrame1HealthBar) then
						PartyMemberFrame1HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame2HealthBar) then
						PartyMemberFrame2HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame3HealthBar) then
						PartyMemberFrame3HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame4HealthBar) then
						PartyMemberFrame4HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame5HealthBar) then
						PartyMemberFrame5HealthBar:SetStatusBarColor(r, g, b);
					end
					
				else
				if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyr) then
						if (statusbar==PartyMemberFrame1HealthBar) then
						PartyMemberFrame1HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyr)
						end
						if (statusbar==PartyMemberFrame2HealthBar) then
						PartyMemberFrame2HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
						end
						if (statusbar==PartyMemberFrame3HealthBar) then
						PartyMemberFrame3HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
						end
						if (statusbar==PartyMemberFrame4HealthBar) then
						PartyMemberFrame4HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
						end
						
					else
						if (statusbar==PartyMemberFrame1HealthBar) then
						PartyMemberFrame1HealthBar:SetStatusBarColor(0,1,0)
						end
						if (statusbar==PartyMemberFrame2HealthBar) then
						PartyMemberFrame2HealthBar:SetStatusBarColor(0,1,0)
						end
						if (statusbar==PartyMemberFrame3HealthBar) then
						PartyMemberFrame3HealthBar:SetStatusBarColor(0,1,0)
						end
						if (statusbar==PartyMemberFrame4HealthBar) then
						PartyMemberFrame4HealthBar:SetStatusBarColor(0,1,0)
						end
						
				end
				end
			else 
				partyclasscolorcheck:SetChecked()
			end
			
			if (GhettoFramesSaveX.classcolorttot==nil) then
				if (GhettoFramesSaveX.percentcolortargettot==1) then
				
					if (statusbar==TargetFrameToTHealthBar) then
						TargetFrameToTHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==TargetFrameToTHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						TargetFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						TargetFrameToTHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						TargetFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						TargetFrameToTHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
			else 
				Ttotclasscolorcheck:SetChecked()
			end
			
			if (GhettoFramesSaveX.classcolorftot==nil) then
				if (GhettoFramesSaveX.percentcolorfocustot==1) then
				
					if (statusbar==FocusFrameToTHealthBar) then
						FocusFrameToTHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==FocusFrameToTHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						FocusFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						FocusFrameToTHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						FocusFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						FocusFrameToTHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
			else 
				Ftotclasscolorcheck:SetChecked()
			end
			
			

			else --no player but classcolored
			
			if (UnitIsConnected(unit) and unit == statusbar.unit) then
				if (GhettoFramesSaveX.percentcolortargettot==1) then
				
					if (statusbar==TargetFrameToTHealthBar) then
						TargetFrameToTHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==TargetFrameToTHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						TargetFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						TargetFrameToTHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						TargetFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						TargetFrameToTHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				if (GhettoFramesSaveX.percentcolorpet==1) then
				
					if (statusbar==PetFrameHealthBar) then
						PetFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==PetFrameHealthBar) then
				
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						PetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						PetFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				
				
				
				if (GhettoFramesSaveX.percentcolorfocustot==1) then
				
					if (statusbar==FocusFrameToTHealthBar) then
						FocusFrameToTHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==FocusFrameToTHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						FocusFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						FocusFrameToTHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						FocusFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						FocusFrameToTHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				if (GhettoFramesSaveX.percentcolorfocus==1) then
					if (statusbar==FocusFrameHealthBar) then
						FocusFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==FocusFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						FocusFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						FocusFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						FocusFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						FocusFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				
				
				
				
				if (GhettoFramesSaveX.percentcolortarget==1) then
					if (statusbar==TargetFrameHealthBar) then
						TargetFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==TargetFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						TargetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						TargetFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						TargetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						TargetFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				
				end
			end

			
			
		
		end
		end
		
		hooksecurefunc("UnitFrameHealthBar_Update", colour)
		hooksecurefunc("HealthBar_OnValueChanged", function(self)
			colour(self, self.unit)
		end)
		else --no classcolored
		
		local function colourx(statusbar, unit)
		if (unit~=mouseover) then
				local value = UnitHealth(unit);
				local min, max = statusbar:GetMinMaxValues();
			
				local r, g, b;
				
				if ( (value < min) or (value > max) ) then
					return;
				end
				if ( (max - min) > 0 ) then
					value = (value - min) / (max - min);
				else
					value = 0;
				end
				if(value > 0.5) then
					r = (1.0 - value) * 2;
					g = 1.0;
				else
					r = 1.0;
					g = value * 2;
				end
				b = 0.0;
			
			if (UnitIsConnected(unit) and unit == statusbar.unit) then
			if (GhettoFramesSaveX.percentcolorplayer==1) then
				PlayerPercentcolorcheck:SetChecked();
					if (statusbar==PlayerFrameHealthBar) then
						PlayerFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==PlayerFrameHealthBar) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						PlayerFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						PlayerFrameHealthBar:SetStatusBarColor(0,1,0)
					end
					end
				end
				
				
				
				if (GhettoFramesSaveX.percentcolortargettot==1) then
				
					if (statusbar==TargetFrameToTHealthBar) then
						TargetFrameToTHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==TargetFrameToTHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						TargetFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						TargetFrameToTHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						TargetFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						TargetFrameToTHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				
				if (GhettoFramesSaveX.percentcolorfocustot==1) then
				
					if (statusbar==FocusFrameToTHealthBar) then
						FocusFrameToTHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==FocusFrameToTHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						FocusFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						FocusFrameToTHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						FocusFrameToTHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						FocusFrameToTHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				if (GhettoFramesSaveX.percentcolorfocus==1) then
				
					if (statusbar==FocusFrameHealthBar) then
						FocusFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==FocusFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						FocusFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						FocusFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						FocusFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						FocusFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
								
				
				
				if (GhettoFramesSaveX.percentcolortarget==1) then
					if (statusbar==TargetFrameHealthBar) then
						TargetFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==TargetFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						TargetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						TargetFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						TargetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						TargetFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				if (GhettoFramesSaveX.percentcolorpet==1) then
				
					if (statusbar==PetFrameHealthBar) then
						PetFrameHealthBar:SetStatusBarColor(r, g, b);
					end
				else 
				if (statusbar==PetFrameHealthBar) then
				if (not UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						PetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
					else
						PetFrameHealthBar:SetStatusBarColor(1,0,0)
					end
				end
				if (UnitIsFriend("player",unit)) then
					if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyg and GhettoFramesSaveX.colorpickenemyb) then
						PetFrameHealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
					else
						PetFrameHealthBar:SetStatusBarColor(0,1,0)
					end
				end
				end
				end
				
				
				if (GhettoFramesSaveX.percentcolorparty==1) then
				
					if (statusbar==PartyMemberFrame1HealthBar) then
						PartyMemberFrame1HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame2HealthBar) then
						PartyMemberFrame2HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame3HealthBar) then
						PartyMemberFrame3HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==PartyMemberFrame4HealthBar) then
						PartyMemberFrame4HealthBar:SetStatusBarColor(r, g, b);
					end
					
					
				else
				if (GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyr and GhettoFramesSaveX.colorpickenemyr) then
						if (statusbar==PartyMemberFrame1HealthBar) then
						PartyMemberFrame1HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyr)
						end
						if (statusbar==PartyMemberFrame2HealthBar) then
						PartyMemberFrame2HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
						end
						if (statusbar==PartyMemberFrame3HealthBar) then
						PartyMemberFrame3HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
						end
						if (statusbar==PartyMemberFrame4HealthBar) then
						PartyMemberFrame4HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickenemyr,GhettoFramesSaveX.colorpickenemyg,GhettoFramesSaveX.colorpickenemyb)
						end
						
					else
						if (statusbar==PartyMemberFrame1HealthBar) then
						PartyMemberFrame1HealthBar:SetStatusBarColor(0,1,0)
						end
						if (statusbar==PartyMemberFrame2HealthBar) then
						PartyMemberFrame2HealthBar:SetStatusBarColor(0,1,0)
						end
						if (statusbar==PartyMemberFrame3HealthBar) then
						PartyMemberFrame3HealthBar:SetStatusBarColor(0,1,0)
						end
						if (statusbar==PartyMemberFrame4HealthBar) then
						PartyMemberFrame4HealthBar:SetStatusBarColor(0,1,0)
						end
						
				end
				end
			
			
			
			if (GhettoFramesSaveX.percentcolorarena==1) then
				
					if (statusbar==ArenaEnemyFrame1HealthBar) then
						ArenaEnemyFrame1HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame2HealthBar) then
						ArenaEnemyFrame2HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame3HealthBar) then
						ArenaEnemyFrame3HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame4HealthBar) then
						ArenaEnemyFrame4HealthBar:SetStatusBarColor(r, g, b);
					end
					if (statusbar==ArenaEnemyFrame5HealthBar) then
						ArenaEnemyFrame5HealthBar:SetStatusBarColor(r, g, b);
					end
					
				else
				if (GhettoFramesSaveX.colorpickfriendr and GhettoFramesSaveX.colorpickfriendg and GhettoFramesSaveX.colorpickfriendb) then
						if (statusbar==ArenaEnemyFrame1HealthBar) then
						ArenaEnemyFrame1HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame2HealthBar) then
						ArenaEnemyFrame2HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame3HealthBar) then
						ArenaEnemyFrame3HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame4HealthBar) then
						ArenaEnemyFrame4HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
						if (statusbar==ArenaEnemyFrame5HealthBar) then
						ArenaEnemyFrame5HealthBar:SetStatusBarColor(GhettoFramesSaveX.colorpickfriendr,GhettoFramesSaveX.colorpickfriendg,GhettoFramesSaveX.colorpickfriendb)
						end
					else
						if (statusbar==ArenaEnemyFrame1HealthBar) then
						ArenaEnemyFrame1HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame2HealthBar) then
						ArenaEnemyFrame2HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame3HealthBar) then
						ArenaEnemyFrame3HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame4HealthBar) then
						ArenaEnemyFrame4HealthBar:SetStatusBarColor(1,0,0)
						end
						if (statusbar==ArenaEnemyFrame5HealthBar) then
						ArenaEnemyFrame5HealthBar:SetStatusBarColor(1,0,0)
						end
				end
				end
			
				
				end
				
				
				
				
				
				
			end
		end
			
		
			

		hooksecurefunc("UnitFrameHealthBar_Update", colourx)
		hooksecurefunc("HealthBar_OnValueChanged", function(self)
			colourx(self, self.unit)
		end)
		end
		
	
	
	if (GhettoFramesSaveX.playername~=nil) then
		PlayerName:Show()
		playernamecheck:SetChecked()
	else
		PlayerName:Hide()
		
	end
	
	if (GhettoFramesSaveX.petname~=nil) then
		PetName:Show()
		petnamecheck:SetChecked()
	else
		PetName:Hide()
		
	end
	if (GhettoFramesSaveX.targetoftarget~=nil) then
				TargetFrameToT:SetAlpha(100)
		targettotcheck:SetChecked()
	
		
	end
	
	if (GhettoFramesSaveX.targetoffocus~=nil) then
		
		FocusFrameToT:SetAlpha(100)
		focustotcheck:SetChecked()
	
		
	end
	if (GhettoFramesSaveX.playerspecialbar~=nil) then
		specialbarcheck:SetChecked()
	else
		local nooop = function() return end
		for _, objname in ipairs({
			"MonkHarmonyBar",
			"PriestBarFrame",
			"PaladinPowerBar",
			"ShardBarFrame",

		}) do
			local obj = _G[objname]
			if obj then
				obj:Hide()
				obj.Show = nooop
			end
		end
		
	end
	if (GhettoFramesSaveX.classportraits~=nil) then
			Portraitcheck:SetChecked()
			hooksecurefunc("UnitFramePortrait_Update",function(self)
			if self.portrait then
                if UnitIsPlayer(self.unit) then                         
                        local t = CLASS_ICON_TCOORDS[select(2, UnitClass(self.unit))]
                        if t then
                                self.portrait:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
                                self.portrait:SetTexCoord(unpack(t))
                        end
                else
                        self.portrait:SetTexCoord(0,1,0,1)
                end
			end
			end)	
			else 
			
	end
	if (GhettoFramesSaveX.playerhitindi~=nil) then
		playerhitindi:SetChecked()
		PlayerHitIndicator:SetText(nil)
		PlayerHitIndicator.SetText = function() end
	end
	if (GhettoFramesSaveX.pethitindi~=nil) then
		pethitindi:SetChecked()
		PetHitIndicator:SetText(nil)
		PetHitIndicator.SetText = function() end
	end
	
	
	if (GhettoFramesSaveX.bartex==1) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		
   end
   if (GhettoFramesSaveX.bartex==2) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		
   end
   if (GhettoFramesSaveX.bartex==3) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		
   end
   if (GhettoFramesSaveX.bartex==4) then 
		
   end
   if (GhettoFramesSaveX.bartex==5) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		
   end
   if (GhettoFramesSaveX.bartex==6) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		
   end
   if (GhettoFramesSaveX.bartex==7) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
	
   end
    if (GhettoFramesSaveX.bartex==8) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
	
   end
    if (GhettoFramesSaveX.bartex==9) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		
   end
    if (GhettoFramesSaveX.bartex==10) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		
   end
    if (GhettoFramesSaveX.bartex==11) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
   end
   if (GhettoFramesSaveX.bartex==12) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
   end
   if (GhettoFramesSaveX.bartex==13) then 
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
   end
  if (GhettoFramesSaveX.phformat==1) then--percent
  local Player="Player"
   		function UpdateHealthValues(...)
			if (0 < UnitHealth(Player)) then 
				local Health = UnitHealth(Player)
				local HealthMax = UnitHealthMax(Player)
				local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",HealthPercent).."%")
			end
		end
 hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
 end
  if (GhettoFramesSaveX.fhformat==1) then--percent
  local Focus="Focus"
   		function UpdateHealthValues(...)
			if (0 < UnitHealth(Focus)) then 
				local Health = UnitHealth(Focus)
				local HealthMax = UnitHealthMax(Focus)
				local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
				_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",HealthPercent).."%")
			end
		end
 hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
 end
  if (GhettoFramesSaveX.thformat==1) then--percent
  local Target="Target"
   		function UpdateHealthValues(...)
			if (0 < UnitHealth(Target)) then 
				local Health = UnitHealth(Target)
				local HealthMax = UnitHealthMax(Target)
				local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
				_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",HealthPercent).."%")
			end
		end
 hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
 end
   
   
   
      if (GhettoFramesSaveX.phformat==2) then--currenthealth
	  local Player="Player"
      function UpdateHealthValues(...)
	     if (0 < UnitHealth(Player)) then 
		 if UnitHealth(Player) < 1000 then
			local Health = UnitHealth(Player)
			local HealthMax = UnitHealthMax(Player)
			_G[Player.."FrameHealthBar"].TextString:SetText(Health)
		elseif (UnitHealth(Player) < 1000000) then
			local Health = (UnitHealth(Player))/1000
			local HealthMax = (UnitHealthMax(Player))/1000
			_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k")
		elseif (1000000<=UnitHealth(Player)) then
			local Health = (UnitHealth(Player))/1000000
			local HealthMax = (UnitHealthMax(Player))/1000000
			_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m")
		end      
end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

      if (GhettoFramesSaveX.thformat==2) then--currenthealth
	  local Target="Target"
      function UpdateHealthValues(...)
	     if (0 < UnitHealth(Target)) then 
		 if UnitHealth(Target) < 1000 then
			local Health = UnitHealth(Target)
			local HealthMax = UnitHealthMax(Target)
			_G[Target.."FrameHealthBar"].TextString:SetText(Health)
		elseif (UnitHealth(Target) < 1000000) then
			local Health = (UnitHealth(Target))/1000
			local HealthMax = (UnitHealthMax(Target))/1000
			_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k")
		elseif (1000000<=UnitHealth(Target)) then
			local Health = (UnitHealth(Target))/1000000
			local HealthMax = (UnitHealthMax(Target))/1000000
			_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m")
		end      
end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end


      if (GhettoFramesSaveX.fhformat==2) then--currenthealth
	  local Focus="Focus"
      function UpdateHealthValues(...)
	     if (0 < UnitHealth(Focus)) then 
		 if UnitHealth(Focus) < 1000 then
			local Health = UnitHealth(Focus)
			local HealthMax = UnitHealthMax(Focus)
			_G[Focus.."FrameHealthBar"].TextString:SetText(Health)
		elseif (UnitHealth(Focus) < 1000000) then
			local Health = (UnitHealth(Focus))/1000
			local HealthMax = (UnitHealthMax(Focus))/1000
			_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k")
		elseif (1000000<=UnitHealth(Focus)) then
			local Health = (UnitHealth(Focus))/1000000
			local HealthMax = (UnitHealthMax(Focus))/1000000
			_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m")
		end      
end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end
   
   
   if (GhettoFramesSaveX.phformat==3) then --currenthealth + percent
     local Player="Player"
         function UpdateHealthValues(...)
		 if (0 < UnitHealth(Player)) then 
	   if UnitHealth(Player) < 1000 then
			local Health = UnitHealth(Player)
			local HealthMax = UnitHealthMax(Player)
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			_G[Player.."FrameHealthBar"].TextString:SetText(Health.." ("..format("%.0f",HealthPercent).."%)")
		elseif (UnitHealth(Player) < 1000000) then
			local Health = (UnitHealth(Player))/1000
			local HealthMax = (UnitHealthMax(Player))/1000
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k ("..format("%.0f",HealthPercent).."%)")
		elseif (1000000<=UnitHealth(Player)) then
			local Health = (UnitHealth(Player))/1000000
			local HealthMax = (UnitHealthMax(Player))/1000000
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m ("..format("%.0f",HealthPercent).."%)")
		end      
end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end
   if (GhettoFramesSaveX.thformat==3) then --currenthealth + percent
     local Target="Target"
         function UpdateHealthValues(...)
		 if (0 < UnitHealth(Target)) then 
	   if UnitHealth(Target) < 1000 then
			local Health = UnitHealth(Target)
			local HealthMax = UnitHealthMax(Target)
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			_G[Target.."FrameHealthBar"].TextString:SetText(Health.." ("..format("%.0f",HealthPercent).."%)")
		elseif (UnitHealth(Target) < 1000000) then
			local Health = (UnitHealth(Target))/1000
			local HealthMax = (UnitHealthMax(Target))/1000
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k ("..format("%.0f",HealthPercent).."%)")
		elseif (1000000<=UnitHealth(Target)) then
			local Health = (UnitHealth(Target))/1000000
			local HealthMax = (UnitHealthMax(Target))/1000000
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m ("..format("%.0f",HealthPercent).."%)")
		end      
end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

   if (GhettoFramesSaveX.fhformat==3) then --currenthealth + percent
	  local Focus="Focus"
         function UpdateHealthValues(...)
		 if (0 < UnitHealth(Focus)) then 
	   if UnitHealth(Focus) < 1000 then
			local Health = UnitHealth(Focus)
			local HealthMax = UnitHealthMax(Focus)
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." ("..format("%.0f",HealthPercent).."%)")
		elseif (UnitHealth(Focus) < 1000000) then
			local Health = (UnitHealth(Focus))/1000
			local HealthMax = (UnitHealthMax(Focus))/1000
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k ("..format("%.0f",HealthPercent).."%)")
		elseif (1000000<=UnitHealth(Focus)) then
			local Health = (UnitHealth(Focus))/1000000
			local HealthMax = (UnitHealthMax(Focus))/1000000
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m ("..format("%.0f",HealthPercent).."%)")
		end      
end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end
   
   
   
   if (GhettoFramesSaveX.phformat==4) then --current health+maxhealth
     local Player="Player"
         function UpdateHealthValues(...)
	    if (0 < UnitHealth(Player)) then 
		if UnitHealth(Player) < 1000 then
			local Health = UnitHealth(Player)
			local HealthMax = UnitHealthMax(Player)
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			if (UnitHealthMax(Player)< 1000) then
				_G[Player.."FrameHealthBar"].TextString:SetText(Health.." / "..(HealthMax))
			elseif (UnitHealthMax(Player)< 1000000) then
				local HealthMax = UnitHealthMax(Player)/1000
				_G[Player.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."k")
			elseif (1000000<=UnitHealthMax(Player)) then
				local HealthMax = UnitHealthMax(Player)/1000000
				_G[Player.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."m")
			end
		elseif (UnitHealth(Player) < 1000000) then
			local Health = (UnitHealth(Player))/1000
			local HealthMax = (UnitHealthMax(Player))/1000
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			if (UnitHealthMax(Player)< 1000000) then
				local HealthMax = (UnitHealthMax(Player))/1000
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."k")
			elseif (1000000<=UnitHealthMax(Player)) then
				local HealthMax = UnitHealthMax(Player)/1000000
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."m")
			end
		elseif (1000000<=UnitHealth(Player)) then
			local Health = (UnitHealth(Player))/1000000
			local HealthMax = (UnitHealthMax(Player))/1000000
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m / "..format("%.0f",HealthMax).."m")
		end      
	end

end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

 if (GhettoFramesSaveX.thformat==4) then --current health+maxhealth
   local Target="Target"
         function UpdateHealthValues(...)
	    if (0 < UnitHealth(Target)) then 
		if UnitHealth(Target) < 1000 then
			local Health = UnitHealth(Target)
			local HealthMax = UnitHealthMax(Target)
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			if (UnitHealthMax(Target)< 1000) then
				_G[Target.."FrameHealthBar"].TextString:SetText(Health.." / "..(HealthMax))
			elseif (UnitHealthMax(Target)< 1000000) then
				local HealthMax = UnitHealthMax(Target)/1000
				_G[Target.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."k")
			elseif (1000000<=UnitHealthMax(Target)) then
				local HealthMax = UnitHealthMax(Target)/1000000
				_G[Target.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."m")
			end
		elseif (UnitHealth(Target) < 1000000) then
			local Health = (UnitHealth(Target))/1000
			local HealthMax = (UnitHealthMax(Target))/1000
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			if (UnitHealthMax(Target)< 1000000) then
				local HealthMax = (UnitHealthMax(Target))/1000
				_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."k")
			elseif (1000000<=UnitHealthMax(Target)) then
				local HealthMax = UnitHealthMax(Target)/1000000
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."m")
			end
		elseif (1000000<=UnitHealth(Target)) then
			local Health = (UnitHealth(Target))/1000000
			local HealthMax = (UnitHealthMax(Target))/1000000
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m / "..format("%.0f",HealthMax).."m")
		end      
	end

end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

 if (GhettoFramesSaveX.fhformat==4) then --current health+maxhealth
   local Focus="Focus"
         function UpdateHealthValues(...)
	    if (0 < UnitHealth(Focus)) then 
		if UnitHealth(Focus) < 1000 then
			local Health = UnitHealth(Focus)
			local HealthMax = UnitHealthMax(Focus)
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			if (UnitHealthMax(Focus)< 1000) then
				_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." / "..(HealthMax))
			elseif (UnitHealthMax(Focus)< 1000000) then
				local HealthMax = UnitHealthMax(Focus)/1000
				_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."k")
			elseif (1000000<=UnitHealthMax(Focus)) then
				local HealthMax = UnitHealthMax(Focus)/1000000
				_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."m")
			end
		elseif (UnitHealth(Focus) < 1000000) then
			local Health = (UnitHealth(Focus))/1000
			local HealthMax = (UnitHealthMax(Focus))/1000
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			if (UnitHealthMax(Focus)< 1000000) then
				local HealthMax = (UnitHealthMax(Focus))/1000
				_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."k")
			elseif (1000000<=UnitHealthMax(Focus)) then
				local HealthMax = UnitHealthMax(Focus)/1000000
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."m")
			end
		elseif (1000000<=UnitHealth(Focus)) then
			local Health = (UnitHealth(Focus))/1000000
			local HealthMax = (UnitHealthMax(Focus))/1000000
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m / "..format("%.0f",HealthMax).."m")
		end      
	end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

   
   
   
   
   
   
   
   if (GhettoFramesSaveX.phformat==5) then --current health+maxhealth+percent
     local Player="Player"
         function UpdateHealthValues(...)
		if (0 < UnitHealth(Player)) then 
	     if UnitHealth(Player) < 1000 then
			local Health = UnitHealth(Player)
			local HealthMax = UnitHealthMax(Player)
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			if (UnitHealthMax(Player)< 1000) then
				_G[Player.."FrameHealthBar"].TextString:SetText(Health.." / "..(HealthMax).." ("..format("%.0f",HealthPercent).."%)")
			elseif (UnitHealthMax(Player)< 1000000) then
				local HealthMax = UnitHealthMax(Player)/1000
				_G[Player.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."k ("..format("%.0f",HealthPercent).."%)")
			elseif (1000000<=UnitHealthMax(Player)) then
				local HealthMax = UnitHealthMax(Player)/1000000
				_G[Player.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
			end
		elseif (UnitHealth(Player) < 1000000) then
			local Health = (UnitHealth(Player))/1000
			local HealthMax = (UnitHealthMax(Player))/1000
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			if (UnitHealthMax(Player)< 1000000) then
				local HealthMax = (UnitHealthMax(Player))/1000
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."k ("..format("%.0f",HealthPercent).."%)")
			elseif (1000000<=UnitHealthMax(Player)) then
				local HealthMax = UnitHealthMax(Player)/1000000
				_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
			end
		elseif (1000000<=UnitHealth(Player)) then
			local Health = (UnitHealth(Player))/1000000
			local HealthMax = (UnitHealthMax(Player))/1000000
			local HealthPercent = (UnitHealth(Player)/UnitHealthMax(Player))*100
			_G[Player.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
		end  
	end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

if (GhettoFramesSaveX.thformat==5) then --current health+maxhealth+percent
  local Target="Target"
         function UpdateHealthValues(...)
		if (0 < UnitHealth(Target)) then 
	     if UnitHealth(Target) < 1000 then
			local Health = UnitHealth(Target)
			local HealthMax = UnitHealthMax(Target)
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			if (UnitHealthMax(Target)< 1000) then
				_G[Target.."FrameHealthBar"].TextString:SetText(Health.." / "..(HealthMax).." ("..format("%.0f",HealthPercent).."%)")
			elseif (UnitHealthMax(Target)< 1000000) then
				local HealthMax = UnitHealthMax(Target)/1000
				_G[Target.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."k ("..format("%.0f",HealthPercent).."%)")
			elseif (1000000<=UnitHealthMax(Target)) then
				local HealthMax = UnitHealthMax(Target)/1000000
				_G[Target.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
			end
		elseif (UnitHealth(Target) < 1000000) then
			local Health = (UnitHealth(Target))/1000
			local HealthMax = (UnitHealthMax(Target))/1000
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			if (UnitHealthMax(Target)< 1000000) then
				local HealthMax = (UnitHealthMax(Target))/1000
				_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."k ("..format("%.0f",HealthPercent).."%)")
			elseif (1000000<=UnitHealthMax(Target)) then
				local HealthMax = UnitHealthMax(Target)/1000000
				_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
			end
		elseif (1000000<=UnitHealth(Target)) then
			local Health = (UnitHealth(Target))/1000000
			local HealthMax = (UnitHealthMax(Target))/1000000
			local HealthPercent = (UnitHealth(Target)/UnitHealthMax(Target))*100
			_G[Target.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
		end  
	end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end

if (GhettoFramesSaveX.fhformat==5) then --current health+maxhealth+percent
  local Focus="Focus"
         function UpdateHealthValues(...)
		if (0 < UnitHealth(Focus)) then 
	     if UnitHealth(Focus) < 1000 then
			local Health = UnitHealth(Focus)
			local HealthMax = UnitHealthMax(Focus)
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			if (UnitHealthMax(Focus)< 1000) then
				_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." / "..(HealthMax).." ("..format("%.0f",HealthPercent).."%)")
			elseif (UnitHealthMax(Focus)< 1000000) then
				local HealthMax = UnitHealthMax(Focus)/1000
				_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."k ("..format("%.0f",HealthPercent).."%)")
			elseif (1000000<=UnitHealthMax(Focus)) then
				local HealthMax = UnitHealthMax(Focus)/1000000
				_G[Focus.."FrameHealthBar"].TextString:SetText(Health.." / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
			end
		elseif (UnitHealth(Focus) < 1000000) then
			local Health = (UnitHealth(Focus))/1000
			local HealthMax = (UnitHealthMax(Focus))/1000
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			if (UnitHealthMax(Focus)< 1000000) then
				local HealthMax = (UnitHealthMax(Focus))/1000
				_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."k ("..format("%.0f",HealthPercent).."%)")
			elseif (1000000<=UnitHealthMax(Focus)) then
				local HealthMax = UnitHealthMax(Focus)/1000000
				_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."k / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
			end
		elseif (1000000<=UnitHealth(Focus)) then
			local Health = (UnitHealth(Focus))/1000000
			local HealthMax = (UnitHealthMax(Focus))/1000000
			local HealthPercent = (UnitHealth(Focus)/UnitHealthMax(Focus))*100
			_G[Focus.."FrameHealthBar"].TextString:SetText(format("%.0f",Health).."m / "..format("%.0f",HealthMax).."m ("..format("%.0f",HealthPercent).."%)")
		end  
	end
end
hooksecurefunc("TextStatusBar_UpdateTextStringWithValues", UpdateHealthValues)
end







if (GhettoFramesSaveX.buffsizebutton~=nil) then
buffsizebutton:SetChecked()
hooksecurefunc("TargetFrame_UpdateAuraPositions", function(self, auraName, numAuras, numOppositeAuras,largeAuraList, updateFunc, maxRowWidth, offsetX)
    local AURA_OFFSET_Y = 3
    local LARGE_AURA_SIZE = GhettoFramesSaveX.buffsize*1.421
    local SMALL_AURA_SIZE = GhettoFramesSaveX.buffsize
    local size
    local offsetY = AURA_OFFSET_Y
    local rowWidth = 0
    local firstBuffOnRow = 1
    for i=1, numAuras do
     if ( largeAuraList[i] ) then
       size = LARGE_AURA_SIZE
       offsetY = AURA_OFFSET_Y + AURA_OFFSET_Y
     else
       size = SMALL_AURA_SIZE
     end
     if ( i == 1 ) then
       rowWidth = size
       self.auraRows = self.auraRows + 1
     else
       rowWidth = rowWidth + size + offsetX
     end
     if ( rowWidth > maxRowWidth ) then
       updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY)
       rowWidth = size
       self.auraRows = self.auraRows + 1
       firstBuffOnRow = i
       offsetY = AURA_OFFSET_Y
     else
       updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY)
     end
    end
	

    end)
	hooksecurefunc('TargetFrame_UpdateAuras', function(self)
        local frameStealable
        local frameName
        local icon
        local debuffType
        local selfName = self:GetName()
        local isEnemy = UnitIsEnemy(PlayerFrame.unit, self.unit)
        for i = 1, MAX_TARGET_BUFFS do
                _, _, icon, _, debuffType = UnitBuff(self.unit, i)
                frameName = selfName..'Buff'..i
                if ( icon and ( not self.maxBuffs or i <= self.maxBuffs ) ) then
                        frameStealable = _G[frameName..'Stealable']
                        if ( isEnemy and debuffType == 'Magic' ) then
                                frameStealable:Show()
								frameStealable:SetHeight(GhettoFramesSaveX.buffsize*1.4)
								frameStealable:SetWidth(GhettoFramesSaveX.buffsize*1.4)
                        else
                                frameStealable:Hide()
                        end
                end
        end
		
end)
	buffsizer:Show()
	else
	buffsizer:Hide()

end








end
end
-- create addon frame
local unserFrame = CreateFrame("Frame", "unserFrameAddon", UIParent)
unserFrame:SetScript("OnEvent", unserAddon.Init)
unserFrame:RegisterEvent("ADDON_LOADED")




-----------------------------
---##GUI FUNCTIONS##---------
-----------------------------
-- CreateGUI
function unserAddon:CreateGUI(frame)
-- General
local title = unserAddon:CreateFont(General, "title", "General Frame Scale", 20, -15, 25)

local generalframescaleslider = unserAddon:CreateSlider(General, "GeneralFrameScale", "General Frame Scale", 0.5, 2, 1, 60,-70)
generalframescaleslider:SetScript("OnValueChanged", function(self, value)
	TargetFrame:SetScale(value)
	PlayerFrame:SetScale(value)
	FocusFrame:SetScale(value)
	GhettoFramesSaveX.framescaletarget=value
	GhettoFramesSaveX.framescaleplayer=value	
	GhettoFramesSaveX.framescalefocus=value	
	getglobal(generalframescaleslider:GetName() .. 'Text'):SetText("Frame Scale: (" .. format("%.2f",value) .. ")");
end)

local title = unserAddon:CreateFont(General, "title", "Classcolored Healthbars", 20, -290, 25)

local Unlock = CreateFrame("CheckButton", "classcolorcheck", General, "UICheckButtonTemplate")
Unlock:ClearAllPoints()
 Unlock:SetPoint("CENTER", -280, -60)
 _G[Unlock:GetName() .. "Text"]:SetText("Classcolored Healthbars")
 function Unlock:OnClick()
	GhettoFramesSaveX.classcolor=Unlock:GetChecked();
	ReloadUI();
 end
Unlock:SetScript("OnClick", Unlock.OnClick)















-- TargetFrame Settings
local title = unserAddon:CreateFont(TargetCastbar, "title", "Target Frame Scale", 20, -15, 15)


--targetframescaleslider
local targetscaleslider = unserAddon:CreateSlider(TargetCastbar, "TargetScale", "TargetFrame Scale", 0.5, 2, GhettoFramesSaveX.framescaletarget, 60,-70)
targetscaleslider:SetScript("OnValueChanged", function(self, value)
	TargetFrame:SetScale(value)
	GhettoFramesSaveX.framescaletarget=value	
	getglobal(targetscaleslider:GetName() .. 'Text'):SetText("Target Frame Scale: (" .. format("%.2f",value) .. ")");
end)

local title = unserAddon:CreateFont(TargetCastbar, "title", "Classcolored Target Healtbar", 20, -125, 15) 


--targetclasscolorcheck
local TargetClasscolorcheck = CreateFrame("CheckButton", "targetclasscolorcheck", TargetCastbar, "UICheckButtonTemplate")
TargetClasscolorcheck:ClearAllPoints()
TargetClasscolorcheck:SetPoint("CENTER", -280, 105)
 _G[TargetClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Target Healthbar")
 function TargetClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolortarget=TargetClasscolorcheck:GetChecked();
	ReloadUI();
 end
TargetClasscolorcheck:SetScript("OnClick", TargetClasscolorcheck.OnClick)



local title = unserAddon:CreateFont(TargetCastbar, "title", "Target Castbar Position", 20, -285, 15) 

--tcbup
local tcbup = unserAddon:CreateButton(TargetCastbar, "tcbup", "Up", 90, 35, 105, -320)
tcbup:SetScript("OnClick", function() unserAddon:tcbup() end) 
--tcbdown
local tcbdown = unserAddon:CreateButton(TargetCastbar, "tcbdown", "Down", 90, 35, 105, -380)
tcbdown:SetScript("OnClick", function() unserAddon:tcbdown() end) 
--tcbright
local tcbright = unserAddon:CreateButton(TargetCastbar, "tcbright", "Right", 90, 35, 190, -350)
tcbright:SetScript("OnClick", function() unserAddon:tcbright() end) 
--tcbleft
local tcbleft = unserAddon:CreateButton(TargetCastbar, "tcbleft", "Left", 90, 35, 20, -350)
tcbleft:SetScript("OnClick", function() unserAddon:tcbleft() end)

local positiontext = unserAddon:CreateFont(TargetCastbar, "positiontext", "TargetFrame", 111, -360, 12) 



--FocusFrameSettings

local title = unserAddon:CreateFont(GhettoFocusFrame, "title", "Focus Frame Scale", 20, -15, 15)

--focusframescaleslider
local targetscaleslider2 = unserAddon:CreateSlider(GhettoFocusFrame, "Target2Scale", "FocusFrame Scale", 0.5, 2, GhettoFramesSaveX.framescalefocus, 60,-70)
targetscaleslider2:SetScript("OnValueChanged", function(self, value)
	FocusFrame:SetScale(value)
	GhettoFramesSaveX.framescalefocus=value	
	getglobal(targetscaleslider2:GetName() .. 'Text'):SetText("Focus Frame ScaleFrame Scale: (" .. format("%.2f",value) .. ")");
end)


local title = unserAddon:CreateFont(GhettoFocusFrame, "title", "Classcolored Focus Healtbar", 20, -125, 15) 


--focustclasscolorcheck
local FocusClasscolorcheck = CreateFrame("CheckButton", "focusclasscolorcheck", GhettoFocusFrame, "UICheckButtonTemplate")
FocusClasscolorcheck:ClearAllPoints()
FocusClasscolorcheck:SetPoint("CENTER", -280, 105)
 _G[FocusClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Focus Healthbar")
 function FocusClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolorFocus=FocusClasscolorcheck:GetChecked();
	ReloadUI();
 end
FocusClasscolorcheck:SetScript("OnClick", FocusClasscolorcheck.OnClick)



local title = unserAddon:CreateFont(GhettoFocusFrame, "title", "Focus Castbar Position", 20, -285, 15) 

--fcbup
local fcbup = unserAddon:CreateButton(GhettoFocusFrame, "fcbup", "Up", 90, 35, 105, -320)
fcbup:SetScript("OnClick", function() unserAddon:fcbup() end) 
--fcbdown
local fcbdown = unserAddon:CreateButton(GhettoFocusFrame, "fcbdown", "Down", 90, 35, 105, -380)
fcbdown:SetScript("OnClick", function() unserAddon:fcbdown() end) 
--fcbright
local fcbright = unserAddon:CreateButton(GhettoFocusFrame, "fcbright", "Right", 90, 35, 190, -350)
fcbright:SetScript("OnClick", function() unserAddon:fcbright() end) 
--fcbleft
local tcbleft = unserAddon:CreateButton(GhettoFocusFrame, "fcbleft", "Left", 90, 35, 20, -350)
fcbleft:SetScript("OnClick", function() unserAddon:fcbleft() end)

local positiontext = unserAddon:CreateFont(GhettoFocusFrame, "positiontext", "FocusFrame", 111, -360, 12) 




--Random Settings
local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "Show Player Name", 20, -15, 15)
local Unlock2 = CreateFrame("CheckButton", "playernamecheck", GhettoPlayerFrame, "UICheckButtonTemplate")
Unlock2:ClearAllPoints()
 Unlock2:SetPoint("CENTER", -280, 225)
 _G[Unlock2:GetName() .. "Text"]:SetText("Show Player Name")
 function Unlock2:OnClick()
	GhettoFramesSaveX.playername=Unlock2:GetChecked();
	if (GhettoFramesSaveX.playername~=nil) then
		
		PlayerName:Show()
		playernamecheck:SetChecked()
	else
		PlayerName:Hide()
		
	end
 end
Unlock2:SetScript("OnClick", Unlock2.OnClick)

--Random Settings
local title = unserAddon:CreateFont(GhettoPetFrame, "title", "Show Pet Name", 20, -15, 15)
local Unlock3 = CreateFrame("CheckButton", "petnamecheck", GhettoPetFrame, "UICheckButtonTemplate")
Unlock3:ClearAllPoints()
 Unlock3:SetPoint("CENTER", -280, 225)
 _G[Unlock3:GetName() .. "Text"]:SetText("Show Pet Name")
 function Unlock3:OnClick()
	GhettoFramesSaveX.petname=Unlock3:GetChecked();
	if (GhettoFramesSaveX.petname~=nil) then
		
		PetName:Show()
		petnamecheck:SetChecked()
	else
		PetName:Hide()
		
	end
 end
Unlock3:SetScript("OnClick", Unlock3.OnClick)




--playerclasscolorcheck
local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "Classcolored Player Healthbar", 20, -115, 15)
local PlayerClasscolorcheck = CreateFrame("CheckButton", "PlayerClasscolorcheck", GhettoPlayerFrame, "UICheckButtonTemplate")
PlayerClasscolorcheck:ClearAllPoints()
PlayerClasscolorcheck:SetPoint("CENTER", -280, 115)
 _G[PlayerClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Player Healthbar")
 function PlayerClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolorplayer=PlayerClasscolorcheck:GetChecked();
	ReloadUI();
 end
PlayerClasscolorcheck:SetScript("OnClick", PlayerClasscolorcheck.OnClick)


--playerpercentcolor
local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "Player Healthbarcolor based on current Health", 20, -215, 15)
local PlayerPercentcolorcheck = CreateFrame("CheckButton", "PlayerPercentcolorcheck", GhettoPlayerFrame, "UICheckButtonTemplate")
PlayerPercentcolorcheck:ClearAllPoints()
PlayerPercentcolorcheck:SetPoint("CENTER", -280, 25)
 _G[PlayerPercentcolorcheck:GetName() .. "Text"]:SetText("Player Healthbarcolor based on current Health")
 function PlayerPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolorplayer=PlayerPercentcolorcheck:GetChecked();
	ReloadUI();
 end
PlayerPercentcolorcheck:SetScript("OnClick", PlayerPercentcolorcheck.OnClick)

--petpercentcolor
local title = unserAddon:CreateFont(GhettoPetFrame, "title", "Pet Healthbarcolor based on current Health", 20, -215, 15)
local PetPercentcolorcheck = CreateFrame("CheckButton", "PetPercentcolorcheck", GhettoPetFrame, "UICheckButtonTemplate")
PetPercentcolorcheck:ClearAllPoints()
PetPercentcolorcheck:SetPoint("CENTER", -280, 25)
 _G[PetPercentcolorcheck:GetName() .. "Text"]:SetText("Pet Healthbarcolor based on current Health")
 function PetPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolorpet=PetPercentcolorcheck:GetChecked();
	ReloadUI();
 end
PetPercentcolorcheck:SetScript("OnClick", PetPercentcolorcheck.OnClick)


--targetpercentcolor
local title = unserAddon:CreateFont(TargetCastbar, "title", "Target Healthbarcolor based on current Health", 20, -215, 15)
local TargetPercentcolorcheck = CreateFrame("CheckButton", "TargetPercentcolorcheck", TargetCastbar, "UICheckButtonTemplate")
TargetPercentcolorcheck:ClearAllPoints()
TargetPercentcolorcheck:SetPoint("CENTER", -280, 25)
 _G[TargetPercentcolorcheck:GetName() .. "Text"]:SetText("Target Healthbarcolor based on current Health")
 function TargetPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolortarget=TargetPercentcolorcheck:GetChecked();
	ReloadUI();
 end
TargetPercentcolorcheck:SetScript("OnClick", TargetPercentcolorcheck.OnClick)

--targetTOTpercentcolor

local TargetToTPercentcolorcheck = CreateFrame("CheckButton", "TargetToTPercentcolorcheck", TargetCastbar, "UICheckButtonTemplate")
TargetToTPercentcolorcheck:ClearAllPoints()
TargetToTPercentcolorcheck:SetPoint("CENTER", 0, 25)
 _G[TargetToTPercentcolorcheck:GetName() .. "Text"]:SetText("Target of Target Healthbarcolor based on current Health")
 function TargetToTPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolortargettot=TargetToTPercentcolorcheck:GetChecked();
	ReloadUI();
 end
TargetToTPercentcolorcheck:SetScript("OnClick", TargetToTPercentcolorcheck.OnClick)


--focuspercentcolor
local title = unserAddon:CreateFont(GhettoFocusFrame, "title", "Focus Healthbarcolor based on current Health", 20, -215, 15)
local FocusPercentcolorcheck = CreateFrame("CheckButton", "FocusPercentcolorcheck", GhettoFocusFrame, "UICheckButtonTemplate")
FocusPercentcolorcheck:ClearAllPoints()
FocusPercentcolorcheck:SetPoint("CENTER", -280, 25)
 _G[FocusPercentcolorcheck:GetName() .. "Text"]:SetText("Focus Healthbarcolor based on current Health")
 function FocusPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolorfocus=FocusPercentcolorcheck:GetChecked();
	ReloadUI();
 end
FocusPercentcolorcheck:SetScript("OnClick", FocusPercentcolorcheck.OnClick)

--focusTOTpercentcolor

local FocusToTPercentcolorcheck = CreateFrame("CheckButton", "FocusToTPercentcolorcheck", GhettoFocusFrame, "UICheckButtonTemplate")
FocusToTPercentcolorcheck:ClearAllPoints()
FocusToTPercentcolorcheck:SetPoint("CENTER", 0, 25)
 _G[FocusToTPercentcolorcheck:GetName() .. "Text"]:SetText("Target of Focus Healthbarcolor based on current Health")
 function FocusToTPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolorfocustot=FocusToTPercentcolorcheck:GetChecked();
	ReloadUI();
 end
FocusToTPercentcolorcheck:SetScript("OnClick", FocusToTPercentcolorcheck.OnClick)


--arenapercentcolor
local title = unserAddon:CreateFont(GhettoArenaFrame, "title", "Arena Healthbarcolor based on current Health", 20, -215, 15)
local ArenaPercentcolorcheck = CreateFrame("CheckButton", "ArenaPercentcolorcheck", GhettoArenaFrame, "UICheckButtonTemplate")
ArenaPercentcolorcheck:ClearAllPoints()
ArenaPercentcolorcheck:SetPoint("CENTER", -280, 25)
 _G[ArenaPercentcolorcheck:GetName() .. "Text"]:SetText("Arena Healthbarcolor based on current Health")
 function ArenaPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolorarena=ArenaPercentcolorcheck:GetChecked();
	ReloadUI();
 end
ArenaPercentcolorcheck:SetScript("OnClick", ArenaPercentcolorcheck.OnClick)

--partypercentcolor
local title = unserAddon:CreateFont(GhettoPartyFrame, "title", "Party Healthbarcolor based on current Health", 20, -215, 15)
local PartyPercentcolorcheck = CreateFrame("CheckButton", "PartyPercentcolorcheck", GhettoPartyFrame, "UICheckButtonTemplate")
PartyPercentcolorcheck:ClearAllPoints()
PartyPercentcolorcheck:SetPoint("CENTER", -280, 25)
 _G[PartyPercentcolorcheck:GetName() .. "Text"]:SetText("Player Healthbarcolor based on current Health")
 function PartyPercentcolorcheck:OnClick()
	GhettoFramesSaveX.percentcolorparty=PartyPercentcolorcheck:GetChecked();
	ReloadUI();
 end
PartyPercentcolorcheck:SetScript("OnClick", PartyPercentcolorcheck.OnClick)










--ToT=?
local title = unserAddon:CreateFont(TargetCastbar, "title", "Show Target of Target Frame", 260, -15, 15)
local Unlock3 = CreateFrame("CheckButton", "targettotcheck", TargetCastbar, "UICheckButtonTemplate")
Unlock3:ClearAllPoints()
 Unlock3:SetPoint("CENTER", 10, 210)
 _G[Unlock3:GetName() .. "Text"]:SetText("Show Target of Target Frame")
 function Unlock3:OnClick()
	GhettoFramesSaveX.targetoftarget=Unlock3:GetChecked();
	if (GhettoFramesSaveX.targetoftarget~=nil) then
		
		TargetFrameToT:SetAlpha(100)
		targettotcheck:SetChecked()
	else
		TargetFrameToT:SetAlpha(0)
		
	end
 end
Unlock3:SetScript("OnClick", Unlock3.OnClick)




--FocusTot
local title = unserAddon:CreateFont(GhettoFocusFrame, "title", "Show Target of Focus Frame", 260, -15, 15)
local Unlock4 = CreateFrame("CheckButton", "focustotcheck", GhettoFocusFrame, "UICheckButtonTemplate")
Unlock4:ClearAllPoints()
 Unlock4:SetPoint("CENTER", 10, 210)
 _G[Unlock4:GetName() .. "Text"]:SetText("Show Target of Focus Frame")
 function Unlock4:OnClick()
	GhettoFramesSaveX.targetoffocus=Unlock4:GetChecked();
	if (GhettoFramesSaveX.targetoffocus~=nil) then
		FocusFrameToT:SetAlpha(100)
		focustotcheck:SetChecked()
	else
		FocusFrameToT:SetAlpha(0)
		
	end
 end
Unlock4:SetScript("OnClick", Unlock4.OnClick)


--arenaclasscolor
local title = unserAddon:CreateFont(GhettoArenaFrame, "title", "Classcolored Arenaframe Healthbars", 20, -295, 15)
local arenaClasscolorcheck = CreateFrame("CheckButton", "arenaclasscolorcheck", GhettoArenaFrame, "UICheckButtonTemplate")
arenaClasscolorcheck:ClearAllPoints()
arenaClasscolorcheck:SetPoint("CENTER", -280, -55)
 _G[arenaClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Arena Healthbar")
 function arenaClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolorarena=arenaClasscolorcheck:GetChecked();
	ReloadUI();
 end
arenaClasscolorcheck:SetScript("OnClick", arenaClasscolorcheck.OnClick)


--partyclasscolor
local title = unserAddon:CreateFont(GhettoPartyFrame, "title", "Classcolored Partyframe Healthbars", 20, -295, 15)
local partyClasscolorcheck = CreateFrame("CheckButton", "partyclasscolorcheck", GhettoPartyFrame, "UICheckButtonTemplate")
partyClasscolorcheck:ClearAllPoints()
partyClasscolorcheck:SetPoint("CENTER", -280, -55)
 _G[partyClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Party Healthbar")
 function partyClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolorparty=partyClasscolorcheck:GetChecked();
	ReloadUI();
 end
partyClasscolorcheck:SetScript("OnClick", partyClasscolorcheck.OnClick)




--partyclasscolor
--local title = unserAddon:CreateFont(General, "title", "Classcolored Partyframes", 20, -195, 15)
--local partyClasscolorcheck = CreateFrame("CheckButton", "partyclasscolorcheck", General, "UICheckButtonTemplate")
--partyClasscolorcheck:ClearAllPoints()
--partyClasscolorcheck:SetPoint("CENTER", -280, 35)
 --_G[partyClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Party Healthbar")
-- function partyClasscolorcheck:OnClick()
--	GhettoFramesSaveX.classcolorparty=partyClasscolorcheck:GetChecked();
--	ReloadUI();
 --end
--partyClasscolorcheck:SetScript("OnClick", partyClasscolorcheck.OnClick)



--targettot classcolor
local TtotClasscolorcheck = CreateFrame("CheckButton", "Ttotclasscolorcheck", TargetCastbar, "UICheckButtonTemplate")
TtotClasscolorcheck:ClearAllPoints()
TtotClasscolorcheck:SetPoint("CENTER", -80, 105)
 _G[TtotClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Target of Target Healthbar")
 function TtotClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolorttot=TtotClasscolorcheck:GetChecked();
	ReloadUI();
 end
TtotClasscolorcheck:SetScript("OnClick", TtotClasscolorcheck.OnClick)


--focustot classcolor
local FtotClasscolorcheck = CreateFrame("CheckButton", "Ftotclasscolorcheck", GhettoFocusFrame, "UICheckButtonTemplate")
FtotClasscolorcheck:ClearAllPoints()
FtotClasscolorcheck:SetPoint("CENTER", -80, 105)
 _G[FtotClasscolorcheck:GetName() .. "Text"]:SetText("Classcolored Target of Focus Healthbar")
 function FtotClasscolorcheck:OnClick()
	GhettoFramesSaveX.classcolorftot=FtotClasscolorcheck:GetChecked();
	ReloadUI();
 end
FtotClasscolorcheck:SetScript("OnClick", FtotClasscolorcheck.OnClick)



--harmonybar etc
local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "Show Player SpecialBar", 20, -290, 15)
local Unlock7 = CreateFrame("CheckButton", "specialbarcheck", GhettoPlayerFrame, "UICheckButtonTemplate")
Unlock7:ClearAllPoints()
Unlock7:SetPoint("CENTER", -280, -50)
 _G[Unlock7:GetName() .. "Text"]:SetText("Show Player SpecialBar")
 function Unlock7:OnClick()
	GhettoFramesSaveX.playerspecialbar=Unlock7:GetChecked();
	if (GhettoFramesSaveX.playerspecialbar~=nil) then
		specialbarcheck:SetChecked()
		ReloadUI()
	else
		local nooop = function() return end
		for _, objname in ipairs({
			"MonkHarmonyBar",
			"PriestBarFrame",
			"PaladinPowerBar",
			"ShardBarFrame",
		}) do
			local obj = _G[objname]
			if obj then
				obj:Hide()
				obj.Show = nooop
			end
		end
		
	end
 end
Unlock7:SetScript("OnClick", Unlock7.OnClick)

local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "Player Special Bar Position", 20, -375, 15)


--move specialbar
local specialup = unserAddon:CreateButton(GhettoPlayerFrame, "specialup", "Up", 90, 35, 75, -410)
specialup:SetScript("OnClick", function() unserAddon:specialup() end) 
--down
local specialdown = unserAddon:CreateButton(GhettoPlayerFrame, "fcbdown", "Down", 90, 35, 75, -460)
specialdown:SetScript("OnClick", function() unserAddon:specialdown() end) 




--hitindicator

local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "PlayerFrame HitIndicators", 360, -15, 15)
local playerhitindi = CreateFrame("CheckButton", "playerhitindi", GhettoPlayerFrame, "UICheckButtonTemplate")
playerhitindi:ClearAllPoints()
playerhitindi:SetPoint("CENTER", 60, 225)
 _G[playerhitindi:GetName() .. "Text"]:SetText("Hide Player Hitindicator")
 function playerhitindi:OnClick()
	GhettoFramesSaveX.playerhitindi=playerhitindi:GetChecked();
	ReloadUI();
 end
playerhitindi:SetScript("OnClick", playerhitindi.OnClick)

--pethitindicator

local title = unserAddon:CreateFont(GhettoPetFrame, "title", "PetFrame HitIndicators", 360, -15, 15)
local pethitindi = CreateFrame("CheckButton", "pethitindi", GhettoPetFrame, "UICheckButtonTemplate")
pethitindi:ClearAllPoints()
pethitindi:SetPoint("CENTER", 60, 225)
 _G[pethitindi:GetName() .. "Text"]:SetText("Hide Pet Hitindicator")
 function pethitindi:OnClick()
	GhettoFramesSaveX.pethitindi=pethitindi:GetChecked();
	ReloadUI();
 end
pethitindi:SetScript("OnClick", pethitindi.OnClick)



--portraitclass
local title = unserAddon:CreateFont(General, "title", "Classportraits", 20, -380, 15)
local portraitcheck = CreateFrame("CheckButton", "Portraitcheck", General, "UICheckButtonTemplate")
portraitcheck:ClearAllPoints()
portraitcheck:SetPoint("CENTER", -280, -130)
 _G[portraitcheck:GetName() .. "Text"]:SetText("Classicons instead of Portraits")
 function portraitcheck:OnClick()
	GhettoFramesSaveX.classportraits=portraitcheck:GetChecked();
	ReloadUI();
 end
portraitcheck:SetScript("OnClick", portraitcheck.OnClick)




--bartexture
local title = unserAddon:CreateFont(General, "title", "Bar Texture Style", 345, -15, 25)
--dropdowntest
if not DropDownMenuTest then
   CreateFrame("Frame", "DropDownMenuTest", General, "UIDropDownMenuTemplate")
 end
DropDownMenuTest:ClearAllPoints()
DropDownMenuTest:SetPoint("CENTER", 150, 205)
DropDownMenuTest:Show()

 local items = {
   "Ace",--1
   "Aluminium",--2
   "Banto",--3
   "Blizzard",--4
   "Charcoal",--5
   "Glaze",--6
   "LiteStep",--7
   "Minimalist",--8
   "Otravi",--9
   "Perl",--10
   "Smooth",--11
   "Striped",--12
   "Swag",--13
 }

 local function OnClick(self)
   UIDropDownMenu_SetSelectedID(DropDownMenuTest, self:GetID())
  if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==1) then 
		GhettoFramesSaveX.bartex=1;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Ace");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==2) then 
		GhettoFramesSaveX.bartex=2;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Aluminium");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==3) then 
		GhettoFramesSaveX.bartex=3;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\banto");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==4) then 
		GhettoFramesSaveX.bartex=4;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\blizzard");
		
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==5) then 
		GhettoFramesSaveX.bartex=5;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Charcoal");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==6) then 
		GhettoFramesSaveX.bartex=6;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\glaze");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==7) then 
		GhettoFramesSaveX.bartex=7;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\LiteStep");
   end
    if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==8) then 
		GhettoFramesSaveX.bartex=8;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\Minimalist");
   end
    if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==9) then 
		GhettoFramesSaveX.bartex=9;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\otravi");
   end
    if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==10) then 
		GhettoFramesSaveX.bartex=10;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\perl");
   end
    if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==11) then 
		GhettoFramesSaveX.bartex=11;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\smooth");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==12) then 
		GhettoFramesSaveX.bartex=12;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\striped");
   end
   if (UIDropDownMenu_GetSelectedID(DropDownMenuTest)==13) then 
		GhettoFramesSaveX.bartex=13;
		PlayerFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		PlayerFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		TargetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		TargetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");			
		TargetFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		TargetFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameToTHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		FocusFrameToTManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		PetFrameManaBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
		PetFrameHealthBar:SetStatusBarTexture("Interface\\AddOns\\GhettoFrames\\Textures\\swag");
   end
 end


 local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items) do
     info = UIDropDownMenu_CreateInfo()
     info.text = v
     info.value = v
     info.func = OnClick
     UIDropDownMenu_AddButton(info, level)
   end
   
 end
 
--UIDropDownMenu_GetSelectedID(DropDownMenuTest)  

 UIDropDownMenu_Initialize(DropDownMenuTest, initialize)
 UIDropDownMenu_SetWidth(DropDownMenuTest, 100);
 UIDropDownMenu_SetButtonWidth(DropDownMenuTest, 124)
 UIDropDownMenu_SetSelectedID(DropDownMenuTest, GhettoFramesSaveX.bartex)
 UIDropDownMenu_JustifyText(DropDownMenuTest, "LEFT")

 
 
 
 
 --healthformat
local title = unserAddon:CreateFont(GhettoPlayerFrame, "title", "Player Healthbar Text Format", 295, -320, 22)
 --healthformatdropdown
if not DropDownMenuTest2 then
   CreateFrame("Frame", "DropDownMenuTest2", GhettoPlayerFrame, "UIDropDownMenuTemplate")
 end
DropDownMenuTest2:ClearAllPoints()
DropDownMenuTest2:SetPoint("CENTER", 150, -100)
DropDownMenuTest2:Show()
 local items2 = {
   "Percent",--1
   "Currenthealth",--2
   "Currenhealth + Percent",--3
   "Currenhealth + Maxhealth",--4
   "Currenhealth + Maxhealth + Percent",--5
 }
local function OnClick(self)
UIDropDownMenu_SetSelectedID(DropDownMenuTest2, self:GetID())
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest2)==1) then 
		GhettoFramesSaveX.phformat=1;
		ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest2)==2) then 
	GhettoFramesSaveX.phformat=2;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest2)==3) then 
	GhettoFramesSaveX.phformat=3;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest2)==4) then 
	GhettoFramesSaveX.phformat=4;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest2)==5) then 
	GhettoFramesSaveX.phformat=5;
	ReloadUI()
end
end
 local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items2) do
     info = UIDropDownMenu_CreateInfo()
     info.text = v
     info.value = v
     info.func = OnClick
     UIDropDownMenu_AddButton(info, level)
   end
 end
 
--UIDropDownMenu_GetSelectedID(DropDownMenuTest)  

 UIDropDownMenu_Initialize(DropDownMenuTest2, initialize)
 UIDropDownMenu_SetWidth(DropDownMenuTest2, 100);
 UIDropDownMenu_SetButtonWidth(DropDownMenuTest2, 124)
 UIDropDownMenu_SetSelectedID(DropDownMenuTest2, GhettoFramesSaveX.phformat)
 UIDropDownMenu_JustifyText(DropDownMenuTest2, "LEFT")
 
 
  --healthformat
local title = unserAddon:CreateFont(GhettoFocusFrame, "title", "Focus Healthbar Text Format", 295, -320, 22)
 --healthformatdropdown
if not DropDownMenuTest3 then
   CreateFrame("Frame", "DropDownMenuTest3", GhettoFocusFrame, "UIDropDownMenuTemplate")
 end
DropDownMenuTest3:ClearAllPoints()
DropDownMenuTest3:SetPoint("CENTER", 150, -100)
DropDownMenuTest3:Show()
local function OnClick(self)
UIDropDownMenu_SetSelectedID(DropDownMenuTest3, self:GetID())
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest3)==1) then 
		GhettoFramesSaveX.fhformat=1;
		ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest3)==2) then 
	GhettoFramesSaveX.fhformat=2;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest3)==3) then 
	GhettoFramesSaveX.fhformat=3;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest3)==4) then 
	GhettoFramesSaveX.fhformat=4;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest3)==5) then 
	GhettoFramesSaveX.fhformat=5;
	ReloadUI()
end
end
 local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items2) do
     info = UIDropDownMenu_CreateInfo()
     info.text = v
     info.value = v
     info.func = OnClick
     UIDropDownMenu_AddButton(info, level)
   end
 end
 
--UIDropDownMenu_GetSelectedID(DropDownMenuTest)  

 UIDropDownMenu_Initialize(DropDownMenuTest3, initialize)
 UIDropDownMenu_SetWidth(DropDownMenuTest3, 100);
 UIDropDownMenu_SetButtonWidth(DropDownMenuTest3, 124)
 UIDropDownMenu_SetSelectedID(DropDownMenuTest3, GhettoFramesSaveX.fhformat)
 UIDropDownMenu_JustifyText(DropDownMenuTest3, "LEFT")
 
 
  --healthformat
local title = unserAddon:CreateFont(TargetCastbar, "title", "Target Healthbar Text Format", 295, -320, 22)
 --healthformatdropdown
if not DropDownMenuTest4 then
   CreateFrame("Frame", "DropDownMenuTest4", TargetCastbar, "UIDropDownMenuTemplate")
 end
DropDownMenuTest4:ClearAllPoints()
DropDownMenuTest4:SetPoint("CENTER", 150, -100)
DropDownMenuTest4:Show()
local function OnClick(self)
UIDropDownMenu_SetSelectedID(DropDownMenuTest4, self:GetID())
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest4)==1) then 
		GhettoFramesSaveX.thformat=1;
		ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest4)==2) then 
	GhettoFramesSaveX.thformat=2;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest4)==3) then 
	GhettoFramesSaveX.thformat=3;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest4)==4) then 
	GhettoFramesSaveX.thformat=4;
	ReloadUI()
end
if (UIDropDownMenu_GetSelectedID(DropDownMenuTest4)==5) then 
	GhettoFramesSaveX.thformat=5;
	ReloadUI()
end
end
 local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items2) do
     info = UIDropDownMenu_CreateInfo()
     info.text = v
     info.value = v
     info.func = OnClick
     UIDropDownMenu_AddButton(info, level)
   end
 end
 
--UIDropDownMenu_GetSelectedID(DropDownMenuTest)  

 UIDropDownMenu_Initialize(DropDownMenuTest4, initialize)
 UIDropDownMenu_SetWidth(DropDownMenuTest4, 100);
 UIDropDownMenu_SetButtonWidth(DropDownMenuTest4, 124)
 UIDropDownMenu_SetSelectedID(DropDownMenuTest4, GhettoFramesSaveX.thformat)
 UIDropDownMenu_JustifyText(DropDownMenuTest4, "LEFT")

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 local test123
 if (GhettoFramesSaveX.darkentextures) then test123=GhettoFramesSaveX.darkentextures else test123=1 end
 
 
 --darkenslider
 local title = unserAddon:CreateFont(General, "title", "Darken Frame Textures", 20, -105, 25)
 
local darkenslider = unserAddon:CreateSliderx(General, "darkvalue", "Darken Frame Textures", 0, 1, test123  , 60,-155)
darkenslider:SetScript("OnValueChanged", function(self, value)
	for i, v in pairs({PlayerFrameTexture, TargetFrameTextureFrameTexture, PetFrameTexture, PartyMemberFrame1Texture, PartyMemberFrame2Texture, PartyMemberFrame3Texture, PartyMemberFrame4Texture,
                        PartyMemberFrame1PetFrameTexture, PartyMemberFrame2PetFrameTexture, PartyMemberFrame3PetFrameTexture, PartyMemberFrame4PetFrameTexture, FocusFrameTextureFrameTexture,
                        TargetFrameToTTextureFrameTexture, FocusFrameToTTextureFrameTexture
	}) do
                        v:SetVertexColor(value, value, value)
    end
	GhettoFramesSaveX.darkentextures=value	
	getglobal(darkenslider:GetName() .. 'Text'):SetText("Darken Value");
end)
 
 
 
 
 --colorpicker
 
 function ShowColorPicker(r, g, b, changedCallback)
   ColorPickerFrame:SetColorRGB(r,g,b);
   ColorPickerFrame.hasOpacity = false
   ColorPickerFrame.previousValues = {r,g,b};
   ColorPickerFrame.func, ColorPickerFrame.opacityFunc, ColorPickerFrame.cancelFunc = 
   changedCallback, changedCallback, changedCallback;
   ColorPickerFrame:Hide(); -- Need to run the OnShow handler.
   ColorPickerFrame:Show();
end

local r,g,b = 1, 1, 1

local function myColorCallback(restore)
   local newR, newG, newB
   if restore then
      -- The user bailed, we extract the old color from the table created by ShowColorPicker.
      newR, newG, newB = unpack(restore);
   else
      -- Something changed
      newR, newG, newB = ColorPickerFrame:GetColorRGB();
   end
   
   -- Update our internal storage.
   r, g, b = newR, newG, newB
   
   GhettoFramesSaveX.colorpickfriendr=r
   GhettoFramesSaveX.colorpickfriendg=g
   GhettoFramesSaveX.colorpickfriendb=b
 
   
   -- And update any UI elements that use this color...
end

local function myColorCallbackx(restore)
   local newR, newG, newB
   if restore then
      -- The user bailed, we extract the old color from the table created by ShowColorPicker.
      newR, newG, newB = unpack(restore);
   else
      -- Something changed
      newR, newG, newB = ColorPickerFrame:GetColorRGB();
   end
   
   -- Update our internal storage.
   r, g, b = newR, newG, newB
   
   GhettoFramesSaveX.colorpickenemyr=r
   GhettoFramesSaveX.colorpickenemyg=g
   GhettoFramesSaveX.colorpickenemyb=b
 
   
   -- And update any UI elements that use this color...
end

--friendcolor
local title = unserAddon:CreateFont(General, "title", "Default Friendly Healthbarcolor", 335, -200, 20)
 local colorpick = unserAddon:CreateButton(General, "colorpick", "Set Color", 90, 35, 415, -330)
colorpick:SetScript("OnClick", function(self)
      ShowColorPicker(r, g, b, myColorCallback);
end) 
--enemycolor
local title = unserAddon:CreateFont(General, "title", "Default Enemy Healthbarcolor", 335, -300, 20)
 local colorpick = unserAddon:CreateButton(General, "colorpickx", "Set Color", 90, 35, 415, -230)
colorpickx:SetScript("OnClick", function(self)
      ShowColorPicker(r, g, b, myColorCallbackx);
end) 











 
 
 
 
 
 
 
 
 
 
 
 
 local title = unserAddon:CreateFont(General, "title", "Custom Target- and Focusbuffsize", 20, -200, 15)
 local buffsizebutton = CreateFrame("CheckButton", "buffsizebutton", General, "UICheckButtonTemplate")
buffsizebutton:ClearAllPoints()
buffsizebutton:SetPoint("CENTER", -280, 50)
 _G[buffsizebutton:GetName() .. "Text"]:SetText("Custom Buffsize")
 function buffsizebutton:OnClick()
	GhettoFramesSaveX.buffsizebutton=buffsizebutton:GetChecked();
	 hooksecurefunc("TargetFrame_UpdateAuraPositions", function(self, auraName, numAuras, numOppositeAuras,largeAuraList, updateFunc, maxRowWidth, offsetX)
    local AURA_OFFSET_Y = 3
    local LARGE_AURA_SIZE = GhettoFramesSaveX.buffsize*1.421
    local SMALL_AURA_SIZE = GhettoFramesSaveX.buffsize
    local size
    local offsetY = AURA_OFFSET_Y
    local rowWidth = 0
    local firstBuffOnRow = 1
    for i=1, numAuras do
     if ( largeAuraList[i] ) then
       size = LARGE_AURA_SIZE
       offsetY = AURA_OFFSET_Y + AURA_OFFSET_Y
     else
       size = SMALL_AURA_SIZE
     end
     if ( i == 1 ) then
       rowWidth = size
       self.auraRows = self.auraRows + 1
     else
       rowWidth = rowWidth + size + offsetX
     end
     if ( rowWidth > maxRowWidth ) then
       updateFunc(self, auraName, i, numOppositeAuras, firstBuffOnRow, size, offsetX, offsetY)
       rowWidth = size
       self.auraRows = self.auraRows + 1
       firstBuffOnRow = i
       offsetY = AURA_OFFSET_Y
     else
       updateFunc(self, auraName, i, numOppositeAuras, i - 1, size, offsetX, offsetY)
     end
    end
    end)
	hooksecurefunc('TargetFrame_UpdateAuras', function(self)
        local frameStealable
        local frameName
        local icon
        local debuffType
        local selfName = self:GetName()
        local isEnemy = UnitIsEnemy(PlayerFrame.unit, self.unit)
        for i = 1, MAX_TARGET_BUFFS do
                _, _, icon, _, debuffType = UnitBuff(self.unit, i)
                frameName = selfName..'Buff'..i
                if ( icon and ( not self.maxBuffs or i <= self.maxBuffs ) ) then
                        frameStealable = _G[frameName..'Stealable']
                        if ( isEnemy and debuffType == 'Magic' ) then
                                frameStealable:Show()
								frameStealable:SetHeight(GhettoFramesSaveX.buffsize*1.4)
								frameStealable:SetWidth(GhettoFramesSaveX.buffsize*1.4)
                        else
                                frameStealable:Hide()
                        end
                end
        end
		
end)

	buffsizer:Show()
 end
buffsizebutton:SetScript("OnClick", buffsizebutton.OnClick)
 
 
 
 
 
 
 

 
 
 
 
 
 
 local buffsizestart
 if (GhettoFramesSaveX.buffsize) then buffsizestart=GhettoFramesSaveX.buffsize else buffsizestart=15 end
 
 local buffsizer = unserAddon:CreateSlidery(General, "buffsizer", "Buffsize", 10, 30, buffsizestart  , 130,-235)
 buffsizer:SetScript("OnValueChanged", function(self, value)
	
	
	GhettoFramesSaveX.buffsize=value	
	getglobal(buffsizer:GetName() .. 'Text'):SetText("Buffsize: (" .. format("%.2f",value) .. ")");
end)
 
 



 
 
 
 
 
 
 
 
 

-- font greeting
local title = unserAddon:CreateFont(GhettoFrames.panel, "title", "|cff71C671GhettoFrames", 50, -35, 25) 
local titlea = unserAddon:CreateFont(GhettoFrames.panel, "titlea", "|cffbbbbbbby Ghettoboyy", 50, -65, 15) 
end



-- CreateSlider 
function unserAddon:CreateSlider(frame, name, text, slidermin, slidermax, slidervalue, x, y, template)
if (template == nil) then template = "OptionsSliderTemplate"
end
local slider = CreateFrame("Slider", name, frame, template) slider:SetPoint("TOPLEFT", x, y) slider:SetMinMaxValues(slidermin, slidermax) slider:SetValue(slidervalue)
getglobal(slider:GetName() .. 'Low'):SetText('0.5');
getglobal(slider:GetName() .. 'High'):SetText('2');
getglobal(slider:GetName() .. 'Text'):SetText("Frame Scale: (" .. format("%.2f",slidervalue) .. ")");
return (slider)
end
-- createSlider2
function unserAddon:CreateSliderx(frame, name, text, slidermin, slidermax, slidervalue, x, y, template)
if (template == nil) then template = "OptionsSliderTemplate"
end
local slider = CreateFrame("Slider", name, frame, template) slider:SetPoint("TOPLEFT", x, y) slider:SetMinMaxValues(slidermin, slidermax) slider:SetValue(slidervalue)
getglobal(slider:GetName() .. 'Low'):SetText('Dark');
getglobal(slider:GetName() .. 'High'):SetText('Bright');
getglobal(slider:GetName() .. 'Text'):SetText("Darken Value");
return (slider)
end
-- createSlider3
function unserAddon:CreateSlidery(frame, name, text, slidermin, slidermax, slidervalue, x, y, template)
if (template == nil) then template = "OptionsSliderTemplate"
end
local slider = CreateFrame("Slider", name, frame, template) slider:SetPoint("TOPLEFT", x, y) slider:SetMinMaxValues(slidermin, slidermax) slider:SetValue(slidervalue)
getglobal(slider:GetName() .. 'Low'):SetText(slidermin);
getglobal(slider:GetName() .. 'High'):SetText(slidermax);
getglobal(slider:GetName() .. 'Text'):SetText("Buffsize: (" .. format("%.2f",slidervalue) .. ")");
return (slider)
end
 
-- CreateButton --
function unserAddon:CreateButton(frame, name, text, width, height, x, y, template)
if (template == nil) then template = "OptionsButtonTemplate"
end
local button = CreateFrame("Button", name, frame, template) button:SetPoint("TOPLEFT", x, y) button:SetWidth(width)
button:SetHeight(height) button:SetText(text)
return (button)
end

-- CreateEditBox --
function unserAddon:CreateEditBox(frame, name, width, height, x, y)
local editBox = CreateFrame("EditBox", name, frame, "InputBoxTemplate")
editBox:SetPoint("TOPLEFT", x, y)
editBox:SetWidth(width)
editBox:SetHeight(height)
editBox:SetAutoFocus(false)
editBox:Show()
return(editbox)
end
-- CreateFont --
function unserAddon:CreateFont(frame, name, text, x, y, size)
if size == nil then size = 15
end
local fontString = frame:CreateFontString(name) fontString:SetPoint("TOPLEFT", x, y) fontString:SetFont("Fonts\\MORPHEUS.ttf", size, "") fontString:SetText(text)
return (fontString)
end

function unserAddon:Clear()
editbox1:SetText("")
editbox2:SetText("")
end


--TargetCastBar
function unserAddon:tcbdown()
	GhettoFramesSaveX.castbx = 0
	GhettoFramesSaveX.castby = 0
	ReloadUI()
end
function unserAddon:tcbup()
	GhettoFramesSaveX.castbx = -15
	GhettoFramesSaveX.castby = 55
	TargetFrameSpellBar:ClearAllPoints()
	TargetFrameSpellBar:SetPoint("CENTER", TargetFrame, "CENTER", GhettoFramesSaveX.castbx,GhettoFramesSaveX.castby)
	TargetFrameSpellBar.SetPoint = function() end
	ReloadUI()
	end
function unserAddon:tcbright()
	GhettoFramesSaveX.castbx = 175
	GhettoFramesSaveX.castby = 0
	TargetFrameSpellBar:ClearAllPoints()
	TargetFrameSpellBar:SetPoint("CENTER", TargetFrame, "CENTER", GhettoFramesSaveX.castbx,GhettoFramesSaveX.castby)
	TargetFrameSpellBar.SetPoint = function() end
	ReloadUI()
	end
function unserAddon:tcbleft()
	GhettoFramesSaveX.castbx = -195
	GhettoFramesSaveX.castby = 0
	TargetFrameSpellBar:ClearAllPoints()
	TargetFrameSpellBar:SetPoint("CENTER", TargetFrame, "CENTER", GhettoFramesSaveX.castbx,GhettoFramesSaveX.castby)
	TargetFrameSpellBar.SetPoint = function() end
	ReloadUI()
end


--FocusCastBar
function unserAddon:fcbdown()
	GhettoFramesSaveX.fcastbx = 0
	GhettoFramesSaveX.fcastby = 0
	ReloadUI()
end
function unserAddon:fcbup()
	GhettoFramesSaveX.fcastbx = -15
	GhettoFramesSaveX.fcastby = 55
	FocusFrameSpellBar:ClearAllPoints()
	FocusFrameSpellBar:SetPoint("CENTER", FocusFrame, "CENTER", GhettoFramesSaveX.fcastbx,GhettoFramesSaveX.fcastby)
	FocusFrameSpellBar.SetPoint = function() end
	ReloadUI()
	end
function unserAddon:fcbright()
	GhettoFramesSaveX.fcastbx = 175
	GhettoFramesSaveX.fcastby = 0
	FocusFrameSpellBar:ClearAllPoints()
	FocusFrameSpellBar:SetPoint("CENTER", TargetFrame, "CENTER", GhettoFramesSaveX.fcastbx,GhettoFramesSaveX.fcastby)
	FocusFrameSpellBar.SetPoint = function() end
	ReloadUI()
	end
function unserAddon:fcbleft()
	GhettoFramesSaveX.fcastbx = -195
	GhettoFramesSaveX.fcastby = 0
	FocusFrameSpellBar:ClearAllPoints()
	FocusFrameSpellBar:SetPoint("CENTER", TargetFrame, "CENTER", GhettoFramesSaveX.fcastbx,GhettoFramesSaveX.fcastby)
	FocusFrameSpellBar.SetPoint = function() end
	ReloadUI()
end

--random
function unserAddon:specialup()
	GhettoFramesSaveX.specialx = 60
	GhettoFramesSaveX.specialy = 40
	GhettoFramesSaveX.monkspecialx = 50
	GhettoFramesSaveX.monkspecialy = 45
	GhettoFramesSaveX.palaspecialx = 50
	GhettoFramesSaveX.palaspecialy = 55
	ReloadUI()
	end
function unserAddon:specialdown()
	GhettoFramesSaveX.specialx = 0
	GhettoFramesSaveX.specialy = 0
	GhettoFramesSaveX.monkspecialx = 0
	GhettoFramesSaveX.monkspecialy = 0
	GhettoFramesSaveX.palaspecialx = 0
	GhettoFramesSaveX.palaspecialy = 0
	ReloadUI()
end