---------------------------------------------------------
-- Refer to GEMHELPER_CHECKBUTTON_TEXT in the localization files for checkbox IDs


-- Base Item IDs for gem materials
-- Format: [Checkbox ID] = Gem itemID
GemHelper_MaterialGemID = {
	[21] = 23117,	-- Azure Moonstone
	[22] = 23077,	-- Blood Garnet
	[23] = 23112,	-- Golden Draenite
	[24] = 23079,	-- Deep Peridot
	[25] = 21929,	-- Flame Spessarite
	[26] = 23107,	-- Shadow Draenite
	[27] = 24478,	-- Jaggal Pearl
	[31] = 23438,	-- Star of Elune
	[32] = 23436,	-- Living Ruby
	[33] = 23440,	-- Dawnstone
	[34] = 23437,	-- Talasite
	[35] = 23439,	-- Noble Topaz
	[36] = 23441,	-- Nightseye
	[37] = 24479,	-- Shadow Pearl
	[41] = 25868,	-- Skyfire Diamond
	[42] = 25867,	-- Earthstorm Diamond
	[51] = 32228,	-- Empyrean Sapphire
	[52] = 32227,	-- Crimson Spinel
	[53] = 32229,	-- Lionseye
	[54] = 32249,	-- Seaspray Emerald
	[55] = 32231,	-- Pyrestone
	[56] = 32230,	-- Shadowsong Amethyst
	[121] = 36923,	-- Chalcedony
	[122] = 36917,	-- Bloodstone
	[123] = 36920,	-- Sun Crystal
	[124] = 36932,	-- Dark Jade
	[125] = 36929,	-- Huge Citrine
	[126] = 36926,	-- Shadow Crystal
	[127] = 36783,	-- Northsea Pearl
	[131] = 36924,	-- Sky Sapphire
	[132] = 36918,	-- Scarlet Ruby
	[133] = 36921,	-- Autumn's Glow
	[134] = 36933,	-- Forest Emerald
	[135] = 36930,	-- Monarch Topaz
	[136] = 36927,	-- Twilight Opal
	[137] = 36784,	-- Siren's Tear
	[141] = 41266,	-- Skyflare Diamond
	[142] = 41334,	-- Earthsiege Diamond
	[143] = 42225,	-- Dragon's Eye
	[151] = 36925,	-- Majestic Zircon
	[152] = 36919,	-- Cardinal Ruby
	[153] = 36922,	-- King's Amber
	[154] = 36934,	-- Eye of Zul
	[155] = 36931,	-- Ametrine	
	[156] = 36928,	-- Dreadstone
	[161] = 52178,  -- Zephyrite
	[162] = 52177,  -- Carnelian
	[163] = 52179,  -- Alicite
	[164] = 52182,  -- Jasper
	[165] = 52181,  -- Hessonite
	[166] = 52180,  -- Nightstone
	[168] = 52196,  -- Chimera's Eye
	[171] = 52191,  -- Ocean Sapphire
	[172] = 52190,  -- Inferno Ruby
	[173] = 52195,  -- Amberjewel
	[174] = 52192,  -- Dream Emerald
	[175] = 52193,  -- Ember Topaz
	[176] = 52194,  -- Demonseye
	[177] = 52303,  -- Shadowspirit Diamond
	[181] = 71807,	-- Deepholm Iolite
	[182] = 71805,	-- Queen's Garnet
	[183] = 71806,  -- Lightstone
	[184] = 71810,  -- Elven Peridot
	[185] = 71808,  -- Lava Coral
	[186] = 71809,  -- Shadow Spinel

	[190] = 76133,  -- Lapis Lazuli
	[191] = 76136,  -- Pandarian Garnet
	[192] = 76134,  -- Sunstone
	[193] = 76137,  -- Alexandrite
	[194] = 76130,  -- Tiger Opal
	[195] = 76135,  -- Roguestone
	[196] = 76132,  -- Primal Diamond
	[197] = 76734,  -- Serpent's Eye
	
	[200] = 76138,  -- River's Heart  (4)
	[201] = 76131,  -- Primordial Ruby  (5)
	[202] = 76142,  -- Sun's Radiance (5)
	[203] = 76139,  -- Wild Jade  (18)
	[204] = 76140,  -- Vermilion Onyx (22)
	[205] = 76141,  -- Imperial Amethyst (14)
}

-- Create reverse lookup table for speed
GemHelper_ReverseMaterialGemID = {}
for k, v in pairs(GemHelper_MaterialGemID) do
	GemHelper_ReverseMaterialGemID[v] = k
end

-- Icons for raw gems
GEMHELPER_CHECKBUTTON_TEXT[21]	= "|TInterface\\Icons\\INV_Misc_Gem_AzureDraenite_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[22]	= "|TInterface\\Icons\\INV_Misc_Gem_BloodGem_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[23]	= "|TInterface\\Icons\\INV_Misc_Gem_GoldenDraenite_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[24]	= "|TInterface\\Icons\\INV_Misc_Gem_DeepPeridot_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[25]	= "|TInterface\\Icons\\INV_Misc_Gem_FlameSpessarite_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[26]	= "|TInterface\\Icons\\INV_Misc_Gem_EbonDraenite_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[27]	= "|TInterface\\Icons\\INV_Misc_Gem_Pearl_02:0|t"

GEMHELPER_CHECKBUTTON_TEXT[31]	= "|TInterface\\Icons\\INV_Jewelcrafting_StarOfElune_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[32]	= "|TInterface\\Icons\\INV_Jewelcrafting_LivingRuby_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[33]	= "|TInterface\\Icons\\INV_Jewelcrafting_Dawnstone_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[34]	= "|TInterface\\Icons\\INV_Jewelcrafting_Talasite_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[35]	= "|TInterface\\Icons\\INV_Jewelcrafting_NobleTopaz_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[36]	= "|TInterface\\Icons\\INV_Jewelcrafting_Nightseye_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[37]	= "|TInterface\\Icons\\INV_Misc_Gem_Pearl_01:0|t"

GEMHELPER_CHECKBUTTON_TEXT[41]	= "|TInterface\\Icons\\INV_Misc_Gem_Diamond_05:0|t"
GEMHELPER_CHECKBUTTON_TEXT[42]	= "|TInterface\\Icons\\INV_Misc_Gem_Diamond_04:0|t"

GEMHELPER_CHECKBUTTON_TEXT[51]	= "|TInterface\\Icons\\INV_Jewelcrafting_EmpyreanSapphire_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[52]	= "|TInterface\\Icons\\INV_Jewelcrafting_CrimsonSpinel_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[53]	= "|TInterface\\Icons\\INV_Jewelcrafting_Lionseye_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[54]	= "|TInterface\\Icons\\INV_Jewelcrafting_SeasprayEmerald_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[55]	= "|TInterface\\Icons\\INV_Jewelcrafting_Pyrestone_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[56]	= "|TInterface\\Icons\\INV_Jewelcrafting_ShadowsongAmethyst_01:0|t"

GEMHELPER_CHECKBUTTON_TEXT[121]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_10:0|t"
GEMHELPER_CHECKBUTTON_TEXT[122]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_12:0|t"
GEMHELPER_CHECKBUTTON_TEXT[123]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_08:0|t"
GEMHELPER_CHECKBUTTON_TEXT[124]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_07:0|t"
GEMHELPER_CHECKBUTTON_TEXT[125]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_09:0|t"
GEMHELPER_CHECKBUTTON_TEXT[126]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_11:0|t"
GEMHELPER_CHECKBUTTON_TEXT[127]	= "|TInterface\\Icons\\INV_Misc_Gem_Pearl_09:0|t"

GEMHELPER_CHECKBUTTON_TEXT[131]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_05:0|t"
GEMHELPER_CHECKBUTTON_TEXT[132]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_04:0|t"
GEMHELPER_CHECKBUTTON_TEXT[133]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[134]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[135]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[136]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_06:0|t"
GEMHELPER_CHECKBUTTON_TEXT[137]	= "|TInterface\\Icons\\INV_Misc_Gem_Pearl_11:0|t"

GEMHELPER_CHECKBUTTON_TEXT[141]	= "|TInterface\\Icons\\INV_Jewelcrafting_IceDiamond_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[142]	= "|TInterface\\Icons\\INV_Jewelcrafting_ShadowSpirit_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[143]	= "|TInterface\\Icons\\INV_Jewelcrafting_DragonsEye01:0|t"

GEMHELPER_CHECKBUTTON_TEXT[151]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_35:0|t"
GEMHELPER_CHECKBUTTON_TEXT[152]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_32:0|t"
GEMHELPER_CHECKBUTTON_TEXT[153]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_36:0|t"
GEMHELPER_CHECKBUTTON_TEXT[154]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_34:0|t"
GEMHELPER_CHECKBUTTON_TEXT[155]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_33:0|t"
GEMHELPER_CHECKBUTTON_TEXT[156]	= "|TInterface\\Icons\\INV_Jewelcrafting_Gem_31:0|t"

GEMHELPER_CHECKBUTTON_TEXT[161]	= "|TInterface\\Icons\\inv_misc_uncutgemsuperior6:0|t"
GEMHELPER_CHECKBUTTON_TEXT[162]	= "|TInterface\\Icons\\inv_misc_uncutgemsuperior4:0|t"
GEMHELPER_CHECKBUTTON_TEXT[163]	= "|TInterface\\Icons\\inv_misc_uncutgemsuperior:0|t"
GEMHELPER_CHECKBUTTON_TEXT[164]	= "|TInterface\\Icons\\inv_misc_uncutgemsuperior2:0|t"
GEMHELPER_CHECKBUTTON_TEXT[165]	= "|TInterface\\Icons\\inv_misc_uncutgemsuperior5:0|t"
GEMHELPER_CHECKBUTTON_TEXT[166]	= "|TInterface\\Icons\\inv_misc_uncutgemsuperior3:0|t"

GEMHELPER_CHECKBUTTON_TEXT[168]	= "|TInterface\\Icons\\item_cutmetagemb:0|t"

GEMHELPER_CHECKBUTTON_TEXT[171]	= "|TInterface\\Icons\\inv_misc_uncutgemnormal2:0|t"
GEMHELPER_CHECKBUTTON_TEXT[172]	= "|TInterface\\Icons\\inv_misc_uncutgemnormal3:0|t"
GEMHELPER_CHECKBUTTON_TEXT[173]	= "|TInterface\\Icons\\inv_misc_uncutgemnormal5:0|t"
GEMHELPER_CHECKBUTTON_TEXT[174]	= "|TInterface\\Icons\\inv_misc_uncutgemnormal1:0|t"
GEMHELPER_CHECKBUTTON_TEXT[175]	= "|TInterface\\Icons\\inv_misc_uncutgemnormal:0|t"
GEMHELPER_CHECKBUTTON_TEXT[176]	= "|TInterface\\Icons\\inv_misc_uncutgemnormal4:0|t"
GEMHELPER_CHECKBUTTON_TEXT[177]	= "|TInterface\\Icons\\inv_misc_metagemuncut_b:0|t"

GEMHELPER_CHECKBUTTON_TEXT[181]	= "|TInterface\\Icons\\inv_misc_epicgem_uncut_02:0|t"
GEMHELPER_CHECKBUTTON_TEXT[182]	= "|TInterface\\Icons\\inv_misc_epicgem_uncut_01:0|t"
GEMHELPER_CHECKBUTTON_TEXT[183]	= "|TInterface\\Icons\\inv_misc_epicgem_uncut_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[184]	= "|TInterface\\Icons\\inv_misc_epicgem_uncut_06:0|t"
GEMHELPER_CHECKBUTTON_TEXT[185]	= "|TInterface\\Icons\\inv_misc_epicgem_uncut_04:0|t"
GEMHELPER_CHECKBUTTON_TEXT[186]	= "|TInterface\\Icons\\inv_misc_epicgem_uncut_05:0|t"

-- MOP stuff
GEMHELPER_CHECKBUTTON_TEXT[190]	= "|TInterface\\Icons\\inv_misc_gem_saphirerough_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[191]	= "|TInterface\\Icons\\inv_misc_gem_rubyrough_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[192]	= "|TInterface\\Icons\\inv_misc_gem_topazrough_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[193]	= "|TInterface\\Icons\\inv_misc_gem_emeraldrough_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[194]	= "|TInterface\\Icons\\inv_misc_gem_opalrough_03:0|t"
GEMHELPER_CHECKBUTTON_TEXT[195]	= "|TInterface\\Icons\\inv_misc_gem_amethystrough_03:0|t"

GEMHELPER_CHECKBUTTON_TEXT[196]	= "|TInterface\\Icons\\inv_misc_gem_x4_metagem_uncut:0|t"
GEMHELPER_CHECKBUTTON_TEXT[197]	= "|TInterface\\Icons\\creatureportrait_sc_eyeofacherus_02:0|t"

GEMHELPER_CHECKBUTTON_TEXT[200]	= "|TInterface\\Icons\\inv_misc_gem_x4_rare_uncut_blue:0|t"
GEMHELPER_CHECKBUTTON_TEXT[201]	= "|TInterface\\Icons\\inv_misc_gem_x4_rare_uncut_red:0|t"
GEMHELPER_CHECKBUTTON_TEXT[202]	= "|TInterface\\Icons\\inv_misc_gem_x4_rare_uncut_yellow:0|t"
GEMHELPER_CHECKBUTTON_TEXT[203]	= "|TInterface\\Icons\\inv_misc_gem_x4_rare_uncut_green:0|t"
GEMHELPER_CHECKBUTTON_TEXT[204]	= "|TInterface\\Icons\\inv_misc_gem_x4_rare_uncut_orange:0|t"
GEMHELPER_CHECKBUTTON_TEXT[205]	= "|TInterface\\Icons\\inv_misc_gem_x4_rare_uncut_purple:0|t"


-- Data for rarity, gemtype, colour, stats
-- Format: [Gem itemID] = gemTable
--   r = rarity quality sort value
--   [checkbox ID] = true (if the statistic is applicable)
GemHelper_GemData = {
	-- Sunwell BoP quest rewards from "Hard to Kill" - http://www.wowhead.com/?quest=11492
	--[35487] = {r = 4, [104] = true, [52] = true, [12] = true, [73] = true},	-- Delicate Crimson Spinel, red, 20 atk power
	--[35488] = {r = 4, [104] = true, [52] = true, [12] = true, [83] = true},	-- Brilliant Crimson Spinel, red, 12 spell
	--[35489] = {r = 4, [104] = true, [52] = true, [12] = true, [83] = true},	-- Teardrop Crimson Spinel, red, 22 spell

	--[[
	The following epic quality gems exist in game (you can sniff their itemIDs), but nobody knows how to obtain the recipes to craft them.
	[33132]-- Delicate Fire Ruby, red, 12 agi
	[33136]-- Nothing
	[33137]-- Sparkling Falling Star, blue, 12 spi
	[33138]-- Mystic Bladestone, yellow, 12 res
	[33139]-- Delicate Bladestone, yellow, 12 int
	[33141]-- Rigid Bladestone, blue, 12 hit
	[33142]-- Rigid Bladestone, yellow, 12 hit
	]]

	[22459] = {r = 4, [102] = true, [11] = true, [12] = true, [13] = true, [86] = true},	-- Void Sphere, red, yellow, blue, 4 resist all
	[22460] = {r = 3, [102] = true, [11] = true, [12] = true, [13] = true, [86] = true},	-- Prismatic Sphere, red, yellow, blue, 3 resist all
	[23094] = {r = 2, [101] = true, [22] = true, [12] = true, [64] = true},	-- Brilliant Blood Garnet, red, 6 int
	[23095] = {r = 2, [101] = true, [22] = true, [12] = true, [61] = true},	-- Bold Blood Garnet, red, 6 str
	[23096] = {r = 2, [12] = true, [64] = true},	-- Brilliant Blood Garnet, red, 7 int
	[23097] = {r = 2, [12] = true, [62] = true},	-- Delicate Blood Garnet, red, 6 agi
	[23098] = {r = 2, [101] = true, [25] = true, [13] = true, [12] = true, [72] = true, [61] = true},	-- Inscribed Flame Spessarite, yellow, red, 3 crit, 3 str
	[23099] = {r = 2, [101] = true, [25] = true, [13] = true, [12] = true, [70] = true, [64] = true},	-- Reckless Flame Spessarite, yellow, red, 3 haste, 3 int
	[23100] = {r = 2, [101] = true, [26] = true, [12] = true, [11] = true, [71] = true, [62] = true},	-- Glinting Shadow Draenite, red, blue, 3 hit, 3 agi
	[23101] = {r = 2, [101] = true, [25] = true, [13] = true, [12] = true, [72] = true, [64] = true},	-- Potent Flame Spessarite, yellow, red, 3 crit, 3 int
	[23103] = {r = 2, [101] = true, [24] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Deep Peridot, yellow, blue, 3 crit, 4 spellpenet
	[23104] = {r = 2, [101] = true, [24] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Deep Peridot, yellow, blue, 3 crit, 4 stam
	[23105] = {r = 2, [101] = true, [24] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Deep Peridot, yellow, blue, 3 dodge, 4 stam
	[23106] = {r = 2, [12] = true, [11] = true, [65] = true, [64] = true},	-- Purified Shadow Draenite, red, blue, 3 spi, 3 int
	[23108] = {r = 2, [101] = true, [26] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Shadow Draenite, red, blue, 3 int, 4 stam
	[23109] = {r = 2, [101] = true, [26] = true, [12] = true, [11] = true, [65] = true, [64] = true},	-- Purified Shadow Draenite, red, blue, 3 int, 3 spi
	[23110] = {r = 2, [101] = true, [26] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadow Draenite, red, blue, 3 agi, 4 stam
	[23111] = {r = 2, [101] = true, [26] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Shadow Draenite, red, blue, 3 str, 4 stam
	[23113] = {r = 2, [12] = true, [64] = true},	-- Brilliant Blood Garnet, red, 6 int
	[23114] = {r = 2, [101] = true, [23] = true, [13] = true, [72] = true},	-- Smooth Golden Draenite, yellow, 6 crit
	[23115] = {r = 2, [101] = true, [23] = true, [13] = true, [74] = true},	-- Subtle Golden Draenite, yellow, 6 dodge
	[23116] = {r = 2, [101] = true, [21] = true, [11] = true, [71] = true},	-- Rigid Azure Moonstone, blue, 6 hit
	[23118] = {r = 2, [101] = true, [21] = true, [11] = true, [63] = true},	-- Solid Azure Moonstone, blue, 9 stam
	[23119] = {r = 2, [101] = true, [21] = true, [11] = true, [65] = true},	-- Sparkling Azure Moonstone, blue, 6 spi
	[23120] = {r = 2, [101] = true, [21] = true, [11] = true, [82] = true},	-- Stormy Azure Moonstone, blue, 8 spellpenet
	[23121] = {r = 2, [101] = true, [21] = true, [11] = true, [65] = true},	-- Sparkling Azure Moonstone, blue, 6 spi
	[24027] = {r = 3, [101] = true, [32] = true, [12] = true, [61] = true},	-- Bold Living Ruby, red, 8 str
	[24028] = {r = 3, [101] = true, [32] = true, [12] = true, [62] = true},	-- Delicate Living Ruby, red, 8 agi
	[24029] = {r = 3, [12] = true, [64] = true},	-- Brilliant Living Ruby, red, 8 int
	[24030] = {r = 3, [101] = true, [32] = true, [12] = true, [64] = true},	-- Brilliant Living Ruby, red, 8 int
	[24031] = {r = 3, [12] = true, [62] = true},	-- Delicate Living Ruby, red, 8 agi
	[24032] = {r = 3, [101] = true, [33] = true, [13] = true, [74] = true},	-- Subtle Dawnstone, yellow, 8 dodge
	[24033] = {r = 3, [101] = true, [31] = true, [11] = true, [63] = true},	-- Solid Star of Elune, blue, 12 stam
	[24035] = {r = 3, [101] = true, [31] = true, [11] = true, [65] = true},	-- Sparkling Star of Elune, blue, 8 spi
	[24036] = {r = 3, [101] = true, [32] = true, [12] = true, [76] = true},	-- Flashing Living Ruby, red, 8 parry
--	[24037] = {r = 3, [11] = true, [65] = true},	-- Sparkling Star of Elune, blue, 8 spi
	[24039] = {r = 3, [101] = true, [31] = true, [11] = true, [82] = true},	-- Stormy Star of Elune, blue, 10 spellpenet
	[24047] = {r = 3, [12] = true, [64] = true},	-- Brilliant Living Ruby, red, 8 int
	[24048] = {r = 3, [101] = true, [33] = true, [13] = true, [72] = true},	-- Smooth Dawnstone, yellow, 8 crit
	[24050] = {r = 3, [13] = true, [72] = true},	-- Smooth Dawnstone, yellow, 8 spell crit
	[24051] = {r = 3, [101] = true, [31] = true, [11] = true, [71] = true},	-- Rigid Star of Elune, blue, 8 hit
	[24052] = {r = 3, [13] = true, [74] = true},	-- Subtle Dawnstone, yellow, 8 dodge
	[24053] = {r = 3, [101] = true, [33] = true, [13] = true, [66] = true},		-- Mystic Dawnstone, yellow, 8 res
	[24054] = {r = 3, [101] = true, [36] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Nightseye, red, blue, 4 str, 6 stam
	[24055] = {r = 3, [101] = true, [36] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Nightseye, red, blue, 4 agi, 6 stam
	[24056] = {r = 3, [101] = true, [36] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Nightseye, red, blue, 5 intel, 6 stam
	[24057] = {r = 3, [12] = true, [11] = true, [65] = true, [64] = true},	-- Purified Nightseye, red, blue, 4 int, 4 spi
	[24058] = {r = 3, [101] = true, [35] = true, [13] = true, [12] = true, [72] = true, [61] = true},	-- Inscribed Noble Topaz, red, yellow, 4 crit, 4 str
	[24059] = {r = 3, [101] = true, [35] = true, [13] = true, [12] = true, [72] = true, [64] = true},	-- Potent Noble Topaz, red, yellow, 4 crit, 4 int
	[24060] = {r = 3, [101] = true, [35] = true, [13] = true, [12] = true, [70] = true, [64] = true},	-- Reckless Noble Topaz, red, yellow, 4 haste, 4 int
	[24061] = {r = 3, [101] = true, [36] = true, [12] = true, [11] = true, [71] = true, [62] = true},	-- Glinting Nightseye, red, blue, 4 hit, 4 agi
	[24062] = {r = 3, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Talasite, yellow, blue, 4 dodge, 6 stam
	[24065] = {r = 3, [101] = true, [36] = true, [12] = true, [11] = true, [65] = true, [64] = true},	-- Purified Nightseye, yellow, blue, 4 int, 4 spi
	[24066] = {r = 3, [101] = true, [34] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Talasite, blue, yellow, 4 crit, 5 spellpenet
	[24067] = {r = 3, [101] = true, [34] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Talasite, yellow, blue, 4 crit, 6 stam
	[25890] = {r = 3, [101] = true, [41] = true, [14] = true, [72] = true}, -- Destructive Skyfire Diamond, meta, 14 crit, 1% spellreflect
	[25893] = {r = 3, [101] = true, [41] = true, [14] = true, [0] = true},	-- Mystical Skyfire Diamond, meta, spell haste for 6 seconds
	[25894] = {r = 3, [101] = true, [41] = true, [14] = true, [72] = true},	-- Swift Skyfire Diamond, meta, 12 crit, minor run speed increase
	[25895] = {r = 3, [101] = true, [41] = true, [14] = true, [72] = true},	-- Enigmatic Skyfire Diamond, meta, 12 crit, 10% snare and root effects reduced
	[25896] = {r = 3, [101] = true, [42] = true, [14] = true, [63] = true},	-- Powerful Earthstorm Diamond, meta, 18 stam, stun duration reduced by 10%
	[25897] = {r = 3, [101] = true, [42] = true, [14] = true, [64] = true},	-- Bracing Earthstorm Diamond, meta, 14 spell, 2% reduced threat
	[25898]	= {r = 3, [101] = true, [42] = true, [14] = true, [74] = true},	-- Tenacious Earthstorm Diamond, meta, 12 dodge, chance to restore spellth on hit
	[25899]	= {r = 3, [101] = true, [42] = true, [14] = true, [0] = true},	-- Brutal Earthstorm Diamond, meta, +3 melee damage, chance to stun target
	[25901]	= {r = 3, [101] = true, [42] = true, [14] = true, [64] = true},	-- Insightful Earthstorm Diamond, meta, 12 int, chance to restore mana on spellcast
	[27679]	= {r = 4, [103] = true, [13] = true, [66] = true},	-- Mystic Dawnstone, yellow, 10 res
--	[27777] = {r = 3, [103] = true, [12] = true, [64] = true},	-- Brilliant Blood Garnet, red, 7 int
--	[27785] = {r = 3, [103] = true, [13] = true, [11] = true, [63] = true, [72] = true},	-- Jagged Deep Peridot, yellow, blue, 3 stam, 4 crit
--	[27786] = {r = 3, [103] = true, [13] = true, [11] = true, [63] = true, [72] = true},	-- Jagged Deep Peridot, yellow, blue, 3 stam, 4 crit
	[27809] = {r = 3, [103] = true, [13] = true, [11] = true, [63] = true, [72] = true},	-- Jagged Deep Peridot, yellow, blue, 3 stam, 4 crit
	[27812] = {r = 3, [103] = true, [12] = true, [64] = true},	-- Brilliant Blood Garnet, red, 7 int
	[27820] = {r = 3, [103] = true, [13] = true, [11] = true, [63] = true, [72] = true},	-- Jagged Deep Peridot, yellow, blue, 3 stam, 4 crit
	[28118] = {r = 4, [103] = true, [12] = true, [64] = true},	-- Brilliant Ornate Ruby, red, 10 int
	[28119] = {r = 4, [103] = true, [13] = true, [72] = true},	-- Smooth Ornate Dawnstone, yellow, 10 crit
	[28120] = {r = 4, [103] = true, [13] = true, [72] = true},	-- Smooth Ornate Dawnstone, yellow, 10 crit
	[28123] = {r = 4, [103] = true, [12] = true, [13] = true, [72] = true, [64] = true},	-- Potent Ornate Topaz, red, yellow, 5 crit, 5 int
	[28290] = {r = 2, [101] = true, [23] = true, [13] = true, [72] = true},	-- Smooth Golden Draenite, yellow, 6 crit
--	[28360] = {r = 3, [103] = true, [12] = true, [62] = true},	-- Delicate Blood Garnet, red, 7 agi
	[28361] = {r = 3, [103] = true, [12] = true, [62] = true},	-- Delicate Blood Garnet, red, 7 agi
	[28362] = {r = 4, [103] = true, [12] = true, [62] = true},	-- Delicate Ornate Ruby, red, 10 agi
	[28363] = {r = 4, [103] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Ornate Topaz, red, yellow, 5 agil, 5 crit
	[28458] = {r = 1, [103] = true, [12] = true, [61] = true},	-- Bold Tourmaline, red, 4 str
	[28459] = {r = 1, [103] = true, [12] = true, [62] = true},	-- Delicate Tourmaline, red, 4 agi
	[28460] = {r = 1, [103] = true, [12] = true, [64] = true},	-- Brilliant Tourmaline, red, 4 int
	[28461] = {r = 1, [103] = true, [12] = true, [64] = true},	-- Brilliant Tourmaline, red, 4 int
	[28462] = {r = 1, [103] = true, [12] = true, [62] = true},	-- Delicate Tourmaline, red, 4 agi
	[28463] = {r = 1, [103] = true, [11] = true, [63] = true},	-- Solid Zircon, blue, 6 stam
	[28464] = {r = 1, [103] = true, [11] = true, [65] = true},	-- Sparkling Zircon, blue, 4 spi
	[28465] = {r = 1, [103] = true, [11] = true, [65] = true},	-- Sparkling Zircon, blue, 4 spi
	[28466] = {r = 1, [103] = true, [12] = true, [64] = true},	-- Brilliant Tourmaline, red, 4 int
	[28467] = {r = 1, [103] = true, [13] = true, [72] = true},	-- Smooth Amber, yellow, 4 crit
	[28468] = {r = 1, [103] = true, [11] = true, [71] = true},	-- Rigid Zircon, blue, 4 hit
	[28469] = {r = 1, [103] = true, [13] = true, [72] = true},	-- Smooth Amber, yellow, 4 crit
	[28470] = {r = 1, [103] = true, [13] = true, [74] = true},	-- Subtle Amber, yellow, 4 dodge
	[28556] = {r = 3, [103] = true, [14] = true, [72] = true},	-- Swift Windfire Diamond, meta, 10 crit, minor run speed increase
	[28557] = {r = 3, [103] = true, [14] = true, [64] = true},	-- Quickend Starfire Diamond, meta, 10 int, minor run speed increase
	[28595] = {r = 2, [101] = true, [22] = true, [12] = true, [62] = true},	-- Delicate Blood Garnet, red, 6 agi (was Bright Blood Garnet, red, 12 atk pwr)
	[30546]	= {r = 4, [104] = true, [12] = true, [11] = true, [61] = true, [63]	= true},	-- Sovereign Tanzanite, red, blue, 5 str, 6 stam
	[30547] = {r = 4, [104] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Fire Opal, red, yellow, 5 int, 4 haste
	[30548] = {r = 4, [104] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Chrysoprase, yellow, blue, 5 crit, 6 stam
	[30549] = {r = 4, [104] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Tanzanite, red, blue, 5 agi, 4 stam
	[30550] = {r = 4, [104] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Chrysoprase, yellow, blue, 5 crit, 4 spi
	[30551] = {r = 4, [104] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Fire Opal, red, yellow, 5 int, 4 haste
	[30552] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Tanzanite, red, blue, 5 int, 6 stam
	[30553] = {r = 4, [104] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Tanzanite, red, blue, 5 agi, 4 hit
	[30554] = {r = 4, [104] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Fire Opal, red, yellow, 5 parry, 4 dodge
	[30555]	= {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Tanzanite, red, blue, 5 int, 6 stam
	[30556] = {r = 4, [104] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Tanzanite, red, blue, 5 agi, 4 hit
	[30558] = {r = 4, [104] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Fire Opal, red, blue, 5 parry, 4 dodge
	[30559] = {r = 4, [104] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Tanzanite, red, blue, 5 str, 4 hit
	[30560] = {r = 4, [104] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Chrysoprase, yellow, blue, 5 crit, 4 spi
	[30563]	= {r = 4, [104] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Chrysoprase, yellow, blue, 5 dodge, 6 stam
	[30564] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Tanzanite, red, blue, 5 int, 4 hit
	[30565] = {r = 4, [104] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Chrysoprase, yellow, blue, 5 crit, 6 stam
	[30566] = {r = 4, [104] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Tanzanite, red, blue, 5 parry, 6 stam
	[30571] = {r = 3, [103] = true, [12] = true, [61] = true},	-- Don Rodrigo's Heart, red, 8 str
	[30572] = {r = 4, [104] = true, [12] = true, [11] = true, [65] = true, [64] = true},	-- Purified Tanzanite, red, blue, 5 spi, 5 int
	[30573] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Tanzanite, red, blue, 5 int, 5 spellpenet
	[30574] = {r = 4, [104] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Tanzanite, red, blue, 5 agi, 6 stam
	[30575] = {r = 4, [104] = true, [11] = true, [13] = true, [74] = true, [71] = true},	-- Nimble Chrysoprase, blue, yellow, 5 dodge, 4 hit
	[30581] = {r = 4, [104] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Fire Opal, red, yellow, 5 int, 4 res
	[30582] = {r = 4, [104] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Fire Opal, red, yellow, 5 agi, 4 crit
	[30583] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Tanzanite, red, blue, 5 int, 6 stam
	[30584] = {r = 4, [104] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Fire Opal, red, yellow, 5 str, 4 crit
	[30585] = {r = 4, [104] = true, [12] = true, [13] = true, [62] = true, [74] = true},	-- Polished Fire Opal, red, yellow, 4 agi, 5 dodge
	[30586] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Tanzanite, red, blue, 5 int, 4 spi
	[30587] = {r = 4, [104] = true, [12] = true, [13] = true, [61] = true, [74] = true},	-- Champion's Fire Opal, red, yellow, 5 str, 4 dodge
	[30588] = {r = 4, [104] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Fire Opal, red, yellow, 5 int, 4 crit
	[30589] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Tanzanite, red, blue, 5 int, 4 spi
	[30590] = {r = 4, [104] = true, [13] = true, [11] = true, [63] = true, [74] = true},	-- Regal Chrysoprase, yellow, blue, 6 stam, 5 dodge
	[30591] = {r = 4, [104] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Fire Opal, red, yellow, 5 agil, 4 resil
	[30592] = {r = 4, [104] = true, [13] = true, [11] = true, [63] = true, [66] = true},	-- Steady Chrysoprase, yellow, blue, 6 stam, 5 res
	[30593] = {r = 4, [104] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Fire Opal, red, yellow, 5 int, 4 crit
	[30594] = {r = 4, [104] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Chrysoprase, yellow, blue, 5 dodge, 6 stam
	[30598] = {r = 3, [103] = true, [12] = true, [61] = true},	-- Don Amancio's Heart, red, 8 str
	[30600] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Tanzanite, red, blue, 5 int, 4 spi
	[30601] = {r = 4, [104] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Chrysoprase, yellow, blue, 5 resil, 6 stam
	[30602] = {r = 4, [104] = true, [13] = true, [11] = true, [63] = true, [72] = true},	-- Jagged Chrysoprase, yellow, blue, 6 stam, 5 crit
	[30603]	= {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Tanzanite, red, blue, 5 int, 4 spi
	[30604] = {r = 4, [104] = true, [12] = true, [13] = true, [61] = true, [66] = true},	-- Resplendent Fire Opal, red, yellow, 5 str, 4 res
	[30605] = {r = 4, [104] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Nimble Chrysoprase, yellow, blue, 5 hit, 6 dodge
	[30606] = {r = 4, [104] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Chrysoprase, yellow, blue, 5 hit, 4 haste
	[30607] = {r = 4, [104] = true, [12] = true, [13] = true, [76] = true, [66] = true},	-- Splendid Fire Opal, red, yellow, 5 parry, 4 res
	[30608] = {r = 4, [104] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Chrysoprase, yellow, blue, 5 crit, 5 spellpenet
	[31116] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Amethyst, red, blue, 5 int, 6 stam
	[31117] = {r = 4, [104] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Tireless Soothing Amethyst, red, blue, 5 int, 6 stam
	[31118] = {r = 4, [104] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Amethyst, red, blue, 5 str, 6 stam
	[31860] = {r = 2, [11] = true, [71] = true},				-- Rigid Azure Moonstone, blue, 6 hit
	[31861] = {r = 3, [11] = true, [71] = true},		-- Rigid Star of Elune, blue, 8 hit
	[31862] = {r = 2, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadow Draenite, red, blue, 3 agil, 4 stam
	[31863] = {r = 3, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Nightseye, red, blue, 4 agil, 6 stam
	[31864] = {r = 2, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadow Draenite, red, blue, 3 agil, 4 stam
	[31865] = {r = 3, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Nightseye, red, blue, 4 agi, 4 hit
	[31866] = {r = 2, [101] = true, [26] = true, [11] = true, [12] = true, [64] = true, [71] = true},	-- Veiled Shadow Draenite, blue, red, 3 int, 3 hit
	[31867] = {r = 3, [101] = true, [35] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Nightseye, red, blue, 4 int, 4 hit
	[31868] = {r = 3, [101] = true, [35] = true, [13] = true, [12] = true, [62] = true, [72] = true},	-- Deadly Noble Topaz, red, yellow, 4 agi, 4 crit
	[31869] = {r = 2, [101] = true, [25] = true, [13] = true, [12] = true, [72] = true, [62] = true},	-- Deadly Flame Spessarite, yellow, red, 3 crit, 3 agil
	[32193] = {r = 4, [101] = true, [52] = true, [12] = true, [61] = true},	-- Bold Crimson Spinel, red, 10 str
	[32194] = {r = 4, [101] = true, [52] = true, [12] = true, [62] = true},	-- Delicate Crimson Spinel, red, 10 agi
	[32195] = {r = 4, [12] = true, [64] = true},	-- Brilliant Crimson Spinel, red, 10 int
	[32196] = {r = 4, [101] = true, [52] = true, [12] = true, [64] = true},	-- Brilliant Crimson Spinel, red, 10 int
	[32197] = {r = 4, [12] = true, [62] = true},	-- Delicate Crimson Spinel, red, 10 agi
	[32198] = {r = 4, [101] = true, [53] = true, [13] = true, [74] = true},	-- Subtle Lionseye, yellow, 10 dodge
	[32199] = {r = 4, [101] = true, [52] = true, [12] = true, [76] = true},	-- Flashing Crimson Spinel, red, 10 parry
	[32200] = {r = 4, [101] = true, [51] = true, [11] = true, [63] = true},	-- Solid Empyrean Sapphire, blue, 15 stam
	[32201] = {r = 4, [101] = true, [51] = true, [11] = true, [65] = true},	-- Sparkling Empyrean Sapphire, blue, 10 spi
	[32202] = {r = 4, [11] = true, [65] = true},	-- Sparkling Empyrean Sapphire, blue, 10 spi
	[32203] = {r = 4, [101] = true, [51] = true, [11] = true, [82] = true},	-- Stormy Empyrean Sapphire, blue, 13 spellpene
	[32204] = {r = 4, [12] = true, [64] = true},	-- Brilliant Crimson Spinel, red, 10 int
	[32205] = {r = 4, [101] = true, [53] = true, [13] = true, [72] = true},	-- Smooth Lionseye, yellow, 10 crit
	[32206] = {r = 4, [101] = true, [51] = true, [11] = true, [71] = true},	-- Rigid Empyrean Sapphire, blue, 10 hit
	[32207] = {r = 4, [13] = true, [72] = true},	-- Smooth Lionseye, yellow, 10 crit
	[32208] = {r = 4, [13] = true, [74] = true},	-- Subtle Lionseye, yellow, 10 dodge
	[32209] = {r = 4, [101] = true, [53] = true, [13] = true, [66] = true},	-- Mystic Lionseye, yellow, 10 res
	[32210] = {r = 4, [11] = true, [71] = true},	-- Rigid Empyrean Sapphire, blue, 10 hit
	[32211] = {r = 4, [101] = true, [56] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Shadowsong Amethyst, red, blue, 5 str, 7 stam
	[32212] = {r = 4, [101] = true, [56] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadowsong Amethyst, red, blue, 5 agi, 7 stam
	[32213] = {r = 4, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadowsong Amethyst, red, blue, 5 agi, 7 stam
	[32214] = {r = 4, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Shadowsong Amethyst, red, blue, 5 agi, 5 hit
	[32215] = {r = 4, [101] = true, [56] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Shadowsong Amethyst, red, blue, 5 int, 7 stam
	[32216] = {r = 4, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadowsong Amethyst, red, blue, 5 int, 5 spi
	[32217] = {r = 4, [101] = true, [55] = true, [12] = true, [13] = true, [72] = true, [61] = true},	-- Inscribed Pyrestone, red, yellow, 5 crit, 5 str
	[32218] = {r = 4, [101] = true, [55] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Pyrestone, red, yellow, 5 int, 5 crit
	[32219] = {r = 4, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Pyrestone, red, yellow, 5 int, 5 haste
	[32220] = {r = 4, [101] = true, [56] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Shadowsong Amethyst, red, blue, 5 agil, 5 hit
	[32221] = {r = 4, [101] = true, [56] = true, [12] = true, [11] = true, [71] = true, [64] = true},	-- Veiled Shadowsong Amethyst, red, blue, 5 hit, 5 int
	[32222] = {r = 4, [101] = true, [55] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Pyrestone, red, yellow, 5 agil, 5 crit
	[32223] = {r = 4, [101] = true, [54] = true, [11] = true, [13] = true, [74] = true, [63] = true},	-- Regal Seaspray Emerald, blue, yellow, 5 dodge, 7 stam
	[32224] = {r = 4, [101] = true, [54] = true, [11] = true, [13] = true, [72] = true, [82] = true},	-- Radiant Seaspray Emerald, blue, yellow, 5 crit, 6 spellpene
	[32225] = {r = 4, [101] = true, [56] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadowsong Amethyst, red, blue, 5 int, 5 spi
	[32226] = {r = 4, [101] = true, [54] = true, [11] = true, [13] = true, [72] = true, [63] = true},	-- Jagged Seaspray Emerald, blue, yellow, 5 crit, 7 stam
	[32409] = {r = 3, [101] = true, [42] = true, [14] = true, [62] = true},		-- Relentless Earthstorm Diamond, meta, 12 agi, 3% increased critical damage
	[32410] = {r = 3, [101] = true, [41] = true, [14] = true, [0] = true},		-- Thundering Skyfire Diamond, meta, Chance to increase melee/ranged attack speed
	[32634] = {r = 3, [103] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Amethyst, red, blue, 5 agi, 6 stam
	[32635] = {r = 3, [103] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Amethyst, red, blue, 4 int, 6 stam
	[32636] = {r = 3, [103] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Amethyst, red, blue, 5 int, 4 spi
	[32637] = {r = 3, [103] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Citrine, red, yellow, 5 agil, 4 crit
	[32638] = {r = 3, [103] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Citrine, red, yellow, 5 int, 4 haste
	[32639] = {r = 3, [103] = true, [11] = true, [13] = true, [63] = true, [72] = true},	-- Jagged Mossjewel, blue, yellow, 4 stam, 4 crit
	[32640] = {r = 3, [103] = true, [14] = true, [72] = true},	-- Tense Unstable Diamond, meta, 12 crit, 5% stun resist
	[32641] = {r = 3, [103] = true, [14] = true, [64] = true},	-- Imbued Unstable Diamond, meta, 12 int, 5% stun resist
	[32833] = {r = 2, [101] = true, [27] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Jaggal Pearl, red, blue, 3 int, 3 spi
	[32836] = {r = 3, [101] = true, [37] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadow Pearl, red, blue, 4 int, 4 spi
	[33131] = {r = 5, [101] = true, [32] = true, [12] = true, [62] = true, [1013] = true},	-- Crimson Sun, red, 12 agi
	[33133] = {r = 5, [101] = true, [32] = true, [12] = true, [64] = true, [1013] = true},	-- Don Julio's Heart, red, 12 int
	[33134] = {r = 5, [101] = true, [32] = true, [12] = true, [64] = true, [1013] = true},	-- Kailee's Rose, red, 12 int
	[33135] = {r = 5, [101] = true, [31] = true, [11] = true, [63] = true, [1013] = true},	-- Falling Star, blue, 18 stam
	[33140] = {r = 5, [101] = true, [33] = true, [13] = true, [72] = true, [1013] = true},	-- Blood of Ember, yellow, 12 crit
	[33143] = {r = 5, [101] = true, [33] = true, [13] = true, [72] = true, [1013] = true},	-- Stone of Blades, yellow, 12 crit
	[33144] = {r = 5, [101] = true, [33] = true, [13] = true, [74] = true, [1013] = true},	-- Facet of Eternity, yellow, 12 dodge
	[33782] = {r = 3, [101] = true, [34] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Talasite, yellow, blue, 4 res, 6 stam
	[34220] = {r = 3, [101] = true, [41] = true, [14] = true, [72] = true},	-- Chaotic Skyfire Diamond, meta, +12 crit, +3% increased critical damage
	[34256] = {r = 4, [104] = true, [11] = true, [63] = true},	-- Charmed Amani Jewel, blue, 15 stam
	[34831] = {r = 3, [104] = true, [11] = true, [63] = true},	-- Eye of the Sea, blue, 15 stam
	[35315] = {r = 3, [101] = true, [33] = true, [13] = true, [70] = true},	-- Quick Dawnstone, yellow, 8 haste
	[35316] = {r = 3, [13] = true, [12] = true, [64] = true, [70] = true},	-- Reckless Noble Topaz, red, yellow, 4 int, 4 haste
	[35318] = {r = 3, [101] = true, [34] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Talasite, yellow, blue, 4 haste, 6 stam
	[35501] = {r = 3, [101] = true, [42] = true, [14] = true, [74] = true},	-- Eternal Earthstorm Diamond, meta, +12 dodge, +1% shieldblock
	[35503] = {r = 3, [101] = true, [41] = true, [14] = true, [64] = true},	-- Ember Skyfire Diamond, meta, 12 int, +2% maximum mana
	[35707] = {r = 3, [101] = true, [34] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Talasite, yellow, blue, 4 dodge, 6 stam
	[35758] = {r = 4, [101] = true, [54] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Seaspray Emerald, yellow, blue, 5 res, 7 stam
	[35759] = {r = 4, [101] = true, [54] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Seaspray Emerald, yellow, blue, 5 haste, 7 stam
	[35760] = {r = 4, [101] = true, [55] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Pyrestone, red, yellow, 5 int, 5 haste
	[35761] = {r = 4, [101] = true, [53] = true, [13] = true, [70] = true},	-- Quick Lionseye, yellow, 10 haste
	[36766] = {r = 16, [101] = true, [143] = true, [12] = true, [62] = true, [1013] = true},	-- Delicate Dragon's Eye, red, 34 agil
	[36767] = {r = 16, [101] = true, [143] = true, [11] = true, [63] = true, [1013] = true},	-- Solid Dragon's Eye, blue, 51 stam
	[37503] = {r = 4, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadowsong Amethyst, red, blue, 5 int, 5 spi
	[39900] = {r = 11, [101] = true, [122] = true, [12] = true, [61] = true},	-- Bold Bloodstone, red, 12 str
	[39905] = {r = 11, [101] = true, [122] = true, [12] = true, [62] = true},	-- Delicate Bloodstone, red, 12 agi
	[39906] = {r = 11, [12] = true, [62] = true},	-- Delicate Bloodstone, red, 12 agil
	[39907] = {r = 11, [101] = true, [123] = true, [13] = true, [74] = true},	-- Subtle Sun Crystal, yellow, 12 dodge
	[39908] = {r = 11, [101] = true, [122] = true, [12] = true, [76] = true},	-- Flashing Bloodstone, red, 12 parry
	[39909] = {r = 11, [101] = true, [123] = true, [13] = true, [72] = true},	-- Smooth Sun Crystal, yellow, 12 crit
	[39910] = {r = 11, [101] = true, [122] = true, [12] = true, [84] = true},	-- Precise Bloodstone, red, 12 expert
	[39911] = {r = 11, [12] = true, [64] = true},	-- Brilliant Bloodstone, red, 12 int
	[39912] = {r = 11, [101] = true, [122] = true, [12] = true, [64] = true},	-- Brilliant Bloodstone, red, 12 int
	[39914] = {r = 11, [13] = true, [72] = true},	-- Smooth Sun Crystal, yellow, 12 crit
	[39915] = {r = 11, [101] = true, [121] = true, [11] = true, [71] = true},	-- Rigid Chalcedony, blue, 12 hit
	[39916] = {r = 11, [101] = true, [123] = true, [13] = true, [74] = true},	-- Subtle Sun Crystal, yellow, 12 dodge
	[39917] = {r = 11, [101] = true, [123] = true, [13] = true, [66] = true},	-- Mystic Sun Crystal, yellow, 12 res
	[39918] = {r = 11, [101] = true, [123] = true, [13] = true, [70] = true},	-- Quick Sun Crystal, yellow, 12 haste
	[39919] = {r = 11, [101] = true, [121] = true, [11] = true, [63] = true},	-- Solid Chalcedony, blue, 18 stam
	[39920] = {r = 11, [11] = true, [65] = true},	-- Sparkling Chalcedony, blue, 12 spi
	[39927] = {r = 11, [101] = true, [121] = true, [11] = true, [65] = true},	-- Sparkling Chalcedony, blue, 12 spi
	[39932] = {r = 11, [101] = true, [121] = true, [11] = true, [82] = true},	-- Stormy Chalcedony, blue, 15 spellpenet
	[39933] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Dark Jade, yellow, blue, 6 crit, 9 stam
	[39934] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Shadow Crystal, red, blue, 6 str, 9 stam
	[39935] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadow Crystal, red, blue, 6 agi, 9 stam
	[39936] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Shadow Crystal, red, blue, 6 int, 9 stam
	[39937] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Shadow Crystal, red, blue, 6 agil, 9 stam
	[39938] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Dark Jade, yellow, blue, 6 dodge, 9 stam
	[39939] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Shadow Crystal, red, blue, 6 parry, 9 stam
	[39940] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian Shadow Crystal, red, blue, 6 expert, 9 stam
	[39941] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadow Crystal, red, blue, 6 int, 6 spi
	[39942] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Shadow Crystal, red, blue, 6 agi, 6 hit
	[39943] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadow Crystal, red, blue, 6 int, 6 spi
	[39944] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Shadow Crystal, red, blue, 6 agil, 6 hit
	[39945] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Shadow Crystal, red, blue, 6 int, 8 spellpenet
	[39946] = {r = 11, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Huge Citrine, red, yellow, 6 int, 6 haste
	[39947] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Huge Citrine, red, yellow, 6 str, 6 crit
	[39948] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Shadow Crystal, red, blue, 6 str, 6 hit
	[39949] = {r = 11, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [74] = true},	-- Champion's Huge Citrine, yellow, red, 6 str, 6 dodge
	[39950] = {r = 11, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [66] = true},	-- Resplendent Huge Citrine, yellow, red, 6 str, 6 res
	[39951] = {r = 11, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [70] = true},	-- Fierce Huge Citrine, yellow, red, 6 str, 6 haste
	[39952] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Huge Citrine, red, yellow, 6 agi, 6 crit
	[39953] = {r = 11, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Shadow Crystal, red, blue, 6 agi, 6 hit
	[39954] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Huge Citrine, red, yellow, 6 agi, 6 res
	[39955] = {r = 11, [101] = true, [125] = true, [13] = true, [12] = true, [62] = true, [70] = true},	-- Deft Huge Citrine, yellow, red, 6 agi, 6 haste
	[39956] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Huge Citrine, red, yellow, 6 int, 6 crit
	[39957] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Shadow Crystal, red, blue, 6 int, 6 hit
	[39958] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Huge Citrine, red, yellow, 6 int, 6 res
	[39959] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Huge Citrine, red, yellow, 6 int, 6 haste
	[39960] = {r = 11, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Huge Citrine, red, yellow, 6 agil, 6 crit
	[39961] = {r = 11, [101] = true, [125] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Shadow Crystal, red, blue, 6 agil, 6 hit
	[39962] = {r = 11, [13] = true, [12] = true, [62] = true, [66] = true},	-- Lucent Huge Citrine, yellow, red, 6 agil, 6 res
	[39963] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Huge Citrine, red, yellow, 6 agil, 6 haste
	[39964] = {r = 11, [12] = true, [13] = true, [74] = true, [76] = true},	-- Stalwart Huge Citrine, red, yellow, 6 dodge, 6 parry
	[39965] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Huge Citrine, red, yellow, 6 parry, 6 dodge
	[39966] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Shadow Crystal, red, blue, 6 expert, 6 hit
	[39967] = {r = 11, [101] = true, [125] = true, [12] = true, [13] = true, [84] = true, [74] = true},	-- Resolute Huge Citrine, red, yellow, 6 expert, 6 dodge
	[39968] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Shadow Crystal, red, blue, 6 int, 9 stam
	[39974] = {r = 11, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Dark Jade, yellow, blue, 6 crit, 9 stam
	[39975] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Nimble Dark Jade, yellow, blue, 6 hit, 6 dodge
	[39976] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Dark Jade, yellow, blue, 6 dodge, 9 stam
	[39977] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Dark Jade, yellow, blue, 6 res, 9 stam
	[39978] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Dark Jade, yellow, blue, 6 haste, 9 stam
	[39979] = {r = 11, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadow Crystal, red, blue, 6 int, 6 spi
	[39980] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Dark Jade, yellow, blue, 6 crit, 6 spi
	[39981] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Dark Jade, yellow, blue, 6 hit, 6 haste
	[39982] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Turbid Dark Jade, yellow, blue, 6 res, 6 spi
	[39983] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Dark Jade, yellow, blue, 6 haste, 6 spi
	[39984] = {r = 11, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Shadow Crystal, red, blue, 6 int, 6 spi
	[39985] = {r = 11, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Dark Jade, yellow, blue, 6 crit, 6 spi
	[39986] = {r = 11, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Dark Jade, yellow, blue, 6 hit, 6 haste
	[39988] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Turbid Dark Jade, yellow, blue, 6 res, 6 spi
	[39989] = {r = 11, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Dark Jade, yellow, blue, 6 haste, 6 spi
	[39990] = {r = 11, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Dark Jade, yellow, blue, 6 crit, 8 spellpenet
	[39991] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Dark Jade, yellow, blue, 6 crit, 8 spellpenet
	[39992] = {r = 11, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Shattered Dark Jade, yellow, blue, 6 haste, 8 spellpenet
	[39996] = {r = 13, [101] = true, [132] = true, [12] = true, [61] = true},	-- Bold Scarlet Ruby, red, 16 str
	[39997] = {r = 13, [101] = true, [132] = true, [12] = true, [62] = true},	-- Delicate Scarlet Ruby, red, 16 agi
	[39998] = {r = 13, [101] = true, [132] = true, [12] = true, [64] = true},	-- Brilliant Scarlet Ruby, red, 16 int
	[39999] = {r = 13, [101] = true, [132] = true, [12] = true, [62] = true},	-- Delicate Scarlet Ruby, red, 16 agil
	[40000] = {r = 13, [101] = true, [133] = true, [13] = true, [74] = true},	-- Subtle Autumn's Glow, yellow, 16 dodge
	[40001] = {r = 13, [101] = true, [132] = true, [12] = true, [76] = true},	-- Flashing Scarlet Ruby, red, 16 parry
	[40002] = {r = 13, [101] = true, [133] = true, [13] = true, [72] = true},	-- Smooth Autumn's Glow, yellow, 16 crit
	[40003] = {r = 13, [101] = true, [132] = true, [12] = true, [84] = true},	-- Precise Scarlet Ruby, red, 16 expert
	[40008] = {r = 13, [101] = true, [131] = true, [11] = true, [63] = true},	-- Solid Sky Sapphire, blue, 24 stam
	[40009] = {r = 13, [101] = true, [131] = true, [11] = true, [65] = true},	-- Sparkling Sky Sapphire, blue, 16 spi
	[40010] = {r = 13, [101] = true, [131] = true, [11] = true, [65] = true},	-- Sparkling Sky Sapphire, blue, 16 spi
	[40011] = {r = 13, [101] = true, [131] = true, [11] = true, [82] = true},	-- Stormy Sky Sapphire, blue, 20 spellpenet
	[40012] = {r = 13, [101] = true, [132] = true, [12] = true, [64] = true},	-- Brilliant Scarlet Ruby, red, 16 int
	[40013] = {r = 13, [101] = true, [133] = true, [13] = true, [72] = true},	-- Smooth Autumn's Glow, yellow, 16 crit
	[40014] = {r = 13, [101] = true, [131] = true, [11] = true, [71] = true},	-- Rigid Sky Sapphire, blue, 16 hit
	[40015] = {r = 13, [101] = true, [133] = true, [13] = true, [74] = true},	-- Subtle Autumn's Glow, yellow, 16 dodge
	[40016] = {r = 13, [101] = true, [133] = true, [13] = true, [66] = true},	-- Mystic Autumn's Glow, yellow, 16 res
	[40017] = {r = 13, [101] = true, [133] = true, [13] = true, [70] = true},	-- Quick Autumn's Glow, yellow, 16 haste
	[40022] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Twilight Opal, red, blue, 8 str, 12 stam
	[40023] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Twilight Opal, red, blue, 8 agi, 12 stam
	[40024] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Twilight Opal, red, blue, 8 agi, 8 hit
	[40025] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Twilight Opal, red, blue, 8 int, 12 stam
	[40026] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Twilight Opal, red, blue, 8 int, 8 spi
	[40027] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Twilight Opal, red, blue, 8 int, 8 spi
	[40028] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Twilight Opal, red, blue, 8 int, 10 spellpenet
	[40029] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Twilight Opal, red, blue, 8 agil, 12 stam
	[40030] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Twilight Opal, red, blue, 8 agil, 8 hit
	[40031] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Forest Emerald, yellow, blue, 8 dodge, 12 stam
	[40032] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Twilight Opal, red, blue, 8 parry, 12 stam
	[40033] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Forest Emerald, yellow, blue, 8 crit, 12 stam
	[40034] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian's Twilight Opal, red, blue, 8 expert, 12 stam
	[40037] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [61] = true, [72] = true},	-- Inscribed Monarch Topaz, yellow, red, 8 str, 8 crit
	[40038] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Twilight Opal, red, blue, 8 str, 8 hit
	[40039] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [61] = true, [74] = true},	-- Champion's Monarch Topaz, yellow, red, 8 str, 8 dodge
	[40040] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [61] = true, [66] = true},	-- Resplendent Monarch Topaz, yellow, red, 8 str, 8 res
	[40041] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [61] = true, [70] = true},	-- Fierce Monarch Topaz, yellow, red, 8 str, 8 haste
	[40043] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [62] = true, [72] = true},	-- Deadly Monarch Topaz, yellow, red, 8 agi, 8 crit
	[40044] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Twilight Opal, red, blue, 8 agi, 8 hit
	[40045] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [62] = true, [66] = true},	-- Lucent Monarch Topaz, yellow, red, 8 agi, 8 res
	[40046] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [62] = true, [70] = true},	-- Deft Monarch Topaz, yellow, red, 8 agi, 8 haste
	[40047] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [64] = true, [70] = true},	-- Reckless Monarch Topaz, yellow, red, 8 int, 8 haste
	[40048] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [64] = true, [72] = true},	-- Potent Monarch Topaz, yellow, red, 8 int, 8 crit
	[40049] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Twilight Opal, red, blue, 8 int, 8 hit
	[40050] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [64] = true, [66] = true},	-- Willful Monarch Topaz, yellow, red, 8 int, 8 res
	[40051] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [64] = true, [70] = true},	-- Reckless Monarch Topaz, yellow, red, 8 int, 8 haste
	[40052] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [62] = true, [72] = true},	-- Deadly Monarch Topaz, yellow, red, 8 agil, 8 crit
	[40053] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Twilight Opal, red, blue, 8 agil, 8 hit
	[40054] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [62] = true, [66] = true},	-- Lucent Monarch Topaz, yellow, red, 8 agil, 8 res
	[40055] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [62] = true, [70] = true},	-- Deft Monarch Topaz, yellow, red, 8 agil, 8 haste
	[40056] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [74] = true, [76] = true},	-- Stalwart Monarch Topaz, yellow, red, 8 dodge, 8 parry
	[40057] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [76] = true, [74] = true},	-- Stalwart Monarch Topaz, yellow, red, 8 parry, 8 dodge
	[40058] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Twilight Opal, red, blue, 8 expert, 8 hit
	[40059] = {r = 13, [101] = true, [135] = true, [13] = true, [12] = true, [84] = true, [74] = true},	-- Resolute Monarch Topaz, yellow, red, 8 expert, 8 dodge
	[40085] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Twilight Opal, red, blue, 8 int, 12 stam
	[40086] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Forest Emerald, yellow, blue, 8 crit, 12 stam
	[40088] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [71] = true, [63] = true},	-- Nimble Forest Emerald, yellow, blue, 8 hit, 8 dodge
	[40089] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Forest Emerald, yellow, blue, 8 dodge, 12 stam
	[40090] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Forest Emerald, yellow, blue, 8 res, 12 stam
	[40091] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Forest Emerald, yellow, blue, 8 haste, 12 stam
	[40092] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Twilight Opal, red, blue, 8 int, 8 spi
	[40094] = {r = 13, [101] = true, [136] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Twilight Opal, red, blue, 8 int, 8 spi
	[40095] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Forest Emerald, yellow, blue, 8 crit, 8 spi
	[40096] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Forest Emerald, yellow, blue, 8 crit, 8 spi
	[40098] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Forest Emerald, yellow, blue, 8 crit, 10 spellpenet
	[40099] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Forest Emerald, yellow, blue, 8 hit, 8 haste
	[40100] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Forest Emerald, yellow, blue, 8 hit, 8 haste
	[40101] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [71] = true, [82] = true},	-- Radiant Forest Emerald, yellow, blue, 8 hit, 10 spellpenet
	[40102] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Turbid Forest Emerald, yellow, blue, 8 res, 8 spi
	[40103] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [65] = true, [66] = true},	-- Turbid Forest Emerald, yellow, blue, 8 spi, 8 resil
	[40104] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Forest Emerald, yellow, blue, 8 haste, 8 spi
	[40105] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Forest Emerald, yellow, blue, 8 haste, 8 spi
	[40106] = {r = 13, [101] = true, [134] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Shattered Forest Emerald, yellow, blue, 8 haste, 10 spellpenet
	[40111] = {r = 15, [101] = true, [152] = true, [12] = true, [61] = true},	-- Bold Cardinal Ruby, red, 20 str
	[40112] = {r = 15, [101] = true, [152] = true, [12] = true, [62] = true},	-- Delicate Cardinal Ruby, red, 20 agi
	[40113] = {r = 15, [101] = true, [152] = true, [12] = true, [64] = true},	-- Brilliant Cardinal Ruby, red, 20 int
	[40114] = {r = 15, [101] = true, [152] = true, [12] = true, [62] = true},	-- Delicate Cardinal Ruby, red, 20 agi
	[40115] = {r = 15, [101] = true, [153] = true, [13] = true, [74] = true},	-- Subtle King's Amber, red, 20 dodge
	[40116] = {r = 15, [101] = true, [152] = true, [12] = true, [76] = true},	-- Flashing Cardinal Ruby, red, 20 parry
	[40117] = {r = 15, [101] = true, [153] = true, [13] = true, [72] = true},	-- Smooth King's Amber, yellow, 20 crit
	[40118] = {r = 15, [101] = true, [152] = true, [12] = true, [84] = true},	-- Precise Cardinal Ruby, red, 20 expert
	[40119] = {r = 15, [101] = true, [151] = true, [11] = true, [63] = true},	-- Solid Majestic Zircon, blue, 30 stam
	[40120] = {r = 15, [101] = true, [151] = true, [11] = true, [65] = true},	-- Sparkling Majestic Zircon, blue, 20 spi
	[40121] = {r = 15, [101] = true, [151] = true, [11] = true, [65] = true},	-- Sparkling Majestic Zircon, blue, 20 spi
	[40122] = {r = 15, [101] = true, [151] = true, [11] = true, [82] = true},	-- Stormy Majestic Zircon, blue, 25 spellpenet
	[40123] = {r = 15, [101] = true, [152] = true, [12] = true, [64] = true},	-- Brilliant Cardinal Ruby, red, 20 int
	[40124] = {r = 15, [101] = true, [153] = true, [13] = true, [72] = true},	-- Smooth King's Amber, yellow, 20 crit
	[40125] = {r = 15, [101] = true, [151] = true, [11] = true, [71] = true},	-- Rigid Majestic Zircon, blue, 20 hit
	[40126] = {r = 15, [101] = true, [153] = true, [13] = true, [74] = true},	-- Subtle King's Amber, yellow, 20 dodge
	[40127] = {r = 15, [101] = true, [153] = true, [13] = true, [66] = true},	-- Mystic King's Amber, yellow, 20 res
	[40128] = {r = 15, [101] = true, [153] = true, [13] = true, [70] = true},	-- Quick King's Amber, yellow, 20 haste
	[40129] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Dreadstone, red, blue, 10 str, 15 stam
	[40130] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Dreadstone, red, blue, 10 agi, 15 stam
	[40131] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Dreadstone, red, blue, 10 agi, 10 hit
	[40132] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Dreadstone, red, blue, 10 int, 15 stam
	[40133] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Dreadstone, red, blue, 10 int, 10 spi
	[40134] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Dreadstone, red, blue, 10 int, 10 spi
	[40135] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Dreadstone, red, blue, 10 int, 13 spellpenet
	[40136] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Dreadstone, red, blue, 10 agil, 15 stam
	[40137] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Dreadstone, red, blue, 10 agil, 10 hit
	[40138] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Eye of Zul, yellow, blue, 10 dodge, 15 stam
	[40139] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Dreadstone, red, blue, 10 parry, 15 stam
	[40140] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Eye of Zul, yellow, blue, 10 crit, 15 stam
	[40141] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian's Dreadstone, red, blue, 10 expert, 15 stam
	[40142] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Ametrine, red, yellow, 10 str, 10 crit
	[40143] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Dreadstone, red, blue, 10 str, 10 hit
	[40144] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [61] = true, [74] = true},	-- Champion's Ametrine, red, yellow, 10 str, 10 dodge
	[40145] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [61] = true, [66] = true},	-- Resplendent Ametrine, red, yellow, 10 str, 10 res
	[40146] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [61] = true, [70] = true},	-- Fierce Ametrine, red, yellow, 10 str, 10 haste
	[40147] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Ametrine, red, yellow, 10 agi, 10 crit
	[40148] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Dreadstone, red, blue, 10 agi, 10 hit
	[40149] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Ametrine, red, yellow, 10 agi, 10 res
	[40150] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Ametrine, red, yellow, 10 agi, 10 haste
	[40151] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Dreadstone, red, blue, 10 int, 10 spi
	[40152] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Ametrine, red, yellow, 10 int, 10 crit
	[40153] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Dreadstone, red, blue, 10 int, 10 hit
	[40154] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Ametrine, red, yellow, 10 int, 10 res
	[40155] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Ametrine, red, yellow, 10 int, 10 haste
	[40156] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Ametrine, red, yellow, 10 agil, 10 crit
	[40157] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Dreadstone, red, blue, 10 agil, 10 hit
	[40158] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Ametrine, red, yellow, 10 agil, 10 res
	[40159] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Ametrine, red, yellow, 10 agil, 10 haste
	[40160] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [74] = true, [76] = true},	-- Stalwart Ametrine, red, yellow, 10 dodge, 10 parry
	[40161] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Ametrine, red, yellow, 10 parry, 10 dodge
	[40162] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Dreadstone, red, blue, 10 expert, 10 hit
	[40163] = {r = 15, [101] = true, [155] = true, [12] = true, [13] = true, [84] = true, [74] = true},	-- Resolute Ametrine, red, yellow, 10 expert, 10 dodge
	[40164] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Dreadstone, red, blue, 10 int, 15 stam
	[40165] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Eye of Zul, yellow, blue, 10 crit, 15 stam
	[40166] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Nimble Eye of Zul, yellow, blue, 10 hit, 10 dodge
	[40167] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Eye of Zul, yellow, blue, 10 dodge, 15 stam
	[40168] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Eye of Zul, yellow, blue, 10 res, 15 stam
	[40169] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Eye of Zul, yellow, blue, 10 haste, 15 stam
	[40170] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Dreadstone, red, blue, 10 int, 10 spi
	[40171] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Eye of Zul, yellow, blue, 10 crit, 10 spi
	[40172] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Eye of Zul, yellow, blue, 10 hit, 10 haste
	[40173] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Turbid Eye of Zul, yellow, blue, 10 res, 10 spi
	[40174] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Eye of Zul, yellow, blue, 10 haste, 10 spi
	[40175] = {r = 15, [101] = true, [156] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Dreadstone, red, blue, 10 int, 10 spi
	[40176] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Misty Eye of Zul, yellow, blue, 10 crit, 10 spi
	[40177] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Lightning Eye of Zul, yellow, blue, 10 hit, 10 haste
	[40178] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Turbid Eye of Zul, yellow, blue, 10 res, 10 spi
	[40179] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Eye of Zul, yellow, blue, 10 haste, 10 spi
	[40180] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Eye of Zul, yellow, blue, 10 crit, 13 spellpenet
	[40181] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Eye of Zul, yellow, blue, 10 crit, 13 spellpenet
	[40182] = {r = 15, [101] = true, [154] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Shattered Eye of Zul, yellow, blue, 10 haste, 13 spellpenet
	[41285] = {r = 14, [101] = true, [141] = true, [14] = true, [72] = true},	-- Chaotic Skyflare Diamond, meta, 21 crit, +3% crit damage
	[41307] = {r = 14, [101] = true, [141] = true, [14] = true, [72] = true},	-- Destructive Skyflare Diamond, meta, 25 crit, 1% spellreflect
	[41333] = {r = 14, [101] = true, [141] = true, [14] = true, [64] = true},	-- Ember Skyflare Diamond, meta, 21 int, +2% max mana
	[41335] = {r = 14, [101] = true, [141] = true, [14] = true, [72] = true},	-- Enigmatic Skyflare Diamond, meta, 21 crit, reduces snare/root duration by 10%
	[41339] = {r = 14, [101] = true, [141] = true, [14] = true, [72] = true},	-- Swift Skyflare Diamond, meta, 21 crit, minor run speed increase
	[41375] = {r = 14, [101] = true, [141] = true, [14] = true, [64] = true},	-- Tireless Skyflare Diamond, meta, 21 int, minor run speed increase
	[41376] = {r = 14, [101] = true, [141] = true, [14] = true, [65] = true},	-- Revitalizing Skyflare Diamond, meta, 22 spi, 3% increased crit healing effect
	[41377] = {r = 14, [101] = true, [141] = true, [14] = true, [63] = true},	-- Shielded Skyflare Diamond, meta, 32 stam, reduce spell damage taken by 2%
	[41378] = {r = 14, [101] = true, [141] = true, [14] = true, [64] = true},	-- Forlorn Skyflare Diamond, meta, 21 int, silence duration reduced by 10%
	[41379] = {r = 14, [101] = true, [141] = true, [14] = true, [72] = true},	-- Impassive Skyflare Diamond, meta, 21 crit, fear duration reduced by 10%
	[41380] = {r = 14, [101] = true, [142] = true, [14] = true, [63] = true},	-- Austere Earthsiege Diamond, meta, 32 stam, +2% armor value from items
	[41381] = {r = 14, [101] = true, [142] = true, [14] = true, [72] = true},	-- Persistent Earthsiege Diamond, meta, 21 crit, stun duration reduced by 10%
	[41382] = {r = 14, [101] = true, [142] = true, [14] = true, [64] = true},	-- Trenchant Earthsiege Diamond, meta, 21 int, stun duration reduced by 10%
	[41385] = {r = 14, [101] = true, [142] = true, [14] = true, [70] = true},	-- Invigorating Earthsiege Diamond, meta, 21 haste, sometimes heal on your crits
	[41389] = {r = 14, [101] = true, [142] = true, [14] = true, [72] = true},	-- Beaming Earthsiege Diamond, meta, 21 crit, +2% mana
	[41395] = {r = 14, [101] = true, [142] = true, [14] = true, [64] = true},	-- Bracing Earthsiege Diamond, meta, 21 int, 2% reduced threat
	[41396] = {r = 14, [101] = true, [142] = true, [14] = true, [74] = true},	-- Eternal Earthsiege Diamond, meta, 21 dodge, +5% shield block value
	[41397] = {r = 14, [101] = true, [142] = true, [14] = true, [63] = true},	-- Powerful Earthsiege Diamond, meta, 32 stam, stun duration reduced by 10%
	[41398] = {r = 14, [101] = true, [142] = true, [14] = true, [62] = true},	-- Relentless Earthsiege Diamond, meta, 21 agi, +3% crit damage
	[41400] = {r = 14, [101] = true, [141] = true, [14] = true, [0] = true},	-- Thundering Skyflare Diamond, meta, chance to increase melee/ranged attack speed
	[41401]	= {r = 14, [101] = true, [142] = true, [14] = true, [64] = true},	-- Insightful Earthsiege Diamond, meta, 21 int, chance to restore mana on spellcast
	[41429] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [62] = true, [72] = true},	-- Perfect Deadly Huge Citrine, yellow, red, 7 agil, 7 crit
	[41432] = {r = 12, [101] = true, [122] = true, [12] = true, [61] = true},	-- Perfect Bold Bloodstone, red, 14 str
	[41433] = {r = 12, [101] = true, [122] = true, [12] = true, [62] = true},	-- Perfect Delicate Bloodstone, red, 14 agi
	[41434] = {r = 12, [101] = true, [122] = true, [12] = true, [62] = true},	-- Perfect Delicate Bloodstone, red, 14 agi
	[41435] = {r = 12, [101] = true, [122] = true, [12] = true, [76] = true},	-- Perfect Flashing Bloodstone, red, 14 parry
	[41436] = {r = 12, [101] = true, [123] = true, [13] = true, [72] = true},	-- Perfect Smooth Sun Crystal, yellow, 14 crit
	[41437] = {r = 12, [101] = true, [122] = true, [12] = true, [84] = true},	-- Perfect Precise Bloodstone, red, 14 expert
	[41438] = {r = 12, [101] = true, [122] = true, [12] = true, [64] = true},	-- Perfect Brilliant Bloodstone, red, 14 int
	[41439] = {r = 12, [101] = true, [123] = true, [13] = true, [74] = true},	-- Perfect Subtle Sun Crystal, yellow, 14 dodge
	[41440] = {r = 12, [101] = true, [121] = true, [11] = true, [65] = true},	-- Perfect Sparkling Chalcedony, blue, 14 spi
	[41441] = {r = 12, [101] = true, [121] = true, [11] = true, [63] = true},	-- Perfect Solid Chalcedony, blue, 21 stam
	[41442] = {r = 12, [101] = true, [121] = true, [11] = true, [65] = true},	-- Perfect Sparkling Chalcedony, blue, 14 spi
	[41443] = {r = 12, [101] = true, [121] = true, [11] = true, [82] = true},	-- Perfect Stormy Chalcedony, blue, 18 spellpenet
	[41444] = {r = 12, [101] = true, [122] = true, [12] = true, [64] = true},	-- Perfect Brilliant Bloodstone, red, 14 int
	[41445] = {r = 12, [101] = true, [123] = true, [13] = true, [66] = true},	-- Perfect Mystic Sun Crystal, yellow, 14 res
	[41446] = {r = 12, [101] = true, [123] = true, [13] = true, [70] = true},	-- Perfect Quick Sun Crystal, yellow, 14 haste
	[41447] = {r = 12, [101] = true, [121] = true, [11] = true, [71] = true},	-- Perfect Rigid Chalcedony, blue, 14 hit
	[41448] = {r = 12, [101] = true, [123] = true, [13] = true, [72] = true},	-- Perfect Smooth Sun Crystal, yellow, 14 crit
	[41449] = {r = 12, [101] = true, [123] = true, [13] = true, [74] = true},	-- Perfect Subtle Sun Crystal, yellow, 14 dodge
	[41450] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Perfect Shifting Shadow Crystal, red, blue, 7 agil, 10 stam
	[41451] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Perfect Defender's Shadow Crystal, red, blue, 7 parry, 10 stam
	[41452] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Perfect Timeless Shadow Crystal, red, blue, 7 int, 10 stam
	[41453] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Perfect Guardian's Shadow Crystal, red, blue, 7 expert, 10 stam
	[41454] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Perfect Glinting Shadow Crystal, red, blue, 7 agil, 7 hit
	[41455] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Perfect Mysterious Shadow Crystal, red, blue, 7 int, 9 spellpenet
	[41456] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Perfect Jagged Dark Jade, yellow, blue, 7 crit, 10 stam
	[41457] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Perfect Purified Shadow Crystal, red, blue, 7 int, 7 spi
	[41458] = {r = 12, [101] = true, [126] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Perfect Regal Dark Jade, yellow, blue, 7 dodge, 10 stam
	[41459] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Perfect Purified Shadow Crystal, red, blue, 7 int, 7 spi
	[41460] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Perfect Shifting Shadow Crystal, red, blue, 7 agi, 10 stam
	[41461] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Perfect Sovereign Shadow Crystal, red, blue, 7 str, 10 stam
	[41462] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Perfect Glinting Shadow Crystal, red, blue, 7 agi, 7 hit
	[41463] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Perfect Purified Shadow Crystal, red, blue, 7 int, 7 spi
	[41464] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Perfect Regal Dark Jade, yellow, blue, 7 dodge, 11 stam
	[41465] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Perfect Energized Dark Jade, yellow, blue, 7 haste, 7 spi
	[41466] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Perfect Forceful Dark Jade, yellow, blue, 7 haste, 10 stam
	[41467] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Perfect Energized Dark Jade, yellow, blue, 7 haste, 7 spi
	[41468] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Perfect Jagged Dark Jade, yellow, blue, 7 crit, 10 stam
	[41469] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Perfect Lightning Dark Jade, yellow, blue, 7 hit, 7 haste
	[41470] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Perfect Misty Dark Jade, yellow, blue, 7 crit, 7 spi
	[41471] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Perfect Turbid Dark Jade, yellow, blue, 7 res, 7 spi
	[41472] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Perfect Radiant Dark Jade, yellow, blue, 7 crit, 9 spellpenet
	[41473] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Perfect Purified Shadow Crystal, red, blue, 7 int, 7 spi
	[41474] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Perfect Shattered Dark Jade, yellow, blue, 7 haste, 9 spellpenet
	[41475] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [71] = true, [70] = true},	-- Perfect Lightning Dark Jade, yellow, blue, 7 hit, 7 haste
	[41476] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Perfect Steady Dark Jade, yellow, blue, 7 res, 10 stam
	[41477] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [65] = true},	-- Perfect Misty Dark Jade, yellow, blue, 7 crit, 7 spi
	[41478] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Perfect Radiant Dark Jade, yellow, blue, 7 crit, 9 spellpenet
	[41479] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Perfect Timeless Shadow Crystal, red, blue, 7 int, 10 stam
	[41480] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [66] = true, [65] = true},	-- Perfect Turbid Dark Jade, yellow, blue, 7 res, 7 spi
	[41481] = {r = 12, [101] = true, [124] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Perfect Nimble Dark Jade, yellow, blue, 7 hit, 7 dodge
	[41482] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Perfect Accurate Shadow Crystal, red, blue, 7 expert, 7 hit
	[41483] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [74] = true},	-- Perfect Champion's Huge Citrine, yellow, red, 7 str, 7 dodge
	[41484] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [62] = true, [72] = true},	-- Perfect Deadly Huge Citrine, yellow, red, 7 agi, 7 crit
	[41485] = {r = 12, [101] = true, [125] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Perfect Deft Huge Citrine, red, yellow, 7 agi, 7 haste
	[41486] = {r = 12, [101] = true, [125] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Perfect Willful Huge Citrine, red, yellow, 7 int, 7 res
	[41487] = {r = 12, [101] = true, [125] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Perfect Lucent Huge Citrine, red, yellow, 7 agil, 7 res
	[41488] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Perfect Etched Shadow Crystal, red, blue, 7 str, 7 hit
	[41489] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [70] = true},	-- Perfect Fierce Huge Citrine, yellow, red, 7 str, 7 haste
	[41490] = {r = 12, [101] = true, [125] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Perfect Stalwart Huge Citrine, red, yellow, 7 parry, 7 dodge
	[41491] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Perfect Glinting Shadow Crystal, red, blue 7 agi, 7 hit
	[41492] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [72] = true},	-- Perfect Inscribed Huge Citrine, yellow, red, 7 str, 7 crit
	[41493] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [62] = true, [66] = true},	-- Perfect Lucent Huge Citrine, yellow, red, 7 agi, 7 res
	[41494] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Perfect Purified Shadow Crystal, red, blue, 7 int, 7 spi
	[41495] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [64] = true, [72] = true},	-- Perfect Potent Huge Citrine, yellow, red, 7 int, 7 crit
	[41496] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Perfect Glinting Shadow Crystal, red, blue, 7 agil, 7 hit
	[41497] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [64] = true, [70] = true},	-- Perfect Reckless Huge Citrine, yellow, red, 7 int, 7 haste
	[41498] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [84] = true, [74] = true},	-- Perfect Resolute Huge Citrine, yellow, red, 7 expert, 7 dodge
	[41499] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [61] = true, [66] = true},	-- Perfect Resplendent Huge Citrine, yellow, red, 7 str, 7 res
	[41500] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [74] = true, [76] = true},	-- Perfect Stalwart Huge Citrine, yellow, red, 7 dodge, 7 parry
	[41501] = {r = 12, [101] = true, [125] = true, [13] = true, [12] = true, [62] = true, [70] = true},	-- Perfect Deft Huge Citrine, yellow, red, 7 agil, 7 haste
	[41502] = {r = 12, [101] = true, [126] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Perfect Veiled Shadow Crystal, red, blue, 7 int, 7 hit
	[42142] = {r = 16, [101] = true, [143] = true, [12] = true, [61] = true, [1013] = true},	-- Bold Dragon's Eye, red, 34 str
	[42143] = {r = 16, [101] = true, [143] = true, [12] = true, [62] = true, [1013] = true},	-- Delicate Dragon's Eye, red, 34 agi
	[42144] = {r = 16, [101] = true, [143] = true, [12] = true, [64] = true, [1013] = true},	-- Brilliant Dragon's Eye, red, 34 int
	[42145] = {r = 16, [101] = true, [143] = true, [11] = true, [65] = true, [1013] = true},	-- Sparkling Dragon's Eye, blue, 34 spi
	[42146] = {r = 16, [101] = true, [143] = true, [11] = true, [65] = true, [1013] = true},	-- Sparkling Dragon's Eye, blue, 34 spi
	[42148] = {r = 16, [101] = true, [143] = true, [12] = true, [64] = true, [1013] = true},	-- Brilliant Dragon's Eye, red, 34 int
	[42149] = {r = 16, [101] = true, [143] = true, [13] = true, [72] = true, [1013] = true},	-- Smooth Dragon's Eye, yellow, 34 crit
	[42150] = {r = 16, [101] = true, [143] = true, [13] = true, [70] = true, [1013] = true},	-- Quick Dragon's Eye, yellow, 34 haste
	[42151] = {r = 16, [101] = true, [143] = true, [13] = true, [74] = true, [1013] = true},	-- Subtle Dragon's Eye, yellow, 34 dodge
	[42152] = {r = 16, [101] = true, [143] = true, [12] = true, [76] = true, [1013] = true},	-- Flashing Dragon's Eye, red, 34 parry
	[42153] = {r = 16, [101] = true, [143] = true, [13] = true, [72] = true, [1013] = true},	-- Smooth Dragon's Eye, yellow, 34 crit
	[42154] = {r = 16, [101] = true, [143] = true, [12] = true, [84] = true, [1013] = true},	-- Precise Dragon's Eye, red, 34 expert
	[42155] = {r = 16, [101] = true, [143] = true, [11] = true, [82] = true, [1013] = true},	-- Stormy Dragon's Eye, blue, 43 spellpenet
	[42156] = {r = 16, [101] = true, [143] = true, [11] = true, [71] = true, [1013] = true},	-- Rigid Dragon's Eye, blue, 34 hit
	[42157] = {r = 16, [101] = true, [143] = true, [13] = true, [74] = true, [1013] = true},	-- Subtle Dragon's Eye, yellow, 34 dodge
	[42158] = {r = 16, [101] = true, [143] = true, [13] = true, [66] = true, [1013] = true},	-- Mystic Dragon's Eye, yellow, 34 res
	[42701] = {r = 11, [101] = true, [127] = true, [12] = true, [13] = true, [11] = true, [61] = true, [62] = true, [63] = true, [64] = true, [65] = true},	-- Enchanted Pearl, red, yellow, blue, 4 stats
	[42702] = {r = 13, [101] = true, [137] = true, [12] = true, [13] = true, [11] = true, [61] = true, [62] = true, [63] = true, [64] = true, [65] = true},	-- Enchanted Tear, red, yellow, blue, 6 stats
	[44066] = {r = 15, [103] = true, [13] = true, [66] = true},	-- Kharmaa's Grace, yellow, 20 res
	[44076] = {r = 14, [103] = true, [14] = true, [72] = true},	-- Swift Starflare Diamond, meta, 17 crit, minor run speed increase
	[44078] = {r = 14, [103] = true, [14] = true, [64] = true},	-- Tireless Starflare Diamond, meta, 17 int, minor run speed increase
	[44081] = {r = 14, [103] = true, [14] = true, [72] = true},	-- Enigmatic Starflare Diamond, meta, 17 crit, reduces snare/root duration by 10%
	[44082] = {r = 14, [103] = true, [14] = true, [72] = true},	-- Impassive Starflare Diamond, meta, 17 crit, fear duration reduced by 10%
	[44084] = {r = 14, [103] = true, [14] = true, [64] = true},	-- Forlorn Starflare Diamond, meta, 17 int, silence duration reduced by 10%
	[44087] = {r = 14, [103] = true, [14] = true, [72] = true},	-- Persistent Earthshatter Diamond, meta, 17 crit, stun duration reduced by 10%
	[44088] = {r = 14, [103] = true, [14] = true, [63] = true},	-- Powerful Earthshatter Diamond, meta, 26 stam, stun duration reduced by 10%
	[44089] = {r = 14, [103] = true, [14] = true, [64] = true},	-- Trenchant Earthshatter Diamond, meta, 17 int, stun duration reduced by 10%
	[45862] = {r = 15, [104] = true, [12] = true, [61] = true},	-- Bold Stormjewel, red, 20 str
	[45879] = {r = 15, [104] = true, [12] = true, [62] = true},	-- Delicate Stormjewel, red, 20 agi
	[45880] = {r = 15, [104] = true, [11] = true, [63] = true},	-- Solid Stormjewel, blue, 30 stam
	[45881] = {r = 15, [104] = true, [11] = true, [65] = true},	-- Sparkling Stormjewel, blue, 20 spi
	[45882] = {r = 15, [104] = true, [12] = true, [64] = true},	-- Brilliant Stormjewel, red, 20 int
--	[45883] = {r = 15, [104] = true, [12] = true, [64] = true},	-- Brilliant Stormjewel, red, 20 int  -- duplicate
	[45987] = {r = 15, [104] = true, [11] = true, [71] = true},	-- Rigid Stormjewel, blue, 20 hit
	[49110] = {r = 15, [101] = true, [143] = true, [11] = true, [12] = true, [13] = true, [61] = true, [62] = true, [63] = true, [64] = true, [65] = true},	-- Nightmare Tear, red, yellow, blue, 10 stats
	[52081] = {r = 21, [101] = true, [162] = true, [12] = true, [61] = true}, -- Bold Carnelian, red, 30 str
	[52082] = {r = 21, [101] = true, [162] = true, [12] = true, [62] = true}, -- Delicate Carnelian, red, 30 agil
	[52083] = {r = 21, [101] = true, [162] = true, [12] = true, [76] = true}, -- Flashing Carnelian, red, 30 parry
	[52084] = {r = 21, [101] = true, [162] = true, [12] = true, [64] = true}, -- Brilliant Carnelian, red, 30 int
	[52085] = {r = 22, [101] = true, [162] = true, [12] = true, [84] = true}, -- Precise Carnelian, red, 30 expert
	[52086] = {r = 21, [101] = true, [161] = true, [11] = true, [63] = true}, -- Solid Zephyrite, blue, 45 sta
	[52087] = {r = 21, [101] = true, [161] = true, [11] = true, [65] = true}, -- Sparkling Zephyrite, blue, 30 spi
	[52088] = {r = 21, [101] = true, [161] = true, [11] = true, [82] = true}, -- Stormy Zephyrite, blue, 38 spellpen
	[52089] = {r = 21, [101] = true, [161] = true, [11] = true, [71] = true}, -- Rigid Zephyrite, blue, 30 hit
	[52090] = {r = 21, [101] = true, [163] = true, [13] = true, [74] = true}, -- Subtle Alicite, yellow, 30 dodge
	[52091] = {r = 21, [101] = true, [163] = true, [13] = true, [72] = true}, -- Smooth Alicite, yellow, 30 crit
	[52092] = {r = 21, [101] = true, [163] = true, [13] = true, [66] = true}, -- Mystic Alicite, yellow, 30 resil
	[52093] = {r = 21, [101] = true, [163] = true, [13] = true, [70] = true}, -- Quick Alicite, yellow, 30 haste
	[52094] = {r = 21, [101] = true, [163] = true, [13] = true, [85] = true}, -- Fractured Alicite, yellow, 30 mastery
	[52095] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [61] = true, [63] = true}, -- Sovereign Nightstone, red, blue, 15 str, 23 stam
	[52096] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [62] = true, [63] = true}, -- Shifting Nightstone, red, blue, 15 agil, 23 stam
	[52097] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [76] = true, [63] = true}, -- Defender's Nightstone, red, blue, 15 parry, 23 stam
	[52098] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [64] = true, [63] = true}, -- Timeless Nightstone, red, blue, 15 int, 23 stam
	[52099] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [84] = true, [63] = true}, -- Guardian's Nightstone, red, blue, 15 expert, 23 stam
	[52100] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [64] = true, [65] = true}, -- Purified Nightstone, red, blue, 15 int, 15 spi
	[52101] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [61] = true, [71] = true}, -- Etched Nightstone, red, blue, 15 str, 15 hit
	[52102] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [62] = true, [71] = true}, -- Glinting Nightstone, red, blue, 15 agil, 15 hit
	[52103] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [76] = true, [71] = true}, -- Retaliating Nightstone, red, blue, 15 parry, 15 hit
	[52104] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [64] = true, [71] = true}, -- Veiled Nightstone, red, blue, 15 int, 15 hit
	[52105] = {r = 21, [101] = true, [166] = true, [12] = true, [11] = true, [84] = true, [71] = true}, -- Accurate Nightstone, red, blue, 15 expert, 15 hit
	[52106] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [74] = true}, -- Polished Hessonite, red, yellow, 15 agil, 15 dodge
	[52107] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [84] = true, [74] = true}, -- Resolute Hessonite, red, yellow, 15 expert, 15 dodge
	[52108] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [61] = true, [72] = true}, -- Inscribed Hessonite, red, yellow, 15 str, 15 crit
	[52109] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [72] = true}, -- Deadly Hessonite, red, yellow, 15 agil, 15 crit
	[52110] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [64] = true, [72] = true}, -- Potent Hessonite, red, yellow, 15 int, 15 crit
	[52111] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [61] = true, [70] = true}, -- Fierce Hessonite, red, yellow, 15 str, 15 haste
	[52112] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [70] = true}, -- Deft Hessonite, red, yellow, 15 agil, 15 haste
	[52113] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [64] = true, [70] = true}, -- Reckless Hessonite, red, yellow, 15 int, 15 haste
	[52114] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [61] = true, [85] = true}, -- Skillful Hessonite, red, yellow, 15 str, 15 mastery
	[52115] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [85] = true}, -- Adept Hessonite, red, yellow, 15 agil, 15 mastery
	[52116] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [76] = true, [85] = true}, -- Fine Hessonite, red, yellow, 15 parry, 15 mastery
	[52117] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [64] = true, [85] = true}, -- Artful Hessonite, red, yellow, 15 int, 15 mastery
	[52118] = {r = 21, [101] = true, [165] = true, [12] = true, [13] = true, [84] = true, [85] = true}, -- Keen Hessonite, red, yellow, 15 expert, 15 mastery
	[52119] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [74] = true, [63] = true}, -- Regal Jasper, blue, yellow, 15 dodge, 23 stam
	[52120] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [74] = true, [71] = true}, -- Nimble Jasper, blue, yellow, 15 dodge, 15 hit
	[52121] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [72] = true, [63] = true}, -- Jagged Jasper, blue, yellow, 15 crit, 23 sta
	[52122] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [72] = true, [71] = true}, -- Piercing Jasper, blue, yellow, 15 crit, 15 hit
	[52123] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [66] = true, [63] = true}, -- Steady Jasper, blue, yellow, 15 resil, 23 stam
	[52124] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [70] = true, [63] = true}, -- Forceful Jasper, blue, yellow, 15 haste, 23 sta
	[52125] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [70] = true, [71] = true}, -- Lightning Jasper, blue, yellow, 15 haste, 15 hit
	[52126] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [85] = true, [63] = true}, -- Puissant Jasper, blue, yellow, 15 mastery, 23 stam
	[52127] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [85] = true, [65] = true}, -- Zen Jasper, blue, yellow, 15 mastery, 15 spi
	[52128] = {r = 21, [101] = true, [164] = true, [11] = true, [13] = true, [85] = true, [71] = true}, -- Sensei's Jasper, blue, yellow, 15 mastery, 15 hit
	[52129] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [85] = true, [71] = true}, -- Perfect Sensei's Jasper, blue, yellow, 18 mastery, 17 hit
	[52130] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [85] = true, [65] = true}, -- Perfect Zen Jasper, blue, yellow, 18 mastery, 17 spi
	[52131] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [85] = true, [63] = true}, -- Perfect Puissant Jasper, blue, yellow, 18 mastery, 26 sta
	[52132] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [70] = true, [71] = true}, -- Perfect Lightning Jasper, blue, yellow, 18 haste, 17 hit
	[52133] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [70] = true, [63] = true}, -- Perfect Forceful Jasper, blue, yellow, 18 haste, 26 sta
	[52134] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [66] = true, [63] = true}, -- Perfect Steady Jasper, blue, yellow, 18 resil, 26 sta
	[52135] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [72] = true, [71] = true}, -- Perfect Piercing Jasper, blue, yellow, 18 crit, 17 hit
	[52136] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [72] = true, [63] = true}, -- Perfect Jagged Jasper, blue, yellow, 18 crit, 26 sta
	[52137] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [74] = true, [71] = true}, -- Perfect Nimble Jasper, blue, yellow, 18 dodge, 17 hit
	[52138] = {r = 22, [101] = true, [164] = true, [11] = true, [13] = true, [74] = true, [63] = true}, -- Perfect Regal Jasper, blue, yellow, 18 dodge, 26 sta
	[52139] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [84] = true, [85] = true}, -- Perfect Keen Hessonite, red, yellow, 18 expert, 17 mastery
	[52140] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [64] = true, [85] = true}, -- Perfect Artful Hessonite, red, yellow, 18 int, 17 mastery
	[52141] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [76] = true, [85] = true}, -- Perfect Fine Hessonite, red, yellow, 18 parry, 17 mastery
	[52142] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [85] = true}, -- Perfect Adept Hessonite, red, yellow, 18 agil, 17 mastery
	[52143] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [61] = true, [85] = true}, -- Perfect Skillful Hessonite, red, yellow, 18 str, 17 mastery
	[52144] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [64] = true, [70] = true}, -- Perfect Reckless Hessonite, red, yellow, 18 int, 17 haste
	[52145] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [70] = true}, -- Perfect Deft Hessonite, red, yellow, 18 agil, 17 haste
	[52146] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [61] = true, [70] = true}, -- Perfect Fierce Hessonite, red, yellow, 18 str, 17 haste
	[52147] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [64] = true, [72] = true}, -- Perfect Potent Hessonite, red, yellow, 18 int, 17 crit
	[52148] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [72] = true}, -- Perfect Deadly Hessonite, red, yellow, 18 agil, 17 crit
	[52149] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [61] = true, [72] = true}, -- Perfect Inscribed Hessonite, red, yellow, 18 str, 17 crit
	[52150] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [84] = true, [74] = true}, -- Perfect Resolute Hessonite, red, yellow, 18 expert, 17 dodge
	[52151] = {r = 22, [101] = true, [165] = true, [12] = true, [13] = true, [62] = true, [74] = true}, -- Perfect Polished Hessonite, red, yellow, 18 agil, 17 dodge
	[52152] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [84] = true, [71] = true}, -- Perfect Accurate Nightstone, red, blue, 18 expert, 17 hit
	[52153] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [64] = true, [71] = true}, -- Perfect Veiled Nightstone, red, blue, 18 int, 17 hit
	[52154] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [76] = true, [71] = true}, -- Perfect Retaliating Nightstone, red, blue, 18 parry, 17 hit
	[52155] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [62] = true, [71] = true}, -- Perfect Glinting Nightstone, red, blue, 18 agil, 17 hit
	[52156] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [61] = true, [71] = true}, -- Perfect Etched Nightstone, red, blue, 18 str, 17 hit
	[52157] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [64] = true, [65] = true}, -- Perfect Purified Nightstone, red, blue, 18 int, 17 spi
	[52158] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [84] = true, [63] = true}, -- Perfect Guardian's Nightstone, red, blue, 18 expert, 26 stam
	[52159] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [64] = true, [63] = true}, -- Perfect Timeless Nightstone, red, blue, 18 int, 26 stam
	[52160] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [76] = true, [63] = true}, -- Perfect Defender's Nightstone, red, blue, 18 parry, 26 stam
	[52161] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [62] = true, [63] = true}, -- Perfect Shifting Nightstone, red, blue, 18 agil, 23 stam
	[52162] = {r = 22, [101] = true, [166] = true, [12] = true, [11] = true, [61] = true, [63] = true}, -- Perfect Sovereign Nightstone, red, blue, 18 str, 26 stam
	[52163] = {r = 22, [101] = true, [163] = true, [13] = true, [85] = true}, -- Perfect Fractured Alicite, yellow, 35 mastery
	[52164] = {r = 22, [101] = true, [163] = true, [13] = true, [70] = true}, -- Perfect Quick Alicite, yellow, 35 haste
	[52165] = {r = 22, [101] = true, [163] = true, [13] = true, [66] = true}, -- Perfect Mystic Alicite, yellow, 35 resil
	[52166] = {r = 22, [101] = true, [163] = true, [13] = true, [72] = true}, -- Perfect Smooth Alicite, yellow, 35 crit
	[52167] = {r = 22, [101] = true, [163] = true, [13] = true, [74] = true}, -- Perfect Subtle Alicite, yellow, 35 dodge
	[52168] = {r = 22, [101] = true, [161] = true, [11] = true, [71] = true}, -- Perfect Rigid Zephyrite, blue, 35 hit
	[52169] = {r = 22, [101] = true, [161] = true, [11] = true, [82] = true}, -- Perfect Stormy Zephyrite, blue, 44 spellpen
	[52170] = {r = 22, [101] = true, [161] = true, [11] = true, [65] = true}, -- Perfect Sparkling Zephyrite, blue, 35 spi
	[52171] = {r = 22, [101] = true, [161] = true, [11] = true, [63] = true}, -- Perfect Solid Zephyrite, blue, 53 sta
	[52172] = {r = 22, [101] = true, [162] = true, [12] = true, [84] = true}, -- Perfect Precise Carnelian, red, 35 expert
	[52173] = {r = 22, [101] = true, [162] = true, [12] = true, [64] = true}, -- Perfect Brilliant Carnelian, red, 35 int
	[52174] = {r = 22, [101] = true, [162] = true, [12] = true, [76] = true}, -- Perfect Flashing Carnelian, red, 35 parry
	[52175] = {r = 22, [101] = true, [162] = true, [12] = true, [62] = true}, -- Perfect Delicate Carnelian, red, 35 agil
	[52176] = {r = 22, [101] = true, [162] = true, [12] = true, [61] = true}, -- Perfect Bold Carnelian, red, 35 str
	[52203] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Demonseye, red, blue, 20 expert, 20 hit
	[52204] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [62] = true, [85] = true},	-- Adept Ember Topaz, red, yellow, 20 agil, 20 mastery
	[52205] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [64] = true, [85] = true},	-- Artful Ember Topaz, red, yellow, 20 int, 20 mastery
	[52206] = {r = 23, [101] = true, [172] = true, [12] = true, [61] = true},	-- Bold Inferno Ruby, red, 40 str
	[52207] = {r = 23, [101] = true, [172] = true, [12] = true, [64] = true},	-- Brilliant Inferno Ruby, red, 40 int
	[52208] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Ember Topaz, red, yellow, 20 int, 20 haste
	[52209] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Ember Topaz, red, yellow, 20 agil, 20 crit
	[52210] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Demonseye, red, blue, 20 parry, 30 stam
	[52211] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Ember Topaz, red, yellow, 20 agil, 20 haste
	[52212] = {r = 23, [101] = true, [172] = true, [12] = true, [62] = true},	-- Delicate Inferno Ruby, red, 40 agil
	[52213] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Demonseye, red, blue, 20 str, 20 hit
	[52214] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [61] = true, [70] = true},	-- Fierce Ember Topaz, red, yellow, 20 str, 20 haste
	[52215] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [76] = true, [85] = true},	-- Fine Ember Topaz, red, yellow, 20 parry, 20 mastery
	[52216] = {r = 23, [101] = true, [172] = true, [12] = true, [76] = true},	-- Flashing Inferno Ruby, red, 40 parry
	[52217] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Demonseye, red, blue, 20 int, 20 hit
	[52218] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [70] = true, [63] = true},	-- Forceful Dream Emerald, blue, yellow, 20 haste, 30 stam
	[52219] = {r = 23, [101] = true, [173] = true, [13] = true, [85] = true},	-- Fractured Amberjewel, yellow, 40 mastery
	[52220] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Demonseye, red, blue, 20 agil, 20 hit
	[52221] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian's Demonseye, red, blue, 20 expert, 30 stam
	[52222] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Ember Topaz, red, yellow, 20 str, 20 crit
	[52223] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [72] = true, [63] = true},	-- Jagged Dream Emerald, blue, yellow, 20 crit, 30 stam
	[52224] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [84] = true, [85] = true},	-- Keen Ember Topaz, red, yellow, 20 expert, 20 mastery
	[52225] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [70] = true, [71] = true},	-- Lightning Dream Emerald, blue, yellow, 20 haste, 20 hit
	[52226] = {r = 23, [101] = true, [173] = true, [13] = true, [66] = true},	-- Mystic Amberjewel, yellow, 40 resil
	[52227] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [74] = true, [71] = true},	-- Nimble Dream Emerald, blue, yellow, 20 dodge, 20 hit
	[52228] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [72] = true, [71] = true},	-- Piercing Dream Emerald, blue, yellow, 20 crit, 20 hit
	[52229] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [62] = true, [74] = true},	-- Polished Ember Topaz, red, yellow, 20 agil, 20 dodge
	[52230] = {r = 23, [101] = true, [172] = true, [12] = true, [84] = true},	-- Precise Inferno Ruby, red, 40 expert
	[52231] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [85] = true, [63] = true},	-- Puissant Dream Emerald, blue, yellow, 20 mastery, 30 stam
	[52232] = {r = 23, [101] = true, [173] = true, [13] = true, [70] = true},	-- Quick Amberjewel, yellow, 40 haste
	[52233] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [74] = true, [63] = true},	-- Regal Dream Emerald, blue, yellow, 20 dodge, 30 stam
	[52234] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [76] = true, [71] = true},	-- Retaliating Demonseye, red, blue, 20 parry, 20 hit
	[52235] = {r = 23, [101] = true, [171] = true, [11] = true, [71] = true},	-- Rigid Ocean Sapphire, blue, 40 hit
	[52236] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Demonseye, red, blue, 20 int, 20 spi
	[52237] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [85] = true, [71] = true},	-- Sensei's Dream Emerald, blue, yellow, 20 mastery, 20 hit
	[52238] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Demonseye, red, blue, 20 agil, 30 stam
	[52239] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Ember Topaz, red, yellow, 20 int, 20 crit
	[52240] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [61] = true, [85] = true},	-- Skillful Ember Topaz, red, yellow, 20 str, 20 mastery
	[52241] = {r = 23, [101] = true, [173] = true, [13] = true, [72] = true},	-- Smooth Amberjewel, yellow, 40 crit
	[52242] = {r = 23, [101] = true, [171] = true, [11] = true, [63] = true},	-- Solid Ocean Sapphire, blue, 60 stam
	[52243] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Demonseye, red, blue, 20 str, 30 stam
	[52244] = {r = 23, [101] = true, [171] = true, [11] = true, [65] = true},	-- Sparkling Ocean Sapphire, blue, 40 spi
	[52245] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [66] = true, [63] = true},	-- Steady Dream Emerald, blue, yellow, 20 resil, 30 stam
	[52246] = {r = 23, [101] = true, [171] = true, [11] = true, [82] = true},	-- Stormy Ocean Sapphire, blue, 50 spellpen
	[52247] = {r = 23, [101] = true, [173] = true, [13] = true, [74] = true},	-- Subtle Amberjewel, yellow, 40 dodge
	[52248] = {r = 23, [101] = true, [176] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Demonseye, red, blue, 20 int, 30 stam
	[52249] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [84] = true, [74] = true},	-- Resolute Ember Topaz, red, yellow, 20 expert, 20 dodge
	[52250] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [85] = true, [65] = true},	-- Zen Dream Emerald, blue, yellow, 20 mastery, 20 spi
	[52255] = {r = 26, [101] = true, [168] = true, [12] = true, [61] = true, [1013] = true},	-- Bold Chimera's Eye, red, 67 str
--	[52256] = {r = 26, [101] = true, [168] = true, [12] = true, [1013] = true},	-- Bright Chimera's Eye, red
	[52257] = {r = 26, [101] = true, [168] = true, [12] = true, [64] = true, [1013] = true},	-- Brilliant Chimera's Eye, red, 67 int
	[52258] = {r = 26, [101] = true, [168] = true, [12] = true, [62] = true, [1013] = true},	-- Delicate Chimera's Eye, red, 67 agil
	[52259] = {r = 26, [101] = true, [168] = true, [12] = true, [76] = true, [1013] = true},	-- Flashing Chimera's Eye, red, 67 parry
	[52260] = {r = 26, [101] = true, [168] = true, [12] = true, [84] = true, [1013] = true},	-- Precise Chimera's Eye, red, 67 expert
	[52261] = {r = 26, [101] = true, [168] = true, [11] = true, [63] = true, [1013] = true},	-- Solid Chimera's Eye, blue, 101 stam
	[52262] = {r = 26, [101] = true, [168] = true, [11] = true, [65] = true, [1013] = true},	-- Sparkling Chimera's Eye, blue, 67 spi
	[52263] = {r = 26, [101] = true, [168] = true, [11] = true, [82] = true, [1013] = true},	-- Stormy Chimera's Eye, blue, 84 spellpen
	[52264] = {r = 26, [101] = true, [168] = true, [11] = true, [71] = true, [1013] = true},	-- Rigid Chimera's Eye, blue, 67 hit
	[52265] = {r = 26, [101] = true, [168] = true, [13] = true, [74] = true, [1013] = true},	-- Subtle Chimera's Eye, yellow, 67 dodge
	[52266] = {r = 26, [101] = true, [168] = true, [13] = true, [72] = true, [1013] = true},	-- Smooth Chimera's Eye, yellow, 67 crit
	[52267] = {r = 26, [101] = true, [168] = true, [13] = true, [66] = true, [1013] = true},	-- Mystic Chimera's Eye, yellow, 67 resil
	[52268] = {r = 26, [101] = true, [168] = true, [13] = true, [70] = true, [1013] = true},	-- Quick Chimera's Eye, yellow, 67 haste
	[52269] = {r = 26, [101] = true, [168] = true, [13] = true, [85] = true, [1013] = true},	-- Fractured Chimera's Eye, yellow, 67 mastery
	[52289] = {r = 24, [101] = true, [177] = true, [14] = true, [85] = true}, -- Fleet Shadowspirit Diamond, meta, 54 mastery, minor run speed increase
	[52291] = {r = 24, [101] = true, [177] = true, [14] = true, [72] = true}, -- Chaotic Shadowspirit Diamond, meta, 54 crit, 3% increased crit damage
	[52292] = {r = 24, [101] = true, [177] = true, [14] = true, [64] = true}, -- Bracing Shadowspirit Diamond, meta, 54 int, 2% reduced threat
	[52293] = {r = 24, [101] = true, [177] = true, [14] = true, [63] = true}, -- Eternal Shadowspirit Diamond, meta, 81 stam, 1% shield block value
	[52294] = {r = 24, [101] = true, [177] = true, [14] = true, [63] = true}, -- Austere Shadowspirit Diamond, meta, 81 stam, 2% increased armor value from items
	[52295] = {r = 24, [101] = true, [177] = true, [14] = true, [63] = true}, -- Effulgent Shadowspirit Diamond, meta, 81 stam, reduced spell damage taken by 2%
	[52296] = {r = 24, [101] = true, [177] = true, [14] = true, [64] = true}, -- Ember Shadowspirit Diamond, meta, 54 int, 2% max mana
	[52297] = {r = 24, [101] = true, [177] = true, [14] = true, [65] = true}, -- Revitalizing Shadowspirit Diamond, meta, 54 spi, 3% increased crit effect
	[52298] = {r = 24, [101] = true, [177] = true, [14] = true, [72] = true}, -- Destructive Shadowspirit Diamond, meta, 54 crit, 1% spell reflect
	[52299] = {r = 24, [101] = true, [177] = true, [14] = true, [63] = true}, -- Powerful Shadowspirit Diamond, meta, 81 stam, stun duration reduced by 10%
	[52300] = {r = 24, [101] = true, [177] = true, [14] = true, [72] = true}, -- Enigmatic Shadowspirit Diamond, meta, 54 crit, reduced snare / root duration by 10
	[52301] = {r = 24, [101] = true, [177] = true, [14] = true, [72] = true}, -- Impassive Shadowspirit Diamond, meta, 54 crit, fear duration reduced by 10%
	[52302] = {r = 24, [101] = true, [177] = true, [14] = true, [64] = true}, -- Forlorn Shadowspirit Diamond, meta, 54 int, silence duration reduced by 10%
	[59477] = {r = 27, [103] = true, [15] = true, [74] = true}, -- Subtle Cogwheel, Cogwheel, 208 dodge
	[59478] = {r = 27, [103] = true, [15] = true, [72] = true}, -- Smooth Cogwheel, Cogwheel, 208 crit
	[59479] = {r = 27, [103] = true, [15] = true, [70] = true}, -- Quick Cogwheel, Cogwheel, 208 haste
	[59480] = {r = 27, [103] = true, [15] = true, [85] = true}, -- Fractured Cogwheel, Cogwheel, 208 mastery
	[59489] = {r = 27, [103] = true, [15] = true, [84] = true}, -- Precise Cogwheel, Cogwheel, 208 expert
	[59491] = {r = 27, [103] = true, [15] = true, [76] = true}, -- Flashing Cogwheel, Cogwheel, 208 parry
	[59493] = {r = 27, [103] = true, [15] = true, [71] = true}, -- Rigid Cogwheel, Cogwheel, 208 hit
	[59496] = {r = 27, [103] = true, [15] = true, [65] = true}, -- Sparkling Cogwheel, Cogwheel, 208 spi
	[68356] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Ember Topaz, red, yellow, 20 int, 20 resil
	[68357] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Ember Topaz, red, yellow, 20 agil, 20 resil
	[68358] = {r = 23, [101] = true, [175] = true, [12] = true, [13] = true, [61] = true, [66] = true},	-- Resplendent Ember Topaz, red, yellow, 20 str, 20 resil
	[68660] = {r = 27, [103] = true, [15] = true, [66] = true}, -- Mystic Cogwheel, Cogwheel, 208 resil
	[68741] = {r = 23, [101] = true, [174] = true, [11] = true, [13] = true, [66] = true, [82] = true},	-- Vivid Dream Emerald, blue, yellow, 20 resil, 25 spellpen
	[68778] = {r = 24, [101] = true, [177] = true, [14] = true, [62] = true}, -- Agile Shadowspirit Diamond, meta, 54 agil, 3% increased crit damage
	[68779] = {r = 24, [101] = true, [177] = true, [14] = true, [61] = true}, -- Reverberating Shadowspirit Diamond, meta, 54 str, 3% increased crit effect
	[68780] = {r = 24, [101] = true, [177] = true, [14] = true, [64] = true}, -- Burning Shadowspirit Diamond, meta, 54 int, 3% increased crit damage
	[71817] = {r = 25, [101] = true, [181] = true, [11] = true, [71] = true}, -- Rigid Deepholm Iolite, blue, 50 hit
	[71818] = {r = 25, [101] = true, [181] = true, [11] = true, [82] = true}, -- Stormy Deepholm Iolite, blue, 63 spellpen
	[71819] = {r = 25, [101] = true, [181] = true, [11] = true, [65] = true}, -- Sparkling Deepholm Iolite, blue, 50 spi
	[71820] = {r = 25, [101] = true, [181] = true, [11] = true, [63] = true}, -- Solid Deepholm Iolite, blue, 75 stam
	[71822] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [65] = true, [72] = true}, -- Misty Elven Peridot, yellow, blue, 25 spi, 25 crit
	[71823] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [72] = true, [71] = true}, -- Piercing Elven Peridot, yellow, blue, 25 crit, 25 hit
	[71824] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [70] = true, [71] = true}, -- Lightning Elven Peridot, yellow, blue, 25 haste, 25 hit
	[71825] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [71] = true, [85] = true}, -- Sensei's Elven Peridot, yellow, blue, 25 hit, 25 mastery
	[71826] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [82] = true, [85] = true}, -- Infused Elven Peridot, yellow, blue, 32 spellpen, 25 mastery
	[71827] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [65] = true, [85] = true}, -- Zen Elven Peridot, yellow, blue, 25 spi, 25 mastery
	[71828] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [71] = true, [66] = true}, -- Balanced Elven Peridot, yellow, blue, 25 hit, 25 resil
	[71829] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [82] = true, [66] = true}, -- Vivid Elven Peridot, yellow, blue, 32 spellpen, 25 resil
	[71830] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [65] = true, [66] = true}, -- Turbid Elven Peridot, yellow, blue, 25 spi, 25 resil
	[71831] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [72] = true, [82] = true}, -- Radiant Elven Peridot, yellow, blue, 25 crit, 32 spellpen
	[71832] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [70] = true, [82] = true}, -- Shattered Elven Peridot, yellow, blue, 25 haste, 32 spellpen
	[71833] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [70] = true, [65] = true}, -- Energized Elven Peridot, yellow, blue, 25 haste, 25 spi
	[71834] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [72] = true, [63] = true}, -- Jagged Elven Peridot, yellow, blue, 25 crit, 37 stam
	[71835] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [74] = true, [63] = true}, -- Regal Elven Peridot, yellow, blue, 25 dodge, 37 stam
	[71836] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [70] = true, [63] = true}, -- Forceful Elven Peridot, yellow, blue, 25 haste, 37 stam
	[71837] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [71] = true, [74] = true}, -- Nimble Elven Peridot, yellow, blue, 25 hit, 25 dodge
	[71838] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [85] = true, [63] = true}, -- Puissant Elven Peridot, yellow, blue, 25 mastery, 37 stam
	[71839] = {r = 25, [101] = true, [184] = true, [13] = true, [11] = true, [66] = true, [63] = true}, -- Steady Elven Peridot, yellow, blue, 25 resil, 37 stam
	[71840] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [62] = true, [72] = true}, -- Deadly Lava Coral, red, yellow, 25 agil, 25 crit
	[71841] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [84] = true, [72] = true}, -- Crafty Lava Coral, red, yellow, 25 expert, 25 crit
	[71842] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [64] = true, [72] = true}, -- Potent Lava Coral, red, yellow, 25 int, 25 crit
	[71843] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [61] = true, [72] = true}, -- Inscribed Lava Coral, red, yellow, 25 str, 25 crit
	[71844] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [62] = true, [74] = true}, -- Polished Lava Coral, red, yellow, 25 agil, 25 dodge
	[71845] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [84] = true, [74] = true}, -- Resolute Lava Coral, red, yellow, 25 expert, 25 dodge
	[71846] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [76] = true, [74] = true}, -- Stalwart Lava Coral, red, yellow, 25 parry, 25 dodge
	[71847] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [61] = true, [74] = true}, -- Champion's Lava Coral, red, yellow, 25 str, 25 dodge
	[71848] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [62] = true, [70] = true}, -- Deft Lava Coral, red, yellow, 25 agil, 25 haste
	[71849] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [84] = true, [70] = true}, -- Wicked Lava Coral, red, yellow, 25 expert, 25 haste
	[71850] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [64] = true, [70] = true}, -- Reckless Lava Coral, red, yellow, 25 int, 25 haste
	[71851] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [61] = true, [70] = true}, -- Fierce Lava Coral, red, yellow, 25 str, 25 haste
	[71852] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [62] = true, [85] = true}, -- Adept Lava Coral, red, yellow, 25 agil, 25 mastery
	[71854] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [64] = true, [85] = true}, -- Artful Lava Coral, red, yellow, 25 int, 25 mastery
	[71855] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [76] = true, [85] = true}, -- Fine Lava Coral, red, yellow, 25 parry, 25 mastery
	[71856] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [61] = true, [85] = true}, -- Skillful Lava Coral, red, yellow, 25 str, 25 mastery
	[71857] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [62] = true, [66] = true}, -- Lucent Lava Coral, red, yellow, 25 agil, 25 resil
	[71858] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [84] = true, [66] = true}, -- Tenuous Lava Coral, red, yellow, 25 expert, 25 resil
	[71859] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [64] = true, [66] = true}, -- Willful Lava Coral, red, yellow, 25 int, 25 resil
	[71860] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [76] = true, [66] = true}, -- Splendid Lava Coral, red, yellow, 25 parry, 25 resil
	[71861] = {r = 25, [101] = true, [185] = true, [12] = true, [13] = true, [61] = true, [66] = true}, -- Resplendent Lava Coral, red, yellow, 25 str, 25 resil
	[71862] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [62] = true, [71] = true}, -- Glinting Shadow Spinel, red, blue, 25 agil, 25 hit
	[71863] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [84] = true, [71] = true}, -- Accurate Shadow Spinel, red, blue, 25 expert, 25 hit
	[71864] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [64] = true, [71] = true}, -- Veiled Shadow Spinel, red, blue, 25 int, 25 hit
	[71865] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [76] = true, [71] = true}, -- Retaliating Shadow Spinel, red, blue, 25 parry, 25 hit
	[71866] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [61] = true, [71] = true}, -- Etched Shadow Spinel, red, blue, 25 str, 25 hit
	[71867] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [64] = true, [82] = true}, -- Mysterious Shadow Spinel, red, blue, 25 int, 32 spellpen
	[71868] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [64] = true, [65] = true}, -- Purified Shadow Spinel, red, blue, 25 int, 25 spi
	[71869] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [62] = true, [63] = true}, -- Shifting Shadow Spinel, red, blue, 25 agil, 37 stam
	[71870] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [84] = true, [63] = true}, -- Guardian's Shadow Spinel, red, blue, 25 expert, 37 stam
	[71871] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [64] = true, [63] = true}, -- Timeless Shadow Spinel, red, blue, 25 int, 37 stam
	[71872] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [76] = true, [63] = true}, -- Defender's Shadow Spinel, red, blue, 25 parry, 37 stam
	[71873] = {r = 25, [101] = true, [186] = true, [12] = true, [11] = true, [61] = true, [63] = true}, -- Sovereign Shadow Spinel, red, blue, 25 str, 37 stam
	[71874] = {r = 25, [101] = true, [183] = true, [13] = true, [72] = true}, -- Smooth Lightstone, yellow, 50 crit
	[71875] = {r = 25, [101] = true, [183] = true, [13] = true, [74] = true}, -- Subtle Lightstone, yellow, 50 dodge
	[71876] = {r = 25, [101] = true, [183] = true, [13] = true, [70] = true}, -- Quick Lightstone, yellow, 50 haste
	[71877] = {r = 25, [101] = true, [183] = true, [13] = true, [85] = true}, -- Fractured Lightstone, yellow, 50 mastery
	[71878] = {r = 25, [101] = true, [183] = true, [13] = true, [66] = true}, -- Mystic Lightstone, yellow, 50 resil
	[71879] = {r = 25, [101] = true, [182] = true, [12] = true, [62] = true}, -- Delicate Queen's Garnet, red, 50 agil
	[71880] = {r = 25, [101] = true, [182] = true, [12] = true, [84] = true}, -- Precise Queen's Garnet, red, 50 expert
	[71881] = {r = 25, [101] = true, [182] = true, [12] = true, [64] = true}, -- Brilliant Queen's Garnet, red, 50 int
	[71882] = {r = 25, [101] = true, [182] = true, [12] = true, [76] = true}, -- Flashing Queen's Garnet, red, 50 parry
	[71883] = {r = 25, [101] = true, [182] = true, [12] = true, [61] = true}, -- Bold Queen's Garnet, red, 50 str
	[77130] = {r = 25, [103] = true, [13] = true, [11] = true, [71] = true, [66] = true}, -- Balanced Elven Peridot, yellow, blue, 25 hit, 25 resil
	[77131] = {r = 25, [103] = true, [13] = true, [11] = true, [82] = true, [85] = true}, -- Infused Elven Peridot, yellow, blue, 32 spellpen, 25 mastery
	[77132] = {r = 25, [103] = true, [12] = true, [13] = true, [62] = true, [66] = true}, -- Lucent Lava Coral, red, yellow, 25 agil, 25 resil
	[77133] = {r = 25, [103] = true, [12] = true, [11] = true, [64] = true, [82] = true}, -- Mysterious Shadow Spinel, red, blue, 25 int, 32 spellpen
	[77134] = {r = 25, [103] = true, [13] = true, [66] = true}, -- Mystic Lightstone, yellow, 50 resil
	[77136] = {r = 25, [103] = true, [12] = true, [13] = true, [61] = true, [66] = true}, -- Resplendent Lava Coral, red, yellow, 25 str, 25 resil
	[77137] = {r = 25, [103] = true, [13] = true, [11] = true, [70] = true, [82] = true}, -- Shattered Elven Peridot, yellow, blue, 25 haste, 32 spellpen
-- pvp resil / pvp power updates completed below this line
	[77138] = {r = 25, [103] = true, [12] = true, [13] = true, [76] = true, [66] = true}, -- Splendid Lava Coral, red, yellow, 25 parry, 25 pvp-resil
	[77139] = {r = 25, [103] = true, [13] = true, [11] = true, [66] = true, [63] = true}, -- Steady Elven Peridot, yellow, blue, 25 pvp-resil, 37 stam
	[77140] = {r = 25, [103] = true, [11] = true, [82] = true},  -- Stormy Deepholm Iolite, blue, 50 pvppow
	[77141] = {r = 25, [103] = true, [12] = true, [13] = true, [84] = true, [66] = true}, -- Tenuous Lava Coral, red, yellow, 25 expert, 25 pvp-resil
	[77142] = {r = 25, [103] = true, [13] = true, [11] = true, [65] = true, [66] = true}, -- Turbid Elven Peridot, yellow, blue, 25 spi, 25 pvp-resil
	[77143] = {r = 25, [103] = true, [13] = true, [11] = true, [82] = true, [66] = true}, -- Vivid Elven Peridot, yellow, blue, 25 pvp-pow, 25 pvp-resil
	[77144] = {r = 25, [103] = true, [12] = true, [13] = true, [64] = true, [66] = true}, -- Willful Lava Coral, red, yellow, 25 int, 25 pvp-resil
	[77154] = {r = 25, [103] = true, [13] = true, [11] = true, [72] = true, [82] = true}, -- Radiant Elven Peridot, yellow, blue, 25 crit, 25 pvppow
-- start of MoP gems
	[76502] = {r = 31, [101] = true, [190] = true, [11] = true, [71] = true},	-- Rigid Lapis Lazuli, blue, 240 hit
	[76504] = {r = 31, [101] = true, [190] = true, [11] = true, [82] = true},	-- Stormy Lapis Lazuli, blue, 240 pvp-pow
	[76505] = {r = 31, [101] = true, [190] = true, [11] = true, [65] = true},	-- Sparkling Lapis Lazuli, blue, 240 spi
	[76506] = {r = 31, [101] = true, [190] = true, [11] = true, [63] = true},	-- Solid Lapis Lazuli, blue, 180 stam
	[76507] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [65] = true, [72] = true},	-- Misty Alexandrite, yellow, blue, 120 spi, 120 crit
	[76508] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [72] = true, [71] = true},	-- Piercing Alexandrite, yellow, blue, 120 crit, 120 hit
	[76509] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [71] = true},	-- Lightning Alexandrite, yellow, blue, 120 haste, 120 hit
	[76510] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [85] = true},	-- Sensei's Alexandrite, yellow, blue, 120 hit, 120 mastery
	[76511] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [82] = true, [85] = true},	-- Effulgent Alexandrite, yellow, blue, 120 pvp-pow, 120 mastery
	[76512] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [65] = true, [85] = true},	-- Zen Alexandrite, yellow, blue, 120 spi, 120 mastery
	[76513] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [66] = true},	-- Balanced Alexandrite, yellow, blue, 120 hit, 120 pvp-resil
	[76514] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [82] = true, [66] = true},	-- Vivid Alexandrite, yellow, blue, 120 pvp-pow, 120 pvp-resil
	[76515] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [65] = true, [66] = true},	-- Turbid Alexandrite, yellow, blue, 120 spi, 120 pvp-resil
	[76517] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Alexandrite, yellow, blue, 120 crit, 120 pvppow
	[76518] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Shattered Alexandrite, yellow, blue, 120 haste, 120 pvppow
	[76519] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Alexandrite, yellow, blue, 120 haste, 120 spi
	[76520] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Alexandrite, yellow, blue, 120 crit, 90 stam
	[76521] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Alexandrite, yellow, blue, 120 dodge, 90 stam
	[76522] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Alexandrite, yellow, blue, 120 haste, 90 stam
	[76523] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [63] = true},	-- Confounded Alexandrite, yellow, blue, 120 hit, 90 stam
	[76524] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [85] = true, [63] = true},	-- Puissant Alexandrite, yellow, blue, 120 mastery, 90 stam
	[76525] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Alexandrite, yellow, blue, 120 pvp-resil, 90 stam
	[76526] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Tiger Opal, red, yellow, 60 agil, 120 crit
	[76527] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [72] = true},	-- Crafty Tiger Opal, red, yellow, 120 expert, 120 crit
	[76528] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Tiger Opal, red, yellow, 60 int, 120 crit
	[76529] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Tiger Opal, red, yellow, 60 str, 120 crit
	[76530] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [74] = true},	-- Polished Tiger Opal, red, yellow, 60 agil, 120 dodge
	[76531] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [74] = true},	-- Resolute Tiger Opal, red, yellow, 120 expert, 120 dodge
	[76532] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Tiger Opal, red, yellow, 120 parry, 120 dodge
	[76533] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [74] = true},	-- Champion's Tiger Opal, red, yellow, 60 str, 120 dodge
	[76534] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Tiger Opal, red, yellow, 60 agil, 120 haste
	[76535] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [70] = true},	-- Wicked Tiger Opal, red, yellow, 120 expert, 120 haste
	[76536] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Tiger Opal, red, yellow, 60 int, 120 haste
	[76537] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [70] = true},	-- Fierce Tiger Opal, red, yellow, 60 str, 120 haste
	[76538] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [85] = true},	-- Adept Tiger Opal, red, yellow, 60 agil, 120 mastery
	[76539] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [85] = true},	-- Keen Tiger Opal, red, yellow, 120 expert, 120 mastery
	[76540] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [85] = true},	-- Artful Tiger Opal, red, yellow, 60 int, 120 mastery
	[76541] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [76] = true, [85] = true},	-- Fine Tiger Opal, red, yellow, 120 parry, 120 mastery
	[76542] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [85] = true},	-- Skillful Tiger Opal, red, yellow, 60 str, 120 mastery
	[76543] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Tiger Opal, red, yellow, 60 agil, 120 pvp-resil
	[76544] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [66] = true},	-- Tenuous Tiger Opal, red, yellow, 120 expert, 120 pvp-resil
	[76545] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Tiger Opal, red, yellow, 60 int, 120 pvp-resil
	[76546] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [76] = true, [66] = true},	-- Splendid Tiger Opal, red, yellow, 120 parry, 120 pvp-resil
	[76547] = {r = 31, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [66] = true},	-- Resplendent Tiger Opal, red, yellow, 60 str, 120 pvp-resil
	[76548] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Roguestone, red, blue, 60 agi, 120 hit
	[76549] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Roguestone, red, blue, 120 exp, 120 hit
	[76550] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Roguestone, red, blue, 60 int, 120 hit
	[76551] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [76] = true, [71] = true},	-- Retaliating Roguestone, red, blue, 120 parry, 120 hit
	[76552] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Roguestone, red, blue, 60 str, 120 hit
	[76553] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Roguestone, red, blue, 60 int, 120 pvppow
	[76554] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Roguestone, red, blue, 60 int, 120 spi
	[76555] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Roguestone, red, blue, 60 agi, 90 sta
	[76556] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian's Roguestone, red, blue, 120 exp, 90 sta
	[76557] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Roguestone, red, blue, 60 int, 90 sta
	[76558] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Roguestone, red, blue, 120 parry, 90 sta
	[76559] = {r = 31, [101] = true, [195] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Roguestone, red, blue, 60 str, 90 sta
	[76560] = {r = 31, [101] = true, [191] = true, [12] = true, [62] = true},	-- Delicate Pandarian Garnet, red, 120 agi
	[76561] = {r = 31, [101] = true, [191] = true, [12] = true, [84] = true},	-- Precise Pandarian Garnet, red, 240 expert
	[76562] = {r = 31, [101] = true, [191] = true, [12] = true, [64] = true},	-- Brilliant Pandarian Garnet, red, 120 int
	[76563] = {r = 31, [101] = true, [191] = true, [12] = true, [76] = true},	-- Flashing Pandarian Garnet, red, 240 parry
	[76564] = {r = 31, [101] = true, [191] = true, [12] = true, [61] = true},	-- Bold Pandarian Garnet, red, 120 str
	[76565] = {r = 31, [101] = true, [192] = true, [13] = true, [72] = true},	-- Smooth Sunstone, yellow, 240 crit
	[76566] = {r = 31, [101] = true, [192] = true, [13] = true, [74] = true},	-- Subtle Sunstone, yellow, 240 dodge
	[76567] = {r = 31, [101] = true, [192] = true, [13] = true, [70] = true},	-- Quick Sunstone, yellow, 240 haste
	[76568] = {r = 31, [101] = true, [192] = true, [13] = true, [85] = true},	-- Fractured Sunstone, yellow, 240 mastery
	[76569] = {r = 31, [101] = true, [192] = true, [13] = true, [66] = true},	-- Mystic Sunstone, yellow, 240 pvp-resil
	[76570] = {r = 32, [101] = true, [190] = true, [11] = true, [71] = true},	-- Perfect Rigid Lapis Lazuli, blue, 320 hit
	[76571] = {r = 32, [101] = true, [190] = true, [11] = true, [82] = true},	-- Perfect Stormy Lapis Lazuli, blue, 320 pvp-pow
	[76572] = {r = 32, [101] = true, [190] = true, [11] = true, [65] = true},	-- Perfect Sparkling Lapis Lazuli, blue, 320 spi
	[76573] = {r = 32, [101] = true, [190] = true, [11] = true, [63] = true},	-- Perfect Solid Lapis Lazuli, blue, 240 stam
	[76574] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [65] = true, [72] = true},	-- Perfect Misty Alexandrite, yellow, blue, 160 spi, 160 crit
	[76575] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [72] = true, [71] = true},	-- Perfect Piercing Alexandrite, yellow, blue, 160 crit, 160 hit
	[76576] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [71] = true},	-- Perfect Lightning Alexandrite, yellow, blue, 160 haste, 160 hit
	[76577] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [85] = true},	-- Perfect Sensei's Alexandrite, yellow, blue, 160 hit, 160 mastery
	[76578] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [82] = true, [85] = true},	-- Perfect Effulgent Alexandrite, yellow, blue, 160 pvp-pow, 160 mastery
	[76579] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [65] = true, [85] = true},	-- Perfect Zen Alexandrite, yellow, blue, 160 spi, 160 mastery
	[76580] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [66] = true},	-- Perfect Balanced Alexandrite, yellow, blue, 160 hit, 160 pvp-resil
	[76581] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [82] = true, [66] = true},	-- Perfect Vivid Alexandrite, yellow, blue, 160 pvp-pow, 160 pvp-resil
	[76582] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [65] = true, [66] = true},	-- Perfect Turbid Alexandrite, yellow, blue, 160 spi, 160 pvp-resil
	[76583] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Perfect Radiant Alexandrite, yellow, blue, 160 crit, 160 pvp-pow
	[76584] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Perfect Shattered Alexandrite, yellow, blue, 160 haste, 160 pvp-pow
	[76585] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Perfect Energized Alexandrite, yellow, blue, 160 haste, 160 spi
	[76586] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Perfect Jagged Alexandrite, yellow, blue, 160 crit, 120 stam
	[76587] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Perfect Regal Alexandrite, yellow, blue, 160 dodge, 120 stam
	[76588] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Perfect Forceful Alexandrite, yellow, blue, 160 haste, 120 stam
	[76589] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [63] = true},	-- Perfect Confounded Alexandrite, yellow, blue, 160 hit, 120 stam
	[76590] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [85] = true, [63] = true},	-- Perfect Puissant Alexandrite, yellow, blue, 160 mastery, 120 stam
	[76591] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Perfect Steady Alexandrite, yellow, blue, 160 pvp-resil, 120 stam
	[76592] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Perfect Deadly Tiger Opal, red, yellow, 80 agil, 160 crit
	[76593] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [72] = true},	-- Perfect Crafty Tiger Opal, red, yellow, 160 expert, 160 crit
	[76594] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Perfect Potent Tiger Opal, red, yellow, 80 int, 160 crit
	[76595] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Perfect Inscribed Tiger Opal, red, yellow, 80 str, 160 crit
	[76596] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [74] = true},	-- Perfect Polished Tiger Opal, red, yellow, 80 agil, 160 dodge
	[76597] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [74] = true},	-- Perfect Resolute Tiger Opal, red, yellow, 160 expert, 160 dodge
	[76598] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Perfect Stalwart Tiger Opal, red, yellow, 160 parry, 160 dodge
	[76599] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [74] = true},	-- Perfect Champion's Tiger Opal, red, yellow, 80 str, 160 dodge
	[76600] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Perfect Deft Tiger Opal, red, yellow, 80 agil, 160 haste
	[76601] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [70] = true},	-- Perfect Wicked Tiger Opal, red, yellow, 160 expert, 160 haste
	[76602] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Perfect Reckless Tiger Opal, red, yellow, 80 int, 160 haste
	[76603] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [70] = true},	-- Perfect Fierce Tiger Opal, red, yellow, 80 str, 160 haste
	[76604] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [85] = true},	-- Perfect Adept Tiger Opal, red, yellow, 80 agil, 160 mastery
	[76605] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [85] = true},	-- Perfect Keen Tiger Opal, red, yellow, 160 expert, 160 mastery
	[76606] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [85] = true},	-- Perfect Artful Tiger Opal, red, yellow, 80 int, 160 mastery
	[76607] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [76] = true, [85] = true},	-- Perfect Fine Tiger Opal, red, yellow, 160 parry, 160 mastery
	[76608] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [85] = true},	-- Perfect Skillful Tiger Opal, red, yellow, 80 str, 160 mastery
	[76609] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Perfect Lucent Tiger Opal, red, yellow, 80 agil, 160 pvpresil
	[76610] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [84] = true, [66] = true},	-- Perfect Tenuous Tiger Opal, red, yellow, 160 expert, 160 pvpresil
	[76611] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Perfect Willful Tiger Opal, red, yellow, 80 int, 160 pvpresil
	[76612] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [76] = true, [66] = true},	-- Perfect Splendid Tiger Opal, red, yellow, 160 parry, 160 pvpresil
	[76613] = {r = 32, [101] = true, [194] = true, [12] = true, [13] = true, [61] = true, [66] = true},	-- Perfect Resplendent Tiger Opal, red, yellow, 80 str, 160 pvpresil
	[76614] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Perfect Glinting Roguestone, red, blue, 80 agi, 160 hit
	[76615] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Perfect Accurate Roguestone, red, blue, 160 exp, 160 hit
	[76616] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Perfect Veiled Roguestone, red, blue, 160 int, 160 hit
	[76617] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [76] = true, [71] = true},	-- Perfect Retaliating Roguestone, red, blue, 160 parry, 160 hit
	[76618] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Perfect Etched Roguestone, red, blue, 80 str, 160 hit
	[76619] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Perfect Mysterious Roguestone, red, blue, 80 int, 160 pvp-pow
	[76620] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Perfect Purified Roguestone, red, blue, 80 int, 160 spi
	[76621] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Perfect Shifting Roguestone, red, blue, 80 agi, 120 sta
	[76622] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Perfect Guardian's Roguestone, red, blue, 160 exp, 120 sta
	[76623] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Perfect Timeless Roguestone, red, blue, 80 int, 120 sta
	[76624] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Perfect Defender's Roguestone, red, blue, 160 parry, 120 sta
	[76625] = {r = 32, [101] = true, [195] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Perfect Sovereign Roguestone, red, blue, 80 str, 120 sta
	[76626] = {r = 32, [101] = true, [191] = true, [12] = true, [62] = true},	-- Perfect Delicate Pandarian Garnet, red, 160 agi
	[76627] = {r = 32, [101] = true, [191] = true, [12] = true, [84] = true},	-- Perfect Precise Pandarian Garnet, red, 320 expert
	[76628] = {r = 32, [101] = true, [191] = true, [12] = true, [64] = true},	-- Perfect Brilliant Pandarian Garnet, red, 320 int
	[76629] = {r = 32, [101] = true, [191] = true, [12] = true, [76] = true},	-- Perfect Flashing Pandarian Garnet, red, 320 parry
	[76630] = {r = 32, [101] = true, [191] = true, [12] = true, [61] = true},	-- Perfect Bold Pandarian Garnet, red, 320 str
	[76631] = {r = 32, [101] = true, [192] = true, [13] = true, [72] = true},	-- Perfect Smooth Sunstone, yellow, 320 crit
	[76632] = {r = 32, [101] = true, [192] = true, [13] = true, [74] = true},	-- Perfect Subtle Sunstone, yellow, 320 dodge
	[76633] = {r = 32, [101] = true, [192] = true, [13] = true, [70] = true},	-- Perfect Quick Sunstone, yellow, 320 haste
	[76634] = {r = 32, [101] = true, [192] = true, [13] = true, [85] = true},	-- Perfect Fractured Sunstone, yellow, 320 mastery
	[76635] = {r = 32, [101] = true, [192] = true, [13] = true, [66] = true},	-- Perfect Mystic Sunstone, yellow, 320 pvp-resil
	[76636] = {r = 33, [101] = true, [200] = true, [11] = true, [71] = true},	-- Rigid River's Heart, blue, 320 hit
	[76637] = {r = 33, [101] = true, [200] = true, [11] = true, [82] = true},	-- Stormy River's Heart, blue, 320 pvppow
	[76638] = {r = 33, [101] = true, [200] = true, [11] = true, [65] = true},	-- Sparkling River's Heart, blue, 320 spi
	[76639] = {r = 33, [101] = true, [200] = true, [11] = true, [63] = true},	-- Solid River's Heart, blue, 240 stam
	[76640] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [65] = true, [72] = true},	-- Misty Wild Jade, yellow, blue, 160 spi, 160 crit
	[76641] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [72] = true, [71] = true},	-- Piercing Wild Jade, yellow, blue, 160 crit, 160 hit
	[76642] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [70] = true, [71] = true},	-- Lightning Wild Jade, yellow, blue, 160 haste, 160 hit
	[76643] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [71] = true, [85] = true},	-- Sensei's Wild Jade, yellow, blue, 160 hit, 160 mastery
	[76644] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [82] = true, [85] = true},	-- Effulgent Wild Jade, yellow, blue, 160 pvppow, 160 mastery
	[76645] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [65] = true, [85] = true},	-- Zen Wild Jade, yellow, blue, 160 spi, 160 mastery
	[76646] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [71] = true, [66] = true},	-- Balanced Wild Jade, yellow, blue, 160 hit, 160 pvpres
	[76647] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [82] = true, [66] = true},	-- Vivid Wild Jade, yellow, blue, 160 pvppow, 160 pvpres
	[76648] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [65] = true, [66] = true},	-- Turbid Wild Jade, yellow, blue, 160 spi, 160 pvpres
	[76649] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Wild Jade, yellow, blue, 160 crit, 160 pvppow
	[76650] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [70] = true, [82] = true},	-- Shattered Wild Jade, yellow, blue, 160 haste, 160 pvppow
	[76651] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Wild Jade, yellow, blue, 160 haste, 160 spi
	[76652] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Wild Jade, yellow, blue, 160 crit, 120 stam
	[76653] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Wild Jade, yellow, blue, 160 dodge, 120 stam
	[76654] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Wild Jade, yellow, blue, 160 haste, 120 stam
	[76655] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [71] = true, [63] = true},	-- Confounded Wild Jade, yellow, blue, 160 hit, 120 stam
	[76656] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [85] = true, [63] = true},	-- Puissant Wild Jade, yellow, blue, 160 mastery, 120 stam
	[76657] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Wild Jade, yellow, blue, 160 pvpres, 120 stam
	[76658] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Vermilion Onyx, red, yellow, 80 agil, 160 crit
	[76659] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [72] = true},	-- Crafty Vermilion Onyx, red, yellow, 160 expert, 160 crit
	[76660] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Vermilion Onyx, red, yellow, 80 int, 160 crit
	[76661] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Vermilion Onyx, red, yellow, 80 str, 160 crit
	[76662] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [62] = true, [74] = true},	-- Polished Vermilion Onyx, red, yellow, 80 agil, 160 dodge
	[76663] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [74] = true},	-- Resolute Vermilion Onyx, red, yellow, 160 expert, 160 dodge
	[76664] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Vermilion Onyx, red, yellow, 160 parry, 160 dodge
	[76665] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [61] = true, [74] = true},	-- Champion's Vermilion Onyx, red, yellow, 80 str, 160 dodge
	[76666] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Vermilion Onyx, red, yellow, 80 agil, 160 haste
	[76667] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [70] = true},	-- Wicked Vermilion Onyx, red, yellow, 160 expert, 160 haste
	[76668] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Vermilion Onyx, red, yellow, 80 int, 160 haste
	[76669] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [61] = true, [70] = true},	-- Fierce Vermilion Onyx, red, yellow, 80 str, 160 haste
	[76670] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [62] = true, [85] = true},	-- Adept Vermilion Onyx, red, yellow, 80 agi, 160 mastery
	[76671] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [85] = true},	-- Keen Vermilion Onyx, red, yellow, 160 expert, 160 mastery
	[76672] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [64] = true, [85] = true},	-- Artful Vermilion Onyx, red, yellow, 80 int, 160 mastery
	[76673] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [76] = true, [85] = true},	-- Fine Vermilion Onyx, red, yellow, 160 parry, 160 mastery
	[76674] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [61] = true, [85] = true},	-- Skillful Vermilion Onyx, red, yellow, 80 str, 160 mastery
	[76675] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Vermilion Onyx, red, yellow, 80 agil, 160 pvpres
	[76676] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [66] = true},	-- Tenuous Vermilion Onyx, red, yellow, 160 expert, 160 pvpres
	[76677] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Vermilion Onyx, red, yellow, 80 int, 160 pvpres
	[76678] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [76] = true, [66] = true},	-- Splendid Vermilion Onyx, red, yellow, 160 parry, 160 pvpres
	[76679] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [61] = true, [66] = true},	-- Resplendent Vermilion Onyx, red, yellow, 80 str, 160 pvpres
	[76680] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Imperial Amethyst, red, blue, 80 agil, 160 hit
	[76681] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Imperial Amethyst, red, blue, 160 expert, 160 hit
	[76682] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Imperial Amethyst, red, blue, 80 int, 160 hit
	[76683] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [76] = true, [71] = true},	-- Retaliating Imperial Amethyst, red, blue, 160 parry, 160 hit
	[76684] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Imperial Amethyst, red, blue, 80 str, 160 hit
	[76685] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Imperial Amethyst, red, blue, 80 int, 160 pvppow
	[76686] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Imperial Amethyst, red, blue, 80 int, 160 spi
	[76687] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Imperial Amethyst, red, blue, 80 agi, 120 sta
	[76688] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian's Imperial Amethyst, red, blue, 160 expert, 120 sta
	[76689] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Imperial Amethyst, red, blue, 80 int, 120 sta
	[76690] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Imperial Amethyst, red, blue, 160 parry, 120 sta
	[76691] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Imperial Amethyst, red, blue, 80 str, 120 sta
	[76692] = {r = 33, [101] = true, [201] = true, [12] = true, [62] = true},	-- Delicate Primordial Ruby, red, 160 agil
	[76693] = {r = 33, [101] = true, [201] = true, [12] = true, [84] = true},	-- Precise Primordial Ruby, red, 320 expert
	[76694] = {r = 33, [101] = true, [201] = true, [12] = true, [64] = true},	-- Brilliant Primordial Ruby, red, 160 int
	[76695] = {r = 33, [101] = true, [201] = true, [12] = true, [76] = true},	-- Flashing Primordial Ruby, red, 320 parry
	[76696] = {r = 33, [101] = true, [201] = true, [12] = true, [61] = true},	-- Bold Primordial Ruby, red, 160 str
	[76697] = {r = 33, [101] = true, [202] = true, [13] = true, [72] = true},	-- Smooth Sun's Radiance, yellow, 320 crit
	[76698] = {r = 33, [101] = true, [202] = true, [13] = true, [74] = true},	-- Subtle Sun's Radiance, yellow, 320 dodge
	[76699] = {r = 33, [101] = true, [202] = true, [13] = true, [70] = true},	-- Quick Sun's Radiance, yellow, 320 haste
	[76700] = {r = 33, [101] = true, [202] = true, [13] = true, [85] = true},	-- Fractured Sun's Radiance, yellow, 320 mastery
	[76701] = {r = 33, [101] = true, [202] = true, [13] = true, [66] = true},	-- Mystic Sun's Radiance, yellow, 320 pvpres

--	[76714] = {r = 33, [200] = true, [11] = true, [71] = true},	-- Perfect Rigid River's Heart, blue, 24 hit
	
	[76879] = {r = 34, [101] = true, [196] = true, [14] = true, [64] = true},	-- Ember Primal Diamond, meta, 216 int, 2% maximum mana
	[76884] = {r = 34, [101] = true, [196] = true, [14] = true, [62] = true},	-- Agile Primal Diamond, meta, 216 agil, 3% increased crit effect
	[76885] = {r = 34, [101] = true, [196] = true, [14] = true, [64] = true},	-- Burning Primal Diamond, meta, 216 int, 3% increased crit effect
	[76886] = {r = 34, [101] = true, [196] = true, [14] = true, [61] = true},	-- Reverberating Primal Diamond, meta, 216 str, 3% increased crit effect
	[76887] = {r = 34, [101] = true, [196] = true, [14] = true, [85] = true},	-- Fleet Primal Diamond, meta, 432 mastery, minor run speed increase
	[76888] = {r = 34, [101] = true, [196] = true, [14] = true, [65] = true},	-- Revitalizing Primal Diamond, meta, 432 spi, 3% increased crit effect
	[76890] = {r = 34, [101] = true, [196] = true, [14] = true, [72] = true},	-- Destructive Primal Diamond, meta, 432 crit, 1% spell reflect
	[76891] = {r = 34, [101] = true, [196] = true, [14] = true, [63] = true},	-- Powerful Primal Diamond, meta, 324 stam, stun duration reduced 10%
	[76892] = {r = 34, [101] = true, [196] = true, [14] = true, [72] = true},	-- Enigmatic Primal Diamond, meta, 432 crit, reduced snare / root duration by 10%
	[76893] = {r = 34, [101] = true, [196] = true, [14] = true, [72] = true},	-- Impassive Primal Diamond, meta, 432 crit, fear duration reduced by 10%
	[76894] = {r = 34, [101] = true, [196] = true, [14] = true, [64] = true},	-- Forlorn Primal Diamond, meta, 216 int, silence duration reduced by 10%
	[76895] = {r = 34, [101] = true, [196] = true, [14] = true, [63] = true},	-- Austere Primal Diamond, meta, 324 stam, 2% increased armor value from items
	[76896] = {r = 34, [101] = true, [196] = true, [14] = true, [74] = true},	-- Eternal Primal Diamond, meta, 432 dodge, 1% shield block value
	[76897] = {r = 34, [101] = true, [196] = true, [14] = true, [63] = true},	-- Effulgent Primal Diamond, meta, 324 stam, reduced spell damage taken by 2%
	
	[77540] = {r = 37, [103] = true, [15] = true, [74] = true},	-- Subtle Tinker's Gear, cogwheel, 567 dodge
	[77541] = {r = 37, [103] = true, [15] = true, [72] = true},	-- Smooth Tinker's Gear, cogwheel, 567 crit
	[77542] = {r = 37, [103] = true, [15] = true, [70] = true},	-- Quick Tinker's Gear, cogwheel, 567 haste
	[77543] = {r = 37, [103] = true, [15] = true, [84] = true},	-- Precise Tinker's Gear, cogwheel, 567 expert
	[77544] = {r = 37, [103] = true, [15] = true, [76] = true},	-- Flashing Tinker's Gear, cogwheel, 567 parry
	[77545] = {r = 37, [103] = true, [15] = true, [71] = true},	-- Rigid Tinker's Gear, cogwheel, 567 hit
	[77546] = {r = 37, [103] = true, [15] = true, [65] = true},	-- Sparkling Tinker's Gear, cogwheel, 567 spirit
	[77547] = {r = 37, [103] = true, [15] = true, [85] = true},	-- Fractured Tinker's Gear, cogwheel, 567 mastery

	[83141] = {r = 36, [101] = true, [197] = true, [12] = true, [61] = true, [1013] = true},	-- Bold Serpent's Eye, red, 320 str
	[83142] = {r = 36, [101] = true, [197] = true, [13] = true, [70] = true, [1013] = true},	-- Quick Serpent's Eye, yellow, 480 haste
	[83143] = {r = 36, [101] = true, [197] = true, [13] = true, [85] = true, [1013] = true},	-- Fractured Serpent's Eye, yellow, 480 mastery
	[83144] = {r = 36, [101] = true, [197] = true, [11] = true, [71] = true, [1013] = true},	-- Rigid Serpent's Eye, blue, 480 hit
	[83145] = {r = 36, [101] = true, [197] = true, [13] = true, [74] = true, [1013] = true},	-- Subtle Serpent's Eye, yellow, 480 dodge
	[83146] = {r = 36, [101] = true, [197] = true, [13] = true, [72] = true, [1013] = true},	-- Smooth Serpent's Eye, yellow, 480 crit
	[83147] = {r = 36, [101] = true, [197] = true, [12] = true, [84] = true, [1013] = true},	-- Precise Serpent's Eye, red, 480 expert
	[83148] = {r = 36, [101] = true, [197] = true, [11] = true, [63] = true, [1013] = true},	-- Solid Serpent's Eye, blue, 480 stam
	[83149] = {r = 36, [101] = true, [197] = true, [11] = true, [65] = true, [1013] = true},	-- Sparkling Serpent's Eye, blue, 480 spi
	[83150] = {r = 36, [101] = true, [197] = true, [12] = true, [64] = true, [1013] = true},	-- Brilliant Serpent's Eye, red, 320 int
	[83151] = {r = 36, [101] = true, [197] = true, [12] = true, [62] = true, [1013] = true},	-- Delicate Serpent's Eye, red, 320 agil
	[83152] = {r = 36, [101] = true, [197] = true, [12] = true, [76] = true, [1013] = true},	-- Flashing Serpent's Eye, red, 480 parry
	
	
	[88911] = {r = 35, [13] = true, [11] = true, [71] = true, [66] = true},	-- Balanced Adventurine, yellow, blue, 200 hit, 200 pvpres
	[88912] = {r = 35, [13] = true, [11] = true, [82] = true, [85] = true},	-- Effulgent Adventurine, yellow, blue, 200 pvppow, 200 mastery
	[88913] = {r = 35, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Adventurine, yellow, blue, 200 haste, 200 spi
	[88914] = {r = 35, [13] = true, [11] = true, [70] = true, [63] = true},	-- Forceful Adventurine, yellow, blue, 200 haste, 150 stam
	[88915] = {r = 35, [13] = true, [11] = true, [72] = true, [63] = true},	-- Jagged Adventurine, yellow, blue, 200 crit, 150 stam
	[88916] = {r = 35, [13] = true, [11] = true, [70] = true, [71] = true},	-- Lightning Adventurine, yellow, blue, 200 haste, 200 hit
	[88917] = {r = 35, [13] = true, [11] = true, [65] = true, [72] = true},	-- Misty Adventurine, yellow, blue, 200 spi, 200 crit
	[88918] = {r = 35, [13] = true, [11] = true, [71] = true, [63] = true},	-- Confounded Adventurine, yellow, blue, 200 hit, 150 stam
	[88919] = {r = 35, [13] = true, [11] = true, [72] = true, [71] = true},	-- Piercing Adventurine, yellow, blue, 200 crit, 200 hit
	[88920] = {r = 35, [13] = true, [11] = true, [85] = true, [63] = true},	-- Puissant Adventurine, yellow, blue, 200 mastery, 150 stam
	[88921] = {r = 35, [13] = true, [11] = true, [72] = true, [82] = true},	-- Radiant Adventurine, yellow, blue, 200 crit, 200 pvppow
	[88922] = {r = 35, [13] = true, [11] = true, [74] = true, [63] = true},	-- Regal Adventurine, yellow, blue, 200 dodge, 150 stam
	[88923] = {r = 35, [13] = true, [11] = true, [71] = true, [85] = true},	-- Sensei's Adventurine, yellow, blue, 200 hit, 200 mastery
	[88924] = {r = 35, [13] = true, [11] = true, [70] = true, [82] = true},	-- Shattered Adventurine, yellow, blue, 200 haste, 200 pvppow
	[88925] = {r = 35, [13] = true, [11] = true, [66] = true, [63] = true},	-- Steady Adventurine, yellow, blue, 200 pvpres, 150 stam
	[88926] = {r = 35, [13] = true, [11] = true, [65] = true, [66] = true},	-- Turbid Adventurine, yellow, blue, 200 spi, 200 pvpres
	[88927] = {r = 35, [13] = true, [11] = true, [82] = true, [66] = true},	-- Vivid Adventurine, yellow, blue, 200 pvppow, 200 pvpres
	[88928] = {r = 35, [13] = true, [11] = true, [65] = true, [85] = true},	-- Zen Adventurine, yellow, blue, 200 spi, 200 mastery
	[88930] = {r = 35, [12] = true, [13] = true, [62] = true, [85] = true},	-- Adept Sardonyx, red, yellow, 100 agil, 200 mastery
	[88931] = {r = 35, [12] = true, [13] = true, [64] = true, [85] = true},	-- Artful Sardonyx, red, yellow, 100 int, 200 mastery
	[88932] = {r = 35, [12] = true, [13] = true, [61] = true, [74] = true},	-- Champion's Sardonyx, red, yellow, 100 str, 200 dodge
	[88933] = {r = 35, [12] = true, [13] = true, [84] = true, [72] = true},	-- Crafty Sardonyx, red, yellow, 200 expert, 200 crit
	[88934] = {r = 35, [12] = true, [13] = true, [62] = true, [72] = true},	-- Deadly Sardonyx, red, yellow, 100 agil, 200 crit
	[88935] = {r = 35, [12] = true, [13] = true, [62] = true, [70] = true},	-- Deft Sardonyx, red, yellow, 100 agil, 200 haste
	[88936] = {r = 35, [12] = true, [13] = true, [61] = true, [70] = true},	-- Fierce Sardonyx, red, yellow, 100 str, 200 haste
	[88937] = {r = 35, [12] = true, [13] = true, [76] = true, [85] = true},	-- Fine Sardonyx, red, yellow, 200 parry, 200 mastery
	[88938] = {r = 35, [12] = true, [13] = true, [61] = true, [72] = true},	-- Inscribed Sardonyx, red, yellow, 100 str, 200 crit
	[88939] = {r = 35, [12] = true, [13] = true, [84] = true, [85] = true},	-- Keen Sardonyx, red, yellow, 200 expert, 200 mastery
	[88940] = {r = 35, [12] = true, [13] = true, [62] = true, [66] = true},	-- Lucent Sardonyx, red, yellow, 100 agil, 200 pvpres
	[88941] = {r = 35, [12] = true, [13] = true, [62] = true, [74] = true},	-- Polished Sardonyx, red, yellow, 100 agil, 200 dodge
	[88942] = {r = 35, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Sardonyx, red, yellow, 100 int, 200 crit
	[88943] = {r = 35, [12] = true, [13] = true, [64] = true, [70] = true},	-- Reckless Sardonyx, red, yellow, 100 int, 200 haste
	[88944] = {r = 35, [12] = true, [13] = true, [84] = true, [74] = true},	-- Resolute Sardonyx, red, yellow, 200 expert, 200 dodge
	[88945] = {r = 35, [12] = true, [13] = true, [61] = true, [66] = true},	-- Resplendent Sardonyx, red, yellow, 100 str, 200 pvpres
	[88946] = {r = 35, [12] = true, [13] = true, [61] = true, [85] = true},	-- Skillful Sardonyx, red, yellow, 100 str, 200 mastery
	[88947] = {r = 35, [12] = true, [13] = true, [76] = true, [66] = true},	-- Splendid Sardonyx, red, yellow, 200 parry, 200 pvpres
	[88948] = {r = 35, [12] = true, [13] = true, [76] = true, [74] = true},	-- Stalwart Sardonyx, red, yellow, 200 parry, 200 dodge
	[88949] = {r = 35, [12] = true, [13] = true, [84] = true, [66] = true},	-- Tenuous Sardonyx, red, yellow, 200 expert, 200 pvpres
	[88950] = {r = 35, [12] = true, [13] = true, [84] = true, [70] = true},	-- Wicked Sardonyx, red, yellow, 200 expert, 200 haste
	[88951] = {r = 35, [12] = true, [13] = true, [64] = true, [66] = true},	-- Willful Sardonyx, red, yellow, 100 int, 200 pvpres
	[88952] = {r = 35, [12] = true, [11] = true, [84] = true, [71] = true},	-- Accurate Zyanite, red, blue, 200 expert, 200 hit
	[88953] = {r = 35, [12] = true, [11] = true, [76] = true, [63] = true},	-- Defender's Zyanite, red, blue, 200 parry, 150 sta
	[88954] = {r = 35, [12] = true, [11] = true, [61] = true, [71] = true},	-- Etched Zyanite, red, blue, 100 str, 200 hit
	[88955] = {r = 35, [12] = true, [11] = true, [62] = true, [71] = true},	-- Glinting Zyanite, red, blue, 100 agil, 200 hit
	[88956] = {r = 35, [12] = true, [11] = true, [84] = true, [63] = true},	-- Guardian's Zyanite, red, blue, 200 expert, 150 sta
	[88958] = {r = 35, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Zyanite, red, blue, 100 int, 200 spi
	[88959] = {r = 35, [12] = true, [11] = true, [76] = true, [71] = true},	-- Retaliating Zyanite, red, blue, 200 parry, 200 hit
	[88960] = {r = 35, [12] = true, [11] = true, [62] = true, [63] = true},	-- Shifting Zyanite, red, blue, 100 agil, 150 stam
	[88961] = {r = 35, [12] = true, [11] = true, [61] = true, [63] = true},	-- Sovereign Zyanite, red, blue, 100 str, 150 stam
	[88962] = {r = 35, [12] = true, [11] = true, [64] = true, [63] = true},	-- Timeless Zyanite, red, blue, 100 int, 150 stam
	[88963] = {r = 35, [12] = true, [11] = true, [64] = true, [71] = true},	-- Veiled Zyanite, red, blue, 100 int, 200 hit

	[88987] = {r = 35, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Zyanite, red, blue, 100 int, 200 pvppow

	[89674] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [61] = true, [82] = true},	-- Tense Imperial Amethyst, red, blue, 80 str, 160 pvppow
	[89675] = {r = 31, [12] = true, [11] = true},	-- Tense Roguestone, red, blue
	[89676] = {r = 32, [12] = true, [11] = true},	-- Perfect Tense Roguestone, red, blue
	[89677] = {r = 35, [12] = true, [11] = true, [61] = true, [82] = true},	-- Tense Zyanite, red, blue, 100 str, 200 pvppow
	[89678] = {r = 31, [12] = true, [11] = true},	-- Assassin's Roguestone, red, blue
	[89679] = {r = 32, [12] = true, [11] = true},	-- Perfect Assassin's Roguestone, red, blue
	[89680] = {r = 33, [101] = true, [205] = true, [12] = true, [11] = true, [62] = true, [82] = true},	-- Assassin's Imperial Amethyst, red, blue, 80 agi, 160 pvppow
	[89681] = {r = 35, [12] = true, [11] = true, [62] = true, [82] = true},	-- Assassin's Zyanite, red, blue, 100 agil, 200 pvppow
	
	[89873] = {r = 37, [103] = true, [105] = true, [16] = true, [62] = true},  -- Crystalized Dread, hydrolic, 500 agil
	[89881] = {r = 37, [103] = true, [105] = true, [16] = true, [61] = true},  -- Crystalized Terror, hydrolic, 500 str
	[89882] = {r = 37, [103] = true, [105] = true, [16] = true, [64] = true},  -- Crystalized Horror, hydrolic, 500 int
	[93364] = {r = 38, [105] = true, [16] = true, [62] = true},  -- Refined Crystalized Dread, hydrolic, 550 agil
	[93365] = {r = 38, [105] = true, [16] = true, [61] = true},  -- Refined Crystalized Terror, hydrolic, 550 str
	[93366] = {r = 38, [105] = true, [16] = true, [64] = true},  -- Refined Crystalized Horror, hydrolic, 550 int
	[93404] = {r = 36, [101] = true, [197] = true, [12] = true, [13] = true, [61] = true, [66] = true, [1013] = true},	-- Resplendent Serpent's Eye, red, yellow, 160 str, 320 pvpres
	[93405] = {r = 36, [101] = true, [197] = true, [12] = true, [13] = true, [62] = true, [66] = true, [1013] = true},	-- Lucent Serpent's Eye, red, yellow, 160 agil, 320 pvpres
	[93406] = {r = 36, [101] = true, [197] = true, [12] = true, [13] = true, [64] = true, [66] = true, [1013] = true},	-- Willful Serpent's Eye, red, yellow, 160 int, 320 pvpres
	[93408] = {r = 36, [101] = true, [197] = true, [12] = true, [11] = true, [61] = true, [82] = true, [1013] = true},	-- Tense Serpent's Eye, red, blue, 160 str, 320 pvppow
	[93409] = {r = 36, [101] = true, [197] = true, [12] = true, [11] = true, [62] = true, [82] = true, [1013] = true},	-- Assassin's Serpent's Eye, red, blue, 160 agil, 320 pvppow
	[93410] = {r = 36, [101] = true, [197] = true, [12] = true, [11] = true, [64] = true, [82] = true, [1013] = true},	-- Mysterious Serpent's Eye, red, blue, 160 int, 320 pvppow
	[93705] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Nimble Wild Jade, yellow, blue, 160 hit, 160 dodge
	[93706] = {r = 31, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Nimble Alexandrite, yellow, blue, 120 hit, 120 dodge
	[93707] = {r = 32, [101] = true, [193] = true, [13] = true, [11] = true, [71] = true, [74] = true},	-- Perfect Nimble Alexandrite, yellow, blue, 160 hit, 160 dodge
	[93708] = {r = 35, [13] = true, [11] = true, [71] = true, [74] = true},	-- Nimble Adventurine, yellow, blue, 200 hit, 200 dodge
	[95344] = {r = 36, [105] = true, [14] = true, [63] = true},	-- Indomitable Primal Diamond, meta, 324 stam, chance on being hit to gain 20% reduction to physical damage taken for 15 seconds
	[95345] = {r = 36, [105] = true, [14] = true, [64] = true},	-- Courageous Primal Diamond, meta, 324 int rating, chance on beneficial spell to make your next spell cost 0 mana
	[95346] = {r = 36, [105] = true, [14] = true, [72] = true},	-- Capacitive Primal Diamond, meta, 324 crit rating, chance on melee or range hit to gain capacitance (100 dmg)
	[95347] = {r = 36, [105] = true, [14] = true, [72] = true},	-- Sinister Primal Diamond, meta, 324 crit rating, chance on spell damage to gain 30% spell haste
	[95348] = {r = 35, [196] = true, [14] = true, [82] = true, [66] = true},	-- Tyrannical Primal Diamond, meta, 665 pvppow, 775 resil

-- clones added before 5.3 - source / reason unknown
--[[	[97306] = {r = 34, [14] = true, [65] = true},	-- Revitalizing Primal Diamond, meta, 30 spi, 3% increased crit effect
	[97307] = {r = 33, [11] = true, [65] = true},	-- Sparkling River's Heart, blue, 20 spi
	[97308] = {r = 33, [13] = true, [11] = true, [65] = true, [72] = true},	-- Misty Wild Jade, yellow, blue, 10 spi, 10 crit
	[97309] = {r = 37, [16] = true, [64] = true},  -- Crystalized Horror, hydrolic, 34 int
	[97310] = {r = 33, [12] = true, [11] = true, [64] = true, [65] = true},	-- Purified Imperial Amethyst, red, blue, 5 int, 10 spi
	[97311] = {r = 33, [13] = true, [70] = true},	-- Quick Sun's Radiance, yellow, 20 haste
	[97312] = {r = 33, [13] = true, [11] = true, [70] = true, [65] = true},	-- Energized Wild Jade, yellow, blue, 10 haste, 10 spi
	[97313] = {r = 33, [12] = true, [64] = true},	-- Brilliant Primordial Ruby, red, 10 int

	[97534] = {r = 34, [14] = true, [64] = true},	-- Burning Primal Diamond, meta, 15 int, 3% increased crit effect
	[97535] = {r = 33, [13] = true, [66] = true},	-- Mystic Sun's Radiance, yellow, 20 pvpres
	[97536] = {r = 33, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Imperial Amethyst, red, blue, 5 int, 10 pvppow
	[97537] = {r = 33, [11] = true, [82] = true},	-- Stormy River's Heart, blue, 20 pvppow
	[97538] = {r = 32, [12] = true, [13] = true, [64] = true, [66] = true},	-- Perfect Willful Tiger Opal, red, yellow, 5 int, 10 pvpresil

	[97547] = {r = 33, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Imperial Amethyst, red, blue, 5 int, 10 pvppow

	[97937] = {r = 34, [14] = true, [64] = true},	-- Burning Primal Diamond, meta, 12 int, 3% increased crit effect
	[97938] = {r = 33, [13] = true, [66] = true},	-- Mystic Sun's Radiance, yellow, 16 pvpres
	[97939] = {r = 33, [12] = true, [11] = true, [64] = true, [82] = true},	-- Mysterious Imperial Amethyst, red, blue, 5 int, 8 pvppow

	[97941] = {r = 33, [11] = true, [82] = true},	-- Stormy River's Heart, blue, 16 pvppow
	
	[97943] = {r = 32, [12] = true, [13] = true, [64] = true, [66] = true},	-- Perfect Willful Tiger Opal, red, yellow, 4 int, 8 pvpresil

-- clones added before 5.4 - source / reason unknown

	[98025] = {r = 33, [101] = true, [203] = true, [13] = true, [11] = true, [72] = true, [71] = true},	-- Piercing Wild Jade, yellow, blue, 8 crit, 8 hit
	[98026] = {r = 33, [101] = true, [202] = true, [13] = true, [72] = true},	-- Smooth Sun's Radiance, yellow, 16 crit
	[98027] = {r = 33, [101] = true, [202] = true, [13] = true, [72] = true, [84] = true},	-- Smooth Sun's Radiance, yellow, 8 expert, 8 crit  ? wrong name for these stats 2013/06/12
	[98028] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [72] = true},	-- Crafty Vermilion Onyx, red, yellow, 8 expert, 8 crit
	[98051] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [64] = true, [72] = true},	-- Potent Vermilion Onyx, red, yellow, 4 int, 8 crit
	[98056] = {r = 37, [16] = true, [64] = true},  -- Crystalized Horror, hydrolic, 20 int
	[98088] = {r = 33, [101] = true, [202] = true, [13] = true, [85] = true},	-- Fractured Sun's Radiance, yellow, 16 mastery
	[98089] = {r = 33, [101] = true, [204] = true, [12] = true, [13] = true, [84] = true, [85] = true},	-- Keen Vermilion Onyx, red, yellow, 8 expert, 8 mastery
	[98090] = {r = 33, [101] = true, [200] = true, [11] = true, [71] = true},	-- Rigid River's Heart, blue, 16 hit
	[98094] = {r = 33, [12] = true, [64] = true},	-- Brilliant Primordial Ruby, red, 8 int

	
	]]



--1142 when 5.2 goes live (2013/03/05)

--1112 now on ptr - lost a few.. ?  (2013/04/12)
-- ptr filter after patch 5.2.0 = 19  (2013/04/12)

}