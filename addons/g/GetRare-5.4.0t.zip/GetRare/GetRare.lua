local Version = "5.4.0t"

--[[ saved variables:
	GetRareConfig = global configuration-settings
		int x,y,width,lineHt
		int syncs
		Bool locked,name1,all,fixed,map,tom,alert,sts,RA,RS,hermit,chkclk,wordy
		str alarm,alarm2-4
		int alertx,alerty
	GetRare_[UNIT_ID id] = global settings per rare
		str alarm
		str name
		Bool ignore
	GetRare[str realm][UNIT_ID id] = data per realm per rare
		TIMESTAMP t	timestamp of last kill or live sighting, or of a meaningful dead sighting
		Bool alive	nil=killed, NO=seen dead, 1=alive
		int x,y		observer's coords*100; change to mob's when Blizz fix their vignette-bug

     unsaved data:
	R_[UNIT_ID id] = global constants per rare
		int x,y		rare's coords*100
		QUEST_ID d,f	quest-id for completion on d=day f=firstever
		ACHIEVE_NDX tc,bb
		str name,fullname
		FRAME crosshair
	R[UNIT_ID id] = home-realm data per rare
		TIME lastBroadcast
		TIME announced
		str announcedBy
		str authority		player responsible for most recent GetRare-update
		str authaddon		.. and his addon
		int(0-100) hp 		rounded hp% (currently rounded down to conform with RC)
		real(0-1) randomizer	random element so we don't all transmit at the same time
		bool RCcontention	an RC-user is transmitting, so switch to 10%-rounded hp
		TOMTOM_ID tom
	Addon[RC/RA/RS/GR] = data per addon catered for
		str version		version tested for
		str chan		chat channel-name that it uses
		str prefix		AddonMessagePrefix, if any
		str sync		sync-command
		----------		static fields above, dynamic fields below
		Bool registered		whether we have successfully executed a RegisterAddonMessagePrefix(Addon.xx.prefix)
		int chano		chat-channel number
		str owner		chat-channel owner
		set.str members		chat-channel members
--]]

local R45="random 30..60mins"

local S		--GetRareConfig
local SR_  	--GetRare_
local SR	--GetRare
local R		--as above
local R_ = {
        [73279]= {q= 1,              d=33313,f=33289,tc=29      ,name="Evermaw", r=R45},
        [73281]= {q= 2,x=26.2,y=22.8,d=33314,f=33290,tc=30,bb=32,name="Dread Ship Vazuvius", short="Dread Ship", r="shrine spawns with Evermaw"},
        [72045]= {q= 3,x=25.3,y=35.8,d=32966,f=33318,tc= 8,bb=10,name="Chelon", r=R45},
        [73158]= {q= 4,              d=33295,f=33261,tc= 1,bb=39,name="Emerald Gander", r="rare spawn of Brilliant Windfeather"},
        [73163]= {q= 5,              d=33303,f=33278,tc=18,bb=53,name="Imperial Python", r="rare spawn of Death Adder"},
        [73161]= {q= 6,              d=33297,f=33272,tc= 3,bb=10,name="Great Turtle Furyshell", short="Furyshell", r="rare spawn of Great Turtle"},
        [73166]= {q= 7,              d=33302,f=33277,tc=17,bb=49,name="Monstrous Spineclaw", short="Monstr Spineclaw", r="rare spawn of Ancient Spineclaw"},
        [73160]= {q= 8,              d=33296,f=33270,tc= 2,      name="Ironfur Steelhorn", r="rare spawn of Ironfur cluster"},
        [72769]= {q= 9,x=44,  y=41,  d=33293,f=33259,tc=12,bb=22,name="Spirit of Jadefire", r=R45},
        [73157]= {q=10,x=41.5,y=34  ,d=33307,f=33283,tc=20,bb=19,name="Rock Moss", r=R45},
--	[70323]= {q=11,x=47  ,y=55  ,				 name="Krakkanon"},
        [72808]= {q=12,x=54  ,y=42  ,d=33304,f=33279,tc=16,bb=42,name="Tsavo'ka", r=R45},
        [71864]= {q=13,x=59.5,y=49  ,d=32960,        tc= 9,bb=18,name="Spelurk", r=R45}, --f?
        [72970]= {q=14,x=62  ,y=63.7,d=33315,f=33291,tc=28,bb=44,name="Golganarr", r="random 2..26hr (approx)"},
        [72775]= {q=15,              d=33301,f=33276,tc=14,bb=48,name="Bufo", r=R45},
        [73704]= {q=16,x=71.4,y=82.9,d=33305,f=33280,tc=19,      name="Stinkbraid", r=R45},
        [72048]= {q=17,x=59.5,y=87.5,d=32964,	     tc=11,bb=17,name="Rattleskew", r="random 1..2hr (approx)"}, --f? (d is bugged atm)
        [72245]= {q=18,x=47.3,y=88  ,d=33316,f=32997,tc= 5,bb=26,name="Zesqua", r=R45},
        [72193]= {q=19,x=34  ,y=86  ,d=33292,f=33258,tc= 7,bb= 3,name="Karkanos", r=R45},
        [71919]= {q=20,x=37.5,y=77.5,d=32959,f=33317,tc= 6,bb=50,name="Zhu-Gon the Sour", short="Beer boss", r=R45},
        [72909]= {q=21,              d=33294,f=33260,tc= 4,bb=35,name="Gu'chi the Swarmbringer", short="Gu'chi", r=R45},
        [72049]= {q=22,x=44  ,y=70  ,d=32967,f=33319,tc=10,bb=42,name="Cranegnasher", r=R45},
        [73169]= {q=23,x=53.3,y=83.1,d=33306,f=33281,tc=22,bb=14,name="Jakur of Ordon", short="Jakur", r=R45},
        [73170]= {q=24,x=57.5,y=77  ,d=33322,f=33321,tc=21,bb=24,name="Watcher Osu", r=R45},
        [73167]= {q=25,              d=33311,f=33287,tc=27,bb=41,name="Huolon", r=R45},
        [73277]= {q=26,x=67.3,y=44.2,d=33298,f=33273,tc=13,bb=57,name="Leafmender", r=R45},
        [73171]= {q=27,              d=33299,f=33274,tc=23,bb=27,name="Champion of the Black Flame", short="Champs", r=R45},
        [73175]= {q=28,x=54.2,y=52.9,d=33310,f=33286,tc=24,bb=28,name="Cinderfall", r=R45},
        [73172]= {q=29,              d=33309,f=33285,tc=26,bb=29,name="Flintlord Gairan", r=R45},
        [73173]= {q=30,x=45.4,y=26.6,d=33308,f=33284,tc=25,bb=23,name="Urdur the Cauterizer", short="Urdur", r=R45},
        [73282]= {q=31,x=64.5,y=28.5,d=33300,f=33275,tc=15,bb=55,name="Garnia", r=R45},
        [73666]= {q=32,              d=33312,f=33288,tc=31,bb= 6,name="Archiereus of Flame", short="Archie (Terrace)", r="when summoned"},
        [73174]= {q=33,                              	   bb= 6,name="Archiereus of Flame", short="Archie (Sanctuary)"},
--      [71826]= {q=34,x=47.5,y=73.5,d=32961,f=33257      ,bb=54,name="Spritewood"},
--      [71908]= {q=35,x=37.4,y=77.4,                            name="Skunky Brew Alemental", short="Beer", r=R45},
--      [72032]= {q=36,x=61  ,y=88  ,				 name="Captain Zvezdan", short="Rattleskew inc"},
--      [72151]= {q=37,		     				 name="Fin Longpaw", short="Karkanos inc"},
}
local RARE_CNT=0
local RARE_MIN
for id in pairs(R_) do
	RARE_CNT = RARE_CNT+1
	if not RARE_MIN or RARE_MIN > id then
		RARE_MIN = id
	end
end

local LocalName = {}
LocalName.deDE = {
	[71919] = "Zhu-Gon der Saure",
	[72048] = "Klapperknochen",
	[72049] = "Kranichknirscher",
	[72769] = "Jadefeuergeist",
	[73157] = "Steinmoos",
	[73158] = "Smaragdkranich",
	[73160] = "Eisenfellstahlhorn",
	[73161] = "Großschildkröte Zornpanzer",
	[73163] = "Kaiserpython",
	[73166] = "Monströse Dornzange",
	[73169] = "Jakur von Ordos",
	[73170] = "Behüter Osu",
	[73171] = "Champion der Schwarzen Flamme",
	[73172] = "Funkenlord Gairan",
	[73173] = "Urdur der Kauterisierer",
	[73174] = "Archiereus der Flamme (Heiligtum)",
	[73175] = "Glutfall",
	[73277] = "Blattheiler",
	[73279] = "Tiefenschlund",
	[73281] = "Schreckensschiff Vazuvius",
	[73666] = "Archiereus der Flamme (Beschworen)",
	[73704] = "Stinkezopf",
}
LocalName.ruRU = {
        [71864] = "Чароброд",
        [71919] = "Чжу-Гонь Прокисший",
        [72045] = "Шелон",
        [72048] = "Косохрип",
        [72049] = "Журавлецап",
        [72193] = "Карканос",
        [72245] = "Зесква",
        [72769] = "Дух Нефритового Пламени",
        [72775] = "Буфо",
        [72808] = "Тсаво'ка",
        [72909] = "Гу'чи Зовущий Рой",
        [72970] = "Голганарр",
        [73157] = "Пещерный Мох",
        [73158] = "Изумрудный гусак",
        [73160] = "Твердорогий сталемех",
	[73161] = "Большая черепаха Гневный Панцирь",
        [73163] = "Императорский питон",
        [73166] = "Огромный хребтохват",
	[73167] = "Холон",
        [73169] = "Якур Ордосский",
        [73170] = "Смотритель Осу",
        [73171] = "Защитник Черного Пламени",
        [73172] = "Повелитель кремня Гайран",
        [73173] = "Урдур Прижигатель",
        [73174] = "Архиерей пламени (святилище)",
        [73175] = "Пеплопад",
        [73277] = "Целитель листвы",
        [73279] = "Вечножор",
        [73281] = "Проклятый корабль Вазувий",
        [73282] = "Гарния",
        [73666] = "Архиерей пламени (вызванный)",
        [73704] = "Вонекос",
}

local Addon = {
	RC = {version="5.4.1-4", chan="RCELVA", prefix="RCELVA", sync="GetStatus"},	-- RareCoordinator
	RA = {version="5.4.1.3A",chan="RAREAN", prefix="RAREAN", sync="Sync"},		-- RareAnnouncer
	RS = {version="1.7",	 chan="dantuprareshare"},				-- RareShare
	GR = {version=Version,	 chan="GetRare",prefix="RCELVA", sync="GetStatus"}	-- GetRare
}

local ALARMS = {
	[[Sound/Interface/PVPFlagTakenMono.wav]],
	[[Sound/Interface/AlarmClockWarning2.ogg]],
	[[Sound/Interface/AlarmClockWarning3.ogg]],
	[[Sound/Creature/MANDOKIR/VO_ZG2_MANDOKIR_LEVELUP_EVENT_01.ogg]],	--duuurrrhhh
	[[Sound/interface/ReadyCheck.wav]],
	[[Sound/Interface/PVPWarningHordeMono.wav]],
	[[Sound/Creature/Tong/VO_54_TONG_LEGENDARY_EPILOGUE_01.OGG]],
	[[Sound/Creature/SiegecrafterBlackfuse/VO_54_SIEGECRAFTER_BLACKFUSE_WoundCrit_05.OGG]],
	[[Sound/SPELLS/YarrrrImpact.ogg]],
	[[Sound/Creature/ShaOfPride/VO_54_SHA_OF_PRIDE_WoundCrit_05.OGG]],
	[[Sound/character/BloodElf/BloodElfFemaleRaspberry01.ogg]],
	[[Sound/Creature/BabyMurloc/BabyMurlocA.wav]],
	[[Sound/Creature/Xaril/VO_54_XARIL_Attack_08.OGG]],
	[[Sound/SPELLS/Ulduar_Hodir_FlashFreeze.ogg]],
	[[Sound/Creature/Meathook/CS_Meathook_Spawn.wav]],
	[[Sound/Interface/UI_51_BrawlersGuild_Loss_Horde.OGG]],
	[[Sound/Creature/Illidan/BLACK_Illidan_04.wav]],			--you are not prepared
	[[Sound/Creature/YoggSaron/UR_YoggSaron_Slay01.wav]],
	[[Sound/Creature/WarmasterBlackhorn/VO_DS_Blackhorn_Spell_02.ogg]],
}

local CONFIG_ALARMS = {
	"a rare (default alarm)",
	"a rare not killed today",
	"a rare never killed",
	"a rare needed for drop"
}

local FONT_HT = 10		--standard font-height for FrameFontNormalSmall
local MENU_HT = 16
local CHECKBOX_HT = 24		--standard line-height to accommodate a check-box

local YES = true
local NO = false

local WHITE=	"|cffffffff"
local YELLOW=	"|cffffff00"
local GREEN=	"|cff00ff00"
local BLUE=	"|cff0000ff"
local LIGHTBLUE="|cff00ccff"
local BLACK=	"|cff000000"
local PURPLE=	"|cff800080"
local RED=	"|cffff0000"
local LIGHTRED=	"|cffff6060"
local INDIANRED="|cffcd5c5c"
local AMBER=	"|cffff880f"
local ORANGE=	"|cffffa500"

local TIMELESS_ISLE = 951
local KILLED=nil
local DEAD=NO
local ALIVE=1

local ConnectedRealms = {


	{"Aegwynn", "Bonechewer", "Daggerspine", "Gurubashi", "Hakkar"},
		{"Agamaggan", "Archimonde", "Burning Legion", "Jaedenar", "The Underbog"},
	{"Aggramar", "Fizzcrank"},
	{"Akama", "Dragonmaw", "Mug'thol"},
	{"Alexstrasza", "Terokkar"},
	{"Alleria", "Khadgar"},
	{"Altar of Storms", "Anetheron", "Magtheridon", "Ysondre"},
	{"Alterac Mountains", "Balnazzar", "Gorgonnash", "The Forgotten Coast", "Warsong"},
	{"Andorhal", "Scilla", "Ursin", "Zuluhed"},
	{"Antonidas", "Uldum"},
	{"Anub�arak", "Chromaggus", "Chrushridge", "Garithos", "Nathrezim", "Smolderthorn"},
	{"Anvilmar", "Undermine"},
	{"Arygos", "Llane"},
	{"Auchindoun", "Cho'gall", "Laughing Skull"},
	{"Azgalor", "Azshara", "Destromath", "Thunderlord"},
	{"Azjol-Nerub", "Khaz Modan"},
	{"Azuremyst", "Staghelm"},
	{"Black Dragonflight", "Gul'dan", "Skullcrusher"},
	{"Blackhand", "Galakrond"},
	{"Blackwater Raiders", "Shadow Council"},
	{"Blackwing Lair", "Dethecus", "Detheroc", "Haomarush", "Lethon", "Shadowmoon"},
	{"Bladefist", "Kul Tiras"},
	{"Blade's Edge", "Thunderhorn"},
	{"Blood Furnace", "Mannaroth", "Nazjatar"},
	{"Bloodscalp", "Boulderfist", "Dunemaul", "Maiev", "Stonemaul"},
	{"Borean Tundra", "Shadowsong "},
	{"Bronzebeard", "Shandris"},
	{"Burning Blade", "Lightning's Blade", "Onyxia"},
	{"Cairne", "Perenolde"},
		{"Cenarion Circle", "Sisters of Elune"},
		{"Coilfang", "Dark Iron", "Dalvengyr", "Demon Soul", "Shattered Hand"},
	{"Darrowmere", "Windrunner"},
	{"Dath'Remar", "Khaz'goroth"},
	{"Dawnbringer", "Madoran"},
	{"Deathwing", "Executus", "Kalecgos", "Shattered Halls"},
	{"Dentarg", "Whisperwind"},
	{"Doomhammer", "Baelgun"},
	{"Draenor", "Echo Isles"},
	{"Draka", "Suramar"},
	{"Drak�Tharon", "Firetree", "Malorne", "Rivendare", "Spirestone", "Stormscale"},
	{"Drak'thul", "Skywall"},
	{"Dreadmaul", "Thaurissan"},
	{"Drenden", "Arathor"},
	{"Duskwood", "Bloodhoof"},
	{"Eitrigg", "Shu'halo"},
	{"Eldre�Thalas", "Korialstrasz"},
	{"Eonar", "Velen"},
	{"Eredar", "Gorefiend", "Spinebreaker", "Wildhammer"},
	{"Exodar", "Medivh"},
	{"Farstriders", "Silver Hand", "Thorium Brotherhood"},
	{"Fenris", "Dragonblight"},
	{"Frostmane", "Ner'zhul", "Tortheldrin"},
	{"Frostwolf", "Vashj"},
	{"Ghostlands", "Kael'thas"},
	{"Gilneas", "Elune"},
	{"Gnomeregan", "Moonrunner"},
	{"Grizzly Hills", "Lothar"},
	{"Gundrak", "Jubei'Thos"},
	{"Hellscream", "Zangarmarsh"},
	{"Hydraxis", "Terenas"},
	{"Icecrown", "Malygos"},
	{"Kargath", "Norgannon"},
	{"Kilrogg", "Winterhoof"},
	{"Kirin Tor", "Sentinels", "Steamwheedle Cartel"},
		{"Lightninghoof", "Maelstrom", "The Venture Co"},
	{"Malfurion", "Trollbane"},
	{"Misha", "Rexxar"},
	{"Mok'Nathal", "Silvermoon"},
	{"Nagrand", "Caelestrasz"},
	{"Nazgrel", "Nesingwary", "Vek'nilash"},
	{"Nordrassil", "Muradin"},
	{"Quel'dorei", "Sen'jin"},
	{"Ravenholdt", "Twisting Nether"},
	{"Runetotem", "Uther"},
	{"Scarlet Crusade", "Feathermoon"},
	{"Tanaris", "Greymane"},
	{"The Scryers", "Argent Dawn"},
	{"Uldaman", "Ravencrest"},
	{"Ysera", "Durotan"},
}

----------------------------------------

local Event = {}	--events
local E,D,C,L,T,M,W	--frames for events, display-list, configuration, lock-bar, alert, minimap, world-map

local MyLocale		--"enUS" etc
local MyLocaleFont	--STANDARD_TEXT_FONT
local MyName		--my name, without realm-suffix
local MyRealm		--my home realm
local MyRealm1		--the first (in alphabetical order) realm connected to mine, or nil if none is connected

local Dtiny		--whether main display D is minimized
local Configuring	--nil or 1..#CONFIG_ALARMS(global configuration) or id of rare being configured
local Tid		--id of unit displayed by T (If not T:IsShown() then nil Tid -> closed by system, so OK for system to reinstate)
local EntryTid		--Tid on entry to CONFIGURE

	--current realm
local GenChat		--channel number of chat-channel "General" (not always 1)
local Line		--Line[i] = id displayed
local ArrowTo		--(if S.map) nil or id being pointed at
local Carb		--(if Carbonite) ditto

----------------------------------------
local NULL = {}
local function null(t,k)
	if next(NULL) ~= nil then
		for kk,v in pairs(NULL) do
			if S.sts == 2 then print("Ugh!",kk,"=",v) end
			v = nil
		end
	end
	return NULL
end

local function must(a,i)
	if not rawget(a,i) then rawset(a,i,{}) end
	return a[i]
end

local function round(r)
	return tonumber(string.format("%.0f", r))
end

local function roundRC(r)
	return floor(r)
end

local function round10(i)
	return floor(i/10)*10
end

local function periodColour(secs)
	local m = secs/60
	return m < 25 and WHITE
	or m < 60 and ORANGE
	or LIGHTBLUE
end

local function period(secs)
	if abs(secs) < 99 then
		return ("%d"):format(secs), "sec"
	end
	local m = secs/60
	if abs(m) < 99 then
		return ("%.0f"):format(m), "minutes"
	end
	local h = m/60
	if abs(h) < 10 then
		return ("%i:%.2i"):format(floor(h), m % 60), "hr"
	elseif abs(h) < 99 then
		return ("%.0f"):format(h), "hr"
	end
	local d = h/24
	if abs(d) < 99 then
		return ("%.0f"):format(d), "days"
	end
	local m = d/30
	return ("%.0f"):format(m), "Months"
end

local function period2(secs)
	local fs = secs > 0 and "slow" or "fast"
	local s = abs(secs)
	if s < 60 then
		return ("%ds %s"):format(s,fs)
	end
	local m = floor(s/60)
	s = s % 60
	if m < 60 then
		return ("%d:%.2dmin %s"):format(m,s,fs)
	end
	local h = floor(m/60)
	m = m % 60
	if h < 24 then
		return ("%i:%.2i:%.2ihr %s"):format(h,m,s,fs)
	end
	local d = h/24
	h = h % 24
	return ("%idays %i:%.2i:%.2ihr %s"):format(d,h,m,s,fs)
end

local function subtractSet (A, B)	--A := A - B
	if A and B then
		for a in pairs(A) do
			if B[a] then A[a] = nil end
		end
	end
end

----------------------------------------
local ZERO=0x26
local BASE=0x7b-ZERO	--base 85
local BACKSLASH=0x5c	--skip since "\n" is dynamite

local function btoB(i,n)	--convert integer <i> to a n-digit (or variable-length if no n) little-endian string of base <BASE>
	local function wot(i,n)
		if (n or i) > 0 then
			local c = i % BASE
			return	c < BACKSLASH-ZERO and c+ZERO or c+(ZERO+1),
				wot(floor(i/BASE), n and n-1)
		end
	end
	return strchar(wot(i,n))
end

local function Btob(s,n,m)	--convert little-endian string s[n..m] (default 1..#s) in base <BASE> to integer <i>
	local function wot(c,...)
		return c and ((c < BACKSLASH and c-ZERO or c-(ZERO+1)) + BASE*wot(...)) or 0
	end
	return wot(strbyte(s, n or 1, m or -1))
end

----------------------------------------

local function myname(s)
	return	s == MyName or
		s == MyName.."-"..MyRealm	--yes, this can happen
end

local function myXY0()
	local x,y = GetPlayerMapPosition ("Player")
	return	x and tonumber(("%.0f"):format(x*100)) or 0,
		y and tonumber(("%.0f"):format(y*100)) or 0
end

local function unit_ID(unit)
	local id_hex = UnitGUID(unit)	--0xAABCCCCCDDEEEEEE, where B=3 for an NPC, CCCCC=id, EEEEEE=spawn counter
	if not id_hex then return nil end
	return tonumber(id_hex:sub(6, 10), 16), id_hex
end

local function warn(s)
	PlaySound("RaidWarning")
	RaidNotice_AddMessage(RaidWarningFrame, s, ChatTypeInfo.RAID_WARNING)
end

local function prt(...)
	if S.sts then print(...) end
end

local function prt2(...)	--of interest mainly to developers
	if S.sts == 2 then print(...) end
end

local mobName_tt, mobName_tl, mobName_tr
local function mobName(id)
	if not mobName_tt then
		mobName_tt = CreateFrame("GameTooltip")
		mobName_tl = mobName_tt:CreateFontString()
		mobName_tr = mobName_tt:CreateFontString()
		mobName_tt:AddFontStrings(mobName_tl, mobName_tr)
	end
	mobName_tt:SetOwner(UIParent)
	mobName_tt:SetHyperlink(("unit:0xf53%05x00000000"):format(id))
	if mobName_tt:IsShown() then
		return mobName_tl:GetText()
	end
end

----------------------------------------

local function obs(id)
	local sr = SR[id]
	if not sr.t then return YES end
	if sr.alive then	--whether live-sighting is more than 7 minutes old
		return sr.t + 7*60 < time()
	else			--whether dead-sighting is more than 2 hours old, or longer for Golganarr
		return sr.t + (id == 72970 and 30*60*60 or 2*60*60) < time()
	end
end

local function recent(id)	--whether last sighting is within the past 2 hours, or longer for Golganarr
	local sr = SR[id]
	return sr.t and sr.t + (id == 72970 and 30*60*60 or 2*60*60) > time()
end

local function dead_or_dubious(id)	--either virgin or dead or sighted more than 7 minutes ago
	local sr = SR[id]
	return	not sr.t or
		not sr.alive or
		sr.t + 7*60 < time()
end

local function getXY(id)
	local sr = SR[id]
	if sr.x and sr.y then
		return sr.x, sr.y
	else
		local r_ = R_[id]
		if r_.x and r_.y then
			return r_.x, r_.y
		end
	end
end

----------------------------------------

local ARROW = [[Interface/Minimap/Vehicle-SilvershardMines-Arrow]]

local InZone = NO	--whether on TI
local ZoneIndex		--my current zone
local Zwidth		--its width in yards
local Zheight		--its height in yards

local sin = math.sin	--use radians, not degrees
local cos = math.cos
local atan2 = math.atan2
local pi = math.pi

local function refreshM()
	local x,y = getXY(ArrowTo)
	if not x then return NO end

	local x0,y0 = GetPlayerMapPosition("player")
	local dx =  (x/100-x0)*Zwidth
	local dy = -(y/100-y0)*Zheight		--adjust to positive = upwards of us
	local dist = sqrt(dx*dx + dy*dy)	--Pythagoras
	M.dist:SetText((WHITE.."%.0f|ryd"):format(dist))

	local a = atan2(dx,-dy) + pi	 	--adjust to positive angle anticlockwise from North
	if GetCVar("RotateMinimap") == "1" then
		a = a - GetPlayerFacing()	--negative is fine
		dx = -dist * sin(a)		--new Cartesian coords relative to rotated minimap
		dy = dist * cos(a)
	end

	do					--position at edge of minimap
		local width = Minimap:GetWidth()
		local r = width/2 - 16		--deduct half the width of the arrow
		local scale = dist/r
		M:SetPoint("CENTER", dx/scale, dy/scale)
		M.arrow:SetAlpha(dist>20 and 1 or dist/20)	--fade arrow as target reaches minimap
	end
	do					--spin arrow around (gratias Ro@Hyjal)
		local c = cos(a+pi/4)/sqrt(2)	--constant-folding
		local s = sin(a+pi/4)/sqrt(2)
		M.arrow:SetTexCoord(
			.5-c, .5-s,
			.5-s, .5+c,
			.5+s, .5-c,
			.5+c, .5+s
		)
	end

--		dist > 480 and 1,0,0,1 or	-- could change colour as get closer
--		dist > 280 and 1, (480-dist)/200, 0, 1 or
--		dist > 80  and (280-dist)/200, 1, 0, 1 or
--			   0, 1, 0, (80-dist)/80
	return YES
end

local function startM(id)
	if not M then
		M = CreateFrame("Frame", nil, Minimap)
		M:SetSize(30,30)

	 	M.arrow = M:CreateTexture()
		M.arrow:SetTexture(ARROW)
		M.arrow:SetAllPoints()

		M.who = M:CreateFontString (nil, "OVERLAY", "GameFontNormalSmall")
		M.who:SetPoint ("BOTTOMLEFT", Minimap, 126, -14)

		M.dist = M:CreateFontString (nil, "OVERLAY", "GameFontNormalSmall")
		M.dist:SetPoint ("BOTTOMLEFT", Minimap, 126, -3)

		M.tooltip = CreateFrame("GameTooltip", "GetRareArrowTooltip", nil, "GameTooltipTemplate")
	        M:SetScript("OnEnter", function()
			M.tooltip:SetOwner(M, "ANCHOR_TOPRIGHT")
			M.tooltip:SetText(M.dist:GetText().." - "..M.who:GetText())
			M.tooltip:Show()
		end)
	        M:SetScript("OnLeave", function() M.tooltip:Hide() end)

		local mm_elapsed = 0
		M:SetScript("OnUpdate", function(self,elapsed)	--per frame that M IsShown
			mm_elapsed = mm_elapsed + elapsed
			if mm_elapsed > .25 then
				mm_elapsed = 0
				refreshM()
			end
		end)
		M:Hide()
	end
	if not ArrowTo then
		M.who:SetText(R_[id].short or R_[id].name)
		ArrowTo = id
		if refreshM() then
			M:Show()
		else
			ArrowTo = nil
		end
	end
end

local function stopM(id)
	if id == ArrowTo then
		if M then M:Hide() end
		ArrowTo = nil
	end
end

local function updateTom(id,add)
	if TomTom then
		local r = R[id]
		if r.tom then
			TomTom:RemoveWaypoint(r.tom)
			r.tom = nil
		end
		if add then
			local x,y = getXY(id)
			if x then
				R(id).tom = TomTom:AddWaypoint(x, y, SR[id].name or R_[id].short or R_[id].name)
			end
		end
	end
	if Nx and Nx.Map then
		if add then
			local x,y = getXY(id)
			if x then
				local map = Nx.Map:GetMap(1)
				map:SetTargetAtStr(("%.0f %.0f"):format(x,y))
				Carb = id
			end
		elseif Carb then
			local map = Nx.Map:GetMap(1)
			map:Menu_OnClearGoto()
			Carb = nil
		end
	end
end

local function showArrow(id)
	if S.map then startM(id) end
	if S.tom then updateTom(id,YES) end
end

local function hideArrow(id)
	if S.map then stopM(id) end
	if S.tom then updateTom(id,NO) end
end

local function toggleArrow(id)
	if S.map then
		if ArrowTo == id then
			stopM(id)
		else
			stopM(ArrowTo)
			startM(id)
		end
	end
	if S.tom then
		updateTom(id, not R[id].tom)
	end
end

----------------------------------------

local function hideIcon(id)
	local r_ = R_[id]
	if r_.crosshair and r_.crosshair:IsShown() then
		r_.crosshair:Hide()
	end
end

local function showIcon(id,x,y,r,g,b)
	if SR_[id].ignore then return end
	local r_ = R_[id]
	if not r_.crosshair then
		local ch = CreateFrame("Frame", nil, W)
		ch:SetSize(150, 150)
		ch.tooltip = CreateFrame("GameTooltip", "GetRareMapTip"..id, nil, "GameTooltipTemplate")
	        ch:SetScript("OnEnter", function()
			ch.tooltip:SetOwner(ch, "ANCHOR_TOPRIGHT")
			ch.tooltip:SetText(r_.short or r_.name)
			ch.tooltip:Show()
		end)
	        ch:SetScript("OnLeave", function() ch.tooltip:Hide() end)

		ch.model = CreateFrame("PlayerModel", nil, ch)
		ch.model:SetAllPoints()
		ch.model:SetCreature(id)
		ch.model:SetFrameLevel(ch.model:GetFrameLevel()-1)
		ch.model:SetAlpha(0.4)

		ch.h = ch:CreateTexture()
		ch.w = ch:CreateTexture()
		local width_crosshair = 2
		ch.w:SetSize(40, width_crosshair)
		ch.h:SetSize(width_crosshair, 40)
		ch.w:SetPoint("CENTER")
		ch.h:SetPoint("CENTER")

		r_.crosshair = ch
	end
	local dx,dy = W:GetSize()
	r_.crosshair:SetPoint("CENTER", W, "TOPLEFT", x*dx, -y*dy)
	r_.crosshair.w:SetTexture(r,g,b,1)
	r_.crosshair.h:SetTexture(r,g,b,1)
	r_.crosshair:Show()
end

local function refreshW()
	for id,r_ in pairs(R_) do
		local sr = SR[id]
		if dead_or_dubious(id) then
			if id == ArrowTo then
				local x = r_.x and r_.x/100 or sr.x and sr.x/100
				local y = r_.y and r_.y/100 or sr.y and sr.y/100
				if x and y then
					showIcon(id,x,y,1,0,0)
				end
			else
				hideIcon(id)
			end
		else
			local x = sr.x and sr.x/100 or r_.x and r_.x/100
			local y = sr.y and sr.y/100 or r_.y and r_.y/100
			if x and y then
				if id == ArrowTo then
					showIcon(id,x,y,1,1,1)
				else
					showIcon(id,x,y,0,1,0)
				end
			end
		end
	end
end

local function startW()
	if not W then
		W = CreateFrame("Frame", nil, WorldMapButton)
		W:SetAllPoints()

		local wm_elapsed = 0
		W:SetScript("OnUpdate", function(self,elapsed)	--per frame that WorldMap IsShown
			wm_elapsed = wm_elapsed - elapsed
			if wm_elapsed < 0 then
				wm_elapsed = 1
				refreshW()
			end
		end)
	end
	W:Show()
end

----------------------------------------

local function getLineno(id)
	for i = 1,#Line do
		if Line[i] == id then return i end
	end
end

local function sortLine()
--A purely time-based sort is better than giving priority to live rares.
--Not only is it simpler, but it quickly shows which live rares have an obsolescent hp%.
	Line = {}
	if Dtiny and not Configuring then return end

	local i = 1
	for id in pairs(R_) do
		if S.all
		or (Configuring and not S.locked)
		or (recent(id) and not SR_[id].ignore) then
			Line[i] = id
			i = i + 1
		end
	end

	sort(Line, function(a,b)
		if not S.fixed then
			local d = (SR[a].t or 0) - (SR[b].t or 0)
			if d < 0 then return YES elseif d > 0 then return NO end
		end
		return R_[a].q < R_[b].q
	end)
end

local function sanitizeDimensions()	--impose some sanity
	S.lineHt = max(8, S.lineHt)	--should be impossible, but still
	S.lineHt = min(20, S.lineHt)	--likewise
	S.width = max(100, S.width)
	S.width = min(300, S.width)
end

local function alignD()	--align D's internal fields at start or after resize or column-swapping of D
	sanitizeDimensions()
	if L then
		L:SetWidth(S.lineHt-2)
	end
	D.bg:SetHeight(D:GetHeight())
	D.max:SetSize(S.lineHt, S.lineHt-1)
	if S.name1 then
		D.max:SetPoint("TOPLEFT", 1, -1)
	else
		D.max:SetPoint("TOPRIGHT", -1, -1)
	end

	for i=0,RARE_CNT do
		D.but[i]:SetSize(S.width*.25, S.lineHt-1)
		if i == 0 then
			D.nam[i]:SetHeight(S.lineHt-1)
		else
			D.nam[i]:SetFont(MyLocaleFont, S.lineHt-3)
		end

		local y = -i*S.lineHt
		if S.name1 then
			D.but[i]:SetPoint("TOPRIGHT", 0, y-1)
			D.nam[i]:SetPoint("TOPRIGHT", D, "TOPLEFT", .75*S.width, i==0 and -1 or y-2)
		else
			D.but[i]:SetPoint("TOPLEFT", 0, y-1)
			D.nam[i]:SetPoint("TOPLEFT", D, "TOPRIGHT", -.75*S.width, i==0 and -1 or y-2)
		end
	end
end

local function refreshDbut(i)
	local id = Line[i]
	local sr = SR[id]
	if dead_or_dubious(id) then
		local secs = time() - sr.t
		local age, units = period(secs)
		D.but[i]:SetText (table.concat{
			sr.alive and GREEN or periodColour(secs),
			sr.alive == DEAD and ">" or "",
			age,
			#age < 4 and units:sub(1,1) or "",
			"|r"})
	else
		local r = R[id]
		D.but[i]:SetText (table.concat{
			GREEN,
			(not r.hp or r.hp == 0.5) and "alive" or r.hp.."%",
			"|r"})
	end
end

local function need_kill(id)
	local r_ = R_[id]
	if r_.tc then
		local _,_,completed = GetAchievementCriteriaInfo(8714, r_.tc)
		return not completed
	else
		return NO
	end
end

local function need_drop(id)
	local r_ = R_[id]
	if r_.bb then
		local _,_,completed = GetAchievementCriteriaInfo(8728, r_.bb)
		return not completed
	else
		return NO
	end
end

local function killed_today(id)
	local r_ = R_[id]
	return r_.d and IsQuestFlaggedCompleted(r_.d)
end

local RefreshD					--force a refreshD() within this many secs
local function refreshD()
	local n = Line and #Line or RARE_CNT	--save prior #Line, or LineCnt on first time
	sortLine()				--rebuild Line
	for i=1,RARE_CNT do
		if i <= #Line then
			local id = Line[i]
			if i > n then
				D.but[i]:Show()
				D.nam[i]:Show()
			end
			local flag =		--Orange bar=need drop
				(need_drop(id) and AMBER or GREEN).."|||r"
			D.nam[i]:SetText(	--Orange text=need kill, Blue text=killed today, else WHITE
				(S.name1 and "" or flag)..
				(killed_today(id) and LIGHTBLUE or need_kill(id) and YELLOW or WHITE)..
					(SR_[id].name or R_[id].short or R_[id].name)..
					"|r"..
				(S.name1 and flag or "")
			)
			if SR[id].t then
				refreshDbut(i)
			else
				D.but[i]:SetText("")
			end
		elseif i <= n then
			D.but[i]:Hide()
			D.nam[i]:Hide()
		else
			break
		end
	end
	if n ~= #Line then
		D.bg:SetHeight((1+#Line)*S.lineHt)
	end
end

----------------------------------------

local function playAlarm(alarm)
	local ok = PlaySoundFile(alarm, "Master")
	if not ok then
		warn("Sound-file not found")
	end
	return ok

end

local function aliveAgain (id, tim)
	R(id).announced = nil
	local sr_ = SR_[id]
	if sr_.ignore then return end

	local sr = SR[id]
	if sr.t then
		local r_ = R_[id]
		local age,units = period(tim-sr.t)
		prt (r_.short or r_.name,"alive after",age,units)
	end

	local alarm =
		sr_.alarm or
		need_drop(id) and S.alarm4 or
		need_kill(id) and S.alarm3 or
		not killed_today(id) and S.alarm2 or
		S.alarm
	if alarm and alarm ~= "" then
		playAlarm(alarm)
	end
end

local function extMarkAlive(id, hp, x, y, tim, authority, authaddon)
	local sr = SR(id)
	if not sr.t or tim > sr.t then	--must have a later timestamp to be worth looking at
		local dod = dead_or_dubious(id)
		if dod then
			if sr.t and tim - sr.t < 10 and hp < 50 then return end	--usually delayed alive-reports
			if tim > time() - 2*60 then	--else false alarm - probably synccing
				aliveAgain(id, tim)
			end
		end
		local r = R(id)
		local hp0 = r.hp	--original hp
		if not sr.alive
		or hp ~= 0.5 then	--leave hp alone if already marked alive and get a vague "alive" report
			sr.alive = ALIVE
			r.hp = hp
		end
		sr.t = tim
		r.authority = authority
		r.authaddon = authaddon
		local sr_ = SR_[id]
		if x and y then
			sr.x, sr.y = x,y
			--if not r_.x then
			if not sr_.ignore then
				showArrow(id)
			end
		end

		if sr_.ignore then return end
		local i = getLineno(id)
		if dod or not i then	--if we have to ..
			RefreshD=1	--..then display all
		elseif r.hp ~= hp0 then
			refreshDbut(i)	--..else go easy on screen-refresh
		end
	end
end

local function supersedes(yourstate, yourtime, mystate, mytime)	--whether your data dead/killed supersedes mine alive/dead/killed
	if not mytime then
		return YES
	elseif mystate == ALIVE then
		return yourtime >= mytime
	elseif mystate == DEAD then
		if yourstate == KILLED then
			return yourtime > mytime - 25*60
		elseif yourstate == DEAD then
			return	yourtime > mytime + 25*60 or
				yourtime > mytime - 25*60 and yourtime < mytime
		end
	elseif mystate == KILLED then
		if yourstate == KILLED then
			return yourtime > mytime + 120		--ignore natural fluctuations in time() of upto 2mins
		elseif yourstate == DEAD then
			return yourtime > mytime + 25*60	--regrettably I must reject some valid reports of a dead gander
		end
	end
end

local function extMarkDead(id, killed, tim, authority, authaddon)
	local sr = SR(id)
	local yourstate = DEAD
	if killed then
		yourstate = KILLED
	end
	if supersedes(yourstate, tim, sr.alive, sr.t) then
		if not SR_[id].ignore and sr.t and not sr.alive then
   			local age,units = period(tim-sr.t)
			if units:sub(1,1) == "m" then
				local r_ = R_[id]
				local agem = tonumber(age)
				prt (r_.short or r_.name,"had been",
					sr.alive == KILLED and "killed" or "dead",
					abs(agem), units,
					agem > 0 and "earlier" or "later")
			end
		end
		sr.t = tim
		sr.alive = yourstate
		local r = R(id)
		r.authority = authority
		r.authaddon = authaddon
		hideArrow(id)
		RefreshD=1
	end
end

----------------------------------------

local function normalizeTime(t, realtime)
	local now = time()
	return	realtime and now-1 or		--use my own clock for current data
		t < now+60 and min(t,now)	--and reject future times for sync data
end

local function RSnormalizeTime(t, realtime)	--RS data can lag by 30+ secs - so accept send-time, within reason
	local now = time()
	return	realtime and max(now-90,min(now-1,t)) or
		t < now+60 and min(t,now)	--and reject future times for sync data
end

----------------------------------------

local function checkClock(t, sender)
	local secs = time() - t
	local bad = abs(secs) > 2.5*60
	if bad and S.chkclk then
		print (sender,"'s PC-clock is",period2(secs))
	end
	return bad
end

local function GRdecode(msg, sender, realtime)
	local rectyp, s2, s3, s = strsplit("~",msg)
	local rare_min = Btob(s2)
	local now = Btob(s3)
	if not checkClock(now, sender) then return end
	for i = 1,#s,6 do
		local id = Btob(s,i,i+1) + rare_min
		if not R_[id] then
			prt2 ("Invalid rare-id",id)
			return NO
		end
		local t = normalizeTime (Btob(s,i+2,i+4) + now, realtime)
		local c = strsub(s,i+5,i+5)
		local alive = c == "^"
		if not alive then
			if c == ">" then alive = DEAD
			elseif c == "=" then alive = KILLED
			else
				prt2("Invalid alive-flag",c)
				return NO
			end
		end
		if t then
			if alive then
				extMarkAlive (id, 0.5, nil, nil, t, sender, "GR-sync")
			else
				extMarkDead (id, alive == KILLED, t, sender, "GR-sync")
			end
			if S.sts == 2 then
				print(	sender,rectyp,
					R_[id] and R_[id].name or id,
					period(time()-now),
					alive and "ALIVE" or alive==DEAD and "DEAD" or "KILLED")
			end
		end
	end
	return YES
end

local function GRencode()
	local now = time()
	local a = {"[gr]1~", btoB(RARE_MIN), "~", btoB(now), "~"}	--RC ignores any msg not containing "[RCELVA]"
	for id in pairs(R_) do
		if recent(id) then
			local sr = SR[id]
			if sr.t <= now then
				tinsert(a, btoB(id-RARE_MIN,2))
				tinsert(a, btoB(now-sr.t,3))
				tinsert(a,
					sr.alive and "^" or
					sr.alive == DEAD and ">" or "=")
			end
		end
	end
	return table.concat(a)
end

local function myClockBad()	--whether my PC-clock minute-hand conflicts with server-time
	local sh,sm = GetGameTime()
	local ltim = time()
	local ls = ltim % 60
	local lm = floor(ltim/60) % 60
	local dm = lm - sm
	if dm < -30 then
		dm = dm + 60
	elseif dm > 30 then
		dm = dm - 60
	end
	if abs(dm) > 1 then
		print (	YELLOW.."GR: Your PC minute-hand is",
			abs(dm), "min.",
			dm > 0 and "ahead of" or "behind", "server|r")
--		print (	YELLOW,
--			"PC-time:",format("xx:%.2i:%.2i",lm, ls),
--			"Server-time:", format("%i:%.2ihr",sh,sm),
--			"|r"
--		)
		return YES
	end
end

local GRsent			--whether we have done a one-off data-send
local receiptAdvised		--time of last advice of data-receipt
local receivedFrom = {}		--lua needs "own" variables
local function adviseReceipt(addon,sender)
	if not GRsent and Addon.RC.chano then
		if not myClockBad() then
			SendChatMessage(GRencode(), "CHANNEL", nil, Addon.RC.chano)
		end
		GRsent = YES
	end
	local tim = time()
	if not receivedFrom[sender]
	or not receiptAdvised or receiptAdvised < tim - 15 then
		if S.sts == 2 or S.sts == 1 and addon ~= "GR" then
			print ("GR: Receiving",addon,"data from",sender)
		end
		receivedFrom[sender] = YES
		receiptAdvised = tim
	end
end

----------------------------------------

local function RCencode(id, typ, tim)
	return strjoin("_",Addon.RC.version,id,typ,tim,"")
end

local function RCsend(id,typ)
	if Addon.RC.chano then
		SendChatMessage("[RCELVA]"..RCencode(id, typ, time()), "CHANNEL", nil, Addon.RC.chano)
	end
end

local function RCannounceMsg(msg)
	SendChatMessage(msg, "CHANNEL", nil, GenChat)
end

local function RCdecode(msg, sender, realtime)
	local s1,s2,s3,s4,s5 = strsplit("_",msg)
	if s5 ~= "" then
		prt2("GR-RC Bad msg2:",sender,msg)
		return
	end
	local version = s1
	local id = tonumber(s2)
	local typ = s3
	local tim = normalizeTime (tonumber(s4), realtime)
	if realtime and S.chkclk then checkClock (tonumber(s4), sender) end
	if not tim then return end

	if not R_[id] then
		prt2("GR-RC: Unknown Rare#",id)
		return
	end

	local r = R(id)
	r.lastBroadcast = tim
	r.RCcontention = YES
	if typ == "announce" then
		if not r.announced then
			r.announced = tim
			r.announcedBy = sender
		end
		return
	end

	if unit_ID("target") == id then	--prefer my own data, thanks
		return
	end

	local authaddon = realtime and "RC" or "RC-sync"
	if typ == "alive" then
		extMarkAlive (id, 0.5, nil, nil, tim, sender, authaddon)	--"alive": hp=0.5
	elseif typ:sub(1,5) == "alive" then
		if typ:find(",",1,YES) and typ:find("-",1,YES) then
			local hp_,x_,y_ = string.match(typ, "(%d+),(%d+)-(%d+)")
			extMarkAlive (id, tonumber(hp_), tonumber(x_), tonumber(y_), tim, sender, authaddon)
		else
			extMarkAlive (id, tonumber(typ:sub(6)), nil, nil, tim, sender, authaddon)
		end
	elseif typ == "killed" or typ == "dead" then
		extMarkDead (id, typ == "killed", tim, sender, authaddon)
	elseif typ ~= "seen" then
		prt2("GR: Unknown RC-type",typ,"received from",sender)
	end
end

local function RAdecode(msg, sender, realtime)
	if msg:sub(1,8) ~= "[RAREAN]" then
		prt2("GR-RA Bad msg:",sender,msg)
		return
	end
	local s1,s2,s3,s4 = ("_"):split(msg:sub(9))
	if not s3 or s4 then
		prt2("GR-RA Bad msg:",sender,msg)
		return
	end
	local id = tonumber(s1)
	local typ = s2
	local tim = normalizeTime (tonumber(s3), realtime)
	if not tim then return end

	if not R_[id] then
		prt2("GR: Unknown Rare#",id)
		return
	end

	if typ == "killannounced" or typ == "request" then return end

	if unit_ID("target") == id then		--prefer my own data, thanks
		return
	end

	if typ == "kill" or typ == "death" then
		extMarkDead (id, typ == "kill", tim, sender, realtime and "RA" or "RA-sync")
	else
		prt2("GR: Unknown RA-type",typ,"received from",sender)
	end
end

local function RSdecode(msg, sender, realtime)
	local s1,s2,s3,s4,s5,s6,s7,s8 = ("[^~]+"):split(msg)	--s2=rarename,s3=zonename
	if not s8 then
		prt2("GR-RS Bad msg:",sender,msg)
		return
	end
	local id = tonumber(s1)
	if not R_[id] then return end		--outside Timeless Isle
	if unit_ID("target") == id then		--prefer my own data, thanks
		return
	end
	local sr = SR[id]
	local typ = s4
	local tim = RSnormalizeTime (tonumber(s8), realtime)
	if not tim then return end

	local authaddon = realtime and "RS" or "RS-sync"
	if typ == "Alive" then
		local hp = tonumber(s5)
		local x = tonumber(s6)
		local y = tonumber(s7)
		if sr.alive then
			local r = R[id]
			if r.hp and hp >= r.hp then return end
		elseif sr.t then
			if tim < sr.t then return end
			if sr.t > time() - 90 then return end
		end
		--print("alive",id, hp, x, y, tim)
		extMarkAlive (id, hp, x, y, tim, sender, authaddon)
	elseif typ == "Dead" then
		if sr.t then
			if not sr.alive then
				if tim < sr.t then return end
				if sr.t > time() - 30 then return end
			end
		end
		--print("dead",id, tim)
		extMarkDead (id, YES, tim, sender, authaddon)
	else
		prt2("GR: Unknown RS-type",typ,"received from",sender)
	end
end

function Event.CHAT_MSG_CHANNEL(msg,sender,_,_,_,_,_,_,channelName)
	if myname(sender) then return end
	if strupper(channelName) == Addon.RC.chan then
		if msg:sub(1,8) == "[RCELVA]" then
			RCdecode(msg:sub(9), sender, YES)
		elseif msg:sub(1,4) == "[gr]" then
			if not S.hermit then
				adviseReceipt("GR", sender)
				GRdecode(msg:sub(5), sender, NO)
			end
		elseif msg:sub(1,4) == "[GR]" then
			SendChatMessage("Automated message: GetRare 5.4.0k corrupts data - PLEASE update it ASAP", "WHISPER", nil, sender)
			print (sender,"is running a version of GetRare known to corrupt timestamps. YOU HAVE AUTO-WARNED HIM.")
		else
			prt2("GR-RC Bad msg:", sender, msg)
		end
	elseif strupper(channelName) == Addon.RA.chan then
		RAdecode(msg, sender, YES)
	elseif strlower(channelName) == Addon.RS.chan then
		RSdecode(msg, sender, YES)
	end
end

----------------------------------------

local function markAlive (id, hp, tim)		--keep efficient since called so often
	local sr = SR(id)
	local r = R(id)
	local x,y = myXY0()

	local dod = dead_or_dubious(id)
	if dod then
		r.RCcontention = nil
		aliveAgain(id, tim)
	end

	local function send (similarHP, min, avg)
		if similarHP and r.lastBroadcast then
			if not sr.alive or not r.randomizer then r.randomizer = random() end
			if tim - r.lastBroadcast < min + avg * r.randomizer then return end
		end
		RCsend (id, "alive"..hp..","..x.."-"..y)
		if hp == 100 then
			RCsend (id, "seen")	--comply with RC protocol
		end
		r.lastBroadcast = tim
	end
	if hp == 100 then			--if on 100% health
		send (hp == r.hp, 20, 20)	--then send updates every 20-40 sec, or now if health has changed
	elseif not r.RCcontention then		--else send an update whenever there is a 10% change in health or it is more than 5-15 secs since the last update
		send (r.hp and floor(hp/10) == floor(r.hp/10), 5, 10)
	else					--but don't contend with RC's rounded figures
		local r10 = round10(hp)
		if not r.hp or r10 ~= round10(r.hp) then
			local save_hp = hp; hp = r10; send(NO); hp = save_hp
		end
	end

	local hp0 = r.hp	--original hp
	r.hp = hp
	sr.alive = ALIVE
	sr.t = tim
	sr.x, sr.y = x,y
	r.authority = "self"
	r.authaddon = "GR"

 	if SR_[id].ignore then return end
	local i = getLineno(id)
	if dod or not i then	--if we have to ..
		RefreshD=1	--..then display all
	elseif r.hp ~= hp0 then
		refreshDbut(i)	--..else go easy on screen-refresh
	end
end

local function markDead (id, killed, tim)
	local sr = SR(id)
	if sr.alive or not sr.t or tim > sr.t + 25*60 then	--if marked alive or last seen over 25 minutes ago
		if not SR_[id].ignore and sr.t and not sr.alive then
			local r_ = R_[id]
   			local age,units = period(tim-sr.t)
			prt (r_.short or r_.name, sr.alive == KILLED and "was killed" or "was dead", age, units, "ago")
		end
		sr.t = tim
		if killed then
			sr.alive = KILLED
		else
			sr.alive = DEAD
		end
		sr.x, sr.y = myXY0()
		local r = R(id)
		r.authority = "self"
		r.authaddon = "GR"
		hideArrow(id)
		RefreshD=1
		RCsend (id, killed and "killed" or "dead")
		RCsend (id, "seen")
	end
end

local function alert(id)
	if Tid == id then return end
	if InCombatLockdown() then return end	--don't Show() in combat
	if id <= #CONFIG_ALARMS then
		T.model:SetUnit("Player")
		T.name:SetText(MyName)
	else
		local r_ = R_[id]
		T.model:SetCreature(id)
		T.name:SetText(r_.name)
		local tar = "/targetExact "..r_.name
		T:SetAttribute("macrotext", "/cleartarget\n"..tar..'\n/run print"'..tar..'"')
	end
	Tid = id
	T:Show()
end

local function unalert(id)
	if Tid ~= id then return end
	if T:IsShown() then
		if InCombatLockdown() then
			function Event.PLAYER_REGEN_ENABLED()
				E:UnregisterEvent "PLAYER_REGEN_ENABLED"
				unalert(id)
			end
			E:RegisterEvent "PLAYER_REGEN_ENABLED"
			return
		end
		T:Hide()
	end
	Tid = nil			--allow for auto-reinstatement (e.g. for champs, temp out of range)
end

local function updUnit(unit, health_changed)
	local id = unit_ID(unit)
	if not id or not R_[id] then return end
	if unit == "target" then
		hideArrow(id)		--enough is enough
	end
	local hc = UnitHealth(unit)
	local tim = time()
	if hc == 0 then
		unalert(id)
		markDead (id, health_changed, tim)
	else
		if S.alert and not SR_[id].ignore then
			alert(id)
		end
		local hm = UnitHealthMax(unit)
		if not hm or hm == 0 then return end
		markAlive (id, hc == hm and 100 or roundRC(hc/hm * 100), tim)
	end
end

local last_call_UNIT_HEALTH = 0
function Event.UNIT_HEALTH(unit)	--Fired when a unit's health level changes (fires for target & focus, but not mouseover)
	local tim = time()
	if (tim - last_call_UNIT_HEALTH) < 1 then return end	--ignore more than once/sec
	last_call_UNIT_HEALTH = tim
	updUnit(unit, YES)
end

function Event.PLAYER_TARGET_CHANGED()
	updUnit("target", NO)
end

function Event.PLAYER_FOCUS_CHANGED()
	updUnit("focus", NO)
end

function Event.UPDATE_MOUSEOVER_UNIT()
	updUnit("mouseover", NO)
end

function Event.VIGNETTE_ADDED(instanceID)
	if not instanceID then
		return
	end
	local x, y, name, typ = C_Vignettes.GetVignetteInfoFromInstanceID(instanceID)
	--prt (instanceID.." - ("..(x or "nil")..","..(y or "nil")..") "..(name or "nil")..": "..(typ or "nil"))
	if typ ~= 40 and typ ~= 42 then
		warn (S.vignette or "vignette")
	end
end

function Event.VIGNETTE_REMOVED(instanceID)
	prt2 ("removed",instanceID)
end

function Event.COMBAT_LOG_EVENT_UNFILTERED(timeStamp,event,_,_,_,_,_,destGUID,_,_,_,_,x13)
	if event == "UNIT_DIED" then
		local id = tonumber(destGUID:sub(6, 10), 16)
		local r_ = R_[id]
		if not r_ then return end
		local sr = SR(id)
		sr.alive = KILLED
		sr.x, sr.y = myXY0()
		sr.t = time()		--logged timestamp is local time, so forget it
		hideArrow(id)
		RefreshD=1
		local r = R[id]
		if r.announcedBy == "self" then
			RCannounceMsg(table.concat{
				S.wordy and "[GetRare] " or "",
				"{rt8}",
				S.wordy and r_.name or r_.short or r_.name,
				" dead{rt8}"})
			r.announcedBy = nil
		end
		RCsend (id, "killed")
		RCsend (id, "dead")	--oh?
		unalert(id)		--always fails because don't go out of combat straight away
	elseif S.alert then
		local id = tonumber(destGUID:sub(6, 10), 16)
		if R_[id] and x13 ~= "Skinning" and not SR_[id].ignore then
			alert(id)
		end
	end
end

----------------------------------------

local function alignC()		--left/right-justify when enter Config and after dragging/resizing
	local x,y,dx,dy = D:GetRect()
	local leftOfCentre = x + dx/2 < GetScreenWidth() / 2
	C:ClearAllPoints()
	if leftOfCentre then
		C:SetPoint("TOPLEFT", S.locked and D or L, "TOPRIGHT")
	else
		C:SetPoint("TOPRIGHT", D, "TOPLEFT")
	end
end

local function startL()
	if not L then
		L = CreateFrame("Frame", nil, D)
		L:SetPoint("TOPLEFT", D, "TOPRIGHT")
		L:SetPoint("BOTTOMLEFT", D, "BOTTOMRIGHT")
		L:SetWidth(S.lineHt-2)
		L:EnableMouse(YES)
		L:SetScript("OnMouseDown", function(self)
			D:StartSizing("BOTTOMRIGHT")
		end)
		L:SetScript("OnMouseUp", function(self,button)
			D:StopMovingOrSizing()
		end)
		L.bg = L:CreateTexture()
		L.bg:SetAllPoints()
		L.bg:SetTexture(1,1,1,1)

		D:SetScript("OnSizeChanged", function(self,w,h)
			S.width = w
			S.lineHt = h/(1+#Line)
			alignD()
		end)

		D:SetScript("OnDragStart", D.StartMoving)
		D:SetScript("OnDragStop", function(self)
			self:StopMovingOrSizing()
			S.x = self:GetLeft()
			S.y = self:GetTop()
			alignC()
		end)

		T:SetScript("OnDragStart", T.StartMoving)
		T:SetScript("OnDragStop", function(self)
			self:StopMovingOrSizing()
			S.alertx = self:GetLeft()
			S.alerty = self:GetTop()
		end)
	else
		L:Show()
	end

	if not InCombatLockdown() then
		D:EnableMouse(YES)
	end
	D:SetMovable(YES)
	D:SetResizable(YES)
	D:RegisterForDrag("LeftButton")

	T:SetMovable(YES)
	T:RegisterForDrag("LeftButton")
end

local function stopL()
	L:Hide()

	if not InCombatLockdown() then D:EnableMouse(NO) end
	D:SetMovable(NO)
	D:SetResizable(NO)
	D:RegisterForDrag()

	T:SetMovable(NO)
	T:RegisterForDrag()
end

local function stopC()
	C:Hide()
	Configuring = nil

	if L and L:IsShown() then
		stopL()
		refreshD()
	end
	if EntryTid then
		alert(EntryTid)
	else
		if not InCombatLockdown() then T:Hide() end
		Tid = EntryTid
	end
end

local function expandAlarm(s)
	return	not s and "(default alarm)" or
		s == "" and "(silence)" or
		s
end

local function getAlarm(i)
	return
		i == 1 and expandAlarm(S.alarm) or
		i == 2 and expandAlarm(S.alarm2) or
		i == 3 and expandAlarm(S.alarm3) or
		i == 4 and expandAlarm(S.alarm4) or
		expandAlarm(SR_[i].alarm)
end

local function setAlarm(i, alarm)
	if i == 1 then
		S.alarm = alarm
	elseif i == 2 then
		S.alarm2 = alarm
	elseif i == 3 then
		S.alarm3 = alarm
	elseif i == 4 then
		S.alarm4 = alarm
	else
		SR_(i).alarm = alarm
	end
end

local function initSoundMenu()
	local function onClick(self,alarm)
		C.alarm:SetText(expandAlarm(alarm))
		if not alarm or alarm == "" or playAlarm(alarm) then
			setAlarm(Configuring, alarm)
		end
	end
	UIDropDownMenu_Initialize(C.alarm.menu, function()
		UIDropDownMenu_AddButton{text=expandAlarm(nil), arg1=nil, func=onClick}
		UIDropDownMenu_AddButton{text=expandAlarm(""), arg1="", func=onClick}
		for _,v in ipairs(ALARMS) do
			UIDropDownMenu_AddButton{text=v, arg1=v, func=onClick}
		end
		if S.alarms then
			for _,v in pairs(S.alarms) do
				UIDropDownMenu_AddButton{text=v, arg1=v, func=onClick}
			end
		end
	end)
end

local function addAlarm(alarm)
	for _,v in pairs(ALARMS) do
		if alarm == v then return end
	end
	if not S.alarms then
		S.alarms = {}
	end
	for _,v in pairs(S.alarms) do
		if alarm == v then return end
	end
	S.alarms[#S.alarms+1] = alarm
	initSoundMenu()		--can't append to menu - have to rebuild from scratch
end

local function addifOK()
	local alarm = C.alarm:GetText()
	if playAlarm(alarm) then
		setAlarm(Configuring, alarm)
		addAlarm(alarm)
	end
end

local function strSyncs(i)
	return i == -1 and "All" or tostring(i)
end

local function configure(id)
	Configuring = id
	alert(id)
	C.alarm:SetText(getAlarm(id) or "")
	if id <= #CONFIG_ALARMS then
		C.rare:SetText (LIGHTBLUE.."To select a rare, mouseover its button|r")
		UIDropDownMenu_SetText(C.alarmingMenu, CONFIG_ALARMS[id])

		C.name:SetText("")
		C.ignore:SetChecked(nil)
		C.rare1:SetText("")
		C.rare2:SetText("")
		C.rare3:SetText("")
		C.rare4:SetText("")
		return
	end

	local r_ = R_[id]
	C.rare:SetText(table.concat{LIGHTBLUE,"#",id," ",WHITE,r_.name,"|r"})
	UIDropDownMenu_SetText(C.alarmingMenu, r_.short or r_.name)

	if r_.bb then
		local d = GetAchievementCriteriaInfo(8728, r_.bb)
--		local _,link = GetItemInfo(d)	--only works if item in bag
--		if link then
--			C.rare1:SetText(link)
--		else
			local colour = need_drop(id) and AMBER or GREEN
--			C.rare1:SetText(table.concat{LIGHTBLUE,#d <= 32 and "Drops " or "",colour,d,"|r"})
			C.rare1:SetText(table.concat{YELLOW,"Drop ",colour,d,"|r"})
--		end
	else
		C.rare1:SetText("")
	end

	C.rare2:SetText(r_.r and table.concat{YELLOW, "Respawn ", LIGHTBLUE, r_.r, "|r"} or "")

	local sr_ = SR_[id]
	C.name:SetText (sr_.name or r_.short or "")
	C.ignore:SetChecked(sr_.ignore)

	local r = R[id]
	local sr = SR[id]
	local state =
		not sr.t and "" or
		sr.alive and GREEN.."Seen alive " or
		LIGHTBLUE..(sr.alive == KILLED and "Killed " or "Seen dead ")
	local ago = ""
	if sr.t then
		local age,units = period(time()-sr.t)
		ago = table.concat{WHITE,age," ",units," ago","|r"}
	end
	local locn = sr.x and sr.y
		and table.concat{LIGHTBLUE," @ ",sr.x,",",sr.y}
		or ""
	C.rare3:SetText(table.concat{state,ago,locn})
	C.rare4:SetText(r.authority and table.concat{YELLOW,"Source ", LIGHTBLUE, "[",r.authaddon,"] ",r.authority,"|r"} or "")
end

local function initC()
	C = CreateFrame("Frame", nil, D)
	local w = 500
	C:SetSize(w, 12*CHECKBOX_HT)

	C.bg = C:CreateTexture()
	C.bg:SetAllPoints()
	C.bg:SetTexture(0,0,0,0.5)

	C.hdr = C:CreateFontString(nil, nil, "GameFontNormal")
	C.hdr:SetPoint("TOP", 0, -7)
	C.hdr:SetPoint("CENTER")
	C.hdr:SetText(LIGHTBLUE.."GetRare Configuration|r")

	C.cls = CreateFrame("Button", nil, C, "UIPanelCloseButton")
	C.cls:SetPoint("TOPRIGHT")
	C.cls:SetSize(2*MENU_HT, 2*MENU_HT)
	C.cls:SetScript("OnClick", function()
		stopC()
	end)

	C.locked = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.locked:SetPoint("TOPLEFT", 0, -CHECKBOX_HT)
	C.locked:SetScript("OnClick", function()
		S.locked = C.locked:GetChecked()
		if S.locked then stopL() else startL() end
		refreshD()	--shrink/extend according to S.locked
		alignC()	--shift right/left according to S.locked
	end)
	C.locked.tooltip = "Lock windows against being dragged or resized"
	C.locked.txt = C.locked:CreateFontString(nil, nil, "GameFontNormal")
	C.locked.txt:SetPoint("LEFT", C.locked, "RIGHT")
	C.locked.txt:SetText("Disable dragging & resizing")

	C.name1 = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.name1:SetPoint("TOPLEFT", w/2, -CHECKBOX_HT)
	C.name1:SetScript("OnClick", function()
		S.name1 = C.name1:GetChecked()
		D.max:ClearAllPoints()
		for i=0,RARE_CNT do
			D.but[i]:ClearAllPoints()
			D.nam[i]:ClearAllPoints()
		end
		alignD()
		refreshD()
	end)
	C.name1.tooltip = "Swap time & name columns"
	C.name1.txt = C.name1:CreateFontString(nil, nil, "GameFontNormal")
	C.name1.txt:SetPoint("LEFT", C.name1, "RIGHT")
	C.name1.txt:SetText("Locate name to left of time")

	C.wordy = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.wordy:SetPoint("TOPLEFT", 0, -2*CHECKBOX_HT)
	C.wordy:SetScript("OnClick", function()
		S.wordy = C.wordy:GetChecked()
	end)
	C.wordy.tooltip = "Whether to announce the full name of a rare instead of the short name, e.g. 'Zhu-Gon the Sour' instead of 'Beer Boss'"
	C.wordy.txt = C.wordy:CreateFontString(nil, nil, "GameFontNormal")
	C.wordy.txt:SetPoint("LEFT", C.wordy, "RIGHT")
	C.wordy.txt:SetText("Announce name in full")

	C.fixed = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.fixed:SetPoint("TOPLEFT", w/2, -2*CHECKBOX_HT)
	C.fixed:SetScript("OnClick", function()
		S.fixed = C.fixed:GetChecked()
		refreshD()
	end)
	C.fixed.txt = C.fixed:CreateFontString(nil, nil, "GameFontNormal")
	C.fixed.txt:SetPoint("LEFT", C.fixed, "RIGHT")
	C.fixed.txt:SetText("Sort by circuit, not time")

	C.map = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.map:SetPoint("TOPLEFT", 0, -3*CHECKBOX_HT)
	C.map:SetScript("OnClick", function()
		S.map = C.map:GetChecked()
		if S.map then
			startW()
		else
			if M then M:Hide() end
			if W then W:Hide() end
		end
	end)
	C.map.tooltip = "Track live rares on map & minimap (you can right-click button to toggle waypoint manually)"
	C.map.txt = C.map:CreateFontString(nil, nil, "GameFontNormal")
	C.map.txt:SetPoint("LEFT", C.map, "RIGHT")
	C.map.txt:SetText("Track live rares on map")

	C.tom = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.tom:SetPoint("TOPLEFT", w/2, -3*CHECKBOX_HT)
	C.tom:SetScript("OnClick", function()
		S.tom = C.tom:GetChecked()
		if not S.tom then
			for id,r in pairs(R) do
				if r.tom then updateTom(id,NO) end
			end
		end
	end)
	C.tom.tooltip = "Track live rares on map & minimap using TomTom or Carbonite (you can right-click button to toggle waypoint manually)"
	C.tom.txt = C.tom:CreateFontString(nil, nil, "GameFontNormal")
	C.tom.txt:SetPoint("LEFT", C.tom, "RIGHT")
	C.tom.txt:SetText("Track with TomTom/Carbonite")

	C.alert = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.alert:SetPoint("TOPLEFT", 0, -4*CHECKBOX_HT)
	C.alert:SetScript("OnClick", function()
		S.alert = C.alert:GetChecked()
	end)
	C.alert.txt = C.alert:CreateFontString(nil, nil, "GameFontNormal")
	C.alert.txt:SetPoint("LEFT", C.alert, "RIGHT")
	C.alert.txt:SetText("Show alert when near a rare")

	C.sts = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.sts:SetPoint("TOPLEFT", w/2, -4*CHECKBOX_HT)
	C.sts:SetScript("OnClick", function()
		S.sts = C.sts:GetChecked()
	end)
	C.sts.tooltip = "Display detailed status-messages in the chat-window"
	C.sts.txt = C.sts:CreateFontString(nil, nil, "GameFontNormal")
	C.sts.txt:SetPoint("LEFT", C.sts, "RIGHT")
	C.sts.txt:SetText("Show status messages")

	C.alarmingtxt = C:CreateFontString(nil, nil, "GameFontNormal")
	C.alarmingtxt:SetPoint("TOPLEFT", 24, -6-5*CHECKBOX_HT)
	--C.alarmingtxt:SetText("Sound alarm on a reported sighting of")
	C.alarmingtxt:SetText("Alarm for")

	C.alarmingMenu = CreateFrame("Frame", "GetRareAlarmingMenu", C, "UIDropDownMenuTemplate")
	C.alarmingMenu:SetPoint("LEFT", C.alarmingtxt, "RIGHT", -18, 0)
	UIDropDownMenu_SetWidth(C.alarmingMenu, 140)
	local function onClick(self,i)
		configure(i)
	end
	UIDropDownMenu_Initialize(C.alarmingMenu, function()
		for i,v in ipairs(CONFIG_ALARMS) do
			UIDropDownMenu_AddButton{text=v, arg1=i, func=onClick}
		end
		for id,r_ in pairs(R_) do
			UIDropDownMenu_AddButton{text=r_.short or r_.name, arg1=id, func=onClick}
		end
	end)

	C.test = CreateFrame("Button", nil, C, "UIPanelButtonTemplate")
	C.test:SetPoint("TOP", C.alarmingMenu, "TOP")
	C.test:SetPoint("RIGHT", -2, 0)
	C.test:SetNormalFontObject("GameFontNormal")
	C.test:SetText("Test")
	C.test.tooltipText="Play the sound"
	C.test:SetSize(50, CHECKBOX_HT)
	C.test:RegisterForClicks("LeftButtonUp")
	C.test:SetScript("OnClick", addifOK)	--save in case this is clicked instead of hitting Enter

 	C.alarm = CreateFrame("EditBox", "C.alarm", C)
	C.alarm:SetSize(w-47, MENU_HT)
	C.alarm:SetPoint("TOPLEFT", 9, -6*CHECKBOX_HT)
	C.alarm:SetBlinkSpeed(0)
	C.alarm:SetMaxLetters(150)
	C.alarm:SetFontObject("GameFontNormalSmall")
	C.alarm:SetTextColor(1,1,1)
	C.alarm:SetScript("OnEnterPressed", addifOK)
	C.alarm:SetScript("OnTabPressed", function(self)
		if Configuring > #CONFIG_ALARMS then
			C.name:SetFocus()
		end
	end)
	C.alarm:SetScript("OnSpacePressed", function(self)
		--StopMusic()		--*sigh* PlayMusic() won't work for me
		self:SetText("")
	end)
	C.alarm:SetScript("OnEscapePressed", function(self)
		stopC()
	end)

	C.alarm.menu = CreateFrame("Frame", "GetRareAlarmMenu", C, "UIDropDownMenuTemplate")
	C.alarm.menu:SetPoint("TOPLEFT", -15, 6-6*CHECKBOX_HT)
	UIDropDownMenu_SetWidth(C.alarm.menu, w-22)
	initSoundMenu()
	C.alarm:SetFrameLevel(1+C.alarm.menu:GetFrameLevel())

	C.raref = CreateFrame("Frame", nil, C)
	C.raref:SetPoint("TOPLEFT",2,5-7*CHECKBOX_HT)
	C.raref:SetPoint("BOTTOMRIGHT", C, "TOPLEFT",w-2,-9*CHECKBOX_HT)
	C.raref:SetBackdrop{
		edgeFile=[[Interface/ChatFrame/ChatFrameBackground]],
		edgeSize= 1,
	}
	C.raref:SetBackdropBorderColor(1,1,0,1)

	C.rare = C:CreateFontString(nil, nil, "GameFontNormal")
	C.rare:SetPoint("TOPLEFT", 7, 1-7*CHECKBOX_HT)

	C.nametxt = C:CreateFontString(nil, nil, "GameFontNormal")
	C.nametxt:SetPoint("TOPLEFT", 7, 9-8*CHECKBOX_HT)
	C.nametxt:SetText("Short name ")
 	C.name = CreateFrame("EditBox", nil, C)
	C.name:SetSize(144, CHECKBOX_HT)
	C.name:SetPoint("LEFT", C.nametxt, "RIGHT")
	C.name:SetBlinkSpeed(0)
	C.name:SetMaxLetters(20)
	C.name:SetFontObject("GameFontNormal")
	C.name:SetTextColor(1,1,1)
	C.name:SetScript("OnEnterPressed", function(self)
		if Configuring <= #CONFIG_ALARMS then warn("No rare selected") return end
		local name = self:GetText()
		SR_(Configuring).name = name ~= "" and name or nil
		self:ClearFocus()
		refreshD()
	end)
	C.name:SetScript("OnTabPressed", function(self)
		C.alarm:SetFocus()
	end)
	C.name:SetScript("OnEscapePressed", function(self)
		stopC()
	end)

	C.ignore = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.ignore:SetPoint("TOPLEFT", 0, -8*CHECKBOX_HT)
	C.ignore:SetScript("OnClick", function()
		if Configuring <= #CONFIG_ALARMS then warn("No rare selected") return end
		SR_(Configuring).ignore = C.ignore:GetChecked()
		refreshD()
	end)
	C.ignore.txt = C.ignore:CreateFontString(nil, nil, "GameFontNormal")
	C.ignore.txt:SetPoint("LEFT", C.ignore, "RIGHT")
	C.ignore.txt:SetText("Ignore this rare")

	C.rare1 = C:CreateFontString(nil, nil, "GameFontNormalSmall")
	C.rare1:SetPoint("TOPLEFT", 3+w/2, 1-7*CHECKBOX_HT)

	C.rare2 = C:CreateFontString(nil, nil, "GameFontNormalSmall")
	C.rare2:SetPoint("TOPLEFT", 3+w/2, -10-7*CHECKBOX_HT)

	C.rare3 = C:CreateFontString(nil, nil, "GameFontNormalSmall")
	C.rare3:SetPoint("TOPLEFT", 3+w/2, -21-7*CHECKBOX_HT)

	C.rare4 = C:CreateFontString(nil, nil, "GameFontNormalSmall")
	C.rare4:SetPoint("TOPLEFT", 3+w/2, -32-7*CHECKBOX_HT)


	C.syncs = CreateFrame("Frame", "GetRareSyncMenu", C, "UIDropDownMenuTemplate")
	C.syncs:SetPoint("TOPLEFT", w/2-15, 1-9*CHECKBOX_HT)
	UIDropDownMenu_SetWidth(C.syncs, 30)
	local function onClick(self,i)
		S.syncs = i
		--UIDropDownMenu_SetText(C.syncs, strSyncs(i))
		C.syncs.txt0:SetText(strSyncs(i))
		--goSync?
	end
	UIDropDownMenu_Initialize(C.syncs, function()
		local tip = "Number of users per addon (including RareCoordinator and GetRare) to sync with on entry to the Isle"
		for _,i in ipairs{0,1,2,3,4,-1} do
			UIDropDownMenu_AddButton{
				text = strSyncs(i),
				arg1 = i,
				checked = i == S.syncs,
				func = onClick,
				tooltipText = tip}
		end
	end)

	C.syncs.txt0 = C.syncs:CreateFontString(nil, nil, "GameFontNormal")
	C.syncs.txt0:SetPoint("LEFT", 24, 3)
	C.syncs.txt0:SetText(strSyncs(S.syncs))

	C.syncs.txt1 = C.syncs:CreateFontString(nil, nil, "GameFontNormal")
	C.syncs.txt1:SetPoint("RIGHT", C.syncs, "LEFT", 16, 3)
	C.syncs.txt1:SetText("On entry to Isle, sync with")

	C.syncs.txt2 = C.syncs:CreateFontString(nil, nil, "GameFontNormal")
	C.syncs.txt2:SetPoint("LEFT", C.syncs, "RIGHT", -14, 3)
	C.syncs.txt2:SetText("users per addon")

	C.RA = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.RA:SetPoint("TOPLEFT", 0, -10*CHECKBOX_HT)
	C.RA:SetScript("OnClick", function()
		S.RA = C.RA:GetChecked()
	end)
	C.RA.tooltip = "Join the RareAnnouncer Channel - RAREAN"
	C.RA.txt = C.RA:CreateFontString(nil, nil, "GameFontNormal")
	C.RA.txt:SetPoint("LEFT", C.RA, "RIGHT")
	C.RA.txt:SetText("Eavesdrop on RareAnnouncer")

	C.RS = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.RS:SetPoint("TOPLEFT", w/2, -10*CHECKBOX_HT)
	C.RS:SetScript("OnClick", function()
		S.RS = C.RS:GetChecked()
	end)
	C.RS.tooltip = "Join the RareShare Channel - dantuprareshare"
	C.RS.txt = C.RS:CreateFontString(nil, nil, "GameFontNormal")
	C.RS.txt:SetPoint("LEFT", C.RS, "RIGHT")
	C.RS.txt:SetText("Eavesdrop on RareShare")

	C.hermit = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.hermit:SetPoint("TOPLEFT", 0, -11*CHECKBOX_HT)
	C.hermit:SetScript("OnClick", function()
		S.hermit = C.hermit:GetChecked()
	end)
	C.hermit.tooltip = "Whether to ignore data-updates from GetRare users logging in"
	C.hermit.txt = C.hermit:CreateFontString(nil, nil, "GameFontNormal")
	C.hermit.txt:SetPoint("LEFT", C.hermit, "RIGHT")
	C.hermit.txt:SetText("Decline dynamic sync")

	C.chkclk = CreateFrame("CheckButton", nil, C, "ChatConfigCheckButtonTemplate")
	C.chkclk:SetPoint("TOPLEFT", w/2, -11*CHECKBOX_HT)
	C.chkclk:SetScript("OnClick", function()
		S.chkclk = C.chkclk:GetChecked()
	end)
	C.chkclk.tooltip = "Tell me whose PC clock is more than 2 minutes slow/fast"
	C.chkclk.txt = C.chkclk:CreateFontString(nil, nil, "GameFontNormal")
	C.chkclk.txt:SetPoint("LEFT", C.chkclk, "RIGHT")
	C.chkclk.txt:SetText("Monitor bad clocks")

	C.zap = CreateFrame("Button", nil, C, "UIPanelButtonTemplate")
	C.zap:SetPoint("LEFT", C.chkclk.txt, "RIGHT", 3, 2)
	C.zap:SetNormalFontObject("GameFontNormal")
	C.zap:SetText("Zap timers")
	C.zap.tooltipText="Clear all timers and reconnect"
	C.zap:SetWidth(80)
	C.zap:RegisterForClicks("LeftButtonUp")
	C.zap:SetScript("OnClick", Event.zap)
end

local function startC()
	if C then C:Show() else initC() end
	C.wordy:SetChecked(S.wordy)
	C.name1:SetChecked(S.name1)
	C.fixed:SetChecked(S.fixed)
	C.map:SetChecked(S.map)
	C.tom:SetChecked(S.tom)
	C.alert:SetChecked(S.alert)
	C.sts:SetChecked(S.sts)
	C.RA:SetChecked(S.RA)
	C.RS:SetChecked(S.RS)
	C.hermit:SetChecked(S.hermit)
	C.chkclk:SetChecked(S.chkclk)
end

----------------------------------------

local function state(id)
	local sr = SR[id]
	if not sr.t then
		return nil, "Nothing to announce"
	end
	local r_ = R_[id]
	local name = S.wordy and r_.name or r_.short or r_.name
	if dead_or_dubious(id) then
		local age, units = period(time()-sr.t)
		return NO, table.concat{
			S.wordy and "[GetRare] " or "",
			name, " - ",
			sr.alive and "seen alive " or
			sr.alive == KILLED and "killed " or
				"seen dead ",
			age, " ", units, " ago"}
	else
		local r = R[id]
		if r.hp == 0.5 then
			return nil, table.concat{name, " - health unknown"}
		end
		local function ann_at(...)
			return YES, table.concat{
				S.wordy and "[GetRare] " or "",
				"{rt1}", name,
				sr.alive and r.hp and (" "..r.hp.."%") or "",
				"{rt1} ",
				...}
		end
		if r_.x then
			return ann_at(r_.x, ", ", r_.y)
		elseif unit_ID("target") == id then
			local x,y = myXY0()
			return ann_at("seen from ", x, ",", y)
		else
			return nil, "To announce coordinates, please target "..name
		end
	end
end

local function announce(id)
	local alive, msg = state(id)
	if alive == nil then warn(msg) return end
	RCannounceMsg(msg)
	if alive then
		RCsend (id, "announce")
		local r = R(id)
		if r.announced then
			local age,units = period(time()-r.announced)
			print ("GR: Announced by",r.announcedBy,age,units,"ago")
		else
			r.announced = time()
			r.announcedBy = "self"
		end
	end
end

local function prt_achv()
	--for i=1,GetAchievementNumCriteria(8714) do
	--	_, _, completed, _, _, _, _,id = GetAchievementCriteriaInfo(8714,i)
	--	prt ((not id and "no id" or not R_[id] and id or R_[id].short or R_[id].name)..(completed and " Y" or " N"))
	--end
	for i=1,GetAchievementNumCriteria(8714) do
		prt(GetAchievementCriteriaInfo(8714,i))
	end
	for i=1,GetAchievementNumCriteria(8728) do
		prt(GetAchievementCriteriaInfo(8728,i))
	end
end

local function initD()
	D = CreateFrame("Frame", nil, UIParent)
	D:SetFrameStrata("BACKGROUND")
	D:SetClampedToScreen(YES)
	D:SetMinResize(100, (1+RARE_CNT)*10)
	D:SetMaxResize(300, (1+RARE_CNT)*20)
	D:SetSize(S.width, (1+RARE_CNT)*S.lineHt)
	if S.x and S.y then
		D:SetPoint ("TOPLEFT", UIParent, "BOTTOMLEFT", S.x, S.y)
	else
		D:SetPoint("CENTER")
	end

	D.bg = D:CreateTexture()
	D.bg:SetPoint("TOPLEFT")
	D.bg:SetPoint("TOPRIGHT")
	D.bg:SetTexture(0,0,0,0.333)

	D.nam = {}
	D.but = {}

	D.but[0] = CreateFrame("Button", nil, D, "UIPanelButtonTemplate")
	D.but[0]:SetNormalFontObject("GameFontNormal")
	D.but[0]:SetText(S.all and "v" or "^")
	D.but[0].tooltipText="Toggle all/recent rares"	--button too small to register?
	D.but[0]:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	D.but[0]:SetScript("OnClick", function(self,button)
		if button == "LeftButton" then
			S.all = not S.all
			D.but[0]:SetText(S.all and "v" or "^")
			refreshD()
		elseif button == "RightButton" then
			prt_achv()
		end
	end)
	D.but[0]:SetScript("OnEnter", function()
		if Configuring then
			configure(1)
		end
	end)

	D.nam[0] = CreateFrame("Button", nil, D, "UIPanelButtonTemplate")
	D.nam[0]:SetNormalFontObject("GameFontNormalSmall")
	D.nam[0]:SetText("CONFIGURE")
--	D.nam[0].tooltipText="Click to change preferences"
	D.nam[0]:SetWidth(80)
	D.nam[0]:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	D.nam[0]:SetScript("OnClick", function()
		if Configuring then stopC() return end
		--if InCombatLockdown() then warn("In combat") return end
		EntryTid = T:IsShown() and Tid
		startC()
		configure(1)
		if not S.locked then
			startL()
			refreshD()
		end
		alignC()
	end)

	for i = 1,RARE_CNT do
		D.but[i] = CreateFrame("Button", nil, D, "UIPanelButtonTemplate")
		D.but[i]:SetNormalFontObject("GameFontNormal")
		D.but[i]:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
		D.but[i]:SetScript("OnClick", function(self,button)
			local id = Line[i]
			if button == "LeftButton" then
				announce(id)
			elseif button == "RightButton" then
				local alive,msg = state(id)
				if alive ~= nil then print(msg) end
				local r_ = R_[id]
				if r_.bb then
					local d = GetAchievementCriteriaInfo(8728, r_.bb)
					local _,link = GetItemInfo(d)	--only works if item in bag
					prt ("Drops",link or d)
				end
				toggleArrow(id)
			--elseif button == "MiddleButton" then
				--local msg = GRencode()
				--prt2(msg)
				--GRdecode(strsub(msg,5))
			end
		end)

		D.but[i]:SetScript("OnEnter", function()
			if Configuring then
				configure(Line[i])
			end
		end)

		D.nam[i] = D:CreateFontString(nil, nil, "GameFontNormalSmall")
		D.nam[i]:SetTextColor(1,1,1)	--default colour white
	end

	D.max = CreateFrame("Button", nil, D, "UIPanelButtonTemplate")
	D.max:SetNormalFontObject("GameFontNormal")
	D.max:RegisterForClicks("LeftButtonUp")
	D.max:SetText("[x]")
	D.max:SetScript("OnClick", function(self,button)
		Dtiny = not Dtiny
		D.max:SetText(Dtiny and "[+]" or "[x]")
		refreshD()
	end)
end

local function initT()
	T = CreateFrame("Button", nil, D, "SecureActionButtonTemplate")	--error if in combat when executed
	T:SetClampedToScreen(YES)
	T:SetSize(150,164)
	T:SetAttribute("type", "macro")
	if S.alertx and S.alerty then
		T:SetPoint ("TOPLEFT", UIParent, "BOTTOMLEFT", S.alertx, S.alerty)
	else
		T:SetPoint("TOPLEFT", D, "BOTTOMLEFT")
	end
	T:SetScript("OnEnter", function() T.bg:SetAlpha(1) end)
 	T:SetScript("OnLeave", function() T.bg:SetAlpha(0.4) end)

	T.bg = T:CreateTexture()
	T.bg:SetAllPoints()
	T.bg:SetTexture(0,0,0,0.4)

	T.model = CreateFrame("PlayerModel", nil, T)
	T.model:SetSize(150,150)
	T.model:SetPoint("TOPLEFT")
	T.model:SetFrameLevel(T.model:GetFrameLevel()-1)	--needed for Dread Ship

	T.name = T:CreateFontString(nil, nil, "GameFontNormalSmall")
	T.name:SetPoint("BOTTOM", 0, 2)
	T.name:SetFont(MyLocaleFont, FONT_HT)
	T.name:SetTextColor(1,1,1)

	local cls = CreateFrame("Button", nil, T, "UIPanelCloseButton")
	cls:SetPoint("TOPRIGHT")
	cls:SetSize(30,30)
	cls:SetAttribute("_onclick", "self:GetParent():Hide()")

	T:Hide()
end

----------------------------------------

local function registerAddon(prefix,advise)	--allow addon-sent messages with this prefix to be received by me
	local ok = RegisterAddonMessagePrefix(prefix)
	if not ok and advise then print("GR: Unable to RegisterAddonMessagePrefix",prefix) end
	return ok
end

local function senda (ar, msg, target)
	if not ar.registered then
		ar.registered = registerAddon(ar.prefix, NO)	--just in case original attempt never worked
	end
	SendAddonMessage (ar.prefix, msg, "WHISPER", target)	--send even if can't receive
end

local function goSync(a)
	local ar = Addon[a]
	if not ar.prefix or not ar.members then return end
	local count = 0
	local function poll(player)
		if myname(player) or IsIgnored(player) then
			return YES
		else
			prt("GR: Polling",a,player,"...")
			senda (ar, ar.sync, player)
			count = count + 1
			return S.syncs == -1 or count < S.syncs
		end
	end
	if ar.members[ar.owner] then
		if not poll(ar.owner) then return end		--ignore owner if imposter
	end
	for player in pairs(ar.members) do
		if player ~= ar.owner then
			if not poll(player) then return end
		end
	end
end

function Event.CHAT_MSG_ADDON(prefix, msg, typ, sender)	--I have received a <msg> from <sender>
	if typ ~= "WHISPER" then return end
	if prefix == Addon.RC.chan then
		if msg == Addon.RC.sync then		--he wants a data-update from me
			prt2 ("GR: Sending RC-data to",sender)
			for id in pairs(R_) do
				if recent(id) then
					local sr = SR[id]
					senda (
						Addon.RC,
						RCencode(id, "seen", sr.t),
						sender)
					senda (
						Addon.RC,
						RCencode(id,
							sr.alive and "alive" or
							sr.alive == DEAD and "dead" or
								"killed",
							sr.t),
						sender)
				end
			end
		else					--else I have received an update from him
			adviseReceipt("RC", sender)
			RCdecode(msg, sender, NO)
		end
	elseif prefix == Addon.RA.chan then		--could remove this since RA does a GetStatus anyway on RCELVA
		if msg == Addon.RA.sync then		--he wants a data-update from me
			prt2 ("GR: Sending RA-data to",sender)
			for id in pairs(R_) do
				if recent(id) then
					local sr = SR[id]
					if sr.alive == KILLED then
						senda (Addon.RA, ("_"):join("[RAREAN]"..id, "death", sr.t), sender)
						--prt(sender, ("_"):join("[RAREAN]"..id, "death", sr.t))
					end
				end
			end
		else					--else I have received an update from him
			adviseReceipt("RA", sender)
			RAdecode(msg, sender, NO)
		end
	end
end

----------------------------------------
local Thread		--current thread
local SecsToResume	--force resume when negative

local function resume(...)
	E:SetScript("OnUpdate", nil)
	coroutine.resume(Thread,...)
end

local function timeout(self,elapsed)
	SecsToResume = SecsToResume - elapsed
	if SecsToResume < 0 then resume() end
end

local function yield(secs)	--force a <resume> after <secs> if specified
	if secs then
		SecsToResume = secs
		E:SetScript("OnUpdate", timeout)
	end
	return coroutine.yield()
end

local function waitUntilOutOfCombat()
	if InCombatLockdown() then
		print "GR: Waiting until out of combat..."	--can't use "prt" until have S
		function Event.PLAYER_REGEN_ENABLED()
			E:UnregisterEvent "PLAYER_REGEN_ENABLED"
			resume()
		end
		E:RegisterEvent "PLAYER_REGEN_ENABLED"
		yield()
	end
end

function Event.CHANNEL_ROSTER_UPDATE()	--Theoretically can speed things up, but in practice timer always resumes successfully first
	resume()
end

local function getRoster2(a)		--ugh - returns cached data after a /reload and possibly in other circumstances too
	local ar = Addon[a]
	local ndx
	repeat
		for i = 1, GetNumDisplayChannels() do
			if GetChannelDisplayInfo(i) == ar.chan then
				ndx = i
				break
			end
		end
		if not ndx then
			prt ("GR: Awaiting channel-index...")
			yield(1)
		end
	until ndx

	local count
	repeat
		SetSelectedDisplayChannel(ndx)	--needed before non-nil count can be returned
		yield(1)
		count = select(5, GetChannelDisplayInfo(ndx))
		if not count then
			prt ("GR: Awaiting channel roster-update...")
		end
	until count

	local list = "GR: Channel "..ar.chano..":"..ar.chan
	for i=1,count do
		local name,owner = GetChannelRosterInfo(ndx, i)
		if owner then ar.owner = name end
		if not ar.members then ar.members = {} end
		ar.members[name] = YES
		list = list.." - "..(owner and "*" or "")..name
	end
	prt (YELLOW..list.."|r")
end

function Event.CHAT_MSG_CHANNEL_LIST (members,_,_,_,_,_,_,_,chan)
	local ar
	for _,arr in pairs(Addon) do
		if arr.chan == chan then
			ar = arr
			break
		end
	end
	local function f(i)	--a credit to lua that it optimizes tail recursion and handles functions nested 3 deep
		local owner = members:sub(i,i) == "*"
		if owner then i=i+1 end
		local function add(member)
			if owner then ar.owner = member end
			if not ar.members then ar.members = {} end
			ar.members[member] = YES
		end
		local j = members:find(", ",i,YES)
		if j then
			add(members:sub(i,j-1))
			f(j+2)
		else
			add(members:sub(i))
		end
	end
	if ar then f(1) end
	resume(chan)
end

local function getRoster(a)
	local ar = Addon[a]
	ListChannelByName(ar.chan)
	for _ = 1,10 do		--10+ lists for 4 channels ample
		if ar.chan == yield(1) then return end	--timed escape from occasional death-trap
	end
end

local function eavesdropping(a)
	return	(a ~= "RA" or S.RA) and
		(a ~= "RS" or S.RS)
end

local function joinChannel(name, fullname)
	local told
	local n
	repeat
		JoinChannelByName(name)
		local i = GetChannelName(fullname)
		if i and i ~= 0 then
			n = i
		else	-- seen this for General when flying to Isle
			if not told then
				prt ("GR: Awaiting channel-number for",fullname,"...")
				told = YES
			end
			yield(1)
		end
	until n
	return n
end

local function firstRealm(realm)
	for _,clist in ipairs(ConnectedRealms) do
		for _,s in ipairs(clist) do
			if s == realm then return clist[1] end
		end
	end
end

local function translateNames(l)
	local localName = LocalName[l]
	for id,r_ in pairs(R_) do
		local name
		if localName then
			name = localName[id]
		else
			name = mobName(id)
		end
		if name and name ~= r_.name then
			r_.name = name
			r_.short = nil
		end
	end
end

local function resync()
	if S.syncs == 0 then return end
	for _,ar in pairs(Addon) do
		ar.owner = nil
		ar.members = nil
	end

	if YES then				--CHAT_MSG_CHANNEL_LIST more reliable than CHANNEL_ROSTER_UPDATE
		E:RegisterEvent "CHAT_MSG_CHANNEL_LIST"
		for _,a in ipairs{"RC","RA","RS","GR"} do	--want GR at end since OK if lose GR tail
			if eavesdropping(a) then getRoster(a) end
		end
		E:UnregisterEvent "CHAT_MSG_CHANNEL_LIST"
	else
		E:RegisterEvent "CHANNEL_ROSTER_UPDATE"
		for a in pairs(Addon) do
			if eavesdropping(a) then getRoster2(a) end
		end
		E:UnregisterEvent "CHANNEL_ROSTER_UPDATE"
	end
	subtractSet (Addon.RC.members, Addon.GR.members)
	subtractSet (Addon.RA.members, Addon.GR.members)
	subtractSet (Addon.RS.members, Addon.GR.members)
	subtractSet (Addon.RC.members, Addon.RA.members)
	subtractSet (Addon.RC.members, Addon.RS.members)
	--local s = "" for t in pairs(Addon.RC.members) do s = s.." - "..t end print(s)
	for _,a in ipairs{"GR","RC","RA"} do
		if eavesdropping(a) then goSync(a) end
	end
end

local function startD()
	Thread = coroutine.create(function()
		if not S then
			if not GetRareConfig then	--init database if first time ever
				GetRareConfig = {
					width=140,
					lineHt=FONT_HT+3.5,
					map = 1,
					alert = 1,
					wordy = 1,
					alarm=ALARMS[4]
				}
			end
			if not GetRare_ then GetRare_ = {} end
			if not GetRare then GetRare = {} end

			S = GetRareConfig
			if not S.syncs then
				S.syncs = 3
				S.RA = 1
				S.RS = 1
			end

			local zoneIndex,x1,y1,x2,y2 = GetCurrentMapZone()
			ZoneIndex = zoneIndex
			Zwidth = abs(x1-x2)		--2400 on Timeless Isle
			Zheight = abs(y1-y2)		--1600 on Timeless Isle

			if GetCVar("portal") == "US" then
				MyRealm1 = firstRealm(MyRealm)
			end
			if not MyRealm1 or MyRealm1 == MyRealm then
				if not GetRare[MyRealm] then GetRare[MyRealm] = {} end
			else
				if GetRare[MyRealm] then
					GetRare[MyRealm1] = GetRare[MyRealm]
					print ("GR: Data will be merged with",Myrealm1,"from now on")
				elseif not GetRare[MyRealm1] then
					GetRare[MyRealm1] = {}
				end
				GetRare[MyRealm] = nil
			end

			if MyLocale:sub(1,2) ~= "en" then translateNames(MyLocale) end

			SR_ = setmetatable(GetRare_, {__index=null,__call=must})
			sanitizeDimensions()
		end
		R = setmetatable({}, {__index=null,__call=must})
		SR = setmetatable(GetRare[MyRealm1 or MyRealm], {__index=null,__call=must})

		GenChat =
			strsub(MyLocale,1,2) == "en" and joinChannel("General", "General - Timeless Isle") or
			MyLocale == "deDE" and joinChannel("Allgemein", "Allgemein - Zeitlose Insel") or
			1
		for a,ar in pairs(Addon) do
			if eavesdropping(a) then
				ar.chano = joinChannel(ar.chan, ar.chan)
			end
		end

		waitUntilOutOfCombat()
		if not D then
			initD() alignD()
			initT()

			local dsp_elapsed = 0		--refresh display (mainly for elapsed time) every 10 secs, or earlier if forced to
			D:SetScript("OnUpdate", function(self,elapsed)
				dsp_elapsed = dsp_elapsed + elapsed
				if dsp_elapsed > (RefreshD or 10) then
					dsp_elapsed = 0
					RefreshD = nil
					refreshD()
				end
			end)
		else
			D:Show()
		end
		refreshD()
		if S.map then
			startW()
		end

		E:RegisterEvent "UNIT_HEALTH"
		E:RegisterEvent "PLAYER_TARGET_CHANGED"
		E:RegisterEvent "PLAYER_FOCUS_CHANGED"
		E:RegisterEvent "UPDATE_MOUSEOVER_UNIT"
		E:RegisterEvent "COMBAT_LOG_EVENT_UNFILTERED"

		E:RegisterEvent "VIGNETTE_ADDED"
		--E:RegisterEvent "VIGNETTE_REMOVED"

		E:RegisterEvent "CHAT_MSG_CHANNEL"

		for _,a in ipairs{"RC","RA"} do
			local ar = Addon[a]
			if eavesdropping(a) and not ar.registered then
				ar.registered = registerAddon(ar.prefix, YES)
			end
		end
		E:RegisterEvent "CHAT_MSG_ADDON"
		resync()
	end)
	resume()
end

local function stopD()
	Thread = coroutine.create(function()
		for _,ar in pairs(Addon) do
			if ar.chano then
				LeaveChannelByName(ar.chan)
				ar.chano = nil
			end
		end
		E:UnregisterEvent "CHAT_MSG_CHANNEL"
		--UnregisterAddonMessagePrefix() here if Blizz adds it
		E:UnregisterEvent "CHAT_MSG_ADDON"

		E:UnregisterEvent "UNIT_HEALTH"
		E:UnregisterEvent "PLAYER_TARGET_CHANGED"
		E:UnregisterEvent "PLAYER_FOCUS_CHANGED"
		E:UnregisterEvent "UPDATE_MOUSEOVER_UNIT"
		E:UnregisterEvent "COMBAT_LOG_EVENT_UNFILTERED"

		E:UnregisterEvent "VIGNETTE_ADDED"
		--E:UnregisterEvent "VIGNETTE_REMOVED"

		waitUntilOutOfCombat()
		if D then D:Hide() end	--turn off display and associated onUpdates
		if M then M:Hide() end
		if W then W:Hide() end
	end)
	resume()
end

----------------------------------------

function Event.zap()				--manually fired "event" - flush and resync
	for _,v in pairs(SR) do
		v.t = nil
		v.alive = nil
	end
	refreshD()
	Thread = coroutine.create(function()
		resync()
	end)
	resume()
end

local function onSameRealmAs(s)			--on same realm as party1-4 or raid1-40
	local name = GetUnitName(s,YES)
	local i = name:find("-",1,YES)
	local hisRealm = i and name:sub(i+1)
	if hisRealm 				--he is on a different realm
	and hisRealm ~= MyRealm			--can happen?
	and UnitRealmRelationship(s) == 2 then	--his home-realm is not connected to mine
		return NO,hisRealm
	end
	return YES
end

local function onMyRealm() 			--whether I am PROBABLY on my home-realm
	if not IsInGroup() then return YES end
	if IsInRaid() then return NO end	--no reliable way to check whether raid is on home-realm atm
	for i = 1,GetNumGroupMembers()-1 do	--even this check is not 100% reliable
		if not onSameRealmAs("party"..i) then return NO end
	end
	return YES
end

function Event.GROUP_ROSTER_UPDATE()		--fireable only as long as we are on TI
	local running = D and D:IsShown()
	if onMyRealm() then
		if not running then startD() end
	else
		if running then stopD() end
	end
end

function Event.ZONE_CHANGED_NEW_AREA()
	local iz = GetCurrentMapAreaID() == TIMELESS_ISLE
	if iz == InZone then return end
	InZone = iz
	if InZone then
		E:RegisterEvent "GROUP_ROSTER_UPDATE"
		if onMyRealm() then startD() end
	else
		E:UnregisterEvent "GROUP_ROSTER_UPDATE"
		stopD()
	end
end

function Event.PLAYER_ENTERING_WORLD()	--fired at logon or at any other loading screen, entering/leaving an instance, or rezzing at a GY
	Event.ZONE_CHANGED_NEW_AREA()
end

local function initCmd()		--force recheck of key Events
	SlashCmdList["GETRARE"] = function()
		Event.ZONE_CHANGED_NEW_AREA()
		if not InZone then
			print "GetRare is inactive because you are not on Timeless Isle"
			return
		end
		Event.GROUP_ROSTER_UPDATE()
		if not onMyRealm() then
			print "GetRare is inactive in case you are on another realm"
		end
	end
	SLASH_GETRARE1 = "/GetRare"
	SLASH_GETRARE2 = "/gr"
end

local function playerLogin()
	print("GetRare v"..Version, "("..LIGHTBLUE.."/gr|r to check status)")
	MyLocale = GetLocale()
	MyLocaleFont = STANDARD_TEXT_FONT
	MyName = UnitName("player")
	MyRealm = GetRealmName()
	E:RegisterEvent "ZONE_CHANGED_NEW_AREA"
	E:RegisterEvent "PLAYER_ENTERING_WORLD"
	initCmd()
end

function Event.PLAYER_LOGIN()
	E:UnregisterEvent "PLAYER_LOGIN"
	playerLogin()
end

function Event.ADDON_LOADED(name)
	if name ~= "GetRare" then
		return
	end
	E:UnregisterEvent "ADDON_LOADED"
	if IsLoggedIn() then
		playerLogin()
	else
		E:RegisterEvent "PLAYER_LOGIN"
	end
end

E = CreateFrame ("Frame")
E:SetScript("OnEvent", function(self,e,...) Event[e](...) end)
E:RegisterEvent "ADDON_LOADED"

