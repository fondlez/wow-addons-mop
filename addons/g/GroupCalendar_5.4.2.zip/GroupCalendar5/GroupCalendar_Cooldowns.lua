----------------------------------------
-- Group Calendar 5 Copyright 2005 - 2013 John Stephen, wobbleworks.com
-- All rights reserved, unauthorized redistribution is prohibited
----------------------------------------

GroupCalendar.Cooldowns = {}

