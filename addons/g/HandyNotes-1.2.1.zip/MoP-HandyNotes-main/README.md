# MoP-HandyNotes
HandyNotes for Mists of Pandaria 5.4.8

Mostly original versions from Xinhuan and other authors, with minor fixes by me.

Original links:

https://www.curseforge.com/wow/addons/handynotes

https://www.curseforge.com/wow/addons/handynotes_dungeonlocations

https://www.curseforge.com/wow/addons/handynotes_lorewalkers

https://www.wowace.com/projects/handynotes_lostandfound

https://www.curseforge.com/wow/addons/handynotes_timelessisle_rareelit

https://www.curseforge.com/wow/addons/timelessislechests

https://www.curseforge.com/wow/addons/handynotes_guild

https://www.curseforge.com/wow/addons/handy-notes-pandaria-treasures
