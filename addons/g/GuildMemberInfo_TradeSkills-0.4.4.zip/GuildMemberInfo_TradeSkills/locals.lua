local addonName, L = ...;

-- Default
L["Alchemy"] = "Alchemy"
L["Blacksmithing"] = "Blacksmithing"
L["Enchanting"] = "Enchanting"
L["Engineering"] = "Engineering"
L["Herbalism"] = "Herbalism"
L["Inscription"] = "Inscription"
L["Jewelcrafting"] = "Jewelcrafting"
L["Leatherworking"] = "Leatherworking"
L["Mining"] = "Mining"
L["No Profession"] = "No Profession"
L["Skinning"] = "Skinning"
L["Tailoring"] = "Tailoring"

