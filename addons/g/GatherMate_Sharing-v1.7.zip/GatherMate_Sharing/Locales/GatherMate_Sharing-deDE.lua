local L = LibStub("AceLocale-3.0"):NewLocale("GatherMate_Sharing","deDE")
if not L then return end

-- Addon name
L["Gathermate_Sharing"] = true
