local _G = getfenv(0)
local pairs, ipairs, type, select, table, tonumber, tostring = _G.pairs, _G.ipairs, _G.type, _G.select, _G.table, _G.tonumber, _G.tostring

local OneChoice = LibStub('AceAddon-3.0'):NewAddon('OneChoice', 'AceEvent-3.0', 'AceHook-3.0')

local is_mop = _G.GetBuildInfo():match('^5.') ~= nil

local CLOTH, LEATHER, MAIL, PLATE
local _, preferable_subclass_by_class
local universal_equip_slots = {
    ["INVTYPE_CLOAK"] = 1,
    ["INVTYPE_FINGER"] = 1,
    ["INVTYPE_NECK"] = 1,
    ["INVTYPE_TRINKET"] = 1,
    ["INVTYPE_WEAPONOFFHAND"] = 1,
    ["INVTYPE_HOLDABLE"] = 1,
}

if not is_mop then
    universal_equip_slots["INVTYPE_RELIC"] = 1
end

-- I assume that these are all valid values....
-- I went ahead and do a runtime conversion from the slotnames to the slotids
local invtype_to_slotname = {
    ["INVTYPE_2HWEAPON"] = "MainHandSlot",
    ["INVTYPE_AMMO"] = "AmmoSlot",
    ["INVTYPE_BAG"] = { "Bag0Slot", "Bag1Slot", "Bag2Slot", "Bag3Slot" },
    ["INVTYPE_BODY"] = "ShirtSlot",
    ["INVTYPE_CHEST"] = "ChestSlot",
    ["INVTYPE_CLOAK"] = "BackSlot",
    ["INVTYPE_FEET"] = "FeetSlot",
    ["INVTYPE_FINGER"] = { "Finger0Slot", "Finger1Slot" },
    ["INVTYPE_HAND"] = "HandsSlot",
    ["INVTYPE_HEAD"] = "HeadSlot",
    ["INVTYPE_HOLDABLE"] = "SecondaryHandSlot",
    ["INVTYPE_LEGS"] = "LegsSlot",
    ["INVTYPE_NECK"] = "NeckSlot",
    ["INVTYPE_QUIVER"] = { "Bag0Slot", "Bag1Slot", "Bag2Slot", "Bag3Slot" },
    ["INVTYPE_ROBE"] = "ChestSlot",
    ["INVTYPE_SHIELD"] = "SecondaryHandSlot",
    ["INVTYPE_SHOULDER"] = "ShoulderSlot",
    ["INVTYPE_TABARD"] = "TabardSlot",
    ["INVTYPE_TRINKET"] = { "Trinket0Slot", "Trinket1Slot" },
    ["INVTYPE_WAIST"] = "WaistSlot",
    ["INVTYPE_WEAPON"] = "MainHandSlot",
    ["INVTYPE_WEAPONMAINHAND"] = "MainHandSlot",
    ["INVTYPE_WEAPONMAINHAND_PET"] = "MainHandSlot",
    ["INVTYPE_WEAPONOFFHAND"] = "SecondaryHandSlot",
    ["INVTYPE_WRIST"] = "WristSlot",
}

if not is_mop then
    invtype_to_slotname["INVTYPE_RANGED"] = "RangedSlot"
    invtype_to_slotname["INVTYPE_RANGEDRIGHT"] = "RangedSlot"
    invtype_to_slotname["INVTYPE_RELIC"] = "RangedSlot"
    invtype_to_slotname["INVTYPE_THROWN"] = "RangedSlot"
end

local invtype_to_slotid = {}

function OneChoice:OnInitialize()
-- This lets me get around having to ship a localization
    CLOTH = self:GetSubclass("Cloth", 1433, 3642)
    LEATHER = self:GetSubclass("Leather", 1425, 2371)
    MAIL = self:GetSubclass("Mail", 2648, 2417)
    PLATE = self:GetSubclass("Plate", 8086, 8094)

    preferable_subclass_by_class = {
        ["HUNTER"] = LEATHER,
        ["WARLOCK"] = CLOTH,
        ["PRIEST"] = CLOTH,
        ["PALADIN"] = MAIL,
        ["MAGE"] = CLOTH,
        ["ROGUE"] = LEATHER,
        ["DRUID"] = LEATHER,
        ["SHAMAN"] = LEATHER,
        ["WARRIOR"] = MAIL,
        ["DEATHKNIGHT"] = PLATE,
        ["MONK"] = LEATHER,
    }

    local invtype, slotname
    for invtype,slotname in pairs(invtype_to_slotname) do
        if type(slotname) == "table" then
            invtype_to_slotid[invtype] = {}
            for _,v in ipairs(slotname) do
                local id = GetInventorySlotInfo(v)
                table.insert(invtype_to_slotid[invtype], id)
            end
        else
            local id = GetInventorySlotInfo(slotname)
            invtype_to_slotid[invtype] = { id }
        end
    end

    self.quest_mv_displays = {}
    self.quest_ilevel_displays = {}

    for i=1,10 do
        local nameframe = _G["QuestInfoItem" .. i .. "NameFrame"]

        local name = _G["QuestInfoItem" .. i .. "Name"]
        name:SetPoint("TOP", nameframe, "TOP", 0, -12)
        name:SetSize(90, 24)

        local mv_display = _G["QuestInfoItem" .. i]:CreateFontString("QuestInfoItem" .. i .. "MVDisplay", "BACKGROUND", "AchievementPointsFontSmall")
        mv_display:SetPoint("BOTTOMLEFT", nameframe, "BOTTOMLEFT", 15, 13)
        mv_display:SetSize(30, 12)
        mv_display:SetJustifyH("LEFT")
        mv_display:SetJustifyV("BOTTOM")
        mv_display:SetTextColor(1, 1, .26, 1)
        mv_display:SetText("MV")
        mv_display:Hide()

        self.quest_mv_displays[i] = mv_display

        local display = _G["QuestInfoItem" .. i]:CreateFontString("QuestInfoItem" .. i .. "ILevelDisplay", "BACKGROUND", "AchievementPointsFontSmall")
        display:SetPoint("BOTTOMRIGHT", nameframe, "BOTTOMRIGHT", -15, 13)
        display:SetSize(80, 12)
        display:SetJustifyH("RIGHT")
        display:SetJustifyV("BOTTOM")

        self.quest_ilevel_displays[i] = display
    end
end

function OneChoice:OnEnable()
    self:SecureHook("QuestInfo_Display")
    self:RegisterEvent("PLAYER_LEVEL_UP")
    self:PLAYER_LEVEL_UP(nil, UnitLevel("player"))
end

function OneChoice:GetSubclass(default, ...)
    for n=1,3 do
        for i=1,select('#', ...) do
            local subclass = select(7, GetItemInfo(select(i, ...)))
            if subclass then
                return subclass
            end
        end
    end

    return default
end

function OneChoice:PLAYER_LEVEL_UP(event, level)
    if tonumber(level) > 39 then
        preferable_subclass_by_class["HUNTER"] = MAIL
        preferable_subclass_by_class["PALADIN"] = PLATE
        preferable_subclass_by_class["SHAMAN"] = MAIL
        preferable_subclass_by_class["WARRIOR"] = PLATE
    end

    local _, class = UnitClass("player")
    self.preferable_subclass = preferable_subclass_by_class[class]
end

function OneChoice:QuestInfo_Display()
    for i=1,10 do
        self.quest_ilevel_displays[i]:SetText("")
        self.quest_mv_displays[i]:Hide()
    end

    local number_of_choices

    if QuestInfoFrame.questLog then
        number_of_choices = GetNumQuestLogChoices()
    else
        number_of_choices = GetNumQuestChoices()
    end

    if number_of_choices < 2 then
        return
    end

    local most_valuable_choice, most_valuable_price = 0, 0

    for i=1,number_of_choices do
        local link, numItems, isUsable

        if QuestInfoFrame.questLog then
            link = GetQuestLogItemLink("choice", i)
            _, _, numItems, _, isUsable = GetQuestLogChoiceInfo(i)
        else
            link = GetQuestItemLink("choice", i)
            _, _, numItems, _, isUsable = GetQuestItemInfo("choice", i)
        end

        if link then
            local name, link, quality, iLevel, reqLevel, class, subclass, maxStack, equipSlot, texture, vendorPrice = GetItemInfo(link)

            if vendorPrice * numItems > most_valuable_price then
                most_valuable_choice = i
                most_valuable_price = vendorPrice
            end

            local is_usable_shield = equipSlot == "INVTYPE_SHIELD" and isUsable
            if not universal_equip_slots[equipSlot] and class == "Armor" and subclass ~= self.preferable_subclass and not is_usable_shield then
                _G["QuestInfoItem" .. i .. "IconTexture"]:SetVertexColor(0.9, 0, 0)
                _G["QuestInfoItem" .. i .. "NameFrame"]:SetVertexColor(0.9, 0, 0)

                self.quest_ilevel_displays[i]:SetText("")
            elseif isUsable and self:EquippedIsHeirloom(equipSlot) then
                self.quest_ilevel_displays[i]:SetText("Heirloom")
                self.quest_ilevel_displays[i]:SetTextColor(0.9, 0.8, 0.5, 1)
            elseif isUsable then
                local differences = {}
                local upgrade = false
                for _,equipped_ilevel in ipairs(self:EquippedILevels(equipSlot)) do
                    local diff = iLevel - equipped_ilevel

                    if diff > 0 then
                        upgrade = true
                        table.insert(differences, "+" .. diff)
                    elseif diff < 0 then
                        table.insert(differences, tostring(diff))
                    else
                        table.insert(differences, "--")
                    end
                end

                if #differences > 0 then
                    self.quest_ilevel_displays[i]:SetText(table.concat(differences, "/") .. (#differences == 1 and " iLevels" or " iLvls"))

                    if upgrade then
                        self.quest_ilevel_displays[i]:SetTextColor(0, 1, 0, 1)
                    else
                        self.quest_ilevel_displays[i]:SetTextColor(.8, .8, .8, 1)
                    end
                end
            end
        end
    end

    local most_valued_texture = _G["QuestInfoItem" .. most_valuable_choice .. "IconTexture"]
    local most_valued_name = _G["QuestInfoItem" .. most_valuable_choice .. "Name"]

    if most_valued_texture and most_valued_name then
        self.quest_mv_displays[most_valuable_choice]:Show()
    -- TODO: make this optional
        QuestInfoItem_OnClick(_G["QuestInfoItem".. most_valuable_choice])
    end
end

function OneChoice:EquippedIsHeirloom(invtype)
    for _,id in ipairs(invtype_to_slotid[invtype] or {}) do
        local itemid = GetInventoryItemID("player", id)
        if itemid then
            local quality = select(3, GetItemInfo(itemid))
            if quality == 7 then
                return true
            end
        end
    end
end

function OneChoice:EquippedILevels(invtype)
    local results = {}

    for _,id in ipairs(invtype_to_slotid[invtype] or {}) do
        local itemid = GetInventoryItemID("player", id)
        if itemid then
            local equipped_ilevel = select(4, GetItemInfo(itemid))
            table.insert(results, equipped_ilevel)
        end
    end

    return results
end
