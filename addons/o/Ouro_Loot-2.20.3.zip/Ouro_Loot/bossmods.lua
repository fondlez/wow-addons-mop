local addon = select(2,...)
if addon.NOLOAD then return end

--[==[
Here's the control flow:
(1) This file or another addon calls
       addon:register_boss_mod("Foo",register[,unregister])
(2) When OL decides it's time to register with a boss mod, it calls
       register (addon, addon_do_boss)
    which should do whatever's needed.  This may happen more than once, if OL
    is turned on/off, etc.  It should return a true value if successful.
(2b) If a boss mod is already in place,
       unregister (addon)
    will be called first, if such a function was given at the start.
(3) When the boss mod triggers a callback, this code should call
       addon_do_boss (.....)
    with the crapton of data passed as in the DBM-related code below.

NOTA BENE:
- 'register' will not be called multiple times in a row for the same boss mod.
- The callback for (3) must check if OL is appropriately active.

------ Constants
------ Globals
------ Deadly Boss Mods
]==]

------ Constants

------ Globals
local flib = LibStub("LibFarmbuyer")
local pprint, tabledump = addon.pprint, flib.tabledump

-- Lua
local pairs, ipairs, tinsert, tremove = pairs, ipairs, table.insert, table.remove
local tonumber = tonumber

-- WoW
--local GetRaidRosterInfo = GetRaidRosterInfo

-- OL
local addon_do_boss 


------ Deadly Boss Mods
do
	local DBM
	local location, maxsize
	local real_loadmod
	-- When zoning into a raid instance not seen this session, make sure
	-- we don't report a previous raid instance as current location.  DBM
	-- has no callback event for this, so we do a small hook instead.
	local function resetting_loadmod (...)
		addon.latest_instance = nil
		return real_loadmod(...)
	end

	local function DBMBossCallback (self, reason, mod, ...)
		if (not self.rebroadcast) and (not self.enabled) then return end

		-- Behavior based on the first arg to DBM:NewMod.  Old style is just
		-- a boss name, which is set as mod.id and *should* also be set as
		-- combatinfo.name.  New style is the "encounter ID", fed through the
		-- EJ_GetEncounterInfo API to get the name, and then stripped down
		-- to the first comma (if any).
		local name
		if mod.combatInfo and mod.combatInfo.name then
			name = mod.combatInfo.name
		elseif mod.id then
			name = mod.id
		else
			name = "Unknown Boss"
		end

		local it
		if location then
			it = location
		else
			it, maxsize = self.instance_tag()
		end
		self.latest_instance = it
		location = nil

		local duration = 0
		if mod.combatInfo and mod.combatInfo.pull then
			duration = math.floor (GetTime() - mod.combatInfo.pull)
		end

		return addon_do_boss (self, reason, name, it, maxsize, duration)
	end

	local function callback(...) DBMBossCallback(addon,...) end

	local function _registerDBM (self, OL_boss_worker)
		DBM = _G.DBM
		if DBM then
			local rev = tonumber(DBM.Revision) or 0
			if rev < 1503 then
				self.status_text = "|cffff1010Deadly Boss Mods must be version 1.26 or newer to work with Ouro Loot.|r"
				return
			end
			addon_do_boss = OL_boss_worker
			local r = DBM:RegisterCallback("kill", callback)
					  DBM:RegisterCallback("wipe", callback)
					  DBM:RegisterCallback("pull", function()
						  location, maxsize = self.instance_tag()
					  end)
			real_loadmod = DBM.LoadMod
			DBM.LoadMod = resetting_loadmod
			return r > 0
		else
			self.status_text = "|cffff1010Ouro Loot cannot find Deadly Boss Mods, loot will not be grouped by boss.|r"
		end
	end

	local function _unregisterDBM (self)
		self.latest_instance = nil
		DBM.LoadMod = real_loadmod 
	end

	addon:register_boss_mod ("DBM", _registerDBM, _unregisterDBM)
end  -- DBM tie-ins


-- DXE, BigWigs, etc, need to be researched for this too

addon.FILES_LOADED = addon.FILES_LOADED + 1
-- vim:noet
