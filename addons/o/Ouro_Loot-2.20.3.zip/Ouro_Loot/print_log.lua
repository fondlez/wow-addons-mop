#!/usr/bin/env lua

--[[
This is meant to be run from a command-line interpreter.  It's what I
use in practice, but is shipping primarily an example.
]]

if not arg[1] or arg[1] == "" then
	print"Usage:  lua print_log.lua /path/to/OuroLoot_savedvars.lua"
	print"Don't forget to delete log table after viewing!"
	os.exit(1)
end

dofile(arg[1])

if type(OuroLootSV_log) ~= 'table' then
	print("Did not find OuroLootSV_log in", arg[1])
	os.exit(1)
end

for _,v in ipairs(OuroLootSV_log) do
	print(v)
end

os.exit(0)

-- vim:noet ff=unix
