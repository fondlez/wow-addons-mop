local addon = select(2,...)
if addon.NOLOAD then return end

local todo = [[
- Right-clicking the [ouroloot] chat link could do something different than
the current left-clicking.  Popup small menu in place?

- A fight duration of (0:00) happens when DBM gets confused.  If it happens
"near" another boss entry with nonzero duration, can we just safely assume
that's the real entry and delete the zero entry altogether?

- Loading enough plugin tabs to grow a second tab row causes the ST frames
to be too large.

- Rework candidate groups into the expiring caches.

- Break more methods out into private routines.

- implement ack, then fallback to recording if not ack'd

- Being able to drag rows up and down the main loot grid would be awesome.  Coding
that would be likely to drive me batshiat insane.

- Something to NOT do:  sort cross-realm recipients into history realms based
on the realm of the recipient instead of the realm of the player.  While this
would be useful for building up a history across realms... why would you want
to do that?  Massive data piling up that wouldn't be noticed unless the user
makes a habit of clicking the realm dropdown menu and looking around history.
]]

local helptree = {
	{
		value = "about",
		text = "About",
	},
	{
		value = "basic",
		text = "Basics",
		children = {
			{
				value = "loot",
				text = "Loot Entries",
			},
			{
				value = "boss",
				text = "Boss Entries",
			},
		},
	},
	{
		value = "tracking",
		text = "Tracking Loot",
		children = {
			{
				value = "enabled",
				text = "Full Tracking",
			},
			{
				value = "bcast",
				text = "Rebroadcasting",
			},
		},
	},
	{
		value = "texts",
		text = "Generated Texts",
		children = {
			{
				value = "forum",
				text = "Forum Markup",
			},
			{
				value = "other",
				text = "Other Texts",
			},
			{
				value = "saved",
				text = "Saved Texts",
			},
		},
	},
	{
		value = "history",
		text = "History Tab",
	},
	{
		value = "tips",
		text = "Handy Tips",
		children = {
			{
				value = "slashies",
				text = "Slash Commands",
			},
			{
				value = "prescan",
				text = "Prescanning",
			},
		},
	},
	{
		value = "todo",
		text = "TODOs, Bugs, etc",
		children = {
			{
				value = "gotchas",
				text = "Gotchas",
			},
			{
				value = "todolist",
				text = "TODO/knownbugs",
			},
        },
	},
}

-- Help text.  Formatting doesn't matter, but use a blank line to split
-- paragraphs.  This file needs to be edited with a text editor that doesn't
-- do anything stupid by placing extra spaces at the end of lines.
local helptext
do
local replacement_colors = {
	["+"]="|cff30adff", -- blue: right-click options, control panel names
	["<"]="|cff00ff00", -- light green, tab titles and generic highlighting
	[">"]="|r" }
local T={}
T.about = [[
Ouro Loot is the fault of Farmbuyer of Ouroboros on US-Kilrogg.  Bug reports,
comments, and suggestions are welcome at the project page:

<www.curse.com/addons/wow/ouroloot>


or send them to <farmbuyer@gmail.com> in non-HTML format.

If you have downloaded this addon from anywhere other than Curse or WoWInterface,
then it is probably outdated at best or stuffed full of |cffff335dmalware and
viruses|r at worst.  Get your addons from reputable safe sites!
]]

T.basic = [[
The </ouroloot> command opens this display.  The buttons
on the right side control operation and are mostly self-explanatory.  Hovering over
things will usually display some additional text in the gray line at the bottom.

Each tab on the left side can additionally create extra contols in the lower right
section (with the same name as the tab).

The first tab on the left side, <Loot>, is where everything goes to and comes
from.  Looting events and Deadly Boss Mods notifications go to the <Loot> tab; the
other tabs are all generated from the information in the <Loot> tab.

|cffff335dNote about these Help pages:|r  The category "titles" on the left side
have their own help text, in addition to the more specific entries in the expanded
list.  Read those first before expanding the categories or you'll miss stuff.
]]

T.basic_loot = [[
A "loot row" in the first tab has three columns:  the item, the recipient, and any
extra notes.

<Mouse Hover>

Hovering the mouse over the first column will display the item tooltip.

Hovering over the second column will display a tooltip with the loot that person
has received.  If they've won more than 10 items, the list is cut off with '...'
at the end; to see the full list, use the right-click +Show only this player> option
instead.

<Right-Click>

Right-clicking a loot row shows a dropdown menu.

Right-clicking in the first or third columns will display options for special
treatment of that loot entry (e.g., marking as offspec).  Using any of those
options will change the text in the third column, which will then affect the
text in the generated tabs, such as forum markup.

Right-clicking in the second column allows you to temporarily remove all other
players from the loot display.  Use the reset button in the lower-right corner to
restore the display to normal.  The menu also allows you to +reassign> loot from
one player to another; if the new recipient is not in the raid group at the time,
use the +Enter name...> option at the bottom of the list of names to type the
name into a text box.  If your raid takes advantage of the ability to trade
soulbound items, you will need to reassign the item here for the generated text
to be factually correct.

See the help screen on "Boss Entries" for the +Insert new boss kill event> option.

<Double-Click>

Double-clicking a loot row in the third ("Notes") column allows you to edit that
field directly.  The color of the text will still depend on any +Mark as ___>
actions done to that loot row, whether automatically or by hand.
]]

T.basic_boss = [[
Boss wipe/kill entries are entirely dependant on Deadly Boss Mods being enabled and
up-to-date.  The typical sequence of events for our usual raids goes like this:

We make four or five attempts on Baron Steamroller.  As DBM registers that combat
ends, a <wipe> event is entered on the loot display along with the duration of the
fight.  If the loot display is opened, the wipes will be visible with a light gray
background.

After reminding the melee dps to move out of fire, we manage to kill
Steamroller.  When DBM registers the win, a <kill> event is entered on the display
with a dark gray background.
All previous <wipe>s are removed and collapsed into the <kill> event.  The final
<kill> event shows the duration of the successful fight and the number of attempts
needed (or "one-shot" if we're competent).

Sometimes this goes wrong, when DBM misses its own triggers.  If DBM does not catch
the start of the boss fight, it can't register the end, so nothing at all is
recorded.  If the fight was a win but DBM does not catch the victory conditions,
then DBM will (after several seconds) decide that it was a wipe instead.  And
sometimes useful loot will drop from trash mobs, which DBM knows nothing about.

For all those reasons, right-clicking on a "boss row" will display options for
+Insert new boss kill event>, and for toggling a <wipe> into a <kill>.  We often
insert bosses named "trash" to break up the display and correct the forum markup
listing.
]]

T.tracking = [[
The first button underneath +Main> in the right-hand column displays the current
status of the addon.  If it is disabled, then no recording, rebroadcasting, or
listening for rebroadcasts is performed.  Any loot already recorded will be restored
across login sessions no matter the status.

You can turn on tracking/broadcasting before joining a raid.  If you join a raid
and the addon has not been turned on, then a popup dialog will ask for
instructions.  (This can be turned off in the advanced <Options>.)

The addon tries to be smart about logging on during a raid (due to a disconnect or
relog).  If you log in, are already in a raid group, and loot has already been
stored from tracking, it will re-enable itself automatically.

The intent of the addon design is that, after the end of a raid, all the generated
markup text is done, optionally saved (see "Generated Texts - Saved Texts"), and
then cleared from
storage altogether.  As a result, if you login with restored loot information but
are not in a raid, the addon will do nothing on its own -- but will assume that
you've forgotten to finish those steps and will yammer about it in the chat window
as a reminder.

The +Threshold> drop-down has no connection at all with any current loot threshold
set by you or a master looter.
]]

T.tracking_enabled = [[
Full tracking records all loot events that fulfill these criteria:

1)  The loot quality is equal to or better than what you have selected in the
+Threshold> drop-down.

2)  The loot is not in the list of items to filter out (see the <Options> tab).
These are things like shards from disenchanting and Darkmoon Faire quest items.

3)  <You can see the loot event.>  More precisely, you need to be close enough
to the recipient of the loot to be able to see "So-And-So receives loot: [Stuff]"
in your chat window, even if you have those actual loot messages turned off.

It is (3) that causes complications.  A master looter can assign loot to anybody
anywhere in a raid instance, but the range on detecting loot events is much
smaller.  If your raid does not use master looting then you merely need to be
close enough to the boss corpse, presuming that the winners will need to walk
over to get their phat epix.

If you do use master looter, then you have two options:  first, you can
require players
who might get loot to stay near the boss.  You would then also need to stay near
the boss to detect the loot event.  (This can be less hassle if you are also
the loot master.)  The downside is that other players moving on to fight to the
next boss are doing so without the help of their teammates.

The other option is to ask other players to also install Ouro Loot, and for
them to turn on the "Rebroadcasting" feature.  Any loot events which they can
see will be communicated to you.  Then it only becomes necessary for at least
one person to be close enough to the loot recipient to see the item awarded,
and you will record it no matter how far away you are -- even back in Orgrimmar.

If you have Full Tracking enabled, then you are also automatically rebroadcasting.
Having more than one player with Full Tracking turned on is probably a good
idea, in case one of the trackers experiences a game crash or is suddenly kidnapped
by robot ninja monkeys.
]]

T.tracking_bcast = [[
The simplest method of operation is only rebroadcasting the loot events that you
see, as you see them.  Nothing is recorded in your local copy of the addon.

If you logout for any reason, the addon will not reactivate when you log back in.

You can use </ouroloot bcast> or </ouroloot broadcast> to turn on rebroadcasting
without opening the GUI.
]]

T.texts = [[
The middle tabs are simply large editable text boxes.  Their text is initially
generated from
the information stored on the main <Loot> tab, at the time you click on the tab.
Not every bit of information that
we want in the generated text is always available, or depends on things that the
game itself can't know.  So you can edit the text in the tabs and your edits will
be preserved.

Each time you click one of the text tabs, every new entry on the <Loot> tab
since the last time this tab was shown will be turned into text.

Clicking the +Regenerate> button will throw away all the text on that tab, including
any edits you've made, and recreate all of it from scratch.  If you've accidentally
deleted the text from the editbox, or you've made manual changes to the <Loot> tab,
you can use this button to start over.

You can click in an editbox and use Control-A to select all text, then Control-C
to copy it to the system clipboard for subsequent pasting into a web browser or
whatever.  If you're on a Mac, you probably already know the equivalent keys.
]]

T.texts_forum = [[
The <Forum Markup> tab creates text as used by the guild forums for Ouroboros
of US-Kilrogg.  By default this is fairly standard BBcode.  The format of the
individual loot items can be adjusted via the dropdown menu on the lower right
of the tab.

The [url] choice defaults to using Wowhead.  If you have the [item] extension
for your BBcode installed, you can use either of those choices too.  The "by ID"
variant is good for heroic raid items that share names with nonheroic items,
but the raw output is harder to read in the text tab.

You can also specify a custom string.  Formatting is done with these replacements:

+$N>:  item name|r

+$I>:  (capital "eye", not "ell") numeric item ID|r

+$T>:  loot recipient and any additional notes|r

+$X>:  if more than one of the item was looted, this is the "x2", "x3", etc


Pro tip #1:  if something has happened on the main <Loot> tab which cannot be
changed directly but would generate incorrect text, you can click this tab to
generate the text right away.  Then edit/move the text as needed.  When you
close the display or click back on the <Loot> tab, your edited text will be
preserved for later.

Pro tip #2:  Barring situations like pro tip #1, this addon author typically
does not generate any text until the end of the raid, simplifying things
considerably.
]]

T.texts_other = [[
So far the only other generated text is the <Attendance> tab, an alphabetized list
on a per-boss basis.  Players who are probably inside the raid are grouped
under [:PLUS:], and the remaining players are under [-].  "Probably inside" is an
assumption that groups 1 and 2 are raiding in a 10-player instance, groups 1-5
are raiding in a 25-player instance, and so forth.

Other addons can register their own text tabs and corresponding generation
functions.  If you want to be able to feed text into an offline program (for
example, a spreadsheet or DKP tracker), then this may be of use to you.

Ideas for more tabs?  Tell me!
]]

T.texts_saved = [[
The contents of the <Forum Markup>, <Attendance>, and other such tabs can be saved,
so that they will not be lost when you use the +Clear> button.

Do any edits you want to the generated text tabs, then click the +Save Current As...>
button on the right-hand side.  Enter a short descriptive reminder (for example,
"thursday hardmodes") in the popup dialog.  The texts will remain in their tabs,
but clearing loot information will not lose them now.

All saved texts are listed on the right-hand side.  Clicking a saved text name
lets you +Load> or +Delete> that saved set.  The primary <Loot> tab is not saved
and restored by this process, only the generated texts.  This also means you cannot
+Regenerate> the texts.
]]

T.history = [[
The <History> tab maintains a list of all loot.  It is intended to help answer
questions such as "When was the last time PlayerX won something?" and "How much stuff
has PlayerY gotten lately?"  The history tab is, by design, not as configurable
as the main <Loot> tab; entries cannot be manually edited and so forth.

This loot history is the only "live" data tab which persists across the +Clear Loot> command.
For this reason, very little information is stored:  only the recipient, the item,
and a textual timestamp.  Boss names, offspecs, and other notes are not preserved.

The default history window shows the most recent item received by each person.  It
is sorted with the most recent loot at the top, towards older loot at the bottom.
You can click the column headers to rearrange the rows, but doing so repeatedly can
lead to odd display issues.

Left-clicking a row will change the window to display all recorded loot for that
player.  While on that display, right-clicking any row will return to showing the
most recent single item for all players.

Histories are maintained per-realm.  This refers to the realm you are on when the
loot drops, not the realm of the player receiving it (in the case of cross-realm
groups).  If you play multiple characters on the same realm, history will accumulate
across all your raids.  To change the displayed realm, use the dropdown menu in
the lower right corner.

The +Regenerate> button permanently erases the history of the displayed realm, and
creates fresh entries using whatever loot information is currently on the <Loot> tab.
Be aware that the <Loot> tab does not track realms, so if you have gathered data
for players on realm A, but are displaying realm B when you click the Regenerate button,
then your history for realm B will be... very odd.

+Clear Realm History> and +Clear ALL History> are used to periodically wipe the
slate clean.  They do not generate any new entries from existing loot.

+Clear Older> deletes history information older than a certain threshold (by
default, 5 loot events).  It is another good periodic maintenance step, but
does not discard as much data as the other actions.

From the right-click menu on the main tab, using +Reassign to...> will also
move the item between player histories.  The timestamp will not be changed;
it will "always have been" received by the new recipient.  Using
+Mark as disenchanted> or +Mark as guild vault> will remove the item from
history altogether.  Remarking such an item as +normal> or +offspec> will
replace the item back into the player's history.

Note:  the first time you display the histories during a game session, you will
likely see several items listed as +UNKNOWN>.  This is not a bug; these items are
simply not in your local game cache.  WoW will automatically retrieve the missing
data after several seconds, but the display will not update until the next time
the History tab is shown.  Starting in WoW 4.0, the local game cache is not preserved
across play sessions, so the +UNKNOWN> entries will pop up from time to time.
]]

T.tips = [[
The |cffff8000[Ouro Loot]|r "legendary item" displayed at the start of all
chat messages is a clickable link.  Clicking opens the main display, and if
possible will jump to and/or highlight the relevent data which caused the
associated chat message to be printed in the first place.
The "Be chatty" options on the <Options> tab will cause a chat message to be
printed after various events, thus providing a way to quickly view them.

If you are broadcasting to somebody else who is tracking, you should probably be
using the same threshold.  If yours is lower, then some of the loot you broadcast
to him will be ignored.  If yours is higher, then you will not be sending information
that he would have recorded.  The "correct" setting depends on what your guild wants
to track.

Ticking the "notraid" box in advanced debugging <Options>, before enabling tracking,
will make the tracking work outside of a raid group.  Communication functions
will behave a little strangely when doing this.  Be sure to check the threshold!
You can also use <"/ouroloot debug notraid"> instead.

Using the "Saved Texts" feature plus the +Clear> button is a great way of putting
off pasting loot into your guild's website until a more convenient time.

Shift-clicking an item in the <Loot> or <History> display will paste it into an
open chat editbox.
]]

T.tips_slashies = [[
A text field in the <Options> tab lets you use additional slash commands as a
shortcut for </ouroloot>.  The author prefers </ol>, as an example.  The
default used to be </loot> until that became a builtin command in MoP.

If you give an unrecognized argument to a slash command, it will
search the tab titles left to right for a title beginning with the same letters as
the argument, and open the display to that tab.  For example, <"/ol a"> would
open the <Attendance> tab, and <"/ol o"> would open the <Options> tab.  If
you had added a theoretical <EQDKP> tab, then <"/ol eq"> would be the fastest
way to see it.  Only enough text to be unambiguous is required, and all of it
is case-insensitive.

Some tabs will accept additional text after the tab title, and try to Do The
Right Thing.  For example, <"/ol history blah"> will search for a player named
"blah", and if found, will act as if you had clicked on that row, switching
the display to every loot received by that player.  The same unambiguous prefix
searching is used for names as for tab titles, so <"/ol hi farm"> is enough to
trigger Farmbuyer's history display (as long as nobody named Farmville joins
the raid), and so forth. 

The </ouroloot> command can take arguments to do things without going through
the UI.  Parts given in *(angle brackets)* are required, parts in [square brackets]
are optional:

+help>:  opens the UI to the help tab|r

+broadcast>/+bcast>:  turns on rebroadcasting|r

+on [T]>:  turns on full tracking, optionally setting threshold to T|r

+off>:  turns off everything|r

+thre[shold] T>:  sets tracking threshold to T|r

+ping>:  same as clicking "Ping!" on the Options tab|r

+list>:  prints saved text names and numbers|r

+save *(your set name)*>:  saves texts as "your set name"|r

+restore *(N)*>:  restores set number N|r

+delete *(N)*>:  deletes set number N|r

+toggle>:  opens or closes the UI (used mostly in automated wrappers)|r

+fix ?>:  lists the available automated data integrity fixes|r


If you use the slash commands to enable tracking or set loot thresholds, you can
give numbers or common names for the threshold.  For example, "0", "poor", "trash",
"gray"/"grey" are all the same, "4", "epic", "purple" are the same, and so on.
]]

T.tips_prescan = [[
When loot is manipulated, the history of previous loot entries must be scanned
to determine whether you already have any information for that loot.  In this
case, "loot manipulation" includes things like receiving loot broadcasts from
other players, marking older loot as being disenchanted, and so on.

You can speed up these actions by turning on the +Prescan for faster handling>
toggle on the <Options> tab.  This is a tradeoff:  loot manipulation will
go faster, but data from the prescan will use up more memory.  (If you end up
doing things to every single piece of loot, you would use up all that memory
eventually.  But if you don't, then that memory is essentially wasted.)

This prescanning is only done for the specific realm on which you're playing.
Much depends on how far back you preserve history.  The more history you keep
for a given realm, then...

[option on] ...the more memory this option uses...

[option off] ...the longer loot work takes...

...while manipulating loot for that realm.  See the tradeoff?

The prescan is only done once, during login.  It will print out how much
additional memory is used, so you can better decide whether this option is
worth turning on.  This also means that you need to relog or /reload to have
the option take effect once you enable it.
]]

T.todo = [[
If you have ideas or complaints or bug reports, first check the Bugs subcategories
to see if they're already being worked on.  Bug reports are especially helpful
if you can include a screenshot (in whatever image format you find convenient),
and a copy of your SavedVariables file.  This is found in your World of Warcraft
installation folder, named "WTF/Account/you/SavedVariables/Ouro_Loot.lua"
(where "you" is your account name).  You may need to compress this file
before the ticket system will accept it.

Click the "About" line on the left for contact information.
]]

T.todo_gotchas = [[
<Things Which Might Surprise You> (and things I'm not sure I like in the
current design):

Manipulating existing information while logged into a realm other than the
realm represented by that same information can yield strange results, including
outright breakage.

If you relog (or get disconnected) while in a raid group, behavior when you log
back in can be surprising.  If you have already recorded loot (and therefore
the loot list is restored), then OL assumes it's from the current raid and should
reactivate automatically in full tracking mode.  If you were tracking but no
loot had dropped yet (and therefore there was nothing *to* restore), then OL
will pop up its reminder and ask again.  Either way, if you were only broadcasting
then OL will *not* go back to only broadcasting.  This is probably a bug.

The saved texts feature does exactly that: only saves the generated texts, not
the full loot list.  Restoring will get you a blank first tab and whatever you
previously had in the various generated text tabs.

The generated forum text tries to only list the name of the instance if it has
not already been listed, or if it is different than the instance of the previous
boss.  If you relog, the "last printed instance name" will be forgotten, and
you'll see redundant raid instance names appearing in the text.

After a boss wipe, multiple broadcasting players releasing spirit more than
several seconds apart can cause spurious "wipe" entries (of zero duration) on
the loot grid.  The surefire way to avoid this is to not release spirit until
DBM announces the wipe, but the problem isn't serious enough to really worry
about.  (Right-click the spurious entries and delete them.)

When a boss is killed, ALL previous wipes for that boss are removed and
collapsed... even if they're on other days with other raids.  If you only
raid with one guild, this can result in some amusing statistics ("kill
on 27th attempt" would actually mean something), but if there are multiple
raid configurations without clearing loot in between, then this number
is simply garbage.
]]

T.todo_todolist = todo


-- Fill out the table that will actually be used.  Join adjacent lines here so
-- that they'll wrap properly.
helptext = {}
for k,text in pairs(T) do
	local funkykey = k:gsub('_','\001')  -- this is how TreeGroup makes unique keys
	local wrapped = text
	wrapped = wrapped:gsub ("[%+<>]", replacement_colors)
	wrapped = wrapped:gsub ("([^\n])\n([^\n])", "%1 %2")
	--safeprint(wrapped)
	wrapped = wrapped:gsub ("|r\n\n", "|r\n")
	wrapped = wrapped:gsub ("Ouroboros", "|cffa335ee<Ouroboros>|r")
	--safeprint(wrapped)
	wrapped = wrapped:gsub ("%*%(", "<") :gsub("%)%*", ">") :gsub(":PLUS:", "+")
	helptext[funkykey] = wrapped
end
end -- do scope
todo = nil


-- Tab 5:  Help
do
	local mkbutton = addon.gui_state_pointer.mkbutton
	local gui = addon.gui_state_pointer
	local AceGUI = LibStub("AceGUI-3.0")
	-- widget container status tables (will have things magically appear
	-- inside them that we wish to preserve)
	local status_for_scroll = {}
	local status_for_select = { treewidth = 145 }

	-- Clicking an entry on the left tree column.
	local help_OnGroupSelected_func = function (treeg,event,category)
		-- Some way of just reusing the same Label widget when clicking
		-- different topics?
		treeg:ReleaseChildren()
		local txt = AceGUI:Create("Label")
		txt:SetFullWidth(true)
		txt:SetFontObject(GameFontNormal)
		txt:SetText(helptext[category])
		local sf = AceGUI:Create("ScrollFrame")
		sf:SetStatusTable(status_for_scroll)
		sf:SetLayout("Fill")
		-- This forces the scrolling area to be bigger than the visible area; else
		-- some of the text gets cut off without ever triggering the scrollbar.
		sf.content:SetHeight(700)
		sf:AddChild(txt)
		treeg:AddChild(sf)
		if treeg:GetUserData("help restore scroll") then
			if status_for_scroll.scrollvalue then
				sf:SetScroll(status_for_scroll.scrollvalue)
			end
			treeg:SetUserData("help restore scroll", false)
		else
			sf:SetScroll(0)
		end
	end

	-- Clicking the Help tab as a whole (tabs_OnGroupSelected["help"]).
	local tabs_OGS = function(container,specials)
		container:SetLayout("Fill")
		local left = AceGUI:Create("TreeGroup")
		left:SetStatusTable(status_for_select)
		left:SetLayout("Fill")
		left:SetFullWidth(true)
		left:SetFullHeight(true)
		left:EnableButtonTooltips(false)
		left:SetTree(helptree)
		left:SetCallback("OnGroupSelected", help_OnGroupSelected_func)
		container:AddChild(left)
		if status_for_select.selected then
			left:SetUserData("help restore scroll", true)
			left:SelectByValue(status_for_select.selected)
		else
			left:SelectByValue("basic")
		end

		local b = mkbutton("Force Loot Refresh",
			[[Force the Loot tab display to update from stored data.  Shouldn't be needed.]])
		b:SetFullWidth(true)
		b:SetCallback("OnClick", function ()
			addon.loot_clean = nil
			addon:gui_init()
			addon:Print[[Loot tab display re-initialized.]]
		end)
		specials:AddChild(b)
	end

	addon:register_tab_control_AT_END ("help", [[Help]],
		[[Instructions, reminders, and tips for non-obvious features]],
		tabs_OGS, [[
Every tab across the top also gets its own special buttons here in the lower
right, under the same name as the tab.  Some controls do not become visible
until that tab has data to work with.]])

end

addon.FILES_LOADED = addon.FILES_LOADED + 1
-- vim:noet
