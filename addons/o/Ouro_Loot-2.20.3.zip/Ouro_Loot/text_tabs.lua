local addon = select(2,...)
if addon.NOLOAD then return end

--[[ Generator:
boolean FUNC (ttype, loot, last_printed, generated, cache)
in      TTYPE:  the registered text type as passed to register_text_generator
in      LOOT:  pointer to g_loot table
in      LAST_PRINTED:  index into loot most recently formatted by this routine
in      GENERATED.TTYPE:  (string) FIFO buffer for text created by this routine;
           other parts of the GUI copy and nil out this string.  Do not change
           this string, only examine it if needed.  If the generator is called
           more than once between GUI updates, text will build up here.
in/out  GENERATED.TTYPE_pos:  if non-nil, this is the saved cursor position in
           the text window (so that it stays where the user last left it).
           Move it if you're doing something strange with the displayed text.
tmp     GENERATED.loc_TTYPE_*:  Fields with this pattern free to use as needed.
out     CACHE:  Empty output table.  Accumulate generated lines here, one entry
           per visible line.  Do not terminate with a newline unless you want
           an extra blank line there.

Preconditions:
  + LAST_PRINTED < #LOOT
  + LOOT.TTYPE is a non-nil string containing all text in the text box (and
    if the user has edited the text box, this string will be updated).  Do not
    change this, but like GENERATED.TTYPE it is available for examination.

Return true if text was created, false if nothing was done.
]]

--[[ Optional special widgets:
FUNC (ttype, editbox, container, mkbutton)
    TTYPE:  see above
    EDITBOX:  the MultiLineEditBox widget
    CONTAINER:  widget container (already has 'Regenerate' button in it)
    MKBUTTON:  function to create more AceGUI widgets, as follows:

mkbutton ("WidgetType", 'display key', "Text On Widget", "mouseover text")
mkbutton ( [Button]     'display key', "Text On Widget", "mouseover text")
mkbutton ( [Button]      [text]        "Text On Widget", "mouseover text")

The 'display key' parameter will almost certainly be specified as nil for
these functions.
]]

local forum_warned_heroic
local warning_text
do
	local red = '|cffff0505'
	local green = ITEM_QUALITY_COLORS[ITEM_QUALITY_UNCOMMON].hex
	warning_text = ([[%sWARNING:|r  Heroic (and Raid Finder) items sharing the same name as normal items often display incorrectly on forums that use the item name as the identifier.  Recommend you change the %sItem markup|r dropdown in the right-hand side to %s"[item] by ID"|r (or some other format that uses $I) and regenerate this loot.]]):format(red, green, green)
end

local function forum (_, loot, last_printed, generated, cache)
	local fmt = addon.db.profile.forum[addon.db.profile.forum_current] or ""
	-- if it's capable of handling heroic items, consider them warned already
	forum_warned_heroic = forum_warned_heroic or fmt:find'%$I'

	for i = last_printed+1, #loot do
		local e = loot[i]

		if e.kind == 'loot' then
			local destination = e.person
			if e.disposition then
				local disp = e.disposition
				local disptext = addon:_test_disposition(disp,'text')
				if disp == 'offspec' then
					destination = e.person .. " " .. disptext
				elseif disp == 'gvault' then
					--destination = ("%s (%s)"):format(disptext,e.person)
					destination = disptext
				else
					destination = disptext
				end
			end
			if e.extratext_byhand then
				destination = destination .. " -- " .. e.extratext
			end
			if e.variant and not forum_warned_heroic then
				forum_warned_heroic = true
				addon:Print(warning_text)
			end
			local t = fmt:gsub('%$I', e.id)
			             :gsub('%$N', e.itemname)
			             :gsub('%$X', e.count or "")
			             :gsub('%$T', destination)
			cache[#cache+1] = t

		elseif e.kind == 'boss' and e.reason == 'kill' then
			-- The first boss in an instance gets an instance tag, others
			-- get a blank line
			if generated.last_instance == e.instance then
				cache[#cache+1] = ""
			else
				cache[#cache+1] = "\n[b]" .. e.instance .. "[/b]"
				generated.last_instance = e.instance
			end
			cache[#cache+1] = "[i]" .. e.bossname .. "[/i]"

		elseif e.kind == 'time' then
			cache[#cache+1] = "[b]" .. e.startday.text .. "[/b]"

		end
	end
	return #cache > 0
end

local function forum_specials (_,_, container, mkbutton)
	local opts = addon.db.profile
	local map,current = {}
	for label,format in pairs(opts.forum) do
		table.insert(map,label)
		if label == opts.forum_current then
			current = #map
		end
	end

	local dd, editbox
	dd = mkbutton("Dropdown", nil, "",
		[[Chose specific formatting of loot items.  See Help tab for more.  Regenerate to take effect.]])
	dd:SetFullWidth(true)
	dd:SetLabel("Item markup")
	dd:SetList(map)
	dd:SetValue(current)
	dd:SetCallback("OnValueChanged", function(_dd,event,choice)
		opts.forum_current = map[choice]
		forum_warned_heroic = nil
		editbox:SetDisabled(map[choice] ~= "Custom...")
	end)
	container:AddChild(dd)

	editbox = mkbutton("EditBox", nil, opts.forum["Custom..."],
		[[Format described in Help tab (Generated Text -> Forum Markup).]])
	editbox:SetFullWidth(true)
	editbox:SetLabel("Custom:")
	editbox:SetCallback("OnEnterPressed", function(_e,event,value)
		opts.forum["Custom..."] = value
		_e.editbox:ClearFocus()
	end)
	editbox:SetDisabled(opts.forum_current ~= "Custom...")
	container:AddChild(editbox)
end

addon:register_text_generator ("forum", [[Forum Markup]], [[BBcode ready for Ouroboros forums]], forum, forum_specials)


local ingroups, outgroups = {}, {}
local function do_attendance (raidertable, max_group_number)
	local tins, wipe, tsort, tconcat =
		table.insert, table.wipe, table.sort, table.concat

	-- Assumption:  everybody is packed into the first N groups.
	if raidertable then for name,info in pairs(raidertable) do
		if info.online ~= 'no_longer' then   -- 'no_longer' == left the raid
			if (info.subgroup or (NUM_RAID_GROUPS+1)) <= max_group_number then
				tins (ingroups, info.fname)
			else
				tins (outgroups, info.fname)
			end
		end
	end end
	if #ingroups > 0 then
		tsort(ingroups)
	else
		ingroups[1] = [[Nobody recorded as inside the instance.]]
	end
	if #outgroups > 0 then
		tsort(outgroups)
	else
		outgroups[1] = [[Nobody recorded as outside the instance.]]
	end
	local i,o = tconcat(ingroups,", "), tconcat(outgroups,", ")
	wipe(ingroups)
	wipe(outgroups)
	return i,o
end

local function att (_, loot, last_printed, _, cache)
	for i = last_printed+1, #loot do
		local e = loot[i]

		if e.kind == 'boss' and e.reason == 'kill' then
			-- Raid size can potentially be different on a per-boss basis
			-- (e.g., "we're dropping to 10-man for the PvP boss")
			local i,o = do_attendance (e.raidersnap, e.maxsize / MEMBERS_PER_RAID_GROUP)

			cache[#cache+1] = ("\n%s -- %s\n{+} %s\n{-} %s\n"):
				format(e.instance, e.bossname, i, o)

		elseif e.kind == 'time' then
			cache[#cache+1] = e.startday.text

		end
	end
	return #cache > 0
end

local function att_specials (_, editbox, container, mkbutton)
	local w = mkbutton("Take Attendance",
		[[Take attendance now (will continue to take attendance on each boss kill).]])
	w:SetFullWidth(true)
	w:SetCallback("OnClick", function(_w)
		local ss,max,instance = addon:snapshot_raid (--[[inraid=]]true)
		local i,o = do_attendance (ss, max / MEMBERS_PER_RAID_GROUP)
		local h, m = GetGameTime()

		local additional = ("Attendance for %s at %.2d:%.2d:\n{+} %s\n{-} %s"):
			format(instance, h, m, i, o)
		editbox:SetText(editbox:GetText() .. '\n' .. additional)
	end)
	container:AddChild(w)
end

addon:register_text_generator ("attend", [[Attendance]], [[Attendance list for each kill]], att, att_specials)

addon.FILES_LOADED = addon.FILES_LOADED + 1
-- vim:noet
