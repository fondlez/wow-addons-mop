﻿OptiTaunt_SpellDB["BUFF"] = {
	--Power Word: Shield
	[1] = {
		["SpellName"] = "Power Word: Shield",
		["SpellID"] = 17,
		["CD"] = 0,
		["Duration"] = 0,
		["Category"] = "Ability",
	},
}