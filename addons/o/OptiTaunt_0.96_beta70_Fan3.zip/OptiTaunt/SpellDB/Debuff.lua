﻿OptiTaunt_SpellDB["DEBUFF"] = {
	
--Debuff (without dispell type)
	{
	["SpellName"] = "Delirious Slash",
	["SpellID"] = {71623,71624,71625,71626},
	["Category"] = "Debuff",
	},
	{
	["SpellName"] = "Rune of Blood",
	["SpellID"] = {72408,72409,72410,72447,72448,72449},
	["Category"] = "Debuff",
	},
	{
	["SpellName"] = "Necrotic Strike",
	["SpellID"] = {70659,71951,72490,72491,72492},
	["Category"] = "Debuff",
	},
	{
	["SpellName"] = "Rend Flesh",
	["SpellID"] = {70435,71154},
	["Category"] = "Debuff",
	},
	{
	["SpellName"] = "Banish",
	["SpellID"] = {71298},
	["Category"] = "Debuff",
	},
	{
	["SpellName"] = "Black Brand",
	["SpellID"] = {70392},
	["Category"] = "Debuff",
	},

--Disarm
	{
	["SpellName"] = "Disarm",
	["SpellID"] = {676},
	["Category"] = "Disarm",
	},
	{
	["SpellName"] = "Disarm",
	["SpellID"] = {51722},
	["Category"] = "Disarm",
	},
	

--Stun
	{
	["SpellName"] = "Blood Sap",
	["SpellID"] = {70432},
	["Category"] = "Stun",
	},
	{
	["SpellName"] = "Shovelled!",
	["SpellID"] = {69572,70280},
	["Category"] = "Stun",
	},
	{
	["SpellName"] = "Hoarfrost",
	["SpellID"] = {69245,69645},
	["Category"] = "Stun",
	},
	{
	["SpellName"] = "Despair Stricken",
	["SpellID"] = {72428},
	["Category"] = "Stun",
	},
	{
	["SpellName"] = "Kidney Shot",
	["SpellID"] = {72335},
	["Category"] = "Stun",
	},


--Magic
	{
	["SpellName"] = "Polymorph: Spider",
	["SpellID"] = {70410,72106},
	["Category"] = "Magic",
	},
	{
	["SpellName"] = "Consuming Shadows",
	["SpellID"] = {69405},
	["Category"] = "Magic",
	},
	{
	["SpellName"] = "Chains of Shadow",
	["SpellID"] = {70645},
	["Category"] = "Magic",
	},
	{
	["SpellName"] = "Soul Sickness",
	["SpellID"] = {69131},
	["Category"] = "Magic",
	},
	{
	["SpellName"] = "Impending Despair",
	["SpellID"] = {72426},
	["Category"] = "Magic",
	},
	{
	["SpellName"] = "Shared Suffering",
	["SpellID"] = {72368,72369,72373},
	["Category"] = "Magic",
	},
	{
	["SpellName"] = "Chains of Ice",
	["SpellID"] = {72171},
	["Category"] = "Magic",
	},

--Curse
	{
	["SpellName"] = "Veil of Shadow",
	["SpellID"] = {69633},
	["Category"] = "Curse",
	},
	{
	["SpellName"] = "Curse of Doom",
	["SpellID"] = {70144,70183},
	["Category"] = "Curse",
	},
	{
	["SpellName"] = "Cursed Arrow",
	["SpellID"] = {72222},
	["Category"] = "Curse",
	},

--Poison
	{
	["SpellName"] = "Blinding Dirt",
	["SpellID"] = {70302},
	["Category"] = "Poison",
	},
	{
	["SpellName"] = "Deadly Poison",
	["SpellID"] = {72329,72330},
	["Category"] = "Poison",
	},
--Disease
	{
	["SpellName"] = "Leeching Rot",
	["SpellID"] = {70671,70710},
	["Category"] = "Disease",
	},
	{
	["SpellName"] = "Blight",
	["SpellID"] = {69603,70285},
	["Category"] = "Disease",
	},
--Full heal req.
	{
	["SpellName"] = "Glacial Strike",
	["SpellID"] = {70292,71316,71317},
	["Category"] = "Healreq",
	},

}