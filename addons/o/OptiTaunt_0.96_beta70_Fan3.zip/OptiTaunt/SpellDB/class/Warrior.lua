﻿OptiTaunt_PlayerSpellDB["WARRIOR"] = {
	
	--Avatar
	{
		["SpellName"] = "Avatar",
		["SpellID"] = {107574},
		["CD"] = 180,
		["Duration"] = 20,
		["Category"] = "Aura",
	},
	--Shield Wall
	{
		["SpellName"] = "Shield Wall",
		["SpellID"] = {871},
		["CD"] = 120,
		["Duration"] = 12,
		["Category"] = "Aura",
	},
	--Last Stand
	{
		["SpellName"] = "Last Stand",
		["SpellID"] = {12975},
		["CD"] = 180,
		["Duration"] = 20,
		["Category"] = "Aura",
	},
	--Enraged Regeneration
	{
		["SpellName"] = "Enraged Regeneration",
		["SpellID"] = {55694},
		["CD"] = 60,
		["Duration"] = 5,
		["Category"] = "Aura",
	},
	--Skull Banner
	{
		["SpellName"] = "Skull Banner",
		["SpellID"] = {114207},
		["CD"] = 180,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	--Disarm
	{
		["SpellName"] = "Disarm",
		["SpellID"] = {676},
		["CD"] = 60,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	--Taunt
	{
		["SpellName"] = "Taunt",
		["SpellID"] = {355},
		["CD"] = 8,
		["Duration"] = 3,
		["Category"] = "Taunt",
	},
	--Mocking Banner
	{
		["SpellName"] = "Mocking Banner",
		["SpellID"] = {114192},
		["CD"] = 180,
		["Duration"] = 6,
		["Category"] = "Taunt",
	},
	--Rallying Cry
	{
		["SpellName"] = "Rallying Cry",
		["SpellID"] = {97462},
		["CD"] = 180,
		["Duration"] = 10,
		["Category"] = "Timer",
	},
	--Pummel
	{
		["SpellName"] = "Pummel",
		["SpellID"] = {6552},
		["CD"] = 15,
		["Duration"] = 4,
		["Category"] = "Interrupt",
	},
	--Disrupting Shout
	{
		["SpellName"] = "Disrupting Shout",
		["SpellID"] = {102060},
		["CD"] = 40,
		["Duration"] = 4,
		["Category"] = "Interrupt",
	},
	
}
