﻿OptiTaunt_PlayerSpellDB["PRIEST"] = {

	--Pain Suppression
	{
		["SpellName"] = "Pain Suppression",
		["SpellID"] = {33206},
		["CD"] = 180,
		["Duration"] = 8,
		["Category"] = "Aura",
	},
	--Guardian Spirit
	{
		["SpellName"] = "Guardian Spirit",
		["SpellID"] = {47788},
		["CD"] = 180,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	--Power Infusion
	{
		["SpellName"] = "Power Infusion",
		["SpellID"] = {10060},
		["CD"] = 120,
		["Duration"] = 20,
		["Category"] = "Aura",
	},
	--Fear Ward
	{
		["SpellName"] = "Fear Ward",
		["SpellID"] = {6346},
		["CD"] = 180,
		["Duration"] = 180,
		["Category"] = "Aura",
	},
	--Hymn of Hope
	{
		["SpellName"] = "Hymn of Hope",
		["SpellID"] = {64901},
		["CD"] = 360,
		["Duration"] = 8,
		["Category"] = "Ability",
	},
	--Divine Hymn
	{
		["SpellName"] = "Divine Hymn",
		["SpellID"] = {64843},
		["CD"] = 180,
		["Duration"] = 8,
		["Category"] = "Ability",
	},
	--Leap of Faith
	{
		["SpellName"] = "Leap of Faith",
		["SpellID"] = {73325},
		["CD"] = 90,
		["Duration"] = 0,
		["Category"] = "Ability",
	},
	--Lightwell
	{
		["SpellName"] = "Lightwell",
		["SpellID"] = {724},
		["CD"] = 180,
		["Duration"] = 180,
		["Category"] = "Totem",
	},
	--Power Word: Barrier
	{
		["SpellName"] = "Power Word: Barrier",
		["SpellID"] = {62618},
		["CD"] = 180,
		["Duration"] = 10,
		["Category"] = "Summon",
	},
	--Dispersion
	{
		["SpellName"] = "Dispersion",
		["SpellID"] = {47585},
		["CD"] = 120,
		["Duration"] = 6,
		["Category"] = "Aura",
	},

}
