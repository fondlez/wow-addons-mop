﻿OptiTaunt_PlayerSpellDB["ROGUE"] = {
	
	--Tricks of the Trade
	{
		["SpellName"] = "Tricks of the Trade",
		["SpellID"] = {57933},
		["CD"] = 30,
		["Duration"] = 6,
		["Category"] = "Aura",
	},
	
	--Kick
	{
		["SpellName"] = "Kick",
		["SpellID"] = {1766},
		["CD"] = 10,
		["Duration"] = 5,
		["Category"] = "Interrupt",
	},
	
}
