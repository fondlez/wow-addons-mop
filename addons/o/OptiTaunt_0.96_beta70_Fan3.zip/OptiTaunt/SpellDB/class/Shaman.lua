﻿OptiTaunt_PlayerSpellDB["SHAMAN"] = {

	--Reincarnation
	{
		["SpellName"] = "Reincarnation",
		["SpellID"] = {20608},
		["CD"] = 1800,
		["Duration"] = 0,
		["Category"] = "CD",
	},	
	--Stormlash Totem
	{
		["SpellName"] = "Stormlash Totem",
		["SpellID"] = {120668},
		["CD"] = 300,
		["Duration"] = 10,
		["Category"] = "Totem",
	},	
	--Mana Tide Totem
	{
		["SpellName"] = "Mana Tide Totem",
		["SpellID"] = {16190},
		["CD"] = 180,
		["Duration"] = 16,
		["Category"] = "Totem",
	},
	--Spirit Link Totem
	{
		["SpellName"] = "Spirit Link Totem",
		["SpellID"] = {98008},
		["CD"] = 180,
		["Duration"] = 6,
		["Category"] = "Totem",
	},
	--Wind Shear
	{
		["SpellName"] = "Wind Shear",
		["SpellID"] = {98008},
		["CD"] = 12,
		["Duration"] = 3,
		["Category"] = "Interrupt",
	},
	--Shamanistic Rage
	{
		["SpellName"] = "Shamanistic Rage",
		["SpellID"] = {30823},
		["CD"] = 60,
		["Duration"] = 15,
		["Category"] = "Aura",
	},	
	
}
