﻿OptiTaunt_PlayerSpellDB["PALADIN"] = {

	--Avenger's Shield			31935	Interrupt
	{
		["SpellName"] = "Avenger's Shield",
		["SpellID"] = {31935},
		["CD"] = 15,
		["Duration"] = 3,
		["Category"] = "Interrupt",
	},
	--Reckoning			62124	Taunt
	{
		["SpellName"] = "Reckoning",
		["SpellID"] = {62124},
		["CD"] = 8,
		["Duration"] = 3,
		["Category"] = "Taunt",
	},
	--Divine Protection			498		Aura
	{
		["SpellName"] = "Divine Protection",
		["SpellID"] = {498},
		["CD"] = 60,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	--Rebuke					96231	Interrupt
	{
		["SpellName"] = "Rebuke",
		["SpellID"] = {96231},
		["CD"] = 15,
		["Duration"] = 4,
		["Category"] = "Interrupt",
	},
	--Ardent Defender			31850	Aura
	{
		["SpellName"] = "Ardent Defender",
		["SpellID"] = {31850},
		["CD"] = 180,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	--Guardian of Ancient Kings(Prot)	86659	Aura
	{
		["SpellName"] = "Guardian of Ancient Kings",
		["SpellID"] = {86659},
		["CD"] = 180,
		["Duration"] = 12,
		["Category"] = "Aura",
	},

-----------------------------------------------------------------------------------------------	
	--Divine Plea				54428	Aura
	{
		["SpellName"] = "Divine Plea",
		["SpellID"] = {54428},
		["CD"] = 120,
		["Duration"] = 9,
		["Category"] = "Aura",
	},
	--Divine Shield				642		Aura
	{
		["SpellName"] = "Divine Shield",
		["SpellID"] = {642},
		["CD"] = 300,
		["Duration"] = 8,
		["Category"] = "Aura",
	},
	--Lay on Hands				633		Ability
	{
		["SpellName"] = "Lay on Hands",
		["SpellID"] = {633},
		["CD"] = 600,
		["Duration"] = 0,
		["Category"] = "Ability",
	},
	--Hand of Protection		1022	Aura/Ability
	{
		["SpellName"] = "Hand of Protection",
		["SpellID"] = {1022},
		["CD"] = 300,
		["Duration"] = 10,
		["Category"] = "Ability",
	},
	--Hand of Salvation			1038	Ability
	{
		["SpellName"] = "Hand of Salvation",
		["SpellID"] = {1038},
		["CD"] = 120,
		["Duration"] = 10,
		["Category"] = "Ability",
	},
	--Hand of Freedom			1044	Ability
	{
		["SpellName"] = "Hand of Freedom",
		["SpellID"] = {1044},
		["CD"] = 25,
		["Duration"] = 6,
		["Category"] = "Ability",
	},
	--Hand of Sacrifice			6940	Aura
	{
		["SpellName"] = "Hand of Sacrifice",
		["SpellID"] = {6940},
		["CD"] = 120,
		["Duration"] = 12,
		["Category"] = "Aura",
	},
	--Devotion Aura
	{
		["SpellName"] = "Devotion Aura",
		["SpellID"] = {31821},
		["CD"] = 180,
		["Duration"] = 6,
		["Category"] = "Aura",
	},

}
