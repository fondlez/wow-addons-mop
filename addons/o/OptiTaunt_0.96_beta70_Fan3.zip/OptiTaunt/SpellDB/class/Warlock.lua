﻿OptiTaunt_PlayerSpellDB["WARLOCK"] = {}
