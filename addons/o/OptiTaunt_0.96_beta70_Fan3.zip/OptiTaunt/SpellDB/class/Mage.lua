﻿OptiTaunt_PlayerSpellDB["MAGE"] = {
	
}
