﻿OptiTaunt_PlayerSpellDB["DEATHKNIGHT"] = {

	--Vampiric Blood 
	{
		["SpellName"] = "Vampiric Blood",
		["SpellID"] = {55233},
		["CD"] = 60,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	--Icebound Fortitude
	{
		["SpellName"] = "Icebound Fortitude",
		["SpellID"] = {48792},
		["CD"] = 180,
		["Duration"] = 12,
		["Category"] = "Aura",
	},
	--Anti-Magic Shell
	{
		["SpellName"] = "Anti-Magic Shell",
		["SpellID"] = {48707},
		["CD"] = 45,
		["Duration"] = 5,
		["Category"] = "Aura",
	},
	--Pillar of Frost
	{
		["SpellName"] = "Pillar of Frost",
		["SpellID"] = {51271},
		["CD"] = 60,
		["Duration"] = 20,
		["Category"] = "Ability",
	},
	--Desecrated Ground
	{
		["SpellName"] = "Desecrated Ground",
		["SpellID"] = {108201},
		["CD"] = 120,
		["Duration"] = 10,
		["Category"] = "Ability",
	},
	--Dancing Rune Weapon
	{
		["SpellName"] = "Dancing Rune Weapon",
		["SpellID"] = {49028},
		["CD"] = 90,
		["Duration"] = 12,
		["Category"] = "Ability",
	},
	--Death Grip
	{
		["SpellName"] = "Death Grip",
		["SpellID"] = {49576},
		["CD"] = 35,
		["Duration"] = 3,
		["Category"] = "Ability",
	},
	--Mind Freeze
	{
		["SpellName"] = "Mind Freeze",
		["SpellID"] = {47528},
		["CD"] = 10,
		["Duration"] = 4,
		["Category"] = "Interrupt",
	},
	--Strangulate 47476 / Interrupt 32747
	{
		["SpellName"] = "Strangulate",
		["SpellID"] = {47476},
		["CD"] = 120,
		["Duration"] = 3,
		["Category"] = "Interrupt",
	},	
	--Dark Command
	{
		["SpellName"] = "Dark Command",
		["SpellID"] = {56222},
		["CD"] = 8,
		["Duration"] = 3,
		["Category"] = "Taunt",
	},

}
