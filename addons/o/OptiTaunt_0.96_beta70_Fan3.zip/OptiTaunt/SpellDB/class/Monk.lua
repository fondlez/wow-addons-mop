﻿OptiTaunt_PlayerSpellDB["MONK"] = {
	--Avert Harm
	{
		["SpellName"] = "Avert Harm",
		["SpellID"] = {115213},
		["CD"] = 180,
		["Duration"] = 6,
		["Category"] = "Aura",
	},
	--Fortifying Brew
	{
		["SpellName"] = "Fortifying Brew",
		["SpellID"] = {115203},
		["CD"] = 180,
		["Duration"] = 20,
		["Category"] = "Aura",
	},
	--Zen Meditation
	{
		["SpellName"] = "Zen Meditation",
		["SpellID"] = {115203},
		["CD"] = 180,
		["Duration"] = 8,
		["Category"] = "Aura",
	},
	--Provoke
	{
		["SpellName"] = "Provoke",
		["SpellID"] = {115546},
		["CD"] = 8,
		["Duration"] = 3,
		["Category"] = "Taunt",
	},
	--Spear Hand Strike
	{
		["SpellName"] = "Spear Hand Strike",
		["SpellID"] = {116705},
		["CD"] = 15,
		["Duration"] = 4,
		["Category"] = "Interrupt",
	},
	--Grapple Weapon
	{
		["SpellName"] = "Grapple Weapon",
		["SpellID"] = {117368},
		["CD"] = 60,
		["Duration"] = 10,
		["Category"] = "Aura",
	},
	
}
