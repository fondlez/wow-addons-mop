﻿OptiTaunt_PlayerSpellDB["DRUID"] = {
	
	--Growl
	{
		["SpellName"] = "Growl",
		["SpellID"] = {6795},
		["CD"] = 8,
		["Duration"] = 3,
		["Category"] = "Taunt",
	},
	--Survival Instincts		61336	Aura
	{
		["SpellName"] = "Survival Instincts",
		["SpellID"] = {61336},
		["CD"] = 180,
		["Duration"] = 12,
		["Category"] = "Aura",
	},
	--Ironbark
	{
		["SpellName"] = "Ironbark",
		["SpellID"] = {102342},
		["CD"] = 120,
		["Duration"] = 12,
		["Category"] = "Aura",
	},
	--Might of Ursoc
	{
		["SpellName"] = "Might of Ursoc",
		["SpellID"] = {106922},
		["CD"] = 180,
		["Duration"] = 20,
		["Category"] = "Aura",
	},
	--Barkskin					22812	Aura
	{
		["SpellName"] = "Barkskin",
		["SpellID"] = {22812},
		["CD"] = 60,
		["Duration"] = 12,
		["Category"] = "Aura",
	},
	--Skull Bash				80964,80965,93985	Interrupt
	{
		["SpellName"] = "Skull Bash",
		["SpellID"] = {93985},
		["CD"] = 15,
		["Duration"] = 4,
		["Category"] = "Interrupt",
	},	
	--Innervate
	{
		["SpellName"] = "Innervate",
		["SpellID"] = {29166},
		["CD"] = 180,
		["Duration"] = 10,
		["Category"] = "Ability",
	},
	--Rebirth
	{
		["SpellName"] = "Rebirth",
		["SpellID"] = {20484},
		["CD"] = 600,
		["Duration"] = 0,
		["Category"] = "Taunt",
	},
	--Tranquility
	{
		["SpellName"] = "Tranquility",
		["SpellID"] = {740},
		["CD"] = 480,
		["Duration"] = 8,
		["Category"] = "Ability",
	},

}
