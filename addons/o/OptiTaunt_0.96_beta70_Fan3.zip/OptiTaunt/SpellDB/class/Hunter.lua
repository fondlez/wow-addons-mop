﻿OptiTaunt_PlayerSpellDB["HUNTER"] = {
	--Growl
	{
		["SpellName"] = "Growl",
		["SpellID"] = {6795},
		["CD"] = 8,
		["Duration"] = 3,
		["Category"] = "Taunt",
	},
	
	--Misdirection				34477	Ability
	--Distracting Shot			20736	Taunt/Ability
	--Scatter Shot				19503	Aura
	--Silencing Shot			34490	Interrupt	3sec
	--Ice Trap					13809,82941	Ability
	
}
