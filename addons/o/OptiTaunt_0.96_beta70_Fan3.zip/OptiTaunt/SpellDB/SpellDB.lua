﻿OptiTaunt_PlayerSpellDB = {
	["DEATHKNIGHT"] = {},
	["DRUID"] = {},
	["HUNTER"] = {},
	["MAGE"] = {},
	["MONK"] = {},
	["PALADIN"] = {},
	["PRIEST"] = {},
	["ROGUE"] = {},
	["SHAMAN"] = {},
	["WARLOCK"] = {},
	["WARRIOR"] = {},	
}

OptiTaunt_SpellDB = {
	["BUFF"] = {},
	["DEBUFF"] = {},
}