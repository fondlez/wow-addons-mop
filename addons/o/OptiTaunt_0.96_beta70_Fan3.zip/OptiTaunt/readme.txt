﻿OptiTaunt
by humfras (Shinizu @ EU-Dalvengyr)
original author: Nebelmond (EU-Die silberne Hand)

     Brief description

OptiTaunt is an addon for warriors and druids, paladins and Deathknights.
It informs you and your party/raid if your taunt/mocking blow/growl/righteous defense was resisted.
It also announce special abilities eg. Last Stand / Shield Wall, AE Taunts, Disarm, Counterspells...
Since v0.93 OptiTaunt also announces important Tank debuffs eg. Disarms, Stuns and heal reducing debuffs.
It fully works for english and german WoW-clients; esES, frFR, koKR, ruRu, zhCN, zhTW are partially localized.
     
	 
	 When will OptiTaunt inform me about resisted taunts?

OptiTaunt detects if your taunt/mocking blow/growl was resisted or the mob was immune. It will inform you if...
- another _player_ actually has aggro of the mob which resisted your taunt/mocking blow/growl

Or, to put it the other way round, it will not inform you if your taunt/mocking blow/growl was resisted and...
- you already have aggro of that mob (who should care about this anyway?)
- you are in pvp and you accidentally tried to taunt another hostile player

     
	 How will OptiTaunt inform me?

There are several options you can enable or disable:
- ErrorFrame, SCT, ..., warnings (via SinkLib)
- Raid- and partychat warnings
- Whisper (automatically whispers a warning to the player which has aggro of the mob which resisted your taunt)
- Audio warnings (plays an audio warning on your client when your taunt resisted, which is quiet valuable in combat situations)


     Ok, ok. Understood. But how do I configure it?

This is simple. OptiTaunt ships with a Fubar-plugin. If you have Fubar installed it will be shown there.
If you don't have Fubar installed you will notice a new minimap icon.
There are also slash-commands, just type "/ot" for descriptions.


    Contributions

-- humfras
Many thanks to my guildmate Andrephalus and my friend Edsâs for persistent testing.
	
-- Nebelmond	
Many thanks to my guildmates Gondwana and Tymara for persistent testing.
/target Gondwana
/bow
/target Tymara
/salute