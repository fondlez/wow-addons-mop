﻿local L = AceLibrary("AceLocale-2.2"):new("OptiTaunt")

L:RegisterTranslations("esES", function() return {
--Addon Stuff
	["Tooltip"] = "Click derecho para opciones.",
	["Slash-Commands"] = { "/optitaunt", "/ot" },
	
	["Statistics"] = "Estadísticas",
	["Taunts"] = "Taunts:",
	["Resisted"] = "Resistidos:",
	
--Messages
	["resistmessage"] = "Cuidado! {t} ha Resistido mi {a}!",
	["immunemessage"] = "Cuidado! {t} es Inmune a mi {a}!",
	
	["abilitymessage"] = "+++ {a} activo durante {d} segundos +++",
	["abilityendmessage"] = "--- {a} ends ---",
	
	["abilityontargetmessage"] = "+++ {a} activated on {t} ({d}s) +++",
	["abilityontargetendmessage"] = "--- {a} on {t} ends ---",	
	
	["instantcastmessage"] = "{a} casted on {t}",	
	
	["counterspellmessage"] = "Kicked {s} by {t}  ({d}s)",
	
	["procmessage"] = " {a} has proc'ed",
	
	["disarmmessage"] = ">>> {a}! I am DISARMED ({d}s) <<<",
	["disarmendmessage"] = "<<< {a} fades. I am REARMED >>>",
	
	["debuffmessage"] = ">>> {a} ({d}s) <<<",
	["debuffendmessage"] = "<<< {a} ends. >>>",
	
	["debuffstunmessage"] = ">>> {a} ({d}s) - STUNNED<<<",
	["debuffmagicmessage"] = ">>> {a} ({d}s) - DISPEL<<<",
	["debuffcursemessage"] = ">>> {a} ({d}s) - DECURSE<<<",
	["debuffpoisonmessage"] = ">>> {a} ({d}s) - CURE POISON<<<",
	["debuffdiseasemessage"] = ">>> {a} ({d}s) - ABOLISH DISEASE<<<",
	["healreqmessage"] = ">>> {a} ({d}s) - HEAL ME TO 100%<<<",
	["pullcountmessage"] = "Pull in {d} seconds.",
	["pullmessage"] = ">>>>>> PULL <<<<<<",
	["pulltimerrange"] = 3,
	
	
--Whisper Strings
	["Resist-Whisper-Message-Warrior"] = "Cuidao que van a darte yoyas. Aguanta! :-)",
	["Resist-Whisper-Message-Druid"] = "Cuidao que van a darte yoyas. Ponte en ozito o aprieta el culo! :-)",
	["Resist-Whisper-Message-Paladin"] = "Cuidao que van a darte yoyas. Aguanta! :-)",
	["Resist-Whisper-Message-Mage"] = "Cuidao que van a darte yoyas. CUBITO! :-)",
	["Resist-Whisper-Message-Warlock"] = "Cuidao que van a darte yoyas. Ven hacia mi! :-)",
	["Resist-Whisper-Message-Hunter"] = "Cuidao que van a darte yoyas. FEIGN DEATH! :-)",
	["Resist-Whisper-Message-Rogue"] = "Cuidao que van a darte yoyas. VANISH!!! :-)",
	["Resist-Whisper-Message-Priest"] = "Cuidao que van a darte yoyas. Aguanta! :-)",
	["Resist-Whisper-Message-Shaman"] = "Cuidao que van a darte yoyas. Aguanta! :-)",
	["Resist-Whisper-Message-Deathknight"] = "Frost Presence ftw! :-)",
	
	
--Options
	--Chat (say, group/raid, whisper, raidwarning)
	["opt_name_raidparty"] = "Banda/Grupo",
	["opt_desc_raidparty"] = "Muestra las alertas de OptiTaunt en Grupo o Chat de Banda.",
	["opt_name_say"] = "Decir",
	["opt_desc_say"] = "Muestra las alertas de OptiTaunt en el canal de chat normal.",
	["opt_name_yell"] = "Yell",
	["opt_desc_yell"] = "Shows OptiTaunt warning via /yell.",
	["opt_name_autowhisper"] = "Susurrar",
	["opt_desc_autowhisper"] = "Susurra automaticamente una alerta al jugador que es ahora el objetivo del mob que resistió el Taunt.",
	["opt_name_raidwarning"] = "Alerta de Banda",
	["opt_desc_raidwarning"] = "Muestra las alertas de OptiTaunt como Alerta de Banda (estando en Banda necesitas Promote).",
	--SpellLink
	["opt_name_spelllink"] = "SpellLink instead of SpellName",
	["opt_desc_spelllink"] = "Post the click-able SpellLink instead of the standard SpellName.",
	--Audio
	["opt_name_audio"] = "Alerta sonora",
	["opt_desc_audio"] = "Hace sonar una alerta sonora cuando alguno de tus taunts es resistido.",
	--Aggro Check
	["opt_name_aggrocheck"] = "Comprobar aggro",
	["opt_desc_aggrocheck"] = "OptiTaunt sólo mandará mensajes si el Taunt falla en un objetivo del que NO retienes todavía el aggro.",
	--PvP Check	
	["opt_name_pvpcheck"] = "Check PvP",
	["opt_desc_pvpcheck"] = "No hacer alertas estando en PvP.",
	--Whisper Warriors
	["opt_name_whisperwarriors"] = "Susurrar a Guerreros",
	["opt_desc_whisperwarriors"] = "OptiTaunt susurrará incluso a otros Guerreros si alguno de tus Taunts es resistido.",
	--SinkLib
	["opt_name_output_sink"] = "Salida (via SinkLib)",
	--Announce
	["opt_name_output"] = "Salida (Chat)",
	["opt_desc_output"] = "En que canales de chat se mostrarán los anuncios.",
	["opt_name_outputchannel"] = "Salida (Canales)",
	["opt_desc_outputchannel"] = "En que canales privados se mostrarán los anuncios.",
	--Additional Options
	["opt_name_options"] = "Opciones adicionales",
	["opt_desc_options"] = "Opciones adicionales",
	--Taunt Counter / Statistics
	["Reset counters"] = "Resetear contador de taunts",
	["opt_desc_resetcounters"] = "Vuelve a poner a 0 el contador para las estadísticas de Taunts.",
	["PrintTauntStatistics"] = "Announce taunt statistics",
	["opt_desc_printtauntstatistics"] = "Announces your taunt statistics in group or raid chat.",
	
	
--Announce Options
	
	--resist
	["opt_name_announceresist"] = "Anunciar Resists",
	["opt_desc_announceresist"] = "Activa o desactiva los anuncios de Taunts resistidos.",
	--immune
	["opt_name_announceimmue"] = "Anunciar inmunes",
	["opt_desc_announceimmue"] = "Activa o desactiva los anuncios de mobs inmunes a Taunts.",
	
	--ability
	["opt_name_announceability"] = "Anunciar habilidades",
	["opt_desc_announceability"] = "Activa o desactiva los anuncios de habiilidades activadas.",
	--ability END
	["opt_name_announceabilityend"] = "Announce end of abilites",
	["opt_desc_announceabilityend"] = "Turns announcements of fading abilities on or off.\n Requires 'Announce abilites'.",
	
	--ability on target
	["opt_name_announceabilityontarget"] = "Announce abilites used on target",
	["opt_desc_announceabilityontarget"] = "Turns announcements of abilities used on target on or off.",
	--ability on target END
	["opt_name_announceabilityontargetend"] = "Announce end of abilites used on target",
	["opt_desc_announceabilityontargetend"] = "Turns announcements of fading abilities used on target on or off.\n Requires 'Announce abilites'.",
	
	--disarm
	["opt_name_announcedisarm"] = "Announce disarm",
	["opt_desc_announcedisarm"] = "Turns announcements of disarm on or off.",
	--disarm END
	["opt_name_announcedisarmend"] = "Announce end of disarm",
	["opt_desc_announcedisarmend"] = "Turns announcements of fading disarm on or off.\n Requires 'Announce disarm'.",
	
	--debuff
	["opt_name_announcedebuff"] = "Announce debuff",
	["opt_desc_announcedebuff"] = "Turns announcements of debuff on or off.",
	--debuff END
	["opt_name_announcedebuffend"] = "Announce end of debuff",
	["opt_desc_announcedebuffend"] = "Turns announcements of fading debuff on or off.\n Requires 'Announce debuff'.",
	
	--stun
	["opt_name_announcedebuffstun"] = "Announce stun",
	["opt_desc_announcedebuffstun"] = "Turns announcements of stuns on or off.",
	--magic
	["opt_name_announcedebuffmagic"] = "Announce magic debuffs",
	["opt_desc_announcedebuffmagic"] = "Turns announcements of magic debuffs on or off.",
	--curse
	["opt_name_announcedebuffcurse"] = "Announce curse",
	["opt_desc_announcedebuffcurse"] = "Turns announcements of curses on or off.",
	--poison
	["opt_name_announcedebuffpoison"] = "Announce poison",
	["opt_desc_announcedebuffpoison"] = "Turns announcements of poisons on or off.",
	--disease
	["opt_name_announcedebuffdisease"] = "Announce disease",
	["opt_desc_announcedebuffdisease"] = "Turns announcements of stuns on or off.",
	--heal req.
	["opt_name_announcehealreq"] = "Announce healing debuffs",
	["opt_desc_announcehealreq"] = "Turns announcements of heal intensive debuffs on or off.",
	
	
--Message Text

	--resist
	["opt_name_resistmessage"] = "Mensaje de Alerta: resistido",
	["opt_usage_resistmessage"] = "\n{t}: targetname\n{a}: ability",
	
	--immune
	["opt_name_immunemessage"] = "Mensaje de Alerta: immune",
	["opt_usage_immunemessage"] = "\n{t}: targetname\n{a}: ability",
	
	--ability
	["opt_name_abilitymessage"] = "Mensaje de Alerta: habilidad activada",
	["opt_usage_abilitymessage"] = "\n{a}: ability\n{d}: duration",
	--ability END
	["opt_name_abilityendmessage"] = "Warningmessage: ability ends",
	["opt_usage_abilityendmessage"] = "\n{a}: ability",
	
	--ability on target
	["opt_name_abilityontargetmessage"] = "Warningmessage: activated ability on target",
	["opt_usage_abilityontargetmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	--ability on target END
	["opt_name_abilityontargetendmessage"] = "Warningmessage: ability on target expires",
	["opt_usage_abilityontargetendmessage"] = "\n{a}: ability\n{t}: target",
	
	--counterspell
	["opt_name_counterspellmessage"] = "Warningmessage: interrupted target's spellcast",
	["opt_usage_counterspellmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	
	--disarm
	["opt_name_disarmmessage"] = "Warningmessage: being disarmed",
	["opt_usage_disarmmessage"] = "\n{a}: ability\n{d}: duration",
	--disarm END
	["opt_name_disarmendmessage"] = "Warningmessage: being no longer disarmed",
	["opt_usage_disarmendmessage"] = "\n{a}: ability",
	
	--debuff
	["opt_name_debuffmessage"] = "Warningmessage: Debuff",
	["opt_usage_debuffmessage"] = "\n{a}: debuff\n{d}: duration",
	--debuff END
	["opt_name_debuffendmessage"] = "Warningmessage: Debuff ends",
	["opt_usage_debuffendmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--stun
	["opt_name_debuffstunmessage"] = "Warningmessage: Stun",
	["opt_usage_debuffstunmessage"] = "\n{a}: debuff\n{d}: duration",
	--magic
	["opt_name_debuffmagicmessage"] = "Warningmessage: Magic debuff",
	["opt_usage_debuffmagicmessage"] = "\n{a}: debuff\n{d}: duration",
	--curse
	["opt_name_debuffcursemessage"] = "Warningmessage: Curse",
	["opt_usage_debuffcursemessage"] = "\n{a}: debuff\n{d}: duration",
	--poison
	["opt_name_debuffpoisonmessage"] = "Warningmessage: Poison",
	["opt_usage_debuffpoisonmessage"] = "\n{a}: debuff\n{d}: duration",
	--disease
	["opt_name_debuffdiseasemessage"] = "Warningmessage: Disease",
	["opt_usage_debuffdiseasemessage"] = "\n{a}: debuff\n{d}: duration",
	--heal req.
	["opt_name_healreqmessage"] = "Warningmessage: Heal needed",
	["opt_usage_healreqmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--PullTimer
	["opt_name_countmessage"] = "Countdown message",
	["opt_usage_countmessage"] = "\n{d}: duration",
	["opt_name_pullmessage"] = "Pull message",
	["opt_usage_pullmessage"] = "",
	["opt_name_pullscale"] = "Pull time (seconds)",
	["opt_usage_pullscale"] = "Time in seconds until pull (3 - 20 sec)",
	["Output"] = "Output channels",
	
--Menu Text

	--Message Text
	["opt_name_messagetexts"] = "Mensajes de Alerta",
	["opt_desc_messagetexts"] = "Edita tus mensajes de Alertas.",
	
	--Announcement Settings
	["opt_name_announcesettings"] = "Announcements",
	["opt_desc_announcesettings"] = "What should be announced.",	
	
	--ability
	["opt_name_announces"] = "Anuncios de habilidades",
	["opt_desc_announces"] = "Qué habilidades deben anunciarse.",
	--disarm
	["opt_name_disarm_announces"] = "Disarms",
	["opt_desc_disarm_announces"] = "Which disarms should be announced.",
	--debuff
	["opt_name_debuff_announces"] = "Debuffs",
	["opt_desc_debuff_announces"] = "Which debuffs should be announced.",
	--stun
	["opt_name_debuff_stun_announces"] = "Stun effects",
	["opt_desc_debuff_stun_announces"] = "Which stun effects should be announced?",
	--magic
	["opt_name_debuff_magic_announces"] = "Magic debuffs",
	["opt_desc_debuff_magic_announces"] = "Which magic debuffs should be announced?",
	--curse
	["opt_name_debuff_curse_announces"] = "Curse",
	["opt_desc_debuff_curse_announces"] = "Which curses should be announced?",
	--poison
	["opt_name_debuff_poison_announces"] = "Poison",
	["opt_desc_debuff_poison_announces"] = "Which poisons should be announced?",
	--disease
	["opt_name_debuff_disease_announces"] = "Disease",
	["opt_desc_debuff_disease_announces"] = "Which diseases should be announced?",
	--heal req.
	["opt_name_healreq_announces"] = "Healing debuffs",
	["opt_desc_healreq_announces"] = "Which healing debuffs should be announced?",
	--ability on target
		--none so far (handled via ability_announce - 0.93)
	
	--PullTimer
	["opt_name_pulltimeroptions"] = "PullTimer Options",
	["opt_desc_pulltimeroptions"] = "Set message texts and time.",
	
} end)