﻿local L = AceLibrary("AceLocale-2.2"):new("OptiTaunt")

L:RegisterTranslations("deDE", function() return {
--Addon Stuff
	["Tooltip"] = "Rechtsklick f\195\188r Optionen.",
	["Slash-Commands"] = { "/optitaunt", "/ot" },
	
	["Statistics"] = "Statistiken",
	["Taunts"] = "Gespottet:",
	["Resisted"] = "Widerstanden:",
	
--Messages
	["resistmessage"] = "ACHTUNG! {t} hat meinem {a} widerstanden!",
	["immunemessage"] = "ACHTUNG! {t} ist immun gegen meine Fähigkeit {a}!",
	
	["abilitymessage"] = "+++ {a} aktiviert ({d}s) +++",
	["abilityendmessage"] = "--- {a} endet ---",
	
	["abilityontargetmessage"] = "+++ {a} auf {t} aktiviert ({d}s) +++",
	["abilityontargetendmessage"] = "--- {a} auf {t} endet ---",
	
	["instantcastmessage"] = "{a} auf {t} gezaubert",	
	
	["counterspellmessage"] = "{s} von {t} unterbrochen  ({d}s)",
	
	["procmessage"] = " {a} wurde ausgelöst ",		
	
	["disarmmessage"] = ">>> {a}! ENTWAFFNET ({d}s) <<<",
	["disarmendmessage"] = "<<< {a} endet. Wiederbewaffnet >>>",
	
	["debuffmessage"] = ">>> {a} ({d}s) <<<",
	["debuffendmessage"] = "<<< {a} endet. >>>",
	
	["debuffstunmessage"] = ">>> {a} ({d}s) - STUNNED <<<",
	["debuffmagicmessage"] = ">>> {a} ({d}s) - MAGIE entfernen <<<",
	["debuffcursemessage"] = ">>> {a} ({d}s) - ENTFLUCHEN <<<",
	["debuffpoisonmessage"] = ">>> {a} ({d}s) - ENTGIFTEN <<<",
	["debuffdiseasemessage"] = ">>> {a} ({d}s) - KRANKHEIT entfernen <<<",
	["healreqmessage"] = ">>> {a} ({d}s) - HEIL MICH AUF 100% <<<",
	["pullcountmessage"] = "Pull in {d} Sekunden.",
	["pullmessage"] = ">>>>>> PULL <<<<<<",
	["pulltimerrange"] = 3,
	
	
--Whisper Strings
	["Resist-Whisper-Message-Warrior"] = "Aber zum Glück hältst du ja auch einiges aus. :-)",
	["Resist-Whisper-Message-Druid"] = "Bärform ftw! :-)",
	["Resist-Whisper-Message-Paladin"] = "Beim Hammer der Gerechtigkeit, du bist auf dich allein gestellt! :-)",
	["Resist-Whisper-Message-Mage"] = "EISBLOCK, EISBLOCK, EISBLOCK! :-)",
	["Resist-Whisper-Message-Warlock"] = "Wo steckt dein Leerwandler wenn man ihn mal braucht? :-)",
	["Resist-Whisper-Message-Hunter"] = "Zeig, dass du ein guter Schauspieler bist und stell dich tot! :-)",
	["Resist-Whisper-Message-Rogue"] = "Zeit für einen beherzten Sprint! :-)",
	["Resist-Whisper-Message-Priest"] = "Zeit für ein letztes Gebet... :-)",
	["Resist-Whisper-Message-Shaman"] = "Du und deine Totems, ihr seid auf euch allein gestellt! :-)",
	["Resist-Whisper-Message-Deathknight"] = "Frostpräsenz ftw! :-)",
	
	
--Options
	--Chat (say, group/raid, whisper, raidwarning)
	["opt_name_raidparty"] = "Raid/Gruppe",
	["opt_desc_raidparty"] = "Zeigt OptiTaunt Warnungen im Gruppen- oder Raidchat.",
	["opt_name_say"] = "Sagen",
	["opt_desc_say"] = "Zeigt OptiTaunt Warnungen im Sagenchat.",
	["opt_name_yell"] = "Schreien",
	["opt_desc_yell"] = "Zeigt OptiTaunt Warnungen via /yell.",
	["opt_name_autowhisper"] = "Flüstern",
	["opt_desc_autowhisper"] = "Flüstert automatisch Warnungen an den Spieler, der Aggro von dem Mob hat, das gerade dem Spott widerstanden hat.",
	["opt_name_raidwarning"] = "Raidwarnung",
	["opt_desc_raidwarning"] = "Zeigt OptiTaunt Warnungen als Raidwarnung.",
	--SpellLink
	["opt_name_spelllink"] = "SpellLink instead of SpellName",
	["opt_desc_spelllink"] = "Post the click-able SpellLink instead of the standard SpellName.",
	--Audio
	["opt_name_audio"] = "Audio-Warnungen",
	["opt_desc_audio"] = "Spielt Warnungssound bei widerstandenem Spott.",
	--Aggro Check
	["opt_name_aggrocheck"] = "Aggro-Check",
	["opt_desc_aggrocheck"] = "Warnt nur wenn man selbst nicht schon die Aggro hat.",
	--PvP Check
	["opt_name_pvpcheck"] = "PvP-Check",
	["opt_desc_pvpcheck"] = "Keine Warnungen, wenn wir uns im PvP befinden.",
	--Whisper Warriors
	["opt_name_whisperwarriors"] = "Kriegern zuflüstern",
	["opt_desc_whisperwarriors"] = "OptiTaunt wird selbst Kriegern eine Warnung zuflüstern wenn einem Spott widerstanden wurde.",
	--SinkLib
	["opt_name_output_sink"] = "Ausgabeoptionen (via SinkLib)",
	--Announce
	["opt_name_output"] = "Ausgabeoptionen (Chat)",
	["opt_desc_output"] = "In welchem Chat die Ausgaben gemacht werden sollen.",
	["opt_name_outputchannel"] = "Ausgabeoptionen (Channel)",
	["opt_desc_outputchannel"] = "In welchen Channeln die Ausgaben gemacht werden sollen.",
	--Additional Options
	["opt_name_options"] = "Weitere Optionen",
	["opt_desc_options"] = "Weitere Optionen.",
	--Taunt Counter / Statistics
	["Reset counters"] = "Spott-Zähler zurücksetzen",
	["opt_desc_resetcounters"] = "Setzt den Zähler der bisherigen Spott-Statistik zurück.",	
	["PrintTauntStatistics"] = "Spott-Statistiken publizieren",
	["opt_desc_printtauntstatistics"] = "Zeigt deine Spott-Statistik in der Gruppe / im Raid.",


--Announce Options

	--resist
	["opt_name_announceresist"] = "Widerstehen ansagen",
	["opt_desc_announceresist"] = "Schaltet Meldungen von widerstandenen Aktionen an und aus.",
	--immune
	["opt_name_announceimmue"] = "Immun ansagen",
	["opt_desc_announceimmue"] = "Schaltet Meldungen von immunen Aktionen an und aus.",
	
	--ability
	["opt_name_announceability"] = "Fähigkeiten ansagen",
	["opt_desc_announceability"] = "Schaltet Meldungen von eingesetzten Fähigkeiten an und aus.",
	--ability END
	["opt_name_announceabilityend"] = "Ende von Fähigkeiten ansagen",
	["opt_desc_announceabilityend"] = "Schaltet Meldungen von auslaufenden Fähigkeiten an und aus.\n Setzt 'Fähigkeiten ansagen' voraus.",
	
	--ability on target
	["opt_name_announceabilityontarget"] = "Fähigkeiten, auf Ziel angewendet, ansagen",
	["opt_desc_announceabilityontarget"] = "Schaltet Meldungen von auf das Ziel angewendeten Fähigkeiten an und aus.",
	--ability on target END
	["opt_name_announceabilityontargetend"] = "Ende von Fähigkeiten ansagen",
	["opt_desc_announceabilityontargetend"] = "Schaltet Meldungen von auslaufenden, auf das Ziel angewendet, Fähigkeiten an und aus.\n Setzt 'Fähigkeiten ansagen' voraus.",
	
	--disarm
	["opt_name_announcedisarm"] = "Entwaffnung ansagen",
	["opt_desc_announcedisarm"] = "Schaltet die Meldung, wenn du entwaffnet bist,  an und aus.",
	--disarm END
	["opt_name_announcedisarmend"] = "Ende von Entwaffnen ansagen",
	["opt_desc_announcedisarmend"] = "Schaltet die Meldung, wenn du nicht mehr entwaffnet bist, an und aus.\n Setzt 'Entwaffnung ansagen' voraus.",
	
	--debuff
	["opt_name_announcedebuff"] = "Debuffs ansagen",
	["opt_desc_announcedebuff"] = "Schaltet die Meldung von Debuffs an und aus.",
	--debuff END
	["opt_name_announcedebuffend"] = "Ende von Debuffs ansagen",
	["opt_desc_announcedebuffend"] = "Schaltet die Meldung von auslaufenden Debuffs an und aus.\n Setzt 'Debuffs ansagen' voraus.",
	
	--stun
	["opt_name_announcedebuffstun"] = "Stun ansagen",
	["opt_desc_announcedebuffstun"] = "Schaltet die Meldung von Stun-Effekten an und aus.",
	--magic
	["opt_name_announcedebuffmagic"] = "Magie-Debuffs ansagen",
	["opt_desc_announcedebuffmagic"] = "Schaltet die Meldung von Magie-Debuffs an und aus.",
	--curse
	["opt_name_announcedebuffcurse"] = "Flüche ansagen",
	["opt_desc_announcedebuffcurse"] = "Schaltet die Meldung von Flüchen an und aus.",
	--poison
	["opt_name_announcedebuffpoison"] = "Gifte ansagen",
	["opt_desc_announcedebuffpoison"] = "Schaltet die Meldung von Giften an und aus.",
	--disease
	["opt_name_announcedebuffdisease"] = "Krankheiten ansagen",
	["opt_desc_announcedebuffdisease"] = "Schaltet die Meldung von Krankheiten an und aus.",
	--heal req.
	["opt_name_announcehealreq"] = "Heilungs-Debuffs ansagen",
	["opt_desc_announcehealreq"] = "Schaltet die Meldung von Heilungs-intensiven Debuffs an und aus.",	

	
--Message Text
	
	--resist
	["opt_name_resistmessage"] = "Meldungstext: widerstehen",
	["opt_usage_resistmessage"] = "\n{t}: Name des Ziels\n{a}: Fähigkeit",
	
	--immune
	["opt_name_immunemessage"] = "Meldungstext: immun",
	["opt_usage_immunemessage"] = "\n{t}: Name des Ziels\n{a}: Fähigkeit",
	
	--ability
	["opt_name_abilitymessage"] = "Meldungstext: Fähigkeit eingesetzt",
	["opt_usage_abilitymessage"] = "\n{a}: Fähigkeit\n{d}: Dauer der Fähigkeit",
	--ability END
	["opt_name_abilityendmessage"] = "Meldungstext: Fähigkeit endet",
	["opt_usage_abilityendmessage"] = "\n{a}: Fähigkeit",
	
	--ability on target
	["opt_name_abilityontargetmessage"] = "Meldungstext: Fähigkeit auf Ziel eingesetzt",
	["opt_usage_abilityontargetmessage"] = "\n{a}: Fähigkeit\n{t}: Ziel\n{d}: Dauer der Fähigkeit",
	--ability on target END
	["opt_name_abilityontargetendmessage"] = "Meldungstext: Fähigkeit auf Ziel endet",
	["opt_usage_abilityontargetendmessage"] = "\n{a}: Fähigkeit\n{t}: Ziel",
	
	--counterspell
	["opt_name_counterspellmessage"] = "Meldungstext: Zauber des Ziel's unterbrochen",
	["opt_usage_counterspellmessage"] = "\n{a}: Fähigkeit\n{t}: Ziel\n{d}: Dauer der Fähigkeit",
	
	--disarm
	["opt_name_disarmmessage"] = "Meldungstext: Entwaffnet sein",
	["opt_usage_disarmmessage"] = "\n{a}: Fähigkeit\n{d}: Dauer der Fähigkeit",
	--disarm END
	["opt_name_disarmendmessage"] = "Meldungstext: Nicht mehr entwaffnet sein",
	["opt_usage_disarmendmessage"] = "\n{a}: Fähigkeit",
	
	--debuff
	["opt_name_debuffmessage"] = "Meldungstext: Debuff",
	["opt_usage_debuffmessage"] = "\n{a}: Debuff\n{d}: Dauer des Debuffs",
	--debuff END
	["opt_name_debuffendmessage"] = "Meldungstext: Debuff endet",
	["opt_usage_debuffendmessage"] = "\n{a}: Debuff\n{d}: Dauer des Debuffs",
	
	--stun
	["opt_name_debuffstunmessage"] = "Meldungstext: Stun",
	["opt_usage_debuffstunmessage"] = "\n{a}: Debuff\n{d}: Dauer des Stuns",
	--magic
	["opt_name_debuffmagicmessage"] = "Meldungstext: Magie-Debuff",
	["opt_usage_debuffmagicmessage"] = "\n{a}: Debuff\n{d}: Dauer des Magie-Debuffs",
	--curse
	["opt_name_debuffcursemessage"] = "Meldungstext: Fluch",
	["opt_usage_debuffcursemessage"] = "\n{a}: Debuff\n{d}: Dauer des Fluchs",
	--poison
	["opt_name_debuffpoisonmessage"] = "Meldungstext: Gift",
	["opt_usage_debuffpoisonmessage"] = "\n{a}: Debuff\n{d}: Dauer des Gift-Debuffs",
	--disease
	["opt_name_debuffdiseasemessage"] = "Meldungstext: Krankheit",
	["opt_usage_debuffdiseasemessage"] = "\n{a}: Debuff\n{d}: Dauer des Krankheits-Debuffs",
	--heal req.	
	["opt_name_healreqmessage"] = "Meldungstext: Heilung benötigt",
	["opt_usage_healreqmessage"] = "\n{a}: Debuff\n{d}: Dauer des Debuffs",	
	
	--PullTimer
	["opt_name_countmessage"] = "Countdown-Nachricht",
	["opt_usage_countmessage"] = "\n{d}: duration",
	["opt_name_pullmessage"] = "Pull-Nachricht",
	["opt_usage_pullmessage"] = "",
	["opt_name_pullscale"] = "Pull-Zeit (Sekunden)",
	["opt_usage_pullscale"] = "Zeit in Sekunden bis zum Pull (3 - 20 sek)",
	["Output"] = "Ausgabe-Channel",
	
--Menu Text

	--Message Text
	["opt_name_messagetexts"] = "Meldungstexte",
	["opt_desc_messagetexts"] = "Die Meldungstexte frei editieren.",
	
	--Announcement Settings
	["opt_name_announcesettings"] = "Meldungen",
	["opt_desc_announcesettings"] = "Einstellung, was gemeldet werden soll.",
	
	--ability
	["opt_name_announces"] = "Fähigkeiten",
	["opt_desc_announces"] = "Welche Fähigkeiten sollen angekündigt werden.",
	--disarm
	["opt_name_disarm_announces"] = "Entwaffnungen",
	["opt_desc_disarm_announces"] = "Welche Entwaffnungen sollen angekündigt werden?",
	--debuff
	["opt_name_debuff_announces"] = "Debuffs",
	["opt_desc_debuff_announces"] = "Welche Debuffs sollen angekündigt werden?",
	--stun
	["opt_name_debuff_stun_announces"] = "Stun-Effekte",
	["opt_desc_debuff_stun_announces"] = "Welche Stun-Effekte sollen angekündigt werden?",
	--magic
	["opt_name_debuff_magic_announces"] = "Magie-Debuffs",
	["opt_desc_debuff_magic_announces"] = "Welche Magie-Debuffs sollen angekündigt werden?",
	--curse
	["opt_name_debuff_curse_announces"] = "Flüche",
	["opt_desc_debuff_curse_announces"] = "Welche Flüche sollen angekündigt werden?",
	--poison
	["opt_name_debuff_poison_announces"] = "Gifte",
	["opt_desc_debuff_poison_announces"] = "Welche Gifte sollen angekündigt werden?",
	--disease
	["opt_name_debuff_disease_announces"] = "Krankheiten",
	["opt_desc_debuff_disease_announces"] = "Welche Krankheiten sollen angekündigt werden?",
	--heal req.
	["opt_name_healreq_announces"] = "Heilungs-Debuffs",
	["opt_desc_healreq_announces"] = "Welche Heilungs-Debuffs sollen angekündigt werden?",
	--ability on target
		--none so far (handled via ability_announce - 0.93)
	
	--PullTimer
	["opt_name_pulltimeroptions"] = "PullTimer-Optionen",
	["opt_desc_pulltimeroptions"] = "Nachrichten- und Zeit-Einstellungen.",

} end)