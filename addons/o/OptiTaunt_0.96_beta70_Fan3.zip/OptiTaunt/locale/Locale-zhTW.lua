﻿local L = AceLibrary("AceLocale-2.2"):new("OptiTaunt")

L:RegisterTranslations("zhTW", function() return {
--Addon Stuff
	["Tooltip"] = "右鍵點擊開啟選項.",
	["Slash-Commands"] = { "/optitaunt", "/ot" },
	
	["Statistics"] = "統計資料",
	["Taunts"] = "嘲諷次數:",
	["Resisted"] = "被抵抗次數:",
	
--Messages
	["resistmessage"] = "注意! {t} 抵抗了我的 {a}!",
	["immunemessage"] = "注意! {t} 免疫我的技能 {a}!",
	
	["abilitymessage"] = "+++ {a} 開啟了 ({d}s) +++",
	["abilityendmessage"] = "--- {a} ends ---",	
	
	["abilityontargetmessage"] = "+++ {a} activated on {t} ({d}s) +++",
	["abilityontargetendmessage"] = "--- {a} on {t} ends ---",	
	
	["instantcastmessage"] = "{a} casted on {t}",	
	
	["counterspellmessage"] = "Kicked {s} by {t}  ({d}s)",
	
	["procmessage"] = " {a} has proc'ed",	
	
	["disarmmessage"] = ">>> {a}! I am DISARMED ({d}s) <<<",
	["disarmendmessage"] = "<<< {a} fades. I am REARMED >>>",
	
	["debuffmessage"] = ">>> {a} ({d}s) <<<",
	["debuffendmessage"] = "<<< {a} ends. >>>",
	
	["debuffstunmessage"] = ">>> {a} ({d}s) - STUNNED<<<",
	["debuffmagicmessage"] = ">>> {a} ({d}s) - DISPEL<<<",
	["debuffcursemessage"] = ">>> {a} ({d}s) - DECURSE<<<",
	["debuffpoisonmessage"] = ">>> {a} ({d}s) - CURE POISON<<<",
	["debuffdiseasemessage"] = ">>> {a} ({d}s) - ABOLISH DISEASE<<<",
	["healreqmessage"] = ">>> {a} ({d}s) - HEAL ME TO 100%<<<",
	["pullcountmessage"] = "Pull in {d} seconds.",
	["pullmessage"] = ">>>>>> PULL <<<<<<",
	["pulltimerrange"] = 3,
	
	
--Whisper Strings
	["Resist-Whisper-Message-Warrior"] = "啊! 幸好你能多撐幾下.",
	["Resist-Whisper-Message-Druid"] = "變熊才是王道!",
	["Resist-Whisper-Message-Paladin"] = "快拿出你的正義之鎚敲下去!",
	["Resist-Whisper-Message-Mage"] = "冰箱, 冰箱, 快冰箱!",
	["Resist-Whisper-Message-Warlock"] = "你可能極需粉碎?",
	["Resist-Whisper-Message-Hunter"] = "拿出你最帥的姿勢假死吧!",
	["Resist-Whisper-Message-Rogue"] = "還能消失吧?",
	["Resist-Whisper-Message-Priest"] = "祈禱吧...",
	["Resist-Whisper-Message-Shaman"] = "你先跟你的圖騰待一下吧",
	["Resist-Whisper-Message-Deathknight"] = "Frost Presence ftw! :-)",
	
	
--Options
	--Chat (say, group/raid, whisper, raidwarning)
	["opt_name_raidparty"] = "團隊/隊伍",
	["opt_desc_raidparty"] = "發佈 OptiTaunt 警告在隊伍或是團隊頻道.",
	["opt_name_say"] = "說",
	["opt_desc_say"] = "發佈 OptiTaunt 警告在說話頻.",
	["opt_name_yell"] = "Yell",
	["opt_desc_yell"] = "Shows OptiTaunt warning via /yell.",
	["opt_name_autowhisper"] = "密語",
	["opt_desc_autowhisper"] = "自動密語警告給玩家當未取得目標仇恨而嘲諷失敗時發出警告.",
	["opt_name_raidwarning"] = "團隊警告",
	["opt_desc_raidwarning"] = "發佈 Optitaunt 警告為團隊警告.",
	--SpellLink
	["opt_name_spelllink"] = "SpellLink instead of SpellName",
	["opt_desc_spelllink"] = "Post the click-able SpellLink instead of the standard SpellName.",
	--Audio
	["opt_name_audio"] = "音效警告",
	["opt_desc_audio"] = "播放音效警告當你嘲諷失敗時.",
	--Aggro Check
	["opt_name_aggrocheck"] = "檢查 aggro",
	["opt_desc_aggrocheck"] = "OptiTaunt 只會在你未取得aggro而嘲諷失敗時發出警告.",
	--PvP Check
	["opt_name_pvpcheck"] = "檢查 PvP",
	["opt_desc_pvpcheck"] = "PVP 時,不發佈警告.",
	--Whisper Warriors
	["opt_name_whisperwarriors"] = "密語戰士",
	["opt_desc_whisperwarriors"] = "OptiTaunt 會自動密語戰士當你嘲諷失敗時.",
	--SinkLib
	["opt_name_output_sink"] = "輸出 (經由 SinkLib)",
	--Announce
	["opt_name_output"] = "輸出 (聊天)",
	["opt_desc_output"] = "在哪個聊天發佈你的警告.",
	["opt_name_outputchannel"] = "輸出 (頻道)",
	["opt_desc_outputchannel"] = "在哪個頻道發佈你的警告.",
	--Additional Options
	["opt_name_options"] = "其他選項",
	["opt_desc_options"] = "其他選項",
	--Taunt Counter / Statistics
	["Reset counters"] = "重置計數器",
	["opt_desc_resetcounters"] = "重置嘲諷統計計數器.",
	["PrintTauntStatistics"] = "Announce taunt statistics",
	["opt_desc_printtauntstatistics"] = "Announces your taunt statistics in group or raid chat.",
	
	
--Announce Options
	
	--resist
	["opt_name_announceresist"] = "發佈抵抗",
	["opt_desc_announceresist"] = "是否開啟抵抗發佈功能.",
	--immune
	["opt_name_announceimmue"] = "發佈免疫",
	["opt_desc_announceimmue"] = "是否開啟免疫發佈功能.",
	
	--ability
	["opt_name_announceability"] = "發佈技能",
	["opt_desc_announceability"] = "是否開啟技能使用發佈功能.",
	--ability END
	["opt_name_announceabilityend"] = "Announce end of abilites",
	["opt_desc_announceabilityend"] = "Turns announcements of fading abilities on or off.\n Requires 'Announce abilites'.",

	--ability on target
	["opt_name_announceabilityontarget"] = "Announce abilites used on target",
	["opt_desc_announceabilityontarget"] = "Turns announcements of abilities used on target on or off.",
	--ability on target END
	["opt_name_announceabilityontargetend"] = "Announce end of abilites used on target",
	["opt_desc_announceabilityontargetend"] = "Turns announcements of fading abilities used on target on or off.\n Requires 'Announce abilites'.",
	
	--disarm
	["opt_name_announcedisarm"] = "Announce disarm",
	["opt_desc_announcedisarm"] = "Turns announcements of disarm on or off.",
	--disarm END
	["opt_name_announcedisarmend"] = "Announce end of disarm",
	["opt_desc_announcedisarmend"] = "Turns announcements of fading disarm on or off.\n Requires 'Announce disarm'.",
	
	--debuff
	["opt_name_announcedebuff"] = "Announce debuff",
	["opt_desc_announcedebuff"] = "Turns announcements of debuff on or off.",
	--debuff END
	["opt_name_announcedebuffend"] = "Announce end of debuff",
	["opt_desc_announcedebuffend"] = "Turns announcements of fading debuff on or off.\n Requires 'Announce debuff'.",
	
	--stun
	["opt_name_announcedebuffstun"] = "Announce stun",
	["opt_desc_announcedebuffstun"] = "Turns announcements of stuns on or off.",
	--magic
	["opt_name_announcedebuffmagic"] = "Announce magic debuffs",
	["opt_desc_announcedebuffmagic"] = "Turns announcements of magic debuffs on or off.",
	--curse
	["opt_name_announcedebuffcurse"] = "Announce curse",
	["opt_desc_announcedebuffcurse"] = "Turns announcements of curses on or off.",
	--poison
	["opt_name_announcedebuffpoison"] = "Announce poison",
	["opt_desc_announcedebuffpoison"] = "Turns announcements of poisons on or off.",
	--disease
	["opt_name_announcedebuffdisease"] = "Announce disease",
	["opt_desc_announcedebuffdisease"] = "Turns announcements of stuns on or off.",
	--heal req.
	["opt_name_announcehealreq"] = "Announce healing debuffs",
	["opt_desc_announcehealreq"] = "Turns announcements of heal intensive debuffs on or off.",
	
	
--Message Text

	--resist
	["opt_name_resistmessage"] = "訊息警告: 抵抗",
	["opt_usage_resistmessage"] = "\n{t}: 目標名\n{a}: 技能名",
	
	--immune
	["opt_name_immunemessage"] = "訊息警告: 免疫",
	["opt_usage_immunemessage"] = "\n{t}: 目標名\n{a}: 技能名",
	
	--ability
	["opt_name_abilitymessage"] = "訊息警告: 開啟的技能",
	["opt_usage_abilitymessage"] = "\n{a}: 技能\n{d}: 持續時間",
	--ability END
	["opt_name_abilityendmessage"] = "Warningmessage: ability ends",
	["opt_usage_abilityendmessage"] = "\n{a}: ability",
	
	--ability on target
	["opt_name_abilityontargetmessage"] = "Warningmessage: activated ability on target",
	["opt_usage_abilityontargetmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	--ability on target END
	["opt_name_abilityontargetendmessage"] = "Warningmessage: ability on target expires",
	["opt_usage_abilityontargetendmessage"] = "\n{a}: ability\n{t}: target",
	
	--counterspell
	["opt_name_counterspellmessage"] = "Warningmessage: interrupted target's spellcast",
	["opt_usage_counterspellmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	
	--disarm
	["opt_name_disarmmessage"] = "Warningmessage: being disarmed",
	["opt_usage_disarmmessage"] = "\n{a}: ability\n{d}: duration",
	--disarm END
	["opt_name_disarmendmessage"] = "Warningmessage: being no longer disarmed",
	["opt_usage_disarmendmessage"] = "\n{a}: ability",
	
	--debuff
	["opt_name_debuffmessage"] = "Warningmessage: Debuff",
	["opt_usage_debuffmessage"] = "\n{a}: debuff\n{d}: duration",
	--debuff END
	["opt_name_debuffendmessage"] = "Warningmessage: Debuff ends",
	["opt_usage_debuffendmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--stun
	["opt_name_debuffstunmessage"] = "Warningmessage: Stun",
	["opt_usage_debuffstunmessage"] = "\n{a}: debuff\n{d}: duration",
	--magic
	["opt_name_debuffmagicmessage"] = "Warningmessage: Magic debuff",
	["opt_usage_debuffmagicmessage"] = "\n{a}: debuff\n{d}: duration",
	--curse
	["opt_name_debuffcursemessage"] = "Warningmessage: Curse",
	["opt_usage_debuffcursemessage"] = "\n{a}: debuff\n{d}: duration",
	--poison
	["opt_name_debuffpoisonmessage"] = "Warningmessage: Poison",
	["opt_usage_debuffpoisonmessage"] = "\n{a}: debuff\n{d}: duration",
	--disease
	["opt_name_debuffdiseasemessage"] = "Warningmessage: Disease",
	["opt_usage_debuffdiseasemessage"] = "\n{a}: debuff\n{d}: duration",
	--heal req.
	["opt_name_healreqmessage"] = "Warningmessage: Heal needed",
	["opt_usage_healreqmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--PullTimer
	["opt_name_countmessage"] = "Countdown message",
	["opt_usage_countmessage"] = "\n{d}: duration",
	["opt_name_pullmessage"] = "Pull message",
	["opt_usage_pullmessage"] = "",
	["opt_name_pullscale"] = "Pull time (seconds)",
	["opt_usage_pullscale"] = "Time in seconds until pull (3 - 20 sec)",
	["Output"] = "Output channels",
	
--Menu Text

	--Message Text
	["opt_name_messagetexts"] = "訊息警告",
	["opt_desc_messagetexts"] = "編輯你的訊息警告.",
	
	--Announcement Settings	
	["opt_name_announcesettings"] = "Announcements",
	["opt_desc_announcesettings"] = "What should be announced.",	
	
	--ability
	["opt_name_announces"] = "發佈技能",
	["opt_desc_announces"] = "發佈哪些技能.",
	--disarm
	["opt_name_disarm_announces"] = "Disarms",
	["opt_desc_disarm_announces"] = "Which disarms should be announced.",
	--debuff
	["opt_name_debuff_announces"] = "Debuffs",
	["opt_desc_debuff_announces"] = "Which debuffs should be announced.",
	--stun
	["opt_name_debuff_stun_announces"] = "Stun effects",
	["opt_desc_debuff_stun_announces"] = "Which stun effects should be announced?",
	--magic
	["opt_name_debuff_magic_announces"] = "Magic debuffs",
	["opt_desc_debuff_magic_announces"] = "Which magic debuffs should be announced?",
	--curse
	["opt_name_debuff_curse_announces"] = "Curse",
	["opt_desc_debuff_curse_announces"] = "Which curses should be announced?",
	--poison
	["opt_name_debuff_poison_announces"] = "Poison",
	["opt_desc_debuff_poison_announces"] = "Which poisons should be announced?",
	--disease
	["opt_name_debuff_disease_announces"] = "Disease",
	["opt_desc_debuff_disease_announces"] = "Which diseases should be announced?",
	--heal req.
	["opt_name_healreq_announces"] = "Healing debuffs",
	["opt_desc_healreq_announces"] = "Which healing debuffs should be announced?",
	--ability on target
		--none so far (handled via ability_announce - 0.93)

	--PullTimer
	["opt_name_pulltimeroptions"] = "PullTimer Options",
	["opt_desc_pulltimeroptions"] = "Set message texts and time.",

} end)