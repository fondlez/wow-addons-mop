﻿local L = AceLibrary("AceLocale-2.2"):new("OptiTaunt")

L:RegisterTranslations("enUS", function() return {
--Addon Stuff
	["Tooltip"] = "Rightclick for options.",
	["Slash-Commands"] = { "/optitaunt", "/ot" },
	
	["Statistics"] = "Statistics",
	["Taunts"] = "Taunts:",
	["Resisted"] = "Resisted:",
	
--Messages
	["resistmessage"] = "Warning! {t} resisted my {a}!",
	["immunemessage"] = "Warning! {t} is immune against my ability {a}!",
	
	["abilitymessage"] = "+++ {a} activated ({d}s) +++",
	["abilityendmessage"] = "--- {a} ends ---",	
	
	["abilityontargetmessage"] = "+++ {a} activated on {t} ({d}s) +++",
	["abilityontargetendmessage"] = "--- {a} on {t} ends ---",
	
	["instantcastmessage"] = "{a} casted on {t}",	
	
	["counterspellmessage"] = "Kicked {s} by {t}  ({d}s)",
	
	["procmessage"] = " {a} has proc'ed",	
	
	["disarmmessage"] = ">>> {a}! I am DISARMED ({d}s) <<<",
	["disarmendmessage"] = "<<< {a} fades. I am REARMED >>>",
	
	["debuffmessage"] = ">>> {a} ({d}s) <<<",
	["debuffendmessage"] = "<<< {a} ends. >>>",
	
	["debuffstunmessage"] = ">>> {a} ({d}s) - STUNNED<<<",
	["debuffmagicmessage"] = ">>> {a} ({d}s) - DISPEL<<<",
	["debuffcursemessage"] = ">>> {a} ({d}s) - DECURSE<<<",
	["debuffpoisonmessage"] = ">>> {a} ({d}s) - CURE POISON<<<",
	["debuffdiseasemessage"] = ">>> {a} ({d}s) - ABOLISH DISEASE<<<",
	["healreqmessage"] = ">>> {a} ({d}s) - HEAL ME TO 100%<<<",
	["pullcountmessage"] = "Pull in {d} seconds.",
	["pullmessage"] = ">>>>>> PULL <<<<<<",
	["pulltimerrange"] = 3,
	
	
--Whisper Strings
	["Resist-Whisper-Message-Warrior"] = "But fortunately you are able to take some hits yourself. :-)",
	["Resist-Whisper-Message-Druid"] = "Bearform ftw! :-)",
	["Resist-Whisper-Message-Paladin"] = "By the Hammer of Justice, you are on your own for a while. :-)",
	["Resist-Whisper-Message-Mage"] = "ICEBLOCK, ICEBLOCK, ICEBLOCK! :-)",
	["Resist-Whisper-Message-Warlock"] = "Where is your Voidwalker when you need him? :-)",
	["Resist-Whisper-Message-Hunter"] = "Show your acting skills and feign death! :-)",
	["Resist-Whisper-Message-Rogue"] = "Time for a sprint? :-)",
	["Resist-Whisper-Message-Priest"] = "Time for a last prayer... :-)",
	["Resist-Whisper-Message-Shaman"] = "You and your totems are on your own for a while! :-)",
	["Resist-Whisper-Message-Deathknight"] = "Frost Presence ftw! :-)",
	
	
--Options
	--Chat (say, group/raid, whisper, raidwarning)
	["opt_name_raidparty"] = "Raid/Party",
	["opt_desc_raidparty"] = "Shows OptiTaunt warning in party- or raidchat.",
	["opt_name_say"] = "Say",
	["opt_desc_say"] = "Shows OptiTaunt warning in saychat.",
	["opt_name_yell"] = "Yell",
	["opt_desc_yell"] = "Shows OptiTaunt warning via /yell.",
	["opt_name_autowhisper"] = "Whisper",
	["opt_desc_autowhisper"] = "Automatically whispers a warning to the player which has aggro of the mob which resisted your taunt.",
	["opt_name_raidwarning"] = "Raidwarning",
	["opt_desc_raidwarning"] = "Shows Optitaunt warning as raidwarning.",
	--SpellLink
	["opt_name_spelllink"] = "SpellLink instead of SpellName",
	["opt_desc_spelllink"] = "Post the click-able SpellLink instead of the standard SpellName.",
	--Audio
	["opt_name_audio"] = "Audio warning",
	["opt_desc_audio"] = "Plays an audio warning when your taunt resisted.",
	--Aggro Check
	["opt_name_aggrocheck"] = "Check aggro",
	["opt_desc_aggrocheck"] = "OptiTaunt will only give a warning if your taunt fails on a target of which you do not have aggro already.",
	--PvP Check
	["opt_name_pvpcheck"] = "Check PvP",
	["opt_desc_pvpcheck"] = "No warning when we do PvP.",
	--Whisper Warriors
	["opt_name_whisperwarriors"] = "Whisper warriors",
	["opt_desc_whisperwarriors"] = "OptiTaunt will Autowhisper even warriors if your taunt was resisted.",
	--SinkLib
	["opt_name_output_sink"] = "Output (via SinkLib)",
	--Announce
	["opt_name_output"] = "Output (Chat)",
	["opt_desc_output"] = "Which chat should announce your warnings.",
	["opt_name_outputchannel"] = "Output (Channel)",
	["opt_desc_outputchannel"] = "Which channels should announce your warnings.",
	--Additional Options
	["opt_name_options"] = "Additional options",
	["opt_desc_options"] = "Additional options",
	--Taunt Counter / Statistics
	["Reset counters"] = "Reset tauntcounter",
	["opt_desc_resetcounters"] = "Resets the counter of the taunt-statistics.",
	["PrintTauntStatistics"] = "Announce taunt statistics",
	["opt_desc_printtauntstatistics"] = "Announces your taunt statistics in group or raid chat.",
	
	
--Announce Options
	
	--resist
	["opt_name_announceresist"] = "Announce resists",
	["opt_desc_announceresist"] = "Turns announcements of resisted actions on or off.",
	--immune
	["opt_name_announceimmue"] = "Announce immune",
	["opt_desc_announceimmue"] = "Turns announcements of immune actions on or off.",
	
	--ability
	["opt_name_announceability"] = "Announce abilites",
	["opt_desc_announceability"] = "Turns announcements of abilities on or off.",
	--ability END
	["opt_name_announceabilityend"] = "Announce end of abilites",
	["opt_desc_announceabilityend"] = "Turns announcements of fading abilities on or off.\n Requires 'Announce abilites'.",

	--ability on target
	["opt_name_announceabilityontarget"] = "Announce abilites used on target",
	["opt_desc_announceabilityontarget"] = "Turns announcements of abilities used on target on or off.",
	--ability on target END
	["opt_name_announceabilityontargetend"] = "Announce end of abilites used on target",
	["opt_desc_announceabilityontargetend"] = "Turns announcements of fading abilities used on target on or off.\n Requires 'Announce abilites'.",
	
	--disarm
	["opt_name_announcedisarm"] = "Announce disarm",
	["opt_desc_announcedisarm"] = "Turns announcements of disarm on or off.",
	--disarm END
	["opt_name_announcedisarmend"] = "Announce end of disarm",
	["opt_desc_announcedisarmend"] = "Turns announcements of fading disarm on or off.\n Requires 'Announce disarm'.",
	
	--debuff
	["opt_name_announcedebuff"] = "Announce debuff",
	["opt_desc_announcedebuff"] = "Turns announcements of debuff on or off.",
	--debuff END
	["opt_name_announcedebuffend"] = "Announce end of debuff",
	["opt_desc_announcedebuffend"] = "Turns announcements of fading debuff on or off.\n Requires 'Announce debuff'.",
	
	--stun
	["opt_name_announcedebuffstun"] = "Announce stun",
	["opt_desc_announcedebuffstun"] = "Turns announcements of stuns on or off.",
	--magic
	["opt_name_announcedebuffmagic"] = "Announce magic debuffs",
	["opt_desc_announcedebuffmagic"] = "Turns announcements of magic debuffs on or off.",
	--curse
	["opt_name_announcedebuffcurse"] = "Announce curse",
	["opt_desc_announcedebuffcurse"] = "Turns announcements of curses on or off.",
	--poison
	["opt_name_announcedebuffpoison"] = "Announce poison",
	["opt_desc_announcedebuffpoison"] = "Turns announcements of poisons on or off.",
	--disease
	["opt_name_announcedebuffdisease"] = "Announce disease",
	["opt_desc_announcedebuffdisease"] = "Turns announcements of stuns on or off.",
	--heal req.
	["opt_name_announcehealreq"] = "Announce healing debuffs",
	["opt_desc_announcehealreq"] = "Turns announcements of heal intensive debuffs on or off.",
	
	
--Message Text

	--resist
	["opt_name_resistmessage"] = "Warningmessage: resist",
	["opt_usage_resistmessage"] = "\n{t}: targetname\n{a}: ability",
	
	--immune
	["opt_name_immunemessage"] = "Warningmessage: immune",
	["opt_usage_immunemessage"] = "\n{t}: targetname\n{a}: ability",
	
	--ability
	["opt_name_abilitymessage"] = "Warningmessage: activated ability",
	["opt_usage_abilitymessage"] = "\n{a}: ability\n{d}: duration",
	--ability END
	["opt_name_abilityendmessage"] = "Warningmessage: ability ends",
	["opt_usage_abilityendmessage"] = "\n{a}: ability",
	
	--ability on target
	["opt_name_abilityontargetmessage"] = "Warningmessage: activated ability on target",
	["opt_usage_abilityontargetmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	--ability on target END
	["opt_name_abilityontargetendmessage"] = "Warningmessage: ability on target expires",
	["opt_usage_abilityontargetendmessage"] = "\n{a}: ability\n{t}: target",
	
	--counterspell
	["opt_name_counterspellmessage"] = "Warningmessage: interrupted target's spellcast",
	["opt_usage_counterspellmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	
	--disarm
	["opt_name_disarmmessage"] = "Warningmessage: being disarmed",
	["opt_usage_disarmmessage"] = "\n{a}: ability\n{d}: duration",
	--disarm END
	["opt_name_disarmendmessage"] = "Warningmessage: being no longer disarmed",
	["opt_usage_disarmendmessage"] = "\n{a}: ability",
	
	--debuff
	["opt_name_debuffmessage"] = "Warningmessage: Debuff",
	["opt_usage_debuffmessage"] = "\n{a}: debuff\n{d}: duration",
	--debuff END
	["opt_name_debuffendmessage"] = "Warningmessage: Debuff ends",
	["opt_usage_debuffendmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--stun
	["opt_name_debuffstunmessage"] = "Warningmessage: Stun",
	["opt_usage_debuffstunmessage"] = "\n{a}: debuff\n{d}: duration",
	--magic
	["opt_name_debuffmagicmessage"] = "Warningmessage: Magic debuff",
	["opt_usage_debuffmagicmessage"] = "\n{a}: debuff\n{d}: duration",
	--curse
	["opt_name_debuffcursemessage"] = "Warningmessage: Curse",
	["opt_usage_debuffcursemessage"] = "\n{a}: debuff\n{d}: duration",
	--poison
	["opt_name_debuffpoisonmessage"] = "Warningmessage: Poison",
	["opt_usage_debuffpoisonmessage"] = "\n{a}: debuff\n{d}: duration",
	--disease
	["opt_name_debuffdiseasemessage"] = "Warningmessage: Disease",
	["opt_usage_debuffdiseasemessage"] = "\n{a}: debuff\n{d}: duration",
	--heal req.
	["opt_name_healreqmessage"] = "Warningmessage: Heal needed",
	["opt_usage_healreqmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--PullTimer
	["opt_name_countmessage"] = "Countdown message",
	["opt_usage_countmessage"] = "\n{d}: duration",
	["opt_name_pullmessage"] = "Pull message",
	["opt_usage_pullmessage"] = "",
	["opt_name_pullscale"] = "Pull time (seconds)",
	["opt_usage_pullscale"] = "Time in seconds until pull (3 - 20 sec)",
	["Output"] = "Output channels",
	
--Menu Text

	--Message Text
	["opt_name_messagetexts"] = "Warningmessages",
	["opt_desc_messagetexts"] = "Edit your warningmessages.",

	--Announcement Settings	
	["opt_name_announcesettings"] = "Announcements",
	["opt_desc_announcesettings"] = "What should be announced.",	
	
	--ability
	["opt_name_announces"] = "Announcing abilities",
	["opt_desc_announces"] = "Which abilities should be announced.",
	--disarm
	["opt_name_disarm_announces"] = "Disarms",
	["opt_desc_disarm_announces"] = "Which disarms should be announced.",
	--debuff
	["opt_name_debuff_announces"] = "Debuffs",
	["opt_desc_debuff_announces"] = "Which debuffs should be announced.",
	--stun
	["opt_name_debuff_stun_announces"] = "Stun effects",
	["opt_desc_debuff_stun_announces"] = "Which stun effects should be announced?",
	--magic
	["opt_name_debuff_magic_announces"] = "Magic debuffs",
	["opt_desc_debuff_magic_announces"] = "Which magic debuffs should be announced?",
	--curse
	["opt_name_debuff_curse_announces"] = "Curse",
	["opt_desc_debuff_curse_announces"] = "Which curses should be announced?",
	--poison
	["opt_name_debuff_poison_announces"] = "Poison",
	["opt_desc_debuff_poison_announces"] = "Which poisons should be announced?",
	--disease
	["opt_name_debuff_disease_announces"] = "Disease",
	["opt_desc_debuff_disease_announces"] = "Which diseases should be announced?",
	--heal req.
	["opt_name_healreq_announces"] = "Healing debuffs",
	["opt_desc_healreq_announces"] = "Which healing debuffs should be announced?",
	--ability on target
		--none so far (handled via ability_announce - 0.93)
	
	--PullTimer
	["opt_name_pulltimeroptions"] = "PullTimer Options",
	["opt_desc_pulltimeroptions"] = "Set message texts and time.",

} end)