local L = AceLibrary("AceLocale-2.2"):new("OptiTaunt")
  
L:RegisterTranslations("zhCN", function() return {
--Addon Stuff
	["Tooltip"] = "右键点击进入设置界面.",
	["Slash-Commands"] = { "/optitaunt", "/ot" },
	
	["Statistics"] = "统计",
	["Taunts"] = "嘲讽:",
	["Resisted"] = "抵抗:",
	
--Messages
	["resistmessage"] = "警告! {t} 抵抗了我的 {a}!",
	["immunemessage"] = "警告! {t} 免疫 {a}!",
	
	["abilitymessage"] = "+++ {a} 已经被使用了 ({d}s) +++",
	["abilityendmessage"] = "--- {a} ends ---",
	
	["abilityontargetmessage"] = "+++ {a} activated on {t} ({d}s) +++",
	["abilityontargetendmessage"] = "--- {a} on {t} ends ---",	
	
	["instantcastmessage"] = "{a} casted on {t}",	
	
	["counterspellmessage"] = "Kicked {s} by {t}  ({d}s)",
	
	["procmessage"] = " {a} has proc'ed",
	
	["disarmmessage"] = ">>> {a}! I am DISARMED ({d}s) <<<",
	["disarmendmessage"] = "<<< {a} fades. I am REARMED >>>",
	
	["debuffmessage"] = ">>> {a} ({d}s) <<<",
	["debuffendmessage"] = "<<< {a} ends. >>>",
	
	["debuffstunmessage"] = ">>> {a} ({d}s) - STUNNED<<<",
	["debuffmagicmessage"] = ">>> {a} ({d}s) - DISPEL<<<",
	["debuffcursemessage"] = ">>> {a} ({d}s) - DECURSE<<<",
	["debuffpoisonmessage"] = ">>> {a} ({d}s) - CURE POISON<<<",
	["debuffdiseasemessage"] = ">>> {a} ({d}s) - ABOLISH DISEASE<<<",
	["healreqmessage"] = ">>> {a} ({d}s) - HEAL ME TO 100%<<<",
	["pullcountmessage"] = "Pull in {d} seconds.",
	["pullmessage"] = ">>>>>> PULL <<<<<<",
	["pulltimerrange"] = 3,
	
	
--Whisper Strings
	["Resist-Whisper-Message-Warrior"] = "嘿小子,你真走运,居然能和MT一样被抽. :-)",
	["Resist-Whisper-Message-Druid"] = "熊是无敌的! :-)",
	["Resist-Whisper-Message-Paladin"] = "以正义之锤的名义, 你得自己呆一会儿了. :-)",
	["Resist-Whisper-Message-Mage"] = "冰箱, 冰箱, 冰箱! :-)",
	["Resist-Whisper-Message-Warlock"] = "珍惜生命,远离术士? :-)",
	["Resist-Whisper-Message-Hunter"] = "让你Y的假死技能起点作用吧! :-)",
	["Resist-Whisper-Message-Rogue"] = "消失还能用吧? :-)",
	["Resist-Whisper-Message-Priest"] = "你是最后一个还活着的... :-)",
	["Resist-Whisper-Message-Shaman"] = "你得和你的图腾一块呆一会儿了! :-)",
	["Resist-Whisper-Message-Deathknight"] = "Frost Presence ftw! :-)",
	
	
--Options
	--Chat (say, group/raid, whisper, raidwarning)
	["opt_name_raidparty"] = "团队/队伍",
	["opt_desc_raidparty"] = "OptiTaunt 警报通报到队伍(小队/团队).",
	["opt_name_say"] = "说话",
	["opt_desc_say"] = "显示 OptiTaunt 在说话频道.",
	["opt_name_yell"] = "Yell",
	["opt_desc_yell"] = "Shows OptiTaunt warning via /yell.",
	["opt_name_autowhisper"] = "密语",
	["opt_desc_autowhisper"] = "当有玩家OT并且该怪物抵抗了你的嘲讽时自动发送警报信息给此玩家.",
	["opt_name_raidwarning"] = "团队警告",
	["opt_desc_raidwarning"] = "显示 Optitaunt 警告在团队警告频道.",
	--SpellLink
	["opt_name_spelllink"] = "SpellLink instead of SpellName",
	["opt_desc_spelllink"] = "Post the click-able SpellLink instead of the standard SpellName.",
	--Audio
	["opt_name_audio"] = "声音警告",
	["opt_desc_audio"] = "当你的嘲讽失败时播放一个音效警告.",
	--Aggro Check
	["opt_name_aggrocheck"] = "检查 怪物目标",
	["opt_desc_aggrocheck"] = "OptiTaunt 将仅在怪物仇恨不是你并且你嘲讽抵抗的情况下发出警报.",
	--PvP Check
	["opt_name_pvpcheck"] = "检查 PvP 状态",
	["opt_desc_pvpcheck"] = "当你在PvP时不发出警告.",
	--Whisper Warriors
	["opt_name_whisperwarriors"] = "密语战士",
	["opt_desc_whisperwarriors"] = "OptiTaunt 将在你的嘲讽被抵抗时自动密语其它战士.",
	--SinkLib
	["opt_name_output_sink"] = "输出 (需要 SinkLib)",
	--Announce
	["opt_name_output"] = "输出 (聊天频道)",
	["opt_desc_output"] = "在哪个聊天通告你的警告.",
	["opt_name_outputchannel"] = "输出 (频道)",
	["opt_desc_outputchannel"] = "在哪个频道通告你的警告.",
	--Additional Options
	["opt_name_options"] = "其它选项",
	["opt_desc_options"] = "其它选项",
	--Taunt Counter / Statistics
	["Reset counters"] = "重置嘲讽计数器",
	["opt_desc_resetcounters"] = "重置嘲讽统计计数器.",
	["PrintTauntStatistics"] = "Announce taunt statistics",
	["opt_desc_printtauntstatistics"] = "Announces your taunt statistics in group or raid chat.",
	
	
--Announce Options
	
	--resist
	["opt_name_announceresist"] = "通告抵抗",
	["opt_desc_announceresist"] = "是否开启嘲讽抵抗通告功能.",
	--immune
	["opt_name_announceimmue"] = "通告免疫",
	["opt_desc_announceimmue"] = "是否开启免疫嘲讽通告功能.",
	
	--ability
	["opt_name_announceability"] = "通告技能",
	["opt_desc_announceability"] = "是否开启技能使用通告功能.",
	--ability END
	["opt_name_announceabilityend"] = "Announce end of abilites",
	["opt_desc_announceabilityend"] = "Turns announcements of fading abilities on or off.\n Requires 'Announce abilites'.",

	--ability on target
	["opt_name_announceabilityontarget"] = "Announce abilites used on target",
	["opt_desc_announceabilityontarget"] = "Turns announcements of abilities used on target on or off.",
	--ability on target END
	["opt_name_announceabilityontargetend"] = "Announce end of abilites used on target",
	["opt_desc_announceabilityontargetend"] = "Turns announcements of fading abilities used on target on or off.\n Requires 'Announce abilites'.",
	
	--disarm
	["opt_name_announcedisarm"] = "Announce disarm",
	["opt_desc_announcedisarm"] = "Turns announcements of disarm on or off.",
	--disarm END
	["opt_name_announcedisarmend"] = "Announce end of disarm",
	["opt_desc_announcedisarmend"] = "Turns announcements of fading disarm on or off.\n Requires 'Announce disarm'.",
	
	--debuff
	["opt_name_announcedebuff"] = "Announce debuff",
	["opt_desc_announcedebuff"] = "Turns announcements of debuff on or off.",
	--debuff END
	["opt_name_announcedebuffend"] = "Announce end of debuff",
	["opt_desc_announcedebuffend"] = "Turns announcements of fading debuff on or off.\n Requires 'Announce debuff'.",
	
	--stun
	["opt_name_announcedebuffstun"] = "Announce stun",
	["opt_desc_announcedebuffstun"] = "Turns announcements of stuns on or off.",
	--magic
	["opt_name_announcedebuffmagic"] = "Announce magic debuffs",
	["opt_desc_announcedebuffmagic"] = "Turns announcements of magic debuffs on or off.",
	--curse
	["opt_name_announcedebuffcurse"] = "Announce curse",
	["opt_desc_announcedebuffcurse"] = "Turns announcements of curses on or off.",
	--poison
	["opt_name_announcedebuffpoison"] = "Announce poison",
	["opt_desc_announcedebuffpoison"] = "Turns announcements of poisons on or off.",
	--disease
	["opt_name_announcedebuffdisease"] = "Announce disease",
	["opt_desc_announcedebuffdisease"] = "Turns announcements of stuns on or off.",
	--heal req.
	["opt_name_announcehealreq"] = "Announce healing debuffs",
	["opt_desc_announcehealreq"] = "Turns announcements of heal intensive debuffs on or off.",
	
	
--Message Text

	--resist
	["opt_name_resistmessage"] = "警告信息: 抵抗",
	["opt_usage_resistmessage"] = "\n{t}: 怪物名字\n{a}: 技能名称",
	
	--immune
	["opt_name_immunemessage"] = "警告信息: 免疫",
	["opt_usage_immunemessage"] = "\n{t}: 怪物名字\n{a}: 技能名称",
	
	--ability
	["opt_name_abilitymessage"] = "警告信息: 技能使用",
	["opt_usage_abilitymessage"] = "\n{a}: 技能名称\n{d}: 持续时间",
	--ability END
	["opt_name_abilityendmessage"] = "Warningmessage: ability ends",
	["opt_usage_abilityendmessage"] = "\n{a}: ability",
	
	--ability on target
	["opt_name_abilityontargetmessage"] = "Warningmessage: activated ability on target",
	["opt_usage_abilityontargetmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	--ability on target END
	["opt_name_abilityontargetendmessage"] = "Warningmessage: ability on target expires",
	["opt_usage_abilityontargetendmessage"] = "\n{a}: ability\n{t}: target",
	
	--counterspell
	["opt_name_counterspellmessage"] = "Warningmessage: interrupted target's spellcast",
	["opt_usage_counterspellmessage"] = "\n{a}: ability\n{t}: target\n{d}: duration",
	
	--disarm
	["opt_name_disarmmessage"] = "Warningmessage: being disarmed",
	["opt_usage_disarmmessage"] = "\n{a}: ability\n{d}: duration",
	--disarm END
	["opt_name_disarmendmessage"] = "Warningmessage: being no longer disarmed",
	["opt_usage_disarmendmessage"] = "\n{a}: ability",
	
	--debuff
	["opt_name_debuffmessage"] = "Warningmessage: Debuff",
	["opt_usage_debuffmessage"] = "\n{a}: debuff\n{d}: duration",
	--debuff END
	["opt_name_debuffendmessage"] = "Warningmessage: Debuff ends",
	["opt_usage_debuffendmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--stun
	["opt_name_debuffstunmessage"] = "Warningmessage: Stun",
	["opt_usage_debuffstunmessage"] = "\n{a}: debuff\n{d}: duration",
	--magic
	["opt_name_debuffmagicmessage"] = "Warningmessage: Magic debuff",
	["opt_usage_debuffmagicmessage"] = "\n{a}: debuff\n{d}: duration",
	--curse
	["opt_name_debuffcursemessage"] = "Warningmessage: Curse",
	["opt_usage_debuffcursemessage"] = "\n{a}: debuff\n{d}: duration",
	--poison
	["opt_name_debuffpoisonmessage"] = "Warningmessage: Poison",
	["opt_usage_debuffpoisonmessage"] = "\n{a}: debuff\n{d}: duration",
	--disease
	["opt_name_debuffdiseasemessage"] = "Warningmessage: Disease",
	["opt_usage_debuffdiseasemessage"] = "\n{a}: debuff\n{d}: duration",
	--heal req.
	["opt_name_healreqmessage"] = "Warningmessage: Heal needed",
	["opt_usage_healreqmessage"] = "\n{a}: debuff\n{d}: duration",
	
	--PullTimer
	["opt_name_countmessage"] = "Countdown message",
	["opt_usage_countmessage"] = "\n{d}: duration",
	["opt_name_pullmessage"] = "Pull message",
	["opt_usage_pullmessage"] = "",
	["opt_name_pullscale"] = "Pull time (seconds)",
	["opt_usage_pullscale"] = "Time in seconds until pull (3 - 20 sec)",
	["Output"] = "Output channels",
	
--Menu Text

	--Message Text
	["opt_name_messagetexts"] = "警告信息",
	["opt_desc_messagetexts"] = "编辑你的警告信息.",
	
	--Announcement Settings	
	["opt_name_announcesettings"] = "Announcements",
	["opt_desc_announcesettings"] = "What should be announced.",	
	
	--ability
	["opt_name_announces"] = "Announcing abilities",
	["opt_desc_announces"] = "Which abilities should be announced.",
	--disarm
	["opt_name_disarm_announces"] = "Disarms",
	["opt_desc_disarm_announces"] = "Which disarms should be announced.",
	--debuff
	["opt_name_debuff_announces"] = "Debuffs",
	["opt_desc_debuff_announces"] = "Which debuffs should be announced.",
	--stun
	["opt_name_debuff_stun_announces"] = "Stun effects",
	["opt_desc_debuff_stun_announces"] = "Which stun effects should be announced?",
	--magic
	["opt_name_debuff_magic_announces"] = "Magic debuffs",
	["opt_desc_debuff_magic_announces"] = "Which magic debuffs should be announced?",
	--curse
	["opt_name_debuff_curse_announces"] = "Curse",
	["opt_desc_debuff_curse_announces"] = "Which curses should be announced?",
	--poison
	["opt_name_debuff_poison_announces"] = "Poison",
	["opt_desc_debuff_poison_announces"] = "Which poisons should be announced?",
	--disease
	["opt_name_debuff_disease_announces"] = "Disease",
	["opt_desc_debuff_disease_announces"] = "Which diseases should be announced?",
	--heal req.
	["opt_name_healreq_announces"] = "Healing debuffs",
	["opt_desc_healreq_announces"] = "Which healing debuffs should be announced?",
	--ability on target
		--none so far (handled via ability_announce - 0.93)

	--PullTimer
	["opt_name_pulltimeroptions"] = "PullTimer Options",
	["opt_desc_pulltimeroptions"] = "Set message texts and time.",

} end)