﻿--[[
---- Debuff overview ------------------------------------------------------------------------------

Debuffs listed here that are already implented are marked with a '+'
Debuffs listed without any symbol or comment are pending approval


	Debuffs are implented in categories depending on there debuff type (debuff, stun, magic, curse, poison, disease, until fully healed)


Symbols:
	+	Already implented
	-	not intended to be implented
	\	Debuffs of the same effect / name (different levels (nhc/hc) of the same spell) like the above one marked with a '+' or '-'
	!	Needs review
	?	Pending approval
		(no symbol) recently added without any comment
	

Currently not completely sorted
	
]]--

Debuff (

RAIDS (
	Icecrown Citadel
		(
	+	71298	--Banish				 6sec
	+	71316	--Glacial Strike		until fully healed
	\	71317	
	+	70671	--Leeching Rot			 9sec	DISEASE(dispel)
	\	70710	
	+	69405	--Consuming Shadows		20sec	MAGIC(dispel)
	+	70645	--Chains of Shadow		10sec	MAGIC(dispel) BANISH
	+	70435	--Rend Flesh			30sec	
	+	71154	
	+	70659	--Necrotic Strike		20sec	HEAL-ABSORB
	\	71951	
	\	72490	
	\	72491	
	\	72492	
	+	70432	--Blood Sap				 8sec	STUN
	+	71623	--Delirious Slash
	\	71624
	\	71625
	\	71626
	\	72261
	\	72264
	\	72265
	\	72266
	+	72408	--Rune of Blood
	\	72409
	\	72410
	\	72447
	\	72448
	\	72449
		)
	
	Trial of the Crusader
		(
		-- none so far
		)
	
	)
DUNGEONS (
	Forge of Souls
		(
	+	69633	--Veil of Shadow		15sec	CURSE(dispel)
	+	69131	--Soul Sickness			 8sec	MAGIC(dispel)
		)
	Pit of Saron
		(
	+	70392	--Black Brand			10sec	
	+	69245	--Hoarfrost				 5sec	STUN
	\	69645	
	+	70302	--Blinding Dirt			 3sec	POISON(dispel)
	+	69572	--Shovelled!			 3sec	STUN
	\	70280	
	+	70292	--Glacial Strike		until fully healed
	+	69603	--Blight				15sec	DISEASE(dispell), jumps
	\	70285	
		)
	Halls of Reflection
		(
	+	72426	--Impending Despair		 6sec	MAGIC(dispel) *if NOT* -> 72428 Despair Stricken
	+	72428	--Despair Stricken		 6sec	STUN
	+	72368	--Shared Suffering		12sec	MAGIC(dispel) -> AE-DMG
	\	72369	
	\	72373
	+	72171	--Chains of Ice			 6sec	MAGIC(dispel) ROOTED
	+	70144	--Curse of Doom			10sec	CURSE(dispel)
	\	70183	
	+	72329	--Deadly Poison			12sec	POISON(dispel)
	\	72330	
	+	72335	--Kidney Shot			 3sec	STUN
	+	72222	--Cursed Arrow			15sec	CURSE(dispel)
		
		)
	
	)
)


Polymorph (

RAIDS (
	Icecrown Citadel
		(
	+	70410	--Polymorph: Spider / Verwandlung: Spinne			12sec
		72106	--Polymorph: Spider NPC / Verwandlung: Spinne NPC	 5sec
		)
		
	)
)


Disarm (
+	676		--Disarm / Entwaffnen
+	51722	--Dismantle / Zerlegen
+	53359	--Chimera Shot - Scorpid / Schimärenschuss - Skorpid
)

