if not myBigIgnite then
	return
end

local addon = myBigIgnite



-- common functions

function addon:GetColor(t)
	return t.r, t.g, t.b, t.a
end

function addon:SetColor(t, r, g, b, a)
	t.r, t.g, t.b, t.a = r, g, b, a or t.a
end

function addon:DeepCopy(src)
	local res = {}
    for k, v in pairs(src) do
        if type(v) == "table" then
            v = addon:DeepCopy(v)
        end
        res[k] = v
    end
    return res
end

function addon:Round(number, dec)
	return math.floor(number * 10^dec + 0.5) / 10^dec
end

function addon:BankerRound(number)
	local integer = math.floor(number)
	if number - integer == 0.5 then
		if integer % 2 ~= 0 then
			number = math.ceil(number)
		else
			number = integer
		end
	else
		number = addon:Round(number, 0)
	end
	
	return number
end

function addon:FormatDamage(txt, layout)
	if type(txt) == "number" then
		if layout == "condensed" then
			txt = addon:Round(txt / 1000, 1) .. "k"
		elseif layout == "integer" then
			txt = addon:Round(txt / 1000, 0) .. "k"
		end
	end
	return txt
end

function addon:HlString(str, colorL, colorR)
	local colorL = colorL
	local colorR = colorR
	return colorL .. str .. colorR
end

function addon:FormatTime(num)
	local hour = "%dh"
	local minute = "%dm"
	local seconde = "%ds"
	local fewsec = "%.1fs"
	
	if num < 10 then
		return fewsec:format(num)
	elseif num < 60 then
		return seconde:format(num)
	elseif num < 3600 then
		return minute:format(ceil(num / 60))
	else
		return hour:format(ceil(num / 3600))
	end
end

--[[
This function walks trough a "maze" table following the path provided by the map table.
Read: the value at the end of the path is returned by the function.
Write: the new value must be passed to the newValue parameter. The value and the new value must be of the same type otherwise the newValue is discarded.
i is used as a recursive increment to walk through the table and shouldn't be explicitly passed to the function unless for specific purposes.
]]
function addon:TableWalk(maze, map, newValue, i)
	i = i or 1
	local value

	-- debug
	if type(maze[map[i]]) ~= "boolean" then
		assert(maze[map[i]], "There is no entry in the maze table for the step number " .. i .. " with the name \"" .. map[i] .. "\".\n" )
	end

	-- recursive calls are stoped if either the end of the maze table or the end of the map table is reached
	if type(maze[map[i]]) ~= "table" or i >= #map then
		if newValue ~= nil then
			maze[map[i]] = newValue
		end
		value = maze[map[i]]
	else
		value = addon:TableWalk(maze[map[i]], map, newValue, i + 1)
	end
	return value
end

function addon:List(lib, mediatype)
	local t = {}
	for k, v in pairs(lib:List(mediatype)) do
		t[v] = v
	end
	return t
end




