if not myBigIgnite then
	return
end


local MBI = myBigIgnite
local L = LibStub("AceLocale-3.0"):GetLocale("myBigIgnite", true)

-- cache
local pairs, ipairs, type, tonumber, tostring, print, tinsert, tremove, wipe = pairs, ipairs, type, tonumber, tostring, print, tinsert, tremove, wipe
local strfind, strsub, floor, ceil, format = strfind, strsub, floor, ceil, format
local _



--##############################################################################################################################################
-- info and stats frame functions --------------------------------------------------------------------------------------------------------------

function MBI:OpenInfo(mode, isCmd)
	if not MBI.F.info then
		MBI:SetInfoFrame()
		MBI.infoTable = {}
	end
	
	MBI:PopulateInfo(mode)
	MBI:InfoScrollUpdate()
	MBI.F.info:Show()
	
	if isCmd then
		MBI.F.info.shownFromCmd = true
	else
		InterfaceOptionsFrame:Hide()
		HideUIPanel(GameMenuFrame)
	end
end

-- info frame
function MBI:SetInfoFrame()
	local R, G, B = 1, 0.5, 0
	local infoW, infoH = 700, 600
	
	-- info frame
	local info = myBigIgnite_info
	info:SetFrameStrata("DIALOG")
	info:Raise()
	info:SetWidth(infoW)
	info:SetHeight(infoH)
	info:SetPoint("TOP", UIParent, "TOP", 0, -100)
	info:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 2})
	info:SetBackdropBorderColor(R, G, B)
	info:EnableMouse(true)
	info:SetMovable(true)

	info:SetScript("OnMouseDown", function()
		info:StartMoving()
	end)
	info:SetScript("OnMouseUp", function()
		info:StopMovingOrSizing()
	end)
	
	-- scroll
	local scroll = myBigIgnite_infoScroll
	scroll:SetPoint("TOPLEFT", info, "TOPLEFT", 2, -75)
	scroll:SetPoint("BOTTOMRIGHT", info, "BOTTOMRIGHT", -30, 50)
	info.scroll = scroll
	
	-- title
	local title = CreateFrame("Frame", nil, info)
	title:SetHeight(25)
	title:SetPoint("TOP", info, "TOP", 0, -10)
	title:SetBackdrop({bgFile = "", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 0.75})
	title:SetBackdropBorderColor(R, G, B)
	title.txt = title:CreateFontString()
	title.txt:SetPoint("CENTER", title, "CENTER")
	title.txt:SetFont(MBI.font, 12)
	title.txt:SetShadowColor(0, 0, 0, 1)
	title.txt:SetShadowOffset(1, -1)
	info.title = title
	
	-- close button	
	local close = MBI:MakeButton(L["Close"], info)
	close:SetPoint("BOTTOMRIGHT", info, "BOTTOMRIGHT", -30, 15)
	close:SetScript("OnClick", function()
		info:Hide()
		if not MBI.F.info.shownFromCmd then
			InterfaceOptionsFrame_OpenToCategory("myBigIgnite")
		end
		MBI.F.info.shownFromCmd = false
	end)

	-- lines
	local maxLine = 26
	local lineHeight = 18
	local lines = {}
	for i = 1, maxLine do
		local line = lines[i]
		line = scroll:CreateFontString()
		line:SetPoint("TOPLEFT", scroll, "TOPLEFT", 7, -lineHeight * (i - 1))
		line:SetWidth(infoW - 40)
		line:SetShadowColor(0, 0, 0, 1)
		line:SetShadowOffset(1, -1)
		line:SetWordWrap(true)
		line:SetSpacing(4)
		lines[i] = line
	end
	info.lines = lines
	
	MBI.F.info = info
	MBI.F.info:Hide()
end

-- button factory
function MBI:MakeButton(text, parent)
	local R, G, B = 1, 0.5, 0
	
	local btn = CreateFrame("Button", nil, parent)
	btn:SetBackdrop({bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 0.75})
	btn:SetBackdropColor(R * 0.3, G * 0.3, B * 0.3)
	btn:SetBackdropBorderColor(R, G, B)
	btn.txt = btn:CreateFontString()
	btn.txt:SetPoint("CENTER", btn, "CENTER")
	btn.txt:SetFont("Fonts\\FRIZQT__.TTF", 13)
	btn.txt:SetShadowColor(0, 0, 0, 1)
	btn.txt:SetShadowOffset(1, -1)
	btn.txt:SetTextColor(R, G, B)
	btn.txt:SetText(text)
	btn:SetWidth(btn.txt:GetStringWidth() * 1.4)
	btn:SetHeight(btn.txt:GetStringHeight() * 1.3)
	btn.highL = btn:CreateTexture(nil, "HIGHLIGHT")
	btn.highL:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
	btn.highL:SetAllPoints(btn)
	btn.highL:SetBlendMode("ADD")
	btn.highL:SetAlpha(0.5)
	btn:SetScript("OnMouseDown", function()
		btn.txt:ClearAllPoints()
		btn.txt:SetPoint("CENTER", btn, "CENTER", 1, -1)
	end)
	btn:SetScript("OnMouseUp", function()
		btn.txt:ClearAllPoints()
		btn.txt:SetPoint("CENTER", btn, "CENTER")
	end)
	
	return btn
end

-- info scroll frame update
function MBI:InfoScrollUpdate()
	local maxLine = 26
	local lineHeight = 18
	local lineOffset, nLine
	
	local i, j = 1, 1
	while i <= #MBI.infoTable do
		if MBI.F.info.lines[i] then	
			MBI.F.info.lines[i]:Hide()
		end
		if MBI.infoTable[i] and MBI.infoTable[i].type == "button" then
			MBI.infoTable[i].value:ClearAllPoints()
			MBI.infoTable[i].value:Hide()
		end
		i = i + 1
	end
	i = 1
	while i <= maxLine do
		lineOffset = j + FauxScrollFrame_GetOffset(myBigIgnite_infoScroll)
		if lineOffset <= #MBI.infoTable then
			if MBI.infoTable[lineOffset].type == "text" or string.find(MBI.infoTable[lineOffset].type, "title") or MBI.infoTable[lineOffset].type == "special" then
				local fontSize = 11
				MBI.F.info.lines[i]:SetJustifyH("LEFT")
				if MBI.infoTable[lineOffset].type == "title1" then
					fontSize = 15
				elseif MBI.infoTable[lineOffset].type == "title2" then
					fontSize = 12
				elseif MBI.infoTable[lineOffset].type == "special" then
					fontSize = 15
					MBI.F.info.lines[i]:SetJustifyH("CENTER")
				end
				
				MBI.F.info.lines[i]:SetFont("Fonts\\FRIZQT__.TTF", fontSize)
				MBI.F.info.lines[i]:SetText(MBI.infoTable[lineOffset].value)
				nLine = math.ceil(MBI.F.info.lines[i]:GetStringHeight() / lineHeight)
				MBI.infoTable[lineOffset].line = nLine
				MBI.F.info.lines[i]:Show()
				if i + nLine > maxLine then
					MBI.F.info.lines[i]:Hide()
				end
				i = i + nLine - 1
			elseif MBI.infoTable[lineOffset].type == "button" then
				MBI.F.info.lines[i]:Hide()
				local btn = MBI.infoTable[lineOffset].value
				btn:ClearAllPoints()
				btn:SetPoint("TOPLEFT", MBI.F.info.scroll, "TOPLEFT", 7, -lineHeight * (i - 1))
				btn:Show()
				local nLine = math.ceil(btn:GetHeight() / lineHeight)
				MBI.infoTable[lineOffset].line = nLine
				if i + nLine > maxLine then
					btn:ClearAllPoints()
				end
				i = i + nLine - 1
			end
		else
			MBI.F.info.lines[i]:Hide()
		end
		i = i + 1
		j = j + 1
	end
	
	local realLineNum = maxLine + 1
	local tot = 0
	for entry in ipairs(MBI.infoTable) do
		tot = tot + MBI.infoTable[entry].line
	end
	if tot > realLineNum then
		realLineNum = tot
	end
	
	FauxScrollFrame_Update(myBigIgnite_infoScroll, realLineNum, maxLine, lineHeight)
end

-- info table update
function MBI:PopulateInfo(mode)
	for i = 1, #MBI.infoTable do
		if MBI.infoTable[i].type == "button" then
			MBI.infoTable[i].value:ClearAllPoints()
			MBI.infoTable[i].value:Hide()
		end
	end
	wipe(MBI.infoTable)
	local info = MBI.infoTable
	
	-- stats
	if mode == "stats" then
		MBI.F.info.title.txt:SetText(format(MBI:HlString(L["myBigIgnite: "], MBI.ORANGE, MBI.NORMAL) .. L["statistics"]))
		MBI.F.info.title:SetWidth(MBI.F.info.title.txt:GetStringWidth() * 1.1)
		
		-- ignite damages
		do
			table.insert(info, {
				type = "title1",
				value = MBI.ORANGE .. L["Ignite statistics"],
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
			table.insert(info, {
				type = "text",
				value = format(L["    total damages: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.ignite.dmg),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    total ticks: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.ignite.count),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    average tick damages: %s"], MBI.ORANGE .. MBI:Round(MBI.db.profile.stats.info.ignite.average, 1)),
			})
			local lowest = MBI.db.profile.stats.info.ignite.lowest
			if MBI.db.profile.stats.info.ignite.lowest == 100000 then
				lowest = 0
			end
			table.insert(info, {
				type = "text",
				value = format(L["    lowest tick damages: %s"], MBI.ORANGE .. lowest),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    highest tick damages: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.ignite.highest),
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
			local count = MBI.db.profile.stats.info.ignite.thresholdCount
			if MBI.db.profile.stats.info.ignite.thresholdCount == 0 then	-- workaround to avoid div by 0
				count = 1
			end
			table.insert(info, {
				type = "text",
				value = format(L["    number of ticks since last change of threshold: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.ignite.thresholdCount),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    percentage of ticks above optimal threshold: %s"], MBI.ORANGE .. MBI:Round(MBI.db.profile.stats.info.ignite.supOptT / count, 4) * 100 .. "%"),
			})
			if MBI.db.profile.threshold.interm.enabled then
				table.insert(info, {
					type = "text",
					value = format(L["    percentage of ticks between intermediate and optimal threshold: %s"], MBI.ORANGE .. MBI:Round(MBI.db.profile.stats.info.ignite.supIntermT / count, 4) * 100 .. "%"),
				})
			end
			table.insert(info, {
				type = "text",
				value = " ",
			})
		end
		
		table.insert(info, {
			type = "text",
			value = " ",
		})
		
		-- combu damages
		do
			table.insert(info, {
				type = "title1",
				value = MBI.ORANGE .. L["Combustion statistics"],
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
			table.insert(info, {
				type = "text",
				value = MBI.ORANGE .. L["Dot component:"],
			})
			table.insert(info, {
				type = "text",
				value = format(L["    total damages: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.combustion.dmgDot),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    total ticks: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.combustion.countDot),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    average tick damages: %s"], MBI.ORANGE .. MBI:Round(MBI.db.profile.stats.info.combustion.averageDot, 1)),
			})
			local lowest = MBI.db.profile.stats.info.combustion.lowestDot
			if MBI.db.profile.stats.info.combustion.lowestDot == 100000 then
				lowest = 0
			end
			table.insert(info, {
				type = "text",
				value = format(L["    lowest tick damages: %s"], MBI.ORANGE .. lowest),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    highest tick damages: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.combustion.highestDot),
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
		end
		do
			table.insert(info, {
				type = "text",
				value = MBI.ORANGE .. L["Direct damages:"],
			})
			table.insert(info, {
				type = "text",
				value = format(L["    total damages: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.combustion.dmgDirect),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    total counts: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.combustion.countDirect),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    average damages: %s"], MBI.ORANGE .. MBI:Round(MBI.db.profile.stats.info.combustion.averageDirect, 1)),
			})
			local lowest = MBI.db.profile.stats.info.combustion.lowestDirect
			if MBI.db.profile.stats.info.combustion.lowestDirect == 100000 then
				lowest = 0
			end
			table.insert(info, {
				type = "text",
				value = format(L["    lowest damages: %s"], MBI.ORANGE .. lowest),
			})
			table.insert(info, {
				type = "text",
				value = format(L["    highest damages: %s"], MBI.ORANGE .. MBI.db.profile.stats.info.combustion.highestDirect),
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
		end
		
		-- reset button
		table.insert(info, {
			type = "text",
			value = " ",
		})
		table.insert(info, {
			type = "text",
			value = " ",
		})
		MBI.F.info.statReset = MBI.F.info.statReset or MBI:MakeButton(L["Reset all stats"], MBI.F.info.scroll)
		MBI.F.info.statReset:SetScript("OnClick", function()
			wipe(info)
			wipe(MBI.db.profile.stats.info)
			MBI:InitStatModule()
			MBI:PopulateInfo("stats")
			MBI:InfoScrollUpdate()
		end)
		table.insert(info, {
			type = "button",
			value = MBI.F.info.statReset,
		})
		
		info.type = "stats"
		
	-- help
	else
		MBI.F.info.title.txt:SetText(format(MBI:HlString(L["myBigIgnite: "], MBI.ORANGE, MBI.NORMAL) .. L["help"]))
		MBI.F.info.title:SetWidth(MBI.F.info.title.txt:GetStringWidth() * 1.1)
		
		-- version and author
		table.insert(info, {
			type = "text",
			value = format("version %s     Istaran | Medivh - EU", MBI.ORANGE .. MBI.VERSION),
		})
		table.insert(info, {
			type = "text",
			value = " ",
		})
		
		-- no threshold
		if MBI.db.profile.threshold.value == 0 then
			table.insert(info, {
				type = "special",
				value = format(MBI.ORANGE .. "Your threshold is not set yet.\nGo to Threshold tab in configuration window or type %s to set it.", MBI:HlString("/mbi threshold [value]", MBI.NORMAL, MBI.ORANGE)),
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
			table.insert(info, {
				type = "text",
				value = " ",
			})
		end
		
		-- news
		table.insert(info, {
			type = "title1",
			value = MBI.ORANGE .. "Latest additions",
		})
		table.insert(info, {
			type = "text",
			value = format(MBI:HlString("- Heating up module layout completly redesigned.\n- Arrangement of modules redesigned.\n- Bug fixes and optimizations.", MBI.YELLOW, MBI.NORMAL))})
		table.insert(info, {
			type = "text",
			value = " ",
		})
		
		-- features
		table.insert(info, {
			type = "title1",
			value = MBI.ORANGE .. "Features",
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Visual warning",
		})
		table.insert(info, {
			type = "text",
			value = "myBigIgnite provides a visual warning when the current Ignite tick damage is above your threshold. The availability of Combustion is also taken into account. Thus, if Ignite tick damage is sufficient and Combustion available, the display is updated: color and size are adapted to the value of Ignite.",
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Damage display",
		})
		table.insert(info, {
			type = "text",
			value = "myBigIgnite shows current Ignite tick damage in a very clear way. Advanced options can change the way damages are displayed; they can be set up in Ignite frame tab.",
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Ignite timer",
		})
		table.insert(info, {
			type = "text",
			value = "A timer representing the remaining time of Ignite is provided with marks that show when Ignite ticks happen. The timer has a configurable red zone to better know if using Combustion is risky or not.",
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Ignite power bar",
		})
		table.insert(info, {
			type = "text",
			value = "Ignite power bar in another way to represent how high is the amount of damages done by the current Ignite tick. This feature is fully automatized and is here to help you to visualize the current Ignite tick together with the threshold.\nBriefly, the average damage and deviation are calculated over a given amount of ticks. The middle of the bar is set to the average value of Ignite ticks and the maximum of the bar correponds to 3 times the deviation. These numbers are adjusted regularly as you are playing. Some advanced options can be changed in the configuration.",
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Combustion module",
		})
		table.insert(info, {
			type = "text",
			value = "Combustion module adds plenty of informations about Combustion. Settings can be accessed by Module tab.\nWhen a threshold is crossed, this feature shows a predicted amount of damage done by Combustion as well as the number of Combustion ticks. Once Combustion triggered, the module will show you the remining time of Combustion dot and damages done by each tick. Upon Combustion fading, it will show the total damages done and a comparison with the predicted amount. Note that the total damage summary takes into account dot damages done on every targets. Finally, the module will display when Combustion is in CD.\nThe whole feature can be disabled.", 
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Heating up module",
		})
		table.insert(info, {
			type = "text",
			value = "Heating up module shows when you have Heating up and Pyroblast! buffs. By default, Heating up icon is hidden if Inferno Blast is in CD. This can be changed, together with cosmetic options.", 
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Statistics",
		})
		table.insert(info, {
			type = "text",
			value = "Statistics about the damages done by Ignite and Combustion(NYI) are stored and can be accessed. This is for number lovers and also can be used to properly adjust your threshold.",
		})
		table.insert(info, {
			type = "text",
			value = " ",
		})
		
		-- usage
		table.insert(info, {
			type = "title1",
			value = MBI.ORANGE .. "Usage",
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Accessing the config",
		})
		table.insert(info, {
			type = "text",
			value = format("Type %s or use the game menu to acces config options. Enabling %s will make the frame movable, animate the frame and shows it if necessary.", MBI:HlString("/mbi config", MBI.ORANGE, MBI.NORMAL), MBI:HlString("Config mode", MBI.ORANGE, MBI.NORMAL)), 
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Setting the threshold",
		})
		table.insert(info, {
			type = "text",
			value = format("To set up your threshold, go to Threshold tab in configuration window. You can also quickly set up your optimal threshold by typing %s.\n A good threshold must allow you to capture rare events. You can use the stats registered by myBigIgnite as well as the the power bar to help you setiing properly your threshold.", MBI:HlString("/mbi threshold [value]", MBI.ORANGE, MBI.NORMAL)),
		})
		table.insert(info, {
			type = "title2",
			value = MBI.YELLOW .. "Showing stats and help",
		})
		table.insert(info, {
			type = "text",
			value = format("Type %s to show several statistics about Ignite and Combustion or use the button in the config options. Type %s to show this help.", MBI:HlString("/mbi stats", MBI.ORANGE, MBI.NORMAL), MBI:HlString("/mbi help", MBI.ORANGE, MBI.NORMAL)),
		})
		table.insert(info, {
			type = "text",
			value = " ",
		})
		table.insert(info, {
			type = "text",
			value = MBI.ORANGE .. "Suggestions and bug reports can be done on Curse site [http://www.curse.com/addons/wow/mybigignite] either in comments or by pm.",
		})
		
		info.type = "help"
	end
	
	for entry in ipairs(info) do
		info[entry].line = 1
	end
	
	MBI.infoTable = info
end
