﻿if not myBigIgnite then
	return
end


local MBI = myBigIgnite
local L = LibStub("AceLocale-3.0"):GetLocale("myBigIgnite", true)
local LSM = LibStub("LibSharedMedia-3.0")
local ACR = LibStub("AceConfigRegistry-3.0")
MBI.cfMode = false

-- cache
local pairs, ipairs, type, tonumber, tostring, print, tinsert, tremove, wipe = pairs, ipairs, type, tonumber, tostring, print, tinsert, tremove, wipe
local strfind, strsub, floor, ceil, format = strfind, strsub, floor, ceil, format
local _



--##############################################################################################################################################
-- local stuff ---------------------------------------------------------------------------------------------------------------------------------


local function IsInCombat()
	return MBI.inCombat
end

local function IsPositiveNum(info, value)
	if tonumber(value) ~= nil and tonumber(value)> 0 then
		return true
	else
		print(format(L["%senter a positive number"], MBI:HlString(L["myBigIgnite: "], MBI.ORANGE, MBI.NORMAL)))
	end
end



--##############################################################################################################################################
-- option tables -------------------------------------------------------------------------------------------------------------------------------

-- default option table
function MBI:LoadFakeOptions()
	MBI.fakeOptions = {
		type = "group",
		name = "myBigIgnite",
		childGroups = "tab",
		disabled = IsInCombat,
		args = {
			toggleOptions = {
				type = "execute",
				name = L["myBigIgnite config"],
				desc = L["Toggles myBigIgnite configuration panel."],
				order = 1,
				func = function()
					MBI:ChangeConfigDisplay("fireSpec")
					MBI.configLoaded = true
				end,
			},
		},
	}

	-- ACE registry
	MBI.options = MBI:DeepCopy(MBI.fakeOptions)
	ACR:RegisterOptionsTable("myBigIgnite", MBI.options)
	LibStub("AceConfigDialog-3.0"):AddToBlizOptions("myBigIgnite", "myBigIgnite")
end

-- config panel, switching out of fire spec
function MBI:LoadooFOptions()
	MBI.ooFOptions = {
		type = "group",
		name = "myBigIgnite",
		childGroups = "tab",
		args = {
			message = {
				type = "description",
				name = L["Configuration available only when myBigIgnite is enabled."],
				fontSize = "medium",
			},
		},
	}
end

-- real config panel
function MBI:LoadFireOptions()
	MBI.fireOptions = {
		type = "group",
		name = "myBigIgnite",
		childGroups = "tab",
		disabled = IsInCombat,
		args = {
			configMode = {
				type = "toggle",
				name = L["Configuration mode"],
				desc = L["Enable myBigIgnite configuration mode."],
				order = 0,
				get = function()
					return MBI.cfMode
				end,
				set = function(info, value)
					MBI.cfMode = value
					MBI:ConfigMode(value)
				end,
			},
			stats = {
				type = "execute",
				name = L["Stats"],
				desc = L["Shows damages statistics."],
				order = 3,
				func = function()
					MBI:OpenInfo("stats")
				end,
			},
			help = {
				type = "execute",
				name = L["Help"],
				desc = L["Shows help."],
				order = 7,
				func = function()
					MBI:OpenInfo("help")
				end,
			},
			reset = {
				type = "execute",
				name = L["Reset"],
				desc = L["Reset all settings."],
				order = 10,
				confirm = true,
				width = "half",
				confirmText = L["This will reset all myBigIgnite settings. Are you sure?"],
				func = function()
					local temp = MBI:DeepCopy(MBI.defaults.profile)
					for k, v in pairs(MBI.db.profile) do
						if MBI.defaults.profile[k] then
							if type(MBI.db.profile[k]) == "table" then
								wipe(MBI.db.profile[k])
							end
							MBI.db.profile[k] = temp[k]
						end
					end
					
					MBI:Reset()
					print(MBI.YELLOW_LIGHT .. L["myBigIgnite has been reset."])
				end,
			},
			threshold = {
				type = "group",
				name = L["Threshold"],
				desc = L["Ignite threshold options."],
				order = 20,
				get = function(info) return MBI:TableWalk(MBI.db.profile, info)	end,
				set = function(info, value)
					MBI:TableWalk(MBI.db.profile, info, value)
				end,
				args = MBI:ThresholdOptions(),
			},
			general = {
				type = "group",
				name = L["General"],
				desc = L["General options."],
				order = 30,
				get = function(info) return MBI:TableWalk(MBI.db.profile, info)	end,
				set = function(info, value)
					MBI:TableWalk(MBI.db.profile, info, value)
					MBI.font = LSM:Fetch("font", MBI.db.profile.general.layout.font)
					MBI:SetIgniteFrame()
					MBI:SetCombustionFrame()
					MBI:SetHeatingUpFrame()
				end,
				args = MBI:GeneralOptions(),
			},
			ignite = {
				type = "group",
				name = L["Ignite frame"],
				desc = L["Ignite frame options."],
				order = 40,
				get = function(info) return MBI:TableWalk(MBI.db.profile, info)	end,
				set = function(info, value)
					MBI:TableWalk(MBI.db.profile, info, value)
					MBI:SetIgniteFrame()
				end,
				args = MBI:IgniteOptions(),
			},
			modules = {
				type = "group",
				name = L["Modules"],
				desc = L["Extra modules options."],
				order = 50,
				get = function(info) return MBI:TableWalk(MBI.db.profile, info)	end,
				set = function(info, value)
					local modules = {"combustion", "heatingup", "bomb"}
					if info[#info] == "position" and info[#info - 2] == "general" then
						for _, modules in ipairs(modules) do
							if value == MBI.db.profile.modules.general[modules].position then
								MBI.db.profile.modules.general[modules].position = MBI.db.profile.modules.general[info[#info - 1]].position
								break
							end
						end
					end
					
					MBI:TableWalk(MBI.db.profile, info, value)
					
					MBI.combuCDShown = false
					MBI:SetCombustionFrame()
					if not MBI.db.profile.modules.general.combustion.enabled and MBI.F.combustion then
						MBI.F.combustion:Hide()
					end
					if MBI.F.combustion then
						MBI.F.combustion.dmg[1].aniGroup:Stop()
						MBI.F.combustion.dmg[1]:Hide()
						MBI.F.combustion.dmg[1].update:Hide()
					end
					
					MBI:SetHeatingUpFrame()
					if not MBI.db.profile.modules.general.heatingup.enabled and MBI.F.pyro and MBI.F.hup then
						MBI.F.pyro:Hide()
						MBI.F.hup:Hide()
					end
				end,
				args = MBI:ModulesOptions(),
			},



		},
	}
end

-- general tab
function MBI:GeneralOptions()
	local UIScale = UIParent:GetScale()
	local UIWidth = UIParent:GetWidth()
	local UIHeight = UIParent:GetHeight()

	local options = {
		autohide = {
			type = "group",
			inline = true,
			order = 0,
			args = {
				header = {
					type = "header",
					name = L["Autohiding"],
					order = 0,
				},
				desc = {
					type = "description",
					name = MBI.YELLOW .. L["Hide automatically myBigIgnite if:"],
					fontSize = "medium",
					width = "full",
					order = 10,
				},
				noCombat = {
					type = "toggle",
					name = L["Out of combat"],
					order = 20,
					set = function(info, value)
						MBI.db.profile.general.autohide.noCombat = value
						if not MBI.cfMode then
							if value then
								MBI.F.main:Hide()
							else
								MBI.F.main:Show()
							end
						end
						if not value then
							MBI.db.profile.general.autohide.noIgnite = false
							MBI.db.profile.general.autohide.combuCD = false
						end
					end,
				},
				noIgnite = {
					type = "toggle",
					name = L["No Ignite"],
					order = 30,
					set = function(info, value)
						MBI.db.profile.general.autohide.noIgnite = value
						if value then
							MBI.db.profile.general.autohide.noCombat = true
							if not MBI.cfMode then
								if value then
									MBI.F.main:Hide()
								else
									MBI.F.main:Show()
								end
							end
						end
					end,
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 40,
				},
				combuCD = {
					type = "toggle",
					name = L["Combustion in CD"],
					order = 50,
					set = function(info, value)
						MBI.db.profile.general.autohide.combuCD = value
						if value then
							MBI.db.profile.general.autohide.noCombat = true
							if not MBI.cfMode then
								if value then
									MBI.F.main:Hide()
								else
									MBI.F.main:Show()
								end
							end
						end
					end,
				},
				combuCDTime = {
					type = "range",
					name = L["Time before CD end"],
					desc = L["Shows the frame when Combustion CD is less than this value."],
					order = 60,
					disabled = function()
						return not MBI.db.profile.general.autohide.combuCD
					end,
					min = 0, max = 45, softMax = 30, step = 1,
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		anchor = {
			type = "group",
			inline = true,
			order = 10,
			args = {
				header = {
					type = "header",
					name = L["Position"],
					order = 0,
				},
				coord = {
					type = "group",
					inline = true,
					order = 10,
					args = {
						xcd = {
							type = "range",
							name = L["Horizontal position"],
							order = 0,
							min = 0,
							max = MBI:Round(UIWidth, 0),
							softMin = 0,
							softMax = MBI:Round(UIWidth, 0),
							bigStep = 0.5,
						},
						ycd = {
							type = "range",
							name = L["Vertical position"],
							order = 10,
							min = 0,
							max = MBI:Round(UIHeight, 0),
							softMin = 0,
							softMax = MBI:Round(UIHeight, 0),
							bigStep = 0.5,
						},
						resetPosition = {
							type = "execute",
							name = L["Reset position"],
							desc = L["Reset the main frame to its default position."],
							order = 20,
							confirm = true,
							confirmText = L["Reset the main frame position?"],
							func = function()
								MBI.db.profile.general.anchor.coord = MBI:DeepCopy(MBI.defaults.profile.general.anchor.coord)
								MBI:SetAnchorFramePosition()
							end,
						},
					},
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 20,
				},
				align = {
					type = "select",
					name = L["Main Window alignment"],
					order = 30,
					values = {
						RIGHT = L["Right"],
						LEFT = L["Left"],
						CENTER = L["Center"],
						TOP = L["Top"],
						BOTTOM = L["Bottom"],
						TOPLEFT = L["TopLeft"],
						BOTTOMLEFT = L["BottomLeft"],
						TOPRIGHT = L["TopRight"],
						BOTTOMRIGHT = L["BottomRight"],
					},
				},
				strata = {
					type = "select",
					name = L["Window strata"],
					order = 40,
					values = {
							[1] = L["Low"],
							[2] = L["Medium"],
							[3] = L["High"],
					},
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		layout = {
			type = "group",
			inline = true,
			order = 20,
			args = {
				header = {
					type = "header",
					name = L["Layout"],
					order = 0,
				},
				textSize = {
					type = "range",
					name = L["Text and window size"],
					order = 10,
					min = 8, max = 20, step = 1,
				},
				alpha = {
					type = "range",
					order = 20,
					name = L["Main window alpha"],
					min = 0.4, max = 1, bigStep = 0.05,
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 30,
				},
				font = {
					type = "select",
					name = L["Font"],
					order = 40,
					values = function()
						return MBI:List(LSM, "font")
					end,
				},
				bar = {
					type = "select",
					order = 45,
					disabled = function()
						return not MBI.db.profile.ignite.timer.enabled and not MBI.db.profile.ignite.power.enabled
					end,
					name = L["Bar"],
					values = MBI:List(LSM, "statusbar"),
				},
				space2 = {
					type = "description",
					name = " ",
					width = "full",
					order = 50,
				},
				background = {
					type = "group",
					inline = true,
					order = 60,
					args = {
						enabled = {
							type = "toggle",
							name = L["Enable background"],
							order = 0,
						},
						texture = {
							type = "select",
							name = L["Background"],
							order = 10,
							disabled = function()
								return not MBI.db.profile.general.layout.background.enabled
							end,
							values = function()
								return MBI:List(LSM, "background")
							end,
						},
						darkness = {
							type = "range",
							name = L["Background brightness"],
							order = 20,
							disabled = function()
								return not MBI.db.profile.general.layout.background.enabled
							end,
							min = 0, max = 1, step = 0.01,
							isPercent = true,
						},
						space = {
							type = "description",
							name = " ",
							width = "full",
							order = 500,
						},
					},
				},
				border = {
					type = "group",
					inline = true,
					order = 70,
					args = {
						enabled = {
							type = "toggle",
							name = L["Enable border"],
							order = 0,
						},
						texture = {
							type = "select",
							name = L["Border"],
							order = 10,
							disabled = function()
								return not MBI.db.profile.general.layout.border.enabled
							end,
							values = function()
								return MBI:List(LSM, "background")
							end,
						},
						space = {
							type = "description",
							name = " ",
							width = "full",
							order = 500,
						},
					},
				},
				iconTextColor = {
					type = "color",
					order = 95,
					name = L["Icon text colour"],
					get = function()
						return MBI:GetColor(MBI.db.profile.general.layout.iconTextColor)
					end,
					set = function(info, r, g, b)
						MBI:SetColor(MBI.db.profile.general.layout.iconTextColor, r, g, b)
						MBI:SetCombustionFrame()
					end,
				},
				barTextSpecificColor = {
					type = "toggle",
					name = L["Fixed bar text colour"],
					desc = L["Always uses the same colour to display timer text."],
					order = 100,
				},
				barTextColor = {
					type = "color",
					order = 110,
					name = L["Bar text colour"],
					disabled = function() return not MBI.db.profile.general.layout.barTextSpecificColor end,
					get = function()
						return MBI:GetColor(MBI.db.profile.general.layout.barTextColor)
					end,
					set = function(info, r, g, b)
						MBI:SetColor(MBI.db.profile.general.layout.barTextColor, r, g, b)
						if not MBI.cfMode then
							MBI:UpdateIgniteFrame("low")
						end
					end,
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		header1 = {
			type = "header",
			name = L["Miscellaneous"],
			order = 30,
		},
		splashMsg = {
			type = "toggle",
			name = L["Splash message"],
			desc = L["Enables the welcome message on myBigIgnite loading."],
			order = 40,
		},
		resetStats = {
			type = "range",
			name = L["Auto reset of stats"],
			desc = L["(every x million of ticks). Simply to avoid storing super huge numbers."],
			order = 50,
			min = 0.1, max = 1, step = 0.1,
		},
	}

	return options
end

-- threshold tab
function MBI:ThresholdOptions()
	local options = {
		descHigh = {
			type = "description",
			name = MBI.ORANGE .. L["HIGH IGNITE TICK: minimal value above which myBigIgnite will inform you that Ignite tick is optimal."],
			order = 10,
			width = "full",
			fontSize = "medium",
		},
		value = {
			type = "input",
			name = L["Ignite threshold value"],
			order = 20,
			validate = IsPositiveNum,
			get = function()
				return tostring(MBI.db.profile.threshold.value)
			end,
			set = function(info, value)
				MBI.db.profile.threshold.value = tonumber(value)
				MBI.db.profile.stats.info.ignite.thresholdCount = 0
				MBI.db.profile.stats.info.ignite.supOptT = 0
				MBI.db.profile.stats.info.ignite.supIntermT = 0
				if MBI.F.info and MBI.F.info:IsShown() and MBI.infoTable.type == "stats" then
					MBI:PopulateInfo("stats")
					MBI:InfoScrollUpdate()
				end
				if MBI.warning then
					MBI.warning = false
				end
			end,
		},
		high = {
			type = "group",
			inline = true,
			order = 25,
			args = {
				color = {
					type = "color",
					order = 0,
					name = L["Colour scheme"],
					get = function()
						return MBI:GetColor(MBI.db.profile.threshold.high.color)
					end,
					set = function(info, r, g, b)
						MBI:SetColor(MBI.db.profile.threshold.high.color, r, g, b)
					end,
				},
				mult = {
					type = "range",
					name = L["Scale multiplier"],
					desc = L["Main window is enlarged by this setting when the corresponding threshold is reached."],
					disabled = function()
						return MBI.db.profile.modules.general.heatingup.enabled or MBI.db.profile.modules.bomb.enabled
					end,
					order = 10,
					min = 1, max = 3, softMin = 1, softMax = 2, step = 0.1,
				},
			},
		},
		space1 = {
			type = "description",
			name = " ",
			width = "full",
			order = 30,
		},
		space2 = {
			type = "description",
			name = " ",
			widh = "full",
			order = 40,
		},
		interm = {
			type = "group",
			inline = true,
			order = 50,
			args = {
				descMid = {
					type = "description",
					name = MBI.ORANGE .. L["MID IGNITE TICK: intermediate value, under optimal value. Useful in situations where you cannot expect to get a big Ignite."],
					order = 0,
					width = "full",
					fontSize = "medium",
				},
				enabled = {
					type = "toggle",
					name = L["Intermediate threshold"],
					desc = L["Enable intermediate threshold"],
					order = 10,
				},
				igPerctAbs = {
					type = "input",
					name = " ",
					order = 20,
					width = "half",
					disabled = true,
					get = function()
						if MBI.db.profile.threshold.interm.enabled then
							return "|cffFFFFFF" .. tostring(MBI.db.profile.threshold.interm.perct * MBI.db.profile.threshold.value)
						end
					end,
				},
				perct = {
					type = "range",
					name = L["% of optimal Ignite"],
					order = 30,
					disabled = function()
						return not MBI.db.profile.threshold.interm.enabled
					end,
					min = 0.05,	max = 0.99,	softMin = 0.5, softMax = 0.95, step = 0.05,
					isPercent = true,
				},
			},
		},
		mid = {
			type = "group",
			inline = true,
			order = 60,
			args = {
				color = {
					type = "color",
					order = 0,
					disabled = function()
						return not MBI.db.profile.threshold.interm.enabled
					end,
					name = L["Colour scheme"],
					get = function()
						return MBI:GetColor(MBI.db.profile.threshold.mid.color)
					end,
					set = function(info, r, g, b)
						MBI:SetColor(MBI.db.profile.threshold.mid.color, r, g, b)
					end,
				},
				mult = {
					type = "range",
					disabled = function()
						return not MBI.db.profile.threshold.interm.enabled or MBI.db.profile.modules.general.heatingup.enabled or MBI.db.profile.modules.bomb.enabled
					end,
					name = L["Scale multiplier"],
					desc = L["Main window is enlarged by this setting when the corresponding threshold is reached."],
					order = 10,
					min = 1, max = 3, softMin = 1, softMax = 2, step = 0.1,
				},
			},
		},
		space4 = {
			type = "description",
			name = " ",
			widh = "full",
			order = 70,
		},
		space5 = {
			type = "description",
			name = " ",
			widh = "full",
			order = 80,
		},
		descLow = {
			type = "description",
			name = MBI.ORANGE .. L["LOW IGNITE TICK: default display when Ignite tick doesn't rich a sufficient level or Combution is not available."],
			order = 85,
			width = "full",
			fontSize = "medium",
		},
		low = {
			type = "group",
			inline = true,
			order = 90,
			args = {
				color = {
					type = "color",
					order = 0,
					name = L["Colour scheme"],
					get = function()
						return MBI:GetColor(MBI.db.profile.threshold.low.color)
					end,
					set = function(info, r, g, b)
						MBI:SetColor(MBI.db.profile.threshold.low.color, r, g, b)
						if not MBI.cfMode then
							MBI:UpdateIgniteFrame("low")
						end
					end,
				},
			},
		},
	}

	return options
end

-- ignite tab
function MBI:IgniteOptions()
	local options = {
		header = {
			type = "header",
			name = L["Ignite damage display"],
			order = 0,
		},
		useCombatLog = {
			type = "toggle",
			name = L["Use combat log"],
			desc = L["If this option is enabled, myBigIgnite will fetch Ignite damages from combat log instead of using the new method based on buffs. Consequently, damages will be displayed after each tick of Ignite as previously. (Not recommended)"],
			order = 10,
			width = "full",
		},
		smoothDmgReport = {
			type = "toggle",
			name = L["Smoothing damage"],
			desc = L["Smoothes damage display: this option introduces a lag (in seconds) before damage display is refreshed. This allows to even the display without compromising its accuracy."],
			order = 20,
			disabled = function()
				return MBI.db.profile.ignite.useCombatLog
			end,
		},
		smoothDmgValue = {
			type = "range",
			name = L["Lag time"],
			desc = L["In seconds."],
			order = 30,
			disabled = function()
				return not MBI.db.profile.ignite.smoothDmgReport or MBI.db.profile.ignite.useCombatLog
			end,
			min = 0.2, max = 1, softMin = 0.2, softMax = 1, step = 0.1,
		},
		dmgAsDps = {
			type = "toggle",
			name = L["Show DPS"],
			desc = L["Shows Ignite damage as DPS instead of raw tick damage."],
			order = 40,
			width = "full",
		},
		space4 = {
			type = "description",
			name = " ",
			widh = "full",
			order = 50,
		},
		timer = {
			type = "group",
			inline = true,
			order = 70,
			args = {
				header = {
					type = "header",
					name =  L["Ignite timer"],
					order = 0,
				},
				enabled = {
					type = "toggle",
					order = 10,
					name = L["Enable"],
					desc = L["Activates a timer bar showing visually the remaining time of an Ignite dot."],
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 20,
				},
				reverse = {
					type = "toggle",
					order = 30,
					disabled = function()
						return not MBI.db.profile.ignite.timer.enabled
					end,
					name = L["Reversed"],
				},
				tick = {
					type = "toggle",
					order = 35,
					disabled = function()
						return not MBI.db.profile.ignite.timer.enabled
					end,
					name = L["Enable tick marks"],
				},
				alpha = {
					type = "range",
					order = 50,
					disabled = function()
						return not MBI.db.profile.ignite.timer.enabled
					end,
					name = L["Alpha"],
					min = 0.2, max = 1, bigStep = 0.05,
				},
				space4 = {
					type = "description",
					name = " ",
					width = "full",
					order = 70,
				},
				redZone = {
					type = "range",
					order = 80,
					disabled = function()
						return not MBI.db.profile.ignite.timer.enabled
					end,
					name = L["Ignite red zone"],
					desc = L["The timer bar will turn of the selected colour when the remaining time of Ignite is under this value."],
					min = 0, max = 2, step = 0.05, bigStep = 0.1,
				},
				redZoneColor = {
					type = "color",
					order = 90,
					disabled = function()
						return not MBI.db.profile.ignite.timer.enabled
					end,
					name = L["Red zone colour"],
					get = function()
						return MBI:GetColor(MBI.db.profile.ignite.timer.redZoneColor)
					end,
					set = function(info, r, g, b)
						MBI:SetColor(MBI.db.profile.ignite.timer.redZoneColor, r, g, b)
					end,
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		power = {
			type = "group",
			inline = true,
			order = 80,
			args = {
				header = {
					type = "header",
					name =  L["Ignite power bar"],
					order = 0,
				},
				enabled = {
					type = "toggle",
					order = 10,
					name = L["Enable"],
					desc = L["Activates a power bar showing visually how high is your current ignite tick."],
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 15,
				},
				align = {
					type = "select",
					disabled = function()
						return not MBI.db.profile.ignite.power.enabled
					end,
					name = L["Bar alignement"],
					order = 20,
					values = {
						RIGHT = L["Right"],
						LEFT = L["Left"],
					},
				},
				alpha = {
					type = "range",
					order = 30,
					disabled = function()
						return not MBI.db.profile.ignite.power.enabled
					end,
					name = L["Alpha"],
					min = 0.2, max = 1, step = 0.05,
				},
				space2 = {
					type = "description",
					name = " ",
					width = "full",
					order = 40,
				},
				gradient = {
					type = "select",
					disabled = function()
						return not MBI.db.profile.ignite.power.enabled
					end,
					name = L["Gradient colour"],
					order = 50,
					values = {
						rg = L["Red to green"],
						bg = L["Blue to green"],
					},
				},
				middle = {
					type = "range",
					order = 60,
					disabled = function()
						return not MBI.db.profile.ignite.power.enabled
					end,
					name = L["Gradient middle"],
					desc = L["Percentage of the power bar at which is placed the midle of the colour gradient."],
					isPercent = true,
					min = 0.5, max = 0.8, step = 0.05,
				},				
				space3 = {
					type = "description",
					name = " ",
					width = "full",
					order = 70,
				},
				tableSize = {
					type = "range",
					order = 80,
					disabled = function()
						return not MBI.db.profile.ignite.power.enabled
					end,
					name = L["Number of ticks"],
					desc = L["Set the number of last ticks to consider in calculations. Higher value means more stable but less reactive power bar."],
					min = 50, max = 150, step = 10,
				},
				reset = {
					type = "execute",
					name = L["Reset numbers"],
					desc = L["Reset the numbers driving the power bar."],
					order = 90,
					confirm = true,
					confirmText = L["Sure?"],
					func = function()
						wipe(MBI.db.profile.stats.power)
						MBI:InitPowerBar()
					end,
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		layout = {
			type = "group",
			inline = true,
			order = 90,
			args = {
				header = {
					type = "header",
					name =  L["Ignite frame layout"],
					order = 0,
				},
				text = {
					type = "group",
					inline = true,
					order = 10,
					args = {
						align = {
							type = "select",
							name = L["Text alignement"],
							order = 0,
							values = {
								RIGHT = L["Right"],
								LEFT = L["Left"],
								CENTER = L["Center"],
							},
						},
						ofx = {
							type = "range",
							name = L["Horizontal offset"],
							order = 10,
							min = -10, max = 10, step = 0.05, bigStep = 0.25,
						},
						ofy = {
							type = "range",
							name = L["Vertical offset"],
							order = 20,
							min = -2.5, max = 2.5, step = 0.05, bigStep = 0.25,
						},
						space1 = {
							type = "description",
							name = " ",
							width = "full",
							order = 30,
						},
						format = {
							type = "select",
							name = L["Text format"],
							order = 40,
							values = {
								["normal"] = L["Normal"],
								["condensed"] = L["Condensed"],
							},
						},
						space = {
							type = "description",
							name = " ",
							width = "full",
							order = 500,
						},
					},
				},
				bgInset = {
					type = "range",
					name = L["Background inset"],
					order = 20,
					disabled = function()
						return not MBI.db.profile.general.layout.background.enabled
					end,
					min = -10, max = 10, step = 0.05,
				},
				bdSize = {
					type = "range",
					name = L["Border thickness"],
					order = 30,
					disabled = function()
						return not MBI.db.profile.general.layout.border.enabled
					end,
					min = 0, max = 35, step = 0.05 ,
				},
				adjust = {
					type = "range",
					name = L["Edge spacing"],
					desc = L["Adjusts the space between the inside frame (timer, power and display) and the border or the edge of the background."],
					order = 40,
					min = 0, max = 5, step = 0.05 ,
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
	}

	return options
end

-- extra module options
function MBI:ModulesOptions()
	local options = {
		general = {
			type = "group",
			inline = true,
			order = 0,
			args = {
				header = {
					type = "header",
					name = L["Module activation and global layout"],
					order = 0,
				},
				combustion = {
					type = "group",
					inline = true,
					order = 10,
					args = {
						enabled = {
							type = "toggle",
							name = L["Enable Combustion"],
							order = 0,
						},
						position = {
							type = "select",
							name = L["Module location"],
							order = 10,
							disabled = function()
								return not MBI.db.profile.modules.general.combustion.enabled
							end,
							values = {
								LEFT = L["Left"],
								RIGHT = L["Right"],
								TOP = L["Top"],
								BOTTOM = L["Bottom"],
							},
						},
					},
				},
				heatingup = {
					type = "group",
					inline = true,
					order = 20,
					args = {
						enabled = {
							type = "toggle",
							name = L["Enable Heating Up"],
							desc = L["Enabling this module deactivates addon scale change when crossing the thresholds."],
							order = 0,
						},
						position = {
							type = "select",
							name = L["Module location"],
							order = 10,
							disabled = function()
								return not MBI.db.profile.modules.general.heatingup.enabled
							end,
							values = {
								LEFT = L["Left"],
								RIGHT = L["Right"],
								TOP = L["Top"],
								BOTTOM = L["Bottom"],
							},
						},
						show = {
							type = "select",
							name = L["Procs to show"],
							order = 20,
							disabled = function()
								return not MBI.db.profile.modules.general.heatingup.enabled
							end,
							values = {
								both = L["Hup and Pyro!"],
								hup = L["Hup only"],
								pyro = L["Pyro! only"],
							},
						},
					},
				},
				--bomb = {
				--	type = "group",
				--	inline = true,
				--	order = 30,
				--	args = {
				--		enabled = {
				--			type = "toggle",
				--			name = L["Enable Bomb"],
				--			desc = L["Enabling this module deactivates addon scale change when crossing the thresholds."],
				--			order = 0,
				--		},
				--		position = {
				--			type = "select",
				--			name = L["Module location"],
				--			order = 10,
				--			disabled = function()
				--				return not MBI.db.profile.modules.general.bomb.enabled
				--			end,
				--			values = {
				--				LEFT = L["Left"],
				--				RIGHT = L["Right"],
				--				TOP = L["Top"],
				--				BOTTOM = L["Bottom"],
				--			},
				--		},
				--	},
				--},
				offset = {
					type = "range",
					name = L["Spacing"],
					desc = L["Spacing between modules and Ignite display."],
					order = 40,
					min = 0, max = 40, step = 0.05 ,
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		combustion = {
			type = "group",
			inline = true,
			order = 5,
			disabled = function()
				return not MBI.db.profile.modules.general.combustion.enabled
			end,
			args = {
				header = {
					type = "header",
					name = L["Combustion module"],
					order = 0,
				},
				size = {
					type = "range",
					name = L["Module size"],
					order = 10,
					min = 1.25, max = 2, step = 0.05 ,
				},
				scaling = {
					type = "group",
					inline = true,
					order = 20,
					disabled = function()
						return not MBI.db.profile.modules.general.combustion.enabled or (not MBI.db.profile.modules.general.heatingup.enabled and not MBI.db.profile.modules.bomb.enabled)
					end,
					args = {
						enabled = {
							type = "toggle",
							name = L["Module scaling"],
							desc = L["Will increase the size of Combustion icon when crossing the thresholds. Only activated if global scaling is deactivated."],
							order = 0,
						},
						mid = {
							type = "range",
							name = L["Mid tick"],
							order = 10,
							min = 1, max = 3, softMin = 1, softMax = 2, step = 0.1,
						},
						high = {
							type = "range",
							name = L["High tick"],
							order = 10,
							min = 1, max = 3, softMin = 1, softMax = 2, step = 0.1,
						},
					},
				},
				low = {
					type = "toggle",
					name = L["Show low tick"],
					desc = L["Shows Combustion damage prediction even when Ignite tick is low."],
					order = 25,
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 30,
				},
				timer = {
					type = "group",
					inline = true,
					order = 60,
					args = {
						align = {
							type = "select",
							name = L["Timer location"],
							order = 10,
							disabled = function()
								return MBI.db.profile.modules.general.combustion.position == "TOP" or MBI.db.profile.modules.general.combustion.position == "BOTTOM"
							end,
							values = {
								above = L["Above"],
								bellow = L["Bellow"],
							},
						},
						reverse = {
							type = "toggle",
							name = L["Reverse"],
							order = 20,
						},
					},
				},
				space3 = {
					type = "description",
					name = " ",
					width = "full",
					order = 70,
				},
				scrollText = {
					type = "group",
					inline = true,
					order = 100,
					args = {
						color = {
							type = "color",
							order = 0,
							name = L["Scrolling text colour"],
							get = function()
								return MBI:GetColor(MBI.db.profile.modules.combustion.scrollText.color)
							end,
							set = function(info, r, g, b)
								MBI:SetColor(MBI.db.profile.modules.combustion.scrollText.color, r, g, b)
							end,
						},
						size = {
							type = "range",
							name = L["Scrolling text size"],
							desc = L["Portion of module size."],
							order = 10,
							min = 0.5, max = 3, step = 0.05 ,
						},
					},
				},
				space5 = {
					type = "description",
					name = " ",
					width = "full",
					order = 110,
				},
				iconText = {
					type = "group",
					inline = true,
					order = 120,
					args = {
						dmgSize = {
							type = "range",
							name = L["Damage text size"],
							desc = L["Portion of module size."],
							order = 10,
							min = 0.1, max = 1, step = 0.05 ,
						},
						dmgOfx = {
							type = "range",
							name = L["Horizontal offset"],
							order = 11,
							min = -10, max = 10, step = 0.05, bigStep = 0.25,
						},
						dmgOfy = {
							type = "range",
							name = L["Vertical offset"],
							order = 12,
							min = -2.5, max = 2.5, step = 0.05, bigStep = 0.25,
						},
						space0 = {
							type = "description",
							name = " ",
							width = "full",
							order = 15,
						},
						tickSize = {
							type = "range",
							name = L["Tick text size"],
							desc = L["Portion of module size."],
							order = 20,
							min = 0.1, max = 0.5, step = 0.05 ,
						},
						tickOfx = {
							type = "range",
							name = L["Horizontal offset"],
							order = 21,
							min = -10, max = 10, step = 0.05, bigStep = 0.25,
						},
						tickOfy = {
							type = "range",
							name = L["Vertical offset"],
							order = 22,
							min = -2.5, max = 2.5, step = 0.05, bigStep = 0.25,
						},
						space1 = {
							type = "description",
							name = " ",
							width = "full",
							order = 30,
						},
						cdTextEnabled = {
							type = "toggle",
							name = L["Enable CD text"],
							desc = L["Activates CD remaining timer display. Disable it if you use a cooldown addon like OmniCC."],
							order = 40,
						},
						cdSize = {
							type = "range",
							name = L["CD text size"],
							desc = L["Portion of module size."],
							disabled = function()
								return not MBI.db.profile.modules.general.combustion.enabled or not MBI.db.profile.modules.combustion.iconText.cdTextEnabled
							end,
							order = 50,
							min = 0.1, max = 1.5, step = 0.05 ,
						},
					},
				},
				space = {
					type = "description",
					name = " ",
					width = "full",
					order = 500,
				},
			},
		},
		space1 = {
			type = "description",
			name = " ",
			width = "full",
			order = 10,
		},
		heatingup = {
			type = "group",
			inline = true,
			order = 20,
			disabled = function()
				return not MBI.db.profile.modules.general.heatingup.enabled
			end,
			args = {
				header = {
					type = "header",
					name = L["Heating up module"],
					order = 0,
				},
				size = {
					type = "range",
					name = L["Module size"],
					order = 20,
					min = 1.25, max = 10, step = 0.05 ,
				},
				space1 = {
					type = "description",
					name = " ",
					width = "full",
					order = 30,
				},
				showHUPAlways = {
					type = "toggle",
					name = L["Always shown"],
					desc = L["If toggled, heating up icon will be shown even when Inferno Blast is on CD. Doesn't affect Pyroblast! icon."],
					order = 35,
				},
				vertical = {
					type = "toggle",
					name = L["Vertical"],
					desc = L["Displays icons vertically."],
					order = 40,
				},
				switch = {
					type = "toggle",
					name = L["Switch order"],
					desc = L["Switches Heating Up and Pyroblast! display order."],
					order = 50,
				},
				space2 = {
					type = "description",
					name = " ",
					width = "full",
					order = 60,
				},
				highlight = {
					type = "toggle",
					name = L["Highligt"],
					order = 70,
				},
				texture = {
					type = "select",
					name = L["Texture"],
					order = 80,
					values = {
						fire = L["Fire"],
						hl = L["Simple"],
					},
				},
				space3 = {
					type = "description",
					name = " ",
					width = "full",
					order = 90,
				},
				text = {
					type = "group",
					inline = true,
					order = 100,
					args = {
						enabled = {
							type = "toggle",
							name = L["Enable timer"],
							order = 0,
						},
						size = {
							type = "range",
							name = L["Text size"],
							desc = L["Portion of module size."],
							order = 10,
							min = 0.1, max = 1, step = 0.05 ,
						},
						space1 = {
							type = "description",
							name = " ",
							width = "full",
							order = 15,
						},
						anchor = {
							type = "select",
							name = L["Text Side"],
							order = 17,
							values = {
								RIGHT = L["Right"],
								LEFT = L["Left"],
								CENTER = L["Center"],
							},
						},
						ofx = {
							type = "range",
							name = L["Horizontal offset"],
							order = 20,
							min = -10, max = 10, step = 0.05, bigStep = 0.25,
						},
						ofy = {
							type = "range",
							name = L["Vertical offset"],
							order = 30,
							min = -10, max = 10, step = 0.05, bigStep = 0.25,
						},
						space = {
							type = "description",
							name = " ",
							width = "full",
							order = 500,
						},
					},
				},
			},
		},
	}	
	
	return options
end



--##############################################################################################################################################
-- managing of config panel --------------------------------------------------------------------------------------------------------------------

-- open config function
function MBI:OpenConfig()
	MBI.db.RegisterCallback(MBI, "OnProfileChanged", "Reset")
	MBI.db.RegisterCallback(MBI, "OnProfileCopied", "Reset")
	MBI.db.RegisterCallback(MBI, "OnProfileReset", "Reset")
	InterfaceOptionsFrame_OpenToCategory("myBigIgnite")
end

-- switch between real and fake options
function MBI:ChangeConfigDisplay(state)
	wipe(MBI.options.args)
	if state == "ooFireSpec" then
		if MBI.ooFOptions == nil then
			MBI:LoadooFOptions()
		end
		MBI.options.args = MBI:DeepCopy(MBI.ooFOptions.args)
	elseif state == "fireSpec" then
		if MBI.fireOptions == nil then
			MBI:LoadFireOptions()
		end
		MBI.options.args = MBI:DeepCopy(MBI.fireOptions.args)
		MBI.options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(MBI.db)
	else
		MBI.options.args = MBI:DeepCopy(MBI.fakeOptions.args)
	end
	ACR:NotifyChange("myBigIgnite")
end

-- profiles changing
function MBI:Reset()
	MBI:InitStatModule()
	MBI:InitPowerBar()
	
	MBI.font = LSM:Fetch("font", MBI.db.profile.general.layout.font)
	
	MBI:CreateSpellTables()
	
	MBI:SetIgniteFrame()
	MBI:SetCombustionFrame()
	MBI:SetHeatingUpFrame()
	
	MBI:UpdateIgniteFrame("low")
	MBI:UpdateIgniteTimerDisplay("low", 6)
	MBI:UpdateIgnitePowerDisplay(0)
	
	if MBI.db.profile.threshold.value == 0 then
		print(MBI.ORANGE .. L["myBigIgnite: "] .. MBI.YELLOW_LIGHT .. L["notyetthreshold"])
	end
	if MBI.db.profile.general.autohide.noCombat then
		MBI.F.main:Hide()
	else
		MBI.F.main:Show()
	end
end

-- resets layout
function MBI:ResetLayout()
	MBI.font = LSM:Fetch("font", MBI.db.profile.general.layout.font)
	MBI:SetIgniteFrame()
	if not MBI.cfMode and MBI.db.profile.general.autohide.noCombat then
		MBI.F.main:Hide()
	end
end



--##############################################################################################################################################
-- config mode associated functions ------------------------------------------------------------------------------------------------------------

-- config mode
function MBI:ConfigMode(cfmode)
	if cfmode then
		MBI.F.anchor:SetMovable(true)
		MBI.F.main:EnableMouse(true)
		MBI.F.main:Show()
		MBI.F.main:SetScript("OnMouseDown", function(self, button)
			MBI.F.anchor.isMoving = true
			MBI.F.anchor:StartMoving()
		end)
		MBI.F.main:SetScript("OnMouseUp", function(self, button)
				if MBI.F.anchor.isMoving then
					local UIScale = UIParent:GetScale()
					MBI.F.anchor.isMoving = nil
					MBI.F.anchor:StopMovingOrSizing()
					MBI.db.profile.general.anchor.coord.xcd, MBI.db.profile.general.anchor.coord.ycd = MBI.F.anchor:GetLeft() * UIScale, MBI.F.anchor:GetBottom() * UIScale
				end
		end)

		MBI.F.config = MBI.F.config or CreateFrame("Frame", nil, MBI.F.anchor)
		MBI.F.config:SetMovable(false)
		MBI.F.config:EnableMouse(false)
		MBI.F.config:Show()
		
		local i = 0
		local igRemain = -1
		local noTimer = true
		MBI.F.hup.value = 0
		MBI.F.pyro.value = 0
		MBI.F.config:SetScript("OnUpdate", function(self, elapsed)
			igRemain = igRemain - elapsed
			if igRemain < 0 then
				igRemain = 6
			end
			self.lastUpdate = (self.lastUpdate or 0) + elapsed
			
			if MBI.db.profile.modules.general.heatingup.enabled then
				if MBI.db.profile.modules.general.heatingup.show == "both" or MBI.db.profile.modules.general.heatingup.show == "hup" then
					if MBI.F.hup.value < 0.5 then
						MBI.F.hup.value = 6
					end
					MBI.F.hup:Show()
				else
					MBI.F.hup.value = 0
					MBI.F.hup:Hide()
				end
				
				if MBI.db.profile.modules.general.heatingup.show == "both" or MBI.db.profile.modules.general.heatingup.show == "pyro" then
					if MBI.F.pyro.value < 0.5 then
						MBI.F.pyro.value = 6
					end
					MBI.F.pyro:Show()
				else
					MBI.F.pyro.value = 0
					MBI.F.pyro:Hide()
				end
				
				MBI:UpdateHUPModule()
			end
			
			if MBI.inCombat then
				MBI.cfMode = false
				MBI:ConfigMode(MBI.cfMode)
			end
			
			if i < 3 then
				MBI:UpdateIgniteFrame("low")
				MBI:UpdateIgniteTimerDisplay("low", igRemain)
				MBI.F.timer.txt:SetText(MBI:FormatDamage(0, MBI.db.profile.ignite.layout.text.format))
				if MBI.db.profile.ignite.timer.enabled then
					MBI.F.timer:SetValue(igRemain)
				else
					MBI.F.timer:SetValue(0)
				end
				if MBI.db.profile.ignite.power.enabled then
					MBI.F.power.endValue = 0.3
				end
				if MBI.db.profile.modules.general.combustion.enabled and not MBI.combuCD then
					MBI.targetAuras.combustion.remain = 10
					MBI:UpdateCombustionModule("low", 0)
					MBI.F.combustion.text:Hide()
					MBI.F.combustion.tick:Hide()
					
					if noTimer then
						MBI.F.combustion.timer.value = 3
						MBI.F.combustion.timer:SetMinMaxValues(0, 3)
						MBI.F.combustion.timer:SetValue(3)
						MBI.F.combustion.timer:Show()
						noTimer = false
					end
					
					if not MBI.F.combustion.dmg[1].aniGroup:IsPlaying() then
						MBI.F.combustion.dmg[1].alpha = 1
						MBI.F.combustion.dmg[1]:SetAlpha(MBI.F.combustion.dmg[1].alpha)
						MBI.F.combustion.dmg[1].slide:SetDuration(2)
						MBI.F.combustion.dmg[1].text:SetTextColor(MBI:GetColor(MBI.db.profile.modules.combustion.scrollText.color))
						MBI.F.combustion.dmg[1].text:SetText(MBI:FormatDamage(MBI.db.profile.threshold.value / 2, "condensed"))
						MBI.F.combustion.dmg[1]:Show()
						MBI.F.combustion.dmg[1].aniGroup:Play()
						MBI.F.combustion.dmg[1].update:Show()
					end
					
					local fakeCD = 2
					if not MBI.combuCDShown then
						MBI.F.combustion.cooldown:SetCooldown(GetTime(), fakeCD)
						MBI.combuCDShown = true
					end
					if MBI.db.profile.modules.combustion.iconText.cdTextEnabled then
						MBI.F.combustion.cooldown.text:SetText(MBI:FormatTime(fakeCD))
						MBI.F.combustion.cooldown.text:Show()
					else
						MBI.F.combustion.cooldown.text:Hide()
					end

					
					MBI.F.combustion:Show()
				end
			elseif i < 6 then
				if MBI.db.profile.threshold.interm.enabled then
					MBI:UpdateIgniteFrame("mid")
					MBI:UpdateIgniteTimerDisplay("mid", igRemain)
					MBI.F.timer.txt:SetText(MBI:FormatDamage(MBI.db.profile.threshold.value * MBI.db.profile.threshold.interm.perct, MBI.db.profile.ignite.layout.text.format))
				end
				if MBI.db.profile.ignite.timer.enabled then
					MBI.F.timer:SetValue(igRemain)
				else
					MBI.F.timer:SetValue(0)
				end
				if MBI.db.profile.ignite.power.enabled then
					MBI.F.power.endValue = MBI.db.profile.ignite.power.middle
				end
				if MBI.db.profile.modules.general.combustion.enabled and not MBI.combuCD then
					MBI.targetAuras.combustion.remain = 0
					MBI.F.combustion.timer:Hide()
					MBI:UpdateCombustionModule("mid", MBI.db.profile.threshold.value * MBI.db.profile.threshold.interm.perct * 8, true, 15)
					MBI.F.combustion:Show()
				end
			elseif i < 9 then
				MBI:UpdateIgniteFrame("high")
				MBI:UpdateIgniteTimerDisplay("high", igRemain)
				MBI.F.timer.txt:SetText(MBI:FormatDamage(MBI.db.profile.threshold.value, MBI.db.profile.ignite.layout.text.format))
				if MBI.db.profile.ignite.timer.enabled then
					MBI.F.timer:SetValue(igRemain)
				else
					MBI.F.timer:SetValue(0)
				end
				if MBI.db.profile.ignite.power.enabled then
					MBI.F.power.endValue = 1
				end
				if MBI.db.profile.modules.general.combustion.enabled and not MBI.combuCD then
					MBI.targetAuras.combustion.remain = 0
					MBI.F.combustion.timer:Hide()
					MBI:UpdateCombustionModule("high", MBI.db.profile.threshold.value * 8, true, 15)
					MBI.F.combustion:Show()
				end
			end
			if (self.lastUpdate > MBI.REFRESH_CM) then
				i = i + 1
				if i >= 9 then
					i = 0
					noTimer = true
					MBI.combuCDShown = false
				end
				self.lastUpdate = 0
			end
		end)
	else
		MBI.F.timer.txt:SetText(MBI:FormatDamage(0, MBI.db.profile.ignite.layout.text.format))
		MBI.F.anchor:SetMovable(false)
		MBI.F.main:EnableMouse(false)
		MBI.F.config:Hide()
		MBI.F.timer:SetValue(0)
		MBI.F.power.endValue = 0
		MBI:UpdateIgniteFrame("low")
		if MBI.db.profile.general.autohide.noCombat then
			MBI.F.main:Hide()
		end
		
		if MBI.db.profile.modules.general.combustion.enabled then
			MBI.targetAuras.combustion.remain = 0
			MBI.F.combustion.timer.value = 0
			MBI.F.combustion.timer:SetMinMaxValues(0, 0)
			MBI.F.combustion.timer:SetValue(0)
			MBI.F.combustion.timer:Hide()
			MBI.F.combustion.dmg[1].aniGroup:Stop()
			MBI.F.combustion.dmg[1]:Hide()
			MBI.F.combustion.dmg[1].update:Hide()
			MBI.combuCDShown = false
			MBI:UpdateCombustionModule("low", 0, 0, 0)
			MBI.F.combustion:Hide()
		end
		
		if MBI.db.profile.modules.general.heatingup.enabled then
			MBI.F.hup.value = 0
			MBI.F.hup:Hide()
			
			MBI.F.pyro.value = 0
			MBI.F.pyro:Hide()
		end
		
		collectgarbage()
	end
end

