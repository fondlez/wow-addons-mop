--[[
		When you mouseover a unit frame, if the player is nearby but out
		of range, an arrow will appear beside the mouse pointing towards them.

		Note that "mouseover" is a valid unit only in the general area.
		It won't point towards someone in another part of the zone.

		05/20/2014 1.0.3 fix for error when mouse is over a unit upon login
		05/20/2014 1.0.2 initial release
]]


local slowThrottle = 0.10 -- update speed while mouseover exists but no arrow needed
local fastThrottle = 0.01 -- update speed when we want to point with the arrow

local pointer = CreateFrame("Frame",nil,UIParent,"SecureUnitButtonTemplate")
pointer.timer = 0
pointer:SetFrameStrata("FULLSCREEN")
pointer:SetAttribute("unit","mouseover")
RegisterUnitWatch(pointer) -- only show frame when "mouseover" exists

pointer.arrow = pointer:CreateTexture(nil,"OVERLAY")
pointer.arrow:SetSize(32,32)
pointer.arrow:SetTexture("Interface\\MiniMap\\MiniMap-QuestArrow")

local sqrt2 = sqrt(2) -- stuff to help texcoord mumbo jumbo later
local rads45 = 0.25*PI
local rads135 = 0.75*PI
local rads225 = 1.25*PI
local cos, sin = math.cos, math.sin
local function corner(r) return 0.5+cos(r)/sqrt2, 0.5+sin(r)/sqrt2 end

-- self here is pointer.arrow; update whether to show arrow and direction it points
local function UpdateArrow(self)

	-- hide arrow if mouseover is in range or we're not over a unit frame
	local focus = GetMouseFocus()
	if UnitInRange("mouseover") or not focus or not focus:GetAttribute("unit") then
		self:Hide()
		pointer.timer = slowThrottle
		return
	end

	local playerX, playerY = GetPlayerMapPosition("player")
	local unitX, unitY = GetPlayerMapPosition("mouseover")

	-- hide arrow if player is not in a zone with coordinates, or mouseover doesn't have
	-- coordinates, or player and mouseover are same unit
	if (playerX==0 and playerY==0) or (unitX==0 and unitY==0) or UnitIsUnit("player","mouseover") then
		self:Hide()
		pointer.timer = slowThrottle
		return
	end

	pointer.timer = fastThrottle -- we're going to show an arrow, speed up updates

	-- calculate angle between player facing and mouseover map position (trig courtesy of Javonthalas-Hyjal)
	local angle = atan2(unitY-playerY,playerX-unitX)*PI/180+PI/2
	if angle<0 then
		angle = angle+2*PI
	end
	angle = angle - GetPlayerFacing()

	-- rotate arrow to the calculated angle; from http://wowpedia.org/SetTexCoord_Transformations
	local ULx,ULy = corner(angle+rads225)
	local LLx,LLy = corner(angle+rads135)
	local URx,URy = corner(angle-rads45)
	local LRx,LRy = corner(angle+rads45)
	self:SetTexCoord(ULx,ULy,LLx,LLy,URx,URy,LRx,LRy)

	-- position arrow to lowerleft of cursor
	local cursorX, cursorY = GetCursorPosition()
	local scale = UIParent:GetEffectiveScale()
	self:SetPoint("CENTER",UIParent,"BOTTOMLEFT",cursorX/scale-10,cursorY/scale-12)

	self:Show()
end

-- this only runs while we have a mouseover unit due to RegisterUnitWatch
pointer:SetScript("OnUpdate",function(self,elapsed)
	self.timer = self.timer - elapsed
	if self.timer < 0 then
		UpdateArrow(self.arrow)
	end
end)

-- when we gain a mouseover unit, do an immediate update
pointer:SetScript("OnShow",function(self)
	UpdateArrow(self.arrow)
end)
