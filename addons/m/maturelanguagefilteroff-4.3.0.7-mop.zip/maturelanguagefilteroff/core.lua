local GetCVar,SetCVar,BNGetMatureLanguageFilter,BNSetMatureLanguageFilter,BNConnected =
      GetCVar,SetCVar,BNGetMatureLanguageFilter,BNSetMatureLanguageFilter,BNConnected

local frame=CreateFrame("Frame")
frame:Hide()

local function allowSwearing()
	if GetCVar("profanityFilter")~="0" then
		SetCVar("profanityFilter", "0")
		print("Turned Mature Language Filter off.")
	end
	if BNConnected() and BNGetMatureLanguageFilter() then 
		BNSetMatureLanguageFilter(false)
		print("Turned Battle.net Mature Language Filter off.")
	end
end

frame:SetScript("OnEvent", allowSwearing)
frame:RegisterEvent("VARIABLES_LOADED")
frame:RegisterEvent("CVAR_UPDATE")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("BN_MATURE_LANGUAGE_FILTER")
frame:RegisterEvent("BN_CONNECTED")

allowSwearing() -- in case we're LoDed
