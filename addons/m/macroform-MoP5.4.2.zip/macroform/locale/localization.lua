﻿BINDING_HEADER_MACRO_FORM = "|cFF000cFFMacro Form|r";
BINDING_NAME_MacroFormToggle = "Toggle Macro Form";