﻿Usage:

/mf - Opens the MacroForm window
/mf hide - Hides the MacroForm window

Drag a spell/ability from your spellbook to the spell area in the window.
Check the conditions and the target you want to use and press generate.
Copy the script from the bottom of the window and paste it in to a macro.

For castsequence hit the Sequence button at the top (OneLine to go back).
Set the conditions and reset conditions for your macro, drag in a spell,
press add, drag in a new spell, press add and so on until you're done.
Copy the script from the bottom of the window and paste it in to the macro,
or press "Create General" to make a general macro or "Create Character specific"
to create a macro for the character you are currently logged on to.
The new macros will have the name "NewMacro" and have the ? icon.
Colours will indicate what role a specific word plays in the macro like
command, spell and conditions. Red text indicates that something is wrong
and that the macro will not work.