local _, MySlot = ...

local L = setmetatable({}, {
	__index = function(table, key)
		if key then
			table[key] = tostring(key)
		end
		return tostring(key)
	end,
})


MySlot.L = L

--
-- Use http://www.wowace.com/addons/myslot/localization/ to translate thanks
-- 
local locale = GetLocale()

if locale == 'enUs' then
L["All slots were restored"] = true
L["Are you SURE to import ?"] = true
L["Bad importing text [CRC32]"] = true
L["Bad importing text [TEXT]"] = true
L["Close"] = true
L["Export"] = true
L["Feedback"] = true
L["Ignore unactived pet[id=%s], %s"] = true
L["Ignore unlearned skill [id=%s], %s"] = true
L["Import"] = true
L["Importing text [ver:%s] is not compatible with current version"] = true
L["Import is not allowed when you are in combat"] = true
L["Macro %s was ignored, check if there is enough space to create"] = true
L["Time"] = true
L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = true
L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = true
L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = true

elseif locale == 'deDE' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'esES' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'esMX' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'frFR' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'itIT' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'koKR' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'ptBR' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'ruRU' then
-- L["All slots were restored"] = "All slots were restored"
-- L["Are you SURE to import ?"] = "Are you SURE to import ?"
-- L["Bad importing text [CRC32]"] = "Bad importing text [CRC32]"
-- L["Bad importing text [TEXT]"] = "Bad importing text [TEXT]"
-- L["Close"] = "Close"
-- L["Export"] = "Export"
-- L["Feedback"] = "Feedback"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
-- L["Import"] = "Import"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
-- L["Time"] = "Time"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

elseif locale == 'zhCN' then
L["All slots were restored"] = "所有按钮及按键邦定位置恢复完毕"
L["Are you SURE to import ?"] = "你 确定 要导入么？？？"
L["Bad importing text [CRC32]"] = "导入字符码校验不合法 [CRC32]"
L["Bad importing text [TEXT]"] = "导入字符不合法 [TEXT]"
L["Close"] = "关闭"
L["Export"] = "导出"
L["Feedback"] = "问题/建议"
L["Ignore unactived pet[id=%s], %s"] = "忽略未开启的战斗宠物[id=%s]：%s"
L["Ignore unlearned skill [id=%s], %s"] = "忽略未掌握技能[id=%s]：%s"
L["Import"] = "导入"
L["Importing text [ver:%s] is not compatible with current version"] = "导入串版本不兼容当前Myslot版本 导入版本号 %s"
L["Import is not allowed when you are in combat"] = "请在非战斗时候使用导入功能"
L["Macro %s was ignored, check if there is enough space to create"] = "宏 [ %s ] 被忽略，请检查是否有足够的空格创建宏"
L["Time"] = "时间"
L["TOC_NOTES"] = "保存你的技能按钮位置 farmer1992@gmail.com"
L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] 忽略出错技能 DEBUG INFO = [S=%s T=%s I=%s] 请将出错的字符和 DEBUG INFO 发给作者 %s"
L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN]忽略不支持的绑定 K = [ %s ] 请通知作者 %s"
L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN]忽略不支持的按键类型[ %s ] 请通知作者 %s"

elseif locale == 'zhTW' then
-- L["All slots were restored"] = "All slots were restored"
L["Are you SURE to import ?"] = "你確定要導入嗎？"
L["Bad importing text [CRC32]"] = "錯誤的導入字符串[CRC32]"
L["Bad importing text [TEXT]"] = "錯誤的導入字符串[TEXT]"
L["Close"] = "關閉"
L["Export"] = "導出"
L["Feedback"] = "反饋"
-- L["Ignore unactived pet[id=%s], %s"] = "Ignore unactived pet[id=%s], %s"
-- L["Ignore unlearned skill [id=%s], %s"] = "Ignore unlearned skill [id=%s], %s"
L["Import"] = "導入"
-- L["Importing text [ver:%s] is not compatible with current version"] = "Importing text [ver:%s] is not compatible with current version"
-- L["Import is not allowed when you are in combat"] = "Import is not allowed when you are in combat"
-- L["Macro %s was ignored, check if there is enough space to create"] = "Macro %s was ignored, check if there is enough space to create"
L["Time"] = "時間"
-- L["TOC_NOTES"] = "Myslot is for transfering settings between accounts. Feedback farmer1992@gmail.com"
-- L["[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"] = "[WARN] Ignore slot due to an unknown error DEBUG INFO = [S=%s T=%s I=%s] Please send Importing Text and DEBUG INFO to %s"
-- L["[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Key Binding [ %s ] , contact %s please"
-- L["[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"] = "[WARN] Ignore unsupported Slot Type [ %s ] , contact %s please"

end

