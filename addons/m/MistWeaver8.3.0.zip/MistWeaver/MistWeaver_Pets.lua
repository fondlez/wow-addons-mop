
function MistWeaver_InitPets()
end
