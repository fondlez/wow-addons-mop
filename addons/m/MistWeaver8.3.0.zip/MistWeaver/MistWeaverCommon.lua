

local debug = false;
function mw_debug(...)
    if (not debug) then
        return;
    end

    local message = "";

    for i = 1, select("#", ...) do
		message = message .. " " .. (select(i, ...) or "nil");
	end

    DEFAULT_CHAT_FRAME:AddMessage("CUI DEBUG:"..(message or "nil"), 1.0, 1.0, 1.0, 1, 10);
end

function mw_info(message)
    if (message) then
        DEFAULT_CHAT_FRAME:AddMessage(message, 1.0, 1.0, 1.0, 1, 10);
    end
end

function mw_pairsByKeys(t, f)
    local a = {};

    for n in pairs(t) do
        table.insert(a, n)
    end

    table.sort(a, f);
    local i = 0;      -- iterator variable
    local iter = function ()   -- iterator function
        i = i + 1;
        if a[i] == nil then
            return nil;
        else
            return a[i], t[a[i]];
        end
    end

    return iter;
end

function mw_pairsByKeysDesc(t, f)
    local a = {}
    for n in pairs(t) do table.insert(a, n) end
    table.sort(a, function(a,b) return a>b end)
    local i = 0      -- iterator variable
    local iter = function ()   -- iterator function
        i = i + 1
        if a[i] == nil then return nil
        else return a[i], t[a[i]]
        end
    end
    return iter
end

function mw_rgb2hex(red, green, blue)

    if (not red) then
        red = 1.0;
    end

    if (not green) then
        green = 1.0;
    end

    if (not blue) then
        blue = 1.0;
    end

    local r = string.format("%x", red * 255);
    local g = string.format("%x", green * 255);
    local b = string.format("%x", blue * 255);

    if (strlen(r) < 2) then
        r = "0"..r;
    end
    if (strlen(g) < 2) then
        g = "0"..g;
    end
    if (strlen(b) < 2) then
        b = "0"..b;
    end

    local color = r..g..b;

    return color;
end

function MistWeaver_RemoveTextures(frame)
    for i, child in ipairs({frame:GetRegions()}) do

        if (child and child:IsObjectType("texture")) then
            child:SetTexture(nil);
        end
    end
end

function MistWeaver_SetBackdrop(frame)

    local background = "Interface\\Addons\\MistWeaver\\images\\frame-background";
    local border = "Interface\\Addons\\MistWeaver\\images\\frame-border";

    local insetValue = 2;

    frame:SetBackdrop( {
        bgFile = background,
        edgeFile = border, tile = true, tileSize = 64, edgeSize = 16,
        insets = { left = insetValue, right = insetValue, top = insetValue, bottom = insetValue }
    });
end

function MW_UnitBuff(unit, spellName)
    local name, icon, count, debuffType, duration, expirationTime, unitCaster, canStealOrPurge, xy, spellId, canApplyAura;
    for ii=1, 40 do 
        name, icon, count, debuffType, duration, expirationTime, unitCaster, canStealOrPurge, xy, spellId, canApplyAura = UnitBuff(unit, ii);
        if (name and name == spellName) then
            return name, icon, count, debuffType, duration, expirationTime, unitCaster, canStealOrPurge, xy, spellId, canApplyAura;
        end
    end
    
    return nil;
end
