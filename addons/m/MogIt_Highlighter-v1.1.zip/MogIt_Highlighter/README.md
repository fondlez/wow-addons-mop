MogIt Highlighter
=================


What it does
------------

MogIt Highlighter will place a bright glowy border over items in your MogIt wishlist, making them easier to find.

The addon will highlight:

* Quest Rewards
* Vendor Goods

Requires [MogIt](http://www.curse.com/addons/wow/mogit) to work.


Configuration
-------------

There are no options for this addon.  Simply install and go!


Translations
------------

This addon should work for everyone regardless of language.


Feedback
--------

If you have any comments, bug reports or feature requests, please leave a comment here or open a ticket on [WoWace](http://www.wowace.com/addons/mogit-highlighter/tickets/) or [GitHub](https://github.com/EthanCentaurai/MogIt_Highlighter/issues).


* * *


* Visit my [website](http://www.ethancentaurai.com/).
* Follow me on [Twitter](http://twitter.com/StevenBlanchard).
* Watch me on [GitHub](https://github.com/EthanCentaurai).
