--[[


Movable Holy Power

by evil.oz/Morfraen

2.04
----
fixed mouse interaction, now you can properly click thru the frame

2.03
----
back to a cloned powerbar for pitbull compatibility (and all addons that remove player UF)

2.02
----
added checkbox to make alpha blening progressive as the stacks increase
added checkbox to allow always-transparent bar when no charges available
code cleanup

2.01b (unreleased)
----
moved to internal powerbar
rewrote mount detection (ismmounted() seems broken in 5.0)


2.0 by Morfraen
----
rebuild using blizzard PaladinPowerBar instead of just 3 hardcoded images for 1-2 holy power

1.45
----
trying to change event handling to prevent frame appear when addon is disinstalled

1.44
----
toc bump
fixed error at boot, still no idea on how to fix the options reset

1.43
----
toc bump

1.42
----
main frame is now a child of UIParent
 
1.41
----
more range to x/y offset
moved saving variables to global from percharacter 

1.4
---
added options to see bar in combat, mounted and in vehicle (by popular request)

1.3
---
no bar while in vehicle

1.2
---
removed bar when mounted

1.1
---
fix on scaling sliders

1.0
---
initial un-release


]]




function MovableHolyPower_OnLoad(this)

	MovableHolyPower_combat=nil

	local cls, class = UnitClass("player");
	if (class == "PALADIN") then
		
		local events={}
		
		function events:VARIABLES_LOADED()
			DEFAULT_CHAT_FRAME:AddMessage("Movable Holy Power loaded sucessful", 1.0, 1.0, 0.0);
			--hide blizz one
			PaladinPowerBar:SetAlpha(0)
									
			MovableHolyPower_panel = MovableHolyPower_options
		  MovableHolyPower_panel.name = "Movable Holy Power"
			MovableHolyPower_panel.okay = MovableHolyPower_PanelOk
		  MovableHolyPower_panel.cancel = MovableHolyPower_PanelCancel
			InterfaceOptions_AddCategory(MovableHolyPower_panel)
				
			if (not MovableHolyPower_data) then
				MovableHolyPower_resetData()
			end
	
			MovableHolyPower_createFrames()
			
			MovableHolyPower_Refresh()
			
		end
		
		function events:PLAYER_REGEN_DISABLED()
		    MovableHolyPower_combat="we are under attack"
	    	MovableHolyPower_Refresh()
		end
		
		function events:PLAYER_REGEN_ENABLED()
		    MovableHolyPower_combat= nil
	   		MovableHolyPower_Refresh()
		end
		
		function events:COMPANION_UPDATE()
		  MovableHolyPower_Refresh()
		end
		
		function events:UNIT_POWER(unit,type)
			if unit == "player" and type == "HOLY_POWER" then
				MovableHolyPower_Refresh()
			end
		end
			
		function events:UNIT_ENTERED_VEHICLE(unit)
			if unit == "player" then
				MovableHolyPower_Refresh()
			end
		end
				
		function events:UNIT_EXITED_VEHICLE(unit)
			if unit == "player" then
				MovableHolyPower_Refresh()
			end
		end
		
		-- activate events (cryptic blizz crap)
		MovableHolyPower_frame:SetScript("OnEvent", function(self, event, ...)
		 							events[event](self, ...); 
								end
						);
		for k, v in pairs(events) do
			MovableHolyPower_frame:RegisterEvent(k);
		end
		
	else 
		DEFAULT_CHAT_FRAME:AddMessage("Movable Holy Power disabled, not a paladin", 1.0, 1.0, 0.0);
	end

end


-- toggle function
function  MovableHolyPower_Refresh()

	local power = UnitPower("player",9)
	local alpha = MovableHolyPower_data.alpha
	
	
	if 	MovableHolyPower_data.progressive then
		alpha = alpha * (0.2 + (0.3 * power))
	end
	
	if  MovableHolyPower_data.hideFirst and power==0 then
	  alpha=0
	end
	                   
	MovableHolyPowerBar:SetAlpha(alpha)	

	if (not MovableHolyPower_IsMounted() or MovableHolyPower_data.showWhenMounted) and (not UnitInVehicle("player") or MovableHolyPower_data.showInVehicle) and (MovableHolyPower_combat or MovableHolyPower_data.showOffCombat) then
		MovableHolyPowerBar:Show()
	else			
		MovableHolyPowerBar:Hide()
	end
end	


function MovableHolyPower_resetData()
	              
	MovableHolyPower_data={}
	MovableHolyPower_data.showOffCombat=nil
	MovableHolyPower_data.showWhenMounted=nil
	MovableHolyPower_data.showInVehicle=nil
	MovableHolyPower_data.scale=1
	MovableHolyPower_data.alpha=1
	MovableHolyPower_data.x=0
	MovableHolyPower_data.y=70
	MovableHolyPower_data.progressive=nil
	MovableHolyPower_data.hideFirst=nil
		
end


function MovableHolyPower_createFrames()

	-- Set up main frame
	
	--replace blizzard background (no chains) - no need, we use custom one now
	--MovableHolyPowerBarBankBG:SetTexture("Interface\\AddOns\\MovableHolyPower\\PALADINPOWERTEXTURES.tga")	
	--MovableHolyPowerBarBG:SetTexture("Interface\\AddOns\\MovableHolyPower\\PALADINPOWERTEXTURES.tga")
	--MovableHolyPowerBarGlowBGTexture:SetTexture("Interface\\AddOns\\MovableHolyPower\\PALADINPOWERTEXTURES.tga")	
	
	MovableHolyPowerBar:ClearAllPoints()
	MovableHolyPowerBar:SetPoint("CENTER","UIParent","CENTER",MovableHolyPower_data.x,MovableHolyPower_data.y)
	MovableHolyPowerBar:SetScale(MovableHolyPower_data.scale)
	MovableHolyPowerBar:SetAlpha(MovableHolyPower_data.alpha)
	MovableHolyPowerBar:Hide()
	
end


function MovableHolyPower_InitConfigPage()

	
	MovableHolyPower_optionsScaleSlider:SetValue(MovableHolyPower_data.scale)
	MovableHolyPower_optionsAlphaSlider:SetValue(MovableHolyPower_data.alpha)
	MovableHolyPower_optionsXSlider:SetValue(MovableHolyPower_data.x)
	MovableHolyPower_optionsYSlider:SetValue(MovableHolyPower_data.y)
	
  MovableHolyPower_optionsScaleSliderText:SetFormattedText("%1.1f",MovableHolyPower_optionsScaleSlider:GetValue())
	MovableHolyPower_optionsAlphaSliderText:SetFormattedText("%1.2f",MovableHolyPower_optionsAlphaSlider:GetValue())
	MovableHolyPower_optionsXSliderText:SetFormattedText("%d",MovableHolyPower_optionsXSlider:GetValue())
	MovableHolyPower_optionsYSliderText:SetFormattedText("%d",MovableHolyPower_optionsYSlider:GetValue())
	
	
	MovableHolyPower_optionsProgressive:SetChecked(MovableHolyPower_data.progressive)
	MovableHolyPower_optionsHideFirst:SetChecked(MovableHolyPower_data.hideFirst)
	
	MovableHolyPower_optionsShowOffCombat:SetChecked(MovableHolyPower_data.showOffCombat)
	MovableHolyPower_optionsShowWhenMounted:SetChecked(MovableHolyPower_data.showWhenMounted)
	MovableHolyPower_optionsShowInVehicle:SetChecked(MovableHolyPower_data.showInVehicle)
	
	
end

function MovableHolyPower_SliderChanged(this)

	if MovableHolyPower_data then 
	
		local ctrl = this:GetName()
			
		if ctrl ==  "MovableHolyPower_optionsScaleSlider"   then
			MovableHolyPower_optionsScaleSliderText:SetFormattedText("%1.1f",this:GetValue())
			MovableHolyPowerBar:SetScale(this:GetValue())
		end	
		if ctrl ==  "MovableHolyPower_optionsAlphaSlider"   then
			MovableHolyPower_optionsAlphaSliderText:SetFormattedText("%1.2f", this:GetValue())
			MovableHolyPowerBar:SetAlpha(this:GetValue())

		end	
		if ctrl ==  "MovableHolyPower_optionsXSlider"   then
			MovableHolyPower_optionsXSliderText:SetFormattedText("%d",this:GetValue())
			MovableHolyPowerBar:ClearAllPoints()
			MovableHolyPowerBar:SetPoint("CENTER","UIParent","CENTER",MovableHolyPower_optionsXSlider:GetValue(),MovableHolyPower_optionsYSlider:GetValue())
			
		end	
		if ctrl ==  "MovableHolyPower_optionsYSlider"   then 
			MovableHolyPower_optionsYSliderText:SetFormattedText("%d",this:GetValue())
			MovableHolyPowerBar:ClearAllPoints()
			MovableHolyPowerBar:SetPoint("CENTER","UIParent","CENTER",MovableHolyPower_optionsXSlider:GetValue(),MovableHolyPower_optionsYSlider:GetValue())
		end	
				
	end	
end

function MovableHolyPower_optionsSHOW()

	MovableHolyPowerBar:Show()
	MovableHolyPower_InitConfigPage()

end	


function MovableHolyPower_PanelCancel()

	--restore main frame
	
 	MovableHolyPowerBar:SetAlpha(MovableHolyPower_data.alpha)
  MovableHolyPowerBar:ClearAllPoints()
	MovableHolyPowerBar:SetPoint("CENTER","UIParent","CENTER",MovableHolyPower_data.x,MovableHolyPower_data.y)
	
end

function MovableHolyPower_PanelOk()

	MovableHolyPowerBar:Hide()
	
	local _, _, _, x, y = MovableHolyPowerBar:GetPoint(1)
	MovableHolyPower_data.x = x
	MovableHolyPower_data.y = y
	MovableHolyPower_data.scale = MovableHolyPower_optionsScaleSlider:GetValue()
  MovableHolyPower_data.alpha = 	MovableHolyPower_optionsAlphaSlider:GetValue()
	      
	MovableHolyPower_Refresh()
	
end


function MovableHolyPower_HideFirstClick(this)

 	MovableHolyPower_data.hideFirst = MovableHolyPower_optionsHideFirst:GetChecked()
	MovableHolyPower_Refresh()
		
end

function MovableHolyPower_ProgressiveClick(this)

 	MovableHolyPower_data.progressive = MovableHolyPower_optionsProgressive:GetChecked()
	MovableHolyPower_Refresh()
		
end

function MovableHolyPower_ShowOffCombatClick(this)

	MovableHolyPower_data.showOffCombat = MovableHolyPower_optionsShowOffCombat:GetChecked()
	MovableHolyPower_Refresh()	

end


function MovableHolyPower_ShowWhenMountedClick(this)

	MovableHolyPower_data.showWhenMounted = MovableHolyPower_optionsShowWhenMounted:GetChecked()
	MovableHolyPower_Refresh()	

end

function MovableHolyPower_ShowInVehicleClick(this)

	MovableHolyPower_data.showInVehicle = MovableHolyPower_optionsShowInVehicle:GetChecked()
	MovableHolyPower_Refresh()	

end

function MovableHolyPower_IsMounted()
	for i=1,GetNumCompanions("CRITTER") do
    local creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("Mount", i);
    if (creatureID) then
				if (issummoned) then
				  --DEFAULT_CHAT_FRAME:AddMessage("You are mounted on "..creatureName, 1.0, 1.0, 0.0); 
					return 1
				end
		end
	end
end



---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
-- 
-- code from original blizzard frame
-- 
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------



HOLY_POWER_FULL = 3;
PALADINPOWERBAR_SHOW_LEVEL = 9;

function MovableHolyPowerBar_ToggleHolyRune(self, visible)
	if visible then
		self.deactivate:Play();
	else
		self.activate:Play();
	end
end

function MovableHolyPowerBar_OnUpdate(self, elapsed)
	self.delayedUpdate = self.delayedUpdate - elapsed;
	if ( self.delayedUpdate <= 0 ) then
		self.delayedUpdate = nil;
		self:SetScript("OnUpdate", nil);
		MovableHolyPowerBar_Update(self);
	end
end

function MovableHolyPowerBar_Update(self)
	if ( self.delayedUpdate ) then
		return;
	end
	
	local numHolyPower = UnitPower("player", SPELL_POWER_HOLY_POWER );
	local maxHolyPower = UnitPowerMax("player", SPELL_POWER_HOLY_POWER );
	
	-- a little hacky but we want to signify that the bank is being used to replenish holy power
	if ( self.lastPower and self.lastPower > HOLY_POWER_FULL and numHolyPower == self.lastPower - HOLY_POWER_FULL ) then
		for i = 1, HOLY_POWER_FULL do
			MovableHolyPowerBar_ToggleHolyRune(self["rune"..i], true);
		end
		self.lastPower = nil;
		self.delayedUpdate = 0.5;
		self:SetScript("OnUpdate", MovableHolyPowerBar_OnUpdate);
		return;
	end
	
	for i=1,maxHolyPower do
		local holyRune = self["rune"..i];
		local isShown = holyRune:GetAlpha()> 0 or holyRune.activate:IsPlaying();
		local shouldShow = i <= numHolyPower;
		if isShown ~= shouldShow then 
			MovableHolyPowerBar_ToggleHolyRune(holyRune, isShown);
		end
	end

	-- flash the bar if it's full (3 holy power)
	if numHolyPower >= HOLY_POWER_FULL then
		self.glow.pulse.stopPulse = false;
		self.glow.pulse:Play();
	else
		self.glow.pulse.stopPulse = true;
	end
	
	-- check whether to show bank slots
	if ( maxHolyPower ~= self.maxHolyPower ) then
		if ( maxHolyPower > HOLY_POWER_FULL ) then
			self.showBankAnim:Play();
		else
			-- there is no way to lose the bank slots once you have them, but just in case
			self.showBankAnim:Stop();
			self.bankBG:SetAlpha(0);
		end
		self.maxHolyPower = maxHolyPower;
	end
	
	self.lastPower = numHolyPower;
end



function MovableHolyPowerBar_OnLoad (self)
	-- Disable frame if not a paladin
	local _, class = UnitClass("player");	
	if ( class ~= "PALADIN" ) then
		self:Hide();
		return;
	elseif UnitLevel("player") < PALADINPOWERBAR_SHOW_LEVEL then
		self:RegisterEvent("PLAYER_LEVEL_UP");
		self:SetAlpha(0);
	end
	
	self.maxHolyPower = UnitPowerMax("player", SPELL_POWER_HOLY_POWER);
	if ( self.maxHolyPower > HOLY_POWER_FULL ) then
		self.bankBG:SetAlpha(1);
	end

	self:RegisterEvent("UNIT_POWER");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("UNIT_DISPLAYPOWER");
	
	self.glow:SetAlpha(0);
	self.rune1:SetAlpha(0);
	self.rune2:SetAlpha(0);
	self.rune3:SetAlpha(0);
	self.rune4:SetAlpha(0);
	self.rune5:SetAlpha(0);
end



function MovableHolyPowerBar_OnEvent (self, event, arg1, arg2)
	if ( (event == "UNIT_POWER") and (arg1 == "player") ) then
		if ( arg2 == "HOLY_POWER" ) then
			MovableHolyPowerBar_Update(self);
		end
	elseif( event ==  "PLAYER_LEVEL_UP" ) then
		local level = arg1;
		if level >= PALADINPOWERBAR_SHOW_LEVEL then
			self:UnregisterEvent("PLAYER_LEVEL_UP");
			self.showAnim:Play();
			MovableHolyPowerBar_Update(self);
		end
	else
		MovableHolyPowerBar_Update(self);
	end
end

