-------------------------------------------------------------------------------
-- MrTrader 
--
-- Suite of tools for the avid crafter.
--
-- Send suggestions, comments, and bugs to user@zedonline.net
-------------------------------------------------------------------------------

-----
-- XML Definitions
-----
MRTRADER_NEW_CATEGORY = MRTLoc["New Group"];
MRTRADER_NEW_FAVORITE_GROUP = MRTLoc["New Favorite Group"];
MRTRADER_NAME = MRTLoc["Name"];
MRT_QUEUE = MRTLoc["Queue"];
MRT_SHOW_QUEUE = MRTLoc["Show Queue"];
MRT_HIDE_QUEUE = MRTLoc["Hide Queue"];
MRT_CLEAR_SEARCH = MRTLoc["Clear Search"];
MRT_SHOW_FILTERS = MRTLoc["Show Filter List"];
MRT_HIDE_FILTERS = MRTLoc["Hide Filter List"];
