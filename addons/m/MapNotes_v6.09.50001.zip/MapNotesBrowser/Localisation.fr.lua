
MNB_NAME = "MapNotes Chercher";

MNB_ALLMAPS = "Toutes les Cartes";
MNB_SEARCH = "Chercher";

