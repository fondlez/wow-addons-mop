﻿local ADDON_NAME = ...

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_NAME, "zhCN", false);

if not L then return end

L["Auction expired"] = "拍卖过期" -- Needs review
L["Datafeed"] = "数据中心" -- Needs review
L["Draws the icon on the minimap."] = "小地图显示插件图标" -- Needs review
L["Hide Hint Text"] = "隐藏提示文字" -- Needs review
L["Hides the hint text at the bottom of the tooltip."] = "隐藏提示信息底部的文字" -- Needs review
L["Minimap Icon"] = "小地图图标" -- Needs review
L["Move the slider to adjust the scale of the tooltip."] = "移动滚动条以调整提示信息的大小" -- Needs review
L["Move the slider to adjust the tooltip fade time."] = "移动滚动条以调整提示信息的淡出时间" -- Needs review
L["Right-click to open configuration menu."] = "右键点击打开设置菜单" -- Needs review
L["Tooltip"] = "提示信息" -- Needs review
L["Tooltip Scale"] = "提示信息大小" -- Needs review
L["Tooltip Timer"] = "提示信息时间" -- Needs review
