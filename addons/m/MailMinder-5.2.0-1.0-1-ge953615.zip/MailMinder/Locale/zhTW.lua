﻿local ADDON_NAME = ...

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_NAME, "zhTW", false)

if not L then return end

L["Auction expired"] = "拍賣過期" -- Needs review
L["Datafeed"] = "數據中心" -- Needs review
L["Draws the icon on the minimap."] = "小地圖顯示插件圖標" -- Needs review
L["Hide Hint Text"] = "隱藏提示文字" -- Needs review
L["Hides the hint text at the bottom of the tooltip."] = "隱藏提示信息底部的文字" -- Needs review
L["Minimap Icon"] = "小地圖圖標" -- Needs review
L["Move the slider to adjust the scale of the tooltip."] = "移動滾動條以調整提示信息的大小" -- Needs review
L["Move the slider to adjust the tooltip fade time."] = "移動滾動條以調整提示信息的淡出時間" -- Needs review
L["Right-click to open configuration menu."] = "右鍵點擊打開設置菜單" -- Needs review
L["Tooltip"] = "提示信息" -- Needs review
L["Tooltip Scale"] = "提示信息大小" -- Needs review
L["Tooltip Timer"] = "提示信息時間" -- Needs review
