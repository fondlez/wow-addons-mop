-- Copyright © 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.

if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

_G["MonkTimers"] = MonkTimers

local Version = 0.7

local SpellIDs = MonkTimers.SpellIDs

MonkTimers.DefaultGlobalSettings = {
	Version = 0.7,
    Profiles = {},
    Sink = {}
}

MonkTimers_Profiles = {
    ["default"] = {}
}
MonkTimers_GlobalSettings = {}

MonkTimers.DefaultProfile = {

    --General            
        Lock = false,
        FlashRed = true,
        ShowTimerBars = true,
        Tooltips = true,
        TooltipsAtButtons = true,
        TimeFont = "Friz Quadrata TT",
        TimeColor = {r=1,g=1,b=1},
        TimerBarTexture = "Blizzard",
        TimerBarColor = {r=0.5,g=0.5,b=1.0,a=1.0},
        ShowKeybinds = true,
        HideInVehicle = true,
        StopPulse = true,
        TimersOnButtons = false,
        
        
    --CDs
        Timer_Spells = {
            [2] = {
                [1] = true, 
                [2] = true, 
                [3] = true, 
                [4] = true, 
                [5] = true, 
                [6] = true, 
                [7] = true, 
                [8] = true, 
                [9] = true, 
                [10] = true, 
				[11] = true,
				[12] = true,
            },
            [1] = {
                [1] = true, 
                [2] = true, 
                [3] = true, 
                [4] = true, 
                [5] = true, 
                [6] = true, 
                [7] = true, 
                [8] = true, 
                [9] = true, 
                [10] = true, 
				[11] = true,
				[12] = true,
            },
            [3] = {
                [1] = true, 
                [2] = true, 
                [3] = true, 
                [4] = true, 
                [5] = true, 
                [6] = true, 
                [7] = true, 
				[8] = true,
				[9] = true,
				[10] = true,
				[11] = true,
				[12] = true,
            },
        },
        Timer_Order = {
            [2] = {
                [1] = 1, 
                [2] = 2, 
                [3] = 3, 
                [4] = 4, 
                [5] = 5, 
                [6] = 6, 
                [7] = 7, 
                [8] = 8, 
                [9] = 9, 
                [10] = 10,
				[11] = 11,				
            },
            [1] = {
                [1] = 1, 
                [2] = 2, 
                [3] = 3, 
                [4] = 4, 
                [5] = 5, 
                [6] = 6, 
                [7] = 7, 
                [8] = 8, 
                [9] = 9, 
                [10] = 10, 
                [11] = 11, 
            },
            [3] = {
                [1] = 1, 
                [2] = 2, 
                [3] = 3, 
                [4] = 4,
                [5] = 5, 
                [6] = 6,
                [7] = 7,
				[8] = 8,
				[9] = 9,
				[10] = 10,
				[11] = 11,
            },
        },
        Timers = true,
        TimerSize = 30,
        TimerTimeHeight = 12,
        TimerOOCAlpha = 0.4,
        TimersOnButtons = true,
        Clickthrough = false,
        HideTimersOOC = false,
    
        FramePositions = {
            MonkTimersFrame = {"CENTER", nil, "CENTER", 0, -200},
			MonkTimers_LongCooldownsFrame = {"CENTER", nil, "CENTER", 220, -200},
        },
		
		LongCooldowns = true,
		LongCooldownSpells = {
			[SpellIDs.FortifyingBrew] = true,
			[SpellIDs.AvertHarm] = true,
			[SpellIDs.LifeCocoon] = true,
			[SpellIDs.TouchOfKarma] = true,
			[SpellIDs.DampenHarm] = true,
			[SpellIDs.DiffuseMagic] = true,
			[SpellIDs.Xuen] = true,
			[SpellIDs.RushingJadeWind] = true,
			[SpellIDs.ZenMeditation] = true,
			[SpellIDs.Revival] = true,			
		},
		LongCooldownsArrange = "horizontal",
		
		StaggerBar = true,
		StaggerHeight = 17,
		StaggerDot = true,
		StaggerDotTotal = true,
		StaggerDotPercent = true,
		ChiBar = true,
		ChiBarSize = 1,
		HideBlizzardChiBar = false,
        
		CloudFart = false,
}

MonkTimers.ActiveProfile = MonkTimers_Profiles.default


local function copy(object) 
    if type(object) ~= "table" then
        return object
    else
        local newtable = {}
        for k,v in pairs(object) do
            newtable[k] = copy(v)
        end
        return newtable
    end
end




function MonkTimers.CreateProfile(name)
    if not MonkTimers_Profiles[name] then
        MonkTimers.ResetProfile(name)
        return true
    else
        return false
    end
end


function MonkTimers.DeleteProfile(name)
    if name == "default" then return end
    MonkTimers_Profiles[name] = nil
    for u,p in pairs(MonkTimers_GlobalSettings.Profiles) do
        for i = 1,3 do
            for _,v in pairs({"none","party","arena","pvp","raid"}) do
                if p[i][v] == name then
                    p[i][v] = "default"
                end
            end
        end
    end
end

function MonkTimers.ResetProfile(name)
    MonkTimers_Profiles[name] = copy(MonkTimers.DefaultProfile)
end

function MonkTimers.ResetAllProfiles()
    MonkTimers_Profiles = {
        ["default"] = {}
    }
    MonkTimers.ResetProfile("default")
end

function MonkTimers.SelectActiveProfile()
    local player = UnitName("player")
    local specialization = GetSpecialization()
    if not specialization then specialization = 2 end
    local _,instance = IsInInstance()
	if not instance then instance = "party" end
    MonkTimers.ActiveProfile = MonkTimers_Profiles[MonkTimers_GlobalSettings.Profiles[player][specialization][instance]] or MonkTimers_Profiles.default
end


function MonkTimers.ExecuteProfile()
    MonkTimers.ProcessAllSettings()
end

local SettingsConverters = {
	[0.6] = function()
		MonkTimers_GlobalSettings.Version = 0.7
		for k,v in pairs(MonkTimers_Profiles) do
			v.CloudFart = false
		end
	end,
}

	
function MonkTimers.UpdateProfiles()

    if not MonkTimers_Profiles then MonkTimers_Profiles = {default={}} end
    
	if not MonkTimers_GlobalSettings.Version or MonkTimers_GlobalSettings.Version <= 0.5 then
		DEFAULT_CHAT_FRAME:AddMessage("MonkTimers: Pre-1.0 or no saved settings found, loading defaults...")
        MonkTimers_GlobalSettings = {}
		MonkTimers.ResetAllProfiles()
	elseif MonkTimers_GlobalSettings.Version ~= Version then
        if not SettingsConverters[MonkTimers_GlobalSettings.Version] then
            DEFAULT_CHAT_FRAME:AddMessage("MonkTimers: Unknown settings found, loading defaults...")
            MonkTimers_GlobalSettings = {}
            MonkTimers.ResetAllProfiles()
        else
            while SettingsConverters[MonkTimers_GlobalSettings.Version] do
                SettingsConverters[MonkTimers_GlobalSettings.Version]()
            end
        end
    end


	for k,v in pairs(MonkTimers.DefaultProfile) do
        for _,profile in pairs(MonkTimers_Profiles) do
            if profile[k] == nil then
                profile[k] = copy(v)
            end
        end
	end
	for _,profile in pairs(MonkTimers_Profiles) do
		for i,j in pairs(MonkTimers.DefaultProfile.FramePositions) do
			if not profile.FramePositions[i] then
				profile.FramePositions[i] = copy(j)
			end
		end
	end
    
    
    for k,v in pairs(MonkTimers.DefaultGlobalSettings) do
        if MonkTimers_GlobalSettings[k] == nil then
            MonkTimers_GlobalSettings[k] = copy(v)
        end
    end
    
    local player = UnitName("player")
    if not MonkTimers_GlobalSettings.Profiles[player] then
        MonkTimers_GlobalSettings.Profiles[player] = {
            [1] = {none="default",pvp="default",arena="default",party="default",raid="default"},
            [2] = {none="default",pvp="default",arena="default",party="default",raid="default"},
            [3] = {none="default",pvp="default",arena="default",party="default",raid="default"},
        }
    end
	for i=1,3 do
		if not MonkTimers_GlobalSettings.Profiles[player][i].scenario then
			MonkTimers_GlobalSettings.Profiles[player][i].scenario = "default"
		end
	end
end

function MonkTimers.ResetProfilePositions(name)
    MonkTimers_Profiles[name].FramePositions = copy(MonkTimers.DefaultProfile.FramePositions)
    MonkTimers_Profiles[name].TimerPositions = copy(MonkTimers.DefaultProfile.TimerPositions)
    MonkTimers.ProcessSetting("FramePositions")
end

function MonkTimers.CopyProfile(p1,p2)
    MonkTimers_Profiles[p2] = copy(MonkTimers_Profiles[p1])
end

function MonkTimers.CopyFramePositions(p1, p2)
    MonkTimers_Profiles[p2].FramePositions = copy(MonkTimers_Profiles[p1].FramePositions)
    MonkTimers_Profiles[p2].TimerPositions = copy(MonkTimers_Profiles[p2].TimerPositions)
end


local GeneralList = {
    Lock, FlashRed, ShowTimerBars,
    HideBlizzTimers, Tooltips, TooltipsAtButtons,
    TimeFont, TimeColor, TimerBarTexture,
    TimerBarColor, ShowKeybinds, HideInVehicle,
    StopPulse, 
	Timers, TimerSize,
    TimerTimeHeight, 
    TimerOOCAlpha, TimersOnButtons, TimersClickthrough,	
	HideTimersOOC,
	StaggerBar, StaggerHeight, ChiBar,
}

function MonkTimers.CopyGeneralSettings(p1,p2)
    for k,v in pairs(GeneralList) do
        MonkTimers_Profiles[p2][v] = copy(MonkTimers_Profiles[p1][v])
    end
end

local TimerSettings = {
    Timers_Spells, Timers_Order, 
}

function MonkTimers.CopyCDSettings(p1,p2)
    for k,v in pairs(CDList) do
        MonkTimers_Profiles[p2][v] = copy(MonkTimers_Profiles[p1][v])
    end
end

