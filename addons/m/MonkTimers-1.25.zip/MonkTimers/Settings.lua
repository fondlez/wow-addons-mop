-- Copyright © 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.


if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

local Timers = XiTimers.timers

local SpellIDs = MonkTimers.SpellIDs
local SpellNames = MonkTimers.SpellNames
local AvailableSpells = MonkTimers.AvailableSpells

local LSM = LibStub:GetLibrary("LibSharedMedia-3.0", true)

local SettingsFunctions

function MonkTimers.ProcessSetting(setting)
    if SettingsFunctions[setting] then
        SettingsFunctions[setting](MonkTimers.ActiveProfile[setting], XiTimers.timers)
    end
end


function MonkTimers.ProcessAllSettings()
    for k,v in pairs(MonkTimers.ActiveProfile) do
        MonkTimers.ProcessSetting(k)
    end
end


SettingsFunctions = {
    ShowTimerBars = 
        function(value, Timers) 
            for _,timer in pairs(Timers) do
                timer.visibleTimerBars = value
                if timer.timer>0 and value and not timer.timerOnButton then
                    timer:ShowTimerBar()
                else
                    timer.timerBar.background:Hide()
                    timer.timerBar:SetValue(0)			
                end
            end
        end,

    FlashRed = 
        function(value, Timers)
        	for _,timer in pairs(MonkTimers.LongCooldowns) do
                timer.flashRed = value
            end
        end,
        
        
    Lock =
        function(value, Timers)
            for k,v in pairs(Timers) do
                v.locked = value
            end
        end,
     
    TimeFont =
        function(value, Timers)
            local font = LSM:Fetch("font", value)
            if font then
                for _,timer in pairs(Timers) do
                    timer:SetFont(font)
                end
            end
        end,
        
    TimerBarTexture =
        function(value, Timers) 
            local texture = LSM:Fetch("statusbar", value)
            if texture then
                for _,timer in pairs(Timers) do
                    timer:SetBarTexture(texture)
                end
            end
        end,


    TimersOnButtons = 
        function(value, Timers)
            for i=1,#Timers do
                Timers[i].timerOnButton = value
                if Timers[i].timer > 0 then Timers[i]:Start(Timers[i].timer, Timers[i].duration) end
            end
        end,
        
        
    Timers = 
        function(value)
            if value then
                MonkTimers.ActivateTimers() 
            else
                MonkTimers.DeactivateTimers()
            end
        end,
        
    TimerSize =
        function(value, Timers)
            for k,v in pairs(MonkTimers.Timers) do
                v:SetScale(value/36)
            end
			for k,v in pairs(MonkTimers.LongCooldowns) do
				v:SetScale(value/36)
			end
			--MonkTimers.stagger.background:SetWidth(value*3+10)
            --MonkTimers.stagger:SetWidth(value*3+10)
            --MonkTimers.staggerButton:SetWidth(value*3+10)
			MonkTimers.stagger:SetScale(value/36)
			--MonkTimersHarmonyBar:SetScale((value/36)*0.9)
			MonkTimers.ProcessSetting("ChiBarSize")
            MonkTimers.LayoutTimers()
			MonkTimers.LayoutLongCooldowns()
        end,
        
    TimersTimeHeight = 
         function(value, Timers)
    		for e=1, #Timers do
                Timers[e]:SetTimeHeight(value)
                local font, _ = Timers[e].button.time:GetFont()
                Timers[e].button.time:SetFont(font, value+5, "OUTLINE")
    		end 
            MonkTimers.LayoutTimers()
        end,
		
		
	Tooltips =  
        function(value, Timers)
            for i=1,#Timers do
                Timers[i].button:SetAttribute("tooltip", value)
            end
        end,
        
--[[       
    Tooltips =  
        function(value, Timers)
            for i=1,8 do
                Timers[i].button:SetAttribute("tooltip", value)
            end
            for i=1,TTActionBars.numbars do
                TTActionBars.bars[i]:SetTooltip(value)
            end
        end,
        
       
    ShowKeybinds =
        function(value, Timers)
            for _,t in pairs(Timers) do
                if value then
                    t.button.hotkey:Show()
                else
                    t.button.hotkey:Hide()
                end
            end
        end,  ]]
        
    FramePositions = 
        function(value, Timers)
            for name, pos in pairs(value) do
                if _G[name] and pos and pos[1] then
                    _G[name]:ClearAllPoints()
                    _G[name]:SetPoint(pos[1],pos[2],pos[3],pos[4],pos[5])
                end
            end
        end,
        
      
        
    TimerOOCAlpha = 
        function(value, Timers)
            for i = 1,#Timers do
                Timers[i].OOCAlpha = value
            end
            XiTimers.invokeOOCFader()
        end,
        
   
    TimeColor = 
        function(value, Timers)
            for i=1,#Timers do
                Timers[i].button.time:SetTextColor(value.r, value.g, value.b, 1)
                Timers[1].timeColor = value
                for j=1,#Timers[i].timerBar do
                    Timers[i].timerBar.time:SetTextColor(value.r,value.g,value.b,1)
                end
            end
        end,
        
   
    HideInVehicle = 
        function(value, Timers)
            if value then
                for k,v in pairs(Timers) do
                    RegisterStateDriver(v.button,"invehicle","[bonusbar:5]hide;show")
                end
                --RegisterStateDriver(MonkTimers.MB,"invehicle","[bonusbar:5]hide;show")
            else
                for k,v in pairs(Timers) do
                    UnregisterStateDriver(v.button,"invehicle")
                end
                --UnregisterStateDriver(MonkTimers.MB,"invehicle")
            end
        end,
   
    StopPulse =
        function(value, Timers)
            for i = 1,#MonkTimers.LongCooldowns do
                MonkTimers.LongCooldowns[i].StopPulse = value
            end
        end,
        
    HideTimersOOC =
        function(value, Timers)
            for i = 1,#Timers do
                Timers[i].HideOOC = value
				Timers[i].button:SetAttribute("HideOOC", value)
            end
			MonkTimers.stagger:SetAttribute("HideOOC", value)
            MonkTimers.ConfigTimers()
			MonkTimers.ProcessSetting("LongCooldowns")
        end,
        
        
    Clickthrough =
        function(value, Timers)
            for i = 1,#Timers do
                Timers[i].button:EnableMouse(not value)
            end
			MonkTimersHarmonyBar:EnableMouse(not value)
			MonkTimersHarmonyBarEnergyBar:EnableMouse(not value)
			MonkTimersFrame:EnableMouse(not value)
        end,
		
	LongCooldowns =
		function(value, Timers)
			MonkTimers.ActivateLongCooldowns(value)
		end,
		
	LongCooldownsArrange =
		function(value, Timers)
			MonkTimers.LayoutLongCooldowns()
		end,
		
	StaggerHeight = 
        function(value, Timers)
            MonkTimers.stagger:SetHeight(value)
            MonkTimers.stagger.background:SetHeight(value)
            MonkTimers.staggerButton:SetHeight(value)
            MonkTimers.stagger.icon:SetWidth(value)
            MonkTimers.stagger.icon:SetHeight(value)
            local font = MonkTimers.stagger.text:GetFont()
            local outline
            if Timers[1].timerOnButton then outline = "OUTLINE" end
    		MonkTimers.stagger.text:SetFont(font, value*0.7, outline)
        end,
		
	ChiBarSize =
		function(value, Timers)
			MonkTimers.harmonyBar:SetScale(((MonkTimers.ActiveProfile.TimerSize/36)*0.9)*value)
		end,
		
		
	HideBlizzardChiBar = 
		function(value, Timers)
			if value then
				--MonkHarmonyBar:UnregisterAllEvents()
				MonkHarmonyBar:Hide()
			else
				MonkHarmonyBar:Show()
			end
		end,
		
	
}



