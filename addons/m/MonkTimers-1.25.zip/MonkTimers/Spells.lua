-- Copyright © 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.

if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

MonkTimers.AvailableSpells = {}
MonkTimers.AvailableTalents = {}

MonkTimers.SpellIDs = {
    TigerPalm = 100787,
    TigerPower = 125359,
    PowerGuard = 118636,
    BlackoutKick = 100784,
    Shuffle = 115307,
    ElusiveBrew = 115308,
    ElusiveBrewStacks = 128939,
    ElusiveBrewBuff = 126453,
    KegSmash = 121253,
    ExpelHarm = 115072,
    Guard = 115295,
    Provoke = 115546,
    AvertHarm = 115213,
    DampenHarm = 122278,
    FortifyingBrew = 115203,
    GrappleWeapon = 117368,
	SpearHandStrike = 116705,
	ZenMeditation = 115176,
	ChiBrew = 115399,
	DiffuseMagic = 122783,
	Xuen = 123904,
	RushingJadeWind = 116847,
	LegSweep = 119381,
	ChargingOxWave = 119392,
	Clash = 122057,
	TouchOfKarma = 122470,
	LifeCocoon = 116849,
	Revival = 115310,
	EnergizingBrew = 115288,
	FistsOfFury = 113656,
	RisingSunKick = 107428,
	TigereyeBrew = 116740,
	TigereyeBrewStacks = 125195,
	FlyingSerpentKick = 101545,
	ThunderFocusTea = 116680,
	ChiWave = 115098,
	RenewingMist = 115151,
	Detox = 115450,
	VitalMists = 118674,
	SerpentsZeal = 127722,	
	PurifyingBrew = 119582,
	StaggerHeavy = 124273,
	StaggerModerate = 124274,
	StaggerLight = 124275,
	OxStance = 115069,
	ManaTea = 115294,
	ManaTeaGlyphed = 123761,
	ZenFlight = 125883,
	ZenSphere = 124081,
	ChiBurst = 123986,
	Purifier = 138237,
	Staggering = 138233,
	SpinningCraneKick = 101546,
    
}

MonkTimers.SpellTextures = {}
MonkTimers.SpellNames = {}

for k,v in pairs(MonkTimers.SpellIDs) do
    local n,_,t = GetSpellInfo(v)
    MonkTimers.SpellTextures[v] = t
    MonkTimers.SpellNames[v] = n
end


local function GetSpellTab(tab)
    local _, _, offset, numSpells = GetSpellTabInfo(tab)
    local AvailableSpells = MonkTimers.AvailableSpells
    for s = offset + 1, offset + numSpells do 
        local spelltype, spell = GetSpellBookItemInfo(s, BOOKTYPE_SPELL)
        if spelltype == "SPELL" then 
            AvailableSpells[spell] = true
        end
    end
end    


function MonkTimers.GetSpells()
    local AvailableSpells = MonkTimers.AvailableSpells
    wipe(AvailableSpells)
    for _,s in pairs(MonkTimers.SpellIDs) do
		AvailableSpells[s] = IsPlayerSpell(s)
		if AvailableSpells[s] then
			AvailableSpells[s] = GetSpellInfo(MonkTimers.SpellNames[s]) == MonkTimers.SpellNames[s]
		end
    end
    return true
end


function MonkTimers.LearnedSpell(spell,tab)
    if spell then
        MonkTimers.AvailableSpells[spell] = true
    else
        MonkTimers.GetSpells()
    end
	MonkTimers.ProcessSetting("Timers")
	MonkTimers.ProcessSetting("LongCooldowns")
end


function MonkTimers.ChangedTalents()
	MonkTimers.GetSpells()
    MonkTimers.SelectActiveProfile()
    MonkTimers.ExecuteProfile()
end
