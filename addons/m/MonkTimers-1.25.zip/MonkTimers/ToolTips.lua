-- Copyright © 2008 - 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.
-- This code is not to be modified or distributed without written permission by the author.
-- Current distribution permissions only include curse.com, wowinterface.com and their respective addon updaters

if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

local L = LibStub("AceLocale-3.0"):GetLocale("MonkTimers", true)

local SpellNames = MonkTimers.SpellNames

local r = 0
local g = 0.9
local b = 1


local function SetTooltipSpellID(id)
    if GetCVar("UberTooltips") == "1" then
         GameTooltip:SetSpellByID(id)
    else
        GameTooltip:ClearLines()
        GameTooltip:AddLine(SpellNames[id],1,1,1)
    end
end

local function PositionTooltip(self)
    if not MonkTimers.ActiveProfile.TooltipsAtButtons then 
        GameTooltip_SetDefaultAnchor(GameTooltip, self)
    else
        local left = self:GetLeft()
        if left<UIParent:GetWidth()/2 then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        else			
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        end
    end
end

function MonkTimers.HideTooltip(self)
    GameTooltip:Hide()
end

function MonkTimers.Tooltip(self)
	if self:GetAttribute("tooltip") then
        local spell = self:GetAttribute("*spell1")
        if spell and spell > 0 then
            PositionTooltip(self)
            SetTooltipSpellID(spell)
        end
    end
end

