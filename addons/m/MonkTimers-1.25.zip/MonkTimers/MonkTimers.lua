-- Copyright © 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.
-- This code is not to be modified or distributed without written permission by the author.
-- Current distribution permissions only include curse.com, wowinterface.com and their respective addon updaters

if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...
local SpellIDs = MonkTimers.SpellIDs

local PlayerName = UnitName("player")

local zoning = false
MonkTimers.updateAfterCombat = false
local introQueue = {}

local function IntroAnimation(spell)
	MonkTimers.TimerIntroAnimation(spell)
	MonkTimers.LongCooldownIntroAnimation(spell)
end

local function PlayIntroQueue()
	while #introQueue > 0 do
		IntroAnimation(table.remove(introQueue, 1))
	end
end

local farts = 0
local fartelapsed = 0.6

FartFrame = CreateFrame("Frame")
FartFrame:Hide()
FartFrame:SetScript("OnUpdate", function(self, elapsed)
		fartelapsed = fartelapsed + elapsed
		if fartelapsed > 0.5 then
			fartelapsed = 0
			farts = farts + 1
			if farts >= 3 then
				farts = 0
				fartelapsed = 0.5
				self:Hide()
			end
			DoEmote("fart", "none")
		end
	end)

local function MonkTimers_OnEvent(self, event, ...)
    if zoning and event ~= "PLAYER_ENTERING_WORLD" then return
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
		if MonkTimers.ActiveProfile.CloudFart and select(5,...) == SpellIDs.ZenFlight then
			FartFrame:Show()
		end
	elseif event == "PLAYER_ENTERING_WORLD" then
        if zoning then
            MonkTimersFrame:UnregisterEvent("PLAYER_ENTERING_WORLD")
            zoning = false
            return
        end
		MonkTimers.SetupGlobals()
	elseif event == "PLAYER_REGEN_ENABLED" then
		if MonkTimers.updateAfterCombat then
			MonkTimers.ChangedTalents()
			PlayIntroQueue()
			MonkTimers.updateAfterCombat = false
		end
    elseif event == "LEARNED_SPELL_IN_TAB" then
		if InCombatLockdown() then
			MonkTimers.updateAfterCombat = true
		else
			MonkTimers.LearnedSpell(...)
		end
    elseif event == "PLAYER_ALIVE" then
        --MonkTimers.ProcessSetting("EnhanceCDs")
	elseif event == "PLAYER_TALENT_UPDATE" or event == "PLAYER_SEPCIALIZATION_CHANGED" or event == "SPELLS_CHANGED" then
		if InCombatLockdown() then
			MonkTimers.updateAfterCombat = true
		else
			MonkTimers.ChangedTalents()        
		end
    elseif event == "PLAYER_LEAVING_WORLD" then
        zoning = true
        MonkTimersFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
	elseif event == "SPELL_PUSHED_TO_ACTIONBAR" then
		if not InCombatLockdown() then
			IntroAnimation(...)
		else
			local spell = select(1,...)
			table.insert(introQueue, spell)
			updateAfterCombat = true
		end
	end   
end

MonkTimersFrame:SetScript("OnEvent", MonkTimers_OnEvent)
--MonkTimersFrame:RegisterEvent("PLAYER_ENTERING_WORLD")


function MonkTimers.SetupGlobals()
	if MonkTimers_IsSetUp then
		return
	end
	if select(2,UnitClass("player")) == "MONK" then
		MonkTimers.GetSpells()
		MonkTimers.UpdateProfiles()
        MonkTimers.SelectActiveProfile()
        
        MonkTimers.CreateTimers()
		MonkTimers.CreateLongCooldowns()
        
        MonkTimers.ProcessAllSettings()
		MonkTimers.ChiBarEvent(MonkTimersHarmonyBar, "UNIT_MAXPOWER")

		MonkTimersFrame:Show()
		MonkTimers.InitMasque()
		
		--set the slashcommand
		SLASH_MONKTIMERS1 = "/monktimers";
		SLASH_MONKTIMERS2 = "/mkt";
		SlashCmdList["MONKTIMERS"] = MonkTimers_Slash

	
        MonkTimersFrame:RegisterEvent("SPELLS_CHANGED")
        MonkTimersFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        MonkTimersFrame:RegisterEvent("PLAYER_ALIVE")
        MonkTimersFrame:RegisterEvent("LEARNED_SPELL_IN_TAB")
        MonkTimersFrame:RegisterEvent("CHARACTER_POINTS_CHANGED")
		MonkTimersFrame:RegisterEvent("PLAYER_TALENT_UPDATE")
        MonkTimersFrame:RegisterEvent("PLAYER_LEAVING_WORLD")
        MonkTimersFrame:RegisterEvent("PLAYER_SEPCIALIZATION_CHANGED")
		MonkTimersFrame:RegisterEvent("SPELL_PUSHED_TO_ACTIONBAR")
		MonkTimersFrame:RegisterEvent("SPELLS_CHANGED")
		MonkTimersFrame:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")
        
        MonkTimers_OnEvent("PLAYER_ALIVE") -- simulate PLAYER_ALIVE event in case the ui is reloaded
        XiTimers.invokeOOCFader()
        MonkTimersFrame:SetScript("OnUpdate", XiTimers.UpdateTimers)
        XiTimers.SaveFramePositions = MonkTimers.SaveFramePositions
	else
		MonkTimersFrame:Hide()
	end
	MonkTimers_IsSetUp = true
    MonkTimersFrame:UnregisterEvent("PLAYER_ENTERING_WORLD")
end

function MonkTimers_Slash(msg)
	if InCombatLockdown() then
		DEFAULT_CHAT_FRAME:AddMessage("Can't open MT options in combat.")
		return
	end
    if MonkTimers.LastGUIPanel then
        InterfaceOptionsFrame_OpenToCategory(MonkTimers.LastGUIPanel)
    else
        InterfaceOptionsFrame_OpenToCategory("MonkTimers")
    end
end


function MonkTimers.SaveFramePositions()
    for k,v in pairs(MonkTimers.ActiveProfile.FramePositions) do
        local pos = {_G[k]:GetPoint()}
        if not pos[1] then pos = nil end
        if pos[2] then pos[2] = pos[2]:GetName() end
        MonkTimers.ActiveProfile.FramePositions[k] = pos
    end 
end



