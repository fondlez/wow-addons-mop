-- Copyright © 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.
-- This code is not to be modified or distributed without written permission by the author.

if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

local nrfonts = 0

local L = LibStub("AceLocale-3.0"):GetLocale("MonkTimers_GUI", true)

local LSM = LibStub:GetLibrary("LibSharedMedia-3.0", true)


MonkTimers.options = {
    type = "group",
    args = {
        general = {
            type = "group",
            name = "general",
            args = {
                version= {
                    order = 0,
                    type ="description",
                    name = L["Version"]..": "..tostring(GetAddOnMetadata("MonkTimers", "Version"))
                },
                lock = {
                    order = 1,
                    type = "toggle",
                    name = L["Lock"],
                    desc = L["Locks the position of MonkTimers"],
                    set = function(info, val) MonkTimers.ActiveProfile.Lock = val MonkTimers.ProcessSetting("Lock") end,
                    get = function(info) return MonkTimers.ActiveProfile.Lock end,
                },            
				chibar = {
					order = 3,
					type = "toggle",
					name = L["Chi Bar"],
					desc = L["Chi Bar"],
					set = function(info, val) MonkTimers.ActiveProfile.ChiBar = val MonkTimers.ConfigTimers() MonkTimers.LayoutTimers() end,
					get = function(info) return MonkTimers.ActiveProfile.ChiBar end,
				},
				blizzchibar = {
					order = 4,
					type = "toggle",
					name = L["Hide Blizz Chi Bar"],
					set = function(info, val) MonkTimers.ActiveProfile.HideBlizzardChiBar = val MonkTimers.ProcessSetting("HideBlizzardChiBar") end,
					get = function(info, val) return MonkTimers.ActiveProfile.HideBlizzardChiBar end,
				},
                showTimerBars = {
                    order = 5,
                    type = "toggle",
                    name = L["Show Timer Bars"],
                    desc = L["Displays timer bars underneath times"],
                    set = function(info, val) MonkTimers.ActiveProfile.ShowTimerBars = val MonkTimers.ProcessSetting("ShowTimerBars") end,
                    get = function(info) return MonkTimers.ActiveProfile.ShowTimerBars end,
                },
                timersonbuttons = {
                    order = 7,
                    type = "toggle",
                    name = L["Timers On Buttons"],
                    desc = L["Timers On Buttons Desc"],
                    set = function(info, val) 
                        MonkTimers.ActiveProfile.TimersOnButtons = val 
                        MonkTimers.ProcessSetting("TimersOnButtons")
                        for i=1,#XiTimers.timers do
                            XiTimers.timers[i]:SetTimerBarPos(XiTimers.timers[i].timerBarPos)
                        end
                    end,
                    get = function(info) return MonkTimers.ActiveProfile.TimersOnButtons end,
                },
				clickthrough = {
					order = 9,
					type = "toggle", 
					name = L["Clickthrough"],
					desc = L["Clickthrough Desc"],
					set = function(info, val) MonkTimers.ActiveProfile.Clickthrough = val  MonkTimers.ProcessSetting("Clickthrough") end,
					get = function(info) return MonkTimers.ActiveProfile.Clickthrough end,
				},
				--[[TimersOnButtons = {
					order = 11,
					type = "toggle",
					name = L["Timers On Buttons"],
					set = function(info, val) MonkTimers.ActiveProfile.TimersOnButtons = val
								MonkTimers.ProcessSetting("TimersOnButtons") end,
					get = function(info) return MonkTimers.ActiveProfile.TimersOnButtons end,
				},  ]]
				HideTimersOOC = {
					order = 11,
					type = "toggle",
					name = L["Hide out of combat"],
					desc = L["Hide OOC Desc"],
					set = function(info, val) MonkTimers.ActiveProfile.HideTimersOOC = val  MonkTimers.ProcessSetting("HideTimersOOC") end,
					get = function(info) return MonkTimers.ActiveProfile.HideTimersOOC end,
				}, 
				OOCAlpha = {
					order = 13,
					type="range",
					min = 0,
					max = 1,
					step = 0.1,
					name = L["OOC Alpha"], 
					desc = L["OOC Alpha Desc"],
					set = function(info, val)
								MonkTimers.ActiveProfile.TimerOOCAlpha = val  MonkTimers.ProcessSetting("TimerOOCAlpha")	
						  end,
					get = function(info) return MonkTimers.ActiveProfile.TimerOOCAlpha end,
				},
				tooltips = {
                    order = 15,
                    type = "toggle",
                    name = L["Show Tooltips"],
                    desc = L["Shows tooltips on timer and totem buttons"],
                    set = function(info, val) MonkTimers.ActiveProfile.Tooltips = val MonkTimers.ProcessSetting("Tooltips") end,
                    get = function(info) return MonkTimers.ActiveProfile.Tooltips end,
                },  
                tooltipsatbuttons = {
                    order = 16,
                    type = "toggle",
                    name = L["Tooltips At Buttons"],
                    desc = L["Tooltips At Buttons Desc"],
                    set = function(info, val) MonkTimers.ActiveProfile.TooltipsAtButtons = val end,
                    get = function(info) return MonkTimers.ActiveProfile.TooltipsAtButtons end,
                }, 
				flashred = {
                    order = 17,
                    type = "toggle",
                    name = L["Red Flash Color"],
                    desc = L["RedFlash Desc"],
                    set = function(info, val) MonkTimers.ActiveProfile.FlashRed = val MonkTimers.ProcessSetting("FlashRed") end,
                    get = function(info) return MonkTimers.ActiveProfile.FlashRed end,
                }, 
                stoppulse = {
                    order = 18,
                    type = "toggle",
                    name = L["Stop Pulse"],
                    desc = L["Stop Pulse Desc"],
                    set = function(info, val) MonkTimers.ActiveProfile.StopPulse = val MonkTimers.ProcessSetting("StopPulse") end,
                    get = function(info) return MonkTimers.ActiveProfile.StopPulse end,
                },
                --[[HideInVehicle = {
                    order = 3,
                    type = "toggle",
                    name = L["Hide In Vehicles"],
                    desc = L["Hide In Vehicles Desc"],
                    set = function(info, val) MonkTimers.ActiveProfile.HideInVehicle = val MonkTimers.ProcessSetting("HideInVehicle") end,
                    get = function(info) return MonkTimers.ActiveProfile.HideInVehicle end,
                },                
                Keybinds = {
                     order = 4,
                   type = "toggle",
                    name = L["Show Key Bindings"],
                    desc = L["Shows key bindings on totem timers"],
                    set = function(info, val) MonkTimers.ActiveProfile.ShowKeybinds = val MonkTimers.ProcessSetting("ShowKeybinds") end,
                    get = function(info) return MonkTimers.ActiveProfile.ShowKeybinds end,
                },    ]]
				cloudfart = {
					order = 19,
					type = "toggle",
					name = L["Cloud Fart"],
					desc = L["Cloud Fart Desc"],
					set = function(info, val) MonkTimers.ActiveProfile.CloudFart = val end,
					get = function(info) return MonkTimers.ActiveProfile.CloudFart end,
				},				
				h2 = {
                    order = 20,
                    type = "header",
                    name = "",
                },
				staggerbar = {
					order = 22,
					type = "toggle",
					name = L["Stagger Bar"],
					set = function(info, val) MonkTimers.ActiveProfile.StaggerBar = val MonkTimers.ConfigTimers() MonkTimers.LayoutTimers() end,
					get = function(info) return MonkTimers.ActiveProfile.StaggerBar end,
				},	
				staggerdot = {
					order = 23,
					type = "toggle",
					name = L["Stagger Dot Tick"],
					set = function(info, val) MonkTimers.ActiveProfile.StaggerDot = val end,
					get = function(info) return MonkTimers.ActiveProfile.StaggerDot end,
				},
				staggerdottotal = {
					order = 24,
					type = "toggle",
					name = L["Stagger Dot Total"],
					set = function(info, val) MonkTimers.ActiveProfile.StaggerDotTotal = val end,
					get = function(info) return MonkTimers.ActiveProfile.StaggerDotTotal end,
				},
				staggerdotpercent = {
					order = 25,
					type = "toggle",
					name = L["Stagger Dot Percent"],
					set = function(info, val) MonkTimers.ActiveProfile.StaggerDotPercent = val end,
					get = function(info) return MonkTimers.ActiveProfile.StaggerDotPercent end,
				},
                h3 = {
                    order = 50,
                    type = "header",
                    name = "",
                },
				Size = {
					order = 51,
					type = "range",
					name = L["Button Size"] ,
					min = 16,
					max = 96,
					step = 1,
					bigStep = 2,
					set = function(info, val)
								MonkTimers.ActiveProfile.TimerSize = val  MonkTimers.ProcessSetting("TimerSize")	
						  end,
					get = function(info) return MonkTimers.ActiveProfile.TimerSize end,
				},
				StaggerHeight = {
					order = 52,
					type = "range",
					name = L["Stagger Bar Height"] ,
					min = 10,
					max = 50,
					step = 1,
					bigStep = 2,
					set = function(info, val)
								MonkTimers.ActiveProfile.StaggerHeight = val  MonkTimers.ProcessSetting("StaggerHeight")	
						  end,
					get = function(info) return MonkTimers.ActiveProfile.StaggerHeight end,
				},
				chisize = {
					order = 51,
					type = "range",
					name = L["Chi Bar Size"] ,
					min = 0.5,
					max = 4,
					step = 0.1,
					set = function(info, val)
								MonkTimers.ActiveProfile.ChiBarSize = val  MonkTimers.ProcessSetting("ChiBarSize")	
						  end,
					get = function(info) return MonkTimers.ActiveProfile.ChiBarSize end,
				},
				fontSize = {
					order = 54,
					type = "range",
					name = L["Font Size"],
					min = 6,
					max = 40,
					step = 1,
					set = function(info, val)
								MonkTimers.ActiveProfile.TimersTimeHeight = val  MonkTimers.ProcessSetting("TimersTimeHeight")	
						  end,
					get = function(info) return MonkTimers.ActiveProfile.TimersTimeHeight end,
				},	
                TimerBarTexture = {
                    order = 54,
                    type = "select",
                    name = L["Timer Bar Texture"],
                    values = AceGUIWidgetLSMlists.statusbar,
                    set = function(info, val) MonkTimers.ActiveProfile.TimerBarTexture = val MonkTimers.ProcessSetting("TimerBarTexture") end,
                    get = function(info) return MonkTimers.ActiveProfile.TimerBarTexture end,
                    dialogControl = "LSM30_Statusbar",
                },                
                TimeFont = {
                    order = 55,
                    type = "select",
                    name = L["Time Font"] ,
                    values = AceGUIWidgetLSMlists.font,
                    set = function(info, val) MonkTimers.ActiveProfile.TimeFont = val MonkTimers.ProcessSetting("TimeFont") end,
                    get = function(info) return MonkTimers.ActiveProfile.TimeFont end,
                    dialogControl = "LSM30_Font",
                }, 
                TimeColor = {
                    order = 56,
                    type = "color",
                    name = L["Time Color"],
                    set = function(info, r,g,b)
                        MonkTimers.ActiveProfile.TimeColor.r = r
                        MonkTimers.ActiveProfile.TimeColor.g = g
                        MonkTimers.ActiveProfile.TimeColor.b = b
                        MonkTimers.ProcessSetting("TimeColor")
                    end,
                    get = function(info) return MonkTimers.ActiveProfile.TimeColor.r,
                                                MonkTimers.ActiveProfile.TimeColor.g,
                                                MonkTimers.ActiveProfile.TimeColor.b,
                                                1
                          end,
                },
                TimerBarColor = {
                    order = 57,
                    type = "color",
                    name = L["Timer Bar Color"],
                    hasAlpha = true,
                    set = function(info, r,g,b,a)
                        MonkTimers.ActiveProfile.TimerBarColor.r = r
                        MonkTimers.ActiveProfile.TimerBarColor.g = g
                        MonkTimers.ActiveProfile.TimerBarColor.b = b
                        MonkTimers.ActiveProfile.TimerBarColor.a = a
                        MonkTimers.ProcessSetting("ColorTimerBars")
                    end,
                    get = function(info) return MonkTimers.ActiveProfile.TimerBarColor.r,
                                                MonkTimers.ActiveProfile.TimerBarColor.g,
                                                MonkTimers.ActiveProfile.TimerBarColor.b,
                                                MonkTimers.ActiveProfile.TimerBarColor.a
                          end,
                },
            },
        },
    },
}

ACR =	LibStub("AceConfigRegistry-3.0")
ACR:RegisterOptionsTable("MonkTimers", MonkTimers.options)
local ACD = LibStub("AceConfigDialog-3.0")
local frame = ACD:AddToBlizOptions("MonkTimers", "MonkTimers", nil, "general")
frame:SetScript("OnEvent", function(self) InterfaceOptionsFrame:Hide() end)
frame:HookScript("OnShow", function(self) if InCombatLockdown() then InterfaceOptionsFrame:Hide() end MonkTimers.LastGUIPanel = self end)
frame:RegisterEvent("PLAYER_REGEN_DISABLED")
MonkTimers.LastGUIPanel = frame



