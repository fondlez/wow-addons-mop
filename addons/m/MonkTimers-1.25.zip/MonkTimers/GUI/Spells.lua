if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

local L = LibStub("AceLocale-3.0"):GetLocale("MonkTimers_GUI", true)

local SpellIDs = MonkTimers.SpellIDs
local SpellNames = MonkTimers.SpellNames


MonkTimers.options.args.spells = {
    type = "group",
    name = "enhancecds",
    args = {
        ["1"] = {
            order = 30,
            type = "group",
            name = select(2,GetSpecializationInfo(1)) or "Brewmaster",
            args = {
                tigerpalm = {
                    order = 1,
                    type = "toggle",
                    name = SpellNames[SpellIDs.TigerPalm],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][1] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][1] end,
                },
                blackoutkick = {
                    order = 2,
                    type = "toggle",
                    name = SpellNames[SpellIDs.BlackoutKick].."/"..SpellNames[SpellIDs.Shuffle],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][2] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][2] end,
                },
                elusivebrew = {
                    order = 3,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ElusiveBrew],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][3] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][3] end,
                },
                kegsmash = {
                    order = 4,
                    type = "toggle",
                    name = SpellNames[SpellIDs.KegSmash],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][4] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][4] end,
                },
                expelharm = {
                    order = 5,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ExpelHarm],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][5] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][5] end,
                },
                guard = {
                    order = 6,
                    type = "toggle",
                    name = SpellNames[SpellIDs.Guard],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][6] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][6] end,
                },
                provoke = {
                    order = 7,
                    type = "toggle",
                    name = SpellNames[SpellIDs.Provoke],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][7] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][7] end,
                },
                grappleweapon = {
                    order = 8,
                    type = "toggle",
                    name = SpellNames[SpellIDs.GrappleWeapon],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][8] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][8] end,
                },
                spearhandstrike = {
                    order = 9,
                    type = "toggle",
                    name = SpellNames[SpellIDs.SpearHandStrike],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][9] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][9] end,
                },
                clash = {
                    order = 10,
                    type = "toggle",
                    name = SpellNames[SpellIDs.Clash],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][10] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][10] end,
                },
                talent30 = {
                    order = 11,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ChiWave].."/"..SpellNames[SpellIDs.ZenSphere].."/"..SpellNames[SpellIDs.ChiBurst],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][11] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][11] end,
                },
				rushingjadewind = {
                    order = 12,
                    type = "toggle",
                    name = SpellNames[SpellIDs.RushingJadeWind],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[1][12] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[1][12] end,
                },
			},
        },
        ["2"] = {
            order = 40,
            type = "group",
            name = select(2,GetSpecializationInfo(2)) or "Mistweaver",
            args = {
                tigerpalm = {
                    order = 1,
                    type = "toggle",
                    name = SpellNames[SpellIDs.TigerPalm],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][1] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][1] end,
                },
                blackoutkick = {
                    order = 2,
                    type = "toggle",
                    name = SpellNames[SpellIDs.BlackoutKick],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][2] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][2] end,
                },
                renewingmist = {
                    order = 3,
                    type = "toggle",
                    name = SpellNames[SpellIDs.RenewingMist],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][3] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][3] end,
                },
                chiwave = {
                    order = 4,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ChiWave].."/"..SpellNames[SpellIDs.ZenSphere].."/"..SpellNames[SpellIDs.ChiBurst],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][4] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][4] end,
                },
                manatea = {
                    order = 5,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ManaTea],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][5] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][5] end,
                },                detox = {
                    order = 6,
                    type = "toggle",
                    name = SpellNames[SpellIDs.Detox],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][6] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][6] end,
                },
                thunderfocustea = {
                    order = 7,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ThunderFocusTea],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][7] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][7] end,
                },
                expelharm = {
                    order = 8,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ExpelHarm],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][8] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][8] end,
                },
				grappleweapon = {
                    order = 9,
                    type = "toggle",
                    name = SpellNames[SpellIDs.GrappleWeapon],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][9] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][9] end,
                },
				spearhandstrike = {
                    order = 10,
                    type = "toggle",
                    name = SpellNames[SpellIDs.SpearHandStrike],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][10] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][10] end,
                },
				rushingjadewind = {
                    order = 11,
                    type = "toggle",
                    name = SpellNames[SpellIDs.RushingJadeWind],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[2][11] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[2][11] end,
                },
            },
        },
        ["3"] = {
            order = 50,
            type = "group",
            name = select(2,GetSpecializationInfo(3)) or "Windwalker",
            args = {
                tigerpalm = {
                    order = 1,
                    type = "toggle",
                    name = SpellNames[SpellIDs.TigerPalm],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][1] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][1] end,
                },
				blackoutkick = {
                    order = 2,
                    type = "toggle",
                    name = SpellNames[SpellIDs.BlackoutKick],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][2] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][2] end,
                },
                risingsunkick = {
                    order = 3,
                    type = "toggle",
                    name = SpellNames[SpellIDs.RisingSunKick],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][3] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][3] end,
                },
                tigereyebrew = {
                    order = 4,
                    type = "toggle",
                    name = SpellNames[SpellIDs.TigereyeBrew],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][4] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][4] end,
                },
                fistsoffury = {
                    order = 5,
                    type = "toggle",
                    name = SpellNames[SpellIDs.FistsOfFury],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][5] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][5] end,
                },
                energizingbrew = {
                    order = 6,
                    type = "toggle",
                    name = SpellNames[SpellIDs.EnergizingBrew],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][6] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][6] end,
                },
                flyingserpentkick = {
                    order = 7,
                    type = "toggle",
                    name = SpellNames[SpellIDs.FlyingSerpentKick],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][7] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][7] end,
                },
				spearhandstrike = {
                    order = 8,
                    type = "toggle",
                    name = SpellNames[SpellIDs.SpearHandStrike],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][8] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][8] end,
                },
                expelharm = {
                    order = 9,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ExpelHarm],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][9] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][9] end,
                },
				grappleweapon = {
                    order = 10,
                    type = "toggle",
                    name = SpellNames[SpellIDs.GrappleWeapon],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][10] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][10] end,
                },
				talent30 = {
                    order = 11,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ChiWave].."/"..SpellNames[SpellIDs.ZenSphere].."/"..SpellNames[SpellIDs.ChiBurst],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][11] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][11] end,
                },
				rushingjadewind = {
                    order = 12,
                    type = "toggle",
                    name = SpellNames[SpellIDs.RushingJadeWind],
                    set = function(info, val) MonkTimers.ActiveProfile.Timer_Spells[3][12] = val  MonkTimers.ProcessSetting("Timers") end,
                    get = function(info) return MonkTimers.ActiveProfile.Timer_Spells[3][12] end,
                },
            },
        }, 
        ["4"] = {
            order = 60,
            type = "group",
            name = L["Long Cooldowns"],
            args = {
                fortifyingbrew = {
                    order = 1,
                    type = "toggle",
                    name = SpellNames[SpellIDs.FortifyingBrew],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.FortifyingBrew] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.FortifyingBrew] end,
                },
                avertharm = {
                    order = 2,
                    type = "toggle",
                    name = SpellNames[SpellIDs.AvertHarm],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.AvertHarm] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.AvertHarm] end,
                },
                lifecocoon = {
                    order = 3,
                    type = "toggle",
                    name = SpellNames[SpellIDs.LifeCocoon],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.LifeCocoon] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.LifeCocoon] end,
                },
                touchofkarma = {
                    order = 4,
                    type = "toggle",
                    name = SpellNames[SpellIDs.TouchOfKarma],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.TouchOfKarma] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.TouchOfKarma] end,
                },
                dampenharm = {
                    order = 5,
                    type = "toggle",
                    name = SpellNames[SpellIDs.DampenHarm],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.DampenHarm] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.DampenHarm] end,
                },
                diffusemagic = {
                    order = 6,
                    type = "toggle",
                    name = SpellNames[SpellIDs.DiffuseMagic],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.DiffuseMagic] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.DiffuseMagic] end,
                },
                xuen = {
                    order = 7,
                    type = "toggle",
                    name = SpellNames[SpellIDs.Xuen],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.Xuen] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.Xuen] end,
                },
                --[[rushingjadewind = {
                    order = 8,
                    type = "toggle",
                    name = SpellNames[SpellIDs.RushingJadeWind],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.RushingJadeWind] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.RushingJadeWind] end,
                },]]
                zenmeditation = {
                    order = 9,
                    type = "toggle",
                    name = SpellNames[SpellIDs.ZenMeditation],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.ZenMeditation] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.ZenMeditation] end,
                },
                revival = {
                    order = 10,
                    type = "toggle",
                    name = SpellNames[SpellIDs.Revival],
                    set = function(info, val) MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.Revival] = val  MonkTimers.ProcessSetting("LongCooldowns") end,
                    get = function(info) return MonkTimers.ActiveProfile.LongCooldownSpells[SpellIDs.Revival] end,
                },
			},
		},
	},
}
    
local ACD = LibStub("AceConfigDialog-3.0")
local frame = ACD:AddToBlizOptions("MonkTimers", L["Spells"], "MonkTimers", "spells")    
frame:SetScript("OnEvent", function(self) InterfaceOptionsFrame:Hide() end)
frame:HookScript("OnShow", function(self) if InCombatLockdown() then InterfaceOptionsFrame:Hide() end MonkTimers.LastGUIPanel = self end)
frame:RegisterEvent("PLAYER_REGEN_DISABLED")