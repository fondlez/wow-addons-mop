local L = LibStub("AceLocale-3.0"):NewLocale("MonkTimers_GUI", "esMX")
if not L then return end


L["Chi Bar"] = "Chi Bar" -- Requires localization
L["Chi Bar Size"] = "Chi Bar Size" -- Requires localization
L["Displays timer bars underneath times"] = "Displays timer bars underneath times" -- Requires localization
L["General"] = "General" -- Requires localization
L["Hide Blizz Chi Bar"] = "Hide Blizz Chi Bar" -- Requires localization
L["Lock"] = "Lock" -- Requires localization
L["Locks the position of MonkTimers"] = "Locks the position of MonkTimers" -- Requires localization
L["Red Flash Color"] = "Red Flash Color" -- Requires localization
L["RedFlash Desc"] = "If enabled expiring timers flash red, else they will fade in and out." -- Requires localization
L["Show Timer Bars"] = "Show Timer Bars" -- Requires localization
L["Show Tooltips"] = "Show Tooltips" -- Requires localization
L["Stagger Bar"] = "Stagger Bar" -- Requires localization
L["Stagger Bar Height"] = "Stagger Bar Height" -- Requires localization
L["Stagger Dot Percent"] = "Stagger Dot Percent" -- Requires localization
L["Stagger Dot Tick"] = "Stagger Dot Tick" -- Requires localization
L["Stagger Dot Total"] = "Stagger Dot Total" -- Requires localization
L["Stop Pulse"] = "Stop Pulse" -- Requires localization
L["Stop Pulse Desc"] = "If a timer stops its icon gives a big visible pulse" -- Requires localization
L["Time Color"] = "Time Color" -- Requires localization
L["Time Font"] = "Time Font" -- Requires localization
L["Timer Bar Color"] = "Timer Bar Color" -- Requires localization
L["Timer Bar Texture"] = "Timer Bar Texture" -- Requires localization
L["Timers On Buttons"] = "Timers On Buttons" -- Requires localization
L["Timers On Buttons Desc"] = "Timers are displayed on the buttons instead of next to them." -- Requires localization
L["Tooltips At Buttons"] = "Tooltips At Buttons" -- Requires localization
L["Tooltips At Buttons Desc"] = "Shows Tooltips to the right of TT's buttons." -- Requires localization

L["Button Size"] = "Button Size" -- Requires localization
L["Clickthrough"] = "Clickthrough" -- Requires localization
L["Clickthrough Desc"] = "Disables any clicking functionality of the timer buttons" -- Requires localization
L["Enable"] = "Enable" -- Requires localization
L["Font Size"] = "Font Size" -- Requires localization
L["Hide OOC Desc"] = "Changing this setting will have effect after the next combat" -- Requires localization
L["Hide out of combat"] = "Hide out of combat" -- Requires localization
L["OOC Alpha"] = "OOC Alpha" -- Requires localization
L["OOC Alpha Desc"] = "Controls the opacity of the buttons out of combat, 0 = transparent, 1 = opaque" -- Requires localization

L["Arena"] = "Arena" -- Requires localization
L["Battleground"] = "Battleground" -- Requires localization
L["Copy All"] = "Copy All" -- Requires localization
L["Copy Frame Positions"] = "Copy Frame Positions" -- Requires localization
L["Copy From"] = "Copy From" -- Requires localization
L["Copy General Settings"] = "Copy General Settings" -- Requires localization
L["Copy Settings"] = "Copy Settings" -- Requires localization
L["Copy Timers Settings"] = "Copy Timers Settings" -- Requires localization
L["Copy To"] = "Copy To" -- Requires localization
L["Create Profile"] = "Create Profile" -- Requires localization
L["default"] = "Default" -- Requires localization
L["Delete Profile"] = "Delete Profile" -- Requires localization
L["Manage Profiles"] = "Manage Profiles" -- Requires localization
L["New Name"] = "New Name" -- Requires localization
L["Party"] = "Party" -- Requires localization
L["Profile"] = "Profile" -- Requires localization
L["Profile already exists."] = "Profile already exists." -- Requires localization
L["Profiles"] = "Profiles" -- Requires localization
L["Raid"] = "Raid" -- Requires localization
L["Really delete profile?"] = "Really delete profile?" -- Requires localization
L["Really reset frame positions?"] = "Really reset frame positions?" -- Requires localization
L["Reset Frame Positions"] = "Reset Frame Positions" -- Requires localization
L["Reset Profile"] = "Reset Profile" -- Requires localization
L["Select Profiles"] = "Select Profiles" -- Requires localization
L["Solo"] = "Solo" -- Requires localization
L["You cannot delete the default profile."] = "You cannot delete the default profile." -- Requires localization
L["You need to enter a profile name first."] = "You need to enter a profile name first." -- Requires localization


