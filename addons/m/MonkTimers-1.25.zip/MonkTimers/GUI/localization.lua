local L = LibStub("AceLocale-3.0"):NewLocale("MonkTimers_GUI", "enUS", true, true)


L["Chi Bar"] = true
L["Chi Bar Size"] = true
L["Displays timer bars underneath times"] = true
L["General"] = true
L["Hide Blizz Chi Bar"] = true
L["Lock"] = true
L["Locks the position of MonkTimers"] = true
L["Red Flash Color"] = true
L["RedFlash Desc"] = "If enabled expiring timers flash red, else they will fade in and out."
L["Show Timer Bars"] = true
L["Show Tooltips"] = true
L["Stagger Bar"] = true
L["Stagger Bar Height"] = true
L["Stagger Dot Percent"] = true
L["Stagger Dot Tick"] = true
L["Stagger Dot Total"] = true
L["Stop Pulse"] = true
L["Stop Pulse Desc"] = "If a timer stops its icon gives a big visible pulse"
L["Time Color"] = true
L["Time Font"] = true
L["Timer Bar Color"] = true
L["Timer Bar Texture"] = true
L["Timers On Buttons"] = true
L["Timers On Buttons Desc"] = "Timers are displayed on the buttons instead of next to them."
L["Tooltips At Buttons"] = true
L["Tooltips At Buttons Desc"] = "Shows Tooltips to the right of TT's buttons."

L["Button Size"] = true
L["Clickthrough"] = true
L["Clickthrough Desc"] = "Disables any clicking functionality of the timer buttons"
L["Enable"] = true
L["Font Size"] = true
L["Hide OOC Desc"] = "Changing this setting will have effect after the next combat"
L["Hide out of combat"] = true
L["OOC Alpha"] = true
L["OOC Alpha Desc"] = "Controls the opacity of the buttons out of combat, 0 = transparent, 1 = opaque"

L["Arena"] = true
L["Battleground"] = true
L["Copy All"] = true
L["Copy Frame Positions"] = true
L["Copy From"] = true
L["Copy General Settings"] = true
L["Copy Settings"] = true
L["Copy Timers Settings"] = true
L["Copy To"] = true
L["Create Profile"] = true
L["default"] = "Default"
L["Delete Profile"] = true
L["Manage Profiles"] = true
L["New Name"] = true
L["Party"] = true
L["Profile"] = true
L["Profile already exists."] = true
L["Profiles"] = true
L["Raid"] = true
L["Really delete profile?"] = true
L["Really reset frame positions?"] = true
L["Reset Frame Positions"] = true
L["Reset Profile"] = true
L["Select Profiles"] = true
L["Solo"] = true
L["You cannot delete the default profile."] = true
L["You need to enter a profile name first."] = true


--[===[@debug@
L["MonkTimers"] = true
L["General"] = true
L["Version"] = true
L["Lock"] = true
L["Locks the position of MonkTimers"] = true
L["Red Flash Color"] = true
L["RedFlash Desc"] = "If enabled expiring timers flash red, else they will fade in and out."
L["Stop Pulse"] = true
L["Stop Pulse Desc"] = "For long cooldowns, if a timer stops its icon gives a big visible pulse"
L["Show Timer Bars"] = true
L["Displays timer bars underneath times"] = true
L["Timers On Buttons"] = true
L["Timers On Buttons Desc"] = "Timers are displayed on the buttons instead of next to them."
L["Show Tooltips"] = true
L["Tooltips At Buttons"] = true
L["Tooltips At Buttons Desc"] = "Shows Tooltips to the right of MT's buttons."
L["Time Color"] = true
L["Time Font"] = true
L["Timer Bar Color"] = true
L["Timer Bar Texture"] = true

L["Stagger Bar"] = true
L["Chi Bar"] = true
L["Stagger Bar Height"] = true
L["Chi Bar Size"] = true
L["Hide Blizz Chi Bar"] = true

L["Stagger Dot Tick"] = true
L["Stagger Dot Total"] = true
L["Stagger Dot Percent"] = true

L["Cloud Fart"] = true
L["Cloud Fart Desc"] = 'Fart 3 times to get your "meditative" cloud going.'

--L["Show Key Bindings"] = true
--L["Shows key bindings on totem timers"] = true
--L["Hide In Vehicles"] = true
--L["Hide In Vehicles Desc"] = "Hides MonkTimers while driving a vehicle. Do not change this setting while driving"



L["Clickthrough"] = true
L["Clickthrough Desc"] = "Disables any clicking functionality of the timer buttons"
L["Enable"] = true
L["Hide OOC Desc"] = "Changing this setting will have effect after the next combat"
L["Hide out of combat"] = true
L["OOC Alpha"] = true
L["OOC Alpha Desc"] = "Controls the opacity of the buttons out of combat, 0 = transparent, 1 = opaque"
L["Button Size"] = true
L["Font Size"] = true


L["default"] = "Default"
L["Manage Profiles"] = true
L["Select Profiles"] = true
L["Copy Settings"] = true
L["Solo"] = true
L["Arena"] = true
L["Party"] = true
L["Battleground"] = true
L["Raid"] = true
L["Scenario"] = true
L["Profiles"] = true
L["Profile"] = true
L["New Name"] = true
L["Create Profile"] = true
L["Delete Profile"] = true
L["Reset Profile"] = true
L["Really delete profile?"] = true
L["You need to enter a profile name first."] = true
L["Profile already exists."] = true
L["You cannot delete the default profile."] = true
L["Reset Frame Positions"] = true
L["Really reset frame positions?"] = true
L["Copy From"] = true
L["Copy To"] = true
L["Copy All"] = true
L["Copy General Settings"] = true
L["Copy Timers Settings"] = true
L["Copy Frame Positions"] = true


L["Blizz Style"] = true
L["Debug"] = true


L["Reset All"] = true
L["Reset Positions"] = true



--@end-debug@]===]
