﻿local L = LibStub("AceLocale-3.0"):NewLocale("MonkTimers_GUI", "ruRU")
if not L then return end 


L["Chi Bar"] = "Полоска чи" -- Needs review
L["Chi Bar Size"] = "Размер полоски чи" -- Needs review
L["Displays timer bars underneath times"] = "Отображать полоску таймера под числовым таймером" -- Needs review
L["General"] = "Общее" -- Needs review
L["Hide Blizz Chi Bar"] = "Скрыть стандартную полоску чи" -- Needs review
L["Lock"] = "Заблокировать" -- Needs review
L["Locks the position of MonkTimers"] = "Закрепить позицию аддона" -- Needs review
L["Red Flash Color"] = "Окрашивать красным" -- Needs review
L["RedFlash Desc"] = "При активации истекающие кулдауны будут окрашены красным, иначе - просто мигать" -- Needs review
L["Show Timer Bars"] = "Показывать полоски таймеров" -- Needs review
L["Show Tooltips"] = "Показывать всплывающие подсказки" -- Needs review
L["Stagger Bar"] = "Полоска пошатывания" -- Needs review
L["Stagger Bar Height"] = "Толщина полоски пошатывания" -- Needs review
L["Stagger Dot Percent"] = "Дота пошатывания в процентах" -- Needs review
L["Stagger Dot Tick"] = "Тик доты пошатывания" -- Needs review
L["Stagger Dot Total"] = "Общая величина доты пошатывания" -- Needs review
L["Stop Pulse"] = "Пульсация при окончании" -- Needs review
L["Stop Pulse Desc"] = "При истечении таймера иконка сделает большую пульсацию" -- Needs review
L["Time Color"] = "Цвет таймеров" -- Needs review
L["Time Font"] = "Шрифт таймеров" -- Needs review
L["Timer Bar Color"] = "Цвет полосок таймеров" -- Needs review
L["Timer Bar Texture"] = "Текстура полосок таймеров" -- Needs review
L["Timers On Buttons"] = "Таймеры на иконках" -- Needs review
L["Timers On Buttons Desc"] = "Таймеры будут отображаться прямо на иконках, а не рядом с ними" -- Needs review
L["Tooltips At Buttons"] = "Подсказки рядом с иконками" -- Needs review
L["Tooltips At Buttons Desc"] = "Показывать всплывающие подсказки рядом с иконками" -- Needs review

L["Button Size"] = "Размер иконок" -- Needs review
L["Clickthrough"] = "Возможность кликать сквозь иконки" -- Needs review
L["Clickthrough Desc"] = "Иконки перестают быть кликабельными (можно кликать сквозь них)" -- Needs review
L["Enable"] = "Включить" -- Needs review
L["Font Size"] = "Размер шрифта" -- Needs review
L["Hide OOC Desc"] = "Изменение этой опции применится после следующего боя" -- Needs review
L["Hide out of combat"] = "Скрывать вне боя" -- Needs review
L["OOC Alpha"] = "Прозрачность вне боя" -- Needs review
L["OOC Alpha Desc"] = "Регулирует прозрачность иконок вне боя: 0 = прозрачные, 1 - непрозрачные" -- Needs review

L["Arena"] = "Арена" -- Needs review
L["Battleground"] = "Поле боя" -- Needs review
L["Copy All"] = "Скопировать все" -- Needs review
L["Copy Frame Positions"] = "Скопировать позиции фреймов" -- Needs review
L["Copy From"] = "Скопировать из" -- Needs review
L["Copy General Settings"] = "Скопировать общие настройки" -- Needs review
L["Copy Settings"] = "Скопировать настройки" -- Needs review
L["Copy Timers Settings"] = "Скопировать настройки таймеров" -- Needs review
L["Copy To"] = "Скопировать в" -- Needs review
L["Create Profile"] = "Создать профиль" -- Needs review
L["default"] = "По умолчанию" -- Needs review
L["Delete Profile"] = "Удалить профиль" -- Needs review
L["Manage Profiles"] = "Управление профилями" -- Needs review
L["New Name"] = "Новое имя" -- Needs review
L["Party"] = "Группа" -- Needs review
L["Profile"] = "Профиль" -- Needs review
L["Profile already exists."] = "Профиль уже существует" -- Needs review
L["Profiles"] = "Профили" -- Needs review
L["Raid"] = "Рейд" -- Needs review
L["Really delete profile?"] = "Действительно удалить профиль?" -- Needs review
L["Really reset frame positions?"] = "Действительно сбросить позиции фреймов?" -- Needs review
L["Reset Frame Positions"] = "Сбросить позиции фреймов" -- Needs review
L["Reset Profile"] = "Сбросить настройки профиля" -- Needs review
L["Select Profiles"] = "Выбор профилей" -- Needs review
L["Solo"] = "Соло" -- Needs review
L["You cannot delete the default profile."] = "Нельзя удалить профиль по умолчанию" -- Needs review
L["You need to enter a profile name first."] = "Сначала введите имя профиля" -- Needs review
