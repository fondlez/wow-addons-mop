-- Copyright © 2012 Xianghar  <xian@zron.de>
-- All Rights Reserved.
-- This code is not to be modified or distributed without written permission by the author.
-- Current distribution permissions only include curse.com, wowinterface.com and their respective addon updaters

if select(2,UnitClass("player")) ~= "MONK" then return end

local _, MonkTimers = ...

local SpellIDs = MonkTimers.SpellIDs
local SpellTextures = MonkTimers.SpellTextures
local SpellNames = MonkTimers.SpellNames
local AvailableSpells = MonkTimers.AvailableSpells


local cds = {}

local player = UnitName("player")


-- spells: avert harm, dampen harm, fortifying brew

local CDEvent
local BuffEvent
local CDAndBuffEvent
local DampenHarmEvent

local function ConfigureTimer(nr, spell)
	cds[nr].cdspell = spell
	cds[nr].button.cdspell = spell
	cds[nr].button.cdspellName = SpellNames[spell]
	cds[nr].durationTimer.buffSpell = spell
	cds[nr].button.icon:SetTexture(SpellTextures[spell])
	--[[cds[nr].durationTimer.button.icon:SetTexture(SpellTextures[spell])
	cds[nr].durationTimer.button.buffSpellName = SpellNames[spell]
	cds[nr].durationTimer.button.cooldown:SetAlpha(0.4) ]]
	
	cds[nr].button:SetAttribute("*type*", "spell")
	cds[nr].button:SetAttribute("*spell1", spell)
	cds[nr].rangeCheck = SpellNames[spell]
	cds[nr].manaCheck = SpellNames[spell]
end


function MonkTimers.CreateLongCooldowns()

	for i = 1,6 do
		cds[i] = XiTimers:new()
		cds[i].durationTimer = XiTimers:new(true)
		cds[i].durationTimer.button:SetParent(cds[i].button)
		cds[i].durationTimer.button:EnableMouse(false)
		cds[i].button.anchorframe = MonkTimers_LongCooldownsFrame
		cds[i].durationTimer.hideInactive = true
		cds[i].durationTimer:SetPoint("CENTER", cds[i], "CENTER")
		
		cds[i].SetWidth = function(self, width)
			XiTimers.SetWidth(self, width)
			self.durationTimer:SetWidth(width)
		end
		cds[i].SetHeight = function(self, height)
			XiTimers.SetHeight(self, height)
			self.durationTimer:SetHeight(height)
		end
		cds[i].durationTimer:SetScale(2)
		cds[i].durationTimer.button:SetFrameStrata("BACKGROUND")
		
		--cds[i].button:SetScript("OnEvent", CDEvent)
		cds[i].button:SetScript("OnEvent", CDAndBuffEvent)
		cds[i].durationTimer.button:SetScript("OnEvent", BuffEvent)
		
		cds[i].durationTimer.maxAlpha = 0.6
		
		cds[i].button:RegisterForClicks("LeftButtonDown", "RightButtonDown", "MiddleButtonDown")
		
		cds[i].events[1] = "SPELL_UPDATE_COOLDOWN"
		cds[i].events[2] = "UNIT_AURA"
		
		cds[i].durationTimer.Activate = function(self)
			self.button:RegisterUnitEvent("UNIT_AURA", "player")
			XiTimers.Activate(self)
		end
		
		cds[i].durationTimer.Deactivate = function(self)
			self.button:UnregisterEvent("UNIT_AURA")
			XiTimers.Deactivate(self)
		end
		
		cds[i].durationTimer.showCooldown = true
		cds[i].durationTimer.hideTime = true
		cds[i].durationTimer.dontFlash = true
		
		cds[i].SetScale = function(self, scale)
			XiTimers.SetScale(self, scale)
			self.durationTimer:SetScale(scale*2)
		end
		
		cds[i].button:SetScript("OnEnter", function(self) MonkTimers.Tooltip(self) end)
		cds[i].button:SetScript("OnLeave", function(self) MonkTimers.HideTooltip(self) end)
		
		cds[i].button.bar:SetStatusBarColor(0.6,0.6,1,0.8)
	end
	MonkTimers.LongCooldowns = cds
	
	ConfigureTimer(1, SpellIDs.FortifyingBrew)
	ConfigureTimer(2, SpellIDs.AvertHarm) -- + LifeCocoon +TouchOfKarma
	ConfigureTimer(3, SpellIDs.DampenHarm) -- + DiffuseMagic
	ConfigureTimer(4, SpellIDs.Xuen) -- Rushing Jade Wind removed
	ConfigureTimer(5, SpellIDs.ZenMeditation)
	ConfigureTimer(6, SpellIDs.Revival)

    
end


function MonkTimers.ActivateLongCooldowns(activate)
	for i = 1,#cds do
		cds[i]:Deactivate()
		cds[i].durationTimer:Deactivate()
		cds[i].button:SetScript("OnEvent", CDAndBuffEvent)
	end
	if AvailableSpells[SpellIDs.DampenHarm] then 
		ConfigureTimer(3, SpellIDs.DampenHarm)
		cds[3].button:SetScript("OnEvent", DampenHarmEvent)
	else
		ConfigureTimer(3, SpellIDs.DiffuseMagic)
	end
	--if AvailableSpells[SpellIDs.Xuen] then ConfigureTimer(4, SpellIDs.Xuen) else ConfigureTimer(4, SpellIDs.RushingJadeWind) end
	if AvailableSpells[SpellIDs.AvertHarm] then
		ConfigureTimer(2, SpellIDs.AvertHarm)
	elseif AvailableSpells[SpellIDs.LifeCocoon] then
		ConfigureTimer(2, SpellIDs.LifeCocoon)
	else
		ConfigureTimer(2, SpellIDs.TouchOfKarma)
	end
	if activate then
		for i = 1,#cds do
			if MonkTimers.ActiveProfile.LongCooldownSpells[cds[i].cdspell] and AvailableSpells[cds[i].cdspell] then
				cds[i]:Activate()
			--	cds[i].durationTimer:Activate()
			end
		end
	end
	MonkTimers.LayoutLongCooldowns()
end

local activecds = {}

function MonkTimers.LayoutLongCooldowns()
	local point1, point2
	if MonkTimers.ActiveProfile.LongCooldownsArrange ~= "vertical" then
		point1 = "LEFT"
		point2 = "RIGHT"
	else
		point1 = "TOP"
		point2 = "BOTTOM"
	end
	wipe(activecds)
	for i = 1,#cds do
		cds[i]:ClearAnchors()
	end
	for i=1,#cds do
		if cds[i].active then tinsert(activecds,cds[i]) end
	end
	if #activecds > 0 then
		activecds[1]:SetPoint("CENTER", MonkTimers_LongCooldownsFrame, "CENTER")
	end
	for i = 2,#activecds do
		activecds[i]:Anchor(activecds[i-1], point1, point2)
	end
end

CDEvent = function(self, event, unit, spell)
	local start, duration, enable = GetSpellCooldown(self.timer.cdspell)
	if (not start and not duration) or (duration <= 1.5 and not InCombatLockdown()) then
		self.timer:Stop()					
	else
		if duration == 0 then
			self.timer:Stop(1)
		elseif duration > 2 and self.timer.timer<=0 then
			self.timer:Start(start+duration-floor(GetTime()),duration)
		end
		CooldownFrame_SetTimer(self.cooldown, start, duration, enable)
	end 
end

BuffEvent = function(self, event)
	local name,_,_,count,_,duration,expiration = UnitBuff("player", self.buffSpellName)
	if duration and duration > 0 then
		self.timer:Start(expiration-GetTime(), duration)
	elseif self.timer.timer > 0 then
		self.timer:Stop()
	end
end

CDAndBuffEvent = function(self, event, ...)
    if event == "SPELL_UPDATE_COOLDOWN" and AvailableSpells[self.cdspell] and not self.BuffIsRunning then 
        local start, duration, enable = GetSpellCooldown(self.cdspell)
        if (not start and not duration) or (duration <= 1.5 and not InCombatLockdown()) then
            self.timer:Stop()					
        else
            if duration == 0 then
                self.timer:Stop()
            elseif duration > 2 and self.timer.timer<=0 then
                self.timer:Start(start+duration-floor(GetTime()),duration)
            end
            CooldownFrame_SetTimer(self.cooldown, start, duration, enable)
        end 
    elseif event == "UNIT_AURA" then
        local unit = ...
        if unit == "player" then
            local timer = self.timer
            local _,_,_,count,_,duration,expiration = UnitBuff("player", self.cdspellName)
            if duration then
				self.BuffIsRunning = true
                timer.reverseAlpha = false
				timer.prohibitCooldown = true
				timer.dontFlash = true
                timer:Start(expiration-GetTime(), duration)
                timer:StartBarTimer(expiration-GetTime(), duration)                
            elseif self.BuffIsRunning then
                self.BuffIsRunning = false
                timer.reverseAlpha = true
				timer.prohibitCooldown = false
				timer.dontFlash = false
                timer:StopBarTimer()
                local cdstart, cdduration, cdenable = GetSpellCooldown(self.cdspell)
                if cdduration then
                    timer:Start(cdstart+cdduration-floor(GetTime()),cdduration)
                else
                    timer:Stop()
                end
            end
        end        
    end
end

local introIcon = CreateFrame("FRAME", "MonkTimers_LongCooldownIntro", UIParent, "IconIntroTemplate")

function MonkTimers.LongCooldownIntroAnimation(spell)
	local doAnimation = false
	for i=1,#cds do
		if cds[i].cdspell == spell then doAnimation = i end
	end
	if not doAnimation then return end
	introIcon:ClearAllPoints()
	introIcon:SetPoint("CENTER", cds[doAnimation].button, 0,0)
	introIcon.icon.icon:SetTexture(SpellTextures[spell])
	introIcon.icon.slot = 0
	introIcon.icon.flyin:Play(1)
end

local DampenHarm = SpellNames[SpellIDs.DampenHarm]
local DampenHarmActive = false

DampenHarmEvent = function(self, event, unit)
    if event == "SPELL_UPDATE_COOLDOWN" and AvailableSpells[self.cdspell] and not self.BuffIsRunning then 
        local start, duration, enable = GetSpellCooldown(self.cdspell)
        if (not start and not duration) or (duration <= 1.5 and not InCombatLockdown()) then
            self.timer:Stop()					
        else
            if duration == 0 then
                self.timer:Stop()
            elseif duration > 2 and self.timer.timer<=0 then
                self.timer:Start(start+duration-floor(GetTime()),duration)
            end
            CooldownFrame_SetTimer(self.cooldown, start, duration, enable)
        end 
    elseif event == "UNIT_AURA" then
        if unit == "player" then
            local timer = self.timer
            local _,_,_,count,_,duration,expiration = UnitBuff("player", self.cdspellName)
            if duration then
				self.BuffIsRunning = true
                timer.reverseAlpha = false
				timer.prohibitCooldown = true
				timer.dontFlash = true
				timer.barTimerOnly = true
				timer.timeStyle = "sec"
                timer:Start(count, 3)
                timer:StartBarTimer(expiration-GetTime(), duration)                
            elseif self.BuffIsRunning then
                self.BuffIsRunning = false
                timer.reverseAlpha = true
				timer.prohibitCooldown = false
				timer.dontFlash = false
				timer.barTimerOnly = false	
				timer.timeStyle = "mm:ss"
                timer:StopBarTimer()
                local cdstart, cdduration, cdenable = GetSpellCooldown(self.cdspell)
                if cdduration then
                    timer:Start(cdstart+cdduration-floor(GetTime()),cdduration)
                else
                    timer:Stop()
                end
            end
        end        
    end
end