-- ********************************************************
-- **               Memoria - itIT Local                 **
-- **           <http://nanaki.affenfelsen.de>           **
-- ********************************************************
--
-- This localization is written by:
--  Deepking
--

-- Check for addon table
if (not Memoria) then Memoria = {}; end
if GetLocale() ~= "itIT" then return end

-- Localization
-- Memoria.L["arena endings"] = "arena endings"
-- Memoria.L["battleground endings"] = "battleground endings"
-- Memoria.L["exalted only"] = "exalted only"
-- Memoria.L["level up"] = "level up"
-- Memoria.L["new achievement"] = "new achievement"
-- Memoria.L["new reputation level"] = "new reputation level"
-- Memoria.L["Take screenshot on"] = "Take screenshot on"
-- Memoria.L["wins only"] = "wins only"

