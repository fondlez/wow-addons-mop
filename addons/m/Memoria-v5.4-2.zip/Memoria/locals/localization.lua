-- ********************************************************
-- **             Memoria - enGB/enUS Local              **
-- **           <http://nanaki.affenfelsen.de>           **
-- ********************************************************
--
-- This localization is written by:
--  Mizukichan
--

-- Check for addon table
if (not Memoria) then Memoria = {}; end
local Memoria = Memoria;

-- Localization
Memoria.L = {
    ["Take screenshot on"] = "Take screenshot on",
    ["arena endings"] = "arena endings",
    ["battleground endings"] = "battleground endings",
    ["exalted only"] = "exalted only",
    ["level up"] = "level up",
    ["new achievement"] = "new achievement",
    ["new reputation level"] = "new reputation level",
    ["wins only"] = "wins only",
}
