local a,t=...
local s=t.AddPlate
s(1315,"Abandoned Fealty Battleplate",{44349,47497,47514,46058,48978,47212,47227,47201},35) --1315; Plate
s(1316,"Abandoned Fealty Battleplate (Recolor)",{47172,46057,48977,47567,47510,47503,47199},2) --1315; Plate
s(1317,"Abandoned Fealty Battleplate (Recolor)",{47220,47502,47176,47565,47197,47229,47495,47511},nil) --1315; Plate
s(584,"Aegis Battlegear",{45835,45843,45375,45377,45380},2) --584; Plate
s(428,"Aegis Battlegear (Recolor)",{45552,45561,45226,45452,45252,45167,45140},nil) --584; Plate
s(458,"Aegis Battlegear (Recolor)",{45445,46345,45975,46028,45936,45321,45698,45928},nil) --584; Plate
s(585,"Aegis Battlegear (Recolor)",{70120,46152,46153,46154,46155,46156},2) --584; Plate
s(1061,"Amani Plate",{69595,69552,69599,69641,69562,33517},nil) --1061; Plate
s(1062,"Amani Plate (Recolor)",{69582,69557,69614,69608,69587,33523,69633},nil) --1061; Plate
s(1647,"Amani Plate (Recolor)",{69593,69801,69619,69583},nil) --1061; Plate
s(577,"Avenger's Battlegear",{21389,21387,21388,21390,21391,21618,21606,21623},2) --577; Plate
s(593,"Battlearmor of Immolation",{70946,70947,70948,70949,70950,71026,71253,71351},2) --593; Plate
s(454,"Battlearmor of Immolation (Lookalike)",{69938,71342,71043,70988,71026,71028,71351},nil) --593; Plate
s(495,"Battlearmor of Immolation (Lookalike)",{71465,71413,71439,71452,71426,71453,71475},nil) --593; Plate
s(594,"Battlearmor of Immolation (Recolor)",{71522,71523,71524,71525,71526,71452,71475},2) --593; Plate
s(935,"Battlegear of Heroism",{97762,97767,97766,97763,97764,97765,97761,21996},1) --935; Plate
s(685,"Battlegear of Might",{16864,16861,16865,16863,16866,16867,16868,16862},1) --685; Plate
s(1791,"Battlegear of Valor (Recolor)",{31368,31364,31367},nil) --685; Plate
s(686,"Battlegear of Wrath",{49320,16959,16966,16964,16962,16961,16965,16960},1) --686; Plate
s(1194,"Battleplate of Radiant Glory",{76874,76875,77005,76768,76769,77265,77244},2) --1194; Plate
s(1246,"Battleplate of Radiant Glory (Lookalike)",{77153,77123,71991,77164,77184,71982,77169},nil) --1194; Plate
s(1195,"Battleplate of Radiant Glory (Recolor)",{78464,78436,78727,78695,78717,78746,78361},2) --1194; Plate
s(1196,"Battleplate of Radiant Glory (Recolor)",{78469,78444,78822,78790,78812,78841,78386},2) --1194; Plate
s(1460,"Battleplate of the Lost Catacomb",{86913,86914,86915,86916,86917,87186,90507,90506},32) --1460; Plate
s(1461,"Battleplate of the Lost Catacomb (Lookalike)",{90506,90507,86944,86966,87186,87049,87059,89923},nil) --1460; Plate
s(1468,"Battleplate of the Lost Catacomb (Lookalike)",{86174,86203,86213,86230,86232,86385,87402,87406},nil) --1460; Plate
s(1787,"Battleplate of the Lost Catacomb (Lookalike)",{86832,86860,89958,86854,89981,86904,86870,86868},nil) --1460; Plate
s(1464,"Battleplate of the Lost Catacomb (Recolor)",{86654,86655,86656,86657,86658,86904,86870,86868},32) --1460; Plate
s(1467,"Battleplate of the Lost Catacomb (Recolor)",{85314,85315,85316,85317,85318,86385,86232,86230},32) --1460; Plate
s(916,"Blessed Battlegear of Undead Slaying",{43070,43068,43071,43069},nil) --916; Plate
s(383,"Bold Armor (Recolor)",{44205,44201,28775,28743,28597,28518,28502},nil) --916; Plate
s(755,"Brutal Gladiator's Aegis",{35027,35028,35029,35030,35031,35155,35140},2) --755; Plate
s(857,"Brutal Gladiator's Battlegear",{35066,35067,35068,35069,35070,35161,35146},1) --857; Plate
s(1224,"Cataclysmic Gladiator's Battlegear",{73482,73481,73480,73479,73478,73554,73552},1) --1224; Plate
s(1225,"Cataclysmic Gladiator's Battlegear (Recolor)",{73655,73654,73653,73652,73651,73695},1) --1224; Plate
s(1228,"Cataclysmic Gladiator's Desecration",{73620,73619,73618,73617,73616,73555,73553},32) --1228; Plate
s(1229,"Cataclysmic Gladiator's Desecration (Recolor)",{73742,73741,73740,73739,73738,73696},32) --1228; Plate
s(1226,"Cataclysmic Gladiator's Redemption",{73571,73570,73569,73568,73567,73563,73566},2) --1226; Plate
s(1227,"Cataclysmic Gladiator's Redemption (Recolor)",{73708,73707,73706,73705,73704,73702},2) --1226; Plate
s(1197,"Colossal Dragonplate Battlegear",{76984,76985,76990,76991,76987,77171,77186},1) --1197; Plate
s(1244,"Colossal Dragonplate Battlegear (Lookalike)",{77156,77268,77120,77258,77166,77239,71984,77171},nil) --1197; Plate
s(1198,"Colossal Dragonplate Battlegear (Recolor)",{78367,78657,78668,78689,78705,78431,78452},1) --1197; Plate
s(1199,"Colossal Dragonplate Battlegear (Recolor)",{78378,78752,78763,78784,78800,78460,78439},1) --1197; Plate
s(687,"Conqueror's Battlegear",{21814,21329,21333,21332,21330,21618,21598,21581},1) --687; Plate
s(499,"Conqueror's Darkruned Battlegear",{45833,45841,46111,46115,46117,45501},32) --499; Plate
s(580,"Crystalforge Armor",{30034,30123,30125,30124,30126,30127,30027},2) --580; Plate
s(1029,"Crystalforge Armor (Recolor)",{31992,31993,31995,31996,31997,32801,32789},2) --580; Plate
s(1661,"Crystalforge Armor (Recolor)",{30048,30084,30112,30065,34947},nil) --580; Plate
s(1055,"Dark Iron Plate",{31548,30960,11745,24996,19148,17014,20039},nil) --1055; Plate
s(1119,"Darkruned Battlegear",{45134,45107,45320,45225,45481,45161,45599},nil) --1119; Plate
s(430,"Darkruned Battlegear (Recolor)",{46041,45712,45299,45982,45330,46037,45888,45997},nil) --1119; Plate
s(858,"Deadly Gladiator's Battlegear",{40786,40804,40823,40844,40862,40888,40879,40880},1) --858; Plate
s(936,"Deadly Gladiator's Desecration",{40784,40806,40824,40845,40863,40888,40879,40880},32) --936; Plate
s(756,"Deadly Gladiator's Redemption",{40905,40926,40932,40938,40962,40982,40974,40975},2) --756; Plate
s(690,"Destroyer Armor",{30032,30113,30115,30114,30116,30117,30057,30081},1) --690; Plate
s(409,"Destroyer Armor (Recolor)",{29983,30053,30102,29998,29950},nil) --690; Plate
s(1049,"Destroyer Armor (Recolor)",{30486,30487,30488,30489,30490,32805,32793},1) --690; Plate
s(692,"Dreadnaught Battlegear",{39605,39606,39607,39608,39609,39195,39298,39139},1) --692; Plate
s(693,"Dreadnaught Battlegear (Recolor)",{39717,39759,40525,40527,40528,40529,40530},1) --692; Plate
s(688,"Dreadnaught's Battlegear",{22423,22416,22421,22422,22418,22417,22419,22420},nil) --688; Plate
s(930,"Earthen Warplate",{60331,60330,60328,60332,60329,59470,63491,59221},1) --930; Plate
s(446,"Earthen Warplate (Lookalike)",{55058,59356,59505,67141,59344,55061,59221,59470},nil) --930; Plate
s(931,"Earthen Warplate (Recolor)",{65269,65270,65271,65272,65273,65143,65370,60229},1) --930; Plate
s(1666,"Earthen Warplate (Recolor)",{65027,65071,65121,65131,65038},nil) --930; Plate
s(507,"Elementium Deathplate Battlegear",{71058,71059,71060,71061,71062,70920,71250,71029},32) --507; Plate
s(452,"Elementium Deathplate Battlegear (Lookalike)",{69937,70734,71344,71250,70739,71029,70920},nil) --507; Plate
s(493,"Elementium Deathplate Battlegear (Lookalike)",{71469,71419,71430,71431,71404,71470},nil) --507; Plate
s(508,"Elementium Deathplate Battlegear (Recolor)",{71476,71477,71478,71479,71480,71470,71404},32) --507; Plate
s(849,"Field Marshal's Battlegear",{16477,16478,16480,16483,16484,16479},1) --849; Plate
s(861,"Furious Gladiator's Battlegear",{40789,40807,40826,40847,40866},1) --861; Plate
s(939,"Furious Gladiator's Desecration",{40787,40809,40827,40848,40868,40889,40881,40882},32) --939; Plate
s(759,"Furious Gladiator's Redemption",{40907,40927,40933,40939,40963,40983,40976,40977},2) --759; Plate
s(752,"Gladiator's Aegis",{27702,27703,27704,27705,27706,28641,28642},2) --752; Plate
s(854,"Gladiator's Battlegear",{24544,24549,24545,24547,24546,28385,28383},1) --854; Plate
s(1531,"Golden King Plate",{90147,90148,90149,90150,90151,90152,90153,90154},1) --1531; Plate
s(1702,"Grievous Gladiator's Battleplate",{103459,103456,103525,103526,103527,103528,103529,103457},1) --1702; Plate
s(1703,"Grievous Gladiator's Battleplate (Recolor)",{102702,102618,102685,102698,102619,102724,102728,102732},1) --1702; Plate
s(1705,"Grievous Gladiator's Battleplate (Recolor)",{103074,103075,103128,103129,103130,103131,103132},1) --1702; Plate
s(1699,"Grievous Gladiator's Desecration",{103455,103376,103378,103379,103380,103377,103458,103460},32) --1699; Plate
s(1700,"Grievous Gladiator's Desecration (Recolor)",{102968,102873,102847,102910,102848,102849,102837,102942},32) --1699; Plate
s(1701,"Grievous Gladiator's Desecration (Recolor)",{103004,103005,103006,103007,103008,103073,103076},32) --1699; Plate
s(1696,"Grievous Gladiator's Redemption",{103450,103441,103442,103443,103444,103446,103448,103440},2) --1696; Plate
s(1697,"Grievous Gladiator's Redemption (Recolor)",{100710,100582,100726,100725,100693,100690,100668,102962},2) --1696; Plate
s(1698,"Grievous Gladiator's Redemption (Recolor)",{100374,100378,100364,100366,100368,100370,100372},2) --1696; Plate
s(859,"Hateful Gladiator's Battlegear",{44895,40783,40801,40819,40840,40859,40887,40877},1) --859; Plate
s(937,"Hateful Gladiator's Desecration",{40781,40803,40820,40841,40860},32) --937; Plate
s(757,"Hateful Gladiator's Redemption",{44894,40904,40925,40931,40937,40961,40972,40966},2) --757; Plate
s(697,"Hellscream's Battlegear",{48396,48397,48398,48399,48400,90320,47414,47859},1) --697; Plate
s(1010,"Hellscream's Battlegear (Lookalike)",{90320,90293,90302,90311,47444,48016,47492},nil) --697; Plate
s(496,"Heroes' Scourgeborne Battlegear",{39617,39618,39619,39620,39621},32) --496; Plate
s(1710,"Heroic Plate (Recolor)",{30074,23532,30069},nil) --496; Plate
s(1530,"Holy Warrior Plate",{90096,90097,90098,90099,90100,90101,90102,90103},2) --1530; Plate
s(1477,"Inner Serenity Plate",{95520,90722,89423,93265,86149,89096,86027,88749},nil) --1477; Plate
s(1478,"Inner Serenity Plate (Recolor)",{90718,95524,89823,93263,86080,89216,85983,88746},nil) --1477; Plate
s(1479,"Inner Serenity Plate (Recolor)",{90717,86076,93264,93323,89345,85984,88879,86135},nil) --1477; Plate
s(1716,"Inner Serenity Plate (Recolor)",{101789,101791,101792,101793,101794,101796,101797,101799},nil) --1477; Plate
s(576,"Judgement Armor",{49323,16952,16951,16958,16956,16954,16957,16953},2) --576; Plate
s(579,"Justicar Armor",{29066,29068,29067,29069,29070,28512,28733,28569},2) --579; Plate
s(1028,"Justicar Armor (Recolor)",{27702,27703,27704,27705,27706,28641,28642},2) --579; Plate
s(501,"Koltira's Battlegear",{48491,48492,48493,48494,48495,90321,47869,47870},32) --501; Plate
s(1008,"Koltira's Battlegear (Lookalike)",{90321,90294,90303,90312,47429,47696,47851},nil) --501; Plate
s(1792,"Lawbringer Armor (Recolor)",{23535,31369,31370},nil) --501; Plate
s(587,"Liadrin's Battlegear",{48585,48586,48587,48588,48589,90319,47455,47484},2) --587; Plate
s(1002,"Liadrin's Battlegear (Lookalike)",{90319,90292,90301,90310,47701,47997,47455},nil) --587; Plate
s(1529,"Lich Lord Plate",{90049,90050,90051,90052,90053,90054,90055,90056},32) --1529; Plate
s(581,"Lightbringer Armor",{30991,30987,30985,30995,30998,32279,32512,32245},2) --581; Plate
s(1030,"Lightbringer Armor (Recolor)",{32354,33695,33698,33699,33888,33890},2) --581; Plate
s(588,"Lightsworn Garb",{54565,50324,50325,50326,50327,50328,50796,50772},2) --588; Plate
s(473,"Lightsworn Garb (Lookalike)",{54565,50796,50772,51018,50775,51586,50967},nil) --588; Plate
s(474,"Lightsworn Garb (Lookalike)",{54586,49902,50969,50976,51907,51824,51836},nil) --588; Plate
s(475,"Lightsworn Garb (Lookalike)",{54586,49902,50969,50976,50175,50060,49980,50451},nil) --588; Plate
s(476,"Lightsworn Garb (Lookalike)",{50632,50721,50701,50650,50623,50680,50617,50667},nil)
s(589,"Lightsworn Garb (Recolor)",{51160,51161,51162,51163,51164,51907,51836,51931},2)
s(590,"Lightsworn Garb (Recolor)",{51275,51276,51277,51278,51279,50721,50667,50632},2)
s(505,"Magma Plated Battlearmor",{90577,60340,60341,60342,60343,59118,62384,59464},32) --505; Plate
s(445,"Magma Plated Battlearmor (Lookalike)",{59487,90577,59901,59317,59328,59342,59118},nil) --505; Plate
s(1651,"Magma Plated Battlearmor (Lookalike)",{65130,65379,65062,65051,60228,65040},nil) --505; Plate
s(506,"Magma Plated Battlearmor (Recolor)",{65179,65180,65181,65182,65183,65085,65369,65051},32) --505; Plate
s(1411,"Malevolent Gladiator's Battleplate",{98864,98926,98927,98928,98929,98930,98860,98862},1) --1411; Plate
s(1412,"Malevolent Gladiator's Battleplate (Recolor)",{84987,84999,85019,85032,85063,85077,85103},1) --1411; Plate
s(1417,"Malevolent Gladiator's Desecration",{98784,98785,98786,98787,98788,98859,98861,98863},32) --1417; Plate
s(1418,"Malevolent Gladiator's Desecration (Recolor)",{84993,85000,85028,85046,85059,85086,85102},32) --1417; Plate
s(1414,"Malevolent Gladiator's Redemption",{84793,84811,84831,84849,84869,84914,84951,84974},2) --1414; Plate
s(1415,"Malevolent Gladiator's Redemption (Recolor)",{84991,85001,85024,85042,85056,85090,85104},2) --1414; Plate
s(753,"Merciless Gladiator's Aegis",{31992,31993,31995,31996,31997,32801,32789},2) --753; Plate
s(855,"Merciless Gladiator's Battlegear",{30486,30487,30488,30489,30490,32805,32793},1) --855; Plate
s(932,"Molten Giant Battleplate",{70941,70942,70944,70943,70945,71004,71021,70912},1) --932; Plate
s(453,"Molten Giant Battleplate (Lookalike)",{69936,70916,70737,70914,70937,71021,70913,70912},nil) --932; Plate
s(494,"Molten Giant Battleplate (Lookalike)",{71459,71432,71405,71443,71444,71420,71458},nil) --932; Plate
s(933,"Molten Giant Battleplate (Recolor)",{71604,71605,71606,71607,71608,71418,71443,71420},1) --932; Plate
s(1193,"Naxxramas Icebane Plate",{22671,22669,22670,43587,23019,22699,22940},nil) --1193; Plate
s(1200,"Necrotic Boneplate Battlegear",{76974,76975,77010,76977,76978,77170,77250},32) --1200; Plate
s(1245,"Necrotic Boneplate Battlegear (Lookalike)",{77155,77236,77119,77317,77165,77250,71983,77259},nil) --1200; Plate
s(1201,"Necrotic Boneplate Battlegear (Recolor)",{78465,78659,78670,78697,78707,78389,78416},32) --1200; Plate
s(1202,"Necrotic Boneplate Battlegear (Recolor)",{78470,78754,78765,78792,78802,78396,78424},32) --1200; Plate
s(691,"Onslaught Armor",{34546,32521,32280,34569,30976,30978,30980,32232},1) --691; Plate
s(1050,"Onslaught Armor (Recolor)",{32341,32373,32278,33728,33732,33811,33812},1) --691; Plate
s(1777,"Plate of Cyclopean Dread",{99192,105165,99193,99194,99191,99187,105184,105166},32) --1777; Plate
s(1778,"Plate of Cyclopean Dread (Lookalike)",{105359,105165,105382,105807,105759,105794,105184,105166},nil) --1777; Plate
s(1780,"Plate of Cyclopean Dread (Lookalike)",{105608,105414,105631,105586,105565,105434,105433,105415},nil) --1777; Plate
s(1782,"Plate of Cyclopean Dread (Lookalike)",{105110,104916,105823,105088,105067,104936,104935,104917},nil) --1777; Plate
s(1779,"Plate of Cyclopean Dread (Recolor)",{99335,105414,99336,99337,99338,99339,105433,105415},32)
s(1781,"Plate of Cyclopean Dread (Recolor)",{99066,104916,99067,99057,99058,99059,104935,104917},32)
s(1458,"Plate of Resounding Rings",{87192,87193,87194,87195,87196,86955,86979,87001},1) --1458; Plate
s(1459,"Plate of Resounding Rings (Lookalike)",{89921,89928,86955,86956,86979,87001,87171,87024},nil) --1458; Plate
s(1785,"Plate of Resounding Rings (Lookalike)",{90415,89828,90425,89837,86165,86164,86190,86201},nil) --1458; Plate
s(1786,"Plate of Resounding Rings (Lookalike)",{86664,86891,89963,86823,86822,86852,86848},1) --1458; Plate
s(1466,"Plate of Resounding Rings (Recolor)",{86664,86665,86666,86667,86668,86822,86852,86848},1)
s(1470,"Plate of Resounding Rings (Recolor)",{85324,85325,85326,85327,85328,86164,86190,86201},1)
s(1629,"Plate of the All-Consuming Maw",{96569,96570,96571,96572,96573,95002,95011,96800},32) --1629; Plate
s(1630,"Plate of the All-Consuming Maw (Lookalike)",{96990,97095,95038,96868,95025,96818,96894,96800},nil) --1629; Plate
s(1632,"Plate of the All-Consuming Maw (Lookalike)",{94268,94267,95152,95199,95191,96023,96055,96056},nil) --1629; Plate
s(1634,"Plate of the All-Consuming Maw (Lookalike)",{95630,95798,95752,95778,95651,95683,95702,95684},nil) --1629; Plate
s(1631,"Plate of the All-Consuming Maw (Recolor)",{95225,95226,95227,95228,95229,96074,96170,96056},32)
s(1633,"Plate of the All-Consuming Maw (Recolor)",{95825,95826,95827,95828,95829,95702,95798,95684},32)
s(1635,"Plate of the Last Mogu",{96730,96731,96732,96733,96734,95003,95012,96747},1) --1635; Plate
s(1636,"Plate of the Last Mogu (Lookalike)",{97094,96790,96851,95023,95003,96768,96989,96747},nil) --1635; Plate
s(1638,"Plate of the Last Mogu (Lookalike)",{94266,94265,95153,95198,95192,96003,96105,96245},nil) --1635; Plate
s(1640,"Plate of the Last Mogu (Lookalike)",{95674,95734,95725,95652,95733,95873,95629,95631},nil) --1635; Plate
s(1637,"Plate of the Last Mogu (Recolor)",{95330,95331,95332,95333,95334,96001,96106,96003},1)
s(1639,"Plate of the Last Mogu (Recolor)",{95986,95987,95988,95989,95990,95734,95631,95629},1)
s(1641,"Plate of the Lightning Emperor",{96654,96655,96656,96657,96658,95001,95010,96780},2) --1641; Plate
s(1642,"Plate of the Lightning Emperor (Lookalike)",{95010,96760,96862,96893,96812,96839,96883,96780},nil) --1641; Plate
s(1644,"Plate of the Lightning Emperor (Lookalike)",{94263,94264,95151,95201,95190,96036,96119,96139},nil) --1641; Plate
s(1646,"Plate of the Lightning Emperor (Lookalike)",{95644,95716,95697,95723,95747,95767,95696,95664},nil) --1641; Plate
s(1643,"Plate of the Lightning Emperor (Recolor)",{95280,95281,95282,95283,95284,96068,96088,96036},2)
s(1645,"Plate of the Lightning Emperor (Recolor)",{95910,95911,95912,95913,95914,95696,95716,95664},2)
s(1771,"Plate of the Prehistoric Marauder",{99201,105282,99202,99206,99195,99200,105260,105162},1) --1771; Plate
s(1772,"Plate of the Prehistoric Marauder (Lookalike)",{105769,105282,105370,105394,105391,105796,105260,105162},nil) --1771; Plate
s(1774,"Plate of the Prehistoric Marauder (Lookalike)",{105532,105531,105619,105643,105640,105641,105509,105411},nil) --1771; Plate
s(1776,"Plate of the Prehistoric Marauder (Lookalike)",{105034,105033,105121,105145,105142,105143,105011,104913},nil) --1771; Plate
s(1773,"Plate of the Prehistoric Marauder (Recolor)",{99415,105531,99412,99418,99410,99414,105509,105411},1)
s(1775,"Plate of the Prehistoric Marauder (Recolor)",{99047,105033,99038,99046,99033,99036,105011,104913},1)
s(578,"Redemption Armor",{30678,22430,22426,22428,22427,22429,22425,22424},nil) --578; Plate
s(582,"Redemption Battlegear",{39633,39634,39635,39636,39637,39235,39261,39369},2) --582; Plate
s(583,"Redemption Battlegear (Recolor)",{40574,40575,40576,40577,40578,40332,40241,40745},2) --582; Plate
s(591,"Reinforced Sapphirium Battlearmor",{60358,60357,60356,60355,60354,59497,58198,59450},2) --591; Plate
s(447,"Reinforced Sapphirium Battlearmor (Lookalike)",{55062,62365,67144,59509,59497,59450,59476,59216},nil) --591; Plate
s(1117,"Reinforced Sapphirium Battlearmor (Lookalike)",{65115,65067,65042,65031,65022,65137,65080,60234},nil) --591; Plate
s(592,"Reinforced Sapphirium Battlearmor (Recolor)",{65228,65227,65226,65225,65224,65127,65375,65080},2) --591; Plate
s(862,"Relentless Gladiator's Battlegear",{40790,40810,40829,40850,40870,40884},1) --862; Plate
s(940,"Relentless Gladiator's Desecration",{40791,40811,40830,40851,40871,40883,40890},32) --940; Plate
s(760,"Relentless Gladiator's Redemption",{40910,40928,40934,40940,40964,40984,40978,40979},2) --760; Plate
s(384,"Righteous Armor (Lookalike)",{44239,44121,34605,44296,28666,34612},nil) --760; Plate
s(865,"Ruthless Gladiator's Battlegear",{70254,70255,70256,70257,70258,70322,70326,70323},1) --865; Plate
s(866,"Ruthless Gladiator's Battlegear",{70477,70478,70479,70480,70481,70505},1) --866; Plate
s(943,"Ruthless Gladiator's Desecration",{72332,72333,72334,72335,72336,72394,72396,72398},32) --943; Plate
s(944,"Ruthless Gladiator's Desecration",{70490,70491,70492,70493,70494,70504},32) --944; Plate
s(763,"Ruthless Gladiator's Redemption",{70353,70354,70355,70356,70357,70334,70319,70324},2) --763; Plate
s(764,"Ruthless Gladiator's Redemption",{70415,70416,70417,70418,70419,70502},2) --764; Plate
s(1349,"Saronite War Battleplate (Lookalike)",{39395,39267,39239,44183,37171,43994,41392},nil) --764; Plate
s(959,"Saronite War Battleplate (Recolor)",{40590,40363,39703,40210,43989,40592,40298,40735},nil) --764; Plate
s(960,"Saronite War Battleplate (Recolor)",{97737,97723,97722,97724,97725,97735,97736},32) --764; Plate
s(961,"Saronite War Battleplate (Recolor)",{44006,41391,39726,40334,40446,40365,40734},nil)
s(502,"Scourgelord's Battlegear",{50094,50095,50096,50097,50098,51832,51879,51915},32) --502; Plate
s(441,"Scourgelord's Battlegear (Lookalike)",{51817,51835,51847,51917,51924,51832,51821,51915},nil) --502; Plate
s(442,"Scourgelord's Battlegear (Lookalike)",{50660,50640,50612,50681,50716,50659,50620,50639},nil) --502; Plate
s(503,"Scourgelord's Battlegear (Recolor)",{51125,51126,51127,51128,51129},32) --502; Plate
s(504,"Scourgelord's Battlegear (Recolor)",{51310,51311,51312,51313,51314,50659,50620,50639},32)
s(969,"Scourgelord's Frigid Battleplate",{50311,50234,49816,50284,49853,50229,49795,49797},nil) --969; Plate
s(970,"Scourgelord's Frigid Battleplate (Recolor)",{50272,50208,50230,50194,50305},nil) --969; Plate
s(1352,"Scourgelord's Frigid Battleplate (Recolor)",{49791,49808,49784,49819,49855},nil) --969; Plate
s(694,"Siegebreaker Battlegear",{45429,45430,45431,45432,45433},1) --694; Plate
s(431,"Siegebreaker Battlegear (Recolor)",{45487,45594,45502,45251,45334,45111,45139,45166},nil) --694; Plate
s(695,"Siegebreaker Battlegear (Recolor)",{45842,45834,46146,46149,46151,45825},1) --694; Plate
s(1118,"Siegebreaker Battlegear (Recolor)",{45560,45551,46340,45935,45697,46039,45708},nil) --694; Plate
s(1247,"Sorrow Plate",{72842,72861,72819,72803,72800,72818,72815},nil) --1247; Plate
s(1248,"Sorrow Plate (Recolor)",{72807,72817,72879,72864,72843,76154},nil) --1247; Plate
s(1249,"Sorrow Plate (Recolor)",{72853,76156,72881,72872,72821,72832,72820,72801},nil) --1247; Plate
s(596,"Soulforge Armor",{97779,97783,97782,97775,97785,97786,97787,22088},2) --596; Plate
s(420,"Sunwell Paladin Armor",{34216,34380,34401,34382,34389,34432,34487,34559},2) --420; Plate
s(1031,"Sunwell Paladin Armor (Recolor)",{35027,35028,35029,35030,35031,35155,35140},2) --420; Plate
s(421,"Sunwell Warrior Battlegear",{34215,34341,34345,34180,34388,34568,34442,34547},1) --421; Plate
s(1051,"Sunwell Warrior Battlegear (Recolor)",{40440,40441,40442,40443,40444,35161,35146},1) --421; Plate
s(500,"Thassarian's Battlegear",{47072,48486,48487,48488,48489,48490,90372,47935},32) --500; Plate
s(1009,"Thassarian's Battlegear (Lookalike)",{90372,47072,47591,90346,47121,47698,47234},nil) --500; Plate
s(586,"Turalyon's Battlegear",{48580,48581,48582,48583,48584,90371,47574,47207},2) --586; Plate
s(1003,"Turalyon's Battlegear (Lookalike)",{90371,90353,90344,47067,47702,47924,47098},nil) --586; Plate
s(1572,"Tyrannical Gladiator's Battleplate",{91299,91301,91305,91430,91432,91434,91436,91438},1) --1572; Plate
s(1573,"Tyrannical Gladiator's Battleplate (Recolor)",{100088,100110,100114,99992,99993,100118,100071,100084},1) --1572; Plate
s(1574,"Tyrannical Gladiator's Battleplate (Recolor)",{91300,91302,91431,91433,91435,91437,91439},1) --1572; Plate
s(1578,"Tyrannical Gladiator's Desecration",{99806,99807,99808,99809,99810,99886,99889,99891},32) --1578; Plate
s(1579,"Tyrannical Gladiator's Desecration (Recolor)",{94353,94364,94365,94366,94392,94429,94461,94487},32) --1578; Plate
s(1580,"Tyrannical Gladiator's Desecration (Recolor)",{91148,91150,91152,91154,91156,91298,91304},32) --1578; Plate
s(1575,"Tyrannical Gladiator's Redemption",{99870,99871,99872,99873,99874,99875,99877,99879},2) --1575; Plate
s(1576,"Tyrannical Gladiator's Redemption (Recolor)",{100130,100166,100165,100013,100133,100022,100134,100081},2) --1575; Plate
s(1577,"Tyrannical Gladiator's Redemption (Recolor)",{91268,91270,91272,91274,91276,91278,91282},2) --1575; Plate
s(498,"Valorous Darkruned Battlegear",{45340,45341,45342,45343,45344},32) --498; Plate
s(497,"Valorous Scourgeborne Battlegear",{40550,40552,40554,40556,40557,45825,40742},32) --497; Plate
s(754,"Vengeful Gladiator's Aegis",{33695,33696,33697,33698,33699,33888,33890},2) --754; Plate
s(856,"Vengeful Gladiator's Battlegear",{32341,32373,32608,33728,33732,33811,33812},1) --856; Plate
s(864,"Vicious Gladiator's Battlegear",{70623,70624,70625,70626,70627,70513,70574,70667},1) --864; Plate
s(991,"Vicious Gladiator's Battlegear",{60418,60419,60420,60421,60422,60512,60521,60513},1) --991; Plate
s(992,"Vicious Gladiator's Battlegear",{65580,65581,65582,65583,65584,65608},1) --992; Plate
s(704,"Vicious Gladiator's Desecration",{65593,65594,65595,65596,65597,65607},32) --704; Plate
s(942,"Vicious Gladiator's Desecration",{70558,70559,70560,70561,70562,70514,70573,70668},32) --942; Plate
s(993,"Vicious Gladiator's Desecration",{60408,60409,60410,60411,60412,60508,60509,60523},32) --993; Plate
s(762,"Vicious Gladiator's Redemption",{70615,70616,70617,70618,70619,70529,70540,70575},2) --762; Plate
s(980,"Vicious Gladiator's Redemption",{60601,60602,60603,60604,60605,60541,60505,60516},2) --980; Plate
s(981,"Vicious Gladiator's Redemption",{65518,65519,65520,65521,65522,65605},2) --981; Plate
s(689,"Warbringer Armor",{33524,30641,29012,29011,29017,29015,29016,28502},1) --689; Plate
s(1048,"Warbringer Armor (Recolor)",{24544,24549,24545,24547,24546,28385,28383},1) --689; Plate
s(1100,"Warlord's Aegis",{29612,29613,29614,29615,29616,29617},2) --1100; Plate
s(850,"Warlord's Battlegear",{16541,16542,16544,16545,16548,16543},1) --850; Plate
s(1462,"White Tiger Vestments",{87099,87100,87101,87102,87103,87184,87165,86999},2) --1462; Plate
s(1463,"White Tiger Vestments (Lookalike)",{89941,90516,86973,86999,87165,87184,87031,87078},nil) --1462; Plate
s(1465,"White Tiger Vestments (Recolor)",{86876,86659,86660,86662,86663,86846,86887,86902},2) --1462; Plate
s(1469,"White Tiger Vestments (Recolor)",{90445,85319,85320,85321,85322,85323,86188,86383},2) --1462; Plate
s(1765,"Winged Triumph Plate",{99136,105179,99137,99138,99139,99132,105178,105222},2) --1765; Plate
s(1766,"Winged Triumph Plate (Lookalike)",{103734,105775,105179,105804,105756,105802,105178,105222},nil) --1765; Plate
s(1768,"Winged Triumph Plate (Lookalike)",{105654,105428,105448,105477,105503,105655,105427,105471},nil) --1765; Plate
s(1770,"Winged Triumph Plate (Lookalike)",{105156,104930,105822,104979,105005,105157,104929,104973},nil) --1765; Plate
s(1767,"Winged Triumph Plate (Recolor)",{99387,105428,99380,99379,99377,99378,105427,105471},2)
s(1769,"Winged Triumph Plate (Recolor)",{99052,104930,99028,99029,99026,99076,104929,104973},2)
s(863,"Wrathful Gladiator's Battlegear",{51541,51542,51543,51544,51545,51364,51363},1) --863; Plate
s(941,"Wrathful Gladiator's Desecration",{51413,51414,51415,51416,51418,51364,51362,51363},32) --941; Plate
s(761,"Wrathful Gladiator's Redemption",{51468,51469,51470,51471,51473,51361,51359,51360},2) --761; Plate
s(696,"Wrynn's Battlegear",{48381,48382,48383,48384,48385,90373,46999},1) --696; Plate
s(1011,"Wrynn's Battlegear (Lookalike)",{90345,90355,90373,47944,47052,47002,47609},nil) --696; Plate
s(698,"Ymirjar Lord's Plate",{54564,50078,50079,50080,50081,50082,51563,51000},1) --698; Plate
s(478,"Ymirjar Lord's Plate (Lookalike)",{54564,50801,50811,50779,51025,51014,51782,50802},nil) --698; Plate
s(477,"Ymirjar Lord's Plate (Recolor)",{53125,50991,49903,50965,50977,49986,50003,49960},nil) --698; Plate
s(699,"Ymirjar Lord's Plate (Recolor)",{53125,50991,51210,51211,51212,51213,51214,50002},1) --698; Plate
s(929,"Ymirjar Lord's Plate (Recolor)",{51225,51226,51227,51228,51229},1)
s(1308,"Abalone Battleplate",{55792,55803,55848,55254,55784,55862,56104},nil) --1308; Plate
s(1309,"Abalone Battleplate (Recolor)",{55831,55249,55274,55867,56099,56124,63444},nil) --1308; Plate
s(1310,"Abalone Battleplate (Recolor)",{55797,55842,55229,55779,55856,56093,56118},nil) --1308; Plate
s(393,"Battlegear of Might (Recolor)",{27455,28207,27906,28324,27918,28375,27487,27788},nil) --1308; Plate
s(934,"Battlegear of Valor",{16736,16734,16735,16730,16737,16731,16732,16733},nil) --934; Plate
s(381,"Battlegear of Valor (Recolor)",{24463,24363,24387,25956,24091,24456,24064},nil) --934; Plate
s(403,"Battlegear of Wrath (Recolor)",{27520,27847,28262,28390,27459,27672,27527,27813},nil) --934; Plate
s(919,"Bold Armor",{44306,28205,27475,27977,27803,28350,29238},nil) --919; Plate
s(920,"Burning Rage",{23522,23521,23520,33173},nil) --920; Plate
s(848,"Champion's Battlearmor",{22868,22858,22872,22873,23244,23243,77861},1) --848; Plate
s(1102,"Champion's Redoubt",{29600,29601,29602,29603,29604,29605,33331},2) --1102; Plate
s(751,"Crusader's Ornamented Battlegear",{34700,35402,35404,35405,35406},2) --751; Plate
s(921,"Deathbone Guardian",{14624,14622,14620,14623,14621},nil) --921; Plate
s(1324,"Deathbone Guardian (Recolor)",{13394,29316,18722,21706,29783,18547},nil) --921; Plate
s(1325,"Deathbone Guardian (Recolor)",{11633,22672,18533,23533,14620,14621},nil) --921; Plate
s(1326,"Deathbone Guardian (Recolor)",{13070,21475,30964,21486},nil) --921; Plate
s(922,"Doomplate Battlegear",{34807,28403,27497,28225,27870,27771,27985},nil) --922; Plate
s(1264,"Exalted Plate (Recolor)",{31155,14901,13075,23510,23511,31714},nil) --922; Plate
s(748,"Field Marshal's Aegis",{16473,16474,16476,16472,16471,16475},2) --748; Plate
s(851,"Grand Marshal's Battlegear",{28699,28700,28701,28702,28703},1) --851; Plate
s(1518,"Hateshatter Battleplate",{87611,87593,87603,80908,87627,98251,98255,98257},nil) --1518; Plate
s(1519,"Hateshatter Battleplate (Recolor)",{87602,87594,87455,87433,87628,82958,82956,82952},nil) --1518; Plate
s(1520,"Hateshatter Battleplate (Recolor)",{87612,87589,87601,80915,87629,80924,82940,82942},nil) --1518; Plate
s(1708,"Heroic Plate (Recolor)",{19695,19693,31480,19694},nil) --1518; Plate
s(1709,"Heroic Plate (Recolor)",{14851,23513,23515,23514,13077,23518},nil)
s(750,"High Warlord's Aegis",{28831,28832,28833,28834,28835,27639},2) --750; Plate
s(1270,"Imbued Plate (Recolor)",{12618,12619,31232,22205},nil) --750; Plate
s(404,"Judgement Armor (Recolor)",{31460,27790,27539,27897,27457,27489,27748,28221},nil) --750; Plate
s(575,"Lawbringer Armor",{16858,16859,16857,16853,16860,16854,16855,16856},2) --575; Plate
s(392,"Lawbringer Armor (Recolor)",{27505,27844,28337,27798,27447,27755,27893,27884},nil) --575; Plate
s(847,"Lieutenant Commander's Battlearmor",{23300,23301,23286,23287,23314,23315,77659},1) --847; Plate
s(747,"Lieutenant Commander's Redoubt",{23272,23273,23274,23275,23276,23277},2) --747; Plate
s(595,"Lightforge Armor",{16723,16725,16722,16726,16724,16728,16729,16727},nil) --595; Plate
s(380,"Lightforge Armor (Recolor)",{24364,24458,25942,24021,24457,27408,27420},nil) --595; Plate
s(1410,"Malevolent Gladiator's Battleplate (Recolor)",{84435,84437,84439,84504,84505,84506,84507,84508},1) --595; Plate
s(1416,"Malevolent Gladiator's Desecration (Recolor)",{84372,84373,84374,84375,84376,84434,84436,84438},32) --595; Plate
s(1413,"Malevolent Gladiator's Redemption (Recolor)",{84418,84419,84420,84421,84422,84423,84425,84427},2)
s(1114,"Pyrium Battlegear",{70010,70005,70011,70004,70006,70007,70008,70009},nil) --1114; Plate
s(1113,"Pyrium Battlegear (Recolor)",{70018,70013,70019,70012,70014,70015,70016,70017},nil) --1114; Plate
s(1284,"Pyrium Battleplate (Recolor)",{66907,58106,58110,58108,58107,57915,62438},nil) --1114; Plate
s(1330,"Redpath Plate",{59401,65292,59404,65932,63672,62961,65955},nil) --1330; Plate
s(1331,"Redpath Plate (Recolor)",{66036,59440,64574,62998,65928},nil) --1330; Plate
s(927,"Righteous Armor",{28203,27535,28285,27839,27739,29253,29254},nil) --927; Plate
s(1263,"Saronite War Battleplate",{38667,38668,38669,38670,38661,38663,38665,38666},nil) --1263; Plate
s(860,"Savage Gladiator's Battlegear",{40778,40797,40816,40836,40856},1) --860; Plate
s(938,"Savage Gladiator's Desecration",{40779,40799,40817,40837,40857},32) --938; Plate
s(758,"Savage Gladiator's Redemption",{40898,40918,40930,40936,40960},2) --758; Plate
s(853,"Savage Plate Battlegear",{35407,35408,35409,35410,35411},1) --853; Plate
s(1178,"Savage Saronite Battlegear",{37795,41354,41353,41347,41351,41350,41352,41348},nil) --1178; Plate
s(1177,"Savage Saronite Battlegear (Recolor)",{42723,43184,42768,42724,42725,42726,42728,42729},nil) --1178; Plate
s(1350,"Savage Saronite Battlegear (Recolor)",{37782,37150,36969,44357,37115,35604,37790,41345},nil) --1178; Plate
s(1351,"Savage Saronite Battlegear (Recolor)",{37785,37743,43402,41344,42765,37783,41189,41355},nil) --1178; Plate
s(1262,"Acherus Knight's Battleplate",{34649,34651,34648,34652,34656,34655,34650,34653},nil) --1262; Plate
s(326,"Alabaster Plate",{8312,8318,8319,8317,8314,8316,8311,8315},nil) --326; Plate
s(315,"Alabaster Plate (Recolor)",{10087,10086,10088,10091,10092,10094,10089},nil) --326; Plate
s(318,"Alabaster Plate (Recolor)",{20650,8274,8277,8278,8279,8280,8281,8273},nil) --326; Plate
s(325,"Alabaster Plate (Recolor)",{10240,10244,10245,10238,10242,10243,10239},nil) --326; Plate
s(1545,"Amani Plate (Recolor)",{94211,94085,94089,94087,94091,94090,94086,94088},nil)
s(338,"Angro'rosh Plate",{24928,24926,24929,24931,24932,24927,24933},nil) --338; Plate
s(1182,"Angro'rosh Plate (Recolor)",{7933,7930,7919,7934,7921,7918,24981,24974},nil) --338; Plate
s(1071,"Artificial Gorilla Plate",{64612,59429,59390,53573,53582,64608,53568},nil) --1071; Plate
s(1070,"Artificial Gorilla Plate (Recolor)",{67221,64621,59379,59383,59424,59413,59371},nil) --1071; Plate
s(1277,"Artificial Gorilla Plate (Recolor)",{53576,64520,67188,64619,67200,53565,67193},nil) --1071; Plate
s(347,"Bloodfist Plate",{25000,24998,25001,24999,25003,25005},nil) --347; Plate
s(345,"Bloodfist Plate (Recolor)",{24982,24984,24989,24985,24983,24987},nil) --347; Plate
s(317,"Bloodforged Plate",{14956,14950,14948,14949,14953,14951},nil) --317; Plate
s(310,"Bloodforged Plate (Recolor)",{14821,14827,14826,14828,14829,14832},nil) --317; Plate
s(321,"Bloodforged Plate (Recolor)",{14844,14847,14846,14850,14848,14853},nil) --317; Plate
s(323,"Bloodforged Plate (Recolor)",{14958,14962,14959,14960,14957,14965},nil) --317; Plate
s(340,"Bloodscale Plate",{24949,24942,24944,24945,24947,24943},nil) --340; Plate
s(341,"Bogslayer Plate",{24950,24957,24952,24953,24954,24955,24956,24951},nil) --341; Plate
s(1501,"Brick Battleplate",{101127,101126,101125,101124,101123,101122,101121,101120},nil) --1501; Plate
s(1502,"Brick Battleplate (Recolor)",{101166,101165,101164,101158,101157,101156,101155,101153},nil) --1501; Plate
s(1503,"Brick Battleplate (Recolor)",{101309,101308,101307,101301,101300,101299,101298,101296},nil) --1501; Plate
s(313,"Chromite Plate",{8137,8138,8139,8140,8141,8143},nil) --313; Plate
s(307,"Chromite Plate (Recolor)",{8157,8158,8159,8160,8162,8156},nil) --313; Plate
s(309,"Chromite Plate (Recolor)",{9289,9286,9287,9288,9291,9292,9285},nil) --313; Plate
s(311,"Chromite Plate (Recolor)",{9973,9966,9972,9967,9968,9970,9971},nil) --313; Plate
s(1180,"Cobalt Battlegear",{39087,39088,39085,41975,39084,39086,39083,36370},nil) --1180; Plate
s(359,"Cobalt Battlegear (Recolor)",{72937,72938,72939,72940,72941,72942,72943,72944},1) --1180; Plate
s(1184,"Cobalt Battlegear (Recolor)",{72955,72956,72957,72958,72959,72960,72961,72962},2) --1180; Plate
s(1186,"Cobalt Battlegear (Recolor)",{72918,72919,72920,72921,72922,72923,72924,72925},32) --1180; Plate
s(349,"Conqueror's Plate",{25008,25009,25006,25007,25011,25013},nil) --349; Plate
s(1183,"Conqueror's Plate (Recolor)",{7936,7935,7927,7937,7926,7928},nil) --349; Plate
s(1086,"Contained Sorrow Battleplate",{63603,63569,63585,62938},nil) --1086; Plate
s(1084,"Contained Sorrow Battleplate (Recolor)",{63222,65323,65326,65338,63211},nil) --1086; Plate
s(335,"Exalted Plate",{30375,31690,31488,14975,14980,14981,14983},nil) --335; Plate
s(316,"Exalted Plate (Recolor)",{31473,14904,14908,14911,14910,14906,14909},nil) --335; Plate
s(333,"Exalted Plate (Recolor)",{14862,14866,14867,14868,14863,14865,14864,14869},nil) --335; Plate
s(1295,"Gateshattering Battleplate",{61436,61502,61454,61466,61430,61424,61463,55033},nil) --1295; Plate
s(365,"Gateshattering Battleplate (Recolor)",{55499,55508,55517,55526,55535,55544,55553,55495},nil) --1295; Plate
s(1298,"Gateshattering Battleplate (Recolor)",{57309,57323,57320,57349,57312,57342,57370},nil) --1295; Plate
s(1300,"Gateshattering Battleplate (Recolor)",{59717,59653,59693,59735,59621,59641,59756},nil) --1295; Plate
s(330,"Glorious Plate",{14966,14970,14971,14967,14972,14968,14974},nil) --330; Plate
s(324,"Glorious Plate (Recolor)",{14924,14928,14926,14922,14927,14923},nil) --330; Plate
s(327,"Glorious Plate (Recolor)",{14854,14859,14855,14856,14857,14861},nil) --330; Plate
s(337,"Grimscale Plate",{24918,24920,24921,24923,24919,24925},nil) --337; Plate
s(351,"Grimscale Plate (Recolor)",{25015,25021,25019,25018,25017,25020,25016,25014},nil) --337; Plate
s(1176,"Hardened Obsidium Battlegear",{63709,63712,63715,63748,63763,63770,63815,63850},nil) --1176; Plate
s(1293,"Hardened Obsidium Battleplate (Recolor)",{65858,65884,65852,65848,65837,65789,65871},nil) --1176; Plate
s(331,"Heroic Plate",{25948,25522,31581,31582,31578,31583,14936},nil) --331; Plate
s(1181,"Heroic Plate (Recolor)",{31209,23489,23487,23482,23484},nil) --331; Plate
s(332,"Imbued Plate",{10373,10368,10369,10371,10370,10375},nil) --332; Plate
s(334,"Imbued Plate (Recolor)",{10382,10378,10376,10380,10377},nil) --332; Plate
s(336,"Imbued Plate (Recolor)",{12631,10384,10387,10385,10389,10391},nil) --332; Plate
s(11830,"Imperial Plate",{31436,30002,12424,12425,12422,12427,12429},nil) --11830; Plate
s(319,"Jade Plate",{14918,14914,14915,14913,14917,14920},nil) --319; Plate
s(308,"Jade Plate (Recolor)",{14897,14903,14898,14900,14896,14895},nil) --319; Plate
s(314,"Jade Plate (Recolor)",{14838,14834,14835,14833,14839,14840},nil) --319; Plate
s(1658,"Justicar Armor (Recolor)",{29945,29944,32648},nil) --319; Plate
s(1085,"K'Vlar Battleplate",{55027,55028,55025,55032,55026,55030,63218,63198},nil) --1085; Plate
s(1088,"K'Vlar Battleplate (Recolor)",{63545,63557,62974,62950,33256,33258},nil) --1085; Plate
s(1664,"K'Vlar Battleplate (Recolor)",{63179,65298,56861,65314,57829},nil) --1085; Plate
s(1665,"K'Vlar Battleplate (Recolor)",{63651,63655,63006},nil) --1085; Plate
s(1504,"Mountainscaler Battleplate",{101141,101140,101139,101133,101132,101131,101130,101128},nil) --1504; Plate
s(1505,"Mountainscaler Battleplate (Recolor)",{101286,101285,101284,101283,101282,101281,101280,101279},nil) --1504; Plate
s(1506,"Mountainscaler Battleplate (Recolor)",{100984,100983,100982,100981,100980,100979,100978,100977},nil) --1504; Plate
s(1507,"Mountainscaler Battleplate (Recolor)",{101005,101004,101003,100997,100996,100995,100994,100992},nil) --1504; Plate
s(320,"Overlord's Plate",{22270,25788,10207,10203,10206,10208,10209,10202},nil) --320; Plate
s(370,"Redsteel Plate",{55032,55027,55028,55025,55026,55031,55030,55029},nil) --370; Plate
s(322,"Revenant Plate",{11787,31163,30258,10133,10130,10127},nil) --322; Plate
s(328,"Revenant Plate (Recolor)",{30371,31534,10171,10167,10164,10169},nil) --322; Plate
s(329,"Revenant Plate (Recolor)",{31428,10280,10275,10279,10281,10276,10282,10278},nil) --322; Plate
s(1185,"Revenant Plate (Recolor)",{43588,31459,12614,12610},nil) --322; Plate
s(1187,"Revenant Plate (Recolor)",{23524,12405,12409,12414,12408,18366},nil)
s(343,"Talonguard Plate",{24973,24968,24966,24969,24967,24971},nil) --343; Plate
s(1179,"Tempered Saronite Battlegear",{40669,40671,41116,40672,41114,40673,40674,40675},nil) --1179; Plate
s(356,"Tempered Saronite Battlegear (Recolor)",{36331,36333,36337,36334,36335,36336,36332,36338},nil) --1179; Plate
s(357,"Tempered Saronite Battlegear (Recolor)",{35670,36342,36341,36339,36344,36345,36340,36346},nil) --1179; Plate
s(312,"Warbringer's Plate",{14943,14941,14939,14942,14945,14940},nil) --312; Plate
s(353,"Warlord's Plate",{25024,25025,25022,25027,25029,25023},nil) --353; Plate
s(1541,"Zandalari Freethinker's Plate",{18380,21453,29959,30968,94041,94040,94039},nil) --1541; Plate
s(1540,"Zandalari Vindicator Plate",{94035,94032,94033,94030,94031,94043,94034},nil)--1540; Plate
