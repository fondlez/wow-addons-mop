local a,t=...
local s=t.AddMail
s(544,"Ahn'Kahar Blood Hunter's Battlegear",{54566,50114,50115,50116,50118,50789,50762,50812},4) --544; Mail
s(469,"Ahn'Kahar Blood Hunter's Battlegear (Lookalike)",{49901,50970,50979,50022,50413,49952,50071,50000},nil) --544; Mail
s(470,"Ahn'Kahar Blood Hunter's Battlegear (Lookalike)",{49901,50970,50979,51891,51877,51911,51853,51914},nil) --544; Mail
s(471,"Ahn'Kahar Blood Hunter's Battlegear (Lookalike)",{54566,50800,50812,50777,51002,51566,51325,50789},nil) --544; Mail
s(472,"Ahn'Kahar Blood Hunter's Battlegear (Lookalike)",{50689,50619,50673,50645,50688,50655,50605,50711},nil) --544; Mail
s(545,"Ahn'Kahar Blood Hunter's Battlegear (Recolor)",{49901,50970,50979,54577,51151,51153,51914,51935},4) --544; Mail
s(546,"Ahn'Kahar Blood Hunter's Battlegear (Recolor)",{51285,51286,51287,51288,51289,50655,50688,50711},4)
s(1059,"Amani Mail",{69603,69640,69580,69616,69561,69590,94216},nil) --1059; Mail
s(1060,"Amani Mail (Recolor)",{33464,33286,33533,33469,33535,94079,94083,94078},nil) --1059; Mail
s(1544,"Amani Mail (Recolor)",{33328,33528,33527,33529},nil) --1059; Mail
s(1546,"Amani Mail (Recolor)",{34912,34916,34914},nil) --1059; Mail
s(1517,"Azure Serpent Set (Recolor)",{93088,93090,93092,98181,98182,98184,98186,98188},nil) --1059; Mail
s(657,"Battlegear of the Raging Elements",{90572,60322,60320,60319,60318,59310,63535,62363},64) --657; Mail
s(485,"Battlegear of the Raging Elements (Lookalike)",{56538,56563,63505,59350,59324,59481,59510,59310},nil) --657; Mail
s(486,"Battlegear of the Raging Elements (Lookalike)",{65386,65004,65033,65055,65136,65114,65046,65068},nil) --657; Mail
s(658,"Battlegear of the Raging Elements (Recolor)",{65253,65252,65251,65250,65249,65068,65092,65033},64) --657; Mail
s(1759,"Battlegear of the Unblinking Vigil",{99167,105258,99168,99157,99158,99159,105779,105792},4) --1759; Mail
s(1760,"Battlegear of the Unblinking Vigil (Lookalike)",{105336,105258,105183,105809,105754,105800,105779,105792},nil) --1759; Mail
s(1762,"Battlegear of the Unblinking Vigil (Lookalike)",{104589,105507,105432,105638,105454,105639,105584,105617},nil) --1759; Mail
s(1764,"Battlegear of the Unblinking Vigil (Lookalike)",{105087,105009,105819,105140,104956,105141,105086,105119},nil) --1759; Mail
s(1761,"Battlegear of the Unblinking Vigil (Recolor)",{99405,105507,99406,99402,99403,99404,105584,105617},4) --1759; Mail
s(1763,"Battlegear of the Unblinking Vigil (Recolor)",{99085,105009,99086,99080,99081,99082,105086,105119},4) --1759; Mail
s(1274,"Beast Lord Armor (Recolor)",{28740,28519,44042,28599,44030},nil)
s(552,"Beastmaster Armor",{34799,97685,97643,97659,97651,9767,97667,22011},4) --552; Mail
s(1321,"Beaststalker Armor (Recolor)",{29520,29521,29519,31328},nil) --552; Mail
s(900,"Blessed Garb of the Undead Slayer",{43082,43081,43083,43080},nil) --900; Mail
s(813,"Brutal Gladiator's Earthshaker",{34373,34374,35044,35045,35046,35157,35142},64) --813; Mail
s(717,"Brutal Gladiator's Pursuit",{34390,34990,34991,34992,34993,35151,35136},4) --717; Mail
s(646,"Cataclysm Harness",{30043,30185,30189,30190,30192,30194,30030},64) --646; Mail
s(1041,"Cataclysm Harness (Recolor)",{32803,33805,32004,32005,32006,32007,32008},64) --646; Mail
s(407,"Cataclysm Raiment (Recolor)",{30097,30068,29921,29976,29991,30066,30047},nil) --646; Mail
s(1232,"Cataclysmic Gladiator's Earthshaker",{73517,73516,73515,73514,73513,73521,73507},64) --1232; Mail
s(1233,"Cataclysmic Gladiator's Earthshaker (Recolor)",{73675,73674,73673,73672,73671,73677},64) --1232; Mail
s(1230,"Cataclysmic Gladiator's Pursuit",{73584,73583,73582,73581,73580,73587,73590},4) --1230; Mail
s(1231,"Cataclysmic Gladiator's Pursuit (Recolor)",{73718,73717,73716,73714,73715,73720},4) --1230; Mail
s(1753,"Celestial Harmony Battlegear",{99663,99101,105161,99108,99109,99104,105784,105790},64) --1753; Mail
s(1754,"Celestial Harmony Battlegear (Lookalike)",{104797,105329,105161,105259,105404,105755,105784,105790},nil) --1753; Mail
s(1756,"Celestial Harmony Battlegear (Lookalike)",{105544,105578,105410,105508,105653,105470,105597,105598},nil) --1753; Mail
s(1758,"Celestial Harmony Battlegear (Lookalike)",{105080,104912,105820,105155,104972,105046,105099,105100},nil) --1753; Mail
s(1755,"Celestial Harmony Battlegear (Recolor)",{99346,99344,105410,99352,99353,99354,105597,105598},64) --1753; Mail
s(1757,"Celestial Harmony Battlegear (Recolor)",{98992,104912,99088,99089,99090,99091,105099,105100},64) --1753; Mail
s(534,"Cryptstalker Armor",{22440,22442,22441,22438,22437,22439,22436,22443},nil) --534; Mail
s(538,"Cryptstalker Battlegear",{39578,39579,39580,39581,39582,39278,39379,39236},4) --538; Mail
s(539,"Cryptstalker Battlegear (Recolor)",{40503,40504,40505,40506,40507,39702,39762,40746},4) --538; Mail
s(645,"Cyclone Harness",{30682,29038,29039,29040,29043,29042,28503,28567},64) --645; Mail
s(1040,"Cyclone Harness (Recolor)",{28629,28630,25997,26000,25998,26001,25999},64) --645; Mail
s(814,"Deadly Gladiator's Earthshaker",{41080,41136,41150,41198,41210,41074,41069,41064},64) --814; Mail
s(718,"Deadly Gladiator's Pursuit",{41086,41142,41156,41204,41216,41229,41234,41224},4) --718; Mail
s(535,"Demon Stalker Armor",{33280,29085,29081,29083,29082,29084,28454,28746},4) --535; Mail
s(1020,"Demon Stalker Armor (Recolor)",{28334,28335,28331,28332,28333,28450,28449},4) --535; Mail
s(1250,"Demonsbane Mail",{72841,72877,72816,72806,76161,72856,72850},nil) --1250; Mail
s(1251,"Demonsbane Mail (Recolor)",{72870,72834,72887,72859,72799,72848,76159,72875},nil) --1250; Mail
s(532,"Dragonstalker Armor",{16936,16935,16942,16940,16941,49319,16938,16937},4) --532; Mail
s(1275,"Dragonstalker Armor (Recolor)",{30739,28631,29515,29517,29516},nil) --532; Mail
s(648,"Earthshatter Battlegear",{39597,39601,39602,39603,39604,39307,39251,39189},64) --648; Mail
s(649,"Earthshatter Battlegear (Recolor)",{40520,40521,40522,40523,40524,40209,40327,40747},64) --648; Mail
s(709,"Field Marshal's Pursuit",{16466,16465,16468,16462,16463,16467},4) --709; Mail
s(549,"Flamewaker's Battlegear",{71050,71051,71052,71053,71054,71365,71255,71315},4) --549; Mail
s(451,"Flamewaker's Battlegear (Lookalike)",{69939,71315,71005,70736,71018,71255,71365,71030},nil) --549; Mail
s(492,"Flamewaker's Battlegear (Lookalike)",{71429,71442,71468,71417,71457,71561,71403},nil) --549; Mail
s(550,"Flamewaker's Battlegear (Recolor)",{71501,71502,71503,71504,71505,71561,71457},4) --549; Mail
s(654,"Frost Witch's Garb",{50830,50831,50832,50833,50834,50774,50784,51006},64) --654; Mail
s(466,"Frost Witch's Garb (Lookalike)",{49900,50202,50059,50971,50064,53488,51873,51929},nil) --654; Mail
s(467,"Frost Witch's Garb (Lookalike)",{50687,50671,50698,50723,50652,50626,50703},nil) --654; Mail
s(468,"Frost Witch's Garb (Lookalike)",{50784,50774,51792,51019,50797,51583,51006,51551},nil) --654; Mail
s(655,"Frost Witch's Garb (Recolor)",{51195,51196,51197,51198,51199,51929,51919,51873},64) --654; Mail
s(656,"Frost Witch's Garb (Recolor)",{51240,51241,51242,51243,51244,50687,50671,50652},64) --654; Mail
s(967,"Frostsworn Bone Mail",{50197,50233,50297,50304,50295,49836,50270,50209},nil) --967; Mail
s(968,"Frostsworn Bone Mail (Recolor)",{49804,49826,49837,49811,50283,49787},nil) --967; Mail
s(817,"Furious Gladiator's Earthshaker",{41081,41137,41151,41199,41211,41075,41070,41065},64) --817; Mail
s(721,"Furious Gladiator's Pursuit",{41087,41143,41157,41205,41217,41230,41235,41225},4) --721; Mail
s(531,"Giantstalker Armor",{16851,16849,16850,16845,16848,16852,16846,16847},4) --531; Mail
s(810,"Gladiator's Earthshaker",{25997,26000,25998,26001,25999,28639,28640},64) --810; Mail
s(714,"Gladiator's Pursuit",{28334,28335,28331,28332,28333,28450,28449},4) --714; Mail
s(1693,"Grievous Gladiator's Earthshaker",{103500,103499,103498,103497,103496,103495,103484,103482},64) --1693; Mail
s(1694,"Grievous Gladiator's Earthshaker (Recolor)",{102781,102774,102759,102718,102677,102665,102664,102655},64) --1693; Mail
s(1695,"Grievous Gladiator's Earthshaker (Recolor)",{100449,100451,100453,100455,100457,100441,100443},64) --1693; Mail
s(1690,"Grievous Gladiator's Pursuit",{103415,103413,103411,103416,103417,103418,103419,103420},4) --1690; Mail
s(1691,"Grievous Gladiator's Pursuit (Recolor)",{100614,100635,100636,100680,100683,100588,100589,102885},4) --1690; Mail
s(1692,"Grievous Gladiator's Pursuit (Recolor)",{100319,100321,100323,100325,100327,100309,100313},4) --1690; Mail
s(537,"Gronnstalker's Armor",{31004,31001,31003,31005,31006,32251,32346,32510},4) --537; Mail
s(1022,"Gronnstalker's Armor (Recolor)",{33664,33665,33666,33667,33668,33877,33878},4) --537; Mail
s(815,"Hateful Gladiator's Earthshaker",{44897,41079,41135,41149,41162,41209,41068,41063},64) --815; Mail
s(719,"Hateful Gladiator's Pursuit",{44898,41085,41141,41155,41203,41215,41233,41223},4) --719; Mail
s(1528,"Howling Beast Set",{90075,90074,90068,90069,90070,90071,90072,90073},4) --1528; Mail
s(1054,"Inferno Forged Mail",{13133,30773,30774,30772,30770},nil) --1054; Mail
s(547,"Lightning-Charged Battlegear",{90570,60306,60303,60307,60304,59355,63492,62385},4) --547; Mail
s(487,"Lightning-Charged Battlegear (Lookalike)",{90570,59346,59315,59472,59504,59222,59485,59355},nil) --547; Mail
s(488,"Lightning-Charged Battlegear (Lookalike)",{60230,65037,65063,65141,65120,65074,65132,65028},nil) --547; Mail
s(548,"Lightning-Charged Battlegear (Recolor)",{65204,65205,65206,65207,65208,65028,65368,65063},4) --547; Mail
s(1408,"Malevolent Gladiator's Earthshaker",{98889,98890,98892,98894,98895,98896,98897,98898},64) --1408; Mail
s(1409,"Malevolent Gladiator's Earthshaker (Recolor)",{84988,84997,85011,85029,85048,85075,85097},64) --1408; Mail
s(1405,"Malevolent Gladiator's Pursuit",{98814,98816,98818,98820,98821,98822,98823,98824},4) --1405; Mail
s(1406,"Malevolent Gladiator's Pursuit (Recolor)",{84994,85007,85020,85034,85061,85076,85095},4) --1405; Mail
s(811,"Merciless Gladiator's Earthshaker",{32803,32004,32005,32006,32007,32008,32792},64) --811; Mail
s(715,"Merciless Gladiator's Pursuit",{31960,31961,31962,31963,31964,32797,32785},4) --715; Mail
s(1650,"Naxxramas Icy Scale Mail",{43595,43593,23033,22967,22665,22666,22702},nil) --1650; Mail
s(652,"Nobundo's Battlegear",{48290,48291,48292,48293,48294,90370,47068,46991},64) --652; Mail
s(1013,"Nobundo's Battlegear (Lookalike)",{47686,90352,90370,47616,47068,47744,46991,47087},nil) --652; Mail
s(999,"Northrend Frozen Mail",{39182,39248,39397,39263,37407,39294},nil) --999; Mail
s(998,"Northrend Frozen Mail (Recolor)",{39391,39274,39217,37623,43996,37855,39405,37788},nil) --999; Mail
s(1000,"Northrend Frozen Mail (Recolor)",{40262,39724,44003,40201,40549,40543,40736},nil) --999; Mail
s(1001,"Northrend Frozen Mail (Recolor)",{40283,40288,40196,40302,40340,45184,40737},nil) --999; Mail
s(1313,"Ravenous Fiend Set",{44590,44182,44189,44109,47245,47244,47211,47561},68) --1313; Mail
s(1314,"Ravenous Fiend Set (Recolor)",{44592,44110,46074,47250,47178},64) --1313; Mail
s(1450,"Regalia of the Firebird",{87129,87130,87131,87132,87133,87183,86962,90515},64) --1450; Mail
s(1451,"Regalia of the Firebird (Lookalike)",{87143,89925,89927,89942,90515,86962,87183,87042},64) --1450; Mail
s(1453,"Regalia of the Firebird (Lookalike)",{87695,86818,86826,86900,90739,89979},nil) --1450; Mail
s(1457,"Regalia of the Firebird (Lookalike)",{89885,89835,89834,85821,86168,86319,86342},nil) --1450; Mail
s(1452,"Regalia of the Firebird (Recolor)",{86624,86625,86626,86627,86628,86826,86877,86900},64) --1450; Mail
s(1456,"Regalia of the Firebird (Recolor)",{85284,85285,85286,85287,85288,86342,86168,86319},64) --1450; Mail
s(818,"Relentless Gladiator's Earthshaker",{48994,41052,41082,41138,41152,41212,41076,41066},64) --818; Mail
s(722,"Relentless Gladiator's Pursuit",{48983,41088,41144,41158,41218,41231,41236,41226},4) --722; Mail
s(536,"Rift Stalker Armor",{30139,30140,30141,30142,30143,30026,30046,29951},4) --536; Mail
s(408,"Rift Stalker Armor (Recolor)",{30085,30054,30091,30046,29985,30045},nil) --536; Mail
s(1021,"Rift Stalker Armor (Recolor)",{31960,31961,31962,31963,31964,32797,32785},4) --536; Mail
s(821,"Ruthless Gladiator's Earthshaker",{72427,72428,72430,72432,72433,72434,72435,72436},64) --821; Mail
s(822,"Ruthless Gladiator's Earthshaker",{70456,70457,70458,70459,70460,70508},64) --822; Mail
s(725,"Ruthless Gladiator's Pursuit",{72362,72364,72366,72368,72369,72370,72371,72372},4) --725; Mail
s(726,"Ruthless Gladiator's Pursuit",{70434,70435,70440,70441,70476,70501},4) --726; Mail
s(1623,"Saurok Stalker Battlegear",{96626,96627,96628,96629,96630,95000,95009,96797},4) --1623; Mail
s(1624,"Saurok Stalker Battlegear (Lookalike)",{96798,96847,96867,95026,95000,96797,96744,96788},nil) --1623; Mail
s(1626,"Saurok Stalker Battlegear (Lookalike)",{94271,94272,95149,95197,95189,95999,96000,96122},nil) --1623; Mail
s(1628,"Saurok Stalker Battlegear (Lookalike)",{95731,95682,95751,95672,95627,95628,95972,95681},nil) --1623; Mail
s(1625,"Saurok Stalker Battlegear (Recolor)",{95255,95256,95257,95258,95259,96344,96054,96053},4) --1623; Mail
s(1627,"Saurok Stalker Battlegear (Recolor)",{95882,95883,95884,95885,95886,95972,95682,95681},4) --1623; Mail
s(540,"Scourgestalker Battlegear",{45360,45361,45362,45363,45364},4) --540; Mail
s(427,"Scourgestalker Battlegear (Recolor)",{45553,45562,45543,45143,45610,45444,45524,45454},nil) --540; Mail
s(456,"Scourgestalker Battlegear (Recolor)",{45711,45941,45679,45895,46019,46346},nil) --540; Mail
s(541,"Scourgestalker Battlegear (Recolor)",{45844,45836,46141,46143,46145,45827},4) --540; Mail
s(647,"Skyshatter Harness",{37155,31018,31011,31015,31024,30869,32258},64) --647; Mail
s(1042,"Skyshatter Harness (Recolor)",{33706,33707,33708,33709,33710,33895,33896},64) --647; Mail
s(412,"Skyshatter Raiment (Recolor)",{32241,32517,30887,35619},nil) --647; Mail
s(1617,"Spiritbreaker Regalia",{96684,96685,96686,96687,96688,94999,95008,96789},64) --1617; Mail
s(1618,"Spiritbreaker Regalia (Lookalike)",{96759,96831,96917,95027,96830,96789,96811,96881},nil) --1617; Mail
s(1620,"Spiritbreaker Regalia (Lookalike)",{94276,95150,95200,95188,96177,96242,96332,96045},nil) --1617; Mail
s(1622,"Spiritbreaker Regalia (Lookalike)",{95649,95643,95701,95765,95663,95695,95714,95673},nil) --1617; Mail
s(1619,"Spiritbreaker Regalia (Recolor)",{95310,95311,95312,95313,95314,96086,96015,96045},64) --1617; Mail
s(1621,"Spiritbreaker Regalia (Recolor)",{95940,95941,95942,95943,95944,95714,95643,95673},64) --1617; Mail
s(1203,"Spiritwalker's Battlegear",{77040,77038,76758,77036,76760,77183,77174},64) --1203; Mail
s(1253,"Spiritwalker's Battlegear (Lookalike)",{77151,77242,77125,77237,71988,77174,77163},nil) --1203; Mail
s(1204,"Spiritwalker's Battlegear (Recolor)",{78724,78435,78666,78691,78711,78370,78405},64) --1203; Mail
s(1205,"Spiritwalker's Battlegear (Recolor)",{78819,78761,78786,78806,78834,78385,78411},64) --1203; Mail
s(643,"Stormcaller's Garb",{23531,21372,21373,21374,21375,21376,21607},64) --643; Mail
s(533,"Striker's Garb",{21366,21365,21370,21368,21367,21599},4) --533; Mail
s(418,"Sunwell Hunter Armor",{34168,34228,34194,34343,34333,34549,34443,34570},4) --418; Mail
s(1023,"Sunwell Hunter Armor (Recolor)",{34390,34990,34991,34992,34993,35151,35136},4) --418; Mail
s(419,"Sunwell Shaman Harness",{34935,34229,34376,34332,34186,34208,34437,34566},64) --419; Mail
s(1043,"Sunwell Shaman Harness (Recolor)",{34373,34374,35044,35045,35046,35157,35142},64) --419; Mail
s(641,"The Earthfury",{16838,16837,16840,16841,16844,16839,16842,16843},64) --641; Mail
s(644,"The Earthshatterer",{22468,22470,22469,22466,22465,22467,22464,22471},nil) --644; Mail
s(662,"The Five Thunders",{97627,97625,97770,97626,97631,97630,97628,22095},64) --662; Mail
s(642,"The Ten Storms",{49329,16944,16943,16950,16945,16948,16949,16946},64) --642; Mail
s(653,"Thrall's Battlegear",{47687,48305,48306,48308,48309,90318,47580,47426},64) --653; Mail
s(1015,"Thrall's Battlegear (Lookalike)",{47687,90300,90309,90318,47860,47441,47893,47426},nil) --653; Mail
s(1569,"Tyrannical Gladiator's Earthshaker",{99911,99912,99914,99916,99917,99918,99919,99920},64) --1569; Mail
s(1570,"Tyrannical Gladiator's Earthshaker (Recolor)",{100004,100048,100145,100128,100100,100164,100012,100063},64) --1569; Mail
s(1571,"Tyrannical Gladiator's Earthshaker (Recolor)",{91351,91353,91359,91361,91363,91365,91367},64) --1569; Mail
s(1566,"Tyrannical Gladiator's Pursuit",{99841,99843,99845,99847,99848,99849,99850,99851},4) --1566; Mail
s(1567,"Tyrannical Gladiator's Pursuit (Recolor)",{99991,100029,100054,100074,100075,100076,100120,100123},4) --1566; Mail
s(1568,"Tyrannical Gladiator's Pursuit (Recolor)",{91213,91217,91223,91225,91227,91229,91231},4) --1566; Mail
s(1475,"Undergrowth Stalker Set",{90719,95522,89975,89825,89766,90906,89344,88883},nil) --1475; Mail
s(1476,"Undergrowth Stalker Set (Recolor)",{90723,95525,89977,89429,93266,86141,86745,85923},nil) --1475; Mail
s(1714,"Undergrowth Stalker Set (Recolor)",{101830,101831,101832,101833,101834,101835,101836,101837},nil) --1475; Mail
s(1715,"Undergrowth Stalker Set (Recolor)",{101838,101839,101840,101841,101842,101843,101844,101845},nil) --1475; Mail
s(812,"Vengeful Gladiator's Earthshaker",{33706,33707,33894,33386,33708,33709,33710,33896},64) --812; Mail
s(716,"Vengeful Gladiator's Pursuit",{33664,33665,33666,33667,33668,33877,33878},4) --716; Mail
s(820,"Vicious Gladiator's Earthshaker",{70590,70591,70592,70593,70594,70511,70640,70665},64) --820; Mail
s(987,"Vicious Gladiator's Earthshaker",{60433,60434,60435,60436,60437,60535,60567,60536},64) --987; Mail
s(988,"Vicious Gladiator's Earthshaker",{65559,65560,65561,65562,65563,65612},64) --988; Mail
s(724,"Vicious Gladiator's Pursuit",{70533,70534,70535,70536,70537,70595,70639,70669},4) --724; Mail
s(976,"Vicious Gladiator's Pursuit",{60423,60424,60425,60426,60427,60557,60564,60565},4) --976; Mail
s(977,"Vicious Gladiator's Pursuit",{65537,65538,65543,65544,65579,65604},4) --977; Mail
s(659,"Volcanic Vestments",{71305,71304,71303,71302,71301,71009,71254,71027},64) --659; Mail
s(450,"Volcanic Vestments (Lookalike)",{69941,71027,71042,71009,71340,71254,70985,71356},nil) --659; Mail
s(491,"Volcanic Vestments (Lookalike)",{71412,71451,71425,71464,71438,71437,71616},nil) --659; Mail
s(660,"Volcanic Vestments (Recolor)",{71547,71548,71549,71550,71551,71425,71451},64) --659; Mail
s(710,"Warlord's Pursuit",{16569,16571,16567,16565,16566,16568},4) --710; Mail
s(1527,"Windfury Set",{90127,90128,90129,90130,90131,90132,90133,90134},64) --1527; Mail
s(542,"Windrunner's Battlegear",{48260,48261,48262,48263,48264,90366,47074,47153},4) --542; Mail
s(1012,"Windrunner's Battlegear (Lookalike)",{90339,90348,90366,47829,47074,47153,47191},nil) --542; Mail
s(543,"Windrunner's Pursuit",{48265,48266,48267,48268,48269,90314,47989,47472},4) --543; Mail
s(1014,"Windrunner's Pursuit (Lookalike)",{90290,90296,90305,90314,47901,47442,47472},nil) --543; Mail
s(650,"Worldbreaker Battlegear",{45412,45413,45414,45415,45416},64) --650; Mail
s(651,"Worldbreaker Battlegear (Recolor)",{46200,46203,46205,46208,46212},64) --650; Mail
s(429,"Worldbreaker Garb (Recolor)",{45837,45563,45554,45544,45259,45474,45187},nil) --650; Mail
s(1120,"Worldbreaker Garb (Recolor)",{45828,45845,45687,46044,45288,45943,45701},nil) --650; Mail
s(819,"Wrathful Gladiator's Earthshaker",{51503,51504,51505,51506,51508,51375,51374,51376},64) --819; Mail
s(723,"Wrathful Gladiator's Pursuit",{51458,51459,51460,51461,51462,51351,51350,51352},4) --723; Mail
s(1206,"Wyrmstalker Battlegear",{77028,77029,77030,77031,77032,77241,77251},4) --1206; Mail
s(1252,"Wyrmstalker Battlegear (Lookalike)",{77150,77124,77321,77162,77241,71987,77251},nil) --1206; Mail
s(1207,"Wyrmstalker Battlegear (Recolor)",{78362,78661,78698,78709,78737,78447,78415},4) --1206; Mail
s(1208,"Wyrmstalker Battlegear (Recolor)",{78423,78455,78769,78793,78804,78832,78756},4) --1206; Mail
s(1448,"Yaungol Slayer Battlegear",{87002,87003,87004,87005,87006,87182,86985,86997},4) --1448; Mail
s(1449,"Yaungol Slayer Battlegear (Lookalike)",{86965,89920,89929,89940,90505,86985,89951,86997},nil) --1448; Mail
s(1788,"Yaungol Slayer Battlegear (Lookalike)",{86228,86204,89830,85831,90421,86343,86214,86189},nil) --1448; Mail
s(1789,"Yaungol Slayer Battlegear (Lookalike)",{86866,86855,86882,89955,86901,86861,86833,86847},nil) --1448; Mail
s(1454,"Yaungol Slayer Battlegear (Recolor)",{86634,86635,86636,86637,86638,86901,86861,86847},4) --1448; Mail
s(1455,"Yaungol Slayer Battlegear (Recolor)",{85294,85295,85296,85297,85298,86343,86214,86189},4) --1448; Mail
s(1515,"Azure Serpent Set",{87632,87610,87596,87592,87489,81085,81112,81185},nil) --1515; Mail
s(1516,"Azure Serpent Set (Recolor)",{87588,87600,87606,87630,81060,81069,81114,82820},nil) --1515; Mail
s(910,"Beast Lord Armor",{44671,28228,27474,28275,27801,29261,29262},nil) --910; Mail
s(551,"Beaststalker Armor",{16680,16675,16681,16677,16674,16678,16679,16676},nil) --551; Mail
s(379,"Beaststalker Armor (Recolor)",{27414,24366,24465,24090,24451,24360,24022,25941},nil) --551; Mail
s(903,"Black Dragon Mail",{29344,16984,15050,15051},nil) --903; Mail
s(905,"Bloodmail Regalia",{14614,14616,14615,14611,14612},nil) --905; Mail
s(210,"Brackwater Mail (Recolor)",{15487,15485,14147,31197},nil) --905; Mail
s(908,"Chain of the Scarlet Crusade",{10329,10332,10328,10331,10330,10333},nil) --908; Mail
s(708,"Champion's Pursuance",{22843,22862,23251,23252,22874,22875},4) --708; Mail
s(805,"Champion's Stormcaller",{29599,29598,22857,22867,22876,22887,77835},64) --805; Mail
s(1108,"Charscale Battlegear",{70044,70045,70046,70047,70048,70049,70050,70051},nil) --1108; Mail
s(1109,"Charscale Battlegear (Recolor)",{70036,70037,70038,70039,70040,70041,70042,70043},nil) --1108; Mail
s(909,"Desolation Battlegear",{31138,34614,27936,27528,28192,27713,28384},nil) --909; Mail
s(401,"Dragonstalker Armor (Recolor)",{27888,28344,27823,27745,27494,27541,28219,27915},nil) --909; Mail
s(1116,"Field Marshal's Earthshaker",{28698,28697,28576,28695,28694,29606},64) --1116; Mail
s(391,"Giantstalker Armor (Recolor)",{28215,39679,28306,28186,27521,27773,27450},nil) --1116; Mail
s(711,"Grand Marshal's Pursuit",{28613,28614,28615,28616,28617},4) --711; Mail
s(1272,"Gryphon Mail (Recolor)",{17767,15553,12624,17754},nil) --711; Mail
s(712,"High Warlord's Pursuit",{28805,28806,28807,28808,28809},4) --712; Mail
s(1534,"Lieutenant Commander's Earthshaker",{29597,29595,29594,29596,77642,77645},64) --1534; Mail
s(707,"Lieutenant Commander's Pursuance",{23292,23293,23278,23279,23306,23307,77612},4) --707; Mail
s(1407,"Malevolent Gladiator's Earthshaker (Recolor)",{84467,84468,84470,84472,84473,84474,84475,84476},64) --707; Mail
s(1404,"Malevolent Gladiator's Pursuit (Recolor)",{84402,84404,84406,84408,84409,84410,84411,84412},4) --707; Mail
s(962,"Mistshroud Set",{31570,31574,31575,31571,31572,31573},nil) --962; Mail
s(1386,"Mistshroud Set (Recolor)",{25696,25697,25695,30948,70115},nil) --962; Mail
s(816,"Savage Gladiator's Earthshaker",{41078,41134,41148,41160,41208},64) --816; Mail
s(720,"Savage Gladiator's Pursuit",{41084,41140,41154,41202,41214},4) --720; Mail
s(809,"Seer's Mail Battlegear",{28751,44248,28735,28520,35390},64) --809; Mail
s(1163,"Slayer's Mail (Recolor)",{25661,25659,25662,25660,19043,13179},nil) --809; Mail
s(713,"Stalker's Chain Battlegear",{35376,35377,35378,35379,35380,29261,29262},4) --713; Mail
s(1306,"Stilled Heart Mail",{55818,55832,55205,55269,55857,55887,56119},nil) --1306; Mail
s(1307,"Stilled Heart Mail (Recolor)",{55835,55195,55253,55263,55861,55997,56123},nil) --1306; Mail
s(1160,"Swiftarrow Battlegear",{37167,43442,43183,43444,43446,43445,43447,43448},nil) --1160; Mail
s(390,"The Earthfury (Recolor)",{27993,27454,28391,27793,28266,27845},nil) --1160; Mail
s(661,"The Elements",{16673,16670,16671,16667,16672,16668,16669,16666},nil) --661; Mail
s(378,"The Elements (Recolor)",{25955,25947,24357,24046,24388,27428},64) --661; Mail
s(402,"The Ten Storms (Recolor)",{31280,27759,27826,27912,28194,27835,27458,27549},nil) --661; Mail
s(1328,"Thousand Needles Mail",{63670,65957,62222,64573,65950},nil) --1328; Mail
s(1329,"Thousand Needles Mail (Recolor)",{65975,63021,65978,59400,67191},nil) --1328; Mail
s(1538,"Thousand Needles Mail (Recolor)",{88343,88277,88292,63677},nil) --1328; Mail
s(915,"Tidefury Raiment",{34791,28231,28349,27909,27802,29244,29245},nil) --915; Mail
s(806,"Warlord's Earthshaker",{16577,16578,16580,16573,16574,16579},64) --806; Mail
s(230,"Banded Mail",{9836,10409,9841,9839,9840,9837},nil) --230; Mail
s(232,"Banded Mail (Recolor)",{7418,7417,7423,7421,7422,7416},nil) --230; Mail
s(236,"Banded Mail (Recolor)",{18296,9864,9869,9866,9868,9871},nil) --230; Mail
s(1173,"Banded Mail (Recolor)",{5750,3482,2869,3483,10423,3481},nil) --230; Mail
s(1068,"Bear Oiled Chainmail",{88268,67203,67204,59416,53581,67218,59394},nil) --1068; Mail
s(1069,"Bear Oiled Chainmail (Recolor)",{64611,59423,67219,67217,53579,67225,59370},nil) --1068; Mail
s(1384,"Bear Oiled Chainmail (Recolor)",{64512,64599,64516,64527,67176,67212,64609,67180},nil) --1068; Mail
s(1385,"Bear Oiled Chainmail (Recolor)",{64610,64562,64523,67199,64607,64554,53564},nil) --1068; Mail
s(1167,"Black Dragon Mail (Recolor)",{23490,23491,23494},nil) --1068; Mail
s(247,"Blackforge Mail",{4465,4082,6426,6425,27652,18694,4733},nil) --247; Mail
s(249,"Blackforge Mail (Recolor)",{7539,7538,7543,7541,7546,7542,7545},nil) --247; Mail
s(1168,"Blackforge Mail (Recolor)",{4478,3847,6040,3837,3845,9366,3841},nil) --247; Mail
s(278,"Blood Knight Mail",{24862,30004,24869,24864,24865,24867},nil) --278; Mail
s(228,"Blood Knight Mail (Recolor)",{4071,4073,4072,6386,6387,4712},nil) --278; Mail
s(212,"Brackwater Mail",{3305,3306,3302},nil) --212; Mail
s(206,"Brackwater Mail (Recolor)",{15477,15479,26037,26035},nil) --212; Mail
s(208,"Brackwater Mail (Recolor)",{3283,3282,26036,26040,26034,26038},nil) --212; Mail
s(245,"Brigade Mail",{9926,9927,9928,9932,9930,9931,9933,9934},nil) --245; Mail
s(218,"Burnished Mail",{23406,2991,4697,2992,2990,2989},nil) --218; Mail
s(220,"Burnished Mail (Recolor)",{6573,6577,6578,6580,6574,6576},nil) --218; Mail
s(273,"Burnished Mail (Recolor)",{24822,24824,24829,24825,24823,24827,24828},nil) --218; Mail
s(283,"Burnished Mail (Recolor)",{24895,24896,24899,24894,24901,24897},nil) --218; Mail
s(240,"Chief Brigadier Mail",{6411,4079,6412,1988,4727,6413},nil) --240; Mail
s(234,"Combat Mail",{4074,6402,4076,4717,4075,6403},nil) --234; Mail
s(243,"Combat Mail (Recolor)",{9510,7493,7486,7489,7487},nil) --234; Mail
s(275,"Combat Mail (Recolor)",{9445,24845,24840,24839,24843,24838},nil) --234; Mail
s(1083,"Counterfeit Mail",{63606,63580,63548,63189,56877,65316,63564},nil) --1083; Mail
s(1080,"Counterfeit Mail (Recolor)",{65347,56905,65351,63232,63221,63225,65332},nil) --1083; Mail
s(1081,"Counterfeit Mail (Recolor)",{63210,65327,62994,63013,63654,65322},nil) --1083; Mail
s(1082,"Counterfeit Mail (Recolor)",{56873,63172,62943,63154,63661,63590,65295},nil) --1083; Mail
s(1662,"Crimson Mail Set",{30953,30772,30947,30952},nil) --1662; Mail
s(1332,"Dark Vessel Mail",{55923,65992,65968,59297,57851},nil) --1332; Mail
s(1096,"Dark Vessel Mail (Recolor)",{59309,57505,54912,55898},nil) --1332; Mail
s(1097,"Dark Vessel Mail (Recolor)",{55908,55901,55957,66034,57464,55893},nil) --1332; Mail
s(1099,"Dark Vessel Mail (Recolor)",{62174,54930,62184,62194,66017,65991},nil) --1332; Mail
s(1333,"Demon-Forged Mail",{59170,57460,56692,59215,29313,61127},nil) --1333; Mail
s(1334,"Demon-Forged Mail (Recolor)",{57427,59105,57491,29180,57479,56728},nil) --1333; Mail
s(1335,"Demon-Forged Mail (Recolor)",{18812,66003,59066,59069,59075,65714},nil) --1333; Mail
s(1336,"Demon-Forged Mail (Recolor)",{31516,56651,65705,65984,28177,59089},nil) --1333; Mail
s(1337,"Demon-Forged Mail (Recolor)",{56717,66030,59085,65987,15823,21705},nil) --1333; Mail
s(1294,"Earthen Mail",{59808,59659,59694,59705,59712,59736,59750},nil) --1294; Mail
s(1297,"Earthen Mail (Recolor)",{57381,57310,57351,57317,57295,57364,57313},nil) --1294; Mail
s(272,"Felstone Mail",{53436,24821,24817,24815,24819,24820,24814,24890},nil) --272; Mail
s(211,"Felstone Mail (Recolor)",{58499,53435,52939,9842,57578,14814,57406,52959},nil) --272; Mail
s(213,"Felstone Mail (Recolor)",{62862,6545,6551,6547,6546,6548,15580},nil) --272; Mail
s(274,"Felstone Mail (Recolor)",{24837,24830,24836,24832,24833,24831,24834,24835},64) --272; Mail
s(276,"Fenclaw Mail",{61119,30363,6459,24853,24849,24850,24851,24846},nil) --276; Mail
s(224,"Fenclaw Mail (Recolor)",{3212,3045,3049,4707,3047,3048},nil) --276; Mail
s(279,"Fenclaw Mail (Recolor)",{24877,24870,24872,24873,24871,24875,57446},nil) --276; Mail
s(1171,"Fenclaw Mail (Recolor)",{18494,4438,6350,2866,2865},nil) --276; Mail
s(1157,"Frostscale Binding",{38412,38413,38414,38415,38416,38424,38436,38440},nil) --1157; Mail
s(282,"Frostscale Binding (Recolor)",{36181,36186,36182,36180,36183,36184,36185,36179},nil) --1157; Mail
s(1158,"Frostscale Binding (Recolor)",{35662,35600,35571,35592,37592,38422,38417,38435},nil) --1157; Mail
s(1345,"Frostscale Binding (Recolor)",{35599,35672,39776,36946,37777,38034,39815,37425},nil) --1157; Mail
s(1169,"Green Iron Set",{25716,30295,3484,3835,3844,3842,7494},nil) --1169; Mail
s(250,"Green Iron Set (Recolor)",{14778,14783,14779,14782,14784,14786,14787},nil) --1169; Mail
s(267,"Green Iron Set (Recolor)",{6793,14811,14815,14816,14809,14817,14808},nil) --1169; Mail
s(252,"Gryphon Mail",{9388,28181,15619,15622,15625,15626,15627,15628},nil) --252; Mail
s(1663,"Hailwood Mail Set",{54995,52936,52907,52906},nil) --1663; Mail
s(1162,"Heavy Scorpid Set",{15082,15077,15078,15079,15076,94057},nil) --1162; Mail
s(1164,"Heavy Scorpid Set (Recolor)",{15082,8209,8205,8203,8204,8206},nil) --1162; Mail
s(133,"Insignia Garb",{8207,4057,4052,4054,6409,4055,6408,6410},nil) --133; Mail
s(257,"Ironhide Mail",{15640,15645,15646,15647,15644,15642,15641,15639},nil) --257; Mail
s(261,"Ironhide Mail (Recolor)",{14798,14799,14805,14803,14802,14807},nil) --257; Mail
s(1292,"Kavem's Mail",{65819,65853,65885,65881,65866,65838,65855},nil) --1292; Mail
s(298,"Kavem's Mail (Recolor)",{55623,55560,55587,55578,55596,55605,55614,55569},nil) --1292; Mail
s(1323,"Kavem's Mail (Recolor)",{63926,63875,63854,63767,63733,63728,63821},nil) --1292; Mail
s(238,"Knight's Mail",{6731,7455,7458,7457,7462,7461},nil) --238; Mail
s(265,"Magnificent Mail",{15669,15676,15672,15674,15673,15668},nil) --265; Mail
s(248,"Magnificent Mail (Recolor)",{25789,15609,15610,15612,15616,15614},nil) --265; Mail
s(268,"Magnificent Mail (Recolor)",{15680,15682,15685,15678,15679,15683},nil) --265; Mail
s(237,"Marauder's Mail",{27726,15565,15566,15570,15573,15567},nil) --237; Mail
s(277,"Marshcreeper Mail",{82885,24861,24854,24857,24859,24855},nil) --277; Mail
s(222,"Marshcreeper Mail (Recolor)",{3341,9810,9814,9811,9818,9815,9817},nil) --277; Mail
s(280,"Marshcreeper Mail (Recolor)",{24885,24878,24880,24881,24879,24882,24883,24884},nil) --277; Mail
s(260,"Merciless Mail",{15650,15651,15655,15654,15656,15694,15653,15649},nil) --260; Mail
s(253,"Merciless Mail (Recolor)",{25983,15629,15631,15634,15635,15637,15630,15638},nil) --260; Mail
s(263,"Merciless Mail (Recolor)",{17711,15660,15666,15658,15662,15663,15659},nil) --260; Mail
s(269,"Mercurial Mail",{11679,31454,10157,10162,10160,10163,10154,10155},nil) --269; Mail
s(254,"Mercurial Mail (Recolor)",{18458,9435,25702,8126,8129,8130},nil) --269; Mail
s(258,"Mercurial Mail (Recolor)",{13344,10193,10199,10192,10197,10191},nil) --269; Mail
s(259,"Mercurial Mail (Recolor)",{31156,31440,25782,31515,8269,8264},nil) --269; Mail
s(262,"Ornate Mail",{10118,10119,10124,10121,10122,10126},nil) --262; Mail
s(264,"Ornate Mail (Recolor)",{10230,10236,10234,10232,10233,10229},nil) --262; Mail
s(270,"Ornate Mail (Recolor)",{10265,10269,10270,10268,10273,10266},nil) --262; Mail
s(233,"Pillager's Mail",{15556,15555,15557,15554,15560,15561},nil) --233; Mail
s(256,"Protector Mail",{14788,14794,14789,14792,14796,14793},nil) --256; Mail
s(1170,"Radiant Set",{12416,12419,12415,12417,12418,12420},nil) --1170; Mail
s(255,"Radiant Set (Recolor)",{10082,10076,10077,10080,10081,10084},nil) --1170; Mail
s(266,"Radiant Set (Recolor)",{8303,8309,8307,8306,8305,8302},nil) --1170; Mail
s(244,"Ravager's Mail",{14768,14770,14773,14772,14769,14775},nil) --244; Mail
s(1172,"Runed Copper Set",{2857,2854,2864,3472,3473},nil) --1172; Mail
s(225,"Sentry's Mail",{15524,15529,15525,15527,15532,15528},nil) --225; Mail
s(241,"Sentry's Mail (Recolor)",{15591,15590,15598,15595,15596,15589},nil) --225; Mail
s(1166,"Sentry's Mail (Recolor)",{7916,7914,7917,7915,7913},nil) --225; Mail
s(227,"Slayer's Mail",{14750,14754,14757,14755,14756,14751},nil) --227; Mail
s(221,"Slayer's Mail (Recolor)",{14746,14743,25655,14744,14747,14748},nil) --227; Mail
s(231,"Slayer's Mail (Recolor)",{13255,15546,15551,15544,15549,15545},nil) --227; Mail
s(239,"Sparkleshell Mail",{15578,15582,15576,15581,15575,15577},nil) --239; Mail
s(246,"Sparkleshell Mail (Recolor)",{15601,15599,15607,15605,15600,15606},nil) --239; Mail
s(1498,"Stormscale Set",{85844,85841,85842,85843,85848,85847,85846,85845},nil) --1498; Mail
s(1497,"Stormscale Set (Recolor)",{101065,101064,101063,101062,101061,101060,101059,101058},nil) --1498; Mail
s(1499,"Stormscale Set (Recolor)",{82489,82507,84520,84511,82534,88068,82543,82516},nil) --1498; Mail
s(1500,"Stormscale Set (Recolor)",{83182,83218,83164,83191,83209,83200,83173,83227},nil) --1498; Mail
s(1159,"Swiftarrow Battlegear (Recolor)",{51997,51982,51981,51980,51978,44443,44444,36263},nil) --1498; Mail
s(1342,"Swiftarrow Battlegear (Recolor)",{72910,72911,72912,72913,72914,72915,72916,72917},4) --1498; Mail
s(1343,"Swiftarrow Battlegear (Recolor)",{35882,35578,38030,43459,37043,37845,36992,36999},nil)
s(1344,"Swiftarrow Battlegear (Recolor)",{72698,72699,72700,72701,72702,72703,72704,72705},64)
s(285,"Talhide Mail",{24906,24904,24903,24909,24905,24907,24908,24902},nil) --285; Mail
s(305,"Tsunami Mail",{56504,56498,56482,56494,56481,56490,56512,56508},nil) --305; Mail
s(1165,"Turtle Scale Set",{18530,23403,8198,8187},nil) --1165; Mail
s(271,"Unyielding Mail",{24808,24813,24809,24807,24810,24811,24812,24806},nil) --271; Mail
s(205,"Unyielding Mail (Recolor)",{2966,2965,9870,15523},nil) --271; Mail
s(207,"Unyielding Mail (Recolor)",{30342,25951,6337,6336,68753,68760,10083},nil) --271; Mail
s(216,"War Paint Mail",{14723,14722,14730,14726,14727,14725},nil) --216; Mail
s(214,"War Paint Mail (Recolor)",{15488,15493,15489,15491,15492,15495},nil) --216; Mail
s(217,"War Paint Mail (Recolor)",{15500,15497,15499,15502,15503,15498},nil) --216; Mail
s(219,"War Paint Mail (Recolor)",{15514,15511,15506,15509,15510,15507},nil) --216; Mail
s(223,"War Paint Mail (Recolor)",{15518,15515,15520,15521,15523,15516,15517},nil) --216; Mail
s(1191,"Warcaster's Scaled Links",{25694,30076,25482,25592,25523,25568},nil) --1191; Mail
s(251,"Warmonger's Mail",{9956,9961,9957,9963,9960,9962,9964,9965},nil) --251; Mail
s(229,"Wicked Chain Mail",{22195,31689,15535,15534,15536,15538},nil) --229; Mail
s(235,"Wicked Chain Mail (Recolor)",{14762,14761,14759,14760,14766,14764},nil) --229; Mail
s(1496,"Wild Plains Set",{101244,101243,101242,101241,101240,101239,101238,101237},nil) --1496; Mail
s(1494,"Wild Plains Set (Recolor)",{101261,101260,101259,101257,101256,101255,101254,101253},nil) --1496; Mail
s(1495,"Wild Plains Set (Recolor)",{101235,101234,101233,101231,101230,101229,101228,101227},nil) --1496 --1496 --1496 --1496; Mail
