local a,t=...
local s=t.AddCloth
s(603,"Absolution Regalia",{31061,31064,31067,31070,31065,32513,32519,30885},16) --603; Cloth
s(410,"Absolution Regalia (Recolor)",{32329,32273,32340,32353,34926},nil)  --603; Cloth
s(1034,"Absolution Regalia (Recolor)",{33717,33718,33719,33720,33721,33900,33902},16)  --603; Cloth
s(557,"Aldor Regalia",{29076,29080,29078,29079,29077,28477,28565,28517},128) --557; Cloth
s(1024,"Aldor Regalia (Recolor)",{25854,25855,25857,25856,25858,28409,28410},128)  --557; Cloth
s(1542,"Amani Regalia",{94066,94064,94067,33587,33585},nil) --1542; Cloth
s(1056,"Amani Regalia (Recolor)",{69578,69612,69797,69567},nil)  --1542; Cloth
s(1547,"Amani Regalia (Recolor)",{69550,33317,33453,33586,94029},nil)  --1542; Cloth
s(1648,"Amani Regalia (Recolor)",{69577,69598,69601},nil)  --1542; Cloth
s(553,"Arcanist Regalia",{16802,16799,16795,16800,16801,16796,16797,16798},128) --553; Cloth
s(386,"Arcanist Regalia (Recolor)",{28804,30925,28578,24263,28780},nil)  --553; Cloth
s(1322,"Arcanist Regalia (Recolor)",{27547,21869,21871,21870,28507},nil)  --553; Cloth
s(602,"Avatar Raiment",{30153,30152,30151,30154,30150,32516,30036,30035},16) --602; Cloth
s(1033,"Avatar Raiment (Recolor)",{32015,32016,32017,32018,32019,32979,32981},16)  --602; Cloth
s(681,"Balespider's Burning Vestments",{70989,71011,71041,69945,71285,71265,71023},256) --681; Cloth
s(682,"Balespider's Burning Vestments (Recolor)",{71435,71421,71407,71594,71598,71447},256)  --681; Cloth
s(1523,"Betrayer Regalia",{90138,90136,90137,90139,90141,90142,90143,90140},256) --1523; Cloth
s(867,"Blessed Regalia of Undead Cleansing",{43073,43074,43075,43072},nil) --867; Cloth
s(566,"Bloodmage's Regalia",{53118,50275,50276,50277,50278,50279,51007,50804},128) --566; Cloth
s(434,"Bloodmage's Regalia (Lookalike)",{53118,51554,51020,51790,51007,50782,50990,50804},nil)  --566; Cloth
s(435,"Bloodmage's Regalia (Lookalike)",{49891,50974,50983,49991,49994,49978,50062},nil)  --566; Cloth
s(567,"Bloodmage's Regalia (Recolor)",{49891,50974,50983,51155,51158,49994,49978,50062},128)  --566; Cloth
s(568,"Bloodmage's Regalia (Recolor)",{51280,51281,51282,51283,51284},128)  --566; Cloth
s(836,"Brutal Gladiator's Dreadgear",{35003,35004,35005,35006,35007,35153,35138},256) --836; Cloth
s(775,"Brutal Gladiator's Investiture",{35053,35054,35055,35056,35057,35159,35144},16) --775; Cloth
s(737,"Brutal Gladiator's Regalia",{35096,35097,35098,35099,35100,35164,35149},128) --737; Cloth
s(1242,"Cataclysmic Gladiator's Felshroud",{73483,73486,73487,73484,73485,73635,73638},256) --1242; Cloth
s(1243,"Cataclysmic Gladiator's Felshroud (Recolor)",{73656,73659,73660,73657,73658,73744},256)  --1242; Cloth
s(1240,"Cataclysmic Gladiator's Investiture",{73540,73541,73542,73543,73544,73634,73637},16) --1240; Cloth
s(1241,"Cataclysmic Gladiator's Investiture (Recolor)",{73686,73687,73688,73689,73685,73743},16)  --1240; Cloth
s(1238,"Cataclysmic Gladiator's Regalia",{73572,73575,73576,73573,73574,73636,73639},128) --1238; Cloth
s(1239,"Cataclysmic Gladiator's Regalia (Recolor)",{73709,73712,73713,73710,73711,73745},128)  --1238; Cloth
s(1723,"Chronomancer Regalia",{99152,105288,99160,99161,105212,105266,99153,99162},128) --1723; Cloth
s(1724,"Chronomancer Regalia (Lookalike)",{103802,105288,105364,105171,105212,105266,105215},nil)  --1723; Cloth
s(1726,"Chronomancer Regalia (Lookalike)",{105440,105613,105420,105537,105461,105515,105464},nil)  --1723; Cloth
s(1728,"Chronomancer Regalia (Lookalike)",{104942,105039,105115,104922,104963,105017,104966},nil)  --1723; Cloth
s(1725,"Chronomancer Regalia (Recolor)",{99400,99398,105537,99397,105461,105515,99401,99399},128)  --1723; Cloth
s(1727,"Chronomancer Regalia (Recolor)",{99078,105039,99083,99084,104963,105017,99079,99077},128)  --1723; Cloth
s(668,"Corruptor Raiment",{30211,30212,30213,30215,30214,30064,30050},256) --668; Cloth
s(406,"Corruptor Raiment (Recolor)",{30079,30056,30064,30050},nil)  --668; Cloth
s(1045,"Corruptor Raiment (Recolor)",{31973,31974,31975,31976,31977,32799,32787},256)  --668; Cloth
s(610,"Crimson Acolyte's Raiment",{50765,50766,50767,50768,50769,50785,50773,51380},16) --610; Cloth
s(436,"Crimson Acolyte's Raiment (Lookalike)",{50807,50988,51379,50785,51005,50773,51777,51380},nil)  --610; Cloth
s(437,"Crimson Acolyte's Raiment (Lookalike)",{50975,50984,50006,50449,50032,50063,49893},nil)  --610; Cloth
s(438,"Crimson Acolyte's Raiment (Lookalike)",{50661,50717,50686,50722,50702},nil)  --610; Cloth
s(439,"Crimson Acolyte's Raiment (Recolor)",{51896,51883,51851,51918,51874,51930,51823,51850},nil)  --610; Cloth
s(611,"Crimson Acolyte's Raiment (Recolor)",{50975,50984,51175,51177,51178,50032,50063,49893},16)  --610; Cloth
s(612,"Crimson Acolyte's Raiment (Recolor)",{51260,51261,51262,51263,51264,50686,50702},16) 
s(676,"Dark Coven's Regalia",{50240,50241,50242,50243,50244,51899},256) --676; Cloth
s(432,"Dark Coven's Regalia (Recolor)",{51837,51859,51813,51872,51921,51862,51882,51899},nil)  --676; Cloth
s(677,"Dark Coven's Regalia (Recolor)",{51205,51206,51207,51208,51209,50613},256)  --676; Cloth
s(678,"Dark Coven's Regalia (Recolor)",{51230,51231,51232,51233,51234,50651,50613,50699},256)  --676; Cloth
s(838,"Deadly Gladiator's Felshroud",{41992,41997,42004,42010,42016},256) --838; Cloth
s(776,"Deadly Gladiator's Investiture",{41853,41858,41863,41868,41873,41880,41892,41884},16) --776; Cloth
s(738,"Deadly Gladiator's Regalia",{41945,41951,41958,41964,41970,41897,41908,41902},128) --738; Cloth
s(672,"Deathbringer Garb",{45417,45419,45420,45421,45422},256) --672; Cloth
s(673,"Deathbringer Garb (Recolor)",{45848,46135,46136,46137,46140,45831},256)  --672; Cloth
s(684,"Deathmist Raiment (Recolor)",{97681,97662,97673,97653,97669,97638,97646,22071},256)  --672; Cloth
s(665,"Doomcaller's Attire",{21337,21338,21335,21334,21336,21611,21585},256) --665; Cloth
s(1522,"Elemental Triad Regalia",{90080,90086,90079,90081,90082,90083,90084,90085},128) --1522; Cloth
s(555,"Enigma Vestments",{21344,21347,21346,21343,21345,21582},128) --555; Cloth
s(1471,"Eternal Dynasty Regalia",{90721,95518,89966,85990,93271,86041,86151,88893},nil) --1471; Cloth
s(1472,"Eternal Dynasty Regalia (Recolor)",{90725,95517,89434,93270,89339,88741,89338,88892},nil)  --1471; Cloth
s(1712,"Eternal Dynasty Regalia (Recolor)",{101811,101812,101813,101814,101815,101816,101817,101818},nil)  --1471; Cloth
s(663,"Felheart Raiment",{16806,16804,16805,16810,16809,16807,16808,16803},256) --663; Cloth
s(767,"Field Marshal's Raiment",{17604,17603,17605,17608,17607,17602},16) --767; Cloth
s(729,"Field Marshal's Regalia",{16441,16444,16443,16437,16440,16442},128) --729; Cloth
s(825,"Field Marshal's Threads",{17581,17580,17583,17584,17579,17578},256) --825; Cloth
s(571,"Firehawk Robes of Conflagration",{71358,71343,71287,71288,71289,71350,71258,69954},128) --571; Cloth
s(572,"Firehawk Robes of Conflagration (Recolor)",{71461,71614,71508,71509,71510,71471},128)  --571; Cloth
s(569,"Firelord's Vestments",{90588,60246,60244,60245,60243,59475,54503,59234},128) --569; Cloth
s(443,"Firelord's Vestments (Lookalike)",{54506,67132,59454,59325,59219,59234,54503},nil)  --569; Cloth
s(479,"Firelord's Vestments (Lookalike)",{60237,65019,65054,65069,65383,65138},nil)  --569; Cloth
s(570,"Firelord's Vestments (Recolor)",{65213,65212,65211,65210,65209,65138,65069},128)  --569; Cloth
s(560,"Frostfire Garb",{39491,39492,39493,39494,39495,39252,39216,39273},128) --560; Cloth
s(561,"Frostfire Garb (Recolor)",{64643,40415,40416,40417,40419,40198,39735,40750},128)  --560; Cloth
s(556,"Frostfire Regalia",{22502,22503,22498,22501,22497,22496,22500,22499},nil) --556; Cloth
s(841,"Furious Gladiator's Felshroud",{41993,41998,42005,42011,42017,41898,41909,41903},256) --841; Cloth
s(779,"Furious Gladiator's Investiture",{41854,41859,41864,41869,41874,41881,41893,41885},16) --779; Cloth
s(741,"Furious Gladiator's Regalia",{41946,41953,41959,41965,41971},128) --741; Cloth
s(599,"Garments of the Oracle",{21349,21350,21348,21352,21351,21604,22730,21619},16) --599; Cloth
s(830,"Gladiator's Felshroud",{30186,30187,30188,30200,30201,28980,28982},256) --830; Cloth
s(772,"Gladiator's Investiture",{31409,31410,31411,31412,31413},16) --772; Cloth
s(734,"Gladiator's Regalia",{25854,25855,25857,25856,25858,28409,28410},128) --734; Cloth
s(1678,"Grievous Gladiator's Felweave",{103323,103324,103325,103326,103327,103158,103160,103155},256) --1678; Cloth
s(1679,"Grievous Gladiator's Felweave (Recolor)",{102952,102923,102922,102884,102879,102859,102858,102817},256)  --1678; Cloth
s(1680,"Grievous Gladiator's Felweave (Recolor)",{102992,102995,103123,103124,103125,103126,103127},256)  --1678; Cloth
s(1675,"Grievous Gladiator's Investiture",{103159,103156,103162,103265,103266,103267,103268,103269},16) --1675; Cloth
s(1676,"Grievous Gladiator's Investiture (Recolor)",{102615,102621,102622,102666,102671,102703,102709,102752},16)  --1675; Cloth
s(1677,"Grievous Gladiator's Investiture (Recolor)",{100406,100408,100410,100412,100414,100210,100216},16)  --1675; Cloth
s(1672,"Grievous Gladiator's Regalia",{100336,100334,100332,100330,100328,100205,100218,100211},128) --1672; Cloth
s(1673,"Grievous Gladiator's Regalia (Recolor)",{102932,102930,102912,102883,102881,102870,102864,102845},128)  --1672; Cloth
s(1674,"Grievous Gladiator's Regalia (Recolor)",{100329,100331,100333,100335,100337,100206,100212},128)  --1672; Cloth
s(675,"Gul'dan's Regalia",{47714,47317,47794,47796,47797,47447,47873},256) --675; Cloth
s(839,"Hateful Gladiator's Felshroud",{41991,42001,42003,42009,42015},256) --839; Cloth
s(777,"Hateful Gladiator's Investiture",{44900,41852,41857,41862,41867,41872,41877,41878},16) --777; Cloth
s(739,"Hateful Gladiator's Regalia",{44899,41944,41950,41957,41963,41969,41896,41907},128) --739; Cloth
s(1729,"Horned Nightmare Regalia",{99204,105190,99096,99097,105245,105320,99205,99098},256) --1729; Cloth
s(1730,"Horned Nightmare Regalia (Lookalike)",{104308,105190,105213,105246,105245,105320,103807,105267},nil)  --1729; Cloth
s(1732,"Horned Nightmare Regalia (Lookalike)",{105604,105439,105462,105495,105494,105569,105441,105516},nil)  --1729; Cloth
s(1734,"Horned Nightmare Regalia (Lookalike)",{105106,104941,105105,104997,104996,105071,104943,105018},nil)  --1729; Cloth
s(1731,"Horned Nightmare Regalia (Recolor)",{99416,105439,99424,99425,105494,105569,99417,99426},256)  --1729; Cloth
s(1733,"Horned Nightmare Regalia (Recolor)",{99056,104941,99053,99054,104996,105071,99045,99055},256)  --1729; Cloth
s(601,"Incarnate Raiment",{29055,29049,29054,29050,29053,28511,28652,28663},16) --601; Cloth
s(1032,"Incarnate Raiment (Recolor)",{31409,31410,31411,31412,31413},16)  --601; Cloth
s(1052,"Infernoweave Regalia",{22405,30762,30764,18809,30761,30763},nil) --1052; Cloth
s(674,"Kel'Thuzad's Regalia",{47788,47789,47790,47791,47792,90367,47861,47617},256) --674; Cloth
s(1105,"Kel'Thuzad's Regalia (Lookalike)",{90367,47603,47663,47617,47189},nil)  --674; Cloth
s(564,"Khadgar's Regalia",{47758,47759,47760,47761,47762,47143,47084},128) --564; Cloth
s(1104,"Khadgar's Regalia (Lookalike)",{90340,90349,47713,47143,47236,47084},nil)  --564; Cloth
s(562,"Kirin Tor Garb",{45365,45367,45368,45369,46131},128) --562; Cloth
s(422,"Kirin Tor Garb (Recolor)",{46013,45976,45566,45464,45557,45865,45291,45894},nil)  --562; Cloth
s(563,"Kirin Tor Garb (Recolor)",{45840,46129,46130,46133,46134},128)  --562; Cloth
s(1121,"Kirin Tor Garb (Recolor)",{45150,45186,45117,45508,45238,45258},nil)  --562; Cloth
s(1521,"Light Regalia",{90112,90110,90116,90115,90117,90113,90114,90111},16) --1521; Cloth
s(669,"Malefic Raiment",{31050,31051,31053,31054,31052,30888},256) --669; Cloth
s(1046,"Malefic Raiment (Recolor)",{33676,33677,33678,33679,33680,33882,33884},256)  --669; Cloth
s(1390,"Malevolent Gladiator's Felweave",{98769,98767,98764,98925,98924,98923,98922,98921},256) --1390; Cloth
s(1391,"Malevolent Gladiator's Felweave (Recolor)",{85005,85021,85035,85047,85069,85078,85093},256)  --1390; Cloth
s(1393,"Malevolent Gladiator's Investiture",{84816,84838,84863,84883,84908,84928,84956,91476},16) --1393; Cloth
s(1394,"Malevolent Gladiator's Investiture (Recolor)",{85006,85013,85039,85052,85072,85074,85094},16)  --1393; Cloth
s(1387,"Malevolent Gladiator's Regalia",{98829,98828,98827,98826,98825,98770,98766,98763},128) --1387; Cloth
s(1388,"Malevolent Gladiator's Regalia (Recolor)",{85004,85016,85031,85062,85068,85085,85092},128)  --1387; Cloth
s(832,"Merciless Gladiator's Dreadgear",{31973,31974,31975,31976,31977,32799,32787},256) --832; Cloth
s(773,"Merciless Gladiator's Investiture",{32015,32016,32017,32018,32019,32979,32981},16) --773; Cloth
s(735,"Merciless Gladiator's Regalia",{32047,32048,32049,32050,32051,32807,32795},128) --735; Cloth
s(613,"Mercurial Vestments",{60253,60254,60255,60256,60257,59322,62386,59508},16) --613; Cloth
s(444,"Mercurial Vestments (Lookalike)",{67147,67146,54505,54504,59337,59482,59508,59322},nil)  --613; Cloth
s(480,"Mercurial Vestments (Lookalike)",{65093,65135,65116,65043,65065,65376,65032},nil)  --613; Cloth
s(614,"Mercurial Vestments (Recolor)",{65238,65237,65236,65235,65234,65376,65116},16)  --613; Cloth
s(1649,"Naxxramas Glacial Regalia",{30271,43583,43585,31683,22658,22654,22700,22655},nil) --1649; Cloth
s(664,"Nemesis Raiment",{49315,16933,16927,16934,16928,16930,16931,16932},256) --664; Cloth
s(554,"Netherwind Regalia",{49318,16818,16918,16912,16917,16913,16915,16916},128) --554; Cloth
s(997,"Northrend Spellweave Regalia",{39295,37757,39242,37361,40697,39285,39408,47560},nil) --997; Cloth
s(994,"Northrend Spellweave Regalia (Recolor)",{39732,40555,40062,40740,40380,40561,39720,40558},nil)  --997; Cloth
s(995,"Northrend Spellweave Regalia (Recolor)",{40398,40247,40289,42101,40741,42111},nil)  --997; Cloth
s(996,"Northrend Spellweave Regalia (Recolor)",{39181,39176,39409,47226,39396,37884,40696},nil)  --997; Cloth
s(1656,"Oblivion Raiment (Recolor)",{44061,34607},nil)  --997; Cloth
s(964,"Palebone Regalia",{49834,49825,49796,49822},nil) --964; Cloth
s(963,"Palebone Regalia (Recolor)",{50298,50193,50266,49788,50314},nil)  --964; Cloth
s(670,"Plagueheart Garb",{39496,39497,39498,39499,39500},256) --670; Cloth
s(671,"Plagueheart Garb (Recolor)",{40420,40421,40422,40423,40424,40325,40301,40269},256)  --670; Cloth
s(666,"Plagueheart Raiment",{30668,22510,22511,22506,22505,22504,22508,22507},nil) --666; Cloth
s(604,"Regalia of Faith",{39514,39515,39517,39518,39519,39390,39190,39254},16) --604; Cloth
s(605,"Regalia of Faith (Recolor)",{40445,40447,40448,40449,40450,39731,39721,40751},16)  --604; Cloth
s(1717,"Regalia of Ternion Glory",{99110,105247,99121,99117,105193,105214,99111,99118},16) --1717; Cloth
s(1718,"Regalia of Ternion Glory (Lookalike)",{105270,105247,105169,105289,105193,105214,105170},nil)  --1717; Cloth
s(1720,"Regalia of Ternion Glory (Lookalike)",{105519,105496,105418,105538,105442,105463,105419},nil)  --1717; Cloth
s(1722,"Regalia of Ternion Glory (Lookalike)",{105021,104998,104920,105040,104944,104965,104921},nil)  --1717; Cloth
s(1719,"Regalia of Ternion Glory (Recolor)",{99357,105496,99359,99360,105442,105463,99358,99361},16)  --1717; Cloth
s(1721,"Regalia of Ternion Glory (Recolor)",{99004,104998,99019,99020,104944,104965,99005,99021},16)  --1717; Cloth
s(1429,"Regalia of the Burning Scroll",{87007,87008,87009,87010,87011,87177,86959,86958},128) --1429; Cloth
s(1430,"Regalia of the Burning Scroll (Lookalike)",{89947,89931,87174,87179,86959,86958,87027,87073},nil)  --1429; Cloth
s(1432,"Regalia of the Burning Scroll (Lookalike)",{90439,89883,86170,86311,86338,86389},nil)  --1429; Cloth
s(1434,"Regalia of the Burning Scroll (Lookalike)",{89982,86825,86828,86896,86908,82437,82438},nil)  --1429; Cloth
s(1431,"Regalia of the Burning Scroll (Recolor)",{85374,85375,85376,85377,85378,86338,86167,86170},128)  --1429; Cloth
s(1433,"Regalia of the Burning Scroll (Recolor)",{86714,86715,86716,86717,86718,86896,86825,86828},128)  --1429; Cloth
s(1581,"Regalia of the Chromatic Hydra",{94277,96060,96333,95260,95263,95261,95262,95264},128) --1581; Cloth
s(1582,"Regalia of the Chromatic Hydra (Lookalike)",{94277,95194,96027,96060,96091,96112,96184,96333},nil)  --1581; Cloth
s(1584,"Regalia of the Chromatic Hydra (Lookalike)",{96378,96463,96450,96399,96556,96484,96705,96432},nil)  --1581; Cloth
s(1586,"Regalia of the Chromatic Hydra (Lookalike)",{95634,95719,95706,95655,95812,95740,95961,95688},nil)  --1581; Cloth
s(1583,"Regalia of the Chromatic Hydra (Recolor)",{96634,96637,96450,96635,96636,96638,96705,96432},128)  --1581; Cloth
s(1585,"Regalia of the Chromatic Hydra (Recolor)",{95890,95891,95892,95893,95894,95961,95706,95688},128)  --1581; Cloth
s(615,"Regalia of the Cleansing Flame",{69944,71280,71279,71278,71277,71266,71357,69953},16) --615; Cloth
s(616,"Regalia of the Cleansing Flame (Recolor)",{71532,71533,71534,71535,71536,71613},16)  --615; Cloth
s(1593,"Regalia of the Thousand Hells",{95325,95326,95327,95328,95329,96335,96090,96080},256) --1593; Cloth
s(1594,"Regalia of the Thousand Hells (Lookalike)",{95183,95185,96007,96008,96080,96110,96143,96335},nil)  --1593; Cloth
s(1596,"Regalia of the Thousand Hells (Lookalike)",{95738,95668,95771,95635,95636,95718,95708,95963},nil)  --1593; Cloth
s(1598,"Regalia of the Thousand Hells (Lookalike)",{97079,96875,96854,96751,96824,96834,96752,96887},nil)  --1593; Cloth
s(1595,"Regalia of the Thousand Hells (Recolor)",{95708,95718,95963,95981,95982,95983,95984,95985},256)  --1593; Cloth
s(1597,"Regalia of the Thousand Hells (Recolor)",{96725,96726,96727,96728,96729,96834,95005,96824},256)  --1593; Cloth
s(842,"Relentless Gladiator's Felshroud",{41994,41999,42006,42012,42018},256) --842; Cloth
s(780,"Relentless Gladiator's Investiture",{48991,41855,41860,41870,41875,49179,49181,49183},16) --780; Cloth
s(742,"Relentless Gladiator's Regalia",{41947,41954,41960,41966,41972,41899,41910,41904},128) --742; Cloth
s(845,"Ruthless Gladiator's Felshroud",{72314,72317,72459,72460,72461,72462,72463,70363},256) --845; Cloth
s(846,"Ruthless Gladiator's Felshroud",{70425,70426,70427,70468,70469,70496},256) --846; Cloth
s(783,"Ruthless Gladiator's Investiture",{72315,72318,72405,72406,72407,72408,72409,70366},16) --783; Cloth
s(784,"Ruthless Gladiator's Investiture",{70450,70451,70452,70453,70475,70497},16) --784; Cloth
s(745,"Ruthless Gladiator's Regalia",{72313,72316,72373,72374,72375,72376,72377,70363},128) --745; Cloth
s(746,"Ruthless Gladiator's Regalia",{70454,70455,70461,70462,70463,70495},128) --746; Cloth
s(423,"Sanctification Garb (Recolor)",{46068,46012,45289,45927,45423,45694,46034,46050},nil)  --746; Cloth
s(424,"Sanctification Garb (Recolor)",{45558,45514,45135,45520,45497,45240,45468},nil)  --746; Cloth
s(606,"Sanctification Regalia",{45567,45386,45387,45388,45389,45390,45619},16) --606; Cloth
s(607,"Sanctification Regalia (Recolor)",{46188,46190,46193,46195,46197},16)  --606; Cloth
s(433,"Sanctified Dark Coven's Regalia (Lookalike)",{50643,50629,50651,50663,50613,50694,50699},nil)  --606; Cloth
s(1425,"Sha-Skin Regalia",{87187,87188,87189,87190,87191,86981,86969,86948},256) --1425; Cloth
s(1427,"Sha-Skin Regalia (Lookalike)",{86815,86836,86839,86857,86867,86313,86892},nil)  --1425; Cloth
s(1532,"Sha-Skin Regalia (Lookalike)",{89930,87051,87162,87169,86948,86989,87038,87052},nil)  --1425; Cloth
s(1426,"Sha-Skin Regalia (Recolor)",{86709,86710,86711,86712,86713,86857,86836,86815},256)  --1425; Cloth
s(1428,"Sha-Skin Regalia (Recolor)",{85369,85370,85371,85372,85373,86157,86178,86210},256)  --1425; Cloth
s(679,"Shadowflame Regalia",{59336,59449,59498,60252,60251,60211,59349,62450},256) --679; Cloth
s(680,"Shadowflame Regalia (Recolor)",{65126,65044,65263,65262,65260,65034},256)  --679; Cloth
s(574,"Sorcerer's Regalia",{97686,97642,97658,97649,97666,97677,97671,22063},128) --574; Cloth
s(565,"Sunstrider's Regalia",{47763,47764,47765,47766,47767,90315,47861,47855},128) --565; Cloth
s(1106,"Sunstrider's Regalia (Lookalike)",{47604,90315,90306,90289,47467,47487,47994},nil)  --565; Cloth
s(415,"Sunwell Mage Regalia",{34366,34364,34405,34393,34386,34574,34447,34557},128) --415; Cloth
s(1027,"Sunwell Mage Regalia (Recolor)",{35096,35097,35098,35099,35100,35164,35149},128)  --415; Cloth
s(414,"Sunwell Priest Vestments",{34367,34365,34339,34202,34170,34562,34527,34435},16) --414; Cloth
s(1035,"Sunwell Priest Vestments (Recolor)",{35053,35054,35055,35056,35057,35159,35144},16)  --414; Cloth
s(413,"Sunwell Warlock Raiment",{34340,34181,34232,34344,34210,34564,34436,34541},256) --413; Cloth
s(1047,"Sunwell Warlock Raiment (Recolor)",{35003,35004,35005,35006,35007,35153,35138},256)  --413; Cloth
s(559,"Tempest Regalia",{31056,31055,31058,31059,31057,32270,32239},128) --559; Cloth
s(1026,"Tempest Regalia (Recolor)",{33757,33758,33759,33760,33761,33912,33914},128)  --559; Cloth
s(1221,"Time Lord's Regalia",{71980,77159,76213,76216,76215,77255,77176},128) --1221; Cloth
s(1222,"Time Lord's Regalia (Recolor)",{78671,78701,78720,78748,78729,78391},128)  --1221; Cloth
s(1223,"Time Lord's Regalia (Recolor)",{78766,78796,78815,78843,78824,78398},128)  --1221; Cloth
s(558,"Tirisfal Regalia",{30038,30206,30205,30207,30210,30196,29918,30067},128) --558; Cloth
s(405,"Tirisfal Regalia (Recolor)",{30038,29986,30024,30107,29987,29972,30067,29918},nil)  --558; Cloth
s(1025,"Tirisfal Regalia (Recolor)",{32047,32048,32049,32050,32051,32807,32795},128)  --558; Cloth
s(1551,"Tyrannical Gladiator's Felweave",{91420,91422,91424,91426,91428,91111,91117,91121},256) --1551; Cloth
s(1552,"Tyrannical Gladiator's Felweave (Recolor)",{100046,100073,100068,100112,100111,100045,100141,99994},256)  --1551; Cloth
s(1553,"Tyrannical Gladiator's Felweave (Recolor)",{91421,91423,91425,91427,91429,91112,91118},256)  --1551; Cloth
s(1554,"Tyrannical Gladiator's Investiture",{99783,99786,99789,99893,99894,99895,99896,99897},16) --1554; Cloth
s(1555,"Tyrannical Gladiator's Investiture (Recolor)",{94397,94420,94419,94466,94468,94328,94425,94380},16)  --1554; Cloth
s(1556,"Tyrannical Gladiator's Investiture (Recolor)",{91120,91310,91312,91314,91316,91318,91114},16)  --1554; Cloth
s(1548,"Tyrannical Gladiator's Regalia",{91232,91234,91236,91238,91240,91122,91115,91109},128) --1548; Cloth
s(1549,"Tyrannical Gladiator's Regalia (Recolor)",{94400,94403,94389,94381,94451,94431,94362,94402},128)  --1548; Cloth
s(1550,"Tyrannical Gladiator's Regalia (Recolor)",{91233,91235,91237,91239,91241,91116,91110},128)  --1548; Cloth
s(608,"Velen's Raiment",{48029,48031,48033,48035,48037,90368,47208,47837},16) --608; Cloth
s(1103,"Velen's Raiment (Lookalike)",{90341,90350,90368,47715,47208,46973,47062},nil)  --608; Cloth
s(834,"Vengeful Gladiator's Dreadgear",{33676,33677,33678,33679,33680,33882,33884},256) --834; Cloth
s(774,"Vengeful Gladiator's Investiture",{33717,33718,33719,33720,33721,33900,33902},16) --774; Cloth
s(736,"Vengeful Gladiator's Regalia",{33757,33758,33759,33760,33761,33912,33914},128) --736; Cloth
s(1215,"Vestments of Dying Light",{76345,76348,76358,76346,76361,77187,77177},16) --1215; Cloth
s(1260,"Vestments of Dying Light (Lookalike)",{77121,77146,77323,77187,77157,77177,71981},nil)  --1215; Cloth
s(1216,"Vestments of Dying Light (Recolor)",{78461,78365,78750,78700,78722},16)  --1215; Cloth
s(1217,"Vestments of Dying Light (Recolor)",{78380,78466,78795,78817,78842},16)  --1215; Cloth
s(600,"Vestments of Faith",{22518,22519,22514,22517,22513,22512,22516,22515},nil) --600; Cloth
s(597,"Vestments of Prophecy",{16811,16813,16817,16812,16814,16816,16815,16819},16) --597; Cloth
s(387,"Vestments of Prophecy (Recolor)",{24264,21874,21875,21873,24261},nil)  --597; Cloth
s(1587,"Vestments of the Exorcist",{95295,95296,95297,95298,95299,96154,96039},16) --1587; Cloth
s(1588,"Vestments of the Exorcist (Lookalike)",{94280,95182,95193,95184,96337,96028,96079,96133},nil)  --1587; Cloth
s(1590,"Vestments of the Exorcist (Lookalike)",{95760,95637,95667,95689,95761,95707,95782,95656},nil)  --1587; Cloth
s(1592,"Vestments of the Exorcist (Lookalike)",{96898,97081,96753,96876,95031,96772,96823,96805},nil)  --1587; Cloth
s(1589,"Vestments of the Exorcist (Recolor)",{95925,95926,95927,95928,95929,98142,95782},16)  --1587; Cloth
s(1591,"Vestments of the Exorcist (Recolor)",{96669,96670,96671,96672,96673,94995,95004},16)  --1587; Cloth
s(1218,"Vestments of the Faceless Shroud",{76343,76342,76341,76339,76340,77234,77179},256) --1218; Cloth
s(1261,"Vestments of the Faceless Shroud (Lookalike)",{77147,77267,77122,77249,77179,77234},nil)  --1218; Cloth
s(1219,"Vestments of the Faceless Shroud (Recolor)",{78366,78681,78702,78721,78730,78449},256)  --1218; Cloth
s(1220,"Vestments of the Faceless Shroud (Recolor)",{78381,78776,78797,78816,78825,78457},256)  --1218; Cloth
s(1419,"Vestments of the Guardian Serpent",{87114,87115,87116,87117,87118,87161,89918,90510},16) --1419; Cloth
s(1420,"Vestments of the Guardian Serpent (Lookalike)",{89918,89924,87017,90510,89949,87161,86947},nil)  --1419; Cloth
s(1422,"Vestments of the Guardian Serpent (Lookalike)",{89953,89959,89984,86819,86850,86884},nil)  --1419; Cloth
s(1424,"Vestments of the Guardian Serpent (Lookalike)",{89829,89833,89887,86161,86192,86326,90408,85978},nil)  --1419; Cloth
s(1421,"Vestments of the Guardian Serpent (Recolor)",{86699,86700,86701,86702,86703,86884,89953,86850},16)  --1419; Cloth
s(1423,"Vestments of the Guardian Serpent (Recolor)",{85359,85360,85361,85362,85363,86326,89829,90524},16)  --1419; Cloth
s(618,"Vestments of the Virtuous",{97683,97657,97648,97674,97670,97641,97664,22079},16) --618; Cloth
s(598,"Vestments of Transcendence",{49316,16925,16926,16919,16920,16922,16924,16923},16) --598; Cloth
s(844,"Vicious Gladiator's Felshroud",{64745,64746,64747,64748,64749,70544,70549,70660},256) --844; Cloth
s(989,"Vicious Gladiator's Felshroud",{60478,60479,60480,60481,60482,60630,60634,60626},256) --989; Cloth
s(990,"Vicious Gladiator's Felshroud",{65528,65529,65530,65571,65572,65599},256) --990; Cloth
s(782,"Vicious Gladiator's Investiture",{60468,60469,60470,60471,60472,60637,60635,60636},16) --782; Cloth
s(982,"Vicious Gladiator's Investiture",{65553,65554,65555,65556,65578,65598},16) --982; Cloth
s(744,"Vicious Gladiator's Regalia",{64853,64854,64855,64856,64857,70661,70545},128) --744; Cloth
s(978,"Vicious Gladiator's Regalia",{60463,60464,60465,60466,60467,60628,60613,60612},128) --978; Cloth
s(979,"Vicious Gladiator's Regalia",{65557,65558,65564,65565,65566,65598},128) --979; Cloth
s(667,"Voidheart Raiment",{30673,33357,28963,28968,28966,28967,28964,28515},256) --667; Cloth
s(1044,"Voidheart Raiment (Recolor)",{30186,30187,30188,30200,30201,28980,28982},256)  --667; Cloth
s(768,"Warlord's Raiment",{17623,17625,17622,17624,17618,17620},16) --768; Cloth
s(730,"Warlord's Regalia",{16536,16533,16535,16539,16540,16534},128) --730; Cloth
s(826,"Warlord's Threads",{28759,17586,17588,17593,17590,17592},256) --826; Cloth
s(1258,"Whisperwind Regalia",{76158,76152,72883,72825,72858,72802,72813},nil) --1258; Cloth
s(1259,"Whisperwind Regalia (Recolor)",{72852,72851,72839,72865,72826,72836},nil)  --1258; Cloth
s(843,"Wrathful Gladiator's Felshroud",{51536,51537,51538,51539,51540,51329,51338},256) --843; Cloth
s(781,"Wrathful Gladiator's Investiture",{51337,51482,51483,51484,51485,51486,51367,51366},16) --781; Cloth
s(743,"Wrathful Gladiator's Regalia",{51463,51464,51465,51466,51467,51339,51328,51327},128) --743; Cloth
s(609,"Zabra's Raiment",{48057,48058,48059,48060,48061,47485,47909,49232},16) --609; Cloth
s(1107,"Zabra's Raiment (Lookalike)",{90307,90298,90288,47716,47485,47419,47454},nil)  --609; Cloth
s(1301,"Anraphet's Regalia",{55878,56105,57860,55793,55849,55198,55786},nil) --1301; Cloth
s(1302,"Anraphet's Regalia (Recolor)",{55876,55993,55998,57864,55255,67237,66892},nil)  --1301; Cloth
s(1303,"Anraphet's Regalia (Recolor)",{55278,55817,56133,55275,57280},nil)  --1301; Cloth
s(61,"Arcane Regalia",{8283,8289,8284},nil) --61
s(53,"Arcane Regalia (Recolor)",{10057,17603,10059,10062,20054},16)  --61
s(1371,"Arcane Regalia (Recolor)",{10044,7051,13008},nil)  --61
s(385,"Arcanist Regalia (Recolor)",{27488,27816,28252,27764,27746,27742,28212,27848},nil)  --61
s(1364,"Aurora Regalia (Recolor)",{4035,11310},nil)  --61
s(1670,"Aurora Regalia (Recolor)",{82891,22234},nil)  --61
s(728,"Champion's Arcanum",{22870,22860,23263,23264,22883,22886,77786},128) --728; Cloth
s(824,"Champion's Dreadgear",{22865,22855,23255,23256,22881,22884,16486},256) --824; Cloth
s(766,"Champion's Investiture",{22869,22859,22882,22885,23261,23262},16) --766; Cloth
s(683,"Dreadmist Raiment",{16702,16703,16699,16701,16700,16704,16698,16705},nil) --683; Cloth
s(829,"Dreadweave Battlegear",{44593,28726,28744,35328,35332,44202},256) --829; Cloth
s(1110,"Embersilk Battlegear",{54495,54496,54497,54498,54499,54500,54501,54502},nil) --1110; Cloth
s(1111,"Embersilk Battlegear (Recolor)",{54487,54488,54489,54490,54491,54492,54493,54494},nil)  --1110; Cloth
s(1278,"Embersilk Battlegear (Recolor)",{58155,58157,58153,58158,57921,58154},nil)  --1110; Cloth
s(733,"Evoker's Silk Battlegear",{44116,44180,35343,35344,35347},128) --733; Cloth
s(1508,"Firewool Regalia",{98199,98198,98197,98196,98195,98194,98193,98192},nil) --1508; Cloth
s(1509,"Firewool Regalia (Recolor)",{87590,82421,82422,82423,82424,82426,82427,82428},nil)  --1508; Cloth
s(1510,"Firewool Regalia (Recolor)",{81699,82848,87586,82430,82431,82432,82434,82436},nil)  --1508; Cloth
s(1353,"Frostsavage Battlegear (Recolor)",{43859,42758,42760,37655,36973,35682,37637,37876},nil)  --733; Cloth
s(1354,"Frostsavage Battlegear (Recolor)",{72644,72643,72642,72641,72640,72639,72638,35654},256)  --733; Cloth
s(1381,"Gossamer Regalia",{7523,7518,24255},nil) --1381; Cloth
s(1654,"Gossamer Regalia (Recolor)",{30762,22730,8250},nil)  --1381; Cloth
s(1276,"Gossamer Regalia (Recolor)",{30928,30929,28075},nil)  --1381; Cloth
s(1652,"Gossamer Regalia (Recolor)",{10210,19399,30932,21489},nil) --1381; Cloth
s(1653,"Gossamer Regalia (Recolor)",{16980,7054,31199},nil) --1381; Cloth
s(1655,"Gossamer Regalia (Recolor)",{31158,19849,22306,22303,28179},256) --1381; Cloth
s(874,"Hallowed Raiment",{44668,44302,28413,27536,27775,27875,29251},nil) --874; Cloth
s(770,"High Warlord's Investiture",{31626,31627,31621,31628,31629},16) --770; Cloth
s(876,"Incanter's Regalia",{44309,28278,27508,27738,28229,27838,29258},nil) --876; Cloth
s(1101,"Ironweave Battlesuit",{22306,22311,22313,22302,22304,22305,22303,22301},400) --1101; Cloth
s(1373,"Ivycloth Regalia (Recolor)",{2292,7684,4827},nil)  --1101; Cloth
s(1374,"Ivycloth Regalia (Recolor)",{29954,18450,18405},nil)  --1101; Cloth
s(1535,"Koegler's Regalia",{88340,88345,88350,88359,88269,88279},nil) --1535; Cloth
s(727,"Lieutenant Commander's Arcanum",{77619,23304,23305,23290,23291,23319,18456},128) --727; Cloth
s(823,"Lieutenant Commander's Dreadgear",{77652,23296,23297,23282,23283,23311},256) --823; Cloth
s(765,"Lieutenant Commander's Investiture",{77629,23302,23303,23288,23289,23317},16) --765; Cloth
s(1127,"Mageweave Regalia",{29117,31442,10026,13525,31531},nil) --1127; Cloth
s(1268,"Mageweave Regalia (Recolor)",{21888,13869,29928,31452,28491},128)  --1127; Cloth
s(573,"Magister's Regalia",{16685,16683,16686,16684,16687,16689,16688,16682},nil) --573; Cloth
s(374,"Magister's Regalia (Recolor)",{24024,24481,24450,24392,24395,24359,25957},nil)  --573; Cloth
s(1389,"Malevolent Gladiator's Felweave (Recolor)",{84354,84357,84359,84499,84500,84501,84502,84503},256)  --573; Cloth
s(1392,"Malevolent Gladiator's Investiture (Recolor)",{84355,84358,84361,84440,84441,84442,84443,84444},16)  --573; Cloth
s(1533,"Malevolent Gladiator's Regalia (Recolor)",{84353,84356,84360,84413,84414,84415,84416,84417},128)  --573; Cloth
s(877,"Mana-Etched Regalia",{28612,28756,27465,27907,28191,27843,28406},nil) --877; Cloth
s(771,"Mooncloth Battlegear",{44062,34793,35333,35334,35335,35336},16) --771; Cloth
s(878,"Necropile Raiment",{14631,14629,14632,14633,14626},nil) --878; Cloth
s(394,"Nemesis Raiment (Recolor)",{27781,27994,27799,27493,27462,27795,28338,27821},nil)  --878; Cloth
s(395,"Netherwind Regalia (Recolor)",{27466,28374,27824,28317,27517,27768,28185,27902},400)  --878; Cloth
s(879,"Oblivion Raiment",{27537,28415,28232,27778,27948,29241,29242},nil) --879; Cloth
s(840,"Savage Gladiator's Felshroud",{41990,41996,42002,42008,42014},256) --840; Cloth
s(778,"Savage Gladiator's Investiture",{41847,41848,41849,41850,41851},16) --778; Cloth
s(740,"Savage Gladiator's Regalia",{41943,41949,41956,41962,41968},128) --740; Cloth
s(881,"The Postmaster",{22256,13390,13388,13391,13389},nil) --881; Cloth
s(617,"Vestments of the Devout",{16696,16691,16697,16693,16692,16695,16694,16690},nil) --617; Cloth
s(375,"Vestments of the Devout (Recolor)",{27410,27433,24397,24083,27411},nil)  --617; Cloth
s(396,"Vestments of Transcendence (Recolor)",{27866,28250,27506,28304,27452,27542,28218,27919},nil)  --617; Cloth
s(983,"Vicious Gladiator's Investiture",{64795,64796,64797,64798,64799,70548,70662,70546},16) --983; Cloth
s(1188,"Windchanneller's Regalia",{31558,31557,31559,31556,31553,31554},nil) --1188; Cloth
s(1711,"Windchanneller's Regalia (Recolor)",{21862,21859,24251},nil)  --1188; Cloth
s(51,"Abjurer's Regalia",{9936,9939,9942,9945,9946,9937},nil) --51
s(37,"Abjurer's Regalia (Recolor)",{21500,52921,52918,59539,57523,24249},nil)  --51
s(84,"Abjurer's Regalia (Recolor)",{52584,4708,69221,58915,59008,9821},nil)  --51
s(11,"Aboriginal Regalia",{14117,14113,14114,14119,14121},nil) --11
s(4,"Aboriginal Regalia (Recolor)",{3291,3292},nil)  --11
s(8,"Aboriginal Regalia (Recolor)",{3310,3309,3307,3308,4687,3644},nil)  --11
s(1376,"Apothecary's Regalia",{66012,14223},nil) --1376; Cloth
s(1377,"Apothecary's Regalia (Recolor)",{57426,7435},nil)  --1376; Cloth
s(1378,"Apothecary's Regalia (Recolor)",{7367,59212},nil)  --1376; Cloth
s(1379,"Apothecary's Regalia (Recolor)",{9850,9852},nil)  --1376; Cloth
s(54,"Arachnidian Regalia",{14288,14291,14290,14289,14294,14295},nil) --54
s(50,"Arachnidian Regalia (Recolor)",{14446,14439,14438,14444,14443,14442,14437,8115},nil)  --54
s(67,"Arcane Regalia (Recolor)",{21855,21852,21853},nil)  --54
s(76,"Astralaan Regalia",{24646,24645,24652,24648,24649,24650,24647,24651},nil) --76
s(1363,"Aurora Regalia",{52927,4729,4041},nil) --1363; Cloth
s(1365,"Aurora Regalia (Recolor)",{4476,14212,4328},nil)  --1363; Cloth
s(1366,"Aurora Regalia (Recolor)",{5770,4718,7526},nil)  --1363; Cloth
s(46,"Bloodwoven Regalia",{30398,14260,14258,14267,14262,14264},256) --46
s(44,"Bloodwoven Regalia (Recolor)",{13101,14435,14429,14431,14433,14427},nil)  --46
s(48,"Bloodwoven Regalia (Recolor)",{14276,14268,14272,14274,14269,14277},128)  --46
s(52,"Bloodwoven Regalia (Recolor)",{14286,14285,14279,14282,14283,14287},16)  --46
s(56,"Bloodwoven Regalia (Recolor)",{10023,14448,14454,14447,14455,15119},128)  --46
s(58,"Bonecaster's Regalia",{14301,14304,14299,14302,14305,14306},nil) --58
s(60,"Bonecaster's Regalia (Recolor)",{14311,14309,14314,14315,14310,14317},nil)  --58
s(62,"Bonecaster's Regalia (Recolor)",{14323,14324,14319,14327,14320,14326},nil)  --58
s(64,"Bonecaster's Regalia (Recolor)",{14458,14465,14457,14461,14462,14464},nil)  --58
s(65,"Bonecaster's Regalia (Recolor)",{14333,14334,14329,14330,14337,14336},nil)  --58
s(20,"Bright Regalia",{3067,4708,3066,3065,3647,6608},nil) --20
s(14,"Buccaneer's Regalia",{14171,14173,14174,14166,14175},nil) --14
s(1126,"Buccaneer's Regalia (Recolor)",{7048,4324,7046},nil)  --14
s(1129,"Buccaneer's Regalia (Recolor)",{7058,14171,7055},nil)  --14
s(32,"Conjurer's Regalia",{9851,9848,9846,9845,9853,9844},nil) --32
s(22,"Conjurer's Regalia (Recolor)",{9797,9795,9799,9791},nil)  --32
s(27,"Conjurer's Regalia (Recolor)",{4723,56673,9823,9819},nil)  --32
s(38,"Conjurer's Regalia (Recolor)",{9874,9879,9880,9875,65910,9876},nil)  --32
s(1671,"Conjurer's Regalia (Recolor)",{61125,61114,59209,59165},nil)  --32
s(77,"Consortium Regalia",{24660,24654,24656,24657,24659,24658,24655,24653},nil) --77
s(40,"Darkmist Regalia",{14237,14240,14238,14245,14241,14242},nil) --40
s(24,"Darkmist Regalia (Recolor)",{7429,7438,7434,7437,7433,7431},nil)  --40
s(26,"Darkmist Regalia (Recolor)",{14402,14399,14406,14403,14404,14398},nil)  --40
s(36,"Darkmist Regalia (Recolor)",{14236,14226,14235,14233,14231,14230},256)  --40
s(39,"Darkmist Regalia (Recolor)",{14418,14419,14421,14426,14422,14424,14417},nil)  --40
s(1706,"Darkmoon Regalia",{38318,61107,24614},nil) --1706; Cloth
s(1707,"Darkmoon Regalia (Recolor)",{2585,65686},nil)  --1706; Cloth
s(99,"Deathsilk Regalia",{54478,54475,54471,54477,54473,54476,54472,54474},nil) --99
s(100,"Deathsilk Regalia (Recolor)",{55767,55740,55731,55749,55713,55722,55758,55709},nil)  --99
s(103,"Deathsilk Regalia (Recolor)",{66882,54485,54481,54482,54480,54484,54483,54486},nil)  --99
s(1289,"Deathsilk Regalia (Recolor)",{61480,61501,61495,61492,61459,61444,61498},nil)  --99
s(1091,"Dream Bough Regalia",{54919,53308,61534,57501,53287,61513,55945},nil) --1091; Cloth
s(1089,"Dream Bough Regalia (Recolor)",{53234,61586,61570,55918,59252},nil)  --1091; Cloth
s(1090,"Dream Bough Regalia (Recolor)",{59269,62148,33229,62165,55894},nil)  --1091; Cloth
s(1130,"Felcloth Regalia",{14108,14111,14107,14106,14112,18407},nil) --1130; Cloth
s(1287,"Fleshburned Regalia",{63870,63786,63896,63814,63855,63759,63780},nil) --1287; Cloth
s(1288,"Fleshburned Regalia (Recolor)",{65847,65873,65860,65889,65876,65857,65792},nil)  --1287; Cloth
s(1075,"Flirtation Regalia",{62951,63624,56871,62935,62939,63550,63566},nil) --1075; Cloth
s(1072,"Flirtation Regalia (Recolor)",{63641,65288,63230,65294,56852,56903,65293,65291},nil)  --1075; Cloth
s(1073,"Flirtation Regalia (Recolor)",{63164,56840,63588,63151,63175,63183,63659,63617},nil)  --1075; Cloth
s(1074,"Flirtation Regalia (Recolor)",{63638,62999,63209,65289},nil)  --1075; Cloth
s(1123,"Frostsavage Battlegear",{72661,72660,72659,72658,72657,72656,72655,72653},16) --1123; Cloth
s(93,"Frostsavage Battlegear (Recolor)",{72627,72626,72625,72624,72623,72622,72621,51972},128)  --1123; Cloth
s(94,"Frostsavage Battlegear (Recolor)",{36019,36054,36058,44378,36055,36056,36053,36052},nil)  --1123; Cloth
s(1125,"Frostwoven Power",{41522,41520,44211,41519,41515,41512,37594,36982},nil) --1125; Cloth
s(88,"Frostwoven Power (Recolor)",{36007,36010,36006,36009,36008,36005,36003,36004},nil)  --1125; Cloth
s(89,"Frostwoven Power (Recolor)",{36014,36018,36015,36016,36017,36013,36011,36012},nil)  --1125; Cloth
s(1122,"Frostwoven Power (Recolor)",{41543,41544,41545,41550,41546,41548,41549,41551},nil)  --1125; Cloth
s(1372,"Ivycloth Regalia",{6569,6461,4829},nil) --1372; Cloth
s(1375,"Ivycloth Regalia (Recolor)",{14186,9913},nil)  --1372; Cloth
s(71,"Laughing Skull Regalia",{24612,24606,24609,24608,24610,24607,24605},nil) --71
s(68,"Laughing Skull Regalia (Recolor)",{24588,26009,24582,24575,24586,24583},nil)  --71
s(69,"Laughing Skull Regalia (Recolor)",{24596,24590,24591,24589,24592,24594,24593},nil)  --71
s(74,"Laughing Skull Regalia (Recolor)",{24636,24632,24631,24634,24630,24629},nil)  --71
s(1128,"Mageweave Regalia (Recolor)",{30926,14045,14042,30924,30927},nil)  --71
s(1267,"Mageweave Regalia (Recolor)",{10217,10218,31456},16)  --71
s(75,"Mistyreed Regalia",{24637,24638,24644,24640,24641,24642,24643,24639},nil) --75
s(13,"Mystic's Regalia",{14025,14366,14367,14364,14370,14369},nil) --13
s(3,"Mystic's Regalia (Recolor)",{14090,26008,14094},nil)  --13
s(15,"Mystic's Regalia (Recolor)",{14133,14125,14124,14129,14131,14122},nil)  --13
s(1480,"Nayeli Regalia",{101078,101073,101075,101076,101077,101074,101079,101080},nil) --1480; Cloth
s(1481,"Nayeli Regalia (Recolor)",{101174,101175,101176,101177,101182,101184,101185,101186},nil)  --1480; Cloth
s(1482,"Nayeli Regalia (Recolor)",{87283,80731,80749,80740,80686,80704,80722,80695},nil)  --1480; Cloth
s(17,"Pagan Regalia",{3229,14160,14165,14162,14159,14158},nil) --17
s(7,"Pagan Regalia (Recolor)",{14097,14096},nil)  --17
s(18,"Pagan Regalia (Recolor)",{9771,9772,9767,9766,9774,9768},nil)  --17
s(1382,"Rebirth Regalia",{31657,7061,13100},nil) --1382; Cloth
s(1269,"Royal Ascension Regalia",{19375,10253,21838,19842,94063,94062,94061},16) --1269; Cloth
s(1367,"Royal Ascension Regalia (Recolor)",{13868,31552,6617},nil)  --1269; Cloth
s(1368,"Royal Ascension Regalia (Recolor)",{10004,3985,13867},nil)  --1269; Cloth
s(1369,"Royal Ascension Regalia (Recolor)",{7711,7712,30284},nil)  --1269; Cloth
s(1370,"Royal Ascension Regalia (Recolor)",{50213,7520,7526},16)  --1269; Cloth
s(1135,"Runecloth Regalia",{13864,13863,13865,13857,24604},256) --1135; Cloth
s(43,"Runecloth Regalia (Recolor)",{7113,4047,4045,6428,4046,4736},128)  --1135; Cloth
s(59,"Runecloth Regalia (Recolor)",{10095,10096,10099,10101,10104},16)  --1135; Cloth
s(66,"Runecloth Regalia (Recolor)",{10137,10136,10140,10141,10135},nil)  --1135; Cloth
s(19,"Sanguine Regalia",{14379,14377,14373,14375,14374,14372},nil) --19
s(21,"Sanguine Regalia (Recolor)",{14183,14181,14185,14176,14177,14180},16)  --19
s(33,"Sanguine Regalia (Recolor)",{14414,14416,14408,14415,14411,14407},nil)  --19
s(34,"Sanguine Regalia (Recolor)",{14224,14218,14222,14221,14216,14205},nil)  --19
s(12,"Seer's Regalia",{2911,3645,2983,2984,2982,6561},nil) --12
s(78,"Shadow Council Regalia",{24663,24666,24661,24664,24662,24668},nil) --78
s(41,"Shadow Council Regalia (Recolor)",{7332,7469,7471,7472,7476,7475,41984},nil)  --78
s(55,"Shadow Council Regalia (Recolor)",{12256,8246,8249,8253,8245,8247},nil)  --78
s(57,"Shadow Council Regalia (Recolor)",{10181,10177,10179,10176,10180,10173,29927},nil)  --78
s(16,"Shimmering Regalia",{6568,6565,6570,6562,6563,6567},nil) --16
s(25,"Shimmering Regalia (Recolor)",{10724,6609,6615,6616,6611,6613},nil)  --16
s(23,"Silver-thread Regalia",{7110,6394,4036,6393,4037,4714},nil) --23
s(6,"Simple Regalia",{9747,9749},nil) --6
s(1380,"Stonecloth Regalia",{14413,13403,25974},nil) --1380; Cloth
s(1483,"Swampwalker Regalia",{101272,101267,101269,101270,101271,101268,101273,101274},nil) --1483; Cloth
s(1484,"Swampwalker Regalia (Recolor)",{82536,82403,82402,82400,82397,82401,82398,82399},nil)  --1483; Cloth
s(1485,"Swampwalker Regalia (Recolor)",{101189,101190,101191,101192,101193,101194,101195,101196},nil)  --1483; Cloth
s(1063,"Tarred Regalia",{67172,67171,53592,53577,59368,67170,67173,53585},nil) --1063; Cloth
s(1064,"Tarred Regalia (Recolor)",{64590,64591,67158,64547,64556,53566,67165},nil)  --1063; Cloth
s(47,"The Postmaster (Recolor)",{10214,7517,7526,7519,7522,7525},nil)  --1063; Cloth
s(72,"Vindicator Regalia",{24614,24613,24620,24617,24616,24618,24619,24615},nil) --72
s(10,"Willow Regalia",{6543,6537,6541,6539,6540,6536},nil) --10
s(1358,"Wizard Regalia",{14152,9941,9878},nil) --1358; Cloth
s(1359,"Wizard Regalia (Recolor)",{25510,14443,14178},nil)  --1358; Cloth
s(1360,"Wizard Regalia (Recolor)",{18385,14278,31766},nil)  --1358; Cloth
s(1361,"Wizard Regalia (Recolor)",{1716,10142,7470},nil)  --1358; Cloth
s(1362,"Wizard Regalia (Recolor)",{31174,14232,30294},nil) --1358; Cloth
