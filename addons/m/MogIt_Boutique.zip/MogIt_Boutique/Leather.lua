local a,t=...
local s=t.AddLeather
s(1058,"Amani Garb",{34902,69589,69634,69559,69564,69569,69574},nil) --Leather; 1058
s(1543,"Amani Raiment",{94075,94070,94072,94071,94076,94074,94073,33479},nil) --Leather; 1543
s(1057,"Amani Raiment (Recolor)",{69594,69556,69586,69623,69613,94213},nil) --Leather; 1543
s(1747,"Armor of Seven Sacred Seals",{99140,105218,105204,99142,99143,99144,105402,105256},512) --Leather; 1747
s(1750,"Armor of Seven Sacred Seals (Lookalike)",{105452,105467,105453,105476,105596,105551,105651,105505},nil) --Leather; 1747
s(1752,"Armor of Seven Sacred Seals (Lookalike)",{104954,104969,104955,104978,105098,105053,105153,105007},nil) --Leather; 1747
s(1748,"Armor of Seven Sacred Seals (Recolor)",{105203,105218,105227,105347,105302,105402,105256,104706},nil) --Leather; 1747
s(1749,"Armor of Seven Sacred Seals (Recolor)",{99382,105467,99383,99384,99385,99381,105651,105505},512) --Leather
s(1751,"Armor of Seven Sacred Seals (Recolor)",{99061,104969,99064,99065,99050,99051,105153,105007},512) --Leather
s(1438,"Armor of the Red Crane",{87084,87085,87086,87087,87088,87181,86984,86995},512) --Leather; 1438
s(1439,"Armor of the Red Crane (Lookalike)",{86950,86984,86995,87013,87029,87033,87058,87181},nil) --Leather; 1438
s(1443,"Armor of the Red Crane (Recolor)",{86724,86725,86726,86727,86728,86843,86859,86898},512) --Leather; 1438
s(1447,"Armor of the Red Crane (Recolor)",{86340,85384,85385,85386,85387,85388,86185,86212},512) --Leather; 1438
s(1741,"Armor of the Shattered Vale",{99170,105175,99163,99164,99165,99166,105251,105176},1024) --Leather; 1741
s(1742,"Armor of the Shattered Vale (Lookalike)",{105219,105380,105175,105160,105758,105196,105251,105176},nil) --Leather; 1741
s(1744,"Armor of the Shattered Vale (Lookalike)",{105468,105629,105424,105409,105445,105500,105425},nil) --Leather; 1741
s(1746,"Armor of the Shattered Vale (Lookalike)",{104970,105131,104926,104911,104947,105002,104927},nil) --Leather; 1741
s(1743,"Armor of the Shattered Vale (Recolor)",{99326,105424,99327,99328,99329,99322,105500,105425},1024) --Leather
s(1745,"Armor of the Shattered Vale (Recolor)",{98997,104926,98994,98995,98981,98978,105002,104927},1024) --Leather
s(1473,"Ascendant Tribe Armor",{95519,90720,86136,93269,86146,85995,89645,88744},nil) --Leather; 1473
s(1474,"Ascendant Tribe Armor (Recolor)",{95521,90724,89432,93268,85989,86039,86786,88743},nil) --Leather; 1473
s(1713,"Ascendant Tribe Armor (Recolor)",{101862,101863,101864,101865,101866,101867,101868,101869},nil) --Leather; 1473
s(1735,"Barbed Assassin Battlegear",{99112,105182,99113,99114,99115,99116,105279,105367},8) --Leather; 1735
s(1736,"Barbed Assassin Battlegear (Lookalike)",{105312,105182,105236,105387,105280,105257,105279,105367},nil) --Leather; 1735
s(1738,"Barbed Assassin Battlegear (Lookalike)",{105845,105561,105431,105636,105529,105506,105528,105616},nil) --Leather; 1735
s(1740,"Barbed Assassin Battlegear (Lookalike)",{105817,105063,104933,105138,105031,105008,105030,105118},nil) --Leather; 1735
s(1737,"Barbed Assassin Battlegear (Recolor)",{99356,105431,99355,99348,99349,99350,105528,105616},8) --Leather
s(1739,"Barbed Assassin Battlegear (Recolor)",{99006,104933,99007,99008,99009,99010,105030,105118},8) --Leather
s(1435,"Battlegear of the Thousandfold Blades",{87124,87125,87126,87127,87128,87180,86943,86954},8) --Leather; 1435
s(1783,"Battlegear of the Thousandfold Blades (Lookalike)",{90411,89836,85788,86341,89841,86153,86163,89842},nil) --Leather; 1435
s(1784,"Battlegear of the Thousandfold Blades (Lookalike)",{87070,89950,87180,90504,86943,86954,89945},nil) --Leather; 1435
s(1440,"Battlegear of the Thousandfold Blades (Recolor)",{89961,89978,89980,89985,86641,86811,86821,86899},8) --Leather; 1435
s(1444,"Battlegear of the Thousandfold Blades (Recolor)",{85299,85300,85301,85302,85303,86341,86153,86163},8) --Leather
s(1209,"Blackfang Battleweave",{77023,77024,77025,77026,77027,77260,77254},8) --Leather; 1209
s(1256,"Blackfang Battleweave (Lookalike)",{77148,77271,77126,77240,77161,77260,71985,77254},nil) --Leather; 1209
s(1210,"Blackfang Battleweave (Recolor)",{78368,78664,78679,78699,78708,78388,78462},8) --Leather; 1209
s(1211,"Blackfang Battleweave (Recolor)",{78375,78759,78774,78794,78803,78395,78467},8) --Leather; 1209
s(620,"Bloodfang Armor",{49477,16910,16906,16911,16905,16907,16909,16832},8) --Leather; 620
s(398,"Bloodfang Armor (Recolor)",{29947,28732,28755,28601,28828,28741,28545},nil) --Leather; 620
s(399,"Bloodfang Armor (Recolor)",{28803,28647,28600,28521,30062,28591,28545},nil) --Leather; 620
s(622,"Bonescythe Armor",{30674,22483,22476,22481,22478,22477,22479,22482},nil) --Leather; 622
s(626,"Bonescythe Battlegear",{39558,39560,39561,39564,39565,39247,39279,39196},8) --Leather; 626
s(627,"Bonescythe Battlegear (Recolor)",{40495,40496,40499,40500,40502,39765,40205,40748},8) --Leather; 626
s(1311,"Brazen Trespass Armor",{44054,44908,47221,47496,47177,47170,47202,47248},1544) --Leather; 1311
s(956,"Brutal Gladiator's Refuge",{35022,35023,35024,35025,35026,35152,35137},1024) --Leather; 956
s(795,"Brutal Gladiator's Vestments",{35032,35033,35034,35035,35036,35156,35141},8) --Leather; 795
s(1236,"Cataclysmic Gladiator's Refuge",{73602,73599,73598,73597,73596,73595,73601},1024) --Leather; 1236
s(1237,"Cataclysmic Gladiator's Refuge (Recolor)",{73725,73724,73723,73722,73721,73726},1024) --Leather; 1236
s(1234,"Cataclysmic Gladiator's Vestments",{73526,73525,73524,73523,73527,73531,73532},8) --Leather; 1234
s(1235,"Cataclysmic Gladiator's Vestments (Recolor)",{73681,73682,73680,73679,73678,73683},8) --Leather; 1234
s(509,"Cenarion Raiment",{16828,16829,16830,16833,16831,16834,16835,16836},1024) --Leather; 509
s(965,"Choking Winter's Garb",{50206,50293,50300,50269,50264,50308},nil) --Leather; 965
s(966,"Choking Winter's Garb (Recolor)",{49785,49841,49838,49806,49817},nil) --Leather; 965
s(1346,"Choking Winter's Garb (Recolor)",{49830,49786,50318,50212},nil) --Leather; 965
s(1526,"Cycle Armor",{90059,90060,90061,90062,90063,90064,90065,90066},1024) --Leather; 1526
s(640,"Darkmantle Armor",{31797,97682,97639,97655,97647,97663,97633,22004},8) --Leather; 640
s(957,"Deadly Gladiator's Refuge",{41274,41286,41297,41309,41320,41639,41629,41634},1024) --Leather; 957
s(796,"Deadly Gladiator's Vestments",{41649,41654,41671,41682,41766,41839,41831,41835},8) --Leather; 796
s(621,"Deathdealer's Embrace",{21359,21360,21361,21362,21364,21672,21602,21586},8) --Leather; 621
s(624,"Deathmantle Armor",{30040,30039,30144,30145,30146,30148,30149,29966},8) --Leather; 624
s(1037,"Deathmantle Armor (Recolor)",{30055,29995,31998,31999,32002,32802,32790},8) --Leather; 624
s(1212,"Deep Earth Battlegarb",{77013,77018,77019,77020,76753,77248,77172},1024) --Leather; 1212
s(1213,"Deep Earth Battlegarb (Recolor)",{78665,78676,78696,78714,78740,78420,78434},1024) --Leather; 1212
s(1214,"Deep Earth Battlegarb (Recolor)",{78760,78771,78791,78809,78835,78428,78442},1024) --Leather; 1212
s(1257,"Deep Earth Vestments (Lookalike)",{77149,77127,77320,77160,77181,71986,77243},nil) --Leather; 1212
s(516,"Dreamwalker Battlegear",{39553,39554,39555,39556,39557,39283,39308,39215},1024) --Leather; 516
s(517,"Dreamwalker Battlegear (Recolor)",{40409,40471,40472,40473,40493,40494,39722,40200},1024) --Leather; 516
s(512,"Dreamwalker Raiment",{22492,22494,22493,22490,22489,22491,22488,22495},nil) --Leather; 512
s(1657,"Fel Skin (Recolor)",{29131,29525,29527},nil) --Leather; 512
s(530,"Feralheart Raiment",{22106,22107,22108,22109,22110,22111,22112,22113},1024) --Leather; 530
s(947,"Field Marshal's Sanctuary",{16452,16451,16449,16459,16448,16450},1024) --Leather; 947
s(787,"Field Marshal's Vestments",{16453,16457,16455,16446,16454,16456},8) --Leather; 787
s(1599,"Fire Charm Vestments",{96639,96640,96641,96642,96643,94997,96860,96758},512) --Leather; 1599
s(1600,"Fire Charm Vestments (Lookalike)",{96860,95032,96865,96777,94997,96829,96984,96758},nil) --Leather; 1599
s(1602,"Fire Charm Vestments (Lookalike)",{94273,94274,95147,95186,96014,96033,96191,96241},nil) --Leather; 1599
s(1604,"Fire Charm Vestments (Lookalike)",{95642,95971,95868,95661,95713,95749,95744,95679},nil) --Leather; 1599
s(1601,"Fire Charm Vestments (Recolor)",{95265,95266,95267,95268,95269,96116,96343,96014},512) --Leather
s(1603,"Fire Charm Vestments (Recolor)",{95895,95896,95897,95898,95899,95971,95642,95787},512) --Leather
s(1095,"Flowing Water Armor (Recolor)",{65969,54933,97747,97753,97757,97756,97748},512) --Leather
s(701,"Furious Gladiator's Refuge",{41275,41287,41298,41310,41321,41640,41630,41635},1024) --Leather; 701
s(799,"Furious Gladiator's Vestments",{48988,41650,41672,41683,41767,41840,41832,41836},8) --Leather; 799
s(631,"Garona's Battlegear",{48233,48234,48235,48236,48237,90313,47474,47460},8) --Leather; 631
s(1007,"Garona's Battlegear (Lookalike)",{90285,90295,90304,90313,47904,47313,47878,47299},nil) --Leather; 631
s(511,"Genesis Raiment",{21355,21353,21354,21356,21357,21609,21617},1024) --Leather; 511
s(952,"Gladiator's Refuge",{31375,31376,31377,31378,31379,31596,31597},1024) --Leather; 952
s(792,"Gladiator's Vestments",{25834,25833,25830,25832,25831,28986,28987},8) --Leather; 792
s(1681,"Grievous Gladiator's Copperskin",{103431,103429,103430,103432,103433,103428,103426,103427},512) --Leather; 1681
s(1682,"Grievous Gladiator's Copperskin (Recolor)",{102825,102824,102959,102960,102974,102913,102844,102908},512) --Leather; 1681
s(1683,"Grievous Gladiator's Copperskin (Recolor)",{100344,100346,100348,100350,100352,100339,100341},512) --Leather; 1681
s(1687,"Grievous Gladiator's Refuge",{103192,103193,103194,103195,103196,103190,103189,103191},1024) --Leather; 1687
s(1688,"Grievous Gladiator's Refuge (Recolor)",{102691,102657,102658,102721,102761,102776,102694,102631},1024) --Leather; 1687
s(1689,"Grievous Gladiator's Refuge (Recolor)",{100254,100256,100258,100260,100262,100264,100266},1024) --Leather; 1687
s(1684,"Grievous Gladiator's Vestments",{103282,103281,103280,103279,103278,103277,103276,103275},8) --Leather; 1684
s(1685,"Grievous Gladiator's Vestments (Recolor)",{102857,102860,102905,102907,102924,102927,102928,102951},8) --Leather; 1684
s(1686,"Grievous Gladiator's Vestments (Recolor)",{103088,103089,103090,103091,103092,103093,103094},8) --Leather; 1684
s(958,"Hateful Gladiator's Refuge",{44892,41273,41284,41296,41308,41319,41638,41628},1024) --Leather; 958
s(797,"Hateful Gladiator's Vestments",{44893,41648,41653,41670,41681,41765,41830,41827},8) --Leather; 797
s(1605,"Haunted Forest Vestments",{96579,96580,96581,96582,96583,96913,95006,96764},1024) --Leather; 1605
s(1606,"Haunted Forest Vestments (Lookalike)",{97082,96787,96892,95029,96778,96913,96764},nil) --Leather; 1605
s(1608,"Haunted Forest Vestments (Lookalike)",{95195,96034,96043,96065,96136,96169,96338},nil) --Leather; 1605
s(1610,"Haunted Forest Vestments (Lookalike)",{95648,95797,95662,95764,95776,95966,95671},nil) --Leather; 1605
s(1607,"Haunted Forest Vestments (Recolor)",{95235,95236,95237,95238,95239,96169,96338,96020},1024) --Leather
s(1609,"Haunted Forest Vestments (Recolor)",{95835,95836,95837,95838,95839,95797,95966,95648},1024) --Leather
s(1053,"Inferno Hardened Garb",{21501,16982,19139,29967,30778},nil) --Leather; 1053
s(522,"Lasherweave Battlegear",{53117,50824,50825,50826,50828,50985,50795,50783},1024) --Leather; 522
s(523,"Lasherweave Battlegear (Recolor)",{49898,50981,50973,51140,51143,50417,50069,50009},1024) --Leather; 522
s(524,"Lasherweave Battlegear (Recolor)",{51297,51295,51296,51298,51299,50630,50705,50665},1024) --Leather; 522
s(440,"Lasherweave Garb (Lookalike)",{51297,50665,50630,50649,50615,50679,50705,50715},1024) --Leather; 522
s(459,"Lasherweave Garb (Lookalike)",{49898,50981,50973,50417,50009,50026,50069,50171},nil) --Leather
s(461,"Lasherweave Garb (Lookalike)",{53117,51009,50783,51585,50806,51552,50795,50985},nil) --Leather
s(460,"Lasherweave Garb (Recolor)",{51920,51870,51908,51814,51897,51839,51825,51885},nil) --Leather
s(1396,"Malevolent Gladiator's Copperskin",{84809,84836,84854,84873,84902,84919,84947,84973},512) --Leather; 1396
s(1397,"Malevolent Gladiator's Copperskin (Recolor)",{85010,85015,85030,85060,85066,85087,85100},512) --Leather; 1396
s(1402,"Malevolent Gladiator's Refuge",{98789,98790,98791,98792,98793,98794,98795,98796},1024) --Leather; 1402
s(1403,"Malevolent Gladiator's Refuge (Recolor)",{84996,85022,85037,85049,85065,85080,85098},1024) --Leather; 1402
s(1399,"Malevolent Gladiator's Vestments",{98881,98882,98883,98884,98885,98886,98887,98888},8) --Leather; 1399
s(1400,"Malevolent Gladiator's Vestments (Recolor)",{84995,85009,85023,85041,85055,85089,85101},8) --Leather; 1399
s(520,"Malfurion's Battlegear",{48138,48139,48140,48141,48142,90369,47055,47929},1024) --Leather; 520
s(1004,"Malfurion's Battlegear (Lookalike)",{90342,90351,90369,47613,47066,47669,47190},nil) --Leather; 520
s(513,"Malorne Raiment",{29087,29086,29090,29088,29089,28453,28655,28752},1024) --Leather; 513
s(1016,"Malorne Raiment (Recolor)",{31375,31376,31377,31378,31379,31596,31597},1024) --Leather; 513
s(953,"Merciless Gladiator's Refuge",{31987,31988,31989,31990,31991,32798,32786},1024) --Leather; 953
s(793,"Merciless Gladiator's Vestments",{30055,29995,31998,31999,32002,32802,32790},8) --Leather; 793
s(1348,"Naxxramas Polar Armor",{28492,61126,43590,22663,22662,43591,23020,22701},nil) --Leather; 1348
s(623,"Netherblade Armor",{29046,29045,29044,29048,29047,28514,28750,28669},8) --Leather; 623
s(1036,"Netherblade Armor (Recolor)",{25834,25833,25830,25832,25831,28986,28987},8) --Leather; 623
s(619,"Nightslayer Armor",{16827,16824,16825,16820,16821,16826,16822,16823},8) --Leather; 619
s(1660,"Nightslayer Armor (Recolor)",{31333,30730,28347,29357},nil) --Leather; 619
s(518,"Nightsong Battlegear",{45847,45839,45356,45358,45359,45830},1024) --Leather; 518
s(519,"Nightsong Battlegear (Recolor)",{46157,46158,46159,46160,46161},1024) --Leather; 518
s(425,"Nightsong Garb (Recolor)",{45565,45439,45492,45237,45149,45512,45185,45482},nil) --Leather; 518
s(426,"Nightsong Garb (Recolor)",{45864,45974,45686,46009,45293,45455,46049,45378},nil) --Leather; 518
s(1611,"Nine-Tail Battlegear",{96679,96680,96681,96682,96683,94998,95007,96912},8) --Leather; 1611
s(1612,"Nine-Tail Battlegear (Lookalike)",{97075,95033,96796,95028,94998,96742,96816,96912},nil) --Leather; 1611
s(1614,"Nine-Tail Battlegear (Lookalike)",{95148,95196,95187,95998,96072,96101,96168,96331},nil) --Leather; 1611
s(1616,"Nine-Tail Battlegear (Lookalike)",{95796,95721,95700,95729,95626,95680,95959,95804},nil) --Leather; 1611
s(1613,"Nine-Tail Battlegear (Recolor)",{95305,95306,95307,95308,95309,96093,96331,96168},8) --Leather; 1611
s(1615,"Nine-Tail Battlegear (Recolor)",{95935,95936,95937,95938,95939,95721,95959,95796},8) --Leather; 1611
s(514,"Nordrassil Harness",{30041,30222,30223,30228,30229,30230,30062,29984},1024) --Leather; 514
s(1017,"Nordrassil Harness (Recolor)",{31987,31988,31989,31990,31991,32798,32786},1024) --Leather; 514
s(973,"Northrend Leather Garb",{39240,39230,39259,39275,40695,43991,40519},nil) --Leather; 973
s(971,"Northrend Leather Garb (Recolor)",{39399,39237,43990,39299,39224,40694},nil) --Leather; 973
s(972,"Northrend Leather Garb (Recolor)",{40296,40437,40319,40362,39761},nil) --Leather; 973
s(1347,"Northrend Leather Garb (Recolor)",{40304,40439,40249,40349,40566,40285},nil) --Leather; 973
s(527,"Obsidian Arborweave Garb",{71097,71098,71099,71100,71101,71341,71249,70987},1024) --Leather; 527
s(449,"Obsidian Arborweave Garb (Lookalike)",{71044,71040,71349,71010,70987,71249,71025,71262},nil) --Leather; 527
s(490,"Obsidian Arborweave Garb (Lookalike)",{71410,71411,71474,71424,71436,71450,71463},nil) --Leather; 527
s(528,"Obsidian Arborweave Garb (Recolor)",{71486,71487,71488,71489,71490,71463,71436},1024) --Leather; 527
s(1525,"Regal Lord Armor",{90093,90094,90095,90092,90088,90089,90090,90091},512) --Leather; 1525
s(702,"Relentless Gladiator's Refuge",{41276,41288,41299,41311,41322,41641,41631,41636},1024) --Leather; 702
s(800,"Relentless Gladiator's Vestments",{41651,41656,41673,41684,41768,41841,41833,41837},8) --Leather; 800
s(521,"Runetotem's Battlegear",{48143,48144,48145,48146,48147,90317,47438,47469},1024) --Leather; 521
s(1005,"Runetotem's Battlegear (Lookalike)",{90287,90299,90308,90317,47857,47438,47863},nil) --Leather; 521
s(705,"Ruthless Gladiator's Refuge",{72337,72338,72339,72340,72341,72342,72343,72344},1024) --Leather; 705
s(706,"Ruthless Gladiator's Refuge",{70430,70431,70432,70436,70437,70498},1024) --Leather; 706
s(803,"Ruthless Gladiator's Vestments",{72416,72418,72420,72422,72423,72424,72425,72426},8) --Leather; 803
s(804,"Ruthless Gladiator's Vestments",{70442,70443,70444,70445,70446,70507},8) --Leather; 804
s(632,"Shadowblade's Battlegear",{54561,50088,50089,50090,50105,51783,50778,51023},8) --Leather; 632
s(462,"Shadowblade's Battlegear (Lookalike)",{50982,50073,49899,49987,50001,51856,51925,51820},nil) --Leather; 632
s(463,"Shadowblade's Battlegear (Lookalike)",{54561,51013,51550,50799,51565,50778,51023,51783},nil) --Leather; 632
s(464,"Shadowblade's Battlegear (Lookalike)",{50707,50675,50646,50607,50697,50713,50656,50670},nil) --Leather; 632
s(633,"Shadowblade's Battlegear (Recolor)",{49899,49987,50982,50073,50001,51820,51925,51856},8) --Leather
s(634,"Shadowblade's Battlegear (Recolor)",{51250,51251,51252,51253,51254,50670,50707,50607},8) --Leather
s(1524,"Silent Assassin Armor",{90119,90120,90121,90122,90123,90124,90125,90126},8) --Leather; 1524
s(625,"Slayer's Armor",{31028,31026,31027,31029,31030,32324,30891},8) --Leather; 625
s(1038,"Slayer's Armor (Recolor)",{32265,32377,32347,32366,33701,33702,33704},8) --Leather; 625
s(1312,"Snowy Bramble Armor",{44194,47217,47210,46063,47498,47174,47504},1024) --Leather; 1312
s(510,"Stormrage Raiment",{49326,16903,16898,16904,16897,16899,16901,16902},1024) --Leather; 510
s(525,"Stormrider's Garb",{85823,60290,60286,60288,60289,59451,63497,59495},1024) --Leather; 525
s(483,"Stormrider's Garb (Lookalike)",{56536,56561,60202,59467,59511,59353,59451,58484},nil) --Leather; 525
s(484,"Stormrider's Garb (Lookalike)",{65057,65066,65113,65030,65021,65078,65045,65128},nil) --Leather; 525
s(526,"Stormrider's Garb (Recolor)",{65193,65192,65191,65190,65189,65021,65374,65128},1024) --Leather; 525
s(1266,"Stormshroud Armor (Recolor)",{6433,22409,29141,21458,21708},nil) --Leather
s(417,"Sunwell Druid Raiment",{34209,34372,34371,34384,34245,34572,34446,34555},1024) --Leather; 417
s(1019,"Sunwell Druid Raiment (Recolor)",{35022,35023,35024,35025,35026,35152,35137},1544) --Leather; 417
s(416,"Sunwell Rogue Armor",{34369,34370,34188,34195,34244,34575,34448,34558},8) --Leather; 416
s(1039,"Sunwell Rogue Armor (Recolor)",{35032,35033,35034,35035,35036,35156,35141},8) --Leather; 416
s(628,"Terrorblade Battlegear",{45396,45397,45398,45399,45400},8) --Leather; 628
s(455,"Terrorblade Battlegear (Recolor)",{45555,6095,46043,45893,45324,45677,45940},nil) --Leather; 628
s(457,"Terrorblade Battlegear (Recolor)",{45846,45829,45838,45473,45245,45611,45162,45523},nil) --Leather; 628
s(629,"Terrorblade Battlegear (Recolor)",{46123,46124,46125,46126,46127},8) --Leather; 628
s(515,"Thunderheart Harness",{31042,31034,31039,31044,31048,32351,32339,32352},1024) --Leather; 515
s(1018,"Thunderheart Harness (Recolor)",{33690,33691,33692,33693,33694,33879,33880},1024) --Leather; 515
s(411,"Thunderheart Regalia (Recolor)",{32240,32518,32328,30899,32271},nil) --Leather; 515
s(1254,"Time Twisted Armor",{72824,72868,72805,72847,72830,72835,72849},nil) --Leather; 1254
s(1255,"Time Twisted Armor (Recolor)",{72882,72798,72857,72840,72823,76157,72874,76150},nil) --Leather; 1254
s(1557,"Tyrannical Gladiator's Copperskin",{91242,91244,91246,91247,91249,91251,91253,91255},512) --Leather; 1557
s(1558,"Tyrannical Gladiator's Copperskin (Recolor)",{100097,100102,100010,100011,100148,100163,100149,100030},512) --Leather; 1557
s(1559,"Tyrannical Gladiator's Copperskin (Recolor)",{91243,91245,91248,91250,91252,91254,91256},512) --Leather; 1557
s(1563,"Tyrannical Gladiator's Refuge",{91157,91159,91161,91163,91165,91167,91169,91171},1024) --Leather; 1563
s(1564,"Tyrannical Gladiator's Refuge (Recolor)",{94327,94344,94347,94368,94371,94372,94407,94410},1024) --Leather; 1563
s(1565,"Tyrannical Gladiator's Refuge (Recolor)",{91158,91160,91162,91164,91166,91168,91170},1024) --Leather; 1563
s(1560,"Tyrannical Gladiator's Vestments",{99903,99904,99905,99906,99907,99908,99909,99910},8) --Leather; 1560
s(1561,"Tyrannical Gladiator's Vestments (Recolor)",{94470,94424,94377,94374,94447,94426,94446,94443},8) --Leather; 1560
s(1562,"Tyrannical Gladiator's Vestments (Recolor)",{91336,91338,91341,91343,91345,91347,91349},8) --Leather; 1560
s(884,"Undead Slayer's Blessed Armor",{43078,43077,43079,43076},nil) --Leather; 884
s(630,"VanCleef's Battlegear",{48228,48229,48230,48231,48232,90365,47151,47107},8) --Leather; 630
s(1006,"VanCleef's Battlegear (Lookalike)",{90365,90347,90338,47832,47151,47719,47107,46974},nil) --Leather; 630
s(954,"Vengeful Gladiator's Refuge",{33690,33691,33692,33693,33694,33879,33880},1024) --Leather; 954
s(794,"Vengeful Gladiator's Vestments",{32265,32377,32347,32366,33701,33702,33704},8) --Leather; 794
s(637,"Vestments of the Dark Phoenix",{71045,71046,71047,71048,71049,70735,71131,71313},8) --Leather; 637
s(448,"Vestments of the Dark Phoenix (Lookalike)",{69942,71314,71031,71345,71313,71640,71003,70735},nil) --Leather; 637
s(489,"Vestments of the Dark Phoenix (Lookalike)",{71455,71402,71456,71467,71641,71416,71440,71428},nil) --Leather; 637
s(638,"Vestments of the Dark Phoenix (Recolor)",{71537,71538,71539,71540,71541,71428,71641,71467},8) --Leather; 637
s(1436,"Vestments of the Eternal Blossom",{86923,86924,86925,86926,86927,87022,90514},1024) --Leather; 1436
s(1437,"Vestments of the Eternal Blossom (Lookalike)",{89948,89922,90514,86972,86977,87022,87041},nil) --Leather; 1436
s(1442,"Vestments of the Eternal Blossom (Lookalike)",{89957,89983,86838,86845,86878,86912},nil) --Leather; 1436
s(1446,"Vestments of the Eternal Blossom (Lookalike)",{89884,89831,85829,86187,86320,86514,90450},nil) --Leather; 1436
s(1441,"Vestments of the Eternal Blossom (Recolor)",{86644,86645,86646,86647,86648,86878,86845},1024) --Leather
s(1445,"Vestments of the Eternal Blossom (Recolor)",{85304,85305,85306,85307,85308,90450,86320,86187},1024) --Leather
s(974,"Vicious Gladiator's Refuge",{60583,60448,60449,60450,60451,60452,60582,60581},1024) --Leather; 974
s(975,"Vicious Gladiator's Refuge",{70580,70581,70582,70583,70584,70523,70525,70571},1024) --Leather; 975
s(1704,"Vicious Gladiator's Refuge",{65533,65534,65535,65539,65540,65601},1024) --Leather; 1704
s(984,"Vicious Gladiator's Vestments ",{60458,60459,60460,60461,60462,60591,60609,60593},1536) --Leather; 984
s(985,"Vicious Gladiator's Vestments",{65545,65546,65547,65548,65549,65610},8) --Leather; 985
s(986,"Vicious Gladiator's Vestments",{70585,70586,70587,70588,70589,70515,70527,70663},8) --Leather; 986
s(788,"Warlord's Vestments",{16563,16561,16562,16564,16560,16558},8) --Leather; 788
s(635,"Wind Dancer's Regalia",{60302,60300,60299,60298,60301,59329,56537,59469},8) --Leather; 635
s(481,"Wind Dancer's Regalia (Lookalike)",{56562,62417,59343,59502,59329,59120,59469,59490},nil) --Leather; 635
s(482,"Wind Dancer's Regalia (Lookalike)",{65122,65039,65073,65129,65050,65083,65060,65144},nil) --Leather; 635
s(636,"Wind Dancer's Regalia (Recolor)",{65243,65242,65241,65240,65239,65050,65122,65144},8) --Leather; 635
s(885,"Windhawk Armor",{29523,29524,29522,24802,15067},nil) --Leather; 885
s(703,"Wrathful Gladiator's Refuge",{51419,51420,51421,51422,51424,51345,51343,51344},1024) --Leather; 703
s(801,"Wrathful Gladiator's Vestments",{51492,51493,51494,51495,51496,51370,51368,51369},8) --Leather; 801
s(886,"Assassination Armor",{44117,30358,27509,28414,27776,28204,29247,29248},nil) --Leather; 886
s(397,"Bloodfang Armor (Recolor)",{28206,27831,27787,28396,27765,28124,27514,27867},nil) --Leather; 886
s(888,"Cadaverous Garb",{28178,14637,14636,14640,14638},nil) --Leather; 888
s(388,"Cenarion Raiment (Recolor)",{27763,28340,27456,28268,27827,28398,27800,28251},nil) --Leather; 888
s(786,"Champion's Guard",{22864,22856,22879,22880,23257,23258,77814},8) --Leather; 786
s(946,"Champion's Refuge",{22863,22852,22877,22878,23253,23254,77743},1024) --Leather; 946
s(1304,"Curious Visitor Armor",{57266,55890,56094,56113,57858,66921,55877},nil) --Leather; 1304
s(1305,"Curious Visitor Armor (Recolor)",{55871,56128,55812,55844,55204,55273,69877},nil) --Leather; 1304
s(1383,"Dark Arctic Armor",{35575,38590,43255,37766,43484,38591},nil) --Leather; 1383
s(1340,"Dark Arctic Armor (Recolor)",{44356,39177,39171,37117,39183},nil) --Leather; 1383
s(1341,"Dark Arctic Armor (Recolor)",{66886,37083,37724,37114},nil) --Leather; 1383
s(889,"Defias Leather",{10399,10403,10402,10401,10400},nil) --Leather; 889
s(951,"Dragonhide Battlegear",{44055,35356,35357,35358,35359},1024) --Leather; 951
s(890,"Embrace of the Viper",{8202,10412,10411,10413,6473},nil) --Leather; 890
s(1141,"Eviscerator's Battlegear",{35647,43435,43434,43260,43438,43433,42762,43437},nil) --Leather; 1141
s(1142,"Eviscerator's Battlegear (Recolor)",{37745,35605,35634,35607,44442,43264,43271,43262},nil) --Leather; 1141
s(1338,"Eviscerator's Battlegear (Recolor)",{37616,37293,43194,37366,42761,43256},nil) --Leather; 1141
s(1339,"Eviscerator's Battlegear (Recolor)",{35620,41891,37000,44364,45181},nil) --Leather; 1141
s(891,"Fel Skin",{31788,31288,25687,24699,29973,31224},nil) --Leather; 891
s(790,"High Warlord's Vestments",{28575,28836,28838,28839,28840},8) --Leather; 790
s(785,"Lieutenant Commander's Guard",{23298,23299,23284,23285,23312,23313,77639},8) --Leather; 785
s(945,"Lieutenant Commander's Refuge",{23294,23295,23280,23281,23308,23309,77604},1024) --Leather; 945
s(1395,"Malevolent Gladiator's Copperskin (Recolor)",{84456,84459,84461,84543,84544,84545,84546,84547},512) --Leather; 945
s(1401,"Malevolent Gladiator's Refuge (Recolor)",{84377,84378,84379,84380,84381,84382,84383,84384},1024) --Leather; 945
s(1398,"Malevolent Gladiator's Vestments (Recolor)",{84457,84458,84460,84462,84463,84464,84465,84466},8) --Leather; 945
s(893,"Moonglade Raiment",{28348,27468,27873,28202,27737,29264,29265},nil) --Leather; 893
s(1356,"Nightscape Garb (Recolor)",{28172,8124,9414,22204,11686,9398},nil) --Leather; 893
s(389,"Nightslayer Armor (Recolor)",{27938,27995,27461,27825,27911,27545,27467},nil) --Leather; 893
s(1511,"Nimbletoe Armor",{81135,81249,87369,90597,81071,82851,87320,81700},nil) --Leather; 1511
s(1512,"Nimbletoe Armor (Recolor)",{81111,87346,87305,87374,87425,81093,87493,87316},nil) --Leather; 1511
s(1513,"Nimbletoe Armor (Recolor)",{87631,87605,87599,98180,98174,98177,98178,98179},nil) --Leather; 1511
s(1514,"Nimbletoe Armor (Recolor)",{87609,87595,98209,98203,98206,98202,98207,98208},nil) --Leather; 1511
s(791,"Opportunist's Battlegear",{44583,51958,34613,35366,35367,44106},8) --Leather; 791
s(700,"Savage Gladiator's Refuge",{48987,41268,41269,41271,41272},1024) --Leather; 700
s(798,"Savage Gladiator's Vestments",{41643,41644,41645,41646,41647},8) --Leather; 798
s(639,"Shadowcraft Armor",{16713,16711,16710,16721,16708,16709,16712,16707},nil) --Leather; 639
s(377,"Shadowcraft Armor (Recolor)",{27415,24398,24396,24365,31175,24063,24466,25946},nil) --Leather; 639
s(1318,"Shadowcraft Armor (Recolor)",{15059,18810,15060,13954,30943,31793},nil) --Leather; 639
s(1319,"Shadowcraft Armor (Recolor)",{21474,18875,13208,21493,21689},nil) --Leather; 639
s(1189,"Skystalker's Armor",{31565,31566,31567,31561,31562},nil) --Leather; 1189
s(400,"Stormrage Raiment (Recolor)",{28220,28255,27818,28214,27483,27783,27492,27914},nil) --Leather; 1189
s(895,"Stormshroud Armor",{15056,15057,15058,21278,23073,30362,12966},1544) --Leather; 895
s(948,"Warlord's Sanctuary",{16554,16555,16552,16551,16549,16550},1024) --Leather; 948
s(1327,"Warpwood Bark Armor",{65948,59399,63668,65951,65954},nil) --Leather; 1327
s(1536,"Warpwood Bark Armor (Recolor)",{88336,88347,88351,88266,88291},nil) --Leather; 1327
s(1537,"Warpwood Bark Armor (Recolor)",{88295,88270,65933,57846},nil) --Leather; 1327
s(898,"Wastewalker Armor",{44686,31131,28264,28224,27837,27797,28339},nil) --Leather; 898
s(1265,"Wicked Leather Armor (Recolor)",{18490,11685,21680,31179,14545},nil) --Leather; 898
s(529,"Wildheart Raiment",{16716,16715,16714,16720,16706,16718,16719,16717},nil) --Leather; 529
s(376,"Wildheart Raiment (Recolor)",{27409,27417,24455,24452,24391},nil) --Leather; 529
s(1115,"Wyrmhide Battlegear",{70028,70029,70030,70031,70032,70033,70034,70035},nil) --Leather; 1115
s(1112,"Wyrmhide Battlegear (Recolor)",{70020,70021,70022,70023,70024,70025,70026,70027},nil) --Leather; 1115
s(135,"Archer's Garb",{9863,9854,9862,9856,9859,9855,9861,9857},nil) --Leather; 135
s(117,"Bandit Garb",{1314,9781,9782,9776,9777,9775},nil) --Leather; 117
s(112,"Bandit Garb (Recolor)",{18368,6553,6552,6557,6558,6556},nil) --Leather; 117
s(179,"Bandit Garb (Recolor)",{24772,24765,24770,24768,24767,24766},nil) --Leather; 117
s(170,"Bonechewer Garb",{24695,24700,24693,24698,24699,24694,24697,24696},nil) --Leather; 170
s(1138,"Borean Embrace",{35905,39873,39881,39035,44397,37388,35918,38433},nil) --Leather; 1138
s(185,"Borean Embrace (Recolor)",{36084,36083,36087,36086,36085,36088,36089,36090},nil) --Leather; 1138
s(187,"Borean Embrace (Recolor)",{35815,36091,36098,36092,36095,36094,36096,36097},nil) --Leather; 1138
s(189,"Borean Embrace (Recolor)",{36108,36109,36114,36107,36110,36111,36112,36113},nil) --Leather; 1138
s(190,"Borean Embrace (Recolor)",{36115,36122,36116,36118,36119,36120,36121,36117},nil) --Leather
s(151,"Cabalist Garb",{15379,15378,15380,15381,15383,15385,15386},nil) --Leather; 151
s(153,"Cabalist Garb (Recolor)",{9948,9947,9949,9950,9952,9954,9955},nil) --Leather; 151
s(154,"Cabalist Garb (Recolor)",{14663,14664,14661,14666,14662,14669,14668},nil) --Leather; 151
s(1290,"Cartographer's Armor",{63876,63924,63866,63813,63836,63755,63771},nil) --Leather; 1290
s(1291,"Cartographer's Armor (Recolor)",{65835,65850,65843,65807,65818,65869,65801,65798},nil) --Leather; 1290
s(111,"Ceremonial Leather Garb",{3315,3313,3314},nil) --Leather; 111
s(177,"Daggerfen Garb",{2300,24749,24756,24750,24752,24755,24754},nil) --Leather; 177
s(115,"Daggerfen Garb (Recolor)",{4700,2985,2986,2988,2987,6379,3205},nil) --Leather; 177
s(172,"Daggerfen Garb (Recolor)",{24709,24716,24710,24711,24712,24714,24715},nil) --Leather; 177
s(176,"Daggerfen Garb (Recolor)",{24741,24748,24742,24744,24745,24743,24746},nil) --Leather; 177
s(1146,"Daggerfen Garb (Recolor)",{4249,2315,4248,5961,4252,2317},nil) --Leather
s(118,"Defias Leather (Recolor)",{6197,15116,15117,15115,15111,15110,15112},nil) --Leather
s(123,"Defias Leather (Recolor)",{9809,9808,9806,9807,9802,9803,9801},nil) --Leather
s(174,"Dementia Garb",{24732,24726,24725,24728,24731,24730,24727},nil) --Leather; 174
s(178,"Dementia Garb (Recolor)",{24758,24764,24762,24760,24763,24759,24757},nil) --Leather; 174
s(1149,"Dementia Garb (Recolor)",{4256,4258,5966,5962},nil) --Leather; 174
s(1355,"Dementia Garb (Recolor)",{7374,2264,31564,7390,7387},nil) --Leather; 174
s(182,"Devilsaur Garb",{24781,24783,24789,24784,24786,24785,24787,24788},nil) --Leather; 182
s(131,"Devilsaur Garb (Recolor)",{9406,6467,15351,15349,15353,15350,15357,15358},nil) --Leather; 182
s(1078,"Discovery Armor",{63613,63605,63579,63555,62207,63622,65275},nil) --Leather; 1078
s(1076,"Discovery Armor (Recolor)",{65284,65344,65312,63224,63234,65348,63648},nil) --Leather; 1078
s(1077,"Discovery Armor (Recolor)",{63618,65308,65303,63196,63583,65313,63231,56884},nil) --Leather; 1078
s(1079,"Discovery Armor (Recolor)",{56868,63152,63181,63161,63658},nil) --Leather; 1078
s(127,"Emblazoned Garb",{4049,6398,6397,4051,6399,4048,4050,6396},nil) --Leather; 127
s(121,"Emblazoned Garb (Recolor)",{3056,3055,3058,4709,3057,3202,6382},nil) --Leather; 127
s(132,"Emblazoned Garb (Recolor)",{1489,7414,7409,7413,7408,7406,7412,7410},nil) --Leather; 127
s(184,"Expedition Garb",{24797,24791,24790,24793,24794,24795,24796,24792},nil) --Leather; 184
s(1155,"Fel Skin (Recolor)",{25673,25674,25675,25676},nil) --Leather; 184
s(1190,"Fel Skin (Recolor)",{25559,25576,25486,25565,25507,25515},nil) --Leather; 184
s(114,"Feral Garb",{15311,15312,15305,15310,15308,15306},nil) --Leather; 114
s(105,"Feral Garb (Recolor)",{1211,15009},nil) --Leather; 114
s(1147,"Fine Leather Armor",{4246,2307,2312,18528,5958,4243,24724,9953},nil) --Leather; 1147
s(104,"Fine Leather Armor (Recolor)",{2962,2961,15384},nil) --Leather; 1147
s(1539,"Fine Leather Armor (Recolor)",{5753,2087,7282,4788},nil) --Leather; 1147
s(1092,"Flowing Water Armor",{61535,62146,33245,53274,55907,59267,61630},nil) --Leather; 1092
s(1093,"Flowing Water Armor (Recolor)",{33240,54940,55910,55922,59263,54943,54925},nil) --Leather; 1092
s(1094,"Flowing Water Armor (Recolor)",{57515,57834,53301,54911,55943,53307,57835},nil) --Leather; 1092
s(134,"Ghostwalker Garb",{15143,15148,15142,15146,15149,15151,15150,15144},nil) --Leather; 134
s(120,"Ghostwalker Garb (Recolor)",{4861,14567,14573,14569,14568,14574,14572,4052},nil) --Leather; 134
s(126,"Ghostwalker Garb (Recolor)",{3000,29502,29503,15344,15345,15341,15347,15348},nil) --Leather; 134
s(139,"Glyphed Garb",{65937,66020,6421,4059,4058,4731,4060},nil) --Leather; 139
s(144,"Glyphed Garb (Recolor)",{65671,4738,6431,4061,6430,4062,4737},nil) --Leather; 139
s(147,"Glyphed Garb (Recolor)",{65701,57490,9924,9922,9923,60919,9917},nil) --Leather; 139
s(159,"Glyphed Garb (Recolor)",{59107,10188,10182,10187,10189,61072,10183,10190},nil) --Leather; 139
s(1145,"Glyphed Garb (Recolor)",{59098,15073,61074,15072,15075,65719,56719},nil) --Leather
s(164,"Grand Garb",{15193,15195,15194,15189,15192,15693,15188,15191},nil) --Leather; 164
s(109,"Grizzly Garb",{15303,15304},nil) --Leather; 109
s(108,"Gypsy Garb",{5341,26020,26023,26024,19044},nil) --Leather; 108
s(116,"Gypsy Garb (Recolor)",{14562,14566,14565,14560,14564,14559,14561},nil) --Leather; 108
s(171,"Haal'eshi Garb",{24708,24702,24701,4124,24704,24703,24706,24707},nil) --Leather; 171
s(1139,"Iceborne Embrace",{72696,72695,72694,72693,72692,72691,72690,72689},1024) --Leather; 1139
s(192,"Iceborne Embrace (Recolor)",{36132,36138,36131,36134,36133,36136,36137},nil) --Leather; 1139
s(194,"Iceborne Embrace (Recolor)",{35613,36154,36148,36150,36152,36153,36149,42872},nil) --Leather; 1139
s(195,"Iceborne Embrace (Recolor)",{51998,72670,72668,72667,72666,72665,72664,51962},8) --Leather; 1139
s(141,"Insignia Garb (Recolor)",{9887,3204,9891,9885,9889,9892,9894},nil) --Leather
s(1667,"Insignia Garb (Recolor)",{30218,20681,20661,20667,20665,20658,31443},nil) --Leather
s(1151,"Nightscape Garb",{8197,8176,8193,8192,8175,31563,9428,94044},nil) --Leather; 1151
s(143,"Nightscape Garb (Recolor)",{7478,18505,7477,7481,7482,7480,7484},nil) --Leather; 1151
s(155,"Nightscape Garb (Recolor)",{31235,27712,10067,10072,10075,10074,10070},nil) --Leather; 1151
s(1296,"Nimble-Knife Armor",{88630,88629,88628,88627,88626,88625,88624,88623},512) --Leather; 1296
s(198,"Nimble-Knife Armor (Recolor)",{55650,55677,55659,55668,55641,55686,55695,55635},nil) --Leather; 1296
s(200,"Nimble-Knife Armor (Recolor)",{56484,56513,56499,56491,56483,56509,56505,56495},nil) --Leather; 1296
s(1299,"Nimble-Knife Armor (Recolor)",{59769,59806,59680,59777,59764,59700,59737,59674},nil) --Leather; 1296
s(140,"Nocturnal Garb",{18478,4456,15155,15157,15152,15160},nil) --Leather; 140
s(125,"Nocturnal Garb (Recolor)",{6607,6603,6601,6605,6600,6602},nil) --Leather; 140
s(128,"Nocturnal Garb (Recolor)",{7359,14580,14579,14581,14578,14584,14585,14587},nil) --Leather; 140
s(138,"Nocturnal Garb (Recolor)",{17005,15362,15360,15365,15366,15361},nil) --Leather; 140
s(145,"Nocturnal Garb (Recolor)",{15370,15369,15372,15374,15376,15377},nil) --Leather
s(1486,"Riverblade Armor",{88697,84244,80732,80723,80687,80714,80705,88022},nil) --Leather; 1486
s(1487,"Riverblade Armor (Recolor)",{101050,101049,101048,101047,101046,101045,101044,101043},nil) --Leather; 1486
s(1488,"Riverblade Armor (Recolor)",{82660,82678,82651,82669,82615,82642,82633,82624},nil) --Leather; 1486
s(1489,"Riverblade Armor (Recolor)",{101119,101111,101110,101108,101103,101100,101099,101098},nil) --Leather; 1486
s(119,"Scouting Garb",{52971,62884,52612,6584,6583,6581,39895,8174},nil) --Leather; 119
s(124,"Scouting Garb (Recolor)",{52606,15129,15128,15127,15125,15126,15120,15122},nil) --Leather; 119
s(129,"Scouting Garb (Recolor)",{52968,52922,9827,9829,9832,9834,9835,4048},nil) --Leather; 119
s(1357,"Scouting Garb (Recolor)",{58995,82877,14584,7284,49449,54874},nil) --Leather; 119
s(137,"Sentinel Garb",{18744,7447,7444,7439,7441,7448,7445,7440},nil) --Leather; 137
s(162,"Sentinel Garb (Recolor)",{15433,15431,15426,15429,15428,15425},nil) --Leather; 137
s(157,"Serpentskin Garb",{9633,8258,8262,8260,8257,8255,14686},nil) --Leather; 157
s(152,"Serpentskin Garb (Recolor)",{15378,15172,15170,15171,15174,15176},nil) --Leather; 157
s(165,"Serpentskin Garb (Recolor)",{10227,10220,10222,10225,10223,10221},nil) --Leather; 157
s(169,"Serpentskin Garb (Recolor)",{15436,15434,15435,15440,15438,15442},nil) --Leather; 157
s(168,"Shadowcraft Armor (Recolor)",{30945,10262,10260,10263,10259,10257,10256},nil) --Leather
s(1320,"Shadowcraft Armor (Recolor)",{31658,31198,29939,31172},nil) --Leather
s(1490,"Silentleaf Armor",{101097,101096,101095,101094,101093,101092,101091,101090},nil) --Leather; 1490
s(1491,"Silentleaf Armor (Recolor)",{84588,84597,83690,83708,83681,83699,83672,83654},nil) --Leather; 1490
s(1492,"Silentleaf Armor (Recolor)",{101035,101034,101033,101031,101030,101029,101028,101027},nil) --Leather; 1490
s(1493,"Silentleaf Armor (Recolor)",{101209,101205,101206,101207,101208,101204,101210,101211},nil) --Leather; 1490
s(1066,"Smoking Pit Armor",{67184,67186,67202,59426,59369,67190,59381,59384},nil) --Leather; 1066
s(1065,"Smoking Pit Armor (Recolor)",{67182,67185,67169,67187,67167,53586,67189,53578},nil) --Leather; 1066
s(1067,"Smoking Pit Armor (Recolor)",{53567,64600,64511,64548,64526,67166,67163,64589},nil) --Leather; 1066
s(1659,"Smoking Pit Armor (Recolor)",{64561,64601,64535,64553,67175},nil) --Leather; 1066
s(163,"Stormshroud Armor (Recolor)",{54727,8300,8296,8299,8301,8298,8293,8295},nil) --Leather
s(166,"Stormshroud Armor (Recolor)",{29804,28051,10152,10150,10153,10149,10147,10145},nil) --Leather
s(1154,"Wicked Leather Armor",{19389,12603,15087,15083,15084,18043},nil) --Leather; 1154
s(161,"Wicked Leather Armor (Recolor)",{10112,10105,10113,10106,10110,10109,10107,3020},nil) --Leather; 1154 --1154 --1154
