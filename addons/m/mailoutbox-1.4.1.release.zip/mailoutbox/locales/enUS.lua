local folder, core = ...
local L = LibStub("AceLocale-3.0"):NewLocale(folder, "enUS", true)

L.PoI = "People of Interest"
L.PoIDesc = "Buyer names you want to stand out."
L.fwDesc = "Hide entries beyond this time"
L.receviedMail = "You made |cffffffff%d|r sales worth a total of %s."
L["Show sales saved by the 'Save sales' setting."] = true
L.showSalesChange = "Show Sales auto set to |cffffffff%s|r."
--~ L["Source"] = true
--~ L["Auction"] = true
--~ L["COD"] = true
--~ L[""] = true
--~ L[""] = true
