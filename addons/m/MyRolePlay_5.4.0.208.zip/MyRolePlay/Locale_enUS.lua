if GetCVar("locale")~="enUS" then return end
local L = mrp.L

L["option_HeightUnit"] = 2 -- 0 = centimetres, 1 = metres, 2 = feet/inches
L["option_WeightUnit"] = 1 -- 0 = kilograms, 1 = pounds, 2 = stone/pounds