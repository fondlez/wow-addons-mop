local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_SendOOM", "deDE", false)

if not L then return end

-- L["Emotion"] = ""
-- L["I have no mana!"] = ""
-- L["Message"] = ""
-- L["Reset if its mana level is more than % ..."] = ""
-- L["Send a message stating that there is no more mana if its level is less than % ..."] = ""
-- L["SendOOM"] = ""
-- L["Send OOM mesage to party/raid?"] = ""
