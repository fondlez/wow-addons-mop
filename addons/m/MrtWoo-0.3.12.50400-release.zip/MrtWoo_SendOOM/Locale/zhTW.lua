local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_SendOOM", "zhTW", false)

if not L then return end

-- L["Emotion"] = ""
L["I have no mana!"] = "我沒有法力了!"
L["Message"] = "訊息"
L["Reset if its mana level is more than % ..."] = "在法力值大於%之後重設"
L["Send a message stating that there is no more mana if its level is less than % ..."] = "在法力值低於%時發送出訊息。"
L["SendOOM"] = "OOM"
L["Send OOM mesage to party/raid?"] = "發送 OOM (沒有法力) 訊息到 隊伍/團隊中?"
