local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_SendOOM", "enUS", true, true)

if not L then return end

L["Emotion"] = true
L["I have no mana!"] = true
L["Message"] = true
L["Reset if its mana level is more than % ..."] = true
L["Send a message stating that there is no more mana if its level is less than % ..."] = true
L["SendOOM"] = "OOM"
L["Send OOM mesage to party/raid?"] = true
