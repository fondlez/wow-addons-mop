﻿local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_SendOOM", "ruRU", false)

if not L then return end

L["Emotion"] = "Эмоция "
L["I have no mana!"] = "У меня нет маны!"
L["Message"] = "Сообщение"
L["Reset if its mana level is more than % ..."] = "Повторно показывать сообщение только после того как уровень маны повысился больше чем на % ..."
L["Send a message stating that there is no more mana if its level is less than % ..."] = "Отправлять сообщение если уровень манны меньше чем % ..."
L["SendOOM"] = "ООМ"
L["Send OOM mesage to party/raid?"] = "Сообщать о том что у Вас кончилась мана в пати/рейд?"
