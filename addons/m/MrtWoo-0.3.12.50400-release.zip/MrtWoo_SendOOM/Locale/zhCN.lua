local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_SendOOM", "zhCN", false)

if not L then return end

L["Emotion"] = "表情动作"
L["I have no mana!"] = "我法力不足！" -- Needs review
L["Message"] = "信息" -- Needs review
L["Reset if its mana level is more than % ..."] = "高于此值时重置%"
L["Send a message stating that there is no more mana if its level is less than % ..."] = "低于此值时发送不足信息%"
L["SendOOM"] = "法力不足通报" -- Needs review
L["Send OOM mesage to party/raid?"] = "发送法力不足信息到队伍/团队？" -- Needs review
