local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_SendOOM", "koKR", false)

if not L then return end

L["Emotion"] = "감정 표현"
L["I have no mana!"] = "마나가 부족해!"
L["Message"] = "메시지"
L["Reset if its mana level is more than % ..."] = "마나가 x% 이상이면 초기화"
L["Send a message stating that there is no more mana if its level is less than % ..."] = "설정수치 미만이면 마나부족 메시지 보냄"
L["SendOOM"] = "마나 부족 알림"
L["Send OOM mesage to party/raid?"] = "파티/공격대에 마나부족 메시지를 보냄"
