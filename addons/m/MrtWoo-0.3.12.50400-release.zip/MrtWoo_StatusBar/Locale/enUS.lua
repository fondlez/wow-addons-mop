local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_StatusBar", "enUS", true, true)

if not L then return end

L["Bottom"] = true
L["Custom"] = true
L["Exalted"] = true
L["Experience in the short form (1k..)?"] = true
L["Freeze"] = true
L["Friendly"] = true
L["Hated"] = true
L["Honored"] = true
L["Hostile"] = true
L["Maximum gain experience"] = true
L["Move"] = true
L["Nuetral"] = true
L["Position"] = true
L["Revered"] = true
L["Show experience?"] = true
L["Show last updatet reputation?"] = true
L["Show me a reputation?"] = true
L["Show me the emblems?"] = true
L["Show statistics about the block spam / flood?"] = true
L["Show status bar?"] = true
L["StatusBar"] = true
L["Top"] = true
L["Unfriendly"] = true
L["Unknown"] = true
