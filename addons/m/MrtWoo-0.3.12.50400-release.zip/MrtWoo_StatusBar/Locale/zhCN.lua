local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_StatusBar", "zhCN", false)

if not L then return end

L["Bottom"] = "底部" -- Needs review
L["Custom"] = "自定义" -- Needs review
L["Exalted"] = "崇拜" -- Needs review
L["Experience in the short form (1k..)?"] = "缩略方式显示经验值(1000=1k)" -- Needs review
L["Freeze"] = "冻结" -- Needs review
L["Friendly"] = "友善" -- Needs review
L["Hated"] = "仇恨" -- Needs review
L["Honored"] = "尊敬" -- Needs review
L["Hostile"] = "敌对" -- Needs review
L["Maximum gain experience"] = "最大获得经验"
L["Move"] = "移动" -- Needs review
L["Nuetral"] = "中立" -- Needs review
L["Position"] = "位置" -- Needs review
L["Revered"] = "崇敬" -- Needs review
L["Show experience?"] = "显示经验值" -- Needs review
L["Show last updatet reputation?"] = "显示最近增加的声望"
L["Show me a reputation?"] = "显示声望"
L["Show me the emblems?"] = "显示徽章"
L["Show statistics about the block spam / flood?"] = "显示垃圾信息过滤统计"
L["Show status bar?"] = "显示状态条？" -- Needs review
L["StatusBar"] = "状态条" -- Needs review
L["Top"] = "顶部" -- Needs review
L["Unfriendly"] = "冷漠" -- Needs review
L["Unknown"] = "未知" -- Needs review
