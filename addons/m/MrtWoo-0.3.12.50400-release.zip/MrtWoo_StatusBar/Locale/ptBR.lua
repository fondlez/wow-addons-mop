local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo_StatusBar", "ptBR", false)

if not L then return end

L["Bottom"] = "Base"
L["Custom"] = "Personalizado"
L["Exalted"] = "Exaltado"
-- L["Experience in the short form (1k..)?"] = ""
L["Freeze"] = "Travar" -- Needs review
L["Friendly"] = "Amigavél" -- Needs review
L["Hated"] = "Odiado" -- Needs review
L["Honored"] = "Honrado" -- Needs review
L["Hostile"] = "Hostíl" -- Needs review
L["Maximum gain experience"] = "Experiência máxima ganha"
L["Move"] = "Mover" -- Needs review
L["Nuetral"] = "Neutro" -- Needs review
L["Position"] = "Posição"
L["Revered"] = "Reverenciado" -- Needs review
L["Show experience?"] = "Mostrar experiência?" -- Needs review
-- L["Show last updatet reputation?"] = ""
L["Show me a reputation?"] = "Mostrar reputação?"
L["Show me the emblems?"] = "Mostrar emblemas?"
L["Show statistics about the block spam / flood?"] = "Mostrar estatísticas sobre o bloqueio de spam?"
-- L["Show status bar?"] = ""
-- L["StatusBar"] = ""
L["Top"] = "Topo"
-- L["Unfriendly"] = ""
L["Unknown"] = "Desconhecido" -- Needs review
