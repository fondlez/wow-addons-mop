﻿local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo", "ruRU", false)

if not L then return end

L["Check new versions?"] = "Проверять наличие новых версий?"
L["Current version of the addon: %s"] = "Текущая версия аддона: %s"
L["Default"] = "По умолчанию"
L["Hello from %s!"] = "Привет вам от %s!"
L["If enabled, on the minimap will display an icon for quick access to settings."] = "Если включено, то на миникарте появится иконка при помощи которой можно будет получить доступ к настройкам аддона."
L["If enabled, the addon will check for new versions of the guild / group"] = "Если включено, то аддон будет проверять наличие новых версий в гильдии/группе... если обнаружит новую версию, то сообщит вам об этом..."
L["New version of addon was found in your party/guild, it's recommended to update"] = "|cff00ff00Внимание!|r В Вашей группе/гильдии обнаружена более новая версия аддона |cff00ff00'MrtWoo'|r, рекомендуется скачать обновление с curse.com"
L["Profiles"] = "Профили"
L["Show icon on minimap?"] = "Отображать иконку на миникарте? "
