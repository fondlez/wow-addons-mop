local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo", "esES", false)

if not L then return end

-- L["Check new versions?"] = ""
-- L["Current version of the addon: %s"] = ""
-- L["Default"] = ""
-- L["Hello from %s!"] = ""
-- L["If enabled, on the minimap will display an icon for quick access to settings."] = ""
-- L["If enabled, the addon will check for new versions of the guild / group"] = ""
-- L["New version of addon was found in your party/guild, it's recommended to update"] = ""
-- L["Profiles"] = ""
-- L["Show icon on minimap?"] = ""
