local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo", "zhCN", false)

if not L then return end

L["Check new versions?"] = "检查新版本?"
L["Current version of the addon: %s"] = "当前插件版本: %s" -- Needs review
L["Default"] = "默认" -- Needs review
L["Hello from %s!"] = "来自 %s 的问候!" -- Needs review
L["If enabled, on the minimap will display an icon for quick access to settings."] = "如启用，将显示一个小地图图标，可快速进入插件设置页面。" -- Needs review
L["If enabled, the addon will check for new versions of the guild / group"] = "如启用，插件将从公会/团队中检查新版本" -- Needs review
L["New version of addon was found in your party/guild, it's recommended to update"] = "|cff00ff00注意!|r 在你的队伍/公会中发现新版本的 |cff00ff00'MrtWoo'|r 插件, 建议访问 curse.com 进行升级" -- Needs review
L["Profiles"] = "配置" -- Needs review
L["Show icon on minimap?"] = "显示小地图图标？" -- Needs review
