local L = LibStub("AceLocale-3.0"):NewLocale("MrtWoo", "enUS", true, true)

if not L then return end

L["Check new versions?"] = true
L["Current version of the addon: %s"] = true
L["Default"] = true
L["Hello from %s!"] = true
L["If enabled, on the minimap will display an icon for quick access to settings."] = true
L["If enabled, the addon will check for new versions of the guild / group"] = true
L["New version of addon was found in your party/guild, it's recommended to update"] = "|cff00ff00Attention!|r New version of |cff00ff00'MrtWoo'|r addon was found in your party/guild, it's recommended to update it from curse.com"
L["Profiles"] = true
L["Show icon on minimap?"] = true
