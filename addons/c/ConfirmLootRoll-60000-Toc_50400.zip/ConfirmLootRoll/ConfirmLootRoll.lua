--[[
	Author: Awbee
	Source: https://www.wowinterface.com/downloads/info15416-ConfirmLootRoll.html
	Modified for MoP 5.4.8 (Interface 50400); logic otherwise unchanged.
]]
function ConfirmLootRoll_OnLoad()
	ConfirmLootRollFrame:RegisterEvent("CONFIRM_DISENCHANT_ROLL");
	ConfirmLootRollFrame:RegisterEvent("CONFIRM_LOOT_ROLL");
	StaticPopupDialogs["CONFIRM_LOOT_ROLL"] = nil;
end

function ConfirmLootRoll_OnEvent(event, ...)
	local arg1, arg2 = ...;
	ConfirmLootRoll(arg1, arg2);
end