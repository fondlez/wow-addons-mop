-- Addon:	ChiBar: constants and variables
-- Author:	Fushui(EU-Azshara)

if select(2, UnitClass("player")) ~= "MONK" then
    return
end

------------------------------------------
--		Creating Variables 				--
------------------------------------------

-- Creating MainArray for all da fun, mon!
ChiBar.VERSIONNUMBER = GetAddOnMetadata("ChiBar", "Version")

-- Some Constants
ChiBar.ICON = "|TInterface\\Addons\\ChiBar\\images\\MonkLightPower:15:15|t"
ChiBar.VERSIONTEXT_1 = ChiBar.ICON .. " |cff00FF96ChiBar Version " .. ChiBar.VERSIONNUMBER .. " " .. ChiBar.ICON
ChiBar.VERSIONTEXT_2 = "|cff00FF96Coding: Fushui (EU-Azshara)   Textures: Ayliara (EU-Azshara)"
ChiBar.BUBBLEDIM = 50
ChiBar.CLASSPOWER = {
	["MONK"] = 12,
	["PALADIN"] = 9,
	}
ChiBar.CLASSPOWERID = ChiBar.CLASSPOWER[select(2, UnitClass("player"))]
ChiBar.FIRST_SLASH_START = 0

-- Texture names
ChiBar.TEXTURES = {
	{"Chinese Dragon",		"chinese_dragon"},
	{"KittyFox",			"kittyfox"},
	{"Minimalistic 1",		"minimalistic_1"},
	{"Minimalistic 2",		"minimalistic_2"},
	{"Rhombus 1",			"rhombus_1"},
	{"Rhombus 2",			"rhombus_2"},
	{"Sphere Simple",		"sphere_simple"},
	{"Sphere Sun 1",		"sphere_sun_1"},
	{"Sphere Sun 2",		"sphere_sun_2"},
	{"Square Simple",		"square_simple"},
	{"Yin & Yang 1",		"yin_yang_1"},
	{"Yin & Yang 2",		"yin_yang_2"},
	{"Yin & Yang 3",		"yin_yang_3"},
}

-- Texture paths (name on position 1 belongs path on position 1, etc.)
--ChiBar.TEXTURE_PATH = {
--
--	}

-- Creating the folderpath of the textures for the addon
ChiBar.textures = {}
local index
for index = 1, #ChiBar.TEXTURES do
	ChiBar.textures[((index*2)-1)] =
		"Interface\\Addons\\ChiBar\\images\\" .. ChiBar.TEXTURES[index][2] .. "_empty.tga"
	ChiBar.textures[(index*2)] =
		"Interface\\Addons\\ChiBar\\images\\" .. ChiBar.TEXTURES[index][2] .. "_glow.tga"
end


------------------------------------------
--		End of Script					--
------------------------------------------