-- Addon:	ChiBar: GUI-creating part
-- Author:	Fushui(EU-Azshara)


-- Disables Addons, if Character is no Monk
if select(2, UnitClass("player")) ~= "MONK" then
    return
end


------------------------------------------
--		GUI								--
------------------------------------------

function ChiBar:createUI()

	-- Creating SubFrame
	ChiBar.Bubbles = {}

	local index
	for index = 1, 5 do
		ChiBar.Bubbles[index] = CreateFrame("Frame", "ChiBubble1" .. index, ChiBar.mainFrame)
	end

	-- Creating Textures
	ChiBar.BGTexture = ChiBar.mainFrame:CreateTexture("BGTexture")
	ChiBar.BGTexture2 = ChiBar.Bubbles[1]:CreateTexture("BGTexture2")
	ChiBar.BGTexture:SetTexture(220, 220, 220, 0.3)
	ChiBar.BGTexture2:SetTexture(250, 250, 250, 0.7)
	ChiBar.BGTexture2:SetAllPoints(ChiBar.mainFrame)
	ChiBar.BGTexture:Hide()
	ChiBar.BGTexture2:Hide()
	ChiBar.Textures0 = {}
	ChiBar.Textures1 = {}
	for index = 1, 5 do
		ChiBar.Textures0[index] = ChiBar.Bubbles[index]:CreateTexture("ChiTexture" .. index .. "0")
		ChiBar.Textures1[index] = ChiBar.Bubbles[index]:CreateTexture("ChiTexture" .. index .. "1")
	end
	
	-- Layer and Strata level
	ChiBar:updateLayerLevel()
	
	-- Orientation
	ChiBar:settingUpOrientation()
	
	-- Setting proberties of the mainFrame
	ChiBar.mainFrame:SetWidth(ChiBar.BUBBLEDIM)
	ChiBar.mainFrame:SetHeight(ChiBar.BUBBLEDIM)
	ChiBar.mainFrame:SetPoint(ChiBarDB.from, UIParent, ChiBarDB.to, ChiBarDB.x, ChiBarDB.y)
	ChiBar.mainFrame:SetScale(ChiBarDB.scale)
	ChiBar:adjustOpacity(ChiBarDB.alpha1, ChiBarDB.alpha2)
	ChiBar:changeColor()
	ChiBar.mainFrame:RegisterForDrag("LeftButton")
	ChiBar.mainFrame:SetMovable(false)

	-- Setting proberties of the subFrames
	for index = 1, 5 do
		ChiBar.Bubbles[index]:SetHeight(ChiBar.BUBBLEDIM)
		ChiBar.Bubbles[index]:SetWidth(ChiBar.BUBBLEDIM)
	end	
	
	-- Setting proberties of the Frames
	for index = 1, 5 do
		ChiBar.Textures0[index]:SetAllPoints(ChiBar.Bubbles[index])
		ChiBar.Textures1[index]:SetAllPoints(ChiBar.Bubbles[index])
		ChiBar.Textures0[index]:SetTexture(ChiBar.textures[((ChiBarDB.savedTexture*2)-1)])
		ChiBar.Textures1[index]:SetTexture(ChiBar.textures[(ChiBarDB.savedTexture*2)])
		ChiBar.Textures1[index]:Hide()
	end
end


------------------------------------------
--		End of Script					--
------------------------------------------