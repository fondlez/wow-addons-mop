local L = LibStub("AceLocale-3.0"):NewLocale("Cosplay", "koKR")
if not L then return end
--
L["Undress"] = "벗기"
L["Target"] = "대상"
L["Open the DressUpFrame"] = "미리보기 창 열기"
L["Undress Button"] = "벗기 버튼"
