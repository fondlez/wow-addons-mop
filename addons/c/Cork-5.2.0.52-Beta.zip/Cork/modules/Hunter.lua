
local myname, Cork = ...
if Cork.MYCLASS ~= "HUNTER" then return end


-- Aspects
Cork:GenerateAdvancedSelfBuffer("Aspects", {13165, 5118, 13159, 61648, 109260})
