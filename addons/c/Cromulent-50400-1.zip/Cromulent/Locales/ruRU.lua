﻿local L = LibStub("AceLocale-3.0"):NewLocale("Cromulent", "ruRU")
if not L then return end
--
L["%d-man"] = "%d-чел."
L["Instances"] = "Cпециальные области"
