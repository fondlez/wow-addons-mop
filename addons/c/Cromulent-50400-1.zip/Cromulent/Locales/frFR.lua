local L = LibStub("AceLocale-3.0"):NewLocale("Cromulent", "frFR")
if not L then return end
--
L["%d-man"] = "%dj"
--L["Instances"] = true
