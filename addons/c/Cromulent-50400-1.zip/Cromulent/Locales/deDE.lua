local L = LibStub("AceLocale-3.0"):NewLocale("Cromulent", "deDE")
if not L then return end
--
L["%d-man"] = "%d Spieler"
L["Instances"] = "Instanzen"
