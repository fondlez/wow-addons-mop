local L = LibStub("AceLocale-3.0"):NewLocale("Cromulent", "zhTW")
if not L then return end
--
L["%d-man"] = "%d人"
L["Instances"] = "副本"
