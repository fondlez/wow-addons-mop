local UpdateRate = 0.5
local TimeSinceLastUpdate = 0
local PresenceFrame = CreateFrame('Frame')
PresenceFrame:SetHeight(64)
PresenceFrame:SetWidth(64)
PresenceFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
PresenceFrame:EnableMouse(false)
PresenceFrame:Hide()
local t = PresenceFrame:CreateTexture(nil,"BACKGROUND")
t:SetBlendMode("ADD")
t:SetAllPoints(PresenceFrame)
t:SetTexCoord(0,1,0,1)

PresenceFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
PresenceFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
PresenceFrame:RegisterEvent("PLAYER_REGEN_DISABLED")


local function CheckPresence()
	local currentSpec = GetSpecialization()
	
	if currentSpec == 1 then
	t:SetTexture("Interface\\ICONS\\Spell_Deathknight_BloodPresence")
	local icon, name, active, castable = GetShapeshiftFormInfo(1)
		if not active then
			PresenceFrame:Show()
		else
			PresenceFrame:Hide()
		end
	else
	if currentSpec == 2 then
		t:SetTexture("Interface\\ICONS\\Spell_Deathknight_FrostPresence")
	elseif currentSpec == 3 then
		t:SetTexture("Interface\\ICONS\\Spell_Deathknight_UnholyPresence")
	end
	local icon2, name2, active2, castable2 = GetShapeshiftFormInfo(2)
	local icon3, name3, active3, castable3 = GetShapeshiftFormInfo(3)
		if active2 or active3 then
			PresenceFrame:Hide()
		else
			PresenceFrame:Show()	
		end
	end		
end

local function Presence_OnEvent(self, event, ...)
local playerClass, englishClass = UnitClass("player");
	if englishClass ~= "DEATHKNIGHT" then
		return;
	end
	
	if event == "ACTIVE_TALENT_GROUP_CHANGED" or event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_REGEN_DISABLED" then	
		CheckPresence()
	end
end

local function Presence_OnUpdate(self, elapsed)
local playerClass, englishClass = UnitClass("player");
	if englishClass ~= "DEATHKNIGHT" then
		return;
	end
	TimeSinceLastUpdate = TimeSinceLastUpdate + elapsed;
	if (TimeSinceLastUpdate > UpdateRate) then
		CheckPresence();
		TimeSinceLastUpdate = 0;
	end
end


PresenceFrame:SetScript("OnUpdate", Presence_OnUpdate) 
PresenceFrame:SetScript("OnEvent", Presence_OnEvent) 