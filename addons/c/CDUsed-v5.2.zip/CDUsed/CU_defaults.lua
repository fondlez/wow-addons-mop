--[[
  Cooldown Used by Kiki/Esp�rance - European Conseil des Ombres
]]


--------------- Shared Constantes ---------------

CU_SPELLS_COOLDOWN_USED = 1; -- Spell used by raid member on someone
CU_SPELLS_AURA_GAINED = 2; -- Raid member gained an aura
CU_SPELLS_AURA_LOST = 3; -- Raid member lost an aura
CU_SPELLS_INTERRUPTED = 4; -- Raid member interrupted someone
CU_SPELLS_INTERRUPT_USED_SUCCESS = 5; -- SpellCastSuccess with an interrupt spell
CU_SPELLS_INTERRUPT_USED_FAILED = 6; -- SpellFailed with an interrupt
CU_SPELLS_TAUNTED = 7; -- Raid member successfully taunted
CU_SPELLS_TAUNT_MISSED = 8; -- Raid member failed to taunt
CU_SPELLS_RESURRECT = 9; -- Resurrection spell used
CU_SPELLS_CREATIONS = 10; -- Raid member creating things
CU_SPELLS_FEAST = 11; -- Feasts

CU_SpellTypeToName = {
 [CU_SPELLS_COOLDOWN_USED] = "CooldownUsed",
 [CU_SPELLS_AURA_GAINED] = "AuraGained",
 [CU_SPELLS_AURA_LOST] = "AuraLost",
 [CU_SPELLS_INTERRUPTED] = "Interrupted",
 [CU_SPELLS_INTERRUPT_USED_SUCCESS] = "InterruptUsedSuccess",
 [CU_SPELLS_INTERRUPT_USED_FAILED] = "InterruptUsedFailed",
 [CU_SPELLS_TAUNTED] = "Taunted",
 [CU_SPELLS_TAUNT_MISSED] = "TauntMissed",
 [CU_SPELLS_RESURRECT] = "SpellRez",
 [CU_SPELLS_CREATIONS] = "Creations",
 [CU_SPELLS_FEAST] = "Feast",
};

--------------- Spells ---------------

-- Spell creations
local TOY_TRAIN_SET = 61031;

-- Feasts
local GREAT_FEAST = 57301;
local FISH_FEAST = 57426;
local BOUNTIFUL_FEAST = 66476;
local DRAGON_FEAST = 87643;
local SEAFOOD_FEAST = 87644;
local GOBELIN_BARBECUE_FEAST = 87915; -- 84351

-- Cauldron
local CAULDRON_OF_BATTLE = 92649;

-- Cooldown spells
 -- Death Knight
 local UNHOLY_FRENZY = 49016;
 local ICEBOUND_FORTITUDE = 48792;
 local VAMPIRIC_BLOOD = 55233;
 local DANCING_RUNE_WEAPON = 81256;
 local ANTIMAGIC_SHELL = 48707;
 local RAISE_ALLY = 61999;
 -- Druid
 local INNERVATE = 29166;
 local REBIRTH = 20484;
 local SURVIVAL_INSTINCTS = 61336;
 local FRENZIED_REGENERATION = 22842;
 local BARKSKIN = 22812;
 -- Hunter
 local MISDIRECTION = 34477;
 local FEIGN_DEATH = 5384;
 local DETERRENCE = 19263;
 -- Mage
 local ICE_BLOCK = 45438;
 local INVISIBILITY = 66;
 -- Paladin
 local DIVINE_PROTECTION = 498;
 local HAND_OF_SACRIFICE = 6940;
 local LAY_ON_HANDS = 633;
 local DIVINE_GUARDIAN = 70940;
 local ARDENT_DEFENDER = 31850;
 local HAND_OF_SALVATION = 1038;
 local DEVOTION_AURA = 31821;
 local HAND_OF_PROTECTION = 1022;
 local DIVINE_PLEA = 54428;
 local GUARDIAN_ANCIENT_KINGS = 86150; -- Currently bugged, only the SPELL_CAST is in the combat log, AURA_GAINED/AURA_LOST is not shown
 --local GUARDIAN_ANCIENT_KINGS_TANK = 86659; -- The buff
 --local GUARDIAN_ANCIENT_KINGS_HEAL = 86669; -- The buff
 --local GUARDIAN_ANCIENT_KINGS_DPS = 86698; -- The buff
 local HOLY_RADIANCE = 82327;
 -- Priest
 local PAIN_SUPPRESSION = 33206;
 local GUARDIAN_SPIRIT = 47788;
 local POWER_INFUSION = 10060;
 local LEAP_OF_FAITH = 73325;
 -- Rogue
 local TRICKOFTRADE = 57934;
 local CLOAK_OF_SHADOWS = 31224;
 -- Warlock
 local SOUL_SHATTER = 29858;
 -- Warrior
 local LAST_STAND = 12975;
 local SHIELD_WALL = 871;

-- Taunts
 -- Death Knight
 local DARK_COMMAND = 56222;
 -- Druid
 local GROWL = 6795;
 -- Hunter
 local DISTRACTING_SHOT = 20736;
 -- Paladin
 local HAND_OF_RECKONING = 62124;
 local RIGHTEOUS_DEFENSE = 31789;
 -- Warrior
 local TAUNT = 355;

-- Interrupts
 -- Death Knight
 local MIND_FREEZE = 47528;
 -- Druid
 local MAIM_INTERRUPT = 32747; -- Druid's Maim
 local SKULL_BASH_INTERRUPT = 93985;
 local SKULL_BASH_BEAR = 80964;
 local SKULL_BASH_CAT = 80965;
 --local SOLAR_BEAM = 78675;
 local SOLAR_BEAM = 97547;
 -- Hunter
 local SILENCING_SHOT = 34490;
 -- Mage
 local COUNTERSPELL = 2139;
 -- Paladin
 local AVENGERS_SHIELD = 31935;
 local HAMMER_OF_JUSTICE = 853;
 local REBUKE = 96231;
 -- Rogue
 local KICK = 1766;
 -- Shaman
 local WIND_SHEAR = 57994;
 -- Warrior
 local PUMMEL = 6552;
 local INTERCEPT = 20252;
 -- Monk
 local SPEAR_HAND_STRIKE = 116709;
 -- Common
 local ARCANE_TORRENT_MANA = 28730;
 local ARCANE_TORRENT_ENERGY = 25046;
 local ARCANE_TORRENT_RAGE = 69179;
 local ARCANE_TORRENT_FOCUS = 80483;
 local ARCANE_TORRENT_RUNIC_POWER = 50613;

--------------- Templates ---------------

CU_Template_All = {
 [CU_SPELLS_CREATIONS] = {
  [TOY_TRAIN_SET] = true,
 },
 [CU_SPELLS_FEAST] = {
  [GREAT_FEAST] = true,
  [FISH_FEAST] = true,
  [BOUNTIFUL_FEAST] = true,
  [DRAGON_FEAST] = true,
  [SEAFOOD_FEAST] = true,
  [GOBELIN_BARBECUE_FEAST] = true,
  [CAULDRON_OF_BATTLE] = true,
 },
 [CU_SPELLS_AURA_GAINED] = {
  [SURVIVAL_INSTINCTS] = true,
  [FRENZIED_REGENERATION] = true,
  [BARKSKIN] = true,
  [DIVINE_PROTECTION] = true,
  --[GUARDIAN_ANCIENT_KINGS] = true, -- Currently bugged, only the SPELL_CAST is in the combat log, AURA_GAINED/AURA_LOST is not shown
  [LAST_STAND] = true,
  [SHIELD_WALL] = true,
  [HAND_OF_SACRIFICE] = true,
  [PAIN_SUPPRESSION] = true,
  [POWER_INFUSION] = true,
  [GUARDIAN_SPIRIT] = true,
  [ICEBOUND_FORTITUDE] = true,
  [VAMPIRIC_BLOOD] = true,
  [DANCING_RUNE_WEAPON] = true,
  [ARDENT_DEFENDER] = true,
  [DIVINE_PLEA] = true,
  [INVISIBILITY] = true,
 },
 [CU_SPELLS_AURA_LOST] = {
  [SURVIVAL_INSTINCTS] = true,
  [FRENZIED_REGENERATION] = true,
  [BARKSKIN] = true,
  [DIVINE_PROTECTION] = true,
  --[GUARDIAN_ANCIENT_KINGS] = true, -- Currently bugged, only the SPELL_CAST is in the combat log, AURA_GAINED/AURA_LOST is not shown
  [LAST_STAND] = true,
  [SHIELD_WALL] = true,
  [HAND_OF_SACRIFICE] = true,
  [PAIN_SUPPRESSION] = true,
  [POWER_INFUSION] = true,
  [GUARDIAN_SPIRIT] = true,
  [ICEBOUND_FORTITUDE] = true,
  [VAMPIRIC_BLOOD] = true,
  [DANCING_RUNE_WEAPON] = true,
  [ARDENT_DEFENDER] = true,
  [DIVINE_PLEA] = true,
  [INVISIBILITY] = true,
 },
 [CU_SPELLS_INTERRUPTED] = {
  [KICK] = true,
  [HAMMER_OF_JUSTICE] = true,
  [WIND_SHEAR] = true,
  [COUNTERSPELL] = true,
  [REBUKE] = true,
  [MIND_FREEZE] = true,
  [MAIM_INTERRUPT] = true,
  [INTERCEPT] = true,
  [SKULL_BASH_INTERRUPT] = true,
  [SKULL_BASH_BEAR] = true,
  [SKULL_BASH_CAT] = true,
  [SILENCING_SHOT] = true,
  [SOLAR_BEAM] = true,
  [PUMMEL] = true,
  [SPEAR_HAND_STRIKE] = true,
  [ARCANE_TORRENT_MANA] = true,
  [ARCANE_TORRENT_ENERGY] = true,
  [ARCANE_TORRENT_RAGE] = true,
  [ARCANE_TORRENT_FOCUS] = true,
  [ARCANE_TORRENT_RUNIC_POWER] = true,
  [AVENGERS_SHIELD] = true,
 },
 [CU_SPELLS_INTERRUPT_USED_SUCCESS] = {
  [KICK] = true,
  [HAMMER_OF_JUSTICE] = true,
  [WIND_SHEAR] = true,
  [COUNTERSPELL] = true,
  [REBUKE] = true,
  [MIND_FREEZE] = true,
  [MAIM_INTERRUPT] = true,
  [INTERCEPT] = true,
  [SKULL_BASH_INTERRUPT] = true,
  [SKULL_BASH_BEAR] = true,
  [SKULL_BASH_CAT] = true,
  [SOLAR_BEAM] = true,
  [SILENCING_SHOT] = true,
  [PUMMEL] = true,
  [SPEAR_HAND_STRIKE] = true,
  [ARCANE_TORRENT_MANA] = true,
  [ARCANE_TORRENT_ENERGY] = true,
  [ARCANE_TORRENT_RAGE] = true,
  [ARCANE_TORRENT_FOCUS] = true,
  [ARCANE_TORRENT_RUNIC_POWER] = true,
  [AVENGERS_SHIELD] = true,
 },
 [CU_SPELLS_INTERRUPT_USED_FAILED] = {
  [KICK] = true,
  [HAMMER_OF_JUSTICE] = true,
  [WIND_SHEAR] = true,
  [COUNTERSPELL] = true,
  [REBUKE] = true,
  [MIND_FREEZE] = true,
  [MAIM_INTERRUPT] = true,
  [INTERCEPT] = true,
  [SKULL_BASH_INTERRUPT] = true,
  [SKULL_BASH_BEAR] = true,
  [SKULL_BASH_CAT] = true,
  [SOLAR_BEAM] = true,
  [SILENCING_SHOT] = true,
  [PUMMEL] = true,
  [SPEAR_HAND_STRIKE] = true,
  [ARCANE_TORRENT_MANA] = true,
  [ARCANE_TORRENT_ENERGY] = true,
  [ARCANE_TORRENT_RAGE] = true,
  [ARCANE_TORRENT_FOCUS] = true,
  [ARCANE_TORRENT_RUNIC_POWER] = true,
  [AVENGERS_SHIELD] = true,
 },
 [CU_SPELLS_TAUNTED] = {
  [HAND_OF_RECKONING] = true,
  [GROWL] = true,
  [TAUNT] = true,
  [DARK_COMMAND] = true,
  [RIGHTEOUS_DEFENSE] = true,
 },
 [CU_SPELLS_TAUNT_MISSED] = {
  [HAND_OF_RECKONING] = true,
  [GROWL] = true,
  [TAUNT] = true,
  [DARK_COMMAND] = true,
  [RIGHTEOUS_DEFENSE] = true,
 },
 [CU_SPELLS_COOLDOWN_USED] = {
  [GUARDIAN_ANCIENT_KINGS] = true,
  [LAY_ON_HANDS] = true,
  [DIVINE_GUARDIAN] = true,
  [INNERVATE] = true,
  [UNHOLY_FRENZY] = true,
  [REBIRTH] = true,
  [RAISE_ALLY] = true,
  [HAND_OF_SALVATION] = true,
  [DEVOTION_AURA] = true,
  [HOLY_RADIANCE] = true,
  [HAND_OF_PROTECTION] = true,
  [MISDIRECTION] = true,
  [TRICKOFTRADE] = true,
  [CLOAK_OF_SHADOWS] = true,
  [ICE_BLOCK] = true,
  [FEIGN_DEATH] = true,
  [DETERRENCE] = true,
  [ANTIMAGIC_SHELL] = true,
  [SOUL_SHATTER] = true,
  [LEAP_OF_FAITH] = true,
 },
 [CU_SPELLS_RESURRECT] = {
  [REBIRTH] = true,
  [RAISE_ALLY] = true,
 },
};

CU_Template_Tank = {
 [CU_SPELLS_CREATIONS] = {
 },
 [CU_SPELLS_FEAST] = {
 },
 [CU_SPELLS_AURA_GAINED] = {
  [SURVIVAL_INSTINCTS] = true,
  [FRENZIED_REGENERATION] = true,
  [BARKSKIN] = true,
  [DIVINE_PROTECTION] = true,
  --[GUARDIAN_ANCIENT_KINGS] = true, -- Currently bugged, only the SPELL_CAST is in the combat log, AURA_GAINED/AURA_LOST is not shown
  [LAST_STAND] = true,
  [SHIELD_WALL] = true,
  [HAND_OF_SACRIFICE] = true,
  [PAIN_SUPPRESSION] = true,
  [GUARDIAN_SPIRIT] = true,
  [ICEBOUND_FORTITUDE] = true,
  [VAMPIRIC_BLOOD] = true,
  [DANCING_RUNE_WEAPON] = true,
  [ARDENT_DEFENDER] = true,
  [INVISIBILITY] = true,
 },
 [CU_SPELLS_AURA_LOST] = {
  [SURVIVAL_INSTINCTS] = true,
  [FRENZIED_REGENERATION] = true,
  [BARKSKIN] = true,
  [DIVINE_PROTECTION] = true,
  --[GUARDIAN_ANCIENT_KINGS] = true, -- Currently bugged, only the SPELL_CAST is in the combat log, AURA_GAINED/AURA_LOST is not shown
  [LAST_STAND] = true,
  [SHIELD_WALL] = true,
  [HAND_OF_SACRIFICE] = true,
  [PAIN_SUPPRESSION] = true,
  [GUARDIAN_SPIRIT] = true,
  [ICEBOUND_FORTITUDE] = true,
  [VAMPIRIC_BLOOD] = true,
  [DANCING_RUNE_WEAPON] = true,
  [ARDENT_DEFENDER] = true,
  [INVISIBILITY] = true,
 },
 [CU_SPELLS_INTERRUPTED] = {
 },
 [CU_SPELLS_INTERRUPT_USED_SUCCESS] = {
 },
 [CU_SPELLS_INTERRUPT_USED_FAILED] = {
 },
 [CU_SPELLS_TAUNTED] = {
  [HAND_OF_RECKONING] = true,
  [GROWL] = true,
  [TAUNT] = true,
  [DARK_COMMAND] = true,
  [RIGHTEOUS_DEFENSE] = true,
 },
 [CU_SPELLS_TAUNT_MISSED] = {
  [HAND_OF_RECKONING] = true,
  [GROWL] = true,
  [TAUNT] = true,
  [DARK_COMMAND] = true,
  [RIGHTEOUS_DEFENSE] = true,
 },
 [CU_SPELLS_COOLDOWN_USED] = {
  [GUARDIAN_ANCIENT_KINGS] = true,
  [MISDIRECTION] = true,
  [TRICKOFTRADE] = true,
 },
 [CU_SPELLS_RESURRECT] = {
 },
};

CU_Template_Heal = {
 [CU_SPELLS_CREATIONS] = {
 },
 [CU_SPELLS_FEAST] = {
 },
 [CU_SPELLS_AURA_GAINED] = {
  [SURVIVAL_INSTINCTS] = true,
  [FRENZIED_REGENERATION] = true,
  [BARKSKIN] = true,
  [DIVINE_PROTECTION] = true,
  --[GUARDIAN_ANCIENT_KINGS] = true, -- No buff gained :/
  [LAST_STAND] = true,
  [SHIELD_WALL] = true,
  [HAND_OF_SACRIFICE] = true,
  [PAIN_SUPPRESSION] = true,
  [POWER_INFUSION] = true,
  [GUARDIAN_SPIRIT] = true,
  [ICEBOUND_FORTITUDE] = true,
  [VAMPIRIC_BLOOD] = true,
  [DANCING_RUNE_WEAPON] = true,
  [ARDENT_DEFENDER] = true,
  [DIVINE_PLEA] = true,
 },
 [CU_SPELLS_AURA_LOST] = {
  [SURVIVAL_INSTINCTS] = true,
  [FRENZIED_REGENERATION] = true,
  [BARKSKIN] = true,
  [DIVINE_PROTECTION] = true,
  --[GUARDIAN_ANCIENT_KINGS] = true, -- No buff gained :/
  [LAST_STAND] = true,
  [SHIELD_WALL] = true,
  [HAND_OF_SACRIFICE] = true,
  [PAIN_SUPPRESSION] = true,
  [POWER_INFUSION] = true,
  [GUARDIAN_SPIRIT] = true,
  [ICEBOUND_FORTITUDE] = true,
  [VAMPIRIC_BLOOD] = true,
  [DANCING_RUNE_WEAPON] = true,
  [ARDENT_DEFENDER] = true,
  [DIVINE_PLEA] = true,
 },
 [CU_SPELLS_INTERRUPTED] = {
 },
 [CU_SPELLS_INTERRUPT_USED_SUCCESS] = {
 },
 [CU_SPELLS_INTERRUPT_USED_FAILED] = {
 },
 [CU_SPELLS_TAUNTED] = {
 },
 [CU_SPELLS_TAUNT_MISSED] = {
 },
 [CU_SPELLS_COOLDOWN_USED] = {
  [GUARDIAN_ANCIENT_KINGS] = true,
  [LAY_ON_HANDS] = true,
  [DIVINE_GUARDIAN] = true,
  [INNERVATE] = true,
  [REBIRTH] = true,
  [RAISE_ALLY] = true,
  [DEVOTION_AURA] = true,
  [HOLY_RADIANCE] = true,
  [ANTIMAGIC_SHELL] = true,
 },
 [CU_SPELLS_RESURRECT] = {
  [REBIRTH] = true,
  [RAISE_ALLY] = true,
 },
};

CU_Template_Kicker = {
 [CU_SPELLS_CREATIONS] = {
 },
 [CU_SPELLS_FEAST] = {
 },
 [CU_SPELLS_AURA_GAINED] = {
 },
 [CU_SPELLS_AURA_LOST] = {
 },
 [CU_SPELLS_INTERRUPTED] = {
  [KICK] = true,
  [HAMMER_OF_JUSTICE] = true,
  [WIND_SHEAR] = true,
  [COUNTERSPELL] = true,
  [REBUKE] = true,
  [MIND_FREEZE] = true,
  [MAIM_INTERRUPT] = true,
  [INTERCEPT] = true,
  [SKULL_BASH_INTERRUPT] = true,
  [SKULL_BASH_BEAR] = true,
  [SKULL_BASH_CAT] = true,
  [SOLAR_BEAM] = true,
  [SILENCING_SHOT] = true,
  [PUMMEL] = true,
  [SPEAR_HAND_STRIKE] = true,
  [ARCANE_TORRENT_MANA] = true,
  [ARCANE_TORRENT_ENERGY] = true,
  [ARCANE_TORRENT_RAGE] = true,
  [ARCANE_TORRENT_FOCUS] = true,
  [ARCANE_TORRENT_RUNIC_POWER] = true,
  [AVENGERS_SHIELD] = true,
 },
 [CU_SPELLS_INTERRUPT_USED_SUCCESS] = {
  [KICK] = true,
  [HAMMER_OF_JUSTICE] = true,
  [WIND_SHEAR] = true,
  [COUNTERSPELL] = true,
  [REBUKE] = true,
  [MIND_FREEZE] = true,
  [MAIM_INTERRUPT] = true,
  [INTERCEPT] = true,
  [SKULL_BASH_INTERRUPT] = true,
  [SKULL_BASH_BEAR] = true,
  [SKULL_BASH_CAT] = true,
  [SOLAR_BEAM] = true,
  [SILENCING_SHOT] = true,
  [PUMMEL] = true,
  [SPEAR_HAND_STRIKE] = true,
  [ARCANE_TORRENT_MANA] = true,
  [ARCANE_TORRENT_ENERGY] = true,
  [ARCANE_TORRENT_RAGE] = true,
  [ARCANE_TORRENT_FOCUS] = true,
  [ARCANE_TORRENT_RUNIC_POWER] = true,
  [AVENGERS_SHIELD] = true,
 },
 [CU_SPELLS_INTERRUPT_USED_FAILED] = {
  [KICK] = true,
  [HAMMER_OF_JUSTICE] = true,
  [WIND_SHEAR] = true,
  [COUNTERSPELL] = true,
  [REBUKE] = true,
  [MIND_FREEZE] = true,
  [MAIM_INTERRUPT] = true,
  [INTERCEPT] = true,
  [SKULL_BASH_INTERRUPT] = true,
  [SKULL_BASH_BEAR] = true,
  [SKULL_BASH_CAT] = true,
  [SOLAR_BEAM] = true,
  [SILENCING_SHOT] = true,
  [PUMMEL] = true,
  [SPEAR_HAND_STRIKE] = true,
  [ARCANE_TORRENT_MANA] = true,
  [ARCANE_TORRENT_ENERGY] = true,
  [ARCANE_TORRENT_RAGE] = true,
  [ARCANE_TORRENT_FOCUS] = true,
  [ARCANE_TORRENT_RUNIC_POWER] = true,
  [AVENGERS_SHIELD] = true,
 },
 [CU_SPELLS_TAUNTED] = {
 },
 [CU_SPELLS_TAUNT_MISSED] = {
 },
 [CU_SPELLS_COOLDOWN_USED] = {
 },
 [CU_SPELLS_RESURRECT] = {
 },
};

