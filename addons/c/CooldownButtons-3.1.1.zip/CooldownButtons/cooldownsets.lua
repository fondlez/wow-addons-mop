--[[
Name: CooldownButtons
Project Revision: @project-revision@
File Revision: @file-revision@ 
Author(s): Netrox
Website: http://www.wowace.com/projects/cooldownbuttons/
Git Repo: git://git.wowace.com/wow/cooldownbuttons/mainline.git
License: All rights reserved.
]]

local CDB = CDB

local function CreateTableEntrys(...)
    local count = select('#', ...)
    local entrys = {}
    for i = 1, count, 1 do
        entrys[tostring(select(i, ...))] = true
    end
    return entrys
end

function CDB:InitDefaultCooldownSets()
    local class = select(2, UnitClass("player"))
    local sets = {
        ["**"] = {
            ["icon"] = "Interface\\Icons\\INV_Misc_QuestionMark",
            ["type"] = "Spell",
            ["ids"] = {
                ["**"] = false,
            },
        }
    }
    if class == "WARLOCK" then 
        sets["Summon Infernal/Doomguard"] = {
            ["icon"] = "Interface\\Icons\\warlock_summon_doomguard",
            ["ids"] = {
                ["1122"]   = true, -- Infernal
                ["18540"]  = true, -- Doomguard
                ["112927"] = true, -- Terrorguard
				["112921"] = true, -- Abyssal
            },
        }
    elseif class == "DRUID" then 
        sets["Incarnation"] = {
            ["icon"] = "Interface\\Icons\\spell_druid_incarnation",
            ["ids"] = {
                ["106731"] = true, -- Talent
                ["33891"]  = true, -- Restoration
                ["102558"] = true, -- Guardian
                ["102560"] = true, -- Moonkin
                ["102543"] = true, -- Feral
            },
        }
    elseif class == "WARRIOR" then 
        sets["Shouts"] = {
            ["icon"] = "Interface\\Icons\\ability_warrior_battleshout",
            ["ids"] = {
                ["6673"] = true, -- Battle Shout
                ["469"]  = true, -- Commanding Shout
            },
        }
    elseif class == "HUNTER" then 
        sets["Fire Traps"] = {
            ["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
            ["ids"] = {
                -- Immolation
                ["13795"] = true,
                -- Explosive
                ["13813"] = true,
            },
        }
        sets["Frost Traps"] = {
            ["icon"] = "Interface\\Icons\\Spell_Frost_FreezingBreath",
            ["ids"] = {
                -- Freezing Trap
                ["1499"] = true,
                -- Frost Trap
                ["13809"] = true,
            },
        }
    elseif class == "SHAMAN" then 
        sets["Shocks"] = {
            ["icon"] = "Interface\\AddOns\\CooldownButtons\\Icons\\shocks.tga",
            ["ids"] = {
                -- Earth Shock
                ["8042"] = true,
                -- Flame Shock
                ["8050"] = true,
                -- Frost Shock
                ["8056"] = true,
            },
        }
	--[[
    elseif class == "PALADIN" then 
        -- nothing to do here? :)
    ]]
    end
    sets["Potions"] = {
        ["icon"] = "Interface\\AddOns\\CooldownButtons\\Icons\\healmana.tga",
        ["type"] = "Item",
        -- Got IDs from wowhead.com ( Filter: http://www.wowhead.com/items=0?filter=ty=1;cr=62;crs=3;crv=60 ) 
        ["ids"] = CreateTableEntrys(109222,109217,109219,109220,109221,109218,109223,109226,117415,118006,118262,92954,93742,98061,98062,98063,76089,76093,76094,76095,76096,76097,76098,92941,92942,92943,113585,116266,116278,76090,76092,58488,57099,57194,64994,64993,63145,63144,58090,58146,58145,58091,57193,58487,63300,57191,67415,57192,40211,43569,40217,40216,40215,40214,40213,40212,41166,40093,40087,40081,40077,33448,33447,43570,42545,40067,22850,34440,39671,22849,31677,31841,31854,31855,32783,32784,32840,32844,32845,32846,32847,32909,32910,38351,31838,31852,31853,31840,31839,22847,22846,22845,22844,22842,22841,22839,22838,22837,22836,33093,23823,31676,43530,22832,32902,32903,32948,22871,23822,33092,32947,22829,43531,39327,32904,32905,22828,22826,33935,28101,18253,33934,13506,116277,20002,28100,13444,13456,13457,13458,13459,13461,20008,116276,13462,13455,3386,13446,17348,17351,18841,13443,13442,116275,3387,3928,9144,12190,17349,17352,18839,4623,9030,9036,6149,6050,6052,5633,6049,3827,1710,116267,5634,6048,5816,3385,3384,929,6372,6051,107640,54213,4596,3087,2459,2456,2455,5631,858,118),
    }
    return sets
end
