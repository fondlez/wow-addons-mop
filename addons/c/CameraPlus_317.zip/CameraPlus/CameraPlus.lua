--[[
	author: Zax
	content:
		globales: SCAM_
		functions: CameraPlus.
		XML: Scam_
		XML UI: Scam_ui_
		main UI frame: Scam_ui_mainFrame
		event frame: Scam_ui_eventFrame
		XML config: Scam_cfg_
	todo : 
--]]

---------------------------------------------------------------------------------------
------------------------------------- VARIABLES ---------------------------------------
SCAM_NAME = "CameraPlus";
SCAM_VERS = GetAddOnMetadata(SCAM_NAME,"Version");
CameraPlus = {};
local ZaxLibMin = 1.0; -- version minimale requise de ZaxLib
ZAXLIB_NAME = SCAM_NAME; -- pour debug
local enTest = false; -- /////

local cameraOn = false; -- flag pour sauvegarde et restauration CVars (mode film et UI)
SCAM_UP_DOWN = 0.1; -- ///// valeur absolue d'un cran pour les changements a la volee de yaw, pitch et zoom (globale pour acces depuis fichier Bindings.xml)

function CameraPlus.getLocal(key)
	----------- pour traduction (voir localization.lua) : ne pas deplacer !!!
	if (SCAM_LOCAL_TBL[key] == nil) then
		return key;
	else
		return SCAM_LOCAL_TBL[key];
	end;
end;

----------------------------------------- saved et init
SCAM_SAVED = {};

function CameraPlus.initData()
	if (enTest) then ZaxLib:echo(SCAM_NAME.."=========== INIT DATA"); end;
	wipe(SCAM_SAVED);
	SCAM_SAVED["version"] = SCAM_VERS;
	SCAM_SAVED["inited"] = 0;
	
	SCAM_SAVED["showOwnName"] = GetCVar("UnitNameOwn");
	SCAM_SAVED["showPlayersName"] = GetCVar("UnitNameFriendlyPlayerName");
	SCAM_SAVED["showPlayersGuild"] = GetCVar("UnitNamePlayerGuild");
	SCAM_SAVED["showPlayersPVPrank"] = GetCVar("UnitNamePlayerPVPTitle");
	SCAM_SAVED["showPNJsName"] = GetCVar("UnitNameNPC");
	SCAM_SAVED["showPetName"] = GetCVar("UnitNameFriendlyPetName");
	SCAM_SAVED["showTarget"] = 1;
	SCAM_SAVED["showBubbles"] = 0;
	SCAM_SAVED["showCombat"] = 0;
	
	SCAM_SAVED["alphaMainUI"] = 0;

	SCAM_SAVED["yawSpeed"] = ZaxLib:nombreParDefaut(GetCVar("cameraYawMoveSpeed"),2,200,180);
	SCAM_SAVED["pitchSpeed"] = ZaxLib:nombreParDefaut(GetCVar("cameraPitchMoveSpeed"),2,200,80);
	SCAM_SAVED["zoomSpeed"] = ZaxLib:nombreParDefaut(GetCVar("cameraDistanceMoveSpeed"),1,50,20);
	
	SCAM_SAVED["distanceMax"] = ZaxLib:nombreParDefaut(GetCVar("cameraDistanceMax"),15,25,15);
	SCAM_SAVED["distanceMaxFactor"] = ZaxLib:nombreParDefaut(GetCVar("cameraDistanceMaxFactor"),1,3,1);
end

-----------------------------------------
local visibleFPS, visibleMinimap, visibleParty;

SCAM_NOMSCVAR = {}; -- globale pour acces depuis fichier XML
SCAM_NOMSCVAR[1]= "UnitNameOwn"; -- SCAM_SAVED["showOwnName"]
SCAM_NOMSCVAR[2]= "UnitNameFriendlyPlayerName"; -- SCAM_SAVED["showPlayersName"]
SCAM_NOMSCVAR[3]= "UnitNameEnemyPlayerName"; -- SCAM_SAVED["showPlayersName"]
SCAM_NOMSCVAR[4]= "UnitNamePlayerGuild"; -- SCAM_SAVED["showPlayersGuild"]
SCAM_NOMSCVAR[5]= "UnitNamePlayerPVPTitle"; -- SCAM_SAVED["showPlayersPVPrank"]
SCAM_NOMSCVAR[6]= "UnitNameNPC"; -- SCAM_SAVED["showPNJsName"]

SCAM_NOMSCVAR[7]= "UnitNameFriendlyPetName"; -- SCAM_SAVED["showPetName"]
SCAM_NOMSCVAR[8]= "UnitNameEnemyPetName"; -- SCAM_SAVED["showPetName"]
SCAM_NOMSCVAR[9]= "UnitNameFriendlyGuardianName"; -- SCAM_SAVED["showPetName"]
SCAM_NOMSCVAR[10]= "UnitNameEnemyGuardianName"; -- SCAM_SAVED["showPetName"]
SCAM_NOMSCVAR[11] = "UnitNameEnemyGuardianName"; -- SCAM_SAVED["showPetName"]
------ ajout v3.11 (WoW 5)
SCAM_NOMSCVAR[28] = "UnitNameFriendlyTotemName"; -- SCAM_SAVED["showPetName"]
SCAM_NOMSCVAR[29] = "UnitNameEnemyTotemName"; -- SCAM_SAVED["showPetName"]
SCAM_NOMSCVAR[30]= "UnitNameGuildTitle"; -- SCAM_SAVED["showPlayersGuild"]
SCAM_NOMSCVAR[31]= "UnitNameFriendlySpecialNPCName"; -- SCAM_SAVED["showPNJsName"]
SCAM_NOMSCVAR[32]= "UnitNameNonCombatCreatureName"; -- SCAM_SAVED["showPNJsName"]
--[[
	-------------------------- WoW 4
	UnitNameOwn	0
	UnitNameFriendlyPlayerName	1
	UnitNameEnemyPlayerName	1
	UnitNamePlayerGuild	1
	UnitNamePlayerPVPTitle 1
	UnitNameNPC	0
	UnitNameFriendlyPetName	1
	UnitNameEnemyPetName	1
	UnitNameFriendlyGuardianName	0
	UnitNameEnemyGuardianName	0
	-------------------------- WoW 5
	UnitNameFriendlyTotemName	0
	UnitNameEnemyTotemName	0
	UnitNameFriendlySpecialNPCName	1
	UnitNameGuildTitle	1
	UnitNameHostleNPC	0
	UnitNameNonCombatCreatureName	0
	
	-------------------------- WoW 4 et 5
	nameplateShowFriends	0
	nameplateShowEnemies	0
	nameplateShowFriendlyGuardians	1
	nameplateShowEnemyGuardians	1
	nameplateShowFriendlyPets	1
	nameplateShowEnemyPets	1
	nameplateShowFriendlyTotems	1
	nameplateShowEnemyTotems	1
--]]

SCAM_NOMSCVAR[12]= "ObjectSelectionCircle"; -- SCAM_SAVED["showTarget"]
SCAM_NOMSCVAR[13]= "unitHighlights"; -- SCAM_SAVED["showTarget"]
SCAM_NOMSCVAR[14]= "ChatBubbles"; -- SCAM_SAVED["showBubbles"]
SCAM_NOMSCVAR[15]= "ChatBubblesParty"; -- SCAM_SAVED["showBubbles"]
SCAM_NOMSCVAR[16]= "CombatDamage"; -- SCAM_SAVED["showCombat"]
SCAM_NOMSCVAR[17]= "CombatHealing"; -- SCAM_SAVED["showCombat"]
SCAM_NOMSCVAR[18]= "PetMeleeDamage"; -- SCAM_SAVED["showCombat"]
SCAM_NOMSCVAR[19]= "PetSpellDamage"; -- SCAM_SAVED["showCombat"]

SCAM_NOMSCVAR[20]= "nameplateShowFriends"; -- SCAM_SAVED["friendPlate"]
SCAM_NOMSCVAR[21]= "nameplateShowEnemies"; -- SCAM_SAVED["ennemyPlate"]

------ ajout v3.11 (WoW 5)
SCAM_NOMSCVAR[22] = "nameplateShowFriendlyGuardians"; -- SCAM_SAVED["friendPlate"]
SCAM_NOMSCVAR[23] = "nameplateShowEnemyGuardians"; -- SCAM_SAVED["ennemyPlate"]
SCAM_NOMSCVAR[24] = "nameplateShowFriendlyPets"; -- SCAM_SAVED["friendPlate"]
SCAM_NOMSCVAR[25] = "nameplateShowEnemyPets"; -- SCAM_SAVED["ennemyPlate"]
SCAM_NOMSCVAR[26] = "nameplateShowFriendlyTotems"; -- SCAM_SAVED["friendPlate"]
SCAM_NOMSCVAR[27] = "nameplateShowEnemyTotems"; -- SCAM_SAVED["ennemyPlate"]
		
local listeValsCVarUI = {};
local nomsCVarCamera = {"cameraYawMoveSpeed","cameraPitchMoveSpeed","cameraDistanceMoveSpeed"};
local listeValsCVarCamera = {};

---------------------------------------------------------------------------------------
--------------------------------------- EVENTS ----------------------------------------
function CameraPlus.eventHandler(self,event,...)
	if (event == "PLAYER_LOGIN") then
		CameraPlus.chargement();
	elseif (event == "PLAYER_LOGOUT") then
		if (cameraOn) then CameraPlus.restoreMainUI(); end; -- secu si quittage alors que les CVars sont modifiees
		CameraPlus.saveSettings();
	end;
end

---------------------------------------------------------------------------------------
-------------------------- CHARGEMENT / COMMANDES /BINDINGS ---------------------------
function CameraPlus.chargement()
	------------------------------- slash commandes
	SlashCmdList["SCAM_CMD"] = CameraPlus.slashCmd;
		SLASH_SCAM_CMD1 = "/cameraplus";
		SLASH_SCAM_CMD2 = "/camplus";
		SLASH_SCAM_CMD3 = "/scam";

	------------------------------- bindings
	BINDING_HEADER_SCAM = SCAM_NAME
	BINDING_NAME_SCAMSHOWUI = CameraPlus.getLocal("Settings (UI)")
	BINDING_NAME_SCAMMOVIE = CameraPlus.getLocal("Movie environment")
	BINDING_NAME_SCAMROTL = CameraPlus.getLocal("Rotate left")
	BINDING_NAME_SCAMROTR = CameraPlus.getLocal("Rotate right")
	BINDING_NAME_SCAMZOOMIN = CameraPlus.getLocal("Zoom in")
	BINDING_NAME_SCAMZOOMOUT = CameraPlus.getLocal("Zoom out")
	BINDING_NAME_SCAMUP = CameraPlus.getLocal("Up")
	BINDING_NAME_SCAMDOWN = CameraPlus.getLocal("Down")
	
	BINDING_NAME_SCAMYAWUP = CameraPlus.getLocal("Increase rotation speed")
	BINDING_NAME_SCAMYAWDOWN = CameraPlus.getLocal("Decrease rotation speed")
	BINDING_NAME_SCAMPITCHUP = CameraPlus.getLocal("Increase up and down speed")
	BINDING_NAME_SCAMPITCHDOWN = CameraPlus.getLocal("Decrease up and down speed")
	BINDING_NAME_SCAMZOOMUP = CameraPlus.getLocal("Increase zoom speed")
	BINDING_NAME_SCAMZOOMDOWN = CameraPlus.getLocal("Decrease zoom speed")
	
	------------------------------- zaxlib
	local addonStatus = true;
	if (ZAXLIB_VERS == nil or ZAXLIB_VERS < ZaxLibMin) then
		if (DEFAULT_CHAT_FRAME) then ChatFrame1:AddMessage(SCAM_NAME.." ERROR: ZaxLib v"..ZaxLibMin.." not loaded! "..SCAM_NAME.." will not properly work.",0.9,0.4,0.4); end;
		addonStatus = false;
	end;
	
	------------------------------- settings
	if (not ZaxLib:isEmpty(SCAM_SAVED)) then
		--if (SCAM_SAVED["version"] ~= SCAM_VERS) then CameraPlus.initData(); end; --/////
	else
		CameraPlus.initData();
	end;
	if (enTest) then ZaxLib:echoTable(SCAM_SAVED,true,"   "); end;
	
	------------------------------- suite
	--if (SCAM_SAVED["inited"] ~= 1) then
		if (addonStatus) then ZaxLib:echo("|cFF618FBF"..SCAM_NAME.." "..SCAM_VERS.." |cFFCBA934"..CameraPlus.getLocal("loaded. Type /cameraplus to display settings UI.")); end;-- ZaxLib:getBindedKey() pas encore dispo a ce stade ???
	--end;
end

---------------------------------------------------------------------------------------
-------------------------------------- SLASH CMD --------------------------------------
function CameraPlus.slashCmd(arg)
	local param2 = 0;
	local tblParams = ZaxLib:explode(arg," ",2);
	if (tblParams[1] ~= nil) then
		tblParams[1] = strlower(tblParams[1]);
		
		if (tblParams[1] == "ui" or tblParams[1] == "settings" or tblParams[1] == "options") then
			CameraPlus.showUI();
		elseif (tblParams[1] == "yaw" or tblParams[1] == "rotation") then
			param2 = ZaxLib:strToNumber(tblParams[2]);
			CameraPlus.setYawVitesse(param2);
		elseif (tblParams[1] == "pitch") then
			param2 = ZaxLib:strToNumber(tblParams[2]);
			CameraPlus.setPitchVitesse(param2);
		elseif (tblParams[1] == "zoom") then
			param2 = ZaxLib:strToNumber(tblParams[2]);
			CameraPlus.setZoomVitesse(param2);
		elseif (tblParams[1] == "max") then
			param2 = ZaxLib:strToNumber(tblParams[2]);
			CameraPlus.setDistanceMax(param2);
		elseif (tblParams[1] == "factor") then
			param2 = ZaxLib:strToNumber(tblParams[2]);
			CameraPlus.setDistanceMaxFactor(param2);
		elseif (tblParams[1] == "info" or tblParams[1] == "infos" or tblParams[1] == "cvar") then
			CameraPlus.echoSettings();
		elseif (tblParams[1] == "reset") then
			CameraPlus.reset();
		elseif (tblParams[1] == "help") then
			CameraPlus.help();
		elseif (tblParams[1] == "test") then
			CameraPlus.fcnTest(tblParams[2]);
		elseif (tblParams[1] == "debug") then
			CameraPlus.toggleDebug();
		else
			ZaxLib:echo(SCAM_NAME.." ERROR: unknown parameter '"..tblParams[1].."'.","red");
		end;
	else
		CameraPlus.help();
	end;
end

function CameraPlus.setYawVitesse(valeur)
	if (valeur ~= nil) then
		local newVal = ZaxLib:strToNumber(valeur);
		if (newVal > 0) then
			SCAM_SAVED["yawSpeed"] = newVal;
			if (Scam_ui_mainFrame:IsVisible()) then
				Scam_ui_yaw_Slider:SetValue(newVal);
			else
				ZaxLib:echo(SCAM_NAME..": rotation speed set to "..newVal,"yellow");
			end;
		else
			ZaxLib:echo(SCAM_NAME..": bad value for rotation speed!","red");
		end;
	end;
end

function CameraPlus.setPitchVitesse(valeur)
	if (valeur ~= nil) then
		local newVal = ZaxLib:strToNumber(valeur);
		if (newVal > 0) then
			SCAM_SAVED["pitchSpeed"] = newVal;
			if (Scam_ui_mainFrame:IsVisible()) then
				Scam_ui_pitch_Slider:SetValue(newVal);
			else
				ZaxLib:echo(SCAM_NAME..": pitch speed set to "..newVal,"yellow");
			end;
		else
			ZaxLib:echo(SCAM_NAME..": bad value for pitch speed!","red");
		end;
	end;
end

function CameraPlus.setZoomVitesse(valeur)
	if (valeur ~= nil) then
		local newVal = ZaxLib:strToNumber(valeur);
		if (newVal > 0) then
			SCAM_SAVED["zoomSpeed"] = newVal;
			if (Scam_ui_mainFrame:IsVisible()) then
				Scam_ui_zoom_Slider:SetValue(newVal);
			else
				ZaxLib:echo(SCAM_NAME..": zoom speed set to "..newVal,"yellow");
			end;
		else
			ZaxLib:echo(SCAM_NAME..": bad value for zoom speed!","red");
		end;
	end;
end

function CameraPlus.setDistanceMax(valeur)
	if (valeur ~= nil) then
		local newVal = ZaxLib:strToNumber(valeur);
		if (newVal > 0) then
			SCAM_SAVED["distanceMax"] = newVal;
			SetCVar("cameraDistanceMax",newVal);
			if (Scam_ui_mainFrame:IsVisible()) then
				Scam_ui_distance_SliderMax:SetValue(newVal);
			else
				ZaxLib:echo(SCAM_NAME..": distance max set to "..newVal,"yellow");
			end;
		else
			ZaxLib:echo(SCAM_NAME..": bad value for distance max!","red");
		end;
	end;
end

function CameraPlus.setDistanceMaxFactor(valeur)
	if (valeur ~= nil) then
		local newVal = ZaxLib:strToNumber(valeur);
		if (newVal > 0) then
			SCAM_SAVED["distanceMaxFactor"] = newVal;
			SetCVar("cameraDistanceMaxFactor",newVal);
			if (Scam_ui_mainFrame:IsVisible()) then
				Scam_ui_distance_SliderMaxFactor:SetValue(newVal);
			else
				ZaxLib:echo(SCAM_NAME..": distance max factor set to "..newVal,"yellow");
			end;
		else
			ZaxLib:echo(SCAM_NAME..": bad value for distance max factor!","red");
		end;
	end;
end

function CameraPlus.yawChange(modification) -------- modification "a la volee" par raccourcis-clavier
	local minValue, maxValue = 2, 200; -- /////
	local newValue = max(minValue,min(maxValue, SCAM_SAVED["yawSpeed"] + CameraPlus.myFloor(SCAM_SAVED["yawSpeed"] * modification)));
	if (newValue ~= SCAM_SAVED["yawSpeed"]) then
		--ZaxLib:echo(SCAM_SAVED["yawSpeed"].."--->"..newValue);
		SCAM_SAVED["yawSpeed"] = newValue;
		if (cameraOn) then SetCVar("cameraYawMoveSpeed",newValue); end;
	end;
end

function CameraPlus.pitchChange(modification) -------- modification "a la volee" par raccourcis-clavier
	local minValue, maxValue = 2, 200; -- /////
	local newValue = max(minValue,min(maxValue, SCAM_SAVED["pitchSpeed"] + CameraPlus.myFloor(SCAM_SAVED["pitchSpeed"] * modification)));
	if (newValue ~= SCAM_SAVED["pitchSpeed"]) then
		--ZaxLib:echo(SCAM_SAVED["pitchSpeed"].."--->"..newValue);
		SCAM_SAVED["pitchSpeed"] = newValue;
		if (cameraOn) then SetCVar("cameraPitchMoveSpeed",newValue); end;
	end;
end

function CameraPlus.zoomChange(modification) -------- modification "a la volee" par raccourcis-clavier
	local minValue, maxValue = 1, 50; -- /////
	local newValue = max(minValue,min(maxValue, SCAM_SAVED["zoomSpeed"] + CameraPlus.myFloor(SCAM_SAVED["zoomSpeed"] * modification)));
	if (newValue ~= SCAM_SAVED["zoomSpeed"]) then
		--ZaxLib:echo(SCAM_SAVED["zoomSpeed"].."--->"..newValue);
		SCAM_SAVED["zoomSpeed"] = newValue;
		if (cameraOn) then SetCVar("cameraDistanceMoveSpeed",newValue); end;
	end;
end

function CameraPlus.reset()
	local uiVisible = Scam_ui_mainFrame:IsVisible();
	CameraPlus.closeUI();
	
	for i = 1,11,1 do
		SetCVar(SCAM_NOMSCVAR[i],0);
	end
	for i = 12,19,1 do
		SetCVar(SCAM_NOMSCVAR[i],1);
	end
	for i = 20,27,1 do
		SetCVar(SCAM_NOMSCVAR[i],0);
	end
	for i = 28,32,1 do
		SetCVar(SCAM_NOMSCVAR[i],1);
	end
	--------------- 
	SetCVar("cameraYawMoveSpeed",180);
	SetCVar("cameraPitchMoveSpeed",80);
	SetCVar("cameraDistanceMoveSpeed",20);
	
	SetCVar("cameraDistanceMax",15);
	SetCVar("cameraDistanceMaxFactor",1);
	--------------
	
	CameraPlus.initData(); -- MAJ SCAM_SAVED
	if (uiVisible) then
		CameraPlus.showUI(); -- re-affichage des options si necessaire
	else
		ZaxLib:echo(SCAM_NAME..": "..CameraPlus.getLocal("all settings reset to default."),"yellow");
	end;
end

function CameraPlus.echoSettings()
	local cvarCam =  {"cameraDistance","cameraPitch","cameraPivot","","cameraYawMoveSpeed","cameraYawSmoothMax","cameraYawSmoothMin","cameraYawSmoothSpeed","",
"cameraPitchMoveSpeed","cameraPitchSmoothSpeed","","cameraDistanceMax","cameraDistanceMaxFactor","","cameraDistanceMoveSpeed","cameraDistanceSmoothSpeed","","cameraSmooth","cameraSmoothYaw","cameraSmoothPitch","cameraSmoothTimeMax","cameraSmoothTimeMin"};
	ZaxLib:echo(SCAM_NAME.." Camera CVars settings: -----------","blue");
	for i,valeur in pairs(cvarCam) do
		if (valeur == "") then
			ZaxLib:echo("--------","grey");
		else
			ZaxLib:echo(valeur.." = "..ZaxLib:nilSiNul(GetCVar(valeur)),"grey");
		end;
	end;
	ZaxLib:echo("-----------------------------------------------","blue");
end

function CameraPlus.fcnTest(arg)
	--
	echo("UnitNameFriendlyPetName---"..GetCVar("UnitNameFriendlyPetName"))
end

function CameraPlus.toggleDebug()
	enTest = not enTest;
	ZaxLib:echo(SCAM_NAME..": debug "..ZaxLib:booleanToStr(enTest)..".","orange");
end

function CameraPlus.help()
	InterfaceOptionsFrame_OpenToCategory(Scam_cfg_frame);
	InterfaceOptionsFrame_OpenToCategory(Scam_cfg_frame);-- r�p�tition pour bug WoW 5.4
end

---------------------------------------------------------------------------------------
------------------------------------- MODE FILM ---------------------------------------
function CameraPlus.modeFilm()
	if (cameraOn) then --------- fin du mode film : re-affichage
		CameraPlus.restoreMainUI();
		cameraOn = false;
	else ---------------------- passage en mode film : masquage
		cameraOn = true;
		visibleFPS = FramerateText:IsVisible();
		CameraPlus.affecteMainUI();
	end;
	if (visibleFPS) then ToggleFramerate(); end;
end

function CameraPlus.sauveCVars() -- sauvegarde des variables d'affichage et de vitesse
	if (enTest) then ZaxLib:echo(SCAM_NAME.." "..time().." -------------->>> SAUVE"); end;
	for index, nomCVar in ipairs(SCAM_NOMSCVAR) do
		listeValsCVarUI[nomCVar] = GetCVar(nomCVar);
	end
	for i, nomCVar in ipairs(nomsCVarCamera) do
		listeValsCVarCamera[nomCVar] = GetCVar(nomCVar);
	end
end

function CameraPlus.restaureCVars() -- restauration des variables d'affichage et de vitesse
	if (enTest) then ZaxLib:echo(SCAM_NAME.." "..time().." <<<-------------- RESTAURE"); end;
	for index, nomCVar in ipairs(SCAM_NOMSCVAR) do
		SetCVar(nomCVar,listeValsCVarUI[nomCVar]);
	end
	for i, nomCVar in ipairs(nomsCVarCamera) do
		SetCVar(nomCVar,listeValsCVarCamera[nomCVar]);
	end
end

function CameraPlus.affecteMainUI()
	CameraPlus.sauveCVars();
	visibleMinimap = Minimap:IsVisible(); -- 3.13
	if (CompactRaidFrameContainer == nil) then -- 3.14
		visibleParty = false;
	else
		visibleParty = CompactRaidFrameContainer:IsVisible();
	end;
	-------------- affichage noms et bulles dialogues
	SetCVar(SCAM_NOMSCVAR[1],ZaxLib:strToNumber(SCAM_SAVED["showOwnName"]));
	
	---------- ajout 2.1 pour namePlates : a placer avant d'effectuer "showPlayersName" !
	if (SCAM_SAVED["showPlayersName"] == 0 or SCAM_SAVED["showPNJsName"] == 0) then
		for i = 20,27,1 do
			SetCVar(SCAM_NOMSCVAR[i],0);
		end
	end;
	----------
	SetCVar(SCAM_NOMSCVAR[2],ZaxLib:strToNumber(SCAM_SAVED["showPlayersName"]));
	SetCVar(SCAM_NOMSCVAR[3],ZaxLib:strToNumber(SCAM_SAVED["showPlayersName"]));
	SetCVar(SCAM_NOMSCVAR[4],ZaxLib:strToNumber(SCAM_SAVED["showPlayersGuild"]));
	SetCVar(SCAM_NOMSCVAR[5],ZaxLib:strToNumber(SCAM_SAVED["showPlayersPVPrank"]));
	SetCVar(SCAM_NOMSCVAR[6],ZaxLib:strToNumber(SCAM_SAVED["showPNJsName"]));
	SetCVar(SCAM_NOMSCVAR[7],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[8],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[9],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[10],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[11],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[12],ZaxLib:strToNumber(SCAM_SAVED["showTarget"]));
	SetCVar(SCAM_NOMSCVAR[13],ZaxLib:strToNumber(SCAM_SAVED["showTarget"]));
	SetCVar(SCAM_NOMSCVAR[14],ZaxLib:strToNumber(SCAM_SAVED["showBubbles"]));
	SetCVar(SCAM_NOMSCVAR[15],ZaxLib:strToNumber(SCAM_SAVED["showBubbles"]));
	SetCVar(SCAM_NOMSCVAR[16],ZaxLib:strToNumber(SCAM_SAVED["showCombat"]));
	SetCVar(SCAM_NOMSCVAR[17],ZaxLib:strToNumber(SCAM_SAVED["showCombat"]));
	SetCVar(SCAM_NOMSCVAR[18],ZaxLib:strToNumber(SCAM_SAVED["showCombat"]));
	SetCVar(SCAM_NOMSCVAR[19],ZaxLib:strToNumber(SCAM_SAVED["showCombat"]));
	------ ajout v3.11 (WoW 5)
	SetCVar(SCAM_NOMSCVAR[28],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[29],ZaxLib:strToNumber(SCAM_SAVED["showPetName"]));
	SetCVar(SCAM_NOMSCVAR[30],ZaxLib:strToNumber(SCAM_SAVED["showPlayersGuild"]));
	SetCVar(SCAM_NOMSCVAR[31],ZaxLib:strToNumber(SCAM_SAVED["showPNJsName"]));
	SetCVar(SCAM_NOMSCVAR[32],ZaxLib:strToNumber(SCAM_SAVED["showPNJsName"]));
	
	-------------- UI
	if (SCAM_SAVED["alphaMainUI"] == 0 and visibleMinimap) then Minimap:Hide(); end;
	if (SCAM_SAVED["alphaMainUI"] == 0 and visibleParty) then CompactRaidFrameContainer:Hide(); end;-- ajout 3.13
	UIParent:SetAlpha(SCAM_SAVED["alphaMainUI"]);
	-------------- valeurs camera
	SetCVar("cameraYawMoveSpeed",ZaxLib:nombreParDefaut(SCAM_SAVED["yawSpeed"],2,200,180));
 	SetCVar("cameraPitchMoveSpeed",ZaxLib:nombreParDefaut(SCAM_SAVED["pitchSpeed"],2,200,80));
	SetCVar("cameraDistanceMoveSpeed",ZaxLib:nombreParDefaut(SCAM_SAVED["zoomSpeed"],1,50,20));
end;

function CameraPlus.restoreMainUI()
	UIParent:SetAlpha(1);
	if (visibleMinimap) then Minimap:Show(); end;
	if (visibleParty) then CompactRaidFrameContainer:Show(); end;-- ajout 3.13
	CameraPlus.restaureCVars();
end

---------------------------------------------------------------------------------------
------------------------------------- SETTINGS UI -------------------------------------
function CameraPlus.showUI()
	if (Scam_ui_mainFrame:IsVisible()) then
		CameraPlus.closeUI();
	else
		Scam_ui_mainFrame:Show(); -- voir OnShow du fichier XML
	end;
end

function CameraPlus.closeUI()
	Scam_ui_mainFrame:Hide();
	Scam_ui_mainFrame:Hide(); -- voir OnHide du fichier XML
end

function CameraPlus.uiShown()
	cameraOn = true;
	CameraPlus.affecteMainUI();
end

function CameraPlus.uiClosed()
	--ColorPickerFrame:Hide();
	cameraOn = false;
	CameraPlus.restoreMainUI();
end

---------------------------------------------------------------------------------------
------------------------------------ FCNS INTERNES ------------------------------------
function CameraPlus.saveSettings()
	SCAM_SAVED["inited"] = 1;
end

function CameraPlus.myFloor(valeur) -- floor perso pour gerer differemment les nombres negatifs
	if (valeur >= 0) then
		return ceil(valeur);
	else
		return floor(valeur);
	end;
end

---------------------------------------------------------------------------------------
-------------------------------------- UI CONFIG --------------------------------------
-- voir aussi <OnLoad> de ConfigFrame.xml
-- affichage direct du panneau de config : InterfaceOptionsFrame_OpenToCategory(xxxxxx_cfg_frame);

function CameraPlus.config(panel)
	panel.name = SCAM_NAME; -- Set the name for the Category for the Panel
	panel.okay = function (self) CameraPlus.configOK(); end; -- When the player clicks okay, run this function.
	panel.cancel = function (self) CameraPlus.configCancel(); end; -- When the player clicks cancel, run this function.
	panel.default = function (self) CameraPlus.configDefault(); end; -- When the player clicks the default button, run this function.
	--panel.refresh = function (self) CameraPlus.configRefresh(); end; -- This method will run when the Interface Options frame calls its OnShow function and after panel.default
	InterfaceOptions_AddCategory(panel); -- Add the panel to the Interface Options
end

function CameraPlus.configOK()
	--if (Scam_ui_mainFrame:IsVisible()) then -- sinon, ca concerne pas cet addon
	-- unused : la sauvegarde est deja faite
end

function CameraPlus.configCancel()
	--if (Scam_ui_mainFrame:IsVisible()) then -- sinon, ca concerne pas cet addon
	-- unused : la sauvegarde est deja faite
end

function CameraPlus.configDefault()
	if (Scam_cfg_frame:IsVisible()) then -- sinon, ca concerne pas cet addon
		CameraPlus.reset();
		CameraPlus.configRefresh();
	end;
end

function CameraPlus.configRefresh()
	-- unused
end

function CameraPlus.getHelpText()
	local touche = ZaxLib:getBindedKey("SCAMMOVIE");
	if (touche == nil) then
		return CameraPlus.getLocal("Bind keys to switch to Movie Environment and for camera movements.");
	else
		return (touche.." "..CameraPlus.getLocal("is defined to switch to Movie Environment").."\n\n"..CameraPlus.getLocal("See included ReadMe text file for more infos about supported slash-commands."));
	end;
end
