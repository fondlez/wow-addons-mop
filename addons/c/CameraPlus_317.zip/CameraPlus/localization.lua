SCAM_LOCAL_TBL = {};
-- voir fichier .lua

----------------------------------------------------------
if (GetLocale() == "frFR") then
	SCAM_LOCAL_TBL["Settings (UI)"] = "R\195\169glages (UI)";
	SCAM_LOCAL_TBL["Movie environment"] = "Mode film";
	SCAM_LOCAL_TBL["Rotate left"] = "Rotation gauche";
	SCAM_LOCAL_TBL["Rotate right"] = "Rotation droite";
	SCAM_LOCAL_TBL["Up"] = "Monter";
	SCAM_LOCAL_TBL["Down"] = "Descendre";
	SCAM_LOCAL_TBL["Zoom in"] = "Zoom avant";
	SCAM_LOCAL_TBL["Zoom out"] = "Zoom arri\195\168re";
	SCAM_LOCAL_TBL["Increase rotation speed"] = "Augmenter vitesse rotation";
	SCAM_LOCAL_TBL["Decrease rotation speed"] = "Diminuer vitesse rotation";
	SCAM_LOCAL_TBL["Increase up and down speed"] = "Augmenter vitesse verticale";
	SCAM_LOCAL_TBL["Decrease up and down speed"] = "Diminuer vitesse verticale";
	SCAM_LOCAL_TBL["Increase zoom speed"] = "Augmenter vitesse zoom";
	SCAM_LOCAL_TBL["Decrease zoom speed"] = "Diminuer vitesse zoom";
	
	SCAM_LOCAL_TBL["loaded. Type /cameraplus to display settings UI."] = "charg\195\169. Entrer /cameraplus pour afficher le panneau des options.";
	SCAM_LOCAL_TBL["all settings reset to defaults."] = "les r\195\169glages ont \195\169t\195\169 r\195\169initialis\195\169s.";
	
	SCAM_LOCAL_TBL["Settings"] = "Options";
	SCAM_LOCAL_TBL["Reset to default"] = "Par d\195\169faut";
	
	SCAM_LOCAL_TBL["settings"] = "options";
	SCAM_LOCAL_TBL["Bind keys to switch to Movie Environment and for camera movements."] = "D\195\169finissez les touches pour basculer en Mode Film et pour les mouvements de cam\195\169ra.";
	SCAM_LOCAL_TBL["is defined to switch to Movie Environment"] = "est la touche d\195\169finie pour activer le Mode Film.";
	SCAM_LOCAL_TBL["See included ReadMe text file for more infos about supported slash-commands."] = "Consultez le document ReadMe inclus pour la liste des commandes-slash support\195\169es.";
	SCAM_LOCAL_TBL["Main UI transparency in Movie Environment:"] = "Transparence de l\'UI principale en mode film :";
	SCAM_LOCAL_TBL["Hidden"] = "Masqu\195\169e";
	SCAM_LOCAL_TBL["Visible"] = "Visible";
	SCAM_LOCAL_TBL["Hide these UI parts in Movie Environment:"] = "Parties de l\'interface \195\160 masquer en Mode Film :";
	SCAM_LOCAL_TBL["Own name visible"] = "Nom perso visible";
	SCAM_LOCAL_TBL["NPCs\'name visible"] = "Nom des PNJs visible";
	SCAM_LOCAL_TBL["Pets\'name visible"] = "Nom des familiers visible";
	SCAM_LOCAL_TBL["Players\' name visible"] = "Nom des joueurs visible";
	SCAM_LOCAL_TBL["Guild\'s name visible"] = "Nom de la guilde visible";
	SCAM_LOCAL_TBL["Players\' PVP title visible"] = "Titre JcJ des joueurs visible";
	SCAM_LOCAL_TBL["Show main UI"] = "Afficher l\'UI principale";
	SCAM_LOCAL_TBL["Chat bubbles visible"] = "Bulles de dialogue visibles";
	SCAM_LOCAL_TBL["Combat text visible"] = "Textes de combat visibles";
	SCAM_LOCAL_TBL["Hilite target"] = "Cible visible";
	SCAM_LOCAL_TBL["Camera movements speed in Movie Environment:"] = "Vitesse des mouvements de cam\195\169ra en Mode Film :";
	SCAM_LOCAL_TBL["Horizontal rotation speed (yaw)"] = "Vitesse de rotation horizontale (yaw)";
	SCAM_LOCAL_TBL["Vertical rotation speed (pitch)"] = "Vitesse de rotation verticale (pitch)";
	SCAM_LOCAL_TBL["Zoom speed"] = "Vitesse de zoom";
	SCAM_LOCAL_TBL["Camera distance (out of Movie Environment):"] = "Distance cam\195\169ra (hors Mode Film) :";
	SCAM_LOCAL_TBL["Distance max"] = "Distance max";
	SCAM_LOCAL_TBL["Distance max factor"] = "Facteur de distance max";
	SCAM_LOCAL_TBL["Default"] = "Par d\195\169faut";
	SCAM_LOCAL_TBL["Close"] = "Fermer";
	
elseif (GetLocale() == "zhCN") then
	SCAM_LOCAL_TBL["Settings (UI)"] = "\230\143\146\228\187\182\232\174\190\231\189\174\230\136\143\231\170\151\229\143\163";
	SCAM_LOCAL_TBL["Movie environment"] = "\229\189\177\231\137\135\229\189\149\229\136\182\230\168\161\229\188\143";
	SCAM_LOCAL_TBL["Rotate left"] = "\233\149\156\229\164\180\229\183\166\230\151\139\232\189\172";
	SCAM_LOCAL_TBL["Rotate right"] = "\233\149\156\229\164\180\229\143\179\230\151\139\232\189\172";
	SCAM_LOCAL_TBL["Up"] = "\233\149\156\229\164\180\229\144\145\228\184\138";
	SCAM_LOCAL_TBL["Down"] = "\233\149\156\229\164\180\229\144\145\228\184\139";
	SCAM_LOCAL_TBL["Zoom in"] = "\233\149\156\229\164\180\230\139\137\232\191\145";
	SCAM_LOCAL_TBL["Zoom out"] = "\233\149\156\229\164\180\230\139\137\232\191\156";
	SCAM_LOCAL_TBL["Increase rotation speed"] = "Increase rotation speed";
	SCAM_LOCAL_TBL["Decrease rotation speed"] = "Decrease rotation speed";
	SCAM_LOCAL_TBL["Increase up and down speed"] = "Increase up and down speed";
	SCAM_LOCAL_TBL["Decrease up and down speed"] = "Decrease up and down speed";
	SCAM_LOCAL_TBL["Increase zoom speed"] = "Increase zoom speed";
	SCAM_LOCAL_TBL["Decrease zoom speed"] = "Decrease zoom speed";

	SCAM_LOCAL_TBL["loaded. Type /cameraplus to display settings UI."] = "loaded. Type /cameraplus to display settings UI.";
	SCAM_LOCAL_TBL["all settings reset to defaults."] = "all settings reset to defaults.";
	
	SCAM_LOCAL_TBL["Settings"] = "Settings";
	SCAM_LOCAL_TBL["Reset to default"] = "Reset to default";
	
	SCAM_LOCAL_TBL["settings"] = "\232\174\190\231\189\174\231\170\151\229\143\163";
	SCAM_LOCAL_TBL["Bind keys to switch to Movie Environment and for camera movements."] = "\232\175\183\229\156\168\230\140\137\233\148\174\231\187\145\229\174\154\228\184\173\228\184\186\233\149\156\229\164\180\231\167\187\229\138\168\229\146\140\229\189\149\229\136\182\230\168\161\229\188\143\231\187\145\229\174\154\230\140\137\233\148\174";
	SCAM_LOCAL_TBL["is defined to switch to Movie Environment"] = "is defined to switch to Movie Environment";
	SCAM_LOCAL_TBL["See included ReadMe text file for more infos about supported slash-commands."] = "See included ReadMe text file for more infos about supported slash-commands.";
	SCAM_LOCAL_TBL["Main UI transparency in Movie Environment:"] = "Main UI transparency in movie environment:";
	SCAM_LOCAL_TBL["Hidden"] = "Hidden";
	SCAM_LOCAL_TBL["Visible"] = "Visible";
	SCAM_LOCAL_TBL["Hide these UI parts in Movie Environment:"] = "\229\156\168\229\189\149\229\136\182\230\168\161\229\188\143\228\184\139\233\154\144\232\151\143\228\187\165\228\184\139\230\143\146\228\187\182\233\131\168\229\136\134";
	SCAM_LOCAL_TBL["Own name visible"] = "Own name visible";
	SCAM_LOCAL_TBL["NPCs\'name visible"] = "NPC\229\146\140\229\174\160\231\137\169\229\144\141\229\173\151";
	SCAM_LOCAL_TBL["Pets\'name visible"] = "Pets\'name visible";
	SCAM_LOCAL_TBL["Players\' name visible"] = "\231\142\169\229\174\182\229\144\141\229\173\151";
	SCAM_LOCAL_TBL["Guild\'s name visible"] = "\229\183\165\228\188\154\229\144\141\229\173\151";
	SCAM_LOCAL_TBL["Players\' PVP title visible"] = "PVP\229\164\180\232\161\148";
	SCAM_LOCAL_TBL["Show main UI"] = "UI\231\149\140\233\157\162";
	SCAM_LOCAL_TBL["Chat bubbles visible"] = "\232\129\138\229\164\169\230\179\161\230\179\161";
	SCAM_LOCAL_TBL["Combat text visible"] = "\230\136\152\230\150\151\230\150\135\229\173\151";
	SCAM_LOCAL_TBL["Hilite target"] = "\232\167\146\232\137\178\233\152\180\229\189\177";
	SCAM_LOCAL_TBL["Camera movements speed in Movie Environment:"] = "\229\189\149\229\136\182\230\168\161\229\188\143\228\184\139\233\149\156\229\164\180\231\167\187\229\138\168\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Horizontal rotation speed (yaw)"] = "\230\176\180\229\185\179\230\151\139\232\189\172\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Vertical rotation speed (pitch)"] = "\229\158\130\231\155\180\230\139\137\228\188\184\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Zoom speed"] = "\229\143\152\231\132\166\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Camera distance (out of Movie Environment):"] = "\233\149\156\229\164\180\232\183\157\231\166\187(\233\157\158\229\189\149\229\136\182\230\168\161\229\188\143\228\184\139)";
	SCAM_LOCAL_TBL["Distance max"] = "\233\149\156\229\164\180\230\156\128\229\164\167\232\183\157\231\166\187";
	SCAM_LOCAL_TBL["Distance max factor"] = "\233\149\156\229\164\180\230\156\128\229\164\167\229\128\141\230\149\176";
	SCAM_LOCAL_TBL["Default"] = "\233\187\152\232\174\164";
	SCAM_LOCAL_TBL["Close"] = "\229\133\179\233\151\173";

elseif (GetLocale() == "zhTW") then
	SCAM_LOCAL_TBL["Settings (UI)"] = "\230\143\146\228\187\182\232\168\173\231\189\174\230\136\178\231\170\151\229\143\163";
	SCAM_LOCAL_TBL["Movie environment"] = "\229\189\177\231\137\135\233\140\132\229\136\182\230\168\161\229\188\143";
	SCAM_LOCAL_TBL["Rotate left"] = "\233\143\161\233\160\173\229\183\166\230\151\139\232\189\137";
	SCAM_LOCAL_TBL["Rotate right"] = "\233\143\161\233\160\173\229\143\179\230\151\139\232\189\137";
	SCAM_LOCAL_TBL["Up"] = "\233\143\161\233\160\173\229\144\145\228\184\138";
	SCAM_LOCAL_TBL["Down"] = "\233\143\161\233\160\173\229\144\145\228\184\139";
	SCAM_LOCAL_TBL["Zoom in"] = "\233\143\161\233\160\173\230\139\137\232\191\145";
	SCAM_LOCAL_TBL["Zoom out"] = "\233\143\161\233\160\173\230\139\137\233\129\160";
	SCAM_LOCAL_TBL["Increase rotation speed"] = "Increase rotation speed";
	SCAM_LOCAL_TBL["Decrease rotation speed"] = "Decrease rotation speed";
	SCAM_LOCAL_TBL["Increase up and down speed"] = "Increase up and down speed";
	SCAM_LOCAL_TBL["Decrease up and down speed"] = "Decrease up and down speed";
	SCAM_LOCAL_TBL["Increase zoom speed"] = "Increase zoom speed";
	SCAM_LOCAL_TBL["Decrease zoom speed"] = "Decrease zoom speed";

	SCAM_LOCAL_TBL["loaded. Type /cameraplus to display settings UI."] = "loaded. Type /cameraplus to display settings UI.";
	SCAM_LOCAL_TBL["all settings reset to defaults."] = "all settings reset to defaults.";
	
	SCAM_LOCAL_TBL["Settings"] = "Settings";
	SCAM_LOCAL_TBL["Reset to default"] = "Reset to default";
	
	SCAM_LOCAL_TBL["settings"] = "\232\168\173\231\189\174\231\170\151\229\143\163";
	SCAM_LOCAL_TBL["Bind keys to switch to Movie Environment and for camera movements."] = "\232\171\139\229\156\168\230\140\137\233\141\181\231\182\129\229\174\154\228\184\173\231\130\186\233\143\161\233\160\173\231\167\187\229\139\149\229\146\140\233\140\132\229\136\182\230\168\161\229\188\143\231\182\129\229\174\154\230\140\137\233\141\181";
	SCAM_LOCAL_TBL["is defined to switch to Movie Environment"] = "is defined to switch to Movie Environment.";
	SCAM_LOCAL_TBL["See included ReadMe text file for more infos about supported slash-commands."] = "See included ReadMe text file for more infos about supported slash-commands.";
	SCAM_LOCAL_TBL["Main UI transparency in Movie Environment:"] = "Main UI transparency in movie environment:";
	SCAM_LOCAL_TBL["Hidden"] = "Hidden";
	SCAM_LOCAL_TBL["Visible"] = "Visible";
	SCAM_LOCAL_TBL["Hide these UI parts in Movie Environment:"] = "\229\156\168\233\140\132\229\136\182\230\168\161\229\188\143\228\184\139\233\154\177\232\151\143\228\187\165\228\184\139\230\143\146\228\187\182\233\131\168\229\136\134";
	SCAM_LOCAL_TBL["Own name visible"] = "Own name visible";
	SCAM_LOCAL_TBL["NPCs\'name visible"] = "NPC\229\146\140\229\175\181\231\137\169\229\144\141\229\173\151";
	SCAM_LOCAL_TBL["Pets\'name visible"] = "Pets\'name visible";
	SCAM_LOCAL_TBL["Players\' name visible"] = "\231\142\169\229\174\182\229\144\141\229\173\151";
	SCAM_LOCAL_TBL["Guild\'s name visible"] = "\229\183\165\230\156\131\229\144\141\229\173\151";
	SCAM_LOCAL_TBL["Players\' PVP title visible"] = "PVP\233\160\173\233\138\156";
	SCAM_LOCAL_TBL["Show main UI"] = "UI\231\149\140\233\157\162";
	SCAM_LOCAL_TBL["Chat bubbles visible"] = "\232\129\138\229\164\169\230\179\161\230\179\161";
	SCAM_LOCAL_TBL["Combat text visible"] = "\230\136\176\230\150\151\230\150\135\229\173\151";
	SCAM_LOCAL_TBL["Hilite target"] = "\232\167\146\232\137\178\233\153\176\229\189\177";
	SCAM_LOCAL_TBL["Camera movements speed in Movie Environment:"] = "\233\140\132\229\136\182\230\168\161\229\188\143\228\184\139\233\143\161\233\160\173\231\167\187\229\139\149\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Horizontal rotation speed (yaw)"] = "\230\176\180\229\185\179\230\151\139\232\189\137\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Vertical rotation speed (pitch)"] = "\229\158\130\231\155\180\230\139\137\228\188\184\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Zoom speed"] = "\232\174\138\231\132\166\233\128\159\229\186\166";
	SCAM_LOCAL_TBL["Camera distance (out of Movie Environment):"] = "\233\143\161\233\160\173\232\183\157\233\155\162(\233\157\158\233\140\132\229\136\182\230\168\161\229\188\143\228\184\139)";
	SCAM_LOCAL_TBL["Distance max"] = "\233\143\161\233\160\173\230\156\128\229\164\167\232\183\157\233\155\162";
	SCAM_LOCAL_TBL["Distance max factor"] = "\233\143\161\233\160\173\230\156\128\229\164\167\229\128\141\230\149\184";
	SCAM_LOCAL_TBL["Default"] = "\233\187\152\232\170\141";
	SCAM_LOCAL_TBL["Close"] = "\233\151\156\233\150\137";
end
