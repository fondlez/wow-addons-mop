--[[
	author: Zax
	type: library used by Zax addons
	- attention pour les versions suivantes : pour des raisons de retro-compatibilite, les fcns existantes peuvent etre modifiees a condition que leurs comportements (et surtout leurs retours) ne soient pas changes. Si les modification sont trop importantes, ajouter une nouvelle version de ces fcns en conservant les anciennes versions !
	- hook possible en definissant une fcn du meme nom dans un addon avec : local function maFcn()
	todo: 
--]]

---------------------------------------------------------------------------------------
---------------------------------------- INTERNE --------------------------------------
ZAXLIB_VERS = 1.0; -- 2011-06-28
ZAXLIB_NAME = "_";

ZaxLib = {}; -- prefixage fonctions

function ZaxLib:getLibVers()
	return ZAXLIB_VERS..","..ZAXLIB_NAME;
end

---------------------------------------------------------------------------------------
-------------------------------------- CONVERSION -------------------------------------
function ZaxLib:strToNumber(chaine)
	----- renvoit 0 par defaut, alors que tonumber() renvoit nil
	local valTmp = tonumber(chaine,10);
	if (valTmp == nil) then
		return 0;
	else
		return valTmp;
	end;
end

function ZaxLib:booleanToStr(booleen)
	return tostring(booleen);
end

function ZaxLib:booleanToInt(valeur)
	if (valeur) then return 1; else return 0; end;
end

function ZaxLib:booleanToBin(valeur)
	return (valeur == 1);
end

---------------------------------------------------------------------------------------
------------------------------------- ARITHMETIQUE ------------------------------------
function ZaxLib:inversionValeur(valeur)
	return abs(valeur - 1);
end

function ZaxLib:arrondi(valeur)
	if (valeur - math.floor(valeur) > 0.5) then valeur = valeur + 0.5;end;
	return (math.floor(valeur));
end

function ZaxLib:nombreCompris(nombre,borneInf,borneSup)
	local valeur = tonumber(nombre);
	if (valeur ~= nil) then
		valeur = max(borneInf,valeur);
		valeur = min(borneSup,valeur);
	else
		valeur = borneInf;
	end;
	return valeur;
end

function ZaxLib:nombreParDefaut(nombre,borneInf,borneSup,defaut)
	local valeur = tonumber(nombre);
	if (valeur == nil) then return defaut; end;
	if (valeur < borneInf) then return defaut; end;
	if (valeur > borneSup) then return defaut; end;
	return valeur;
end

---------------------------------------------------------------------------------------
--------------------------------------- CHAINES ---------------------------------------
function ZaxLib:kwote(chaine)
	return ("\""..chaine.."\"");
end

function ZaxLib:explode(chaine,delim,maxItems)
	----- identique a la fcn de PHP (renvoit une table), avec en plus la possibilite de limiter le nombre d'elements renvoyes (maxItems)
	----- si maxItems = 0 ou un entier negatif, la fcn renverra une table vide
	local tbl = {};
	if (chaine == nil) then return tbl; end;
	if (delim == nil) then delim = " "; end;
	local maxi = maxItems;
	if (maxi ~= nil) then
		maxi = tonumber(maxi);
		if (maxi == nil) then maxi = 9999; end;
	else
		maxi = 9999;
	end;
	
	local cpt = 0;
	for valeur in string.gmatch(chaine, "[^"..delim.."]+") do
		if (cpt < maxi) then tinsert(tbl,valeur); end;
		cpt = cpt + 1;
	end;
	return tbl;
end

function ZaxLib:implode(tbl,delim)
	----- identique a la fcn de PHP (renvoit une chaine)
	if (type(tbl) == "table") then
		if (not ZaxLib:isEmpty(tbl)) then
			if (delim == nil) then delim = ""; end;
			local tailleDelim = strlen(delim);
			local chaine = "";
			for index, value in pairs(tbl) do
				chaine = chaine..value..delim;
			end;
			tbl = string.sub(chaine,1,-(tailleDelim + 1)); -- suppression dernier delim
		end;
	end;
	return tbl;
end

function ZaxLib:getItem(chaine,delim,numItem)
	----- renvoit l'element numItem de la chaine passee (les "elements" sont separes par delim)
	----- renvoit la chaine entiere passee ou son 1ere element en cas de probleme
	
	if (chaine == nil) then return nil; end;
	if (delim == nil) then delim = " "; end;
	numItem = tonumber(numItem);
	if (numItem == nil) then numItem = 1; end;
	if (numItem < 1) then numItem = 1; end;
	
	local tbl = ZaxLib:explode(chaine,delim,numItem);
	if (not ZaxLib:isEmpty(tbl)) then
		return tbl[numItem];
	else
		return chaine;
	end;
end

---------------------------------------------------------------------------------------
---------------------------------------- TABLES ---------------------------------------
function ZaxLib:sortTable(tableOr,cle,sens,genre)
	----- trie la table passee par une cle
	----- sens peut etre "A" (ascendant, defaut) ou "D" (descendant)
	----- genre peut etre "N" (numerique, defaut) ou "A" (alphabetique)
	
	local tableTemp = {};
	for i in ipairs(tableOr)do
		table.insert(tableTemp,i);
	end;
	if (sens == nil) then sens = "A"; end;
	sens = string.upper(string.sub(sens,1,1));
	if (genre == nil) then genre = "N"; end;
	genre = string.upper(string.sub(genre,1,1));
	if (sens == "D") then
		if (genre == "A") then
			table.sort(tableTemp, function(a,b) return string.lower(tableOr[a][cle]) > string.lower(tableOr[b][cle]) end);
		else -- numerique par defaut
			table.sort(tableTemp, function(a,b) return tableOr[a][cle] > tableOr[b][cle] end);
		end;
	else -- ascendant par defaut
		if (genre == "A") then
			table.sort(tableTemp, function(a,b) return string.lower(tableOr[a][cle]) < string.lower(tableOr[b][cle]) end);
		else -- numerique par defaut
			table.sort(tableTemp, function(a,b) return tableOr[a][cle] < tableOr[b][cle] end);
		end;
	end;
	for i in ipairs(tableTemp) do
		tableTemp[i] = tableOr[tableTemp[i]];
	end
	return tableTemp;
end

function ZaxLib:copyTable(tbl,metaIdentique)
	----- effectue une vraie copie d'une table et non un clonage
	----- si metaIdentique vaut TRUE, les 2 tables partageront la meme metatable
	
	local lookup_table = {}
	local function _copy(tbl)
		if type(tbl) ~= "table" then
			return tbl
		elseif lookup_table[tbl] then
			return lookup_table[tbl]
		end
		local new_table = {}
		lookup_table[tbl] = new_table
		for index, value in pairs(tbl) do
			new_table[_copy(index)] = _copy(value)
		end
		
		if (metaIdentique) then
			return setmetatable(new_table, getmetatable(tbl))
		else
			return setmetatable(new_table, _copy(getmetatable(tbl)))
		end;
	end
	return _copy(tbl)
end

function ZaxLib:isInTable(tbl,valeur,caseNonSensitive)
	----- renvoit la cle (numerique ou associative) de la table passee dont l'element vaut la valeur passee
	----- renvoit NIL si aucun element ne vaut la valeur passee
	----- identique � tcontains() mais fonctionne aussi pour une table associative
	if (caseNonSensitive) then
		for key, value in pairs(tbl) do
			if (strlower(value) == strlower(valeur)) then return key; end;
		end;
	else
		for key, value in pairs(tbl) do
			if (value == valeur) then return key; end;
		end;
	end;
	return nil;
end

---------------------------------------------------------------------------------------
------------------------------------------ XML ----------------------------------------
function ZaxLib:setTextInAutoFrame(frame,fontString,texte,bordure,padding)
	----- remplit la fontString du frame passe avec du texte, en dessinant eventuellement une bordure et ajuste la hauteur du frame cible
	----- sans bordure, le padding vaut 0, quelle que soit la valeur passee
	if (frame ~= nil and fontString ~= nil) then
		if (bordure or bordure == 1) then
			local texture = {
				bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
				edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
				tile = true,
				tileSize = 16,
				edgeSize = 16,
				insets = {left = 4, right = 4, top = 4, bottom = 2}
			}
			frame:SetBackdrop(texture);
			frame:SetBackdropBorderColor(0.5,0.5,0.5);
			frame:SetBackdropColor(0.3,0.3,0.3,0.5);
		
			if (padding ~= nil) then padding = tonumber(padding); end;
			if (padding == nil) then padding = 10; end;
		else
			padding = 0;
		end;
		
		fontString:SetText(texte);
		fontString:SetPoint("TOPLEFT",frame,"TOPLEFT",padding,-padding);
		fontString:SetWidth(ceil(frame:GetWidth()) - (padding*2));
		frame:SetHeight(fontString:GetHeight() + (padding*2));
	end;
end

---------------------------------------------------------------------------------------
---------------------------------------- DIVERS ---------------------------------------
function ZaxLib:videSiNul(valeur)
	if (valeur == nil) then return ""; else return valeur; end;
end

function ZaxLib:nilSiNul(valeur)
	if (valeur == nil) then return "NIL"; else return valeur; end;
end

function ZaxLib:isEmpty(variable)
	------ renvoit true si la variable ou la table passee est vide ou nil
	if (type(variable) == "table") then
		local next = next;
		return (next(variable) == nil);
	else
		return (variable == nil or variable == "");
	end;
end

function ZaxLib:attribueBinaire(valeur)
	if (valeur == 1 or valeur == "1") then return (1); else return (0); end;
end

function ZaxLib:getBindedKey(nomCommande)
	----- renvoit le NOM de la touche associee a la commande passee : non encore disponible sur VARIABLE_LOADED !
	----- renvoit NIL s'il n'y a pas de touche associee a la commande passee
	local key1,key2 = GetBindingKey(nomCommande);
	if (key1 == nil and key2 == nil) then return nil; end;
	if (key1 ~= nil) then
		return key1;
	else
		return nil;
	end;
end

function echo(chaine,nomCouleur)
	ZaxLib:echo(chaine,nomCouleur);
end
function ZaxLib:echo(chaine,nomCouleur)
	local tableCouleurs = {
		["red"] = {0.9,0.4,0.4},
		["orange"] = {0.8,0.3,0.1},
		["yellow"] = {1,1,0},
		["green"] = {0.4,0.9,0.4},
		["aqua"] = {0.42,0.8,0.84},
		["blue"] = {0.4,0.4,0.9},
		["purple"] = {0.66,0.3,0.95},
		["cream"] = {0.93,0.87,0.75},
		["grey"] = {0.6,0.6,0.6},
		["gray"] = {0.6,0.6,0.6},
		["silver"] = {0.85,0.85,0.85},
		["white"] = {1,1,1},
	}
	if (nomCouleur == nil) then nomCouleur = "silver"; end;
	if (tableCouleurs[nomCouleur] == nil) then nomCouleur = "silver"; end;
	if (DEFAULT_CHAT_FRAME) then ChatFrame1:AddMessage(chaine,tableCouleurs[nomCouleur][1],tableCouleurs[nomCouleur][2],tableCouleurs[nomCouleur][3]); end;
end

function echoTable(tbl,niveauUnique,prefixe,nivIndent) -- echo recursif de table (pour debug)
	ZaxLib:echoTable(tbl,niveauUnique,prefixe,nivIndent);
end
function ZaxLib:echoTable(tbl,niveauUnique,prefixe,nivIndent)
	----- echo recursif de table (pour debug)
	if (tbl == nil) then
		echo("|cFFEDDDC0---NIL");
	elseif next(tbl) == nil then -- attention : #tbl renvoit toujours 0
		echo("|cFFEDDDC0---EMPTY");
	else
		if (niveauUnique == nil) then niveauUnique = false; end;
		if (prefixe == nil) then prefixe = ""; end;
		if (nivIndent == nil) then
			nivIndent = 0;
		else
			nivIndent = ZaxLib:strToNumber(nivIndent); -- fcn perso
		end;
		for key,value in pairs(tbl) do
			if (type(value) == "table") then
				if (niveauUnique) then
					echo("|cFFEDDDC0"..prefixe.."|cFF60B599["..key.."]|cFFEDDDC0".."-----TABLE");
				else
					echo("|cFFEDDDC0"..prefixe.."|cFF60B599["..key.."]|cFFEDDDC0");
					local indentStr = "";
					for i = 0,nivIndent,1 do
						indentStr = indentStr.."   ";
					end;
					echoTable(value,niveauUnique,prefixe..indentStr,nivIndent + 1);
				end;
			else
				echo("|cFFEDDDC0"..prefixe.."|cFF60B599["..key.."]|cFFEDDDC0"..tostring(value).."---");
			end;
		end;
	end;
end