function CCTracker:ResetSources()
	CCTrackerSettings["ccSources"] = {};
end

function CCTracker:SourceEnabled(sourceName)
	for k,v in pairs(CCTrackerSettings["ccSources"]) do
		if (sourceName == k and v == 1) then
			return true;
		elseif (sourceName == k and v == 0) then
			return false;
		end
	end
	return true;
end

function CCTracker:EnableSource(sourceName)
	if (CCTrackerSettings["ccSources"][sourceName] == 0) then
		CCTrackerSettings["ccSources"][sourceName] = nil;
	end
end

function CCTracker:DisableSource(sourceName)
	CCTrackerSettings["ccSources"][sourceName] = 0;
end

function CCTracker:ListSources()
	print("Sources that are disabled:");
	local sources = "";
	for k,v in pairs(CCTrackerSettings["ccSources"]) do
		if v == 0 then
			if sources ~= "" then
				sources = sources .. ", ";
			end
			sources = sources .. k;
		end
	end
	print(sources);
	print("Any sources not listed here is enabled by default.");
end