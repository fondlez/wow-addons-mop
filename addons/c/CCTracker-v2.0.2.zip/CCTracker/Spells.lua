function CCTracker:ResetSpells()
	CCTrackerSettings["ccSpells"] = {}
	
	--rogue
	CCTrackerSettings["ccSpells"]["Sap"] = 1;
	CCTrackerSettings["ccSpells"]["Blind"] = 1;
	CCTrackerSettings["ccSpells"]["Gouge"] = 1;

	--shamen
	CCTrackerSettings["ccSpells"]["Hex"] = 1;
	CCTrackerSettings["ccSpells"]["Bind Elemental"] = 1;

	--pally
	CCTrackerSettings["ccSpells"]["Repentance"] = 1;
	CCTrackerSettings["ccSpells"]["Turn Evil"] = 1;
	CCTrackerSettings["ccSpells"]["Blinding Light"] = 1;

	--hunter
	CCTrackerSettings["ccSpells"]["Scatter Shot"] = 1;
	CCTrackerSettings["ccSpells"]["Freezing Trap"] = 1;
	CCTrackerSettings["ccSpells"]["Wyvern Sting"] = 1;

	--warrior
	CCTrackerSettings["ccSpells"]["Intimidating Shout"] = 1;

	--dk
	--ccSpells["Hungering Cold"]=1;

	--mage
	CCTrackerSettings["ccSpells"]["Polymorph"] = 1;
	CCTrackerSettings["ccSpells"]["Ring of Frost"] = 1;

	--priest
	CCTrackerSettings["ccSpells"]["Psychic Scream"] = 1;
	CCTrackerSettings["ccSpells"]["Psychic Terror"] = 1;
	CCTrackerSettings["ccSpells"]["Holy Word: Chastise"] = 1;
	CCTrackerSettings["ccSpells"]["Shackle Undead"] = 1;

	--warlock
	CCTrackerSettings["ccSpells"]["Fear"] = 1;
	CCTrackerSettings["ccSpells"]["Seduction"] = 1;
	CCTrackerSettings["ccSpells"]["Howl of Terror"] = 1;

	--druid
	CCTrackerSettings["ccSpells"]["Entangling Roots"] = 1;
	CCTrackerSettings["ccSpells"]["Hibernate"] = 1;
	
	--monk
	CCTrackerSettings["ccSpells"]["Hibernate"] = 1;
end

function CCTracker:AddSpell(spellName)
	CCTrackerSettings["ccSpells"][spellName] = 1;
end

function CCTracker:DisableSpell(spellName)
	if (CCTrackerSettings["ccSpells"][spellName] == 1) then
		CCTrackerSettings["ccSpells"][spellName] = 0;
	end
end

function CCTracker:SpellEnabled(spellName)
	for k,v in pairs(CCTrackerSettings["ccSpells"]) do
		if (spellName == k and v == 1) then
			return true;
		end
	end
	return false;
end

function CCTracker:ListSpells()
	print("Spells in all uppercase are disabled:");
	local spells = "";
	for k,v in pairs(CCTrackerSettings["ccSpells"]) do
		local spellName = k;
		if (v == 0) then
			spellName = spellName:upper();
		end
		if spells ~= "" then
			spells = spells .. ", ";
		end
		spells = spells .. spellName;
	end
	print(spells);
	print("Any spell not listed here is disabled by default.");
end