local CUR_VER = 2;

-- Newer version that we are (shouldn't happen).
if CCTrackerSettings ~= nil and CCTrackerSettings["ver"] > CUR_VER then
	CCTrackerSettings = nil;
end

-- No version
if CCTrackerSettings == nil then
	CCTrackerSettings = {}
	CCTracker:ResetSpells();
	CCTracker:ResetTargets();
	CCTracker:ResetSources();
	CCTrackerSettings["ver"] = CUR_VER;
	CCTrackerSettings["channel"] = "SELF";
end

-- Any pre 2 version
if CCTrackerSettings["ver"] < 2 then
	CCTracker:ResetSpells();
	CCTracker:ResetSpells();
	CCTracker:ResetSpells();
	CCTrackerSettings["ver"] = CUR_VER;
end