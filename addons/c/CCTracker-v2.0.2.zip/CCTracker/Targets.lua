function CCTracker:ResetTargets()
	CCTrackerSettings["ccTargets"] = {};
end

function CCTracker:TargetEnabled(targetName)
	for k,v in pairs(CCTrackerSettings["ccTargets"]) do
		if (targetName == k and v == 1) then
			return true;
		elseif (targetName == k and v == 0) then
			return false;
		end
	end
	return true;
end

function CCTracker:EnableTarget(targetName)
	if (CCTrackerSettings["ccTargets"][targetName] == 0) then
		CCTrackerSettings["ccTargets"][targetName] = nil;
	end
end

function CCTracker:DisableTarget(targetName)
	CCTrackerSettings["ccTargets"][targetName] = 0;
end

function CCTracker:ListTargets()
	print("Targets that are disabled:");
	local targets = "";
	for k,v in pairs(CCTrackerSettings["ccTargets"]) do
		if v == 0 then
			if targets ~= "" then
				targets = targets .. ", ";
			end
			targets = targets .. k;
		end
	end
	print(targets);
	print("Any targets not listed here is enabled by default.");
end