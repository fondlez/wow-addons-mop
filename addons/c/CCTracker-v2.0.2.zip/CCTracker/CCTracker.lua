CCTracker = CreateFrame("Frame");

local RaidIconMaskToIndex = {
	[COMBATLOG_OBJECT_RAIDTARGET1] = 1,
	[COMBATLOG_OBJECT_RAIDTARGET2] = 2,
	[COMBATLOG_OBJECT_RAIDTARGET3] = 3,
	[COMBATLOG_OBJECT_RAIDTARGET4] = 4,
	[COMBATLOG_OBJECT_RAIDTARGET5] = 5,
	[COMBATLOG_OBJECT_RAIDTARGET6] = 6,
	[COMBATLOG_OBJECT_RAIDTARGET7] = 7,
	[COMBATLOG_OBJECT_RAIDTARGET8] = 8
};

local currentCC = {};

local currentTick = "";
local tickDamage = {};
local tickCCBreak = {};

local DEBUG = false;

CCTracker:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", "CombatLog")

CCTracker:SetScript("OnEvent", function(self, event, ...)
    if (event=="COMBAT_LOG_EVENT_UNFILTERED") then
        CCTracker:CombatLog(event,...)
    end
end)

function CCTracker:ccDamage(sourceName,spellID,destGUID,destName,destFlags,destFlags2)
	--print("cc damaged | " .. destGUID .. " | " .. spellID);
	if (tickCCBreak[destGUID] ~= nil)
	then
		for k,v in pairs(tickCCBreak[destGUID]) do
			CCTracker:ccBreak(sourceName,k,nil,destGUID,destName,destFlags,destFlags2,spellID,nil);
		end
	else
		tickDamage[destGUID] = {}
		tickDamage[destGUID]["sourceName"]=sourceName;
		tickDamage[destGUID]["spellID"]=spellID;
	end
end

function CCTracker:ccBreak(sourceName,spellID,spellName,destGUID,destName,destFlags,destFlags2,otherSpellID,otherSpellName)
	--print("cc broken | " .. destGUID .. " | " .. spellID);
	local spellLink, craftingLink, otherSpellLink, otherCraftingLink, raidIconIndex
	
	if (destGUID ~= nil)
	then
		if (currentCC[destGUID] ~= nil)
		then
			currentCC[destGUID][spellID] = nil;
		end
		raidIconIndex = RaidIconMaskToIndex[bit.band(destFlags2, COMBATLOG_OBJECT_RAIDTARGET_MASK)];
	else
		raidIconIndex = nil;
	end
	
	if (spellID == -1)
	then
		if (raidIconIndex ~= nil)
		then
			CCTracker:Output(spellLink.." was broken on {rt".. raidIconIndex .."}"..destName.." by environmental damage");
		else
			CCTracker:Output(spellLink.." was broken on "..destName.." by environmental damage");
		end
	elseif (spellID ~= nil)
	then
		spellLink, craftingLink = GetSpellLink(spellID);
		otherSpellLink, otherCraftingLink = GetSpellLink(otherSpellID);
	else -- for /cc test <cc breaker> <cc'd target> <cc spell> <breaking spell>
		spellLink = spellName;
		otherSpellLink = otherSpellName;
	end
	
	if (CCTracker:SourceEnabled(sourceName) and CCTracker:TargetEnabled(destName)) then
		if (raidIconIndex ~= nil)
		then
			CCTracker:Output(sourceName.." broke "..spellLink.." on {rt".. raidIconIndex .."}"..destName.." with "..otherSpellLink);
		else
			CCTracker:Output(sourceName.." broke "..spellLink.." on "..destName.." with "..otherSpellLink);
		end
	end
end

function CCTracker:ccRemoved(spellID,destGUID,destName,destFlags,destFlags2)
	--print("cc removed | " .. destGUID .. " | " .. spellID);
	if (tickDamage ~= nil and tickDamage[destGUID] ~= nil)
	then
		CCTracker:ccBreak(tickDamage[destGUID]["sourceName"],spellID,nil,destGUID,destName,destFlags,destFlags2,tickDamage[destGUID]["spellID"],nil);
	else
		if (tickCCBreak[destGUID] == nil)
		then
			tickCCBreak[destGUID] = {};
		end
		tickCCBreak[destGUID][spellID] = {};
		tickCCBreak[destGUID][spellID]["destName"]=destName;
	end
end

function CCTracker:ccApply(spellID,spellName,sourceGUID,sourceName,destGUID)
	--print("cc applied | " .. destGUID .. " | " .. spellID);
	if (currentCC[destGUID] == nil)
	then
		currentCC[destGUID] = {}
	end
	currentCC[destGUID][spellID] = {};
	currentCC[destGUID][spellID]["srcGUID"]=sourceGUID;
	currentCC[destGUID][spellID]["srcName"]=srcName;
end

function CCTracker:CombatLog(event,...)
    local timestamp, type, hideCaster, sourceGUID, sourceName, sourceFlags, sourceFlags2, destGUID, destName, destFlags, destFlags2, spellID, spellName, something, otherSpellID, otherSpellName = ...
	
	if (currentTick ~= timestamp)
	then
		if (tickCCBreak[destGUID] ~= nil) --must have expired naturally
		then
			for k,v in pairs(tickCCBreak[destGUID]) do
				if (currentCC[destGUID] ~= nil)
				then
					currentCC[destGUID][k] = nil;
				end
				if (currentCC[destGUID] == {})
				then
					currentCC[destGUID] = nil;
				end
			end
		end
		tickCCBreak = {}
		tickDamage = {};
		currentTick = timestamp;
	end
	
	if (destName ~= nil and UnitIsFriend("player",destName) ~= nil)
	then
		return;
	end
	
	if DEBUG then
		print(timestamp, type, hideCaster, sourceGUID, sourceName, sourceFlags, sourceFlags2, destGUID, destName, destFlags, destFlags2, spellID, spellName, something, otherSpellID, otherSpellName);
	end
	
	if (type=="SWING_DAMAGE" and currentCC[destGUID] ~= nil)
	then
		if (CCTracker:SourceEnabled(sourceName) and CCTracker:TargetEnabled(destName)) then
			CCTracker:ccDamage(sourceName,6603,destGUID,destName,destFlags,destFlags2); --AutoAttack
		end
	elseif ((type=="SPELL_DAMAGE" or type=="RANGE_DAMAGE" or type=="SPELL_PERIODIC_DAMAGE" or type=="SPELL_BUILDING_DAMAGE") and currentCC[destGUID] ~= nil)
	then
		if (CCTracker:SourceEnabled(sourceName) and CCTracker:TargetEnabled(destName)) then
			CCTracker:ccDamage(sourceName,spellID,destGUID,destName,destFlags,destFlags2);
		end
	elseif (type=="ENVIRONMENTAL_DAMAGE" and currentCC[destGUID] ~= nil)
	then
		if (CCTracker:TargetEnabled(destName)) then
			CCTracker:ccDamage(sourceName,-1,destGUID,destName,destFlags,destFlags2);
		end
	elseif (type=="SPELL_AURA_APPLIED" or type =="SPELL_AURA_REFRESH")
	then
		if (CCTracker:SpellEnabled(spellName) and CCTracker:TargetEnabled(destName)) then
			CCTracker:ccApply(spellID,spellName,sourceGUID,sourceName,destGUID);
		end
	elseif (type=="SPELL_AURA_REMOVED")
	then
		if (CCTracker:SpellEnabled(spellName) and CCTracker:TargetEnabled(destName)) then
			CCTracker:ccRemoved(spellID,destGUID,destName,destFlags,destFlags2);
		end
	elseif (type=="SPELL_AURA_BROKEN_SPELL")
	then
		if (CCTracker:SpellEnabled(spellName) and CCTracker:SourceEnabled(sourceName) and CCTracker:TargetEnabled(destName)) then
			CCTracker:ccBreak(sourceName,spellID,spellName,destGUID,destName,destFlags,destFlags2,otherSpellID,otherSpellName);
		end
	end
	
	for gui,guiData in pairs(currentCC) do
		keepTarget = false;
		for cc, ccData in pairs(currentCC[gui]) do
			if ccData ~= nil
			then
				keepTarget = true;
			end
		end
		if keepTarget == false
		then
			currentCC[gui] = nil;
		end
	end
end

function CCTracker:Output(msg)
	if CCTrackerSettings["channel"] == "SELF" then
		DEFAULT_CHAT_FRAME:AddMessage(msg);
	else
		SendChatMessage(msg,CCTrackerSettings["channel"],nil,nil);
	end
end

SLASH_CCTRACKER1 = "/cc"
SlashCmdList["CCTRACKER"] = function(msg)
	local cmd, arg = string.split(" ", msg, 2);
	cmd = cmd:lower();

	if cmd == "test" then
		local person, target, ccSpell, breakingSpell = string.split(" ", arg);
		CCTracker:CombatLog(nil,nil,"SPELL_AURA_BROKEN_SPELL",false,nil,person,nil,nil,nil,target,nil,nil,nil,ccSpell,nil,nil,breakingSpell);
	elseif cmd == "debug" then
		arg = arg:lower();
		if arg == "on" then
			print("Debuging enabled");
			DEBUG = true;
		elseif arg == "off" then
			print("Debuging disabled");
			DEBUG = false;
		else
			print("Unknown option '" .. arg .."'");
		end
	elseif cmd == "channel" then
		arg = arg:lower();
		if arg == "" or arg == "self" then
			arg = "SELF";
		end
		CCTrackerSettings["channel"] = arg;
		print("Channel Set");
	elseif cmd == "spell" then
		local option, spellName = string.split(" ", arg, 2);
		option = option:lower();
		if option == "add" then
			CCTracker:AddSpell(spellName);
			print("Spell Added.");
		elseif option == "remove" then
			CCTracker:DisableSpell(spellName);
			print("Spell removed.");
		else
			print("Unknown option '" .. option .. "'");
		end
	elseif cmd == "source" then
		local option, sourceName = string.split(" ", arg, 2);
		option = option:lower();
		if option == "enable" then
			CCTracker:EnableSource(sourceName);
			print("Now tracking from this source.");
		elseif option == "disable" then
			CCTracker:DisableSource(sourceName);
			print("No longer tracking from this source.");
		else
			print("Unknown option '" .. option .. "'");
		end
	elseif cmd == "target" then
		local option, targetName = string.split(" ", arg, 2);
		option = option:lower();
		if option == "enable" then
			CCTracker:EnableTarget(targetName);
			print("Now tracking from this target.");
		elseif option == "disable" then
			CCTracker:DisableTarget(targetName);
			print("No longer tracking from this target.");
		else
			print("Unknown option '" .. option .. "'");
		end
	elseif cmd == "reset" then
		arg = arg:lower();
		if arg == "spells" then
			CCTracker:ResetSpells();
			print("Spell tracking reset to default.");
		elseif arg == "sources" then
			CCTracker:ResetSources();
			print("Source tracking reset to default.");
		elseif arg == "targets" then
			CCTracker:ResetTargets();
			print("Target tracking reset to default.");
		else
			print("Unknown option '" .. arg .. "'");
		end
	elseif cmd == "list" then
		arg = arg:lower();
		if arg == "spells" then
			CCTracker:ListSpells();
		elseif arg == "targets" then
			CCTracker:ListTargets();
		elseif arg == "sources" then
			CCTracker:ListSources();
		end
	elseif cmd == "?" then
		print("Usage:")
		print("/cc channel <SELF||RAID|PARTY|SAY|etc>");
		print("Sets output channel");
		
		print("/cc spell <add||remove> <spellname>");
		print("Adds or removes spells from tracking");
		
		print("/cc source <enable|disable> <sourceName>");
		print("Adds or removes tracking of cc breaking by source. IE your tanks name, or an npc.");
		
		print("/cc target <enable|disable> <targetName>");
		print("Adds or removes tracking of cc breaking on specific targets.");
		
		print("/cc list <targets|spells|sources>");
		print("Lists current target, spell or source options.");
		
		print("/cc reset spells");
		print("Resets cc that is tracked to default.");
		
		print("/cc reset sources");
		print("Resets sources that are tracked to default.");
		
		print("/cc reset targets");
		print("Resets targets that are tracked to default.");
		
		print("/cc test <Person> <CCSpell> <Target> <BreakingSpell>");
		print("Tests outputing a message.");
		
		print("/cc debug <on|off>");
		print("For debuging the addon.");
	else
		print("Unknown command '" .. cmd .. "'.");
		print("Type '/cc ?' for usage information");
	end
end

--http://wow.mmoui.com/forums/showthread.php?p=232488
local function GetIconIndex(flags)
    local number, mask, mark
    if bit.band(flags, COMBATLOG_OBJECT_SPECIAL_MASK) ~= 0 then
        for i=1,8 do
            mask = COMBATLOG_OBJECT_RAIDTARGET1 * (2 ^ (i - 1))
            mark = bit.band(flags, mask) == mask
            if mark then number = i break end
        end
    end
    return number
end