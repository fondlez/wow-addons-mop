local L = LibStub("AceLocale-3.0"):NewLocale("CompactRunes", "frFR", false)

if not L then return end


