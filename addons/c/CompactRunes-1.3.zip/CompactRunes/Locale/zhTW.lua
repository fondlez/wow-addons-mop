local L = LibStub("AceLocale-3.0"):NewLocale("CompactRunes", "zhTW", false)

if not L then return end


