local L = LibStub("AceLocale-3.0"):NewLocale("CompactRunes", "esES", false)

if not L then return end

L["BarHeight_Desc"] = "Alto" -- Needs review
L["Bar Texture"] = "Textura de la Barra" -- Needs review
L["BarTexture_OptionDesc"] = "La textura que se usará en la barra." -- Needs review
L["BarWidth_Desc"] = "Ancho" -- Needs review
L["Blood, Frost, Unholy"] = "Sangre, Escarcha, Muerte" -- Needs review
L["Blood, Unholy, Frost"] = "Sangre, Muerte, Escarcha" -- Needs review
L["Border"] = "Borde" -- Needs review
L["Border_OptionDesc"] = "El borde que se usará." -- Needs review
L["Frost, Blood, Unholy"] = "Escarcha, Sangre, Muerte" -- Needs review
L["General Options"] = "Opciones Generales" -- Needs review
L["Height"] = "Alto" -- Needs review
L["Lock"] = "Bloquear" -- Needs review
L["LockDesc"] = "Activa/Desactiva el movimiento del marco." -- Needs review
L["Monochrome"] = "Monocromo." -- Needs review
L["OOC Alpha"] = "Transparencia FdC" -- Needs review
L["OOCAlpha_Desc"] = "Transparencia Fuera de Combate." -- Needs review
L["Outline"] = "Línea Exterior" -- Needs review

