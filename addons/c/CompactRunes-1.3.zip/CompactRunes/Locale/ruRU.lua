local L = LibStub("AceLocale-3.0"):NewLocale("CompactRunes", "ruRU", false)

if not L then return end


