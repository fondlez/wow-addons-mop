local L = LibStub("AceLocale-3.0"):NewLocale("CompactRunes", "zhCN", false)

if not L then return end


