local L = LibStub("AceLocale-3.0"):NewLocale("CompactRunes", "deDE", false)

if not L then return end


