local _G = getfenv(0)
-- Local versions for performance
local string = _G.string
local math = _G.math
local pairs = _G.pairs
local ipairs = _G.ipairs
local table = _G.table
local floor, ceil, min, max, abs = math.floor, math.ceil, math.min, math.max, math.abs
local tconcat, tinsert = table.concat, table.insert
local wipe = _G.wipe
local tostring = _G.tostring
local tonumber = _G.tonumber

local CompactRunes = _G.LibStub("AceAddon-3.0"):NewAddon("Compact Runes", "AceConsole-3.0", "AceEvent-3.0","AceTimer-3.0")
local L = _G.LibStub("AceLocale-3.0"):GetLocale("CompactRunes", true)
local LDB = _G.LibStub("LibDataBroker-1.1")
local LibQTip = _G.LibStub("LibQTip-1.0")
local Icon = _G.LibStub("LibDBIcon-1.0")
local LSM = _G.LibStub:GetLibrary("LibSharedMedia-3.0")

-- Try to remove the Git hash at the end, otherwise return the passed in value.
local function cleanupVersion(version)
	local iter = string.gmatch(version, "(.*)-[a-z0-9]+$")
	if iter then
		local ver = iter()
		if ver and #ver >= 3 then
			return ver
		end
	end
	return version
end

local ADDON_NAME = ...
local ADDON_VERSION = cleanupVersion("1.3")
local options = nil
local MIN_UPDATE_TIME = 0.05
CompactRunes.MIN_UPDATE_TIME = MIN_UPDATE_TIME

local function round(number)
    if not number then return 0 end
    return floor(number+0.5)
end
CompactRunes.round = round

-- Define a simplistic class for combat statistics
local CombatStats = {}
CombatStats.__index = CombatStats

function CombatStats:new()
    local stats = {}
    _G.setmetatable(stats, CombatStats)
    stats:Reset()
    return stats
end

function CombatStats:Reset()
	self.rcProcs = 0
	self.cappedBC = 0
	self.reProcs = self.reProcs or {}
	wipe(self.reProcs)
	self.regenUses = self.regenUses or {}
	wipe(self.regenUses)
end

local RuneColors = nil
local RuneCooldownColors = nil
local RuneMapping = {
	[0] = "NONE",
	[1] = "BLOOD",
	[2] = "UNHOLY",
	[3] = "FROST",
	[4] = "DEATH",
}
local RuneNames = {
	["BLOOD"] = L["Blood"],
	["UNHOLY"] = L["Unholy"],
	["FROST"] = L["Frost"],
	["DEATH"] = L["Death"],
}

local HEXFMT = "|c%2x%2x%2x%2x"
local function chatColorCode(color)
	local a = 255
	local r = ceil(255 * color.r)
	local g = ceil(255 * color.g)
	local b = ceil(255 * color.b)
	return HEXFMT:format(a, r, g, b)
end

local RuneChatColors = {}
function CompactRunes:UpdateRuneColors()
	RuneColors = self.db.profile.RuneColors
	RuneCooldownColors = self.db.profile.RuneCooldownColors
	wipe(RuneChatColors)
	for k, v in pairs(self.db.profile.RuneColors) do
		RuneChatColors[k] = chatColorCode(v)
	end
end

-- Define Bar for now but the rest is at the bottom of the file.
local Bar = {}

CompactRunes.bars = {}
CompactRunes.blocks = {}
CompactRunes.cdbars = {}
CompactRunes.diseases = {
	ff = {},
	bp = {},
}
CompactRunes.playerName = UnitName("player")
CompactRunes.isDK = false
CompactRunes.TotalStats = CombatStats:new()
CompactRunes.LastFightStats = CombatStats:new()
CompactRunes.regenMethod = "None"
CompactRunes.currentSpec = ""
CompactRunes.currentProcs = {}
CompactRunes.soulReaperKnown = false
CompactRunes.soulReaperPerc = 0.35
CompactRunes.tierCount = { ["T15"] = 0 }
CompactRunes.currentTarget = nil
CompactRunes.targetSoulReaper = false
CompactRunes.targetHostile = false
CompactRunes.targetMaxHealth = 0
CompactRunes.srMethod = "cooldown"
CompactRunes.pillarReady = nil
CompactRunes.gargoyleReady = nil
CompactRunes.frenzyReady = nil
CompactRunes.base = { ff = 0, bp = 0 }
CompactRunes.eff = { ff = 0, bp = 0 }
CompactRunes.ff = {}
CompactRunes.bp = {}
CompactRunes.cinderglacier = false
CompactRunes.effectiveAP = 0
CompactRunes.mastery = 0
CompactRunes.critChance = 0
CompactRunes.damageModifier = 1.0
CompactRunes.bloodCharges = 0
CompactRunes.bcExpires = 0
CompactRunes.MaxBloodCharges = 12
CompactRunes.BCPerUse = 2
CompactRunes.altRuneBkg = nil
CompactRunes.enabled = {}
CompactRunes.adjustments = {
	["Tricks of the Trade"] = nil,
}
CompactRunes.adjustmentMods = {
	["Tricks of the Trade"] = 1.15,
}

local Broker = _G.CreateFrame("Frame")
Broker.obj = LDB:NewDataObject(_G.GetAddOnMetadata(ADDON_NAME, "Title"), {
    type = "data source",
    icon = "Interface\\Icons\\Spell_DeathKnight_RuneTap",
    label = _G.GetAddOnMetadata(ADDON_NAME, "Title"),
    text = _G.GetAddOnMetadata(ADDON_NAME, "Title"),
    barValue = 0,
    barR = 0,
    barG = 0,
    barB = 1,
	OnClick = function(clickedframe, button)
		if button == "RightButton" then
			local optionsFrame = _G.InterfaceOptionsFrame

			if optionsFrame:IsVisible() then
				optionsFrame:Hide()
			else
				CompactRunes:ShowOptions()
			end
		elseif button == "LeftButton" and _G.IsShiftKeyDown() then
		    CompactRunes.TotalStats:Reset()
		    CompactRunes.LastFightStats:Reset()
        end
	end
} )

local GREEN = "|cff00ff00"
local YELLOW = "|cffffff00"
local BLUE = "|cff0198e1"
local ORANGE = "|cffff9933"
local addonHdr = GREEN.."%s %s"
local totalDataHdr = ORANGE..L["Session"]
local lastFightValueHdr = ORANGE..L["Last Fight"]
local reProcFmt = "%s%d|r / %s%d|r / %s%d|r / %s%d"
local valuePlusPercFmt = "%d (%.1f%%)"
local reProcTypeHdr = "    %s%s"

local function valuePlusPercent(value, total)
	local val = value or 0
	local tot = total or 0
	local perc = (tot > 0) and (val / tot * 100) or 0
	return valuePlusPercFmt:format(val, perc)
end

local function AddStats(tooltip, stats)
	local totalProcs = 0
	local reProcs = stats.reProcs
	for k, v in pairs(reProcs) do
		totalProcs = totalProcs + (v or 0)
	end
	local reRegenUses = stats.regenUses["RE"] or 0
	local rcRegenUses = stats.regenUses["RC"] or 0
	local btRegenUses = stats.regenUses["BT"] or 0

    tooltip:AddSeparator(1)
	tooltip:AddLine(L["Blood Charges Capped"],
		valuePlusPercent(stats.cappedBC, btRegenUses))
	tooltip:AddLine(L["Runic Corruption Procs"],
		valuePlusPercent(stats.rcProcs, rcRegenUses))
	tooltip:AddLine(L["Runic Empowerment Procs"],
		valuePlusPercent(totalProcs, reRegenUses))
	tooltip:AddLine(
		reProcTypeHdr:format(RuneChatColors["BLOOD"],"Blood"),
			valuePlusPercent(reProcs[1], totalProcs))
	tooltip:AddLine(
		reProcTypeHdr:format(RuneChatColors["UNHOLY"],"Unholy"),
			valuePlusPercent(reProcs[2], totalProcs))
	tooltip:AddLine(
		reProcTypeHdr:format(RuneChatColors["FROST"],"Frost"),
			valuePlusPercent(reProcs[3], totalProcs))
	tooltip:AddLine(
		reProcTypeHdr:format(RuneChatColors["DEATH"],"Death"),
			valuePlusPercent(reProcs[4], totalProcs))


	--tooltip:AddLine("RE Procs By Type",
	--	reProcFmt:format(RuneChatColors["BLOOD"], (reProcs[1] or 0), 
	--		RuneChatColors["UNHOLY"], (reProcs[2] or 0), 
	--		RuneChatColors["FROST"], (reProcs[3] or 0), 
	--		RuneChatColors["DEATH"], (reProcs[4] or 0)))
end

function Broker.obj:OnEnter()
	local tooltip = LibQTip:Acquire("CompactRunesTooltip", 2, "LEFT", "RIGHT")
	self.tooltip = tooltip 

    tooltip:AddHeader(addonHdr:format(_G.GetAddOnMetadata(ADDON_NAME,"Title"), ADDON_VERSION))
    tooltip:AddLine()

    if CompactRunes.isDK then
        tooltip:AddLine(L["Shift + Left-Click to reset"], "", 1, 1, 1)
        tooltip:AddLine()

        tooltip:AddLine(totalDataHdr)
        AddStats(tooltip, CompactRunes.TotalStats)

        tooltip:AddLine()
	    tooltip:AddLine(lastFightValueHdr)
        AddStats(tooltip, CompactRunes.LastFightStats)	
    end

	tooltip:SmartAnchorTo(self)
	tooltip:Show()
end

function Broker.obj:OnLeave()
	LibQTip:Release(self.tooltip)
	self.tooltip = nil
end

local LookupOrKeyMT = {__index = function (t,k) return k end}
local SpellIds = {
	["Frost Fever"] = 59921,
	["Blood Plague"] = 59879,
	["Frost Fever Periodic"] = 55095,
	["Blood Plague Periodic"] = 55078,
	["Freezing Fog"] = 59052,
	["Killing Machine"] = 51128,
	["Sudden Doom"] = 49530,
	["Blood Charge"] = 114851,
	["Shadow Infusion"] = 91342,
	["Dark Transformation"] = 63560,
	["Death Coil"] = 47541,
	["Death Coil Damage"] = 47632,
	["Death Coil Heal"] = 47633,
	["Rune Strike"] = 56815,
	["Frost Strike"] = 49143,
	["Blood Tap"] = 45529,
	["Runic Empowerment"] = 81229,
	["Runic Corruption"] = 51460,
	["Dark Succor"] = 101568,
	["Crimson Scourge"] = 81141,
	["Plague Leech"] = 123693,
	["Plague Strike"] = 45462,
	["Outbreak"] = 77575,
	["Soul Reaper"] = 130735,
	["Soul Reaper (Blood)"] = 114866,
	["Soul Reaper (Frost)"] = 130735,
	["Soul Reaper (Unholy)"] = 130736,
	["Pillar of Frost"] = 51271,
	["Cinderglacier"] = 53386,
	["Auto Attack"] = 6603,
	["Bone Shield"] = 49222,
	["Blood Shield"] = 77535,
	["Summon Gargoyle"] = 49206,
	["Unholy Frenzy"] = 49016,
	["Tricks of the Trade"] = 57933,
	["Rune Tap"] = 48982,
	["Vampiric Blood"] = 55233,
	["Dancing Rune Weapon"] = 49028,
	["Icebound Fortitude"] = 48792,
	["Anti-Magic Shell"] = 48707,
	["Death Pact"] = 48743,
	["Army of the Dead"] = 42650,
	["Empower Rune Weapon"] = 47568,
	["Feathers of Fury"] = 138759,
	["Determination"] = 146250,
	["Surge of Strength"] = 138702,
	["Tenacious"] = 148899,
	["Outrage"] = 146245,
}
local SpellNames = {}
local SpellIcons = {}
_G.setmetatable(SpellNames, LookupOrKeyMT)
local function LoadSpellNames()
	for k, v in pairs(SpellIds) do
		local name, _, icon = _G.GetSpellInfo(v)
		SpellNames[k] = name
		SpellIcons[k] = icon
	end
end
LoadSpellNames()
CompactRunes.SpellIds = SpellIds
CompactRunes.SpellNames = SpellNames
CompactRunes.SpellIcons = SpellIcons

local ItemIds = {
	["Steadfast Talisman of the Shado-Pan Assault"] = 94507,
	["Brutal Talisman of the Shado-Pan Assault"] = 94508,
	["Fortitude of the Zandalari"] = 94516,
	["Fabled Feather of Ji-Kun"] = 94515,
	["Thok's Tail Tip"] = 102305,
	["Fusion-Fire Core"] = 102295,
	["Evil Eye of Galakras"] = 102298,
}
local ItemNames = {}
local ItemIcons = {}
local ReverseItemNames = {}
_G.setmetatable(ItemNames, LookupOrKeyMT)
local function LoadItemNames()
	for k, v in pairs(ItemIds) do
		local name = _G.GetItemInfo(v)
		local icon = _G.GetItemIcon(v)
		ItemNames[k] = name
		ItemIcons[k] = icon
		if name then
			ReverseItemNames[name] = k
		end
	end
end
LoadItemNames()
CompactRunes.ItemIds = ItemIds
CompactRunes.ItemNames = ItemNames
CompactRunes.ItemIcons = ItemIcons
CompactRunes.ReverseItemNames = ReverseItemNames

local ItemProcs = {
	["Fabled Feather of Ji-Kun"] = {
		proc = "Feathers of Fury",
		procIds = { 138759 },
	},
	["Thok's Tail Tip"] = {
		proc = "Determination",
		procIds = { 146250 },
		icd = 115,
	},
	["Fusion-Fire Core"] = {
		proc = "Tenacious",
		procIds = { 148899 },
		icd = 115,
	},
	["Evil Eye of Galakras"] = {
		proc = "Outrage",
		procIds = { 146245 },
		icd = 55,
	},
	["Brutal Talisman of the Shado-Pan Assault"] = {
		proc = "Surge of Strength",
		procIds = { 138702 },
		icd = 85,
	},
}
CompactRunes.ItemProcs = ItemProcs

local millFmt = "%.0fm"
local thousandFmt = "%.0fk"
local function FormatNumber(number)
    if tonumber(number) == nil then
        return number
    end

    if number > 1000000 then
        return millFmt:format(number / 1000000)
    elseif number > 1000 then
        return thousandFmt:format(number / 1000)
    end

    return number
end

local frames = {}

CompactRunes.PriorityListDefaults = {
	["Blood"] = {
		"Plague Leech",
		"Soul Reaper",
		"Crimson Scourge",					
		"Dark Succor",		
		"Blood Charge",
	},
	["Frost"] = {
		"Plague Leech",
		"Soul Reaper",
		"Killing Machine", 
		"Freezing Fog", 
		"Blood Charge",
		"Dark Succor",
		"Pillar of Frost",
	},
	["Unholy"] = {
		"Plague Leech",
		"Soul Reaper",
		"Sudden Doom", 
		"Summon Gargoyle",
		"Unholy Frenzy",
		"Blood Charge",
		"Dark Succor",
	},
}

CompactRunes.DefaultCDBarOrderings = {
	["Blood"] = {
		"Rune Tap",
		"Vampiric Blood",
		"Anti-Magic Shell",
		"Outbreak",
		"Dancing Rune Weapon",
		"Death Pact",
		"Icebound Fortitude",
		"Empower Rune Weapon",
		"Army of the Dead",
		"Steadfast Talisman of the Shado-Pan Assault",
		"Fortitude of the Zandalari",
	},
	["Frost"] = {
		"Pillar of Frost",
		"Outbreak",
		"Anti-Magic Shell",
		"Empower Rune Weapon",
		"Army of the Dead",
		"Thok's Tail Tip",
		"Brutal Talisman of the Shado-Pan Assault",
		"Fabled Feather of Ji-Kun",
		"Fusion-Fire Core",
		"Evil Eye of Galakras",
	},
	["Unholy"] = {
		"Summon Gargoyle",
		"Unholy Frenzy",
		"Anti-Magic Shell",
		"Outbreak",
		"Empower Rune Weapon",
		"Army of the Dead",
		"Thok's Tail Tip",
		"Fabled Feather of Ji-Kun",
		"Brutal Talisman of the Shado-Pan Assault",
		"Fusion-Fire Core",
		"Evil Eye of Galakras",
	},
}

-- These procs are handled differently.
CompactRunes.specialProcs = {
	["Soul Reaper"] = true,
	["Plague Leech"] = true,
	["Pillar of Frost"] = true,
	["Summon Gargoyle"] = true,
	["Unholy Frenzy"] = true,
}

CompactRunes.soulReaperIds = {
	["Blood"] = SpellIds["Soul Reaper (Blood)"],
	["Frost"] = SpellIds["Soul Reaper (Frost)"],
	["Unholy"] = SpellIds["Soul Reaper (Unholy)"]
}

CompactRunes.regenAbilities = {
	[SpellIds["Death Coil"]] = true,
	[SpellIds["Rune Strike"]] = true,
	[SpellIds["Frost Strike"]] = true,
	[SpellIds["Death Coil Damage"]] = true,
}

function CompactRunes:MergeLists(list, settings, defaults)
	local uniques = {}
	local added = {}
	for i, v in ipairs(defaults) do
		uniques[v] = true
	end
	if settings then
		for i, v in ipairs(settings) do
			if v and uniques[v] and not added[v] then
				tinsert(list, v)
				added[v] = true
			end
		end
	end
	for i, v in ipairs(defaults) do
		if v and not added[v] then
			tinsert(list, v)
			added[v] = true
		end
	end
end

function CompactRunes:UpdatePriorityListSettings()
	for spec, list in pairs(self.PriorityListDefaults) do
		local list = {}
		self:MergeLists(
			list,
			self.db.profile.priorityList[spec],
			self.PriorityListDefaults[spec])
		self.db.profile.priorityList[spec] = list
	end
end

function CompactRunes:UpdateCDBarOrderings()
	for spec, list in pairs(self.DefaultCDBarOrderings) do
		local list = {}
		self:MergeLists(
			list,
			self.db.profile.cdbars[spec].ordering,
			self.DefaultCDBarOrderings[spec])
		self.db.profile.cdbars[spec].ordering = list
	end
end

function CompactRunes:MigrateSettings()
	local version = self.db.profile.profileVersion
	if version and version < 2 then
		for spec, list in pairs(self.db.profile.priorityList) do
			self.db.profile.priorityList[spec] = {}
		end
	end
	self.db.profile.profileVersion = 2
end

function CompactRunes:ResetPriorityList(spec)
	self.db.profile.priorityList[spec] = {}
	self:UpdatePriorityList(spec)
end

function CompactRunes:RemoveDefaults()
	for spec, list in pairs(self.PriorityListDefaults) do
		local matches = true
		local profile = self.db.profile.priorityList[spec]
		for i, v in ipairs(list) do
			if not (v and profile[i] and profile[i] == v) then
				matches = false
			end
		end
		if matches then
			self.db.profile.priorityList[spec] = {}
		end
	end
end

local defaults = {
	profile = {
		minimap = {
			hide = true,
		},
		debug = false,
		debugBP = false,
		locked = false,
		hideBlizzardFrames = false,
		ooc_alpha = 0.4,
		combatAlpha = 1.0,
		rechargeAlpha = 0.3,
		runeRechargeNums = false,
		almostReadyTime = 0,
		almostReadyAlpha = 0.6,
		runeBackground = 1,
		runeBackgroundAlpha = 0.1,
		runeBackgrounds = {
			transparent = { r = 0.0, g = 0.0, b = 0.0, a = 0.0 },
			black = { r = 0.0, g = 0.0, b = 0.0, a = 1.0 },
		},
		RuneColors = {
			["BLOOD"] = { r = 0.77, g = 0.12, b = 0.23, a = 1.0 },
			["UNHOLY"] = { r = 0.3, g = 0.8, b = 0.1, a = 1.0 },
			["FROST"] = { r = 0.0, g = 0.4, b = 0.7, a = 1.0 },
			["DEATH"] = { r = 0.51, g = 0.23, b = 0.65, a = 1.0 },
		},
		RuneCooldownColors = {
			["BLOOD"] = { r = 1.0, g = 0.0, b = 0.0, a = 0.1 },
			["UNHOLY"] = { r = 0.0, g = 1.0, b = 0.0, a = 0.1 },
			["FROST"] = { r = 0.0, g = 0.0, b = 1.0, a = 0.1 },
			["DEATH"] = { r = 1.0, g = 0.0, b = 1.0, a = 0.1 },
			["NONE"] = { r = 0.0, g = 0.0, b = 0.0, a = 0.0 },
		},
		rangeInd = true,
		plRefresh = 3,
		plOutbreak = true,
		trackDiseases = true,
		diseaseThresholdType = "Percent",
		diseaseThreshold = 0.1,
		diseaseThresholdAmt = 1000,
		adjustments = {
			["Tricks of the Trade"] = true,
		},
		font_face = "Friz Quadrata TT",
		font_size = 12,
		fontFlags = {
			OUTLINE = true,
			THICKOUTLINE = false,
			MONOCHROME = false
		},
		texture = "Compact Runes",
		border = "Compact Runes",
		runeOrder = "BFU",
		diseaseOrder = "BF",
		width = 30,
		height = 10,
		spacing = 4,
		["frame"] = {
			x = 0,
			y = 0,
			color = { r = 0.1, g = 0.1, b = 0.1, a = 1.0 },
			bdcolor = { r = 0.5, g = 0.5, b = 0.5, a = 1.0 },
			rccolor = { r = 1.0, g = 1.0, b = 1.0, a = 0.7 },
		},
		["procIcon"] = {
			scale = 1.0,
			userPlaced = false,
			x = 0,
			y = 0,
		},
		["runes"] = {
			inset = 6,
		},
		procs = true,
		enabled = {
			["Blood"] = {
				["Blood Charge"] = false,
				["Soul Reaper"] = true,
				["Crimson Scourge"] = true,					
				["Dark Succor"] = true,
				["Plague Leech"] = false,
			},
			["Frost"] = {
				["Soul Reaper"] = true,
				["Freezing Fog"] = true, 
				["Killing Machine"] = true, 
				["Blood Charge"] = false,
				["Dark Succor"] = true,
				["Plague Leech"] = false,
			},
			["Unholy"] = {
				["Soul Reaper"] = true,
				["Sudden Doom"] = true, 
				["Blood Charge"] = false,
				["Dark Succor"] = true,
				["Plague Leech"] = false,
			},
		},
		priorityList = {
			["Blood"] = {},
			["Frost"] = {},
			["Unholy"] = {},
		},
		cdbars = {
			['**'] = {
				enabled = false,
				x = nil,
				y = nil,
				spacing = 5,
				maxItemsPerRow = 10,
				maxRows = 2,
				oocAlpha = 0.6,
				combatAlpha = 1.0,
				inactiveAlpha = 0.4,
				activeAlpha = 1.0,
				textcolor = { r = 0.85, g = 0.85, b = 0.0, a = 1.0 },
				showCDText = true,
				textFontSize = 14,
				fontFace = "Friz Quadrata TT",
			},
			["Unholy"] = {
				cds = {
					["Outbreak"] = {
						enabled = true,
						type = "spell",
					},
					["Summon Gargoyle"] = {
						enabled = true,
						type = "spell",
					},
					["Unholy Frenzy"] = {
						enabled = true,
						type = "spell",
					},
					["Anti-Magic Shell"] = {
						enabled = true,
						type = "spell",
					},
					["Empower Rune Weapon"] = {
						enabled = true,
						type = "spell",
					},
					["Army of the Dead"] = {
						enabled = true,
						type = "spell",
					},
					["Thok's Tail Tip"] = {
						enabled = true,
						type = "itemicd",
					},
					["Fabled Feather of Ji-Kun"] = {
						enabled = true,
						type = "itemproc",
					},
					["Brutal Talisman of the Shado-Pan Assault"] = {
						enabled = true,
						type = "itemicd",
					},
					["Fusion-Fire Core"] = {
						enabled = true,
						type = "itemicd",
					},
					["Evil Eye of Galakras"] = {
						enabled = true,
						type = "itemicd",
					},
				},
				ordering = {},
			},
			["Frost"] = {
				cds = {
					["Outbreak"] = {
						enabled = true,
						type = "spell",
					},
					["Pillar of Frost"] = {
						enabled = true,
						type = "spell",
					},
					["Anti-Magic Shell"] = {
						enabled = true,
						type = "spell",
					},
					["Empower Rune Weapon"] = {
						enabled = true,
						type = "spell",
					},
					["Army of the Dead"] = {
						enabled = true,
						type = "spell",
					},
					["Thok's Tail Tip"] = {
						enabled = true,
						type = "item",
					},
					["Fabled Feather of Ji-Kun"] = {
						enabled = true,
						type = "itemproc",
					},
					["Brutal Talisman of the Shado-Pan Assault"] = {
						enabled = true,
						type = "itemicd",
					},
					["Fusion-Fire Core"] = {
						enabled = true,
						type = "itemicd",
					},
					["Evil Eye of Galakras"] = {
						enabled = true,
						type = "itemicd",
					},
				},
				ordering = {},
			},
			["Blood"] = {
				cds = {
					["Outbreak"] = {
						enabled = true,
						type = "spell",
					},
					["Rune Tap"] = {
						enabled = true,
						type = "spell",
					},
					["Vampiric Blood"] = {
						enabled = true,
						type = "spell",
					},
					["Anti-Magic Shell"] = {
						enabled = true,
						type = "spell",
					},
					["Dancing Rune Weapon"] = {
						enabled = true,
						type = "spell",
					},
					["Death Pact"] = {
						enabled = true,
						type = "spell",
					},
					["Icebound Fortitude"] = {
						enabled = true,
						type = "spell",
					},
					["Steadfast Talisman of the Shado-Pan Assault"] = {
						enabled = true,
						type = "item",
					},
					["Fortitude of the Zandalari"] = {
						enabled = true,
						type = "item",
					},
					["Army of the Dead"] = {
						enabled = true,
						type = "spell",
					},
					["Empower Rune Weapon"] = {
						enabled = true,
						type = "spell",
					},
				},
				ordering = {},
			},
		},
		blocks = {
			['**'] = {
				width = 30,
				height = 10,
				textcolor = { r = 1.0, g = 1.0, b = 1.0, a = 1.0 },
				userPlaced = false,
				x = nil,
				y = nil,
				reapplycolor = {
					[-1] = { r = 0.8, g = 0.1, b = 0.1, a = 0.5 },
					[1] = { r = 0.8, g = 0.8, b = 0.1, a = 0.5 },
					[2] = { r = 0.1, g = 0.8, b = 0.1, a = 0.5 },
				},
			},
			["FrostFeverStrength"] = {
				enabled = false,
				background = true,
				fontSize = 12,
				offset = 6,
				bgcolor = { r = 0.0, g = 0.0, b = 0.5, a = 0.8 },
			},
			["BloodPlagueStrength"] = {
				enabled = false,
				background = true,
				fontSize = 12,
				offset = 6,
				bgcolor = { r = 0.0, g = 0.0, b = 0.5, a = 0.8 },
			},
		},
		-- Bars
		bars = {
			-- Provide defaults for all bars.
			-- These are inherited if no bar or no value is set.
			['**'] = {
				textcolor = { r = 1.0, g = 1.0, b = 1.0, a = 1.0 },
				userPlaced = false,
				x = nil,
				y = nil,
			},
			["RunicPowerBar"] = {
				enabled = true,
				color = { r = 0.0, g = 0.82, b = 1.0, a = 1.0 },
				bgcolor = { r = 0.0, g = 0.205, b = 0.25, a = 1.0 },
				textcolor = { r = 0.66, g = 0.82, b = 1.0, a = 1.0 },
			},
			["BloodShieldBar"] = {
				enabled = false,
				color = { r = 1.0, g = 0.1, b = 0.1, a = 1.0 },
				bgcolor = { r = 0.5, g = 0.05, b = 0.05, a = 1.0 },
				textcolor = { r = 1.0, g = 0.85, b = 0.85, a = 1.0 },
			},
			["FrostFeverBar"] = {
				enabled = true,
				color = { r = 0.0, g = 0.45, b = 0.6, a = 1.0 },
				bgcolor = { r = 0.0, g = 0.1125, b = 0.15, a = 0.9 },
				textcolor = { r = 0.8, g = 0.8, b = 0.8, a = 1.0 },
				reapplycolor = {
					[-1] = { r = 0.8, g = 0.1, b = 0.1, a = 1.0 },
					[1] = { r = 0.8, g = 0.8, b = 0.1, a = 1.0 },
					[2] = { r = 0.1, g = 0.8, b = 0.1, a = 1.0 },
				},
			},
			["BloodPlagueBar"] = {
				enabled = true,
				color = { r = 0.5, g = 0.0, b = 0.6, a = 1.0 },
				bgcolor = { r = 0.125, g = 0.0, b = 0.15, a = 0.9 },
				textcolor = { r = 0.8, g = 0.8, b = 0.8, a = 1.0 },
				reapplycolor = {
					[-1] = { r = 0.8, g = 0.1, b = 0.1, a = 1.0 },
					[1] = { r = 0.8, g = 0.8, b = 0.1, a = 1.0 },
					[2] = { r = 0.1, g = 0.8, b = 0.1, a = 1.0 },
				},
			},
			["DarkTransformationBar"] = {
				enabled = true,
				color = { r = 0.0, g = 0.5, b = 0.0, a = 1.0 },
				bgcolor = { r = 0.125, g = 0.0, b = 0.15, a = 0.9 },
				textcolor = { r = 0.83, g = 0.66, b = 0.86, a = 1.0 },
				alt_color = { r = 0.5, g = 0.25, b = 0.0, a = 1.0 },
				alt_textcolor = { r = 0.8, g = 0.8, b = 0.8, a = 1.0 },
			},
			["BloodChargeBar"] = {
				enabled = true,
				color = { r = 1.0, g = 0.0, b = 0.0, a = 1 },
				bgcolor = { r = 0.65, g = 0.0, b = 0.0, a = 0.8 },
				textcolor = { r = 1.0, g = 0.9, b = 0.9, a = 1.0 },
			},
			["BoneShieldBar"] = {
				enabled = false,
				progress = "Time",
				showCooldown = true,
				showReady = true,
				color = { r = 0.1, g = 0.45, b = 0.1, a = 1.0 },
				bgcolor = { r = 0.05, g = 0.15, b = 0.05, a = 0.9 },
				textcolor = { r = 0.9, g = 1.0, b = 0.9, a = 1.0 },
				rechargeTextColor = { r = 1.0, g = 0.7, b = 0.7, a = 1.0 },
			},
		},
	},
}

function CompactRunes:SetRuneBackground()
	local setting = self.db.profile.runeBackground

	if setting == nil or tonumber(setting) == nil or setting < 1 or setting > 3 then
		self.db.profile.runeBackground = 1
		setting = 1
	end

	if setting == 3 then
		self.altRuneBkg = self.db.profile.runeBackgrounds.black
	else
		self.altRuneBkg = self.db.profile.runeBackgrounds.transparent
	end
end

function CompactRunes:UpdateBoneShieldBarMode()
	local bar = frames.boneBar
    if bar.db.progress == "Time" then
        bar.bar:SetMinMaxValues(0, 1)
        bar.bar:SetValue(1)
    elseif bar.db.progress == "Charges" then
        bar.bar:SetMinMaxValues(0, 6)
        bar.bar:SetValue(0)
    elseif bar.db.progress == "None" then
        bar.bar:SetMinMaxValues(0, 1)
        bar.bar:SetValue(1)        
    end
end

function CompactRunes:GetOptions()
    if not options then
        options = {
            type = "group",
            name = _G.GetAddOnMetadata(ADDON_NAME, "Title"),
            args = {
				core = self:GetGeneralOptions(),
				strength = self:GetDiseaseStrengthOptions(),
				cooldowns = self:GetCooldownOptions(),
				layout = self:GetLayoutOptions(),
				colors = self:GetColorsOptions(),
				procs = self:GetProcsOptions()
            }
        }
		options.args.profile = _G.LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
    end
    return options
end

function CompactRunes:ShowOptions()
	_G.InterfaceOptionsFrame_OpenToCategory(self.optionsFrame.Main)
end

function CompactRunes:GetGeneralOptions()
	local core = {
	    order = 1,
		name = L["General Options"],
		type = "group",
		args = {
		    description = {
		        order = 1,
		        type = "description",
		        name = L["CompactRunes_Desc"],
		    },
		    generalOptions = {
		        order = 100,
		        type = "header",
		        name = L["General Options"],
		    },
			locked = {
				name = L["Lock"],
				desc = L["LockDesc"],
				type = "toggle",
				order = 110,
				set = function(info, val)
				    self.db.profile.locked = val
					if frames.main then
						frames.main.lock = val
						frames.main:EnableMouse(not val)
					end
					for name, bar in pairs(self.cdbars) do
						if bar then bar:Lock(val) end
					end
				end,
                get = function(info)
					return self.db.profile.locked
				end,
			},
			hideBlizzard = {
				name = L["Hide Blizzard Runes"],
				desc = L["HideBlizzardDesc"],
				type = "toggle",
				order = 115,
				set = function(info, val)
					self.db.profile.hideBlizzardFrames = val
				end,
                get = function(info)
					return self.db.profile.hideBlizzardFrames
				end,
			},
    	    minimap = {
    			order = 120,
                name = L["Minimap Button"],
                desc = L["Toggle the minimap button"],
                type = "toggle",
                set = function(info,val)
                    	-- Reverse the value since the stored value is to hide it
                        self.db.profile.minimap.hide = not val
                    	if self.db.profile.minimap.hide then
                    		Icon:Hide("CompactRunesLDB")
                    	else
                    		Icon:Show("CompactRunesLDB")
                    	end
                      end,
                get = function(info)
            	        -- Reverse the value since the stored value is to hide it
                        return not self.db.profile.minimap.hide
                      end,
            },
			runeOrder = {
				order = 130,
				name = L["Rune Order"],
				desc = L["RuneOrder_Desc"],
				type = "select",
				values = {
				    ["BFU"] = L["Blood, Frost, Unholy"],
				    ["BUF"] = L["Blood, Unholy, Frost"],
				    ["FBU"] = L["Frost, Blood, Unholy"],
				    ["FUB"] = L["Frost, Unholy, Blood"],
				    ["UFB"] = L["Unholy, Frost, Blood"],
				    ["UBF"] = L["Unholy, Blood, Frost"],
				},
				set = function(info, val)
				    self.db.profile.runeOrder = val
					self:SetRuneOrder(val)
				end,
                get = function(info)
                    return self.db.profile.runeOrder
                end,
			},
			diseaseOrder = {
				order = 140,
				name = L["Disease Order"],
				desc = L["DiseaseOrder_Desc"],
				type = "select",
				values = {
				    ["FB"] = SpellNames["Frost Fever"]..", "..SpellNames["Blood Plague"],
				    ["BF"] = SpellNames["Blood Plague"]..", "..SpellNames["Frost Fever"],
				},
				set = function(info, val)
				    self.db.profile.diseaseOrder = val
					if frames.ffBar and frames.bpBar then
						frames.ffBar:SetPoint()
						frames.bpBar:SetPoint()
					end
				end,
                get = function(info)
                    return self.db.profile.diseaseOrder
                end,
			},
			rangeInd = {
				name = L["Range Indicator"],
				desc = L["RangeInd_Desc"],
				type = "toggle",
				order = 150,
				set = function(info, val)
				    self.db.profile.rangeInd = val
				end,
                get = function(info)
					return self.db.profile.rangeInd
				end,
			},
		    displayAlphas = {
		        order = 190,
		        type = "header",
		        name = L["Display Alpha"],
		    },
			combatAlpha = {
				order = 191,
				name = L["In Combat"],
				desc = L["In Combat"],
				type = "range",
				min = 0,
				max = 1,
				step = 0.05,
				set = function(info, val)
				    self.db.profile.combatAlpha = val
				end,
				get = function(info, val)
				    return self.db.profile.combatAlpha
				end,					
			},
			ooc_alpha = {
				order = 192,
				name = L["Out of Combat"],
				desc = L["Out of Combat"],
				type = "range",
				min = 0,
				max = 1,
				step = 0.05,
				set = function(info, val)
				    self.db.profile.ooc_alpha = val
					if frames.main and not _G.InCombatLockdown() then
						frames.main:SetAlpha(self.db.profile.ooc_alpha)
					end
				end,
				get = function(info, val)
				    return self.db.profile.ooc_alpha
				end,					
			},
		    refreshingRunes = {
		        order = 200,
		        type = "header",
		        name = L["Recharging Runes"],
		    },
			rechargeAlpha = {
				order = 210,
				name = L["Recharge Alpha"],
				desc = L["RechargeAlpha_Desc"],
				type = "range",
				min = 0,
				max = 1,
				step = 0.05,
				set = function(info, val)
				    self.db.profile.rechargeAlpha = val
					if frames.main and not _G.InCombatLockdown() then
						frames.main:SetAlpha(self.db.profile.rechargeAlpha)
					end
				end,
				get = function(info, val)
				    return self.db.profile.rechargeAlpha
				end,					
			},
			showNums = {
				name = L["Show Timer"],
				desc = L["RechargeTimerDesc"],
				type = "toggle",
				order = 220,
				set = function(info, val)
				    self.db.profile.runeRechargeNums = val
					self:ShowRechargeNumbers(val)
				end,
                get = function(info)
					return self.db.profile.runeRechargeNums
				end,
			},
			almostReady = {
				order = 230,
				name = L["Almost Ready"],
				desc = L["AlmostReady_Desc"],
				type = "range",
				min = 0,
				max = 4,
				step = 0.5,
				set = function(info, val)
				    self.db.profile.almostReadyTime = val
				end,
				get = function(info, val)
				    return self.db.profile.almostReadyTime
				end,
			},
			almostReadyAlpha = {
				order = 240,
				name = L["Almost Ready Alpha"],
				desc = L["AlmostReadyAlpha_Desc"],
				type = "range",
				min = 0,
				max = 1,
				step = 0.05,
				set = function(info, val)
				    self.db.profile.almostReadyAlpha = val
				end,
				get = function(info, val)
				    return self.db.profile.almostReadyAlpha
				end,					
			},
		    runeBackgroundHdr = {
		        order = 290,
		        type = "header",
		        name = L["Rune Background"],
		    },
			runeBackground = {
				order = 291,
				name = L["Rune Background"],
				desc = L["RuneBackground_Desc"],
				type = "select",
				values = {
				    [1] = L["Rune Color"],
				    [2] = L["Transparent"],
				    [3] = L["Black"],
				},
				set = function(info, val)
				    self.db.profile.runeBackground = val
					self:SetRuneBackground()
					self:UpdateRunes()
				end,
                get = function(info)
                    return self.db.profile.runeBackground
                end,
			},
			runeBackgroundAlpha = {
				order = 295,
				name = L["Background Alpha"],
				desc = L["RuneBackgroundAlpha_Desc"],
				type = "range",
				min = 0,
				max = 1,
				step = 0.05,
				set = function(info, val)
				    self.db.profile.runeBackgroundAlpha = val
					self:SetRuneBackground()
					self:UpdateRunes()
				end,
				get = function(info, val)
				    return self.db.profile.runeBackgroundAlpha
				end,
				disabled = function()
					return self.db.profile.runeBackground ~= 1
				end,			
			},
		    features = {
		        order = 300,
		        type = "header",
		        name = L["Features"],
		    },
			runicpower = {
				name = L["Runic Power"],
				desc = L["RunicPowerDesc"],
				type = "toggle",
				order = 310,
				set = function(info, val)
				    self.db.profile.bars.RunicPowerBar.enabled = val
					self:ShowRunicPowerBar()
				end,
                get = function(info)
					return self.db.profile.bars.RunicPowerBar.enabled
				end,
			},
			frostFever = {
				name = SpellNames["Frost Fever"],
				desc = SpellNames["Frost Fever"],
				type = "toggle",
				order = 320,
				set = function(info, val)
				    self.db.profile.bars.FrostFeverBar.enabled = val
				end,
                get = function(info)
					return self.db.profile.bars.FrostFeverBar.enabled
				end,
			},
			bloodPlague = {
				name = SpellNames["Blood Plague"],
				desc = SpellNames["Blood Plague"],
				type = "toggle",
				order = 330,
				set = function(info, val)
				    self.db.profile.bars.BloodPlagueBar.enabled = val
				end,
                get = function(info)
					return self.db.profile.bars.BloodPlagueBar.enabled
				end,
			},
			darktrans = {
				name = SpellNames["Dark Transformation"],
				desc = SpellNames["Dark Transformation"],
				type = "toggle",
				order = 340,
				set = function(info, val)
				    self.db.profile.bars.DarkTransformationBar.enabled = val
					self:UpdateDTBCBars()
				end,
                get = function(info)
					return self.db.profile.bars.DarkTransformationBar.enabled
				end,
			},
			bloodcharge = {
				name = SpellNames["Blood Charge"],
				desc = SpellNames["Blood Charge"],
				type = "toggle",
				order = 350,
				set = function(info, val)
				    self.db.profile.bars.BloodChargeBar.enabled = val
					self:UpdateDTBCBars()
				end,
                get = function(info)
					return self.db.profile.bars.BloodChargeBar.enabled
				end,
			},
			bloodshield = {
				name = SpellNames["Blood Shield"],
				desc = SpellNames["Blood Shield"],
				type = "toggle",
				order = 360,
				set = function(info, val)
				    self.db.profile.bars.BloodShieldBar.enabled = val
				end,
                get = function(info)
					return self.db.profile.bars.BloodShieldBar.enabled
				end,
			},
			boneshield = {
				name = SpellNames["Bone Shield"],
				desc = SpellNames["Bone Shield"],
				type = "toggle",
				order = 365,
				set = function(info, val)
				    self.db.profile.bars.BoneShieldBar.enabled = val
					if not val and frames.boneBar then
						frames.boneBar:Hide()
					end
					self:CheckSpells()
				end,
                get = function(info)
					return self.db.profile.bars.BoneShieldBar.enabled
				end,
			},
			procs = {
				name = L["Procs"],
				desc = L["ProcsDesc"],
				type = "toggle",
				order = 370,
				set = function(info, val)
				    self.db.profile.procs = val
				end,
                get = function(info)
					return self.db.profile.procs
				end,
			},
			plagueLeech = {
		        order = 400,
		        type = "header",
		        name = SpellNames["Plague Leech"],
			},
			plRefreshTime = {
				order = 410,
				name = L["Refresh Time"],
				desc = L["PLRefresh_Desc"],
				type = "range",
				min = 1,
				max = 6,
				step = 0.5,
				set = function(info, val)
				    self.db.profile.plRefresh = val
				end,
				get = function(info, val)
				    return self.db.profile.plRefresh
				end,					
			},
			plOutbreak = {
				name = L["Require Outbreak"],
				desc = L["PLOutbreak_Desc"],
				type = "toggle",
				order = 420,
				set = function(info, val)
				    self.db.profile.plOutbreak = val
				end,
                get = function(info)
					return self.db.profile.plOutbreak
				end,
			},
			diseaseTrackingHdr = {
		        order = 450,
		        type = "header",
		        name = L["Disease Strength Tracking"],
			},
			trackDiseases = {
				name = L["Enabled"],
				desc = L["Enabled"],
				type = "toggle",
				order = 460,
				set = function(info, val)
				    self.db.profile.trackDiseases = val
					self:ToggleDiseaseTracking()
				end,
                get = function(info)
					return self.db.profile.trackDiseases
				end,
			},
			diseaseThreshold = {
				name = L["Threshold"],
				desc = L["Threshold"],
				type = "select",
				values = {
				    ["Percent"] = L["Percent"],
				    ["Fixed"] = L["Fixed"],
				},
				order = 470,
				set = function(info, val)
				    self.db.profile.diseaseThresholdType = val
				end,
                get = function(info)
                    return self.db.profile.diseaseThresholdType
                end,
			},
			diseaseThresholdPerc = {
				order = 471,
				name = L["Percent"],
				desc = L["Percent"],
				type = "range",
				min = 0.01,
				max = 1,
				step = 0.01,
				bigStep = 0.05,
				isPercent = true,
				set = function(info, val)
				    self.db.profile.diseaseThreshold = val
				end,
				get = function(info, val)
				    return self.db.profile.diseaseThreshold
				end,
				disabled = function()
					return self.db.profile.diseaseThresholdType ~= "Percent"
				end,
			},
			diseaseThresholdAmt = {
				order = 472,
				name = L["Amount"],
				desc = L["Amount"],
				type = "range",
				min = 0,
				max = 100000,
				step = 1,
				bigStep = 500,
				set = function(info, val)
				    self.db.profile.diseaseThresholdAmt = val
				end,
				get = function(info, val)
				    return self.db.profile.diseaseThresholdAmt
				end,
				disabled = function()
					return self.db.profile.diseaseThresholdType ~= "Fixed"
				end,
			},
			adjHdr = {
		        order = 480,
		        type = "header",
		        name = L["Adjustments"],
			},
			-- Adjustments added here dynamically
		    boneShieldOpts = {
		        order = 490,
		        type = "header",
		        name = SpellNames["Bone Shield"],
		    },
			boneProgress = {
				name = L["Progress Bar"],
				desc = L["BoneShieldProgressDesc"],
				type = "select",
				values = {
				    ["None"] = L["None"],
				    ["Time"] = L["Time Remaining"],
				    ["Charges"] = L["Charges"]
				},
				order = 491,
				set = function(info, val)
				    self.db.profile.bars["BoneShieldBar"].progress = val
			        self:UpdateBoneShieldBarMode()
				end,
                get = function(info)
                    return self.db.profile.bars["BoneShieldBar"].progress
                end,
			},
			showCooldown = {
				name = L["Show on Cooldown"],
				desc = L["ShowCooldownDesc"],
				type = "toggle",
				order = 492,
				set = function(info, val)
				    self.db.profile.bars["BoneShieldBar"].showCooldown = val
				end,
                get = function(info)
					return self.db.profile.bars["BoneShieldBar"].showCooldown
				end,
			},
			showReady = {
				name = L["Show when Ready"],
				desc = L["ShowReadyDesc"],
				type = "toggle",
				order = 493,
				set = function(info, val)
				    self.db.profile.bars["BoneShieldBar"].showReady = val
				end,
                get = function(info)
					return self.db.profile.bars["BoneShieldBar"].showReady
				end,
			},
		    dimensions = {
		        order = 500,
		        type = "header",
		        name = L["Dimensions"],
		    },
			width = {
				order = 510,
				name = L["Width"],
				desc = L["BarWidth_Desc"],	
				type = "range",
				min = 20,
				max = 100,
				step = 1,
				set = function(info, val)
				    self.db.profile.width = val
					self:Reset()
				end,
				get = function(info, val)
				    return self.db.profile.width
				end,
			},
			height = {
				order = 520,
				name = L["Height"],
				desc = L["BarHeight_Desc"],
				type = "range",
				min = 5,
				max = 50,
				step = 1,
				set = function(info, val)
				    self.db.profile.height = val
					self:Reset()
				end,
				get = function(info, val)
				    return self.db.profile.height
				end,					
			},
			procIconScale = {
				order = 530,
				name = L["Proc Indicator Scale"],
				desc = L["ProcIndScale_Desc"],
				type = "range",
				min = 1,
				max = 2,
				step = 0.01,
				bigStep = 0.05,
				isPercent = true,
				set = function(info, val)
				    self.db.profile.procIcon.scale = val
					frames.procInd:SetDimensions()
				end,
				get = function(info, val)
				    return self.db.profile.procIcon.scale
				end,					
			},
		    fonts = {
		        order = 600,
		        type = "header",
		        name = L["Font"],
		    },
			font_size = {
				order = 610,
				name = L["Font size"],
				desc = L["Font size for the bars."],
				type = "range",
				min = 8,
				max = 30,
				step = 1,
				set = function(info, val) 
					self.db.profile.font_size = val
					self:ResetFonts()
				end,
				get = function(info,val) return self.db.profile.font_size end,
			},
			font_face = {
				order = 620,
				type = "select",
				name = L["Font"],
				desc = L["Font to use."],
				values = LSM:HashTable("font"),
				dialogControl = 'LSM30_Font',
				get = function() return self.db.profile.font_face end,
				set = function(info, val) 
				    self.db.profile.font_face = val
					self:ResetFonts()
				end
			},
			font_outline = {
				name = L["Outline"],
				desc = L["FontOutlineDesc"],
				type = "toggle",
				order = 630,
				set = function(info, val)
				    self.db.profile.fontFlags.OUTLINE = val
				    self:ResetFonts()
				end,
                get = function(info)
                    return self.db.profile.fontFlags.OUTLINE
                end,
			},
			font_thickoutline = {
				name = L["Thick Outline"],
				desc = L["FontThickOutline_OptionDesc"],
				type = "toggle",
				order = 640,
				set = function(info, val)
				    self.db.profile.fontFlags.THICKOUTLINE = val
				    self:ResetFonts()
				end,
                get = function(info)
                    return self.db.profile.fontFlags.THICKOUTLINE
                end,
			},
			font_monochrome = {
				name = L["Monochrome"],
				desc = L["FontMonochromeDesc"],
				type = "toggle",
				order = 650,
				set = function(info, val)
				    self.db.profile.fontFlags.MONOCHROME = val
				    self:ResetFonts()
				end,
                get = function(info)
                    return self.db.profile.fontFlags.MONOCHROME
                end,
			},
            textures = {
                order = 700,
                type = "header",
                name = L["Textures"],
            },
			bartexture = {
				order = 710,
				name = L["Bar Texture"],
				desc = L["BarTexture_OptionDesc"],
				type = "select",
				values = LSM:HashTable("statusbar"),
				dialogControl = 'LSM30_Statusbar',
				get = function()
				    return self.db.profile.texture
				end,
				set = function(info, val)
				    self.db.profile.texture = val
					self:UpdateTextures()
				end,
			},
			bordertexture = {
				order = 720,
				name = L["Border"],
				desc = L["Border_OptionDesc"],
				type = "select",
				values = LSM:HashTable("border"),
				dialogControl = 'LSM30_Border',
				get = function()
				    return self.db.profile.border
				end,
				set = function(info, val)
				    self.db.profile.border = val
					self:SetMainFrameBorder()
				end,
			},
		},
	}

	local i = 481
	for name, val in pairs(self.db.profile.adjustments) do
		core.args["adjust"..name] = {
			name = SpellNames[name],
			desc = SpellNames[name],
			type = "toggle",
			order = i,
			set = function(info, val)
			    self.db.profile.adjustments[name] = val
			end,
            get = function(info)
				return self.db.profile.adjustments[name]
			end,
		}
		i = i + 1
	end

	return core
end

function CompactRunes:GetLayoutOptions()
	local layout = {
	    order = 1,
		name = L["Layout"],
		type = "group",
		inline = true,
		args = {
		    description = {
		        order = 1,
		        type = "description",
		        name = L["LayoutDesc"],
		    },
		    layoutHdr = {
		        order = 100,
		        type = "header",
		        name = L["Layout"],
		    },
		}
	}

	local bars = {
		["Proc Icon"] = {
			["frame"] = frames.procInd,
			["profile"] = self.db.profile.procIcon,
		},
		["Runic Power Bar"] = {
			["frame"] = frames.powerBar,
			["profile"] = self.db.profile.bars["RunicPowerBar"],
		},
		["Blood Shield Bar"] = {
			["frame"] = frames.bsBar,
			["profile"] = self.db.profile.bars["BloodShieldBar"],
		},
		["Frost Fever Bar"] = {
			["frame"] = frames.ffBar,
			["profile"] = self.db.profile.bars["FrostFeverBar"],
		},
		["Blood Plague Bar"] = {
			["frame"] = frames.bpBar,
			["profile"] = self.db.profile.bars["BloodPlagueBar"],
		},
		["Dark Transformation Bar"] = {
			["frame"] = frames.dtBar,
			["profile"] = self.db.profile.bars["DarkTransformationBar"],
		},
		["Blood Charge Bar"] = {
			["frame"] = frames.bcBar,
			["profile"] = self.db.profile.bars["BloodChargeBar"],
		},
		["Frost Fever Strength"] = {
			["frame"] = frames.ffStr,
			["profile"] = self.db.profile.blocks["FrostFeverStrength"],
		},
		["Blood Plague Strength"] = {
			["frame"] = frames.bpStr,
			["profile"] = self.db.profile.blocks["BloodPlagueStrength"],
		},
	}

	local i = 1
	for k, v in pairs(bars) do
		layout.args[k.."_Layout"] = {
			order = 101+i,
			type = "group",
			name = L[k],
			args = self:GetLayoutOptionsForBar(k, v),
		}
		i = i + 1
	end

	return layout
end

function CompactRunes:GetLayoutOptionsForBar(name, data)
	local frame = data.frame
	local profile = data.profile
	local layoutOpts = {
	    header = {
	        order = 100,
	        type = "header",
	        name = L[name],
	    },
		userPlaced = {
			name = L["Override"],
			desc = L["OverrideDesc"],
			type = "toggle",
			order = 110,
			set = function(info, val)
			    profile.userPlaced = val
				frame:SetDesiredPoint()
			end,
	        get = function(info)
				return profile.userPlaced
			end,
		},
		locked = {
			name = function()
				return frame:IsLocked() and L["Unlock"] or L["Lock"]
			end,
			desc = L["LockDesc"],
			type = "execute",
			order = 120,
			func = function(info, val)
				if frame then
					frame:Lock(not frame:IsLocked())
				end
			end,
			disabled = function()
				return not profile.userPlaced
			end,
		},
		procIconX = {
			order = 140,
			name = L["X Offset"],
			desc = L["XOffset_Desc"],	
			type = "range",
			softMin = -floor(_G.GetScreenWidth()),
			softMax = floor(_G.GetScreenWidth()),
			bigStep = 1,
			set = function(info, val)
			    profile.x = val
				frame:SetDesiredPoint()
			end,
			get = function(info, val)
			    return profile.x
			end,
			disabled = function()
				return profile.userPlaced == false
			end,
		},
		procIconY = {
			order = 150,
			name = L["Y Offset"],
			desc = L["YOffset_Desc"],	
			type = "range",
			softMin = -floor(_G.GetScreenHeight()),
			softMax = floor(_G.GetScreenHeight()),
			bigStep = 1,
			set = function(info, val)
			    profile.y = val
				frame:SetDesiredPoint()
			end,
			get = function(info, val)
			    return profile.y
			end,
			disabled = function()
				return profile.userPlaced == false
			end,
		},
	}
	return layoutOpts
end

function CompactRunes:GetProcsOptions()
	local procs = {
	    order = 2,
		name = L["Procs"],
		type = "group",
		inline = true,
		args = {
		    description = {
		        order = 1,
		        type = "description",
		        name = L["ProcsDesc"],
		    },
		    procsHdr = {
		        order = 100,
		        type = "header",
		        name = L["Procs"],
		    },
		},
	}

	local i = 1
	for k, v in pairs(self.db.profile.priorityList) do
		procs.args[k.."List"] = {
			order = 101+i,
			type = "group",
			name = k,
			args = self:GetProcsOptionsForSpec(k),
		}
		i = i + 1
	end

	return procs		
end

function CompactRunes:GetProcsOptionsForSpec(spec)
	local procList = {
        priorityList = {
	  	    order = 105,
	  	    type = "group",
	  	    inline = true,
	  	    name = L["Priority List"],
	  	    args = {
			},
		},
		reset = {
			order = 110,
			type = "execute",
			name = L["Reset Order"],
			confirmText = L["ResetOrderDesc"],
			confirm = true,
			func = function() self:ResetPriorityList(spec) end,
		},
	}
	
	if self.db.profile.priorityList[spec] then
		for k, v in pairs(self.db.profile.priorityList[spec]) do
			--local argName = v:gsub(" ", "_")
			procList.priorityList.args[v] = {
				name = SpellNames[v],
				desc = SpellNames[v],
				type = "toggle",
				order = function()
					local o = 0
					for pr, name in pairs(self.db.profile.priorityList[spec]) do
						if name == v then
							o = pr
						end
					end
					return 110 + (o * 5)
				end,
				set = function(info, val)
				    self.db.profile.enabled[spec][v] = val
				end,
		        get = function(info)
					return self.db.profile.enabled[spec][v]
				end,
			}
			procList.priorityList.args[v.."_Up"] = {
				name = L["Up"],
				desc = L["MoveUp_Desc"],
				type = "execute",
				width = "half",
				order = 111 + (k * 5),
				disabled = function()
					return k == 1
				end,
		        func = function(info)
					-- Swap with the one above it.
					local list = self.db.profile.priorityList[spec]
					local tmp = list[k - 1]

					if tmp then
						list[k - 1] = list[k]
						list[k] = tmp
					end
				end,
			}
			procList.priorityList.args[v.."_Down"] = {
				name = L["Down"],
				desc = L["MoveDown_Desc"],
				type = "execute",
				width = "half",
				order = 112 + (k * 5),
				disabled = function()
					return k >= #self.db.profile.priorityList[spec]
				end,
		        func = function(info)
					-- Swap with the one above it.
					local list = self.db.profile.priorityList[spec]
					local tmp = list[k + 1]
					if tmp then
						list[k + 1] = list[k]
						list[k] = tmp
					end
				end,
			}
		end
	end

	return procList
end

function CompactRunes:GetDiseaseStrengthOptions()
	local strength = {
	    order = 1,
		name = L["Disease Strength"],
		type = "group",
		args = {
		},
	}

	local diseaseValues = {
		["Frost Fever Strength"] = "ffStr",
		["Blood Plague Strength"] = "bpStr",
	}
	local i = 100
	for name, frameName in pairs(diseaseValues) do
		local dbname = name:gsub(" ", "")
		strength.args[name.."Hdr"] = {
	        order = i,
	        type = "header",
	        name = L[name],
		}
		strength.args[name.."Enabled"] = {
	        order = i + 1,
	        name = L["Enabled"],
			desc = L["Enabled"],
			type = "toggle",
			set = function(info, val)
			    self.db.profile.blocks[dbname].enabled = val
				local frame = frames[frameName]
				if frame and frame.UpdateLayout then frame:UpdateLayout() end
			end,
            get = function(info)
				return self.db.profile.blocks[dbname].enabled
			end,
		}
		strength.args[name.."Background"] = {
	        order = i + 2,
	        name = L["Background"],
			desc = L["Background"],
			type = "toggle",
			set = function(info, val)
			    self.db.profile.blocks[dbname].background = val
				local frame = frames[frameName]
				if frame and frame.UpdateLayout then frame:UpdateLayout() end
			end,
            get = function(info)
				return self.db.profile.blocks[dbname].background
			end,
		}
		strength.args[name.."Width"] = {
			order = i + 3,
			name = L["Width"],
			desc = L["BarWidth_Desc"],	
			type = "range",
			min = 20,
			max = 500,
			step = 1,
			set = function(info, val)
			    self.db.profile.blocks[dbname].width = val
				local frame = frames[frameName]
				if frame and frame.UpdateLayout then frame:UpdateLayout() end
			end,
			get = function(info, val)
			    return self.db.profile.blocks[dbname].width
			end,
		}
		strength.args[name.."Height"] = {
			order = i + 4,
			name = L["Height"],
			desc = L["BarHeight_Desc"],
			type = "range",
			min = 5,
			max = 200,
			step = 1,
			set = function(info, val)
			    self.db.profile.blocks[dbname].height = val
				local frame = frames[frameName]
				if frame and frame.UpdateLayout then frame:UpdateLayout() end
			end,
			get = function(info, val)
			    return self.db.profile.blocks[dbname].height
			end,					
		}
		strength.args[name.."Offset"] = {
			order = i + 5,
			name = L["Offset"],
			desc = L["Offset"],
			type = "range",
			min = 2,
			max = 400,
			step = 1,
			set = function(info, val)
			    self.db.profile.blocks[dbname].offset = val
				local frame = frames[frameName]
				if frame and frame.UpdateLayout then frame:UpdateLayout() end
			end,
			get = function(info, val)
			    return self.db.profile.blocks[dbname].offset
			end,					
		}
		strength.args[name.."FontSize"] = {
			order = i + 6,
			name = L["Font size"],
			desc = L["Font size"],
			type = "range",
			min = 8,
			max = 30,
			step = 1,
			set = function(info, val)
			    self.db.profile.blocks[dbname].fontSize = val
				local frame = frames[frameName]
				if frame and frame.UpdateLayout then frame:UpdateLayout() end
			end,
			get = function(info,val)
				return self.db.profile.blocks[dbname].fontSize
			end,
		}
		i = i + 100
	end
	return strength
end

function CompactRunes:GetCooldownOptions()
	local cooldowns = {
	    order = 2,
		name = L["Cooldown Bars"],
		type = "group",
		inline = true,
		args = {
		    description = {
		        order = 1,
		        type = "description",
		        name = L["CooldownBarsDesc"],
		    },
		    procsHdr = {
		        order = 100,
		        type = "header",
		        name = L["Cooldown Bars"],
		    },
		},
	}

	local i = 1
	for k, v in pairs(self.db.profile.cdbars) do
		if self.db.profile.cdbars[k] then
			cooldowns.args[k.."List"] = {
				order = 101+i,
				type = "group",
				name = k,
				args = self:GetCDOptionsForSpec(k),
			}
			i = i + 1
		end
	end

	return cooldowns
end

function CompactRunes:GetCDOptionsForSpec(spec)
	local options = {
		enabled = {
	  	    order = 105,
			name = L["Enabled"],
			desc = L["Enabled"],
			type = "toggle",
			set = function(info, val)
				self.db.profile.cdbars[spec].enabled = val
				self:UpdateCDBars()
			end,
			get = function(info)
				return self.db.profile.cdbars[spec].enabled
			end,
		},
		maxItemsPerRow = {
			order = 106,
			name = L["Max Items Per Row"],
			desc = L["Max Items Per Row"],	
			type = "range",
			min = 2,
			max = 20,
			step = 1,
			set = function(info, val)
				self.db.profile.cdbars[spec].maxItemsPerRow = val
				local bar = self.cdbars[spec]
				if bar then bar:Update() end
			end,
			get = function(info, val)
			    return self.db.profile.cdbars[spec].maxItemsPerRow
			end,
		},
	    alphaHdr = {
	        order = 110,
	        type = "header",
	        name = L["Display Alpha"],
	    },
		oocAlpha = {
			order = 111,
			name = L["Out of Combat"],
			desc = L["Out of Combat"],
			type = "range",
			min = 0,
			max = 1,
			step = 0.05,
			set = function(info, val)
			    self.db.profile.cdbars[spec].oocAlpha = val
				if self.currentSpec == spec then
					local bar = self.cdbars[spec]
					if bar and bar.SetAlpha then bar:SetAlpha() end
				end
			end,
			get = function(info, val)
			    return self.db.profile.cdbars[spec].oocAlpha
			end,					
		},
		combatAlpha = {
			order = 112,
			name = L["In Combat"],
			desc = L["In Combat"],
			type = "range",
			min = 0,
			max = 1,
			step = 0.05,
			set = function(info, val)
			    self.db.profile.cdbars[spec].combatAlpha = val
				if self.currentSpec == spec then
					local bar = self.cdbars[spec]
					if bar and bar.SetAlpha then bar:SetAlpha() end
				end
			end,
			get = function(info, val)
			    return self.db.profile.cdbars[spec].combatAlpha
			end,					
		},
	    layoutHdr = {
	        order = 130,
	        type = "header",
	        name = L["Layout"],
	    },
		xOffset = {
			order = 131,
			name = L["X Offset"],
			desc = L["XOffset_Desc"],	
			type = "range",
			softMin = -floor(_G.GetScreenWidth()),
			softMax = floor(_G.GetScreenWidth()),
			bigStep = 1,
			set = function(info, val)
				self.db.profile.cdbars[spec].x = val
				local bar = self.cdbars[spec]
				if bar then bar:Update() end
			end,
			get = function(info, val)
			    return self.db.profile.cdbars[spec].x
			end,
		},
		yOffset = {
			order = 132,
			name = L["Y Offset"],
			desc = L["YOffset_Desc"],	
			type = "range",
			softMin = -floor(_G.GetScreenHeight()),
			softMax = floor(_G.GetScreenHeight()),
			bigStep = 1,
			set = function(info, val)
			    self.db.profile.cdbars[spec].y = val
				local bar = self.cdbars[spec]
				if bar then bar:Update() end
			end,
			get = function(info, val)
			    return self.db.profile.cdbars[spec].y
			end,
		},
		fontSize = {
			order = 150,
			name = L["Font size"],
			desc = L["Font size for the bars."],
			type = "range",
			min = 8,
			max = 30,
			step = 1,
			set = function(info, val) 
				self.db.profile.cdbars[spec].textFontSize = val
				local bar = self.cdbars[spec]
				if bar then bar:ResetFonts() end
			end,
			get = function(info,val) return self.db.profile.cdbars[spec].textFontSize end,
		},
		fontFace = {
			order = 151,
			type = "select",
			name = L["Font"],
			desc = L["Font to use."],
			values = LSM:HashTable("font"),
			dialogControl = 'LSM30_Font',
			get = function() return self.db.profile.cdbars[spec].fontFace end,
			set = function(info, val) 
			    self.db.profile.cdbars[spec].fontFace = val
				local bar = self.cdbars[spec]
				if bar then bar:ResetFonts() end
			end
		},
        ordering = {
	  	    order = 200,
	  	    type = "group",
	  	    inline = true,
	  	    name = L["Cooldowns"],
	  	    args = {
			},
		},
	}
	for i, name in ipairs(self.db.profile.cdbars[spec].ordering) do
		--local argName = v:gsub(" ", "_")
		options.ordering.args[name] = {
			name = SpellNames[name],
			desc = SpellNames[name],
			type = "toggle",
			order = function()
				local o = 0
				for i, v in ipairs(self.db.profile.cdbars[spec].ordering) do
					if v == name then
						o = i
					end
				end
				return 210 + (o * 5)
			end,
			set = function(info, val)
				self.db.profile.cdbars[spec].cds[name].enabled = val
				local bar = self.cdbars[spec]
				if bar then bar:Update() end
			end,
	        get = function(info)
				return self.db.profile.cdbars[spec].cds[name].enabled
			end,
		}
		options.ordering.args[name.."_Up"] = {
			name = L["Up"],
			desc = L["MoveUp_Desc"],
			type = "execute",
			width = "half",
			order = 211 + (i * 5),
			disabled = function()
				return i == 1
			end,
	        func = function(info)
				-- Swap with the one above it.
				local list = self.db.profile.cdbars[spec].ordering
				local tmp = list[i - 1]

				if tmp then
					list[i - 1] = list[i]
					list[i] = tmp
				end
				local bar = self.cdbars[spec]
				if bar then
					bar:Swap(i, i - 1)
					bar:Update()
				end
			end,
		}
		options.ordering.args[name.."_Down"] = {
			name = L["Down"],
			desc = L["MoveDown_Desc"],
			type = "execute",
			width = "half",
			order = 212 + (i * 5),
			disabled = function()
				return i >= #self.db.profile.cdbars[spec].ordering
			end,
	        func = function(info)
				-- Swap with the one above it.
				local list = self.db.profile.cdbars[spec].ordering
				local tmp = list[i + 1]
				if tmp then
					list[i + 1] = list[i]
					list[i] = tmp
				end
				local bar = self.cdbars[spec]
				if bar then
					bar:Swap(i, i + 1)
					bar:Update()
				end
			end,
		}
	end

	return options
end

function CompactRunes:GetColorsOptions()
	local colors = {
	    order = 1,
		name = L["Colors"],
		type = "group",
		inline = true,
		args = {
		    layoutHdr = {
		        order = 100,
		        type = "header",
		        name = L["Colors"],
		    },
			runes = {
		  	    order = 200,
		  	    type = "group",
		  	    name = L["Runes"],
		  	    args = {},
			},
		}
	}

	local i = 100
	for runeColor, data in pairs(self.db.profile.RuneColors) do
		colors.args.runes.args[runeColor.."_Header"] = {
	        order = i,
	        type = "header",
	        name = RuneNames[runeColor] or "",
		}
		colors.args.runes.args[runeColor.."_Color"] = {
	        order = i + 1,
			name = L["Ready"],
			desc = L["Ready"],
			type = "color",
			hasAlpha = true,
			set = function(info, r, g, b, a)
			    local c = self.db.profile.RuneColors[runeColor]
			    c.r, c.g, c.b, c.a = r, g, b, a
				self:UpdateRuneColors()
				self:UpdateRunes()
			end,
			get = function(info)
		        local c = self.db.profile.RuneColors[runeColor]
			    return c.r, c.g, c.b, c.a
			end,					
		}
		colors.args.runes.args[runeColor.."_RechargeColor"] = {
	        order = i + 1,
			name = L["Recharge"],
			desc = L["Recharge"],
			type = "color",
			hasAlpha = true,
			set = function(info, r, g, b, a)
			    local c = self.db.profile.RuneCooldownColors[runeColor]
			    c.r, c.g, c.b, c.a = r, g, b, a
				self:UpdateRuneColors()
				self:UpdateRunes()
			end,
			get = function(info)
		        local c = self.db.profile.RuneCooldownColors[runeColor]
			    return c.r, c.g, c.b, c.a
			end,					
		}
		i = i + 5
	end
	return colors
end

function CompactRunes:OnInitialize()
    -- Load the settings
    self.db = _G.LibStub("AceDB-3.0"):New("CompactRunesDB", defaults, "Default")

	self:MigrateSettings()
	self:UpdateRuneColors()
	self:UpdatePriorityListSettings()
	self:UpdateCDBarOrderings()

	-- Register for profile callbacks
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChange")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChange")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChange")
	self.db.RegisterCallback(self, "OnProfileShutdown", "RemoveDefaults")
	self.db.RegisterCallback(self, "OnDatabaseShutdown", "RemoveDefaults")
	
	LSM:Register("statusbar", "Compact Runes", [[Interface\Addons\CompactRunes\CompactRunes]])
	LSM:Register("border", "Compact Runes", [[Interface\Addons\CompactRunes\CompactRunesBorder]])
	LSM:Register("border", "Compact Runes Bright", [[Interface\Addons\CompactRunes\CompactRunesBrightBorder]])

	Icon:Register("CompactRunesLDB", Broker.obj, self.db.profile.minimap)
	LSM.RegisterCallback(CompactRunes, "LibSharedMedia_Registered")
end

function CompactRunes:OnProfileChange()
	self:MigrateSettings()
	self:UpdateRuneColors()
	self:UpdatePriorityListSettings()
	self:UpdateCDBarOrderings()
	self:Reset()
end

function CompactRunes:Reset()
	--self:ResetFonts()
	--self:UpdateTextures()

	self:UpdateRuneColors()
	self:SetRuneBackground()

	for k, v in pairs(self.bars) do
		if v then
			v.db = self.db.profile.bars[v.name]
			v:Reset()
		end
	end

	self:SetRuneOrder(self.db.profile.runeOrder)

	local procInd = frames.procInd
	if procInd then
		procInd.ResetFonts()
		procInd:SetWidth(procInd:GetDesiredWidth())
		procInd:SetHeight(procInd:GetDesiredHeight())
		procInd:SetDesiredPoint()
	end

	self:SetMainFrameBorder()
	local main = frames.main
	if main then
		main:SetWidth(main.GetDesiredWidth())
		main:SetHeight(main.GetDesiredHeight())
	end
end

function CompactRunes:LibSharedMedia_Registered(event, mediatype, key)
	if _G.strlen(self.db.profile.font_face) > 1 and mediatype == "font" then
		if self.db.profile.font_face == key then
			self:ResetFonts()
		end
	end
	if mediatype == "statusbar" then
	    self:UpdateTextures()
	end
end

function CompactRunes:ResetFonts()
	for k, v in pairs(self.bars) do
		if v then
			v:ResetFonts()
		end
	end

	if frames.procInd then
		frames.procInd.ResetFonts()
	end
end

function CompactRunes:UpdateTextures()
	for k, v in pairs(self.bars) do
		if v then
			v:UpdateTexture()
		end
	end
end

local function splitWords(str)
  local w = {}
  local function helper(word) table.insert(w, word) return nil end
  str:gsub("(%w+)", helper)
  return w
end

local function GetNumericValue(...)
    for i = 1, _G.select("#", ...) do
        local region = _G.select(i, ...)
        if region and region:GetObjectType() == "FontString" then
            local regionText = region:GetText()
            if regionText then
                local valueText = regionText:match("[0-9,]+")
                if valueText then
					valueText = valueText:gsub(",","")
                    local value = tonumber(valueText)
                    if value then
                        return value
                    end
                end
            end
        end
    end
end

local TipFrame = nil
function CompactRunes:VerifyDiseaseDamage()
	if not TipFrame then
		TipFrame = _G.CreateFrame("GameTooltip", "CompactRunes_TipFrame", nil, "GameTooltipTemplate")
		TipFrame:SetOwner(_G.WorldFrame, "ANCHOR_NONE")
	end

	TipFrame:ClearLines()
	TipFrame:SetSpellByID(SpellIds["Frost Fever"])
	local baseFF = GetNumericValue(TipFrame:GetRegions())
	TipFrame:ClearLines()
	TipFrame:SetSpellByID(SpellIds["Blood Plague"])
	local baseBP = GetNumericValue(TipFrame:GetRegions())

	self:CalculateDiseaseDamage()
	self:Print("Tooltip vs Calculated Values:")
	local fmt = "%s: Tooltip = %d,  Calculated = %d [Effective = %d]"
	self:Print(fmt:format("Frost Fever", baseFF, 
		round(self.base.ff), round(self.eff.ff)))
	self:Print(fmt:format("Blood Plague", baseBP, 
		round(self.base.bp), round(self.eff.bp)))
end

function CompactRunes:ChatCommand(input)
    if not input or input:trim() == "" then
        self:ShowOptions()
    else
		local cmds = splitWords(input)
        if cmds[1] and cmds[1] == "debug" then
			if cmds[2] and cmds[2] == "on" then
				self.db.profile.debug = true
	            self:Print("Debugging on.  Use '/crunes debug off' to disable.")
		    elseif cmds[2] and cmds[2] == "off" then
				self.db.profile.debug = false
	            self:Print("Debugging off.")
			else
				self:Print("Debugging is "..(self.db.profile.debug and "on." or "off."))
			end
		elseif cmds[1] and cmds[1] == "srMethod" then
			if cmds[2] and cmds[2] == "cooldown" then
				self.srMethod = "cooldown"
		    elseif cmds[2] and cmds[2] == "target" then
				self.srMethod = "target"
			end
			self:Print("Soul Reaper detected via " ..
				tostring(self.srMethod))
        elseif cmds[1] and cmds[1] == "debugBP" then
			if cmds[2] and cmds[2] == "on" then
				self.db.profile.debugBP = true
	            self:Print("Debugging BP on.")
		    elseif cmds[2] and cmds[2] == "off" then
				self.db.profile.debugBP = false
	            self:Print("Debugging BP off.")
			else
				self:Print("Debugging BP is "..(self.db.profile.debugBP and "on." or "off."))
			end
		elseif cmds[1] and cmds[1] == "verify" then
			self:VerifyDiseaseDamage()
		end
	end
end

function CompactRunes:OnEnable()
    self:CheckTalents()
	self:SetRuneBackground()
	self:ToggleDiseaseTracking()
	self:Load()
	self:CheckGear()
	LoadSpellNames()
	LoadItemNames()
	
	self:HideBlizzardFrames()

	if not self.optionsFrame then
		-- Register Options
	    local displayName = _G.GetAddOnMetadata(ADDON_NAME, "Title")
		self:GetOptions()
	    _G.LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable(displayName, options)

	    self.optionsFrame = {}
	    local ACD = _G.LibStub("AceConfigDialog-3.0")
		self.optionsFrame.Main = ACD:AddToBlizOptions(
		    displayName, displayName, nil, "core")
		self.optionsFrame.Layout = ACD:AddToBlizOptions(
		    displayName, L["Layout"], displayName, "layout")
		self.optionsFrame.Colors = ACD:AddToBlizOptions(
		    displayName, L["Colors"], displayName, "colors")
		self.optionsFrame.Procs = ACD:AddToBlizOptions(
		    displayName, L["Procs"], displayName, "procs")
		self.optionsFrame.Strength = ACD:AddToBlizOptions(
		    displayName, L["Disease Strength"], displayName, "strength")
		self.optionsFrame.CDBars = ACD:AddToBlizOptions(
		    displayName, L["Cooldown Bars"], displayName, "cooldowns")
		ACD:AddToBlizOptions(
		    displayName, options.args.profile.name, displayName, "profile")
	    -- Register the chat command
	    self:RegisterChatCommand("crunes", "ChatCommand")
	end
end

function CompactRunes:HideBlizzardFrames()
	if not self.db.profile.hideBlizzardFrames then return end
	-- Securely and safely hide and then hook the OnShow to hide itself.
	-- It should last until the UI is reloaded.
	local RuneFrame = _G.RuneFrame
	if RuneFrame and RuneFrame.Hide and _G.type(RuneFrame.Hide) == "function" then
		RuneFrame:Hide()
		if RuneFrame.HookScript and _G.type(RuneFrame.HookScript) == "function" then
			RuneFrame:HookScript("OnShow", function(self) self:Hide() end)
		end
	end
end

local WatchedEvents = {
	"RUNE_POWER_UPDATE",
	"RUNE_TYPE_UPDATE",
	"PLAYER_REGEN_DISABLED",
	"PLAYER_REGEN_ENABLED",
	"PLAYER_TARGET_CHANGED",
	"PLAYER_TALENT_UPDATE",
	"PLAYER_SPECIALIZATION_CHANGED",
	"COMBAT_LOG_EVENT_UNFILTERED",
	"PLAYER_ENTERING_WORLD",
	"UNIT_LEVEL",
	"SPELL_UPDATE_COOLDOWN",
	"PLAYER_EQUIPMENT_CHANGED",
}

local UnitEvents = {
	["player"] = {
		"UNIT_POWER_FREQUENT", 
		"UNIT_MAXPOWER",
		"UNIT_AURA",
	},
	["target"] = {
		"UNIT_HEALTH",
		"UNIT_AURA",
	},
	["pet"] = {
		--"UNIT_PET",
		"UNIT_AURA",
	},
}
local function EventFrame_OnEvent(frame, event, ...)
	if event == "UNIT_ATTACK_POWER" then
		CompactRunes:UNIT_ATTACK_POWER(event, ...)
	elseif event == "UNIT_STATS" then
		CompactRunes:UNIT_STATS(event, ...)
	elseif event == "UNIT_POWER_FREQUENT" then
		CompactRunes:UNIT_POWER_FREQUENT(event, ...)
	elseif event == "UNIT_MAXPOWER" then
		CompactRunes:UNIT_MAXPOWER(event, ...)
	elseif event == "UNIT_HEALTH" then
		CompactRunes:UNIT_HEALTH(event, ...)
	elseif event == "UNIT_AURA" then
		CompactRunes:UNIT_AURA(event, ...)
	--elseif event == "UNIT_PET" then
	--	CompactRunes:UNIT_PET(event, ...)
	end
end
local EventFrames = {}
for unit, events in pairs(UnitEvents) do
	local frame = _G.CreateFrame("Frame", ADDON_NAME.."_EventFrame_"..unit)
	frame:SetScript("OnEvent", EventFrame_OnEvent)
	EventFrames[unit] = frame
end

function CompactRunes:Load()
	if self.isDK then
		self:CreateDisplay()
		for i = 1, #WatchedEvents do
			self:RegisterEvent(WatchedEvents[i])
		end
		for unit, events in pairs(UnitEvents) do
			local eventFrame = EventFrames[unit]
			if eventFrame then
				for i, event in ipairs(events) do
					eventFrame:RegisterUnitEvent(event, unit)
				end
			else
				self:Print("Missing event frame for "..tostring(unit).."!")
			end
		end
	end
end

function CompactRunes:Unload()
end

function CompactRunes:OnDisable()
	for i = 1, #WatchedEvents do
		self:UnregisterEvent(WatchedEvents[i])
	end
	for unit, events in pairs(UnitEvents) do
		local eventFrame = EventFrames[unit]
		if eventFrame then
			for i, event in ipairs(events) do
				eventFrame:UnregisterEvent(event, unit)
			end
		end
	end
end

local DiseaseStrengthEvents = {
	"PLAYER_DAMAGE_DONE_MODS",
	"COMBAT_RATING_UPDATE",
}
local DiseaseStrengthUnitEvents = {
	["player"] = {"UNIT_ATTACK_POWER", "UNIT_STATS"},
}

function CompactRunes:ToggleDiseaseTracking()
	if self.db.profile.trackDiseases then
		for i = 1, #DiseaseStrengthEvents do
			self:RegisterEvent(DiseaseStrengthEvents[i])
		end
		for unit, events in pairs(DiseaseStrengthUnitEvents) do
			local eventFrame = EventFrames[unit]
			if not eventFrame then
				self:Print("Missing event frame for "..tostring(unit).."!")
			else
				for i, event in ipairs(events) do
					eventFrame:RegisterUnitEvent(event, unit)
				end
			end
		end
		self:UpdateAllStats()
	else
		for i = 1, #DiseaseStrengthEvents do
			self:UnregisterEvent(DiseaseStrengthEvents[i])
		end
		for unit, events in pairs(DiseaseStrengthUnitEvents) do
			local eventFrame = EventFrames[unit]
			for i, event in ipairs(events) do
				if eventFrame then
					eventFrame:UnregisterEvent(event, unit)
				end
			end
		end
	end
end

function CompactRunes:UpdateCDBars()
	if self.isDK and self.currentSpec and self.currentSpec ~= "" then
		local enabled = self.db.profile.cdbars[self.currentSpec].enabled
		local bar = self.cdbars[self.currentSpec]
		if enabled and not bar then
			bar = self.CooldownBar:Create(self.currentSpec)
			self.cdbars[self.currentSpec] = bar
		end
		for k, v in pairs(self.cdbars) do
			if k == self.currentSpec and enabled then
				v:Enable()
			elseif v and v.Disable then
				v:Disable()
			end
		end
	end
end

function CompactRunes:CheckTalents()
    local class, className = _G.UnitClass("player")
    if className then
        if (className == 'DEATH KNIGHT' or className == 'DEATHKNIGHT') then
            self.isDK = true

			local activeSpecNum = _G.GetSpecialization()
			if activeSpecNum and activeSpecNum > 0 then
				local id, name, desc, texture = _G.GetSpecializationInfo(activeSpecNum)
		    	if texture == "Interface\\Icons\\Spell_Deathknight_BloodPresence" then
					self.currentSpec = "Blood"
				elseif texture == "Interface\\Icons\\Spell_Deathknight_FrostPresence" then
					self.currentSpec = "Frost"
				elseif texture == "Interface\\Icons\\Spell_Deathknight_UnholyPresence" then
					self.currentSpec = "Unholy"
				else
					self:Print("Error detecing player spec.")
					self.currentSpec = "Blood"
				end
			end
			
			if self.currentSpec ~= "Blood" and frames.boneBar then
				frames.boneBar.bar:Hide()
				frames.boneBar.bar.active = false
				frames.boneBar.bar:SetScript("OnUpdate", nil)
				frames.boneBar.bar.state = nil
			end

			local soulReaperId = self.soulReaperIds[self.currentSpec]
			self.soulReaperKnown = soulReaperId and 
				_G.IsSpellKnown(soulReaperId) or false

			local regenFound = false
			local plFound = false
			for i = 1, 18 do
				local name, iconTexture, tier, column, selected, available = 
					_G.GetTalentInfo(i, "player")
				if name and selected and available then
					if name == SpellNames["Blood Tap"] then
						self.regenMethod = "BT"
						regenFound = true
					elseif name == SpellNames["Runic Empowerment"] then
						self.regenMethod = "RE"
						regenFound = true
					elseif name == SpellNames["Runic Corruption"] then
						self.regenMethod = "RC"
						regenFound = true
					elseif name == SpellNames["Plague Leech"] then
						plFound = true
					end
				end
			end

			if not regenFound then
				self.regenMethod = "None"
			end
			if plFound then
				self.plagueLeech = true
			else
				self.plagueLeech = false
			end
        else
            self.isDK = false
			self.regenMethod = "None"
        end
    end

	self:CheckSpells()
	self:UpdateDTBCBars()
	self:UpdateCDBars()

	if self.db.profile.debug then
		local fmt = "CheckTalents [isDK=%s,spec=%s,regen=%s,SR=%s]"
		self:Print(
			fmt:format(tostring(self.isDK),
				self.currentSpec, self.regenMethod, 
				tostring(self.soulReaperKnown)))
	end
end

function CompactRunes:CheckSpells()
	self.enabled.BoneShieldBar = self.db.profile.bars.BoneShieldBar.enabled and 
			self.currentSpec == "Blood" and _G.IsSpellKnown(SpellIds["Bone Shield"])
end

local function onUpdateRune(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.showing.timer = self.showing.timer + elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		self.lastUpdate = 0
		local profile = CompactRunes.db.profile
		self:SetValue(self.showing.timer)

		local remain = abs(self.showing.duration - self.showing.timer)
		local almostReadyTime = profile.almostReadyTime
		if almostReadyTime > 0 and almostReadyTime >= remain then
			self:SetAlpha(profile.almostReadyAlpha)
		end
		if profile.runeRechargeNums then
			if self.showing.start > 0 then
				self.value:SetText(tostring(round(remain)))
			else
				self.value:SetText("")
			end
		end
	end
end

local function onUpdateDisease(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.timer = self.timer - elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		self.lastUpdate = 0
		if self.active then
			if self.timer < 0 then
				self.timer = 0
				self.active = false
				if self.parent.name == "BloodPlagueBar" and
					CompactRunes.currentProcs["Plague Leech"] ~= nil then
					CompactRunes.currentProcs["Plague Leech"] = nil
					CompactRunes:UpdateProcIcon()
				end
			end
		
			self:Show()
			self:SetValue(self.timer)
			self.value:SetText(tostring(round(self.timer)))
			local db = CompactRunes.db.profile
			if self.parent.name == "BloodPlagueBar" then
				if self.timer <= db.plRefresh then
					if CompactRunes.currentProcs["Plague Leech"] == nil then
						local showPL = true
						if db.plOutbreak then
							local start, duration, enabled = 
								_G.GetSpellCooldown(SpellIds["Outbreak"])
							if duration > 0 then
								local timeLeft = duration - (_G.GetTime() - start)
								if timeLeft - self.timer >= 1 then
									showPL = false
								end
							end 
						end
						if showPL then
							CompactRunes.currentProcs["Plague Leech"] = 1
							CompactRunes:UpdateProcIcon()
						end
					end
				end
			end
		else
			self.value:SetText("0")
			self:Hide()
			self:SetScript("OnUpdate", nil)
			if self.parent.name == "BloodPlagueBar" and 
				CompactRunes.currentProcs["Plague Leech"] ~= nil then
				CompactRunes.currentProcs["Plague Leech"] = nil
				CompactRunes:UpdateProcIcon()
			end
		end
	end
end

local function onUpdateDarkTrans(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.timer = self.timer - elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		self.lastUpdate = 0
		if self.active then
			if self.timer < 0 then
				self.timer = 0
				self.active = false
				self:SetScript("OnUpdate", nil)
				self:Hide()
			else
				self:Show()
				self:SetValue(self.timer)
				if self.dt then
					self.value:SetText(tostring(round(self.timer)))
				end
			end
		else
			self:Hide()
		end
	end
end

local function onUpdateBloodCharge(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.timer = self.timer - elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		self.lastUpdate = 0
		if self.active then
			if self.timer < 0 then
				self.timer = 0
				self.active = false
				self:SetScript("OnUpdate", nil)
				self:Hide()
			else
				self:Show()
				self:SetValue(self.timer)
			end
		else
			self:Hide()
		end
	end
end

local function onUpdateBoneShield(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.timer = self.timer - elapsed
	self.recharge = self.recharge - elapsed
	if self.lastUpdate >= 0.1 then
		if self.active then
			local profile = CompactRunes.db.profile.bars["BoneShieldBar"]
			if self.timer > 0 then
				self:Show()
				if profile.progress == "Time" then
					self:SetValue(self.timer)
				elseif profile.progress == "Charges" then
					self:SetValue(self.count)
				end
			else
				self.timer = 0
				self.active = false
				self:SetScript("OnUpdate", nil)
				self:Hide()
			end
		elseif self.recharging then
			if self.recharge >= 0 then
				local remaining = 0
				if self.recharge > 60 then
					remaining = tostring(ceil(self.recharge / 60)) .. "m"
				else
					remaining = tostring(round(self.recharge))
				end
				self.rechargeTime:SetText(remaining)
			else
				self.recharging = false
				self.recharge = 0
				self.value:SetText("-")
				self:SetScript("OnUpdate", nil)	
			end
		else
			self:Hide()
		end
		self.lastUpdate = 0
	end
end

local function onUpdateInd(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		local outOfRange = false
		if _G.UnitExists("target") and not _G.UnitIsDead("target") and
			_G.UnitCanAttack("player", "target") then
			if _G.IsSpellInRange(SpellNames["Plague Strike"], "target") == 0 then
				outOfRange = true
			end
		end

		if outOfRange ~= self.outOfRange then
			self.outOfRange = outOfRange
			self:UpdateInd()
		end

		self.lastUpdate = 0
	end
end

local fontFlags = {}
function CompactRunes:GetFontSettings()
	wipe(fontFlags)
	for k, v in pairs(self.db.profile.fontFlags) do
		if v then tinsert(fontFlags, k) end
	end
	return self.db.profile.font_face, self.db.profile.font_size, tconcat(fontFlags, ",")
end

-- Define a generic class for the bars
Bar.__index = Bar

function Bar:Create(name, fontAdj, width, height, setPoint, setValuePoint)
    local object = _G.setmetatable({}, Bar)
	object.name = name
	object.fontAdj = fontAdj
	
	local widthFunc = width
	if _G.type(width) ~= "function" then
		widthFunc = function() return width end
	end
	object.GetWidth = widthFunc
	local heightFunc = width
	if _G.type(height) ~= "function" then
		heightFunc = function() return height end
	end
	object.GetHeight = height

	object.SetPoint = setPoint
	object.SetDesiredPoint = setPoint
	object.SetValuePoint = setValuePoint
	object:Initialize()
	-- Add the bar to the addon's table of bars
	CompactRunes.bars[name] = object
	return object
end

function Bar:Initialize()
    local bar = _G.CreateFrame("StatusBar", "CompactRunes_"  .. self.name, frames.main)
	self.bar = bar
	bar.parent = self
	self.db = CompactRunes.db.profile.bars[self.name]
	self.altcolor = false
	self.isRuneBar = self.name:find("RuneBar%d")
	bar:SetScale(1)
	if self.name == "BoneShieldBar" then
    	bar:SetOrientation("VERTICAL")
	else
    	bar:SetOrientation("HORIZONTAL")
	end
    bar:SetWidth(self.GetWidth())
    bar:SetHeight(self.GetHeight())
	local bt = LSM:Fetch("statusbar", CompactRunes.db.profile.texture)
    bar:SetStatusBarTexture(bt)
    bar:GetStatusBarTexture():SetHorizTile(false)
    bar:GetStatusBarTexture():SetVertTile(false)
	if not self.isRuneBar then
    	local bc = self.db.color
    	bar:SetStatusBarColor(bc.r, bc.g, bc.b, bc.a)
	end
    bar.bg = bar:CreateTexture(nil, "BACKGROUND")
    bar.bg:SetTexture(bt)
    bar.bg:SetAllPoints(true)
	if not self.isRuneBar then
		local bgc = self.db.bgcolor
    	bar.bg:SetVertexColor(bgc.r, bgc.g, bgc.b, bgc.a)
	end

	local ff, fh, fflags = CompactRunes:GetFontSettings()
	local font = LSM:Fetch("font", ff)
    bar.value = bar:CreateFontString(nil, "OVERLAY")
    bar.value:SetPoint("CENTER")
    bar.value:SetFont(font, fh + self.fontAdj, fflags)
    bar.value:SetJustifyH("CENTER")
    --bar.value:SetShadowOffset(1, -1)
   	local tc = self.db.textcolor
   	bar.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
	if self.isRuneBar and not CompactRunes.db.profile.runeRechargeNums then
		bar.value:Hide()
	end
	if self.name == "BloodShieldBar" then
		bar.value:SetText("0")
	end

	if self.name == "BoneShieldBar" then
	    bar.rechargeTime = bar:CreateFontString(nil, "OVERLAY")
	    bar.rechargeTime:SetPoint("CENTER")
	    bar.rechargeTime:SetFont(font, fh + self.fontAdj - 1, fflags)
	    bar.rechargeTime:SetJustifyH("CENTER")
	   	local tc = self.db.rechargeTextColor
	   	bar.rechargeTime:SetTextColor(tc.r, tc.g, tc.b, tc.a)
		bar.rechargeTime:SetText("0")
		bar.rechargeTime:Hide()
	end

	if self.SetPoint then self:SetPoint() end
	if self.SetValuePoint then
		self:SetValuePoint()
	else
	    bar.value:SetPoint("CENTER")
	end

	if self.name == "FrostFeverBar" or 
		self.name == "BloodPlagueBar" or 
		self.name == "DarkTransformationBar" or
		self.name == "BloodChargeBar" or
		self.name == "BloodShieldBar" or
		self.name == "BoneShieldBar" then
		bar.active = false
		bar.timer = 0
		bar:Hide()
	end

	if self.name == "BoneShieldBar" then
		self.bar.recharge = 0
	end

	bar.locked = true
end

function Bar:IsLocked()
	return self.bar.locked
end

function Bar:Lock(locked)
	if locked ~= nil then
		self.bar.locked = locked
	end
	self.bar:EnableMouse(not self.bar.locked)
	if self.name == "BloodShieldBar" then
		if not self.bar.locked then
			self.bar:Show()
		elseif not self.bar.active then
			self.bar:Hide()
		end
	end
end

function Bar:SetMovable()
	local bar = self.bar
    bar:SetMovable()
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart",
        function(self, button)
			if not self.locked then
            	self:StartMoving()
			end
        end)
    bar:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.parent.db.x, self.parent.db.y = x, y
			self:SetUserPlaced(false);
        end)
	self:Lock()
end

local numberFmt = "%.0f"
function Bar:SetValue(value)
	self.bar:SetValue(value)
	self.bar.value:SetText(numberFmt:format(value))
end

function Bar:SetValueTextColor(color)
   	local tc = color or self.db.textcolor
   	self.bar.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
end

function Bar:Reset()
	self:ResetFonts()
	self:UpdateVisibility()
	--self:UpdateTexture()
	self:UpdateGraphics()
end

function Bar:ResetFonts()
	local ff, fh, fontFlags = CompactRunes:GetFontSettings()
	local font = LSM:Fetch("font", ff)
	self.bar.value:SetFont(font, fh + self.fontAdj, fontFlags)
	self.bar.value:SetText(self.bar.value:GetText())
	if self.name == "BoneShieldBar" then
		self.bar.rechargeTime:SetFont(font, fh + self.fontAdj - 1, fontFlags)
		self.bar.rechargeTime:SetText(self.bar.rechargeTime:GetText())
	end
end

function Bar:UpdateVisibility()
	if self.GetWidth then self.bar:SetWidth(self:GetWidth()) end
	if self.GetHeight then self.bar:SetHeight(self:GetHeight())	end
	if self.SetPoint and not self.isRuneBar then self:SetPoint() end
	if self.SetValuePoint then
		self:SetValuePoint()
	else
	    self.bar.value:SetPoint("CENTER")
	end
	if self.name == "BoneShieldBar" then
		if not (self.currentSpec == "Blood" or self.db.enabled) then
			self.bar:Hide()
			self.bar:SetScript("OnUpdate", nil)
		end
	else
		if not self.db.enabled then
			self.bar:Hide()
			self.bar:SetScript("OnUpdate", nil)
		end
	end

	self:UpdateTexture()
end

function Bar:UpdateTexture()
    local bt = LSM:Fetch("statusbar", CompactRunes.db.profile.texture)
	self.bar:SetStatusBarTexture(bt)
	self.bar.bg:SetTexture(bt)
    self.bar:GetStatusBarTexture():SetHorizTile(false)
    self.bar:GetStatusBarTexture():SetVertTile(false)
	--self:UpdateGraphics()
end

function Bar:UpdateGraphics()
	if not self.isRuneBar then
	    local bc, bgc, tc
		if self.altcolor then
		    bc = self.db.alt_color or self.db.color
		    bgc = self.db.alt_bgcolor or self.db.bgcolor
		    tc = self.db.alt_textcolor or self.db.textcolor
		else
		    bc = self.db.color
		    bgc = self.db.bgcolor
		    tc = self.db.textcolor
		end

	    self.bar:SetStatusBarColor(bc.r, bc.g, bc.b, bc.a)
	    self.bar.bg:SetVertexColor(bgc.r, bgc.g, bgc.b, bgc.a)
	    self.bar.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
		if self.name == "BoneShieldBar" then
			local tc = self.db.rechargeTextColor
		    self.bar.rechargeTime:SetTextColor(tc.r, tc.g, tc.b, tc.a)
		end
	end
end

local runes = {
	[1] = {
		partner = 2,
		timer = 0,
		duration = 10,
		start = 0,
		type = 1,
		ready = true,
	},
	[2] = {
		partner = 1,
		timer = 0,
		duration = 10,
		start = 0,
		type = 1,
		ready = true,
	},
	[3] = {
		partner = 4,
		timer = 0,
		duration = 10,
		start = 0,
		type = 1,
		ready = true,
	},
	[4] = {
		partner = 3,
		timer = 0,
		duration = 10,
		start = 0,
		type = 1,
		ready = true,
	},
	[5] = {
		partner = 6,
		timer = 0,
		duration = 10,
		start = 0,
		type = 1,
		ready = true,
	},
	[6] = {
		partner = 5,
		timer = 0,
		duration = 10,
		start = 0,
		type = 1,
		ready = true,
	},
}
local runeBars = {}
local orderings = {
	["BUF"] = { 1, 2, 3, 4, 5, 6 },
	["BFU"] = { 1, 2, 5, 6, 3, 4 },
	["UFB"] = { 3, 4, 5, 6, 1, 2 },
	["UBF"] = { 3, 4, 1, 2, 5, 6 },
	["FBU"] = { 5, 6, 1, 2, 3, 4 },
	["FUB"] = { 5, 6, 3, 4, 1, 2 },
}
function CompactRunes:SetRuneOrder(ordering)
	for i = 1, 6 do
		local barNum = orderings[ordering][i]
		local runeBar = runeBars[barNum]
		if runeBar then
			local bar = runeBar.bar
			bar:ClearAllPoints()
		    bar:SetPoint("TOPLEFT", frames.main, "TOPLEFT", 
				1 + self.db.profile.runes.inset + (self.db.profile.width + self.db.profile.spacing) * ((i - 1) % 2), 
				- 1 - self.db.profile.runes.inset - (self.db.profile.height + self.db.profile.spacing) * (ceil(i / 2) - 1))
		end
	end
end

function CompactRunes:ShowRechargeNumbers(enabled)
	for k, v in pairs(self.bars) do
		if v and v.isRuneBar and v.bar and v.bar.value then
			if enabled then
				v.bar.value:Show()
			else
				v.bar.value:Hide()
			end
		end
	end

	for i = 1, 6 do
		local runeBar = runeBars[i]
		if runeBar then
			local bar = runeBar.bar
			bar.value:Show()
		end
	end
end

function CompactRunes:CheckSoulReaper()
	if self.soulReaperKnown and 
		self.db.profile.enabled[self.currentSpec]["Soul Reaper"] then
		local health = _G.UnitHealth("target") or 0
		local percent = self.targetMaxHealth > 0 and 
			health / self.targetMaxHealth or 0

		local srActive = false
		if self.srMethod == "cooldown" then
			local start, duration, enabled = 
				_G.GetSpellCooldown(self.soulReaperIds[self.currentSpec])
			if duration > 0 then
				local timeLeft = duration - (_G.GetTime() - start)
				if timeLeft >= 1 then
					srActive = true
				end
			end 
		else
			srActive = self.targetSoulReaper
		end

		local old = self.currentProcs["Soul Reaper"]
		if self.targetHostile and percent < self.soulReaperPerc and not srActive then
			self.currentProcs["Soul Reaper"] = 1
		else
			self.currentProcs["Soul Reaper"] = nil
		end
		if old ~= self.currentProcs["Soul Reaper"] then
			self:UpdateProcIcon()
		end
	end
end

function CompactRunes:UpdateRuneType(runeIndex)
	local partnerIndex = runes[runeIndex].partner
	local bar = runeBars[runeIndex]
	local type = _G.GetRuneType(runeIndex)
	runes[runeIndex].type = type

	local time = _G.GetTime()
	local firstIndex = min(runeIndex, partnerIndex)
	local secondIndex = max(runeIndex, partnerIndex)
	local first = runeBars[firstIndex]
	local second = runeBars[secondIndex]
	local sooner, later = runes[firstIndex], runes[secondIndex]
	if time - sooner.start < time - later.start then
		sooner, later = runes[secondIndex], runes[firstIndex]
	end

	local rc, rcc
	-- Update first
	rc = RuneColors[RuneMapping[sooner.type]]
	if self.db.profile.runeBackground == 1 then
		rcc = RuneCooldownColors[RuneMapping[sooner.type]]
		rcc.a = self.db.profile.runeBackgroundAlpha or rcc.a
	else
		rcc = self.altRuneBkg
	end
    first.bar:SetStatusBarColor(rc.r, rc.g, rc.b, 1)
	first.bar.bg:SetVertexColor(rcc.r, rcc.g, rcc.b, rcc.a)
	first.bar.showing = sooner
	-- Update second
	rc = RuneColors[RuneMapping[later.type]]
	if self.db.profile.runeBackground == 1 then
		rcc = RuneCooldownColors[RuneMapping[later.type]]
		rcc.a = self.db.profile.runeBackgroundAlpha or rcc.a
	else
		rcc = self.altRuneBkg
	end
    second.bar:SetStatusBarColor(rc.r, rc.g, rc.b, 1)
	second.bar.bg:SetVertexColor(rcc.r, rcc.g, rcc.b, rcc.a)
	second.bar.showing = later
end

function CompactRunes:UpdateRuneCooldown(runeIndex, isEnergized)
	local partnerIndex = runes[runeIndex].partner
	local start, duration, ready = _G.GetRuneCooldown(runeIndex)
	local type = _G.GetRuneType(runeIndex)
	local rune = runes[runeIndex]
	local bar = runeBars[runeIndex]
	rune.ready = ready

	if rune.ready and self.regenMethod == "RE" then
		local timeLeft = rune.timer - rune.duration
		if timeLeft > 0.5 then
			self.TotalStats.reProcs[type] = (self.TotalStats.reProcs[type] or 0) + 1
			self.LastFightStats.reProcs[type] = (self.LastFightStats.reProcs[type] or 0) + 1
			if self.db.profile.debug then
				self:Print("RE Proc - " .. (RuneMapping[type] or "Unknown"))
			end
		end
		--local refFmt = "Rune %d: %0.2f [%0.2f, %0.2f]"
		--self:Print(refFmt:format(runeIndex, timeLeft, 
		--	rune.duration, rune.timer))
	end

	rune.start = start
	if ready == false then
		rune.duration = duration
		rune.timer = _G.GetTime() - start
	else
		rune.timer = 10
		rune.duration = 10
	end

	local time = _G.GetTime()
	local firstIndex = min(runeIndex, partnerIndex)
	local secondIndex = max(runeIndex, partnerIndex)
	local first = runeBars[firstIndex]
	local second = runeBars[secondIndex]
	local sooner, later = runes[firstIndex], runes[secondIndex]
	if time - sooner.start < time - later.start then
		sooner, later = runes[secondIndex], runes[firstIndex]
	end

	-- Update first
	first.bar.showing = sooner
	first.bar:SetMinMaxValues(0, sooner.duration)
	first.bar:SetValue(sooner.timer)
	if sooner.ready == false then
		first.bar:SetScript("OnUpdate", onUpdateRune)
		first.bar:SetAlpha(self.db.profile.rechargeAlpha)
	else
		first.bar:SetScript("OnUpdate", nil)
		first.bar:SetAlpha(1.0)
		if CompactRunes.db.profile.runeRechargeNums then
			first.bar.value:SetText("")
		end
	end
	-- Update second
	second.bar.showing = later
	second.bar:SetMinMaxValues(0, later.duration)
	second.bar:SetValue(later.timer)
	if later.ready == false then
		second.bar:SetScript("OnUpdate", onUpdateRune)
		second.bar:SetAlpha(self.db.profile.rechargeAlpha)
	else
		second.bar:SetScript("OnUpdate", nil)
		second.bar:SetAlpha(1.0)
		if CompactRunes.db.profile.runeRechargeNums then
			second.bar.value:SetText("")
		end
	end

	--self:CheckSoulReaper()
end

function CompactRunes:UpdateRunes()
	for i = 1, 6 do
		self:UpdateRuneType(i)
		self:UpdateRuneCooldown(i)
	end	
end

function CompactRunes:CreateProcIndicator()
    local bar = _G.CreateFrame("Frame", "CompactRunes_Proc", frames.main)
	bar.db = self.db.profile
	frames.procInd = bar
	bar.currentProc = nil
	bar.procList = nil
	bar.SetDesiredPoint = function(bar)
		bar:ClearAllPoints()
		local profile = CompactRunes.db.profile
		local x, y = profile.procIcon.x, profile.procIcon.y
		if profile.procIcon.userPlaced and x ~= nil and y ~= nil then
	    	bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
		else
	    	bar:SetPoint("BOTTOM", frames.main, "TOP", 0, 
				profile.spacing * 7 + profile.height + 2)
		end
	end
	bar:SetDesiredPoint()
	bar:SetScale(1)
	bar.GetDesiredHeight = function()
		local scale = self.db.profile.procIcon.scale
		return ceil(scale*(frames.main:GetWidth()*frames.main:GetHeight()*0.233)^0.5)
	end
	bar.GetDesiredWidth = function()
		local scale = self.db.profile.procIcon.scale
		return ceil(scale*(frames.main:GetWidth()*frames.main:GetHeight()*0.233)^0.5)
	end
	bar.SetDimensions = function(bar)
	    bar:SetWidth(bar:GetDesiredHeight())
	    bar:SetHeight(bar:GetDesiredWidth())
	end
	bar:SetDimensions()
	bar.texture = bar:CreateTexture(nil, "ARTWORK")
    bar.texture:SetAllPoints(bar)
    bar.texture:SetVertexColor(1, 1, 1)
	local ff, fh, fflags = self:GetFontSettings()
	local font = LSM:Fetch("font", ff)
    bar.value = bar:CreateFontString(nil, "OVERLAY")
    bar.value:SetPoint("BOTTOMRIGHT", bar, "BOTTOMRIGHT", 0, -2)
    bar.value:SetFont(font, fh + 3, fflags)
    bar.value:SetJustifyH("CENTER")
	bar.value:SetJustifyV("CENTER")
    bar.value:SetShadowOffset(1, -1)
    local tc = bar.db.bars.ProcInd.textcolor
    bar.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
	bar.value:Hide()
	
	bar.ResetFonts = function()
		local ff, fh, fontFlags = self:GetFontSettings()
		local font = LSM:Fetch("font", ff)
		bar.value:SetFont(font, fh + 3, fontFlags)						
		bar.value:SetText(bar.value:GetText())
	end

	bar.locked = true
	bar.Lock = function(self, locked)
		if locked ~= nil then
			self.locked = locked
		end
		self:EnableMouse(not self.locked)
		self:Configure(not self.locked)
	end
	bar.IsLocked = function(self)
		return self.locked
	end

	bar.configMode = false
	bar.Configure = function(self, config)
		if config ~= nil then
			self.configMode = config
		else
			self.configMode = not self.configMode
		end
		if self.configMode then
			self.texture:SetTexture(SpellIcons["Auto Attack"])
			self:Show()
		else
			CompactRunes:UpdateProcIcon()
		end
	end

    bar:SetMovable()
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart",
        function(self, button)
			if not self.locked then
            	self:StartMoving()
			end
        end)
    bar:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			local procIcon = CompactRunes.db.profile.procIcon
			procIcon.x, procIcon.y = x, y
			procIcon.userPlaced = true
			self:SetUserPlaced(false)
        end)
	bar:Lock()
end

function CompactRunes:UpdateProcIcon()
	local procInd = frames.procInd
	local found = false

	if self.db.profile.procs then
		local procPriority = self.db.profile.priorityList[self.currentSpec]
		local enabled = self.db.profile.enabled[self.currentSpec]
		if procPriority and enabled then
			for i, spell in ipairs(procPriority) do
				local count = self.currentProcs[spell]
				local isPL = spell == "Plague Leech"
				if enabled[spell] and count and 
					(not isPL or (isPL and self.plagueLeech)) then
					found = true
					procInd.texture:SetTexture(SpellIcons[spell])
					procInd:Show()
					if count > 1 then
						procInd.value:SetText(tostring(count))
						procInd.value:Show()
					else
						procInd.value:Hide()
					end

					break
				end
			end
		end
	end

	if not found then
		procInd:Hide()
	end
end

function CompactRunes:SetMainFrameBorder()
	local frame = frames.main
	if frame then
		local border = LSM:Fetch("border", self.db.profile.border)
		local backdrop = {
	        bgFile = "Interface\\Buttons\\WHITE8X8", 
	        edgeFile = border, tile = false, tileSize = 16, edgeSize = 16, 
	        insets = { left = 4, right = 4, top = 4, bottom = 4 }
	    }
		local bdbc = self.db.profile.frame.bdcolor
		local bdc = self.db.profile.frame.color
	    frame:SetBackdrop(backdrop)
	    frame:SetBackdropBorderColor(bdbc.r, bdbc.g, bdbc.b, bdbc.a)
	    frame:SetBackdropColor(bdc.r, bdc.g, bdc.b, bdc.a)

		border = LSM:Fetch("border", "Compact Runes Bright")
		backdrop = {
	        bgFile = "Interface\\Buttons\\WHITE8X8", 
	        edgeFile = border, tile = false, tileSize = 16, edgeSize = 16, 
	        insets = { left = 4, right = 4, top = 4, bottom = 4 }
	    }
		local rc = self.db.profile.frame.rccolor
	    frame.ind:SetBackdrop(backdrop)
	    frame.ind:SetBackdropBorderColor(rc.r, rc.g, rc.b, rc.a)
	    frame.ind:SetBackdropColor(0, 0, 0, 0)
	end
end

function CompactRunes:IsBothDTBCBars()
	return self.currentSpec == "Unholy" and 
			self.regenMethod == "BT" and
			self.db.profile.bars.BloodChargeBar.enabled and
			self.db.profile.bars.DarkTransformationBar.enabled
end

function CompactRunes:UpdateDTBCBars()
	if self.isDK then
		local bars = {
			"DarkTransformationBar",
			"BloodChargeBar"
		}
		for k, v in pairs(bars) do
			if v and self.bars[v] then
				local bar = self.bars[v]
				bar:SetPoint()
				if not bar.db.enabled then
					bar.bar.active = false 
					bar.bar.timer = 0
					bar.bar:SetScript("OnUpdate", nil)
					bar.bar:Hide()
				end
			end
		end
	end
end

function CompactRunes:CalculateSize()
	self.sizes = self.sizes or {}
	self.sizes.Display = self.sizes.Display or {}
	self.sizes.Display.width = (self.db.profile.width + self.db.profile.spacing) * 2 + 9
	self.sizes.Display.height = (self.db.profile.height + self.db.profile.spacing) * 3 + 9
	self.sizes.hinset = 0
	self.sizes.vinset = 0
end

function CompactRunes:CreateValueBlock(name, parent, setPoint)
	if self.blocks[name] then return end
	local parentFrame = parent or _G.UIParent
	local frame = _G.CreateFrame("Frame", "CompactRunes_ValBlock_"..name, parentFrame)
	self.blocks[name] = frame
	frame.parentFrame = parentFrame
	frame.db = self.db.profile.blocks[name]
	frame.name = name
	frame.lock = true
	frame:SetBackdrop({
		bgFile = "Interface\\Buttons\\WHITE8X8", 
		edgeFile = "",
		tile = true, tileSize = 16, edgeSize = 16,
		insets = { left = 0, right = 0, top = 0, bottom = 0 }
		})

    frame.value = frame:CreateFontString(nil, "OVERLAY")
    frame.value:SetPoint("CENTER")
    frame.value:SetJustifyH("CENTER")
	frame.value:Show()

	if setPoint and _G.type(setPoint) == "function" then
		frame.SetDesiredPoint = setPoint
	else
		frame.SetDesiredPoint = function(self)
			self:SetPoint("CENTER")
		end
	end

	frame.SetValue = function(self, value) self.value:SetText(value) end

	frame.UpdateColor = function(self, color)
		local c
		if color then c = self.db.reapplycolor[color] end
		if self.db.background then
			if not c then c = self.db.bgcolor end
			self:SetBackdropColor(c.r, c.g, c.b, c.a)
		else
			if not c then c = self.db.textcolor end
			self.value:SetTextColor(c.r, c.g, c.b, c.a)
		end
	end

	frame.ResetFonts = function(self)
		local ff, fh, fflags = CompactRunes:GetFontSettings()
		local font = LSM:Fetch("font", ff)
	    self.value:SetFont(font, self.db.fontSize or fh, fflags)
		self.value:SetText(self.value:GetText())
	end

	frame.IsLocked = function(self)
		return self.lock
	end

	frame.Lock = function(self, locked)
		if locked ~= nil then
			self.lock = locked
		end
		self:EnableMouse(not self.lock)
	end

	frame.UpdateLayout = function(self)
		self:SetHeight(self.db.height)
		self:SetWidth(self.db.width)
		self:Lock()
		self:SetDesiredPoint()
		self:ResetFonts()
		if not self.db.background then
			self:SetBackdropColor(0,0,0,0)
		else
			local c = self.db.textcolor
			self.value:SetTextColor(c.r, c.g, c.b, c.a)
		end
		if self.db.enabled then self:Show() else self:Hide() end
	end

    frame:SetMovable()
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",
        function(self, button)
			if not self.lock then
            	self:StartMoving()
			end
        end)
    frame:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.db.x, self.db.y = x, y
			self:SetUserPlaced(false);
        end)

	frame:UpdateColor()
	frame:UpdateLayout()

	return frame
end

function CompactRunes:CreateBlocks()
	frames.ffStr = self:CreateValueBlock("FrostFeverStrength", 
		frames.ffBar.bar, 
		function(self)
			local db = CompactRunes.db.profile
			self:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				if db.diseaseOrder == "BF" then
					self:SetPoint("LEFT", self.parentFrame, "RIGHT", 
						self.db.offset, 0)
				else
					self:SetPoint("RIGHT", self.parentFrame, "LEFT", 
						-self.db.offset, 0)
				end
			end
		end)
	self.diseases.ff.val = frames.ffStr
	frames.bpStr = self:CreateValueBlock("BloodPlagueStrength", 
		frames.bpBar.bar, 
		function(self)
			local db = CompactRunes.db.profile
			self:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				if db.diseaseOrder == "BF" then
					self:SetPoint("RIGHT", self.parentFrame, "LEFT", 
						-self.db.offset, 0)
				else
					self:SetPoint("LEFT", self.parentFrame, "RIGHT", 
						self.db.offset, 0)
				end
			end
		end)
	self.diseases.bp.val = frames.bpStr
end

function CompactRunes:CreateDisplay()
	local frame = _G.CreateFrame("Frame", "CompactRunes_Display", _G.UIParent)
	frames.main = frame
	frame.db = self.db.profile.frame
	frame:SetPoint("CENTER", _G.UIParent, "CENTER", frame.db.x, frame.db.y)
	frame.GetDesiredWidth = function()
		return (self.db.profile.width + self.db.profile.spacing) * 2 + 10
	end
	frame.GetDesiredHeight = function()
		return (self.db.profile.height + self.db.profile.spacing) * 3 + 10
	end
	frame:SetWidth(frame.GetDesiredWidth())
	frame:SetHeight(frame.GetDesiredHeight())

	frame.ind = _G.CreateFrame("Frame", nil,frame)
	frame.ind:SetAllPoints(frame)
	frame.ind:Hide()
	frame.rcActive = false
	frame.outOfRange = false
	frame.UpdateInd = function(self)
		if self.outOfRange then
			self.ind:SetBackdropBorderColor(1, 0, 0, 0.6)
			self.ind:Show()
		elseif self.rcActive then
			self.ind:SetBackdropBorderColor(1, 1, 1, 0.6)
			self.ind:Show()
		else
			self.ind:Hide()
		end
	end
	self:SetMainFrameBorder()

	frame.lock = self.db.profile.locked
    frame:SetMovable()
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",
        function(self, button)
			if not self.lock then
            	self:StartMoving()
			end
        end)
    frame:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.db.x, self.db.y = x, y
			self:SetUserPlaced(false);
        end)
    frame:EnableMouse(not frame.lock)

	frames.boneBar = Bar:Create("BoneShieldBar", 0, 
		function() return self.db.profile.height - 2 end,
		function() return frame:GetDesiredHeight() end,
		function(self)
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				self.bar:SetPoint("BOTTOMLEFT", frames.main, "BOTTOMRIGHT", 
					CompactRunes.db.profile.runes.inset - 3, 0)
			end
		end
	)
	frames.boneBar:SetMovable()
	self:UpdateBoneShieldBarMode()

	frames.powerBar = Bar:Create("RunicPowerBar", 2, 
		function() return self.db.profile.width * 2 + self.db.profile.spacing end,
		function() return self.db.profile.height end,
		function(self)
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				self.bar:SetPoint("TOPLEFT", frames.main, "BOTTOMLEFT", 
					CompactRunes.db.profile.runes.inset + 1, -2)
			end
		end
	)
	frames.powerBar:SetMovable()
	self:UpdateRunicPowerMax()
	self:UpdateRunicPower()
	self:ShowRunicPowerBar()

	frames.bsBar = Bar:Create("BloodShieldBar", 2, 
		function() return self.db.profile.width * 2 + self.db.profile.spacing end,
		function() return self.db.profile.height end,
		function(self)
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				self.bar:SetPoint("TOPLEFT", frames.main, "BOTTOMLEFT", 
					CompactRunes.db.profile.runes.inset + 1, 
					-2 - CompactRunes.db.profile.height - 6)
			end
		end
	)
	frames.bsBar:SetMovable()

	frames.ffBar = Bar:Create("FrostFeverBar", 2, 
		function() return self.db.profile.width end,
		function() return self.db.profile.height end,
		function(self)
			local db = CompactRunes.db.profile
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				if db.diseaseOrder == "BF" then
					self.bar:SetPoint("BOTTOMRIGHT", frames.main, "TOPRIGHT", 
						-db.runes.inset, 0)
				else
					self.bar:SetPoint("BOTTOMLEFT", frames.main, "TOPLEFT", 
						db.runes.inset, 0)
				end
			end
		end,
		function(self) self.bar.value:SetPoint("CENTER", self.bar, "TOP", 0, 0) end
	)
	frames.ffBar:SetMovable()
	frames.ffBar.reapply = nil
	self.diseases.ff.bar = frames.ffBar

	frames.bpBar = Bar:Create("BloodPlagueBar", 2, 
		function() return self.db.profile.width end,
		function() return self.db.profile.height end,
		function(self)
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				local db = CompactRunes.db.profile
				if db.diseaseOrder == "FB" then
					self.bar:SetPoint("BOTTOMRIGHT", frames.main, "TOPRIGHT", 
						-db.runes.inset, 0)
				else
					self.bar:SetPoint("BOTTOMLEFT", frames.main, "TOPLEFT", 
						db.runes.inset, 0)
				end
			end
		end,
		function(self) self.bar.value:SetPoint("CENTER", self.bar, "TOP", 0, 0) end
	)
	frames.bpBar:SetMovable()
	frames.bpBar.reapply = nil
	self.diseases.bp.bar = frames.bpBar

	frames.dtBar = Bar:Create("DarkTransformationBar", 2, 
		function() return self.db.profile.width end,
		function() return self.db.profile.height end,
		function(self)
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				local profile = CompactRunes.db.profile
				local yOffset = profile.spacing * 2 + profile.height + 2
				if CompactRunes:IsBothDTBCBars() then
					self.bar:SetPoint("BOTTOMLEFT", frames.main, "TOPLEFT", 
						profile.runes.inset, yOffset)
				else
					self.bar:SetPoint("BOTTOM", frames.main, "TOP", 
						0, yOffset)
				end
			end
		end,
		function(self) self.bar.value:SetPoint("CENTER", self.bar, "TOP", 0, 0) end
	)
	frames.dtBar:SetMovable()

	frames.bcBar = Bar:Create("BloodChargeBar", 2, 
		function() return self.db.profile.width end,
		function() return self.db.profile.height end,
		function(self)
			self.bar:ClearAllPoints()
			local x, y = self.db.x, self.db.y
			if self.db.userPlaced and x ~= nil and y ~= nil then
				self.bar:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
			else
				local profile = CompactRunes.db.profile
				local yOffset = profile.spacing * 2 + profile.height + 2
				if CompactRunes:IsBothDTBCBars() then
					self.bar:SetPoint("BOTTOMRIGHT", frames.main, "TOPRIGHT", 
						-profile.runes.inset, yOffset)
				else
					self.bar:SetPoint("BOTTOM", frames.main, "TOP", 
						0, yOffset)
				end
			end
		end,
		function(self) self.bar.value:SetPoint("CENTER", self.bar, "TOP", 0, 0) end
	)
	frames.bcBar:SetMovable()

	self:CreateProcIndicator()
	self:CreateBlocks()

	-- Create the runes and then update their status
	for i = 1, 6 do
		runeBars[i] = Bar:Create("RuneBar"..i, 0, 
			function() return self.db.profile.width end,
			function() return self.db.profile.height end,
			nil,
			nil
		)
		runeBars[i].bar.showing = runes[i]
	end
	self:UpdateRunes()
	self:SetRuneOrder(self.db.profile.runeOrder)
	frames.main:SetAlpha(self.db.profile.ooc_alpha)
	frames.main:Show()
end

function CompactRunes:ShowRunicPowerBar()
	if self.db.profile.bars.RunicPowerBar.enabled then
		frames.powerBar.bar:Show()
		self:RegisterEvent("UNIT_POWER_FREQUENT")
	else
		frames.powerBar.bar:Hide()
		self:UnregisterEvent("UNIT_POWER_FREQUENT")
	end
end

function CompactRunes:RUNE_POWER_UPDATE(event, runeIndex, isEnergized)
	self:UpdateRuneCooldown(runeIndex, isEnergized)
end

function CompactRunes:RUNE_TYPE_UPDATE(event, runeIndex)
	self:UpdateRuneType(runeIndex)
end

function CompactRunes:UNIT_POWER_FREQUENT(event, unit, type)
	if unit == "player" then -- and type == "RUNIC_POWER" then
		self:UpdateRunicPower()
	end
end

function CompactRunes:UpdateRunicPower()
	frames.powerBar:SetValue(_G.UnitPower("player", 6))
end

function CompactRunes:UpdateRunicPowerMax()
	frames.powerBar.bar:SetMinMaxValues(0, _G.UnitPowerMax("player", 6))
end

-- Frost Vulnerability from Razorice is dynamic.  No need to calculate it.
-- 5.1 FF: 143 + 0.138 * AP
-- 5.1 BP: 172 + 0.138 * AP
local BASEFF = 166
local BASEBP = 197
local APMOD = 0.158
function CompactRunes:CalculateDiseaseDamage()
	local dmgmod = self.damageModifier
	for name, val in pairs(self.adjustments) do
		if name and self.db.profile.adjustments[name] and self.adjustments[name] then
			dmgmod = dmgmod / self.adjustmentMods[name]
		end
	end

	local baseFF = (BASEFF + APMOD * self.effectiveAP) * dmgmod
	local baseBP = (BASEBP + APMOD * self.effectiveAP) * dmgmod

	if self.currentSpec == "Frost" then
		baseFF = baseFF * (1 + (2.0 * self.mastery / 100))
	elseif self.currentSpec == "Unholy" then
		baseFF = baseFF * 1.6
		baseBP = baseBP * (1 + (2.5 * self.mastery / 100)) * 1.6
	end

	local effFF = baseFF * (1 + self.critChance)
	local effBP = baseBP * (1 + self.critChance)

	if self.cinderglacier then
		effFF = effFF * 1.2
		effBP = effBP * 1.2
	end

	self.base.ff = baseFF
	self.base.bp = baseBP
	self.eff.ff = effFF
	self.eff.bp = effBP

	if self.db.profile.debug then
		local fmt = "FF: %d / %d, BP: %d/ %d"
		self:Print(fmt:format(
			round(baseFF), round(effFF), round(baseBP), round(effBP)))
	end

	self:CheckDiseases()
end

local percFmt = "%.0f"
local reapplyFmt = "Reapply %s [%d %s %d : %d (%.1f)]"
local diseases = { "ff", "bp" }
function CompactRunes:CheckDiseases()
	if self.currentTarget and self.db.profile.trackDiseases then
		local thresholdType = self.db.profile.diseaseThresholdType
		local thresholdPerc = self.db.profile.diseaseThreshold
		local thresholdAmt = self.db.profile.diseaseThresholdAmt
		for i, disease in ipairs(diseases) do
			local snapshot = self[disease][self.currentTarget] or 0
			local reapply = 0
			local perc = 0
			if snapshot > 0 then
				perc = self.eff[disease] / snapshot * 100
				if self.eff[disease] > snapshot then
					local threshold
					if thresholdType == "Fixed" then
						threshold = snapshot + thresholdAmt
					else
						threshold = snapshot * (1 + thresholdPerc)
					end
					reapply = self.eff[disease] >= threshold and 2 or 1
				elseif self.eff[disease] < snapshot then
					reapply = -1
				end
				if self.db.profile.debug and reapply ~= 0 then
					local diff = self.eff[disease]-snapshot
					self:Print(reapplyFmt:format(
						disease:upper(), round(self.eff[disease]), 
						reapply == -1 and "<" or ">",
						round(snapshot),
						diff, diff/snapshot*100))
				end
			end
			local objs = self.diseases[disease]
			local bar = objs.bar
			local val = objs.val
			if val.db.enabled then val:SetValue(percFmt:format(perc)) end
			if reapply ~= bar.reapply then
				bar:SetValueTextColor(bar.db.reapplycolor[reapply])
				if val.db.enabled then
					val:UpdateColor(reapply)
				end
				bar.reapply = reapply
			end
		end
	end
end

function CompactRunes:UNIT_MAXPOWER(event)
	self:UpdateRunicPowerMax()
end

function CompactRunes:UNIT_HEALTH(event, unit)
	if unit == "target" then
		self:CheckSoulReaper()
	end
end

function CompactRunes:UNIT_LEVEL(event, unit)
	if unit == "player" then
		self:CheckTalents()
	end
end

function CompactRunes:UpdateAllStats()
	local update = false

	local base, posBuff, negBuff = _G.UnitAttackPower("player")
	local effAP = base + posBuff - negBuff
	if effAP ~= self.effectiveAP then
		self.effectiveAP = effAP
		update = true
	end

	local dmgMod = _G.select(7, _G.UnitDamage("player")) or 1.0
	if dmgMod ~= self.damageModifier then
		if self.db.profile.debugBP then
			local fmt = "Dmg Mod: %.1f"
			self:Print(fmt:format(dmgMod))
		end
		self.damageModifier = dmgMod
		update = true
	end

	local mastery = _G.GetMastery()
	if mastery ~= self.mastery then
		self.mastery = mastery
		update = true
	end

	local critChance = _G.GetCritChance() / 100
	if critChance > 1 then critChance = 1 end
	if critChance ~= self.critChance then
		self.critChance = critChance
		update = true
	end

	if update then self:CalculateDiseaseDamage() end
end

function CompactRunes:UNIT_ATTACK_POWER(event, unit)
	if unit == "player" then
		self:UpdateAllStats()
	end
end

function CompactRunes:UNIT_STATS(event, unit)
	if unit == "player" then
		self:UpdateAllStats()
	end
end

function CompactRunes:PLAYER_DAMAGE_DONE_MODS(event, unit)
	if unit == "player" then
		self:UpdateAllStats()
	end
end

function CompactRunes:COMBAT_RATING_UPDATE()
	self:UpdateAllStats()
end

local LastBPTick = 0
function CompactRunes:PLAYER_REGEN_DISABLED()
	-- Player has entered combat.
	frames.main:SetAlpha(self.db.profile.combatAlpha)
	self.LastFightStats:Reset()
	if self.db.profile.rangeInd then
		frames.main:SetScript("OnUpdate", onUpdateInd)
	end
	local bar = self.cdbars[self.currentSpec]
	if bar and bar.SetAlpha then bar:SetAlpha() end

	LastBPTick = 0
end

function CompactRunes:PLAYER_REGEN_ENABLED()
	-- Player has left combat.
	frames.main:SetAlpha(self.db.profile.ooc_alpha)
	if self.db.profile.rangeInd and not self.targetHostile then
		frames.main:SetScript("OnUpdate", nil)
		frames.main.outOfRange = false
		frames.main:UpdateInd()
	end
	local bar = self.cdbars[self.currentSpec]
	if bar and bar.SetAlpha then bar:SetAlpha() end
end

function CompactRunes:PLAYER_TARGET_CHANGED(unit)
	self.targetHostile = _G.UnitExists("target") and 
		_G.UnitCanAttack("player", "target") and
		not _G.UnitIsDead("target")
	if self.targetHostile and self.db.profile.rangeInd then
		frames.main:SetScript("OnUpdate", onUpdateInd)
	else
		frames.main:SetScript("OnUpdate", nil)
		frames.main.outOfRange = false
		frames.main:UpdateInd()
	end

	self.targetMaxHealth = _G.UnitHealthMax("target") or 0
	self.currentTarget = _G.UnitGUID("target")

	if self.currentProcs["Plague Leech"] ~= nil then
		self.currentProcs["Plague Leech"] = nil
		self:UpdateProcIcon()
	end
	self:UNIT_AURA("UNIT_AURA", "target")
	self:CheckSoulReaper()
	frames.ffBar.reapply = nil
	frames.bpBar.reapply = nil
	self:CheckDiseases()
end

local petBuffs = {
	SpellNames["Dark Transformation"],
	SpellNames["Shadow Infusion"],
}
local diseases
function CompactRunes:UNIT_AURA(event, unit)
	local name, rank, icon, count, dispelType, duration, expires, 
		caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
		isBossDebuff, castByPlayer, value1, value2, value3 

	if unit == "target" then
		diseases = diseases or {
			[SpellNames["Frost Fever"]] = frames.ffBar,
			[SpellNames["Blood Plague"]] = frames.bpBar,
		}

		for spell, bar in pairs(diseases) do
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
			= _G.UnitDebuff("target", spell, nil, "PLAYER")

			if name and bar.db.enabled then
				bar.bar.active = true
				local timeLeft = expires - _G.GetTime()
				if timeLeft > bar.bar.timer + 1 then
					if self.currentProcs["Plague Leech"] ~= nil then
						self.currentProcs["Plague Leech"] = nil
						self:UpdateProcIcon()
					end
				end
				bar.bar.timer = timeLeft
				bar.bar:SetMinMaxValues(0, duration)
				bar.bar:Show()
				bar.bar:SetScript("OnUpdate", onUpdateDisease)
			else
				bar.bar.active = false 
				bar.bar.timer = 0
				bar.bar:SetScript("OnUpdate", nil)
				bar.bar:Hide()
				if spell == "Blood Plague" then
					if self.currentProcs["Plague Leech"] ~= nil then
						self.currentProcs["Plague Leech"] = nil
						self:UpdateProcIcon()
					end
				end
			end
		end

		name, rank, icon, count, dispelType, duration, expires, 
		caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
		isBossDebuff, castByPlayer, value1, value2, value3 
		= _G.UnitDebuff("target", SpellNames["Soul Reaper"], nil, "PLAYER")
		local old = self.targetSoulReaper
		if name then
			self.targetSoulReaper = true
		else
			self.targetSoulReaper = false
		end
		if old ~= self.targetSoulReaper then
			self:UpdateProcIcon()
		end
	elseif unit == "player" then
		if self.db.profile.bars.BloodShieldBar.enabled then
			local bsBar = frames.bsBar
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitBuff("player", SpellNames["Blood Shield"])
			if name then
				bsBar.bar.timer = expires - _G.GetTime()
				bsBar.bar:SetMinMaxValues(0, duration)
				bsBar.bar.value:SetText(FormatNumber(value1 or 0))
				bsBar.bar.active = true 
				bsBar.bar:Show()
				bsBar.bar:SetScript("OnUpdate", onUpdateBloodCharge)
			else
				bsBar.bar.active = false 
				bsBar.bar.timer = 0
				bsBar.bar:SetScript("OnUpdate", nil)
				bsBar.bar:Hide()
			end
		end

		if self.enabled.BoneShieldBar then
			local bar = frames.boneBar
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitBuff("player", SpellNames["Bone Shield"])
			local state = nil
			if name then
				state = 0
				local timeLeft = expires - _G.GetTime()
				if bar.db.progress == "Charges" and timeLeft > bar.bar.timer + 10 then
					bar.bar:SetMinMaxValues(0, count)
				end
				bar.bar.timer = timeLeft
				bar.bar.active = true 
				if count ~= bar.bar.count then
					bar.bar.value:SetText(tostring(count))
				end
				bar.bar.count = count
				bar.bar.recharging = false
				bar.bar.recharging = 0
			else
				bar.bar.active = false 
				bar.bar.timer = 0
				bar.bar.count = 0
				local start, duration, enabled = 
					_G.GetSpellCooldown(SpellIds["Bone Shield"])
				if duration > 0 then
					state = 1
					bar.bar.recharging = true
					bar.bar.recharge = duration - (_G.GetTime() - start)
				else
					state = 2
					bar.bar.recharging = false
					bar.bar.recharging = 0
				end
			end

			-- Update the display if state has changed
			if state ~= bar.bar.state then
				if state == 0 then
					-- Active
					if bar.db.progress == "Charges" then
						bar.bar:SetMinMaxValues(0, bar.bar.count)
					elseif bar.db.progress == "Time" then
						bar.bar:SetMinMaxValues(0, duration)
					else
						bar.bar:SetMinMaxValues(0, 1)
						bar.bar:SetValue(1)
					end
					bar.bar:SetAlpha(1)
					bar.bar.rechargeTime:Hide()
					bar.bar.value:Show()
					bar.bar:Show()
					bar.bar:SetScript("OnUpdate", onUpdateBoneShield)
				elseif state == 1 then
					-- Recharging
					if bar.db.showCooldown then
						bar.bar.value:Hide()
						bar.bar.rechargeTime:Show()
						bar.bar:SetAlpha(0.5)
						bar.bar:SetValue(_G.select(2, bar.bar:GetMinMaxValues()))
						bar.bar:SetScript("OnUpdate", onUpdateBoneShield)
						bar.bar:Show()
					else
						bar.bar:Hide()
					end
				else 
					-- Ready
					bar.bar.rechargeTime:Hide()
					bar.bar.value:Show()
					bar.bar.value:SetText("-")
					if bar.db.showReady then
						bar.bar:SetAlpha(0.5)
						bar.bar:SetValue(_G.select(2, bar.bar:GetMinMaxValues()))
						bar.bar:SetScript("OnUpdate", nil)
						bar.bar:Show()
					else
						bar.bar:Hide()
					end
				end
			end
			bar.bar.state = state
		end

		if self.db.profile.bars.BloodChargeBar.enabled then
			local bcBar = frames.bcBar
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitBuff("player", SpellNames["Blood Charge"])
			if name then
				if expires > self.bcExpires then
					if self.bloodCharges >= self.MaxBloodCharges - 1 then
						self.TotalStats.cappedBC = self.TotalStats.cappedBC + 1
						self.LastFightStats.cappedBC = self.LastFightStats.cappedBC + 1
					end
				end
				self.bloodCharges = count
				self.bcExpires = expires
				bcBar.bar.timer = expires - _G.GetTime()
				bcBar.bar:SetMinMaxValues(0, duration)
				bcBar.bar.value:SetText(tostring(count))
				bcBar.bar.active = true 
				bcBar.bar:Show()
				bcBar.bar:SetScript("OnUpdate", onUpdateBloodCharge)
			else
				self.bloodCharges = 0
				self.bcExpires = 0
				bcBar.bar.active = false 
				bcBar.bar.timer = 0
				bcBar.bar:SetScript("OnUpdate", nil)
				bcBar.bar:Hide()
			end
		end

		if self.db.profile.procs then
			local procInd = frames.procInd
			local procPriority = self.db.profile.priorityList[self.currentSpec]
			local enabled = self.db.profile.enabled[self.currentSpec]
			if procPriority and enabled then
				for i, spell in ipairs(procPriority) do
					if not self.specialProcs[spell] then
						name, rank, icon, count, dispelType, duration, expires, 
						caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
						isBossDebuff, castByPlayer, value1, value2, value3 
						= _G.UnitBuff("player", SpellNames[spell])
						if name then
							self.currentProcs[spell] = (count or 1)
						else
							self.currentProcs[spell] = nil
						end
					end
				end
			end
			self:UpdateProcIcon()
		end

		if self.db.profile.trackDiseases then
			local calculate = false
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitBuff("player", SpellNames["Cinderglacier"])
			local cinder = (name ~= nil)
			if cinder ~= self.cinderglacier then
				self.cinderglacier = cinder
				calculate = true
			end

			if self.db.profile.adjustments["Tricks of the Trade"] then
				name, rank, icon, count, dispelType, duration, expires, 
				caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
				isBossDebuff, castByPlayer, value1, value2, value3 
					= _G.UnitBuff("player", SpellNames["Tricks of the Trade"])
				local tricks = (name ~= nil)
				if tricks ~= self.adjustments["Tricks of the Trade"] then
					self.adjustments["Tricks of the Trade"] = tricks
					calculate = true
				end
			end
			if calculate then self:CalculateDiseaseDamage() end
		end
	elseif unit == "pet" then
		for i, spell in pairs(petBuffs) do
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
			= _G.UnitBuff("pet", spell, nil, "PLAYER")
			if name then break end
		end

		local dtBar = frames.dtBar
		if name then
			dtBar.bar.dt = (name == SpellNames["Dark Transformation"])
			dtBar.altcolor = dtBar.bar.dt
			dtBar.bar.timer = expires - _G.GetTime()
			local dtdb = self.db.profile.bars.DarkTransformationBar
			local bc, tc
			if dtBar.altcolor then
				bc = dtdb.alt_color
				tc = dtdb.alt_textcolor
			else
				bc = dtdb.color
				tc = dtdb.textcolor
				dtBar.bar.value:SetText(tostring(count))
			end
			dtBar.bar:SetMinMaxValues(0, duration)
			dtBar.bar:SetStatusBarColor(bc.r, bc.g, bc.b, bc.a)
			dtBar.bar.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
			if self.db.profile.bars.DarkTransformationBar.enabled then
				dtBar.bar.active = true 
				dtBar.bar:Show()
				dtBar.bar:SetScript("OnUpdate", onUpdateDarkTrans)
			end
		else
			dtBar.bar.active = false 
			dtBar.bar.timer = 0
			dtBar.bar:SetScript("OnUpdate", nil)
			dtBar.bar:Hide()
		end
	end
end

function CompactRunes:PLAYER_SPECIALIZATION_CHANGED(event)
	self:CheckTalents()
end

function CompactRunes:PLAYER_TALENT_UPDATE(event)
	self:CheckTalents()
end

function CompactRunes:COMBAT_LOG_EVENT_UNFILTERED(...)
    local event, timestamp, eventtype, hideCaster, 
        srcGUID, srcName, srcFlags, srcRaidFlags, 
        destGUID, destName, destFlags, destRaidFlags, 
        param9, param10, param11, param12, param13, param14, 
        param15, param16, param17, param18, param19, param20

    event, timestamp, eventtype, hideCaster, 
    srcGUID, srcName, srcFlags, srcRaidFlags,
    destGUID, destName, destFlags, destRaidFlags,
    param9, param10, param11, param12, param13, param14, 
    param15, param16, param17, param18, param19, param20 = ...

	if destGUID == self.playerGUID then
		if eventtype == "SPELL_AURA_APPLIED" then
			if param9 == SpellIds["Runic Corruption"] then
				self.LastFightStats.rcProcs = self.LastFightStats.rcProcs + 1
				self.TotalStats.rcProcs = self.TotalStats.rcProcs + 1
				if frames.main then
					frames.main.rcActive = true
					frames.main:UpdateInd()
				end
			end
		elseif eventtype == "SPELL_AURA_REMOVED" then
			if param9 == SpellIds["Runic Corruption"] then
				if frames.main then
					frames.main.rcActive = false
					frames.main:UpdateInd()
				end
			end
		end
	end
	if srcGUID == self.playerGUID then
		if self.db.profile.debugBP and 
			eventtype == "SPELL_PERIODIC_DAMAGE" and 
			param9 == SpellIds["Blood Plague Periodic"] and
			destGUID == self.currentTarget and not param18 then
			if math.abs(param12 - LastBPTick) > 1 then
				LastBPTick = param12
				local fmt = "New BP Tick: %d"
				self:Print(fmt:format(LastBPTick))
			end
		end
		if eventtype == "SPELL_AURA_APPLIED" or eventtype == "SPELL_AURA_REFRESH" then
			if param9 == SpellIds["Frost Fever"] or param9 == SpellIds["Frost Fever Periodic"] then
				self.ff[destGUID] = self.eff.ff
				if destGUID == self.currentTarget then
					frames.ffBar:SetValueTextColor()
					if frames.ffStr.db.enabled then
						frames.ffStr:SetValue("100")
						frames.ffStr:UpdateColor()
					end
					frames.ffBar.reapply = nil
				end
			elseif param9 == SpellIds["Blood Plague"] or param9 == SpellIds["Blood Plague Periodic"] then
				self.bp[destGUID] = self.eff.bp
				if destGUID == self.currentTarget then
					frames.bpBar:SetValueTextColor()
					if frames.bpStr.db.enabled then
						frames.bpStr:SetValue("100")
						frames.bpStr:UpdateColor()
					end
					frames.bpBar.reapply = nil

					-- If Plague Leech proc is active, remove it.
					if self.currentProcs["Plague Leech"] ~= nil then
						self.currentProcs["Plague Leech"] = nil
						self:UpdateProcIcon()
					end
				end
			end
		elseif eventtype == "SPELL_AURA_REMOVED" then
			if param9 == SpellIds["Frost Fever"] or param9 == SpellIds["Frost Fever Periodic"] then
				self.ff[destGUID] = nil
				frames.ffBar.reapply = nil
			elseif param9 == SpellIds["Blood Plague"] or param9 == SpellIds["Blood Plague Periodic"] then
				self.bp[destGUID] = nil
				frames.bpBar.reapply = nil
				
				if destGUID == self.currentTarget then
					-- If Plague Leech proc is active, remove it.
					if self.currentProcs["Plague Leech"] ~= nil then
						self.currentProcs["Plague Leech"] = nil
						self:UpdateProcIcon()
					end
				end
			end
		elseif eventtype == "SPELL_DAMAGE" or 
			(eventtype == "SPELL_HEAL" and self.regenMethod == "BT") then
			local damage = param12 or 0
			if damage > 0 and self.regenAbilities[param9] ~= nil then
				local regenMethod = self.regenMethod
				self.TotalStats.regenUses[regenMethod] = (self.TotalStats.regenUses[regenMethod] or 0) + 1
				self.LastFightStats.regenUses[regenMethod] = (self.LastFightStats.regenUses[regenMethod] or 0) + 1
			end
		end
	end
end

function CompactRunes:SPELL_UPDATE_COOLDOWN(event)
	local changed = false
	if self.currentSpec == "Frost" then
		local start, duration, enabled = 
			_G.GetSpellCooldown(SpellIds["Pillar of Frost"])
		local pillarReady = (duration < 2)
		self.currentProcs["Pillar of Frost"] = (pillarReady and 1 or nil)
		if self.pillarReady ~= pillarReady then
			changed = true
		end
		self.pillarReady = pillarReady
	elseif self.currentSpec == "Unholy" then
		local start, duration, enabled = 
			_G.GetSpellCooldown(SpellIds["Summon Gargoyle"])
		local gargoyleReady = (duration < 2)
		self.currentProcs["Summon Gargoyle"] = (gargoyleReady and 1 or nil)
		if self.gargoyleReady ~= gargoyleReady then
			changed = true
		end
		self.gargoyleReady = gargoyleReady

		start, duration, enabled = 
			_G.GetSpellCooldown(SpellIds["Unholy Frenzy"])
		local frenzyReady = (duration == 0)
		self.currentProcs["Unholy Frenzy"] = (frenzyReady and 1 or nil)
		if self.frenzyReady ~= frenzyReady then
			changed = true
		end
		self.frenzyReady = frenzyReady
	end

	if changed then
		self:UpdateProcIcon()
	end
end

function CompactRunes:UNIT_PET(event, unit)
	if unit and unit == "player" then
		if not _G.UnitExists("pet") and self.currentSpec == "Unholy" then
			-- Ghoul is missing.
		end
	end
end

function CompactRunes:PLAYER_ENTERING_WORLD(event)
	for i = 1, 6 do
		self:UpdateRuneType(i)
		self:UpdateRuneCooldown(i)
	end
	self:UpdateRunicPower()
	self.playerGUID = _G.UnitGUID("player") or ""
	self:UNIT_AURA("PLAYER_ENTERING_WORLD", "player")
end

local TierSlotIds = {
	["Head"] = _G.GetInventorySlotInfo("HeadSlot"),
	["Shoulder"] = _G.GetInventorySlotInfo("ShoulderSlot"),
	["Chest"] = _G.GetInventorySlotInfo("ChestSlot"),
	["Legs"] = _G.GetInventorySlotInfo("LegsSlot"),
	["Hands"] = _G.GetInventorySlotInfo("HandsSlot"),
}

local TierIds = {
	["T15 DPS"] = {
		["Head"] = {
			[95827] = true,
			[95227] = true,
			[96571] = true,
			},
		["Shoulder"] = {
			[95829] = true,
			[95229] = true,
			[96573] = true,
			},
		["Chest"] = {
			[95825] = true,
			[95225] = true,
			[96569] = true,
			},
		["Legs"] = {
			[95828] = true,
			[95228] = true,
			[96572] = true,
			},
		["Hands"] = {
			[95826] = true,
			[95226] = true,
			[96570] = true,
		},
	},
	["T16 DPS"] = {
		["Head"] = {
			[99057] = true,
			[99194] = true,
			[99337] = true,
			},
		["Shoulder"] = {
			[99059] = true,
			[99187] = true,
			[99339] = true,
			},
		["Chest"] = {
			[99066] = true,
			[99192] = true,
			[99355] = true,
			},
		["Legs"] = {
			[99058] = true,
			[99186] = true,
			[99338] = true,
			},
		["Hands"] = {
			[99067] = true,
			[99193] = true,
			[99336] = true,
		}
	},
}

local TierSlots = {}
for k, v in pairs(TierSlotIds) do
	TierSlots[v] = true
end

local TrackedItemSlotIds = {
	["Trinket1"] = _G.GetInventorySlotInfo("Trinket0Slot"),
	["Trinket2"] = _G.GetInventorySlotInfo("Trinket1Slot"),
}
local TrackedItemSlots = {}
for k, v in pairs(TrackedItemSlotIds) do
	TrackedItemSlots[v] = true
end

local GearChangeTimer = nil
function CompactRunes:CheckGear()
	GearChangeTimer = nil
	local count = 0
	local changed = false

	for tier, ids in pairs(TierIds) do
		count = 0
		for slot, slotid in pairs(TierSlotIds) do
			local id = _G.GetInventoryItemID("player", slotid)
			if ids[slot][id] then
				count = count + 1
			end
		end

		if count ~= self.tierCount[tier] then
			self.tierCount[tier] = count
			if self.db.profile.debug and not _G.InCombatLockdown() then
				local fmt = "%s Detected: %d/5"
				self:Print(fmt:format(tier, self.tierCount[tier]))
			end
			changed = true
		end
	end

	if changed then self:UpdateTierBonus() end
	for name, bar in pairs(self.cdbars) do
		if bar then bar:Update() end
	end
end

function CompactRunes:UpdateTierBonus()
	self.soulReaperPerc = self.tierCount["T15 DPS"] >= 4 and 0.45 or 0.35
end

function CompactRunes:PLAYER_EQUIPMENT_CHANGED(event, slot, hasItem)
	if (TierSlots[slot] or TrackedItemSlots[slot]) and not GearChangeTimer then
		GearChangeTimer = self:ScheduleTimer("CheckGear", 1.5)
	end
end
