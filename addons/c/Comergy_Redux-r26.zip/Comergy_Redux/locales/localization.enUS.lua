if (true) then
    COMERGY_OPTION_FRAME_MESSAGE = "Comergy is a simple and nice-looking combo/energy/power addon."

    COMERGY_OPTION_FRAME_BUTTON = "Comergy Options"

    COMERGY_RUNE_NAME = {

    "Blood",
    "Unholy",
    "Frost",
    "Death"
	}

end
