local L = LibStub("AceLocale-3.0"):NewLocale("CharacterNotes", "esMX", false)

if not L then return end


