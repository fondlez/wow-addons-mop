local L = LibStub("AceLocale-3.0"):NewLocale("CharacterNotes", "esES", false)

if not L then return end

L["Are you sure you wish to delete the note for:"] = "Seguro que quieres eliminar la nota de:" -- Needs review
L["Cancel"] = "Cancelar" -- Needs review
L["Character Name"] = "Nombre del Personaje" -- Needs review
L["Character Notes"] = "Notas del Personaje" -- Needs review
L["Clear"] = "Borrar" -- Needs review
L["Close"] = "Cerrar" -- Needs review
L["Delete"] = "Eliminar" -- Needs review
L["Deleted note for %s"] = "Nota de %s eliminada" -- Needs review
L["Delete Note"] = "Eliminar Nota" -- Needs review
L["Edit"] = "Editar" -- Needs review
L["Right click"] = "Click derecho" -- Needs review
L["Save"] = "Guardar" -- Needs review
L["Search"] = "Buscar" -- Needs review
L["Set note for %s: %s"] = "Establecer nota para %s: %s" -- Needs review
L["Show notes at logon"] = "Mostrar notas al iniciar sesión" -- Needs review
L["Show notes in tooltips"] = "Mostrar notas en tooltips" -- Needs review

