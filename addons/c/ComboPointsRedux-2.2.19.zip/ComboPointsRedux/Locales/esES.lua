local AceLocale = LibStub:GetLibrary("AceLocale-3.0") 
local L = AceLocale:NewLocale("ComboPointsRedux", "esES") 
if not L then return end 

-- L["Left click and drag to move the frame."] = "Left click and drag to move the frame."
-- L["%s Graphics"] = "%s Graphics"
-- L["%s Text"] = "%s Text"
-- L["To hide the background, open the options and select the 'Lock' option."] = "To hide the background, open the options and select the 'Lock' option."

