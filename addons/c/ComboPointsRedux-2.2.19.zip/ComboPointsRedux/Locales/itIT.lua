local AceLocale = LibStub:GetLibrary("AceLocale-3.0") 
local L = AceLocale:NewLocale("ComboPointsRedux", "itIT") 
if not L then return end

L["Left click and drag to move the frame."] = "Clicka con il tasto sinistro e sposta per muovere il frame" -- Needs review
L["%s Graphics"] = "%s Grafica" -- Needs review
L["%s Text"] = "%s Testo" -- Needs review
L["To hide the background, open the options and select the 'Lock' option."] = "Per nascondere lo sfondo, apri le opzioni e seleziona l'opzione 'Blocca'" -- Needs review
