function vexpower_Show_check(frame)
	local returnvalue = true
	
	--check for enabled addon and enabled frame
	if vexpower_parameters["frame"]["show"] and vexpower_parameters["frame"][frame]["show"] then
		--check for infight		
		if vexpower_parameters["frame"][frame]["infightshow"] and not(vexpower.infight) then
			returnvalue = false
		end
		
		--check for stealth (overwrites infight result!)
		if vexpower_parameters["frame"][frame]["stealthshow"] and vexpower.stealth then
			returnvalue = true
		end
		
		--check for targetSet (overwrites infight result!)
		if vexpower_parameters["frame"][frame]["targetSetshow"] and vexpower.targetSet then
			returnvalue = true
		end
			
		--check for vehicle
		if vexpower.inVehicle and vexpower_parameters["frame"][frame]["vehiclehide"] then
			returnvalue = false
		end
			
		--check for petBattle
		if vexpower.inPetBattle and vexpower_parameters["frame"][frame]["petBattleHide"] then
			returnvalue = false
		end
		
		--check for show not with powertype
		if vexpower_parameters["frame"][frame]["showWithPowerType"][vexpower.energytype] ~= nil then
			if not(vexpower_parameters["frame"][frame]["showWithPowerType"][vexpower.energytype]) then
				returnvalue = false
			end
		end
		
		--check for class and spec
		if frame == "combo" then			
			if not(vexpower_Show_Classcheck()) then
				returnvalue = false
			end
		end
	else
		returnvalue = false
	end
	
	return returnvalue
end

function vexpower_Show_Classcheck()
	local returnvalue = true
	
	if vexpower.class == "SHAMAN" and vexpower.specType == 263 then 		-- Shaman		Enhancer
		returnvalue = vexpower_parameters["classSpec"]["shaman"]["enhancer"] 
		
	elseif vexpower.class == "HUNTER" and vexpower.specType == 254 then		-- Hunter		Marksman
		returnvalue = vexpower_parameters["classSpec"]["hunter"]["mm"] 
	elseif vexpower.class == "HUNTER" and vexpower.specType == 253 then		-- Hunter		Beast Master
		returnvalue = vexpower_parameters["classSpec"]["hunter"]["bm"] 
		
	elseif vexpower.class == "WARRIOR" and vexpower.specType == 72 then		-- Warrior		Fury
		returnvalue = vexpower_parameters["classSpec"]["warrior"]["fury"] 
		
	elseif vexpower.class == "PRIEST" and vexpower.specType == 256 then		-- Priest		Discipline
		returnvalue = vexpower_parameters["classSpec"]["priest"]["disci"] 
	elseif vexpower.class == "PRIEST" and vexpower.specType == 258 then		-- Priest		Shadow
		returnvalue = vexpower_parameters["classSpec"]["priest"]["shadow"] 
		
	elseif vexpower.class == "MAGE" and vexpower.specType == 62 then		-- Mage			Arcane
		returnvalue = vexpower_parameters["classSpec"]["mage"]["arcane"] 
	
	elseif vexpower.class == "PALADIN" then									-- Paladin
		returnvalue = vexpower_parameters["classSpec"]["paladin"]["cps"] 
		
	elseif vexpower.class == "ROGUE" then									-- Rogues
		returnvalue = vexpower_parameters["classSpec"]["rogue"]["cps"] 
		
	elseif vexpower.class == "DRUID" then									-- Druid
		returnvalue = vexpower_parameters["classSpec"]["druid"]["cps"] 
		
	elseif vexpower.class == "MONK" then									-- Monk
		returnvalue = vexpower_parameters["classSpec"]["monk"]["cps"] 
		
	elseif vexpower.class == "WARLOCK" and vexpower.specType == 265 then	-- Warlock		Affliction
		returnvalue = vexpower_parameters["classSpec"]["warlock"]["affli"] 
	elseif vexpower.class == "WARLOCK" and vexpower.specType == 266 then	-- Warlock		Demonology
		returnvalue = vexpower_parameters["classSpec"]["warlock"]["demo"] 
	elseif vexpower.class == "WARLOCK" and vexpower.specType == 267 then	-- Warlock		Destruction
		returnvalue = vexpower_parameters["classSpec"]["warlock"]["destro"] 
	end
	
	return returnvalue
end


function vexpower_Show_handler()
	local show_energy = vexpower_Show_check("energy")
	local show_cps = vexpower_Show_check("combo")
	
	--react to 'show'
	if show_energy then
		vexpower_energybarbg:Show()
		UIFrameFadeOut(vexpower_energybarbg, 0, 1, 1)
	elseif not(show_energy) and vexpower.showEnergy then
		if vexpower_parameters["frame"]["fadeout"] then	
			UIFrameFadeOut(vexpower_energybarbg, vexpower_parameters["fadeOutTime"], 1, 0)
		else
			vexpower_energybarbg:Hide()
		end
	elseif not(show_energy) then
		vexpower_energybarbg:Hide()
	end
	
	if show_cps then
		vexpower_cpsbar:Show()
		vexpower_CPs_show()
		UIFrameFadeOut(vexpower_cpsbar, 0, 1, 1)
	elseif not(show_cps) and vexpower.showCPs then
		if vexpower_parameters["frame"]["fadeout"] then	
			UIFrameFadeOut(vexpower_cpsbar, vexpower_parameters["fadeOutTime"], 1, 0)
		else
			vexpower_cpsbar:Hide()
		end
	elseif not(show_cps) then
		vexpower_cpsbar:Hide()
	end
	
	vexpower.showCPs = show_cps
	vexpower.showEnergy = show_energy
end