function vexpower.options.specProfiles.panel()
	local name = GetRealmName().."-"..select(1, UnitName("player"))
	
	return {
		type = "group",
		args = {
			grpadd = {
				name = "Spec-Profiles",
				order=3, type ="group", dialogInline = true,
				args = {
					desc = {name = "Loads a specific profile depending on your active spec.\nThese settings won't be saved in profiles or global profiles and have to be set separately for every char!\n", type = "description", order=1},
					activate = {
						name = "Enable Spec-Profiles",
						order=10, type = "toggle", width="full",
						set = function(self,key) vexpower_SV_data["specProfile"]["activate"]=key vexpower.initialize.core(true) end,
						get = function() return vexpower_SV_data["specProfile"]["activate"] end,
						},
					profileA = {
						name = "Profile to load when spec A is active",
						order=20, type = "select", style = "dropdown", width="double",
						desc = "Delete an existing profile",
						values = vexpower.options.profiles.getList(true), disabled=not(vexpower_SV_data["specProfile"]["activate"]),
						set = function(self,key) vexpower_SV_data["specProfile"]["specAProfile"]=key end,
						get = function() return vexpower_SV_data["specProfile"]["specAProfile"] end,
						},
					descSpecA = {name = vexpower.options.specProfiles.getSpecDesc("A").."\n", type = "description", order=21},
					profileB = {
						name = "Profile to load when spec B is active",
						order=30, type = "select", style = "dropdown", width="double",
						desc = "Delete an existing profile",
						values = vexpower.options.profiles.getList(true), disabled=not(vexpower_SV_data["specProfile"]["activate"]),
						set = function(self,key) vexpower_SV_data["specProfile"]["specBProfile"]=key end,
						get = function() return vexpower_SV_data["specProfile"]["specBProfile"] end,
						},
					descSpecB = {name = vexpower.options.specProfiles.getSpecDesc("B").."\n", type = "description", order=31},
					},
				},
			}
		}
end
