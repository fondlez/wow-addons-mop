local isAtTransmogrifier, isAtVoidStorage

local slots = {
	"HeadSlot",
	"ShoulderSlot",
	"BackSlot",
	"ChestSlot",
	"WristSlot",
	"HandsSlot",
	"WaistSlot",
	"LegsSlot",
	"FeetSlot",
	"MainHandSlot",
	"SecondaryHandSlot",
}

local currentVoidItem = 0

local origClickVoidStorageSlot = ClickVoidStorageSlot

function ClickVoidStorageSlot(slot, isRightClick)
	local _, _, wasLocked = GetVoidItemInfo(slot)
	if not isRightClick or isAtVoidStorage then
		origClickVoidStorageSlot(slot, isRightClick)
	end
	-- make sure an item was picked up when clicked, and if not, clear current item
	if not wasLocked and select(3, GetVoidItemInfo(slot)) and not isRightClick then
		currentVoidItem = slot
	elseif not select(3, GetVoidItemInfo(currentVoidItem)) then
		currentVoidItem = 0
	end
end

-- disable transfer and withdraw functionality when not actually at the void storage
local origClickVoidTransferDepositSlot = ClickVoidTransferDepositSlot
function ClickVoidTransferDepositSlot(slot, isRightClick)
	if isAtVoidStorage then
		origClickVoidTransferDepositSlot(slot, isRightClick)
	end
end

local origClickVoidTransferWithdrawalSlot = ClickVoidTransferWithdrawalSlot
function ClickVoidTransferWithdrawalSlot(slot, isRightClick)
	if isAtVoidStorage then
		origClickVoidTransferWithdrawalSlot(slot, isRightClick)
	end
end

local origClickTransmogrifySlot = ClickTransmogrifySlot

function ClickTransmogrifySlot(slotID)
	if select(3, GetVoidItemInfo(currentVoidItem)) then
		local soundCVar = GetCVar("Sound_EnableSFX")
		SetCVar("Sound_EnableSFX", 0)
		UseVoidItemForTransmogrify(currentVoidItem, slotID)
		SetCVar("Sound_EnableSFX", soundCVar)
		local equipped = GetInventoryItemID("player", slotID)
		if equipped and CanTransmogrifyItemWithItem(GetVoidItemHyperlinkString(currentVoidItem), equipped) then
			ClearCursor()
			currentVoidItem = 0
		end
		return
	end
	local _, _, _, hasPending = GetTransmogrifySlotInfo(slotID)
	origClickTransmogrifySlot(slotID)
	if hasPending and not GetCursorInfo() then
		local soundCVar = GetCVar("Sound_EnableSFX")
		SetCVar("Sound_EnableSFX", 0)
		ClearCursor()
		SetCVar("Sound_EnableSFX", soundCVar)
	end
end

local function openTransmog()
	ItemAlteration_LoadUI()
	TransmogrifyFrame_Show()
end

SlashCmdList["VOIDTRANSMOG"] = openTransmog
SLASH_VOIDTRANSMOG1 = "/transmog"
SLASH_VOIDTRANSMOG2 = "/vt"

local function createButton(name, parent)
	local button = CreateFrame("Button", name, parent, "UIPanelButtonTemplate")
	button:SetWidth(100)
	button:SetText("Transmogrify")
	button:SetScript("OnClick", openTransmog)
	return button
end

local bankButton = createButton("VoidTransmog_BankButton", BankFrame)
bankButton:SetPoint("RIGHT", BankItemSearchBox, "LEFT", -16, 0)

local loadVoidButton

local origAddMessage = UIErrorsFrame.AddMessage

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("TRANSMOGRIFY_OPEN")
frame:RegisterEvent("TRANSMOGRIFY_CLOSE")
frame:RegisterEvent("VOID_STORAGE_OPEN")
frame:RegisterEvent("VOID_STORAGE_CLOSE")
frame:SetScript("OnEvent", function(self, event, ...)
	self[event](self, ...)
end)

function frame:ADDON_LOADED(addon)
	if addon == "Blizzard_ItemAlterationUI" then
		-- apparently pending items are retained between sessions, so clear them on load
		local soundCVar = GetCVar("Sound_EnableSFX")
		SetCVar("Sound_EnableSFX", 0)
		for i, slot in ipairs(slots) do
			ClearTransmogrifySlot(GetInventorySlotInfo(slot))
		end
		SetCVar("Sound_EnableSFX", soundCVar)
		
		UIPanelWindows["TransmogrifyFrame"].pushable = 1
		hooksecurefunc("TransmogrifyFrame_UpdateApplyButton", function()
			if not isAtTransmogrifier then
				TransmogrifyApplyButton:Disable()
			end
		end)
		TransmogrifyApplyButton:SetScript("OnEnter", function(self)
			if not isAtTransmogrifier then
				GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
				GameTooltip:AddLine("Visit transmogrifier to apply changes.")
				GameTooltip:Show()
			end
		end)
		TransmogrifyApplyButton:SetScript("OnLeave", GameTooltip_Hide)
		TransmogrifyApplyButton:SetMotionScriptsWhileDisabled(true)
		
		loadVoidButton = CreateFrame("Button", "VoidTransmog_LoadVoidButton", TransmogrifyFrame, "UIMenuButtonStretchTemplate")
		loadVoidButton:SetWidth(64)
		loadVoidButton:SetPoint("BOTTOMRIGHT", -24, 47)
		loadVoidButton:SetText("Void")
		loadVoidButton:SetFrameLevel(TransmogrifyFrame:GetFrameLevel() + 3)
		loadVoidButton:SetScript("OnClick", function(self)
			VoidStorage_LoadUI()
			VoidStorageFrame_Show()
		end)
		loadVoidButton:SetScript("OnEnter", function(self)
			if not self:IsEnabled() then
				GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
				GameTooltip:AddLine(CanUseVoidStorage() and "Visit transmogrifier to enable loading of void storage." or "Void storage is not unlocked.")
				GameTooltip:Show()
			end
		end)
		loadVoidButton:SetScript("OnLeave", GameTooltip_Hide)
		loadVoidButton:SetMotionScriptsWhileDisabled(true)
		if not (CanUseVoidStorage() and IsVoidStorageReady()) then
			loadVoidButton:Disable()
		end
	end
	if addon == "Blizzard_VoidStorageUI" then
		local voidButton = createButton("VoidTransmog_VoidButton", VoidStorageFrame)
		voidButton:SetPoint("RIGHT", VoidItemSearchBox, "LEFT", -16, 0)
	end
	if IsAddOnLoaded("Blizzard_ItemAlterationUI") and IsAddOnLoaded("Blizzard_VoidStorageUI") then
		self:UnregisterEvent("ADDON_LOADED")
		self.ADDON_LOADED = nil
	end
end

function frame:TRANSMOGRIFY_OPEN()
	isAtTransmogrifier = true
	TransmogrifyFrame_UpdateApplyButton()
	if CanUseVoidStorage() then
		loadVoidButton:Enable()
	end
end

function frame:TRANSMOGRIFY_CLOSE()
	isAtTransmogrifier = false
	loadVoidButton:Disable()
end

function frame:VOID_STORAGE_OPEN()
	isAtVoidStorage = true
end

function frame:VOID_STORAGE_CLOSE()
	isAtVoidStorage = false
end