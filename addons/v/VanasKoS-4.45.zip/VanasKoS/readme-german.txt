Beschreibung:

Vanas KoS is a Kill-on-Sight Warner, der jede M�glichkeit nutzt um in der N�he befindliche KoS-Ziele zu erkennen und den Nutzer zu warnen.

Features:
* KoS-Listen f�r Spieler und Gilden
* Nette-Leute Liste
* Hassliste
* Sortieren dieser Listen
* Alle Listen werden pro Realm gespeichert
* Goldener Drache um das Spieler-Portrait, wenn Spieler auf KoS-Liste ist, Silber f�r Gilden KoS-Liste, Rot f�r Hassliste, Gr�n f�r Nette-Leute-Liste
* Modifiziert den Tooltip bei r�berfahren mit der Maus um den Grund, warum entsprechender Spieler auf eine der Listen hinzugef�gt wurde
* Warnt Dich im Chatframe, Oberen Bereich und mit Sound, wenn ein Spieler in deiner N�he eine Aktion (k�mpfen, buffen, reden) ausf�hrt.
* Warn-Fenster, das dir hilft feindliche und freundliche  Aktivit�ten in deiner N�he zu erkennen.
* Nette graphische Benutzerschnittstelle
* Verteiltes Suchen - andere Leute halten Ausschau nach deinen KoS-Zielen und melden dir die Position dieser, wenn sie sie finden.
* Ein Knopf f�r die Minimap
* Import von 'Ultimate Book of the Dead' KoS Daten
* Import von 'Opium' KoS Daten
* Kann sich selbst als zus�tzlichen Reiter in das "Freunde"-Fenster integrieren
* Eintr�ge an Leute in der Gruppe versenden
* Automatische Synchronisation mit Leuten auf deiner Freunde- und Gildenliste, Manuelle Synchronisation mit jedem.

Befehle:
/kos und /vanaskos geben einen �berblick �ber die Verf�gbaren Befehle

Zus�tzlich gibt es /kadd:

Mit Ziel:
/kadd - fragt nach Grund

Ohne Ziel:
/kadd - fragt nach Name und Grund

Immer:
/kadd <player> - fragt nach Grund
/kadd <player> <reason> - f�gt <player> mit <reason> hinzu.


Funktionen die eine weitere Erkl�rung ben�tigen:

Minimap Knopf:
Linksklick um ein Menu zu �ffnen, Rechtsklick ist wie die Eingabe von /kadd

Verteiltes Suchen:
Alle 10 Minuten werden die Namen auf deienr KoS-Liste ver�ffentlicht in deiner Gilde und Zone, wenn ein anderer Spieler in der Gilde/Zone nun eines von deinen KoS-Zielen findet, benachrichtigt es (ohne es dem Finder zu melden) dich mit der aktuellen Position des Ziels und du kannst den anderen Spieler jagen.
Wenn du 'Cartographer' installiert hast, wirst du automatisch gefragt, ob du eine MapNote mit Wegpunkt zu dem Standort des Spielers generieren m�chtest.



credits:
Ace2, Parser-3.0, Babble-Zone-2.2, Dewdrop-2.0, DeuceLog, Tourist-2.0