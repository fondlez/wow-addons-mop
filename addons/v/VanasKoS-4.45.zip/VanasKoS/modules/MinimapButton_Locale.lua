﻿--[[----------------------------------------------------------------------
      MinimapButton Module - Part of VanasKoS
Creates a MinimapButton with a menu for VanasKoS
------------------------------------------------------------------------]]

local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "enUS", true)
if L then
	L["Add Attacker to KoS"] = true
	L["Add Guild to KoS"] = true
	L["Add Player to Hatelist"] = true
	L["Add Player to KoS"] = true
	L["Add Player to Nicelist"] = true
	L["Angle"] = true
	L["Configuration"] = true
	L["Distance"] = true
	L["Last Attackers"] = true
	L["Locked"] = true
	L["Main Window"] = true
	L["Minimap Button"] = true
	L["Nearby People"] = true
	L["Reset Position"] = true
	L["Reverse action of left/right mouse buttons"] = true
	L["Reverse Buttons"] = true
	L["%s ago"] = true
	L["Show information"] = true
	L["Show Warning Frame Infos as Text and Tooltip"] = true
	L["Warning Window"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "frFR")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "Ajouter un attaquant en KoS"
L["Add Guild to KoS"] = "Ajouter une guilde KoS"
L["Add Player to Hatelist"] = "Ajouter un joueur à la liste noire"
L["Add Player to KoS"] = "Ajouter un joueur KoS"
L["Add Player to Nicelist"] = "Ajouter un joueur à la liste blanche"
L["Angle"] = "Angle" -- Needs review
L["Configuration"] = "Configuration" -- Needs review
L["Distance"] = "Distance" -- Needs review
L["Last Attackers"] = "Derniers attaquants"
L["Locked"] = "Verrouillé"
L["Main Window"] = "Fenêtre principale"
L["Minimap Button"] = "Bouton Minicarte"
L["Nearby People"] = "Personnes voisines"
L["Reset Position"] = "Remettre à zéro la position"
L["Reverse action of left/right mouse buttons"] = "Inverser l'action des boutons gauche / droit de la souris" -- Needs review
L["Reverse Buttons"] = "Inverser boutons" -- Needs review
L["%s ago"] = "Il y'a %s"
L["Show information"] = "Afficher des informations" -- Needs review
L["Show Warning Frame Infos as Text and Tooltip"] = "Afficher les infos de la fenêtre d'avertissement"
L["Warning Window"] = "Fenêtre d'avertissement"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "deDE")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "Angreifer zur KoS-Liste hinzufügen"
L["Add Guild to KoS"] = "Gilde zur KoS-Liste hinzufügen"
L["Add Player to Hatelist"] = "Spieler zur Hassliste hinzufügen"
L["Add Player to KoS"] = "Spieler zur KoS-Liste hinzufügen"
L["Add Player to Nicelist"] = "Spieler zur Nette-Leute-Liste hinzufügen"
L["Angle"] = "Winkel"
L["Configuration"] = "Konfiguration"
L["Distance"] = "Entfernung"
L["Last Attackers"] = "Letzte Angreifer"
L["Locked"] = "Versperrt"
L["Main Window"] = "Hauptfenster"
L["Minimap Button"] = "Minikarten-Schaltfläche"
L["Nearby People"] = "Nahe Spieler"
L["Reset Position"] = "Position zurücksetzen"
L["Reverse action of left/right mouse buttons"] = "Tauschen der linken/rechten Maustastenaktion auf der Minikarten-Schaltfläche"
L["Reverse Buttons"] = "Tauschen der linken/rechten Maustastenaktion auf der Minikarten-Schaltfläche"
L["%s ago"] = "%s her"
L["Show information"] = "Informationen anzeigen"
L["Show Warning Frame Infos as Text and Tooltip"] = "Warn-Fenster Infos als Text und Tooltip anzeigen"
L["Warning Window"] = "Warnfenster"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "koKR")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "KoS에 공격자 추가"
L["Add Guild to KoS"] = "KoS에 길드 추가"
L["Add Player to Hatelist"] = "악인명부에 플레이어 추가"
L["Add Player to KoS"] = "KoS에 플레이어 추가"
L["Add Player to Nicelist"] = "호인명부에 플레이어 추가"
-- L["Angle"] = ""
-- L["Configuration"] = ""
-- L["Distance"] = ""
L["Last Attackers"] = "마지막 공격자"
L["Locked"] = "고정"
L["Main Window"] = "메인창"
L["Minimap Button"] = "미니맵 버튼"
L["Nearby People"] = "근처에 있는 사람"
L["Reset Position"] = "위치 초기화"
-- L["Reverse action of left/right mouse buttons"] = ""
-- L["Reverse Buttons"] = ""
L["%s ago"] = "%s 이전"
-- L["Show information"] = ""
L["Show Warning Frame Infos as Text and Tooltip"] = "텍스트와 툴팁으로 경고창 정보 표시"
L["Warning Window"] = "경고창"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Add Attacker to KoS"] = ""
-- L["Add Guild to KoS"] = ""
-- L["Add Player to Hatelist"] = ""
-- L["Add Player to KoS"] = ""
-- L["Add Player to Nicelist"] = ""
-- L["Angle"] = ""
-- L["Configuration"] = ""
-- L["Distance"] = ""
-- L["Last Attackers"] = ""
-- L["Locked"] = ""
-- L["Main Window"] = ""
-- L["Minimap Button"] = ""
-- L["Nearby People"] = ""
-- L["Reset Position"] = ""
-- L["Reverse action of left/right mouse buttons"] = ""
-- L["Reverse Buttons"] = ""
-- L["%s ago"] = ""
-- L["Show information"] = ""
-- L["Show Warning Frame Infos as Text and Tooltip"] = ""
-- L["Warning Window"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "ruRU")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "Добавить атакующего в KoS"
L["Add Guild to KoS"] = "Добавить гильдию в KoS"
L["Add Player to Hatelist"] = "Добавить игрока в Ненавистных"
L["Add Player to KoS"] = "Добавить игрока в KoS"
L["Add Player to Nicelist"] = "Добавить игрока в Хороших"
L["Angle"] = "Угол"
L["Configuration"] = "Конфигурация"
L["Distance"] = "Расстояние"
L["Last Attackers"] = "Последние напавшие"
L["Locked"] = "Зафиксировать"
L["Main Window"] = "Главное окно"
L["Minimap Button"] = "Кнопка на миникарте"
L["Nearby People"] = "Ближайшие игроки"
L["Reset Position"] = "Сбросить расположение"
L["Reverse action of left/right mouse buttons"] = "Изменить действия левой/правой кнопок мыши" -- Needs review
L["Reverse Buttons"] = "Изменить кнопки" -- Needs review
L["%s ago"] = "%s назад"
L["Show information"] = "Показать информацию"
L["Show Warning Frame Infos as Text and Tooltip"] = "Показывать KoS/Врагов/Друзей на панели FuBar"
L["Warning Window"] = "Окно предупреждений"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "zhCN")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "添加攻击者到仇敌"
L["Add Guild to KoS"] = "添加公会到仇敌"
L["Add Player to Hatelist"] = "添加玩家到仇恨列表"
L["Add Player to KoS"] = "添加玩家到仇敌"
L["Add Player to Nicelist"] = "添加玩家到友好列表"
L["Angle"] = "角度"
L["Configuration"] = "配置"
L["Distance"] = "距离"
L["Last Attackers"] = "最后攻击者"
L["Locked"] = "已锁定"
L["Main Window"] = "主窗口"
L["Minimap Button"] = "小地图按钮"
L["Nearby People"] = "周围玩家"
L["Reset Position"] = "重置位置"
L["Reverse action of left/right mouse buttons"] = "反转鼠标左/右按钮动作"
L["Reverse Buttons"] = "反转按钮"
L["%s ago"] = "%s之前"
L["Show information"] = "显示信息"
L["Show Warning Frame Infos as Text and Tooltip"] = "显示文本和提示警报框体信息"
L["Warning Window"] = "警报窗口"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "esES")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "Añadir Atacante a KoS"
L["Add Guild to KoS"] = "Añadir Hermandad a KoS"
L["Add Player to Hatelist"] = "Añadir Jugador a Odiados"
L["Add Player to KoS"] = "Añadir Jugador a KoS"
L["Add Player to Nicelist"] = "Añadir Jugador a Simpáticos"
-- L["Angle"] = ""
-- L["Configuration"] = ""
-- L["Distance"] = ""
-- L["Last Attackers"] = ""
L["Locked"] = "Bloqueado"
L["Main Window"] = "Ventana Principal"
L["Minimap Button"] = "Botón del Minimapa"
-- L["Nearby People"] = ""
L["Reset Position"] = "Reestablecer Posición"
-- L["Reverse action of left/right mouse buttons"] = ""
-- L["Reverse Buttons"] = ""
-- L["%s ago"] = ""
-- L["Show information"] = ""
-- L["Show Warning Frame Infos as Text and Tooltip"] = ""
L["Warning Window"] = "Ventana de Aviso"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/MinimapButton", "zhTW")
if L then
-- auto generated from wowace translation app
L["Add Attacker to KoS"] = "增加攻擊者到仇敵"
L["Add Guild to KoS"] = "增加公會到仇敵"
L["Add Player to Hatelist"] = "增加玩家到討厭列表"
L["Add Player to KoS"] = "增加玩家到仇敵"
L["Add Player to Nicelist"] = "增加玩家到好人列表"
-- L["Angle"] = ""
-- L["Configuration"] = ""
-- L["Distance"] = ""
L["Last Attackers"] = "最後出現" -- Needs review
L["Locked"] = "鎖定" -- Needs review
L["Main Window"] = "主視窗" -- Needs review
L["Minimap Button"] = "小地圖按鈕" -- Needs review
L["Nearby People"] = "周圍的玩家" -- Needs review
L["Reset Position"] = "重置位置" -- Needs review
-- L["Reverse action of left/right mouse buttons"] = ""
-- L["Reverse Buttons"] = ""
-- L["%s ago"] = ""
-- L["Show information"] = ""
-- L["Show Warning Frame Infos as Text and Tooltip"] = ""
-- L["Warning Window"] = ""

end
