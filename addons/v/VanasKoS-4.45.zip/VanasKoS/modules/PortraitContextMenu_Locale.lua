﻿--[[----------------------------------------------------------------------
	TargetPortraitContextMenu Module - Part of VanasKoS
modifies the TargetPortrait to add context menu options for adding targets to lists
------------------------------------------------------------------------]]

local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "enUS", true)
if L then
	L["Add to %s"] = true
	L["Context Menu"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "frFR")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "Ajouter - %s"
L["Context Menu"] = "Menu contextuel" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "deDE")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "Zu %s hinzufügen"
L["Context Menu"] = "Kontextmenü"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "koKR")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "%s에 추가"
-- L["Context Menu"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Add to %s"] = ""
-- L["Context Menu"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "ruRU")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "Добавить в %s"
L["Context Menu"] = "Контекстное меню"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "zhCN")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "添加到%s"
L["Context Menu"] = "菜单"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "esES")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "Añadir a %s"
-- L["Context Menu"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PortraitContextMenu", "zhTW")
if L then
-- auto generated from wowace translation app
L["Add to %s"] = "增加到 %s"
-- L["Context Menu"] = ""

end
