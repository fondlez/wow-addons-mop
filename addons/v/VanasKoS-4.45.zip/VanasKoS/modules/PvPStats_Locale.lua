﻿--[[----------------------------------------------------------------------
      PvPStats Module - Part of VanasKoS
Displays Stats about PvP in a window
------------------------------------------------------------------------]]

local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "enUS", true)
if L then
	L["All Characters (Realm)"] = true
	L["All Time"] = true
	L["Last 24 hours"] = true
	L["Last Month"] = true
	L["Last Week"] = true
	L["Losses: |cffff0000%d|r (%.1f%%)"] = true
	L["PvP Stats"] = true
	L["Wins: |cff00ff00%d|r (%.1f%%)"] = true
	L["Enemies"] = true
	L["Map"] = true
	L["Date"] = true
	L["Total"] = true
	L["Average Level"] = true

	L["Lost"] = true
	L["Score"] = true
	L["PvP Data Gathering"] = true
	L["PvP Stats"] = true
	L["by losses"] = true
	L["sort by most losses"] = true
	L["by encounters"] = true
	L["sort by most PVP encounters"] = true
	L["by wins"] = true
	L["sort by most wins"] = true
	L["by score"] = true
	L["sort by most wins to losses"] = true
	L["by name"] = true
	L["sort by name"] = true

	L["Players"] = true
	L["Enemy level"] = true
	L["My level"] = true
	L["Level difference"] = true

	L["Add to Player KoS"] = true
	L["Add to Hatelist"] = true
	L["Add to Nicelist"] = true
	L["Remove Entry"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "frFR")
if L then
-- auto generated from wowace translation app
-- L["Add to Hatelist"] = ""
-- L["Add to Nicelist"] = ""
-- L["Add to Player KoS"] = ""
L["All Characters (Realm)"] = "Tous les caractères (Realm)" -- Needs review
L["All Time"] = "Tous Les Temps" -- Needs review
L["Average Level"] = "Niveau moyen" -- Needs review
L["by encounters"] = "par des rencontres" -- Needs review
L["by losses"] = "par des pertes" -- Needs review
L["by name"] = "par nom" -- Needs review
L["by score"] = "par score" -- Needs review
L["by wins"] = "par gagne" -- Needs review
L["Date"] = "Date" -- Needs review
L["Enemies"] = "Ennemis" -- Needs review
L["Enemy level"] = "niveau Enemy" -- Needs review
L["Last 24 hours"] = "Dernières 24 heures" -- Needs review
L["Last Month"] = "Le mois dernier" -- Needs review
L["Last Week"] = "La semaine dernière" -- Needs review
L["Level difference"] = "différence de niveau" -- Needs review
L["Losses: |cffff0000%d|r (%.1f%%)"] = "Pertes: |cffff0000%d|r (%.1f%%)" -- Needs review
L["Lost"] = "Perdu" -- Needs review
L["Map"] = "Carte" -- Needs review
L["My level"] = "Mon niveau" -- Needs review
L["Players"] = "Joueurs" -- Needs review
L["PvP Data Gathering"] = "Collecte de données PvP" -- Needs review
L["PvP Stats"] = "Stats PvP" -- Needs review
-- L["Remove Entry"] = ""
L["Score"] = "Score" -- Needs review
L["sort by most losses"] = "trier par la plupart des pertes" -- Needs review
L["sort by most PVP encounters"] = "trier par des rencontres les plus PVP" -- Needs review
L["sort by most wins"] = "trier par plus de victoires" -- Needs review
L["sort by most wins to losses"] = "trier par plus de victoires à des pertes" -- Needs review
L["sort by name"] = "trier par nom" -- Needs review
L["Total"] = "Total" -- Needs review
L["Wins: |cff00ff00%d|r (%.1f%%)"] = "Victoires: |cff00ff00%d|r (%.1f%%)" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "deDE")
if L then
-- auto generated from wowace translation app
L["Add to Hatelist"] = "Zur Hassliste hinzufügen" -- Needs review
L["Add to Nicelist"] = "Zur Nettliste hinzufügen" -- Needs review
L["Add to Player KoS"] = "Zur Spieler-KoS-Liste hinzufügen" -- Needs review
L["All Characters (Realm)"] = "Alle Charaktere (Realm)"
L["All Time"] = "Komplette Zeit"
L["Average Level"] = "Durchschnittliche Stufe"
L["by encounters"] = "nach Gefechten"
L["by losses"] = "nach Niederlagen"
L["by name"] = "nach Namen"
L["by score"] = "nach Wertung"
L["by wins"] = "nach Siegen"
L["Date"] = "Datum"
L["Enemies"] = "Feinde"
L["Enemy level"] = "Stufe des Feindes"
L["Last 24 hours"] = "die letzten 24 Stunden"
L["Last Month"] = "letzten Monat"
L["Last Week"] = "letzte Woche"
L["Level difference"] = "Stufenunterschied"
L["Losses: |cffff0000%d|r (%.1f%%)"] = "Niederlagen: |cffff0000%d|r (%.1f%%)"
L["Lost"] = "Niederlage"
L["Map"] = "Karte"
L["My level"] = "Meine Stufe"
L["Players"] = "Spieler"
L["PvP Data Gathering"] = "PvP-Datensammlung"
L["PvP Stats"] = "PvP-Stats"
L["Remove Entry"] = "Eintrag löschen" -- Needs review
L["Score"] = "Wertung"
L["sort by most losses"] = "Sortieren nach den meisten Niederlagen"
L["sort by most PVP encounters"] = "Sortieren nach den meisten PVP-Gefechten"
L["sort by most wins"] = "Sortieren nach den meisten Siegen"
L["sort by most wins to losses"] = "Sortieren nach den meisten Siegen bis Niedelagen"
L["sort by name"] = "Nach Namen sortieren"
L["Total"] = "Insgesamt"
L["Wins: |cff00ff00%d|r (%.1f%%)"] = "Siege: |cff00ff00%d|r (%.1f%%)"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "koKR")
if L then
-- auto generated from wowace translation app
-- L["Add to Hatelist"] = ""
-- L["Add to Nicelist"] = ""
-- L["Add to Player KoS"] = ""
L["All Characters (Realm)"] = "모든 케릭터 (서버)"
L["All Time"] = "모든 시간"
-- L["Average Level"] = ""
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Date"] = ""
-- L["Enemies"] = ""
-- L["Enemy level"] = ""
L["Last 24 hours"] = "마지막 24 시간"
L["Last Month"] = "마지막 월"
L["Last Week"] = "마지막 주"
-- L["Level difference"] = ""
L["Losses: |cffff0000%d|r (%.1f%%)"] = "패: |cffff0000%d|r (%.1f%%)" -- Needs review
-- L["Lost"] = ""
-- L["Map"] = ""
-- L["My level"] = ""
-- L["Players"] = ""
-- L["PvP Data Gathering"] = ""
L["PvP Stats"] = "PvP 현황"
-- L["Remove Entry"] = ""
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
-- L["Total"] = ""
L["Wins: |cff00ff00%d|r (%.1f%%)"] = "승: |cff00ff00%d|r (%.1f%%)" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Add to Hatelist"] = ""
-- L["Add to Nicelist"] = ""
-- L["Add to Player KoS"] = ""
-- L["All Characters (Realm)"] = ""
-- L["All Time"] = ""
-- L["Average Level"] = ""
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Date"] = ""
-- L["Enemies"] = ""
-- L["Enemy level"] = ""
-- L["Last 24 hours"] = ""
-- L["Last Month"] = ""
-- L["Last Week"] = ""
-- L["Level difference"] = ""
-- L["Losses: |cffff0000%d|r (%.1f%%)"] = ""
-- L["Lost"] = ""
-- L["Map"] = ""
-- L["My level"] = ""
-- L["Players"] = ""
-- L["PvP Data Gathering"] = ""
-- L["PvP Stats"] = ""
-- L["Remove Entry"] = ""
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
-- L["Total"] = ""
-- L["Wins: |cff00ff00%d|r (%.1f%%)"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "ruRU")
if L then
-- auto generated from wowace translation app
-- L["Add to Hatelist"] = ""
-- L["Add to Nicelist"] = ""
L["Add to Player KoS"] = "Добавить игрока в KoS"
L["All Characters (Realm)"] = "Все персонажи (мир)"
L["All Time"] = "Все время"
L["Average Level"] = "Средний уровень"
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
L["Date"] = "Дата"
L["Enemies"] = "Противники"
L["Enemy level"] = "Уровень противника"
L["Last 24 hours"] = "Последние 24 часа"
L["Last Month"] = "Последний месяц"
L["Last Week"] = "Последняя неделя"
L["Level difference"] = "Разница в уровне"
L["Losses: |cffff0000%d|r (%.1f%%)"] = "Поражений: |cffff0000%d|r (%.1f%%)"
-- L["Lost"] = ""
L["Map"] = "Карта"
L["My level"] = "Мой уровень"
L["Players"] = "Игроки"
-- L["PvP Data Gathering"] = ""
L["PvP Stats"] = "Статистика PvP"
-- L["Remove Entry"] = ""
-- L["Score"] = ""
L["sort by most losses"] = "сортировать по большинству поражений"
L["sort by most PVP encounters"] = "сортировать по большему количеству PvP событий"
L["sort by most wins"] = "сортировать по большинству побед"
L["sort by most wins to losses"] = "сортировать по лучшему отношению побед к поражениям"
L["sort by name"] = "сортировать по имени"
-- L["Total"] = ""
L["Wins: |cff00ff00%d|r (%.1f%%)"] = "Побед: |cff00ff00%d|r (%.1f%%)"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "zhCN")
if L then
-- auto generated from wowace translation app
L["Add to Hatelist"] = "添加到仇恨列表"
L["Add to Nicelist"] = "添加到友好列表"
L["Add to Player KoS"] = "添加到玩家仇敌"
L["All Characters (Realm)"] = "全部角色（服务器）"
L["All Time"] = "全部时间"
L["Average Level"] = "平均等级"
L["by encounters"] = "按战斗"
L["by losses"] = "按失败"
L["by name"] = "按名称"
L["by score"] = "按分数"
L["by wins"] = "按胜利"
L["Date"] = "日期"
L["Enemies"] = "敌人"
L["Enemy level"] = "敌对等级"
L["Last 24 hours"] = "最后24小时"
L["Last Month"] = "上个月"
L["Last Week"] = "上星期"
L["Level difference"] = "等级差异"
L["Losses: |cffff0000%d|r (%.1f%%)"] = "失败：|cffff0000%d|r（%.1f%%）"
L["Lost"] = "失败"
L["Map"] = "地图"
L["My level"] = "我的等级"
L["Players"] = "玩家"
L["PvP Data Gathering"] = "PvP 数据收集"
L["PvP Stats"] = "PvP 状态"
L["Remove Entry"] = "移除条目"
L["Score"] = "分数"
L["sort by most losses"] = "按最多失败排序"
L["sort by most PVP encounters"] = "按最多 PvP 战斗排序"
L["sort by most wins"] = "按最多胜利排序"
L["sort by most wins to losses"] = "按最多胜利到失败排序"
L["sort by name"] = "按名称排序"
L["Total"] = "总共"
L["Wins: |cff00ff00%d|r (%.1f%%)"] = "胜利：|cff00ff00%d|r（%.1f%%）"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "esES")
if L then
-- auto generated from wowace translation app
-- L["Add to Hatelist"] = ""
-- L["Add to Nicelist"] = ""
-- L["Add to Player KoS"] = ""
-- L["All Characters (Realm)"] = ""
-- L["All Time"] = ""
-- L["Average Level"] = ""
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Date"] = ""
-- L["Enemies"] = ""
-- L["Enemy level"] = ""
-- L["Last 24 hours"] = ""
-- L["Last Month"] = ""
-- L["Last Week"] = ""
-- L["Level difference"] = ""
-- L["Losses: |cffff0000%d|r (%.1f%%)"] = ""
-- L["Lost"] = ""
-- L["Map"] = ""
-- L["My level"] = ""
-- L["Players"] = ""
-- L["PvP Data Gathering"] = ""
-- L["PvP Stats"] = ""
-- L["Remove Entry"] = ""
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
-- L["Total"] = ""
-- L["Wins: |cff00ff00%d|r (%.1f%%)"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPStats", "zhTW")
if L then
-- auto generated from wowace translation app
-- L["Add to Hatelist"] = ""
-- L["Add to Nicelist"] = ""
-- L["Add to Player KoS"] = ""
-- L["All Characters (Realm)"] = ""
-- L["All Time"] = ""
-- L["Average Level"] = ""
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Date"] = ""
-- L["Enemies"] = ""
-- L["Enemy level"] = ""
-- L["Last 24 hours"] = ""
-- L["Last Month"] = ""
-- L["Last Week"] = ""
-- L["Level difference"] = ""
-- L["Losses: |cffff0000%d|r (%.1f%%)"] = ""
-- L["Lost"] = ""
-- L["Map"] = ""
-- L["My level"] = ""
-- L["Players"] = ""
-- L["PvP Data Gathering"] = ""
-- L["PvP Stats"] = ""
-- L["Remove Entry"] = ""
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
L["sort by name"] = "按名稱排序" -- Needs review
-- L["Total"] = ""
-- L["Wins: |cff00ff00%d|r (%.1f%%)"] = ""

end
