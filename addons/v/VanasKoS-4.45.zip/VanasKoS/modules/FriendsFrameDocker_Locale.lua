﻿local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "enUS", true)
if L then
	L["Dock into Friends Frame"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "frFR")
if L then
-- auto generated from wowace translation app
L["Dock into Friends Frame"] = "Onglet dans la liste d'amis"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "deDE")
if L then
-- auto generated from wowace translation app
L["Dock into Friends Frame"] = "In das Freunde-Fenster einbinden"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "koKR")
if L then
-- auto generated from wowace translation app
L["Dock into Friends Frame"] = "친구목록에 적용"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Dock into Friends Frame"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "ruRU")
if L then
-- auto generated from wowace translation app
L["Dock into Friends Frame"] = "Прикрепить к окну Друзей"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "zhCN")
if L then
-- auto generated from wowace translation app
L["Dock into Friends Frame"] = "与好友框体对接"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "esES")
if L then
-- auto generated from wowace translation app
L["Dock into Friends Frame"] = "Acoplar a la ventana de Amigos"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/FriendsFrameDocker", "zhTW")
if L then
-- auto generated from wowace translation app
-- L["Dock into Friends Frame"] = ""

end
