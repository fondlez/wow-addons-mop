﻿--[[---------------------------------------------------------------------------------------------
      PvPDataGatherer Module - Part of VanasKoS
Gathers PvP Wins and Losses
---------------------------------------------------------------------------------------------]]

local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "enUS", true)
if L then
	L["Lost"] = true
	L["Score"] = true
	L["PvP Data Gathering"] = true
	L["PvP Loss versus %s registered."] = true
	L["PvP Stats"] = true
	L["PvP Win versus %s registered."] = true
	L["by losses"] = true
	L["sort by most losses"] = true
	L["by encounters"] = true
	L["sort by most PVP encounters"] = true
	L["by wins"] = true
	L["sort by most wins"] = true
	L["by score"] = true
	L["sort by most wins to losses"] = true
	L["by name"] = true
	L["sort by name"] = true
	L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = true
	L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "frFR")
if L then
-- auto generated from wowace translation app
L["by encounters"] = "par des rencontres" -- Needs review
L["by losses"] = "par des pertes" -- Needs review
L["by name"] = "par des nom" -- Needs review
L["by score"] = "par des score" -- Needs review
L["by wins"] = "par gagne" -- Needs review
L["Lost"] = "Perdu" -- Needs review
L["Name"] = "Nom" -- Needs review
L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = "statistiques PvP Old détecté. Vous devez importer des données anciennes en allant à l'importateur en vertu VanasKoS configuration" -- Needs review
L["PvP"] = "PvP" -- Needs review
L["PvP Data Gathering"] = "Rassemblement de données PvP"
L["PvP Loss versus %s registered."] = "PvP pertes par rapport aux %s enregistré." -- Needs review
L["PvP Stats"] = "PvP Stats"
L["PvP Win versus %s registered."] = "PvP Win versus %s enregistré." -- Needs review
L["Score"] = "Score" -- Needs review
L["sort by most losses"] = "Trier par la plupart des pertes" -- Needs review
L["sort by most PVP encounters"] = "Trier par des rencontres les plus PVP" -- Needs review
L["sort by most wins"] = "Trier par plus de victoires" -- Needs review
L["sort by most wins to losses"] = "Trier par plus de victoires à des pertes" -- Needs review
L["sort by name"] = "Trier par nom" -- Needs review
L["Win"] = "Gagner" -- Needs review
L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = "victoires: |cff00ff00%d|r défaites: |cffff0000%d|r" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "deDE")
if L then
-- auto generated from wowace translation app
L["by encounters"] = "nach Gefechten"
L["by losses"] = "nach Niederlagen"
L["by name"] = "nach Namen"
L["by score"] = "nach Ergebnissen"
L["by wins"] = "Nach Siegen"
L["Lost"] = "Verloren"
L["Name"] = "Name"
L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = "Alte PvP-Statistiken entdeckt. Du solltest die alten Daten importieren, indem du das Import-Modul in der VanasKoS-Konfiguration verwendest."
L["PvP"] = "PvP"
L["PvP Data Gathering"] = "PvP-Daten sammeln"
L["PvP Loss versus %s registered."] = "PvP-Niederlage gegen %s registriert."
L["PvP Stats"] = "PvP-Statistik"
L["PvP Win versus %s registered."] = "PvP-Sieg gegen %s registriert."
L["Score"] = "Wertung"
L["sort by most losses"] = "sortiere nach den meisten Niederlagen"
L["sort by most PVP encounters"] = "sortiere nach den meisten PvP-Gefechten"
L["sort by most wins"] = "sortiere nach den meisten Siegen"
L["sort by most wins to losses"] = "sortiere nach den meisten Siegen gegenüber Niederlagen"
L["sort by name"] = "sortiere nach Namen"
L["Win"] = "Sieg"
L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = "Siege: |cff00ff00%d|r Niederlagen: |cffff0000%d|r"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "koKR")
if L then
-- auto generated from wowace translation app
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Lost"] = ""
-- L["Name"] = ""
-- L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = ""
-- L["PvP"] = ""
L["PvP Data Gathering"] = "PvP 데이터 수집"
L["PvP Loss versus %s registered."] = "%s에 대한 PvP 패배가 기록되었습니다."
L["PvP Stats"] = "PvP 현황"
L["PvP Win versus %s registered."] = "%s에 대한 PvP 승리가 기록되었습니다."
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
-- L["Win"] = ""
L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = "승: |cff00ff00%d|r 패: |cffff0000%d|r" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "esMX")
if L then
-- auto generated from wowace translation app
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Lost"] = ""
-- L["Name"] = ""
-- L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = ""
-- L["PvP"] = ""
-- L["PvP Data Gathering"] = ""
-- L["PvP Loss versus %s registered."] = ""
-- L["PvP Stats"] = ""
-- L["PvP Win versus %s registered."] = ""
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
-- L["Win"] = ""
-- L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "ruRU")
if L then
-- auto generated from wowace translation app
L["by encounters"] = "по событиям"
L["by losses"] = "по проигрышам"
L["by name"] = "по имени"
L["by score"] = "по очкам"
L["by wins"] = "по победам"
L["Lost"] = "Потерянный"
L["Name"] = "Название"
-- L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = ""
L["PvP"] = "PvP"
L["PvP Data Gathering"] = "Сбор PvP-статистики"
L["PvP Loss versus %s registered."] = "PvP поражений от %s."
L["PvP Stats"] = "Статистика PvP "
L["PvP Win versus %s registered."] = "PvP побед над %s."
L["Score"] = "Счет"
L["sort by most losses"] = "сортировать по большинству поражений"
L["sort by most PVP encounters"] = "сортировать по большинству PvP событий"
L["sort by most wins"] = "сортировать по большинству побед"
L["sort by most wins to losses"] = "сортировать по лучшему отношению побед к поражениям"
L["sort by name"] = "сортировать по имени"
L["Win"] = "Победа"
L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = "побед: |cff00ff00%d|r поражений: |cffff0000%d|r"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "zhCN")
if L then
-- auto generated from wowace translation app
L["by encounters"] = "按战斗"
L["by losses"] = "按失败"
L["by name"] = "按名称"
L["by score"] = "按分数"
L["by wins"] = "按胜利"
L["Lost"] = "失败"
L["Name"] = "名称"
L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = "侦测到旧的 PvP 状态。应去 VanasKoS 导入功能配置导入旧数据"
L["PvP"] = "PvP"
L["PvP Data Gathering"] = "PvP 数据收集"
L["PvP Loss versus %s registered."] = "已注册 PvP 失败交战%s。"
L["PvP Stats"] = "PvP 状态"
L["PvP Win versus %s registered."] = "已注册 PvP 胜利交战%s。"
L["Score"] = "分数"
L["sort by most losses"] = "按最多失败排序"
L["sort by most PVP encounters"] = "按最多 PvP 战斗排序"
L["sort by most wins"] = "按最多胜利排序"
L["sort by most wins to losses"] = "按最多胜利到失败排序"
L["sort by name"] = "按名称排序"
L["Win"] = "胜利"
L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = "胜利：|cff00ff00%d|r - 失败：|cffff0000%d|r"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "esES")
if L then
-- auto generated from wowace translation app
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
-- L["Lost"] = ""
-- L["Name"] = ""
-- L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = ""
-- L["PvP"] = ""
L["PvP Data Gathering"] = "Recolección de Datos JcJ"
-- L["PvP Loss versus %s registered."] = ""
L["PvP Stats"] = "Estadísticas JcJ"
-- L["PvP Win versus %s registered."] = ""
-- L["Score"] = ""
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
-- L["Win"] = ""
L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = "ganados: |cff00ff00%d|r perdidos: |cffff0000%d|r"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/PvPDataGatherer", "zhTW")
if L then
-- auto generated from wowace translation app
-- L["by encounters"] = ""
-- L["by losses"] = ""
-- L["by name"] = ""
-- L["by score"] = ""
-- L["by wins"] = ""
L["Lost"] = "輸了"
L["Name"] = "名字"
-- L["Old pvp statistics detected. You should import old data by going to importer under VanasKoS configuration"] = ""
L["PvP"] = "PvP"
-- L["PvP Data Gathering"] = ""
-- L["PvP Loss versus %s registered."] = ""
-- L["PvP Stats"] = ""
-- L["PvP Win versus %s registered."] = ""
L["Score"] = "分數"
-- L["sort by most losses"] = ""
-- L["sort by most PVP encounters"] = ""
-- L["sort by most wins"] = ""
-- L["sort by most wins to losses"] = ""
-- L["sort by name"] = ""
L["Win"] = "勝利"
-- L["wins: |cff00ff00%d|r - losses: |cffff0000%d|r"] = ""

end
