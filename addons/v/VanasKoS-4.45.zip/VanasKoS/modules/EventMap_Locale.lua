﻿--[[----------------------------------------------------------------------
      EventMap Module - Part of VanasKoS
Displays PvP Events on World Map
------------------------------------------------------------------------]]

local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "enUS", true)
if L then
	L["|cffff0000%s - %s killed by %s|r"] = true
	L["|cff00ff00%s - %s killed %s|r"] = true
	L["Colored dots"] = true
	L["Dot Options"] = true
	L["Draw Alts"] = true
	L["Drawing mode"] = true
	L["Draws PvP events on map for all characters"] = true
	L["Dynamic Zoom"] = true
	L["Icon Options"] = true
	L["Icons"] = true
	L["PvP Encounter"] = true
	L["PvP Event Map"] = true
	L["Redraws icons based on Cartographer3 zoom level"] = true
	L["Reset"] = true
	L["Reset dots to default"] = true
	L["Sets the loss color and opacity"] = true
	L["Sets the win color and opacity"] = true
	L["Show tooltips when hovering over PvP events"] = true
	L["Size"] = true
	L["Size of dots"] = true
	L["Toggle showing individual icons or simple dots"] = true
	L["Tooltips"] = true
	L["Remove events"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "frFR")
if L then
-- auto generated from wowace translation app
L["|cff00ff00%s - %s killed %s|r"] = "|cff00ff00%s - %s tué %s|r" -- Needs review
L["|cffff0000%s - %s killed by %s|r"] = "|cffff0000%s -%s tué par %s|r" -- Needs review
L["Colored dots"] = "points de couleur" -- Needs review
L["Dot Options"] = "Options Dot" -- Needs review
L["Draw Alts"] = "Dessiner Alts" -- Needs review
L["Drawing mode"] = "Dessin mode" -- Needs review
L["Draws PvP events on map for all characters"] = "Dessine événements PvP sur la carte pour tous les caractères" -- Needs review
L["Dynamic Zoom"] = " Zoom dynamique" -- Needs review
L["Icon Options"] = "Icône Options" -- Needs review
L["Icons"] = "Icônes" -- Needs review
L["PvP Encounter"] = "Rencontre PvP" -- Needs review
L["PvP Event Map"] = "Carte de l'événement PvP" -- Needs review
L["Redraws icons based on Cartographer3 zoom level"] = "Redessine icônes basées sur zoom Cartographer3 niveau" -- Needs review
L["Reset"] = "Remise" -- Needs review
L["Reset dots to default"] = "Reset points par défaut" -- Needs review
L["Sets the loss color and opacity"] = "Définit la couleur de la perte et l'opacité" -- Needs review
L["Sets the win color and opacity"] = "Définit la couleur et l'opacité gagner" -- Needs review
L["Show tooltips when hovering over PvP events"] = " Afficher les bulles lors du survol des événements PvP" -- Needs review
L["Size"] = "Taille" -- Needs review
L["Size of dots"] = "Taille de points" -- Needs review
L["Toggle showing individual icons or simple dots"] = "Toggle montrant icônes ou de simples points" -- Needs review
L["Tooltips"] = "Les info-bulles" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "deDE")
if L then
-- auto generated from wowace translation app
L["|cff00ff00%s - %s killed %s|r"] = "|cff00ff00%s: %s tötete %s|r"
L["|cffff0000%s - %s killed by %s|r"] = "|cffff0000%s: %s wurde getötet von %s|r"
L["Colored dots"] = "Gefärbte Punkte"
L["Dot Options"] = "Punkte-Optionen"
L["Draw Alts"] = "Alts aufzeichnen"
L["Drawing mode"] = "Zeichenmodus"
L["Draws PvP events on map for all characters"] = "Zeichnet PvP-Aktionen für alle Charaktere auf der Karte auf"
L["Dynamic Zoom"] = "Dynamischer Zoom"
L["Icon Options"] = "Icon Optionen"
L["Icons"] = "Icons"
L["PvP Encounter"] = "PvP-Kampf"
L["PvP Event Map"] = "PvP-Aktionskarte"
L["Redraws icons based on Cartographer3 zoom level"] = "Zeichnet Icons neu, basierend auf die Zoom-Stufe von Cartographer3"
L["Reset"] = "Zurücksetzen"
L["Reset dots to default"] = "Punkte auf Standard zurücksetzen"
L["Sets the loss color and opacity"] = "Setzt Farbe und Deckkraft bei Niederlage"
L["Sets the win color and opacity"] = "Setzt Farbe und Deckkraft bei Sieg"
L["Show tooltips when hovering over PvP events"] = "Tooltipps anzeigen, wenn die Maus über PvP-Aktionen geführt wird"
L["Size"] = "Größe"
L["Size of dots"] = "Größe der Punkte"
L["Toggle showing individual icons or simple dots"] = "Anzeige individueller Icons oder einfacher Punkte umschalten"
L["Tooltips"] = "Tooltips"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "koKR")
if L then
-- auto generated from wowace translation app
-- L["|cff00ff00%s - %s killed %s|r"] = ""
-- L["|cffff0000%s - %s killed by %s|r"] = ""
-- L["Colored dots"] = ""
-- L["Dot Options"] = ""
-- L["Draw Alts"] = ""
-- L["Drawing mode"] = ""
-- L["Draws PvP events on map for all characters"] = ""
-- L["Dynamic Zoom"] = ""
-- L["Icon Options"] = ""
-- L["Icons"] = ""
-- L["PvP Encounter"] = ""
-- L["PvP Event Map"] = ""
-- L["Redraws icons based on Cartographer3 zoom level"] = ""
-- L["Reset"] = ""
-- L["Reset dots to default"] = ""
-- L["Sets the loss color and opacity"] = ""
-- L["Sets the win color and opacity"] = ""
-- L["Show tooltips when hovering over PvP events"] = ""
-- L["Size"] = ""
-- L["Size of dots"] = ""
-- L["Toggle showing individual icons or simple dots"] = ""
-- L["Tooltips"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "esMX")
if L then
-- auto generated from wowace translation app
-- L["|cff00ff00%s - %s killed %s|r"] = ""
-- L["|cffff0000%s - %s killed by %s|r"] = ""
-- L["Colored dots"] = ""
-- L["Dot Options"] = ""
-- L["Draw Alts"] = ""
-- L["Drawing mode"] = ""
-- L["Draws PvP events on map for all characters"] = ""
-- L["Dynamic Zoom"] = ""
-- L["Icon Options"] = ""
-- L["Icons"] = ""
-- L["PvP Encounter"] = ""
-- L["PvP Event Map"] = ""
-- L["Redraws icons based on Cartographer3 zoom level"] = ""
-- L["Reset"] = ""
-- L["Reset dots to default"] = ""
-- L["Sets the loss color and opacity"] = ""
-- L["Sets the win color and opacity"] = ""
-- L["Show tooltips when hovering over PvP events"] = ""
-- L["Size"] = ""
-- L["Size of dots"] = ""
-- L["Toggle showing individual icons or simple dots"] = ""
-- L["Tooltips"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "ruRU")
if L then
-- auto generated from wowace translation app
L["|cff00ff00%s - %s killed %s|r"] = "|cff00ff00%s - %s убит %s|r"
L["|cffff0000%s - %s killed by %s|r"] = " |cffff0000%s - %s убит %s|r"
L["Colored dots"] = "Цветные точки"
L["Dot Options"] = "Настройки точек" -- Needs review
L["Draw Alts"] = "сделать все альт" -- Needs review
L["Drawing mode"] = "Рисунок режиме" -- Needs review
L["Draws PvP events on map for all characters"] = "Рисует PvP события на карте для всех символов" -- Needs review
L["Dynamic Zoom"] = "Динамические Увеличить" -- Needs review
L["Icon Options"] = "Значок параметры" -- Needs review
L["Icons"] = "Иконы" -- Needs review
L["PvP Encounter"] = "PvP встречи" -- Needs review
L["PvP Event Map"] = "PvP событий Карта" -- Needs review
L["Redraws icons based on Cartographer3 zoom level"] = "Перерисовать иконы на основе Cartographer3 масштаба" -- Needs review
L["Reset"] = "Сброс"
L["Reset dots to default"] = "Сбросить точки по умолчанию"
L["Sets the loss color and opacity"] = "Устанавливает цвет и прозрачность потери" -- Needs review
L["Sets the win color and opacity"] = "Наборы выиграть цвет и прозрачность" -- Needs review
-- L["Show tooltips when hovering over PvP events"] = ""
L["Size"] = "Размер"
L["Size of dots"] = "Размер отметок"
L["Toggle showing individual icons or simple dots"] = "Отображать конкретные иконки или просто отметки."
L["Tooltips"] = "Подсказки"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "zhCN")
if L then
-- auto generated from wowace translation app
L["|cff00ff00%s - %s killed %s|r"] = "|cff00ff00%s - %s杀死%s|r"
L["|cffff0000%s - %s killed by %s|r"] = "|cffff0000%s - %s被%s杀死|r"
L["Colored dots"] = "颜色点"
L["Dot Options"] = "点选项"
L["Draw Alts"] = "绘制亮点"
L["Drawing mode"] = "绘制模式"
L["Draws PvP events on map for all characters"] = "在地图上为全部角色绘制 PvP 事件"
L["Dynamic Zoom"] = "动态缩放"
L["Icon Options"] = "图标选项"
L["Icons"] = "图标"
L["PvP Encounter"] = "PvP 战斗"
L["PvP Event Map"] = "PvP 事件地图"
L["Redraws icons based on Cartographer3 zoom level"] = "基于 Cartographer3 区域等级重绘图标"
L["Reset"] = "重置"
L["Reset dots to default"] = "重置点为默认"
L["Sets the loss color and opacity"] = "设置失败颜色和不透明度"
L["Sets the win color and opacity"] = "设置胜利颜色和不透明度"
L["Show tooltips when hovering over PvP events"] = "悬停 PvP 事件时显示提示"
L["Size"] = "尺寸"
L["Size of dots"] = "点尺寸"
L["Toggle showing individual icons or simple dots"] = "切换显示独立图标或简单点"
L["Tooltips"] = "提示"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "esES")
if L then
-- auto generated from wowace translation app
-- L["|cff00ff00%s - %s killed %s|r"] = ""
-- L["|cffff0000%s - %s killed by %s|r"] = ""
-- L["Colored dots"] = ""
-- L["Dot Options"] = ""
-- L["Draw Alts"] = ""
-- L["Drawing mode"] = ""
-- L["Draws PvP events on map for all characters"] = ""
-- L["Dynamic Zoom"] = ""
-- L["Icon Options"] = ""
-- L["Icons"] = ""
-- L["PvP Encounter"] = ""
-- L["PvP Event Map"] = ""
-- L["Redraws icons based on Cartographer3 zoom level"] = ""
-- L["Reset"] = ""
-- L["Reset dots to default"] = ""
-- L["Sets the loss color and opacity"] = ""
-- L["Sets the win color and opacity"] = ""
-- L["Show tooltips when hovering over PvP events"] = ""
-- L["Size"] = ""
-- L["Size of dots"] = ""
-- L["Toggle showing individual icons or simple dots"] = ""
-- L["Tooltips"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/EventMap", "zhTW")
if L then
-- auto generated from wowace translation app
-- L["|cff00ff00%s - %s killed %s|r"] = ""
L["|cffff0000%s - %s killed by %s|r"] = "|cffff0000%s - %s 被 %s殺害|r" -- Needs review
-- L["Colored dots"] = ""
-- L["Dot Options"] = ""
-- L["Draw Alts"] = ""
-- L["Drawing mode"] = ""
-- L["Draws PvP events on map for all characters"] = ""
-- L["Dynamic Zoom"] = ""
-- L["Icon Options"] = ""
-- L["Icons"] = ""
-- L["PvP Encounter"] = ""
-- L["PvP Event Map"] = ""
-- L["Redraws icons based on Cartographer3 zoom level"] = ""
-- L["Reset"] = ""
-- L["Reset dots to default"] = ""
-- L["Sets the loss color and opacity"] = ""
-- L["Sets the win color and opacity"] = ""
-- L["Show tooltips when hovering over PvP events"] = ""
-- L["Size"] = ""
-- L["Size of dots"] = ""
-- L["Toggle showing individual icons or simple dots"] = ""
-- L["Tooltips"] = ""

end
