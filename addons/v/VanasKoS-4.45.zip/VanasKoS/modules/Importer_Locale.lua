﻿--[[----------------------------------------------------------------------
      Importer Module - Part of VanasKoS
Handles import of other AddOns KoS Data
------------------------------------------------------------------------]]
local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "enUS", true)
if L then
	L["Import Data"] = true
	L["imported"] = true
	L["Imported %d KoS entries (%d duplicates)"] = true
	L["Imported %d PVP events"] = true
	L["Imports Data from old VanasKoS"] = true
	L["Imports KoS Data from Opium"] = true
	L["Imports KoS Data from other KoS tools"] = true
	L["Imports KoS Data from Shim's Kill Map"] = true
	L["Imports KoS Data from Ultimate Book of the Dead"] = true
	L["Imports PvP Stats Data from Opium"] = true
	L["Imports PvP Stats Data from Shim's Kill Map"] = true
	L["Old VanasKoS"] = true
	L["Opium data couldn't be loaded"] = true
	L["Opium data was imported"] = true
	L["Opium KoS"] = true
	L["Opium PvP Stats"] = true
	L["Shim's Kill Map"] = true
	L["SKMap data couldn't be loaded"] = true
	L["SKMap data was imported"] = true
	L["SKMap KoS"] = true
	L["SKMap PvP Stats"] = true
	L["UBotD data couldn't be loaded"] = true
	L["UBotD data was imported"] = true
	L["UBotD KoS"] = true
	L["Ultimate Book of the Dead"] = true
	L["Updated %d PVP statistics"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "frFR")
if L then
-- auto generated from wowace translation app
L["Import Data"] = "Importer des données" -- Needs review
L["imported"] = "importé"
L["Imported %d KoS entries (%d duplicates)"] = "%d Importés Kos entrées (%d doublons)" -- Needs review
L["Imported %d PVP events"] = "%d Importés événements PVP" -- Needs review
L["Imports Data from old VanasKoS"] = "L'importation de données à partir de vieux VanasKoS" -- Needs review
L["Imports KoS Data from Opium"] = "Importe les données de \"Opium\""
L["Imports KoS Data from other KoS tools"] = "Importe les données KoS d'autres outils KoS"
L["Imports KoS Data from Shim's Kill Map"] = "Importations de données de Kos Shim's Kill Carte" -- Needs review
L["Imports KoS Data from Ultimate Book of the Dead"] = "Importe les données de \"Ultimate Book of the Dead\""
L["Imports PvP Stats Data from Opium"] = "Les importations Stats JcJ de données de l'opium" -- Needs review
L["Imports PvP Stats Data from Shim's Kill Map"] = "Les importations Stats JcJ Les données de Shim's Kill Carte" -- Needs review
L["Old VanasKoS"] = "Ancien VanasKoS" -- Needs review
L["Opium data couldn't be loaded"] = "Des données d'Opium n'ont pas pu être chargées"
L["Opium data was imported"] = "Des données d'Opium ont été importées"
L["Opium KoS"] = "Opium Kos" -- Needs review
L["Opium PvP Stats"] = "Stats JcJ opium" -- Needs review
L["Shim's Kill Map"] = "Carte Kill Shim's" -- Needs review
L["SKMap data couldn't be loaded"] = "SKMap données ne peut être chargé" -- Needs review
L["SKMap data was imported"] = "SKMap données a été importée" -- Needs review
L["SKMap KoS"] = "SKMap Kos" -- Needs review
L["SKMap PvP Stats"] = "Stats PvP SKMap" -- Needs review
L["UBotD data couldn't be loaded"] = "Des données d'UBotD n'ont pas pu être chargées"
L["UBotD data was imported"] = "Des données d'UBotD ont été importées"
L["UBotD KoS"] = "UBotD Kos" -- Needs review
L["Ultimate Book of the Dead"] = "Réservez Ultimate of the Dead" -- Needs review
L["Updated %d PVP statistics"] = "Mise à jour des statistiques %d PVP" -- Needs review

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "deDE")
if L then
-- auto generated from wowace translation app
L["Import Data"] = "Daten importieren"
L["imported"] = "importiert"
L["Imported %d KoS entries (%d duplicates)"] = "%d KoS-Einträge wurden importiert (%d Duplikate)"
L["Imported %d PVP events"] = "%d PvP-Events importiert"
L["Imports Data from old VanasKoS"] = "Alte VanasKoS-Daten importieren"
L["Imports KoS Data from Opium"] = "Importieren von Daten aus Opium"
L["Imports KoS Data from other KoS tools"] = "Importieren von Daten aus anderen KoS-AddOns"
L["Imports KoS Data from Shim's Kill Map"] = "Importiert KoS-Daten von Shim's Kill Map"
L["Imports KoS Data from Ultimate Book of the Dead"] = "Importieren von Daten aus dem \"Ultimate Book of the Dead\""
L["Imports PvP Stats Data from Opium"] = "Importieren von Opiums PvP-Statistiken"
L["Imports PvP Stats Data from Shim's Kill Map"] = "Importiert PvP-Statistiken von Shim's Kill Map"
L["Old VanasKoS"] = "Altes VanasKoS"
L["Opium data couldn't be loaded"] = "Opium Daten konnten nicht geladen werden"
L["Opium data was imported"] = "Opium Daten wurden importiert"
L["Opium KoS"] = "Opium KoS"
L["Opium PvP Stats"] = "Opium PvP Stats"
L["Shim's Kill Map"] = "Shim's Kill Map"
L["SKMap data couldn't be loaded"] = "SKMap Daten konnten nicht geladen werden"
L["SKMap data was imported"] = "SKMap Daten wurden importiert"
L["SKMap KoS"] = "SKMap KoS"
L["SKMap PvP Stats"] = "SKMap PvP Stats"
L["UBotD data couldn't be loaded"] = "UBotD Daten konnten nicht geladen werden"
L["UBotD data was imported"] = "UBotD Daten wurden importiert"
L["UBotD KoS"] = "UBotD KoS"
L["Ultimate Book of the Dead"] = "Ultimate Book of the Dead"
L["Updated %d PVP statistics"] = "%d PvP-Statisttik-Einträge aktualisiert"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "koKR")
if L then
-- auto generated from wowace translation app
-- L["Import Data"] = ""
L["imported"] = "로드됨"
-- L["Imported %d KoS entries (%d duplicates)"] = ""
-- L["Imported %d PVP events"] = ""
-- L["Imports Data from old VanasKoS"] = ""
L["Imports KoS Data from Opium"] = "Opium의 KoS 데이터를 불러옵니다."
L["Imports KoS Data from other KoS tools"] = "다른 KoS 툴에서 KoS 데이터를 불러옵니다."
-- L["Imports KoS Data from Shim's Kill Map"] = ""
L["Imports KoS Data from Ultimate Book of the Dead"] = "Ultimate Book of the Dead에서 KoS 데이터를 불러옵니다."
L["Imports PvP Stats Data from Opium"] = "Opium에서 PvP 상태 데이터를 불러옵니다."
-- L["Imports PvP Stats Data from Shim's Kill Map"] = ""
-- L["Old VanasKoS"] = ""
L["Opium data couldn't be loaded"] = "Opium 데이터를 불러올 수 없습니다."
L["Opium data was imported"] = "Opium 데이터를 로드하였습니다."
-- L["Opium KoS"] = ""
-- L["Opium PvP Stats"] = ""
-- L["Shim's Kill Map"] = ""
-- L["SKMap data couldn't be loaded"] = ""
-- L["SKMap data was imported"] = ""
-- L["SKMap KoS"] = ""
-- L["SKMap PvP Stats"] = ""
L["UBotD data couldn't be loaded"] = "UBotD 데이터를 불러올 수 없습니다."
L["UBotD data was imported"] = "UBotD 데이터를 로드하였습니다."
-- L["UBotD KoS"] = ""
-- L["Ultimate Book of the Dead"] = ""
-- L["Updated %d PVP statistics"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Import Data"] = ""
-- L["imported"] = ""
-- L["Imported %d KoS entries (%d duplicates)"] = ""
-- L["Imported %d PVP events"] = ""
-- L["Imports Data from old VanasKoS"] = ""
-- L["Imports KoS Data from Opium"] = ""
-- L["Imports KoS Data from other KoS tools"] = ""
-- L["Imports KoS Data from Shim's Kill Map"] = ""
-- L["Imports KoS Data from Ultimate Book of the Dead"] = ""
-- L["Imports PvP Stats Data from Opium"] = ""
-- L["Imports PvP Stats Data from Shim's Kill Map"] = ""
-- L["Old VanasKoS"] = ""
-- L["Opium data couldn't be loaded"] = ""
-- L["Opium data was imported"] = ""
-- L["Opium KoS"] = ""
-- L["Opium PvP Stats"] = ""
-- L["Shim's Kill Map"] = ""
-- L["SKMap data couldn't be loaded"] = ""
-- L["SKMap data was imported"] = ""
-- L["SKMap KoS"] = ""
-- L["SKMap PvP Stats"] = ""
-- L["UBotD data couldn't be loaded"] = ""
-- L["UBotD data was imported"] = ""
-- L["UBotD KoS"] = ""
-- L["Ultimate Book of the Dead"] = ""
-- L["Updated %d PVP statistics"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "ruRU")
if L then
-- auto generated from wowace translation app
L["Import Data"] = "Импорт данных"
L["imported"] = "импортировано"
L["Imported %d KoS entries (%d duplicates)"] = "Импортировано %d KoS записей (%d совпадает)"
L["Imported %d PVP events"] = "Импортировано %d PVP событий"
L["Imports Data from old VanasKoS"] = "Импортирует данные из старых версий VanasKoS"
L["Imports KoS Data from Opium"] = "Импортирует данные KoS из Opium"
L["Imports KoS Data from other KoS tools"] = "Импортирует данные KoS из других KoS инструментов"
-- L["Imports KoS Data from Shim's Kill Map"] = ""
L["Imports KoS Data from Ultimate Book of the Dead"] = "Импортирует данные KoS из Ultimate Book of the Dead"
L["Imports PvP Stats Data from Opium"] = "Импортирует ПвП статистику из Opium"
-- L["Imports PvP Stats Data from Shim's Kill Map"] = ""
-- L["Old VanasKoS"] = ""
L["Opium data couldn't be loaded"] = "Не удалось загрузить данные Opium"
L["Opium data was imported"] = "Данные Opium импортированы"
-- L["Opium KoS"] = ""
-- L["Opium PvP Stats"] = ""
-- L["Shim's Kill Map"] = ""
-- L["SKMap data couldn't be loaded"] = ""
-- L["SKMap data was imported"] = ""
-- L["SKMap KoS"] = ""
-- L["SKMap PvP Stats"] = ""
L["UBotD data couldn't be loaded"] = "Не удалось загрузить данные UBotD"
L["UBotD data was imported"] = "Данные UBotD импортированы"
-- L["UBotD KoS"] = ""
-- L["Ultimate Book of the Dead"] = ""
L["Updated %d PVP statistics"] = "Обновлено %d PVP наблюдений"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "zhCN")
if L then
-- auto generated from wowace translation app
L["Import Data"] = "导入数据"
L["imported"] = "已导入"
L["Imported %d KoS entries (%d duplicates)"] = "已导入%d仇敌条目（%d重复）"
L["Imported %d PVP events"] = "已导入%d PvP 事件"
L["Imports Data from old VanasKoS"] = "从旧的 VanasKoS 导入数据"
L["Imports KoS Data from Opium"] = "从 Opium 导入仇敌数据"
L["Imports KoS Data from other KoS tools"] = "从其他仇敌工具导入仇敌数据"
L["Imports KoS Data from Shim's Kill Map"] = "从 Shim's Kill Map 导入仇敌数据"
L["Imports KoS Data from Ultimate Book of the Dead"] = "从 Book of the Dead 导入仇敌数据"
L["Imports PvP Stats Data from Opium"] = "从 Opium 导入 PvP 状态"
L["Imports PvP Stats Data from Shim's Kill Map"] = "从 Shim's Kill Map 导入 PvP 状态"
L["Old VanasKoS"] = "旧的 VanasKoS"
L["Opium data couldn't be loaded"] = "不能加载 Opium 数据"
L["Opium data was imported"] = "已导入 Opium 数据"
L["Opium KoS"] = "Opium 仇敌"
L["Opium PvP Stats"] = "Opium PvP 状态"
L["Shim's Kill Map"] = "Shim's Kill Map"
L["SKMap data couldn't be loaded"] = "不能加载 SKMap 数据"
L["SKMap data was imported"] = "已导入 SKMap 数据"
L["SKMap KoS"] = "SKMap 仇敌"
L["SKMap PvP Stats"] = "SKMap PvP 状态"
L["UBotD data couldn't be loaded"] = "不能加载 UBotD 数据"
L["UBotD data was imported"] = "已导入 UBotD 数据"
L["UBotD KoS"] = "UBotD 仇敌"
L["Ultimate Book of the Dead"] = "Ultimate Book of the Dead"
L["Updated %d PVP statistics"] = "已更新%s PvP状态"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "esES")
if L then
-- auto generated from wowace translation app
-- L["Import Data"] = ""
L["imported"] = "importados"
-- L["Imported %d KoS entries (%d duplicates)"] = ""
-- L["Imported %d PVP events"] = ""
-- L["Imports Data from old VanasKoS"] = ""
L["Imports KoS Data from Opium"] = "Importa datos de KoS de Opium"
L["Imports KoS Data from other KoS tools"] = "Importa datos de KoS de otras herramientas de KoS"
-- L["Imports KoS Data from Shim's Kill Map"] = ""
L["Imports KoS Data from Ultimate Book of the Dead"] = "Importa datos de KoS de Ultimate Book of the Dead"
-- L["Imports PvP Stats Data from Opium"] = ""
-- L["Imports PvP Stats Data from Shim's Kill Map"] = ""
-- L["Old VanasKoS"] = ""
L["Opium data couldn't be loaded"] = "Los datos de Opium no han podido ser cargados"
L["Opium data was imported"] = "Los datos de Opium han sido importados"
-- L["Opium KoS"] = ""
-- L["Opium PvP Stats"] = ""
-- L["Shim's Kill Map"] = ""
-- L["SKMap data couldn't be loaded"] = ""
-- L["SKMap data was imported"] = ""
-- L["SKMap KoS"] = ""
-- L["SKMap PvP Stats"] = ""
L["UBotD data couldn't be loaded"] = "Los datos de UBotD no han podido ser cargados"
L["UBotD data was imported"] = "Los datos de UBotD han sido importados"
-- L["UBotD KoS"] = ""
-- L["Ultimate Book of the Dead"] = ""
-- L["Updated %d PVP statistics"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/Importer", "zhTW")
if L then
-- auto generated from wowace translation app
-- L["Import Data"] = ""
-- L["imported"] = ""
-- L["Imported %d KoS entries (%d duplicates)"] = ""
-- L["Imported %d PVP events"] = ""
-- L["Imports Data from old VanasKoS"] = ""
-- L["Imports KoS Data from Opium"] = ""
-- L["Imports KoS Data from other KoS tools"] = ""
-- L["Imports KoS Data from Shim's Kill Map"] = ""
-- L["Imports KoS Data from Ultimate Book of the Dead"] = ""
-- L["Imports PvP Stats Data from Opium"] = ""
-- L["Imports PvP Stats Data from Shim's Kill Map"] = ""
-- L["Old VanasKoS"] = ""
-- L["Opium data couldn't be loaded"] = ""
-- L["Opium data was imported"] = ""
-- L["Opium KoS"] = ""
-- L["Opium PvP Stats"] = ""
-- L["Shim's Kill Map"] = ""
-- L["SKMap data couldn't be loaded"] = ""
-- L["SKMap data was imported"] = ""
-- L["SKMap KoS"] = ""
-- L["SKMap PvP Stats"] = ""
-- L["UBotD data couldn't be loaded"] = ""
-- L["UBotD data was imported"] = ""
-- L["UBotD KoS"] = ""
-- L["Ultimate Book of the Dead"] = ""
-- L["Updated %d PVP statistics"] = ""

end
