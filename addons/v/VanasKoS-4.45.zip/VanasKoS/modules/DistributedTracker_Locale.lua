﻿--[[----------------------------------------------------------------------
      DistributedTracker Module - Part of VanasKoS
Broadcasts a list to GUILD and handles returning position answers
------------------------------------------------------------------------]]
local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "enUS", true)
if L then
	L["Distributed Tracking"] = true
	L["Found multiple matches for zone '%s': %s"] = true
	L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = true
	L["No match was found for zone '%s'"] = true
	L["Ok"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "frFR")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "Annuler"
L["Distributed Tracking"] = "Répartition des informations KoS"
L["Found multiple matches for zone '%s': %s"] = "multiples trouvé ces résultats pour la zone «%s»: %s" -- Needs review
L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = "Carte mise à jour sur la position du joueur %s (%d, %d %s dans) a reçu - Raison: %s" -- Needs review
L["No match was found for zone '%s'"] = "Aucune correspondance n'a été trouvée pour la zone '%s'" -- Needs review
L["Ok"] = "Ok"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "deDE")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "Abbrechen"
L["Distributed Tracking"] = "Verteiltes Suchen"
L["Found multiple matches for zone '%s': %s"] = "Mehrere Treffer für die Zone '%s' gefunden: %s"
L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = "Karten-Position von Player %s aktualisiert (%d, %d in %s) von %s - Grund: %s"
L["No match was found for zone '%s'"] = "Es wurde kein Treffer für die Zone '%s' gefunden."
L["Ok"] = "OK"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "koKR")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "취소"
L["Distributed Tracking"] = "분산 추적"
-- L["Found multiple matches for zone '%s': %s"] = ""
-- L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = ""
-- L["No match was found for zone '%s'"] = ""
L["Ok"] = "확인"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Cancel"] = ""
-- L["Distributed Tracking"] = ""
-- L["Found multiple matches for zone '%s': %s"] = ""
-- L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = ""
-- L["No match was found for zone '%s'"] = ""
-- L["Ok"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "ruRU")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "Отмена"
L["Distributed Tracking"] = "Распределенное слежение"
L["Found multiple matches for zone '%s': %s"] = "Найдено несколько совпадений для зоны '%s': %s"
L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = "Карта Позиция обновление Player %s (%d, %d в%s) получил - Причина:%s" -- Needs review
L["No match was found for zone '%s'"] = "Не было найдено совпадение для зоны '%s'" -- Needs review
L["Ok"] = "Ok"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "zhCN")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "取消"
L["Distributed Tracking"] = "分布式跟踪"
L["Found multiple matches for zone '%s': %s"] = "找到区域内'%s'多个匹配：%s"
L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = "已接受玩家地图位置更新%s（%d, %d位于%s）- 原因：%s"
L["No match was found for zone '%s'"] = "没有找到匹配区域'%s'"
L["Ok"] = "确定"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "esES")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "Cancelar"
L["Distributed Tracking"] = "Rastreo Distribuido"
-- L["Found multiple matches for zone '%s': %s"] = ""
-- L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = ""
-- L["No match was found for zone '%s'"] = ""
L["Ok"] = "Aceptar"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DistributedTracker", "zhTW")
if L then
-- auto generated from wowace translation app
L["Cancel"] = "取消"
L["Distributed Tracking"] = "很多追蹤" -- Needs review
L["Found multiple matches for zone '%s': %s"] = "找到眾多符合區域 '%s': %s"
-- L["Map Position update on Player %s (%d, %d in %s) received - Reason: %s"] = ""
L["No match was found for zone '%s'"] = "未找到符合的區域 '%s'"
L["Ok"] = "Ok"

end
