﻿local L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "enUS", true)
if L then
	L["Enable in Sanctuaries"] = true
	L["Enable in Cities"] = true
	L["Data Gathering"] = true
	L["Permanent Player-Data-Storage"] = true
	L["Save data gathered in cities"] = true
	L["Toggles detection of players in sanctuaries"] = true
	L["Toggles detection of players in cities"] = true
	L["Toggles if data from players gathered in cities should be saved."] = true
	L["Toggles if the combatlog should be used to detect nearby player"] = true
	L["Toggles if the data about players (level, class, etc) should be saved permanently."] = true
	L["Use Combat Log"] = true
	L["Enable in Battleground"] = true
	L["Toggles detection of players in battlegrounds"] = true
	L["Enable in combat zone"] = true
	L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = true
	L["Enable in arena"] = true
	L["Toggles detection of players in arenas"] = true
end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "frFR")
if L then
-- auto generated from wowace translation app
-- L["Data Gathering"] = ""
-- L["Enable in arena"] = ""
-- L["Enable in Battleground"] = ""
-- L["Enable in Cities"] = ""
-- L["Enable in combat zone"] = ""
-- L["Enable in Sanctuaries"] = ""
-- L["Permanent Player-Data-Storage"] = ""
-- L["Save data gathered in cities"] = ""
-- L["Toggles detection of players in arenas"] = ""
-- L["Toggles detection of players in battlegrounds"] = ""
-- L["Toggles detection of players in cities"] = ""
-- L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = ""
-- L["Toggles detection of players in sanctuaries"] = ""
-- L["Toggles if data from players gathered in cities should be saved."] = ""
-- L["Toggles if the combatlog should be used to detect nearby player"] = ""
-- L["Toggles if the data about players (level, class, etc) should be saved permanently."] = ""
-- L["Use Combat Log"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "deDE")
if L then
-- auto generated from wowace translation app
L["Data Gathering"] = "Datensammlung"
L["Enable in arena"] = "Aktivieren in der Arena"
L["Enable in Battleground"] = "Aktivieren auf Schlachtfeldern"
L["Enable in Cities"] = "In Städten aktivieren"
L["Enable in combat zone"] = "Aktivieren in Kampfzonen (Tol Barad, etc.)"
L["Enable in Sanctuaries"] = "In Zufluchtsstätten aktivieren"
L["Permanent Player-Data-Storage"] = "Dauerhafte Spieler-Datenspeicherung"
L["Save data gathered in cities"] = "In Städten gesammelte Daten speichern"
L["Toggles detection of players in arenas"] = "Schaltet Spieler-Detektion in Arenen ein/aus"
L["Toggles detection of players in battlegrounds"] = "Schaltet Spieler-Detektion in Schlachtfeldern ein/aus"
L["Toggles detection of players in cities"] = "Spielererkennung in Städten ein- und ausschalten"
L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = "Schaltet Spieler-Detektion in Kampfzonen ein/aus (Tol Barad, etc.)"
L["Toggles detection of players in sanctuaries"] = "Spielererkennung in Zufluchtsstätten ein- und ausschalten"
L["Toggles if data from players gathered in cities should be saved."] = "Schaltet die Speicherung von in Städten gesammelten Spielerdaten ein/aus."
L["Toggles if the combatlog should be used to detect nearby player"] = "Schaltet die Erkennung von in der Nähe befindlichen Spielern im Kampflog ein/aus."
L["Toggles if the data about players (level, class, etc) should be saved permanently."] = "Schaltet die dauerhafte Speicherung der Spielerdaten (Stufe, Klasse, etc.) ein/aus."
L["Use Combat Log"] = "Kampflog verwenden"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "koKR")
if L then
-- auto generated from wowace translation app
-- L["Data Gathering"] = ""
-- L["Enable in arena"] = ""
-- L["Enable in Battleground"] = ""
-- L["Enable in Cities"] = ""
-- L["Enable in combat zone"] = ""
-- L["Enable in Sanctuaries"] = ""
-- L["Permanent Player-Data-Storage"] = ""
-- L["Save data gathered in cities"] = ""
-- L["Toggles detection of players in arenas"] = ""
-- L["Toggles detection of players in battlegrounds"] = ""
-- L["Toggles detection of players in cities"] = ""
-- L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = ""
-- L["Toggles detection of players in sanctuaries"] = ""
-- L["Toggles if data from players gathered in cities should be saved."] = ""
-- L["Toggles if the combatlog should be used to detect nearby player"] = ""
-- L["Toggles if the data about players (level, class, etc) should be saved permanently."] = ""
-- L["Use Combat Log"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "esMX")
if L then
-- auto generated from wowace translation app
-- L["Data Gathering"] = ""
-- L["Enable in arena"] = ""
-- L["Enable in Battleground"] = ""
-- L["Enable in Cities"] = ""
-- L["Enable in combat zone"] = ""
-- L["Enable in Sanctuaries"] = ""
-- L["Permanent Player-Data-Storage"] = ""
-- L["Save data gathered in cities"] = ""
-- L["Toggles detection of players in arenas"] = ""
-- L["Toggles detection of players in battlegrounds"] = ""
-- L["Toggles detection of players in cities"] = ""
-- L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = ""
-- L["Toggles detection of players in sanctuaries"] = ""
-- L["Toggles if data from players gathered in cities should be saved."] = ""
-- L["Toggles if the combatlog should be used to detect nearby player"] = ""
-- L["Toggles if the data about players (level, class, etc) should be saved permanently."] = ""
-- L["Use Combat Log"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "ruRU")
if L then
-- auto generated from wowace translation app
-- L["Data Gathering"] = ""
-- L["Enable in arena"] = ""
-- L["Enable in Battleground"] = ""
-- L["Enable in Cities"] = ""
-- L["Enable in combat zone"] = ""
-- L["Enable in Sanctuaries"] = ""
-- L["Permanent Player-Data-Storage"] = ""
-- L["Save data gathered in cities"] = ""
-- L["Toggles detection of players in arenas"] = ""
-- L["Toggles detection of players in battlegrounds"] = ""
-- L["Toggles detection of players in cities"] = ""
-- L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = ""
-- L["Toggles detection of players in sanctuaries"] = ""
-- L["Toggles if data from players gathered in cities should be saved."] = ""
-- L["Toggles if the combatlog should be used to detect nearby player"] = ""
L["Toggles if the data about players (level, class, etc) should be saved permanently."] = "Включите, если хотите чтобы информация о игроках (уровень, класс, и т.п.) не очищалась со временем."
L["Use Combat Log"] = "Использовать лог боя"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "zhCN")
if L then
-- auto generated from wowace translation app
L["Data Gathering"] = "数据收集"
L["Enable in arena"] = "在竞技场启用"
L["Enable in Battleground"] = "在战场启用"
L["Enable in Cities"] = "在城里启用"
L["Enable in combat zone"] = "在战斗区域启用"
L["Enable in Sanctuaries"] = "在安全区域启用"
L["Permanent Player-Data-Storage"] = "永久保存玩家数据"
L["Save data gathered in cities"] = "保存城里收集数据"
L["Toggles detection of players in arenas"] = "切换竞技场玩家侦测"
L["Toggles detection of players in battlegrounds"] = "切换战场玩家侦测"
L["Toggles detection of players in cities"] = "切换城里玩家侦测"
L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = "切换战斗区域玩家侦测（冬拥湖，托尔巴拉德）"
L["Toggles detection of players in sanctuaries"] = "切换安全区域玩家侦测"
L["Toggles if data from players gathered in cities should be saved."] = "切换保存城里玩家数据收集。"
L["Toggles if the combatlog should be used to detect nearby player"] = "切换使用战斗记录侦测附近玩家。"
L["Toggles if the data about players (level, class, etc) should be saved permanently."] = "切换永久性保存玩家数据。（等级，职业等）"
L["Use Combat Log"] = "使用战斗记录"

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "esES")
if L then
-- auto generated from wowace translation app
-- L["Data Gathering"] = ""
-- L["Enable in arena"] = ""
-- L["Enable in Battleground"] = ""
-- L["Enable in Cities"] = ""
-- L["Enable in combat zone"] = ""
-- L["Enable in Sanctuaries"] = ""
-- L["Permanent Player-Data-Storage"] = ""
-- L["Save data gathered in cities"] = ""
-- L["Toggles detection of players in arenas"] = ""
-- L["Toggles detection of players in battlegrounds"] = ""
-- L["Toggles detection of players in cities"] = ""
-- L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = ""
-- L["Toggles detection of players in sanctuaries"] = ""
-- L["Toggles if data from players gathered in cities should be saved."] = ""
-- L["Toggles if the combatlog should be used to detect nearby player"] = ""
-- L["Toggles if the data about players (level, class, etc) should be saved permanently."] = ""
-- L["Use Combat Log"] = ""

end

L = LibStub("AceLocale-3.0"):NewLocale("VanasKoS/DataGatherer", "zhTW")
if L then
-- auto generated from wowace translation app
-- L["Data Gathering"] = ""
-- L["Enable in arena"] = ""
-- L["Enable in Battleground"] = ""
-- L["Enable in Cities"] = ""
-- L["Enable in combat zone"] = ""
-- L["Enable in Sanctuaries"] = ""
-- L["Permanent Player-Data-Storage"] = ""
-- L["Save data gathered in cities"] = ""
-- L["Toggles detection of players in arenas"] = ""
-- L["Toggles detection of players in battlegrounds"] = ""
-- L["Toggles detection of players in cities"] = ""
-- L["Toggles detection of players in combat zones (Wintergrasp, Tol Barad)"] = ""
-- L["Toggles detection of players in sanctuaries"] = ""
-- L["Toggles if data from players gathered in cities should be saved."] = ""
-- L["Toggles if the combatlog should be used to detect nearby player"] = ""
-- L["Toggles if the data about players (level, class, etc) should be saved permanently."] = ""
-- L["Use Combat Log"] = ""

end
