Description:
VanasKoS est un "Kill-on-Sight notifier" (Liste noire (KoS)), �a emploie
chaque possibilit�s pour d�tecter un ennemi list� et informe l'utilisateur
de diff�rentes mani�res.

Dispositifs:
* Liste KoS pour joueurs et Guildes
* Liste blanche
* Liste noire
* Tri de listes
* Toutes les listes sont sauv�s par Royaumes
* Portrait �lite de couleur "or" si le joueur et dans la liste KoS, de
couleur "argent" pour la liste de guilde KoS, de couleur "rouge" pour un
alli� dans la liste noire, et de couleur "vert" pour un ennemi dans la liste
blanche.
* Possibilit� d'ajouter ou de modifier une raison pour laquelle on a rajout�
un joueur ou une guilde
* Vous informe si un joueur sur votre liste KoS fait quelque chose pr�s de
vous
(combat/buff/parle...) dans la fen�tre de discussion, le notifie selon les
options que vous avez choisi
* Fen�tre d'avertissement pour aider � traquer les cibles amicales ou
hostiles.
* Configuration facile gr�ce � l'interface simplifi� ! essayez /kos menu
* R�partition des informations KoS - D'autres personnes peuvent vous aider �
traquer vos cibles
* Bouton minicarte
* Importation de donn�es 'Ultimate Book of the Dead'
* Importation de donn�es 'Opium'
* Possibilit� de rajouter un onglet � la liste d'amis
* Partagez vos entr�e en groupe
* Synchronisation automatique avec des personnes de votre guilde/liste 
d'amis (liste) ou synchronisation manuelle.

Commandes:
/kos ou /vanaskos pour plus d'informations

Vous pouvez employer  /kadd:

Avec une cible:
/kadd - demande d'une raison

Sans cible:
/kadd - demande un nom et une raison

Toujours:
/kadd <joueur> - demande d'une raison
/kadd <joueur> <raison> - rajoute <joueur> avec <raison>

Explication des fonctions:

Bouton minicarte:
Clique gauche pour ouvrir le menu, clique-droit pour utiliser la fonction
/kadd

R�partition des informations KoS:
Toutes les 10 minutes, les nom dans votre liste KoS est publi� a toute la
guilde et � la zone courante. Si un autre joueur de la guilde ou de la zone
utilise VanasKos, il recevra la liste et v�rifira si une de vos cibles est
pr�t de lui. Si c'est le cas, un message vous indiquera ou se trouve votre
cible en indiquant sa position pour une vengeance. Si vous avez
cartographer, vous pouvez rajouter une note sur la zone ou a �t� d�tect�
votre cible.

cr�dits:
Ace2, Parser-3.0, Babble-Zone-2.2, Dewdrop-2.0, DeuceLog, Tourist-2.0