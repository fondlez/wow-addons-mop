local E=unpack(select(2,...))

E.CHANNELS={
	SendChatMessage={
		order=1,
		name="Send to chat",
		msgArg=1,
		list={
			"SAY",
			"YELL",
			"PARTY",
			"GUILD",
			"OFFICER",
			"RAID",
			"RAID_WARNING",
			"INSTANCE_CHAT",
			"SMART_GROUP",
		},
	},
	AddMessage={
		order=2,
		name="Print to frame (player only)",
		msgArg=2,
		list={
			"UIErrorsFrame",
			"DEFAULT_CHAT_FRAME",
		},
		colored=true,
	},
	RaidNotice_AddMessage={
		order=3,
		name="Display in frame (player only)",
		msgArg=2,
		list={
			"RaidWarningFrame",
			"RaidBossEmoteFrame",
		},
		chatType=true,
	},
}

E.INSTANCE_FORMAT="Announce pulls in %s"

E.INSTANCE_TYPES={
	none={
		order=1,
		readable="The World",
	},
	pvp={
		order=5,
		readable=BATTLEGROUNDS,
	},
	arena={
		order=6,
		readable=ARENA_BATTLES,
	},
	raid={
		order=2,
		readable=RAIDS,
	},
	party={
		order=3,
		readable=DUNGEONS,
	},
	scenario={
		order=4,
		readable=SCENARIOS,
	},
}