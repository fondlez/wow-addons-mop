local E=unpack(select(2,...))

--frames
local monitor=CreateFrame("Frame")
do
	monitor.whosInCombat={}
	monitor.unitTable={}
	monitor:RegisterEvent("GROUP_ROSTER_UPDATE")
	monitor:RegisterEvent("PLAYER_ENTERING_WORLD")
end
local announcer=CreateFrame("Frame")

--util functions
local function unitColorString(unitId)
	local class=select(2,UnitClass(unitId))
	return class and RAID_CLASS_COLORS[class].colorStr or "ff000000"
end
local function toMyUnitId(unitId)
	if strfind(unitId,"pet") then
		unitId=gsub(unitId,"pet","").."pet"
	end
	if not IsInRaid() then
		if unitId=="player" then
			unitId="party5"
		elseif unitId=="pet" then
			unitId="party5pet"
		end
	end
	if (monitor.groupType=="raid" and strfind(unitId,"raid")) or (monitor.groupType=="party" and strfind(unitId,"party")) then
		return unitId
	end
end
local function fromMyUnitId(unitId)
	return (gsub(unitId,"party5","player",1))
end
local function throughMyUnitId(unitId)
	if strfind(unitId,"pet") then
		unitId=gsub(unitId,"pet","").."pet"
	end
	if (monitor.groupType=="raid" and strfind(unitId,"raid")) or (monitor.groupType=="party" and strfind(unitId,"party")) then
		return unitId
	end
end
local function standardizedUnitId(unitId)
	unitId=gsub(unitId,"pet","-pet")
	unitId=gsub(unitId,"target","-target")
	local main,suffix=strsplit("-",unitId,2)
	if suffix then
		suffix="-"..suffix
	end
	unitId=strconcat(UnitName(main) or "",suffix or "")
	return unitId
end
local function unitInGroup(unitId)
	return UnitPlayerOrPetInRaid(unitId) or UnitPlayerOrPetInParty(unitId)
end
local function getGroupType()
	local numGroupMembers=GetNumGroupMembers()
	if numGroupMembers<2 then
		return
	end
	local groupType,instanceType
	if numGroupMembers>5 or IsInRaid() then
		groupType="raid"
	else
		groupType="party"
	end
	instanceType=select(2,IsInInstance())
	return groupType,instanceType
end
local function getGroupSize()
	return monitor.groupType=="raid" and MAX_RAID_MEMBERS or (MAX_PARTY_MEMBERS+1)
end
local function getUnitOrOwner(unitId)
	return (gsub(unitId,"-pet","",1))
end
local function unitIsTank(unitId)
	return UnitGroupRolesAssigned(unitId)=="TANK" or GetPartyAssignment("MAINTANK",unitId,true)
end
local function unitInInstance(unitId)
	if UnitInRange(unitId) then
		return true
	end
	SetMapToCurrentZone()
	local levels=GetNumDungeonMapLevels()
	local x,y=0,0
	if levels==0 then
		x,y=GetPlayerMapPosition(unitId)
	else
		local level=1
		while level<=levels and x==0 and y==0 do
			SetDungeonMapLevel(level)
			x,y=GetPlayerMapPosition(unitId)
			level=level+1
		end
	end
	return x>0 and y>0
end
local function anyBossExists()
	for i=1,MAX_BOSS_FRAMES do
		if UnitExists("boss"..i) then
			return true
		end
	end
end

--monitor methods
function monitor:updateTables(unit)
	local isInCombat
	if UnitExists(unit) and unit~=UNKNOWN then
		local wasInCombat=self.unitTable[unit]
		isInCombat=UnitAffectingCombat(unit)
		if wasInCombat~=isInCombat then
			self.unitTable[unit]=isInCombat
			if isInCombat and not tContains(self.whosInCombat,unit) then
				tinsert(self.whosInCombat,unit)
			end
		end
	else
		self.unitTable[unit]=nil
	end
	if not isInCombat then
		tDeleteItem(self.whosInCombat,unit)
	end
	return isInCombat
end
function monitor:settingsFilters(unit)
	local unitOrOwner=getUnitOrOwner(unit)
	if not self.instanceType then
		error("Instance Type not found")
		return
	end
	if not E.db.global.instanceTypes[self.instanceType] then return end
	local isTank=unitIsTank(unitOrOwner)
	if E.db.global.ignoreTanks and isTank then return end
	if E.db.global.ignoreMisdirect then
		local class=select(3,UnitClass(unit))
		if (class==3 and UnitBuff(unit,(GetSpellInfo(35079)))) or (class==4 and UnitBuff(unit,(GetSpellInfo(57934)))) then return end
	end
	return true,isTank
end
function monitor:onEvent(event,arg1,...)
	if event=="UNIT_FLAGS" then
		local unit=arg1
		local myUnit=toMyUnitId(unit)
		if myUnit and unitInGroup(unit) then
			unit=standardizedUnitId(fromMyUnitId(myUnit))
			local isInCombat=self:updateTables(unit)
			if not self.isAnyoneInCombat and isInCombat and not self.justEnteredWorld then
				self.isAnyoneInCombat=true
				if self.groupType then
					local pass,isTank=self:settingsFilters(unit)
					if pass then
						announcer:scheduleAnnounce(unit,isTank)
					end
				end
			elseif self.isAnyoneInCombat and #self.whosInCombat==0 then
				self.isAnyoneInCombat=false
				announcer:noCombat()
				announcer:clear()
			end
		end
	elseif event=="GROUP_ROSTER_UPDATE" or event=="PLAYER_ENTERING_WORLD" or event=="UNIT_PET" then
		if event=="PLAYER_ENTERING_WORLD" then
			self.justEnteredWorld=true
		end
		self.groupType,self.instanceType=getGroupType()
		if self.groupType then
			self:RegisterEvent("UNIT_FLAGS")
			self:RegisterEvent("UNIT_PET")
		else
			self:UnregisterEvent("UNIT_FLAGS")
			self:UnregisterEvent("UNIT_PET")
		end
		for unit,_ in pairs(self.unitTable) do
			if not unitInGroup(unit) then
				self.unitTable[unit]=nil
			end
		end
		do
			local i=1
			while self.whosInCombat[i] do
				if not unitInGroup(self.whosInCombat[i]) then
					tremove(self.whosInCombat,i)
					i=i-1
				end
				i=i+1
			end
		end
		if event=="GROUP_ROSTER_UPDATE" or event=="PLAYER_ENTERING_WORLD" then
			if self.groupType then
				for i=1,getGroupSize() do
					local unit=UnitName(fromMyUnitId(self.groupType..i))
					if unit and unit~=UNKNOWN then
						local unitPet=unit.."-pet"
						if not self.unitTable[unit] then
							self:updateTables(unit)
						end
						if UnitExists(unitPet) and not self.unitTable[unitPet] then
							self:updateTables(unitPet)
						end
					end
				end
			else
				wipe(self.unitTable)
				wipe(self.whosInCombat)
			end
		end
		if self.isAnyoneInCombat and #self.whosInCombat==0 then
			announcer:noCombat()
			announcer:clear()
		end
		self.isAnyoneInCombat=(#self.whosInCombat>0)
		if event=="PLAYER_ENTERING_WORLD" then
			self.justEnteredWorld=nil
		end
	end
end

--announcer methods
function announcer:noCombat()
	if WhoPulledIt_Debug then
		print("Out of combat")
		UIErrorsFrame:AddMessage("Out of combat")
	end
end
function announcer:clear()
	self.whoPulled=nil
	self.isTank=nil
	self.tankLate=nil
	self.timeSincePull=nil
	self:UnregisterEvent("UNIT_FLAGS")
	self:SetScript("OnUpdate",nil)
end
function announcer:scheduleAnnounce(unit,isTank)
	self.whoPulled=unit
	self.isTank=isTank
	self.tankLate=isTank
	self.timeSincePull=0
	self:RegisterEvent("UNIT_FLAGS")
	self:SetScript("OnUpdate",self.onUpdate)
end
function announcer:announceNow()
	E.allOutput("Who Pulled First: ",unitColorString(getUnitOrOwner(self.whoPulled)),self.whoPulled)
	self:clear()
end
function announcer:onUpdate(elapsed)
	if self.isTank and self.timeSincePull==0 then
		self:UnregisterEvent("UNIT_FLAGS")
	end
	self.timeSincePull=self.timeSincePull+elapsed
	if not self.tankLate and self.timeSincePull>E.db.global.minTankResponseTime then
		self.tankLate=true
		self:UnregisterEvent("UNIT_FLAGS")
	elseif self.timeSincePull>E.db.global.minCombatTime then
		if E.db.global.ignoreTrash and not anyBossExists() then return self:clear() end
		return self:announceNow()
	end
end
function announcer:onEvent(event,arg1,...)
	if event=="UNIT_FLAGS" then
		local unit=arg1
		unit=throughMyUnitId(unit)
		if unit and not UnitIsUnit(getUnitOrOwner(self.whoPulled),getUnitOrOwner(standardizedUnitId(unit))) and UnitAffectingCombat(unit) then
			if self.timeSincePull==0 then
				return self:clear()
			end
			if not self.tankLate and self.timeSincePull<E.db.global.minTankResponseTime and unitIsTank(getUnitOrOwner(standardizedUnitId(unit))) then
				return self:clear()
			else
			end
		end
	end
end

--setscripts
do
	monitor:SetScript("OnEvent",monitor.onEvent)
	announcer:SetScript("OnEvent",announcer.onEvent)
end