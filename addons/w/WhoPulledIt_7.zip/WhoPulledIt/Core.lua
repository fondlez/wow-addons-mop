local AddOnName, Engine = ...
local AddOn = LibStub("AceAddon-3.0"):NewAddon(AddOnName)
AddOn.db={}
AddOn.db.global={}
AddOn.Options = {
	type = "group",
	name = AddOnName,
	args = {},
}

Engine[1]=AddOn

_G[AddOnName] = Engine

local defaults={
	global={
		ignoreTanks=true,
		ignoreMisdirect=false,
		ignoreTrash=false,
		instanceTypes={
			raid=true,
			party=true,
		},
		channelOutput={
			"UIErrorsFrame",
		},
		minCombatTime=10,
		minTankResponseTime=0.7,
	}
}

local optionsFrame

function AddOn:OnInitialize()
	self.db=LibStub("AceDB-3.0"):New("WPIDB",defaults,true)
	
	LibStub("AceConfigRegistry-3.0"):ValidateOptionsTable(self.Options, AddOnName)
	LibStub("AceConfig-3.0"):RegisterOptionsTable(AddOnName, self.Options)
	optionsFrame=LibStub("AceConfigDialog-3.0"):AddToBlizOptions(AddOnName)
	
	SlashCmdList["WHOPULLEDIT"]=function(msg)
		self:Config()
	end
	SLASH_WHOPULLEDIT1 = "/whopulledit"
	SLASH_WHOPULLEDIT2 = "/wpi"
end

function AddOn:Config()
	if InCombatLockdown() then
		print("Who Pulled It config: can't do that in combat")
	else
		if optionsFrame then
			if ( InterfaceOptionsFrame:IsShown() and optionsFrame:IsShown() ) then
				InterfaceOptionsFrame:Hide()
			else
				InterfaceOptionsFrame:Show()
				InterfaceOptionsFrame_OpenToCategory(optionsFrame)
			end
		end
	end
end