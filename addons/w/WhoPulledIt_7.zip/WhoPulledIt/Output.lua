local E=unpack(select(2,...))


local function getSmartChannel(channel)
	if channel == "SMART_GROUP" then
		if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
			return "INSTANCE_CHAT"
		elseif IsInRaid() then
			return "RAID"
		else
			return "PARTY"
		end		
	else
		return channel
	end
end

local function oneOutput(channelType,channel,text,colorStr,coloredText)
	local channelInfo=E.CHANNELS[channelType]
	if channelInfo then
		local func=_G[channelType] or _G[channel][channelType]
		local msg
		if channelInfo.colored and coloredText and colorStr then
			msg=text.."|c"..colorStr..coloredText.."|r"
		elseif coloredText then
			msg=text..coloredText
		else
			msg=text
		end
		channel = getSmartChannel(channel)
		if channelInfo.msgArg==1 then
			func(msg,channel)
		elseif channelInfo.msgArg==2 then
			local chatType
			if channelInfo.chatType then
				chatType=ChatTypeInfo[strupper(gsub(gsub(channel,"Frame",""),"(%l)(%u)","%1_%2"))]
			end
			func(_G[channel],msg,chatType or ChatTypeInfo["SYSTEM"])
		end
	end
end

function E.allOutput(text,colorStr,coloredText)
	for _,channel in ipairs(E.db.global.channelOutput) do
		for channelType,channelInfo in pairs(E.CHANNELS) do
			if tContains(channelInfo.list,channel) then
				oneOutput(channelType,channel,text,colorStr,coloredText)
				break
			end
		end
	end
end