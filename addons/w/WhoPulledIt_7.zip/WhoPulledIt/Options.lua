local E=unpack(select(2,...))

do
	E.Options.args.general={
		name=GENERAL_LABEL,
		desc="General Options",
		type="group",
		order=1,
		args={
			ignoreTanks={
				name="Ignore tank pulls",
				desc=format("Don't announce pulls by a player marked as a %s or %s",TANK,MAIN_TANK),
				type="toggle",
				order=1,
				set=function(info,val) E.db.global.ignoreTanks=val if not val then E.db.global.ignoreMisdirect=val end end,
				get=function(info) return E.db.global.ignoreTanks end,
			},
			ignoreMisdirect={
				name="Ignore misdirect pulls",
				desc=format("Don't announce pulls by a player using %s or %s",GetSpellInfo(35079),GetSpellInfo(57934)),
				type="toggle",
				order=2,
				set=function(info,val) E.db.global.ignoreMisdirect=val end,
				get=function(info) return E.db.global.ignoreMisdirect end,
				disabled=function(info) return not E.db.global.ignoreTanks end,
			},
			ignoreTrash={
				name="Ignore trash pulls",
				desc="Don't announce pulls if no boss was pulled",
				type="toggle",
				order=3,
				set=function(info,val) E.db.global.ignoreTrash=val end,
				get=function(info) return E.db.global.ignoreTrash end,
			}
		}
	}
	E.Options.args.instanceTypes={
		name="Instance types",
		desc="In which instance types to announce pulls",
		type="group",
		order=2,
		args={},
	}
	for instanceType,typeInfo in pairs(E.INSTANCE_TYPES) do
		E.Options.args.instanceTypes.args[instanceType]={
			name=typeInfo.readable,
			desc=format(E.INSTANCE_FORMAT,typeInfo.readable),
			type="toggle",
			order=typeInfo.order,
			set=function(info,val) E.db.global.instanceTypes[instanceType]=val end,
			get=function(info) return E.db.global.instanceTypes[instanceType] end,
		}
	end
	E.Options.args.channels={
		name="Output Channels",
		desc="How to announce pulls",
		type="group",
		order=3,
		args={},
	}
	for func, funcInfo in pairs(E.CHANNELS) do
		E.Options.args.channels.args[func]={
			order=funcInfo.order,
			name=funcInfo.name,
			type="group",
			args={},
		}
		for index,channelName in ipairs(funcInfo.list) do
			E.Options.args.channels.args[func].args[channelName]={
				order=index,
				name=type(_G[channelName])=="string" and _G[channelName] or channelName,
				type="toggle",
				set=function(info,val)
					if val and not tContains(E.db.global.channelOutput,channelName) then
						tinsert(E.db.global.channelOutput,channelName)
					elseif not val then
						tDeleteItem(E.db.global.channelOutput,channelName)
					end
				end,
				get=function(info) return tContains(E.db.global.channelOutput,channelName) end,
			}
		end
	end
	E.Options.args.advanced={
		name=ADVANCED_LABEL,
		desc=ADVANCED_OPTIONS,
		type="group",
		order=4,
		args={
			minCombatTime={
				name="Minimum Combat Duration (s)",
				desc="Increase this if WPI is announcing trivial or \"phantom\" pulls",
				type="range",
				order=1,
				set=function(info,val) E.db.global.minCombatTime=val end,
				get=function(info) return E.db.global.minCombatTime end,
				min=0,
				max=20,
				step=1,
			},
			minTankResponseTime={
				name="Tank Response Delay Tolerance (s)",
				desc="Increase this if WPI is too strict when your raid uses a pull timer",
				type="range",
				order=2,
				set=function(info,val) E.db.global.minTankResponseTime=val end,
				get=function(info) return E.db.global.minTankResponseTime end,
				disabled=function(info) return not E.db.global.ignoreTanks end,
				min=0,
				max=2,
				step=0.1
			},
		}
	}
end