
IdxBattleShout = 1
IdxCommandingShout = 2

IdxBerserkerRage = 3 -- available and not enraged
IdxBloodsurge = 4 -- alert on buff
IdxBloodthirst = 5 -- available
IdxCollossusSmashDebuff = 6 -- debuff and available
IdxExecute = 7 -- available
IdxImpendingVictory = 8 -- available
IdxOhShit = 9 -- low health
IdxMeatCleaver = 10 -- 3 stacks of buff
IdxMortalStrike = 11 -- available
IdxOverPower = 12 -- available
IdxRageDump = 13 -- high rage
IdxRagingBlow = 14 -- available
IdxRevenge = 15 -- available
IdxShieldSlam = 16 -- available
IdxShout = 17 -- available and low rage
IdxSlam = 18 -- available and collosus smash debuff active
IdxThunderClap = 19 -- available
IdxUltimatum = 20 -- alert on buff
IdxWeakenedBlows = 21 -- alert on no debuff
IdxWhirlWind = 22 -- available

IdxScanBegin = 1
IdxScanEnd = 22

IdxCheckBoxBegin = 3
IdxCheckBoxEnd = 22

IdxAllBegin = 1
IdxAllEnd = 22

IdxLastUnused = 26

IdxArms = 31
IdxFury = 32
IdxProt = 33

ProfileBoxBS = 310
ProfileBoxCS = 320

ProcTable = {}
WarriorProcAlertInitialized = false

function WarriorProcAlertDetectBuff ( index )
	if ( InCombatLockdown() and CheckInteractDistance("target", 2) ) then
		local name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff("player", ProcTable[index].DetectBuff)	
		if (name ~= nil ) then
			WarriorProcAlertAbilityAvailable ( index )
		end
	end
end

function WarriorProcAlertDetectDebuffAbsence ( index )
	local nonstackingdetected = false

	if ( InCombatLockdown() and CheckInteractDistance("target", 2) ) then
		if ProcTable[index].NonStackingBuffs then
			for proc, procname in pairs(ProcTable[index].NonStackingBuffs) do
				name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", procname)
				if ( name ~= nil ) then
					nonstackingdetected = true
				end
			end
		end
		
		name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", ProcTable[index].DetectBuff)
		if ( 	not nonstackingdetected and 
				(name == nil or ( expirationTime ~= nil and (-1*(GetTime()-expirationTime)) < ProcTable[index].TimeLimit) )  ) then
               WarriorProcAlertAbilityAvailable ( index )
		end	
	end
	
end

function WarriorProcAlertDetectDebuff ( index )
	local nonstackingdetected = false

	if ( InCombatLockdown() and CheckInteractDistance("target", 2) ) then
		if ProcTable[index].NonStackingBuffs then
			for proc, procname in pairs(ProcTable[index].NonStackingBuffs) do
				name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", procname)
				if ( name ~= nil ) then
					nonstackingdetected = true
				end
			end
		end
		
		name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", ProcTable[index].DetectBuff)
		if ( 	not nonstackingdetected and 
				(name ~= nil )  ) then
               WarriorProcAlertAbilityAvailable ( index )
		end	
	end
	
end

function WarriorProcAlertDetectBuffAbsence ( index )
    local nonstackingdetected = false

	if ProcTable[index].NonStackingBuffs then
		for proc, procname in pairs(ProcTable[index].NonStackingBuffs) do
			name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff("player", procname)
			if ( name ~= nil ) then
				nonstackingdetected = true
			end
		end
	end

	name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff("player", ProcTable[index].DetectBuff)	
	if ( not nonstackingdetected and
		not UnitIsPVPSanctuary("player") and
		(name == nil or ( expirationTime ~= nil and (-1*(GetTime()-expirationTime)) < ProcTable[index].TimeLimit) ) ) then
        WarriorProcAlertAbilityAvailable ( index )
	end
	
end

function WarriorProcAlertDetectRage ( index )
    
	if ( InCombatLockdown() and CheckInteractDistance("target", 2) ) then
		if 75 < UnitPower ("player") then
			ProcTable[index].Procced = true
			ProcTable[index].Timer = format("%.1f", 0)
		end
	end
end

function WarriorProcAlertDetectStackingDebuff ( index )
	
	local nonstackingdetected = false
	
	if ( InCombatLockdown() and CheckInteractDistance("target", 2) ) then
		if ProcTable[index].NonStackingBuffs then
			for proc, procname in pairs(ProcTable[index].NonStackingBuffs) do
				name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", procname)
				if ( name ~= nil ) then
					nonstackingdetected = true
				end
			end
		end
		
		local usable = IsUsableSpell (ProcTable[index].Name)
		
		local name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitDebuff("target", ProcTable[index].Name)
		if ( 	not nonstackingdetected and 
				ProcTable[index].Cost <= UnitPower ("player") and
				usable ~= nil and
					(name == nil or 
					(expirationTime ~= nil and (expirationTime-GetTime()) < ProcTable[index].TimeLimit) or  
					(count ~= nil and count < 3)  )  ) then
			
			ProcTable[index].Procced = true
			
			if count == nil or expirationTime == nil then
				ProcTable[index].Timer = format("%.1f", 0)
			elseif ( count < 3 ) then
				ProcTable[index].Timer = format("Stacks %d", count)
			elseif (expirationTime-GetTime()) < 5 then
				ProcTable[index].Timer = format("%.1f", (expirationTime-GetTime()))
			
			end
		end	
	end
end

function WarriorProcAlertDetectStackingBuff ( index )

	if ( InCombatLockdown() ) then
		
		local name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitBuff("player", ProcTable[index].Name)
		if ( 	ProcTable[index].Cost <= UnitPower ("player") and
				(name ~= nil )  )then
			ProcTable[index].Procced = true
			ProcTable[index].Timer = format("%.1f", 0)
			ProcTable[index].Rank = ProcTable[index].BaseRank + (count * ProcTable[index].Stack)
		end	
	end

end

function WarriorProcAlertDetectOhShit ( index )
    
	if InCombatLockdown() then
		if .3 > UnitHealth("player")/UnitHealthMax("player") then
			ProcTable[index].Procced = true
			ProcTable[index].Timer = format("%.1f", 0)
		end
	end
end

function WarriorProcAlertAbilityAvailable ( index )

	local name = GetSpellInfo(ProcTable[index].ID)
	local start, duration, enabled = GetSpellCooldown(name)
	
	if  start and
		duration < 2 and
		ProcTable[index].Cost <= UnitPower ("player")and
		IsUsableSpell(name) then

		ProcTable[index].Procced = true
		ProcTable[index].Timer = format("%.1f", duration)
	end
end

function WarriorProcAlertShout ( index )
	if UnitPower ("player") >= 30 and ProcTable[index].Procced then
	    WarriorProcAlertAbilityAvailable( index )
	end
end

function WarriorProcAlertAbilityReady ( index )
	if ( InCombatLockdown() and CheckInteractDistance("target", 2) ) then
		WarriorProcAlertAbilityAvailable( index )
	end
end

local function DeepCopy ( Source )

	local Dest = {}
	for Key, Val in pairs(Source) do
		Key = type(Key) == "table" and DeepCopy(Key) or Key
		Val = type(Val) == "table" and DeepCopy(Val) or Val
		Dest[Key] = Val
	end
	return Dest
end

function initWarriorProcAlertTable ()

	local ProcEntry = {
	ID = 88163,
	Rank = 0,
	BaseRank = 0,
	Procced = false,
	NonStackingBuffs = nil, 
	Name = nil,
	Timer = format("%.1f", 0),
	TimeLimit = 5,
	Cost = 0,
	Color = { 0, 0, 0, 0 },
	Type = nil,
	Detect = nil,
	Talent = nil,
	Texture = nil,
    DetectBuff = nil,
    Stack = 0
	}
	
	for procnum = IdxAllBegin, IdxAllEnd do
		ProcTable[procnum] = DeepCopy(ProcEntry)
	end
    
    ProcTable[IdxBattleShout].ID = 6673 -- available and not enraged
    ProcTable[IdxBattleShout].Rank = 200
	ProcTable[IdxBattleShout].Name, _, ProcTable[IdxBattleShout].Texture, ProcTable[IdxBattleShout].Cost = GetSpellInfo(ProcTable[IdxBattleShout].ID)
    ProcTable[IdxBattleShout].Color = { .33, .33, .33, 1}
    ProcTable[IdxBattleShout].DetectBuff = GetSpellInfo(6673)
    ProcTable[IdxBattleShout].Type = WarriorProcAlertDetectBuffAbsence
    ProcTable[IdxBattleShout].NonStackingBuffs = {hornofwinter = GetSpellInfo(57330), trueshot = GetSpellInfo(19506)}
    
    ProcTable[IdxCommandingShout].ID = 469 -- available and not enraged
    ProcTable[IdxCommandingShout].Rank = 200
	ProcTable[IdxCommandingShout].Name, _, ProcTable[IdxCommandingShout].Texture, ProcTable[IdxCommandingShout].Cost = GetSpellInfo(ProcTable[IdxCommandingShout].ID)
    ProcTable[IdxCommandingShout].Color = { .33, .33, .33, 1}
    ProcTable[IdxCommandingShout].DetectBuff = GetSpellInfo(469)
    ProcTable[IdxCommandingShout].Type = WarriorProcAlertDetectBuffAbsence
    ProcTable[IdxCommandingShout].NonStackingBuffs = {fortitude = GetSpellInfo(21562), bloodpact = GetSpellInfo(103127)}
	
    ProcTable[IdxBerserkerRage].ID = 18499 -- available and not enraged
    ProcTable[IdxBerserkerRage].Rank = 150
	ProcTable[IdxBerserkerRage].Name, _, ProcTable[IdxBerserkerRage].Texture, ProcTable[IdxBerserkerRage].Cost = GetSpellInfo(ProcTable[IdxBerserkerRage].ID)
    ProcTable[IdxBerserkerRage].Color = { .33, .33, .33, 1}
    ProcTable[IdxBerserkerRage].DetectBuff = GetSpellInfo(18499)
    ProcTable[IdxBerserkerRage].Type = WarriorProcAlertDetectBuffAbsence
    ProcTable[IdxBerserkerRage].NonStackingBuffs = {enrage = GetSpellInfo(12880)}
    
    ProcTable[IdxBloodsurge].ID = 46915 -- buff
    ProcTable[IdxBloodsurge].Rank = 160
	ProcTable[IdxBloodsurge].Name, _, ProcTable[IdxBloodsurge].Texture = GetSpellInfo(ProcTable[IdxBloodsurge].ID)
	_, _, _, ProcTable[IdxBloodsurge].Cost = GetSpellInfo(100130)
	ProcTable[IdxBloodsurge].Color = { .33, .33, .33, 1}
	ProcTable[IdxBloodsurge].DetectBuff = ProcTable[IdxBloodsurge].Name
    ProcTable[IdxBloodsurge].Type = WarriorProcAlertDetectBuff
    
    ProcTable[IdxBloodthirst].ID = 23881 -- available
    ProcTable[IdxBloodthirst].Rank = 190
	ProcTable[IdxBloodthirst].Name, _, ProcTable[IdxBloodthirst].Texture, ProcTable[IdxBloodthirst].Cost = GetSpellInfo(ProcTable[IdxBloodthirst].ID)
    ProcTable[IdxBloodthirst].Color = { .33, .33, .33, 1}
    ProcTable[IdxBloodthirst].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxCollossusSmashDebuff].ID = 86346 -- debuff and available
    ProcTable[IdxCollossusSmashDebuff].Rank = 185
	ProcTable[IdxCollossusSmashDebuff].Name, _, ProcTable[IdxCollossusSmashDebuff].Texture, ProcTable[IdxCollossusSmashDebuff].Cost = GetSpellInfo(ProcTable[IdxCollossusSmashDebuff].ID)
    ProcTable[IdxCollossusSmashDebuff].Color = { .33, .33, .33, 1}
    ProcTable[IdxCollossusSmashDebuff].DetectBuff = GetSpellInfo(86346)
	ProcTable[IdxCollossusSmashDebuff].TimeLimit = .5
    ProcTable[IdxCollossusSmashDebuff].Type = WarriorProcAlertDetectDebuffAbsence
    
    ProcTable[IdxExecute].ID = 5308 -- available
    ProcTable[IdxExecute].Rank = 180
	ProcTable[IdxExecute].Name, _, ProcTable[IdxExecute].Texture, ProcTable[IdxExecute].Cost = GetSpellInfo(ProcTable[IdxExecute].ID)
    ProcTable[IdxExecute].Color = { .33, .33, .33, 1}
    ProcTable[IdxExecute].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxImpendingVictory].ID = 103840 -- available
    ProcTable[IdxImpendingVictory].Rank = 50
	ProcTable[IdxImpendingVictory].Name, _, ProcTable[IdxImpendingVictory].Texture, ProcTable[IdxImpendingVictory].Cost = GetSpellInfo(ProcTable[IdxImpendingVictory].ID)
    ProcTable[IdxImpendingVictory].Color = { .33, .33, .33, 1}
    ProcTable[IdxImpendingVictory].DetectBuff = GetSpellInfo(34428)
    ProcTable[IdxImpendingVictory].Type = WarriorProcAlertAbilityReady

    ProcTable[IdxOhShit].ID = 118038 -- available
    ProcTable[IdxOhShit].Rank = 210
	ProcTable[IdxOhShit].Name = OhShittext
    _, _, ProcTable[IdxOhShit].Texture, ProcTable[IdxOhShit].Cost = GetSpellInfo(ProcTable[IdxOhShit].ID)
    ProcTable[IdxOhShit].Color = { .33, .33, .33, 1}
    ProcTable[IdxOhShit].Type = WarriorProcAlertDetectOhShit
	
    ProcTable[IdxMeatCleaver].ID = 12950
    ProcTable[IdxMeatCleaver].Rank = 120
	ProcTable[IdxMeatCleaver].BaseRank = 120
	ProcTable[IdxMeatCleaver].Name, _, ProcTable[IdxMeatCleaver].Texture = GetSpellInfo(ProcTable[IdxMeatCleaver].ID)
	_, _, _, ProcTable[IdxMeatCleaver].Cost = GetSpellInfo(85288)
    ProcTable[IdxMeatCleaver].Color = { .33, .33, .33, 1}
    ProcTable[IdxMeatCleaver].Type = WarriorProcAlertDetectStackingBuff
    ProcTable[IdxMeatCleaver].Stack = 10
    
    ProcTable[IdxMortalStrike].ID = 12294 -- available
    ProcTable[IdxMortalStrike].Rank = 190
	ProcTable[IdxMortalStrike].Name, _, ProcTable[IdxMortalStrike].Texture, ProcTable[IdxMortalStrike].Cost = GetSpellInfo(ProcTable[IdxMortalStrike].ID)
    ProcTable[IdxMortalStrike].Color = { .33, .33, .33, 1}
    ProcTable[IdxMortalStrike].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxOverPower].ID = 7384 -- available
    ProcTable[IdxOverPower].Rank = 170
	ProcTable[IdxOverPower].Name, _, ProcTable[IdxOverPower].Texture, ProcTable[IdxOverPower].Cost = GetSpellInfo(ProcTable[IdxOverPower].ID)
    ProcTable[IdxOverPower].Color = { .33, .33, .33, 1}
    ProcTable[IdxOverPower].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxRageDump].ID = 23588
    ProcTable[IdxRageDump].Rank = 20
	ProcTable[IdxRageDump].Name = Ragetext
    _, _, ProcTable[IdxRageDump].Texture, ProcTable[IdxRageDump].Cost = GetSpellInfo(ProcTable[IdxRageDump].ID)
    ProcTable[IdxRageDump].Color = { .33, .33, .33, 1}
    ProcTable[IdxRageDump].Type = WarriorProcAlertDetectRage
	
	ProcTable[IdxRagingBlow].ID = 85288 -- available
    ProcTable[IdxRagingBlow].Rank = 170
	ProcTable[IdxRagingBlow].Name, _, ProcTable[IdxRagingBlow].Texture, ProcTable[IdxRagingBlow].Cost = GetSpellInfo(ProcTable[IdxRagingBlow].ID)
    ProcTable[IdxRagingBlow].Color = { .33, .33, .33, 1}
    ProcTable[IdxRagingBlow].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxRevenge].ID = 6572 -- available
    ProcTable[IdxRevenge].Rank = 280
	ProcTable[IdxRevenge].Name, _, ProcTable[IdxRevenge].Texture, ProcTable[IdxRevenge].Cost = GetSpellInfo(ProcTable[IdxRevenge].ID)
    ProcTable[IdxRevenge].Color = { .33, .33, .33, 1}
    ProcTable[IdxRevenge].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxShieldSlam].ID = 23922 -- available
    ProcTable[IdxShieldSlam].Rank = 290
	ProcTable[IdxShieldSlam].Name, _, ProcTable[IdxShieldSlam].Texture, ProcTable[IdxShieldSlam].Cost = GetSpellInfo(ProcTable[IdxShieldSlam].ID)
	ProcTable[IdxShieldSlam].Color = { .33, .33, .33, 1}
    ProcTable[IdxShieldSlam].Type = WarriorProcAlertAbilityReady
    
    ProcTable[IdxShout].ID = 131736 -- available
    ProcTable[IdxShout].Rank = 80
    ProcTable[IdxShout].Name = Shouttext
	_, _, ProcTable[IdxShout].Texture, ProcTable[IdxShout].Cost = GetSpellInfo(ProcTable[IdxShout].ID)
    ProcTable[IdxShout].Color = { .33, .33, .33, 1}
    ProcTable[IdxShout].Type = WarriorProcAlertShout

    ProcTable[IdxSlam].ID = 1464 -- debuf and available
    ProcTable[IdxSlam].Rank = 175
	ProcTable[IdxSlam].Name, _, ProcTable[IdxSlam].Texture = GetSpellInfo(ProcTable[IdxSlam].ID)
	ProcTable[IdxSlam].Cost = 40
	ProcTable[IdxSlam].Color = { .33, .33, .33, 1}
	ProcTable[IdxSlam].DetectBuff = ProcTable[IdxCollossusSmashDebuff].Name
    ProcTable[IdxSlam].Type = WarriorProcAlertDetectDebuff
    
    ProcTable[IdxThunderClap].ID = 6343 -- available
    ProcTable[IdxThunderClap].Rank = 110
	ProcTable[IdxThunderClap].Name, _, ProcTable[IdxThunderClap].Texture, ProcTable[IdxThunderClap].Cost = GetSpellInfo(ProcTable[IdxThunderClap].ID)
    ProcTable[IdxThunderClap].Color = { .33, .33, .33, 1}
    ProcTable[IdxThunderClap].Type = WarriorProcAlertAbilityReady
	
	ProcTable[IdxWeakenedBlows].ID = 6343 -- debuff and available
    ProcTable[IdxWeakenedBlows].Rank = 260
	_, _, _, ProcTable[IdxWeakenedBlows].Cost = GetSpellInfo(ProcTable[IdxWeakenedBlows].ID)
	ProcTable[IdxWeakenedBlows].Name, _, ProcTable[IdxWeakenedBlows].Texture = GetSpellInfo(115798)
    ProcTable[IdxWeakenedBlows].Color = { .33, .33, .33, 1}
    ProcTable[IdxWeakenedBlows].DetectBuff = GetSpellInfo(115798)
    ProcTable[IdxWeakenedBlows].Type = WarriorProcAlertDetectDebuffAbsence
	
    ProcTable[IdxWhirlWind].ID = 1680 -- available
    ProcTable[IdxWhirlWind].Rank = 110
	ProcTable[IdxWhirlWind].Name, _, ProcTable[IdxWhirlWind].Texture, ProcTable[IdxWhirlWind].Cost = GetSpellInfo(ProcTable[IdxWhirlWind].ID)
    ProcTable[IdxWhirlWind].Color = { .33, .33, .33, 1}
    ProcTable[IdxWhirlWind].Type = WarriorProcAlertAbilityReady

    ProcTable[IdxUltimatum].ID = 78 -- buff
    ProcTable[IdxUltimatum].Rank = 250
	ProcTable[IdxUltimatum].Name, _, ProcTable[IdxUltimatum].Texture = GetSpellInfo(122510)
    ProcTable[IdxUltimatum].Color = { .33, .33, .33, 1}
	ProcTable[IdxUltimatum].DetectBuff = ProcTable[IdxUltimatum].Name
    ProcTable[IdxUltimatum].Type = WarriorProcAlertDetectBuff
	
    WarriorProcAlertInitialized = true
end
	
function GetColor ( Entry )
	return Entry.Color[1], Entry.Color[2], Entry.Color[3], Entry.Color[4]
end
