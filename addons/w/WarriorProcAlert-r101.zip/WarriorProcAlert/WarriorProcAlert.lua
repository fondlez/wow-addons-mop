-------------------------------------------------------------------------------
-- Title: Warrior Proc Alert
-- Author: Lambsauce, KCmilam
-------------------------------------------------------------------------------

--Saved character variables.
WPA1_4_3Saved_Var = {
	Lock = true,
	Showing = false,
	ScalingFactor = 1,
	ShoutBox = 0,
	ProfileBox = 0,
	InstanceOnly = false,
	ShowSpellNames = false,
	
	Profiles = {
		[IdxArms] = {
			Name = Armstext,
			[IdxBerserkerRage] = 1,
			[IdxBloodsurge] = nil,
			[IdxBloodthirst] = nil,
			[IdxCollossusSmashDebuff] = 1,
			[IdxExecute] = 1,
			[IdxImpendingVictory] = 1,
			[IdxOhShit] = 1,
			[IdxMeatCleaver] = nil,
			[IdxMortalStrike] = 1,
			[IdxOverPower] = 1,
			[IdxRageDump] = 1,
			[IdxRagingBlow] = nil,
			[IdxRevenge] = nil,
			[IdxShieldSlam] = nil,
			[IdxShout] = 1,
			[IdxSlam] = 1,
			[IdxThunderClap] = nil,
			[IdxUltimatum] = nil,
		    [IdxWeakenedBlows] = nil,
			[IdxWhirlWind] = nil,
		},
		[IdxFury] = {
			Name = Furytext,
			[IdxBerserkerRage] = 1,
			[IdxBloodsurge] = 1,
			[IdxBloodthirst] = 1,
			[IdxCollossusSmashDebuff] = 1,
			[IdxExecute] = 1,
			[IdxImpendingVictory] = 1,
			[IdxOhShit] = 1,
			[IdxMeatCleaver] = nil,
			[IdxMortalStrike] = nil,
			[IdxOverPower] = nil,
			[IdxRageDump] = 1,
			[IdxRagingBlow] = 1,
			[IdxRevenge] = nil,
			[IdxShieldSlam] = nil,
			[IdxShout] = 1,
			[IdxSlam] = nil,
			[IdxThunderClap] = nil,
			[IdxUltimatum] = nil,
			[IdxWeakenedBlows] = nil,
			[IdxWhirlWind] = nil,
		},
		[IdxProt] = {
			Name = Prottext,
			[IdxBerserkerRage] = 1,
			[IdxBloodsurge] = nil,
			[IdxBloodthirst] = nil,
			[IdxCollossusSmashDebuff] = nil,
			[IdxExecute] = nil,
			[IdxImpendingVictory] = 1,
			[IdxOhShit] = 1,
			[IdxMeatCleaver] = nil,
			[IdxMortalStrike] = nil,
			[IdxOverPower] = nil,
			[IdxRageDump] = 1,
			[IdxRagingBlow] = nil,
			[IdxRevenge] = 1,
			[IdxShieldSlam] = 1,
			[IdxShout] = 1,
			[IdxSlam] = nil,
			[IdxThunderClap] = nil,
			[IdxUltimatum] = 1,
			[IdxWeakenedBlows] = 1,
			[IdxWhirlWind] = nil,
		}
	}
}

local LastDisplayTime = 0
local OptionShow = false

function WPA_Debug(Message)
	DEFAULT_CHAT_FRAME:AddMessage(Message)
end

--Add-on On Load tasks
function WarriorProcAlert_OnLoadOptions(self)
	SLASH_WARRIORPROCALERT1 = "/wproc"
   	SlashCmdList["WARRIORPROCALERT"] = WarriorProcAlert_SlashCommand
    
	WarriorProcAlert_Transparent_Frame:RegisterEvent("ADDON_LOADED")
	WarriorProcAlert_Transparent_Frame:RegisterEvent("PLAYER_ALIVE")
	
	WarriorProcAlertProc_Frame:Hide()
	WarriorProcAlertOptions_Frame:Hide()

	DEFAULT_CHAT_FRAME:AddMessage(STARTtext)
end

local function setProcTableShouts()

	if WPA1_4_3Saved_Var.ShoutBox == ProfileBoxBS then
		ProcTable[IdxBattleShout].Detect = 1
		ProcTable[IdxCommandingShout].Detect = nil
	elseif WPA1_4_3Saved_Var.ShoutBox == ProfileBoxCS then
		ProcTable[IdxBattleShout].Detect = nil
		ProcTable[IdxCommandingShout].Detect= 1
	else
		ProcTable[IdxBattleShout].Detect = nil
		ProcTable[IdxCommandingShout].Detect= nil
	end
end

local function setProcTableDetection( ProfileSet )

	if ProfileSet > 0 then
		for procnum = IdxCheckBoxBegin, IdxCheckBoxEnd do
            rank = nil
			if (ProcTable[procnum].Talent) then
					_, _, _, _, rank = GetTalentInfo(ProcTable[procnum].Talent[1], ProcTable[procnum].Talent[2])
			end
			
			if IsSpellKnown(ProcTable[procnum].ID) or (rank and rank > 0) then
				ProcTable[procnum].Detect = WPA1_4_3Saved_Var.Profiles[ProfileSet][procnum]
			else
				ProcTable[procnum].Detect = nil
			end
		end
    else
		for procnum = IdxCheckBoxBegin, IdxCheckBoxEnd do
            ProcTable[procnum].Detect = nil
        end
	end

	setProcTableShouts()
end

function WarriorProcAlert_OnEvent(event, ...)

	local sourceName = select(1, ...)
	if event == "ADDON_LOADED" and sourceName == "WarriorProcAlert" then
        if WarriorProcAlertInitialized == false then
            initWarriorProcAlertTable ()
        end

        if (WPA1_4_3Saved_Var.Showing) then
            WarriorProcAlertProc_Frame:Show()
        end

        local combobox = getglobal("WarriorProcAlertOptions_FrameShoutComboBox")
        UIDropDownMenu_Initialize(combobox, WarriorProcAlertOptions_ShoutDropDownMenu_OnLoad)
        combobox = getglobal("WarriorProcAlertOptions_FrameProfileComboBox")
		UIDropDownMenu_Initialize(combobox, WarriorProcAlertOptions_ProfileDropDownMenu_OnLoad)

		setProcTableDetection(WPA1_4_3Saved_Var.ProfileBox)
	end
	if event == "PLAYER_ALIVE" then
		setProcTableDetection(WPA1_4_3Saved_Var.ProfileBox)
	end
end
	
--Register the slash commands
function WarriorProcAlert_SlashCommand(msg)

	msg = string.lower(msg)
	local args = {}
	
	for word in string.gmatch(msg, "[^%s]+") do
		table.insert(args, word)
	end
		
	if ( args[1] ) then
		if ( args[1] == "options" ) then
			WarriorProcAlertOptions_Toggle()
			
		elseif ( args[1] == "help" ) then
			DEFAULT_CHAT_FRAME:AddMessage(USAGEtext)
			
		elseif ( args[1] == "show" ) then
			WPA1_4_3Saved_Var.Showing = not WPA1_4_3Saved_Var.Showing
			
		elseif ( args[1] == "lock" ) then
			WPA1_4_3Saved_Var.Lock = not WPA1_4_3Saved_Var.Lock
			
		elseif ( args[1] == "bs" ) then
			WarriorProcAlert_UpdateShout( ProfileBoxBS )
			
		elseif ( args[1] == "cs" ) then
			WarriorProcAlert_UpdateShout( ProfileBoxCS )
			
		elseif ( args[1] == "protection" ) then
			WarriorProcAlert_UpdateProfile ( IdxProt )
			
		elseif ( args[1] == "arms" ) then
			WarriorProcAlert_UpdateProfile ( IdxArms )
		 
		elseif ( args[1] == "fury" ) then
			WarriorProcAlert_UpdateProfile ( IdxFury )
			
		else
			DEFAULT_CHAT_FRAME:AddMessage(USAGEtext)
		end
		
	else
		DEFAULT_CHAT_FRAME:AddMessage(USAGEtext)
	end
end

function WarriorProcAlert_Transparent_Update()
    if ( LastDisplayTime < 10 ) then
        LastDisplayTime = LastDisplayTime + 1
    else
        LastDisplayTime = 0
        WarriorProcAlert_OnDisplay()
    end
end

function WarriorProcAlert_OnDisplay()

	if WPA1_4_3Saved_Var.Showing and 
		((not WPA1_4_3Saved_Var.InstanceOnly) or 
			(WPA1_4_3Saved_Var.InstanceOnly and IsInInstance()))
		then
		
		for procnum = IdxScanBegin, IdxScanEnd do
            if ProcTable[procnum].Detect ~= nil and ProcTable[procnum].Type ~= nil then
				ProcTable[procnum].Type(procnum)
			end
		end

		local Highest_Rank = 0
		local Highest_Index = 0

		for procnum = IdxAllBegin, IdxAllEnd do
			if (ProcTable[procnum].Procced and ProcTable[procnum].Rank > Highest_Rank) then
				Highest_Rank = ProcTable[procnum].Rank
				Highest_Index = procnum
			end
		end

		local ProcAvailable = false

		if Highest_Rank ~= 0 then
			ProcAvailable = true
			WarriorProcAlertProc_Frame:Show()
			WarriorProcAlertProc_Frame_Timer:SetText(ProcTable[Highest_Index].Timer)
			WarriorProcAlertProc_Frame_Image:SetTexture(ProcTable[Highest_Index].Texture)
			if WPA1_4_3Saved_Var.ShowSpellNames then
				WarriorProcAlertProc_Frame_Name:SetText(ProcTable[Highest_Index].Name)
			else
				WarriorProcAlertProc_Frame_Name:SetText("")
			end
		end

        if not ProcAvailable then
            WarriorProcAlertProc_Frame:Hide()
        end

		for procnum = IdxScanBegin, IdxScanEnd do
			ProcTable[procnum].Procced = false
		end

	else
		WarriorProcAlertProc_Frame:Hide()
	end
end

function WarriorProcAlert_Lock(self)
	WPA1_4_3Saved_Var.Lock = not WPA1_4_3Saved_Var.Lock
	self:SetChecked(WPA1_4_3Saved_Var.Lock)
end

function WarriorProcAlert_DependencyButton(self)
	
	--Try using getglobal...give it a name and it returns the object!
	if self:GetChecked() then
		WarriorProcAlertOptions_FramechkInstance:Enable()
		WarriorProcAlertOptions_FramechkSpellNames:Enable()
	else
		WarriorProcAlertOptions_FramechkInstance:SetChecked(false)
		WarriorProcAlertOptions_FramechkInstance:Disable()
		
		WarriorProcAlertOptions_FramechkSpellNames:SetChecked(false)
		WarriorProcAlertOptions_FramechkSpellNames:Disable()
	end

end

function WarriorProcAlert_UpdateShout( newValue )
	
	if WPA1_4_3Saved_Var.ShoutBox == newValue then
		WPA1_4_3Saved_Var.ShoutBox = 0
	else		
		WPA1_4_3Saved_Var.ShoutBox = newValue
	end
	
	setProcTableShouts()
	UIDropDownMenu_SetSelectedValue(WarriorProcAlertOptions_FrameShoutComboBox, WPA1_4_3Saved_Var.ShoutBox)
	if WPA1_4_3Saved_Var.ShoutBox == 0 then
		WarriorProcAlertOptions_FrameShoutComboBoxText:SetText ( Nonetext )
	end
end

function WarriorProcAlert_SetChecks ( ProcEntry )
	
	if ProcEntry ~= nil then
        for procnum = IdxCheckBoxBegin, IdxCheckBoxEnd do
            getglobal("WarriorProcAlertOptions_FrameCheckButton"..procnum):SetChecked(ProcEntry[procnum])
        end
        
	else
		for procnum = IdxCheckBoxBegin, IdxCheckBoxEnd do
            getglobal("WarriorProcAlertOptions_FrameCheckButton"..procnum):SetChecked(false)
        end
        
	end
end

function WarriorProcAlert_GetChecks ()
	
	if WPA1_4_3Saved_Var.ProfileBox > 0 then
		-- Saves the old values
        for procnum = IdxCheckBoxBegin, IdxCheckBoxEnd do
			WPA1_4_3Saved_Var.Profiles[WPA1_4_3Saved_Var.ProfileBox][procnum] = getglobal("WarriorProcAlertOptions_FrameCheckButton"..procnum):GetChecked()
		end
    end
end

function WarriorProcAlert_UpdateProfile ( newValue )

	WarriorProcAlert_GetChecks()
	
	if WPA1_4_3Saved_Var.ProfileBox == newValue then
        
		WPA1_4_3Saved_Var.ProfileBox = 0
		UIDropDownMenu_SetSelectedValue(WarriorProcAlertOptions_FrameProfileComboBox, 0)
		WarriorProcAlertOptions_FrameProfileComboBoxText:SetText ( Nonetext )
	else
        
		UIDropDownMenu_SetSelectedValue(WarriorProcAlertOptions_FrameProfileComboBox, newValue)
		WPA1_4_3Saved_Var.ProfileBox = newValue
	end
		
	-- Sets the alert for the new value
	setProcTableDetection( WPA1_4_3Saved_Var.ProfileBox )

	-- Set Buttons if visible
	if OptionShow then
		WarriorProcAlert_SetChecks ( WPA1_4_3Saved_Var.Profiles[WPA1_4_3Saved_Var.ProfileBox] )
	end
end

function WarriorProcAlertOptions_ClickShoutComboBox(self)

	if self:GetName() == "DropDownList1Button1" then
		WarriorProcAlert_UpdateShout( ProfileBoxBS )
	elseif self:GetName() == "DropDownList1Button2" then
		WarriorProcAlert_UpdateShout( ProfileBoxCS )
	end
end

function WarriorProcAlertOptions_ClickProfileComboBox(self)

	if self:GetName() == "DropDownList1Button1" then
		WarriorProcAlert_UpdateProfile( IdxArms )
	elseif self:GetName() == "DropDownList1Button2" then
		WarriorProcAlert_UpdateProfile( IdxFury )
	elseif self:GetName() == "DropDownList1Button3" then
		WarriorProcAlert_UpdateProfile( IdxProt )
	end
end

function WarriorProcAlertOptions_ShoutDropDownMenu_OnLoad()
	
	if WarriorProcAlertInitialized == false then
		initWarriorProcAlertTable ()
	end
	
	info = {}
	
	info.text       = ProcTable[IdxBattleShout].Name
	info.value      = ProfileBoxBS
	info.func       = WarriorProcAlertOptions_ClickShoutComboBox
	if ( WPA1_4_3Saved_Var.ShoutBox == ProfileBoxBS ) then
		info.checked 	= true
		WarriorProcAlertOptions_FrameShoutComboBoxText:SetText ( ProcTable[IdxBattleShout].Name )
	else
		info.checked 	= false
	end
	UIDropDownMenu_AddButton(info)
	
	info.text       = ProcTable[IdxCommandingShout].Name
	info.value      = ProfileBoxCS
	info.func       = WarriorProcAlertOptions_ClickShoutComboBox
	if ( WPA1_4_3Saved_Var.ShoutBox == ProfileBoxCS ) then
		info.checked 	= true
		WarriorProcAlertOptions_FrameShoutComboBoxText:SetText ( ProcTable[IdxCommandingShout].Name )
	else
		info.checked 	= false
	end
	UIDropDownMenu_AddButton(info)

end

function WarriorProcAlertOptions_ProfileDropDownMenu_OnLoad()

	info = {}
   
	for index = IdxArms, IdxProt do
		info.text       = WPA1_4_3Saved_Var.Profiles[index].Name
		info.value      = index
		info.func       = WarriorProcAlertOptions_ClickProfileComboBox
		if ( WPA1_4_3Saved_Var.ProfileBox == index ) then
			info.checked = true
		else
			info.checked = false
		end
	
		UIDropDownMenu_AddButton(info)
	end
end

--Shows and hides the options frame.
function WarriorProcAlertOptions_Toggle()
	
	OptionShow = not OptionShow
	
	if OptionShow then
		WarriorProcAlertOptions_Frame:Show()
        
		-- Set Labels for top checkboxes
		WarriorProcAlertOptions_FramechkShowText:SetText(Showtext)
		WarriorProcAlertOptions_FramechkInstanceText:SetText(Instancetext)
		WarriorProcAlertOptions_FramechkSpellNamesText:SetText(ShowSpellNamestext)
		
		WarriorProcAlertOptions_FramechkLockText:SetText(Locktext)
		
		-- Set invisible
		for procnum = IdxCheckBoxEnd+1, IdxLastUnused do
            getglobal("WarriorProcAlertOptions_FrameCheckButton"..procnum):Hide()
		end
		
		-- Set the Labels for the checkboxes
        for procnum = IdxCheckBoxBegin, IdxCheckBoxEnd do
			--getglobal("WarriorProcAlertOptions_FrameCheckButton"..procnum):Show()
            getglobal("WarriorProcAlertOptions_FrameCheckButton"..procnum.."Text"):SetText(ProcTable[procnum].Name)
		end
		
		-- Set the Labels for ComboBoxes
		WarriorProcAlertOptions_ProfileDropDownMenu_OnLoad()
		UIDropDownMenu_SetSelectedValue(WarriorProcAlertOptions_FrameProfileComboBox, WPA1_4_3Saved_Var.ProfileBox)
		if WPA1_4_3Saved_Var.ProfileBox == 0 then
			WarriorProcAlertOptions_FrameProfileComboBoxText:SetText ( Nonetext )
			WarriorProcAlert_SetChecks ( nil )
		else
			WarriorProcAlert_SetChecks ( WPA1_4_3Saved_Var.Profiles[WPA1_4_3Saved_Var.ProfileBox] )
		end
		
		WarriorProcAlertOptions_ShoutDropDownMenu_OnLoad()
		UIDropDownMenu_SetSelectedValue(WarriorProcAlertOptions_FrameShoutComboBox, WPA1_4_3Saved_Var.ShoutBox)
		
		if WPA1_4_3Saved_Var.ShoutBox == 0 then			
			WarriorProcAlertOptions_FrameShoutComboBoxText:SetText ( Nonetext )
		end

		-- Set the Checkboxes themselves
		WarriorProcAlertOptions_FramechkShow:SetChecked(WPA1_4_3Saved_Var.Showing)
		WarriorProcAlert_DependencyButton(WarriorProcAlertOptions_FramechkShow)
		WarriorProcAlertOptions_FramechkInstance:SetChecked(WPA1_4_3Saved_Var.InstanceOnly)
		WarriorProcAlertOptions_FramechkSpellNames:SetChecked(WPA1_4_3Saved_Var.ShowSpellNames)
		WarriorProcAlertOptions_FramechkLock:SetChecked(WPA1_4_3Saved_Var.Lock)
			
	else
		WarriorProcAlertOptions_Frame:Hide()
		
		WPA1_4_3Saved_Var.Showing = WarriorProcAlertOptions_FramechkShow:GetChecked()
		WPA1_4_3Saved_Var.InstanceOnly = WarriorProcAlertOptions_FramechkInstance:GetChecked()
		WPA1_4_3Saved_Var.ShowSpellNames = WarriorProcAlertOptions_FramechkSpellNames:GetChecked()
		WPA1_4_3Saved_Var.Lock = WarriorProcAlertOptions_FramechkLock:GetChecked()
		
		WarriorProcAlert_GetChecks ()
		
		WPA1_4_3Saved_Var.ShoutBox = UIDropDownMenu_GetSelectedValue ( WarriorProcAlertOptions_FrameShoutComboBox )
		WPA1_4_3Saved_Var.ProfileBox = UIDropDownMenu_GetSelectedValue ( WarriorProcAlertOptions_FrameProfileComboBox )
		
		setProcTableDetection( WPA1_4_3Saved_Var.ProfileBox )
	end
end
