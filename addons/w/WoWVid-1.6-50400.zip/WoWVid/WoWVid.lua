--  WoWVid Addon
--
--	Changelog :
--
--		Dridzt
--		V.1.51.40000 - 29.10.2010
--			- Don't capture mouse when locked'.
--			- Make options window draggable from title.
--			- Throttle OnUpdate for better performance.
--
--		V.1.5.40000 - 29.10.2010
--			- Updated for WoW 4.x (Dridzt)
--
--		Norpse
--		V.1.4.1700 - 25.09.2005
--			- Updated TOC number
--
--		V.1.3.1500 - 06.08.2005
--			- Added check for button show/hide on login
--
--		V.1.2.1500 - 06.07.2005
--			- Updated TOC number
--
--		V.1.1.1300 - 04.25.2005
--			- Added Keybindings
--			- Fixed slash commands issues		
--
--		V.1.0
--			- initial release
--


-- Variables
WoWVid = {
	Red = 16,
  Green = 0,
  Blue = 16,
  Locked = 0,
  Button = 1,
  Pos = 321,
  Show = 1
};

local lastupdate

BINDING_HEADER_WOWVID_TITLE = "WoWVid";
WOWVID_OPTIONS_TITLE = "WoWVid v"..GetAddOnMetadata("WoWVid","Version");
WOWVID_PRESETS = "Presets"
WOWVID_INPUT_PRESET = "New preset"

function WoWVid_OnLoad(self)
	self:RegisterEvent("VARIABLES_LOADED");
	
	WoWVidFrame:RegisterForDrag("LeftButton");

	SlashCmdList["WOWVIDCOMMAND"] = WoWVid_SlashHandler;
	SLASH_WOWVIDCOMMAND1 = "/wowvid";
	SLASH_WOWVIDCOMMAND2 = "/wv";
	
	lastupdate = 0
end

function WoWVid_OnEvent (self, event, ...)
	if (event == "VARIABLES_LOADED") then
		WoWVid_OnUpdate();
		WoWVidOptionsFrame_OnLoad();
		WoWVid_Button_UpdatePosition();
	end
end

function WoWVid_OnDragStart(self)
	if (WoWVid.Locked == 0) then	
		WoWVidFrame:StartMoving();
	end
end

function WoWVid_OnUpdate(self, elapsed)
	if (not elapsed) or (lastupdate+elapsed > 0.2) then
		WoWVidBackground:SetVertexColor((WoWVid.Red / 255),(WoWVid.Green / 255),(WoWVid.Blue / 255));
		
		if ( WoWVid.Show == 0 ) then
			WoWVidFrame:Hide();
		elseif ( WoWVid.Show == 1 ) then
			WoWVidFrame:Show();
		end	
		
		-- this checks if the frame is smaller than 10 in height/width 
		if ( WoWVidFrame:GetWidth() < 10 ) then
			WoWVidFrame:SetWidth(10);
		end
		if ( WoWVidFrame:GetHeight() < 10 ) then
			WoWVidFrame:SetHeight(10);
		end
		lastupdate = 0
	end
end

function WoWVid_ResizeBtnDragStart(self, button)
	if (WoWVid.Locked == 0) then
		WoWVidFrame:StartSizing();
	end
end

function WoWVid_ResizeBtnDragStop(self, button)
	if (WoWVid.Locked == 0) then	
		WoWVidFrame:StopMovingOrSizing();
	end
end


function WoWVidShow_Toggle()
	if(WoWVidFrame:IsVisible()) then
		WoWVidFrame:Hide();
		WoWVid.Show = 0;
	else
		WoWVidFrame:Show();
		WoWVid.Show = 1;
	end
	WoWVidOptionsFrame_OnLoad();
end

function WoWVidButtonShow_Toggle()
	if(WoWVid_Button:IsVisible()) then
		WoWVid_Button:Hide();
		WoWVid.Button = 0;
	else
		WoWVid_Button:Show();
		WoWVid.Button = 1;
	end
	WoWVidOptionsFrame_OnLoad();
end

function WoWVid_SlashHandler(msg)
-- This function is called when a user types one of your slash commands
-- the text they enter after the command comes in msg
	msg = string.lower (msg);
	if (msg == "") then
		DEFAULT_CHAT_FRAME:AddMessage("/wowvid or /wv  - this menu");
		DEFAULT_CHAT_FRAME:AddMessage("/wowvid toggle - Toggle WoWVid Frame");
		DEFAULT_CHAT_FRAME:AddMessage("/wowvid button - Toggle Minimap Button");
		DEFAULT_CHAT_FRAME:AddMessage("/wowvid lock - Toggle Lock");
		DEFAULT_CHAT_FRAME:AddMessage("/wowvid config - Toggle Option Panel");
	elseif (msg == "toggle") then
		WoWVidShow_Toggle();
	elseif (msg == "button") then
		WoWVidButtonShow_Toggle();
	elseif (msg == "lock") then
		WoWVidLock_Toggle();
	elseif (msg == "config") then
		ShowUIPanel(WoWVidOptionsFrame);
	end
end