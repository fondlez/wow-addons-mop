** WoWVid **

By: Norpse


WoWVid creates an blank frame with adjustable RBG values, using this
frame.  The blank frame with the proper color set will allow video to
"show through" being played by any other software operating in overlay
mode.  Most TV software and most accelerated DVD or video playback
software operates in overlay mode as it reduces CPU usage.

Options
-------
Move
Resize
Lock/Unlock
Hide/Show
Custom background

Left-clicking the WoWVid icon on your minimap will toggle the option menu
where you can change the background color with 3 sliders.  There is also
an option to show/hide the Frame.  Right-clicking on the WoWVid icon will
lock the frame so it cannot be moved or resized.

----------

If you are using one of the following players you dont need to change the RBG values in the options:

Windows Media Player
Winamp
RealPlayer

----------

1) Play a video on the player. Resize it to be the size that you want it to show up in game and place it on your desktop to where you want it to be in game
2) Run WoW. Once youve selected your character and are in game there should be a BLACK window in WoW. If not open the options window by R-Clicking the WV Icon on your minimap. Make sure the box next to Show/Hide WoWVid is checked
3) Move the black box by dragging it to where you placed you player on your desktop. You can resize WoWVid if needed by using the little resize circle in lower right corner of the WoWVid Window. It is important that the WoWVid Window and your Player window line up or you will see no video.

----------

credits to the WoWTV original author (Unknown)

please note: This AddOn is a recode of WoWTV with multiple options added

----------

To find out what color to set the background color to for your TV software do the following:
1. Open your tv software.
2. Hit the Print Screen button next to the scroll lock on your keyboard.
3. Open MS Paint (Start->Run, type in mspaint.exe and click ok)
4. Go to the Edit menu and select paste.
5. Click on the eye-dropper tool from the tools on the left side.
6. click in the blank area (where the video would normally be) of the TV software in the screen shot.
** Note if the video area of the TV software in the screen shot is not all one color, but an actual still image of whatever you were watching at the time, the TV software is not in overlay mode and the WoWVid mod will not work.
7. Go to the colors menu and select Edit Colors...
8. Click on the Define Custom Colors button
9. The values you need to set the WoWVid mod will be listed in the Red, Green, Blue settings.
