local presets = {}
presets[1] = {["name"] = "Default", ["red"]=16,["green"]=0,["blue"]=16}
presets[2] = {["name"] = "VideoLAN", ["red"]=0,["green"]=0,["blue"]=1}
presets[3] = {["name"] = "KMPlayer", ["red"]=15,["green"]=0,["blue"]=15}
WoWVid.preset = WoWVid.preset or 1

function WoWVidOptions_Toggle()
	if(WoWVidOptionsFrame:IsVisible()) then
		WoWVidOptionsFrame:Hide();
	else
		WoWVidOptionsFrame:Show();
	end
end

function WoWVidOptionsFrame_OnShow()
	UIPanelWindows['WoWVidOptionsFrame'] = {area = 'center', pushable = 0};
end

function WoWVidOptionsFrame_OnLoad()
	WoWVid.presets = WoWVid.presets or presets
	presets = WoWVid.presets
	WoWVidOptionsFrame:SetBackdropColor(0, 0, 0, 1);
	WoWVidOptionsFrameToggleButton:SetChecked(WoWVid.Show);
	WoWVidOptionsButtonToggleButton:SetChecked(WoWVid.Button);
	SliderPos:SetValue(WoWVid.Pos);
	SliderRed:SetValue(WoWVid.Red);
	SliderGreen:SetValue(WoWVid.Green);
	SliderBlue:SetValue(WoWVid.Blue);
	UIDropDownMenu_SetText(WoWVidOptionsFramePresetsDropdown, presets[WoWVid.preset]["name"])
end

function WoWVidOptions_Reset()
	WoWVid.preset = 1
	SliderRed:SetValue(WoWVid.presets[1]["red"])
	SliderGreen:SetValue(WoWVid.presets[1]["green"])
	SliderBlue:SetValue(WoWVid.presets[1]["blue"])
	UIDropDownMenu_SetSelectedValue(WoWVidOptionsFramePresetsDropdown,WoWVid.preset)
	UIDropDownMenu_SetText(WoWVidOptionsFramePresetsDropdown, presets[WoWVid.preset]["name"])
end

function WoWVidOptionsSetPreset(value)
	WoWVid.preset = value
	SliderRed:SetValue(presets[value]["red"])
	SliderGreen:SetValue(presets[value]["green"])
	SliderBlue:SetValue(presets[value]["blue"])
end

function WoWVidPresetsDropdown_OnLoad(self)
	UIDropDownMenu_Initialize(self, WoWVidPresetsDropdown_Initialize)
	UIDropDownMenu_SetWidth(WoWVidOptionsFramePresetsDropdown,100)
end

function WoWVidPresetsDropdown_Initialize()
	local info = UIDropDownMenu_CreateInfo()
	info.func = WoWVidPresetsDropdown_OnClick
	for k,v in pairs(presets) do
		info.text = presets[k]["name"]
		info.value = k
		UIDropDownMenu_AddButton(info)
	end
	UIDropDownMenu_SetSelectedValue(WoWVidOptionsFramePresetsDropdown, WoWVid.preset);
end

function WoWVidPresetsDropdown_OnClick(self)
	WoWVidOptionsSetPreset(self.value)
	UIDropDownMenu_SetSelectedValue(WoWVidOptionsFramePresetsDropdown, WoWVid.preset);
end

function WoWVidOptionsFrameAddPresetEditBox_OnEnterPressed(self)
	local newpreset = self:GetText()
	newpreset = newpreset and strtrim(newpreset)
	if strlower(newpreset) == strlower(presets[1]["name"]) then
		-- do not modify the default template.
	else
		local found
		local r,g,b = SliderRed:GetValue(), SliderGreen:GetValue(), SliderBlue:GetValue()
		for k,v in pairs(presets) do
			if strlower(presets[k]["name"]) == strlower(newpreset) then
				found = true
				presets[k]["red"] = r
				presets[k]["green"] = g
				presets[k]["blue"] = b
			end
		end
		if not found then
			tinsert(presets,{["name"]=newpreset, ["red"]=r, ["green"]=g, ["blue"]=b})
			UIDropDownMenu_ClearAll(WoWVidOptionsFramePresetsDropdown)
			UIDropDownMenu_Initialize(WoWVidOptionsFramePresetsDropdown,WoWVidPresetsDropdown_Initialize)
			UIDropDownMenu_SetSelectedValue(WoWVidOptionsFramePresetsDropdown,WoWVid.preset)
			UIDropDownMenu_SetText(WoWVidOptionsFramePresetsDropdown, presets[WoWVid.preset]["name"])
			WoWVid.presets = presets
		end
	end
	self:SetText("")
	EditBox_ClearFocus(self)
end

function WoWVidOptionsFrameAddPresetEditBox_OnEscapePressed(self)
	self:SetText("")
	EditBox_ClearFocus(self)
end

function WoWVidOptionsFrameDeletePreset_OnClick(self,button)
	local delpreset = UIDropDownMenu_GetSelectedValue(WoWVidOptionsFramePresetsDropdown)
	if (delpreset == 1) then
		-- do nothing, we don't touch the default
	else
		tremove(presets,delpreset)
		UIDropDownMenu_ClearAll(WoWVidOptionsFramePresetsDropdown)
		UIDropDownMenu_Initialize(WoWVidOptionsFramePresetsDropdown,WoWVidPresetsDropdown_Initialize)
		WoWVidOptions_Reset()
		WoWVid.presets = presets		
	end
end