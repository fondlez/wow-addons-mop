-- create new button around the Minimap 
--	left click : lock unlock
--	right click : show hide


function WoWVid_Button_Init()
	if (WoWVid.Locked == nil) then
			WoWVid.Locked = 0;
	end	
	if(WoWVid.Locked == 1) then
		WoWVid_Button:SetChecked(1);
		WoWVidResizeBottomRight:Hide();
		WoWVidFrame:EnableMouse(false);
	else
		WoWVid_Button:SetChecked(0);
		WoWVidResizeBottomRight:Show();
		WoWVidFrame:EnableMouse(true);
	end
	
	if (WoWVid.Button == nil) then
			WoWVid.Button = 1;
	end
	if(WoWVid.Button == 0) then
		WoWVid_Button:Hide();
	else
		WoWVid_Button:Show();
	end
end


function WoWVid_ButtonOnClick(self, button)
	if ( button == "RightButton" ) then
		WoWVidOptions_Toggle();
	else
		if ( WoWVid_Button:GetChecked() ) then
			WoWVid.Locked = 0;
			PlaySound("igMainMenuQuit");
			GameTooltip:SetText("Left Click - Lock WoWVid \nRight Click - Options Menu", 1.0, 1.0, 1.0);
			WoWVidResizeBottomRight:Show();
			WoWVidFrame:EnableMouse(true);
		else
			WoWVid.Locked = 1;
			PlaySound("igMainMenuOption");
			GameTooltip:SetText("Left Click - Unlock WoWVid \nRight Click - Options Menu", 1.0, 1.0, 1.0);
			WoWVidResizeBottomRight:Hide();
			WoWVidFrame:EnableMouse(false)
		end
	end
end

function WoWVid_Button_UpdatePosition()
	WoWVid_Button:SetPoint(
		"TOPLEFT",
		"Minimap",
		"TOPLEFT",
		52 - (80 * cos(WoWVid.Pos)),
		(80 * sin(WoWVid.Pos)) - 52
	);
end

function WoWVidLock_Toggle()
	if( WoWVid_Button:GetChecked() ) then
		WoWVid_Button:SetChecked(0)
		WoWVid.Locked = 0;
		PlaySound("igMainMenuQuit");
		WoWVidResizeBottomRight:Show();
		WoWVidFrame:EnableMouse(true);
	else
		WoWVid_Button:SetChecked(1)
		WoWVid.Locked = 1;
		PlaySound("igMainMenuOption");
		WoWVidResizeBottomRight:Hide();
		WoWVidFrame:EnableMouse(false)
	end
end



-- Tooltip display OnEnter
function WoWVid_ButtonOnEnter(self)
	-- Set Option button tooltip
	GameTooltip:SetOwner(self, "ANCHOR_LEFT");
	if (WoWVid_Button:GetChecked()) then
		GameTooltip:SetText("Left Click - Unlock WoWVid \nRight Click - Options Menu", 1.0, 1.0, 1.0);
	else
		GameTooltip:SetText("Left Click - Lock WoWVid \nRight Click - Options Menu", 1.0, 1.0, 1.0);
	end
end
