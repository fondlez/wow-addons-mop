local qrencode;


local whurl=true;

function reinit()
	local nodes=QR.viewFrame:GetChildren()
	for _,node in ipairs(nodes) do
		node:SetAlpha(0);
		node:ClearAllPoints();
	end
end

function init(event,arg1)
		WQR_VARS={};
		for y=1,40 do
			for x=1,40 do
				local f=CreateFrame("Frame","qr"..x.."_"..y,QR.viewFrame);
				f:SetFrameStrata("DIALOG");
				f:SetWidth(4);
				f:SetHeight(4);
				f.texture = f:CreateTexture();
				f.texture:SetAllPoints(f);
				f.texture:SetTexture(0,0,0);
				f:SetPoint("BOTTOMLEFT",4+(y*4),8+((35-x)*4));
				f:Show();
				f:SetAlpha(0);
			end
		end
end

local function qrgen(str)
	a,t=QR:qrcode(str);
	QR.viewFrame:SetWidth((#t*4)+16)
	QR.viewFrame:SetHeight((#t*4)+16)
	for y=1,#t do
		for x=1,#t[1] do
			reinit();
			local viewFrame = QR.viewFrame;
			if(t[y][x] < 0)then
				_G["qr"..x.."_"..y]:SetAlpha(0);
				_G["qr"..x.."_"..y]:SetPoint("BOTTOMLEFT",4+(y*4),8+((#t-x)*4));
			else
				_G["qr"..x.."_"..y]:SetAlpha(1);
				_G["qr"..x.."_"..y]:SetPoint("BOTTOMLEFT",4+(y*4),8+((#t-x)*4));
			end
		end
	end
end

local function initQR()
	
		
end

SLASH_QRTEST1 = '/qr';
SLASH_QRTARGET1 = '/qrtar';
local function handler(msg, editbox)
	print("Generating QR code for "..msg);
	local t,id=string.match(msg:sub(13),'([a-z]+):([0-9]+)');
	if(t~=nil and id~=nil)then
		
		initQR();
		viewFrame:Show();
		if(t=='enchant' or t=='spell')then
			if(whurl==true)then
				qrgen('www.wowhead.com/spell='..id);
			else
				qrgen('SPELL:'..id);
			end
		elseif(t=='achievement')then
		if(whurl==true)then
				qrgen('www.wowhead.com/achievement='..id);
			else
			qrgen('ACHIEVEMENT:'..id);
			end
		elseif(t=='quest')then
		if(whurl==true)then
				qrgen('www.wowhead.com/quest='..id);
			else
			qrgen('QUEST:'..id);
			end
		elseif(t=='currency')then
		if(whurl==true)then
				qrgen('www.wowhead.com/currency='..id);
			else
			qrgen('CURRENCY:'..id);
			end
		elseif(t=='item')then
		if(whurl==true)then
				qrgen('www.wowhead.com/item='..id);
			else
			qrgen('ITEM:'..id);
			end
		else
			viewFrame:Hide();
			print("This link is not implemented yet");
		end
	else
		msg=string.gsub(msg,' ','+');
		initQR();
		viewFrame:Show();
		if(whurl==true)then
				qrgen('www.wowhead.com/search='..msg);
			else
		qrgen('SEARCH:'..msg);
		end
	end
end

local function handlerb(msg, editbox)

	initQR();
	if(UnitIsPlayer("target")== 1)then
		local name,realm = UnitName("target");
		if(realm == nil)then
			realm = GetRealmName();
		end
		--print('us.battle.net/wow/en/character/'..realm..'/'..name..'/advanced');
		viewFrame:Show();
		qrgen('http://us.battle.net/wow/en/character/'..realm..'/'..name..'/advanced');
		
	elseif(UnitPlayerControlled("target")==1)then
		if(UnitCreatureType("target")=="Non-combat Pet" or UnitCreatureType("target")=="Wild Pet")then
			--This is a non combat pet, so it should have an NPC id. 
			local guid, name = UnitGUID("target"), UnitName("target"); 
			local B = tonumber(guid:sub(5,5), 16);
			local maskedB = B % 8; -- x % 8 has the same effect as x & 0x7 on numbers <= 0xf
			if(maskedB==3)then
				QR.viewFrame:Show();
				if(whurl==true)then
					qrgen('www.wowhead.com/npc='..tonumber(guid:sub(6,10), 16))
				else
					qrgen('NPC:'..tonumber(guid:sub(6,10), 16))
				end
			end
		else
			--Hunter,Warlock,Mage pets. 
			print("unsupported unit");
		end
	else
		local guid, name = UnitGUID("target"), UnitName("target"); 
		local B = tonumber(guid:sub(5,5), 16);
		local maskedB = B % 8; -- x % 8 has the same effect as x & 0x7 on numbers <= 0xf
		if(maskedB==3)then
			QR.viewFrame:Show();
			if(whurl==true)then
				qrgen('www.wowhead.com/npc='..tonumber(guid:sub(6,10), 16))
			else
				qrgen('NPC:'..tonumber(guid:sub(6,10), 16))
			end
		end
	end
end

SlashCmdList["QRTEST"] = handler;
SlashCmdList["QRTARGET"] = handlerb;