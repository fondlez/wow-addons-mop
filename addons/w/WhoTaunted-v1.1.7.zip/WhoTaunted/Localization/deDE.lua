﻿--[[
	German Locale.
]]

local L = LibStub("AceLocale-3.0"):NewLocale("WhoTaunted", "deDE", true);
if not L then return end

L["against"] = "gegen"
L["Announcements"] = "Ankündigungen"
L["Anounce AOE Taunts"] = "Berichte AOE Spots"
L["Anounce AOE Taunts."] = "Berichte AOE Spots"
L["Anounce AOE Taunts Output:"] = "Poste AOE Spot nach:"
L["Anounce Fails"] = "Fehlgeschlagenes anzeigen"
L["Anounce Fails Output:"] = "Ansagenausgabe:"
L["Anounce taunts."] = "Berichte wer spottete"
L["Anounce Taunts"] = "Berichte wer spottete"
L["Anounce Taunts Output:"] = "Ausgabe \"Wer spottete\" nach:"
L["Anounce taunts that fail."] = "Fehlgeschlagene Spotts anzeigen"
L["AOE"] = "Flächenschaden"
L["AOE taunted using"] = "benutzter Flächenschaden" -- Needs review
L["Chat Window"] = "Chat Fenster"
L["Disables Who Taunted?."] = "Deaktiviert Who Taunted?."
L["Disables Who Taunted? while you are in a battleground."] = "Deaktiviert Who Taunted? während du dich in Schlachtfeldern befindest."
L["Disable Who Taunted?"] = "Who Taunted? deaktivieren"
L["Disable Who Taunted? in Battlegrounds"] = "Who Taunted? in Schlachtfelder deaktivieren"
L["Display Ability"] = "Möglichleit ausschalten"
L["Display the ability that was used to taunt."] = "Zeige an, womit gepullt wurde"
L["Don't show your own failed taunts."] = "Zeige eigene fehlgeschlagene Pulls nicht"
L["Don't show your own taunts."] = "Zeige eigene Pulls nicht."
L["etc"] = "etc."
L["Failed:"] = "Fehlgeschlagen:"
L["General"] = "Hauptsächlich."
L["Hide Own Failed Taunts"] = "Verstecke eigene fehlgeschlagene Spots."
L["Hide Own Taunts"] = "Verstecke eigene Spots"
L["Immune"] = "Immun"
L["Include Prefix"] = "mit Präfix"
L["Include the"] = "Mit"
L["off of"] = "runter von"
L["Party"] = "Gruppe"
L["prefix when a message's output is"] = "Präfix wenn "
L["Raid"] = "Schlachtzug"
L["Raid Warning"] = "Schlachtzugswarnung"
L["'s"] = true
L["Say"] = "Sagen"
L["Self"] = "Eigener Chat"
L["Show"] = "Zeige"
L["Target"] = "Ziel"
L["taunt"] = "Spot" -- Needs review
L["taunted"] = "taunted" -- Requires localization
L["taunts"] = "spottet" -- Needs review
L["The chat window taunts will be announced in when the output is set to"] = "The chat window taunts will be announced in when the output is set to" -- Requires localization
L["using"] = "verwendet" -- Needs review
L["Where AOE Taunts will be announced."] = "Wohin sollen Pulls gepostet werden"
L["Where taunts will be announced."] = "Wo sollen Spots ausgegeben werden ?"
L["Where the taunt fails will be announced."] = "Wo der fehlgeschlagene Spott angesagt wird." -- Needs review
L["<WhoTaunted>"] = "<Wer pullte>"
L["Who Taunted?"] = "Wer spottete ?"
L["Yell"] = "Schreien"
