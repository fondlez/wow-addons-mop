-- Which Rank Does What Locale
-- Please use the Localization App on WoWAce to Update this
-- http://www.wowace.com/addons/whichrankdoeswhat/localization/
local nametag = ...
local L = LibStub("AceLocale-3.0"):NewLocale(nametag, "deDE")
if not L then return end

-- L["General options"] = "General options"
-- L["Guild Control for non-GMs"] = "Guild Control for non-GMs"
-- L["Guild flags have changed!"] = "Guild flags have changed!"
-- L["Guild vault information is incomplete.  Be closer to a vault, and give it some time.  You may need to relog and/or open the guild roster/vault to force a client update."] = "Guild vault information is incomplete.  Be closer to a vault, and give it some time.  You may need to relog and/or open the guild roster/vault to force a client update."
-- L["Make the grayed-out Guild Control button activate this addon instead."] = "Make the grayed-out Guild Control button activate this addon instead."
-- L["Show flag columns %d - %d"] = "Show flag columns %d - %d"
-- L["Toggle WRDW window"] = "Toggle WRDW window"
-- L["Use this addon"] = "Use this addon"
-- L["You must close and reopen this window to display the changes."] = "You must close and reopen this window to display the changes."
-- L["You will need to relog or /reload to fully disable this addon."] = "You will need to relog or /reload to fully disable this addon."

