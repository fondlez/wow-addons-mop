-- Which Rank Does What Locale
-- Please use the Localization App on WoWAce to Update this
-- http://www.wowace.com/addons/whichrankdoeswhat/localization/
local nametag = ...
local L = LibStub("AceLocale-3.0"):NewLocale(nametag, "enUS", --[[default=]]true, --[[silent=]]true)

L["General options"] = true
L["Guild Control for non-GMs"] = true
L["Guild flags have changed!"] = true
L["Guild vault information is incomplete.  Be closer to a vault, and give it some time.  You may need to relog and/or open the guild roster/vault to force a client update."] = true
L["Make the grayed-out Guild Control button activate this addon instead."] = true
L["Show flag columns %d - %d"] = true
L["Toggle WRDW window"] = true
L["Use this addon"] = true
L["You must close and reopen this window to display the changes."] = true
L["You will need to relog or /reload to fully disable this addon."] = true

