local L = LibStub("AceLocale-3.0"):NewLocale("WorldBossStatus", "enUS", true)

if not L then
	return
end

L["World Bosses"] = true
L["World Boss Status"] = true

--L["Available"] = true
--L["Defeated"] = true
L["Character"] = true

L["Click to open the options menu"] = true


--L["Include Characters"] = true
--L["Include the following characters in the display."] = true
--L["Active Character Only"] = true
--L["On This Realm"] = true
--L["On This Account"] = true

L["Toggles the display of this world boss."] = true

--General Options
L["General Options"] = true
L["Minimap Button"] = true
L["Toggles the display of the minimap button."] = true

--Character Options
L["Characters"] = true
L["Character Options"] = true
L["Show Characters"] = true
L["On this realm"] = true
L["Show characters on this realm."] = true
L["On this account"] = true
L["Show characters on this WoW account."] = true
L["Enable"] = true
L["Level Restriction"] = true
L["Enable level restriction."] = true
L["Minimum Level"] = true
L["Show characters this level and higher."] = true
L["Hide Inactive Characters"] = true
L["Enable hiding inactive characters."] = true
L["Inactivity Threshold (days)"] = true
L["Hide characters that have been inactive for this many days."] = true
L["Remove Tracked Characters"] = true
L["Realm"] = true
L["Select a realm to remove a tracked character from."] = true
L["Select the tracked character to remove."] = true
L["Remove"] = true
L["Click to remove the selected tracked character."] = true

--Boss Options
L["Bosses"] = true
L["Boss Options"] = true
L["Tracked Bosses"] = true
L["Select the world bosses you would like to track."] = true

--Bonus Roll Options
L["Bonus Rolls"] = true
L["Bonus Roll Options"] = true
L["Track weekly quest"] = true
L["Enable tracking the weekly bonus roll currency quest."] = true
L["Tracked Currencies"] = true
L["Select the currencies you would like to track."] = true