﻿local L = LibStub("AceLocale-3.0"):NewLocale("WorldBossStatus", "zhTW")

if not L then
	return
end

L["Active Character Only"] = "只顯示激活的角色"
L["Available"] = "未擊殺"
L["Character"] = "角色"
L["Click to open the options menu"] = "點擊打開選項菜單"
L["Defeated"] = "已擊殺"
L["Include Characters"] = "包含角色"
L["Include the following characters in the display."] = "顯示包含追踪的角色。"
L["Minimap Button"] = "小地圖按鈕"
L["Minimum Level"] = "最低等級"
L["On This Account"] = "此帳號"
L["On This Realm"] = "此伺服器"
L["Show characters this level and higher."] = "顯示高於此等級的角色。"
L["Toggles the display of the minimap button."] = "切換顯示小地圖按鈕。"
L["Toggles the display of this world boss."] = "切換世界首領顯示。"
L["Undefeated"] = "未擊殺"
L["World Boss Status"] = "世界首領狀態"