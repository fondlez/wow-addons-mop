﻿local L = LibStub("AceLocale-3.0"):NewLocale("WorldBossStatus", "koKR")

if not L then
	return
end

L["Click to open the options menu"] = "옵션 메뉴를 열려면 클릭하세요." -- Needs review
L["Defeated"] = "처치" -- Needs review
L["Minimap Button"] = "미니맵 버튼" -- Needs review
L["Toggles the display of the minimap button."] = "미니맵 버튼을 표시합니다." -- Needs review
L["Undefeated"] = "잔류" -- Needs review
L["World Boss Status"] = "월드 보스 상태" -- Needs review
