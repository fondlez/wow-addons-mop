﻿local L = LibStub("AceLocale-3.0"):NewLocale("WorldBossStatus", "esES")

if not L then
	return
end

L["Active Character Only"] = "Sólo personajes Activos"
L["Available"] = "No derrotado"
L["Character"] = "Personaje"
L["Click to open the options menu"] = "Click para el menú de opciones"
L["Defeated"] = "Derrotado"
L["Include Characters"] = "Incluye los personajes"
L["Include the following characters in the display."] = "Incluye los siguientes personajes en la pantalla."
L["Minimap Button"] = "Botón del minimapa"
L["Minimum Level"] = "Nivel mínimo"
L["On This Account"] = "En esta Cuenta"
L["On This Realm"] = "En este Reino"
L["Show characters this level and higher."] = "Muestra los personajes de este nivel y superior."
L["Toggles the display of the minimap button."] = "Mostrar/Ocultar el botón del minimapa"
L["Toggles the display of this world boss."] = "Activa la pantalla de estos boss del mundo."
L["World Boss Status"] = "Estado de los Jefes del Mundo"