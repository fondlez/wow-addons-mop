if( GetLocale() == "esES" ) then
	
	--Set/Item Procs
--	KHT_BEAST_4PC = "Beast Lord 4-piece bonus";
--	KHT_DRAGON_8PC = "Dragonstalker 8-piece bonus";
--	KHT_DESOLATION_4PC = "Desolation 4-piece bonus";
--	KHT_ZG = "ZG fist weapons"
--	KHT_DON_SANTOS = "Don Santos' Famous Hunting Rifle";
--	KHT_THUNDER = "Thundering Skyfire Diamond";
--	KHT_SCOURGE = "Scourgestalker 4-piece bonus";
--	KHT_ASHEN = "Ashen Band of Vengeance";
--	KHT_BLOOD_HUNTER = "Blood Hunter 2/4-piece bonuses";
--	KHT_WINDRUNNER = "Windrunner 4-piece bonus";
--	KHT_HYPER = "Hyperspeed Accelerators";
--	KHT_FLAMEWAKER = "Flamewaker 4-piece bonus";
--	KHT_WYRMSTALKER = "Wyrmstalker 4-piece bonus";
--	KHT_SAUROK = "Saurok Stalker 2-piece bonus";

	--Trinket Spells
	KHT_ADWT = "Dije de guerra draenei antiguo";
	KHT_ANVIL = "Yunque de titanes";
	KHT_ATOS = "Talism\195\161n Lengua de ceniza de presteza";
	KHT_BERSERK_CALL = "Llamada de rabioso";
	KHT_BLADEFIST = "Placa de Garrafilada";
	KHT_BLOODLUST_BROOCH = "Broche de Ansia de Sangre";
	KHT_ARKELOS = "N\195\186cleo de Ar'kelos";
	KHT_DARK_GREAT = "Naipe de la Luna Negra: Grandeza";
	KHT_DARK_MAD = "Naipe de la Luna Negra: Locura";
	KHT_DARK_WRATH = "Naipe de la Luna Negra: C\195\179lera";
	KHT_VERDICT = "Veredicto de la muerte";
	KHT_DEVIL_EYE = "Ojo de demosaurio";
	KHT_DST = "Trofeo de espinazo de drag\195\179n";
	KHT_EMPTY_MUG = "Jarra de cerveza temible vac\195\173a";
	KHT_HOURGLASS = "Reloj de arena del liberador";
	KHT_MOTB = "Locura de El Traidor";
	KHT_MIRROR = "Espejo de verdad";
	KHT_OGRE = "Distintivo de destructor ogro";
	KHT_PYRITE_INFUSER = "Inyector de pirita";
	KHT_SIGNET_EDWARD = "Sello de Edward el Extra\195\177o";
	KHT_SKY_CROSS = "Cruz de plata de Guardia del cielo";
	KHT_TALON_ALAR = "Garfa de Al'ar";
	KHT_TTP = "Tablilla Terokkar de precisi\195\179n";
	KHT_TSUNAMI_TALISMAN = "Talism\195\161n tsunami";
	KHT_UNITING = "Talism\195\161n de unidad";
	KHT_HERO_MEDALLION = "Medall\195\179n de h\195\169roe Zandalar";
	KHT_NEEDLE = "Escorpi\195\179n incrustado de agujas";
	KHT_DEATHBRINGER = "Testamento del Libramorte";
	KHT_FANGED_SKULL = "Calavera dentuda susurrante";
	KHT_SHARP_SCALE = "Escama Crepuscular afilada";
	KHT_HUNGERER = "El Hambriento";
	KHT_RELICXUEN = "Reliquia de Xuen";

	--Pet Abilities
	KHT_PET_INTIM = "Mascota "..GetSpellInfo(19577);					-- Pet Intimidation

	--Traps
	KHT_VENOMOUS = "Culebra venenosa";
	KHT_AURA = "Aura";
	KHT_PRIMED = "colocada";

	--Stings
	KHT_STING = "Picadura";
	KHT_WYVERN_TEXT = GetSpellInfo(19386).." (Dormir)";

	--Other
	KHT_DONE = "Fin!"

	--Status Text---------------------------------------
	KHT_ON = "on";
	KHT_OFF = "off";
	--Slash Text
	KHT_SLASH_HELP = {
		[1] = "Kharthus's Hunter Timers "..KHT_VERSION,
		[2] = "Commands: /kht",
		[3] = "/kht "..KHT_ON.."/"..KHT_OFF,
		[4] = "/kht menu (bring up the gui menu)",
		[5] = "/kht reset (resets all the visible bars)",
		[6] = "/kht resetpos (resets the bar frame position)",
		[7] = "/kht delay <time> (time is in milliseconds)",
		[8] = "/kht flash <timeleft> (timeleft in seconds to flash the bar, 0 for off)",
		[9] = "/kht step <step> (higher step means faster flashing when time is low)",
		[10] = "/kht barcolor r g b (where r, g, b are between 0 and 1)",
		[11] = "/kht barendcolor r g b (where r, g, b are between 0 and 1)",
		[12] = "/kht setbgcolor r g b a (where r, g, b, a are between 0 and 10)",
		[13] = "/kht colorchange "..KHT_ON.."/"..KHT_OFF.." (color change feature)",
		[14] = "/kht up/down (cascade bars up or down)",
		[15] = "/kht scale % (/kht scale 100 = 100% scale)",
		[16] = "/kht lock/unlock (lock or unlock the frame)",
		[17] = "/kht status",
		[18] = "/kht clear all (resets all options to defaults)",
		[19] = "/kht debug (debug info for testing purposes)"
	};
	KHT_STATUS_STRINGS = {
		[1] = "|cFFFFFF00Kharthus's Hunter Timers "..KHT_VERSION.."|r",
		[2] = "|cFFFFFF00Status:|r %s",
		[3] = "|cFFFFFF00Shot delay:|r %dms", 
		[4] = "|cFFFFFF00Flash time:|r %ds |cFFFFFF00Step:|r %f",
		[5] = "|cFFFFFF00Barcolor:|r %s |cFFFFFF00Barcolorend:|r %s",
		[6] = "|cFFFFFF00Colorchange:|r %s |cFFFFFF00Growth:|r %s",
		[7] = "|cFFFFFF00Scale:|r %d%%"
	};

	KHT_OPTIONS_COLOR_CHANGE = "Cambiar Color";
	KHT_OPTIONS_MILI = "ms";
	KHT_OPTIONS_LOCK = "Bloquear";
	KHT_OPTIONS_BAR_DIST = "Distancia entre Barras";
	KHT_OPTIONS_SCALE = "Escalar";
	KHT_OPTIONS_FLASH = "Flash Time";
	KHT_OPTIONS_STEP = "Flash Step";
	KHT_OPTIONS_BARSTART = "Color comienzo de barra";
	KHT_OPTIONS_BAREND = "Color fin de barra";
	KHT_OPTIONS_BACKDROP = "Color de fondo";
	KHT_OPTIONS_TIMERS_TEXT = "Temporizadores";
	KHT_OPTIONS_BARS_TEXT = "Barras";
	KHT_OPTIONS_DECIMALS = "Decimales";
	KHT_OPTIONS_SHOT_DELAY = "Retraso Disparo";
	KHT_OPTIONS_SHOW_TEX = "Mostrar Texturas";
	KHT_OPTIONS_LARGE_TEX = "Texturas Grandes";
	KHT_OPTIONS_APPEND = "A\195\177adir Objetivo";
	KHT_OPTIONS_BORDER = "Color Borde";
	KHT_OPTIONS_TEXT_COLOR = "Color Texto";
	KHT_OPTIONS_TIME_COLOR = "Color Tiempo";
	KHT_OPTIONS_TARGET_COLOR = "Color Texto Objetivo";
	KHT_OPTIONS_OVERALL_OPACITY = "Opacidad";
	KHT_OPTIONS_HIDE_TEXT = "Esconder Texto";
	KHT_OPTIONS_HIDE_TIME = "Esconder Tiempo";
	KHT_OPTIONS_HIDE_GAP = "Esconder Gap";
	KHT_OPTIONS_BAR_THICKNESS = "Grosor Barra";
	KHT_OPTIONS_HIDE_PADDING = "Hide Padding";
	KHT_OPTIONS_STICKY = "Sticky Auto Shot";
	KHT_OPTIONS_DOWN = "Barras en cascada descendente";
--	KHT_OPTIONS_TEXTURE = "Bar Texture";

--	KHT_BEAST = "Enable 'Beast Mastery' Timers";
--	KHT_MARKS = "Enable 'Marksmanship' Timers";
--	KHT_SURV = "Enable 'Survival' Timers";
--	KHT_PETS = "Enable 'Pet' Timers";
--	KHT_MISC = "Enable 'Miscellaneous' Timers";
--	KHT_TRINKETS = "Enable 'Trinket' Timers";

end
	
