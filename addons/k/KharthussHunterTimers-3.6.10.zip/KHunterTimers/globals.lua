--KHT globals

KHT_NUM_BARS = 11;
KHT_NUM_OPTIONS = 11;
KHT_NUM_LABELS = 11;
KHT_NUM_SLIDERS = 7;

KHT_NUM_TIMERS = {
	[1] = 14,		-- Beast
	[2] = 14,		-- Marks
	[3] = 16,		-- Surv
	[4] = 20,		-- Pets
	[5] = 24,		-- Misc
	[6] = 44		-- Trinkets
};

KHT_OPTIONS_TIMERS = {
	[1] = {		-- Beast
		[1]  = KHT_BEAST,
		[2]  = KHT_CLEAVE,
		[3]  = KHT_BW,
		[4]  = KHT_COBRA_STRIKES,
		[5]  = KHT_DIRE,
		[6]  = KHT_FEED_PET,
		[7]  = KHT_FOCUS_FIRE,
		[8]  = KHT_PET_FRENZY,
		[9]  = KHT_INTIM,
		[10] = KHT_MEND_PET,
		[11] = KHT_CROWS,
		[12] = KHT_SCARE_BEAST,
		[13] = KHT_STAMPEDE,
		[14] = KHT_WIDOW_VENOM
	},
	[2] = {		-- Marks
		[1]  = KHT_MARKS,
		[2]  = KHT_AUTO_SHOT,
		[3]  = KHT_CONC_BARRAGE,
		[4]  = KHT_CONC_SHOT,
		[5]  = KHT_FLARE,
		[6]  = KHT_GLAIVE,
		[7]  = KHT_HUNTERS_MARK,
		[8]  = KHT_STEADY,
		[9]  = KHT_MASTER_MARKS,
		[10] = KHT_PIERCING,
		[11] = KHT_RAPID_FIRE,
		[12] = KHT_SERPENT,
		[13] = KHT_SILENCE_SHOT,
		[14] = KHT_THRILL
	},
	[3] = {		-- Surv
		[1]  = KHT_SURV,
		[2]  = KHT_BLACK_ARROW,
		[3]  = KHT_CAMO,
		[4]  = KHT_DETERRENCE,
		[5]  = KHT_ENTRAPMENT,
		[6]  = KHT_EXPL_SHOT,
		[7]  = KHT_EXPL_TRAP,
		[8]  = KHT_FREEZING_TRAP,
		[9]  = KHT_FROST_TRAP,
		[10] = KHT_IMMO_TRAP,
		[11] = KHT_LOCK_LOAD,
		[12] = KHT_MISDIRECTION,
		[13] = KHT_SCATTER,
		[14] = KHT_SNAKE_TRAP,
		[15] = KHT_SNIPER,
		[16] = KHT_WYVERN
	},
	[4] = {		-- Pets
		[1]  = KHT_PETS,
		[2]  = KHT_ANKLE,
		[3]  = KHT_CARRION,
		[4]  = KHT_COWER,
		[5]  = KHT_CULLING,
		[6]  = KHT_DASH,
		[7]  = KHT_FURIOUS,
		[8]  = KHT_STAND,
		[9]  = KHT_BITE,
		[10] = KHT_RABID,
		[11] = KHT_COURAGE,
		[12] = KHT_RECOVERY,
		[13] = KHT_ROAR,
		[14] = KHT_SERENITY,
		[15] = KHT_SHIELD,
		[16] = KHT_SPIRIT_MEND,
		[17] = KHT_WARP,
		[18] = KHT_VENOM_WEB,
		[19] = KHT_WEB,
		[20] = KHT_WEB_WRAP
	},
	[5] = {		-- Misc
		[1]  = KHT_MISC,
		[2]  = KHT_ARCANE,
		[3]  = KHT_ASHEN,
		[4]  = KHT_CHAMPION,
		[5]  = KHT_BEAST_4PC,
		[6]  = KHT_BERSERKING,
		[7]  = KHT_BLOOD_FURY,
		[8]  = KHT_BLOOD_HUNTER,
		[9]  = KHT_BLOODLUST,
		[10] = KHT_DESOLATION_4PC,
		[11] = KHT_DON_SANTOS,
		[12] = KHT_DRAGON_8PC,
		[13] = KHT_FLAMEWAKER,
		[14] = KHT_HEROISM,
		[15] = KHT_HYPER,
		[16] = KHT_SAUROK,
		[17] = KHT_SCOURGE,
		[18] = KHT_STONEFORM,
		[19] = KHT_THUNDER,
		[20] = KHT_TIME_WARP,
		[21] = KHT_WAR_STOMP,
		[22] = KHT_WINDRUNNER,
		[23] = KHT_WYRMSTALKER,
		[24] = KHT_ZG
	},
	[6] = {		-- Trinkets
		[1]  = KHT_TRINKETS,
		[2]  = KHT_ABACUS,
		[3]  = KHT_ADWT,
		[4]  = KHT_ANVIL,
		[5]  = KHT_ATOS,
		[6]  = KHT_SWARMGUARD,
		[7]  = KHT_BERSERK_CALL,
		[8]  = KHT_BLADEFIST,
		[9]  = KHT_BLOODLUST_BROOCH,
		[10] = KHT_ARKELOS,
		[11] = KHT_DARK_GREAT,
		[12] = KHT_DARK_MAD,
		[13] = KHT_DARK_WRATH,
		[14] = KHT_DEATHBRINGER,
		[15] = KHT_VERDICT,
		[16] = KHT_DEVIL_EYE,
		[17] = KHT_DST,
		[18] = KHT_EARTHSTRIKE,
		[19] = KHT_EMPTY_MUG,
		[20] = KHT_GRIM_TOLL,
		[21] = KHT_HOURGLASS,
		[22] = KHT_HUNGERER,
		[23] = KHT_INCISOR,
		[24] = KHT_JOM_GABBAR,
		[25] = KHT_KISS_SPIDER,
		[26] = KHT_LOATHEB,
		[27] = KHT_MOTB,
		[28] = KHT_METEORITE,
		[29] = KHT_MIRROR,
		[30] = KHT_MJOLNIR,
		[31] = KHT_NEEDLE,
		[32] = KHT_NIGHTSEYE,
		[33] = KHT_OGRE,
		[34] = KHT_PYRITE_INFUSER,
		[35] = KHT_RELICXUEN,
		[36] = KHT_SHARP_SCALE,
		[37] = KHT_SIGNET_EDWARD,
		[38] = KHT_SKY_CROSS,
		[39] = KHT_TALON_ALAR,
		[40] = KHT_TTP,
		[41] = KHT_TSUNAMI_TALISMAN,
		[42] = KHT_UNITING,
		[43] = KHT_FANGED_SKULL,
		[44] = KHT_HERO_MEDALLION
	}
};

KHT_OPTIONS_BARS = {
	[1] = KHT_OPTIONS_LOCK,
	[2] = KHT_OPTIONS_COLOR_CHANGE,
	[3] = KHT_OPTIONS_SHOW_TEX,
	[4] = KHT_OPTIONS_LARGE_TEX,
	[5] = KHT_OPTIONS_HIDE_GAP,
	[6] = KHT_OPTIONS_APPEND,
	[7] = KHT_OPTIONS_HIDE_PADDING,
	[8] = KHT_OPTIONS_HIDE_TEXT,
	[9] = KHT_OPTIONS_HIDE_TIME,
	[10] = KHT_OPTIONS_STICKY,
	[11] = KHT_OPTIONS_DOWN
};

KHT_OPTIONS_LABELS = {
	[1] = KHT_OPTIONS_BARS_TEXT,
	[2] = KHT_OPTIONS_BORDER,
	[3] = KHT_OPTIONS_BARSTART,
	[4] = KHT_OPTIONS_TEXT_COLOR,
	[5] = KHT_OPTIONS_BACKDROP,
	[6] = KHT_OPTIONS_BAREND,
	[7] = KHT_OPTIONS_TIME_COLOR,
	[8] = KHT_OPTIONS_SHOT_DELAY,
	[9] = KHT_OPTIONS_MILI,
	[10] = KHT_OPTIONS_TARGET_COLOR,
	[11] = KHT_OPTIONS_TEXTURE
};

KHT_OPTIONS_SLIDER = {
	[1] = KHT_OPTIONS_BAR_DIST,
	[2] = KHT_OPTIONS_SCALE,
	[3] = KHT_OPTIONS_DECIMALS,
	[4] = KHT_OPTIONS_FLASH,
	[5] = KHT_OPTIONS_STEP,
	[6] = KHT_OPTIONS_OVERALL_OPACITY,
	[7] = KHT_OPTIONS_BAR_THICKNESS
};

KHT_OPTIONS_SLIDER_ENDS = {
	[1] = {
		[1] = "0",
		[2] = "10"
	},
	[2] = {
		[1] = "50%",
		[2] = "150%"
	},
	[3] = {
		[1] = KHT_OFF,
		[2] = "3"
	},
	[4] = {
		[1] = KHT_OFF,
		[2] = "10"
	},
	[5] = {
		[1] = "0.01",
		[2] = "0.05"
	},
	[6] = {
		[1] = "0%",
		[2] = "100%"
	},
	[7] = {
		[1] = "10",
		[2] = "32"
	}
};
