﻿-- Author      : LintyDruid

-- Localisation

function LFGShout_Locale_Korean()

end
