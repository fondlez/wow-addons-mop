﻿-- Author      : LintyDruid

-- Localisation

function LFGShout_Locale_French()

end
