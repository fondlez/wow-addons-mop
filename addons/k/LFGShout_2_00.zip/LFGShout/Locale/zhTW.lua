﻿-- Author      : LintyDruid

-- Localisation

function LFGShout_Locale_Taiwan()

end