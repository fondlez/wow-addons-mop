# MoP-LightHeaded
LightHeaded for Mists of Pandaria 5.4.8

Official Version 364 from Cladhaire, few minor issues fixed by me. 

Original link: https://www.wowinterface.com/downloads/info7017-LightHeaded.html
