local LibUSC = LibStub and LibStub("LibUserSpecifiedConditions", true)
if not LibUSC then return end

local CATEGORY = nil

LibUSC:RegisterParameter("Macro", { 
    version = 3,
    type = "Truth",
    category = CATEGORY,
    description = "True when the given macro condition is true (square brackets [] are required)",
    ParameterTypes = {
        "Text",
    },
    Events = {
        "PLAYER_REGEN_DISABLED",
        "PLAYER_REGEN_ENABLED",
        "PLAYER_FOCUS_CHANGED",
        "PARTY_MEMBERS_CHANGED",
        "UNIT_PET",
        "PLAYER_TARGET_CHANGED",
        "MODIFIER_STATE_CHANGED",
        "ACTIONBAR_PAGE_CHANGED",
        "UPDATE_BONUS_ACTIONBAR",
        "PLAYER_ENTERING_WORLD",
        "UPDATE_SHAPESHIFT_FORM",
        "UPDATE_STEALTH",
        "RAID_ROSTER_UPDATE",
    },
    receivesUpdates = true,
    configString = "Macro Condition: {1}",
    
    Init = function(self)
        self:SetParameter(2, LibUSC:Create("User-Entered Text", "[flying]"))
    end,
    
    Call = function(self)
        return SecureCmdOptionParse(self.Parameters[1]:GetValue()) ~= nil
    end,
    
    IsValid = function(self)
        local condition = string.match(self.Parameters[1]:GetValue(), "(%[.*%])");
        if not condition then
            return false, "Condition(s) must use square brackets (e.g. [flying])"
        end
        return true
    end,
})

LibUSC:RegisterParameter("Mana", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by most casters",
    value = 0,
})
LibUSC:SetTypeDefault("Power", "Mana")

LibUSC:RegisterParameter("Rage", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by warriors and druids in bear form",
    value = 1,
})

LibUSC:RegisterParameter("Focus", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by hunters",
    value = 2,
})

LibUSC:RegisterParameter("Energy", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by rogues and druids in cat form",
    value = 3,
})

LibUSC:RegisterParameter("Happiness", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by hunter pets",
    value = 4,
})

LibUSC:RegisterParameter("Runes", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by death knights",
    value = 5,
})

LibUSC:RegisterParameter("Runic Power", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by death knights",
    value = 6,
})

LibUSC:RegisterParameter("Soul Shards", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by warlocks",
    value = 7,
})

LibUSC:RegisterParameter("Eclipse", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by balance druids",
    value = 8,
})

LibUSC:RegisterParameter("Holy Power", { 
    version = 2,
    type = "Power",
    category = CATEGORY,
    description = "Power type used by paladins",
    value = 9,
})

LibUSC:RegisterParameter("Instance Type", { 
    version = 2,
    type = "Instance",
    category = CATEGORY,
    configString = "Instance Type",
    description = "The current type of instance (Dungeon, Battleground, etc.)",
    Events = {"PLAYER_ENTERING_WORLD"},
    
    Call = function(self)
        local _, instance = IsInInstance()
        return instance
    end,
})

LibUSC:RegisterParameter("Dungeon", { 
    version = 2,
    type = "Instance",
    category = CATEGORY,
    description = "A five player PvE instance",
    value = "party",
})
LibUSC:SetTypeDefault("Instance", "Dungeon")

LibUSC:RegisterParameter("Raid", { 
    version = 2,
    type = "Instance",
    category = CATEGORY,
    description = "A 10+ player PvE instance",
    value = "raid",
})

LibUSC:RegisterParameter("Battleground", { 
    version = 2,
    type = "Instance",
    category = CATEGORY,
    description = "A 10+ player PvP instance",
    value = "pvp",
})

LibUSC:RegisterParameter("Arena", { 
    version = 2,
    type = "Instance",
    category = CATEGORY,
    description = "A 2 to 5 player PvP instance",
    value = "arena",
})

LibUSC:RegisterParameter("None", { 
    version = 2,
    type = "Instance",
    category = CATEGORY,
    description = "The outside world",
    value = "none",
})

LibUSC:RegisterParameter("Seconds Since Event", {
    type = "Number",
    category = CATEGORY,
    configString = "Seconds since {1}",
    description = "The amount of time that has passed since the given event occurred",
    receivesUpdates = true,
    ParameterTypes = {
        "Event",
    },
    
    Call = function(self)
        return GetTime() - self.Parameters[1]:GetValue()
    end,
})

LibUSC:RegisterParameter("Event Occurred Recently", {
    type = "Truth",
    category = CATEGORY,
    configString = "{1} Within the Last {2} Seconds",
    description = "True when an event has occurred within a specific time range",
    receivesUpdates = true,
    ParameterTypes = {
        "Event",
        "Number",
    },
    
    Init = function(self)
        self:SetParameter(2, LibUSC:Create("User-Entered Number", 5))
    end,
    
    Call = function(self)
        return GetTime() - self.Parameters[1]:GetValue() < self.Parameters[2]:GetValue()
    end,
})

LibUSC:RegisterParameter("Minimap Ping", {
    type = "Event",
    category = CATEGORY,
    configString = "Minimap Ping",
    description = "Occurs when the player or a teammate clicks on the minimap",
    Events = {"MINIMAP_PING"},
    
    Init = function(self)
        self:SetValue(-math.huge)
    end,
    
    OnEvent = function(self, event)
        return self:SetValue(GetTime())
    end,
})
LibUSC:SetTypeDefault("Event", "Minimap Ping")

LibUSC:RegisterParameter("Quest Acceptance", {
    type = "Event",
    category = CATEGORY,
    configString = "Quest Acceptance",
    description = "Occurs when the player accepts a quest",
    Events = {"QUEST_ACCEPTED"},
    
    Init = function(self)
        self:SetValue(-math.huge)
    end,
    
    OnEvent = function(self, event)
        return self:SetValue(GetTime())
    end,
})

LibUSC:RegisterParameter("Quest Update", {
    type = "Event",
    category = CATEGORY,
    configString = "Quest Update",
    description = "Occurs when quest status changes",
    Events = {"QUEST_WATCH_UPDATE"},
    
    Init = function(self)
        self:SetValue(-math.huge)
    end,
    
    OnEvent = function(self, event)
        return self:SetValue(GetTime())
    end,
})

LibUSC:RegisterParameter("Change in Value", {
    type = "Event",
    category = CATEGORY,
    configString = "Change in {1}",
    description = "Occurs when the given value changes",
    ParameterTypes = {
        "Any",
    },
    
    Init = function(self)
        self:SetValue(-math.huge)
    end,
    
    Call = function(self)
        return GetTime()
    end,
})

-- TODO:
-- Level Up
-- Zone Change
-- Quest Acceptance
-- Buff Application
-- Cooldown Completion
-- Reactive Ability 