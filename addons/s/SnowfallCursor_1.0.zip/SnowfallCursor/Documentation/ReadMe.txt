This is an addon that improves the visibility of the mouse cursor. It places a star at the cursor, with size proportional to the cursor speed.
