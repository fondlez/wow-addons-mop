if not Skinner:isAddonEnabled("IPopBar") then return end

function Skinner:IPopBar()

	self:keepFontStrings(IPopBarFrame)
	self:keepFontStrings(IPopBarFrameBar)

end
