if not Skinner:isAddonEnabled("MuffinMOTD") then return end

function Skinner:MuffinMOTD()

	self:addSkinFrame{obj=MuffinMOTDFrame, hdr=true, x1=10, y1=2, x2=-10}

end
