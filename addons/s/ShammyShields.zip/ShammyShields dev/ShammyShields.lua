local onCooldown = false --Reincarnate on CD
local msActive, msCast = true, false --Self shield is up or just cast
local esActive, esCast = false, 0 --ES on someone or just cast
local tank --ES target
local freq = 0 --Update counter
local Earth, Lightning, Water = 974, 324, 52127 --SpellID's for shields

------------------------------------------------
-- Binding Variables
------------------------------------------------
BINDING_HEADER_SHAMMYSHIELDS = "ShammyShields"
BINDING_NAME_SSPERSONALSHIELD = "Personal Shield"
BINDING_NAME_SSEARTHSHIELD = "Earth Shield"

------------------------------------------------
--Formats time from seconds into a MM:SS string
------------------------------------------------
local function calcTime(time)
    local minutes = math.floor(time/60)
    local seconds = math.floor(time-(minutes*60))
    if seconds < 10 then
        return (minutes..":0"..seconds)
    else
        return (minutes..":"..seconds)
    end
end

------------------------------------------------
--Updates frame to show that user has no active shield
------------------------------------------------
local function MShield_Remove()
    msActive = false
    ShammyShields_MSIcon_Charges:SetText("")
    ShammyShields_MSTime:SetText("No Shield")
    ShammyShields_MSTime:SetTextColor(unpack(SSOptions.MSNoC))
    ShammyShields_MSIcon:SetAlpha(.5)
end

------------------------------------------------
--Checks the status of users Water or Lightning Shield and updates timer
------------------------------------------------
local function MShield_Update()
    local n = GetSpellInfo(Water)
    local name, _, _, charges, _, _, x = UnitBuff("player", n, nil, "PLAYER")
	charges = "" --Water Shield no longer has charges
    if not name then
        n = GetSpellInfo(Lightning)
        name, _, _, charges, _, _, x = UnitBuff("player", n, nil, "PLAYER")
    end
    if name then
        ShammyShields_MSIcon_Charges:SetText(charges)
        ShammyShields_MSTime:SetText(calcTime(x - GetTime()))
		if msCast then
			msActive = true
			msCast = false
		end
        return
    end
    MShield_Remove()
end

------------------------------------------------
--Updates frame to show that Earth Shield is not active any longer
------------------------------------------------
local function EShield_Remove()
    esActive = false
    ShammyShields_ESName:SetText("No Shield")
    ShammyShields_ESIcon_Charges:SetText("")
    ShammyShields_ESTime:SetText("")
    ShammyShields_ESName:SetAlpha(.5)
    ShammyShields_ESIcon:SetAlpha(.5)
end

------------------------------------------------
--Checks users Earth Shield target and updates timer
------------------------------------------------
local function EShield_Update()
    if tank then
        local n = GetSpellInfo(Earth)
        local name, _, _, charges, _, _, x = UnitBuff(tank, n, nil, "PLAYER")
        if name then
            ShammyShields_ESIcon_Charges:SetText(charges)
            ShammyShields_ESTime:SetText(calcTime(x - GetTime()))
            return
        end
    end
	EShield_Remove()
end

------------------------------------------------
--Determines if Reincarnate is on cooldown
--updates timer if it is, othewise display "Ready"
------------------------------------------------
local function Reincarnate_Timer()
	local start, dur, _ = GetSpellCooldown("Reincarnation")
    if start and dur and start > 0 and dur > 0 then
        local seconds = math.ceil(dur - (GetTime() - start))
        if seconds <=60 then
			onCooldown = true
            ShammyShields_Cooldown:SetText(seconds.. " Sec")
            ShammyShields_Cooldown:SetTextColor(unpack(SSOptions.rCDShortC))
            if seconds <= 1 then
                start = 0
                dur = 0
            end
        else
            local minutes = math.ceil(seconds/60)
            ShammyShields_Cooldown:SetText(minutes.. " Min")
            ShammyShields_Cooldown:SetTextColor(unpack(SSOptions.rCDLongC))
        end
    else
        onCooldown = false
        ShammyShields_Cooldown:SetText("Ready")
        ShammyShields_Cooldown:SetTextColor(unpack(SSOptions.rReadyC))
    end
end

------------------------------------------------
--Checks if the user is specced into Earth Shield
--Adjusts frame accordingly
------------------------------------------------
local function Check_Spec()
	if not GetSpecialization() or GetSpecialization() < 3 then
        esActive = false
		ShammyShields_MSIcon:SetNormalTexture("Interface\\Icons\\Spell_Nature_LightningShield")
        ShammyShields_MSIcon:SetAttribute("spell", Lightning)
		ShammyShields_ESIcon:Hide()
		ShammyShields_ESName:SetAlpha(0)
		ShammyShields_ESTime:SetAlpha(0)
		ShammyShields_ESIcon_Charges:SetAlpha(0)
	else
        ShammyShields_MSIcon:SetNormalTexture("Interface\\Icons\\Ability_Shaman_WaterShield")
        ShammyShields_MSIcon:SetAttribute("spell", Water)
		ShammyShields_ESIcon:Show()
		ShammyShields_ESTime:SetAlpha(1)
		ShammyShields_ESIcon_Charges:SetAlpha(1)
        EShield_Remove()
	end
	SSOp_Refresh()
end

------------------------------------------------
--Finds the UnitID for person ES was cast on
------------------------------------------------
local function FindTank()
	local n = GetSpellInfo(Earth)
	local unit, name, group
	unit = "player"
	name = UnitBuff(unit, n, nil, "PLAYER")
	if name then
		return unit
    end
	if IsInRaid() then
		group = "raid"
	else
		group = "party"
	end
	for i=1, GetNumGroupMembers() do
		unit = group..i
		name = UnitBuff(unit, n, nil, "PLAYER")
		if name then
			return unit
		end
		--print(unit,name)
		unit = group.."pet"..i
		name = UnitBuff(unit, n, nil, "PLAYER")
		if name then
			return unit
		end
	end
end

------------------------------------------------
--Updates ES target when party members change
------------------------------------------------
local function PartyChanged()
	tank = FindTank()
	if tank and not InCombatLockdown() then
		ShammyShields_ESIcon:SetAttribute("unit", tank)
	end
end

------------------------------------------------
--Register used events
------------------------------------------------
function ShammyShields_OnLoad()
	local _, class = UnitClass("player")
	if class ~= "SHAMAN" then
		DisableAddOn("ShammyShields")
		ShammyShields:Hide()
		--print("Reload to disable")
	else
        ShammyShields:RegisterEvent("ADDON_LOADED")
        ShammyShields:RegisterEvent("VARIABLES_LOADED")
        ShammyShields:RegisterEvent("PLAYER_ENTERING_WORLD")
        ShammyShields:RegisterEvent("PLAYER_ALIVE")
        ShammyShields:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
        ShammyShields:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
        ShammyShields:RegisterEvent("PLAYER_REGEN_DISABLED")
        ShammyShields:RegisterEvent("PLAYER_REGEN_ENABLED")
        ShammyShields:RegisterEvent("GROUP_ROSTER_UPDATE")
        ShammyShields:RegisterEvent("SPELLS_CHANGED")
    end
end

------------------------------------------------
--Update timers every second if currently running
------------------------------------------------
function ShammyShields_OnUpdate(self, elapsed)
    freq = freq + elapsed
    if freq > 1 then
        freq = 0
        if onCooldown then
            Reincarnate_Timer()
        end
		if esCast > 0 then
			tank = FindTank()
			if tank then
				if not InCombatLockdown() then
					ShammyShields_ESIcon:SetAttribute("unit", tank)
				end
				ShammyShields_ESName:SetText(GetUnitName(tank, false))
				ShammyShields_ESName:SetAlpha(1)
				ShammyShields_ESIcon:SetAlpha(1)
				esActive = true
			end
			esCast = esCast - 1
		end
        if esActive then
            EShield_Update()
		end
		if msActive or msCast then
			MShield_Update()
		end
    end
end

------------------------------------------------
--Event Handler
------------------------------------------------
function ShammyShields_OnEvent(self, event, ...)
    local arg = ...
    if event == "ADDON_LOADED" and arg == "ShammyShields" then
        SSOp_Initialize()
		SSAn_Initialize()
    elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_ALIVE" then
        Check_Spec()
        ShammyShields_MSTime:SetTextColor(unpack(SSOptions.MSTimerC))
        ShammyShields_MSIcon:SetAlpha(1)
		msActive = true
		SSOp_Refresh()
		SSAn_UpdateAnchor()
	elseif event == "SPELLS_CHANGED" then
		if GetSpellInfo("Reincarnation") then
			ShammyShields_Cooldown:Show()
			ShammyShields:RegisterEvent("SPELL_UPDATE_COOLDOWN")
			ShammyShields:UnregisterEvent("SPELLS_CHANGED")
			Reincarnate_Timer()
		else
			ShammyShields_Cooldown:Hide()
		end
    elseif event == "SPELL_UPDATE_COOLDOWN" then
        Reincarnate_Timer()
	elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
		Check_Spec()
		SSAn_Spec()
	elseif event == "PLAYER_REGEN_DISABLED" then
		ShammyShields:SetAlpha(1)
	elseif event == "PLAYER_REGEN_ENABLED" then
		ShammyShields:SetAlpha(SSOptions.oocTrans)
	elseif event == "GROUP_ROSTER_UPDATE" then
		PartyChanged()
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
		local unit, _, _, _, spellID = ...
		if unit == "player" then
			if spellID == Water then
                ShammyShields_MSTime:SetTextColor(unpack(SSOptions.MSTimerC))
                ShammyShields_MSIcon:SetNormalTexture("Interface\\Icons\\Ability_Shaman_WaterShield")
				if not InCombatLockdown() then
					ShammyShields_MSIcon:SetAttribute("spell", Water)
				end
                ShammyShields_MSIcon:SetAlpha(1)
				msCast = true
			elseif spellID == Lightning then
                ShammyShields_MSTime:SetTextColor(unpack(SSOptions.MSTimerC))
                ShammyShields_MSIcon:SetNormalTexture("Interface\\Icons\\Spell_Nature_LightningShield")
				if not InCombatLockdown() then
					ShammyShields_MSIcon:SetAttribute("spell", Lightning)
				end
                ShammyShields_MSIcon:SetAlpha(1)
				msCast = true
            elseif spellID == Earth then
				esCast = 2
            end
        end
    end
end
