local spec, anchor, startX, startY, _
local defaultAnchors = {
    [1] = {
        name = "Elemental",
        sspoint = "CENTER",
        relpoint = "CENTER",
        relto = "UIParent",
        xoff = 0,
        yoff = 0
    },
    [2] = {
        name = "Enhancement",
        sspoint = "CENTER",
        relpoint = "CENTER",
        relto = "UIParent",
        xoff = 0,
        yoff = 0
    },
    [3] = {
        name = "Restoration",
        sspoint = "CENTER",
        relpoint = "CENTER",
        relto = "UIParent",
        xoff = 0,
        yoff = 0
    },
}

------------------------------------------------
--Revert to default anchors
------------------------------------------------
local function SSAn_ToDefault()
    wipe(SSAnchors)
    SSAnchors = defaultAnchors
end

------------------------------------------------
--Refresh anchor point
------------------------------------------------
function SSAn_UpdateAnchor()
    if _G[anchor.relto] then
        ShammyShields:ClearAllPoints()
        ShammyShields:SetPoint(anchor.sspoint, anchor.relto, anchor.relpoint, anchor.xoff, anchor.yoff)
    end
end

--------- << SS Anchor Selection >> ------------
--Functions controlling the dropdown menu for
--list of available anchors.
------------------------------------------------
local function SSAnchor_SelectAnchor(value)
	spec = value
	anchor = SSAnchors[spec]
	SSAn_UpdateAnchor()
end

local function SSAnchor_OnClick(self)
    SSAnchorFrameSSAnchor:SetValue(self.value)
    SSAnchorFrameSSAnchor:RefreshValue()
end

local function SSAnchor_Refresh()
	SSAn_OnShow()
    SSAnchorFrameSSPoint:SetValue(anchor.sspoint)
    SSAnchorFrameSSPoint:RefreshValue()
    SSAnchorFrameRelPoint:SetValue(anchor.relpoint)
    SSAnchorFrameRelPoint:RefreshValue()
end

local function SSAnchor_Initialize()
    local selectedValue = spec
    local info = UIDropDownMenu_CreateInfo()
 
    for i, k in pairs(SSAnchors) do
        info.text = k.name
        info.func = SSAnchor_OnClick
        info.value = i
        if ( info.value == selectedValue ) then
            info.checked = 1
        else
            info.checked = nil
        end
        UIDropDownMenu_AddButton(info)
    end
end

local function SSAnchor_Start(self)
	local value = spec
	self.defaultValue = 1
	self.value = value
	self.oldValue = value

	UIDropDownMenu_SetWidth(self, 90)
	UIDropDownMenu_Initialize(self, SSAnchor_Initialize)
	UIDropDownMenu_SetSelectedValue(self, value)
	SSAnchor_SelectAnchor(value)

	self.SetValue =
		function (self, value)
			self.value = value
            SSAnchor_SelectAnchor(value)
			SSAnchor_Refresh()
		end
	self.GetValue =
		function (self)
			return UIDropDownMenu_GetSelectedValue(self)
		end
	self.RefreshValue =
		function (self)
			UIDropDownMenu_Initialize(self, SSAnchor_Initialize)
			UIDropDownMenu_SetSelectedValue(self, self.value)
		end
end

--------- << SS Anchor Point >> ----------------
--Functions controlling the dropdown menu for
--frame locations to anchor from.
------------------------------------------------
local function SSPoint_SetSSPoint(value)
	anchor.sspoint = value
	SSAn_UpdateAnchor()
end

local function SSPoint_OnClick(self)
    SSAnchorFrameSSPoint:SetValue(self.value)
    SSAnchorFrameSSPoint:RefreshValue()
end

local function SSPoint_Initialize()
    local selectedValue = anchor.sspoint
    local info = UIDropDownMenu_CreateInfo()
 
    info.text = "Topleft"
    info.func = SSPoint_OnClick
    info.value = "TOPLEFT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Top"
    info.func = SSPoint_OnClick
    info.value = "TOP"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Topright"
    info.func = SSPoint_OnClick
    info.value = "TOPRIGHT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Left"
    info.func = SSPoint_OnClick
    info.value = "LEFT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Center"
    info.func = SSPoint_OnClick
    info.value = "CENTER"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Right"
    info.func = SSPoint_OnClick
    info.value = "RIGHT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Bottomleft"
    info.func = SSPoint_OnClick
    info.value = "BOTTOMLEFT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Bottom"
    info.func = SSPoint_OnClick
    info.value = "BOTTOM"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Bottomright"
    info.func = SSPoint_OnClick
    info.value = "BOTTOMRIGHT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
end

local function SSPoint_Start(self)
	local value = anchor.sspoint
	self.defaultValue = "CENTER"
	self.value = value
	self.oldValue = value

	UIDropDownMenu_SetWidth(self, 90)
	UIDropDownMenu_Initialize(self, SSPoint_Initialize)
	UIDropDownMenu_SetSelectedValue(self, value)
	SSPoint_SetSSPoint(value)

	self.SetValue =
		function (self, value)
			self.value = value
			SSPoint_SetSSPoint(value)
		end
	self.GetValue =
		function (self)
			return UIDropDownMenu_GetSelectedValue(self)
		end
	self.RefreshValue =
		function (self)
			UIDropDownMenu_Initialize(self, SSPoint_Initialize)
			UIDropDownMenu_SetSelectedValue(self, self.value)
		end
end

--------- << SS Relative Point >> --------------
--Functions controlling the dropdown menu for
--frame locations to anchor to.
------------------------------------------------
local function RelPoint_SetSSPoint(value)
	anchor.relpoint = value
	SSAn_UpdateAnchor()
end

local function RelPoint_OnClick(self)
    SSAnchorFrameRelPoint:SetValue(self.value)
    SSAnchorFrameRelPoint:RefreshValue()
end

local function RelPoint_Initialize()
    local selectedValue = anchor.relpoint
    local info = UIDropDownMenu_CreateInfo()
 
    info.text = "Topleft"
    info.func = RelPoint_OnClick
    info.value = "TOPLEFT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Top"
    info.func = RelPoint_OnClick
    info.value = "TOP"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Topright"
    info.func = RelPoint_OnClick
    info.value = "TOPRIGHT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Left"
    info.func = RelPoint_OnClick
    info.value = "LEFT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Center"
    info.func = RelPoint_OnClick
    info.value = "CENTER"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Right"
    info.func = RelPoint_OnClick
    info.value = "RIGHT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Bottomleft"
    info.func = RelPoint_OnClick
    info.value = "BOTTOMLEFT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Bottom"
    info.func = RelPoint_OnClick
    info.value = "BOTTOM"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
    info.text = "Bottomright"
    info.func = RelPoint_OnClick
    info.value = "BOTTOMRIGHT"
    if ( info.value == selectedValue ) then
        info.checked = 1
    else
        info.checked = nil
    end
    UIDropDownMenu_AddButton(info)
 
end

local function RelPoint_Start(self)
	local value = anchor.relpoint
	self.defaultValue = "CENTER"
	self.value = value
	self.oldValue = value

	UIDropDownMenu_SetWidth(self, 90)
	UIDropDownMenu_Initialize(self, RelPoint_Initialize)
	UIDropDownMenu_SetSelectedValue(self, value)
	RelPoint_SetSSPoint(value)

	self.SetValue =
		function (self, value)
			self.value = value
			RelPoint_SetSSPoint(value)
		end
	self.GetValue =
		function (self)
			return UIDropDownMenu_GetSelectedValue(self)
		end
	self.RefreshValue =
		function (self)
			UIDropDownMenu_Initialize(self, RelPoint_Initialize)
			UIDropDownMenu_SetSelectedValue(self, self.value)
		end
end

--------- << SS Relative To >> -----------------
--Functions controlling the edit box to
--specify what frame to anchor too.
------------------------------------------------
function SSRelTo_ValueChanged(self)
    if _G[self:GetText()] then
        SSAnchorFrameRelTo:SetTextColor(0,1,0,1)
        anchor.relto = self:GetText()
        SSAn_UpdateAnchor()
    else
        SSAnchorFrameRelTo:SetTextColor(1,0,0,1)
    end
end

function SSRelTo_FocusLost(self)
	self:SetText(anchor.relto)
end

--------- << Horizontal Offset >> --------------
--Functions controlling the edit box to
--specify the horizontal offset.
------------------------------------------------
function SSOffsetX_ValueChanged(self)
    local x = tonumber(self:GetText())
	if self:GetText() == "" or self:GetText() == "-" then
		x = 0
	elseif self:GetText() == "0-" then
		self:SetText("-")
	end
    if x then
		anchor.xoff = x
		SSAnchorFrameOffsetX:SetTextColor(0,1,0,1)
		SSAn_UpdateAnchor()
		if x ~= 0 then
			self:SetText(x)
		end
	else
        SSAnchorFrameOffsetX:SetTextColor(1,0,0,1)
    end
end

function SSOffsetX_FocusLost(self)
	self:SetText(anchor.xoff)
end

--------- << Vertical Offset >> ----------------
--Functions controlling the edit box to
--specify the vertical offset.
------------------------------------------------
function SSOffsetY_ValueChanged(self)
    local y = tonumber(self:GetText())
	if self:GetText() == "" or self:GetText() == "-" then
		y = 0
	elseif self:GetText() == "0-" then
		self:SetText("-")
	end
    if y then
        anchor.yoff = y
        SSAnchorFrameOffsetY:SetTextColor(0,1,0,1)
        SSAn_UpdateAnchor()
		if y ~= 0 then
			self:SetText(y)
		end
    else
        SSAnchorFrameOffsetY:SetTextColor(1,0,0,1)
    end
end

function SSOffsetY_FocusLost(self)
	self:SetText(anchor.yoff)
end

------------------------------------------------
--Begins moving the frame when user clicks to drag
------------------------------------------------
function SSAn_StartDrag()
    ShammyShields:StartMoving()
    _,_,_, startX, startY = ShammyShields:GetPoint()
end

------------------------------------------------
--Stops moving frame
--Keeps frame at user placed location
--while preserving anchor points
------------------------------------------------
function SSAn_StopDrag()
    local _,_,_, endX, endY = ShammyShields:GetPoint()
    ShammyShields:StopMovingOrSizing()
    local newX = endX - startX
    local newY = endY - startY
    anchor.xoff = math.floor(anchor.xoff + newX)
    anchor.yoff = math.floor(anchor.yoff + newY)
    SSAn_UpdateAnchor()
    SSAn_OnShow()
end

------------------------------------------------
--Resets frame to center of the screen
------------------------------------------------
local function Reset_Location()
    ShammyShields:ClearAllPoints()
    ShammyShields:SetPoint("CENTER", "WorldFrame", "CENTER", 0, 0)
end

------------------------------------------------
--Change anchor based on spec
------------------------------------------------
function SSAn_Spec()
    spec = GetSpecialization() or 1
    anchor = SSAnchors[spec]
    SSAn_UpdateAnchor()
	if SSAnchorFrameSSAnchor.SetValue then
		SSAnchorFrameSSAnchor:SetValue(spec)
		SSAnchorFrameSSAnchor:RefreshValue()
		SSAnchor_Refresh()
	end
end

------------------------------------------------
--Set options frame to current values
------------------------------------------------
function SSAn_OnShow()
    SSAnchorFrameRelTo:SetText(anchor.relto or "")
    SSAnchorFrameRelTo:SetTextColor(0,1,0,1)
	SSAnchorFrameOffsetX:SetText(anchor.xoff)
	SSAnchorFrameOffsetY:SetText(anchor.yoff)
    SSAnchorFrameLocked:SetChecked(SSOptions.locked)
end

------------------------------------------------
--Add options panel to WoW Addon Interface
------------------------------------------------
function SSAn_OnLoad(panel)
    panel.name = "ShammyShields Anchors"
    panel.parent = "ShammyShields "..GetAddOnMetadata("ShammyShields", "Version")
    panel.default = function() SSAn_ToDefault() end
    InterfaceOptions_AddCategory(panel)
end

------------------------------------------------
--Startup configuration
------------------------------------------------
function SSAn_Initialize()
    if not SSAnchors then
        SSAnchors = defaultAnchors
    end
    SSAn_Spec()
    SSAnchor_Start(SSAnchorFrameSSAnchor)
    SSPoint_Start(SSAnchorFrameSSPoint)
    RelPoint_Start(SSAnchorFrameRelPoint)
    SlashCmdList["SSRESET"] = Reset_Location
    SLASH_SSRESET1 = "/ssreset"
end
