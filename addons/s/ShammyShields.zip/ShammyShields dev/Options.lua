local font = "Fonts\\FRIZQT__.TTF" --Font
local unpack = unpack
local defaults = {
	version = GetAddOnMetadata("ShammyShields", "Version"),
    scale = 1,
    bgTrans = 1,
	oocTrans = 1,
	locked = false,
    rReadyC = {0,0,1},
    rCDLongC = {1,0,0},
    rCDShortC = {0,1,0},
    MSChargeC = {0.8,0.2,0.9},
    MSChargeS = 16,
    MSTimerC = {1,1,1},
    MSNoC = {1,0,0},
    ESChargeC = {0.2,0.8,0.9},
    ESChargeS = 16,
    ESNameC = {1,1,1},
    ESTimerC = {1,1,1},
    timers= true,
    horizontal = false,
}

------------------------------------------------
--Refreshes GUI
------------------------------------------------
function SSOp_Refresh()
    SSOp_Align()
    SSOp_Color()
	SSOp_Resize()
    SSOp_Visible()
end

------------------------------------------------
--Aligns Earth Shield vertically or horizontally
------------------------------------------------
function SSOp_Align()
    if SSOptions.horizontal then
        ShammyShields_ESIcon:SetPoint("TOPLEFT", ShammyShields_MSIcon, "TOPRIGHT", 5, 0)
    else
        ShammyShields_ESIcon:SetPoint("TOPLEFT", ShammyShields_MSIcon, "BOTTOMLEFT", 0, -5)
    end
end

------------------------------------------------
--Refreshes font colors
------------------------------------------------
function SSOp_Color()
    ShammyShields:SetScale(SSOptions.scale)
    ShammyShields:SetBackdropColor(1,1,1,SSOptions.bgTrans)
    ShammyShields_MSIcon_Charges:SetTextColor(unpack(SSOptions.MSChargeC))
    ShammyShields_MSIcon_Charges:SetFont(font, SSOptions.MSChargeS)
    ShammyShields_ESIcon_Charges:SetTextColor(unpack(SSOptions.ESChargeC))
    ShammyShields_ESIcon_Charges:SetFont(font, SSOptions.ESChargeS)
    ShammyShields_ESName:SetTextColor(unpack(SSOptions.ESNameC))
    ShammyShields_ESTime:SetTextColor(unpack(SSOptions.ESTimerC))
    ShammyShields_MSTime:SetTextColor(unpack(SSOptions.MSTimerC))
    ShammyShields_Cooldown:SetTextColor(unpack(SSOptions.rReadyC))
end

------------------------------------------------
--Resize SS Frame for timers and orientation
------------------------------------------------
function SSOp_Resize()
	if SSOptions.timers then
		if ShammyShields_ESIcon:IsVisible() then
			ShammyShields:SetWidth(100)
			ShammyShields:SetHeight(95)
		else
			ShammyShields:SetWidth(100)
			ShammyShields:SetHeight(57)
		end
	else
		if ShammyShields_ESIcon:IsVisible() then
			if SSOptions.horizontal then
				ShammyShields:SetWidth(78)
				ShammyShields:SetHeight(57)
			else
				ShammyShields:SetWidth(40)
				ShammyShields:SetHeight(95)
			end
		else
			ShammyShields:SetWidth(40)
			ShammyShields:SetHeight(57)
		end
	end
end

------------------------------------------------
--Show/hide names and timers
------------------------------------------------
function SSOp_Visible()
    if SSOptions.timers then
        ShammyShields_ESName:Show()
        ShammyShields_ESTime:Show()
        ShammyShields_MSTime:Show()
    else
        ShammyShields_ESName:Hide()
        ShammyShields_ESTime:Hide()
		ShammyShields_MSTime:Hide()
    end
end

------------------------------------------------
--Fade in/out color options in use
------------------------------------------------
local function SSOp_TimerOptions()
	if SSOptions.timers then
		if SSOptions.horizontal then
			SSConfigFrame_Horizontal:Click()
		end
        SSConfigFrame_Horizontal:Disable()
		SSConfigFrame_HorizontalText:SetAlpha(.5)
        SSConfigFrame_MSTimerColor_Text:SetAlpha(1)
        SSConfigFrame_MSNoColor_Text:SetAlpha(1)
        SSConfigFrame_ESNameColor_Text:SetAlpha(1)
        SSConfigFrame_ESTimerColor_Text:SetAlpha(1)
    else
        SSOptions.timers = false
        SSConfigFrame_Horizontal:Enable()
		SSConfigFrame_HorizontalText:SetAlpha(1)
        SSConfigFrame_MSTimerColor_Text:SetAlpha(.5)
        SSConfigFrame_MSNoColor_Text:SetAlpha(.5)
        SSConfigFrame_ESNameColor_Text:SetAlpha(.5)
        SSConfigFrame_ESTimerColor_Text:SetAlpha(.5)
    end
end

------------------------------------------------
--Sets option page to stored values
------------------------------------------------
function SSOp_OnShow()
	SSConfigFrame_Scale:SetValue(SSOptions.scale)
	SSConfigFrame_BGTransparency:SetValue(SSOptions.bgTrans)
	SSConfigFrame_OOCTransparency:SetValue(SSOptions.oocTrans)
	SSConfigFrame_Locked:SetChecked(SSOptions.locked)
    SSConfigFrame_Timers:SetChecked(SSOptions.timers)
    SSConfigFrame_Horizontal:SetChecked(SSOptions.horizontal)
	SSConfigFrame_MSChargeSize:SetValue(SSOptions.MSChargeS)
	SSConfigFrame_ESChargeSize:SetValue(SSOptions.ESChargeS)
    SSConfigFrame_RReadyColor_Color:SetTexture(unpack(SSOptions.rReadyC))
    SSConfigFrame_RCDLongColor_Color:SetTexture(unpack(SSOptions.rCDLongC))
    SSConfigFrame_RCDShortColor_Color:SetTexture(unpack(SSOptions.rCDShortC))
    SSConfigFrame_MSChargeColor_Color:SetTexture(unpack(SSOptions.MSChargeC))
    SSConfigFrame_MSTimerColor_Color:SetTexture(unpack(SSOptions.MSTimerC))
    SSConfigFrame_MSNoColor_Color:SetTexture(unpack(SSOptions.MSNoC))
    SSConfigFrame_ESChargeColor_Color:SetTexture(unpack(SSOptions.ESChargeC))
    SSConfigFrame_ESNameColor_Color:SetTexture(unpack(SSOptions.ESNameC))
    SSConfigFrame_ESTimerColor_Color:SetTexture(unpack(SSOptions.ESTimerC))
	SSOp_TimerOptions()
end

------------------------------------------------
--Sets up Color Wheel for color changes
------------------------------------------------
local function ShowColorPicker(value, callback)
    ColorPickerFrame.func = function()
        SSOptions[value][1], SSOptions[value][2], SSOptions[value][3] = ColorPickerFrame:GetColorRGB()
        SSConfig_OnShow()
        SSRefresh()
    end
    ColorPickerFrame.opacityFunc = nil
    ColorPickerFrame.cancelFunc = function(restore)
        local r, g, b = unpack(restore)
        SSOptions[value][1], SSOptions[value][2], SSOptions[value][3] = r,g,b
        SSConfig_OnShow()
        SSRefresh()
    end
    ColorPickerFrame:SetColorRGB(unpack(SSOptions[value]))
    ColorPickerFrame.hasOpacity = false
    ColorPickerFrame.previousValues = {unpack(SSOptions[value])}
    ColorPickerFrame:Hide()
    ColorPickerFrame:Show()
end

------------------------------------------------
--Restores default settings
------------------------------------------------
function SSOp_ToDefault()
    wipe(SSOptions)
    SSOptions = defaults
    SSOp_Refresh()
    SSOp_OnShow()
	ShammyShields:EnableMouse(true)
end

------------------------------------------------
--Adds options panel to WoW Addon Interface
------------------------------------------------
function SSOp_OnLoad(panel)
    panel.name = "ShammyShields "..GetAddOnMetadata("ShammyShields", "Version")
    panel.default = function() SSOp_ToDefault() end
    panel.refresh = function() SSOp_Refresh() end
    InterfaceOptions_AddCategory(panel)
end

------------------------------------------------
--Startup configuration
------------------------------------------------
function SSOp_Initialize()
    if not SSOptions then 
        SSOptions = defaults
    elseif not (SSOptions.version == GetAddOnMetadata("ShammyShields", "Version")) then
        for i, v in pairs(defaults) do
            if not SSOptions[i] then
                SSOptions[i] = v
            end
        end
        SSOptions.version = GetAddOnMetadata("ShammyShields", "Version")
    end
    SlashCmdList["SSOPTION"] = function()
        InterfaceOptionsFrame_OnShow()
        InterfaceOptionsFrame_OpenToCategory("ShammyShields "..GetAddOnMetadata("ShammyShields", "Version"))
    end
    SLASH_SSOPTION1 = "/ssop"
    SSOp_Refresh()
end

------------------------------------------------
--Makes changes based on what option was clicked
------------------------------------------------
function SSOp_OnClick(self)
    if self == SSConfigFrame_Scale then
        SSOptions.scale = self:GetValue()
        ShammyShields:SetScale(SSOptions.scale)
    elseif self == SSConfigFrame_BGTransparency then
        SSOptions.bgTrans = self:GetValue()
        ShammyShields:SetBackdropColor(1,1,1,SSOptions.bgTrans)
    elseif self == SSConfigFrame_OOCTransparency then
        SSOptions.oocTrans = self:GetValue()
        ShammyShields:SetAlpha(SSOptions.oocTrans)
    elseif self == SSConfigFrame_MSChargeSize then
        SSOptions.MSChargeS = self:GetValue()
        ShammyShields_MSIcon_Charges:SetFont(font, SSOptions.MSChargeS)
    elseif self == SSConfigFrame_ESChargeSize then
        SSOptions.ESChargeS = self:GetValue()
        ShammyShields_ESIcon_Charges:SetFont(font, SSOptions.ESChargeS)
    elseif self == SSConfigFrame_RReadyColor then
        ShowColorPicker("rReadyC", SSColorCallback)
    elseif self == SSConfigFrame_RCDLongColor then
        ShowColorPicker("rCDLongC", SSColorCallback)
    elseif self == SSConfigFrame_RCDShortColor then
        ShowColorPicker("rCDShortC", SSColorCallback)
    elseif self == SSConfigFrame_MSChargeColor then
        ShowColorPicker("MSChargeC", SSColorCallback)
    elseif self == SSConfigFrame_MSTimerColor then
        ShowColorPicker("MSTimerC", SSColorCallback)
    elseif self == SSConfigFrame_MSNoColor then
        ShowColorPicker("MSNoC", SSColorCallback)
    elseif self == SSConfigFrame_ESChargeColor then
        ShowColorPicker("ESChargeC", SSColorCallback)
    elseif self == SSConfigFrame_ESNameColor then
        ShowColorPicker("ESNameC", SSColorCallback)
    elseif self == SSConfigFrame_ESTimerColor then
        ShowColorPicker("ESTimerC", SSColorCallback)
    end
end

------------------------------------------------
--Toggles drag registration for locking frame
------------------------------------------------
function SSOp_Locked(self)
    if self:GetChecked() then
        SSOptions.locked = true
        ShammyShields:EnableMouse(false)
    else
        SSOptions.locked = false
        ShammyShields:EnableMouse(true)
    end
end

------------------------------------------------
--Toggles showing/hiding timers
------------------------------------------------
function SSOp_TimersOnClick(self)
    SSOptions.timers = self:GetChecked()
	SSOp_TimerOptions()
	SSOp_Resize()
	SSOp_Visible()
end

------------------------------------------------
--Toggles vertical/horizontal orientation
------------------------------------------------
function SSOp_HorizontalOnClick(self)
    SSOptions.horizontal = self:GetChecked()
    SSOp_Align()
	SSOp_Resize()
end
