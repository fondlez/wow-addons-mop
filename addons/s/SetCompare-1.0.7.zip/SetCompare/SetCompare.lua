--! @brief Initialize addon, hook into tooltips
--! @private
function scInit()
  -- Tooltips to hook into
  hooksecurefunc(ShoppingTooltip1, "SetHyperlinkCompareItem", function(self, ItemLink, ...) _scCurrentlyEquippedTooltipHook("ShoppingTooltip1", "SetHyperlinkCompareItem", ItemLink, ...) end)
  hooksecurefunc(ItemRefShoppingTooltip1, "SetHyperlinkCompareItem", function(self, ItemLink, ...) _scCurrentlyEquippedTooltipHook("ItemRefShoppingTooltip1", "SetHyperlinkCompareItem", ItemLink, ...) end)
end

--! @brief Callback for tooltip hooks
--! @param tooltipName     string     Name of the tooltip to display SetCompare info into
--! @param methodName      string     Internal name for troubleshooting purposes
--! @param compareItemLink itemLink   Item link to compare
--! @private
function _scCurrentlyEquippedTooltipHook(tooltipName, methodName, compareItemLink, ...)
  if (not tooltipName) or (not methodName) then return end
  local outputTooltip;

  -- Find the output tooltip
  outputTooltip = getglobal(tooltipName);
  if not outputTooltip then return end

  -- Now that we have the output tooltip and the item link to compare to the sets, lets do it!
  showSetCompare(outputTooltip, compareItemLink);
end

--! @brief Show SetCompare info
--! @param tooltip         GameTooltip   Tooltip object to show SetCompare info on
--! @param compareItemLink itemLink      Item to compare against set equipment
function showSetCompare(tooltip, compareItemLink)
  if not tooltip then return end
  if not compareItemLink then return end

  local eqSetID, eqSetNum, setItemLinks, currentlyEquippedItemLinks, equipSlot1, equipSlot2;
  eqSetID = nil;                     --- Equipment Set ID counter
  eqSetNum = GetNumEquipmentSets();  --- Number of equipment sets that are defined for the character
  setItemLinks = {};                 --- key is ItemLinks for various set's assignments, value is numeric-index table of set names which use the item as values. eg: {[awesome_item] = {[0] => [set1]}}
  currentlyEquippedItemLinks = {}    --- key is the ItemLink of equipped items belonging to the compareItemLink slot, value is true
  equipSlot1 = nil;                  --- First slot that the compareItemLink goes into
  equipSlot2 = nil;                  --- Second slot that the compareItemLink goes into (eg: ring, weapon, trinket)

  if eqSetNum ~= 0 then

    -- Figure out the items which are currently equipped, since we don't want to display those
    equipSlot1, equipSlot2 = _scIdentifyComparisonSlot(compareItemLink);
    if equipSlot1 then
      itemLink = GetInventoryItemLink("player", equipSlot1);
      if itemLink then currentlyEquippedItemLinks[itemLink] = true; end
    end

    if equipSlot2 then
      itemLink = GetInventoryItemLink("player", equipSlot2);
      if itemLink then currentlyEquippedItemLinks[itemLink] = true; end
    end

    --- Figure out the items from each set
    for eqSetID = 1, eqSetNum do
      -- Get the itemLink and set name for the eqSetID which uses the same equipment slot as the compareItemLink
      eqSetName, eqSetItemLinks = _scGetItemLinkAndNameForSet(eqSetID, equipSlot1, equipSlot2);

      for _, eqSingleSetItemLink in pairs(eqSetItemLinks) do
        -- If the set item should be diplayed, add it to the setItemLinks table
        if _scSetItemShouldBeDisplayed(eqSingleSetItemLink, compareItemLink, currentlyEquippedItemLinks) then
          if setItemLinks[eqSingleSetItemLink] then
            --- Item is in two sets, add the set name to the item's values
            table.insert(setItemLinks[eqSingleSetItemLink], eqSetName);
          elseif eqSingleSetItemLink then
            --- Item link has been identified for the first time
            setItemLinks[eqSingleSetItemLink] = {};
            table.insert(setItemLinks[eqSingleSetItemLink], eqSetName);
          else
            --- Set has no item in the slot, don't do anything for this set.
          end
        end
      end
      wipe(eqSetItemLinks);
    end

    -- Now we have all the itemLinks and set names for the equipment slot(s), let's display everything
    _scDisplayOnTooltip(tooltip, setItemLinks, compareItemLink);
  end
  wipe(setItemLinks);
end

--! @brief Identify the InventorySlotIDs that an item can be equipped in
--! @param  itemLink itemLink Item to find equipment slots
--! @return int, int InventorySlotIDs which the item can be equipped in
--! @retval NULL No equipment slot identified
--! @private
function _scIdentifyComparisonSlot(itemLink)
  if not itemLink then return end
  -- Special thanks to VgerAN and Pawn for this bit
  local equipSlotMap =
  {
    INVTYPE_AMMO = 0,
    INVTYPE_HEAD = 1,
    INVTYPE_NECK = 2,
    INVTYPE_SHOULDER = 3,
    INVTYPE_BODY = 4,
    INVTYPE_CHEST = 5,
    INVTYPE_ROBE = 5,
    INVTYPE_WAIST = 6,
    INVTYPE_LEGS = 7,
    INVTYPE_FEET = 8,
    INVTYPE_WRIST = 9,
    INVTYPE_HAND = 10,
    INVTYPE_FINGER = 11,
    INVTYPE_TRINKET = 13,
    INVTYPE_CLOAK = 15,
    INVTYPE_WEAPON = 16,
    INVTYPE_SHIELD = 17,
    INVTYPE_2HWEAPON = 16,
    INVTYPE_WEAPONMAINHAND = 16,
    INVTYPE_WEAPONOFFHAND = 17,
    INVTYPE_HOLDABLE = 17,
    INVTYPE_RANGED = 18,
    INVTYPE_THROWN = 18,
    INVTYPE_RANGEDRIGHT = 18,
    INVTYPE_RELIC = 18,
    INVTYPE_TABARD = 19,
  }
  local secondarySlotMap =
  {
    INVTYPE_FINGER = 12,
    INVTYPE_TRINKET = 14,
    INVTYPE_WEAPON = 17,
  }
  local name, link, quality, iLevel, reqLevel, class, subclass, maxStack, equipSlot, texture, vendorPrice = GetItemInfo(itemLink);
  return equipSlotMap[equipSlot], secondarySlotMap[equipSlot];
end

--! @brief Get the itemLinks of equipment in a set which is either equipped or in the player's bag for the provided slots and the set name
--! @param  setID int     Equipment set index
--! @param  slot1 int     InventorySlotID for the first itemLink
--! @param  slot2 int     InventorySlotID for the second itemLink
--! @return string, table Equipment set name, itemLinks of gear in the equipment set
--! @private
function _scGetItemLinkAndNameForSet(setID, slot1, slot2)
  if not setID then return end
  local setItemLinks = {} -- Table for itemLinks that belong to the set (max: 2).
  local setName, icon, setID = GetEquipmentSetInfo(setID);
  local setEquipmentLocations = GetEquipmentSetLocations(setName);

  if slot1 then
    local player, bank, bags, voidStorage, slot, bag = EquipmentManager_UnpackLocation(setEquipmentLocations[slot1])
    if bags then
      setItemLinks[0] = GetContainerItemLink(bag, slot);
    elseif player then
      setItemLinks[0] = GetInventoryItemLink("player", slot);
    end
  end

  if slot2 then
    player, bank, bags, voidStorage, slot, bag = EquipmentManager_UnpackLocation(setEquipmentLocations[slot2])
    if bags then
      setItemLinks[1] = GetContainerItemLink(bag, slot);
    elseif player then
      setItemLinks[1] = GetInventoryItemLink("player", slot);
    end
  end

  return setName, setItemLinks;
end

--! @brief Decide if stat comparison info should be displayed for an item depending upon what tooltips are already displayed
--! @param eqSetItemLink              itemLink ItemLink in question
--! @param compareItemLink            itemLink ItemLink of what item is being compared to the set equipment
--! @param currentlyEquippedItemLinks table    itemLinked index of what is currently equipped on the character
--! @return boolean
--! @private
function _scSetItemShouldBeDisplayed(eqSetItemLink, compareItemLink, currentlyEquippedItemLinks)
  -- if there is no set item, then it cannot be displayed
  if not eqSetItemLink then return false; end
  -- if the compare item is the same as the equipment set item, don't display the eq set item
  if compareItemLink == eqSetItemLink then return false; end
  -- if the equipment set item is currently equipped, the Blizzard currently equipped tooltip already shows the info
  if currentlyEquippedItemLinks[eqSetItemLink] then return false; end

  -- if we've made it this far, then display the equipment set item in SetCompare
  return true;
end

--! @brief Adds SetCompare text to a tooltip
--! @param tooltip            GameTooltip   Tooltip to add text to
--! @param setItemLinks       table         index is itemLink of items to display, value is a table where values is the text to display alongside the itemLink
--! @param comparisonItemLink itemLink      Item to compare with the setItemLinks
--! @private
function _scDisplayOnTooltip(tooltip, setItemLinks, comparisonItemLink)
  if not tooltip then tooltip = GameTooltip; end
  local setHeader = nil;
  local deltaFlag = false;
  local setFlag = false;

  tooltip:AddLine(" ");
  tooltip:AddLine("SetCompare");
  for itemLink, setNames in pairs(setItemLinks) do
    --- Display the header for an item
    if deltaFlag then
      tooltip:AddLine(" ");
    end

    setHeader = itemLink .. " - Set(s): ";
    for _, setName in pairs(setNames) do
      if setFlag then
        setHeader = setHeader .. ", " .. setName;
      else
        setHeader = setHeader .. setName;
        setFlag = true;
      end
    end
    setFlag = false;
    tooltip:AddLine(setHeader);

    --- Display the delta
    _scDisplayDelta(tooltip, comparisonItemLink, itemLink);
    deltaFlag = true;
  end

  tooltip:Show();
end

--! @brief Add stat comparison information between two items to a tooltip
--! @param tooltip   GameTooltip   Tooltip to add the text to
--! @param itemLink1 itemLink      First item for comparison
--! @param itemLink2 itemLink      Second item for comparison
--! @private
function _scDisplayDelta(tooltip, itemLink1, itemLink2)
  if not tooltip then tooltip = GameTooltip; end
  if not itemLink1 or not itemLink2 then return end

  statDelta = GetItemStatDelta(itemLink1, itemLink2)
  for stat, value in pairs(statDelta) do
    -- Only show stats which exist in _G.  Eg: Some stats are blank when I tested for some reason; even from Blizzard
    if _G[stat] then
      -- Round to one decimal place for DPS
      -- Thanks to jurmerian for this localization-free way of detecting dps
      if stat == "ITEM_MOD_DAMAGE_PER_SECOND_SHORT" then
        value = math.floor(value * 10 + 0.5) / 10;
      end

      if value > 0 then
        tooltip:AddLine("+" .. value .. " " .. _G[stat], 0, 1, 0);
      else
        tooltip:AddLine(value .. " " .. _G[stat], 1, 0, 0);
      end
    end
  end
end
