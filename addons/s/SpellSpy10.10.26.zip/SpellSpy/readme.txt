SpellSpy - A Spell Brower Addon
-------------------------------
With this addon you can lookup and browse all spells in World of Warcraft.
Slash command is "/ss". To set a spell filter use "/ss <filter>". Clear filter with "/ss --clear". Show spell by spell id "/ss --<id>"

So what can I use it for?
-------------------------
Personally I use this tool for a lot of things, I'll give an example. I am at the auction house, and need to buy mats for the "Tuskarr's Vitality" enchant,
but instead of trying to find an enchanter who can link me the mats, or going to Wowhead, I just type in "/ss Tuskarr" and I can look at the tooltip what that enchant needs.
It can also be used to check up abilities of bosses.