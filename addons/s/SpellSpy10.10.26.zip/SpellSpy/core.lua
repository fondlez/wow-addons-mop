-- Global Chat Message Function
function AzMsg(msg) DEFAULT_CHAT_FRAME:AddMessage(tostring(msg):gsub("|1","|cffffff80"):gsub("|2","|cffffffff"),0.5,0.75,1.0); end

-- Addon
local modName = "SpellSpy";
local core = CreateFrame("Frame",modName,UIParent);

-- Config
local cfg;
local defaultConfig = {
	sortMethod = "name",
	displayMode = "normal",
};

-- Variables
local spellList = {};
local spellCustomList;

-- Constants
local SPELL_LINK_FORMAT = "|cff71d5ff|Hspell:%d|h[%s]|h|r";
local POWERTYPE_NAMES = { [-2] = HEALTH, [0] = MANA, [1] = RAGE, [2] = FOCUS, [3] = ENERGY, [4] = HAPPINESS, [5] = RUNES, [6] = RUNIC_POWER, [7] = SOUL_SHARDS, [8] = ECLIPSE, [9] = HOLY_POWER };
local MAX_SPELL_ID = 150000;
local MAX_ENTRIES = 9;
local ITEM_SIZE = 36;

--------------------------------------------------------------------------------------------------------
--                                           Frame Scripts                                            --
--------------------------------------------------------------------------------------------------------

core:RegisterEvent("VARIABLES_LOADED");

-- OnEvent
local function OnEvent(self,event,...)
	self[event](self,event,...);
end

-- Variables Loaded
function core:VARIABLES_LOADED(event)
	-- init cfg
	if (not SpellSpy_Config) then
		SpellSpy_Config = {};
	end
	cfg = setmetatable(SpellSpy_Config,{ __index = defaultConfig });
	if (not SpellSpy_CustomList) then
		SpellSpy_CustomList = {};
	end
	spellCustomList = SpellSpy_CustomList;
	-- dropdown
	self.dropDown:InitSelectedItem(cfg.displayMode);
	self.dropDown2:InitSelectedItem(cfg.sortMethod);
	-- cleanup
	self:UnregisterEvent(event);
	self[event] = nil;
end

--------------------------------------------------------------------------------------------------------
--                                          Initialize Frame                                          --
--------------------------------------------------------------------------------------------------------

core:SetWidth(444);
core:SetHeight(MAX_ENTRIES * ITEM_SIZE + 66 + 30);
core:SetPoint("CENTER");
core:SetBackdrop({ bgFile = "Interface\\ChatFrame\\ChatFrameBackground", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16, insets = { left = 3, right = 3, top = 3, bottom = 3 } });
core:SetBackdropColor(0.1,0.22,0.35,1);
core:SetBackdropBorderColor(0.1,0.1,0.1,1);
core:EnableMouse(1);
core:SetMovable(1);
core:SetToplevel(1);
core:SetClampedToScreen(1);
core:Hide();

core:SetScript("OnEvent",OnEvent);
core:SetScript("OnMouseDown",core.StartMoving);
core:SetScript("OnMouseUp",core.StopMovingOrSizing);

core.outline = CreateFrame("Frame",nil,core);
core.outline:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } });
core.outline:SetBackdropColor(0.1,0.1,0.2,1);
core.outline:SetBackdropBorderColor(0.8,0.8,0.9,0.4);
core.outline:SetPoint("TOPLEFT",12,-38);
core.outline:SetPoint("BOTTOMRIGHT",-12,42);

local function SpellSpyClose_OnClick(self,button,down)
	core:Hide();
	for i = 1, #spellList do
		wipe(spellList[i]);
	end
	wipe(spellList);
	collectgarbage();
end

core.close = CreateFrame("Button",nil,core,"UIPanelCloseButton");
core.close:SetPoint("TOPRIGHT",-4,-4);
core.close:SetScript("OnClick",SpellSpyClose_OnClick);

core.header = core:CreateFontString(nil,"ARTWORK","GameFontHighlight");
core.header:SetPoint("TOPLEFT",12,-12);
core.header:SetFont(core.header:GetFont(),26,"THICKOUTLINE");

--------------------------------------------------------------------------------------------------------
--                                          Helper Functions                                          --
--------------------------------------------------------------------------------------------------------

-- Sort Spells
local function SortSpellsFunc(a,b)
	if (cfg.sortMethod == "id") then
		return a.id < b.id;
	elseif (a.name == b.name) then
		return (tonumber(a.rank:match("%d+")) or 0) < (tonumber(b.rank:match("%d+")) or 0);
	else
		return a.name < b.name;
	end
end

--------------------------------------------------------------------------------------------------------
--                                       DropDown - Display Mode                                      --
--------------------------------------------------------------------------------------------------------

local function DropDown_Init(parent,list)
	list[1].text = "Normal"; list[1].value = "normal";
	list[2].text = "Custom Pick"; list[2].value = "custom";
--	list[3].text = "Combat Monitor"; list[3].value = "combat";
end

local function DropDown_SelectValue(parent,entry,index)
	cfg.displayMode = entry.value;
	core:BuildSpellTable();
end

core.dropDown = AzDropDown.CreateDropDown(core,133,true,DropDown_Init,DropDown_SelectValue);
core.dropDown:SetPoint("BOTTOMLeft",13,13);
core.dropDown.label:SetText("Display Mode...");

--------------------------------------------------------------------------------------------------------
--                                           DropDown - Sort                                          --
--------------------------------------------------------------------------------------------------------

local function DropDown2_Init(parent,list)
	list[1].text = "|cffffa0a0Unsorted"; list[1].value = "none";
	list[2].text = "Sort by Name"; list[2].value = "name";
	list[3].text = "Sort by Spell ID"; list[3].value = "id";
end

local function DropDown2_SelectValue(parent,entry,index)
	cfg.sortMethod = entry.value;
	if (entry.value ~= "none") then
		sort(spellList,SortSpellsFunc);
		core:UpdateList();
	else
		core:BuildSpellTable();
	end
end

core.dropDown2 = AzDropDown.CreateDropDown(core,133,true,DropDown2_Init,DropDown2_SelectValue);
core.dropDown2:SetPoint("BOTTOMRIGHT",-13,13);
core.dropDown2.label:SetText("Sort Method...");

--------------------------------------------------------------------------------------------------------
--                                               Entries                                              --
--------------------------------------------------------------------------------------------------------

core.entries = {};

-- OnClick
local function Entry_OnClick(self,button)
	local id = spellList[self.index].id;
	local editBox = ChatEdit_GetActiveWindow();
	if (IsModifiedClick("CHATLINK")) and (editBox) and (editBox:IsVisible()) then
		editBox:Insert(GetSpellLink(id) or format(SPELL_LINK_FORMAT,id,GetSpellInfo(id)));
	elseif (IsShiftKeyDown()) then
		if (spellCustomList[id]) then
			spellCustomList[id] = nil
			self.name:SetTextColor(1,1,1);
		else
			spellCustomList[id] = true;
			self.name:SetTextColor(0.5,1,0.5);
		end
		if (cfg.displayMode == "custom") then
			core:BuildSpellTable();
		end
	end
end

-- OnEnter
local function Entry_OnEnter(self)
	GameTooltip:SetOwner(self,"ANCHOR_LEFT");
	GameTooltip:SetHyperlink("spell:"..spellList[self.index].id);
end

-- Hide GTT
local function HideGTT()
	GameTooltip:Hide();
end

-- Make Entries
for i = 1, MAX_ENTRIES do
	local btn = CreateFrame("Button",nil,core);
	btn:SetHeight(ITEM_SIZE);

	btn:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestLogTitleHighlight");
	btn:GetHighlightTexture():SetVertexColor(0.1,0.22,0.35);
	btn:SetScript("OnClick",Entry_OnClick);
	btn:SetScript("OnEnter",Entry_OnEnter);
	btn:SetScript("OnLeave",HideGTT);

	btn.icon = btn:CreateTexture(nil,"ARTWORK");
	btn.icon:SetPoint("TOPLEFT",2,-2);
	btn.icon:SetPoint("BOTTOMLEFT",2,2);
	btn.icon:SetWidth(ITEM_SIZE - 4);
	btn.icon:SetTexCoord(0.07,0.93,0.07,0.93);

	btn.name = btn:CreateFontString(nil,"ARTWORK","GameFontHighlight");
	btn.name:SetPoint("TOPLEFT",btn.icon,"TOPRIGHT",3,-3);
	btn.name:SetTextColor(1,1,1);

	btn.info = btn:CreateFontString(nil,"ARTWORK","GameFontNormalSmall");
	btn.info:SetPoint("BOTTOMLEFT",btn.icon,"BOTTOMRIGHT",8,3);
	btn.info:SetTextColor(1,1,1);
	btn.info:SetTextColor(0.6,0.6,0.6);

	if (i == 1) then
		btn:SetPoint("TOPLEFT",18,-46);
		btn:SetPoint("TOPRIGHT",-12,-46);
	else
		btn:SetPoint("TOPLEFT",core.entries[#core.entries],"BOTTOMLEFT");
		btn:SetPoint("TOPRIGHT",core.entries[#core.entries],"BOTTOMRIGHT");
	end

	core.entries[i] = btn;
end

-- Scroll
core.scroll = CreateFrame("ScrollFrame","SpellSpyScroll",core,"FauxScrollFrameTemplate");
core.scroll:SetPoint("TOPLEFT",core.entries[1]);
core.scroll:SetPoint("BOTTOMRIGHT",core.entries[#core.entries],-28,-1);
core.scroll:SetScript("OnVerticalScroll",function(self,offset) local func = core.UpdateList; FauxScrollFrame_OnVerticalScroll(self,offset,ITEM_SIZE,func); end);
FauxScrollFrame_Update(core.scroll,#core.entries,MAX_ENTRIES,ITEM_SIZE);

--------------------------------------------------------------------------------------------------------
--                                                Code                                                --
--------------------------------------------------------------------------------------------------------

-- Update List
function core:UpdateList()
	FauxScrollFrame_Update(core.scroll,#spellList,MAX_ENTRIES,ITEM_SIZE);
	local index = core.scroll.offset;
	local gttOwner = GameTooltip:GetOwner();
	-- Loop Entries
	for i = 1, MAX_ENTRIES do
		index = (index + 1);
		local btn = core.entries[i];
		if (spellList[index]) then
			local id = spellList[index].id;
			local name, rank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo(id);
			local powerName = (POWERTYPE_NAMES[powerType] or " (type "..tostring(powerType)..")");
			local costText = (cost == 0 and powerType == 0 and "None") or (cost.." "..powerName);
			local castTimeText = castTime == 0 and "Instant" or format("%.3f sec",castTime / 1000);
			local rangeText = (maxRange == 0 and tostring(minRange) or minRange == 0 and tostring(maxRange) or tostring(minRange).." - "..tostring(maxRange)).." yards";

			btn.icon:SetTexture(icon);
			btn.name:SetFormattedText((rank and rank ~= "") and "%s |cff20ff20(%s)|r" or "%s",name,rank);
			btn.info:SetFormattedText("ID: |cffffff00%d|r, Cost: |cffffff00%s|r, Cast Time: |cffffff00%s|r, Range: |cffffff00%s%s|r.",id,costText,castTimeText,rangeText,(isFunnel and "|cffc0c0c0  Funneled" or ""));
			btn.index = index;

			if (spellCustomList[id]) then
				btn.name:SetTextColor(0.5,1,0.5);
			else
				btn.name:SetTextColor(1,1,1);
			end

			if (btn == gttOwner) then
				Entry_OnEnter(btn);
			end

			btn:Show();
		else
			btn:Hide();
		end
	end
end

-- Build List, Sort and Update
function core:BuildSpellTable()
	-- cleanup
	for i = 1, #spellList do
		wipe(spellList[i]);
	end
	wipe(spellList);
	-- Normal
	if (cfg.displayMode == "normal") then
		if (type(cfg.filter) == "number") then
			local name, rank = GetSpellInfo(cfg.filter);
			spellList[#spellList + 1] = { id = cfg.filter, name = name:lower(), rank = rank:lower() };
		else
			for i = 1, MAX_SPELL_ID do
				local name, rank = GetSpellInfo(i);
				if (name) and (not cfg.filter or name:lower():find(cfg.filter)) then
					spellList[#spellList + 1] = { id = i, name = name:lower(), rank = rank:lower() };
				end
			end
		end
	-- Custom
	elseif (cfg.displayMode == "custom") then
		for id in next, spellCustomList do
			local name, rank = GetSpellInfo(id);
			spellList[#spellList + 1] = { id = id, name = name:lower(), rank = rank:lower() };
		end
	end
	-- Sort
	if (cfg.sortMethod ~= "none") then
		sort(spellList,SortSpellsFunc);
	end
	core.header:SetFormattedText("SpellSpy (|cffffff20%d|r)",#spellList);
	self:UpdateList();
end

--------------------------------------------------------------------------------------------------------
--                                           Slash Handling                                           --
--------------------------------------------------------------------------------------------------------
_G["SLASH_"..modName.."1"] = "/ss";
SlashCmdList[modName] = function(cmd)
	local code = cmd:match("^%-%-(.+)");
	-- Show/Hide Dialog
	if (cmd == "") then
		if (core:IsVisible()) then
			core:Hide();
		else
			core:BuildSpellTable();
			core:Show();
		end
	-- Filter by SpellId
	elseif (code) and (tonumber(code)) then
		if (GetSpellInfo(tonumber(code))) then
			cfg.filter = tonumber(code);
			cfg.displayMode = "normal";
			core.dropDown:InitSelectedItem(cfg.displayMode);
			AzMsg("|2"..modName.."|r: Spell filter set to the spell |1"..GetSpellInfo(cfg.filter).."|r.");
			core:BuildSpellTable();
			core:Show();
		else
			AzMsg("|2"..modName.."|r: There is no spell with that id.");
		end
	-- Clears the Filter
	elseif (code == "clear") then
		cfg.filter = nil;
		AzMsg("|2"..modName.."|r: Spell filter cleared.");
		core:BuildSpellTable();
	-- Sets the Filter
	elseif (not code) then
		cfg.filter = cmd:lower();
		cfg.displayMode = "normal";
		core.dropDown:InitSelectedItem(cfg.displayMode);
		AzMsg("|2"..modName.."|r: Matching spells containing the string: |1"..cfg.filter.."|r.");
		core:BuildSpellTable();
		core:Show();
	-- Invalid or No Command
	else
		UpdateAddOnMemoryUsage();
		AzMsg(format("----- |2%s|r |1%s|r ----- |1%.2f |2kb|r -----",modName,GetAddOnMetadata(modName,"Version"),GetAddOnMemoryUsage(modName)));
		AzMsg("The following |2parameters|r are valid for this addon:");
		AzMsg(" |2--clear|r = Clears the current filter");
		AzMsg(" |2--<spellId>|r = Shows the spell with the given spellId, if one exists");
		AzMsg(" |2<filter>|r = Set the filter for which spells to display");
	end
end