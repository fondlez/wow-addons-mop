local addonName = ...
local SimpleActionSets = _G[addonName]
local L = LibStub( "AceLocale-3.0" ):GetLocale(addonName)

local SAS_Temp
local barLength = 12
local maxBar = 9
local enumForceClear, enumForceNoChange = 0, 1
local enumName, enumTexture, enumRank, enumLink, enumMacroID, enumSpellID = 1, 2, 3, 4, 5, 6

-----------------------
-- Get/Set Functions --
-----------------------

function SimpleActionSets:GetTemp(x, y)
	if ( x and y ) then
		return SAS_Temp[x][y]
	elseif (x) then
		return SAS_Temp[x]
	else
		return SAS_Temp
	end
end

function SimpleActionSets:SetTemp(x, y, value)
	if ( x and y ) then
		SAS_Temp[x][y] = value
	elseif (x) then
		SAS_Temp[x] = value
	else
		SAS_Temp = value
	end
end

function SimpleActionSets:GetMaxBar()
	return maxBar
end

function SimpleActionSets:GetBarLength()
	return barLength
end

function SimpleActionSets:GetForceClear()
	return enumForceClear
end

function SimpleActionSets:GetForceNoChange()
	return enumForceNoChange
end

function SimpleActionSets:GetEnumName()
	return enumName
end

function SimpleActionSets:GetEnumTexture()
	return enumTexture
end

------------------------
-- Reusable Functions --
------------------------

function SimpleActionSets:TableIsEmpty(table)
	return next(table) == nil
end

function SimpleActionSets:ToBool(value)
	return value == 1
end

function SimpleActionSets:PairsByKeys(t, f)
	local a = {}
	for n in pairs(t) do table.insert(a, n) end
		table.sort(a, f)
		local i = 0
		local iter = function ()
			i = i + 1
			if a[i] == nil then return nil
				else return a[i], t[a[i]]
			end
		end
	return iter
end

function SimpleActionSets:BarEnabled(bar, set)
	if ( not set ) then set = SAS_Temp end
	if ( set and set[bar] ) then
		return not set[bar][0]
	end
end

function SimpleActionSets:BarHasActions(bar, set)
	if ( not set ) then
		set = SAS_Temp
	end
	if ( bar and set[bar] ) then
		for i = 1, barLength do
			if ( set[bar][i] ) then
				return 1
			end
		end
	end
end

function SimpleActionSets:SetTooltip(self, bar, slot)
	-- Sets the Tooltip for the found action
	if ( not bar or not slot ) then return end
	if ( SAS_Temp[bar][slot] ) then
		if ( SAS_Temp[bar][slot] == enumForceClear ) then
			GameTooltip:SetText(L["SAS_TEXT_TOOLTIP_FORCECLEAR"], 1, 1, 1)
			SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_FORCECLEAR_TIP"])
			GameTooltip:Show()
		elseif ( SAS_Temp[bar][slot] == enumForceNoChange ) then
			GameTooltip:SetText(L["SAS_TEXT_TOOLTIP_FORCENOAPPLY"], 1, 1, 1)
			SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_FORCENOAPPLY_TIP"])
			GameTooltip:Show()
		else
			local name, texture, rank, link, macro, actionSpellID = SimpleActionSets:ParseActionInfo(SAS_Temp[bar][slot])
			local TooltipReturn
			-- is a macro
			if ( macro ) then
				TooltipReturn = GameTooltip:SetText(name, 1, 1, 1)
				local macroName,macroTexture,macroText = GetMacroInfo(SimpleActionSets:FindMacro(name, texture, macro))
				if ( macroText ) then
					GameTooltip:AddLine(macroText, 0.75, 0.75, 0.75, 1, 1)
					GameTooltip:Show()
				else
					SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOMACRO"])
				end
			-- is a companion
			elseif ( rank == "MOUNT" ) then
				local companionid, spellid = SimpleActionSets:FindCompanion(name, rank)
				if ( companionid ) then
					TooltipReturn = GameTooltip:SetHyperlink("spell:" .. spellid)
				else
					TooltipReturn = GameTooltip:SetText(name, 1, 1, 1)
					SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOCOMPANION"])
				end
			-- is a battle pet
			elseif ( rank == "summonpet" ) then
				local battlePetName = select(8, C_PetJournal.GetPetInfoByPetID(link))
				if ( battlePetName ) then
					TooltipReturn = GameTooltip:SetText(battlePetName, 1, 1, 1)
					GameTooltip:AddLine(L["SAS_PET_COMPANION_TOOLTIP_LINE_1"], 1, 1, 1)
					GameTooltip:AddLine(L["SAS_PET_COMPANION_TOOLTIP_LINE_2"] .. "\n" .. battlePetName .. ".")
					GameTooltip:Show()
				else
					SimpleActionSets:TooltipAddLine( L["SAS_TEXT_TOOLTIP_NOBATTLEPET"] )
				end
			-- is an equipment set
			elseif ( rank == "equipmentset" ) then
				local equipSetIcon = GetEquipmentSetInfoByName(name)
				if ( equipSetIcon ) then
					TooltipReturn = GameTooltip:SetEquipmentSet(name)
				else
					TooltipReturn = GameTooltip:SetText(name, 1, 1, 1)
					SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOEQUIPMENTSET"])
				end
			-- is a flyout menu
			elseif ( rank == "flyout" ) then
				local _, description, _, isKnown = GetFlyoutInfo(link)
				TooltipReturn = GameTooltip:SetText(name, 1, 1, 1)
				if (isKnown) then
					GameTooltip:AddLine(description)
					GameTooltip:Show()
				else
					SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOFLYOUT"])
				end
			-- is an item
			elseif ( link ) then
				local itemLink
				if ( link == "?" ) then
					itemLink = SimpleActionSets:FindItem(name)
					if ( itemLink ) then
						link = SimpleActionSets:FindLink(itemLink)
					else
						link = nil
					end
				else
					itemLink = SimpleActionSets:FindItem(link)
				end
				if ( link and select(2, GetItemInfo(link)) ) then
					TooltipReturn = GameTooltip:SetHyperlink(select(2, GetItemInfo(link)))
					if ( not itemLink ) then
						SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOTHAVE"])
					end
				else
					TooltipReturn = GameTooltip:SetText(name, 1, 1, 1)
					SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOTVALID"])
				end
			-- is a spell
			else
				local spellNum = SimpleActionSets:FindSpell(name, rank, actionSpellID)
				if ( spellNum ) then
					TooltipReturn = GameTooltip:SetSpellBookItem(spellNum, "spell")
				else
					TooltipReturn = GameTooltip:SetText(name, 1, 1, 1)
					SimpleActionSets:TooltipAddLine(L["SAS_TEXT_TOOLTIP_NOSPELL"])
				end
			end
		end
		if ( TooltipReturn ) then
			self.updateTooltip = TOOLTIP_UPDATE_TIME
		else
			self.updateTooltip = nil
		end
	end
end

function SimpleActionSets:TooltipAddLine(msg)
	-- Adds a coloured line to the tooltip
	GameTooltip:AddLine(msg, 0.012, 0.658, 0.62, 1, 1)
	GameTooltip:Show()
end

function SimpleActionSets:CalcSlotAndBar(id)
	-- slot is 1-12, bar is 0-9
	local slot = mod(id - 1, barLength) + 1
	local bar = (id - slot) / barLength
	return slot, bar
end

function SimpleActionSets:GetNumSpellBookItems()
	local t = GetNumSpellTabs()
	local n
	while true do
		local name, _, offset, numSpells = GetSpellTabInfo(t)
		if ( not name ) then
			break
		end
		n = offset + numSpells
		t = t + 1
	end
	return n
end

function SimpleActionSets:CopyTable(copyTable)
	-- properly copies a table instead of referencing the same table, thanks Sallust.
	if ( not copyTable ) then return end
	local returnTable = {}
	for k, v in pairs(copyTable) do
		if ( type(v) == "table" ) then
			returnTable[k] = self:CopyTable(v)
		else
			returnTable[k] = v
		end
	end
	return returnTable
end

-------------------------------
-- Action Building Functions --
-------------------------------

function SimpleActionSets:BuildCursorAction()
	self:FakeDrag_Drop(true)
	local curtype, detail, subdetail, spellID = GetCursorInfo()
	if ( not curtype ) then
		return
	elseif ( curtype == "item" ) then
		local name, _, _, _, _, _, _, _, _, texture = GetItemInfo(detail)
		if ( name ) then
			return self:BuildActionInfo(name, texture, nil, detail)
		end
	elseif ( curtype == "spell" ) then
		local name, rank, texture = GetSpellInfo(spellID)
		return self:BuildActionInfo(name, texture, rank, nil, nil, spellID)
	elseif ( curtype == "companion" ) then
		local _, name, _, texture = GetCompanionInfo(subdetail, detail)
		if ( name ) then
			return self:BuildActionInfo(name, texture, subdetail)
		end
	elseif ( curtype == "battlepet" ) then
		local name, texture = select(8, C_PetJournal.GetPetInfoByPetID(detail))
		return self:BuildActionInfo(name, texture, "summonpet", detail)
	elseif ( curtype == "equipmentset" ) then
		local icon = GetEquipmentSetInfoByName(detail)
		return self:BuildActionInfo(detail, "Interface\\Icons\\" .. icon, curtype)
	elseif ( curtype == "flyout" ) then
		local name = GetFlyoutInfo(detail)
		return self:BuildActionInfo(name, subdetail, curtype, detail)
	elseif ( curtype == "macro" ) then
		local name, texture = GetMacroInfo(detail)
		if ( name ) then
			return self:BuildActionInfo(name, texture, nil, nil, detail)
		end
	end
end

function SimpleActionSets:BuildActionInfo(...)
	if ( select("#", ...) == 0 ) then return end

	-- ... = name, texture, rank, link, macroID, spellID
	local temp, string, i = ""
	for i = 1, select("#",...) do
		local val = select(i,...)
		if ( val ) then
			string = (string or "") .. temp .. (val or "") .. "�"
			temp = ""
		else
			temp = temp .. "�"
		end
	end
	return string
end

function SimpleActionSets:IncActionInfo(action, val, part)
	-- Used to update a single element of an action
	if ( not val ) then return end

	local a = {self:ParseActionInfo(action)}
	a[part] = val

	return self:BuildActionInfo(a[enumName], a[enumTexture], a[enumRank], a[enumLink], a[enumMacroID], a[enumSpellID])
end

function SimpleActionSets:ParseActionInfo(action, ...)
	-- Returns action[1] to action[6] if ... is empty, if it contains numbers it
	-- returns those parts in order, eg (action, 4, 2) returns action[4], action[2]
	if ( not action ) then return end
	if type(action) ~= "string" then return action end
	local a = { strsplit("�", action) }
	for k, v in pairs(a) do
		if v == "" then
			a[k] = nil
		end
	end
	if ( select("#", ...) > 0 ) then
		local b = {}
		for i = 1, select("#", ...) do
			tinsert(b, a[select(i, ...)])
		end
		return unpack(b)
	else
		return a[enumName], a[enumTexture], a[enumRank], a[enumLink], tonumber(a[enumMacroID]), tonumber(a[enumSpellID])
	end
end

function SimpleActionSets:GetActionInfo(id)
	if ( not HasAction(id) ) then return end

	local actionType, typeId, subType = GetActionInfo(id)

	if ( actionType == "spell" ) then
		local spellID
		-- Morphed spells aren't 'known', but their base spell is
		if ( IsSpellKnown(typeId) ) then
			-- Unmorphed Spell
			spellID = typeId
		else
			-- Morphed Spell
			-- Picking up the action off the action bar then using GetCursorInfo returns the base spell ID.
			PickupAction(id)
			spellID = select(4, GetCursorInfo())
			self:Debug("Morphed Spell: "..GetSpellInfo(typeId).." ("..typeId..") base: "..GetSpellInfo(spellID).." ("..spellID..")")
			PlaceAction(id)
		end
		local name, rank, texture = GetSpellInfo(spellID)
		return name, texture, rank, nil, nil, spellID
	elseif ( actionType == "item" ) then
		local texture = GetActionTexture(id)
		return (GetItemInfo(typeId)), texture, nil, typeId
	elseif ( actionType == "macro" ) then
		local name, texture = GetMacroInfo(typeId)
		if ( not texture ) then
			texture = GetActionTexture(id)
		end
		return name, texture, nil, nil, typeId
	elseif ( actionType == "companion" ) then
		local name = GetSpellInfo(typeId)
		local companionId = self:FindCompanion(name, subType)
		local texture = select(4, GetCompanionInfo(subType, companionId))
		return name, texture, subType -- treat companions as spells for now
	elseif ( actionType == "summonpet") then
		-- typeID = petID
		local name, texture = select(8, C_PetJournal.GetPetInfoByPetID(typeId))
		return name, texture, actionType, typeId
	elseif ( actionType == "equipmentset" ) then
		local icon = GetEquipmentSetInfoByName(typeId)
		return typeId, "Interface\\Icons\\" .. icon, actionType
	elseif ( actionType == "flyout" ) then
		-- GetCursorInfo seems to be only way of finding a flyout's texture
		self:PickupFlyout(typeId)
		local texture = select(3, GetCursorInfo())
		ClearCursor()
		local name = GetFlyoutInfo(typeId)
		return name, texture, actionType, typeId
	end
end

function SimpleActionSets:IterateActions()
	-- Iterate over all current actions
	local actionlist = {}
	for i = 0, maxBar do
		actionlist[i] = {}
		for j = 1, barLength do
			actionlist[i][j] = self:BuildActionInfo(self:GetActionInfo(j + (i * barLength)))
		end
	end

	return actionlist
end

--------------------------
-- Action Set Functions --
--------------------------

function SimpleActionSets:SwapSet(set, player, restoringBackup)
	if ( not player ) then
		player = self:GetPlrName()
		self:Debug("self:SwapSet - No player name specified, using " .. player)
	end

	local actions
	if ( set ) then
		self:Debug("self:SwapSet - about to do copy table on self.db.profiles[" .. player .. "].sets[" .. set .. "]")
		actions = self:CopyTable(self.db.profiles[player].sets[set])
	elseif ( SASMain:IsVisible() ) then
		self:Debug("self:SwapSet - about to do copy table on SAS_Temp")
		actions = self:CopyTable(SAS_Temp)
	else
		return
	end

	if ( not actions ) then
		self:Debug("|wNo actions to change to.")
		return
	end

	if ( not self:GetCombatStatus() ) then
		self:DoSwap(actions, set, player, restoringBackup)
	end
end

function SimpleActionSets:DoSwap(actions, set, player, restoringBackup)
	-- Swaps a saved set to the player's real action bars.
	self:SetSwappingSet(true)
	if ( not player or player == self:GetPlrName() ) then
		self:SetCurrentSet(set)
	end
	ClearCursor()
	for i = 0, maxBar do
		if ( self:BarEnabled(i, actions) and (self:BarHasActions(i, actions) or self.db.profile.emptyBars or restoringBackup) ) then
			for j = 1, barLength do
				local id = j + i * barLength
				local msg = "Action " .. id
				if ( actions[i][j] ) then
					if ( actions[i][j] == enumForceClear ) then
						msg = msg .. " forced cleared."
						self:ClearSlot(id, true)
					elseif ( actions[i][j] == enumForceNoChange ) then
						msg = msg .. " forced no change."
					else
						local ename, _, erank, elink, emacro, eActionSpellID = self:GetActionInfo(id)
						local name, texture, rank, link, macro, actionSpellID = self:ParseActionInfo(actions[i][j])
						if ( (name == ename and ((rank == erank) or (macro and emacro) or (link and elink))) or (eActionSpellID and eActionSpellID == actionSpellID)) then
							msg = msg .. " is the same as the one trying to be swapped."
						else
							if ( macro ) then
								msg = msg .. " is a macro."
								local macroID = self:FindMacro(name, texture, macro)
								if ( macroID ) then
									PickupMacro(macroID)
									PlaceAction(id)
								else
									msg = msg .. " |wCouldn't find macro."
									self:ClearSlot(id)
								end
							elseif ( rank == "MOUNT" ) then
								msg = msg .. " is a companion."
								local companionId = self:FindCompanion(name, rank)
								if ( companionId ) then
									PickupCompanion(rank, companionId)
									PlaceAction(id)
								else
									msg = msg .. " |wCouldn't find companion."
									self:ClearSlot(id)
								end
							elseif ( rank == "summonpet" ) then
								-- name is actually battle pet id as its a unique identifier
								msg = msg .. " is a battle pet."
								local battlePetInfo = C_PetJournal.GetPetInfoByPetID(link)
								if ( battlePetInfo ) then
									C_PetJournal.PickupPet(link)
									PlaceAction(id)
								else
									msg = msg .. " |wCouldn't find battlepet."
									self:ClearSlot(id)
								end
							elseif ( rank == "equipmentset" ) then
								msg = msg .. " is an equipment set."
								local equipSetIcon = GetEquipmentSetInfoByName(name)
								if ( equipSetIcon ) then
									PickupEquipmentSetByName(name)
									PlaceAction(id)
								else
									msg = msg .. " |wCouldn't find equipment set."
									self:ClearSlot(id)
								end
							elseif ( rank == "flyout") then
								msg = msg .. " is a flyout menu."
								local isKnown = select(4, GetFlyoutInfo(link))
								if ( isKnown ) then
									self:PickupFlyout(link)
									PlaceAction(id)
								else
									msg = msg .. " |wCouldn't find flyout menu."
									self:ClearSlot(id)
								end
							elseif ( link ) then
								msg = msg .. " is an item."
								if ( not self:PlaceItem(id, link, name, set) ) then
									msg = msg .. " |wCouldn't find item."
								end
							elseif ( name ) then
								msg = msg .. " is a spell."
								local spellNum = self:FindSpell(name, rank, actionSpellID)
								if ( spellNum ) then
									PickupSpellBookItem(spellNum, "spell")
									PlaceAction(id)
								else
									msg = msg .. " |wCoulnd't find spell."
									self:ClearSlot(id)
								end
							else
								msg = msg .. " has no name, rank, link, macro?"
							end
						end
						ClearCursor()
					end
				self:Debug(msg)
				elseif ( (not self.db.profile.noEmptyButtons) or restoringBackup ) then
					self:ClearSlot(id)
				end
			end
		elseif ( not self:BarEnabled(i, actions) ) then
			self:Debug("Bar " .. (i + 1) .. " not enabled, skipping")
		else
			self:Debug("Bar " .. (i + 1) .. " has no actions, skipping")
		end
	end
	ClearCursor()
	self:SetSwappingSet(false)
end

function SimpleActionSets:SetExists(set)
	-- Check to see if the set already exists
	if ( self.db.profile.sets[set] ) then
		return true
	end
end

function SimpleActionSets:SaveSet(set)
	set = set or self:GetCurrentSet()
	-- Save a set
	if ( not set ) then return end

	local actions
	if ( SASMain:IsVisible() and SAS_Temp ) then
		actions = self:CopyTable(SAS_Temp)
	else
		actions = self:IterateActions()
	end

	self:Print(L["SAS_TEXT_SAVING"] .. set)
	self.db.profile.sets[set] = self:CopyTable(actions)
	self:Actions_Load(set)
end

function SimpleActionSets:Delete(set)
	-- Delete a set
	self:Print(L["SAS_TEXT_DELETING"] .. set)
	self.db.profile.sets[set] = nil
	if ( self:GetCurrentSet() == set ) then
		self:SetCurrentSet()
	end
	self:Actions_Load()
end

function SimpleActionSets:SetDifferent(set1, set2, strict)
	-- Compare two sets to see if they're different
	if ( not ( set1 and set2 ) ) then
		self:Debug("Problem comparing sets: set1 " .. ((set1 and "exists") or "is missing") .. ", set2 " .. ((set2 and "exists") or "is missing"))
		return true
	end

	for i = 0, maxBar do
		if ( set1[i] ) then
			if ( strict ) then
				if ( set1[i][0] ~= set2[i][0] ) then
					return true
				end
			end
			for j = 1, barLength do
				if ( set1[i][j] ) then
					if ( self:ActionDifferent(set1[i][j], set2[i][j]) ) then
						self:Debug("returning at " .. i .. " " .. j)
						return true
					end
				elseif ( strict and set2[i][j] ) then
					self:Debug("strict returning at " .. i .. " " .. j .. " no set 1 but set 2")
					return true
				end
			end
		elseif ( strict and set2[i] ) then
			self:Debug("strict returning at " .. i .. " no set 1 but set 2")
			return true
		end
	end
end

----------------------
-- Action Functions --
----------------------

function SimpleActionSets:ActionDifferent(a, b)
	if ( not ( a and b ) ) then
		self:Debug("Tried to compare a: " .. strsplit("�", a or "missing") .. " and b: " .. strsplit("�", b or "missing"))
		return true
	end

	local A = { self:ParseActionInfo(a) }
	local B = { self:ParseActionInfo(b) }
	for k, v in pairs(A) do
		-- Ignores link in case itemLink has been lost
		-- Ignores spellID in case its missing or incorrect, spell name and rank should be enough to identify correct spell
		if ( k ~= enumLink and k ~= enumSpellID and (not B[k] or v ~= B[k]) ) then
			self:Debug(k .. " " .. v .. " does not == " .. B[k])
			return true
		end
	end
end

function SimpleActionSets:FindLink(item)
	if ( not item ) then return end
	-- Find an item's link number from it's item link
	return strmatch(item, "item:(%d+):")
end

function SimpleActionSets:FindName(item)
	-- Find an item's name from it's item link
	if ( item ) then
		for name in gmatch(item, "%[(.+)%]") do
			return name
		end
	end
end

function SimpleActionSets:FindSpell(spell, rank, spellID)
	if ( not spell ) then return end
	local spellBookIndex
	local isFound = false
	local bookSpellID
	local ignoreRank = false

	-- Due to rank being a new addition, will allow it to ignore rank so old saves don't break
	if ( not rank ) then
		ignoreRank = true
	end

	-- Iterate over spells the player has and return location
	for i = 1, self:GetNumSpellBookItems() do
		local spellName, spellRank = GetSpellBookItemName(i, "spell")
		bookSpellID = select(2, GetSpellBookItemInfo(i, "spell"))
		if ( spellName == spell and ( ignoreRank or spellRank == rank ) and bookSpellID == spellID ) then
			-- self:Debug(spellName.."("..( gsub(spellRank, "^$", "no rank") )..", "..bookSpellID..") = "..spell.."("..(rank or "no rank").. ", "..(spellID or "no spellID")..")")
			isFound = true
			spellBookIndex = i
			break
		elseif ( ( ignoreRank or spellRank == rank ) and ( spellName == spell or bookSpellID == spellID ) ) then
			-- Morphed spell (names don't match)
			-- self:Debug("Morph "..spellName.."("..( gsub(spellRank, "^$", "no rank") )..", "..bookSpellID..") = "..spell.."("..(rank or "no rank").. ", "..(spellID or "no spellID")..")")
			isFound = true
			spellBookIndex = i
			break
		end
	end

	if ( isFound and IsSpellKnown(bookSpellID) ) then
		-- Spell is usable within current specialization
		return spellBookIndex
	else
		return nil
	end
end

function SimpleActionSets:FindMacro(name, texture, macro)
	-- Check saved macro id
	local macroName, macroTexture, bestguess
	if ( macro ) then
		macroName, macroTexture = GetMacroInfo(macro)
		if ( macroName == name ) then
			if ( texture and macroTexture == texture ) then
				return macro
			end
			bestguess = macro
		end
	end

	-- If no direct match, iterate over macros and return matching index
	local numAccountMacros, numCharacterMacros = GetNumMacros()
	numCharacterMacros = numCharacterMacros + MAX_ACCOUNT_MACROS
	for i = 1, MAX_ACCOUNT_MACROS + MAX_CHARACTER_MACROS do
		if ( i > numAccountMacros and i < MAX_ACCOUNT_MACROS + 1 ) then
			-- no more global macros, skip to local
			i = MAX_ACCOUNT_MACROS + 1
		end
		if ( i > numCharacterMacros ) then
			-- no more macros
			break
		end
		macroName, macroTexture = GetMacroInfo(i)
		if ( macroName and macroName == name ) then
			if ( texture and macroTexture == texture ) then
				return i
			end
			bestguess = i
		end
	end

	return bestguess
end

function SimpleActionSets:FindCompanion(name, companionType)
	for i = 1, GetNumCompanions(companionType) do
		local creatureID, creatureName, spellID, icon, _, mountFlags = GetCompanionInfo(companionType, i)
		if (name == creatureName or gsub(name,"Summon ","") == creatureName) then
			-- need to return the index
			return i, spellID
		end
	end
end

function SimpleActionSets:FindItem(item)
	-- Iterate over items the player has and return it's link and location
	if ( not item ) then return end

	item = tostring(item)

	-- Iterate over bags
	for i = 0, NUM_BAG_SLOTS do
		local bagSlots = GetContainerNumSlots(i)
		if ( bagSlots ) then
			for j = 1, bagSlots do
				local itemLink = GetContainerItemLink(i, j)
				if ( itemLink ) then
					if ( item == self:FindLink(itemLink) or item == self:FindName(itemLink) ) then
						return itemLink, i, j
					end
				end
			end
		end
	end

	-- Iterate over paper doll
	for i = 0, INVSLOT_LAST_EQUIPPED do
		local itemLink = GetInventoryItemLink("player", i)
		if ( itemLink ) then
			if ( item == self:FindLink(itemLink) or item == self:FindName(itemLink) ) then
				return itemLink, nil, nil, i
			end
		end
	end
end

function SimpleActionSets:CheckItem(name, id, set)
	if ( not name ) then return end

	local itemLink, bag, slot, inv = self:FindItem(name)
	itemLink = self:FindLink(itemLink)
	if ( not itemLink ) then
		itemLink = "?"
	elseif ( itemLink ~= "?" ) then
		local slot, bar = self:CalcSlotAndBar(id)
		if ( self.db.profile.sets[set] ) then
			local action = self.db.profile.sets[set][bar][slot]
			local iname, ilink = self:ParseActionInfo(action, enumName, enumLink)
			if ( iname ) then
				if ( iname == name and ilink and ilink == "?" ) then
					self:Debug("Updating item in action #" .. id .. " in set " .. set .. " with itemLink.")
					self.db.profile.sets[set][bar][slot] = self:IncActionInfo(action, itemLink, enumLink)
				else
					self:Debug("|wAttempted to update itemLink in action #" .. id .. " but names are wrong?")
				end
			end
		end
	end

	return itemLink, bag, slot, inv
end

function SimpleActionSets:PickupFlyout(id)
	for i = 1, self:GetNumSpellBookItems() do
		local sbtype, sbid = GetSpellBookItemInfo(i, "spell")
		if (sbtype == "FLYOUT" and sbid == tonumber(id)) then
			PickupSpellBookItem(i, "spell")
			break
		end
	end
end

function SimpleActionSets:PlaceItem(id, link, name, set)
	-- Place an item, update set link id if found
	local itemLink, bag, slot, inv

	if ( link == "?" ) then
		itemLink, bag, slot, inv = self:CheckItem(name, id, set)
	else
		itemLink, bag, slot, inv = self:FindItem(link)
	end
	if ( bag ) then
		PickupContainerItem(bag, slot)
		PlaceAction(id)
		return true
	elseif ( inv ) then
		PickupInventoryItem(inv)
		PlaceAction(id)
		return true
	end
end

function SimpleActionSets:ClearSlot(id, force)
	-- Clear an action slot
	if ( HasAction(id) and (force or not self.db.profile.noEmptyButtons) ) then
		PickupAction(id)
		ClearCursor()
	end
end
