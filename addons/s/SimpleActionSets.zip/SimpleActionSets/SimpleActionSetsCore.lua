local addonName = ...
_G[addonName] = LibStub("AceAddon-3.0"):NewAddon(addonName, "AceConsole-3.0", "AceEvent-3.0", "AceHook-3.0")

local SimpleActionSets = _G[addonName]
local L = LibStub("AceLocale-3.0"):GetLocale(addonName)
local minimapIcon = LibStub("LibDBIcon-1.0")

local SAS_SavedPickup
local SAS_ReturnAction
local PlrName
local inCombat
local SAS_SwappingSet
local backupCreatedThisRun = false

-- Basic data broker support
local ldb = LibStub("LibDataBroker-1.1"):NewDataObject(addonName, {
	type = "launcher",
	label = addonName,
	icon = "Interface\\AddOns\\SimpleActionSets\\sas",
	OnClick = function(self, button)
		if ( button == "RightButton" ) then
			ToggleDropDownMenu(1, nil, SAS_SetsDropDown, self, 0, 0)
		else
			SimpleActionSets:Main_Toggle()
		end
	end,
	OnTooltipShow = function(self)
		self:AddLine(addonName)
		self:AddDoubleLine("Current Set", SimpleActionSets:GetCurrentSet(), 1, 1, 1, 0.75, 0.75, 0.75)
	end,
})

local defaults = {
	profile = {
		minimap = {
			hide = false,
			lock = false,
			minimapPos = 270
		},
		noUIWarnings = false,
		emptyBars = false,
		noEmptyButtons = false,
		autoRestore = false,
		noAutoRestoreWarning = false,
		noRemove = false,
		currentSet = nil,
		sets = {}
	},
	global = {
		debug = false
	},
}

function SimpleActionSets:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("SAS_Saved", defaults)
	self:RegisterChatCommand("SAS", "Console")
	minimapIcon:Register(addonName, ldb, self.db.profile.minimap)
	-- Need to load MacroUI to define MAX_CHARACTER_MACROS and MAX_ACCOUNT_MACROS
	LoadAddOn("Blizzard_MacroUI")
	-- Make sure this is loaded otherwise pets can be missing names (cleared cache and first run)
	LoadAddOn("Blizzard_PetJournal")
end

function SimpleActionSets:OnEnable()
	self:RegisterEvent("ACTIONBAR_HIDEGRID")
	self:RegisterEvent("ACTIONBAR_SHOWGRID")
	self:RegisterEvent("PET_JOURNAL_LIST_UPDATE")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")

	PlrName = UnitName("player") .. " - " .. GetCVar("realmName")

	if ( not self.db.profiles["BackUp"] ) then
		self.db.profiles["BackUp"] = {}
		self.db.profiles["BackUp"].sets = {}
		self.db.profiles["BackUp"].sets[PlrName] = {}
		backupCreatedThisRun = true
	end

	SimpleActionSets:CreateUIFrames()

	self:SecureHook("PickupAction", "ActionPickedUp")
	self:SecureHook("CameraOrSelectOrMoveStart", "ForceFakeDrop")
	self:SecureHook("TurnOrActionStart", "ForceFakeDrop")
	self:SecureHook("Logout", "SaveBackup")
	self:SecureHook("ReloadUI", "SaveBackup")
	self:SecureHook("Quit", "SaveBackup")
	-- self:SecureHook("ForceQuit", "SaveBackup")
end

function SimpleActionSets:OnDisable()
	self:UnregisterAllEvents()
	self:UnhookAll()
end

---------------------
-- Event Functions --
---------------------

function SimpleActionSets:ACTIONBAR_HIDEGRID()
	if ( not SAS_SwappingSet ) then
		-- self:Debug("No Valid Item on Cursor")
		SAS_SavedPickup = nil
		SAS_ReturnAction = nil
	end

end

function SimpleActionSets:ACTIONBAR_SHOWGRID()
	if ( not SAS_SwappingSet ) then
		-- self:Debug("Valid Item on Cursor")
		SAS_SavedPickup = self:BuildCursorAction()
	end
end


function SimpleActionSets:PET_JOURNAL_LIST_UPDATE()
	-- Due to the mount/pet journal not being fully loaded when enable code is run, this event is registered as the data needed seems to be ready by that point.
	local currentset = self:GetCurrentSet()
	local liveactions = self:IterateActions()

	if ( self.db.profile.autoRestore and self.db.profiles["BackUp"] and self.db.profiles["BackUp"].sets[PlrName] ) then
		if ( self:SetDifferent(liveactions, self.db.profiles["BackUp"].sets[PlrName], true) ) then
			self:Warning("CHANGEDSINCELAST", function() self:RestoreBackUp() end, nil, true)
			return
		end
	end

	if ( backupCreatedThisRun ) then
		self.db.profiles["BackUp"].sets[PlrName] = liveactions
	end

	if ( currentset ) then
		if ( self:SetDifferent(liveactions, self.db.profile.sets[currentset]) ) then
			self:Debug(currentset .. " does not appear to be loaded.")
			self:SetCurrentSet()
		else
			self:Debug(currentset .. " appears to be loaded, keeping as current set.")
		end
	end
	-- Only want this code to run once
	self:UnregisterEvent("PET_JOURNAL_LIST_UPDATE")
end

function SimpleActionSets:PLAYER_REGEN_DISABLED()
	inCombat = true
end

function SimpleActionSets:PLAYER_REGEN_ENABLED()
	inCombat = false
end

function SimpleActionSets:PLAYER_SPECIALIZATION_CHANGED()
	if (SASMain:IsShown()) then
		self:Actions_Display()
	end
end

----------------------------
-- Get/Set/Hook Functions --
----------------------------

function SimpleActionSets:GetPlrName()
	return PlrName
end

function SimpleActionSets:GetSavedPickup()
	return SAS_SavedPickup
end

function SimpleActionSets:GetReturnAction()
	return SAS_ReturnAction
end

function SimpleActionSets:ActionPickedUp(id)
	SAS_ReturnAction = id
end

function SimpleActionSets:GetCombatStatus()
	return inCombat
end

function SimpleActionSets:SetSwappingSet(value)
	SAS_SwappingSet = value
end

function SimpleActionSets:SetCurrentSet(set)
	self:Debug("Changing current set to " .. (set or "nil"))
	self.db.profile.currentSet = set
end

function SimpleActionSets:GetCurrentSet()
	if ( not self.db ) then return end
	return self.db.profile.currentSet
end

function SimpleActionSets:GetDefaultMinimapPosition()
	return defaults.profile.minimap.minimapPos
end

function SimpleActionSets:ForceFakeDrop()
	self:FakeDrag_Drop(true)
end

function SimpleActionSets:SaveBackup()
	self.db.profiles["BackUp"].sets[PlrName] = self:IterateActions()
end

function SimpleActionSets:RestoreBackUp()
	self:SwapSet(self:GetPlrName(), "BackUp", true)
end

-------------------
-- Console/Debug --
-------------------

function SimpleActionSets:Console(msg)
	-- Splits msg into 2 parts only, delimiter is space
	local msgParts = { strsplit(" ", msg, 2) }
	local cmd = strlower(msgParts[1])

	if ( cmd == "swap" ) then
		if ( msgParts[2] and self:SetExists(msgParts[2]) ) then
			self:SwapSet(msgParts[2])
		else
			local noSetMsg = gsub(L["SAS_TEXT_CONSOLE_NOVALID"], "%%s", msgParts[2])
			self:Print(noSetMsg)
		end
	elseif ( cmd == "save" ) then
		if ( msgParts[2] ) then
			self:SaveSet(msgParts[2])
		end
	elseif ( cmd == "debug" ) then
		self:Print("Debug: " .. ((not self.db.global.debug and "on") or "off") )
		self.db.global.debug = not self.db.global.debug
	elseif ( cmd == "show" or cmd == "" ) then
		self:Main_Toggle()
	else
		self:Print( L["SAS_TITLE"] .. L["SAS_TEXT_CONSOLE_HELP"] )
	end
end

function SimpleActionSets:Debug(msg)
	-- Print when debug is turned on
	if ( self.db.global.debug ) then self:Print("<|wDEBUG|r> " .. msg) end
end
