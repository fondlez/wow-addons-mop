local addonName = ...
local SimpleActionSets = _G[addonName]
local L = LibStub( "AceLocale-3.0" ):GetLocale(addonName)

-- Minimap variables
local SAS_POS_DEFAULT = SimpleActionSets:GetDefaultMinimapPosition()
local SAS_POS_TEMP
local minimapIcon = LibStub("LibDBIcon-1.0")

-- 'Enums'
local barLength = SimpleActionSets:GetBarLength()
local maxBar = SimpleActionSets:GetMaxBar()
local enumForceClear = SimpleActionSets:GetForceClear()
local enumForceNoChange = SimpleActionSets:GetForceNoChange()
local enumName = SimpleActionSets:GetEnumName()
local enumTexture = SimpleActionSets:GetEnumTexture()
local actionButtonSize = 36

-- Fake Drag Frame's variable to store bar being dragged
local SAS_DraggingBar

-- Main Frame's tabs, used to adjust scroll frame's height
local SASMainTabs = {
	{280, "SASSets"},
	{185, "SASOptions"},
}

function SimpleActionSets:CreateUIFrames()
	local texturePath = "Interface\\DialogFrame\\UI-DialogBox-"
	local backDrop = {
		bgFile = texturePath .. "Background",
		edgeFile = texturePath .."Border", tile = true, tileSize = 32, edgeSize = 32,
		insets = { left = 11, right = 12, top = 12, bottom = 11 }
	}

	self:CreateMainFrame()
	self:CreateSaveMenu(backDrop)
	self:CreateWarningFrame(backDrop)
	self:CreateFakeDragFrame()
	self:CreateSetsDropDownFrame()
end

----------------
-- Main Frame --
----------------

function SimpleActionSets:CreateMainFrame()
	local frame = self:CreateBasicFrame(nil, "SASMain", UIParent, nil, 640, 512, "CENTER", nil, nil, nil, nil, nil, true, true, true, true)
	frame:CreateTitleRegion():SetAllPoints()
	frame:SetHitRectInsets(0, 44, 0, 13)

	local texturePath = "Interface\\HelpFrame\\HelpFrame-"

	-- Main frame textures
	self:CreateFrameTexture(frame, nil, 256, 256, "BACKGROUND", texturePath .. "TopLeft", "TOPLEFT")
	self:CreateFrameTexture(frame, nil, 256, 256, "BACKGROUND", texturePath .. "Top", "TOPLEFT", 256, 0)
	self:CreateFrameTexture(frame, nil, 128, 256, "BACKGROUND", texturePath .. "TopRight", "TOPRIGHT")
	self:CreateFrameTexture(frame, nil, 256, 256, "BACKGROUND", texturePath .. "BotLeft", "BOTTOMLEFT")
	self:CreateFrameTexture(frame, nil, 256, 256, "BACKGROUND", texturePath .. "Bottom", "BOTTOMLEFT", 256, 0)
	self:CreateFrameTexture(frame, nil, 128, 256, "BACKGROUND", texturePath .. "BotRight", "BOTTOMRIGHT")

	-- Main frame title
	self:CreateFrameTexture(frame, "$parentHeader", 400, 64, "ARTWORK", "Interface\\DialogFrame\\UI-DialogBox-Header", "TOP", -12, 12)
	self:CreateString(frame, "$parentTitle", L["SAS_TITLE"] .. " " .. GetAddOnMetadata(addonName, "Version"), nil, nil, "ARTWORK", nil, "TOP", 0, -14, "$parentHeader")

	frame:SetScript("OnShow", function() SimpleActionSets:Main_OnShow() end)
	frame:SetScript("OnHide", function() SimpleActionSets:SetTemp(nil, nil, nil) end)

	self:CreateDivider(frame, "$parentTabDivider", "TOPLEFT", 12, -42)

	self:CreateButton(frame, "SASActionsDelete", L["SAS_TEXT_DELETE"], 100, 21, "TOPRIGHT", -53, -56, nil, nil, function() SimpleActionSets:Actions_Delete() end)
	self:CreateButton(frame, "SASActionsSaveNew", L["SAS_TEXT_SAVEAS"], 100, 21, "RIGHT", nil, nil, "SASActionsDelete", "LEFT", function() SimpleActionSets:Actions_SaveNew() end)
	self:CreateActionSetsDropDownFrame(frame)
	self:CreateButton(frame, "$parentTab1", L["SAS_TEXT_TAB_SETS"], nil, nil, "BOTTOMLEFT", 15, 10, nil, nil, function(self) SimpleActionSets:Tab_OnClick(self) end, "CharacterFrameTabButtonTemplate", 1)
	self:CreateButton(frame, "$parentTab2", L["SAS_TEXT_TAB_OPTIONS"], nil, nil, "LEFT", -14, 0, "$parentTab1", "RIGHT", function(self) SimpleActionSets:Tab_OnClick(self) end, "CharacterFrameTabButtonTemplate", 2)

	-- Close (X) button
	self:CreateButton(frame, "SASMainCloseButton", nil, nil, nil, "TOPRIGHT", -42, -3, nil, nil, nil, "UIPanelCloseButton")

	self:CreateCheckedButton(frame, "SASActionsCheckAll", true, 28, 28, "TOPLEFT", 18, -52, nil, nil, function(self) SimpleActionSets:Actions_Bar_CheckAll(self:GetChecked()) end, nil, nil, L["SAS_TEXT_CB_ALLBARS"], L["SAS_TEXT_CHECK_ALL"])
	self:CreateDivider(frame, "$parentTopDivider", "TOPLEFT", 12, -72)
	self:CreateDivider(frame, "$parentBottomDivider", "TOPLEFT", 0, -270, "$parentTopDivider", "BOTTOMLEFT")

	-- Actions ScrollFrame
	local sfTexture = "Interface\\PaperDollInfoFrame\\UI-Character-ScrollBar"
	local actionsScrollFrame = self:CreateBasicFrame("ScrollFrame", "SASActions", frame, "UIPanelScrollFrameTemplate", 540, 280, "TOPLEFT", 8, 4, "$parentTopDivider", "BOTTOMLEFT")

	self:CreateFrameTexture(actionsScrollFrame, "$parentScrollBarTop", 31, 128, "ARTWORK", sfTexture, "TOPLEFT", -2, 6, actionsScrollFrame, "TOPRIGHT", 0, 0.484375, 0, 0.5)
	self:CreateFrameTexture(actionsScrollFrame, "$parentScrollBarBottom", 31, 108, "ARTWORK", sfTexture, "BOTTOMLEFT", -2, -4, actionsScrollFrame, "BOTTOMRIGHT", 0.515625, 1, 0, 0.421875)

	local frameTexture = self:CreateFrameTexture(actionsScrollFrame, nil, 31, 60, "ARTWORK", sfTexture, "TOP", 0, 0, "$parentScrollBarTop", "BOTTOM", 0, 0.484375, 0.75, 1)
	frameTexture:SetPoint("BOTTOM", "$parentScrollBarBottom", "TOP")

	local actionScrollChild = self:CreateBasicFrame(nil, "SASActionsScrollChild", nil, nil, 526, 465)

	self:CreateActionBar(actionScrollChild, 0, "TOPRIGHT", 0, -5)

	for i = 1, maxBar do
		self:CreateActionBar(actionScrollChild, i, "TOPLEFT", 0, -10, "SASActionBar" .. (i - 1), "BOTTOMLEFT")
	end

	actionsScrollFrame:SetScrollChild(actionScrollChild)

	-- SAS Sets
	local sets = self:CreateBasicFrame(nil, "SASSets", frame, nil, 568, 90, "BOTTOMLEFT", 18, 48)

	self:CreateButton(sets, "$parentSave", L["SAS_TEXT_SAVE"], 152, 21, "BOTTOMLEFT", 5, 5, nil, nil, function(self) SimpleActionSets:Actions_Save(self) end)
	self:CreateButton(sets, "$parentLoadCurrent", L["SAS_TEXT_LOADCURRENT"], 152, 21, "BOTTOMRIGHT", -5, 5, nil, nil, function(self) SimpleActionSets:Actions_LoadCurrent(self) end)
	self:CreateButton(sets, "$parentClearSet", L["SAS_TEXT_CLEARSET"], 152, 21, "BOTTOM", 0, 5, nil, nil, function(self) SimpleActionSets:Actions_ClearTemp(self) end)
	self:CreateCharacterDropDownFrame(sets)
	self:CreateCharacterSetsDropDownFrame(sets)
	self:CreateButton(sets, "$parentOtherSet", L["SAS_TEXT_LOADSET"], 174, 21, "LEFT", -14, 2, "$parent_CharacterSets_DropDown", "RIGHT",  function(self) SimpleActionSets:Actions_LoadOtherSet(self) end)

	-- SAS Options
	local options = self:CreateBasicFrame(nil, "SASOptions", frame, nil, 568, 180, "BOTTOMLEFT", 18, 50)
	options:SetScript("OnShow", function(self) SimpleActionSets:Options_OnShow(self) end)

	local backDrop = {
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16,
		insets = { left = 5, right = 5, top = 5, bottom = 5 }
	}

	self:MinimapOptionsFrame(options, backDrop)
	self:GeneralOptionsFrame(options, backDrop)

	-- Cancel/Apply Set buttons
	self:CreateButton(frame, "$parentCancel", L["SAS_OPTIONS_CLOSE"], 100, 21, "BOTTOMRIGHT", -53, 21, nil, nil, function(self) SimpleActionSets:Actions_Cancel(self) end)
	self:CreateButton(frame, "$parentSwapSet", L["SAS_TEXT_SWAPSET"], 100, 21, "RIGHT", 0, 0, "$parentCancel", "LEFT", function(self) SimpleActionSets:Actions_SwapSet(self) end)

	PanelTemplates_SetNumTabs(frame, 2)
	frame.selectedTab = 1
	PanelTemplates_UpdateTabs(frame)
end

function SimpleActionSets:Main_UpdateDisplay()
	SASSets:Hide()
	SASOptions:Hide()
	local tab = SASMain.selectedTab
	local height = SASMainTabs[tab][1]
	SASActions:SetHeight(height)
	SASMainBottomDivider:SetPoint("TOPLEFT", SASMainTopDivider, "BOTTOMLEFT", 0, 10 - height)
	_G[SASMainTabs[tab][2]]:Show()
end

function SimpleActionSets:Main_OnShow()
	self:Actions_Load(self:GetCurrentSet())
	self:Main_UpdateDisplay()
end

function SimpleActionSets:Tab_OnClick(self)
	PanelTemplates_Tab_OnClick(self, self:GetParent())
	SimpleActionSets:Main_UpdateDisplay()
end

function SimpleActionSets:Main_Toggle()
	if ( SASMain:IsVisible() ) then
		HideUIPanel(SASMain)
	else
		ShowUIPanel(SASMain)
	end
end

function SimpleActionSets:Options_OnShow()
	self:Options_Minimap_Update()
	SAS_POS_TEMP = self.db.profile.minimap.minimapPos
	SASOptionsMinimapPositionUndo:Disable()
end

-----------------------------------------
-- Main Frame Display Update Functions --
-----------------------------------------

function SimpleActionSets:Actions_Load(set, plr)
	local SAS_Temp = {}
	local PlrName = self:GetPlrName()
	local loadingPlayerSet

	plr = plr or PlrName

	if ( not set ) then
		self:Debug("Loading current actions")
		SAS_Temp = self:CopyTable(self:IterateActions())
		loadingPlayerSet = false
	elseif ( plr ~= PlrName ) then
		self:Debug("Loading set " .. set .. " from " .. plr)
		SAS_Temp = self:CopyTable(self.db.profiles[plr].sets[set])
		loadingPlayerSet = false
	else
		self:Debug("Loading set " .. set)
		SAS_Temp = self:CopyTable(self.db.profile.sets[set])
		loadingPlayerSet = true
	end

	UIDropDownMenu_Initialize(SASActionSetsDropDown, function() SimpleActionSets:Actions_DropDown_Initialize() end)
	self:SetTemp(nil, nil, SAS_Temp)

	if ( loadingPlayerSet ) then
		UIDropDownMenu_SetSelectedName(SASActionSetsDropDown, set)
		SASActionsDelete:Enable()
	else
		UIDropDownMenu_SetSelectedID(SASActionSetsDropDown, 0)
		SASActionSetsDropDownText:SetText(L["SAS_TEXT_CURRENT"])
		SASActionsDelete:Disable()
	end

	if ( self:TableIsEmpty(self.db.profile.sets) ) then
		SASActionSetsDropDownButton:Disable()
	else
		SASActionSetsDropDownButton:Enable()
	end

	self:Actions_Display()
	SASSetsSave:Disable()
end

function SimpleActionSets:Actions_Display()
	-- Update the display of all bars.
	if ( self:GetTemp() ) then
		for i = 0, maxBar do
			self:Actions_UpdateBar(i)
		end
	end
	self:Actions_SaveEnable()
end

function SimpleActionSets:Actions_UpdateBar(bar)
	local SAS_TempBar = self:GetTemp(bar)

	-- Update the display of a bar
	local BarFrame = _G["SASActionBar" .. bar]
	if ( SAS_TempBar ) then
		_G[BarFrame:GetName() .. "Enable"]:SetChecked(not SAS_TempBar[0])
	end
	if ( bar ) then
		for i = 1, barLength do
			self:Actions_UpdateAction(bar, i)
		end
	end

	-- Fade the bar if its being dragged
	if ( SAS_DraggingBar == bar and SASFakeDragFrame:IsVisible() ) then
		BarFrame:SetAlpha(0.5)
	else
		BarFrame:SetAlpha(1)
	end
end

function SimpleActionSets:Actions_UpdateAction(bar, slot)
	-- Update the display of an action.
	local button = "SASActionBar" .. bar .. "Action" .. slot
	local actualButton = _G[button]
	local icon = _G[button .. "Icon"]
	local buttonName = _G[button .. "Name"]
	local normalTexture = _G[button .. "NormalTexture"]
	local border = _G[button .. "Border"]
	local hotkey = _G[button .. "HotKey"]
	local enable = self:BarEnabled(bar)
	local SAS_Temp = self:GetTemp()

	-- If not applying empty buttons and there is a blank slot or if not applying empty bars and the bar has no actions
	if ( (self.db.profile.noEmptyButtons and not SAS_Temp[bar][slot]) or not (self.db.profile.emptyBars or self:BarHasActions(bar)) ) then
		enable = false
	end

	normalTexture:SetVertexColor(1, 1, 1, 1)

	if ( enable ) then
		actualButton:SetAlpha(1)
		border:SetVertexColor(1, 0.5, 0, 0.2)
	else
		actualButton:SetAlpha(0.5)
		border:SetVertexColor(0.5, 1, 1, 0.2)
	end

	hotkey:SetTextColor(0.25, 0.25, 0.25)

	if ( not SAS_Temp ) then
		actualButton:Disable()
	else
		actualButton:Enable()
		buttonName:Hide()
		icon:SetVertexColor(1, 1, 1)

		if ( SAS_Temp[bar] and SAS_Temp[bar][slot] ) then
			icon:Show()
			if ( SAS_Temp[bar][slot] == enumForceClear ) then
				normalTexture:SetTexture("Interface\\Buttons\\UI-Quickslot")
				border:SetVertexColor(1, 0.5, 0, 1)
				icon:SetTexture()
			elseif ( SAS_Temp[bar][slot] == enumForceNoChange ) then
				actualButton:SetAlpha(0.5)
				normalTexture:SetTexture("Interface\\Buttons\\UI-Quickslot2")
				border:SetVertexColor(0.5, 1, 1, 1)
				icon:SetTexture()
			else
				local name, texture, rank, link, macro, actionSpellID = self:ParseActionInfo(SAS_Temp[bar][slot])
				icon:SetTexture(texture)
				normalTexture:SetTexture("Interface\\Buttons\\UI-Quickslot2")
				hotkey:SetTextColor(0.6, 0.6, 0.6)

				if ( macro ) then
					buttonName:SetText(name)
					buttonName:Show()
					if ( self:FindMacro(name, texture, macro) ) then
						buttonName:SetTextColor(1, 1, 1)
					else
						self:ActionNotFound(icon, border)
						buttonName:SetTextColor(0.4, 0.4, 0.4)
						normalTexture:SetVertexColor(0.9, 0, 0, 1)
					end
				elseif ( rank == "MOUNT" ) then
					if ( not self:FindCompanion(name, rank) ) then
						self:ActionNotFound(icon, border)
					end
				elseif ( rank == "summonpet" ) then
					local battlePetInfo = C_PetJournal.GetPetInfoByPetID(link)
					if ( not battlePetInfo ) then
						self:ActionNotFound(icon, border)
					end
				elseif ( rank == "equipmentset" ) then
					local equipSetIcon = GetEquipmentSetInfoByName(name)
					if ( not equipSetIcon ) then
						self:ActionNotFound(icon, border)
					end
				elseif ( rank == "flyout" ) then
					local isKnown = select(4, GetFlyoutInfo(link))
					if ( not isKnown ) then
						self:ActionNotFound(icon, border)
					end
				elseif ( link ) then
					border:SetVertexColor(0, 1, 0, 0.35)
					local itemLink
					if ( link == "?" ) then
						itemLink = self:CheckItem(name, bar * barLength + slot, UIDropDownMenu_GetSelectedName(SASActionSetsDropDown))
					else
						itemLink = self:FindItem(link)
					end
					if ( not itemLink or itemLink == "?" ) then
						self:ActionNotFound(icon, border)
						normalTexture:SetVertexColor(0.9, 0, 0, 1)
					elseif ( link == "?" ) then
						self:SetTemp(bar, slot, self:IncActionInfo(SAS_Temp[bar][slot], itemLink, 4))
					end
				else
					local spellNum = self:FindSpell(name, rank, actionSpellID)

					if ( not spellNum ) then
						self:ActionNotFound(icon, border)
					else
						local checktexture = GetSpellTexture(spellNum, "spell")
						if ( texture ~= checktexture ) then
							icon:SetTexture(checktexture)
							local set = UIDropDownMenu_GetSelectedName(SASActionSetsDropDown)
							if ( set ) then
								self:SetTemp(bar, slot, self:IncActionInfo(SAS_Temp[bar][slot], checktexture, enumTexture))
								self.db.profile.sets[set][bar][slot] = self:IncActionInfo(self.db.profile.sets[set][bar][slot], checktexture, enumTexture)
							end
						end
					end
				end
			end
		elseif ( SAS_Temp[bar] ) then
			icon:Hide()
			if ( enable ) then
				normalTexture:SetTexture("Interface\\Buttons\\UI-Quickslot")
			else
				normalTexture:SetTexture("Interface\\Buttons\\UI-Quickslot2")
			end
		end
	end

	-- Needs to be last to cover instance where two bars are swapped
	SetDesaturation(icon, not enable)
end

function SimpleActionSets:ActionNotFound(icon, border)
	icon:SetVertexColor(0.4, 0.4, 0.4)
	border:SetVertexColor(1, 0, 0, 0.35)
end

function SimpleActionSets:Actions_SaveEnable()
	local set = UIDropDownMenu_GetSelectedName(SASActionSetsDropDown)
	if ( set and self:SetDifferent(self:GetTemp(), self.db.profile.sets[set], true) ) then
		SASSetsSave:Enable()
	else
		SASSetsSave:Disable()
	end
end

---------------------------------
-- Main Frame Button Functions --
---------------------------------

function SimpleActionSets:Actions_Delete()
	self:Warning("DELETE", function(set) self:Delete(set) end, UIDropDownMenu_GetSelectedName(SASActionSetsDropDown))
end

function SimpleActionSets:Actions_SaveNew()
	SASSaveMenuNameEB:SetText("")
	ShowUIPanel(SASSaveMenu)
end

function SimpleActionSets:Actions_Save()
	self:Warning("SAVE", function(set) self:SaveSet(set) end, UIDropDownMenu_GetSelectedName(SASActionSetsDropDown))
end

function SimpleActionSets:Actions_LoadCurrent()
	if ( not SASSetsSave:IsEnabled() ) then
		self:Actions_Load()
	else
		self:Warning("UNSAVED_LOAD", function() self:Actions_Load() end)
	end
end

function SimpleActionSets:Actions_ClearTemp()
	local SAS_Temp = self:GetTemp()
	-- Clear the temp set
	for i = 0, maxBar do
		SAS_Temp[i] = {}
	end
	self:SetTemp(nil, nil, SAS_Temp)
	self:Actions_Display()
end

function SimpleActionSets:Actions_LoadOtherSet()
	local char = SASSets_Character_DropDownText:GetText()
	local set = SASSets_CharacterSets_DropDownText:GetText()
	self:Actions_Load(set, char)
end

function SimpleActionSets:Actions_Cancel(self)
	if ( not SASSetsSave:IsEnabled() ) then
		HideUIPanel(self:GetParent())
	else
		SimpleActionSets:Warning("UNSAVED_CANCEL", function() SimpleActionSets:Main_Toggle() end)
	end
end

function SimpleActionSets:Actions_SwapSet()
	if ( SASSetsSave:IsEnabled() ) then
		self:Warning("SWAPPINGSAVE", function(set) self:Actions_SwapSave(set) end, UIDropDownMenu_GetSelectedName(SASActionSetsDropDown))
	else
		self:Warning("SWAPPING", function(set) self:SwapSet(set) end, UIDropDownMenu_GetSelectedName(SASActionSetsDropDown))
	end
end

function SimpleActionSets:Actions_SwapSave(set)
	self:SaveSet(set)
	self:SwapSet(set)
end

--------------------------------
-- Actions DropDown (On Main) --
--------------------------------

function SimpleActionSets:CreateActionSetsDropDownFrame(frameToAttach)
	local actionSetsDropDown = self:CreateBasicFrame(nil, "SASActionSetsDropDown", frameToAttach, "UIDropDownMenuTemplate", nil, nil, "RIGHT", 16, -2, "SASActionsSaveNew", "LEFT")
	UIDropDownMenu_Initialize(actionSetsDropDown, function() SimpleActionSets:Actions_DropDown_Initialize() end)
	UIDropDownMenu_SetWidth(actionSetsDropDown, 135)
	UIDropDownMenu_SetButtonWidth(actionSetsDropDown, 24)
	UIDropDownMenu_JustifyText(actionSetsDropDown, "LEFT")

	local set = SimpleActionSets:GetCurrentSet()
	if ( set ) then
		UIDropDownMenu_SetSelectedName(actionSetsDropDown, SASActionSetsDropDown, set)
	else
		UIDropDownMenu_SetText(actionSetsDropDown, L["SAS_TEXT_CURRENT"], SASActionSetsDropDown)
	end
end

function SimpleActionSets:Actions_DropDown_Initialize()
	if ( not (self.db and self.db.profile.sets) ) then return end

	local func = function(self) SimpleActionSets:Actions_DropDown_OnClick(self) end

	for k, v in self:PairsByKeys(self.db.profile.sets) do
		self:SetsDropDown_AddButton(k, false, func)
	end
end

function SimpleActionSets:Actions_DropDown_OnClick(self)
	UIDropDownMenu_SetSelectedID(SASActionSetsDropDown, self:GetID())
	SimpleActionSets:Actions_Load(self:GetText())
end

-------------------------------------
-- DropDowns For Other Characters  --
-------------------------------------

function SimpleActionSets:CreateCharacterDropDownFrame(frameToAttach)
	local setsCharDropDown = self:CreateBasicFrame(nil, "$parent_Character_DropDown", frameToAttach, "UIDropDownMenuTemplate", nil, nil, "BOTTOMLEFT", 0, 40)
	UIDropDownMenu_Initialize(setsCharDropDown, function() SimpleActionSets:Character_DropDown_Initialize() end)
	UIDropDownMenu_SetWidth(setsCharDropDown, 160)
	UIDropDownMenu_SetButtonWidth(setsCharDropDown, 24)
	UIDropDownMenu_JustifyText(setsCharDropDown, "LEFT")
	UIDropDownMenu_SetSelectedID(setsCharDropDown, 1)
end

function SimpleActionSets:Character_DropDown_Initialize()
	local func = function(self) SimpleActionSets:Character_DropDown_OnClick(self) end

	for k, v in self:PairsByKeys(self.db.profiles) do
		if ( k ~= "BackUp" and k ~= self:GetPlrName() and v.sets ) then
			self:SetsDropDown_AddButton(k, false, func)
		end
	end

	-- Make the backup sets (if they exist) appear last in the list
	if ( self.db.profiles["BackUp"] ) then
		self:SetsDropDown_AddButton("BackUp", false, func)
	end
end

function SimpleActionSets:Character_DropDown_OnClick(self)
	UIDropDownMenu_SetSelectedName(SASSets_Character_DropDown, self:GetText())
	UIDropDownMenu_Initialize(SASSets_CharacterSets_DropDown, function() SimpleActionSets:CharacterSets_DropDown_Initialize() end)
	UIDropDownMenu_SetSelectedID(SASSets_CharacterSets_DropDown, 1)
end

function SimpleActionSets:CreateCharacterSetsDropDownFrame(frameToAttach)
	local setsCharSetsDropDown = self:CreateBasicFrame(nil, "$parent_CharacterSets_DropDown", frameToAttach, "UIDropDownMenuTemplate", nil, nil, "LEFT", -30, 0, "$parent_Character_DropDown", "RIGHT")
	UIDropDownMenu_Initialize(setsCharSetsDropDown, function() SimpleActionSets:CharacterSets_DropDown_Initialize() end)
	UIDropDownMenu_SetWidth(setsCharSetsDropDown, 160)
	UIDropDownMenu_SetButtonWidth(setsCharSetsDropDown, 24)
	UIDropDownMenu_JustifyText(setsCharSetsDropDown, "LEFT")
	UIDropDownMenu_SetSelectedID(setsCharSetsDropDown, 1)
end

function SimpleActionSets:CharacterSets_DropDown_Initialize()
	local char = SASSets_Character_DropDownText:GetText()
	if ( not (char and self.db.profiles[char] and self.db.profiles[char].sets) ) then return end

	local func = function(self) UIDropDownMenu_SetSelectedID(SASSets_CharacterSets_DropDown, self:GetID()) end

	for k, v in self:PairsByKeys(self.db.profiles[char].sets) do
		self:SetsDropDown_AddButton(k, false, func)
	end
end

---------------------
-- Minimap Options --
---------------------

function SimpleActionSets:MinimapOptionsFrame(frameToAttach, backDrop)
	local optMinimap = self:CreateBasicFrame(nil, "$parentMinimap", frameToAttach, nil, 300, 60, "TOPLEFT", 0, -10)
	optMinimap:SetBackdrop(backDrop)

	self:CreateString(optMinimap, "$parentName", L["SAS_TEXT_OPTIONS_MINIMAP"], nil, nil, "ARTWORK", "GameFontHighlight", "BOTTOMLEFT", 9, 0, nil, "TOPLEFT")
	self:CreateCheckedButton(optMinimap, "$parentShow", not self.db.profile.minimap.hide, nil, nil, "TOPLEFT", 5, -5, nil, nil, function(self) SimpleActionSets:Options_Minimap_Show(self) end, nil, nil, nil, L["SAS_TEXT_OPTIONS_MINIMAP_SHOW"])
	self:CreateCheckedButton(optMinimap, "$parentDrag", self.db.profile.minimap.lock, nil, nil, "TOP", 0, 0, "$parentShow", "BOTTOM", function(self) SimpleActionSets:Options_Minimap_Lock(self) end, nil, nil, nil, L["SAS_TEXT_OPTIONS_MINIMAP_DRAG"])

	local optMinimapPosition = self:CreateBasicFrame(nil, "$parentMinimapPosition", frameToAttach, nil, 300, 110, "TOPLEFT", 0, 0, "$parentMinimap", "BOTTOMLEFT")
	optMinimapPosition:SetBackdrop(backDrop)

	local optMinimapPosSlider = self:CreateBasicFrame("Slider", "SASButtonPos", optMinimapPosition, "OptionsSliderTemplate", 280, 16, "TOP", 0, -20)
	_G[optMinimapPosSlider:GetName() .. "High"]:SetText(360)
	_G[optMinimapPosSlider:GetName() .. "Low"]:SetText(0)
	optMinimapPosSlider:SetMinMaxValues(0, 360)
	optMinimapPosSlider:SetValueStep(1)

	optMinimapPosSlider:SetScript("OnValueChanged", function(self) SimpleActionSets:Options_Minimap_OnValueChanged(self) end)

	self:CreateButton(optMinimapPosition, "$parentDefault", L["SAS_TEXT_OPTIONS_MINIMAP_DEFAULT"], nil, nil, "BOTTOMLEFT", 5, 5, nil, nil, function(self) SimpleActionSets:Options_Minimap_Defaults(self) end, "OptionsButtonTemplate")
	self:CreateButton(optMinimapPosition, "$parentUndo", L["SAS_TEXT_OPTIONS_MINIMAP_UNDO"], nil, nil, "BOTTOMRIGHT", -5, 5, nil, nil, function(self) SimpleActionSets:Options_Minimap_Undo(self) end, "OptionsButtonTemplate")
end

function SimpleActionSets:Options_Minimap_Show(self)
	SimpleActionSets.db.profile.minimap.hide = not self:GetChecked()
	if ( self:GetChecked() ) then
		minimapIcon:Show(addonName)
	else
		minimapIcon:Hide(addonName)
	end
end

function SimpleActionSets:Options_Minimap_Lock(self)
	SimpleActionSets.db.profile.minimap.lock = SimpleActionSets:ToBool(self:GetChecked())
	if ( SimpleActionSets.db.profile.minimap.lock ) then
		minimapIcon:Lock(addonName)
	else
		minimapIcon:Unlock(addonName)
	end
end

function SimpleActionSets:Options_Minimap_OnValueChanged(self)
	SimpleActionSets.db.profile.minimap.minimapPos = SASButtonPos:GetValue()
	_G[self:GetName() .. "Text"]:SetText(L["SAS_OPTIONS_BUTPOS"] .. " " .. SASButtonPos:GetValue())
	SimpleActionSets:Options_Minimap_Update()
	SASOptionsMinimapPositionUndo:Enable()
end

function SimpleActionSets:Options_Minimap_Defaults()
	self.db.profile.minimap.minimapPos = SAS_POS_DEFAULT
	self:Options_Minimap_Update()
end

function SimpleActionSets:Options_Minimap_Undo()
	self.db.profile.minimap.minimapPos = SAS_POS_TEMP
	self:Options_Minimap_Update()
	SASOptionsMinimapPositionUndo:Disable()
end

function SimpleActionSets:Options_Minimap_Update()
	SASButtonPos:SetValue(self.db.profile.minimap.minimapPos)

	if ( not self.db.profile.minimap.hide ) then
		-- Show also updates the position
		minimapIcon:Show(addonName)
	end
end

---------------------
-- General Options --
---------------------

function SimpleActionSets:GeneralOptionsFrame(frameToAttach, backDrop)
	local optGeneral = self:CreateBasicFrame(nil, "$parentGeneral", frameToAttach, nil, 268, 170, "TOPRIGHT", 0, -10)
	optGeneral:SetBackdrop(backDrop)

	self:CreateString(optGeneral, "$parentName", L["SAS_TEXT_OPTIONS_GENERAL"], nil, nil, "ARTWORK", "GameFontHighlight", "BOTTOMLEFT", 9, 0, nil, "TOPLEFT")
	self:CreateCheckedButton(optGeneral, "$parentWarnings", not self.db.profile.noUIWarnings, nil, nil, "TOPLEFT", 5, -5, nil, nil, function(self) SimpleActionSets.db.profile.noUIWarnings = not self:GetChecked() end, nil, nil, L["SAS_TEXT_OPTIONS_GENERAL_WARNINGS_TOOLTIP"], L["SAS_TEXT_OPTIONS_GENERAL_WARNINGS"])
	self:CreateCheckedButton(optGeneral, "$parentEmptyBars", not self.db.profile.emptyBars, nil, nil, "TOP", 0, 0, "$parentWarnings", "BOTTOM", function(self) SimpleActionSets:Options_General_EmptyBars(self) end, nil, nil, L["SAS_TEXT_OPTIONS_GENERAL_EMPTYBARS_TOOLTIP"], L["SAS_TEXT_OPTIONS_GENERAL_EMPTYBARS"])
	self:CreateCheckedButton(optGeneral, "$parentEmptyButtons", self.db.profile.noEmptyButtons, nil, nil, "TOP", 20, 0, "$parentEmptyBars", "BOTTOM", function(self) SimpleActionSets:Options_General_EmptyButtons(self) end, nil, nil, L["SAS_TEXT_OPTIONS_GENERAL_EMPTYBUTTONS_TOOLTIP"], L["SAS_TEXT_OPTIONS_GENERAL_EMPTYBUTTONS"])
	self:CreateCheckedButton(optGeneral, "$parentAutoRestore", self.db.profile.autoRestore, nil, nil, "TOP", -20, 0, "$parentEmptyButtons", "BOTTOM", function(self) SimpleActionSets.db.profile.autoRestore = SimpleActionSets:ToBool(self:GetChecked()) end, nil, nil, L["SAS_TEXT_OPTIONS_GENERAL_AUTORESTORE_TOOLTIP"], L["SAS_TEXT_OPTIONS_GENERAL_AUTORESTORE"])
	self:CreateCheckedButton(optGeneral, "$parentAutoRestoreWarning", not self.db.profile.noAutoRestoreWarnings, nil, nil, "TOP", 20, 0, "$parentAutoRestore", "BOTTOM", function(self) SimpleActionSets.db.profile.noAutoRestoreWarnings = not self:GetChecked() end, nil, nil, L["SAS_TEXT_OPTIONS_GENERAL_AUTORESTOREWARN_TOOLTIP"], L["SAS_TEXT_OPTIONS_GENERAL_AUTORESTOREWARN"])
end

function SimpleActionSets:Options_General_EmptyBars(self)
	SimpleActionSets.db.profile.emptyBars = not self:GetChecked()
	SimpleActionSets:Actions_Display()
end

function SimpleActionSets:Options_General_EmptyButtons(self)
	SimpleActionSets.db.profile.noEmptyButtons = SimpleActionSets:ToBool(self:GetChecked())
	SimpleActionSets:Actions_Display()
end

---------------------
-- Save Menu Frame --
---------------------

function SimpleActionSets:CreateSaveMenu(backDrop)
	local frame = self:CreateBasicFrame(nil, "SASSaveMenu", UIParent, nil, 350, 135, "CENTER", nil, nil, nil, nil, "DIALOG", true, true, nil, true)
	local texturePath = "Interface\\DialogFrame\\UI-DialogBox-"

	frame:SetBackdrop(backDrop)

	self:CreateFrameTexture(frame, "$parentHeaderTexture", 300, 64, "ARTWORK", texturePath .. "Header", "TOP", 0, 12)

	frame:SetScript("OnShow", function() PlaySound("UChatScrollButton") end)
	frame:SetScript("OnHide", function() PlaySound("UChatScrollButton") end)

	-- Various text for frame
	self:CreateString(frame, "$parentTitle", L["SAS_SAVEMENU_TITLE"], nil, nil, "ARTWORK", nil, "TOP", 0, -14, "$parentHeaderTexture")
	self:CreateString(frame, "$parentEditing", L["SAS_SAVEMENU_EDITING"], nil, nil, "ARTWORK", nil, "TOP", 0, -25)
	self:CreateString(frame, "$parentHelp", nil, nil, nil, "ARTWORK", nil, "TOP", 0, -75)

	-- Edit Box
	local nameEB = self:CreateBasicFrame("EditBox", "$parentNameEB", frame, nil, 250, 32, "TOP", 0, -40)
	nameEB:SetMaxLetters(250)
	nameEB:SetFontObject("ChatFontNormal")

	texturePath = "Interface\\ChatFrame\\UI-ChatInputBorder-"

	self:CreateFrameTexture(nameEB, "$parentLeft", 65, 32, "BACKGROUND", texturePath .. "Left", "LEFT", -10, 0, nil, nil, 0, 0.2359, 0, 1)
	self:CreateFrameTexture(nameEB, "$parentRight", 25, 32, "BACKGROUND", texturePath .. "Right", "RIGHT", 10, 0, nil, nil, 0.9, 1, 0, 1)

	local frameTexture = self:CreateFrameTexture(nameEB, nil, 5, 32, "BACKGROUND", texturePath .. "Left", "LEFT", 0, 0, "$parentLeft", "RIGHT", 0.29296875, 1, 0, 1)
	frameTexture:SetPoint("RIGHT", "$parentRight", "LEFT")

	nameEB:SetScript("OnShow", function(self) self:SetFocus() end)
	nameEB:SetScript("OnEnterPressed", function(self) SimpleActionSets:SaveNameEB_OnEnterPressed(self) end)
	nameEB:SetScript("OnTextChanged", function(self) SimpleActionSets:SaveNameEB_OnTextChanged(self) end)
	nameEB:SetScript("OnEscapePressed", function(self) HideUIPanel(self:GetParent()) end)

	-- Save frame OK/Cancel
	self:CreateButton(frame, "$parentOkayButton", L["SAS_TEXT_WARNING_OKAY"], 70, 21, "BOTTOM", -42, 20, nil, nil, function(self) SimpleActionSets:SaveMenu_Save(SASSaveMenuNameEB:GetText()) end)
	self:CreateButton(frame, "$parentCancelButton", L["SAS_TEXT_WARNING_CANCEL"], 70, 21, "BOTTOM", 42, 20, nil, nil, function(self) HideUIPanel(self:GetParent()) end)
end

function SimpleActionSets:SaveMenu_Save(set)
	SASSaveMenuHelp:Hide()
	self:SaveSet(set)
	HideUIPanel(SASSaveMenu)
end

function SimpleActionSets:SaveNameEB_OnEnterPressed(self)
	if ( _G[self:GetParent():GetName() .. "OkayButton"]:IsEnabled() ) then
		SimpleActionSets:SaveMenu_Save(SASSaveMenuNameEB:GetText())
	end
end

function SimpleActionSets:SaveNameEB_OnTextChanged(self)
	if ( self:GetText() == "" ) then
		_G[self:GetParent():GetName() .. "OkayButton"]:Disable()
		SASSaveMenuHelp:SetText(L["SAS_SAVEMENU_NEWSET"])
		SASSaveMenuHelp:Show()
	elseif ( SimpleActionSets:SetExists(self:GetText()) ) then
		_G[self:GetParent():GetName() .. "OkayButton"]:Enable()
		SASSaveMenuHelp:SetText(L["SAS_SAVEMENU_SET_EXISTS"])
		SASSaveMenuHelp:Show()
	else
		_G[self:GetParent():GetName() .. "OkayButton"]:Enable()
		SASSaveMenuHelp:Hide()
	end
end

-------------------
-- Warning Frame --
-------------------

function SimpleActionSets:CreateWarningFrame(backDrop)
	local frame = self:CreateBasicFrame(nil, "SASWarningFrame", UIParent, nil, 350, 135, "CENTER", nil, nil, nil, nil, "DIALOG", true, true, nil, true)
	frame:SetBackdrop(backDrop)

	local texturePath = "Interface\\DialogFrame\\UI-DialogBox-"

	self:CreateFrameTexture(frame, "$parentHeaderTexture", 256, 64, "ARTWORK", texturePath .. "Header", "TOP", 0, 12)

	frame:SetScript("OnShow", function() PlaySound("UChatScrollButton") end)
	frame:SetScript("OnHide", function() PlaySound("UChatScrollButton") end)

	-- Text for frame
	self:CreateString(frame, "$parentTitle", L["SAS_WARNING_FRAME"], nil, nil, "ARTWORK", nil, "TOP", 0, -14, "$parentHeaderTexture")
	self:CreateString(frame, "$parentText", nil, 300, 64, "ARTWORK", nil, "CENTER", 0, 10, nil, nil, "TOP")

	-- Save frame OK/Cancel
	self:CreateButton(frame, "$parentOkayButton", L["SAS_TEXT_WARNING_OKAY"], 70, 21, "BOTTOM", -42, 20, nil, nil, function(self) SimpleActionSets:Warning_Okay(self) end)
	self:CreateButton(frame, "$parentCancelButton", L["SAS_TEXT_WARNING_CANCEL"], 70, 21, "BOTTOM", 42, 20, nil, nil, function(self) HideUIPanel(self:GetParent()) end)
end

function SimpleActionSets:Warning(type, func, value, backupRestore)
	if ( self.db.profile.noUIWarnings or ( backupRestore and self.db.profile.noAutoRestoreWarnings ) ) then
		func(value)
	else
		if ( value ) then
			SASWarningFrameText:SetText(gsub(L["SAS_TEXT_WARNING_" .. type], "%%s", value))
		else
			SASWarningFrameText:SetText(L["SAS_TEXT_WARNING_" .. type])
		end
		SASWarningFrame.func = func
		SASWarningFrame.value = value
		ShowUIPanel(SASWarningFrame)
	end
end

function SimpleActionSets:Warning_Okay(self)
	SASWarningFrame.func(SASWarningFrame.value)
	SASWarningFrame.func = nil
	SASWarningFrame.value = nil
	HideUIPanel(self:GetParent())
end

--------------------
-- FakeDrag Frame --
--------------------

function SimpleActionSets:CreateFakeDragFrame()
	local frame = self:CreateBasicFrame(nil, "SASFakeDragFrame", UIParent, nil, actionButtonSize, actionButtonSize, "CENTER", nil, nil, nil, nil, "DIALOG", true, nil, nil, true)

	-- Fake drag frame for a single action
	local frameTexture = self:CreateFrameTexture(frame, "$parentIcon", actionButtonSize, actionButtonSize, "ARTWORK", nil, "TOP")
	frameTexture:SetAlpha(0.5)

	-- Fake drag frame for a whole action bar
	frameTexture = self:CreateFrameTexture(frame, "$parentIcon1", actionButtonSize, actionButtonSize, "ARTWORK", nil, "TOP", -40, -10)
	frameTexture:SetAlpha(0.5)

	for i = 2, barLength do
		frameTexture = self:CreateFrameTexture(frame, "$parentIcon" .. i, actionButtonSize, actionButtonSize, "ARTWORK", nil, "LEFT", 6, 0, "$parentIcon" .. i - 1, "RIGHT")
		frameTexture:SetAlpha(0.5)
	end
end

function SimpleActionSets:FakeDrag_Drop(clear)
	-- Pick up sas item
	SASFakeDragFrame:Hide()
	local focus = GetMouseFocus()
	local action = SASFakeDragFrame.Action
	local bar = SASFakeDragFrame.Bar

	if ( (focus and not (focus.IsSASAction or focus.IsSASBar)) or clear ) then
		if ( action or bar ) then
			PlaySoundFile("Sound\\Interface\\uSpellIconDrop.wav")
			self:Debug("Dumping FakeDrag " .. ((action and "Action " .. SimpleActionSets:ParseActionInfo(action, enumName)) or (bar and "Bar")))
		end
		SASFakeDragFrame.Action = nil
		SASFakeDragFrame.Bar = nil
		SASFakeDragFrame:SetScript("OnUpdate", nil)
		if ( SAS_DraggingBar and SASActions:IsVisible() ) then
			self:Actions_UpdateBar(SAS_DraggingBar)
		else
			SAS_DraggingBar = nil
		end
	end

	if ( not clear and SAS_DraggingBar and focus.IsSASAction ) then
		-- User dragged a bar onto an empty action
		_G["SASActionBar" .. SAS_DraggingBar]:SetAlpha(1)
		SAS_DraggingBar = nil
		SASFakeDragFrame.Bar = nil
	end

	return action or bar
end

function SimpleActionSets:FakeDrag_PickupAction(action)
	SASFakeDragFrame.Action = action
	SASFakeDragFrame.Bar = nil

	-- User dragged a bar onto an action, which drops the bar and picks up the action instead
	if ( SAS_DraggingBar ) then
		_G["SASActionBar" .. SAS_DraggingBar]:SetAlpha(1)
		SAS_DraggingBar = nil
	end

	if ( action ) then
		local name, texture = self:ParseActionInfo(action)
		for i = 1, barLength do
			_G["SASFakeDragFrameIcon" .. i]:SetTexture()
		end
		self:Debug("FakeDrag Pickup Action " .. name)
		SASFakeDragFrame:Show()
		SASFakeDragFrame:SetScript("OnUpdate", function(self) SimpleActionSets:FakeDrag_OnUpdate(self) end)
		SASFakeDragFrameIcon:SetTexture(texture)
		PlaySoundFile("Sound\\Interface\\uSpellIconPickup.wav")
	else
		SASFakeDragFrame:Hide()
	end
end

function SimpleActionSets:FakeDrag_PickupBar(bar)
	SASFakeDragFrame.Bar = self:CopyTable(bar)
	SASFakeDragFrame.Action = nil

	if ( bar ) then
		SASFakeDragFrameIcon:SetTexture()
		for i = 1, barLength do
			local icon = _G["SASFakeDragFrameIcon" .. i]
			if ( bar[i] ) then
				local texture = self:ParseActionInfo(bar[i], enumTexture)
				icon:SetTexture(texture)
				icon:SetTexCoord(0, 1, 0, 1)
			else
				icon:SetTexture("Interface\\Buttons\\UI-Quickslot")
				icon:SetTexCoord(0.1875, 0.8125, 0.1875, 0.8125)
			end
		end
		SASFakeDragFrame:Show()
		SASFakeDragFrame:SetScript("OnUpdate", function(self) SimpleActionSets:FakeDrag_OnUpdate(self) end)
		PlaySoundFile("Sound\\Interface\\uSpellIconPickup.wav")
	else
		SASFakeDragFrame:Hide()
	end
end

function SimpleActionSets:FakeDrag_OnUpdate(self)
	-- Update the position of the FakeDrag frame to under the cursor
	if ( SASActions:IsVisible() ) then
		local curX, curY = GetCursorPosition()
		local scale = UIParent:GetScale()
		self:SetPoint("CENTER", "UIParent", "BOTTOMLEFT", curX/scale, curY/scale )
	else
		SASFakeDragFrame:SetScript("OnUpdate", nil)
		SimpleActionSets:FakeDrag_Drop(true)
	end
end

-------------------------------
-- Sets DropDown Frame (LDB) --
-------------------------------

function SimpleActionSets:CreateSetsDropDownFrame()
	local frame = CreateFrame("Frame", "SAS_SetsDropDown", UIParent, "UIDropDownMenuTemplate")
	frame:Hide()
	UIDropDownMenu_Initialize(frame, function() SimpleActionSets:SetsDropDown_Initialize() end, "MENU")
end

function SimpleActionSets:SetsDropDown_Initialize()
	local func = function(self) SimpleActionSets:SetsDropDown_OnClick(self) end
	local currentSet = self:GetCurrentSet()
	self:SetsDropDown_AddButton(L["SAS_TEXT_DROPDOWN_TITLE"], true, nil, false, true, "CENTER")
	self:SetsDropDown_AddButton(L["SAS_TEXT_DROPDOWN_OPEN"], true, func)
	self:SetsDropDown_AddButton(L["SAS_TEXT_DROPDOWN_SAVENEW"], true, func)
	self:SetsDropDown_AddButton(L["SAS_TEXT_DROPDOWN_SAVECURRENT"], true, func, currentSet == nil)
	self:SetsDropDown_AddButton(L["SAS_TEXT_DROPDOWN_SETS"], true, nil, false, true, "CENTER")

	if ( not self.db or self:TableIsEmpty(self.db.profile.sets) ) then
		self:SetsDropDown_AddButton(L["SAS_TEXT_DROPDOWN_NONE"], false, nil, true)
	else
		for k, v in self:PairsByKeys(self.db.profile.sets) do
			self:SetsDropDown_AddButton(k, false, func, false, false, nil, currentSet == k)
		end
	end
end

function SimpleActionSets:SetsDropDown_OnClick(self)
	local id = self:GetID()
	if ( id == 2 ) then
		ShowUIPanel(SASMain)
	elseif ( id == 3 ) then
		SimpleActionSets:Actions_SaveNew()
	elseif ( id == 4 ) then
		SimpleActionSets:Warning("SAVE", function(set) SimpleActionSets:SaveSet(set) end, SimpleActionSets:GetCurrentSet())
	elseif ( id > 5 ) then
		SimpleActionSets:Debug(self:GetText())
		SimpleActionSets:SwapSet(self:GetText())
	end
end

function SimpleActionSets:SetsDropDown_AddButton(text, notCheckable, func, disabled, isTitle, justifyH, checked)
	local info = UIDropDownMenu_CreateInfo()
	info.text = text
	info.notCheckable = notCheckable
	info.func = func
	info.disabled = disabled
	info.isTitle = isTitle
	info.justifyH = justifyH
	info.checked = checked
	UIDropDownMenu_AddButton(info)
end

-----------------------------
-- UI Element Constructors --
-----------------------------

function SimpleActionSets:CreateButton(frameToAttach, name, text, x, y, position, offsetX, offsetY, relativeTo, relativePoint, onClick, inherits, id)
	local frame = frameToAttach
	local buttonFrame = CreateFrame("Button", name, frame, inherits or "UIPanelButtonTemplate")
	buttonFrame:SetText(text)
	buttonFrame:SetPoint(position, relativeTo or frame, relativePoint or position, offsetX, offsetY)

	if ( x and y ) then
		buttonFrame:SetSize(x, y)
	end

	if ( onClick ) then
		buttonFrame:SetScript("OnClick", onClick)
	end

	if ( id ) then
		buttonFrame:SetID(id)
	end
end

function SimpleActionSets:CreateCheckedButton(frameToAttach, name, checked, x, y, position, offsetX, offsetY, relativeTo, relativePoint, onClick, onDrag, inherits, tooltipText, text, textPos, textRelPoint)
	local frame = frameToAttach
	local buttonFrame = CreateFrame("CheckButton", name, frame, inherits or "OptionsCheckButtonTemplate")
	buttonFrame:SetChecked(checked)
	buttonFrame:SetPoint(position, relativeTo or frame, relativePoint or position, offsetX, offsetY)
	buttonFrame.tooltipText = tooltipText
	_G[buttonFrame:GetName() .. "Text"]:SetText(text)

	if ( x and y ) then
		buttonFrame:SetSize(x, y)
	end

	if ( onClick ) then
		buttonFrame:SetScript("OnClick", onClick)
	end

	if ( onDrag ) then
		buttonFrame:SetScript("OnReceiveDrag", onDrag)
	end
end

function SimpleActionSets:CreateDivider(frameToAttach, name, position, offsetX, offsetY, relativeTo, relativePoint)
	local divider = self:CreateBasicFrame(nil, name, frameToAttach, nil, 577, 19, position, offsetX, offsetY, relativeTo, relativePoint)

	self:CreateFrameTexture(divider, "$parentLeft", 256, 20, "BACKGROUND", "Interface\\HelpFrame\\HelpFrameDivider", "TOPLEFT", nil, nil, nil, nil, 0, 1, 0, 0.3125)
	self:CreateFrameTexture(divider, "$parentMid", 256, 20, "BACKGROUND", "Interface\\HelpFrame\\HelpFrameDivider", "LEFT", 0, 1, "$parentLeft", "RIGHT", 0, 1, 0.3125, 0.625)
	self:CreateFrameTexture(divider, "$parentRight", 65, 20, "BACKGROUND", "Interface\\HelpFrame\\HelpFrameDivider", "LEFT", nil, nil, "$parentMid", "RIGHT", 0, 0.25390625, 0.625, 0.9375)
end

function SimpleActionSets:CreateFrameTexture(frameToAttach, name, x, y, layer, texture, position, offsetX, offsetY, relativeTo, relativePoint, texLeft, texRight, texTop, texBot)
	local frame = frameToAttach
	local frameTexture = frame:CreateTexture(name, layer)
	frameTexture:SetTexture(texture)
	frameTexture:SetSize(x, y)
	frameTexture:SetPoint(position, relativeTo or frame, relativePoint or position, offsetX, offsetY)

	if ( texLeft ) then
		frameTexture:SetTexCoord(texLeft, texRight, texTop, texBot)
	end

	return frameTexture
end

function SimpleActionSets:CreateString(frameToAttach, name, text, x, y, layer, inherits, position, offsetX, offsetY, relativeTo, relativePoint, justifyV)
	local frame = frameToAttach
	local string = frame:CreateFontString(name, layer, inherits or "GameFontNormal")
	string:SetText(text)
	string:SetPoint(position, relativeTo or frame, relativePoint or position, offsetX, offsetY)

	if ( x and y ) then
		string:SetSize(x, y)
	end

	if ( justifyV ) then
		string:SetJustifyV(justifyV)
	end
end

function SimpleActionSets:CreateBasicFrame(type, name, parent, inherits, x, y, position, offsetX, offsetY, relativeTo, relativePoint, strata, topLevel, enableMouse, movable, hide)
	local frame = CreateFrame(type or "Frame", name, parent, inherits)

	if ( x and y ) then
		frame:SetSize(x, y)
	end

	if ( topLevel ) then
		frame:SetToplevel(topLevel)
	end

	if ( enableMouse ) then
		frame:EnableMouse(enableMouse)
	end

	if ( movable ) then
		frame:SetMovable(movable)
		frame:SetClampedToScreen(movable)
	end

	if ( position ) then
		frame:SetPoint(position, relativeTo or parent, relativePoint or position, offsetX, offsetY)
	end

	if ( hide ) then
		frame:Hide()
	end

	if ( strata ) then
		frame:SetFrameStrata(strata)
	end

	return frame
end

----------------
-- Action Bar --
----------------

function SimpleActionSets:CreateActionBar(frameToAttach, id, position, offsetX, offsetY, relativeTo, relativePoint)
	local name = "SASActionBar" .. id

	local actionBar = self:CreateBasicFrame(nil, name, frameToAttach, nil, 498, actionButtonSize, position, offsetX, offsetY, relativeTo, relativePoint)
	actionBar:SetID(id)

	self:CreateActionBarButton(actionBar, "RIGHT", "LEFT")

	local onClickFunc = function(self) SimpleActionSets:Actions_BarEnable_OnClick(self:GetParent():GetID(), self:GetChecked()) end
	local onDragFunc = function(self) SimpleActionSets:ActionBarButton_OnClick(self) end

	self:CreateCheckedButton(actionBar, "$parentEnable", true, 24, 24, "BOTTOM", 0, 1, "$parentButton", nil, onClickFunc, onDragFunc, "UICheckButtonTemplate")
	self:CreateActionButton(actionBar, 1, "BOTTOMLEFT", 8, 0)

	for i = 2, barLength do
		-- Create action button
		self:CreateActionButton(actionBar, i, "LEFT", 6, 0, name .. "Action" .. (i - 1), "RIGHT")
	end
end

function SimpleActionSets:Actions_Bar_CheckAll(enable)
	for i = 0, maxBar do
		self:ActionsBarSetEnabled(i, enable)
	end
	self:Actions_Display()
end

function SimpleActionSets:Actions_BarEnable_OnClick(bar, enable)
	self:ActionsBarSetEnabled(bar, enable)
	self:Actions_UpdateBar(bar)
	SASActionsCheckAll:SetChecked(true)
	self:Actions_SaveEnable()
end

function SimpleActionSets:ActionsBarSetEnabled(bar, enable)
	if ( self:GetTemp(bar) ) then
		-- Set/Clear disabled flag (held at bar[0]), true = disabled, nil = enabled
		self:SetTemp(bar, 0, not enable or nil)
	end
end

-------------------
-- Action Button --
-------------------

function SimpleActionSets:CreateActionButton(frameToAttach, id, position, offsetX, offsetY, relativeTo, relativePoint)
	local texturePath = "Interface\\Buttons\\"

	local buttonFrame = self:CreateBasicFrame("Button", "$parentAction" .. id, frameToAttach, nil, actionButtonSize, actionButtonSize, position, offsetX, offsetY, relativeTo, relativePoint)
	buttonFrame:SetID(id)

	self:CreateFrameTexture(buttonFrame, "$parentIcon", actionButtonSize, actionButtonSize, "BACKGROUND", nil, "CENTER")

	self:CreateString(buttonFrame, "$parentHotKey", id, nil, nil, "ARTWORK", "NumberFontNormalSmallGray", "TOPRIGHT", -2, -2)
	self:CreateString(buttonFrame, "$parentName", nil, actionButtonSize, 10, "OVERLAY", "GameFontHighlightSmallOutline", "BOTTOM", 0, 2)

	local frameTexture = self:CreateFrameTexture(buttonFrame, "$parentBorder", 62, 62, "OVERLAY", texturePath .. "UI-ActionButton-Border", "CENTER")
	frameTexture:SetBlendMode("ADD")

	frameTexture = self:CreateFrameTexture(buttonFrame, "$parentDelete", 32, 32, "OVERLAY", texturePath .. "UI-GroupLoot-Pass-Up", "CENTER")
	frameTexture:Hide()

	frameTexture = self:CreateFrameTexture(buttonFrame, "$parentCopy", 62, 62, "OVERLAY", texturePath .. "UI-AutoCastableOverlay", "CENTER")
	frameTexture:Hide()

	buttonFrame:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	buttonFrame:RegisterForDrag("LeftButton")
	buttonFrame.IsSASAction = true

	buttonFrame:SetScript("OnClick", function(self, button) SimpleActionSets:ActionButton_OnClick(self, button) end)
	buttonFrame:SetScript("OnEnter", function(self) SimpleActionSets:ActionButton_OnEnter(self) end)
	buttonFrame:SetScript("OnLeave", function(self) SimpleActionSets:ActionButton_OnLeave(self) end)
	buttonFrame:SetScript("OnDragStart", function(self) SimpleActionSets:ActionButton_OnDragStart(self) end)
	buttonFrame:SetScript("OnDragStop", function() SimpleActionSets:FakeDrag_Drop() end)
	buttonFrame:SetScript("OnReceiveDrag", function(self) SimpleActionSets:ActionButton_OnClick(self) end)
	buttonFrame:SetScript("OnMouseDown", function(self, button) SimpleActionSets:ActionButton_OnMouseDown(self, button) end)
	buttonFrame:SetScript("OnMouseUp", function(self, button) SimpleActionSets:ActionButton_OnMouseUp(self, button) end)

	frameTexture = self:CreateFrameTexture(buttonFrame, "$parentNormalTexture", 66, 66, nil, texturePath .. "UI-Quickslot2", "CENTER", 0, -1)

	buttonFrame:SetNormalTexture(frameTexture)
	buttonFrame:SetPushedTexture(texturePath .. "UI-Quickslot-Depress")
	buttonFrame:SetHighlightTexture(texturePath .. "ButtonHilight-Square")
end

function SimpleActionSets:ActionButton_OnClick(self, button)
	-- Pick up action, and replace with held action (if there is one)
	local bar = self:GetParent():GetID()
	local slot = self:GetID()
	local LocalSavedAction
	local SAS_SavedPickup = SimpleActionSets:GetSavedPickup()
	local SAS_ReturnAction = SimpleActionSets:GetReturnAction()
	local inCombat = SimpleActionSets:GetCombatStatus()
	local SAS_TempButton = SimpleActionSets:GetTemp(bar, slot)

	if (button == "RightButton") then
		if ( SASFakeDragFrame.Action ) then
			SimpleActionSets:FakeDrag_Drop(true)
		-- Move state one along, normal (nil)->force clear->force no change (loop)
		elseif ( SAS_TempButton == enumForceClear ) then
			SimpleActionSets:SetTemp(bar, slot, enumForceNoChange)
		elseif ( SAS_TempButton == enumForceNoChange or SAS_TempButton ) then
			SimpleActionSets:SetTemp(bar, slot, nil)
		else
			SimpleActionSets:SetTemp(bar, slot, enumForceClear)
		end
	elseif ( IsShiftKeyDown() and not IsControlKeyDown() and not SASFakeDragFrame.Action ) then
		LocalSavedAction = SAS_TempButton
		ClearCursor()
	else
		local actionName = SimpleActionSets:ParseActionInfo(SAS_SavedPickup or SASFakeDragFrame.Action or SAS_TempButton, enumName)
		if ( SAS_SavedPickup ) then
			-- Cursor has an item / action / macro that can be placed on the action bar
			SimpleActionSets:Debug("ActionButton_OnClick getting action " .. actionName .. " from cursor")
			if ( SimpleActionSets:GetTemp(bar) and not SAS_TempButton == SAS_SavedPickup ) then
				LocalSavedAction = SAS_TempButton
			end
			SimpleActionSets:SetTemp(bar, slot, SAS_SavedPickup)
			if ( SAS_ReturnAction and not inCombat ) then
				PlaceAction(SAS_ReturnAction)
			elseif ( not inCombat ) then
				ClearCursor()
			end
		elseif ( SASFakeDragFrame.Action ) then
			-- Cursor fake drag is holding an action
			SimpleActionSets:Debug("ActionButton_OnClick getting fake drag action " .. actionName)
			if ( SimpleActionSets:GetTemp(bar) and SAS_TempButton ) then
				LocalSavedAction = SAS_TempButton
			end
			SimpleActionSets:SetTemp(bar, slot, SimpleActionSets:FakeDrag_Drop(true))
		elseif ( SAS_TempButton ) then
			SimpleActionSets:Debug("ActionButton_OnClick putting action " .. actionName .. " on fake drag")
			-- This slot already has an action, pick it up
			LocalSavedAction = SAS_TempButton
			SimpleActionSets:SetTemp(bar, slot, nil)
			if ( IsControlKeyDown() and not IsShiftKeyDown() ) then
				LocalSavedAction = nil
			end
			_G[self:GetName() .. "Delete"]:Hide()
			_G[self:GetName() .. "Copy"]:Hide()
		end
	end

	if (LocalSavedAction) then
		SimpleActionSets:FakeDrag_PickupAction(LocalSavedAction)
	end
	SimpleActionSets:Actions_UpdateBar(bar)
	SimpleActionSets:Actions_SaveEnable()
	SimpleActionSets:ActionButton_OnEnter(self)
end

function SimpleActionSets:ActionButton_OnEnter(self)
	local bar = self:GetParent():GetID()
	local slot = self:GetID()
	local enabled = _G["SASActionBar" .. bar .. "Enable"]:GetChecked()

	-- Make Copy/Delete textures display for this button
	self:SetScript("OnUpdate", function(self) SimpleActionSets:ActionButton_OnUpdate(self) end)

	if ( not enabled ) then
		SetDesaturation(_G[self:GetName() .. "Icon"], 0)
		self:SetAlpha(1)
		self:SetNormalTexture("Interface\\Buttons\\UI-Quickslot")
	end

	if ( _G[self:GetName().."Icon"]:IsVisible() and SimpleActionSets:GetTemp() ) then
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		SimpleActionSets:SetTooltip(self, bar, slot)
	else
		GameTooltip:Hide()
	end
end

function SimpleActionSets:ActionButton_OnLeave(self)
	-- Hide the tooltip, reset desaturated on disabled bars
	local enabled = _G["SASActionBar" .. self:GetParent():GetID() .. "Enable"]:GetChecked()
	local bar = self:GetParent():GetID()
	local slot = self:GetID()

	SimpleActionSets:Actions_UpdateAction(bar, slot)
	self:SetScript("OnUpdate", nil)
	_G[self:GetName() .. "Delete"]:Hide()
	_G[self:GetName() .. "Copy"]:Hide()
	GameTooltip:Hide()
end

function SimpleActionSets:ActionButton_OnDragStart(self)
	local bar = self:GetParent():GetID()
	local slot = self:GetID()

	SimpleActionSets:FakeDrag_PickupAction(SimpleActionSets:GetTemp(bar, slot))
	if ( not IsShiftKeyDown() ) then
		SimpleActionSets:SetTemp(bar, slot, nil)
		SimpleActionSets:Actions_UpdateBar(bar)
		SimpleActionSets:Actions_SaveEnable(self)
	end
end

function SimpleActionSets:ActionButton_OnMouseDown(self, button)
	if ( button == "RightButton" ) then
		local bar = self:GetParent():GetID()
		local slot = self:GetID()
		local SAS_TempBar = SimpleActionSets:GetTemp(bar)
		if ( SAS_TempBar and SAS_TempBar[slot] and type(SAS_TempBar[slot]) == "string" ) then
			self.mousedown = true
		end
	end
end

function SimpleActionSets:ActionButton_OnMouseUp(self, button)
	-- Although only set by RightButton, any other click disrupts the delete
	self.mousedown = false
	_G[self:GetName() .. "Delete"]:Hide()
end

function SimpleActionSets:ActionButton_OnUpdate(self)
	if ( not _G[self:GetName().."Icon"]:IsVisible() or not SimpleActionSets:GetTemp() ) then return end

	if ( self.mousedown or (IsControlKeyDown() and not IsShiftKeyDown()) ) then
		_G[self:GetName() .. "Delete"]:Show()
	else
		_G[self:GetName() .. "Delete"]:Hide()
	end
	if ( IsShiftKeyDown() and not IsControlKeyDown() and not self.mousedown) then
		_G[self:GetName() .. "Copy"]:Show()
	else
		_G[self:GetName() .. "Copy"]:Hide()
	end
end

-----------------------
-- Action Bar Button --
-----------------------

function SimpleActionSets:CreateActionBarButton(frameToAttach, position, relativePoint)
	local barButtonX, barButtonY = 29, 44

	local actionBarButton = self:CreateBasicFrame("Button", "$parentButton", frameToAttach, nil, barButtonX, barButtonY, position, nil, nil, nil, relativePoint)
	actionBarButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	actionBarButton:RegisterForDrag("LeftButton")
	actionBarButton.IsSASBar = true

	self:CreateString(actionBarButton, "$parentNumber", frameToAttach:GetID() + 1, nil, nil, "ARTWORK", "GameFontNormalLarge", "TOP", -2, -4)

	actionBarButton:SetScript("OnClick", function(self, button) SimpleActionSets:ActionBarButton_OnClick(self, button) end)
	actionBarButton:SetScript("OnEnter", function(self) SimpleActionSets:ActionBarButton_OnEnter(self) end)
	actionBarButton:SetScript("OnLeave", function(self) SimpleActionSets:ActionBarButton_OnLeave(self) end)
	actionBarButton:SetScript("OnDragStart", function(self) SimpleActionSets:ActionBarButton_OnDragStart(self) end)
	actionBarButton:SetScript("OnDragStop", function() SimpleActionSets:FakeDrag_Drop() end)
	actionBarButton:SetScript("OnReceiveDrag", function(self) SimpleActionSets:ActionBarButton_OnClick(self) end)

	-- Allows clicks to go through to the enable bar checkbox
	actionBarButton:SetHitRectInsets(0, 0, 0, 22)

	local texturePath = "Interface\\Buttons\\UI-MicroButton"

	local frameTexture = self:CreateFrameTexture(actionBarButton, nil, barButtonX, barButtonY, nil, texturePath .. "Character-Up", "CENTER", nil, nil, nil, nil, 0.2, 1, 0.359375, 1)
	actionBarButton:SetNormalTexture(frameTexture)

	frameTexture = 	self:CreateFrameTexture(actionBarButton, nil, barButtonX, barButtonY, nil, texturePath .. "Character-Down", "CENTER", nil, nil, nil, nil, 0.2, 1, 0.359375, 1)
	actionBarButton:SetPushedTexture(frameTexture)

	frameTexture = 	self:CreateFrameTexture(actionBarButton, nil, barButtonX, barButtonY, nil, texturePath .. "-Hilight", "CENTER", nil, nil, nil, nil, 0.2, 1, 0.359375, 1)
	actionBarButton:SetHighlightTexture(frameTexture)
end

function SimpleActionSets:ActionBarButton_OnClick(self, button)
	local bar = self:GetParent():GetID()
	local LocalSavedBar = SimpleActionSets:CopyTable(SimpleActionSets:GetTemp(bar))
	local returnbar = SAS_DraggingBar

	if ( button == "RightButton" ) then
		if ( LocalSavedBar ) then
			local set
			for slot = 1, barLength do
				if ( not LocalSavedBar[slot] or type(LocalSavedBar[slot]) == "number" ) then
					-- Move state one along, normal (nil)->force clear->force no change (loop), keeping bar the same
					-- -1 is an arbitrary number to give set a value that isn't nil (had to be different to enumForceClear and enumForceNoChange)
					set = set or LocalSavedBar[slot] or -1

					if ( set == enumForceClear ) then
						SimpleActionSets:SetTemp(bar, slot, enumForceNoChange)
					elseif ( set == enumForceNoChange ) then
						SimpleActionSets:SetTemp(bar, slot, nil)
					else
						SimpleActionSets:SetTemp(bar, slot, enumForceClear)
					end
				end
			end
		end
		LocalSavedBar = nil
	elseif ( SASFakeDragFrame.Bar and not (IsShiftKeyDown() or IsControlKeyDown()) ) then
		-- Copying fake drag bar to bar that was clicked on
		SimpleActionSets:SetTemp(bar, nil, SimpleActionSets:FakeDrag_Drop(true))
		if ( returnbar ) then
			-- Copy bar (before copy) to previous bar
			SAS_DraggingBar = nil
			SimpleActionSets:SetTemp(returnbar, nil, SimpleActionSets:CopyTable(LocalSavedBar))
			SimpleActionSets:Actions_UpdateBar(returnbar)
		end
		LocalSavedBar = nil
	elseif ( IsControlKeyDown() and not IsShiftKeyDown() ) then
		-- Clears the bar
		SimpleActionSets:SetTemp(bar, nil, {})
	end

	if ( SimpleActionSets:BarHasActions(bar) and LocalSavedBar ) then
		SimpleActionSets:FakeDrag_PickupBar(LocalSavedBar)
		if ( not IsShiftKeyDown() ) then
			SAS_DraggingBar = bar
		end
	end
	SimpleActionSets:Actions_UpdateBar(bar)
	SimpleActionSets:Actions_SaveEnable()
end

function SimpleActionSets:ActionBarButton_OnEnter(self)
	self:SetScript("OnUpdate", function(self) SimpleActionSets:ActionBarButton_OnUpdate(self) end)
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	GameTooltip:SetText(L["SAS_TEXT_BARS_" .. self:GetParent():GetID()])
	GameTooltip:Show()
end

function SimpleActionSets:ActionBarButton_OnLeave(self)
	self:SetScript("OnUpdate", nil)

	for i = 1, barLength do
		local barButton = _G[self:GetParent():GetName() .. "Action" .. i]:GetName()
		_G[barButton .. "Delete"]:Hide()
		_G[barButton .. "Copy"]:Hide()
	end

	GameTooltip:Hide()
end

function SimpleActionSets:ActionBarButton_OnDragStart(self)
	local bar = self:GetParent():GetID()
	if ( SimpleActionSets:BarHasActions(bar) ) then
		SimpleActionSets:Debug("Picking up bar " .. bar )
		SimpleActionSets:FakeDrag_PickupBar(SimpleActionSets:GetTemp(bar))
		SAS_DraggingBar = bar
		SimpleActionSets:Actions_UpdateBar(bar)
	else
		SimpleActionSets:FakeDrag_PickupBar()
		SAS_DraggingBar = nil
	end
end

function SimpleActionSets:ActionBarButton_OnUpdate(self)
	if ( not SimpleActionSets:GetTemp() ) then return end

	local BarFrame = self:GetParent()
	local barName = BarFrame:GetName()

	for i = 1, barLength do
		local barButton = _G[barName .. "Action" .. i]:GetName()
		if ( IsControlKeyDown() and not IsShiftKeyDown() and _G[barButton .. "Icon"]:IsVisible() ) then
			_G[barButton .. "Delete"]:Show()
			_G[barButton .. "Copy"]:Hide()
		elseif ( IsShiftKeyDown() and not IsControlKeyDown() and SimpleActionSets:BarHasActions(BarFrame:GetID()) ) then
			_G[barButton .. "Copy"]:Show()
			_G[barButton .. "Delete"]:Hide()
		else
			_G[barButton .. "Delete"]:Hide()
			_G[barButton .. "Copy"]:Hide()
		end
	end
end
