﻿--[[
	Sick Of Clicking Dailies? - Locale file for alt tracking module
	Written By: OrionShock
]]--

do	--enUS Base, Always Load
	local silent = false
	--[===[@debug@
	silent = true
	--@end-debug@]===]

	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "enUS", true, silent)

	if L then

L["Dailies for all Characters"] = true
L["Dailies On Alts"] = true


	end
end

do	--deDE
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "deDE")

	if L then

L["Dailies for all Characters"] = "Dailies für alle Charaktere"
L["Dailies On Alts"] = "Dailies auf Twinks"


	end
end

do	--esES
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "esES")

	if L then

-- L["Dailies for all Characters"] = ""
-- L["Dailies On Alts"] = ""


	end
end

do	--esMX
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "esMX")

	if L then

-- L["Dailies for all Characters"] = ""
-- L["Dailies On Alts"] = ""


	end
end

do	--frFR
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "frFR")

	if L then

L["Dailies for all Characters"] = "Journalières de tous les personnages" -- Needs review
L["Dailies On Alts"] = "Journalières des rerolls" -- Needs review


	end
end

do	--itIT
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "itIT")

	if L then

-- L["Dailies for all Characters"] = ""
-- L["Dailies On Alts"] = ""


	end
end

do	--koKR
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "koKR")

	if L then

-- L["Dailies for all Characters"] = ""
-- L["Dailies On Alts"] = ""


	end
end

do	--ptBR
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "ptBR")

	if L then

-- L["Dailies for all Characters"] = ""
-- L["Dailies On Alts"] = ""


	end
end

do	--ruRU
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "ruRU")

	if L then

-- L["Dailies for all Characters"] = ""
-- L["Dailies On Alts"] = ""


	end
end

do	--zhCN
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "zhCN")

	if L then

L["Dailies for all Characters"] = "所有角色的日常" -- Needs review
L["Dailies On Alts"] = "小号的日常" -- Needs review


	end
end

do	--zhTW
	local L = LibStub("AceLocale-3.0"):NewLocale("SOCD_AltTracking", "zhTW")

	if L then

L["Dailies for all Characters"] = "所有角色的每日"
L["Dailies On Alts"] = "分身的每日"


	end
end
