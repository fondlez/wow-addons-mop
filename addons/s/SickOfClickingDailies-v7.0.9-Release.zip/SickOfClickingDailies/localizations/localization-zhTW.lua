﻿--[[
	Sick Of Clicking Dailies? - Locale file for zhTW
	Written By: OrionShock

]]--
local addonName = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "zhTW", false)

if L then

L["Auto Complete Daily or Weekly?"] = "自動完成每日或每周任務嗎？"
L["Click: Left for Quest Log"] = "點擊: 左鍵 開啟任務日誌"
L["Dailies reset in"] = "重置每日"
L["Disabled Quests"] = "取消的任務"
L["Enabled Gossip"] = "啟用廢話"
L["Expires"] = "過期"
L["Found a new Quest:"] = "找到一個新的任務："
-- L["It has reward choices but is not yet added to the addon. Please report it at http://www.wowace.com/addons/sick-of-clicking-dailies/tickets/"] = ""
L["Listed here are disabled quests, when unchecked they will be enabled and will be removed here"] = "這裡列出的是禁用任務，未勾選時，他們將被啟用並從這裡移除"
L["Listed here are enabled gossip options, when unchecked they will be disabled and will be removed here"] = "這裡列出的是已啟用的廢話選項，當未勾選時將會取消並且從這裡移除。"
L["Quest"] = "任務"
L["Quest Reward Choices"] = "任務獎勵選擇"
L["QuestScanner finished, Sick of Clicking Dailies is now ready for use."] = "任務掃描結束，Sick of Clicking Dailies現在已可使用。"
L["QuestScanner started, Sick of Clicking Dailies can be used once it's finished."] = "任務掃描已開始，當完成時Sick of Clicking Dailies就可使用。"
L["Right for SOCD Options"] = "右鍵開啟SOCD選項"


end

---Localization Counter-- Bump to generate new zip for locale changes = 16
