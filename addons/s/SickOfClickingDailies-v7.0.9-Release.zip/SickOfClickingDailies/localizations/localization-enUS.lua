--[[
	Sick Of Clicking Dailies? - Locale file for enUS
	Written By: OrionShock

]]--
local addonName = ...
local silent = false
--[===[@debug@
silent = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "enUS", true, silent)

if L then

L["Auto Complete Daily or Weekly?"] = true
L["Click: Left for Quest Log"] = true
L["Dailies reset in"] = true
L["Disabled Quests"] = true
L["Enabled Gossip"] = true
L["Expires"] = true
L["Found a new Quest:"] = true
L["It has reward choices but is not yet added to the addon. Please report it at http://www.wowace.com/addons/sick-of-clicking-dailies/tickets/"] = true
L["Listed here are disabled quests, when unchecked they will be enabled and will be removed here"] = true
L["Listed here are enabled gossip options, when unchecked they will be disabled and will be removed here"] = true
L["Quest"] = true
L["Quest Reward Choices"] = true
L["QuestScanner finished, Sick of Clicking Dailies is now ready for use."] = true
L["QuestScanner started, Sick of Clicking Dailies can be used once it's finished."] = true
L["Right for SOCD Options"] = true


end

---Localization Counter-- Bump to generate new zip for locale changes = 18
