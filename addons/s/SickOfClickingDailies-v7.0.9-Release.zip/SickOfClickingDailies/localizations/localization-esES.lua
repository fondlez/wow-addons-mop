﻿--[[
	Sick Of Clicking Dailies? - Locale file for esES
	Written By: OrionShock

]]--
local addonName = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "esES", false)

if L then

-- L["Auto Complete Daily or Weekly?"] = ""
-- L["Click: Left for Quest Log"] = ""
-- L["Dailies reset in"] = ""
-- L["Disabled Quests"] = ""
-- L["Enabled Gossip"] = ""
-- L["Expires"] = ""
-- L["Found a new Quest:"] = ""
-- L["It has reward choices but is not yet added to the addon. Please report it at http://www.wowace.com/addons/sick-of-clicking-dailies/tickets/"] = ""
-- L["Listed here are disabled quests, when unchecked they will be enabled and will be removed here"] = ""
-- L["Listed here are enabled gossip options, when unchecked they will be disabled and will be removed here"] = ""
-- L["Quest"] = ""
-- L["Quest Reward Choices"] = ""
-- L["QuestScanner finished, Sick of Clicking Dailies is now ready for use."] = ""
-- L["QuestScanner started, Sick of Clicking Dailies can be used once it's finished."] = ""
-- L["Right for SOCD Options"] = ""


end

---Localization Counter-- Bump to generate new zip for locale changes = 16
