﻿--[[
	Sick Of Clicking Dailies? - Locale file for deDE
	Written By: OrionShock

]]--
local addonName = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "deDE", false)

if L then

L["Auto Complete Daily or Weekly?"] = "Quest automatisch Annehmen und Abgeben?"
L["Click: Left for Quest Log"] = "Klicken: Links für Questlog"
L["Dailies reset in"] = "Dailies werden zurückgesetzt in"
L["Disabled Quests"] = "Deaktivierte Quests"
L["Enabled Gossip"] = "Aktivierte Gesprächsoptionen"
L["Expires"] = "Ablauf"
L["Found a new Quest:"] = "Neue Quest gefunden:"
L["It has reward choices but is not yet added to the addon. Please report it at http://www.wowace.com/addons/sick-of-clicking-dailies/tickets/"] = "Sie hat Belohnungen zur Auswahl, wurde aber noch nicht zum Addon hinzugefügt. Bitte melde sie auf http://www.wowace.com/addons/sick-of-clicking-dailies/tickets/"
L["Listed here are disabled quests, when unchecked they will be enabled and will be removed here"] = "Hier sind deaktivierte Quests aufgelistet. Wenn der Haken entfernt wird, werden sie aktiviert und hier entfernt."
L["Listed here are enabled gossip options, when unchecked they will be disabled and will be removed here"] = "Hier sind aktivierte Gesprächsoptionen aufgelistet. Wenn der Haken entfernt wird, werden sie deaktiviert und hier entfernt."
L["Quest"] = true
L["Quest Reward Choices"] = "Questbelohnungen"
L["QuestScanner finished, Sick of Clicking Dailies is now ready for use."] = "QuestScanner fertig, Sick of Clicking Dailies kann nun benutzt werden."
L["QuestScanner started, Sick of Clicking Dailies can be used once it's finished."] = "QuestScanner gestartet, Sick of Clicking Dailies kann benutzt werden, sobald er fertig ist."
L["Right for SOCD Options"] = "Rechts für SOCD Optionen"


end

---Localization Counter-- Bump to generate new zip for locale changes = 16
