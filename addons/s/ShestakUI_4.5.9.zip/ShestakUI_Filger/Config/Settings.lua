local T, C, L, _ = unpack(ShestakUI)
if C.unitframe.enable ~= true then return end

C["filger_settings"] = {
	config_mode = false,
	max_test_icon = 5,
	show_tooltip = false,
}