-- @release $Id: Options.lua 244 2012-12-07 12:56:19Z reighnman $

if not SlamAndAwe then return end

local L = LibStub("AceLocale-3.0"):GetLocale("SlamAndAwe")
local media = LibStub:GetLibrary("LibSharedMedia-3.0");
if not C then 
	SlamAndAwe:SetConstants()
end
local _, _, _, clientVersion = GetBuildInfo()

SlamAndAwe.emptyOptions = { "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none" }
SlamAndAwe.furyOptions = { "re_boss", "ava", "blb", "br", "none", "dec_boss", "bt_r", "cs", "ex", "stb", "rb", "wis_bs", "shw", "drr", "het", "bsh_noCS", "bls", "wis_cs", "bsh_rage", "bt" }
SlamAndAwe.protectionOptions = { "thcl_wb", "shs", "reve", "bsh", "deva", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none", "none" }
SlamAndAwe.armsOptions = { "re_boss", "ava", "blb", "br", "none", "dec_boss", "most", "cs_re", "ex", "stb", "ovpo", "shw", "drr", "sl_cs", "het", "bsh_noCS", "bls", "sl", "imv", "bsh_rage" }

SlamAndAwe.fonteffects = {
	["none"] = L["None"],
	["OUTLINE"] = L["OUTLINE"],
	["THICKOUTLINE"] = L["THICKOUTLINE"],
	["MONOCHROME"] = L["MONOCHROME"],
}

-------------------
-- Config details
-------------------
function SlamAndAwe:SetDefaultOptions()
	SlamAndAwe.defaults = {
		char = {
			disabled = false,
			specchangewarning = true,
			message = "Welcome Home!",
			movingframes = true,
			showicons = true,
			relativeTo = "UIParent",
			relativePoint = "CENTER",
			point = "CENTER",
			texture = "Blizzard",
			barfont = "Friz Quadrata TT",
			barfontsize = 12,
			barfonteffect = "none",
			msgfont = "Friz Quadrata TT",
			msgfontsize = 24,
			msgfonteffect = "none",
			border = "None",
			barborder = "Blizzard Tooltip",
			tfb5flash = true,
			tfb4sound = "Sound\\Spells\\ShootWandLaunchLightning.wav",
			tfb4soundname = "SAA Maelstrom 1",
			tfb5sound = "Sound\\Spells\\DynamiteExplode.wav",
			tfb5soundname = "SAA Maelstrom 2",
			shieldsound = "Sound\\Doodad\\BellowIn.wav",
			shieldsoundname = "SAA Shield 1",
			weaponsound = "Sound\\Doodad\\BellowIn.wav",
			weaponsoundname = "SAA Shield 1",
			framestratalevel = "LOW",
			xOffset = 0,
			yOffset = -100,
			fWidth = 300,
			fHeight = 175,
			resetOn = true,
			scale = 1,
			ShockPercent = .6,
			ShearPercent = .6,
			shockshow = true,
			shearshow = false,
			ssshow = true,
			firetotemshow = true,
			wfshow = true,
			fsdotshow = true,
			gcdshow = true,
			gcdfullwidth = false,
			fnshow = true,
			fsshow = true,
			petshow = false,
			disablebars = false,
			maelstromTalents = 0,
			feralSpiritTalented = false,
			tfb4soundplay = true,
			tfb5soundplay = true,
			tfb5repeat = 3,
			tfbflash = true,
			shieldshow = true,
			tfbshow = true,
			tfbstacks = 0,
			arena = false,
			barstext = true,
			SSlen = 8,
			maxLen = 10,

--SlamAndAwe
			rageshow = true,
			hsshow = true,		
			rageThreshold = 90,
			csshow = true,
			dcshow = true,
			reshow = true,
			sbshow = true,
			sblshow = true,
			swshow = true,
			swstshow = true,
			demoshoutshow = true,
			laststandshow = true,
			rallyingcryshow = true, 
			CSLen = 6,
			DWLen = 30,
			RELen = 12,
			SBLen = 10,
			SBlLen = 6,
			SWLen = 12,
			DCLen = 9,
			SWSTLen = 10,
			TFBLen = 15,
			RCLen = 10,
			threatThreshold = 90,
			DSLen = 11,
			LSLen = 20,
			RCLen = 10,
			enableTimeRemaining = false,
			enableDisableBorder = false,
			hideRageBarOOC = false,
			enableProtSpec = true,
			enableFurySpec = true,
			enableArmsSpec = true,
			
			
--SlamAndAwe Announcements
			announce_skull_banner = true,
			announce_skull_banner_where = 1,
			announce_demoralizing_banner = true,
			announce_demoralizing_banner_where = 1,
			announce_mocking_banner = true,
			announce_mocking_banner_where = 1,
			announce_interrupt = true,
			announce_interrupt_where = 1,
			sBannerLen = 10,
			dBannerLen = 15,
			mBannerLen = 30,
			
--SlamAndAwe CDs
			PurgeLen = 10,
			RagingBlowLen = 6,
			BloodthirstLen = 3,
			BattleShoutLen = 30,
			ColossusSmashLen = 20,
			SweepingStrikesLen = 10,
			
			ShockLen = 6,
			ShearLen = 6,
			lastshock = "",
			debug = false,
			msg = { r = 1, g = .5, b = 0, },
			msgtime = 2,
			newsitem = 0,
			castweaponrebuff = false,
			MSBToutputarea = "Notification",
			colours = {
				watershield = { r=.6, g=.6,	b=1, a=.3 },
				lightningshield = { r=0, g=0, b=1, a=.5 },
				earthshield = { r=0, g=1, b=0, a=.5 },
				noshield = { r=1, g=0, b=0, a=1 },
				
				flameshock = { r=1, g=.6, b=.2, a=.9 },
				flameshockDot = { r=1, g=.6, b=.2, a=.6 },
				earthshock = { r=0, g=1, b=.3, a=.9 },
				frostshock = { r=.6, g=.6, b=1, a=.9 },
				windshear = { r=.6, g=.6, b=.6, a=.9 },
				magma = { r=.9, g=.4, b=0, a=.9 },
				feralspiritCD = { r=0, g=.6, b=.95, a=.9 },
				stormstrike = { r=1, g=1, b=.2, a=.9 },
				firenova = { r=1, g=.9, b=.4, a=.9 },
				windfury = { r=1, g=0, b=0, a=.5 },

--SlamAndAwe

        rage = { r=1, g=0, b=0, a=.9 },
        bloodthirst = { r=0, g=1, b=.3, a=.9 },
        ragingblow = { r=0, g=1, b=.3, a=.9 },
        bloodsurge = { r=0, g=1, b=.3, a=.9 },
	      slam = { r=0, g=1, b=.3, a=.9 },
	      heroicstrike = { r=0, g=1, b=.3, a=.9 },
	      purge = { r=0, g=1, b=.3, a=.9 },		
	      colossussmash = { r=1, g=.8, b=0, a=.9 },	
	      sweepingstrikes = { r=.5, g=.8, b=1, a=.9 },	

	      tfb = { r=1, g=.5, b=1, a=.3 },
		  tfbalpha = .3,
		  tfbalphaFull = .9,
		  
		  deadlycalm = { r=1, g=.6, b=0, a=.9 },
		  recklessness = { r=1, g=.13, b=0, a=.9 },		
  
  	      shieldbarrier = { r=.7, g=0, b=.7, a=.9 },	
		  shieldblock = { r=0, g=.8, b=0, a=.9 },
		  shieldwall = { r=0, g=0, b=.8, a=.9 },
		  demoshout = { r=0, g=.8, b=0, a=.9},
		  laststand = { r=.8, g=.8, b=0, a=.9},
		  rallyingcry = {r=.1,g=.1,b=.8, a=.9},
			},
			uptime = {
				show = true,
				fWidth = 120,
				fHeight = 120,
				barWidth = 100,
				barHeight = 20,
				relativeTo = "UIParent",
				relativePoint = "CENTER",
				point = "CENTER",
				xOffset = -200,
				yOffset = -275,
				alpha = 0.4,
				scale = 1,
				flurry = { r = .2, g = .1, b = 1, a = 0.5, },
				en = { r = 1, g = 1, b = .8, a = 0.5, },
				ur = { r = 1, g = .5, b = 0, a = 0.5, },
			},
			stats = {
				show = true,
				fWidth = 120,
				fHeight = 200,
				barWidth = 100,
				barHeight = 20,
				relativeTo = "SlamAndAwe.UptimeFrame",
				relativePoint = "TOPLEFT",
				point = "TOPLEFT",
				xOffset = 125,
				yOffset = 0,
				alpha = 0.4,
				scale = 1,	
				wfcalc = true,
				wfcol = { r = 1, g = .5, b = 0, a = 0.8, },
				wftime = 2,
				best = {
					ap = 0,
					spellpower = 0,
					meleehit = 0,
					spellhit = 0,
					expertise = 0,
					meleecrit = 0,
					spellcrit = 0,
					wfmh = 0,
					wfoh = 0,
					stormstrike = 0,
				},
			},
			priority = {
				show = true,
				titleshow = false,
				relativeTo = "UIParent",
				relativePoint = "CENTER",
				point = "CENTER",
				fWidth = 50,
				fHeight = 50,
				xOffset = -215,
				yOffset = -60,
				alpha = 0.4,
				scale = 1,	
				next = 1,
				cooldown = 0.5,
				fsticksleft = 2,
				totemtimeleft = 20,
				srmana = 10,
				wsmana = 0,
				shieldorbs = 1,
				magmaticks = 2,
				firetotemtime = 0,
				searingticks = 0,
				worldbossonly = true,
				hideImmune = true,
--				combopoints = true,
				showpurge = true,
				showinterrupt = true,
				showcooldown = true,
				prOption = SlamAndAwe.singleOptions,
				groupnumber = 1, 
				prOptions = { 	
						SlamAndAwe.furyOptions, 
						SlamAndAwe.protectionOptions, 
						SlamAndAwe.armsOptions, 
						SlamAndAwe.emptyOptions, 
						SlamAndAwe.emptyOptions }
			},
			binding = {
				show = true,
				relativeTo = "UIParent",
				relativePoint = "CENTER",
				point = "CENTER",
				fWidth = 200,
				fHeight = 50,
				xOffset = -200,
				yOffset = -100,
				alpha = 0.4,
				scale = 1,	
				mhspell = SlamAndAwe.constants["Windfury Weapon"],
				ohspell = SlamAndAwe.constants["Flametongue Weapon"],
				macroset = false,
			},
			warning = {
				show = true,
				duration = 3,
				shield = false,
				weapon = true,
				range = false,
				grounding = true,
				interrupt = true,
				purge = true,
				timeleft = 300, 
				colour = { r = 1, g = .5, b = 0, a = 0.5, },
				relativeTo = "UIParent",
				relativePoint = "TOP",
				point = "CENTER",
				fWidth = 400,
				fHeight = 75,
				xOffset = 0,
				yOffset = -250,
			},
		}
	}
end

function SlamAndAwe:VerifyOptions()
	SlamAndAwe.db.char.priority.option =  nil -- remove old format of options
	SlamAndAwe.db.char.priority.options = nil
	if not SlamAndAwe.db.char.priority.prOption then -- fix for corruption in v5.50
		SlamAndAwe.db.char.priority.prOption = SlamAndAwe.emptyOptions
		SlamAndAwe:Print(L["SlamAndAwe Warning : No options set"])
	end
	for index = 1, 20 do
		if not SlamAndAwe.db.char.priority.prOption[index] then
			SlamAndAwe.db.char.priority.prOption[index] = "none"
		end
	end
	for group = 1, 5 do
		for index = 1, 20 do
			if not SlamAndAwe.db.char.priority.prOptions[group][index] then
				SlamAndAwe.db.char.priority.prOptions[group][index] = "none"
			end
		end
	end
end

function SlamAndAwe:GetOptions()
	local options = { 
		name = "SlamAndAwe",
		handler = SlamAndAwe,
		type='group',
		childGroups ='tree',
		args = {
			frames = {
				name = L["Frame Options"],
				type = 'group',
				order = 1,
				args = {
					width = {
						type = 'range',
						name = L["Bar Width"],
						desc = L["help_width"],
						min = 100,
						max = 600,
						step = 10,
						get = "GetWidth",
						set = "SetWidth",
						order = 10,
					},
					height = {
						type = 'range',
						name = L["Bar Height"],
						desc = L["help_height"],
						min = 100,
						max = 700,
						step = 10,
						get = "GetHeight",
						set = "SetHeight",
						order = 11,
					},
					scale = {
						type = 'range',
						name = L["Bar Scale"],
						desc = L["help_scale"],
						min = 0.10,
						max = 2.00,
						step = 0.05,
						get = "GetScale",
						set = "SetScale",
						order = 12,
					},
					framestrata = {
						type = 'select',
						name = L["Frame Strata"],
						get = "getFrameStrataLevel",
						set = "setFrameStrataLevel",
						values = { L["BACKGROUND"], L["LOW"], L["MEDIUM"], L["HIGH"] },
						order = 3,
					},		
					resetbars = {
						type = 'execute',
						name = L["Reset Bars"],
						desc = L["help_reset"],
						func = "ResetBars",
						order = 13,
					},
					resetuptime = {
						type = 'execute',
						name = L["Reset Uptime"],
						desc = L["help_reset_uptime"],
						func = "ResetUptime",
						order = 14,
					},
					resetpriority = {
						type = 'execute',
						name = L["Reset Priority"],
						desc = L["help_reset_priority"],
						func = "ResetPriority",
						order = 15,
					},
				},
			},
			bars = {
				name = L["Bar Settings"],
				type = 'group',
				order = 2,
				args = {
					icons = {
						type = 'toggle',
						name = L["Show bar icons"],
						desc = L["help_baricons"],
						get = "bariconsQuery",
						set = "ActivateBarIcons",
						order = 1,
						},
				  tb_break1 = {
						type = 'header',
						name = L["Misc Bars"],
						order = 2,
					},		
					gcd = {
						type = 'toggle',
						name = L["GCD"],
						desc = L["help_gcd"],
						get = "gcdQuery",
						set = "ActivateGCD",
						order = 3,
					},
					gcdfullwidth = {
						type = 'toggle',
						name = L["GCD full width"],
						desc = L["help_gcd_fullwidth"],
						get = "gcdFullwidthQuery",
						set = "ActivateGCDfullwidth",
						order = 4,
					},
					rage_bar = {
						type = 'toggle',
						name = L["Rage Bar"],
						desc = L["help_Rage"],
						get = "ragebarQuery",
						set = "ActivateRage",
						order = 5,
					},
					RCBar = {
						type = 'toggle',
						name = L["Rallying Cry Bar"],
						desc = L["help_RC"],
						get = "rallyingCryQuery",
						set = "ActivateRallyingCry",
						order = 5,
					},
					tb_break2 = {
						type = 'header',
						name = L["DPS Bars"],
						order = 6,
					},
					CSbar = {
						type = 'toggle',
						name = L["Colossus Smash Bar"],
						desc = L["help_CS"],
						get = "colossussmashQuery",
						set = "ActivateColossusSmash",
						order = 7,
						},
					tfbbar = {
						type = 'toggle',
						name = L["Taste for Blood Bar"],
						desc = L["help_tfb"],
						get = "tfbQuery",
						set = "ActivateTasteForBlood",
						order = 8,
					},
					SWSTbar = {
						type = 'toggle',
						name = L["Sweeping Strikes Bar"],
						desc = L["help_SWST"],
						get = "sweepingstrikesQuery",
						set = "ActivateSweepingStrikes",
						order = 9,
					},
					DCbar = {
						type = 'toggle',
						name = L["Deadly Calm Bar"],
						desc = L["help_DC"],
						get = "deadlycalmQuery",
						set = "ActivateDeadlyCalm",
						order = 10,
						},
					REbar = {
						type = 'toggle',
						name = L["Recklessness Bar"],
						desc = L["help_RE"],
						get = "recklessnessQuery",
						set = "ActivateRecklessness",
						order = 11,
					},
					tb_break3 = {
						type = 'header',
						name = L["Protection Bars"],
						order = 12,
					},
					SBbar = {
						type = 'toggle',
						name = L["Shield Barrier Bar"],
						desc = L["help_SB"],
						get = "shieldbarrierQuery",
						set = "ActivateShieldBarrier",
						order = 13
					},
					SBlbar = {
						type = 'toggle',
						name = L["Shield Block Bar"],
						desc = L["help_SBl"],
						get = "shieldblockQuery",
						set = "ActivateShieldBlock",
						order = 14,
					},
					SWbar = {
						type = 'toggle',
						name = L["Shield Wall Bar"],
						desc = L["help_SW"],
						get = "shieldwallQuery",
						set = "ActivateShieldWall",
						order = 15,
					},	
					LSBar = {
						type = 'toggle',
						name = L["Last Stand Bar"],
						desc = L["help_LS"],
						get = "lastStandQuery",
						set = "ActivateLastStand",
						order = 16,
					},						
					DSBar = {
						type = 'toggle',
						name = L["Demoralizing Shout Bar"],
						desc = L["help_DS"],
						get = "demoShoutQuery",
						set = "ActivateDemoShout",
						order = 17,
					},
					tb_break4 = {
						type = 'header',
						name = L["Misc Settings"],
						order = 18,
					},
					enableTimeRemaining = {
						type = 'toggle',
						name = L["Enable Time Remaining"],
						desc = L["help_enableTimeRemaining"],
						get = "enableTimeRemainingQuery",
						set = "ActivateEnableTimeRemaining",
						order = 19,
					},						
					
					hideRageBarOOC = {
						type = 'toggle',
						name = L["Hide Rage Bar Out of Combat"],
						desc = L["help_hideRageBarOOC"],
						get = "hideRageBarOOCQuery",
						set = "ActivateHideRageBarOOC",
						order = 20,
					},					
				},
			},
			barcolours = {
				name = L["Bar Colours"],
				type = 'group',
				order = 3, 
				args = {
          bc_break1 = {
						type = 'header',
						name = L["Misc Bars"],
						order = 1,
					},
		Rage = {
            type = 'color',
            name = L["Rage Bar Colour"],
            desc = "Rage bar",
            get = "getRageColour",
            set = "setRageColour",
            hasAlpha = true,
            order = 2,
          },
		rallyingcry  = {
            type = 'color',
            name = L["Rallying Cry Bar Colour"],
            desc = L["colRallyingCry"],
            get = "getRallyingCryColour",
            set = "setRallyingCryColour",
            hasAlpha = true,
            order = 2,
          },
		bc_break2 = {
			type = 'header',
			name = L["DPS Bars"],
			order = 3,
		},					
         ColossusSmash = {
            type = 'color',
            name = L["Colossus Smash Bar Colour"],
            desc = L["colColossusSmash"],
            get = "getColossusSmashColour",
            set = "setColossusSmashColour",
            hasAlpha = true,
            order = 4,
          },
          DeadlyCalm = {
            type = 'color',
						name = L["Deadly Calm Bar Colour"],
						desc = L["colDeadlyCalm"],
						get = "getDeadlyCalmColour",
						set = "setDeadlyCalmColour",
						hasAlpha = true,
						order = 5,
					},
					Recklessness = {
						type = 'color',
						name = L["Recklessness Bar Colour"],
						desc = L["colRecklessness"],
						get = "getRecklessnessColour",
						set = "setRecklessnessColour",
						hasAlpha = true,
						order = 6,
					},
					 SweepingSTrikes = {
            type = 'color',
            name = L["Sweeping Strikes Bar Colour"],
            desc = L["colSweepingStrikes"],
            get = "getSweepingStrikesColour",
            set = "setSweepingStrikesColour",
            hasAlpha = true,
            order = 4,
          },
					tfb = {
						type = 'color',
						name = L["Taste for Blood Bar Colour"],
						desc = L["colTasteForBlood"],
						get = "getTasteForBloodColour",
						set = "setTasteForBloodColour",
						hasAlpha = false,
						order = 7,
					},
					tfbalpha = {
						type = 'range',
						name = L["Taste for Blood Alpha"],
						desc = L["colTasteForBloodAlpha"],
						min = 0,
						max = 1,
						isPercent = true,
						get = "GetTFBalpha",
						set = "SetTFBalpha",
						order = 8,
					},
					tfbalphaFull = {
						type = 'range',
						name = L["Taste for Blood Full Alpha"],
						desc = L["colTasteForBloodFullAlpha"],
						min = 0,
						max = 1,
						isPercent = true,
						get = "GetTFBalphaFull",
						set = "SetTFBalphaFull",
						order = 9,
					},
					bc_break3 = {
						type = 'header',
						name = L["Protection Bars"],
						order = 10,
					},			
					ShieldBarrier = {
						type = 'color',
						name = L["Shield Barrier Colour"],
						desc = L["colShieldBarrier"],
						get = "getShieldBarrierColour",
						set = "setShieldBarrierColour",
						hasAlpha = true,
						order = 11,
					},
					ShieldBlock = {
						type = 'color',
						name = L["Shield Block Colour"],
						desc = L["colShieldBlock"],
						get = "getShieldBlockColour",
						set = "setShieldBlockColour",
						hasAlpha = true,
						order = 12,
					},
					ShieldWall = {
						type = 'color',
						name = L["Shield Wall Colour"],
						desc = L["colShieldWall"],
						get = "getShieldWallColour",
						set = "setShieldWallColour",
						hasAlpha = true,
						order = 13,
					},
					demoshout = {
						type = 'color',
						name = L["Demoralizing Shout Colour"],
						desc = L["colDemoShout"],
						get = "getDemoShoutColour",
						set = "setDemoShoutColour",
						hasAlpha = true,
						order = 13,
					},
					laststand = {
						type = 'color',
						name = L["Last Stand Colour"],
						desc = L["colLastStand"],
						get = "getLastStandColour",
						set = "setLastStandColour",
						hasAlpha = true,
						order = 13,
					},
				},
			},
			priority = {
				name = L["Priority Frame"],
				type = 'group',
				order = 4, 
				args = {
					priority = {
						type = 'toggle',
						name = L["Priority Frame"],
						desc = L["help_priority"],
						get = "priorityQuery",
						set = "ActivatePriority",
						order = 40,
					},

--					combopoints = {
--						type = 'toggle',
--						name = L["Combo Points"],
--						desc = L["help_combopoints"],
--						get = "combopointsQuery",
--						set = "ActivateComboPoints",
--						order = 23,
--					},
					priorityscale = {
						type = 'range',
						name = L["Priority Bar Scale"],
						desc = L["help_priority_scale"],
						min = 0.50,
						max = 2.00,
						step = 0.01,
						get = "GetPriorityScale",
						set = "SetPriorityScale",
						order = 41,
					},
					heroicstrike = {
						type = 'toggle',
						name = SlamAndAwe.constants["Heroic Strike"],
						desc = L["help_heroicstrike"],
						get = "heroicstrikeQuery",
						set = "ActivateHeroicStrike",
						order = 44,
					},
					rage = {
						type = 'range',
						name = L["HS Rage Threshold"],
						desc = L["help_hsrage"],
						min = 1,
						max = 120,
						step = 1,
						get = "GetRageThreshold",
						set = "SetRageThreshold",
						order = 45,
					},
					showcooldown = {
						type = 'toggle',
						name = L["Show Cooldown"],
						desc = L["help_showcooldown"],
						get = "showcooldownQuery",
						set = "ActivateShowCooldown",
						order = 42,
					},
					cooldown = {
						type = 'range',
						name = L["Cooldown Threshold"],
						desc = L["help_cooldown"],
						min = 0,
						max = 1.5,
						step = 0.05,
						get = "GetCooldownThreshold",
						set = "SetCooldownThreshold",
						order = 43,
					},
					title = {
						type = 'toggle',
						name = L["Display frame title"],
						get = "priorityTitleQuery",
						set = "ActivatePriorityTitle",
						order = 46,
					},
					threat = {
						type = 'range',
						name = L["Threat Threshold"],
						desc = L["help_threat"],
						min = 75,
						max = 110,
						step = 1,
						get = "GetThreatThreshold",
						set = "SetThreatThreshold",
				   	guiHidden = true,					
						order = 47,
					},
					showinterrupt = {
						type = 'toggle',
						name = L["Show Interrupt"],
						desc = L["help_showinterrupt"],
						get = "showinterruptQuery",
						set = "ActivateShowInterrupt",
						order = 48,
					},
				},
			},
			announcer = {
				name = L["Announcer"],
				type = 'group',
				order = 5,
				args = {
					announcer_b1 = {
						type = 'header',
						name = L["Banners"],
						order = 1,
					},		
					announceskullbanner = {
						type = 'toggle',
						name = L["Skull Banner"],
						desc = L["help_skull_banner"],
						get = "SkullBannerAnnounceQuery",
						set = "ActivateAnnounceSkullBanner",
						order = 2,
					},					
					announceskullbannerwhere = {
						type = 'select',
						name = L["Output Location"],
						get = "GetSkullBannerAnnounceLocation",
						set = "SetSkullBannerAnnounceLocation",
						values = { L["SAY"], L["YELL"], L["PARTY"], L["RAID"] },
						order = 3,
					},					
					announcedemoralizingbanner = {
						type = 'toggle',
						name = L["Demoralizing Banner"],
						desc = L["help_demoralizing_banner"],
						get = "DemoralizingBannerAnnounceQuery",
						set = "ActivateAnnounceDemoralizingBanner",
						order = 5,
					},					
					announcedemoralizingbannerwhere = {
						type = 'select',
						name = L["Output Location"],
						get = "GetDemoralizingBannerAnnounceLocation",
						set = "SetDemoralizingBannerAnnounceLocation",
						values = { L["SAY"], L["YELL"], L["PARTY"], L["RAID"] },
						order = 6,
					},
					announcemockingbanner = {
						type = 'toggle',
						name = L["Mocking Banner"],
						desc = L["help_mocking_banner"],
						get = "MockingBannerAnnounceQuery",
						set = "ActivateAnnounceMockingBanner",
						order = 8,
					},					
					announcemockingbannerwhere = {
            type = 'select',
						name = L["Output Location"],
						get = "GetMockingBannerAnnounceLocation",
						set = "SetMockingBannerAnnounceLocation",
						values = { L["SAY"], L["YELL"], L["PARTY"], L["RAID"] },
						order = 9,
					},
	--				announcer_b2 = {
	--					type = 'header',
	--					name = L["Cooldowns"],
	--					order = 10,
	--				},
					announcer_b3 = {
						type = 'header',
						name = L["Misc"],
						order = 11,
					},					
					announceinterrupt = {
						type = 'toggle',
						name = L["Spell Interrupts"],
						desc = L["help_announce_interrupt"],
						get = "InterruptAnnounceQuery",
						set = "ActivateAnnounceInterrupt",
						order = 12,
					},	
					announceinterruptwhere = {
						type = 'select',
						name = L["Output Location"],
						get = "GetInterruptAnnounceLocation",
						set = "SetInterruptAnnounceLocation",
						values = { L["SAY"], L["YELL"], L["PARTY"], L["RAID"] },
						order = 13,
					},					
				},			
			},
			warning = {
				name = L["Warning Options"],
				type = 'group',
				order = 6, 
				args = {
					show = {
						type = 'toggle',
						name = L["Use Warning Frame"],
						desc = L["help_warningframe"],
						get = "WarningFrameQuery",
						set = "ActivateWarningFrame",
						order = 60,
					},

					range = {
						type = 'toggle',
						name = L["Out of range"],
						desc = L["help_outofrange"],
						get = "rangeWarnQuery",
						set = "ActivateRangeWarn",
						order = 61,
					},
					interrupt = {
						type = 'toggle',
						name = L["Interrupt Warning"],
						desc = L["help_interruptwarning"],
						get = "interruptWarnQuery",
						set = "ActivateInterruptWarn",
						order = 62,
					},
					colour = {
						type = 'color',
						name = L["Warning Msg Colour"],
						desc = L["colWarningMessage"],
						get = "getWarningColour",
						set = "setWarningColour",
						hasAlpha = true,
						order = 63,
					},
					duration = {
						type = 'range',
						name = L["Warning Message Duration"],
						min = 1,
						max = 10,
						step = .2,
						get = "GetWarningDuration",
						set = "SetWarningDuration",
						order = 64,
					},
--~					msbt = {
--~						type = 'select',
--~						name = L["MSBT output area"],
--~						get = "GetMSBTareas",
--~						set = "SetMSBTareas",
--~						values = SlamAndAwe.MSBT.areas,
--~						order = 12,
--~					},
--~ 					rebuff = {
--~ 						type = 'range',
--~ 						name = L["Weapon Rebuff time"],
--~ 						desc = L["help_weaponrebuff"],
--~ 						min = 0,
--~ 						max = 900,
--~ 						step = 10,
--~ 						get = "GetRebuffTime",
--~ 						set = "SetRebuffTime",
--~ 						order = 6,
--~ 					},
				},
			},
			media = {
				name = L["Media Options"],
				type = 'group',
				order = 8,
				args = {
					m_break1 = {
						type = 'header',
						name = L["Bar Media"],
						order = 1,
					},		
					texture = {
						type = 'select',
						name = L["Bar Texture"],
						get = "GetBarTexture",
						set = "SetBarTexture",
						values = SlamAndAwe.textures,
						order = 2,
					},
					barborder = {
						type = 'select',
						name = L["Bar Border Texture"],
						get = "GetBarBorderTexture",
						set = "SetBarBorderTexture",
						values = SlamAndAwe.borders,
						order = 3,
					},
					enableDisableBorder = {
						type = 'toggle',
						name = L["Disable Borders"],
						desc = L["help_enableDisableBorder"],
						get = "enableDisableBorderQuery",
						set = "ActivateEnableDisableBorder",
						order = 7,
					},
					barfont = {
						type = 'select',
						name = L["Bar Font"],
						get = "GetBarFont",
						set = "SetBarFont",
						values = SlamAndAwe.fonts,
						order = 4,
					},
					barfonteffect = {
						name = L["Bar Font Effect"],
						type = "select",
						get = "GetBarFontEffect",
						set = "SetBarFontEffect",
						values = SlamAndAwe.fonteffects,
						order = 5,
					},
					barfontsize = {
						type = 'range',
						name = L["Bar Font Size"],
						min = 6,
						max = 32,
						step = 1,
						get = "GetBarFontSize",
						set = "SetBarFontSize",
						order = 6,
					},
	
					m_break2 = {
						type = 'header',
						name = L["Warning Message Media"],
						order = 8,
					},		
					msgfont = {
						type = 'select',
						name = L["Message Font"],
						get = "GetMsgFont",
						set = "SetMsgFont",
						values = SlamAndAwe.fonts,
						order = 9,
					},
					msgfonteffect = {
						name = L["Message Font Effect"],
						type = "select",
						get = "GetMsgFontEffect",
						set = "SetMsgFontEffect",
						values = SlamAndAwe.fonteffects,
						order = 10,
					},
					msgfontsize = {
						type = 'range',
						name = L["Message Font Size"],
						min = 6,
						max = 32,
						step = 1,
						get = "GetMsgFontSize",
						set = "SetMsgFontSize",
						order = 11,
					},
				},
			},
			uptime = {
				name = L["Uptime Frame"],
				type = 'group',
				order = 8,
				args = {
					break1 = {
						type = 'header',
						name = L["Bar Colours"],
						dialogHidden = true,
						order = 80,
					},
					flurry = {
						type = 'color',
						name = L["Flurry Colour"],
						desc = L["colFlurry"],
						get = "getFlurryColour",
						set = "setFlurryColour",
						hasAlpha = true,
						order = 81,
					},					
					en = {
						type = 'color',
						name = L["Enrage Colour"],
						desc = L["colEN"],
						get = "getENColour",
						set = "setENColour",
						hasAlpha = true,
						order = 82,
					},					
					break2 = {
						type = 'header',
						name = L["Misc Options"],
						dialogHidden = true,
						order = 83,
					},
					show = {
						type = 'toggle',
						name = L["Show Frame"],
						desc = L["help_showuptime"],
						get = "showUptimeQuery",
						set = "ActivateShowUptime",
						order = 84,
					},
					resetsession = {
						type = 'execute',
						name = L["Reset Session info"],
						desc = L["help_reset"],
						func = "InitialiseUptime",
						order = 85,
					},			
				},			
			},
			debug = {
				type = 'toggle',
				name = L["Debug mode"],
				desc = L["help_debug"],
				get = "debugQuery",
				set = "ActivateDebug",
				order = 99,
			},
			moveframes = {
				type = 'toggle',
				name = L["Move Frames"],
				desc = L["help_display"],
				get = "MovingFramesQuery",
				set = "ShowHideBars",
				order = 100,
			},
		--	specchangewarning = {
		--				type = 'toggle',
		--				name = L["Warn on Spec Change"],
		--				desc = L["help_specchangewarning"],
		--				get = "specchangewarningQuery",
		--				set = "Activatespecchangewarning",
		--				order = 92,
		--			},
			enable = {
				type = 'execute',
				name = L["Enable/Disable"],
				desc = L["help_disable"],
				func = "EnableDisable",
				order = 98,
			},
			disable = {
				type = 'execute',
				name = L["Enable/Disable"],
				desc = L["help_disable"],
				func = "EnableDisable",
				guiHidden = true,
				order = 99,
			},

			enableProtSpec = {
				type = 'toggle',
				name = L["Enable Addon - Prot"],
				desc = L["help_enableProtSpec"],
				get = "enableProtSpecQuery",
				set = "ActivateProtSpec",
				order = 94,
			},
			enableArmsSpec = {
				type = 'toggle',
				name = L["Enable Addon - Arms"],
				desc = L["help_enableArmsSpec"],
				get = "enableArmsSpecQuery",
				set = "ActivateArmsSpec",
				order = 92,
			},			
			enableFurySpec = {
				type = 'toggle',
				name = L["Enable Addon - Fury"],
				desc = L["help_enableFurySpec"],
				get = "enableFurySpecQuery",
				set = "ActivateFurySpec",
				order = 93,
			},
			config = {
				type = 'execute',
				name = L["Configure Options"],
				desc = L["help_config"],
				func = "OpenConfig",	
				guiHidden = true,						
				order = 95,
			},
			version = {
				type = 'execute',
				name = L["Version"],
				desc = L["help_version"],
				func = "DisplayVersion",
				order = 96,
				guiHidden = true,
			},
			help = {
				type = 'description',
				name = L["help"],
				guiHidden = true,
				order = 97,
			},
			priorities = { 
				name = L["Set Priorities"],
				type='group',
				childGroups ='tree',
				order = 5,
				args = {			
					prioritygroup = {
						type = 'select',
						name = L["Priority Group"],
						get = "GetPriorityGroup",
						set = "SetPriorityGroup",
						values = { L["Priority Group One"],  L["Priority Group Two"], L["Priority Group Three"], L["Priority Group Four"], L["Priority Group Five"] },
						order = 100,
					},
					priority1 = {
						type = 'select',
						name = L["First Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(1),
						set = SlamAndAwe:SetPriority(1),
						values = SlamAndAwe.priorityTable.name,
						order = 101,
					},
					priority2 = {
						type = 'select',
						name = L["Second Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(2),
						set = SlamAndAwe:SetPriority(2),
						values = SlamAndAwe.priorityTable.name,
						order = 102,
					},
					priority3 = {
						type = 'select',
						name = L["Third Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(3),
						set = SlamAndAwe:SetPriority(3),
						values = SlamAndAwe.priorityTable.name,
						order = 103,
					},
					priority4 = {
						type = 'select',
						name = L["Fourth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(4),
						set = SlamAndAwe:SetPriority(4),
						values = SlamAndAwe.priorityTable.name,
						order = 104,
					},
					priority5 = {
						type = 'select',
						name = L["Fifth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(5),
						set = SlamAndAwe:SetPriority(5),
						values = SlamAndAwe.priorityTable.name,
						order = 105,
					},
					priority6 = {
						type = 'select',
						name = L["Sixth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(6),
						set = SlamAndAwe:SetPriority(6),
						values = SlamAndAwe.priorityTable.name,
						order = 106,
					},
					priority7 = {
						type = 'select',
						name = L["Seventh Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(7),
						set = SlamAndAwe:SetPriority(7),
						values = SlamAndAwe.priorityTable.name,
						order = 107,
					},
					priority8 = {
						type = 'select',
						name = L["Eighth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(8),
						set = SlamAndAwe:SetPriority(8),
						values = SlamAndAwe.priorityTable.name,
						order = 108,
					},
					priority9 = {
						type = 'select',
						name = L["Ninth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(9),
						set = SlamAndAwe:SetPriority(9),
						values = SlamAndAwe.priorityTable.name,
						order = 109,
					},
					priority10 = {
						type = 'select',
						name = L["Tenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(10),
						set = SlamAndAwe:SetPriority(10),
						values = SlamAndAwe.priorityTable.name,
						order = 110,
					},
					priority11 = {
						type = 'select',
						name = L["Eleventh Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(11),
						set = SlamAndAwe:SetPriority(11),
						values = SlamAndAwe.priorityTable.name,
						order = 111,
					},
					priority12 = {
						type = 'select',
						name = L["Twelfth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(12),
						set = SlamAndAwe:SetPriority(12),
						values = SlamAndAwe.priorityTable.name,
						order = 112,
					},
					priority13 = {
						type = 'select',
						name = L["Thirteenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(13),
						set = SlamAndAwe:SetPriority(13),
						values = SlamAndAwe.priorityTable.name,
						order = 113,
					},
					priority14 = {
						type = 'select',
						name = L["Fourteenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(14),
						set = SlamAndAwe:SetPriority(14),
						values = SlamAndAwe.priorityTable.name,
						order = 114,
					},
					priority15 = {
						type = 'select',
						name = L["Fifteenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(15),
						set = SlamAndAwe:SetPriority(15),
						values = SlamAndAwe.priorityTable.name,
						order = 115,
					},
					priority16 = {
						type = 'select',
						name = L["Sixteenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(16),
						set = SlamAndAwe:SetPriority(16),
						values = SlamAndAwe.priorityTable.name,
						order = 116,
					},
					priority17 = {
						type = 'select',
						name = L["Seventeenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(17),
						set = SlamAndAwe:SetPriority(17),
						values = SlamAndAwe.priorityTable.name,
						order = 117,
					},
					priority18 = {
						type = 'select',
						name = L["Eighteenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(18),
						set = SlamAndAwe:SetPriority(18),
						values = SlamAndAwe.priorityTable.name,
						order = 118,
					},
					priority19 = {
						type = 'select',
						name = L["Nineteenth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(19),
						set = SlamAndAwe:SetPriority(19),
						values = SlamAndAwe.priorityTable.name,
						order = 119,
					},	
					priority20 = {
						type = 'select',
						name = L["Twentieth Priority"],
						width = 'full',						
						get = SlamAndAwe:GetPriority(20),
						set = SlamAndAwe:SetPriority(20),
						values = SlamAndAwe.priorityTable.name,
						order = 120,
					},																			
				}
			}
		}
	}
	return options
end

function SlamAndAwe:ActivateShear()
	SlamAndAwe.db.char.shearshow = not SlamAndAwe.db.char.shearshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.shearshow) then
		SlamAndAwe:Print(L["config_Shear_on"])
	else
		SlamAndAwe:Print(L["config_Shear_off"])
	end
end

function SlamAndAwe:ActivateShowUptime()
	SlamAndAwe.db.char.uptime.show = not SlamAndAwe.db.char.uptime.show
	if (SlamAndAwe.db.char.uptime.show) and not SlamAndAwe.db.char.disabled then
		SlamAndAwe.UptimeFrame:Show()
		SlamAndAwe:Print(L["config_Uptime_on"])
	else
		SlamAndAwe.UptimeFrame:Hide()
		SlamAndAwe:Print(L["config_Uptime_off"])
	end
end

function SlamAndAwe:ActivateTasteForBlood()
	SlamAndAwe.db.char.tfbshow = not SlamAndAwe.db.char.tfbshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.tfbshow) then
		SlamAndAwe:Print(L["config_tfb_on"])
	else
		SlamAndAwe:Print(L["config_tfb_off"])
	end
end

function SlamAndAwe:ActivateColossusSmash()
	SlamAndAwe.db.char.csshow = not SlamAndAwe.db.char.csshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.csshow) then
		SlamAndAwe:Print(L["config_CS_on"])
	else
		SlamAndAwe.frames["ColossusSmash"]:Hide()
		SlamAndAwe:Print(L["config_CS_off"])
	end
end

function SlamAndAwe:ActivateSweepingStrikes()
	SlamAndAwe.db.char.swstshow = not SlamAndAwe.db.char.swstshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.swstshow) then
		SlamAndAwe:Print(L["config_SWST_on"])
	else
		SlamAndAwe.frames["SweepingStrikes"]:Hide()
		SlamAndAwe:Print(L["config_SWST_off"])
	end
end

function SlamAndAwe:ActivateDeadlyCalm()
	SlamAndAwe.db.char.dcshow = not SlamAndAwe.db.char.dcshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.dcshow) then
		SlamAndAwe:Print(L["config_DC_on"])
	else
		SlamAndAwe.frames["DeadlyCalm"]:Hide()
		SlamAndAwe:Print(L["config_DC_off"])
	end
end

function SlamAndAwe:ActivateRecklessness()
	SlamAndAwe.db.char.reshow = not SlamAndAwe.db.char.reshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.reshow) then
		SlamAndAwe:Print(L["config_RE_on"])
	else
		SlamAndAwe.frames["Recklessness"]:Hide()
		SlamAndAwe:Print(L["config_RE_off"])
	end
end

function SlamAndAwe:ActivateShieldBlock()
	SlamAndAwe.db.char.sblshow = not SlamAndAwe.db.char.sblshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.sblshow) then
		SlamAndAwe:Print(L["config_SBl_on"])
	else
		SlamAndAwe.frames["ShieldBlock"]:Hide()
		SlamAndAwe:Print(L["config_SBl_off"])
	end
end

function SlamAndAwe:ActivateShieldWall()
	SlamAndAwe.db.char.swshow = not SlamAndAwe.db.char.swshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.swshow) then
		SlamAndAwe:Print(L["config_SW_on"])
	else
		SlamAndAwe.frames["ShieldWall"]:Hide()
		SlamAndAwe:Print(L["config_SW_off"])
	end
end

function SlamAndAwe:ActivateLastStand()
	SlamAndAwe.db.char.laststandshow = not SlamAndAwe.db.char.laststandshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.laststandshow) then
		SlamAndAwe:Print(L["config_LS_on"])
	else
		SlamAndAwe.frames["LastStand"]:Hide()
		SlamAndAwe:Print(L["config_LS_off"])
	end
end
function SlamAndAwe:ActivateRallyingCry()
	SlamAndAwe.db.char.rallyingcryshow = not SlamAndAwe.db.char.rallyingcryshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.rallyingcryshow) then
		SlamAndAwe:Print(L["config_RC_on"])
	else
		SlamAndAwe.frames["RallyingCry"]:Hide()
		SlamAndAwe:Print(L["config_RC_off"])
	end
end
function SlamAndAwe:ActivateRallyingCry()
	SlamAndAwe.db.char.rallyingcryshow = not SlamAndAwe.db.char.rallyingcryshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.rallyingcryshow) then
		SlamAndAwe:Print(L["config_RC_on"])
	else
		SlamAndAwe.frames["RallyingCry"]:Hide()
		SlamAndAwe:Print(L["config_RC_off"])
	end
end
function SlamAndAwe:ActivateDemoShout() 
	SlamAndAwe.db.char.demoshoutshow = not SlamAndAwe.db.char.demoshoutshow 
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.demoshoutshow) then
		SlamAndAwe:Print(L["config_DS_on"]) 
	else
		SlamAndAwe.frames["DemoShout"]:Hide() 
	SlamAndAwe:Print(L["config_DS_off"]) end
end


function SlamAndAwe:ActivateShieldBarrier()
	SlamAndAwe.db.char.sbshow = not SlamAndAwe.db.char.sbshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.sbshow) then
		SlamAndAwe:Print(L["config_SB_on"])
	else
		SlamAndAwe.frames["ShieldBarrier"]:Hide()
		SlamAndAwe:Print(L["config_SB_off"])
	end
end

function SlamAndAwe:ActivateGCD()
	SlamAndAwe.db.char.gcdshow = not SlamAndAwe.db.char.gcdshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.gcdshow) then
		SlamAndAwe.frames["GCD"]:Show()
		SlamAndAwe:Print(L["config_GCD_on"])
	else
		SlamAndAwe.frames["GCD"]:Hide()
		SlamAndAwe:Print(L["config_GCD_off"])
	end
end

function SlamAndAwe:ActivateRage()
	SlamAndAwe.db.char.rageshow = not SlamAndAwe.db.char.rageshow
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.rageshow) then
		SlamAndAwe:RageBar()
		SlamAndAwe:Print(L["config_RageBar_on"])
	else
		SlamAndAwe.frames["Rage"]:Hide()
		SlamAndAwe:Print(L["config_RageBar_off"])
	end
end

function SlamAndAwe:ActivateGCDfullwidth()
	SlamAndAwe.db.char.gcdfullwidth = not SlamAndAwe.db.char.gcdfullwidth
	SlamAndAwe:SetTalentEffects()
	SlamAndAwe:CreateBaseFrame()
	if (SlamAndAwe.db.char.gcdfullwidth) then
		SlamAndAwe:Print(L["config_GCD_fullwidth_on"])
	else
		SlamAndAwe:Print(L["config_GCD_fullwidth_off"])
	end
end

function SlamAndAwe:Activatedisablebars()
	SlamAndAwe.db.char.disablebars = not SlamAndAwe.db.char.disablebars
	if (SlamAndAwe.db.char.disablebars) then
		if not InCombatLockdown() then
      if SlamAndAwe.db.char.rageshow then
        SlamAndAwe:RageBar()
      else
        SlamAndAwe.BaseFrame:Hide()
      end
		end
		SlamAndAwe:Print(L["config_disable_on"])
	else
		SlamAndAwe.BaseFrame:Show()
		SlamAndAwe:Print(L["config_disable_off"])
	end
end

function SlamAndAwe:ActivateBarIcons()
	SlamAndAwe.db.char.showicons = not SlamAndAwe.db.char.showicons
	if (SlamAndAwe.db.char.showicons) then
		SlamAndAwe:Print(L["config_baricons_on"])
	else
		SlamAndAwe:Print(L["config_baricons_off"])
	end
end

function SlamAndAwe:ActivateDebug()
	SlamAndAwe.db.char.debug = not SlamAndAwe.db.char.debug
	if (SlamAndAwe.db.char.debug) then
		SlamAndAwe:Print(L["config_debug_on"])
	else
		SlamAndAwe:Print(L["config_debug_off"])
	end
end

function SlamAndAwe:Activatespecchangewarning()
	SlamAndAwe.db.char.specchangewarning = not SlamAndAwe.db.char.specchangewarning
	if (SlamAndAwe.db.char.specchangewarning) then
		SlamAndAwe:Print(L["config_specchangewarning_on"])
	else
		SlamAndAwe:Print(L["config_specchangewarning_off"])
	end
end

function SlamAndAwe:ActivateHeroicStrike()
	SlamAndAwe.db.char.hsshow = not SlamAndAwe.db.char.hsshow
	if (SlamAndAwe.db.char.hsshow) then
		SlamAndAwe:Print(L["config_HS_on"])
	else
		SlamAndAwe:Print(L["config_HS_off"])
	end
end

function SlamAndAwe:ActivateHideImmune()
	SlamAndAwe.db.char.priority.hideImmune = not SlamAndAwe.db.char.priority.hideImmune
	if (SlamAndAwe.db.char.priority.hideImmune) then
		SlamAndAwe:Print(L["config_hideimmune_on"])
	else
		SlamAndAwe:Print(L["config_hideimmune_off"])
	end
end



function SlamAndAwe:ActivateShowInterrupt()
	SlamAndAwe.db.char.priority.showinterrupt = not SlamAndAwe.db.char.priority.showinterrupt
	if (SlamAndAwe.db.char.priority.showinterrupt) then
		--SlamAndAwe.PriorityFrame.interrupt.frame:Show()
		SlamAndAwe:Print(L["config_showinterrupt_on"])
	else
		--SlamAndAwe.PriorityFrame.interrupt.frame:Hide()
		SlamAndAwe:Print(L["config_showinterrupt_off"])
	end
end

function SlamAndAwe:ActivateShowPurge()
	SlamAndAwe.db.char.hsshow = not SlamAndAwe.db.char.hsshow
	if (SlamAndAwe.db.char.hsshow) then
		SlamAndAwe.PriorityFrame.purge.frame:Show()
		SlamAndAwe:Print(L["config_showpurge_on"])
	else
		SlamAndAwe.PriorityFrame.purge.frame:Hide()
		SlamAndAwe:Print(L["config_showpurge_off"])
	end
end

function SlamAndAwe:ActivateShowCooldown()
	SlamAndAwe.db.char.priority.showcooldown = not SlamAndAwe.db.char.priority.showcooldown
	if (SlamAndAwe.db.char.priority.showcooldown) then
		SlamAndAwe:Print(L["config_showcooldown_on"])
	else
		SlamAndAwe:Print(L["config_showcooldown_off"])
	end
end

function SlamAndAwe:ActivateTextOnBars()
	SlamAndAwe.db.char.barstext = not SlamAndAwe.db.char.barstext
	if (SlamAndAwe.db.char.barstext) then
		SlamAndAwe:Print(L["config_Barstext_on"])
	else
		SlamAndAwe:Print(L["config_Barstext_off"])
	end
end

function SlamAndAwe:ActivateEnableTimeRemaining()
	SlamAndAwe.db.char.enableTimeRemaining = not SlamAndAwe.db.char.enableTimeRemaining
	if (SlamAndAwe.db.char.enableTimeRemaining) then
		SlamAndAwe:Print(L["config_enableTimeRemaining_on"])
	else
		SlamAndAwe:Print(L["config_enableTimeRemaining_off"])
	end
end

function SlamAndAwe:ActivateHideRageBarOOC()
	SlamAndAwe.db.char.hideRageBarOOC = not SlamAndAwe.db.char.hideRageBarOOC
	if (SlamAndAwe.db.char.hideRageBarOOC) then
		SlamAndAwe:Print(L["config_hideRageBarOOC_on"])
		SlamAndAwe:RageBar()
	else
		SlamAndAwe:Print(L["config_hideRageBarOOC_off"])
		SlamAndAwe:RageBar()
	end
end

function SlamAndAwe:ActivateProtSpec()
 local currentSpec = GetSpecialization()
	SlamAndAwe.db.char.enableProtSpec = not SlamAndAwe.db.char.enableProtSpec
	if (SlamAndAwe.db.char.enableProtSpec) then
		SlamAndAwe:Print(L["config_enableProtSpec_on"])
		if SlamAndAwe.db.char.disabled and currentSpec == 3  then
			SlamAndAwe:Enable()
		end
	else
		SlamAndAwe:Print(L["config_enableProtSpec_off"])
		if SlamAndAwe.db.char.disabled == false and currentSpec == 3  then
			SlamAndAwe:Disable()
		end
	end
end

function SlamAndAwe:ActivateFurySpec()
 local currentSpec = GetSpecialization()
	SlamAndAwe.db.char.enableFurySpec = not SlamAndAwe.db.char.enableFurySpec
	if (SlamAndAwe.db.char.enableFurySpec) then
		SlamAndAwe:Print(L["config_enableFurySpec_on"])
		if SlamAndAwe.db.char.disabled  and currentSpec == 2 then
		SlamAndAwe:Enable()
		end
	else
		SlamAndAwe:Print(L["config_enableFurySpec_off"])
				if SlamAndAwe.db.char.disabled == false  and currentSpec == 2 then
				SlamAndAwe:Disable()
		end
	end
end

function SlamAndAwe:ActivateArmsSpec()
 local currentSpec = GetSpecialization()
	SlamAndAwe.db.char.enableArmsSpec = not SlamAndAwe.db.char.enableArmsSpec
	if (SlamAndAwe.db.char.enableArmsSpec) then
		SlamAndAwe:Print(L["config_enableArmsSpec_on"])
		if SlamAndAwe.db.char.disabled and currentSpec ==  1 then
		SlamAndAwe:Enable()
		end
	else
		SlamAndAwe:Print(L["config_enableArmsSpec_off"])
				if not SlamAndAwe.db.char.disabled and currentSpec == 1  then
				SlamAndAwe:Disable()
		end
	end
end

function SlamAndAwe:ShowHideBars()
	if InCombatLockdown() then
		SlamAndAwe:Print(L["Cannot move frames in combat"])
		return
	end
	SlamAndAwe.db.char.movingframes = not SlamAndAwe.db.char.movingframes
	if SlamAndAwe.db.char.movingframes then
		SlamAndAwe.PriorityFrame:EnableMouse(1)
		SlamAndAwe.PriorityFrame:SetBackdropColor(0, 0, 0, 1)
		SlamAndAwe.PriorityFrame:Show()
		SlamAndAwe.UptimeFrame:EnableMouse(1)
		SlamAndAwe.UptimeFrame:SetBackdropColor(0, 0, 0, 1)
		SlamAndAwe.UptimeFrame:Show()
		SlamAndAwe.msgFrame:EnableMouse(1)
		SlamAndAwe.msgFrame:SetBackdropColor(0, 0, 0, 1)
		SlamAndAwe.msgFrame:Show()
		SlamAndAwe.BaseFrame:EnableMouse(1)
		SlamAndAwe.BaseFrame:SetBackdropColor(0, 0, 0, 1);
		SlamAndAwe.frames["GCD"]:Show()
		SlamAndAwe.UptimeFrame:Show()
		SlamAndAwe:RageBar()
		
		--  All specs have these
		SlamAndAwe:RecklessnessBar()
		SlamAndAwe:DeadlyCalmBar()
		SlamAndAwe:RallyingCryBar()

    if SlamAndAwe.db.char.currentspec == "Fury" then
      SlamAndAwe:ColossusSmashBar()
    elseif SlamAndAwe.db.char.currentspec == "Protection" then
     -- SlamAndAwe:ShieldBarrierBar()  -- Don't show this since it isn't timer based and will get stuck.
      SlamAndAwe:ShieldBlockBar()
      SlamAndAwe:ShieldWallBar()
	   SlamAndAwe:DemoShoutBar()
	   SlamAndAwe:LastStandBar()
    elseif SlamAndAwe.db.char.currentspec == "Arms" then
      SlamAndAwe:ColossusSmashBar()
      SlamAndAwe:SweepingStrikesBar()  
		end
	else
		SlamAndAwe.PriorityFrame:EnableMouse(0);
		SlamAndAwe.PriorityFrame:SetBackdropColor(1, 1, 1, 0);
		SlamAndAwe.BaseFrame:EnableMouse(0);
		SlamAndAwe.BaseFrame:SetBackdropColor(1, 1, 1, 0);
		SlamAndAwe.UptimeFrame:EnableMouse(0)
		SlamAndAwe.UptimeFrame:SetBackdropColor(0, 0, 0, 0.3);
		SlamAndAwe.msgFrame:EnableMouse(0)
		SlamAndAwe.msgFrame:SetBackdropColor(1, 1, 1, 0);
		-- SlamAndAwe.BaseFrame:Hide()
		SlamAndAwe.frames["GCD"]:Hide()
		if SlamAndAwe.db.char.priority.show and InCombatLockdown() then
			SlamAndAwe.PriorityFrame:Show()
		else
			SlamAndAwe.PriorityFrame:Hide()
		end
		if SlamAndAwe.db.char.uptime.show and not SlamAndAwe.db.char.disabled then
			SlamAndAwe.UptimeFrame:Show()
		else
			SlamAndAwe.UptimeFrame:Hide()
		end
		
		SlamAndAwe:RageBar()
	end
	SlamAndAwe:SetPriorityUpdateScript()
end

function SlamAndAwe:FinishedMoving(var, frame)
	local point, relativeTo, relativePoint, xOffset, yOffset = frame:GetPoint();
	var.point = point
	var.relativeTo = relativeTo
	var.relativePoint = relativePoint
	var.xOffset = xOffset
	var.yOffset = yOffset
end

function SlamAndAwe:MovingFramesQuery()
	return SlamAndAwe.db.char.movingframes
end

function SlamAndAwe:enableProtSpecQuery()
	return SlamAndAwe.db.char.enableProtSpec
end

function SlamAndAwe:enableFurySpecQuery()
	return SlamAndAwe.db.char.enableFurySpec
end

function SlamAndAwe:enableArmsSpecQuery()
	return SlamAndAwe.db.char.enableArmsSpec
end

function SlamAndAwe:PetFrameQuery()
	return SlamAndAwe.db.char.petframeshow
end

function SlamAndAwe:SSQuery()
	return SlamAndAwe.db.char.ssshow
end

function SlamAndAwe:FireTotemQuery()
	return SlamAndAwe.db.char.firetotemshow
end

function SlamAndAwe:WFQuery()
	return SlamAndAwe.db.char.wfshow
end

function SlamAndAwe:shockQuery()
	return SlamAndAwe.db.char.shockshow
end

function SlamAndAwe:fsdotbarQuery()
	return SlamAndAwe.db.char.fsdotshow
end

function SlamAndAwe:shearQuery()
	return SlamAndAwe.db.char.shearshow
end

function SlamAndAwe:gcdQuery()
	return SlamAndAwe.db.char.gcdshow
end

function SlamAndAwe:gcdFullwidthQuery()
	return SlamAndAwe.db.char.gcdfullwidth
end

function SlamAndAwe:heroicstrikeQuery()
	return SlamAndAwe.db.char.hsshow
end

--function SlamAndAwe:combopointsQuery()
--	return SlamAndAwe.db.char.priority.combopoints
--end

function SlamAndAwe:worldbossQuery()
	return SlamAndAwe.db.char.priority.worldbossonly
end

function SlamAndAwe:hideImmuneQuery()
	return SlamAndAwe.db.char.priority.hideImmune
end

function SlamAndAwe:showinterruptQuery()
	return SlamAndAwe.db.char.priority.showinterrupt
end

function SlamAndAwe:showpurgeQuery()
	return SlamAndAwe.db.char.hsshow
end

function SlamAndAwe:showcooldownQuery()
	return SlamAndAwe.db.char.priority.showcooldown
end

function SlamAndAwe:disablebarsQuery()
	return SlamAndAwe.db.char.disablebars
end

function SlamAndAwe:bariconsQuery()
	return SlamAndAwe.db.char.showicons
end

function SlamAndAwe:arenaQuery()
	return SlamAndAwe.db.char.arena
end

function SlamAndAwe:showUptimeQuery()
	return SlamAndAwe.db.char.uptime.show
end

function SlamAndAwe:tfbQuery()
	return SlamAndAwe.db.char.tfbshow
end

--SlamAndAwe
function SlamAndAwe:shieldbarrierQuery()
	return SlamAndAwe.db.char.sbshow
end

function SlamAndAwe:shieldblockQuery()
	return SlamAndAwe.db.char.sblshow
end

function SlamAndAwe:shieldwallQuery()
	return SlamAndAwe.db.char.swshow
end

function SlamAndAwe:lastStandQuery()
	return SlamAndAwe.db.char.laststandshow
end

function SlamAndAwe:rallyingCryQuery()
	return SlamAndAwe.db.char.rallyingcryshow
end

function SlamAndAwe:demoShoutQuery()
	return SlamAndAwe.db.char.demoshoutshow
end

function SlamAndAwe:enableTimeRemainingQuery()
	return SlamAndAwe.db.char.enableTimeRemaining
end

function SlamAndAwe:hideRageBarOOCQuery()
	return SlamAndAwe.db.char.hideRageBarOOC
end


function SlamAndAwe:colossussmashQuery()
	return SlamAndAwe.db.char.csshow
end

function SlamAndAwe:sweepingstrikesQuery()
	return SlamAndAwe.db.char.swstshow
end

function SlamAndAwe:deadlycalmQuery()
	return SlamAndAwe.db.char.dcshow
end

function SlamAndAwe:recklessnessQuery()
	return SlamAndAwe.db.char.reshow
end

function SlamAndAwe:ragebarQuery()
	return SlamAndAwe.db.char.rageshow
end

function SlamAndAwe:firenovaQuery()
	return SlamAndAwe.db.char.fnshow
end

function SlamAndAwe:textOnBarsQuery()
    return SlamAndAwe.db.char.barstext
end

function SlamAndAwe:mw5soundplayQuery()
    return SlamAndAwe.db.char.mw5soundplay
end

function SlamAndAwe:mw4soundplayQuery()
    return SlamAndAwe.db.char.mw4soundplay
end

function SlamAndAwe:mw5flashQuery()
    return SlamAndAwe.db.char.mw5flash
end

function SlamAndAwe:debugQuery()
	return SlamAndAwe.db.char.debug
end

function SlamAndAwe:specchangewarningQuery()
	return SlamAndAwe.db.char.specchangewarning
end

function SlamAndAwe:GetBarTexture()
    return SlamAndAwe.db.char.texture
end

function SlamAndAwe:GetBorderTexture()
    return SlamAndAwe.db.char.border
end

function SlamAndAwe:GetBarBorderTexture()
    return SlamAndAwe.db.char.barborder
end

function SlamAndAwe:GetBarFont()
    return SlamAndAwe.db.char.barfont
end

function SlamAndAwe:GetBarFontSize()
    return SlamAndAwe.db.char.barfontsize
end

function SlamAndAwe:GetBarFontEffect()
    return SlamAndAwe.db.char.barfonteffect
end

function SlamAndAwe:GetMsgFont()
    return SlamAndAwe.db.char.msgfont
end

function SlamAndAwe:GetMsgFontSize()
    return SlamAndAwe.db.char.msgfontsize
end

function SlamAndAwe:GetMsgFontEffect()
    return SlamAndAwe.db.char.msgfonteffect
end

function SlamAndAwe:GetWidth()
    return SlamAndAwe.db.char.fWidth
end

function SlamAndAwe:GetHeight()
    return SlamAndAwe.db.char.fHeight
end

function SlamAndAwe:GetScale()
    return SlamAndAwe.db.char.scale
end

function SlamAndAwe:GetPriorityScale()
    return SlamAndAwe.db.char.priority.scale
end

function SlamAndAwe:GetTFBalpha()
    return SlamAndAwe.db.char.colours.tfbalpha
end

function SlamAndAwe:GetTFBalphaFull()
    return SlamAndAwe.db.char.colours.tfbalphaFull
end

function SlamAndAwe:GetWeaponSound()
    return SlamAndAwe.db.char.weaponsoundname
end

function SlamAndAwe:Gettfb5sound()
    return SlamAndAwe.db.char.tfb5soundname
end

function SlamAndAwe:Gettfb5repeat()
    return SlamAndAwe.db.char.tfb5repeat
end

function SlamAndAwe:Gettfb4sound()
    return SlamAndAwe.db.char.tfb4soundname
end

function SlamAndAwe:GetThreatThreshold()
    return SlamAndAwe.db.char.threatThreshold
end

function SlamAndAwe:GetRageThreshold()
   return SlamAndAwe.db.char.rageThreshold
end

function SlamAndAwe:GetCooldownThreshold()
    return SlamAndAwe.db.char.priority.cooldown
end

function SlamAndAwe:GetTotemTimeLeft()
    return SlamAndAwe.db.char.priority.totemtimeleft
end

function SlamAndAwe:GetRebuffTime()
    return SlamAndAwe.db.char.warning.timeleft
end

function SlamAndAwe:GetShowWFTotals()
	return SlamAndAwe.db.char.stats.wfcalc
end

function SlamAndAwe:SetBarFont(info, newValue)
	SlamAndAwe.db.char.barfont = newValue
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:RageBar()
end

function SlamAndAwe:SetBarFontSize(info, newValue)
	SlamAndAwe.db.char.barfontsize = newValue
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:RageBar()
end

function SlamAndAwe:SetBarFontEffect(info, newValue)
	SlamAndAwe.db.char.barfonteffect = newValue
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:RageBar()
end

function SlamAndAwe:SetMsgFont(info, newValue)
	SlamAndAwe.db.char.msgfont = newValue
	SlamAndAwe:CreateMsgFrame()
end

function SlamAndAwe:SetMsgFontSize(info, newValue)
	SlamAndAwe.db.char.msgfontsize = newValue
	SlamAndAwe:CreateMsgFrame()
end

function SlamAndAwe:SetMsgFontEffect(info, newValue)
	SlamAndAwe.db.char.msgfonteffect = newValue
	SlamAndAwe:CreateMsgFrame()
end

function SlamAndAwe:SetBarTexture(info, newValue)
	SlamAndAwe.db.char.texture = newValue
	local barTexture = media:Fetch('statusbar', newValue)
	SlamAndAwe.frames["GCD"].statusbar:SetStatusBarTexture(barTexture)
	SlamAndAwe:RedrawFrames()
end

function SlamAndAwe:SetBorderTexture(info, newValue)
	SlamAndAwe.db.char.border = newValue
	local newTexture = media:Fetch("border", SlamAndAwe.db.char.border)
	if newTexture then
		SlamAndAwe.frameBackdrop.edgeFile = newTexture
		SlamAndAwe:RedrawFrames()
	else
		if SlamAndAwe.db.char.debug then
			SlamAndAwe:Print("border texture not found. Trying to set "..SlamAndAwe.db.char.border)
		end
	end
end

function SlamAndAwe:SetBarBorderTexture(info, newValue)
	SlamAndAwe.db.char.barborder = newValue
	local newTexture = media:Fetch("border", SlamAndAwe.db.char.barborder)
	if newTexture then
		SlamAndAwe.barBackdrop.edgeFile = newTexture
		SlamAndAwe.frames["GCD"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldBarrier"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldBlock"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldWall"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ColossusSmash"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["DeadlyCalm"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["Recklessness"]:SetBackdrop(SlamAndAwe.barBackdrop)		
		SlamAndAwe.frames["SweepingStrikes"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["DemoShout"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["LastStand"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["RallyingCry"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe:RedrawFrames()
	else
		if SlamAndAwe.db.char.debug then
			SlamAndAwe:Print("bar border texture not found. Trying to set "..SlamAndAwe.db.char.barborder)
		end
	end
end

function SlamAndAwe:SetWeaponSound(info, newValue)
	local newSound = media:Fetch("sound", newValue)
	SlamAndAwe.db.char.weaponsoundname = newValue
	if newSound then
		SlamAndAwe.db.char.weaponsound = newSound
		PlaySoundFile(newSound)
	else
		if SlamAndAwe.db.char.debug then
			SlamAndAwe:Print("Sound not found. Trying to set "..newSound)
		end
	end
end

function SlamAndAwe:SetMW5sound(info, newValue)
	local newSound = media:Fetch("sound", newValue)
	SlamAndAwe.db.char.mw5soundname = newValue
	if newSound then
		SlamAndAwe.db.char.mw5sound = newSound
		PlaySoundFile(newSound)
	else
		if SlamAndAwe.db.char.debug then
			SlamAndAwe:Print("Sound not found. Trying to set "..newSound)
		end
	end
end

function SlamAndAwe:SetMW5repeat(info, newValue)
	SlamAndAwe.db.char.mw5repeat = newValue
end

function SlamAndAwe:SetMW4sound(info, newValue)
	local newSound = media:Fetch("sound", newValue)
	SlamAndAwe.db.char.mw4soundname = newValue
	if newSound then
		SlamAndAwe.db.char.mw4sound = newSound
		PlaySoundFile(newSound)
	else
		if SlamAndAwe.db.char.debug then
			SlamAndAwe:Print("Sound not found. Trying to set "..newSound)
		end
	end
end

function SlamAndAwe:SetThreatThreshold(info, newValue)
	SlamAndAwe.db.char.threatThreshold = newValue
	SlamAndAwe:Print(L["config_Threat"]..newValue)
end

function SlamAndAwe:SetRageThreshold(info, newValue)
	SlamAndAwe.db.char.rageThreshold = newValue
	SlamAndAwe:Print(L["config_Rage"]..newValue)
end

function SlamAndAwe:SetCooldownThreshold(info, newValue)
	SlamAndAwe.db.char.priority.cooldown = newValue
	SlamAndAwe:Print(L["config_Cooldown"]..newValue)
end

function SlamAndAwe:SetRebuffTime(info, newValue)
	SlamAndAwe.db.char.warning.timeleft = newValue
end

function SlamAndAwe:SetWidth(info,newValue)
	if InCombatLockdown() then
		SlamAndAwe:Print(L["Cannot change bar width in combat"])
		return
	end
	local wasMoving = SlamAndAwe.db.char.movingframes
	SlamAndAwe.db.char.fWidth = newValue
	SlamAndAwe:RedrawFrames()
  SlamAndAwe:RageBar()
	if wasMoving then
		SlamAndAwe:ShowHideBars()
	end
	SlamAndAwe:DebugPrint(L["Frame width set to : "]..SlamAndAwe.db.char.fWidth)	
end

function SlamAndAwe:SetHeight(info,newValue)
	if InCombatLockdown() then
		SlamAndAwe:Print(L["Cannot change bar height in combat"])
		return
	end
	local wasMoving = SlamAndAwe.db.char.movingframes
	SlamAndAwe.db.char.fHeight = newValue
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:RageBar()
	if wasMoving then
		SlamAndAwe:ShowHideBars()
	end
	SlamAndAwe:DebugPrint(L["Frame height set to : "]..SlamAndAwe.db.char.fHeight)	
end

function SlamAndAwe:SetScale(info,newValue)
	if InCombatLockdown() then
		SlamAndAwe:Print(L["Cannot change scale in combat"])
		return
	end
	local wasMoving = SlamAndAwe.db.char.movingframes
	SlamAndAwe.db.char.scale = newValue
	SlamAndAwe.BaseFrame:SetScale(SlamAndAwe.db.char.scale)
	SlamAndAwe:RedrawFrames()
	if wasMoving then
		SlamAndAwe:ShowHideBars()
	end
	SlamAndAwe:DebugPrint(L["Scale set to : "]..SlamAndAwe.db.char.scale)
end

function SlamAndAwe:SetPriorityScale(info,newValue)
	if InCombatLockdown() then
		SlamAndAwe:Print(L["Cannot change scale in combat"])
	end
	SlamAndAwe.db.char.priority.scale = newValue
	SlamAndAwe.PriorityFrame:SetScale(SlamAndAwe.db.char.priority.scale)
	SlamAndAwe:DebugPrint(L["Priority Scale set to : "]..SlamAndAwe.db.char.priority.scale)
end

function SlamAndAwe:SetTFBalpha(info,newValue)
	if SlamAndAwe.db.char.tfbshow then
		SlamAndAwe.db.char.colours.tfbalpha = newValue
		SlamAndAwe:Print(L["config_tfbAlpha_ooc"]..SlamAndAwe.db.char.colours.tfbalpha)
		SlamAndAwe:SetTasteForBloodAlpha(SlamAndAwe.db.char.colours.tfbalpha)
	end
end

function SlamAndAwe:SetTFBalphaFull(info,newValue)
	if SlamAndAwe.db.char.tfbshow then
		SlamAndAwe.db.char.colours.tfbalphaFull = newValue
		SlamAndAwe:Print(L["config_tfbAlpha_combat"]..SlamAndAwe.db.char.colours.tfbalphaFull)
		SlamAndAwe:SetTasteForBloodAlpha(SlamAndAwe.db.char.colours.tfbalphaFull)
	end
end

function SlamAndAwe:SetTasteForBloodAlpha(alphaValue)
	SlamAndAwe.frames["TasteForBlood"]:SetBackdropColor(0, 0, 0, alphaValue * .2)
	SlamAndAwe.frames["TasteForBlood"]:SetBackdropBorderColor( 1, 1, 1, alphaValue)
	local colours = SlamAndAwe.db.char.colours.tfb
	SlamAndAwe.frames["TasteForBlood"].statusbar:SetStatusBarColor( colours.r, colours.g, colours.b, alphaValue)
end

-----------------------------------------
-- Colour choices getter/setters
-----------------------------------------

function SlamAndAwe:getFlameShockColour(info)
	local colours = SlamAndAwe.db.char.colours.flameshock
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setFlameShockColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.flameshock.r = r
	SlamAndAwe.db.char.colours.flameshock.g = g
	SlamAndAwe.db.char.colours.flameshock.b = b
	SlamAndAwe.db.char.colours.flameshock.a = a
	SlamAndAwe:ShockBar(SlamAndAwe.db.char.colours.flameshock)
end

function SlamAndAwe:getFlameShockDotColour(info)
	local colours = SlamAndAwe.db.char.colours.flameshockDot
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setFlameShockDotColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.flameshockDot.r = r
	SlamAndAwe.db.char.colours.flameshockDot.g = g
	SlamAndAwe.db.char.colours.flameshockDot.b = b
	SlamAndAwe.db.char.colours.flameshockDot.a = a
	FSDotTime = GetTime() + 18
	SlamAndAwe:FlameShockDotBar(true) 
end

function SlamAndAwe:getFrostShockColour(info)
	local colours = SlamAndAwe.db.char.colours.frostshock
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setFrostShockColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.frostshock.r = r
	SlamAndAwe.db.char.colours.frostshock.g = g
	SlamAndAwe.db.char.colours.frostshock.b = b
	SlamAndAwe.db.char.colours.frostshock.a = a
	SlamAndAwe:ShockBar(SlamAndAwe.db.char.colours.frostshock)
end

function SlamAndAwe:getWindShearColour(info)
	local colours = SlamAndAwe.db.char.colours.windshear
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setWindShearColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.windshear.r = r
	SlamAndAwe.db.char.colours.windshear.g = g
	SlamAndAwe.db.char.colours.windshear.b = b
	SlamAndAwe.db.char.colours.windshear.a = a
	SlamAndAwe:ShearBar()
end

function SlamAndAwe:getTasteForBloodColour(info)
	local colours = SlamAndAwe.db.char.colours.tfb
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setTasteForBloodColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.tfb.r = r
	SlamAndAwe.db.char.colours.tfb.g = g
	SlamAndAwe.db.char.colours.tfb.b = b
	SlamAndAwe.db.char.colours.tfb.a = a
end

function SlamAndAwe:getStormstrikeColour(info)
	local colours = SlamAndAwe.db.char.colours.stormstrike
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setStormstrikeColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.stormstrike.r = r
	SlamAndAwe.db.char.colours.stormstrike.g = g
	SlamAndAwe.db.char.colours.stormstrike.b = b
	SlamAndAwe.db.char.colours.stormstrike.a = a
	SlamAndAwe:StormstrikeBar()
end

function SlamAndAwe:getDemoShoutColour(info)
	local colours = SlamAndAwe.db.char.colours.demoshout
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setDemoShoutColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.demoshout.r = r
	SlamAndAwe.db.char.colours.demoshout.g = g
	SlamAndAwe.db.char.colours.demoshout.b = b
	SlamAndAwe.db.char.colours.demoshout.a = a
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:DemoShoutBar()
end

function SlamAndAwe:getLastStandColour(info)
	local colours = SlamAndAwe.db.char.colours.laststand
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setLastStandColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.laststand.r = r
	SlamAndAwe.db.char.colours.laststand.g = g
	SlamAndAwe.db.char.colours.laststand.b = b
	SlamAndAwe.db.char.colours.laststand.a = a
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:LastStandBar()
end
 
 

function SlamAndAwe:getWindfuryColour(info)
	local colours = SlamAndAwe.db.char.colours.windfury
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setWindfuryColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.windfury.r = r
	SlamAndAwe.db.char.colours.windfury.g = g
	SlamAndAwe.db.char.colours.windfury.b = b
	SlamAndAwe.db.char.colours.windfury.a = a
	SlamAndAwe:WFProcBar()
end

function SlamAndAwe:getShieldBarrierColour(info)
	local colours = SlamAndAwe.db.char.colours.shieldbarrier
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setShieldBarrierColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.shieldbarrier.r = r
	SlamAndAwe.db.char.colours.shieldbarrier.g = g
	SlamAndAwe.db.char.colours.shieldbarrier.b = b
	SlamAndAwe.db.char.colours.shieldbarrier.a = a
end

function SlamAndAwe:getShieldBlockColour(info)
	local colours = SlamAndAwe.db.char.colours.shieldblock
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setShieldBlockColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.shieldblock.r = r
	SlamAndAwe.db.char.colours.shieldblock.g = g
	SlamAndAwe.db.char.colours.shieldblock.b = b
	SlamAndAwe.db.char.colours.shieldblock.a = a
	if SlamAndAwe.db.char.currentspec == "Protection" then
	SlamAndAwe:ShieldBlockBar()
	end
end

function SlamAndAwe:getShieldWallColour(info)
	local colours = SlamAndAwe.db.char.colours.shieldwall
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setShieldWallColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.shieldwall.r = r
	SlamAndAwe.db.char.colours.shieldwall.g = g
	SlamAndAwe.db.char.colours.shieldwall.b = b
	SlamAndAwe.db.char.colours.shieldwall.a = a
	if SlamAndAwe.db.char.currentspec == "Protection" then
	SlamAndAwe:ShieldWallBar()
	end
end

function SlamAndAwe:getRageColour(info)
	local colours = SlamAndAwe.db.char.colours.rage
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:getRallyingCryColour(info)
	local colours = SlamAndAwe.db.char.colours.rallyingcry
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setRallyingCryColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.rallyingcry.r = r
	SlamAndAwe.db.char.colours.rallyingcry.g = g
	SlamAndAwe.db.char.colours.rallyingcry.b = b
	SlamAndAwe.db.char.colours.rallyingcry.a = a
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:RallyingCryBar()
end


function SlamAndAwe:setRageColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.rage.r = r
	SlamAndAwe.db.char.colours.rage.g = g
	SlamAndAwe.db.char.colours.rage.b = b
	SlamAndAwe.db.char.colours.rage.a = a
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:RageBar()
end

function SlamAndAwe:getTasteForBloodColour(info)
	local colours = SlamAndAwe.db.char.colours.tfb
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setTasteForBloodColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.tfb.r = r
	SlamAndAwe.db.char.colours.tfb.g = g
	SlamAndAwe.db.char.colours.tfb.b = b
	SlamAndAwe.db.char.colours.tfb.a = a
end

function SlamAndAwe:getColossusSmashColour(info)
	local colours = SlamAndAwe.db.char.colours.colossussmash
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setColossusSmashColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.colossussmash.r = r
	SlamAndAwe.db.char.colours.colossussmash.g = g
	SlamAndAwe.db.char.colours.colossussmash.b = b
	SlamAndAwe.db.char.colours.colossussmash.a = a
	if SlamAndAwe.db.char.currentspec == "Fury" then
	SlamAndAwe:ColossusSmashBar()
	end
end

function SlamAndAwe:getSweepingStrikesColour(info)
	local colours = SlamAndAwe.db.char.colours.sweepingstrikes
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setSweepingStrikesColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.sweepingstrikes.r = r
	SlamAndAwe.db.char.colours.sweepingstrikes.g = g
	SlamAndAwe.db.char.colours.sweepingstrikes.b = b
	SlamAndAwe.db.char.colours.sweepingstrikes.a = a
	if SlamAndAwe.db.char.currentspec == "Arms" then
	SlamAndAwe:SweepingStrikesBar()
	end
end

function SlamAndAwe:getDeadlyCalmColour(info)
	local colours = SlamAndAwe.db.char.colours.deadlycalm
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setDeadlyCalmColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.deadlycalm.r = r
	SlamAndAwe.db.char.colours.deadlycalm.g = g
	SlamAndAwe.db.char.colours.deadlycalm.b = b
	SlamAndAwe.db.char.colours.deadlycalm.a = a
	SlamAndAwe:DeadlyCalmBar()
end

function SlamAndAwe:getRecklessnessColour(info)
	local colours = SlamAndAwe.db.char.colours.recklessness
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setRecklessnessColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.recklessness.r = r
	SlamAndAwe.db.char.colours.recklessness.g = g
	SlamAndAwe.db.char.colours.recklessness.b = b
	SlamAndAwe.db.char.colours.recklessness.a = a
	if SlamAndAwe.db.char.currentspec == "Fury" then
	SlamAndAwe:RecklessnessBar()
	end
end

function SlamAndAwe:getFireNovaColour(info)
	local colours = SlamAndAwe.db.char.colours.firenova
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setFireNovaColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.firenova.r = r
	SlamAndAwe.db.char.colours.firenova.g = g
	SlamAndAwe.db.char.colours.firenova.b = b
	SlamAndAwe.db.char.colours.firenova.a = a
	SlamAndAwe:FireNovaBar()
end

function SlamAndAwe:getMagmaColour(info)
	local colours = SlamAndAwe.db.char.colours.magma
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setMagmaColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.magma.r = r
	SlamAndAwe.db.char.colours.magma.g = g
	SlamAndAwe.db.char.colours.magma.b = b
	SlamAndAwe.db.char.colours.magma.a = a
	SlamAndAwe:MagmaBar()
end

function SlamAndAwe:getLavaBurstColour(info)
	local colours = SlamAndAwe.db.char.colours.lavaburst
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setLavaBurstColour(info,r,g,b,a)
	SlamAndAwe.db.char.colours.lavaburst.r = r
	SlamAndAwe.db.char.colours.lavaburst.g = g
	SlamAndAwe.db.char.colours.lavaburst.b = b
	SlamAndAwe.db.char.colours.lavaburst.a = a
	SlamAndAwe:LavaBurstBar()
end

function SlamAndAwe:getFlurryColour(info)
	local colours = SlamAndAwe.db.char.uptime.flurry
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setFlurryColour(info,r,g,b,a)
	SlamAndAwe.db.char.uptime.flurry.r = r
	SlamAndAwe.db.char.uptime.flurry.g = g
	SlamAndAwe.db.char.uptime.flurry.b = b
	SlamAndAwe.db.char.uptime.flurry.a = a
	local buffColours = SlamAndAwe.db.char.uptime.flurry
	SlamAndAwe.uptime.session.buffs[Flurry].barFrame.statusbar:SetStatusBarColor(buffColours.r, buffColours.g, buffColours.b, buffColours.a)
	SlamAndAwe.uptime.lastfight.buffs[Flurry].barFrame.statusbar:SetStatusBarColor(buffColours.r, buffColours.g, buffColours.b, buffColours.a)
end

function SlamAndAwe:getENColour(info)
	local colours = SlamAndAwe.db.char.uptime.en
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setENColour(info,r,g,b,a)
	SlamAndAwe.db.char.uptime.en.r = r
	SlamAndAwe.db.char.uptime.en.g = g
	SlamAndAwe.db.char.uptime.en.b = b
	SlamAndAwe.db.char.uptime.en.a = a
	local buffColours = SlamAndAwe.db.char.uptime.en
	SlamAndAwe.uptime.session.buffs[Enrage].barFrame.statusbar:SetStatusBarColor(buffColours.r, buffColours.g, buffColours.b, buffColours.a)
	SlamAndAwe.uptime.lastfight.buffs[Enrage].barFrame.statusbar:SetStatusBarColor(buffColours.r, buffColours.g, buffColours.b, buffColours.a)
end

function SlamAndAwe:getWFTotalsColour(info)
	local colours = SlamAndAwe.db.char.stats.wfcol
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setWFTotalsColour(info,r,g,b,a)
	SlamAndAwe.db.char.stats.wfcol.r = r
	SlamAndAwe.db.char.stats.wfcol.g = g
	SlamAndAwe.db.char.stats.wfcol.b = b
	SlamAndAwe.db.char.stats.wfcol.a = a
end


function SlamAndAwe:getFrameStrataLevel(info)
	local retValue = SlamAndAwe.db.char.framestratalevel
	
	if retValue == "BACKGROUND" then
		return 1
	elseif retValue == "LOW" then
		return 2
	elseif retValue == "MEDIUM" then
		return 3
	else 
		return 4
	end
end


function SlamAndAwe:setFrameStrataLevel(info, newValue)
	if newValue == 1 then
		newValue = "BACKGROUND"
	elseif newValue == 2 then
		newValue = "LOW"
	elseif newValue == 3 then
		newValue = "MEDIUM"
	else 
		newValue = "HIGH" 
	end
	SlamAndAwe.db.char.framestratalevel = newValue
	SlamAndAwe:RedrawFrames()
	SlamAndAwe:Print(L["config_framestratalevel"]..newValue)
end
-----------------------------------------
-- Annoucement Functions
-----------------------------------------
function SlamAndAwe:MessageType(input)
  i = { "SAY", "YELL", "PARTY", "RAID" }
  return i[input]
end

--Skull Banner
function SlamAndAwe:SkullBannerAnnounceQuery()
	return SlamAndAwe.db.char.announce_skull_banner
end

function SlamAndAwe:ActivateAnnounceSkullBanner()
	SlamAndAwe.db.char.announce_skull_banner = not SlamAndAwe.db.char.announce_skull_banner
	if (SlamAndAwe.db.char.announce_skull_banner) then
		SlamAndAwe:Print(L["config_skull_banner_announce_on"])
	else
		SlamAndAwe:Print(L["config_skull_banner_announce_off"])
	end
end

function SlamAndAwe:GetSkullBannerAnnounceLocation(info)
	return SlamAndAwe.db.char.announce_skull_banner_where
end

function SlamAndAwe:SetSkullBannerAnnounceLocation(info, newValue)
	SlamAndAwe.db.char.announce_skull_banner_where = newValue
	SlamAndAwe:Print(L["config_skull_banner_announce_where"]..SlamAndAwe:MessageType(newValue))
end

--Demoralizing Banner
function SlamAndAwe:DemoralizingBannerAnnounceQuery()
	return SlamAndAwe.db.char.announce_demoralizing_banner
end

function SlamAndAwe:ActivateAnnounceDemoralizingBanner()
	SlamAndAwe.db.char.announce_demoralizing_banner = not SlamAndAwe.db.char.announce_demoralizing_banner
	if (SlamAndAwe.db.char.announce_demoralizing_banner) then
		SlamAndAwe:Print(L["config_demoralizing_banner_announce_on"])
	else
		SlamAndAwe:Print(L["config_demoralizing_banner_announce_off"])
	end
end

function SlamAndAwe:GetDemoralizingBannerAnnounceLocation(info)
	return SlamAndAwe.db.char.announce_demoralizing_banner_where
end

function SlamAndAwe:SetDemoralizingBannerAnnounceLocation(info, newValue)
	SlamAndAwe.db.char.announce_demoralizing_banner_where = newValue
	SlamAndAwe:Print(L["config_demoralizing_banner_announce_where"]..SlamAndAwe:MessageType(newValue))
end

--Mocking Banner
function SlamAndAwe:MockingBannerAnnounceQuery()
	return SlamAndAwe.db.char.announce_mocking_banner
end

function SlamAndAwe:ActivateAnnounceMockingBanner()
	SlamAndAwe.db.char.announce_mocking_banner = not SlamAndAwe.db.char.announce_mocking_banner
	if (SlamAndAwe.db.char.announce_mocking_banner) then
		SlamAndAwe:Print(L["config_mocking_banner_announce_on"])
	else
		SlamAndAwe:Print(L["config_mocking_banner_announce_off"])
	end
end

function SlamAndAwe:GetMockingBannerAnnounceLocation(info)
	return SlamAndAwe.db.char.announce_mocking_banner_where
end

function SlamAndAwe:SetMockingBannerAnnounceLocation(info, newValue)
	SlamAndAwe.db.char.announce_mocking_banner_where = newValue
	SlamAndAwe:Print(L["config_mocking_banner_announce_where"]..SlamAndAwe:MessageType(newValue))
end

--Interrupt Announce
function SlamAndAwe:InterruptAnnounceQuery()
	return SlamAndAwe.db.char.announce_interrupt
end

function SlamAndAwe:ActivateAnnounceInterrupt()
	SlamAndAwe.db.char.announce_interrupt = not SlamAndAwe.db.char.announce_interrupt
	if (SlamAndAwe.db.char.announce_interrupt) then
		SlamAndAwe:Print(L["config_interrupt_announce_on"])
	else
		SlamAndAwe:Print(L["config_interrupt_announce_off"])
	end
end

function SlamAndAwe:GetInterruptAnnounceLocation(info)
	return SlamAndAwe.db.char.announce_interrupt_where
end

function SlamAndAwe:SetInterruptAnnounceLocation(info, newValue)
	SlamAndAwe.db.char.announce_interrupt_where = newValue
	SlamAndAwe:Print(L["config_interrupt_announce_where"]..SlamAndAwe:MessageType(newValue))
end

-----------------------------------------
-- Priority Choices
-----------------------------------------

function SlamAndAwe:GetPriorityGroup(info)
	return SlamAndAwe.db.char.priority.groupnumber
end

function SlamAndAwe:SetPriorityGroup(info, groupnumber)
	SlamAndAwe.db.char.priority.groupnumber = groupnumber
	SlamAndAwe:SelectPrioritySet(groupnumber)
end

function SlamAndAwe:GetPriority(index)
	return 	
		function(info) 
			return SlamAndAwe.db.char.priority.prOption[index]  
		end
end

function SlamAndAwe:SetPriority(index)
	return 		
		function(info, priorityValue)
			SlamAndAwe:DebugPrint("setting priority "..index.." to "..priorityValue)
			SlamAndAwe.db.char.priority.prOption[index] = priorityValue
			SlamAndAwe.db.char.priority.prOptions[SlamAndAwe.db.char.priority.groupnumber] = SlamAndAwe.db.char.priority.prOption
		end
end

function SlamAndAwe:priorityQuery()
	return SlamAndAwe.db.char.priority.show
end

function SlamAndAwe:ActivatePriority()
	SlamAndAwe.db.char.priority.show = not SlamAndAwe.db.char.priority.show
	if (SlamAndAwe.db.char.priority.show) then
		SlamAndAwe:Print(L["config_priority_on"])
	else
		SlamAndAwe.PriorityFrame:Hide()
		SlamAndAwe:Print(L["config_priority_off"])
	end
end

function SlamAndAwe:priorityTitleQuery()
	return SlamAndAwe.db.char.priority.titleshow
end

function SlamAndAwe:ActivatePriorityTitle()
	SlamAndAwe.db.char.priority.titleshow = not SlamAndAwe.db.char.priority.titleshow
	if SlamAndAwe.db.char.priority.titleshow then
		SlamAndAwe.PriorityFrame.topText:Show()
		SlamAndAwe:Print(L["config_prioritytitle_on"])
	else
		SlamAndAwe.PriorityFrame.topText:Hide()
		SlamAndAwe:Print(L["config_prioritytitle_off"])
	end
end

---------------
-- Warnings
---------------

function SlamAndAwe:WarningFrameQuery()
	return SlamAndAwe.db.char.warning.show
end

function SlamAndAwe:ActivateWarningFrame()
	SlamAndAwe.db.char.warning.show = not SlamAndAwe.db.char.warning.show
	if (SlamAndAwe.db.char.warning.show) then
		SlamAndAwe:Print(L["config_warnframe_on"])
	else
		SlamAndAwe:Print(L["config_warnframe_off"])
	end
end

function SlamAndAwe:rangeWarnQuery()
	return SlamAndAwe.db.char.warning.range
end

function SlamAndAwe:ActivateRangeWarn()
	SlamAndAwe.db.char.warning.range = not SlamAndAwe.db.char.warning.range
	if (SlamAndAwe.db.char.warning.range) then
		SlamAndAwe:Print(L["config_rangewarn_on"])
	else
		SlamAndAwe:Print(L["config_rangewarn_off"])
	end
end

function SlamAndAwe:interruptWarnQuery()
	return SlamAndAwe.db.char.warning.interrupt
end

function SlamAndAwe:enableDisableBorderQuery()
	return SlamAndAwe.db.char.enableDisableBorder
end

function SlamAndAwe:ActivateEnableDisableBorder()
	SlamAndAwe.db.char.enableDisableBorder = not SlamAndAwe.db.char.enableDisableBorder
	if (SlamAndAwe.db.char.enableDisableBorder) then
	SlamAndAwe:Print("Borders will no longer be shown")
	SlamAndAwe.barBackdrop = {
			bgFile = "Interface/Tooltips/UI-Tooltip-Background",
		}
	SlamAndAwe.frameBackdrop ={
			bgFile = "Interface/Tooltips/UI-Tooltip-Background",
		}
		SlamAndAwe.frames["GCD"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldBarrier"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldBlock"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldWall"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ColossusSmash"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["DeadlyCalm"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["Recklessness"]:SetBackdrop(SlamAndAwe.barBackdrop)		
		SlamAndAwe.frames["SweepingStrikes"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["DemoShout"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["LastStand"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["RallyingCry"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["GCD"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ShieldBarrier"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ShieldBlock"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ShieldWall"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ColossusSmash"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["DeadlyCalm"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["Recklessness"]:SetBackdrop(SlamAndAwe.frameBackdrop)		
		SlamAndAwe.frames["SweepingStrikes"]:SetBackdrop(SlamAndAwe.frameBackdrop)	
		SlamAndAwe.frames["DemoShout"]:SetBackdrop(SlamAndAwe.frameBackdrop)	
		SlamAndAwe.frames["LastStand"]:SetBackdrop(SlamAndAwe.frameBackdrop)	
		SlamAndAwe.frames["RallyingCry"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe:RedrawFrames()
	else
	SlamAndAwe.barBackdrop = {
			bgFile = "Interface/Tooltips/UI-Tooltip-Background",
			edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
			tile = false, tileSize = 0, edgeSize = 12,
			insets = { left = 2, right = 2, top = 2, bottom = 2 }
		}
	SlamAndAwe.frameBackdrop ={
			bgFile = "Interface/Tooltips/UI-Tooltip-Background",
			--edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
			tile = false, tileSize = 0, edgeSize = 12,
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
		}

		SlamAndAwe.frames["GCD"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldBarrier"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldBlock"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ShieldWall"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["ColossusSmash"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["DeadlyCalm"]:SetBackdrop(SlamAndAwe.barBackdrop)
		SlamAndAwe.frames["Recklessness"]:SetBackdrop(SlamAndAwe.barBackdrop)		
		SlamAndAwe.frames["SweepingStrikes"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["DemoShout"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["LastStand"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["RallyingCry"]:SetBackdrop(SlamAndAwe.barBackdrop)	
		SlamAndAwe.frames["GCD"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ShieldBarrier"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ShieldBlock"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ShieldWall"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["ColossusSmash"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["DeadlyCalm"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe.frames["Recklessness"]:SetBackdrop(SlamAndAwe.frameBackdrop)		
		SlamAndAwe.frames["SweepingStrikes"]:SetBackdrop(SlamAndAwe.frameBackdrop)	
		SlamAndAwe.frames["DemoShout"]:SetBackdrop(SlamAndAwe.frameBackdrop)	
		SlamAndAwe.frames["LastStand"]:SetBackdrop(SlamAndAwe.frameBackdrop)	
		SlamAndAwe.frames["RallyingCry"]:SetBackdrop(SlamAndAwe.frameBackdrop)
		SlamAndAwe:RedrawFrames()
	end
end


function SlamAndAwe:ActivateInterruptWarn()
	SlamAndAwe.db.char.warning.interrupt = not SlamAndAwe.db.char.warning.interrupt
	if (SlamAndAwe.db.char.warning.interrupt) then
		SlamAndAwe:Print(L["config_interruptwarn_on"])
	else
		SlamAndAwe:Print(L["config_interruptwarn_off"])
	end
end

function SlamAndAwe:EnableDisable()
	if SlamAndAwe.db.char.disabled then
		SlamAndAwe:Enable()
	else
		SlamAndAwe:Disable()
	end
end

function SlamAndAwe:Disable()
		if InCombatLockdown() then
			SlamAndAwe:Print(L["Cannot enable/disable addon in combat"])
			return
		end
		SlamAndAwe.db.char.disabled = true
		SlamAndAwe:OnDisable()
		SlamAndAwe.PriorityFrame:Hide()
		SlamAndAwe.UptimeFrame:Hide()
		SlamAndAwe.frames["Rage"]:Hide()
		SlamAndAwe.frames["ShieldBarrier"]:Hide()
		SlamAndAwe.frames["ShieldBarrier"].icon:Hide()
		SlamAndAwe:Print(L["config_disabled_on"])
end

function SlamAndAwe:Enable()
		
		 local currentSpec = GetSpecialization()
		if InCombatLockdown() then
			SlamAndAwe:Print(L["Cannot enable/disable addon in combat"])
			return
		end
		SlamAndAwe.db.char.disabled = false
		SlamAndAwe:OnEnable()
		SlamAndAwe:RedrawFrames()
		if  not SlamAndAwe.db.char.movingframes then -- need to ensure moving frames is false on enabled to disabled to enabled
			SlamAndAwe.db.char.movingframes = true -- forces false in ShowHideBars to re-enable frames -- need a better hack
		else
			SlamAndAwe.db.char.movingframes  = false
		end
		
		
		SlamAndAwe:ShowHideBars()
		SlamAndAwe:Print(L["config_disabled_off"])
		SlamAndAwe:RageBar()
		
end



function SlamAndAwe:ResetImmunity()
	SlamAndAwe.db.char.immuneTargets = {}
	SlamAndAwe:Print(L["config_resetImmunity"])
end

function SlamAndAwe:GetMSBTareas(info)
	return SlamAndAwe.db.char.MSBToutputarea
end

function SlamAndAwe:SetMSBTareas(info, value)
	SlamAndAwe.db.char.MSBToutputarea = value
end

function SlamAndAwe:getWarningColour(info)
	local colours = SlamAndAwe.db.char.warning.colour
	return colours.r, colours.g, colours.b, colours.a
end

function SlamAndAwe:setWarningColour(info,r,g,b,a)
	SlamAndAwe.db.char.warning.colour.r = r
	SlamAndAwe.db.char.warning.colour.g = g
	SlamAndAwe.db.char.warning.colour.b = b
	SlamAndAwe.db.char.warning.colour.a = a
end

function SlamAndAwe:GetWarningDuration(info)
	return SlamAndAwe.db.char.warning.duration 
end

function SlamAndAwe:SetWarningDuration(info, priorityValue)
	SlamAndAwe.db.char.warning.duration = priorityValue
end

function SlamAndAwe:OpenConfig()
	if InterfaceOptionsFrame_OpenToCategory then
		InterfaceOptionsFrame_OpenToCategory("SlamAndAwe");
	else
		InterfaceOptionsFrame_OpenToFrame("SlamAndAwe");
	end
end

function SlamAndAwe:GetMSBTAreaDefaults()
    local i = 0;
	SlamAndAwe.MSBT = {}
	SlamAndAwe.MSBT.areas = {}
    if MikSBT ~= nil and MikSBT.IterateScrollAreas ~= nil then
        for scrollAreaKey, scrollAreaName in MikSBT.IterateScrollAreas() do
            i = i + 1
            SlamAndAwe.MSBT.areas[i] = scrollAreaName
        end
    end
end