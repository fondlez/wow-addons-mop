local L = LibStub("AceLocale-3.0"):NewLocale("SlamAndAwe", "deDE", true, debug);
if not L then end