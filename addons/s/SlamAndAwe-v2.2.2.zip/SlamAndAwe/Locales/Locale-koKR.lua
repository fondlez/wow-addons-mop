local L = LibStub("AceLocale-3.0"):NewLocale("SlamAndAwe", "koKR", true, debug);
if not L then end