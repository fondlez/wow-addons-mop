local L = LibStub("AceLocale-3.0"):NewLocale("SlamAndAwe", "frFR", true, debug);
if not L then end