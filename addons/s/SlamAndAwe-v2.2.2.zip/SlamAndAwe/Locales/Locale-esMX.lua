local L = LibStub("AceLocale-3.0"):NewLocale("SlamAndAwe", "esMX", true, debug);
if not L then end