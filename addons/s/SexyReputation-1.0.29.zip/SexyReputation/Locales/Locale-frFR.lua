local L = LibStub("AceLocale-3.0"):NewLocale("SexyReputation", "frFR")
if not L then return end

-- To help localize SexyReputation please enter phrase translations on the
-- following URL:
-- http://www.wowace.com/projects/sexyreputation/localization/
-- This file should not be edited manually!

L["Active Factions Only"] = "Factions actives uniquement"
L["Alt-Click:"] = "Alt-Clic gauche :"
L["Bar"] = "Barre"
L["Both Standing and Reputation"] = "État et réputation"
L["Changes"] = "Changements"
L["Click:"] = "Clic gauche :"
L["Color standing and reputation fields based on your standing with the different factions."] = "Color standing and reputation fields based on your standing with the different factions." -- Requires localization
L["Color Text"] = "Color Text" -- Requires localization
L["Configure the LDB display of the tracked faction."] = "Configure l'affichage LDB de la faction suivie."
L["Configure the look and feel of the faction tooltip."] = "Configure l'apparence et le comportement de la bulle d'aide de faction."
L["Faction"] = "Faction"
L["Factions"] = "Factions"
L["Fold / unfold faction headers."] = "Fold / unfold faction headers." -- Requires localization
L["Last Month"] = "Mois dernier"
L["Last Week"] = "Semaine dernière"
L["Maximum tooltip height, in pixels. Regardless of this value, the tooltip will be sized to fit the screen."] = "Maximum tooltip height, in pixels. Regardless of this value, the tooltip will be sized to fit the screen." -- Requires localization
L["No changes recorded in the last 30 days."] = "Aucun changement enregistré ces 30 derniers jours."
L["None"] = "Aucun"
L["Only show factions with recent reputation changes."] = "Affiche uniquement les factions ayant reçus de récents changements de réputation."
L["Percentage"] = "Pourcentage"
L["Recent reputation changes"] = "Changements de réputation récents"
L["Reputation"] = "Réputation"
L["Reputation Only"] = "Réputation uniquement"
L["Session"] = "Session"
L["Sexy Reputation"] = "Sexy Reputation" -- Requires localization
L["Sexy Reputations"] = "Sexy Reputations" -- Requires localization
L["Shift+Ctrl-Click:"] = "Shift+Ctrl-Click:" -- Requires localization
L["Show Gains"] = "Afficher les gains"
L["Show lines after each row so you can more easily see which values below to which reputation"] = "Affiche des lignes après chaque rangée afin que vous puissiez voir plus facilement quelles valeurs correspondent à quelles réputations."
L["Show Name"] = "Afficher le nom"
L["Show Percentage"] = "Afficher le pourcentage"
L["Show reputation gained or lost in the session and today."] = "Affiche la réputation gagnée ou perdue pendant la session et aujourd'hui."
L["Show Row Lines"] = "Show Row Lines" -- Requires localization
L["Show the name of the tracked faction."] = "Affiche le nom de la faction suivie."
L["Show the reputation numbers for the tracked faction."] = "Show the reputation numbers for the tracked faction." -- Requires localization
L["Show the reputation percentage in the current standing level for the tracked faction."] = "Show the reputation percentage in the current standing level for the tracked faction." -- Requires localization
L["Show the session changes for the tracked faction."] = "Show the session changes for the tracked faction." -- Requires localization
L["Show the standing of the tracked faction."] = "Affiche l'état de la faction suivie."
L["Show your rep as a percentage of the reputation standing (i.e Neutral 1500/3000 = 50%)"] = "Affiche votre réputation en tant que pourcentage de votre état de réputation (c'est-à-dire, par exemple : Neutre 1500/3000 = 50%)."
L["Standing"] = "État"
L["Standing Colors"] = "Couleurs de l'état"
L["Standing Only"] = "État uniquement"
L["Standing Style"] = "Style de l'état"
L["Text"] = "Texte"
L["Text Display"] = "Affichage du texte"
L["Text Reputation Style"] = "Style du texte de réputation"
L["The colors used for the bar/text for the reputation standings."] = "The colors used for the bar/text for the reputation standings." -- Requires localization
L["This faction is currently being tracked."] = "Cette faction est actuellement surveillée."
L["Today"] = "Aujourd'hui"
L["Toggle faction inactive state."] = "Toggle faction inactive state." -- Requires localization
L["Toggle faction tracking state on and off."] = "Toggle faction tracking state on and off." -- Requires localization
L["Tooltip max height"] = "Hauteur max. bulle d'aide"
L["Tooltip Options"] = "Tooltip Options" -- Requires localization
L["Using the faction tooltip:"] = "Using the faction tooltip:" -- Requires localization
L["Whether to show the reputation level as a bar, text or not at all"] = "Whether to show the reputation level as a bar, text or not at all" -- Requires localization
L["Whether to show the standing and/or reputation level text."] = "Whether to show the standing and/or reputation level text." -- Requires localization
L["Yesterday"] = "Hier"

