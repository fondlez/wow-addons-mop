-- Author         : Fig�/Krag'jin
-- Create Date    : 29/08/2012 18:21:13
-- 5.0.5
-- Version 5.0.9

Shadowtimer_Default_X = 0
Shadowtimer_Default_Y = 0
Shadowtimer_Default_Size = 100
Shadowtimer_Default_Scale = 1

MyAddon_UpdateInterval = 0.05; -- How often the OnUpdate code will run (in seconds)
WarningTime = 600; -- WarningTime (in milliseconds)
----------------------------------------------
local nameWordPain, rankWordPain = GetSpellInfo(589);	--"schmerz"
local IconWordPain = "Interface\\ICONS\\Spell_Shadow_ShadowWordPain.blp"
----------------------------------------------
--"Vampirber�hrung"
local nameTouch, rankTouch, icon, cost, isFunnel, powerType, castTimeVT, minRange, maxRange = GetSpellInfo(34914)	
local IconTouch = "Interface\\ICONS\\Spell_Holy_Stoicism.blp"
----------------------------------------------
local namePlague, rankPlague = GetSpellInfo(2944);	--"Plague"
local IconPlague = "Interface\\ICONS\\Spell_Shadow_DevouringPlague.blp"
----------------------------------------------
local SPELL_POWER_SHADOW_ORBS  = SPELL_POWER_SHADOW_ORBS 
local IconShadowOrbs = "Interface\\ICONS\\spell_priest_shadoworbs.blp"
----------------------------------------------
local nameMindBlast, rankMindBlast = GetSpellInfo(8092);
local IconMindBlast = "Interface\\ICONS\\spell_shadow_unholyfrenzy.blp"
----------------------------------------------
local nameEmbrace, rankEmbrace = GetSpellInfo(15286);	--"Vampiric Embrace"
local IconEmbrace = "Interface\\ICONS\\spell_shadow_unsummonbuilding.blp"
----------------------------------------------
local nameDeath, rankDeath = GetSpellInfo(32379);	--"Shadow Word: Death"
local IconDeath = "Interface\\ICONS\\spell_shadow_demonicfortitude.blp"
----------------------------------------------
local nameBender, rankBender = GetSpellInfo(123040);	--"Mindbender"
local IconBender = "Interface\\ICONS\\spell_shadow_soulleech_3.blp"
----------------------------------------------
local nameFiend, rankFiend = GetSpellInfo(34433);
local IconFiend = "Interface\\ICONS\\spell_shadow_shadowfiend.blp"
----------------------------------------------
local nameSurge, rankSurge = GetSpellInfo(87160);
local IconSpike = "Interface\\ICONS\\spell_priest_mindspike.blp"
----------------------------------------------
local IconMindFlay = "Interface\\ICONS\\spell_shadow_siphonmana.blp"

local inCombat = false;
local hideOrbs = false;
local useMindBender = false;
local useFDCL = false;

local DPPrio = 0;
local SWDPrio = 0;
local MBPrio = 0;
local SWPPrio = 0;
local VTPrio = 0;
local PetPrio = 0;
local DHPrio = 0; -- Dark Halo Prio
local MSPrio = 0;

local DPfirst = 0;
local SWDfirst = 0;
local MBfirst = 0;
local SWPfirst = 0;
local VTfirst = 0;
local Petfirst = 0;
local DHfirst = 0; 
local MSfirst = 0;


function ShadowTimerFrame_OnLoad()
	ShadowTimerFrame:RegisterEvent("VARIABLES_LOADED");
	ShadowTimerFrame:RegisterEvent("PLAYER_LOGOUT");
	ShadowTimerFrame:RegisterEvent("ADDON_LOADED");
	ShadowTimerFrame:RegisterEvent("PLAYER_REGEN_DISABLED") --Fired when you enter combat
	ShadowTimerFrame:RegisterEvent("PLAYER_REGEN_ENABLED") --Fired when you leave combat
	ShadowTimerFrame:RegisterEvent("PLAYER_TALENT_UPDATE")	
		
	DEFAULT_CHAT_FRAME:AddMessage("---Simple shadow timers loaded---");
	Texture1:SetTexture(IconTouch)
	Texture2:SetTexture(IconPlague)
	Texture3:SetTexture(IconWordPain)
	Texture4:SetTexture(IconMindBlast)
	Texture5:SetTexture(IconDeath)
	Texture6:SetTexture(IconSpike)
	Texture7:SetTexture(IconBender)
	Texture8:SetTexture(IconEmbrace)
	Texture9:SetTexture(IconTouch)
	Texture10:SetTexture(IconWordPain)
	Texture12:SetTexture(IconWordPain)
	
	TEXT1:Hide()
	TEXT2:Hide()
	TEXT3:Hide()
	TEXT4:Hide()
	TEXT5:Hide()
	TEXT6:Hide()
	TEXT7:Hide()
	TEXT8:Hide()
	TEXT9:Hide()
	TEXT10:Hide()
	TEXT11:Hide()
	
	Texture1:Hide()
	Texture2:Hide()
	Texture3:Hide()		
	Texture6:Hide()
	Texture7:Hide()
	Texture8:Hide()
	Texture9:Hide()
	Texture10:Hide()
	Texture11:Hide()
	Texture12:Hide()
	
	
	ShadowTimerFrame:Show()	
	
	TimeSinceLastUpdate = 0
	ShadowTimerFrame:RegisterForDrag("LeftButton", "RightButton")
	ShadowTimerFrame:EnableMouse(false)	
end


function ShadowTimerFrame_OnUpdate(elapsed)		
		TimeSinceLastUpdate = TimeSinceLastUpdate + elapsed;
		while (TimeSinceLastUpdate > MyAddon_UpdateInterval) and checkShadowPriest() do		
			CheckCurrentTargetDeBuffs();			
			CheckPlayerBuffs();
			if showFocus == true then
				CheckFocusTargetDeBuffs();
			end
			if showPrio == true then
				CheckFirstPrio();
				CheckSecondPrio();
			end
		TimeSinceLastUpdate = TimeSinceLastUpdate - MyAddon_UpdateInterval;	
		end
	end


function ShadowTimerFrame_OnEvent(self, event, ...)	

		if (event == "ADDON_LOADED") then
			if ShadowtimerxPosiFrame then
				--DEFAULT_CHAT_FRAME:AddMessage(ShadowtimerxPosiFrame)
			end

			if (ShadowtimerScaleFrame) then
				--DEFAULT_CHAT_FRAME:AddMessage("found stscale");
				ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
			else
				--DEFAULT_CHAT_FRAME:AddMessage("found no stscale");
				ShadowtimerScaleFrame = 1.0
			end			
		elseif (event == "VARIABLES_LOADED" and addon == "ShadowTimers") then 
		  
			if (not Shadowtimer_X) then
				Shadowtimer_X = Shadowtimer_Default_X
				Shadowtimer_Y = Shadowtimer_Default_Y
				Shadowtimer_Size = Shadowtimer_Default_Size				
				DEFAULT_CHAT_FRAME:AddMessage("Shadowtimer Options not found. Generating...");
			end
				--point, relativeTo, relativePoint, xOffset, yOffset = self:GetPoint(1);				
				--ShadowtimerxPosiFrame = xOffset				
		elseif (event == "PLAYER_REGEN_ENABLED") and hideOOC then
				inCombat = false
				ShadowTimerFrame:Hide()
		elseif (event == "PLAYER_REGEN_DISABLED") and hideOOC and checkShadowPriest() then
				inCombat = true
				ShadowTimerFrame:Show()		
		elseif (event == "PLAYER_TALENT_UPDATE") then	
			talentCheck()			
			checkShadowPriest()						
		elseif (event == "PLAYER_LOGOUT") then
			---
		end		 
end

function CheckFirstPrio()
	Texture11:Show()	
	if DPPrio == 1 then
		Texture11:SetTexture(IconPlague)
		DPfirst = 1
	elseif SWDprio == 1 then
		Texture11:SetTexture(IconDeath)
		SWDfirst = 1
	elseif MBPrio == 1 then
		Texture11:SetTexture(IconMindBlast)
		MBfirst = 1
	elseif SWPPrio == 1 then
		Texture11:SetTexture(IconWordPain)
		SWPfirst = 1
	elseif VTPrio == 1 then
		Texture11:SetTexture(IconTouch)
		VTfirst = 1
	elseif PetPrio == 1 then
		Petfirst = 1
		if useMindBender then
			Texture11:SetTexture(IconBender)
		else
			Texture11:SetTexture(IconFiend)
		end
	else
		Texture11:SetTexture(IconMindFlay)
	end
end

function CheckSecondPrio()
	Texture12:Show()
	if DPPrio == 1 and DPfirst == 0 then
		Texture12:SetTexture(IconPlague)
	elseif SWDprio == 1 and SWDfirst == 0 then
		Texture12:SetTexture(IconDeath)
	elseif MBPrio == 1 and MBfirst == 0 then
		Texture12:SetTexture(IconMindBlast)
	elseif SWPPrio == 1 and SWPfirst == 0 then
		Texture12:SetTexture(IconWordPain)
	elseif VTPrio == 1 and VTfirst == 0 then
		Texture12:SetTexture(IconTouch)
	elseif PetPrio == 1 and Petfirst == 0 then
		if useMindBender then
			Texture12:SetTexture(IconBender)
		else
			Texture12:SetTexture(IconFiend)
		end
	else
		Texture12:SetTexture(IconMindFlay)
	end
end

function CheckCurrentTargetDeBuffs()
	local finished = false
	local count = 0
	local TouchFound = 0
	local TouchLeft = 0
	local PlagueFound = 0
	local PlagueLeft = 0
	local WordPainFound = 0
	local WordPainLeft = 0
	local Toutchlefttime = 0
	local TouchlasttickTime = 0
	local TouchlasttickcastTime = 0
	local ToutchleftMS = 0
	local WordPainlasttickTime = 0
	local WordPainlasttickCastTime = 0
	local MindBlastCooldown = 0	
	local EmbraceCooldown = 0
	
	local name, rank, icon, cost, isFunnel, powerType, castTimeVT, minRange, maxRange = GetSpellInfo(34914)	 -- get castTime
	TouchlasttickTime = castTimeVT*3+WarningTime -- unbuffed 1.5*2 time vonticks + 1.5 cast time
	TouchlasttickcastTime = castTimeVT*3 -- unbuffed 1.5*2 time vonticks + 1.5 cast time)
	WordPainlasttickTime = castTimeVT*2+WarningTime
	WordPainlasttickCastTime = castTimeVT*2  -- unbuffed und nichtgeskilled 3000 ms
--new
--info
--with enough haste u get an additional tick  these must be taken into account so
--normal touchtime=15 when ur globalcd == 1,5 you get 5 ticks @ 3,0 sec intervall
--normal Plaguetime=24 when ur GCD = 1,5 you get 8 ticks @ 3,0 sec intervall

-- the best time to renew the dot is 1ms after the last tick
--lets assume u have a Gcd of 1.36  --->ticktimes	2,72/5.44/8.16/10.88/13.6/16,32/19.04/21.76/24.48/27.2
--lets assume u have a Gcd of 1.33  --->ticktimes	2,66/5.32/7,98/10.64/13.3/15,96/18,62/21.28/23,94/26.6
--under 1.363 GCD u get 6ticks of VB but remember  your last tick  comes after 15sec
--
--best casttime VB is and will be ((GCD*2)+GCD) bevor ending the debuff,course refrehing faster will add more time to the next AURA
-- u gonna get more ticks

	while not finished do
		count = count+1
		local bn,brank,bicon,bcount,bType,bduration,bexpirationTime,bisMine,bisStealable,bshouldConsolidate,bspellId =  UnitDebuff("target", count, 0)
		
		if not bn then
			finished = true
		else			
			if bisMine == "player" then				
				if bn == nameTouch then 
					TouchFound = 1 
					Toutchlefttime = floor((((bexpirationTime-GetTime())*10)+ 0.5))/10				--Time left
					TouchLeft = string.format("%1.1f",Toutchlefttime)							-- as formated string
					ToutchleftMS = Toutchlefttime*1000			
					ToutchleftMSSafe = ToutchleftMS-WarningTime					
				end
				if bn == namePlague then 
					PlagueFound = 1
					Plaguelefttime = floor((((bexpirationTime-GetTime())*10)+ 0.5))/10				--Time left
					PlagueLeft = string.format("%1.1f",Plaguelefttime)	 
			
				end
				if bn == nameWordPain then 
					WordPainFound = 1
					WordPainlefttime = floor((((bexpirationTime-GetTime())*10)+ 0.5))/10
					WordPainLeft = string.format("%1.1f",floor((((bexpirationTime-GetTime())*10)+ 0.5))/10)  
					WordPainleftMS = WordPainlefttime*1000
				end
			end
		end
	end
	if TouchFound == 1 then
		Texture1:Show()
		VTfirst = 0
		if  ToutchleftMS < TouchlasttickTime then
			if ToutchleftMS < TouchlasttickcastTime then
				VTPrio = 1
				Texture1:SetVertexColor(0.1, 0.6, 0.1);
			else 
				VTPrio = 1
				Texture1:SetVertexColor(0.9, 0.2, 0.2);
			end
		else	
			VTPrio = 0
			Texture1:SetVertexColor(1.0, 1.0, 1.0);
		end		
		TEXT1:SetText(TouchLeft)
		TEXT1:Show()			
	else
		VTPrio = 1
		TEXT1:Hide()
		Texture1:Hide()
	end

	if PlagueFound == 1 then
		DPfirst = 0
		Texture2:SetVertexColor(1.0, 1.0, 1.0)
		Texture2:SetTexture(IconPlague)
		Texture2:Show()
		TEXT2:SetText(PlagueLeft)
		TEXT2:Show()
		hideOrbs = true;
	else
		Texture2:Hide()
		TEXT2:Hide()
		hideOrbs = false;
	end
	
	if WordPainFound == 1 then
		Texture3:Show()
		SWPfirst = 0
		if  WordPainleftMS < WordPainlasttickTime then
			if WordPainleftMS < WordPainlasttickCastTime  then
				SWPPrio = 1
				Texture3:SetVertexColor(0.1, 0.6, 0.1);
			else 
				SWPPrio = 1
				Texture3:SetVertexColor(0.9, 0.2, 0.2);
			end
		else	
			SWPPrio = 0
			Texture3:SetVertexColor(1.0, 1.0, 1.0);
		end		
		TEXT3:SetText(WordPainLeft)
		TEXT3:Show()
	else
		SWPPrio = 1
		Texture3:Hide()
		TEXT3:Hide()
	end

return
end	


function CheckPlayerBuffs()		
	local finished = false	
	local count = 0
	local EmbraceFound = 0	
	local SPELL_POWER_SHADOW_ORBS  = SPELL_POWER_SHADOW_ORBS 
	local orbs = UnitPower('player', SPELL_POWER_SHADOW_ORBS)	
	local name, rank, icon, cost, isFunnel, powerType, castTimeVT, minRange, maxRange = GetSpellInfo(34914)	
	local pseudoGCD = castTimeVT/1000
	
	-- Shadow Orbs --
	if(orbs > 0) and (not hideOrbs) then
		Texture2:SetTexture(IconShadowOrbs)
		Texture2:Show()
		TEXT2:SetText(orbs)
		TEXT2:Show()
		DPPrio = 0
		if ( orbs == 3) then
			DPPrio = 1
			Texture2:SetVertexColor(0.1, 0.6, 0.1)
		end
	else
		DPPrio = 0
	end	
	
	-- Mind Blast --
	if showMB then	
		MBstart, MBduration, MBenabled = GetSpellCooldown(nameMindBlast);
		Texture4:Show()	
		if  MBstart == 0 then			
			Texture4:SetVertexColor(0.1, 0.6, 0.1)			
			TEXT4:Hide()
			MBPrio = 1
		elseif MBenabled == 1 and MBduration > pseudoGCD then
			Texture4:SetVertexColor(0.9, 0.2, 0.2)			
			MindBlastCooldown = MBstart + MBduration - GetTime()
			MindBlastCooldownString = string.format("%1.1f",MindBlastCooldown)				
			TEXT4:SetText(MindBlastCooldownString)
			TEXT4:Show()
			MBPrio = 0
			MBfirst = 0
		else	
			MBPrio = 1 
			MBfirst = 0
			Texture4:SetVertexColor(0.1, 0.6, 0.1)
			TEXT4:Hide()
		end
	else
		Texture4:Hide()
		TEXT4:Hide()
	end
	-- Shadow Word: Death "without Glyph" --
	if showSWD then
		Deathstart, Deathduration, Deathenabled = GetSpellCooldown(nameDeath);
		Texture5:Show()
		if  ceil(UnitHealth("target") / UnitHealthMax("target") * 100) <= 20 then
			DeathCooldown = Deathstart + Deathduration - GetTime();
			DeathCooldownString = string.format("%1.1f",DeathCooldown);
			if Deathstart == 0 and Deathenabled == 1 then
				Texture5:SetVertexColor(0.1, 0.6, 0.1)			
				TEXT5:Hide()
			else
				Texture5:SetVertexColor(1.0, 1.0, 1.0)		
				TEXT5:Show()			
				TEXT5:SetText(DeathCooldownString)	
			end
		else				
			Texture5:SetVertexColor(0.9, 0.2, 0.2)			
			TEXT5:Hide()
		end
	else
		Texture5:Hide()
		TEXT5:Hide()
	end
	
	-- FDCL --
	if showSpike and useFDCL then		
		local name, rank, icon, count = UnitAura("player", nameSurge)	
		Texture6:Show()
		if name == nil then	
			MSPrio = 0
			Texture6:SetVertexColor(0.9, 0.2, 0.2)			
			TEXT6:Hide()						
		else
			MSPrio = 1
			Texture6:SetVertexColor(0.1, 0.6, 0.1)
			stackCount = string.format("%d",count)			
			TEXT6:SetText(stackCount)
			TEXT6:Show()
		end	
	else
		Texture6:Hide()
		TEXT6:Hide()
	end
	
	-- MindBender and Shadowfiend --	
	if showPet then 
		Texture7:Show()		
		if useMindBender then
			Benderstart, Benderduration, Benderenabled = GetSpellCooldown(nameBender);
			BenderCooldown = Benderstart + Benderduration - GetTime();	
			Texture7:SetTexture(IconBender)			
			if Benderstart == 0 then
				PetPrio = 1
				Texture7:SetVertexColor(0.1, 0.6, 0.1)					
				TEXT7:Hide()	
			else				
				if IsPetAttackActive() then
					Petfirst = 0
					PetPrio = 0
					Texture7:SetVertexColor(1.0, 1.0, 1.0)				
					BenderCooldownString = string.format("%1.1f",15 + (Benderstart - GetTime()))
					TEXT7:SetText(BenderCooldownString)
					TEXT7:Show()												
				elseif Benderduration > pseudoGCD then
					Petfirst = 0
					PetPrio = 0
					Texture7:SetVertexColor(0.9, 0.2, 0.2)					
					BenderCooldownString = string.format("%1.1f",BenderCooldown)								
					TEXT7:SetText(BenderCooldownString)	
					TEXT7:Show()
				else
					PetPrio = 1
					Petfirst = 0
					TEXT7:Hide()
				end
			end
		else
			Fiendstart, Fiendduration, Fiendenabled = GetSpellCooldown(nameFiend);
			FiendCooldown = Fiendstart + Fiendduration - GetTime();	
			Texture7:SetTexture(IconFiend)
			
			if Fiendstart == 0 then
				PetPrio = 1
				Texture7:SetVertexColor(0.1, 0.6, 0.1)					
				TEXT7:Hide()	
			else				
				if IsPetAttackActive() then	
					Petfirst = 0
					PetPrio = 0
					Texture7:SetVertexColor(1.0, 1.0, 1.0)					
					FiendCooldownString = string.format("%1.1f",12 - (Fiendstart - GetTime()))
					TEXT7:SetText(FiendCooldownString)
					TEXT7:Show()												
				elseif Fiendduration > pseudoGCD then
					Petfirst = 0
					PetPrio = 0
					Texture7:SetVertexColor(0.9, 0.2, 0.2)					
					FiendCooldownString = string.format("%1.1f",FiendCooldown)								
					TEXT7:SetText(FiendCooldownString)	
					TEXT7:Show()
				else
					PetPrio = 1
					Petfirst = 0
					TEXT7:Hide()
				end
			end
		end
	else
		Texture7:Hide()
		TEXT7:Hide()
	end
			
	
	-- Embrace --	
	if showEmbrace then	
		while not finished do
			count = count+1
			local bn,brank,bicon,bcount,bType,bduration,bexpirationTime,bisMine,bisStealable,bshouldConsolidate,bspellId =  UnitBuff("player", count, 0)
			
			if not bn then
				finished = true
			else		
				if bn == nameEmbrace then 
						EmbraceFound = 1
						Embracelefttime = floor((((bexpirationTime-GetTime())*10)+ 0.5))/10				--Time left
						EmbraceLeft = string.format("%1.1f",Embracelefttime)						-- as formated string						
				end
			end
		end			
		Embstart, Embduration, Embenabled = GetSpellCooldown(nameEmbrace);
		EmbraceCooldown = Embstart + Embduration - GetTime()
		if Embstart == 0 then
			Texture8:SetVertexColor(0.1, 0.6, 0.1)	
			Texture8:Show()
			TEXT8:Hide()	
		else			
			if EmbraceFound == 1 then
				Texture8:SetVertexColor(1.0, 1.0, 1.0)
				Texture8:Show()
				TEXT8:SetText(EmbraceLeft)	
				TEXT8:Show()
			else	
				Texture8:SetVertexColor(0.9, 0.2, 0.2)	
				Texture8:Show()			
				EmbraceCooldownString = string.format("%1.1f",EmbraceCooldown)	
				TEXT8:SetText(EmbraceCooldownString)
				TEXT8:Show()
			end
		end
	end
return 
end


function CheckFocusTargetDeBuffs()
	local finished = false
	local count = 0
	local TouchFound = 0
	local TouchLeft = 0
	local WordPainFound = 0
	local WordPainLeft = 0
	local Toutchlefttime = 0	
	local TouchlasttickTime = 0
	local TouchlasttickcastTime = 0
	local ToutchleftMS = 0
	local WordPainlasttickTime = 0
	local WordPainlasttickCastTime = 0

	local name, rank, icon, cost, isFunnel, powerType, castTimeVT, minRange, maxRange = GetSpellInfo(34914)	 -- get castTime
	TouchlasttickTime = castTimeVT*3+WarningTime -- unbuffed 1.5*2 time vonticks + 1.5 cast time
	TouchlasttickcastTime = castTimeVT*3 -- unbuffed 1.5*2 time vonticks + 1.5 cast time)
	WordPainlasttickTime = castTimeVT*2+WarningTime
	WordPainlasttickCastTime = castTimeVT*2  -- unbuffed und nichtgeskilled 3000 ms
	
	while not finished do
		count = count+1
		local bn,brank,bicon,bcount,bType,bduration,bexpirationTime,bisMine,bisStealable,bshouldConsolidate,bspellId =  UnitDebuff("focus", count, 0)
		
		if not bn then
			finished = true
		else		
			if bisMine == "player" then
				if bn == nameTouch then 
					TouchFound = 1 
					Toutchlefttime = floor((((bexpirationTime-GetTime())*10)+ 0.5))/10				--Time left
					TouchLeft = string.format("%1.1f",Toutchlefttime)							-- as formated string
					ToutchleftMS = Toutchlefttime*1000				
					ToutchleftMSSafe = ToutchleftMS-WarningTime				
				end
				if bn == nameWordPain then 
					WordPainFound = 1
					WordPainlefttime = floor((((bexpirationTime-GetTime())*10)+ 0.5))/10
					WordPainLeft = string.format("%1.1f",floor((((bexpirationTime-GetTime())*10)+ 0.5))/10)  
					WordPainleftMS = WordPainlefttime*1000
				end
			end
		end
	end
	if TouchFound == 1 then
		Texture9:Show()
		if  ToutchleftMS < TouchlasttickTime then
			if ToutchleftMS < TouchlasttickcastTime then
				Texture9:SetVertexColor(0.1, 0.6, 0.1);
			else 
				Texture9:SetVertexColor(0.9, 0.2, 0.2);
			end
		else
			Texture9:SetVertexColor(1.0, 1.0, 1.0);
		end
		TEXT9:SetText(TouchLeft)
		TEXT9:Show()	
		
	else
		TEXT9:Hide()
		Texture9:Hide()
	end
	
	if WordPainFound == 1 then
		Texture10:Show()
		if  WordPainleftMS < WordPainlasttickTime then
			if WordPainleftMS < WordPainlasttickCastTime  then
				Texture10:SetVertexColor(0.1, 0.6, 0.1);
			else 
				Texture10:SetVertexColor(0.9, 0.2, 0.2);
			end
		else
			Texture10:SetVertexColor(1.0, 1.0, 1.0);
		end
		TEXT10:SetText(WordPainLeft)
		TEXT10:Show()
	else
		Texture10:Hide()
		TEXT10:Hide()
	end
return 
end

	-- check if priest and shadow specc -- 
function checkShadowPriest()
	local locClass, engClass = UnitClass("player");
	local currentSpec = GetSpecialization();
	if( engClass == "PRIEST") and (currentSpec == 3) then
		ShadowTimerFrame:Show()
		return true
	else
		ShadowTimerFrame:Hide()
		return false
	end		
end

	-- check for various talents --
function talentCheck()
	-- Mindbender -- 
	name, texture, tier, column, selected, available = GetTalentInfo(8)	
	if selected then
		useMindBender = true
	else
		useMindBender = false
	end
	
	-- FDCL --
	name, texture, tier, column, selected, available = GetTalentInfo(7)
	if selected then
		useFDCL = true
	else
		useFDCL = false
	end		
end



SLASH_SHADOWTIMERS1, SLASH_SHADOWTIMERS2 = '/st', '/ShadowTimer';
local function SLASH_SHADOWTIMERShandler(msg, editbox)
	if msg == 'show' then
		ShadowTimerFrame:Show()
	elseif  msg == 'hide' then
		ShadowTimerFrame:Hide()
	elseif  msg == 'reset' then
		ShadowTimerFrame:Hide()
		ShadowTimerFrame:Show()	
	elseif  msg == 'ncm' then	
		ShadowTimerFrame:Hide()	
		ShadowTimerFrame:EnableMouse(false);
		ShadowTimerFrame:SetBackdrop(nil);
		STmode = 1
	elseif  msg == 'cm' then	
		ShadowTimerFrame:Show()
		ShadowTimerFrame:EnableMouse(true);
		ShadowTimerFrame:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", edgeFile= "Interface/Tooltips/UI-Tooltip-Border", edgeSize = 4, tile = false, tileSize =16, insets = { left = 0, right = 0, top = 0, bottom = 0 }});
		STmode = 2
	elseif  msg == 'hideOOC' then
		if ( not inCombat) then
		ShadowTimerFrame:Hide()
		end
		hideOOC = true;
	elseif  msg == 'showOOC' then
		ShadowTimerFrame:Show()	
		hideOOC = false;
	elseif  msg == 'hideMB' then
		showMB = false;
		Texture4:Hide();
		TEXT4:Hide();
	elseif  msg == 'showMB' then
		showMB = true;
		Texture4:Show();
		TEXT4:Show();
	elseif  msg == 'hideSWD' then
		showSWD = false;
		Texture5:Hide();
		TEXT5:Hide();
	elseif  msg == 'showSWD' then
		showSWD = true;
		Texture5:Show();
		TEXT5:Show();
	elseif  msg == 'hideSpike' then
		showSpike = false;
		Texture6:Hide();
		TEXT6:Hide();
	elseif  msg == 'showSpike' then
		showSpike = true;
		Texture6:Show();
		TEXT6:Show();
	elseif  msg == 'hidePet' then
		showPet = false;
		Texture7:Hide();
		TEXT7:Hide();
	elseif  msg == 'showPet' then
		showPet = true;
		Texture7:Show();
		TEXT7:Show();
	elseif  msg == 'hideVE' then
		showEmbrace = false;
		Texture8:Hide();
		TEXT8:Hide();
	elseif  msg == 'showVE' then
		showEmbrace = true;
		Texture8:Show();
		TEXT8:Show();
	elseif  msg == 'hideFocus' then
		showFocus = false;
	elseif  msg == 'showFocus' then
		showFocus = true;
	elseif msg ==  'showPrio' then
		showPrio = true;
		Texture11:Show();
		Texture12:Show();
	elseif msg ==  'hidePrio' then
		showPrio = false;
		Texture11:Hide();
		Texture12:Show();
	elseif  msg == 'hideAll' then
		showMB = false;
		showSWD = false;
		showVE = false;
		showFocus = false;
		showEmbrace = false;
		showPet = false;
		showSpike = false;
	    showPrio = false;
		hideOOC = true;		
	elseif  msg == 'showAll' then
		showMB = true;
		showSWD = true;
		showVE = true;
		showFocus = true;			
		showEmbrace = true;
		showPet = true;
		showSpike = true;
		showPrio = true;
		hideOOC = false;
	elseif  msg == 'scale1' then
		ShadowtimerScaleFrame = 0.5
		ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
	elseif  msg == 'scale2' then
		ShadowtimerScaleFrame = 0.6
		ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
	elseif  msg == 'scale3' then
		ShadowtimerScaleFrame = 0.7
		ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
	elseif  msg == 'scale4' then
		ShadowtimerScaleFrame = 0.8
		ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
	elseif  msg == 'scale5' then
		ShadowtimerScaleFrame = 0.9
		ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
	elseif  msg == 'scale6' then
		ShadowtimerScaleFrame = 1.0
		ShadowTimerFrame:SetScale(ShadowtimerScaleFrame);
	else
	   print("Syntax: /st (show | hide | reset | cm | ncm)");
	   print("Syntax: /st (scale1 - scale6)");
	   print("Syntax: /st (hideMB|SWD|Focus|OOC|VE|All|Pet|Spike|Prio)");
	   print("Syntax: /st (showMB|SWD|Focus|OOC|VE|All|Pet|Spike|Prio)");
	end
end
SlashCmdList["SHADOWTIMERS"] = SLASH_SHADOWTIMERShandler;






