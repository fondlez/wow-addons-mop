Yellowjacket Truetype Font for Windows

2002 Iconian Fonts - Daniel Zadorozny

http://www.iconian.com/

This font comes with the following 7 versions: Regular, Italic, Expanded, Condensed, Rotate, Shadow and Bitmap (.fon).

This font has several alternate characters in the upper and lower cases.

This font may be freely distributed and is free for all non-commercial uses.  This font is e-mailware; that is, if you like it, please e-mail the author at:

iconian@aol.com