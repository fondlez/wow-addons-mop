if not Skinner:isAddonEnabled("MonkeyQuestLog") then return end

function Skinner:MonkeyQuestLog()

	self:applySkin(MkQL_Main_Frame)

end
