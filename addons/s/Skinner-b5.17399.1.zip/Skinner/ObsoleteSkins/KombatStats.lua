
function Skinner:KombatStats()

	self:applySkin(KombatStatsFrame)
	if KombatStats.dpsButton then
		self:applySkin(KombatStats.dpsButton)
	end

end
