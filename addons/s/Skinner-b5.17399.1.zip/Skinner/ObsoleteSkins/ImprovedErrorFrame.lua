
function Skinner:ImprovedErrorFrame()

	self:applySkin(ImprovedErrorFrameCloseButton)
	self:applySkin(ImprovedErrorFrameFrame)

end
