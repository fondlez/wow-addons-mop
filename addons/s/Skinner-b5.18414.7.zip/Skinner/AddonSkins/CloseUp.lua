if not Skinner:isAddonEnabled("CloseUp") then return end
-- thanks to sixthepaladin

function Skinner:CloseUp()

	self:skinButton{obj=CloseUpUndressButton}

end
