if not Skinner:isAddonEnabled("Ara_Broker_Guild_Friends") then return end

function Skinner:Ara_Broker_Guild_Friends()

	self:addSkinFrame{obj=AraBrokerGuildFriends}

end
