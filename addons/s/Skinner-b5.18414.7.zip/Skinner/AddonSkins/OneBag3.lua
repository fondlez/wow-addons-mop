if not Skinner:isAddonEnabled("OneBag3") then return end

function Skinner:OneBag3()

	self:applySkin(OneBagFrame)
	self:applySkin(OneBagSideFrame)

end

function Skinner:OneBank3()

	self:applySkin(OneBankFrame)
	self:applySkin(OneBankSideFrame)
	self:applySkin(OneBankPurchaseFrame)

end
