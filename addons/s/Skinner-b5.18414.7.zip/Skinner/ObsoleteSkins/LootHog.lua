
function Skinner:LootHog()

	self:applySkin(loothog_main)
	self:skinEditBox(loothog_configTimeout, {9})
	self:skinEditBox(loothog_configAnnouncement, {9})
	self:applySkin(loothog_config)

end
