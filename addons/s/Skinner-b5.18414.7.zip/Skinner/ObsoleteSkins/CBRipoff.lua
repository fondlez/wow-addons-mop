
function Skinner:CBRipoff()

	self:applySkin(CBRipoffFrame)
	self:glazeStatusBar(CBRipoffFrame.Bar)
	self:applySkin(CBRipoffMirror1)
	self:glazeStatusBar(CBRipoffMirror1.Bar)
	self:applySkin(CBRipoffMirror2)
	self:glazeStatusBar(CBRipoffMirror2.Bar)
	self:applySkin(CBRipoffMirror3)
	self:glazeStatusBar(CBRipoffMirror3.Bar)

end
