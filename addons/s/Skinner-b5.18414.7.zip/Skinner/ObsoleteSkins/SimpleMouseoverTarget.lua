
function Skinner:SimpleMouseoverTarget()

	self:glazeStatusBar(SMouseTargetStatusBar, 0)
	self:applySkin(SMouseTarget)

end
