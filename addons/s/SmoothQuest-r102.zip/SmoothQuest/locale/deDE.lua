﻿local L = LibStub("AceLocale-3.0"):NewLocale("SmoothQuest", "deDE")

if not L then return end

L["Smooth Quest"] = "Smooth Quest"

L["Sound Configuration"] = "Soundkonfiguration"
L["Configure the sounds you want to hear with the toggles below."] = "Mit den untenstehenden Optionen kannst du bestimmen, welche Sounds abgespielt werden."

L["More Work?!"] = "More Work?!"
L["Toggle playing the 'More Work?!' sound after completing an objective."] = "Schaltet den Sound 'More Work?!' an oder aus, den du hörst, wenn du ein Teilziel erreichst."

L["Job's Done!"] = "Job's Done!"
L["Toggle playing the 'Job's Done!' sound after completing a quest."] = "Schaltet den Sound 'More Work?!' an oder aus, den du hörst, wenn du eine Quest erledigst."

L["Progress Output"] = "Fortschrittsausgabe"
L["You can select where you want progress messages displayed using the options below."] = "Mit den untenstehenden Optionen kannst du bestimmen, wo Nachrichten über den Questfortschritt angezeigt werden."