local L = LibStub("AceLocale-3.0"):NewLocale("SmoothQuest", "frFR")

if not L then return end

L["Smooth Quest"] = "Smooth Quest"

L["Progress Output"] = "Sortie de la progression"
L["You can select where you want progress messages displayed using the options below."] = "Vous pouvez choisir où vous voulez que les messages de progression soient affichés en utilisant les options ci-dessous."
