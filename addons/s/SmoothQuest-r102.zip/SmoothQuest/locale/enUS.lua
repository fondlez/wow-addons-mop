local L = LibStub("AceLocale-3.0"):NewLocale("SmoothQuest", "enUS", true)

if not L then return end

L["Smooth Quest"] = true

L["Sound Configuration"] = true
L["Configure the sounds you want to hear with the toggles below."] = true

L["More Work?!"] = true
L["Toggle playing the 'More Work?!' sound after completing an objective."] = true

L["Job's Done!"] = true
L["Toggle playing the 'Job's Done!' sound after completing a quest."] = true

L["Progress Output"] = true
L["You can select where you want progress messages displayed using the options below."] = true
