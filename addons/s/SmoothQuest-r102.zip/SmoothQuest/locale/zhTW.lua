﻿local L = LibStub("AceLocale-3.0"):NewLocale("SmoothQuest", "zhTW")

if not L then return end

L["Smooth Quest"] = true

L["Sound Configuration"] = "聲音設置"
L["Configure the sounds you want to hear with the toggles below."] = "切換以下來設置要聽取的聲音"

L["More Work?!"] = "More Work?!"
L["Toggle playing the 'More Work?!' sound after completing an objective."] = "切換當完成目標時'More Work?!'聲音."

L["Job's Done!"] = "Job's Done!"
L["Toggle playing the 'Job's Done!' sound after completing a quest."] = "切換當完成任務時'Job's Done!'聲音."

L["Progress Output"] = "進度輸出"
L["You can select where you want progress messages displayed using the options below."] = "您可以從下面的選項來選擇您想要使用的進度信息顯示."
