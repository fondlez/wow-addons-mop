local _, Simulationcraft = ...


local L = LibStub("AceLocale-3.0"):NewLocale("Simulationcraft", "enUS", true)

-- General options
L["General"] = true

L["Use Compact Output"] = true
L["UseCompactOutputDescription"] = "Use item-id output sytle\n(newer, faster, slightly less error prone)"

L["SocketBonusPrefix"] = "Socket Bonus: ";
L["EnchantBonusPrefix"] = "Enchanted: ";