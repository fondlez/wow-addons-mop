-- If you aren't a rogue/druid, then disable the addon
if select(2, UnitClass("player")) ~= "ROGUE" and select(2, UnitClass("player")) ~= "DRUID" then
	return
end


local f = CreateFrame("frame")
local max_combo_points = 5
local xpos = 0
local ypos = 0
local r = 0.9686274509803922
local g = 0.674509803921568
local b = 0.1450980392156863
local scale = 1
local hidenocombat = false
local leftanchor = "CENTER"
local cpframes = {}
local apframes = {}
local locked_by_druid_form = false
local currently_shown = true

local anticipation_enabled = true
local anticipation_r = 0.9
local anticipation_g = 0.05
local anticipation_b = 0.15
local anticipation_scale = 1
local anticipation_position = "above"
local apframes_shown = false

local anticipation_name = "Anticipation"

f:SetScript("OnEvent", function(self, event, ...)
    self[event](self, ...)
end)

local function refreshDisplayState()
	if locked_by_druid_form then
		return
	end

	if not InCombatLockdown() and GetComboPoints("player") == 0 and hidenocombat then
		for i = 1,max_combo_points do
			cpframes[i]:Hide()
		end
		currently_shown = false
	else
		if not currently_shown then
			for i = 1,max_combo_points do
				cpframes[i]:Show()
			end
			currently_shown = true
		end
	end
end

local function updateCP()
	local power = GetComboPoints("player")
	local i = 1

	while i <= power do
		cpframes[i]:SetBackdropColor(r, g, b, 1)
		i = 1 + i
	end

	while i <= max_combo_points do
		cpframes[i]:SetBackdropColor(r, g, b, 0.1)
		i = 1 + i
	end

	if hidenocombat then
		refreshDisplayState()
	end

	if currently_shown and anticipation_enabled then
		local _, _, _, count =  UnitAura("player", anticipation_name)

		if count == nil then
			count = 0
		end

		if count == 0 and apframes_shown == true then
			for i = 1,max_combo_points do
				apframes[i]:Hide()
			end
			apframes_shown = false
		end

		if count > 0 and apframes_shown == false then
			for i = 1,max_combo_points do
				apframes[i]:Show()
			end
			apframes_shown = true
		end

		if apframes_shown then
			local ai = 1

			while ai <= count do
				apframes[ai]:SetBackdropColor(anticipation_r, anticipation_g, anticipation_b, 1)
				ai = 1 + ai
			end	

			while ai <= max_combo_points do
				apframes[ai]:SetBackdropColor(anticipation_r, anticipation_g, anticipation_b, 0.1)
				ai = 1 + ai
			end
			
		end

	end
end


local function updateFrames()
	for i = 1,max_combo_points do
		cpframes[i]:SetSize(22, 22)

		cpframes[i]:SetBackdropColor(r, g, b, 0.1)
		cpframes[i]:SetBackdropBorderColor(0, 0, 0, 1)
	 
		if i == 1 then
			cpframes[i]:SetPoint(leftanchor, UIParent, leftanchor, xpos, ypos)
			cpframes[i]:SetScale(scale)

			cpframes[i]:SetMovable(true)
			cpframes[i]:EnableMouse(true)
			cpframes[i]:RegisterForDrag("LeftButton")
			cpframes[i]:SetScript("OnDragStart", function(self)
				if IsAltKeyDown() then
					self:StartMoving()
				end
			end)
			cpframes[i]:SetScript("OnDragStop", function(self)
				self:StopMovingOrSizing()
				anch,_, _, x, y = self:GetPoint(1)
				xpos = x
				SimpleComboPointsDB.xpos = x
				xpos = y
				SimpleComboPointsDB.ypos = y
				leftanchor = anch
				SimpleComboPointsDB.leftanchor = anch

			end)
			

		else
			cpframes[i]:SetPoint("RIGHT", 23, 0)

		end

		cpframes[i]:Show()

	end

	if anticipation_position ~= "off" and anticipation_enabled then

		local r_offset = 0
		for i = 1,max_combo_points do
			apframes[i]:SetSize(22*anticipation_scale, 22*anticipation_scale)

			apframes[i]:SetBackdropColor(anticipation_r, anticipation_g, anticipation_b, 0.1)
			apframes[i]:SetBackdropBorderColor(0, 0, 0, 1)
		 
			if i == 1 then


				if anticipation_position == "above" then
					r_offset = 0
				else
					r_offset = 46
				end


				apframes[i]:SetPoint("TOP", cpframes[1], "TOP", 0, 23-r_offset)
				

			else
				apframes[i]:SetPoint("RIGHT", 23, 0)

			end
			apframes[i]:Hide()

		end
		apframes_shown = false
	end


	updateCP()
end

local function initFrames()
	for i = 1,max_combo_points do
		cpframes[i] = CreateFrame("Frame", "SCPFrame"..i, i == 1 and UIParent or cpframes[i-1])
		cpframes[i]:SetBackdrop({bgFile=[[Interface\ChatFrame\ChatFrameBackground]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=4,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})

	end

	for i = 1,max_combo_points do
		apframes[i] = CreateFrame("Frame", "ASCPFrame"..i, i == 1 and cpframes[1] or apframes[i-1])
		apframes[i]:SetBackdrop({bgFile=[[Interface\ChatFrame\ChatFrameBackground]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=4,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})

	end

	updateFrames()
end

local function destroyFrames()
	for i = 1,max_combo_points do
		cpframes[i]:Hide()
		cpframes[i] = nil
	end
	cpframes = {}
end

function CPColorPickCallback(restore)
	if restore then
		r, g, b = unpack(restore)
	else
		r, g, b = ColorPickerFrame:GetColorRGB();
	end
	
	SimpleComboPointsDB.r = r
	SimpleComboPointsDB.g = g
	SimpleComboPointsDB.b = b

	updateFrames()
end

function A_CPColorPickCallback(restore)
	if restore then
		anticipation_r, anticipation_g, anticipation_b = unpack(restore)
	else
		anticipation_r, anticipation_g, anticipation_b = ColorPickerFrame:GetColorRGB();
	end
	
	SimpleComboPointsDB.anticipationr = anticipation_r
	SimpleComboPointsDB.anticipationg = anticipation_g
	SimpleComboPointsDB.anticipationb = anticipation_b

	updateFrames()
end

function f:PLAYER_ENTERING_WORLD()
	updateCP()
end

function f:UNIT_COMBO_POINTS()
	updateCP()
end

function f:UNIT_AURA(unit)
	if unit == "player" then
		updateCP()
	end
end

function f:PLAYER_TARGET_CHANGED()
	updateCP()
end

function f:UPDATE_SHAPESHIFT_FORM()
	if GetShapeshiftForm() == 3 then
		for i = 1,max_combo_points do
			cpframes[i]:Show()
		end
		locked_by_druid_form = false
	else
		for i = 1,max_combo_points do
			cpframes[i]:Hide()
		end
		locked_by_druid_form = true
	end
	updateCP()
end

function f:PLAYER_REGEN_ENABLED()
	refreshDisplayState()
end


function f:ADDON_LOADED(addon)
	if addon ~= "SimpleComboPoints" then return end
	if select(2, UnitClass("player")) ~= "ROGUE" and select(2, UnitClass("player")) ~= "DRUID" then
		return
	end

	local defaults = {
		xpos = 0,
		ypos = 0,
		r = 0.9686274509803922,
		g = 0.6745098039215687,
		b = 0.1450980392156863,
		scale = 1,
		leftanchor = "CENTER",
		hidenocombat = false, 
		anticipationenabled = true,
		anticipationr = 0.9,
		anticipationg = 0.05,
		anticipationb = 0.15,
		anticipationscale = 1,
		anticipationposition = "above"

	}
		
	SimpleComboPointsDB = SimpleComboPointsDB or {}
		
	for k,v in pairs(defaults) do
		if SimpleComboPointsDB[k] == nil then
			SimpleComboPointsDB[k] = v
		end
	end


	SLASH_SCP1, SLASH_SCP2 = "/scp", "/simplecombopoints"
	SlashCmdList.SCP = function(txt)
		local cmd, msg = txt:match("^(%S*)%s*(.-)$");
		cmd = string.lower(cmd)
		msg = string.lower(msg)

		if cmd == "reset" then
			xpos = 0
			ypos = 0
			r = 0.9686274509803922
			g = 0.674509803921568
			b = 0.1450980392156863
			scale = 1
			leftanchor = "CENTER"
			SimpleComboPointsDB.xpos = 0
			SimpleComboPointsDB.ypos = 0
			SimpleComboPointsDB.r = 0.9686274509803922
			SimpleComboPointsDB.g = 0.674509803921568
			SimpleComboPointsDB.b = 0.1450980392156863
			SimpleComboPointsDB.scale = 1
			SimpleComboPointsDB.leftanchor = "CENTER"
			
			anticipation_r = 0.9
			anticipation_g = 0.05
			anticipation_b = 0.15
			anticipation_scale = 1
			anticipation_position = "above"

			SimpleComboPointsDB.anticipationr = 0.9
			SimpleComboPointsDB.anticipationg = 0.05
			SimpleComboPointsDB.anticipationb = 0.15
			SimpleComboPointsDB.anticipationscale = 1
			SimpleComboPointsDB.anticipationposition = "above"

				
			destroyFrames()
			initFrames()

			print("Frame reset to the center, you can now move it to the desired position.")

		elseif cmd == "scale" then
			local num = tonumber(msg)
			if num then
				scale = num
				SimpleComboPointsDB.scale = num

				updateFrames()
			else
				print("Not a valid scale! Scale has to be a number, recommended to be between 0.5 and 3")
			end
		elseif cmd == "anticipation_scale" then
			local num = tonumber(msg)
			if num then
				anticipation_scale = num
				SimpleComboPointsDB.anticipationscale = num

				updateFrames()
			else
				print("Not a valid scale! Scale has to be a number, recommended to be between 0.5 and 3")
			end
		elseif cmd == "anticipation_position" then
			if msg == "above" then
				anticipation_position = "above"
				SimpleComboPointsDB.anticipationposition = "above"
				anticipation_enabled = true
			elseif msg == "below" then
				anticipation_position = "below"
				SimpleComboPointsDB.anticipationposition = "below"
				anticipation_enabled = true
			elseif msg == "off" then
				anticipation_position = "off"
				SimpleComboPointsDB.anticipationposition = "off"
				anticipation_enabled = false
				for i = 1,max_combo_points do
					apframes[i]:Hide()
				end
			else
				print("Invalid position. The position has to be above, below or off.")	
			end

			updateFrames()	
		elseif cmd == "color" or cmd == "colour" then
			ColorPickerFrame:SetColorRGB(r,g,b)
			ColorPickerFrame.previousValues = {r,g,b}
			ColorPickerFrame.func, ColorPickerFrame.opacityFunc, ColorPickerFrame.cancelFunc = CPColorPickCallback, CPColorPickCallback, CPColorPickCallback
			ColorPickerFrame:Hide() -- apparently needed...
			ColorPickerFrame:Show()
			updateFrames()
		elseif cmd == "anticipation_color" or cmd == "anticipation_colour" then
			ColorPickerFrame:SetColorRGB(anticipation_r,anticipation_g,anticipation_b)
			ColorPickerFrame.previousValues = {anticipation_r,anticipation_g,anticipation_b}
			ColorPickerFrame.func, ColorPickerFrame.opacityFunc, ColorPickerFrame.cancelFunc = A_CPColorPickCallback, A_CPColorPickCallback, A_CPColorPickCallback
			ColorPickerFrame:Hide() -- apparently needed...
			ColorPickerFrame:Show()
			updateFrames()
		elseif cmd  == "nocombat" then
			if msg == "on" then
				hidenocombat = false
				SimpleComboPointsDB.hidenocombat = false
				refreshDisplayState()
			elseif msg == "off" then
				hidenocombat = true
				SimpleComboPointsDB.hidenocombat = true
				refreshDisplayState()
			else
				print("|cffff0000Invalid command!|r Use |cff3399FF/scp nocombat off|r or |cff3399FF/scp nocombat on|r")
			end
		else
			print("|cff3399FF/scp|r usage:")
			print("|cff3399FF/scp reset|r Resets the addon back to default settings. Use if you can't see the frame and/or dragged it out of the screen.")
			print("|cff3399FF/scp color|r Open the color picker window.")
			print("|cff3399FF/scp scale|r Change the scale of the addon (default: 1, don't use values larger than 3)")
			print("|cff3399FF/scp nocombat|r |cff00cf00on|r | |cffff0000off|r Whether the boxes should be shown outside combat or not.")
			print("|cff3399FF/scp anticipation_color|r Open the anticipation color picker window.")
			print("|cff3399FF/scp anticipation_scale|r Change the scale of the anticipation boxes.")
			print("|cff3399FF/scp anticipation_position above|below|off |r Change the postition of the anticipation boxes relative the combo point boxes.")
			print("|cff33FF99To move the boxes:|r Alt+Left mouse button on the leftmost box to drag it.")
		end

	end

	xpos = SimpleComboPointsDB.xpos
	ypos = SimpleComboPointsDB.ypos
	r = SimpleComboPointsDB.r
	g = SimpleComboPointsDB.g
	b = SimpleComboPointsDB.b
	scale = SimpleComboPointsDB.scale
	leftanchor = SimpleComboPointsDB.leftanchor
	hidenocombat = SimpleComboPointsDB.hidenocombat

	anticipation_r = SimpleComboPointsDB.anticipationr
	anticipation_g = SimpleComboPointsDB.anticipationg
	anticipation_b = SimpleComboPointsDB.anticipationb
	anticipation_scale = SimpleComboPointsDB.anticipationscale
	anticipation_position = SimpleComboPointsDB.anticipationposition

	local locale = GetLocale()
	if locale == "ruRU" then
		anticipation_name = "Предчувствие"
	elseif locale == "deDE" then
		anticipation_name = "Erwartung"
	elseif locale == "esES" or locale == "esMX" then
		anticipation_name = "Anticipación"
	elseif locale == "ptBR" then
		anticipation_name = "Antecipação"
	else
		anticipation_name = "Anticipation"
	end


	initFrames()
	f:RegisterEvent("UNIT_COMBO_POINTS")
	f:RegisterEvent("PLAYER_ENTERING_WORLD")
	f:RegisterEvent("PLAYER_TARGET_CHANGED")
	f:RegisterEvent("PLAYER_REGEN_ENABLED")

	if select(2, UnitClass("player")) == "DRUID" then
		f:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
		f:UPDATE_SHAPESHIFT_FORM()
		anticipation_enabled = false
	else
		f:RegisterEvent("UNIT_AURA")
	end



end

f:RegisterEvent("ADDON_LOADED")

