local ADDON_NAME = ...

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_NAME, "ptBR", false);

if not L then return end

L["Bytes"] = true -- Needs review
L["Messages"] = "Mensagens" -- Needs review
L["Minimap Icon"] = "Icone do Minimapa" -- Needs review
L["Received"] = "Recebido" -- Needs review
L["Sent"] = "Enviado" -- Needs review

