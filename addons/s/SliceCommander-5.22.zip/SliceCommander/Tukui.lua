-- Come frome Tukui API, thanks to him
-- See tukui at www.tukui.org
function SliceCommander_LoadTukuiApi()
	local noop = function() return end
	local floor = math.floor
	local class = "ROGUE"
	local texture = "Interface\\AddOns\\SliceCommander\\Images\\solid.tga"
	local backdropr, backdropg, backdropb = .1, .1, .1
	local borderr, borderg, borderb = .6, .6, .6
	local backdropa = 1
	local bordera = 1
	local template
	local inset = 0

	-- pixel perfect script of custom ui Scale.
	local resolution = GetCVar("gxResolution")
	local height = tonumber(string.match(GetCVar("gxResolution"), "%d+x(%d+)"))
	local width = tonumber(string.match(GetCVar("gxResolution"), "(%d+)x+%d"))
	local uiscale = min(2, max(.64, 768/string.match(resolution, "%d+x(%d+)")))
	local mult = 768/string.match(GetCVar("gxResolution"), "%d+x(%d+)")/uiscale


	local ScaleFunc = function(x)
		return mult*math.floor(x/mult+.5)
	end
	local ScaleFuncW = function(w)
		return w*(UIParent:GetWidth()/width)
	end
	local ScaleFuncH = function(h)
		return h*(UIParent:GetHeight()/height)
	end

	if noinset then inset = mult end

	--SetCVar("useUiScale", 1)
	SetMultisampleFormat(1)

	local function UpdateColor(t)
		if t == template then return end

		local balpha = 1
		if t == "Transparent" then balpha = 0.8 end
		borderr, borderg, borderb = .6, .6, .6
		backdropr, backdropg, backdropb = .1, .1, .1
		backdropa = balpha

		template = t
	end

	---------------------------------------------------
	-- TUKUI API START HERE
	---------------------------------------------------

	local function Size(frame, width, height)
		frame.width = width
		frame.height = height
		frame:SetSize(ScaleFuncW(width), ScaleFuncH(height or width))
	end

	local function Width(frame, width)
		frame.width = width
		frame:SetWidth(ScaleFuncW(width))
	end

	local function Height(frame, height)
		frame.height = height
		frame:SetHeight(ScaleFuncH(height))
	end

	local function AddSize(frame, width, realWidth, height, realHeight)
		frame:SetSize(ScaleFuncW(realWidth)+width, ScaleFuncH(realHeight or realWidth)+(height or width))
	end

	local function AddWidth(frame, width, realWidth)
		frame:SetWidth(ScaleFuncW(realWidth)+width)
	end

	local function AddHeight(frame, height, realHeight)
		frame:SetHeight(ScaleFuncH(realHeight)+height)
	end

	local function Point(obj, arg1, arg2, arg3, arg4, arg5)
		-- anyone has a more elegant way for this?
		if type(arg1)=="number" then arg1 = ScaleFunc(arg1) end
		if type(arg2)=="number" then arg2 = ScaleFunc(arg2) end
		if type(arg3)=="number" then arg3 = ScaleFunc(arg3) end
		if type(arg4)=="number" then arg4 = ScaleFuncW(arg4) end
		if type(arg5)=="number" then arg5 = ScaleFuncH(arg5) end

		obj:SetPoint(arg1, arg2, arg3, arg4, arg5)
	end

	local function SetOutside(obj, anchor, xOffset, yOffset)
		xOffset = xOffset or 2
		yOffset = yOffset or 2
		anchor = anchor or obj:GetParent()

		if obj:GetPoint() then obj:ClearAllPoints() end

		obj:Point("TOPLEFT", anchor, "TOPLEFT", -xOffset, yOffset)
		obj:Point("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", xOffset, -yOffset)
	end

	local function SetInside(obj, anchor, xOffset, yOffset)
		xOffset = xOffset or 2
		yOffset = yOffset or 2
		anchor = anchor or obj:GetParent()

		if obj:GetPoint() then obj:ClearAllPoints() end

		obj:Point("TOPLEFT", anchor, "TOPLEFT", xOffset, -yOffset)
		obj:Point("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", -xOffset, yOffset)
	end

	local function SetTemplate(f, t, tex)
		if tex then
			texture = "Interface\\AddOns\\SliceCommander\\Images\\Tukui.tga"
		else
			texture = "Interface\\AddOns\\SliceCommander\\Images\\solid.tga"
		end

		UpdateColor(t)

		f:SetBackdrop({
			bgFile = texture,
			edgeFile = "Interface\\AddOns\\SliceCommander\\Images\\solid.tga",
			tile = false, tileSize = 0, edgeSize = mult,
		})

		if not noinset and not f.isInsetDone then
			f.insettop = f:CreateTexture(nil, "BORDER")
			f.insettop:Point("TOPLEFT", f, "TOPLEFT", -1, 1)
			f.insettop:Point("TOPRIGHT", f, "TOPRIGHT", 1, -1)
			f.insettop:Height(1)
			f.insettop:SetTexture(0,0,0)
			f.insettop:SetDrawLayer("BORDER", -7)

			f.insetbottom = f:CreateTexture(nil, "BORDER")
			f.insetbottom:Point("BOTTOMLEFT", f, "BOTTOMLEFT", -1, -1)
			f.insetbottom:Point("BOTTOMRIGHT", f, "BOTTOMRIGHT", 1, -1)
			f.insetbottom:Height(1)
			f.insetbottom:SetTexture(0,0,0)
			f.insetbottom:SetDrawLayer("BORDER", -7)

			f.insetleft = f:CreateTexture(nil, "BORDER")
			f.insetleft:Point("TOPLEFT", f, "TOPLEFT", -1, 1)
			f.insetleft:Point("BOTTOMLEFT", f, "BOTTOMLEFT", 1, -1)
			f.insetleft:Width(1)
			f.insetleft:SetTexture(0,0,0)
			f.insetleft:SetDrawLayer("BORDER", -7)

			f.insetright = f:CreateTexture(nil, "BORDER")
			f.insetright:Point("TOPRIGHT", f, "TOPRIGHT", 1, 1)
			f.insetright:Point("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, -1)
			f.insetright:Width(1)
			f.insetright:SetTexture(0,0,0)
			f.insetright:SetDrawLayer("BORDER", -7)

			f.insetinsidetop = f:CreateTexture(nil, "BORDER")
			f.insetinsidetop:Point("TOPLEFT", f, "TOPLEFT", 1, -1)
			f.insetinsidetop:Point("TOPRIGHT", f, "TOPRIGHT", -1, 1)
			f.insetinsidetop:Height(1)
			f.insetinsidetop:SetTexture(0,0,0)
			f.insetinsidetop:SetDrawLayer("BORDER", -7)

			f.insetinsidebottom = f:CreateTexture(nil, "BORDER")
			f.insetinsidebottom:Point("BOTTOMLEFT", f, "BOTTOMLEFT", 1, 1)
			f.insetinsidebottom:Point("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
			f.insetinsidebottom:Height(1)
			f.insetinsidebottom:SetTexture(0,0,0)
			f.insetinsidebottom:SetDrawLayer("BORDER", -7)

			f.insetinsideleft = f:CreateTexture(nil, "BORDER")
			f.insetinsideleft:Point("TOPLEFT", f, "TOPLEFT", 1, -1)
			f.insetinsideleft:Point("BOTTOMLEFT", f, "BOTTOMLEFT", -1, 1)
			f.insetinsideleft:Width(1)
			f.insetinsideleft:SetTexture(0,0,0)
			f.insetinsideleft:SetDrawLayer("BORDER", -7)

			f.insetinsideright = f:CreateTexture(nil, "BORDER")
			f.insetinsideright:Point("TOPRIGHT", f, "TOPRIGHT", -1, -1)
			f.insetinsideright:Point("BOTTOMRIGHT", f, "BOTTOMRIGHT", 1, 1)
			f.insetinsideright:Width(1)
			f.insetinsideright:SetTexture(0,0,0)
			f.insetinsideright:SetDrawLayer("BORDER", -7)

			f.isInsetDone = true
		end

		f:SetBackdropColor(backdropr, backdropg, backdropb, backdropa)
		f:SetBackdropBorderColor(borderr, borderg, borderb)
	end

	local borders = {
		"insettop",
		"insetbottom",
		"insetleft",
		"insetright",
		"insetinsidetop",
		"insetinsidebottom",
		"insetinsideleft",
		"insetinsideright",
	}

	local function HideInsets(f)
		for i, border in pairs(borders) do
			if f[border] then
				f[border]:SetTexture(0,0,0,0)
			end
		end
	end

	local function CreateBackdrop(f, t, tex)
		if f.backdrop then return end
		if not t then t = "Default" end

		local b = CreateFrame("Frame", nil, f)
		b:Point("TOPLEFT", -2 + inset, 2 - inset)
		b:Point("BOTTOMRIGHT", 2 - inset, -2 + inset)
		b:SetTemplate(t, tex)

		if f:GetFrameLevel() - 1 >= 0 then
			b:SetFrameLevel(f:GetFrameLevel() - 1)
		else
			b:SetFrameLevel(0)
		end

		f.backdrop = b
	end

	local function CreateShadow(f, t)
		if f.shadow then return end

		local shadow = CreateFrame("Frame", nil, f)
		shadow:SetFrameLevel(1)
		shadow:SetFrameStrata(f:GetFrameStrata())
		shadow:Point("TOPLEFT", -3, 3)
		shadow:Point("BOTTOMLEFT", -3, -3)
		shadow:Point("TOPRIGHT", 3, 3)
		shadow:Point("BOTTOMRIGHT", 3, -3)
		shadow:SetBackdrop( {
			edgeFile = "Interface\\AddOns\\SliceCommander\\Images\\glowTex.tga", edgeSize = ScaleFunc(3),
			insets = {left = ScaleFuncW(5), right = ScaleFuncW(5), top = ScaleFuncH(5), bottom = ScaleFuncH(5)},
		})
		shadow:SetBackdropColor(0, 0, 0, 0)
		shadow:SetBackdropBorderColor(0, 0, 0, 0.8)
		f.shadow = shadow
	end

	local function Kill(object)
		if object.UnregisterAllEvents then
			object:UnregisterAllEvents()
		end
		object.Show = noop
		object:Hide()
	end

	local function StyleButton(button)
		if button.SetHighlightTexture and not button.hover then
			local hover = button:CreateTexture("frame", nil, self)
			hover:SetTexture(1, 1, 1, 0.3)
			hover:Point("TOPLEFT", 2, -2)
			hover:Point("BOTTOMRIGHT", -2, 2)
			button.hover = hover
			button:SetHighlightTexture(hover)
		end

		if button.SetPushedTexture and not button.pushed then
			local pushed = button:CreateTexture("frame", nil, self)
			pushed:SetTexture(0.9, 0.8, 0.1, 0.3)
			pushed:Point("TOPLEFT", 2, -2)
			pushed:Point("BOTTOMRIGHT", -2, 2)
			button.pushed = pushed
			button:SetPushedTexture(pushed)
		end

		if button.SetCheckedTexture and not button.checked then
			local checked = button:CreateTexture("frame", nil, self)
			checked:SetTexture(0,1,0,.3)
			checked:Point("TOPLEFT", 2, -2)
			checked:Point("BOTTOMRIGHT", -2, 2)
			button.checked = checked
			button:SetCheckedTexture(checked)
		end

		local cooldown = button:GetName() and _G[button:GetName().."Cooldown"]
		if cooldown then
			cooldown:ClearAllPoints()
			cooldown:Point("TOPLEFT", 2, -2)
			cooldown:Point("BOTTOMRIGHT", -2, 2)
		end
	end

	local function FontString(parent, name, fontName, fontHeight, fontStyle)
		local fs = parent:CreateFontString(nil, "OVERLAY")
		fs:SetFont(fontName, fontHeight, fontStyle)
		fs:SetJustifyH("LEFT")
		fs:SetShadowColor(0, 0, 0)
		fs:SetShadowOffset(mult, -mult)

		if not name then
			parent.text = fs
		else
			parent[name] = fs
		end

		return fs
	end

	local function HighlightTarget(self, event, unit)
		if self.unit == "target" then return end
		if UnitIsUnit("target", self.unit) then
			self.HighlightTarget:Show()
		else
			self.HighlightTarget:Hide()
		end
	end

	local function HighlightUnit(f, r, g, b)
		if f.HighlightTarget then return end
		local glowBorder = {edgeFile = "Interface\\AddOns\\SliceCommander\\Images\\solid.tga", edgeSize = 1}
		f.HighlightTarget = CreateFrame("Frame", nil, f)
		f.HighlightTarget:Point("TOPLEFT", f, "TOPLEFT", -2, 2)
		f.HighlightTarget:Point("BOTTOMRIGHT", f, "BOTTOMRIGHT", 2, -2)
		f.HighlightTarget:SetBackdrop(glowBorder)
		f.HighlightTarget:SetFrameLevel(f:GetFrameLevel() + 1)
		f.HighlightTarget:SetBackdropBorderColor(r,g,b,1)
		f.HighlightTarget:Hide()
		f:RegisterEvent("PLAYER_TARGET_CHANGED", HighlightTarget)
	end

	local function StripTextures(object, kill)
		for i=1, object:GetNumRegions() do
			local region = select(i, object:GetRegions())
			if region:GetObjectType() == "Texture" then
				if kill then
					region:Kill()
				else
					region:SetTexture(nil)
				end
			end
		end
	end

	---------------------------------------------------
	-- TUKUI API STOP HERE
	---------------------------------------------------

	---------------------------------------------------
	-- MERGE TUKUI API WITH WOW API
	---------------------------------------------------

	local function addapi(object)
		local mt = getmetatable(object).__index
		if not object.SCSize then mt.SCSize = Size end
		if not object.SCPoint then mt.SCPoint = Point end
		if not object.SCSetOutside then mt.SCSetOutside = SetOutside end
		if not object.SCSetInside then mt.SCSetInside = SetInside end
		if not object.SCSetTemplate then mt.SCSetTemplate = SetTemplate end
		if not object.SCCreateBackdrop then mt.SCCreateBackdrop = CreateBackdrop end
		if not object.SCStripTextures then mt.SCStripTextures = StripTextures end
		if not object.SCCreateShadow then mt.SCCreateShadow = CreateShadow end
		if not object.SCKill then mt.SCKill = Kill end
		if not object.SCStyleButton then mt.SCStyleButton = StyleButton end
		if not object.SCWidth then mt.SCWidth = Width end
		if not object.SCHeight then mt.SCHeight = Height end
		if not object.SCFontString then mt.SCFontString = FontString end
		if not object.SCHighlightUnit then mt.SCHighlightUnit = HighlightUnit end
		if not object.SCHideInsets then mt.SCHideInsets = HideInsets end
		if not object.SCAddWidth then mt.AddSizeWidth = AddWidth end
		if not object.SCAddHeight then mt.AddSizeHeight = AddHeight end
		if not object.SCAddSize then mt.AddSize = AddSize end
	end

	local handled = {["Frame"] = true}
	local object = CreateFrame("Frame")
	addapi(object)
	addapi(object:CreateTexture())
	addapi(object:CreateFontString())

	object = EnumerateFrames()
	while object do
		if not handled[object:GetObjectType()] then
			addapi(object)
			handled[object:GetObjectType()] = true
		end

		object = EnumerateFrames(object)
	end
end