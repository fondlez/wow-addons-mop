local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local AceConfig = LibStub("AceConfig-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("SliceCommander")


function SliceCommander:ArrayPos()
	local returnArray = {}
	for key = -20, 20, 1 do
		returnArray[key] = key
	end
	return returnArray
end

local SC_OptionsTable_Sound = {
	name = L["Sound settings"],
	handler = SliceCommander,
	type = "group",
	args = {--Sound settings
		headerSndSoundSetting = {--Slice and Dice
			order = 1,
			name = SC_SPELL_SND,
			type = "header"
		},
		STick3 = {--Alert - 3 sec
			order = 2,
			name = L["Alert - 3 sec"],
			desc = L["Alert 3 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Tick")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['alert3'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['alert3'] end
		},
		STick2 = {--Alert - 2 sec
			order = 3,
			name = L["Alert - 2 sec"],
			desc = L["Alert 2 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Tick")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['alert2'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['alert2'] end
		},
		STick1 = {--Alert - 1 sec
			order = 4,
			name = L["Alert - 1 sec"],
			desc = L["Alert 1 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Tick")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['alert1'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['alert1'] end
		},
		SApply3 = {--Refresh - 3 sec
			order = 5,
			name = L["Refresh - 3 sec"],
			desc = L["Refresh 3 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['refresh3'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['refresh3'] end
		},
		SApply2 = {--Refresh - 2 sec
			order = 6,
			name = L["Refresh - 2 sec"],
			desc = L["Refresh 2 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['refresh2'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['refresh2'] end
		},
		SApply1 = {--Refresh - 1 sec
			order = 7,
			name = L["Refresh - 1 sec"],
			desc = L["Refresh 1 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['refresh1'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['refresh1'] end
		},
		SApplied = {--Applied
			order = 9,
			name = L["Applied"],
			desc = L["Slice and Dice is applied"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['applied'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['applied'] end
		},
		SExpire = {--Expire
			order = 10,
			name = L["Expired"],
			desc = L["Slice and Dice buff expire"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Fail")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['SnD']['sound']['expired'] = val
			end,
			get = function(info) return SC.BARS['SnD']['sound']['expired'] end
		},
		headerRupSoundSetting = {--Rupture
			order = 20,
			name = SC_SPELL_RUP,
			type = "header"
		},
		RTick3 = {--Alert - 3 sec
			order = 21,
			name = L["Alert - 3 sec"],
			desc = L["Alert 3 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Tick")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['alert3'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['alert3'] end
		},
		RTick2 = {--Alert - 2 sec
			order = 22,
			name = L["Alert - 2 sec"],
			desc = L["Alert 2 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Tick")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['alert2'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['alert2'] end
		},
		RTick1 = {--Alert - 1 sec
			order = 23,
			name = L["Alert - 1 sec"],
			desc = L["Alert 1 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Tick")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['alert1'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['alert1'] end
		},
		RApply3 = {--Refresh - 3 sec
			order = 24,
			name = L["Refresh - 3 sec"],
			desc = L["Refresh 3 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['refresh3'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['refresh3'] end
		},
		RApply2 = {--Refresh - 2 sec
			order = 25,
			name = L["Refresh - 2 sec"],
			desc = L["Refresh 2 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['refresh2'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['refresh2'] end
		},
		RApply1 = {--Refresh - 1 sec
			order = 26,
			name = L["Refresh - 1 sec"],
			desc = L["Refresh 1 secondes before fade"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['refresh1'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['refresh1'] end
		},
		RApplied = {--Applied
			order = 27,
			name = L["Applied"],
			desc = L["Rupture is applied"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Apply")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['applied'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['applied'] end
		},
		RExpire = {--Expire
			order = 28,
			name = L["Expired"],
			desc = L["Rupture buff expire"],
			type = "select",
			values = function()
				return SliceCommander:ConfigSoundMenuInit("Fail")
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.BARS['RUP']['sound']['expired'] = val
			end,
			get = function(info) return SC.BARS['RUP']['sound']['expired'] end
		},
	}
}

local SC_OptionsTable_GeneralTimer = {
	name = L["General settings"],
	handler = SliceCommander,
	type = "group",
	args = {--Display setting
		displayDescription = {
			order = 0,
			name = L["displayDescription"],
			fontSize = "medium",
			type = "description"
		},
		headerSndSetting = {--Slice and Dice Settings
			order = 10,
			name = string.format(L["%s Settings"], SC_SPELL_SND),
			type = "header"
		},
		SnDBarShow = {--Show Slice and Dice
			order = 11,
			name = string.format(L["Show %s bar"], SC_SPELL_SND),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_SND),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.SnD = val
			end,
			get = function(info) return SC.SET.display.SnD end
		},
		PosSnD = {--Slice and Dice position
			order = 12,
			name = string.format(L["%s bar position"], SC_SPELL_SND),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_SND),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.SnD = val
			end,
			get = function(info) return SC.SET.Pos.SnD end
		},
		headerRupSetting = {--Rupture Settings
			order = 20,
			name = string.format(L["%s Settings"], SC_SPELL_RUP),
			type = "header"
		},
		RupBarShow = {--Show Rupture
			order = 21,
			name = string.format(L["Show %s bar"], SC_SPELL_RUP),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_RUP),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.RUP = val
			end,
			get = function(info) return SC.SET.display.RUP end
		},
		PosRUP = {--Rupture position
			order = 22,
			name = string.format(L["%s bar position"], SC_SPELL_RUP),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_RUP),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.RUP = val
			end,
			get = function(info) return SC.SET.Pos.RUP end
		},
		PowerRUP = {--Rupture DoT power
			order = 23,
			name = string.format(L["%s DoT power"], SC_SPELL_RUP),
			desc = string.format(L["%s DoT power is display bye a dot, Red = Current is more powerfull, Yellow = almost the same (-250 dmg), Green = Less powerfull"], SC_SPELL_RUP),
			type = "toggle",
			set = function(info,val)
				SC.SET.power.RUP = val
				SliceCommander:ToggleRupPower(val)
			end,
			get = function(info) return SC.SET.power.RUP end
		},
		headerGarSetting = {--Garrot Settings
			order = 30,
			name = string.format(L["%s Settings"], SC_SPELL_GAR),
			type = "header"
		},
		GarBarShow = {--Garrot Blood
			order = 31,
			name = string.format(L["Show %s bar"], SC_SPELL_GAR),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_GAR),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.GAR = val
			end,
			get = function(info) return SC.SET.display.GAR end
		},
		PosGAR = {--Garrot position
			order = 32,
			name = string.format(L["%s bar position"], SC_SPELL_GAR),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_GAR),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.GAR = val
			end,
			get = function(info) return SC.SET.Pos.GAR end
		},
		headerRecSetting = {--Recuperate Settings
			order = 40,
			name = string.format(L["%s Settings"], SC_SPELL_REC),
			type = "header"
		},
		RECBarShow = {--Show Recuperate
			order = 41,
			name = string.format(L["Show %s bar"], SC_SPELL_REC),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_REC),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.REC = val
			end,
			get = function(info) return SC.SET.display.REC end
		},
		PosREC = {--Recuperate position
			order = 42,
			name = string.format(L["%s bar position"], SC_SPELL_REC),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_REC),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.REC = val
			end,
			get = function(info) return SC.SET.Pos.REC end
		},
		headerEASetting = {--Expose Armor Settings
			order = 50,
			name = string.format(L["%s Settings"], SC_SPELL_EA),
			type = "header"
		},
		EABarShow = {--Show EA
			order = 51,
			name = string.format(L["Show %s bar"], SC_SPELL_EA),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_EA),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.EA = val
			end,
			get = function(info) return SC.SET.display.EA end
		},
		PosEA = {--EA position
			order = 52,
			name = string.format(L["%s bar position"], SC_SPELL_EA),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_EA),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.EA = val
			end,
			get = function(info) return SC.SET.Pos.EA end
		},
		headerToTSetting = {--Tricks of the Trade Settings
			order = 60,
			name = string.format(L["%s Settings"], SC_SPELL_TOT),
			type = "header"
		},
		TotTBarShow = {--Show ToT
			order = 61,
			name = string.format(L["Show %s bar"], SC_SPELL_TOT),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_TOT),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.ToT = val
			end,
			get = function(info) return SC.SET.display.ToT end
		},
		PosToT = {--ToT position
			order = 62,
			name = string.format(L["%s bar position"], SC_SPELL_TOT),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_TOT),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.ToT = val
			end,
			get = function(info) return SC.SET.Pos.ToT end
		},
		ToTTarget = {
			order = 63,
			name = L["Taget name"],
			desc = L["Write a macro which Tricks the target if it is friendly, if not the target of target. Except if a modifier is down the Tricks will target the player name specify here."],
			type = "input",
			set = function(info,val)
				SC.SET.ToTTarget = val
				SliceCommander:CreateToTMacro()
			end,
			get = function(info) return SC.SET.ToTTarget end
		},
		headerFESetting = {--Feint Settings
			order = 70,
			name = string.format(L["%s Settings"], SC_SPELL_FE),
			type = "header"
		},
		FEBarShow = {--Show Feint
			order = 71,
			name = string.format(L["Show %s bar"], SC_SPELL_FE),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_FE),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.FE = val
			end,
			get = function(info) return SC.SET.display.FE end
		},
		PosFE = {--Feint position
			order = 72,
			name = string.format(L["%s bar position"], SC_SPELL_FE),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_FE),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.FE = val
				SC.SET.Pos.FECD = val
			end,
			get = function(info) return SC.SET.Pos.FE end
		},
		headerSBSetting = {--Shadow Blades Settings
			order = 80,
			name = string.format(L["%s Settings"], SC_SPELL_SB),
			type = "header"
		},
		SBBarShow = {--Show Shadow Blades
			order = 81,
			name = string.format(L["Show %s bar"], SC_SPELL_SB),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_SB),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.SB = val
			end,
			get = function(info) return SC.SET.display.SB end
		},
		SBCDBarShow = {--Show Shadow Blades CD
			order = 82,
			name = string.format(L["Show %s bar CD"], SC_SPELL_SB),
			desc = string.format(L["Display the %s cooldown bar"], SC_SPELL_SB),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.SBCD = val
			end,
			get = function(info) return SC.SET.display.SBCD end
		},
		PosSB = {--Shadow Blades position
			order = 82,
			name = string.format(L["%s bar position"], SC_SPELL_SB),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_SB),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.SB = val
				SC.SET.Pos.SBCD = val
			end,
			get = function(info) return SC.SET.Pos.SB end
		},
		headerCTSetting = {--Crimson Tempest Settings
			order = 90,
			name = string.format(L["%s Settings"], SC_SPELL_CT),
			type = "header"
		},
		CTBarShow = {--Show Crimson Tempest
			order = 91,
			name = string.format(L["Show %s bar"], SC_SPELL_CT),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_CT),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.CT = val
			end,
			get = function(info) return SC.SET.display.CT end
		},
		PosCT = {--Crimson Tempest position
			order = 92,
			name = string.format(L["%s bar position"], SC_SPELL_CT),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_CT),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.CT = val
			end,
			get = function(info) return SC.SET.Pos.CT end
		},
	}
}

local SC_OptionsTable_MutilateTimer = {
	name = L["Assassination settings"],
	handler = SliceCommander,
	type = "group",
	args = {--Display setting
		displayDescription = {
			order = 0,
			name = L["displayDescription"],
			fontSize = "medium",
			type = "description"
		},
		DispatchHeader = {--Dispatch header
			order = 10,
			name = string.format(L["%s Settings"], SC_SPELL_DIS),
			type = "header"
		},
		checkHealth = {--Check health spec1
			order = 11,
			name = L["Enable 35% Dispatch Icon"],
			type = "select",
			values = {
				[0] = L["Disable"],
				[1] = L["Spec 1"],
				[2] = L["Spec 2"],
				[3] = L["All spec"]
			},
			set = function(info,val) SC.SET.checkHealth = val end,
			get = function(info) return SC.SET.checkHealth end
		},
		HealthUnder = {
			order = 12,
			name = L["Sound under 35% health"],
			desc = L["The sound play when the health reach 35% health"],
			type = "select",
			values = function()
				local returnArray = { ["None"] = L["None"] }
				for ignore, SoundName in pairs(SliceCommander_SoundMenu['All']) do
					returnArray[SoundName] = SoundName
				end
				return returnArray
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.SET.HealthUnder = val
			end,
			get = function(info)
				return SC.SET.HealthUnder
			end
		},
		BSShow = {--Show Blinde Side
			order = 13,
			name = string.format(L["Show %s bar"], SC_SPELL_BS),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_BS),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.BS = val
			end,
			get = function(info) return SC.SET.display.BS end
		},
		PosBS = {--Blinde Side position
			order = 14,
			name = string.format(L["%s bar position"], SC_SPELL_BS),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_BS),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.BS = val
			end,
			get = function(info) return SC.SET.Pos.BS end
		},
		headerVendettaSetting = {--Vendetta Settings
			order = 20,
			name = string.format(L["%s Settings"], SC_SPELL_VEN),
			type = "header"
		},
		VenBarShow = {--Show vendetta
			order = 21,
			name = string.format(L["Show %s bar"], SC_SPELL_VEN),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_VEN),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.VEN = val
			end,
			get = function(info) return SC.SET.display.VEN end
		},
		PosVEN = {--Vendetta position
			order = 22,
			name = string.format(L["%s bar position"], SC_SPELL_VEN),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_VEN),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.VEN = val
				SC.SET.Pos.VENCD = val
			end,
			get = function(info) return SC.SET.Pos.VEN end
		},
		ARCDBarShow = {--Show Vendetta CD
			order = 23,
			name = string.format(L["Show %s bar CD"], SC_SPELL_VEN),
			desc = string.format(L["Display the %s cooldown bar"], SC_SPELL_VEN),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.VENCD = val
			end,
			get = function(info) return SC.SET.display.VENCD end
		},
		headerEnvenom = {--Envenom header
			order = 30,
			name = string.format(L["%s Settings"], SC_SPELL_ENV),
			type = "header"
		},
		EnvenomShow = {--Show Envenom
			order = 31,
			name = string.format(L["Show %s bar"], SC_SPELL_ENV),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_ENV),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.ENV = val
			end,
			get = function(info) return SC.SET.display.ENV end
		},
		PosENV = {--Envenom position
			order = 32,
			name = string.format(L["%s bar position"], SC_SPELL_ENV),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_ENV),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.ENV = val
			end,
			get = function(info) return SC.SET.Pos.ENV end
		},
	}
}

local SC_OptionsTable_CombatTimer = {
	name = L["Combat settings"],
	handler = SliceCommander,
	type = "group",
	args = {--Display setting
		displayDescription = {
			order = 0,
			name = L["displayDescription"],
			fontSize = "medium",
			type = "description"
		},
		headerBG = {--Bandit's Guile header
			order = 10,
			name = string.format(L["%s Settings"], SC_SPELL_BG),
			type = "header"
		},
		ShowBG = {--Show Bandit's Guile
			order = 11,
			name = string.format(L["Show %s icon"], SC_SPELL_BG),
			desc = string.format(L["Display the %s icon when enbale"], SC_SPELL_BG),
			type = "toggle",
			set = function(info,val)
				SC.SET.BanditGuild = val
			end,
			get = function(info) return SC.SET.BanditGuild end
		},
		BGSound = {--Bandit's Guile Sound
			order = 12,
			name = L["Bandit's Guile Sound"],
			desc = L["Bandit's Guile Sound. It has no effect if Bandit's Guile is not display."],
			type = "select",
			values = function()
				local returnArray = { ["None"] = L["None"] }
				for ignore, SoundName in pairs(SliceCommander_SoundMenu['All']) do
					returnArray[SoundName] = SoundName
				end
				return returnArray
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.SET.BGSound = val
			end,
			get = function(info)
				return SC.SET.BGSound
			end
		},
		headerBFSetting = {--Blade Fury Settings
			order = 16,
			name = string.format(L["%s Settings"], SC_SPELL_BF),
			type = "header"
		},
		BFShow = {--Blade Fury Strike
			order = 17,
			name = string.format(L["Show %s icon"], SC_SPELL_BF),
			desc = string.format(L["Display the %s icon when enbale"], SC_SPELL_BF),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.BF = val
			end,
			get = function(info) return SC.SET.display.BF end
		},
		headerARSetting = {--Adrenaline rush Settings
			order = 20,
			name = string.format(L["%s Settings"], SC_SPELL_AR),
			type = "header"
		},
		ARBarShow = {--Show Adrenaline rush
			order = 21,
			name = string.format(L["Show %s bar"], SC_SPELL_AR),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_AR),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.AR = val
			end,
			get = function(info) return SC.SET.display.AR end
		},
		PosAR = {--Adrenaline rush position
			order = 22,
			name = string.format(L["%s bar position"], SC_SPELL_AR),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_AR),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.AR = val
				SC.SET.Pos.ARCD = val
			end,
			get = function(info) return SC.SET.Pos.AR end
		},
		ARCDBarShow = {--Show Adrenaline rush CD
			order = 23,
			name = string.format(L["Show %s bar CD"], SC_SPELL_AR),
			desc = string.format(L["Display the %s cooldown bar"], SC_SPELL_AR),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.ARCD = val
			end,
			get = function(info) return SC.SET.display.ARCD end
		},
		ARMarioMod = {--Enable Mario mod
			order = 24,
			name = L["Enable Mario mod"],
			desc = L["Enable mario star music during Adrenaline rush buff"],
			type = "toggle",
			set = function(info,val)
				if val then
					SC.BARS['AR']['sound']['applied'] = 'Mario'
				else
					SC.BARS['AR']['sound']['applied'] = 'None'
				end
				SC.SET.ARMarioMod = val
			end,
			get = function(info) return SC.SET.ARMarioMod end
		},
		headerRSSetting = {--Revealing Strike Settings
			order = 30,
			name = string.format(L["%s Settings"], SC_SPELL_RS),
			type = "header"
		},
		RSBarShow = {--Show Revealing Strike
			order = 31,
			name = string.format(L["Show %s bar"], SC_SPELL_RS),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_RS),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.RS = val
			end,
			get = function(info) return SC.SET.display.RS end
		},
		PosRS = {--Revealing Strike position
			order = 32,
			name = string.format(L["%s bar position"], SC_SPELL_RS),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_RS),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.RS = val
			end,
			get = function(info) return SC.SET.Pos.RS end
		},
		headerKSPSetting = {--KSP Settings
			order = 40,
			name = string.format(L["%s Settings"], SC_SPELL_KSP),
			type = "header"
		},
		KSPBarShow = {--Show KSP
			order = 41,
			name = string.format(L["Show %s bar CD"], SC_SPELL_KSP),
			desc = string.format(L["Display the %s cooldown bar"], SC_SPELL_KSP),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.KSP = val
			end,
			get = function(info) return SC.SET.display.KSP end
		},
		PosKSP = {--KSP position
			order = 42,
			name = string.format(L["%s bar position"], SC_SPELL_KSP),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_KSP),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.KSP = val
			end,
			get = function(info) return SC.SET.Pos.KSP end
		},
	}
}

local SC_OptionsTable_SubletyTimer = {
	name = L["Subtlety settings"],
	handler = SliceCommander,
	type = "group",
	args = {--Display setting
		displayDescription = {
			order = 0,
			name = L["displayDescription"],
			fontSize = "medium",
			type = "description"
		},
		headerSDSetting = {--Shadow Dance Settings
			order = 10,
			name = string.format(L["%s Settings"], SC_SPELL_SD),
			type = "header"
		},
		SDBarShow = {--Show Shadow Dance
			order = 11,
			name = string.format(L["Show %s bar"], SC_SPELL_SD),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_SD),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.SD = val
				SC.SET.display.SDCD = val
			end,
			get = function(info) return SC.SET.display.SD end
		},
		PosSD = {--Show Shadow position
			order = 12,
			name = string.format(L["%s bar position"], SC_SPELL_SD),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_SD),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.SD = val
				SC.SET.Pos.SDCD = val
			end,
			get = function(info) return SC.SET.Pos.SD end
		},
		headerHemoSetting = {--Hemorrhage Settings
			order = 20,
			name = string.format(L["%s Settings"], SC_SPELL_HEM),
			type = "header"
		},
		HemoBarShow = {--Hemorrhage Dance
			order = 21,
			name = string.format(L["Show %s bar"], SC_SPELL_HEM),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_HEM),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.HEM = val
			end,
			get = function(info) return SC.SET.display.HEM end
		},
		PosHemo = {--Hemorrhage position
			order = 22,
			name = string.format(L["%s bar position"], SC_SPELL_HEM),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_HEM),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.HEM = val
			end,
			get = function(info) return SC.SET.Pos.HEM end
		},
		headerFWSetting = {--FW Settings
			order = 30,
			name = string.format(L["%s Settings"], SC_SPELL_FW),
			type = "header"
		},
		FWShow = {--FW Dance
			order = 31,
			name = string.format(L["Show %s bar"], SC_SPELL_FW),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_FW),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.FW = val
			end,
			get = function(info) return SC.SET.display.FW end
		},
		PosFW = {--FW position
			order = 32,
			name = string.format(L["%s bar position"], SC_SPELL_FW),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_FW),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.FW = val
			end,
			get = function(info) return SC.SET.Pos.FW end
		},
	}
}

local SC_OptionsTable_ComplementaryTimer = {
	name = L["General settings"],
	handler = SliceCommander,
	type = "group",
	args = {--Display setting
		displayDescription = {
			order = 0,
			name = L["displayDescription"],
			fontSize = "medium",
			type = "description"
		},
		headerDPSetting = {--Poison bar Settings
			order = 10,
			name = string.format(L["%s Settings"], SC_SPELL_DP),
			type = "header"
		},
		DPBarShow = {--Show Poison
			order = 11,
			name = string.format(L["Show %s bar"], SC_SPELL_DP),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_DP),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.DP = val
			end,
			get = function(info) return SC.SET.display.DP end
		},
		PosDP = {--Poison position
			order = 12,
			name = string.format(L["%s bar position"], SC_SPELL_DP),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_DP),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.DP = val
			end,
			get = function(info) return SC.SET.Pos.DP end
		},
		DPIconShow = {--Show Poison Icon
			order = 13,
			name = L["Show poison icon"],
			desc = string.format(L["Display the %s icon when the %s the timer left on your poison go under 10 minutes. If you are in combat it only display the icon when it fade out."], SC_SPELL_DP, SC_SPELL_DP),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.DPICON = val
			end,
			get = function(info) return SC.SET.display.DPICON end
		},
		DPButtonEnable = {--Enable Poison button
			order = 14,
			name = L["Enable poison button"],
			desc = L["Enable poison button has no effect if poison icon is not shown. If it is enable there is two restrinction: You can't click through the area where the icon was when the icon is hide in combat and the button does not work when the icon is shown in combat."],
			type = "toggle",
			set = function(info,val)
				SC.SET.display.DPBUT = val
			end,
			get = function(info) return SC.SET.display.DPBUT end
		},
		DPSound = {--Poison Sound
			order = 15,
			name = string.format(L["%s Sound"], SC_SPELL_DP),
			desc = string.format(L["%s Sound. It has no effect if %s is not display."], SC_SPELL_DP, SC_SPELL_DP),
			type = "select",
			values = function()
				local returnArray = { ["None"] = L["None"] }
				for ignore, SoundName in pairs(SliceCommander_SoundMenu['All']) do
					returnArray[SoundName] = SoundName
				end
				return returnArray
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.SET.DPSound = val
			end,
			get = function(info)
				return SC.SET.DPSound
			end
		},
		displayDescriptionChekcedSpec = {
			order = 16,
			name = L["displayDescriptionChekcedSpec"],
			fontSize = "medium",
			type = "description"
		},
		poisonSpec1 = {
			order = 17,
			name = L["Spec 1"],
			type = "header"
		},
		Lethal1 = {
			order = 18,
			name = L["Lethal poison"],
			type = "select",
			values = function()
				return { [SC_SPELL_DP] = SC_SPELL_DP, [SC_SPELL_WP] = SC_SPELL_WP }
			end,
			set = function(info,val)
				SC.OTHER['POISON']['obj'].button:SetAttribute("spell1", val)
				SC.SET.poison[1].mh = val
			end,
			get = function(info)
				return SC.SET.poison[1].mh
			end
		},
		Utility1 = {
			order = 19,
			name = L["Utility poison"],
			type = "select",
			values = function()
				return { [SC_SPELL_CP] = SC_SPELL_CP, [SC_SPELL_MP] = SC_SPELL_MP, [SC_SPELL_LP] = SC_SPELL_LP, [SC_SPELL_PP] = SC_SPELL_PP }
			end,
			set = function(info,val)
				SC.OTHER['POISON']['obj'].button:SetAttribute("spell2", val)
				SC.SET.poison[1].oh = val
			end,
			get = function(info)
				return SC.SET.poison[1].oh
			end
		},
		poisonSpec2 = {
			order = 20,
			name = L["Spec 2"],
			type = "header"
		},
		Lethal2 = {
			order = 21,
			name = L["Lethal poison"],
			type = "select",
			values = function()
				return { [SC_SPELL_DP] = SC_SPELL_DP, [SC_SPELL_WP] = SC_SPELL_WP }
			end,
			set = function(info,val)
				SC.OTHER['POISON']['obj'].button:SetAttribute("spell1", val)
				SC.SET.poison[2].mh = val
			end,
			get = function(info)
				return SC.SET.poison[2].mh
			end
		},
		Utility2 = {
			order = 22,
			name = L["Utility poison"],
			type = "select",
			values = function()
				return { [SC_SPELL_CP] = SC_SPELL_CP, [SC_SPELL_MP] = SC_SPELL_MP, [SC_SPELL_LP] = SC_SPELL_LP, [SC_SPELL_PP] = SC_SPELL_PP }
			end,
			set = function(info,val)
				SC.OTHER['POISON']['obj'].button:SetAttribute("spell2", val)
				SC.SET.poison[2].oh = val
			end,
			get = function(info)
				return SC.SET.poison[2].oh
			end
		},
		headerCPSetting = {--Combo Point Settings
			order = 25,
			name = L["Combo Point bar Settings"],
			type = "header"
		},
		CPBarShow = {--Show Combo Point
			order = 26,
			name = L["Show Combo Point bar"],
			desc = L["Display the Combo Point timer bar"],
			type = "toggle",
			set = function(info,val)
				SC.SET.display.CP = val
			end,
			get = function(info) return SC.SET.display.CP end
		},
		PosCP = {--Combo Point position
			order = 27,
			name = L["Combo Point bar position"],
			desc = L["The place where to display the Combo Point bar"],
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.CP = val
			end,
			get = function(info) return SC.SET.Pos.CP end
		},
		headerHealthSetting = {--Health Settings
			order = 30,
			name = L["Health bar Settings"],
			type = "header"
		},
		HEALTHBarShow = {--Show Health
			order = 31,
			name = L["Show Health player bar"],
			desc = L["Show Health player bar"],
			type = "toggle",
			set = function(info,val)
				SC.SET.display.HEALTH = val
			end,
			get = function(info) return SC.SET.display.HEALTH end
		},
		PosHEALTH = {--Health position
			order = 32,
			name = L["Health bar position"],
			desc = L["The place where to display the Health bar"],
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.HEALTH = val
			end,
			get = function(info) return SC.SET.Pos.HEALTH end
		},
		MidHealthUnder = {
			order = 33,
			name = L["Sound under 50% health"],
			desc = L["The sound play when your health reach 50% health"],
			type = "select",
			values = function()
				local returnArray = { ["None"] = L["None"] }
				for ignore, SoundName in pairs(SliceCommander_SoundMenu['All']) do
					returnArray[SoundName] = SoundName
				end
				return returnArray
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.SET.MidHealthUnder = val
			end,
			get = function(info)
				return SC.SET.MidHealthUnder
			end
		},
		LowHealthUnder = {
			order = 34,
			name = L["Sound under 35% health"],
			desc = L["The sound play when your health reach 35% health"],
			type = "select",
			values = function()
				local returnArray = { ["None"] = L["None"] }
				for ignore, SoundName in pairs(SliceCommander_SoundMenu['All']) do
					returnArray[SoundName] = SoundName
				end
				return returnArray
			end,
			set = function(info,val)
				SliceCommander:SoundTest(val)
				SC.SET.LowHealthUnder = val
			end,
			get = function(info)
				return SC.SET.LowHealthUnder
			end
		},
		healthPercentage = {
			order = 35,
			name = L["Show HP Value"],
			desc = L["Show HP value rather than health percentage."],
			type = "toggle",
			set = function(info,val)
				SC.SET.healthValue = val
				SliceCommander:PlayerHealth()
			end,
			get = function(info) return SC.SET.healthValue end
		},
		healthCombat = {
			order = 36,
			name = L["Hide out of combat"],
			desc = L["Hide health bar when you are not in combat."],
			type = "toggle",
			set = function(info,val)
				SC.SET.healthHideCombat = val
				SliceCommander:PlayerHealth()
			end,
			get = function(info) return SC.SET.healthHideCombat end
		},
		headerVANSetting = {--VAN Settings
			order = 40,
			name = string.format(L["%s Settings"], SC_SPELL_VAN),
			type = "header"
		},
		VANShow = {--VAN show
			order = 41,
			name = string.format(L["Show %s bar"], SC_SPELL_VAN),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_VAN),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.VAN = val
			end,
			get = function(info) return SC.SET.display.VAN end
		},
		PosVAN = {--VAN position
			order = 42,
			name = string.format(L["%s bar position"], SC_SPELL_VAN),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_VAN),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.VAN = val
			end,
			get = function(info) return SC.SET.Pos.VAN end
		},
		headerFotDSetting = {--FotD Settings
			order = 50,
			name = string.format(L["%s Settings"], SC_SPELL_FOTD),
			type = "header"
		},
		FotDShow = {--FotD
			order = 51,
			name = string.format(L["Show %s bar"], SC_SPELL_FOTD),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_FOTD),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.FotD = val
			end,
			get = function(info) return SC.SET.display.FotD end
		},
		PosFotD = {--FotD position
			order = 52,
			name = string.format(L["%s bar position"], SC_SPELL_FOTD),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_FOTD),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.FotD = val
			end,
			get = function(info) return SC.SET.Pos.FotD end
		},
		SotDIcon = {--Shadow of the destroyer icon
			order = 54,
			name = string.format(L["%s icon"], SC_SPELL_SOTD),
			desc = string.format(L["%s icon. It's only display when stack reach 30. There is a counter on it."], SC_SPELL_SOTD),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.SotD = val
			end,
			get = function(info)
				return SC.SET.display.SotD
			end
		},
		headerThreatSetting = {--Threat Settings
			order = 60,
			name = L["Threat bar Settings"],
			type = "header"
		},
		THREATBarShow = {--Show Threat
			order = 61,
			name = L["Show Threat bar"],
			desc = L["Display the Threat bar"],
			type = "toggle",
			set = function(info,val)
				SC.SET.display.THREAT = val
			end,
			get = function(info) return SC.SET.display.THREAT end
		},
		PosTHREAT = {--Threat position
			order = 62,
			name = L["Threat bar position"],
			desc = L["The place where to display the Threat bar"],
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.THREAT = val
			end,
			get = function(info) return SC.SET.Pos.THREAT end
		},
		ThreatGroupOnly = {--Show Threat bar only in group
			order = 63,
			name = L["Threat bar only in group"],
			desc = L["Display the Threat bar only if you are in a group or a raid"],
			type = "toggle",
			set = function(info,val)
				SC.SET.ThreatGroupOnly = val
			end,
			get = function(info) return SC.SET.ThreatGroupOnly end
		},
		headerKSSetting = {--Stun bar Settings
			order = 70,
			name = string.format(L["%s Settings"], SC_SPELL_KS),
			type = "header"
		},
		KSBarShow = {--Show Stun
			order = 71,
			name = string.format(L["Show %s bar"], SC_SPELL_KS),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_KS),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.KS = val
			end,
			get = function(info) return SC.SET.display.KS end
		},
		PosKS = {--Stun position
			order = 72,
			name = string.format(L["%s bar position"], SC_SPELL_KS),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_KS),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.KS = val
			end,
			get = function(info) return SC.SET.Pos.KS end
		},
		headerCSSetting = {--Stun bar Settings
			order = 80,
			name = string.format(L["%s Settings"], SC_SPELL_CS),
			type = "header"
		},
		CSBarShow = {--Show Stun
			order = 81,
			name = string.format(L["Show %s bar"], SC_SPELL_CS),
			desc = string.format(L["Display the %s timer bar"], SC_SPELL_CS),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.CS = val
			end,
			get = function(info) return SC.SET.display.CS end
		},
		PosCS = {--Stun position
			order = 82,
			name = string.format(L["%s bar position"], SC_SPELL_CS),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_CS),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.CS = val
			end,
			get = function(info) return SC.SET.Pos.CS end
		},
		headerSSSetting = {--Shadowstep bar Settings
			order = 90,
			name = string.format(L["%s Settings"], SC_SPELL_SS),
			type = "header"
		},
		SSBarShow = {--Show Shadowstep
			order = 91,
			name = string.format(L["Show %s bar CD"], SC_SPELL_SS),
			desc = string.format(L["Display the %s cooldown bar"], SC_SPELL_SS),
			type = "toggle",
			set = function(info,val)
				SC.SET.display.SS = val
			end,
			get = function(info) return SC.SET.display.SS end
		},
		PosSS = {--Shadowstep position
			order = 92,
			name = string.format(L["%s bar position"], SC_SPELL_SS),
			desc = string.format(L["The place where to display the %s bar"], SC_SPELL_SS),
			type = "select",
			values = SliceCommander:ArrayPos(),
			set = function(info,val)
				SC.SET.Pos.SS = val
			end,
			get = function(info) return SC.SET.Pos.SS end
		},
	}
}

local SC_OptionsTable = {
	name = "SliceCommander",
	handler = SliceCommander,
	type = "group",
	args = {--SliceCommander
		IsLocked = {--Lock
			order = 1,
			name = L["Lock"],
			desc = L["Disable Left Click to Move"],
			type = "toggle",
			set = function(info,val)
				SliceCommander:LockCkecked(val)
			end,
			get = function(info) return SC.SET.IsLocked end
		},
		FullTimer = {--Full timer
			order = 2,
			name = L["Full Timer"],
			desc = L["Make timer full bar duration"],
			type = "toggle",
			set = function(info,val) SC.SET.FullTimer = val end,
			get = function(info) return SC.SET.FullTimer end
		},
		PadLatency = {--Latency
			order = 3,
			name = L["Enable Latency"],
			desc = L["Pad Alerts with Latency"],
			type = "toggle",
			set = function(info,val) SC.SET.PadLatency = val end,
			get = function(info) return SC.SET.PadLatency end
		},
		SpellText = {--Spell text
			order = 4,
			name = L["Spell Text"],
			desc = L["Enable spell text on bars"],
			type = "toggle",
			set = function(info,val) SC.SET.SpellText = val end,
			get = function(info) return SC.SET.SpellText end
		},
		GCD = {--Spell text
			order = 5,
			name = L["GCD Bar"],
			desc = L["Enable GCD bar"],
			type = "toggle",
			set = function(info,val) SC.SET.displayGCD = val end,
			get = function(info) return SC.SET.displayGCD end
		},
		BarTexture = {--Texture
			order = 6,
			name = L["Bar Texture"],
			desc = L["Bar Texture for timer and energy"],
			type = "select",
			values = function()
				local returnArray = {}
				for key, value in pairs(SliceCommander_BarTextures) do
					returnArray[key] = key
				end
				return returnArray
			end,
			set = function(info,val)
				SC.SET.BarTexture = val
				SliceCommander:Config_RetextureBars(SliceCommander:BarTexture())
			end,
			get = function(info) return SC.SET.BarTexture end
		},
		headerDisplaySetting = {--CDisplay Setting
			order = 7,
			name = L["Display Setting"],
			type = "header"
		},
		IconSize = {--Icon size
			order = 8,
			name = L["Icon size"],
			desc = L["Icon size"],
			type = "range",
			min = 10,
			max = 50,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				SC.SET.IconSize = val
				SliceCommander:SetIconSize(val)
			end,
			get = function(info) return SC.SET.IconSize end,
			isPercent = false
		},
		Width = {--Width
			order = 9,
			name = L["Width"],
			desc = L["widthDescription"],
			type = "range",
			min = 125,
			max = 300,
			step = 1,
			bigStep = 5,
			set = function(info,val)
				SC.SET.Width = val
				if SC.SET.skin then
					SliceCommander:ApplySkin(false)
				end
				SliceCommander:SetWidth(val)
				if SC.SET.skin then
					SliceCommander:ApplySkin(true)
				end

			end,
			get = function(info) return SC.SET.Width end,
			isPercent = false
		},
		TimerHeight = {--Timer height
			order = 11,
			name = L["Timer Height"],
			desc = L["Timer Bar Height"],
			type = "range",
			min = 1,
			max = 50,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				SC.SET.TimerHeight = val
				SliceCommander:SetTimersHeight(val)
				SliceCommander:ApplySkin(SC.SET.skin)
			end,
			get = function(info) return SC.SET.TimerHeight end,
			isPercent = false
		},
		BarMargin = {--Margin
			order = 12,
			name = L["Bar Margin"],
			desc = L["Bar Margin"],
			type = "range",
			min = -2,
			max = 10,
			step = 1,
			bigStep = 1,
			set = function(info,val) SC.SET.BarMargin = val end,
			get = function(info) return SC.SET.BarMargin end,
			isPercent = false
		},
		FrameOpacity = {--Opacity
			order = 13,
			name = L["Frame opacity"],
			desc = L["Frame opacity"],
			type = "range",
			min = 25,
			max = 100,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				SliceCommander:FrameOpacity(val)
				SC.SET.FrameOpacity = val
			end,
			get = function(info) return SC.SET.FrameOpacity end,
			isPercent = false
		},
		headerEnergySetting = {--Combo Point Settings
			order = 14,
			name = L["Energy bar Settings"],
			type = "header"
		},
		HideEnergy = {--Hide Energy
			order = 15,
			name = L["Hide Energy bar"],
			desc = L["Hide Energy bar"],
			type = "toggle",
			set = function(info,val)
				if val then
					VTimerEnergy:Hide()
				else
					VTimerEnergy:Show()
				end
				SC.SET.HideEnergy = val
			end,
			get = function(info) return SC.SET.HideEnergy end
		},
		EnergyHeight = {--Energy bar height
			order = 16,
			name = L["Energy Height"],
			desc = L["Energy Bar Height"],
			type = "range",
			min = 1,
			max = 40,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				SC.SET.EnergyHeight = val
				SliceCommander:SetEnergyHeight(val)
			end,
			get = function(info) return SC.SET.EnergyHeight end,
			isPercent = false
		},
		EnergyTrans = {--Energy bar transparency
			order = 17,
			name = L["Transparency (Full)"],
			desc = L["The fade out value of the energy bar when it is full."],
			type = "range",
			min = 0,
			max = 100,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				SliceCommander:SetTransparency(val)
				SC.SET.EnergyTrans = val
			end,
			get = function(info) return SC.SET.EnergyTrans end,
			isPercent = false
		},
		Energy1 = {--Energy Marker 1
			order = 18,
			name = L["Energy Marker 1"],
			type = "range",
			min = 0,
			max = 120,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				if val > UnitManaMax("player") then
					val = UnitManaMax("player")
				end
				SC.SET.Energy1 = val
				SliceCommander:Config_OtherVars()
			end,
			get = function(info) return SC.SET.Energy1 end,
			isPercent = false
		},
		Energy2 = {--Energy Marker 2
			order = 19,
			name = L["Energy Marker 2"],
			type = "range",
			min = 0,
			max = 120,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				if val > UnitManaMax("player") then
					val = UnitManaMax("player")
				end
				SC.SET.Energy2 = val
				SliceCommander:Config_OtherVars()
			end,
			get = function(info) return SC.SET.Energy2 end,
			isPercent = false
		},
		Energy3 = {--Energy Marker 3
			order = 20,
			name = L["Energy Marker 3"],
			type = "range",
			min = 0,
			max = 120,
			step = 1,
			bigStep = 1,
			set = function(info,val)
				if val > UnitManaMax("player") then
					val = UnitManaMax("player")
				end
				SC.SET.Energy3 = val
				SliceCommander:Config_OtherVars()
			end,
			get = function(info) return SC.SET.Energy3 end,
			isPercent = false
		},
		headerKick = {
			order = 21,
			name = L["Kick Feature"],
			type = "header"
		},
		kickEnable = {
			order = 22,
			name = L["Enable"],
			desc = L["If enable, a warning message will be display when you succeed to interrupts spellcasting."],
			type = "toggle",
			set = function(info,val) SC.SET.kickEnable = val end,
			get = function(info) return SC.SET.kickEnable end
		},
		kickMessage = {
			order = 23,
			name = L["Warning message"],
			desc = L["The warning message which will be display when you kick is successful."],
			type = "input",
			width = "double",
			set = function(info,val) SC.SET.kickMessage = val end,
			get = function(info) return SC.SET.kickMessage end
		},
		headerSkin = {
			order = 30,
			name = L["Border Feature"],
			type = "header"
		},
		skinEnable = {
			order = 31,
			name = L["Enable"],
			desc = L["Add a border like the one on Tukui."],
			type = "toggle",
			set = function(info,val)
				SC.SET.skin = val
				SliceCommander:ApplySkin(val)
				SliceCommander:ShowHideBorder(val)
			end,
			get = function(info) return SC.SET.skin end
		},
		headerSound = {
			order = 40,
			name = L["Sound settings"],
			type = "header"
		},
		SoundCombat = {--Disable sound out of combat
			order = 41,
			name = L["Sound Combat"],
			desc = L["Disable sounds out of combat"],
			type = "toggle",
			set = function(info,val) SC.SET.SoundCombat = val end,
			get = function(info) return SC.SET.SoundCombat end
		},
		SoundChannel = {--SoundChannel
			order = 42,
			name = L["Sound channel"],
			desc = L["Choose the sound channel with which you want to play SliceCommander sounds. 'MASTER' must be use if you want to ear sounds when sound is disable. Other channels should be use if you want o lower volume."],
			type = "select",
			values = function()
				local returnArray = {
					["Master"] = "Master",
					["SFX"] = "SFX",
					["Ambience"] = "Ambience",
					["Music"] = "Music",
				}
				return returnArray
			end,
			set = function(info,val)
				SC.SET.soundChannel = val
			end,
			get = function(info) return SC.SET.soundChannel end
		},
		SoundVolume = {--Sound Volume
			order = 43,
			name = L["Sound Volume"],
			desc = L["Warning: It will change the sound channel volume. If other sounds are played with this channel it will also change their volume."],
			type = "range",
			min = 0,
			max = 1,
			step = 0.05,
			bigStep = 0.1,
			set = function(info,val)
				SliceCommander:ChangeVolume(val)
			end,
			get = function(info) return tonumber(SliceCommander:GetVolume()) end,
			isPercent = true
		},
	}
}

function SliceCommander:ChangeVolume(val)
	if SC.SET.soundChannel == "Master" then
		SetCVar("Sound_MasterVolume",val)
	elseif SC.SET.soundChannel == "SFX" then
		SetCVar("Sound_SFXVolume",val)
	elseif SC.SET.soundChannel == "Ambience" then
		SetCVar("Sound_AmbienceVolume",val)
	elseif SC.SET.soundChannel == "Music" then
		SetCVar("Sound_MusicVolume",val)
	end
end

function SliceCommander:GetVolume()
	if SC.SET.soundChannel == "Master" then
		return GetCVar("Sound_MasterVolume")
	elseif SC.SET.soundChannel == "SFX" then
		return GetCVar("Sound_SFXVolume")
	elseif SC.SET.soundChannel == "Ambience" then
		return GetCVar("Sound_AmbienceVolume")
	elseif SC.SET.soundChannel == "Music" then
		return GetCVar("Sound_MusicVolume")
	end
end

function SliceCommander:OnInitialize()
	if SC == nil then
		_G['SC'] = {}
	end
	_G['SC'].initDone = false
	local _, englishClass = UnitClass("player")
	if englishClass == "ROGUE" then
		SliceCommander:RegisterEvent("PLAYER_REGEN_DISABLED")
		SliceCommander:RegisterEvent("PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED")
		SliceCommander:RegisterEvent("UNIT_COMBO_POINTS")
		SliceCommander:RegisterEvent("PLAYER_TARGET_CHANGED")
		SliceCommander:RegisterEvent("UNIT_HEALTH")
		SliceCommander:RegisterEvent("PLAYER_LOGIN")
		SliceCommander:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		SliceCommander:RegisterEvent("UNIT_SPELLCAST_START")
		SliceCommander:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED","UNIT_SPELLCAST_START")
		SliceCommander:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
	else
		SliceCommander:OnDisable()
		return 0
	end
end

function SliceCommander:ACTIVE_TALENT_GROUP_CHANGED()
	local aSpec = GetActiveSpecGroup()
	if SC.initDone then
		SC.OTHER['POISON']['obj'].button:SetAttribute("spell1", SC.SET.poison[aSpec].mh)
		SC.OTHER['POISON']['obj'].button:SetAttribute("spell2", SC.SET.poison[aSpec].oh)
	end
end

function SliceCommander:InitConfigurationTable()
	AceConfig:RegisterOptionsTable("SliceCommander", SC_OptionsTable)
	AceConfig:RegisterOptionsTable("SliceCommander_GeneralTimer", SC_OptionsTable_GeneralTimer)
	AceConfig:RegisterOptionsTable("SliceCommander_MutilateTimer", SC_OptionsTable_MutilateTimer)
	AceConfig:RegisterOptionsTable("SliceCommander_CombatTimer", SC_OptionsTable_CombatTimer)
	AceConfig:RegisterOptionsTable("SliceCommander_SubletyTimer", SC_OptionsTable_SubletyTimer)
	AceConfig:RegisterOptionsTable("SliceCommander_ComplementaryTimer", SC_OptionsTable_ComplementaryTimer)
	AceConfig:RegisterOptionsTable("SliceCommander_Sound", SC_OptionsTable_Sound)

	local SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander","SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end

	SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander_GeneralTimer",L["General settings"],"SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end

	SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander_MutilateTimer",L["Assassination settings"],"SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end

	SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander_CombatTimer",L["Combat settings"],"SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end

	SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander_SubletyTimer",L["Subtlety settings"],"SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end

	SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander_ComplementaryTimer",L["Complementary settings"],"SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end

	SetDefaultOpttion = AceConfigDialog:AddToBlizOptions("SliceCommander_Sound",L["Sound settings"],"SliceCommander")
	SetDefaultOpttion.default = function() SliceCommander:ResetOptions() end
end

function SliceCommander:InitFont()
	SC.BarFont1 = SliceCommander:NewFont("VTimerFont2", 8, 0.7, 213/255, 200/255, 184/255)
	SC.BarFont2 = SliceCommander:NewFont("VTimerFont4", 8, 1, 213/255, 200/255, 184/255)
	SC.FontIcon = SliceCommander:NewFont("IconFont", 15, 0.5, 1, 1, 1)
end

function SliceCommander:InitIcon()
	SC.OTHER['POISON']['obj'] = SliceCommander:NewIcon("Interface\\Icons\\ability_rogue_dualweild", 'POISON')--Create poison icon warning when it left 5minute or less on the current timer
	SC.OTHER['POISON']['obj']:Show()
	SC.OTHER['POISON']['obj'].button = CreateFrame("Button", nil, UIParent, "SecureActionButtonTemplate")--Create button to reaply poison
	SC.OTHER['POISON']['obj'].button:SetFrameStrata("HIGH")
	SC.OTHER['POISON']['obj'].button:SetFrameLevel(5)
	SC.OTHER['POISON']['obj'].button:SetPoint("BOTTOMLEFT", SC.OTHER['POISON']['obj'], "BOTTOMLEFT")
	SC.OTHER['POISON']['obj'].button:SetPoint("TOPRIGHT", SC.OTHER['POISON']['obj'], "TOPRIGHT")
	SC.OTHER['POISON']['obj'].button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	SC.OTHER['POISON']['obj'].button:SetAttribute("unit", "player")
	SC.OTHER['POISON']['obj'].button:SetAttribute("*type1", "spell")
	SC.OTHER['POISON']['obj'].button:SetAttribute("spell1", SC_SPELL_DP)
	SC.OTHER['POISON']['obj'].button:SetAttribute("*type2", "spell")
	SC.OTHER['POISON']['obj'].button:SetAttribute("spell2", SC_SPELL_LP)
	SC.OTHER['POISON']['obj'].button:EnableMouse(false)
	SC.OTHER['BF']['obj'] = SliceCommander:NewIcon("Interface\\Icons\\Ability_Warrior_PunishingBlow", 'BF')--Create Blade fury icon display when BF is enable
	SC.OTHER['HEALTHICON']['obj'] = SliceCommander:NewIcon("Interface\\Icons\\Ability_BackStab", 'HEALTHICON')--Create Backstab icon display when Target is under 35% HP
	SC.OTHER['SotD']['obj'] = SliceCommander:NewIcon("Interface\\Icons\\inv_misc_volatileshadow", 'SotD')--Create Shadow of the destroyer icon display when stack rise 30
	SC.OTHER['SotD']['obj'].overlay:Show()
end

function SliceCommander:InitGCDBar()
	SC.OTHER['AS']['obj'] = SliceCommander:ThinBar("BOTTOMLEFT", "TOPLEFT", 0 , 0)--Create Autoshot
	SC.OTHER['AS']['obj']:SetStatusBarColor(180/255, 38/255, 38/255)
end

function SliceCommander:DisableIcon(obj, val)
	for i,v in pairs(obj.iconBorder) do
		v:Hide()
	end
	obj:SetMinMaxValues(0, val)--Threat value should be between 0 and val
end

function SliceCommander:InitBar()
	SC.OTHER['BG']['obj'] = SliceCommander:BGFrame()--create Bandit's Guile bar
	SC.BARS['CP']['obj'] = SliceCommander:CPFrame()--create Combo Point bar
	for i,v in pairs(SC.BARS) do
		if i ~= "CP" then
			SC.BARS[i].obj = SliceCommander:NewFrame(v.color)
		end
	end
	SliceCommander:NewTickArray(SC.BARS['RUP'])--Create Ticks marker for Rupture Bar
	SliceCommander:NewTickArray(SC.BARS['GAR'])--Create Ticks marker for Garrote Bar
	SliceCommander:NewTickArray(SC.BARS['REC'])	--Create Ticks marker for Recuperate Bar
	SliceCommander:NewTickArray(SC.BARS['HEM'])--Create Ticks marker for Hemo Bar
	SliceCommander:NewTickArray(SC.BARS['CT'])--Create Ticks marker for Crimson Tempest Bar

	SC.BARS['VENCD']['obj'].icon:SetTexture("Interface\\Icons\\Ability_Rogue_Deadliness")
	SC.BARS['ARCD']['obj'].icon:SetTexture("Interface\\Icons\\Spell_Shadow_ShadowWordDominate")
	SC.BARS['ToT']['obj'].icon:SetTexture("Interface\\Icons\\Ability_Rogue_TricksOftheTrade")
	SC.BARS['FECD']['obj'].icon:SetTexture("Interface\\Icons\\ability_rogue_feint")
	SC.BARS['SDCD']['obj'].icon:SetTexture("Interface\\Icons\\Ability_Rogue_Shadowdance")
	SC.BARS['VAN']['obj'].icon:SetTexture("Interface\\Icons\\Ability_Vanish")
	SC.BARS['KSP']['obj'].icon:SetTexture("Interface\\Icons\\Ability_Rogue_Murderspree")
	SC.BARS['SS']['obj'].icon:SetTexture("Interface\\Icons\\Ability_Rogue_Shadowstep")
	SC.BARS['SBCD']['obj'].icon:SetTexture("Interface\\Icons\\Inv_Knife_1h_Grimbatolraid_d_03")

	SliceCommander:DisableIcon(SC.BARS['THREAT']['obj'], 110)
	SliceCommander:DisableIcon(SC.BARS['HEALTH']['obj'], 100)

	SliceCommander:NewDotPowerIcon(SC.BARS['RUP'])--Create Ticks marker for Rupture Bar
end

function SliceCommander:InitConstantValue()
	local height, width
	height = tonumber(string.match(GetCVar("gxResolution"), "%d+x(%d+)"))
	width = tonumber(string.match(GetCVar("gxResolution"), "(%d+)x+%d"))
	width = width*SC.SET.eyefinity--eyefinity is wired
	SC.LastEnergy = UnitMana('player')
	SC.curCombo = 0
	SC.RUP_AlertPending = 3
	SC.SND_AlertPending = 3
	SC.V = {
		['bColor'] = {.1,.1,.1},
		['wColor'] = {.6,.6,.6},
		['pxH'] = UIParent:GetHeight() / height,
		['pxW'] = UIParent:GetWidth() / width,
		['CP'] = {
			[1] = {.33, .63, .33},
			[2] = {.46, .63, .35},
			[3] = {.65, .63, .35},
			[4] = {.65, .42, .31},
			[5] = {.69, .31, .31},
			[6] = {.50, .50, .50},
		},
	}
	SC.Backdrop = {
		bgFile="Interface\\AddOns\\SliceCommander\\Images\\solid.tga",
		edgeFile="",
		tile=false, tileSize=0, edgeSize=0,
		insets={left=0, right=0, top=0, bottom=0}
	}
	SC.Spark = {}
end

function SliceCommander:PLAYER_LOGIN()
	SliceCommander_LoadTukuiApi()
	SliceCommander:TestValueOptions()
	SliceCommander:InitConfigurationTable()
	SliceCommander:InitFont()
	SliceCommander:InitConstantValue()
	SliceCommander:CreateCore()
	SliceCommander:InitBar()
	SliceCommander:InitIcon()
	SliceCommander:InitGCDBar()
	SliceCommander:ApplyConf()
	_G['SC'].initDone = true
	collectgarbage()
	UpdateAddOnMemoryUsage()
	print('|cffc14f2cSlice|r|cff40a740Commander|r v'..GetAddOnMetadata("SliceCommander", "Version")..' ('..L["memory use"]..':'..floor(GetAddOnMemoryUsage("SliceCommander"))..' kb)')
end

function SliceCommander:ResetOptions()
	SC.SET = nil
	SliceCommander:TestValueOptions()
	if SC.BARS['SnD']['obj'] ~= 0 then
		SliceCommander:ApplyConf()
		LibStub("AceConfigRegistry-3.0"):NotifyChange("SliceCommander")
	end
end

function SliceCommander:ShowHideBorder(visible)
	if visible then
		for i,v in pairs(VTimerEnergy.border) do
			v:Show()
		end
		for i,v in pairs(SC.BARS) do
			if i ~= "CP" then
				for j,w in pairs(v['obj'].border) do
					w:Show()
				end
				if i ~= "THREAT" and i ~= "HEALTH" then
					for j,w in pairs(v['obj'].iconBorder) do
						w:Show()
					end
				end
			end
		end
		for i,v in pairs(SC.BARS['RUP']['dot']['obj'].border) do
			v:Show()
		end
		for i,v in pairs(SC.BARS['CP']['obj'].combos) do
			for j,w in pairs(v.border) do
				w:Show()
			end
		end
	else
		for i,v in pairs(VTimerEnergy.border) do
			v:Hide()
		end
		for i,v in pairs(SC.BARS) do
			if i ~= "CP" then
				for j,w in pairs(v['obj'].border) do
					w:Hide()
				end
				if i ~= "THREAT" and i ~= "CP" and i ~= "HEALTH" then
					for j,w in pairs(v['obj'].iconBorder) do
						w:Hide()
					end
				end
			end
		end
		for i,v in pairs(SC.BARS['CP']['obj'].combos) do
			for j,w in pairs(v.border) do
				w:Hide()
			end
		end
		for i,v in pairs(SC.BARS['RUP']['dot']['obj'].border) do
			v:Hide()
		end
	end
end

function SliceCommander:ApplyConf()
	SliceCommander:LockCkecked(SC.SET.IsLocked)
	SliceCommander:SetTimersHeight(SC.SET.TimerHeight)
	SliceCommander:SetWidth(SC.SET.Width)
	SliceCommander:SetEnergyHeight(SC.SET.EnergyHeight)
	SliceCommander:SetIconSize(SC.SET.IconSize)
	SliceCommander:Config_RetextureBars(SliceCommander:BarTexture())
	SliceCommander:ToggleRupPower(SC.SET.power.RUP)
	SliceCommander:FrameOpacity(SC.SET.FrameOpacity)
	SliceCommander:SetTransparency(SC.SET.EnergyTrans)
	SliceCommander:ApplySkin(SC.SET.skin)
	SliceCommander:ShowHideBorder(SC.SET.skin)
	SliceCommander:ACTIVE_TALENT_GROUP_CHANGED()
end

function SliceCommander:ToggleRupPower(toggle)
	if toggle and not SC.BARS['RUP']['dot']['obj']:IsVisible() then
		SC.BARS['RUP']['dot']['obj']:Show()
	end
	if not toggle and SC.BARS['RUP']['dot']['obj']:IsVisible() then
		SC.BARS['RUP']['dot']['obj']:Hide()
	end
	SliceCommander:SetWidth(SC.SET.Width)
end

function SliceCommander:ConfigSoundMenuInit(WhichMenu)
	local returnArray = { ["None"] = L["None"] }
	for ignore, SoundName in pairs(SliceCommander_SoundMenu[WhichMenu]) do
		returnArray[SoundName] = SoundName
	end
	return returnArray
end

function SliceCommander:Config_OtherVars()
	SC.Spark[1]:SCPoint("TOPLEFT", VTimerEnergy, "TOPLEFT", ((SC.SET.Energy1 / UnitManaMax("player") * SC.SET.Width)-1), 0)
	SC.Spark[2]:SCPoint("TOPLEFT", VTimerEnergy, "TOPLEFT", ((SC.SET.Energy2 / UnitManaMax("player") * SC.SET.Width)-1), 0)
	SC.Spark[3]:SCPoint("TOPLEFT", VTimerEnergy, "TOPLEFT", ((SC.SET.Energy3 / UnitManaMax("player") * SC.SET.Width)-1), 0)
end

function SliceCommander:LockCkecked(checked)
	if checked then
		SliceCommander:SetTransparency(SC.SET.FrameOpacity)
		SliceCommanderFrame:SetAlpha(0)
		SliceCommanderFrame:EnableMouse(false)
		SC.OTHER['POISON']['obj']['moveframe']:SetAlpha(0)
		SC.OTHER['POISON']['obj']['moveframe']:EnableMouse(false)
		SC.OTHER['BF']['obj']['moveframe']:SetAlpha(0)
		SC.OTHER['BF']['obj']['moveframe']:EnableMouse(false)
		SC.OTHER['HEALTHICON']['obj']['moveframe']:SetAlpha(0)
		SC.OTHER['HEALTHICON']['obj']['moveframe']:EnableMouse(false)
		SC.OTHER['HEALTHICON']['obj']:Hide()
		SC.OTHER['SotD']['obj']['moveframe']:SetAlpha(0)
		SC.OTHER['SotD']['obj']['moveframe']:EnableMouse(false)
		SC.SET.IsLocked = true
	else
		SliceCommander:SetTransparency(100)
		SliceCommanderFrame:SetAlpha(.5)
		SliceCommanderFrame:EnableMouse(true)
		SC.OTHER['POISON']['obj']['moveframe']:SetAlpha(.5)
		SC.OTHER['POISON']['obj']['moveframe']:EnableMouse(true)
		SC.OTHER['POISON']['obj']:Show()
		SC.OTHER['BF']['obj']['moveframe']:SetAlpha(.5)
		SC.OTHER['BF']['obj']['moveframe']:EnableMouse(true)
		SC.OTHER['BF']['obj']:Show()
		SC.OTHER['HEALTHICON']['obj']['moveframe']:SetAlpha(.5)
		SC.OTHER['HEALTHICON']['obj']['moveframe']:EnableMouse(true)
		SC.OTHER['HEALTHICON']['obj']:Show()
		SC.OTHER['SotD']['obj']['moveframe']:SetAlpha(.5)
		SC.OTHER['SotD']['obj']['moveframe']:EnableMouse(true)
		SC.OTHER['SotD']['obj']:Show()
		SC.SET.IsLocked = false
	end
end

function SliceCommander:Config_RetextureBars(texture)
	VTimerEnergy:SetStatusBarTexture(texture)
	for i,v in pairs(SC.BARS) do
		if v['expire'] ~= nil and i ~= 'CP' then
			v['obj']:SetStatusBarTexture(texture)
		end
	end

	for i = 1, 5 do
		SC.BARS['CP']['obj'].combos[i].bg:SetTexture(texture)
	end
end

function SliceCommander:SetWidth(w)
	local h = SC.SET.TimerHeight

	if SC.SET.skin then
		--3 pixel border x2 + 1 pixel margin
		h = h + 6 + 1
	end
	for i,v in pairs(SC.BARS) do
		if v['expire'] ~= nil and i ~= 'THREAT' and i ~= 'CP' and i ~= "HEALTH" then
			if i == 'RUP' and SC.SET.power.RUP then
				SliceCommander:SetSizeBorder(w-(h*2), 0, v['obj'].border)
				v['obj']:SCWidth(w-(h*2))
			else
				SliceCommander:SetSizeBorder(w-h, 0, v['obj'].border)
				v['obj']:SCWidth(w-h)
			end
		end
	end

	VTimerEnergy:SCWidth(w)
	SliceCommander:SetSizeBorder(w, 0, VTimerEnergy.border)
	SliceCommanderFrame:SCWidth(w+16)

	SC.OTHER['AS']['obj']:SCWidth(w)
	SC.BARS['CP']['obj']:SCWidth(w)

	SC.BARS['THREAT']['obj']:SCWidth(w)
	SliceCommander:SetSizeBorder(w, 0, SC.BARS['THREAT']['obj'].border)

	SC.BARS['HEALTH']['obj']:SCWidth(w)
	SliceCommander:SetSizeBorder(w, 0, SC.BARS['HEALTH']['obj'].border)

	local cx = 0
	local pxBorder = 7
	local widthCP = (w-(pxBorder*4))/5
	for i = 1, 5 do
		SC.BARS['CP']['obj'].combos[i]:ClearAllPoints()
		SC.BARS['CP']['obj'].combos[i]:SCPoint("TOPLEFT", SC.BARS['CP']['obj'], "TOPLEFT", cx, 0)
		SC.BARS['CP']['obj'].combos[i]:SCPoint("BOTTOMRIGHT", SC.BARS['CP']['obj'], "BOTTOMLEFT", cx + widthCP , 0)
		SC.BARS['CP']['obj'].combos[i]:SCWidth(widthCP)
		SliceCommander:SetSizeBorder(widthCP, 0, SC.BARS['CP']['obj'].combos[i].border)
		cx = cx + widthCP + pxBorder
	end
	SliceCommander:Config_OtherVars()
end

function SliceCommander:SetSizeBorder(w, h, border)
	local k = 6
	for i,v in pairs(border) do
		if h ~= 0 then
			v:SCHeight(h+k)
		end
		if w ~= 0 then
			v:SCWidth(w+k)
		end
		k = k-2
	end
end

function SliceCommander:SetEnergyHeight(h)
	VTimerEnergy:SCHeight(h)
	SliceCommanderFrame:SCHeight(h+16)
	VTimerEnergyTxt:SCHeight(h)
	SliceCommander_Combo:SCHeight(h)
	SC.Spark[1]:SCHeight(h)
	SC.Spark[2]:SCHeight(h)
	SC.Spark[3]:SCHeight(h)
	SliceCommander:SetSizeBorder(0, h, VTimerEnergy.border)
	SliceCommander:PlayerHealth()
end

function SliceCommander:SetIconSize(w)
	SliceCommander:SetIconSizeObj(SC.OTHER['POISON']['obj'], w)
	SliceCommander:SetIconSizeObj(SC.OTHER['BF']['obj'], w)
	SliceCommander:SetIconSizeObj(SC.OTHER['HEALTHICON']['obj'], w)
	SliceCommander:SetIconSizeObj(SC.OTHER['SotD']['obj'], w)
end

function SliceCommander:SetIconSizeObj(obj, w)
	obj:SCSize(w, w)
	obj.overlay:SCSize(w, w)
	obj.icon:SCSize(w, w)
	obj.moveframe:SCSize(w+16, w+16)
	SliceCommander:SetSizeBorder(w, w, obj.border)
end

function SliceCommander:SetTimersHeight(h)
	for i,v in pairs(SC.BARS) do
		if v['expire'] ~= nil and i ~= 'CP' then
			v['obj']:SCHeight(h)
			v['obj'].text:SCHeight(h)
			v['obj'].text2:SCHeight(h)

			SliceCommander:SetSizeBorder(0, h, v['obj'].border)
			if i ~= 'THREAT' and i ~= 'HEALTH' then
				v['obj'].icon:SCSize(h, h)
				SliceCommander:SetSizeBorder(h, h, v['obj'].iconBorder)
			end

			if i == 'RUP' then
				v['dot']['obj']:SCSize(h, h)
				SliceCommander:SetSizeBorder(h, h, v['dot']['obj'].border)
			end
		end
	end

	for i = 1, 3 do
		SC.BARS['REC']['tick']['obj'][i]:SCHeight(h)
		SC.BARS['GAR']['tick']['obj'][i]:SCHeight(h)
		SC.BARS['RUP']['tick']['obj'][i]:SCHeight(h)
		SC.BARS['HEM']['tick']['obj'][i]:SCHeight(h)
		SC.BARS['CT']['tick']['obj'][i]:SCHeight(h)
	end

	SC.BARS['CP']['obj']:SCHeight(h)
	SC.BARS['CP']['obj'].comboText:SCHeight(h)
	for i = 1, 5 do
		SC.BARS['CP']['obj'].combos[i]:SCHeight(h)
		SliceCommander:SetSizeBorder(0, h, SC.BARS['CP']['obj'].combos[i].border)
	end

	SC.BarFont1:SetFont("Interface\\AddOns\\SliceCommander\\Fonts\\FRIZQT__.TTF", (h-2)*SC.V.pxH)
	SC.BarFont2:SetFont("Interface\\AddOns\\SliceCommander\\Fonts\\FRIZQT__.TTF", (h-2)*SC.V.pxH)
	SC.BARS['CP']['obj'].comboText:SetFont("Interface\\AddOns\\SliceCommander\\Fonts\\FRIZQT__.TTF", (h-2)*SC.V.pxH, "THINOUTLINE")
	SliceCommander:SetWidth(SC.SET.Width)
end

function SliceCommander:FrameOpacity(opValue)
	SliceCommander:SetTransparency(opValue)

	for i,v in pairs(SC.BARS) do
		if v['expire'] ~= nil then
			v['obj']:SetAlpha(opValue/100)
		end
	end

	SC.OTHER['BF']['obj']:SetAlpha(opValue/100)
	SC.OTHER['HEALTHICON']['obj']:SetAlpha(opValue/100)
end

function SliceCommander:TestValueOptions()
	if SC == nil then
		_G['SC'] = {}
	end
	if SC.SET == nil or SC.SET.display == nil or SC.SET.Pos == nil then
		SC.SET = { display = {}, Pos = {} }
	end
	if SC.SET.power == nil then
		SC.SET.power = {}
	end
	if SC.SET.poison == nil then
		SC.SET.poison = {}
	end
	if SC.SET.poison[1] == nil then
		SC.SET.poison[1] = {}
	end
	if SC.SET.poison[2] == nil then
		SC.SET.poison[2] = {}
	end
	if SC.SET.ARSound == nil then
		SC.SET.ARSound = 'Mario'
	end
	if SC.SET.ARSound_Glyphed == nil then
		SC.SET.ARSound_Glyphed = 'Mario glyphed'
	end
	if SC.SET.IsLocked == nil then
		SC.SET.IsLocked = true
	end
	if SC.SET.HideEnergy == nil then
		SC.SET.HideEnergy = false
	end
	if SC.SET.Energy1 == nil then
		SC.SET.Energy1 = 35
	end
	if SC.SET.Energy2 == nil then
		SC.SET.Energy2 = 55
	end
	if SC.SET.Energy3 == nil then
		SC.SET.Energy3 = 25
	end
	if SC.SET.EnergySound1 == nil then
		SC.SET.EnergySound1 = 'None'
	end
	if SC.SET.EnergySound2 == nil then
		SC.SET.EnergySound2 = 'None'
	end
	if SC.SET.EnergySound3 == nil then
		SC.SET.EnergySound3 = 'None'
	end
	if SC.SET.HealthUnder == nil then
		SC.SET.HealthUnder = 'None'
	end
	if SC.SET.MidHealthUnder == nil then
		SC.SET.MidHealthUnder = 'None'
	end
	if SC.SET.LowHealthUnder == nil then
		SC.SET.LowHealthUnder = 'None'
	end
	if SC.SET.BGSound == nil then
		SC.SET.BGSound = 'None'
	end
	if SC.SET.DPSound == nil then
		SC.SET.DPSound = 'None'
	end
	if SC.SET.FotDSound == nil then
		SC.SET.FotDSound = 'OH YEAH'
	end
	if SC.SET.Width == nil then
		SC.SET.Width = 287
	end
	if SC.SET.PadLatency == nil then
		SC.SET.PadLatency = true
	end
	if SC.SET.SpellText == nil then
		SC.SET.SpellText = true
	end
	if SC.SET.FullTimer == nil then
		SC.SET.FullTimer = false
	end
	if SC.SET.SoundCombat == nil then
		SC.SET.SoundCombat = true
	end
	if SC.SET.EnergyTrans == nil then
		SC.SET.EnergyTrans = 0
	end
	if SC.SET.BarMargin == nil then
		SC.SET.BarMargin = 7
	end
	if SC.SET.PoisonTransparencyShow == nil then
		SC.SET.PoisonTransparencyShow = true
	end
	if SC.SET.checkHealth == nil then
		SC.SET.checkHealth = 3
	end
	if SC.SET.ThreatGroupOnly == nil then
		SC.SET.ThreatGroupOnly = true
	end
	if SC.SET.EnergyHeight == nil then
		SC.SET.EnergyHeight = 28
	end
	if SC.SET.IconSize == nil then
		SC.SET.IconSize = 20
	end
	if SC.SET.TimerHeight == nil then
		SC.SET.TimerHeight = 17
	end
	if SC.SET.BarTexture == nil then
		SC.SET.BarTexture = 'Tukui'
	end
	if SC.SET.display.CP == nil then
		SC.SET.display.CP = true
	end
	if SC.SET.display.Poison == nil then
		SC.SET.display.Poison = true
	end
	if SC.SET.display.DP == nil then
		SC.SET.display.DP = false
	end
	if SC.SET.display.ENV == nil then
		SC.SET.display.ENV = true
	end
	if SC.SET.display.EA == nil then
		SC.SET.display.EA = true
	end
	if SC.SET.display.SnD == nil then
		SC.SET.display.SnD = true
	end
	if SC.SET.display.VEN == nil then
		SC.SET.display.VEN = true
	end
	if SC.SET.display.VENCD == nil then
		SC.SET.display.VENCD = true
	end
	if SC.SET.display.SD == nil then
		SC.SET.display.SD = true
	end
	if SC.SET.display.HEM == nil then
		SC.SET.display.HEM = true
	end
	if SC.SET.display.SDCD == nil then
		SC.SET.display.SDCD = true
	end
	if SC.SET.display.REC == nil then
		SC.SET.display.REC = true
	end
	if SC.SET.display.KS == nil then
		SC.SET.display.KS = true
	end
	if SC.SET.display.CS == nil then
		SC.SET.display.CS = true
	end
	if SC.SET.display.SS == nil then
		SC.SET.display.SS = true
	end
	if SC.SET.display.ToT == nil then
		SC.SET.display.ToT = true
	end
	if SC.SET.display.RUP == nil then
		SC.SET.display.RUP = true
	end
	if SC.SET.display.GAR == nil then
		SC.SET.display.GAR = true
	end
	if SC.SET.display.THREAT == nil then
		SC.SET.display.THREAT = true
	end
	if SC.SET.display.AR == nil then
		SC.SET.display.AR = true
	end
	if SC.SET.display.ARCD == nil then
		SC.SET.display.ARCD = true
	end
	if SC.SET.display.BF == nil then
		SC.SET.display.BF = true
	end
	if SC.SET.display.FE == nil then
		SC.SET.display.FE = true
	end
	if SC.SET.display.HEALTH == nil then
		SC.SET.display.HEALTH = false
	end
	if SC.SET.display.RS == nil then
		SC.SET.display.RS = true
	end
	if SC.SET.display.KSP == nil then
		SC.SET.display.KSP = true
	end
	if SC.SET.display.VAN == nil then
		SC.SET.display.VAN = false
	end
	if SC.SET.display.FW == nil then
		SC.SET.display.FW = false
	end
	if SC.SET.display.FotD == nil then
		SC.SET.display.FotD = true
	end
	if SC.SET.display.SotD == nil then
		SC.SET.display.SotD = true
	end
	if SC.SET.display.BS == nil then
		SC.SET.display.BS = true
	end
	if SC.SET.display.SB == nil then
		SC.SET.display.SB = true
	end
	if SC.SET.display.SBCD == nil then
		SC.SET.display.SBCD = true
	end
	if SC.SET.display.CT == nil then
		SC.SET.display.CT = true
	end
	if SC.SET.display.DPICON == nil then
		SC.SET.display.DPICON = true
	end
	if SC.SET.display.DPBUT == nil then
		SC.SET.display.DPBUT = true
	end
	if SC.SET.Pos.CP == nil then
		SC.SET.Pos.CP = -1
	end
	if SC.SET.Pos.THREAT == nil then
		SC.SET.Pos.THREAT = -2
	end
	if SC.SET.Pos.CS == nil then
		SC.SET.Pos.CS = -3
	end
	if SC.SET.Pos.KS == nil then
		SC.SET.Pos.KS = -4
	end
	if SC.SET.Pos.HEALTH == nil then
		SC.SET.Pos.HEALTH = -5
	end
	if SC.SET.Pos.REC == nil then
		SC.SET.Pos.REC = 1
	end
	if SC.SET.Pos.SnD == nil then
		SC.SET.Pos.SnD = 2
	end
	if SC.SET.Pos.RUP == nil then
		SC.SET.Pos.RUP = 3
	end
	if SC.SET.Pos.GAR == nil then
		SC.SET.Pos.GAR = 4
	end
	if SC.SET.Pos.ToT == nil then
		SC.SET.Pos.ToT = 5
	end
	if SC.SET.Pos.VEN == nil then
		SC.SET.Pos.VEN = 6
	end
	if SC.SET.Pos.VENCD == nil then
		SC.SET.Pos.VENCD = 6
	end
	if SC.SET.Pos.SD == nil then
		SC.SET.Pos.SD = 6
	end
	if SC.SET.Pos.SDCD == nil then
		SC.SET.Pos.SDCD = 6
	end
	if SC.SET.Pos.DP == nil then
		SC.SET.Pos.DP = 7
	end
	if SC.SET.Pos.ENV == nil then
		SC.SET.Pos.ENV = 8
	end
	if SC.SET.Pos.AR == nil then
		SC.SET.Pos.AR = 6
	end
	if SC.SET.Pos.ARCD == nil then
		SC.SET.Pos.ARCD = 6
	end
	if SC.SET.Pos.EA == nil then
		SC.SET.Pos.EA = 10
	end
	if SC.SET.Pos.FE == nil then
		SC.SET.Pos.FE = 11
	end
	if SC.SET.Pos.FECD == nil then
		SC.SET.Pos.FECD = 11
	end
	if SC.SET.Pos.RS == nil then
		SC.SET.Pos.RS = 8
	end
	if SC.SET.Pos.KSP == nil then
		SC.SET.Pos.KSP = 15
	end
	if SC.SET.Pos.HEM == nil then
		SC.SET.Pos.HEM = 8
	end
	if SC.SET.Pos.VAN == nil then
		SC.SET.Pos.VAN = 13
	end
	if SC.SET.Pos.FW == nil then
		SC.SET.Pos.FW = 15
	end
	if SC.SET.Pos.BS == nil then
		SC.SET.Pos.BS = 15
	end
	if SC.SET.Pos.FotD == nil then
		SC.SET.Pos.FotD = -6
	end
	if SC.SET.Pos.SS == nil then
		SC.SET.Pos.SS = 16
	end
	if SC.SET.Pos.SB == nil then
		SC.SET.Pos.SB = 17
	end
	if SC.SET.Pos.SBCD == nil then
		SC.SET.Pos.SBCD = 17
	end
	if SC.SET.Pos.CT == nil then
		SC.SET.Pos.CT = 18
	end
	if SC.SET.FrameOpacity == nil then
		SC.SET.FrameOpacity = 100
	end
	if SC.SET.ARMarioMod == nil then
		SC.SET.ARMarioMod = false
	end
	if SC.SET.kickEnable == nil then
		SC.SET.kickEnable = true
	end
	if SC.SET.kickMessage == nil then
		SC.SET.kickMessage = "Kick successful"
	end
	if SC.SET.skin == nil then
		SC.SET.skin = true
	end
	if SC.SET.eyefinity == nil then
		SC.SET.eyefinity = 1
	end
	if SC.SET.BanditGuild == nil then
		SC.SET.BanditGuild = false
	end
	if SC.SET.healthValue == nil then
		SC.SET.healthValue = false
	end
	if SC.SET.healthHideCombat == nil then
		SC.SET.healthHideCombat = true
	end
	if SC.SET.soundChannel == nil then
		SC.SET.soundChannel = "Master"
	end
	if SC.SET.displayGCD == nil then
		SC.SET.displayGCD = true
	end
	if SC.SET.colorCP == nil then
		SC.SET.colorCP = false
	end
	if SC.SET.power.RUP == nil then
		SC.SET.power.RUP = true
	end
	if SC.SET.poison[1].mh == nil then
		SC.SET.poison[1].mh = SC_SPELL_DP
	end
	if SC.SET.poison[1].oh == nil then
		SC.SET.poison[1].oh = SC_SPELL_LP
	end
	if SC.SET.poison[2].mh == nil then
		SC.SET.poison[2].mh = SC_SPELL_DP
	end
	if SC.SET.poison[2].oh == nil then
		SC.SET.poison[2].oh = SC_SPELL_LP
	end
	SliceCommander:InitBarArray()
	SliceCommander:InitOtherArray()
end


function SliceCommander:InitOtherArray()
	if SC.OTHER == nil then
		SC.OTHER = {}
	end
	if SC.OTHER['BG'] == nil then
		SC.OTHER['BG'] = {
			['obj'] = 0,
			['expire'] = 0
		}
	end
	if SC.OTHER['BF'] == nil or SC.OTHER['BF']['position'] == nil then
		SC.OTHER['BF'] = {
			['obj'] = 0,
			['position'] = {
				['xOfs'] = 45,
				['yOfs'] = 0,
				['relativePoint'] = "CENTER",
				['point'] = "CENTER",
				['relativeTo'] = "UIParent"
			}
		}
	end
	if SC.OTHER['SotD'] == nil or SC.OTHER['SotD']['position']== nil then
		SC.OTHER['SotD'] = {
			['obj'] = 0,
			['iconTxt'] = 0,
			['overlay'] = false,
			['position'] = {
				['xOfs'] = 30,
				['yOfs'] = 0,
				['relativePoint'] = "CENTER",
				['point'] = "CENTER",
				['relativeTo'] = "UIParent"
			}
		}
	end
	if SC.OTHER['HEALTHICON'] == nil or SC.OTHER['HEALTHICON']['position'] == nil then
		SC.OTHER['HEALTHICON'] = {
			['obj'] = 0,
			['position'] = {
				['xOfs'] = 15,
				['yOfs'] = 0,
				['relativePoint'] = "CENTER",
				['point'] = "CENTER",
				['relativeTo'] = "UIParent"
			}
		}
	end
	if SC.OTHER['AS'] == nil then
		SC.OTHER['AS'] = {
			['obj'] = 0,
			['expire'] = 0,
			['color'] = 0
		}
	end
	if SC.OTHER['POISON'] == nil then
		SC.OTHER['POISON'] = {
			['obj'] = 0,
			['expire'] = 0,
			['color'] = 0,
			['position'] = {
				['xOfs'] = 0,
				['yOfs'] = 0,
				['relativePoint'] = "CENTER",
				['point'] = "CENTER",
				['relativeTo'] = "UIParent"
			}
		}
	end
	if SC.OTHER['SliceCommanderFrame'] == nil then
		SC.OTHER['SliceCommanderFrame'] = {
			['position'] = {
				['xOfs'] = 0,
				['yOfs'] = 0,
				['relativePoint'] = "CENTER",
				['point'] = "CENTER",
				['relativeTo'] = "UIParent"
			}
		}
	end
end
function SliceCommander:InitBarArray()
	if SC.BARS == nil then
		SC.BARS = {}
	end
	if SC.BARS['HEALTH'] == nil then
		SC.BARS['HEALTH'] = {
			['obj'] = 0,
			['expire'] = 0,
			['color'] = {0, 0, 0}
		}
	end
	if SC.BARS['THREAT'] == nil then
		SC.BARS['THREAT'] = {
			['obj'] = 0,
			['expire'] = 0,
			['color'] = {0, 0, 0}
		}
	end
	if SC.BARS['KS'] == nil then
		SC.BARS['KS'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['color'] = {.89, .73, .52}
		}
	end
	if SC.BARS['CS'] == nil then
		SC.BARS['CS'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['color'] = {.89, .73, .2}
		}
	end
	if SC.BARS['EA'] == nil then
		SC.BARS['EA'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 3,
			['color'] = {.59, .4, .78}
		}
	end
	if SC.BARS['CP'] == nil then
		SC.BARS['CP'] = {
			['obj'] = 0,
			['expire'] = 0,
			['last'] = 0,
			['target'] = '',
			['color'] = 0
		}
	end
	if SC.BARS['VEN'] == nil then
		SC.BARS['VEN'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['color'] = {.43, .13, .18}
		}
	end
	if SC.BARS['VENCD'] == nil then
		SC.BARS['VENCD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['color'] = {.55, .31, .34}
		}
	end
	if SC.BARS['SD'] == nil then
		SC.BARS['SD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.04, .24, .31}
		}
	end
	if SC.BARS['SDCD'] == nil then
		SC.BARS['SDCD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {0, .39, .65}
		}
	end
	if SC.BARS['ToT'] == nil then
		SC.BARS['ToT'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.3, .3, 1}
		}
	end
	if SC.BARS['SnD'] == nil then
		SC.BARS['SnD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.76, .31, .17}
		}
	end
	if SC.BARS['SnD']['sound'] == nil then
		SC.BARS['SnD']['sound'] = {
			['alert3'] = 'None',
			['alert2'] = 'None',
			['alert1'] = 'None',
			['refresh3'] = 'None',
			['refresh2'] = 'None',
			['refresh1'] = 'None',
			['applied'] = 'None',
			['expired'] = 'None',
		}
	end
	if SC.BARS['FE'] == nil then
		SC.BARS['FE'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.15, .42, .68}
		}
	end
	if SC.BARS['FECD'] == nil then
		SC.BARS['FECD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.15, .42, .68}
		}
	end
	if SC.BARS['DP'] == nil then
		SC.BARS['DP'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['count'] = 0,
			['color'] = {.25, .65, .25}
		}
	end
	if SC.BARS['ENV'] == nil then
		SC.BARS['ENV'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.25, .65, .25}
		}
	end
	if SC.BARS['REC'] == nil then
		SC.BARS['REC'] = {
			['obj'] = 0,
			['expire'] = 0,
			['tick'] = {
				['obj'] = {},
				['expire'] = {}
			},
			['type'] = 1,
			['color'] = {.43, .67, .64}
		}
	end
	if SC.BARS['RUP'] == nil then
		SC.BARS['RUP'] = {
			['obj'] = 0,
			['expire'] = 0,
			['tick'] = {
				['obj'] = {},
				['expire'] = {},
				['value'] = 2
			},
			['type'] = 2,
			['color'] = {.71, .15, .15}
		}
	end
	if SC.BARS['RUP']['dot'] == nil then
		SC.BARS['RUP']['dot'] = {
			['obj'] = 0,
			['power'] = 0
		}
	end
	if SC.BARS['RUP']['sound'] == nil then
		SC.BARS['RUP']['sound'] = {
			['alert3'] = 'None',
			['alert2'] = 'None',
			['alert1'] = 'None',
			['refresh3'] = 'None',
			['refresh2'] = 'None',
			['refresh1'] = 'None',
			['applied'] = 'None',
			['expired'] = 'None',
		}
	end
	if SC.BARS['HEM'] == nil then
		SC.BARS['HEM'] = {
			['obj'] = 0,
			['expire'] = 0,
			['tick'] = {
				['obj'] = {},
				['expire'] = {},
			},
			['type'] = 2,
			['color'] = {.43, .13, .18}
		}
	end
	if SC.BARS['GAR'] == nil then
		SC.BARS['GAR'] = {
			['obj'] = 0,
			['expire'] = 0,
			['tick'] = {
				['obj'] = {},
				['expire'] = {},
				['value'] = 3
			},
			['type'] = 2,
			['color'] = {.71, .15, .15}
		}
	end
	if SC.BARS['AR'] == nil then
		SC.BARS['AR'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.89, .51, .35}
		}
	end
	if SC.BARS['AR']['sound'] == nil then
		SC.SET.ARMarioMod = 0
		SC.BARS['AR']['sound'] = {
			['applied'] = 'None',
			["alert1"] = "None",
			["refresh3"] = "None",
			["refresh2"] = "None",
			["expired"] = "None",
			["alert3"] = "None",
			["alert2"] = "None",
			["refresh1"] = "None"
		}
	end
	if SC.BARS['ARCD'] == nil then
		SC.BARS['ARCD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {1, .68, .52}
		}
	end
	if SC.BARS['RS'] == nil then
		SC.BARS['RS'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['color'] = {.15, .42, .68}
		}
	end
	if SC.BARS['KSP'] == nil then
		SC.BARS['KSP'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.06, .34, .28}
		}
	end
	if SC.BARS['VAN'] == nil then
		SC.BARS['VAN'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.42, .46, .51}
		}
	end
	if SC.BARS['FW'] == nil then
		SC.BARS['FW'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 2,
			['color'] = {.28, .86, .47}
		}
	end
	if SC.BARS['FotD'] == nil then
		SC.BARS['FotD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.7, .13, .75}
		}
	end
	if SC.BARS['BS'] == nil then
		SC.BARS['BS'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.52, .38, .75}
		}
	end
	if SC.BARS['SS'] == nil then
		SC.BARS['SS'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.76, .28, .78}
		}
	end
	if SC.BARS['SB'] == nil then
		SC.BARS['SB'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.33, .1, .49}
		}
	end
	if SC.BARS['SBCD'] == nil then
		SC.BARS['SBCD'] = {
			['obj'] = 0,
			['expire'] = 0,
			['type'] = 1,
			['color'] = {.33, .1, .49}
		}
	end
	if SC.BARS['CT'] == nil then
		SC.BARS['CT'] = {
			['obj'] = 0,
			['expire'] = 0,
			['tick'] = {
				['obj'] = {},
				['expire'] = {},
				['value'] = 2
			},
			['type'] = 2,
			['color'] = {.71, .15, .15}
		}
	end
	SliceCommander:InitSpellId()
end

function SliceCommander:InitSpellId()
	SC.BARS['CP']['last'] = 0--last CP has to be init to 0
	SC.BARS['FW']['type'] = 2--fix a wrong type
	SC.BARS['EA']['type'] = 3--fix wrong type
	SC.BARS['KS']['name'] = SC_SPELL_KS
	SC.BARS['CS']['name'] = SC_SPELL_CS
	SC.BARS['EA']['name'] = SC_SPELL_EA
	SC.BARS['VEN']['name'] = SC_SPELL_VEN
	SC.BARS['VENCD']['name'] = SC_SPELL_VEN
	SC.BARS['SD']['name'] = SC_SPELL_SD
	SC.BARS['SDCD']['name'] = SC_SPELL_SD
	SC.BARS['ToT']['name'] = SC_SPELL_TOT
	SC.BARS['SnD']['name'] = SC_SPELL_SND
	SC.BARS['FE']['name'] = SC_SPELL_FE
	SC.BARS['FECD']['name'] = SC_SPELL_FE
	SC.BARS['DP']['name'] = SC_SPELL_DP
	SC.BARS['ENV']['name'] = SC_SPELL_ENV
	SC.BARS['REC']['name'] = SC_SPELL_REC
	SC.BARS['RUP']['name'] = SC_SPELL_RUP
	SC.BARS['HEM']['name'] = SC_SPELL_HEM
	SC.BARS['GAR']['name'] = SC_SPELL_GAR
	SC.BARS['AR']['name'] = SC_SPELL_AR
	SC.BARS['ARCD']['name'] = SC_SPELL_AR
	SC.BARS['RS']['name'] = SC_SPELL_RS
	SC.BARS['KSP']['name'] = SC_SPELL_KSP
	SC.BARS['VAN']['name'] = SC_SPELL_VAN
	SC.BARS['FW']['name'] = SC_SPELL_FW
	SC.BARS['FotD']['name'] = SC_SPELL_FOTD
	SC.BARS['BS']['name'] = SC_SPELL_BS
	SC.BARS['SS']['name'] = SC_SPELL_SS
	SC.BARS['SB']['name'] = SC_SPELL_SB
	SC.BARS['SBCD']['name'] = SC_SPELL_SB
	SC.BARS['CT']['name'] = SC_SPELL_CT
end