﻿SliceCommander = LibStub("AceAddon-3.0"):NewAddon("SliceCommander", "AceEvent-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("SliceCommander")

function SliceCommander:BarTexture()
	if SC.SET.BarTexture then
		return SliceCommander_BarTextures[SC.SET.BarTexture]
	else
		return "Interface\\AddOns\\SliceCommander\\Images\\Smooth.tga"
	end

end

function SliceCommander:SoundTest(name)
	if SliceCommander_Sounds[name] and SliceCommander_Sounds[name] ~= "" and SliceCommander_Sounds[name] ~= nil then
		PlaySoundFile( SliceCommander_Sounds[name], SC.SET.soundChannel)
	end
end

function SliceCommander:PlaySound(name)
	if isCombat()==1 then
		if SliceCommander_Sounds[name] and SliceCommander_Sounds[name] ~= "" and SliceCommander_Sounds[name] ~= nil then
			PlaySoundFile( SliceCommander_Sounds[name], SC.SET.soundChannel)
		end
	end
end

function SliceCommander:Sound(saved)
	if isCombat()==1 then
		if SC.SET[saved] then
			if SliceCommander_Sounds[SC.SET[saved]] ~= "" and SliceCommander_Sounds[SC.SET[saved]] ~= nil then
				PlaySoundFile( SliceCommander_Sounds[SC.SET[saved]], SC.SET.soundChannel )
			end
		end
	end
end

function SliceCommander:ChangeAnchor()
	local offSetSize, numberPos, numberNeg, alignPos, alignNeg
	offSetSize = SC.SET.BarMargin -- other good values, -1, -2
	numberPos = 0
	numberNeg = 0

	offSetSize = (offSetSize+SC.SET.TimerHeight)

	for i = 1, 20 do
		for j,v in pairs(SC.BARS) do
			if SC.SET.Pos[j] == i and v['expire'] ~= 0 then
				alignPos = numberNeg*offSetSize*-1
				alignPos = alignPos-SC.SET.BarMargin
				v['obj']:ClearAllPoints()
				if v['dot'] ~= nil and SC.SET.power[j] then
					v['obj']:SCPoint("TOP", VTimerEnergy, "BOTTOM", 0, alignPos)
				else
					v['obj']:SCPoint("TOPRIGHT", VTimerEnergy, "BOTTOMRIGHT", 0, alignPos)
				end
				numberNeg = numberNeg +1
			end
			if SC.SET.Pos[j] == i*-1 and v['expire'] ~= 0 then
				alignNeg = numberPos*offSetSize
				alignNeg = alignNeg+SC.SET.BarMargin
				v['obj']:ClearAllPoints()
				if v['dot'] ~= nil and SC.SET.power[j] then
					v['obj']:SCPoint("BOTTOM", VTimerEnergy, "TOP", 0, alignPos)
				else
					v['obj']:SCPoint("BOTTOMRIGHT", VTimerEnergy, "TOPRIGHT", 0, alignNeg)
				end
				numberPos = numberPos +1
			end
		end
	end
end

function isCombat()
	if SC.SET.SoundCombat==true then
		if UnitAffectingCombat("player")==1 then
			return 1
		else
			return 0
		end
	else
		return 1
	end
end

function SliceCommander:COMBAT_LOG_EVENT_UNFILTERED(_, _, event, _, _, sourceName)
	if event == "SPELL_INTERRUPT" and sourceName == UnitName("player") and SC.SET.kickEnable == true then
		SendChatMessage(SC.SET.kickMessage ,"SAY")
	end
end

function SliceCommander:UNIT_COMBO_POINTS(eventName, unit)
	if unit == "player" then
		SC.BARS['CP']['target'] = UnitGUID("target")
		SliceCommander:CPColor()
		SliceCommander:SetComboPts()
		SliceCommander:ChangeAnchor()
	end
end

function SliceCommander:PLAYER_TARGET_CHANGED(eventName, arg1)
	if SC.SET.IsLocked == true then
		SC.OTHER['HEALTHICON']['obj']:Hide()
	end
	SliceCommander:CPColor()
	SliceCommander:SetComboPts()
	SliceCommander:ChangeAnchor()
end

function SliceCommander:UNIT_SPELLCAST_START(eventName, unit, spell)
	if unit == "player" and SC.SET.displayGCD then
		local start, dur = GetSpellCooldown(spell)
		if dur and dur > 0 and dur <= 1.5 then
			SC.OTHER['AS']['expire'] = start+dur
			SC.OTHER['AS']['obj']:SetMinMaxValues(0, dur)
			SC.OTHER['AS']['obj']:Show()
		end
	end
end

function SliceCommander:SetComboPts()
	local points = GetComboPoints("player")
	if points == 0 then
		if UnitGUID("target") ~= SC.BARS['CP']['target'] then
			return
		end
	end

	SliceCommander_Combo:SetText("")
	SC.BARS['CP']['obj'].comboText:SetText("")
	for i = 1, 5 do
		SC.BARS['CP']['obj'].combos[i]:Hide()
	end
	SC.BARS['CP']['obj']:Hide()
	SC.BARS['CP']['last'] = SC.BARS['CP']['expire']
	SC.BARS['CP']['expire'] = 0

	if points ~= 0 then
		local text = points
		local name, _, _, count = UnitAura("player", SC_SPELL_ANT, nil, "PLAYER")
		if name then
			text = text..' |cffD30C00+'..count..'|r'
		end
		SliceCommander_Combo:SetText(text)
		SC.BARS['CP']['expire'] = points
		if SC.SET.display.CP == true then
			SC.BARS['CP']['obj'].comboText:SetText(text)
			for i = 1, points do
				SC.BARS['CP']['obj'].combos[i]:Show()
			end
			SC.BARS['CP']['obj']:Show()
		end
	end
end

function SliceCommander:OnDisable()
	SliceCommander:UnregisterAllEvents()
end

function SliceCommander:NewFrame(color)
	local f = CreateFrame("StatusBar", nil, UIParent)

	f:SetStatusBarTexture(SliceCommander:BarTexture())
	f:SetValue(0)
	f:SetBackdropColor(unpack({1,1,1}))
	f:SetFrameStrata("MEDIUM")

	-- text on the right --
	f.text = f:CreateFontString(nil, nil, "GameFontWhite")
	f.text:SetFontObject(SC.BarFont1)
	f.text:SCWidth(120)
	f.text:SCPoint("TOPRIGHT", f, "TOPRIGHT", -5, 0)
	f.text:SetJustifyH("RIGHT")

	f.icon = f:CreateTexture(nil, "OVERLAY")
	f.icon:SCPoint("RIGHT", f, "LEFT", -2, 0)
	f.icon:SetTexCoord(.08, .92, .08, .92)

	-- text on the left --
	f.text2 = f:CreateFontString(nil, nil, nil)
	f.text2:SCPoint("CENTER", f, "CENTER", -8, 0)
	f.text2:SetFontObject(SC.BarFont1)
	f.text2:SCWidth(120)
	f.text2:SetJustifyH("CENTER")

	f:SetStatusBarColor(unpack(color))
	f.border = SliceCommander:tukSkin(f, false)
	f.iconBorder = SliceCommander:tukSkin(f, f.icon)

	return f

end

function SliceCommander:CPFrame()
	local f = CreateFrame("StatusBar", nil, UIParent)

	f.bg = f:CreateTexture(nil, "BACKGROUND")
	f.bg:SCPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
	f.bg:SCPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
	f:SetFrameStrata("MEDIUM")

	f.combos = {}

	for i = 1, 5 do
		local combo = CreateFrame("Frame", nil, f)
		combo.bg = combo:CreateTexture(nil, "BACKGROUND")
		combo.bg:SetAllPoints(combo)
		combo.bg:SetTexture("Interface\\AddOns\\SliceCommander\\Images\\solid.tga")
		combo.border = SliceCommander:tukSkin(combo, false)
		combo:Hide()
		f.combos[i] = combo
	end

	f.overlay = CreateFrame("Frame", nil, f)
	f.overlay:SetAllPoints(f)
	
	f.comboText = f.overlay:CreateFontString(nil, 'OVERLAY')
	f.comboText:SetFont("Interface\\AddOns\\SliceCommander\\Fonts\\FRIZQT__.TTF", 8, "THINOUTLINE")
	f.comboText:SetShadowColor(0, 0, 0, 0.4)
	f.comboText:SetTextColor(1, 1, 1)
	f.comboText:SetShadowOffset(1, -1)	
	f.comboText:SetJustifyH("CENTER")
	f.comboText:SCWidth(120)
	f.comboText:SetAllPoints(f.overlay)

	f:Hide()
	return f

end

function SliceCommander:ThinBar(point, relativePoint, x, y)
	local f = CreateFrame("StatusBar", nil, UIParent)
	f:SCHeight(2)
	f:SetFrameLevel(2)
	f:SetStatusBarTexture(SliceCommander:BarTexture())
	f:SetStatusBarColor(64/255, 167/255, 64/255)
	f:SetMinMaxValues(0, 3600*1000)
	f:SetFrameStrata("MEDIUM")
	f:Hide()
	f:SetBackdrop({
		bgFile="Interface\\AddOns\\SliceCommander\\Images\\solid.tga",
		edgeFile="",
		tile=true, tileSize=1, edgeSize=0,
		insets={left=0, right=0, top=0, bottom=0}
	})
	local r,v,b = unpack(SC.V.bColor)
	f:SetBackdropBorderColor(unpack(SC.V.wColor))
	f:SetBackdropColor(r,v,b,0)
	f:SetPoint(point, VTimerEnergy, relativePoint, x, y)
	return f
end

function SliceCommander:CreateMoveFrame()
	CreateFrame('Frame', 'SliceCommanderFrame', UIParent)
	SliceCommanderFrame:SetToplevel(true)
	SliceCommanderFrame:EnableMouse(false)
	SliceCommanderFrame:SetMovable(true)
	SliceCommanderFrame:SCSize(216, 36)
	SliceCommanderFrame:SetPoint(
		SC.OTHER['SliceCommanderFrame']['position'].point,
		SC.OTHER['SliceCommanderFrame']['position'].relativeTo,
		SC.OTHER['SliceCommanderFrame']['position'].relativePoint,
		SC.OTHER['SliceCommanderFrame']['position'].xOfs,
		SC.OTHER['SliceCommanderFrame']['position'].yOfs
	)
	SliceCommanderFrame:SetBackdrop(SC.Backdrop)
	SliceCommanderFrame:SetBackdropColor(0.7,0.2,0.2,1)
	SliceCommanderFrame:SetScript("OnMouseDown",function () SliceCommander:MoveStart(SliceCommanderFrame) end)
	SliceCommanderFrame:SetScript("OnMouseUp",function () SliceCommander:MoveStop(SliceCommanderFrame) end)
	SliceCommanderFrame:SetScript("OnUpdate",function () SliceCommander:OnUpdate() end)
end

function SliceCommander:CreateEnergyFrame()
	CreateFrame('StatusBar', 'VTimerEnergy', UIParent)
	VTimerEnergy:SCSize(200, 20)
	VTimerEnergy:SetMinMaxValues(0,100)
	VTimerEnergy:SCPoint('CENTER', SliceCommanderFrame, 'CENTER', 0, 0)
	VTimerEnergy:SetFrameLevel(1)
	VTimerEnergy:SetMinMaxValues(0,UnitManaMax("player"))
	VTimerEnergy:SetBackdrop(SC.Backdrop)
	VTimerEnergy:SetBackdropBorderColor(unpack(SC.V.wColor))
	VTimerEnergy:SetBackdropColor(unpack(SC.V.bColor))
	VTimerEnergy:SetStatusBarTexture(SliceCommander:BarTexture())
	VTimerEnergy:SetFrameStrata("MEDIUM")
	VTimerEnergy:SetFrameLevel(1)
	VTimerEnergy:SetStatusBarColor(234/255, 234/255, 234/255)
	VTimerEnergy.border = SliceCommander:tukSkin(VTimerEnergy, false)
	if SC.SET.HideEnergy then
		VTimerEnergy:Hide()
	else
		VTimerEnergy:Show()
	end

	VTimerEnergy:CreateFontString('VTimerEnergyTxt', 'OVERLAY', GameFontWhite)
	VTimerEnergyTxt:SetJustifyH("RIGHT")
	VTimerEnergyTxt:SCSize(49, 20)
	VTimerEnergyTxt:SCPoint('RIGHT', VTimerEnergy, 'RIGHT', -5, 0)
	VTimerEnergyTxt:SetFontObject(SliceCommander:NewFont("VTimerFont", 17, 0.7, 1, 1, 1))
end

function SliceCommander:CreateComboText()
	VTimerEnergy:CreateFontString('SliceCommander_Combo', 'OVERLAY')
	SliceCommander_Combo:SetFont("Interface\\AddOns\\SliceCommander\\Fonts\\FRIZQT__.TTF", 17, "THINOUTLINE")
	SliceCommander_Combo:SetShadowColor(0, 0, 0, 0.4)
	SliceCommander_Combo:SetTextColor(1, 1, 1)
	SliceCommander_Combo:SetShadowOffset(1, -1)	
	SliceCommander_Combo:SetJustifyH("LEFT")
	SliceCommander_Combo:SCSize(40, 20)
	SliceCommander_Combo:SCPoint('TOPLEFT', VTimerEnergy, 'TOPLEFT', 5, 0)
end

function SliceCommander:CreateSpark()
	for i = 1, 3 do
		SC.Spark[i] = VTimerEnergy:CreateTexture(nil, 'OVERLAY', GameFontWhite)
		SC.Spark[i]:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
		SC.Spark[i]:SetBlendMode('ADD')
		SC.Spark[i]:SCSize(5,20)
	end
end

function SliceCommander:CreateCore()
	SliceCommander:CreateMoveFrame()
	SliceCommander:CreateEnergyFrame()
	SliceCommander:CreateComboText()
	SliceCommander:CreateSpark()
end

function SliceCommander:NewTickArray(BAR)
	for i = 1, 3 do
		BAR['tick']['obj'][i] = BAR['obj']:CreateTexture(nil, 'OVERLAY', GameFontWhite)
		BAR['tick']['obj'][i]:SetTexture('Interface\\AddOns\\SliceCommander\\Images\\solid.tga')
		BAR['tick']['obj'][i]:SCWidth(1)
		BAR['tick']['obj'][i]:SetVertexColor(226/255, 226/255, 226/255, 0.75)
	end
end

function SliceCommander:NewDotPowerIcon(BAR)
	BAR['dot']['obj'] = BAR['obj']:CreateTexture(nil, "OVERLAY")

	BAR['dot']['obj']:SCPoint("LEFT", BAR['obj'], "RIGHT", 2, 0)
	BAR['dot']['obj']:SetTexture('Interface\\AddOns\\SliceCommander\\Images\\solid.tga')
	BAR['dot']['obj'].border = SliceCommander:tukSkin(BAR['obj'], BAR['dot']['obj'])

	BAR['obj'].text2:ClearAllPoints()
	BAR['obj'].text2:SCPoint("CENTER", BAR['obj'], "CENTER", 3, 0)
end

function SliceCommander:MoveStart(frame)
	if SC.SET.IsLocked == false then
		frame:StartMoving()
	end
end

function SliceCommander:MoveStop(frame)
	if SC.SET.IsLocked == false then
		frame:StopMovingOrSizing()
		frame:SetUserPlaced(false)
		SC.OTHER[frame:GetName()]['position'].point,
		SC.OTHER[frame:GetName()]['position'].relativeTo,
		SC.OTHER[frame:GetName()]['position'].relativePoint,
		SC.OTHER[frame:GetName()]['position'].xOfs,
		SC.OTHER[frame:GetName()]['position'].yOfs = frame:GetPoint();
	end
end

function SliceCommander:NewIcon(icon, name)
	local MoveFrame = CreateFrame('Button', name, UIParent)
	MoveFrame:SetToplevel(true)
	MoveFrame:EnableMouse(false)
	MoveFrame:SetMovable(true)
	MoveFrame:SCSize(28, 28)
	MoveFrame:SetPoint(
		SC.OTHER[name]['position'].point,
		SC.OTHER[name]['position'].relativeTo,
		SC.OTHER[name]['position'].relativePoint,
		SC.OTHER[name]['position'].xOfs,
		SC.OTHER[name]['position'].yOfs
	)
	MoveFrame:SetBackdrop({
		bgFile="Interface\\AddOns\\SliceCommander\\Images\\solid.tga",
		edgeFile="",
		tile=true, tileSize=1, edgeSize=0,
		insets={left=0, right=0, top=0, bottom=0}
	})
	MoveFrame:SetBackdropColor(0.7,0.2,0.2,1)
	MoveFrame:SetScript("OnMouseDown",function () SliceCommander:MoveStart(MoveFrame) end)
	MoveFrame:SetScript("OnMouseUp",function () SliceCommander:MoveStop(MoveFrame) end)
	--MoveFrame:SetScript("OnUpdate",function () SliceCommander:OnUpdate() end)

	local f = CreateFrame("Frame", name..'button', UIParent)
	f:SCPoint('CENTER', name, 'CENTER', 0, 0)
	f:SetFrameStrata("MEDIUM")
	f:SetFrameLevel(1)
	f:SCSize(20, 20)
	f:Hide()
	f.moveframe = MoveFrame

	local fIcon = f:CreateTexture(nil)
	fIcon:SCSize(20, 20)
	fIcon:SCPoint("CENTER", f, "CENTER", 0, 0)
	fIcon:SetAlpha(1)
	fIcon:SetTexCoord(.08, .92, .08, .92)
	fIcon:SetTexture(icon)
	f.icon = fIcon
	f.border = SliceCommander:tukSkin(f, fIcon)

	f.overlay = CreateFrame('Frame', nil, f)
	f.overlay:SetFrameStrata("HIGH")
	f.overlay:SetFrameLevel(2)
	f.overlay:SCSize(20, 20)
	f.overlay:SCPoint('CENTER', f:GetName(), 'CENTER', 0, 0)
	f.overlay:SetBackdrop({
		bgFile="Interface\\AddOns\\SliceCommander\\Images\\solid.tga",
		edgeFile="",
		tile=true, tileSize=1, edgeSize=0,
		insets={left=0, right=0, top=0, bottom=0}
	})
	f.overlay:SetBackdropColor(0,0,0,.3)
	f.overlay:Hide()

	f.iconTxt = f.overlay:CreateFontString(nil, 'OVERLAY', GameFontWhite)
	f.iconTxt:SetJustifyH("CENTER")
	f.iconTxt:SetJustifyV("MIDDLE")
	f.iconTxt:SCSize(20, 15)
	f.iconTxt:SCPoint('CENTER', f, "CENTER", 2, 0)
	f.iconTxt:SetFontObject(SC.FontIcon)
	f.iconTxt:SetShadowColor(0,0,0,1)
	f.iconTxt:SetShadowOffset(2*SC.V.pxW, -2*SC.V.pxH)

	return f
end

function SliceCommander:NewFont(name, FontSize, aShadow, rColor, gColor, bColor)
	local f = CreateFont(name)
	f:SetFont("Interface\\AddOns\\SliceCommander\\Fonts\\FRIZQT__.TTF", FontSize)
	f:SetShadowColor(0, 0, 0, aShadow)
	f:SetTextColor(rColor, gColor, bColor, 1)
	f:SetShadowOffset(0.8, -0.8)

	return f
end

function SliceCommander:BGFrame()
	local f = CreateFrame("Frame",nil,UIParent)
	f:SCPoint("LEFT", VTimerEnergy, "LEFT", 40, 0)
	f:SetFrameStrata("HIGH")
	f:SCSize(40, 16)
	f:Show()

	local returnArray = { }
	local x = 0
	for i = 1,3 do
		returnArray[i] = f:CreateTexture(nil, "OVERLAY")
		returnArray[i]:SCSize(16, 16)
		returnArray[i]:SCPoint("LEFT", f, "LEFT", x, 0)
		returnArray[i]:SetAlpha(1)
		returnArray[i]:Hide()
		x = x + 12
	end

	returnArray[1]:SetTexture('Interface\\AddOns\\SliceCommander\\Images\\Green.tga')
	returnArray[2]:SetTexture('Interface\\AddOns\\SliceCommander\\Images\\Yellow.tga')
	returnArray[3]:SetTexture('Interface\\AddOns\\SliceCommander\\Images\\Red.tga')

	return returnArray
end

function SliceCommander:ApplySkin(isApply)
	if isApply then
		for i,v in pairs(SC.BARS) do
			if i ~= 'CP' then
				if i ~= 'THREAT' and i ~= 'HEALTH' then
					v['obj'].icon:ClearAllPoints()
					v['obj'].icon:SCPoint("RIGHT", v['obj'], "LEFT", -7, 0)
				end
				if i == 'RUP' then
					v['dot']['obj']:ClearAllPoints()
					v['dot']['obj']:SCPoint("LEFT", v['obj'], "RIGHT", 7, 0)
				end
			end
		end
	else
		for i,v in pairs(SC.BARS) do
			if i ~= 'CP' then
				if i ~= 'THREAT' and i ~= 'HEALTH' then
					v['obj'].icon:ClearAllPoints()
					v['obj'].icon:SCPoint("RIGHT", v['obj'], "LEFT", -1, 0)
				end
				if i == 'RUP' then
					v['dot']['obj']:ClearAllPoints()
					v['dot']['obj']:SCPoint("LEFT", v['obj'], "RIGHT", 1, 0)
				end
			end
		end
	end

	SliceCommander:SetTimersHeight(SC.SET.TimerHeight)
	SliceCommander:SetWidth(SC.SET.Width)
	SliceCommander:SetEnergyHeight(SC.SET.EnergyHeight)
	SliceCommander:SetIconSize(SC.SET.IconSize)
end

function SliceCommander:CreateTextureSkin(frame, w, h, color, level, texture)
	local t = CreateFrame('Frame', nil, frame)
	t:SetBackdrop({
		bgFile="Interface\\AddOns\\SliceCommander\\Images\\solid.tga",
		edgeFile="",
		tile=true, tileSize=1, edgeSize=0,
		insets={left=0, right=0, top=0, bottom=0}
	})
	t:SetFrameLevel(level)
	t:SetFrameStrata("LOW")
	t:SetBackdropColor(unpack(color))
	if texture then
		t:SCPoint("CENTER", texture, "CENTER", 0, 0)
	else
		t:SCPoint("CENTER", frame, "CENTER", 0, 0)
	end
	t:Show()

	return t
end

function SliceCommander:tukSkin(frame, texture)
	return {
		[1] = SliceCommander:CreateTextureSkin(frame, 6, 6, SC.V.bColor, 1, texture),
		[2] = SliceCommander:CreateTextureSkin(frame, 4, 4, SC.V.wColor, 2, texture),
		[3] = SliceCommander:CreateTextureSkin(frame, 2, 2, SC.V.bColor, 3, texture)
	}
end

function SliceCommander:AbilityCDBar(BAR, display)
	if display ~= true then
		if BAR['obj']:IsVisible() then
			SliceCommander:HideBar(BAR)
		end
		return
	end

	local start, duration, enabled = GetSpellCooldown(BAR['name'])
	if start == nil or duration == nil or enabled == nil then--not in this spec
		if BAR['obj']:IsVisible()then--if you respect when a cd is enabled
			BAR['expire'] = 0
			SliceCommander:HideBar(BAR)
		end
		return
	end
	if start ~= 0 and duration > 2 and not BAR['obj']:IsVisible() and enabled == 1 then
		SliceCommander:EnableBar(BAR, duration, BAR['name'].." (CD)", (start+duration))
		return
	end
	if start == 0 and BAR['obj']:IsVisible()then
		BAR['expire'] = 0
		SliceCommander:HideBar(BAR)
		return
	end
	if start == 0 or duration < 2 or enabled ~= 1 then
		return
	end
	BAR['expire'] = (start+duration)
	local x
	if BAR['expire'] > 0 and SC.tNow < BAR['expire'] then
		x = BAR['expire'] - SC.tNow
	else
		x = 0
	end
	BAR['obj']:SetValue(x)
	BAR['obj'].text:SetText(string.format("%0.1f", x))
end

function SliceCommander:EnableBar(BAR, duration, text, expire)
	BAR['expire'] = expire
	if SC.SET.FullTimer == true then
		BAR['obj']:SetMinMaxValues(0, duration)
	else
		BAR['obj']:SetMinMaxValues(0, 6.0)
	end
	if SC.SET.SpellText == true then
		BAR['obj'].text2:SetText(string.format("%s", text))
	else
		BAR['obj'].text2:SetText("")
	end
	BAR['obj']:Show()
	SliceCommander:ChangeAnchor()
end

function SliceCommander:HideBar(BAR)
	BAR['obj'].text:SetText("")
	BAR['expire'] = 0
	SliceCommander:ChangeAnchor()
	BAR['obj']:Hide()
end

function SliceCommander:RupotureDotPower(CP, AP)
	local power = 0

	if CP == 0 then
		power = 0
	else
		if CP == 1 then
			power = (1052+0.1*AP)/4
		else
			if  CP == 2 then
				power = (1770+0.24*AP)/6
			else
				if  CP == 3 then
					power = (2616+0.4*AP)/8
				else
					if  CP == 4 then
						power = (3590+0.56*AP)/10
					else
						if  CP == 5 then
							power = ((4692+0.744*AP)/12)
						end
					end
				end
			end
		end
	end

	local currentSpec = GetSpecialization()
	if currentSpec == 1 then
		power = power*1.25
	else
		if currentSpec == 3 then
			local mastery = GetMasteryEffect()
			power = power*(1+mastery/100)*1.5*1.2
		end
	end

	return floor(power)
end

function SliceCommander:DotPower()
	local BAR = SC.BARS['RUP']
	local power = 0
	local base, posBuff, negBuff = UnitAttackPower("Player");
	local AP = base + posBuff + negBuff
	local CP = SC.BARS['CP']['last']
	if CP < SC.BARS['CP']['expire'] then
		CP = SC.BARS['CP']['expire']
	end

	BAR['dot']['power'] = SliceCommander:RupotureDotPower(CP, AP)
end

function SliceCommander:TestDotPower(BAR)
	local base, posBuff, negBuff = UnitAttackPower("Player");
	local AP = base + posBuff + negBuff
	local CP = SC.BARS['CP']['last']
	local currentPower = SliceCommander:RupotureDotPower(CP, AP)

	if BAR['dot']['power'] < currentPower then
		BAR['dot']['obj']:SetVertexColor(0/255, 255/255, 0/255, 0.75)
	else
		if BAR['dot']['power']-250 < currentPower then
			BAR['dot']['obj']:SetVertexColor(255/255, 255/255, 0/255, 0.75)
		else
			BAR['dot']['obj']:SetVertexColor(255/255, 0/255, 0/255, 0.75)
		end
	end
end

function SliceCommander:UpdateBar(BAR, display, tick)
	local expire, icon, duration, unitCaster, x, _, maxValue, widthSeconde, possible, value, timeLeftOnLast, spellId
	if display ~= true then
		SliceCommander:HideBar(BAR)
		return
	end

	local last = BAR['expire']
	if BAR['name'] == SC_SPELL_HEM then
		for i = 1,40 do
			_, _, icon, _, _, duration, expire, unitCaster, _, _, spellId = UnitDebuff("target", i, "PLAYER")
			if spellId == 89775 then
				BAR['expire'] = expire
				break
			end
			icon, duration, expire, unitCaster, spellId = nil, nil, nil, nil, nil
		end
	else
		if BAR['type'] == 1 then
			_, _, icon, _, _, duration, BAR['expire'], unitCaster = UnitAura("player", BAR['name'], nil, "PLAYER")
		elseif BAR['type'] == 2 then
			_, _, icon, _, _, duration, BAR['expire'], unitCaster = UnitDebuff("target", BAR['name'], nil, "PLAYER")
		else
			_, _, icon, _, _, duration, BAR['expire'], unitCaster = UnitDebuff("target", BAR['name'])
		end
	end

	if unitCaster ~= "player" and BAR['type'] ~= 3 and unitCaster ~= nil then
		BAR['expire'] = last
	end

	if BAR['expire'] == nil then
		BAR['expire'] = 0
	end
	if SC.tNow == nil then
		SC.tNow = GetTime()
	end
	if BAR['expire'] > 0 and SC.tNow < BAR['expire'] then
		x = BAR['expire'] - SC.tNow
	else
		x = 0
	end
	if x > 0 then
		if BAR['name'] == 'Rupture' then
			if last ~= BAR['expire'] and BAR['expire'] ~= 0 then
				SliceCommander:DotPower()--Maybe I can do better...
			end
		end
		xlast = BAR['obj']:GetValue()
		if BAR['obj']:IsVisible() ~= 1 then
			xlast = 0
			if BAR['sound'] ~= nil then
				SliceCommander:PlaySound(BAR['sound']['applied'])
			end
			BAR['obj'].icon:SetTexture(icon)
			SliceCommander:EnableBar(BAR, duration, BAR['name'], BAR['expire'])
		end
		xlast = BAR['obj']:GetValue()
		BAR['obj']:SetValue(x)
		BAR['obj'].text:SetText(string.format("%0.1f", x))
		if tick ~= false then
			_, maxValue = BAR['obj']:GetMinMaxValues()
			widthSeconde = (BAR['obj']:GetWidth())/maxValue
			possible = 0
			value = (x % tick)
			if value == 0 then
				value = tick
			end
			for i = 1,3 do
				if value > x or value > maxValue then
					BAR['tick']['obj'][i]:Hide()
				else
					BAR['tick']['obj'][i]:Show()
					BAR['tick']['obj'][i]:SetPoint("LEFT", BAR['obj'], "LEFT", widthSeconde*value, 0)
					value = value+tick
				end
			end
		end
		
		if BAR['sound'] ~= nil then
			if xlast >= 3 and x < 3 then
				SliceCommander:PlaySound(BAR['sound']['alert3'])
			elseif xlast >= 2 and x < 2 then
				SliceCommander:PlaySound(BAR['sound']['alert2'])
			elseif xlast >= 1 and x < 1 then
				SliceCommander:PlaySound(BAR['sound']['alert1'])
			end
			
			if xlast > 0 and xlast <= 1 and x > 1 then
				SliceCommander:PlaySound(BAR['sound']['refresh1'])
			elseif xlast <= 2 and x > 2 then
				SliceCommander:PlaySound(BAR['sound']['refresh2'])
			elseif xlast <= 3 and x > 3 then
				SliceCommander:PlaySound(BAR['sound']['refresh3'])
			end
		end
	else
		if BAR['obj']:IsVisible() then
			if BAR['sound'] ~= nil then
				SliceCommander:PlaySound(BAR['sound']['expired'])
			end
			if tick ~= false then
				for i = 1,3 do
					BAR['tick']['expire'][i] = 0
				end
			end
			SliceCommander:HideBar(BAR)
		end
	end
end

function SliceCommander:CPColor()
	local nameUID = UnitGUID("target")
	local cpColor
	if not nameUID then
		nameUID = UnitGUID("player")
	end
	for i = 1, 5 do
	  	if SC.BARS['CP']['target'] ~= nameUID then
			cpColor = SC.V.CP[6]--Gray
		else
			cpColor = SC.V.CP[i]--Yellow
		end
		SC.BARS['CP']['obj'].combos[i].bg:SetVertexColor(unpack(cpColor))
	  	SC.BARS['CP']['obj'].combos[i].border[2]:SetBackdropColor(unpack(SC.V.wColor))
	end
end

function SliceCommander:CreateToTMacro()
	if not UnitAffectingCombat("player") then
		local alreadyExist = GetMacroBody("SC_ToT")
		if alreadyExist then
			EditMacro("SC_ToT", "SC_ToT", "INV_MISC_QUESTIONMARK", "/cast [@"..SC.SET.ToTTarget..",modifier:alt] [help] [@targettarget, help][@none,@="..SC.SET.ToTTarget.."] "..SC_SPELL_TOT, 1, 1)
		else
			CreateMacro("SC_ToT", "INV_MISC_QUESTIONMARK", "/cast [@"..SC.SET.ToTTarget..",modifier:alt] [help] [@targettarget, help][@none,@="..SC.SET.ToTTarget.."] "..SC_SPELL_TOT, 1, 1)
		end
	end
end

function SliceCommander:UNIT_HEALTH()
	if (GetActiveSpecGroup() == 1 and (SC.SET.checkHealth == 1 or SC.SET.checkHealth == 3))
		or (GetActiveSpecGroup() == 2 and (SC.SET.checkHealth == 2 or SC.SET.checkHealth == 3)) then
		local HP, maxHP, pourcentHP
		HP = UnitHealth("target")
		maxHP = UnitHealthMax("target")
		if HP ~= 0 and maxHP ~= 0 and not UnitIsFriend("player","target")then
			pourcentHP = (HP / maxHP) * 100
			if pourcentHP <= 35 then
				if not SC.OTHER['HEALTHICON']['obj']:IsVisible() then
					SliceCommander:Sound("HealthUnder")
					SC.OTHER['HEALTHICON']['obj']:Show()
				end
			else
				if SC.OTHER['HEALTHICON']['obj']:IsVisible() and SC.SET.IsLocked == true then
					SC.OTHER['HEALTHICON']['obj']:Hide()
				end
			end
		else
			if SC.OTHER['HEALTHICON']['obj']:IsVisible() and SC.SET.IsLocked == true then
				SC.OTHER['HEALTHICON']['obj']:Hide()
			end
		end
	end
	SliceCommander:PlayerHealth()
end

function SliceCommander:PlayerHealth()
	if SC.SET.display.HEALTH then
		local HP, maxHP, pourcentHP, hexCol, rCol, gCol, bCol, healthText
		HP = UnitHealth("player")
		maxHP = UnitHealthMax("player")
		if maxHP ~= 0 then
			pourcentHP = (HP / maxHP) * 100
		else
			pourcentHP = 0
		end
		if maxHP == nil then
			maxHP = 0
		end
		if HP == nil then
			HP = 0
		end

		if SC.BARS['HEALTH']['expire'] > 35 and pourcentHP < 35 then
			SliceCommander:Sound("LowHealthUnder")
		elseif SC.BARS['HEALTH']['expire'] > 50 and pourcentHP < 50 then
			SliceCommander:Sound("MidHealthUnder")
		end
		hexCol = (100-pourcentHP)*(255/100)
		rCol = hexCol
		gCol = 255-hexCol
		if rCol > 210 then
			rCol = 210
		end
		if rCol < 50 then
			rCol = 50
		end
		if gCol > 210 then
			gCol = 210
		end
		if gCol < 50 then
			gCol = 50
		end
		bCol = 50

		if SC.SET.healthHideCombat and not UnitAffectingCombat("player") then
			if SC.BARS['HEALTH']['obj']:IsVisible() then
				SC.BARS['HEALTH']['obj']:Hide()
			end
			SC.BARS['HEALTH']['expire'] = 0
		else
			if not SC.BARS['HEALTH']['obj']:IsVisible() then
				SC.BARS['HEALTH']['obj']:Show()
			end
			SC.BARS['HEALTH']['expire'] = pourcentHP
		end
		SC.BARS['HEALTH']['obj']:SetValue(pourcentHP)
		if SC.SET.healthValue then
			healthText = HP
		else
			healthText = string.format("%0.1f", pourcentHP)
		end
		SC.BARS['HEALTH']['obj'].text:SetText(healthText)
		SC.BARS['HEALTH']['obj']:SetStatusBarColor(rCol/255,gCol/255,bCol/255)
	else
		SC.BARS['HEALTH']['expire'] = 0
		SC.BARS['HEALTH']['obj']:Hide()
	end
end

function SliceCommander:PLAYER_REGEN_DISABLED()
	SliceCommander:PlayerHealth()
	SliceCommander:TestDP()
end


function SliceCommander:TargetThreat()
    local hexCol, rCol, gCol, bCol
	if SC.SET.display.THREAT == false or (SC.SET.ThreatGroupOnly and IsInRaid() == false and IsInGroup() == false) then
		SC.BARS['THREAT']['expire'] = 0
	else
		local isTanking, status, threatpct, rawthreatpct, threatvalue = UnitDetailedThreatSituation("player", "target")
		if rawthreatpct == nil then
			SC.BARS['THREAT']['expire'] = 0
		else
			hexCol = rawthreatpct *(255/110)
			rCol = hexCol-45
			gCol = 255-hexCol+50
			if isTanking == 1 then
				rCol = 210
				gCol = 50
				rawthreatpct = 100
			end
			if rCol > 210 then
				rCol = 210
			end
			if rCol < 50 then
				rCol = 50
			end
			if gCol > 210 then
				gCol = 210
			end
			if gCol < 50 then
				gCol = 50
			end
			bCol = 50
			SC.BARS['THREAT']['expire'] = rawthreatpct
		end
	end
	if SC.BARS['THREAT']['expire'] == 0 then
		SC.BARS['THREAT']['obj']:Hide()
	else
		SC.BARS['THREAT']['obj']:SetValue(SC.BARS['THREAT']['expire'])
		SC.BARS['THREAT']['obj'].text:SetText(string.format("%0.1f", SC.BARS['THREAT']['expire']))
		SC.BARS['THREAT']['obj']:SetStatusBarColor(rCol/255,gCol/255,bCol/255)
		SC.BARS['THREAT']['obj']:Show()
		SliceCommander:ChangeAnchor()
	end
end

function SliceCommander:SetTransparency(value)
	VTimerEnergy:SetAlpha(value/100)
	SC.OTHER['AS']['obj']:SetAlpha(value/100)
end

function SliceCommander:TestBF()
	if SC.SET.display.BF then
		local name = UnitAura("player", SC_SPELL_BF, nil, "PLAYER")
		if name and not SC.OTHER['BF']['obj']:IsVisible() then
			SC.OTHER['BF']['obj']:Show()
		elseif not name and SC.OTHER['BF']['obj']:IsVisible() then
			if SC.SET.IsLocked == true then
				SC.OTHER['BF']['obj']:Hide()
			end
		end
	else
		if SC.SET.IsLocked == true then
			SC.OTHER['BF']['obj']:Hide()
		end
	end
end

function SliceCommander:TestAnt()
	local name, _, _, count = UnitAura("player", SC_SPELL_ANT, nil, "PLAYER")
	local points = SC.BARS['CP']['expire']
	local text = ''
	if points and points ~= 0 then
		text = points
	end
	if name then
		text = text..' |cffD30C00+'..count..'|r'
	end
	SliceCommander_Combo:SetText(text)
	SC.BARS['CP']['obj'].comboText:SetText(text)
end

function SliceCommander:TestDP()
	local combat = UnitAffectingCombat("player")
	if SC.SET.display.DPICON then
		local name, _, _, _, _, _, expirationTime = UnitAura("player", SC.SET.poison[GetActiveSpecGroup()].mh, nil, "PLAYER")
		local name2, _, _, _, _, _, expirationTime2 = UnitAura("player", SC.SET.poison[GetActiveSpecGroup()].oh, nil, "PLAYER")

		if IsMounted() == 1 or ((name and ((expirationTime-SC.tNow) > 600 or combat==1)) and (name2 and ((expirationTime2-SC.tNow) > 600 or combat==1))) then
			if SC.SET.IsLocked == true then
				if SC.OTHER['POISON']['obj']:GetAlpha() == 1 then
					SC.OTHER['POISON']['obj']:SetAlpha(0)
				end
				if combat==nil and SC.OTHER['POISON']['obj'].button:IsMouseEnabled() then
					SC.OTHER['POISON']['obj'].button:EnableMouse(false)
				end
			end
		elseif not name or not name2 or (((expirationTime-SC.tNow) < 600 or (expirationTime2-SC.tNow) < 600) and combat==nil) and IsMounted() == nil then
			if SC.OTHER['POISON']['obj']:GetAlpha() ~= 1 then
				SliceCommander:SoundTest(SC.SET.DPSound)
				SC.OTHER['POISON']['obj']:SetAlpha(1)
			end
			if combat==nil and not SC.OTHER['POISON']['obj'].button:IsMouseEnabled() and SC.SET.display.DPBUT then
				SC.OTHER['POISON']['obj'].button:EnableMouse(true)
		--	else
		--		if combat==nil and SC.OTHER['POISON']['obj'].button:IsMouseEnabled() and not SC.SET.display.DPBUT then
		--			SC.OTHER['POISON']['obj'].button:EnableMouse(false)
		--		end
			end
		end
	else
		if SC.SET.IsLocked == true then
			if SC.OTHER['POISON']['obj']:GetAlpha() == 1 then
				SC.OTHER['POISON']['obj']:SetAlpha(0)
			end
			if combat==nil and SC.OTHER['POISON']['obj'].button:IsMouseEnabled() then
				SC.OTHER['POISON']['obj'].button:EnableMouse(false)
			end
		end
	end
end

function SliceCommander:TestSOTD()
	if SC.SET.display.SotD then
		local name, _, _, count = UnitAura("player", SC_SPELL_SOTD, nil, "PLAYER")
		if name and count >= 29 then
			if not SC.OTHER['SotD']['obj']:IsVisible() then
				SC.OTHER['SotD']['obj']:Show()
			end
			SC.OTHER['SotD']['obj'].iconTxt:SetText(count)
		elseif SC.OTHER['SotD']['obj']:IsVisible() then
			if SC.SET.IsLocked == true then
				SC.OTHER['SotD']['obj']:Hide()
			end
			SC.OTHER['SotD']['obj'].iconTxt:SetText('')
		end
	else
		if SC.SET.IsLocked == true then
			SC.OTHER['SotD']['obj']:Hide()
		end
		SC.OTHER['SotD']['obj'].iconTxt:SetText('')
	end
end

function SliceCommander:Latency()
	local _
	SC.tNow = GetTime()
	if (SC.SET.PadLatency) then
		 _, _, SC.lag = GetNetStats()
		SC.tNow = SC.tNow + (SC.lag*2/1000)
	end
end

function SliceCommander:Energy()
	VTimerEnergy:SetValue(UnitMana("player"))
	VTimerEnergy:SetMinMaxValues(0,UnitManaMax("player"))
	VTimerEnergyTxt:SetText(VTimerEnergy:GetValue())

	if SC.LastEnergy < SC.SET.Energy2 and UnitMana('player') >= SC.SET.Energy2 then
		SliceCommander:Sound("EnergySound2")
	elseif SC.LastEnergy < SC.SET.Energy1 and UnitMana('player') >= SC.SET.Energy1 then
		SliceCommander:Sound("EnergySound1")
	elseif SC.LastEnergy < SC.SET.Energy3 and UnitMana('player') >= SC.SET.Energy3 then
		SliceCommander:Sound("EnergySound3")
	end
	SC.LastEnergy = UnitMana('player')

	if UnitManaMax("player") == UnitMana('player') and UnitAffectingCombat("player")~=1 then
		SliceCommander:SetTransparency(SC.SET.EnergyTrans)
	else
		SliceCommander:SetTransparency(SC.SET.FrameOpacity)
	end
end

function SliceCommander:BanditGuile()
	if UnitAura("player", SC_SPELL_BG1, nil, "PLAYER") then
		SC.OTHER['BG']['expire'] = 1
	elseif UnitAura("player", SC_SPELL_BG2, nil, "PLAYER") then
		SC.OTHER['BG']['expire'] = 2
	elseif UnitAura("player", SC_SPELL_BG3, nil, "PLAYER") then
		if SC.OTHER['BG']['expire'] ~= 3 then
			SliceCommander:Sound("BGSound")
		end
		SC.OTHER['BG']['expire'] = 3
	else
		SC.OTHER['BG']['expire'] = 0
	end

	if not SC.SET.BanditGuild then
		SC.OTHER['BG']['expire'] = 0
	end

	for i = 1, 3 do
		if i <= SC.OTHER['BG']['expire'] then
			SC.OTHER['BG']['obj'][i]:Show()
		else
			SC.OTHER['BG']['obj'][i]:Hide()
		end
	end
end

function SliceCommander:GCD()
  	if not SC.OTHER['AS']['expire'] then return SC.OTHER['AS']['obj']:Hide() end

	local val = (SC.OTHER['AS']['expire']-GetTime())
	if val < 0 then
		SC.OTHER['AS']['expire'] = nil
	else
		SC.OTHER['AS']['obj']:SetValue(val)
	end
end

function SliceCommander:OnUpdate()
	SliceCommander:Energy()--Update energy value and play sound if necessary
	SliceCommander:Latency()--Update timer reference and latency

	SliceCommander:GCD()--Update GCD Bar
	SliceCommander:TargetThreat()--Update Threat Bar

	SliceCommander:BanditGuile()--Update Bandit's Guile indicator

	SliceCommander:UpdateBar(SC.BARS['RUP'], SC.SET.display.RUP, 2)--Update Rupture Bar
	SliceCommander:UpdateBar(SC.BARS['SnD'], SC.SET.display.SnD, false)--Update SnD Bar
	SliceCommander:UpdateBar(SC.BARS['REC'], SC.SET.display.REC, 3)--Update Recuperate Bar
	SliceCommander:UpdateBar(SC.BARS['CT'], SC.SET.display.CT, 2)--Update Crimson Tempest Bar
	SliceCommander:UpdateBar(SC.BARS['HEM'], SC.SET.display.HEM, 3)--Update Hemorrhage Bar
	SliceCommander:UpdateBar(SC.BARS['GAR'], SC.SET.display.GAR, 3)--Update Garrote Bar
	SliceCommander:UpdateBar(SC.BARS['EA'], SC.SET.display.EA, false)--Update Expose Armor Bar
	SliceCommander:UpdateBar(SC.BARS['FE'], SC.SET.display.FE, false)--Update Feint Bar
	SliceCommander:UpdateBar(SC.BARS['KS'], SC.SET.display.KS, false)--Update Kidney Shot Bar
	SliceCommander:UpdateBar(SC.BARS['CS'], SC.SET.display.CS, false)--Update Cheap Shot Bar
	SliceCommander:UpdateBar(SC.BARS['DP'], SC.SET.display.DP, false)--Update Deadly poison Bar
	SliceCommander:UpdateBar(SC.BARS['ENV'], SC.SET.display.ENV, false)--Update Envenom Bar
	SliceCommander:UpdateBar(SC.BARS['VEN'], SC.SET.display.VEN, false)--Update Vendetta Bar
	SliceCommander:UpdateBar(SC.BARS['AR'], SC.SET.display.AR, false)--Update Adrenaline rush Bar
	SliceCommander:UpdateBar(SC.BARS['RS'], SC.SET.display.RS, false)--Update Vendetta Bar
	SliceCommander:UpdateBar(SC.BARS['SD'], SC.SET.display.SD, false)--Update ShadowDance Bar
	SliceCommander:UpdateBar(SC.BARS['FW'], SC.SET.display.FW, false)--Update Find Weakness Bar
	SliceCommander:UpdateBar(SC.BARS['FotD'], SC.SET.display.FotD, false)--Update Fury Of The Destroyer Bar
	SliceCommander:UpdateBar(SC.BARS['BS'], SC.SET.display.BS, false)--Update Blinde Side Bar
	SliceCommander:UpdateBar(SC.BARS['SB'], SC.SET.display.SB, false)--Update Shadow Blades Bar
	SliceCommander:AbilityCDBar(SC.BARS['VENCD'], SC.SET.display.VENCD)--Update Vendetta CD bar
	SliceCommander:AbilityCDBar(SC.BARS['ToT'], SC.SET.display.ToT)--Update ToT CD bar
	SliceCommander:AbilityCDBar(SC.BARS['ARCD'], SC.SET.display.ARCD)--Update Adrenaline rush CD bar
	SliceCommander:AbilityCDBar(SC.BARS['FECD'], SC.SET.display.FE)--Update Feint CD bar
	SliceCommander:AbilityCDBar(SC.BARS['SDCD'], SC.SET.display.SDCD)--Update ShadowDance CD bar
	SliceCommander:AbilityCDBar(SC.BARS['VAN'], SC.SET.display.VAN)--Update Vanish CD bar
	SliceCommander:AbilityCDBar(SC.BARS['KSP'], SC.SET.display.KSP)--Update KSP CD bar
	SliceCommander:AbilityCDBar(SC.BARS['SS'], SC.SET.display.SS)--Update Shadowstep CD bar
	SliceCommander:AbilityCDBar(SC.BARS['SBCD'], SC.SET.display.SBCD)--Update Shadow Blades CD bar
	SliceCommander:CPColor()--Update Combo point color
	SliceCommander:TestBF()--Update BF bar display
	SliceCommander:TestAnt()--Update Anticipation stack
	SliceCommander:TestSOTD()--Update SotD bar display
	SliceCommander:TestDP()--Update DP Icon
	SliceCommander:TestDotPower(SC.BARS['RUP'])
end

--MAIN
SLASH_RELOADUI1 = "/rl"
SlashCmdList.RELOADUI = ReloadUI

SLASH_SLICECOMMANDER1 = "/slicecommander"
SLASH_SLICECOMMANDER2 = "/sc"
SlashCmdList["SLICECOMMANDER"] = function(msg, editbox)
	local command, rest = msg:match("^(%S*)%s*(.-)$")
	if command == "lock" or command == "unlock" then
		SliceCommander:LockCkecked(not SC.SET.IsLocked)
	elseif command == "eyefinity" and tonumber(rest) then
		SC.SET.eyefinity = rest
		ReloadUI()
	elseif command == "tot" and tostring(rest) then
		SC.SET.ToTTarget = rest
		SliceCommander:CreateToTMacro()
		print(L['Macro update'])
	else
		InterfaceOptionsFrame_OpenToCategory("SliceCommander")
	end
end