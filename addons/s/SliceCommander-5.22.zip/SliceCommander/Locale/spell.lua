--[[
	à : \195\160	è : \195\168	ì : \195\172	ò : \195\178	ù : \195\185
	á : \195\161	é : \195\169	í : \195\173	ó : \195\179	ú : \195\186
	â : \195\162	ê : \195\170	î : \195\174	ô : \195\180	û : \195\187
	ã : \195\163	ë : \195\171	ï : \195\175	õ : \195\181	ü : \195\188
	ä : \195\164					ñ : \195\177	ö : \195\182
	æ : \195\166									ø : \195\184
	ç : \195\167									œ : \197\147
	Ä : \195\132	Ö : \195\150	Ü : \195\156	ß : \195\159
]]
SC_SPELL_KS = 	GetSpellInfo(408)	--Kidney Shot
SC_SPELL_GAR = 	GetSpellInfo(703)	--Garrote
SC_SPELL_CS = 	GetSpellInfo(1833)	--Cheap Shot
SC_SPELL_VAN = 	GetSpellInfo(1856)	--Vanish
SC_SPELL_RUP = 	GetSpellInfo(1943)	--Rupture
SC_SPELL_FE = 	GetSpellInfo(1966)	--Feint
SC_SPELL_SND = 	GetSpellInfo(5171)	--Slice and Dice
SC_SPELL_AR = 	GetSpellInfo(13750)	--Adrenaline Rush
SC_SPELL_BF = 	GetSpellInfo(13877)	--Blade Flurry
SC_SPELL_ENV = 	GetSpellInfo(32645)	--Envenom
SC_SPELL_SS = 	GetSpellInfo(36554)	--Shadowstep
SC_SPELL_KSP = 	GetSpellInfo(51690)	--Killing Spree
SC_SPELL_SD = 	GetSpellInfo(51713)	--Shadow Dance
SC_SPELL_TOT = 	GetSpellInfo(57934)	--Tricks of the Trade
SC_SPELL_REC = 	GetSpellInfo(73651)	--Recuperate
SC_SPELL_VEN = 	GetSpellInfo(79140)	--Vendetta
SC_SPELL_RS = 	GetSpellInfo(84617)	--Revealing Strike
SC_SPELL_BG = 	GetSpellInfo(84654)	--Bandit's Guile
SC_SPELL_BG1 = 	GetSpellInfo(84745)	--Bandit's Guile
SC_SPELL_BG2 = 	GetSpellInfo(84746)	--Bandit's Guile
SC_SPELL_BG3 = 	GetSpellInfo(84747)	--Bandit's Guile
SC_SPELL_HEM = 	GetSpellInfo(89775)	--Hemorrhage
SC_SPELL_FW = 	GetSpellInfo(91023)	--Find Weakness
SC_SPELL_SOTD = GetSpellInfo(109941)--Shadpw of the Destroyer
SC_SPELL_FOTD = GetSpellInfo(109949)--Fury of the Destroyer
SC_SPELL_DIS = 	GetSpellInfo(111240)--Dispatch
SC_SPELL_EA = 	GetSpellInfo(113746)--Expose Armor
SC_SPELL_ANT = 	GetSpellInfo(114015)--Anticipation
SC_SPELL_BS = 	GetSpellInfo(121153)--Blindside
SC_SPELL_CT = 	GetSpellInfo(121411)--Crimson Tempest
SC_SPELL_SB = 	GetSpellInfo(121471)--Shadow Blades


SC_SPELL_DP = 	GetSpellInfo(2818)	--Deadly Poison
SC_SPELL_CP = 	GetSpellInfo(3408)	--Crippling Poison
SC_SPELL_MP = 	GetSpellInfo(5761)	--Mind-numbing_Poison
SC_SPELL_WP = 	GetSpellInfo(8679)	--Wound Poison
SC_SPELL_LP = 	GetSpellInfo(108211)--Leeching Poison
SC_SPELL_PP = 	GetSpellInfo(108215)--Paralytic Poison