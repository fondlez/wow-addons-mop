
--[[

    
    SoulSpeak reacts to various soul events using emotes and quotes!
    Copyright (C) 2007-2014 Lilih @ Defias Brotherhood (EU)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    
--]]

SoulSpeak = {}

local _, class = UnitClass("player")
if class ~= "WARLOCK" then return end

local L = LibStub("AceLocale-3.0"):GetLocale("SoulSpeak")
SoulSpeak = LibStub("AceAddon-3.0"):NewAddon("SoulSpeak", 'AceEvent-3.0', 'AceConsole-3.0')

BINDING_HEADER_SOULSPEAK = "SoulSpeak";
BINDING_NAME_SSOPTIONS = "Options";
BINDING_NAME_SSRELOADGFX = "Restart GFX engine";
BINDING_NAME_SSRELOADUI = "Reload UI";

local SoulSpeak = SoulSpeak
local dropDownMenu, db
local SStarget = ""
local SSres = 0
local targetClass, englishClass
local genderTable
local	SSgenderTable1
local	SSgenderTable2
local	SSgenderTable3
local	SSgenderTable4
local DemonName = ""
local HSspell = GetSpellInfo(8690)
local IDspell = GetSpellInfo(91226)
local RSOspell = GetSpellInfo(29893)
local RSUspell = GetSpellInfo(698)
--local SSRspell = GetSpellInfo(5697)  -- debug unending breath spell
local SSRspell = GetSpellInfo(20707)
local summonFGRD = GetSpellInfo(30146)
local summonWGRD = GetSpellInfo(112870)
local summonFEL = GetSpellInfo(691)
local summonOBS = GetSpellInfo(112869)
local summonIMP = GetSpellInfo(688)
local summonFIMP = GetSpellInfo(112866)
local summonSUC = GetSpellInfo(712)
local summonSHI = GetSpellInfo(112868)
local summonVOID = GetSpellInfo(697)
local summonVOIDnomana = GetSpellInfo(25112)
local summonVOIDL = GetSpellInfo(112867)

local HearthstoneStyles = {
	"|cff00ff00"..L.HSBLINK, "|cffffd200"..L.HSSMILE, "|cffff6b00"..L.HSGOING, "|cffff2f32"..L.HSYAWN,
	"|cfff58cba"..L.HSWAVE, "|cffffdbad"..L.HSFAREWELL, "|cff7777aa"..L.HSTIRED, "|cff00ff00"..L.HSSMIRK,
	"|cffffd200"..L.HSPRAISE, "|cffff6b00"..L.HSLOVE,	"|cffff2f32"..L.HSLOST, "|cfff58cba"..L.HSKISS,
	"|cffffdbad"..L.HSGAZE,	"|cff7777aa"..L.HSABSENT,
}
local HearthstoneEmotes = {
	"BLINK", "SMILE", "GOING", "YAWN", "WAVE", "BYE", "TIRED",
	"SMIRK", "PRAISE", "LOVE", "LOST", "KISS", "GAZE", "ABSENT",
}
local ResurrectedStyles = {
	"|cff00ff00"..L.REZTHANK, "|cffffd200"..L.REZHUG, "|cffff6b00"..L.REZBLINK, "|cffff2f32"..L.REZKISS,
	"|cfff58cba"..L.REZSMILE, "|cffffdbad"..L.REZPRAISE, "|cff7777aa"..L.REZLOVE, "|cff00ff00"..L.REZGAZE,
	"|cffffd200"..L.REZABSENT, "|cffff6b00"..L.REZPURR, "|cffff2f32"..L.REZSEXY, "|cfff58cba"..L.REZDANCE,
	"|cffffdbad"..L.REZBOW, "|cff7777aa"..L.REZCHEER,
}
local ResurrectedEmotes = {
	"THANK", "HUG", "BLINK", "KISS", "SMILE", "PRAISE",
	"LOVE", "GAZE", "ABSENT", "PURR", "SEXY", "DANCE",
	"BOW", "CHEER",
}
local CombatModeChannels = {
	"|cffaaeeff"..L.PARTY, "|cffff6b00"..L.RAID, "Solo",
}
local PartyChannels = {
	('PARTY'), ('SAY'), ('YELL'),
}
local PartyQuoteChannels = {
	"|cffaaeeff"..L.PARTY, L.SAY, "|cffff2f32"..L.YELL,
}
local RaidChannels = {
	('PARTY'), ('RAID'), ('SAY'), ('YELL'),
}
local RaidQuoteChannels = {
	"|cffaaeeff"..L.PARTY, "|cffff6b00"..L.RAID, L.SAY, "|cffff2f32"..L.YELL,
}
local SoloChannels = {
	('CHAT'), ('SAY'), ('YELL'),
}
local SoloQuoteChannels = {
	"|cffffdbad"..L.CHAT, L.SAY, "|cffff2f32"..L.YELL,
}
local SoulSoloChannels = {
	('CHAT'), ('SAY'), ('SAY'), ('YELL'), ('YELL'),
}
local SoulSoloQuoteChannels = {
	"|cffffdbad"..L.CHAT, L.SAY, L.SAYWHISPER, "|cffff2f32"..L.YELL, "|cffff2f32"..L.YELLWHISPER,
}
local SoulPartyChannels = {
	('PARTY'), ('PARTY'), ('SAY'), ('SAY'), ('YELL'), ('YELL'),
}
local SoulPartyQuoteChannels = {
	"|cffaaeeff"..L.PARTY, "|cffaaeeff"..L.PARTYWHISPER, L.SAY, L.SAYWHISPER, "|cffff2f32"..L.YELL, "|cffff2f32"..L.YELLWHISPER,
}
local SoulRaidChannels = {
	('PARTY'), ('PARTY'), ('RAID'), ('RAID'), ('SAY'), ('SAY'), ('YELL'), ('YELL'),
}
local SoulRaidQuoteChannels = {
	"|cffaaeeff"..L.PARTY, "|cffaaeeff"..L.PARTYWHISPER, "|cffff6b00"..L.RAID, "|cffff6b00"..L.RAIDWHISPER, L.SAY,
	L.SAYWHISPER, "|cffff2f32"..L.YELL, "|cffff2f32"..L.YELLWHISPER,
}

local toggle_option = { 
	name = function(info) return SoulSpeak:GetName(info) end,
	desc = function(info)
	if string.find(info[#info], L.FGRD) then return db.SUMfgrdQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.WGRD) then return db.SUMwgrdQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.FEL) then return db.SUMfelQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.FIMP) then return db.SUMfimpQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.IMP) then return db.SUMimpQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.OBS) then return db.SUMobsQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SUC) then return db.SUMsucQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SHI) then return db.SUMshiQuotes[tonumber(string.match(info[#info], "%d%d"))]		
	elseif string.find(info[#info], L.VOID) then return db.SUMvoidQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.VOIDL) then return db.SUMvoidlQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RESURRECTION.." "..L.QUOTE) then return db.ResurrectionQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RESURRECTION.." "..L.WHISPER) then return db.ResurrectionWhispers[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SOULSTONE.." "..L.EMOTE) then return db.SoulstoneEmotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SOULSTONE.." "..L.QUOTE) then return db.SoulstoneQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SOULSTONE.." "..L.WHISPER) then return db.SoulstoneWhispers[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RITUALSOULS) then return db.RitualSoulsQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RITUALSUMMONING) then return db.RitualSummoningQuotes[tonumber(string.match(info[#info], "%d%d"))] end
	end,
	type = "input", get = "getSSopt", set = "setSSopt", disabled = "disSSopt",
}

local SoulSpeakBlock = LibStub("LibDataBroker-1.1"):NewDataObject("SoulSpeak", {
	type = "data source", icon = "Interface\\Icons\\Spell_Shadow_SoulGem",
	OnClick = function(self, button)
		if button == "LeftButton" and IsAltKeyDown() then
				RestartGx()
		elseif button == "RightButton" then
			if IsAltKeyDown() then
				ReloadUI()
			else
				SoulSpeak:OpenOptions()
			end
		end
	end,
	OnTooltipShow = function(tooltip)
		local color = "|cffff0000"
		tooltip:AddLine("\124TInterface\\Icons\\Spell_Shadow_SoulGem:14\124t SoulSpeak v"..GetAddOnMetadata("SoulSpeak", "version"))
		tooltip:AddLine(" ")

		color = "|cffff0000"
		if db.RitualSouls == true then
			if db.RitualSoulsFrequency == 100 then color = "|cff00ff00"
			elseif db.RitualSoulsFrequency >= 75 and db.RitualSoulsFrequency < 100 then color = "|cff7fff7f"
			elseif db.RitualSoulsFrequency >= 50 and db.RitualSoulsFrequency < 75 then color = "|cffffff00"
			elseif db.RitualSoulsFrequency >= 25 and db.RitualSoulsFrequency < 50 then color = "|cffffff78"
			elseif db.RitualSoulsFrequency >= 1 and db.RitualSoulsFrequency < 25 then color = "|cffff6b00"
			end
			local tt = "|cffffffff"
			tt = tt.."["..color..db.RitualSoulsFrequency.."%|cffffffff]"
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_shadesofdarkness:14\124t |cffffffff"..L.RITUALSOULS.." "..L.QUOTE,tt)
		else
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_shadesofdarkness:14\124t |cffffffff"..L.RITUALSOULS.." "..L.QUOTE,"|cffffffff["..color..L.OFF.."|cffffffff]")
		end

		color = "|cffff0000"
		if db.RitualSummoning == true then
			if db.RitualSummoningFrequency == 100 then color = "|cff00ff00"
			elseif db.RitualSummoningFrequency >= 75 and db.RitualSummoningFrequency < 100 then color = "|cff7fff7f"
			elseif db.RitualSummoningFrequency >= 50 and db.RitualSummoningFrequency < 75 then color = "|cffffff00"
			elseif db.RitualSummoningFrequency >= 25 and db.RitualSummoningFrequency < 50 then color = "|cffffff78"
			elseif db.RitualSummoningFrequency >= 1 and db.RitualSummoningFrequency < 25 then color = "|cffff6b00"
			end
			local tt = "|cffffffff"
			tt = tt.."["..color..db.RitualSummoningFrequency.."%|cffffffff]"
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_twilight:14\124t |cffffffff"..L.RITUALSUMMONING.." "..L.QUOTE,tt)
		else
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_twilight:14\124t |cffffffff"..L.RITUALSUMMONING.." "..L.QUOTE,"|cffffffff["..color..L.OFF.."|cffffffff]")
		end

		color = "|cffff0000"
		if db.Soulstone == true then
			local tt = "|cffffffff"
			if db.SoulstoneSelf == true then
				if db.SoulstoneEmoteFrequency == 100 then color = "|cff00ff00"
				elseif db.SoulstoneEmoteFrequency >= 75 and db.SoulstoneEmoteFrequency < 100 then color = "|cff7fff7f"
				elseif db.SoulstoneEmoteFrequency >= 50 and db.SoulstoneEmoteFrequency < 75 then color = "|cffffff00"
				elseif db.SoulstoneEmoteFrequency >= 25 and db.SoulstoneEmoteFrequency < 50 then color = "|cffffff78"
				elseif db.SoulstoneEmoteFrequency >= 1 and db.SoulstoneEmoteFrequency < 25 then color = "|cffff6b00"
				end
				tt = tt.."[|cffADFF2F"..L.EMOTE:gsub("^%l", string.upper).."|cffbbbbbb("..color..db.SoulstoneEmoteFrequency.."%|cffbbbbbb)|cffffffff]"
			else
				color = "|cffff0000"
				tt = tt.."[|cffADFF2F"..L.EMOTE:gsub("^%l", string.upper).."|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]"
			end
			if db.SoulstoneQuoteFrequency > 0 then
				if db.SoulstoneQuoteFrequency == 100 then color = "|cff00ff00"
				elseif db.SoulstoneQuoteFrequency >= 75 and db.SoulstoneQuoteFrequency < 100 then color = "|cff7fff7f"
				elseif db.SoulstoneQuoteFrequency >= 50 and db.SoulstoneQuoteFrequency < 75 then color = "|cffffff00"
				elseif db.SoulstoneQuoteFrequency >= 25 and db.SoulstoneQuoteFrequency < 50 then color = "|cffffff78"
				elseif db.SoulstoneQuoteFrequency >= 1 and db.SoulstoneQuoteFrequency < 25 then color = "|cffff6b00"
				end
				tt = tt.."|cffffffff[|cffADFF2F"..L.QUOTE:gsub("^%l", string.upper).."|cffbbbbbb("..color..db.SoulstoneQuoteFrequency.."%|cffbbbbbb)|cffffffff]"
			else
				color = "|cffff0000"
				tt = tt.."|cffffffff[|cffADFF2F"..L.QUOTE:gsub("^%l", string.upper).."|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]"
			end
			if db.SoulstoneWhisperFrequency > 0 then
				if db.SoulstoneWhisperFrequency == 100 then color = "|cff00ff00"
				elseif db.SoulstoneWhisperFrequency >= 75 and db.SoulstoneWhisperFrequency < 100 then color = "|cff7fff7f"
				elseif db.SoulstoneWhisperFrequency >= 50 and db.SoulstoneWhisperFrequency < 75 then color = "|cffffff00"
				elseif db.SoulstoneWhisperFrequency >= 25 and db.SoulstoneWhisperFrequency < 50 then color = "|cffffff78"
				elseif db.SoulstoneWhisperFrequency >= 1 and db.SoulstoneWhisperFrequency < 25 then color = "|cffff6b00"
				end
				tt = tt.."|cffffffff[|cffADFF2F"..L.WHISPER:gsub("^%l", string.upper).."|cffbbbbbb("..color..db.SoulstoneWhisperFrequency.."%|cffbbbbbb)|cffffffff]"
			else
				color = "|cffff0000"
				tt = tt.."|cffffffff[|cffADFF2F"..L.WHISPER:gsub("^%l", string.upper).."|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]"
			end
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_SoulGem:14\124t |cffffffff"..L.SOULSTONE.." ",tt)			
			local tt = "|cffffffff"
			if db.ResurrectionQuoteFrequency > 0 then
				if db.ResurrectionQuoteFrequency == 100 then color = "|cff00ff00"
				elseif db.ResurrectionQuoteFrequency >= 75 and db.ResurrectionQuoteFrequency < 100 then color = "|cff7fff7f"
				elseif db.ResurrectionQuoteFrequency >= 50 and db.ResurrectionQuoteFrequency < 75 then color = "|cffffff00"
				elseif db.ResurrectionQuoteFrequency >= 25 and db.ResurrectionQuoteFrequency < 50 then color = "|cffffff78"
				elseif db.ResurrectionQuoteFrequency >= 1 and db.ResurrectionQuoteFrequency < 25 then color = "|cffff6b00"
				end
				tt = tt.."[|cffADFF2F"..L.QUOTE:gsub("^%l", string.upper).."|cffbbbbbb("..color..db.ResurrectionQuoteFrequency.."%|cffbbbbbb)|cffffffff]"
			else
				color = "|cffff0000"
				tt = tt.."[|cffADFF2F"..L.QUOTE:gsub("^%l", string.upper).."|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]"
			end
			if db.ResurrectionWhisperFrequency > 0 then
				if db.ResurrectionWhisperFrequency == 100 then color = "|cff00ff00"
				elseif db.ResurrectionWhisperFrequency >= 75 and db.ResurrectionWhisperFrequency < 100 then color = "|cff7fff7f"
				elseif db.ResurrectionWhisperFrequency >= 50 and db.ResurrectionWhisperFrequency < 75 then color = "|cffffff00"
				elseif db.ResurrectionWhisperFrequency >= 25 and db.ResurrectionWhisperFrequency < 50 then color = "|cffffff78"
				elseif db.ResurrectionWhisperFrequency >= 1 and db.ResurrectionWhisperFrequency < 25 then color = "|cffff6b00"
				end
				tt = tt.."|cffffffff[|cffADFF2F"..L.WHISPER:gsub("^%l", string.upper).."|cffbbbbbb("..color..db.ResurrectionWhisperFrequency.."%|cffbbbbbb)|cffffffff]"
			else
				color = "|cffff0000"
				tt = tt.."|cffffffff[|cffADFF2F"..L.WHISPER:gsub("^%l", string.upper).."|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]"
			end

			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_SoulGem:14\124t |cffffffff"..L.SSR.." ",tt)			
		else
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_Shadow_SoulGem:14\124t |cffffffff"..L.SSR,"|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]")
		end

		color = "|cffff0000"
		if db.SUM == true then
			local demon_frequency = {db.SUMfgrdFrequency, db.SUMwgrdFrequency,	db.SUMfelFrequency, db.SUMimpFrequency, db.SUMfimpFrequency, db.SUMobsFrequency, db.SUMsucFrequency, db.SUMshiFrequency, db.SUMvoidFrequency, db.SUMvoidlFrequency}
			local average_frequency = 0
			local n = 0
			for i = 1, 10 do
				average_frequency = average_frequency + demon_frequency[i]
				if demon_frequency[i] > 0 then n = n + 1 end
			end
			average_frequency = average_frequency / n
			average_frequency = math.floor(average_frequency + 0.5)
			local tt = "|cffffffff"
			color = "|cffff0000"
			if db.SUMcombat == true then
				local n = 0
				for i = 1, 3 do
					if db.SUMcombatModeChannels[i] == true then n = n + 1 end
				end
				if n == 3 then color = "|cff00ff00"
				elseif n == 2 then color = "|cffffff00"
				else color = "|cffff6b00"
				end
				tt = tt.."[|cffaaeeff"..L.COMBAT:gsub("^%l", string.upper).."|cffbbbbbb("..color..n.."/3|cffbbbbbb)|cffffffff]"
			else
				tt = tt.."[|cffaaeeff"..L.COMBAT:gsub("^%l", string.upper).."|cffbbbbbb("..color..L.OFF.."|cffbbbbbb)|cffffffff]"
			end
			if average_frequency == 100 then color = "|cff00ff00"
			elseif average_frequency >= 75 and average_frequency < 100 then color = "|cff7fff7f"
			elseif average_frequency >= 50 and average_frequency < 75 then color = "|cffffff00"
			elseif average_frequency >= 25 and average_frequency < 50 then color = "|cffffff78"
			elseif average_frequency >= 1 and average_frequency < 25 then color = "|cffff6b00"
			end
			tt = tt.."|cffffffff["..color..average_frequency.."%|cffffffff]"
			tooltip:AddDoubleLine(db.lastSUMicon.."4\124t |cffffffff"..L.SUMMONS.." "..L.QUOTE,tt)
		else
			tooltip:AddDoubleLine(db.lastSUMicon.."4\124t |cffffffff"..L.SUMMONS.." "..L.QUOTE,""..color..L.OFF.."|cffffffff]")
		end

		if db.Hearthstone == true then
			local hs_emote = {db.randomHSmorning, db.randomHSafternoon, db.randomHSevening, db.randomHSnight}
			local n = 0
			for i = 1, 4 do
				if hs_emote[i] == true then n = n + 1 end
			end
			if n > 0 == true then
				if n == 4 then rcolor = "|cff00ff00" fcolor = "|cffff2f32"
				elseif n == 3 then rcolor = "|cff7fff7f" fcolor = "|cffff6b00"
				elseif n == 2 then rcolor = "|cffffff00" fcolor = "|cffffff00"
				elseif n == 1 then rcolor = "|cffff6b00" fcolor = "|cff7fff7f"
				end
			else
				rcolor = "|cffff2f32" fcolor = "|cff00ff00"
			end
			if db.HearthstoneFrequency == 100 then color = "|cff00ff00"
			elseif db.HearthstoneFrequency >= 75 and db.HearthstoneFrequency < 100 then color = "|cff7fff7f"
			elseif db.HearthstoneFrequency >= 50 and db.HearthstoneFrequency < 75 then color = "|cffffff00"
			elseif db.HearthstoneFrequency >= 25 and db.HearthstoneFrequency < 50 then color = "|cffffff78"
			elseif db.HearthstoneFrequency >= 1 and db.HearthstoneFrequency < 25 then color = "|cffff6b00"
			end
			local tt = "|cffffffff"
			tt = tt.."["..fcolor..string.lower(L.FIXED).."|cffffffff/"..rcolor..L.RANDOM
			tt = tt.."|cffffffff][|cff888888"..color..db.HearthstoneFrequency.."%|cffbbbbbb)|cffffffff]"
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Inv_misc_rune_01:14\124t |cffffffff"..L.HEARTHSTONE.." "..L.EMOTE,tt)			
		else
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Inv_misc_rune_01:14\124t |cffffffff"..L.HEARTHSTONE.." "..L.EMOTE,"|cffffffff["..color..L.OFF.."|cffffffff]")
		end

		color = "|cffff0000"
		if db.Resurrected == true then
			local res_emote = {db.randomRESparty, db.randomRESraid, db.randomRESsolo}
			local n = 0
			for i = 1, 3 do
				if res_emote[i] == true then n = n + 1 end
			end
			if n > 0 == true then
				if n == 3 then rcolor = "|cff00ff00" fcolor = "|cffff2f32"
				elseif n == 2 then rcolor = "|cff7fff7f" fcolor = "|cffff6b00"
				elseif n == 1 then rcolor = "|cffff6b00" fcolor = "|cff7fff7f"
				end
			else
				rcolor = "|cffff2f32" fcolor = "|cff00ff00"
			end
			if db.RESfrequency == 100 then color = "|cff00ff00"
			elseif db.RESfrequency >= 75 and db.RESfrequency < 100 then color = "|cff7fff7f"
			elseif db.RESfrequency >= 50 and db.RESfrequency < 75 then color = "|cffffff00"
			elseif db.RESfrequency >= 25 and db.RESfrequency < 50 then color = "|cffffff78"
			elseif db.RESfrequency >= 1 and db.RESfrequency < 25 then color = "|cffff6b00"
			end
			local tt = "|cffffffff"
			tt = tt.."["..fcolor..string.lower(L.FIXED).."|cffffffff/"..rcolor..L.RANDOM
			tt = tt.."|cffffffff]["..color..db.RESfrequency.."%|cffbbbbbb)|cffffffff]"
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_holy_resurrection:14\124t |cffffffff"..L.RESURRECTED.." "..L.EMOTE,tt)			
		else
			tooltip:AddDoubleLine("\124TInterface\\Icons\\Spell_holy_resurrection:14\124t |cffffffff"..L.RESURRECTED.." "..L.EMOTE,"|cffffffff["..color..L.OFF.."|cffffffff]")
		end		
				
		tooltip:AddLine(" ")
		tooltip:AddLine("|cffeda55f"..L.RIGHTCLICK.."|r "..L.FOROPTIONS, 0.2, 1, 0.2)
		tooltip:AddLine("|cffeda55f"..L.ALTCLICK.."|r "..L.RESTARTGFX, 0.2, 1, 0.2)
		tooltip:AddLine("|cffeda55f"..L.ALTRIGHTCLICK.."|r "..L.RELOADUI, 0.2, 1, 0.2)
	end,
})

local SoulstoneOptions = {
	handler = SoulSpeak,
	type = 'group',
	childGroups = "tab",
	name = "\124TInterface\\Icons\\Spell_Shadow_SoulGem:16\124t "..L.SSR.." "..L.MANAGEMENT,
	order = 3,
	args = {
		options = {
			name = "\124TInterface\\Icons\\Classicon_warlock:16\124t "..L.OPTIONS,
			order = 0,
			type = "group",
			args = {
				Soulstone = {
    			type = "toggle",
    			name = L.USE,
    			desc = L.QUOTESCASTING,
					order = 2,
     			get = "getSSopt",
     			set = "setSSopt",
 				},
				ssTab = {
 					type = "description",
   				name = "",
					order = 3,
    		},
    		SoulstoneParty = {
    			type = "toggle",
    			name = L.INPARTY,
    			desc = L.USEQUOTESPARTY,
					order = 4,
     			get = "getSSopt",
    			set = "setSSopt",
     			disabled = "disSSopt",
    		},
				SoulstonePartyChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 5,
    			get = "getSSopt",
    			set = "setSSopt",
					values = SoulPartyQuoteChannels,
     			disabled = "disSSopt",
     			width = "double"
				},
    		SoulstoneRaid = {
		    	type = "toggle",
  	  		name = L.INRAID,
    			desc = L.USEQUOTESRAID,
					order = 7,
     			get = "getSSopt",
    			set = "setSSopt",
     			disabled = "disSSopt",
    		},
				SoulstoneRaidChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 8,
    			get = "getSSopt",
    			set = "setSSopt",
					values = SoulRaidQuoteChannels,
     			disabled = "disSSopt",
     			width = "double"
				},
    		SoulstoneSolo = {
    			type = "toggle",
    			name = L.BYOURSELF,
    			desc = L.USEQUOTESOLO,
					order = 10,
     			get = "getSSopt",
    			set = "setSSopt",
     			disabled = "disSSopt",
    		},
				SoulstoneSoloChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 11,
    			get = "getSSopt",
    			set = "setSSopt",
					values = SoulSoloQuoteChannels,
     			disabled = "disSSopt",
     			width = "double"
				},
				SoulstoneSelf = {
		 			type = "toggle",
  	 			name = L.ONYOURSELF,
   				desc = L.USEMOTEYOURSELF,
					order = 13,
     			get = "getSSopt",
    			set = "setSSopt",
     			disabled = "disSSopt",
    		},
			},
		},
		SoulstoneEmoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L.EMOTES,
			order = 10,
			args = {
				SoulstoneEMmaxScale = {
					order = 1,
					type = "range",
					name = L.ENABLEDEMOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 21, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
 					disabled = "disSSopt",
 				},
 				SoulstoneEmoteFrequency = {
					order = 2,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 1, max = 100, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SoulstoneEmoteTab = {
 					type = "description",
 					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
 					desc = " ",
 					order = 3,
				},						
				SSemoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 4,
					childGroups = "input",
					args = {
						[L.SOULSTONE.." "..L.EMOTE.." #01"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #02"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #03"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #04"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #05"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #06"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #07"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #08"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #09"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #10"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #11"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #12"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #13"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #14"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #15"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #16"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #17"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #18"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #19"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #20"] = toggle_option,
						[L.SOULSTONE.." "..L.EMOTE.." #21"] = toggle_option,
					},
				},
			},
		},
		SoulstoneQuoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L.QUOTES,
			order = 12,
			args = {
				SoulstoneQuotesmaxScale = {
					order = 1,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 39, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				SoulstoneQuoteFrequency = {
					order = 2,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SoulstoneQuoteTab = {
					type = "description",
 					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCTARGET.."\n|cFF00FF00"..L.GENTARGET.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
	 				desc = " ",
 					order = 3,
				},
				SSquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 4,
					childGroups = "input",
					args = {
						[L.SOULSTONE.." "..L.QUOTE.." #01"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #02"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #03"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #04"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #05"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #06"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #07"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #08"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #09"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #10"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #11"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #12"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #13"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #14"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #15"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #16"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #17"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #18"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #19"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #20"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #21"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #22"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #23"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #24"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #25"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #26"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #27"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #28"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #29"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #30"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #31"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #32"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #33"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #34"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #35"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #36"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #37"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #38"] = toggle_option,
						[L.SOULSTONE.." "..L.QUOTE.." #39"] = toggle_option,
					},
				},						
			},
		},
		SoulstoneWhisperOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L.WHISPERS,
			order = 13,
			args = {
				SoulstoneWhispersmaxScale = {
					order = 1,
					type = "range",
					name = L.ENABLEDWHISPERS,			
					desc = L.MAXTOUSE,
					min = 1, max = 24, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				SoulstoneWhisperFrequency = {
					order = 2,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				SoulstoneWhisperTab = {
					type = "description",
					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCTARGET.."\n|cFF00FF00"..L.GENTARGET.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
					desc = " ",
					order = 3,
				},
				SSwhisperGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 4,
					childGroups = "input",
					args = {
						[L.SOULSTONE.." "..L.WHISPER.." #01"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #02"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #03"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #04"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #05"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #06"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #07"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #08"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #09"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #10"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #11"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #12"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #13"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #14"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #15"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #16"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #17"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #18"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #19"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #20"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #21"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #22"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #23"] = toggle_option,
						[L.SOULSTONE.." "..L.WHISPER.." #24"] = toggle_option,
					},
				},
			},
		},
		ResurrectionQuoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L["RESURRECTION"].." "..L.QUOTES,
			order = 14,
			args = {
				ResurrectionQuotesmaxScale = {
					order = 1,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 66, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				ResurrectionQuoteFrequency = {
					order = 2,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				ResurrectionQuoteTab = {
					type = "description",
 					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCTARGET.."\n|cFF00FF00"..L.GENTARGET.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
	 				desc = " ",
 					order = 3,
				},
				RRquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 4,
					childGroups = "input",
					args = {
						[L.RESURRECTION.." "..L.QUOTE.." #01"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #02"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #03"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #04"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #05"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #06"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #07"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #08"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #09"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #10"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #11"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #12"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #13"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #14"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #15"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #16"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #17"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #18"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #19"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #20"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #21"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #22"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #23"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #24"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #25"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #26"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #27"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #28"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #29"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #30"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #31"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #32"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #33"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #34"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #35"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #36"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #37"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #38"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #39"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #40"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #41"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #42"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #43"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #44"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #45"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #46"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #47"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #48"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #49"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #50"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #51"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #52"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #53"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #54"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #55"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #56"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #57"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #58"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #59"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #60"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #61"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #62"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #63"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #64"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #65"] = toggle_option,
						[L.RESURRECTION.." "..L.QUOTE.." #66"] = toggle_option,
					},
				},						
			},
		},
		ResurrectionWhisperOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L["RESURRECTION"].." "..L.WHISPERS,
			order = 15,
			args = {
				ResurrectionWhispersmaxScale = {
					order = 1,
					type = "range",
					name = L.ENABLEDWHISPERS,			
					desc = L.MAXTOUSE,
					min = 1, max = 36, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				ResurrectionWhisperFrequency = {
					order = 2,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				ResurrectionWhisperTab = {
					type = "description",
					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCTARGET.."\n|cFF00FF00"..L.GENTARGET.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
					desc = " ",
					order = 3,
				},
				RRwhisperGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 4,
					childGroups = "input",
					args = {
						[L.RESURRECTION.." "..L.WHISPER.." #01"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #02"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #03"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #04"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #05"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #06"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #07"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #08"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #09"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #10"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #11"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #12"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #13"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #14"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #15"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #16"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #17"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #18"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #19"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #20"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #21"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #22"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #23"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #24"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #25"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #26"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #27"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #28"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #29"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #30"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #31"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #32"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #33"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #34"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #35"] = toggle_option,
						[L.RESURRECTION.." "..L.WHISPER.." #36"] = toggle_option,
					},
				},
			},
		},
	},
}

local RitualSoulsOptions = {
	handler = SoulSpeak,
	type = 'group',
	childGroups = "tab",
	name = "\124TInterface\\Icons\\Spell_Shadow_shadesofdarkness:16\124t "..L.RITUALSOULS.." "..L.MANAGEMENT,
	order = 1,
	args = {
		options = {
			name = "\124TInterface\\Icons\\Classicon_warlock:16\124t "..L.OPTIONS,
			order = 0,
			type = "group",
			args = {
				RitualSouls = {
 					type = "toggle",
   				name = L.USE,
   				desc = L.QUOTESCASTING,
					order = 1,
     			get = "getSSopt",
     			set = "setSSopt",
				},
				RitualSoulsFrequency = {
					order = 2,
				type = "range",
				name = L.FREQUENCY,
				desc = L.FREQDESC,
				min = 1, max = 100, step = 1,
   			get = "getSSopt",
   			set = "setSSopt",
				disabled = "disSSopt",
				},
		 		rsTab1 = {
					type = "description",
					name = "",
					order = 3,
 				},
 				RitualSoulsParty = {
 					type = "toggle",
   				name = L.INPARTY,
   				desc = L.USEQUOTESPARTY,
					order = 5,
     			get = "getSSopt",
   				set = "setSSopt",
					disabled = "disSSopt",
 				},
				RitualSoulsPartyChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 6,
   				get = "getSSopt",
   				set = "setSSopt",
					values = PartyQuoteChannels,
					disabled = "disSSopt",
					width = "double"
				},
 				RitualSoulsRaid = {
 					type = "toggle",
   				name = L.INRAID,
   				desc = L.USEQUOTESRAID,
					order = 8,
     			get = "getSSopt",
   				set = "setSSopt",
					disabled = "disSSopt",
 				},
				RitualSoulsRaidChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 9,
   				get = "getSSopt",
   				set = "setSSopt",
					values = RaidQuoteChannels,
					disabled = "disSSopt",
					width = "double"
				},
				RitualSoulsChatFrame = {
					type = "toggle",
					name = L.INCHAT,
					desc = L.SENDCHAT,
					order = 11,
     			get = "getSSopt",
   				set = "setSSopt",
					disabled = "disSSopt",
					width = "double"
 				},
		 		rsTab2 = {
					type = "description",
					name = "",
					order = 12,
 				},
 			},
 		},
		RitualSoulsQuoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L.QUOTES,
			order = 10,
			args = {
				RitualSoulsQuotesmaxScale = {
					order = 14,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 21, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
 					disabled = "disSSopt",
				},					
				RitualSoulsQuoteTab = {
					type = "description",
					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
					desc = " ",
					order = 15,
				},
				RSOquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 16,
					childGroups = "input",
					args = {
						[L.RITUALSOULS.." #01"] = toggle_option,
						[L.RITUALSOULS.." #02"] = toggle_option,
						[L.RITUALSOULS.." #03"] = toggle_option,
						[L.RITUALSOULS.." #04"] = toggle_option,
						[L.RITUALSOULS.." #05"] = toggle_option,
						[L.RITUALSOULS.." #06"] = toggle_option,
						[L.RITUALSOULS.." #07"] = toggle_option,
						[L.RITUALSOULS.." #08"] = toggle_option,
						[L.RITUALSOULS.." #09"] = toggle_option,
						[L.RITUALSOULS.." #10"] = toggle_option,
						[L.RITUALSOULS.." #11"] = toggle_option,
						[L.RITUALSOULS.." #12"] = toggle_option,
						[L.RITUALSOULS.." #13"] = toggle_option,
						[L.RITUALSOULS.." #14"] = toggle_option,
						[L.RITUALSOULS.." #15"] = toggle_option,
						[L.RITUALSOULS.." #16"] = toggle_option,
						[L.RITUALSOULS.." #17"] = toggle_option,
						[L.RITUALSOULS.." #18"] = toggle_option,
						[L.RITUALSOULS.." #19"] = toggle_option,
						[L.RITUALSOULS.." #20"] = toggle_option,
						[L.RITUALSOULS.." #21"] = toggle_option,
					},
				},
			},
		},
	},
}

local RitualSummoningOptions = {
	handler = SoulSpeak,
	type = 'group',
	childGroups = "tab",
	name = "\124TInterface\\Icons\\Spell_Shadow_twilight:16\124t "..L.RITUALSUMMONING.." "..L.MANAGEMENT,
	order = 2,
	args = {
		options = {
			name = "\124TInterface\\Icons\\Classicon_warlock:16\124t "..L.OPTIONS,
			order = 0,
			type = "group",
			args = {
				RitualSummoning = {
 					type = "toggle",
   				name = L.USE,
   				desc = L.QUOTESCASTING,
					order = 1,
     			get = "getSSopt",
     			set = "setSSopt",
 				},
				RitualSummoningFrequency = {
					order = 2,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 1, max = 100, step = 1,
   				get = "getSSopt",
   				set = "setSSopt",
					disabled = "disSSopt",
				},
		 		rsuTab1 = {
					type = "description",
					name = "",
					order = 3,
 				},
 				RitualSummoningParty = {
 					type = "toggle",
   				name = L.INPARTY,
   				desc = L.USEQUOTESPARTY,
					order = 5,
     			get = "getSSopt",
     			set = "setSSopt",
					disabled = "disSSopt",
 				},
				RitualSummoningPartyChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 6,
   				get = "getSSopt",
   				set = "setSSopt",
					values = PartyQuoteChannels,
					disabled = "disSSopt",
					width = "double"
				},
 				RitualSummoningRaid = {
 					type = "toggle",
   				name = L.INRAID,
   				desc = L.USEQUOTESRAID,
					order = 8,
     			get = "getSSopt",
     			set = "setSSopt",
					disabled = "disSSopt",
 				},
				RitualSummoningRaidChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 9,
   				get = "getSSopt",
   				set = "setSSopt",
					values = RaidQuoteChannels,
					disabled = "disSSopt",
					width = "double"
				},
				RitualSummoningChatFrame = {
 					type = "toggle",
   				name = L.INCHAT,
   				desc = L.SENDCHAT,
					order = 11,
     			get = "getSSopt",
     			set = "setSSopt",
					disabled = "disSSopt",
					width = "double"
 				},
		 		rsuTab2 = {
					type = "description",
					name = "",
					order = 12,
 				},

				RitualSummoningHelpme = {
 					type = "toggle",
   				name = L.HELPME,
   				desc = L.EMOTESCASTING,
					order = 13,
    			get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
 				},
 			},
 		},
		RitualSummoningQuoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Inv_misc_book_09:16\124t "..L.QUOTES,
			order = 10,
			args = {
				RitualSummoningQuotesmaxScale = {
					order = 13,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 33, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},					
				RitualSummoningQuoteTab = {
					type = "description",
					name = "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE,
					desc = " ",
					order = 14,
				},
				RSUquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 15,
					childGroups = "input",
					args = {
						[L.RITUALSUMMONING.." #01"] = toggle_option,
						[L.RITUALSUMMONING.." #02"] = toggle_option,
						[L.RITUALSUMMONING.." #03"] = toggle_option,
						[L.RITUALSUMMONING.." #04"] = toggle_option,
						[L.RITUALSUMMONING.." #05"] = toggle_option,
						[L.RITUALSUMMONING.." #06"] = toggle_option,
						[L.RITUALSUMMONING.." #07"] = toggle_option,
						[L.RITUALSUMMONING.." #08"] = toggle_option,
						[L.RITUALSUMMONING.." #09"] = toggle_option,
						[L.RITUALSUMMONING.." #10"] = toggle_option,
						[L.RITUALSUMMONING.." #11"] = toggle_option,
						[L.RITUALSUMMONING.." #12"] = toggle_option,
						[L.RITUALSUMMONING.." #13"] = toggle_option,
						[L.RITUALSUMMONING.." #14"] = toggle_option,
						[L.RITUALSUMMONING.." #15"] = toggle_option,
						[L.RITUALSUMMONING.." #16"] = toggle_option,
						[L.RITUALSUMMONING.." #17"] = toggle_option,
						[L.RITUALSUMMONING.." #18"] = toggle_option,
						[L.RITUALSUMMONING.." #19"] = toggle_option,
						[L.RITUALSUMMONING.." #20"] = toggle_option,
						[L.RITUALSUMMONING.." #21"] = toggle_option,
						[L.RITUALSUMMONING.." #22"] = toggle_option,
						[L.RITUALSUMMONING.." #23"] = toggle_option,
						[L.RITUALSUMMONING.." #24"] = toggle_option,
						[L.RITUALSUMMONING.." #25"] = toggle_option,
						[L.RITUALSUMMONING.." #26"] = toggle_option,
						[L.RITUALSUMMONING.." #27"] = toggle_option,
						[L.RITUALSUMMONING.." #28"] = toggle_option,
						[L.RITUALSUMMONING.." #29"] = toggle_option,
						[L.RITUALSUMMONING.." #30"] = toggle_option,
						[L.RITUALSUMMONING.." #31"] = toggle_option,
						[L.RITUALSUMMONING.." #32"] = toggle_option,
						[L.RITUALSUMMONING.." #33"] = toggle_option,
					},
				},
 			},
 		},
 	},
}

local sumOptions = {
	handler = SoulSpeak,
	type = 'group',
	childGroups = "tab",
	name = function(info) return db.lastSUMicon.."6\124t "..L.SUMMONS.." "..L.MANAGEMENT end,
	order = 4,
	args = {
		options = {
			name = "\124TInterface\\Icons\\Classicon_warlock:16\124t "..L.OPTIONS,
			order = 0,
			type = "group",
			args = {
 				SUM = {
 					type = "toggle",
   				name = L.USE,
   				desc = L.QUOTES..L.EMOTESUM,
   				order = 2,
     			get = "getSSopt",
     			set = "setSSopt",
 				},
 				sumTab1 = {
					type = "description",
					name = "",
					order = 3,
 				},
 				SUMparty = {
 					type = "toggle",
   				name = L.INPARTY,
   				desc = L.USEQUOTESPARTY,
					order = 4,
     			get = "getSSopt",
   				set = "setSSopt",
     			disabled = "disSSopt",
 				},
				SUMpartyChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 5,
   				get = "getSSopt",
   				set = "setSSopt",
					values = PartyQuoteChannels,
     			disabled = "disSSopt",
				},
 				sumTab2 = {
					type = "description",
					name = "",
					order = 6,
 				},
 				SUMraid = {
 					type = "toggle",
   				name = L.INRAID,
   				desc = L.USEQUOTESRAID,
					order = 7,
     			get = "getSSopt",
   				set = "setSSopt",
     			disabled = "disSSopt",
 				},
				SUMraidChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 8,
   				get = "getSSopt",
   				set = "setSSopt",
					values = RaidQuoteChannels,
     			disabled = "disSSopt",
				},
 				sumTab3 = {
					type = "description",
					name = "",
					order = 9,
 				},	
 				SUMsolo = {
 					type = "toggle",
   				name = L.BYOURSELF,
   				desc = L.USEQUOTESOLO,
					order = 10,
     			get = "getSSopt",
   				set = "setSSopt",
     			disabled = "disSSopt",
 				},
				SUMsoloChannels = {
					type = 'select',
					name = L.SELECTEDCHANNEL,
					desc = L.SELECTCHANNEL,
					order = 11,
   				get = "getSSopt",
   				set = "setSSopt",
					values = SoloQuoteChannels,
     			disabled = "disSSopt",
				},
				sumTab4 = {
					type = "description",
					name = "",
					order = 12,
 				},
				sumLine = {
			  	type = "header",
			  	name = "",
			  	order = 13,
			  },
 				SUMcombat = {
 					type = "toggle",
   				name = "Use while in combat",
					order = 14,
     			get = "getSSopt",
   				set = "setSSopt",
     			disabled = "disSSopt",
 				},
				SUMcombatModeChannels = {
					type = 'multiselect',
					name = ".."..L.AND.." "..L.ACTIVATED.." "..L.IN,
					order = 15,
					get = function(_, x) return db.SUMcombatModeChannels[x] end,
   				set = function(_, x, y)
		      	local n = 0
						for i = 1, 3 do
							if db.SUMcombatModeChannels[i] == false then n=n+1 end
						end
					if n == 2 then db.SUMcombatModeChannels[x] = true else db.SUMcombatModeChannels[x] = y end
          end,
					values = CombatModeChannels,
     			disabled = "disSSopt",
				},
			},
		},
		FGRDquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Spell_Shadow_summonfelguard:16\124t "..L.FGRD.." "..string.lower(L.QUOTES),
			order = 1,
			args = {
				SUMfgrdQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMfgrdFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				FGRDquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.FGRD..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMfgrd.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				FGRDquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.FGRD.." #01"] = toggle_option,
						[L.FGRD.." #02"] = toggle_option,
						[L.FGRD.." #03"] = toggle_option,
						[L.FGRD.." #04"] = toggle_option,
						[L.FGRD.." #05"] = toggle_option,
						[L.FGRD.." #06"] = toggle_option,
						[L.FGRD.." #07"] = toggle_option,
						[L.FGRD.." #08"] = toggle_option,
						[L.FGRD.." #09"] = toggle_option,
						[L.FGRD.." #10"] = toggle_option,
						[L.FGRD.." #11"] = toggle_option,
						[L.FGRD.." #12"] = toggle_option,
						[L.FGRD.." #13"] = toggle_option,
						[L.FGRD.." #14"] = toggle_option,
						[L.FGRD.." #15"] = toggle_option,
					},
				},
			},
		},
		WGRDquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Spell_warlock_summonwrathguard:16\124t "..L.WGRD.." "..string.lower(L.QUOTES),
			order = 2,
			args = {
				SUMwgrdQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMwgrdFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				WGRDquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.WGRD..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMwgrd.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				WGRDquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.WGRD.." #01"] = toggle_option,
						[L.WGRD.." #02"] = toggle_option,
						[L.WGRD.." #03"] = toggle_option,
						[L.WGRD.." #04"] = toggle_option,
						[L.WGRD.." #05"] = toggle_option,
						[L.WGRD.." #06"] = toggle_option,
						[L.WGRD.." #07"] = toggle_option,
						[L.WGRD.." #08"] = toggle_option,
						[L.WGRD.." #09"] = toggle_option,
						[L.WGRD.." #10"] = toggle_option,
						[L.WGRD.." #11"] = toggle_option,
						[L.WGRD.." #12"] = toggle_option,
						[L.WGRD.." #13"] = toggle_option,
						[L.WGRD.." #14"] = toggle_option,
						[L.WGRD.." #15"] = toggle_option,
					},
				},
			},
		},
		FELquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Spell_Shadow_summonfelhunter:16\124t "..L.FEL.." "..string.lower(L.QUOTES),
			order = 3,
			args = {
				SUMfelQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMfelFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				FELquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.FEL..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMfel.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				FELquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.FEL.." #01"] = toggle_option,
						[L.FEL.." #02"] = toggle_option,
						[L.FEL.." #03"] = toggle_option,
						[L.FEL.." #04"] = toggle_option,
						[L.FEL.." #05"] = toggle_option,
						[L.FEL.." #06"] = toggle_option,
						[L.FEL.." #07"] = toggle_option,
						[L.FEL.." #08"] = toggle_option,
						[L.FEL.." #09"] = toggle_option,
						[L.FEL.." #10"] = toggle_option,
						[L.FEL.." #11"] = toggle_option,
						[L.FEL.." #12"] = toggle_option,
						[L.FEL.." #13"] = toggle_option,
						[L.FEL.." #14"] = toggle_option,
						[L.FEL.." #15"] = toggle_option,
					},
				},
			},
		},
		OBSquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\WARLOCK_SUMMON_ BEHOLDER:16\124t "..L.OBS.." "..string.lower(L.QUOTES),
			order = 4,
			args = {
				SUMobsQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMobsFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				OBSquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.OBS..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMobs.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				OBSquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.OBS.." #01"] = toggle_option,
						[L.OBS.." #02"] = toggle_option,
						[L.OBS.." #03"] = toggle_option,
						[L.OBS.." #04"] = toggle_option,
						[L.OBS.." #05"] = toggle_option,
						[L.OBS.." #06"] = toggle_option,
						[L.OBS.." #07"] = toggle_option,
						[L.OBS.." #08"] = toggle_option,
						[L.OBS.." #09"] = toggle_option,
						[L.OBS.." #10"] = toggle_option,
						[L.OBS.." #11"] = toggle_option,
						[L.OBS.." #12"] = toggle_option,
						[L.OBS.." #13"] = toggle_option,
						[L.OBS.." #14"] = toggle_option,
						[L.OBS.." #15"] = toggle_option,
					},
				},
			},
		},				
		IMPquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Spell_Shadow_summonimp:16\124t "..L.IMP.." "..string.lower(L.QUOTES),
			order = 5,
			args = {
				SUMimpQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 24, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMimpFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				IMPquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.IMP..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMimp.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				IMPquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.IMP.." #01"] = toggle_option,
						[L.IMP.." #02"] = toggle_option,
						[L.IMP.." #03"] = toggle_option,
						[L.IMP.." #04"] = toggle_option,
						[L.IMP.." #05"] = toggle_option,
						[L.IMP.." #06"] = toggle_option,
						[L.IMP.." #07"] = toggle_option,
						[L.IMP.." #08"] = toggle_option,
						[L.IMP.." #09"] = toggle_option,
						[L.IMP.." #10"] = toggle_option,
						[L.IMP.." #11"] = toggle_option,
						[L.IMP.." #12"] = toggle_option,
						[L.IMP.." #13"] = toggle_option,
						[L.IMP.." #14"] = toggle_option,
						[L.IMP.." #15"] = toggle_option,
						[L.IMP.." #16"] = toggle_option,
						[L.IMP.." #17"] = toggle_option,
						[L.IMP.." #18"] = toggle_option,
						[L.IMP.." #19"] = toggle_option,
						[L.IMP.." #20"] = toggle_option,
						[L.IMP.." #21"] = toggle_option,
						[L.IMP.." #22"] = toggle_option,
						[L.IMP.." #23"] = toggle_option,
						[L.IMP.." #24"] = toggle_option,
					},
				},
			},
		},
		FIMPquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\spell_warlock_summonimpoutland:16\124t "..L.FIMP.." "..string.lower(L.QUOTES),
			order = 6,
			args = {
				SUMfimpQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 24, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMfimpFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				FIMPquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.FIMP..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMfimp.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				FIMPquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.FIMP.." #01"] = toggle_option,
						[L.FIMP.." #02"] = toggle_option,
						[L.FIMP.." #03"] = toggle_option,
						[L.FIMP.." #04"] = toggle_option,
						[L.FIMP.." #05"] = toggle_option,
						[L.FIMP.." #06"] = toggle_option,
						[L.FIMP.." #07"] = toggle_option,
						[L.FIMP.." #08"] = toggle_option,
						[L.FIMP.." #09"] = toggle_option,
						[L.FIMP.." #10"] = toggle_option,
						[L.FIMP.." #11"] = toggle_option,
						[L.FIMP.." #12"] = toggle_option,
						[L.FIMP.." #13"] = toggle_option,
						[L.FIMP.." #14"] = toggle_option,
						[L.FIMP.." #15"] = toggle_option,
						[L.FIMP.." #16"] = toggle_option,
						[L.FIMP.." #17"] = toggle_option,
						[L.FIMP.." #18"] = toggle_option,
						[L.FIMP.." #19"] = toggle_option,
						[L.FIMP.." #20"] = toggle_option,
						[L.FIMP.." #21"] = toggle_option,
						[L.FIMP.." #22"] = toggle_option,
						[L.FIMP.." #23"] = toggle_option,
						[L.FIMP.." #24"] = toggle_option,
					},
				},
			},
		},		
		SUCquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Spell_Shadow_summonsuccubus:16\124t "..L.SUC.." "..string.lower(L.QUOTES),
			order = 7,
			args = {
				SUMsucQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMsucFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUCquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.SUC..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMsuc.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				SUCquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.SUC.." #01"] = toggle_option,
						[L.SUC.." #02"] = toggle_option,
						[L.SUC.." #03"] = toggle_option,
						[L.SUC.." #04"] = toggle_option,
						[L.SUC.." #05"] = toggle_option,
						[L.SUC.." #06"] = toggle_option,
						[L.SUC.." #07"] = toggle_option,
						[L.SUC.." #08"] = toggle_option,
						[L.SUC.." #09"] = toggle_option,
						[L.SUC.." #10"] = toggle_option,
						[L.SUC.." #11"] = toggle_option,
						[L.SUC.." #12"] = toggle_option,
						[L.SUC.." #13"] = toggle_option,
						[L.SUC.." #14"] = toggle_option,
						[L.SUC.." #15"] = toggle_option,
					},
				},
			},
		},
		SHIquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\WARLOCK_SUMMON_ SHIVAN:16\124t "..L.SHI.." "..string.lower(L.QUOTES),
			order = 8,
			args = {
				SUMshiQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMshiFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				SHIquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.SHI..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMshi.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				SHIquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.SHI.." #01"] = toggle_option,
						[L.SHI.." #02"] = toggle_option,
						[L.SHI.." #03"] = toggle_option,
						[L.SHI.." #04"] = toggle_option,
						[L.SHI.." #05"] = toggle_option,
						[L.SHI.." #06"] = toggle_option,
						[L.SHI.." #07"] = toggle_option,
						[L.SHI.." #08"] = toggle_option,
						[L.SHI.." #09"] = toggle_option,
						[L.SHI.." #10"] = toggle_option,
						[L.SHI.." #11"] = toggle_option,
						[L.SHI.." #12"] = toggle_option,
						[L.SHI.." #13"] = toggle_option,
						[L.SHI.." #14"] = toggle_option,
						[L.SHI.." #15"] = toggle_option,
					},
				},
			},
		},
		VOIDquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\Spell_Shadow_summonvoidwalker:16\124t "..L.VOID.." "..string.lower(L.QUOTES),
			order = 9,
			args = {
				SUMvoidQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMvoidFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				VOIDquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.VOID..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMvoid.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				VOIDquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.VOID.." #01"] = toggle_option,
						[L.VOID.." #02"] = toggle_option,
						[L.VOID.." #03"] = toggle_option,
						[L.VOID.." #04"] = toggle_option,
						[L.VOID.." #05"] = toggle_option,
						[L.VOID.." #06"] = toggle_option,
						[L.VOID.." #07"] = toggle_option,
						[L.VOID.." #08"] = toggle_option,
						[L.VOID.." #09"] = toggle_option,
						[L.VOID.." #10"] = toggle_option,
						[L.VOID.." #11"] = toggle_option,
						[L.VOID.." #12"] = toggle_option,
						[L.VOID.." #13"] = toggle_option,
						[L.VOID.." #14"] = toggle_option,
						[L.VOID.." #15"] = toggle_option,
					},
				},
			},
		},
		VOIDLquoteOptions = {
			type = 'group',
			name = "\124TInterface\\Icons\\WARLOCK_SUMMON_ VOIDLORD:16\124t "..L.VOIDL.." "..string.lower(L.QUOTES),
			order = 10,
			args = {
				SUMvoidlQuotesmaxScale = {
					order = 2,
					type = "range",
					name = L.ENABLEDQUOTES,			
					desc = L.MAXTOUSE,
					min = 1, max = 15, step = 1,
 					get = "getSSopt",
 					set = "setSSopt",
					disabled = "disSSopt",
				},
				SUMvoidlFrequency = {
					order = 3,
					type = "range",
					name = L.FREQUENCY,
					desc = L.FREQDESC,
					min = 0, max = 100, step = 1,
					get = "getSSopt",
					set = "setSSopt",
					disabled = "disSSopt",
				},
				VOIDLquoteTab = {
					type = "description",
					name = function() return "|cFF00FF00"..L.SUPPORT.."\n|cff7fff7f"..L.TAGDESCPLAYER.."\n|cFF00FF00"..L.GENPLAYER.." |cffff0000"..L.ONLY.." |cFF00FF00"..L.AND.." |cffff0000"..L.NOT.." |cFF00FF00"..L.CASESENSITIVE.."\n"..L.IFNONAME.."\n"..L.VOIDL..L.NAMEDETECT.."|cffff0000<|cffB0A0ff"..db.SUMvoidl.."|cffff0000>" end,
					desc = " ",
					order = 4,
				},						
				VOIDLquoteGroup = {
					type = "group",
					name = " ",
					guiInline = true,
					order = 5,
					childGroups = "input",
					args = {
						[L.VOIDL.." #01"] = toggle_option,
						[L.VOIDL.." #02"] = toggle_option,
						[L.VOIDL.." #03"] = toggle_option,
						[L.VOIDL.." #04"] = toggle_option,
						[L.VOIDL.." #05"] = toggle_option,
						[L.VOIDL.." #06"] = toggle_option,
						[L.VOIDL.." #07"] = toggle_option,
						[L.VOIDL.." #08"] = toggle_option,
						[L.VOIDL.." #09"] = toggle_option,
						[L.VOIDL.." #10"] = toggle_option,
						[L.VOIDL.." #11"] = toggle_option,
						[L.VOIDL.." #12"] = toggle_option,
						[L.VOIDL.." #13"] = toggle_option,
						[L.VOIDL.." #14"] = toggle_option,
						[L.VOIDL.." #15"] = toggle_option,
					},
				},
			},
		},
	},
}

local HearthstoneOptions = {
	handler = SoulSpeak,
	type = 'group',
	name = "\124TInterface\\Icons\\Inv_misc_rune_01:16\124t "..L.HEARTHSTONE.." "..L.MANAGEMENT,
	order = 5,
	args = {
		header = {
			type = "header",
			name = "",
			order = 0,
		},
  	Hearthstone = {
   		type = "toggle",
   		name = L.USE,
   		desc = L.EMOTEWITHYOURHS,
   		order = 1,
     	get = "getSSopt",
     	set = "setSSopt",
  	},
		HearthstoneFrequency = {
			order = 2,
			type = "range",
			name = L.FREQUENCY,
			desc = L.FREQDESC,
			min = 1, max = 100, step = 1,
    	get = "getSSopt",
    	set = "setSSopt",
			disabled = "disSSopt",
		},
 		hsTab = {
			type = "description",
			name = "",
			order = 3,
 		},
		hsLine = {
			type = "header",
			name = "",
			order = 4,
		},
  	morningHearthstone = {
  		type = "toggle",
    	name = L.HSMORNING,
    	order = 10,
     	get = "getSSopt",
    	set = "setSSopt",
     	disabled = "disSSopt",
  	},
		morningEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTMORNING,
			order = 11,
     	get = "getSSopt",
    	set = "setSSopt",
			values = HearthstoneStyles,
     	disabled = "disSSopt",
     	width = "double"
		},
		randomHSmorning = {
    	type = "toggle",
    	name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
    	order = 12,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
    },
    hsTab2 = {
			type = "description",
			name = "",
			order = 13,
 		},
		hsLine2 = {
			type = "header",
			name = "",
			order = 14,
		},
  	afternoonHearthstone = {
  		type = "toggle",
    	name = L.HSAFTERNOON,
    	order = 20,
     	get = "getSSopt",
    	set = "setSSopt",
     	disabled = "disSSopt",
  	},      								
		afternoonEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTAFTERNOON,
			order = 21,
     	get = "getSSopt",
    	set = "setSSopt",
			values = HearthstoneStyles,
     	disabled = "disSSopt",
     	width = "double"
		},
		randomHSafternoon = {
    	type = "toggle",
    	name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
    	order = 22,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
    },
		hsTab3 = {
			type = "description",
			name = "",
			order = 23,
 		},
		hsLine3 = {
			type = "header",
			name = "",
			order = 24,
		},
  	eveningHearthstone = {
  		type = "toggle",
    	name = L.HSEVENING,
    	order = 30,
     	get = "getSSopt",
    	set = "setSSopt",
     	disabled = "disSSopt",
  	},      								
		eveningEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTEVENING,
			order = 31,
     	get = "getSSopt",
    	set = "setSSopt",
			values = HearthstoneStyles,
     	disabled = "disSSopt",
     	width = "double"
		},
		randomHSevening = {
    	type = "toggle",
    	name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
    	order = 32,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
    },
    hsTab4 = {
			type = "description",
			name = "",
			order = 33,
 		},
		hsLine4 = {
			type = "header",
			name = "",
			order = 40,
		},
    nightHearthstone = {
    	type = "toggle",
    	name = L.HSNIGHT,
    	order = 41,
     	get = "getSSopt",
    	set = "setSSopt",
     	disabled = "disSSopt",
    },    
		nightEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTNIGHT,
			order = 42,
     	get = "getSSopt",
    	set = "setSSopt",
			values = HearthstoneStyles,
     	disabled = "disSSopt",
     	width = "double"
		},
    randomHSnight = {
    	type = "toggle",
    	name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
    	order = 43,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
    },
 	},
}

local ResurrectedOptions = {
	handler = SoulSpeak,
	type = 'group',
	name = "\124TInterface\\Icons\\Spell_holy_resurrection:16\124t "..L.RESURRECTED.." "..L.MANAGEMENT,
	order = 6,
	args = {    	
		header = {
			type = "header",
			name = "",
			order = 1,
		},
 		Resurrected = {
 			type = "toggle",
   		name = L.USE,
   		desc = L.EMOTEREZ,
   		order = 2,
     	get = "getSSopt",
     	set = "setSSopt",
 		},
		RESfrequency = {
			order = 3,
			type = "range",
			name = L.FREQUENCY,
			desc = L.FREQDESC,
			min = 1, max = 100, step = 1,
   		get = "getSSopt",
   		set = "setSSopt",
			disabled = "disSSopt",
		},
		resLine = {
			type = "header",
			name = "",
			order = 4,
		},
 		RESparty = {
 			type = "toggle",
   		name = L.INPARTY,
   		desc = L.EMOTEPARTY,
   		order = 5,
     	get = "getSSopt",
			set = "setSSopt",
			disabled = "disSSopt",
 		},
		RESpartyEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTREZEMOTE,
			order = 6,
     	get = "getSSopt",
			set = "setSSopt",
			values = ResurrectedStyles,
     	disabled = "disSSopt",
     	width = "double"
		},
		randomRESparty = {
    	type = "toggle",
    	name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
    	order = 7,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
    },
    resTab2 = {
			type = "description",
			name = "",
			order = 8,
		},
    resLine2 = {
			type = "header",
			name = "",
			order = 9,
		},
 		RESraid = {
 			type = "toggle",
   		name = L.INRAID,
   		desc = L.EMOTERAID,
   		order = 10,
     	get = "getSSopt",
			set = "setSSopt",
			disabled = "disSSopt",
 		},
		RESraidEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTREZEMOTE,
			order = 11,
     	get = "getSSopt",
			set = "setSSopt",
			values = ResurrectedStyles,
			disabled = "disSSopt",
			width = "double"
		},
		randomRESraid = {
    	type = "toggle",
    	name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
    	order = 12,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
    },
    resTab3 = {
			type = "description",
			name = "",
			order = 13,
		},
		resLine3 = {
			type = "header",
			name = "",
			order = 14,
		},
 		RESsolo = {
 			type = "toggle",
   		name = L.BYOURSELF,
   		desc = L.EMOTESOLO,
   		order = 15,
     	get = "getSSopt",
			set = "setSSopt",
			disabled = "disSSopt",
 		},
		RESsoloEmotes = {
			type = 'select',
			name = L.SELECTEDEMOTE,
			desc = L.SELECTREZEMOTE,
			order = 16,
     	get = "getSSopt",
			set = "setSSopt",
			values = ResurrectedStyles,
			disabled = "disSSopt",
			width = "double"
		},
 		randomRESsolo = {
 			type = "toggle",
   		name = L.USE.." "..L.RANDOM.." "..L.EMOTE,
   		order = 17,
     	get = "getSSopt",
			set = "setSSopt",
     	disabled = "disSSopt",
 		},
 	},
 }

local AboutFrame = {
	type = "group",
	name = L.ABOUT,
  desc = L.CLICKREAD,			
	order = 7,
	args = {
		header = {
			type = "header",
			name = L.ABOUT,
			order = 0,
		},
		logo = {
			type = "description",
			name = "\124TInterface\\Icons\\Spell_Shadow_SoulGem:64\124t",
			order = 1,
		},				
		logdesc = {
			type = "description",
			name = L["ABOUT_TEXT"](GetAddOnMetadata("SoulSpeak", "version")),
			order = 2,
		},								
	},
}

local defaults = {
	profile =  {
    Hearthstone = true,
    morningHearthstone = true,
    afternoonHearthstone = true,
    eveningHearthstone = true,
    nightHearthstone = true,
    randomHSmorning = true,
    randomHSafternoon = true,
    randomHSevening = true,
    randomHSnight = true,
    morningEmotes = { Emote = 1 },
    afternoonEmotes = { Emote = 2 },
    eveningEmotes = { Emote = 3 },
    nightEmotes = { Emote = 4 },
    HearthstoneFrequency = 50,

    RitualSouls = true,
    RitualSoulsParty = true,
    RitualSoulsRaid = true,
    RitualSoulsChatFrame = false,
    RitualSoulsPartyChannels = { Channel = 1 },
    RitualSoulsRaidChannels = { Channel = 2 },
    RitualSoulsQuotesmaxScale = 19,
    RitualSoulsFrequency = 100,
    lastRSOquote = "",

    RitualSummoning = true,
    RitualSummoningHelpme = true,
    RitualSummoningParty = true,
    RitualSummoningRaid = true,
    RitualSummoningChatFrame = false,
    RitualSummoningPartyChannels = { Channel = 1 },
    RitualSummoningRaidChannels = { Channel = 2 },
    RitualSummoningQuotesmaxScale = 32,
    RitualSummoningFrequency = 100,
    lastRSUquote = "",

    Soulstone = true,
    SoulstoneParty = true,
    SoulstoneRaid = true,
    SoulstoneSelf = true,
    SoulstoneSolo = true,
    SoulstoneEmoteFrequency = 15,
    SoulstoneQuoteFrequency = 15,
    SoulstoneWhisperFrequency = 25,
    ResurrectionQuoteFrequency = 15,
    ResurrectionWhisperFrequency = 25,
    SoulstonePartyChannels = { Channel = 1 },
    SoulstoneRaidChannels = { Channel = 4 },
    SoulstoneSoloChannels = { Channel = 3 },
    SoulstoneEMmaxScale = 20,
    SoulstoneQuotesmaxScale = 39,
    SoulstoneWhispersmaxScale = 24,
    ResurrectionQuotesmaxScale = 66,
    ResurrectionWhispersmaxScale = 36,
    lastSSRemote = "",
    lastSSRquote = "",
    lastSSRwhisper = "",
    lastRRquote = "",
    lastRRwhisper = "",

		SUM = true,
		SUMcombat = false,
		SUMparty = true,
		SUMraid = true,
		SUMsolo = true,
		SUMfgrdFrequency = 15,
		SUMwgrdFrequency = 15,
		SUMfelFrequency = 15,
		SUMimpFrequency = 15,
		SUMfimpFrequency = 15,
		SUMobsFrequency = 15,
		SUMsucFrequency = 15,
		SUMshiFrequency = 15,
		SUMvoidFrequency = 15,
		SUMvoidlFrequency = 15,
		SUMcombatModeChannels = { true,true,true },
		SUMpartyChannels = { Channel = 2 },
		SUMraidChannels = { Channel = 3 },
		SUMsoloChannels = { Channel = 2 },
		SUMfgrdQuotesmaxScale = 8,
		SUMwgrdQuotesmaxScale = 8,
		SUMfelQuotesmaxScale = 6,
		SUMimpQuotesmaxScale = 23,
		SUMfimpQuotesmaxScale = 23,
		SUMobsQuotesmaxScale = 7,
		SUMsucQuotesmaxScale = 14,
		SUMshiQuotesmaxScale = 14,
		SUMvoidQuotesmaxScale = 13,
		SUMvoidlQuotesmaxScale = 10,
		SUMfgrd = "noname",
		SUMwgrd = "noname",
		SUMfel = "noname",
		SUMobs = "noname",
		SUMimp = "noname",
		SUMfimp = "noname",
		SUMobs = "noname",
		SUMsuc = "noname",
	  SUMshi = "noname",
		SUMvoid = "noname",
		SUMvoidl = "noname",
		lastSUMicon = "\124TInterface\\Icons\\Spell_Shadow_summonimp:1",
		lastFGRDquote = "",
		lastWGRDquote = "",
		lastFELquote = "",
		lastIMPquote = "",
		lastFIMPquote = "",
		lastOBSquote = "",
		lastSUCquote = "",
		lastSHIquote = "",
		lastVOIDquote = "",
		lastVOIDLquote = "",
    Resurrected = true,
    RESparty = true,
    RESraid = true,
    RESsolo = true,
    RESplayer = "",
    RESfrequency = 100,
    randomRESparty = true,
    randomRESraid = true,
    randomRESsolo = true,
    RESpartyEmotes = { Emote = 1 },
    RESraidEmotes = { Emote = 1 },
    RESsoloEmotes = { Emote = 1 },

    RitualSoulsQuotes = {
			L.RSOquote1,
			L.RSOquote2,
			L.RSOquote3,
			L.RSOquote4,
			L.RSOquote5,
			L.RSOquote6,
			L.RSOquote7,
			L.RSOquote8,
			L.RSOquote9,																					
			L.RSOquote10,
			L.RSOquote11,
			L.RSOquote12,
			L.RSOquote13,
			L.RSOquote14,
			L.RSOquote15,
			L.RSOquote16,
			L.RSOquote17,
			L.RSOquote18,
			L.RSOquote19,
			L.RSOquote20,
			L.RSOquote21,
    },
    RitualSummoningQuotes = {
			L.RSUquote1,
			L.RSUquote2,
			L.RSUquote3,
			L.RSUquote4,
			L.RSUquote5,
			L.RSUquote6,
			L.RSUquote7,
			L.RSUquote8,
			L.RSUquote9,
			L.RSUquote10,
			L.RSUquote11,
			L.RSUquote12,
			L.RSUquote13,
			L.RSUquote14,
			L.RSUquote15,
			L.RSUquote16,
			L.RSUquote17,
			L.RSUquote18,
			L.RSUquote19,
			L.RSUquote20,
			L.RSUquote21,
			L.RSUquote22,
			L.RSUquote23,
			L.RSUquote24,
			L.RSUquote25,
			L.RSUquote26,
			L.RSUquote27,
			L.RSUquote28,
			L.RSUquote29,
			L.RSUquote30,
			L.RSUquote31,
			L.RSUquote32,
			L.RSUquote33,
    },
    SoulstoneEmotes = {
			L.SSEquote1,
			L.SSEquote2,
			L.SSEquote3,
			L.SSEquote4,
			L.SSEquote5,
			L.SSEquote6,
			L.SSEquote7,
			L.SSEquote8,
			L.SSEquote9,																					
			L.SSEquote10,
			L.SSEquote11,
			L.SSEquote12,
			L.SSEquote13,
			L.SSEquote14,
			L.SSEquote15,
			L.SSEquote16,
			L.SSEquote17,
			L.SSEquote18,
			L.SSEquote19,
			L.SSEquote20,
			L.SSEquote21,
    },
    ResurrectionQuotes = {
			L.RRQquote1,
			L.RRQquote2,
			L.RRQquote3,
			L.RRQquote4,
			L.RRQquote5,
			L.RRQquote6,
			L.RRQquote7,
			L.RRQquote8,
			L.RRQquote9,																					
			L.RRQquote10,
			L.RRQquote11,
			L.RRQquote12,
			L.RRQquote13,
			L.RRQquote14,
			L.RRQquote15,
			L.RRQquote16,
			L.RRQquote17,
			L.RRQquote18,
			L.RRQquote19,
			L.RRQquote20,
			L.RRQquote21,
			L.RRQquote22,
			L.RRQquote23,
			L.RRQquote24,
			L.RRQquote25,
			L.RRQquote26,
			L.RRQquote27,
			L.RRQquote28,
			L.RRQquote29,
			L.RRQquote30,
			L.RRQquote31,
			L.RRQquote32,
			L.RRQquote33,
			L.RRQquote34,
			L.RRQquote35,
			L.RRQquote36,
			L.RRQquote37,
			L.RRQquote38,
			L.RRQquote39,
			L.RRQquote40,
			L.RRQquote41,
			L.RRQquote42,
			L.RRQquote43,
			L.RRQquote44,
			L.RRQquote45,
			L.RRQquote46,
			L.RRQquote47,
			L.RRQquote48,
			L.RRQquote49,
			L.RRQquote50,
			L.RRQquote51,
			L.RRQquote52,
			L.RRQquote53,
			L.RRQquote54,
			L.RRQquote55,
			L.RRQquote56,
			L.RRQquote57,
			L.RRQquote58,
			L.RRQquote59,
			L.RRQquote60,
			L.RRQquote61,
			L.RRQquote62,
			L.RRQquote63,
			L.RRQquote64,
			L.RRQquote65,
			L.RRQquote66,
    },
    ResurrectionWhispers = {
			L.RRWquote1,
			L.RRWquote2,
			L.RRWquote3,
			L.RRWquote4,
			L.RRWquote5,
			L.RRWquote6,
			L.RRWquote7,
			L.RRWquote8,
			L.RRWquote9,
			L.RRWquote10,
			L.RRWquote11,
			L.RRWquote12,
			L.RRWquote13,
			L.RRWquote14,
			L.RRWquote15,
			L.RRWquote16,
			L.RRWquote17,
			L.RRWquote18,
			L.RRWquote19,
			L.RRWquote20,
			L.RRWquote21,
			L.RRWquote22,
			L.RRWquote23,
			L.RRWquote24,
			L.RRWquote25,
			L.RRWquote26,
			L.RRWquote27,
			L.RRWquote28,
			L.RRWquote29,
			L.RRWquote30,
			L.RRWquote31,
			L.RRWquote32,
			L.RRWquote33,
			L.RRWquote34,
			L.RRWquote35,
			L.RRWquote36,
    },
    SoulstoneQuotes = {
			L.SSQquote1,
			L.SSQquote2,
			L.SSQquote3,
			L.SSQquote4,
			L.SSQquote5,
			L.SSQquote6,
			L.SSQquote7,
			L.SSQquote8,
			L.SSQquote9,																					
			L.SSQquote10,
			L.SSQquote11,
			L.SSQquote12,
			L.SSQquote13,
			L.SSQquote14,
			L.SSQquote15,
			L.SSQquote16,
			L.SSQquote17,
			L.SSQquote18,
			L.SSQquote19,
			L.SSQquote20,
			L.SSQquote21,
			L.SSQquote22,
			L.SSQquote23,
			L.SSQquote24,
			L.SSQquote25,
			L.SSQquote26,
			L.SSQquote27,
			L.SSQquote28,
			L.SSQquote29,
			L.SSQquote30,
			L.SSQquote31,
			L.SSQquote32,
			L.SSQquote33,
			L.SSQquote34,
			L.SSQquote35,
			L.SSQquote36,
			L.SSQquote37,
			L.SSQquote38,
			L.SSQquote39,
    },
    SoulstoneWhispers = {
			L.SSWquote1,
			L.SSWquote2,
			L.SSWquote3,
			L.SSWquote4,
			L.SSWquote5,
			L.SSWquote6,
			L.SSWquote7,
			L.SSWquote8,
			L.SSWquote9,																					
			L.SSWquote10,
			L.SSWquote11,
			L.SSWquote12,
			L.SSWquote13,
			L.SSWquote14,
			L.SSWquote15,
			L.SSWquote16,
			L.SSWquote17,
			L.SSWquote18,
			L.SSWquote19,
			L.SSWquote20,
			L.SSWquote21,
			L.SSWquote22,
			L.SSWquote23,
			L.SSWquote24,
			
    },
    SUMfgrdQuotes = {
			L.FGRDquote1,
    	L.FGRDquote2,
    	L.FGRDquote3,
    	L.FGRDquote4,
    	L.FGRDquote5,
    	L.FGRDquote6,
    	L.FGRDquote7,
    	L.FGRDquote8,
    	L.FGRDquote9,
    	L.FGRDquote10,
    	L.FGRDquote11,
    	L.FGRDquote12,
    	L.FGRDquote13,
    	L.FGRDquote14,
    	L.FGRDquote15,
    },
    SUMwgrdQuotes = {
    	L.WGRDquote1,
    	L.WGRDquote2,
    	L.WGRDquote3,
    	L.WGRDquote4,
    	L.WGRDquote5,
    	L.WGRDquote6,
    	L.WGRDquote7,
    	L.WGRDquote8,
    	L.WGRDquote9,
    	L.WGRDquote10,
    	L.WGRDquote11,
    	L.WGRDquote12,
    	L.WGRDquote13,
    	L.WGRDquote14,
    	L.WGRDquote15,
    },
    SUMfelQuotes = {
    	L.FELquote1,
    	L.FELquote2,
    	L.FELquote3,
    	L.FELquote4,
    	L.FELquote5,
    	L.FELquote6,
    	L.FELquote7,
    	L.FELquote8,
    	L.FELquote9,
    	L.FELquote10,
    	L.FELquote11,
    	L.FELquote12,
    	L.FELquote13,
    	L.FELquote14,
    	L.FELquote15,
    },
    SUMimpQuotes = {
    	L.IMPquote1,
    	L.IMPquote2,
    	L.IMPquote3,
    	L.IMPquote4,
    	L.IMPquote5,
    	L.IMPquote6,
    	L.IMPquote7,
    	L.IMPquote8,
    	L.IMPquote9,
    	L.IMPquote10,
    	L.IMPquote11,
    	L.IMPquote12,
    	L.IMPquote13,
    	L.IMPquote14,
    	L.IMPquote15,
    	L.IMPquote16,
    	L.IMPquote17,
    	L.IMPquote18,
    	L.IMPquote19,
    	L.IMPquote20,
    	L.IMPquote21,
    	L.IMPquote22,
    	L.IMPquote23,
    	L.IMPquote24,
    },
    SUMfimpQuotes = {
    	L.FIMPquote1,
    	L.FIMPquote2,
    	L.FIMPquote3,
    	L.FIMPquote4,
    	L.FIMPquote5,
    	L.FIMPquote6,
    	L.FIMPquote7,
    	L.FIMPquote8,
    	L.FIMPquote9,
    	L.FIMPquote10,
    	L.FIMPquote11,
    	L.FIMPquote12,
    	L.FIMPquote13,
    	L.FIMPquote14,
    	L.FIMPquote15,
    	L.FIMPquote16,
    	L.FIMPquote17,
    	L.FIMPquote18,
    	L.FIMPquote19,
    	L.FIMPquote20,
    	L.FIMPquote21,
    	L.FIMPquote22,
    	L.FIMPquote23,
    	L.FIMPquote24,
    },
    SUMobsQuotes = {
    	L.OBSquote1,
    	L.OBSquote2,
    	L.OBSquote3,
    	L.OBSquote4,
    	L.OBSquote5,
    	L.OBSquote6,
    	L.OBSquote7,
    	L.OBSquote8,
    	L.OBSquote9,
    	L.OBSquote10,
    	L.OBSquote11,
    	L.OBSquote12,
    	L.OBSquote13,
    	L.OBSquote14,
    	L.OBSquote15,    
    },
    SUMsucQuotes = {
    	L.SUCquote1,
    	L.SUCquote2,
    	L.SUCquote3,
    	L.SUCquote4,
    	L.SUCquote5,
    	L.SUCquote6,
    	L.SUCquote7,
    	L.SUCquote8,
    	L.SUCquote9,
    	L.SUCquote10,
    	L.SUCquote11,
    	L.SUCquote12,
    	L.SUCquote13,
    	L.SUCquote14,
    	L.SUCquote15,
    },
    SUMshiQuotes = {
    	L.SHIquote1,
    	L.SHIquote2,
    	L.SHIquote3,
    	L.SHIquote4,
    	L.SHIquote5,
    	L.SHIquote6,
    	L.SHIquote7,
    	L.SHIquote8,
    	L.SHIquote9,
    	L.SHIquote10,
    	L.SHIquote11,
    	L.SHIquote12,
    	L.SHIquote13,
    	L.SHIquote14,
    	L.SHIquote15,
    },
    SUMvoidQuotes = {
    	L.VOIDquote1,
    	L.VOIDquote2,
    	L.VOIDquote3,
    	L.VOIDquote4,
    	L.VOIDquote5,
    	L.VOIDquote6,
    	L.VOIDquote7,
    	L.VOIDquote8,
    	L.VOIDquote9,
    	L.VOIDquote10,
    	L.VOIDquote11,
    	L.VOIDquote12,
    	L.VOIDquote13,
    	L.VOIDquote14,
    	L.VOIDquote15,
    },
    SUMvoidlQuotes = {
    	L.VOIDLquote1,
    	L.VOIDLquote2,
    	L.VOIDLquote3,
    	L.VOIDLquote4,
    	L.VOIDLquote5,
    	L.VOIDLquote6,
    	L.VOIDLquote7,
    	L.VOIDLquote8,
    	L.VOIDLquote9,
    	L.VOIDLquote10,
    	L.VOIDLquote11,
    	L.VOIDLquote12,
    	L.VOIDLquote13,
    	L.VOIDLquote14,
    	L.VOIDLquote15,
    },
  },
}

local function txtReplace(txt)
	local playerClass, englishClass = UnitClass("player")
	txt = txt:gsub(L.PLAYER, UnitName("player"))
	if DemonName ~= "noname" then
		txt = txt:gsub(L.PET, DemonName)
	else
		txt = txt:gsub(L.PET, "...")
	end
	if SStarget == "" or SStarget == UnitName("player") then	
		local genderTable = { L.IT, L.HE, L.SHE }
		local gender = string.match(txt, genderTable[UnitSex("player")])
		if gender ~= nil then
			txt = txt:gsub(L.HESHE, gender)
			gender = nil
		end
		genderTable = { L.ITS, L.HIM, L.HER }	
		gender = string.match(txt, genderTable[UnitSex("player")])
		if gender ~= nil then
			txt = txt:gsub(L.HIMHER, gender)
			gender = nil
		end
		genderTable = { L.ITS, L.HIS, L.HER }	
		gender = string.match(txt, genderTable[UnitSex("player")])
		if gender ~= nil then
			txt = txt:gsub(L.HISHER, gender)
			gender = nil
		end
		genderTable = { L.ITS, L.HIS, L.HERS }	
		gender = string.match(txt, genderTable[UnitSex("player")])
		if gender ~= nil then
			txt = txt:gsub(L.HISHERS, gender)
			gender = nil
		end		
		if UnitName("target") ~= nil then
			local targetClass, englishClass = UnitClass("target")	
			txt = txt:gsub(L.TARGET, (UnitName("target")))
			txt = txt:gsub(L.TARGETCLASS, targetClass)
		else
			txt = txt:gsub(L.TARGET, L.NOTARGET)
			txt = txt:gsub(L.TARGETCLASS, L.NOTARGET)
		end		
	elseif SStarget ~= "" then
		txt = txt:gsub(L.TARGET, (SStarget))
		txt = txt:gsub(L.TARGETCLASS, targetClass)		
		local gender = string.match(txt, SSgenderTable1)
		if gender ~= nil then
			txt = txt:gsub(L.HESHE, gender)
			gender = nil
		end
		gender = string.match(txt, SSgenderTable2)
		if gender ~= nil then
			txt = txt:gsub(L.HIMHER, gender)
			gender = nil
		end
		gender = string.match(txt, SSgenderTable3)
		if gender ~= nil then
			txt = txt:gsub(L.HISHER, gender)
			gender = nil
		end
		gender = string.match(txt, SSgenderTable4)
		if gender ~= nil then
			txt = txt:gsub(L.HISHERS, gender)
			gender = nil
		end
	end	
	return txt
end

function SoulSpeak:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("SoulSpeakDB", defaults)
  db = self.db.profile
	SoulSpeak.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	SoulSpeak.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	SoulSpeak.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")	
	local AceConfig = LibStub("AceConfig-3.0")
	local AceConfigDialog = LibStub("AceConfigDialog-3.0")
  local about_panel = LibStub:GetLibrary("LibAboutPanel", true)
  
	if about_panel then
		self.optionsFrame = about_panel.new(nil, "SoulSpeak")
	end
	
	AceConfig:RegisterOptionsTable("RitualSoulsOptions", RitualSoulsOptions)
  AceConfig:RegisterOptionsTable("RitualSummoningOptions", RitualSummoningOptions)
  AceConfig:RegisterOptionsTable("Soulstone Resurrection", SoulstoneOptions)
  AceConfig:RegisterOptionsTable("sumOptions", sumOptions)
  AceConfig:RegisterOptionsTable("Hearthstone emotes", HearthstoneOptions)
  AceConfig:RegisterOptionsTable("ResurrectedOptions", ResurrectedOptions)
  AceConfig:RegisterOptionsTable("SoulSpeak About", AboutFrame)
  AceConfig:RegisterOptionsTable("SoulSpeak Profiles", LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db))

  AceConfigDialog:AddToBlizOptions("RitualSoulsOptions", L.RITUALSOULS, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("RitualSummoningOptions", L.RITUALSUMMONING, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("Soulstone Resurrection", L.SSR, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("sumOptions", L.SUMMONS, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("Hearthstone emotes", L.HEARTHSTONE, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("ResurrectedOptions", L.RESURRECTED, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("SoulSpeak About", L.ABOUT, "SoulSpeak")
  AceConfigDialog:AddToBlizOptions("SoulSpeak Profiles", L.PROFILES, "SoulSpeak")
  
  self:RegisterChatCommand("ss", "ChatCommand")
  self:RegisterChatCommand("SoulSpeak", "ChatCommand")
  --self:Print("|cffB0A0ff<SoulSpeak>|r v|cffffd200"..GetAddOnMetadata("SoulSpeak", "version").."|r initialized. Type /ss or use hotkey for options.")
  self:Print("v|cffffd200"..GetAddOnMetadata("SoulSpeak", "version").."|r initialized. Type |cffB0A0ff/ss|r or use |cffB0A0ffhotkey|r for options.")
end

function SoulSpeak:OnProfileChanged(event, database, newProfileKey)
	self.db = LibStub("AceDB-3.0"):New("SoulSpeakDB", defaults)
  db = self.db.profile
 	SoulSpeak.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	SoulSpeak.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	SoulSpeak.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
end

function SoulSpeak:OnEnable()
	self:RegisterEvent("UNIT_PET")
	self:RegisterEvent("PLAYER_ALIVE")
	self:RegisterEvent("PLAYER_UNGHOST")
	self:RegisterEvent("RESURRECT_REQUEST")
	self:RegisterEvent("UNIT_SPELLCAST_SENT")
	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
end

function SoulSpeak:GetName(info)
	local n = info[#info]
	return (n)
end

function SoulSpeak:ChatCommand(input)
	PlaySound("igSpellBookOpen")
	-- Fix for Blizzard addon panel (http://www.wowace.com/paste/8364)
	-- Bail out if already loaded and up to date
	local MAJOR, MINOR = "InterfaceOptionsFix", 1
--	if _G[MAJOR] and _G[MAJOR].version >= MINOR then return end
	-- Reuse the existing frame or create a new one
	local frame = _G[MAJOR] or CreateFrame("Frame", MAJOR, _G.InterfaceOptionsFrame)
	frame.version = MINOR
	-- Hook once and the call the possibly upgraded methods
	if not frame.Saved_InterfaceOptionsFrame_OpenToCategory then
  	-- Save the unhooked function
    frame.Saved_InterfaceOptionsFrame_OpenToCategory = _G.InterfaceOptionsFrame_OpenToCategory
    hooksecurefunc("InterfaceOptionsFrame_OpenToCategory", function(...)
    	return frame:InterfaceOptionsFrame_OpenToCategory(...)
    end)
    -- Please note that the frame is a child of InterfaceOptionsFrame, so OnUpdate won't called before InterfaceOptionsFrame is shown
    frame:SetScript('OnUpdate', function(_, ...)
        return frame:OnUpdate(...)
    end)
	end
	-- This will be called twice on first open : 
	-- 1) with the panel which is actually wanted,
	-- 2) with the "Control" panel from InterfaceOptionsFrame_OnShow (this is what actually cause the bug). 
	function frame:InterfaceOptionsFrame_OpenToCategory(panel)
  	self.panel = panel
	end
	function frame:OnUpdate()
    local panel = self.panel   
    -- Clean up
    self:SetScript('OnUpdate', nil)
    self:Hide()
    self.panel = nil
    self.InterfaceOptionsFrame_OpenToCategory = function() end
    -- Call the original InterfaceOptionsFrame_OpenToCategory with the last panel
    self.Saved_InterfaceOptionsFrame_OpenToCategory(panel)
	end
	-- EoF
	InterfaceOptionsFrame_OpenToCategory(SoulSpeak.optionsFrame)
end

function SoulSpeak:OpenOptions()
	PlaySound("igSpellBookOpen")
	-- Fix for Blizzard addon panel (http://www.wowace.com/paste/8364)
	-- Bail out if already loaded and up to date
	local MAJOR, MINOR = "InterfaceOptionsFix", 1
--	if _G[MAJOR] and _G[MAJOR].version >= MINOR then return end
	-- Reuse the existing frame or create a new one
	local frame = _G[MAJOR] or CreateFrame("Frame", MAJOR, _G.InterfaceOptionsFrame)
	frame.version = MINOR
	-- Hook once and the call the possibly upgraded methods
	if not frame.Saved_InterfaceOptionsFrame_OpenToCategory then
  	-- Save the unhooked function
    frame.Saved_InterfaceOptionsFrame_OpenToCategory = _G.InterfaceOptionsFrame_OpenToCategory
    hooksecurefunc("InterfaceOptionsFrame_OpenToCategory", function(...)
    	return frame:InterfaceOptionsFrame_OpenToCategory(...)
    end)
    -- Please note that the frame is a child of InterfaceOptionsFrame, so OnUpdate won't called before InterfaceOptionsFrame is shown
    frame:SetScript('OnUpdate', function(_, ...)
        return frame:OnUpdate(...)
    end)
	end
	-- This will be called twice on first open : 
	-- 1) with the panel which is actually wanted,
	-- 2) with the "Control" panel from InterfaceOptionsFrame_OnShow (this is what actually cause the bug). 
	function frame:InterfaceOptionsFrame_OpenToCategory(panel)
  	self.panel = panel
	end
	function frame:OnUpdate()
    local panel = self.panel   
    -- Clean up
    self:SetScript('OnUpdate', nil)
    self:Hide()
    self.panel = nil
    self.InterfaceOptionsFrame_OpenToCategory = function() end
    -- Call the original InterfaceOptionsFrame_OpenToCategory with the last panel
    self.Saved_InterfaceOptionsFrame_OpenToCategory(panel)
	end
	-- EoF
	InterfaceOptionsFrame_OpenToCategory(SoulSpeak.optionsFrame)
end

function SoulSpeak:UNIT_SPELLCAST_SENT(arg1,arg2,arg3,arg4,arg5)
	if (arg3 == HSspell or arg3 == IDspell) and db.Hearthstone == true and random(1,100) <= db.HearthstoneFrequency then
		local hour,minute = GetGameTime()
		local second = (hour * 3600) + (minute * 60)
		if (second >= 0 and second < 21600) and db.nightHearthstone == true  then
			if db.randomHSnight == true then DoEmote(HearthstoneEmotes[random(1,14)])
			else
				DoEmote(HearthstoneEmotes[db.nightEmotes.Emote])
			end
		elseif (second >= 21600 and second < 43200) and db.morningHearthstone == true then
			if db.randomHSmorning == true then DoEmote(HearthstoneEmotes[random(1,14)])
			else
				DoEmote(HearthstoneEmotes[db.morningEmotes.Emote])
			end
		elseif (second >= 43200 and second < 64800) and db.afternoonHearthstone == true then
			if db.randomHSafternoon == true then DoEmote(HearthstoneEmotes[random(1,14)])
			else
				DoEmote(HearthstoneEmotes[db.afternoonEmotes.Emote])
			end
		elseif (second >= 64800 and second <= 86400) and db.eveningHearthstone == true then
			if db.randomHSevening == true then DoEmote(HearthstoneEmotes[random(1,14)])
			else
				DoEmote(HearthstoneEmotes[db.eveningEmotes.Emote])
			end
		end
	end

	if db.Soulstone == true and arg2 == "player" and arg3 == SSRspell then
		SStarget = arg5
		if UnitName("target") and arg5 == nil then SStarget = UnitName("target") end
		if UnitIsDeadOrGhost("target") then
			SSres = 2
			if UnitIsDead("target") then SSres = 1 end
		else SSres = 0 end
		targetClass, englishClass = UnitClass("target")
		genderTable = { L.IT, L.HE, L.SHE }
		SSgenderTable1 = genderTable[UnitSex("target")]
		genderTable = { L.ITS, L.HIM, L.HER }
		SSgenderTable2 = genderTable[UnitSex("target")]
		genderTable = { L.ITS, L.HIS, L.HER }
		SSgenderTable3 = genderTable[UnitSex("target")]
		genderTable = { L.ITS, L.HIS, L.HERS }
		SSgenderTable4 = genderTable[UnitSex("target")]
	else SStarget = "" end

	local start, duration, enabled = GetSpellCooldown(RSOspell)
	if db.RitualSouls == true and arg3 == RSOspell and duration == 0 and random(1,100) <= db.RitualSoulsFrequency then
		local i = 0		
		if db.RitualSoulsQuotesmaxScale == 1 then i = 1
		else
			repeat 
				i = random(1,db.RitualSoulsQuotesmaxScale)
  		until i ~= db.lastRSOquote
		end
		db.lastRSOquote = i
		if GetNumGroupMembers() > 5 and db.RitualSoulsRaid == true then
			if db.RitualSoulsQuotes[i] ~= "" then
				if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
				and 
				RaidChannels[db.RitualSoulsRaidChannels.Channel] ~= "SAY"
				and 
				RaidChannels[db.RitualSoulsRaidChannels.Channel] ~= "YELL" then
					SendChatMessage(txtReplace(db.RitualSoulsQuotes[i]),"INSTANCE_CHAT")
				else	
					SendChatMessage(txtReplace(db.RitualSoulsQuotes[i]),RaidChannels[db.RitualSoulsRaidChannels.Channel])
				end
			else
				self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
			end
		elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.RitualSoulsParty == true then
			if db.RitualSoulsQuotes[i] ~= "" then
				if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
				and 
				PartyChannels[db.RitualSoulsPartyChannels.Channel] ~= "SAY"
				and 
				PartyChannels[db.RitualSoulsPartyChannels.Channel] ~= "YELL" then
					SendChatMessage(txtReplace(db.RitualSoulsQuotes[i]),"INSTANCE_CHAT")
				else
				SendChatMessage(txtReplace(db.RitualSoulsQuotes[i]),PartyChannels[db.RitualSoulsPartyChannels.Channel])
				end
			else
				self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
			end
		elseif db.RitualSoulsChatFrame == true then
			if db.RitualSoulsQuotes[i] ~= "" then
				self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.RitualSoulsQuotes[i]))
			else
				self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
			end
		end
	end

	local start, duration, enabled = GetSpellCooldown(RSUspell)
	if db.RitualSummoning == true and arg3 == RSUspell and duration == 0 and random(1,100) <= db.RitualSummoningFrequency then
		local i = 0
		if db.RitualSummoningQuotesmaxScale == 1 then i = 1
		else
			repeat 
				i = random(1,db.RitualSummoningQuotesmaxScale)
  		until i ~= db.lastRSUquote
		end
		db.lastRSUquote = i
		if GetNumGroupMembers() > 5 and db.RitualSummoningRaid == true then
			if db.RitualSummoningQuotes[i] ~= "" then
				if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
				and 
				RaidChannels[db.RitualSummoningRaidChannels.Channel] ~= "SAY"
				and 
				RaidChannels[db.RitualSummoningRaidChannels.Channel] ~= "YELL" then
					SendChatMessage(txtReplace(db.RitualSummoningQuotes[i]),"INSTANCE_CHAT")
				else	
				SendChatMessage(txtReplace(db.RitualSummoningQuotes[i]),RaidChannels[db.RitualSummoningRaidChannels.Channel])
				end
			else
				self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
			end
		elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.RitualSummoningParty == true then
			if db.RitualSummoningQuotes[i] ~= "" then
				if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
				and 
				RaidChannels[db.RitualSummoningPartyChannels.Channel] ~= "SAY"
				and 
				RaidChannels[db.RitualSummoningPartyChannels.Channel] ~= "YELL" then
					SendChatMessage(txtReplace(db.RitualSummoningQuotes[i]),"INSTANCE_CHAT")
				else
				SendChatMessage(txtReplace(db.RitualSummoningQuotes[i]),PartyChannels[db.RitualSummoningPartyChannels.Channel])
				end
			else
				self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
			end
		elseif db.RitualSummoningChatFrame == true then
			if db.RitualSummoningQuotes[i] ~= "" then
				self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.RitualSummoningQuotes[i]))
			else
				self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
			end
		end
	end

	if UnitAffectingCombat("player") and db.SUMcombat == false then return elseif db.SUM == true then
		if arg3 == summonFGRD and random(1,100) <= db.SUMfgrdFrequency then
			local i = 0
			if db.SUMfgrdQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMfgrdQuotesmaxScale)
  			until i ~= db.lastFGRDquote
			end
			db.lastFGRDquote = i
			DemonName = db.SUMfgrd
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMfgrdQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMfgrdQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMfgrdQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end	
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMfgrdQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMfgrdQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMfgrdQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMfgrdQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMfgrdQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMfgrdQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMfgrdQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end			
		elseif arg3 == summonWGRD and random(1,100) <= db.SUMwgrdFrequency then
			local i = 0
			if db.SUMwgrdQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMwgrdQuotesmaxScale)
  			until i ~= db.lastWGRDquote
			end
			db.lastWGRDquote = i
			DemonName = db.SUMwgrd
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMwgrdQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMwgrdQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMwgrdQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end	
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMwgrdQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMwgrdQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMwgrdQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMwgrdQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMwgrdQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMwgrdQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMwgrdQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		elseif arg3 == summonFEL and random(1,100) <= db.SUMfelFrequency then
			local i = 0
			if db.SUMfelQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMfelQuotesmaxScale)
  			until i ~= db.lastFELquote
			end
			db.lastFELquote = i
			if arg3 == summonFEL then
				DemonName = db.SUMfel
			else
				DemonName = db.SUMobs
			end
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMfelQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMfelQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMfelQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMfelQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMfelQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMfelQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMfelQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMfelQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMfelQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMfelQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		elseif arg3 == summonIMP and random(1,100) <= db.SUMimpFrequency then
			local i = 0
			if db.SUMimpQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMimpQuotesmaxScale)
  			until i ~= db.lastIMPquote
			end
			db.lastIMPquote = i
			DemonName = db.SUMimp
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMimpQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMimpQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMimpQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMimpQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMimpQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMimpQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end					
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMimpQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMimpQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMimpQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMimpQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		elseif arg3 == summonFIMP and random(1,100) <= db.SUMfimpFrequency then
			local i = 0
			if db.SUMfimpQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMfimpQuotesmaxScale)
  			until i ~= db.lastFIMPquote
			end
			db.lastFIMPquote = i
			DemonName = db.SUMfimp
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMfimpQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMfimpQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMfimpQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMfimpQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMfimpQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMfimpQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end					
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMfimpQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMfimpQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMfimpQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMfimpQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		elseif arg3 == summonOBS and random(1,100) <= db.SUMobsFrequency then
			local i = 0
			if db.SUMobsQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMobsQuotesmaxScale)
  			until i ~= db.lastOBSquote
			end
			db.lastOBSquote = i
			DemonName = db.SUMobs
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMobsQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMobsQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMobsQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMobsQuotes[i] ~= "" then
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMobsQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMobsQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMobsQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMobsQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMobsQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMobsQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		elseif arg3 == summonSUC and random(1,100) <= db.SUMsucFrequency then
			local i = 0
			if db.SUMsucQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMsucQuotesmaxScale)
  			until i ~= db.lastSUCquote
			end
			db.lastSUCquote = i
			DemonName = db.SUMsuc
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMsucQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMsucQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMsucQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMsucQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMsucQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMsucQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMsucQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMsucQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMsucQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMsucQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end			
		elseif arg3 == summonSHI and random(1,100) <= db.SUMshiFrequency then
			local i = 0
			if db.SUMshiQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMshiQuotesmaxScale)
  			until i ~= db.lastSHIquote
			end
			db.lastSHIquote = i
			DemonName = db.SUMshi
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMshiQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMshiQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMshiQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMshiQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMshiQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMshiQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMshiQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMshiQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMshiQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMshiQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		elseif (arg3 == summonVOID or arg3 == summonVOIDnomana) and random(1,100) <= db.SUMvoidFrequency then
			local i = 0
			if db.SUMvoidQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMvoidQuotesmaxScale)
  			until i ~= db.lastVOIDquote
			end
			db.lastVOIDquote = i
			DemonName = db.SUMvoid
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMvoidQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMvoidQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMvoidQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMvoidQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMvoidQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMvoidQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMvoidQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMvoidQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMvoidQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMvoidQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end			
		elseif arg3 == summonVOIDL and random(1,100) <= db.SUMvoidlFrequency then
			local i = 0
			if db.SUMvoidlQuotesmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SUMvoidlQuotesmaxScale)
  			until i ~= db.lastVOIDLquote
			end
			db.lastVOIDLquote = i
			DemonName = db.SUMvoidl
			if GetNumGroupMembers() > 5 and db.SUMraid == true and db.SUMcombatModeChannels[2] == true then
				if db.SUMvoidlQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "SAY"
					and 
					RaidChannels[db.SUMraidChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMvoidlQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMvoidlQuotes[i]),RaidChannels[db.SUMraidChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SUMparty == true and db.SUMcombatModeChannels[1] == true then
				if db.SUMvoidlQuotes[i] ~= "" then					
					if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "SAY"
					and 
					PartyChannels[db.SUMpartyChannels.Channel] ~= "YELL" then
						SendChatMessage(txtReplace(db.SUMvoidlQuotes[i]),"INSTANCE_CHAT")
					else
						SendChatMessage(txtReplace(db.SUMvoidlQuotes[i]),PartyChannels[db.SUMpartyChannels.Channel])
					end
				else
					self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)				
				end
			elseif GetNumGroupMembers() == 0 and db.SUMsolo == true and db.SUMcombatModeChannels[3] == true then
				if db.SUMsoloChannels.Channel == 1 then
					if db.SUMvoidlQuotes[i] ~= "" then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SUMvoidlQuotes[i]))
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)
					end					
				else
					if db.SUMvoidlQuotes[i] ~= "" then
						SendChatMessage(txtReplace(db.SUMvoidlQuotes[i]),SoloChannels[db.SUMsoloChannels.Channel])
					else
						self:Print("|cffff0000"..L.WARNING.." |cffB0A0ff"..L.EMPTYQUOTE)												
					end
				end
			end
		end
	end
end

function SoulSpeak:UNIT_SPELLCAST_SUCCEEDED(arg1,arg2,arg3,arg4,arg5)
	if db.RitualSummoning == true and db.RitualSummoningHelpme == true and arg2 == "player" and arg3 == RSUspell then
		if GetNumGroupMembers() > 0 and random(1,100) <= db.RitualSummoningFrequency then
			DoEmote("HELPME")
			end
	end

	if db.Soulstone == true and arg2 == "player" and arg3 == SSRspell then
		if SStarget == UnitName("player") and db.SoulstoneSelf == true and random(1,100) <= db.SoulstoneEmoteFrequency then
			local i = 0
			if db.SoulstoneEMmaxScale == 1 then i = 1
			else
				repeat 
					i = random(1,db.SoulstoneEMmaxScale)
  			until i ~= db.lastSSRemote
  		end
  		if db.SoulstoneEmotes[i] ~= "" then
				SendChatMessage(txtReplace(db.SoulstoneEmotes[i]),"EMOTE",nil,"SAY")
			end
			db.lastSSRemote = i
		elseif SStarget ~= "" and SStarget ~= UnitName("player") then
			local iq = 0
			local iw = 0
			local irq = 0
			local irw = 0			
			if db.SoulstoneQuotesmaxScale == 1 then iq = 1
			else
				repeat 
					iq = random(1,db.SoulstoneQuotesmaxScale)
  			until iq ~= db.lastSSRquote
  		end
  		if db.SoulstoneWhispersmaxScale == 1 then iw = 1
  		else
				repeat 
					iw = random(1,db.SoulstoneWhispersmaxScale)
  			until iw ~= db.lastSSRwhisper
  		end
			if db.ResurrectionQuotesmaxScale == 1 then irq = 1
			else
				repeat 
					irq = random(1,db.ResurrectionQuotesmaxScale)
  			until irq ~= db.lastRRquote
  		end
  		if db.ResurrectionWhispersmaxScale == 1 then irw = 1
  		else
				repeat 
					irw = random(1,db.ResurrectionWhispersmaxScale)
  			until irw ~= db.lastRRwhisper
  		end  		
			db.lastSSRquote = iq  		
			db.lastSSRwhisper = iw
			db.lastRRquote = irq  		
			db.lastRRwhisper = irw
			if GetNumGroupMembers() > 5 and db.SoulstoneRaid == true then
				if (db.SoulstoneRaidChannels.Channel == 1 or db.SoulstoneRaidChannels.Channel == 3 or db.SoulstoneRaidChannels.Channel == 5 or db.SoulstoneRaidChannels.Channel == 7) then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then						
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "SAY"
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),SoulRaidChannels[db.SoulstoneRaidChannels.Channel])
						end
					elseif db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then						
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "SAY"
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),SoulRaidChannels[db.SoulstoneRaidChannels.Channel])
						end
					end
				elseif db.SoulstoneRaidChannels.Channel == 2 or db.SoulstoneRaidChannels.Channel == 4 or db.SoulstoneRaidChannels.Channel == 6 or db.SoulstoneRaidChannels.Channel == 8 then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "SAY"
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),SoulRaidChannels[db.SoulstoneRaidChannels.Channel])
						end
					elseif db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "SAY"
						and 
						SoulRaidChannels[db.SoulstoneRaidChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),SoulRaidChannels[db.SoulstoneRaidChannels.Channel])
						end
					end
					if db.SoulstoneWhispers[iw] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneWhisperFrequency then
						SendChatMessage(txtReplace(db.SoulstoneWhispers[iw]),"WHISPER",nil,SStarget)
					elseif  db.ResurrectionWhispers[irw] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionWhisperFrequency then
						SendChatMessage(txtReplace(db.ResurrectionWhispers[irw]),"WHISPER",nil,SStarget)
					end
				end
			elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.SoulstoneParty == true then
				if db.SoulstonePartyChannels.Channel == 1 or db.SoulstonePartyChannels.Channel == 3 or db.SoulstonePartyChannels.Channel == 5 then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "SAY"
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),SoulPartyChannels[db.SoulstonePartyChannels.Channel])
						end
					elseif db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "SAY"
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),SoulPartyChannels[db.SoulstonePartyChannels.Channel])
						end	
					end
				elseif db.SoulstonePartyChannels.Channel == 2 or db.SoulstonePartyChannels.Channel == 4 or db.SoulstonePartyChannels.Channel == 6 then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "SAY"
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),SoulPartyChannels[db.SoulstonePartyChannels.Channel])
						end
					elseif  db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then
						if (IsInGroup(LE_PARTY_CATEGORY_INSTANCE))
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "SAY"
						and 
						SoulPartyChannels[db.SoulstonePartyChannels.Channel] ~= "YELL" then
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),"INSTANCE_CHAT")
						else
							SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),SoulPartyChannels[db.SoulstonePartyChannels.Channel])
						end
					end
					if db.SoulstoneWhispers[iw] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneWhisperFrequency then
						SendChatMessage(txtReplace(db.SoulstoneWhispers[iw]),"WHISPER",nil,SStarget)
					elseif  db.ResurrectionWhispers[irw] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionWhisperFrequency then
						SendChatMessage(txtReplace(db.ResurrectionWhispers[irw]),"WHISPER",nil,SStarget)
					end
				end
			elseif GetNumGroupMembers() == 0 and db.SoulstoneSolo == true then
				if db.SoulstoneSoloChannels.Channel == 1 then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.SoulstoneQuotes[iq]))
					elseif  db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then
						self:Print("|cffff0000"..L.CHATONLY.." |cffB0A0ff"..txtReplace(db.ResurrectionQuotes[irq]))
					end
				elseif db.SoulstoneSoloChannels.Channel == 2 or db.SoulstoneSoloChannels.Channel == 4 then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then
						SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),SoulSoloChannels[db.SoulstoneSoloChannels.Channel])
					elseif  db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then
						SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),SoulSoloChannels[db.SoulstoneSoloChannels.Channel])
					end
				elseif db.SoulstoneSoloChannels.Channel == 3 or db.SoulstoneSoloChannels.Channel == 5 then
					if db.SoulstoneQuotes[iq] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneQuoteFrequency then
						SendChatMessage(txtReplace(db.SoulstoneQuotes[iq]),SoulSoloChannels[db.SoulstoneSoloChannels.Channel])
					elseif  db.ResurrectionQuotes[irq] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionQuoteFrequency then
						SendChatMessage(txtReplace(db.ResurrectionQuotes[irq]),SoulSoloChannels[db.SoulstoneSoloChannels.Channel])
					end
					if db.SoulstoneWhispers[iw] ~= "" and SSres == 0 and random(1,100) <= db.SoulstoneWhisperFrequency then
						SendChatMessage(txtReplace(db.SoulstoneWhispers[iw]),"WHISPER",nil,SStarget)
					elseif  db.ResurrectionWhispers[irw] ~= "" and SSres == 1 and random(1,100) <= db.ResurrectionWhisperFrequency then
						SendChatMessage(txtReplace(db.ResurrectionWhispers[irw]),"WHISPER",nil,SStarget)
					end
				end
			end	
		end
		SStarget = ""			
		SSres = 0
	end

	if arg2 == "player" and (arg3 == summonFGRD or arg3 == summonWGRD or arg3 == summonFEL or arg3 == summonOBS or arg3 == summonIMP or arg3 == summonFIMP or arg3 == summonSUC or arg3 == summonSHI or arg3 == summonVOID or arg3 == summonVOIDnomana or arg3 == summonVOIDL) then
		if arg3 == summonFGRD then db.lastSUMicon = "\124TInterface\\Icons\\Spell_Shadow_summonfelguard:1"
		elseif arg3 == summonWGRD then db.lastSUMicon = "\124TInterface\\Icons\\spell_warlock_summonwrathguard:1"
		elseif arg3 == summonFEL then db.lastSUMicon = "\124TInterface\\Icons\\Spell_Shadow_summonfelhunter:1"
		elseif arg3 == summonIMP then db.lastSUMicon = "\124TInterface\\Icons\\Spell_Shadow_summonimp:1"
		elseif arg3 == summonFIMP then db.lastSUMicon = "\124TInterface\\Icons\\spell_warlock_summonimpoutland:1"
		elseif arg3 == summonOBS then db.lastSUMicon = "\124TInterface\\Icons\\WARLOCK_SUMMON_ BEHOLDER:1"
		elseif arg3 == summonSUC then db.lastSUMicon = "\124TInterface\\Icons\\Spell_Shadow_summonsuccubus:1"
		elseif arg3 == summonSHI then db.lastSUMicon = "\124TInterface\\Icons\\WARLOCK_SUMMON_ SHIVAN:1"
		elseif arg3 == summonVOID or arg3 == summonVOIDnomana then db.lastSUMicon = "\124TInterface\\Icons\\Spell_Shadow_summonvoidwalker:1"
		elseif arg3 == summonVOIDL then db.lastSUMicon = "\124TInterface\\Icons\\WARLOCK_SUMMON_ VOIDLORD:1"
		end
	end
end

function SoulSpeak:UNIT_PET(arg1,arg2)
	if arg2 == "player" and (UnitName("pet")) ~= "Unknown" then
		if UnitCreatureFamily("pet") == L.FGRD and (UnitName("pet")) ~= db.SUMfgrd then
			db.SUMfgrd = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffFelguard's name saved as |cffff0000<|cffB0A0ff"..db.SUMfgrd.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.WGRD and (UnitName("pet")) ~= db.SUMwgrd then
			db.SUMwgrd = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffWrathguard's name saved as |cffff0000<|cffB0A0ff"..db.SUMwgrd.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.FEL and (UnitName("pet")) ~= db.SUMfel then
			db.SUMfel = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffFelhunter's name saved as |cffff0000<|cffB0A0ff"..db.SUMfel.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.OBS and (UnitName("pet")) ~= db.SUMobs then
			db.SUMobs = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffObserver's name saved as |cffff0000<|cffB0A0ff"..db.SUMobs.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.IMP and (UnitName("pet")) ~= db.SUMimp then
			db.SUMimp = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffImp's name saved as |cffff0000<|cffB0A0ff"..db.SUMimp.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.FIMP and (UnitName("pet")) ~= db.SUMfimp then
			db.SUMfimp = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffFel Imp's name saved as |cffff0000<|cffB0A0ff"..db.SUMfimp.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.SUC and (UnitName("pet")) ~= db.SUMsuc then
			db.SUMsuc = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffSuccubus's name saved as |cffff0000<|cffB0A0ff"..db.SUMsuc.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.SHI and (UnitName("pet")) ~= db.SUMshi then
			db.SUMshi = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffShivarra's name saved as |cffff0000<|cffB0A0ff"..db.SUMshi.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.VOID and (UnitName("pet")) ~= db.SUMvoid then
			db.SUMvoid = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffVoidwalker's name saved as |cffff0000<|cffB0A0ff"..db.SUMvoid.."|cffff0000>")
		elseif UnitCreatureFamily("pet") == L.VOIDL and (UnitName("pet")) ~= db.SUMvoidl then
			db.SUMvoidl = (UnitName("pet"))
			SoulSpeak:Print("|cffB0A0ffVoidlord's name saved as |cffff0000<|cffB0A0ff"..db.SUMvoidl.."|cffff0000>")
		end
	end
end

function SoulSpeak:RESURRECT_REQUEST(arg1,arg2)
	if db.Resurrected == true and arg2 ~= nil then
		if db.RESraid == true or db.RESparty == true or DB.RESsolo == true then db.RESplayer = arg2
		else db.RESplayer = ""
		end
	end
end

function SoulSpeak:PLAYER_UNGHOST()
	if db.Resurrected == true and db.RESplayer ~= "" and random(1,100) <= db.RESfrequency then
		if GetNumGroupMembers() > 5 and db.RESraid == true then
			if db.randomRESraid == true then DoEmote(ResurrectedEmotes[random(1,14)],db.RESplayer)
			else
				DoEmote(ResurrectedEmotes[db.RESraidEmotes.Emote],db.RESplayer)
			end
		elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.RESparty == true then
			if db.randomRESparty == true then DoEmote(ResurrectedEmotes[random(1,14)],db.RESplayer)
			else
				DoEmote(ResurrectedEmotes[db.RESpartyEmotes.Emote],db.RESplayer)
			end
		elseif GetNumGroupMembers() == 0 and db.RESsolo == true then
			if db.randomRESsolo == true then DoEmote(ResurrectedEmotes[random(1,14)],db.RESplayer)
			else
				DoEmote(ResurrectedEmotes[db.RESsoloEmotes.Emote],db.RESplayer)
			end
		end
		db.RESplayer = ""
	end
end

function SoulSpeak:PLAYER_ALIVE()
	if db.Resurrected == true and db.RESplayer ~= "" and random(1,100) <= db.RESfrequency then
		if GetNumGroupMembers() > 5 and db.RESraid == true then
			if db.randomRESraid == true then DoEmote(ResurrectedEmotes[random(1,14)],db.RESplayer)
			else
				DoEmote(ResurrectedEmotes[db.RESraidEmotes.Emote],db.RESplayer)
			end
		elseif GetNumGroupMembers() > 0 and GetNumGroupMembers() < 6 and db.RESparty == true then
			if db.randomRESparty == true then DoEmote(ResurrectedEmotes[random(1,14)],db.RESplayer)
			else
				DoEmote(ResurrectedEmotes[db.RESpartyEmotes.Emote],db.RESplayer)
			end
		elseif GetNumGroupMembers() == 0 and db.RESsolo == true then
			if db.randomRESsolo == true then DoEmote(ResurrectedEmotes[random(1,14)],db.RESplayer)
			else
				DoEmote(ResurrectedEmotes[db.RESsoloEmotes.Emote],db.RESplayer)
			end
		end
		db.RESplayer = ""
	end
end

function SoulSpeak:getSSopt(info, ...)		
	if string.find(info[#info], "Emotes") then return db[info[#info]].Emote
	elseif string.find(info[#info], "Channels") then return db[info[#info]].Channel
	elseif string.find(info[#info], L.RESURRECTION.." "..L.QUOTE) then return db.ResurrectionQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RESURRECTION.." "..L.WHISPER) then return db.ResurrectionWhispers[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SOULSTONE.." "..L.EMOTE) then return db.SoulstoneEmotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SOULSTONE.." "..L.QUOTE) then return db.SoulstoneQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SOULSTONE.." "..L.WHISPER) then return db.SoulstoneWhispers[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RITUALSOULS) then return db.RitualSoulsQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.RITUALSUMMONING) then return db.RitualSummoningQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.FGRD) then return db.SUMfgrdQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.WGRD) then return db.SUMwgrdQuotes[tonumber(string.match(info[#info], "%d%d"))]		
	elseif string.find(info[#info], L.FEL) then return db.SUMfelQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.FIMP) then return db.SUMfimpQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.IMP) then return db.SUMimpQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.OBS) then return db.SUMobsQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SUC) then return db.SUMsucQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.SHI) then return db.SUMshiQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.VOID) then return db.SUMvoidQuotes[tonumber(string.match(info[#info], "%d%d"))]
	elseif string.find(info[#info], L.VOIDL) then return db.SUMvoidlQuotes[tonumber(string.match(info[#info], "%d%d"))]
	else return db[info[#info]] end
end

function SoulSpeak:setSSopt(info, newValue)
	if string.find(info[#info], "Emotes") then db[info[#info]].Emote = newValue
	elseif string.find(info[#info], "Channels") then db[info[#info]].Channel = newValue
	elseif string.find(info[#info], L.RESURRECTION.." "..L.QUOTE) then db.ResurrectionQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.RESURRECTION.." "..L.WHISPER) then db.ResurrectionWhispers[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.SOULSTONE.." "..L.EMOTE) then db.SoulstoneEmotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.SOULSTONE.." "..L.QUOTE) then db.SoulstoneQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.SOULSTONE.." "..L.WHISPER) then db.SoulstoneWhispers[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.RITUALSOULS) then db.RitualSoulsQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.RITUALSUMMONING) then db.RitualSummoningQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.FGRD) then db.SUMfgrdQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.WGRD) then db.SUMwgrdQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.FEL) then db.SUMfelQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.FIMP) then db.SUMfimpQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.IMP) then db.SUMimpQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.OBS) then db.SUMobsQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue		
	elseif string.find(info[#info], L.SUC) then db.SUMsucQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.SHI) then db.SUMshiQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.VOID) then db.SUMvoidQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue
	elseif string.find(info[#info], L.VOIDL) then db.SUMvoidlQuotes[tonumber(string.match(info[#info], "%d%d"))] = newValue

	elseif info[#info] == "morningHearthstone" then
		if db.Hearthstone == true and newValue == false and db.afternoonHearthstone == false and db.eveningHearthstone == false and db.nightHearthstone == false then db.morningHearthstone = true
		elseif newValue == true then db.morningHearthstone = true
    else db.morningHearthstone = false end
 	elseif info[#info] == "afternoonHearthstone" then
 		if db.Hearthstone == true and newValue == false and db.morningHearthstone == false and db.eveningHearthstone == false and db.nightHearthstone == false then db.afternoonHearthstone = true
		elseif newValue == true then db.afternoonHearthstone = true
    else db.afternoonHearthstone = false end
 	elseif info[#info] == "eveningHearthstone" then
 		if db.Hearthstone == true and newValue == false and db.morningHearthstone == false and db.afternoonHearthstone == false and db.nightHearthstone == false then db.eveningHearthstone = true
		elseif newValue == true then db.eveningHearthstone = true
    else db.eveningHearthstone = false end
 	elseif info[#info] == "nightHearthstone" then
 		if db.Hearthstone == true and newValue == false and db.morningHearthstone == false and db.afternoonHearthstone == false and db.eveningHearthstone == false then db.nightHearthstone = true
		elseif newValue == true then db.nightHearthstone = true
 		else db.nightHearthstone = false end

 	elseif info[#info] == "SoulstoneParty" then
 		if db.Soulstone == true and newValue == false and db.SoulstoneSelf == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false then db.SoulstoneParty = true
		elseif newValue == true then db.SoulstoneParty = true
    else db.SoulstoneParty = false end
 	elseif info[#info] == "SoulstoneRaid" then
 		if db.Soulstone == true and newValue == false and db.SoulstoneSelf == false and db.SoulstoneParty == false and db.SoulstoneSolo == false then db.SoulstoneRaid = true
		elseif newValue == true then db.SoulstoneRaid = true
    else db.SoulstoneRaid = false end
 	elseif info[#info] == "SoulstoneSolo" then
 		if db.Soulstone == true and newValue == false and db.SoulstoneSelf == false and db.SoulstoneParty == false and db.SoulstoneRaid == false then db.SoulstoneSolo = true
		elseif newValue == true then db.SoulstoneSolo = true
    else db.SoulstoneSolo = false end
 	elseif info[#info] == "SoulstoneSelf" then
	 	if db.Soulstone == true and newValue == false and db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false then db.SoulstoneSelf = true
		elseif newValue == true then db.SoulstoneSelf = true
    else db.SoulstoneSelf = false end

	elseif info[#info] == "RitualSoulsParty" then
		if newValue == false and db.RitualSoulsRaid == false and db.RitualSoulsChatFrame == false then db.RitualSoulsParty = true
		elseif newValue == true then db.RitualSoulsParty = true
		else db.RitualSoulsParty = false end
	elseif info[#info] == "RitualSoulsRaid" then
  	if newValue == false and db.RitualSoulsParty == false and db.RitualSoulsChatFrame == false then db.RitualSoulsRaid = true
		elseif newValue == true then db.RitualSoulsRaid = true
  	else db.RitualSoulsRaid = false end
	elseif info[#info] == "RitualSoulsChatFrame" then
		if newValue == false and db.RitualSoulsParty == false and db.RitualSoulsRaid == false then db.RitualSoulsChatFrame = true
		elseif newValue == true then db.RitualSoulsChatFrame = true
  	else db.RitualSoulsChatFrame = false end
  	
	elseif info[#info] == "RitualSummoningParty" then
		if newValue == false and db.RitualSummoningRaid == false and db.RitualSummoningChatFrame == false then db.RitualSummoningParty = true
		elseif newValue == true then db.RitualSummoningParty = true
		else db.RitualSummoningParty = false end
	elseif info[#info] == "RitualSummoningRaid" then
		if newValue == false and db.RitualSummoningParty == false and db.RitualSummoningChatFrame == false then db.RitualSummoningRaid = true
		elseif newValue == true then db.RitualSummoningRaid = true
		else db.RitualSummoningRaid = false end
	elseif info[#info] == "RitualSummoningChatFrame" then
		if newValue == false and db.RitualSummoningParty == false and db.RitualSummoningRaid == false then db.RitualSummoningChatFrame = true
		elseif newValue == true then db.RitualSummoningChatFrame = true
		else db.RitualSummoningChatFrame = false end
		
	elseif info[#info] == "SUMparty" then
		if db.SUM == true and newValue == false and db.SUMraid == false and db.SUMsolo == false then db.SUMparty = true
		elseif newValue == true then db.SUMparty = true
		else db.SUMparty = false end
	elseif info[#info] == "SUMraid" then
		if db.SUM == true and newValue == false and db.SUMparty == false and db.SUMsolo == false then db.SUMraid = true
		elseif newValue == true then db.SUMraid = true
		else db.SUMraid = false end
	elseif info[#info] == "SUMsolo" then
		if db.SUM == true and newValue == false and db.SUMparty == false and db.SUMraid == false then db.SUMsolo = true
		elseif newValue == true then db.SUMsolo = true
		else db.SUMsolo = false end

	elseif info[#info] == "RESparty" then
		if newValue == false and db.RESraid == false and db.RESsolo == false then db.RESparty = true
		elseif newValue == true then db.RESparty = true
		else db.RESparty = false end
	elseif info[#info] == "RESraid" then
		if newValue == false and db.RESparty == false and db.RESsolo == false then db.RESraid = true
		elseif newValue == true then db.RESraid = true
		else db.RESraid = false end
	elseif info[#info] == "RESsolo" then
		if newValue == false and db.RESparty == false and db.RESraid == false then db.RESsolo = true
		elseif newValue == true then db.RESsolo = true
		else db.RESsolo = false end      		

	else
		db[info[#info]] = newValue
	end
end

function SoulSpeak:disSSopt(info, ...)
	if info[#info] == "morningEmotes" then return (db.Hearthstone == false or db.morningHearthstone == false or db.randomHSmorning == true)
	elseif info[#info] == "afternoonEmotes" then return (db.Hearthstone == false or db.afternoonHearthstone == false or db.randomHSafternoon == true)
	elseif info[#info] == "eveningEmotes" then return (db.Hearthstone == false or db.eveningHearthstone == false or db.randomHSevening == true)
	elseif info[#info] == "nightEmotes" then return (db.Hearthstone == false or db.nightHearthstone == false or db.randomHSnight == true)
	elseif info[#info] == "randomHSmorning" then return (db.Hearthstone == false or db.morningHearthstone == false)
	elseif info[#info] == "randomHSafternoon" then return (db.Hearthstone == false or db.afternoonHearthstone == false)
	elseif info[#info] == "randomHSevening" then return (db.Hearthstone == false or db.eveningHearthstone == false)
	elseif info[#info] == "randomHSnight" then return (db.Hearthstone == false or db.nightHearthstone == false)
	elseif string.find(info[#info], L.HEARTHSTONE) then return (db.Hearthstone == false)

	elseif string.find(info[#info], L.RESURRECTION.." "..L.QUOTE) then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false) or (db.ResurrectionQuoteFrequency == 0) or (db.ResurrectionQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "ResurrectionQuotesmaxScale" then return (db.Soulstone == false or ResurrectionQuoteFrequency == 0 or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif info[#info] == "ResurrectionQuoteFrequency" then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif string.find(info[#info], L.RESURRECTION.." "..L.WHISPER) then return (db.Soulstone == false or ResurrectionWhisperFrequency == 0 or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false) or (db.ResurrectionWhisperFrequency == 0) or (db.ResurrectionWhispersmaxScale < tonumber(string.match(info[#info], "%d%d")) ))		
	elseif info[#info] == "ResurrectionWhispersmaxScale" then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif info[#info] == "ResurrectionWhisperFrequency" then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif string.find(info[#info], L.SOULSTONE.." "..L.EMOTE) then return (db.Soulstone == false or db.SoulstoneSelf == false or (db.SoulstoneEMmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SoulstoneEMmaxScale" then return (db.Soulstone == false or db.SoulstoneSelf == false)
	elseif info[#info] == "SoulstoneEmoteFrequency" then return (db.Soulstone == false or db.SoulstoneSelf == false)
	elseif string.find(info[#info], L.SOULSTONE.." "..L.QUOTE) then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false) or (db.SoulstoneQuoteFrequency == 0) or (db.SoulstoneQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SoulstoneQuotesmaxScale" then return (db.Soulstone == false or db.SoulstoneQuoteFrequency == 0 or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif info[#info] == "SoulstoneQuoteFrequency" then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif string.find(info[#info], L.SOULSTONE.." "..L.WHISPER) then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false) or (db.SoulstoneWhisperFrequency == 0) or (db.SoulstoneWhispersmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SoulstoneWhispersmaxScale" then return (db.Soulstone == false or db.SoulstoneWhisperFrequency == 0 or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif info[#info] == "SoulstoneWhisperFrequency" then return (db.Soulstone == false or (db.SoulstoneParty == false and db.SoulstoneRaid == false and db.SoulstoneSolo == false))
	elseif info[#info] == "SoulstonePartyChannels" then return (db.Soulstone == false or db.SoulstoneParty == false)
	elseif info[#info] == "SoulstoneRaidChannels" then return (db.Soulstone == false or db.SoulstoneRaid == false)
	elseif info[#info] == "SoulstoneSoloChannels" then return (db.Soulstone == false or db.SoulstoneSolo == false)
	elseif string.find(info[#info], L.SOULSTONE) then return (db.Soulstone == false)	

	elseif string.find(info[#info], L.RITUALSOULS) then return (db.RitualSouls == false or (db.RitualSoulsQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "RitualSoulsPartyChannels" then return (db.RitualSouls == false or db.RitualSoulsParty == false)
	elseif info[#info] == "RitualSoulsRaidChannels" then return (db.RitualSouls == false or db.RitualSoulsRaid == false)
	elseif string.find(info[#info], "RitualSouls") then return (db.RitualSouls == false)

	elseif string.find(info[#info], L.RITUALSUMMONING) then return (db.RitualSummoning == false or (db.RitualSummoningQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "RitualSummoningPartyChannels" then return (db.RitualSummoning == false or db.RitualSummoningParty == false)
	elseif info[#info] == "RitualSummoningRaidChannels" then return (db.RitualSummoning == false or db.RitualSummoningRaid == false)
	elseif string.find(info[#info], "RitualSummoning") then return (db.RitualSummoning == false)

	elseif string.find(info[#info], L.FGRD) then return (db.SUM == false or (db.SUMfgrdFrequency == 0) or (db.SUMfgrdQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMfgrdQuotesmaxScale" then return (db.SUM == false or db.SUMfgrdFrequency == 0)
	elseif string.find(info[#info], L.WGRD) then return (db.SUM == false or (db.SUMwgrdFrequency == 0) or (db.SUMwgrdQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))		
	elseif info[#info] == "SUMwgrdQuotesmaxScale" then return (db.SUM == false or db.SUMwgrdFrequency == 0)
	elseif string.find(info[#info], L.FEL) then return (db.SUM == false or (db.SUMfelFrequency == 0) or (db.SUMfelQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMfelQuotesmaxScale" then return (db.SUM == false or db.SUMfelFrequency == 0)
	elseif string.find(info[#info], L.FIMP) then return (db.SUM == false or (db.SUMfimpFrequency == 0) or (db.SUMfimpQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))				
	elseif info[#info] == "SUMfimpQuotesmaxScale" then return (db.SUM == false or db.SUMfimpFrequency == 0)
	elseif string.find(info[#info], L.IMP) then return (db.SUM == false or (db.SUMimpFrequency == 0) or (db.SUMimpQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMimpQuotesmaxScale" then return (db.SUM == false or db.SUMimpFrequency == 0)
	elseif string.find(info[#info], L.OBS) then return (db.SUM == false or (db.SUMobsFrequency == 0) or (db.SUMobsQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMobsQuotesmaxScale" then return (db.SUM == false or db.SUMobsFrequency == 0)
	elseif string.find(info[#info], L.SUC) then return (db.SUM == false or (db.SUMsucFrequency == 0) or (db.SUMsucQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMsucQuotesmaxScale" then return (db.SUM == false or db.SUMsucFrequency == 0)
	elseif string.find(info[#info], L.SHI) then return (db.SUM == false or (db.SUMshiFrequency == 0) or (db.SUMshiQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))		
	elseif info[#info] == "SUMshiQuotesmaxScale" then return (db.SUM == false or db.SUMshiFrequency == 0)
	elseif string.find(info[#info], L.VOID) then return (db.SUM == false or (db.SUMvoidFrequency == 0) or (db.SUMvoidQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMvoidQuotesmaxScale" then return (db.SUM == false or db.SUMvoidFrequency == 0)
	elseif string.find(info[#info], L.VOIDL) then return (db.SUM == false or (db.SUMvoidlFrequency == 0) or (db.SUMvoidlQuotesmaxScale < tonumber(string.match(info[#info], "%d%d")) ))
	elseif info[#info] == "SUMvoidlQuotesmaxScale" then return (db.SUM == false or db.SUMvoidlFrequency == 0)

	elseif (info[#info] == "RESfrequency" or info[#info] == "RESrandom" ) then return (db.Resurrected == false)
	elseif info[#info] == "RESpartyEmotes" then return (db.Resurrected == false or db.RESparty == false or db.randomRESparty == true)
	elseif info[#info] == "RESraidEmotes" then return (db.Resurrected == false or db.RESraid == false or db.randomRESraid == true)
	elseif info[#info] == "RESsoloEmotes" then return (db.Resurrected == false or db.RESsolo == false or db.randomRESsolo == true)
	elseif info[#info] == "randomRESparty" then return (db.Resurrected == false or db.RESparty == false)
	elseif info[#info] == "randomRESraid" then return (db.Resurrected == false or db.RESraid == false)
	elseif info[#info] == "randomRESsolo" then return (db.Resurrected == false or db.RESsolo == false)
	elseif string.find(info[#info], "RES") then return (db.Resurrected == false)

	elseif info[#info] == "SUMpartyChannels"	then return (db.SUM == false or db.SUMparty == false)
	elseif info[#info] == "SUMraidChannels" then	return (db.SUM == false or db.SUMraid == false)
	elseif info[#info] == "SUMsoloChannels" then return (db.SUM == false or db.SUMsolo == false)
	elseif info[#info] == "SUMcombatModeChannels" then return (db.SUM == false or db.SUMcombat == false)
	elseif string.find(info[#info], "SUM") then return (db.SUM == false)
--	else return (db.SUM == false)
	end
end