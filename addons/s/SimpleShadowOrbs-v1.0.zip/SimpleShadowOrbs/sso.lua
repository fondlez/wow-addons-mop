-- If you aren't a priest, then disable the addon
if select(2, UnitClass("player")) ~= "PRIEST" then
	return
end


local f = CreateFrame("frame")
local max_resources = 3
local xpos = 0
local ypos = 0
local r = 0.65
local g = 0.14
local b = 0.82
local scale = 1
local hidenocombat = false
local leftanchor = "CENTER"
local ssoframes = {}
local duetohide = false
local firstrun = true
local is_hidden = true
local has_initialized = false
local old_power = 0



f:SetScript("OnEvent", function(self, event, ...)
    self[event](self, ...)
end)

local function getCharges()
	return UnitPower("player", 13);
end

local function updateResources()
	local power = getCharges()
	if old_power == power then
		return
	end
	old_power = power
	local i = 1

	while i <= power do
		ssoframes[i]:SetBackdropColor(r, g, b, 1)
		i = 1 + i
	end

	while i <= max_resources do
		ssoframes[i]:SetBackdropColor(r, g, b, 0.1)
		i = 1 + i
	end

	if duetohide and power == 0 then
		for i = 1,max_resources do
			ssoframes[i]:Hide()
		end
		duetohide = false
		is_hidden = true
	end

end


local function updateFrames()
	for i = 1,max_resources do

		ssoframes[i]:SetSize(22, 22)

		ssoframes[i]:SetBackdropColor(r, g, b, 0.1)
		ssoframes[i]:SetBackdropBorderColor(0, 0, 0, 1)
	 
		if i == 1 then
			ssoframes[i]:SetPoint(leftanchor, UIParent, leftanchor, xpos, ypos)
			ssoframes[i]:SetScale(scale)

			ssoframes[i]:SetMovable(true)
			ssoframes[i]:EnableMouse(true)
			ssoframes[i]:RegisterForDrag("LeftButton")
			ssoframes[i]:SetScript("OnDragStart", function(self)
				if IsAltKeyDown() then
					self:StartMoving()
				end
			end)
			ssoframes[i]:SetScript("OnDragStop", function(self)
				self:StopMovingOrSizing()
				anch,_, _, x, y = self:GetPoint(1)
				xpos = x
				SimpleShadowOrbsDB.xpos = x
				xpos = y
				SimpleShadowOrbsDB.ypos = y
				leftanchor = anch
				SimpleShadowOrbsDB.leftanchor = anch

			end)
			

		else
			ssoframes[i]:SetPoint("RIGHT", 23, 0)

		end

		if hidenocombat and not InCombatLockdown() then
			duetohide = true
		else
			ssoframes[i]:Show()
			is_hidden = false
		end
		

	end
	updateResources()
end

local function initFrames()
	for i = 1,max_resources do
		ssoframes[i] = CreateFrame("Frame", "SSOFrame"..i, i == 1 and UIParent or ssoframes[i-1])
		ssoframes[i]:SetBackdrop({bgFile=[[Interface\ChatFrame\ChatFrameBackground]],edgeFile=[[Interface/Tooltips/UI-Tooltip-Border]],tile=true,tileSize=4,edgeSize=4,insets={left=0.5,right=0.5,top=0.5,bottom=0.5}})
	end
	updateFrames()
	has_initialized = true
end

local function destroyFrames()
	for i = 1,max_resources do
		if ssoframes[i] ~= nil then
			ssoframes[i]:Hide()
		end
	end
	for i = 1,max_resources do
		if ssoframes[i] ~= nil then
			ssoframes[i] = nil
		end
	end
	ssoframes = {}
end

local function updateNumBoxes()
	if has_initialized == false then
		return
	end

	local old_max_resources = max_resources
	
	
	local specId = 0
	local tmp_spec = GetSpecialization()
	if tmp_spec ~= nil then
		specId = GetSpecializationInfo(tmp_spec)
	end

	if specId == 258 then
		max_resources = 3
	else 
		max_resources = 0
	end

	if max_resources == 0 then
		for i = 1,old_max_resources do
			if ssoframes[i] ~= nil then
				ssoframes[i]:Hide()
			end
		end
		is_hidden = true
	elseif old_max_resources ~= max_resources then
		if ssoframes[1] ~= nil then
			destroyFrames()
			initFrames()
		else
			initFrames()
		end
		is_hidden = false
	end
end

function SSO_ColorPickCallback(restore)
	if restore then
		r, g, b = unpack(restore)
	else
		r, g, b = ColorPickerFrame:GetColorRGB();
	end
	
	SimpleShadowOrbsDB.r = r
	SimpleShadowOrbsDB.g = g
	SimpleShadowOrbsDB.b = b

	updateFrames()
end

function f:PLAYER_ENTERING_WORLD()
	updateResources()
end

function f:PLAYER_LOGIN()
	-- 258 = shadow

	local specId = 0
	local tmp_spec = GetSpecialization()
	if tmp_spec ~= nil then
		specId = GetSpecializationInfo(tmp_spec)
	end

	if specId == 258 then
		max_resources = 3
	else 
		max_resources = 0
	end

	initFrames()
end

function f:UNIT_POWER(power_unit, power_type)


	if power_unit == "player" then  -- and power_type == SHADOW_ORBS omitted because this is fucking retarded and won't work, because apparently we're in the quantum world where SHADOW_ORBS != SHADOW_ORBS
	
		if firstrun then
			updateNumBoxes()
			firstrun = false
		end
		updateResources()
	end
end

function f:PLAYER_TALENT_UPDATE()
	updateNumBoxes()
end
	
function f:PLAYER_REGEN_DISABLED()
	updateNumBoxes()
	for i = 1,max_resources do
		ssoframes[i]:Show()
	end
	is_hidden =  false
	duetohide = false
end

function f:PLAYER_REGEN_ENABLED()
	if hidenocombat then
		if getCharges() == 0 then
			for i = 1,max_resources do
				ssoframes[i]:Hide()
			end
			is_hidden = true
		else
			duetohide = true
		end
	end
end


function f:ADDON_LOADED(addon)
	if addon ~= "SimpleShadowOrbs" then return end
	if select(2, UnitClass("player")) ~= "PRIEST" then
		return
	end

	local defaults = {
		xpos = 0,
		ypos = 0,
		r = 0.65,
		g = 0.14,
		b = 0.82,
		scale = 1,
		leftanchor = "CENTER",
		hidenocombat = false
	}
		
	SimpleShadowOrbsDB = SimpleShadowOrbsDB or {}
		
	for k,v in pairs(defaults) do
		if SimpleShadowOrbsDB[k] == nil then
			SimpleShadowOrbsDB[k] = v
		end
	end


	SLASH_SSO1, SLASH_SSO2 = "/sso", "/simpleshadoworbs"
	SlashCmdList.SSO = function(txt)
		local cmd, msg = txt:match("^(%S*)%s*(.-)$");
		cmd = string.lower(cmd)
		msg = string.lower(msg)

		if cmd == "reset" then
			xpos = 0
			ypos = 0
			r = 0.65
			g = 0.14
			b = 0.82
			scale = 1
			leftanchor = "CENTER"
			SimpleShadowOrbsDB.xpos = 0
			SimpleShadowOrbsDB.ypos = 0
			SimpleShadowOrbsDB.r = 0.65
			SimpleShadowOrbsDB.g = 0.14
			SimpleShadowOrbsDB.b = 0.82
			SimpleShadowOrbsDB.scale = 1
			SimpleShadowOrbsDB.leftanchor = "CENTER"
			
			destroyFrames()
			initFrames()

			print("Frame reset to the center, you can now move it to the desired position.")

		elseif cmd == "scale" then
			local num = tonumber(msg)
			if num then
				scale = num
				SimpleShadowOrbsDB.scale = num

				updateFrames()
			else
				print("Not a valid scale! Scale has to be a number, recommended to be between 0.5 and 3")
			end
		elseif cmd == "color" or cmd == "colour" then
			ColorPickerFrame:SetColorRGB(r,g,b)
			ColorPickerFrame.previousValues = {r,g,b}
			ColorPickerFrame.func, ColorPickerFrame.opacityFunc, ColorPickerFrame.cancelFunc = SSO_ColorPickCallback, SSO_ColorPickCallback, SSO_ColorPickCallback
			ColorPickerFrame:Hide() -- apparently needed...
			ColorPickerFrame:Show()
		elseif cmd  == "nocombat" then
			if msg == "on" then
				hidenocombat = false
				SimpleShadowOrbsDB.hidenocombat = false
				duetohide = false
				f:UnregisterEvent("PLAYER_REGEN_ENABLED")
				f:UnregisterEvent("PLAYER_REGEN_DISABLED")
				for i = 1,max_resources do
					ssoframes[i]:Show()
				end
			elseif msg == "off" then
				hidenocombat = true
				SimpleShadowOrbsDB.hidenocombat = true
				f:RegisterEvent("PLAYER_REGEN_ENABLED")
				f:RegisterEvent("PLAYER_REGEN_DISABLED")

				if not InCombatLockdown() then
					for i = 1,max_resources do
						ssoframes[i]:Hide()
					end
					is_hidden = true
				end

			else
				print("|cffff0000Invalid command!|r Use |cff3399FF/sso nocombat off|r or |cff3399FF/sso nocombat on|r")
			end

		else
			print("|cff3399FF/sso|r usage:")
			print("|cff3399FF/sso reset|r Resets the addon back to default settings. Use if you can't see the frame and/or dragged it out of the screen.")
			print("|cff3399FF/sso color|r Open the color picker window.")
			print("|cff3399FF/sso scale|r Change the scale of the addon (default: 1, don't use values larger than 3)")
			print("|cff3399FF/sso nocombat|r |cff00cf00on|r | |cffff0000off|r Whether the boxes should be shown outside combat or not.")
			print("|cff33FF99To move the boxes:|r Alt+Left mouse button on the leftmost box to drag it.")
		end

	end

	xpos = SimpleShadowOrbsDB.xpos
	ypos = SimpleShadowOrbsDB.ypos
	r = SimpleShadowOrbsDB.r
	g = SimpleShadowOrbsDB.g
	b = SimpleShadowOrbsDB.b
	scale = SimpleShadowOrbsDB.scale
	leftanchor = SimpleShadowOrbsDB.leftanchor
	hidenocombat = SimpleShadowOrbsDB.hidenocombat


	if hidenocombat and not InCombatLockdown() then
		duetohide = true
	end

	


	f:RegisterEvent("PLAYER_LOGIN")
	f:RegisterEvent("UNIT_POWER")
	f:RegisterEvent("PLAYER_ENTERING_WORLD")
	f:RegisterEvent("PLAYER_TALENT_UPDATE")
	f:RegisterEvent("PLAYER_REGEN_DISABLED")

	if hidenocombat then
		f:RegisterEvent("PLAYER_REGEN_ENABLED")
	end




end

f:RegisterEvent("ADDON_LOADED")

