Loremaster = select(2, ...)
Loremaster.frame = CreateFrame("Frame")