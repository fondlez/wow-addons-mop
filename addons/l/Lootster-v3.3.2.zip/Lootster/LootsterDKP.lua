-- Lootster DKP
--
-- Minimalist DKP Enabling File

Lootster_DateDKP = "DKP Stub";

Lootster_MainDKP =
{
};

Lootster_AltsDKP =
{
};

Lootster_ParkDKP =
{
};

Lootster_ZoneDKP =
{
};

Lootster_MobsDKP =
{
};

Lootster_ItemDKP =
{
};

Lootster_TierDKP =
{
};
