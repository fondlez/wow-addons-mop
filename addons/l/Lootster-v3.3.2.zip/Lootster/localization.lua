-- Default English Localization
LOOTSTER_LANG_COMMON = "Common";
LOOTSTER_LANG_ORCISH = "Orcish";

LOOTSTER_LABEL_LOOTSTER = "Lootster";

BINDING_HEADER_LOOTSTER = "Lootster";
BINDING_NAME_LOOTSTER_TOGGLE = "Show/Hide Window";
BINDING_NAME_LOOTSTER_TOGGLE_DESC = "Toggle Visibility of Lootster Window";

LOOTSTER_LABEL_DATA =  "Player\nPoints";
LOOTSTER_LABEL_LOOT =  "Loot Points";
LOOTSTER_LABEL_RAID =  "Raid";
LOOTSTER_LABEL_ROLLS = "Rolls";
LOOTSTER_LABEL_ITEMS = "Restricted\nLoot";
LOOTSTER_LABEL_RULES = "Rules";
LOOTSTER_LABEL_HIDDEN = "Hidden";
LOOTSTER_LABEL_CLASSES = "Classes";
LOOTSTER_LABEL_OPTIONS = "Options";
LOOTSTER_LABEL_DEBUGGING = "Debugging";
LOOTSTER_LABEL_RAIDREPORT = "Raid Report";

LOOTSTER_BUTTONNORM_TOGGLE = "Toggle Lootster";
LOOTSTER_BUTTONHIGH_TOGGLE = "Toggle Lootster (Roll Detected)";

LOOTSTER_RAID_TOGGLE_OPEN = "Open Raid";
LOOTSTER_RAID_TOGGLE_CLOSE = "Close Raid";
LOOTSTER_BOSS_TOGGLE_START = "Start Boss";
LOOTSTER_BOSS_TOGGLE_FINISH = "Finish Boss";

LOOTSTER_DATE_USENOW = "Use Wallclock";
LOOTSTER_DATE_USENOW_TT = "Use the Wallclock to Fill Date/Time";

LOOTSTER_RF_INDICATOR = " (RF)";
LOOTSTER_HEROIC_INDICATOR = " (H)";

LOOTSTER_RAIDWARN_LIST = { "All Messages", "Initial Message" };
LOOTSTER_RAIDWARN_LIST_TT = { "All Roll Messages Will be Echoed to Raid Warning Channel", "Only the Initial Roll Message Will be Echoed to Raid Warning Channel" };
LOOTSTER_ROLLMODE_LIST = { "DKP Rolling", "Simple Rolling" };
LOOTSTER_DKPTYPE_LIST = { "DKP and Rolls", "Tier and Rolls", "Modified Rolls by DKP", "Modified DKP by Rolls", "EPGP and Rolls" };
LOOTSTER_NORMTYPE_LIST = { "100 and 1000 Rolls", "Need or Greed Rolls", "Free for All Rolls" };
LOOTSTER_TRACKBY_LIST = { "Raid", "Raid and Boss" };
LOOTSTER_TRACKBY_LIST_TT = { "A Single Boss is Used to Book All Attendances and Adjustments", "Separate Boss Attempts are Used to Book Attendances and Adjustments" };
LOOTSTER_RAIDTYPE_LIST = { "Unknown Instance", "Normal Dungeon", "Heroic Dungeon", "Normal 10-Man Raid", "Heroic 10-Man Raid", "RF 25-Man Raid", "Normal 25-Man Raid", "Heroic 25-Man Raid", "Outdoor Raid" };
LOOTSTER_RAIDTYPE_LIST_REP = { "Unknown Instance", "Normal Dungeon", "Heroic Dungeon", "Normal 10-Man Raid", "Heroic 10-Man Raid", "RF 25-Man Raid", "Normal 25-Man Raid", "Heroic 25-Man Raid", "Outdoor Raid" };
LOOTSTER_BOSSTYPE_LIST = { "Raid: Start", "Raid: Finish", "Boss: Attempt", "Boss: Kill", "Boss: Wipe", "Bonus: Award", "Bonus: Time" };
LOOTSTER_BOSSTYPE_LIST_REP = { "Raid Start", "Raid Finish", "Boss Attempt", "Boss Kill", "Boss Wipe", "Bonus Award", "Bonus Time" };
LOOTSTER_MEMBER_LIST = { "Equal", "Full", "Trial", "App" };
LOOTSTER_TOON_LIST = { "Equal", "Main", "Alt" };
LOOTSTER_ATTENDED_LIST = { "Full", "Partial", "Standby", "No" };
LOOTSTER_TOBEASSIGNED_LIST = { "Booked", "Looted" };
LOOTSTER_DKPVALUE_LIST = { "Earnt", "Spent" };
LOOTSTER_DKPVALUE_LIST_TT = { "DKP is Earnt", "DKP is Spent" };
LOOTSTER_USAGEBY_LIST = { "Separate Roll Calls (Available for All DKP Types)", "Single Roll Call (Not Modified Rolls by DKP) Using /roll:" };
LOOTSTER_USAGEBY_LIST_TT = { "Separate Roll Calls are Made for Each Enabled Usage", "Single Roll Call is Made with /roll of Enabled Usage" };
LOOTSTER_USAGEDKP_LIST = { [0]="Manual Entry", "Called", "Main-Spec Need", "Off-Spec Need", "Main-Spec Greed", "Off-Spec Greed", "Alt BoE", "Bank BoE", "Main-Spec Shard", "Off-Spec Shard", "Bank Shard", "Greed" };
LOOTSTER_USAGEDKP_LIST_REP = { [0]="Manual Entry", "Called", "Main Need", "Off Need", "Main Greed", "Off Greed", "Alt BoE", "Bank BoE", "Main Shard", "Off Shard", "Bank Shard", "Greed" };
LOOTSTER_USAGENORM_LIST = { [0]="Manual Entry", "Called", "Main-Spec Need", "Off-Spec Need", "Main-Spec Greed", "Off-Spec Greed", "Alt BoE", "Bank BoE", "Main-Spec Shard", "Off-Spec Shard", "Bank Shard", "Greed" };
LOOTSTER_USAGENORM_LIST_REP = { [0]="Manual Entry", "Called", "Main Need", "Off Need", "Main Greed", "Off Greed", "Alt BoE", "Bank BoE", "Main Shard", "Off Shard", "Bank Shard", "Greed" };
LOOTSTER_EVENT_LIST = { "Raid: Start", "Raid: Finish", "Boss: Kill", "Boss: Wipe", "Bonus: Award", "Bonus: Time" };
LOOTSTER_EVENTNAME_LIST = { " (Outside %d Hours)", " (Outside %d Hours)", nil, nil, nil, " (Every %d Minutes)" };
LOOTSTER_EVENTINFO_LIST = { "Hours:", "Hours:", nil, nil, nil, "Minutes:" };
LOOTSTER_EVENTINFO_LIST_TT = { "Hours Between Raid Start with Same Raid ID", "Hours Between Raid Finish with Same Raid ID", nil, nil, nil, "Minutes Between Time Bonuses" };

LOOTSTER_ROLL_CLEARROLLS = "Clear Rolls";
LOOTSTER_ROLL_CLEARROLLS_TT = "Clear Roll List";
LOOTSTER_ROLL_ITEMS = "Item Count:";
LOOTSTER_ROLL_ITEMS_TT = "Count of Items for Roll";
LOOTSTER_ROLL_ASSIGNLOOT = "Bookkeep Loot";
LOOTSTER_ROLL_ASSIGNLOOT_TT = "Bookkeep Loot to Player.  Note You Will Need a Boss\nSelected on the Raid Tab";
LOOTSTER_ROLL_ACTIVE = "Active calling";
LOOTSTER_ROLL_ACTIVE_TT = "Lootster is Active (Messaging)";
LOOTSTER_ROLL_NEEDROLL = "NEED Roll";
LOOTSTER_ROLL_NEEDROLL_TT = "Call for NEED Rolls";
LOOTSTER_ROLL_GREEDROLL = "GREED Roll";
LOOTSTER_ROLL_GREEDROLL_TT = "Call for GREED Rolls";
LOOTSTER_ROLL_1001000ROLL = "100/1000 Roll";
LOOTSTER_ROLL_1001000ROLL_TT = "Call for 100/1000 Rolls";
LOOTSTER_ROLL_FREEFORALLROLL = "FFA Roll";
LOOTSTER_ROLL_FREEFORALLROLL_TT = "Call for Free-For-All Rolls";
LOOTSTER_ROLL_CALLUSAGE_TT = "Select the Usage Roll";
LOOTSTER_ROLL_CALLROLL = "Call";
LOOTSTER_ROLL_CALLROLL_TT = "Call the Selected Usage Roll";
LOOTSTER_ROLL_CALLRESET = "Reset";
LOOTSTER_ROLL_CALLRESET_TT = "Reset the Selected Usage Roll";
LOOTSTER_ROLL_USAGEROLL = "USAGE";
LOOTSTER_ROLL_USAGEROLL_TT = "Call for All USAGE Rolls";
LOOTSTER_ROLL_TIEDROLL = "TIED Roll";
LOOTSTER_ROLL_TIEDROLL_TT = "Call for TIED Rolls";
LOOTSTER_ROLL_ROLLCOUNT_TT = "Announce Players Yet To Roll/Pass";
LOOTSTER_ROLL_ROLLCOUNT_FMT = "Rolls: %2d of %2d";
LOOTSTER_ROLL_COUNTDOWN = "Countdown";
LOOTSTER_ROLL_COUNTDOWN_TT = "Countdown Roll Expiry";
LOOTSTER_ROLL_ANNOUNCE = "Announce";
LOOTSTER_ROLL_ANNOUNCE_TT = "Announce Winner(s)";
LOOTSTER_ROLL_PASSIVE = "Allow roll/pass";
LOOTSTER_ROLL_PASSIVE_TT = "Allow Passive Rolling/Passing";
LOOTSTER_ROLL_ROLLRNG = "Roll 1-100";
LOOTSTER_ROLL_ROLLRNG_TT = "Roll the Dice";
LOOTSTER_ROLL_ROLL100RNG = "1-100";
LOOTSTER_ROLL_ROLL100RNG_TT = "Roll the Dice for NEED";
LOOTSTER_ROLL_ROLL1000RNG = "1-1000";
LOOTSTER_ROLL_ROLL1000RNG_TT = "Roll the Dice for GREED";
LOOTSTER_ROLL_ROLLRNG_FMT = "Roll 1-%d";
LOOTSTER_ROLL_ROLLUSAGE_TT = "Roll the Selected Usage";
LOOTSTER_ROLL_ROLLUSAGE_SEL = "<select usage>";
LOOTSTER_ROLL_PASS = "Pass Roll";
LOOTSTER_ROLL_PASS_TT = "Pass on Your Roll";
LOOTSTER_ROLL_RECLAIM = "Reclaim Roll";
LOOTSTER_ROLL_RECLAIM_TT = "Reclaim on Your Previous Roll";
LOOTSTER_ROLL_ITEM = "Item:";
LOOTSTER_ROLL_CLEARITEM_TT = "Clear Item Link";
LOOTSTER_ROLL_RESTRICT = "Restrict";
LOOTSTER_ROLL_RESTRICT_TT = "Restrict Class(es) for Rolling";
LOOTSTER_ROLL_POINTSDKP = "DKP:";
LOOTSTER_ROLL_POINTSGP = "GP:";
LOOTSTER_ROLL_DKPOVR = "Override:";
LOOTSTER_ROLL_DKPMAN = "Provisonal:";
LOOTSTER_ROLL_DKPSET = "Set";
LOOTSTER_ROLL_DKPSET_TT = "Set Official Item Points Override";
LOOTSTER_ROLL_DKPREAPP = "Reapply";
LOOTSTER_ROLL_DKPREAPP_TT = "Reapply Official Item Points Override";
LOOTSTER_ROLL_DKPRESET = "Reset";
LOOTSTER_ROLL_DKPRESET_TT = "Reset Official Item Points Override";
LOOTSTER_ROLL_DKPCREATE = "Create";
LOOTSTER_ROLL_DKPCREATE_TT = "Create Provisional Item Points";
LOOTSTER_ROLL_DKPMODIFY = "Modify";
LOOTSTER_ROLL_DKPMODIFY_TT = "Modify Provisional Item Points";
LOOTSTER_ROLL_DKPDELETE = "Delete";
LOOTSTER_ROLL_DKPDELETE_TT = "Delete Provisional Item Points";
LOOTSTER_ROLL_DKPNON = "No Item";
LOOTSTER_ROLL_DKPNEW = "Unknown";
LOOTSTER_ROLL_DKPPROTEM = "Provisiory";
LOOTSTER_ROLL_DKPMULTIPLE = "Multiple";
LOOTSTER_ROLL_CLEARDKPOVR_TT = "Clear Override Points";
LOOTSTER_ROLL_CLEARDKPMAN_TT = "Clear Provisional Points";
LOOTSTER_ROLL_PLAYER = "Player";
LOOTSTER_ROLL_ROLL = "Roll";
LOOTSTER_ROLL_HOLD_TT = "Hold Player's Roll";
LOOTSTER_ROLL_HELD_TT = "Player's Roll is Held";
LOOTSTER_ROLL_ALLOW_TT = "Allow Player's Roll";
LOOTSTER_ROLL_ALLOWED_TT = "Player's Roll is Allowed";
LOOTSTER_ROLL_CLASS = "Class";
LOOTSTER_ROLL_DKP = "DKP";
LOOTSTER_ROLL_PREPGP = "PR=EP/GP";
LOOTSTER_ROLL_USAGE = "Usage";
LOOTSTER_ROLL_USAGEN_G = "Need/Greed";
LOOTSTER_ROLL_RESULTTIER = "Tier";
LOOTSTER_ROLL_RESULTDKPPROLL = "DKP+Roll";
LOOTSTER_ROLL_MEMBER = "Mem";
LOOTSTER_ROLL_TOON = "Toon";
LOOTSTER_ROLL_BAD = "Bad";
LOOTSTER_ROLL_DUP = "Dup";

LOOTSTER_ROLL_HELD_CLR_CODE = RED_FONT_COLOR_CODE;
LOOTSTER_ROLL_ALLOW_CLR_CODE = GREEN_FONT_COLOR_CODE;

LOOTSTER_ROLL_DKPNON_CLR = GRAY_FONT_COLOR;
LOOTSTER_ROLL_DKPNEW_CLR = RED_FONT_COLOR;
LOOTSTER_ROLL_DKPPROTEM_CLR = NORMAL_FONT_COLOR;
LOOTSTER_ROLL_DKPOFFICIAL_CLR = GREEN_FONT_COLOR;
LOOTSTER_ROLL_DKPMULTIPLE_CLR = HIGHLIGHT_FONT_COLOR;

LOOTSTER_HOLDROLL_TITLE = "Hold Roll";
LOOTSTER_ROLLCALL_TITLE = "Roll Call";

LOOTSTER_CLASS_ALLOW = "Class";
LOOTSTER_CLASS_ALLOW_TT = "Permit This Class to Roll";
LOOTSTER_CLASS_DISPLAY = "Echo Classes";
LOOTSTER_CLASS_DISPLAY_TT = "Echo These Class Restrictions\nto Party/Raid/Raid Warning";
LOOTSTER_CLASS_REMEMBER = "Save Classes";
LOOTSTER_CLASS_REMEMBER_TT = "Save These Class Restrictions\nfor This Loot";
LOOTSTER_CLASS_FORGET = "Clear Classes";
LOOTSTER_CLASS_FORGET_TT = "Clear These Class Restrictions\nfor This Loot";

LOOTSTER_DATA_WHISPERALL = "Whisper Points";
LOOTSTER_DATA_WHISPERALL_TT = "Whisper Points to All Players";

LOOTSTER_DATA_DKPPLAYER = "DKP: Player";
LOOTSTER_DATA_DATEATT = "Att Date";
LOOTSTER_DATA_DATEADJ = "Adj Date";

LOOTSTER_DATA_PLAYER = "Player";
LOOTSTER_DATA_CLASS = "Class";
LOOTSTER_DATA_DKP = "DKP";
LOOTSTER_DATA_DKP_TT = "Whisper DKP to Player";
LOOTSTER_DATA_PREPGP = "PR=EP/GP";
LOOTSTER_DATA_PREPGP_TT = "Whisper PR to Player";
LOOTSTER_DATA_DKPEARNT = "Tot Earnt";
LOOTSTER_DATA_EPTOT = "Tot EP";
LOOTSTER_DATA_DKPSPENT = "Tot Spent";
LOOTSTER_DATA_GPTOT = "Tot GP";
LOOTSTER_DATA_TIER = "Tier";
LOOTSTER_DATA_MEMBER = "Mem";
LOOTSTER_DATA_TOON = "Toon";
LOOTSTER_DATA_ATTENDED = "Att";
LOOTSTER_DATA_DKPATTEARNT = "Att Earnt";
LOOTSTER_DATA_EPATT = "Att EP";
LOOTSTER_DATA_DKPADJEARNT = "Adj Earnt";
LOOTSTER_DATA_EPADJ = "Adj EP";
LOOTSTER_DATA_DKPADJSPENT = "Adj Spent";
LOOTSTER_DATA_GPADJ = "Adj GP";
LOOTSTER_DATA_BOSS = "Boss/Event";
LOOTSTER_DATA_USAGE = "Usage";
LOOTSTER_DATA_REASON = "Link/Reason";

LOOTSTER_LOOT_SYNC = "Loot Synchronise";
LOOTSTER_LOOT_SYNC_TT = "Sychronise Your Loot Point Data with Another Lootster";
LOOTSTER_LOOT_CLEARALL = "Clear All Overrides";
LOOTSTER_LOOT_CLEARALL_TT = "Clear ALL Overrides of Offical Loot Points";
LOOTSTER_LOOT_DELETEALL = "Delete All Provisory";
LOOTSTER_LOOT_DELETEALL_TT = "Delete ALL Provisory Loot Points";
LOOTSTER_LOOT_LOOT = "Item:";
LOOTSTER_LOOT_CLEARITEM_TT = "Clear Item Link";
LOOTSTER_LOOT_RESTRICT = "Restrict";
LOOTSTER_LOOT_RESTRICT_TT = "Restrict Class(es) for Rolling";
LOOTSTER_LOOT_TEXT = "Loot Name";
LOOTSTER_LOOT_DKP = "Official Points";
LOOTSTER_LOOT_DKPMAN = "Manual Points";
LOOTSTER_LOOT_CLEAR = "Clear";
LOOTSTER_LOOT_CLEAR_TT = "Clear Override Loot Points";
LOOTSTER_LOOT_DELETE = "Delete";
LOOTSTER_LOOT_DELETE_TT = "Delete Provisional Loot Points Entry";

LOOTSTER_RAID_SYNC = "Raid Sychronise";
LOOTSTER_RAID_SYNC_TT = "Sychronise Your Raid/Boss/Attendance/Adjustsment\nData with Another Lootster";
LOOTSTER_RAID_REPORTFULL = "Full Report";
LOOTSTER_RAID_REPORTFULL_TT = "Report on All Raids/Bosses/Attendance/Adjustsments";
LOOTSTER_RAID_REPORTRAID = "Raid Report";
LOOTSTER_RAID_REPORTRAID_TT = "Report on Selected Raid/Bosses/Attendance/Adjustsments";
LOOTSTER_RAID_REPORTBOSS = "Boss Report";
LOOTSTER_RAID_REPORTBOSS_TT = "Report on Selected Boss/Attendance/Adjustsments";

LOOTSTER_RAID_RAIDLABEL = "Raid";
LOOTSTER_RAID_BOSSLABEL = "Boss";
LOOTSTER_RAID_ATTENDLABEL = "Attend";
LOOTSTER_RAID_ADJUSTLABEL = "Adjust";
LOOTSTER_RAID_ASSIGNLABEL = "Assigned Adjustment";

LOOTSTER_RAID_INSERT = "Create";
LOOTSTER_RAID_INSERT_TT = "Create a New %s Entry";
LOOTSTER_RAID_MODIFY = "Modify";
LOOTSTER_RAID_MODIFY_TT = "Modify This %s Entry";
LOOTSTER_RAID_DELETE = "Delete";
LOOTSTER_RAID_DELETE_TT = "Delete This %s Entry";
LOOTSTER_RAID_DELETEALL = "Clear";
LOOTSTER_RAID_DELETEALL_TT = "Clear ALL %s Entries";
LOOTSTER_RAID_USEROSTER = "Roster";
LOOTSTER_RAID_USEROSTER_TT = "Apply Current Roster to Attendance";
LOOTSTER_RAID_ASSIGN = "Match";
LOOTSTER_RAID_ASSIGN_TT = "Mark Adjustment as Matched";
LOOTSTER_RAID_ASSIGNALL = "Match All";
LOOTSTER_RAID_ASSIGNALL_TT = "Mark ALL Adjustments as Matched";

LOOTSTER_RAID_RAIDZONE = "Raids: Zone";
LOOTSTER_RAID_BOSSBOSS = "Bosses: Boss/Event";
LOOTSTER_RAID_ATTPLAYER = "Attends: Player";
LOOTSTER_RAID_ADJPLAYER = "Adjusts: Player";
LOOTSTER_RAID_ASSPLAYER = "Assigns: Player";

LOOTSTER_RAID_ZONE = "Zone";
LOOTSTER_RAID_DATEOPN = "Opened";
LOOTSTER_RAID_BOSSES = "Boss";
LOOTSTER_RAID_RUN = "Run";
LOOTSTER_RAID_RUN_TT = "Toggle Running State of this Boss";
LOOTSTER_RAID_PLAYERS = "Att";
LOOTSTER_RAID_PLAYERS_TT = "Show Attendees in Raid/Boss";
LOOTSTER_RAID_ADJUSTS = "Adj";
LOOTSTER_RAID_ADJUSTS_TT = "Show Adjustments in Raid/Boss";
LOOTSTER_RAID_ASSIGNS = "Ass";
LOOTSTER_RAID_ASSIGNS_TT = "Show Assignments in Raid/Boss";
LOOTSTER_RAID_DKPEARNT = "Earnt";
LOOTSTER_RAID_DKPSPENT = "Spent";
LOOTSTER_RAID_EP = "EP";
LOOTSTER_RAID_GP = "GP";
LOOTSTER_RAID_BOSS = "Boss";
LOOTSTER_RAID_DATEBEG = "Started";
LOOTSTER_RAID_PLAYER = "Player";
LOOTSTER_RAID_DKPATTEARNT = "Att Earnt";
LOOTSTER_RAID_DKPADJEARNT = "Adj Earnt";
LOOTSTER_RAID_DKPADJSPENT = "Adj Spent";
LOOTSTER_RAID_ATTEP = "Att EP";
LOOTSTER_RAID_ADJEP = "Adj EP";
LOOTSTER_RAID_ADJGP = "Adj GP";
LOOTSTER_RAID_TOON = "Toon";
LOOTSTER_RAID_ATTENDED = "Att";
LOOTSTER_RAID_USAGE = "Usage";
LOOTSTER_RAID_REASON = "Link/Reason";

LOOTSTER_RAID_NORMAL_CLR = NORMAL_FONT_COLOR;
LOOTSTER_RAID_RUNNING_CLR = GREEN_FONT_COLOR;

LOOTSTER_RAID_ASSIGNS_CLR_CODE = RED_FONT_COLOR_CODE;
LOOTSTER_RAID_NOASSIGNS_CLR_CODE = GREEN_FONT_COLOR_CODE;

LOOTSTER_ITEM_SYNC = "Item Synchronise";
LOOTSTER_ITEM_SYNC_TT = "Sychronise Your Item Restriction Data with Another Lootster";
LOOTSTER_ITEM_DELETEALL = "Delete All";
LOOTSTER_ITEM_DELETEALL_TT = "Delete ALL Items";
LOOTSTER_ITEM_ITEM = "Item:";
LOOTSTER_ITEM_CLEARITEM_TT = "Clear Item Link";
LOOTSTER_ITEM_RESTRICT = "Restrict";
LOOTSTER_ITEM_RESTRICT_TT = "Restrict Class(es) for Rolling";

LOOTSTER_ITEM_TEXT = "Item Name";
LOOTSTER_ITEM_DELETE = "Delete";
LOOTSTER_ITEM_DELETE_TT = "Delete Item Entry";

LOOTSTER_RULE_HELP = "Lootster Help";
LOOTSTER_RULE_RULE = "Looting Rules: %s Loot Rules";
LOOTSTER_RULE_USAGE = "Usage Rolls";
LOOTSTER_RULE_SHOWHELP = "Show Help";
LOOTSTER_RULE_SHOWHELP_TT = "Show Lootster Help to Party/Raid";
LOOTSTER_RULE_SHOWRULES = "Show Rules";
LOOTSTER_RULE_SHOWRULES_TT = "Show Looting Rules to Party/Raid";
LOOTSTER_RULE_SHOWUSAGE = "Show Usage Rolls";
LOOTSTER_RULE_SHOWUSAGE_TT = "Show Usage Rolls to Party/Raid";

LOOTSTER_OPTION_TAB1 = "Interface & General";
LOOTSTER_OPTION_UIMANAGE = "Interface Management:";
LOOTSTER_OPTION_MINIMAP = "Minimap button:";
LOOTSTER_OPTION_MINIMAP_TT = "Toggle Minimap Button";
LOOTSTER_OPTION_RESETUI = "Reset UI";
LOOTSTER_OPTION_RESETUI_TT = "Reset UI Window Locations";
LOOTSTER_OPTION_RESETUI_EXP = "Reset all Lootster UI windows to center of screen";
LOOTSTER_OPTION_VERSION = "Version:";
LOOTSTER_OPTION_DKPDATE = "DKP Date:";
LOOTSTER_OPTION_DKPSITE = "DKP Guild:";
LOOTSTER_OPTION_DEBUGGING = "Debugging";
LOOTSTER_OPTION_DEBUGGING_TT = "Show Debugging Window for Message Logging";
LOOTSTER_OPTION_GENERALMANAGE = "General Management:";
LOOTSTER_OPTION_ROLLMANAGE = "Roll Management:";
LOOTSTER_OPTION_SUPPRESS = "Suppress rolls in chatlog";
LOOTSTER_OPTION_SUPPRESS_TT = "Toggle Suppression of Rolls in Chatlog";
LOOTSTER_OPTION_RWROLL = "Echo roll messages to Raid Warning:";
LOOTSTER_OPTION_RWROLL_TT = "Toggle Echo of Roll Messages to Raid Warning Channel";
LOOTSTER_OPTION_ACKROLL = "Whisper roll acknowledge to player";
LOOTSTER_OPTION_ACKROLL_TT = "Toggle Whisper of Roll Acknowledge to Player";
LOOTSTER_OPTION_ACKNOINFO = "Whisper DKP to player on roll call";
LOOTSTER_OPTION_ACKNOINFO_TT = "Toggle Whisper DKP Information to Player on Roll Call";
LOOTSTER_OPTION_ACKNOCALL = "Whisper out of call roll to player";
LOOTSTER_OPTION_ACKNOCALL_TT = "Toggle Whisper Out of Call Roll to Player";
LOOTSTER_OPTION_ACKNOROLL = "Whisper /roll on laggard announce to player";
LOOTSTER_OPTION_ACKNOROLL_TT = "Toggle Whisper of Roll Command When\nAnnouncing Laggards to Player";
LOOTSTER_OPTION_ACKNOHELP = "Whisper help on bad whisper from player";
LOOTSTER_OPTION_ACKNOHELP_TT = "Toggle Whisper of Help To Player On Receiving\nBad Whisper Command From Player";
LOOTSTER_OPTION_ACKNORAID = "Announce Raid tracking changes";
LOOTSTER_OPTION_ACKNORAID_TT = "Toggle Broadcast of Raid Tracking Changes to Party/Raid";
LOOTSTER_OPTION_ACKNOBOSS = "Announce Boss tracking changes";
LOOTSTER_OPTION_ACKNOBOSS_TT = "Toggle Broadcast of Boss Tracking Changes to Party/Raid";
LOOTSTER_OPTION_ACKNOATT = "Announce Attendance tracking changes";
LOOTSTER_OPTION_ACKNOATT_TT = "Toggle Broadcast/Whisper of Attendance Tracking Changes to Party/Raid/Player";
LOOTSTER_OPTION_ACKNOADJ = "Announce Adjustment tracking changes";
LOOTSTER_OPTION_ACKNOADJ_TT = "Toggle Broadcast/Whisper of Adjustment Tracking Changes to Party/Raid/Player";
LOOTSTER_OPTION_COUNTER = "Utilise roll countdown:";
LOOTSTER_OPTION_COUNTER_TT = "Toggle Countdown for Rolling";
LOOTSTER_OPTION_COUNTERSECONDS = "seconds";
LOOTSTER_OPTION_COUNTERSECONDS_TT = "Countdown Period in Seconds";
LOOTSTER_OPTION_AUTOSNOOP = "Snoop roll modes and calls";
LOOTSTER_OPTION_AUTOSNOOP_TT = "Toggle Snoop Roll Mode Changes\nand Calls for Rolls";
LOOTSTER_OPTION_ECHORESTRICT = "Echo item's class restrictions to channel:";
LOOTSTER_OPTION_ECHORESTRICT_TT = "Toggle Ability to Echo Loot Item's\nClass Restrictions To Channel";
LOOTSTER_OPTION_ECHOTOCHAT = "To Party/Raid chat";
LOOTSTER_OPTION_ECHOTOCHAT_TT = "Toggle Echo of Restrictions to\nParty/Raid Chat";
LOOTSTER_OPTION_ECHOTORW = "To Raid Warning";
LOOTSTER_OPTION_ECHOTORW_TT = "Toggle Echo of Restrictions to\nRaid Warning Channel";
LOOTSTER_OPTION_ECHOBYCLICK = "By item link Ctrl-Shift-Right-Click";
LOOTSTER_OPTION_ECHOBYCLICK_TT = "Toggle Ability to Echo Class Restrictions\nBy Item Link Ctrl-Shift-Right-Click";
LOOTSTER_OPTION_ECHOBYGROUPLOOT = "By echo button next to Group Loot UI";
LOOTSTER_OPTION_ECHOBYGROUPLOOT_TT = "Toggle Ability to Echo Class Restrictions\nBy Showing Echo Button Next to Group Loot User Interface";
LOOTSTER_OPTION_DEBUGMSGS = "Show debug messages";
LOOTSTER_OPTION_DEBUGMSGS_TT = "Toggle Showing of Debug Messages\nWhen Not Active";
LOOTSTER_OPTION_TAB2 = "Roll & Raid";
LOOTSTER_OPTION_ROLLMANAGE = "Roll Management:";
LOOTSTER_OPTION_ROLLMODE = "Roll using:";
LOOTSTER_OPTION_ROLLMODE_TT = "Select Roll Method";
LOOTSTER_OPTION_ROLLTYPE = "By:";
LOOTSTER_OPTION_DKPTYPE_TT = "Select DKP Loot Distribution Mode";
LOOTSTER_OPTION_NORMTYPE_TT = "Select Simple Roll Loot Distribution Mode";
LOOTSTER_OPTION_ROLLTYPE_TT = "Select Loot Distribution Mode";
LOOTSTER_OPTION_DKPMEMBER = "Use Full/Trial/App membership priority";
LOOTSTER_OPTION_DKPMEMBER_TT = "Toggle Full/Trial/App Membership Priority for Roll Sorting";
LOOTSTER_OPTION_DKPTOON = "Use Main/Alt toon priority";
LOOTSTER_OPTION_DKPTOON_TT = "Toggle Main/Alt Toon Priority for Roll Sorting";
LOOTSTER_OPTION_DKPGREEDFFA = "Use only the roll on greed rolls";
LOOTSTER_OPTION_DKPGREEDFFA_TT = "Toggle Use of Only the Roll for Comparing Greed Rolls,\nIgnoring DKP/Tier/Membership/Toon";
LOOTSTER_OPTION_DKPATTEARNT = "Use attend earnt DKP in player's total DKP";
LOOTSTER_OPTION_DKPATTEARNT_TT = "Toggle Use of Attendance Earnt DKP in Player's Total DKP";
LOOTSTER_OPTION_DKPCAPS = "Use DKP caps:";
LOOTSTER_OPTION_DKPCAPS_TT = "Toggle Hi/Lo DKP Caps";
LOOTSTER_OPTION_DKPHI = "Hi:+";
LOOTSTER_OPTION_DKPHI_TT = "Hi DKP Cap Limit";
LOOTSTER_OPTION_DKPLO = "Lo:-";
LOOTSTER_OPTION_DKPLO_TT = "Lo DKP Cap Limit";
LOOTSTER_OPTION_DKPFACTORING = "Use DKP factoring:";
LOOTSTER_OPTION_DKPFACTORING_TT = "Toggle DKP Factoring (Divisor) for DKP Modified Rolling";
LOOTSTER_OPTION_ROLLFACTORING = "Use Roll factoring:";
LOOTSTER_OPTION_ROLLFACTORING_TT = "Toggle Roll Factoring (Multiplier) for Roll Modified Rolling";
LOOTSTER_OPTION_EPMIN = "Use minimum EP:";
LOOTSTER_OPTION_EPMIN_TT = "Toggle a Mimimum Level for Effort Points";
LOOTSTER_OPTION_GPBASE = "Use base GP:";
LOOTSTER_OPTION_GPBASE_TT = "Toggle a Base Level for Gear Points";
LOOTSTER_OPTION_NORMMEMBER = "Use Full/Trial/App membership priority";
LOOTSTER_OPTION_NORMMEMBER_TT = "Toggle Full/Trial/App Membership\nPriority for Roll Sorting";
LOOTSTER_OPTION_NORMTOON = "Use Main/Alt toon priority";
LOOTSTER_OPTION_NORMTOON_TT = "Toggle Main/Alt Toon\nPriority for Roll Sorting";
LOOTSTER_OPTION_NORMGREEDFFA = "Use only the roll on greed rolls";
LOOTSTER_OPTION_NORMGREEDFFA_TT = "Toggle Use of Only the Roll for Comparing Greed Rolls,\nIgnoring Membership/Toon";
LOOTSTER_OPTION_NORMAUTOROLL = "Accept rolls without roll call";
LOOTSTER_OPTION_NORMAUTOROLL_TT = "Toggle Ability for Players to Roll\nWithout a Call for Rolls";
LOOTSTER_OPTION_NORMAUTOOPEN = "Open Lootster on accepting initial roll";
LOOTSTER_OPTION_NORMAUTOOPEN_TT = "Toggle Lootster Opening on\nAccepting Initial Roll";
LOOTSTER_OPTION_NORMAUTOCLOSE = "Clear rolls on closing Lootster";
LOOTSTER_OPTION_NORMAUTOCLOSE_TT = "Toggle Lootster Closure Clearing Rolls";
LOOTSTER_OPTION_RAIDMANAGE = "Raid & Attendance Management:";
LOOTSTER_OPTION_TRACK = "Track:";
LOOTSTER_OPTION_TRACKBY = "Track by:";
LOOTSTER_OPTION_AUTORAID = "Automatically track raids/bosses";
LOOTSTER_OPTION_AUTORAID_TT = "Toggle Automatic Open/Close of Raids and Start/Stop of Bosses\nOn Detecting Raid Zone and Boss Mob Change";
LOOTSTER_OPTION_AUTOBOSS = "Automatically track boss attempts";
LOOTSTER_OPTION_AUTOBOSS_TT = "Toggle Automatic Start/Stop of Bosses\nOn Detecting Boss Wipes/Attempts";
LOOTSTER_OPTION_RAIDICON = "Display raid open/close UI icon";
LOOTSTER_OPTION_RAIDICON_TT = "Toggle Display of the Raid Open/Close User Interface Icon\nNext to Lootster User Interface Button";
LOOTSTER_OPTION_BOSSICON = "Display boss start/stop UI icon";
LOOTSTER_OPTION_BOSSICON_TT = "Toggle Display of the Boss Start/Stop User Interface Icon\nNext to Lootster User Interface Button";
LOOTSTER_OPTION_ATTENDHERE = "Allow 'here' whispers by Standby players";
LOOTSTER_OPTION_ATTENDHERE_TT = "Toggle Acceptance of 'here' Whispers by Standby Players\nfor Attendance When Not in Party/Raid";
LOOTSTER_OPTION_ATTENDANNOUNCE = "Announce new raid/bosses:";
LOOTSTER_OPTION_ATTENDANNOUNCE_TT = "Toggle Announcement of New Raid/Bosses";
LOOTSTER_OPTION_ATTENDGROUP = "To Party/Raid";
LOOTSTER_OPTION_ATTENDGROUP_TT = "Toggle Announcement to the Party/Raid Channel";
LOOTSTER_OPTION_ATTENDGUILD = "To Guild";
LOOTSTER_OPTION_ATTENDGUILD_TT = "Toggle Announcement to the Guild Channel";
LOOTSTER_OPTION_ATTENDCUSTOM = "To Custom:";
LOOTSTER_OPTION_ATTENDCUSTOM_TT = "Toggle Announcement to a Custom Channel";
LOOTSTER_OPTION_TAB3 = "Loot, Member & Toon";
LOOTSTER_OPTION_LOOTMANAGE = "Loot Management:";
LOOTSTER_OPTION_LOOTMODE = "Loot quality:";
LOOTSTER_OPTION_LOOTMODE_TT = "Select Loot Quality To Be Tracked";
LOOTSTER_OPTION_AUTODKPLOOT = "Automatically bookkeep DKP loot wins";
LOOTSTER_OPTION_AUTODKPLOOT_TT = "Toggle Automatic Bookkeeping of DKP Loot Wins";
LOOTSTER_OPTION_AUTONONDKPLOOT = "Automatically bookkeep non-DKP loot wins";
LOOTSTER_OPTION_AUTONONDKPLOOT_TT = "Toggle Automatic Bookkeeping of non-DKP Loot Wins";
LOOTSTER_OPTION_AUTOLOOTRAID = "Automatically create raid/boss for loot";
LOOTSTER_OPTION_AUTOLOOTRAID_TT = "Toggle Automatic Open of Raids and/or Start of Boss\nfor Bookkeeping Loot (If None Running)";
LOOTSTER_OPTION_PRIORMANAGE = "Membership & Toon Management:";
LOOTSTER_OPTION_RANKMEMBERS = "Use Guild Ranks for membership priority";
LOOTSTER_OPTION_RANKMEMBERS_TT = "Toggle Guild Ranks for Membership Full/Trial/App Priority";
LOOTSTER_OPTION_NOTETOONS = "Use guild's Public Note for toon priority"
LOOTSTER_OPTION_NOTETOONS_TT = "Toggle Guild's Public Note Use for Toon Main/Alt Priority"
LOOTSTER_OPTION_RANKTOONS = "Cross check with alt toon Guild Ranks";
LOOTSTER_OPTION_RANKTOONS_TT = "Toggle Cross Check With Alt Toon Guild Ranks";
LOOTSTER_OPTION_ALTSMAIN = "Format of Alt's Main Name in Public Note:"
LOOTSTER_OPTION_ALTSMAINPREFIX = "Prefixed by:";
LOOTSTER_OPTION_ALTSMAINPREFIX_TT = "Text Before the Alt's Main Name - May be Empty";
LOOTSTER_OPTION_ALTSMAINSUFFIX = "Suffixed by:";
LOOTSTER_OPTION_ALTSMAINSUFFIX_TT = "Text After the Alt's Main Name - May be Empty";
LOOTSTER_OPTION_RESCANGUILD = "Rescan Info";
LOOTSTER_OPTION_RESCANGUILD_TT = "Rescan Guild Information and Update";
LOOTSTER_OPTION_RANKFULL = "Full";
LOOTSTER_OPTION_RANKFULL_TT = "Make this Rank have Full Membership";
LOOTSTER_OPTION_RANKTRIAL = "Trial";
LOOTSTER_OPTION_RANKTRIAL_TT = "Make this Rank have Trial Membership";
LOOTSTER_OPTION_RANKAPP = "App";
LOOTSTER_OPTION_RANKAPP_TT = "Make this Rank have Applicant Membership";
LOOTSTER_OPTION_RANKALT = "Alt";
LOOTSTER_OPTION_RANKALT_TT = "Make this Rank be Alt Toon";
LOOTSTER_OPTION_RANK_TEXT = "Rank Name";
LOOTSTER_OPTION_RANK_FULL = "Full";
LOOTSTER_OPTION_RANK_TRIAL = "Trial";
LOOTSTER_OPTION_RANK_APP = "App";
LOOTSTER_OPTION_RANK_ALT = "Alt";
LOOTSTER_OPTION_RANK_NONMAIN = "<No Main for Alt>";
LOOTSTER_OPTION_RANK_NONGUILD = "<Non-Guild Member>";
LOOTSTER_OPTION_TAB4 = "Usage Rolls";
LOOTSTER_OPTION_USAGEMANAGE = "Usage Management:";
LOOTSTER_OPTION_USAGEROLLS = "Use usage rolls in DKP mode:";
LOOTSTER_OPTION_USAGEROLLS_TT = "Toggle Use of Usage Rolls for DKP Rolling";
LOOTSTER_OPTION_BANKER = "Banker Name:";
LOOTSTER_OPTION_OTHERBANKER = "Other Banker...";
LOOTSTER_OPTION_USAGE = "Usage";
LOOTSTER_OPTION_USEUSAGE = "Use";
LOOTSTER_OPTION_USEUSAGE_TT = "Toggle Use of this Usage Roll";
LOOTSTER_OPTION_ROLLCMD = "/roll";
LOOTSTER_OPTION_ROLLCMD_TT = "%d";
LOOTSTER_OPTION_ALTFACTOR = "Alt Factor";
LOOTSTER_OPTION_ALTFACTOR_TT = "Set Usage's Alt Cost Factor";
LOOTSTER_OPTION_USAGEVALUE = "By Val";
LOOTSTER_OPTION_USAGEVALUE_TT = "Make this Usage Roll an Outright Cost Value";
LOOTSTER_OPTION_COSTVALUE = "Cost Value";
LOOTSTER_OPTION_COSTVALUE_TT = "Set Usage's Outright Cost Value";
LOOTSTER_OPTION_USAGEFACTOR = "By Fctr";
LOOTSTER_OPTION_USAGEFACTOR_TT = "Make this Usage Roll a Cost Factor";
LOOTSTER_OPTION_COSTFACTOR = "Cost Factor";
LOOTSTER_OPTION_COSTFACTOR_TT = "Set Usage's Cost Factor";
LOOTSTER_OPTION_USAGEWINS = "Wins";
LOOTSTER_OPTION_USAGEWINS_TT = "Toggle Use of Maximum Wins Per Raid for this Usage";
LOOTSTER_OPTION_WINSPERRAID = "Win#";
LOOTSTER_OPTION_WINSPERRAID_TT = "Set Usage's Maximum Wins Per Raid";
LOOTSTER_OPTION_WINSPERRAIDINF = "\226\136\158";
LOOTSTER_OPTION_USAGEMOVEUP_TT = "Move Selected Usage Up One Position in Priority";
LOOTSTER_OPTION_USAGEMOVEDOWN_TT = "Move Selected Usage Down One Position in Priority";
LOOTSTER_OPTION_NOUSAGE = "<no usage selected>";
LOOTSTER_OPTION_USAGESET = "Set";
LOOTSTER_OPTION_USAGESET_TT = "Set the Selected Usage's Points Value/Factor";
LOOTSTER_OPTION_USAGERESET = "Reset";
LOOTSTER_OPTION_USAGERESET_TT = "Reset the Selected Usage's Points Value/Factor";
LOOTSTER_OPTION_USAGERESETALL = "Reset All";
LOOTSTER_OPTION_USAGERESETALL_TT = "Reset All Selected Usage's Points Value/Factor";
LOOTSTER_OPTION_TAB5 = "Events";
LOOTSTER_OPTION_EVENTSMANAGE = "Event Management:";
LOOTSTER_OPTION_EVENT = "Event";
LOOTSTER_OPTION_USE10 = "10m";
LOOTSTER_OPTION_USE10_TT = "Toggle Use of the Event for 10 Man Raids";
LOOTSTER_OPTION_DKP10 = "Full Pts";
LOOTSTER_OPTION_DKP10_TT = "Set Event's 10 Man Full Points Value";
LOOTSTER_OPTION_PARTIAL10 = "P%";
LOOTSTER_OPTION_PARTIAL10_TT = "Set Event's 10 Man Partial Attendance Percentage of Full Points";
LOOTSTER_OPTION_STANDBY10 = "S%";
LOOTSTER_OPTION_STANDBY10_TT = "Set Event's 10 Man Standby Attendance Percentage of Full Points";
LOOTSTER_OPTION_USE25 = "25m";
LOOTSTER_OPTION_USE25_TT = "Toggle Use of the Event for 25 Man Raids";
LOOTSTER_OPTION_DKP25 = "Full Pts";
LOOTSTER_OPTION_DKP25_TT = "Set Event's 25 Man Full Points Value";
LOOTSTER_OPTION_PARTIAL25 = "P%";
LOOTSTER_OPTION_PARTIAL25_TT = "Set Event's 25 Man Partial Attendance Percentage of Full Points";
LOOTSTER_OPTION_STANDBY25 = "S%";
LOOTSTER_OPTION_STANDBY25_TT = "Set Event's 25 Man Standby Attendance Percentage of Full Points";
LOOTSTER_OPTION_NOEVENT = "<no event selected>";
LOOTSTER_OPTION_EVENTSET = "Set";
LOOTSTER_OPTION_EVENTSET_TT = "Set the Selected Event's 10 and 25 Man Points,\nand Partial and Standby Points Percentage";
LOOTSTER_OPTION_EVENTRESET = "Reset";
LOOTSTER_OPTION_EVENTRESET_TT = "Reset the Selected Event's 10 and 25 Man Points,\nand Partial and Standby Points Percentage";
LOOTSTER_OPTION_EVENTRESETALL = "Reset All";
LOOTSTER_OPTION_EVENTRESETALL_TT = "Reset All Event 10 and 25 Man Points,\nand Partial and Standby Points Percentage";
LOOTSTER_OPTION_TAB6 = "Item Points";
LOOTSTER_OPTION_POINTSMANAGE = "Item Points Management:";
LOOTSTER_OPTION_CALCPOINTS = "Use calculated item points - |cffffff7fhttp://wow.allakhazam.com/wiki/Itemization_Formulas_(WoW)|r";
LOOTSTER_OPTION_CALCPOINTS_TT = "Toggle Use of Calculated Item Points";
LOOTSTER_OPTION_FORMULA = "Points = (iLevel * qFactor - qBias) * sFactor * pFactor";
LOOTSTER_OPTION_WHERE = "Where:";
LOOTSTER_OPTION_WHERE_ILEVEL = "iLevel is the item level";
LOOTSTER_OPTION_WHERE_QFACTOR = "qFactor is the item quality factor";
LOOTSTER_OPTION_WHERE_QBIAS = "qBias is the item quality bias";
LOOTSTER_OPTION_WHERE_SFACTOR = "sFactor is the item slot type factor";
LOOTSTER_OPTION_WHERE_PFACTOR = "pFactor is a item points factor: ";
LOOTSTER_OPTION_QUALITY = "Quality";
LOOTSTER_OPTION_USEQUALITY = "Use";
LOOTSTER_OPTION_USEQUALITY_TT = "Toggle Use of Points for this Item Quality";
LOOTSTER_OPTION_QFACTOR = "qFactor";
LOOTSTER_OPTION_QFACTOR_TT = "Set Selected Quality's qFactor";
LOOTSTER_OPTION_QBIAS = "qBias";
LOOTSTER_OPTION_QBIAS_TT = "Set Selected Quality's qBias";
LOOTSTER_OPTION_NOQNAME = "<no quality selected>";
LOOTSTER_OPTION_QUALITYSET = "Set";
LOOTSTER_OPTION_QUALITYSET_TT = "Set the Selected Item Quality's Factor & Bias";
LOOTSTER_OPTION_QUALITYRESET = "Reset";
LOOTSTER_OPTION_QUALITYRESET_TT = "Reset the Selected Item Quality's Factor & Bias";
LOOTSTER_OPTION_QUALITYRESETALL = "Reset All";
LOOTSTER_OPTION_QUALITYRESETALL_TT = "Reset All Item Quality Factor & Bias";
LOOTSTER_OPTION_SLOTTYPE = "Slot Type";
LOOTSTER_OPTION_SFACTOR = "sFactor";
LOOTSTER_OPTION_SFACTOR_TT = "Set Selected Slot's sFactor";
LOOTSTER_OPTION_SFACTOR1 = "Head, Chest, Legs, 2H";
LOOTSTER_OPTION_SFACTOR2 = "Shoulder, Hands, Feet, Waist";
LOOTSTER_OPTION_SFACTOR3 = "Trinket";
LOOTSTER_OPTION_SFACTOR4 = "Wrist, Neck, Finger, Back, OH";
LOOTSTER_OPTION_SFACTOR5 = "1H";
LOOTSTER_OPTION_SFACTOR6 = "Ranged, Relic";
LOOTSTER_OPTION_SFACTOR7 = "Ammo, Quiver/Pouch, Bags, Unknown";
LOOTSTER_OPTION_NOSNAME = "<no quality selected>";
LOOTSTER_OPTION_SLOTSET = "Set";
LOOTSTER_OPTION_SLOTSET_TT = "Set the Selected Item Slots's Factor";
LOOTSTER_OPTION_SLOTRESET = "Reset";
LOOTSTER_OPTION_SLOTRESET_TT = "Reset the Selected Item Slots's Factor";
LOOTSTER_OPTION_SLOTRESETALL = "Reset All";
LOOTSTER_OPTION_SLOTRESETALL_TT = "Reset All Item Slot Factor";
LOOTSTER_OPTION_POINTS = "Calculated Item Points and Formula:";
LOOTSTER_OPTION_EQUATION = "%0.3f = (%d * %0.3f - %0.3f) * %0.3f * %0.3f";
LOOTSTER_OPTION_ITEM = "Item:";
LOOTSTER_OPTION_CLEARITEM_TT = "Clear Item Link";

LOOTSTER_LOOTSYNC_TITLE = "Loot Synchronise";
LOOTSTER_LOOTSYNC_CLOSE = "Close";
LOOTSTER_LOOTSYNC_CLOSE_TT = "Close Synchronisation";
LOOTSTER_LOOTSYNC_CANCEL = "Cancel";
LOOTSTER_LOOTSYNC_CANCEL_TT = "Cancel Synchronisation";
LOOTSTER_LOOTSYNC_APPLY = "Synchronise";
LOOTSTER_LOOTSYNC_APPLY_TT = "Commence Synchronisation";
LOOTSTER_LOOTSYNC_HELPINTR = "Loot Synchronise allows you to transfer loot DKP listings from an online player's Lootster (version 3.0.0 and above) to your Lootster.";
LOOTSTER_LOOTSYNC_HELPINFO = "You may also choose to update a loot's DKP if it is also defined by the other player (that is, you have that loot in COMMON).  Note that your official DKP loot will only have override DKP synchronised."
LOOTSTER_LOOTSYNC_HELPCONF = "To continue, select the name of the player running Lootster with whom you wish to synchronise loot.";
LOOTSTER_LOOTSYNC_OVERWRITE = "Update Your Loot DKP For Items In Common";
LOOTSTER_LOOTSYNC_OVERWRITE_TT = "Toggle Update of Loot DKP\nFor Loot You Have In Common";
LOOTSTER_LOOTSYNC_SELECT = "Select Player:"
LOOTSTER_LOOTSYNC_PLAYER = "Player:"
LOOTSTER_LOOTSYNC_PROGRESS = "Progress:"
LOOTSTER_LOOTSYNC_OTHERPLAYER = "Other Player...";

LOOTSTER_RAIDSYNC_TITLE = "Raid Synchronise";
LOOTSTER_RAIDSYNC_CLOSE = "Close";
LOOTSTER_RAIDSYNC_CLOSE_TT = "Close Synchronisation";
LOOTSTER_RAIDSYNC_CANCEL = "Cancel";
LOOTSTER_RAIDSYNC_CANCEL_TT = "Cancel Synchronisation";
LOOTSTER_RAIDSYNC_APPLY = "Synchronise";
LOOTSTER_RAIDSYNC_APPLY_TT = "Commence Synchronisation";
LOOTSTER_RAIDSYNC_HELPINTR = "Raid Synchronise allows you to transfer all raid data from an online player's Lootster (version 3.0.0 and above) to your Lootster.";
LOOTSTER_RAIDSYNC_HELPWARN = "ALL YOUR CURRENT RAID DATA WILL BE ERASED AFTER SYNCHRONISATION!"
LOOTSTER_RAIDSYNC_HELPCONF = "To continue, select the name of the player running Lootster with whom you wish to synchronise raids.";
LOOTSTER_RAIDSYNC_SELECT = "Select Player:"
LOOTSTER_RAIDSYNC_PLAYER = "Player:"
LOOTSTER_RAIDSYNC_PROGRESS = "Progress:"
LOOTSTER_RAIDSYNC_OTHERPLAYER = "Other Player...";

LOOTSTER_ITEMSYNC_TITLE = "Item Synchronise";
LOOTSTER_ITEMSYNC_CLOSE = "Close";
LOOTSTER_ITEMSYNC_CLOSE_TT = "Close Synchronisation";
LOOTSTER_ITEMSYNC_CANCEL = "Cancel";
LOOTSTER_ITEMSYNC_CANCEL_TT = "Cancel Synchronisation";
LOOTSTER_ITEMSYNC_APPLY = "Synchronise";
LOOTSTER_ITEMSYNC_APPLY_TT = "Commence Synchronisation";
LOOTSTER_ITEMSYNC_HELPINTR = "Item Synchronise allows you to transfer item class restrictions from an online player's Lootster (version 3.0.0 and above) to your Lootster.";
LOOTSTER_ITEMSYNC_HELPINFO = "You may also choose to update an item's class restrictions if it is also defined by the other player (that is, you have that item in COMMON)."
LOOTSTER_ITEMSYNC_HELPCONF = "To continue, select the name of the player running Lootster with whom you wish to synchronise items.";
LOOTSTER_ITEMSYNC_OVERWRITE = "Update Your Class Restrictions For Items In Common";
LOOTSTER_ITEMSYNC_OVERWRITE_TT = "Toggle Update of Class Restrictions\nFor Items You Have In Common";
LOOTSTER_ITEMSYNC_SELECT = "Select Player:"
LOOTSTER_ITEMSYNC_PLAYER = "Player:"
LOOTSTER_ITEMSYNC_PROGRESS = "Progress:"
LOOTSTER_ITEMSYNC_OTHERPLAYER = "Other Player...";

LOOTSTER_RAIDREPORT_CLOSE = "Close";
LOOTSTER_RAIDREPORT_CLOSE_TT = "Close Raid Report";
LOOTSTER_RAIDREPORT_REFRESH = "Refresh";
LOOTSTER_RAIDREPORT_REFRESH_TT = "Refresh Raid Report";
LOOTSTER_RAIDREPORT_SORTMANAGE = "Sort Field & Order:";
LOOTSTER_RAIDREPORT_SORTRAID = "Raids:";
LOOTSTER_RAIDREPORT_SORTRAID_TT = "Select Raid Sorting Field";
LOOTSTER_RAIDREPORT_SORTRAIDORD_TT = "Toggle Raid Sort Order Between Ascending/Descending";
LOOTSTER_RAIDREPORT_SORTBOSS = "Bosses:";
LOOTSTER_RAIDREPORT_SORTBOSS_TT = "Select Boss Sorting Field";
LOOTSTER_RAIDREPORT_SORTBOSSORD_TT = "Toggle Boss Sort Order Between Ascending/Descending";
LOOTSTER_RAIDREPORT_SORTATTEND = "Attendances:";
LOOTSTER_RAIDREPORT_SORTATTEND_TT = "Select Attendance Sorting Field";
LOOTSTER_RAIDREPORT_SORTATTENDORD_TT = "Toggle Attendance Sort Order Between Ascending/Descending";
LOOTSTER_RAIDREPORT_SORTADJUST = "Adjustments:";
LOOTSTER_RAIDREPORT_SORTADJUST_TT = "Select Adjustment Sorting Field";
LOOTSTER_RAIDREPORT_SORTADJUSTORD_TT = "Toggle Adjustment Sort Order Between Ascending/Descending";
LOOTSTER_RAIDREPORT_DETAILMANAGE = "Report Details:";
LOOTSTER_RAIDREPORT_REPORTATTEND = "Report boss attendances";
LOOTSTER_RAIDREPORT_REPORTATTEND_TT = "Toggle Reporting of Boss Attendances";
LOOTSTER_RAIDREPORT_REPORTATTENDDETAIL = "Show attendance details";
LOOTSTER_RAIDREPORT_REPORTATTENDDETAIL_TT = "Toggle Showing of Attendance Details";
LOOTSTER_RAIDREPORT_REPORTADJUST = "Report boss adjustments";
LOOTSTER_RAIDREPORT_REPORTADJUST_TT = "Toggle Reporting of Boss Adjustments";
LOOTSTER_RAIDREPORT_REPORTFORMAT = "Report Format:";
LOOTSTER_RAIDREPORT_REPORTFORMAT_TT = "Select Format of Report";
LOOTSTER_RAIDREPORT_TEXTDETAIL = "Text (Detailed)";
LOOTSTER_RAIDREPORT_TEXTDETAIL_TT = "Text-based Report with Full Details";
LOOTSTER_RAIDREPORT_TEXTCONSOL = "Text (Consolidated)";
LOOTSTER_RAIDREPORT_TEXTCONSOL_TT = "Text-based Report with Consolidated Details";
LOOTSTER_RAIDREPORT_CTRT1_16_13 = "CT_RaidTracker 1.16.13";
LOOTSTER_RAIDREPORT_CTRT1_16_13_TT = "CT_RaidTracker 1.16.13 XML Import Format";
LOOTSTER_RAIDREPORT_RAIDSORTLIST = 
{
	{ Field="BossN",		Prompt="Bosses" },
	{ Field="DateOpn",		Prompt="Date Opened" },
	{ Field="DateExp",		Prompt="Date Reset" },
	{ Field="DKPEarnt",		Prompt="DKP Earnt",	DKP=true },
	{ Field="DKPSpent",		Prompt="DKP Spent",	DKP=true },
	{ Field="DKPEarnt",		Prompt="EP",		EPGP=true },
	{ Field="DKPSpent",		Prompt="GP",		EPGP=true },
	{ Field="Zone",			Prompt="Zone" }
};
LOOTSTER_RAIDREPORT_BOSSSORTLIST = 
{
	{ Field="AdjustN",		Prompt="Adjustments" },
	{ Field="AttendN",		Prompt="Attendances" },
	{ Field="Boss",			Prompt="Boss" },
	{ Field="DateBeg",		Prompt="Date Started" },
	{ Field="DateEnd",		Prompt="Date Finished" },
	{ Field="DKPEarnt",		Prompt="DKP Earnt",	DKP=true },
	{ Field="DKPSpent",		Prompt="DKP Spent",	DKP=true },
	{ Field="DKPEarnt",		Prompt="EP",		EPGP=true },
	{ Field="DKPSpent",		Prompt="GP",		EPGP=true }
};
LOOTSTER_RAIDREPORT_ATTENDSORTLIST = 
{
	{ Field="Alt",			Prompt="Alt" },
	{ Field="Attended",		Prompt="Attended" },
	{ Field="AdjustN",		Prompt="Adjustments" },
	{ Field="DKPEarnt",		Prompt="DKP Earnt",	DKP=true },
	{ Field="DKPEarnt",		Prompt="EP",		EPGP=true },
	{ Field="Player",		Prompt="Main" },
	{ Field="Toon",			Prompt="Toon" },
};
LOOTSTER_RAIDREPORT_ADJUSTSORTLIST = 
{
	{ Field="Alt",			Prompt="Alt" },
	{ Field="DateAdj",		Prompt="Date Adjusted" },
	{ Field="Comment",		Prompt="Comment" },
	{ Field="DKPEarnt",		Prompt="DKP Earnt",	DKP=true },
	{ Field="DKPSpent",		Prompt="DKP Spent",	DKP=true },
	{ Field="DKPEarnt",		Prompt="EP",		EPGP=true },
	{ Field="DKPSpent",		Prompt="GP",		EPGP=true },
	{ Field="Player",		Prompt="Main" },
	{ Field="Quality",		Prompt="Quality" },
	{ Field="Reason",		Prompt="Reason" },
	{ Field="Usage",		Prompt="Usage" }
};

LOOTSTER_RAIDRAID_TITLE = "%s Raid";
LOOTSTER_RAIDRAID_CLOSE = "Cancel";
LOOTSTER_RAIDRAID_CLOSE_TT = "Cancel Changes";
LOOTSTER_RAIDRAID_APPLY = "%s";
LOOTSTER_RAIDRAID_APPLY_TT = "Apply Changes";
LOOTSTER_RAIDRAID_ZONE = "Zone:";
LOOTSTER_RAIDRAID_USEHERE = "Use Here";
LOOTSTER_RAIDRAID_USEHERE_TT = "Use Current Zone as Raid Name";
LOOTSTER_RAIDRAID_RUNNING = "Running";
LOOTSTER_RAIDRAID_RUNNING_TT = "Make this Raid the Running Raid";
LOOTSTER_RAIDRAID_TYPE = "Raid Type:";
LOOTSTER_RAIDRAID_TYPE_TT = "Select Type of Raid Entry";
LOOTSTER_RAIDRAID_WOWID = "WoW ID:";
LOOTSTER_RAIDRAID_DATEOPN = "Open Date:";
LOOTSTER_RAIDRAID_DATEEXP = "Reset Date:";
LOOTSTER_RAIDRAID_COMMENT = "Comment:";
LOOTSTER_RAIDRAID_NOWOWID = "No Raid ID";
LOOTSTER_RAIDRAID_NODATEEXP = "Not Set";
LOOTSTER_RAIDRAID_ZONEUNKNOWN = "Unknown Zone";

LOOTSTER_RAIDBOSS_TITLE = "%s Boss";
LOOTSTER_RAIDBOSS_CLOSE = "Cancel";
LOOTSTER_RAIDBOSS_CLOSE_TT = "Cancel Changes";
LOOTSTER_RAIDBOSS_APPLY = "%s";
LOOTSTER_RAIDBOSS_APPLY_TT = "Apply Changes";
LOOTSTER_RAIDBOSS_BOSS = "Boss:"
LOOTSTER_RAIDBOSS_TYPE = "Boss Type:"
LOOTSTER_RAIDBOSS_TYPE_TT = "Select Type of Boss/Event Entry"
LOOTSTER_RAIDBOSS_ATTEMPT = "Attempt:";
LOOTSTER_RAIDBOSS_TBD = "TBD";
LOOTSTER_RAIDBOSS_MAKETBD = "Make TBD";
LOOTSTER_RAIDBOSS_MAKETBD_TT = "Make Boss Name "..LOOTSTER_RAIDBOSS_TBD.." to be Auto-Filled on Detecting Boss";
LOOTSTER_RAIDBOSS_USETARGET = "Use Target";
LOOTSTER_RAIDBOSS_USETARGET_TT = "Use Current Target as Boss Name";
LOOTSTER_RAIDBOSS_RUNNING = "Running";
LOOTSTER_RAIDBOSS_RUNNING_TT = "Make this Boss the Running Boss";
LOOTSTER_RAIDBOSS_FULLDKP = "Full DKP:";
LOOTSTER_RAIDBOSS_FULLDKP_TT = "Bonus Award's Full DKP Value";
LOOTSTER_RAIDBOSS_PARTIAL = "P%:";
LOOTSTER_RAIDBOSS_PARTIAL_TT = "Bonus Award's Partial Attendance Percentage of Full DKP";
LOOTSTER_RAIDBOSS_STANDBY = "S%:";
LOOTSTER_RAIDBOSS_STANDBY_TT = "Bonus Award's Standby Attendance Percentage of Full DKP";
LOOTSTER_RAIDBOSS_DATEBEG = "Start Date:";
LOOTSTER_RAIDBOSS_DATEEND = "Finish Date:";
LOOTSTER_RAIDBOSS_NODATEEND = "In Progress";

LOOTSTER_RAIDATTEND_TITLE = "%s Attendance";
LOOTSTER_RAIDATTEND_CLOSE = "Cancel";
LOOTSTER_RAIDATTEND_CLOSE_TT = "Cancel Changes";
LOOTSTER_RAIDATTEND_APPLY = "%s";
LOOTSTER_RAIDATTEND_APPLY_TT = "Apply Changes";
LOOTSTER_RAIDATTEND_SELECT = "Select Player:"
LOOTSTER_RAIDATTEND_PLAYER = "Player:"
LOOTSTER_RAIDATTEND_ATTENDED = "Attended:";
LOOTSTER_RAIDATTEND_DKPEARNT = "DKP Earnt:";
LOOTSTER_RAIDATTEND_EPEARNT = "EP Earnt:";
LOOTSTER_RAIDATTEND_OTHERPLAYER = "Other Player...";
LOOTSTER_RAIDATTEND_DATEATT = "Attend Date:";

LOOTSTER_RAIDADJUST_TITLE = "%s Adjustment";
LOOTSTER_RAIDADJUST_CLOSE = "Cancel";
LOOTSTER_RAIDADJUST_CLOSE_TT = "Cancel Changes";
LOOTSTER_RAIDADJUST_APPLY = "%s";
LOOTSTER_RAIDADJUST_APPLY_TT = "Apply Changes";
LOOTSTER_RAIDADJUST_ZONE = "Zone:"
LOOTSTER_RAIDADJUST_BOSS = "Boss:"
LOOTSTER_RAIDADJUST_SELECT = "Select Player:"
LOOTSTER_RAIDADJUST_PLAYER = "Player:"
LOOTSTER_RAIDADJUST_APPEND = "Append";
LOOTSTER_RAIDADJUST_APPEND_TT = "Append Selected Player to Assignee List";
LOOTSTER_RAIDADJUST_UPDATE = "Update";
LOOTSTER_RAIDADJUST_UPDATE_TT = "Update Selected Player in Assignee List";
LOOTSTER_RAIDADJUST_REMOVE = "Remove";
LOOTSTER_RAIDADJUST_REMOVE_TT = "Remove Selected Player from Assignee List";
LOOTSTER_RAIDADJUST_REMOVEALL = "Clear";
LOOTSTER_RAIDADJUST_REMOVEALL_TT = "Remove All Players from Assignee List";
LOOTSTER_RAIDADJUST_ASSIGNEES = "Assignees: %d"
LOOTSTER_RAIDADJUST_USAGE = "Usage"
LOOTSTER_RAIDADJUST_DKPVALUE = "DKP Value:";
LOOTSTER_RAIDADJUST_DKPEARNT = "DKP Earnt:";
LOOTSTER_RAIDADJUST_EPEARNT = "EP Earnt:";
LOOTSTER_RAIDADJUST_DKPSPENT = "DKP Spent:";
LOOTSTER_RAIDADJUST_GPSPENT = "GP Spent:";
LOOTSTER_RAIDADJUST_DEFAULT = "Default";
LOOTSTER_RAIDADJUST_DEFAULT_TT = "Reset DKP to Default Value For Item Use";
LOOTSTER_RAIDADJUST_USAGE = "Usage:";
LOOTSTER_RAIDADJUST_USAGE_TT = "Select Usage of Adjustment Entry"
LOOTSTER_RAIDADJUST_X = "x";
LOOTSTER_RAIDADJUST_ITEM = "Item:";
LOOTSTER_RAIDADJUST_REASON = "Reason:"
LOOTSTER_RAIDADJUST_COMMENT = "Comment:"
LOOTSTER_RAIDADJUST_OTHERPLAYER = "Other Player...";

LOOTSTER_DEBUGGING_CLOSE = "Close";
LOOTSTER_DEBUGGING_CLOSE_TT = "Close Debugging Window";
LOOTSTER_DEBUGGING_TRANSMIT = "Transmit";
LOOTSTER_DEBUGGING_TRANSMIT_TT = "Transmit to Addon";

LOOTSTER_ROLL_PATTERN = "(%S+) rolls (%d+) %((%d+)%-(%d+)%)";
LOOTSTER_CLASS_PATTERN = "%s?([^%p]+)%p?";
LOOTSTER_RF_PATTERN = "^.*Raid Finder";
LOOTSTER_HEROIC_PATTERN = "^.*Heroic";
LOOTSTER_CLASSES_PATTERN = "^Classes:(.*)";

LOOTSTER_LOOT_SELF_PATTERN = "^You receive loot: ("..LOOTSTER_ITEMFULL_PATTERN..")(.-)%.$";
LOOTSTER_LOOT_PLAYER_PATTERN = "^([^%s]+) receives loot: ("..LOOTSTER_ITEMFULL_PATTERN..")(.-)%.$";
LOOTSTER_LOOT_MULTIITEM_PATTERN = "^x(%d+)$";

LOOTSTER_SEP_DATE = "/";
LOOTSTER_SEP_TIME = ":";

LOOTSTER_MSG_LOAD = "Lootster v%s loaded";
LOOTSTER_MSG_QUERY = "|cffff8400"..LOOTSTER_LABEL_LOOTSTER.."|r is querying server for %s";
LOOTSTER_MSG_NBG = "%s roll for %s";
LOOTSTER_MSG_NBG_LINK = "%s roll for %s on %s";
LOOTSTER_MSG_NBG_LINK_COST = "%s roll for %s on %s costing %s points";
LOOTSTER_MSG_NBG_TIED = "%s, please roll for %s using /roll 100";
LOOTSTER_MSG_NBG_TIED_LINK = "%s, please roll for %s on %s using /roll 100";
LOOTSTER_MSG_PLEASE = "Please";
LOOTSTER_MSG_PLEASE_CLASS = "%s, please";
LOOTSTER_MSG_PLEASE_USAGECLASS = "%s only can roll %s, please";
LOOTSTER_MSG_ASKN = "Please roll for %s using /roll %d";
LOOTSTER_MSG_ASKN_LINK = "Please roll for %s on %s using /roll %d";
LOOTSTER_MSG_ASKU = "Please roll for %s using a Usage Roll.  Whisper me 'loot usage' for list of usage rolls";
LOOTSTER_MSG_ASKU_LINK = "Please roll for %s on %s using a Usage Roll.  Whisper me 'loot usage' for list of usage rolls";
LOOTSTER_MSG_ASK100 = "Please roll for %s using /roll 100";
LOOTSTER_MSG_ASK100_LINK = "Please roll for %s on %s using /roll 100";
LOOTSTER_MSG_ASK1000 = "Please roll for %s using /roll 100 (Need) or /roll 1000 (Greed)";
LOOTSTER_MSG_ASK1000_LINK = "Please roll for %s on %s using /roll 100 (Need) or /roll 1000 (Greed)";
LOOTSTER_MSG_ACKPASSNONE = "You passed your roll for %s.  If you do want to roll, issue roll command";
LOOTSTER_MSG_ACKPASSNONE_LINK = "You passed your roll for %s on %s.  If you do want to roll, issue roll command";
LOOTSTER_MSG_ACKPASSROLL = "You passed your roll of %d for %s.  If you do want your roll to count, type 'reclaim' into party/raid chat";
LOOTSTER_MSG_ACKPASSROLL_LINK = "You passed your roll of %d for %s on %s.  If you do want your roll to count, type 'reclaim' into party/raid chat";
LOOTSTER_MSG_ACKRECLAIMNONE = "You have no roll to reclaim for %s";
LOOTSTER_MSG_ACKRECLAIMNONE_LINK = "You have no roll to reclaim for %s on %s";
LOOTSTER_MSG_ACKRECLAIMROLL = "You have reclaimed your roll of %d for %s";
LOOTSTER_MSG_ACKRECLAIMROLL_LINK = "You have reclaimed your roll of %d for %s on %s";
LOOTSTER_MSG_ACTIVEROLL = "Your roll of %d for %s had not been passed!";
LOOTSTER_MSG_ACTIVEROLL_LINK = "Your roll of %d for %s on %s had not been passed!";
LOOTSTER_MSG_MUSTRECLAIMROLL = "You must reclaim your previous roll of %d for %s by typing 'reclaim' in party/raid chat";
LOOTSTER_MSG_MUSTRECLAIMROLL_LINK = "You must reclaim your previous roll of %d for %s on %s by typing 'reclaim' in party/raid chat";
LOOTSTER_MSG_DUP = "Your roll of %s (%s-%s) is a duplicate (first roll is %d)!";
LOOTSTER_MSG_REJECT = "Your roll of %s (%s-%s) has an incorrect range!";
LOOTSTER_MSG_ACKROLL = "Received your roll of %s (%s-%s).  Good luck!";
LOOTSTER_MSG_ACKROLLTOGREED = "Received your NEED to GREED roll of %s (%s-%s).  Good luck!";
LOOTSTER_MSG_ACKROLLTODOWNGRADE = "Received your downgrade %s to %s roll of %s (%s-%s).  Good luck!";
LOOTSTER_MSG_WINSPERRAID = "Your roll of %s has been put on hold as you have already won %s %s item(s).  Maximum wins of this usage per raid is %s";
LOOTSTER_MSG_NONBGSELF = "Player %s has rolled outside of a call for rolls!";
LOOTSTER_MSG_NONBGPLAYER = "No call for rolls has been made!  Whisper %s if urgent!";
LOOTSTER_MSG_NOTROLLCLASS = "Your roll of %s (%s-%s) is ignored as you are not a %s";
LOOTSTER_MSG_NOTPASSCLASS = "Your pass is ignored as you are not a %s";
LOOTSTER_MSG_NOTRECLAIMCLASS = "Your reclaim is ignored as you are not a %s";
LOOTSTER_MSG_NOTTIEDSELF = "Player %s made a TIED roll when they are not a tied winner!";
LOOTSTER_MSG_NOTTIEDPLAYER = "Your TIED roll is ignored as you are not a tied winner!";
LOOTSTER_MSG_NOTMEMBER = "Player %s has rolled and is not member of the party/raid!";
LOOTSTER_MSG_LAGGARD1 = "%s has yet to roll or pass!"
LOOTSTER_MSG_LAGGARDN = "%s have yet to roll or pass!"
LOOTSTER_MSG_LAGGARD1_LINK = "%s has yet to roll or pass for %s!"
LOOTSTER_MSG_LAGGARDN_LINK = "%s have yet to roll or pass for %s!"
LOOTSTER_MSG_COUNTDOWN = "Countdown of %s roll in %d seconds...";
LOOTSTER_MSG_COUNTDOWN_LINK = "Countdown of %s roll for %s in %d seconds...";
LOOTSTER_MSG_COUNTDOWNTIC = "%d";
LOOTSTER_MSG_TIED = "%s tied with %s roll of %s!";
LOOTSTER_MSG_TIED_LINK = "%s tied for %s with %s roll of %s!";
LOOTSTER_MSG_ANNOUNCE = "%s won with %s roll of %s!";
LOOTSTER_MSG_ANNOUNCE_LINK = "%s won %s with %s roll of %s!";
LOOTSTER_MSG_UNCLAIMED1 = "There is one item unclaimed!";
LOOTSTER_MSG_UNCLAIMED1_LINK = "There is one %s unclaimed!";
LOOTSTER_MSG_UNCLAIMEDN = "There are %d items unclaimed!";
LOOTSTER_MSG_UNCLAIMEDN_LINK = "There are %d x %s unclaimed!";
LOOTSTER_MSG_HOLDROLL = "Holding roll for %s!";
LOOTSTER_MSG_ALLOWROLL = "Allowing roll for %s!";
LOOTSTER_MSG_CHATRESTRICT = "<%s> Item: %s";
LOOTSTER_MSG_CHATRESTRICT_LINK = "<%s> %s: %s";
LOOTSTER_MSG_NORESTRICTIONS = "No Restrictions";
LOOTSTER_MSG_RESTRICTIODELETED = "Lootster has removed the restriction for non-cached item '%s'";
LOOTSTER_MSG_SEP = ", ";
LOOTSTER_MSG_OR = " or ";
LOOTSTER_MSG_AND = " and ";
LOOTSTER_MSG_BADCOMMAND = "Unrecognised Looster command '%s'";
LOOTSTER_MSG_DKPMODE = "%s Mode.  Priority: %s Membership, %s Toons, %s Greed.  %s";
LOOTSTER_MSG_NORMMODE = "%s Mode.  Priority: %s Membership, %s Toons, %s Greed.  Call for Roll: %s";
LOOTSTER_MSG_TYPE1001000 = "100 and 1000";
LOOTSTER_MSG_TYPENEEDGREED = "Need then Greed Roll";
LOOTSTER_MSG_TYPEFREEFORALL = "Free-For-All Roll";
LOOTSTER_MSG_TYPEDKP = "DKP Roll";
LOOTSTER_MSG_TYPETIER = "TIER Roll";
LOOTSTER_MSG_TYPEMODIFIEDROLL = "DKP MODIFIED Roll";
LOOTSTER_MSG_TYPEMODIFIEDDKP = "Roll MODIFIED DKP";
LOOTSTER_MSG_TYPEEPGP = "EP/GP";
LOOTSTER_MSG_MEMBERNONE = "Equal";
LOOTSTER_MSG_MEMBERUSED = "Full/Trial/App";
LOOTSTER_MSG_TOONNONE = "Equal";
LOOTSTER_MSG_TOONUSED = "Main/Alt";
LOOTSTER_MSG_GREEDFFANONE = "Member/Toon";
LOOTSTER_MSG_GREEDFFAUSED = "Equal";
LOOTSTER_MSG_ATTEARNTNONE = "Att Earnt DKP: Ignored";
LOOTSTER_MSG_ATTEARNTUSED = "Att Earnt DKP: In Total";
LOOTSTER_MSG_CAPSNONE = ", DKP Caps: None";
LOOTSTER_MSG_CAPSUSED = ", DKP Caps: +%d/-%d";
LOOTSTER_MSG_DKPFACTOR = ", DKP Divisor %d";
LOOTSTER_MSG_ROLLFACTOR = ", Roll Multiplier %d";
LOOTSTER_MSG_EPMINUSED = "EP Minimum %d, ";
LOOTSTER_MSG_EPMINNONE = "No EP Minimum, ";
LOOTSTER_MSG_GPBASEUSED = "GP Base %d";
LOOTSTER_MSG_GPBASENONE = "No GP Base";
LOOTSTER_MSG_OPTIONAL = "Optional";
LOOTSTER_MSG_REQUIRED = "Required";
LOOTSTER_MSG_UNKNOWNTIER = "?";
LOOTSTER_MSG_ATTENDEDTOOLTIP = "Double Click to Navigate to Attendance Entry in Raid Tab";
LOOTSTER_MSG_ADJUSTEDTOOLTIP = "Click to Link Into Lootster\nCtrl-Click to Display Link Details\nShift-Click to Link into Chat Window\nDouble Click to Navigate to Adjustment Entry in Raid Tab";
LOOTSTER_MSG_LOOTTOOLTIP = "DKP on %s: Official=%s, Manual=%s";
LOOTSTER_MSG_LOOTDKPMOB = "Unknown";
LOOTSTER_MSG_RAIDTOOLTIP = "%s is a %s\nDouble Click to Toggle this Raid's Running State";
LOOTSTER_MSG_RAIDCREATED = "A raid was created: Zone %s (%s) opened/reset %s/%s";
LOOTSTER_MSG_RAIDCHANGED = "A raid was changed: Zone %s (%s) opened/reset %s/%s, was Zone %s (%s) opened/reset %s/%s";
LOOTSTER_MSG_RAIDDELETED = "A raid was removed: Zone %s (%s) opened/reset %s/%s";
LOOTSTER_MSG_RAIDDELETEDALL = "All raids have been removed";
LOOTSTER_MSG_BOSSTOOLTIPDC = "%s is a %s\nDouble Click to Toggle this Boss's Running State";
LOOTSTER_MSG_BOSSTOOLTIPNDC = "%s is a %s";
LOOTSTER_MSG_BOSSCREATED = "A boss was created: Boss %s started/ended %s/%s";
LOOTSTER_MSG_BOSSCHANGED = "A boss was changed: Boss %s started/ended %s/%s, was Boss %s started/ended %s/%s";
LOOTSTER_MSG_BOSSDELETED = "A boss was removed: Boss %s started/ended %s/%s";
LOOTSTER_MSG_BOSSDELETEDALL = "All bosses for Zone %s have been removed";
LOOTSTER_MSG_ATTENDTOTAL = "Attendance Total";
LOOTSTER_MSG_ATTENDTOOLTIP = "Player is %s, Alt is %s";
LOOTSTER_MSG_ATTENDCREATEDDKP = "An attendance was created: Attendance is %s granting DKP of %0.3f";
LOOTSTER_MSG_ATTENDCREATEDEPGP = "An attendance was created: Attendance is %s granting EP of %0.3f";
LOOTSTER_MSG_ATTENDCREATEDNODKP = "An attendance was created: Attendance is %s";
LOOTSTER_MSG_ATTENDCHANGEDDKP = "An attendance was changed: Attendance is %s granting DKP of %0.3f, was Attendance of %s granting DKP of %0.3f";
LOOTSTER_MSG_ATTENDCHANGEDEPGP = "An attendance was changed: Attendance is %s granting EP of %0.3f, was Attendance of %s granting EP of %0.3f";
LOOTSTER_MSG_ATTENDCHANGEDNODKP = "An attendance was changed: Attendance is %s, was Attendance of %s";
LOOTSTER_MSG_ATTENDIGNORED = "An attendance was ignored: Attendance is already %s";
LOOTSTER_MSG_ATTENDDELETEDDKP = "An attendance was removed: Attendance was %s granting DKP of %0.3f";
LOOTSTER_MSG_ATTENDDELETEDEPGP = "An attendance was removed: Attendance was %s granting EP of %0.3f";
LOOTSTER_MSG_ATTENDDELETEDNODKP = "An attendance was removed: Attendance was %s";
LOOTSTER_MSG_ATTENDDELETEDALL = "All %s/%s attendances have been removed";
LOOTSTER_MSG_ADJUSTTOTAL = "Adjustment Total";
LOOTSTER_MSG_ADJUSTTOOLTIP = "Player is %s, Alt is %s, Usage of %s";
LOOTSTER_MSG_ADJUSTCREATEDDKP = "An adjustment was created: DKP is %0.3f for %s";
LOOTSTER_MSG_ADJUSTCREATEDEPGP = "An adjustment was created: EP/GP is %0.3f/%0.3f for %s";
LOOTSTER_MSG_ADJUSTCREATEDNODKP = "An adjustment was created: For %s";
LOOTSTER_MSG_ADJUSTCHANGEDDKP = "An adjustment was changed: DKP is %0.3f for %s, was DKP of %0.3f for %s";
LOOTSTER_MSG_ADJUSTCHANGEDEPGP = "An adjustment was changed: EP/GP is %0.3f/%0.3f for %s, was EP/GP of %0.3f/%0.3f for %s";
LOOTSTER_MSG_ADJUSTCHANGEDNODKP = "An adjustment was changed: For %s, Was %s";
LOOTSTER_MSG_ADJUSTDELETEDDKP = "An adjustment was removed: DKP was %0.3f for %s";
LOOTSTER_MSG_ADJUSTDELETEDEPGP = "An adjustment was removed: EP/GP was %0.3f/%0.3f for %s";
LOOTSTER_MSG_ADJUSTDELETEDNODKP = "An adjustment was removed: Was %s";
LOOTSTER_MSG_ADJUSTDELETEDALL = "All %s/%s adjustments have been removed";
LOOTSTER_MSG_ASSIGNTOOLTIP = "Player is %s, Alt is %s, Usage of %s has been %s";
LOOTSTER_MSG_ASSIGNDELETEDALL = "All %s/%s unmatched adjustments have been removed";
LOOTSTER_MSG_BADREPORTPLUGIN = 	"Lootster_RegisterReport: Must have invariant handle string (%q), type mask (%q), name string (%q), tooltip string (%q) and callback (%q)";
LOOTSTER_MSG_ITEMTOOLTIP = "Restrictions on %s: %s";
LOOTSTER_MSG_HERE_NOBOSS = "No boss is running at the moment";
LOOTSTER_MSG_HERE_INRAID = "You are already in the party/raid";
LOOTSTER_MSG_HERE_NOSTANDBY = "Standby attendence has not been enabled";
LOOTSTER_MSG_HERE_NOCHANNEL = "Unable to join custom channel '%s' - either a bad channel name or your channel limit has been reached";
LOOTSTER_MSG_TELL_RESET = "Your tell overrides have been reset";
LOOTSTER_MSG_TELL_TOGGLE = "Your %s tell override has been set %s";

LOOTSTER_MSG_SYNCBADVERSION = "%s Version invalid: player %s version %d greater than %d";
LOOTSTER_MSG_SYNCBADRECORD = "%s Aborted: bad %s record, data=%s";
LOOTSTER_MSG_SYNCBADCANCEL = "%s Cancelled: by player";
LOOTSTER_MSG_SYNCBADHASHTOTAL = "%s Ignored: received records of %d differ from hash total of %d";

LOOTSTER_MSG_SYNCHRONISEDLOOT = "Loot DKP synchronised with player %s, %d records!";
LOOTSTER_MSG_SYNCHRONISEDRAID = "Raids/bosses/attendances/adjustments synchronised with player %s, %d records!";
LOOTSTER_MSG_SYNCHRONISEDITEM = "Item class restrictions synchronised with player %s, %d records!";

LOOTSTER_MSG_ADDONBADVERSION = "%s Version invalid: player %s version %d greater than %d.  It is suggested to upgrade to latest Lootster";
LOOTSTER_MSG_ADDONBADRECORD = "%s Aborted: bad %s record, data=%s";
LOOTSTER_MSG_ADDONBADCANCEL = "%s Cancelled: by player";
LOOTSTER_MSG_ADDONBADHASHTOTAL = "%s Ignored: received records of %d differ from hash total of %d";
LOOTSTER_MSG_ADDONPERMDENIED = "%s Ignored: %s is not Master Looter/Leader to hold/allow %s's roll";

LOOTSTER_SYNC_STATE_CONTACT = "Contacting...";
LOOTSTER_SYNC_STATE_ACKED = "Acknowledged...";
LOOTSTER_SYNC_STATE_RECEIVE = "Receiving...";
LOOTSTER_SYNC_STATE_COMMIT = "Saving...";
LOOTSTER_SYNC_STATE_SUCCESS = "Successful";
LOOTSTER_SYNC_STATE_OFFLINE = "Player Offline";
LOOTSTER_SYNC_STATE_TIMEOUT = "Timed Out";
LOOTSTER_SYNC_STATE_CANCEL = "Cancelled";
LOOTSTER_SYNC_STATE_FAILED = "Failure";

LOOTSTER_PROMPT_LOOT_CLEARALL = "Are you sure you want to clear ALL official DKP overrides?";
LOOTSTER_PROMPT_LOOT_DELETE = "Are you sure you want to delete this provisory DKP loot?";
LOOTSTER_PROMPT_LOOT_DELETEALL = "Are you sure you want to delete ALL provisory DKP loot?";
LOOTSTER_PROMPT_RAID_DELETE = "Are you sure you want to delete this raid?";
LOOTSTER_PROMPT_RAID_DELETEALL = "Are you sure you want to delete ALL raids?";
LOOTSTER_PROMPT_BOSS_DELETE = "Are you sure you want to delete this raid boss?";
LOOTSTER_PROMPT_BOSS_DELETEALL = "Are you sure you want to delete ALL raid bosses?";
LOOTSTER_PROMPT_ATTEND_PLAYER = "Enter Player for Attendance";
LOOTSTER_PROMPT_ATTEND_DELETE = "Are you sure you want to delete this boss attendance?";
LOOTSTER_PROMPT_ATTEND_DELETEALL = "Are you sure you want to delete ALL boss attendances?";
LOOTSTER_PROMPT_ADJUST_PLAYER = "Enter Player for Adjustment";
LOOTSTER_PROMPT_ADJUST_DELETE = "Are you sure you want to delete this boss adjustment?";
LOOTSTER_PROMPT_ADJUST_DELETEALL = "Are you sure you want to delete ALL boss adjustments?";
LOOTSTER_PROMPT_ASSIGN_DELETE = "Are you sure you want to delete this unmatched boss adjustment?";
LOOTSTER_PROMPT_ASSIGN_DELETEALL = "Are you sure you want to delete ALL unmatched boss adjustments?";
LOOTSTER_PROMPT_ITEM_DELETE = "Are you sure you want to delete this item?";
LOOTSTER_PROMPT_ITEM_DELETEALL = "Are you sure you want to delete ALL items?";
LOOTSTER_PROMPT_LOOTSYNC_PLAYER = "Enter Player for Loot Synchronise";
LOOTSTER_PROMPT_RAIDSYNC_PLAYER = "Enter Player for Raid Synchronise";
LOOTSTER_PROMPT_ITEMSYNC_PLAYER = "Enter Player for Item Synchronise";
LOOTSTER_PROMPT_OPTION_BANKER = "Enter Banker's Name for Banked Items";

LOOTSTER_REPORT_BREAK = "\n";
LOOTSTER_REPORT_SUMMARY	= "|cffffff80Summary|r\n";
LOOTSTER_REPORT_RAIDS = "Raids:         %5d\n";
LOOTSTER_REPORT_BOSSES = "Bosses:        %5d\n";
LOOTSTER_REPORT_ATTENDS = "Attendances:   %5d\n";
LOOTSTER_REPORT_ADJUSTS =  "Adjustments:   %5d\n";
LOOTSTER_REPORT_TOTALDKP =  "Total Earnt/Spent: %10.3f/%10.3f\n";
LOOTSTER_REPORT_TOTALEPGP = "Total EP/GP:       %10.3f/%10.3f\n";
LOOTSTER_REPORT_RAID = "|cff80ff80Raid: %s|r\n";
LOOTSTER_REPORT_BOSS = "|cff80ffffBoss: %s|r\n";
LOOTSTER_REPORT_TYPE = "Type: %s\n";
LOOTSTER_REPORT_DATEOPN = "Date Opened:   %-11.11s\n";
LOOTSTER_REPORT_DATEEXP = "Date Expires:  %-11.11s (%s)\n";
LOOTSTER_REPORT_COMMENT = "Comments:\n%s\n";
LOOTSTER_REPORT_DATEBEG = "Date Started:  %-11.11s\n";
LOOTSTER_REPORT_DATEEND = "Date Finished: %-11.11s\n";
LOOTSTER_REPORT_ATTEND = "|cff8080ffAttendances|r\n";
LOOTSTER_REPORT_ADJUST = "|cff408080Adjustments|r\n";
LOOTSTER_REPORT_ATTENDANCEDKPDETAIL = "%-12.12s %-12.12s %-7.7s %9.3f\n";
LOOTSTER_REPORT_ATTENDANCEDKPSIMPLE = "%-12.12s\n";
LOOTSTER_REPORT_ATTENDANCENODKPDETAIL = "%-12.12s %-12.12s %-7.7s\n";
LOOTSTER_REPORT_ATTENDANCENODKPSIMPLE = "%-12.12s\n";
LOOTSTER_REPORT_ADJUSTMENTDKP = "%-12.12s %-12.12s %-11.11s %9.3f/%9.3f %-10.10q %6d %q %q\n";
LOOTSTER_REPORT_ADJUSTMENTNODKP = "%-12.12s %-12.12s %-11.11s %-10.10q %6d %q %q\n";

LOOTSTER_ECHO_NA = "N/A";
LOOTSTER_ECHO_BOSS = "%s \#%d";
LOOTSTER_ECHO_DATE = "%m/%d %H%M";
LOOTSTER_ECHO_ITEMS = "%d items"
LOOTSTER_ECHO_ITEMS_LINK = "%d x %s";
LOOTSTER_ECHO_ITEMDKP = "Item DKP %0.3f %s (%s)";
LOOTSTER_ECHO_ITEMGP = "Item GP %0.3f %s (%s)";
LOOTSTER_ECHO_LEVELSEP = "/";
LOOTSTER_ECHO_LEVELCOUNT = "%s=%d";
LOOTSTER_ECHO_LEVELBREAKDOWNNORM = "Priorities: %s";
LOOTSTER_ECHO_LEVELBREAKDOWNTIER = "Tiers & Priorities: %s";
LOOTSTER_ECHO_LEVELBREAKDOWNMAXLEN = 255 - string.len(LOOTSTER_ECHO_LEVELBREAKDOWNTIER);

LOOTSTER_ECHO_PLAYERROLLDKP_FMT = "Your %s%s.  %s";
LOOTSTER_ECHO_PLAYERROLLNORM_FMT = "Your %s.  %s";

LOOTSTER_ECHO_PLAYERROLL_DKP = "DKP is %+0.3f as ";
LOOTSTER_ECHO_PLAYERROLL_TIER = "DKP is %+0.3f in Tier %d as ";
LOOTSTER_ECHO_PLAYERROLL_EPGP = "PR is %0.3f as ";
LOOTSTER_ECHO_PLAYERROLL_ROLL = "Your roll command is /roll %d";
LOOTSTER_ECHO_PLAYERROLL_ROLLU = "Whisper me 'loot usage' for list of usage rolls";
LOOTSTER_ECHO_PLAYERROLL_PRIOR = "Priority %s";
LOOTSTER_ECHO_PLAYERROLL_PRIORIS = "Priority is %s";
LOOTSTER_ECHO_PLAYERROLL_PRIORPOS = "Priority %s (Higher=%s, Equal=%s)";
LOOTSTER_ECHO_PLAYERROLL_PRIORPOSIS = "Priority is %s (Higher=%s, Equal=%s)";
LOOTSTER_ECHO_USAGEROLLS = "Available usage rolls in priority order:";
LOOTSTER_ECHO_USAGEROLLCMD = "Roll /roll %d for %s";
LOOTSTER_ECHO_ATTENDDKP = "Player Attend is %s granting DKP of %+0.3f for %s";
LOOTSTER_ECHO_ATTENDEPGP = "Player Attend is %s granting EP of %0.3f for %s";
LOOTSTER_ECHO_ATTENDNODKP = "Player Attend is %s for %s";
LOOTSTER_ECHO_ADJUSTDKP = "Player Adjust DKP %+0.3f for %s";
LOOTSTER_ECHO_ADJUSTEPGP = "Player Adjust EP/GP %0.3f/%0.3f for %s";
LOOTSTER_ECHO_ADJUSTNODKP = "Player Adjust for %s";
LOOTSTER_ECHO_PLAYERDKP = "Player Base DKP %+0.3f as Priority %s, Effective DKP %+0.3f as Priority %s, Adj %+0.3f for %s";
LOOTSTER_ECHO_PLAYERTIER = "Player Base DKP %+0.3f in Tier %d as Priority %s, Effective DKP %+0.3f in Tier %d as Priority %s, Adj %+0.3f for %s";
LOOTSTER_ECHO_PLAYEREPGP = "Player Base PR=EP/GP %0.3f=%0.3f/%0.3f as Priority %s, Effective PR=EP/GP %0.3f=%0.3f/%0.3f as Priority %s, Earnt/Spent %0.3f/%0.3f for %s";

LOOTSTER_NBG_NEED = "NEED";
LOOTSTER_NBG_GREED = "GREED";
LOOTSTER_NBG_1001000 = "NEED(100)/GREED(1000)";
LOOTSTER_NBG_FREEFORALL = "FREE-FOR-ALL";
LOOTSTER_NBG_USAGE = "USAGE";
LOOTSTER_NBG_TIED = "TIED";
LOOTSTER_NBG_PASSIVE = "PASSIVE";

LOOTSTER_TOGGLE_ON = "On";
LOOTSTER_TOGGLE_OFF = "Off";

LOOTSTER_CONV_RAID = "Old Raid";
LOOTSTER_CONV_RAIDID = "RConverted";
LOOTSTER_CONV_BOSS = "Old Boss";
LOOTSTER_CONV_BOSSID = "BConverted";

LOOTSTER_COST_POINTS = "%0.3f";
LOOTSTER_COST_DKPTBD = "TBD";
LOOTSTER_COST_DKP0TBD = "No/TBD";
LOOTSTER_COST_DKPCALC = "Calculated";
LOOTSTER_COST_DKPNONE = "None";

LOOTSTER_ROLL_PREFIX = "a";
LOOTSTER_ROLL_DKPPREFIX = "a DKP";
LOOTSTER_ROLL_TIERPREFIX = "a Tier";
LOOTSTER_ROLL_MODIFIEDROLLPREFIX = "a Roll Modified";
LOOTSTER_ROLL_MODIFIEDDKPPREFIX = "a DKP Modified";
LOOTSTER_ROLL_PRPREFIX = "a PR"
LOOTSTER_ROLL_INFOSEP = " ";
LOOTSTER_ROLL_INFOPREFIX = " (";
LOOTSTER_ROLL_INFOSUFFIX = ")";
LOOTSTER_ROLL_DKPINFO = "DKP %+0.3f";
LOOTSTER_ROLL_PRINFO = "PR %0.3f";
LOOTSTER_ROLL_TIERINFO = "Tier %d";

LOOTSTER_PRIORITY_SEP = "/";
LOOTSTER_PRIORITY_PREFIX = "";
LOOTSTER_PRIORITY_SUFFIX = "";

LOOTSTER_TELL_ACKROLL = "roll acknowledge"
LOOTSTER_TELL_ACKNOINFO = "DKP information on roll call"
LOOTSTER_TELL_ACKNOCALL = "no call for roll"
LOOTSTER_TELL_ACKNOROLL = "yet to roll roll command"
LOOTSTER_TELL_ACKNOADJ = "adjustment tracking change command"
LOOTSTER_TELL_ACKNOHELP = "help on bad whisper command"

LOOTSTER_CMD_RESETUI = "resetui";
LOOTSTER_CMD_PASS = "pass";
LOOTSTER_CMD_RECLAIM = "reclaim";
LOOTSTER_CMD_LOOT = "loot";
LOOTSTER_CMD_ATT = "att";
LOOTSTER_CMD_ADJ = "adj";
LOOTSTER_CMD_DKP = "dkp";
LOOTSTER_CMD_MOB = "mob";
LOOTSTER_CMD_ITEM = "item";
LOOTSTER_CMD_TELL = "tell";
LOOTSTER_CMD_HERE = "here";
LOOTSTER_CMD_PATTERN = "(%w+)";

LOOTSTER_SUBCMD_HELP = "help";
LOOTSTER_SUBCMD_ROLL = "roll";
LOOTSTER_SUBCMD_NOINFO = "noinfo";
LOOTSTER_SUBCMD_NOCALL = "nocall";
LOOTSTER_SUBCMD_NOROLL = "noroll";
LOOTSTER_SUBCMD_NOHELP = "nohelp";
LOOTSTER_SUBCMD_NOATT = "noatt";
LOOTSTER_SUBCMD_NOADJ = "noadj";
LOOTSTER_SUBCMD_USAGE = "usage";
LOOTSTER_SUBCMD_RULES = "rules";
LOOTSTER_SUBCMD_RESET = "reset";
LOOTSTER_SUBCMD_VERSION = "version";
LOOTSTER_SUBCMD_PATTERN = "%w+%s+(.+)";

LOOTSTER_HELP =
{
	"Lootster Commands:",
	" resetui - reset all Lootster window positions",
	"Lootster Party/Raid Chat Commands:",
	" pass - pass on roll (before or after roll)",
	" reclaim - reclaim previously passed roll",
	"Lootster Whisper Chat Commands:",
	" here - mark attendance as standby (when not in party/raid)",
	" loot help - show help instructions",
	" loot roll - show your roll command(s)",
	" loot usage - show usage rolls",
	" loot rules - show looting rules",
	" loot version - show Lootster version",
	" tell roll - toggle your roll acknowledge tells",
	" tell noinfo - toggle your Points information on roll call tells",
	" tell nocall - toggle your no call for roll tells",
	" tell noroll - toggle your yet to roll roll command tells",
	" tell nohelp - toggle your bad Lootster whisper command help tells",
	" tell noatt - toggle your attendance tracking change tells",
	" tell noadj - toggle your adjustment tracking change tells",
	" tell reset - reset all tells toggles"
};

LOOTSTER_HELPDKP =
{
	" att - show your DKP attendances",
	" att <name> - show DKP attendances for matching players",
	" att <class> - show DKP attendances for players of class",
	" adj - show your DKP adjustments",
	" adj <name> - show DKP adjustments for matching players",
	" adj <class> - show DKP adjustments for players of class",
	" dkp - show your current/adjustment DKP",
	" dkp <name> - show DKP for matching players",
	" dkp <class> - show DKP for players of class",
	" mob <name> - show DKP for items dropped by matching mobs",
	" item <name> - show DKP value of matching items"
};

LOOTSTER_HELPEPGP =
{
	" att - show your EP attendances",
	" att <name> - show EP attendances for matching players",
	" att <class> - show EP attendances for players of class",
	" adj - show your EP/GP adjustment",
	" adj <name> - show EP/GP adjustments for matching players",
	" adj <class> - show EP/GP adjustments for players of class",
	" epgp - show your current/adjustment EP/GP",
	" epgp <name> - show EP/GP for matching players",
	" epgp <class> - show EP/GP for players of class",
	" mob <name> - show GP for items dropped by matching mobs",
	" item <name> - show GP value of matching items"
};

LOOTSTER_RULES =
{
};

LOOTSTER_CLASS =
{
	["DRUID"]		= { Mask=0x0001, Singular="Druid", Plural="Druids" },
	["HUNTER"]		= { Mask=0x0002, Singular="Hunter", Plural="Hunters" },
	["MAGE"]		= { Mask=0x0004, Singular="Mage", Plural="Mages" },
	["PALADIN"]		= { Mask=0x0008, Singular="Paladin", Plural="Paladins" },
	["PRIEST"]		= { Mask=0x0010, Singular="Priest", Plural="Priests" },
	["ROGUE"]		= { Mask=0x0020, Singular="Rogue", Plural="Rogues" },
	["SHAMAN"]		= { Mask=0x0040, Singular="Shaman", Plural="Shamans" },
	["WARLOCK"]		= { Mask=0x0080, Singular="Warlock", Plural="Warlocks" },
	["WARRIOR"]		= { Mask=0x0100, Singular="Warrior", Plural="Warriors" },
	["DEATHKNIGHT"]	= { Mask=0x0200, Singular="Death Knight", Plural="Death Knights" },
	["MONK"]		= { Mask=0x0400, Singular="Monk", Plural="Monks" }
};

LOOTSTER_CLASS_SORT =
{
	"DEATHKNIGHT",
	"DRUID",
	"HUNTER",
	"MAGE",
	"MONK",
	"PALADIN",
	"PRIEST",
	"ROGUE",
	"SHAMAN",
	"WARLOCK",
	"WARRIOR"
};

LOOTSTER_BOSS_NAME = 
{
	[34702]	= "Alliance Champions",
	[34467]	= "Alliance Crusaders",
	[37540]	= "Alliance Gunship Battle",
	[43735]	= "Ascendant Council",
	[32927]	= "Assembly of Iron",
	[37972]	= "Blood Princes",
	[45870]	= "Conclave of Wind",
	[24201]	= "Constructor & Controller",
	[42166]	= "Omnotron Defense System",
	[16060] = "Gothik the Harvester",
	[35617]	= "Horde Champions",
	[34451]	= "Horde Crusaders",
	[37215]	= "Horde Gunship Battle",
	[36477]	= "Krick and Ick",
	[55419]	= "Mannoroth and Captain Varo'then",
	[17537]	= "Nazan & Vazruden",
	[11583] = "Nefarian",
	[35144] = "Northrend Beasts",
	[60583]	= "Protectors of the Endless",
	[23418]	= "Reliquary of Souls",
	[17533]	= "Romulo & Julianne",
	[15928] = "Thaddius",
	[21684]	= "The Chess Event",
	[30549]	= "The Four Horsemen",
	[22949]	= "The Illidari Council",
	[15511]	= "The Three Bugs",
	[61429]	= "The Spirit Kings",
	[60047]	= "The Stone Guard",
	[61442]	= "Trial of the King",
	[28234]	= "Tribunal of Ages",
	[15276]	= "Twin Emperors",
	[34496]	= "Twin Val'kyr",
	[45992]	= "Valiona and Theralion",
	[60400]	= "Will of the Emperor",
	[18168]	= "Wizard of Oz"
};

LOOTSTER_YELL_BOSS_START = 
{
	["Brann Bronzebeard"]			= { BOSSID=28234, MSG="Now keep an eye out! I'll have this licked in two shakes of a--" },
	["High Overlord Saurfang"]		= { BOSSID=37215, MSG="Rise up, sons and daughters of the Horde! Today we battle a hated enemy of the Horde! LOK'TAR OGAR! Kor'kron, take us out!" },
	["Muradin Bronzebeard"]			= { BOSSID=37540, MSG="Fire up the engines! We got a meetin' with destiny, lads!" },
	["The Lich King"]				= { BOSSID=37226, MSG="There is no escape!" },
	["Valithria Dreamwalker"]		= { BOSSID=36789, MSG="Heroes, lend me your aid! I... I cannot hold them off much longer! You must heal my wounds!" }
};

LOOTSTER_YELL_BOSS_FINISH = 
{
	["Abedneum"]					= "Alert! Security fail safes deactivated. Beginning memory purge...",
	["Argent Confessor Paletress"]	= "Excellent work!",
	["Eadric the Pure"]				= "I yield! I submit. Excellent work. May I run away now?",
	["Freya"]						= "His hold on me dissipates. I can see clearly once more. Thank you, heroes.",
	["High Overlord Saurfang"]		= "The Alliance falter. Onward to the Lich King!",
	["Hodir"]						= "I... I am released from his grasp... at last.",
	["Lady Jaina Proudmoore"]		= "We now know what must be done. I will deliver this news to King Varian and Highlord Fordring.",
	["Lady Sylvanas Windrunner"]	= "We are safe, for now. His strength has increased ten-fold since our last battle! It will take a mighty army to destroy the Lich King, an army greater than even the Horde can rouse.",
	["Majordomo Executus"]			= "Impossible! Stay your attack, mortals... I submit! I submit!",
	["Mal'Ganis"]					= "Your journey has just begun, young prince. Gather your forces, and meet me in the arctic land of Northrend. It is there we shall settle the score between us. It is there that your true destiny will unfold.",
	["Muradin Bronzebeard"]			= "Don't say I d1278idn't warn ya, scoundrels! Onward, brothers and sisters!",
	["Sky-Captain Justin Bartlett"]	= "Fire! FIRE!",
	["Sky-Reaver Korm Blackscar"]	= "Fire! FIRE!",
	["Thorim"]						= "Stay your arms! I yield!",
	["Valithria Dreamwalker"]		= "I am renewed! Ysera grants me the favor to lay these foul creatures to rest!"
};


if		(GetLocale() == "frFR") then
	-- French Localization:
	LOOTSTER_LANG_COMMON = "Commun";
	LOOTSTER_LANG_ORCISH = "Orc";
	
	BINDING_HEADER_LOOTSTER = "Lootster";
	BINDING_NAME_LOOTSTER_TOGGLE = "Afficher/Cacher la fen\195\170tre";

	LOOTSTER_ROLL_PATTERN = "(%S+) obtient un (%d+) %((%d+)%-(%d+)%)"

	LOOTSTER_CLASS =
	{
		["DRUID"]		= { Mask=0x0001, Singular="Druide", Plural="Druides" },
		["HUNTER"]		= { Mask=0x0002, Singular="Chasseur", Plural="Chasseurs" },
		["MAGE"]		= { Mask=0x0004, Singular="Mage", Plural="Mages" },
		["PALADIN"]		= { Mask=0x0008, Singular="Paladin", Plural="Paladins" },
		["PRIEST"]		= { Mask=0x0010, Singular="Pr\195\170tre", Plural="Pr\195\170tres" },
		["ROGUE"]		= { Mask=0x0020, Singular="Voleur", Plural="Voleurs" },
		["SHAMAN"]		= { Mask=0x0040, Singular="Shaman", Plural="Shamans" },
		["WARLOCK"]		= { Mask=0x0080, Singular="D\195\169moniste", Plural="D\195\169monistes" },
		["WARRIOR"]		= { Mask=0x0100, Singular="Guerrier", Plural="Guerriers" },
		["DEATHKNIGHT"]	= { Mask=0x0200, Singular="Knight Mort", Plural="Chevaliers de Mort" },
		["MONK"]		= { Mask=0x0400, Singular="Moine", Plural="Moines" },
	};

	LOOTSTER_CLASS_SORT =
	{
		"HUNTER",
		"WARLOCK",
		"DRUID",
		"WARRIOR",
		"DEATHKNIGHT",
		"MAGE",
		"MONK",
		"PALADIN",
		"PRIEST",
		"SHAMAN",
		"ROGUE"
	};
elseif	(GetLocale() == "deDE") then
	-- German Localization:
	LOOTSTER_LANG_COMMON = "Gemeinsprache";
	LOOTSTER_LANG_ORCISH = "Orcisch";

	LOOTSTER_ROLL_PATTERN = "(%S+) w\195\188rfelt. Ergebnis: (%d+) %((%d+)%-(%d+)%)"
elseif	((GetLocale() == "esES") or (GetLocale() == "esMX")) then
	-- Spanish Localization:
	LOOTSTER_LANG_COMMON = "Com\195\186n";
	LOOTSTER_LANG_ORCISH = "Orco";

	LOOTSTER_TOGGLE_ON = "Encendido";
	LOOTSTER_TOGGLE_OFF = "Apagado";
	
	BINDING_NAME_LOOTSTER_TOGGLE = "Mostrar/Ocultar ventana";
	BINDING_NAME_LOOTSTER_TOGGLE_DESC = "Alterna la visibilidad de la ventana de Lootster";
	
	LOOTSTER_ROLL_PATTERN = "(%S+) tira los dados y obtiene (%d+) %((%d+)%-(%d+)%)"

	LOOTSTER_ROLL_NEEDROLL = "NECESIDAD";
	LOOTSTER_ROLL_NEEDROLL_TT = "Llamar a tiradas por NECESIDAD";
	LOOTSTER_ROLL_GREEDROLL = "CODICIA";
	LOOTSTER_ROLL_GREEDROLL_TT = "Llamar a tiradas por CODICIA";
	LOOTSTER_ROLL_1001000ROLL = "100/1000";
	LOOTSTER_ROLL_1001000ROLL_TT = "Llamar a tiradas 100/1000";
	LOOTSTER_ROLL_FREEFORALLROLL = "Tirada Libre";
	LOOTSTER_ROLL_FREEFORALLROLL_TT = "Llamar a tiradas Libre-Para-Todos";

	LOOTSTER_NBG_NEED = "NECESIDAD";
	LOOTSTER_NBG_GREED = "CODICIA";
	LOOTSTER_NBG_1001000 = "NECESIDAD (100) / CODICIA (1000)";
	LOOTSTER_NBG_FREEFORALL = "LIBRE-PARA-TODOS";
	LOOTSTER_NBG_USAGE = "USO";
	LOOTSTER_NBG_TIED = "EMPATE";
	LOOTSTER_NBG_PASSIVE = "PASIVO";

	LOOTSTER_MSG_LOAD = "Lootster v%s cargado";
	LOOTSTER_MSG_NBG = "%s tira dados por %s";
	LOOTSTER_MSG_NBG_LINK = "%s tira dados en la modalidad %s por %s";
	LOOTSTER_MSG_NBG_TIED = "%s, por favor tira dados por %s usando /dados 100";
	LOOTSTER_MSG_NBG_TIED_LINK = "%s, por favor tira dados por %s usando /dados 100";
	LOOTSTER_MSG_PLEASE = "Por favor";
	LOOTSTER_MSG_PLEASE_CLASS = "%s, por favor";
	LOOTSTER_MSG_PLEASE_USAGECLASS = "%s solo pueden tirar dados los %s, por favor";
	LOOTSTER_MSG_ASKN = "Por favor tira dados por %s usando /dados %d";
	LOOTSTER_MSG_ASKN_LINK = "Por favor tira dados por %s en %s usando /dados %d";
	LOOTSTER_MSG_ASK100 = "Por favor tira dados por %s usando /dados 100";
	LOOTSTER_MSG_ASK100_LINK = "Por favor tira dados por %s en %s usando /dados 100";
	LOOTSTER_MSG_ASK1000 = "Por favor tira dados por %s usando /dados 100 (Necesidad) o /dados 1000 (Codicia)";
	LOOTSTER_MSG_ASK1000_LINK = "Por favor tira dados por %s en %s usando /dados 100 (Necesidad) o /dados 1000 (Codicia)";
	LOOTSTER_MSG_DUP = "\194\161 Tu tirada de %s (%s-%s) est\195\161 duplicada (la primera fue de %d) !";
	LOOTSTER_MSG_REJECT = "\194\161 Tu tirada de %s (%s-%s) tiene un rango incorrecto !";
	LOOTSTER_MSG_ACKROLL = "Recibida tu tirada de %s (%s-%s). \194\161 Buena suerte !";
	LOOTSTER_MSG_NONBGSELF = "\194\161 El jugador %s ha tirado dados sin ser el momento para ello !";
	LOOTSTER_MSG_NONBGPLAYER = "\194\161 No se ha hecho ning\195\186n llamamiento para tirar dados ! \194\161 Habla con %s si es urgente !";
	LOOTSTER_MSG_NOTROLLCLASS = "Tu tirada de %s (%s-%s) ha sido ignorada porque no eres un %s";
	LOOTSTER_MSG_NOTTIEDSELF = "\194\161 El jugador %s hizo una tirada de desempate sin ser uno de los que empataron !";
	LOOTSTER_MSG_NOTTIEDPLAYER = "\194\161 Tu tirada de desempate ha sido ignorada porque t\195\186 no fuiste de los que empataron !";
	LOOTSTER_MSG_LAGGARD1 = "\194\161 %s a\195\186n no ha tirado dados !";
	LOOTSTER_MSG_LAGGARDN = "\194\161 %s a\195\186n no han tirado dados !";
	LOOTSTER_MSG_LAGGARD1_LINK = "\194\161 %s a\195\186n no ha tirado dados por %s !";
	LOOTSTER_MSG_LAGGARDN_LINK = "\194\161 %s a\195\186n no han tirado dados por %s !";
	LOOTSTER_MSG_COUNTDOWN = "Cuenta atr\195\161s para las tiradas por %s en %d segundos...";
	LOOTSTER_MSG_COUNTDOWN_LINK = "Cuenta atr\195\161s de %s para las tiradas por %s en %d segundos...";
	LOOTSTER_MSG_COUNTDOWNTIC = "%d";
	LOOTSTER_MSG_TIED = "\194\161 %s ha empatado con %s con una tirada de %s !";
	LOOTSTER_MSG_TIED_LINK = "\194\161 %s ha empatado por %s con %s con una tirada de %s !";
	LOOTSTER_MSG_ANNOUNCE = "\194\161 %s ha ganado %s con una tirada de %s !";
	LOOTSTER_MSG_ANNOUNCE_LINK = "\194\161 %s ha ganado %s %s con una tirada de %s !";
	LOOTSTER_ROLL_PREFIX = "";
	LOOTSTER_MSG_SEP = ", ";
	LOOTSTER_MSG_OR = " o ";
	LOOTSTER_MSG_AND = " y ";
	LOOTSTER_MSG_TYPE1001000 = "100 y 1000";
	LOOTSTER_MSG_TYPENEEDGREED = "Tirada de Necesidad antes que Codicia";
	LOOTSTER_MSG_TYPEFREEFORALL = "Tirada Libre para Todos";
	LOOTSTER_MSG_HOLDROLL = "\194\161 Tirada de %s bloqueada !";
	LOOTSTER_MSG_ALLOWROLL = "\194\161 Tirada de %s permitida !";

	LOOTSTER_CLASS =
	{
		["DRUID"]		= { Mask=0x0001, Singular="Druida", Plural="Druidas" },
		["HUNTER"]		= { Mask=0x0002, Singular="Cazador", Plural="Cazadores" },
		["MAGE"]		= { Mask=0x0004, Singular="Mago", Plural="Magos" },
		["PALADIN"]		= { Mask=0x0008, Singular="Palad\195\173n", Plural="Paladines" },
		["PRIEST"]		= { Mask=0x0010, Singular="Sacerdote", Plural="Sacerdote" },
		["ROGUE"]		= { Mask=0x0020, Singular="P\195\173caro", Plural="P\195\173caros" },
		["SHAMAN"]		= { Mask=0x0040, Singular="Cham\195\161n", Plural="Chamanes" },
		["WARLOCK"]		= { Mask=0x0080, Singular="Brujo", Plural="Brujos" },
		["WARRIOR"]		= { Mask=0x0100, Singular="Guerrero", Plural="Guerreros" },
		["DEATHKNIGHT"]	= { Mask=0x0200, Singular="Caballero de la Muerte", Plural="Caballeros de la Muerte" },
		["MONK"]		= { Mask=0x0400, Singular="Monje", Plural="Monjes" },
	};

	LOOTSTER_CLASS_SORT =
	{
		"WARLOCK",
		"DEATHKNIGHT",
		"HUNTER",
		"SHAMAN",
		"DRUID",
		"WARRIOR",
		"MAGE",
		"MONK",
		"PALADIN",
		"ROGUE",
		"PRIEST"
	};
end
