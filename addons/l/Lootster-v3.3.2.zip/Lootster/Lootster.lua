-- Lootster
--
-- Created by Mackenz, Server: Dragonblight
--
-- Acknowledgements to the following people from whom I snaffled code or provided translations:
--
-- Sardonic, LootHog
-- CodeMoose, DepositBox
-- Morok (sargeras), French Translation

-- Constant (non-localised) Data
--
-- Scoll line count and height
LOOTSTER_ROLL_LINES			= 12;

LOOTSTER_DATADKP_LINES		= 6;
LOOTSTER_DATAATTEND_LINES	= 4;
LOOTSTER_DATAADJUST_LINES	= 4;

LOOTSTER_LOOT_LINES			= 16;

LOOTSTER_RAIDRAID_LINES		= 4;
LOOTSTER_RAIDBOSS_LINES		= 4;
LOOTSTER_BOSSATTEND_LINES	= 6;
LOOTSTER_BOSSADJUST_LINES	= 6;
LOOTSTER_BOSSASSIGN_LINES	= 6;

LOOTSTER_OPTIONITEM_LINES	= 16;
LOOTSTER_OPTIONRANK_LINES	= 10;
LOOTSTER_OPTIONUSAGE_LINES	= 11;
LOOTSTER_OPTIONEVENT_LINES	= 6;
LOOTSTER_OPTIONQUALITY_LINES= 4;
LOOTSTER_OPTIONSLOT_LINES	= 6;

LOOTSTER_RAIDADJUST_LINES	= 4;

LOOTSTER_FRAME_HEIGHT		= 16;

-- Option Tabs
LOOTSTER_OPTION_TABS		= 6;

-- Version
LOOTSTER_VERSION			= GetAddOnMetadata("Lootster", "Version");

-- Enumerated Constants
LOOTSTER_ENUM_EVENTSTATE	= { LOAD=1, LOGIN=2, ENTER=3 };

LOOTSTER_ENUM_RAIDWARN		= { ALL=1, CALL=2 };

LOOTSTER_ENUM_MEMBER		= { NONE=1, FULL=2, TRIAL=3, APP=4 };

LOOTSTER_ENUM_TOON			= { NONE=1, MAIN=2, ALT=3 };

LOOTSTER_ENUM_RANK			= { FULL=1, TRIAL=2, APP=3, ALT=4 };

LOOTSTER_ENUM_NBG			= { NEED=1, GREED=2 };

LOOTSTER_ENUM_IDTYPE		= { RAID="R", BOSS="B", ATTEND="T", ADJUST="D", NATIVE="" };

LOOTSTER_ENUM_RAIDTYPE		= { UNKNOWN=1, DUNGEONNORM=2, DUNGEONHERO=3, RAID10NORM=4, RAID10HERO=5, RAID25RF=6, RAID25NORM=7, RAID25HERO=8, OUTDOOR=9 };

LOOTSTER_ENUM_BOSSTYPE		= { RAIDSTART=1, RAIDFINISH=2, BOSSATTEMPT=3, BOSSKILL=4, BOSSWIPE=5, BONUSAWARD=6, BONUSTIME=7 };

LOOTSTER_ENUM_DKPLOOTTYPE	= { NONE=1, OFFICIAL=2, OVERRIDE=3, PROVISORY=4 };

LOOTSTER_ENUM_ATTENDED		= { FULL=1, PARTIAL=2, STANDBY=3, NOTATALL=4 };

LOOTSTER_ENUM_TOBEASSIGNED	= { BOOKED=1, LOOTED=2, MATCHED=nil };

LOOTSTER_ENUM_VIEWRAID		= { BYATTEND=1, BYADJUST=2, BYASSIGN=3 };		

LOOTSTER_ENUM_ROLLMODE		= { USEDKP=1, USENORM=2 };

LOOTSTER_ENUM_DKP			= { BYDKP=1, BYTIER=2, BYMODIFIEDROLL=3, BYMODIFIEDDKP=4, BYEPGP=5 };
LOOTSTER_ENUM_NORM			= { BY1001000=1, BYNEEDGREED=2, BYFREEFORALL=3 };

LOOTSTER_ENUM_TRACKBY		= { RAID=1, RAIDNBOSS=2 };

LOOTSTER_ENUM_LOOTMODE		= { UNKNOWN=-1, POOR=0, COMMON=1, UNCOMMON=2, RARE=3, EPIC=4, LEGENDARY=5 };
LOOTSTER_ENUM_LOOTMETHOD	= { FREEFORALL=1, ROUNDROBIN=2, MASTER=3, GROUP=4, NEEDBEFOREGREED=5 };

LOOTSTER_ENUM_DKPVALUE		= { EARNT=1, SPENT=2 };

LOOTSTER_ENUM_USAGE			= { MANUAL=0, CALLED=1, MAINNEED=2, OFFNEED=3, MAINGREED=4, OFFGREED=5, ALTBOE=6, BANKBOE=7, MAINSHARD=8, OFFSHARD=9, BANKSHARD=10, GREED=11 };
LOOTSTER_ENUM_USAGEBY		= { SEPARATE=1, SINGLE=2 };
LOOTSTER_ENUM_USAGECOST		= { VALUE=1, FACTOR=2 };

LOOTSTER_ENUM_EVENT			= { RAIDSTART=1, RAIDFINISH=2, BOSSKILL=3, BOSSWIPE=4, BONUSAWARD=5, BONUSTIME=6 };

LOOTSTER_ENUM_SLOTFACTOR	= { SFACTOR1=1, SFACTOR2=2, SFACTOR3=3, SFACTOR4=4, SFACTOR5=5, SFACTOR6=6, SFACTOR7=7 };

LOOTSTER_ENUM_SCHEDULERID	= { ZONE=1, REGEN=2, BONUSTIME=3 };

LOOTSTER_MASK_REPORTTYPE	= { FULL=0x0001, RAID=0x0002, BOSS=0x0004, SELTEXT=0x8000, SHOWSORT=0x4000, SHOWDETAIL=0x2000, MASKIN=0x0007, MASKOUT=0xfff8 };

-- Horde/Alliance Only Classes
LOOTSTER_CLASS_ALLIANCE		= { };
LOOTSTER_CLASS_HORDE		= { };

-- Unknown Tier
LOOTSTER_TIER_UNKNOWN		= 99999;

-- Pre-Defined Member Ranks
LOOTSTER_RANK_GM			=  0;
LOOTSTER_RANK_NONMAIN		= -1;
LOOTSTER_RANK_NONGUILD		= -2;

-- WoW Version/TOC Formats
LOOTSTER_VERSION_WOW		= "^(%d+)%.(%d+)%.(%d+)$";
LOOTSTER_VERSION_TOC		= "%d%02d%02d";

-- Text Encoding/Decoding Strings
LOOTSTER_ENC_ORBAR_RAW		= "|";
LOOTSTER_ENC_ORBAR_ENC		= LOOTSTER_ENC_ORBAR_RAW..LOOTSTER_ENC_ORBAR_RAW;
LOOTSTER_ENC_MARKER_RAW		= "#";
LOOTSTER_ENC_MARKER_ENC		= LOOTSTER_ENC_MARKER_RAW..LOOTSTER_ENC_MARKER_RAW;
LOOTSTER_ENC_NEWLINE_RAW	= "\\\n";
LOOTSTER_ENC_NEWLINE_ENC	= " "..LOOTSTER_ENC_MARKER_RAW.." ";
LOOTSTER_ENC_QUOTESLASH_RAW	= "\"/";
LOOTSTER_ENC_QUOTESLASH_ENC	= "\""..LOOTSTER_ENC_MARKER_RAW.."/";
LOOTSTER_ENC_SLASHSLASH_ENC	= "\\";
LOOTSTER_ENC_SLASHSLASH_RAW	= "";

-- Regular Expression Encoding/Decoding Strings
LOOTSTER_ENC_REGEXP_INP		= "([().%+-*?[^$])";
LOOTSTER_ENC_REGEXP_ENC		= "%%%1";
LOOTSTER_ENC_REGEXP_DEC		= "%%([().%+-*?[^$])";
LOOTSTER_ENC_REGEXP_OUT		= "%1";

-- To/From Whisper Queue Intervals (seconds) and Initial Message Dispatch Count
LOOTSTER_TQUE_DISPATCH 		= 1.000;
LOOTSTER_TQUE_DISPATCHBIAS	= 0.100;
LOOTSTER_TQUE_DISPATCHINIT	= 4;

LOOTSTER_FQUE_CLEAR 		= 5.000;

-- Lootster Tab/Frame List
LOOTSTER_TAB_FRAME			= 

{
	{ Tab="Lootster_RollTab",		Frame="Lootster_RollFrame"		},
	{ Tab="Lootster_DataTab",		Frame="Lootster_DataFrame"		},
	{ Tab="Lootster_LootTab",		Frame="Lootster_LootFrame"		},
	{ Tab="Lootster_RaidTab",		Frame="Lootster_RaidFrame"		},
	{ Tab="Lootster_ItemTab",		Frame="Lootster_ItemFrame"		},
	{ Tab="Lootster_RuleTab",		Frame="Lootster_RuleFrame"		},
	{ Tab="Lootster_OptionsTab",	Frame="Lootster_OptionsFrame"	}
};

-- Lootster Popup Frame List
LOOTSTER_POPUP_FRAME		= 
{
	"Lootster_LootSyncFrame",
	"Lootster_ItemSyncFrame",
	"Lootster_RaidSyncFrame",
	"Lootster_RaidFrameRaidFrame",
	"Lootster_RaidFrameBossFrame",
	"Lootster_RaidFrameAttendFrame",
	"Lootster_RaidFrameAdjustFrame",
	"Lootster_RaidFrameReportFrame"
};

-- Server Time Zones
LOOTSTER_TZ_SERVER			=
{
	-- US East
	[ -5] =   0,	-- STD, same day
	[ -4] =  -1,	-- DST, same day
	[ 19] = -24,	-- STD, previous day
	[ 20] = -25,	-- DST, previous day

	-- US West
	[ -8] =   0,	-- STD, same day
	[ -7] =  -1,	-- DST, same day
	[ 16] = -24,	-- STD, previous day
	[ 17] = -25,	-- DST, previous day

	-- European
	[-23] =  24,	-- STD, following day
	[-22] =  23,	-- DST, following day
	[  1] =   0,	-- STD, same day
	[  2] =  -1,	-- DST, same day

	-- Oceanic
	[-13] =  24,	-- STD, following day
	[-12] =  23,	-- DST, following day
	[ 11] =   0,	-- STD, same day
	[ 12] =  -1,	-- DST, same day
};

-- Roll to Usage Map
LOOTSTER_USAGE_ROLL			=
{
	[1]		= LOOTSTER_ENUM_USAGE.CALLED,
	[100]	= LOOTSTER_ENUM_USAGE.MAINNEED,
	[200]	= LOOTSTER_ENUM_USAGE.OFFNEED,
	[300]	= LOOTSTER_ENUM_USAGE.MAINGREED,
	[400]	= LOOTSTER_ENUM_USAGE.OFFGREED,
	[500]	= LOOTSTER_ENUM_USAGE.ALTBOE,
	[600]	= LOOTSTER_ENUM_USAGE.BANKBOE,
	[700]	= LOOTSTER_ENUM_USAGE.MAINSHARD,
	[800]	= LOOTSTER_ENUM_USAGE.OFFSHARD,
	[900]	= LOOTSTER_ENUM_USAGE.BANKSHARD,
	[1000]	= LOOTSTER_ENUM_USAGE.GREED
};

-- Usage to be Banked Map
LOOTSTER_USAGE_BANKED			=
{
	[LOOTSTER_ENUM_USAGE.BANKBOE]	= true,
	[LOOTSTER_ENUM_USAGE.BANKSHARD]	= true
};

-- Boss Types that are Bosses Map
LOOTSTER_BOSSTYPE_BOSS		=
{
	[LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT]	= true,
	[LOOTSTER_ENUM_BOSSTYPE.BOSSKILL]		= true,
	[LOOTSTER_ENUM_BOSSTYPE.BOSSWIPE]		= true
};

-- Boss Type to Event Map
LOOTSTER_BOSSTYPE_EVENT		=
{
	[LOOTSTER_ENUM_BOSSTYPE.RAIDSTART]		= LOOTSTER_ENUM_EVENT.RAIDSTART,
	[LOOTSTER_ENUM_BOSSTYPE.RAIDFINISH]		= LOOTSTER_ENUM_EVENT.RAIDFINISH,
	[LOOTSTER_ENUM_BOSSTYPE.BOSSKILL]		= LOOTSTER_ENUM_EVENT.BOSSKILL,
	[LOOTSTER_ENUM_BOSSTYPE.BOSSWIPE]		= LOOTSTER_ENUM_EVENT.BOSSWIPE,
	[LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD]		= LOOTSTER_ENUM_EVENT.BONUSAWARD,
	[LOOTSTER_ENUM_BOSSTYPE.BONUSTIME]		= LOOTSTER_ENUM_EVENT.BONUSTIME
};

-- Item Slot Type to Factor Map
LOOTSTER_SLOT_FACTOR		=
{
	[""]						= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7,
	["INVTYPE_2HWEAPON"]		= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR1,
	["INVTYPE_AMMO"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7,
	["INVTYPE_BAG"]				= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7,
	["INVTYPE_BODY"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7,
	["INVTYPE_CHEST"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR1,
	["INVTYPE_CLOAK"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4,
	["INVTYPE_FEET"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR2,
	["INVTYPE_FINGER"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4,
	["INVTYPE_HAND"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR2,
	["INVTYPE_HEAD"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR1,
	["INVTYPE_HOLDABLE"]		= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4,
	["INVTYPE_LEGS"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR1,
	["INVTYPE_NECK"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4,
	["INVTYPE_QUIVER"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7,
	["INVTYPE_RANGED"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR6,
	["INVTYPE_RANGEDRIGHT"]		= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR6,
	["INVTYPE_RELIC"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR6,
	["INVTYPE_ROBE"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR1,
	["INVTYPE_SHIELD"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4,
	["INVTYPE_SHOULDER"]		= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR2,
	["INVTYPE_TABARD"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7,
	["INVTYPE_THROWN"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR6,
	["INVTYPE_TRINKET"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR3,
	["INVTYPE_WAIST"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR2,
	["INVTYPE_WEAPON"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR5,
	["INVTYPE_WEAPONMAINHAND"]	= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR5,
	["INVTYPE_WEAPONOFFHAND"]	= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4,
	["INVTYPE_WRIST"]			= LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4
};

-- Synchronise Message Management
LOOTSTER_SYNC_PREFIX		= "<LS>";
LOOTSTER_SYNC_PREFIXLEN		= string.len(LOOTSTER_SYNC_PREFIX);
LOOTSTER_SYNC_POSTFIXCONT	= "-";
LOOTSTER_SYNC_VERSION		= 3;
LOOTSTER_SYNC_VERSION_BASE	= 3;
LOOTSTER_SYNC_TIMEOUT		= 8.000;
LOOTSTER_SYNC_MESSAGELEN	= 255;

LOOTSTER_SYNC_CMD_SYNCLOOT	= "SYNCLOOT";
LOOTSTER_SYNC_CMD_SYNCRAID	= "SYNCRAID";
LOOTSTER_SYNC_CMD_SYNCITEM	= "SYNCITEM";

LOOTSTER_SYNC_CMD_ACK		= "ACK";
LOOTSTER_SYNC_CMD_BEGIN		= "BEGIN";
LOOTSTER_SYNC_CMD_ABORT		= "ABORT";
LOOTSTER_SYNC_CMD_COMMIT	= "COMMIT";

LOOTSTER_SYNC_CMD_LOOT		= "LOOT";

LOOTSTER_SYNC_CMD_ID		= "ID";
LOOTSTER_SYNC_CMD_RAID		= "RAID";
LOOTSTER_SYNC_CMD_BOSS		= "BOSS";
LOOTSTER_SYNC_CMD_ATTEND	= "ATTEND";
LOOTSTER_SYNC_CMD_ADJUST	= "ADJUST";
LOOTSTER_SYNC_CMD_RUNNING	= "RUNNING";

LOOTSTER_SYNC_CMD_ITEM		= "ITEM";

LOOTSTER_SYNC_EXP_SYNCLOOT	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_SYNCLOOT.."/%d/";
LOOTSTER_SYNC_EXP_SYNCRAID	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_SYNCRAID.."/%d/";
LOOTSTER_SYNC_EXP_SYNCITEM	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_SYNCITEM.."/%d/";

LOOTSTER_SYNC_EXP_ACK		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_ACK.."/";
LOOTSTER_SYNC_EXP_BEGIN		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_BEGIN.."/%d/%d/";
LOOTSTER_SYNC_EXP_ABORT		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_ABORT.."/";
LOOTSTER_SYNC_EXP_COMMIT	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_COMMIT.."/%d/";

LOOTSTER_SYNC_EXP_LOOT		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_LOOT.."/%d/%q/";

LOOTSTER_SYNC_EXP_ID		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_ID.."/%d/";
LOOTSTER_SYNC_EXP_RAID		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_RAID.."/%s/%q/";
LOOTSTER_SYNC_EXP_BOSS		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_BOSS.."/%s/%q/";
LOOTSTER_SYNC_EXP_ATTEND	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_ATTEND.."/%s/%q/";
LOOTSTER_SYNC_EXP_ADJUST	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_ADJUST.."/%s/%q/";
LOOTSTER_SYNC_EXP_RUNNING	= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_RUNNING.."/%s/%s/";

LOOTSTER_SYNC_EXP_ITEM		= LOOTSTER_SYNC_PREFIX..LOOTSTER_SYNC_CMD_ITEM.."/%s/%q/";

LOOTSTER_SYNC_IMP_PREFIX	= "^"..LOOTSTER_SYNC_PREFIX;

LOOTSTER_SYNC_IMP_PATTERN	= "^"..LOOTSTER_SYNC_PREFIX.."(.*)$";
LOOTSTER_SYNC_IMP_COMMAND	= "^(%w+)/(.*)$";

LOOTSTER_SYNC_IMP_SYNCLOOT	= "^(%d+)/$";
LOOTSTER_SYNC_IMP_SYNCRAID	= "^(%d+)/$";
LOOTSTER_SYNC_IMP_SYNCITEM	= "^(%d+)/$";

LOOTSTER_SYNC_IMP_BEGIN		= "^(%d+)/(%d+)/$";
LOOTSTER_SYNC_IMP_COMMIT	= "^(%d+)/$";

LOOTSTER_SYNC_IMP_LOOT		= "^(%d+)/\"(.+)\"/$";

LOOTSTER_SYNC_IMP_ID		= "^(%d+)/$";
LOOTSTER_SYNC_IMP_RAID		= "^(.+)/\"(.+)\"/$";
LOOTSTER_SYNC_IMP_BOSS		= "^(.+)/\"(.+)\"/$";
LOOTSTER_SYNC_IMP_ATTEND	= "^(.+)/\"(.+)\"/$";
LOOTSTER_SYNC_IMP_ADJUST	= "^(.+)/\"(.+)\"/$";
LOOTSTER_SYNC_IMP_RUNNING	= "^(.+)/(.+)/$";

LOOTSTER_SYNC_IMP_ITEM		= "^(.+)/\"(.+)\"/$";

-- Addon Message Management
LOOTSTER_ADDON_PREFIX		= "<LS>";
LOOTSTER_ADDON_PREFIXLEN	= string.len(LOOTSTER_ADDON_PREFIX);
LOOTSTER_ADDON_POSTFIXCONT	= "-";
LOOTSTER_ADDON_VERSION		= 4;
LOOTSTER_ADDON_VERSION_BASE	= 4;
LOOTSTER_ADDON_MESSAGELEN	= 254 - LOOTSTER_ADDON_PREFIXLEN;

LOOTSTER_ADDON_CMD_CALLROLL	= "CALLROLL";
LOOTSTER_ADDON_CMD_HOLDROLL	= "HOLDROLL";

LOOTSTER_ADDON_CMD_BEGIN	= "BEGIN";
LOOTSTER_ADDON_CMD_COMMIT	= "COMMIT";

LOOTSTER_ADDON_CMD_MODE		= "MODE";
LOOTSTER_ADDON_CMD_EARN		= "EARN";
LOOTSTER_ADDON_CMD_CAPS		= "CAPS";
LOOTSTER_ADDON_CMD_FCTR		= "FCTR";
LOOTSTER_ADDON_CMD_EPGP		= "EPGP";
LOOTSTER_ADDON_CMD_ROLL		= "ROLL";
LOOTSTER_ADDON_CMD_TIED		= "TIED";
LOOTSTER_ADDON_CMD_CLASS	= "CLASS";
LOOTSTER_ADDON_CMD_USAGE	= "USAGE";
LOOTSTER_ADDON_CMD_EVENTS	= "EVENTS";
LOOTSTER_ADDON_CMD_POINTS	= "POINTS";

LOOTSTER_ADDON_EXP_CALLROLL	= LOOTSTER_ADDON_CMD_CALLROLL.."/%d/";
LOOTSTER_ADDON_EXP_HOLDROLL	= LOOTSTER_ADDON_CMD_HOLDROLL.."/%d/%s/%s/";

LOOTSTER_ADDON_EXP_BEGIN	= LOOTSTER_ADDON_CMD_BEGIN.."/%d/%d/";
LOOTSTER_ADDON_EXP_COMMIT	= LOOTSTER_ADDON_CMD_COMMIT.."/%d/";

LOOTSTER_ADDON_EXP_MODE		= LOOTSTER_ADDON_CMD_MODE.."/%d/%d/%s/%s/%s/%s/%s/%s/%q/";
LOOTSTER_ADDON_EXP_EARN		= LOOTSTER_ADDON_CMD_EARN.."/%s/";
LOOTSTER_ADDON_EXP_CAPS		= LOOTSTER_ADDON_CMD_CAPS.."/%d/%d/";
LOOTSTER_ADDON_EXP_FCTR		= LOOTSTER_ADDON_CMD_FCTR.."/%d/";
LOOTSTER_ADDON_EXP_EPGP		= LOOTSTER_ADDON_CMD_EPGP.."/%s/%d/%s/%d/";
LOOTSTER_ADDON_EXP_ROLL		= LOOTSTER_ADDON_CMD_ROLL.."/%s/%d/%s/";
LOOTSTER_ADDON_EXP_TIED		= LOOTSTER_ADDON_CMD_TIED.."/%q/%q/";
LOOTSTER_ADDON_EXP_CLASS	= LOOTSTER_ADDON_CMD_CLASS.."/%d/%d/%q/";
LOOTSTER_ADDON_EXP_USAGE	= LOOTSTER_ADDON_CMD_USAGE.."/%q/%q/";
LOOTSTER_ADDON_EXP_EVENTS	= LOOTSTER_ADDON_CMD_EVENTS.."/%q/";
LOOTSTER_ADDON_EXP_POINTS	= LOOTSTER_ADDON_CMD_POINTS.."/%f/%q/%q/";

LOOTSTER_ADDON_IMP_COMMAND	= "^(%w+)/(.*)$";

LOOTSTER_ADDON_IMP_CALLROLL	= "^(%d+)/$";
LOOTSTER_ADDON_IMP_HOLDROLL	= "^(%d+)/(.+)/(.+)/$";

LOOTSTER_ADDON_IMP_BEGIN	= "^(%d+)/(%d+)/$";
LOOTSTER_ADDON_IMP_COMMIT	= "^(%d+)/$";

LOOTSTER_ADDON_IMP_MODE		= "^(%d+)/(%d+)/(.+)/(.+)/(.+)/(.+)/(.+)/(.+)/\"(.*)\"/$";
LOOTSTER_ADDON_IMP_EARN		= "^(.+)/$";
LOOTSTER_ADDON_IMP_CAPS		= "^(%d+)/(%d+)/$";
LOOTSTER_ADDON_IMP_FCTR		= "^(%d+)/$";
LOOTSTER_ADDON_IMP_EPGP		= "^(.+)/(%d+)/(.+)/(%d+)/$";
LOOTSTER_ADDON_IMP_ROLL		= "^(.+)/(%d+)/(.*)/$";
LOOTSTER_ADDON_IMP_TIED		= "^\"(.*)\"/\"(.*)\"/$";
LOOTSTER_ADDON_IMP_CLASS	= "^(%d+)/(%d+)/\"(.*)\"/$";
LOOTSTER_ADDON_IMP_USAGE	= "^\"(.*)\"/\"(.*)\"/$";
LOOTSTER_ADDON_IMP_EVENTS	= "^\"(.*)\"/$";
LOOTSTER_ADDON_IMP_POINTS	= "^([%d%.]+)/\"(.*)\"/\"(.*)\"/$";

-- Combat Log Reaction
local	COMBATLOG_OBJECT_REACTION_NEUTRAL		= COMBATLOG_OBJECT_REACTION_NEUTRAL		or 0x00000020
local	COMBATLOG_OBJECT_REACTION_HOSTILE		= COMBATLOG_OBJECT_REACTION_HOSTILE		or 0x00000040
local	COMBATLOG_OBJECT_REACTION_COMBATIVE		= bit.bor(COMBATLOG_OBJECT_REACTION_NEUTRAL, COMBATLOG_OBJECT_REACTION_HOSTILE);

-- Saved Variables
Lootster_Options			= {};

Lootster_Options_Default	=
{
	Active				= false;
	Passive				= false;
	MiniMap				= true;
	MiniMapPos			= 270;
	Suppress			= false;
	RWRoll				= false;
	RWRollBy			= LOOTSTER_ENUM_RAIDWARN.CALL;
	AckRoll				= true;
	AckNoInfo			= true;
	AckNoCall			= true;
	AckNoRoll			= true;
	AckNoHelp			= false;
	AckNoRaid			= true;
	AckNoBoss			= true;
	AckNoAtt			= true;
	AckNoAdj			= true;
	Counter				= true;
	CounterSec			= 5;
	AutoSnoop			= true;
	DebugMsgs			= false;
	EchoRestrict		= true;
	EchoToChat			= true;
	EchoToRW			= true;
	EchoByClick			= true;
	EchoByGroupLoot		= true;
	RollMode			= LOOTSTER_ENUM_ROLLMODE.USENORM;
	DKPType				= LOOTSTER_ENUM_DKP.BYTIER;
	DKPMember			= false;
	DKPToon				= false;
	DKPGreedFFA			= false;
	DKPFactoring		= false;
	DKPFactor			= 1;
	RollFactoring		= false;
	RollFactor			= 1;
	DKPAttEarnt			= false;
	DKPCaps				= true;
	DKPHi				= 50;
	DKPLo				= 50;
	EPMin				= false;
	EPMinEP				= 1000;
	GPBase				= false;
	GPBaseGP			= 1000;
	NormType			= LOOTSTER_ENUM_NORM.BYNEEDGREED;
	NormMember			= false;
	NormToon			= false;
	NormGreedFFA		= false;
	NormAutoRoll		= false;
	NormAutoOpen		= false;
	NormAutoClose		= false;
	Track				= {
							[LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM]	= false,
							[LOOTSTER_ENUM_RAIDTYPE.DUNGEONHERO]	= false, 
							[LOOTSTER_ENUM_RAIDTYPE.RAID10NORM]		= true, 
							[LOOTSTER_ENUM_RAIDTYPE.RAID10HERO]		= true, 
							[LOOTSTER_ENUM_RAIDTYPE.RAID25RF]		= true, 
							[LOOTSTER_ENUM_RAIDTYPE.RAID25NORM]		= true, 
							[LOOTSTER_ENUM_RAIDTYPE.RAID25HERO]		= true, 
							[LOOTSTER_ENUM_RAIDTYPE.OUTDOOR]		= true
						  };
	TrackBy				= LOOTSTER_ENUM_TRACKBY.RAID;
	AutoRaid			= false;
	AutoBoss			= false;
	RaidIcon			= false;
	BossIcon			= false;
	AttendHere			= false;
	AttendAnnounce		= false;
	AttendGroup			= false;
	AttendGuild			= false;
	AttendCustom		= false;
	AttendCustomChannel	= nil;
	LootMode			= LOOTSTER_ENUM_LOOTMODE.UNCOMMON;
	AutoDKPLoot			= false;
	AutoNonDKPLoot		= false;
	AutoLootRaid		= false;
	RankMembers			= {};
	NoteToons			= {};
	RankToons			= {};
	RankAltPrefix		= {};
	RankAltSuffix		= {};
	Ranks				= {};
	UsageRolls			= false;
	UsageBy				= LOOTSTER_ENUM_USAGEBY.SINGLE;
	Banker				= nil;
	Usage				= {
							[LOOTSTER_ENUM_USAGE.CALLED]		= { Use=false, Priority=1, Restrict=true, Roll=1, aFactor=1.000, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=1.000, Wins=true, WinsPerRaid=1 },
							[LOOTSTER_ENUM_USAGE.MAINNEED]		= { Use=true, Priority=2, Restrict=true, Roll=100, aFactor=0.500, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=1.000, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.OFFNEED]		= { Use=true, Priority=3, Restrict=true, Roll=200, aFactor=0.500, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=0.500, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.MAINGREED]		= { Use=false, Priority=4, Restrict=true, Roll=300, aFactor=0.500, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=1.000, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.OFFGREED]		= { Use=false, Priority=5, Restrict=true, Roll=400, aFactor=0.500, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=0.500, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.ALTBOE]		= { Use=true, Priority=6, Restrict=false, Roll=500, aFactor=1.000, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=0.500, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.BANKBOE]		= { Use=true, Priority=7, Restrict=false, Roll=600, aFactor=1.000, Cost=LOOTSTER_ENUM_USAGECOST.FACTOR, cValue=0.000, cFactor=1.000, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.MAINSHARD]		= { Use=false, Priority=8, Restrict=false, Roll=700, aFactor=0.500, Cost=LOOTSTER_ENUM_USAGECOST.VALUE, cValue=10.000, cFactor=0.000, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.OFFSHARD]		= { Use=false, Priority=9, Restrict=false, Roll=800, aFactor=0.500, Cost=LOOTSTER_ENUM_USAGECOST.VALUE, cValue=10.000, cFactor=0.000, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.BANKSHARD]		= { Use=true, Priority=10, Restrict=false, Roll=900, aFactor=1.000, Cost=LOOTSTER_ENUM_USAGECOST.VALUE, cValue=10.000, cFactor=0.000, Wins=false, WinsPerRaid=0 },
							[LOOTSTER_ENUM_USAGE.GREED]			= { Use=true, Priority=11, Restrict=false, Roll=1000, aFactor=1.000, Cost=LOOTSTER_ENUM_USAGECOST.VALUE, cValue=0.000, cFactor=0.000, Wins=false, WinsPerRaid=0 }
						  };
	UsageSort			= {
							[1]									= LOOTSTER_ENUM_USAGE.CALLED,
							[2]									= LOOTSTER_ENUM_USAGE.MAINNEED,
							[3]									= LOOTSTER_ENUM_USAGE.OFFNEED,
							[4]									= LOOTSTER_ENUM_USAGE.MAINGREED,
							[5]									= LOOTSTER_ENUM_USAGE.OFFGREED,
							[6]									= LOOTSTER_ENUM_USAGE.ALTBOE,
							[7]									= LOOTSTER_ENUM_USAGE.BANKBOE,
							[8]									= LOOTSTER_ENUM_USAGE.MAINSHARD,
							[9]									= LOOTSTER_ENUM_USAGE.OFFSHARD,
							[10]								= LOOTSTER_ENUM_USAGE.BANKSHARD,
							[11]								= LOOTSTER_ENUM_USAGE.GREED
						  };
	Event				= {
							[LOOTSTER_ENUM_EVENT.RAIDSTART]		= { Use10=false, DKP10=0.00, Partial10=100, Standby10=100, Use25=false, DKP25=0.00, Partial25=100, Standby25=100, Time=12 },
							[LOOTSTER_ENUM_EVENT.RAIDFINISH]	= { Use10=false, DKP10=0.00, Partial10=100, Standby10=100, Use25=false, DKP25=0.00, Partial25=100, Standby25=100, Time=12 },
							[LOOTSTER_ENUM_EVENT.BOSSKILL]		= { Use10=false, DKP10=0.00, Partial10=100, Standby10=100, Use25=false, DKP25=0.00, Partial25=100, Standby25=100 },
							[LOOTSTER_ENUM_EVENT.BOSSWIPE]		= { Use10=false, DKP10=0.00, Partial10=100, Standby10=100, Use25=false, DKP25=0.00, Partial25=100, Standby25=100 },
							[LOOTSTER_ENUM_EVENT.BONUSAWARD]	= { Use10=true, DKP10=0.00, Partial10=100, Standby10=100, Use25=true, DKP25=0.00, Partial25=100, Standby25=100 },
							[LOOTSTER_ENUM_EVENT.BONUSTIME]		= { Use10=false, DKP10=0.00, Partial10=100, Standby10=100, Use25=false, DKP25=0.00, Partial25=100, Standby25=100, Time=15 }
						  };
	CalcPoints			= false;
	pFactor				= 1.000;
	Quality				= {
							[LOOTSTER_ENUM_LOOTMODE.UNCOMMON]	= { Active=false, qFactor=0.500, qBias=2.000 },
							[LOOTSTER_ENUM_LOOTMODE.RARE]		= { Active=false, qFactor=0.625, qBias=1.150 },
							[LOOTSTER_ENUM_LOOTMODE.EPIC]		= { Active=true, qFactor=0.770, qBias=1.000 },
							[LOOTSTER_ENUM_LOOTMODE.LEGENDARY]	= { Active=true, qFactor=1.000, qBias=0.000 }
						  };
	Slot				= {
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR1]	= 1.000,
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR2]	= 0.770,
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR3]	= 0.700,
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR4]	= 0.550,
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR5]	= 0.420,
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR6]	= 0.300,
							[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7]	= 0.000
						  };
	RepFormat			= "TEXTDETAIL";
	RepRaidSortCol		= "DateOpn";
	RepRaidSortColOrd	= true;
	RepBossSortCol		= "DateBeg";
	RepBossSortColOrd	= true;
	RepAttendSortCol	= "Player";
	RepAttendSortColOrd	= true;
	RepAdjustSortCol	= "DateAdj";
	RepAdjustSortColOrd	= true;
	RepAttend			= true;
	RepAttendDetail		= true;
	RepAdjust			= true;
	Sound				= true;
	UpdatedV300			= false;
	UpdatedV30b2		= false;
	UpdatedV315			= false;
	UpdatedV324			= false;
	Updated1900			= false;
	Updated20000		= false;
	Updated20100		= false;
	Updated20200		= false;
	Updated20300		= false;
	Updated30000		= false;
	Updated30200		= false;
	Updated40200		= false;
	Updated40300		= false;
	Updated50001		= false;
};

Lootster_Options_Rank_Default	=
{
	RankMembers			= false;
	NoteToons			= false;
	RankToons			= false;
	RankAltPrefix		= "";
	RankAltSuffix		= "";
	Ranks				= {};
};

Lootster_Rules				= {};

Lootster_Rules_Default		=
{
	RulesDKP		= "";
	RulesNorm		= "";
};

Lootster_Id					= 1;

Lootster_Loot				= {};

Lootster_Raid				= {};

Lootster_Boss				= {};

Lootster_Attend				= {};

Lootster_Adjust				= {};

Lootster_Assign				= {};

Lootster_Players			= {};

Lootster_Running			= {};

Lootster_Restrict			= {};

-- Global Variables
local	Lootster_EventState									= LOOTSTER_ENUM_EVENTSTATE.LOAD;

local	Lootster_VersionWoW									= nil;		-- WoW Version (TOC format)

local	Lootster_ChatFrame_OnEventCB						= nil;		-- ChatFrame_OnEvent callback function
local	Lootster_ChatFrame_OnHyperlinkShowCB				= nil;		-- ChatFrame_OnHyperlinkShow callback function
local	Lootster_ChatFrame_AddMessageGroupCB				= nil;		-- ChatFrame_AddMessageGroup callback function
local	Lootster_ChatFrame_RemoveMessageGroupCB				= nil;		-- ChatFrame_RemoveMessageGroup callback function
local	Lootster_ChatFrame_RegisterForMessagesCB			= nil;		-- ChatFrame_RegisterForMessages callback function
local	Lootster_ChatFrame_RemoveAllMessageGroupsCB			= nil;		-- ChatFrame_RemoveAllMessageGroups callback function
local	Lootster_LootButton_OnClickCB						= {};		-- LootButtonN_OnClick callback functions
local	Lootster_GroupLootFrame_OnShowCB					= nil;		-- GroupLootFrame_OnShow callback function
local	Lootster_GroupLootFrame_OnEventCB					= nil;		-- GroupLootFrame_OnEvent callback function
local	Lootster_HandleModifiedItemClickCB					= nil;		-- HandleModifiedItemClick callback function

local   Lootster_Language									= nil;		-- Default language

local	Lootster_TZOffsetSvrUTC								= 0;		-- Server timezone offset from UTC
local	Lootster_TZOffsetSvrCur								= 0;		-- Server timezone offset from current

local   Lootster_Self										= nil;		-- Self
local   Lootster_SelfRank									= nil;		-- Self rank
local   Lootster_SelfGuild									= nil;		-- Self guild
local	Lootster_SelfIsGuilded								= false;	-- Self is guilded
local   Lootster_SelfClass									= nil;		-- Self class
local   Lootster_SelfClassType								= nil;		-- Self class type
local	Lootster_SelfRealm									= "";		-- Self realm name

local	Lootster_SelfRoll									= 100;		-- Self roll maximum

local	Lootster_IsLoaded									= false;	-- Lootster loaded flag

local	Lootster_Roster										= {};		-- Current roster
local	Lootster_RosterRoll									= {};		-- Current roll roster

local	Lootster_HasDKP										= false;	-- Has DKP enabled flag

local   Lootster_DKP										= {};		-- Current data DKP
local   Lootster_DKPSort									= {};		-- Current data DKP sort
local   Lootster_DKPSortCol									= "Player";	-- Current data DKP sort column
local   Lootster_DKPSortOrd									= true;		-- Current data DKP sort order
local	Lootster_IsEPGPCapable								= true;		-- EPGP capable unless otherwise detected

local	Lootster_DKPMainAlt									= {};		-- DKP Main to Alt Look-aside Table
local	Lootster_DKPAltMain									= {};		-- DKP Alt to Main Look-aside Table

local   Lootster_PlayerId									= nil;      -- Current player id
local	Lootster_DataAttendSort								= {};		-- Current player attend sort
local	Lootster_DataAdjustSort								= {};		-- Current player adjust sort

local	Lootster_LootSel									= nil;		-- Current loot selected
local	Lootster_LootSort									= {};		-- Current loot sort
local	Lootster_LootSortCol								= "Id";		-- Current loot sort column
local	Lootster_LootSortOrd								= true;		-- Current loot sort order

local   Lootster_RaidRec									= nil;      -- Editing raid record

local   Lootster_RaidId										= nil;		-- Current raid id
local	Lootster_RaidSort									= {};		-- Current raid sort
local	Lootster_RaidSortCol								= "DateOpn";-- Current raid sort column
local	Lootster_RaidSortOrd								= false;	-- Current raid sort order

local   Lootster_BossRec									= nil;      -- Editing boss record

local   Lootster_BossId										= nil;      -- Current boss id
local	Lootster_BossSort									= {};		-- Current boss sort
local	Lootster_BossSortCol								= "DateBeg";-- Current boss sort column
local	Lootster_BossSortOrd								= false;	-- Current boss sort order

local   Lootster_BossDateBeg								= nil;      -- New boss beginning date

local   Lootster_AttendRec									= nil;      -- Editing attendance record

local   Lootster_AttendId									= nil;      -- Current attendance id
local	Lootster_BossAttendSort								= {};		-- Current boss attendance sort
local	Lootster_BossAttendSortCol							= "Player";	-- Current boss attendance sort column
local	Lootster_BossAttendSortOrd							= true;		-- Current boss attendance sort order

local   Lootster_AdjustRec									= nil;      -- Editing adjustment record

local   Lootster_AdjustId									= nil;      -- Current adjustment id
local	Lootster_BossAdjustSort								= {};		-- Current boss adjustment sort
local	Lootster_BossAdjustSortCol							= "DateAdj";-- Current boss adjustment sort column
local	Lootster_BossAdjustSortOrd							= false;	-- Current boss adjustment sort order

local   Lootster_AssignRec									= nil;      -- Editing assignment (adjustment) record

local   Lootster_AssignId									= nil;      -- Current assignment (adjustment) id
local	Lootster_BossAssignSort								= {};		-- Current boss assignment sort
local	Lootster_BossAssignSortCol							= "DateAdj";-- Current boss assignment sort column
local	Lootster_BossAssignSortOrd							= false;	-- Current boss assignment sort order

local	Lootster_Guildie									= {};		-- Guild player information

local	Lootster_GuildieMainAlt								= {};		-- Guild Main to Alt Look-aside Table
local	Lootster_GuildieAltMain								= {};		-- Guild Alt to Main Look-aside Table

local	Lootster_ParkSort									= {};		-- Park player sort

local   Lootster_Rolls										= {};		-- Current rolls
local   Lootster_RollsSort									= {};		-- Current rolls sort
local   Lootster_RollsSortCol								= "Roll";	-- Current rolls sort column
local   Lootster_RollsSortOrd								= true;		-- Current rolls sort order
local   Lootster_RollsUsage									= nil;		-- Current rolls usage in usage sort

local   Lootster_Levels										= {};		-- Current levels
local   Lootster_LevelsSort									= {};		-- Current levels sort
local   Lootster_LevelsPrompt								= "";		-- Current levels prompt

local	Lootster_Grouped									= false;	-- Player is grouped
local	Lootster_RollCount									= 0;		-- Roll count
local	Lootster_PlayerCount								= 0;		-- Player count
local	Lootster_RestrictedCount							= 0;		-- Restricted class count

local	Lootster_ItemID										= nil;		-- Item ID
local	Lootster_ItemSlot									= nil;		-- Item slot
local	Lootster_ItemLink									= nil;		-- Item link
local	Lootster_ItemText									= "";		-- Item text
local	Lootster_ItemCount									= 1;		-- Item count to roll on
local	Lootster_ItemPrompt									= "";		-- Item prompt text (with appropriate item count)
local	Lootster_ItemDKPLootType							= LOOTSTER_ENUM_DKPLOOTTYPE.NONE;

local	Lootster_AnnounceItemCount							= nil;		-- Item count after announcement

local	Lootster_ItemSel									= nil;		-- Current item selected
local	Lootster_ItemSort									= {};		-- Current item sort
local	Lootster_ItemSortCol								= "Text";	-- Current item sort column
local	Lootster_ItemSortOrd								= true;		-- Current item sort order

local	Lootster_ItemQueried								= {};		-- Queried item ID

local	Lootster_RankSort									= {};		-- Current rank sort
local	Lootster_RankSortCol								= "Index";	-- Current rank sort column
local	Lootster_RankSortOrd								= true;		-- Current rank sort order

local	Lootster_EventSel									= nil;		-- Current event selected

local	Lootster_UsageSel									= nil;		-- Current usage selected

local	Lootster_QualitySel									= nil;		-- Current quality selected

local	Lootster_SlotSel									= nil;		-- Current slot selected

local   Lootster_NBG										= nil;		-- Need before Greed
local   Lootster_NBG_Usage									= nil;		-- Need before Greed usage
local   Lootster_NBG_ClassPlease							= "";		-- Need before Greed class please text
local   Lootster_NBG_ClassIgnore							= "";		-- Need before Greed class ignore text

local	Lootster_Won										= {};		-- Winner list
local	Lootster_WonItemCount								= 0;		-- Winner item count (may be different from Winner list entries)

local	Lootster_Tied										= false;	-- Tied roll
local	Lootster_TiedRolls									= {};		-- Tied rolls
local	Lootster_TiedRollsSort								= {};		-- Tied rolls sort
local	Lootster_TiedItemCount								= 0;		-- Tied item count to roll on

local	Lootster_LootMode									= LOOTSTER_ENUM_LOOTMODE.UNCOMMON;
local	Lootster_LootMethod									= LOOTSTER_ENUM_LOOTMETHOD.GROUP;
local	Lootster_LootMaster									= nil;		-- Master looter

local	Lootster_LootQuality								= {};		-- Loot colour/quality lookup

local	Lootster_ClassIgnore								= {};		-- No ignore class yet

local	Lootster_ClassLower									= {};		-- Class lower/invariant lookup
local	Lootster_ClassPlural								= {};		-- Class plural/invariant lookup
local	Lootster_ClassSingular								= {};		-- Class singular/invariant lookup

local	Lootster_ClassRestricted							= false;	-- Class is restricted
local	Lootster_ClassRestrictedLock						= false;	-- Class is restricted locked

local	Lootster_ClassRestrictions							= {};		-- Class roll restrictions
local	Lootster_ClassRestrictionsN							= 0;		-- Class roll restrictions count
local	Lootster_ClassRestrictionsMaskOrig					= 0;		-- Class roll restrictions mask (original)
local	Lootster_ClassRestrictionsMaskCurr					= 0;		-- Class roll restrictions mask (current)

local	Lootster_RepList									= {};		-- Report plugin list

local	Lootster_SchedulerID								= {};		-- Scheduler ID table
local	Lootster_SchedulerQue								= nil;		-- Scheduler queue

local	Lootster_ToWhisperQue								= nil;		-- To Whisper queue
local	Lootster_FromWhisperQue								= nil;		-- From Whisper queue

local	Lootster_ChannelID									= nil;		-- Attend custom channel ID

local	Lootster_ChatMaskWhisper							= 0;		-- Chat Frames whisper mask

local	Lootster_SyncUser									= nil;		-- Synchronise player
local	Lootster_SyncType									= nil;		-- Synchronise type
local	Lootster_SyncCont									= nil;		-- Synchronise continuation record
local	Lootster_SyncAcks									= 0;		-- Synchronise acknowledgements received
local	Lootster_SyncTitle									= "";		-- Synchronise title
local	Lootster_SyncCount									= 0;		-- Synchronise record count
local	Lootster_SyncTotal									= 0;		-- Synchronise record total

local	Lootster_SyncData									= {};		-- Synchronise data table

local	Lootster_CallUser									= nil;		-- Call player
local	Lootster_CallType									= nil;		-- Call type
local	Lootster_CallCont									= nil;		-- Call continuation record
local	Lootster_CallTitle									= "";		-- Call title
local	Lootster_CallCount									= 0;		-- Call record count
local	Lootster_CallTotal									= 0;		-- Call record total

local	Lootster_CallData									= {};		-- Call data table

local	Lootster_MenuGroups									= {}		-- Menu groups
local	Lootster_MenuPlayers								= {}		-- Menu players

local	Lootster_CountdownCount								= 0;		-- Roll clear counter

local	Lootster_ViewRaidType								= LOOTSTER_ENUM_VIEWRAID.BYATTEND;

local	Lootster_ReportWriterCB								= nil;		-- No initial report writer
local	Lootster_ReportWriterMask							= nil;		-- No initial report writer mask
local	Lootster_ReportWriterArgs							= nil;		-- No initial report writer arguments

local	Lootster_DKPFactorSave								= nil;		-- DKP factor save
local	Lootster_RollFactorSave								= nil;		-- Roll factor save
local	Lootster_AttendCustomChannelSave					= nil;		-- Attend custom channel save
local	Lootster_AltFactorSave								= nil;		-- Alt factor save
local	Lootster_CostValueSave								= nil;		-- Cost value save
local	Lootster_CostFactorSave								= nil;		-- Cost factor save
local	Lootster_WinsPerRaidSave							= nil;		-- Wins per raid save
local	Lootster_pFactorSave								= nil;		-- Points factor save
local	Lootster_qFactorSave								= nil;		-- Quality factor save
local	Lootster_qBiasSave									= nil;		-- Quality bias save
local	Lootster_sFactorSave								= nil;		-- Slot factor save

local	Lootster_InDebugger									= false;	-- In debugger flag
local	Lootster_FromDebugger								= false;	-- From debugger flag

-- Load handler
function Lootster_OnLoad(self)
	local   faction, ix, key, classRec, frame, name, tabEntry;

	-- hook events
	self:RegisterEvent("ADDON_LOADED")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	self:RegisterEvent("PLAYER_LOGIN")
	self:RegisterEvent("PLAYER_LOGOUT")
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("PLAYER_LEAVING_WORLD");
	self:RegisterEvent("PLAYER_REGEN_ENABLED");
	self:RegisterEvent("PLAYER_REGEN_DISABLED");
	self:RegisterEvent("PARTY_LEADER_CHANGED");
	self:RegisterEvent("PARTY_LOOT_METHOD_CHANGED"); 
	self:RegisterEvent("PARTY_MEMBERS_CHANGED"); 
	self:RegisterEvent("GUILD_ROSTER_UPDATE");
	self:RegisterEvent("RAID_ROSTER_UPDATE");
	self:RegisterEvent("LOOT_OPENED");
	self:RegisterEvent("LOOT_CLOSED");
	self:RegisterEvent("LOOT_SLOT_CLEARED");
	self:RegisterEvent("CHAT_MSG_LOOT");
	self:RegisterEvent("CHAT_MSG_RAID");
	self:RegisterEvent("CHAT_MSG_PARTY");
	self:RegisterEvent("CHAT_MSG_RAID_LEADER");
	self:RegisterEvent("CHAT_MSG_ADDON");
	self:RegisterEvent("CHAT_MSG_SYSTEM");
	self:RegisterEvent("CHAT_MSG_WHISPER");
	self:RegisterEvent("CHAT_MSG_MONSTER_YELL");
	self:RegisterEvent("INSTANCE_ENCOUNTER_ENGAGE_UNIT");
	self:RegisterEvent("UPDATE_INSTANCE_INFO");
	self:RegisterEvent("WORLD_MAP_UPDATE");

	-- hook command handler
	SLASH_LOOTSTER1 = "/lootster";
	SLASH_LOOTSTER2 = "/ls";

	SlashCmdList["LOOTSTER"] = Lootster_OnCommand;

	-- echo current version
	if (DEFAULT_CHAT_FRAME) then
		DEFAULT_CHAT_FRAME:AddMessage(string.format(LOOTSTER_MSG_LOAD, LOOTSTER_VERSION));
	end
	
	-- make the popups closable using Escape key
	table.insert(UISpecialFrames, "Lootster_RaidFrameRaidFrame");
	table.insert(UISpecialFrames, "Lootster_RaidFrameBossFrame");
	table.insert(UISpecialFrames, "Lootster_RaidFrameAttendFrame");
	table.insert(UISpecialFrames, "Lootster_RaidFrameAdjustFrame");
	table.insert(UISpecialFrames, "Lootster_RaidFrameReportFrame");

	-- resolve popup frame for faster access
	for ix, name in ipairs(LOOTSTER_POPUP_FRAME) do
		-- resolve this popup frame
		LOOTSTER_POPUP_FRAME[ix] = _G[name];
	end

	-- create a dialogs for raid deletion
	StaticPopupDialogs["LOOTSTER_PROMPT_RAID_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_RAID_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Raid_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Raid_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_RAID_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_RAID_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Raid_DeleteAll_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Raid_DeleteAll_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	-- create a dialogs for boss deletion
	StaticPopupDialogs["LOOTSTER_PROMPT_BOSS_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_BOSS_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Boss_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Boss_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_BOSS_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_BOSS_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Boss_DeleteAll_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Boss_DeleteAll_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};
	
	-- create a dialogs for attendence player and attednance deletion
	StaticPopupDialogs["LOOTSTER_PROMPT_ATTEND_PLAYER"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ATTEND_PLAYER),
		button1					= TEXT(ACCEPT),
		button2					= TEXT(CANCEL),
		hasEditBox				= 1,
		maxLetters				= 12,
		OnAccept				=	function(self)
										-- make sure we have an attend record
										if (Lootster_AttendRec ~= nil) then
											-- snarf the entered player - this will be the alt
											Lootster_AttendRec.Alt = self.editBox:GetText();

											-- get the main
											Lootster_AttendRec.Player = Lootster_GetAltMain(Lootster_AttendRec.Alt);

											-- and cause menu to update
											UIDropDownMenu_SetText(Lootster_RaidFrameAttendFramePlayerDropDown, Lootster_AttendRec.Alt);
											UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAttendFramePlayerDropDown, Lootster_AttendRec.Alt);

											-- update player if set
											if (Lootster_AttendRec.Player == "") then
												Lootster_AttendRec.Player = nil;
												Lootster_AttendRec.Alt = nil;
											end

											-- update raid attend UI
											Lootster_UpdateRaidAttendUI();
										end
									end,
		OnShow					=	function(self)
										self.editBox:SetFocus();
									end,
		OnHide					=	function(self)
										if (ChatEdit_GetActiveWindow() ~= nil) then
											ChatEdit_GetActiveWindow():SetFocus();
										end

										self.editBox:SetText("");
									end,
		EditBoxOnEnterPressed	=	function(self)
										-- make sure we have an attend record
										if (Lootster_AttendRec ~= nil) then
											-- snarf the entered player - this will be the alt
											Lootster_AttendRec.Alt = self.editBox:GetText();

											-- get the main
											Lootster_AttendRec.Player = Lootster_GetAltMain(Lootster_AttendRec.Alt);

											-- and cause menu to update
											UIDropDownMenu_SetText(Lootster_RaidFrameAttendFramePlayerDropDown, Lootster_AttendRec.Alt);
											UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAttendFramePlayerDropDown, Lootster_AttendRec.Alt);

											-- update player if set
											if (Lootster_AttendRec.Player == "") then
												Lootster_AttendRec.Player = nil;
												Lootster_AttendRec.Alt = nil;
											end

											-- update raid attend UI
											Lootster_UpdateRaidAttendUI();

											-- thats all folks
											self:GetParent():Hide();
										end
									end,
		EditBoxOnEscapePressed	=	function(self)
										self:GetParent():Hide();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_ATTEND_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ATTEND_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Attend_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Attend_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_ATTEND_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ATTEND_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Attend_DeleteAll_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Attend_DeleteAll_OnCancel();
									end,
		timeout					= 0,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};
	
	-- create a dialogs for adjustment player and adjustment deletion
	StaticPopupDialogs["LOOTSTER_PROMPT_ADJUST_PLAYER"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ADJUST_PLAYER),
		button1					= TEXT(ACCEPT),
		button2					= TEXT(CANCEL),
		hasEditBox				= 1,
		maxLetters				= 12,
		OnAccept				=	function(self)
										-- make sure we have an adjust record
										if (Lootster_AdjustRec ~= nil) then
											-- snarf the entered player - this will be the alt
											Lootster_AdjustRec.Alt = self.editBox:GetText();

											-- get the main
											Lootster_AdjustRec.Player = Lootster_GetAltMain(Lootster_AdjustRec.Alt);

											-- and cause menu to update
											UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
											UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);

											-- update player if set
											if (Lootster_AdjustRec.Player == "") then
												Lootster_AdjustRec.Player = nil;
												Lootster_AdjustRec.Alt = nil;
											end

											-- update raid adjust UI
											Lootster_UpdateRaidAdjustUI();
										end
									end,
		OnShow					=	function(self)
										self.editBox:SetFocus();
									end,
		OnHide					=	function(self)
										if (ChatEdit_GetActiveWindow() ~= nil) then
											ChatEdit_GetActiveWindow():SetFocus();
										end

										self.editBox:SetText("");
									end,
		EditBoxOnEnterPressed	=	function(self)
										-- make sure we have an adjust record
										if (Lootster_AdjustRec ~= nil) then
											-- snarf the entered player - this will be the alt
											Lootster_AdjustRec.Alt = self.editBox:GetText();

											-- get the main
											Lootster_AdjustRec.Player = Lootster_GetAltMain(Lootster_AdjustRec.Alt);

											-- and cause menu to update
											UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
											UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);

											-- update player if set
											if (Lootster_AdjustRec.Player == "") then
												Lootster_AdjustRec.Player = nil;
												Lootster_AdjustRec.Alt = nil;
											end

											-- update raid adjust UI
											Lootster_UpdateRaidAdjustUI();

											-- thats all folks
											self:GetParent():Hide();
										end
									end,
		EditBoxOnEscapePressed	=	function(self)
										self:GetParent():Hide();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};
	
	StaticPopupDialogs["LOOTSTER_PROMPT_ADJUST_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ADJUST_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Adjust_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Adjust_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_ADJUST_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ADJUST_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Adjust_DeleteAll_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Adjust_DeleteAll_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};
	
	StaticPopupDialogs["LOOTSTER_PROMPT_ASSIGN_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ASSIGN_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Assign_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Assign_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_ASSIGN_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ASSIGN_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Raid_Assign_DeleteAll_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Raid_Assign_DeleteAll_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};
	
	-- create a dialog for raid synchronise player
	StaticPopupDialogs["LOOTSTER_PROMPT_RAIDSYNC_PLAYER"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_RAIDSYNC_PLAYER),
		button1					= TEXT(ACCEPT),
		button2					= TEXT(CANCEL),
		hasEditBox				= 1,
		maxLetters				= 12,
		OnAccept				=	function(self)
										-- snarf the entered player
										Lootster_SyncUser = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_RaidSyncFramePlayerDropDown, Lootster_SyncUser);
										UIDropDownMenu_SetSelectedName(Lootster_RaidSyncFramePlayerDropDown, Lootster_SyncUser);

										-- if player is blank, reset
										if (Lootster_SyncUser == "") then
											Lootster_SyncUser = nil;
										end

										-- update raid synchronise UI
										Lootster_UpdateRaidSyncUI();
									end,
		OnShow					=	function(self)
										self.editBox:SetFocus();
									end,
		OnHide					=	function(self)
										if (ChatEdit_GetActiveWindow() ~= nil) then
											ChatEdit_GetActiveWindow():SetFocus();
										end

										self.editBox:SetText("");
									end,
		EditBoxOnEnterPressed	=	function(self)
										-- snarf the entered player
										Lootster_SyncUser = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_RaidSyncFramePlayerDropDown, Lootster_SyncUser);
										UIDropDownMenu_SetSelectedName(Lootster_RaidSyncFramePlayerDropDown, Lootster_SyncUser);

										-- if player is blank, reset
										if (Lootster_SyncUser == "") then
											Lootster_SyncUser = nil;
										end

										-- update raid synchronise UI
										Lootster_UpdateRaidSyncUI();

										-- thats all folks
										self:GetParent():Hide();
									end,
		EditBoxOnEscapePressed	=	function(self)
										self:GetParent():Hide();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	-- create a dialog for loot synchronise player
	StaticPopupDialogs["LOOTSTER_PROMPT_LOOTSYNC_PLAYER"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_LOOTSYNC_PLAYER),
		button1					= TEXT(ACCEPT),
		button2					= TEXT(CANCEL),
		hasEditBox				= 1,
		maxLetters				= 12,
		OnAccept				=	function(self)
										-- snarf the entered player
										Lootster_SyncUser = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_LootSyncFramePlayerDropDown, Lootster_SyncUser);
										UIDropDownMenu_SetSelectedName(Lootster_LootSyncFramePlayerDropDown, Lootster_SyncUser);

										-- if player is blank, reset
										if (Lootster_SyncUser == "") then
											Lootster_SyncUser = nil;
										end

										-- update loot synchronise UI
										Lootster_UpdateLootSyncUI();
									end,
		OnShow					=	function(self)
										self.editBox:SetFocus();
									end,
		OnHide					=	function(self)
										if (ChatEdit_GetActiveWindow() ~= nil) then
											ChatEdit_GetActiveWindow():SetFocus();
										end

										self.editBox:SetText("");
									end,
		EditBoxOnEnterPressed	=	function(self)
										-- snarf the entered player
										Lootster_SyncUser = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_LootSyncFramePlayerDropDown, Lootster_SyncUser);
										UIDropDownMenu_SetSelectedName(Lootster_LootSyncFramePlayerDropDown, Lootster_SyncUser);

										-- if player is blank, reset
										if (Lootster_SyncUser == "") then
											Lootster_SyncUser = nil;
										end

										-- update loot synchronise UI
										Lootster_UpdateLootSyncUI();

										-- thats all folks
										self:GetParent():Hide();
									end,
		EditBoxOnEscapePressed	=	function(self)
										self:GetParent():Hide();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	-- create dialogs for loot and all loot deletion
	StaticPopupDialogs["LOOTSTER_PROMPT_LOOT_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_LOOT_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Loot_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Loot_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_LOOT_CLEARALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_LOOT_CLEARALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Loot_ClearAll_OnAccept();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};	

	StaticPopupDialogs["LOOTSTER_PROMPT_LOOT_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_LOOT_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Loot_DeleteAll_OnAccept();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};	

	-- create a dialog for item synchronise player
	StaticPopupDialogs["LOOTSTER_PROMPT_ITEMSYNC_PLAYER"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ITEMSYNC_PLAYER),
		button1					= TEXT(ACCEPT),
		button2					= TEXT(CANCEL),
		hasEditBox				= 1,
		maxLetters				= 12,
		OnAccept				=	function(self)
										-- snarf the entered player
										Lootster_SyncUser = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_ItemSyncFramePlayerDropDown, Lootster_SyncUser);
										UIDropDownMenu_SetSelectedName(Lootster_ItemSyncFramePlayerDropDown, Lootster_SyncUser);

										-- if player is blank, reset
										if (Lootster_SyncUser == "") then
											Lootster_SyncUser = nil;
										end

										-- update item synchronise UI
										Lootster_UpdateItemSyncUI();
									end,
		OnShow					=	function(self)
										self.editBox:SetFocus();
									end,
		OnHide					=	function(self)
										if (ChatEdit_GetActiveWindow() ~= nil) then
											ChatEdit_GetActiveWindow():SetFocus();
										end

										self.editBox:SetText("");
									end,
		EditBoxOnEnterPressed	=	function(self)
										-- snarf the entered player
										Lootster_SyncUser = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_ItemSyncFramePlayerDropDown, Lootster_SyncUser);
										UIDropDownMenu_SetSelectedName(Lootster_ItemSyncFramePlayerDropDown, Lootster_SyncUser);

										-- if player is blank, reset
										if (Lootster_SyncUser == "") then
											Lootster_SyncUser = nil;
										end

										-- update item synchronise UI
										Lootster_UpdateItemSyncUI();

										-- thats all folks
										self:GetParent():Hide();
									end,
		EditBoxOnEscapePressed	=	function(self)
										self:GetParent():Hide();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	-- create dialogs for item and all item deletion
	StaticPopupDialogs["LOOTSTER_PROMPT_ITEM_DELETE"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ITEM_DELETE),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Item_Delete_OnAccept();
									end,
		OnCancel				=	function(self)
										Lootster_Item_Delete_OnCancel();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};

	StaticPopupDialogs["LOOTSTER_PROMPT_ITEM_DELETEALL"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_ITEM_DELETEALL),
		button1					= TEXT(YES),
		button2					= TEXT(CANCEL),
		OnAccept				=	function(self)
										Lootster_Item_DeleteAll_OnAccept();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};
	
	-- create a dialogs for option usage banker
	StaticPopupDialogs["LOOTSTER_PROMPT_OPTION_BANKER"] =
	{
		text					= TEXT(LOOTSTER_PROMPT_OPTION_BANKER),
		button1					= TEXT(ACCEPT),
		button2					= TEXT(CANCEL),
		hasEditBox				= 1,
		maxLetters				= 12,
		OnAccept				=	function(self)
										-- snarf the entered banker
										Lootster_Options.Banker = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_OptionsFrameUsageFrameBankerDropDown, Lootster_Options.Banker);
										UIDropDownMenu_SetSelectedName(Lootster_OptionsFrameUsageFrameBankerDropDown, Lootster_Options.Banker);

										-- update banker if set
										if (Lootster_Options.Banker == "") then
											Lootster_Options.Banker = nil;
										end
									end,
		OnShow					=	function(self)
										self.editBox:SetFocus();
									end,
		OnHide					=	function(self)
										if (ChatEdit_GetActiveWindow() ~= nil) then
											ChatEdit_GetActiveWindow():SetFocus();
										end

										self.editBox:SetText("");
									end,
		EditBoxOnEnterPressed	=	function(self)
										-- snarf the entered banker
										Lootster_Options.Banker = self.editBox:GetText();

										-- and cause menu to update
										UIDropDownMenu_SetText(Lootster_OptionsFrameUsageFrameBankerDropDown, Lootster_Options.Banker);
										UIDropDownMenu_SetSelectedName(Lootster_OptionsFrameUsageFrameBankerDropDown, Lootster_Options.Banker);

										-- update banker if set
										if (Lootster_Options.Banker == "") then
											Lootster_Options.Banker = nil;
										end

										-- thats all folks
										self:GetParent():Hide();
									end,
		EditBoxOnEscapePressed	=	function(self)
										self:GetParent():Hide();
									end,
		timeout					= 0,
		exclusive				= 1,
		whileDead				= 1,
		hideOnEscape			= 1
	};	
end

-- Event handler
function Lootster_OnEvent(self, event, ...)
	local	arg1, arg2, arg3, arg4 = ...;

	-- determine event
	if		(event == "ADDON_LOADED") then
		Lootster_ADDON_Load(arg1);
	elseif	(event == "COMBAT_LOG_EVENT_UNFILTERED") then
		Lootster_COMBAT_Log(...);
	elseif	(event == "PLAYER_LOGIN") then
		Lootster_PLAYER_Login();
	elseif	(Lootster_EventState < LOOTSTER_ENUM_EVENTSTATE.LOGIN) then
		return;
	elseif	(event == "PLAYER_LOGOUT") then
		Lootster_PLAYER_Logout();
	elseif	(event == "PLAYER_ENTERING_WORLD") then
		Lootster_PLAYER_Enter();
	elseif	(Lootster_EventState < LOOTSTER_ENUM_EVENTSTATE.ENTER) then
		return;
	elseif	(event == "PLAYER_LEAVING_WORLD") then
		Lootster_PLAYER_Leave();
	elseif	(event == "PLAYER_REGEN_ENABLED") then
		Lootster_PLAYER_Regen(true, true);
	elseif	(event == "PLAYER_REGEN_DISABLED") then
		Lootster_PLAYER_Regen(false, true);
	elseif	(event == "PARTY_LEADER_CHANGED") then
		Lootster_PARTY_Leader();
	elseif	(event == "PARTY_LOOT_METHOD_CHANGED") then
		Lootster_PARTY_Leader();
	elseif	(event == "PARTY_MEMBERS_CHANGED") then
		Lootster_PARTY_Roster();
	elseif	(event == "GUILD_ROSTER_UPDATE") then
		Lootster_GUILD_Roster();
	elseif	(event == "RAID_ROSTER_UPDATE") then
		Lootster_PARTY_Roster();
	elseif	(event == "LOOT_OPENED") then
		Lootster_LOOT_Opened();
	elseif	(event == "LOOT_CLOSED") then
		Lootster_LOOT_Closed();
	elseif	(event == "LOOT_SLOT_CLEARED") then
		Lootster_LOOT_Slot_Cleared(arg1);
	elseif	(event == "CHAT_MSG_LOOT") then
		Lootster_MSG_Loot(arg1);
	elseif	(event == "CHAT_MSG_RAID") then
		Lootster_MSG_PartyRaid(arg1, arg2);
	elseif	(event == "CHAT_MSG_PARTY") then
		Lootster_MSG_PartyRaid(arg1, arg2);
	elseif	(event == "CHAT_MSG_RAID_LEADER") then
		Lootster_MSG_PartyRaid(arg1, arg2);
	elseif	(event == "CHAT_MSG_ADDON") then
		Lootster_MSG_Addon(arg1, arg2, arg3, arg4);
	elseif	(event == "CHAT_MSG_SYSTEM") then
		Lootster_MSG_System(arg1);
	elseif	(event == "CHAT_MSG_WHISPER") then
		Lootster_MSG_Whisper(arg1, arg2);
	elseif	(event == "CHAT_MSG_MONSTER_YELL") then
		Lootster_MSG_MonsterYell(arg1, arg2);
	elseif	(event == "UPDATE_INSTANCE_INFO") then
		Lootster_UPDATE_Instance();
	elseif	(event == "WORLD_MAP_UPDATE") then
		Lootster_WORLD_Update(true);
	end
end

-- Timer Update handler
function Lootster_OnUpdate(self, elapsed)
	-- handle only if counting down
	if (elapsed ~= nil) then		
		-- is the countdown timer active?
		if (Lootster_CountdownCount > 0) then
			-- call the timer countdown handler
			Lootster_Timer_Countdown(self, elapsed);
		end

		-- is the scheduler queue active?
		if (Lootster_SchedulerQue ~= nil) then
			-- call the scheduler handler
			Lootster_Timer_Scheduler(self, elapsed);
		end

		-- is the to whisper queue active?
		if (Lootster_ToWhisperQue ~= nil) then
			-- call the timer to whisper handler
			Lootster_Timer_ToWhisper(self, elapsed);
		end

		-- is the from whisper queue active?
		if (Lootster_FromWhisperQue ~= nil) then
			-- call the timer whisper handler
			Lootster_Timer_FromWhisper(self, elapsed);
		end

		-- is the synchronise timeout active?
		if (self.NextSyncTimeoutTime > 0) then
			-- call the timer synchronise handler
			Lootster_Timer_SyncTimeout(self, elapsed);
		end
	end
end

-- Timer Countdown handler
function Lootster_Timer_Countdown(self, elapsed)
	-- update elapsed time
	self.LastCountdownTime = self.LastCountdownTime + elapsed;

	-- see if we passed a second since last update
	if (self.LastCountdownTime >= 1) then
		-- decrement counter
		Lootster_CountdownCount = Lootster_CountdownCount - 1;

		-- punch out tic if it has not expired
		if (Lootster_CountdownCount > 0) then
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_COUNTDOWNTIC, Lootster_CountdownCount));
		end

		-- reset last update time
		self.LastCountdownTime = 0;
	end
end

-- Timer Scheduler handler
function Lootster_Timer_Scheduler(self, elapsed)
	local	timeNow, nextTime, dispatch;
	
	-- update elapsed time in milliseconds
	self.LastSchedulerTime = self.LastSchedulerTime + elapsed;

	-- see if we passed next scheduler time
	if (self.LastSchedulerTime >= self.NextSchedulerTime) then
		-- get current time and current next time
		timeNow = time();
		nextTime = self.NextSchedulerTime;
		
		-- dispatch  callback while we have them and our time marker is valid
		while((Lootster_SchedulerQue ~= nil) and (#Lootster_SchedulerQue > 0) and (Lootster_SchedulerQue[1].Time <= nextTime)) do
			-- get scheduler entry for later dispatch
			dispatch = Lootster_SchedulerQue[1];
			
			-- smoke scheduler ID entry
			Lootster_SchedulerID[Lootster_SchedulerQue[1].ID] = nil;

			-- smoke this event
			table.remove(Lootster_SchedulerQue, 1);

			-- and smoke queue if empty
			if (#Lootster_SchedulerQue == 0) then
				Lootster_SchedulerQue = nil;
			end

			-- dispatch this callback
			dispatch.Callback(dispatch.Args);
		end

		-- any more callbacks?
		if (Lootster_SchedulerQue ~= nil) then
			-- snarf current time for last
			self.LastSchedulerTime = timeNow;

			-- set next time to start dispatching
			self.NextSchedulerTime = Lootster_SchedulerQue[1].Time;
		end
	end
end

-- Timer To Whisper handler
function Lootster_Timer_ToWhisper(self, elapsed)
	-- update elapsed time in milliseconds
	self.LastToWhisperTime = self.LastToWhisperTime + elapsed;

	-- see if we passed next to whisper time
	if (self.LastToWhisperTime >= self.NextToWhisperTime) then
		-- dispatch messages while we have them and our time marker is valid
		while((Lootster_ToWhisperQue ~= nil) and (#Lootster_ToWhisperQue > 0) and (Lootster_ToWhisperQue[1].Time <= self.NextToWhisperTime)) do
			-- punch this message out
			SendChatMessage(Lootster_ToWhisperQue[1].Msg, "WHISPER", Lootster_Language, Lootster_ToWhisperQue[1].To);

			-- are we showing debug messages?
			if (Lootster_Options.DebugMsgs == false) then 
				-- enqueue on from whisper queue to supress the whisper echo
				Lootster_FromWhisper_Enqueue(Lootster_ToWhisperQue[1].To, Lootster_ToWhisperQue[1].Msg);
			end

			-- smoke this message
			table.remove(Lootster_ToWhisperQue, 1);

			-- and smoke queue if empty
			if (#Lootster_ToWhisperQue == 0) then
				Lootster_ToWhisperQue = nil;
			end
		end

		-- any more messages?
		if (Lootster_ToWhisperQue ~= nil) then
			-- snarf current time as for last
			self.LastToWhisperTime = time();

			-- calculate next time to start dispatching
			self.NextToWhisperTime = self.LastToWhisperTime + LOOTSTER_TQUE_DISPATCH;
		end
	end
end

-- Timer From Whisper handler
function Lootster_Timer_FromWhisper(self, elapsed)
	-- update elapsed time in milliseconds
	self.LastFromWhisperTime = self.LastFromWhisperTime + elapsed;

	-- see if we passed next from whisper time
	if (self.LastFromWhisperTime >= self.NextFromWhisperTime) then
		-- indeed - smoke from whisper queue as it is essentially defunct
		Lootster_FromWhisperQue = nil;
	end
end

-- Timer Synchronise Timeout handler
function Lootster_Timer_SyncTimeout(self, elapsed)
	-- update elapsed time in milliseconds
	self.LastSyncTimeoutTime = self.LastSyncTimeoutTime + elapsed;

	-- see if we passed next synchronise time
	if (self.LastSyncTimeoutTime >= self.NextSyncTimeoutTime) then
		-- do we have a synchronise user?
		if (Lootster_SyncUser ~= nil) then
			-- abort synchronise
			Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- timed out operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_TIMEOUT);
		end
	end
end

-- Scheduler Enqueue handler
function Lootster_Scheduler_Enqueue(id, timeDelay, callback, ...)
	local	timeNow, timeExpire;
	local	ix;
	
	-- get current time and calculate expiry
	timeNow = time();
	timeExpire = timeNow + timeDelay;
	
	-- have we an empty queue?
	if (Lootster_SchedulerQue == nil) then
		-- initialise
		Lootster_SchedulerQue = {};
		
		-- insert at front
		ix = 1;
	else
		-- is this scheduler ID already in the table?
		if (Lootster_SchedulerID[id] ~= nil) then
			-- dequeue redundent event
			Lootster_Scheduler_Dequeue(id);

			-- call ourselves again in case queue was emptied
			return Lootster_Scheduler_Enqueue(id, timeDelay, callback, ...);
		end
		
		-- locate where we need to stuff this event
		ix = Lootster_FindPosition(Lootster_SchedulerQue, "Time", timeExpire);
	end

	-- enqueue this schedule
	table.insert(Lootster_SchedulerQue, ix, { Callback=callback, Time=timeExpire, ID=id, Args=... });

	-- remember this event's expiry time
	Lootster_SchedulerID[id] = timeExpire;
	
	-- we may have a new scheduler entry, so setup last and next scheduler time 
	Lootster_Timer.LastSchedulerTime = timeNow;
	Lootster_Timer.NextSchedulerTime = Lootster_SchedulerQue[1].Time;
end

-- Scheduler Dequeue handler
function Lootster_Scheduler_Dequeue(id)
	local	timeNow;
	
	-- is this scheduler ID in the table?
	if (Lootster_SchedulerID[id] ~= nil) then
		-- get current time
		timeNow = time();
		
		-- locate this event
		ix = Lootster_FindPosition(Lootster_SchedulerQue, "Time", Lootster_SchedulerID[id]);
		
		-- we may have duplicate time entries, so we need to check each.  Find first in series
		while ((ix <= #Lootster_SchedulerQue) and (ix > 1) and (Lootster_SchedulerQue[ix - 1].Time == Lootster_SchedulerID[id])) do
			ix = ix - 1;
		end
		
		-- check each duplicate time until found
		while ((ix < #Lootster_SchedulerQue) and (Lootster_SchedulerQue[ix].Time == Lootster_SchedulerID[id]) and (Lootster_SchedulerQue[ix].ID ~= id)) do
			ix = ix + 1;
		end
		
		-- remove if found
		if		((ix <= #Lootster_SchedulerQue) and (Lootster_SchedulerQue[ix].ID == id)) then
			-- smoke this event
			table.remove(Lootster_SchedulerQue, ix);

			-- smoke queue if empty
			if (#Lootster_SchedulerQue == 0) then
				Lootster_SchedulerQue = nil;
			else
				-- we may have a top scheduler entry, so setup last and next scheduler time 
				Lootster_Timer.LastSchedulerTime = timeNow;
				Lootster_Timer.NextSchedulerTime = Lootster_SchedulerQue[1].Time;
			end
		elseif	(Lootster_Options.DebugMsgs == true) then
			-- debugging, send note to ourselves
			if (DEFAULT_CHAT_FRAME) then
				DEFAULT_CHAT_FRAME:AddMessage("Scheduler Event ID not found "..id);
			end
		end
		
		-- smoke scheduler ID entry
		Lootster_SchedulerID[id] = nil;
	end
end

-- To Whisper Enqueue handler
function Lootster_ToWhisper_Enqueue(to, msg, sync)
	local	sub;

	-- is this a Lootster message?
	if (string.find(msg, LOOTSTER_SYNC_IMP_PREFIX) ~= nil) then
		-- is this message over length?
		if (string.len(msg) > LOOTSTER_SYNC_MESSAGELEN) then
			-- chunk up the message
			repeat
				-- get sub-message
				sub = string.sub(msg, 1, (LOOTSTER_SYNC_MESSAGELEN - 1))..LOOTSTER_SYNC_POSTFIXCONT;

				-- and slice up current message
				msg = LOOTSTER_SYNC_PREFIX..string.sub(msg, LOOTSTER_SYNC_MESSAGELEN);

				-- enqueue sub-message
				Lootster_ToWhisper_Enqueue(to, sub);
			until (string.len(msg) <= LOOTSTER_SYNC_MESSAGELEN);

			-- enqueue final sub-message
			Lootster_ToWhisper_Enqueue(to, msg, sync);
		end
	end

	-- first message being enqueued?
	if (Lootster_ToWhisperQue == nil) then
		-- establish current time
		Lootster_Timer.CurrToWhisperTime = time();

		-- set the next broadcast period, which is enough for initial message dispatches
		Lootster_Timer.NextToWhisperTime = Lootster_Timer.CurrToWhisperTime + LOOTSTER_TQUE_DISPATCHBIAS * LOOTSTER_TQUE_DISPATCHINIT;

		-- set last time fired
		Lootster_Timer.LastToWhisperTime = Lootster_Timer.CurrToWhisperTime;

		-- create queue
		Lootster_ToWhisperQue = {};
	else
		-- bias current time to delay message
		Lootster_Timer.CurrToWhisperTime = Lootster_Timer.CurrToWhisperTime + LOOTSTER_TQUE_DISPATCHBIAS;
	end

	-- is this a synchronous request (that is, immediate - no queuing)
	if (sync ~= true) then	
		-- enqueue this message
		table.insert(Lootster_ToWhisperQue, { Time=Lootster_Timer.CurrToWhisperTime, To=to, Msg=msg });
	else
		-- punch this message out right now
		SendChatMessage(msg, "WHISPER", Lootster_Language, to);

		-- and enqueue to be suppressed
		Lootster_FromWhisper_Enqueue(to, msg);
	end
end

-- From Whisper Enqueue handler
function Lootster_FromWhisper_Enqueue(to, msg)
	-- set last time fired
	Lootster_Timer.LastFromWhisperTime = time();
	
	-- update whisper expiry clear timer
	Lootster_Timer.NextFromWhisperTime = Lootster_Timer.LastFromWhisperTime + LOOTSTER_FQUE_CLEAR;
	
	-- have we an empty queue?
	if (Lootster_FromWhisperQue == nil) then
		-- initialise
		Lootster_FromWhisperQue = {};
	end

	-- have we an empty player queue?
	if (Lootster_FromWhisperQue[to] == nil) then
		-- initialise
		Lootster_FromWhisperQue[to] = {};
	end

	-- enqueue this from whisper
	table.insert(Lootster_FromWhisperQue[to], { Mask=0, Msg=msg });
end

-- Command handler
function Lootster_OnCommand(cmd)
	-- only command is nothing at all - toggle display
	if (cmd == "") then
		Lootster_OnToggle(self);
	else
		-- process this as a player inquiry from ourselves
		Lootster_PlayerInquiry(Lootster_Self, cmd);
	end
end

-- ChatFrame Event handler
function Lootster_ChatFrame_OnEvent(self, event, ...)
	-- manage roll and whisper suppression
	if		(event == "CHAT_MSG_SYSTEM") then
		Lootster_CHAT_System(self, event, ...);
	elseif	(event == "CHAT_MSG_WHISPER") then
		Lootster_CHAT_Whisper(self, event, ...);
	elseif	(event == "CHAT_MSG_WHISPER_INFORM") then
		Lootster_CHAT_Whisper_Inform(self, event, ...);
	else
		-- pass to chat frame for processing
		Lootster_ChatFrame_OnEventCB(self, event, ...);
	end
end

-- ChatFrame Hyperlink Show handler
function Lootster_ChatFrame_OnHyperlinkShow(self, link, text, button)
	-- must be an item
	if (strsub(link, 1, 4) == "item") then
		-- pass link to tooltip click handler but don't link
		if (Lootster_ClickTooltip(text, button, true) == true) then
			-- display restrictions bails out now
			return;
		end
	end

	-- and pass to base class
	Lootster_ChatFrame_OnHyperlinkShowCB(self, link, text, button);
end

-- ChatFrame Add Message Group handler
function Lootster_ChatFrame_AddMessageGroup(chatFrame, group)
	-- is this the whisper group?
	if (group == "WHISPER") then
		-- add this frame to the chat frame whisper mask
		Lootster_ChatMaskWhisper = bit.bor(Lootster_ChatMaskWhisper, bit.lshift(1, chatFrame:GetID()));
	end

	-- call base class
	Lootster_ChatFrame_AddMessageGroupCB(chatFrame, group);
end

-- ChatFrame Remove Message Group handler
function Lootster_ChatFrame_RemoveMessageGroup(chatFrame, group)
	-- call base class
	Lootster_ChatFrame_RemoveMessageGroupCB(chatFrame, group);

	-- is this the whisper group?
	if (group == "WHISPER") then
		-- remove this frame remove the chat frame whisper mask
		Lootster_ChatMaskWhisper = bit.band(Lootster_ChatMaskWhisper, bit.bnot(bit.lshift(1, chatFrame:GetID())));
	end
end

-- ChatFrame Register For Messages handler
function Lootster_ChatFrame_RegisterForMessages(self, ...)
	local	aix;

	-- hammer through all the arguments
	for aix=1, select("#", ...) do
		-- is this whisper?
		if (select(aix, ...) == "WHISPER") then
			-- add this frame to the chat frame whisper mask
			Lootster_ChatMaskWhisper = bit.bor(Lootster_ChatMaskWhisper, bit.lshift(1, self:GetID()));
			break
		end
	end

	-- call base class
	Lootster_ChatFrame_RegisterForMessagesCB(self, ...);
end

-- ChatFrame Remove All Message Groups handler
function Lootster_ChatFrame_RemoveAllMessageGroups(chatFrame)
	-- call base class
	Lootster_ChatFrame_RemoveAllMessageGroupsCB(chatFrame);

	-- remove this frame remove the chat frame whisper mask
	Lootster_ChatMaskWhisper = bit.band(Lootster_ChatMaskWhisper, bit.bnot(bit.lshift(1, chatFrame:GetID())));
end

-- LootButton Click handler
function Lootster_LootButton_OnClick(self, button)
	-- pass to base class if we have one
	if (Lootster_LootButton_OnClickCB[self] ~= nil) then
		-- see if its a modified click
		if (IsModifiedClick() == true) then
			-- handle modified click
			Lootster_HandleModifiedItemClickCB(GetLootSlotLink(self.slot));
		else
			-- pass to loot button handler
			Lootster_LootButton_OnClickCB[self](self, button);
		end
	end

	-- is this a loot item?
	if (LootSlotHasItem(self.slot) == true) then
		-- pass link to tooltip click handler
		Lootster_ClickTooltip(GetLootSlotLink(self.slot), button, true, self.slot);
	end
end

-- GroupLootFrame Show handler
function Lootster_GroupLootFrame_OnShow(self)
	local	lootFrame, classIcon, classFrame;
	local	_, restrictions, restrictionsN;

	-- pass to the callback function
	Lootster_GroupLootFrame_OnShowCB(self);

	-- retrieve the echo loot frame
	lootFrame = _G["Lootster_EchoLootFrame"..self:GetID()];

	-- are we to allow class restrictions to be echoed?
	if ((Lootster_Options.EchoRestrict == true) and (Lootster_Options.EchoByGroupLoot == true)) then
		-- get the item details for the roll link
		_, _, _, _, _, restrictions, restrictionsN = Lootster_GetItemDetails(GetLootRollItemLink(self.rollID));

		-- see if we have class restrictions
		if (restrictionsN > 0) then
			local	class, count, ix;
			local	classes = {};
			local	icon;

			-- build an alphabetical list of restricted classes
			for ix, flag in ipairs(LOOTSTER_CLASS_SORT) do
				-- this class restricted?
				if ((Lootster_ClassIgnore[LOOTSTER_CLASS_SORT[ix]] == nil) and (restrictions[LOOTSTER_CLASS_SORT[ix]] == true)) then
					table.insert(classes, LOOTSTER_CLASS_SORT[ix]);
				end
			end

			-- now show the respective class icons
			count = #classes;

			for ix=1, count, 1 do
				-- get this class icon
				classIcon = _G["Lootster_EchoLootFrame"..self:GetID().."ClassFrame"..ix.."Icon"];

				-- hammer in the class texture
				classIcon:SetTexture("Interface\\AddOns\\Lootster\\Images\\Class-"..classes[ix]);

				-- get this class frame
				classFrame = _G["Lootster_EchoLootFrame"..self:GetID().."ClassFrame"..ix];

				-- update the class frame's class
				classFrame.Class = LOOTSTER_CLASS[classes[ix]].Plural;

				-- and show
				classFrame:Show();
			end

			-- now hide the remaining class icon slots
			for ix=(count + 1), (#LOOTSTER_CLASS_SORT - 1), 1 do
				-- get this class frame
				classFrame = _G["Lootster_EchoLootFrame"..self:GetID().."ClassFrame"..ix];

				-- and hide
				classFrame:Hide();
			end

			-- and show the echo loot frame
			lootFrame:Show();
		else
			-- hide the frame
			lootFrame:Hide();
		end
	else
		-- hide the frame
		lootFrame:Hide();
	end
end

-- GroupLootFrame Event handler
function Lootster_GroupLootFrame_OnEvent(self, event, ...)
	local rollID = ...;

	-- first, pass to the callback function
	Lootster_GroupLootFrame_OnEventCB(self, event, ...);

	-- is this the cancel loot roll event?
	if (event == "CANCEL_LOOT_ROLL") then
		-- make sure this is the roll we are handling
		if (rollID == self.rollID) then
			-- hide our echo loot frame
			_G["Lootster_EchoLootFrame"..self:GetID()]:Hide()
		end
	end
end

-- HandleModifiedItemClick handler
function Lootster_HandleModifiedItemClick(link)
	local	linkType, button;

	-- onlyhandle if we have a link
	if (link ~= nil) then
		-- extract link type
		linkType = string.match(link, "|H([^:]+)");

		-- make sure this is an item link
		if ((link ~= nil) and IsModifiedClick() and (linkType == "item")) then
			-- we don't get the button, but our function wants it
			if		((IsModifiedClick("CHATLINK") ~= nil) or (IsModifiedClick("DRESSUP") ~= nil)) then
				button = "LeftButton";
			elseif	(IsModifiedClick("STICKYCAMERA") ~= nil) then
				button = "RightButton";
			end

			-- pass link to tooltip click handler but don't link
			if (Lootster_ClickTooltip(link, button, true) == true) then
				-- display restrictions bails out now
				return true;
			end
		end
	end

	-- and pass to base function
	return Lootster_HandleModifiedItemClickCB(link);
end

-- UI Toggle handler
function Lootster_OnToggle(self)
	-- handle toggling of the UI
	if (Lootster_Options.MiniMap == true) then
		-- MiniMap Operation
		if (Lootster_IsVisible()) then
			if (Lootster_Options.Sound) then
				PlaySound("igMiniMapClose");
			end

			-- hide
			Lootster_TabsFrame:Hide();

			Lootster_ClassFrame:Hide();

			-- hide dialogs et al
			Lootster_LootSyncFrame:Hide();
			Lootster_ItemSyncFrame:Hide();
			Lootster_RaidSyncFrame:Hide();
			Lootster_RaidFrameRaidFrame:Hide();
			Lootster_RaidFrameBossFrame:Hide();
			Lootster_RaidFrameAttendFrame:Hide();
			Lootster_RaidFrameAdjustFrame:Hide();

			Lootster_RaidFrameReportFrame:Hide();

			-- are we in Normal auto mode using auto-clear on close?
			if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and ((Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) or
				(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL)) and (Lootster_Options.AutoRollClose == true)) then
				-- clear rolls
				Lootster_Roll_ClearRolls_OnClick(Lootster_RollFrameClearRolls, "LeftButton");
			end
		else
			if (Lootster_Options.Sound) then
				PlaySound("igMiniMapOpen");
			end

			-- if we are class restricted, we show the class dialog
			if (Lootster_ClassRestricted == true) then
				Lootster_ClassFrame:Show();
			else
				-- reset class restrictions
				Lootster_ResetClass();

				-- update the class UI
				Lootster_UpdateClassUI();

				-- update the UI
				Lootster_UpdateRollUI();
			end

			-- show
			Lootster_TabsFrame:Show();
		end
	else
		-- normal operation
		if (Lootster_IsVisible()) then
			if (Lootster_Options.Sound) then
				PlaySound("igMiniMapClose");
			end

			-- hide
			Lootster_TabsFrame:Hide();

			Lootster_ClassFrame:Hide();

			-- hide dialogs et al
			Lootster_LootSyncFrame:Hide();
			Lootster_ItemSyncFrame:Hide();
			Lootster_RaidSyncFrame:Hide();
			Lootster_RaidFrameRaidFrame:Hide();
			Lootster_RaidFrameBossFrame:Hide();
			Lootster_RaidFrameAttendFrame:Hide();
			Lootster_RaidFrameAdjustFrame:Hide();

			Lootster_RaidFrameReportFrame:Hide();

			-- are we in Normal 100/1000 mode using auto-clear on close?
			if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and ((Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) or
				(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL)) and (Lootster_Options.NormAutoClose == true)) then
				-- clear rolls
				Lootster_Roll_ClearRolls_OnClick(Lootster_RollFrameClearRolls, "LeftButton");
			end
		else
			if (Lootster_Options.Sound) then
				PlaySound("igMiniMapOpen");
			end

			-- if we are class restricted, we show the class dialog
			if (Lootster_ClassRestricted == true) then
				Lootster_ClassFrame:Show();
			else
				-- reset class restrictions
				Lootster_ResetClass();

				-- update the class UI
				Lootster_UpdateClassUI();

				-- update the UI
				Lootster_UpdateRollUI();
			end

			-- show
			Lootster_TabsFrame:Show();
		end
	end
	
	-- show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState(false);
end

-- Change Tab handler
function Lootster_ChangeTab(tab)
	local	ix, tabEntry, cframe, ctab;

	-- are we to simply show the one already checked?
	if		(tab == true) then
		-- check for a checked tab
		for ix, tabEntry in ipairs(LOOTSTER_TAB_FRAME) do
			-- get the tab
			tab = _G[tabEntry.Tab];

			-- this guy checked?
			if (tab:GetChecked() ~= nil) then
				break;
			end
		end

		-- still unknown?
		if (tab:GetChecked() == nil) then
			-- use the roll tab
			tab = Lootster_RollTab;
		end
	elseif	(tab == false) then
		-- hide all tabs
		tab = nil;
	end

	-- resolve tab/frames for faster access
	for ix, tabEntry in ipairs(LOOTSTER_TAB_FRAME) do
		-- get this tab and frame
		ctab = _G[tabEntry.Tab];
		cframe = _G[tabEntry.Frame];

		-- are we to show or hide?
		if (tab ~= nil) then
			-- is this the tab to show?
			if (tab == ctab) then
				-- check this tab
				ctab:SetChecked(1);

				-- and show frame
				cframe:Show();
			else
				-- uncheck this tab
				ctab:SetChecked(0);

				-- and hide frame
				cframe:Hide();
			end
		else
			-- and hide frame
			cframe:Hide();
		end
	end
end

-- UI Raid Toggle handler
function Lootster_Raid_OnToggle(self, boss, killSet)
	local	_, zone, type, wowId, dateExp, raidId, bossId, raidRec;
	
	-- if we are running raid and boss and we have running boss id we must toggle the boss off
	if ((Lootster_Running.BossId ~= nil) and (Lootster_Options.TrackBy ~= LOOTSTER_ENUM_TRACKBY.RAID)) then
		-- toggle off boss
		Lootster_Boss_OnToggle(self);
	end
	
	-- wax on or wax off?
	if (Lootster_Running.RaidId == nil) then
		-- get the zone name (dont care if not changed)
		_, zone, type = Lootster_HasRaidZoneChanged();

		-- no zone use default
		if (zone == nil) then
			zone = LOOTSTER_RAIDRAID_ZONEUNKNOWN
		end

		-- ignore WoW instance Id if this is an ordinary instance
		if ((type ~= LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) and (type ~= LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM)) then	
			-- determine the WoW instance id and instance reset date
			wowId, dateExp = Lootster_GetInstanceId(zone, type);
		end
		
		-- we need to determine if this is a continuation of an instance
		raidId, bossId = Lootster_GetMatchingRaidNBoss(zone, type, wowId);
		
		-- have we a matching raid?
		if (raidId ~= nil) then
			-- existing raid: mark as running
			Lootster_RunRaid(raidId);
			
			-- determine if we have a matching boss
			if		(bossId == nil) then
				-- force toggle of boss to start a default.  This will be TBD until targeted
				Lootster_Boss_OnToggle(self, boss, killSet);
			elseif	(Lootster_Boss[bossId].Combat == false) then
				-- existing boss: mark as running
				Lootster_RunBoss(bossId);
			else
				-- if this is a boss attempt, mark as a wipe
				if (Lootster_IsBossAttempt(bossId) == true) then
					-- update the current boss as a wipe
					Lootster_UpdateBoss(bossId, LOOTSTER_ENUM_BOSSTYPE.BOSSWIPE);
				end
				
				-- force toggle of boss to start a default.  This will be TBD until targeted
				Lootster_Boss_OnToggle(self, boss, killSet);
			end
		else		
			-- instantiate a new raid record
			raidRec = Lootster_NewRaid(zone, type, wowId, Lootster_CalcServerTime(time()), dateExp);

			-- create raid and make our running raid
			Lootster_RunRaid(Lootster_CreateRaid(raidRec));
		
			-- force toggle of boss to start a default
			Lootster_Boss_OnToggle(self, boss, killSet);
		end
	else
		-- end of raid
		Lootster_RunRaid(nil);
		
		-- end of boss
		Lootster_RunBoss(nil);
	end		

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- UI Boss Toggle handler
function Lootster_Boss_OnToggle(self, boss, killSet)
	local	 tbd, bossId, bossRec, name;

	-- no running raid id we are done
	if (Lootster_Running.RaidId == nil) then
		return;
	end
	
	-- wax on or wax off?
	if (Lootster_Running.BossId == nil) then
		-- if not a real boss, then we need to fake one
		if (boss == nil) then
			-- use To Be Determined boss initially
			boss = LOOTSTER_RAIDBOSS_TBD;
			tbd = true;
		else
			-- we know the dude
			tbd = false;
			
			-- is this raid in an unknown instance?
			if (Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) then
				-- this is a well known boss, so mark it as an outdoor raid
				Lootster_Raid[Lootster_Running.RaidId].Type = LOOTSTER_ENUM_RAIDTYPE.OUTDOOR;
				
				-- and rerun the raid
				Lootster_RunRaid(Lootster_Running.RaidId);
			end				
		end
		
		-- locate any previous attempts
		bossId = Lootster_GetMatchingBoss(Lootster_Running.RaidId, boss);
		
		-- are we tracking boss attempts?
		if		((Lootster_Options.AutoBoss == false) and (bossId ~= nil)) then
			-- only using one boss, so simply re-run the old boss, and take partial attendance
			Lootster_RunBoss(bossId);

			-- take partial attendance now
			Lootster_TakeAttendance(Lootster_Running.BossId, LOOTSTER_ENUM_ATTENDED.PARTIAL);
		elseif	((bossId ~= nil) and (Lootster_Boss[bossId].Type == LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT)) then
			-- simply re-run the old boss attempt, and take partial attendance
			Lootster_RunBoss(bossId);

			-- take partial attendance now
			Lootster_TakeAttendance(Lootster_Running.BossId, LOOTSTER_ENUM_ATTENDED.PARTIAL);
		else
			-- did we have a previous attempt at boss?
			if (bossId ~= nil) then
				-- and bump attempt number
				attempt = Lootster_Boss[bossId].Attempt + 1;
			else
				-- inital attempt
				attempt = 1;
			end

			-- instantiate a new boss record
			bossRec = Lootster_NewBoss(boss, Lootster_CalcServerTime(time()), tbd, attempt, nil, killSet);
				
			-- create boss and make our running boss
			Lootster_RunBoss(Lootster_CreateBoss(bossRec));
		
			-- insert boss into the running
			Lootster_InsertBoss(Lootster_Running.RaidId, Lootster_Running.BossId);

			-- take full attendance now
			Lootster_TakeAttendance(Lootster_Running.BossId, LOOTSTER_ENUM_ATTENDED.FULL);
		end
	else
		-- take partial attendance now
		Lootster_TakeAttendance(Lootster_Running.BossId, LOOTSTER_ENUM_ATTENDED.PARTIAL);

		-- end of boss - update end time first
		Lootster_Boss[Lootster_Running.BossId].DateEnd = Lootster_CalcServerTime(time());

		Lootster_RunBoss(nil);
	end	

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Addon Load handler
function Lootster_ADDON_Load(addon)
	local	key, value;
	local	itemString, itemId, itemRec, itemSet, itemText, raidId, raidRec, bossId, flag, player, attendId, adjustId, adjustRec, guild;
	local	usageId, usageRec;

	-- is this Lootster?
	if (addon ~= LOOTSTER_LABEL_LOOTSTER) then
		-- not me
		return;
	end

	-- initialise session
	for key, value in pairs(Lootster_Options_Default) do
		if (Lootster_Options[key] == nil) then
			Lootster_Options[key] = value;
		end
	end

	for key, value in pairs(Lootster_Rules_Default) do
		if (Lootster_Rules[key] == nil) then
			Lootster_Rules[key] = value;
		end
	end

	-- retrieve WoW version
	Lootster_VersionWoW = Lootster_GetWoWVersion();

	-- transfer old DKP used toggle to new selection style
	if (Lootster_Options.DKPUsed ~= nil) then
		-- update roll mode
		if (Lootster_Options.DKPUsed == true) then
			-- DKP mode
			Lootster_Options.RollMode = LOOTSTER_ENUM_ROLLMODE.USEDKP;
		else
			-- Normal mode
			Lootster_Options.RollMode = LOOTSTER_ENUM_ROLLMODE.USENORM;
		end

		-- set default DKP type (old style)
		Lootster_Options.DKPType = LOOTSTER_ENUM_DKP.BYMODIFIEDROLL;

		-- set default Normal mode
		Lootster_Options.NormType = LOOTSTER_ENUM_NORM.BYNEEDGREED;

		-- erase old DKP used toggle
		Lootster_Options.DKPUsed = nil;
	end

	-- transfer old rules to new rules if necessary
	if (Lootster_Rules.Rules ~= nil) then
		-- update DKP rules
		Lootster_Rules.RulesDKP = Lootster_Rules.Rules;

		-- update normal rules
		Lootster_Rules.RulesNorm = Lootster_Rules.Rules;

		-- erase old rules
		Lootster_Rules.Rules = nil;
	end

	-- transfer old 100 rules to new Norm rules as necessary (name change)
	if (Lootster_Rules.Rules100 ~= nil) then
		-- update normal rules
		Lootster_Rules.RulesNorm = Lootster_Rules.Rules100;

		-- erase old 100 rules
		Lootster_Rules.Rules100 = nil;
	end

	-- ensure loot rules have a trailing break
	Lootster_Rules.RulesDKP = Lootster_AppendTrailingLineBreak(Lootster_Rules.RulesDKP);
	Lootster_Rules.RulesNorm = Lootster_AppendTrailingLineBreak(Lootster_Rules.RulesNorm);

	-- WoW Version 1800 -> 1900 update
	--
	-- Version 1900 causes the Suppress Rolls in Chat Log to work.  Modified initial load of Lootster
	-- to flip this flag OFF to reduce surprises
	if ((Lootster_Options.Updated1900 == nil) or (Lootster_Options.Updated1900 == false)) then
		-- flip suppression off
		Lootster_Options.Suppress = false;

		-- and mark as having done so
		Lootster_Options.Updated1900 = true;
	end

	-- transfer old 100/1000 UI options to normal rolling auto options
	if (Lootster_Options.CorKRoll ~= nil) then
		-- move to normal rolling auto-roll option
		Lootster_Options.NormAutoRoll = Lootster_Options.CorKRoll;

		-- erase old 100/1000 auto roll option
		Lootster_Options.CorKRoll = nil;
	end

	if (Lootster_Options.CorKOpen ~= nil) then
		-- move to normal rolling auto-open option
		Lootster_Options.NormAutoOpen = Lootster_Options.CorKOpen;

		-- erase old 100/1000 auto open option
		Lootster_Options.CorKOpen = nil;
	end

	if (Lootster_Options.CorKClose ~= nil) then
		-- move to normal rolling auto-close option
		Lootster_Options.NormAutoClose = Lootster_Options.CorKClose;

		-- erase old 100/1000 auto close option
		Lootster_Options.CorKClose = nil;
	end

	-- transfer old DKP priority mode as DKP membership mode
	if (Lootster_Options.DKPPrior ~= nil) then
		-- move to DKP membership option
		Lootster_Options.DKPMember = Lootster_Options.DKPPrior;

		-- erase old 100/1000 auto close option
		Lootster_Options.DKPPrior = nil;
	end

	-- WoW Version 20000: The Burning Crusade
	--
	-- Changes made to handle Lua 5.1
	if (Lootster_IsWoWVersion(20000)) then
		-- update report sort ordering to reflect changed set attributes
		if (strsub(Lootster_Options.RepRaidSortCol, -3) == "Set") then
			-- replace with new sort attribute
			Lootster_Options.RepRaidSortCol = strsub(Lootster_Options.RepRaidSortCol, 1, -3).."N";
		end

		if (strsub(Lootster_Options.RepBossSortCol, -3) == "Set") then
			-- replace with new sort attribute
			Lootster_Options.RepBossSortCol = strsub(Lootster_Options.RepBossSortCol, 1, -3).."N";
		end

		if (strsub(Lootster_Options.RepAttendSortCol, -3) == "Set") then
			-- replace with new sort attribute
			Lootster_Options.RepAttendSortCol = strsub(Lootster_Options.RepAttendSortCol, 1, -3).."N";
		end

		-- and mark as having done so
		Lootster_Options.Updated20000 = true;
	end

	-- WoW Version 20000 -> 20100 update
	--
	-- Fix item restriction Ids to conform to TBC 8-type id format
	if (Lootster_IsWoWVersion(20100)) then
		-- deprecated code -  mark as having done so
		Lootster_Options.Updated20100 = true;
	end

	-- WoW Version 20100 -> 20200 update
	--
	-- Remove restricted items that have been removed by Blizzard
	if (Lootster_IsWoWVersion(20200)) then
		-- deprecated code - mark as having done so
		Lootster_Options.Updated20200 = true;
	end

	-- WoW Version 20200 -> 20300 update
	--
	-- Copy RankToons to NoteToons for Public Note utilisation
	if (Lootster_IsWoWVersion(20300)) then
		-- hammer through each recorded guild for 
		for guild, flag in pairs(Lootster_Options.RankToons) do
			-- copy this value to public note used for toons
			Lootster_Options.NoteToons[guild] = flag;
		end

		-- and mark as having done so
		Lootster_Options.Updated20300 = true;
	end

	-- WoW Version 20300 -> 30000 update
	--
	-- Fix item restriction Ids to conform to new 9-type (WotLK) id format
	if (Lootster_IsWoWVersion(30000)) then
		-- hammer through existing raids adding an instance type of Unknown
		for raidId, raidRec in pairs(Lootster_Raid) do
			-- is the instance type set?
			if (raidRec.Type == nil) then
				-- set to unknown
				raidRec.Type = LOOTSTER_ENUM_RAIDTYPE.UNKNOWN;
			end
		end				

		-- and mark as having done so
		Lootster_Options.Updated30000 = true;
	end

	-- Lootster Version 3.0.0 (EPGP and Events)
	-- 
	-- Upgrade DKP handling to attendance Earnt points, seperate adjustment Earnt and Spent points, 
	-- and modify attendance enumeration
	if ((Lootster_Options.UpdatedV300 == nil) or (Lootster_Options.UpdatedV300 == false)) then
		-- hammer through the adjustment table
		for adjustId, adjustRec in pairs(Lootster_Adjust) do
			-- apply fixup for the record if this is old style DKP bookkeeping (single DKP for earnt or spent)
			if		(adjustRec.DKP ~= nil) then
				-- convert to new style DKP bookkeeping (two DKPs for earnt and spent)
				if (adjustRec.Link == nil) then
					-- no link so assume earnt
					adjustRec.DKPAdjEarnt = adjustRec.DKP;
					adjustRec.DKPAdjSpent = 0;
				else
					-- link so assume spent.  Note we flip the sign since spent is *use of* DKP
					adjustRec.DKPAdjEarnt = 0;
					adjustRec.DKPAdjSpent = -adjustRec.DKP;
				end
				
				-- and hammer old DKP value
				adjustRec.DKP = nil;
			elseif	((adjustRec.DKPAdjEarnt == nil) or (adjustRec.DKPAdjSpent == nil)) then
				-- this is a total record which we no longer use
				Lootster_Adjust[adjustId] = nil;
			end
			
			-- set the item usage as main spec need
			adjustRec.Usage = LOOTSTER_ENUM_USAGE.MAINNEED;
			
			-- and hammer old ML value
			adjustRec.ML = nil;
		end
		
		-- preprocess the adjustment table, translating all previous version records
		for adjustIx, adjustRec in ipairs(Lootster_Adjust) do
			-- apply fixup for the record if this is old style DKP bookkeeping (single DKP for earnt or spent)
			if (adjustRec.DKPAct ~= nil) then
				-- convert to new style DKP bookkeeping (two DKPs for earnt and spent)
				if (adjustRec.DKPAct >= 0) then
					-- positive so assume earnt (crude)
					adjustRec.DKPAdjEarnt = adjustRec.DKPAct;
					adjustRec.DKPAdjSpent = 0;
				else
					-- negative so assume spent (crude).  Note we flip the sign since spent is *use of* DKP
					adjustRec.DKPAdjEarnt = 0;
					adjustRec.DKPAdjSpent = -adjustRec.DKPAct;
				end
				
				-- and hammer old DKP value
				adjustRec.DKPAct = nil;
			end
		end

		-- hammer through the raid table
		for raidId, raidRec in pairs(Lootster_Raid) do
			-- create assign set and count
			raidRec.AssignSet = {};
			raidRec.AssignN = 0;

			-- reset attendance earnt DKP
			raidRec.DKPAttEarnt = 0;

			-- reset adjustment earnt/spent DKP
			raidRec.DKPAdjEarnt = 0;
			raidRec.DKPAdjSpent = 0;
			
			-- hammer through bosses in raid
			for bossId, flag in pairs(raidRec.BossSet) do
				-- create assign set and count
				Lootster_Boss[bossId].AssignSet = {};
				Lootster_Boss[bossId].AssignN = 0;

				-- reset attendance earnt DKP
				Lootster_Boss[bossId].DKPAttEarnt = 0;

				-- reset adjustment earnt/spent DKP
				Lootster_Boss[bossId].DKPAdjEarnt = 0;
				Lootster_Boss[bossId].DKPAdjSpent = 0;
				
				-- hammer through attendences in boss
				for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
					-- reset attendance earnt DKP
					Lootster_Attend[attendId].DKPAttEarnt = 0;

					-- reset adjustment earnt/spent DKP
					Lootster_Attend[attendId].DKPAdjEarnt = 0;
					Lootster_Attend[attendId].DKPAdjSpent = 0;
					
					-- hammer through adjustments in attendance
					for adjustId, adjustId in pairs(Lootster_Attend[attendId].AdjustSet) do
						-- accumulate attendance earnt/spent DKP
						Lootster_Attend[attendId].DKPAdjEarnt = Lootster_Attend[attendId].DKPAdjEarnt + 
																Lootster_Adjust[adjustId].DKPAdjEarnt;
						Lootster_Attend[attendId].DKPAdjSpent = Lootster_Attend[attendId].DKPAdjSpent + 
																Lootster_Adjust[adjustId].DKPAdjSpent;
					end
			
					-- and hammer old DKP value
					Lootster_Attend[attendId].DKP = nil;

					-- accumulate boss attendance earnt DKP
					Lootster_Boss[bossId].DKPAttEarnt = Lootster_Boss[bossId].DKPAttEarnt + Lootster_Attend[attendId].DKPAttEarnt;

					-- accumulate boss adjustment earnt/spent DKP
					Lootster_Boss[bossId].DKPAdjEarnt = Lootster_Boss[bossId].DKPAdjEarnt + Lootster_Attend[attendId].DKPAdjEarnt;
					Lootster_Boss[bossId].DKPAdjSpent = Lootster_Boss[bossId].DKPAdjSpent + Lootster_Attend[attendId].DKPAdjSpent;
					
					-- if the boss has an end date, use it as the attendance date, otherwise use the boss begin date
					if (Lootster_Boss[bossId].DateEnd ~= nil) then
						-- end date is attendance date
						Lootster_Attend[attendId].DateAtt = Lootster_Boss[bossId].DateEnd;
					else
						-- begin date is attendance date
						Lootster_Attend[attendId].DateAtt = Lootster_Boss[bossId].DateBeg;
					end
				
					-- apply Attended value fixup
					if		(Lootster_Attend[attendId].Attended == LOOTSTER_ENUM_ATTENDED.STANDBY) then
						-- old Not at All
						Lootster_Attend[attendId].Attended = LOOTSTER_ENUM_ATTENDED.NOTATALL;
					elseif	(Lootster_Attend[attendId].Attended == LOOTSTER_ENUM_ATTENDED.NOTATALL) then
						-- old Standby
						Lootster_Attend[attendId].Attended = LOOTSTER_ENUM_ATTENDED.STANDBY;
					end
				end

				-- and hammer old DKP value
				Lootster_Boss[bossId].DKP = nil;
				
				-- add the new Type value, note though we don't know whether it was a wipe or kill
				Lootster_Boss[bossId].Type = LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT;
				
				-- killed flag is no longer used
				if (Lootster_Boss[bossId].Killed ~= nil) then
					-- hammer old Killed value
					Lootster_Boss[bossId].Killed = nil;
				end

				-- do we have an existing attempt number?
				if (Lootster_Boss[bossId].Attempt == nil) then
					-- add attempt number to the boss
					Lootster_Boss[bossId].Attempt = 1;
				end
				
				-- accumulate boss attendance earnt DKP
				raidRec.DKPAttEarnt = raidRec.DKPAttEarnt + Lootster_Boss[bossId].DKPAttEarnt;

				-- accumulate raid adjustment earnt/spent DKP
				raidRec.DKPAdjEarnt = raidRec.DKPAdjEarnt + Lootster_Boss[bossId].DKPAdjEarnt;
				raidRec.DKPAdjSpent = raidRec.DKPAdjSpent + Lootster_Boss[bossId].DKPAdjSpent;
			end
	
			-- and hammer old DKP value
			raidRec.DKP = nil;
		end
		
		-- upgrade tracking of instances by differentiating normal and heroic raids.  Outdoor raid enumeration
		-- got changed from what is now heroic raids
		Lootster_Options.Track[6] = Lootster_Options.Track[5];
		Lootster_Options.Track[5] = true;
		
		-- remove DKP alts settings - now in usage management
		Lootster_Options.DKPAlts = nil;
		Lootster_Options.DKPAltsFactor = nil;

		-- remove DKP off spec settings - now via usage management
		Lootster_Options.DKPOffSpecs = nil;
		Lootster_Options.DKPOffSpecsFactor = nil;
		
		-- modify DKP sort to new style as necessary
		if (Lootster_DKPSortCol == "DKP") then
			Lootster_DKPSortCol = "DKPTotal";
		end
		
		-- modify raid sort to new style as necessary
		if (Lootster_RaidSortCol == "DKP") then
			Lootster_RaidSortCol = "DKPSpent";
		end
		
		-- modify boss sort to new style as necessary
		if (Lootster_BossSortCol == "DKP") then
			Lootster_BossSortCol = "DKPSpent";
		end
		
		-- modify attend sort to new style as necessary
		if (Lootster_AttendSortCol == "DKP") then
			Lootster_AttendSortCol = "DKPEarnt";
		end
		
		-- modify adjust sort to new style as necessary
		if (Lootster_AdjustSortCol == "DKP") then
			Lootster_AdjustSortCol = "DKPSpent";
		end
		
		-- modify report raid sort to new style as necessary
		if (Lootster_Options.RepRaidSortCol == "DKP") then
			Lootster_Options.RepRaidSortCol = "DKPSpent";
		end
		
		-- modify report boss sort to new style as necessary
		if (Lootster_Options.RepBossSortCol == "DKP") then
			Lootster_Options.RepBossSortCol = "DKPSpent";
		end
		
		-- modify report attend sort to new style as necessary
		if (Lootster_Options.RepAttendSortCol == "DKP") then
			Lootster_Options.RepAttendSortCol = "DKPEarnt";
		end
		
		-- modify report adjust sort to new style as necessary
		if (Lootster_Options.RepAdjustSortCol == "DKP") then
			Lootster_Options.RepAdjustSortCol = "DKPSpent";
		end

		-- reset item set
		itemSet = {};

		-- hammer through item restrictions, locating all 4-type (Classic), 8-type (TBC) and 9-type (WotLK)
		for itemString, itemRec in pairs(Lootster_Restrict) do
			-- snarf base item id
			if (string.find(itemString, LOOTSTER_ITEM_MATCH)) then
				-- add this guy to our item set
				itemSet[itemString] = Lootster_NewRestrict(itemRec.Text, itemRec.Classes);
			end
		end

		-- hammer through the item set, replacing all 4-type (Classic), 8-type (TBC) and 9-type (WotLK)
		-- with straight item id
		for itemString, itemRec in pairs(itemSet) do
			-- extract the ID, text and quality of the link
			for itemId in string.gmatch(itemString, LOOTSTER_ITEM_PATTERN) do
				-- convert item id to numeric
				itemId = tonumber(itemId);
				
				-- add as an item id
				Lootster_Restrict[itemId] = Lootster_NewRestrict(itemRec.Text, itemRec.Classes);

				-- and smoke old 4-type (Classic), 8-type (TBC) and 9-type (WotLK) entry
				Lootster_Restrict[itemString] = nil;
			end
		end	

		-- and mark as having done so
		Lootster_Options.UpdatedV300 = true;
	end

	-- Lootster Version 3.0.Beta2 (EPGP and Events)
	-- 
	-- Remove consolidated report option
	if ((Lootster_Options.UpdatedV30b2 == nil) or (Lootster_Options.UpdatedV30b2 == false)) then
		-- now a separate report type
		Lootster_Options.RepConsolidate = nil;

		-- and mark as having done so
		Lootster_Options.UpdatedV30b2 = true;
	end

	-- WoW Version 30000 -> 30200 update
	--
	-- Update raid types for new 10- man and 25-man normal and heroic raids
	if (Lootster_IsWoWVersion(30200)) then
		-- upgrade tracking of instances by differentiating 10-man and 25-man normal and heroic raids.  Outdoor raid enumeration
		-- got changed from what is now heroic raids
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.OUTDOOR] = Lootster_Options.Track[6];
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25NORM] = Lootster_Options.Track[5];
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID10HERO] = true;
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25HERO] = true;
		
		-- hammer through existing raids adding an instance type of Unknown
		for raidId, raidRec in pairs(Lootster_Raid) do
			-- was raid type 25-man or outdoor?
			if		(raidRec.Type == 5) then
				-- set 25-man normal
				raidRec.Type = LOOTSTER_ENUM_RAIDTYPE.RAID25NORM;
			elseif	(raidRec.Type == 6) then
				-- set outdoor
				raidRec.Type = LOOTSTER_ENUM_RAIDTYPE.OUTDOOR;
			end
		end

		-- and mark as having done so
		Lootster_Options.Updated30200 = true;
	end

	-- Lootster Version 3.1.5 (Wins Per Raid Tracking)
	-- 
	-- Upgrade usage options for wins per raid, and accumulate wins for exiting raids
	if ((Lootster_Options.UpdatedV315 == nil) or (Lootster_Options.UpdatedV315 == false)) then
		-- hammer through usages adding the Wins and WinsPerField attributes
		for usageId, usageRec in pairs(Lootster_Options.Usage) do
			-- copy attrbutes from default
			usageRec.Wins = Lootster_Options_Default.Usage[usageId].Wins;
			usageRec.WinsPerRaid = Lootster_Options_Default.Usage[usageId].WinsPerRaid;
		end
		
		-- hammer through existing raids accumulating wins per usage for each player
		for raidId, raidRec in pairs(Lootster_Raid) do
			-- add a usage set to the raid
			raidRec.UsageSet = {};
			
			-- hammer through raid's adjustments
			for adjustId, player in pairs(raidRec.AdjustSet) do
				-- does this player have an entry yet?
				if (raidRec.UsageSet[player] == nil) then
					-- add this player's usage set
					raidRec.UsageSet[player] = {};
				end
				
				-- do we have an entry for this loot's usage?
				if (raidRec.UsageSet[player][Lootster_Adjust[adjustId].Usage] == nil) then
					-- initially one of course
					raidRec.UsageSet[player][Lootster_Adjust[adjustId].Usage] = 1;
				else
					-- bump
					raidRec.UsageSet[player][Lootster_Adjust[adjustId].Usage] = raidRec.UsageSet[player][Lootster_Adjust[adjustId].Usage] + 1;
				end
			end
		end
		
		-- and mark as having done so
		Lootster_Options.UpdatedV315 = true;
	end

	-- WoW Version 30200 -> 40200 update
	--
	-- Update restrict list to use numeric item ID
	if (Lootster_IsWoWVersion(40200)) then
		-- reset item set
		itemSet = {};

		-- hammer through item restrictions, ensuring item ids are numeric
		for itemString, itemRec in pairs(Lootster_Restrict) do
			-- old string item id?
			if (type(itemString) ~= "number") then
				-- add to item set
				itemSet[itemString] = itemRec;
			end
		end

		-- hammer through item set, converting item id to numeric
		for itemString, itemRec in pairs(itemSet) do
			-- convert item id to numeric
			itemId = tonumber(itemString);
				
			-- add as an numeric item id
			Lootster_Restrict[itemId] = itemRec;

			-- and smoke string item id
			Lootster_Restrict[itemString] = nil;
		end	

		-- and mark as having done so
		Lootster_Options.Updated40200 = true;
	end

	-- WoW Version 40200 -> 40300 update
	--
	-- Update raid types for new 25-man looking for raid
	if (Lootster_IsWoWVersion(40300)) then
		-- upgrade tracking of instances by differentiating 25-man looking for raid, normal, heroic raids.  Shift 25-man 
		-- and outdoor types up one
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.OUTDOOR] = Lootster_Options.Track[8];
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25HERO] = Lootster_Options.Track[7];
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25NORM] = Lootster_Options.Track[6];
		Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25RF] = true;
		
		-- hammer through existing raids shifting 25-man and outdoor raid type up one
		for raidId, raidRec in pairs(Lootster_Raid) do
			-- was raid type 25-man or outdoor?
			if		(raidRec.Type == 6) then
				-- set 25-man normal
				raidRec.Type = LOOTSTER_ENUM_RAIDTYPE.RAID25NORM;
			elseif	(raidRec.Type == 7) then
				-- set 25-man heroic
				raidRec.Type = LOOTSTER_ENUM_RAIDTYPE.RAID25HERO;
			elseif	(raidRec.Type == 8) then
				-- set outdoor
				raidRec.Type = LOOTSTER_ENUM_RAIDTYPE.OUTDOOR;
			end
		end

		-- and mark as having done so
		Lootster_Options.Updated40300 = true;
	end

	-- has DKP check
	Lootster_HasDKP = (Lootster_DateDKP ~= nil) and (Lootster_MainDKP ~= nil) and (Lootster_AltsDKP ~= nil) and
					  (Lootster_ParkDKP ~= nil) and (Lootster_MobsDKP ~= nil) and (Lootster_ItemDKP ~= nil) and
					  (Lootster_TierDKP ~= nil);

	-- if DKP is disabled, make sure we correct current states
	if (not Lootster_HasDKP) then
		-- switch off DKP
		Lootster_Options.RollMode = LOOTSTER_ENUM_ROLLMODE.USENORM;

		-- spoof empty tables so we process as normal
		Lootster_DateDKP = "";
		Lootster_SiteDKP = "";
		Lootster_MainDKP = {};
		Lootster_AltsDKP = {};
		Lootster_ParkDKP = {};
		Lootster_MobsDKP = {};
		Lootster_ItemDKP = {};
		Lootster_TierDKP = {};
	else
		-- show DKP date widgets
		Lootster_OptionsFrameVersionFrameDKPDateLabel:Show();
		Lootster_OptionsFrameVersionFrameDKPDate:Show();

		-- enable roll mode widget
		Lootster_OptionsFrameRollModeButton:Enable();

		-- do we have DKP site name?
		if (Lootster_SiteDKP ~= nil) then
			-- show DKP site widgets
			Lootster_OptionsFrameVersionFrameDKPSiteLabel:Show();
			Lootster_OptionsFrameVersionFrameDKPSite:Show();
		else
			-- no site name
			Lootster_SiteDKP = "";
		end
	end
	
	-- disable the countdown button
	Lootster_RollFrameCountdown:Disable();

	-- initialise roll tab
	Lootster_RollFrameActive:SetChecked(Lootster_Options.Active);
	Lootster_RollFramePassive:SetChecked(Lootster_Options.Passive);

	-- disable/enable passive rolling checkbox
	if (Lootster_Options.Active == true) then
		Lootster_RollFramePassive:Disable();
	else
		Lootster_RollFramePassive:Enable();
	end

	-- initialise options tab
	Lootster_OptionsFrameMiniMapButton:SetChecked(Lootster_Options.MiniMap);

	Lootster_OptionsFrameMiniMapSlider:SetValue(Lootster_Options.MiniMapPos);
	Lootster_OptionsFrameMiniMapSliderText:SetText(Lootster_Options.MiniMapPos);

	Lootster_OptionsFrameVersionFrameVersion:SetText(LOOTSTER_VERSION);
	Lootster_OptionsFrameVersionFrameDKPDate:SetText(Lootster_DateDKP);
	Lootster_OptionsFrameVersionFrameDKPSite:SetText(Lootster_SiteDKP);

	Lootster_OptionsFrameSuppress:SetChecked(Lootster_Options.Suppress);

	Lootster_OptionsFrameRWRoll:SetChecked(Lootster_Options.RWRoll);

	Lootster_OptionsFrameRWAll:SetChecked(Lootster_Options.RWRollBy == LOOTSTER_ENUM_RAIDWARN.ALL);
	Lootster_OptionsFrameRWCall:SetChecked(Lootster_Options.RWRollBy == LOOTSTER_ENUM_RAIDWARN.CALL);

	Lootster_OptionsFrameAckRoll:SetChecked(Lootster_Options.AckRoll);

	Lootster_OptionsFrameAckNoInfo:SetChecked(Lootster_Options.AckNoInfo);

	Lootster_OptionsFrameAckNoCall:SetChecked(Lootster_Options.AckNoCall);

	Lootster_OptionsFrameAckNoRoll:SetChecked(Lootster_Options.AckNoRoll);

	Lootster_OptionsFrameAckNoHelp:SetChecked(Lootster_Options.AckNoHelp);

	Lootster_OptionsFrameAckNoRaid:SetChecked(Lootster_Options.AckNoRaid);

	Lootster_OptionsFrameAckNoBoss:SetChecked(Lootster_Options.AckNoBoss);

	Lootster_OptionsFrameAckNoAtt:SetChecked(Lootster_Options.AckNoAtt);

	Lootster_OptionsFrameAckNoAdj:SetChecked(Lootster_Options.AckNoAdj);

	Lootster_OptionsFrameCounter:SetChecked(Lootster_Options.Counter);

	Lootster_OptionsFrameSeconds:SetNumber(Lootster_Options.CounterSec);

	Lootster_OptionsFrameEchoRestrict:SetChecked(Lootster_Options.EchoRestrict);
	Lootster_OptionsFrameEchoToChat:SetChecked(Lootster_Options.EchoToChat);
	Lootster_OptionsFrameEchoToRW:SetChecked(Lootster_Options.EchoToRW);
	Lootster_OptionsFrameEchoByClick:SetChecked(Lootster_Options.EchoByClick);
	Lootster_OptionsFrameEchoByGroupLoot:SetChecked(Lootster_Options.EchoByGroupLoot);

	Lootster_OptionsFrameAutoSnoop:SetChecked(Lootster_Options.AutoSnoop);

	Lootster_OptionsFrameDebugMsgs:SetChecked(Lootster_Options.DebugMsgs);

	Lootster_OptionsFrameDKPMember:SetChecked(Lootster_Options.DKPMember);
	Lootster_OptionsFrameDKPToon:SetChecked(Lootster_Options.DKPToon);
	Lootster_OptionsFrameDKPGreedFFA:SetChecked(Lootster_Options.DKPGreedFFA);

	Lootster_OptionsFrameDKPAttEarnt:SetChecked(Lootster_Options.DKPAttEarnt);

	Lootster_OptionsFrameDKPCaps:SetChecked(Lootster_Options.DKPCaps);

	Lootster_OptionsFrameDKPHi:SetNumber(Lootster_Options.DKPHi);
	Lootster_OptionsFrameDKPLo:SetNumber(Lootster_Options.DKPLo);

	Lootster_OptionsFrameDKPFactoring:SetChecked(Lootster_Options.DKPFactoring);

	Lootster_OptionsFrameDKPFactor:SetNumber(Lootster_Options.DKPFactor);

	Lootster_OptionsFrameRollFactoring:SetChecked(Lootster_Options.RollFactoring);

	Lootster_OptionsFrameRollFactor:SetNumber(Lootster_Options.RollFactor);

	Lootster_OptionsFrameEPMin:SetChecked(Lootster_Options.EPMin);
	Lootster_OptionsFrameGPBase:SetChecked(Lootster_Options.GPBase);

	Lootster_OptionsFrameEPMinEP:SetNumber(Lootster_Options.EPMinEP);
	Lootster_OptionsFrameGPBaseGP:SetNumber(Lootster_Options.GPBaseGP);

	Lootster_OptionsFrameNormMember:SetChecked(Lootster_Options.NormMember);
	Lootster_OptionsFrameNormToon:SetChecked(Lootster_Options.NormToon);
	Lootster_OptionsFrameNormGreedFFA:SetChecked(Lootster_Options.NormGreedFFA);

	Lootster_OptionsFrameNormAutoRoll:SetChecked(Lootster_Options.NormAutoRoll);
	Lootster_OptionsFrameNormAutoOpen:SetChecked(Lootster_Options.NormAutoOpen);
	Lootster_OptionsFrameNormAutoClose:SetChecked(Lootster_Options.NormAutoClose);

	Lootster_OptionsFrameRaidFrameTrackDungeonNorm:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM]);
	Lootster_OptionsFrameRaidFrameTrackDungeonHero:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.DUNGEONHERO]);
	Lootster_OptionsFrameRaidFrameTrackRaid10Norm:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID10NORM]);
	Lootster_OptionsFrameRaidFrameTrackRaid10Hero:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID10HERO]);
	Lootster_OptionsFrameRaidFrameTrackRaid25Norm:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25NORM]);
	Lootster_OptionsFrameRaidFrameTrackRaid25Hero:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.RAID25HERO]);
	Lootster_OptionsFrameRaidFrameTrackOutdoor:SetChecked(Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.OUTDOOR]);

	Lootster_OptionsFrameRaidFrameTrackByRaid:SetChecked(Lootster_Options.TrackBy == LOOTSTER_ENUM_TRACKBY.RAID);
	Lootster_OptionsFrameRaidFrameTrackByRaidNBoss:SetChecked(Lootster_Options.TrackBy == LOOTSTER_ENUM_TRACKBY.RAIDNBOSS);
	
	Lootster_OptionsFrameAutoRaid:SetChecked(Lootster_Options.AutoRaid);
	Lootster_OptionsFrameAutoBoss:SetChecked(Lootster_Options.AutoBoss);

	Lootster_OptionsFrameRaidIcon:SetChecked(Lootster_Options.RaidIcon);
	Lootster_OptionsFrameBossIcon:SetChecked(Lootster_Options.BossIcon);
	
	Lootster_OptionsFrameAttendHere:SetChecked(Lootster_Options.AttendHere);
	Lootster_OptionsFrameAttendAnnounce:SetChecked(Lootster_Options.AttendAnnounce);
	Lootster_OptionsFrameAttendGroup:SetChecked(Lootster_Options.AttendGroup);
	Lootster_OptionsFrameAttendGuild:SetChecked(Lootster_Options.AttendGuild);
	Lootster_OptionsFrameAttendCustom:SetChecked(Lootster_Options.AttendCustom);

	if (Lootster_Options.AttendCustomChannel ~= nil) then
		Lootster_OptionsFrameAttendCustomChannel:SetText(Lootster_Options.AttendCustomChannel);
	else
		Lootster_OptionsFrameAttendCustomChannel:SetText("");
	end
	
	Lootster_OptionsFrameAutoDKPLoot:SetChecked(Lootster_Options.AutoDKPLoot);
	Lootster_OptionsFrameAutoNonDKPLoot:SetChecked(Lootster_Options.AutoNonDKPLoot);
	Lootster_OptionsFrameAutoLootRaid:SetChecked(Lootster_Options.AutoLootRaid);
	
	Lootster_OptionsFrameUsageRolls:SetChecked(Lootster_Options.UsageRolls);

	Lootster_OptionsFrameUsageFrameUsageBySeparate:SetChecked(Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SEPARATE);
	Lootster_OptionsFrameUsageFrameUsageBySingle:SetChecked(Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SINGLE);
	
	Lootster_OptionsFrameCalcPoints:SetChecked(Lootster_Options.CalcPoints);
	
	Lootster_OptionsFrameItemPointsFramepFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.pFactor));
	
	-- disable quality and slot set/reset buttons
	Lootster_OptionsFrameItemPointsFrameQualitySet:Disable();
	Lootster_OptionsFrameItemPointsFrameQualityReset:Disable();
	Lootster_OptionsFrameItemPointsFrameSlotSet:Disable();
	Lootster_OptionsFrameItemPointsFrameSlotReset:Disable();

	-- initialise raid report
	Lootster_RaidFrameReportFrameAttend:SetChecked(Lootster_Options.RepAttend);
	Lootster_RaidFrameReportFrameAttendDetail:SetChecked(Lootster_Options.RepAttendDetail);
	Lootster_RaidFrameReportFrameAdjust:SetChecked(Lootster_Options.RepAdjust);

	-- hide the UI
	Lootster_TabsFrame:Hide();
	
	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState(false);

	-- reflect the position
	Lootster_MiniMapButton_UpdatePosition();

	-- setup location of main frame
	Lootster_CheckLocation();

	-- update echo UI
	Lootster_CheckEchoUse();

	-- check tabs and update mode UI
	Lootster_CheckModeUse();

	-- check raid UI
	Lootster_CheckRaidUse();

	-- check boss UI
	Lootster_CheckBossUse();

	-- check attend UI
	Lootster_CheckAttendUse();

	-- reset hyperlink
	Lootster_SetHyperlink(nil);
end

-- Combat Log handler
function Lootster_COMBAT_Log(...)
	local	timestamp, event, hideCaster, srcGUID, srcName, srcFlagsP, srcFlagsR, dstGUID, dstName, dstFlagsP, dstFlagsR = ...;
	
	local	srcId, srcNPC, dstId, dstNPC, kiaId, npcId, killSet, actIx, actRec, spellId, boss, bossId, bossRec, count, id, kills;
	
	-- check if we will arenot to auto-create raids/bosses
	if ((Lootster_Running.RaidId == nil) or (Lootster_Running.BossId == nil)) then
		-- the only raid/boss not auto-created by this stage would be one for outdoor raids
		if ((Lootster_Options.AutoRaid ~= true) or (Lootster_Options.Track[LOOTSTER_ENUM_RAIDTYPE.OUTDOOR] ~= true) or (IsInInstance() == 1)) then
			return;
		end
	end
	
	-- extract the source and destination details
	srcId, srcNPC = Lootster_GetBossId(srcGUID);
	dstId, dstNPC = Lootster_GetBossId(dstGUID);
	
	-- snarf destination id for later kill detection
	kiaId = dstId;
	
	-- if not NPCs or they have already been checked, ignore
	if ((srcNPC ~= true) or (srcId == 0) or (bit.band(srcFlagsP, COMBATLOG_OBJECT_REACTION_COMBATIVE) == 0)) then
		-- no check necessary
		srcId = nil;
	end
	
	if ((dstNPC ~= true) or (dstId == 0) or (bit.band(dstFlagsP, COMBATLOG_OBJECT_REACTION_COMBATIVE) == 0)) then
		-- no check necessary
		dstId = nil;
	end
	
	-- no NPC id yet
	npcId = nil;
	
	-- no boss information yet
	boss = nil;
	killSet = nil;
	
	-- no dude(s) to check means skip all the boss checks
	if ((srcId ~= nil) or (dstId ~= nil)) then
		-- no boss or no combat means we haven't found a boss
		if		((Lootster_Running.BossId == nil) or (Lootster_Boss[Lootster_Running.BossId].Combat == false)) then
			-- ensure this boss doesn't have fake engaging actions
			if ((srcId ~= nil) and (LOOTSTER_BOSS_FAKESRC[srcId] ~= nil)) then
				-- check each engaging action
				for actIx, actRec in ipairs(LOOTSTER_BOSS_FAKESRC[srcId]) do
					-- check the selected argument against the test
					if (select(actRec.Select, ...) == actRec.Test) then
						-- and ignore source and destination
						srcId = nil;
						dstId = nil;
					end
					
					-- found?
					if (srcId == nil) then
						break;
					end
				end
			end

			-- ensure this boss doens't have fake engaged actions
			if ((dstId ~= nil) and (LOOTSTER_BOSS_FAKEDST[dstId] ~= nil)) then
				-- check each engaged action
				for actIx, actRec in ipairs(LOOTSTER_BOSS_FAKEDST[dstId]) do
					-- check the selected argument against the test
					if (select(actRec.Select, ...) == actRec.Test) then
						-- and ignore source and destination
						srcId = nil;
						dstId = nil;
					end
					
					-- found?
					if (dstId == nil) then
						break;
					end
				end
			end

			-- determine if the source or destination is a boss
			if		((srcId ~= nil) and (LOOTSTER_BOSS_ID[srcId] ~= nil)) then
				npcId = srcId;
			elseif	((dstId ~= nil) and (LOOTSTER_BOSS_ID[dstId] ~= nil)) then
				-- ensure this boss wasn't hit by fake engaged actions
				spellId = select(9, ...);
				
				if ((spellId ~= nil) and (LOOTSTER_SPELL_IGNORE[spellId] == true)) then
					-- ignore destination
					dstId = nil;
				else
					npcId = dstId;
				end
			end
			
			-- did we resolve to a boss?
			if (npcId ~= nil) then
				-- see if we have a translation look-aside buffer for this boss
				if (LOOTSTER_BOSS_TLB[npcId] ~= nil) then
					-- use this underlying boss's ID
					npcId = LOOTSTER_BOSS_TLB[npcId];
				end
				
				-- have we a group fight name for this boss?
				if		(LOOTSTER_BOSS_NAME[npcId] ~= nil) then
					-- use the group's name
					boss = LOOTSTER_BOSS_NAME[npcId];
				elseif	(npcId == srcId) then
					-- use source name
					boss = srcName;
				elseif	(npcId == dstId) then
					-- use destination name
					boss = dstName;
				end
		
				-- have we a kill list for this boss?
				if (LOOTSTER_BOSS_KILL[npcId] ~= nil) then
					-- copy this boss's kill list
					killSet = Lootster_CopyRecord(LOOTSTER_BOSS_KILL[npcId]);
				end
			end
		elseif	((Lootster_Running.BossId ~= nil) and (type(Lootster_Boss[Lootster_Running.BossId].TBD) == "number")) then
			-- check if the TBD NPC id has shown up so we can resolve to the name
			if		(Lootster_Boss[Lootster_Running.BossId].TBD == srcId) then
				-- use source name
				boss = srcName;
			elseif	(Lootster_Boss[Lootster_Running.BossId].TBD == dstId) then
				-- use destination name
				boss = dstName;
			end
		end
	end
	
	-- start a boss attempt as necessary
	Lootster_StartBossAttempt(npcId, boss, killSet);
	
	-- only interested in destination NPC died when we have a boss running
	if ((Lootster_Running.BossId ~= nil) and (dstNPC == true) and (event == "UNIT_DIED")) then
		-- do we have a kill list for this boss?
		if		(Lootster_Boss[Lootster_Running.BossId].KillSet ~= nil) then
			-- some fights have a variable kill count depending on 10-man or 25-man
			if ((Lootster_Boss[Lootster_Running.BossId].KillSet.Count10 ~= nil) and (Lootster_Boss[Lootster_Running.BossId].KillSet.Count25 ~= nil)) then
				-- dungeon size?
				if		((Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID10NORM) or
						 (Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID10HERO)) then
					-- use 10-man count
					Lootster_Boss[Lootster_Running.BossId].KillSet.Count = Lootster_Boss[Lootster_Running.BossId].KillSet.Count10;
				elseif	((Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID25NORM) or
						 (Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID25HERO)) then
					-- use 25-man count
					Lootster_Boss[Lootster_Running.BossId].KillSet.Count = Lootster_Boss[Lootster_Running.BossId].KillSet.Count25;
				end
				
				-- and reset 10-man and 25-man counts
				Lootster_Boss[Lootster_Running.BossId].KillSet.Count10 = nil;
				Lootster_Boss[Lootster_Running.BossId].KillSet.Count25 = nil;
			end
		
			-- make sure the kill set count has been initialised
			if (Lootster_Boss[Lootster_Running.BossId].KillSet.Count == nil) then
				-- initial count
				count = 0;
				
				-- count each boss ID
				for id, kills in pairs(Lootster_Boss[Lootster_Running.BossId].KillSet) do
					-- bump count
					count = count + 1;
				end
				
				-- update count
				Lootster_Boss[Lootster_Running.BossId].KillSet.Count = count;
			end		
		
			-- see if this boss id is in the boss's kill list
			if (Lootster_Boss[Lootster_Running.BossId].KillSet[kiaId] ~= nil) then
				-- decrement the kill count
				Lootster_Boss[Lootster_Running.BossId].KillSet[kiaId] = Lootster_Boss[Lootster_Running.BossId].KillSet[kiaId] - 1;
				
				-- last kill for this dude?
				if (Lootster_Boss[Lootster_Running.BossId].KillSet[kiaId] == 0) then
					-- remove the boss entry
					Lootster_Boss[Lootster_Running.BossId].KillSet[kiaId] = nil;
					
					-- update boss kill count
					Lootster_Boss[Lootster_Running.BossId].KillSet.Count = Lootster_Boss[Lootster_Running.BossId].KillSet.Count - 1;
					
					-- any more kills left?
					if (Lootster_Boss[Lootster_Running.BossId].KillSet.Count == 0) then
						-- remove kill list
						Lootster_Boss[Lootster_Running.BossId].KillSet = nil;
						
						-- mark boss as toast
						Lootster_UpdateBoss(Lootster_Running.BossId, LOOTSTER_ENUM_BOSSTYPE.BOSSKILL);
					end
				end
			end
		elseif	(Lootster_Boss[Lootster_Running.BossId].Boss == dstName) then
			-- mark boss as toast
			Lootster_UpdateBoss(Lootster_Running.BossId, LOOTSTER_ENUM_BOSSTYPE.BOSSKILL);
		end
	end
end

-- Player Login handler
function Lootster_PLAYER_Login()
	local	faction, cix;
	local	button, icon;
	local	ix, colour;
	local	key, classRec;

	-- bump event state
	Lootster_EventState = Lootster_EventState + 1;

	-- determine language and player class to jetison
	faction = UnitFactionGroup("player");

	if		(faction == "Alliance") then
		Lootster_Language = LOOTSTER_LANG_COMMON;

		Lootster_ClassIgnore = LOOTSTER_CLASS_HORDE;
	elseif  (faction == "Horde") then
		Lootster_Language = LOOTSTER_LANG_ORCISH;

		Lootster_ClassIgnore = LOOTSTER_CLASS_ALLIANCE;
	end

	-- initialise class frame
	for cix=1, #LOOTSTER_CLASS_SORT, 1 do
		-- get the class item button
		button = _G["Lootster_ClassFrameClass"..cix.."Text"];

		-- hammer the text into this guy
		button:SetText(LOOTSTER_CLASS[LOOTSTER_CLASS_SORT[cix]].Singular);

		-- get button for the item class header
		button = _G["Lootster_ItemFrameClassHeader"..cix];

		-- set the class tooltip
		button.Class = LOOTSTER_CLASS[LOOTSTER_CLASS_SORT[cix]].Plural;

		-- get class icon for the item class header
		icon = _G["Lootster_ItemFrameClassHeader"..cix.."Icon"];

		-- and set the class icon
		icon:SetTexture("Interface\\AddOns\\Lootster\\Images\\Class-"..LOOTSTER_CLASS_SORT[cix]);
	end

	-- get default language
 	Lootster_Language = GetDefaultLanguage("player");

	-- get player name and class
	Lootster_Self = UnitName("player");
	Lootster_SelfClass, Lootster_SelfClassType = UnitClass("player");

	-- get realm name
	Lootster_SelfRealm = GetRealmName();
	
	-- make unknown quality red
	Lootster_LootQuality[LOOTSTER_ENUM_LOOTMODE.UNKNOWN] = LOOTSTER_ITEMQUAL_UNCACHED;

	-- generate loot colour/quality lookup
	for ix=LOOTSTER_ENUM_LOOTMODE.POOR, LOOTSTER_ENUM_LOOTMODE.LEGENDARY do
		-- extract colour
		for colour in string.gmatch(ITEM_QUALITY_COLORS[ix].hex, LOOTSTER_ITEMCOLOUR_PATTERN) do
			-- add the colour to quality
			Lootster_LootQuality[colour] = ix;
		end
	end
	
	-- make red and unknown quality
	Lootster_LootQuality[LOOTSTER_ITEMQUAL_UNCACHED] = LOOTSTER_ENUM_LOOTMODE.UNKNOWN;

	-- generate the class plural and singulars class name to invariant lookups
	for key, classRec in pairs(LOOTSTER_CLASS) do
		-- add the lower to invariant
		Lootster_ClassLower[string.lower(classRec.Singular)] = key;

		-- add the plural to invariant
		Lootster_ClassPlural[classRec.Plural] = key;

		-- add the singular to invariant
		Lootster_ClassSingular[classRec.Singular] = key;
	end

	-- gather chat frame whisper mask
	Lootster_ChatMaskWhisper = Lootster_LoadChatMask("WHISPER");

	-- determine server time zone
	Lootster_LoadTimeZone();

	-- determine if guilded
	Lootster_SelfIsGuilded = IsInGuild() ~= nil;

	-- if we are unguilded, we can load data immediately
	if (Lootster_SelfIsGuilded == false) then
		-- load data
		Lootster_LoadData();

		-- mark as loaded
		Lootster_IsLoaded = true;
	else
		-- generate a guild roster event when the guild information is loaded
		GuildRoster();
	end

	-- hook chat frame event and hyperlink handler
	Lootster_ChatFrame_OnEventCB = ChatFrame_OnEvent;

	ChatFrame_OnEvent = Lootster_ChatFrame_OnEvent;

	Lootster_ChatFrame_OnHyperlinkShowCB = ChatFrame_OnHyperlinkShow;

	ChatFrame_OnHyperlinkShow = Lootster_ChatFrame_OnHyperlinkShow;

	Lootster_ChatFrame_AddMessageGroupCB = ChatFrame_AddMessageGroup;

	ChatFrame_AddMessageGroup = Lootster_ChatFrame_AddMessageGroup;

	Lootster_ChatFrame_RemoveMessageGroupCB = ChatFrame_RemoveMessageGroup;

	ChatFrame_RemoveMessageGroup = Lootster_ChatFrame_RemoveMessageGroup;

	Lootster_ChatFrame_RegisterForMessagesCB = ChatFrame_RegisterForMessages;

	ChatFrame_RegisterForMessages = Lootster_ChatFrame_RegisterForMessages;

	Lootster_ChatFrame_RemoveAllMessageGroupsCB = ChatFrame_RemoveAllMessageGroups;

	ChatFrame_RemoveAllMessageGroups = Lootster_ChatFrame_RemoveAllMessageGroups;

	-- hook each loot frame button item click handler
	for ix=1, LOOTFRAME_NUMBUTTONS do
		-- get this button
		button = _G["LootButton"..ix];
		
		-- see if we have a script to hook
		if (button:HasScript("OnClick") == 1) then
			-- get callback
			Lootster_LootButton_OnClickCB[button] = button:GetScript("OnClick");
		end

		-- and set our hook
		button:SetScript("OnClick", Lootster_LootButton_OnClick);
	end

	-- hook group loot frame show and event handlers
	Lootster_GroupLootFrame_OnShowCB = GroupLootFrame_OnShow;

	GroupLootFrame_OnShow = Lootster_GroupLootFrame_OnShow;
	
	Lootster_GroupLootFrame_OnEventCB = GroupLootFrame_OnEvent;

	GroupLootFrame_OnEvent = Lootster_GroupLootFrame_OnEvent;

	-- hook modified item click handling
	Lootster_HandleModifiedItemClickCB = HandleModifiedItemClick;

	HandleModifiedItemClick = Lootster_HandleModifiedItemClick;
	
	-- change custom channel, as required
	if ((Lootster_Options.AttendHere ~= true) or (Lootster_Options.AttendAnnounce ~= true) or (Lootster_Options.AttendCustom ~= true)) then
		-- leave channel
		Lootster_ChannelChange(nil, Lootster_Options.AttendCustomChannel);
	else
		-- join channel
		Lootster_ChannelChange(Lootster_Options.AttendCustomChannel, nil);
	end
	
	-- add internal report formatters
	Lootster_RegisterReport(LOOTSTER_REPORT_TEXTDETAIL,
							bit.bor(LOOTSTER_MASK_REPORTTYPE.FULL, LOOTSTER_MASK_REPORTTYPE.RAID, LOOTSTER_MASK_REPORTTYPE.BOSS, LOOTSTER_MASK_REPORTTYPE.SHOWSORT, LOOTSTER_MASK_REPORTTYPE.SHOWDETAIL),
							LOOTSTER_RAIDREPORT_TEXTDETAIL, LOOTSTER_RAIDREPORT_TEXTDETAIL_TT, Lootster_WriteReportDetail);

	Lootster_RegisterReport(LOOTSTER_REPORT_TEXTCONSOL,
							bit.bor(LOOTSTER_MASK_REPORTTYPE.FULL, LOOTSTER_MASK_REPORTTYPE.RAID, LOOTSTER_MASK_REPORTTYPE.SHOWSORT, LOOTSTER_MASK_REPORTTYPE.SHOWDETAIL),
							LOOTSTER_RAIDREPORT_TEXTCONSOL, LOOTSTER_RAIDREPORT_TEXTCONSOL_TT, Lootster_WriteReportConsolidate);

	Lootster_RegisterReport(LOOTSTER_REPORT_CTRT1_16_13,
							bit.bor(LOOTSTER_MASK_REPORTTYPE.RAID, LOOTSTER_MASK_REPORTTYPE.SELTEXT),
							LOOTSTER_RAIDREPORT_CTRT1_16_13, LOOTSTER_RAIDREPORT_CTRT1_16_13_TT, Lootster_WriteReportCTRT, 1.1613);
end

-- Player Logout handler
function Lootster_PLAYER_Logout()
	-- previous event state
	Lootster_EventState = Lootster_EventState - 1;
end

-- Player Enter World handler
function Lootster_PLAYER_Enter()
	local	change, zone;
	
	-- bump event state
	Lootster_EventState = Lootster_EventState + 1;
	
	-- register our addon comms prefix
	RegisterAddonMessagePrefix(LOOTSTER_ADDON_PREFIX);

	-- force a roster update
	Lootster_PARTY_Roster();

	-- initially select the running raid and boss, if any
	Lootster_RaidId = Lootster_Running.RaidId;
	Lootster_BossId = Lootster_Running.BossId;

	-- check for a zone change
	Lootster_WORLD_Update(true);
	
	-- see if instance information updated
	Lootster_CheckInstanceInfo();

	-- update roll screen
	Lootster_Roll_Update();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort loot using current sort
	Lootster_Loot_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);
	
	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);
	
	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- resort item using current sort
	Lootster_Item_Sort(nil);
	
	-- resort rank using current sort
	Lootster_Rank_Sort(nil);
	
	-- update usage data
	Lootster_Usage_Update();
	
	-- update event data
	Lootster_Event_Update();
	
	-- update item quality data
	Lootster_Quality_Update();
	
	-- update item slot data
	Lootster_Slot_Update();

	-- initialise roll UI
	Lootster_UpdateRollUI();

	-- initialise raid UI
	Lootster_UpdateRaidUI();
end

-- Player Leave World handler
function Lootster_PLAYER_Leave()
	-- previous event state
	Lootster_EventState = Lootster_EventState - 1;
end

-- Player Aggro handler
function Lootster_PLAYER_Regen(regen, delay)
	local	change;
	
	-- ignore if we are toasted
	if (UnitIsDeadOrGhost(Lootster_Self)) then
		return;
	end

	-- which way is the combat going
	if		(regen == true) then
		-- exiting combat.  Make sure our zone is the same as the raid
		if (Lootster_Running.RaidId ~= nil) then
			-- get the zone, if any
			change = Lootster_HasRaidZoneChanged();
			
			--  change of nil means no result for the moment
			if (change == nil) then
				-- the zone change event is already scheduled
				return;
			end
			
			--  a delay means we have received a leaving combat event
			if (delay == true) then
				-- this may arrive before the boss's UNIT_DIED event, so retry in 5 seconds
				Lootster_Scheduler_Enqueue(LOOTSTER_ENUM_SCHEDULERID.REGEN, 5, Lootster_PLAYER_Regen, true);
				return;
			end

			-- if no zone change and this is a boss attempt, mark as a wipe
			if ((change == false) and (Lootster_IsBossAttempt(Lootster_Running.BossId) == true)) then
				-- update the current boss as a wipe
				Lootster_UpdateBoss(Lootster_Running.BossId, LOOTSTER_ENUM_BOSSTYPE.BOSSWIPE);
			end
		end
	elseif	(regen == false) then
		-- was the current boss was in combat?
		if ((Lootster_Running.BossId ~= nil) and (Lootster_Boss[Lootster_Running.BossId].Type ~= LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT)) then
			--  a delay means we have received a leaving combat event
			if (delay == true) then
				-- this may arrive before the boss's UNIT_DIED event, so retry in 5 seconds
				Lootster_Scheduler_Enqueue(LOOTSTER_ENUM_SCHEDULERID.REGEN, 5, Lootster_PLAYER_Regen, false);
				return;
			end

			-- are we tracking bosses?
			if (Lootster_Options.AutoBoss == true) then
				-- previous boss fight is over - stop it
				Lootster_Boss_OnToggle(self);
				
				-- and start new one
				Lootster_Boss_OnToggle(self);
			end
		end
	end
end

-- Party/Raid Leader handler
function Lootster_PARTY_Leader()
	local	_, unit, pcount, player, ix, rank, partyIx, raidIx;

	-- get the loot mode
	Lootster_LootMode = GetLootThreshold();

	-- get the loot method
	Lootster_LootMethod = LOOTSTER_ENUM_LOOTMETHOD[string.upper(GetLootMethod())];

	-- determine if we are party or raid
	if		(GetNumGroupMembers() > 0) then
		-- get new player count
		pcount = GetNumGroupMembers()

		-- no loot master yet
		Lootster_LootMaster = nil;

		-- are we master looting?
		if		(Lootster_LootMethod == LOOTSTER_ENUM_LOOTMETHOD.MASTER) then
			-- grab the master looter raid index
			_, partyIx, raidIx = GetLootMethod();

			-- do we have a party index?
			if		(partyIx ~= nil) then
				-- is it us?
				if (partyIx == 0) then
					Lootster_LootMaster = Lootster_Self;
				else
					Lootster_LootMaster = UnitName("party"..partyIx);
				end
			elseif	(raidIx ~= nil) then
				Lootster_LootMaster = UnitName("raid"..raidIx);
			end
		elseif	(UnitIsGroupLeader("player")() == true) then
			-- we are the man!
			Lootster_LootMaster = Lootster_Self;
		end

		-- if loot master not resolved yet, manually locate raid leader
		if ((Lootster_LootMaster == nil) or (Lootster_LootMaster == UNKNOWNOBJECT)) then
			-- still no loot master
			Lootster_LootMaster = nil;

			-- get the raid attend
			for ix=1, pcount, 1 do
				-- form the unit name
				unit = "raid"..ix;

				-- get the player name
				player = UnitName(unit);

				-- no player (no information there yet) or unknown, move on
				if ((player ~= nil) and (player ~= UNKNOWNOBJECT)) then
					-- get rank in the raid
					_, rank = GetRaidRosterInfo(ix);

					if (rank == 2) then
						-- they are the man!
						Lootster_LootMaster = player;
						break;
					end
				end
			end
		end
	elseif	(GetNumSubgroupMembers() > 0) then
		-- get new player count
		pcount = GetNumSubgroupMembers();

		-- no loot master yet
		Lootster_LootMaster = nil;

		-- are we master looting?
		if		(Lootster_LootMethod == LOOTSTER_ENUM_LOOTMETHOD.MASTER) then
			-- grab the master looter party index
			_, partyIx = GetLootMethod();

			-- do we have a party index?
			if (partyIx ~= nil) then
				-- is it us?
				if (partyIx == 0) then
					Lootster_LootMaster = Lootster_Self;
				else
					Lootster_LootMaster = UnitName("party"..partyIx);
				end
			end
		elseif	(IsPartyLeader() ~= nil) then
			-- we are the man!
			Lootster_LootMaster = Lootster_Self;
		end

		-- if loot master not resolved yet, manually locate raid leader
		if ((Lootster_LootMaster == nil) or (Lootster_LootMaster == UNKNOWNOBJECT)) then
			-- still no loot master
			Lootster_LootMaster = nil;

			-- get the party leader index
			partyIx = GetPartyLeaderIndex();

			-- form the unit name
			unit = "party"..partyIx;

			-- get the player name
			player = UnitName(unit);

			-- no player (no information there yet) or unknown, move on
			if ((player ~= nil) and (player ~= UNKNOWNOBJECT)) then
				-- they are the man!
				Lootster_LootMaster = player;
			end
		end
	else
		-- we are the man!
		Lootster_LootMaster = Lootster_Self;
	end
end

-- Guild Roster Update handler
function Lootster_GUILD_Roster()
	local	_;

	-- are we yet to load data?
	if (Lootster_IsLoaded == false) then
		-- retrieve our guild and guild rank
		Lootster_SelfGuild, _, Lootster_SelfRank = GetGuildInfo("player");

		-- load guild ranks
		Lootster_LoadGuildRanks();

		-- load our guild player information
		Lootster_LoadGuildieInfo();

		-- load data
		Lootster_LoadData();

		-- force a roster update
		Lootster_PARTY_Roster();

		-- resort data DKP using current sort
		Lootster_Data_DKP_Sort(nil);

		-- resort rank using current sort
		Lootster_Rank_Sort(nil);

		-- update roll handling to reflect new guild information
		Lootster_UpdateRollUI();

		-- mark as loaded
		Lootster_IsLoaded = true;
	end
end

-- Party/Raid Roster handler
function Lootster_PARTY_Roster()
	local	wasGrouped, unit, pcount, player, class, classType, name, main;

	local   adj, key;
	
	local	change, zone, boss;
	
	-- snarf whether player was previously grouped
	wasGrouped = Lootster_Grouped;

	-- reset attendance list
	Lootster_Roster = {};

	if		(GetNumGroupMembers() > 0) then
		-- get new player count
		pcount = GetNumGroupMembers()

		Lootster_PlayerCount = pcount;

		-- get the raid attend
		for ix=1, pcount,1 do
			-- form the unit name
			unit = "raid"..ix;

			-- get the player name
			player = UnitName(unit);

			-- no player (no information there yet) or unknown, move on
			if ((player ~= nil) and (player ~= UNKNOWNOBJECT)) then
				-- get the player class
				class, classType = UnitClass(unit);

				-- force player name to lower case for later matching
				name = string.lower(player);

				-- and bookkeep
				Lootster_Roster[player] = Lootster_NewRoster(name, class, classType);
			else
				-- adjust the player count
				Lootster_PlayerCount = Lootster_PlayerCount - 1;
			end
		end
	elseif	(GetNumSubgroupMembers() > 0) then
		-- get new player count
		pcount = GetNumSubgroupMembers();

		Lootster_PlayerCount = pcount;

		-- get the raid attend
		for ix=1, pcount, 1 do
			-- form the unit name
			unit = "party"..ix;

			-- get the player name
			player = UnitName(unit);

			-- no player (no information there yet) or unknown, move on
			if ((player ~= nil) and (player ~= UNKNOWNOBJECT)) then
				-- get the player class
				class, classType = UnitClass(unit);

				-- force player name to lower case for later matching
				name = string.lower(player);

				-- and bookkeep
				Lootster_Roster[player] = Lootster_NewRoster(name, class, classType);
			else
				-- adjust the player count
				Lootster_PlayerCount = Lootster_PlayerCount - 1;
			end
		end

		-- add us
		Lootster_PlayerCount = Lootster_PlayerCount + 1;
	else
		-- just us
		Lootster_PlayerCount = 1;
	end
	
	-- let Blizzard tell us if we are really really grouped
	Lootster_Grouped = UnitInParty("player") or UnitInRaid("player");

	-- force ourselves to lower case for later matching
	name = string.lower(Lootster_Self);

	Lootster_Roster[Lootster_Self] = Lootster_NewRoster(name, Lootster_SelfClass, Lootster_SelfClassType);

	-- establish party/raid leadership for master looter
	Lootster_PARTY_Leader();

	-- iterate through roll table looking for ex-parrots
	for key, value in pairs(Lootster_Rolls) do
		-- in the roster?
		if (Lootster_Roster[key] == nil) then
			-- if this guy actually rolled, adjust the roll count
			if (value.Roll ~= nil) then
				Lootster_RollCount = Lootster_RollCount - 1;
			end

			-- remove the record
			Lootster_Rolls[key] = nil;
		end
	end

	-- iterate through tied roll table looking for ex-parrots
	for key, value in pairs(Lootster_TiedRolls) do
		-- in the roster?
		if (Lootster_Roster[key] == nil) then
			-- if this guy actually rolled, adjust the roll count
			if (value.Roll ~= nil) then
				Lootster_TiedRollCount = Lootster_TiedRollCount - 1;
			end

			-- remove the record
			Lootster_TiedRolls[key] = nil;
		end
	end

	-- reset Main/Alt Look-aside Tables
	Lootster_DKPMainAlt = {};
	Lootster_GuildieMainAlt = {};

	-- create the Main/Alt Look-aside Tables for the current roster
	for player, rosRec in pairs(Lootster_Roster) do
		-- is this guy a DKP alt?
		if (Lootster_DKPAltMain[player] ~= nil) then
			-- set this as the main
			main = Lootster_DKPAltMain[player];
			
			-- add this guy to the DKP Main to Alt look-aside table
			Lootster_DKPMainAlt[main] = player;
		else
			-- this is the main
			main = player;
		end

		-- is this guy a Guild alt?
		if (Lootster_GuildieAltMain[player] ~= nil) then
			-- add this guy to the Guild Main to Alt look-aside table
			Lootster_GuildieMainAlt[Lootster_GuildieAltMain[player]] = player;
		end
		
		-- make sure this main has a DKP entry
		if (Lootster_DKP[main] == nil) then
			-- create DKP entry for main
			Lootster_DKP[main] = Lootster_NewDKP(main, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.APP);
		end
	end
	
	-- update restricted count
	Lootster_UpdateRestricted();

	-- resort rolls
	Lootster_Roll_Sort();

	-- update the screen
	Lootster_Roll_Update();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- update received roll status
	Lootster_UpdateRollUI();
end

-- Loot Opened handler
function Lootster_LOOT_Opened()
end

-- Loot Closed handler
function Lootster_LOOT_Closed()
	-- clear item link if we are using the loot item and not autolooting the roll mode
	if (Lootster_ItemSlot ~= nil) then
		-- are we auto-bookkeeping loot for the respective roll mode?
		if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.AutoDKPLoot == true)) or
			((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.AutoNonDKPLoot == true))) then
			-- reset the hyperlinks
			Lootster_SetHyperlink(nil);
		end
	end
end

-- Loot Slot Cleared handler
function Lootster_LOOT_Slot_Cleared(slot)
	-- reset our item if this was the guy that was toasted
	if (slot == Lootster_ItemSlot) then
		Lootster_LOOT_Closed();
	end
end

-- Loot Message handler
function Lootster_MSG_Loot(msg)
	local	 _, player, itemLink, multi, itemId, itemText, itemQual, count, ix, usage, dkp, reason, items, type, adjustId, main, dateNow;
	
	-- are we bookkeeping loot?
	if ((Lootster_Options.AutoDKPLoot == false) and (Lootster_Options.AutoNonDKPLoot == false)) then
		-- not bookkeeping
		return;
	end
	
	-- no boss and we are not auto-creating bosses?
	if ((Lootster_Running.BossId == nil) and (Lootster_Options.AutoLootRaid == false)) then
		-- not bookkeeping
		return;
	end

	-- attempt to parse loot message
	_, _, player, itemLink, _, _, _, multi = string.find(msg, LOOTSTER_LOOT_PLAYER_PATTERN);

	-- player loot?
	if ((player == nil) or (itemLink == nil)) then
		-- nope, check us
		_, _, itemLink, _, _, _, multi = string.find(msg, LOOTSTER_LOOT_SELF_PATTERN);

		-- a link?
		if (itemLink == nil) then
			-- no clue
			return;
		end
		
		-- we won something
		player = Lootster_Self;
	end
	
	-- retrieve the item text and, quality
	itemId, itemText, itemQual = Lootster_GetItemBasics(itemLink);
	
	-- is this loot fake (a la badges)?
	if (LOOTSTER_LOOT_FAKE[itemId] ~= nil) then
		-- don't bother recording
		return;
	end

	-- are we tracking this quality level?
	if (itemQual < Lootster_Options.LootMode) then
		-- not good enough
		return;
	end

	-- if we have multiple items, determine count
	if (multi ~= nil) then
		_, _, count = string.find(multi, LOOTSTER_LOOT_MULTIITEM_PATTERN);

		-- did we have a numeric count?
		if (count ~= nil) then
			-- convert to numeric
			count = tonumber(count);
		else
			-- just one item
			count = 1;
		end
	else
		-- just one item
		count = 1;
	end

	-- determine what kind of loot this is (DKP or non-DKP)
	dkp, reason, items = Lootster_GetItemDKP(itemText, itemLink);

	-- is this a DKP item and tracking non-DKP loot?
	if		((items == 0) and (Lootster_Options.AutoNonDKPLoot == false)) then
		-- don't bother with non-DKP loot
		return;
	elseif	((items ~= 0) and (Lootster_Options.AutoDKPLoot == false)) then
		-- don't bother with DKP loot
		return;
	end

	-- do we have a running raid?
	if		(Lootster_Running.RaidId == nil) then
		-- determine zone type
		_, _, type = Lootster_HasRaidZoneChanged();
		
		-- do we track this type of zone?
		if ((type ~= LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) and (Lootster_Options.Track[type] == true)) then
			-- yarp, so create a raid
			Lootster_Raid_OnToggle(self);
		else
			-- we don't bookkeep raids in this zone, so ignore
			return;
		end
	elseif	(Lootster_Running.BossId == nil) then
		-- nope, so create a boss
		Lootster_Boss_OnToggle(self);
	end
	
	-- get the main for this player, if applicable
	main = Lootster_GetAltMain(player);

	-- get the current server time
	dateNow = Lootster_CalcServerTime(time());

	-- mark as primary use
	usage =  LOOTSTER_ENUM_USAGE.MAINNEED;
	
	-- calculate the usage factors
	dkp = Lootster_CalcUsageDKP(main, player, usage, dkp);
	
	-- and normalise
	dkp = Lootster_CalcPoints(dkp);
				
	-- process each item seperately
	for ix=1, count do
		-- see if this loot was assigned
		adjustId = Lootster_FindAssign(main, itemLink, LOOTSTER_ENUM_TOBEASSIGNED.BOOKED);
		
		if (adjustId ~= nil) then
			-- copy the existing record
			adjustRec = Lootster_CopyRecord(Lootster_Adjust[adjustId]);
			
			-- match the TBA flag and reset assign key
			adjustRec.TBA = LOOTSTER_ENUM_TOBEASSIGNED.MATCHED;
			adjustRec.AssignKey = nil;
			
			-- and modify the adjustment
			Lootster_ModifyAdjust(adjustRec, true);
		else
			-- create adjustment as to be assigned
			adjustId = Lootster_CreateAdjust(Lootster_NewAdjust(main, player, dateNow, 0, dkp, usage, itemLink, reason, "", LOOTSTER_ENUM_TOBEASSIGNED.LOOTED));
			
			-- create an assign key
			Lootster_Adjust[adjustId].AssignKey = Lootster_CreateAssignKey(main, itemLink);
					
			-- is this a banked item and we have an official banker?
			if ((LOOTSTER_USAGE_BANKED[usage] == true) and (Lootster_Options.Banker ~= nil)) then
				-- we need to hammer the player and alt to the banker
				Lootster_Adjust[adjustId].Player = Lootster_Options.Banker;
				Lootster_Adjust[adjustId].Alt = Lootster_Options.Banker;
			end
					
			-- add this adjustment to the running boss
			Lootster_InsertAdjust(Lootster_Running.BossId, adjustId);
		end
	end

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Party/Raid Message handler
function Lootster_MSG_PartyRaid(msg, player)
	-- see if it was a pass/reclaim
	if		(string.lower(msg) == LOOTSTER_CMD_PASS) then
		-- let the player pass their roll
		Lootster_PassRoll(player);
	elseif	(string.lower(msg) == LOOTSTER_CMD_RECLAIM) then
		-- let the player reclaim their roll
		Lootster_ReclaimRoll(player);
	end
end

-- Addon Message handler
function Lootster_MSG_Addon(prefix, msg, type, player)
	local	_, addoncmd, payload;

	-- ignore all but our party/raid messages
	if ((prefix == LOOTSTER_ADDON_PREFIX) and ((type == "PARTY") or (type == "RAID"))) then
		-- is this a continutation record?
		if		((string.len(msg) == LOOTSTER_ADDON_MESSAGELEN) and (string.sub(msg, -1) == LOOTSTER_ADDON_POSTFIXCONT)) then
			-- continuation records are received after initiation
			if	((Lootster_CallType == nil) or (Lootster_CallUser ~= player)) then
				-- eep!  Player is not our addon sender - no message as it can spam
				return false;
			end

			-- have we a current continuation record?
			if (Lootster_CallCont == nil) then
				-- snarf initial continuation record
				Lootster_CallCont = string.sub(msg, 1, -2);
			else
				-- next continuation record - just add payload sans continuation marker
				Lootster_CallCont = Lootster_CallCont..string.sub(msg, 1, -2);
			end
			return true;
		elseif	(Lootster_CallCont ~= nil) then
			-- continuation records are received after initiation
			if	((Lootster_CallType == nil) or (Lootster_CallUser ~= player)) then
				-- eep!  Player is not our addon sender - no message as it can spam
				return false;
			end

			-- final continuation record - add payload and make this the real message
			msg = Lootster_CallCont..msg;

			-- reset continuation record
			Lootster_CallCont = nil;
		end

		-- extract addon command and payload
		_, _, addoncmd, payload	= string.find(msg, LOOTSTER_ADDON_IMP_COMMAND);
		-- pass to addon process
		LOOTSTER_ADDON_Process(player, addoncmd, payload);
	end
end

-- System Message handler
function Lootster_MSG_System(msg)
	local	_, player, roll, min_roll, max_roll;

	-- attempt to decode /random roll
	_, _, player, roll, minRoll, maxRoll = string.find(msg, LOOTSTER_ROLL_PATTERN);

	-- if we have a player we have a playa
	if (player ~= nil) then
		Lootster_ProcessRoll(player, roll, minRoll, maxRoll);
	end
end

-- Whisper Message handler
function Lootster_MSG_Whisper(msg, player)
	-- pass to our inquiry handler
	Lootster_PlayerInquiry(player, msg);
end

-- Monster Yell Message handler
function Lootster_MSG_MonsterYell(msg, boss)
	local	npcId, killSet;
	
	-- no boss means we are done
	if (boss == nil) then
		return;
	end
	
	-- are we starting a boss attempt or in a boss attempt and this boss is yelling uncle?
	if		(not Lootster_IsBossAttempt(Lootster_Running.BossId) and (LOOTSTER_YELL_BOSS_START[boss] ~= nil) and (LOOTSTER_YELL_BOSS_START[boss].MSG == msg)) then
		-- get the NPC Id
		npcId = LOOTSTER_YELL_BOSS_START[boss].BOSSID;
		
		-- see if we have a translation look-aside buffer for this boss
		if (LOOTSTER_BOSS_TLB[npcId] ~= nil) then
			-- use this underlying boss's ID
			npcId = LOOTSTER_BOSS_TLB[npcId];
		end
		
		-- have we a group fight name for this boss?
		if (LOOTSTER_BOSS_NAME[npcId] ~= nil) then
			-- use the group's name
			boss = LOOTSTER_BOSS_NAME[npcId];
		end

		-- have we a kill list for this boss?
		if (LOOTSTER_BOSS_KILL[npcId] ~= nil) then
			-- copy this boss's kill list
			killSet = Lootster_CopyRecord(LOOTSTER_BOSS_KILL[npcId]);
		end
		
		-- start a boss attempt as necessary
		Lootster_StartBossAttempt(npcId, boss, killSet);
	elseif	(Lootster_IsBossAttempt(Lootster_Running.BossId) and (Lootster_Boss[Lootster_Running.BossId].Boss == boss) and (LOOTSTER_YELL_BOSS_FINISH[boss] == msg)) then
		-- mark boss as toast
		Lootster_UpdateBoss(Lootster_Running.BossId, LOOTSTER_ENUM_BOSSTYPE.BOSSKILL);
	end
end

-- System Chat handler
function Lootster_CHAT_System(self, event, ...)
	local	msg, player	= ...;

	-- snarf /randoms
	if (msg == nil) or (not Lootster_Options.Suppress) or (not string.find(msg, LOOTSTER_ROLL_PATTERN)) then
		-- not a suppressed roll, so pass to callback
		Lootster_ChatFrame_OnEventCB(self, event, ...);
	end
end

-- Whisper Chat Message handler
function Lootster_CHAT_Whisper(self, event, ...)
	local	msg, player	= ...;

	-- don't echo whisper if a foreign player inquiry (don't execute!) or debug is on
	if ((msg == nil) or (player == Lootster_Self) or (Lootster_PlayerInquiry(player, msg, true) == false) or 
		(Lootster_Options.DebugMsgs == true)) then
		-- unless debugging, suppress internal Lootster messages
		if ((Lootster_Options.DebugMsgs == true) or (string.find(msg, LOOTSTER_SYNC_IMP_PREFIX) == nil)) then  
			-- punt this out
			Lootster_ChatFrame_OnEventCB(self, event, ...);
		end
	end
end

-- Whisper Inform Chat Message handler
function Lootster_CHAT_Whisper_Inform(self, event, ...)
	local	msg, player	= ...;
	local	mask;

	-- no message, echoing debug messages or nothing in the from whisper from queue for this guy? 
	if ((msg == nil) or (Lootster_Options.DebugMsgs == true) or (Lootster_FromWhisperQue == nil) or (Lootster_FromWhisperQue[player] == nil) or 
		(Lootster_FromWhisperQue[player][1].Msg ~= msg)) then
		-- unless debugging, suppress internal Lootster messages
		if ((Lootster_Options.DebugMsgs == true) or (string.find(msg, LOOTSTER_SYNC_IMP_PREFIX) == nil)) then  
			-- punt this out
			Lootster_ChatFrame_OnEventCB(self, event, ...);
		end
	else
		-- calculate chat frame mask
		mask = bit.bor(Lootster_FromWhisperQue[player][1].Mask, bit.lshift(1, self:GetID()));

		-- is this guy been reported by all whisper chat frames?
		if (mask == Lootster_ChatMaskWhisper) then
			-- remove this message
			table.remove(Lootster_FromWhisperQue[player], 1);

			-- if we have no more from whispers, smoke the player queue
			if (#Lootster_FromWhisperQue[player] == 0) then	
				-- smoke the player's queue entry
				Lootster_FromWhisperQue[player] = nil;
			end
		else
			-- update the message's whisper chat mask
			Lootster_FromWhisperQue[player][1].Mask = mask;
		end
	end
end

-- World Update handler
function Lootster_WORLD_Update(delay)
	local	change, zone, type;
	
	-- determine zone
	change, zone, type = Lootster_HasRaidZoneChanged(delay);
	
	-- has zone changed?
	if		(change == true) then
		-- yes, so see if we are auto-tracking raids
		if (Lootster_Options.AutoRaid == true) then
			-- have we are running raid?
			if (Lootster_Running.RaidId ~= nil) then
				-- toggle off raid
				Lootster_Raid_OnToggle(self);
			end

			-- do we have a new raid?
			if ((type ~= LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) and (Lootster_Options.Track[type] == true)) then
				-- toggle a new raid
				Lootster_Raid_OnToggle(self);
				
				-- fake aggro handling being reset
				Lootster_PLAYER_Regen(true, true);
			end
		end
	elseif	(change == false) then
		-- fake aggro handling being reset
		Lootster_PLAYER_Regen(true, true);
	end
end

-- Update Instance Information handler
function Lootster_UPDATE_Instance()
	-- update the running raid, if any
	if (Lootster_CheckInstanceInfo() == true) then
		-- resort raid raid using current sort
		Lootster_Raid_Raid_Sort(nil);
	end
end

-- Check Location handler
function Lootster_CheckLocation()
	local width			= Lootster_RollFrame:GetWidth();
	local width2		= width / 2;
	local height		= Lootster_RollFrame:GetHeight();

	local tabwidth		= Lootster_TabsFrame:GetWidth();
	local tabheight		= Lootster_TabsFrame:GetHeight();

	Lootster_RollFrame:ClearAllPoints();
	Lootster_RollFrame:SetPoint("TOPLEFT", "Lootster_Title", "BOTTOM", -width2, 0);
	Lootster_RollFrame:SetPoint("TOPRIGHT", "Lootster_Title", "BOTTOM", width2, 0);

	Lootster_TabsFrame:ClearAllPoints();
	Lootster_TabsFrame:SetPoint("TOPLEFT", "Lootster_RollFrame", "BOTTOMLEFT", 0, 7);
	Lootster_TabsFrame:SetPoint("TOPRIGHT", "Lootster_RollFrame", "BOTTOMLEFT", tabwidth, 7-tabheight);

	Lootster_ClassFrame:ClearAllPoints();
	Lootster_ClassFrame:SetPoint("TOPLEFT", "Lootster_RollFrame", "TOPRIGHT", -7, 0);
end

-- Check Echo Use handler
function Lootster_CheckEchoUse()
	-- are we allowing click display of class restrictions?
	if (Lootster_Options.EchoRestrict == false) then
		-- disable echo To check boxes
		Lootster_OptionsFrameEchoToChat:Disable();
		Lootster_OptionsFrameEchoToRW:Disable();

		-- disable echo By check boxes
		Lootster_OptionsFrameEchoByClick:Disable();
		Lootster_OptionsFrameEchoByGroupLoot:Disable();
	else
		-- enable echo To check boxes
		Lootster_OptionsFrameEchoToChat:Enable();
		Lootster_OptionsFrameEchoToRW:Enable();

		-- enable echo By check boxes
		Lootster_OptionsFrameEchoByClick:Enable();
		Lootster_OptionsFrameEchoByGroupLoot:Enable();
	end
end		

-- Check Mode Use handler
function Lootster_CheckModeUse()
	-- show the mode widgets as required
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- show the data tab
		Lootster_DataTab:Show();
		Lootster_LootTab:Show();

		-- show anchors to force repaint
		Lootster_Anchor1Tab:Show();
		Lootster_Anchor2Tab:Show();
		Lootster_Anchor3Tab:Show();

		-- move raid tab relative to item tab
		Lootster_RaidTab:ClearAllPoints();
		Lootster_RaidTab:SetPoint("TOPLEFT", "Lootster_Anchor3Tab", "TOPLEFT", 0, 0);
		Lootster_RaidTab:SetPoint("BOTTOMRIGHT", "Lootster_Anchor3Tab", "BOTTOMRIGHT", 0, 0);

		-- and rehide anchors
		Lootster_Anchor3Tab:Hide();
		Lootster_Anchor2Tab:Hide();
		Lootster_Anchor1Tab:Hide();

		-- update rolling UI
		Lootster_CheckRollUse();

		-- show DKP heading for roll tab
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- update points prompt
			Lootster_RollFrameDKPLabel:SetText(LOOTSTER_ROLL_POINTSGP);

			-- PR=EP/GP		
			Lootster_RollFrameColumnHeader3:SetText(LOOTSTER_ROLL_PREPGP);
		else
			-- update points prompt
			Lootster_RollFrameDKPLabel:SetText(LOOTSTER_ROLL_POINTSDKP);

			-- DKP
			Lootster_RollFrameColumnHeader3:SetText(LOOTSTER_ROLL_DKP);
		end
		
		-- usage rolling - does not apply to modified roll by DKP?
		if ((Lootster_Options.UsageRolls == true) and (Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYMODIFIEDROLL)) then
			-- Usage
			Lootster_RollFrameColumnHeader4:SetText(LOOTSTER_ROLL_USAGE);
		else
			-- no Usage
			Lootster_RollFrameColumnHeader4:SetText("");
		end
	
		-- show result heading for roll tab
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			-- Tiers
			Lootster_RollFrameColumnHeader5:SetText(LOOTSTER_ROLL_RESULTTIER);
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
			-- DKP+Roll
			Lootster_RollFrameColumnHeader5:SetText(LOOTSTER_ROLL_RESULTDKPPROLL);
		else
			-- no heading
			Lootster_RollFrameColumnHeader5:SetText("");
		end

		-- show DKP membership heading for roll tab
		if (Lootster_Options.DKPMember == true) then
			-- Membership
			Lootster_RollFrameColumnHeader6:SetText(LOOTSTER_ROLL_MEMBER);
		else
			-- no heading
			Lootster_RollFrameColumnHeader6:SetText("");
		end

		-- show DKP toon heading for roll tab
		if (Lootster_Options.DKPToon == true) then
			-- Toon
			Lootster_RollFrameColumnHeader7:SetText(LOOTSTER_ROLL_TOON);
		else
			-- no heading
			Lootster_RollFrameColumnHeader7:SetText("");
		end

		-- show DKP heading for DKP tab
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- PR=EP/GP
			Lootster_DataFrameDKPFrameColumnHeader3:SetText(LOOTSTER_DATA_PREPGP);
			Lootster_DataFrameDKPFrameColumnHeader4:SetText(LOOTSTER_DATA_EPTOT);
			Lootster_DataFrameDKPFrameColumnHeader5:SetText(LOOTSTER_DATA_GPTOT);
			
			Lootster_DataFrameAttendFrameColumnHeader3:SetText(LOOTSTER_DATA_EPATT);
			Lootster_DataFrameAttendFrameColumnHeader4:SetText(LOOTSTER_DATA_EPADJ);
			Lootster_DataFrameAttendFrameColumnHeader5:SetText(LOOTSTER_DATA_GPADJ);
			
			Lootster_DataFrameAdjustFrameColumnHeader3:SetText(LOOTSTER_DATA_EPADJ);
			Lootster_DataFrameAdjustFrameColumnHeader4:SetText(LOOTSTER_DATA_GPADJ);
		else
			-- DKP
			Lootster_DataFrameDKPFrameColumnHeader3:SetText(LOOTSTER_DATA_DKP);
			Lootster_DataFrameDKPFrameColumnHeader4:SetText(LOOTSTER_DATA_DKPEARNT);
			Lootster_DataFrameDKPFrameColumnHeader5:SetText(LOOTSTER_DATA_DKPSPENT);
			
			Lootster_DataFrameAttendFrameColumnHeader3:SetText(LOOTSTER_DATA_DKPATTEARNT);
			Lootster_DataFrameAttendFrameColumnHeader4:SetText(LOOTSTER_DATA_DKPADJEARNT);
			Lootster_DataFrameAttendFrameColumnHeader5:SetText(LOOTSTER_DATA_DKPADJSPENT);
			
			Lootster_DataFrameAdjustFrameColumnHeader3:SetText(LOOTSTER_DATA_DKPADJEARNT);
			Lootster_DataFrameAdjustFrameColumnHeader4:SetText(LOOTSTER_DATA_DKPADJSPENT);
		end
		
		-- show/hide the DKP tier if we are in tier mode on DKP tab
		if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			Lootster_DataFrameDKPFrameColumnHeader6:SetText(LOOTSTER_DATA_TIER);
		else
			Lootster_DataFrameDKPFrameColumnHeader6:SetText("");
		end

		-- show DKP heading for raid, boss, attend and adjust tabs
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- PR=EP/GP
			Lootster_RaidFrameRaidFrameColumnHeader6:SetText(LOOTSTER_RAID_EP);
			Lootster_RaidFrameRaidFrameColumnHeader7:SetText(LOOTSTER_RAID_GP);
			Lootster_RaidFrameBossFrameColumnHeader6:SetText(LOOTSTER_RAID_EP);
			Lootster_RaidFrameBossFrameColumnHeader7:SetText(LOOTSTER_RAID_GP);
			Lootster_RaidFrameBossAttendFrameColumnHeader4:SetText(LOOTSTER_RAID_ATTEP);
			Lootster_RaidFrameBossAttendFrameColumnHeader5:SetText(LOOTSTER_RAID_ADJEP);
			Lootster_RaidFrameBossAttendFrameColumnHeader6:SetText(LOOTSTER_RAID_ADJGP);
			Lootster_RaidFrameBossAdjustFrameColumnHeader2:SetText(LOOTSTER_RAID_ADJEP);
			Lootster_RaidFrameBossAdjustFrameColumnHeader3:SetText(LOOTSTER_RAID_ADJGP);
		else
			-- DKP
			Lootster_RaidFrameRaidFrameColumnHeader6:SetText(LOOTSTER_RAID_DKPEARNT);
			Lootster_RaidFrameRaidFrameColumnHeader7:SetText(LOOTSTER_RAID_DKPSPENT);
			Lootster_RaidFrameBossFrameColumnHeader6:SetText(LOOTSTER_RAID_DKPEARNT);
			Lootster_RaidFrameBossFrameColumnHeader7:SetText(LOOTSTER_RAID_DKPSPENT);
			Lootster_RaidFrameBossAttendFrameColumnHeader4:SetText(LOOTSTER_RAID_DKPATTEARNT);
			Lootster_RaidFrameBossAttendFrameColumnHeader5:SetText(LOOTSTER_RAID_DKPADJEARNT);
			Lootster_RaidFrameBossAttendFrameColumnHeader6:SetText(LOOTSTER_RAID_DKPADJSPENT);
			Lootster_RaidFrameBossAdjustFrameColumnHeader2:SetText(LOOTSTER_RAID_DKPADJEARNT);
			Lootster_RaidFrameBossAdjustFrameColumnHeader3:SetText(LOOTSTER_RAID_DKPADJSPENT);
		end
		
		-- update rule table show rules label
		Lootster_RuleFrameRulesFrameLabel:SetFormattedText(LOOTSTER_RULE_RULE, LOOTSTER_ROLLMODE_LIST[Lootster_Options.RollMode]);
		
		-- update rules tab with DKP rules
		Lootster_RuleFrameRulesFrameText:SetText(Lootster_Rules.RulesDKP);
		
		-- if we have usage rolling, show the usage rolls rules button
		if ((Lootster_Options.UsageRolls == true) and (Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYMODIFIEDROLL)) then
			-- show usage rolls rules button
			Lootster_RuleFrameUsageFrame:Show();
		else
			-- hide usage rolls rules button
			Lootster_RuleFrameUsageFrame:Hide();
		end

		-- setup the roll type for using DKP
		Lootster_Option_RollType_OnShow(self);

		-- show the DKP mode option frame
		Lootster_OptionsFrameRollManageDKPFrame:Show();

		-- what kind of DKP we using?
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then 
			-- show DKP limit frame
			Lootster_OptionsFrameRollManageDKPDKPFrame:Show();

			-- hide EPGP limit frame
			Lootster_OptionsFrameRollManageDKPEPGPFrame:Hide();

			-- hide DKP and roll factoring frames
			Lootster_OptionsFrameDKPFactorFrame:Hide();
			Lootster_OptionsFrameRollFactorFrame:Hide();
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			-- show DKP limit frame
			Lootster_OptionsFrameRollManageDKPDKPFrame:Show();

			-- hide EPGP limit frame
			Lootster_OptionsFrameRollManageDKPEPGPFrame:Hide();

			-- hide DKP and roll factoring frames
			Lootster_OptionsFrameDKPFactorFrame:Hide();
			Lootster_OptionsFrameRollFactorFrame:Hide();
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
			-- show DKP limit frame
			Lootster_OptionsFrameRollManageDKPDKPFrame:Show();

			-- hide EPGP limit frame
			Lootster_OptionsFrameRollManageDKPEPGPFrame:Hide();

			-- show DKP factoring frame
			Lootster_OptionsFrameDKPFactorFrame:Show();

			-- hide Roll factoring frame
			Lootster_OptionsFrameRollFactorFrame:Hide();
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
			-- show DKP limit frame
			Lootster_OptionsFrameRollManageDKPDKPFrame:Show();

			-- hide EPGP limit frame
			Lootster_OptionsFrameRollManageDKPEPGPFrame:Hide();

			-- show Roll factoring frame
			Lootster_OptionsFrameRollFactorFrame:Show();

			-- hide DKP factoring frame
			Lootster_OptionsFrameDKPFactorFrame:Hide();
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- hide DKP limit frame
			Lootster_OptionsFrameRollManageDKPDKPFrame:Hide();

			-- show EPGP limit frame
			Lootster_OptionsFrameRollManageDKPEPGPFrame:Show();
		end

		-- hide the Normal mode option frame
		Lootster_OptionsFrameRollManageNormFrame:Hide();

		-- show adjustment DKP edit box and default button
		Lootster_RaidFrameAdjustFrameDKP:Show();
		Lootster_RaidFrameAdjustFrameDKPDefault:Show();
		
		-- show earnt/spent options
		Lootster_RaidFrameAdjustFrameDKPValueEarnt:Show();
		Lootster_RaidFrameAdjustFrameDKPValueSpent:Show();
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- hide the data tab
		Lootster_DataTab:Hide();
		Lootster_LootTab:Hide();

		-- show anchors to force repaint
		Lootster_Anchor1Tab:Show();
		Lootster_Anchor2Tab:Show();
		Lootster_Anchor3Tab:Show();

		-- move item tab relative to data tab
		Lootster_RaidTab:ClearAllPoints();
		Lootster_RaidTab:SetPoint("TOPLEFT", "Lootster_Anchor1Tab", "TOPLEFT", 0, 0);
		Lootster_RaidTab:SetPoint("BOTTOMRIGHT", "Lootster_Anchor1Tab", "BOTTOMRIGHT", 0, 0);

		-- and rehide anchors
		Lootster_Anchor3Tab:Hide();
		Lootster_Anchor2Tab:Hide();
		Lootster_Anchor1Tab:Hide();

		-- update rolling UI
		Lootster_CheckRollUse();

		-- erase DKP heading for roll tab
		Lootster_RollFrameColumnHeader3:SetText("");

		-- what Normal mode are we using?
		if (Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
			-- set result heading to Need or Greed
			Lootster_RollFrameColumnHeader4:SetText(LOOTSTER_ROLL_USAGEN_G);
		else
			-- erase result heading for roll tab
			Lootster_RollFrameColumnHeader4:SetText("");
		end

		-- erase result heading for roll tab
		Lootster_RollFrameColumnHeader5:SetText("");

		-- show Normal membership heading for roll tab
		if (Lootster_Options.NormMember == true) then
			-- Membership
			Lootster_RollFrameColumnHeader6:SetText(LOOTSTER_ROLL_MEMBER);
		else
			-- no heading
			Lootster_RollFrameColumnHeader6:SetText("");
		end

		-- show Normal toon heading for roll tab
		if (Lootster_Options.NormToon == true) then
			-- Toon
			Lootster_RollFrameColumnHeader7:SetText(LOOTSTER_ROLL_TOON);
		else
			-- no heading
			Lootster_RollFrameColumnHeader7:SetText("");
		end

		-- erase DKP heading for raid, boss, attend and adjust tabs
		Lootster_RaidFrameRaidFrameColumnHeader6:SetText("");
		Lootster_RaidFrameRaidFrameColumnHeader7:SetText("");
		Lootster_RaidFrameBossFrameColumnHeader6:SetText("");
		Lootster_RaidFrameBossFrameColumnHeader7:SetText("");
		Lootster_RaidFrameBossAttendFrameColumnHeader4:SetText("");
		Lootster_RaidFrameBossAttendFrameColumnHeader5:SetText("");
		Lootster_RaidFrameBossAttendFrameColumnHeader6:SetText("");
		Lootster_RaidFrameBossAdjustFrameColumnHeader2:SetText("");
		Lootster_RaidFrameBossAdjustFrameColumnHeader3:SetText("");

		-- update rule table show rules label
		Lootster_RuleFrameRulesFrameLabel:SetFormattedText(LOOTSTER_RULE_RULE, LOOTSTER_ROLLMODE_LIST[Lootster_Options.RollMode]);

		-- update rules tab with normal rules
		Lootster_RuleFrameRulesFrameText:SetText(Lootster_Rules.RulesNorm);
		
		-- hide usage rolls rules button
		Lootster_RuleFrameUsageFrame:Hide();

		-- setup the roll type for using DKP
		Lootster_Option_RollType_OnShow(self);

		-- hide the DKP mode option frame
		Lootster_OptionsFrameRollManageDKPFrame:Hide();

		-- show the Normal mode option frame
		Lootster_OptionsFrameRollManageNormFrame:Show();

		-- see what Normal type is in effect
		if (Lootster_Options.NormType ~= LOOTSTER_ENUM_NORM.BYFREEFORALL) then
			-- show greed FFA option
			Lootster_OptionsFrameNormGreedFFA:Show();
		else
			-- hide greed FFA option
			Lootster_OptionsFrameNormGreedFFA:Hide();
		end
			
		-- see what Normal type is in effect
		if ((Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) or (Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL)) then
			-- show the Normal rolling auto mode option frame
			Lootster_OptionsFrameRollManageNormAutoFrame:Show();
		else
			-- hide the Normal rolling auto mode mode option frame
			Lootster_OptionsFrameRollManageNormAutoFrame:Hide();
		end

		-- hide adjustment DKP edit box and default button
		Lootster_RaidFrameAdjustFrameDKP:Hide();
		Lootster_RaidFrameAdjustFrameDKPDefault:Hide();
		
		-- hide earnt/spent options
		Lootster_RaidFrameAdjustFrameDKPValueEarnt:Hide();
		Lootster_RaidFrameAdjustFrameDKPValueSpent:Hide();
	end
end

-- Check Rolling Use handler
function Lootster_CheckRollUse()
	-- show the rolling widgets as required
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- what kind of Normal rolling?
		if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
			-- show 100/1000 buttons
			Lootster_RollFrame1001000Roll:Show();

			Lootster_RollFrameRoll100:Show();
			Lootster_RollFrameRoll1000:Show();

			-- hide need/greed buttons
			Lootster_RollFrameNeedRoll:Hide();
			Lootster_RollFrameGreedRoll:Hide();

			Lootster_RollFrameRoll:Hide();

			-- hide FFA buttons
			Lootster_RollFrameFreeForAllRoll:Hide();
			
			-- hide usage buttons
			Lootster_RollFrameUsageRoll:Hide();
			Lootster_RollFrameRollUsage:Hide();
		elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYNEEDGREED) then
			-- show need/greed buttons
			Lootster_RollFrameNeedRoll:Show();
			Lootster_RollFrameGreedRoll:Show();

			Lootster_RollFrameRoll:Show();

			-- hide 100/1000 buttons
			Lootster_RollFrame1001000Roll:Hide();

			Lootster_RollFrameRoll100:Hide();
			Lootster_RollFrameRoll1000:Hide();

			-- hide FFA buttons
			Lootster_RollFrameFreeForAllRoll:Hide();
			
			-- hide usage buttons
			Lootster_RollFrameUsageRoll:Hide();
			Lootster_RollFrameRollUsage:Hide();
		elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL) then
			-- show FFA buttons
			Lootster_RollFrameFreeForAllRoll:Show();

			Lootster_RollFrameRoll:Show();

			-- hide need/greed buttons
			Lootster_RollFrameNeedRoll:Hide();
			Lootster_RollFrameGreedRoll:Hide();

			-- hide 100/1000 buttons
			Lootster_RollFrame1001000Roll:Hide();

			Lootster_RollFrameRoll100:Hide();
			Lootster_RollFrameRoll1000:Hide();
			
			-- hide usage buttons
			Lootster_RollFrameUsageRoll:Hide();
			Lootster_RollFrameRollUsage:Hide();
		end

		-- check normal rolling auto options as necessary
		if ((Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) or (Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL)) then
			-- do we allow auto-roll?
			if (Lootster_Options.NormAutoRoll == false) then
				-- disable other normal auto options
				Lootster_OptionsFrameNormAutoOpen:Disable();
				Lootster_OptionsFrameNormAutoClose:Disable();
			else
				-- enable other normal auto options
				Lootster_OptionsFrameNormAutoOpen:Enable();
				Lootster_OptionsFrameNormAutoClose:Enable();
			end
		end
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- are we usage rolling?
		if (Lootster_Options.UsageRolls == true) then
			-- single or separate?  Note single rolls cannot be done for DKP modified rolls
			if		((Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SEPARATE) or (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL)) then
				-- show call buttons
				Lootster_RollFrameCallUsage:Show();
				Lootster_RollFrameCallRoll:Show();
				Lootster_RollFrameCallReset:Show();

				Lootster_RollFrameRoll:Show();
				
				-- hide normal buttons
				Lootster_RollFrameNeedRoll:Hide();
				Lootster_RollFrameGreedRoll:Hide();
				
				-- hide usage buttons
				Lootster_RollFrameUsageRoll:Hide();
				Lootster_RollFrameRollUsage:Hide();
			elseif	(Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SINGLE) then
				-- show usage buttons
				Lootster_RollFrameUsageRoll:Show();
				
				Lootster_RollFrameRollUsage:Show();
				
				-- hide normal buttons
				Lootster_RollFrameNeedRoll:Hide();
				Lootster_RollFrameGreedRoll:Hide();

				Lootster_RollFrameRoll:Hide();
				
				-- hide call buttons
				Lootster_RollFrameCallUsage:Hide();
				Lootster_RollFrameCallRoll:Hide();
				Lootster_RollFrameCallReset:Hide();
			else
				-- show normal buttons
				Lootster_RollFrameNeedRoll:Show();
				Lootster_RollFrameGreedRoll:Show();

				Lootster_RollFrameRoll:Show();
				
				-- hide call buttons
				Lootster_RollFrameCallUsage:Hide();
				Lootster_RollFrameCallRoll:Hide();
				Lootster_RollFrameCallReset:Hide();
				
				-- hide usage buttons
				Lootster_RollFrameUsageRoll:Hide();
				
				Lootster_RollFrameRollUsage:Hide();
			end
		else
			-- show normal buttons
			Lootster_RollFrameNeedRoll:Show();
			Lootster_RollFrameGreedRoll:Show();

			Lootster_RollFrameRoll:Show();
			
			-- hide call buttons
			Lootster_RollFrameCallUsage:Hide();
			Lootster_RollFrameCallRoll:Hide();
			Lootster_RollFrameCallReset:Hide();
			
			-- hide usage buttons
			Lootster_RollFrameUsageRoll:Hide();
			
			Lootster_RollFrameRollUsage:Hide();
		end
		
		-- hide 100/1000 buttons
		Lootster_RollFrame1001000Roll:Hide();

		Lootster_RollFrameRoll100:Hide();
		Lootster_RollFrameRoll1000:Hide();

		-- hide FFA buttons
		Lootster_RollFrameFreeForAllRoll:Hide();
	else
		-- show normal buttons
		Lootster_RollFrameNeedRoll:Show();
		Lootster_RollFrameGreedRoll:Show();

		Lootster_RollFrameRoll:Show();

		-- hide 100/1000 buttons
		Lootster_RollFrame1001000Roll:Hide();

		Lootster_RollFrameRoll100:Hide();
		Lootster_RollFrameRoll1000:Hide();

		-- hide FFA buttons
		Lootster_RollFrameFreeForAllRoll:Hide();
	end
end

-- Check Raid Use handler
function Lootster_CheckRaidUse()
	-- do we track by raid?
	if (Lootster_Options.TrackBy == LOOTSTER_ENUM_TRACKBY.RAID) then
		-- disable boss icon handling
		Lootster_OptionsFrameBossIcon:Disable();
	else
		-- enable boss icon handling
		Lootster_OptionsFrameBossIcon:Enable();
	end
end

-- Check Boss Use handler
function Lootster_CheckBossUse()
	-- are we tracking bosses and auto tracking raids?
	if ((Lootster_Options.TrackBy ~= LOOTSTER_ENUM_TRACKBY.RAIDNBOSS) or (Lootster_Options.AutoRaid == false)) then
		-- disable auto boss check box
		Lootster_OptionsFrameAutoBoss:Disable();
	else
		-- enable auto boss check box
		Lootster_OptionsFrameAutoBoss:Enable();
	end
end		

-- Check Attend Use handler
function Lootster_CheckAttendUse()
	-- are we allowing standby attendance?
	if ((Lootster_Options.AttendHere == false)) then
		-- disable attendance announce check boxes
		Lootster_OptionsFrameAttendAnnounce:Disable();
		Lootster_OptionsFrameAttendGroup:Disable();
		Lootster_OptionsFrameAttendGuild:Disable();
		Lootster_OptionsFrameAttendCustom:Disable();

		-- hide custom channel edit
		Lootster_OptionsFrameAttendCustomChannel:Hide();
	else
		-- enable attendance announce check box
		Lootster_OptionsFrameAttendAnnounce:Enable();
		
		-- are we performing new raid/boss announcements?
		if (Lootster_Options.AttendAnnounce ~= true) then
			-- disable attendance announce channel check boxes
			Lootster_OptionsFrameAttendGroup:Disable();
			Lootster_OptionsFrameAttendGuild:Disable();
			Lootster_OptionsFrameAttendCustom:Disable();

			-- hide custom channel edit
			Lootster_OptionsFrameAttendCustomChannel:Hide();
		else
			-- enable attendance announce channel check boxes
			Lootster_OptionsFrameAttendGroup:Enable();
			Lootster_OptionsFrameAttendGuild:Enable();
			Lootster_OptionsFrameAttendCustom:Enable();
			
			-- do we have a custom channel?
			if (Lootster_Options.AttendCustom ~= true) then
				-- hide custom channel edit
				Lootster_OptionsFrameAttendCustomChannel:Hide();
			else	
				-- show custom channel edit
				Lootster_OptionsFrameAttendCustomChannel:Show();
			end
		end
	end
end		

-- Check Instance Information handler
function Lootster_CheckInstanceInfo(raidRec)
	local	zone, wowId, dateExp;

	-- do we have a passed raid record?
	if (raidRec == nil) then
		-- nope, so do we have a running raid? 
		if (Lootster_Running.RaidId ~= nil) then
			-- use this raid record
			raidRec = Lootster_Raid[Lootster_Running.RaidId];
		end
	end
	
	-- do we already have a WoWID?
	if ((raidRec == nil) or (raidRec.WoWId ~= nil)) then
		-- no raid or it already has a WoWId
		return false;
	end

	-- get the instance information
	wowId, dateExp = Lootster_GetInstanceId(raidRec.Zone, raidRec.Type);
	
	if (wowId ~= nil) then
		-- update raid information
		raidRec.WoWId = wowId;
		raidRec.DateExp = dateExp;
	end
	
	return wowId ~= nil;
end

-- Load Chat Frame Mask handler
function Lootster_LoadChatMask(group)
	local	fix, chatFrame, gix, gvalue;
	local	mask = 0;

	-- hammer through all chat frames
	for fix=1, NUM_CHAT_WINDOWS do
		-- get the chat frame
		chatFrame = _G["ChatFrame"..fix];

		-- hammer through all the message types for this frame
		for gix, gvalue in ipairs(chatFrame.messageTypeList) do
			-- make sure we compare apples to apples
			if (string.upper(gvalue) == string.upper(group)) then
				-- add this guy to the mask
				mask = bit.bor(mask, bit.lshift(1, fix));
				break;
			end
		end
	end

	return mask;
end

-- Load the Time Zone handler
function Lootster_LoadTimeZone()
	local   curTime, utcTime, curDiff, utcHour, svrHour;
	
	-- get current time
	curTime = time();

	-- calculate UTC time
	utcTime = time(date("!*t", curTime));
	
	-- calculate current/UTC time differential, in hours
	curDiff = (curTime - utcTime) / 3600;
	
	-- format as UTC hour
	utcHour = date("!%H", curTime);
	
	-- get the game time hour
	svrHour = GetGameTime();

	-- and calculate server difference in time against UTC
	Lootster_TZOffsetSvrUTC = svrHour - utcHour;

	-- use hack server timezone lookup table to determine correct day bias for server time
	if (LOOTSTER_TZ_SERVER[Lootster_TZOffsetSvrUTC] ~= nil) then

		-- use server's day bias against UTC
		Lootster_TZOffsetSvrUTC = Lootster_TZOffsetSvrUTC + LOOTSTER_TZ_SERVER[Lootster_TZOffsetSvrUTC];
	end
	
	-- calculate our server time offset from current time
	Lootster_TZOffsetSvrCur = Lootster_TZOffsetSvrUTC - curDiff;
end

-- Load Data handler
function Lootster_LoadData()
	local	raidIx, raidId, raidRec, bossIx, bossId, flag, attendIx, attendId, attendRec;
	local	adjustIx, adjustId, assignIx, adjustRec, adjustSet, itemId, itemSet;
	local	resetOld, player, dkpRec, dkpEarnt, dkpSpent, trial, app, member, alt, altRec, parkIx;

	-- reset DKP and adjust total lists
	Lootster_DKP = {};

	-- hammer through each raid, accumulating boss, attend, adjust and assign counts
	for raidId, raidRec in pairs(Lootster_Raid) do
		-- initialise and accumulate boss count
		bossIx = 0;

		for bossId, flag in pairs(Lootster_Raid[raidId].BossSet) do
			-- initialise and accumulate attend count for this boss
			attendIx = 0;

			for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
				-- initialise and accumulate adjust count for this attendee
				adjustIx = 0;

				for adjustId, adjustId in pairs(Lootster_Attend[attendId].AdjustSet) do
					-- bump attend count
					adjustIx = adjustIx + 1;
				end

				-- update attendance counters
				Lootster_Attend[attendId].AdjustN = adjustIx;

				-- bump attend count
				attendIx = attendIx + 1;
			end

			-- initialise and accumulate adjust count for this boss
			adjustIx = 0;

			for adjustId, adjustRec in pairs(Lootster_Boss[bossId].AdjustSet) do
				-- bump adjust count
				adjustIx = adjustIx + 1;
			end

			-- accumulate assign set if it exists
			if (Lootster_Boss[bossId].AssignSet ~= nil) then
				-- initialise and accumulate assign count for this boss
				assignIx = 0;

				for adjustId, player in pairs(Lootster_Boss[bossId].AssignSet) do
					-- bump assign count
					assignIx = assignIx + 1;
				end
			else
				-- no assign index yet
				assignIx = nil;
			end

			-- update boss counters
			Lootster_Boss[bossId].AttendN = attendIx;
			Lootster_Boss[bossId].AdjustN = adjustIx;
			Lootster_Boss[bossId].AssignN = assignIx;

			-- bump boss count
			bossIx = bossIx + 1;
		end

		-- initialise and accumulate attend count for raid
		attendIx = 0;

		for attendId, attendRec in pairs(Lootster_Raid[raidId].AttendSet) do
			-- bump attend count
			attendIx = attendIx + 1;
		end

		-- initialise and accumulate adjust count for raid
		adjustIx = 0;

		for adjustId, adjustRec in pairs(Lootster_Raid[raidId].AdjustSet) do
			-- bump adjust count
			adjustIx = adjustIx + 1;
		end

		-- accumulate assign set if it exists
		if (Lootster_Raid[raidId].AssignSet ~= nil) then
			-- initialise and accumulate assign count for this boss
			assignIx = 0;

			for adjustId, player in pairs(Lootster_Raid[raidId].AssignSet) do
				-- bump assign count
				assignIx = assignIx + 1;
			end
		else
			-- no assign index yet
			assignIx = nil;
		end

		-- update raid counters
		Lootster_Raid[raidId].BossN = bossIx;
		Lootster_Raid[raidId].AttendN = attendIx;
		Lootster_Raid[raidId].AdjustN = adjustIx;
		Lootster_Raid[raidId].AssignN = assignIx;
	end

	-- create the DKP table
	for player, dkpRec in pairs(Lootster_MainDKP) do
		-- determine DKP breakdown.  We handle non-EPGP (prior to 3.x.x.x plugin) compliant DKP
		-- data here.  We also flag non-EPGP compliance
		if		((dkpRec.DKPEarnt ~= nil) and (dkpRec.DKPSpent ~= nil)) then
			-- EPGP compliant.  Use these
			dkpEarnt = dkpRec.DKPEarnt;
			dkpSpent = dkpRec.DKPSpent;
		elseif	(dkpRec.DKP ~= nil) then
			-- non-EPGP compliant.  We can only presume earnt
			dkpEarnt = dkpRec.DKP;
			dkpSpent = 0;
			
			-- mark non-EPGP compliance
			Lootster_IsEPGPCapable = false;
		else
			-- non-EPGP compliant and deficient.  No DKP passed
			dkpEarnt = 0;
			dkpSpent = 0;
			
			-- mark non-EPGP compliance
			Lootster_IsEPGPCapable = false;
		end
		
		-- determine trial and applicant flags
		trial = (dkpRec.Trial ~= nil) and dkpRec.Trial;
		app = (dkpRec.App == nil) or dkpRec.App;

		-- determine the membership
		if		(app == true) then
			member = LOOTSTER_ENUM_MEMBER.APP;
		elseif	(trial == true) then
			member = LOOTSTER_ENUM_MEMBER.TRIAL;
		else
			member = LOOTSTER_ENUM_MEMBER.FULL;
		end
		
		-- stuff into DKP table
		Lootster_DKP[player] = Lootster_NewDKP(player, "-", dkpEarnt, dkpSpent, 0, 0, 0, member);
	end

	-- create the Data Alt/Main Look-aside Table
	for alt, altRec in pairs(Lootster_AltsDKP) do
		-- get the main for this alt
		player = altRec.Name;

		-- add this guy to the Alt to Main look-aside table
		Lootster_DKPAltMain[alt] = player;

		-- do we have a DKP entry for the main yet?
		if (Lootster_DKP[player] == nil) then
			-- stuff into DKP table.  Note there is no way to know the class if this is an alt
			Lootster_DKP[player] = Lootster_NewDKP(player, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.APP);
		end
	end

	-- initialise the park player indirection table
	parkIx = 0;
	Lootster_ParkSort = {};

	for player, value in pairs(Lootster_ParkDKP) do
		parkIx = parkIx + 1;
		Lootster_ParkSort[parkIx] = player;
	end

	-- resort the park players
	table.sort(Lootster_ParkSort);

	-- hammer through the loot table, creating entries in the loot DKP table
	for lootId, lootRec in pairs(Lootster_Loot) do
		-- is this entry in our DKP loot table?
		if (Lootster_ItemDKP[lootId] ~= nil) then
			-- ok, its in the Loot DKP table.  We need to determine how to smoosh it in
			if		((lootRec.DKP ~= nil) and (lootRec.DKPMan ~= nil)) then
				-- we have previously smooshed these guys - copy over the manual DKP
				Lootster_ItemDKP[lootId].DKPMan = lootRec.DKPMan;

				-- repoint the local loot entry to the DKP loot entry
				Lootster_Loot[lootId] = Lootster_ItemDKP[lootId];
			elseif	((lootRec.DKP == nil) and (lootRec.DKPMan ~= nil)) then
				-- this entry is new to the DKP lootbase - erase local copy
				Lootster_Loot[lootId] = nil;
			else
				-- this entry is bogus - erase local copy
				Lootster_Loot[lootId] = nil;
			end
		else
			-- make sure this provisionary loot is marked as such
			lootRec.DKP = nil;

			-- and point the DKP loot to the local loot entry
			Lootster_ItemDKP[lootId] = lootRec;
		end
	end

	-- add park players to DKP and Adjust table
	for player, parkRec in pairs(Lootster_ParkDKP) do
		-- stuff into DKP table
		Lootster_DKP[player] = Lootster_NewDKP(player, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.FULL);
	end

	-- preprocess the adjustment table, removing all translated records
	for adjustId, adjustRec in pairs(Lootster_Adjust) do
		-- see if this key is a string and it converts to a number, in which case its a converted record
		if ((type(adjustId) == "string") and (tonumber(adjustId) ~= nil)) then
			-- translated record - remove so we can reconvert
			Lootster_Adjust[adjustId] = nil;
		end
	end

	-- are previous version records present?
	if (#Lootster_Adjust > 0) then
		-- old raid reset flag
		resetOld = false;

		-- preprocess the adjustment table, translating all previous version records
		for adjustIx, adjustRec in ipairs(Lootster_Adjust) do
			-- have we created the old raid/boss yet?
			if (resetOld == false) then
				-- create special convert raid and boss to accomodate these guys.  First though
				-- clobber any existing special raid/boss
				Lootster_DeleteRaid(LOOTSTER_CONV_RAIDID, true);

				-- create special raid
				Lootster_CreateRaid(Lootster_NewRaid(LOOTSTER_CONV_RAID, nil, nil, Lootster_CalcServerTime(time())), LOOTSTER_CONV_RAIDID, true);

				-- create special boss
				Lootster_CreateBoss(Lootster_NewBoss(LOOTSTER_CONV_BOSS, Lootster_CalcServerTime(time())), LOOTSTER_CONV_BOSSID);

				-- add the special boss to the special raid
				Lootster_InsertBoss(LOOTSTER_CONV_RAIDID, LOOTSTER_CONV_BOSSID, true);

				-- done
				resetOld = true;
			end

			-- create an adjustment record for this guy, using a numeric key so we know it is converted
			adjustId = Lootster_CreateAdjust(Lootster_NewAdjust(adjustRec.Player, adjustRec.Player, Lootster_CalcServerTime(adjustRec.Epoch),
																adjustRec.DKPAdjEarnt, adjustRec.DKPAdjSpent, LOOTSTER_ENUM_USAGE.MAINNEED, 
																nil, adjustRec.Reason, adjustRec.Comment),
											 tostring(adjustIx));

			-- add this adjustment to the special boss
			Lootster_InsertAdjust(LOOTSTER_CONV_BOSSID, adjustId, true);
		end
		
		-- smoke the old version records
		while(#Lootster_Adjust > 0) do
			-- remove record
			table.remove(Lootster_Adjust);
		end
	end
	
	-- process the attendance table
	for attendId, attendRec in pairs(Lootster_Attend) do
		-- have we a DKP entry for the player?
		if (Lootster_DKP[attendRec.Player] == nil) then
			-- create player underlying this attendance
			Lootster_DKP[attendRec.Player] = Lootster_NewDKP(attendRec.Player, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.APP);
		end
						
		-- is this an alt record?
		if	(Lootster_AltsDKP[attendRec.Player] ~= nil) then
			-- the main became the alt - remove the record from the boss
			Lootster_RemoveAttend(attendId);

			-- transfer the adjustment record to the main
			attendRec.Player = Lootster_AltsDKP[attendRec.Player].Name;

			-- and insert back into the boss
			Lootster_InsertAttend(Lootster_Attend[attendId].BossId, attendId, true);
		else
			-- add the attendance DKP to total player attendance DKP
			Lootster_DKP[attendRec.Player].DKPAttEarnt = Lootster_DKP[attendRec.Player].DKPAttEarnt + attendRec.DKPAttEarnt;
		end
	end

	-- process the adjustment table
	for adjustId, adjustRec in pairs(Lootster_Adjust) do
		-- have we a DKP entry for the player?
		if (Lootster_DKP[adjustRec.Player] == nil) then
			-- create player underlying this adjustment
			Lootster_DKP[adjustRec.Player] = Lootster_NewDKP(adjustRec.Player, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.APP);
		end
	
		-- is this a converted record for which we must finalise conversion?
		if (tonumber(adjustId) ~= nil) then
			-- remove the record from the boss
			Lootster_RemoveAdjust(adjustId);

			-- create a new style adjustment record (non-numeric keyed)
			adjustId = Lootster_CreateAdjust(adjustRec);

			-- and insert back into the boss
			Lootster_InsertAdjust(Lootster_Adjust[adjustId].BossId, adjustId, true);

			-- remove translated record
			Lootster_Adjust[adjustId] = nil;				
		end
						
		-- is this an alt record?
		if	(Lootster_AltsDKP[adjustRec.Player] ~= nil) then
			-- the main became the alt - remove the record from the boss
			Lootster_RemoveAdjust(adjustId);

			-- transfer the adjustment record to the main
			adjustRec.Player = Lootster_AltsDKP[adjustRec.Player].Name;

			-- and insert back into the boss
			Lootster_InsertAdjust(Lootster_Adjust[adjustId].BossId, adjustId, true);
		else
			-- add the adjustment DKP to total player adjustment DKP
			Lootster_DKP[adjustRec.Player].DKPAdjEarnt = Lootster_DKP[adjustRec.Player].DKPAdjEarnt + adjustRec.DKPAdjEarnt;
			Lootster_DKP[adjustRec.Player].DKPAdjSpent = Lootster_DKP[adjustRec.Player].DKPAdjSpent + adjustRec.DKPAdjSpent;
		end
	end

	-- clear rolls
	Lootster_Roll_ClearRolls_OnClick(Lootster_RollFrameClearRolls, "LeftButton");
end

-- Load Guild Ranks handler
function Lootster_LoadGuildRanks()
	local	ranks, count, ix, name, value;

	-- we only gather guild information if we are guilded
	if (Lootster_SelfGuild ~= nil) then
		-- initialise guild rank session
		for key, value in pairs(Lootster_Options_Rank_Default) do
			if (Lootster_Options[key][Lootster_SelfGuild] == nil) then
				Lootster_Options[key][Lootster_SelfGuild] = value;
			end
		end

		-- copy existing ranks so we can figure out changes
		ranks = Lootster_CopyRecord(Lootster_Options.Ranks[Lootster_SelfGuild]);

		-- get count of existing ranks
		count = GuildControlGetNumRanks();

		-- retrieve all guild ranks
		for ix=1, count, 1 do
			-- get the name of this rank
			name = GuildControlGetRankName(ix);

			-- do we currently know this rank?
			if (Lootster_Options.Ranks[Lootster_SelfGuild][name] == nil) then
				-- create a new rank for this guy
				Lootster_Options.Ranks[Lootster_SelfGuild][name] = Lootster_NewRank(name, ix, LOOTSTER_ENUM_MEMBER.FULL, LOOTSTER_ENUM_TOON.MAIN);
			else
				-- update the rank index
				Lootster_Options.Ranks[Lootster_SelfGuild][name].Index = ix;
				
				-- remove from the list of copy of ranks
				ranks[name] = nil;
			end
		end

		-- make sure we add the generic member ranks if not present
		if (Lootster_Options.Ranks[Lootster_SelfGuild][LOOTSTER_OPTION_RANK_NONMAIN] == nil) then
			-- add this rank
			Lootster_Options.Ranks[Lootster_SelfGuild][LOOTSTER_OPTION_RANK_NONMAIN] = Lootster_NewRank(LOOTSTER_OPTION_RANK_NONMAIN, LOOTSTER_RANK_NONMAIN, LOOTSTER_ENUM_MEMBER.FULL, LOOTSTER_ENUM_TOON.MAIN);
		else
			-- make sure we remove from check ranks
			ranks[LOOTSTER_OPTION_RANK_NONMAIN] = nil;
		end

		if (Lootster_Options.Ranks[Lootster_SelfGuild][LOOTSTER_OPTION_RANK_NONGUILD] == nil) then
			-- add this rank
			Lootster_Options.Ranks[Lootster_SelfGuild][LOOTSTER_OPTION_RANK_NONGUILD] = Lootster_NewRank(LOOTSTER_OPTION_RANK_NONGUILD, LOOTSTER_RANK_NONGUILD, LOOTSTER_ENUM_MEMBER.APP, LOOTSTER_ENUM_TOON.MAIN);
		else
			-- make sure we remove from check ranks
			ranks[LOOTSTER_OPTION_RANK_NONGUILD] = nil;
		end

		-- remove all deleted ranks
		for name, value in pairs(ranks) do
			-- remove this rank
			Lootster_Options.Ranks[Lootster_SelfGuild][name] = nil;
		end

		-- update the option data
		Lootster_OptionsFrameRankMembers:SetChecked(Lootster_Options.RankMembers[Lootster_SelfGuild]);

		Lootster_OptionsFrameNoteToons:SetChecked(Lootster_Options.NoteToons[Lootster_SelfGuild]);
		Lootster_OptionsFrameRankToons:SetChecked(Lootster_Options.RankToons[Lootster_SelfGuild]);

		Lootster_OptionsFrameAltsMainPrefix:SetText(Lootster_DecodeRegexp(Lootster_Options.RankAltPrefix[Lootster_SelfGuild]));
		Lootster_OptionsFrameAltsMainSuffix:SetText(Lootster_DecodeRegexp(Lootster_Options.RankAltSuffix[Lootster_SelfGuild]));
	end
end

-- Load Player Guild Information handler
function Lootster_LoadGuildieInfo()
	local	_, regexp, count, ix, player, rank, class, pubnote, main;

	-- reset guild information
	Lootster_Guildie = {};

	-- reset Guild Alt/Main Look-aside Table
	Lootster_GuildieMainAlt = {};
	Lootster_GuildieAltMain = {};

	-- if we have no guild we are done
	if (Lootster_SelfGuild == nil) then
		return;
	end

	-- form the regular expression to extract the alt's main name
	regexp = Lootster_Options.RankAltPrefix[Lootster_SelfGuild].."%s*(%S+)%s*"..Lootster_Options.RankAltSuffix[Lootster_SelfGuild];

	-- get total count of guys in guild
	count = GetNumGuildMembers();

	-- for each guy in guild, get their public note
	for ix=1, count do
		-- grab the info for this guy
		player, rank, _, _, class, _, pubnote, _, _, _ = GetGuildRosterInfo(ix);

		-- can this guy be regarded as an alt?
		if		(Lootster_Options.NoteToons[Lootster_SelfGuild] == true) then
			-- are we to cross check alt status with guild rank?
			if (Lootster_Options.RankToons[Lootster_SelfGuild] == true) then
				-- make sure this guys rank is an alt toon
				if (Lootster_Options.Ranks[Lootster_SelfGuild][rank].Toon == LOOTSTER_ENUM_TOON.ALT) then
					-- attempt to parse the public note for the main's name
					_, _, main = string.find(pubnote, regexp);
				else
					-- this is the main
					main = player;
				end
			else
				-- attempt to parse the public note for the main's name regardless of Guild Ranks
				_, _, main = string.find(pubnote, regexp);
			end
		else
			-- this is the main
			main = player;
		end

		-- is this guy an alt we have a main?
		if		((main ~= nil) and (main ~= "") and (main ~= player)) then
			-- add this guy to the Guild Alt to Main look-aside table
			Lootster_GuildieAltMain[player] = main;
		elseif	(player ~= nil) then
			-- create a guild entry for this dude
			Lootster_Guildie[player] = Lootster_NewGuildie(rank);
		end
	end
end

-- Process Restrictions handle
function Lootster_ProcessRestrictions(link, slot)
	local	_, itemLink, ix, field, text, classes, class, flag;

	-- reset item details
	Lootster_ItemID = nil;
	Lootster_ItemLink = nil;
	Lootster_ItemSlot = nil;
	Lootster_ItemText = "";

	-- reset class restrictions
	Lootster_ResetClass();

	-- do we have an item?
	if (link ~= nil) then
		-- wire in item link
		Lootster_ItemLink = link;

		-- do we have a slot?
		if (slot ~= nil) then
			-- wire up slot
			Lootster_ItemSlot = slot;
		end

		-- get the item details for this link
		Lootster_ItemID, 
		Lootster_ItemText,
		_,
		Lootster_ClassRestricted, 
		Lootster_ClassRestrictedLock, 
		Lootster_ClassRestrictions, 
		Lootster_ClassRestrictionsN, 
		Lootster_ClassRestrictionsMaskOrig = Lootster_GetItemDetails(Lootster_ItemLink);

		-- save orginal mask as current mask to dected changes
		Lootster_ClassRestrictionsMaskCurr = Lootster_ClassRestrictionsMaskOrig;
	end

	-- did we find restrictions?
	if (Lootster_ClassRestricted == true) then
		-- update the class frame
		Lootster_UpdateClassUI();

		-- update restricted count
		Lootster_UpdateRestricted();

		-- show the class frame if we are visible
		if (Lootster_IsVisible()) then
			Lootster_ClassFrame:Show();
		end
	else
		-- update the class UI
		Lootster_UpdateClassUI();
	end

	-- update the UI
	Lootster_UpdateRollUI();
end

-- Roll Clear Rolls handler
function Lootster_Roll_ClearRolls_OnClick(self, button)
	local	ix, usage, found;
	
	-- erase rolls
	Lootster_Rolls = {};

	-- reset the roll sorts
	Lootster_RollsSort = {};

	-- reset roll and restricted count
	Lootster_RollCount = 0;

	-- reset current roll NBG to nothing (between roll calls)
	Lootster_NBG = nil;
	Lootster_NBG_Usage = nil;
	
	-- reset list of winners
	Lootster_Won = {};

	-- reset tied indicator, rolls and count
	Lootster_Tied = false;
	Lootster_TiedRolls = {};
	Lootster_TiedItemCount = 0;
	
	-- if we are doing separate usage rolls, bump to next usage
	if ((Lootster_Options.UsageRolls == true) and
		((Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SEPARATE) or (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL))) then
		-- did we have leftovers from announcement?
		if (Lootster_AnnounceItemCount == nil) then
			-- simply reset to the initial call usage
			Lootster_Roll_CallReset_OnClick(Lootster_RollFrameCallReset, button);
		else		
			-- set rolls usage to next available.  First, find currently selected guy
			found = false;
			
			for ix, usage in ipairs(Lootster_Options.UsageSort) do
				-- is this current?
				if		(usage == Lootster_RollsUsage) then
					-- found our current
					Lootster_RollsUsage = nil;
					found = true;
				elseif	((found == true) and (Lootster_Options.Usage[usage].Use == true)) then
					-- this is our man
					Lootster_RollsUsage = usage;
					break;
				end
			end
			
			-- was that the final enabled usage on the list?
			if (Lootster_RollsUsage == nil) then
				-- no next usage means we cycle back to first
				Lootster_Roll_CallReset_OnClick(Lootster_RollFrameCallReset, button);
			else
				-- select next usage
				UIDropDownMenu_SetSelectedValue(Lootster_RollFrameCallUsage, Lootster_RollsUsage);
			end
		end
	else
		-- reset roll usage selection
		UIDropDownMenu_SetText(Lootster_RollFrameRollUsage, LOOTSTER_ROLL_ROLLUSAGE_SEL);
		UIDropDownMenu_JustifyText(Lootster_RollFrameRollUsage, "CENTER");
		UIDropDownMenu_SetSelectedValue(Lootster_RollFrameRollUsage, nil);
	end
	
	-- if we have items leftover from announcement, set them now
	if (Lootster_AnnounceItemCount == nil) then
		-- reset item count
		Lootster_RollFrameItems:SetNumber(1);
	else
		-- set item count to leftovers
		Lootster_RollFrameItems:SetNumber(Lootster_AnnounceItemCount);
		
		-- and none now after announcement
		Lootster_AnnounceItemCount = nil;	
	end

	-- and spoof entry to transfer and update
	Lootster_Roll_Items_OnFocusLost(self);

	-- reset pass/reclaim text
	Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_PASS);

	-- update the roll
	Lootster_UpdateRoll();

	-- update received counter
	Lootster_UpdateRollUI();

	-- and update the screen
	Lootster_Roll_Update();
end

-- Assign Loot handler
function Lootster_Roll_AssignLoot_OnClick(self, button)
	local	count, player, main, itemId, itemText, itemQual, dkp, reason, tba;
	
	-- no loot link or running boss we are done
	if ((Lootster_ItemLink == nil) or (Lootster_Running.RaidId == nil) or (Lootster_Running.BossId == nil)) then
		return;
	end

	-- retrieve the item text and quality
	itemId, itemText, itemQual = Lootster_GetItemBasics(Lootster_ItemLink);
	
	-- retrieve default DKP and reason text and what kind of loot this is (DKP or non-DKP)
	dkp, reason, items = Lootster_GetItemDKP(Lootster_ItemText, Lootster_ItemLink);
	
	-- are we tracking this quality level?
	if (itemQual >= Lootster_Options.LootMode) then
		-- is this a DKP item and tracking non-DKP loot?  If so then this needs to be assigned so we don't rebook when it is looted
		if (((items == 0) and (Lootster_Options.AutoNonDKPLoot == true)) or ((items ~= 0) and (Lootster_Options.AutoDKPLoot == true))) then
			-- yet to be looted
			tba = LOOTSTER_ENUM_TOBEASSIGNED.BOOKED;
		end
	else
		-- not to be assigned
		tba = LOOTSTER_ENUM_TOBEASSIGNED.MATCHED;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- create an adjustment record for this guy
	Lootster_AdjustRec = Lootster_NewAdjust(nil, nil, Lootster_CalcServerTime(time()), 0, dkp, LOOTSTER_ENUM_USAGE.MAINNEED, Lootster_ItemLink,
											reason, "", tba);
	
	-- this adjustment must go into the running boss
	Lootster_AdjustRec.BossId = Lootster_Running.BossId;

	-- copy the winner list and won item count
	Lootster_AdjustRec.Won = Lootster_CopyRecord(Lootster_Won);
	Lootster_AdjustRec.WonItemCount = Lootster_WonItemCount;
	
	-- show data adjustment frame
	Lootster_Popup_Show(Lootster_RaidFrameAdjustFrame);
end

-- Active Toggle handler
function Lootster_Roll_ActiveButton_OnToggle(self)
	-- this is easy
	Lootster_Options.Active = (Lootster_RollFrameActive:GetChecked() ~= nil);

	-- disable/enable passive rolling checkbox
	if (Lootster_Options.Active == true) then
		Lootster_RollFramePassive:Disable();
	else
		Lootster_RollFramePassive:Enable();
	end

	-- update roll handling
	Lootster_UpdateRollUI();
end

-- Need Roll Call handler
function Lootster_Roll_NeedRoll_OnClick(self, button)
	-- set current roll NBG to need
	Lootster_NBG = LOOTSTER_NBG_NEED;
	Lootster_NBG_Usage = LOOTSTER_ENUM_USAGE.MAINNEED;

	-- if the item count is less than or equal to zero, set to 1
	if (Lootster_ItemCount <= 0) then
		-- set item count to default
		Lootster_RollFrameItems:SetNumber(1);

		-- and spoof entry to transfer and update
		Lootster_Roll_Items_OnFocusLost(self);
	end

	-- create roll plead and ignore texts
	Lootster_CreatePlead();

	-- calculate player positioning
	Lootster_CalculatePositions();

	-- update received roll status
	Lootster_UpdateRollUI();
	
	-- transmit roll call
	Lootster_XmitRollCall();
	
	-- announce the roll call
	Lootster_AnnounceRollCall(LOOTSTER_ENUM_USAGE.MAINNEED);
end

-- Greed Roll Call handler
function Lootster_Roll_GreedRoll_OnClick(self, button)
	-- set current roll NBG to greed
	Lootster_NBG = LOOTSTER_NBG_GREED;
	Lootster_NBG_Usage = LOOTSTER_ENUM_USAGE.GREED;

	-- if the item count is less than or equal to zero, set to 1
	if (Lootster_ItemCount <= 0) then
		-- set item count to default
		Lootster_RollFrameItems:SetNumber(1);

		-- and spoof entry to transfer and update
		Lootster_Roll_Items_OnFocusLost(self);
	end

	-- create roll plead and ignore texts
	Lootster_CreatePlead();	

	-- calculate player positioning
	Lootster_CalculatePositions();

	-- reformat our roll button text since we may have greed FFA
	Lootster_UpdateRoll();

	-- update received roll status
	Lootster_UpdateRollUI();	
	
	-- transmit roll call
	Lootster_XmitRollCall();	
	
	-- announce the roll call
	Lootster_AnnounceRollCall(LOOTSTER_ENUM_USAGE.GREED);
end

-- 100/1000 Roll Call handler
function Lootster_Roll_1001000Roll_OnClick(self, button)
	-- set current roll NBG to 100/1000
	Lootster_NBG = LOOTSTER_NBG_1001000;
	Lootster_NBG_Usage = LOOTSTER_ENUM_USAGE.MANUAL;

	-- if the item count is less than or equal to zero, set to 1
	if (Lootster_ItemCount <= 0) then
		-- set item count to default
		Lootster_RollFrameItems:SetNumber(1);

		-- and spoof entry to transfer and update
		Lootster_Roll_Items_OnFocusLost(self);
	end

	-- create roll plead and ignore texts
	Lootster_CreatePlead();

	-- calculate player positioning
	Lootster_CalculatePositions();

	-- update received roll status
	Lootster_UpdateRollUI();	
	
	-- transmit roll call
	Lootster_XmitRollCall();
	
	-- announce the roll call
	Lootster_AnnounceRollCall();
end

-- Free-For-All Roll Call handler
function Lootster_Roll_FreeForAllRoll_OnClick(self, button)
	-- set current roll NBG to FFA
	Lootster_NBG = LOOTSTER_NBG_FREEFORALL;
	Lootster_NBG_Usage = LOOTSTER_ENUM_USAGE.GREED;

	-- if the item count is less than or equal to zero, set to 1
	if (Lootster_ItemCount <= 0) then
		-- set item count to default
		Lootster_RollFrameItems:SetNumber(1);

		-- and spoof entry to transfer and update
		Lootster_Roll_Items_OnFocusLost(self);
	end

	-- create roll plead and ignore texts
	Lootster_CreatePlead();

	-- calculate player positioning
	Lootster_CalculatePositions();

	-- update received roll status
	Lootster_UpdateRollUI();	
	
	-- transmit roll call
	Lootster_XmitRollCall();	
	
	-- announce the roll call
	Lootster_AnnounceRollCall();
end

-- Roll Call Usage Load handler
function Lootster_Roll_CallUsage_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 106);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Roll Call Usage Show handler
function Lootster_Roll_CallUsage_OnShow(self)
	-- make sure we have an initial usage if none
	if (Lootster_RollsUsage == nil) then
		Lootster_Roll_CallReset_OnClick(Lootster_RollFrameCallReset, "LeftButton");
	end
	
	-- setup the roll call usage drop down
	UIDropDownMenu_Initialize(Lootster_RollFrameCallUsage, Lootster_Roll_CallUsage_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RollFrameCallUsage, Lootster_RollsUsage);
end

-- Roll Call Usage Load Initaliser handler
function Lootster_Roll_CallUsage_Initialise()
	local	ix, usage, info;
	
	-- add buttons in usage sort order, ignoring those not in use
	for ix, usage in ipairs(Lootster_Options.UsageSort) do
		-- this guy in use?
		if (Lootster_Options.Usage[usage].Use == true) then
			-- form mode button
			info = {};
			info.text = LOOTSTER_USAGEDKP_LIST[usage];
			info.func = Lootster_Roll_CallUsage_OnSelect;
			info.value = usage;

			-- add roll call usage button
			UIDropDownMenu_AddButton(info);
		end
	end
end

-- Roll Call Usage Select handler
function Lootster_Roll_CallUsage_OnSelect(self)
	-- snarf new roll call usage
	Lootster_RollsUsage = self.value;
	
	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RollFrameCallUsage, self.value);
end

-- Call Roll handler
function Lootster_Roll_CallRoll_OnClick(self, button)
	-- set current roll NBG to specific usage
	Lootster_NBG = LOOTSTER_USAGEDKP_LIST[Lootster_RollsUsage];
	Lootster_NBG_Usage = Lootster_RollsUsage;

	-- if the item count is less than or equal to zero, set to 1
	if (Lootster_ItemCount <= 0) then
		-- set item count to default
		Lootster_RollFrameItems:SetNumber(1);

		-- and spoof entry to transfer and update
		Lootster_Roll_Items_OnFocusLost(self);
	end

	-- create roll plead and ignore texts
	Lootster_CreatePlead();

	-- calculate player positioning
	Lootster_CalculatePositions();

	-- update the roll
	Lootster_UpdateRoll();

	-- update received roll status
	Lootster_UpdateRollUI();
	
	-- transmit roll call
	Lootster_XmitRollCall();	
	
	-- announce the roll call
	Lootster_AnnounceRollCall(Lootster_RollsUsage);
end

-- Call Reset handler
function Lootster_Roll_CallReset_OnClick(self, button)
	local	ix, usage;
	
	-- reset usage
	Lootster_RollsUsage = nil;

	-- locate first used usage
	for ix, usage in ipairs(Lootster_Options.UsageSort) do
		-- is this enabled?
		if (Lootster_Options.Usage[usage].Use == true) then
			-- this is our man
			Lootster_RollsUsage = usage;
			break;
		end
	end
			
	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RollFrameCallUsage, Lootster_RollsUsage);
end

-- Usage Roll handler
function Lootster_Roll_UsageRoll_OnClick(self, button)
	-- set current roll NBG to usage
	Lootster_NBG = LOOTSTER_NBG_USAGE;
	Lootster_NBG_Usage = LOOTSTER_ENUM_USAGE.MANUAL;

	-- if the item count is less than or equal to zero, set to 1
	if (Lootster_ItemCount <= 0) then
		-- set item count to default
		Lootster_RollFrameItems:SetNumber(1);

		-- and spoof entry to transfer and update
		Lootster_Roll_Items_OnFocusLost(self);
	end

	-- create roll plead and ignore texts
	Lootster_CreatePlead();

	-- calculate player positioning
	Lootster_CalculatePositions();

	-- update received roll status
	Lootster_UpdateRollUI();
	
	-- transmit roll call
	Lootster_XmitRollCall();	
	
	-- announce the roll call
	Lootster_AnnounceRollCall(LOOTSTER_ENUM_USAGE.MAINNEED);
end

-- Tied Roll Call handler
function Lootster_Roll_TiedRoll_OnClick(self, button)
	local	count, ix;

	-- set current roll NBG to tied
	Lootster_NBG = LOOTSTER_NBG_TIED;
	Lootster_NBG_Usage = LOOTSTER_ENUM_USAGE.MANUAL;
	
	-- reset class please
	Lootster_NBG_ClassPlease = "";

	-- reset roll count
	Lootster_RollCount = 0;

	-- set the new item count of items remaining to be distributed
	Lootster_RollFrameItems:SetNumber(Lootster_TiedItemCount);

	-- and spoof entry to transfer and update
	Lootster_Roll_Items_OnFocusLost(self);

	-- reset list of rolls and sort order
	Lootster_Rolls = {};
	Lootster_RollsSort = {};

	-- build list of ties to roll
	count = #Lootster_TiedRollsSort;

	for ix=1, count, 1 do
		-- copy this tied player
		Lootster_Rolls[Lootster_TiedRollsSort[ix]] = Lootster_TiedRolls[Lootster_TiedRollsSort[ix]];

		-- update the sort order
		Lootster_RollsSort[ix] = Lootster_TiedRolls[Lootster_TiedRollsSort[ix]].Player;

		-- add name
		Lootster_NBG_ClassPlease = Lootster_NBG_ClassPlease..Lootster_TiedRolls[Lootster_TiedRollsSort[ix]].Player;

		if		(ix < (count - 1)) then
			Lootster_NBG_ClassPlease = Lootster_NBG_ClassPlease..LOOTSTER_MSG_SEP;
		elseif	(ix == (count - 1)) then
			Lootster_NBG_ClassPlease = Lootster_NBG_ClassPlease..LOOTSTER_MSG_AND;
		end
	end
	
	-- update the screen
	Lootster_Roll_Update();

	-- update the roll
	Lootster_UpdateRoll();

	-- update received roll status
	Lootster_UpdateRollUI();	
	
	-- transmit roll call
	Lootster_XmitRollCall();	
	
	-- announce the roll call
	Lootster_AnnounceRollCall();
end

-- Roll Count handler
function Lootster_Roll_RollCount_OnClick(self, button)
	local	rcount, rix, lcount, lix, player;

	local	msgLagName = "";

	local	playerLag = {};

	-- get the count of rolls
	rcount = #Lootster_RollsSort;

	-- build yet to roll or pass announcement
	for rix=1, rcount, 1 do
		-- has this guy rolled?
		if (Lootster_Rolls[Lootster_RollsSort[rix]].Roll == nil) then
			-- add the laggard
			table.insert(playerLag, rix);
		end
	end

	if (#playerLag ~= 0) then
		-- get count of laggards
		lcount = #playerLag;

		-- build laggard announcement
		for lix=1, lcount, 1 do
			-- put the laggard in the message
			msgLagName = msgLagName..Lootster_Rolls[Lootster_RollsSort[playerLag[lix]]].Player

			if		(lix < (lcount - 1)) then
				msgLagName = msgLagName..LOOTSTER_MSG_SEP;
			elseif	(lix == (lcount - 1)) then
				msgLagName = msgLagName..LOOTSTER_MSG_AND;
			end
		end

		-- announce the laggards.  Determine message
		if (Lootster_ItemLink == nil) then
			-- see how many laggards we have
			if (lcount == 1) then
				Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_LAGGARD1, msgLagName));
			else
				Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_LAGGARDN, msgLagName));
			end
		else
			-- how many many laggards we have
			if (lcount == 1) then
				Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_LAGGARD1_LINK, msgLagName, Lootster_ItemLink));
			else
				Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_LAGGARDN_LINK, msgLagName, Lootster_ItemLink));
			end
		end

		-- hammer through each player sending them their roll command, as required
		for lix=1, lcount, 1 do
			-- snarf player
			player = Lootster_Rolls[Lootster_RollsSort[playerLag[lix]]].Player;

			-- have they switched off laggard roll command tells?
			if (Lootster_TestPlayerTell(player, "AckNoRoll") == true) then
				-- send them their roll command
				Lootster_AskForRoll(player);
			end
		end
	end
end

-- Roll Countdown handler
function Lootster_Roll_Countdown_OnClick(self, button)
	-- initialise countdown counter
	Lootster_CountdownCount = Lootster_Options.CounterSec;

	-- reset the timer frame update time
	Lootster_Timer.LastCountdownTime = 0;

	-- and let people know
	if (Lootster_ItemLink == nil) then
		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_COUNTDOWN, Lootster_NBG, Lootster_CountdownCount));
	else
		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_COUNTDOWN_LINK, Lootster_NBG, Lootster_ItemLink, Lootster_CountdownCount));
	end
end

-- Roll Announce handler
function Lootster_Roll_Announce_OnClick(self, button)
	local	msgWinName, msgWinRoll, msgTieName, msgTieRoll, msgRemain, playerCan, playerWin, playerTie, rollInfo, msgRollPrefix;
	local	icount, wcount, rcount, tcount, wix, roll, winRec, rix, tix, tieRec, cix, ix;
	local	dkp, reason, items, itemId, itemText, itemQual, dkp, reason, tba, adjustId, adjustRec, main;

	local	msgWinName = "";
	local	msgWinRoll = "";
	local	msgTieName = "";
	local	msgTieRoll = "";

	local	msgRemain = "";

	local	playerCan = {};
	local	playerWin = {};
	local	playerTie = {};

	-- determine the roll type and whether there is roll info
	if		(Lootster_NBG == LOOTSTER_NBG_TIED) then
		-- no roll information, normal roll
		rollInfo = false;
		msgRollPrefix = LOOTSTER_ROLL_PREFIX;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- normal rolling, roll information
		rollInfo = true;
		msgRollPrefix = LOOTSTER_ROLL_PREFIX;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- DKP rolling, roll information dependent on type
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
			-- has roll information, DKP-based roll
			rollInfo = true;
			msgRollPrefix = LOOTSTER_ROLL_DKPPREFIX;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			-- has roll information, Tier-based roll
			rollInfo = true;
			msgRollPrefix = LOOTSTER_ROLL_TIERPREFIX;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
			-- has roll information, DKP Modified roll
			rollInfo = true;
			msgRollPrefix = LOOTSTER_ROLL_MODIFIEDROLLPREFIX;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
			-- has roll information, Roll Modified roll
			rollInfo = true;
			msgRollPrefix = LOOTSTER_ROLL_MODIFIEDDKPPREFIX;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- has roll information, PR-based roll
			rollInfo = true;
			msgRollPrefix = LOOTSTER_ROLL_PRPREFIX;
		else
			-- no roll information, unknown DKP type
			rollInfo = false;
			msgRollPrefix = LOOTSTER_ROLL_PREFIX;
		end
	else
		-- no roll information, unknown roll mode
		rollInfo = false;
		msgRollPrefix = LOOTSTER_ROLL_PREFIX;
	end

	-- snarf count of items to distribute
	icount = Lootster_ItemCount;

	-- snarf count of items to distribute in event of a tie
	Lootster_TiedItemCount = Lootster_ItemCount;

	-- get the count of rolls
	rcount = #Lootster_RollsSort;

	-- set roll index
	rix = 1;

	-- while we have items to win, get winners
	while ((icount > 0) and (rix <= rcount)) do
		-- do we have a valid roll?
		if ((Lootster_Rolls[Lootster_RollsSort[rix]].Roll == nil) or (Lootster_Rolls[Lootster_RollsSort[rix]].Roll <= 0)) then
			-- none left in the list can be a valid roll
			rix = rcount + 1;
		else
			-- get this candidate
			playerCan = { rix };

			-- calculate starting index for ties
			tix = rix + 1;

			-- gather all the possible candidates with the same roll
			while ((tix <= rcount) and (Lootster_RollEqual(Lootster_RollsSort[rix], Lootster_RollsSort[tix]) == true)) do
				-- get tieing  player
				table.insert(playerCan, tix);

				tix = tix + 1;
			end

			-- okay, now see if all the tieing players each have a item available for them
			if ((icount - (tix - rix)) >= 0) then
				-- we have some winners!
				for cix, ix in ipairs(playerCan) do
					table.insert(playerWin, ix);
				end

				-- subtract these won items from the tied item count
				Lootster_TiedItemCount = Lootster_TiedItemCount - (tix - rix);
			else
				-- we have some ties!
				for cix, ix in ipairs(playerCan) do
					table.insert(playerTie, ix);
				end
			end

			-- calculate the remaining items to roll on
			icount = icount - (tix - rix);

			-- the roll starting position is where we left off
			rix = tix;
		end
	end

	-- see if we have any outright winners
	if (#playerWin ~= 0) then
		-- get count of winners
		wcount = #playerWin;

		-- build winners announcement
		for wix=1, wcount, 1 do
			-- grab the winner record
			winRec = Lootster_Rolls[Lootster_RollsSort[playerWin[wix]]];
			
			-- get the main of this player
			main = Lootster_GetAltMain(winRec.Player);
			
			-- has this winner had an adjustment assigned?
			if (winRec.AdjustId == nil) then
				-- retrieve the item text and quality
				itemId, itemText, itemQual = Lootster_GetItemBasics(Lootster_ItemLink);
				
				-- retrieve default DKP and reason text and what kind of loot this is (DKP or non-DKP)
				dkp, reason, items = Lootster_GetItemDKP(Lootster_ItemText, Lootster_ItemLink);
				
				-- calculate the usage factors
				dkp = Lootster_CalcUsageDKP(main, winRec.Player, winRec.Usage, dkp);
				
				-- and normalise
				dkp = Lootster_CalcPoints(dkp);
				
				-- are we tracking this quality level?
				if (itemQual >= Lootster_Options.LootMode) then
					-- is this a DKP item and tracking non-DKP loot?  If so then this needs to be assigned so we don't rebook when it is looted
					if (((items == 0) and (Lootster_Options.AutoNonDKPLoot == true)) or ((items ~= 0) and (Lootster_Options.AutoDKPLoot == true))) then
						tba = LOOTSTER_ENUM_TOBEASSIGNED.BOOKED;
					end
				else
					-- not to be assigned
					tba = LOOTSTER_ENUM_TOBEASSIGNED.MATCHED;
				end
				
				-- have we a looted adjustment already for this guy?
				adjustId = Lootster_FindAssign(main, Lootster_ItemLink, LOOTSTER_ENUM_TOBEASSIGNED.LOOTED);
				
				if		(adjustId ~= nil) then
					-- copy the adjustment record so we can update it
					adjustRec = Lootster_CopyRecord(Lootster_Adjust[adjustId]);
					
					-- update the boss if we have one running
					if (Lootster_Running.BossId ~= nil) then
						adjustRec.BossId = Lootster_Running.BossId;
					end
					
					-- update the actual usage and DKP
					adjustRec.Usage = winRec.Usage;
					adjustRec.DKPAdjSpent = dkp;
					
					-- flip TBA flag because this has been matched and reset assign key
					adjustRec.TBA = LOOTSTER_ENUM_TOBEASSIGNED.MATCHED;
					adjustRec.AssignKey = nil;
					
					-- modify the adjustment
					Lootster_ModifyAdjust(adjustRec, true);
				elseif	(Lootster_Running.BossId ~= nil) then
					-- create a new adjustment record
					adjustId = Lootster_CreateAdjust(Lootster_NewAdjust(main, winRec.Player, Lootster_CalcServerTime(time()), 0, dkp, 
																		winRec.Usage, Lootster_ItemLink, reason, "", tba));
					
					-- create an assign key
					Lootster_Adjust[adjustId].AssignKey = Lootster_CreateAssignKey(main, Lootster_ItemLink);
					
					-- is this a banked item and we have an official banker?
					if ((LOOTSTER_USAGE_BANKED[winRec.Usage] == true) and (Lootster_Options.Banker ~= nil)) then
						-- we need to hammer the player and alt to the banker
						Lootster_Adjust[adjustId].Player = Lootster_Options.Banker;
						Lootster_Adjust[adjustId].Alt = Lootster_Options.Banker;
					end
					
					-- add this adjustment to the running boss
					Lootster_InsertAdjust(Lootster_Running.BossId, adjustId);
				end
				
				-- bookkeep the fact this roll has been assigned an adjustment
				winRec.AdjustId = adjustId;
			else
				-- retrieve the associated adjustment
				adjustId = winRec.AdjustId;
			end
			
			-- add this guy's main to list of winners 
			table.insert(Lootster_Won, Lootster_NewWin(main, winRec.Usage, 0, dkp, adjustId));

			-- add name
			msgWinName = msgWinName..winRec.Player;

			-- add roll result
			msgWinRoll = msgWinRoll..Lootster_GetPlayerResult(winRec);

			-- is there roll information?
			if (rollInfo == true) then
				-- add roll information
				msgRollInfo = Lootster_GetPlayerRollInfo(winRec);
			else
				msgRollInfo = "";
			end

			-- and put it together
			if		(wcount == 1) then
				msgWinRoll = msgWinRoll..msgRollInfo;
			elseif	(wix < (wcount - 1)) then
				msgWinName = msgWinName..LOOTSTER_MSG_SEP;
				msgWinRoll = msgWinRoll..msgRollInfo..LOOTSTER_MSG_SEP;
			elseif	(wix == (wcount - 1)) then
				msgWinName = msgWinName..LOOTSTER_MSG_AND;
				msgWinRoll = msgWinRoll..msgRollInfo..LOOTSTER_MSG_AND;
			end
		end

		-- announce outright winners
		if (Lootster_ItemLink == nil) then
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_ANNOUNCE, msgWinName, msgRollPrefix, msgWinRoll));
		else
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_ANNOUNCE_LINK, msgWinName, Lootster_ItemLink, msgRollPrefix, msgWinRoll));
		end

		-- resort data DKP using current sort
		Lootster_Data_DKP_Sort(nil);

		-- resort data attend using current sort
		Lootster_Data_Attend_Sort(nil);

		-- resort data adjust using current sort
		Lootster_Data_Adjust_Sort(nil);
		
		-- resort raid raid using current sort
		Lootster_Raid_Raid_Sort(nil);

		-- resort raid boss using current sort
		Lootster_Raid_Boss_Sort(nil);

		-- resort raid attend using current sort
		Lootster_Raid_Attend_Sort(nil);

		-- resort raid adjust using current sort
		Lootster_Raid_Adjust_Sort(nil);		

		-- resort raid assign using current sort
		Lootster_Raid_Assign_Sort(nil);

		-- update the raid UI
		Lootster_UpdateRaidUI();
	end

	-- see if we have any tied players or items left over
	if		(#playerTie ~= 0) then
		-- reset list of tied rolls and sort order
		Lootster_TiedRolls = {};
		Lootster_TiedRollsSort = {};

		-- get count of ties
		tcount = #playerTie;

		-- copy tied players and build tied announcement
		for tix=1, tcount, 1 do
			-- grab the tieing record
			tieRec = Lootster_Rolls[Lootster_RollsSort[playerTie[tix]]];
			
			-- copy this tied player
			Lootster_TiedRolls[Lootster_RollsSort[playerTie[tix]]] = Lootster_CopyRecord(tieRec);

			-- update the sort order
			Lootster_TiedRollsSort[tix] = tieRec.Player;

			-- add name
			msgTieName = msgTieName..tieRec.Player;

			if		(tix < (tcount - 1)) then
				msgTieName = msgTieName..LOOTSTER_MSG_SEP;
			elseif	(tix == (tcount - 1)) then
				msgTieName = msgTieName..LOOTSTER_MSG_AND;
			end
		end

		-- grab first tieing record
		tieRec = Lootster_Rolls[Lootster_RollsSort[playerTie[1]]];

		-- add roll result
		msgTieRoll = Lootster_GetPlayerResult(tieRec);

		-- is there roll information?
		if (rollInfo == true) then
			-- add roll information
			msgRollInfo = Lootster_GetPlayerRollInfo(tieRec);
		else
			msgRollInfo = "";
		end

		-- announce ties
		if (Lootster_ItemLink == nil) then
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_TIED, msgTieName, msgRollPrefix, msgTieRoll..msgRollInfo));
		else
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_TIED_LINK, msgTieName, Lootster_ItemLink, msgRollPrefix, msgTieRoll..msgRollInfo));
		end

		-- now reset current roll data for the ties
		for key, value in pairs(Lootster_TiedRolls) do
			Lootster_TiedRolls[key].Roll = nil;
			Lootster_TiedRolls[key].Bad = nil;
			Lootster_TiedRolls[key].Dup = nil;
		end

		-- set tied flag
		Lootster_Tied = true;
		
		-- reset announce item count
		Lootster_AnnounceItemCount = nil;

		-- update received roll status
		Lootster_UpdateRollUI();
	else
		-- reset list of tied rolls and sort order
		Lootster_TiedRolls = {};
		Lootster_TiedRollsSort = {};

		-- set tied flag
		Lootster_Tied = false;

		-- update received roll status
		Lootster_UpdateRollUI();

		-- any leftovers?
		if	(icount > 0) then
			-- announce leftovers.  Determine message
			if (Lootster_ItemLink == nil) then
				-- how many left over
				if (icount == 1) then
					Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_UNCLAIMED1));
				else
					Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_UNCLAIMEDN, icount));
				end
			else
				-- how many left over
				if (icount == 1) then
					Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_UNCLAIMED1_LINK, Lootster_ItemLink));
				else
					Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_UNCLAIMEDN_LINK, icount, Lootster_ItemLink));
				end
			end
			
			-- set the number of items after announcement
			Lootster_AnnounceItemCount = icount;
		else
			-- reset announce item count
			Lootster_AnnounceItemCount = nil;
		end
	end
end

-- Passive Button Click handler
function Lootster_Roll_PassiveButton_OnToggle(self)
	-- this is easy
	Lootster_Options.Passive = (Lootster_RollFramePassive:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollUI();
end

-- Roll Roll handler
function Lootster_Roll_Roll_OnClick(self, button)
	-- good luck!
	RandomRoll(1, Lootster_SelfRoll);
end

-- Roll Roll 100 handler
function Lootster_Roll_Roll100_OnClick(self, button)
	-- good luck!
	RandomRoll(1, 100);
end

-- Roll Roll 1000 handler
function Lootster_Roll_Roll1000_OnClick(self, button)
	-- good luck!
	RandomRoll(1, 1000);
end

-- Roll Roll Usage Load handler
function Lootster_Roll_RollUsage_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 106);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Roll Roll Usage Show handler
function Lootster_Roll_RollUsage_OnShow(self)
	-- setup the roll roll usage drop down
	UIDropDownMenu_Initialize(Lootster_RollFrameRollUsage, Lootster_Roll_RollUsage_Initialise);

	-- set initial selection depending if we have already rolled
	if ((Lootster_Rolls[Lootster_Self] == nil) or (Lootster_Rolls[Lootster_Self].Roll == nil)) then
		-- prompt for selection	
		UIDropDownMenu_SetText(Lootster_RollFrameRollUsage, LOOTSTER_ROLL_ROLLUSAGE_SEL);
		UIDropDownMenu_JustifyText(Lootster_RollFrameRollUsage, "CENTER");
		UIDropDownMenu_SetSelectedValue(Lootster_RollFrameRollUsage, nil);
	else
		-- set the correct roll	
		UIDropDownMenu_SetSelectedValue(Lootster_RollFrameRollUsage, Lootster_Rolls[Lootster_Self].Usage);
	end
end

-- Roll Roll Usage Load Initaliser handler
function Lootster_Roll_RollUsage_Initialise()
	local	ix, usage, info;

	-- add buttons in usage sort order, ignoring those not in use
	for ix, usage in ipairs(Lootster_Options.UsageSort) do
		-- this guy in use?
		if (Lootster_Options.Usage[usage].Use == true) then
			-- form mode button
			info = {};
			info.text = LOOTSTER_USAGEDKP_LIST[usage];
			info.func = Lootster_Roll_RollUsage_OnSelect;
			info.value = usage;

			-- add roll roll usage button
			UIDropDownMenu_AddButton(info);
		end
	end
end

-- Roll Roll Usage Select handler
function Lootster_Roll_RollUsage_OnSelect(self)
	-- select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RollFrameRollUsage, self.value);
	UIDropDownMenu_JustifyText(Lootster_RollFrameRollUsage, "LEFT");
	
	-- good luck!
	RandomRoll(1, Lootster_Options.Usage[self.value].Roll);
end

-- Pass/Reclaim Roll handler
function Lootster_Roll_PassReclaim_OnClick(self, button)
	-- see what we need to do for ourselves
	if		((Lootster_Rolls[Lootster_Self] == nil) or (Lootster_Rolls[Lootster_Self].Roll == nil) or 
			 (Lootster_Rolls[Lootster_Self].Roll >= 0)) then
		-- see if we need to inform people
		if (Lootster_PlayerCount == 1) then
			-- just pass internally
			Lootster_PassRoll(Lootster_Self);
		else
			-- let everyone know we are passing.  If we are inactive but allowing passive
			-- rolls/passes, force this bad boy out
			if ((Lootster_Options.Active == false) and (Lootster_Options.Passive == true)) then
				-- force out to party/raid chat
				Lootster_SendBroadcast(LOOTSTER_CMD_PASS, true);
			else
				-- normal broadcast...
				Lootster_SendBroadcast(LOOTSTER_CMD_PASS);
			end				
		end
	elseif	((Lootster_Rolls[Lootster_Self] ~= nil) and ((Lootster_Rolls[Lootster_Self].Roll ~= nil) and (Lootster_Rolls[Lootster_Self].Roll < 0))) then
		-- see if we need to inform people
		if (Lootster_PlayerCount == 1) then
			-- just reclaim internally
			Lootster_ReclaimRoll(Lootster_Self);
		else
			-- let everyone know we are reclaiming.  If we are inactive but allowing passive
			-- rolls/passes, force this bad boy out
			if ((Lootster_Options.Active == false) and (Lootster_Options.Passive == true)) then
				-- force out to party/raid chat
				Lootster_SendBroadcast(LOOTSTER_CMD_RECLAIM, true);
			else
				-- normal broadcast...
				Lootster_SendBroadcast(LOOTSTER_CMD_RECLAIM);
			end				
		end
	end
end

-- Roll Clear Item Link handler
function Lootster_Roll_ClearItem_OnClick(self, button)
	-- reset the hyperlinks
	Lootster_SetHyperlink(nil);
end

-- Roll Item Link Click handler
function Lootster_Roll_ItemLink_OnClick(self, button)
	-- do we have a link?
	if (Lootster_ItemLink ~= nil) then
		-- I wonder what they think they are doing...
		Lootster_ClickTooltip(Lootster_ItemLink, button);
	end
end

-- Items Focus Gained handler
function Lootster_Roll_Items_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Items Entered handler
function Lootster_Roll_Items_OnTextChanged(self)
end

-- Items Focus Lost handler
function Lootster_Roll_Items_OnFocusLost(self)
	-- get the new item count
	Lootster_ItemCount = Lootster_RollFrameItems:GetNumber();

	-- must be positive
	if (Lootster_ItemCount <= 0) then
		Lootster_ItemCount = 1;
	end

	-- update
	Lootster_RollFrameItems:SetNumber(Lootster_ItemCount);

	-- copy won item count if not tied
	if (Lootster_Tied ~= true) then
		Lootster_WonItemCount = Lootster_ItemCount;
	end

	-- update item prompt
	Lootster_UpdateItemPrompt();
end

-- DKP Override handler
function Lootster_Roll_DKPMan_OnTextChanged(self)
	local	dkpText, dkpValue;

	-- we only need to worry if we have a link
	if (Lootster_ItemLink == nil) then
		return;
	end

	-- get the manual DKP value, if any
	dkpText = Lootster_RollFrameDKPMan:GetText();

	-- convert to numeric
	dkpValue = tonumber(dkpText);

	-- depending on the type of loot dkp we are handling, manage the action and state
	-- of the update button
	if		(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.NONE) then
		-- set action as create
		Lootster_RollFrameDKPUpdate:SetText(LOOTSTER_ROLL_DKPCREATE);

		-- enable DKP clear and action depending on valid DKP value
		if (dkpValue ~= nil) then
			Lootster_RollFrameClearDKP:Enable();
			Lootster_RollFrameDKPUpdate:Enable();
		elseif	(dkpText ~= "") then 
			Lootster_RollFrameClearDKP:Enable();
			Lootster_RollFrameDKPUpdate:Disable();
		else
			Lootster_RollFrameClearDKP:Disable();
			Lootster_RollFrameDKPUpdate:Disable();
		end
	elseif	(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.OFFICIAL) then
		-- set action as set
		Lootster_RollFrameDKPUpdate:SetText(LOOTSTER_ROLL_DKPSET);

		-- enable action depending on the manual DKP text
		if		(dkpValue ~= nil) then
			Lootster_RollFrameClearDKP:Enable();
			Lootster_RollFrameDKPUpdate:Enable();
		elseif	(dkpText ~= "") then 
			Lootster_RollFrameClearDKP:Enable();
			Lootster_RollFrameDKPUpdate:Disable();
		else
			Lootster_RollFrameClearDKP:Disable();
			Lootster_RollFrameDKPUpdate:Disable();
		end
	elseif	(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE) then
		-- determine action depending on the manual DKP text
		if		(dkpText == "") then
			-- set action as reset
			Lootster_RollFrameDKPUpdate:SetText(LOOTSTER_ROLL_DKPRESET);

			-- disable clear and enable action
			Lootster_RollFrameClearDKP:Disable();
			Lootster_RollFrameDKPUpdate:Enable();
		 else
			-- set action as reapply
			Lootster_RollFrameDKPUpdate:SetText(LOOTSTER_ROLL_DKPREAPP);

			-- enable action depending on valid DKP value
			if		(dkpValue ~= nil) then
				Lootster_RollFrameClearDKP:Enable();
				Lootster_RollFrameDKPUpdate:Enable();
			elseif	(dkpText ~= "") then 
				Lootster_RollFrameClearDKP:Enable();
				Lootster_RollFrameDKPUpdate:Disable();
			else
				Lootster_RollFrameClearDKP:Disable();
				Lootster_RollFrameDKPUpdate:Disable();
			end
		end
	elseif	(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY) then
		-- determine action depending on the manual DKP text
		if		(dkpText == "") then
			-- set action as delete
			Lootster_RollFrameDKPUpdate:SetText(LOOTSTER_ROLL_DKPDELETE);

			-- disable clear and enable action
			Lootster_RollFrameClearDKP:Disable();
			Lootster_RollFrameDKPUpdate:Enable();
		 else
			-- set action as modify
			Lootster_RollFrameDKPUpdate:SetText(LOOTSTER_ROLL_DKPMODIFY);

			-- enable action depending on valid DKP value
			if (dkpValue ~= nil) then
				Lootster_RollFrameClearDKP:Enable();
				Lootster_RollFrameDKPUpdate:Enable();
			elseif	(dkpText ~= "") then 
				Lootster_RollFrameClearDKP:Enable();
				Lootster_RollFrameDKPUpdate:Disable();
			else
				Lootster_RollFrameClearDKP:Disable();
				Lootster_RollFrameDKPUpdate:Disable();
			end
		end
	end
end

-- DKP Clear Click handler
function Lootster_Roll_ClearDKP_OnClick(self, button)
	-- this is easy
	Lootster_RollFrameDKPMan:SetText("");

	-- force management of DKP update action and state
	Lootster_Roll_DKPMan_OnTextChanged(self); 
end

-- DKP Update Click handler
function Lootster_Roll_DKPUpdate_OnClick(self, button)
	local	dkpText, dkpValue;

	-- we only need to worry if we have a link
	if (Lootster_ItemLink == nil) then
		return;
	end

	-- get the manual DKP value, if any
	dkpText = Lootster_RollFrameDKPMan:GetText();

	-- convert to numeric
	dkpValue = tonumber(dkpText);

	-- depending on the type of loot dkp we are handling, manage the action and state
	-- of the update button
	if		(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.NONE) then
		-- if we have a valid DKP value then create the local loot entry
		if (dkpValue ~= nil) then
			-- create a provisional DKP loot entry
			Lootster_Loot[Lootster_ItemText] = Lootster_NewLoot(string.lower(Lootster_ItemText), nil, LOOTSTER_MSG_LOOTDKPMOB, dkpValue);

			-- and point to this entry from the official DKP loot table
			Lootster_ItemDKP[Lootster_ItemText] = Lootster_Loot[Lootster_ItemText];

			-- force the hyperlink back in so we reinitialise UI
			Lootster_SetHyperlink(Lootster_ItemLink);
		end
	elseif	(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.OFFICIAL) then
		-- if we have a valid DKP value then place an override into the official DKP loot entry
		if (dkpValue ~= nil) then
			-- do we have an official entry?
			if (Lootster_ItemDKP[Lootster_ItemText] == nil) then
				-- we are using calculated item points, which in this case is the 'official' DKP.  We need to create
				-- and new loot entry for that.  The official DKP is nil to cause it to be recalculated each time
				Lootster_Loot[Lootster_ItemText] = Lootster_NewLoot(string.lower(Lootster_ItemText), nil, LOOTSTER_MSG_LOOTDKPMOB, dkpValue);

				-- and point to this entry from the official DKP loot table
				Lootster_ItemDKP[Lootster_ItemText] = Lootster_Loot[Lootster_ItemText];
			else
				-- create override DKP in official DKP loot entry
				Lootster_ItemDKP[Lootster_ItemText].DKPMan = dkpValue;

				-- and point to this entry from the provisional DKP loot table
				Lootster_Loot[Lootster_ItemText] = Lootster_ItemDKP[Lootster_ItemText];
			end

			-- force the hyperlink back in so we reinitialise UI
			Lootster_SetHyperlink(Lootster_ItemLink);
		end
	elseif	(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE) then
		-- see if we have no dkp text or if we have a valid DKP value
		if		(dkpText == "") then
			-- no DKP text, so reset the override in the official DKP loot entry			
			Lootster_ItemDKP[Lootster_ItemText].DKPMan = nil;

			-- force the hyperlink back in so we reinitialise UI
			Lootster_SetHyperlink(Lootster_ItemLink);
		elseif	(dkpValue ~= nil) then
			-- modify override DKP in official DKP loot entry
			Lootster_ItemDKP[Lootster_ItemText].DKPMan = dkpValue;

			-- force the hyperlink back in so we reinitialise UI
			Lootster_SetHyperlink(Lootster_ItemLink);
		end
	elseif	(Lootster_ItemDKPLootType == LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY) then
		-- see if we have no dkp text or if we have a valid DKP value
		if		(dkpText == "") then
			-- no DKP text, so delete the provisioal DKP loot entry			
			Lootster_ItemDKP[Lootster_ItemText] = nil;

			-- and delete entry from the provisional DKP loot table
			Lootster_Loot[Lootster_ItemText] = nil;

			-- force the hyperlink back in so we reinitialise UI
			Lootster_SetHyperlink(Lootster_ItemLink);
		elseif	(dkpValue ~= nil) then
			-- modify provisioal DKP in provisioal DKP loot entry
			Lootster_ItemDKP[Lootster_ItemText].DKPMan = dkpValue;

			-- force the hyperlink back in so we reinitialise UI
			Lootster_SetHyperlink(Lootster_ItemLink);
		end
	end
end

-- Roll Hold Click handler
function Lootster_Roll_Hold_OnClick(self, button)
	-- toggle the held status if we are the master looter/leader
	if (Lootster_LootMaster == Lootster_Self) then
		local	offset, player;

		-- retrieve the scroll offset
		offset = FauxScrollFrame_GetOffset(Lootster_RollFrameScrollFrame);

		-- calculate actual the roll index and get the player
		player = Lootster_RollsSort[self:GetParent():GetID() + offset];

		-- toggle the player's roll held status
		Lootster_Rolls[player].Hold = not Lootster_Rolls[player].Hold;

		-- send hold roll addon message
		Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_HOLDROLL, LOOTSTER_ADDON_VERSION, player, tostring(Lootster_Rolls[player].Hold)), true);

		-- let the party/raid know what we did
		if (Lootster_Rolls[player].Hold) then
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_HOLDROLL, player));
		else
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, string.format(LOOTSTER_MSG_ALLOWROLL, player));
		end

		-- resort the rolls
		Lootster_Roll_Sort();

		-- update received roll status
		Lootster_UpdateRollUI();	

		-- update the screen
		Lootster_Roll_Update();
	end
end

-- Roll Hold Enter handler
function Lootster_Roll_Hold_OnEnter(self)
	local	offset, player;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RollFrameScrollFrame);

	-- calculate actual the roll index and get the player
	player = Lootster_RollsSort[self:GetParent():GetID() + offset];

	if (Lootster_Rolls[player].Hold) then
		return LOOTSTER_ROLL_ALLOW_TT;
	else
		return LOOTSTER_ROLL_HOLD_TT;
	end
end

-- Restrict Roll handler
function Lootster_Class_RestrictRoll_OnClick(self, button)
	-- reset class restrictions
	Lootster_ResetClass();

	-- update the class UI
	Lootster_UpdateClassUI();

	-- update the UI
	Lootster_UpdateRollUI();

	-- toggle the class restriction frame
	if (Lootster_ClassFrame:IsVisible()) then
		Lootster_ClassFrame:Hide();
	else
		Lootster_ClassFrame:Show();
	end
end

-- Restrict Roll Class handler
function Lootster_Class_PermitButton_OnToggle(self)
	local	button, class, new;

	-- classes cannot be locked down
	if (Lootster_ClassRestrictedLock == false) then
		-- get the class item button
		button = _G["Lootster_ClassFrameClass"..self:GetID().."Text"];

		-- retrieve the invariant class for this guy
		class = Lootster_ClassSingular[button:GetText()];

		-- is this a new class entry?
		if (Lootster_ClassRestrictions[class] == nil) then
			-- bump count
			Lootster_ClassRestrictionsN = Lootster_ClassRestrictionsN + 1;
		end

		-- mark the class appropriately
		Lootster_ClassRestrictions[class] = (self:GetChecked() ~= nil);

		-- update the current restriction mask accordingly
		if (Lootster_ClassRestrictions[class] == false) then
			Lootster_ClassRestrictionsMaskCurr = bit.band(Lootster_ClassRestrictionsMaskCurr, bit.bnot(LOOTSTER_CLASS[class].Mask));
		else
			Lootster_ClassRestrictionsMaskCurr = bit.bor(Lootster_ClassRestrictionsMaskCurr, LOOTSTER_CLASS[class].Mask);
		end

		-- mark roll as class restricted if we have some classes marked
		Lootster_ClassRestricted = (Lootster_ClassRestrictionsMaskCurr ~= 0);

		-- update restricted count
		Lootster_UpdateRestricted();

		-- update the UI
		Lootster_UpdateRollUI();
	end
end

-- Display Custom Restrictions Class handler
function Lootster_Class_Display_OnClick(self, button, itemLink)
	local	itemText, permitted;

	-- have we been passed a link, or are we to use current?
	if (itemLink == nil) then
		-- use current link
		itemLink = Lootster_ItemLink;
	end

	-- create restrictions message
	itemText, permitted = Lootster_CreateRestricts(itemLink);

	-- do we have an item?
	if (itemLink == nil) then
		-- punching this out to party/raid?
		if (Lootster_Options.EchoToChat == true) then
			-- broadcast
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_CHATRESTRICT, LOOTSTER_LABEL_LOOTSTER, permitted), true);
		end

		-- punching this out to Raid Warning?
		if ((Lootster_Options.EchoToRW == true) and ((UnitIsGroupLeader("player") == true) or (UnitIsGroupAssistant("player") == true))) then
			-- broadcast to raid warning
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_CHATRESTRICT, LOOTSTER_LABEL_LOOTSTER, permitted), true, "RAID_WARNING");
		end
	else
		-- punching this out to party/raid?
		if (Lootster_Options.EchoToChat == true) then
			-- broadcast
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_CHATRESTRICT_LINK, LOOTSTER_LABEL_LOOTSTER, itemText, permitted), true);
		end

		-- punching this out to Raid Warning and we are able to?
		if ((Lootster_Options.EchoToRW == true) and ((UnitIsGroupLeader("player") == true) or (UnitIsGroupAssistant("player") == true))) then
			-- broadcast to raid warning
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_CHATRESTRICT_LINK, LOOTSTER_LABEL_LOOTSTER, itemText, permitted), true, "RAID_WARNING");
		end
	end
end

-- Class Remember Restrictions handler
function Lootster_Class_Remember_OnClick(self, button)
	-- if the restrictions are not locked we can save our own settings
	if ((Lootster_ClassRestrictedLock == false) and (Lootster_ItemID ~= nil)) then
		local	class, flag;

		local	classes = {};

		-- prepare list of classes
		for class, flag in pairs(Lootster_ClassRestrictions) do
			-- this guy on?
			if (flag == true) then
				-- snarf
				table.insert(classes, class);
			end
		end

		-- update the restricted loot table
		Lootster_Restrict[Lootster_ItemID] = Lootster_NewRestrict(Lootster_ItemText, classes);

		-- update the original restrictions mask
		Lootster_ClassRestrictionsMaskOrig = Lootster_ClassRestrictionsMaskCurr;

		-- resort item
		Lootster_Item_Sort(nil);

		-- update the UI
		Lootster_UpdateRollUI();
	end
end

-- Class Forget Restrictions handler
function Lootster_Class_Forget_OnClick(self, button)
	-- if the restricted roll button is disabled, this is class loot, and we just ignore
	if ((Lootster_ClassRestrictedLock == false) and (Lootster_ItemID ~= nil)) then
		-- smack this entry
		Lootster_Restrict[Lootster_ItemID] = nil;

		-- reset the original and current restrictions mask
		Lootster_ClassRestrictionsMaskOrig = 0;

		-- resort item
		Lootster_Item_Sort(nil);

		-- update the UI
		Lootster_UpdateRollUI();
	end
end

-- Roll Row Click handler
function Lootster_Roll_Button_OnClick(self, button)
end

-- Roll Row Enter handler
function Lootster_Roll_Button_OnEnter(self)
	local	offset, player;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RollFrameScrollFrame);

	-- calculate actual the roll index and get the player
	player = Lootster_RollsSort[self:GetID() + offset];

	if (Lootster_Rolls[player].Hold) then
		return LOOTSTER_ROLL_HELD_TT;
	else
		return LOOTSTER_ROLL_ALLOWED_TT;
	end
end

-- Roll Update handler
function Lootster_Roll_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowRoll, rowHold, rowClass, rowDKP, rowResult, rowMember, rowToon, rowBad, rowDup, rowShow, rowHide;

	local	item, roll, clrCode, tier;

	-- retrieve count of roll items
	count = #Lootster_RollsSort;	

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RollFrameScrollFrame);

	-- hammer through the roll frame rows
	for row=1, LOOTSTER_ROLL_LINES, 1 do
		-- calculate actual the roll item index
		ix = row + offset;

		-- retrieve the row components
		rowButton	= _G["Lootster_RollFrameButton"..row];

		-- do we have roll for the row?
		if (ix <= count) then
			-- get the text elements
			rowName		= _G["Lootster_RollFrameButton"..row.."Name"];
			rowRoll		= _G["Lootster_RollFrameButton"..row.."Roll"];
			rowHold		= _G["Lootster_RollFrameButton"..row.."Hold"];
			rowClass	= _G["Lootster_RollFrameButton"..row.."Class"];
			rowDKP		= _G["Lootster_RollFrameButton"..row.."DKP"];
			rowUsage	= _G["Lootster_RollFrameButton"..row.."Usage"];
			rowResult	= _G["Lootster_RollFrameButton"..row.."Result"];
			rowMember	= _G["Lootster_RollFrameButton"..row.."Member"];
			rowToon		= _G["Lootster_RollFrameButton"..row.."Toon"];
			rowBad		= _G["Lootster_RollFrameButton"..row.."Bad"];
			rowDup		= _G["Lootster_RollFrameButton"..row.."Dup"];

			-- okay, retrieve the roll item
			item = Lootster_Rolls[Lootster_RollsSort[ix]];

			-- format the requisiste roll and stuff into the text elements
			rowName:SetText(item.Player);
			
			-- set the class colour of the player
			rowName:SetTextColor(RAID_CLASS_COLORS[item.ClassType].r, RAID_CLASS_COLORS[item.ClassType].g, RAID_CLASS_COLORS[item.ClassType].b);

			-- master looter/leader?
			if (Lootster_LootMaster ~= Lootster_Self) then
				-- not the master looter/leader, so show normal roll widget
				rowShow = rowRoll;
				rowHide = rowHold;
			else
				-- master looter/leader, so show hold button
				rowShow = rowHold;
				rowHide = rowRoll;
			end

			-- determine colour for indicating held status
			if (item.Hold) then
				-- set held text color
				clrCode = LOOTSTER_ROLL_HELD_CLR_CODE;
			else
				-- set allowed text color
				clrCode = LOOTSTER_ROLL_ALLOW_CLR_CODE;
			end

			-- nil roll?
			if (item.Roll == nil) then
				rowShow:SetText(clrCode.."-|r");
			else
				rowShow:SetText(clrCode..item.Roll.."|r");
			end

			-- show/hide appropriately
			rowShow:Show();
			rowHide:Hide();

			-- are we using DKP?
			if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				-- set up the valies
				rowDKP:SetFormattedText(LOOTSTER_COST_POINTS, item.DKP);
				
				-- usage rolling and not modified roll by DKP?
				if ((Lootster_Options.UsageRolls == true) and (Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYMODIFIEDROLL)) then
					-- nil roll?
					if (item.Roll == nil) then
						rowUsage:SetText("-");
					else
						-- determine what kind of roll
						rowUsage:SetText(LOOTSTER_USAGEDKP_LIST[item.Usage]);
					end
				else
					rowUsage:SetText("");
				end
				
				-- DKP by DKP+Roll or Tier?
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
					-- show a message for a bad tier
					if (item.Tier == LOOTSTER_TIER_UNKNOWN) then
						rowResult:SetText(LOOTSTER_MSG_UNKNOWNTIER);
					else
						rowResult:SetText(item.Tier);
					end
				elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
					-- have we a roll yet?
					if (item.Roll == nil) then
						rowResult:SetText("-");
					else
						-- set roll result as DKP+roll
						rowResult:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_GetPlayerResult(item));
					end
				else
					rowResult:SetText("");
				end

				-- using membership?
				if (Lootster_Options.DKPMember == true) then
					rowMember:SetText(LOOTSTER_MEMBER_LIST[item.Member]);
				else
					rowMember:SetText("");
				end

				-- using toonship?
				if (Lootster_Options.DKPToon == true) then
					rowToon:SetText(LOOTSTER_TOON_LIST[item.Toon]);
				else
					rowToon:SetText("");
				end
			elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
				-- erase values
				rowDKP:SetText("");

				-- 100/1000 mode?
				if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
					-- nil roll?
					if (item.Roll == nil) then
						rowUsage:SetText("-");
					else
						-- determine what kind of roll
						rowUsage:SetText(LOOTSTER_USAGENORM_LIST[item.Usage]);
					end
				else
					rowUsage:SetText("");
				end
				
				-- erase result
				rowResult:SetText("");

				-- using membership?
				if (Lootster_Options.NormMember == true) then
					rowMember:SetText(LOOTSTER_MEMBER_LIST[item.Member]);
				else
					rowMember:SetText("");
				end

				-- using toonship?
				if (Lootster_Options.NormToon == true) then
					rowToon:SetText(LOOTSTER_TOON_LIST[item.Toon]);
				else
					rowToon:SetText("");
				end
			else
				-- erase values
				rowDKP:SetText("");
				rowResult:SetText("");
				rowMember:SetText("");
				rowToon:SetText("");
			end

			if (item.Bad == nil) then
				rowBad:SetText("-");
			else
				rowBad:SetText(item.Bad);
			end

			if (item.Dup == nil) then
				rowDup:SetText("-");
			else
				rowDup:SetText(item.Dup);
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RollFrameScrollFrame, count, LOOTSTER_ROLL_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Data Whisper All handler
function Lootster_Data_WhisperAll_OnClick(self, button)
	-- hammer through the roster whispering each their DKP
	for player, value in pairs(Lootster_Roster) do
		-- echo points and roll to player
		Lootster_EchoPlayerPoints(player, player);
		Lootster_EchoPlayerRoll(player, true);
	end
end

-- Data Whisper Player handler
function Lootster_Data_DKP_WhisperPlayer_OnClick(self, button)
	local	offset, button, key, player;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameDKPFrameScrollFrame);

	-- calculate actual the dkp item index and get the dkp record key
	key = Lootster_DKPSort[self:GetParent():GetID() + offset];

	-- get the DKP item
	player = Lootster_DKP[key].Player;

	-- echo points to player
	Lootster_EchoPlayerPoints(player, player, true);
end

-- Data DKP Row Click handler
function Lootster_Data_DKP_Button_OnClick(self, button)
	local	offset, key;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameDKPFrameScrollFrame);

	-- calculate actual the dkp item index and get the dkp record key
	key = Lootster_DKPSort[self:GetID() + offset];

	-- snarf the new player Id
	Lootster_PlayerId = Lootster_DKP[key].Player;
	
	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);
	
	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
end

-- Data Attend Row Double Click handler
function Lootster_Data_Attend_Button_OnDoubleClick(self, button)
	local	offset, offsetRaid, offsetBoss, offsetAttend;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAttendFrameScrollFrame);

	-- ignore if this is the total row
	if ((self:GetID() + offset) > #Lootster_DataAttendSort) then
		return;
	end
	
	-- retrieve the id of the attendance, boss and raid
	Lootster_AttendId = Lootster_DataAttendSort[self:GetID() + offset];
	Lootster_BossId = Lootster_Attend[Lootster_AttendId].BossId;
	Lootster_RaidId = Lootster_Boss[Lootster_BossId].RaidId;
	Lootster_AdjustId = nil;
	Lootster_AssignId = nil;

	-- construct the boss, attend, adjust and assign lists
	Lootster_Raid_Boss_Sort(nil);
	Lootster_Raid_Attend_Sort(nil);
	Lootster_Raid_Adjust_Sort(nil);
	Lootster_Raid_Assign_Sort(nil);

	-- locate the raid, boss and attend in their respective lists
	offsetRaid = Looster_Find(Lootster_RaidSort, Lootster_RaidId) - 1;
	offsetBoss = Looster_Find(Lootster_BossSort, Lootster_BossId) - 1;
	offsetAttend = Looster_Find(Lootster_BossAttendSort, Lootster_AttendId) - 1;
	
	-- any not found means we are done
	if ((offsetRaid == -1) or (offsetBoss == -1) or (offsetAttend == -1)) then
		return;
	end
	
	-- flip raid view mode to attendance
	Lootster_ViewRaidType = LOOTSTER_ENUM_VIEWRAID.BYATTEND;

	-- scroll to the raid raid
	Lootster_SetScrollPosition(Lootster_RaidFrameRaidFrameScrollFrame, offsetRaid, LOOTSTER_RAIDRAID_LINES);
	
	-- scroll to the raid boss
	Lootster_SetScrollPosition(Lootster_RaidFrameBossFrameScrollFrame, offsetBoss, LOOTSTER_RAIDBOSS_LINES);
	
	-- scroll to the boss attend
	Lootster_SetScrollPosition(Lootster_RaidFrameBossAttendFrameScrollFrame, offsetAttend, LOOTSTER_BOSSATTEND_LINES);

	-- update the raid UI
	Lootster_UpdateRaidUI();
	
	-- change to raid tab
	Lootster_ChangeTab(Lootster_RaidTab);	
end

-- Data Attend Row Enter handler
function Lootster_Data_Attend_Button_OnEnter(self)
	local	offset;
	
	-- ignore if no player ID
	if (Lootster_PlayerId == nil) then
		return false;
	end

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAttendFrameScrollFrame);

	-- we have a tooltip if this isn't the total row
	return (self:GetID() + offset) <= #Lootster_DataAttendSort;
end

-- Data Adjust Row Click handler
function Lootster_Data_Adjust_Button_OnClick(self, button)
	local	offset, key, itemLink;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAdjustFrameScrollFrame);

	-- calculate actual the adjustment item index and get the adjustment record index
	key = Lootster_DataAdjustSort[self:GetID() + offset];
	
	-- ignore click if no link
	if (Lootster_Adjust[key].Link == nil) then
		return;
	end

	-- pass link to tooltip click handler
	Lootster_ClickTooltip(Lootster_Adjust[key].Link, button);
end

-- Data Adjust Row Double Click handler
function Lootster_Data_Adjust_Button_OnDoubleClick(self, button)
	local	offset, offsetRaid, offsetBoss, offsetAdjust;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAdjustFrameScrollFrame);

	-- ignore if this is the total row
	if ((self:GetID() + offset) > #Lootster_DataAdjustSort) then
		return;
	end
	
	-- retrieve the id of the adjustment, boss and raid
	Lootster_AdjustId = Lootster_DataAdjustSort[self:GetID() + offset];
	Lootster_BossId = Lootster_Adjust[Lootster_AdjustId].BossId;
	Lootster_RaidId = Lootster_Boss[Lootster_BossId].RaidId;
	Lootster_AttendId = nil;
	Lootster_AssignId = nil;

	-- construct the boss, attend, adjust and assignlists
	Lootster_Raid_Boss_Sort(nil);
	Lootster_Raid_Attend_Sort(nil);
	Lootster_Raid_Adjust_Sort(nil);
	Lootster_Raid_Assign_Sort(nil);
	
	-- locate the raid, boss and attend in their respective lists
	offsetRaid = Looster_Find(Lootster_RaidSort, Lootster_RaidId) - 1;
	offsetBoss = Looster_Find(Lootster_BossSort, Lootster_BossId) - 1;
	offsetAdjust = Looster_Find(Lootster_BossAdjustSort, Lootster_AdjustId) - 1;
	
	-- any not found means we are done
	if ((offsetRaid == -1) or (offsetBoss == -1) or (offsetAdjust == -1)) then
		return;
	end
	
	-- flip raid view mode to adjustment
	Lootster_ViewRaidType = LOOTSTER_ENUM_VIEWRAID.BYADJUST;

	-- scroll to the raid raid
	Lootster_SetScrollPosition(Lootster_RaidFrameRaidFrameScrollFrame, offsetRaid, LOOTSTER_RAIDRAID_LINES);
	
	-- scroll to the raid boss
	Lootster_SetScrollPosition(Lootster_RaidFrameBossFrameScrollFrame, offsetBoss, LOOTSTER_RAIDBOSS_LINES);
	
	-- scroll to the boss adjust
	Lootster_SetScrollPosition(Lootster_RaidFrameBossAdjustFrameScrollFrame, offsetAdjust, LOOTSTER_BOSSADJUST_LINES);

	-- update the raid UI
	Lootster_UpdateRaidUI();
	
	-- change to raid tab
	Lootster_ChangeTab(Lootster_RaidTab);	
end

-- Data Adjust Row Enter handler
function Lootster_Data_Adjust_Button_OnEnter(self)
	local	offset;
	
	-- ignore if no player ID
	if (Lootster_PlayerId == nil) then
		return false;
	end

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAdjustFrameScrollFrame);

	-- we have a tooltip if this isn't the total row
	return (self:GetID() + offset) <= #Lootster_DataAdjustSort;
end

-- Loot Synchronise handler
function Lootster_Loot_Sync_OnClick(self, button)
	-- show the loot sync dialog
	Lootster_Popup_Show(Lootster_LootSyncFrame);
end

-- Loot Clear Item Link handler
function Lootster_Loot_ClearItem_OnClick(self, button)
	-- reset the hyperlinks
	Lootster_SetHyperlink(nil);
end

-- Loot Loot Link Click handler
function Lootster_Loot_ItemLink_OnClick(self, button)
	-- do we have a link?
	if (Lootster_ItemLink ~= nil) then
		-- pass link to tooltip click handler
		Lootster_ClickTooltip(Lootster_ItemLink, button);
	end
end

-- Loot Row Click handler
function Lootster_Loot_Button_OnClick(self, button)
	local	offset, lootId;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_LootFrameScrollFrame);

	-- calculate actual the DKP loot index and get the DKP loot record key
	lootId = Lootster_LootSort[self:GetID() + offset];
end

-- Loot Row Enter handler
function Lootster_Loot_Button_OnEnter(self)
	local	offset, lootId, dkpOff, dkpMan;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_LootFrameScrollFrame);

	-- calculate actual the loot index and get the loot record key
	lootId = Lootster_LootSort[self:GetID() + offset];

	-- do we use calculated points or do we have official DKP?
	if		(Lootster_Options.CalcPoints == true) then
		dkpOff = LOOTSTER_COST_DKPCALC;
	elseif	(Lootster_ItemDKP[lootId].DKP ~= nil) then
		dkpOff = string.format(LOOTSTER_COST_POINTS, Lootster_ItemDKP[lootId].DKP);
	else
		dkpOff = LOOTSTER_COST_DKPNONE;
	end

	-- do we have overridden DKP?
	if (Lootster_ItemDKP[lootId].DKPMan ~= nil) then
		dkpMan = string.format(LOOTSTER_COST_POINTS, Lootster_ItemDKP[lootId].DKPMan);
	else
		dkpMan = LOOTSTER_COST_DKPNONE;
	end
	
	-- format restricted loot tooltip
	tooltip = string.format(LOOTSTER_MSG_LOOTTOOLTIP, lootId, dkpOff, dkpMan);
	
	return tooltip;	
end

-- Loot Clear DKP Click handler
function Lootster_Loot_DKP_Clear_OnClick(self, button)
	local	offset, lootId;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_LootFrameScrollFrame);

	-- calculate actual the loot index and get the loot record key
	lootId = Lootster_LootSort[self:GetParent():GetID() + offset];

	-- hammer the manual DKP for this guy
	Lootster_ItemDKP[lootId].DKPMan = nil;

	-- is this our current loot?
	if (Lootster_ItemText == lootId) then
		-- resnarf as existing hyperlink
		Lootster_SetHyperlink(Lootster_ItemLink);
	else
		-- resort loot using current sort
		Lootster_Loot_Sort(nil);
	end
end

-- Loot Delete Click handler
function Lootster_Loot_Delete_OnClick(self, button)
	local	offset;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_LootFrameScrollFrame);

	-- calculate actual the restricted loot index and get the loot record key
	Lootster_ItemSel = Lootster_LootSort[self:GetParent():GetID() + offset];

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_LOOT_DELETE");
end

-- Loot Clear ALL handler
function Lootster_Loot_ClearAll_OnClick(self, button)
	-- show clear ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_LOOT_CLEARALL");
end

-- Loot Delete ALL handler
function Lootster_Loot_DeleteAll_OnClick(self, button)
	-- show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_LOOT_DELETEALL");
end

-- Loot Delete Accept handler
function Lootster_Loot_Delete_OnAccept()
	-- far too easy
	Lootster_Loot[Lootster_ItemSel] = nil;
	Lootster_ItemDKP[Lootster_ItemSel] = nil;

	-- is this our current loot?
	if (Lootster_ItemText == Lootster_ItemSel) then
		-- resnarf as existing hyperlink
		Lootster_SetHyperlink(Lootster_ItemLink);
	else
		-- resort loot using current sort
		Lootster_Loot_Sort(nil);
	end
	
	-- reset selected loot ID
	Lootster_ItemSel = nil;
end

-- Loot Delete Cancel handler
function Lootster_Loot_Delete_OnCancel()
	-- reset restricted loot key
	Lootster_ItemSel = nil;
end

-- Loot Clear ALL Accept handler
function Lootster_Loot_ClearAll_OnAccept()
	local	lootId, lootRec;

	-- hammer through loot table clearing all official DKP overrides
	for lootId, lootRec in pairs(Lootster_Loot) do
		-- clear this guy if it is official and has a DKP override
		if ((Lootster_ItemDKP[lootId].DKP ~= nil) and (Lootster_ItemDKP[lootId].DKPMan ~= nil)) then
			-- clear official DKP override
			Lootster_ItemDKP[lootId].DKPMan = nil;
		end
	end

	-- resnarf existing hyperlink, if any
	Lootster_SetHyperlink(Lootster_ItemLink);
end

-- Loot Delete ALL Accept handler
function Lootster_Loot_DeleteAll_OnAccept()
	local	lootId, lootRec;

	-- hammer through loot table erasing all provisory DKP loot entries
	for lootId, lootRec in pairs(Lootster_Loot) do
		-- delete this guy if it is provisory
		if (Lootster_ItemDKP[lootId].DKP == nil) then
			-- far too easy
			Lootster_Loot[lootId] = nil;
			Lootster_ItemDKP[lootId] = nil;
		end
	end

	-- resnarf existing hyperlink, if any
	Lootster_SetHyperlink(Lootster_ItemLink);
end

-- Update Raid UI handler
function Lootster_UpdateRaidUI()
	-- if we have loot linked, we will allow them to assign loot (Bank/Rotted) if we have a running boss
	if ((Lootster_ItemLink ~= nil) and (Lootster_Running.RaidId ~= nil) and (Lootster_Running.BossId ~= nil) and (#Lootster_Won > 0)) then
		-- allow loot assignment without roll
		Lootster_RollFrameAssignLoot:Enable();
	else
		-- disallow loot assignment
		Lootster_RollFrameAssignLoot:Disable();
	end

	-- any raids?
	if (#Lootster_RaidSort == 0) then
		-- disable all raid reporting
		Lootster_RaidFrameReportFull:Disable();

		-- disable raid delete all
		Lootster_RaidFrameRaidFrameDeleteAll:Disable();
	else
		-- update the full reporting buttons depending on formatter
		if ((Lootster_RepList[Lootster_Options.RepFormat] == nil) or (bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.FULL) == 0)) then
			Lootster_RaidFrameReportFull:Disable();
		else
			Lootster_RaidFrameReportFull:Enable();
		end

		-- enable raid delete all
		Lootster_RaidFrameRaidFrameDeleteAll:Enable();
	end		

	-- determine state of raid/boss/attendance/adjustment buttons
	if	(Lootster_RaidId == nil) then
		-- disable raid reporting
		Lootster_RaidFrameReportRaid:Disable();

		-- disable raid modification and deletion
		Lootster_RaidFrameRaidFrameModify:Disable();
		Lootster_RaidFrameRaidFrameDelete:Disable();

		-- disable boss creation
		Lootster_RaidFrameBossFrameCreate:Disable();

		-- disable boss delete all
		Lootster_RaidFrameBossFrameDeleteAll:Disable();
	else
		-- update the raid reporting buttons depending on formatter
		if ((Lootster_RepList[Lootster_Options.RepFormat] == nil) or (bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.RAID) == 0)) then
			Lootster_RaidFrameReportRaid:Disable();
		else
			Lootster_RaidFrameReportRaid:Enable();
		end

		-- enable raid modification
		Lootster_RaidFrameRaidFrameModify:Enable();

		-- is this the running raid?
		if (Lootster_RaidId == Lootster_Running.RaidId) then
			-- disable raid deletion
			Lootster_RaidFrameRaidFrameDelete:Disable();
		else
			-- enable raid deletion
			Lootster_RaidFrameRaidFrameDelete:Enable();
		end

		-- enable boss creation
		Lootster_RaidFrameBossFrameCreate:Enable();

		-- any bosses?
		if (Lootster_Raid[Lootster_RaidId].BossN == 0) then
			Lootster_RaidFrameBossFrameDeleteAll:Disable();
		else
			Lootster_RaidFrameBossFrameDeleteAll:Enable();
		end		
	end

	if	(Lootster_BossId == nil) then
		-- disable boss reporting
		Lootster_RaidFrameReportBoss:Disable();

		-- disable boss modification and deletion
		Lootster_RaidFrameBossFrameModify:Disable();
		Lootster_RaidFrameBossFrameDelete:Disable();

		-- disable taking roster
		Lootster_RaidFrameBossAttendFrameUseRoster:Disable();

		-- disable assignnation all
		Lootster_RaidFrameBossAssignFrameAssignAll:Disable();

		-- disable attendance and adjustment creation, and assignment assignation
		Lootster_RaidFrameBossAttendFrameCreate:Disable();
		Lootster_RaidFrameBossAdjustFrameCreate:Disable();
		Lootster_RaidFrameBossAssignFrameAssign:Disable();

		-- disable attendance, adjustment and assignment delete all
		Lootster_RaidFrameBossAttendFrameDeleteAll:Disable();
		Lootster_RaidFrameBossAdjustFrameDeleteAll:Disable();
		Lootster_RaidFrameBossAssignFrameDeleteAll:Disable();
	else
		-- update the boss reporting buttons depending on formatter
		if ((Lootster_RepList[Lootster_Options.RepFormat] == nil) or (bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.BOSS) == 0)) then
			Lootster_RaidFrameReportBoss:Disable();
		else
			Lootster_RaidFrameReportBoss:Enable();
		end

		-- enable boss modification
		Lootster_RaidFrameBossFrameModify:Enable();

		-- is this the running boss?
		if (Lootster_BossId == Lootster_Running.BossId) then
			-- disable boss deletion
			Lootster_RaidFrameBossFrameDelete:Disable();
		else
			-- enable boss deletion
			Lootster_RaidFrameBossFrameDelete:Enable();
		end

		-- enable taking roster
		Lootster_RaidFrameBossAttendFrameUseRoster:Enable();

		-- enable attendance and adjustment creation
		Lootster_RaidFrameBossAttendFrameCreate:Enable();
		Lootster_RaidFrameBossAdjustFrameCreate:Enable();

		-- any attendances?
		if (Lootster_Boss[Lootster_BossId].AttendN == 0) then
			Lootster_RaidFrameBossAttendFrameDeleteAll:Disable();
		else
			Lootster_RaidFrameBossAttendFrameDeleteAll:Enable();
		end		

		-- any adjustments?
		if (Lootster_Boss[Lootster_BossId].AdjustN == 0) then
			Lootster_RaidFrameBossAdjustFrameDeleteAll:Disable();
		else
			Lootster_RaidFrameBossAdjustFrameDeleteAll:Enable();
		end		

		-- any assignments?
		if (Lootster_Boss[Lootster_BossId].AssignN == 0) then
			Lootster_RaidFrameBossAssignFrameAssignAll:Disable();
			Lootster_RaidFrameBossAssignFrameDeleteAll:Disable();
		else
			Lootster_RaidFrameBossAssignFrameAssignAll:Enable();
			Lootster_RaidFrameBossAssignFrameDeleteAll:Enable();
		end		
	end

	if	(Lootster_AttendId == nil) then
		-- disable attend modification and deletion
		Lootster_RaidFrameBossAttendFrameModify:Disable();
		Lootster_RaidFrameBossAttendFrameDelete:Disable();
	else
		-- enable attend modification and deletion
		Lootster_RaidFrameBossAttendFrameModify:Enable();
		Lootster_RaidFrameBossAttendFrameDelete:Enable();
	end

	if	(Lootster_AdjustId == nil) then
		-- disable adjust modification and deletion
		Lootster_RaidFrameBossAdjustFrameModify:Disable();
		Lootster_RaidFrameBossAdjustFrameDelete:Disable();
	else
		-- enable adjust modification and deletion
		Lootster_RaidFrameBossAdjustFrameModify:Enable();
		Lootster_RaidFrameBossAdjustFrameDelete:Enable();
	end

	if	(Lootster_AssignId == nil) then
		-- disable assign assignation, modification and deletion
		Lootster_RaidFrameBossAssignFrameAssign:Disable();
		Lootster_RaidFrameBossAssignFrameModify:Disable();
		Lootster_RaidFrameBossAssignFrameDelete:Disable();
	else
		-- enable assign assignation, modification and deletion
		Lootster_RaidFrameBossAssignFrameAssign:Enable();
		Lootster_RaidFrameBossAssignFrameModify:Enable();
		Lootster_RaidFrameBossAssignFrameDelete:Enable();
	end

	-- deteremine which way we are raid viewing
	if		(Lootster_ViewRaidType == LOOTSTER_ENUM_VIEWRAID.BYATTEND) then
		-- hide boss adjustment and assignment frames
		Lootster_RaidFrameBossAdjustFrame:Hide();
		Lootster_RaidFrameBossAssignFrame:Hide();

		-- show boss attendance frame
		Lootster_RaidFrameBossAttendFrame:Show();

		-- make sure the attend scroll window is updated
		Lootster_Raid_Attend_Update();
	elseif	(Lootster_ViewRaidType == LOOTSTER_ENUM_VIEWRAID.BYADJUST) then
		-- hide boss attendance and assignment frames
		Lootster_RaidFrameBossAttendFrame:Hide();
		Lootster_RaidFrameBossAssignFrame:Hide();

		-- show boss adjustment frame
		Lootster_RaidFrameBossAdjustFrame:Show();

		-- make sure the adjust scroll window is updated
		Lootster_Raid_Adjust_Update();
	elseif	(Lootster_ViewRaidType == LOOTSTER_ENUM_VIEWRAID.BYASSIGN) then
		-- hide boss adjustment and attendance frames
		Lootster_RaidFrameBossAttendFrame:Hide();
		Lootster_RaidFrameBossAdjustFrame:Hide();

		-- show boss assignment frame
		Lootster_RaidFrameBossAssignFrame:Show();

		-- make sure the assign scroll window is updated
		Lootster_Raid_Assign_Update();
	end
	
	-- update MiniMap buttons
	Lootster_MiniMapButton_SwitchState();
	
	-- update raid report UI
	Lootster_UpdateRaidReportUI();
end

--  Raid Synchronise Click handler
function Lootster_Raid_Sync_OnClick(self, button)
	-- show the raid sync dialog
	Lootster_Popup_Show(Lootster_RaidSyncFrame);
end

--  Full Report Click handler
function Lootster_Raid_ReportFull_OnClick(self, button)
	-- hook the report writer for the full report if a report format is selected
	if (Lootster_RepList[Lootster_Options.RepFormat] ~= nil) then
		Lootster_ReportWriterCB = Lootster_RepList[Lootster_Options.RepFormat].Callback;
		Lootster_ReportWriterArgs = Lootster_RepList[Lootster_Options.RepFormat].Args;
		Lootster_ReportWriterMask = bit.bor(LOOTSTER_MASK_REPORTTYPE.FULL, bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.MASKOUT));
	end
	
	-- and show the report
	Lootster_Popup_Show(Lootster_RaidFrameReportFrame);
end

--  Raid Report Click handler
function Lootster_Raid_ReportRaid_OnClick(self, button)
	-- hook the report writer for the raid report if a report format is selected
	if (Lootster_RepList[Lootster_Options.RepFormat] ~= nil) then
		Lootster_ReportWriterCB = Lootster_RepList[Lootster_Options.RepFormat].Callback;
		Lootster_ReportWriterArgs = Lootster_RepList[Lootster_Options.RepFormat].Args;
		Lootster_ReportWriterMask = bit.bor(LOOTSTER_MASK_REPORTTYPE.RAID, bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.MASKOUT));
	end
	
	-- and show the report
	Lootster_Popup_Show(Lootster_RaidFrameReportFrame);
end

--  Boss Report Click handler
function Lootster_Raid_ReportBoss_OnClick(self, button)
	-- hook the report writer for the boss report if a report format is selected
	if (Lootster_RepList[Lootster_Options.RepFormat] ~= nil) then
		Lootster_ReportWriterCB = Lootster_RepList[Lootster_Options.RepFormat].Callback;
		Lootster_ReportWriterArgs = Lootster_RepList[Lootster_Options.RepFormat].Args;
		Lootster_ReportWriterMask = bit.bor(LOOTSTER_MASK_REPORTTYPE.BOSS, bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.MASKOUT));
	end
	
	-- and show the report
	Lootster_Popup_Show(Lootster_RaidFrameReportFrame);
end

-- Raid Raid Row Click handler
function Lootster_Raid_Raid_Button_OnClick(self, button)
	local	offset, key;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameRaidFrameScrollFrame);

	-- calculate actual the raid item index and get the raid record key
	key = Lootster_RaidSort[self:GetID() + offset];

	-- if this is a different raid, snarf
	if (key ~= Lootster_RaidId) then
		-- snarf the new raid Id
		Lootster_RaidId = key;

		-- reset the current boss Id
		Lootster_BossId = nil;

		-- reset the current attend Id
		Lootster_AttendId = nil;

		-- reset the current adjust id
		Lootster_AdjustId = nil;

		-- reset the current assign id
		Lootster_AssignId = nil;

		-- resort raid raid using current sort
		Lootster_Raid_Raid_Sort(nil);

		-- resort raid boss using current sort
		Lootster_Raid_Boss_Sort(nil);

		-- resort raid attend using current sort
		Lootster_Raid_Attend_Sort(nil);

		-- resort raid adjust using current sort
		Lootster_Raid_Adjust_Sort(nil);

		-- resort raid assign using current sort
		Lootster_Raid_Assign_Sort(nil);

		-- update the raid UI
		Lootster_UpdateRaidUI();
	end
end

-- Raid Raid Row Double Click handler
function Lootster_Raid_Raid_Button_OnDoubleClick(self, button)
	local	offset, key;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameRaidFrameScrollFrame);

	-- calculate actual the raid item index and get the raid record key
	key = Lootster_RaidSort[self:GetID() + offset];

	-- determine if running a different raid
	if (key ~= Lootster_Running.RaidId) then
		-- start of raid
		Lootster_RunRaid(key);
	else
		-- end of raid
		Lootster_RunRaid(nil);
	end
	
	-- end of boss
	Lootster_RunBoss(nil);
	
	-- see if instance information updated
	Lootster_CheckInstanceInfo();
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Raid Row Enter handler
function Lootster_Raid_Raid_Button_OnEnter(self)
	local	offset, key, tooltip;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameRaidFrameScrollFrame);

	-- calculate actual the raid item index and get the raid record key
	key = Lootster_RaidSort[self:GetID() + offset];
	
	-- format raid zone and type
	tooltip = string.format(LOOTSTER_MSG_RAIDTOOLTIP, Lootster_Raid[key].Zone, LOOTSTER_RAIDTYPE_LIST[Lootster_Raid[key].Type]);
	
	return tooltip;
end

-- Raid Create Raid handler
function Lootster_Raid_Raid_Create_OnClick(self, button)
	local	_, zone, type, wowId, dateExp;

	-- get the zone name (instance name if appropriate)
	_, zone, type = Lootster_HasRaidZoneChanged();

	-- no zone use default
	if (zone == nil) then
		zone = LOOTSTER_RAIDRAID_ZONEUNKNOWN
	end

	-- ignore WoW instance Id if this is an ordinary instance
	if ((type ~= LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) and (type ~= LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM)) then	
		-- determine the WoW instance id and instance reset date
		wowId, dateExp = Lootster_GetInstanceId(zone, type);
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- instantiate a new raid record
	Lootster_RaidRec = Lootster_NewRaid(zone, type, wowId, Lootster_CalcServerTime(time()), dateExp);

	-- and show the raid dialog
	Lootster_Popup_Show(Lootster_RaidFrameRaidFrame);
end

-- Raid Modify Raid handler
function Lootster_Raid_Raid_Modify_OnClick(self, button)
	-- make sure we have a raid selected
	if (Lootster_RaidId == nil) then
		return;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- copy the raid record
	Lootster_RaidRec = Lootster_CopyRecord(Lootster_Raid[Lootster_RaidId]);

	-- and show the raid dialog
	Lootster_Popup_Show(Lootster_RaidFrameRaidFrame);
end

-- Raid Delete Raid Click handler
function Lootster_Raid_Raid_Delete_OnClick(self, button)
	-- make sure we have a raid selected
	if (Lootster_RaidId == nil) then
		return;
	end

	-- copy the raid record
	Lootster_RaidRec = Lootster_CopyRecord(Lootster_Raid[Lootster_RaidId]);

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_RAID_DELETE");
end

-- Raid Delete Raid Accept handler
function Lootster_Raid_Raid_Delete_OnAccept()
	-- no raid record we are done
	if (Lootster_RaidRec == nil) then
		return;
	end

	-- delete this raid record
	Lootster_DeleteRaid(Lootster_RaidRec.Id);

	-- if this was the running raid, reset
	if (Lootster_RaidId == Lootster_Running.RaidId) then
		-- no running raid
		Lootster_RunRaid(nil);

		-- no running boss
		Lootster_RunBoss(nil);
	end

	-- get the next raid id
	Lootster_RaidId = Lootster_GetNextId(Lootster_RaidSort, Lootster_RaidRec.Id);

	-- reset the current boss Id
	Lootster_BossId = nil;
	
	-- reset the current attend Id
	Lootster_AttendId = nil;
	
	-- reset the current adjust id
	Lootster_AdjustId = nil;

	-- reset the current assign id
	Lootster_AssignId = nil;

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset raid record
	Lootster_RaidRec = nil;

	-- could our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete Raid Cancel handler
function Lootster_Raid_Raid_Delete_OnCancel()
	-- reset raid record
	Lootster_RaidRec = nil;
end

-- Raid Delete ALL Raid handler
function Lootster_Raid_Raid_DeleteAll_OnClick(self, button)
	-- make sure we have some raids
	if (#Lootster_RaidSort == 0) then
		return;
	end

	-- and show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_RAID_DELETEALL");
end

-- Raid Delete ALL Raid Accept handler
function Lootster_Raid_Raid_DeleteAll_OnAccept()
	-- delete all raids
	Lootster_DeleteAllRaid();

	-- reload data
	Lootster_LoadData();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- could our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete All Raid Cancel handler
function Lootster_Raid_Raid_DeleteAll_OnCancel()
end

-- Show Raid handler
function Lootster_Raid_Raid_OnShow(self)
	local	opCode;
	
	-- no raid record means we are done
	if (Lootster_RaidRec == nil) then
		-- rehide frame
		Lootster_RaidFrameRaidFrame:Hide();
	else
		-- set prompts for player depending on operation
		if (Lootster_RaidRec.Id == nil) then
			opCode = LOOTSTER_RAID_INSERT;
		else
			opCode = LOOTSTER_RAID_MODIFY;
		end

		-- format and set raid operation
		Lootster_RaidFrameRaidFrameText:SetFormattedText(LOOTSTER_RAIDRAID_TITLE, opCode);
		Lootster_RaidFrameRaidFrameApply:SetFormattedText(LOOTSTER_RAIDRAID_APPLY, opCode);

		-- raid zone
		Lootster_RaidFrameRaidFrameZone:SetText(Lootster_RaidRec.Zone);

		-- is this the running guy?
		if ((Lootster_RaidRec.Id == nil) or (Lootster_RaidRec.Id == Lootster_Running.RaidId)) then
			-- this is or will be the running raid
			Lootster_RaidFrameRaidFrameRunning:SetChecked(true);
		else
			-- not to be running raid
			Lootster_RaidFrameRaidFrameRunning:SetChecked(false);
		end
		
		-- see if instance information updated
		Lootster_CheckInstanceInfo(Lootster_RaidRec);

		-- WoW instance id
		Lootster_RaidFrameRaidFrameWoWId:SetText(Lootster_RaidRec.WoWId);

		-- begin and reset dates
		Lootster_SetDateTime(Lootster_RaidFrameRaidFrameDateOpn, Lootster_RaidRec.DateOpn, Lootster_Raid_Raid_DateOpn_Entered);
		Lootster_SetDateTime(Lootster_RaidFrameRaidFrameDateExp, Lootster_RaidRec.DateExp);

		-- update comment
		Lootster_RaidFrameRaidFrameCommentText:SetText(Lootster_RaidRec.Comment);

		-- update raid raid UI
		Lootster_UpdateRaidRaidUI();
	end
end

-- Hide Raid handler
function Lootster_Raid_Raid_OnHide(self)
	-- default operation code
	Lootster_RaidFrameRaidFrameText:SetText(LOOTSTER_RAIDRAID_TITLE);
	Lootster_RaidFrameRaidFrameApply:SetText(LOOTSTER_RAIDRAID_APPLY);

	-- no raid zone
	Lootster_RaidFrameRaidFrameZone:SetText("");
	
	-- reset running raid
	Lootster_RaidFrameRaidFrameRunning:SetChecked(false);

	-- no WoW instance id
	Lootster_RaidFrameRaidFrameWoWId:SetText("");

	-- no begin or reset dates
	Lootster_SetDateTime(Lootster_RaidFrameRaidFrameDateOpn, nil, Lootster_Raid_Raid_DateOpn_Entered);
	Lootster_SetDateTime(Lootster_RaidFrameRaidFrameDateExp, nil);

	-- reset raid comment
	Lootster_RaidFrameRaidFrameCommentText:SetText("\n");

	-- smoke raid record
	Lootster_RaidRec = nil;
end

-- Raid Raid Zone Entered handler
function Lootster_Raid_Raid_Zone_OnTextChanged(self)
	-- update raid raid UI
	Lootster_UpdateRaidRaidUI();
end

-- Raid Raid Use Here handler
function Lootster_Raid_Raid_UseHere_OnClick(self, button)
	-- make raid the current zone
	Lootster_RaidFrameRaidFrameZone:SetText(GetRealZoneText());

	-- update raid raid UI
	Lootster_UpdateRaidRaidUI();
end

-- Raid Raid Running handler
function Lootster_Raid_Raid_Running_OnToggle(self)
end

-- Raid Raid Type Load handler
function Lootster_Raid_Raid_Type_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 130);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Raid Type Show handler
function Lootster_Raid_Raid_Type_OnShow(self)
	-- no raid record  we are done
	if (Lootster_RaidRec == nil) then
		return;
	end
	
	-- setup the raid raid type drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameRaidFrameType, Lootster_Raid_Raid_Type_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameRaidFrameType, Lootster_RaidRec.Type);
end

-- Raid Raid Type Load Initaliser handler
function Lootster_Raid_Raid_Type_Initialise()
	local	ix, entry, info;

	for ix, entry in ipairs(LOOTSTER_RAIDTYPE_LIST) do
		-- form mode button
		info = {};
		info.text = entry;
		info.func = Lootster_Raid_Raid_Type_OnSelect;
		info.value = ix;

		-- add raid sort button
		UIDropDownMenu_AddButton(info);
	end
end

-- Raid Raid Type Select handler
function Lootster_Raid_Raid_Type_OnSelect(self)
	-- no raid record  we are done
	if (Lootster_RaidRec == nil) then
		return;
	end
	
	-- snarf new raid type column
	Lootster_RaidRec.Type = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameRaidFrameType, self.value);
end

-- Raid Raid Date Open Entered handler
function Lootster_Raid_Raid_DateOpn_OnTextChanged(self)
	-- update raid raid UI
	Lootster_UpdateRaidRaidUI();
end

-- Raid Raid Comment Entered handler
function Lootster_Raid_Raid_Comment_OnTextChanged(self)
end

-- Raid Raid Apply handler
function Lootster_Raid_Apply_OnClick(self, button)
	local raidId;

	-- no raid record we are done
	if (Lootster_RaidRec == nil) then
		return;
	end

	-- retrieve data
	Lootster_RaidRec.Zone = Lootster_RaidFrameRaidFrameZone:GetText();
	Lootster_RaidRec.DateOpn = Lootster_GetDateTime(Lootster_RaidFrameRaidFrameDateOpn);
	Lootster_RaidRec.Comment = Lootster_AppendTrailingLineBreak(Lootster_RaidFrameRaidFrameCommentText:GetText());

	-- are we creating or modifying a raid record?
	if (Lootster_RaidRec.Id == nil) then
		-- create raid
		raidId = Lootster_CreateRaid(Lootster_RaidRec);
	else
		-- modify the raid
		Lootster_ModifyRaid(Lootster_RaidRec);
	end

	-- retrieve raid Id as necessary
	if (raidId == nil) then
		-- retrieve raid Id
		raidId = Lootster_RaidRec.Id;
	end
	
	-- are we making this the running raid?
	if (Lootster_RaidFrameRaidFrameRunning:GetChecked() ~= nil) then
		-- did the running raid change?
		if		(Lootster_Running.RaidId == raidId) then
			-- remake this guy the running raid to activate possible events
			Lootster_RunRaid(raidId);
		else
			-- make this guy the running raid
			Lootster_RunRaid(raidId);
			
			-- reset running boss
			Lootster_RunBoss(nil);
		end
	else
		-- are we reseting the running raid?
		if (Lootster_Running.RaidId == raidId) then
			-- reset the currently running raid
			Lootster_RunRaid(nil);

			-- reset the currently running boss
			Lootster_RunBoss(nil);
		end
	end		

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset raid record
	Lootster_RaidRec = nil;

	-- hide the UI
	Lootster_RaidFrameRaidFrame:Hide();

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Raid Cancel handler
function Lootster_Raid_Cancel_OnClick(self, button)
	-- smoke raid record
	Lootster_RaidRec = nil;
end

-- Raid Raid Update UI handler
function Lootster_UpdateRaidRaidUI()
	local	dateOpnP, dateOpnT, dateOpnF;
	
	-- determine if open date fully entered
	dateOpnP, dateOpnT, dateOpnF = Lootster_IsDateTimePartial(Lootster_RaidFrameRaidFrameDateOpn);
	
	-- enable raid button if zone entered and open date fully entered
	if ((Lootster_RaidFrameRaidFrameZone:GetText() == "") and (dateOpnT ~= true)) then
		Lootster_RaidFrameRaidFrameApply:Disable();
	else
		Lootster_RaidFrameRaidFrameApply:Enable();
	end
end

-- Raid Boss Row Click handler
function Lootster_Raid_Boss_Button_OnClick(self, button, key)
	local	offset;

	-- if no key passed, retrieve
	if (key == nil) then
		-- retrieve the scroll offset
		offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);

		-- calculate actual the boss item index and get the boss record key
		key = Lootster_BossSort[self:GetID() + offset];
	end

	-- update the key
	Lootster_BossId = key;

	-- reset attend, adjust and assignId
	Lootster_AttendId = nil;
	Lootster_AdjustId = nil;
	Lootster_AssignId = nil;

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- depending on what was the current item before, sort attendance/adjustment
	if		(Lootster_ViewRaidType == LOOTSTER_ENUM_VIEWRAID.BYATTEND) then
		-- resort raid attend using current sort
		Lootster_Raid_Attend_Sort(nil);
	elseif	(Lootster_ViewRaidType == LOOTSTER_ENUM_VIEWRAID.BYADJUST) then
		-- resort raid adjust using current sort
		Lootster_Raid_Adjust_Sort(nil);
	elseif	(Lootster_ViewRaidType == LOOTSTER_ENUM_VIEWRAID.BYASSIGN) then
		-- resort raid assign using current sort
		Lootster_Raid_Assign_Sort(nil);
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Boss Row Double Click handler
function Lootster_Raid_Boss_Button_OnDoubleClick(self, button)
	local	offset, key;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);

	-- calculate actual the boss item index and get the boss record key
	key = Lootster_BossSort[self:GetID() + offset];

	-- did the running boss change?
	if (key ~= Lootster_Running.BossId) then
		-- make sure we have the correct running raid
		Lootster_RunRaid(Lootster_Boss[key].RaidId);

		-- however, boss must be a boss attempt, kill or wipe
		if ((Lootster_Boss[key] ~= nil) and (LOOTSTER_BOSSTYPE_BOSS[Lootster_Boss[key].Type] ~= nil)) then
			-- start of a real boss
			Lootster_RunBoss(key);
		end
	else
		-- end of boss
		Lootster_RunBoss(nil);
	end

	-- see if instance information updated
	Lootster_CheckInstanceInfo();
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Boss Row Enter handler
function Lootster_Raid_Boss_Button_OnEnter(self)
	local	offset, key, tooltip;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);

	-- calculate actual the boss item index and get the boss record key
	key = Lootster_BossSort[self:GetID() + offset];
	
	-- boss types can be run
	if (LOOTSTER_BOSSTYPE_BOSS[Lootster_Boss[key].Type] ~= nil) then
		-- format boss name and type and the fact they can double click
		tooltip = string.format(LOOTSTER_MSG_BOSSTOOLTIPDC, Lootster_FormatBoss(Lootster_Boss[key].Boss, Lootster_Boss[key].Attempt), LOOTSTER_BOSSTYPE_LIST[Lootster_Boss[key].Type]);
	else
		-- format boss name and type
		tooltip = string.format(LOOTSTER_MSG_BOSSTOOLTIPNDC, Lootster_FormatBoss(Lootster_Boss[key].Boss, Lootster_Boss[key].Attempt), LOOTSTER_BOSSTYPE_LIST[Lootster_Boss[key].Type]);
	end
	
	return tooltip;
end

-- Raid Boss Attend Click handler
function Lootster_Raid_Boss_Attend_OnClick(self, button)
	local	offset;

	-- first, flip raid view mode to attendance
	Lootster_ViewRaidType = LOOTSTER_ENUM_VIEWRAID.BYATTEND;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);

	-- and set the current boss to the one pressed
	Lootster_Raid_Boss_Button_OnClick(Lootster_RaidFrameBossFrameButton1, button, Lootster_BossSort[self:GetParent():GetID() + offset]);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Boss Adjust Click handler
function Lootster_Raid_Boss_Adjust_OnClick(self, button)
	local	offset;

	-- first, flip raid view mode to adjustment
	Lootster_ViewRaidType = LOOTSTER_ENUM_VIEWRAID.BYADJUST;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);
	
	-- and set the current boss to the one pressed
	Lootster_Raid_Boss_Button_OnClick(Lootster_RaidFrameBossFrameButton1, button, Lootster_BossSort[self:GetParent():GetID() + offset]);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Boss Assign Click handler
function Lootster_Raid_Boss_Assign_OnClick(self, button)
	local	offset;

	-- first, flip raid view mode to assignment
	Lootster_ViewRaidType = LOOTSTER_ENUM_VIEWRAID.BYASSIGN;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);
	
	-- and set the current boss to the one pressed
	Lootster_Raid_Boss_Button_OnClick(Lootster_RaidFrameBossFrameButton1, button, Lootster_BossSort[self:GetParent():GetID() + offset]);
	
	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Create Boss handler
function Lootster_Raid_Boss_Create_OnClick(self, button)
	local	boss, killSet, bossId, name, tbd, attempt;

	-- no raid we are done
	if (Lootster_RaidId == nil) then
		return;
	end

	-- get the boss name
	boss, killSet, dead = Lootster_GetRaidBoss();
	
	-- not a real boss then we need to fake one
	if ((boss == nil) or (dead == true)) then
		-- use To Be Determined boss initially
		boss = LOOTSTER_RAIDBOSS_TBD;
		tbd = true;
	else
		tbd = false;
	end

	-- is there another entry for this boss?
	bossId = Lootster_GetMatchingBoss(Lootster_RaidId, boss);
	
	-- determine attempt number
	if (bossId ~= nil) then
		-- bump attempt
		attempt = Lootster_Boss[bossId].Attempt + 1;
	else
		attempt = 1;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- instantiate a new boss record
	Lootster_BossRec = Lootster_NewBoss(boss, Lootster_CalcServerTime(time()), tbd, attempt, nil, kill);

	-- and show the boss dialog
	Lootster_Popup_Show(Lootster_RaidFrameBossFrame);
end

-- Raid Modify Boss handler
function Lootster_Raid_Boss_Modify_OnClick(self, button)
	-- make sure we have a boss selected
	if (Lootster_BossId == nil) then
		return;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- copy the boss record
	Lootster_BossRec = Lootster_CopyRecord(Lootster_Boss[Lootster_BossId]);

	-- and show the boss dialog
	Lootster_Popup_Show(Lootster_RaidFrameBossFrame);
end

-- Raid Delete Boss Click handler
function Lootster_Raid_Boss_Delete_OnClick(self, button)
	-- make sure we have a boss selected
	if (Lootster_BossId == nil) then
		return;
	end

	-- copy the boss record
	Lootster_BossRec = Lootster_CopyRecord(Lootster_Boss[Lootster_BossId]);

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_BOSS_DELETE");
end

-- Raid Delete Boss Accept handler
function Lootster_Raid_Boss_Delete_OnAccept()
	-- no boss record we are done
	if (Lootster_BossRec == nil) then
		return;
	end

	-- delete this boss record
	Lootster_DeleteBoss(Lootster_BossRec.Id);

	-- if this was the running boss, reset
	if (Lootster_BossId == Lootster_Running.BossId) then
		-- no running boss
		Lootster_RunBoss(nil);
	end

	-- get the next boss id
	Lootster_BossId = Lootster_GetNextId(Lootster_BossSort, Lootster_BossRec.Id);

	-- reset the current attend Id
	Lootster_AttendId = nil;
	
	-- reset the current adjust id
	Lootster_AdjustId = nil;

	-- reset the current assign id
	Lootster_AssignId = nil;

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset boss record
	Lootster_BossRec = nil;

	-- could our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete Boss Cancel handler
function Lootster_Raid_Boss_Delete_OnCancel()
	-- reset boss record
	Lootster_BossRec = nil;
end

-- Raid Delete ALL Boss handler
function Lootster_Raid_Boss_DeleteAll_OnClick(self, button)
	-- make sure we have some bosses
	if ((Lootster_RaidId == nil) or (#Lootster_BossSort == 0)) then
		return;
	end

	-- copy the first boss record so we retain the selected raid id if they switch raids on us
	Lootster_BossRec = Lootster_CopyRecord(Lootster_Boss[Lootster_BossSort[1]]);

	-- and show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_BOSS_DELETEALL");
end

-- Raid Delete ALL Boss handler
function Lootster_Raid_Boss_DeleteAll_OnAccept()
	-- no boss record we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- delete all bosss
	Lootster_DeleteAllBoss(Lootster_BossRec.RaidId);

	-- reset the current boss Id
	Lootster_BossId = nil;
	
	-- reset the current attend Id
	Lootster_AttendId = nil;
	
	-- reset the current adjust id
	Lootster_AdjustId = nil;

	-- reset the current assign id
	Lootster_AssignId = nil;

	-- no running boss
	Lootster_RunBoss(nil);

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- reset boss record
	Lootster_BossRec = nil;

	-- could our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete ALL Boss Cancel handler
function Lootster_Raid_Boss_DeleteAll_OnCancel()
	-- reset boss record
	Lootster_BossRec = nil;
end

-- Show Boss handler
function Lootster_Raid_Boss_OnShow(self)
	local	opCode, dkp, partial, standby;

	-- no boss record means we are done
	if (Lootster_BossRec == nil) then
		-- rehide frame
		Lootster_RaidFrameBossFrame:Hide();
	else
		-- set prompts for player depending on operation
		if (Lootster_BossRec.Id == nil) then
			opCode = LOOTSTER_RAID_INSERT;
		else
			opCode = LOOTSTER_RAID_MODIFY;
		end

		-- format and set boss operation
		Lootster_RaidFrameBossFrameText:SetFormattedText(LOOTSTER_RAIDBOSS_TITLE, opCode);
		Lootster_RaidFrameBossFrameApply:SetFormattedText(LOOTSTER_RAIDBOSS_APPLY, opCode);

		-- boss and attempt
		Lootster_RaidFrameBossFrameBoss:SetText(Lootster_BossRec.Boss);
		Lootster_RaidFrameBossFrameAttempt:SetNumber(Lootster_BossRec.Attempt);

		-- is this the running guy?
		if ((Lootster_BossRec.Id == nil) or (Lootster_BossRec.Id == Lootster_Running.BossId)) then
			-- this is or will be the running boss
			Lootster_RaidFrameBossFrameRunning:SetChecked(true);
		else
			-- not to be running boss
			Lootster_RaidFrameBossFrameRunning:SetChecked(false);
		end

		-- using DKP?
		if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
			-- manage the bonus award event DKP 
			if		((opCode == LOOTSTER_RAID_INSERT) or (Lootster_BossRec.Type ~= LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD)) then
				-- get the raid type's event DKP
				dkp, partial, standby = Lootster_GetEventDKP(Lootster_Raid[Lootster_RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSAWARD);

				-- prime DKP values
				Lootster_RaidFrameBossFrameDKPFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, dkp));
				Lootster_RaidFrameBossFrameDKPFramePartial:SetNumber(partial);
				Lootster_RaidFrameBossFrameDKPFrameStandby:SetNumber(standby);				
			elseif	((opCode == LOOTSTER_RAID_MODIFY) and (Lootster_BossRec.Type == LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD)) then
				-- use the current values
				Lootster_RaidFrameBossFrameDKPFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_BossRec.DKP));
				Lootster_RaidFrameBossFrameDKPFramePartial:SetNumber(Lootster_BossRec.Partial);
				Lootster_RaidFrameBossFrameDKPFrameStandby:SetNumber(Lootster_BossRec.Standby);
			end
			
			-- manage the bonus time event DKP
			if	(Lootster_BossRec.Type == LOOTSTER_ENUM_BOSSTYPE.BONUSTIME) then
				-- set the saved bonus time DKP values depending on their presence
				if ((Lootster_BossRec.DKP == nil) or (Lootster_BossRec.Partial == nil) or (Lootster_BossRec.Standby == nil)) then
					-- use the placeholders
					Lootster_RaidFrameBossFrameDKPFrameDKPRO:SetText("-");
					Lootster_RaidFrameBossFrameDKPFramePartialRO:SetText("-");
					Lootster_RaidFrameBossFrameDKPFrameStandbyRO:SetText("-");
				else
					-- use the current values
					Lootster_RaidFrameBossFrameDKPFrameDKPRO:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_BossRec.DKP));
					Lootster_RaidFrameBossFrameDKPFramePartialRO:SetText(Lootster_BossRec.Partial);
					Lootster_RaidFrameBossFrameDKPFrameStandbyRO:SetText(Lootster_BossRec.Standby);
				end
			end
		end

		-- begin and end dates
		Lootster_SetDateTime(Lootster_RaidFrameBossFrameDateBeg, Lootster_BossRec.DateBeg, Lootster_Raid_Boss_DateBeg_Entered);
		Lootster_SetDateTime(Lootster_RaidFrameBossFrameDateEnd, Lootster_BossRec.DateEnd, Lootster_Raid_Boss_DateEnd_Entered);

		-- update raid boss UI
		Lootster_UpdateRaidBossUI();
	end
end

-- Hide Boss handler
function Lootster_Raid_Boss_OnHide(self)
	-- default operation code
	Lootster_RaidFrameBossFrameText:SetText(LOOTSTER_RAIDBOSS_TITLE);
	Lootster_RaidFrameBossFrameApply:SetText(LOOTSTER_RAIDBOSS_APPLY);

	-- no boss
	Lootster_RaidFrameBossFrameBoss:SetText("");
	Lootster_RaidFrameBossFrameAttempt:SetNumber(1);
	
	-- reset running boss
	Lootster_RaidFrameBossFrameRunning:SetChecked(false);
	
	-- no begin or end dates
	Lootster_SetDateTime(Lootster_RaidFrameBossFrameDateBeg, nil, Lootster_Raid_Boss_DateBeg_Entered);
	Lootster_SetDateTime(Lootster_RaidFrameBossFrameDateEnd, nil, Lootster_Raid_Boss_DateEnd_Entered);

	-- no DKP values
	Lootster_RaidFrameBossFrameDKPFrameDKP:SetNumber(0);
	Lootster_RaidFrameBossFrameDKPFramePartial:SetNumber(0);
	Lootster_RaidFrameBossFrameDKPFrameStandby:SetNumber(0);

	-- smoke boss record
	Lootster_BossRec = nil;
end

-- Raid Boss Boss Entered handler
function Lootster_Raid_Boss_Boss_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Attempt Entered handler
function Lootster_Raid_Boss_Attempt_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Make TBD handler
function Lootster_Raid_Boss_MakeTBD_OnClick(self, button)
	-- make the boss TBD
	Lootster_RaidFrameBossFrameBoss:SetText(LOOTSTER_RAIDBOSS_TBD);

	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Use Target handler
function Lootster_Raid_Boss_UseTarget_OnClick(self, button)
	-- have we a target and it is an enemy?
	if ((UnitExists("target") == nil) or (UnitIsEnemy("target", "player") == nil)) then
		return;
	end

	-- make the target the boss
	Lootster_RaidFrameBossFrameBoss:SetText(UnitName("target"));

	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Running handler
function Lootster_Raid_Boss_Running_OnToggle(self)
end

-- Raid Boss Type Load handler
function Lootster_Raid_Boss_Type_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 130);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Boss Type Show handler
function Lootster_Raid_Boss_Type_OnShow(self)
	-- no boss record  we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- setup the raid boss type drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameBossFrameType, Lootster_Raid_Boss_Type_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameBossFrameType, Lootster_BossRec.Type);
end

-- Raid Boss Type Load Initaliser handler
function Lootster_Raid_Boss_Type_Initialise()
	local	ix, entry, info;

	for ix, entry in ipairs(LOOTSTER_BOSSTYPE_LIST) do
		-- form mode button
		info = {};
		info.text = entry;
		info.func = Lootster_Raid_Boss_Type_OnSelect;
		info.value = ix;

		-- add raid sort button
		UIDropDownMenu_AddButton(info);
	end
end

-- Raid Boss Type Select handler
function Lootster_Raid_Boss_Type_OnSelect(self)
	local	raidId;
	
	-- no boss record  we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- snarf new boss type column
	Lootster_BossRec.Type = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameBossFrameType, self.value);
	
	-- use boss record raid if present
	if (Lootster_BossRec.RaidId ~= nil) then
		-- use this raid id
		raidId = Lootster_BossRec.RaidId;
	else
		-- use selected raid
		raidId = Lootster_RaidId;
	end

	-- recalculate the boss attempt number for this boss or boss type
	if (LOOTSTER_BOSSTYPE_BOSS[Lootster_BossRec.Type] == true) then
		-- use boss name
		bossId = Lootster_GetMatchingBoss(raidId, Lootster_RaidFrameBossFrameBoss:GetText());
	else
		-- use boss type
		bossId = Lootster_GetMatchingBoss(raidId, nil, Lootster_BossRec.Type);
	end
	
	-- determine attempt number
	if (bossId == nil) then
		Lootster_BossRec.Attempt = 1;
	else
		-- bump last attempt number
		Lootster_BossRec.Attempt = Lootster_Boss[bossId].Attempt + 1;
	end

	-- and update attempt number
	Lootster_RaidFrameBossFrameAttempt:SetNumber(Lootster_BossRec.Attempt);

	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss DKP Focus Gained handler
function Lootster_Raid_Boss_DKP_OnFocusGained(self)
	-- no boss selected means we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- select the current text
	self:HighlightText();
end

-- Raid Boss DKP Entered handler
function Lootster_Raid_Boss_DKP_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss DKP Focus Lost handler
function Lootster_Raid_Boss_DKP_OnFocusLost(self)
	local	dkp;
	
	-- no boss selected means we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- retrive boss DKP
	dkp = Lootster_RaidFrameBossFrameDKPFrameDKP:GetNumber();
	
	-- update
	Lootster_RaidFrameBossFrameDKPFrameDKP:SetNumber(dkp);
	
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Partial Focus Gained handler
function Lootster_Raid_Boss_Partial_OnFocusGained(self)
	-- no boss selected means we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- select the current text
	self:HighlightText();
end

-- Raid Boss Partial Entered handler
function Lootster_Raid_Boss_Partial_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Partial Focus Lost handler
function Lootster_Raid_Boss_Partial_OnFocusLost(self)
	local	partial;
	
	-- no boss selected means we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- retrive boss Partial
	partial = Lootster_RaidFrameBossFrameDKPFramePartial:GetNumber();
	
	-- must be positive
	if (partial < 0) then
		-- negate value
		partial = -partial;
	end
	
	-- update
	Lootster_RaidFrameBossFrameDKPFramePartial:SetNumber(partial);
	
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Standby Focus Gained handler
function Lootster_Raid_Boss_Standby_OnFocusGained(self)
	-- no boss selected means we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- save the current value so we can detect changes
	Lootster_BossStandbySave = Lootster_BossRec.Standby;

	-- select the current text
	self:HighlightText();
end

-- Raid Boss Standby Entered handler
function Lootster_Raid_Boss_Standby_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Standby Focus Lost handler
function Lootster_Raid_Boss_Standby_OnFocusLost(self)
	local	standby;
	
	-- no boss selected means we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- retrive boss Standby
	standby = Lootster_RaidFrameBossFrameDKPFrameStandby:GetNumber();
	
	-- must be positive
	if (standby < 0) then
		-- negate value
		standby = -standby;
	end
	
	-- update
	Lootster_RaidFrameBossFrameDKPFrameStandby:SetNumber(standby);
	
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Date Begin Entered handler
function Lootster_Raid_Boss_DateBeg_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Date End Entered handler
function Lootster_Raid_Boss_DateEnd_OnTextChanged(self)
	-- update raid boss UI
	Lootster_UpdateRaidBossUI();
end

-- Raid Boss Apply handler
function Lootster_Boss_Apply_OnClick(self, button)
	local raidId, player, bossId, tbd;

	-- no boss record  we are done
	if (Lootster_BossRec == nil) then
		return;
	end
	
	-- use boss record raid if present
	if (Lootster_BossRec.RaidId ~= nil) then
		-- use this raid id
		raidId = Lootster_BossRec.RaidId;
	else
		-- use selected raid
		raidId = Lootster_RaidId;
	end

	-- no raid id we are done
	if (raidId == nil) then
		return;
	end
	
	-- retrieve data
	Lootster_BossRec.Boss = Lootster_RaidFrameBossFrameBoss:GetText();
	Lootster_BossRec.Attempt = Lootster_RaidFrameBossFrameAttempt:GetNumber();
	Lootster_BossRec.DateBeg = Lootster_GetDateTime(Lootster_RaidFrameBossFrameDateBeg);
	Lootster_BossRec.DateEnd = Lootster_GetDateTime(Lootster_RaidFrameBossFrameDateEnd);

	-- using DKP?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- this is a bonus award or bonus time?
		if		(Lootster_BossRec.Type == LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD) then
			-- retrieve bonus award DKP
			Lootster_BossRec.DKP = Lootster_RaidFrameBossFrameDKPFrameDKP:GetNumber();
			Lootster_BossRec.Partial = Lootster_RaidFrameBossFrameDKPFramePartial:GetNumber();
			Lootster_BossRec.Standby = Lootster_RaidFrameBossFrameDKPFrameStandby:GetNumber();
		elseif	(Lootster_BossRec.Type ~= LOOTSTER_ENUM_BOSSTYPE.BONUSTIME) then
			-- leave bonus time DKP intact, others reset
			Lootster_BossRec.DKP = nil;
			Lootster_BossRec.Partial = nil;
			Lootster_BossRec.Standby = nil;
		end
	end
	
	-- has the boss been set to TBD?
	Lootster_BossRec.TBD = Lootster_BossRec.Boss == LOOTSTER_RAIDBOSS_TBD;

	-- are we creating or modifying a boss record?
	if (Lootster_BossRec.Id == nil) then
		-- create the boss
		bossId = Lootster_CreateBoss(Lootster_BossRec);

		-- and insert boss into raid
		Lootster_InsertBoss(raidId, bossId);
	else
		-- modify the boss
		Lootster_ModifyBoss(Lootster_BossRec);
	end

	-- retrieve boss Id as necessary
	if (bossId == nil) then
		-- retrieve boss Id
		bossId = Lootster_BossRec.Id;
	end

	-- are we making this the running boss and this boss type is allowed to run?
	if ((LOOTSTER_BOSSTYPE_BOSS[Lootster_BossRec.Type] ~= nil) and (Lootster_RaidFrameBossFrameRunning:GetChecked() ~= nil)) then
		-- did the running boss change?
		if (Lootster_Running.BossId ~= bossId) then
			-- make sure we have the correct running raid
			Lootster_RunRaid(raidId);

			-- make this guy the running boss
			Lootster_RunBoss(bossId);
		end
	else
		-- are we reseting the running boss?
		if (Lootster_Running.BossId == bossId) then
			-- reset the currently running boss
			Lootster_RunBoss(nil);
		end
	end		

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset boss record
	Lootster_BossRec = nil;

	-- hide the UI
	Lootster_RaidFrameBossFrame:Hide();

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Boss Cancel handler
function Lootster_Boss_Cancel_OnClick(self, button)
	-- smoke boss record
	Lootster_BossRec = nil;
end

-- Raid Boss Update UI handler
function Lootster_UpdateRaidBossUI()
	local	dateBegP, dateBegT, dateBegF, dateEndP, dateEndT, dateEndF;

	-- have we a target and it is an enemy?
	if ((UnitExists("target") == nil) or (UnitIsEnemy("target", "player") == nil)) then
		Lootster_RaidFrameBossFrameUseTarget:Disable();
	else
		Lootster_RaidFrameBossFrameUseTarget:Enable();
	end
	
	-- see if we can run this type of boss
	if ((LOOTSTER_BOSSTYPE_BOSS[Lootster_BossRec.Type] ~= nil) and (Lootster_BossRec ~= nil)) then
		-- enable the running check box
		Lootster_RaidFrameBossFrameRunning:Enable();
	else
		-- enable the running check box
		Lootster_RaidFrameBossFrameRunning:Disable();
	end
	
	-- using DKP?
	if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_BossRec ~= nil)) then
		-- this a bonus award?
		if		(Lootster_BossRec.Type == LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD) then
			-- show the DKP frame, hide DKP read only frame
			Lootster_RaidFrameBossFrameDKPFrame:Show();
			Lootster_RaidFrameBossFrameDKPFrameRO:Hide();
		elseif	(Lootster_BossRec.Type == LOOTSTER_ENUM_BOSSTYPE.BONUSTIME) then
			-- hide the DKP frame, show DKP read only frame
			Lootster_RaidFrameBossFrameDKPFrame:Hide();
			Lootster_RaidFrameBossFrameDKPFrameRO:Show();
		else
			-- hide both DKP frame
			Lootster_RaidFrameBossFrameDKPFrame:Hide();
			Lootster_RaidFrameBossFrameDKPFrameRO:Hide();
		end
	end

	-- determine if begin and end date fully entered
	dateOpnP, dateOpnT, dateOpnF = Lootster_IsDateTimePartial(Lootster_RaidFrameBossFrameDateBeg);
	dateEndP, dateEndT, dateEndF = Lootster_IsDateTimePartial(Lootster_RaidFrameBossFrameDateEnd);

	-- enable boss button if boss entered, attempt, begin date is fully entered and end date is not partially entered
	if ((Lootster_RaidFrameBossFrameBoss:GetText() == "") or (Lootster_RaidFrameBossFrameAttempt:GetNumber() <= 0) or (dateOpnT ~= true) or (dateEndP == true)) then
		Lootster_RaidFrameBossFrameApply:Disable();
	else
		Lootster_RaidFrameBossFrameApply:Enable();
	end
end

-- Raid Attend Row Click handler
function Lootster_Raid_Attend_Button_OnClick(self, button)
	local	offset, key;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAttendFrameScrollFrame);

	-- calculate actual the attend item index and get the attend record key
	key = Lootster_BossAttendSort[self:GetID() + offset];

	-- if this is a different attend, snarf
	if (key ~= Lootster_AttendId) then
		-- snarf the new attendance Id
		Lootster_AttendId = key;

		-- resort raid attend using current sort
		Lootster_Raid_Attend_Sort(nil);

		-- update the raid UI
		Lootster_UpdateRaidUI();
	end
end

-- Raid Attend Row Enter handler
function Lootster_Raid_Attend_Button_OnEnter(self)
	local	offset, key, tooltip;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAttendFrameScrollFrame);

	-- calculate actual the attend item index and get the attend record key
	key = Lootster_BossAttendSort[self:GetID() + offset];
	
	-- format player and alt
	tooltip = string.format(LOOTSTER_MSG_ATTENDTOOLTIP, Lootster_Attend[key].Player, Lootster_Attend[key].Alt);
	
	return tooltip;
end

-- Raid Take Attendance handler
function Lootster_Raid_Attend_UseRoster_OnClick(self, button)
	-- no raid or boss id  we are done
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil)) then
		return;
	end

	-- do we have attendance so far?
	if (Lootster_Boss[Lootster_BossId].AttendN == 0) then
		-- take attendance, no missing (so all full raid)
		Lootster_TakeAttendance(Lootster_BossId, LOOTSTER_ENUM_ATTENDED.FULL);
	else
		-- take attendance, marking missing as partials
		Lootster_TakeAttendance(Lootster_BossId, LOOTSTER_ENUM_ATTENDED.PARTIAL);
	end
end

-- Raid Create Attend handler
function Lootster_Raid_Attend_Create_OnClick(self, button)
	-- no raid or boss id  we are done
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil)) then
		return;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- create an attendance record
	Lootster_AttendRec = Lootster_NewAttend(nil, nil, LOOTSTER_ENUM_ATTENDED.FULL, 0);

	-- and show the attend dialog
	Lootster_Popup_Show(Lootster_RaidFrameAttendFrame);
end

-- Raid Modify Attend handler
function Lootster_Raid_Attend_Modify_OnClick(self, button)
	-- make sure we have a attendance selected
	if (Lootster_AttendId == nil) then
		return;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- copy the attendance record
	Lootster_AttendRec = Lootster_CopyRecord(Lootster_Attend[Lootster_AttendId]);

	-- and show the attend dialog
	Lootster_Popup_Show(Lootster_RaidFrameAttendFrame);
end

-- Raid Delete Attend Click handler
function Lootster_Raid_Attend_Delete_OnClick(self, button)
	-- make sure we have a attendance selected
	if (Lootster_AttendId == nil) then
		return;
	end

	-- copy the attendance record
	Lootster_AttendRec = Lootster_CopyRecord(Lootster_Attend[Lootster_AttendId]);

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ATTEND_DELETE");
end

-- Raid Delete Attend Accept handler
function Lootster_Raid_Attend_Delete_OnAccept()
	-- no attendance record we are done
	if (Lootster_AttendRec == nil) then
		return;
	end

	-- delete this attendance record
	Lootster_DeleteAttend(Lootster_AttendRec.Id);
	
	-- get the next attend id
	Lootster_AttendId = Lootster_GetNextId(Lootster_BossAttendSort, Lootster_AttendRec.Id);

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- reset attend record
	Lootster_AttendRec = nil;

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete Attend Cancel handler
function Lootster_Raid_Attend_Delete_OnCancel()
	-- reset attend record
	Lootster_AttendRec = nil;
end

-- Raid Delete ALL Attend handler
function Lootster_Raid_Attend_DeleteAll_OnClick(self, button)
	-- make sure we have some attendances
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil) or (#Lootster_BossAttendSort == 0)) then
		return;
	end

	-- copy the first attendance record so we retain the selected boss id if they switch bosses on us
	Lootster_AttendRec = Lootster_CopyRecord(Lootster_Attend[Lootster_BossAttendSort[1]]);

	-- and show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ATTEND_DELETEALL");
end

-- Raid Delete ALL Attend handler
function Lootster_Raid_Attend_DeleteAll_OnAccept()
	-- no attendance record we are done
	if (Lootster_AttendRec == nil) then
		return;
	end
	
	-- delete all attendances from the boss
	Lootster_DeleteAllAttend(Lootster_AttendRec.BossId);

	-- smoke the current attend id
	Lootster_AttendId = nil;
	
	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);
	
	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- reset attend record
	Lootster_AttendRec = nil;

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete ALL Attend Cancel handler
function Lootster_Raid_Attend_DeleteAll_OnCancel()
	-- reset attend record
	Lootster_AttendRec = nil;
end

-- Raid Attend DKP handler
function Lootster_Raid_Attend_OnShow(self)
	local	opCode;

	-- no attendance record or boss means we are done
	if ((Lootster_AttendRec == nil) or ((Lootster_BossId == nil) and (Lootster_AttendRec.BossId == nil))) then
		-- rehide frame
		Lootster_RaidFrameAttendFrame:Hide();
	else
		-- set prompts for player depending on operation
		if (Lootster_AttendRec.Id == nil) then
			opCode = LOOTSTER_RAID_INSERT;
		else
			opCode = LOOTSTER_RAID_MODIFY;
		end

		-- format and set attendance operation
		Lootster_RaidFrameAttendFrameText:SetFormattedText(LOOTSTER_RAIDATTEND_TITLE, opCode);
		Lootster_RaidFrameAttendFrameApply:SetFormattedText(LOOTSTER_RAIDATTEND_APPLY, opCode);
	
		-- update attendance
		Lootster_Raid_Attend_Attended_RadioButton_OnClick(Lootster_RaidFrameAttendFrameAttendedFrame, "LeftButton", nil);
		
		-- are we using DKP rolling?
		if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
			-- earnt DKP
			Lootster_RaidFrameAttendFrameDKPFrameDKP:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_AttendRec.DKPAttEarnt);
			
			-- show the DKP frame
			Lootster_RaidFrameAttendFrameDKPFrame:Show();
		else
			-- hide the DKP frame
			Lootster_RaidFrameAttendFrameDKPFrame:Hide();
		end
	
		-- attendance date
		Lootster_SetDateTime(Lootster_RaidFrameAttendFrameDateAtt, Lootster_AttendRec.DateAtt);
	end
end

-- Hide Attend DKP handler
function Lootster_Raid_Attend_OnHide(self)
	-- default operation code
	Lootster_RaidFrameAttendFrameText:SetText(LOOTSTER_RAIDATTEND_TITLE);
	Lootster_RaidFrameAttendFrameApply:SetText(LOOTSTER_RAIDATTEND_APPLY);
	
	-- reset attendance
	Lootster_Raid_Attend_Attended_RadioButton_OnClick(Lootster_RaidFrameAttendFrameAttendedFrame, "LeftButton", nil);

	-- smoke attend record
	Lootster_AttendRec = nil;
end

-- Raid Attend Player Show handler
function Lootster_Raid_Attend_Player_OnShow(self)
	-- ignore if no attend record
	if (Lootster_AttendRec == nil) then
		return;
	end

	-- setup the player drop down
	UIDropDownMenu_Initialize(self, Lootster_Raid_Attend_Player_Initialise, "MENU");

	-- set width
	UIDropDownMenu_SetWidth(self, 160);

	-- and justify left
	Lootster_RaidFrameAttendFramePlayerDropDownText:SetJustifyH("LEFT");
end

-- Raid Attend Player Initaliser handler
function Lootster_Raid_Attend_Player_Initialise()
	-- ignore if no attend record
	if (Lootster_AttendRec == nil) then
		return;
	end

	-- build player dropdown for attendance
	Lootster_Build_Player_DropDown(LOOTSTER_RAIDATTEND_SELECT, Lootster_Raid_Attend_OnSelect, LOOTSTER_RAIDATTEND_OTHERPLAYER,
								   Lootster_Raid_Attend_OnPlayer);
	
	-- select the winner if we have one
	if (Lootster_AttendRec.Player ~= nil) then
		-- get the alt if he is present
		player = Lootster_GetMainAlt(Lootster_AttendRec.Player);

		-- he's a winner!
		UIDropDownMenu_SetText(Lootster_RaidFrameAttendFramePlayerDropDown, player);
		UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAttendFramePlayerDropDown, player);
	else
		-- no winner yet - reset
		UIDropDownMenu_SetText(Lootster_RaidFrameAttendFramePlayerDropDown, "");
		UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAttendFramePlayerDropDown, nil);
	end
	
	-- update raid attend UI
	Lootster_UpdateRaidAttendUI();
end

-- Raid Attend Player Select handler
function Lootster_Raid_Attend_OnSelect(self)
	-- ignore if no attend record
	if (Lootster_AttendRec == nil) then
		return;
	end
	
	-- retrieve the selected playa (could be an alt)
	Lootster_AttendRec.Alt = self.value;
	
	-- retrieve the selected playa main
	Lootster_AttendRec.Player = Lootster_GetAltMain(Lootster_AttendRec.Alt);

	-- and select him in the drop down
	UIDropDownMenu_SetText(Lootster_RaidFrameAttendFramePlayerDropDown, self.value);
	UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAttendFramePlayerDropDown, self.value);
	
	-- update raid attend UI
	Lootster_UpdateRaidAttendUI();

	-- close menus
	CloseDropDownMenus();
end

-- Raid Attend Enter Other Player handler
function Lootster_Raid_Attend_OnPlayer()
	-- ignore if no attend record
	if (Lootster_AttendRec == nil) then
		return;
	end

	-- show edit box for player name
	StaticPopup_Show("LOOTSTER_PROMPT_ATTEND_PLAYER");
end

-- Raid Attend Attendance handler
function Lootster_Raid_Attend_Attended_RadioButton_OnClick(self, button, index)
	-- ignore if no attend record
	if (Lootster_AttendRec == nil) then
		return;
	end

	-- do we have a attended value?
	if (index ~= nil) then
		-- snarf attended value
		Lootster_AttendRec.Attended = index;
		
		-- are we using DKP rolling?
		if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
			-- calculate the new attendance DKP
			Lootster_AttendRec.DKPAttEarnt = Lootster_CalcAttendDKP(Lootster_RaidId, Lootster_BossId, index);
		
			-- and update
			Lootster_RaidFrameAttendFrameDKPFrameDKP:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_AttendRec.DKPAttEarnt);
		end
	end

	-- determine the attendance button
	Lootster_RaidFrameAttendFrameAttendFull:SetChecked(Lootster_AttendRec.Attended == LOOTSTER_ENUM_ATTENDED.FULL);
	Lootster_RaidFrameAttendFrameAttendPartial:SetChecked(Lootster_AttendRec.Attended == LOOTSTER_ENUM_ATTENDED.PARTIAL);
	Lootster_RaidFrameAttendFrameAttendStandby:SetChecked(Lootster_AttendRec.Attended == LOOTSTER_ENUM_ATTENDED.STANDBY);
	Lootster_RaidFrameAttendFrameAttendNotAtAll:SetChecked(Lootster_AttendRec.Attended == LOOTSTER_ENUM_ATTENDED.NOTATALL);
	
	-- update raid attend UI
	Lootster_UpdateRaidAttendUI();
	
	-- play sound if selected
	if (index ~= nil) then
		PlaySound("igMainMenuOptionCheckBoxOn");
	end
end

-- Raid Attend Apply handler
function Lootster_Attend_Apply_OnClick(self, button)
	local bossId, player, attendId;
	
	-- no attend record or assignee we are done
	if ((Lootster_AttendRec == nil) or (Lootster_AttendRec.Player == nil)) then
		return;
	end
	
	-- use attend record boss if present
	if (Lootster_AttendRec.BossId ~= nil) then
		-- use this boss id
		bossId = Lootster_AttendRec.BossId;
	else
		-- use selected boss
		bossId = Lootster_BossId;
	end

	-- no boss id we are done
	if (bossId == nil) then
		return;
	end
	
	-- get the player
	player = Lootster_AttendRec.Alt;
	
	-- retrieve data
	if		(Lootster_RaidFrameAttendFrameAttendFull:GetChecked() ~= nil) then
		Lootster_AttendRec.Attended = LOOTSTER_ENUM_ATTENDED.FULL;
	elseif	(Lootster_RaidFrameAttendFrameAttendPartial:GetChecked() ~= nil) then
		Lootster_AttendRec.Attended = LOOTSTER_ENUM_ATTENDED.PARTIAL;
	elseif	(Lootster_RaidFrameAttendFrameAttendStandby:GetChecked() ~= nil) then
		Lootster_AttendRec.Attended = LOOTSTER_ENUM_ATTENDED.STANDBY;
	elseif	(Lootster_RaidFrameAttendFrameAttendNotAtAll:GetChecked() ~= nil) then
		Lootster_AttendRec.Attended = LOOTSTER_ENUM_ATTENDED.NOTATALL;
	else
		-- not set, so ignore
		return;		
	end
	
	-- are we creating or modifying an attendance record?
	if (Lootster_AttendRec.Id == nil) then
		-- insert attendance into the boss
		Lootster_InsertAttend(bossId, Lootster_CreateAttend(Lootster_AttendRec));
	else
		-- modify the attendance
		Lootster_ModifyAttend(Lootster_AttendRec);
	end

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- reset attend record
	Lootster_AttendRec = nil;
	
	-- hide the UI
	Lootster_RaidFrameAttendFrame:Hide();

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Attend Cancel handler
function Lootster_Attend_Cancel_OnClick(self, button)
	-- smoke attendance record
	Lootster_AttendRec = nil;
end

-- Raid Attend Update UI handler
function Lootster_UpdateRaidAttendUI()
	-- enable attend button if player and attendance selected
	if ((Lootster_AttendRec.Player == nil) or (Lootster_AttendRec.Attended == nil)) then
		Lootster_RaidFrameAttendFrameApply:Disable();
	else
		Lootster_RaidFrameAttendFrameApply:Enable();
	end

	-- are we using DKP rolling?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- earnt DKP
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			Lootster_RaidFrameAttendFrameDKPFrameLabel:SetText(LOOTSTER_RAIDATTEND_EPEARNT);
		else
			Lootster_RaidFrameAttendFrameDKPFrameLabel:SetText(LOOTSTER_RAIDATTEND_DKPEARNT);
		end
	end
end

-- Raid Adjust Row Click handler
function Lootster_Raid_Adjust_Button_OnClick(self, button)
	local	offset, key, itemLink;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAdjustFrameScrollFrame);

	-- calculate actual the adjust item index and get the adjust record key
	key = Lootster_BossAdjustSort[self:GetID() + offset];

	-- if this is a different adjustment, snarf
	if (key ~= Lootster_AdjustId) then
		-- snarf the new adjustment Id
		Lootster_AdjustId = key;

		-- resort raid adjust using current sort
		Lootster_Raid_Adjust_Sort(nil);

		-- update the raid UI
		Lootster_UpdateRaidUI();
	end

	-- pass link to tooltip click handler
	Lootster_ClickTooltip(Lootster_Adjust[key].Link, button);
end

-- Raid Adjust Row Enter handler
function Lootster_Raid_Adjust_Button_OnEnter(self)
	local	offset, key, tooltip;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAdjustFrameScrollFrame);

	-- get actual the adjustment item key and get the adjustment record index
	key = Lootster_BossAdjustSort[self:GetID() + offset];
	
	-- format player and alt
	tooltip = string.format(LOOTSTER_MSG_ADJUSTTOOLTIP, Lootster_Adjust[key].Player, Lootster_Adjust[key].Alt, LOOTSTER_USAGEDKP_LIST[Lootster_Adjust[key].Usage]);
	
	return tooltip;
end

-- Raid Create Adjust handler
function Lootster_Raid_Adjust_Create_OnClick(self, button)
	local	dkp, reason, comment;

	-- no raid or boss id  we are done
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil)) then
		return;
	end

	-- set default DKP value and reason
	dkp = 0;
	reason = "";
	comment = ""
	
	-- do we have a loot link?
	if (Lootster_ItemLink ~= nil) then
		-- determine dkp and reason for this link
		dkp, reason = Lootster_GetItemDKP(Lootster_ItemText, Lootster_ItemLink);
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- create an adjustment record
	Lootster_AdjustRec = Lootster_NewAdjust(nil, nil, Lootster_CalcServerTime(time()), 0, dkp, LOOTSTER_ENUM_USAGE.MAINNEED, Lootster_ItemLink,
											reason, comment);

	-- and show the adjust dialog
	Lootster_Popup_Show(Lootster_RaidFrameAdjustFrame);
end

-- Raid Modify Adjust handler
function Lootster_Raid_Adjust_Modify_OnClick(self, button)
	-- make sure we have a adjustment selected
	if (Lootster_AdjustId == nil) then
		return;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- copy the adjustment record
	Lootster_AdjustRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_AdjustId]);

	-- and show the adjust dialog
	Lootster_Popup_Show(Lootster_RaidFrameAdjustFrame);
end

-- Raid Delete Adjust Click handler
function Lootster_Raid_Adjust_Delete_OnClick(self, button)
	-- make sure we have a adjustment selected
	if (Lootster_AdjustId == nil) then
		return;
	end

	-- copy the adjustment record
	Lootster_AdjustRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_AdjustId]);

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ADJUST_DELETE");
end

-- Raid Delete Adjust Accept handler
function Lootster_Raid_Adjust_Delete_OnAccept()
	-- no adustment record we are done
	if (Lootster_AdjustRec == nil) then
		return;
	end
	
	-- delete this adjustment record
	Lootster_DeleteAdjust(Lootster_AdjustRec.Id);
	
	-- get the next adjust id
	Lootster_AdjustId = Lootster_GetNextId(Lootster_BossAdjustSort, Lootster_AdjustRec.Id);
	
	-- get the next assign if this was assign id
	if ((Lootster_AssignId ~= nil) and (Lootster_Adjust[Lootster_AssignId] == nil)) then
		-- get the next assign id
		Lootster_AssignId = Lootster_GetNextId(Lootster_BossAssignSort, Lootster_AssignId);
	end
	
	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset adjust record
	Lootster_AdjustRec = nil;
	
	-- reset assign record if this was the assign id
	if ((Lootster_AssignRec ~= nil) and (Lootster_Adjust[Lootster_AssignRec.Id] == nil)) then
		-- reset assign record
		Lootster_AssignRec = nil;
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete Adjust Cancel handler
function Lootster_Raid_Adjust_Delete_OnCancel()
	-- reset adjust record
	Lootster_AdjustRec = nil;
end

-- Raid Delete ALL Adjust handler
function Lootster_Raid_Adjust_DeleteAll_OnClick(self, button)
	-- make sure we have some adjustments
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil) or (#Lootster_BossAdjustSort == 0)) then
		return;
	end

	-- copy the first adjustment record so we retain the selected boss id if they switch bosses on us
	Lootster_AdjustRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_BossAdjustSort[1]]);

	-- and show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ADJUST_DELETEALL");
end

-- Raid Delete ALL Adjust handler
function Lootster_Raid_Adjust_DeleteAll_OnAccept()
	-- no adjustment record we are done
	if (Lootster_AdjustRec == nil) then
		return;
	end
	
	-- delete all adjustments from the boss
	Lootster_DeleteAllAdjust(Lootster_AdjustRec.BossId);

	-- smoke the current adjust id
	Lootster_AdjustId = nil;

	-- smoke the current assign id
	Lootster_AssignId = nil;

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset adjust record
	Lootster_AdjustRec = nil;

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete ALL Adjust Cancel handler
function Lootster_Raid_Adjust_DeleteAll_OnCancel()
	-- reset adjust record
	Lootster_AdjustRec = nil;
end

-- Show Adjust DKP handler
function Lootster_Raid_Adjust_OnShow(self)
	local	opCode, wcount, dkpValue;

	-- no adjustment record and boss means we are done
	if ((Lootster_AdjustRec == nil) or ((Lootster_BossId == nil) and (Lootster_AdjustRec.BossId == nil))) then
		-- rehide frame
		Lootster_RaidFrameAdjustFrame:Hide();
	else
		-- set prompts for player depending on operation
		if (Lootster_AdjustRec.Id == nil) then
			opCode = LOOTSTER_RAID_INSERT;
		else
			opCode = LOOTSTER_RAID_MODIFY;
		end

		-- format and set adjustment operation
		Lootster_RaidFrameAdjustFrameText:SetFormattedText(LOOTSTER_RAIDADJUST_TITLE, opCode);
		Lootster_RaidFrameAdjustFrameApply:SetFormattedText(LOOTSTER_RAIDADJUST_APPLY, opCode);

		-- do we have a multi-player list?
		if		((Lootster_AdjustRec.Won ~= nil) and (Lootster_AdjustRec.WonItemCount ~= nil)) then
			-- snarf item count
			wcount = Lootster_AdjustRec.WonItemCount;

			-- how many items?
			if		(wcount == 1) then
				-- no assignee list.  Do we have a winning player?
				if (#Lootster_AdjustRec.Won == 1) then
					-- use player drop down
					Lootster_AdjustRec.Player = Lootster_GetAltMain(Lootster_AdjustRec.Won[1].Player);

					Lootster_AdjustRec.Alt = Lootster_AdjustRec.Won[1].Player;
					
					-- update usage and DKP spent
					Lootster_AdjustRec.Usage = Lootster_AdjustRec.Won[1].Usage;
					Lootster_AdjustRec.DKPAdjEarnt = Lootster_AdjustRec.Won[1].DKPAdjEarnt;
					Lootster_AdjustRec.DKPAdjSpent = Lootster_AdjustRec.Won[1].DKPAdjSpent;

					-- and cause player menu to update
					UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
					UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
					
					-- and cause the usage menu to update
					UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameAdjustFrameUsage, Lootster_AdjustRec.Usage);
				end
			elseif	(wcount > 1) then
				-- set the count
				Lootster_RaidFrameAdjustFrameItemItemsText:SetText(wcount);
				Lootster_RaidFrameAdjustFrameReasonItemsText:SetText(wcount);
			end
			
			-- won items are always DKP spent
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				Lootster_RaidFrameAdjustFrameDKPValueEarnt:Hide();
			end
		else
			-- single winner only
			wcount = 1;
			
			-- manually created/modified items can be DKP earnt or spent
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				Lootster_RaidFrameAdjustFrameDKPValueEarnt:Show();
			end
		end
		
		-- show count frames if more than one winner
		if (wcount > 1) then
			-- show multiple assignee frame
			Lootster_RaidFrameAdjustFrameAssignFrame:Show();

			-- show count frames
			Lootster_RaidFrameAdjustFrameItemItemsFrame:Show();
			Lootster_RaidFrameAdjustFrameReasonItemsFrame:Show();

			-- update assignee list
			Lootster_RaidAdjust_Update();
		else
			-- hide multiple assignee frame
			Lootster_RaidFrameAdjustFrameAssignFrame:Hide();

			-- hide count frames
			Lootster_RaidFrameAdjustFrameItemItemsFrame:Hide();
			Lootster_RaidFrameAdjustFrameReasonItemsFrame:Hide();
		end
		
		-- determine whether we use earnt/spent DKP
		if		(Lootster_AdjustRec.DKPAdjEarnt > 0) then
			-- this earnt DKP
			dkpValue = LOOTSTER_ENUM_DKPVALUE.EARNT;
			
			-- update earnt DKP
			Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjEarnt));
		else
			-- this spent DKP
			dkpValue = LOOTSTER_ENUM_DKPVALUE.SPENT;
			
			-- update spent DKP
			Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));
		end
		
		-- set earnt/spent selector
		Lootster_RaidFrameAdjustFrameDKPValueEarnt:SetChecked(dkpValue == LOOTSTER_ENUM_DKPVALUE.EARNT);
		Lootster_RaidFrameAdjustFrameDKPValueSpent:SetChecked(dkpValue == LOOTSTER_ENUM_DKPVALUE.SPENT);
		
		-- update reason
		Lootster_RaidFrameAdjustFrameReason:SetText(Lootster_AdjustRec.Reason);
		Lootster_RaidFrameAdjustFrameCommentText:SetText(Lootster_AdjustRec.Comment);
	end
end

-- Hide Adjust DKP handler
function Lootster_Raid_Adjust_OnHide(self)
	-- default operation code
	Lootster_RaidFrameAdjustFrameText:SetText(LOOTSTER_RAIDADJUST_TITLE);
	Lootster_RaidFrameAdjustFrameApply:SetText(LOOTSTER_RAIDADJUST_APPLY);

	-- reset adjust DKP values
	Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, 0));
	Lootster_RaidFrameAdjustFrameReason:SetText("");
	Lootster_RaidFrameAdjustFrameCommentText:SetText("\n");

	-- smoke adjust record
	Lootster_AdjustRec = nil;
end

-- Raid Adjust Player Show handler
function Lootster_Raid_Adjust_Player_OnShow(self)
	-- ignore if no adjust record
	if (Lootster_AdjustRec == nil) then
		return;
	end

	-- setup the player drop down
	UIDropDownMenu_Initialize(self, Lootster_Raid_Adjust_Player_Initialise, "MENU");

	-- set width
	UIDropDownMenu_SetWidth(self, 160);

	-- and justify left
	Lootster_RaidFrameAdjustFramePlayerDropDownText:SetJustifyH("LEFT");
end

-- Raid Adjust Player Initaliser handler
function Lootster_Raid_Adjust_Player_Initialise()
	-- ignore if no adjust record
	if (Lootster_AdjustRec == nil) then
		return;
	end

	-- build player dropdown for adjustment
	Lootster_Build_Player_DropDown(LOOTSTER_RAIDADJUST_SELECT, Lootster_Raid_Adjust_OnSelect, LOOTSTER_RAIDADJUST_OTHERPLAYER,
								   Lootster_Raid_Adjust_OnPlayer);

	-- select the winner if we have one unless we have a multi-assignee list
	if		((Lootster_AdjustRec.Won == nil) or (Lootster_AdjustRec.WonItemCount == nil)) then
		-- do we have a player?
		if (Lootster_AdjustRec.Player ~= nil) then
			-- get the alt if he is present
			player = Lootster_GetMainAlt(Lootster_AdjustRec.Player);

			-- he's a winner!
			UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, player);
			UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, player);
		else
			-- no winner - reset
			UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, "");
			UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, nil);
		end
	elseif	((#Lootster_AdjustRec.Won == 1) and (Lootster_AdjustRec.WonItemCount == 1))  then
		-- a winner!
		UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
		UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
	else
		-- multiple assignees - reset
		UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, "");
		UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, nil);
	end

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Player Select handler
function Lootster_Raid_Adjust_OnSelect(self)
	-- ignore if no adjust record
	if (Lootster_AdjustRec == nil) then
		return;
	end
	
	-- retrieve the selected playa (could be an alt)
	Lootster_AdjustRec.Alt = self.value;
	
	-- retrieve the selected playa main
	Lootster_AdjustRec.Player = Lootster_GetAltMain(Lootster_AdjustRec.Alt);

	-- and select him in the drop down
	UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, self.value);
	UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, self.value);

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();

	-- close menus
	CloseDropDownMenus();
end

-- Raid Adjust Enter Other Player handler
function Lootster_Raid_Adjust_OnPlayer()
	-- ignore if no adjust record
	if (Lootster_AdjustRec == nil) then
		return;
	end

	-- show edit box for player name
	StaticPopup_Show("LOOTSTER_PROMPT_ADJUST_PLAYER");
end

-- Raid Adjust Assign Show handler
function Lootster_Raid_Adjust_Assign_OnShow(self)
end

-- Raid Adjust Assign Append handler
function Lootster_Raid_Adjust_Assign_Append_OnClick(self, button)
	-- do we have a selected player?
	if (Lootster_AdjustRec.Player == nil) then
		return;
	end

	-- retrieve the selected DKP
	Lootster_AdjustRec.DKPAdjSpent = Lootster_RaidFrameAdjustFrameDKP:GetNumber();

	-- append this entry
	table.insert(Lootster_AdjustRec.Won,
				 Lootster_NewWin(Lootster_AdjustRec.Player, Lootster_AdjustRec.Usage, 0, Lootster_AdjustRec.DKPAdjSpent));

	-- reset the player and alt
	Lootster_AdjustRec.Player = nil;
	Lootster_AdjustRec.Alt = nil;

	-- reset player selection
	UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, "");
	UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, nil);
	
	-- update the spent DKP
	Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));

	-- update assignee list
	Lootster_RaidAdjust_Update();

	-- scroll to end of list
	Lootster_RaidFrameAdjustFrameAssignScrollFrame:SetVerticalScroll(#Lootster_AdjustRec.Won);

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Assign Update handler
function Lootster_Raid_Adjust_Assign_Update_OnClick(self, button)
	local	count;

	-- do we have a selected index?
	if (Lootster_AdjustRec.PlayerIx == nil) then
		return;
	end

	-- retrieve the selected DKP
	Lootster_AdjustRec.DKPAdjSpent = Lootster_RaidFrameAdjustFrameDKP:GetNumber();

	-- update the usage and DKP spent for this assignee
	Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Usage = Lootster_AdjustRec.Usage;
	Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].DKPAdjSpent = Lootster_AdjustRec.DKPAdjSpent;
	
	-- update the spent DKP
	Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));

	-- update assignee list
	Lootster_RaidAdjust_Update();

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Assign Remove handler
function Lootster_Raid_Adjust_Assign_Remove_OnClick(self, button)
	local	count, player;

	-- do we have a selected index?
	if (Lootster_AdjustRec.PlayerIx == nil) then
		return;
	end

	-- remove this entry
	table.remove(Lootster_AdjustRec.Won, Lootster_AdjustRec.PlayerIx);

	-- get count of remaining entries
	count = #Lootster_AdjustRec.Won;

	-- last entry?
	if		(count == 0) then
		-- nothing selected now
		Lootster_AdjustRec.PlayerIx = nil;
	elseif	(Lootster_AdjustRec.PlayerIx > count) then
		-- last is selected
		Lootster_AdjustRec.PlayerIx = count;
	end
	
	-- do we have a selected entry?
	if (Lootster_AdjustRec.PlayerIx ~= nil) then
		-- retrieve the selected playa main
		Lootster_AdjustRec.Player = Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Player;

		-- retrieve the selected playa (could be an alt)
		Lootster_AdjustRec.Alt = Lootster_GetMainAlt(Lootster_AdjustRec.Player);

		-- retrieve the selected usage and DKP
		Lootster_AdjustRec.Usage = Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Usage;
		Lootster_AdjustRec.DKPAdjSpent = Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].DKPAdjSpent;

		-- and select him in the drop down
		UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
		UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
		
		-- and cause the usage menu to update
		UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameAdjustFrameUsage, Lootster_AdjustRec.Usage);
		
		-- update the spent DKP
		Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));
	end
	
	-- update assignee list
	Lootster_RaidAdjust_Update();

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Assign Remove All handler
function Lootster_Raid_Adjust_Assign_RemoveAll_OnClick(self, button)
	-- this is easy
	Lootster_AdjustRec.Won = {};

	-- nothing selected now
	Lootster_AdjustRec.PlayerIx = nil;

	-- update assignee list
	Lootster_RaidAdjust_Update();

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Assign Button handler
function Lootster_Raid_Adjust_Assign_Button_OnClick(self, button)
	local	offset, player;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameAdjustFrameAssignScrollFrame);

	-- calculate the selected assignee index
	Lootster_AdjustRec.PlayerIx = self:GetID() + offset;

	-- retrieve the selected playa main
	Lootster_AdjustRec.Player = Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Player;

	-- retrieve the selected playa (could be an alt)
	Lootster_AdjustRec.Alt = Lootster_GetMainAlt(Lootster_AdjustRec.Player);

	-- retrieve the selected usage and DKP
	Lootster_AdjustRec.Usage = Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Usage;
	Lootster_AdjustRec.DKPAdjSpent = Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].DKPAdjSpent;

	-- and select him in the drop down
	UIDropDownMenu_SetText(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
	UIDropDownMenu_SetSelectedName(Lootster_RaidFrameAdjustFramePlayerDropDown, Lootster_AdjustRec.Alt);
	
	-- and cause the usage menu to update
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameAdjustFrameUsage, Lootster_AdjustRec.Usage);
	
	-- up date the spent DKP
	Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));

	-- update assignee list
	Lootster_RaidAdjust_Update();

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust DKP Entered handler
function Lootster_Raid_Adjust_DKP_OnTextChanged(self)
	-- snarf the DKP, depending on whatDKP value it represents
	if (Lootster_RaidFrameAdjustFrameDKPValueEarnt:GetChecked() ~= nil) then
		Lootster_AdjustRec.DKPAdjEarnt = Lootster_RaidFrameAdjustFrameDKP:GetNumber();
		Lootster_AdjustRec.DKPAdjSpent = 0;
	else
		Lootster_AdjustRec.DKPAdjEarnt = 0;
		Lootster_AdjustRec.DKPAdjSpent = Lootster_RaidFrameAdjustFrameDKP:GetNumber();
	end
		
	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Default DKP handler
function Lootster_Raid_Adjust_Default_OnClick(self, button)
	local	dkp;

	-- retrieve the DKP for this item
	dkp = Lootster_GetItemDKP(Lootster_RaidFrameAdjustFrameReason:GetText(), Lootster_AdjustRec.Link);
	
	-- calculate the usage factors
	dkp = Lootster_CalcUsageDKP(Lootster_AdjustRec.Player, Lootster_AdjustRec.Alt, Lootster_AdjustRec.Usage, dkp);
	
	-- and normalise
	Lootster_AdjustRec.DKPAdjSpent = Lootster_CalcPoints(dkp);
	
	-- display the new DKP
	Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust DKP Value By Click handler
function Lootster_Raid_Adjust_DKPValue_RadioButton_OnClick(self, button, index)
	-- set earnt/spent
	Lootster_RaidFrameAdjustFrameDKPValueEarnt:SetChecked(index == LOOTSTER_ENUM_DKPVALUE.EARNT);
	Lootster_RaidFrameAdjustFrameDKPValueSpent:SetChecked(index == LOOTSTER_ENUM_DKPVALUE.SPENT);
	
	-- resnarf the DKP value
	Lootster_Raid_Adjust_DKP_OnTextChanged(self);
	
	-- play sound if selected
	if (index ~= nil) then
		PlaySound("igMainMenuOptionCheckBoxOn");
	end

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Usage Load handler
function Lootster_Raid_Adjust_Usage_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 130);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Adjust Usage Show handler
function Lootster_Raid_Adjust_Usage_OnShow(self)
	-- no adjust record  we are done
	if (Lootster_AdjustRec == nil) then
		return;
	end
	
	-- setup the raid raid usage drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameAdjustFrameUsage, Lootster_Raid_Adjust_Usage_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameAdjustFrameUsage, Lootster_AdjustRec.Usage);
end

-- Raid Adjust Usage Load Initaliser handler
function Lootster_Raid_Adjust_Usage_Initialise()
	local	list, ix, entry, info;
	
	-- add manual entry usage type if a manual create/modify
	if (Lootster_AdjustRec.Won == nil) then
		-- add manual entry usage type
		info = {};
		info.func = Lootster_Raid_Adjust_Usage_OnSelect;
		info.value = 0;

		-- determine DKP/simple usage enumeration
		if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
			info.text = LOOTSTER_USAGEDKP_LIST[LOOTSTER_ENUM_USAGE.MANUAL];
		elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
			info.text = LOOTSTER_USAGENORM_LIST[LOOTSTER_ENUM_USAGE.MANUAL];
		else
			info.text = LOOTSTER_USAGENORM_LIST[LOOTSTER_ENUM_USAGE.MANUAL];
		end
		
		-- add raid adjust usage button
		UIDropDownMenu_AddButton(info);
	end

	-- determine DKP/simple usage enumeration
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		list = LOOTSTER_USAGEDKP_LIST;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		list = LOOTSTER_USAGENORM_LIST;
	else
		list = LOOTSTER_USAGENORM_LIST;
	end
	
	-- and the regular usage types
	for ix, entry in ipairs(list) do
		-- form mode button
		info = {};
		info.text = entry;
		info.func = Lootster_Raid_Adjust_Usage_OnSelect;
		info.value = ix;

		-- add raid adjust usage button
		UIDropDownMenu_AddButton(info);
	end
end

-- Raid Adjust Usage Select handler
function Lootster_Raid_Adjust_Usage_OnSelect(self)
	local	dkp;

	-- no adjust record  we are done
	if (Lootster_AdjustRec == nil) then
		return;
	end
	
	-- snarf new raid usage column
	Lootster_AdjustRec.Usage = self.value;
	
	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameAdjustFrameUsage, self.value);
	
	-- retrieve the DKP for this item
	dkp = Lootster_GetItemDKP(Lootster_RaidFrameAdjustFrameReason:GetText(), Lootster_AdjustRec.Link);
	
	-- calculate the usage factors
	dkp = Lootster_CalcUsageDKP(Lootster_AdjustRec.Player, Lootster_AdjustRec.Alt, Lootster_AdjustRec.Usage, dkp);
	
	-- and normalise
	Lootster_AdjustRec.DKPAdjSpent = Lootster_CalcPoints(dkp);
	
	-- display the new DKP
	Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, Lootster_AdjustRec.DKPAdjSpent));

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Item Link Click handler
function Lootster_Raid_Adjust_ItemLink_OnClick(self, button)
	local	itemLink;

	-- retrieve  the item link
	itemLink = Lootster_RaidFrameAdjustFrameItemText:GetText();

	-- pass link to tooltip click handler
	Lootster_ClickTooltip(itemLink, button);
end

-- Raid Adjust Reason Entered handler
function Lootster_Raid_Adjust_Reason_OnTextChanged(self)
	local	itemId, itemText, itemQual, dkp, itemLink, bossId;

	-- no initial item link
	itemLink = "";

	-- does the current link text match?
	if		((Lootster_ItemText ~= "") and (Lootster_RaidFrameAdjustFrameReason:GetText() == Lootster_ItemText)) then
		-- use current item ID and link
		itemId = Lootster_ItemID;
		itemLink = Lootster_ItemLink;
	elseif (Lootster_AdjustRec.Link ~= nil) then
		-- get link text
		itemId, itemText, itemQual = Lootster_GetItemBasics(Lootster_AdjustRec.Link);

		-- is this the same as the entered text?
		if (Lootster_RaidFrameAdjustFrameReason:GetText() == itemText) then
			-- use item link
			itemLink = Lootster_AdjustRec.Link;
		end
	end

	-- see if we have an item ID
	if (itemId ~= nil) then
		-- do we have a boss associated with the adjustment?
		if (Lootster_AdjustRec.BossId ~= nil) then
			-- use the adjustment boss
			bossId = Lootster_AdjustRec.BossId;
		else
			-- current boss
			bossId = Lootster_BossId;
		end
	end
	
	-- set whatever link
	Lootster_RaidFrameAdjustFrameItemText:SetText(itemLink);

	-- update raid adjust UI
	Lootster_UpdateRaidAdjustUI();
end

-- Raid Adjust Comment Entered handler
function Lootster_Raid_Adjust_Comment_OnTextChanged(self)
end

-- Raid Adjust Apply handler
function Lootster_Adjust_Apply_OnClick(self, button)
	local bossId, player, itemId, itemText, itemQual, count, ix, adjustRec;
	
	-- no adjust record we are done
	if (Lootster_AdjustRec == nil) then
		return;
	end
	
	-- use adjust record boss if present
	if (Lootster_AdjustRec.BossId ~= nil) then
		-- use this boss id
		bossId = Lootster_AdjustRec.BossId;
	else
		-- use selected boss
		bossId = Lootster_BossId;
	end

	-- no boss id we are done
	if (bossId == nil) then
		return;
	end

	-- is this a non-bookkeep item?
	if ((Lootster_AdjustRec.Won == nil) or (Lootster_AdjustRec.WonItemCount == nil)) then
		-- no assignee we are done
		if (Lootster_AdjustRec.Player == nil) then
			return;
		end
		
		-- spoof a assign list by using this player
		Lootster_AdjustRec.Won = { Lootster_NewWin(Lootster_AdjustRec.Player, Lootster_AdjustRec.Usage, Lootster_AdjustRec.DKPAdjEarnt, Lootster_AdjustRec.DKPAdjSpent, Lootster_AdjustRec.Id) };
		Lootster_AdjustRec.WonItemCount = 1;
	end

	-- retrieve data
	Lootster_AdjustRec.Link = Lootster_RaidFrameAdjustFrameItemText:GetText();
	Lootster_AdjustRec.Reason = Lootster_RaidFrameAdjustFrameReason:GetText();
	Lootster_AdjustRec.Comment = Lootster_AppendTrailingLineBreak(Lootster_RaidFrameAdjustFrameCommentText:GetText());

	-- get link id
	itemId, itemText, itemQual = Lootster_GetItemBasics(Lootster_AdjustRec.Link);

	-- if we have no item ID we assume this is earnt DKP
	if (itemId == nil) then
		Lootster_AdjustRec.DKPAdjEarnt = Lootster_RaidFrameAdjustFrameDKP:GetNumber();
		Lootster_AdjustRec.DKPAdjSpent = 0;
	else
		Lootster_AdjustRec.DKPAdjEarnt = 0;
		Lootster_AdjustRec.DKPAdjSpent = Lootster_RaidFrameAdjustFrameDKP:GetNumber();
	end

	-- determine if we are bookkeeping all items
	if (#Lootster_AdjustRec.Won < Lootster_AdjustRec.WonItemCount) then
		-- only use assigned
		count = #Lootster_AdjustRec.Won;
	else
		-- use item count
		count = Lootster_AdjustRec.WonItemCount
	end

	-- create/modify adjustments for each player
	for ix=1, count do
		-- create a copy of this adjustment
		adjustRec = Lootster_CopyRecord(Lootster_AdjustRec);

		-- reset win bookkeeping in this guy
		adjustRec.Won = nil;
		adjustRec.WonItemCount = nil;
		
		-- transfer the adjustment Id if one was created in the win list
		adjustRec.Id = Lootster_AdjustRec.Won[ix].AdjustId;

		-- get the player and the alt from the list
		adjustRec.Player = Lootster_AdjustRec.Won[ix].Player;

		adjustRec.Alt = Lootster_GetMainAlt(adjustRec.Player);

		-- use the alt as the player
		player = adjustRec.Alt;

		-- get usage and DKP spent
		adjustRec.Usage = Lootster_AdjustRec.Won[ix].Usage;
		adjustRec.DKPAdjEarnt = Lootster_AdjustRec.Won[ix].DKPAdjEarnt;
		adjustRec.DKPAdjSpent = Lootster_AdjustRec.Won[ix].DKPAdjSpent;

		-- are we creating or modifying an adjustment record?
		if (adjustRec.Id == nil) then
			-- create the adjustment
			adjustId = Lootster_CreateAdjust(adjustRec);
			
			-- insert adjustment into the boss
			Lootster_InsertAdjust(bossId, adjustId);
			
			-- and update the winner's adjustment Id
			Lootster_AdjustRec.Won[ix].AdjustId = adjustId;
		else
			-- modify the adjustment
			Lootster_ModifyAdjust(adjustRec);
		end
	end

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- reset adjust record
	Lootster_AdjustRec = nil;

	-- hide the UI
	Lootster_RaidFrameAdjustFrame:Hide();

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Adjust Cancel handler
function Lootster_Adjust_Cancel_OnClick(self, button)
	-- smoke adjustment record
	Lootster_AdjustRec = nil;
end

-- Raid Adjust Update UI handler
function Lootster_UpdateRaidAdjustUI()
	-- enable adjustment button if player(s) selected and reason entered
	if		((Lootster_RaidFrameAdjustFrameReason:GetText() == "") or (Lootster_AdjustRec == nil)) then
		Lootster_RaidFrameAdjustFrameApply:Disable();
	elseif	((Lootster_AdjustRec.Won == nil) and (Lootster_AdjustRec.Player == nil)) then
		Lootster_RaidFrameAdjustFrameApply:Disable();
	elseif	((Lootster_AdjustRec.Won ~= nil) and (Lootster_AdjustRec.WonItemCount == 1) and (Lootster_AdjustRec.Player == nil)) then
		Lootster_RaidFrameAdjustFrameApply:Disable();
	elseif	((Lootster_AdjustRec.Won ~= nil) and (Lootster_AdjustRec.WonItemCount > 1) and (#Lootster_AdjustRec.Won == 0)) then
		Lootster_RaidFrameAdjustFrameApply:Disable();
	else
		Lootster_RaidFrameAdjustFrameApply:Enable();
	end

	-- are we using DKP rolling?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- manage the earnt/spent DKP prompt depending on DKP value selector
		if (Lootster_RaidFrameAdjustFrameDKPValueEarnt:GetChecked() ~= nil) then
			-- earnt DKP
			if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
				Lootster_RaidFrameAdjustFrameDKPLabel:SetText(LOOTSTER_RAIDADJUST_EPEARNT);
			else
				Lootster_RaidFrameAdjustFrameDKPLabel:SetText(LOOTSTER_RAIDADJUST_DKPEARNT);
			end
			
			-- hide the default button
			Lootster_RaidFrameAdjustFrameDKPDefault:Hide();
		else
			-- spent DKP
			if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
				Lootster_RaidFrameAdjustFrameDKPLabel:SetText(LOOTSTER_RAIDADJUST_GPSPENT);
			else
				Lootster_RaidFrameAdjustFrameDKPLabel:SetText(LOOTSTER_RAIDADJUST_DKPSPENT);
			end
			
			-- show the default button
			Lootster_RaidFrameAdjustFrameDKPDefault:Show();
			
			-- retrieve the DKP for this item
			dkp = Lootster_GetItemDKP(Lootster_RaidFrameAdjustFrameReason:GetText(), Lootster_AdjustRec.Link);
			
			-- calculate the usage factors
			dkp = Lootster_CalcUsageDKP(Lootster_AdjustRec.Player, Lootster_AdjustRec.Alt, Lootster_AdjustRec.Usage, dkp);
			
			-- and normalise
			dkp = Lootster_CalcPoints(dkp);
	
			-- do we differ from displayed DKP?
			if (Lootster_RaidFrameAdjustFrameDKP:GetNumber() == dkp) then
				-- disable DKP default button
				Lootster_RaidFrameAdjustFrameDKPDefault:Disable();
			else
				-- enable DKP default button
				Lootster_RaidFrameAdjustFrameDKPDefault:Enable();
			end
		end
	end

	-- update raid adjust assign UI
	Lootster_UpdateRaidAdjustAssignUI();
end

-- Raid Adjust Update Assign UI handler
function Lootster_UpdateRaidAdjustAssignUI()
	-- are we showing an assignee list?
	if ((Lootster_AdjustRec ~= nil) and (Lootster_AdjustRec.Won ~= nil) and (Lootster_AdjustRec.WonItemCount ~= nil)) then
		-- set current count of assignees
		Lootster_RaidFrameAdjustFrameColumnHeader1:SetFormattedText(LOOTSTER_RAIDADJUST_ASSIGNEES, #Lootster_AdjustRec.Won);	

		-- do we have a player to append and we have room?
		if ((Lootster_AdjustRec.Player == nil) or (#Lootster_AdjustRec.Won == Lootster_AdjustRec.WonItemCount)) then
			Lootster_RaidFrameAdjustFrameAssignAppend:Disable();
		else
			Lootster_RaidFrameAdjustFrameAssignAppend:Enable();
		end
		
		-- do we have a player selected and its the same as selected? 
		if ((Lootster_AdjustRec.PlayerIx ~= nil) and (Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Player == Lootster_AdjustRec.Player)) then
			-- unchanged usage and DKP means no update required
			if ((Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].Usage == Lootster_AdjustRec.Usage) and
				(Lootster_AdjustRec.Won[Lootster_AdjustRec.PlayerIx].DKPAdjSpent == Lootster_RaidFrameAdjustFrameDKP:GetNumber())) then
				Lootster_RaidFrameAdjustFrameAssignUpdate:Disable();
			else
				Lootster_RaidFrameAdjustFrameAssignUpdate:Enable();
			end
		else
			Lootster_RaidFrameAdjustFrameAssignUpdate:Disable();
		end

		-- do we have a player selected?
		if (Lootster_AdjustRec.PlayerIx == nil) then
			Lootster_RaidFrameAdjustFrameAssignRemove:Disable();
		else
			Lootster_RaidFrameAdjustFrameAssignRemove:Enable();
		end

		-- do we have any players in the list?
		if (#Lootster_AdjustRec.Won == 0) then
			Lootster_RaidFrameAdjustFrameAssignRemoveAll:Disable();
		else
			Lootster_RaidFrameAdjustFrameAssignRemoveAll:Enable();
		end

		-- if we have allocate all the items, no more player drop down
		if ((Lootster_AdjustRec.WonItemCount > 1) and (#Lootster_AdjustRec.Won == Lootster_AdjustRec.WonItemCount)) then
			Lootster_RaidFrameAdjustFrameDropDownShow:Disable();
			Lootster_RaidFrameAdjustFramePlayerDropDownButton:Disable();
		else
			Lootster_RaidFrameAdjustFrameDropDownShow:Enable();
			Lootster_RaidFrameAdjustFramePlayerDropDownButton:Enable();
		end
	else
		Lootster_RaidFrameAdjustFrameDropDownShow:Enable();
		Lootster_RaidFrameAdjustFramePlayerDropDownButton:Disable();
	end
end

-- Raid Assign Row Click handler
function Lootster_Raid_Assign_Button_OnClick(self, button)
	local	offset, key;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAssignFrameScrollFrame);

	-- calculate actual the assign item index and get the assign record key
	key = Lootster_BossAssignSort[self:GetID() + offset];

	-- if this is a different attend, snarf
	if (key ~= Lootster_AssignId) then
		-- snarf the new assignment Id
		Lootster_AssignId = key;

		-- resort raid attend using current sort
		Lootster_Raid_Assign_Sort(nil);

		-- update the raid UI
		Lootster_UpdateRaidUI();
	end
end

-- Raid Assign Row Enter handler
function Lootster_Raid_Assign_Button_OnEnter(self)
	local	offset, key, tooltip;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAssignFrameScrollFrame);

	-- calculate actual the assign item index and get the assign record key
	key = Lootster_BossAssignSort[self:GetID() + offset];
	
	-- format player and alt
	tooltip = string.format(LOOTSTER_MSG_ASSIGNTOOLTIP, Lootster_Adjust[key].Player, Lootster_Adjust[key].Alt, 
							LOOTSTER_USAGEDKP_LIST[Lootster_Adjust[key].Usage], LOOTSTER_TOBEASSIGNED_LIST[Lootster_Adjust[key].TBA]);
	
	return tooltip;
end

-- Raid Assign ALL Assigns handler
function Lootster_Raid_Assign_AssignAll_OnClick(self, button)
	local	adjustId, player, adjustRec;
	
	-- no raid or boss id  we are done
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil)) then
		return;
	end
	
	-- hammer through all outstanding assigments
	for adjustId, player in pairs(Lootster_Boss[Lootster_BossId].AssignSet) do
		-- copy the adjustment
		adjustRec = Lootster_CopyRecord(Lootster_Adjust[adjustId]);
		
		-- mark as booked
		adjustRec.TBA = LOOTSTER_ENUM_TOBEASSIGNED.MATCHED;
		
		-- and modify
		Lootster_ModifyAdjust(adjustRec, true);
	end
	
	-- smoke the current assign id
	Lootster_AssignId = nil;
	
	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- update the raid UI
	Lootster_UpdateRaidUI();	
end

-- Raid Assign Assign handler
function Lootster_Raid_Assign_Assign_OnClick(self, button)
	local	adjustRec;
	
	-- make sure we have an assignment selected
	if (Lootster_AssignId == nil) then
		return;
	end

	-- copy the adjustment
	adjustRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_AssignId]);
	
	-- mark as booked
	adjustRec.TBA = LOOTSTER_ENUM_TOBEASSIGNED.MATCHED;
	
	-- and modify
	Lootster_ModifyAdjust(adjustRec, true);
	
	-- get the next assignment id
	Lootster_AssignId = Lootster_GetNextId(Lootster_BossAssignSort, Lootster_AssignId);
	
	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);

	-- update the raid UI
	Lootster_UpdateRaidUI();	
end

-- Raid Modify Assign handler
function Lootster_Raid_Assign_Modify_OnClick(self, button)
	-- make sure we have an assignment selected
	if (Lootster_AssignId == nil) then
		return;
	end

	-- hide outstanding dialog, if any
	Lootster_Popup_Show();

	-- copy the adjustment record
	Lootster_AdjustRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_AssignId]);

	-- and show the adjust dialog
	Lootster_Popup_Show(Lootster_RaidFrameAdjustFrame);
end

-- Raid Delete Assign Click handler
function Lootster_Raid_Assign_Delete_OnClick(self, button)
	-- make sure we have an assignment selected
	if (Lootster_AssignId == nil) then
		return;
	end

	-- copy the assignment (adjustment) record
	Lootster_AssignRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_AssignId]);

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ASSIGN_DELETE");
end

-- Raid Delete Assign Accept handler
function Lootster_Raid_Assign_Delete_OnAccept()
	-- no assignment (adjustment) record we are done
	if (Lootster_AssignRec == nil) then
		return;
	end
	
	-- delete this adjustment record
	Lootster_DeleteAdjust(Lootster_AssignRec.Id);
	
	-- get the next adjust if this was assign id
	if ((Lootster_AdjustId ~= nil) and (Lootster_Adjust[Lootster_AdjustId] == nil)) then
		-- get the next adjust id
		Lootster_AdjustId = Lootster_GetNextId(Lootster_BossAdjustSort, Lootster_AdjustId);
	end
	
	-- get the next assignment id
	Lootster_AssignId = Lootster_GetNextId(Lootster_BossAssignSort, Lootster_AssignRec.Id);

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- reset adjust record if this was the adjust id
	if ((Lootster_AdjustRec ~= nil) and (Lootster_Adjust[Lootster_AdjustRec.Id] == nil)) then
		-- reset adjust record
		Lootster_AdjustRec = nil;
	end

	-- reset assignment (adjustment) record
	Lootster_AssignRec = nil;

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete Assign Cancel handler
function Lootster_Raid_Assign_Delete_OnCancel()
	-- reset assign (adjust) record
	Lootster_AssignRec = nil;
end

-- Raid Delete ALL Assign handler
function Lootster_Raid_Assign_DeleteAll_OnClick(self, button)
	-- make sure we have some adjustments
	if ((Lootster_RaidId == nil) or (Lootster_BossId == nil) or (#Lootster_BossAssignSort == 0)) then
		return;
	end

	-- copy the first assignment (adjustment) record so we retain the selected boss id if they switch bosses on us
	Lootster_AssignRec = Lootster_CopyRecord(Lootster_Adjust[Lootster_BossAssignSort[1]]);

	-- and show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ASSIGN_DELETEALL");
end

-- Raid Delete ALL Assign handler
function Lootster_Raid_Assign_DeleteAll_OnAccept()
	-- no assignment (adjustment) record we are done
	if (Lootster_AssignRec == nil) then
		return;
	end
	
	-- delete all assignments (adjustments) from the boss
	Lootster_DeleteAllAssign(Lootster_AssignRec.BossId);

	-- announcing adjustment changes?
	if (Lootster_Options.AckNoAdj == true) then
		-- let them know
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_ASSIGNDELETEDALL, Lootster_Raid[Lootster_Boss[Lootster_AdjustRec.BossId].RaidId].Zone,
											 Lootster_FormatBoss(Lootster_Boss[Lootster_AdjustRec.BossId].Boss, 
																 Lootster_Boss[Lootster_AdjustRec.BossId].Attempt)));
	end
	
	-- reset adjust id if this was the adjust id
	if ((Lootster_AdjustId ~= nil) and (Lootster_Adjust[Lootster_AdjustId] == nil)) then
		-- reset adjust id
		Lootster_AdjustId = nil;
	end

	-- smoke the current assign id
	Lootster_AssignId = nil;

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- reset adjust record if this was the adjust id
	if ((Lootster_AdjustRec ~= nil) and (Lootster_Adjust[Lootster_AdjustRec.Id] == nil)) then
		-- reset adjust record
		Lootster_AdjustRec = nil;
	end

	-- reset assign record
	Lootster_AssignRec = nil;

	-- did our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	-- update the raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Delete ALL Assign Cancel handler
function Lootster_Raid_Assign_DeleteAll_OnCancel()
	-- reset assign (adjust) record
	Lootster_AssignRec = nil;
end

-- Item Synchronise handler
function Lootster_Item_Sync_OnClick(self, button)
	-- show the item sync dialog
	Lootster_Popup_Show(Lootster_ItemSyncFrame);
end

-- Item Clear Item Link handler
function Lootster_Item_ClearItem_OnClick(self, button)
	-- reset the hyperlinks
	Lootster_SetHyperlink(nil);
end

-- Item Item Link Click handler
function Lootster_Item_ItemLink_OnClick(self, button)
	-- do we have a link?
	if (Lootster_ItemLink ~= nil) then
		-- pass link to tooltip click handler
		Lootster_ClickTooltip(Lootster_ItemLink, button);
	end
end

-- Item Row Click handler
function Lootster_Item_Button_OnClick(self, button)
	local	offset, itemId, isCached, itemLink;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_ItemFrameScrollFrame);

	-- calculate actual the restricted item index and get the item record key
	itemId = Lootster_ItemSort[self:GetID() + offset];

	-- get the item link
	isCached, itemLink = Lootster_GetItemLink(itemId, Lootster_Restrict[itemId].Text);

	-- pass link to tooltip click handler
	Lootster_ClickTooltip(itemLink, button);
end

-- Item Row Enter handler
function Lootster_Item_Button_OnEnter(self)
	local	offset, isCached, itemLink, itemText, permitted, tooltip;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_ItemFrameScrollFrame);

	-- calculate actual the restricted item index and get the item record key
	itemId = Lootster_ItemSort[self:GetID() + offset];

	-- get the item link
	isCached, itemLink = Lootster_GetItemLink(itemId, Lootster_Restrict[itemId].Text);

	-- create restrictions text
	itemText, permitted = Lootster_CreateRestricts(itemLink);
	
	-- format restricted item tooltip
	tooltip = string.format(LOOTSTER_MSG_ITEMTOOLTIP, itemText, permitted);

	-- and display the tooltip
	Lootster_DisplayTooltip(self, itemLink, tooltip);
end

-- Item Delete Click handler
function Lootster_Item_Delete_OnClick(self, button)
	local	offset;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_ItemFrameScrollFrame);

	-- calculate actual the restricted item index and get the item record key
	Lootster_ItemSel = Lootster_ItemSort[self:GetParent():GetID() + offset];

	-- and show delete dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ITEM_DELETE");
end

-- Item Delete ALL handler
function Lootster_Item_DeleteAll_OnClick(self, button)
	-- show delete ALL dialog
	Lootster_StaticPopup_Show("LOOTSTER_PROMPT_ITEM_DELETEALL");
end

-- Item Delete Accept handler
function Lootster_Item_Delete_OnAccept()
	-- far too easy
	Lootster_Restrict[Lootster_ItemSel] = nil;

	-- is this our current item?
	if (Lootster_ItemID == Lootster_ItemSel) then
		-- resnarf as existing hyperlink
		Lootster_SetHyperlink(Lootster_ItemLink);
	end
	
	-- resort item using current sort
	Lootster_Item_Sort(nil);

	-- reset selected item ID
	Lootster_ItemSel = nil;
end

-- Item Delete Cancel handler
function Lootster_Item_Delete_OnCancel()
	-- reset restricted item key
	Lootster_ItemSel = nil;
end

-- Item Delete ALL Accept handler
function Lootster_Item_DeleteAll_OnAccept()
	-- far too easy
	Lootster_Restrict = {};

	-- resnarf existing hyperlink, if any
	Lootster_SetHyperlink(Lootster_ItemLink);
	
	-- resort item using current sort
	Lootster_Item_Sort(nil);
end

-- Item Class Toggle handler
function Lootster_Item_Class_OnToggle(self)
	local	offset, itemId, classId, check, ix;
	
	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_ItemFrameScrollFrame);

	-- calculate actual the restricted item index and get the item record key
	itemId = Lootster_ItemSort[self:GetParent():GetID() + offset];
	
	-- get the class id that was hit
	classId = self:GetID();

	-- see which way we are switching
	if (self:GetChecked() ~= nil) then
		-- add this class
		table.insert(Lootster_Restrict[itemId].Classes, LOOTSTER_CLASS_SORT[classId]);
	else
		-- search through class list for removal
		for ix, class in ipairs(Lootster_Restrict[itemId].Classes) do
			-- right class?
			if (LOOTSTER_CLASS_SORT[classId] == class) then
				-- remove this class
				table.remove(Lootster_Restrict[itemId].Classes, ix);
				break;
			end
		end
	end
	
	-- is this our current item?
	if (Lootster_ItemID == itemId) then
		-- resnarf as existing hyperlink
		Lootster_SetHyperlink(Lootster_ItemLink);
	end
	
	-- repaint item list
	Lootster_Item_Update();
end

-- Show Loot Synchronise handler
function Lootster_LootSync_OnShow(self)
	-- reset synchronise user
	Lootster_SyncUser = nil;
	
	-- overwrite is always initially OFF (failsafe)
	Lootster_LootSyncFrameOverwrite:SetChecked(false);

	-- reset progress
	Lootster_LootSyncFrameProgress:SetValue(0);
	
	-- disable apply and enable cancel
	Lootster_LootSyncFrameApply:Disable();
	Lootster_LootSyncFrameCancel:Enable();
	Lootster_LootSyncFrameCancel:SetText(LOOTSTER_LOOTSYNC_CLOSE);
end

-- Hide Loot Synchronise handler
function Lootster_LootSync_OnHide(self)
	-- reset synchronise user
	Lootster_SyncUser = nil;

	-- reset progress
	Lootster_LootSyncFrameProgress:SetValue(0);
end

-- Loot Synchronise Overwrite Button Toggle handler
function Lootster_LootSync_Overwrite_OnToggle(self)
	-- we don't care for the moment - only at commit time
end

-- Loot Synchronise Player Show handler
function Lootster_LootSync_Player_OnShow(self)
	-- setup the player drop down
	UIDropDownMenu_Initialize(self, Lootster_LootSync_Player_Initialise, "MENU");

	-- set width
	UIDropDownMenu_SetWidth(self, 160);

	-- and justify left
	Lootster_LootSyncFramePlayerDropDownText:SetJustifyH("LEFT");
end

-- Loot Synchronise Player Initaliser handler
function Lootster_LootSync_Player_Initialise()
	-- build player dropdown for attendance
	Lootster_Build_Player_DropDown(LOOTSTER_LOOTSYNC_SELECT, Lootster_LootSync_OnSelect, LOOTSTER_LOOTSYNC_OTHERPLAYER, Lootster_LootSync_OnPlayer, true, true);
	
	-- no player yet - reset
	UIDropDownMenu_SetText(Lootster_LootSyncFramePlayerDropDown, "");
	UIDropDownMenu_SetSelectedName(Lootster_LootSyncFramePlayerDropDown, nil);

	-- update item synchronise UI
	Lootster_UpdateLootSyncUI();
end

-- Loot Synchronise Player Select handler
function Lootster_LootSync_OnSelect(self)
	-- snarf the selected player
	Lootster_SyncUser = self.value;

	-- select him in the drop down
	UIDropDownMenu_SetText(Lootster_LootSyncFramePlayerDropDown, self.value);
	UIDropDownMenu_SetSelectedName(Lootster_LootSyncFramePlayerDropDown, self.value);
	
	-- update item attendance UI
	Lootster_UpdateLootSyncUI();

	-- close menus
	CloseDropDownMenus();
end

-- Item Synchronise Enter Other Player handler
function Lootster_LootSync_OnPlayer()
	-- show edit box for player name
	StaticPopup_Show("LOOTSTER_PROMPT_LOOTSYNC_PLAYER");
end

-- Loot Synchronise Apply handler
function Lootster_LootSync_Apply_OnClick(self, button)
	-- no synchronise user means we are done
	if (Lootster_SyncUser == nil) then
		return;
	end
	
	-- set synchronise function
	Lootster_SyncType = LOOTSTER_SYNC_CMD_SYNCLOOT;

	-- set synchronise title
	Lootster_SyncTitle = LOOTSTER_LOOTSYNC_TITLE;

	-- initiate contact
	Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_SYNCLOOT, LOOTSTER_SYNC_VERSION), true);
	
	-- update item synchronise UI
	Lootster_Sync_StateUpdate();
end

-- Loot Synchronise Cancel handler
function Lootster_LootSync_Cancel_OnClick(self, button)
	-- are we in progress?
	if (Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCLOOT) then
		-- cancelled by player - abort
		Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADCANCEL, Lootster_SyncTitle), true);

		-- abort synchronise
		Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

		-- cancelled operation
		Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_CANCEL);
	else
		-- just hide user interface
		Lootster_LootSyncFrame:Hide();
	end
end

-- Loot Synchronise Update UI handler
function Lootster_UpdateLootSyncUI(terminal)
	-- we started to synchronise?
	if		(terminal ~= nil) then
		-- reset player
		UIDropDownMenu_SetText(Lootster_LootSyncFramePlayerDropDown, "");
		UIDropDownMenu_SetSelectedName(Lootster_LootSyncFramePlayerDropDown, nil);

		-- update terminal state
		Lootster_LootSyncFrameProgressState:SetText(terminal);

		-- enable overwrite checkbox
		Lootster_LootSyncFrameOverwrite:Enable();

		-- disable apply and enable close
		Lootster_LootSyncFrameApply:Disable();
		Lootster_LootSyncFrameCancel:Enable();
		Lootster_LootSyncFrameCancel:SetText(LOOTSTER_LOOTSYNC_CLOSE);
	elseif	(Lootster_SyncType == nil) then
		-- pre-sync or post-sync?
		if (Lootster_LootSyncFrameCancel:IsEnabled() ~= nil) then
			-- enable apply button if player selected
			if (Lootster_SyncUser == nil) then
				Lootster_LootSyncFrameApply:Disable();
			else
				Lootster_LootSyncFrameApply:Enable();
			end
		else
			-- enable overwrite checkbox
			Lootster_LootSyncFrameOverwrite:Enable();

			-- enable apply and close
			Lootster_LootSyncFrameApply:Enable();
			Lootster_LootSyncFrameCancel:Enable();
			Lootster_LootSyncFrameCancel:SetText(LOOTSTER_LOOTSYNC_CLOSE);
		end
	elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCLOOT) then
		-- synchronising.  Manage each stage of the sychronise
		if		((Lootster_SyncCount == 0) and (Lootster_SyncTotal == 0)) then
			-- disable apply
			Lootster_LootSyncFrameApply:Disable();
			Lootster_LootSyncFrameCancel:SetText(LOOTSTER_LOOTSYNC_CANCEL);

			-- disable overwrite checkbox
			Lootster_LootSyncFrameOverwrite:Disable();

			-- reset progress
			Lootster_LootSyncFrameProgress:SetValue(0);

			-- set contacting state
			Lootster_LootSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_CONTACT);	
		elseif	(Lootster_SyncAcks == 1) then
			-- set acknowledge state
			Lootster_RaidSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_ACKED);
		elseif	(Lootster_SyncCount == 0) then
			-- initialise progress bar
			Lootster_LootSyncFrameProgress:SetMinMaxValues(0, Lootster_SyncTotal);

			-- set receiving state
			Lootster_LootSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_RECEIVE);	
		elseif	(Lootster_SyncCount ~= Lootster_SyncTotal) then
			-- update progress bar
			Lootster_LootSyncFrameProgress:SetValue(Lootster_SyncCount);
		elseif	(Lootster_SyncCount == Lootster_SyncTotal) then
			-- update progress bar
			Lootster_LootSyncFrameProgress:SetValue(Lootster_SyncCount);

			-- set commiting state
			Lootster_LootSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_COMMIT);
		end
	end
end

-- Show Raid Synchronise handler
function Lootster_RaidSync_OnShow(self)
	-- reset synchronise user
	Lootster_SyncUser = nil;

	-- reset progress
	Lootster_RaidSyncFrameProgress:SetValue(0);

	-- reset receiving state
	Lootster_RaidSyncFrameProgressState:SetText("");	

	-- disable apply and enable close
	Lootster_RaidSyncFrameApply:Disable();
	Lootster_RaidSyncFrameCancel:Enable();
	Lootster_RaidSyncFrameCancel:SetText(LOOTSTER_RAIDSYNC_CLOSE);
end

-- Hide Raid Synchronise handler
function Lootster_RaidSync_OnHide(self)
	-- reset synchronise user
	Lootster_SyncUser = nil;

	-- reset progress
	Lootster_RaidSyncFrameProgress:SetValue(0);
end

-- Raid Synchronise Player Show handler
function Lootster_RaidSync_Player_OnShow(self)
	-- setup the player drop down
	UIDropDownMenu_Initialize(self, Lootster_RaidSync_Player_Initialise, "MENU");

	-- set width
	UIDropDownMenu_SetWidth(self, 160);

	-- and justify left
	Lootster_RaidSyncFramePlayerDropDownText:SetJustifyH("LEFT");
end

-- Raid Synchronise Player Initaliser handler
function Lootster_RaidSync_Player_Initialise()
	-- build player dropdown for attendance
	Lootster_Build_Player_DropDown(LOOTSTER_RAIDSYNC_SELECT, Lootster_RaidSync_OnSelect, LOOTSTER_RAIDSYNC_OTHERPLAYER, Lootster_RaidSync_OnPlayer, true, true);
	
	-- no player yet - reset
	UIDropDownMenu_SetText(Lootster_RaidSyncFramePlayerDropDown, "");
	UIDropDownMenu_SetSelectedName(Lootster_RaidSyncFramePlayerDropDown, nil);

	-- update raid synchronise UI
	Lootster_UpdateRaidSyncUI();
end

-- Raid Synchronise Player Select handler
function Lootster_RaidSync_OnSelect(self)
	-- snarf the selected player
	Lootster_SyncUser = self.value;

	-- select him in the drop down
	UIDropDownMenu_SetText(Lootster_RaidSyncFramePlayerDropDown, self.value);
	UIDropDownMenu_SetSelectedName(Lootster_RaidSyncFramePlayerDropDown, self.value);
	
	-- update raid attend UI
	Lootster_UpdateRaidSyncUI();

	-- close menus
	CloseDropDownMenus();
end

-- Raid Synchronise Enter Other Player handler
function Lootster_RaidSync_OnPlayer()
	-- show edit box for player name
	StaticPopup_Show("LOOTSTER_PROMPT_RAIDSYNC_PLAYER");
end

-- Raid Synchronise Apply handler
function Lootster_RaidSync_Apply_OnClick(self, button)
	-- no synchronise user means we are done
	if (Lootster_SyncUser == nil) then
		return;
	end
	
	-- set synchronise function
	Lootster_SyncType = LOOTSTER_SYNC_CMD_SYNCRAID;

	-- set synchronise title
	Lootster_SyncTitle = LOOTSTER_RAIDSYNC_TITLE;

	-- initiate contact
	Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_SYNCRAID, LOOTSTER_SYNC_VERSION), true);
	
	-- update raid synchronise UI
	Lootster_Sync_StateUpdate();
end

-- Raid Synchronise Cancel handler
function Lootster_RaidSync_Cancel_OnClick(self, button)
	-- are we in progress?
	if (Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCRAID) then
		-- cancelled by player - abort
		Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADCANCEL, Lootster_SyncTitle), true);

		-- abort synchronise
		Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

		-- cancelled operation
		Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_CANCEL);
	else
		-- just hide user interface
		Lootster_RaidSyncFrame:Hide();
	end
end

-- Raid Synchronise Update UI handler
function Lootster_UpdateRaidSyncUI(terminal)
	-- we started to synchronise?
	if		(terminal ~= nil) then
		-- reset player
		UIDropDownMenu_SetText(Lootster_RaidSyncFramePlayerDropDown, "");
		UIDropDownMenu_SetSelectedName(Lootster_RaidSyncFramePlayerDropDown, nil);

		-- update terminal state
		Lootster_RaidSyncFrameProgressState:SetText(terminal);

		-- disable apply and enable cancel
		Lootster_RaidSyncFrameApply:Disable();
		Lootster_RaidSyncFrameCancel:Enable();
		Lootster_RaidSyncFrameCancel:SetText(LOOTSTER_RAIDSYNC_CLOSE);
	elseif	(Lootster_SyncType == nil) then
		-- pre-sync or post-sync?
		if (Lootster_RaidSyncFrameCancel:IsEnabled() ~= nil) then
			-- enable apply button if player selected
			if (Lootster_SyncUser == nil) then
				Lootster_RaidSyncFrameApply:Disable();
			else
				Lootster_RaidSyncFrameApply:Enable();
			end
		else
			-- enable apply and cancel
			Lootster_RaidSyncFrameApply:Enable();
			Lootster_RaidSyncFrameCancel:Enable();
			Lootster_RaidSyncFrameCancel:SetText(LOOTSTER_RAIDSYNC_CLOSE);
		end
	elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCRAID) then
		-- synchronising.  Manage each stage of the sychronise
		if		((Lootster_SyncCount == 0) and (Lootster_SyncTotal == 0)) then
			-- disable apply and change to cancel
			Lootster_RaidSyncFrameApply:Disable();
			Lootster_RaidSyncFrameCancel:SetText(LOOTSTER_RAIDSYNC_CANCEL);

			-- reset progress
			Lootster_RaidSyncFrameProgress:SetValue(0);

			-- set contacting state
			Lootster_RaidSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_CONTACT);
		elseif	(Lootster_SyncAcks == 1) then
			-- set acknowledge state
			Lootster_RaidSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_ACKED);
		elseif	(Lootster_SyncCount == 0) then
			-- initialise progress bar
			Lootster_RaidSyncFrameProgress:SetMinMaxValues(0, Lootster_SyncTotal);

			-- set receiving state
			Lootster_RaidSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_RECEIVE);	
		elseif	(Lootster_SyncCount ~= Lootster_SyncTotal) then
			-- update progress bar
			Lootster_RaidSyncFrameProgress:SetValue(Lootster_SyncCount);
		elseif	(Lootster_SyncCount == Lootster_SyncTotal) then
			-- update progress bar
			Lootster_RaidSyncFrameProgress:SetValue(Lootster_SyncCount);

			-- set commiting state
			Lootster_RaidSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_COMMIT);
		end
	end
end


-- Show Item Synchronise handler
function Lootster_ItemSync_OnShow(self)
	-- reset synchronise user
	Lootster_SyncUser = nil;
	
	-- overwrite is always initially OFF (failsafe)
	Lootster_ItemSyncFrameOverwrite:SetChecked(false);

	-- reset progress
	Lootster_ItemSyncFrameProgress:SetValue(0);
	
	-- disable apply and enable cancel
	Lootster_ItemSyncFrameApply:Disable();
	Lootster_ItemSyncFrameCancel:Enable();
	Lootster_ItemSyncFrameCancel:SetText(LOOTSTER_ITEMSYNC_CLOSE);
end

-- Hide Item Synchronise handler
function Lootster_ItemSync_OnHide(self)
	-- reset synchronise user
	Lootster_SyncUser = nil;

	-- reset progress
	Lootster_ItemSyncFrameProgress:SetValue(0);
end

-- Item Synchronise Overwrite Button Toggle handler
function Lootster_ItemSync_Overwrite_OnToggle(self)
	-- we don't care for the moment - only at commit time
end

-- Item Synchronise Player Show handler
function Lootster_ItemSync_Player_OnShow(self)
	-- setup the player drop down
	UIDropDownMenu_Initialize(self, Lootster_ItemSync_Player_Initialise, "MENU");

	-- set width
	UIDropDownMenu_SetWidth(self, 160);

	-- and justify left
	Lootster_ItemSyncFramePlayerDropDownText:SetJustifyH("LEFT");
end

-- Item Synchronise Player Initaliser handler
function Lootster_ItemSync_Player_Initialise()
	-- build player dropdown for attendance
	Lootster_Build_Player_DropDown(LOOTSTER_ITEMSYNC_SELECT, Lootster_ItemSync_OnSelect, LOOTSTER_ITEMSYNC_OTHERPLAYER, Lootster_ItemSync_OnPlayer, true, true);
	
	-- no player yet - reset
	UIDropDownMenu_SetText(Lootster_ItemSyncFramePlayerDropDown, "");
	UIDropDownMenu_SetSelectedName(Lootster_ItemSyncFramePlayerDropDown, nil);

	-- update item synchronise UI
	Lootster_UpdateItemSyncUI();
end

-- Item Synchronise Player Select handler
function Lootster_ItemSync_OnSelect(self)
	-- snarf the selected player
	Lootster_SyncUser = self.value;

	-- select him in the drop down
	UIDropDownMenu_SetText(Lootster_ItemSyncFramePlayerDropDown, self.value);
	UIDropDownMenu_SetSelectedName(Lootster_ItemSyncFramePlayerDropDown, self.value);
	
	-- update item attendance UI
	Lootster_UpdateItemSyncUI();

	-- close menus
	CloseDropDownMenus();
end

-- Item Synchronise Enter Other Player handler
function Lootster_ItemSync_OnPlayer()
	-- show edit box for player name
	StaticPopup_Show("LOOTSTER_PROMPT_ITEMSYNC_PLAYER");
end

-- Item Synchronise Apply handler
function Lootster_ItemSync_Apply_OnClick(self, button)
	-- no synchronise user means we are done
	if (Lootster_SyncUser == nil) then
		return;
	end
	
	-- set synchronise function
	Lootster_SyncType = LOOTSTER_SYNC_CMD_SYNCITEM;

	-- set synchronise title
	Lootster_SyncTitle = LOOTSTER_ITEMSYNC_TITLE;

	-- initiate contact
	Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_SYNCITEM, LOOTSTER_SYNC_VERSION), true);
	
	-- update item synchronise UI
	Lootster_Sync_StateUpdate();
end

-- Item Synchronise Cancel handler
function Lootster_ItemSync_Cancel_OnClick(self, button)
	-- are we in progress?
	if (Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCITEM) then
		-- cancelled by player - abort
		Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADCANCEL, Lootster_SyncTitle), true);

		-- abort synchronise
		Lootster_SendPrivate(Lootster_SyncUser, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

		-- cancelled operation
		Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_CANCEL);
	else
		-- just hide user interface
		Lootster_ItemSyncFrame:Hide();
	end
end

-- Item Synchronise Update UI handler
function Lootster_UpdateItemSyncUI(terminal)
	-- we started to synchronise?
	if		(terminal ~= nil) then
		-- reset player
		UIDropDownMenu_SetText(Lootster_ItemSyncFramePlayerDropDown, "");
		UIDropDownMenu_SetSelectedName(Lootster_ItemSyncFramePlayerDropDown, nil);

		-- update terminal state
		Lootster_ItemSyncFrameProgressState:SetText(terminal);

		-- enable overwrite checkbox
		Lootster_ItemSyncFrameOverwrite:Enable();

		-- disable apply and enable close
		Lootster_ItemSyncFrameApply:Disable();
		Lootster_ItemSyncFrameCancel:Enable();
		Lootster_ItemSyncFrameCancel:SetText(LOOTSTER_ITEMSYNC_CLOSE);
	elseif	(Lootster_SyncType == nil) then
		-- pre-sync or post-sync?
		if (Lootster_ItemSyncFrameCancel:IsEnabled() ~= nil) then
			-- enable apply button if player selected
			if (Lootster_SyncUser == nil) then
				Lootster_ItemSyncFrameApply:Disable();
			else
				Lootster_ItemSyncFrameApply:Enable();
			end
		else
			-- enable overwrite checkbox
			Lootster_ItemSyncFrameOverwrite:Enable();

			-- enable apply and close
			Lootster_ItemSyncFrameApply:Enable();
			Lootster_ItemSyncFrameCancel:Enable();
			Lootster_ItemSyncFrameCancel:SetText(LOOTSTER_ITEMSYNC_CLOSE);
		end
	elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCITEM) then
		-- synchronising.  Manage each stage of the sychronise
		if		((Lootster_SyncCount == 0) and (Lootster_SyncTotal == 0)) then
			-- disable apply
			Lootster_ItemSyncFrameApply:Disable();
			Lootster_ItemSyncFrameCancel:SetText(LOOTSTER_ITEMSYNC_CANCEL);

			-- disable overwrite checkbox
			Lootster_ItemSyncFrameOverwrite:Disable();

			-- reset progress
			Lootster_ItemSyncFrameProgress:SetValue(0);

			-- set contacting state
			Lootster_ItemSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_CONTACT);	
		elseif	(Lootster_SyncAcks == 1) then
			-- set acknowledge state
			Lootster_RaidSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_ACKED);
		elseif	(Lootster_SyncCount == 0) then
			-- initialise progress bar
			Lootster_ItemSyncFrameProgress:SetMinMaxValues(0, Lootster_SyncTotal);

			-- set receiving state
			Lootster_ItemSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_RECEIVE);	
		elseif	(Lootster_SyncCount ~= Lootster_SyncTotal) then
			-- update progress bar
			Lootster_ItemSyncFrameProgress:SetValue(Lootster_SyncCount);
		elseif	(Lootster_SyncCount == Lootster_SyncTotal) then
			-- update progress bar
			Lootster_ItemSyncFrameProgress:SetValue(Lootster_SyncCount);

			-- set commiting state
			Lootster_ItemSyncFrameProgressState:SetText(LOOTSTER_SYNC_STATE_COMMIT);
		end
	end
end

-- Register Report handler
function Lootster_RegisterReport(handle, mask, name, tooltip, callback, ...)
	-- must have all three
	if ((type(handle) ~= "string") or (type(mask) ~= "number") or (type(name) ~= "string") or (type(tooltip) ~= "string") or (type(callback) ~= "function")) then
		error(string.format(LOOTSTER_MSG_BADREPORTPLUGIN, type(handle), type(mask), type(name), type(tooltip), type(callback)));
	end

	-- add this guy to our list.  Handle is the language invariant key
	Lootster_RepList[handle] = Lootster_NewReport(handle, mask, name, tooltip, callback, ...);
	
	-- sort the report list
	Lootster_RaidReport_Format_Sort();

	return true;
end

-- Show Raid Report handler
function Lootster_RaidReport_OnShow(self)
	-- setup report attendance buttons
	Lootster_RaidReport_Attend_OnToggle(self);

	-- simply build raid report
	Lootster_RaidReport_Refresh_OnClick(Lootster_RaidFrameReportFrameRefresh, "LeftButton");
end

-- Refresh Raid Report handler
function Lootster_RaidReport_Refresh_OnClick(self, button)
	local	txtReport = "";

	-- call the required report writer if we have one
	if (Lootster_ReportWriterCB ~= nil) then
		txtReport = Lootster_ReportWriterCB(Lootster_ReportWriterMask, Lootster_ReportWriterArgs);
	end

	-- and send to report frame
	Lootster_RaidFrameReportFrameReport:SetText(txtReport);

	-- hack to cause scroll frame to be positioned at top
	Lootster_RaidFrameReportFrameReport.Reposition = 0;
	
	-- are we to select the text?
	if (bit.band(Lootster_ReportWriterMask, LOOTSTER_MASK_REPORTTYPE.SELTEXT) ~= 0) then
		-- select all the text
		Lootster_RaidFrameReportFrameReport:HighlightText();
	end
end

-- Raid Report Report Format Load handler
function Lootster_RaidReport_ReportFormat_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 160);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Report Report Format Show handler
function Lootster_RaidReport_ReportFormat_OnShow(self)
	-- setup the adjustment sort drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameReportFrameReportFormat, Lootster_RaidReport_ReportFormat_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameReportFormat, Lootster_Options.RepFormat);
		
	-- initialise raid report UI
	Lootster_UpdateRaidReportUI();
end

-- Raid Report Report Format Enter handler
function Lootster_RaidReport_ReportFormat_OnEnter(self)
	-- return the tooltip for the selected report type, if any
	if (Lootster_RepList[Lootster_Options.RepFormat] ~= nil) then
		return Lootster_RepList[Lootster_Options.RepFormat].Tooltip;
	else
		return LOOTSTER_RAIDREPORT_REPORTFORMAT_TT;
	end
end

-- Raid Report Report Format Load Initaliser handler
function Lootster_RaidReport_ReportFormat_Initialise()
	local	repIx, repHandle;

	for repIx, repHandle in ipairs(Lootster_RepListSort) do
		-- form mode button
		info = {};
		info.text = Lootster_RepList[repHandle].Name;
		info.func = Lootster_RaidReport_ReportFormat_OnSelect;
		info.value = Lootster_RepList[repHandle].Handle;

		-- add adjustment field button
		UIDropDownMenu_AddButton(info);
	end
end

-- Raid Report Report Format Select handler
function Lootster_RaidReport_ReportFormat_OnSelect(self)
	-- snarf new adjustment sort column
	Lootster_Options.RepFormat = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameReportFormat, self.value);
	
	-- hook the report writer for the selected report format
	Lootster_ReportWriterCB = Lootster_RepList[Lootster_Options.RepFormat].Callback;
	Lootster_ReportWriterArgs = Lootster_RepList[Lootster_Options.RepFormat].Args;
	
	-- extract the current report type from the current report format mask
	Lootster_ReportWriterMask = bit.band(Lootster_ReportWriterMask, LOOTSTER_MASK_REPORTTYPE.MASKIN);
	
	-- if the selected report format mask supports this current report type, we are good, else hammer to a supported value
	if (bit.band(Lootster_ReportWriterMask, Lootster_RepList[Lootster_Options.RepFormat].Mask) == 0) then
		-- determine which format fits best
		if		(bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.FULL) ~= 0) then
			-- select a full report type
			Lootster_ReportWriterMask = LOOTSTER_MASK_REPORTTYPE.FULL;
		elseif	(bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.RAID) ~= 0) then
			-- select a raid report type
			Lootster_ReportWriterMask = LOOTSTER_MASK_REPORTTYPE.RAID;
		elseif	(bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.BOSS) ~= 0) then
			-- select a raid report type
			Lootster_ReportWriterMask = LOOTSTER_MASK_REPORTTYPE.BOSS;
		end
	end
	
	-- finally update mask with the rest of the selected report format mask
	Lootster_ReportWriterMask = bit.bor(Lootster_ReportWriterMask, bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.MASKOUT));
		
	-- update raid UI
	Lootster_UpdateRaidUI();
end

-- Raid Report Raid Sort Load handler
function Lootster_RaidReport_RaidSort_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 100);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Report Raid Sort Show handler
function Lootster_RaidReport_RaidSort_OnShow(self)
	-- setup the raid sort drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameReportFrameRaidSort, Lootster_RaidReport_RaidSort_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameRaidSort, Lootster_Options.RepRaidSortCol);
end

-- Raid Report Raid Sort Load Initaliser handler
function Lootster_RaidReport_RaidSort_Initialise()
	local	ix, entry, info;

	for ix, entry in ipairs(LOOTSTER_RAIDREPORT_RAIDSORTLIST) do
		-- is this DKP or EPGP?
		if (((entry.DKP ~= true) and (entry.EPGP ~= true)) or
			((Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) and (entry.DKP == true)) or 
			((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) and (entry.EPGP == true))) then
			-- form mode button
			info = {};
			info.text = entry.Prompt;
			info.func = Lootster_RaidReport_RaidSort_OnSelect;
			info.value = entry.Field;

			-- add raid sort button
			UIDropDownMenu_AddButton(info);
		end
	end
end

-- Raid Report Raid Sort Select handler
function Lootster_RaidReport_RaidSort_OnSelect(self)
	-- snarf new raid sort column
	Lootster_Options.RepRaidSortCol = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameRaidSort, self.value);
end

-- Raid Report Raid Sort Show handler
function Lootster_RaidReport_RaidSortOrd_OnShow(self)
	-- set raid sort order toggle
	Lootster_RaidReport_RaidSortOrd_OnToggle(self, Lootster_Options.RepRaidSortColOrd);
end

-- Raid Report Raid Sort Order Toggle handler
function Lootster_RaidReport_RaidSortOrd_OnToggle(self, ord)
	-- toggle value if not specified
	if (ord == nil) then
		Lootster_Options.RepRaidSortColOrd = not Lootster_Options.RepRaidSortColOrd;
	else
		Lootster_Options.RepRaidSortColOrd = ord;
	end

	-- manage the order button
	if (Lootster_Options.RepRaidSortColOrd ~= true) then
		-- show descending order arrow
		Lootster_RaidFrameReportFrameRaidSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up");
		Lootster_RaidFrameReportFrameRaidSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Down");
		Lootster_RaidFrameReportFrameRaidSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Highlight");
	else
		-- show ascending order arrow
		Lootster_RaidFrameReportFrameRaidSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up");
		Lootster_RaidFrameReportFrameRaidSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Down");
		Lootster_RaidFrameReportFrameRaidSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Highlight");
	end
end

-- Boss Report Boss Sort Load handler
function Lootster_RaidReport_BossSort_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 100);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Report Boss Sort Show handler
function Lootster_RaidReport_BossSort_OnShow(self)
	-- setup the boss sort drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameReportFrameBossSort, Lootster_RaidReport_BossSort_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameBossSort, Lootster_Options.RepBossSortCol);
end

-- Raid Report Boss Sort Load Initaliser handler
function Lootster_RaidReport_BossSort_Initialise()
	local	ix, entry, info;

	for ix, entry in ipairs(LOOTSTER_RAIDREPORT_BOSSSORTLIST) do
		-- is this DKP or EPGP?
		if (((entry.DKP ~= true) and (entry.EPGP ~= true)) or
			((Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) and (entry.DKP == true)) or 
			((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) and (entry.EPGP == true))) then
			-- form mode button
			info = {};
			info.text = entry.Prompt;
			info.func = Lootster_RaidReport_BossSort_OnSelect;
			info.value = entry.Field;

			-- add boss field button
			UIDropDownMenu_AddButton(info);
		end
	end
end

-- Raid Raid Report Boss Sort Select handler
function Lootster_RaidReport_BossSort_OnSelect(self)
	-- snarf new boss sort column
	Lootster_Options.RepBossSortCol = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameBossSort, self.value);
end

-- Raid Report Boss Sort Show handler
function Lootster_RaidReport_BossSortOrd_OnShow(self)
	-- set boss sort order toggle
	Lootster_RaidReport_BossSortOrd_OnToggle(self, Lootster_Options.RepBossSortColOrd);
end

-- Raid Report Boss Sort Order Toggle handler
function Lootster_RaidReport_BossSortOrd_OnToggle(self, ord)
	-- toggle value if not specified
	if (ord == nil) then
		Lootster_Options.RepBossSortColOrd = not Lootster_Options.RepBossSortColOrd;
	else
		Lootster_Options.RepBossSortColOrd = ord;
	end

	-- manage the order button
	if (Lootster_Options.RepBossSortColOrd ~= true) then
		-- show descending order arrow
		Lootster_RaidFrameReportFrameBossSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up");
		Lootster_RaidFrameReportFrameBossSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Down");
		Lootster_RaidFrameReportFrameBossSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Highlight");
	else
		-- show ascending order arrow
		Lootster_RaidFrameReportFrameBossSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up");
		Lootster_RaidFrameReportFrameBossSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Down");
		Lootster_RaidFrameReportFrameBossSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Highlight");
	end
end

-- Raid Report Attend Sort Load handler
function Lootster_RaidReport_AttendSort_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 100);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Report Attend Sort Show handler
function Lootster_RaidReport_AttendSort_OnShow(self)
	-- setup the attendance sort drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameReportFrameAttendSort, Lootster_RaidReport_AttendSort_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameAttendSort, Lootster_Options.RepAttendSortCol);
end

-- Raid Report Attend Sort Load Initaliser handler
function Lootster_RaidReport_AttendSort_Initialise()
	local	ix, entry, info;

	for ix, entry in ipairs(LOOTSTER_RAIDREPORT_ATTENDSORTLIST) do
		-- is this DKP or EPGP?
		if (((entry.DKP ~= true) and (entry.EPGP ~= true)) or
			((Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) and (entry.DKP == true)) or 
			((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) and (entry.EPGP == true))) then
			-- form mode button
			info = {};
			info.text = entry.Prompt;
			info.func = Lootster_RaidReport_AttendSort_OnSelect;
			info.value = entry.Field;

			-- add attendance field button
			UIDropDownMenu_AddButton(info);
		end
	end
end

-- Raid Report Attend Sort Select handler
function Lootster_RaidReport_AttendSort_OnSelect(self)
	-- snarf new attendance sort column
	Lootster_Options.RepAttendSortCol = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameAttendSort, self.value);
end

-- Raid Report Attend Sort Show handler
function Lootster_RaidReport_AttendSortOrd_OnShow(self)
	-- set attendance sort order toggle
	Lootster_RaidReport_AttendSortOrd_OnToggle(self, Lootster_Options.RepAttendSortColOrd);
end

-- Raid Report Attend Sort Order Toggle handler
function Lootster_RaidReport_AttendSortOrd_OnToggle(self, ord)
	-- toggle value if not specified
	if (ord == nil) then
		Lootster_Options.RepAttendSortColOrd = not Lootster_Options.RepAttendSortColOrd;
	else
		Lootster_Options.RepAttendSortColOrd = ord;
	end

	-- manage the order button
	if (Lootster_Options.RepAttendSortColOrd ~= true) then
		-- show descending order arrow
		Lootster_RaidFrameReportFrameAttendSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up");
		Lootster_RaidFrameReportFrameAttendSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Down");
		Lootster_RaidFrameReportFrameAttendSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Highlight");
	else
		-- show ascending order arrow
		Lootster_RaidFrameReportFrameAttendSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up");
		Lootster_RaidFrameReportFrameAttendSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Down");
		Lootster_RaidFrameReportFrameAttendSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Highlight");
	end
end

-- Raid Report Adjust Sort Load handler
function Lootster_RaidReport_AdjustSort_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 100);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Raid Report Adjust Sort Show handler
function Lootster_RaidReport_AdjustSort_OnShow(self)
	-- setup the adjustment sort drop down
	UIDropDownMenu_Initialize(Lootster_RaidFrameReportFrameAdjustSort, Lootster_RaidReport_AdjustSort_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameAdjustSort, Lootster_Options.RepAdjustSortCol);
end

-- Raid Report Adjust Sort Load Initaliser handler
function Lootster_RaidReport_AdjustSort_Initialise()
	local	ix, entry, info;

	for ix, entry in ipairs(LOOTSTER_RAIDREPORT_ADJUSTSORTLIST) do
		-- is this DKP or EPGP?
		if (((entry.DKP ~= true) and (entry.EPGP ~= true)) or
			((Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) and (entry.DKP == true)) or 
			((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) and (entry.EPGP == true))) then
			-- form mode button
			info = {};
			info.text = entry.Prompt;
			info.func = Lootster_RaidReport_AdjustSort_OnSelect;
			info.value = entry.Field;

			-- add adjustment field button
			UIDropDownMenu_AddButton(info);
		end
	end
end

-- Raid Report Adjust Sort Select handler
function Lootster_RaidReport_AdjustSort_OnSelect(self)
	-- snarf new adjustment sort column
	Lootster_Options.RepAdjustSortCol = self.value;

	-- and select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_RaidFrameReportFrameAdjustSort, self.value);
end

-- Raid Report Adjust Sort Show handler
function Lootster_RaidReport_AdjustSortOrd_OnShow(self)
	-- set adjustment sort order toggle
	Lootster_RaidReport_AdjustSortOrd_OnToggle(self, Lootster_Options.RepAdjustSortColOrd);
end

-- Raid Report Adjust Sort Order Toggle handler
function Lootster_RaidReport_AdjustSortOrd_OnToggle(self, ord)
	-- toggle value if not specified
	if (ord == nil) then
		Lootster_Options.RepAdjustSortColOrd = not Lootster_Options.RepAdjustSortColOrd;
	else
		Lootster_Options.RepAdjustSortColOrd = ord;
	end

	-- manage the order button
	if (Lootster_Options.RepAdjustSortColOrd ~= true) then
		-- show descending order arrow
		Lootster_RaidFrameReportFrameAdjustSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up");
		Lootster_RaidFrameReportFrameAdjustSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Down");
		Lootster_RaidFrameReportFrameAdjustSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Highlight");
	else
		-- show ascending order arrow
		Lootster_RaidFrameReportFrameAdjustSortOrd:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up");
		Lootster_RaidFrameReportFrameAdjustSortOrd:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Down");
		Lootster_RaidFrameReportFrameAdjustSortOrd:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Highlight");
	end
end

-- Raid Report Report Attendances Button Toggle handler
function Lootster_RaidReport_Attend_OnToggle(self)
	-- retrieve value
	Lootster_Options.RepAttend = (Lootster_RaidFrameReportFrameAttend:GetChecked() ~= nil);

	-- enable attendance details as required
	if (Lootster_Options.RepAttend == true) then
		Lootster_RaidFrameReportFrameAttendDetail:Enable();
	else
		Lootster_RaidFrameReportFrameAttendDetail:Disable();
	end
end

-- Raid Report Show Detailed Attendance Button Toggle handler
function Lootster_RaidReport_AttendDetail_OnToggle(self)
	-- retrieve value
	Lootster_Options.RepAttendDetail = (Lootster_RaidFrameReportFrameAttendDetail:GetChecked() ~= nil);
end

-- Raid Report Report Adjustments Button Toggle handler
function Lootster_RaidReport_Adjust_OnToggle(self)
	-- retrieve value
	Lootster_Options.RepAdjust = (Lootster_RaidFrameReportFrameAdjust:GetChecked() ~= nil);
end

-- Raid Report Update UI handler
function Lootster_UpdateRaidReportUI()
	-- do we show the sort management frame?
	if ((Lootster_RepList[Lootster_Options.RepFormat] == nil) or (bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.SHOWSORT) == 0)) then
		Lootster_RaidFrameReportFrameSortManageFrame:Hide();
	else
		Lootster_RaidFrameReportFrameSortManageFrame:Show();
	end
	
	-- do we show the detail management frame?
	if ((Lootster_RepList[Lootster_Options.RepFormat] == nil) or (bit.band(Lootster_RepList[Lootster_Options.RepFormat].Mask, LOOTSTER_MASK_REPORTTYPE.SHOWDETAIL) == 0)) then
		Lootster_RaidFrameReportFrameDetailManageFrame:Hide();
	else
		Lootster_RaidFrameReportFrameDetailManageFrame:Show();
	end
end

-- Show Debugging handler
function Lootster_Debugging_OnShow(self)
	-- set the debugging flag
	Lootster_InDebugger = true;
end

-- Debugging Cancel handler
function Lootster_Debugging_Cancel_OnClick(self, button)
	-- reset the debugging flag
	Lootster_InDebugger = false;
end

-- Debugging Transmit handler
function Lootster_Debugging_Transmit_OnClick(self, button)
	local	text, msg;

	-- grab the current debug text
	text = Lootster_DebuggingFrameMessage:GetText();
	
	-- set from debugger flag to indicate we are transmitting
	Lootster_FromDebugger = true;

	-- chop the debug text up according to line ends
	for msg in string.gmatch(text, "(.-)\n") do
		-- send this message directly to the addon message handler
		Lootster_MSG_Addon(LOOTSTER_ADDON_PREFIX, msg, "RAID", Lootster_Self);
	end
	
	-- and reset from debugger flag
	Lootster_FromDebugger = false;
end

-- Data DKP Update handler
function Lootster_Data_DKP_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowClass, rowDKP, rowDKPEarnt, rowDKPSpent, rowTier, rowMember, rowToon, rowTier;

	local	item, name, classColor;
	
	-- retrieve count of DKP items
	count = #Lootster_DKPSort;

	-- retrieve the scroll offset for DKP view
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameDKPFrameScrollFrame);

	-- hammer through the dkp frame rows
	for row=1, LOOTSTER_DATADKP_LINES, 1 do
		-- calculate actual the DKP/adjust item index
		ix = row + offset;

		-- retrieve the DKP row button
		rowButton	= _G["Lootster_DataFrameDKPFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the text elements
			rowName		= _G["Lootster_DataFrameDKPFrameButton"..row.."Name"];
			rowClass	= _G["Lootster_DataFrameDKPFrameButton"..row.."Class"];
			rowDKP		= _G["Lootster_DataFrameDKPFrameButton"..row.."DKP"];
			rowDKPEarnt	= _G["Lootster_DataFrameDKPFrameButton"..row.."DKPEarnt"];
			rowDKPSpent	= _G["Lootster_DataFrameDKPFrameButton"..row.."DKPSpent"];
			rowTier		= _G["Lootster_DataFrameDKPFrameButton"..row.."Tier"];
			rowMember	= _G["Lootster_DataFrameDKPFrameButton"..row.."Member"];
			rowToon		= _G["Lootster_DataFrameDKPFrameButton"..row.."Toon"];

			-- okay, retrieve the DKP item
			item = Lootster_DKP[Lootster_DKPSort[ix]];

			-- this is main record, but the alt may be playing.  Resolve to that alt if it is playing
			name = Lootster_GetMainAlt(item.Player);

			-- format the requisiste data and stuff into the text elements
			rowName:SetText(name);
			rowClass:SetText(item.Class);
			
			-- DKP by EPGP?
			if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
				-- get PR
				rowDKP:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_GetPlayerPR(item.Player));
			else
				-- get DKP
				rowDKP:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_GetPlayerDKP(item.Player));
			end

			-- set earnt/spent DKP
			rowDKPEarnt:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_SumDKPEarnt(item));
			rowDKPSpent:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_SumDKPSpent(item));
			
			-- DKP by Tier?
			if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
				-- show a message for a bad tier
				if (item.Tier == LOOTSTER_TIER_UNKNOWN) then
					rowTier:SetText(LOOTSTER_MSG_UNKNOWNTIER);
				else
					rowTier:SetText(Lootster_GetPlayerTier(item.Player));
				end
			else
				rowTier:SetText("");
			end

			-- set membership and toon using lookup (via data or guild rank values)
			rowMember:SetText(LOOTSTER_MEMBER_LIST[Lootster_GetPlayerMembership(name)]);
			rowToon:SetText(LOOTSTER_TOON_LIST[Lootster_GetPlayerToonship(name)]);

			-- is this the current player?
			if (item.Player == Lootster_PlayerId) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_DataFrameDKPFrameScrollFrame, count, LOOTSTER_DATADKP_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Data Attend Update handler
function Lootster_Data_Attend_Update()
	local	count, tcount;
	local	offset;
	local	row, ix;

	local	rowButton, rowDateAtt, rowAttended, rowDKPAttEarnt, rowDKPAdjEarnt, rowDKPAdjSpent, rowBoss;

	local	item, name;

	local	accDKPAttEarnt, accDKPAdjEarnt, accDKPAdjSpent;

	-- if we are in DKP mode, total row count is 1
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		tcount = 1;
	else
		tcount = 0;
	end

	-- retrieve count of attend items, including our total row
	count = #Lootster_DataAttendSort + 1;
	
	-- retrieve the scroll offset for attend view
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAttendFrameScrollFrame);

	-- reset accumulated DKP
	accDKPAttEarnt=0;
	accDKPAdjEarnt=0;
	accDKPAdjSpent=0;

	-- can we see total row?
	if ((offset + LOOTSTER_DATAATTEND_LINES) <= count) then
		-- run through player sort accumulating DKP
		for ix=1, (count - 1) do
			-- get this attendance
			item = Lootster_Attend[Lootster_DataAttendSort[ix]];

			-- add this records DKP
			accDKPAttEarnt = accDKPAttEarnt + item.DKPAttEarnt;
			accDKPAdjEarnt = accDKPAdjEarnt + item.DKPAdjEarnt;
			accDKPAdjSpent = accDKPAdjSpent + item.DKPAdjSpent;
		end
	end

	-- hammer through the data frame rows
	for row=1, LOOTSTER_DATAATTEND_LINES, 1 do
		-- calculate actual the attend item index
		ix = row + offset;

		-- retrieve the attend row components
		rowButton	= _G["Lootster_DataFrameAttendFrameButton"..row];

		-- do we have data for the row?
		if ((count > 1) and (ix <= count)) then
			-- get the text elements
			rowDateAtt		= _G["Lootster_DataFrameAttendFrameButton"..row.."DateAtt"];
			rowAttended		= _G["Lootster_DataFrameAttendFrameButton"..row.."Attended"];
			rowDKPAttEarnt	= _G["Lootster_DataFrameAttendFrameButton"..row.."DKPAttEarnt"];
			rowDKPAdjEarnt	= _G["Lootster_DataFrameAttendFrameButton"..row.."DKPAdjEarnt"];
			rowDKPAdjSpent	= _G["Lootster_DataFrameAttendFrameButton"..row.."DKPAdjSpent"];
			rowBoss			= _G["Lootster_DataFrameAttendFrameButton"..row.."Boss"];

			-- retrieve the attend item.  If this is the last record, this is the total row
			if (ix < count) then
				item = Lootster_Attend[Lootster_DataAttendSort[ix]];
			else
				item = nil;
			end

			-- no item this is a total record
			if (item ~= nil) then
				-- use item
				rowDateAtt:SetText(Lootster_FormatServerTime(item.DateAtt));
				rowAttended:SetText(LOOTSTER_ATTENDED_LIST[item.Attended]);
				rowDKPAttEarnt:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAttEarnt);
				rowDKPAdjEarnt:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjEarnt);
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjSpent);

				-- set the boss
				rowBoss:SetText(Lootster_Boss[item.BossId].Boss);
			else
				-- total row does not have date and attendance type
				rowDateAtt:SetText("");
				rowAttended:SetText("");

				-- use the accumulated total
				rowDKPAttEarnt:SetFormattedText(LOOTSTER_COST_POINTS, accDKPAttEarnt);
				rowDKPAdjEarnt:SetFormattedText(LOOTSTER_COST_POINTS, accDKPAdjEarnt);
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, accDKPAdjSpent);
				
				-- total row
				rowBoss:SetText(LOOTSTER_MSG_ATTENDTOTAL);
			end

			-- and show this row
			rowButton:Show();
		else
		    -- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_DataFrameAttendFrameScrollFrame, count, LOOTSTER_DATAATTEND_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Data Adjust Update handler
function Lootster_Data_Adjust_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowDateAdj, rowUsage, rowDKPAdjEarnt, rowDKPAdjSpent, rowReason;

	local	item, name;

	local	accDKP, curDKP;

	-- retrieve count of adjust items, including our total row
	count = #Lootster_DataAdjustSort + 1;

	-- retrieve the scroll offset for adjust view
	offset = FauxScrollFrame_GetOffset(Lootster_DataFrameAdjustFrameScrollFrame);

	-- reset accumulated DKP
	accDKPAdjEarnt=0;
	accDKPAdjSpent=0;

	-- can we see total row?
	if ((offset + LOOTSTER_DATAADJUST_LINES) <= count) then
		-- run through player sort accumulating DKP
		for ix=1, (count - 1) do
			-- get this adjustment
			item = Lootster_Adjust[Lootster_DataAdjustSort[ix]];

			-- add this records DKP
			accDKPAdjEarnt = accDKPAdjEarnt + item.DKPAdjEarnt;
			accDKPAdjSpent = accDKPAdjSpent + item.DKPAdjSpent;
		end
	end
	
	-- hammer through the data frame rows
	for row=1, LOOTSTER_DATAADJUST_LINES, 1 do
		-- calculate actual the adjust item index
		ix = row + offset;

		-- retrieve the adjust row components
		rowButton	= _G["Lootster_DataFrameAdjustFrameButton"..row];

		-- do we have data for the row?
		if ((count > 1) and (ix <= count)) then
			-- get the text elements
			rowDateAdj		= _G["Lootster_DataFrameAdjustFrameButton"..row.."DateAdj"];
			rowUsage		= _G["Lootster_DataFrameAdjustFrameButton"..row.."Usage"];
			rowDKPAdjEarnt	= _G["Lootster_DataFrameAdjustFrameButton"..row.."DKPAdjEarnt"];
			rowDKPAdjSpent	= _G["Lootster_DataFrameAdjustFrameButton"..row.."DKPAdjSpent"];
			rowReason		= _G["Lootster_DataFrameAdjustFrameButton"..row.."Reason"];

			-- retrieve the adjust item.  If this is the last record, this is the total row
			if (ix < count) then
				item = Lootster_Adjust[Lootster_DataAdjustSort[ix]];
			else
				item = nil;
			end

			-- no item this is a total record
			if (item ~= nil) then
				-- use item
				rowDateAdj:SetText(Lootster_FormatServerTime(item.DateAdj));
				rowUsage:SetText(LOOTSTER_USAGEDKP_LIST[item.Usage]);
				rowDKPAdjEarnt:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjEarnt);
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjSpent);

				-- if we have a link, use it instead
				if (item.Link ~= nil) then
					rowReason:SetText(item.Link);
				else
					rowReason:SetText(item.Reason);
				end
			else
				-- total row does not have date or usage
				rowDateAdj:SetText("");
				rowUsage:SetText("");

				-- use the accumulated total
				rowDKPAdjEarnt:SetFormattedText(LOOTSTER_COST_POINTS, accDKPAdjEarnt);
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, accDKPAdjSpent);
				
				-- total row
				rowReason:SetText(LOOTSTER_MSG_ADJUSTTOTAL);
			end

			-- and show this row
			rowButton:Show();
		else
		    -- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_DataFrameAdjustFrameScrollFrame, count, LOOTSTER_DATAADJUST_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Loot Update handler
function Lootster_Loot_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowDKPOff, rowDKPMan, rowDKPClear, rowDelete;
	local	text, item, name, dkp, dkpMan;
	
	-- retrieve count of restrict items
	count = #Lootster_LootSort;

	-- retrieve the scroll offset for item view
	offset = FauxScrollFrame_GetOffset(Lootster_LootFrameScrollFrame);

	-- convert any current item text to lower case
	if ((Lootster_ItemText ~= nil) and (Lootster_ItemText ~= "")) then
		text = string.lower(Lootster_ItemText);
	else
		text = nil;
	end

	-- hammer through the loot frame rows
	for row=1, LOOTSTER_LOOT_LINES, 1 do
		-- calculate actual the restrict item index
		ix = row + offset;

		-- retrieve the item row components
		rowButton	= _G["Lootster_LootFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowName		= _G["Lootster_LootFrameButton"..row.."Name"];
			rowDKPOff	= _G["Lootster_LootFrameButton"..row.."DKPOff"];
			rowDKPMan	= _G["Lootster_LootFrameButton"..row.."DKPMan"];
			rowDKPClear	= _G["Lootster_LootFrameButton"..row.."DKPClear"];
			rowDelete	= _G["Lootster_LootFrameButton"..row.."Delete"];

			-- retrieve item id
			id = Lootster_LootSort[ix];

			-- retrieve the item
			item = Lootster_ItemDKP[id];

			-- set name and DKP
			rowName:SetText(id);

			-- are we using calculated points or do we have official DKP?
			if		(Lootster_Options.CalcPoints == true) then
				rowDKPOff:SetText(LOOTSTER_COST_DKPCALC);
			elseif	(item.DKP ~= nil) then
				rowDKPOff:SetFormattedText(LOOTSTER_COST_POINTS, item.DKP);
			else
				rowDKPOff:SetText(LOOTSTER_COST_DKPNONE);
			end

			-- do we have overridden DKP?
			if (item.DKPMan ~= nil) then
				rowDKPMan:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPMan);
			else
				rowDKPMan:SetText(LOOTSTER_COST_DKPNONE);
			end
			
			-- see what kind of loot entry this is
			if		(item.DKP == nil) then
				-- provisional entry, so hide DKP clear and show delete
				rowDKPClear:Hide();
				rowDelete:Show();
			elseif	(item.DKPMan == nil) then
				-- DKP loot entry with no manual DKP, so hide DKP clear and hide delete
				rowDKPClear:Hide();
				rowDelete:Hide();
			else
				-- DKP loot entry with manual DKP, so show DKP clear and hide delete
				rowDKPClear:Show();
				rowDelete:Hide();
			end

			-- does this match any current item text?
			if ((text ~= nil) and (item.Name == text)) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_LootFrameScrollFrame, count, LOOTSTER_LOOT_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Raid Raid Update handle
function Lootster_Raid_Raid_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowZone, rowDateOpn, rowBoss, rowAttend, rowAdjust, rowDKPEarnt, rowDKPSpent;
	
	local	item, dateExp;

	-- retrieve count of raid items
	count = #Lootster_RaidSort;

	-- retrieve the scroll offset for raid view
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameRaidFrameScrollFrame);

	-- hammer through the raid frame rows
	for row=1, LOOTSTER_RAIDRAID_LINES, 1 do
		-- calculate actual the raid item index
		ix = row + offset;

		-- retrieve the raid row components
		rowButton	= _G["Lootster_RaidFrameRaidFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the text elements
			rowZone		= _G["Lootster_RaidFrameRaidFrameButton"..row.."Zone"];
			rowDateOpn	= _G["Lootster_RaidFrameRaidFrameButton"..row.."DateOpn"];
			rowBoss		= _G["Lootster_RaidFrameRaidFrameButton"..row.."Boss"];
			rowAttend	= _G["Lootster_RaidFrameRaidFrameButton"..row.."Attend"];
			rowAdjust	= _G["Lootster_RaidFrameRaidFrameButton"..row.."Adjust"];
			rowDKPEarnt	= _G["Lootster_RaidFrameRaidFrameButton"..row.."DKPEarnt"];
			rowDKPSpent	= _G["Lootster_RaidFrameRaidFrameButton"..row.."DKPSpent"];

			-- okay, retrieve the raid item
			item = Lootster_Raid[Lootster_RaidSort[ix]];

			-- format the requisite data and stuff into the text elements
			rowZone:SetText(item.Zone);
			rowDateOpn:SetText(Lootster_FormatServerTime(item.DateOpn));
			rowBoss:SetText(item.BossN);
			rowAttend:SetText(item.AttendN);
			rowAdjust:SetText(item.AdjustN);

			-- show DKP if in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				rowDKPEarnt:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_SumDKPEarntUpdate(item));
				rowDKPSpent:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_SumDKPSpentUpdate(item));
			else
				rowDKPEarnt:SetText("");
				rowDKPSpent:SetText("");
			end

			-- is this the current raid?
			if (item.Id == Lootster_RaidId) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- is this the running raid?
			if (item.Id ~= Lootster_Running.RaidId) then
				-- set as normal
				rowZone:SetVertexColor(LOOTSTER_RAID_NORMAL_CLR.r, LOOTSTER_RAID_NORMAL_CLR.g, LOOTSTER_RAID_NORMAL_CLR.b);
			else
				-- set as running
				rowZone:SetVertexColor(LOOTSTER_RAID_RUNNING_CLR.r, LOOTSTER_RAID_RUNNING_CLR.g, LOOTSTER_RAID_RUNNING_CLR.b);
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RaidFrameRaidFrameScrollFrame, count, LOOTSTER_RAIDRAID_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Raid Boss Update handle
function Lootster_Raid_Boss_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowBoss, rowDateBeg, rowAttend, rowAdjust, rowAssign, rowDKPEarnt, rowDKPSpent, clrCode;

	local	item;

	-- retrieve count of boss items
	count = #Lootster_BossSort;

	-- retrieve the scroll offset for boss view
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossFrameScrollFrame);

	-- hammer through the boss frame rows
	for row=1, LOOTSTER_RAIDBOSS_LINES, 1 do
		-- calculate actual the boss item index
		ix = row + offset;

		-- retrieve the boss row components
		rowButton	= _G["Lootster_RaidFrameBossFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the text elements
			rowBoss		= _G["Lootster_RaidFrameBossFrameButton"..row.."Boss"];
			rowDateBeg	= _G["Lootster_RaidFrameBossFrameButton"..row.."DateBeg"];
			rowAttend	= _G["Lootster_RaidFrameBossFrameButton"..row.."Attend"];
			rowAdjust	= _G["Lootster_RaidFrameBossFrameButton"..row.."Adjust"];
			rowAssign	= _G["Lootster_RaidFrameBossFrameButton"..row.."Assign"];
			rowDKPEarnt	= _G["Lootster_RaidFrameBossFrameButton"..row.."DKPEarnt"];
			rowDKPSpent	= _G["Lootster_RaidFrameBossFrameButton"..row.."DKPSpent"];

			-- okay, retrieve the boss item
			item = Lootster_Boss[Lootster_BossSort[ix]];

			-- format the requisite data and stuff into the text elements
			rowBoss:SetText(Lootster_FormatBoss(item.Boss, item.Attempt));
			rowDateBeg:SetText(Lootster_FormatServerTime(item.DateBeg));
			rowAttend:SetText(item.AttendN);
			rowAdjust:SetText(item.AdjustN);
			
			-- is the count of assignments outstanding zero?
			if (item.AssignN ~= 0) then
				-- set as outstanding
				clrCode = LOOTSTER_RAID_ASSIGNS_CLR_CODE;
			else
				-- set as normal
				clrCode = LOOTSTER_RAID_NOASSIGNS_CLR_CODE;
			end
			
			rowAssign:SetText(clrCode..item.AssignN.."|r");

			-- show DKP if in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				rowDKPEarnt:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_SumDKPEarntUpdate(item));
				rowDKPSpent:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_SumDKPSpentUpdate(item));
			else
				rowDKPEarnt:SetText("");
				rowDKPSpent:SetText("");
			end

			-- is this the current boss?
			if (item.Id == Lootster_BossId) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- is this the running boss?
			if (item.Id ~= Lootster_Running.BossId) then
				-- set as normal
				rowBoss:SetVertexColor(LOOTSTER_RAID_NORMAL_CLR.r, LOOTSTER_RAID_NORMAL_CLR.g, LOOTSTER_RAID_NORMAL_CLR.b);
			else
				-- set as running
				rowBoss:SetVertexColor(LOOTSTER_RAID_RUNNING_CLR.r, LOOTSTER_RAID_RUNNING_CLR.g, LOOTSTER_RAID_RUNNING_CLR.b);
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RaidFrameBossFrameScrollFrame, count, LOOTSTER_RAIDBOSS_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Raid Attend Update handler
function Lootster_Raid_Attend_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowPlayer, rowToon, rowAttended, rowDKPAttEarnt, rowDKPAdjEarnt, rowDKPAdjSpent;

	local	item;

	-- retrieve count of attend items
	count = #Lootster_BossAttendSort;

	-- retrieve the scroll offset for attend view
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAttendFrameScrollFrame);

	-- hammer through the attend frame rows
	for row=1, LOOTSTER_BOSSATTEND_LINES, 1 do
		-- calculate actual the attend item index
		ix = row + offset;

		-- retrieve the attend row components
		rowButton	= _G["Lootster_RaidFrameBossAttendFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the text elements
			rowPlayer		= _G["Lootster_RaidFrameBossAttendFrameButton"..row.."Player"];
			rowToon			= _G["Lootster_RaidFrameBossAttendFrameButton"..row.."Toon"];
			rowAttended		= _G["Lootster_RaidFrameBossAttendFrameButton"..row.."Attended"];
			rowDKPAttEarnt	= _G["Lootster_RaidFrameBossAttendFrameButton"..row.."DKPAttEarnt"];
			rowDKPAdjEarnt	= _G["Lootster_RaidFrameBossAttendFrameButton"..row.."DKPAdjEarnt"];
			rowDKPAdjSpent	= _G["Lootster_RaidFrameBossAttendFrameButton"..row.."DKPAdjSpent"];

			-- okay, retrieve the attend item
			item = Lootster_Attend[Lootster_BossAttendSort[ix]];

			-- format the requisiste data and stuff into the text elements.  Note we use alt as player as appropriate
			rowPlayer:SetText(Lootster_GetMainAlt(item.Player));

			-- determine toon type
			if (item.Player == Lootster_GetMainAlt(item.Player)) then
				-- main
				rowToon:SetText(LOOTSTER_TOON_LIST[LOOTSTER_ENUM_TOON.MAIN]);
			else
				-- alt
				rowToon:SetText(LOOTSTER_TOON_LIST[LOOTSTER_ENUM_TOON.ALT]);
			end

			rowAttended:SetText(LOOTSTER_ATTENDED_LIST[item.Attended]);

			-- show DKP if in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				rowDKPAttEarnt:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAttEarnt);
				rowDKPAdjEarnt:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjEarnt);
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjSpent);
			else
				rowDKPAttEarnt:SetText("");
				rowDKPAdjEarnt:SetText("");
				rowDKPAdjSpent:SetText("");
			end

			-- is this the current attendance?
			if (item.Id == Lootster_AttendId) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RaidFrameBossAttendFrameScrollFrame, count, LOOTSTER_BOSSATTEND_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Raid Adjust Update handler
function Lootster_Raid_Adjust_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowPlayer, DKPAdjEarnt, DKPAdjSpent, rowReason;

	local	item;

	-- retrieve count of adjust items
	count = #Lootster_BossAdjustSort;

	-- retrieve the scroll offset for adjust view
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAdjustFrameScrollFrame);

	-- hammer through the adjust frame rows
	for row=1, LOOTSTER_BOSSADJUST_LINES, 1 do
		-- calculate actual the adjust item index
		ix = row + offset;

		-- retrieve the adjust row components
		rowButton	= _G["Lootster_RaidFrameBossAdjustFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the text elements
			rowPlayer		= _G["Lootster_RaidFrameBossAdjustFrameButton"..row.."Player"];
			rowDKPAdjEarnt	= _G["Lootster_RaidFrameBossAdjustFrameButton"..row.."DKPAdjEarnt"];
			rowDKPAdjSpent	= _G["Lootster_RaidFrameBossAdjustFrameButton"..row.."DKPAdjSpent"];
			rowReason		= _G["Lootster_RaidFrameBossAdjustFrameButton"..row.."Reason"];

			-- okay, retrieve the adjust item
			item = Lootster_Adjust[Lootster_BossAdjustSort[ix]];

			-- format the requisiste data and stuff into the text elements.  Note we use alt as player as appropriate
			rowPlayer:SetText(Lootster_GetMainAlt(item.Player));

			-- show DKP if in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				rowDKPAdjEarnt:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjEarnt);
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjSpent);
			else
				rowDKPAdjEarnt:SetText("");
				rowDKPAdjSpent:SetText("");
			end

			-- if we have a link, use it instead
			if (item.Link ~= nil) then
				rowReason:SetText(item.Link);
			else
				rowReason:SetText(item.Reason);
			end

			-- is this the current adjustment?
			if (item.Id == Lootster_AdjustId) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RaidFrameBossAdjustFrameScrollFrame, count, LOOTSTER_BOSSADJUST_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Raid Assign Update handler
function Lootster_Raid_Assign_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowPlayer, rowUsage, DKPAdjSpent, rowReason;

	local	item;

	-- retrieve count of assign items
	count = #Lootster_BossAssignSort;

	-- retrieve the scroll offset for assign view
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameBossAssignFrameScrollFrame);

	-- hammer through the assign frame rows
	for row=1, LOOTSTER_BOSSASSIGN_LINES, 1 do
		-- calculate actual the assign item index
		ix = row + offset;

		-- retrieve the assign row components
		rowButton	= _G["Lootster_RaidFrameBossAssignFrameButton"..row];
		
		-- do we have data for the row?
		if (ix <= count) then
			-- get the text elements
			rowPlayer		= _G["Lootster_RaidFrameBossAssignFrameButton"..row.."Player"];
			rowUsage		= _G["Lootster_RaidFrameBossAssignFrameButton"..row.."Usage"];
			rowDKPAdjSpent	= _G["Lootster_RaidFrameBossAssignFrameButton"..row.."DKPAdjSpent"];
			rowReason		= _G["Lootster_RaidFrameBossAssignFrameButton"..row.."Reason"];

			-- okay, retrieve the adjust item
			item = Lootster_Adjust[Lootster_BossAssignSort[ix]];

			-- format the requisiste data and stuff into the text elements.  Note we use alt as player as appropriate
			rowPlayer:SetText(Lootster_GetMainAlt(item.Player));
			rowUsage:SetText(LOOTSTER_USAGEDKP_LIST[item.Usage]);

			-- show DKP if in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				rowDKPAdjSpent:SetFormattedText(LOOTSTER_COST_POINTS, item.DKPAdjSpent);
			else
				rowDKPAdjSpent:SetText("");
			end

			-- we should always have a link
			rowReason:SetText(item.Link);

			-- is this the current assignment?
			if (item.Id == Lootster_AssignId) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RaidFrameBossAssignFrameScrollFrame, count, LOOTSTER_BOSSASSIGN_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Item Update handler
function Lootster_Item_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowIcon, rowText, rowClass;
	local	_, itemName, isCached, itemLink, itemQual, itemName, itemTex;
	local	item, cix, classes, class;
	
	-- retrieve count of restrict items
	count = #Lootster_ItemSort;

	-- retrieve the scroll offset for item view
	offset = FauxScrollFrame_GetOffset(Lootster_ItemFrameScrollFrame);

	-- hammer through the item frame rows
	for row=1, LOOTSTER_OPTIONITEM_LINES, 1 do
		-- calculate actual the restrict item index
		ix = row + offset;

		-- retrieve the item row components
		rowButton	= _G["Lootster_ItemFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowIcon	= _G["Lootster_ItemFrameButton"..row.."Icon"];
			rowText	= _G["Lootster_ItemFrameButton"..row.."Text"];

			-- retrieve item id
			id = Lootster_ItemSort[ix];

			-- retrieve the item
			item = Lootster_Restrict[id];

			-- retrieve the link for this guy (may be fake if uncached)
			isCached, itemLink = Lootster_GetItemLink(id, item.Text);

			if (isCached == true) then
				-- okay, retrieve the restricted item details
				itemName, itemLink, itemQual, _, _, _, _, _, _, itemTex = GetItemInfo(itemLink);
			else
				-- item not in cache
				itemName = nil;
			end

			-- handle uncached data
			if (itemName == nil) then
				-- not cached, so just use remembered name
				rowIcon:SetTexture("Interface\\InventoryItems\\WoWUnknownItem01");
				rowText:SetFormattedText(LOOTSTER_ITEMLINK_UNCACHED, item.Text);
			else
				-- format the requisiste data and stuff into the display elements
				rowIcon:SetTexture(itemTex);
				rowText:SetText(itemLink);
			end

			-- gather item classes
			classes = {};

			for cix, class in ipairs(item.Classes) do
				classes[class] = true;
			end

			-- go through each class to reveal restriction
			for cix, class in ipairs(LOOTSTER_CLASS_SORT) do
				-- get this class check box
				rowClass = _G["Lootster_ItemFrameButton"..row.."Class"..cix];

				-- set state appropriately
				rowClass:SetChecked(classes[class] == true);
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_ItemFrameScrollFrame, count, LOOTSTER_OPTIONITEM_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Rank Update handler
function Lootster_Rank_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowFull, rowTrial, rowApp, rowAlt;
	local	rank;

	-- retrieve count of ranks
	count = #Lootster_RankSort;

	-- retrieve the scroll offset for rank view
	offset = FauxScrollFrame_GetOffset(Lootster_RankFrameScrollFrame);

	-- hammer through the rank frame rows
	for row=1, LOOTSTER_OPTIONRANK_LINES, 1 do
		-- calculate actual the restrict rank index
		ix = row + offset;

		-- retrieve the rank row components
		rowButton	= _G["Lootster_RankFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowName	= _G["Lootster_RankFrameButton"..row.."Name"];
			rowFull	= _G["Lootster_RankFrameButton"..row.."Full"];
			rowTrial= _G["Lootster_RankFrameButton"..row.."Trial"];
			rowApp	= _G["Lootster_RankFrameButton"..row.."App"];
			rowAlt	= _G["Lootster_RankFrameButton"..row.."Alt"];

			-- retrieve rank id
			id = Lootster_RankSort[ix];

			-- retrieve the rank
			rank = Lootster_Options.Ranks[Lootster_SelfGuild][id];

			-- update the rank name
			rowName:SetText(rank.Name);

			-- update the membership state
			rowFull:SetChecked(rank.Member == LOOTSTER_ENUM_MEMBER.FULL);
			rowTrial:SetChecked(rank.Member == LOOTSTER_ENUM_MEMBER.TRIAL);
			rowApp:SetChecked(rank.Member == LOOTSTER_ENUM_MEMBER.APP);

			-- update the toon state
			rowAlt:SetChecked(rank.Toon == LOOTSTER_ENUM_TOON.ALT);

			-- the generic ranks can never be an alt
			if (rank.Index < LOOTSTER_RANK_GM) then
				-- generic rank - can never be an alt (no main/alt information available)
				rowAlt:Hide();
			else
				-- guild rank - can be an alt
				rowAlt:Show();
			end

			-- if we are in roll mode, disable state controls
			if ((Lootster_NBG ~= nil) or (Lootster_Tied == true)) then
				-- disable ability to toggle member and toon states
				rowFull:Disable();
				rowTrial:Disable();
				rowApp:Disable();

				rowAlt:Disable();
			else
				-- enable ability to toggle member and toon states
				rowFull:Enable();
				rowTrial:Enable();
				rowApp:Enable();

				rowAlt:Enable();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RankFrameScrollFrame, count, LOOTSTER_OPTIONRANK_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Usage Update handler
function Lootster_Usage_Update(sel)
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowUseUsage, rowRollCmd, rowAltFactor, rowByValue, rowCostValue, rowByFactor, rowCostFactor, rowWins, rowWinsPerRaid, id;

	-- retrieve count of usages
	count = #Lootster_Options.Usage;

	-- retrieve the scroll offset for usage view
	offset = FauxScrollFrame_GetOffset(Lootster_UsageFrameScrollFrame);

	-- hammer through the usage frame rows
	for row=1, LOOTSTER_OPTIONUSAGE_LINES, 1 do
		-- calculate actual usage index
		ix = row + offset;

		-- retrieve the usage row components
		rowButton	= _G["Lootster_UsageFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowName			= _G["Lootster_UsageFrameButton"..row.."Name"];
			rowUseUsage		= _G["Lootster_UsageFrameButton"..row.."UseUsage"];
			rowRollCmd		= _G["Lootster_UsageFrameButton"..row.."RollCmd"];
			rowAltFactor	= _G["Lootster_UsageFrameButton"..row.."AltFactor"];
			rowByValue		= _G["Lootster_UsageFrameButton"..row.."ByValue"];
			rowCostValue	= _G["Lootster_UsageFrameButton"..row.."CostValue"];
			rowByFactor		= _G["Lootster_UsageFrameButton"..row.."ByFactor"];
			rowCostFactor	= _G["Lootster_UsageFrameButton"..row.."CostFactor"];
			rowWins			= _G["Lootster_UsageFrameButton"..row.."Wins"];
			rowWinsPerRaid	= _G["Lootster_UsageFrameButton"..row.."WinsPerRaid"];

			-- retrieve usage enum
			id = Lootster_Options.UsageSort[ix];

			-- set usage name 
			rowName:SetText(LOOTSTER_USAGEDKP_LIST[id]);

			-- update the usage use
			rowUseUsage:SetChecked(Lootster_Options.Usage[id].Use == true);
			
			-- update the roll command
			rowRollCmd:SetText(string.format(LOOTSTER_OPTION_ROLLCMD_TT, Lootster_Options.Usage[id].Roll));

			-- update alt factor
			rowAltFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Usage[id].aFactor));
			
			-- update the value use
			rowByValue:SetChecked(Lootster_Options.Usage[id].Cost == LOOTSTER_ENUM_USAGECOST.VALUE);
			rowCostValue:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Usage[id].cValue));

			-- update the factor use
			rowByFactor:SetChecked(Lootster_Options.Usage[id].Cost == LOOTSTER_ENUM_USAGECOST.FACTOR);
			rowCostFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Usage[id].cFactor));
			
			-- update the wins per raid use.  Use infinity symbol if not used
			rowWins:SetChecked(Lootster_Options.Usage[id].Wins == true);
			
			if (Lootster_Options.Usage[id].Wins == true) then
				rowWinsPerRaid:SetText(Lootster_Options.Usage[id].WinsPerRaid);
			else
				rowWinsPerRaid:SetText(LOOTSTER_OPTION_WINSPERRAIDINF);
			end
			
			-- if we are in roll mode, disable state controls
			if ((Lootster_NBG ~= nil) or (Lootster_Tied == true)) then
				-- disable use usage checkbox, by value or factor and wins radio buttons
				rowUseUsage:Disable();
				rowByValue:Disable();
				rowByFactor:Disable();
				rowWins:Disable();
			else
				-- enable use usage checkbox, by value or factor and wins radio buttons
				rowUseUsage:Enable();
				rowByValue:Enable();
				rowByFactor:Enable();
				rowWins:Enable();
			end
			
			-- is this the current usage?
			if (id == Lootster_UsageSel) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end
			
			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
		
		-- if this guy is the passed selected usage?
		if (id == sel) then
			-- cause him to be reselected
			Lootster_Usage_Button_OnClick(rowButton);
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_UsageFrameScrollFrame, count, LOOTSTER_OPTIONUSAGE_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Event Update handler
function Lootster_Event_Update(sel)
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowUse10, rowDKP10, rowPartial10, rowStandby10, rowUse25, rowDKP25, rowPartial25, rowStandby25, name;

	-- retrieve count of events
	count = #Lootster_Options.Event;

	-- retrieve the scroll offset for event view
	offset = FauxScrollFrame_GetOffset(Lootster_EventFrameScrollFrame);

	-- hammer through the event frame rows
	for row=1, LOOTSTER_OPTIONEVENT_LINES, 1 do
		-- calculate actual event index
		ix = row + offset;

		-- retrieve the event row components
		rowButton	= _G["Lootster_EventFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowName			= _G["Lootster_EventFrameButton"..row.."Name"];
			rowUse10		= _G["Lootster_EventFrameButton"..row.."Use10"];
			rowDKP10		= _G["Lootster_EventFrameButton"..row.."DKP10"];
			rowPartial10	= _G["Lootster_EventFrameButton"..row.."Partial10"];
			rowStandby10	= _G["Lootster_EventFrameButton"..row.."Standby10"];
			rowUse25		= _G["Lootster_EventFrameButton"..row.."Use25"];
			rowDKP25		= _G["Lootster_EventFrameButton"..row.."DKP25"];
			rowPartial25	= _G["Lootster_EventFrameButton"..row.."Partial25"];
			rowStandby25	= _G["Lootster_EventFrameButton"..row.."Standby25"];

			-- update the event name.  Add name flavour as required
			name = LOOTSTER_EVENT_LIST[ix];
			
			if (Lootster_Options.Event[ix].Time ~= nil) then
				-- add event flavour
				name = name..string.format(LOOTSTER_EVENTNAME_LIST[ix], Lootster_Options.Event[ix].Time);
			end
			
			rowName:SetText(name);

			-- update the 10 man use
			rowUse10:SetChecked(Lootster_Options.Event[ix].Use10 == true);
			
			-- update the quality factor and bias
			rowDKP10:SetText(Lootster_Options.Event[ix].DKP10);
			rowPartial10:SetText(Lootster_Options.Event[ix].Partial10);
			rowStandby10:SetText(Lootster_Options.Event[ix].Standby10);

			-- update the 25 man use
			rowUse25:SetChecked(Lootster_Options.Event[ix].Use25 == true);
			
			-- update the quality factor and bias
			rowDKP25:SetText(Lootster_Options.Event[ix].DKP25);
			rowPartial25:SetText(Lootster_Options.Event[ix].Partial25);
			rowStandby25:SetText(Lootster_Options.Event[ix].Standby25);
			
			-- is this the current event?
			if (ix == Lootster_EventSel) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end
			
			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
		
		-- if this guy is the passed selected event?
		if (ix == sel) then
			-- cause him to be reselected
			Lootster_Event_Button_OnClick(rowButton);
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_EventFrameScrollFrame, count, LOOTSTER_OPTIONEVENT_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Quality Update handler
function Lootster_Quality_Update(sel)
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowUseQuality, rowqFactor, rowqBias;

	-- retrieve count of item qualities
	count = #Lootster_Options.Quality;

	-- retrieve the scroll offset for quality view
	offset = FauxScrollFrame_GetOffset(Lootster_QualityFrameScrollFrame);

	-- hammer through the quality frame rows
	for row=1, LOOTSTER_OPTIONQUALITY_LINES, 1 do
		-- calculate actual the quality index and adjust for minimum loot quality we handle
		ix = row + offset + LOOTSTER_ENUM_LOOTMODE.UNCOMMON - 1;

		-- retrieve the quality row components
		rowButton	= _G["Lootster_QualityFrameButton"..row];

		-- do we have data for the row?
		if (Lootster_Options.Quality[ix] ~= nil) then
			-- get the display elements
			rowName			= _G["Lootster_QualityFrameButton"..row.."qName"];
			rowUseQuality	= _G["Lootster_QualityFrameButton"..row.."UseQuality"];
			rowqFactor		= _G["Lootster_QualityFrameButton"..row.."qFactor"];
			rowqBias		= _G["Lootster_QualityFrameButton"..row.."qBias"];

			-- update the quality name
			rowName:SetText(ITEM_QUALITY_COLORS[ix].hex.._G["ITEM_QUALITY"..ix.."_DESC"]..FONT_COLOR_CODE_CLOSE);

			-- update the quality use
			rowUseQuality:SetChecked(Lootster_Options.Quality[ix].Active == true);
			
			-- update the quality factor and bias
			rowqFactor:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_Options.Quality[ix].qFactor);
			rowqBias:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_Options.Quality[ix].qBias);

			-- if we are in roll mode, disable state controls
			if ((Lootster_NBG ~= nil) or (Lootster_Tied == true)) then
				-- disable ability to toggle use states
				rowUseQuality:Disable();
			else
				-- enable ability to toggle use states
				rowUseQuality:Enable();
			end

			-- is this the current quality?
			if (ix == Lootster_QualitySel) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
		
		-- if this guy is the passed selected item quality?
		if (ix == sel) then
			-- cause him to be reselected
			Lootster_Quality_Button_OnClick(rowButton);
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_QualityFrameScrollFrame, count, LOOTSTER_OPTIONQUALITY_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Slot Update handler
function Lootster_Slot_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowsFactor;

	-- retrieve count of item slots
	count = #Lootster_Options.Slot;

	-- retrieve the scroll offset for quality view
	offset = FauxScrollFrame_GetOffset(Lootster_SlotFrameScrollFrame);

	-- hammer through the quality frame rows
	for row=1, LOOTSTER_OPTIONSLOT_LINES, 1 do
		-- calculate actual the slot index
		ix = row + offset;

		-- retrieve the slot row components
		rowButton	= _G["Lootster_SlotFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowName			= _G["Lootster_SlotFrameButton"..row.."sName"];
			rowsFactor		= _G["Lootster_SlotFrameButton"..row.."sFactor"];

			-- update the slot name
			rowName:SetText(_G["LOOTSTER_OPTION_SFACTOR"..ix]);

			-- update the slot factor
			rowsFactor:SetFormattedText(LOOTSTER_COST_POINTS, Lootster_Options.Slot[ix]);

			-- is this the current slot?
			if (ix == Lootster_SlotSel) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
		
		-- if this guy is the passed selected item slot?
		if (ix == sel) then
			-- cause him to be reselected
			Lootster_Slot_Button_OnClick(rowButton);
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_SlotFrameScrollFrame, count, LOOTSTER_OPTIONSLOT_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Raid Adjust Player Update handler
function Lootster_RaidAdjust_Update()
	local	count;
	local	offset;
	local	row, ix;

	local	rowButton, rowName, rowUsage;

	-- we need an adjustment record with a player won list
	if ((Lootster_AdjustRec ~= nil) and (Lootster_AdjustRec.Won ~= nil)) then
		-- retrieve count of players
		count = #Lootster_AdjustRec.Won;
	else
		-- no assignees
		count = 0;
	end

	-- retrieve the scroll offset for player view
	offset = FauxScrollFrame_GetOffset(Lootster_RaidFrameAdjustFrameAssignScrollFrame);

	-- hammer through the raid adjust player frame rows
	for row=1, LOOTSTER_RAIDADJUST_LINES, 1 do
		-- calculate actual the raid adjust player index
		ix = row + offset;

		-- retrieve the raid adjust player row components
		rowButton	= _G["Lootster_RaidFrameAdjustFrameButton"..row];

		-- do we have data for the row?
		if (ix <= count) then
			-- get the display elements
			rowName		= _G["Lootster_RaidFrameAdjustFrameButton"..row.."Name"];
			rowUsage	= _G["Lootster_RaidFrameAdjustFrameButton"..row.."Usage"];

			-- set player name but as the alt
			rowName:SetText(Lootster_GetMainAlt(Lootster_AdjustRec.Won[ix].Player));
			rowUsage:SetText(LOOTSTER_USAGEDKP_LIST[Lootster_AdjustRec.Won[ix].Usage]);

			-- is this the current assignee?
			if (ix == Lootster_AdjustRec.PlayerIx) then
				-- highlight the row
				rowButton:LockHighlight();
			else
				-- normalise the row
				rowButton:UnlockHighlight();
			end

			-- and show the row
			rowButton:Show();
		else
			-- hide this row
			rowButton:Hide();
		end
	end

	-- update the scroll frame appropriately
	FauxScrollFrame_Update(Lootster_RaidFrameAdjustFrameAssignScrollFrame, count, LOOTSTER_RAIDADJUST_LINES, LOOTSTER_FRAME_HEIGHT);
end

-- Show Help handler
function Lootster_Rule_ShowHelp_OnClick(self, button, player)
	local	ix, msg;
	
	-- output the help to party/raid/player
	for ix, msg in ipairs(LOOTSTER_HELP) do
		-- punching this out to the party/raid?
		if (player == nil) then
			-- party/raid
			Lootster_SendBroadcast(msg);
		else
			-- player
			Lootster_SendPrivate(player, msg);
		end
	end

	-- is DKP in use?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		local	helpList;
		
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- EPGP
			helpList = LOOTSTER_HELPEPGP;
		else
			-- DKP
			helpList = LOOTSTER_HELPDKP;
		end
		
		-- output the help to party/raid/player
		for ix, msg in ipairs(helpList) do
			-- punching this out to the party/raid?
			if (player == nil) then
				-- party/raid
				Lootster_SendBroadcast(msg);
			else
				-- player
				Lootster_SendPrivate(player, msg);
			end
		end
	end
end

-- Show Rules handler
function Lootster_Rule_ShowRules_OnClick(self, button, player)
	local ix = 1;
	local rules, msg;

	-- determine which rule set to use
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		rules = Lootster_Rules.RulesDKP;
	else
		rules = Lootster_Rules.RulesNorm;
	end

	-- chop the looting rules up according to line ends if we have text
	if (rules ~= "\n") then
		for msg in string.gmatch(rules, "(.-)\n") do
			-- punching this out to the party/raid?
			if (player == nil) then
				-- party/raid
				Lootster_SendBroadcast(msg);
			else
				-- player
				Lootster_SendPrivate(player, msg);
			end
		end
	end
	
	-- get the roll handling message
	msg = Lootster_GetRollHandling();

	-- punching this out to the party/raid?
	if (player == nil) then
		-- party/raid
		Lootster_SendBroadcast(msg);
	else
		-- player
		Lootster_SendPrivate(player, msg);
	end
end

-- Looting Rules Text Entered handler
function Lootster_Rule_Rules_OnTextChanged(self)
	local	rules;

	-- snarf rules
	rules = Lootster_AppendTrailingLineBreak(Lootster_RuleFrameRulesFrameText:GetText());

	-- determine which rule set to set
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		Lootster_Rules.RulesDKP = rules;
	else
		Lootster_Rules.RulesNorm = rules;
	end
end

-- Show Usage Rolls handler
function Lootster_Rule_ShowUsage_OnClick(self, button, player)
	local	ix, usage;
	
	-- punching this out to the party/raid?
	if (player == nil) then
		-- party/raid
		Lootster_SendBroadcast(LOOTSTER_ECHO_USAGEROLLS);
	else
		-- player
		Lootster_SendPrivate(player, LOOTSTER_ECHO_USAGEROLLS);
	end
	
	for ix, usage in ipairs(Lootster_Options.UsageSort) do
		-- usage enabled?
		if (Lootster_Options.Usage[usage].Use == true) then
			-- punching this out to the party/raid?
			if (player == nil) then
				-- party/raid
				Lootster_SendBroadcast(string.format(LOOTSTER_ECHO_USAGEROLLCMD, Lootster_Options.Usage[usage].Roll, LOOTSTER_USAGEDKP_LIST[usage]));
			else
				-- player
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_USAGEROLLCMD, Lootster_Options.Usage[usage].Roll, LOOTSTER_USAGEDKP_LIST[usage]));
			end
		end
	end
end

-- Option Tab Toggle handler
function Lootster_Option_Tab_OnToggle(self)
	local	tab;
	
	-- show/hide the respective tab frames
	for tab= 1, LOOTSTER_OPTION_TABS, 1 do
		-- is this ourself?
		if (tab == self:GetID()) then
			-- show this tab frame
			_G["Lootster_OptionsFrameTab"..tab]:Show();
		else
			-- hide this tab frame
			_G["Lootster_OptionsFrameTab"..tab]:Hide();
		end
	end
end

-- Option MiniMap Button Toggle handler
function Lootster_Option_MiniMapButton_OnToggle(self)
	-- retrieve value
	Lootster_Options.MiniMap = (Lootster_OptionsFrameMiniMapButton:GetChecked() ~= nil);

	-- and show/hide the actual button
	if (Lootster_Options.MiniMap == true) then
		-- on she goes
		PlaySound("igMainMenuOptionCheckBoxOn");

	else
		-- off she goes
		PlaySound("igMainMenuOptionCheckBoxOff");
	end

	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState();
end

-- Option MiniMap Button Value handler
function Lootster_Option_MiniMapButton_OnValueChanged(self)
	-- retrieve value
	Lootster_Options.MiniMapPos = Lootster_OptionsFrameMiniMapSlider:GetValue();

	-- update slidertext
	Lootster_OptionsFrameMiniMapSliderText:SetText(Lootster_Options.MiniMapPos);

	-- reflect the position
	Lootster_MiniMapButton_UpdatePosition();
end

-- Option Reset UI Click handler
function Lootster_Option_ResetUI_OnClick(self, button)
	-- reset UI the user has lost the windows off the screen.  Reset the anchors to center
	Lootster_Title:ClearAllPoints();
	Lootster_Title:SetPoint("CENTER");

	Lootster_RaidFrameRaidFrame:ClearAllPoints();
	Lootster_RaidFrameRaidFrame:SetPoint("CENTER");
	Lootster_RaidFrameBossFrame:ClearAllPoints();
	Lootster_RaidFrameBossFrame:SetPoint("CENTER");
	Lootster_RaidFrameAttendFrame:ClearAllPoints();
	Lootster_RaidFrameAttendFrame:SetPoint("CENTER");
	Lootster_RaidFrameAdjustFrame:ClearAllPoints();
	Lootster_RaidFrameAdjustFrame:SetPoint("CENTER");

	Lootster_RaidFrameReportFrame:ClearAllPoints();
	Lootster_RaidFrameReportFrame:SetPoint("CENTER");

	Lootster_RaidSyncFrame:ClearAllPoints();
	Lootster_RaidSyncFrame:SetPoint("CENTER");
	Lootster_ItemSyncFrame:ClearAllPoints();
	Lootster_ItemSyncFrame:SetPoint("CENTER");

	Lootster_DebuggingFrame:ClearAllPoints();
	Lootster_DebuggingFrame:SetPoint("CENTER");
end

-- Option Debugging Click handler
function Lootster_Option_Debugging_OnClick(self, button)
	-- show the debugging window
	Lootster_DebuggingFrame:Show();
end

-- Option Suppress Chat Toggle handler
function Lootster_Option_Suppress_OnToggle(self)
	-- retrieve value
	Lootster_Options.Suppress = (Lootster_OptionsFrameSuppress:GetChecked() ~= nil);
end

-- Option Raid Warning Roll Toggle handler
function Lootster_Option_RWRoll_OnToggle(self)
	-- retrieve value
	Lootster_Options.RWRoll = (Lootster_OptionsFrameRWRoll:GetChecked() ~= nil);
end

-- -- Option Raid Warning By Click handler
function Lootster_Option_RaidWarn_RadioButton_OnClick(self, button, index)
	-- snarf index
	Lootster_Options.RWRollBy = index;
	
	-- determine the raid warning roll by button
	Lootster_OptionsFrameRWAll:SetChecked(Lootster_Options.RWRollBy == LOOTSTER_ENUM_RAIDWARN.ALL);
	Lootster_OptionsFrameRWCall:SetChecked(Lootster_Options.RWRollBy == LOOTSTER_ENUM_RAIDWARN.CALL);
	
	-- play sound if selected
	if (index ~= nil) then
		PlaySound("igMainMenuOptionCheckBoxOn");
	end
end

-- Option Acknowledge Roll Toggle handler
function Lootster_Option_AckRoll_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckRoll = (Lootster_OptionsFrameAckRoll:GetChecked() ~= nil);
end

-- Option Acknowledge DKP Information Toggle handler
function Lootster_Option_AckNoInfo_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoInfo = (Lootster_OptionsFrameAckNoInfo:GetChecked() ~= nil);
end

-- Option Acknowledge No Call Toggle handler
function Lootster_Option_AckNoCall_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoCall = (Lootster_OptionsFrameAckNoCall:GetChecked() ~= nil);
end

-- Option Acknowledge No Roll Toggle handler
function Lootster_Option_AckNoRoll_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoRoll = (Lootster_OptionsFrameAckNoRoll:GetChecked() ~= nil);
end

-- Option Acknowledge No Help Toggle handler
function Lootster_Option_AckNoHelp_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoHelp = (Lootster_OptionsFrameAckNoHelp:GetChecked() ~= nil);
end

-- Option Acknowledge No Raid Toggle handler
function Lootster_Option_AckNoRaid_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoRaid = (Lootster_OptionsFrameAckNoRaid:GetChecked() ~= nil);
end

-- Option Acknowledge No Boss Toggle handler
function Lootster_Option_AckNoBoss_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoBoss = (Lootster_OptionsFrameAckNoBoss:GetChecked() ~= nil);
end

-- Option Acknowledge No Attendance Toggle handler
function Lootster_Option_AckNoAtt_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoAtt = (Lootster_OptionsFrameAckNoAtt:GetChecked() ~= nil);
end

-- Option Acknowledge No Adjustment Toggle handler
function Lootster_Option_AckNoAdj_OnToggle(self)
	-- retrieve value
	Lootster_Options.AckNoAdj = (Lootster_OptionsFrameAckNoAdj:GetChecked() ~= nil);
end

-- Option Counter Toggle handler
function Lootster_Option_Counter_OnToggle(self)
	-- retrieve value
	Lootster_Options.Counter = (Lootster_OptionsFrameCounter:GetChecked() ~= nil);

	-- update the countdown button
	Lootster_UpdateRollUI();
end

-- Option Counter Focus Gained handler
function Lootster_Option_Counter_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option Counter Entered handler
function Lootster_Option_Counter_OnTextChanged(self)
end

-- Option Slot Factor Focus Lost handler
function Lootster_Option_Counter_OnFocusLost(self)
	-- retrieve value
	Lootster_Options.CounterSec = Lootster_OptionsFrameSeconds:GetNumber();

	-- must be positive
	if (Lootster_Options.CounterSec < 0) then
		Lootster_Options.CounterSec = -Lootster_Options.CounterSec;
	end

	-- update
	Lootster_OptionsFrameSeconds:SetNumber(Lootster_Options.CounterSec);

	-- update the countdown button
	Lootster_UpdateRollUI();
end

-- Option Echo Restrictions Toggle handler
function Lootster_Option_EchoRestrict_OnToggle(self)
	-- retrieve value
	Lootster_Options.EchoRestrict = (Lootster_OptionsFrameEchoRestrict:GetChecked() ~= nil);

	-- update echo UI
	Lootster_CheckEchoUse();
end

-- Option Echo By Click Toggle handler
function Lootster_Option_EchoByClick_OnToggle(self)
	-- retrieve value
	Lootster_Options.EchoByClick = (Lootster_OptionsFrameEchoByClick:GetChecked() ~= nil);

	-- update echo UI
	Lootster_CheckEchoUse();
end

-- Option Echo By Group Loot Toggle handler
function Lootster_Option_EchoByGroupLoot_OnToggle(self)
	-- retrieve value
	Lootster_Options.EchoByGroupLoot = (Lootster_OptionsFrameEchoByGroupLoot:GetChecked() ~= nil);

	-- update echo UI
	Lootster_CheckEchoUse();
end

-- Option Echo to Chat Toggle handler
function Lootster_Option_EchoToChat_OnToggle(self)
	-- retrieve value
	Lootster_Options.EchoToChat = (Lootster_OptionsFrameEchoToChat:GetChecked() ~= nil);
end

-- Option Echo to Raid Warning Toggle handler
function Lootster_Option_EchoToRW_OnToggle(self)
	-- retrieve value
	Lootster_Options.EchoToRW = (Lootster_OptionsFrameEchoToRW:GetChecked() ~= nil);
end

-- Option Auto-Snoop Toggle handler
function Lootster_Option_AutoSnoop_OnToggle(self)
	-- retrieve value
	Lootster_Options.AutoSnoop = (Lootster_OptionsFrameAutoSnoop:GetChecked() ~= nil);
end

-- Option Debug Messages Chat Toggle handler
function Lootster_Option_DebugMsgs_OnToggle(self)
	-- retrieve value
	Lootster_Options.DebugMsgs = (Lootster_OptionsFrameDebugMsgs:GetChecked() ~= nil);

	-- if we are switching on debug messages, clear the From Whisper queue
	if (Lootster_Options.DebugMsgs) then
		Lootster_FromWhisperQue = nil;
	end
end

-- Option Roll Mode Load handler
function Lootster_Option_RollMode_OnLoad(self)
	-- initially disable
	Lootster_OptionsFrameRollModeButton:Disable();

	-- set width
	UIDropDownMenu_SetWidth(self, 175);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Option Roll Mode Show handler
function Lootster_Option_RollMode_OnShow(self)
	-- setup the roll mode drop down
	UIDropDownMenu_Initialize(Lootster_OptionsFrameRollMode, Lootster_Option_RollMode_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedID(Lootster_OptionsFrameRollMode, Lootster_Options.RollMode);
end

-- Option Roll Mode Load Initaliser handler
function Lootster_Option_RollMode_Initialise()
	local ix, type, info;

	for ix, type in ipairs(LOOTSTER_ROLLMODE_LIST) do
		-- form mode button
		info = {};
		info.text = type;
		info.func = Lootster_Option_RollMode_OnSelect;

		-- add roll mode button
		UIDropDownMenu_AddButton(info);
	end
end

-- Option Roll Mode Select handler
function Lootster_Option_RollMode_OnSelect(self)
	-- select this entry
	UIDropDownMenu_SetSelectedID(Lootster_OptionsFrameRollMode, self:GetID());

	-- and snarf new mode
	Lootster_Options.RollMode = self:GetID();

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
end

-- Option Roll Type Load handler
function Lootster_Option_RollType_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 175);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Option Roll Type Show handler
function Lootster_Option_RollType_OnShow(self)
	-- setup the roll type drop down
	UIDropDownMenu_Initialize(Lootster_OptionsFrameRollType, Lootster_Option_RollType_Initialise);

	-- set initial selection depending on mode
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- DKP type
		UIDropDownMenu_SetSelectedID(Lootster_OptionsFrameRollType, Lootster_Options.DKPType);
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- normal type
		UIDropDownMenu_SetSelectedID(Lootster_OptionsFrameRollType, Lootster_Options.NormType);
	end
end

-- Option Roll Type Load Initaliser handler
function Lootster_Option_RollType_Initialise()
	local list, ix, type, info;

	-- determine which list to use
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- DKP type
		list = LOOTSTER_DKPTYPE_LIST;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- normal type
		list = LOOTSTER_NORMTYPE_LIST;
	else
		list = {};
	end

	for ix, type in ipairs(list) do
		-- form type button
		info = {};
		info.text = type;
		info.func = Lootster_Option_RollType_OnSelect;
		
		-- massage the EPGP roll type depending on whether it is supported
		if ((info.text == LOOTSTER_DKPTYPE_LIST[LOOTSTER_ENUM_DKP.BYEPGP]) and not Lootster_IsEPGPCapable) then
			info.colorCode = RED_FONT_COLOR_CODE;
		end
		
		-- add DKP type button
		UIDropDownMenu_AddButton(info);
	end
end

-- Option Roll Type Select handler
function Lootster_Option_RollType_OnSelect(self)
	-- select this entry
	UIDropDownMenu_SetSelectedID(Lootster_OptionsFrameRollType, self:GetID());

	-- and snarf new type
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- DKP type
		Lootster_Options.DKPType = self:GetID();
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- normal type
		Lootster_Options.NormType = self:GetID();
	end

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);

	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
end

-- Option DKP Member Toggle handler
function Lootster_Option_DKPMember_OnToggle(self)
	-- retrieve value
	Lootster_Options.DKPMember = (Lootster_OptionsFrameDKPMember:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option DKP Toon Toggle handler
function Lootster_Option_DKPToon_OnToggle(self)
	-- retrieve value
	Lootster_Options.DKPToon = (Lootster_OptionsFrameDKPToon:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option DKP FFA Greed Toggle handler
function Lootster_Option_DKPGreedFFA_OnToggle(self)
	-- retrieve value
	Lootster_Options.DKPGreedFFA = (Lootster_OptionsFrameDKPGreedFFA:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option DKP Attendance Earnt Toggle handler
function Lootster_Option_DKPAttEarnt_OnToggle(self)
	-- retrieve value
	Lootster_Options.DKPAttEarnt = (Lootster_OptionsFrameDKPAttEarnt:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option DKP Caps Toggle handler
function Lootster_Option_DKPCaps_OnToggle(self)
	-- retrieve value
	Lootster_Options.DKPCaps = (Lootster_OptionsFrameDKPCaps:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option DKP Hi Cap Focus Gained handler
function Lootster_Option_DKPHi_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option DKP Hi Cap Entered handler
function Lootster_Option_DKPHi_OnTextChanged(self)
end

-- Option DKP Hi Cap Focus Lost handler
function Lootster_Option_DKPHi_OnFocusLost(self)
	-- retrieve value
	Lootster_Options.DKPHi = Lootster_OptionsFrameDKPHi:GetNumber();

	-- must be positive
	if (Lootster_Options.DKPHi < 0) then
		Lootster_Options.DKPHi = -Lootster_Options.DKPHi;
	end

	-- update
	Lootster_OptionsFrameDKPHi:SetNumber(Lootster_Options.DKPHi);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option DKP Lo Cap Focus Gained handler
function Lootster_Option_DKPLo_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option DKP Lo Cap Entered handler
function Lootster_Option_DKPLo_OnTextChanged(self)
end

-- Option DKP Lo Cap Focus Lost handler
function Lootster_Option_DKPLo_OnFocusLost(self)
	-- retrieve value
	Lootster_Options.DKPLo = Lootster_OptionsFrameDKPLo:GetNumber();

	-- must be positive
	if (Lootster_Options.DKPLo < 0) then
		Lootster_Options.DKPLo = -Lootster_Options.DKPLo;
	end

	-- update
	Lootster_OptionsFrameDKPLo:SetNumber(Lootster_Options.DKPLo);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option DKP Factoring Toggle handler
function Lootster_Option_DKPFactoring_OnToggle(self)
	-- retrieve value
	Lootster_Options.DKPFactoring = (Lootster_OptionsFrameDKPFactoring:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option DKP Factor Focus Gained handler
function Lootster_Option_DKPFactor_OnFocusGained(self)
	-- save the current value so we can detect changes
	Lootster_DKPFactorSave = Lootster_Options.DKPFactor;

	-- select the current text
	self:HighlightText();
end

-- Option DKP Factor Entered handler
function Lootster_Option_DKPFactor_OnTextChanged(self)
end

-- Option DKP Factor Focus Lost handler
function Lootster_Option_DKPFactor_OnFocusLost(self)
	-- retrieve
	Lootster_Options.DKPFactor = Lootster_OptionsFrameDKPFactor:GetNumber();

	-- must be non-nil and non-zero
	if ((Lootster_Options.DKPFactor == nil) or (Lootster_Options.DKPFactor == 0)) then
		-- restore to default
		Lootster_Options.DKPFactor = Lootster_Options_Default.DKPFactor;
	end

	-- update
	Lootster_OptionsFrameDKPFactor:SetNumber(Lootster_Options.DKPFactor);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- and reset the DKP factor
	Lootster_DKPFactorSave = nil;
end

-- Option Roll Factoring Toggle handler
function Lootster_Option_RollFactoring_OnToggle(self)
	-- retrieve value
	Lootster_Options.RollFactoring = (Lootster_OptionsFrameRollFactoring:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option Roll Factor Focus Gained handler
function Lootster_Option_RollFactor_OnFocusGained(self)
	-- save the current value so we can detect changes
	Lootster_RollFactorSave = Lootster_Options.RollFactor;

	-- select the current text
	self:HighlightText();
end

-- Option Roll Factor Entered handler
function Lootster_Option_RollFactor_OnTextChanged(self)
end

-- Option Roll Factor Focus Lost handler
function Lootster_Option_RollFactor_OnFocusLost(self)
	-- retrieve
	Lootster_Options.RollFactor = Lootster_OptionsFrameRollFactor:GetNumber();

	-- must be non-nil and non-zero
	if ((Lootster_Options.RollFactor == nil) or (Lootster_Options.RollFactor == 0)) then
		-- restore to default
		Lootster_Options.RollFactor = Lootster_Options_Default.RollFactor;
	end

	-- update
	Lootster_OptionsFrameRollFactor:SetNumber(Lootster_Options.RollFactor);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- and reset the Roll factor
	Lootster_RollFactorSave = nil;
end

-- Option EP Minimum Toggle handler
function Lootster_Option_EPMin_OnToggle(self)
	-- retrieve value
	Lootster_Options.EPMin = (Lootster_OptionsFrameEPMin:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option EP Minimum EP Focus Gained handler
function Lootster_Option_EPMinEP_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option EP Minimum EP Entered handler
function Lootster_Option_EPMinEP_OnTextChanged(self)
end

-- Option EP Minimum EP Focus Lost handler
function Lootster_Option_EPMinEP_OnFocusLost(self)
	-- retrieve
	Lootster_Options.EPMinEP = Lootster_OptionsFrameEPMinEP:GetNumber();

	-- must be non-nil and positive
	if ((Lootster_Options.EPMinEP == nil) or (Lootster_Options.EPMinEP < 0)) then
		-- restore to default
		Lootster_Options.EPMinEP = Lootster_Options_Default.EPMinEP;
	end

	-- update
	Lootster_OptionsFrameEPMinEP:SetNumber(Lootster_Options.EPMinEP);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option GP Base Toggle handler
function Lootster_Option_GPBase_OnToggle(self)
	-- retrieve value
	Lootster_Options.GPBase = (Lootster_OptionsFrameGPBase:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option GP Base GP Focus Gained handler
function Lootster_Option_GPBaseGP_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option GP Base GP Entered handler
function Lootster_Option_GPBaseGP_OnTextChanged(self)
end

-- Option GP Base GP Focus Lost handler
function Lootster_Option_GPBaseGP_OnFocusLost(self)
	-- retrieve
	Lootster_Options.GPBaseGP = Lootster_OptionsFrameGPBaseGP:GetNumber();

	-- must be non-nil and positive
	if ((Lootster_Options.GPBaseGP == nil) or (Lootster_Options.GPBaseGP < 0)) then
		-- restore to default
		Lootster_Options.GPBaseGP = Lootster_Options_Default.GPBaseGP;
	end

	-- update
	Lootster_OptionsFrameGPBaseGP:SetNumber(Lootster_Options.GPBaseGP);

	-- update roll handling
	Lootster_UpdateRollHandling();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);
end

-- Option Norm Member Toggle handler
function Lootster_Option_NormMember_OnToggle(self)
	-- retrieve value
	Lootster_Options.NormMember = (Lootster_OptionsFrameNormMember:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option Norm Toon Toggle handler
function Lootster_Option_NormToon_OnToggle(self)
	-- retrieve value
	Lootster_Options.NormToon = (Lootster_OptionsFrameNormToon:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option Norm FFA Greed Toggle handler
function Lootster_Option_NormGreedFFA_OnToggle(self)
	-- retrieve value
	Lootster_Options.NormGreedFFA = (Lootster_OptionsFrameNormGreedFFA:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option Normal Auto Roll Toggle handler
function Lootster_Option_NormAutoRoll_OnToggle(self)
	-- retrieve value
	Lootster_Options.NormAutoRoll = (Lootster_OptionsFrameNormAutoRoll:GetChecked() ~= nil);

	-- update roll handling 
	Lootster_UpdateRollHandling();
end

-- Option Normal Auto Open Toggle handler
function Lootster_Option_NormAutoOpen_OnToggle(self)
	-- retrieve value
	Lootster_Options.NormAutoOpen = (Lootster_OptionsFrameNormAutoOpen:GetChecked() ~= nil);
end

-- Option Normal Auto Close Toggle handler
function Lootster_Option_NormAutoClose_OnToggle(self)
	-- retrieve value
	Lootster_Options.NormAutoClose = (Lootster_OptionsFrameNormAutoClose:GetChecked() ~= nil);
end

-- Option Track Click handler
function Lootster_Option_Track_OnToggle(self, index)
	-- retrieve value
	Lootster_Options.Track[index] = (self:GetChecked() ~= nil);
end

-- Option Track By Click handler
function Lootster_Option_TrackBy_RadioButton_OnClick(self, button, index)
	-- snarf index
	Lootster_Options.TrackBy = index;
	
	-- determine the attendance button
	Lootster_OptionsFrameRaidFrameTrackByRaid:SetChecked(index == LOOTSTER_ENUM_TRACKBY.RAID);
	Lootster_OptionsFrameRaidFrameTrackByRaidNBoss:SetChecked(index == LOOTSTER_ENUM_TRACKBY.RAIDNBOSS);
	
	-- play sound if selected
	if (index ~= nil) then
		PlaySound("igMainMenuOptionCheckBoxOn");
	end

	-- update raid management UI
	Lootster_CheckRaidUse();

	-- update boss UI
	Lootster_CheckBossUse();

	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState();
end

-- Option Raid Icon Toggle handler
function Lootster_Option_RaidIcon_OnToggle(self)
	-- retrieve value
	Lootster_Options.RaidIcon = (Lootster_OptionsFrameRaidIcon:GetChecked() ~= nil);

	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState();
end

-- Option Boss Icon Toggle handler
function Lootster_Option_BossIcon_OnToggle(self)
	-- retrieve value
	Lootster_Options.BossIcon = (Lootster_OptionsFrameBossIcon:GetChecked() ~= nil);

	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState();
end

-- Option Auto Raid Toggle handler
function Lootster_Option_AutoRaid_OnToggle(self)
	-- retrieve value
	Lootster_Options.AutoRaid = (Lootster_OptionsFrameAutoRaid:GetChecked() ~= nil);

	-- update boss UI
	Lootster_CheckBossUse();
end

-- Option Auto Boss Toggle handler
function Lootster_Option_AutoBoss_OnToggle(self)
	-- retrieve value
	Lootster_Options.AutoBoss = (Lootster_OptionsFrameAutoBoss:GetChecked() ~= nil);

	-- update boss UI
	Lootster_CheckBossUse();
end

-- Option Attend Here Toggle handler
function Lootster_Option_AttendHere_OnToggle(self)
	-- retrieve value
	Lootster_Options.AttendHere = (Lootster_OptionsFrameAttendHere:GetChecked() ~= nil);

	-- update attend UI
	Lootster_CheckAttendUse();
end

-- Option Attend Announce Toggle handler
function Lootster_Option_AttendAnnounce_OnToggle(self)
	-- retrieve value
	Lootster_Options.AttendAnnounce = (Lootster_OptionsFrameAttendAnnounce:GetChecked() ~= nil);

	-- update attend UI
	Lootster_CheckAttendUse();
end

-- Option Attend Group Toggle handler
function Lootster_Option_AttendGroup_OnToggle(self)
	-- retrieve value
	Lootster_Options.AttendGroup = (Lootster_OptionsFrameAttendGroup:GetChecked() ~= nil);

	-- update attend UI
	Lootster_CheckAttendUse();
end

-- Option Attend Guild Toggle handler
function Lootster_Option_AttendGuild_OnToggle(self)
	-- retrieve value
	Lootster_Options.AttendGuild = (Lootster_OptionsFrameAttendGuild:GetChecked() ~= nil);

	-- update attend UI
	Lootster_CheckAttendUse();
end

-- Option Attend Custom Toggle handler
function Lootster_Option_AttendCustom_OnToggle(self)
	-- retrieve value
	Lootster_Options.AttendCustom = (Lootster_OptionsFrameAttendCustom:GetChecked() ~= nil);

	-- update attend UI
	Lootster_CheckAttendUse();
	
	-- handle toggling of channel
	if (Lootster_Options.AttendCustom ~= true) then
		-- leave channel
		Lootster_ChannelChange(nil, Lootster_Options.AttendCustomChannel);
	else
		-- join channel
		Lootster_ChannelChange(Lootster_Options.AttendCustomChannel, nil);
	end
end

-- Option Attend Custom Channel Focus Gained handler
function Lootster_Option_AttendCustomChannel_OnFocusGained(self)
	-- save the current value so we can detect changes
	Lootster_AttendCustomChannelSave = Lootster_Options.AttendCustomChannel;

	-- select the current text
	self:HighlightText();
end

-- Option Attend Custom Channel Entered handler
function Lootster_Option_AttendCustomChannel_OnTextChanged(self)
end

-- Option Attend Custom Channel Focus Lost handler
function Lootster_Option_AttendCustomChannel_OnFocusLost(self)
	-- retrieve
	Lootster_Options.AttendCustomChannel = Lootster_OptionsFrameAttendCustomChannel:GetText();

	-- did the Attend Custom Channel change?
	if (Lootster_AttendCustomChannelSave ~= Lootster_Options.AttendCustomChannel) then
		-- update custom channel
		Lootster_ChannelChange(Lootster_Options.AttendCustomChannel, Lootster_AttendCustomChannelSave);
	end

	-- and reset the Attend Custom Channel
	Lootster_AttendCustomChannelSave = nil;
end

-- Option Loot Mode Load handler
function Lootster_Option_LootMode_OnLoad(self)
	-- set width
	UIDropDownMenu_SetWidth(self, 115);
	UIDropDownMenu_JustifyText(self, "LEFT");
end

-- Option Loot Mode Show handler
function Lootster_Option_LootMode_OnShow(self)
	-- setup the loot mode drop down
	UIDropDownMenu_Initialize(Lootster_OptionsFrameLootMode, Lootster_Option_LootMode_Initialise);

	-- set initial selection
	UIDropDownMenu_SetSelectedValue(Lootster_OptionsFrameLootMode, Lootster_Options.LootMode);
end

-- Option Loot Mode Load Initaliser handler
function Lootster_Option_LootMode_Initialise()
	local quality, info;

	-- load up loot quality
	for quality=LOOTSTER_ENUM_LOOTMODE.UNCOMMON, LOOTSTER_ENUM_LOOTMODE.LEGENDARY do
		-- form mode button
		info = {};
		info.text = _G["ITEM_QUALITY"..quality.."_DESC"];
		info.func = Lootster_Option_LootMode_OnSelect;
		info.value = quality;
		info.colorCode = ITEM_QUALITY_COLORS[quality].hex;

		-- add loot mode button
		UIDropDownMenu_AddButton(info);
	end
end

-- Option Loot Mode Select handler
function Lootster_Option_LootMode_OnSelect(self)
	-- and snarf new mode
	Lootster_Options.LootMode = self.value;

	-- select this entry
	UIDropDownMenu_SetSelectedValue(Lootster_OptionsFrameLootMode, self.value);

	-- and show/hide the MiniMap button and hide/show the title
	Lootster_MiniMapButton_SwitchState();
end

-- Option Auto DKP Loot Toggle handler
function Lootster_Option_AutoDKPLoot_OnToggle(self)
	-- retrieve value
	Lootster_Options.AutoDKPLoot = (Lootster_OptionsFrameAutoDKPLoot:GetChecked() ~= nil);
end

-- Option Auto NonDKP Loot Toggle handler
function Lootster_Option_AutoNonDKPLoot_OnToggle(self)
	-- retrieve value
	Lootster_Options.AutoNonDKPLoot = (Lootster_OptionsFrameAutoNonDKPLoot:GetChecked() ~= nil);
end

-- Option Auto Loot Raid Toggle handler
function Lootster_Option_AutoLootRaid_OnToggle(self)
	-- retrieve value
	Lootster_Options.AutoLootRaid = (Lootster_OptionsFrameAutoLootRaid:GetChecked() ~= nil);
end

-- Option Guild Ranks for Membership Toggle handler
function Lootster_Option_RankMembers_OnToggle(self)
	-- retrieve value
	Lootster_Options.RankMembers[Lootster_SelfGuild] = (Lootster_OptionsFrameRankMembers:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option Use Public Note for Toons Toggle handler
function Lootster_Option_NoteToons_OnToggle(self)
	-- retrieve value
	Lootster_Options.NoteToons[Lootster_SelfGuild] = (Lootster_OptionsFrameNoteToons:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option Cross Check Public Note for Toons Toggle handler
function Lootster_Option_RankToons_OnToggle(self)
	-- retrieve value
	Lootster_Options.RankToons[Lootster_SelfGuild] = (Lootster_OptionsFrameRankToons:GetChecked() ~= nil);

	-- update roll handling
	Lootster_UpdateRollHandling();
end

-- Option Rescan Guild Information handler
function Lootster_Option_RescanGuild_OnClick(self, button)
	-- first, rescan guild ranks
	Lootster_LoadGuildRanks();

	-- reload our guild player information
	Lootster_LoadGuildieInfo();

	-- reload data
	Lootster_LoadData();

	-- force a roster update
	Lootster_PARTY_Roster();

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort rank using current sort
	Lootster_Rank_Sort(nil);

	-- update roll handling to reflect new guild information
	Lootster_UpdateRollUI();
end

-- Option Alt's Main Prefix Focus Gained handler
function Lootster_Option_AltsMainPrefix_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option Alt's Main Prefix Entered handler
function Lootster_Option_AltsMainPrefix_OnTextChanged(self)
end

-- Option Alt's Main Prefix Focus Lost handler
function Lootster_Option_AltsMainPrefix_OnFocusLost(self)
	-- retrieve value, encoding for a regular expression as required
	Lootster_Options.RankAltPrefix[Lootster_SelfGuild] = Lootster_EncodeRegexp(Lootster_OptionsFrameAltsMainPrefix:GetText());
end

-- Option Alt's Main Suffix Focus Gained handler
function Lootster_Option_AltsMainSuffix_OnFocusGained(self)
	-- select the current text
	self:HighlightText();
end

-- Option Alt's Main Suffix Entered handler
function Lootster_Option_AltsMainSuffix_OnTextChanged(self)
end

-- Option Alt's Main Suffix Focus Lost handler
function Lootster_Option_AltsMainSuffix_OnFocusLost(self)
	-- retrieve value, encoding for a regular expression as required
	Lootster_Options.RankAltSuffix[Lootster_SelfGuild] = Lootster_EncodeRegexp(Lootster_OptionsFrameAltsMainSuffix:GetText());
end

-- Rank Row Click handler
function Lootster_Rank_Button_OnClick(self, button)
end

-- Option Guild Rank By Click handler
function Lootster_Option_Rank_RadioButton_OnClick(self, button, index)
	local	offset, name;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_RankFrameScrollFrame);

	-- calculate actual the rank item index and get the rank record key
	name = Lootster_RankSort[self:GetParent():GetID() + offset];

	-- play sound if selected
	if (index ~= nil) then
		-- see if we are selecting membership or toon type
		if (index ~= LOOTSTER_ENUM_RANK.ALT) then
			-- set the rank's membership
			Lootster_Options.Ranks[Lootster_SelfGuild][name].Member = LOOTSTER_ENUM_MEMBER.NONE + index;

			-- this is always a main
			Lootster_Options.Ranks[Lootster_SelfGuild][name].Toon = LOOTSTER_ENUM_TOON.MAIN;
		else
			-- set the rank's toonship as an ALT
			Lootster_Options.Ranks[Lootster_SelfGuild][name].Toon = LOOTSTER_ENUM_TOON.ALT;

			-- membership is always NONE (since it derives from the main's rank membership)
			Lootster_Options.Ranks[Lootster_SelfGuild][name].Member = LOOTSTER_ENUM_MEMBER.NONE;
		end

		PlaySound("igMainMenuOptionCheckBoxOn");
	end

	-- resort rank using current sort
	Lootster_Rank_Sort(nil);
end

-- Option Usage Rolling Click handler
function Lootster_Option_UsageRolls_OnToggle(self)
	-- retrieve value
	Lootster_Options.UsageRolls = (Lootster_OptionsFrameUsageRolls:GetChecked() ~= nil);
	
	-- reposition tabs and update UI
	Lootster_CheckModeUse();
	
	-- update roll UI
	Lootster_UpdateRollUI();
end

-- Option Usage By Click handler
function Lootster_Option_UsageBy_RadioButton_OnClick(self, button, index)
	-- snarf index
	Lootster_Options.UsageBy = index;
	
	-- determine the usage by button
	Lootster_OptionsFrameUsageFrameUsageBySeparate:SetChecked(Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SEPARATE);
	Lootster_OptionsFrameUsageFrameUsageBySingle:SetChecked(Lootster_Options.UsageBy == LOOTSTER_ENUM_USAGEBY.SINGLE);
	
	-- play sound if selected
	if (index ~= nil) then
		PlaySound("igMainMenuOptionCheckBoxOn");
	end
	
	-- reposition tabs and update UI
	Lootster_CheckModeUse();
	
	-- update roll UI
	Lootster_UpdateRollUI();
end

-- Option Usage Banker Show handler
function Lootster_Option_Usage_Banker_OnShow(self)
	-- setup the banker drop down
	UIDropDownMenu_Initialize(self, Lootster_Option_Usage_Banker_Initialise, "MENU");

	-- set width
	UIDropDownMenu_SetWidth(self, 105);

	-- and justify left
	Lootster_OptionsFrameUsageFrameBankerDropDownText:SetJustifyH("LEFT");
end

-- Option Usage Banker Initaliser handler
function Lootster_Option_Usage_Banker_Initialise()
	local	currIx, player, playerInfo;

	-- form park player buttons
	for currIx, player in ipairs(Lootster_ParkSort) do
		-- form park player button
		playerInfo = {};
		playerInfo.text = player;
		playerInfo.value = player;
		playerInfo.func = Lootster_Option_Usage_OnSelect;

		-- add player button
		UIDropDownMenu_AddButton(playerInfo);
	end

	-- form other banker button
	playerInfo = {};
	playerInfo.text = LOOTSTER_OPTION_OTHERBANKER;
	playerInfo.value = "";
	playerInfo.func = Lootster_Option_Usage_OnBanker;

	-- add player button
	UIDropDownMenu_AddButton(playerInfo);
	
	-- set current banker
	UIDropDownMenu_SetText(Lootster_OptionsFrameUsageFrameBankerDropDown, Lootster_Options.Banker);
	UIDropDownMenu_SetSelectedName(Lootster_OptionsFrameUsageFrameBankerDropDown, Lootster_Options.Banker);
end

-- Option Usage Banker Select handler
function Lootster_Option_Usage_OnSelect(self)
	-- retrieve the selected banker
	Lootster_Options.Banker = self.value;
	
	-- and select him in the drop down
	UIDropDownMenu_SetText(Lootster_OptionsFrameUsageFrameBankerDropDown, self.value);
	UIDropDownMenu_SetSelectedName(Lootster_OptionsFrameUsageFrameBankerDropDown, self.value);

	-- close menus
	CloseDropDownMenus();
end

-- Option Usage Enter Other Banker handler
function Lootster_Option_Usage_OnBanker()
	-- show edit box for banker name
	StaticPopup_Show("LOOTSTER_PROMPT_OPTION_BANKER");
end

-- Usage Row Click handler
function Lootster_Usage_Button_OnClick(self, button)
	local	offset;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_UsageFrameScrollFrame);

	-- and get actual usage through the usage sort
	Lootster_UsageSel = Lootster_Options.UsageSort[self:GetID() + offset];
	
	-- set the usage name, as well as value and factor
	Lootster_UsageFrameLabel:SetText(LOOTSTER_USAGEDKP_LIST[Lootster_UsageSel]);
	Lootster_UsageFrameAltFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Usage[Lootster_UsageSel].aFactor));
	Lootster_UsageFrameCostValue:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Usage[Lootster_UsageSel].cValue));
	Lootster_UsageFrameCostFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Usage[Lootster_UsageSel].cFactor));
	Lootster_UsageFrameWinsPerRaid:SetNumber(Lootster_Options.Usage[Lootster_UsageSel].WinsPerRaid);

	-- update event data
	Lootster_Usage_Update();
	
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();
end

-- Usage Row Move Up handler
function Lootster_Option_Usage_MoveUp(self)
	local	priority, usageTmp;
	
	-- get the priority of the selected usage
	priority = Lootster_Options.Usage[Lootster_UsageSel].Priority;
	
	-- cannot move above first row
	if (priority > 2) then
		-- first, swap priorities on these two usages
		Lootster_Options.Usage[Lootster_Options.UsageSort[priority]].Priority = priority - 1;
		Lootster_Options.Usage[Lootster_Options.UsageSort[priority - 1]].Priority = priority;

		-- next, swap the order in the usage sort
		usageTmp = Lootster_Options.UsageSort[priority];
		Lootster_Options.UsageSort[priority] = Lootster_Options.UsageSort[priority - 1];
		Lootster_Options.UsageSort[priority - 1] = usageTmp;

		-- update event data
		Lootster_Usage_Update();
		
		-- update options usage UI
		Lootster_UpdateOptionUsageUI();
		
		-- reload the roll call usage and roll usage dropdowns
		Lootster_Roll_CallUsage_OnShow();	
		Lootster_Roll_RollUsage_OnShow();	
	end
end

-- Usage Row Move Down handler
function Lootster_Option_Usage_MoveDown(self)
	local	priority, usageTmp;
	
	-- get the priority of the selected usage
	priority = Lootster_Options.Usage[Lootster_UsageSel].Priority;
	
	-- cannot move below last row
	if (priority < (#Lootster_Options.UsageSort - 1)) then
		-- first, swap priorities on these two usages
		Lootster_Options.Usage[Lootster_Options.UsageSort[priority]].Priority = priority + 1;
		Lootster_Options.Usage[Lootster_Options.UsageSort[priority + 1]].Priority = priority;

		-- next, swap the order in the usage sort
		usageTmp = Lootster_Options.UsageSort[priority];
		Lootster_Options.UsageSort[priority] = Lootster_Options.UsageSort[priority + 1];
		Lootster_Options.UsageSort[priority + 1] = usageTmp;

		-- update event data
		Lootster_Usage_Update();
		
		-- update options usage UI
		Lootster_UpdateOptionUsageUI();
		
		-- reload the roll call usage and roll usage dropdowns
		Lootster_Roll_CallUsage_OnShow();	
		Lootster_Roll_RollUsage_OnShow();	
	end
end

-- Option Usage Use Click handler
function Lootster_Option_Use_OnToggle(self)
	local	offset, usage;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_UsageFrameScrollFrame);

	-- calculate actual the usage index through the usage order vector
	usage = Lootster_Options.UsageSort[self:GetParent():GetID() + offset];

	-- toggle the active value
	Lootster_Options.Usage[usage].Use = (self:GetChecked() ~= nil);
	
	-- reload the roll call usage and roll usage dropdowns
	Lootster_Roll_CallUsage_OnShow();	
	Lootster_Roll_RollUsage_OnShow();	
end

-- Option Usage Alt Factor Focus Gained handler
function Lootster_Option_AltFactor_OnFocusGained(self)
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- save the current factor so we can detect changes
	Lootster_AltFactorSave = Lootster_Options.Usage[Lootster_UsageSel].aFactor;

	-- select the current text
	self:HighlightText();
end

-- Option Usage Alt Factor Entered handler
function Lootster_Option_AltFactor_OnTextChanged(self)
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();
end

-- Option Usage Alt Factor Focus Lost handler
function Lootster_Option_AltFactor_OnFocusLost(self)
	local	factor;
	
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- retrive alt factor
	factor = tonumber(Lootster_UsageFrameAltFactor:GetText());
	
	-- must be non-nil
	if (factor == nil) then
		-- restore original factor
		factor = Lootster_AltFactorSave;
	end

	-- must be positive
	if (factor < 0) then
		-- negate factor
		factor = -factor;
	end
	
	-- update
	Lootster_UsageFrameAltFactor:SetText(string.format(LOOTSTER_COST_POINTS, factor));
	
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();

	-- reset the factor
	Lootster_AltFactorSave = nil;
end

-- Option Usage Cost Click handler
function Lootster_Option_Usage_RadioButton_OnClick(self, button, index)
	local	offset, usage;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_UsageFrameScrollFrame);

	-- calculate actual the rank item index through the usage order vector
	usage = Lootster_Options.UsageSort[self:GetParent():GetID() + offset];

	-- play sound if selected
	if (index ~= nil) then
		-- set the cost type
		Lootster_Options.Usage[usage].Cost = index;

		PlaySound("igMainMenuOptionCheckBoxOn");
	end

	-- update usage data
	Lootster_Usage_Update();
		
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();
end

-- Option Usage Cost Value Focus Gained handler
function Lootster_Option_CostValue_OnFocusGained(self)
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- save the current value so we can detect changes
	Lootster_CostValueSave = Lootster_Options.Usage[Lootster_UsageSel].cValue;

	-- select the current text
	self:HighlightText();
end

-- Option Usage Cost Entered handler
function Lootster_Option_CostValue_OnTextChanged(self)
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();
end

-- Option Usage Cost Value Focus Lost handler
function Lootster_Option_CostValue_OnFocusLost(self)
	local	value;
	
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- retrive cost value
	value = tonumber(Lootster_UsageFrameCostValue:GetText());
	
	-- must be non-nil
	if (value == nil) then
		-- restore original value
		value = Lootster_CostValueSave;
	end

	-- must be positive
	if (value < 0) then
		-- negate value
		value = -value;
	end
	
	-- update
	Lootster_UsageFrameCostValue:SetText(string.format(LOOTSTER_COST_POINTS, value));
	
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();

	-- reset the value
	Lootster_CostValueSave = nil;
end

-- Option Usage Cost Factor Focus Gained handler
function Lootster_Option_CostFactor_OnFocusGained(self)
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- save the current factor so we can detect changes
	Lootster_CostFactorSave = Lootster_Options.Usage[Lootster_UsageSel].cFactor;

	-- select the current text
	self:HighlightText();
end

-- Option Usage Cost Factor Entered handler
function Lootster_Option_CostFactor_OnTextChanged(self)
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();
end

-- Option Usage Cost Factor Focus Lost handler
function Lootster_Option_CostFactor_OnFocusLost(self)
	local	factor;
	
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- retrive cost factor
	factor = tonumber(Lootster_UsageFrameCostFactor:GetText());
	
	-- must be non-nil
	if (factor == nil) then
		-- restore original factor
		factor = Lootster_CostFactorSave;
	end

	-- must be positive
	if (factor < 0) then
		-- negate factor
		factor = -factor;
	end
	
	-- update
	Lootster_UsageFrameCostFactor:SetText(string.format(LOOTSTER_COST_POINTS, factor));
	
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();

	-- reset the factor
	Lootster_CostFactorSave = nil;
end

-- Option Usage Wins Click handler
function Lootster_Option_Wins_OnToggle(self)
	local	offset, usage;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_UsageFrameScrollFrame);

	-- calculate actual the usage index through the usage order vector
	usage = Lootster_Options.UsageSort[self:GetParent():GetID() + offset];

	-- toggle the active value
	Lootster_Options.Usage[usage].Wins = (self:GetChecked() ~= nil);

	-- update usage data
	Lootster_Usage_Update();
		
	-- update options usage UI
 	Lootster_UpdateOptionUsageUI();
end

-- Option Usage Wins Per Raid Focus Gained handler
function Lootster_Option_WinsPerRaid_OnFocusGained(self)
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- save the current value so we can detect changes
	Lootster_WinsPerRaidSave = Lootster_Options.Usage[Lootster_UsageSel].WinsPerRaid;

	-- select the current text
	self:HighlightText();
end

-- Option Usage Wins Per Raid Entered handler
function Lootster_Option_WinsPerRaid_OnTextChanged(self)
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();
end

-- Option Usage Wins Per Raid Focus Lost handler
function Lootster_Option_WinsPerRaid_OnFocusLost(self)
	local	wins;
	
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- retrive wins per raid
	wins = tonumber(Lootster_UsageFrameWinsPerRaid:GetText());
	
	-- must be non-nil
	if (wins == nil) then
		-- restore original value
		wins = Lootster_WinsPerRaidSave;
	end

	-- must be positive
	if (wins < 0) then
		-- negate value
		wins = -wins;
	end
	
	-- update
	Lootster_UsageFrameWinsPerRaid:SetNumber(wins);
	
	-- update options usage UI
	Lootster_UpdateOptionUsageUI();

	-- reset the wins
	Lootster_WinsPerRaidSave = nil;
end

-- Option Usage Set Click handler
function Lootster_Option_UsageSet_OnClick(self, button)
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- retrieve alt factor
	Lootster_Options.Usage[Lootster_UsageSel].aFactor = tonumber(Lootster_UsageFrameAltFactor:GetText());
	
	-- retrieve respective value as appropriate
	if		(Lootster_Options.Usage[Lootster_UsageSel].Cost == LOOTSTER_ENUM_USAGECOST.VALUE) then
		Lootster_Options.Usage[Lootster_UsageSel].cValue = tonumber(Lootster_UsageFrameCostValue:GetText());
	elseif	(Lootster_Options.Usage[Lootster_UsageSel].Cost == LOOTSTER_ENUM_USAGECOST.FACTOR) then
		Lootster_Options.Usage[Lootster_UsageSel].cFactor = tonumber(Lootster_UsageFrameCostFactor:GetText());
	end
	
	-- retrieve wins per raid if enabled
	Lootster_Options.Usage[Lootster_UsageSel].WinsPerRaid = tonumber(Lootster_UsageFrameWinsPerRaid:GetText());
	
	-- update event data, reselecting this event entry
	Lootster_Usage_Update(Lootster_UsageSel);
end

-- Option Usage Reset Click handler
function Lootster_Option_UsageReset_OnClick(self, button)
	-- no usage selected means we are done
	if (Lootster_UsageSel == nil) then
		return;
	end
	
	-- reset selected usage
	Lootster_Options.Usage[Lootster_UsageSel] = Lootster_CopyRecord(Lootster_Options_Default.Usage[Lootster_UsageSel]);
	
	-- update event data, reselecting this event entry
	Lootster_Usage_Update(Lootster_UsageSel);
end

-- Option Usage Reset All Click handler
function Lootster_Option_UsageResetAll_OnClick(self, button)
	-- reset all usage
	Lootster_Options.Usage = Lootster_CopyRecord(Lootster_Options_Default.Usage);
	
	-- update event data, reselecting this event entry
	Lootster_Usage_Update(Lootster_UsageSel);
end

-- Event Row Click handler
function Lootster_Event_Button_OnClick(self, button)
	local	offset;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_EventFrameScrollFrame);

	-- calculate actual the event index
	Lootster_EventSel = self:GetID() + offset;
	
	-- set the event name, as well as 10 and 25 man DKP, partial perecentage and standby percentage
	Lootster_EventFrameLabel:SetText(LOOTSTER_EVENT_LIST[Lootster_EventSel]);
	Lootster_EventFrameDKP10:SetNumber(Lootster_Options.Event[Lootster_EventSel].DKP10);
	Lootster_EventFramePartial10:SetNumber(Lootster_Options.Event[Lootster_EventSel].Partial10);
	Lootster_EventFrameStandby10:SetNumber(Lootster_Options.Event[Lootster_EventSel].Standby10);
	Lootster_EventFrameDKP25:SetNumber(Lootster_Options.Event[Lootster_EventSel].DKP25);
	Lootster_EventFramePartial25:SetNumber(Lootster_Options.Event[Lootster_EventSel].Partial25);
	Lootster_EventFrameStandby25:SetNumber(Lootster_Options.Event[Lootster_EventSel].Standby25);
	
	-- if we have a time component, set that as well
	if (Lootster_Options.Event[Lootster_EventSel].Time ~= nil) then
		-- set time text
		Lootster_EventFrameTimeLabel:SetText(LOOTSTER_EVENTINFO_LIST[Lootster_EventSel]);
		
		-- and time
		Lootster_EventFrameTime:SetNumber(Lootster_Options.Event[Lootster_EventSel].Time);
		
		-- show time edit
		Lootster_EventFrameTime:Show();		
	else
		-- hide time edit
		Lootster_EventFrameTime:Hide();		
	end
	
	-- update event data
	Lootster_Event_Update();
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event Use 10 Man Click handler
function Lootster_Option_Use10_OnToggle(self)
	local	offset, event, used10;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_EventFrameScrollFrame);

	-- calculate actual the event index
	event = self:GetParent():GetID() + offset;

	-- if this is the bonus time event, remember use for raid
	if ((Lootster_Running.RaidId ~= nil) and (event == LOOTSTER_ENUM_EVENT.BONUSTIME)) then
		used10 = Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSTIME);
	end
	
	-- toggle the active value
	Lootster_Options.Event[event].Use10 = (self:GetChecked() ~= nil);

	-- if this is the bonus time event, check use for raid 
	if ((Lootster_Running.RaidId ~= nil) and (event == LOOTSTER_ENUM_EVENT.BONUSTIME)) then
		-- did we toggle the bonus time event?
		if (used10 ~= Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSTIME)) then
			-- toggle bonus time event appropriately
			Lootster_ManageBonusTime(not used10);
		end
	end	
end

-- Option Event Use 25 Man Click handler
function Lootster_Option_Use25_OnToggle(self)
	local	offset, event, used25;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_EventFrameScrollFrame);

	-- calculate actual the event index
	event = self:GetParent():GetID() + offset;

	-- if this is the bonus time event, remember use for raid
	if ((Lootster_Running.RaidId ~= nil) and (event == LOOTSTER_ENUM_EVENT.BONUSTIME)) then
		used25 = Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSTIME);
	end

	-- toggle the active value
	Lootster_Options.Event[event].Use25 = (self:GetChecked() ~= nil);

	-- if this is the bonus time event, check use for raid 
	if ((Lootster_Running.RaidId ~= nil) and (event == LOOTSTER_ENUM_EVENT.BONUSTIME)) then
		-- did we toggle the bonus time event?
		if (used25 ~= Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSTIME)) then
			-- toggle bonus time event appropriately
			Lootster_ManageBonusTime(not used25);
		end
	end
end

-- Option Event Time Focus Gained handler
function Lootster_Option_Time_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event Time Entered handler
function Lootster_Option_Time_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event Time Focus Lost handler
function Lootster_Option_Time_OnFocusLost(self)
	local	eventTime;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event time
	eventTime = Lootster_EventFrameTime:GetNumber();
	
	-- must be positive
	if (eventTime < 0) then
		-- negate value
		eventTime = -eventTime;
	end
	
	-- update
	Lootster_EventFrameTime:SetNumber(eventTime);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event Time Enter handler
function Lootster_Option_Time_OnEnter(self)
	-- setup variable tooltip
	GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");

	if ((Lootster_EventSel ~= nil) and (Lootster_Options.Event[Lootster_EventSel].Time ~= nil)) then
		GameTooltip:SetText(LOOTSTER_EVENTINFO_LIST_TT[Lootster_EventSel]);
	end
end

-- Option Event 10 Man DKP Focus Gained handler
function Lootster_Option_DKP10_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event 10 Man DKP Entered handler
function Lootster_Option_DKP10_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 10 Man DKP Focus Lost handler
function Lootster_Option_DKP10_OnFocusLost(self)
	local	dkp10;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event 10 man DKP
	dkp10 = Lootster_EventFrameDKP10:GetNumber();

	-- must be positive
	if (dkp10 < 0) then
		-- negate value
		dkp10 = -dkp10;
	end
	
	-- update
	Lootster_EventFrameDKP10:SetNumber(dkp10);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 10 Man Partial Focus Gained handler
function Lootster_Option_Partial10_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event 10 Man Partial Entered handler
function Lootster_Option_Partial10_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 10 Man Partial Focus Lost handler
function Lootster_Option_Partial10_OnFocusLost(self)
	local	partial10;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event 10 man Partial
	partial10 = Lootster_EventFramePartial10:GetNumber();

	-- must be positive
	if (partial10 < 0) then
		-- negate value
		partial10 = -partial10;
	end
	
	-- update
	Lootster_EventFramePartial10:SetNumber(partial10);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 10 Man Standby Focus Gained handler
function Lootster_Option_Standby10_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event 10 Man Standby Entered handler
function Lootster_Option_Standby10_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 10 Man Standby Focus Lost handler
function Lootster_Option_Standby10_OnFocusLost(self)
	local	standby10;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event 10 man Standby
	standby10 = Lootster_EventFrameStandby10:GetNumber();
	
	-- must be positive
	if (standby10 < 0) then
		-- negate value
		standby10 = -standby10;
	end
	
	-- update
	Lootster_EventFrameStandby10:SetNumber(standby10);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 25 Man DKP Focus Gained handler
function Lootster_Option_DKP25_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event 25 Man DKP Entered handler
function Lootster_Option_DKP25_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 25 Man DKP Focus Lost handler
function Lootster_Option_DKP25_OnFocusLost(self)
	local	dkp25;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event 25 man DKP
	dkp25 = Lootster_EventFrameDKP25:GetNumber();
	
	-- must be positive
	if (dkp25 < 0) then
		-- negate value
		dkp25 = -dkp25;
	end
	
	-- update
	Lootster_EventFrameDKP25:SetNumber(dkp25);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 25 Man Partial Focus Gained handler
function Lootster_Option_Partial25_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event 25 Man Partial Entered handler
function Lootster_Option_Partial25_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 25 Man Partial Focus Lost handler
function Lootster_Option_Partial25_OnFocusLost(self)
	local	partial25;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event 25 man Partial
	partial25 = Lootster_EventFramePartial25:GetNumber();
	
	-- must be positive
	if (partial25 < 0) then
		-- negate value
		partial25 = -partial25;
	end
	
	-- update
	Lootster_EventFramePartial25:SetNumber(partial25);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 25 Man Standby Focus Gained handler
function Lootster_Option_Standby25_OnFocusGained(self)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end

	-- select the current text
	self:HighlightText();
end

-- Option Event 25 Man Standby Entered handler
function Lootster_Option_Standby25_OnTextChanged(self)
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event 25 Man Standby Focus Lost handler
function Lootster_Option_Standby25_OnFocusLost(self)
	local	standby25;
	
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrive event 25 man Standby
	standby25 = Lootster_EventFrameStandby25:GetNumber();
	
	-- must be positive
	if (standby25 < 0) then
		-- negate value
		standby25 = -standby25;
	end
	
	-- update
	Lootster_EventFrameStandby25:SetNumber(standby25);
	
	-- update options events UI
	Lootster_UpdateOptionEventsUI();
end

-- Option Event Set Click handler
function Lootster_Option_EventSet_OnClick(self, button)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- retrieve 10 Man DKP and Partial and Standby percentages
	Lootster_Options.Event[Lootster_EventSel].DKP10 = tonumber(Lootster_EventFrameDKP10:GetText());
	Lootster_Options.Event[Lootster_EventSel].Partial10 = Lootster_EventFramePartial10:GetNumber();
	Lootster_Options.Event[Lootster_EventSel].Standby10 = Lootster_EventFrameStandby10:GetNumber();
	
	-- retrieve 25 Man DKP and Partial and Standby percentages
	Lootster_Options.Event[Lootster_EventSel].DKP25 = tonumber(Lootster_EventFrameDKP25:GetText());
	Lootster_Options.Event[Lootster_EventSel].Partial25 = Lootster_EventFramePartial25:GetNumber();
	Lootster_Options.Event[Lootster_EventSel].Standby25 = Lootster_EventFrameStandby25:GetNumber();
	
	-- if we have a time component, snarf that too
	if (Lootster_Options.Event[Lootster_EventSel].Time ~= nil) then
		-- grab time component
		Lootster_Options.Event[Lootster_EventSel].Time = Lootster_EventFrameTime:GetNumber();
	end
		
	-- update event data, reselecting this event entry
	Lootster_Event_Update(Lootster_EventSel);
end

-- Option Event Reset Click handler
function Lootster_Option_EventReset_OnClick(self, button)
	-- no event selected means we are done
	if (Lootster_EventSel == nil) then
		return;
	end
	
	-- reset selected event
	Lootster_Options.Event[Lootster_EventSel] = Lootster_CopyRecord(Lootster_Options_Default.Event[Lootster_EventSel]);
		
	-- update event data, reselecting this event entry
	Lootster_Event_Update(Lootster_EventSel);
end

-- Option Event Reset All Click handler
function Lootster_Option_EventResetAll_OnClick(self, button)
	-- reset all event
	Lootster_Options.Event = Lootster_CopyRecord(Lootster_Options_Default.Event);
		
	-- update event data, reselecting this event entry
	Lootster_Event_Update(Lootster_EventSel);
end

-- Option Use Calculated Points Toggle handler
function Lootster_Option_CalcPoints_OnToggle(self)
	-- retrieve value
	Lootster_Options.CalcPoints = (Lootster_OptionsFrameCalcPoints:GetChecked() ~= nil);
end

-- Quality Row Click handler
function Lootster_Quality_Button_OnClick(self, button)
	local	offset;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_QualityFrameScrollFrame);

	-- calculate actual the item quality index
	Lootster_QualitySel = self:GetID() + offset + LOOTSTER_ENUM_LOOTMODE.UNCOMMON - 1;
	
	-- set the quality name, factor and bias
	Lootster_OptionsFrameItemPointsFrameqFactorLabel:SetText(ITEM_QUALITY_COLORS[Lootster_QualitySel].hex.._G["ITEM_QUALITY"..Lootster_QualitySel.."_DESC"]..FONT_COLOR_CODE_CLOSE);
	Lootster_OptionsFrameItemPointsFrameqFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Quality[Lootster_QualitySel].qFactor));
	Lootster_OptionsFrameItemPointsFrameqBias:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Quality[Lootster_QualitySel].qBias));
	
	-- update item quality data
	Lootster_Quality_Update();
	
	-- update options points UI
	Lootster_UpdateOptionPointsUI();
end

-- Option Cost Factor Focus Gained handler
function Lootster_Option_pFactor_OnFocusGained(self)
	-- save the current value so we can detect changes
	Lootster_pFactorSave = Lootster_Options.pFactor;

	-- select the current text
	self:HighlightText();
end

-- Option Cost Factor Entered handler
function Lootster_Option_pFactor_OnTextChanged(self)
end

-- Option Cost Factor Focus Lost handler
function Lootster_Option_pFactor_OnFocusLost(self)
	-- retrieve pFactor
	Lootster_Options.pFactor = tonumber(Lootster_OptionsFrameItemPointsFramepFactor:GetText());

	-- must be non-nil
	if (tonumber(Lootster_OptionsFrameItemPointsFramepFactor:GetText()) == nil) then
		-- restore value
		Lootster_Options.pFactor = Lootster_pFactorSave;
	end

	-- must be positive
	if (Lootster_Options.pFactor < 0) then
		-- negate value
		Lootster_Options.pFactor = -Lootster_Options.pFactor;
	end
	
	-- update
	Lootster_OptionsFrameItemPointsFramepFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.pFactor));

	-- did the points factor change?
	if (Lootster_pFactorSave ~= Lootster_Options.pFactor) then
		-- resnarf any existing hyperlink to recalculate item points
		Lootster_SetHyperlink(Lootster_ItemLink);
	end
		
	-- reset the points factor
	Lootster_pFactorSave = nil;
end

-- Option Quality Active Click handler
function Lootster_Option_UseQuality_OnToggle(self)
	local	offset, quality;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_QualityFrameScrollFrame);

	-- calculate actual the item quality index
	quality = self:GetParent():GetID() + offset + LOOTSTER_ENUM_LOOTMODE.UNCOMMON - 1;

	-- toggle the active value
	Lootster_Options.Quality[quality].Active = (self:GetChecked() ~= nil);
	
	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
end

-- Option Quality Factor Focus Gained handler
function Lootster_Option_qFactor_OnFocusGained(self)
	-- no item quality selected means we are done
	if (Lootster_QualitySel == nil) then
		return;
	end
	
	-- save the current value so we can detect changes
	Lootster_qFactorSave = Lootster_Options.Quality[Lootster_QualitySel].qFactor;

	-- select the current text
	self:HighlightText();
end

-- Option Quality Factor Entered handler
function Lootster_Option_qFactor_OnTextChanged(self)
	-- update options points UI
	Lootster_UpdateOptionPointsUI();
end

-- Option Quality Factor Focus Lost handler
function Lootster_Option_qFactor_OnFocusLost(self)
	local	qFactor;
	
	-- no item quality selected means we are done
	if (Lootster_QualitySel == nil) then
		return;
	end
	
	-- retrive quality factor
	qFactor = tonumber(Lootster_OptionsFrameItemPointsFrameqFactor:GetText());
	
	-- must be non-nil
	if (qFactor == nil) then
		-- restore original value
		qFactor = Lootster_qFactorSave;
	end

	-- must be positive
	if (qFactor < 0) then
		-- negate value
		qFactor = -qFactor;
	end
	
	-- update
	Lootster_OptionsFrameItemPointsFrameqFactor:SetText(string.format(LOOTSTER_COST_POINTS, qFactor));

	-- update options points UI
	Lootster_UpdateOptionPointsUI();

	-- reset the quality factor
	Lootster_qFactorSave = nil;
end

-- Option Quality Bias Focus Gained handler
function Lootster_Option_qBias_OnFocusGained(self)
	-- no item quality selected means we are done
	if (Lootster_QualitySel == nil) then
		return;
	end
	
	-- save the current value so we can detect changes
	Lootster_qBiasSave = Lootster_Options.Quality[Lootster_QualitySel].qBias;

	-- select the current text
	self:HighlightText();
end

-- Option Quality Bias Entered handler
function Lootster_Option_qBias_OnTextChanged(self)
	-- update options points UI
	Lootster_UpdateOptionPointsUI();
end

-- Option Quality Bias Focus Lost handler
function Lootster_Option_qBias_OnFocusLost(self)
	local	qBias;
	
	-- no item quality selected means we are done
	if (Lootster_QualitySel == nil) then
		return;
	end
	
	-- retrive quality bias
	qBias = tonumber(Lootster_OptionsFrameItemPointsFrameqBias:GetText());
	
	-- must be non-nil
	if (qBias == nil) then
		-- restore original value
		qBias = Lootster_qBiasSave;
	end

	-- must be positive
	if (qBias < 0) then
		-- negate value
		qBias = -qBias;
	end
	
	-- update
	Lootster_OptionsFrameItemPointsFrameqBias:SetText(string.format(LOOTSTER_COST_POINTS, qBias));
	
	-- update options points UI
	Lootster_UpdateOptionPointsUI();

	-- reset the quality bias
	Lootster_qBiasSave = nil;
end

-- Option Quality Set Click handler
function Lootster_Option_QualitySet_OnClick(self, button)
	-- no item quality selected means we are done
	if (Lootster_QualitySel == nil) then
		return;
	end
	
	-- retrieve qFactor
	Lootster_Options.Quality[Lootster_QualitySel].qFactor = tonumber(Lootster_OptionsFrameItemPointsFrameqFactor:GetText());

	-- retrieve qBias
	Lootster_Options.Quality[Lootster_QualitySel].qBias = tonumber(Lootster_OptionsFrameItemPointsFrameqBias:GetText());

	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
		
	-- update item quality data, reselecting this item quality entry
	Lootster_Quality_Update(Lootster_QualitySel);
end

-- Option Quality Reset Click handler
function Lootster_Option_QualityReset_OnClick(self, button)
	-- no item quality selected means we are done
	if (Lootster_QualitySel == nil) then
		return;
	end
	
	-- reset selected item quality
	Lootster_Options.Quality[Lootster_QualitySel] = Lootster_CopyRecord(Lootster_Options_Default.Quality[Lootster_QualitySel]);
	
	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
		
	-- update item quality data, reselecting this item quality entry
	Lootster_Quality_Update(Lootster_QualitySel);
end

-- Option Quality Reset All Click handler
function Lootster_Option_QualityResetAll_OnClick(self, button)
	-- reset all item quality
	Lootster_Options.Quality = Lootster_CopyRecord(Lootster_Options_Default.Quality);
	
	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
		
	-- update item quality data, reselecting this item quality entry
	Lootster_Quality_Update(Lootster_QualitySel);
end

-- Slot Row Click handler
function Lootster_Slot_Button_OnClick(self, button)
	local	offset;

	-- retrieve the scroll offset
	offset = FauxScrollFrame_GetOffset(Lootster_SlotFrameScrollFrame);

	-- calculate actual the item slot index
	Lootster_SlotSel = self:GetID() + offset;
	
	-- set the slot name and factor
	Lootster_OptionsFrameItemPointsFramesFactorLabel:SetText(_G["LOOTSTER_OPTION_SFACTOR"..Lootster_SlotSel]);
	Lootster_OptionsFrameItemPointsFramesFactor:SetText(string.format(LOOTSTER_COST_POINTS, Lootster_Options.Slot[Lootster_SlotSel]));
	
	-- update item slot data
	Lootster_Slot_Update();
	
	-- update options points UI
	Lootster_UpdateOptionPointsUI();
end

-- Option Slot Factor Focus Gained handler
function Lootster_Option_sFactor_OnFocusGained(self)
	-- no item slot selected means we are done
	if (Lootster_SlotSel == nil) then
		return;
	end
	
	-- save the current value so we can detect changes
	Lootster_sFactorSave = Lootster_Options.Slot[Lootster_SlotSel];

	-- select the current text
	self:HighlightText();
end

-- Option Slot Factor Entered handler
function Lootster_Option_sFactor_OnTextChanged(self)
	-- update options points UI
	Lootster_UpdateOptionPointsUI();
end

-- Option Slot Factor Focus Lost handler
function Lootster_Option_sFactor_OnFocusLost(self)
	local	sFactor;
	
	-- no item slot selected means we are done
	if (Lootster_SlotSel == nil) then
		return;
	end
	
	-- retrieve slot factor
	sFactor = tonumber(Lootster_OptionsFrameItemPointsFramesFactor:GetText());
	
	-- must be non-nil
	if (sFactor == nil) then
		-- restore original value
		sFactor = Lootster_sFactorSave;
	end
	
	-- must be positive
	if (sFactor < 0) then
		-- negate value
		sFactor = -sFactor;
	end
	
	-- update
	Lootster_OptionsFrameItemPointsFramesFactor:SetText(string.format(LOOTSTER_COST_POINTS, sFactor));

	-- update options points UI
	Lootster_UpdateOptionPointsUI();

	-- reset the slot factor
	Lootster_sFactorSave = nil;
end

-- Option Slot Set Click handler
function Lootster_Option_SlotSet_OnClick(self, button)
	-- no item slot selected means we are done
	if (Lootster_SlotSel == nil) then
		return;
	end
	
	-- retrieve sFactor
	Lootster_Options.Slot[Lootster_SlotSel] = tonumber(Lootster_OptionsFrameItemPointsFramesFactor:GetText());

	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
		
	-- update item slot data, reselecting this item slot entry
	Lootster_Slot_Update(Lootster_SlotSel);
end

-- Option Slot Reset Click handler
function Lootster_Option_SlotReset_OnClick(self, button)
	-- no item slot selected means we are done
	if (Lootster_SlotSel == nil) then
		return;
	end

	-- reset item slot
	Lootster_Options.Slot[Lootster_SlotSel] = Lootster_Options_Default.Slot[Lootster_SlotSel];
	
	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
		
	-- update item slot data, reselecting this item slot entry
	Lootster_Slot_Update(Lootster_SlotSel);
end

-- Option Slot Reset All Click handler
function Lootster_Option_SlotResetAll_OnClick(self, button)
	-- reset all item slot
	Lootster_Options.Slot = Lootster_CopyRecord(Lootster_Options_Default.Slot);
	
	-- resnarf any existing hyperlink to recalculate item points
	Lootster_SetHyperlink(Lootster_ItemLink);
		
	-- update item slot data, reselecting this item slot entry
	Lootster_Slot_Update(Lootster_SlotSel);
end

-- Option Clear Item Link handler
function Lootster_Option_ClearItem_OnClick(self, button)
	-- reset the hyperlinks
	Lootster_SetHyperlink(nil);
end

-- Option Item Link Click handler
function Lootster_Option_ItemLink_OnClick(self, button)
	-- do we have a link?
	if (Lootster_ItemLink ~= nil) then
		-- pass link to tooltip click handler
		Lootster_ClickTooltip(Lootster_ItemLink, button);
	end
end

-- Option Usage Update UI handler
function Lootster_UpdateOptionUsageUI(disable)
	-- do we have a usage selected?
	if ((disable ~= true) and (Lootster_UsageSel ~= nil)) then
		-- current usage row is after top row or before last row?
		if		(Lootster_Options.Usage[Lootster_UsageSel].Priority <= 2) then
			-- disable usage row move up and enable row move down buttons
			Lootster_UsageFrameMoveUp:Disable();
			Lootster_UsageFrameMoveDown:Enable();
		elseif	(Lootster_Options.Usage[Lootster_UsageSel].Priority >= (#Lootster_Options.UsageSort - 1)) then
			-- enable usage row move up and disable row move down buttons
			Lootster_UsageFrameMoveUp:Enable();
			Lootster_UsageFrameMoveDown:Disable();
		else
			-- enable usage row move buttons
			Lootster_UsageFrameMoveUp:Enable();
			Lootster_UsageFrameMoveDown:Enable();
		end
			
		-- do we have a changed value, factor or wins per raid?
		if ((Lootster_Options.Usage[Lootster_UsageSel].aFactor ~= tonumber(Lootster_UsageFrameAltFactor:GetText())) or
			(Lootster_Options.Usage[Lootster_UsageSel].cValue ~= tonumber(Lootster_UsageFrameCostValue:GetText())) or
			(Lootster_Options.Usage[Lootster_UsageSel].cFactor ~= tonumber(Lootster_UsageFrameCostFactor:GetText())) or
			(Lootster_Options.Usage[Lootster_UsageSel].WinsPerRaid ~= tonumber(Lootster_UsageFrameWinsPerRaid:GetText()))) then
			-- enable usage set button
			Lootster_UsageFrameUsageSet:Enable();
		else
			-- disable usage set button
			Lootster_UsageFrameUsageSet:Disable();
		end
		
		-- is value, factor or wins per raid different from default?
		if ((Lootster_Options.Usage[Lootster_UsageSel].aFactor ~= Lootster_Options_Default.Usage[Lootster_UsageSel].aFactor) or
			(Lootster_Options.Usage[Lootster_UsageSel].cValue ~= Lootster_Options_Default.Usage[Lootster_UsageSel].cValue) or
			(Lootster_Options.Usage[Lootster_UsageSel].cFactor ~= Lootster_Options_Default.Usage[Lootster_UsageSel].cFactor) or
			(Lootster_Options.Usage[Lootster_UsageSel].WinsPerRaid ~= Lootster_Options_Default.Usage[Lootster_UsageSel].WinsPerRaid)) then
			-- enable usage reset button
			Lootster_UsageFrameUsageReset:Enable();
		else
			-- disable usage reset button
			Lootster_UsageFrameUsageReset:Disable();
		end
	else
		-- disable usage row move buttons
		Lootster_UsageFrameMoveUp:Disable();
		Lootster_UsageFrameMoveDown:Disable();
		
		-- disable usage set and reset button
		Lootster_UsageFrameUsageSet:Disable();
		Lootster_UsageFrameUsageReset:Disable();
	end
	
	-- disabling UI?
	if (disable == true) then
		-- enable
		Lootster_UsageFrameUsageResetAll:Disable();
	else
		-- disable
		Lootster_UsageFrameUsageResetAll:Enable();
	end
end

-- Option Events Update UI handler
function Lootster_UpdateOptionEventsUI()
	-- do we have a event selected?
	if (Lootster_EventSel ~= nil) then
		-- do we have a changed 10 or 25 man DKP, Partial and Standby percentages?
		if ((Lootster_Options.Event[Lootster_EventSel].DKP10 ~= tonumber(Lootster_EventFrameDKP10:GetText())) or
			(Lootster_Options.Event[Lootster_EventSel].Partial10 ~= tonumber(Lootster_EventFramePartial10:GetText())) or
			(Lootster_Options.Event[Lootster_EventSel].Standby10 ~= tonumber(Lootster_EventFrameStandby10:GetText())) or
			(Lootster_Options.Event[Lootster_EventSel].DKP25 ~= tonumber(Lootster_EventFrameDKP25:GetText())) or
			(Lootster_Options.Event[Lootster_EventSel].Partial25 ~= tonumber(Lootster_EventFramePartial25:GetText())) or
			(Lootster_Options.Event[Lootster_EventSel].Standby25 ~= tonumber(Lootster_EventFrameStandby25:GetText())) or
			((Lootster_Options.Event[Lootster_EventSel].Time ~= nil) and (Lootster_Options.Event[Lootster_EventSel].Time ~= tonumber(Lootster_EventFrameTime:GetText())))) then
			-- enable event set button
			Lootster_EventFrameEventSet:Enable();
		else
			-- disable event set button
			Lootster_EventFrameEventSet:Disable();
		end
		
		-- is 10 or 25 man DKP, Partial and Standby percentages different from default?
		if ((Lootster_Options.Event[Lootster_EventSel].DKP10 ~= Lootster_Options_Default.Event[Lootster_EventSel].DKP10) or
			(Lootster_Options.Event[Lootster_EventSel].Partial10 ~= Lootster_Options_Default.Event[Lootster_EventSel].Partial10) or
			(Lootster_Options.Event[Lootster_EventSel].Standby10 ~= Lootster_Options_Default.Event[Lootster_EventSel].Standby10) or
			(Lootster_Options.Event[Lootster_EventSel].DKP25 ~= Lootster_Options_Default.Event[Lootster_EventSel].DKP25) or
			(Lootster_Options.Event[Lootster_EventSel].Partial25 ~= Lootster_Options_Default.Event[Lootster_EventSel].Partial25) or
			(Lootster_Options.Event[Lootster_EventSel].Standby25 ~= Lootster_Options_Default.Event[Lootster_EventSel].Standby25) or
			((Lootster_Options.Event[Lootster_EventSel].Time ~= nil) and (Lootster_Options.Event[Lootster_EventSel].Time ~= Lootster_Options_Default.Event[Lootster_EventSel].Time))) then
			-- enable event reset button
			Lootster_EventFrameEventReset:Enable();
		else
			-- disable quality reset button
			Lootster_EventFrameEventReset:Disable();
		end
	else
		-- disable event set and reset button
		Lootster_EventFrameEventSet:Disable();
		Lootster_EventFrameEventReset:Disable();
	end
end

-- Option Points Update UI handler
function Lootster_UpdateOptionPointsUI(disable)
	-- do we have a quality selected?
	if ((disable ~= true) and (Lootster_QualitySel ~= nil)) then
		-- do we have a changed qFactor or qBias?
		if ((Lootster_Options.Quality[Lootster_QualitySel].qFactor ~= tonumber(Lootster_OptionsFrameItemPointsFrameqFactor:GetText())) or
			(Lootster_Options.Quality[Lootster_QualitySel].qBias ~= tonumber(Lootster_OptionsFrameItemPointsFrameqBias:GetText()))) then
			-- enable quality set button
			Lootster_OptionsFrameItemPointsFrameQualitySet:Enable();
		else
			-- disable quality set button
			Lootster_OptionsFrameItemPointsFrameQualitySet:Disable();
		end
		
		-- is qFactor or qBias different from default?
		if ((Lootster_Options.Quality[Lootster_QualitySel].qFactor ~= Lootster_Options_Default.Quality[Lootster_QualitySel].qFactor) or
			(Lootster_Options.Quality[Lootster_QualitySel].qBias ~= Lootster_Options_Default.Quality[Lootster_QualitySel].qBias)) then
			-- enable quality reset button
			Lootster_OptionsFrameItemPointsFrameQualityReset:Enable();
		else
			-- disable quality reset button
			Lootster_OptionsFrameItemPointsFrameQualityReset:Disable();
		end
	else
		-- disable quality set and reset button
		Lootster_OptionsFrameItemPointsFrameQualitySet:Disable();
		Lootster_OptionsFrameItemPointsFrameQualityReset:Disable();
	end
	
	-- do we have a slot selected?
	if ((disable ~= true) and (Lootster_SlotSel ~= nil)) then
		-- do we have a changed sFactor?
		if (Lootster_Options.Slot[Lootster_SlotSel] ~= tonumber(Lootster_OptionsFrameItemPointsFramesFactor:GetText())) then
			-- enable slot set button
			Lootster_OptionsFrameItemPointsFrameSlotSet:Enable();
		else
			-- disable slot set button
			Lootster_OptionsFrameItemPointsFrameSlotSet:Disable();
		end
		
		-- is sFactor different from default?
		if (Lootster_Options.Slot[Lootster_SlotSel] ~= Lootster_Options_Default.Slot[Lootster_SlotSel]) then
			-- enable slot reset button
			Lootster_OptionsFrameItemPointsFrameSlotReset:Enable();
		else
			-- disable slot reset button
			Lootster_OptionsFrameItemPointsFrameSlotReset:Disable();
		end
	else
		-- disable slot set and reset button
		Lootster_OptionsFrameItemPointsFrameSlotSet:Disable();
		Lootster_OptionsFrameItemPointsFrameSlotReset:Disable();
	end
	
	-- disabling UI?
	if (disable == true) then
		-- disable
		Lootster_OptionsFrameItemPointsFrameQualityResetAll:Disable();
		Lootster_OptionsFrameItemPointsFrameSlotResetAll:Disable();
	else
		-- enable
		Lootster_OptionsFrameItemPointsFrameQualityResetAll:Enable();
		Lootster_OptionsFrameItemPointsFrameSlotResetAll:Enable();
	end
end

-- Switch MiniMap Button State handler
function Lootster_MiniMapButton_SwitchState(state)
	-- show/hide the button according to toggle
	if		(Lootster_Options.MiniMap == false) then
		-- hide the mini map frames
		Lootster_MiniMapButton:Hide();
	else
		-- show the mini map button frame
		Lootster_MiniMapButton:Show();

		-- set textures according to state
		if		(state == false) then
			-- set normal textures
			Lootster_MiniMapButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterMiniMapButton-Up");
			Lootster_MiniMapButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterMiniMapButton-Down");
		elseif	(state == true) then
			-- set highlight textures
			Lootster_MiniMapButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterMiniMapButton-HighUp");
			Lootster_MiniMapButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterMiniMapButton-HighDown");
		end
	end

	-- determine visibility of title
	if (Lootster_IsVisible() or (Lootster_Options.MiniMap == false)) then
		-- show the title
		Lootster_Title:Show();
	else
		-- hide the title
		Lootster_Title:Hide();
	end

	-- ensure the button state is set as appropriate
	if (state ~= nil) then
		Lootster_Title:SetChecked(state);
	end

	-- showing raid icon?
	if	(Lootster_Options.RaidIcon ~= true) then
		-- hide the frame
		Lootster_TitleRaidButton:Hide();
		Lootster_MiniMapRaidButton:Hide();
	else
		-- show the frame
		Lootster_TitleRaidButton:Show();
		Lootster_MiniMapRaidButton:Show();

		-- is this button operative?
		if ((Lootster_Running.BossId ~= nil) and (Lootster_Options.TrackBy ~= LOOTSTER_ENUM_TRACKBY.RAID)) then
			-- disable the guy
			Lootster_TitleRaidButton:Disable();
			Lootster_MiniMapRaidButton:Disable();
		else
			-- enable the guy
			Lootster_TitleRaidButton:Enable();		
			Lootster_MiniMapRaidButton:Enable();		

			-- set begin/end textures
			if		(Lootster_Running.RaidId == nil) then
				-- set begin textures
				Lootster_TitleRaidButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidBegButton-Up");
				Lootster_TitleRaidButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidBegButton-Down");
				Lootster_MiniMapRaidButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidBegButton-Up");
				Lootster_MiniMapRaidButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidBegButton-Down");
			else
				-- set end textures
				Lootster_TitleRaidButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidEndButton-Up");
				Lootster_TitleRaidButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidEndButton-Down");
				Lootster_MiniMapRaidButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidEndButton-Up");
				Lootster_MiniMapRaidButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterRaidEndButton-Down");
			end
		end
	end

	-- show boss icon?
	if	((Lootster_Options.TrackBy == LOOTSTER_ENUM_TRACKBY.RAID) or (Lootster_Options.BossIcon ~= true)) then
		-- hide the frame
		Lootster_TitleBossButton:Hide();
		Lootster_MiniMapBossButton:Hide();
	else
		-- show the frame
		Lootster_TitleBossButton:Show();
		Lootster_MiniMapBossButton:Show();

		-- is this button operative?
		if (Lootster_Running.RaidId == nil) then
			-- disable the guy
			Lootster_TitleBossButton:Disable();
			Lootster_MiniMapBossButton:Disable();
		else
			-- enable the guy
			Lootster_TitleBossButton:Enable();		
			Lootster_MiniMapBossButton:Enable();		

			-- set begin/end textures
			if (Lootster_Running.BossId == nil) then
				-- set begin textures
				Lootster_TitleBossButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossBegButton-Up");
				Lootster_TitleBossButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossBegButton-Down");
				Lootster_MiniMapBossButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossBegButton-Up");
				Lootster_MiniMapBossButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossBegButton-Down");
			else
				-- set end textures
				Lootster_TitleBossButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossEndButton-Up");
				Lootster_TitleBossButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossEndButton-Down");
				Lootster_MiniMapBossButton:SetNormalTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossEndButton-Up");
				Lootster_MiniMapBossButton:SetPushedTexture("Interface\\AddOns\\Lootster\\Images\\LootsterBossEndButton-Down");
			end
		end
	end
end

-- MiniMap Button Position handler
function Lootster_MiniMapButton_UpdatePosition()
	-- update the MiniMap button position
	Lootster_MiniMapButton:SetPoint("TOPLEFT", "Minimap", "TOPLEFT",
									(52 - (80 * cos(Lootster_Options.MiniMapPos))),
									(80 * sin(Lootster_Options.MiniMapPos)) - 52);

	-- update the MiniMap raid icon position
	Lootster_MiniMapRaidButton:SetPoint("TOPLEFT", "Minimap", "TOPLEFT",
										(52 - (108 * cos(Lootster_Options.MiniMapPos + 8))),
										(108 * sin(Lootster_Options.MiniMapPos + 8)) - 52);

	-- update the MiniMap boss icon position
	Lootster_MiniMapBossButton:SetPoint("TOPLEFT", "Minimap", "TOPLEFT",
										(52 - (108 * cos(Lootster_Options.MiniMapPos - 8))),
										(108 * sin(Lootster_Options.MiniMapPos - 8)) - 52);
end

-- Lootster Is Visible handler
function Lootster_IsVisible()
	-- easy peasy
	return Lootster_RollFrame:IsVisible() or Lootster_DataFrame:IsVisible() or Lootster_LootFrame:IsVisible() or 
		   Lootster_RaidFrame:IsVisible() or Lootster_ItemFrame:IsVisible() or Lootster_RuleFrame:IsVisible() or 
		   Lootster_OptionsFrame:IsVisible();
end

-- Send Broadcast Message handler
function Lootster_SendAddon(msg, show)
	local   chan = "SAY";

	-- deterine the channel we should broadcast on
	if		(GetNumGroupMembers() > 0) then
		chan = "RAID";
	elseif	(GetNumSubgroupMembers() > 0) then
		chan = "PARTY";
	end

	-- are we active?
	if (((Lootster_Options.Active == true) or (show == true)) and (chan ~= "SAY")) then
		-- is this message over length?
		if (string.len(msg) > LOOTSTER_ADDON_MESSAGELEN) then
			-- chunk up the message
			repeat
				-- get sub-message
				sub = string.sub(msg, 1, (LOOTSTER_ADDON_MESSAGELEN - 1))..LOOTSTER_ADDON_POSTFIXCONT;

				-- and slice up current message
				msg = string.sub(msg, LOOTSTER_ADDON_MESSAGELEN);

				-- send sub-message to party/raid addon
				SendAddonMessage(LOOTSTER_ADDON_PREFIX, sub, chan);

				-- if debugging, send to the debug window
				if (Lootster_InDebugger == true) then
					-- add sub-message to debugging window
					Lootster_SendDebugging(sub);
				end
			until (string.len(msg) <= LOOTSTER_ADDON_MESSAGELEN);
		end

		-- send final sub-message to party/raid addon
		SendAddonMessage(LOOTSTER_ADDON_PREFIX, msg, chan);

		-- if debugging, send to the debug window
		if (Lootster_InDebugger == true) then
			-- add final sub-message to debugging window
			Lootster_SendDebugging(msg);
		end
	end
end

-- Send Broadcast Message handler
function Lootster_SendBroadcast(msg, show, chan)
	-- no channel means default of SAY
	if (chan == nil) then
		chan = "SAY";
	end

	-- deterine the channel we should broadcast on
	if		(GetNumGroupMembers() > 0) then
		chan = "RAID";
	elseif	(GetNumSubgroupMembers() > 0) then
		chan = "PARTY";
	end

	-- are we active?
	if (((Lootster_Options.Active == true) or (show == true)) and (chan ~= "SAY")) then
		-- send to party/raid chat
		SendChatMessage(msg, chan);
	else
		-- send to ourselves and let it decide
		Lootster_SendPrivate(chan, msg);
	end
end

-- Send Raid Warning Message handler
function Lootster_SendRaidWarning(rwtype, msg, show, chan)
	-- don't bother if not active, not enabled or not promoted or no raid warning type
	if (((Lootster_Options.Active == true) or (show == true)) and (rwtype ~= nil) and (Lootster_Options.RWRoll == true) and ((UnitIsGroupLeader("player") == true) or (UnitIsGroupAssistant("player") == true))) then
		-- punt out if all raid messages are switched on or this specific type
		if ((Lootster_Options.RWRollBy == LOOTSTER_ENUM_RAIDWARN.ALL) or (Lootster_Options.RWRollBy == rwtype)) then
			-- send to raid warning chat
			SendChatMessage(msg, "RAID_WARNING");
		end
	end
	
	-- and also broadcast as normal
	Lootster_SendBroadcast(msg, show, chan);
end

-- Send Private Message handler
function Lootster_SendPrivate(player, msg, show, sync)
	-- are we active or we always show?
	if		(((Lootster_Options.Active == true) or (show == true)) and (player ~= "SAY")) then
		-- no, so place this message on the To Whisper queue
		Lootster_ToWhisper_Enqueue(player, msg, sync);
	elseif	(Lootster_Options.DebugMsgs == true) then
		-- debugging, send to ourselves
		if (DEFAULT_CHAT_FRAME) then
			DEFAULT_CHAT_FRAME:AddMessage(string.format("<To %s> %s", player, msg));
		end
	end
end

-- Send Attend Announce Message handler
function Lootster_SendAnnouncement(msg, show)
	-- are we announcing, and if so, are we active or we always show?
	if		(Lootster_Options.AttendAnnounce == true) then
		-- to party/raid?
		if (Lootster_Options.AttendGroup == true) then
			-- broadcast to party/raid
			Lootster_SendBroadcast(msg, show);
		end
		
		-- to guild?
		if (Lootster_Options.AttendGuild == true) then
			-- broadcast to party/raid
			Lootster_SendBroadcast(msg, show, "GUILD");
		end
		
		-- to custom channel and we are active or we always show??
		if ((Lootster_Options.AttendCustom == true) and (Lootster_ChannelID ~= nil) and (Lootster_Options.Active == true) or (show == true)) then
			-- broadcast to custom channel
			SendChatMessage(msg, "CHANNEL", Lootster_Language, Lootster_ChannelID);
		end
	elseif	(Lootster_Options.DebugMsgs == true) then
		-- debugging, send to ourselves
		if (DEFAULT_CHAT_FRAME) then
			DEFAULT_CHAT_FRAME:AddMessage(string.format("<To Announce> %s", msg));
		end
	end
end

-- Send Debugging Message handler
function Lootster_SendDebugging(msg)
	local	text;

	-- get the current text, stripping the trailing line break
	text = Lootster_RemoveTrailingLineBreak(Lootster_DebuggingFrameMessage:GetText());

	-- add a line break if we have some previous text
	if (text ~= "") then
		text = text.."\n";
	end

	-- set the text with new message in the debugging window
	Lootster_DebuggingFrameMessage:SetText(Lootster_AppendTrailingLineBreak(text..msg));
end

-- Player Inquiry handler
function Lootster_PlayerInquiry(player, msg, noop)
	local	_, cmd, subcmd, syncmsg, synccmd, payload;

	local	proc = false;
	local	help = false;

	-- we received a whisper - see if it's a lootster command or message.  Chunk it up baby
	_, _, cmd		= string.find(msg, LOOTSTER_CMD_PATTERN);
	_, _, subcmd	= string.find(msg, LOOTSTER_SUBCMD_PATTERN);
	_, _, syncmsg	= string.find(msg, LOOTSTER_SYNC_IMP_PATTERN);

	if		(cmd == LOOTSTER_CMD_RESETUI) then
		-- reset UI command
		Lootster_Option_ResetUI_OnClick(Lootster_OptionsFrameResetUI, "LeftButton");
	elseif	(cmd == LOOTSTER_CMD_HERE) then
		-- Here command - no subcommand for attendance
		if		(noop == true) then
			-- no-op 
		elseif	(Lootster_Running.BossId == nil) then
			-- no running boss
			Lootster_SendPrivate(player, LOOTSTER_MSG_HERE_NOBOSS);
		elseif	(Lootster_Roster[player] ~= nil) then
			-- already in  party/raid
			Lootster_SendPrivate(player, LOOTSTER_MSG_HERE_INRAID);
		elseif	(Lootster_Options.AttendHere ~= true) then
			-- standby attendance is not enabled
			Lootster_SendPrivate(player, LOOTSTER_MSG_HERE_NOSTANDBY);
		else
			local	main;
			
			-- we want to take attendance for this play.  First, attempt to get the main
			main = Lootster_GetAltMain(player);

			-- is this attendance already in the running boss?
			if (Lootster_Boss[Lootster_Running.BossId].AttendSet[main] == nil) then
				-- insert new guy into boss, forcing a private tell
				Lootster_InsertAttend(Lootster_Running.BossId, Lootster_CreateAttend(Lootster_NewAttend(main, player, 
																										LOOTSTER_ENUM_ATTENDED.STANDBY, 0)), false);
				
				-- update raid attend UI
				Lootster_UpdateRaidAttendUI();
			else
				local	attendId;
				
				-- retrieve the attendance Id
				attendId = Lootster_Boss[Lootster_Running.BossId].AttendSet[main];

				-- make sure we don't downgrade him, and ignore if already on standby
				if ((Lootster_Attend[attendId].Attended > LOOTSTER_ENUM_ATTENDED.FULL) and 
					(Lootster_Attend[attendId].Attended ~= LOOTSTER_ENUM_ATTENDED.STANDBY)) then
					-- update the attendance DKP
					Lootster_UpdateAttend(attendId, LOOTSTER_ENUM_ATTENDED.STANDBY, false);
				
					-- update raid attend UI
					Lootster_UpdateRaidAttendUI();
				else
					-- no change to attendance - let them know
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDIGNORED, 
															   LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended]));
				end
			end

			-- resort data DKP using current sort
			Lootster_Data_DKP_Sort(nil);

			-- resort data attend using current sort
			Lootster_Data_Attend_Sort(nil);

			-- resort data adjust using current sort
			Lootster_Data_Adjust_Sort(nil);

			-- resort raid raid using current sort
			Lootster_Raid_Raid_Sort(nil);

			-- resort raid boss using current sort
			Lootster_Raid_Boss_Sort(nil);

			-- resort raid attend using current sort
			Lootster_Raid_Attend_Sort(nil);
		end
		
		-- processed this guy
		proc = true;		
	elseif	(cmd == LOOTSTER_CMD_LOOT) then
		-- loot command - see what the subcommand was
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd ~= nil) then
			-- see what the subcommand is
			if		(subcmd == LOOTSTER_SUBCMD_HELP) then
				-- echo help
				Lootster_Rule_ShowHelp_OnClick(Lootster_RuleFrameShowHelp, "LeftButton", player);
			elseif	(subcmd == LOOTSTER_SUBCMD_ROLL) then
				-- echo player's roll command
				Lootster_EchoPlayerRoll(player, true);
			elseif	(subcmd == LOOTSTER_SUBCMD_USAGE) then
				-- echo usage roll commands
				Lootster_EchoUsageRolls(player);
			elseif	(subcmd == LOOTSTER_SUBCMD_RULES) then
				-- echo rules
				Lootster_Rule_ShowRules_OnClick(Lootster_RuleFrameShowRules, "LeftButton", player);
			elseif	(subcmd == LOOTSTER_SUBCMD_VERSION) then
				-- echo current version
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_LOAD, LOOTSTER_VERSION), true);
			else
				-- please help me
				help = true;
			end
		else
			-- please help me
			help = true;
		end

		-- processed this guy
		proc = true;
	elseif	(cmd == LOOTSTER_CMD_ATT) then
		-- attend command - see what the subcommand is, if any
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd == nil) then
			-- echo player's attendances
			Lootster_EchoPlayerAttends(player, player);
		else
			local	class, name;

			-- see what the subcommand is a class or a player
			class = string.lower(subcmd);

			name = string.lower(subcmd);

			if (Lootster_ClassLower[class] ~= nil) then
				-- they want the adjusts for players in the class
				for playerkey, rosRec in pairs(Lootster_Roster) do
					-- is this player of that class?
					if (rosRec.ClassType == Lootster_ClassLower[class]) then
						-- echo this player's attendances
						Lootster_EchoPlayerAttends(player, playerkey);
					end
				end
			else
				-- they want the attends for matching players
				for playerkey, rosRec in pairs(Lootster_Roster) do
					-- does this player match the passed name
					if (string.find(rosRec.Name, name) ~= nil) then
						-- echo this player's attendances
						Lootster_EchoPlayerAttends(player, playerkey);
					end
				end
			end
		end

		-- processed this guy
		proc = true;
	elseif	(cmd == LOOTSTER_CMD_ADJ) then
		-- adjust command - see what the subcommand is, if any
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd == nil) then
			-- echo player's adjustments
			Lootster_EchoPlayerAdjusts(player, player);
		else
			local	class, name;

			-- see what the subcommand is a class or a player
			class = string.lower(subcmd);

			name = string.lower(subcmd);

			if (Lootster_ClassLower[class] ~= nil) then
				-- they want the adjusts for players in the class
				for playerkey, rosRec in pairs(Lootster_Roster) do
					-- is this player of that class?
					if (rosRec.ClassType == Lootster_ClassLower[class]) then
						-- echo this player's adjustments
						Lootster_EchoPlayerAdjusts(player, playerkey);
					end
				end
			else
				-- they want the adjusts for matching players
				for playerkey, rosRec in pairs(Lootster_Roster) do
					-- does this player match the passed name
					if (string.find(rosRec.Name, name) ~= nil) then
						-- echo this player's adjustments
						Lootster_EchoPlayerAdjusts(player, playerkey);
					end
				end
			end
		end

		-- processed this guy
		proc = true;
	elseif	((cmd == LOOTSTER_CMD_DKP) or (cmd == LOOTSTER_CMD_EPGP)) then
		-- DKP or EPGP command - see what the subcommand is, if any
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd == nil) then
			-- echo player's points
			Lootster_EchoPlayerPoints(player, player);
		else
			local	class, name;

			-- see what the subcommand is a class or a player
			class = string.lower(subcmd);

			name = string.lower(subcmd);

			if (LOOTSTER_CLASS[class] ~= nil) then
				-- they want the DKP for players in the class
				for playerkey, rosRec in pairs(Lootster_Roster) do
					-- is this player of that class?
					if (rosRec.ClassType == LOOTSTER_CLASS[class].ClassType) then
						-- echo this player's points
						Lootster_EchoPlayerPoints(player, playerkey);
					end
				end
			else
				-- they want the DKP for matching players
				for playerkey, rosRec in pairs(Lootster_Roster) do
					-- does this player match the passed name
					if (string.find(rosRec.Name, name) ~= nil) then
						-- echo this player's points
						Lootster_EchoPlayerPoints(player, playerkey);
					end
				end
			end
		end

		-- processed this guy
		proc = true;
	elseif	(cmd == LOOTSTER_CMD_MOB) then
		-- item command - see what the item subcommand is
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd == nil) then
			-- please help me
			help = true;
		else
			local	name;

			name = string.lower(subcmd);

			-- they want the DKP for items dropped by matching mobs
			for mobkey, mobsRec in pairs(Lootster_MobsDKP) do
				-- does this mob match the passed name
				if (string.find(mobsRec.Name, name) ~= nil) then
					-- hammer through all items looking for items dropped by this guy
					for itemKey, itemRec in pairs(Lootster_ItemDKP) do
						-- does this player match the passed name
						if (mobkey == itemRec.Mob) then
							-- echo this item's points
							Lootster_EchoItemPoints(player, itemKey);
						end
					end
				end
			end
		end

		-- processed this guy
		proc = true;
	elseif	(cmd == LOOTSTER_CMD_ITEM) then
		-- item command - see what the item subcommand is
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd == nil) then
			-- please help me
			help = true;
		else
			local	name;

			name = string.lower(subcmd);

			-- they want the DKP for matching items
			for itemKey, itemRec in pairs(Lootster_ItemDKP) do
				-- does this player match the passed name
				if (string.find(itemRec.Name, name) ~= nil) then
					-- echo this item's points
					Lootster_EchoItemPoints(player, itemKey);
				end
			end
		end

		-- processed this guy
		proc = true;
	elseif	(cmd == LOOTSTER_CMD_TELL) then
		-- tell command - see what the subcommand was
		if		(noop == true) then
			-- no-op 
		elseif	(subcmd ~= nil) then
			-- make sure we create a player entry, as necessary
			if (Lootster_Players[player] == nil) then
				Lootster_Players[player] = {};
			end

			-- see what the subcommand is
			if		(subcmd == LOOTSTER_SUBCMD_ROLL) then
				-- toggle this player's roll whispers
				Lootster_Players[player].AckRoll = not Lootster_TestPlayerTell(player, "AckRoll");

				-- let em know
				if (Lootster_Players[player].AckRoll == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKROLL, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKROLL, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_NOINFO) then
				-- toggle this player's no DKP information on NEED roll call
				Lootster_Players[player].AckNoInfo = not Lootster_TestPlayerTell(player, "AckNoInfo");

				-- let em know
				if (Lootster_Players[player].AckNoInfo == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOINFO, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOINFO, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_NOCALL) then
				-- toggle this player's no call whispers
				Lootster_Players[player].AckNoCall = not Lootster_TestPlayerTell(player, "AckNoCall");

				-- let em know
				if (Lootster_Players[player].AckNoCall == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOCALL, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOCALL, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_NOROLL) then
				-- toggle this player's no laggard roll command whispers
				Lootster_Players[player].AckNoRoll = not Lootster_TestPlayerTell(player, "AckNoRoll");

				-- let em know
				if (Lootster_Players[player].AckNoRoll == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOROLL, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOROLL, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_NOHELP) then
				-- toggle this player's no help on bad whisper command whispers
				Lootster_Players[player].AckNoHelp = not Lootster_TestPlayerTell(player, "AckNoHelp");

				-- let em know
				if (Lootster_Players[player].AckNoHelp == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOHELP, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOHELP, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_NOATT) then
				-- toggle this player's no attendance tracking change whispers
				Lootster_Players[player].AckNoAtt = not Lootster_TestPlayerTell(player, "AckNoAtt");

				-- let em know
				if (Lootster_Players[player].AckNoAtt == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOATT, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOATT, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_NOADJ) then
				-- toggle this player's no adjustment tracking change whispers
				Lootster_Players[player].AckNoAdj = not Lootster_TestPlayerTell(player, "AckNoAdj");

				-- let em know
				if (Lootster_Players[player].AckNoAdj == true) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOADJ, LOOTSTER_TOGGLE_ON));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_TELL_TOGGLE, LOOTSTER_TELL_ACKNOADJ, LOOTSTER_TOGGLE_OFF));
				end
			elseif	(subcmd == LOOTSTER_SUBCMD_RESET) then
				-- remove any player whisper toggle overrides
				Lootster_Players[player] = nil;

				-- let em know
				Lootster_SendPrivate(player, LOOTSTER_MSG_TELL_RESET);
			else
				-- please help me
				help = true;
			end
		else
			-- please help me
			help = true;
		end

		-- processed this guy
		proc = true;
	elseif	(syncmsg ~= nil) then
		if (noop == true) then
			-- no-op 
			proc = true;
		else
			-- is this a continutation record?
			if		((string.len(msg) == LOOTSTER_SYNC_MESSAGELEN) and (string.sub(msg, -1) == LOOTSTER_SYNC_POSTFIXCONT)) then
				-- continuation records are received after initiation
				if	((Lootster_SyncType == nil) or (Lootster_SyncUser ~= player)) then
					-- eep!  Player is not our synchronise target - no message as it can spam
					return false;
				end

				-- have we a current continuation record?
				if (Lootster_SyncCont == nil) then
					-- snarf initial continuation record
					Lootster_SyncCont = string.sub(syncmsg, 1, -2);
				else
					-- next continuation record - just add payload sans continuation marker
					Lootster_SyncCont = Lootster_SyncCont..string.sub(syncmsg, 1, -2);
				end

				-- update timers so we don't timeout
				Lootster_Sync_StateUpdate();
				return true;
			elseif	(Lootster_SyncCont ~= nil) then
				-- continuation records are received after initiation
				if	((Lootster_SyncType == nil) or (Lootster_SyncUser ~= player)) then
					-- eep!  Player is not our synchronise target - no message as it can spam
					return false;
				end

				-- final continuation record - add payload and make this the real message
				syncmsg = Lootster_SyncCont..syncmsg;

				-- reset continuation record
				Lootster_SyncCont = nil;
			end

			-- extract synchronise command and payload
			_, _, synccmd, payload	= string.find(syncmsg, LOOTSTER_SYNC_IMP_COMMAND);

			-- Lootster to Lootster synchronise command
			proc = Lootster_Sync_Process(player, synccmd, payload);
		end
	end

	-- are they are noddy?
	if (help == true) then
		-- have they switched off help on bad whispers?
		if (Lootster_TestPlayerTell(player, "AckNoHelp") == true) then
			-- tell them they got it wrong, then echo help
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_BADCOMMAND, msg));
	
			Lootster_Rule_ShowHelp_OnClick(Lootster_RuleFrameShowRules, "LeftButton", player);
		end
	end

	return proc;
end

-- Add Roller
function Lootster_AddRoller(player)
	-- if the roll table is empty, we bookkeep all the guys so we have a visual
	-- on who has and has not rolled
	if (#Lootster_RollsSort == 0) then
		-- add this roller first
		Lootster_AddPlayer(player);

		-- do the rest of the raid
		for key, value in pairs(Lootster_Roster) do
			-- in the roll list?
			if (Lootster_Rolls[key] == nil) then
				-- add this player
				Lootster_AddPlayer(key);
			end
		end
	else
		-- just make sure this guy is added (joined after roll started)
		Lootster_AddPlayer(player);
	end
end

-- Add Player
function Lootster_AddPlayer(player)
	-- is this guy in the roll roster?
	if (Lootster_RosterRoll[player] == nil) then
		-- ignore this guy
		return;
	end

	-- is the player already in the table?
	if (Lootster_Rolls[player] == nil) then
		-- nope, so insert with default data
		Lootster_Rolls[player] = Lootster_NewRolls(player, nil, Lootster_Roster[player].ClassType, Lootster_RosterRoll[player].DKP, Lootster_RosterRoll[player].Tier, 
												   Lootster_RosterRoll[player].Member, Lootster_RosterRoll[player].Toon);
	end
end

-- Ask Player for a Roll handler
function Lootster_AskForRoll(player)
	-- see what roll mode we are in
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		local	rngRoll;

		-- determine DKP roll
		rngRoll = Lootster_GetPlayerRoll(player);
		
		-- bang out usual roll information if not usage roll
		if (Lootster_NBG ~= LOOTSTER_NBG_USAGE) then
			-- ask them to roll
			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASKN, Lootster_NBG, rngRoll));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASKN_LINK, Lootster_NBG, Lootster_ItemLink, rngRoll));
			end
		else
			-- ask them to roll
			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASKU, Lootster_NBG));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASKU_LINK, Lootster_NBG, Lootster_ItemLink));
			end
		end
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- 100/1000 or Need then Greed?
		if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
			-- ask them to roll 100/1000
			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASK1000, Lootster_NBG));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASK1000_LINK, Lootster_NBG, Lootster_ItemLink));
			end
		elseif	((Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYNEEDGREED) or 
				 (Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL)) then
			-- ask them to roll 100
			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASK100, Lootster_NBG));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ASK100_LINK, Lootster_NBG, Lootster_ItemLink));
			end
		end
	end
end

-- Update Roll Text handler
function Lootster_UpdateRoll()
	-- update our roll button text
	if		((Lootster_NBG == LOOTSTER_NBG_TIED) and (Lootster_Rolls[Lootster_Self] ~= nil)) then
		-- tied roll is 100
		Lootster_SelfRoll = 100;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- get our DKP roll
		Lootster_SelfRoll = Lootster_GetPlayerRoll(Lootster_Self);
	else
		-- default roll
		Lootster_SelfRoll = 100;
	end

	-- format for the roll button
	Lootster_RollFrameRoll:SetFormattedText(LOOTSTER_ROLL_ROLLRNG_FMT, Lootster_SelfRoll);
end

-- Is Usage Restricted handler
function Lootster_IsUsageRestricted(usage, class)
	local	isRoll, isClass;
	
	-- roll and class are not initially restricted
	isRoll = false;
	isClass = false;
	
	-- are we to check current roll usage?
	if (usage ~= nil) then
		-- is current NBG specifically set?
		if ((usage ~= nil) and (usage ~= LOOTSTER_ENUM_USAGE.MANUAL)) then
			-- we can check against this usage
			isRoll = (Lootster_Options.Usage[usage].Restrict == true) and (Lootster_ClassRestricted == true);
		end
		
		-- no class check means we simply return roll check
		if (class == nil) then
			return isRoll;
		end
	end
	
	-- are we to check for a specific class?
	if (class ~= nil) then
		-- determine if class itself restricted
		isClass = (Lootster_ClassRestricted == true) and ((Lootster_ClassRestrictions[class] == nil) or (Lootster_ClassRestrictions[class] == false) or not Lootster_ClassRestrictions[class]);
		
		-- if usage was nil then only return class check
		if (usage == nil) then
			return isClass;
		end
	end
	
	-- must be roll restricted and class restricted to apply
	return isRoll and isClass;
end

-- Reset Class handler
function Lootster_ResetClass()
	-- reset restricted count
	Lootster_RestrictedCount = 0;

	-- make sure we clear current class restriction flags
	Lootster_ClassRestricted = false;
	Lootster_ClassRestrictedLock = false;

	-- no classes
	Lootster_ClassRestrictions = {};

	-- reset count
	Lootster_ClassRestrictionsN = 0;

	-- reset the restriction masks
	Lootster_ClassRestrictionsMaskOrig = 0;
	Lootster_ClassRestrictionsMaskCurr = 0;
end

-- Update Class handler
function Lootster_UpdateClassUI()
	local	cix;
	local	button;

	-- set the class restrictions
	for cix = 1, #LOOTSTER_CLASS_SORT, 1 do
		-- get the class item button
		button = _G["Lootster_ClassFrameClass"..cix];

		-- is this guy allowed?
		if ((Lootster_ClassRestrictions[LOOTSTER_CLASS_SORT[cix]] ~= nil) and (Lootster_ClassRestrictions[LOOTSTER_CLASS_SORT[cix]] == true)) then
			button:SetChecked(true);
		else
			button:SetChecked(false);
		end

		-- enable/disable the button depending on whether these class restrictions are locked down
		if (Lootster_ClassRestrictedLock == true) then
			button:Disable();
		else
			button:Enable();
		end
	end
end

-- Create Restrictions handler
function Lootster_CreateRestricts(itemLink)
	local	_, itemText = "";
	local	permitted = "";

	local	restrictions = {};
	local	restrictionsN = 0;

	-- have we been passed a link, or are we using current?
	if (itemLink == Lootster_ItemLink) then
		-- use current text and restrictions
		itemText = Lootster_ItemText;

		restrictions = Lootster_ClassRestrictions;
		restrictionsN = Lootster_ClassRestrictionsN;
	else
		-- retrieve text and restrictions for the link
		_, itemText, _, _, _, restrictions, restrictionsN = Lootster_GetItemDetails(itemLink);
	end

	-- see if we have class restrictions
	if (restrictionsN > 0) then
		local	class, count, ix;
		local	classes = {};

		-- build an alphabetical list of restricted classes
		for ix, flag in ipairs(LOOTSTER_CLASS_SORT) do
			-- this class restricted?
			if ((Lootster_ClassIgnore[LOOTSTER_CLASS_SORT[ix]] == nil) and (restrictions[LOOTSTER_CLASS_SORT[ix]] == true)) then
				table.insert(classes, LOOTSTER_CLASS_SORT[ix]);
			end
		end

		-- now build the class please and class ignore texts
		count = #classes;

		for ix=1, count, 1 do
			-- add plural class to please text
			permitted = permitted..LOOTSTER_CLASS[classes[ix]].Plural;

			if		(ix < (count - 1)) then
				permitted = permitted..LOOTSTER_MSG_SEP;
			elseif (ix == (count - 1)) then
				permitted = permitted..LOOTSTER_MSG_AND;
			end
		end

		-- do we have no class restrictions?
		if (count == 0) then
			-- let them know there are none
			permitted = LOOTSTER_MSG_NORESTRICTIONS;
		end
	else
		-- let them know there are none
		permitted = LOOTSTER_MSG_NORESTRICTIONS;
	end
	
	return itemText, permitted;
end

-- Update Restricted Count handler
function Lootster_UpdateRestricted()
	-- reset restricted count
	Lootster_RestrictedCount = 0;

	-- hammer through the roster counting allowed classes
	for player, rosRec in pairs(Lootster_Roster) do
		-- is this player allowed to roll?
		if ((Lootster_ClassRestrictions[rosRec.ClassType] ~= nil) and (Lootster_ClassRestrictions[rosRec.ClassType] == true)) then
			Lootster_RestrictedCount = Lootster_RestrictedCount + 1;
		end
	end
end

-- Process Roll handler
function Lootster_ProcessRoll(player, roll, minRoll, maxRoll)
	local   rngRoll;

	-- if no roll call, are we in Normal 100/1000 or FFA mode using auto-roll?
	if ((Lootster_NBG == nil) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormAutoRoll == true)) then
		-- auto-roll only in 100/1000 or FFA mode...
		if ((Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) or (Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL)) then
			-- woot!  Initiate the roll by type
			if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
				-- 100/1000 auto-roll, so force that mode
				Lootster_Roll_1001000Roll_OnClick(Lootster_RollFrame1001000Roll, "LeftButton");
			elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL) then
				-- FFA auto-roll, so force that mode
				Lootster_Roll_FreeForAllRoll_OnClick(Lootster_RollFrameFreeForAllRoll, "LeftButton");
			end

			-- is the Looster window open?
			if (not Lootster_IsVisible()) then
				-- Lootster is closed, so are we to open on roll?
				if (Lootster_Options.NormAutoOpen == true) then
					-- yup, so fire up the window
					Lootster_OnToggle(self);
				else
					-- toggle highligh state of MiniMap button/title
					Lootster_MiniMapButton_SwitchState(true);
				end
			end
		end
	end

	-- make sure there has been a roll call and player is in roster
	if		(Lootster_NBG == nil) then
		-- are we to ack the no call for roll?
		if (Lootster_TestPlayerTell(player, "AckNoCall") == true) then
			-- format the no roll call message for the player and let them know
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NONBGPLAYER, Lootster_Self));

			-- format the no roll call message for ourselves and let us know
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_NONBGSELF, player));
		end
		return;
	elseif	(Lootster_Roster[player] == nil) then
		-- format the no member message for ourselves and let us know
		Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_NOTMEMBER, player));
		return;
	elseif	(Lootster_NBG == LOOTSTER_NBG_TIED) then
		-- in a tied situation, only the tied players are allowed to roll
		if (Lootster_Rolls[player] == nil) then
			-- too bad buddy - format the not tied winner message
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NOTTIEDPLAYER));

			-- format the not tied winner message for ourselves and let us know
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_NOTTIEDSELF, player));
			return;
		end
	end

	-- convert roll values
	roll	= tonumber(roll);
	minRoll	= tonumber(minRoll);
	maxRoll	= tonumber(maxRoll);

	-- if we are not using DKP, rolls must be normal (1-100)
	if		(Lootster_NBG == LOOTSTER_NBG_TIED) then
		-- tied roll range is 100
		rngRoll = 100;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- calculate DKP roll
		rngRoll = Lootster_GetPlayerRoll(player);
		
		-- if this is usage rolling, determine if the roll is valid
		if (Lootster_NBG == LOOTSTER_NBG_USAGE) then
			-- cross check in roll map
			if		(LOOTSTER_USAGE_ROLL[maxRoll] == nil) then
				-- invalid roll
				rngRoll = nil;
			elseif	(Lootster_Options.Usage[LOOTSTER_USAGE_ROLL[maxRoll]].Use ~= true) then
				-- disallowed roll
				rngRoll = -maxRoll;
			else
				-- valid roll
				rngRoll = maxRoll;
			end
		end
	else
		-- normal is 100
		rngRoll = 100;
	end

	-- is this guy allowed to roll?
	if		(Lootster_RosterRoll[player] == nil) then
		-- naughty naughty bad Zoot!
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NOTROLLCLASS, roll, minRoll, maxRoll, Lootster_NBG_ClassIgnore));
		return;
	elseif	((Lootster_NBG_Usage ~= LOOTSTER_ENUM_USAGE.MANUAL) and (Lootster_IsUsageRestricted(Lootster_NBG_Usage, Lootster_Roster[player].ClassType) == true)) then
		-- this is a specific usage call, and they rolled on a class restricted item for something that is class restricted against them
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NOTROLLCLASS, roll, minRoll, maxRoll, Lootster_NBG_ClassIgnore));
		return;
	elseif	((Lootster_NBG_Usage == LOOTSTER_ENUM_USAGE.MANUAL) and (Lootster_IsUsageRestricted(LOOTSTER_USAGE_ROLL[maxRoll], Lootster_Roster[player].ClassType) == true)) then
		-- this is a 100/1000 or USAGE call, where the max roll determines the usage.  The roll is for something that is class restricted against them
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NOTROLLCLASS, roll, minRoll, maxRoll, Lootster_NBG_ClassIgnore));
		return;
	end

	-- bookkeep the roller
	Lootster_AddRoller(player);

	-- check for reclaim, valid and duplicate rolls
	if		((Lootster_Rolls[player].Roll ~= nil) and (Lootster_Rolls[player].Roll > 0)) then
		-- if this is 100/1000 mode, then they are allowed to downgrade from Need to Greed
		if		((Lootster_NBG == LOOTSTER_NBG_1001000) and (minRoll == 1) and (maxRoll == 1000) and (Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.MAINNEED)) then
			-- are we to ack the roll?
			if (Lootster_TestPlayerTell(player, "AckRoll") == true) then
				-- format the ack message and let them know
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKROLLTOGREED, roll, minRoll, maxRoll));
			end

			-- bookkeep the roll
			Lootster_Rolls[player].Roll = roll;

			-- this is now a Greed
			Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.GREED;
		elseif	((Lootster_NBG == LOOTSTER_NBG_USAGE) and (rngRoll ~= nil) and
				 (Lootster_Options.Usage[Lootster_Rolls[player].Usage].Priority < Lootster_Options.Usage[LOOTSTER_USAGE_ROLL[maxRoll]].Priority)) then
			-- they are downgrading their current roll.  Are we to ack the roll?
			if (Lootster_TestPlayerTell(player, "AckRoll") == true) then
				-- format the ack message and let them know
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKROLLTODOWNGRADE, LOOTSTER_USAGEDKP_LIST[Lootster_Rolls[player].Usage],
														   LOOTSTER_USAGEDKP_LIST[LOOTSTER_USAGE_ROLL[maxRoll]], roll, minRoll, maxRoll));
			end

			-- bookkeep the roll
			Lootster_Rolls[player].Roll = roll;
			
			-- remove hold, if any
			Lootster_Rolls[player].Hold = false;

			-- this is now downgraded
			Lootster_Rolls[player].Usage = LOOTSTER_USAGE_ROLL[maxRoll];
		else
			-- format the duplicate message and let them know
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_DUP, roll, minRoll, maxRoll, Lootster_Rolls[player].Roll));

			-- bookkeep the duplicate roll
			if (Lootster_Rolls[player].Dup == nil) then
				Lootster_Rolls[player].Dup = 1;
			else
				Lootster_Rolls[player].Dup = Lootster_Rolls[player].Dup + 1;
			end
		end
	elseif	((Lootster_Rolls[player].Roll ~= nil) and (Lootster_Rolls[player].Roll < 0)) then
		-- if this is 100/1000 mode, then they are allowed to downgrade from Need to Greed
		if ((Lootster_NBG == LOOTSTER_NBG_1001000) and (minRoll == 1) and (maxRoll == 1000) and (Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.MAINNEED)) then
			-- are we to ack the roll?
			if (Lootster_TestPlayerTell(player, "AckRoll") == true) then
				-- format the ack message and let them know
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKROLLTOGREED, roll, minRoll, maxRoll));
			end

			-- bookkeep the roll
			Lootster_Rolls[player].Roll = roll;

			-- this is now a Greed
			Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.GREED;

			-- did this come from us?
			if (player == Lootster_Self) then
				-- update the text to indicate pass
				Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_PASS);
			end
		elseif	((Lootster_NBG == LOOTSTER_NBG_USAGE) and (rngRoll ~= nil) and
				 (Lootster_Options.Usage[Lootster_Rolls[player].Usage].Priority < Lootster_Options.Usage[LOOTSTER_USAGE_ROLL[maxRoll]].Priority)) then
			-- they are downgrading their current roll.  Are we to ack the roll?
			if (Lootster_TestPlayerTell(player, "AckRoll") == true) then
				-- format the ack message and let them know
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKROLLTODOWNGRADE, LOOTSTER_USAGEDKP_LIST[Lootster_Rolls[player].Usage],
														   LOOTSTER_USAGEDKP_LIST[LOOTSTER_USAGE_ROLL[maxRoll]], roll, minRoll, maxRoll));
			end

			-- bookkeep the roll
			Lootster_Rolls[player].Roll = roll;
			
			-- remove hold, if any
			Lootster_Rolls[player].Hold = false;

			-- this is now downgraded
			Lootster_Rolls[player].Usage = LOOTSTER_USAGE_ROLL[maxRoll];
		else
			-- they passed a previous roll - let them know they need to reclaim rather than reroll
			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_MUSTRECLAIMROLL, -Lootster_Rolls[player].Roll, Lootster_NBG));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_MUSTRECLAIMROLL_LINK, -Lootster_Rolls[player].Roll, 
									 Lootster_NBG, Lootster_ItemLink));
			end
			return;
		end
	elseif	(minRoll ~= 1) then
		-- format the reject message and let them know
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_REJECT, roll, minRoll, maxRoll));

		-- inform user to roll
		Lootster_AskForRoll(player);

		-- bookkeep the bad roll
		if (Lootster_Rolls[player].Bad == nil) then
			Lootster_Rolls[player].Bad = 1;
		else
			Lootster_Rolls[player].Bad = Lootster_Rolls[player].Bad + 1;
		end
	elseif	((Lootster_NBG == LOOTSTER_NBG_1001000) and (maxRoll ~= rngRoll) and (maxRoll ~= 1000)) then
		-- format the reject message and let them know
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_REJECT, roll, minRoll, maxRoll));

		-- inform user to roll
		Lootster_AskForRoll(player);

		-- bookkeep the bad roll
		if (Lootster_Rolls[player].Bad == nil) then
			Lootster_Rolls[player].Bad = 1;
		else
			Lootster_Rolls[player].Bad = Lootster_Rolls[player].Bad + 1;
		end
	elseif	((Lootster_NBG ~= LOOTSTER_NBG_1001000) and (maxRoll ~= rngRoll)) then
		-- format the reject message and let them know
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_REJECT, roll, minRoll, maxRoll));

		-- inform user to roll
		Lootster_AskForRoll(player);

		-- bookkeep the bad roll
		if (Lootster_Rolls[player].Bad == nil) then
			Lootster_Rolls[player].Bad = 1;
		else
			Lootster_Rolls[player].Bad = Lootster_Rolls[player].Bad + 1;
		end
	else
		-- are we to ack the roll?
		if (Lootster_TestPlayerTell(player, "AckRoll") == true) then
			-- format the ack message and let them know
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKROLL, roll, minRoll, maxRoll));
		end

		-- bump roll count unless they had passed
		if (Lootster_Rolls[player].Roll ~= 0) then
			Lootster_RollCount = Lootster_RollCount + 1;
		end

		-- bookkeep the roll
		Lootster_Rolls[player].Roll = roll;

		-- determine usage by the type of NBG
		if		(Lootster_NBG == LOOTSTER_NBG_NEED) then
			-- this is Need
			Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.MAINNEED;
		elseif	(Lootster_NBG == LOOTSTER_NBG_GREED) then
			-- this is Greed
			Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.GREED;
		elseif	(Lootster_NBG == LOOTSTER_NBG_1001000) then
			-- 100 is a Greed roll
			if (maxRoll == 100) then
				-- this is Need
				Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.MAINNEED;
			else
				-- this is Greed
				Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.GREED;
			end
		elseif	(Lootster_NBG == LOOTSTER_NBG_FREEFORALL) then
			-- this is Greed
			Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.GREED;
		elseif	(Lootster_NBG == LOOTSTER_NBG_USAGE) then
			-- whatever the max roll usage is
			Lootster_Rolls[player].Usage = LOOTSTER_USAGE_ROLL[maxRoll];
		elseif	((Lootster_RollsUsage ~= nil) and (Lootster_NBG == LOOTSTER_USAGEDKP_LIST[Lootster_RollsUsage])) then
			-- whatever the current rolls usage is
			Lootster_Rolls[player].Usage = Lootster_RollsUsage;
		else
			-- this is Main Need by default
			Lootster_Rolls[player].Usage = LOOTSTER_ENUM_USAGE.MAINNEED;
		end
	end
	
	-- see if the player has won more than their fair share of this usages in this raid
	if ((Lootster_Rolls[player].Roll ~= nil) and (Lootster_RaidId ~= nil)) then
		-- see if the usage is tracked
		if (Lootster_Options.Usage[Lootster_Rolls[player].Usage].Wins == true) then
			-- check if the player has won some of these usages in this raid
			if ((Lootster_Raid[Lootster_RaidId].UsageSet[player] ~= nil) and 
				(Lootster_Raid[Lootster_RaidId].UsageSet[player][Lootster_Rolls[player].Usage] ~= nil)) then
				-- see if they have blown their quota
				if (Lootster_Raid[Lootster_RaidId].UsageSet[player][Lootster_Rolls[player].Usage] >= Lootster_Options.Usage[Lootster_Rolls[player].Usage].WinsPerRaid) then
					-- damn greedy bugger.  Ok we accept the roll but we put it on hold
					Lootster_Rolls[player].Hold = true;
					
					-- format the too many wins message and let them know
					if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_WINSPERRAID, roll, Lootster_Raid[Lootster_RaidId].UsageSet[player][Lootster_Rolls[player].Usage],
																   LOOTSTER_USAGEDKP_LIST[Lootster_Rolls[player].Usage], Lootster_Options.Usage[Lootster_Rolls[player].Usage].WinsPerRaid));
					elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_WINSPERRAID, roll, Lootster_Raid[Lootster_RaidId].UsageSet[player][Lootster_Rolls[player].Usage],
																   LOOTSTER_USAGENORM_LIST[Lootster_Rolls[player].Usage], Lootster_Options.Usage[Lootster_Rolls[player].Usage].WinsPerRaid));
					end
				end
			end
		end
	end

	-- resort the rolls
	Lootster_Roll_Sort();

	-- update received roll status
	Lootster_UpdateRollUI();	

	-- update the screen
	Lootster_Roll_Update();
end

-- Create Roll Plead handler
function Lootster_CreatePlead()
	local	ix, flag, count, classes, class, usages, usage, please;

	local	classes = {};

	-- handle the class restrictions if we are rolling a restricted roll and they are set
	if		((Lootster_NBG_Usage == LOOTSTER_ENUM_USAGE.MANUAL) or (Lootster_IsUsageRestricted(Lootster_NBG_Usage) == true)) then
		-- see if we have class restrict
		if (Lootster_ClassRestrictionsN > 0) then
			-- build an alphabetical list of restricted classes
			for ix, flag in ipairs(LOOTSTER_CLASS_SORT) do
				-- is this not the ignore class and this class restricted?
				if ((Lootster_ClassIgnore[LOOTSTER_CLASS_SORT[ix]] == nil) and (Lootster_ClassRestrictions[LOOTSTER_CLASS_SORT[ix]] == true)) then
					table.insert(classes, LOOTSTER_CLASS_SORT[ix]);
				end
			end

			-- now build the class please and class ignore texts
			count = #classes;

			Lootster_NBG_ClassPlease = "";
			Lootster_NBG_ClassIgnore = "";

			for ix, class in ipairs(classes) do
				-- add plural class to please text
				Lootster_NBG_ClassPlease = Lootster_NBG_ClassPlease..LOOTSTER_CLASS[class].Plural;

				if		(ix < (count - 1)) then
					Lootster_NBG_ClassPlease = Lootster_NBG_ClassPlease..LOOTSTER_MSG_SEP;
				elseif	(ix == (count - 1)) then
					Lootster_NBG_ClassPlease = Lootster_NBG_ClassPlease..LOOTSTER_MSG_AND;
				end

				-- add singular class to ignore text
				Lootster_NBG_ClassIgnore = Lootster_NBG_ClassIgnore..LOOTSTER_CLASS[class].Singular;

				if		(ix < (count - 1)) then
					Lootster_NBG_ClassIgnore = Lootster_NBG_ClassIgnore..LOOTSTER_MSG_SEP;
				elseif	(ix == (count - 1)) then
					Lootster_NBG_ClassIgnore = Lootster_NBG_ClassIgnore..LOOTSTER_MSG_OR;
				end
			end

			-- do we have no class restrictions?
			if		(count == 0) then
				-- reset class restrictions
				Lootster_ResetClass();

				-- update the class UI
				Lootster_UpdateClassUI();

				-- update the UI
				Lootster_UpdateRollUI();

				-- nope, so use normal plead
				Lootster_NBG_ClassPlease = LOOTSTER_MSG_PLEASE;
			elseif	(Lootster_NBG_Usage ~= LOOTSTER_ENUM_USAGE.MANUAL) then
				-- yup, so use the class plead
				Lootster_NBG_ClassPlease = string.format(LOOTSTER_MSG_PLEASE_CLASS, Lootster_NBG_ClassPlease);
			else
				-- yup, so use the usage class plead.  First we need to gather the restricted rolls
				if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
					-- only one restricted roll type
					count = 1;
					
					please = LOOTSTER_USAGENORM_LIST[LOOTSTER_ENUM_USAGE.MAINNEED];
				elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					-- gather restricted usages
					usages = {};
					
					for ix, usage in ipairs(Lootster_Options.UsageSort) do
						-- usage enabled?
						if ((Lootster_Options.Usage[usage].Use == true) and (Lootster_Options.Usage[usage].Restrict == true)) then
							-- add this usage
							table.insert(usages, LOOTSTER_USAGEDKP_LIST[ix]);
						end
					end
					
					-- get count of usages
					count = #usages;
					please = "";
					
					-- and create the usage plead
					for ix, usage in ipairs(usages) do
						-- add usage roll to usage plead
						please = please..usage;

						if		(ix < (count - 1)) then
							please = please..LOOTSTER_MSG_SEP;
						elseif	(ix == (count - 1)) then
							please = please..LOOTSTER_MSG_OR;
						end
					end
				else
					-- no restricted classes
					count = 0;
				end
				
				-- create the class plead depending on how many restrict classes
				if (count == 0) then
					-- reset class restrictions
					Lootster_ResetClass();

					-- update the class UI
					Lootster_UpdateClassUI();

					-- update the UI
					Lootster_UpdateRollUI();

					-- nope, so use normal plead
					Lootster_NBG_ClassPlease = LOOTSTER_MSG_PLEASE;
				else
					-- create class usage plead
					Lootster_NBG_ClassPlease = string.format(LOOTSTER_MSG_PLEASE_USAGECLASS, Lootster_NBG_ClassPlease, please);
				end
			end
		else
			-- set the normal plead 
			Lootster_NBG_ClassPlease = LOOTSTER_MSG_PLEASE;
		end
	else
		-- set the normal plead 
		Lootster_NBG_ClassPlease = LOOTSTER_MSG_PLEASE;
	end
end

function Lootster_ManageBonusTime(sched)
	local	bossId, dateBeg, attempt, dateNow, timeSeg, dateEnd, timeDelay;
	
	-- is there another bonus time event for this raid?
	bossId = Lootster_GetMatchingBoss(Lootster_Running.RaidId, nil, LOOTSTER_ENUM_BOSSTYPE.BONUSTIME);
	
	-- determine the start time of the last bonus
	if (bossId == nil) then
		dateBeg = Lootster_Raid[Lootster_Running.RaidId].DateOpn;
		attempt = 1;
	else
		-- use last bonus time start
		dateBeg = Lootster_Boss[bossId].DateBeg;
		attempt = Lootster_Boss[bossId].Attempt;
	end
	
	-- get current date
	dateNow = Lootster_CalcServerTime(time());
	
	-- calculate the bonus time segment length
	timeSeg = Lootster_Options.Event[LOOTSTER_ENUM_EVENT.BONUSTIME].Time * 60;
	
	-- create enough full bonus time entries to bring us up to the current period
	while ((dateNow - dateBeg) >= timeSeg) do
		-- do we have an existing bonus time?
		if (bossId ~= nil) then
			-- modify this bonus time end
			Lootster_Boss[bossId].DateEnd = dateBeg + timeSeg;

			-- take partial attendance now
			Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.PARTIAL);
			
			-- and update the boss
			Lootster_UpdateBoss(bossId);
		else	
			-- instantiate a new bonus time
			bossRec = Lootster_NewBoss(LOOTSTER_BOSSTYPE_LIST[LOOTSTER_ENUM_BOSSTYPE.BONUSTIME], dateBeg, 
									   false, attempt, LOOTSTER_ENUM_BOSSTYPE.BONUSTIME);
			
			-- update bonus time finish time
			bossRec.DateEnd = dateBeg + timeSeg;
		
			-- create the boss
			bossId = Lootster_CreateBoss(bossRec);
			
			-- insert boss into the running
			Lootster_InsertBoss(Lootster_Running.RaidId, bossId, true);

			-- take full attendance now
			Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.FULL);
		end
		
		-- reset boss id so we create new one next time
		bossId = nil;
			
		-- calculate new bonus begin time
		dateBeg = dateBeg + timeSeg;
		
		-- and bump the attempt
		attempt = attempt + 1;
	end

	-- scheduling or de-scheduling?
	if (sched ~= true) then
		-- dequeue the scheduled bonus time callback
		Lootster_Scheduler_Dequeue(LOOTSTER_ENUM_SCHEDULERID.BONUSTIME);
		
		-- have we a non-zero fraction of the bonus time left?
		if  ((dateNow - dateBeg) > 0) then
			-- have we a partial bonus time entry?
			if (bossId ~= nil) then
				-- update the end date with the current time
				Lootster_Boss[bossId].DateEnd = dateNow;

				-- take partial attendance now
				Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.PARTIAL);
				
				-- and update the boss
				Lootster_UpdateBoss(bossId);
			else
				-- instantiate a new bonus time
				bossRec = Lootster_NewBoss(LOOTSTER_BOSSTYPE_LIST[LOOTSTER_ENUM_BOSSTYPE.BONUSTIME], dateBeg, 
										   false, attempt, LOOTSTER_ENUM_BOSSTYPE.BONUSTIME);
				
				-- update the end date with the current time
				bossRec.DateEnd = dateNow;
			
				-- create the boss
				bossId = Lootster_CreateBoss(bossRec);
				
				-- insert boss into the running
				Lootster_InsertBoss(Lootster_Running.RaidId, bossId, true);

				-- take full attendance now
				Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.FULL);
			end
		end
	else		
		-- restarting the raid.  Do we have a partial time bonus left lying around?
		if (bossId ~= nil) then
			-- remove the partial time bonus to smooth the bookkeeping
			Lootster_DeleteBoss(bossId, true);
				
			-- make sure we reset boss if it disappeared
			if (Lootster_Running.BossId == bossId) then
				-- end of boss
				Lootster_RunBoss(nil);
			end
			
			-- make sure we reset selected boss if it disappeared
			if (Lootster_BossId == bossId) then
				-- no current boss
				Lootster_BossId = nil;
			end
		end
			
		-- calculate the time delay until the next bonus time
		timeDelay = (dateBeg + timeSeg) - dateNow;

		-- enqueue the scheduled bonus time callback, ensuring it repeats
		Lootster_Scheduler_Enqueue(LOOTSTER_ENUM_SCHEDULERID.BONUSTIME, timeDelay, Lootster_ManageBonusTime, true);
	end
end

-- Update Roll UI handler
function Lootster_UpdateRollUI()
	-- enable clear rolls and NBGs depending on state
	if		((Lootster_Tied == true) and (Lootster_NBG ~= LOOTSTER_NBG_TIED)) then
		-- clearable
		Lootster_RollFrameClearRolls:Enable();

		-- waiting for tied roll
		Lootster_RollFrameTiedRoll:Enable();
	elseif	(Lootster_NBG ~= nil) then
		-- clearable
		Lootster_RollFrameClearRolls:Enable();

		-- waiting for rolls
		Lootster_RollFrameNeedRoll:Disable();
		Lootster_RollFrameGreedRoll:Disable();
		Lootster_RollFrame1001000Roll:Disable();
		Lootster_RollFrameFreeForAllRoll:Disable();
		Lootster_RollFrameCallUsage:Disable();
		Lootster_RollFrameCallRoll:Disable();
		Lootster_RollFrameCallReset:Disable();
		Lootster_RollFrameUsageRoll:Disable();
		Lootster_RollFrameTiedRoll:Disable();
	else
		-- can't clear!
		Lootster_RollFrameClearRolls:Disable();

		-- waiting for roll call
		Lootster_RollFrameNeedRoll:Enable();
		Lootster_RollFrameGreedRoll:Enable();
		Lootster_RollFrame1001000Roll:Enable();
		Lootster_RollFrameFreeForAllRoll:Enable();
		Lootster_RollFrameCallUsage:Enable();
		Lootster_RollFrameCallRoll:Enable();
		Lootster_RollFrameCallReset:Enable();
		Lootster_RollFrameUsageRoll:Enable();
		Lootster_RollFrameTiedRoll:Disable();
	end

	-- format received count out of players
	if		(Lootster_NBG == LOOTSTER_NBG_TIED) then
		Lootster_RollFrameRollCount:SetFormattedText(LOOTSTER_ROLL_ROLLCOUNT_FMT, Lootster_RollCount, #Lootster_RollsSort);
	elseif	(Lootster_IsUsageRestricted(Lootster_NBG_Usage) == true) then
		Lootster_RollFrameRollCount:SetFormattedText(LOOTSTER_ROLL_ROLLCOUNT_FMT, Lootster_RollCount, Lootster_RestrictedCount);
	else
		Lootster_RollFrameRollCount:SetFormattedText(LOOTSTER_ROLL_ROLLCOUNT_FMT, Lootster_RollCount, Lootster_PlayerCount);
	end

	-- set the text color appropriately
	if		((Lootster_NBG == nil) or (Lootster_RollCount == 0)) then
		Lootster_RollFrameRollCount:Disable();
	elseif	((Lootster_NBG == LOOTSTER_NBG_TIED) and (Lootster_RollCount < #Lootster_RollsSort)) then
		Lootster_RollFrameRollCount:Enable();
	elseif	((Lootster_IsUsageRestricted(Lootster_NBG_Usage) == true) and (Lootster_RollCount < Lootster_RestrictedCount)) then
		Lootster_RollFrameRollCount:Enable();
	elseif	((Lootster_IsUsageRestricted(Lootster_NBG_Usage) == false) and (Lootster_RollCount < Lootster_PlayerCount)) then
		Lootster_RollFrameRollCount:Enable();
	else	
		Lootster_RollFrameRollCount:Disable();
	end

	-- enable countdown button if NBG set
	if ((Lootster_Options.Counter == false) or (Lootster_Options.CounterSec == 0) or (Lootster_NBG == nil) or 
		((Lootster_NBG == LOOTSTER_NBG_TIED) and (Lootster_RollCount == #Lootster_RollsSort)) or
		((Lootster_IsUsageRestricted(Lootster_NBG_Usage) == true) and (Lootster_RollCount == Lootster_RestrictedCount)) or
		((Lootster_IsUsageRestricted(Lootster_NBG_Usage) == false) and (Lootster_RollCount == Lootster_PlayerCount))) then
		Lootster_RollFrameCountdown:Disable();
	else
		Lootster_RollFrameCountdown:Enable();
	end

	-- enable announce button if we have some stuff to roll on
	if		((Lootster_NBG == nil) or (Lootster_ItemCount <= 0)) then
		-- no roll call or no items left	
		Lootster_RollFrameAnnounce:Disable();
	else
		-- and allow announcement	
		Lootster_RollFrameAnnounce:Enable();
	end

	-- if we have loot linked, we will allow them to assign loot (Bank/Rotted) if we have a running boss
	if ((Lootster_ItemLink ~= nil) and (Lootster_Running.RaidId ~= nil) and (Lootster_Running.BossId ~= nil) and (#Lootster_Won > 0)) then
		-- allow loot assignment without roll
		Lootster_RollFrameAssignLoot:Enable();
	else
		-- disallow loot assignment
		Lootster_RollFrameAssignLoot:Disable();
	end

	-- enable roll button if we haven't (pass) rolled (and we are allowed too in a tie)
	if		(Lootster_Options.Active == false) then
		-- have we enabled passive roll/pass?
		if (Lootster_Options.Passive == true) then
			-- we are not the active looter in passive roll/pass mode, so enable rolling if we ourselves are not class restricted or its not a Need roll
			if		(Lootster_IsUsageRestricted(Lootster_NBG_Usage, Lootster_SelfClassType) == true) then
				Lootster_RollFrameRoll:Disable();
			elseif	(Lootster_NBG == LOOTSTER_NBG_1001000) then
				-- 100/1000 rolling - only enable 100 roll if we are allowed to
				if (Lootster_IsUsageRestricted(nil, Lootster_SelfClassType) == true) then
					Lootster_RollFrameRoll100:Disable();
				else
					Lootster_RollFrameRoll100:Enable();
				end

				Lootster_RollFrameRoll1000:Enable();
			else
				Lootster_RollFrameRoll:Enable();
				Lootster_RollFrameRoll100:Enable();
				Lootster_RollFrameRoll1000:Enable();
			end
		else
			Lootster_RollFrameRoll:Disable();
			Lootster_RollFrameRoll100:Disable();
			Lootster_RollFrameRoll1000:Disable();
		end
	elseif	(Lootster_NBG == nil) then
		Lootster_RollFrameRoll:Disable();

		-- are in Normal mode and are allowed to roll without a call?
		if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormAutoRoll == true)) then
			-- in 100/1000 or FFA mode?
			if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then 
				Lootster_RollFrameRoll:Disable();
				Lootster_RollFrameRoll100:Enable();
				Lootster_RollFrameRoll1000:Enable();
			elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYNEEDGREED) then
				Lootster_RollFrameRoll:Disable();
				Lootster_RollFrameRoll100:Disable();
				Lootster_RollFrameRoll1000:Disable();
			elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL) then
				Lootster_RollFrameRoll:Enable();
				Lootster_RollFrameRoll100:Disable();
				Lootster_RollFrameRoll1000:Disable();
			end
		end
	elseif	((Lootster_Rolls[Lootster_Self] ~= nil) and (Lootster_Rolls[Lootster_Self].Roll ~= nil) and (Lootster_Rolls[Lootster_Self].Roll ~= 0)) then
		Lootster_RollFrameRoll:Disable();
		Lootster_RollFrameRoll100:Disable();

		-- if we are in 100/1000 mode, and they rolled Need, we can downgrade to Greed
		if ((Lootster_NBG == LOOTSTER_NBG_1001000) and (Lootster_Rolls[Lootster_Self].Usage == LOOTSTER_ENUM_USAGE.MAINNEED)) then
			Lootster_RollFrameRoll1000:Enable();
		else
			Lootster_RollFrameRoll1000:Disable();
		end
	else
		-- see if we are in a tie or restricted or its not a Need roll 
		if		((Lootster_NBG == LOOTSTER_NBG_TIED) and (Lootster_Rolls[Lootster_Self] == nil)) then
			Lootster_RollFrameRoll:Disable();
		elseif	(Lootster_IsUsageRestricted(Lootster_NBG_Usage, Lootster_SelfClassType) == true) then
			Lootster_RollFrameRoll:Disable();
		elseif	(Lootster_NBG == LOOTSTER_NBG_1001000) then
			-- 100/1000 rolling - only enable 100 roll if we are allowed to
			if (Lootster_IsUsageRestricted(nil, Lootster_SelfClassType) == true) then
				Lootster_RollFrameRoll100:Disable();
			else
				Lootster_RollFrameRoll100:Enable();
			end

			Lootster_RollFrameRoll1000:Enable();
		else
			Lootster_RollFrameRoll:Enable();
			Lootster_RollFrameRoll100:Enable();
			Lootster_RollFrameRoll1000:Enable();
		end
	end

	-- handle pass/reclaim button depending if they have rolled
	if		(Lootster_Options.Active == false) then
		-- have we enabled passive roll/pass?
		if (Lootster_Options.Passive == true) then
			-- we are not the active looter in passive roll/pass mode, so enable pass/reclaim if we ourselves are not class restricted or its not a Need roll
			if (Lootster_IsUsageRestricted(Lootster_NBG_Usage, Lootster_SelfClassType) == true) then
				Lootster_RollFramePassReclaim:Disable();
			else
				Lootster_RollFramePassReclaim:Enable();
			end
		else
			Lootster_RollFramePassReclaim:Disable();
		end
	elseif	(Lootster_NBG == nil) then
		-- nothing to roll on yet
		Lootster_RollFramePassReclaim:Disable();
	elseif	(Lootster_Rolls[Lootster_Self] ~= nil) then
		-- pass/reclaim if we haven't/have passed
		if		((Lootster_Rolls[Lootster_Self].Roll == nil) or (Lootster_Rolls[Lootster_Self].Roll ~= 0)) then
			-- they can pass/reclaim as the case may be
			Lootster_RollFramePassReclaim:Enable();
		elseif	((Lootster_Rolls[Lootster_Self].Roll ~= nil) and (Lootster_Rolls[Lootster_Self].Roll == 0)) then
			-- they can roll if they want
			Lootster_RollFramePassReclaim:Disable();
		end
	elseif	(Lootster_IsUsageRestricted(Lootster_NBG_Usage, Lootster_SelfClassType) == true) then
		Lootster_RollFramePassReclaim:Disable();
	else
		-- no roll yet, but they can pass
		Lootster_RollFramePassReclaim:Enable();
	end

	-- if we are in roll mode, disable item count, DKP use toggle and DKP caps
	if ((Lootster_NBG ~= nil) or (Lootster_Tied == true)) then
		-- disable item count
		Lootster_RollFrameItems:Hide();

		-- do we have DKP handling?
		if (Lootster_HasDKP == true) then
			-- disable roll mode dropdown
			Lootster_OptionsFrameRollModeButton:Disable();
		end

		-- disable roll type dropdown
		Lootster_OptionsFrameRollTypeButton:Disable();

		-- disable DKP membership option
		Lootster_OptionsFrameDKPMember:Disable();

		-- disable DKP toon option
		Lootster_OptionsFrameDKPToon:Disable();

		-- disable greed is FFA option
		Lootster_OptionsFrameDKPGreedFFA:Disable();

		-- disable attendance earnt DKP option
		Lootster_OptionsFrameDKPAttEarnt:Disable();

		-- disable DKP cap options
		Lootster_OptionsFrameDKPCaps:Disable();
		Lootster_OptionsFrameDKPHi:Hide();
		Lootster_OptionsFrameDKPLo:Hide();

		-- disable DKP factor options
		Lootster_OptionsFrameDKPFactoring:Disable();
		Lootster_OptionsFrameDKPFactor:Hide();

		-- disable Roll factor options
		Lootster_OptionsFrameRollFactoring:Disable();
		Lootster_OptionsFrameRollFactor:Hide();

		-- disable EP minimum and GP base options
		Lootster_OptionsFrameEPMin:Disable();
		Lootster_OptionsFrameGPBase:Disable();
		Lootster_OptionsFrameEPMinEP:Hide();
		Lootster_OptionsFrameGPBaseGP:Hide();

		-- disable Normal membership option
		Lootster_OptionsFrameNormMember:Disable();

		-- disable Normal toon option
		Lootster_OptionsFrameNormToon:Disable();

		-- disable greed FFA option
		Lootster_OptionsFrameNormGreedFFA:Disable();

		-- disable guild rank member option
		Lootster_OptionsFrameRankMembers:Disable();

		-- disable guild public note toon options
		Lootster_OptionsFrameNoteToons:Disable();
		Lootster_OptionsFrameRankToons:Disable();

		-- disable guild rank note options
		Lootster_OptionsFrameAltsMainPrefix:Hide();
		Lootster_OptionsFrameAltsMainSuffix:Hide();

		-- disable guild information rescan button
		Lootster_OptionsFrameRescanGuild:Disable();

		-- disable guild rank UI
		Lootster_Rank_Update();

		-- disable usage UI
		Lootster_Usage_Update();
	
		-- disable the usage by options
		Lootster_OptionsFrameUsageFrameUsageBySeparate:Disable();
		Lootster_OptionsFrameUsageFrameUsageBySingle:Disable();
		
		-- disable usage value and factor options
		Lootster_UsageFrameAltFactor:Hide();
		Lootster_UsageFrameCostValue:Hide();
		Lootster_UsageFrameCostFactor:Hide();
		
		-- update usage points UI
		Lootster_UpdateOptionUsageUI(true);

		-- disable events UI
		Lootster_Event_Update();

		-- disable item quality UI
		Lootster_Quality_Update();

		-- disable item slot UI
		Lootster_Slot_Update();
		
		-- disable item points factors and bias options
		Lootster_OptionsFrameItemPointsFramepFactor:Hide();
		Lootster_OptionsFrameItemPointsFrameqFactor:Hide();
		Lootster_OptionsFrameItemPointsFrameqBias:Hide();
		Lootster_OptionsFrameItemPointsFramesFactor:Hide();
		
		-- update option points UI
		Lootster_UpdateOptionPointsUI(true);
	else
		-- enable item count
		Lootster_RollFrameItems:Show();

		-- do we have DKP handling?
		if (Lootster_HasDKP == true) then
			-- enable roll mode dropdown
			Lootster_OptionsFrameRollModeButton:Enable();
		end

		-- enable roll type dropdown
		Lootster_OptionsFrameRollTypeButton:Enable();

		-- enable DKP membership option
		Lootster_OptionsFrameDKPMember:Enable();

		-- enable DKP toon option
		Lootster_OptionsFrameDKPToon:Enable();

		-- enable greed is FFA option
		Lootster_OptionsFrameDKPGreedFFA:Enable();

		-- enable attendance earnt DKP option
		Lootster_OptionsFrameDKPAttEarnt:Enable();

		-- enable DKP cap options
		Lootster_OptionsFrameDKPCaps:Enable();
		Lootster_OptionsFrameDKPHi:Show();
		Lootster_OptionsFrameDKPLo:Show();

		-- enable DKP factor options
		Lootster_OptionsFrameDKPFactoring:Enable();
		Lootster_OptionsFrameDKPFactor:Show();

		-- enable Roll factor options
		Lootster_OptionsFrameRollFactoring:Enable();
		Lootster_OptionsFrameRollFactor:Show();

		-- enable EP minimum and GP base options
		Lootster_OptionsFrameEPMin:Enable();
		Lootster_OptionsFrameGPBase:Enable();
		Lootster_OptionsFrameEPMinEP:Show();
		Lootster_OptionsFrameGPBaseGP:Show();

		-- enable Normal membership option
		Lootster_OptionsFrameNormMember:Enable();

		-- enable Normal toon option
		Lootster_OptionsFrameNormToon:Enable();

		-- enable greed FFA option
		Lootster_OptionsFrameNormGreedFFA:Enable();

		-- enable guild members and toons handling if guilded
		if (Lootster_SelfIsGuilded == true) then
			-- enable guild rank member option
			Lootster_OptionsFrameRankMembers:Enable();

			-- enable guild public note toon options
			Lootster_OptionsFrameNoteToons:Enable();

			-- enable cross check of toons with guild rank if note toons enabled
			if (Lootster_Options.NoteToons[Lootster_SelfGuild] == true) then
				Lootster_OptionsFrameRankToons:Enable();
			else
				Lootster_OptionsFrameRankToons:Disable();
			end

			-- enable guild rank note options
			Lootster_OptionsFrameAltsMainPrefix:Show();
			Lootster_OptionsFrameAltsMainSuffix:Show();

			-- enable guild information rescan button
			Lootster_OptionsFrameRescanGuild:Enable();
		else
			-- disable guild rank member option
			Lootster_OptionsFrameRankMembers:Disable();

			-- disable guild public note toon options
			Lootster_OptionsFrameNoteToons:Disable();
			Lootster_OptionsFrameRankToons:Disable();

			-- disable guild rank note options
			Lootster_OptionsFrameAltsMainPrefix:Hide();
			Lootster_OptionsFrameAltsMainSuffix:Hide();

			-- disable guild information rescan button
			Lootster_OptionsFrameRescanGuild:Disable();
		end

		-- enable guild rank UI
		Lootster_Rank_Update();
		
		-- enable usage UI
		Lootster_Usage_Update();
	
		-- enable the usage by options
		Lootster_OptionsFrameUsageFrameUsageBySeparate:Enable();
		Lootster_OptionsFrameUsageFrameUsageBySingle:Enable();
		
		-- enable usage value and factor options
		Lootster_UsageFrameAltFactor:Show();
		Lootster_UsageFrameCostValue:Show();
		Lootster_UsageFrameCostFactor:Show();
		
		-- update option usage UI
		Lootster_UpdateOptionUsageUI();
		
		-- enable event UI
		Lootster_Event_Update();
		
		-- enable item quality UI
		Lootster_Quality_Update();
		
		-- enable item slot UI
		Lootster_Slot_Update();
		
		-- enable item points factors and bias options
		Lootster_OptionsFrameItemPointsFramepFactor:Show();
		Lootster_OptionsFrameItemPointsFrameqFactor:Show();
		Lootster_OptionsFrameItemPointsFrameqBias:Show();
		Lootster_OptionsFrameItemPointsFramesFactor:Show();
		
		-- update option points UI
		Lootster_UpdateOptionPointsUI();
	end

	-- are these restrictions locked down?
	if ((Lootster_ClassRestrictedLock == true) or (Lootster_ClassRestrictionsMaskOrig ~= 0)) then
		-- disable the restrict roll button
		Lootster_RollFrameRestrictRoll:Disable();
	else
		-- enable the restrict roll button
		Lootster_RollFrameRestrictRoll:Enable();
	end

	-- update state of class restrict remember button
	if ((Lootster_ItemID ~= nil) and (Lootster_ClassRestrictedLock == false) and 
		(Lootster_ClassRestrictionsMaskOrig ~= Lootster_ClassRestrictionsMaskCurr)) then
		-- enable remember button
		Lootster_ClassFrameRemember:Enable();
	else
		-- disable remember button
		Lootster_ClassFrameRemember:Disable();
	end

	-- update state of class restrict forget button
	if ((Lootster_ItemID ~= nil) and (Lootster_ClassRestrictedLock == false) and (Lootster_ClassRestrictionsMaskOrig ~= 0)) then
		-- enable remember button
		Lootster_ClassFrameForget:Enable();
	else
		-- disable remember button
		Lootster_ClassFrameForget:Disable();
	end
end

-- Update Roll Handling handler
function Lootster_UpdateRollHandling()
	-- reposition tabs and update UI
	Lootster_CheckModeUse();

	-- reformat our roll button text
	Lootster_UpdateRoll();

	-- resnarf any existing hyperlink
	Lootster_SetHyperlink(Lootster_ItemLink);

	-- broadcast the roll handling message
	Lootster_SendBroadcast(Lootster_GetRollHandling());
end

-- Pass Roll handler
function Lootster_PassRoll(player)
	-- see if a roll is called
	if (Lootster_NBG == nil) then
		-- no need for us to bookkeep
		return;
	end

	-- if we are in a tied roll, only the tied players can pass/reclaim
	if ((Lootster_NBG == LOOTSTER_NBG_TIED) and (Lootster_Rolls[player] == nil)) then
		-- no processing
		return;
	end

	-- is this guy allowed to roll?
	if (Lootster_RosterRoll[player] == nil) then
		-- naughty naughty bad Zoot!
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NOTPASSCLASS, Lootster_NBG_ClassIgnore));

		return;
	end

	-- bookkeep the roller
	Lootster_AddRoller(player);

	-- check if they have rolled before
	if		(Lootster_Rolls[player].Roll == nil) then
		-- simply set to zero to indicate no roll
		Lootster_Rolls[player].Roll = 0;

		-- bump roll count
		Lootster_RollCount = Lootster_RollCount + 1;

		-- ack the pass
		if (Lootster_ItemLink == nil) then
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSNONE, Lootster_NBG));
		else
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSNONE_LINK, Lootster_NBG, Lootster_ItemLink));
		end
	elseif	(Lootster_Rolls[player].Roll > 0) then
		local	nbg = Lootster_NBG;

		-- if we are in 100/1000 mode, they rolled one or the other.  Reflect that
		if (Lootster_NBG == LOOTSTER_NBG_1001000) then
			-- determine if they rolled need or greed
			if		(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.MAINNEED) then
				nbg = LOOTSTER_NBG_NEED;
			elseif	(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.GREED) then
				nbg = LOOTSTER_NBG_GREED;
			end
		end

		-- simply set to the negative to indicate passed
		Lootster_Rolls[player].Roll = -Lootster_Rolls[player].Roll;

		-- ack the pass
		if (Lootster_ItemLink == nil) then
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSROLL, -Lootster_Rolls[player].Roll, nbg));
		else
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSROLL_LINK, -Lootster_Rolls[player].Roll, nbg, Lootster_ItemLink));
		end
	else
		-- already passed - ignore - ack the pass anyway
		if (Lootster_Rolls[player].Roll == 0) then
			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSNONE, Lootster_NBG));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSNONE_LINK, Lootster_NBG, Lootster_ItemLink));
			end
		else
			local	nbg = Lootster_NBG;

			-- if we are in 100/1000 mode, they rolled one or the other.  Reflect that
			if (Lootster_NBG == LOOTSTER_NBG_1001000) then
				-- determine if they rolled need or greed
				if		(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.MAINNEED) then
					nbg = LOOTSTER_NBG_NEED;
				elseif	(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.GREED) then
					nbg = LOOTSTER_NBG_GREED;
				end
			end

			if (Lootster_ItemLink == nil) then
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSROLL, -Lootster_Rolls[player].Roll, nbg));
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKPASSROLL_LINK, -Lootster_Rolls[player].Roll, nbg, Lootster_ItemLink));
			end
		end

		return;
	end

	-- did this come from us?
	if (player == Lootster_Self) then
		-- update the text to indicate pass or reclaim
		if		((Lootster_Rolls[Lootster_Self] == nil) or (Lootster_Rolls[Lootster_Self].Roll == nil) or 
				 (Lootster_Rolls[Lootster_Self].Roll >= 0)) then
			-- set text for passing
			Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_PASS);
		elseif	((Lootster_Rolls[Lootster_Self] ~= nil) and (Lootster_Rolls[Lootster_Self].Roll ~= nil) and 
				 (Lootster_Rolls[Lootster_Self].Roll <= 0)) then
			-- set text for reclaiming
			Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_RECLAIM);
		else
			-- default is pass
			Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_PASS);
		end
	end

	-- resort the rolls
	Lootster_Roll_Sort();

	-- update received roll status
	Lootster_UpdateRollUI();	

	-- update the screen
	Lootster_Roll_Update();
end

-- Reclaim Roll handler
function Lootster_ReclaimRoll(player)
	-- see if a roll is called
	if (Lootster_NBG == nil) then
		-- no need for us to bookkeep
		return;
	end

	-- if we are in a tied roll, only the tied players can pass/reclaim
	if ((Lootster_NBG == LOOTSTER_NBG_TIED) and (Lootster_Rolls[player] == nil)) then
		-- no processing
		return;
	end

	-- is this guy allowed to roll?
	if (Lootster_RosterRoll[player] == nil) then
		-- naughty naughty bad Zoot!
		Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_NOTRECLAIMCLASS, Lootster_NBG_ClassIgnore));

		return;
	end

	-- bookkeep the roller
	Lootster_AddRoller(player);

	-- check if they have rolled before
	if		((Lootster_Rolls[player].Roll == nil) or (Lootster_Rolls[player].Roll == 0)) then
		-- let them know they have not rolled before
		if (Lootster_ItemLink == nil) then
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKRECLAIMNONE, Lootster_NBG));
		else
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKRECLAIMNONE_LINK, Lootster_NBG, Lootster_ItemLink));
		end

		-- and ask them nicely to roll
		Lootster_AskForRoll(player);

		return;
	elseif	(Lootster_Rolls[player].Roll < 0) then
		local	nbg = Lootster_NBG;

		-- if we are in 100/1000 mode, they rolled one or the other.  Reflect that
		if (Lootster_NBG == LOOTSTER_NBG_1001000) then
			-- determine if they rolled need or greed
			if		(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.MAINNEED) then
				nbg = LOOTSTER_NBG_NEED;
			elseif	(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.GREED) then
				nbg = LOOTSTER_NBG_GREED;
			end
		end

		-- simply set to the re-negate to indicate reclaim
		Lootster_Rolls[player].Roll = -Lootster_Rolls[player].Roll;

		-- ack the reclaim
		if (Lootster_ItemLink == nil) then
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKRECLAIMROLL, Lootster_Rolls[player].Roll, nbg));
		else
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACKRECLAIMROLL_LINK, Lootster_Rolls[player].Roll, nbg, Lootster_ItemLink));
		end
	else
		local	nbg = Lootster_NBG;

		-- if we are in 100/1000 mode, they rolled one or the other.  Reflect that
		if (Lootster_NBG == LOOTSTER_NBG_1001000) then
			-- determine if they rolled need or greed
			if		(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.MAINNEED) then
				nbg = LOOTSTER_NBG_NEED;
			elseif	(Lootster_Rolls[player].Usage == LOOTSTER_ENUM_USAGE.GREED) then
				nbg = LOOTSTER_NBG_GREED;
			end
		end

		-- roll is still active
		if (Lootster_ItemLink == nil) then
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACTIVEROLL, Lootster_Rolls[player].Roll, nbg));
		else
			Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ACTIVEROLL_LINK, Lootster_Rolls[player].Roll, nbg, Lootster_ItemLink));
		end

		return;
	end

	-- did this come from us?
	if (player == Lootster_Self) then
		-- update the text to indicate pass or reclaim
		if		((Lootster_Rolls[Lootster_Self] == nil) or (Lootster_Rolls[Lootster_Self].Roll == nil) or 
				 (Lootster_Rolls[Lootster_Self].Roll >= 0)) then
			-- set text for passing
			Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_PASS);
		elseif	((Lootster_Rolls[Lootster_Self] ~= nil) and (Lootster_Rolls[Lootster_Self].Roll ~= nil) and 
				 (Lootster_Rolls[Lootster_Self].Roll <= 0)) then
			-- set text for reclaiming
			Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_RECLAIM);
		else
			-- default is pass
			Lootster_RollFramePassReclaim:SetText(LOOTSTER_ROLL_PASS);
		end
	end

	-- resort the rolls
	Lootster_Roll_Sort();

	-- update received roll status
	Lootster_UpdateRollUI();	

	-- update the screen
	Lootster_Roll_Update();
end

-- Calculate the Server Time handler
function Lootster_CalcServerTime(time)
	-- simply add our time zone offset to passed time.  This will then be used in UTC formatting
	return time + (Lootster_TZOffsetSvrCur * 3600);
end

-- Format the Server Time handler
function Lootster_FormatServerTime(time)
	-- the time is expected to be in server time
	return date(LOOTSTER_ECHO_DATE, time);
end

-- Sum Total DKP
function Lootster_SumDKP(record)
	-- easy
	return record.DKPEarnt - record.DKPSpent + record.DKPAdjEarnt - record.DKPAdjSpent;
end

-- Sum Earnt DKP
function Lootster_SumDKPEarnt(record)
	-- easy
	return record.DKPEarnt + record.DKPAdjEarnt + record.DKPAttEarnt;
end

-- Sum Spent DKP
function Lootster_SumDKPSpent(record)
	-- easy
	return record.DKPSpent + record.DKPAdjSpent;
end

-- Sum Total DKP
function Lootster_SumDKPTotal(record)
	-- are we to include earnt attendance DKP?
	if ((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) or (Lootster_Options.DKPAttEarnt == true)) then
		-- easy
		return record.DKPEarnt - record.DKPSpent + record.DKPAttEarnt + record.DKPAdjEarnt - record.DKPAdjSpent;
	else
		-- easy
		return record.DKPEarnt - record.DKPSpent + record.DKPAdjEarnt - record.DKPAdjSpent;
	end
end

-- Sum Adjust DKP
function Lootster_SumDKPAdjust(record)
	-- easy
	return record.DKPAdjEarnt + record.DKPAdjSpent;
end

-- Sum Update DKP
function Lootster_SumDKPUpdate(record)
	-- easy
	return record.DKPAdjEarnt - record.DKPAdjSpent + record.DKPAttEarnt;
end

-- Sum Earnt Update DKP
function Lootster_SumDKPEarntUpdate(record)
	-- easy
	return record.DKPAdjEarnt + record.DKPAttEarnt;
end

-- Sum Spent Update DKP
function Lootster_SumDKPSpentUpdate(record)
	-- easy
	return record.DKPAdjSpent;
end

-- Calculate Item DKP handler
function Lootster_CalcItemDKP(itemLink, show)
	local	_, itemId, itemText, itemQual, iQuality, iLevel, iInvType, iPoints, qActive, qFactor, qBias, sFactor, pFactor;
	
	-- reset dkp and intermediate values
	iPoints = 0;
	qActive = false;
	qFactor = 0;
	qBias = 0;
	sFactor = 0;
	pFactor = 0;
	
	-- retrieve the item ID
	itemId, itemText, itemQual = Lootster_GetItemBasics(itemLink);
	
	-- get item quality, level and equipment slot
	_, _, iQuality, iLevel, _, _, _, _, iInvType = GetItemInfo(itemLink);
	
	-- found item quality?
	if (iQuality == nil) then
		-- set item quality to unknown
		iQuality = -1;
	end
	
	-- found item level?
	if (iLevel == nil) then
		-- set item level to zero
		iLevel = 0;
	end

	-- see if this is an armour token
	if (LOOTSTER_ITEM_TLB[itemId] ~= nil) then
		-- retrieve the real item level and equipment location
		iLevel = LOOTSTER_ITEM_TLB[itemId].iLevel;
		iInvType = LOOTSTER_ITEM_TLB[itemId].iInvType;
	end		
	
	-- get quality factor and bias
	if (Lootster_Options.Quality[iQuality] ~= nil) then
		qActive = Lootster_Options.Quality[iQuality].Active;
		qFactor = Lootster_Options.Quality[iQuality].qFactor;
		qBias = Lootster_Options.Quality[iQuality].qBias;
	end
	
	-- get slot factor
	if ((iInvType ~= nil) and (LOOTSTER_SLOT_FACTOR[iInvType] ~= nil)) then
		sFactor = Lootster_Options.Slot[LOOTSTER_SLOT_FACTOR[iInvType]];
	else
		sFactor = Lootster_Options.Slot[LOOTSTER_ENUM_SLOTFACTOR.SFACTOR7];
	end
	
	-- and factor
	pFactor = Lootster_Options.pFactor;
	
	-- calculate item points as required
	if ((qActive == true) or (show == true)) then
		-- return the calculated points
		iPoints = (iLevel * qFactor - qBias) * sFactor * pFactor;
	else
		-- not selected quality for item points and not displaying formula
		iPoints = 0;
	end
	
	-- are we to show the value breakdowns?
	if (show == true) then
		-- update options item points forumula
		Lootster_OptionsFrameItemPointsFramePoints:SetText(ITEM_QUALITY_COLORS[iQuality].hex..string.format(LOOTSTER_OPTION_EQUATION, iPoints, iLevel, qFactor, qBias, sFactor, pFactor)..FONT_COLOR_CODE_CLOSE);
	end
	
	-- return calculated item points
	return iPoints, qActive;
end

-- Calculate Usage DKP handler
function Lootster_CalcUsageDKP(player, alt, usage, dkp)
	local	aFactor, cValue, cFactor;
	
	-- manual entries have no usage calculation
	if (usage == LOOTSTER_ENUM_USAGE.MANUAL) then
		return(dkp);
	end
	
	-- is thids an alt?
	if (player ~= alt) then
		-- retrieve usage alt factor
		aFactor = Lootster_Options.Usage[usage].aFactor;
	else
		-- normal factor
		aFactor = 1.0;
	end
	
	-- determine what the cost basis of this usage is
	if		(Lootster_Options.Usage[usage].Cost == LOOTSTER_ENUM_USAGECOST.VALUE) then
		-- dkp is an outright value
		dkp = Lootster_Options.Usage[usage].cValue;
	elseif	(Lootster_Options.Usage[usage].Cost == LOOTSTER_ENUM_USAGECOST.FACTOR) then
		-- dkp is factored
		dkp = dkp * Lootster_Options.Usage[usage].cFactor;
	end
	
	-- apply alt factor
	return dkp * aFactor;		
end

-- Calculate Attend DKP handler
function Lootster_CalcAttendDKP(raidId, bossId, attended)
	local	eventType, dkp, partial, standby, dateDelta, dkpEarnt;
	
	-- not here means no DKP for you
	if (attended == LOOTSTER_ENUM_ATTENDED.NOTATALL) then
		-- tough luck
		return 0;
	end

	-- is this event utlised for this boss type?
	if (LOOTSTER_BOSSTYPE_EVENT[Lootster_Boss[bossId].Type] == nil) then
		-- no attendance DKP
		return 0;
	end
	
	-- translate boss type into event type
	eventType = LOOTSTER_BOSSTYPE_EVENT[Lootster_Boss[bossId].Type];
		
	-- get the values for calculating the attendance DKP
	if		(eventType == LOOTSTER_ENUM_EVENT.BONUSAWARD) then
		-- use the DKP values in the boss
		dkp = Lootster_Boss[bossId].DKP;
		partial = Lootster_Boss[bossId].Partial;
		standby = Lootster_Boss[bossId].Standby;
	elseif	(eventType == LOOTSTER_ENUM_EVENT.BONUSTIME) then
		-- get the bonus time's event DKP
		dkp, partial, standby = Lootster_GetEventDKP(Lootster_Raid[raidId].Type, eventType);
		
		-- determine how much of the bonus to award based on the difference between the begin and
		-- end date
		dateDelta = Lootster_Boss[bossId].DateEnd - Lootster_Boss[bossId].DateBeg;
		
		-- anything negative is zero DKP
		if		(dateDelta < 0) then
			dkp = 0;
		elseif	(Lootster_Options.Event[LOOTSTER_ENUM_EVENT.BONUSTIME].Time > 0) then
			-- prorate the bonus award
			dkp = dkp * dateDelta / (Lootster_Options.Event[LOOTSTER_ENUM_EVENT.BONUSTIME].Time * 60);
		else
			-- zero bonus time frame means no DKP
			dkp = 0;			
		end
		
		-- store the DKP values in the boss
		Lootster_Boss[bossId].DKP = dkp;
		Lootster_Boss[bossId].Partial = partial;
		Lootster_Boss[bossId].Standby = standby;
	else
		-- get the raid type's event DKP
		dkp, partial, standby = Lootster_GetEventDKP(Lootster_Raid[raidId].Type, eventType);
	end

	-- calculate attendance type DKP
	if		(attended == LOOTSTER_ENUM_ATTENDED.FULL) then
		-- full DKP
		dkpEarnt = dkp;
	elseif	(attended == LOOTSTER_ENUM_ATTENDED.PARTIAL) then
		-- use partial percentage
		dkpEarnt = dkp * partial / 100;
	elseif	(attended == LOOTSTER_ENUM_ATTENDED.STANDBY) then
		-- use partial percentage
		dkpEarnt = dkp * standby / 100;
	else
		-- no attended DKP
		dkpEarnt = 0;
	end
	
	return dkpEarnt;
end	

-- Calculate Points handler
function Lootster_CalcPoints(points)
	-- round DKP as appropriate
	points = tonumber(string.format(LOOTSTER_COST_POINTS, points));

	return points;
end

-- Calculate EP handler
function Lootster_CalcEP(ep)
	-- do we apply EP Minimum?
	if (Lootster_Options.EPMin == true) then
		-- yup, so set as appropriate
		if (ep < Lootster_Options.EPMinEP) then
			-- set to zero
			ep = 0;
		end
	end
	
	return ep;
end

-- Calculate GP handler
function Lootster_CalcGP(gp)
	-- do we apply GP Base?
	if (Lootster_Options.GPBase == true) then
		-- yup, so set as appropriate
		gp = gp + Lootster_Options.GPBaseGP;
	end

	return gp;
end

-- Calculate PR handler
function Lootster_CalcPR(ep, gp)
	local pr;
	
	-- calculate priority
	if (gp ~= 0) then
		pr = ep / gp;
	else
		pr = 1.0;
	end

	return pr;
end

-- Calculate Tier handler
function Lootster_CalcTier(dkp)
	local   found	= false;
	local	tier	= LOOTSTER_TIER_UNKNOWN;

	-- hammer through tier table
	for ix, dkpRec in ipairs(Lootster_TierDKP) do
		-- see how to apply the range
		if		(dkpRec.Lo == nil) then
			found = (dkp < dkpRec.Hi);
		elseif  (dkpRec.Hi == nil) then
			found = (dkp >= dkpRec.Lo);
		else
			found = (dkp >= dkpRec.Lo) and (dkp < dkpRec.Hi);
		end

		if (found) then
			-- snarf tier if we found it
			tier = dkpRec.Tier;
			break;
		end
	end

	return tier;
end

-- Retrieve Player DKP handler
function Lootster_GetPlayerDKP(player)
	local	main;
	local	dkp = 0.0;

	-- resolve the player into a main
	main = Lootster_GetAltMain(player);

	-- retrieve round DKP as appropriate
	dkp = Lootster_CalcPoints(Lootster_SumDKPTotal(Lootster_DKP[main]));

	-- do we apply caps?
	if (Lootster_Options.DKPCaps == true) then
		-- yup, so apply hi/lo as appropriate
		if	  ((dkp < 0) and (math.abs(dkp) > Lootster_Options.DKPLo)) then
			-- set to low limit
			dkp = - Lootster_Options.DKPLo;
		elseif	((dkp > 0) and (dkp > Lootster_Options.DKPHi)) then
			-- set to high limit
			dkp = Lootster_Options.DKPHi;
		end
	end

	return dkp;
end

-- Retrieve Player PR handler
function Lootster_GetPlayerPR(player)
	local	main;
	local	ep = 0.0;
	local	gp = 0.0;

	-- resolve the player into a main
	main = Lootster_GetAltMain(player);

	-- do we have EP/GP for this player?
	if (Lootster_DKP[main] ~= nil) then
		-- snarf DKP
		ep = Lootster_SumDKPEarnt(Lootster_DKP[main]);
		gp = Lootster_SumDKPSpent(Lootster_DKP[main]);
	end
	
	-- calculate EP, GP, and PR
	pr = Lootster_CalcPR(Lootster_CalcEP(ep), Lootster_CalcGP(gp));
	
	return Lootster_CalcPoints(pr);
end

-- Retrieve Player Tier handler
function Lootster_GetPlayerTier(player)
	local	dkp;
	local	tier;

	-- get the player's capped DKP
	dkp = Lootster_GetPlayerDKP(player);

	-- and determine the capped tier
	tier = Lootster_CalcTier(dkp);

	return tier;
end

-- Retrieve Player Roll handler
function Lootster_GetPlayerRoll(player)
	local	roll, dkp;

	-- see what type of DKP we are using
	if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
		-- By DKP, so roll is 100
		roll = 100;
	elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
		-- By Tier, so roll is 100
		roll = 100;
	elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
		-- if our current usage is greed, and greed FFA is on, roll is 100
		if ((Lootster_NBG_Usage == LOOTSTER_ENUM_USAGE.GREED) and (Lootster_Options.DKPGreedFFA == true))  then
			-- everyone equal for greed
			roll = 100;
		else
			-- get the player DKP
			dkp = Lootster_GetPlayerDKP(player);

			-- are we using DKP modified rolling and we are using DKP factoring?
			if ((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) and (Lootster_Options.DKPFactoring == true)) then
				-- apply the factor to the dkp
				dkp = Lootster_CalcPoints(dkp / Lootster_Options.DKPFactor);
			end

			-- By DKP Modified Roll, so roll is (factored) DKP + 100
			roll = dkp + 100;
		end
	elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
		-- By Roll Modified DKP, so roll is 100
		roll = 100;
	else
		-- use 100 since we don't know any better
		roll = 100;
	end

	return roll;
end

-- Get Player Roll Result handler
function Lootster_GetPlayerResult(rollRec)
	local	roll, result;

	-- have we a roll yet?
	if (rollRec.Roll ~= nil) then
		roll = rollRec.Roll;
	else
		roll = 0;
	end

	-- are we using a modified DKP by roll?
	if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP)) then
		-- use roll as DKP+Roll, factoring roll as necessary
		if (Lootster_Options.RollFactoring == true) then
			-- apply the factor to the roll
			result = rollRec.DKP + (roll * Lootster_Options.RollFactor);
		else
			-- just use raw roll
			result = rollRec.DKP + roll;
		end
	else
		-- use roll as is
		result = roll;
	end

	return result;
end

-- Get Player Membership handler
function Lootster_GetPlayerMember(player)
	local	member = LOOTSTER_ENUM_MEMBER.NONE;

	-- what rolling type and membership in effect?
	if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPMember == true)) or
		((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormMember == true))) then
		-- calculate membership
		member = Lootster_GetPlayerMembership(player);
	end

	return member;
end

-- Get Player Toon handler
function Lootster_GetPlayerToon(player)
	local	toon = LOOTSTER_ENUM_TOON.NONE;

	-- what rolling type and membership in effect?
	if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPToon == true)) or
		((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormToon == true))) then
		-- calculate toonship
		toon = Lootster_GetPlayerToonship(player);
	end

	return toon;
end

-- Retrieve Player Position handler
function Lootster_GetPlayerPosition(player)
	local	high = LOOTSTER_ECHO_NA;
	local	equal = LOOTSTER_ECHO_NA;

	-- do we have DKP for this player?
	if (Lootster_RosterRoll[player] ~= nil) then
		-- snarf position
		high = Lootster_RosterRoll[player].High;
		equal = Lootster_RosterRoll[player].Equal;
	end

	return high, equal;
end

-- Retrieve Player Membership handler
function Lootster_GetPlayerMembership(player)
	local	main;
	local	member = LOOTSTER_ENUM_MEMBER.APP;

	-- resolve the player into a main
	main = Lootster_GetAltMain(player);

	-- are we using guild ranks for membership?
	if		((Lootster_SelfGuild ~= nil) and (Lootster_Options.RankMembers[Lootster_SelfGuild] == true)) then
		-- is this main in the guild?
		if (Lootster_Guildie[main] ~= nil) then
			-- is this main an unresolved alt?
			if (Lootster_Options.Ranks[Lootster_SelfGuild][Lootster_Guildie[main].Rank].Toon == LOOTSTER_ENUM_TOON.ALT) then
				-- use the non-main for alt rank's member setting
				member = Lootster_Options.Ranks[Lootster_SelfGuild][LOOTSTER_OPTION_RANK_NONMAIN].Member;
			else
				-- resolve via the guild rank
				member = Lootster_Options.Ranks[Lootster_SelfGuild][Lootster_Guildie[main].Rank].Member;
			end
		else
			-- resolve via the non-guild rank
			member = Lootster_Options.Ranks[Lootster_SelfGuild][LOOTSTER_OPTION_RANK_NONGUILD].Member;
		end
	elseif	(Lootster_DKP[main] ~= nil) then
		-- resolve via the data membership
		member = Lootster_DKP[main].Member;
	end

	return member;
end

-- Retrieve Player Toonship handler
function Lootster_GetPlayerToonship(player)
	local	main;
	local	toon = LOOTSTER_ENUM_TOON.MAIN;

	-- resolve the player into a main
	main = Lootster_GetAltMain(player);

	-- are we using guild ranks for toonship?
	if		((Lootster_SelfGuild ~= nil) and (Lootster_Options.NoteToons[Lootster_SelfGuild] == true)) then
		-- is this main in the guild?
		if		(player ~= main) then
			-- toon is an alt
			toon = LOOTSTER_ENUM_TOON.ALT;
		elseif	((Lootster_Guildie[main] ~= nil) and (Lootster_Options.RankToons[Lootster_SelfGuild] == true)) then
			-- use the guild rank's toonship
			toon = Lootster_Options.Ranks[Lootster_SelfGuild][Lootster_Guildie[main].Rank].Toon;
		end
	elseif (player ~= main) then
		-- toon is an alt
		toon = LOOTSTER_ENUM_TOON.ALT;
	end

	return toon;
end

-- Retrieve Player Roll Information handler
function Lootster_GetPlayerRollInfo(rollRec)
	local	decider, prior, rollInfo;

	-- determine roll mode and type
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		decider = "";
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- decider is DKP mode-based
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
			decider = string.format(LOOTSTER_ROLL_DKPINFO, rollRec.DKP);
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			decider = string.format(LOOTSTER_ROLL_TIERINFO, rollRec.Tier);
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			decider = string.format(LOOTSTER_ROLL_PRINFO, rollRec.DKP);
		else
			decider = "";
		end
	end

	-- get the priority information
	prior = Lootster_FormatPriority(rollRec.Member, rollRec.Toon);

	-- add the roll information pretext
	rollInfo = LOOTSTER_ROLL_INFOPREFIX..decider;

	-- do we need an information separator?
	if ((decider ~= "") and (prior ~= "")) then
		rollInfo = rollInfo..LOOTSTER_ROLL_INFOSEP;
	end

	-- add the roll information posttext
	rollInfo = rollInfo..prior..LOOTSTER_ROLL_INFOSUFFIX;

	return rollInfo;
end

-- Format the Boss Text handler
function Lootster_FormatBoss(boss, attempt)
	-- smoosh of boss and attempt number
	return string.format(LOOTSTER_ECHO_BOSS, boss, attempt);
end

-- Format the Membership/Toon Priority handler
function Lootster_FormatPriority(member, toon)
	local	prior;

	-- form smoosh of membership and toonship text
	prior = LOOTSTER_PRIORITY_PREFIX..LOOTSTER_MEMBER_LIST[member]..LOOTSTER_PRIORITY_SEP..LOOTSTER_TOON_LIST[toon];

	return prior;
end

-- Retrieve Player Tell Toggle handler
function Lootster_TestPlayerTell(player, key)
	-- does this player have a tell override?
	if ((Lootster_Players[player] ~= nil) and (Lootster_Players[player][key] ~= nil)) then
		-- return player's preference
		return Lootster_Players[player][key];
	else
		-- return master preference
		return Lootster_Options[key];
	end
end

-- Get Alt to Main Look-aside Table hander
function Lootster_GetAltMain(player)
	local	name = player;

	-- are we using guild ranks for toonship?
	if ((Lootster_SelfGuild ~= nil) and (Lootster_Options.NoteToons[Lootster_SelfGuild] == true)) then
		-- do we have a guild main for this alt?
		if (Lootster_GuildieAltMain[player] ~= nil) then
			-- resolve main via the guild alt/main mapping
			name = Lootster_GuildieAltMain[player];
		end
	else
		-- do we have a DKP main for this alt?
		if (Lootster_DKPAltMain[player] ~= nil) then
			-- resolve main via the data alt/main mapping
			name = Lootster_DKPAltMain[player];
		end
	end

	return name;
end

-- Get Main to Alt Look-aside Table hander
function Lootster_GetMainAlt(player)
	local	name = player;

	-- are we using guild ranks for toonship?
	if ((Lootster_SelfGuild ~= nil) and (Lootster_Options.NoteToons[Lootster_SelfGuild] == true)) then
		-- do we have a guild alt for this main?
		if (Lootster_GuildieMainAlt[player] ~= nil) then
			-- resolve alt via the guild main/alt mapping
			name = Lootster_GuildieMainAlt[player];
		end
	else
		-- do we have a DKP alt for this main?
		if (Lootster_DKPMainAlt[player] ~= nil) then
			-- resolve alt via the data main/alt mapping
			name = Lootster_DKPMainAlt[player];
		end
	end

	return name;
end

-- Get Roll Handling handler
function Lootster_GetRollHandling()
	local	msg = "";

	-- send the roll handling message
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		local	mode, member, toon, ffa, limits;

		-- determine the DKP type
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
			mode = LOOTSTER_MSG_TYPEDKP;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			mode = LOOTSTER_MSG_TYPETIER;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
			mode = LOOTSTER_MSG_TYPEMODIFIEDROLL;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
			mode = LOOTSTER_MSG_TYPEMODIFIEDDKP;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			mode = LOOTSTER_MSG_TYPEEPGP;
		else
			-- unknown DKP type - hammer into DKP type and recall
			Lootster_Options.DKPType = LOOTSTER_ENUM_DKP.BYDKP;

			return(Lootster_GetRollHandling());
		end

		-- determine membership
		if (Lootster_Options.DKPMember == true) then
			member = LOOTSTER_MSG_MEMBERUSED;
		else
			member = LOOTSTER_MSG_MEMBERNONE;
		end

		-- determine toon
		if (Lootster_Options.DKPToon == true) then
			toon = LOOTSTER_MSG_TOONUSED;
		else
			toon = LOOTSTER_MSG_TOONNONE;
		end

		-- determine FFA for greed
		if (Lootster_Options.DKPGreedFFA == true) then
			ffa = LOOTSTER_MSG_GREEDFFAUSED;
		else
			ffa = LOOTSTER_MSG_GREEDFFANONE;
		end
		
		-- caps are not valid for EPGP
		if		(Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) then
			-- determine if we use earnt attendance DKP in player's total DKP
			if (Lootster_Options.DKPAttEarnt == true) then
				-- earnt attendance DKP is used
				limits = LOOTSTER_MSG_ATTEARNTUSED;
			else
				-- earnt attendance DKP is ignored
				limits = LOOTSTER_MSG_ATTEARNTNONE;
			end
			
			-- determine if we have DKP caps in effect
			if (Lootster_Options.DKPCaps == true) then
				-- format caps
				limits = limits..string.format(LOOTSTER_MSG_CAPSUSED, Lootster_Options.DKPHi, Lootster_Options.DKPLo);
			else
				-- no caps in effect
				limits = limits..LOOTSTER_MSG_CAPSNONE;
			end
			
			-- see what factors we need
			if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
				-- we using a DKP factor?
				if (Lootster_Options.DKPFactoring == true) then
					-- format DKP factor
					limits = limits..string.format(LOOTSTER_MSG_DKPFACTOR, Lootster_Options.DKPFactor);
				else
					-- default is 1
					limits = limits..string.format(LOOTSTER_MSG_DKPFACTOR, 1);
				end
			elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
				-- we using a roll factor?
				if (Lootster_Options.RollFactoring == true) then
					-- format roll factor
					limits = limits..string.format(LOOTSTER_MSG_ROLLFACTOR, Lootster_Options.RollFactor);
				else
					-- default is 1
					limits = limits..string.format(LOOTSTER_MSG_ROLLFACTOR, 1);
				end
			end
		else
			-- determine if we have a EP minimum
			if (Lootster_Options.EPMin == true) then
				-- format EP minimum
				limits = string.format(LOOTSTER_MSG_EPMINUSED, Lootster_Options.EPMinEP);
			else
				-- default none
				limits = LOOTSTER_MSG_EPMINNONE;
			end
			
			-- determine if we have a GP base
			if (Lootster_Options.GPBase == true) then
				-- format GP base
				limits = limits..string.format(LOOTSTER_MSG_GPBASEUSED, Lootster_Options.GPBaseGP);
			else
				-- default none
				limits = limits..LOOTSTER_MSG_GPBASENONE;
			end
		end	

		-- format DKP mode message
		msg = string.format(LOOTSTER_MSG_DKPMODE, mode, member, toon, ffa, limits);
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		local	mode, call, member, toon, ffa;

		-- determine the normal type
		if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
			-- tell everyone that we are using 100/1000
			mode = LOOTSTER_MSG_TYPE1001000;

			-- see if roll calls are required
			if (Lootster_Options.NormAutoRoll == true) then
				call = LOOTSTER_MSG_OPTIONAL;
			else
				call = LOOTSTER_MSG_REQUIRED;
			end
		elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYNEEDGREED) then
			-- tell everyone that we are using Need then Greed
			mode = LOOTSTER_MSG_TYPENEEDGREED;

			-- roll calls always required
			call = LOOTSTER_MSG_REQUIRED;
		elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL) then
			-- tell everyone that we are using FFA
			mode = LOOTSTER_MSG_TYPEFREEFORALL;

			-- see if roll calls are required
			if (Lootster_Options.NormAutoRoll == true) then
				call = LOOTSTER_MSG_OPTIONAL;
			else
				call = LOOTSTER_MSG_REQUIRED;
			end
		else
			-- unknown normal type - hammer into greed then need type and recall
			Lootster_Options.NormType = LOOTSTER_ENUM_NORM.BYNEEDGREED;

			return(Lootster_GetRollHandling());
		end

		-- determine membership
		if (Lootster_Options.NormMember == true) then
			member = LOOTSTER_MSG_MEMBERUSED;
		else
			member = LOOTSTER_MSG_MEMBERNONE;
		end

		-- determine toon
		if (Lootster_Options.NormToon == true) then
			toon = LOOTSTER_MSG_TOONUSED;
		else
			toon = LOOTSTER_MSG_TOONNONE;
		end

		-- determine FFA for greed
		if (Lootster_Options.NormGreedFFA == true) then
			ffa = LOOTSTER_MSG_GREEDFFAUSED;
		else
			ffa = LOOTSTER_MSG_GREEDFFANONE;
		end

		-- format normal mode message
		msg = string.format(LOOTSTER_MSG_NORMMODE, mode, member, toon, ffa, call);
	else
		-- unknown roll type - hammer into normal mode and recall
		Lootster_Options.RollMode = LOOTSTER_ENUM_ROLLMODE.USENORM;

		return(Lootster_GetRollHandling());
	end

	return msg;
end

-- Retrieve Item DKP handler
function Lootster_GetItemDKP(itemText, itemLink, show)
	local	itemRarity, itemEquipLoc, itemType, slot, name, itemKey, itemRec, items, dkp, reason, dkpType, dkpOff, dkpMan, qActive;

	-- reset located items, dkp, dkp loot type, official dkp, manual dkp and text
	items = 0;
	dkp = 0;
	reason = "";
	dkpOff = 0;
	dkpMan = 0;
	dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.NONE;
	
	-- first check our itembase
	if ((itemText ~= nil) and (itemText ~= "")) then
		-- attempt to locate this item
		name = string.lower(itemText);

		for itemKey, itemRec in pairs(Lootster_ItemDKP) do
			-- does this item match the current loot?
			if (itemRec.Name == name) then
				-- set dkp loot type
				if		(itemRec.DKP ~= nil) then
					-- official or overridden?
					if (itemRec.DKPMan == nil) then
						-- only official DKP is set
						dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.OFFICIAL;

						dkpOff = itemRec.DKP;
					else
						-- both official and override DKP is set
						dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE;

						dkpOff = itemRec.DKP;
						dkpMan = itemRec.DKPMan;
					end
				elseif	((itemRec.DKP == nil) and (itemRec.DKPMan ~= nil)) then
					-- provisory only set
					dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY;

					dkpMan = itemRec.DKPMan;
				end

				-- do we have manual DKP?
				if		(dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.OFFICIAL) then
					-- snarf the official DKP as effective DKP
					dkp = itemRec.DKP;
				elseif	((dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE) or (dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY)) then
					-- snarf the override/provisory DKP as effective DKP
					dkp = itemRec.DKPMan;
				end
				
				-- snarf the reason
				reason = itemKey;

				-- and bump located count
				items = items + 1;
			end
		end

		-- if we found more that one item, reset DKP since we don't know which one
		if		(items ~= 1) then
			-- indeterminate DKP, DKP loot type, official and manual DKP
			dkp = 0;
			dkpOff = 0;
			dkpMan = 0;
			dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.NONE;

			-- snarf original item text for reason
			reason = itemText;
		elseif	(reason == "") then
			-- snarf item text for reason
			reason = itemText;
		end
	end

	-- do we calculate item points?
	if		((Lootster_Options.CalcPoints == true) and (itemLink ~= nil)) then
		-- calculate the item points if there is no entry or if it is marked as provisory
		if ((dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.NONE) or (dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY)) then
			-- calculate item DKP.  The quality active flag tells us if this is actually a calculated points item
			dkp, qActive = Lootster_CalcItemDKP(itemLink, show);
			
			-- is calculated points is not active for the item quality?
			if (qActive == true) then
				-- we always have only one item
				items = 1;
				
				-- if no official value, this is the official DKP
				if		(dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.NONE) then
					-- only official DKP is set
					dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.OFFICIAL;
				elseif	(dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY) then
					-- mark it as an override, which in effect it is
					dkpType = LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE;
				end
				
				-- official DKP is returned either way
				dkpOff = dkp;
				
				-- snarf item text for reason
				reason = itemText;
			end
		end
	elseif	((show == true) and (itemLink ~= nil)) then
		-- we are showing item points so cause it to calculate
		Lootster_CalcItemDKP(itemLink, show);
	end
	
	return dkp, reason, items, dkpType, dkpOff, dkpMan;
end

-- Retrieve Item Link handler
function Lootster_GetItemLink(itemId, itemText)
	local	_, isCached, itemLink;

	-- attempt to get the (cached) link
	_, itemLink = GetItemInfo(itemId);

	-- item cached?
	isCached = (itemLink ~= nil);

	-- is this item cached?
	if (isCached == false) then
		-- format a fake link
		itemLink = string.format(LOOTSTER_ITEMLINK_FORMAT, Lootster_LootQuality[LOOTSTER_ENUM_LOOTMODE.UNKNOWN], tonumber(itemId), itemText);
	end

	return isCached, itemLink;
end

-- Retrieve Item Basics handler
function Lootster_GetItemBasics(itemLink)
	local	_, itemId, itemText, itemQual;

	-- do we have an 10 ID (Cata) item?
	if (itemLink ~= nil) then
		_, _, itemQual, itemId, itemText  = string.find(itemLink, LOOTSTER_ITEMFULL_PATTERN);
	end

	-- reset text if we have no item id
	if (itemId == nil) then
		-- no item id so reset text
		itemText = "";
	else
		-- convert item id to number
		itemId = tonumber(itemId);
	end

	-- translate into our item quality
	if (itemQual ~= nil) then
		itemQual = Lootster_LootQuality[itemQual];
	else
		itemQual = LOOTSTER_ENUM_LOOTMODE.UNKNOWN;
	end

	return itemId, itemText, itemQual;
end

-- Retrieve Item Details handler
function Lootster_GetItemDetails(itemLink)
	local	_, itemId, itemText, itemQual, ix, field, text, singulars, singular, classes, class, flag;

	local	restricted = false;
	local	restrictedLock = false;

	local	restrictions = {};
	local	restrictionsN = 0;
	local	restrictionsMask = 0;

	-- get the item basics
	itemId, itemText, itemQual = Lootster_GetItemBasics(itemLink);

	-- do we have a known 10 ID (Cata) item?
	if ((itemId ~= nil) and (itemQual ~= LOOTSTER_ENUM_LOOTMODE.UNKNOWN)) then
		-- process the item for class restrictions by getting the game tooltip to parse prepare the data
		Lootster_Tooltip:SetHyperlink(itemLink);

		-- WoW Call of the Crusade 3.2.0 introduced items with the same name but different levels, the higher
		-- being from heroic dungeons.  WoW Dragon Soul 4.3.0 introduced a new level of Looking for Raid, below
		-- normal gear.  We need to extract that indicators from the tooltip
		field = _G["Lootster_TooltipTextLeft2"];

		if ((field ~= nil) and field:IsShown()) then
			text = field:GetText();

			-- see if it is a RF or heroic item
			if		((text ~= nil) and (string.find(text, LOOTSTER_RF_PATTERN) ~= nil)) then
				-- append the RF tag to the name
				itemText = itemText..LOOTSTER_RF_INDICATOR
			elseif	((text ~= nil) and (string.find(text, LOOTSTER_HEROIC_PATTERN) ~= nil)) then
				-- append the heroic tag to the name
				itemText = itemText..LOOTSTER_HEROIC_INDICATOR
			end
		end

		-- hammer through the tooltip text items looking for any class restrictions
		for ix=1, 30, 1 do
			-- get left text field (the prompt)
			field = _G["Lootster_TooltipTextLeft"..ix];

			if ((field ~= nil) and field:IsShown()) then
				text = field:GetText();

				-- if we have a line break, end processing to prevent processing the restrictions on the item
				-- that is produced by this item
				if ((text ~= nil) and (string.sub(text, 1, 1) == "\n")) then
					text = nil;
					ix = 30;
				end
			else
				text = nil;
			end

			-- do we have text?
			if (text ~= nil) then
				-- see if it is a singulars class qualifiers
				_, _, singulars = string.find(text, LOOTSTER_CLASSES_PATTERN);

				if (singulars ~= nil) then
					-- hmm, dude is class restricted and locked
					restricted = true;
					restrictedLock = true;

					-- okay, snarf out the singulars classes
					for singular in string.gmatch(singulars, LOOTSTER_CLASS_PATTERN) do
						-- we have an invariant for this guy?
						if (Lootster_ClassSingular[singular] ~= nil) then
							-- map this singular to the invariant
							class = Lootster_ClassSingular[singular];

							-- class allowed
							restrictions[class] = true;

							-- bump count
							restrictionsN = restrictionsN + 1;

							-- add to mask
							restrictionsMask = bit.bor(restrictionsMask, LOOTSTER_CLASS[class].Mask);
						end
					end
				end
			end
		end

		-- did we find class restrictions on the item?
		if (restricted == false) then		
			-- no, so see if we have quest imposed class restrictions
			if		(LOOTSTER_CLASS_LOOT[itemId] ~= nil) then
				-- hmm, dude should be class restricted and locked
				restricted = true;
				restrictedLock = true;

				classes = LOOTSTER_CLASS_LOOT[itemId];
			elseif	((itemId ~= nil) and (Lootster_Restrict[itemId] ~= nil)) then
				-- hmm, dude should be class restricted but is not locked
				restricted = true;
				restrictedLock = false;

				classes = Lootster_Restrict[itemId].Classes;
			end

			-- did we find some class restrictions?
			if (restricted == true) then
				-- get each restriction.  Note that faction classes will be ignored when later processed
				for ix, class in ipairs(classes) do
					-- class allowed
					restrictions[class] = true;

					-- add to mask if on
					restrictionsMask = bit.bor(restrictionsMask, LOOTSTER_CLASS[class].Mask);
				end

				-- set count
				restrictionsN = #classes;
			end
		end
	end

	return itemId, itemText, itemQual, restricted, restrictedLock, restrictions, restrictionsN, restrictionsMask;
end

-- Get Raid Type Event DKP handler
function Lootster_GetEventDKP(raidType, eventType)
	local	dkp, partial, standby;
	
	-- no initial DKP
	dkp = 0;
	partial = 0;
	standby = 0;
	
	-- determine the raid type to determine preset award values
	if		((raidType == LOOTSTER_ENUM_RAIDTYPE.RAID10NORM) or (raidType == LOOTSTER_ENUM_RAIDTYPE.RAID10HERO)) then 
		-- are we using this event?
		if (Lootster_Options.Event[eventType].Use10 == true) then
			-- get 10 man DKP values
			dkp = Lootster_Options.Event[eventType].DKP10;
			partial = Lootster_Options.Event[eventType].Partial10;
			standby = Lootster_Options.Event[eventType].Standby10;
		end
	elseif	((raidType == LOOTSTER_ENUM_RAIDTYPE.RAID25NORM) or (raidType == LOOTSTER_ENUM_RAIDTYPE.RAID25HERO) or (raidType == LOOTSTER_ENUM_RAIDTYPE.OUTDOOR)) then 
		-- are we using this event?
		if (Lootster_Options.Event[eventType].Use25 == true) then
			-- get 25 man DKP values
			dkp = Lootster_Options.Event[eventType].DKP25;
			partial = Lootster_Options.Event[eventType].Partial25;
			standby = Lootster_Options.Event[eventType].Standby25;
		end
	end

	return dkp, partial, standby;
end

-- Get Matching Raid and Boss, if any
function Lootster_GetMatchingRaidNBoss(zone, type, wowId)
	local	raidId, raidMatchId, bossId, bossMatchId, raidRec, flag, dateOpn, dateBeg;
	
	-- check raids.  Those without a WoW Id only match if they were the last created
	for raidId, raidRec in pairs(Lootster_Raid) do
		-- match by WoW Id?
		if		((wowId ~= nil) and (raidRec.WoWId ~= nil)) then
			-- since WoW Id is used (either in search or in this raid record), match by Id
			if (wowId == raidRec.WoWId) then
				-- absolute match
				raidMatchId = raidId;
				break;
			end
		elseif ((dateOpn == nil) or (dateOpn < raidRec.DateOpn)) then
			-- matching by last opened instance, zone and type
			raidMatchId = raidId;
			dateOpn = raidRec.DateOpn;
		end
	end
	
	-- determine match results
	if		(raidMatchId == nil) then
		return nil, nil;
	elseif	((Lootster_Raid[raidMatchId].DateOpn + (Lootster_Options.Event[LOOTSTER_ENUM_EVENT.RAIDSTART].Time * 60 * 60)) < Lootster_CalcServerTime(time())) then
		-- create a new raid if this is outside the the raid start time
		return nil, nil;
	elseif	((wowId == nil) or (Lootster_Raid[raidMatchId].WoWId == nil)) then
		-- last created raid has to match zone and type...
		if ((zone ~= Lootster_Raid[raidMatchId].Zone) or (type ~= Lootster_Raid[raidMatchId].Type)) then
			return nil, nil;
		end
	end
	
	-- locate last created boss
	for bossId, flag in pairs(Lootster_Raid[raidMatchId].BossSet) do
		-- last boss that is a boss type?
		if ((LOOTSTER_BOSSTYPE_BOSS[Lootster_Boss[bossId].Type] == true) and ((dateBeg == nil) or (dateBeg < Lootster_Boss[bossId].DateBeg))) then
			-- last one so far
			bossMatchId = bossId;
			dateBeg = Lootster_Boss[bossId].DateBeg;
		end
	end
		
	return raidMatchId, bossMatchId;
end

-- Get Matching Boss, if any
function Lootster_GetMatchingBoss(raidId, boss, bossType)
	local	bossId, bossMatchId, attempt;
	
	-- locate last attempt on this boss and boss type in the raid
	for bossId, flag in pairs(Lootster_Raid[raidId].BossSet) do
		-- last attempt on this boss and/or boss type?
		if ((((boss ~= nil) and (Lootster_Boss[bossId].Boss == boss)) or ((bossType ~= nil) and (bossType == Lootster_Boss[bossId].Type))) and ((attempt == nil) or (attempt < Lootster_Boss[bossId].Attempt))) then
			-- last one so far
			bossMatchId = bossId;
			attempt = Lootster_Boss[bossId].Attempt;
		end
	end
		
	return bossMatchId;
end

-- Get Boss Id handler
function Lootster_GetBossId(guidNPC)
	local isHex, idHex, isNPC, npcId;
	
	-- not an NPC and no boss ID
	isNPC = false;
	npcId = 0;
	
	-- attempt to get the NPC flags and boss ID
	for isHex, idHex in string.gmatch(guidNPC, LOOTSTER_UNIT_PATTERN) do
		-- convert to decimal
		isNPC = (bit.band(tonumber(isHex, 16), LOOTSTER_UNIT_NPC) ~= 0);
		npcId = tonumber(idHex, 16);
	end
	
	return npcId, isNPC;
end

-- Get Zone Instance Id handler
function Lootster_GetInstanceId(zone, type)
	local	ix, count, instance, wowId, timeExp, mode, locked, extended, playerId, isRaid, wowId;
	
	-- normalise type to make testing easier - we are looking for heroic or non-heroic only
	if (type == LOOTSTER_ENUM_RAIDTYPE.OUTDOOR) then
		type = LOOTSTER_ENUM_RAIDTYPE.RAID25NORM;
	end
	
	-- get count of instances
	count = GetNumSavedInstances();
	
	-- look for passed zone
	for ix=1, count do
		-- get this saved instance information
		instance, wowId, timeExp, mode, locked, extended, playerId, isRaid = GetSavedInstanceInfo(ix);
		
		-- ignore instances that are not locked or extended
		if (locked or extended) then		
			-- determine instance type
			if		(not isRaid) then
				-- dungeon tests
				if		(mode == 1) then
					-- normal dungeon
					mode = LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM;
				elseif	(mode == 2) then
					-- heroic dungeon
					mode = LOOTSTER_ENUM_RAIDTYPE.DUNGEONHERO;
				else
					mode = LOOTSTER_ENUM_RAIDTYPE.UNKNOWN;
				end
			elseif	(isRaid) then
				-- raid tests
				if		(mode == 1) then
					-- normal 10 man
					mode = LOOTSTER_ENUM_RAIDTYPE.RAID10NORM;
				elseif	(mode == 2) then
					-- normal 25 man
					mode = LOOTSTER_ENUM_RAIDTYPE.RAID25NORM;
				elseif	(mode == 3) then
					-- heroic 10 man
					mode = LOOTSTER_ENUM_RAIDTYPE.RAID10HERO;
				elseif	(mode == 4) then
					-- heroic 25 man
					mode = LOOTSTER_ENUM_RAIDTYPE.RAID25HERO;
				else
					mode = LOOTSTER_ENUM_RAIDTYPE.UNKNOWN;
				end
			end
			
			-- the one we are looking for?
			if ((zone == instance) and (type == mode)) then
				-- woot! We are done
				return wowId, Lootster_CalcServerTime(time() + timeExp);
			end
		end
	end
	
	return nil, nil;
end

-- Transmit Roll Call handler
function Lootster_XmitRollCall()
	local	recCount, type, usePriorMember, usePriorToon, useGreedFFA;

	-- we must be active to transmit the roll call
	if (Lootster_Options.Active == false) then
		-- ignore
		return;
	end

	-- initiate roll synchronise
	Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_CALLROLL, LOOTSTER_ADDON_VERSION), true);

	-- calculate record count.  Always at least one for the roll and mode
	recCount = 2;

	-- are we in DKP roll mode?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- we adding in earnt attendance DKP?
		if ((Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) and (Lootster_Options.DKPAttEarnt == true)) then
			-- bump for using earnt DKP
			recCount = recCount + 1;
		end
		
		-- we have DKP caps?
		if (Lootster_Options.DKPCaps == true) then
			-- bump for caps
			recCount = recCount + 1;
		end
		
		-- handle DKP types
		if		((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) and (Lootster_Options.DKPFactoring == true)) then
			-- bump for modified roll
			recCount = recCount + 1;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) and (Lootster_Options.RollFactoring == true) then
			-- bump for modified DKP
			recCount = recCount + 1;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- bump for EPGP
			recCount = recCount + 1;
		end
	end

	-- handle Tied winners
	if (Lootster_NBG == LOOTSTER_NBG_TIED) then
		-- bump count for winner list
		recCount = recCount + 1;
	end

	-- handle the class restrictions
	if (Lootster_ClassRestrictionsN > 0) then
		-- bump count for class list
		recCount = recCount + 1;
	end
	
	-- handle additional DKP informations
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- handle usage
		if (Lootster_Options.UsageRolls == true) then
			-- bump count for usage list
			recCount = recCount + 1;
		end
	
		-- bump count for events
		recCount = recCount + 1;
		
		-- handle item points
		if (Lootster_Options.CalcPoints == true) then
			-- bump count for points list
			recCount = recCount + 1;
		end
	end
	
	-- begin transaction
	Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_BEGIN, LOOTSTER_ADDON_VERSION, recCount), true);

	-- gather roll information
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- use DKP type
		type = Lootster_Options.DKPType;
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- use Normal type
		type = Lootster_Options.NormType;
	else
		-- who knows
		type = 0;
	end

	-- get priority member use
	if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPMember == true)) or
		((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormMember == true))) then
		usePriorMember = true;
	else
		usePriorMember = false;
	end

	-- get priority member use
	if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPToon == true)) or
		((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormToon == true))) then
		usePriorToon = true;
	else
		usePriorToon = false;
	end

	-- get greed FFA use
	if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPGreedFFA == true)) or
		((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormGreedFFA == true))) then
		useGreedFFA = true;
	else
		useGreedFFA = false;
	end

	-- roll type transaction
	Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_MODE, Lootster_Options.RollMode, type, tostring(usePriorMember), tostring(usePriorToon), tostring(useGreedFFA),
									 tostring(Lootster_Options.RankMembers[Lootster_SelfGuild]), tostring(Lootster_Options.NoteToons[Lootster_SelfGuild]), 
									 tostring(Lootster_Options.RankToons[Lootster_SelfGuild]), tostring(Lootster_SelfGuild)), true);

	-- are we in DKP roll mode?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- we adding in earnt attendance DKP?
		if ((Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) and (Lootster_Options.DKPAttEarnt == true)) then
			-- Earnt DKP use transaction
			Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_EARN, tostring(Lootster_Options.DKPAttEarnt)), true);
		end
		
		-- have we got DKP caps in place?
		if (Lootster_Options.DKPCaps == true) then
			-- DKP limit transaction
			Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_CAPS, Lootster_Options.DKPLo, Lootster_Options.DKPHi), true);
		end

		-- what kind of DKP type?
		if		((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) and (Lootster_Options.DKPFactoring == true)) then
			-- DKP factoring transaction
			Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_FCTR, Lootster_Options.DKPFactor), true);
		elseif	((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) and (Lootster_Options.RollFactoring == true)) then
			-- roll factoring transaction
			Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_FCTR, Lootster_Options.RollFactor), true);
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- EPGP limit transaction
			Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_EPGP, tostring(Lootster_Options.EPMin), Lootster_Options.EPMinEP, 
											 tostring(Lootster_Options.GPBase), Lootster_Options.GPBaseGP), true);
		end
	end

	-- roll call transaction
	Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_ROLL, Lootster_NBG, Lootster_ItemCount, tostring(Lootster_ItemLink)), true);

	-- handle tied winners
	if (Lootster_NBG == LOOTSTER_NBG_TIED) then
		-- list tied rolls transaction
		Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_TIED, Lootster_EncodeText(Lootster_Serialise(Lootster_TiedRolls)), 
										 Lootster_EncodeText(Lootster_Serialise(Lootster_TiedRollsSort))), true);
	end

	-- handle the class restrictions
	if		(Lootster_ClassRestrictionsN > 0) then
		-- list classes transaction
		Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_CLASS, Lootster_ClassRestrictionsMaskCurr, Lootster_ClassRestrictionsN,
										 Lootster_EncodeText(Lootster_Serialise(Lootster_ClassRestrictions))), true);
	end
	
	-- handle usage if in DKP mode
	if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.UsageRolls == true)) then
		-- usage transaction
		Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_USAGE, Lootster_EncodeText(Lootster_Serialise(Lootster_Options.Usage)), 
										 Lootster_EncodeText(Lootster_Serialise(Lootster_Options.UsageSort))), true);
	end	

	-- handle events if in DKP mode
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- event transaction
		Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_EVENTS, Lootster_EncodeText(Lootster_Serialise(Lootster_Options.Event))), true);
	end	
		
	-- handle item points if in DKP mode
	if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.CalcPoints == true)) then
		-- item points transaction
		Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_POINTS, Lootster_Options.pFactor, Lootster_EncodeText(Lootster_Serialise(Lootster_Options.Quality)),
										 Lootster_EncodeText(Lootster_Serialise(Lootster_Options.Slot))), true);
	end
	
	-- commit transaction
	Lootster_SendAddon(string.format(LOOTSTER_ADDON_EXP_COMMIT, LOOTSTER_ADDON_VERSION), true);	
end

-- Echo Item Points handler
function Lootster_EchoItemPoints(requestor, itemKey)
	local	dkp;

	-- do we have DKP for this item?
	if (Lootster_ItemDKP[itemKey] ~= nil) then
		-- do we have manual DKP?
		if (Lootster_ItemDKP[itemKey].DKPMan == nil) then
			-- snarf the normal DKP
			dkp = Lootster_ItemDKP[itemKey].DKP;
		else
			-- snarf the override DKP
			dkp = Lootster_ItemDKP[itemKey].DKPMan;
		end

		-- send points information as apropos
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			-- send to the requestor
			Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ITEMGP, dkp, itemKey, Lootster_ItemDKP[itemKey].Mob));
		else
			-- send to the requestor
			Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ITEMDKP, dkp, itemKey, Lootster_ItemDKP[itemKey].Mob));
		end
	end
end

-- Announce Roll Call handler
function Lootster_AnnounceRollCall(usage)
	-- format the need roll message and let everyone know
	if		((Lootster_ItemPrompt == nil) and (Lootster_NBG == LOOTSTER_NBG_TIED)) then
		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.CALL, string.format(LOOTSTER_MSG_NBG_TIED, Lootster_NBG_ClassPlease, Lootster_NBG));
	elseif	(Lootster_ItemPrompt == nil) then
		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.CALL, string.format(LOOTSTER_MSG_NBG, Lootster_NBG_ClassPlease, Lootster_NBG));
	elseif	((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_NBG == LOOTSTER_NBG_TIED)) then
		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.CALL, string.format(LOOTSTER_MSG_NBG_TIED_LINK, Lootster_NBG_ClassPlease, Lootster_NBG, Lootster_ItemPrompt));
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.CALL, string.format(LOOTSTER_MSG_NBG_LINK, Lootster_NBG_ClassPlease, Lootster_NBG, Lootster_ItemPrompt));
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		local	dkp, reason, items, cost;
		
		-- a usage supplied?
		if (usage == nil) then
			-- set to main need
			usage = LOOTSTER_ENUM_USAGE.MAINNEED;
		end

		-- retrieve default DKP, reason text and item count
		dkp, reason, items = Lootster_GetItemDKP(Lootster_ItemText, Lootster_ItemLink)

		-- calculate the usage factors
		dkp = Lootster_CalcUsageDKP(nil, nil, usage, dkp);
		
		-- and normalise
		dkp = Lootster_CalcPoints(dkp);
		
		if		(items == 0) then
			-- to be determined
			cost = LOOTSTER_COST_DKPTBD;
		elseif	(dkp == 0) then
			-- no cost or to be determined
			cost = LOOTSTER_COST_DKP0TBD;
		else
			-- format cost
			cost = string.format(LOOTSTER_COST_POINTS, dkp);
		end

		Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.CALL, string.format(LOOTSTER_MSG_NBG_LINK_COST, Lootster_NBG_ClassPlease, Lootster_NBG, Lootster_ItemPrompt, cost));

		-- if this is DKP by Tier, broadcast tiers prompt
		if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			Lootster_SendRaidWarning(LOOTSTER_ENUM_RAIDWARN.ALL, Lootster_LevelsPrompt);
		end

		-- hammer through the roster whispering each their DKP
		for player, rosRec in pairs(Lootster_Roster) do
			-- have they switched off DKP information on NEED roll call tells?
			if (Lootster_TestPlayerTell(player, "AckNoInfo") == true) then
				-- are we using class restrictions?
				if (Lootster_IsUsageRestricted(nil, rosRec.ClassType) == false) then
					-- echo roll to player with class
					Lootster_EchoPlayerRoll(player);
				end
			end
		end
	end
end

-- Echo Player Attendances handler
function Lootster_EchoPlayerAttends(requestor, playerkey, notpartied)
	local	main, key;

	-- resolve the player into a main
	main = Lootster_GetAltMain(playerkey);

	-- use sorted list of attendances
	for ix, key in ipairs(Lootster_BossAttendSort) do
		-- our player?
		if (main == Lootster_Attend[key].Player) then
			-- we have the ability to whisper to a non-roster player
			if ((Lootster_Roster[requestor] ~= nil) or ((notpartied ~= nil) and (notpartied == true))) then
				-- are we using DKP?
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						-- send to the requestor with EP/GP
						Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ATTENDEPGP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].key], 
																	  Lootster_Attend[key].DKPAdjEarnt, playerkey));
					else
						-- send to the requestor with DKP
						Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ATTENDDKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].key], 
																	  Lootster_Attend[key].DKPAdjEarnt, playerkey));
					end
				else
					-- send to the requestor with DKP
					Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ATTENDNODKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].key], playerkey));
				end
			end
		end
	end

	-- whisper points information as well
	Lootster_EchoPlayerPoints(requestor, playerkey, notpartied);
end

-- Echo Player Adjustments handler
function Lootster_EchoPlayerAdjusts(requestor, playerkey, notpartied)
	local	main, key, reason;

	-- resolve the player into a main
	main = Lootster_GetAltMain(playerkey);

	-- use sorted list of adjustments
	for ix, key in ipairs(Lootster_BossAdjustSort) do
		-- our player?
		if (main == Lootster_Adjust[key].Player) then
			-- get reason.  Use link if given
			if (Lootster_AdjustRec.Link ~= nil) then
				-- use link
				reason = Lootster_AdjustRec.Link;
			else
				-- just use reason
				reason = Lootster_AdjustRec.Reason;
			end

			-- we have the ability to whisper to a non-roster player
			if ((Lootster_Roster[requestor] ~= nil) or ((notpartied ~= nil) and (notpartied == true))) then
				-- are we using DKP?
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						-- send to the requestor with EP/GP
						Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ADJUSTEPGP, Lootster_Adjust[key].DKPAdjEarnt, 
											 Lootster_Adjust[key].DKPAdjSpent, playerkey, reason));
					else
						-- send to the requestor with DKP
						Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ADJUSTDKP, Lootster_SumDKPUpdate(Lootster_Adjust[key]),
											 playerkey, reason));
					end
				else
					-- send to the requestor with DKP
					Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_ADJUSTNODKP, playerkey, reason));
				end
			end
		end
	end

	-- whisper points information as well
	Lootster_EchoPlayerPoints(requestor, playerkey, notpartied);
end

-- Echo Player Points handler
function Lootster_EchoPlayerPoints(requestor, playerkey, notpartied)
	-- are we using DKP?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- we have the ability to whisper to a non-roster player
		if ((Lootster_Roster[requestor] ~= nil) or ((notpartied ~= nil) and (notpartied == true))) then
			local	main;

			-- resolve the player into a main
			main = Lootster_GetAltMain(playerkey);

			-- send tier information as apropos
			if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
				local	dkpBase, tierBase, priorBase, adjTotal, dkpEffect, tierEffect, priorEffect;

				-- do we have DKP for this player?
				if (Lootster_DKP[main] ~= nil) then
					-- snarf base data
					dkpBase = Lootster_CalcPoints(Lootster_SumDKPTotal(Lootster_DKP[main]));
					tierBase = Lootster_CalcTier(Lootster_SumDKPTotal(Lootster_DKP[main]));

					-- snarf raid adjust
					adjTotal = Lootster_SumDKPUpdate(Lootster_DKP[main]);
				else
					-- set default base data
					dkpBase = 0;
					tierBase = Lootster_CalcTier(dkpBase);

					-- no adjustments, obviously
					adjTotal = 0;
				end

				-- snarf priority
				priorBase = Lootster_FormatPriority(Lootster_GetPlayerMembership(playerkey), Lootster_GetPlayerToonship(playerkey));

				-- snarf effective data
				dkpEffect = Lootster_GetPlayerDKP(playerkey);
				tierEffect = Lootster_GetPlayerTier(playerkey);
				priorEffect = Lootster_FormatPriority(Lootster_GetPlayerMember(playerkey), Lootster_GetPlayerToon(playerkey));

				-- send to the requestor base and effective information including tier
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERTIER, dkpBase, tierBase, priorBase, dkpEffect,
									 tierEffect, priorEffect, adjTotal, playerkey));
			elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
				local	epBase, gpBase, prBase, priorBase, adjEarnt, adjSpent, epEffect, gpEffect, prEffect, priorEffect;

				-- do we have DKP for this player?
				if (Lootster_DKP[main] ~= nil) then
					-- snarf base data
					epBase = Lootster_SumDKPEarnt(Lootster_DKP[main]);
					gpBase = Lootster_SumDKPSpent(Lootster_DKP[main]);
					prBase = Lootster_CalcPR(epBase, gpBase);
					
					-- snarf raid adjust
					adjEarnt = Lootster_SumDKPEarntUpdate(Lootster_DKP[main]);
					adjSpent = Lootster_SumDKPSpentUpdate(Lootster_DKP[main]);
				else
					-- set default base data
					epBase = 0;
					gpBase = 0;
					prBase = Lootster_CalcPR(epBase, gpBase);

					-- no adjustments, obviously
					adjEarnt = 0;
					adjSpent = 0;
				end

				-- snarf priority
				priorBase = Lootster_FormatPriority(Lootster_GetPlayerMembership(playerkey), Lootster_GetPlayerToonship(playerkey));

				-- snarf effective data
				epEffect = Lootster_CalcEP(epBase);
				gpEffect = Lootster_CalcGP(gpBase);
				prEffect = Lootster_CalcPR(epEffect, gpEffect);
				priorEffect = Lootster_FormatPriority(Lootster_GetPlayerMember(playerkey), Lootster_GetPlayerToon(playerkey));
			
				-- send to the requestor base and effective information
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYEREPGP, prBase, epBase, gpBase, priorBase, prEffect, epEffect,
									 gpEffect, priorEffect, adjEarnt, adjSpent, playerkey));
			
			else
				local	dkpBase, priorBase, adjTotal, dkpEffect, priorEffect;

				-- do we have DKP for this player?
				if (Lootster_DKP[main] ~= nil) then
					-- snarf base data
					dkpBase = Lootster_CalcPoints(Lootster_SumDKPTotal(Lootster_DKP[main]));

					-- snarf raid adjust
					adjTotal = Lootster_CalcPoints(Lootster_SumDKPUpdate(Lootster_DKP[main]));
				else
					-- set default base data
					dkpBase = 0;

					-- no adjustments, obviously
					adjTotal = 0;
				end

				-- snarf priority
				priorBase = Lootster_FormatPriority(Lootster_GetPlayerMembership(playerkey), Lootster_GetPlayerToonship(playerkey));

				-- snarf effective data
				dkpEffect = Lootster_GetPlayerDKP(playerkey);
				priorEffect = Lootster_FormatPriority(Lootster_GetPlayerMember(playerkey), Lootster_GetPlayerToon(playerkey));
			
				-- send to the requestor base and effective information
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERDKP, dkpBase, priorBase, dkpEffect, priorEffect, 
									 adjTotal, playerkey));
			end
		end
	end
end

-- Echo Player Roll handler
function Lootster_EchoPlayerRoll(requestor, noPos)
	-- we do nothing if the requestor is not in the party/raid
	if (Lootster_Roster[requestor] ~= nil) then
		local	roll, prior, high, equal, strRoll, strPrior;

		-- get the player roll
		roll = Lootster_GetPlayerRoll(requestor);

		-- get priority text
		prior = Lootster_FormatPriority(Lootster_GetPlayerMember(requestor), Lootster_GetPlayerToon(requestor));

		-- get the position
		high, equal = Lootster_GetPlayerPosition(requestor);
		
		-- are we using DKP?
		if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
			-- format roll
			if ((Lootster_Options.UsageRolls == true) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL)) then
				-- usage rolls just have a message
				strRoll = LOOTSTER_ECHO_PLAYERROLL_ROLLU;
			else
				-- format roll
				strRoll = string.format(LOOTSTER_ECHO_PLAYERROLL_ROLL, roll);
			end
			
			-- format priority
			if (noPos == true) then
				-- no position information
				strPrior = string.format(LOOTSTER_ECHO_PLAYERROLL_PRIOR, prior);
			else
				-- use position information
				strPrior = string.format(LOOTSTER_ECHO_PLAYERROLL_PRIORPOS, prior, high, equal);
			end

			-- see which DKP type we are using
			if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
				local	dkp, strDKP;

				-- calculate the DKP 
				dkp = Lootster_GetPlayerDKP(requestor);
				
				-- format DKP
				strDKP = string.format(LOOTSTER_ECHO_PLAYERROLL_DKP, dkp, strPrior);

				-- send DKP statement to the requestor
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERROLLDKP_FMT, strDKP, strPrior, strRoll));
			elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
				local	dkp, tier, strDKP;

				-- calculate the DKP 
				dkp = Lootster_GetPlayerDKP(requestor);

				-- get the tier
				tier = Lootster_GetPlayerTier(requestor);
				
				-- format DKP and tier
				strDKP = string.format(LOOTSTER_ECHO_PLAYERROLL_TIER, dkp, tier);

				-- send DKP and tier statement to the requestor
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERROLLDKP_FMT, strDKP, strPrior, strRoll));
			elseif	((Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) or (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP)) then
				local	dkp, strDKP;

				-- calculate the DKP 
				dkp = Lootster_GetPlayerDKP(requestor);
				
				-- format DKP
				strDKP = string.format(LOOTSTER_ECHO_PLAYERROLL_DKP, dkp);

				-- send DKP statement to the requestor
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERROLLDKP_FMT, strDKP, strPrior, strRoll));
			elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
				local	pr, strPR;

				-- calculate the PR 
				pr = Lootster_GetPlayerPR(requestor);

				-- format PR
				strPR = string.format(LOOTSTER_ECHO_PLAYERROLL_EPGP, pr);

				-- send EP/GP statement to the requestor with position as required
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERROLLDKP_FMT, strPR, strPrior, strRoll));
			end
		elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
			-- format roll
			strRoll = string.format(LOOTSTER_ECHO_PLAYERROLL_ROLL, roll);
			
			-- format priority
			if (noPos == true) then
				-- no position information
				strPrior = string.format(LOOTSTER_ECHO_PLAYERROLL_PRIORIS, prior);
			else
				-- use position information
				strPrior = string.format(LOOTSTER_ECHO_PLAYERROLL_PRIORPOSIS, prior, high, equal);
			end
			
			-- send simple statement to the requestor
			Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_PLAYERROLLNORM_FMT, strPrior, strRoll));
		end
	end
end

-- Echo Usage Rolls handler
function Lootster_EchoUsageRolls(requestor)
	-- we do nothing if the requestor is not in the party/raid
	if (Lootster_Roster[requestor] ~= nil) then
		local	ix, usage;
		
		-- send list of usage rolls in priority order
		Lootster_SendPrivate(requestor, LOOTSTER_ECHO_USAGEROLLS);
		
		for ix, usage in ipairs(Lootster_Options.UsageSort) do
			-- usage enabled?
			if (Lootster_Options.Usage[usage].Use == true) then
				-- echo this roll command if enabled
				Lootster_SendPrivate(requestor, string.format(LOOTSTER_ECHO_USAGEROLLCMD, Lootster_Options.Usage[usage].Roll, LOOTSTER_USAGEDKP_LIST[usage]));
			end
		end
	end
end

-- Calculate Player Positions handler
function Lootster_CalculatePositions()
	local	playerO, rosRecO, levelName, playerI, rosRecI, dkp, tier, member, toon;
	local	testOP, testIP, testOT, testIT, levels;

	local	count, ix;

	-- reset current tier list
	Lootster_Levels = {};

	-- reset the level sorts
	Lootster_LevelsSort = {};

	-- reset the levels prompt
	Lootster_LevelsPrompt = "";

	-- reset the roll roster
	Lootster_RosterRoll = {};

	-- prime the effective dkp and tier roll roster
	for playerO, rosRecO in pairs(Lootster_Roster) do
		-- see if this guy is class restricted
		if (Lootster_IsUsageRestricted(Lootster_NBG_Usage, rosRecO.ClassType) == false) then
			-- get this guys dkp or PR
			if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then			
				dkp = Lootster_GetPlayerPR(playerO);
			else
				dkp = Lootster_GetPlayerDKP(playerO);
			end
			
			-- get this guystier, member and toon flags
			tier = Lootster_GetPlayerTier(playerO);
			member = Lootster_GetPlayerMember(playerO);
			toon = Lootster_GetPlayerToon(playerO);

			-- and add to the roll roster, along with initialised high and equal counts
			Lootster_RosterRoll[playerO] = Lootster_NewRosterRoll(dkp, tier, member, toon);
		end
	end

	-- hammer through the roll roster, calculating player positions
	for playerO, rosRecO in pairs(Lootster_RosterRoll) do
		-- are we using DKP by Tier?
		if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER)) then
			-- use tier in level name
			levelName = Lootster_RosterRoll[playerO].Tier..LOOTSTER_ECHO_LEVELSEP;
		else
			-- no tier name
			levelName = "";
		end

		-- add priority to level name
		levelName = levelName..Lootster_FormatPriority(Lootster_RosterRoll[playerO].Member, Lootster_RosterRoll[playerO].Toon);

		-- count this level
		if (Lootster_Levels[levelName] == nil) then
			-- initial level count
			Lootster_Levels[levelName] = Lootster_NewLevel(levelName, rosRecO.Tier, rosRecO.Member, rosRecO.Toon);
		else
			-- bump tier count
			Lootster_Levels[levelName].Count = Lootster_Levels[levelName].Count + 1;
		end

		-- hammer through the rest of the roll roster, determining if they have a higher or equal ranking
		for playerI, rosRecI in pairs(Lootster_RosterRoll) do
			-- determine the priority
			testOP = Lootster_PriorityTest(rosRecO.Member, rosRecO.Toon, rosRecI.Member, rosRecI.Toon);
			testIP = Lootster_PriorityTest(rosRecI.Member, rosRecI.Toon, rosRecO.Member, rosRecO.Toon);

			-- see if membership will determine the outcome
			if		(testIP == true) then
				-- this guy is outranked by DKP type
				Lootster_RosterRoll[playerO].High = Lootster_RosterRoll[playerO].High + 1;
			elseif	((testOP == false) and (testIP == false)) then
				-- DKP type determines ranking
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
					-- use DKP
					testOT = rosRecO.DKP > rosRecI.DKP;
					testIT = rosRecI.DKP > rosRecO.DKP;
				elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
					-- use Tier
					testOT = rosRecO.Tier < rosRecI.Tier;
					testIT = rosRecI.Tier < rosRecO.Tier;
				elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					-- use PR=EP/GP (as stored in DKP)
					testOT = rosRecO.DKP > rosRecI.DKP;
					testIT = rosRecI.DKP > rosRecO.DKP;
				else				
					-- roll is only test
					testOT = false;
					testIT = false;
				end

				-- see where this guy sits
				if		(testIT == true) then
					-- this guy is outranked by membership
					Lootster_RosterRoll[playerO].High = Lootster_RosterRoll[playerO].High + 1;
				elseif	((testOT == false) and (testIT == false) and (playerO ~= playerI)) then
					-- both are false, this guy is an equal (and not us!)
					Lootster_RosterRoll[playerO].Equal = Lootster_RosterRoll[playerO].Equal + 1;
				end
			end
		end
	end

	-- resort the levels
	Lootster_Level_Sort();

	-- build list of levels, breaking the lines as necessary
	count = #Lootster_LevelsSort;

	-- don't bother with this prompt if we are all the same
	if (count > 1) then
		-- hammer through each
		for ix=1, count, 1 do
			-- have we exceeded message length?
			if (string.len(Lootster_LevelsPrompt) > LOOTSTER_ECHO_LEVELBREAKDOWNMAXLEN) then
				-- are we are using DKP tiers?
				if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER)) then
					-- format this level breakdown prompt
					Lootster_LevelsPrompt = string.format(LOOTSTER_ECHO_LEVELBREAKDOWNTIER, Lootster_LevelsPrompt);
				else
					-- format this level breakdown prompt
					Lootster_LevelsPrompt = string.format(LOOTSTER_ECHO_LEVELBREAKDOWNNORM, Lootster_LevelsPrompt);
				end

				-- reset the prompt
				Lootster_LevelsPrompt = "";
			end

			-- add name
			Lootster_LevelsPrompt = Lootster_LevelsPrompt..string.format(LOOTSTER_ECHO_LEVELCOUNT, Lootster_Levels[Lootster_LevelsSort[ix]].Name,
																		 Lootster_Levels[Lootster_LevelsSort[ix]].Count);

			if		(ix < (count - 1)) then
				Lootster_LevelsPrompt = Lootster_LevelsPrompt..LOOTSTER_MSG_SEP;
			elseif (ix == (count - 1)) then
				Lootster_LevelsPrompt = Lootster_LevelsPrompt..LOOTSTER_MSG_AND;
			end
		end

		-- are we are using DKP tiers?
		if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER)) then
			-- format this level breakdown prompt
			Lootster_LevelsPrompt = string.format(LOOTSTER_ECHO_LEVELBREAKDOWNTIER, Lootster_LevelsPrompt);
		else
			-- format this level breakdown prompt
			Lootster_LevelsPrompt = string.format(LOOTSTER_ECHO_LEVELBREAKDOWNNORM, Lootster_LevelsPrompt);
		end
	end
end

-- Tooltip Click handler
function Lootster_ClickTooltip(itemLink, button, isExternal, slot)
	local	itemId, itemText, itemQual, echoed;

	-- no echo of class restrictions
	echoed = false;

	-- get the item basics
	itemId, itemText, itemQual = Lootster_GetItemBasics(itemLink);

	-- behaviour is dependent on whether the item is in cache
	if (itemQual == LOOTSTER_ENUM_LOOTMODE.UNKNOWN) then
		-- determine function
		if		(button == "RightButton") then
			-- set query issued
			Lootster_Tooltip.Queried = true;

			-- mark this item as being queried this session
			Lootster_ItemQueried[itemId] = true;
		
			-- attempt to query the item information from the server
			print(string.format(LOOTSTER_MSG_QUERY, itemLink));
		
			-- set hyperlink into our tooltip
			Lootster_Tooltip:SetHyperlink(itemLink);
		end
	else
		-- determine function
		if		((button == "RightButton") and IsControlKeyDown() and (Lootster_Options.EchoRestrict == true) and (Lootster_Options.EchoByClick == true)) then
			-- display restrictions of the hyperlink
			Lootster_Class_Display_OnClick(Lootster_ClassFrameDisplay, button, itemLink);

			-- echo of class restrictions
			echoed = true;
		elseif	((button == "LeftButton") and IsShiftKeyDown()) then
			-- make sure chat window is visible.  Simply set the link if this is call from the WoW API
			if ((ChatEdit_GetActiveWindow() ~= nil) and not isExternal) then
				ChatEdit_GetActiveWindow():Insert(itemLink);
			else
				-- set as the current link
				Lootster_SetHyperlink(itemLink, slot);
			end
		elseif	((button == "LeftButton") and IsControlKeyDown() and not isExternal) then
			-- show item reference tooltip
			ShowUIPanel(ItemRefTooltip);

			-- make sure we can see it
			if (not ItemRefTooltip:IsVisible()) then
				ItemRefTooltip:SetOwner(UIParent, "ANCHOR_PRESERVE");
			end

			-- set the link
			ItemRefTooltip:SetHyperlink(itemLink);
		end
	end

	return echoed;
end

-- Tooltip Display handler
function Lootster_DisplayTooltip(self, itemLink, tooltip)
	local	itemId, itemText, itemQual;

	-- get the item basics
	itemId, itemText, itemQual = Lootster_GetItemBasics(itemLink);

	-- has this item been cached?
 	if (itemQual ~= LOOTSTER_ENUM_LOOTMODE.UNKNOWN) then
 		-- position toolip
		GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");

		-- did we get passed tooltip text override?
		if (tooltip == nil) then
			-- use hyperlink and regular tooltip
			GameTooltip:SetHyperlink(itemLink);
		else
			GameTooltip:ClearLines();
			GameTooltip:SetText(tooltip);
		end
	
		-- hide our tooltip
		Lootster_Tooltip:Hide();
	
		-- and show
		GameTooltip:Show();
		
		-- if the item was uncached, update tooltips
		if (Lootster_ItemQueried[itemId] ~= nil) then
			-- reset uncached flag
			Lootster_ItemQueried[itemId] = nil;
			
            -- update tooltips
            Looster_UpdateTooltip();
		end
	else
 		-- clear and position tootip
		Lootster_Tooltip:ClearLines();
		Lootster_Tooltip:SetOwner(self, "ANCHOR_TOPLEFT");

		-- if this is the first time we have seen the item, mark it as uncached but not queried
		if (Lootster_ItemQueried[itemId] == nil) then
			Lootster_ItemQueried[itemId] = false;
		end

		-- add item text
		Lootster_Tooltip:AddLine(itemText, 1.00, 1.00, 0.00);
		
		-- format uncached tooltip.  Give them not found warning as appropriate
		if (Lootster_ItemQueried[itemId] ~= true) then
 			Lootster_Tooltip:AddLine(LOOTLIST_LISTS_NOITEM, 1.00, 0.00, 0.00);
		else
 			Lootster_Tooltip:AddLine(LOOTLIST_LISTS_NOITEMFOUND, 1.00, 0.00, 0.00);
		end

 		Lootster_Tooltip:AddLine(LOOTLIST_LISTS_ITEMID..itemId, 0.00, 0.44, 0.87);
 		Lootster_Tooltip:AddLine(LOOTLIST_LISTS_UNSAFE, nil, nil, nil, 1);
 		Lootster_Tooltip:AddLine(" ");
 		Lootster_Tooltip:AddLine(LOOTLIST_LISTS_UNCACHED, nil, nil, nil, 1);
	
		-- hide game tooltip
		GameTooltip:Hide();
	
		-- and show
		Lootster_Tooltip:Show();
	end
end

-- Update Tooltip handler
function Looster_UpdateTooltip()
	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);
	
	-- resort loot using current sort
	Lootster_Loot_Sort(nil);
	
	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);
	
	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);
	
	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
	
	-- resort raid adjust using current sort
	Lootster_Raid_Adjust_Sort(nil);

	-- resort raid assign using current sort
	Lootster_Raid_Assign_Sort(nil);
	
	-- resort item using current sort
	Lootster_Item_Sort(nil);
end

-- Handle Attend Custom Channel Change handler
function Lootster_ChannelChange(newChan, oldChan)
	-- if the channels are the same we are done
	if (newChan == oldChan) then
		return;
	end
	
	-- if we have an old channel, leave it
	if (oldChan ~= nil) then
		-- leave the channel
		LeaveChannelByName(oldChan);
		
		-- and smoke exiting channel ID
		Lootster_ChannelID = nil;
	end
	
	-- if we have a new channel, join it
	if (newChan ~= nil) then
		-- join channel
		Lootster_ChannelID = JoinChannelByName(newChan);
		
		-- no channel means a channel name problem or too many channels
		if (Lootster_ChannelID == nil) then
			-- let them know
			if (DEFAULT_CHAT_FRAME) then
				DEFAULT_CHAT_FRAME:AddMessage(string.format(LOOTSTER_MSG_HERE_NOCHANNEL, newChan));
			end
		end
	end
end

-- Sort Rolls handler
function Lootster_Roll_Sort()
	-- setup sort indirection
	Lootster_RollsSort = {};

	for key, value in pairs(Lootster_Rolls) do
		Lootster_RollsSort[#Lootster_RollsSort + 1] = key;
	end

	-- resort the roll data on the roll
	table.sort(Lootster_RollsSort, Lootster_RollTest);
end

-- Roll Test handler
function Lootster_RollTest(i1, i2)
	local	h1, h2;
	local	r1, r2;
	local	p1, p2;
	local	mp1, mp2;
	local	tp1, tp2;

	-- retrieve indirected held data
	h1 = Lootster_Rolls[i1].Hold;
	h2 = Lootster_Rolls[i2].Hold;

	-- preprocess held rolls
	if (h1 ~= h2) then
		-- depends on whoose roll is being held
		return h2;
	end

	-- retrieve indirected roll data
	r1 = Lootster_Rolls[i1].Roll;
	r2 = Lootster_Rolls[i2].Roll;

	-- preprocess nil and passed rolls
	if		((r1 == nil) and (r2 == nil)) then
		-- both haven't rolled, which means that we will still sort them as usual, but by setting roll to 
		-- zero so highest membership yet to roll player will appear first
		r1 = 0;
		r2 = 0;
	elseif	(r1 == nil) then
		return false;
	elseif	(r2 == nil) then
		return true;
	elseif	((r1 <= 0) and (r2 <= 0)) then
		-- both passed, which means that we will still sort them as usual, but by negating rolls so highest
		-- membership/roll passed roller will appear first
		r1 = -r1;
		r2 = -r2;
	elseif	(r1 <= 0) then
		return false;
	elseif	(r2 <= 0) then
		return true;
	end

	-- handle sort based on usage, but only in DKP mode that is not modified rolling
	if ((Lootster_Options.UsageRolls == true) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYMODIFIEDROLL)) then
		-- retrieve the indirected usage priority
		p1 = Lootster_Options.Usage[Lootster_Rolls[i1].Usage].Priority;
		p2 = Lootster_Options.Usage[Lootster_Rolls[i2].Usage].Priority;

		-- decide by usage priority if different
		if (p1 ~= p2) then
			-- lower is higher
			return p1 < p2;
		end
	end
	
	-- check if greed rolls are FFA
	if (((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (Lootster_Options.DKPGreedFFA == true)) or
		((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) and (Lootster_Options.NormGreedFFA == true))) then
		-- ignore DKP/Tier/membership/toon if rolls are both greed
		if ((Lootster_Rolls[i1].Usage == LOOTSTER_ENUM_USAGE.GREED) and (Lootster_Rolls[i2].Usage == LOOTSTER_ENUM_USAGE.GREED)) then
			-- decide by roll difference
			return r1 > r2;
		end
	end
	
	-- retrieve membership data
	mp1 = Lootster_Rolls[i1].Member;
	mp2 = Lootster_Rolls[i2].Member;
	tp1 = Lootster_Rolls[i1].Toon;
	tp2 = Lootster_Rolls[i2].Toon;

	-- preprocess membership priority
	if		(Lootster_PriorityTest(mp1, tp1, mp2, tp2) == true) then
		-- priority made a difference
		return true;
	elseif	(Lootster_PriorityTest(mp2, tp2, mp1, tp1) == true) then
		-- priority made a difference
		return false;
	end
	
	-- handle sort based on roll mode, type and the rolls themselves 
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- test using a DKP method
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYDKP) then
			local	d1, d2;

			-- retrieve indirected data DKP
			d1 = Lootster_Rolls[i1].DKP;
			d2 = Lootster_Rolls[i2].DKP;

			-- decide by DKP then roll
			if		(d1 ~= d2) then
				-- differing DKP so use it
				return d1 > d2;
			else
				-- same DKP, so use roll difference
				return r1 > r2;
			end
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYTIER) then
			local	t1, t2;

			-- retrieve tier data
			t1 = Lootster_Rolls[i1].Tier;
			t2 = Lootster_Rolls[i2].Tier;

			-- decide by Tier then roll
			if		(t1 ~= t2) then
				-- lower tiers have higher priority
				return t1 < t2;
			else
				-- same Tier, so use roll difference
				return r1 > r2;
			end
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
			-- decide by modified roll
			return r1 > r2;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
			local	d1, d2;

			-- decide by roll modified DKP
			d1 = Lootster_GetPlayerResult(Lootster_Rolls[i1]);
			d2 = Lootster_GetPlayerResult(Lootster_Rolls[i2]);

			-- use DKP + factored roll difference
			return d1 > d2;
		elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			local	d1, d2;

			-- retrieve indirected data DKP
			d1 = Lootster_Rolls[i1].DKP;
			d2 = Lootster_Rolls[i2].DKP;

			-- decide by PR then roll
			if		(d1 ~= d2) then
				-- differing PR so use it
				return d1 > d2;
			else
				-- same DKP, so use roll difference
				return r1 > r2;
			end
		else
			-- no idea what DKP type, so use roll difference
			return r1 > r2;
		end
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- use Normal method
		if		(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BY1001000) then
			local	t1, t2;

			-- retrieve NEED/GREED data
			t1 = Lootster_Rolls[i1].Usage;
			t2 = Lootster_Rolls[i2].Usage;

			-- decide by NEED/GREED then roll
			if		(t1 ~= t2) then
				-- differing NEED/GREED so use it
				return t1 < t2;
			else
				-- same NEED/GREED, so use roll difference
				return r1 > r2;
			end
		elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYNEEDGREED) then
			-- just use roll difference
			return r1 > r2;
		elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_NORM.BYFREEFORALL) then
			-- decide by roll difference
			return r1 > r2;
		else
			-- no idea what Normal type, so use roll difference
			return r1 > r2;
		end
	else
		-- no idea what roll mode, so use roll difference
		return r1 > r2;
	end
end

-- Roll Equal handler
function Lootster_RollEqual(i1, i2)
	-- they are equal if the roll test is the same with each switched
	return (not Lootster_RollTest(i1, i2)) and (not Lootster_RollTest(i2, i1));
end

-- Sort Levels handler
function Lootster_Level_Sort()
	-- setup sort indirection
	Lootster_LevelsSort = {};

	for key, value in pairs(Lootster_Levels) do
		Lootster_LevelsSort[#Lootster_LevelsSort + 1] = key;
	end

	-- resort the level data on the tier and membership
	table.sort(Lootster_LevelsSort, Lootster_LevelTest);
end

-- Level Test handler
function Lootster_LevelTest(i1, i2)
	local	t1, t2;
	
	-- see if membership in effect
	if		(Lootster_PriorityTest(Lootster_Levels[i1].Member, Lootster_Levels[i1].Toon, Lootster_Levels[i2].Member, Lootster_Levels[i2].Toon) == true) then
		-- priority is higher
		return true;
	elseif	(Lootster_PriorityTest(Lootster_Levels[i2].Member, Lootster_Levels[i2].Toon, Lootster_Levels[i1].Member, Lootster_Levels[i1].Toon) == true) then
		-- priority made a difference
		return false;
	else
		-- priority the same - retrieve indirected tier data
		t1 = Lootster_Levels[i1].Tier;
		t2 = Lootster_Levels[i2].Tier;
	
		-- do the tiers differ?
		return t1 < t2;
	end
end

-- Priority Test handler
function Lootster_PriorityTest(m1, t1, m2, t2)
	-- Membership > Toon
	if (m1 == m2) then
		-- membership is equal, so use toon priority: Main > Alt
		return t1 < t2;
	else
		-- membership priority: Full > Trial > App
		return m1 < m2;
	end
end

-- Data DKP Sort handler
function Lootster_Data_DKP_Sort(col)
	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_DKPSortCol) then
			-- flip sort order
			Lootster_DKPSortOrd = not Lootster_DKPSortOrd;
		else
			-- force ascending
			Lootster_DKPSortOrd = true;
		end
		
		Lootster_DKPSortCol = col;
	end

	-- setup sort indirection
	Lootster_DKPSort = {};

	-- get each of the DKP records
	for key, value in pairs(Lootster_DKP) do
		Lootster_DKPSort[#Lootster_DKPSort + 1] = key;
	end

	-- resort the data DKP.  We use a sorted indirection table
	table.sort(Lootster_DKPSort, Lootster_DataDKPTest);

	-- and update screen
	Lootster_Data_DKP_Update();
end

-- Data DKP Test handler
function Lootster_DataDKPTest(i1, i2)
	local	d1, d2;

	-- make sure we handle tiers seperately
	if (Lootster_DKPSortCol ~= "Tier") then
		-- are we sorting by DKP earnt or DKP spent?
		if ((Lootster_DKPSortCol == "DKPTotal") or (Lootster_DKPSortCol == "DKPEarnt") or (Lootster_DKPSortCol == "DKPSpent")) then
			-- handle earnt/spent
			if		(Lootster_DKPSortCol == "DKPTotal") then
				-- is this DKP or EPGP?
				if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					d1 = Lootster_CalcPR(Lootster_CalcEP(Lootster_SumDKPEarnt(Lootster_DKP[i1])), Lootster_CalcGP(Lootster_SumDKPSpent(Lootster_DKP[i1])));
					d2 = Lootster_CalcPR(Lootster_CalcEP(Lootster_SumDKPEarnt(Lootster_DKP[i2])), Lootster_CalcGP(Lootster_SumDKPSpent(Lootster_DKP[i2])));
				else
					d1 = Lootster_SumDKPTotal(Lootster_DKP[i1]);
					d2 = Lootster_SumDKPTotal(Lootster_DKP[i2]);
				end
			elseif	(Lootster_DKPSortCol == "DKPEarnt") then
				d1 = Lootster_SumDKPEarntUpdate(Lootster_DKP[i1]);
				d2 = Lootster_SumDKPEarntUpdate(Lootster_DKP[i2]);
			elseif	(Lootster_DKPSortCol == "DKPSpent") then
				d1 = Lootster_SumDKPSpentUpdate(Lootster_DKP[i1]);
				d2 = Lootster_SumDKPSpentUpdate(Lootster_DKP[i2]);
			end
		else
			-- retrieve indirected data
			d1 = Lootster_DKP[i1][Lootster_DKPSortCol];
			d2 = Lootster_DKP[i2][Lootster_DKPSortCol];
			
			-- are we sorting by player, member or toon?
			if		(Lootster_DKPSortCol == "Player") then
				-- indeed.  Get the alt if it is playing and sort on that
				d1 = Lootster_GetMainAlt(d1);
				d2 = Lootster_GetMainAlt(d2);
			elseif	(Lootster_DKPSortCol == "Member") then
				-- indeed.  Get the alt if it is playing and its membership, and sort on that
				d1 = Lootster_GetPlayerMembership(Lootster_GetMainAlt(Lootster_DKP[i1].Player));
				d2 = Lootster_GetPlayerMembership(Lootster_GetMainAlt(Lootster_DKP[i2].Player));
			elseif	(Lootster_DKPSortCol == "Toon") then
				-- indeed.  Get the alt if it is playing and its toonship, and sort on that
				d1 = Lootster_GetPlayerToonship(Lootster_GetMainAlt(Lootster_DKP[i1].Player));
				d2 = Lootster_GetPlayerToonship(Lootster_GetMainAlt(Lootster_DKP[i2].Player));
			end
		end

		-- handle nil data first
		if		((d1 == nil) and (d2 == nil)) then
			return false;
		elseif	(d1 == nil) then
			return not Lootster_DKPSortOrd;
		elseif	(d2 == nil) then
			return Lootster_DKPSortOrd;
		elseif	(d1 == d2) then
			return false;
		else	
			return (d1 < d2) == Lootster_DKPSortOrd;
		end
	else
		-- get the alts if they playing
		d1 = Lootster_GetMainAlt(Lootster_DKP[i1].Player);
		d2 = Lootster_GetMainAlt(Lootster_DKP[i2].Player);

		-- tiers sort - check priority first, depending on which way the sort goes
		if		(Lootster_DKPSortOrd and Lootster_PriorityTest(Lootster_GetPlayerMembership(d1), Lootster_GetPlayerToonship(d1), 
															   Lootster_GetPlayerMembership(d2), Lootster_GetPlayerToonship(d2)) == true) then
			-- priority made a difference
			return true;
		elseif	(Lootster_DKPSortOrd and Lootster_PriorityTest(Lootster_GetPlayerMembership(d2), Lootster_GetPlayerToonship(d2), 
															   Lootster_GetPlayerMembership(d1), Lootster_GetPlayerToonship(d1)) == true) then
			-- priority made a difference
			return false;
		elseif	(not Lootster_DKPSortOrd and Lootster_PriorityTest(Lootster_GetPlayerMembership(d1), Lootster_GetPlayerToonship(d1), 
																   Lootster_GetPlayerMembership(d2), Lootster_GetPlayerToonship(d2)) == true) then
			-- priority made a difference
			return true;
		elseif	(not Lootster_DKPSortOrd and Lootster_PriorityTest(Lootster_GetPlayerMembership(d2), Lootster_GetPlayerToonship(d2), 
																   Lootster_GetPlayerMembership(d1), Lootster_GetPlayerToonship(d1)) == true) then
			-- priority made a difference
			return false;
		else
			local	t1, t2;
			
			-- get tiers
			t1 = Lootster_CalcTier(Lootster_SumBaseDKP(Lootster_DKP[i1]) - Lootster_SumDKPSpentUpdate(Lootster_DKP[i1]));
			t2 = Lootster_CalcTier(Lootster_SumBaseDKP(Lootster_DKP[i2]) - Lootster_SumDKPSpentUpdate(Lootster_DKP[i2]));

			-- use tiers to decide
			if (t1 == t2) then
				-- tiers equal
				return false;
			else
				-- use tier
				return (t1 < t2) == Lootster_DKPSortOrd;
			end
		end
	end
end

-- Data Attend Sort handler
function Lootster_Data_Attend_Sort(col)
	local	attendId, attendRec;

	-- setup sort indirection
	Lootster_DataAttendSort = {};

	-- do we have a current player?
	if (Lootster_PlayerId ~= nil) then
		-- gather each of the player's attendances
		for attendId, attendRec in pairs(Lootster_Attend) do
			-- is this our player?
			if (attendRec.Player == Lootster_PlayerId) then
				Lootster_DataAttendSort[#Lootster_DataAttendSort + 1] = attendId;
			end
		end
	end

	-- resort the data attend.  We use a sorted indirection table
	table.sort(Lootster_DataAttendSort, Lootster_DataAttendTest);

	-- and update screen
	Lootster_Data_Attend_Update();
end

-- Data Adjust Sort handler
function Lootster_Data_Adjust_Sort(col)
	local	adjustId, adjustRec;

	-- setup sort indirection
	Lootster_DataAdjustSort = {};

	-- do we have a current player?
	if (Lootster_PlayerId ~= nil) then
		-- gather each of the player's adjustments
		for adjustId, adjustRec in pairs(Lootster_Adjust) do
			-- is this our player?
			if (adjustRec.Player == Lootster_PlayerId) then
				Lootster_DataAdjustSort[#Lootster_DataAdjustSort + 1] = adjustId;
			end
		end
	end

	-- resort the data adjust.  We use a sorted indirection table
	table.sort(Lootster_DataAdjustSort, Lootster_DataAdjustTest);

	-- and update screen
	Lootster_Data_Adjust_Update();
end

-- Data Attend Test handler
function Lootster_DataAttendTest(i1, i2)
	local	p1, p2;
	local	e1, e2;

	-- retrieve data attend attend
	p1 = Lootster_Attend[i1].Player;
	p2 = Lootster_Attend[i2].Player;

	-- if the players are different, just sort by name
	if (p1 ~= p2) then
		-- get the alt if it is playing and sort on that
		p1 = Lootster_GetMainAlt(p1);
		p2 = Lootster_GetMainAlt(p2);

		return p1 < p2;
	end

	-- retrieve attendance date
	e1 = Lootster_Attend[i1].DateAtt;
	e2 = Lootster_Attend[i2].DateAtt;

	-- we are not sorting the attendance, just which one was put in first
	return e1 < e2;
end

-- Data Adjust Test handler
function Lootster_DataAdjustTest(i1, i2)
	local	p1, p2;
	local	e1, e2;

	-- retrieve data adjust adjust
	p1 = Lootster_Adjust[i1].Player;
	p2 = Lootster_Adjust[i2].Player;

	-- if the players are different, just sort by name
	if (p1 ~= p2) then
		-- get the alt if it is playing and sort on that
		p1 = Lootster_GetMainAlt(p1);
		p2 = Lootster_GetMainAlt(p2);

		return p1 < p2;
	end

	-- retrieve adjustment date
	e1 = Lootster_Adjust[i1].DateAdj;
	e2 = Lootster_Adjust[i2].DateAdj;

	-- we are not sorting the adjustment, just which one was put in first
	return e1 < e2;
end

-- Loot Sort handler
function Lootster_Loot_Sort(col)
	local	lootId, lootRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_LootSortCol) then
			-- flip sort order
			Lootster_LootSortOrd = not Lootster_LootSortOrd;
		else
			-- force ascending
			Lootster_LootSortOrd = true;
		end

		Lootster_LootSortCol = col;
	end

	-- setup sort indirection
	Lootster_LootSort = {};

	-- get each of the item into the item sort indirection table
	for lootId, lootRec in pairs(Lootster_ItemDKP) do
		Lootster_LootSort[#Lootster_LootSort + 1] = lootId;
	end

	-- resort the item.  We use a sorted indirection table
	table.sort(Lootster_LootSort, Lootster_LootTest);

	-- and update screen
	Lootster_Loot_Update();
end

-- Loot Test handler
function Lootster_LootTest(i1, i2)
	local	d1, d2;

	-- are we sorting by id, clearability or deletablity?
	if		(Lootster_LootSortCol == "Id") then
		-- indeed.  Get the id of the loot
		d1 = i1;
		d2 = i2;
	elseif	(Lootster_LootSortCol == "Clear") then
		-- indeed.  Get the override DKP, making sure it is an override
		if (Lootster_ItemDKP[i1].DKP ~= nil) then
			d1 = Lootster_ItemDKP[i1].DKPMan;
		else
			d1 = nil;
		end

		if (Lootster_ItemDKP[i2].DKP ~= nil) then
			d2 = Lootster_ItemDKP[i2].DKPMan;
		else
			d2 = nil;
		end
	elseif	(Lootster_LootSortCol == "Delete") then
		-- indeed.  Get the override DKP, making sure it isn't an override
		if (Lootster_ItemDKP[i1].DKP == nil) then
			d1 = Lootster_ItemDKP[i1].DKPMan;
		else
			d1 = nil;
		end

		if (Lootster_ItemDKP[i2].DKP == nil) then
			d2 = Lootster_ItemDKP[i2].DKPMan;
		else
			d2 = nil;
		end
	else
		-- retrieve indirected data
		d1 = Lootster_ItemDKP[i1][Lootster_LootSortCol];
		d2 = Lootster_ItemDKP[i2][Lootster_LootSortCol];
	end

	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_LootSortOrd;
	elseif	(d2 == nil) then
		return Lootster_LootSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_LootSortOrd;
	end
end

-- Raid Sort handler
function Lootster_Raid_Raid_Sort(col)
	local	raidId, raidRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_RaidSortCol) then
			-- flip sort order
			Lootster_RaidSortOrd = not Lootster_RaidSortOrd;
		else
			-- force ascending
			Lootster_RaidSortOrd = true;
		end

		Lootster_RaidSortCol = col;
	end

	-- setup sort indirection
	Lootster_RaidSort = {};

	-- get each of the raids
	for raidId, raidRec in pairs(Lootster_Raid) do
		Lootster_RaidSort[#Lootster_RaidSort + 1] = raidId;
	end

	-- resort the raid raid.  We use a sorted indirection table
	table.sort(Lootster_RaidSort, Lootster_RaidRaidTest);

	-- and update screen
	Lootster_Raid_Raid_Update();
end

-- Raid Test handler
function Lootster_RaidRaidTest(i1, i2)
	local	d1, d2;
	
	-- retrieve indirected data
	if		(Lootster_RaidSortCol == "DKPEarnt") then
		d1 = Lootster_SumDKPEarntUpdate(Lootster_Raid[i1]);
		d2 = Lootster_SumDKPEarntUpdate(Lootster_Raid[i2]);
	elseif	(Lootster_RaidSortCol == "DKPSpent") then
		d1 = Lootster_SumDKPSpentUpdate(Lootster_Raid[i1]);
		d2 = Lootster_SumDKPSpentUpdate(Lootster_Raid[i2]);
	else
		d1 = Lootster_Raid[i1][Lootster_RaidSortCol];
		d2 = Lootster_Raid[i2][Lootster_RaidSortCol];
	end
	
	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_RaidSortOrd;
	elseif	(d2 == nil) then
		return Lootster_RaidSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_RaidSortOrd;
	end
end

-- Boss Sort handler
function Lootster_Raid_Boss_Sort(col)
	local	bossId, bossRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_BossSortCol) then
			-- flip sort order
			Lootster_BossSortOrd = not Lootster_BossSortOrd;
		else
			-- force ascending
			Lootster_BossSortOrd = true;
		end

		Lootster_BossSortCol = col;
	end

	-- setup sort indirection
	Lootster_BossSort = {};

	-- do we have a current raid?
	if (Lootster_RaidId ~= nil) then
		-- get each of the raid bosses into the boss sort indirection table
		for bossId, bossRec in pairs(Lootster_Raid[Lootster_RaidId].BossSet) do
			Lootster_BossSort[#Lootster_BossSort + 1] = bossId;
		end
	end

	-- resort the raid boss.  We use a sorted indirection table
	table.sort(Lootster_BossSort, Lootster_RaidBossTest);

	-- and update screen
	Lootster_Raid_Boss_Update();
end

-- Boss Test handler
function Lootster_RaidBossTest(i1, i2)
	local	d1, d2;
	
	-- retrieve indirected data
	if		(Lootster_BossSortCol == "DKPEarnt") then
		d1 = Lootster_SumDKPEarntUpdate(Lootster_Boss[i1]);
		d2 = Lootster_SumDKPEarntUpdate(Lootster_Boss[i2]);
	elseif	(Lootster_BossSortCol == "DKPSpent") then
		d1 = Lootster_SumDKPSpentUpdate(Lootster_Boss[i1]);
		d2 = Lootster_SumDKPSpentUpdate(Lootster_Boss[i2]);
	else
		d1 = Lootster_Boss[i1][Lootster_BossSortCol];
		d2 = Lootster_Boss[i2][Lootster_BossSortCol];
	end
	
	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_BossSortOrd;
	elseif	(d2 == nil) then
		return Lootster_BossSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_BossSortOrd;
	end
end

-- Attendance Sort handler
function Lootster_Raid_Attend_Sort(col)
	local	player, attendId;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_BossAttendSortCol) then
			-- flip sort order
			Lootster_BossAttendSortOrd = not Lootster_BossAttendSortOrd;
		else
			-- force ascending
			Lootster_BossAttendSortOrd = true;
		end

		Lootster_BossAttendSortCol = col;
	end

	-- setup sort indirection
	Lootster_BossAttendSort = {};

	-- do we have a current boss?
	if (Lootster_BossId ~= nil) then
		-- get each of the boss attendances into the attend sort indirection table
		for player, attendId in pairs(Lootster_Boss[Lootster_BossId].AttendSet) do
			Lootster_BossAttendSort[#Lootster_BossAttendSort + 1] = attendId;
		end
	end

	-- resort the raid attend.  We use a sorted indirection table
	table.sort(Lootster_BossAttendSort, Lootster_RaidAttendTest);

	-- and update screen
	Lootster_Raid_Attend_Update();
end

-- Attendance Test handler
function Lootster_RaidAttendTest(i1, i2)
	local	d1, d2;

	-- are we sorting by alt, toon or table?
	if		(Lootster_BossAttendSortCol == "Alt") then
		-- indeed.  Get the alt if it is playing and sort on that
		d1 = Lootster_GetMainAlt(Lootster_Attend[i1].Player);
		d2 = Lootster_GetMainAlt(Lootster_Attend[i2].Player);
	elseif (Lootster_BossAttendSortCol == "Toon") then
		-- determine if each is a main or alt
		if (Lootster_GetMainAlt(Lootster_Attend[i1].Player) == Lootster_Attend[i1].Player) then
			d1 = LOOTSTER_ENUM_TOON.MAIN;
		else
			d1 = LOOTSTER_ENUM_TOON.ALT;
		end
		
		if (Lootster_GetMainAlt(Lootster_Attend[i2].Player) == Lootster_Attend[i2].Player) then
			d2 = LOOTSTER_ENUM_TOON.MAIN;
		else
			d2 = LOOTSTER_ENUM_TOON.ALT;
		end
	else
		-- retrieve indirected data
		d1 = Lootster_Attend[i1][Lootster_BossAttendSortCol];
		d2 = Lootster_Attend[i2][Lootster_BossAttendSortCol];
	end
	
	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_BossAttendSortOrd;
	elseif	(d2 == nil) then
		return Lootster_BossAttendSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_BossAttendSortOrd;
	end
end

-- Adjust Sort handler
function Lootster_Raid_Adjust_Sort(col)
	local	adjustId, adjustRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_BossAdjustSortCol) then
			-- flip sort order
			Lootster_BossAdjustSortOrd = not Lootster_BossAdjustSortOrd;
		else
			-- force ascending
			Lootster_BossAdjustSortOrd = true;
		end

		Lootster_BossAdjustSortCol = col;
	end

	-- setup sort indirection
	Lootster_BossAdjustSort = {};

	-- do we have a current boss?
	if (Lootster_BossId ~= nil) then
		-- get each of the boss adjustments into the adjust sort indirection table
		for adjustId, adjustRec in pairs(Lootster_Boss[Lootster_BossId].AdjustSet) do
			Lootster_BossAdjustSort[#Lootster_BossAdjustSort + 1] = adjustId;
		end
	end

	-- resort the raid adjust.  We use a sorted indirection table
	table.sort(Lootster_BossAdjustSort, Lootster_RaidAdjustTest);

	-- and update screen
	Lootster_Raid_Adjust_Update();
end

-- Adjust Test handler
function Lootster_RaidAdjustTest(i1, i2)
	local	d1, d2;

	-- are we sorting by alt?
	if (Lootster_BossAdjustSortCol == "Alt") then
		-- indeed.  Get the alt if it is playing and sort on that
		d1 = Lootster_GetMainAlt(Lootster_Adjust[i1].Player);
		d2 = Lootster_GetMainAlt(Lootster_Adjust[i2].Player);
	else
		-- retrieve indirected data
		d1 = Lootster_Adjust[i1][Lootster_BossAdjustSortCol];
		d2 = Lootster_Adjust[i2][Lootster_BossAdjustSortCol];
	end

	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_BossAdjustSortOrd;
	elseif	(d2 == nil) then
		return Lootster_BossAdjustSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_BossAdjustSortOrd;
	end
end

-- Assign Sort handler
function Lootster_Raid_Assign_Sort(col)
	local	assignId, assignRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_BossAssignSortCol) then
			-- flip sort order
			Lootster_BossAssignSortOrd = not Lootster_BossAssignSortOrd;
		else
			-- force ascending
			Lootster_BossAssignSortOrd = true;
		end

		Lootster_BossAssignSortCol = col;
	end

	-- setup sort indirection
	Lootster_BossAssignSort = {};

	-- do we have a current boss?
	if (Lootster_BossId ~= nil) then
		-- get each of the boss assignments into the assign sort indirection table
		for assignId, assignRec in pairs(Lootster_Boss[Lootster_BossId].AssignSet) do
			Lootster_BossAssignSort[#Lootster_BossAssignSort + 1] = assignId;
		end
	end

	-- resort the raid assign.  We use a sorted indirection table
	table.sort(Lootster_BossAssignSort, Lootster_RaidAssignTest);

	-- and update screen
	Lootster_Raid_Assign_Update();
end

-- Assign Test handler
function Lootster_RaidAssignTest(i1, i2)
	local	d1, d2;

	-- are we sorting by alt?
	if (Lootster_BossAssignSortCol == "Alt") then
		-- indeed.  Get the alt if it is playing and sort on that
		d1 = Lootster_GetMainAlt(Lootster_Adjust[i1].Player);
		d2 = Lootster_GetMainAlt(Lootster_Adjust[i2].Player);
	else
		-- retrieve indirected data
		d1 = Lootster_Adjust[i1][Lootster_BossAssignSortCol];
		d2 = Lootster_Adjust[i2][Lootster_BossAssignSortCol];
	end

	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_BossAssignSortOrd;
	elseif	(d2 == nil) then
		return Lootster_BossAssignSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_BossAssignSortOrd;
	end
end

-- Item Sort handler
function Lootster_Item_Sort(col)
	local	itemId, itemRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_ItemSortCol) then
			-- flip sort order
			Lootster_ItemSortOrd = not Lootster_ItemSortOrd;
		else
			-- force ascending
			Lootster_ItemSortOrd = true;
		end

		Lootster_ItemSortCol = col;
	end

	-- setup sort indirection
	Lootster_ItemSort = {};

	-- get each of the item into the item sort indirection table
	for itemId, itemRec in pairs(Lootster_Restrict) do
		Lootster_ItemSort[#Lootster_ItemSort + 1] = itemId;
	end

	-- resort the item.  We use a sorted indirection table
	table.sort(Lootster_ItemSort, Lootster_ItemTest);

	-- and update screen
	Lootster_Item_Update();
end

-- Item Test handler
function Lootster_ItemTest(i1, i2)
	local	d1, d2;

	-- retrieve raid adjust
	d1 = Lootster_Restrict[i1][Lootster_ItemSortCol];
	d2 = Lootster_Restrict[i2][Lootster_ItemSortCol];

	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_ItemSortOrd;
	elseif	(d2 == nil) then
		return Lootster_ItemSortOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_ItemSortOrd;
	end
end

-- Rank Sort handler
function Lootster_Rank_Sort(col)
	local	rankId, rankRec;

	-- are we doing current sort order?
	if		(col ~= nil) then
		-- are we inverting sort order?
		if (col == Lootster_RankSortCol) then
			-- flip sort order
			Lootster_RankSortOrd = not Lootster_RankSortOrd;
		else
			-- force ascending
			Lootster_RankSortOrd = true;
		end

		Lootster_RankSortCol = col;
	end

	-- setup sort indirection
	Lootster_RankSort = {};

	-- no ranks if unguilded
	if (Lootster_SelfGuild ~= nil) then
		-- get each of the rank into the rank sort indirection table
		for rankId, rankRec in pairs(Lootster_Options.Ranks[Lootster_SelfGuild]) do
			Lootster_RankSort[#Lootster_RankSort + 1] = rankId;
		end
	end

	-- resort the rank.  We use a sorted indirection table
	table.sort(Lootster_RankSort, Lootster_RankTest);

	-- and update screen
	Lootster_Rank_Update();
end

-- Rank Test handler
function Lootster_RankTest(i1, i2)
	local	d1, d2;

	-- retrieve indirected data
	d1 = Lootster_Options.Ranks[Lootster_SelfGuild][i1][Lootster_RankSortCol];
	d2 = Lootster_Options.Ranks[Lootster_SelfGuild][i2][Lootster_RankSortCol];

	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_RankSortOrd;
	elseif	(d2 == nil) then
		return Lootster_RankSortOrd;
	elseif	(d1 == d2) then
		return false;
	elseif	((Lootster_RankSortCol == "Index") and ((d1 < LOOTSTER_RANK_GM) or (d2 < LOOTSTER_RANK_GM))) then
		-- the non-guild rank is special - invert the order
		return (d1 > d2) == Lootster_RankSortOrd;
	else
		return (d1 < d2) == Lootster_RankSortOrd;
	end
end

-- Raid Report Format Sort handler
function Lootster_RaidReport_Format_Sort()
	local	handle, repEntry;
	
	-- setup sort indirection
	Lootster_RepListSort = {};

	-- get each of the raids
	for handle, repEntry in pairs(Lootster_RepList) do
		Lootster_RepListSort[#Lootster_RepListSort + 1] = handle;
	end

	-- resort the raid formats.  We use a sorted indirection table
	table.sort(Lootster_RepListSort, Lootster_RaidReportFormatTest);
end

-- Raid Report Format Test handler
function Lootster_RaidReportFormatTest(i1, i2)
	local	t1, t2;

	-- retrieve indirected data
	t1 = Lootster_RepList[i1].Name;
	t2 = Lootster_RepList[i2].Name;
	
	-- handle nil data first
	if		((t1 == nil) and (t2 == nil)) then
		return false;
	elseif	(t1 == nil) then
		return false;
	elseif	(t2 == nil) then
		return true;
	elseif	(t1 == t2) then
		return false;
	else
		return (t1 < t2);
	end
end

-- Raid Report Raid Sort handler
function Lootster_RaidReport_Raid_Sort(col, ord)
	local	raidSort, raidId, raidRec;
	local	saveCol, saveOrd;
	
	-- backup sort col and ord
	saveCol = Lootster_Options.RepRaidSortCol;
	saveOrd = Lootster_Options.RepRaidSortColOrd;
	
	-- if the sort col and/or ord is supplied, override for this call
	if (col ~= nil) then
		Lootster_Options.RepRaidSortCol = col;
	end
	
	if (ord ~= nil) then
		Lootster_Options.RepRaidSortColOrd = ord;
	end		

	-- setup sort indirection
	raidSort = {};

	-- get each of the raids
	for raidId, raidRec in pairs(Lootster_Raid) do
		raidSort[#raidSort + 1] = raidId;
	end

	-- resort the raid raid.  We use a sorted indirection table
	table.sort(raidSort, Lootster_RaidReportRaidTest);
	
	-- restore sort col and ord
	Lootster_Options.RepRaidSortCol = saveCol;
	Lootster_Options.RepRaidSortColOrd = saveOrd;

	return raidSort;
end

-- Raid Report Raid Test handler
function Lootster_RaidReportRaidTest(i1, i2)
	local	d1, d2;

	-- are we sorting by DKP earnt or DKP spent?
	if ((Lootster_Options.RepRaidSortCol == "DKPEarnt") or (Lootster_Options.RepRaidSortCol == "DKPSpent")) then
		-- handle earnt/spent
		if		(Lootster_Options.RepRaidSortCol == "DKPEarnt") then
			d1 = Lootster_SumDKPEarntUpdate(Lootster_Raid[i1]);
			d2 = Lootster_SumDKPEarntUpdate(Lootster_Raid[i2]);
		elseif	(Lootster_Options.RepRaidSortCol == "DKPSpent") then
			d1 = Lootster_SumDKPSpentUpdate(Lootster_Raid[i1]);
			d2 = Lootster_SumDKPSpentUpdate(Lootster_Raid[i2]);
		end
	else
		-- retrieve indirected data
		d1 = Lootster_Raid[i1][Lootster_Options.RepRaidSortCol];
		d2 = Lootster_Raid[i2][Lootster_Options.RepRaidSortCol];
	end
	
	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_Options.RepRaidSortColOrd;
	elseif	(d2 == nil) then
		return Lootster_Options.RepRaidSortColOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_Options.RepRaidSortColOrd;
	end
end

-- Raid Report Boss Sort handler
function Lootster_RaidReport_Boss_Sort(raidId, col, ord)
	local	bossSort, bossId, bossRec;
	local	saveCol, saveOrd;
	
	-- backup sort col and ord
	saveCol = Lootster_Options.RepBossSortCol;
	saveOrd = Lootster_Options.RepBossSortColOrd;
	
	-- if the sort col and/or ord is supplied, override for this call
	if (col ~= nil) then
		Lootster_Options.RepBossSortCol = col;
	end
	
	if (ord ~= nil) then
		Lootster_Options.RepBossSortColOrd = ord;
	end		
	
	-- setup sort indirection
	bossSort = {};

	-- do we have a raid?
	if (raidId ~= nil) then
		-- get each of the raid bosses into the boss sort indirection table
		for bossId, bossRec in pairs(Lootster_Raid[raidId].BossSet) do
			bossSort[#bossSort + 1] = bossId;
		end
	end

	-- resort the raid boss.  We use a sorted indirection table
	table.sort(bossSort, Lootster_RaidReportBossTest);
	
	-- restore sort col and ord
	Lootster_Options.RepBossSortCol = saveCol;
	Lootster_Options.RepBossSortColOrd = saveOrd;

	return bossSort;
end

-- Raid Report Boss Test handler
function Lootster_RaidReportBossTest(i1, i2)
	local	d1, d2;

	-- are we sorting by DKP earnt or DKP spent?
	if ((Lootster_Options.RepBossSortCol == "DKPEarnt") or (Lootster_Options.RepBossSortCol == "DKPSpent")) then
		-- handle earnt/spent
		if		(Lootster_Options.RepBossSortCol == "DKPEarnt") then
			d1 = Lootster_SumDKPEarntUpdate(Lootster_Boss[i1]);
			d2 = Lootster_SumDKPEarntUpdate(Lootster_Boss[i2]);
		elseif	(Lootster_Options.RepBossSortCol == "DKPSpent") then
			d1 = Lootster_SumDKPSpentUpdate(Lootster_Boss[i1]);
			d2 = Lootster_SumDKPSpentUpdate(Lootster_Boss[i2]);
		end
	else
		-- retrieve indirected data
		d1 = Lootster_Boss[i1][Lootster_Options.RepBossSortCol];
		d2 = Lootster_Boss[i2][Lootster_Options.RepBossSortCol];
	end
	
	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_Options.RepBossSortColOrd;
	elseif	(d2 == nil) then
		return Lootster_Options.RepBossSortColOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_Options.RepBossSortColOrd;
	end
end

-- Raid Report Attendance Sort handler
function Lootster_RaidReport_Attend_Sort(bossId, col, ord)
	local	attendSort, player, attendId;
	local	saveCol, saveOrd;
	
	-- backup sort col and ord
	saveCol = Lootster_Options.RepAttendSortCol;
	saveOrd = Lootster_Options.RepAttendSortColOrd;
	
	-- if the sort col and/or ord is supplied, override for this call
	if (col ~= nil) then
		Lootster_Options.RepAttendSortCol = col;
	end
	
	if (ord ~= nil) then
		Lootster_Options.RepAttendSortColOrd = ord;
	end		

	-- setup sort indirection
	attendSort = {};

	-- do we have a boss?
	if (bossId ~= nil) then
		-- get each of the boss attendances into the attend sort indirection table
		for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
			attendSort[#attendSort + 1] = attendId;
		end
	end

	-- resort the raid attend.  We use a sorted indirection table
	table.sort(attendSort, Lootster_RaidReportAttendTest);
	
	-- restore sort col and ord
	Lootster_Options.RepAttendSortCol = saveCol;
	Lootster_Options.RepAttendSortColOrd = saveOrd;

	return attendSort;
end

-- Raid Report Consolidate Attendance Sort handler
function Lootster_RaidReport_ConsolidateAttend_Sort(bossSort, col, ord)
	local	attendSort, bix, bossId, player, attendId;
	local	saveCol, saveOrd;
	
	-- backup sort col and ord
	saveCol = Lootster_Options.RepAttendSortCol;
	saveOrd = Lootster_Options.RepAttendSortColOrd;
	
	-- if the sort col and/or ord is supplied, override for this call
	if (col ~= nil) then
		Lootster_Options.RepAttendSortCol = col;
	end
	
	if (ord ~= nil) then
		Lootster_Options.RepAttendSortColOrd = ord;
	end		

	-- setup sort indirection
	attendSort = {};

	-- do we have a boss set?
	if (bossSort ~= nil) then
		-- gather attendances for each boss
		for bix, bossId in ipairs(bossSort) do
			-- get each of the boss attendances into the attend sort indirection table
			for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
				attendSort[#attendSort + 1] = attendId;
			end
		end
	end

	-- resort the raid attend.  We use a sorted indirection table
	table.sort(attendSort, Lootster_RaidReportAttendTest);
	
	-- restore sort col and ord
	Lootster_Options.RepAttendSortCol = saveCol;
	Lootster_Options.RepAttendSortColOrd = saveOrd;

	return attendSort;
end

-- Raid Report Attendance Test handler
function Lootster_RaidReportAttendTest(i1, i2)
	local	d1, d2;

	-- are we sorting by DKP earntt?
	if (Lootster_Options.RepAttendSortCol == "DKPEarnt") then
		-- handle earnt
		d1 = Lootster_Attend[i1].DKPAttEarnt;
		d2 = Lootster_Attend[i2].DKPAttEarnt;
	else
		-- retrieve indirected data
		d1 = Lootster_Attend[i1][Lootster_Options.RepAttendSortCol];
		d2 = Lootster_Attend[i2][Lootster_Options.RepAttendSortCol];
	end
	
	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_Options.RepAttendSortColOrd;
	elseif	(d2 == nil) then
		return Lootster_Options.RepAttendSortColOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_Options.RepAttendSortColOrd;
	end
end

-- Raid Report Adjust Sort handler
function Lootster_RaidReport_Adjust_Sort(bossId, col, ord)
	local	adjustSort, adjustId, adjustRec;
	local	saveCol, saveOrd;
	
	-- backup sort col and ord
	saveCol = Lootster_Options.RepAdjustSortCol;
	saveOrd = Lootster_Options.RepAdjustSortColOrd;
	
	-- if the sort col and/or ord is supplied, override for this call
	if (col ~= nil) then
		Lootster_Options.RepAdjustSortCol = col;
	end
	
	if (ord ~= nil) then
		Lootster_Options.RepAdjustSortColOrd = ord;
	end
	
	-- setup sort indirection
	adjustSort = {};

	-- do we have a current boss?
	if (bossId ~= nil) then
		-- get each of the boss attendances into the attend sort indirection table
		for adjustId, adjustRec in pairs(Lootster_Boss[bossId].AdjustSet) do
			adjustSort[#adjustSort + 1] = adjustId;
		end
	end

	-- resort the raid adjust.  We use a sorted indirection table
	table.sort(adjustSort, Lootster_RaidReportAdjustTest);
	
	-- restore sort col and ord
	Lootster_Options.RepAdjustSortCol = saveCol;
	Lootster_Options.RepAdjustSortColOrd = saveOrd;

	return adjustSort;
end

-- Raid Report Consolidate Adjust Sort handler
function Lootster_RaidReport_ConsolidateAdjust_Sort(bossSort, col, ord)
	local	adjustSort, bix, bossId, adjustId, adjustRec;
	local	saveCol, saveOrd;
	
	-- backup sort col and ord
	saveCol = Lootster_Options.RepAdjustSortCol;
	saveOrd = Lootster_Options.RepAdjustSortColOrd;
	
	-- if the sort col and/or ord is supplied, override for this call
	if (col ~= nil) then
		Lootster_Options.RepAdjustSortCol = col;
	end
	
	if (ord ~= nil) then
		Lootster_Options.RepAdjustSortColOrd = ord;
	end	

	-- setup sort indirection
	adjustSort = {};

	-- do we have a boss set?
	if (bossSort ~= nil) then
		-- gather attendances for each boss
		for bix, bossId in ipairs(bossSort) do
			-- get each of the boss attendances into the attend sort indirection table
			for adjustId, adjustRec in pairs(Lootster_Boss[bossId].AdjustSet) do
				adjustSort[#adjustSort + 1] = adjustId;
			end
		end
	end

	-- resort the raid adjust.  We use a sorted indirection table
	table.sort(adjustSort, Lootster_RaidReportAdjustTest);

	-- restore sort col and ord
	Lootster_Options.RepAdjustSortCol = saveCol;
	Lootster_Options.RepAdjustSortColOrd = saveOrd;

	return adjustSort;
end

-- Raid Report Adjust Test handler
function Lootster_RaidReportAdjustTest(i1, i2)
	local	_, c1, c2, d1, d2;

	-- are we sorting by DKP earnt or DKP spent?
	if ((Lootster_Options.RepAdjustSortCol == "DKPEarnt") or (Lootster_Options.RepAdjustSortCol == "DKPSpent")) then
		-- handle earnt/spent
		if		(Lootster_Options.RepAdjustSortCol == "DKPEarnt") then
			d1 = Lootster_SumDKPEarntUpdate(Lootster_Adjust[i1]);
			d2 = Lootster_SumDKPEarntUpdate(Lootster_Adjust[i2]);
		elseif	(Lootster_Options.RepAdjustSortCol == "DKPSpent") then
			d1 = Lootster_SumDKPSpentUpdate(Lootster_Adjust[i1]);
			d2 = Lootster_SumDKPSpentUpdate(Lootster_Adjust[i2]);
		end
	elseif	(Lootster_Options.RepAdjustSortCol == "Alt") then
		-- by Alt.  Get the alt if it is playing and sort on that
		d1 = Lootster_GetMainAlt(Lootster_Adjust[i1].Player);
		d2 = Lootster_GetMainAlt(Lootster_Adjust[i2].Player);
	elseif	(Lootster_Options.RepAdjustSortCol == "Quality") then
		-- by Quality.  Get the quality via the link colour
		if (Lootster_Adjust[i1].Link ~= nil) then
			-- get the link colour and lookup quality
			_, _, c1 = string.find(Lootster_Adjust[i1].Link, LOOTSTER_ITEMQUAL_PATTERN);

			if (c1 ~= nil) then
				d1 = Lootster_LootQuality[c1];
			end
		end

		if (Lootster_Adjust[i2].Link ~= nil) then
			-- get the link colour and lookup quality
			_, _, c2 = string.find(Lootster_Adjust[i2].Link, LOOTSTER_ITEMQUAL_PATTERN);

			if (c2 ~= nil) then
				d2 = Lootster_LootQuality[c2];
			end
		end
	else
		-- retrieve indirected data
		d1 = Lootster_Adjust[i1][Lootster_Options.RepAdjustSortCol];
		d2 = Lootster_Adjust[i2][Lootster_Options.RepAdjustSortCol];
	end

	-- handle nil data first
	if		((d1 == nil) and (d2 == nil)) then
		return false;
	elseif	(d1 == nil) then
		return not Lootster_Options.RepAdjustSortColOrd;
	elseif	(d2 == nil) then
		return Lootster_Options.RepAdjustSortColOrd;
	elseif	(d1 == d2) then
		return false;
	else
		return (d1 < d2) == Lootster_Options.RepAdjustSortColOrd;
	end
end

-- Build Player Drop Down handler
function Lootster_Build_Player_DropDown(textSelect, funcSelect, textPlayer, funcPlayer, notSelf, notPark)
	local	_, pcount, pix, player, gix, group;
	local	groupInfo = {};
	local	playerInfo = {};
	
	-- see what menu level we are
	if		(UIDROPDOWNMENU_MENU_LEVEL == 1) then
		-- is this a raid?
		if (GetNumGroupMembers() > 0) then
			-- reset assignment details
			Lootster_AssignGroups = {};
			Lootster_AssignPlayers = {};

			-- get player count
			pcount = GetNumGroupMembers();

			-- form menu level for raid groups
			playerInfo = {};
			playerInfo.text = textSelect;
			playerInfo.isTitle = 1;
			playerInfo.notCheckable = 1;

			-- add title button
			UIDropDownMenu_AddButton(playerInfo);

			-- gather players and groups
			for pix=1, pcount do
				-- accumulate all the groups 
				player, _, group = GetRaidRosterInfo(pix);

				-- add group to group list
				Lootster_AssignGroups[group] = true;

				-- add player to group list, making sure we have a table for him
				if (Lootster_AssignPlayers[group] == nil) then
					Lootster_AssignPlayers[group] = {};
				end

				table.insert(Lootster_AssignPlayers[group], player);
			end

			-- form group buttons
			for gix=1, 8 do
				-- this group exists?
				if ((Lootster_AssignGroups[gix] ~= nil) and (Lootster_AssignGroups[gix] == true)) then
					-- form group button
					groupInfo = {};
					groupInfo.text = GROUP.." "..gix;
					groupInfo.hasArrow = 1;
					groupInfo.notCheckable = 1;
					groupInfo.value = gix;
					groupInfo.func = nil;

					-- add group button
					UIDropDownMenu_AddButton(groupInfo);
				end
			end

			-- add park players?
			if ((notPark == nil) or (notPark == false)) then
				-- form park player buttons
				for currIx, player in ipairs(Lootster_ParkSort) do
					-- form park player button
					playerInfo = {};
					playerInfo.text = player;
					playerInfo.value = player;
					playerInfo.func = funcSelect;
	
					-- add player button
					UIDropDownMenu_AddButton(playerInfo);
				end
			end

			-- form other player button
			playerInfo = {};
			playerInfo.text = textPlayer;
			playerInfo.value = "";
			playerInfo.func = funcPlayer;

			-- add player button
			UIDropDownMenu_AddButton(playerInfo);
		else
			-- setup the group with no menuing.  First, us as required
			if ((notSelf == nil) or (notSelf == false)) then
				playerInfo = {};
				playerInfo.text = Lootster_Self;
				playerInfo.value = Lootster_Self;
				playerInfo.func = funcSelect;

				-- add player button
				UIDropDownMenu_AddButton(playerInfo, UIDROPDOWNMENU_MENU_LEVEL);
			end

			for currIx=1, MAX_PARTY_MEMBERS, 1 do
				-- get party member
				player = UnitName("party"..currIx);

				-- no player (no information there yet) or unknown, move on
				if ((player ~= nil) and (player ~= UNKNOWNOBJECT)) then
					-- form player button
					playerInfo = {};
					playerInfo.text = player;
					playerInfo.value = player;
					playerInfo.func = funcSelect;

					-- add player button
					UIDropDownMenu_AddButton(playerInfo);
				end
			end

			-- add park players?
			if ((notPark == nil) or (notPark == false)) then
				-- form park player buttons
				for currIx, player in ipairs(Lootster_ParkSort) do
					-- form park player button
					playerInfo = {};
					playerInfo.text = player;
					playerInfo.value = player;
					playerInfo.func = funcSelect;
	
					-- add player button
					UIDropDownMenu_AddButton(playerInfo);
				end
			end

			-- form other player button
			playerInfo = {};
			playerInfo.text = textPlayer;
			playerInfo.value = "";
			playerInfo.func = funcPlayer;

			-- add player button
			UIDropDownMenu_AddButton(playerInfo);
		end
	elseif	(UIDROPDOWNMENU_MENU_LEVEL == 2) then
		-- form the buttons for the group's players
		for pix=1, #Lootster_AssignPlayers[UIDROPDOWNMENU_MENU_VALUE] do

			-- get the player name
			player = Lootster_AssignPlayers[UIDROPDOWNMENU_MENU_VALUE][pix];

			-- no player (no information there yet) or unknown, move on
			if ((player ~= nil) and (player ~= UNKNOWNOBJECT)) then
				-- add self?
				if ((notSelf == nil) or (notSelf == false) or (Lootster_Self ~= player)) then
					-- form player button
					playerInfo = {};
					playerInfo.text = player;
					playerInfo.value = player;
					playerInfo.func = funcSelect;
	
					-- add player button
					UIDropDownMenu_AddButton(playerInfo, UIDROPDOWNMENU_MENU_LEVEL);
				end
			end
		end
	end
end

-- Instantiate a DKP Entry handler
function Lootster_NewDKP(player, class, dkpEarnt, dkpSpent, dkpAttEarnt, dkpAdjEarnt, dkpAdjSpent, member)
	-- easy
	return { Player=player, Class=class, DKPEarnt=dkpEarnt, DKPSpent=dkpSpent, DKPAttEarnt=dkpAttEarnt, DKPAdjEarnt=dkpAdjEarnt, 
			 DKPAdjSpent=dkpAdjSpent, Member=member };
end

-- Instantiate a Guildie Entry handler
function Lootster_NewGuildie(rank)
	-- easy
	return { Rank=rank };
end

-- Instantiate a Roster Entry handler
function Lootster_NewRoster(name, class, classType)
	-- easy
	return { Name=name, Class=class, ClassType=classType };
end

-- Instantiate a Restrict Entry handler
function Lootster_NewRestrict(text, classes)
	-- easy
	return { Text=text, Classes=classes };
end

-- Instantiate a Rolls Entry handler
function Lootster_NewRolls(player, roll, classType, dkp, tier, member, toon)
	local	usage;
	
	-- are we in normal or DKP mode?
	if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USENORM) then
		-- check what kind of roll we are doing now
		if		(Lootster_NBG == LOOTSTER_NBG_NEED) then
			-- usage Need
			usage = LOOTSTER_ENUM_USAGE.MAINNEED;
		elseif	(Lootster_NBG == LOOTSTER_NBG_GREED) then
			-- usage Greed
			usage = LOOTSTER_ENUM_USAGE.GREED;
		elseif	(Lootster_NBG == LOOTSTER_NBG_1001000) then
			-- usage is Need by default
			usage = LOOTSTER_ENUM_USAGE.MAINNEED;
		else
			-- otherwise Greed
			usage = LOOTSTER_ENUM_USAGE.GREED;
		end
	elseif	(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then 
		-- usage is by default main-spec need
		usage = LOOTSTER_ENUM_USAGE.MAINNEED;
	else
		-- usage is by default greed
		usage = LOOTSTER_ENUM_USAGE.GREED;
	end
	
	return { Player=player, Roll=nil, ClassType=classType, DKP=dkp, Tier=tier, Usage=usage, Member=member, Toon=toon, Bad=nil, Dup=nil, Hold=false };
end

-- Instantiate a Win Entry handler
function Lootster_NewWin(player, usage, dkpAdjEarnt, dkpAdjSpent, adjustId)
	-- easy
	return { Player=player, Usage=usage, DKPAdjEarnt=dkpAdjEarnt, DKPAdjSpent=dkpAdjSpent, AdjustId=adjustId };
end

-- Instantiate a Levels Entry handler
function Lootster_NewLevel(name, tier, member, toon)
	-- easy
	return { Name=name, Tier=tier, Member=member, Toon=toon, Count=1 };
end

-- Instantiate a Roster Roll Entry handler
function Lootster_NewRosterRoll(dkp, tier, member, toon)
	-- easy
	return { DKP=dkp, Tier=tier, Member=member, Toon=toon, High=0, Equal=0 };
end

-- Instantiate a Loot Entry handler
function Lootster_NewLoot(name, dkp, mob, dkpMan)
	-- easy
	return { Name=name, DKP=dkp, Mob=mob, DKPMan=dkpMan };
end

-- Instantiate a Raid Entry handler
function Lootster_NewRaid(zone, raidType, wowId, dateOpn, dateExp)
	-- easy
	return { Id=nil, Zone=zone, Type=raidType, WoWId=wowId, DateOpn=dateOpn, DateExp=dateExp, Comment="", BossSet={}, BossN=0,
			 AttendSet={}, AttendN=0, AdjustSet={}, AdjustN=0, AssignSet={}, AssignN=0, UsageSet={}, DKPAttEarnt=0, DKPAdjEarnt=0, DKPAdjSpent=0 };
end

-- Instantiate a Boss Entry handler
function Lootster_NewBoss(boss, dateBeg, tbd, attempt, bossType, killSet)
	local	dateEnd;
	
	-- is the previously created boss beginning date different to passed date?
	if ((Lootster_BossDateBeg ~= nil) and (dateBeg == Lootster_BossDateBeg)) then
		-- bump this date but one so it sorts higher than the last boss created
		dateBeg = dateBeg + 1;
	end
		
	-- and remember this as the last created boss date
	Lootster_BossDateBeg = dateBeg;
	
	-- if we have a boss type, see if it it's end date is the same as the begin date
	if ((bossType ~= nil) and ((bossType <= LOOTSTER_ENUM_BOSSTYPE.RAIDFINISH) or (bossType >= LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD))) then
		-- set end date to begin date
		dateEnd = begDate;
	else
		dateEnd = nil;
	end
	
	-- if no boss TBD flag, must be known
	if (tbd == nil) then
		tbd = false;
	end
	
	-- if no attempt it must be the first
	if (attempt == nil) then
		attempt = 1;
	end
	
	-- if no boss type, this is an boss attempt
	if (bossType == nil) then
		bossType = LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT;
	end
	
	-- easy
	return { Id=nil, RaidId=nil, Boss=boss, DateBeg=dateBeg, DateEnd=dateEnd, TBD=tbd, Combat=false, Attempt=attempt, Type=bossType, KillSet=killSet,
			 AttendSet={}, AttendN=0, AdjustSet={}, AdjustN=0, AssignSet={}, AssignN=0, DKPAttEarnt=0, DKPAdjEarnt=0, DKPAdjSpent=0 };
end

-- Instantiate a Attend Entry handler
function Lootster_NewAttend(player, alt, attended, dkpEarnt)
	-- easy
	return { Id=nil, BossId=nil, Player=player, Alt=alt, DateAtt=Lootster_CalcServerTime(time()), Attended=attended, AdjustSet={}, AdjustN=0, DKPAttEarnt=dkpEarnt, DKPAdjEarnt=0, DKPAdjSpent=0 };
end

-- Instantiate a Adjust Entry handler
function Lootster_NewAdjust(player, alt, dateAdj, dkpEarnt, dkpSpent, usage, link, reason, comment, tba)
	-- easy
	return { Id=nil, BossId=nil, Player=player, Alt=alt, DateAdj=dateAdj, DKPAdjEarnt=dkpEarnt, DKPAdjSpent=dkpSpent,
			 Usage=usage, Link=link, Reason=reason, Comment=comment, TBA=tba };
end

-- Instantiate a Rank Entry handler
function Lootster_NewRank(name, index, member, toon)
	-- easy
	return { Name=name, Index=index, Member=member, Toon=toon };
end

-- Instantiate a Report handler
function Lootster_NewReport(handle, mask, name, tooltip, callback, args)
	-- easy
	return { Handle=handle, Mask=mask, Name=name, Tooltip=tooltip, Callback=callback, Args=args };
end

-- Create Identifier handler
function Lootster_CreateId(type)
	local   id;

	-- allocate id number and bump for uniqueness
	id = Lootster_Id;

	Lootster_Id = Lootster_Id + 1;

	-- format and return id
	return type..id;
end

-- Create Raid handler
function Lootster_CreateRaid(raidRec, raidId, silent)
	local	wowId, dateExp;
	
	-- are we creating the raid silently?
	if (silent ~= true) then
		-- see if we have a valid instance id and reset date
		if (raidRec.WoWId ~= nil) then
			-- snarf wow id
			wowId = raidRec.WoWId;
			
			if (dateExp ~= nil) then
				dateExp = Lootster_FormatServerTime(dateExp);
			else
				dateExp = LOOTSTER_RAIDRAID_NODATEEXP;
			end
		else
			-- reset
			wowId = LOOTSTER_RAIDRAID_NOWOWID;
			dateExp = LOOTSTER_RAIDRAID_NODATEEXP;
		end

		-- announcing raid changes?
		if (Lootster_Options.AckNoRaid == true) then
			-- let players know a raid was created
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_RAIDCREATED, raidRec.Zone, wowId, Lootster_FormatServerTime(raidRec.DateOpn),
												 LOOTSTER_RAIDRAID_NODATEEXP));
		end

		-- announce new raid as required
		Lootster_SendAnnouncement(string.format(LOOTSTER_MSG_RAIDCREATED, raidRec.Zone, wowId, Lootster_FormatServerTime(raidRec.DateOpn),
												LOOTSTER_RAIDRAID_NODATEEXP));
	end
		
	-- do we have a supplied raid id?
	if (raidId == nil) then
		-- create a raid id
		raidId = Lootster_CreateId(LOOTSTER_ENUM_IDTYPE.RAID);
	end

	-- insert into raid table
	Lootster_Raid[raidId] = Lootster_CopyRecord(raidRec);
	
	-- and update it's id
	Lootster_Raid[raidId].Id = raidId;

	return raidId;
end

-- Create Boss handler
function Lootster_CreateBoss(bossRec, bossId)
	-- do we have a supplied boss id?
	if (bossId == nil) then
		-- create a boss id
		bossId = Lootster_CreateId(LOOTSTER_ENUM_IDTYPE.BOSS);
	end
	
	-- insert into raid table
	Lootster_Boss[bossId] = Lootster_CopyRecord(bossRec);
	
	-- and update it's id
	Lootster_Boss[bossId].Id = bossId;

	return bossId;
end

-- Create Attendance handler
function Lootster_CreateAttend(attendRec, attendId)
	-- do we have a supplied attend id?
	if (attendId == nil) then
		-- create a attendance id
		attendId = Lootster_CreateId(LOOTSTER_ENUM_IDTYPE.ATTEND);
	end

	-- and insert into attendance table
	Lootster_Attend[attendId] = Lootster_CopyRecord(attendRec);
	
	-- and update it's id
	Lootster_Attend[attendId].Id = attendId;

	return attendId;
end

-- Create Adjustment handler
function Lootster_CreateAdjust(adjustRec, adjustId)
	-- do we have a supplied adjust id?
	if (adjustId == nil) then
		-- create a adjustment id
		adjustId = Lootster_CreateId(LOOTSTER_ENUM_IDTYPE.ADJUST);
	end
	
	-- insert into adjustment table
	Lootster_Adjust[adjustId] =  Lootster_CopyRecord(adjustRec);
	
	-- and update it's id
	Lootster_Adjust[adjustId].Id = adjustId;

	return adjustId;
end

-- Delete Raid handler
function Lootster_DeleteRaid(raidId, silent)
	local	bossId, boss, wowIdOrg, dateExpOrg;
	
	-- have we a raid?
	if (Lootster_Raid[raidId] == nil) then
	    -- no raid
	    return false;
	end
	
	-- is this a silent deletion and we announcing raid changes?
	if ((silent ~= true) and (Lootster_Options.AckNoRaid == true)) then
		-- see if we have a valid modified instance id and reset date
		if (Lootster_Raid[raidId].WoWId ~= nil) then
			-- snarf as set, if any
			wowIdMod = Lootster_Raid[raidId].WoWId;

			if (Lootster_Raid[raidId].DateExp ~= nil) then
				dateExpMod = Lootster_FormatServerTime(Lootster_Raid[raidId].DateExp);
			else
				dateExpMod = LOOTSTER_RAIDRAID_NODATEEXP;
			end
		else
			-- reset
			wowIdMod = LOOTSTER_RAIDRAID_NOWOWID;
			dateExpMod = LOOTSTER_RAIDRAID_NODATEEXP;
		end

		-- let them know
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_RAIDDELETED, Lootster_Raid[raidId].Zone, wowIdMod, 
											 Lootster_FormatServerTime(Lootster_Raid[raidId].DateOpn), dateExpMod));
	end
	
	-- delete all bosses
	Lootster_DeleteAllBoss(raidId, true);
	
	-- erase from raid table
	Lootster_Raid[raidId] = nil;
	
	return true;
end

-- Delete Boss handler
function Lootster_DeleteBoss(bossId, silent)
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end

	-- remove all attendances
	Lootster_DeleteAllAttend(bossId, true);
	
	-- delete all adjustments
	Lootster_DeleteAllAdjust(bossId, true);
	
	-- remove boss from raid
	Lootster_RemoveBoss(bossId, silent);

	-- erase from boss table
	Lootster_Boss[bossId] = nil;

	return true;
end

-- Delete Attendance handler
function Lootster_DeleteAttend(attendId, silent)
	local	player;
	
	-- have we a attendance?
	if (Lootster_Attend[attendId] == nil) then
	    -- no attendance
	    return false;
	end
	
	-- smack the attendance
	Lootster_RemoveAttend(attendId, silent);

	-- erase from attendance table
	Lootster_Attend[attendId] = nil;

	return true;
end

-- Delete Adjustment handler
function Lootster_DeleteAdjust(adjustId, silent)
	-- have we a adjustment?
	if (Lootster_Adjust[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end
	
	-- smack the adjustment
	Lootster_RemoveAdjust(adjustId);

	-- erase from adjustment table
	Lootster_Adjust[adjustId] = nil;

	return true;
end

-- Delete All Raids handler
function Lootster_DeleteAllRaid(silent)
	local	raidId, raidRec;

	-- delete each boss
	for raidId, raidRec in pairs(Lootster_Raid) do
		-- delete this raid
		Lootster_DeleteRaid(raidId, true);
	end

	-- reset id seed
	Lootster_Id = 1;

	-- clear all orphan raids
	Lootster_Raid = {};

	-- clear all orphan bosses
	Lootster_Boss = {};

	-- clear all orphan attendances
	Lootster_Attend = {};

	-- clear all orphan adjustments
	Lootster_Adjust = {};

	-- clear all orphan assignments
	Lootster_Assign = {};

	-- reset the current raid id
	Lootster_RaidId = nil;

	-- reset the current boss Id
	Lootster_BossId = nil;
	
	-- reset the current attend Id
	Lootster_AttendId = nil;
	
	-- reset the current adjust id
	Lootster_AdjustId = nil;
	
	-- reset the current assign id
	Lootster_AssignId = nil;
	
	-- reset running raid
	Lootster_Running.RaidId = nil;

	-- reset running boss
	Lootster_Running.BossId = nil;

	-- silent deletion and announcing raid changes?
	if ((silent ~= true) and (Lootster_Options.AckNoRaid == true)) then
		-- let them know
		Lootster_SendBroadcast(LOOTSTER_MSG_RAIDDELETEDALL);
	end

	return true;
end

-- Delete All Bosses handler
function Lootster_DeleteAllBoss(raidId, silent)
	local	bossSet, bossId, flag;

	-- have we a raid?
	if (Lootster_Raid[raidId] == nil) then
	    -- no boss
	    return false;
	end
	
	-- hammer through each boss
	for bossId, flag in pairs(Lootster_Raid[raidId].BossSet) do
		-- delete boss
		Lootster_DeleteBoss(bossId, true);
	end

	-- erase bosses from raid
	Lootster_Raid[raidId].BossSet = {};

    -- wack boss count
    Lootster_Raid[raidId].BossN = 0;

	-- silent deletion and announcing boss changes?
	if ((silent ~= true) and (Lootster_Options.AckNoBoss == true)) then
		-- let them know
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_BOSSDELETEDALL, Lootster_Raid[raidId].Zone));
	end

	return true;
end

-- Delete All Attendance handler
function Lootster_DeleteAllAttend(bossId, silent)
	local	attendSet, attendId;
	
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no attendance
	    return false;
	end
	
	-- copy the set of attend ids
	attendSet = Lootster_CopyRecord(Lootster_Boss[bossId].AttendSet);

	-- remove all attendances
	Lootster_RemoveAllAttend(bossId);

	-- hammer through each attendance
	for player, attendId in pairs(attendSet) do
		-- erase from attendance table
		Lootster_Attend[attendId] = nil;
	end
	
	-- silent deletion and announcing attendance changes?
	if ((silent ~= true) and (Lootster_Options.AckNoAtt == true)) then
		-- let them know
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_ATTENDDELETEDALL, Lootster_Raid[Lootster_Boss[bossId].RaidId].Zone,
											 Lootster_FormatBoss(Lootster_Boss[bossId].Boss, Lootster_Boss[bossId].Attempt)));
	end

	-- did our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	return true;
end

-- Delete All Adjustment handler
function Lootster_DeleteAllAdjust(bossId, silent)
	local	adjustSet, adjustId;
	
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no adjustment
	    return false;
	end
	
	-- copy the set of adjust ids
	adjustSet = Lootster_CopyRecord(Lootster_Boss[bossId].AdjustSet);

	-- remove all adjustments
	Lootster_RemoveAllAdjust(bossId);

	-- hammer through each adjustment
	for adjustId, player in pairs(adjustSet) do
		-- erase from adjustment table
		Lootster_Adjust[adjustId] = nil;
	end

	-- silent deletion and announcing adjustment changes?
	if ((silent ~= true) and (Lootster_Options.AckNoAdj == true)) then
		-- let them know
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_ADJUSTDELETEDALL, Lootster_Raid[Lootster_Boss[bossId].RaidId].Zone,
											 Lootster_FormatBoss(Lootster_Boss[bossId].Boss, 
																 Lootster_Boss[bossId].Attempt)));
	end

	-- did our DKP change?
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	return true;
end

-- Delete All Assignment handler
function Lootster_DeleteAllAssign(bossId)
	local	adjustId, player;
	
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no assignment
	    return false;
	end
	
	-- hammer through set of assigns deleting each from boss
	for adjustId, player in pairs(Lootster_Boss[bossId].AssignSet) do
		-- delete this adjustment
		Lootster_DeleteAdjust(adjustId);
	end

	return true;
end

-- Add Boss to Raid handler
function Lootster_InsertBoss(raidId, bossId, silent)
	local   player, attendId;
	
	-- have we a raid?
	if (Lootster_Raid[raidId] == nil) then
	    -- no raid
	    return false;
	end

	-- is this boss already in the raid?
	if (Lootster_Raid[raidId].BossSet[bossId] ~= nil) then
	    -- done
	    return true;
	end

	-- add boss to raid
	Lootster_Raid[raidId].BossSet[bossId] = true;

    -- bump boss count
    Lootster_Raid[raidId].BossN = Lootster_Raid[raidId].BossN + 1;

    -- add to raid to boss
    Lootster_Boss[bossId].RaidId = raidId;
	
	-- update the boss attendance DKP
	Lootster_UpdateBoss(bossId, Lootster_Boss[bossId].Type);

	-- roll up accounting of adjustment
	for adjustId, player in pairs(Lootster_Boss[bossId].AdjustSet) do
	    -- new guy
	    Lootster_Raid[raidId].AdjustSet[adjustId] = player;

	    -- bump adjust count
	    Lootster_Raid[raidId].AdjustN = Lootster_Raid[raidId].AdjustN + 1;
	
		-- add adjustment DKP
		Lootster_Raid[raidId].DKPAdjEarnt = Lootster_Raid[raidId].DKPAdjEarnt + Lootster_Adjust[adjustId].DKPAdjEarnt;
		Lootster_Raid[raidId].DKPAdjSpent = Lootster_Raid[raidId].DKPAdjSpent + Lootster_Adjust[adjustId].DKPAdjSpent;
	end
	
	-- silent insertion?
	if (silent ~= true) then
		-- announcing boss changes?
		if (Lootster_Options.AckNoBoss == true) then
			-- let players know a boss was created
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_BOSSCREATED, Lootster_FormatBoss(Lootster_Boss[bossId].Boss, Lootster_Boss[bossId].Attempt),
												 Lootster_FormatServerTime(Lootster_Boss[bossId].DateBeg), LOOTSTER_RAIDBOSS_NODATEEND));
		end

		-- announce new boss as required
		Lootster_SendAnnouncement(string.format(LOOTSTER_MSG_BOSSCREATED, Lootster_FormatBoss(Lootster_Boss[bossId].Boss, Lootster_Boss[bossId].Attempt),
												Lootster_FormatServerTime(Lootster_Boss[bossId].DateBeg), LOOTSTER_RAIDBOSS_NODATEEND));
	end
	
	return true;
end

-- Add Attendance to Boss handler
function Lootster_InsertAttend(bossId, attendId, silent)
	local   raidId, main, player;

	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end

    -- get the player for this entry
    main = Lootster_Attend[attendId].Player;

	-- is this attendance already in the boss?
	if (Lootster_Boss[bossId].AttendSet[main] ~= nil) then
	    -- done
	    return true;
	end

	-- add attendance to boss
	Lootster_Boss[bossId].AttendSet[main] = attendId;

    -- bump attend count
    Lootster_Boss[bossId].AttendN = Lootster_Boss[bossId].AttendN + 1;

    -- add to boss to attendance
    Lootster_Attend[attendId].BossId = bossId;
	
	-- update the attendance DKP
	Lootster_UpdateAttend(attendId, Lootster_Attend[attendId].Attended);

	-- roll up accounting of attendance into boss/raid
	Lootster_AddAttend(attendId);

	-- make sure we sum the adjustments for this new guy
	Lootster_SumAttendAdjusts(bossId, attendId);
	
	-- get the alt for this player
	player = Lootster_GetMainAlt(main);
	
	-- silent insertion and announcing attendance changes?
	if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAtt") == true))) then
		-- let player know there DKP was created if they are on roster
		if (Lootster_Roster[player] ~= nil) then
			-- determine if we are in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCREATEDEPGP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
															   Lootster_Attend[attendId].DKPAdjEarnt));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCREATEDDKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
															   Lootster_Attend[attendId].DKPAdjEarnt));
				end
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCREATEDNODKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended]));
			end

			-- echo points and roll to player
			Lootster_EchoPlayerPoints(player, player);
			Lootster_EchoPlayerRoll(player, true);
		end
	end

	-- did our DKP change?
	if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	return true;
end

-- Add Adjustment to Boss handler
function Lootster_InsertAdjust(bossId, adjustId, silent)
	local player, reason;
	
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end

	-- is this adjustment already in the boss?
	if (Lootster_Boss[bossId].AdjustSet[adjustId] ~= nil) then
	    -- done
	    return true;
	end
			
	-- add adjustment to boss
	Lootster_Boss[bossId].AdjustSet[adjustId] = Lootster_Adjust[adjustId].Player;

    -- bump adjust count
    Lootster_Boss[bossId].AdjustN = Lootster_Boss[bossId].AdjustN + 1;

    -- add to boss to adjustment
    Lootster_Adjust[adjustId].BossId = bossId;

	-- add this adjustment to boss/attendance/raid
	Lootster_AddAdjust(adjustId);
	
	-- if this adjustment is marked To Be Assigned, assign now
	if (Lootster_Adjust[adjustId].TBA ~= nil) then
		-- wire up assignment
		Lootster_InsertAssign(adjustId);
	end
	
	-- get the alt for this player
	player = Lootster_GetMainAlt(Lootster_Adjust[adjustId].Player);

	-- silent insertion and announcing adjustment changes?
	if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAdj") == true))) then
		-- let player know there DKP was created if they are on roster
		if (Lootster_Roster[player] ~= nil) then
			-- use link if given
			if (Lootster_Adjust[adjustId].Link ~= nil) then
				-- use link
				reason = Lootster_Adjust[adjustId].Link;
			else
				-- just use reason
				reason = Lootster_Adjust[adjustId].Reason;
			end

			-- determine if we are in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCREATEDEPGP, Lootster_Adjust[adjustId].DKPAdjEarnt, 
										 Lootster_Adjust[adjustId].DKPAdjSpent, reason));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCREATEDDKP, Lootster_SumDKPAdjust(Lootster_Adjust[adjustId]), reason));
				end
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCREATEDNODKP, reason));
			end

			-- echo points and roll to player
			Lootster_EchoPlayerPoints(player, player);
			Lootster_EchoPlayerRoll(player, true);
		end
	end

	-- did our DKP change?
	if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
		-- update our roll text
		Lootster_UpdateRoll();
	end
	
	return true;
end

-- Add Assignment handler
function Lootster_InsertAssign(adjustId)
	local	key, bossId, raidId;
	
	-- we have an adjustment?
	if (Lootster_Adjust[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end
	
	-- no key means no assign
	if (Lootster_Adjust[adjustId].AssignKey == nil) then
		-- no assign key
	    return false;
	end

	-- retrieve the boss
	bossId = Lootster_Adjust[adjustId].BossId;
	
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end
	
	-- is this adjustment not in the boss?
	if (Lootster_Boss[bossId].AdjustSet[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end

	-- retrieve the raid Id, if any
	raidId = Lootster_Boss[bossId].RaidId;
	
	-- add assignment to boss
	Lootster_Boss[bossId].AssignSet[adjustId] = Lootster_Adjust[adjustId].Player;

    -- bump assign count
    Lootster_Boss[bossId].AssignN = Lootster_Boss[bossId].AssignN + 1;
    
    -- accumulate to raid if we have one
    if (raidId ~= nil) then 
		-- add assignment to raid
		Lootster_Raid[raidId].AssignSet[adjustId] = Lootster_Adjust[adjustId].Player;

		-- bump assign count
		Lootster_Raid[raidId].AssignN = Lootster_Raid[raidId].AssignN + 1;
	end
	
    -- is this assignment Id already in assignments?
    if (Lootster_Assign[Lootster_Adjust[adjustId].AssignKey] == nil) then
		-- create empty assignment FIFO queue
		Lootster_Assign[Lootster_Adjust[adjustId].AssignKey] = {};
	end
	
	-- insert the adjustment
	table.insert(Lootster_Assign[Lootster_Adjust[adjustId].AssignKey], adjustId);		
	
	return true;
end

-- Modify Raid handler
function Lootster_ModifyRaid(raidRec, silent)
	local	raidId, wowIdOrg, dateExpOrg, wowIdMod, dateExpMod;
	
	-- retrieve raid id
	raidId = raidRec.Id;
	
	-- have we a raid?
	if ((raidId == nil) or (Lootster_Raid[raidId] == nil)) then
	    -- no raid
	    return false;
	end
	
	-- is this a silent modification and annoucing raid changes?
	if (silent ~= true) and (Lootster_Options.AckNoRaid == true) then
		-- see if we have a valid modified instance id and reset date
		if (raidRec.WoWId ~= nil) then
			-- snarf as set, if any
			wowIdMod = raidRec.WoWId;

			if (raidRec.DateExp ~= nil) then
				dateExpMod = Lootster_FormatServerTime(raidRec.DateExp);
			else
				dateExpMod = LOOTSTER_RAIDRAID_NODATEEXP;
			end
		else
			-- reset
			wowIdMod = LOOTSTER_RAIDRAID_NOWOWID;
			dateExpMod = LOOTSTER_RAIDRAID_NODATEEXP;
		end

		-- see if we have a valid original instance id and reset date
		if (Lootster_Raid[raidId].WoWId ~= nil) then
			wowIdOrg = Lootster_Raid[raidId].WoWId;
		else
			wowIdOrg = LOOTSTER_RAIDRAID_NOWOWID;
		end

		if (Lootster_Raid[raidId].DateExp ~= nil) then
			dateExpOrg = Lootster_FormatServerTime(Lootster_Raid[raidId].DateExp);
		else
			dateExpOrg = LOOTSTER_RAIDRAID_NODATEEXP;
		end

		-- let players know a raid was modified
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_RAIDCHANGED, raidRec.Zone, wowIdMod, 
							   Lootster_FormatServerTime(raidRec.DateOpn), dateExpMod, 
							   Lootster_Raid[raidId].Zone, wowIdOrg, 
							   Lootster_FormatServerTime(Lootster_Raid[raidId].DateOpn), dateExpOrg));
	end
	
	-- simply update the data from the passed record.  Note that the various data sets are
	-- left  untouched since there are other means to modify those
	Lootster_Raid[raidId].Zone		= raidRec.Zone;
	Lootster_Raid[raidId].WoWId		= raidRec.WoWId;
	Lootster_Raid[raidId].DateOpn	= raidRec.DateOpn;
	Lootster_Raid[raidId].DateExp	= raidRec.DateExp;
	Lootster_Raid[raidId].Comment	= raidRec.Comment;
	
	-- update the raid attendance DKP
	Lootster_UpdateRaid(raidId, raidRec.Type);
	
	return true;	
end

-- Modify Boss handler
function Lootster_ModifyBoss(bossRec, silent)
	local	bossId, dateEndOrg, dateEndMod;
	
	-- retrieve boss id
	bossId = bossRec.Id;
	
	-- have we a boss?
	if ((bossId == nil) or (Lootster_Boss[bossId] == nil)) then
	    -- no boss
	    return false;
	end

	-- silent modification and announcing boss changes?
	if (silent ~= true) then
		-- do we have a modified end date?
		if (bossRec.DateEnd ~= nil) then
			dateEndMod = Lootster_FormatServerTime(bossRec.DateEnd);
		else
			dateEndMod = LOOTSTER_RAIDBOSS_NODATEEND;
		end
		
		-- do we have a modified end date?
		if (Lootster_Boss[bossId].DateEnd ~= nil) then
			dateEndOrg = Lootster_FormatServerTime(Lootster_Boss[bossId].DateEnd);
		else
			dateEndOrg = LOOTSTER_RAIDBOSS_NODATEEND;
		end
	
		-- let players know a boss was modified
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_BOSSCHANGED, Lootster_FormatBoss(bossRec.Boss, bossRec.Attempt),
											 Lootster_FormatServerTime(bossRec.DateBeg), dateEndMod, 
											 Lootster_Boss[bossId].Boss, 
											 Lootster_FormatServerTime(Lootster_Boss[bossId].DateBeg), dateEndOrg));
	end
	
	-- simply update the data from the passed record.  Note that the various data sets are
	-- left untouched since there are other means to modify those
	Lootster_Boss[bossId].Boss		= bossRec.Boss;
	Lootster_Boss[bossId].Attempt	= bossRec.Attempt;
	Lootster_Boss[bossId].DateBeg	= bossRec.DateBeg;
	Lootster_Boss[bossId].TBD		= bossRec.TBD;

	-- using DKP and this is not a bonus award?
	if ((Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) and (bossRec.Type == LOOTSTER_ENUM_BOSSTYPE.BONUSAWARD)) then
		-- retrieve bonus award DKP
		Lootster_Boss[bossId].DKP		= bossRec.DKP;
		Lootster_Boss[bossId].Partial	= bossRec.Partial;
		Lootster_Boss[bossId].Standby	= bossRec.Standby;
	else
		-- reset bonus award DKP
		Lootster_Boss[bossId].DKP		= nil;
		Lootster_Boss[bossId].Partial	= nil;
		Lootster_Boss[bossId].Standby	= nil;
	end
	
	-- update the boss attendance DKP
	Lootster_UpdateBoss(bossId, bossRec.Type);
	
	return true;	
end

-- Modify Attend handler
function Lootster_ModifyAttend(attendRec, silent)
	local	attendId, bossId, raidId, main, player, pDelta;
	
	-- retrieve attend id
	attendId = attendRec.Id;
	
	-- have we a attendance?
	if ((attendId == nil) or (Lootster_Attend[attendId] == nil)) then
	    -- no attendance
	    return false;
	end

	-- retrieve the boss, if any
	bossId = Lootster_Attend[attendId].BossId;
	
	-- do we have a boss?
	if (bossId ~= nil) then
		-- get the raid Id
		raidId = Lootster_Boss[bossId].RaidId;
	else
		-- no raid
		raidId = nil;
	end

	-- get the player for this entry
	main = Lootster_Attend[attendId].Player;

	-- get the alt for this player
	player = Lootster_GetMainAlt(main);
	
	-- player change?
	pDelta = main ~= attendRec.Player;

	-- unwind accounting of attendance from boss/raid
	Lootster_SubAttend(attendId);

	-- unwind player from attendance if player changed
	if (pDelta == true) then
		-- silent modification and announcing attendance changes?
		if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAtt") == true))) then
			-- let player know there DKP was changed if they are on roster
			if (Lootster_Roster[player] ~= nil) then
				-- determine if we are in DKP mode
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDDELETEDEPGP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
																   Lootster_Attend[attendId].DKPAdjEarnt));
					else
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDDELETEDDKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
																   Lootster_Attend[attendId].DKPAdjEarnt));
					end
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDDELETEDNODKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended]));
				end
				
				-- echo points and roll to player
				Lootster_EchoPlayerPoints(player, player);
				Lootster_EchoPlayerRoll(player, true);
			end
		end
		
		-- remove attendance from boss
		Lootster_Boss[bossId].AttendSet[main] = nil;

		-- did our DKP change?
		if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
			-- update our roll text
			Lootster_UpdateRoll();
		end
	else
		-- silent modification and announcing attendance changes?
		if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAtt") == true))) then
			-- let player know there DKP was changed if they are on roster
			if (Lootster_Roster[player] ~= nil) then
				-- determine if we are in DKP mode
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCHANGEDEPGP, LOOTSTER_ATTENDED_LIST[attendRec.Attended], attendRec.DKPAdjEarnt,
																   LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended], Lootster_Attend[attendId].DKPAdjEarnt));
					else
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCHANGEDDKP, LOOTSTER_ATTENDED_LIST[attendRec.Attended], attendRec.DKPAdjEarnt,
																   LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended], Lootster_Attend[attendId].DKPAdjEarnt));
					end
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCHANGEDNODKP, LOOTSTER_ATTENDED_LIST[attendRec.Attended],
															   LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended]));
				end

				-- echo points and roll to player
				Lootster_EchoPlayerPoints(player, player);
				Lootster_EchoPlayerRoll(player, true);
			end
		end
	end

	-- update the data from the passed record
	Lootster_Attend[attendId].Player		= attendRec.Player;
	Lootster_Attend[attendId].Alt			= attendRec.Alt;
	
	-- update the attendance DKP
	Lootster_UpdateAttend(attendId, attendRec.Attended);

	-- roll up accounting of attendance into boss/raid
	Lootster_AddAttend(attendId);

	-- get the player for this entry
	main = Lootster_Attend[attendId].Player;

	-- get the alt for this player
	player = Lootster_GetMainAlt(main);
	
	-- add player from attendance if player changed
	if (pDelta == true) then
		-- silent modification and announcing attendance changes?
		if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAtt") == true))) then
			-- let player know there DKP was changed if they are on roster
			if (Lootster_Roster[player] ~= nil) then
				-- determine if we are in DKP mode
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCREATEDEPGP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
																   Lootster_Attend[attendId].DKPAdjEarnt));
					else
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCREATEDDKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
																   Lootster_Attend[attendId].DKPAdjEarnt));
					end
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDCREATEDNODKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended]));
				end
				
				-- echo points and roll to player
				Lootster_EchoPlayerPoints(player, player);
				Lootster_EchoPlayerRoll(player, true);
			end
		end

		-- add attendance to boss
		Lootster_Boss[bossId].AttendSet[main] = attendId;

		-- sum adjustments for this guy
		Lootster_SumAttendAdjusts(bossId, attendId);
	end

	-- did our DKP change?
	if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	return true;	
end

-- Modify Adjust handler
function Lootster_ModifyAdjust(adjustRec, silent)
	local	adjustId, bossId, raidId, main, player, pDelta, bDelta, reason, oldReason, newReason;
	
	-- retrieve adjustment id
	adjustId = adjustRec.Id;
	
	-- have we an adjustment?
	if ((adjustId == nil) or (Lootster_Adjust[adjustId] == nil)) then
	    -- no adjustment
	    return false;
	end
	
	-- retrieve the boss, if any
	bossId = Lootster_Adjust[adjustId].BossId;
	
	-- do we have a boss?
	if (bossId ~= nil) then
		-- get the raid Id
		raidId = Lootster_Boss[bossId].RaidId;
	else
		-- no raid
		raidId = nil;
	end
	
	-- boss change?
	bDelta = bossId ~= adjustRec.BossId

	-- unwind adjustment from boss if boss changed
	if (bDelta == true) then
		-- remove adjustment from boss
		Lootster_RemoveAdjust(adjustId, true);
	else
		-- if this adjustment is marked To Be Assigned, unassign now
		if (Lootster_Adjust[adjustId].TBA ~= nil) then
			-- unwire assignment
			Lootster_RemoveAssign(adjustId);
		end

		-- unwind accounting of adjustment from boss/attendance/raid
		Lootster_SubAdjust(adjustId);
	end

	-- get the player for this entry
	main = Lootster_Adjust[adjustId].Player;

	-- get the alt for this player
	player = Lootster_GetMainAlt(main);

	-- player change?
	pDelta = main ~= adjustRec.Player;

	-- unwind player from adjustment if player changed
	if (pDelta == true) then
		-- silent modification and announcing adjustment changes?
		if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAdj") == true))) then
			-- let player know their DKP was changed if they are on roster
			if (Lootster_Roster[player] ~= nil) then
				-- use link if given
				if (Lootster_Adjust[adjustId].Link ~= nil) then
					-- use link
					reason = Lootster_Adjust[adjustId].Link;
				else
					-- just use reason
					reason = Lootster_Adjust[adjustId].Reason;
				end

				-- determine if we are in DKP mode
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTDELETEDEPGP, Lootster_Adjust[adjustId].DKPAdjEarnt, 
											 Lootster_Adjust[adjustId].DKPAdjSpent, reason));
					else
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTDELETEDDKP, Lootster_SumDKPAdjust(Lootster_Adjust[adjustId]), reason));
					end
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTDELETEDNODKP, reason));
				end

				-- echo points and roll to player
				Lootster_EchoPlayerPoints(player, player);
				Lootster_EchoPlayerRoll(player, true);
			end
		end

		-- did our DKP change?
		if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
			-- update our roll text
			Lootster_UpdateRoll();
		end
	else
		-- silent modification and announcing adjustment changes?
		if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAdj") == true))) then
			-- let player know there DKP was changed if they are on roster
			if (Lootster_Roster[player] ~= nil) then
				-- use old link if given
				if (Lootster_Adjust[adjustId].Link ~= nil) then
					-- use old link
					oldReason = Lootster_Adjust[adjustId].Link;
				else
					-- just use old reason
					oldReason = Lootster_Adjust[adjustId].Reason;
				end

				-- use link if given
				if (adjustRec.Link ~= nil) then
					-- use new link
					newReason = adjustRec.Link;
				else
					-- just use new reason
					newReason = adjustRec.Reason;
				end

				-- determine if we are in DKP mode
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCHANGEDEPGP, adjustRec.DKPAdjEarnt, 
																   adjustRec.DKPAdjSpent, newReason, Lootster_Adjust[adjustId].DKPAdjEarnt,
																   Lootster_Adjust[adjustId].DKPAdjSpent, oldReason));
					else
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCHANGEDDKP, Lootster_SumDKPAdjust(adjustRec), newReason,
																   Lootster_SumDKPAdjust(Lootster_Adjust[adjustId]), oldReason));
					end
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCHANGEDNODKP, newReason, oldReason));
				end

				-- echo points and roll to player
				Lootster_EchoPlayerPoints(player, player);
				Lootster_EchoPlayerRoll(player, true);
			end
		end	
	end
			
	-- update the data from the passed record
	Lootster_Adjust[adjustId].Player		= adjustRec.Player;
	Lootster_Adjust[adjustId].Alt			= adjustRec.Alt;
	Lootster_Adjust[adjustId].DateAdj		= adjustRec.DateAdj;
	Lootster_Adjust[adjustId].DKPAdjEarnt	= adjustRec.DKPAdjEarnt;
	Lootster_Adjust[adjustId].DKPAdjSpent	= adjustRec.DKPAdjSpent;
	Lootster_Adjust[adjustId].Usage			= adjustRec.Usage;
	Lootster_Adjust[adjustId].Link			= adjustRec.Link;
	Lootster_Adjust[adjustId].Reason		= adjustRec.Reason;
	Lootster_Adjust[adjustId].Comment		= adjustRec.Comment;
	Lootster_Adjust[adjustId].TBA			= adjustRec.TBA;
	Lootster_Adjust[adjustId].AssignKey		= adjustRec.AssignKey;
	
	-- insert adjustment into boss if boss changed
	if (bDelta == true) then
		-- insert adjustment from boss
		Lootster_InsertAdjust(adjustRec.BossId, adjustId, true);
	else
		-- update adjustment player
		Lootster_Boss[bossId].AdjustSet[adjustId] = Lootster_Adjust[adjustId].Player;
		
		-- roll up accounting of adjustment into boss/attendance/raid
		Lootster_AddAdjust(adjustId);

		-- if this adjustment is marked To Be Assigned, assign now
		if (Lootster_Adjust[adjustId].TBA ~= nil) then
			-- wire up assignment
			Lootster_InsertAssign(adjustId);
		end
	end

	-- get the alt for this player
	player = Lootster_GetMainAlt(Lootster_Adjust[adjustId].Player);

	-- add player to adjustment if player changed
	if (pDelta == true) then
		-- silent insertion and announcing adjustment changes?
		if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAdj") == true))) then
			-- let player know there DKP was created if they are on roster
			if (Lootster_Roster[player] ~= nil) then
				-- use link if given
				if (adjustRec.Link ~= nil) then
					-- use link
					reason = Lootster_Adjust[adjustId].Link;
				else
					-- just use reason
					reason = Lootster_Adjust[adjustId].Reason;
				end

				-- determine if we are in DKP mode
				if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
					if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCREATEDEPGP, Lootster_Adjust[adjustId].DKPAdjEarnt, 
											 Lootster_Adjust[adjustId].DKPAdjSpent, reason));
					else
						Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCREATEDDKP, Lootster_SumDKPAdjust(Lootster_Adjust[adjustId]), reason));
					end
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTCREATEDNODKP, reason));
				end

				-- echo points and roll to player
				Lootster_EchoPlayerPoints(player, player);
				Lootster_EchoPlayerRoll(player, true);
			end
		end
	end

	-- did our DKP change?
	if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
		-- update our roll text
		Lootster_UpdateRoll();
	end
		
	return true;
end

-- Remove Boss from Raid handler
function Lootster_RemoveBoss(bossId, silent)
	local	raidId, dateEndOrg;
	
	-- is this boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- done
	    return true;
	end

	-- remove all attendance
	Lootster_RemoveAllAttend(bossId);

	-- remove all adjustments
	Lootster_RemoveAllAdjust(bossId);
	
	-- grab the raid id, if any
	raidId = Lootster_Boss[bossId].RaidId;
	
	-- do we have a raid for this boss?
	if (raidId ~= nil) then
		-- erase boss from raid
		Lootster_Raid[raidId].BossSet[bossId] = nil;
	
	    -- wack boss count
	    Lootster_Raid[raidId].BossN = Lootster_Raid[raidId].BossN - 1;

		-- erase raid from boss
		Lootster_Boss[bossId].RaidId = nil;
	end

	-- silent deletion and announcing boss changes?
	if ((silent ~= true) and (Lootster_Options.AckNoBoss == true)) then
		-- do we have an end date?
		if (Lootster_Boss[bossId].DateEnd ~= nil) then
			dateEndOrg = Lootster_FormatServerTime(Lootster_Boss[bossId].DateEnd);
		else
			dateEndOrg = LOOTSTER_RAIDBOSS_NODATEEND;
		end

		-- let them know
		Lootster_SendBroadcast(string.format(LOOTSTER_MSG_BOSSDELETED, Lootster_FormatBoss(Lootster_Boss[bossId].Boss, Lootster_Boss[bossId].Attempt),
											 Lootster_FormatServerTime(Lootster_Boss[bossId].DateBeg), dateEndOrg));
	end
		
	return true;
end

-- Remove Attendance from Boss handler
function Lootster_RemoveAttend(attendId, silent)
	local   bossId, player;

	-- have we a attendance?
	if (Lootster_Attend[attendId] == nil) then
	    -- no boss
	    return false;
	end
	
	-- get the boss id, if any
	bossId = Lootster_Attend[attendId].BossId;

	-- remove this attendance from boss/raid
	Lootster_SubAttend(attendId);

	-- delete attendance from boss
	Lootster_Boss[bossId].AttendSet[Lootster_Attend[attendId].Player] = nil;

    -- wack attend count
    Lootster_Boss[bossId].AttendN = Lootster_Boss[bossId].AttendN - 1;

	-- erase boss from attendance
	Lootster_Attend[attendId].BossId = nil;
	
	-- get the alt for this player
	player = Lootster_GetMainAlt(Lootster_Attend[attendId].Player);

	-- is this a silent deletion and announcing attendance changes?
	if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAtt") == true))) then
		-- let player know their DKP was changed if they are on roster
		if (Lootster_Roster[player] ~= nil) then
			-- determine if we are in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDDELETEDEPGP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
															   Lootster_Attend[attendId].DKPAdjEarnt));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDDELETEDDKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended],
															   Lootster_Attend[attendId].DKPAdjEarnt));
				end
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ATTENDDELETEDNODKP, LOOTSTER_ATTENDED_LIST[Lootster_Attend[attendId].Attended]));
			end
			
			-- echo points and roll to player
			Lootster_EchoPlayerPoints(player, player);
			Lootster_EchoPlayerRoll(player, true);
		end
	end

	return true;
end

-- Remove Adjustment from Boss handler
function Lootster_RemoveAdjust(adjustId, silent)
	local   bossId, player, reason;

	-- have we a adjust?
	if (Lootster_Adjust[adjustId] == nil) then
	    -- no adjust
	    return false;
	end
	
	-- get the boss id, if any
	bossId = Lootster_Adjust[adjustId].BossId;
	
	-- if this adjustment is marked To Be Assigned, unassign now
	if (Lootster_Adjust[adjustId].TBA ~= nil) then
		-- unwire up assignment
		Lootster_RemoveAssign(adjustId);
	end

	-- remove this adjustment from boss/attendance/raid
	Lootster_SubAdjust(adjustId);

	-- delete adjustment from boss
	Lootster_Boss[bossId].AdjustSet[adjustId] = nil;

    -- wack adjust count
    Lootster_Boss[bossId].AdjustN = Lootster_Boss[bossId].AdjustN - 1;

	-- erase boss from adjustment
	Lootster_Adjust[adjustId].BossId = nil;

	-- get the alt for this player
	player = Lootster_GetMainAlt(Lootster_Adjust[adjustId].Player);

	-- silent deletion and announcing adjustment changes?
	if ((silent ~= true) and ((silent == false) or (Lootster_TestPlayerTell(player, "AckNoAdj") == true))) then
		-- let player know their DKP was changed if they are on roster
		if (Lootster_Roster[player] ~= nil) then
			-- use link if given
			if (Lootster_Adjust[adjustId].Link ~= nil) then
				-- use link
				reason = Lootster_Adjust[adjustId].Link;
			else
				-- just use reason
				reason = Lootster_Adjust[adjustId].Reason;
			end

			-- determine if we are in DKP mode
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTDELETEDEPGP, Lootster_Adjust[adjustId].DKPAdjEarnt, 
										 Lootster_Adjust[adjustId].DKPAdjSpent, reason));
				else
					Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTDELETEDDKP, Lootster_SumDKPAdjust(Lootster_Adjust[adjustId]), reason));
				end
			else
				Lootster_SendPrivate(player, string.format(LOOTSTER_MSG_ADJUSTDELETEDNODKP, reason));
			end

			-- echo points and roll to player
			Lootster_EchoPlayerPoints(player, player);
			Lootster_EchoPlayerRoll(player, true);
		end
	end

	-- did our DKP change?
	if ((player == Lootster_Self) and (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP)) then
		-- update our roll text
		Lootster_UpdateRoll();
	end

	return true;
end

-- Remove Assignment from Boss handler
function Lootster_RemoveAssign(adjustId)
	local	bossId, raidId, key, ix, val;
	
	-- we have an adjustment?
	if (Lootster_Adjust[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end
	
	-- no key means no assign
	if (Lootster_Adjust[adjustId].AssignKey == nil) then
		-- no assign key
	    return false;
	end

	-- retrieve the boss
	bossId = Lootster_Adjust[adjustId].BossId;
	
	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end
	
	-- is this adjustment in the boss?
	if (Lootster_Boss[bossId].AdjustSet[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end

    -- make sure we have an assignment queue
    if (Lootster_Assign[Lootster_Adjust[adjustId].AssignKey] == nil) then
		-- no assignment
	    return false;
	end
	
	-- retrieve the raid Id, if any
	raidId = Lootster_Boss[bossId].RaidId;
	
	-- remove assignment from boss
	Lootster_Boss[bossId].AssignSet[adjustId] = nil;

    -- decrement assign count
    Lootster_Boss[bossId].AssignN = Lootster_Boss[bossId].AssignN - 1;
    
    -- remove from raid if we have one
    if (raidId ~= nil) then 
		-- remove assignment from raid
		Lootster_Raid[raidId].AssignSet[adjustId] = nil;

		-- decrement assign count
		Lootster_Raid[raidId].AssignN = Lootster_Raid[raidId].AssignN - 1;
	end

	-- attempt to locate the adjustment
	for ix, val in ipairs(Lootster_Assign[Lootster_Adjust[adjustId].AssignKey]) do
		-- found our adjustment?
		if (val == adjustId) then
			-- remove the adjustment
			table.remove(Lootster_Assign[Lootster_Adjust[adjustId].AssignKey], ix);
			
			-- if assignment id queue is now empty, kill it
			if (#Lootster_Assign[Lootster_Adjust[adjustId].AssignKey] == 0) then
				-- no more assignments
				Lootster_Assign[Lootster_Adjust[adjustId].AssignKey] = nil;
			end			
			break;	
		end
	end
	
	return ix ~= nil;
end

-- Remove All Bosses from Raid handler
function Lootster_RemoveAllBoss(raidId)
	local   bossId;

	-- have we a raid?
	if (Lootster_Raid[raidId] == nil) then
	    -- no raid
	    return false;
	end
	
	-- hammer through each boss
	for bossId, flag in pairs(Lootster_Raid[raidId].BossSet) do
		-- remove all attendance
		Lootster_RemoveAllAttend(bossId);
	
		-- remove all adjustments
		Lootster_RemoveAllAdjust(bossId);

		-- erase raid from boss
		Lootster_Boss[bossId].RaidId = nil;
	end

	-- erase bosses from raid
	Lootster_Raid[raidId].BossSet = {};

    -- wack boss count
    Lootster_Raid[raidId].BossN = 0;

	return true;
end

-- Remove All Attendances from Boss handler
function Lootster_RemoveAllAttend(bossId)
	local   raidId, player, attendId;

	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end

	-- get the raid id
	raidId = Lootster_Boss[bossId].RaidId;

	-- hammer through all the adjustments
	for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
		-- roll up accounting of attendance into raid?
		if (raidId ~= nil) then
		    -- is this player in raid?
		    if (Lootster_Raid[raidId].AttendSet[player] ~= nil) then
				-- unwind attendance DKP
				Lootster_Raid[raidId].DKPAttEarnt = Lootster_Raid[raidId].DKPAttEarnt - Lootster_Attend[attendId].DKPAttEarnt;

		        -- is his attendance for the raid going zero?
		        if (Lootster_Raid[raidId].AttendSet[player] == 1) then
		            -- no longer in raid
			        Lootster_Raid[raidId].AttendSet[player] = nil;
	
			        -- wack attend count
			        Lootster_Raid[raidId].AttendN = Lootster_Raid[raidId].AttendN - 1;
				else
				    -- wack times counted
				    Lootster_Raid[raidId].AttendSet[player] = Lootster_Raid[raidId].AttendSet[player] - 1;
				end
			end
		end

		-- we may not have a DKP entry for this guy if the main/alt relationship has changed since the
		-- attendance
		if (Lootster_DKP[player] ~= nil) then
			-- update player's attend DKP
			Lootster_DKP[player].DKPAttEarnt = Lootster_DKP[player].DKPAttEarnt - Lootster_Attend[attendId].DKPAttEarnt;
		end

		-- erase boss from attendance
		Lootster_Attend[attendId].BossId = nil;
	end

	-- delete attendances from boss
	Lootster_Boss[bossId].AttendSet = {};

    -- wack attend count
    Lootster_Boss[bossId].AttendN = 0;

	-- reset attednance DKP for boss
	Lootster_Boss[bossId].DKPAttEarnt = 0;

	return true;
end

-- Remove All Adjustments from Boss handler
function Lootster_RemoveAllAdjust(bossId)
	local   raidId, adjustId, player, attendId;

	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end
	
	-- get the raid Id
	raidId = Lootster_Boss[bossId].RaidId;

	-- remove all assignments
	Lootster_RemoveAllAssign(bossId);
	
	-- hammer through all the adjustments
	for adjustId, player in pairs(Lootster_Boss[bossId].AdjustSet) do
		-- roll up accounting of adjustment into raid?
		if (raidId ~= nil) then
			-- remove adjustment DKP
			Lootster_Raid[raidId].DKPAdjEarnt = Lootster_Raid[raidId].DKPAdjEarnt - Lootster_Adjust[adjustId].DKPAdjEarnt;
			Lootster_Raid[raidId].DKPAdjSpent = Lootster_Raid[raidId].DKPAdjSpent - Lootster_Adjust[adjustId].DKPAdjSpent;

		    -- no longer in raid
			Lootster_Raid[raidId].AdjustSet[adjustId] = nil;

			-- wack adjust count
			Lootster_Raid[raidId].AdjustN = Lootster_Raid[raidId].AdjustN - 1;
		end

		-- we may not have a DKP entry for this guy if the main/alt relationship has changed since the
		-- adjustment
		if (Lootster_DKP[player] ~= nil) then
			-- update player's adjusted DKP
			Lootster_DKP[player].DKPAdjEarnt = Lootster_DKP[player].DKPAdjEarnt - Lootster_Adjust[adjustId].DKPAdjEarnt;
			Lootster_DKP[player].DKPAdjSpent = Lootster_DKP[player].DKPAdjSpent - Lootster_Adjust[adjustId].DKPAdjSpent;
		end

		-- erase boss from adjustment
		Lootster_Adjust[adjustId].BossId = nil;
	end

	-- hammer through all the attendances
	for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
		-- reset DKP to zero
		Lootster_Attend[attendId].DKPAdjEarnt = 0;
		Lootster_Attend[attendId].DKPAdjSpent = 0;
	end
	
	-- delete adjustments from boss
	Lootster_Boss[bossId].AdjustSet = {};

    -- wack adjust count
    Lootster_Boss[bossId].AdjustN = 0;

	-- reset adjustment DKP for boss
	Lootster_Boss[bossId].DKPAdjEarnt = 0;
	Lootster_Boss[bossId].DKPAdjSpent = 0;

	return true;
end

-- Remove All Assignments from Boss handler
function Lootster_RemoveAllAssign(bossId)
	local   raidId, adjustId, player;

	-- have we a boss?
	if (Lootster_Boss[bossId] == nil) then
	    -- no boss
	    return false;
	end
	
	-- get the raid Id
	raidId = Lootster_Boss[bossId].RaidId;

	-- hammer through all the assignments
	for adjustId, player in pairs(Lootster_Boss[bossId].AssignSet) do
		-- remove assignment
		Lootster_RemoveAssign(adjustId);
		
		-- erase TBA from adjustment
		Lootster_Adjust[adjustId].TBA = nil;
	end

	return true;
end

-- Sum Adjustments for Attendance handler
function Lootster_SumAttendAdjusts(bossId, attendId)
	local	player, adjustId;

	-- make sure we have a boss and attendance
	if ((Lootster_Boss[bossId] == nil) or (Lootster_Attend[attendId] == nil)) then
		return false;
	end
	
	-- reset adjustment set
	Lootster_Attend[attendId].AdjustSet = {};

    -- wack adjust count
    Lootster_Attend[attendId].AdjustN = 0;
	
	-- reset DKP to zero
	Lootster_Attend[attendId].DKPAdjEarnt = 0;
	Lootster_Attend[attendId].DKPAdjSpent = 0;
	
	-- hammer through adjustments in this boss
	for adjustId, player in pairs(Lootster_Boss[bossId].AdjustSet) do
		-- is this our guy?
		if (Lootster_Attend[attendId].Player == player) then
			-- add DKP for this guy
			Lootster_Attend[attendId].DKPAdjEarnt = Lootster_Attend[attendId].DKPAdjEarnt + Lootster_Adjust[adjustId].DKPAdjEarnt;
			Lootster_Attend[attendId].DKPAdjSpent = Lootster_Attend[attendId].DKPAdjSpent + Lootster_Adjust[adjustId].DKPAdjSpent;

			-- add the adjustment to this guy
			Lootster_Attend[attendId].AdjustSet[adjustId] = adjustId;

			-- add adjust count
			Lootster_Attend[attendId].AdjustN = Lootster_Attend[attendId].AdjustN + 1;
		end
	end
	
	return true;
end

-- Add Attendance handler
function Lootster_AddAttend(attendId)
	local	bossId, raidId, player;

	-- have we a attendance?
	if (Lootster_Attend[attendId] == nil) then
	    -- no attendance
	    return false;
	end
	
	-- retrieve the boss, if any
	bossId = Lootster_Attend[attendId].BossId;
	
	-- do we have a boss?
	if (bossId ~= nil) then
		-- get the raid Id
		raidId = Lootster_Boss[bossId].RaidId;
	else
		-- no raid
		raidId = nil;
	end
	
	-- retrieve the player
	player = Lootster_Attend[attendId].Player;

	-- make sure this player has a DKP entry
	if (Lootster_DKP[player] == nil) then
		-- create DKP entry for player
		Lootster_DKP[player] = Lootster_NewDKP(player, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.APP);
	end

	-- update player's attended DKP
	Lootster_DKP[player].DKPAttEarnt = Lootster_DKP[player].DKPAttEarnt + Lootster_Attend[attendId].DKPAttEarnt;
	
	-- roll up accounting of attendance into boss
	if (bossId ~= nil) then
		-- add in DKP
	    Lootster_Boss[bossId].DKPAttEarnt = Lootster_Boss[bossId].DKPAttEarnt + Lootster_Attend[attendId].DKPAttEarnt;
	end

	-- roll up accounting of attendance into raid
	if (raidId ~= nil) then
	    -- is this player already in raid?
	    if (Lootster_Raid[raidId].AttendSet[player] == nil) then
	        -- new guy
	        Lootster_Raid[raidId].AttendSet[player] = 1;

	        -- bump attend count
	        Lootster_Raid[raidId].AttendN = Lootster_Raid[raidId].AttendN + 1;
		else
		    -- bump times counted
		    Lootster_Raid[raidId].AttendSet[player] = Lootster_Raid[raidId].AttendSet[player] + 1;
		end

		-- add in attendance DKP
		Lootster_Raid[raidId].DKPAttEarnt = Lootster_Raid[raidId].DKPAttEarnt + Lootster_Attend[attendId].DKPAttEarnt;
	end
	
	return true;
end

-- Subtract Attendance handler
function Lootster_SubAttend(attendId)
	local	bossId, raidId, player;

	-- have we a attendance?
	if (Lootster_Attend[attendId] == nil) then
	    -- no attendance
	    return false;
	end
	
	-- retrieve the boss, if any
	bossId = Lootster_Attend[attendId].BossId;
	
	-- do we have a boss?
	if (bossId ~= nil) then
		-- get the raid Id
		raidId = Lootster_Boss[bossId].RaidId;
	else
		-- no raid
		raidId = nil;
	end
	
	-- retrieve the player
	player = Lootster_Attend[attendId].Player;
	
	-- we may not have a DKP entry for this guy if the main/alt relationship has changed since the
	-- attendance
	if (Lootster_DKP[player] ~= nil) then
		-- update player's attended DKP
		Lootster_DKP[player].DKPAttEarnt = Lootster_DKP[player].DKPAttEarnt - Lootster_Attend[attendId].DKPAttEarnt;
	end
	
	-- unwind accounting of attendance from boss
	if (bossId ~= nil) then
	    -- remove DKP from boss
	    Lootster_Boss[bossId].DKPAttEarnt = Lootster_Boss[bossId].DKPAttEarnt - Lootster_Attend[attendId].DKPAttEarnt;
	end

	-- unwind accounting of attendance from raid
	if (raidId ~= nil) then
		-- remove attendance DKP
		Lootster_Raid[raidId].DKPAttEarnt = Lootster_Raid[raidId].DKPAttEarnt - Lootster_Attend[attendId].DKPAttEarnt;

	    -- is this player in raid?
	    if (Lootster_Raid[raidId].AttendSet[player] ~= nil) then
	        -- is his attendance for the raid going zero?
	        if (Lootster_Raid[raidId].AttendSet[player] == 1) then
	            -- no longer in raid
		        Lootster_Raid[raidId].AttendSet[player] = nil;

		        -- wack attend count
		        Lootster_Raid[raidId].AttendN = Lootster_Raid[raidId].AttendN - 1;
			else
			    -- wack times counted
			    Lootster_Raid[raidId].AttendSet[player] = Lootster_Raid[raidId].AttendSet[player] - 1;
			end
		end
	end
	
	return true;
end

-- Add Adjustment handler
function Lootster_AddAdjust(adjustId)
	local	bossId, raidId, player, attendId;

	-- have we a adjustment?
	if (Lootster_Adjust[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end
	
	-- retrieve the boss, if any
	bossId = Lootster_Adjust[adjustId].BossId;
	
	-- do we have a boss?
	if (bossId ~= nil) then
		-- get the raid Id
		raidId = Lootster_Boss[bossId].RaidId;
	else
		-- no raid
		raidId = nil;
	end
	
	-- retrieve the player
	player = Lootster_Adjust[adjustId].Player;

	-- make sure this player has a DKP entry
	if (Lootster_DKP[player] == nil) then
		-- create DKP entry for player
		Lootster_DKP[player] = Lootster_NewDKP(player, "-", 0, 0, 0, 0, 0, LOOTSTER_ENUM_MEMBER.APP);
	end

	-- update player's adjusted DKP
	Lootster_DKP[player].DKPAdjEarnt = Lootster_DKP[player].DKPAdjEarnt + Lootster_Adjust[adjustId].DKPAdjEarnt;
	Lootster_DKP[player].DKPAdjSpent = Lootster_DKP[player].DKPAdjSpent + Lootster_Adjust[adjustId].DKPAdjSpent;
	
	-- roll up accounting of adjustment into boss
	if (bossId ~= nil) then
		-- add in DKP
	    Lootster_Boss[bossId].DKPAdjEarnt = Lootster_Boss[bossId].DKPAdjEarnt + Lootster_Adjust[adjustId].DKPAdjEarnt;
	    Lootster_Boss[bossId].DKPAdjSpent = Lootster_Boss[bossId].DKPAdjSpent + Lootster_Adjust[adjustId].DKPAdjSpent;

		-- get the attendance id, if any
		attendId = Lootster_Boss[bossId].AttendSet[player];

	    -- add DKP and adjustment to player, if attending
	    if (attendId ~= nil) then
	    	Lootster_Attend[attendId].DKPAdjEarnt = Lootster_Attend[attendId].DKPAdjEarnt + Lootster_Adjust[adjustId].DKPAdjEarnt;
	    	Lootster_Attend[attendId].DKPAdjSpent = Lootster_Attend[attendId].DKPAdjSpent + Lootster_Adjust[adjustId].DKPAdjSpent;

			-- add the adjustment to this guy
			Lootster_Attend[attendId].AdjustSet[adjustId] = adjustId;

			-- add adjust count
			Lootster_Attend[attendId].AdjustN = Lootster_Attend[attendId].AdjustN + 1;
	    end
	end

	-- roll up accounting of adjustment into raid
	if (raidId ~= nil) then
	    -- new guy
	    Lootster_Raid[raidId].AdjustSet[adjustId] = player;

	    -- bump adjust count
	    Lootster_Raid[raidId].AdjustN = Lootster_Raid[raidId].AdjustN + 1;
	    
	    -- mange usage count - does this player have an entry yet?
		if (Lootster_Raid[raidId].UsageSet[player] == nil) then
			-- add this player's usage set
			Lootster_Raid[raidId].UsageSet[player] = {};
		end
		
		-- do we have an entry for this loot's usage?
		if (Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] == nil) then
			-- initially one of course
			Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] = 1;
		else
			-- bump
			Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] = Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] + 1;
		end
	    
		-- add in DKP
		Lootster_Raid[raidId].DKPAdjEarnt = Lootster_Raid[raidId].DKPAdjEarnt + Lootster_Adjust[adjustId].DKPAdjEarnt;
		Lootster_Raid[raidId].DKPAdjSpent = Lootster_Raid[raidId].DKPAdjSpent + Lootster_Adjust[adjustId].DKPAdjSpent;
	end
	
	return true;
end

-- Subtract Adjustment handler
function Lootster_SubAdjust(adjustId)
	local	bossId, raidId, player, attendId;

	-- have we a adjustment?
	if (Lootster_Adjust[adjustId] == nil) then
	    -- no adjustment
	    return false;
	end
	
	-- retrieve the boss, if any
	bossId = Lootster_Adjust[adjustId].BossId;
	
	-- do we have a boss?
	if (bossId ~= nil) then
		-- get the raid Id
		raidId = Lootster_Boss[bossId].RaidId;
	else
		-- no raid
		raidId = nil;
	end
	
	-- retrieve the player
	player = Lootster_Adjust[adjustId].Player;
	
	-- we may not have a DKP entry for this guy if the main/alt relationship has changed since the
	-- adjustment
	if (Lootster_DKP[player] ~= nil) then
		-- update player's adjusted DKP
		Lootster_DKP[player].DKPAdjEarnt = Lootster_DKP[player].DKPAdjEarnt - Lootster_Adjust[adjustId].DKPAdjEarnt;
		Lootster_DKP[player].DKPAdjSpent = Lootster_DKP[player].DKPAdjSpent - Lootster_Adjust[adjustId].DKPAdjSpent;
	end
	
	-- unwind accounting of adjustment from boss
	if (bossId ~= nil) then
	    -- remove DKP from boss
	    Lootster_Boss[bossId].DKPAdjEarnt = Lootster_Boss[bossId].DKPAdjEarnt - Lootster_Adjust[adjustId].DKPAdjEarnt;
	    Lootster_Boss[bossId].DKPAdjSpent = Lootster_Boss[bossId].DKPAdjSpent - Lootster_Adjust[adjustId].DKPAdjSpent;

		-- get the attendance id, if any
		attendId = Lootster_Boss[bossId].AttendSet[player];

	    -- remove DKP and adjustment from player, if attending
	    if (attendId ~= nil) then
	    	Lootster_Attend[attendId].DKPAdjEarnt = Lootster_Attend[attendId].DKPAdjEarnt - Lootster_Adjust[adjustId].DKPAdjEarnt;
	    	Lootster_Attend[attendId].DKPAdjSpent = Lootster_Attend[attendId].DKPAdjSpent - Lootster_Adjust[adjustId].DKPAdjSpent;

			-- remove the adjustment to this guy
			Lootster_Attend[attendId].AdjustSet[adjustId] = nil;

			-- wack adjust count
			Lootster_Attend[attendId].AdjustN = Lootster_Attend[attendId].AdjustN - 1;
	    end
	end

	-- unwind accounting of adjustment from raid
	if (raidId ~= nil) then
		-- remove DKP
		Lootster_Raid[raidId].DKPAdjEarnt = Lootster_Raid[raidId].DKPAdjEarnt - Lootster_Adjust[adjustId].DKPAdjEarnt;
		Lootster_Raid[raidId].DKPAdjSpent = Lootster_Raid[raidId].DKPAdjSpent - Lootster_Adjust[adjustId].DKPAdjSpent;
	    
	    -- mange usage count - does this player have an entry?
		if (Lootster_Raid[raidId].UsageSet[player] ~= nil) then
			-- do we have an entry for this loot's usage?
			if (Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] ~= nil) then
				-- debump
				Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] = Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] - 1;
			
				-- if zero remove this usage entry
				if (Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] == 0) then
					Lootster_Raid[raidId].UsageSet[player][Lootster_Adjust[adjustId].Usage] = nil;
				end
			end
			
			-- if no usages for player, remove player entry
			if (#Lootster_Raid[raidId].UsageSet[player] == 0) then
				Lootster_Raid[raidId].UsageSet[player] = nil;
			end
		end

	    -- no longer in raid
		Lootster_Raid[raidId].AdjustSet[adjustId] = nil;

		-- wack adjust count
		Lootster_Raid[raidId].AdjustN = Lootster_Raid[raidId].AdjustN - 1;
	end
	
	return true;
end

-- Create Assign Key handler
function Lootster_CreateAssignKey(player, link)
	-- have we a player or link?
	if ((player == nil) or (link == nil)) then
		-- no player or link
	    return nil;
	end

	-- smoosh together for a key
	return player..link;
end

-- Find Assign handler
function Lootster_FindAssign(player, link, tba)
	local	key, ix, adjustId;
	
	-- create the assign key
	key = Lootster_CreateAssignKey(player, link);
	
    -- see if this assign key exists
    if ((key ~= nil) and (Lootster_Assign[key] ~= nil)) then
 		-- attempt to locate an adjustment with a matching tba
		for ix, adjustId in ipairs(Lootster_Assign[key]) do
			-- is this the same TBA as we are looking for?
			if (Lootster_Adjust[adjustId].TBA == tba) then
				-- this is a matching TBA
				return adjustId
			end
		end
		
		-- no corresponding TBA adjustment
		return nil;
	else
		-- no adjustment
		return nil;
	end
end

-- Retrieve Next Id handler
function Lootster_GetNextId(sortList, currId)
	local	count, ix, found, nextId;

	-- no next id found so far
	found = nil;

	-- no sort list we are done
	if (sortList == nil) then
		return nil;
	end

	-- get count of ids
	count = #sortList;

	-- don't bother if only one entry
	if (count < 2) then
		return nil;
	end

	-- search for the current id
	for ix=1, count do
		-- is this the one we are looking for?
		if (sortList[ix] == currId) then
			-- found!
			found = ix;
			break;
		end
	end

	-- how did we do?
	if (found == nil) then
		return nil;
	end

	-- retrieve the next id after this guy, if any
	if (found == count) then
		-- get previous entry
		nextId = sortList[found - 1];
	else
		-- get next entry
		nextId = sortList[found + 1];
	end

	return nextId;
end

-- Set Column Width handler
function Lootster_SetColWidth(self, width)
	-- force it's width
 	self:SetWidth(width);

	-- and the text area
 	_G[self:GetName().."Middle"]:SetWidth(width - 9);
end

-- Set Scroll Frame Position handler
function Lootster_SetScrollPosition(frame, pos, lines)
	-- set the display scroll to a center location
	pos = math.max((pos - math.floor(lines / 2)), 0);
	
	-- set the scroll frame positon
	FauxScrollFrame_SetOffset(frame, pos)
	
	-- set the scroll bar value
	_G[frame:GetName().."ScrollBar"]:SetValue(pos * LOOTSTER_FRAME_HEIGHT);
end

-- Load Edit Box handler
function Lootster_LoadEditBox(self)
	-- attempt to get the edit box's label and read only strings
	self.Label = _G[self:GetName().."Label"];
	self.ReadOnly = _G[self:GetName().."ReadOnly"];
	
	-- if we have a label, reparent it to the edit box's parent so it displays when the edit box doesn't
	if (self.Label ~= nil) then
		-- set parent to parent of edit box
		self.Label:SetParent(self:GetParent());
	end
	
	-- if we have a read only, reparent it to the edit box's parent so it displays when the edit box doesn't
	if (self.ReadOnly ~= nil) then
		-- set parent to parent of edit box
		self.ReadOnly:SetParent(self:GetParent());
	end
end

-- Show Edit Box handler
function Lootster_ShowEditBox(self)
	-- hide the read only string
	if (self.ReadOnly ~= nil) then
		self.ReadOnly:Hide();
	end
end

-- Hide Edit Box handler
function Lootster_HideEditBox(self)
	-- set the read only text and show the read only string
	if (self.ReadOnly ~= nil) then
		self.ReadOnly:SetText(self:GetText());
		self.ReadOnly:Show();
	end
end

-- Set Text Box handler
function Lootster_SetTextEditBox(self)
	-- set the read only text
	if (self.ReadOnly ~= nil) then
		self.ReadOnly:SetText(self:GetText());
	end
end

-- Set Hyperlink handler
function Lootster_SetHyperlink(link, slot)
	local	dkp, reason, items, dkpType, dkpOff, dkpMan;

	-- process the item for class restrictions
	Lootster_ProcessRestrictions(link, slot);

	-- update the item prompt according to item count
	Lootster_UpdateItemPrompt();

	-- update the item text and comment for the roll, loot and item frame
	if (Lootster_ItemLink ~= nil) then
		Lootster_RollFrameItemText:SetText(Lootster_ItemLink);
		Lootster_LootFrameItemText:SetText(Lootster_ItemLink);
		Lootster_ItemFrameItemText:SetText(Lootster_ItemLink);
		Lootster_OptionsFrameItemPointsFrameItemText:SetText(Lootster_ItemLink);
	else
		Lootster_RollFrameItemText:SetText("");
		Lootster_LootFrameItemText:SetText("");
		Lootster_ItemFrameItemText:SetText("");
		Lootster_OptionsFrameItemPointsFramePoints:SetText("");
		Lootster_OptionsFrameItemPointsFrameItemText:SetText("");
	end

	-- determine if we are in DKP mode
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- retrieve default DKP and reason text.  Note we update display of item points
		dkp, reason, items, dkpType, dkpOff, dkpMan = Lootster_GetItemDKP(Lootster_ItemText, Lootster_ItemLink, true);
	else
		-- use default values
		dkp, reason, items, dkpType, dkpOff, dkpMan = Lootster_GetItemDKP(nil);
	end

	-- set the item's DKP loot type
	Lootster_ItemDKPLootType = dkpType;

	-- are we showing roll loot DKP information
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- did we have a link and did we find any items?
		if		(Lootster_ItemLink == nil) then
			-- clear official DKP
			Lootster_RollFrameDKPOffText:SetText(LOOTSTER_ROLL_DKPNON);
			Lootster_RollFrameDKPOffText:SetJustifyH("LEFT");
			Lootster_RollFrameDKPOffText:SetTextColor(LOOTSTER_ROLL_DKPNON_CLR.r, LOOTSTER_ROLL_DKPNON_CLR.g, LOOTSTER_ROLL_DKPNON_CLR.b);

			-- hide manual entry edit
			Lootster_RollFrameDKPMan:Hide();

			-- hide DKP clear button
			Lootster_RollFrameClearDKP:Hide();

			-- hide DKP update button
			Lootster_RollFrameDKPUpdate:Hide();
		elseif	(items == 0) then
			-- this is a new loot entry - reflect as such
			Lootster_RollFrameDKPOffText:SetText(LOOTSTER_ROLL_DKPNEW);
			Lootster_RollFrameDKPOffText:SetJustifyH("LEFT");
			Lootster_RollFrameDKPOffText:SetTextColor(LOOTSTER_ROLL_DKPNEW_CLR.r, LOOTSTER_ROLL_DKPNEW_CLR.g, LOOTSTER_ROLL_DKPNEW_CLR.b);

			-- set manual DKP label
			Lootster_RollFrameDKPManLabel:SetText(LOOTSTER_ROLL_DKPMAN);

			-- clear manual DKP
			Lootster_RollFrameDKPMan:SetText("");

			-- show manual entry edit
			Lootster_RollFrameDKPMan:Show();

			-- show DKP clear button
			Lootster_RollFrameClearDKP:Show();

			-- show DKP update button
			Lootster_RollFrameDKPUpdate:Show();
		elseif	(items == 1) then
			-- what type of DKP is this?
			if		((dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.OFFICIAL) or (dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE)) then
				-- this is an official loot entry - reflect as such
				Lootster_RollFrameDKPOffText:SetFormattedText(LOOTSTER_COST_POINTS, dkpOff);
				Lootster_RollFrameDKPOffText:SetJustifyH("RIGHT");
				Lootster_RollFrameDKPOffText:SetTextColor(LOOTSTER_ROLL_DKPOFFICIAL_CLR.r, LOOTSTER_ROLL_DKPOFFICIAL_CLR.g, 
														  LOOTSTER_ROLL_DKPOFFICIAL_CLR.b);

				-- set manual DKP label
				Lootster_RollFrameDKPManLabel:SetText(LOOTSTER_ROLL_DKPOVR);

				-- clear or set override DKP as required
				if (dkpType ~= LOOTSTER_ENUM_DKPLOOTTYPE.OVERRIDE) then
					-- clear manual DKP
					Lootster_RollFrameDKPMan:SetText("");
				else
					-- set manual DKP
					Lootster_RollFrameDKPMan:SetText(string.format(LOOTSTER_COST_POINTS, dkpMan));
				end
			elseif	(dkpType == LOOTSTER_ENUM_DKPLOOTTYPE.PROVISORY) then
				-- this is a provisory loot entry - reflect as such
				Lootster_RollFrameDKPOffText:SetText(LOOTSTER_ROLL_DKPPROTEM);
				Lootster_RollFrameDKPOffText:SetJustifyH("LEFT");
				Lootster_RollFrameDKPOffText:SetTextColor(LOOTSTER_ROLL_DKPPROTEM_CLR.r, LOOTSTER_ROLL_DKPPROTEM_CLR.g, 
														  LOOTSTER_ROLL_DKPPROTEM_CLR.b);

				-- set manual DKP label
				Lootster_RollFrameDKPManLabel:SetText(LOOTSTER_ROLL_DKPMAN);

				-- set manual DKP
				Lootster_RollFrameDKPMan:SetText(string.format(LOOTSTER_COST_POINTS, dkpMan));
			end

			-- show manual entry edit
			Lootster_RollFrameDKPMan:Show();

			-- show DKP clear button
			Lootster_RollFrameClearDKP:Show();

			-- show DKP update button
			Lootster_RollFrameDKPUpdate:Show();
		else
			-- multiple entries - set up as such
			Lootster_RollFrameDKPOffText:SetText(LOOTSTER_ROLL_DKPMULTIPLE);
			Lootster_RollFrameDKPOffText:SetJustifyH("LEFT");
			Lootster_RollFrameDKPOffText:SetTextColor(LOOTSTER_ROLL_DKPMULTIPLE_CLR.r, LOOTSTER_ROLL_DKPMULTIPLE_CLR.g,
													  LOOTSTER_ROLL_DKPMULTIPLE_CLR.b);

			-- set manual DKP label
			Lootster_RollFrameDKPManLabel:SetText("");

			-- hide manual entry edit
			Lootster_RollFrameDKPMan:Hide();

			-- hide DKP clear button
			Lootster_RollFrameClearDKP:Hide();

			-- hide DKP update button
			Lootster_RollFrameDKPUpdate:Hide();
		end

		-- force management of DKP update action and state
		Lootster_Roll_DKPMan_OnTextChanged(self); 

		-- show roll DKP frame
		Lootster_RollFrameDKPFrame:Show();
	else
		-- hide roll DKP frame
		Lootster_RollFrameDKPFrame:Hide();
	end

	-- update the item text for the adjust DKP frame if visible
	if (Lootster_RaidFrameAdjustFrame:IsVisible()) then
		-- update the adjust record earnt/spent DKP depending on DKP value selector
		if (Lootster_RaidFrameAdjustFrameDKPValueEarnt:GetChecked() ~= nil) then
			Lootster_AdjustRec.DKPAdjEarnt = dkp;
			Lootster_AdjustRec.DKPAdjSpent = 0;
		else
			Lootster_AdjustRec.DKPAdjEarnt = 0;
			Lootster_AdjustRec.DKPAdjSpent = dkp;
		end
		
		Lootster_AdjustRec.Link = Lootster_ItemLink;
		Lootster_AdjustRec.Reason = reason;

		-- set default DKP value and reason
		Lootster_RaidFrameAdjustFrameDKP:SetNumber(string.format(LOOTSTER_COST_POINTS, dkp));
		Lootster_RaidFrameAdjustFrameReason:SetText(reason);
		Lootster_RaidFrameAdjustFrameCommentText:SetText("");
	end
	
	-- update roll UI
	Lootster_UpdateRollUI();

	-- resort loot using current sort
	Lootster_Loot_Sort(nil);
end

-- Update Item Prompt using Item Count
function Lootster_UpdateItemPrompt()
	-- how many items we rolling on?
	if (Lootster_ItemCount <= 1) then
		-- item prompt is item text
		Lootster_ItemPrompt = Lootster_ItemLink;
	else
		-- create item prompt using item count
		if (Lootster_ItemLink == nil) then
			-- create an item prompt
			Lootster_ItemPrompt = string.format(LOOTSTER_ECHO_ITEMS, Lootster_ItemCount);
		else
			-- create item text item prompt
			Lootster_ItemPrompt = string.format(LOOTSTER_ECHO_ITEMS_LINK, Lootster_ItemCount, Lootster_ItemLink);
		end
	end
end

-- Has Raid Zone Changed handler
function Lootster_HasRaidZoneChanged(delay)
	local	zone, isInst, type, mode, change;
	
	-- get the zone name (instance name if appropriate)
	zone = GetRealZoneText();

	-- are we to delay zone change, or has the zone been loaded yet?
	if ((delay == true) or (zone == nil) or (zone == "")) then
		-- retry in 5 seconds
		Lootster_Scheduler_Enqueue(LOOTSTER_ENUM_SCHEDULERID.ZONE, 5, Lootster_WORLD_Update);
		return nil, nil, nil;
	end
	
	-- ignore if we have been toasted
	if (UnitIsGhost(Lootster_Self)) then
		return false, zone, LOOTSTER_ENUM_RAIDTYPE.UNKNOWN;
	end

	-- get instance data
	isInst, type = IsInInstance();
	
	-- process party/raid instances here.  Outdoor bosses will be handled via boss detection
	if	((isInst ~= 1) or (type == "none") or (type == "pvp") or (type == "arena")) then
		-- is there a currently running raid?
		if (Lootster_Running.RaidId ~= nil) then
			-- outdoor bosses we can detect a change only via zone
			if (Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.OUTDOOR) then
				-- yes I know crude
				change = Lootster_Raid[Lootster_Running.RaidId].Zone ~= zone;
			else			
				-- a new non-instance zone
				change = true;
			end
		else			
			-- zone change is not relevant
			change = false;
		end

		return change, zone, LOOTSTER_ENUM_RAIDTYPE.UNKNOWN;
	end

	-- retrieve the instance difficulty
	if		(type == "party") then
		-- dungeon difficulty
		mode = GetDungeonDifficulty();
	elseif	(type == "raid") then
		-- raid difficulty
		mode = GetRaidDifficulty();
	end
	
	-- see what dungeons we are tracking
	if		((type == "party") and (mode == 1)) then
		-- set type
		type = LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM;
	elseif	((type == "party") and (mode == 2)) then
		-- set type
		type = LOOTSTER_ENUM_RAIDTYPE.DUNGEONHERO;
	elseif	((type == "raid") and (mode == 1)) then
		-- set type
		type = LOOTSTER_ENUM_RAIDTYPE.RAID10NORM;
	elseif	((type == "raid") and (mode == 3)) then
		-- set type
		type = LOOTSTER_ENUM_RAIDTYPE.RAID10HERO;
	elseif	((type == "raid") and (mode == 2)) then
		-- set type
		type = LOOTSTER_ENUM_RAIDTYPE.RAID25NORM;
	elseif	((type == "raid") and (mode == 4)) then
		-- set type
		type = LOOTSTER_ENUM_RAIDTYPE.RAID25HERO;
	else
		-- set type as unknown
		type = LOOTSTER_ENUM_RAIDTYPE.UNKNOWN;
	end
	
	-- is this the currently running raid?
	if (Lootster_Running.RaidId ~= nil) then
		-- have we changed zones or type of zone?
		change = (Lootster_Raid[Lootster_Running.RaidId].Zone ~= zone) or (Lootster_Raid[Lootster_Running.RaidId].Type ~= type);
	else
		-- a new zone
		change = true;
	end
	
	return change, zone, type;
end

-- Get Raid Boss handler
function Lootster_GetRaidBoss()
	local	npcId, boss, killSet, dead;
	
	-- no boss, and not dead yet
	boss = nil;
	killSet = nil;
	dead = false;
	
	-- have we a target?
	if (UnitExists("target") == nil) then
		return nil, nil, false;
	end
	
	-- grab the target GUID's ID
	npcId = Lootster_GetBossId(UnitGUID("target"));

	-- grab the target name
	boss = UnitName("target");
	
	-- is this an enemy target?
	if ((LOOTSTER_BOSS_ID[npcId] == nil) and (Lootster_MobsDKP[boss] == nil)) then
		return nil, nil, false;
	end

	-- determine if dead.  Useful only when we know we exited combat on this guy
	dead = UnitIsDead("target") == 1;

	-- check the boss translation look-aside table
	if (LOOTSTER_BOSS_TLB[npcId] ~= nil) then
		-- translate to the underlying boss id
		npcId = LOOTSTER_BOSS_TLB[npcId];
	end
	
	-- this a known boss?
	if		(Lootster_MobsDKP[boss] ~= nil) then
		-- use this boss name
		boss = Lootster_MobsDKP[boss];
	elseif	(LOOTSTER_BOSS_NAME[npcId] ~= nil) then
		-- retrieve group name for boss
		boss = LOOTSTER_BOSS_NAME[npcId];
	end
	
	-- this boss might have co-bosses/mini-bosses that need to be toasted for the kill to count
	if (LOOTSTER_BOSS_KILL[npcId] ~= nil) then
		-- retrieve group of boss ids required for kill
		killSet = Lootster_CopyRecord(LOOTSTER_BOSS_KILL[npcId]);
	end

	return boss, killSet, dead;
end

-- Is Boss Attempt handler
function Lootster_IsBossAttempt(bossId)
	-- if the boss is marked as a boss attempt with a real boss, it is a boss attempt
	return (bossId ~= nil) and (Lootster_Boss[bossId].Type == LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT) and (Lootster_Boss[bossId].Combat == true) and (Lootster_Boss[bossId].TBD ~= true);
end

-- Start Boss Attempt handler
function Lootster_StartBossAttempt(npcId, boss, killSet)
	local	bossRec;
			
	-- determine if it is a raid or boss we must initiate
	if		((Lootster_Running.RaidId == nil) and ((boss ~= nil) or (npcId ~= nil))) then
		-- nope, so start one.  This has to be an outdoor raid that we track otherwise the raid
		-- would already be in progress
		Lootster_Raid_OnToggle(self, boss, killSet);
	elseif	(Lootster_Running.BossId == nil) then
		-- nope, so start one
		Lootster_Boss_OnToggle(self, boss, killSet);
	elseif	((Lootster_Boss[Lootster_Running.BossId].TBD ~= false) and (boss ~= nil)) then
		-- is this raid in an unknown instance?
		if (Lootster_Raid[Lootster_Running.RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) then
			-- this is a well known boss, so mark it as an outdoor raid
			Lootster_Raid[Lootster_Running.RaidId].Type = LOOTSTER_ENUM_RAIDTYPE.OUTDOOR;
			
			-- and rerun the raid
			Lootster_RunRaid(Lootster_Running.RaidId);
		end
		
		-- we resolved the boss name for the fight.  Modify the existing boss with the information
		bossRec = Lootster_CopyRecord(Lootster_Boss[Lootster_Running.BossId]);
		
		-- update the boss and TBD flag
		bossRec.Boss = boss;
		bossRec.TBD = false;
		
		-- locate any previous attempts
		bossId = Lootster_GetMatchingBoss(Lootster_Running.RaidId, boss);

		-- did we have a previous attempt at boss?
		if (bossId ~= nil) then
			-- and bump attempt number
			bossRec.Attempt = Lootster_Boss[bossId].Attempt + 1;
		else
			-- make sure we reset the attempt number
			bossRec.Attempt = 1;
		end
		
		-- and modify the boss
		Lootster_ModifyBoss(bossRec);
		
		-- snarf the resolved kill set unless it is already present
		if ((killSet ~= nil) and (Lootster_Boss[Lootster_Running.BossId].KillSet == nil)) then
			-- setup a new kill set
			Lootster_Boss[Lootster_Running.BossId].KillSet = killSet;
		end
	elseif	((Lootster_Options.AutoBoss == true) and ((boss ~= nil) or (npcId ~= nil))) then
		-- a previously running boss or current boss has been killed/wiped?
		if (((boss ~= nil) and (boss ~= Lootster_Boss[Lootster_Running.BossId].Boss)) or (Lootster_Boss[Lootster_Running.BossId].Type ~= LOOTSTER_ENUM_BOSSTYPE.BOSSATTEMPT)) then
			-- different boss or one that was killed/wiped, so finish this one
			Lootster_Boss_OnToggle(self);
			
			--  and start new one
			Lootster_Boss_OnToggle(self, boss, killSet);
		end
	end
	
	-- have we a boss name or an NPC id?
	if ((boss ~= nil) or (npcId ~= nil)) then
		-- mark this boss as having entered combat
		Lootster_Boss[Lootster_Running.BossId].Combat = true;
		
		-- is this boss still TBD?
		if (Lootster_Boss[Lootster_Running.BossId].TBD == true) then
			-- set TBD to the id of the NPC for this boss fight
			Lootster_Boss[Lootster_Running.BossId].TBD = npcId;
		end
	end		
end

-- Is Event Handled handler
function Lootster_IsHandledEvent(raidType, eventType)
	-- determine if this event is handled for the raid type
	if		((raidType == LOOTSTER_ENUM_RAIDTYPE.RAID10NORM) or (raidType == LOOTSTER_ENUM_RAIDTYPE.RAID10HERO)) then
		return Lootster_Options.Event[eventType].Use10;
	elseif	((raidType == LOOTSTER_ENUM_RAIDTYPE.RAID25NORM) or (raidType == LOOTSTER_ENUM_RAIDTYPE.RAID25HERO) or (raidType == LOOTSTER_ENUM_RAIDTYPE.OUTDOOR)) then
		return Lootster_Options.Event[eventType].Use25;
	else
		return false;
	end
end

-- Run Raid handler
function Lootster_RunRaid(raidId)
	local	dateNow, bossRec, bossId, dateBeg, attempt;
	
	-- get the current server time
	dateNow = Lootster_CalcServerTime(time());
	
	-- if this is not the running raid, do we already have a running raid that needs to be event finished?
	if ((Lootster_Running.RaidId ~= raidId) and (Lootster_Running.RaidId ~= nil)) then
		-- see if we need to terminate the bonus time event
		if (Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSTIME)) then
			-- manage a bonus time boss as necessary, terminating bonus time scheduling
			Lootster_ManageBonusTime(false);
		end
			
		-- see if we need to add a raid finish event
		if (Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.RAIDFINISH)) then
			-- is there another raid finish event for this raid?
			bossId = Lootster_GetMatchingBoss(Lootster_Running.RaidId, nil, LOOTSTER_ENUM_BOSSTYPE.RAIDFINISH);
			
			-- if we have a boss, make sure this raid finish is not inside this raid finish time
			if ((bossId ~= nil) and ((Lootster_Boss[bossId].DateBeg + (Lootster_Options.Event[LOOTSTER_ENUM_EVENT.RAIDFINISH].Time * 60 * 60)) >= dateNow)) then
				-- update new raid finish time
				Lootster_Boss[bossId].DateBeg = dateNow;
				Lootster_Boss[bossId].DateEnd = Lootster_Boss[bossId].DateBeg;
				
				-- update attendance, removing those not here
				Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.NOTATALL);
			else
				-- determine attempt number
				if (bossId ~= nil) then
					-- bump attempt
					attempt = Lootster_Boss[bossId].Attempt + 1;
				else
					attempt = 1;
				end
				
				-- instantiate a new boss record for raid finish
				bossRec = Lootster_NewBoss(LOOTSTER_BOSSTYPE_LIST[LOOTSTER_ENUM_EVENT.RAIDFINISH],
										   dateNow, false, attempt, LOOTSTER_ENUM_BOSSTYPE.RAIDFINISH);

				-- update raid finish end time
				bossRec.DateEnd = bossRec.DateBeg;
				
				-- create the boss
				bossId = Lootster_CreateBoss(bossRec);
			
				-- insert boss into the running
				Lootster_InsertBoss(Lootster_Running.RaidId, bossId, true);

				-- take full attendance now
				Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.FULL);
			end
		end
	end
	
	-- update the running raid
	Lootster_Running.RaidId = raidId;
	
	-- do we have a running raid that needs to be event started?
	if (Lootster_Running.RaidId ~= nil) then
		-- see if we need to add a raid start event
		if (Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.RAIDSTART)) then
			-- is there another raid start event for this raid?
			bossId = Lootster_GetMatchingBoss(Lootster_Running.RaidId, nil, LOOTSTER_ENUM_BOSSTYPE.RAIDSTART);
			
			-- if we have a boss, make sure this raid start is outside the raid start time
			if ((bossId == nil) or ((Lootster_Boss[bossId].DateBeg + (Lootster_Options.Event[LOOTSTER_ENUM_EVENT.RAIDSTART].Time * 60 * 60)) < dateNow)) then
				-- determine begin date of this raid start and attempt number
				if		(bossId ~= nil) then
					-- use current time and bump attempt
					dateBeg = dateNow;
					attempt = Lootster_Boss[bossId].Attempt + 1;
				else
					-- use raid open
					dateBeg = Lootster_Raid[Lootster_Running.RaidId].DateOpn;
					attempt = 1;
				end					
					
				-- instantiate a new boss record for raid start
				bossRec = Lootster_NewBoss(LOOTSTER_BOSSTYPE_LIST[LOOTSTER_ENUM_EVENT.RAIDSTART],
										   dateBeg, false, attempt, LOOTSTER_ENUM_BOSSTYPE.RAIDSTART);
										   
				-- update raid start end time
				bossRec.DateEnd = bossRec.DateBeg;
				
				-- create the boss
				bossId = Lootster_CreateBoss(bossRec);
			
				-- insert boss into the running
				Lootster_InsertBoss(Lootster_Running.RaidId, bossId, true);

				-- take full attendance now
				Lootster_TakeAttendance(bossId, LOOTSTER_ENUM_ATTENDED.FULL);
			end
		end
		
		-- see if we need to remove a raid finish event
		if (Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.RAIDFINISH)) then
			-- is there a raid start finish for this raid?
			bossId = Lootster_GetMatchingBoss(Lootster_Running.RaidId, nil, LOOTSTER_ENUM_BOSSTYPE.RAIDFINISH);
			
			-- found a finish?
			if (bossId ~= nil) then
				-- delete raid finish from the running raid
				Lootster_DeleteBoss(bossId, true);
					
				-- make sure we reset boss if it disappeared
				if (Lootster_Running.BossId == bossId) then
					-- end of boss
					Lootster_RunBoss(nil);
				end
				
				-- make sure we reset selected boss if it disappeared
				if (Lootster_BossId == bossId) then
					-- no current boss
					Lootster_BossId = nil;
				end
			end
		end
			
		-- see if we need to schedule or update a bonus time event
		if (Lootster_IsHandledEvent(Lootster_Raid[Lootster_Running.RaidId].Type, LOOTSTER_ENUM_EVENT.BONUSTIME)) then
			-- manage a bonus time boss as necessary, initiating bonus time scheduling
			Lootster_ManageBonusTime(true);
		end		
	end
end

-- Run Boss handler
function Lootster_RunBoss(bossId)
	-- update the running boss
	Lootster_Running.BossId = bossId;
end

-- Update Raid handler
function Lootster_UpdateRaid(raidId, raidType)
	local	bossId, player, flag;
	
	-- update the raid type as required
	if (raidType ~= nil) then
		-- update the raid type
		Lootster_Raid[raidId].Type = raidType;
	end
	
	-- recalculate raid's boss attendance DKP as required
	for bossId, flag in pairs(Lootster_Raid[raidId].BossSet) do
		-- recalculate boss's attendance DKP as required
		for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
			-- is old attendance DKP zero?
			if (Lootster_Attend[attendId].DKPAttEarnt ~= 0) then
				-- unwind attendance DKP from raid/boss
				Lootster_SubAttend(attendId);
			end
		
			-- calculate attendance DKP.  No need to unwind previous value since we reset raid and boss earnt DKP
			Lootster_Attend[attendId].DKPAttEarnt = Lootster_CalcAttendDKP(raidId, bossId, Lootster_Attend[attendId].Attended);
			
			-- is this attendance DKP zero?
			if (Lootster_Attend[attendId].DKPAttEarnt ~= 0) then
				-- rollup attendance DKP to raid/boss
				Lootster_AddAttend(attendId);
			end
		end
	end
end

-- Update Boss handler
function Lootster_UpdateBoss(bossId, bossType)
	local	raidId, player, attendId;
	
	-- update the boss type as required
	if (bossType ~= nil) then
		-- set new boss type
		Lootster_Boss[bossId].Type = bossType;
		
		-- are we marking this as a kill or a wipe?
		if ((bossType == LOOTSTER_ENUM_BOSSTYPE.BOSSKILL) or (bossType == LOOTSTER_ENUM_BOSSTYPE.BOSSWIPE)) then
			-- set the end date
			Lootster_Boss[bossId].DateEnd = Lootster_CalcServerTime(time());
		end
	end

	-- do we have raid? 
	if (Lootster_Boss[bossId].RaidId ~= nil) then
		-- get the raid id for boss
		raidId = Lootster_Boss[bossId].RaidId;
		
		-- recalculate boss's attendance DKP as required
		for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
			-- is old attendance DKP zero?
			if (Lootster_Attend[attendId].DKPAttEarnt ~= 0) then
				-- unwind attendance DKP from raid/boss
				Lootster_SubAttend(attendId);
			end
			
			-- calculate attendance DKP
			Lootster_Attend[attendId].DKPAttEarnt = Lootster_CalcAttendDKP(raidId, bossId, Lootster_Attend[attendId].Attended);
			
			-- is this attendance DKP zero?
			if (Lootster_Attend[attendId].DKPAttEarnt ~= 0) then
				-- rollup attendance DKP to raid/boss
				Lootster_AddAttend(attendId);
			end
		end
	end
	
	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
end

-- Update Attend handler
function Lootster_UpdateAttend(attendId, attended)
	local	bossId, raidId, event;
	
	-- update the attended type
	Lootster_Attend[attendId].Attended = attended;

	-- do we have boss? 
	if (Lootster_Attend[attendId].BossId == nil) then
		-- nothing can be calculated
		return;
	end
	
	-- get the boss id for attendance
	bossId = Lootster_Attend[attendId].BossId;

	-- do we have raid? 
	if (Lootster_Boss[bossId].RaidId == nil) then
		-- nothing can be calculated
		return;
	end
	
	-- get the raid id for boss
	raidId = Lootster_Boss[bossId].RaidId;
	
	-- calculate attendance DKP
	Lootster_Attend[attendId].DKPAttEarnt = Lootster_CalcAttendDKP(raidId, bossId, attended);
end

-- Take Attendance handler
function Lootster_TakeAttendance(bossId, attended)
	local	oldAttendee, alt, main, attendId, rosRec;
	
	-- we need a boss
	if (bossId == nil) then
		return;
	end
	
	-- reset old attendee list
	oldAttendee = {};
	
	-- accumulate old attendee list
	for main, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
		-- add this old guy
		oldAttendee[main] = attendId;
	end
	
	-- accumulate new attendee list
	for alt, rosRec in pairs(Lootster_Roster) do
		-- determine the main for this possible alt
		main = Lootster_GetAltMain(alt);

		-- was this guy in the old attendee list?
		if (oldAttendee[main] ~= nil) then
			-- he is still here
			oldAttendee[main] = nil;
		else
			-- insert new guy into boss
			Lootster_InsertAttend(bossId, Lootster_CreateAttend(Lootster_NewAttend(main, alt, attended, 0)));
		end
	end

	-- update each of the remaining old guys with the passed attendance
	for main, attendId in pairs(oldAttendee) do
		-- update current alt, if any
		Lootster_Attend[attendId].Alt = Lootster_GetMainAlt(main);
		
		-- if new attendance is not at all, delete entry.  Otherwise make sure we don't upgrade him
		if		(attended == LOOTSTER_ENUM_ATTENDED.NOTATALL) then
			-- delete the attendance entry
			Lootster_DeleteAttend(attendId);
		elseif	(Lootster_Attend[attendId].Attended < attended) then
			-- update the attendance DKP
			Lootster_UpdateAttend(attendId, attended);
		end
	end

	-- resort data DKP using current sort
	Lootster_Data_DKP_Sort(nil);

	-- resort data attend using current sort
	Lootster_Data_Attend_Sort(nil);

	-- resort data adjust using current sort
	Lootster_Data_Adjust_Sort(nil);

	-- resort raid raid using current sort
	Lootster_Raid_Raid_Sort(nil);

	-- resort raid boss using current sort
	Lootster_Raid_Boss_Sort(nil);

	-- resort raid attend using current sort
	Lootster_Raid_Attend_Sort(nil);
end

-- Call Process handler
function LOOTSTER_ADDON_Process(player, msg, payload)
	-- process call command
	if		((player == Lootster_Self) and ((Lootster_InDebugger == false) or (Lootster_FromDebugger == false))) then
		-- ignore our own dog food
		return false;
	elseif	(Lootster_Options.AutoSnoop == false) then
		-- no auto-snoop processing
		return true;
	elseif	(msg == LOOTSTER_ADDON_CMD_CALLROLL) then
		local	_, ver;

		-- snarf version.  This is the version the receiver can process
		_, _, ver = string.find(payload, LOOTSTER_ADDON_IMP_CALLROLL);

		-- validate
		if (ver == nil) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, LOOTSTER_ROLLCALL_TITLE, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is less than our base, make sure we let them know its incompatible
		if (ver < LOOTSTER_ADDON_VERSION_BASE) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADVERSION, LOOTSTER_ROLLCALL_TITLE, player, ver,
															  LOOTSTER_ADDON_VERSION_BASE), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- setup the call handling
		Lootster_CallType = LOOTSTER_ADDON_CMD_CALLROLL;
		Lootster_CallUser = player;
		Lootster_CallData = {};
		Lootster_CallTitle = LOOTSTER_ROLLCALL_TITLE;
	elseif	(msg == LOOTSTER_ADDON_CMD_HOLDROLL) then
		local	_, ver, roller, hold;

		-- snarf version.  This is the version the receiver can process
		_, _, ver, roller, hold = string.find(payload, LOOTSTER_ADDON_IMP_HOLDROLL);

		-- validate
		if ((ver == nil) or (roller == nil) or (hold == nil)) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, LOOTSTER_HOLDROLL_TITLE, msg, payload), true);
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is less than our base, make sure we let them know its incompatible
		if (ver < LOOTSTER_ADDON_VERSION_BASE) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADVERSION, LOOTSTER_HOLDROLL_TITLE, player, ver,
															  LOOTSTER_ADDON_VERSION_BASE), true);
			return false;
		end

		-- sender must be the master looter/leader
		if (player == Lootster_LootMaster) then
			-- if we have an roll entry for this roller, set his roll's held status
			if (Lootster_Rolls[roller] ~= nil) then
				Lootster_Rolls[roller].Hold = (hold == "true");
			end
		else
			-- eep!  No permission for this function - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONPERMDENIED, LOOTSTER_HOLDROLL_TITLE, player, roller), true);
			return false;
		end

		-- resort the rolls
		Lootster_Roll_Sort();

		-- update received roll status
		Lootster_UpdateRollUI();	

		-- update the screen
		Lootster_Roll_Update();
	elseif	(Lootster_CallType == nil) then
		-- eep!  No addon in progress - no message as it can spam
		return false;
	elseif	(Lootster_CallUser ~= player) then
		-- eep!  Player is not our addon transmitter - no message as it can spam
		return false;
	elseif	(msg == LOOTSTER_ADDON_CMD_BEGIN) then
		local	_, ver, recCount;

		-- parse the payload
		_, _, ver, recCount = string.find(payload, LOOTSTER_ADDON_IMP_BEGIN);

		-- validate
		if ((ver == nil) or (recCount == nil)) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is less than our base, make sure we let them know its incompatible
		if (ver < LOOTSTER_ADDON_VERSION_BASE) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADVERSION, Lootster_CallTitle, player, ver,
															  LOOTSTER_ADDON_VERSION_BASE), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert record count to a number
		recCount = tonumber(recCount);

		-- reset record counters
		Lootster_CallCount = 0;
		Lootster_CallTotal = recCount;

		-- reset synchronise data
		Lootster_CallData = {};

		-- setup this call type
		Lootster_CallData[Lootster_CallType] = {};
	elseif	(msg == LOOTSTER_ADDON_CMD_COMMIT) then
		-- validate hash totals
		if (Lootster_CallCount ~= Lootster_CallTotal) then
			-- bad hash total
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADHASHTOTAL, Lootster_CallTitle, Lootster_CallCount,
															  Lootster_CallTotal), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- commit the data
		if		(Lootster_CallType == LOOTSTER_ADDON_CMD_CALLROLL) then
			-- if this a DKP roll call and we have no data DKP, or our guilds differ, ignore silently
			if ((Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollMode"] == LOOTSTER_ENUM_ROLLMODE.USEDKP) and  
				not Lootster_HasDKP) then
				-- failed operation
				LOOTSTER_ADDON_StateUpdate();
				return false;
			elseif (Lootster_SelfGuild ~= Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["Guild"]) then
				-- failed operation
				LOOTSTER_ADDON_StateUpdate();
				return false;
			end

			-- if we are active, make sure we are deactivated
			if (Lootster_Options.Active == true) then
				-- toggle off
				Lootster_RollFrameActive:SetChecked(false);

				-- and snarf
				Lootster_Roll_ActiveButton_OnToggle(self);
			end

			-- clear rolls
			Lootster_Roll_ClearRolls_OnClick(Lootster_RollFrameClearRolls, "LeftButton");

			-- update the UI
			Lootster_UpdateRollUI();

			-- ensure roll mode is valid - fail silently otherwise
			if (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollMode"] > LOOTSTER_ENUM_ROLLMODE.USENORM) then
				-- unknown roll mode - failed operation
				LOOTSTER_ADDON_StateUpdate();
				return false;
			end

			-- first, set the roll mode as necessary
			Lootster_Options.RollMode = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollMode"];

			-- set roll mode
			Lootster_Option_RollMode_OnShow(self);

			-- DKP or normal use?
			if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				-- ensure DKP type is valid - fail silently otherwise
				if (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollType"] > LOOTSTER_ENUM_DKP.BYEPGP) then
					-- unknown roll mode - failed operation
					LOOTSTER_ADDON_StateUpdate();
					return false;
				end

				-- set DKP type
				Lootster_Options.DKPType = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollType"];
			elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_ROLLMODE.USENORM) then
				-- ensure Normal type is valid - fail silently otherwise
				if (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollType"] > LOOTSTER_ENUM_NORM.BYFREEFORALL) then
					-- unknown roll mode - failed operation
					LOOTSTER_ADDON_StateUpdate();
					return false;
				end

				-- set Normal type
				Lootster_Options.NormType = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RollType"];
			end

			-- set roll type
			Lootster_Option_RollType_OnShow(self);

			-- set priority membership and toonship usage
			if		(Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				-- set DKP membership and toonship usage
				Lootster_Options.DKPMember = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["PriorMember"];
				Lootster_Options.DKPToon = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["PriorToon"];
				Lootster_Options.DKPGreedFFA = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["GreedFFA"];

				Lootster_OptionsFrameDKPMember:SetChecked(Lootster_Options.DKPMember);
				Lootster_OptionsFrameDKPToon:SetChecked(Lootster_Options.DKPToon);
			elseif	(Lootster_Options.NormType == LOOTSTER_ENUM_ROLLMODE.USENORM) then
				-- set Normal membership and toonship usage
				Lootster_Options.NormMember = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["PriorMember"];
				Lootster_Options.NormToon = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["PriorToon"];
				Lootster_Options.NormGreedFFA = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["GreedFFA"];

				Lootster_OptionsFrameNormMember:SetChecked(Lootster_Options.NormMember);
				Lootster_OptionsFrameNormToon:SetChecked(Lootster_Options.NormToon);
			end

			-- set guild membership and toonship usage if we are guilded
			if (Lootster_SelfGuild ~= nil) then
				Lootster_Options.RankMembers[Lootster_SelfGuild] = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RankMembers"];
				Lootster_Options.NoteToons[Lootster_SelfGuild] = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["NoteToons"];
				Lootster_Options.RankToons[Lootster_SelfGuild] = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_MODE]["RankToons"];

				Lootster_OptionsFrameRankMembers:SetChecked(Lootster_Options.RankMembers[Lootster_SelfGuild]);
				Lootster_OptionsFrameNoteToons:SetChecked(Lootster_Options.NoteToons[Lootster_SelfGuild]);
				Lootster_OptionsFrameRankToons:SetChecked(Lootster_Options.RankToons[Lootster_SelfGuild]);
			end

			-- are we using DKP?
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				-- manage earnt attendance DKP use if not EPGP
				if (Lootster_Options.DKPType ~= LOOTSTER_ENUM_DKP.BYEPGP) then
					Lootster_Options.DKPAttEarnt = (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EARN] ~= nil);

					Lootster_OptionsFrameDKPAttEarnt:SetChecked(Lootster_Options.DKPAttEarnt);
				end
				
				-- manage DKP caps
				Lootster_Options.DKPCaps = (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CAPS] ~= nil);

				Lootster_OptionsFrameDKPCaps:SetChecked(Lootster_Options.DKPCaps);

				-- are we using caps?
				if (Lootster_Options.DKPCaps == true) then
					-- update DKP hi and lo caps
					Lootster_OptionsFrameDKPHi:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CAPS]["DKPHi"]); 
					Lootster_OptionsFrameDKPLo:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CAPS]["DKPLo"]);

					-- cause snarf of set DKP caps
					Lootster_Option_DKPHi_OnFocusLost(self);
					Lootster_Option_DKPLo_OnFocusLost(self);
				end

				-- manage factoring
				if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDROLL) then
					-- manage DKP factoring
					Lootster_Options.DKPFactoring = (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_FCTR] ~= nil);

					Lootster_OptionsFrameDKPFactoring:SetChecked(Lootster_Options.DKPFactoring);

					-- are we using DKP factoring?
					if (Lootster_Options.DKPFactoring == true) then
						-- update the DKP factor
						Lootster_OptionsFrameDKPFactor:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_FCTR]["Factor"]);

						-- cause snarf of set DKP factor
						Lootster_Option_DKPFactor_OnFocusLost(self);
					end
				elseif	(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYMODIFIEDDKP) then
					-- manage roll factoring
					Lootster_Options.RollFactoring = (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_FCTR] ~= nil);

					Lootster_OptionsFrameRollFactoring:SetChecked(Lootster_Options.RollFactoring);

					-- are we using roll factoring?
					if (Lootster_Options.RollFactoring == true) then
						-- update the roll factor
						Lootster_OptionsFrameRollFactor:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_FCTR]["Factor"]);

						-- cause snarf of set roll factor
						Lootster_Option_RollFactor_OnFocusLost(self);
					end
				end

				-- manage EPGP limits
				if (Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
					-- manage EP minimum
					Lootster_Options.EPMin = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EPGP]["EPMin"];

					Lootster_OptionsFrameEPMin:SetChecked(Lootster_Options.EPMin);

					-- are we using EP minimum?
					if (Lootster_Options.EPMin == true) then
						-- update EP minimum EP
						Lootster_OptionsFrameEPMinEP:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EPGP]["EPMinEP"]); 

						-- cause snarf of set EP minimum EP
						Lootster_Option_EPMinEP_OnFocusLost(self);
					end
					
					-- manage GP base
					Lootster_Options.GPBase = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EPGP]["GPBase"];

					Lootster_OptionsFrameGPBase:SetChecked(Lootster_Options.GPBase);

					-- are we using GP base?
					if (Lootster_Options.GPBase == true) then
						-- update GP base GP
						Lootster_OptionsFrameGPBaseGP:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EPGP]["GPBaseGP"]); 

						-- cause snarf of set GP base GP
						Lootster_Option_GPBaseGP_OnFocusLost(self);
					end
				end
			end

			-- manage usage, if any
			Lootster_Options.UsageRolls = (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_USAGE] ~= nil);
			
			if (Lootster_Options.UsageRolls == true) then
				-- update usage data
				Lootster_Options.Usage = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_USAGE]["Usage"];
				
				-- update usage sort data
				Lootster_Options.UsageSort = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_USAGE]["UsageSort"];
			end

			-- manage events, if any
			if (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EVENTS] ~= nil) then
				-- update event data
				Lootster_Options.Event = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_EVENTS]["Event"];
			end
			
			-- manage item points, if any
			Lootster_Options.CalcPoints = (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_POINTS] ~= nil);
			
			if (Lootster_Options.CalcPoints == true) then
				-- update pFactor
				Lootster_OptionsFrameItemPointsFramepFactor:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_POINTS]["pFactor"]);
				
				-- update item quality data
				Lootster_Options.Quality = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_POINTS]["Quality"];
				
				-- update item slot data
				Lootster_Options.Slot = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_POINTS]["Slot"];

				-- cause snarf of set pFactor
				Lootster_Option_pFactor_OnFocusLost(self);
			end

			-- update roll handling
			Lootster_UpdateRollHandling();

			-- set the number of items being rolled on
			Lootster_RollFrameItems:SetNumber(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["ItemCount"]);

			-- and spoof entry to transfer and update
			Lootster_Roll_Items_OnFocusLost(self);

			-- set the hyperlink as appropriate
			Lootster_SetHyperlink(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["ItemLink"]);

			-- see if an item was passed and it was not class restricted
			if ((Lootster_ClassRestrictedLock == false) and (Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CLASS] ~= nil)) then
				-- dude is class restricted by roll caller
				Lootster_ClassRestricted = true;

				-- set the current restriction mask
				Lootster_ClassRestrictionsMaskCurr = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CLASS]["ClassRestrictionsMaskCurr"];

				-- set count
				Lootster_ClassRestrictionsN = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CLASS]["ClassRestrictionsN"];

				-- set classes
				Lootster_ClassRestrictions = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_CLASS]["ClassRestrictions"];

				-- update the class frame
				Lootster_UpdateClassUI();

				-- update restricted count
				Lootster_UpdateRestricted();

				-- show the class frame if we are visible
				if (Lootster_IsVisible()) then
					Lootster_ClassFrame:Show();
				end
			end

			-- what kind of roll?
			if		(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["NBG"] == LOOTSTER_NBG_NEED) then
				-- force Need roll
				Lootster_Roll_NeedRoll_OnClick(Lootster_RollFrameNeedRoll, "LeftButton");
			elseif	(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["NBG"] == LOOTSTER_NBG_1001000) then
				-- force 100/1000 roll
				Lootster_Roll_1001000Roll_OnClick(Lootster_RollFrame1001000Roll, "LeftButton");
			elseif	(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["NBG"] == LOOTSTER_NBG_GREED) then
				-- force Greed roll
				Lootster_Roll_GreedRoll_OnClick(Lootster_RollFrameGreedRoll, "LeftButton");
			elseif	(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["NBG"] == LOOTSTER_NBG_FREEFORALL) then
				-- force FFA roll
				Lootster_Roll_FreeForAllRoll_OnClick(Lootster_RollFrameFreeForAllRoll, "LeftButton");
			elseif	(Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_ROLL]["NBG"] == LOOTSTER_NBG_TIED) then
				-- calculate the positions
				Lootster_CalculatePositions();
				
				-- set the tied roll list and sort
				Lootster_TiedRolls = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_TIED]["TiedRolls"];
				Lootster_TiedRollsSort = Lootster_CallData[Lootster_CallType][LOOTSTER_ADDON_CMD_TIED]["TiedRollsSort"];

				-- force Tied roll
				Lootster_Roll_TiedRoll_OnClick(Lootster_RollFrameTiedRoll, "LeftButton");
			end
		end

		-- successful operation
		LOOTSTER_ADDON_StateUpdate();
	elseif	(msg == LOOTSTER_ADDON_CMD_MODE) then
		local	_, mode, type, usePriorMember, usePriorToon, useGreedFFA, useRankMembers, useNoteToons, useRankToons, guild;

		-- parse the payload
		_, _, mode, type, usePriorMember, usePriorToon, useGreedFFA, useRankMembers, useNoteToons, useRankToons, guild = string.find(payload, LOOTSTER_ADDON_IMP_MODE);

		-- validate
		if ((mode == nil) or (type == nil) or (usePriorMember == nil) or (usePriorToon == nil) or (useGreedFFA == nil) or 
			(useRankMembers == nil) or (useNoteToons == nil) or (useRankToons == nil) or (guild == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert the roll mode and roll type
		mode = tonumber(mode);
		type = tonumber(type);

		-- translate guild appropriately
		if (guild == "nil") then
			-- no guild
			guild = nil;
		end

		-- do we have a raid table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create mode record
		Lootster_CallData[Lootster_CallType][msg]["RollMode"] = mode;
		Lootster_CallData[Lootster_CallType][msg]["RollType"] = type;

		Lootster_CallData[Lootster_CallType][msg]["PriorMember"] = (usePriorMember == "true");
		Lootster_CallData[Lootster_CallType][msg]["PriorToon"] = (usePriorToon == "true");
		Lootster_CallData[Lootster_CallType][msg]["GreedFFA"] = (useGreedFFA == "true");

		Lootster_CallData[Lootster_CallType][msg]["RankMembers"] = (useRankMembers == "true");
		Lootster_CallData[Lootster_CallType][msg]["NoteToons"] = (useNoteToons == "true");
		Lootster_CallData[Lootster_CallType][msg]["RankToons"] = (useRankToons == "true");

		Lootster_CallData[Lootster_CallType][msg]["Guild"] = guild;

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_EARN) then
		local	_, isEarnt;

		-- parse the payload
		_, _, isEarnt = string.find(payload, LOOTSTER_ADDON_IMP_EARN);

		-- isEarnt
		if (dkpEarnt == nil) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- do we have a earnt table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create earnt record
		Lootster_CallData[Lootster_CallType][msg]["DKPAttEarnt"] = (isEarnt == "true");

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_CAPS) then
		local	_, DKPLo, DKPHi;

		-- parse the payload
		_, _, DKPLo, DKPHi = string.find(payload, LOOTSTER_ADDON_IMP_CAPS);

		-- validate
		if ((DKPLo == nil) or (DKPHi == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert caps
		DKPLo = tonumber(DKPLo);
		DKPHi = tonumber(DKPHi);

		-- do we have a caps table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create caps record
		Lootster_CallData[Lootster_CallType][msg]["DKPLo"] = DKPLo
		Lootster_CallData[Lootster_CallType][msg]["DKPHi"] = DKPHi

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_FCTR) then
		local	_, factor;

		-- parse the payload
		_, _, factor = string.find(payload, LOOTSTER_ADDON_IMP_FCTR);

		-- validate
		if (factor == nil) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert factor
		factor = tonumber(factor);

		-- do we have a factor table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create factor record
		Lootster_CallData[Lootster_CallType][msg]["Factor"] = factor

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;		
	elseif	(msg == LOOTSTER_ADDON_CMD_EPGP) then
		local	_, EPMin, GPBase;

		-- parse the payload
		_, _, useEPMin, EPMin, useGPBase, GPBase = string.find(payload, LOOTSTER_ADDON_IMP_EPGP);

		-- validate
		if ((useEPMin == nil) or (EPMin == nil) or (useGPBase == nil) or (GPBase == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert EP minimum
		EPMin = tonumber(EPMin);

		-- convert GP base
		GPBase = tonumber(GPBase);

		-- do we have a EPGP table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create EPGP record
		Lootster_CallData[Lootster_CallType][msg]["EPMin"] = (useEPMin == "true");
		Lootster_CallData[Lootster_CallType][msg]["EPMinEP"] = EPMin

		Lootster_CallData[Lootster_CallType][msg]["GPBase"] = (useGPBase == "true");
		Lootster_CallData[Lootster_CallType][msg]["GPBaseGP"] = GPBase

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_ROLL) then
		local	_, nbg, count, itemLink;

		-- parse the payload
		_, _, nbg, count, itemLink = string.find(payload, LOOTSTER_ADDON_IMP_ROLL);

		-- validate
		if ((nbg == nil) or (count == nil) or (itemLink == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- do we have a raid table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- translate item link appropriately
		if (itemLink == "nil") then
			-- no link
			itemLink = nil;
		end

		-- create roll record
		Lootster_CallData[Lootster_CallType][msg]["NBG"] = nbg;
		Lootster_CallData[Lootster_CallType][msg]["ItemCount"] = count;
		Lootster_CallData[Lootster_CallType][msg]["ItemLink"] = itemLink;

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_TIED) then
		local	_, tiedRolls, tiedRollsSort, tiedRollsFn, tiedRollsSortFn;

		-- parse the payload
		_, _, tiedRolls, tiedRollsSort = string.find(payload, LOOTSTER_ADDON_IMP_CLASS);

		-- deserialise tied rolls
		tiedRollsFn = Lootster_Deserialise(Lootster_DecodeText(tiedRolls));

		-- deserialise tied rolls sort
		tiedRollsSortFn = Lootster_Deserialise(Lootster_DecodeText(tiedRollsSort));

		-- validate
		if ((tiedRolls == nil) or (tiedRollsSort == nil) or (tiedRollsFn == nil) or (tiedRollsSortFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- do we have a tied rolls table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create tied rolls record
		Lootster_CallData[Lootster_CallType][msg]["TiedRolls"] = tiedRollsFn();
		Lootster_CallData[Lootster_CallType][msg]["TiedRollsSort"] = tiedRollsSortFn();

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;		
	elseif	(msg == LOOTSTER_ADDON_CMD_CLASS) then
		local	_, classRestrictionsMaskCurr, classRestrictionsN, classRestrictions, classRestrictionsFn;

		-- parse the payload
		_, _, classRestrictionsN, classRestrictionsMaskCurr, classRestrictions = string.find(payload, LOOTSTER_ADDON_IMP_CLASS);

		-- deserialise class restrictions
		classRestrictionsFn = Lootster_Deserialise(Lootster_DecodeText(classRestrictions));

		-- validate
		if ((classRestrictionsN == nil) or (classRestrictionsMaskCurr == nil) or (classRestrictions == nil) or (classRestrictionsFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- do we have a class restrictions table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end

		-- create class restriction record
		Lootster_CallData[Lootster_CallType][msg]["ClassRestrictionsMaskCurr"] = classRestrictionsMaskCurr;
		Lootster_CallData[Lootster_CallType][msg]["ClassRestrictionsN"] = classRestrictionsN;
		Lootster_CallData[Lootster_CallType][msg]["ClassRestrictions"] = classRestrictionsFn();

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_USAGE) then
		local	_, usage, usageSort, usageFn, usageSortFn;

		-- parse the payload
		_, _, usage, usageSort = string.find(payload, LOOTSTER_ADDON_IMP_USAGE);
		
		-- deserialise usage
		usageFn = Lootster_Deserialise(Lootster_DecodeText(usage));
		
		-- deserialise usage sort
		usageSortFn = Lootster_Deserialise(Lootster_DecodeText(usageSort));

		-- validate
		if ((usage == nil) or (usageSort == nil) or (usageFn == nil) or (usageSortFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- do we have a usage table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end
		
		-- parse usage record
		Lootster_CallData[Lootster_CallType][msg]["Usage"] = usageFn();
		
		-- parse usage sort record
		Lootster_CallData[Lootster_CallType][msg]["UsageSort"] = slotFn();

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_EVENTS) then
		local	_, event, eventFn;

		-- parse the payload
		_, _, event = string.find(payload, LOOTSTER_ADDON_IMP_EVENTS);
		
		-- deserialise event
		eventFn = Lootster_Deserialise(Lootster_DecodeText(event));

		-- validate
		if ((event == nil) or (eventFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- do we have a events table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end
		
		-- parse event record
		Lootster_CallData[Lootster_CallType][msg]["Event"] = eventFn();

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	elseif	(msg == LOOTSTER_ADDON_CMD_POINTS) then
		local	_, pFactor, quality, slot, qualityFn, slotFn;

		-- parse the payload
		_, _, pFactor, quality, slot = string.find(payload, LOOTSTER_ADDON_IMP_POINTS);
		
		-- deserialise item quality
		qualityFn = Lootster_Deserialise(Lootster_DecodeText(quality));
		
		-- deserialise item slot
		slotFn = Lootster_Deserialise(Lootster_DecodeText(slot));

		-- validate
		if ((pFactor == nil) or (quality == nil) or (slot == nil) or (qualityFn == nil) or (slotFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_ADDONBADRECORD, Lootster_CallTitle, msg, payload), true);

			-- failed operation
			LOOTSTER_ADDON_StateUpdate();
			return false;
		end

		-- convert pFactor
		pFactor = tonumber(pFactor);

		-- do we have a points table yet?
		if (Lootster_CallData[Lootster_CallType][msg] == nil) then
			Lootster_CallData[Lootster_CallType][msg] = {};
		end
		
		-- create points factor record
		Lootster_CallData[Lootster_CallType][msg]["pFactor"] = pFactor;
		
		-- parse item quality record
		Lootster_CallData[Lootster_CallType][msg]["Quality"] = qualityFn();
		
		-- parse item slot record
		Lootster_CallData[Lootster_CallType][msg]["Slot"] = slotFn();

		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;
	else
		-- bump record count
		Lootster_CallCount = Lootster_CallCount + 1;

		-- unknown sync - ignore
		return false;
	end
	
	return true;
end

-- Call State Update handler
function LOOTSTER_ADDON_StateUpdate()
	-- wack call user, type and data
	Lootster_CallUser = nil;
	Lootster_CallType = nil;
	Lootster_CallData = {};
	Lootster_CallTitle = "";
	Lootster_CallCount = 0;
	Lootster_CallTotal = 0;
end

-- Synchronise Process handler
function Lootster_Sync_Process(player, msg, payload)
	-- process synchronisation command
	if		(msg == LOOTSTER_SYNC_CMD_SYNCLOOT) then
		local	_, ver, recCount;

		-- snarf version.  This is the version the receiver can process
		_, _, ver = string.find(payload, LOOTSTER_SYNC_IMP_SYNCLOOT);

		-- validate
		if (ver == nil) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is less than our base, make sure we let them know its incompatible
		if (ver < LOOTSTER_SYNC_VERSION_BASE) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADVERSION, Lootster_SyncTitle, player, ver, LOOTSTER_SYNC_VERSION),
															  true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end
		
		-- if this version is greater than ours, make sure we downgrade it
		if (ver > LOOTSTER_SYNC_VERSION) then
			ver = LOOTSTER_SYNC_VERSION;
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- calculate record count
		recCount = 0;

		for lootName, lootRec in pairs(Lootster_ItemDKP) do
			recCount = recCount + 1;
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- begin transaction
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_BEGIN, ver, recCount), true);

		-- transmit all items
		for lootName, lootRec in pairs(Lootster_ItemDKP) do
			-- send this item
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_LOOT, Lootster_EncodeText(lootName), 
								 Lootster_EncodeText(Lootster_Serialise(lootRec))), true);
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- commit transaction
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_COMMIT, ver), true);	
	elseif	(msg == LOOTSTER_SYNC_CMD_SYNCRAID) then
		local	_, ver, recCount, raidId, raidRec, bossId, bossRec, attendId, attendRec, adjustId, adjustRec, assignId, assignRec;

		-- snarf version.  This is the version the receiver can process
		_, _, ver = string.find(payload, LOOTSTER_SYNC_IMP_SYNCRAID);

		-- validate
		if (ver == nil) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is less than our base, make sure we let them know its incompatible
		if (ver < LOOTSTER_SYNC_VERSION_BASE) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADVERSION, Lootster_SyncTitle, player, ver, LOOTSTER_SYNC_VERSION),
															  true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end
		
		-- if this version is greater than ours, make sure we downgrade it
		if (ver > LOOTSTER_SYNC_VERSION) then
			ver = LOOTSTER_SYNC_VERSION;
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- raid record starts at two for the id and running records
		recCount = 2;

		-- add up raid records
		for raidId, raidRec in pairs(Lootster_Raid) do
			recCount = recCount + 1;
		end

		-- add up boss records
		for bossId, bossRec in pairs(Lootster_Boss) do
			recCount = recCount + 1;
		end

		-- add up attendance records
		for attendId, attendRec in pairs(Lootster_Attend) do
			recCount = recCount + 1;
		end

		-- add up adjustment records
		for adjustId, adjustRec in pairs(Lootster_Adjust) do
			recCount = recCount + 1;
		end

		-- add up assignment records
		for assignId, assignRec in pairs(Lootster_Assign) do
			recCount = recCount + 1;
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- begin transaction
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_BEGIN, ver, recCount), true);

		-- transmit the id
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ID, Lootster_Id), true);

		-- transmit all raids
		for raidId, raidRec in pairs(Lootster_Raid) do
			-- send this raid raid
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_RAID, raidId, Lootster_EncodeText(Lootster_Serialise(raidRec))), true);
		end
	
		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- transmit all bosse
		for bossId, bossRec in pairs(Lootster_Boss) do
			-- send this raid boss
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_BOSS, bossId, Lootster_EncodeText(Lootster_Serialise(bossRec))), true);
		end	
	
		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- transmit all attendances
		for attendId, attendRec in pairs(Lootster_Attend) do
			-- send this raid attend
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ATTEND, attendId, Lootster_EncodeText(Lootster_Serialise(attendRec))), true);
		end
	
		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- transmit all adjustments
		for adjustId, adjustRec in pairs(Lootster_Adjust) do
			-- send this raid adjust
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ADJUST, adjustId, Lootster_EncodeText(Lootster_Serialise(adjustRec))), true);
		end

		-- transmit all assignments
		for assignId, assignRec in pairs(Lootster_Assign) do
			-- send this raid adjust
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ASSIGN, assignId, Lootster_EncodeText(Lootster_Serialise(assignRec))), true);
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- send the running data
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_RUNNING, tostring(Lootster_Running.RaidId), tostring(Lootster_Running.BossId)), true);

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- commit transaction
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_COMMIT, ver), true);
	elseif	(msg == LOOTSTER_SYNC_CMD_SYNCITEM) then
		local	_, ver, recCount, itemId, itemRec;

		-- snarf version.  This is the version the receiver can process
		_, _, ver = string.find(payload, LOOTSTER_SYNC_IMP_SYNCITEM);

		-- validate
		if (ver == nil) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is less than our base, make sure we let them know its incompatible
		if (ver < LOOTSTER_SYNC_VERSION_BASE) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADVERSION, Lootster_SyncTitle, player, ver, LOOTSTER_SYNC_VERSION),
															  true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end
		
		-- if this version is greater than ours, make sure we downgrade it
		if (ver > LOOTSTER_SYNC_VERSION) then
			ver = LOOTSTER_SYNC_VERSION;
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- calculate record count
		recCount = 0;

		for itemId, itemRec in pairs(Lootster_Restrict) do
			recCount = recCount + 1;
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- begin transaction
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_BEGIN, ver, recCount), true);

		-- transmit all items
		for itemId, itemRec in pairs(Lootster_Restrict) do
			-- send this item
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ITEM, itemId, Lootster_EncodeText(Lootster_Serialise(itemRec))), true);
		end

		-- send synchronous ack to keep other end alive
		Lootster_SendPrivate(player, LOOTSTER_SYNC_EXP_ACK, true, true);

		-- commit transaction
		Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_COMMIT, ver), true);	
	elseif	(msg == LOOTSTER_SYNC_CMD_ABORT) then
		local	count, ix, msgRec;
		local	toWhisperQue;

		-- get queue count so we can process in reverse order
		if (Lootster_ToWhisperQue ~= nil) then
			count = #Lootster_ToWhisperQue;
		else
			count = 0;
		end

		-- hammer through message queue looking for messages for the player
		for ix=count, 1, -1 do
			-- is this record for our player?
			if (Lootster_ToWhisperQue[ix].To == player) then
				-- is this one of our outbound messages?
				if (string.find(Lootster_ToWhisperQue[ix].Msg, LOOTSTER_SYNC_IMP_PREFIX) ~= nil) then
					-- yup, so toast
					table.remove(Lootster_ToWhisperQue, ix);
				end
			end				
		end

		-- copy whisper items as we need to requeue them so their delivery time is recalculated
		toWhisperQue = Lootster_CopyRecord(Lootster_ToWhisperQue);

		-- smoke the whisper queue so its recreated from scratch
		Lootster_ToWhisperQue = nil;

		-- hammer through the whisper queue copy and reenqueue items
		for ix, msgRec in ipairs(toWhisperQue) do
			-- renqueue this guy
			Lootster_ToWhisper_Enqueue(msgRec.To, msgRec.Msg);
		end
	elseif	(Lootster_SyncType == nil) then
		-- eep!  No synchronise in progress - no message as it can spam
		return false;
	elseif	(Lootster_SyncUser ~= player) then
		-- eep!  Player is not our synchronise target - no message as it can spam
		return false;
	elseif	(msg == LOOTSTER_SYNC_CMD_ACK) then
		-- this is a keep alive message so that we reset the timeout counter
		Lootster_SyncAcks = Lootster_SyncAcks + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_BEGIN) then
		local	_, ver, recCount;

		-- parse the payload
		_, _, ver, recCount = string.find(payload, LOOTSTER_SYNC_IMP_BEGIN);

		-- validate
		if ((ver == nil) or (recCount == nil)) then
			-- eep!  Unknown data format
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- convert version to a number
		ver = tonumber(ver);

		-- if this version is greater than ours, make sure we let them know its incompatible
		if (ver > LOOTSTER_SYNC_VERSION) then
			-- eep!  We cannot handle record types of this version - bail
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADVERSION, Lootster_SyncTitle, player, ver, LOOTSTER_SYNC_VERSION),
															  true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		else			
			ver = LOOTSTER_SYNC_VERSION;
		end

		-- convert record count to a number
		recCount = tonumber(recCount);

		-- reset record counters
		Lootster_SyncCount = 0;
		Lootster_SyncTotal = recCount;

		-- reset synchronise data
		Lootster_SyncData = {};

		-- setup this sync type
		Lootster_SyncData[Lootster_SyncType] = {};
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_COMMIT) then
		-- validate hash totals
		if (Lootster_SyncCount ~= Lootster_SyncTotal) then
			-- bad hash total
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADHASHTOTAL, Lootster_SyncTitle, Lootster_SyncCount,
															  Lootster_SyncTotal), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- normal operation
		Lootster_Sync_StateUpdate();

		-- commit the data
		if		(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCLOOT) then
			local	update, lootId, lootRec;

			-- retrieve the update flag
			update = (Lootster_LootSyncFrameOverwrite:GetChecked() ~= nil);

			-- do we have any items?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_LOOT] ~= nil) then
				-- smoosh in each item
				for lootId, lootRec in pairs(Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_LOOT]) do
					-- do we have this loot, and if so, is it official or privisory?
					if		(Lootster_ItemDKP[lootId] == nil) then
						-- this is a new guy, so wire up into our loot table
						Lootster_Loot[lootId] = itemRec;

						-- and point item DKP to that entry
						Lootster_ItemDKP[lootId] = Lootster_Loot[lootId];
					elseif	((Lootster_ItemDKP[lootId].DKP ~= nil) and (update == true)) then
						-- this is official loot, so just update the DKP override
						Lootster_ItemDKP[lootId].DKPMan = itemRec.DKPMan;
					elseif	(update == true) then
						-- this is provisory loot, so update all values
						Lootster_Loot[lootId] = itemRec;

						-- and point item DKP to that entry
						Lootster_ItemDKP[lootId] = Lootster_Loot[lootId];
					end
				end
			end

			-- resnarf any existing hyperlink
			Lootster_SetHyperlink(Lootster_ItemLink);

			-- let ourselves know
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCHRONISEDLOOT, player, Lootster_SyncTotal), true);
		elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCRAID) then
			-- delete all raids
			Lootster_DeleteAllRaid(true);

			-- set id data
			Lootster_Id = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ID];

			-- do we have any raids?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_RAID] ~= nil) then
				-- set raid data
				Lootster_Raid = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_RAID];
			end

			-- do we have any bosses?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_BOSS] ~= nil) then
				-- set boss data
				Lootster_Boss = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_BOSS];
			end

			-- do we have any attendances?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ATTEND] ~= nil) then
				-- set attendance data
				Lootster_Attend = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ATTEND];
			end

			-- do we have any adjustments?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ADJUST] ~= nil) then
				-- set adjustment data
				Lootster_Adjust = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ADJUST];
			end

			-- do we have any assignments?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ASSIGN] ~= nil) then
				-- set assignment data
				Lootster_Assign = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ASSIGN];
			end

			-- set running data
			Lootster_Running = Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_RUNNING];

			-- resort data DKP using current sort
			Lootster_Data_DKP_Sort(nil);

			-- resort data attend using current sort
			Lootster_Data_Attend_Sort(nil);

			-- resort data adjust using current sort
			Lootster_Data_Adjust_Sort(nil);

			-- resort raid raid using current sort
			Lootster_Raid_Raid_Sort(nil);

			-- resort raid boss using current sort
			Lootster_Raid_Boss_Sort(nil);

			-- resort raid attend using current sort
			Lootster_Raid_Attend_Sort(nil);

			-- resort raid adjust using current sort
			Lootster_Raid_Adjust_Sort(nil);

			-- resort raid assign using current sort
			Lootster_Raid_Assign_Sort(nil);

			-- could our DKP change?
			if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
				-- update our roll text
				Lootster_UpdateRoll();
			end

			-- update the raid UI
			Lootster_UpdateRaidUI();

			-- let them know
			Lootster_SendBroadcast(string.format(LOOTSTER_MSG_SYNCHRONISEDRAID, player, Lootster_SyncTotal));
		elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCITEM) then
			local	update, itemId, itemRec;

			-- retrieve the update flag
			update = (Lootster_ItemSyncFrameOverwrite:GetChecked() ~= nil);

			-- do we have any items?
			if (Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ITEM] ~= nil) then
				-- smoosh in each item
				for itemId, itemRec in pairs(Lootster_SyncData[Lootster_SyncType][LOOTSTER_SYNC_CMD_ITEM]) do
					-- unknown guy or we are supposed to update?
					if ((Lootster_Restrict[itemId] == nil) or (update == true)) then
						-- hammer it in
						Lootster_Restrict[itemId] = itemRec;
					end
				end
			end

			-- resnarf any existing hyperlink
			Lootster_SetHyperlink(Lootster_ItemLink);

			-- resort item
			Lootster_Item_Sort(nil);

			-- update the UI
			Lootster_UpdateRollUI();

			-- let ourselves know
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCHRONISEDITEM, player, Lootster_SyncTotal), true);
		end

		-- successful operation
		Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_SUCCESS);
	elseif	(msg == LOOTSTER_SYNC_CMD_LOOT) then
		local	_, lootId, lootRec, lootRecFn;

		-- parse the payload
		_, _, lootId, lootRec = string.find(payload, LOOTSTER_SYNC_IMP_LOOT);

		-- deserialise loot record
		lootRecFn = Lootster_Deserialise(Lootster_DecodeText(lootRec));
		
		-- validate
		if ((lootId == nil) or (lootRec == nil) or (lootRecFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- do we have a loot table yet?
		if (Lootster_SyncData[Lootster_SyncType][msg] == nil) then
			Lootster_SyncData[Lootster_SyncType][msg] = {};
		end

		-- create item record
		Lootster_SyncData[Lootster_SyncType][msg][lootId] = lootRecFn();

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_ID) then
		local	_, id;

		-- parse the payload
		_, _, id = string.find(payload, LOOTSTER_SYNC_IMP_ID);

		-- validate
		if (id == nil) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- convert id to a number
		id = tonumber(id);

		-- create id record
		Lootster_SyncData[Lootster_SyncType][msg] = id;

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_RAID) then
		local	_, raidId, raidRec, raidRecFn;

		-- parse the payload
		_, _, raidId, raidRec = string.find(payload, LOOTSTER_SYNC_IMP_RAID);

		-- deserialise raid record
		raidRecFn = Lootster_Deserialise(Lootster_DecodeText(raidRec));
		
		-- validate
		if ((raidId == nil) or (raidRec == nil) or (raidRecFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- do we have a raid table yet?
		if (Lootster_SyncData[Lootster_SyncType][msg] == nil) then
			Lootster_SyncData[Lootster_SyncType][msg] = {};
		end

		-- create raid record
		Lootster_SyncData[Lootster_SyncType][msg][raidId] = raidRecFn();

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_BOSS) then
		local	_, bossId, bossRec, bossRecFn;

		-- parse the payload
		_, _, bossId, bossRec = string.find(payload, LOOTSTER_SYNC_IMP_BOSS);

		-- deserialise boss record
		bossRecFn = Lootster_Deserialise(Lootster_DecodeText(bossRec));
		
		-- validate
		if ((bossId == nil) or (bossRec == nil) or (bossRecFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- do we have a boss table yet?
		if (Lootster_SyncData[Lootster_SyncType][msg] == nil) then
			Lootster_SyncData[Lootster_SyncType][msg] = {};
		end

		-- create boss record
		Lootster_SyncData[Lootster_SyncType][msg][bossId] = bossRecFn();

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_ATTEND) then
		local	_, attendId, attendRec, attendRecFn;

		-- parse the payload
		_, _, attendId, attendRec = string.find(payload, LOOTSTER_SYNC_IMP_ATTEND);

		-- deserialise attendance record
		attendRecFn = Lootster_Deserialise(Lootster_DecodeText(attendRec));
		
		-- validate
		if ((attendId == nil) or (attendRec == nil) or (attendRecFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- do we have a attendance table yet?
		if (Lootster_SyncData[Lootster_SyncType][msg] == nil) then
			Lootster_SyncData[Lootster_SyncType][msg] = {};
		end

		-- create attendance record
		Lootster_SyncData[Lootster_SyncType][msg][attendId] = attendRecFn();

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_ADJUST) then
		local	_, adjustId, adjustRec, adjustRecFn;

		-- parse the payload
		_, _, adjustId, adjustRec = string.find(payload, LOOTSTER_SYNC_IMP_ADJUST);

		-- deserialise adjustment record
		adjustRecFn = Lootster_Deserialise(Lootster_DecodeText(adjustRec));
		
		-- validate
		if ((adjustId == nil) or (adjustRec == nil) or (adjustRecFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- do we have a adjustment table yet?
		if (Lootster_SyncData[Lootster_SyncType][msg] == nil) then
			Lootster_SyncData[Lootster_SyncType][msg] = {};
		end

		-- create adjustment record
		Lootster_SyncData[Lootster_SyncType][msg][adjustId] = adjustRecFn();

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_RUNNING) then
		local	_, raidId, bossId;

		-- parse the payload
		_, _, raidId, bossId = string.find(payload, LOOTSTER_SYNC_IMP_RUNNING);

		-- translate special data
		if (raidId == "nil") then
			raidId = nil;
		end

		-- translate special data
		if (bossId == "nil") then
			bossId = nil;
		end

		-- convert raid id to a number
		raidId = tonumber(raidId);

		-- convert boss id to a number
		bossId = tonumber(bossId);

		-- create running record
		Lootster_SyncData[Lootster_SyncType][msg] = { RaidId=raidId, BossId=bossId };

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	elseif	(msg == LOOTSTER_SYNC_CMD_ITEM) then
		local	_, itemId, itemRec, itemRecFn;

		-- parse the payload
		_, _, itemId, itemRec = string.find(payload, LOOTSTER_SYNC_IMP_ITEM);

		-- deserialise item record
		itemRecFn = Lootster_Deserialise(Lootster_DecodeText(itemRec));

		-- validate
		if ((itemId == nil) or (itemRec == nil) or (itemRecFn == nil)) then
			-- eep!  Unknown data format - abort
			Lootster_SendPrivate(Lootster_Self, string.format(LOOTSTER_MSG_SYNCBADRECORD, Lootster_SyncTitle, msg, payload), true);

			-- abort synchronise
			Lootster_SendPrivate(player, string.format(LOOTSTER_SYNC_EXP_ABORT), true, true);

			-- failed operation
			Lootster_Sync_StateUpdate(LOOTSTER_SYNC_STATE_FAILED);
			return false;
		end

		-- convert item id to a number
		itemId = tonumber(itemId);

		-- do we have a item table yet?
		if (Lootster_SyncData[Lootster_SyncType][msg] == nil) then
			Lootster_SyncData[Lootster_SyncType][msg] = {};
		end

		-- create item record
		Lootster_SyncData[Lootster_SyncType][msg][itemId] = itemRecFn();

		-- bump record count
		Lootster_SyncCount = Lootster_SyncCount + 1;
		
		-- normal operation
		Lootster_Sync_StateUpdate();
	else
		-- unknown sync - ignore
		return false;
	end
	
	return true;
end

-- Synchronise State Update handler
function Lootster_Sync_StateUpdate(terminal)
	-- update synchronise UIs
	if		(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCLOOT) then
		-- update the loot sychronise UI
		Lootster_UpdateLootSyncUI(terminal);
	elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCITEM) then
		-- update the item sychronise UI
		Lootster_UpdateItemSyncUI(terminal);
	elseif	(Lootster_SyncType == LOOTSTER_SYNC_CMD_SYNCRAID) then
		-- update the raid sychronise UI
		Lootster_UpdateRaidSyncUI(terminal);
	end
	
	-- do we have a terminal state?
	if (terminal ~= nil) then		
		-- wack sync user, type and data
		Lootster_SyncUser = nil;
		Lootster_SyncType = nil;
		Lootster_SyncData = {};
		Lootster_SyncAcks = 0;
		Lootster_SyncTitle = "";
		Lootster_SyncCount = 0;
		Lootster_SyncTotal = 0;

		-- reset timeout
		Lootster_Timer.NextSyncTimeoutTime = 0;
	else
		-- not terminal, so maintain timeouts
		Lootster_Timer.LastSyncTimeoutTime = time();	
		Lootster_Timer.NextSyncTimeoutTime = Lootster_Timer.LastSyncTimeoutTime + LOOTSTER_SYNC_TIMEOUT;	
	end		
end

-- Write Detailed Text Report handler
function Lootster_WriteReportDetail(mask, args)
	-- dispatch to requisite report writer depending on mask
	if		(bit.band(mask, LOOTSTER_MASK_REPORTTYPE.FULL) ~= 0) then	
		-- write detailed full report
		return Lootster_WriteReportFull(false, args);
	elseif	(bit.band(mask, LOOTSTER_MASK_REPORTTYPE.RAID) ~= 0) then	
		-- write detailed raid report
		return Lootster_WriteReportRaid(nil, false, args);
	elseif	(bit.band(mask, LOOTSTER_MASK_REPORTTYPE.BOSS) ~= 0) then	
		-- write detailed boss report
		return Lootster_WriteReportBoss(nil, args);
	else
		-- no report
		return "";
	end
end

-- Write Consolidated Text Report handler
function Lootster_WriteReportConsolidate(mask, args)
	-- dispatch to requisite report writer depending on mask
	if		(bit.band(mask, LOOTSTER_MASK_REPORTTYPE.FULL) ~= 0) then	
		-- write consolidated full report 
		return Lootster_WriteReportFull(true, args);
	elseif	(bit.band(mask, LOOTSTER_MASK_REPORTTYPE.RAID) ~= 0) then	
		-- write consolidated raid report
		return Lootster_WriteReportRaid(nil, true, args);
	else
		-- no report
		return "";
	end
end

-- Write Full Report handler
function Lootster_WriteReportFull(consolidated, args)
	local	txtSumm = "";
	local	txtRaid = "";
	local	raidSort, raidId, raidRec, raidIx;
	local	adjusts = 0;
	local	totalEarnt = 0;
	local	totalSpent = 0;
	
	-- produce the full summary
	txtSumm = txtSumm..string.format(LOOTSTER_REPORT_SUMMARY);
	txtSumm = txtSumm..string.format(LOOTSTER_REPORT_RAIDS, #Lootster_RaidSort);
	txtSumm = txtSumm..string.format(LOOTSTER_REPORT_BOSSES, #Lootster_BossSort);
	
	-- sort the raid raid
	raidSort = Lootster_RaidReport_Raid_Sort();
		
	-- dump every raid and gather count of adjustments and total DKP
	for raidIx, raidId in ipairs(raidSort) do
		-- break
		txtRaid = txtRaid..LOOTSTER_REPORT_BREAK;

		-- get the raid report for this guy
		txtRaid = txtRaid..Lootster_WriteReportRaid(raidId, consolidated, args);

		-- add in adjustments
		adjusts = adjusts + Lootster_Raid[raidId].AdjustN;

		-- add in DKP
		totalEarnt = totalEarnt + Lootster_SumDKPEarntUpdate(Lootster_Raid[raidId]);
		totalSpent = totalSpent - Lootster_SumDKPSpentUpdate(Lootster_Raid[raidId]);
	end

	txtSumm = txtSumm..string.format(LOOTSTER_REPORT_ADJUSTS, adjusts);

	-- dump DKP in DKP roll mode only
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			txtSumm = txtSumm..string.format(LOOTSTER_REPORT_TOTALEPGP, totalEarnt, totalSpent);
		else
			txtSumm = txtSumm..string.format(LOOTSTER_REPORT_TOTALDKP, totalEarnt, totalSpent);
		end
	end

	-- smoosh report
	return txtSumm..txtRaid;
end

-- Write Raid Report handler
function Lootster_WriteReportRaid(raidId, consolidated, args)
	local	txtRaid = "";
	local	txtBoss = "";
	local	bossSort, bossId, bossRec, bossIx;
	
	-- a specfic raid?
	if (raidId == nil) then
		-- no raid selected we are done
		if (Lootster_RaidId == nil) then
			return txtRaid;
		end

		-- use current raid
		raidId = Lootster_RaidId;
	end
	
	-- format raid summary
	txtRaid = txtRaid..Lootster_FormatReportRaid(Lootster_Raid[raidId]);
	
	-- are we reporting consolidated bosses and we have some?
	if ((consolidated == true) and (Lootster_Raid[raidId].BossN > 0)) then	
		-- break
		txtBoss = txtBoss..LOOTSTER_REPORT_BREAK;
	
		-- dump all bosses as one
		txtBoss = txtBoss..Lootster_WriteReportConsolidateBoss(raidId, args);
	else
		-- sort the raid boss
		bossSort = Lootster_RaidReport_Boss_Sort(raidId);
		
		-- dump every boss
		for bossIx, bossId in ipairs(bossSort) do
			-- break
			txtBoss = txtBoss..LOOTSTER_REPORT_BREAK;
	
			-- get the boss report for this guy
			txtBoss = txtBoss..Lootster_WriteReportBoss(bossId, args);
		end
	end

	-- smoosh report
	return txtRaid..txtBoss;	
end

-- Write Boss Report handler
function Lootster_WriteReportBoss(bossId, args)
	local	txtBoss = "";
	local	txtAttend = "";
	local	txtAdjust = "";
	local	attendSort, attendId, attendIx;
	local	adjustSort, adjustId, adjustRec, adjustIx;
	
	-- a specfic boss?
	if (bossId == nil) then
		-- no boss selected we are done
		if (Lootster_BossId == nil) then
			return txtBoss;
		end

		-- use current boss
		bossId = Lootster_BossId;
	end
	
	-- produce boss summary
	txtBoss = txtBoss..Lootster_FormatReportBoss(Lootster_Boss[bossId]);
	
	-- are we reporting attendance?
	if (Lootster_Options.RepAttend == true) then
		-- sort the raid attend
		attendSort = Lootster_RaidReport_Attend_Sort(bossId);
				
		-- dump every attendance
		txtAttend = txtAttend..LOOTSTER_REPORT_BREAK;
		txtAttend = txtAttend..string.format(LOOTSTER_REPORT_ATTEND);
		
		for attendIx, attendId in ipairs(attendSort) do
			-- get the attendance report for this guy
			txtAttend = txtAttend..Lootster_FormatReportAttend(Lootster_Attend[attendId]);
		end
	end

	-- are we reporting adjustment?
	if (Lootster_Options.RepAdjust == true) then	
		-- sort the raid adjust
		adjustSort = Lootster_RaidReport_Adjust_Sort(bossId);
						
		-- dump every adjustment
		txtAdjust = txtAdjust..LOOTSTER_REPORT_BREAK;
		txtAdjust = txtAdjust..string.format(LOOTSTER_REPORT_ADJUST);
	
		for adjustIx, adjustId in ipairs(adjustSort) do
			-- get the adjustment report for this guy
			txtAdjust = txtAdjust..Lootster_FormatReportAdjust(Lootster_Adjust[adjustId]);
		end
	end
	
	-- smoosh report
	return txtBoss..txtAttend..txtAdjust;
end

-- Write Consolidated Boss Report handler
function Lootster_WriteReportConsolidateBoss(raidId, args)
	local	txtBoss = "";
	local	txtAttend = "";
	local	txtAdjust = "";
	local	dateBeg = nil;
	local	dateEnd = nil;
	local	bigBossRec, bossSort, bossId, bossRec, bossIx;
	local	attendTempSort, attendConsSort, player, attendIx, attendId;
	local	adjustConsSort, adjustIx, adjustId;
	
	-- we raidId a raid and it's got bosses?
	if ((raidId == nil) or (Lootster_Raid[raidId].BossN == 0)) then
		-- no raid or bosses so we are done
		return txtBoss;
	end

	-- sort the raid adjust
	bossSort = Lootster_RaidReport_Boss_Sort(raidId);

	-- determine lowest begin date and highest finish date
	for bossIx, bossId in ipairs(bossSort) do
		-- do we have a begin date yet or this is lower than current?
		if ((dateBeg == nil) or (Lootster_Boss[bossSort[bossIx]].DateBeg < dateBeg)) then
			dateBeg = Lootster_Boss[bossSort[bossIx]].DateBeg;
		end
	
		-- do we have a finish date yet or this is higher than current?
		if ((Lootster_Boss[bossSort[bossIx]].DateEnd ~= nil) and ((dateEnd == nil) or (Lootster_Boss[bossSort[bossIx]].DateEnd > dateEnd))) then
			dateEnd = Lootster_Boss[bossSort[bossIx]].DateEnd;
		end
	end
	
	-- create a boss record as the master for the raid
	bigBossRec = Lootster_NewBoss(Lootster_Raid[raidId].Zone, Lootster_CalcServerTime(dateBeg));

	-- use last boss's end time
	bigBossRec.DateEnd = dateEnd;

	-- reset consolidated attendance set and count
	attendConsSort = {};

	-- get temporary consolidated attendances for the raid
	attendTempSort = Lootster_RaidReport_ConsolidateAttend_Sort(bossSort);

	-- smoosh all attendances together into the consolidated set
	for attendIx, attendId in ipairs(attendTempSort) do
		-- get this player
		player = Lootster_Attend[attendId].Player;

		-- is this player already in attendance?
		if		(bigBossRec.AttendSet[player] == nil) then
			-- transfer
			bigBossRec.AttendSet[player] = Lootster_CopyRecord(Lootster_Attend[attendId]);
			
			-- and bookkeep in order
			table.insert(attendConsSort, player);
		else
			-- same attendance?
			if	(bigBossRec.AttendSet[player].Attended ~= Lootster_Attend[attendId].Attended) then
				-- no matter which way you cut it they are partial now
				bigBossRec.AttendSet[player].Attended = LOOTSTER_ENUM_ATTENDED.PARTIAL;
			end
			
			-- accumulate the attendance DKP
			bigBossRec.AttendSet[player].DKPAttEarnt = bigBossRec.AttendSet[player].DKPAttEarnt + Lootster_Attend[attendId].DKPAttEarnt;			
		end			
	end

	-- set count of attendances
	bigBossRec.AttendN = #attendConsSort;
	
	-- get consolidated adjustments for the raid
	adjustConsSort = Lootster_RaidReport_ConsolidateAdjust_Sort(bossSort);

	-- set count of adjustments
	bigBossRec.AdjustN = #adjustConsSort;

	-- accumulate total DKP
	for bossIx, bossId in ipairs(bossSort) do
		bigBossRec.DKPAdjEarnt = bigBossRec.DKPAdjEarnt + Lootster_Boss[bossSort[bossIx]].DKPAdjEarnt;
		bigBossRec.DKPAdjSpent = bigBossRec.DKPAdjSpent + Lootster_Boss[bossSort[bossIx]].DKPAdjSpent;
	end

	-- produce boss summary
	txtBoss = txtBoss..Lootster_FormatReportBoss(bigBossRec);

	-- are we reporting attendances?
	if (Lootster_Options.RepAttend == true) then
		-- dump every attendance
		txtAttend = txtAttend..LOOTSTER_REPORT_BREAK;
		txtAttend = txtAttend..string.format(LOOTSTER_REPORT_ATTEND);
		
		for attendIx, player in ipairs(attendConsSort) do
			-- get the attendance report for this guy
			txtAttend = txtAttend..Lootster_FormatReportAttend(bigBossRec.AttendSet[player]);
		end
	end

	-- are we reporting adjustment?
	if (Lootster_Options.RepAdjust == true) then	
		-- dump every adjustment
		txtAdjust = txtAdjust..LOOTSTER_REPORT_BREAK;
		txtAdjust = txtAdjust..string.format(LOOTSTER_REPORT_ADJUST);
	
		for adjustIx, adjustId in ipairs(adjustConsSort) do
			-- get the adjustment report for this guy
			txtAdjust = txtAdjust..Lootster_FormatReportAdjust(Lootster_Adjust[adjustId]);
		end
	end
	
	-- smoosh report
	return txtBoss..txtAttend..txtAdjust;
end

-- Format Raid Report handler
function Lootster_FormatReportRaid(raidRec)
	local	txtRaid = "";
	local	txtBoss = "";
	local	wowId, dateExp;
	
	-- a raid record?
	if (raidRec == nil) then
		-- no raid record so we are done
		return txtRaid;
	end
	
	-- get the WowId, if any
	if (raidRec.WoWId ~= nil) then
		wowId = raidRec.WoWId;
	else
		wowId = LOOTSTER_RAIDRAID_NOWOWID;
	end
	
	-- get the expiry time, if any
	if (raidRec.DateExp ~= nil) then
        dateExp = Lootster_FormatServerTime(raidRec.DateExp);
	else
		dateExp = LOOTSTER_RAIDRAID_NODATEEXP;
	end
	
	-- produce raid summary
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_RAID, raidRec.Zone);
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_TYPE, LOOTSTER_RAIDTYPE_LIST_REP[raidRec.Type]);
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_DATEOPN, Lootster_FormatServerTime(raidRec.DateOpn));
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_DATEEXP, dateExp, wowId);
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_BOSSES, raidRec.BossN);
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_ATTENDS, raidRec.AttendN);
	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_ADJUSTS, raidRec.AdjustN);

	-- dump DKP in DKP roll mode only
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			txtRaid = txtRaid..string.format(LOOTSTER_REPORT_TOTALEPGP, Lootster_SumDKPEarntUpdate(raidRec), Lootster_SumDKPSpentUpdate(raidRec));
		else
			txtRaid = txtRaid..string.format(LOOTSTER_REPORT_TOTALDKP, Lootster_SumDKPEarntUpdate(raidRec), Lootster_SumDKPSpentUpdate(raidRec));
		end
	end

	txtRaid = txtRaid..string.format(LOOTSTER_REPORT_COMMENT, Lootster_RemoveTrailingLineBreak(raidRec.Comment));
	
	-- return raid report
	return txtRaid..txtBoss;	
end

-- Format Boss Report handler
function Lootster_FormatReportBoss(bossRec)
	local	txtBoss = "";
	local	dateEnd;
	
	-- a boss record?
	if (bossRec == nil) then
		-- no boss record so we are done
		return txtBoss;
	end
	
	-- get the end time, if any
	if (bossRec.DateEnd ~= nil) then
        dateEnd = Lootster_FormatServerTime(bossRec.DateEnd);
	else
		dateEnd = LOOTSTER_RAIDBOSS_NODATEEND;
	end
	
	-- produce boss summary
	txtBoss = txtBoss..string.format(LOOTSTER_REPORT_BOSS, Lootster_FormatBoss(bossRec.Boss, bossRec.Attempt));
	txtBoss = txtBoss..string.format(LOOTSTER_REPORT_TYPE, LOOTSTER_BOSSTYPE_LIST_REP[bossRec.Type]);
	txtBoss = txtBoss..string.format(LOOTSTER_REPORT_DATEBEG, Lootster_FormatServerTime(bossRec.DateBeg));
	txtBoss = txtBoss..string.format(LOOTSTER_REPORT_DATEEND, dateEnd);
	txtBoss = txtBoss..string.format(LOOTSTER_REPORT_ATTENDS, bossRec.AttendN);
	txtBoss = txtBoss..string.format(LOOTSTER_REPORT_ADJUSTS, bossRec.AdjustN);

	-- dump DKP in DKP roll mode only
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		if		(Lootster_Options.DKPType == LOOTSTER_ENUM_DKP.BYEPGP) then
			txtRaid = txtBoss..string.format(LOOTSTER_REPORT_TOTALEPGP, Lootster_SumDKPEarntUpdate(bossRec), Lootster_SumDKPSpentUpdate(bossRec));
		else
			txtBoss = txtBoss..string.format(LOOTSTER_REPORT_TOTALDKP, Lootster_SumDKPEarntUpdate(bossRec), Lootster_SumDKPSpentUpdate(bossRec));
		end
	end

	-- return boss report
	return txtBoss;
end

-- Format Attendance Report handler
function Lootster_FormatReportAttend(attendRec)
	local	txtAttend = "";
	
	-- an attendance record?
	if (attendRec == nil) then
		-- no attendance record so we are done
		return txtAttend;
	end
	
	-- produce attendance record.  Dump DKP in DKP roll mode only
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		-- showing attendance details?
		if (Lootster_Options.RepAttendDetail == true) then
			txtAttend = txtAttend..string.format(LOOTSTER_REPORT_ATTENDANCEDKPDETAIL, attendRec.Player, attendRec.Alt, 
												 LOOTSTER_ATTENDED_LIST[attendRec.Attended], attendRec.DKPAttEarnt);
		else
			txtAttend = txtAttend..string.format(LOOTSTER_REPORT_ATTENDANCEDKPSIMPLE, attendRec.Player);
		end
	else
		-- showing attendance details?
		if (Lootster_Options.RepAttendDetail == true) then
			txtAttend = txtAttend..string.format(LOOTSTER_REPORT_ATTENDANCENODKPDETAIL, attendRec.Player, attendRec.Alt, 
												 LOOTSTER_ATTENDED_LIST[attendRec.Attended]);
		else
			txtAttend = txtAttend..string.format(LOOTSTER_REPORT_ATTENDANCENODKPSIMPLE, attendRec.Player);
		end
	end

	return txtAttend;
end

-- Format Adjustment Report handler
function Lootster_FormatReportAdjust(adjustRec)
	local	txtAdjust = "";
	local	itemId, itemText, itemQual;
	
	-- an adjustment record?
	if (adjustRec == nil) then
		-- no adjustment record so we are done
		return txtAdjust;
	end

	-- do we have a link?
	if (adjustRec.Link ~= nil) then
		-- get the item id
		itemId, itemText, itemQual = Lootster_GetItemBasics(adjustRec.Link);
	else
		itemId = nil;
	end

	-- produce adjustment record.  Dump DKP in DKP roll mode only
	if (Lootster_Options.RollMode == LOOTSTER_ENUM_ROLLMODE.USEDKP) then
		txtAdjust = txtAdjust..string.format(LOOTSTER_REPORT_ADJUSTMENTDKP, adjustRec.Player, adjustRec.Alt, Lootster_FormatServerTime(adjustRec.DateAdj),
											 adjustRec.DKPAdjEarnt, adjustRec.DKPAdjSpent, LOOTSTER_USAGEDKP_LIST_REP[adjustRec.Usage],
											 tostring(itemId), adjustRec.Reason, Lootster_RemoveTrailingLineBreak(adjustRec.Comment));
	else
		txtAdjust = txtAdjust..string.format(LOOTSTER_REPORT_ADJUSTMENTNODKP, adjustRec.Player, adjustRec.Alt, Lootster_FormatServerTime(adjustRec.DateAdj),
											 LOOTSTER_USAGENORM_LIST_REP[adjustRec.Usage], tostring(itemId), adjustRec.Reason, 
											 Lootster_RemoveTrailingLineBreak(adjustRec.Comment));
	end

	return txtAdjust;
end

-- EQDKP CT_RaidTracker Import Report handler
function Lootster_WriteReportCTRT(mask, args)
	local	EQDKP_DATE_FORMAT = "%m/%d/%y %H:%M:%S";
	
	local	txtXML = "";

	local	bossSort, bossId, bossRec, bossIx;
	local	attendTempSort, attendConsSet, attendConsSort, player, attendIx, attendId;
	local	adjustConsSort, adjustIx, adjustId, qual, id;
	
	-- no raid selected we are done
	if (Lootster_RaidId == nil) then
		return txtXML;
	end

	-- use current raid
	raidId = Lootster_RaidId;

	-- get the list of bosses, in end order
	bossSort = Lootster_RaidReport_Boss_Sort(raidId, "DateEnd", true);

	-- dump raid info
	txtXML = txtXML.."<RaidInfo>";

	-- dump identifying information
	txtXML = txtXML.."<Version>1.4</Version>";

	txtXML = txtXML.."<key>"..date(EQDKP_DATE_FORMAT, Lootster_Raid[raidId].DateOpn).."</key>";

	-- start and end dates.  Use last boss end; no bosses or no end means use expiry, no expiry use open
	txtXML = txtXML.."<start>"..date(EQDKP_DATE_FORMAT, Lootster_Raid[raidId].DateOpn).."</start>";

	if		((#bossSort > 0) and (Lootster_Boss[bossSort[#bossSort]].DateEnd ~= nil)) then
		txtXML = txtXML.."<end>"..date(EQDKP_DATE_FORMAT, Lootster_Boss[bossSort[#bossSort]].DateEnd).."</end>";
	elseif	(Lootster_Raid[raidId].DateExp ~= nil) then
		txtXML = txtXML.."<end>"..date(EQDKP_DATE_FORMAT, Lootster_Raid[raidId].DateExp).."</end>";
	else
		txtXML = txtXML.."<end>"..date(EQDKP_DATE_FORMAT, Lootster_Raid[raidId].DateOpn).."</end>";
	end

	-- zone and note
	txtXML = txtXML.."<zone>"..Lootster_Raid[raidId].Zone.."</zone>";

	txtXML = txtXML.."<note><![CDATA[";
	txtXML = txtXML..Lootster_Raid[raidId].Zone.." - ";
	
	if (Lootster_Raid[raidId].Comment ~= "\n") then
		txtXML = txtXML..Lootster_Raid[raidId].Comment;
	end
	
	txtXML = txtXML.."]]></note>";
	
	-- reset consolidated attendance set and count
	attendConsSet = {};
	attendConsSort = {};

	-- get the list of all attendances for all the bosses, in taken attendance order
	attendTempSort = Lootster_RaidReport_ConsolidateAttend_Sort(bossSort, "DateAtt", true);

	-- smoosh all attendances together into the consolidated set.  We determine a begin/end time for each
	for attendIx, attendId in ipairs(attendTempSort) do
		-- get this player
		player = Lootster_Attend[attendId].Player;

		-- is this player already in attendance?
		if		(attendConsSet[player] == nil) then
			-- transfer
			attendConsSet[player] = Lootster_CopyRecord(Lootster_Attend[attendId]);
			
			-- and bookkeep in order
			table.insert(attendConsSort, player);
			
			-- set the begin/end time from the boss
			attendConsSet[player].DateBeg = Lootster_Boss[attendConsSet[player].BossId].DateBeg;
			attendConsSet[player].DateEnd = Lootster_Boss[attendConsSet[player].BossId].DateEnd;
		else
			-- same attendance?
			if	(attendConsSet[player].Attended ~= Lootster_Attend[attendId].Attended) then
				-- no matter which way you cut it they are partial now
				attendConsSet[player].Attended = LOOTSTER_ENUM_ATTENDED.PARTIAL;
			end
			
			-- accumulate the attendance DKP
			attendConsSet[player].DKPAttEarnt = attendConsSet[player].DKPAttEarnt + Lootster_Attend[attendId].DKPAttEarnt;
			
			-- determine if the begin time was earlier		
			if (attendConsSet[player].DateBeg > Lootster_Boss[Lootster_Attend[attendId].BossId].DateBeg) then
				attendConsSet[player].DateBeg = Lootster_Boss[Lootster_Attend[attendId].BossId].DateBeg;
			end
			
			-- determine if the end time if we have one and it was later
			if ((Lootster_Boss[Lootster_Attend[attendId].BossId].DateEnd ~= nil) and ((attendConsSet[player].DateEnd == nil) or (attendConsSet[player].DateEnd < Lootster_Boss[Lootster_Attend[attendId].BossId].DateEnd))) then
				attendConsSet[player].DateEnd = Lootster_Boss[Lootster_Attend[attendId].BossId].DateEnd;
			end
		end
	end

	-- dump player info
	txtXML = txtXML.."<PlayerInfos>";
	
	for attendIx, player in ipairs(attendConsSort) do
		-- dump this player
		txtXML = txtXML.."<key"..attendIx..">";
		txtXML = txtXML.."<name>"..player.."</name>";
		txtXML = txtXML.."</key"..attendIx..">";
	end
	
	txtXML = txtXML.."</PlayerInfos>";

	-- dump boss kills
	txtXML = txtXML.."<BossKills>";
	
	for bossIx, bossId in ipairs(bossSort) do
		-- dump this boss
		txtXML = txtXML.."<key"..bossIx..">";
		
		-- add name
		txtXML = txtXML.."<name>"..Lootster_Boss[bossId].Boss.."</name>";
		
		-- use boss end time, or start time if none
		if (Lootster_Boss[bossId].DateEnd ~= nil) then
			txtXML = txtXML.."<time>"..date(EQDKP_DATE_FORMAT, Lootster_Boss[bossId].DateEnd).."</time>";
		else
			txtXML = txtXML.."<time>"..date(EQDKP_DATE_FORMAT, Lootster_Boss[bossId].DateBeg).."</time>";
		end
		
		-- dump the attendees of this fight
		txtXML = txtXML.."<attendees>";
		
		attendIx = 1;
		
		for player, attendId in pairs(Lootster_Boss[bossId].AttendSet) do
			txtXML = txtXML.."<key"..attendIx..">";
			txtXML = txtXML.."<name>"..player.."</name>";
			txtXML = txtXML.."</key"..attendIx..">";
			
			attendIx = attendIx + 1;
		end
		
		txtXML = txtXML.."</attendees>";
		
		txtXML = txtXML.."</key"..bossIx..">";
	end
	
	txtXML = txtXML.."</BossKills>";
	
	-- dump the players joining
	txtXML = txtXML.."<Join>";
	
	for attendIx, player in ipairs(attendConsSort) do
		-- dump this player
		txtXML = txtXML.."<key"..attendIx..">";
		
		txtXML = txtXML.."<player>"..player.."</player>";
		txtXML = txtXML.."<time>"..date(EQDKP_DATE_FORMAT, attendConsSet[player].DateBeg).."</time>";
		
		txtXML = txtXML.."</key"..attendIx..">";
	end

	txtXML = txtXML.."</Join>";
	
	-- dump the players leaving
	txtXML = txtXML.."<Leave>";
	
	for attendIx, player in ipairs(attendConsSort) do
		-- dump this player
		txtXML = txtXML.."<key"..attendIx..">";
		
		txtXML = txtXML.."<player>"..player.."</player>";
		
		if (attendConsSet[player].DateEnd ~= nil) then
			txtXML = txtXML.."<time>"..date(EQDKP_DATE_FORMAT, attendConsSet[player].DateEnd).."</time>";
		else
			txtXML = txtXML.."<time>"..date(EQDKP_DATE_FORMAT, attendConsSet[player].DateBeg).."</time>";
		end		
		
		txtXML = txtXML.."</key"..attendIx..">";
	end

	txtXML = txtXML.."</Leave>";
	
	-- get the list of all adjustments for all the bosses, in taken adjustment order
	adjustConsSort = Lootster_RaidReport_ConsolidateAdjust_Sort(bossSort, "DateAdj", true);

	-- dump loot info
	txtXML = txtXML.."<Loot>";

	for adjustIx, adjustId in ipairs(adjustConsSort) do
		-- dump this item
		txtXML = txtXML.."<key"..adjustIx..">";
		
		-- get the item colour and id, if any
		if (Lootster_Adjust[adjustId].Link ~= nil) then
			qual, id = string.match(Lootster_Adjust[adjustId].Link, LOOTSTER_ITEMFULLID_PATTERN);
		else
			qual = "";
			id = "";
		end
			
		-- dump name
		txtXML = txtXML.."<ItemName>"..Lootster_Adjust[adjustId].Reason.."</ItemName>";
		txtXML = txtXML.."<ItemID>"..id.."</ItemID>";
		txtXML = txtXML.."<Color>"..qual.."</Color>";
		txtXML = txtXML.."<Count>1</Count>";
		txtXML = txtXML.."<Player>"..Lootster_Adjust[adjustId].Player.."</Player>";
		txtXML = txtXML.."<Time>"..date(EQDKP_DATE_FORMAT, Lootster_Adjust[adjustId].DateAdj).."</Time>";
		txtXML = txtXML.."<Zone>"..Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Zone.."</Zone>";
		txtXML = txtXML.."<Boss>"..Lootster_Boss[Lootster_Adjust[adjustId].BossId].Boss.."</Boss>";
		txtXML = txtXML.."<Cost>"..Lootster_Adjust[adjustId].DKPAdjSpent.."</Cost>";
		
		-- format note
		txtXML = txtXML.."<Note><![CDATA[";
		txtXML = txtXML..Lootster_Adjust[adjustId].Comment;
		txtXML = txtXML.." - Zone: "..Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Zone;
		
		if		((Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.UNKNOWN) or
				 (Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.DUNGEONNORM) or
				 (Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.DUNGEONHERO)) then
			txtXML = txtXML.."Normal";
		elseif	((Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID10NORM) or
				 (Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID25NORM)) then
			txtXML = txtXML.."Heroic";
		elseif	((Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID10HERO) or
				 (Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.RAID25HERO) or
				 (Lootster_Raid[Lootster_Boss[Lootster_Adjust[adjustId].BossId].RaidId].Type == LOOTSTER_ENUM_RAIDTYPE.OUTDOOR)) then
			txtXML = txtXML.."Epic";
		end
		
		txtXML = txtXML.." - Boss: "..Lootster_Boss[Lootster_Adjust[adjustId].BossId].Boss;
		txtXML = txtXML.." - "..Lootster_Adjust[adjustId].DKPAdjSpent.." DKP";
		
		txtXML = txtXML.."]]></Note>";
		
		txtXML = txtXML.."</key"..adjustIx..">";
	end
	
	txtXML = txtXML.."</Loot>";
	
	txtXML = txtXML.."</RaidInfo>";

	return txtXML;
end

-- Lootster Popup handler
function Lootster_Popup_Show(frame)
	local	ix, name, dialog, OnCancel;
	
	-- if we don't have a frame we are just closing our dialogs
	if (frame == nil) then
		-- go through all static dialogs, closing exclusive ones
		for ix=1, STATICPOPUP_NUMDIALOGS do
			-- get this static dialog
			dialog = _G["StaticPopup"..ix];
			
			-- if this guy is exclusive and shown, hide him
			if ((dialog:IsShown() == true) and StaticPopupDialogs[dialog.which].exclusive) then
				-- hide this guy
				dialog:Hide();
				
				-- get the cancel function, if any
				OnCancel = StaticPopupDialogs[dialog.which].OnCancel;
				
				-- cancel function?
				if (OnCancel ~= nil) then
					-- spoof cancel
					OnCancel(dialog.data, "override");
				end
				
				-- done
				break;
			end
		end
	end

	-- hammer through list of dialogs making sure all are closed except passed guy
	for ix, dialog in ipairs(LOOTSTER_POPUP_FRAME) do
		-- hide it regardless if its the one we want 
		dialog:Hide();
	end

	-- if we have a frame show it
	if (frame ~= nil) then
		frame:Show();
	end
end

-- Lootster Static Popup Show handler
function Lootster_StaticPopup_Show(which)
	-- this is our own handler that allows us to close down our own dialogs before
	-- showing the static popup dialog
	Lootster_Popup_Show();

	-- and show static dialog
	return StaticPopup_Show(which);
end

-- Lootster Find handler
function Looster_Find(list, testVal)
	local	ix, listVal;
	
	for ix, listVal in ipairs(list) do
		if (listVal == testVal) then
			return ix;
		end
	end
	
	return 0;
end

-- Copy Record handler
function Lootster_CopyRecord(srcRec)
	local	desRec = {};
	local	key, val;

	-- hammer through record copying each value
	for key, val in pairs(srcRec) do
		-- if this is an embedded table, recurse copying it
		if (type(val) == "table") then
			-- copy the embedded table
			desRec[key] = Lootster_CopyRecord(val);
		else
			-- simply copy the value
			desRec[key] = val;
		end
	end

	return desRec;
end

-- Find Position handler
function Lootster_FindPosition(vector, key, val)
	local	six, eix, mix;
	
	-- if empty vector return first position
	if (#vector == 0) then
		return 1;
	end
	
	-- binary chop to locate the record
	six = 1;
	eix = #vector
	
	repeat
		-- calculate midpoint
		mix = math.floor((six + eix) / 2);

		-- hows this for an insertion point?
		if		(val < vector[mix][key]) then
			-- set new end boundary
			eix = mix - 1;
			
			if (eix < six) then
				-- before start so return start
				return six;
			end
		elseif	(val > vector[mix][key]) then
			-- set new start boundary
			six = mix + 1;
			
			if (six > eix) then
				-- past end so return past end
				return eix + 1;
			end
		else
			-- equal so insert before this guy
			return mix;
		end				
	until (false);
end

-- Get WoW Version in TOC Format
function Lootster_GetWoWVersion()
	local	versionWoW, versionTOC;
	local	_, major, minor, patch;

	-- retrieve WoW version
	versionWoW = GetBuildInfo();

	-- tease apart the version into components
	_, _, major, minor, patch = string.find(versionWoW, LOOTSTER_VERSION_WOW);

	-- ensure we are valid
	if ((major == nil) or (minor == nil) or (patch == nil)) then
		-- use default
		major = 0;
		minor = 0;
		patch = 0;
	else
		-- convert to numeric
		major = tonumber(major);
		minor = tonumber(minor);
		patch = tonumber(patch);
	end

	-- convert to TOC format
	versionTOC = string.format(LOOTSTER_VERSION_TOC, major, minor, patch);

	return tonumber(versionTOC);
end

-- Test WoW Version
function Lootster_IsWoWVersion(version)
	-- are we on a PTR or WoW's version is equal or higher than than the test?
	if ((Lootster_VersionWoW < 10000) or (Lootster_VersionWoW >= version)) then
		-- return the requisite update value in the options
		return (Lootster_Options["Updated"..version] == nil) or (Lootster_Options["Updated"..version] == false);
	else
		-- not our time
		return false;
	end
end

-- Set Date & Time handler
function Lootster_SetDateTime(frame, dateSet, callback)
	local	name, dateOut;
	
	-- get the frame name
	name = frame:GetName();
	
	-- make sure we have a date
	if (dateSet ~= nil) then	
		-- break the date into table form
		dateOut = date("*t", dateSet);

		-- and output
		_G[name.."Year"]:SetText(string.format("%04d", dateOut.year));
		_G[name.."Mon"]:SetText(string.format("%02d", dateOut.month));
		_G[name.."Day"]:SetText(string.format("%02d", dateOut.day));

		_G[name.."Hour"]:SetText(string.format("%02d", dateOut.hour));
		_G[name.."Min"]:SetText(string.format("%02d", dateOut.min));
		_G[name.."Sec"]:SetText(string.format("%02d", dateOut.sec));
	else
		-- output empty text
		_G[name.."Year"]:SetText("");
		_G[name.."Mon"]:SetText("");
		_G[name.."Day"]:SetText("");

		_G[name.."Hour"]:SetText("");
		_G[name.."Min"]:SetText("");
		_G[name.."Sec"]:SetText("");
	end

	-- were passed a callback?
	if (callback ~= nil) then
		-- hook the text entered callback, if any
		frame.TextEnteredCB = callback;
	end
end

-- Get Date & Time handler
function Lootster_GetDateTime(frame)
	local	name, dateInp, year, mon, day, hour, min, sec, dateOut;
	
	-- get the frame name
	name = frame:GetName();
	
	-- get the current date into table form
	dateInp = date("*t", Lootster_CalcServerTime(time()));

	-- and input
	year = tonumber(_G[name.."Year"]:GetText());
	mon = tonumber(_G[name.."Mon"]:GetText());
	day = tonumber(_G[name.."Day"]:GetText());
	
	hour = tonumber(_G[name.."Hour"]:GetText());
	min = tonumber(_G[name.."Min"]:GetText());
	sec = tonumber(_G[name.."Sec"]:GetText());

	-- if all input is nil, no date set
	if ((year == nil) and (mon == nil) and (day == nil) and (hour == nil) and (min == nil) and (sec == nil)) then
		return nil;
	end
	
	-- update the values that were input
	if (year ~= nil) then
		dateInp.year = year;
	end
	
	if (mon ~= nil) then
		dateInp.month = mon;
	end
	
	if (day ~= nil) then
		dateInp.day = day;
	end
	
	if (hour ~= nil) then
		dateInp.hour = hour;
	end
	
	if (min ~= nil) then
		dateInp.min = min;
	end
	
	if (sec ~= nil) then
		dateInp.sec = sec;
	end
	
	-- convert the date, and then rebreak the date into table form
	dateOut = date("*t", Lootster_CalcServerTime(time(dateInp)));
	
	-- transfer the DST flag back into the input
	dateInp.isdst = dateOut.isdst;
	
	-- and convert
	return time(dateInp);
end

-- Is Date & Time Partial handler
function Lootster_IsDateTimePartial(frame)
	local	name, year, mon, day, hour, min, sec, allT, allF;
	
	-- get the frame name
	name = frame:GetName();
	
	-- and input
	year = tonumber(_G[name.."Year"]:GetText());
	mon = tonumber(_G[name.."Mon"]:GetText());
	day = tonumber(_G[name.."Day"]:GetText());
	
	hour = tonumber(_G[name.."Hour"]:GetText());
	min = tonumber(_G[name.."Min"]:GetText());
	sec = tonumber(_G[name.."Sec"]:GetText());
	
	-- determine entered state
	allT = (year ~= nil) and (mon ~= nil) and (day ~= nil) and (hour ~= nil) and (min ~= nil) and (sec ~= nil);
	allF = (year == nil) and (mon == nil) and (day == nil) and (hour == nil) and (min == nil) and (sec == nil);
	
	-- can be one or the other
	return not (allT or allF), allT, allF;
end

-- Append Trailing New Line handler
function Lootster_AppendTrailingLineBreak(text)
	-- ensure that it has a trailing new line
	if (string.sub(text, -1, -1) ~= "\n") then
		text = text.."\n";
	end

	return text;
end

-- Remove Trailing New Line handler
function Lootster_RemoveTrailingLineBreak(text)
	-- ensure that it has a trailing new line
	if (string.sub(text, -1) == "\n") then
		text = string.sub(text, 1, -2);
	end

	return text;
end

-- Serialise Data handler
function Lootster_Serialise(data)
	-- determine data type
	if		(type(data) == "table") then
		local	res, key, val;
		
		-- no result yet
		res = {};
		
		-- dump each key
		for key, val in pairs(data) do
			-- even if numeric dump the key to handle sparse tables
			table.insert(res, "["..Lootster_Serialise(key).."]="..Lootster_Serialise(val));
		end
		
		-- return concatenation of table
		return "{"..table.concat(res, ",").."}";
	elseif	(type(data) == "string") then
		-- always quote strings
		return string.format("%q", data);
	else
		-- use native string
		return tostring(data);
	end
end

-- Deserialise Data handler
function Lootster_Deserialise(data)
	-- simply use loadstring
	return loadstring("return "..data);
end

-- Encode Text handler
function Lootster_EncodeText(text)
	-- encode or-bar characters
	text = string.gsub(text, LOOTSTER_ENC_ORBAR_RAW, LOOTSTER_ENC_ORBAR_ENC);

	-- encode encode characters
	text = string.gsub(text, LOOTSTER_ENC_MARKER_RAW, LOOTSTER_ENC_MARKER_ENC);

	-- encode new lines
	text = string.gsub(text, LOOTSTER_ENC_NEWLINE_RAW, LOOTSTER_ENC_NEWLINE_ENC);

	-- encode quote+slash
	text = string.gsub(text, LOOTSTER_ENC_QUOTESLASH_RAW, LOOTSTER_ENC_QUOTESLASH_ENC);

	return text;
end

-- Decode Text handler
function Lootster_DecodeText(text)
	-- decode escapes
	text = string.gsub(text, LOOTSTER_ENC_SLASHSLASH_ENC, LOOTSTER_ENC_SLASHSLASH_RAW);

	-- decode quote+slash
	text = string.gsub(text, LOOTSTER_ENC_QUOTESLASH_ENC, LOOTSTER_ENC_QUOTESLASH_RAW);

	-- decode new lines
	text = string.gsub(text, LOOTSTER_ENC_NEWLINE_ENC, LOOTSTER_ENC_NEWLINE_RAW);

	-- decode encode characters
	text = string.gsub(text, LOOTSTER_ENC_MARKER_ENC, LOOTSTER_ENC_MARKER_RAW);

	-- decode or-bar characters
	text = string.gsub(text, LOOTSTER_ENC_ORBAR_ENC, LOOTSTER_ENC_ORBAR_RAW);

	return text;
end

-- Encode Regular Expression handler
function Lootster_EncodeRegexp(regexp)
	-- encode all LUA pattern characters by escaping them
	return string.gsub(regexp, LOOTSTER_ENC_REGEXP_INP, LOOTSTER_ENC_REGEXP_ENC);
end

-- Decode Regular Expression handler
function Lootster_DecodeRegexp(regexp)
	-- decode all LUA pattern characters by unescaping them
	return string.gsub(regexp, LOOTSTER_ENC_REGEXP_DEC, LOOTSTER_ENC_REGEXP_OUT);
end

