-- Language Invariant Database
LOOTSTER_DIALOG_CLR = { r=0.00, g=0.00, b=0.00, acf=0.80, att=1.00 };

LOOTSTER_BOOLEAN_TEXT = { [false]=NO, [true]=YES };

-- NPC seem to be 0x003 or 0x005 (example, Flame Leviathan & Archavon the Stone Watcher)
LOOTSTER_UNIT_NPC = 0x001;

LOOTSTER_UNIT_PATTERN = "0x(%x%x%x)(%x%x%x%x%x)%x%x%x%x%x%x%x%x";

LOOTSTER_ITEM_MATCH = "^item:%d+:.*$";
LOOTSTER_ITEM_PATTERN = "item:(%d+):.*";

LOOTSTER_ITEMLINK_FORMAT = "|c%s|Hitem:%d:0:0:0:0:0:0:0:0:0:0|h[%s]|h|r";

LOOTSTER_ITEMID_PATTERN = "|c%x+|Hitem:(%d+):%d+:%d+:%d+:%d+:%d+:%-?%d+:%-?%d+:%d+:%d+:%d+|h%[.-%]|h|r";
LOOTSTER_ITEMQUAL_PATTERN = "|c(%x+)|Hitem:%d+:%d+:%d+:%d+:%d+:%d+:%-?%d+:%-?%d+:%d+:%d+:%d+|h%[.-%]|h|r";
LOOTSTER_ITEMTEXT_PATTERN = "|c%x+|Hitem:%d+:%d+:%d+:%d+:%d+:%d+:%-?%d+:%-?%d+:%d+:%d+:%d+|h%[(.-)%]|h|r";
LOOTSTER_ITEMFULL_PATTERN = "|c(%x+)|Hitem:(%d+):%d+:%d+:%d+:%d+:%d+:%-?%d+:%-?%d+:%d+:%d+:%d+|h%[(.-)%]|h|r";
LOOTSTER_ITEMFULLID_PATTERN = "|c(%x+)|Hitem:(%d+:%d+:%d+:%d+:%d+:%d+:%-?%d+:%-?%d+:%d+:%d+:%d+)|h%[(.-)%]|h|r";

LOOTSTER_ITEMQUAL_UNCACHED = "ffff0000";
LOOTSTER_ITEMLINK_UNCACHED = "|c"..LOOTSTER_ITEMQUAL_UNCACHED.."[%s]|r";

LOOTSTER_ITEMCOLOUR_PATTERN = "|c(%x+)";


LOOTSTER_REPORT_TEXTDETAIL = "TEXTDETAIL";
LOOTSTER_REPORT_TEXTCONSOL = "TEXTCONSOL";
LOOTSTER_REPORT_CTRT1_16_13 = "CTRT1.16.13";

LOOTSTER_CLASS_LOOT =
{
	[20864]	= { "DRUID", "HUNTER", "MAGE", "PALADIN", "PRIEST", "SHAMAN", "WARRIOR" },		-- Bone Scarab
	[20861]	= { "DRUID", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK", "WARRIOR" },	-- Bronze Scarab
	[20863]	= { "HUNTER", "MAGE", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK" },		-- Clay Scarab
	[20862]	= { "DRUID", "HUNTER", "MAGE", "ROGUE", "WARLOCK", "WARRIOR" },					-- Crystal Scarab
	[20859]	= { "HUNTER", "MAGE", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK" },		-- Gold Scarab
	[20865]	= { "DRUID", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK", "WARRIOR" },	-- Ivory Scarab
	[20860]	= { "DRUID", "HUNTER", "MAGE", "PALADIN", "PRIEST", "SHAMAN", "WARRIOR" },		-- Silver Scarab
	[20858]	= { "DRUID", "HUNTER", "MAGE", "ROGUE", "WARLOCK", "WARRIOR" }					-- Stone Scarab
};

LOOTSTER_ITEM_TLB =
{
	[29754]	= { iLevel=120, iInvType="INVTYPE_CHEST" },		-- Tier     4: Chestguard of the Fallen Champion
	[29757]	= { iLevel=120, iInvType="INVTYPE_HAND" },		-- Tier     4: Gloves of the Fallen Champion
	[29760]	= { iLevel=120, iInvType="INVTYPE_HEAD" },		-- Tier     4: Helm of the Fallen Champion
	[29766]	= { iLevel=120, iInvType="INVTYPE_LEGS" },		-- Tier     4: Leggings of the Fallen Champion
	[29763]	= { iLevel=120, iInvType="INVTYPE_SHOULDER" },	-- Tier     4: Pauldrons of the Fallen Champion

	[29753]	= { iLevel=120, iInvType="INVTYPE_CHEST" },		-- Tier     4: Chestguard of the Fallen Defender
	[29758]	= { iLevel=120, iInvType="INVTYPE_HAND" },		-- Tier     4: Gloves of the Fallen Defender
	[29761]	= { iLevel=120, iInvType="INVTYPE_HEAD" },		-- Tier     4: Helm of the Fallen Defender
	[29767]	= { iLevel=120, iInvType="INVTYPE_LEGS" },		-- Tier     4: Leggings of the Fallen Defender
	[29764]	= { iLevel=120, iInvType="INVTYPE_SHOULDER" },	-- Tier     4: Pauldrons of the Fallen Defender

	[29755]	= { iLevel=120, iInvType="INVTYPE_CHEST" },		-- Tier     4: Chestguard of the Fallen Hero
	[29756]	= { iLevel=120, iInvType="INVTYPE_HAND" },		-- Tier     4: Gloves of the Fallen Hero
	[29759]	= { iLevel=120, iInvType="INVTYPE_HEAD" },		-- Tier     4: Helm of the Fallen Hero
	[29765]	= { iLevel=120, iInvType="INVTYPE_LEGS" },		-- Tier     4: Leggings of the Fallen Hero
	[29762]	= { iLevel=120, iInvType="INVTYPE_SHOULDER" },	-- Tier     4: Pauldrons of the Fallen Hero

	[30236]	= { iLevel=133, iInvType="INVTYPE_CHEST" },		-- Tier     5: Chestguard of the Vanquished Champion
	[30239]	= { iLevel=133, iInvType="INVTYPE_HAND" },		-- Tier     5: Gloves of the Vanquished Champion
	[30242]	= { iLevel=133, iInvType="INVTYPE_HEAD" },		-- Tier     5: Helm of the Vanquished Champion
	[30245]	= { iLevel=133, iInvType="INVTYPE_LEGS" },		-- Tier     5: Leggings of the Vanquished Champion
	[30248]	= { iLevel=133, iInvType="INVTYPE_SHOULDER" },	-- Tier     5: Pauldrons of the Vanquished Champion

	[30237]	= { iLevel=133, iInvType="INVTYPE_CHEST" },		-- Tier     5: Chestguard of the Vanquished Defender
	[30240]	= { iLevel=133, iInvType="INVTYPE_HAND" },		-- Tier     5: Gloves of the Vanquished Defender
	[30243]	= { iLevel=133, iInvType="INVTYPE_HEAD" },		-- Tier     5: Helm of the Vanquished Defender
	[30246]	= { iLevel=133, iInvType="INVTYPE_LEGS" },		-- Tier     5: Leggings of the Vanquished Defender
	[30249]	= { iLevel=133, iInvType="INVTYPE_SHOULDER" },	-- Tier     5: Pauldrons of the Vanquished Defender

	[30238]	= { iLevel=133, iInvType="INVTYPE_CHEST" },		-- Tier     5: Chestguard of the Vanquished Hero
	[30241]	= { iLevel=133, iInvType="INVTYPE_HAND" },		-- Tier     5: Gloves of the Vanquished Hero
	[30244]	= { iLevel=133, iInvType="INVTYPE_HEAD" },		-- Tier     5: Helm of the Vanquished Hero
	[30247]	= { iLevel=133, iInvType="INVTYPE_LEGS" },		-- Tier     5: Leggings of the Vanquished Hero
	[30250]	= { iLevel=133, iInvType="INVTYPE_SHOULDER" },	-- Tier     5: Pauldrons of the Vanquished Hero

	[31089]	= { iLevel=146, iInvType="INVTYPE_CHEST" },		-- Tier     6: Chestguard of the Forgotten Conqueror
	[34856]	= { iLevel=154, iInvType="INVTYPE_FEET" },		-- Tier   6.5: Boots of the Forgotten Conqueror
	[31092]	= { iLevel=146, iInvType="INVTYPE_HAND" },		-- Tier     6: Gloves of the Forgotten Conqueror
	[31097]	= { iLevel=146, iInvType="INVTYPE_HEAD" },		-- Tier     6: Helm of the Forgotten Conqueror
	[31098]	= { iLevel=146, iInvType="INVTYPE_LEGS" },		-- Tier     6: Leggings of the Forgotten Conqueror
	[31101]	= { iLevel=146, iInvType="INVTYPE_SHOULDER" },	-- Tier     6: Pauldrons of the Forgotten Conqueror
	[34853]	= { iLevel=154, iInvType="INVTYPE_WAIST" },		-- Tier   6.5: Belt of the Forgotten Conqueror
	[34848]	= { iLevel=154, iInvType="INVTYPE_WRIST" },		-- Tier   6.5: Bracers of the Forgotten Conqueror

	[31091]	= { iLevel=146, iInvType="INVTYPE_CHEST" },		-- Tier     6: Chestguard of the Forgotten Protector
	[34857]	= { iLevel=154, iInvType="INVTYPE_FEET" },		-- Tier   6.5: Boots of the Forgotten Protector
	[31094]	= { iLevel=146, iInvType="INVTYPE_HAND" },		-- Tier     6: Gloves of the Forgotten Protector
	[31095]	= { iLevel=146, iInvType="INVTYPE_HEAD" },		-- Tier     6: Helm of the Forgotten Conqueror
	[31100]	= { iLevel=146, iInvType="INVTYPE_LEGS" },		-- Tier     6: Leggings of the Forgotten Protector
	[31103]	= { iLevel=146, iInvType="INVTYPE_SHOULDER" },	-- Tier     6: Pauldrons of the Forgotten Protector
	[34854]	= { iLevel=154, iInvType="INVTYPE_WAIST" },		-- Tier   6.5: Belt of the Forgotten Protector
	[34851]	= { iLevel=154, iInvType="INVTYPE_WRIST" },		-- Tier   6.5: Bracers of the Forgotten Protector

	[31090]	= { iLevel=146, iInvType="INVTYPE_CHEST" },		-- Tier     6: Chestguard of the Forgotten Vanquisher
	[34858]	= { iLevel=154, iInvType="INVTYPE_FEET" },		-- Tier   6.5: Boots of the Forgotten Vanquisher
	[31093]	= { iLevel=146, iInvType="INVTYPE_HAND" },		-- Tier     6: Gloves of the Forgotten Vanquisher
	[31096]	= { iLevel=146, iInvType="INVTYPE_HEAD" },		-- Tier     6: Helm of the Forgotten Vanquisher
	[31099]	= { iLevel=146, iInvType="INVTYPE_LEGS" },		-- Tier     6: Leggings of the Forgotten Vanquisher
	[31102]	= { iLevel=146, iInvType="INVTYPE_SHOULDER" },	-- Tier     6: Pauldrons of the Forgotten Vanquisher
	[34855]	= { iLevel=154, iInvType="INVTYPE_WAIST" },		-- Tier   6.5: Belt of the Forgotten Vanquisher
	[34852]	= { iLevel=154, iInvType="INVTYPE_WRIST" },		-- Tier   6.5: Bracers of the Forgotten Vanquisher
	
	[40610]	= { iLevel=200, iInvType="INVTYPE_CHEST" },		-- Tier     7: Chestguard of the Lost Conqueror
	[40613]	= { iLevel=200, iInvType="INVTYPE_HAND" },		-- Tier     7: Gloves of the Lost Conqueror
	[40616]	= { iLevel=200, iInvType="INVTYPE_HEAD" },		-- Tier     7: Helm of the Lost Conqueror
	[40619]	= { iLevel=200, iInvType="INVTYPE_LEGS" },		-- Tier     7: Leggings of the Lost Conqueror
	[40622]	= { iLevel=200, iInvType="INVTYPE_SHOULDER" },	-- Tier     7: Spaulders of the Lost Conqueror

	[40611]	= { iLevel=200, iInvType="INVTYPE_CHEST" },		-- Tier     7: Chestguard of the Lost Protector
	[40614]	= { iLevel=200, iInvType="INVTYPE_HAND" },		-- Tier     7: Gloves of the Lost Protector
	[40617]	= { iLevel=200, iInvType="INVTYPE_HEAD" },		-- Tier     7: Helm of the Lost Protector
	[40620]	= { iLevel=200, iInvType="INVTYPE_LEGS" },		-- Tier     7: Leggings of the Lost Protector
	[40623]	= { iLevel=200, iInvType="INVTYPE_SHOULDER" },	-- Tier     7: Spaulders of the Lost Protector

	[40612]	= { iLevel=200, iInvType="INVTYPE_CHEST" },		-- Tier     7: Chestguard of the Lost Vanquisher
	[40615]	= { iLevel=200, iInvType="INVTYPE_HAND" },		-- Tier     7: Gloves of the Lost Vanquisher
	[40618]	= { iLevel=200, iInvType="INVTYPE_HEAD" },		-- Tier     7: Helm of the Lost Vanquisher
	[40621]	= { iLevel=200, iInvType="INVTYPE_LEGS" },		-- Tier     7: Leggings of the Lost Vanquisher
	[40624]	= { iLevel=200, iInvType="INVTYPE_SHOULDER" },	-- Tier     7: Spaulders of the Lost Vanquisher

	[40625]	= { iLevel=213, iInvType="INVTYPE_CHEST" },		-- Tier   7.5: Breastplate of the Lost Conqueror
	[40628]	= { iLevel=213, iInvType="INVTYPE_HAND" },		-- Tier   7.5: Gauntlets of the Lost Conqueror
	[40631]	= { iLevel=213, iInvType="INVTYPE_HEAD" },		-- Tier   7.5: Crown of the Lost Conqueror
	[40634]	= { iLevel=213, iInvType="INVTYPE_LEGS" },		-- Tier   7.5: Legplates of the Lost Conqueror
	[40637]	= { iLevel=213, iInvType="INVTYPE_SHOULDER" },	-- Tier   7.5: Mantle of the Lost Conqueror

	[40626]	= { iLevel=213, iInvType="INVTYPE_CHEST" },		-- Tier   7.5: Breastplate of the Lost Protector
	[40629]	= { iLevel=213, iInvType="INVTYPE_HAND" },		-- Tier   7.5: Gauntlets of the Lost Protector
	[40632]	= { iLevel=213, iInvType="INVTYPE_HEAD" },		-- Tier   7.5: Crown of the Lost Protector
	[40635]	= { iLevel=213, iInvType="INVTYPE_LEGS" },		-- Tier   7.5: Legplates of the Lost Protector
	[40638]	= { iLevel=213, iInvType="INVTYPE_SHOULDER" },	-- Tier   7.5: Mantle of the Lost Protector

	[40627]	= { iLevel=213, iInvType="INVTYPE_CHEST" },		-- Tier   7.5: Breastplate of the Lost Vanquisher
	[40630]	= { iLevel=213, iInvType="INVTYPE_HAND" },		-- Tier   7.5: Gauntlets of the Lost Vanquisher
	[40633]	= { iLevel=213, iInvType="INVTYPE_HEAD" },		-- Tier   7.5: Crown of the Lost Vanquisher
	[40636]	= { iLevel=213, iInvType="INVTYPE_LEGS" },		-- Tier   7.5: Legplates of the Lost Vanquisher
	[40639]	= { iLevel=213, iInvType="INVTYPE_SHOULDER" },	-- Tier   7.5: Mantle of the Lost Vanquisher

	[45635]	= { iLevel=219, iInvType="INVTYPE_CHEST" },		-- Tier     8: Chestguard of the Wayward Conqueror
	[45644]	= { iLevel=219, iInvType="INVTYPE_HAND" },		-- Tier     8: Gloves of the Wayward Conqueror
	[45647]	= { iLevel=219, iInvType="INVTYPE_HEAD" },		-- Tier     8: Helm of the Wayward Conqueror
	[45650]	= { iLevel=219, iInvType="INVTYPE_LEGS" },		-- Tier     8: Leggings of the Wayward Conqueror
	[45659]	= { iLevel=219, iInvType="INVTYPE_SHOULDER" },	-- Tier     8: Spaulders of the Wayward Conqueror

	[45636]	= { iLevel=219, iInvType="INVTYPE_CHEST" },		-- Tier     8: Chestguard of the Wayward Protector
	[45645]	= { iLevel=219, iInvType="INVTYPE_HAND" },		-- Tier     8: Gloves of the Wayward Protector
	[45648]	= { iLevel=219, iInvType="INVTYPE_HEAD" },		-- Tier     8: Helm of the Wayward Protector
	[45651]	= { iLevel=219, iInvType="INVTYPE_LEGS" },		-- Tier     8: Leggings of the Wayward Protector
	[45660]	= { iLevel=219, iInvType="INVTYPE_SHOULDER" },	-- Tier     8: Spaulders of the Wayward Protector

	[45637]	= { iLevel=219, iInvType="INVTYPE_CHEST" },		-- Tier     8: Chestguard of the Wayward Vanquisher
	[45646]	= { iLevel=219, iInvType="INVTYPE_HAND" },		-- Tier     8: Gloves of the Wayward Vanquisher
	[45649]	= { iLevel=219, iInvType="INVTYPE_HEAD" },		-- Tier     8: Helm of the Wayward Vanquisher
	[45652]	= { iLevel=219, iInvType="INVTYPE_LEGS" },		-- Tier     8: Leggings of the Wayward Vanquisher
	[45661]	= { iLevel=219, iInvType="INVTYPE_SHOULDER" },	-- Tier     8: Spaulders of the Wayward Vanquisher

	[45632]	= { iLevel=226, iInvType="INVTYPE_CHEST" },		-- Tier   8.5: Breastplate of the Wayward Conqueror
	[45641]	= { iLevel=226, iInvType="INVTYPE_HAND" },		-- Tier   8.5: Gauntlets of the Wayward Conqueror
	[45638]	= { iLevel=226, iInvType="INVTYPE_HEAD" },		-- Tier   8.5: Crown of the Wayward Conqueror
	[45653]	= { iLevel=226, iInvType="INVTYPE_LEGS" },		-- Tier   8.5: Legplates of the Wayward Conqueror
	[45656]	= { iLevel=226, iInvType="INVTYPE_SHOULDER" },	-- Tier   8.5: Mantle of the Wayward Conqueror

	[45633]	= { iLevel=226, iInvType="INVTYPE_CHEST" },		-- Tier   8.5: Breastplate of the Wayward Protector
	[45642]	= { iLevel=226, iInvType="INVTYPE_HAND" },		-- Tier   8.5: Gauntlets of the Wayward Protector
	[45639]	= { iLevel=226, iInvType="INVTYPE_HEAD" },		-- Tier   8.5: Crown of the Wayward Protector
	[45654]	= { iLevel=226, iInvType="INVTYPE_LEGS" },		-- Tier   8.5: Legplates of the Wayward Protector
	[45657]	= { iLevel=226, iInvType="INVTYPE_SHOULDER" },	-- Tier   8.5: Mantle of the Wayward Protector

	[45634]	= { iLevel=226, iInvType="INVTYPE_CHEST" },		-- Tier   8.5: Breastplate of the Wayward Vanquisher
	[45643]	= { iLevel=226, iInvType="INVTYPE_HAND" },		-- Tier   8.5: Gauntlets of the Wayward Vanquisher
	[45640]	= { iLevel=226, iInvType="INVTYPE_HEAD" },		-- Tier   8.5: Crown of the Wayward Vanquisher
	[45655]	= { iLevel=226, iInvType="INVTYPE_LEGS" },		-- Tier   8.5: Legplates of the Wayward Vanquisher
	[45658]	= { iLevel=226, iInvType="INVTYPE_SHOULDER" },	-- Tier   8.5: Mantle of the Wayward Vanquisher

	[47242]	= { iLevel=245, iInvType="INVTYPE_CHEST" },		-- Tier   9.5: Trophy of the Crusade

	[47557]	= { iLevel=258, iInvType="INVTYPE_CHEST" },		-- Tier   9.H: Regalia of the Grand Conqueror
	[47558]	= { iLevel=258, iInvType="INVTYPE_CHEST" },		-- Tier   9.H: Regalia of the Grand Protector
	[47559]	= { iLevel=258, iInvType="INVTYPE_CHEST" },		-- Tier   9.H: Regalia of the Grand Vanquisher

	[52027]	= { iLevel=264, iInvType="INVTYPE_CHEST" },		-- Tier  10.5: Conqueror's Mark of Sanctification
	[52026]	= { iLevel=264, iInvType="INVTYPE_CHEST" },		-- Tier  10.5: Protector's Mark of Sanctification
	[52025]	= { iLevel=264, iInvType="INVTYPE_CHEST" },		-- Tier  10.5: Vanquisher's Mark of Sanctification

	[52030]	= { iLevel=277, iInvType="INVTYPE_CHEST" },		-- Tier  10.H: Conqueror's Mark of Sanctification (H)
	[52029]	= { iLevel=277, iInvType="INVTYPE_CHEST" },		-- Tier  10.H: Protector's Mark of Sanctification (H)
	[52028]	= { iLevel=277, iInvType="INVTYPE_CHEST" },		-- Tier  10.H: Vanquisher's Mark of Sanctification (H)

	[63683]	= { iLevel=359, iInvType="INVTYPE_HEAD" },		-- Tier    11: Helm of the Forlorn Conqueror
	[64315]	= { iLevel=359, iInvType="INVTYPE_SHOULDER" },	-- Tier    11: Mantle of the Forlorn Conqueror

	[63684]	= { iLevel=359, iInvType="INVTYPE_HEAD" },		-- Tier    11: Helm of the Forlorn Protector
	[64316]	= { iLevel=359, iInvType="INVTYPE_SHOULDER" },	-- Tier    11: Mantle of the Forlorn Protector

	[63682]	= { iLevel=359, iInvType="INVTYPE_HEAD" },		-- Tier    11: Helm of the Forlorn Vanquisher
	[64314]	= { iLevel=359, iInvType="INVTYPE_SHOULDER" },	-- Tier    11: Mantle of the Forlorn Vanquisher

	[67423]	= { iLevel=372, iInvType="INVTYPE_CHEST" },		-- Tier  11.H: Chest of the Forlorn Conqueror (H)
	[65001]	= { iLevel=372, iInvType="INVTYPE_HEAD" },		-- Tier  11.H: Crown of the Forlorn Conqueror (H)
	[67429]	= { iLevel=372, iInvType="INVTYPE_HAND" },		-- Tier  11.H: Gauntlets of the Forlorn Conqueror (H)
	[67428]	= { iLevel=372, iInvType="INVTYPE_LEGS" },		-- Tier  11.H: Leggings of the Forlorn Conqueror (H)
	[65088]	= { iLevel=372, iInvType="INVTYPE_SHOULDER" },	-- Tier  11.H: Shoulders of the Forlorn Conqueror (H)

	[67424]	= { iLevel=372, iInvType="INVTYPE_CHEST" },		-- Tier  11.H: Chest of the Forlorn Protector (H)
	[65000]	= { iLevel=372, iInvType="INVTYPE_HEAD" },		-- Tier  11.H: Crown of the Forlorn Protector (H)
	[67430]	= { iLevel=372, iInvType="INVTYPE_HAND" },		-- Tier  11.H: Gauntlets of the Forlorn Protector (H)
	[67427]	= { iLevel=372, iInvType="INVTYPE_LEGS" },		-- Tier  11.H: Leggings of the Forlorn Protector (H)
	[65087]	= { iLevel=372, iInvType="INVTYPE_SHOULDER" },	-- Tier  11.H: Shoulders of the Forlorn Protector (H)

	[67425]	= { iLevel=372, iInvType="INVTYPE_CHEST" },		-- Tier  11.H: Chest of the Forlorn Vanquisher (H)
	[65002]	= { iLevel=372, iInvType="INVTYPE_HEAD" },		-- Tier  11.H: Crown of the Forlorn Vanquisher (H)
	[67431]	= { iLevel=372, iInvType="INVTYPE_HAND" },		-- Tier  11.H: Gauntlets of the Forlorn Vanquisher (H)
	[67426]	= { iLevel=372, iInvType="INVTYPE_LEGS" },		-- Tier  11.H: Leggings of the Forlorn Vanquisher (H)
	[65089]	= { iLevel=372, iInvType="INVTYPE_SHOULDER" },	-- Tier  11.H: Shoulders of the Forlorn Vanquisher (H)

	[66998]	= { iLevel=372, iInvType="INVTYPE_CHEST" },		-- Tier  11.H: Essence of the Forlorn

	[71675]	= { iLevel=378, iInvType="INVTYPE_HEAD" },		-- Tier    12: Helm of the Firey Conqueror
	[71681]	= { iLevel=378, iInvType="INVTYPE_SHOULDER" },	-- Tier    12: Mantle of the Firey Conqueror

	[71682]	= { iLevel=378, iInvType="INVTYPE_HEAD" },		-- Tier    12: Helm of the Firey Protector
	[71688]	= { iLevel=378, iInvType="INVTYPE_SHOULDER" },	-- Tier    12: Mantle of the Firey Protector

	[71668]	= { iLevel=378, iInvType="INVTYPE_HEAD" },		-- Tier    12: Helm of the Firey Vanquisher
	[71674]	= { iLevel=378, iInvType="INVTYPE_SHOULDER" },	-- Tier    12: Mantle of the Firey Vanquisher

	[71679]	= { iLevel=391, iInvType="INVTYPE_CHEST" },		-- Tier  12.H: Chest of the Firey Conqueror (H)
	[71677]	= { iLevel=391, iInvType="INVTYPE_HEAD" },		-- Tier  12.H: Crown of the Firey Conqueror (H)
	[71676]	= { iLevel=391, iInvType="INVTYPE_HAND" },		-- Tier  12.H: Gauntlets of the Firey Conqueror (H)
	[71678]	= { iLevel=391, iInvType="INVTYPE_LEGS" },		-- Tier  12.H: Leggings of the Firey Conqueror (H)
	[71680]	= { iLevel=391, iInvType="INVTYPE_SHOULDER" },	-- Tier  12.H: Shoulders of the Firey Conqueror (H)

	[71686]	= { iLevel=391, iInvType="INVTYPE_CHEST" },		-- Tier  12.H: Chest of the Firey Protector (H)
	[71684]	= { iLevel=391, iInvType="INVTYPE_HEAD" },		-- Tier  12.H: Crown of the Firey Protector (H)
	[71683]	= { iLevel=391, iInvType="INVTYPE_HAND" },		-- Tier  12.H: Gauntlets of the Firey Protector (H)
	[71685]	= { iLevel=391, iInvType="INVTYPE_LEGS" },		-- Tier  12.H: Leggings of the Firey Protector (H)
	[71687]	= { iLevel=391, iInvType="INVTYPE_SHOULDER" },	-- Tier  12.H: Shoulders of the Firey Protector (H)

	[71672]	= { iLevel=391, iInvType="INVTYPE_CHEST" },		-- Tier  12.H: Chest of the Firey Vanquisher (H)
	[71670]	= { iLevel=391, iInvType="INVTYPE_HEAD" },		-- Tier  12.H: Crown of the Firey Vanquisher (H)
	[71669]	= { iLevel=391, iInvType="INVTYPE_HAND" },		-- Tier  12.H: Gauntlets of the Firey Vanquisher (H)
	[71671]	= { iLevel=391, iInvType="INVTYPE_LEGS" },		-- Tier  12.H: Leggings of the Firey Vanquisher (H)
	[71673]	= { iLevel=391, iInvType="INVTYPE_SHOULDER" },	-- Tier  12.H: Shoulders of the Firey Vanquisher (H)

	[71617]	= { iLevel=391, iInvType="INVTYPE_TRINKET" },	-- Tier  12.H: Crystallized Firestone (Note: Many slot types, using 'average')

	[78863]	= { iLevel=384, iInvType="INVTYPE_CHEST" },		-- Tier 13.RF: Chestguard of the Corrupted Conqueror
	[78866]	= { iLevel=384, iInvType="INVTYPE_HAND" },		-- Tier 13.RF: Gauntlets of the Corrupted Conqueror
	[78869]	= { iLevel=384, iInvType="INVTYPE_HEAD" },		-- Tier 13.RF: Crown of the Corrupted Conqueror
	[78872]	= { iLevel=384, iInvType="INVTYPE_LEGS" },		-- Tier 13.RF: Leggings of the Corrupted Conqueror
	[78875]	= { iLevel=384, iInvType="INVTYPE_SHOULDER" },	-- Tier 13.RF: Shoulders of the Corrupted Conqueror

	[78864]	= { iLevel=384, iInvType="INVTYPE_CHEST" },		-- Tier 13.RF: Chestguard of the Corrupted Protector
	[78867]	= { iLevel=384, iInvType="INVTYPE_HAND" },		-- Tier 13.RF: Gauntlets of the Corrupted Protector
	[78870]	= { iLevel=384, iInvType="INVTYPE_HEAD" },		-- Tier 13.RF: Crown of the Corrupted Protector
	[78873]	= { iLevel=384, iInvType="INVTYPE_LEGS" },		-- Tier 13.RF: Leggings of the Corrupted Protector
	[78876]	= { iLevel=384, iInvType="INVTYPE_SHOULDER" },	-- Tier 13.RF: Shoulders of the Corrupted Protector

	[78862]	= { iLevel=384, iInvType="INVTYPE_CHEST" },		-- Tier 13.RF: Chestguard of the Corrupted Vanquisher
	[78865]	= { iLevel=384, iInvType="INVTYPE_HAND" },		-- Tier 13.RF: Gauntlets of the Corrupted Vanquisher
	[78868]	= { iLevel=384, iInvType="INVTYPE_HEAD" },		-- Tier 13.RF: Crown of the Corrupted Vanquisher
	[78871]	= { iLevel=384, iInvType="INVTYPE_LEGS" },		-- Tier 13.RF: Leggings of the Corrupted Vanquisher
	[78874]	= { iLevel=384, iInvType="INVTYPE_SHOULDER" },	-- Tier 13.RF: Shoulders of the Corrupted Vanquisher

	[78184]	= { iLevel=397, iInvType="INVTYPE_CHEST" },		-- Tier    13: Chestguard of the Corrupted Conqueror
	[78183]	= { iLevel=397, iInvType="INVTYPE_HAND" },		-- Tier    13: Gauntlets of the Corrupted Conqueror
	[78182]	= { iLevel=397, iInvType="INVTYPE_HEAD" },		-- Tier    13: Crown of the Corrupted Conqueror
	[78181]	= { iLevel=397, iInvType="INVTYPE_LEGS" },		-- Tier    13: Leggings of the Corrupted Conqueror
	[78180]	= { iLevel=397, iInvType="INVTYPE_SHOULDER" },	-- Tier    13: Shoulders of the Corrupted Conqueror

	[78179]	= { iLevel=397, iInvType="INVTYPE_CHEST" },		-- Tier    13: Chestguard of the Corrupted Protector
	[78178]	= { iLevel=397, iInvType="INVTYPE_HAND" },		-- Tier    13: Gauntlets of the Corrupted Protector
	[78177]	= { iLevel=397, iInvType="INVTYPE_HEAD" },		-- Tier    13: Crown of the Corrupted Protector
	[78176]	= { iLevel=397, iInvType="INVTYPE_LEGS" },		-- Tier    13: Leggings of the Corrupted Protector
	[78175]	= { iLevel=397, iInvType="INVTYPE_SHOULDER" },	-- Tier    13: Shoulders of the Corrupted Protector

	[78174]	= { iLevel=397, iInvType="INVTYPE_CHEST" },		-- Tier    13: Chestguard of the Corrupted Vanquisher
	[78173]	= { iLevel=397, iInvType="INVTYPE_HAND" },		-- Tier    13: Gauntlets of the Corrupted Vanquisher
	[78172]	= { iLevel=397, iInvType="INVTYPE_HEAD" },		-- Tier    13: Crown of the Corrupted Vanquisher
	[78171]	= { iLevel=397, iInvType="INVTYPE_LEGS" },		-- Tier    13: Leggings of the Corrupted Vanquisher
	[78170]	= { iLevel=397, iInvType="INVTYPE_SHOULDER" },	-- Tier    13: Shoulders of the Corrupted Vanquisher

	[78847]	= { iLevel=410, iInvType="INVTYPE_CHEST" },		-- Tier  13.H: Chestguard of the Corrupted Conqueror
	[78853]	= { iLevel=410, iInvType="INVTYPE_HAND" },		-- Tier  13.H: Gauntlets of the Corrupted Conqueror
	[78850]	= { iLevel=410, iInvType="INVTYPE_HEAD" },		-- Tier  13.H: Crown of the Corrupted Conqueror
	[78856]	= { iLevel=410, iInvType="INVTYPE_LEGS" },		-- Tier  13.H: Leggings of the Corrupted Conqueror
	[78859]	= { iLevel=410, iInvType="INVTYPE_SHOULDER" },	-- Tier  13.H: Shoulders of the Corrupted Conqueror

	[78848]	= { iLevel=410, iInvType="INVTYPE_CHEST" },		-- Tier  13.H: Chestguard of the Corrupted Protector
	[78854]	= { iLevel=410, iInvType="INVTYPE_HAND" },		-- Tier  13.H: Gauntlets of the Corrupted Protector
	[78851]	= { iLevel=410, iInvType="INVTYPE_HEAD" },		-- Tier  13.H: Crown of the Corrupted Protector
	[78857]	= { iLevel=410, iInvType="INVTYPE_LEGS" },		-- Tier  13.H: Leggings of the Corrupted Protector
	[78860]	= { iLevel=410, iInvType="INVTYPE_SHOULDER" },	-- Tier  13.H: Shoulders of the Corrupted Protector

	[78849]	= { iLevel=410, iInvType="INVTYPE_CHEST" },		-- Tier  13.H: Chestguard of the Corrupted Vanquisher
	[78855]	= { iLevel=410, iInvType="INVTYPE_HAND" },		-- Tier  13.H: Gauntlets of the Corrupted Vanquisher
	[78852]	= { iLevel=410, iInvType="INVTYPE_HEAD" },		-- Tier  13.H: Crown of the Corrupted Vanquisher
	[78858]	= { iLevel=410, iInvType="INVTYPE_LEGS" },		-- Tier  13.H: Leggings of the Corrupted Vanquisher
	[78861]	= { iLevel=410, iInvType="INVTYPE_SHOULDER" },	-- Tier  13.H: Shoulders of the Corrupted Vanquisher
};

LOOTSTER_LOOT_FAKE =
{
	[29434]	= true,		-- Badge of Justice
	[40316]	= true,		-- Dalaran Cooking Award
	[41596]	= true,		-- Dalaran Jewelcrafter's Token
	[45624]	= true,		-- Emblem of Conquest
	[49426]	= true,		-- Emblem of Frost
	[40752]	= true,		-- Emblem of Heroism
	[47241]	= true,		-- Emblem of Triumph
	[40753]	= true,		-- Emblem of Valor
	[43228]	= true		-- Stone Keeper's Shard
};

LOOTSTER_BOSS_ID =
{
	[35144] = true,		-- Acidmaw
	[17881] = true,		-- Aeonus
	[ 4422] = true,		-- Agathelos the Raging
	[25740] = true,		-- Ahune
	[23574] = true,		-- Akil'zon
	[ 4829] = true,		-- Aku'mai
	[46753] = true,		-- Al'akir
	[19514] = true,		-- Al'ar
	[55869] = true,		-- Alizabal
	[32871] = true,		-- Algalon the Observer
	[43873] = true,		-- Altarius
	[54382] = true,		-- Alysrazor
	[34467] = true,		-- Alyssia Moonstalker
	[11492] = true,		-- Alzzin the Wildshaper
	[30258] = true,		-- Amanitar
	[ 9156] = true,		-- Ambassador Flamelash
	[18731] = true,		-- Ambassador Hellmaw
	[63666] = true,		-- Amber-Shaper Un'sok
	[34702] = true,		-- Ambrose Boltspark
	[60047] = true,		-- Amethyst Guardian
	[39731] = true,		-- Ammunae
	[ 7358] = true,		-- Amnennar the Coldbringer
	[ 7206] = true,		-- Ancient Stone Keeper
	[17808] = true,		-- Anetheron
	[17808] = true,		-- Anger'rel
	[26763] = true,		-- Anomalus
	[39788] = true,		-- Anraphet
	[45870] = true,		-- Anshal
	[34466] = true,		-- Anthar Forgemender
	[ 8127] = true,		-- Antu'sul
	[29120] = true,		-- Anub'arak (Azjol-Nerub)
	[34660] = true,		-- Anub'arak (Crusaders' Coliseum)
	[15956] = true,		-- Anub'Rekhan
	[ 9031] = true,		-- Anub'shiah
	[23035] = true,		-- Anzu
	[ 6487] = true,		-- Arcanist Doan
	[42166] = true,		-- Arcanotron
	[ 2748] = true,		-- Archaedas
	[31125] = true,		-- Archavon the Stone Watcher
	[54938] = true,		-- Archbishop Benedictus
	[17968] = true,		-- Archimonde
	[10811] = true,		-- Archivist Galford
	[ 4275] = true,		-- Archmage Arugal
	[54590] = true,		-- Arcurion
	[43688] = true,		-- Arion
	[47120] = true,		-- Argaloth
	[34102] = true,		-- Argent Confessor Paletress
	[58632] = true,		-- Armsmaster Harlan
	[39705] = true,		-- Ascendant Lord Obsidius
	[43875] = true,		-- Asim al Akir
	[54968] = true,		-- Asira Dawnslayer
	[ 8580] = true,		-- Atal'alarion
	[41442] = true,		-- Atramedes
	[15550] = true,		-- Attumen the Huntsman
	[33515] = true,		-- Auriaya
	[14464] = true,		-- Avalanchion
	[ 8443] = true,		-- Avatar of Hakkar
	[15369] = true,		-- Ayamiss the Hunter
	[17842] = true,		-- Azgalor
	[ 6490] = true,		-- Azshir the Sleepless
	[ 6109] = true,		-- Azuregos
	[ 9016] = true,		-- Bael'Gar
	[34471] = true,		-- Baelnor Lightbearer
	[ 6906] = true,		-- Baelog
	[53494] = true,		-- Baleroc
	[10813] = true,		-- Balnazzar
	[39751] = true,		-- Baltharus the Warborn
	[ 9596] = true,		-- Bannok Grimaxe
	[12876] = true,		-- Baron Aquanis
	[14461] = true,		-- Baron Charr
	[10436] = true,		-- Baroness Anastari
	[12056] = true,		-- Baron Geddon
	[15205] = true,		-- Baron Kazum
	[10440] = true,		-- Baron Rivendare (Stratholme)
	[30549] = true,		-- Baron Rivendare (Naxxramas)
	[ 3887] = true,		-- Baron Silverlaine
	[15516] = true,		-- Battleguard Sartura
	[ 1716] = true,		-- Bazil Thredd
	[11519] = true,		-- Bazzalan
	[39700] = true,		-- Beauty
	[52675] = true,		-- Beth'tilac
	[34451] = true,		-- Birana Stormhoof
	[11121] = true,		-- Black Guard Swordsmith
	[18667] = true,		-- Blackheart the Inciter
	[63664] = true,		-- Blade Lord Ta'yak
	[18836] = true,		-- Blindeye the Seer
	[ 4425] = true,		-- Blind Hunter
	[20923] = true,		-- Blood Guard Porung
	[52933] = true,		-- Blood Guard Hakkuz
	[38004] = true,		-- Blood-Queen Lana'thel
	[11382] = true,		-- Bloodlord Mandokir (Classic)
	[52151] = true,		-- Bloodlord Mandokir (Cataclysm)
	[ 4543] = true,		-- Bloodmage Thalnos
	[ 3672] = true,		-- Boahn
	[  596] = true,		-- Brainwashed Noble
	[34473] = true,		-- Brienna Nightfell
	[17380] = true,		-- Broggok
	[18398] = true,		-- Brokentoe
	[34455] = true,		-- Broln Stouthorn
	[36497] = true,		-- Bronjahm
	[59223] = true,		-- Brother Korloff
	[12017] = true,		-- Broodlord Lashlayer
	[ 1720] = true,		-- Bruegal Ironknuckle
	[24882] = true,		-- Brutallus
	[10263] = true,		-- Burning Felguard
	[15370] = true,		-- Buru the Gorger
	[15727] = true,		-- C'Thun
	[34447] = true,		-- Caiphus the Stern
	[10997] = true,		-- Cannon Master Willey
	[  647] = true,		-- Captain Greenskin
	[14325] = true,		-- Captain Kromcrush
	[17862] = true,		-- Captain Skarloc
	[55419] = true,		-- Captain Varo'then
	[12225] = true,		-- Celebras the Cursed
	[ 4421] = true,		-- Charlga Razorflank
	[62352] = true,		-- Chief Salyis
	[ 7267] = true,		-- Chief Ukorz Sandscalp
	[43296] = true,		-- Chimaron
	[43324] = true,		-- Cho'gall
	[14324] = true,		-- Cho'Rush the Observer
	[14020] = true,		-- Chromaggus
	[17879] = true,		-- Chrono Lord Deja
	[26532] = true,		-- Chrono-Lord Epoch
	[17827] = true,		-- Claw
	[34701] = true,		-- Colosos
	[26798] = true,		-- Commander Kolurg
	[17976] = true,		-- Commander Sarannis
	[56636] = true,		-- Commander Ri'mok
	[ 4278] = true,		-- Commander Springvale
	[26796] = true,		-- Commander Stoutbeard
	[40765] = true,		-- Commander Ulthok
	[61634] = true,		-- Commander Vo'jak
	[  645] = true,		-- Cookie
	[43438] = true,		-- Corborus
	[23872] = true,		-- Coren Direbrew
	[39679] = true,		-- Corla, Herald of Twilight
	[21270] = true,		-- Cosmic Infuser
	[11120] = true,		-- Crimson Hammersmith
	[ 6229] = true,		-- Crowd Pummeler 9-60
	[10376] = true,		-- Crystal Fang
	[31134] = true,		-- Cyanigosa
	[20885] = true,		-- Dalliah the Doomsayer
	[24201] = true,		-- Dalronn the Controller
	[ 6228] = true,		-- Dark Iron Ambassador
	[ 1853] = true,		-- Darkmaster Gandling (Classic)
	[59080] = true,		-- Darkmaster Gandling (Pandaria)
	[18472] = true,		-- Darkweaver Syth
	[14516] = true,		-- Death Knight Darkreaver
	[ 4428] = true,		-- Death Speaker Jargba
	[37813] = true,		-- Deathbringer Saurfang
	[35617] = true,		-- Deathstalker Visceri
	[ 3872] = true,		-- Deathsworn Captain
	[53879] = true,		-- Deathwing
	[21269] = true,		-- Devastation
	[ 5912] = true,		-- Deviate Faerie Dragon
	[36502] = true,		-- Devourer of Souls
	[ 1663] = true,		-- Dextren Ward
	[ 7057] = true,		-- Digmaster Shovelphlange
	[11261] = true,		-- Doctor Theolen Krastinov
	[18728] = true,		-- Doom Lord Kazzak
	[ 9039] = true,		-- Doom'rel
	[17711] = true,		-- Doomwalker
	[ 9040] = true,		-- Dope'rel
	[17535] = true,		-- Dorothee
	[40319] = true,		-- Drahga Shadowburner
	[29307] = true,		-- Drakkari Colossus
	[27654] = true,		-- Drakos the Interrogator
	[34799] = true,		-- Dreadscale
	[ 5721] = true,		-- Dreamscythe
	[10081] = true,		-- Dustwraith
	[35119] = true,		-- Eadric the Pure
	[ 4842] = true,		-- Earthcaller Halmgar
	[39428] = true,		-- Earthrager Ptah
	[14601] = true,		-- Ebonroc
	[54431] = true,		-- Echo of Baine
	[54641] = true,		-- Echo of Jaina
	[54123] = true,		-- Echo of Sylvanas
	[54544] = true,		-- Echo of Tyrande
	[29932] = true,		-- Eck the Ferocious
	[  639] = true,		-- Edwin VanCleef
	[34496] = true,		-- Edyis Darkbane
	[42179] = true,		-- Electron
	[29309] = true,		-- Elder Nadox
	[ 6235] = true,		-- Electrocutioner 6000
	[60410] = true,		-- Elegon
	[33993] = true,		-- Emalon the Storm Watcher
	[14889] = true,		-- Emeriss
	[ 9019] = true,		-- Emperor Dagran Thaurissan
	[15276] = true,		-- Emperor Vek'lor
	[15275] = true,		-- Emperor Vek'nilash
	[25840] = true,		-- Entropius
	[18096] = true,		-- Epoch Hunter
	[29315] = true,		-- Erekem
	[35569] = true,		-- Eressea Dawnsinger
	[34459] = true,		-- Erin Misthoof
	[40484] = true,		-- Erudax
	[40825] = true,		-- Erunak Stonespeaker
	[23420] = true,		-- Essence of Anger
	[23419] = true,		-- Essence of Desire
	[23418] = true,		-- Essence of Suffering
	[ 9029] = true,		-- Eviscerator
	[18373] = true,		-- Exarch Maladaar
	[15589] = true,		-- Eye of C'Thun
	[ 6488] = true,		-- Fallen Champion
	[38112] = true,		-- Falric
	[15510] = true,		-- Fankriss the Unyielding
	[21214] = true,		-- Fathom-Lord Karathress
	[25038] = true,		-- Felmyst
	[43687] = true,		-- Feludius
	[60009] = true,		-- Feng the Accursed
	[ 4274] = true,		-- Fenrus the Devourer
	[36626] = true,		-- Festergut
	[15930] = true,		-- Feugen
	[ 9056] = true,		-- Fineous Darkvire
	[11983] = true,		-- Firemaw
	[34497] = true,		-- Fjola Lightbane
	[11981] = true,		-- Flamegor
	[33113] = true,		-- Flame Leviathan
	[59150] = true,		-- Flameweaver Koegler
	[52442] = true,		-- Florawing Hive Queen
	[  626] = true,		-- Foreman Thistlenettle
	[36494] = true,		-- Forgemaster Garfrost
	[40177] = true,		-- Forgemaster Throngus
	[11058] = true,		-- Fras Siabi
	[32906] = true,		-- Freya
	[15114] = true,		-- Gahz'ranka
	[ 7273] = true,		-- Gahz'rilla
	[29306] = true,		-- Gal'darah
	[ 7291] = true,		-- Galgann Firehammer
	[60143] = true,		-- Gara'jal the Spiritbinder
	[63667] = true,		-- Garalon
	[12057] = true,		-- Garr
	[ 5713] = true,		-- Gasher
	[19218] = true,		-- Gatewatcher Gyro-Kill
	[19710] = true,		-- Gatewatcher Iron-Hand
	[22949] = true,		-- Gathios the Shatterer
	[12259] = true,		-- Gehennas
	[61243] = true,		-- Gekkan
	[ 6243] = true,		-- Gelihast
	[13741] = true,		-- Gelk
	[ 9033] = true,		-- General Angerforge
	[28586] = true,		-- General Bjarngrim
	[10363] = true,		-- General Drakkisath
	[44577] = true,		-- General Husam
	[61485] = true,		-- General Pa'valak
	[15341] = true,		-- General Rajaxx
	[39625] = true,		-- General Umbriss
	[33271] = true,		-- General Vezax
	[39746] = true,		-- General Zarithrian
	[ 4887] = true,		-- Ghamoo-ra
	[18105] = true,		-- Ghaz'an
	[ 9718] = true,		-- Ghok Bashguud
	[ 1763] = true,		-- Gilnid
	[34449] = true,		-- Ginselle Blightslinger
	[10268] = true,		-- Gizrul the Slavener
	[ 9037] = true,		-- Gloom'rel
	[15932] = true,		-- Gluth
	[ 8567] = true,		-- Glutton
	[11988] = true,		-- Golemagg the Incinerator
	[ 8983] = true,		-- Golem Lord Argelmach
	[10899] = true,		-- Goraluk Anvilcrack
	[34458] = true,		-- Gorgrim Shadowcleave
	[34796] = true,		-- Gormok the Impaler
	[ 9027] = true,		-- Gorosh the Dervish
	[26687] = true,		-- Gortok Palehoof
	[16060] = true,		-- Gothik the Harvester
	[20062] = true,		-- Grand Astromancer Capernian
	[62837] = true,		-- Grand Empress Shek'zeer
	[26731] = true,		-- Grand Magus Telestra
	[43878] = true,		-- Grand Vizier Ertan
	[25166] = true,		-- Grand Warlock Alythess
	[16807] = true,		-- Grand Warlock Nethekurse
	[15953] = true,		-- Grand Widow Faerlina
	[18732] = true,		-- Grandmaster Vorpil
	[15082] = true,		-- Gri'lek (Classic)
	[52258] = true,		-- Gri'lek (Cataclysm)
	[ 4854] = true,		-- Grimlok
	[ 9028] = true,		-- Grizzle
	[15931] = true,		-- Grobbulus
	[ 7361] = true,		-- Grubbis
	[19044] = true,		-- Gruul the Dragonkiller
	[56747] = true,		-- Gu Cloudstrike
	[14321] = true,		-- Guard Fengus
	[14326] = true,		-- Guard Mol'dar
	[14323] = true,		-- Guard Slip'kik
	[52440] = true,		-- Gub
	[22948] = true,		-- Gurtogg Bloodboil
	[52392] = true,		-- Gurubashi Master Chef
	[10339] = true,		-- Gyth
	[28921] = true,		-- Hadronox
	[55689] = true,		-- Hagara the Binder
	[14834] = true,		-- Hakkar
	[44600] = true,		-- Halfus Wyrmbreaker
	[23577] = true,		-- Halazzi
	[39863] = true,		-- Halion
	[10220] = true,		-- Halycon
	[ 1717] = true,		-- Hamhock
	[20912] = true,		-- Harbinger Skyriss
	[34450] = true,		-- Harkzog
	[ 9034] = true,		-- Hate'rel
	[15083] = true,		-- Hazza'rah (Classic)
	[52271] = true,		-- Hazza'rah (Cataclysm)
	[ 5722] = true,		-- Hazzas
	[23682] = true,		-- Headless Horseman
	[10558] = true,		-- Hearthsinger Forresten
	[ 9032] = true,		-- Hedrum the Creeper
	[15936] = true,		-- Heigan the Unclean
	[17256] = true,		-- Hellfire Channeler
	[29311] = true,		-- Herald Volazj
	[ 3975] = true,		-- Herod
--	[31146] = true,		-- Heroic Training Dummy (for testing purposes)
	[24239] = true,		-- Hex Lord Malacrass
	[18805] = true,		-- High Astromancer Solarian
	[17975] = true,		-- High Botanist Freywinn
	[ 4542] = true,		-- High Inquisitor Fairbanks
	[ 3977] = true,		-- High Inquisitor Whitemane
	[ 9018] = true,		-- High Interrogator Gerstahn
	[18831] = true,		-- High King Maulgar
	[16062] = true,		-- Highlord Mograine
	[ 9196] = true,		-- Highlord Omokk
	[15204] = true,		-- High Marshal Whirlaxis
	[22950] = true,		-- High Nethermancer Zerevor
	[14515] = true,		-- High Priestess Arlokk
	[42333] = true,		-- High Priestess Azil
	[14517] = true,		-- High Priestess Jeklik
	[52059] = true,		-- High Priestess Kinara
	[14510] = true,		-- High Priestess Mar'li
	[10076] = true,		-- High Priestess of Thaurissan
	[14509] = true,		-- High Priest Thekal
	[14507] = true,		-- High Priest Venoxis (Classic)
	[52155] = true,		-- High Priest Venoxis (Cataclysm)
	[43612] = true,		-- High Prophet Barim
	[22887] = true,		-- High Warlord Naj'entus
	[32845] = true,		-- Hodir
	[56717] = true,		-- Hoptallus
	[59303] = true,		-- Houndmaster Braun
	[ 9319] = true,		-- Houndmaster Grebmar
	[ 3974] = true,		-- Houndmaster Loksey
	[ 5715] = true,		-- Hukku
	[17770] = true,		-- Hungarfen
	[ 9537] = true,		-- Hurley Blackbreath
	[16179] = true,		-- Hyakiss the Lurker
	[17797] = true,		-- Hydromancer Thespia
	[ 7795] = true,		-- Hydromancer Velratha
	[13280] = true,		-- Hydrospawn
	[21216] = true,		-- Hydross the Unstable
	[34797] = true,		-- Icehowl
	[29313] = true,		-- Ichoron
	[36476] = true,		-- Ick
	[43686] = true,		-- Ignacious
	[33118] = true,		-- Ignis the Furnace Master
	[22917] = true,		-- Illidan Stormrage
	[11488] = true,		-- Illyanna Ravenoak
	[11496] = true,		-- Immol'thar
	[66791] = true,		-- Imperial Vizier Zor'lok
	[32273] = true,		-- Infinite Corruptor
	[21271] = true,		-- Infinity Blades
	[23954] = true,		-- Ingvar the Plunderer
	[58633] = true,		-- Instructor Chillheart
	[10505] = true,		-- Instructor Malicia
	[16061] = true,		-- Instructor Razuvious
	[ 3983] = true,		-- Interrogator Vishas
	[28546] = true,		-- Ionar
	[34472] = true,		-- Irieth Shadowstep
	[ 7228] = true,		-- Ironaya
	[ 6489] = true,		-- Ironspine
	[16097] = true,		-- Isalien
	[39587] = true,		-- Isiset
	[ 1063] = true,		-- Jade
	[34657] = true,		-- Jaelyne Evensong
	[ 5710] = true,		-- Jammal'an the Prophet
	[60400] = true,		-- Jan-xi
	[23578] = true,		-- Jan'alai
	[10503] = true,		-- Jandice Barov
	[29310] = true,		-- Jedoga Shadowseeker
	[10509] = true,		-- Jed Runewatcher
	[11518] = true,		-- Jergosh the Invoker
	[11380] = true,		-- Jin'do the Hexxer
	[52150] = true,		-- Jin'do the Godbreaker
	[17534] = true,		-- Julianne
	[24664] = true,		-- Kael'thas Sunstrider (Magisters' Terrace)
	[19622] = true,		-- Kael'thas Sunstrider (The Eye)
	[24850] = true,		-- Kalecgos
	[ 1666] = true,		-- Kam Deepfury
	[39698] = true,		-- Karsh Steelbender
	[52422] = true,		-- Kaulema the Mover
	[34460] = true,		-- Kavina Grovesong
	[ 5401] = true,		-- Kazkaz the Unholy
	[17888] = true,		-- Kaz'rogal
	[17377] = true,		-- Keli'dan the Breaker
	[15990] = true,		-- Kel'Thuzad
	[26723] = true,		-- Keristrasza
	[18835] = true,		-- Kiggler the Crazed
	[25315] = true,		-- Kil'jaeden
	[17229] = true,		-- Kil'rek
	[27483] = true,		-- King Dred
	[11501] = true,		-- King Gordok
	[21684] = true,		-- King Llane
	[26861] = true,		-- King Ymiron
	[10506] = true,		-- Kirtonos the Herald
	[13742] = true,		-- Kolk
	[32930]	= true,		-- Kologarn	
	[35013]	= true,		-- Koralon the Flame Watcher	
	[16118] = true,		-- Kormok
	[ 3653] = true,		-- Kresh
	[36477] = true,		-- Krick
	[28684] = true,		-- Krik'thir the Gatewatcher
	[18832] = true,		-- Krosh Firehand
	[27977] = true,		-- Krystallus
	[61442] = true,		-- Kuai the Brute
	[15348] = true,		-- Kurinnaxx
	[ 3671] = true,		-- Lady Anacondra
	[16065] = true,		-- Lady Blaumeux
	[36855] = true,		-- Lady Deathwhisper
	[10502] = true,		-- Lady Illucia Barov
	[22951] = true,		-- Lady Malande
	[40586] = true,		-- Lady Naz'jar
	[25165] = true,		-- Lady Sacrolash
	[ 4831] = true,		-- Lady Sarevess
	[21212] = true,		-- Lady Vashj
	[17980] = true,		-- Laj
	[34703] = true,		-- Lana Stouthammer
	[12203] = true,		-- Landslide
	[29312] = true,		-- Lavanthor
	[32933] = true,		-- Left Arm of Kologarn
	[63099] = true,		-- Lei Shi
	[21215] = true,		-- Leotheras the Blind
	[14888] = true,		-- Lethon
	[14327] = true,		-- Lethtendris
	[27656] = true,		-- Ley-Guardian Eregos
	[34445] = true,		-- Liandra Suncaller
	[17848] = true,		-- Lieutenant Drake
	[59200] = true,		-- Lilian Voss
	[56732] = true,		-- Liu Flameheart
	[16011] = true,		-- Loatheb
	[43614] = true,		-- Lockmaw
	[28923] = true,		-- Loken
	[10504] = true,		-- Lord Alexei Barov
	[ 3669] = true,		-- Lord Cobrahn
	[14506] = true,		-- Lord Hel'nurath
	[ 9017] = true,		-- Lord Incendius
	[34780] = true,		-- Lord Jaraxxus
	[12397] = true,		-- Lord Kazzak
	[15511] = true,		-- Lord Kri
	[36612] = true,		-- Lord Marrowgar
	[ 3670] = true,		-- Lord Pythas
	[53258] = true,		-- Lord Rhyolith
	[ 9025] = true,		-- Lord Roccor
	[20060] = true,		-- Lord Sanguinar
	[ 3673] = true,		-- Lord Serpentis
	[15305] = true,		-- Lord Skwol
	[16042] = true,		-- Lord Valthalak
	[10162] = true,		-- Lord Victor Nefarius
	[12236] = true,		-- Lord Vyletongue
	[10901] = true,		-- Lorekeeper Polkelt
	[56843] = true,		-- Lorewalker Stonestep
	[ 5714] = true,		-- Loro
	[52418] = true,		-- Lost Offspring of Gahz'ranka
	[12118] = true,		-- Lucifron
	[ 3655] = true,		-- Mad Magglish
	[15952] = true,		-- Maexxna
	[27655] = true,		-- Mage-Lord Urom
	[11487] = true,		-- Magister Kalendris
	[10435] = true,		-- Magistrate Barthilas
	[11982] = true,		-- Magmadar
	[42178] = true,		-- Magmatron
	[41570] = true,		-- Magmaw
	[ 9938] = true,		-- Magmus
	[13740] = true,		-- Magra
	[17257] = true,		-- Magtheridon
	[27975] = true,		-- Maiden of Grief
	[16457] = true,		-- Maiden of Virtue
	[12018] = true,		-- Majordomo Executus
	[52571] = true,		-- Majordomo Staghelm
	[26533] = true,		-- Mal'Ganis
	[24239] = true,		-- Malacrass
	[10438] = true,		-- Maleki the Pallid
	[34456] = true,		-- Malithas Brightblade
	[41378] = true,		-- Maloriak
	[28859] = true,		-- Malygos
	[54969] = true,		-- Mannoroth
	[13739] = true,		-- Maraudos
	[10433] = true,		-- Marduk Blackpool
	[  599] = true,		-- Marisa du'Paige
	[34705] = true,		-- Marshal Jacob Alerius
	[38113] = true,		-- Marwyn
	[20063] = true,		-- Master Engineer Telonicus
	[64387] = true,		-- Master Snowdrift
	[11834] = true,		-- Maur Grimtotem
	[34454] = true,		-- Maz'dinah
	[26529] = true,		-- Meathook
	[19219] = true,		-- Mechano-Lord Capacitus
	[17796] = true,		-- Mekgineer Steamrigger
	[ 7800] = true,		-- Mekgineer Thermaplugg
	[34469] = true,		-- Melador Valestrider
	[61429] = true,		-- Meng the Demented
	[17941] = true,		-- Mennu the Betrayer
	[12237] = true,		-- Meshlok the Harvester
	[16151] = true,		-- Midnight
	[ 5717] = true,		-- Mijan
	[33350] = true,		-- Mimiron
	[ 3586] = true,		-- Miner Johnson
	[15340] = true,		-- Moam
	[18069] = true,		-- Mogor
	[35572] = true,		-- Mokra the Skullcrusher
	[29305] = true,		-- Moorabi
	[29316] = true,		-- Moragg
	[ 7357] = true,		-- Mordresh Fire Eye
	[16080] = true,		-- Mor Grayhoof
	[52405] = true,		-- Mor'Lek the Dismantler
	[55265] = true,		-- Morchok
	[15687] = true,		-- Moroes
	[21213] = true,		-- Morogrim Tidewalker
	[ 5719] = true,		-- Morphaz
	[52438] = true,		-- Mortaxx 
	[22947] = true,		-- Mother Shahraz
	[10596] = true,		-- Mother Smolderweb
	[  646] = true,		-- Mr. Smite
	[18399] = true,		-- Murkblood Twin
	[18708] = true,		-- Murmur
	[54432] = true,		-- Murozond
	[ 7608] = true,		-- Murta Grimgut
	[25741] = true,		-- M'uru
	[11447] = true,		-- Mushgog
	[ 3654] = true,		-- Mutanus the Devourer
	[23576] = true,		-- Nalorakk
	[34453] = true,		-- Narrhok Steelbreaker
	[17536] = true,		-- Nazan
	[41376] = true,		-- Nefarian (Blackwing Decent)
	[11583] = true,		-- Nefarian (Blackwing Lair)
	[ 7796] = true,		-- Nekrum Gutchewer
	[10437] = true,		-- Nerub'enkan
	[19221] = true,		-- Nethermancer Sepethrea
	[15689] = true,		-- Netherspite
	[21268] = true,		-- Netherstrand Longbow
	[18344] = true,		-- Nexus-Prince Shaffar
	[45871] = true,		-- Nezir
	[17225] = true,		-- Nightbane
	[34468] = true,		-- Noozle Whizzlestick
	[15954] = true,		-- Noth the Plaguebringer
	[26631] = true,		-- Novos the Summoner
	[13282] = true,		-- Noxxion
	[ 7023] = true,		-- Obsidian Sentinel
	[52363] = true,		-- Occu'thar
	[ 4279] = true,		-- Odo the Blindwatcher
	[ 5711] = true,		-- Ogom the Wretched
	[14988] = true,		-- Ohgan
	[ 9030] = true,		-- Ok'thor the Breaker
	[ 4830] = true,		-- Old Serra'kis
	[18834] = true,		-- Olm the Summoner
	[57963] = true,		-- Ook-Ook
	[37215] = true,		-- Orgrim's Hammer
	[17308] = true,		-- Omor the Unscarred
	[10184] = true,		-- Onyxia
	[26794] = true,		-- Ormorok the Tree-Shaper
	[ 7606] = true,		-- Oro Eyegouge
	[15339] = true,		-- Ossirian the Unscarred
	[15517] = true,		-- Ouro
	[ 4420] = true,		-- Overlord Ramtusk
	[ 9568] = true,		-- Overlord Wyrmthalak
	[ 9026] = true,		-- Overmaster Pyron
	[42188] = true,		-- Ozruk
	[40655] = true,		-- Ozumat
	[18341] = true,		-- Pandemonius
	[ 8923] = true,		-- Panzor the Invincible
	[16028] = true,		-- Patchwerk
	[19220] = true,		-- Pathaleon the Calculator
	[55085] = true,		-- Peroth'arn
	[ 9502] = true,		-- Phalanx
	[21273] = true,		-- Phaseshift Bulwark
	[14349] = true,		-- Pimgib
	[ 7356] = true,		-- Plaguemaw the Rotting
	[ 9499] = true,		-- Plugger Spazzring
	[11143] = true,		-- Postmaster Malown
	[24560] = true,		-- Priestess Delrissa
	[23953] = true,		-- Prince Keleseth (Utgarde Keep)
	[37972] = true,		-- Prince Keleseth (Icecrown Citadel)
	[15690] = true,		-- Prince Malchezaar
	[15203] = true,		-- Prince Skaldrenox
	[15509] = true,		-- Princess Huhuran
	[ 8929] = true,		-- Princess Moira Bronzebeard
	[14457] = true,		-- Princess Tempestria
	[12201] = true,		-- Princess Theradras
	[15543] = true,		-- Princess Yauj
	[29308] = true,		-- Prince Taldaram (Ahn'kahet: The Old Kingdom)
	[37973] = true,		-- Prince Taldaram (Icecrown Citadel)
	[11486] = true,		-- Prince Tortheldrin
	[37970] = true,		-- Prince Valanar
	[36678] = true,		-- Professor Putricide
	[60583] = true,		-- Protector Kaolan
	[22035]	= true,		-- Pure Spawn of Hydross
	[14354] = true,		-- Pusillin
	[ 9816] = true,		-- Pyroguard Emberseer
	[ 9024] = true,		-- Pyromancer Loregrain
	[17942] = true,		-- Quagmirran
	[ 9736] = true,		-- Quartermaster Zigris
	[54853] = true,		-- Queen Azshara
	[17767] = true,		-- Rage Winterchill
	[ 7354] = true,		-- Ragglesnout
	[11502] = true,		-- Ragnaros (Classic)
	[52409] = true,		-- Ragnaros (Cataclysm)
	[61117] = true,		-- Raigonn
	[39378] = true,		-- Rajh
	[10439] = true,		-- Ramstein the Gorger
	[10508] = true,		-- Ras Frostwhisper
	[11622] = true,		-- Rattlegore (Classic)
	[56906] = true,		-- Rattlegore (Pandaria)
	[ 3886] = true,		-- Razorclaw the Butcher
	[12435] = true,		-- Razorgore the Untamed
	[12258] = true,		-- Razorlash
	[33186] = true,		-- Razorscale
	[15084] = true,		-- Renataki (Classic)
	[52269] = true,		-- Renataki (Cataclysm)
	[ 3914] = true,		-- Rethilgore
	[17261] = true,		-- Restless Skeleton
	[ 6910] = true,		-- Revelosh
	[  644] = true,		-- Rhahk'Zor
	[ 9543] = true,		-- Ribbly Screwspigot
	[32934] = true,		-- Right Arm of Kologarn
	[36661] = true,		-- Rimefang
	[17546] = true,		-- Roar
	[45872] = true,		-- Rohash
	[16181] = true,		-- Rokad the Ravager
	[18400] = true,		-- Rokdar the Sundered Lord
	[17991] = true,		-- Rokmar the Crackler
	[39665] = true,		-- Rom'ogg Bonecrusher
	[17533] = true,		-- Romulo
	[36627] = true,		-- Rotface
	[13596] = true,		-- Rotgrip
	[34448] = true,		-- Ruj'kah
	[32927] = true,		-- Runemaster Molgeim
	[35571] = true,		-- Runok Wildmane
	[ 7797] = true,		-- Ruuzlu
	[34470] = true,		-- Saamul
	[56906] = true,		-- Saboteur Kip'tilak
	[62346] = true,		-- Galleon
	[26530] = true,		-- Salramm the Fleshcrafter
	[10080] = true,		-- Sandarr Dunereaver
	[ 7274] = true,		-- Sandfury Executioner
	[15989] = true,		-- Sapphiron
	[28860] = true,		-- Sartharion
	[24892] = true,		-- Sathrovarr the Corruptor
	[39747] = true,		-- Saviana Ragefire
	[ 3976] = true,		-- Scarlet Commander Mograine
	[36658] = true,		-- Scourgelord Tyrannus
	[ 9038] = true,		-- Seeth'rel
	[24723] = true,		-- Selin Fireheart
	[ 7604] = true,		-- Sergeant Bly
	[34474] = true,		-- Serissa Grimdabbler
	[39732] = true,		-- Setesh
	[60491] = true,		-- Sha of Anger
	[56439] = true,		-- Sha of Doubt
	[60999] = true,		-- Sha of Fear
	[56719] = true,		-- Sha of Violence
	[34463] = true,		-- Shaabad
	[22841] = true,		-- Shade of Akama
	[16524] = true,		-- Shade of Aran
	[ 5709] = true,		-- Shade of Eranikus
	[14986] = true,		-- Shade of Jin'do
	[16180] = true,		-- Shadikith the Glider
	[ 9236] = true,		-- Shadow Hunter Vosh'gajin
	[21875] = true,		-- Shadow of Leotheras
	[ 7275] = true,		-- Shadowpriest Sezz'ziz
	[30451] = true,		-- Shadron
	[53691] = true,		-- Shannox
	[12264] = true,		-- Shazzrah
	[18371] = true,		-- Shirrak the Dead Watcher
	[34475] = true,		-- Shocuul
	[44819] = true,		-- Siamat, Lord of the South Wind
	[52938] = true,		-- Siame-Quashi
	[37755] = true,		-- Sindragosa
	[45213] = true,		-- Sinestra
	[16063] = true,		-- Sir Zeliek
	[27978] = true,		-- Sjonnir The Ironshaper
	[26693] = true,		-- Skadi the Ruthless
	[11498] = true,		-- Skarr the Unbreakable
	[24200] = true,		-- Skarvald the Constructor
	[18401] = true,		-- Skra'gath
	[10393] = true,		-- Skul
	[ 3674] = true,		-- Skum
	[43214] = true,		-- Slabhide
	[29304] = true,		-- Slad'ran
	[  643] = true,		-- Sneed
	[  642] = true,		-- Sneed's Shredder
	[10264] = true,		-- Solakar Flamewreath
	[16148]	= true,		-- Spectral Death Knight
	[16149]	= true,		-- Spectral Horse
	[16150]	= true,		-- Spectral Rider
	[16127]	= true,		-- Spectral Trainee
	[ 9218] = true,		-- Spirestone Battle Lord
	[ 9219] = true,		-- Spirestone Butcher
	[ 9217] = true,		-- Spirestone Lord Magus
	[21274] = true,		-- Staff of Disintegration
	[15929] = true,		-- Stalagg
	[32867]	= true,		-- Steelbreaker
	[14322] = true,		-- Stomper Kreeg
	[10809] = true,		-- Stonespine
	[32857]	= true,		-- Stormcaller Brundir
	[17543] = true,		-- Strawman
	[56589] = true,		-- Striker Ga'dok
	[12098] = true,		-- Sulfuron Harbinger
	[22898] = true,		-- Supremus
	[26668] = true,		-- Svala Sorrowgrave
	[17826] = true,		-- Swamplord Musel'ek
	[14890] = true,		-- Taerar
	[18473] = true,		-- Talon King Ikiss
	[22036]	= true,		-- Tainted Spawn of Hydross
	[11520] = true,		-- Taragaman the Hungerer
	[56884] = true,		-- Taran Zhu
	[ 1696] = true,		-- Targorr the Dread
	[18343] = true,		-- Tavarok
	[ 6231] = true,		-- Techbot
	[39425] = true,		-- Temple Guardian Anhuur
	[17880] = true,		-- Temporus
	[11489] = true,		-- Tendris Warpwood
	[30452] = true,		-- Tenebron
	[15688] = true,		-- Terestian Illhoof
	[22871] = true,		-- Teron Gorefiend
	[43689] = true,		-- Terrastra
	[15928] = true,		-- Thaddius
	[20064] = true,		-- Thaladred the Darkener
	[59789] = true,		-- Thalnos the Soulrender
	[16064] = true,		-- Thane Korth'azz
	[10430] = true,		-- The Beast
	[17521] = true,		-- The Big Bad Wolf
	[35451] = true,		-- The Black Knight
	[17882] = true,		-- The Black Stalker
	[18168] = true,		-- The Crone
	[15691] = true,		-- The Curator
	[37813] = true,		-- The Deathbringer
	[23426] = true,		-- The Illidari Council
	[36597] = true,		-- The Lich King (Icecrown Citadel)
	[37226] = true,		-- The Lich King (Frozen Halls)
	[21217] = true,		-- The Lurker Below
	[17381] = true,		-- The Maker
	[15263] = true,		-- The Prophet Skeram
	[26632] = true,		-- The Prophet Tharon'ja
	[10507] = true,		-- The Ravenian
	[11497] = true,		-- The Razza
	[37540] = true,		-- The Skybreaker
	[10516] = true,		-- The Unforgiven
	[14454] = true,		-- The Windreaver
	[ 7272] = true,		-- Theka the Martyr
	[45993] = true,		-- Theralion
	[21920] = true,		-- Tidewalker Lurker
	[32865] = true,		-- Thorim
	[17978] = true,		-- Thorngrin the Tender
	[34444] = true,		-- Thrakgar
	[10808] = true,		-- Timmy the Cruel
	[17547] = true,		-- Tinhead
	[13601] = true,		-- Tinkerer Gizlock
	[17548] = true,		-- Tito
	[52414] = true,		-- Tor-Tun
	[42180] = true,		-- Toxitron
	[28234] = true,		-- Tribunal of the Ages
	[ 3652] = true,		-- Trigore the Lasher
	[26630] = true,		-- Trollgore
	[11467] = true,		-- Tsu'zee
	[62442] = true,		-- Tsulong
	[ 7355] = true,		-- Tuten'kash
	[ 4832] = true,		-- Twilight Lord Kelris
	[34461] = true,		-- Tyrius Duskblade
	[55294]	= true,		-- Ultraxion
	[16125]	= true,		-- Unrelenting Death Knight
	[16126]	= true,		-- Unrelenting Rider
	[16124]	= true,		-- Unrelenting Trainee
	[10584] = true,		-- Urok Doomhowl
	[13020] = true,		-- Vaelastrasz the Corrupt
	[36789] = true,		-- Valithria Dreamwalker 
	[27447] = true,		-- Varos Cloudstrider
	[17537] = true,		-- Vazruden
	[10432] = true,		-- Vectus
	[34465] = true,		-- Velanaa Malithas
	[45992] = true,		-- Valiona
	[15544] = true,		-- Vem
	[13738] = true,		-- Veng
	[22952] = true,		-- Veras Darkshadow
	[ 5775] = true,		-- Verdan the Everliving
	[ 9042] = true,		-- Verek
	[30449] = true,		-- Vesperon
	[24744] = true,		-- Vexallus
	[ 5399] = true,		-- Veyzhak the Cannibal
	[ 9036] = true,		-- Vile'rel
	[15299] = true,		-- Viscidus
	[ 7079] = true,		-- Viscous Fallout
	[34441] = true,		-- Vivienne Blackwhisper
	[61567] = true,		-- Vizier Jin'bak
	[19516] = true,		-- Void Reaver
	[52924] = true,		-- Vol'jin
	[28587] = true,		-- Volkhan
	[16809] = true,		-- Warbringer O'mrogg
	[21752] = true,		-- Warchief Blackhand
	[16808] = true,		-- Warchief Kargath Bladefist
	[10429] = true,		-- Warchief Rend Blackhand
	[20904] = true,		-- Warden Mellichar
	[ 9041] = true,		-- Warder Stilgiss
	[17798] = true,		-- Warlord Kalithresh
	[55308] = true,		-- Warlord Zon'ozz
	[ 9237] = true,		-- War Master Voone
	[56427] = true,		-- Warmaster Blackhorn
	[18402] = true,		-- Warmaul Champion
	[21272] = true,		-- Warp Slicer
	[17977] = true,		-- Warp Splinter
	[17306] = true,		-- Watchkeeper Gargolmar
	[ 5720] = true,		-- Weaver
	[65501] = true,		-- Wind Lord Mel'jarak
	[62205] = true,		-- Wing Leader Ner'onok
	[56787] = true,		-- Wise Mari
	[52925] = true,		-- Witch Doctor T'wansi
	[ 7271] = true,		-- Witch Doctor Zum'rah
	[ 3927] = true,		-- Wolf Master Nandos
	[20886] = true,		-- Wrath-Scryer Soccothrates
	[15085] = true,		-- Wushoolay (Classic)
	[52286] = true,		-- Wushoolay (Cataclysm)
	[29266] = true,		-- Xevozz
	[61884]	= true,		-- Xin the Weaponmaster
	[33293] = true,		-- XT-002 Deconstructor
	[59479] = true,		-- Yan-Zhu the Uncasked
	[33288] = true,		-- Yogg-Saron
	[55312] = true,		-- Yor'sahj the Unsleeping
	[14887] = true,		-- Ysondre
	[52053] = true,		-- Zanzil
	[ 5400] = true,		-- Zekkis
	[17830] = true,		-- Zelemar the Wrathful
	[20870] = true,		-- Zereketh the Unbound
	[10082] = true,		-- Zerillis
	[11490] = true,		-- Zevrim Thornhoof
	[ 5712] = true,		-- Zolo
	[23863] = true,		-- Zul'jin
	[ 5716] = true,		-- Zul'Lor
	[35570] = true,		-- Zul'tore
	[29314] = true		-- Zuramat the Obliterator
};

LOOTSTER_BOSS_TLB =
{
	[34466]	= 34467,	-- Anthar Forgemender
	[43688] = 43735,	-- Arion
	[34471]	= 34467,	-- Baelnor Lightbearer
	[18836]	= 18831,	-- Blindeye the Seer
	[34473]	= 34467,	-- Brienna Nightfell
	[34455]	= 34451,	-- Broln Stouthorn
	[34447]	= 34451,	-- Caiphus the Stern
	[60051]	= 60047,	-- Cobalt Guardian
	[34701]	= 34702,	-- Colosos
	[17535] = 18168,	-- Dorothee
	[34799] = 35144,	-- Dreadscale
	[60586] = 60583,	-- Elder Asani
	[60585] = 60583,	-- Elder Regail
	[42179] = 42166,	-- Electron
	[15275]	= 15276,	-- Emperor Vek'nilash
	[35569]	= 35617,	-- Eressea Dawnsinger
	[34459]	= 34451,	-- Erin Misthoof
	[23420]	= 23418,	-- Essence of Anger
	[23419]	= 23418,	-- Essence of Desire
	[43687] = 43735,	-- Feludius
	[15930]	= 15928,	-- Feugen
	[34497] = 34496,	-- Fjola Lightbane
	[34449]	= 34451,	-- Ginselle Blightslinger
	[61340]	= 61243,	-- Glintrok Hexxer
	[61337]	= 61243,	-- Glintrok Ironhide
	[61339]	= 61243,	-- Glintrok Oracle
	[61338]	= 61243,	-- Glintrok Skulker
	[34458]	= 34451,	-- Gorgrim Shadowcleave
	[34796] = 35144,	-- Gormok the Impaler
	[61445]	= 61442,	-- Haiyan the Unstoppable
	[34450]	= 34451,	-- Harkzog
	[17256]	= 17257,	-- Hellfire Channeler
	[22950] = 22949,	-- High Nethermancer Zerevor
	[34797] = 35144,	-- Icehowl
	[36476] = 36477,	-- Ick
	[43686] = 43735,	-- Ignacious
	[58664] = 58633,	-- Instructor Chillheart's Phylactery
	[34472]	= 34467,	-- Irieth Shadowstep
	[60043]	= 60047,	-- Jade Guardian
	[34657]	= 34702,	-- Jaelyne Evensong
	[59915]	= 60047,	-- Jasper Guardian
	[17534]	= 17533,	-- Julianne
	[34460]	= 34467,	-- Kavina Grovesong
	[18835]	= 18831,	-- Kiggler the Crazed
	[21684] = 21684,	-- King Llane
	[18832]	= 18831,	-- Krosh Firehand
	[16065]	= 30549,	-- Lady Blaumeux
	[22951] = 22949,	-- Lady Malande
	[34703]	= 34702,	-- Lana Stouthammer
	[32933]	= 32930,	-- Left Arm of Kologarn
	[34445]	= 34451,	-- Liandra Suncaller
	[10162] = 11583,	-- Lord Victor Nefarius
	[42178] = 42166,	-- Magmatron
	[34456]	= 34451,	-- Malithas Brightblade
	[34705]	= 34702,	-- Marshal Jacob Alerius
	[34454]	= 34451,	-- Maz'dinah
	[34469]	= 34467,	-- Melador Valestrider
	[61444]	= 61442,	-- Ming the Cunning
	[35572]	= 35617,	-- Mokra the Skullcrusher
	[34453]	= 34451,	-- Narrhok Steelbreaker
	[45871] = 45870,	-- Nezir
	[34468]	= 34467,	-- Noozle Whizzlestick
	[14988]	= 11382,	-- Ohgan
	[18834]	= 18831,	-- Olm the Summoner
	[37973] = 37972,	-- Prince Taldaram (Icecrown Citadel)
	[37970] = 37972,	-- Prince Valanar
	[15543]	= 15511,	-- Princess Yauj
	[22035]	= 21216,	-- Pure Spawn of Hydross
	[61423]	= 61429,	-- Qiang the Merciless
	[60399]	= 60400,	-- Qin-xi
	[32934]	= 32930,	-- Right Arm of Kologarn
	[36661]	= 36658,	-- Rimefang
	[45872] = 45870,	-- Rohash
	[34448]	= 34451,	-- Ruj'kah
	[35571]	= 35617,	-- Runok Wildmane
	[34470]	= 34467,	-- Saamul
	[34474]	= 34467,	-- Serissa Grimdabbler
	[34463]	= 34467,	-- Shaabad
	[14986]	= 11380,	-- Shade of Jin'do
	[34475]	= 34467,	-- Shocuul
	[16063]	= 30549,	-- Sir Zeliek
	[24200]	= 24201,	-- Skarvald the Constructor
	[16148]	= 16060,	-- Spectral Death Knight
	[16149]	= 16060,	-- Spectral Horse
	[16150]	= 16060,	-- Spectral Rider
	[16127]	= 16060,	-- Spectral Trainee
	[15929]	= 15928,	-- Stalagg
	[32867]	= 32927,	-- Steelbreaker
	[32857]	= 32927,	-- Stormcaller Brundir
	[17543] = 18168,	-- Strawman
	[22036]	= 21216,	-- Tainted Spawn of Hydross
	[43689] = 43735,	-- Terrastra
	[16064]	= 30549,	-- Thane Korth'azz
	[45993] = 45992,	-- Theralion
	[34444]	= 34451,	-- Thrakgar
	[17547] = 18168,	-- Tinhead
	[17548] = 18168,	-- Tito
	[42180] = 42166,	-- Toxitron
	[34461]	= 34467,	-- Tyrius Duskblade
	[16125]	= 16060,	-- Unrelenting Death Knight
	[16126]	= 16060,	-- Unrelenting Rider
	[16124]	= 16060,	-- Unrelenting Trainee
	[34465]	= 34467,	-- Velanaa Malithas
	[22952] = 22949,	-- Veras Darkshadow
	[15544]	= 15511,	-- Vem
	[34441]	= 34451,	-- Vivienne Blackwhisper
	[61421]	= 61429,	-- Zian of the Endless Shadow
	[35570]	= 35617		-- Zul'tore
};

LOOTSTER_BOSS_FAKESRC =
{
	[10440]	= { { Select=9, Test=17467 } },									-- Baron Rivendare (Stratholme) -> Unholy Aura
	[24882]	= { { Select=9, Test=45141 } },									-- Brutallus -> Burn
	[28586]	= {
				{ Select=9, Test=52097 },									-- General Bjarngrim -> Temporary Electrical Charge
				{ Select=9, Test=52098 }									-- General Bjarngrim -> Charge Up
			  },
	[15931]	= { { Select=9, Test=28280 } },									-- Grobbulus -> Bombard Slime
	[28921]	= {
				{ Select=7, Test=nil },										-- Hadronox -> <no target>
				{ Select=8, Test=0xa28 },									-- Hadronox -> Anub'ar Champion, Anub'ar Crypt Fiend, Anub'ar Necromancer (Neutral)
				{ Select=8, Test=0xa48 }									-- Hadronox -> Anub'ar Champion, Anub'ar Crypt Fiend, Anub'ar Necromancer, Hadronox (Hostile)
			  },
	[10504]	= { { Select=9, Test=17467 } },									-- Lord Alexei Barov -> Unholy Aura
	[30451]	= { { Select=9, Test=58105 } },									-- Shadron -> Power of Shadron
	[27978]	= {
				{ Select=9, Test=50831 },									-- Sjonnir The Ironshaper -> Lightning Shield
				{ Select=9, Test=59845 }									-- Sjonnir The Ironshaper -> Lightning Shield (Heroic)
			  },
	[30452]	= { { Select=9, Test=61248 } },									-- Tenebron -> Power of Tenebron
	[26630]	= { { Select=8, Test=0xa48 } },									-- Trollgore -> Drakkari Invader
	[30449]	= { { Select=9, Test=61251 } }									-- Vesperon -> Power of Vesperon
};

LOOTSTER_BOSS_FAKEDST =
{
	[33113]	= {
				{ Select=9, Test=65075 },									-- Flame Leviathan -> Tower of Flames
				{ Select=9, Test=65077 },									-- Flame Leviathan -> Tower of Frost
				{ Select=9, Test=64482 },									-- Flame Leviathan -> Tower of Life
				{ Select=9, Test=65076 }									-- Flame Leviathan -> Tower of Storms
			  },
	[28921]	= {
				{ Select=5, Test=0xa28 },									-- Hadronox -> Anub'ar Champion, Anub'ar Crypt Fiend, Anub'ar Necromancer (Neutral)
				{ Select=5, Test=0xa48 }									-- Hadronox -> Anub'ar Champion, Anub'ar Crypt Fiend, Anub'ar Necromancer, Hadronox (Hostile)
			  },
	[26630]	= { { Select=5, Test=0xa48 } }									-- Trollgore -> Drakkari Invader
};

LOOTSTER_BOSS_KILL =
{
	[35144]	= { [35144]=1, [34799]=1, [34796]=1, [34797]=1 },				-- Acidmaw -> Northrend Beasts
	[34467]	= {																-- Alyssia Moonstalker -> Alliance Crusaders
				[34467]=1, [34466]=1, [34471]=1, [34473]=1, [34472]=1,
				[34460]=1, [34469]=1, [34468]=1, [34470]=1, [34474]=1,
				[34463]=1, [34475]=1, [34461]=1, [34465]=1, Count10=6, Count25=10
			  },
	[34702]	= {																-- Ambrose Boltspark -> Alliance Champions
				[34702]=1, [34701]=1, [34657]=1, [34703]=1, [34705]=1,
				Count=3
			  },
	[60047]	= { [60047]=1, [59915]=1, [60043]=1, [60047]=1 },				-- Amethyst Guardian -> The Stone Guard
	[30549]	= { [30549]=1, [16065]=1, [16063]=1, [16064]=1 },				-- Baron Rivendare (Naxxramas) -> The Four Horsemen
	[34451]	= {																-- Birana Stormhoof -> Horde Crusaders
				[34451]=1, [34455]=1, [34447]=1, [34459]=1, [34449]=1,
				[34458]=1, [34450]=1, [34445]=1, [34456]=1, [34454]=1,
				[34453]=1, [34448]=1, [34444]=1, [34441]=1, Count10=6, Count25=10
			  },
	[24201]	= { [24201]=1, [24200]=1 },										-- Dalronn the Controller -> Constructor & Controller
	[35617]	= {																-- Deathstalker Visceri -> Horde Champions
				[35617]=1, [35569]=1, [35572]=1, [35571]=1, [35570]=1,
				Count=3
			  },
	[34496]	= { [34496]=1, [34497]=1 },										-- Edyis Darkbane -> Twin Val'kyr
	[60410]	= { [60776]=6 },												-- Elegon
	[15276]	= { [15276]=1, [15275]=1 },										-- Emperor Vek'lor -> Twin Emperors
	[23418]	= { [23418]=1, [23419]=1, [23420]=1 },							-- Essence of Suffering -> Reliquary of Souls
	[22949]	= { [22949]=1, [22950]=1, [22951]=1, [22952]=1 },				-- Gathios the Shatterer -> The Illidari Council
	[61243]	= { [61243]=1, [61337]=1, [61338]=1, [61339]=1, [61340]=1 },	-- Gekkan
	[61442]	= { [61442]=1, [61444]=1, [61445]=1 },							-- Kuai the Brute -> Trial of the King
	[23954] = { [23954]=2 },												-- Ingvar the Plunderer
	[58633]	= { [58633]=1, [58664]=1 },										-- Instructor Chillheart
	[36477] = { [36477]=1 },												-- Krick -> Krick and Ick
	[15511]	= { [15511]=1, [15543]=1, [15544]=1 },							-- Lord Kri -> The Three Bugs
	[61429]	= { [61429]=1, [61421]=1, [61423]=1, [61427]=1 },				-- Meng the Demented -> The Spirit Kings
	[37972]	= { [37972]=1, [37973]=1, [37970]=1 },							-- Prince Keleseth -> Blood Princes
	[60583]	= { [60583]=1, [60585]=1, [60586]=1 },							-- Protector Kaolan -> Protectors of the Endless
	[17533]	= { [17533]=2, [17534]=2 },										-- Romulo -> Romulo & Julianne
	[32927]	= { [32927]=1, [32867]=1, [32857]=1 },							-- Runemaster Molgeim -> Assembly of Iron
	[ 3976]	= { [ 3976]=1, [ 3977]=1 },										-- Scarlet Commander Mograine
	[18168]	= { [18168]=1, [17535]=1, [17543]=1, [17547]=1, [17548]=1 },	-- The Crone -> Wizard of Oz
	[17537]	= { [17537]=1, [17536]=1 }										-- Vazruden -> Nazan & Vazruden
};

LOOTSTER_SPELL_IGNORE =
{
	[ 1130]	= true,															-- Hunter's Mark Rank 1
	[14323]	= true,															-- Hunter's Mark Rank 2
	[14324]	= true,															-- Hunter's Mark Rank 3
	[14325]	= true,															-- Hunter's Mark Rank 4
	[53338]	= true															-- Hunter's Mark Rank 5
};
