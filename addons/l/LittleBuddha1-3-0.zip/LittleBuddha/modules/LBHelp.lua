function LittleBuddha_HelpMenu()
	print('|cff388E8ELittleBuddha |cffffcc00v'..LB_Version..' |cffffffffcreated by |cffFF4500Anwyll |cffffffffof Steamwheedle Cartel|cffffffff');
	print('|cffffffffType |cffFF4500/littlebuddha <command> |cffffffffor |cffFF4500/lb <command>|cffffffff');
	print('|cff388E8EExample: |cffFF4500/lb whisper |cffffffffwill enable/disable tab flashing for the whisper channel.|cffffffff');
	print('|cff388E8ECommands: |cffFF4500version, help, status|cffffffff');
	print('|cff388E8ERegular Channels: |cffFF4500bnconversation, bnwhisper, guild, instance, instanceleader, officer, party, partyleader, raid, raidleader, whisper|cffffffff');
	print('|cff388E8EGeneral Tab Channels: |cffFF4500bnconversation_gen, bnwhisper_gen, whisper_gen');
	print('|cffffffffNote - General Tab Channels enable/disable flashing on the General Tab only.|cffffffff');
	print('|cff388E8ECustom Channels: |cffFF4500channel1, channel2, channel3, channel4, channel5, channel6, channel7, channel8, channel9, channel10|cffffffff');
end