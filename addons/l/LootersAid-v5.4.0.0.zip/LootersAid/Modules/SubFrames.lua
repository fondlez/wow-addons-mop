local _G = _G
local LootersAid = LootersAid
local L = LootersAid.L
local string, table, tonumber, format = string, table, tonumber, format
local StaticPopup_Show, UIParent = StaticPopup_Show, UIParent
local CreateFrame, GameTooltip = CreateFrame, GameTooltip

function LootersAid:CreateLootDisplayFrame()
	local frame = LootersAid.AceGUI:Create("Frame")
	frame:SetAutoAdjustHeight(false)
	frame.statustext:GetParent():Hide()
	frame.sizer_se:Hide()
	frame.sizer_s:Hide()
	frame.sizer_e:Hide()
	frame:SetHeight(360)
	frame:SetWidth(360)
	frame.frame:Hide()

	local lalogo = frame.frame:CreateTexture(nil, "ARTWORK")
	lalogo:SetSize(64, 64)
	lalogo:SetTexture("Interface\\AddOns\\LootersAid\\la")
	lalogo:SetPoint("TOPLEFT", frame.frame, 200, -40)

	local sortgroup = LootersAid.AceGUI:Create("InlineGroup")
	sortgroup:SetWidth(115)
	sortgroup:SetTitle(_G.RAID_FRAME_SORT_LABEL)
	frame:AddChild(sortgroup)
	
	local sortp, sorti
	sortp = LootersAid.AceGUI:Create("CheckBox")
	sortp:SetType("radio")
	sortp:SetValue(true)
	sortp:SetLabel(_G.PLAYER)
	sortp:SetCallback("OnValueChanged",
		function(info, event, value)
			sorti:ToggleChecked()
			LootersAid.lootsort = value and "player" or "item"
			LootersAid:sortLootRecord()
		end)
	sortgroup:AddChild(sortp)

	sorti = LootersAid.AceGUI:Create("CheckBox")
	sorti:SetType("radio")
	sorti:SetValue(false)
	sorti:SetLabel(_G.HELPFRAME_ITEM_TITLE)
	sorti:SetCallback("OnValueChanged",
		function(info, event, value)
			sortp:ToggleChecked()
			LootersAid.lootsort = value and "item" or "player"
			LootersAid:sortLootRecord()
		end)
	sortgroup:AddChild(sorti)
	
	local df = LootersAid.AceGUI:Create("InlineGroup")
	df:SetFullWidth(true)
	df:SetHeight(150)
	df:SetLayout("Fill")
	df.frame:SetScript("OnShow", function() PlaySound("igCharacterInfoOpen") end)
	df.frame:SetScript("OnHide", function() PlaySound("igCharacterInfoClose") end)

	local scroll = LootersAid.AceGUI:Create("ScrollFrame")
	scroll:SetLayout("Flow")
	df:AddChild(scroll)

	frame:AddChild(df)
	LootersAid.lootsort = "player"
	return frame, scroll
end

function LootersAid:buttonClick(frame, button)
	local spec
	local check
	local db = LootersAidDB
	local parent = frame:GetParent():GetName()
	local pname = string.sub(_G[format("%s_f1", parent)]:GetText(), 11)
	local pcount = string.sub(_G[format("%s_f2", parent)]:GetText(), 11)
	if LootersAid.testmode then db = LootersAid.testdb end
	if string.find(parent, "LAFloat") then check = LootersAid.pMainCheck:GetChecked()
	else check = LootersAid.mainCheck:GetChecked() end
	if check then spec = L["ms"]
	else spec = L["os"] end
	if button == "LA_MINUS" then pcount = pcount - 1
	elseif button == "LA_PLUS" then pcount = pcount + 1
		if pcount > -1 then pcount = nil end
	elseif button == "LA_WINNER" then LootersAid:setWinner(pname)
	elseif button == "LA_CANCEL" then
		LootersAid:forgetRoll(pname)
		LootersAid.rFrame:Hide()
		LootersAid.rFrame:Show()
	elseif button == "LA_LOOT" then
		LootersAid.lootrecordplayer = pname
		StaticPopup_Show("LOOTERSAID_LOOT")
	end

	if button == "LA_MINUS" or button == "LA_PLUS" then
		local player = format("%s_%s", spec, pname)
		db[player] = pcount
		if LootersAid.pFrame:IsVisible() then
			LootersAid.pFrame:Hide()
			LootersAid.pFrame:Show()
		end
		if LootersAid.fpFrame:IsVisible() then
			LootersAid.fpFrame:Hide()
			LootersAid.fpFrame:Show()
		end
	end
end

function LootersAid:updateScroll(numToDisplay, frame)
	local valueStep = 16
	local b1, b2, b3, pre, player, count, scores, trolls
	local parent = frame:GetParent():GetParent()
	local c1 = LootersAid.progresscolour
	local c2 = LootersAid.playercolour

	if parent == UIParent then
		scores = LootersAid.fcounts
		pre = "LAFloat_"
		b1 = "LA_MINUS"
		b2 = "LA_PLUS"
		b3 = "LA_LOOT"
		trolls = 0
	else
		if string.find(frame:GetName(), "Rolls") then
			scores = LootersAid.rolls
			trolls = 1
			b1 = "LA_WINNER"
			b2 = "LA_CANCEL"
			b3 = nil
			pre = "LARolls_"
		else
			scores = LootersAid.counts
			trolls = 0
			b1 = "LA_MINUS"
			b2 = "LA_PLUS"
			b3 = "LA_LOOT"
			pre = "LAStatic_"
		end
	end

	local numItems = #scores
	FauxScrollFrame_Update(frame, numItems, numToDisplay, valueStep)

	if numItems == 0 then
		if parent == UIParent then
			LootersAid.fnc:SetFormattedText("|cff%s%s", LootersAid.progresscolour, L["No counts yet"])
		else
			if trolls == 1 then LootersAid.nc:SetFormattedText("|cff%s%s", LootersAid.progresscolour, L["No rolls yet"])
			else LootersAid.nc:SetFormattedText("|cff%s%s", LootersAid.progresscolour, L["No counts yet"]) end
		end
		for line = 1, numToDisplay do
			local fLine = _G[format("%s%d", pre, line)]
			fLine:Hide()
		end
	else
		if parent == UIParent then LootersAid.fnc:SetText("")
		else LootersAid.nc:SetText("") end
		if trolls == 1 then table.sort(scores, function(a, b) return LootersAid:rollSort(a, b) end)
		else table.sort(scores, function(a,b) return a.playername < b.playername end) end
		for line = 1, numToDisplay do
			local linePlusOffset = line + FauxScrollFrame_GetOffset(frame)
			local fLine = _G[format("%s%d", pre, line)]
			if linePlusOffset <= numItems then
				local pretmp = format("%s%d_", pre, line)
				local tmp = scores[linePlusOffset]
				if trolls == 1 then player = tmp.player
					if string.sub(player,1 ,1) == "_" then
						player = string.sub(player, 2)
						c1 = "ff0000"
						c2 = "ff0000"
					end
				else player = tmp.playername end
				if trolls == 1 then count = tmp.playerroll
				else count = tmp.count
					if LootersAidMain:IsVisible() then
						if LootersAid:isEligible(player) or LootersAid.testmode then
							c1 = LootersAid.progresscolour
							c2 = LootersAid.playercolour
						else
							c1 = "ff0000"
							c2 = "ff0000"
						end
					else
						c1 = LootersAid.progresscolour
						c2 = LootersAid.playercolour
					end
				end

				_G[format("%sf1", pretmp)]:SetFormattedText("|cff%s%s", c1, player)
				_G[format("%sf2", pretmp)]:SetFormattedText("|cff%s%s", c2, count)
				_G[format("%sb1", pretmp)]:SetScript("OnClick", function(this) LootersAid:buttonClick(this, b1) end)
				_G[format("%sb2", pretmp)]:SetScript("OnClick", function(this) LootersAid:buttonClick(this, b2) end)

				if b3 then _G[format("%sb3", pretmp)]:SetScript("OnClick", function(this) LootersAid:buttonClick(this, b3) end) end
				if trolls == 1 and c1 == "ff0000" then _G[format("%sb1", pretmp)]:Hide()
				else _G[format("%sb1", pretmp)]:Show() end
				fLine:Show()
			else fLine:Hide() end
		end
	end
end

function LootersAid:createLine(parent, button1, button2, button3, linename)
	local frame = CreateFrame("Frame", linename, parent)
	local f1 = frame:CreateFontString("$parent_f1", "ARTWORK", "GameFontNormal")
	local f2 = frame:CreateFontString("$parent_f2", "ARTWORK", "GameFontNormal")
	local b1, b2, b3, txt

	frame:SetHeight(16)
	frame:SetWidth(LootersAid.LApWidth)

	f1:SetPoint("LEFT", frame, "LEFT")
	f1:Show()

	f2:SetPoint("LEFT", frame, LootersAid.LApWidth - 105, 0)
	f2:Show()

	if button1 == "LA_MINUS" then
		b1 = CreateFrame("Button", "$parent_b1", frame, "LootersAidMinusButtonTemplate")
		local function b1mOnEnter(this)
			GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
			txt = format(L["Change %s to %d"], f1:GetText(), (tonumber(string.sub(f2:GetText(), 11)) -1))
			txt = string.gsub(txt, "ff0000", "ffffff")
			GameTooltip:SetText(txt, 1, 1, 1)
		end
		b1:SetScript("OnEnter", function(this) b1mOnEnter(this) end)
	elseif button1 == "LA_WINNER" then
		b1 = CreateFrame("Button", "$parent_b1", frame, "LootersAidWinnerButtonTemplate")
		local function b1OnEnter(this)
			GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
			txt = format(L["Set winner to %s"], f1:GetText())
			txt = string.gsub(txt, "ff0000", "ffffff")
			GameTooltip:SetText(txt, 1, 1, 1)
		end
		b1:SetScript("OnEnter", function(this) b1OnEnter(this) end)
	end

	local function b1OnLeave() GameTooltip:Hide() end
	b1:SetScript("OnLeave", b1OnLeave)

	if button2 == "LA_PLUS" then
		b2 = CreateFrame("Button", "$parent_b2", frame, "LootersAidPlusButtonTemplate")
		local function b2mOnEnter(this)
			GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
			txt = format(L["Change %s to %d"], f1:GetText(), (tonumber(string.sub(f2:GetText(), 11))) + 1)
			txt = string.gsub(txt, "ff0000", "ffffff")
			GameTooltip:SetText(txt, 1, 1, 1)
		end
		b2:SetScript("OnEnter", function(this) b2mOnEnter(this) end)
	elseif button2 == "LA_CANCEL" then
		b2 = CreateFrame("Button", "$parent_b2", frame, "LootersAidCancelButtonTemplate")
		local function b2OnEnter(this)
			GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
			txt = format(L["Cancel %s's roll"], f1:GetText())
			txt = string.gsub(txt, "ff0000", "ffffff")
			GameTooltip:SetText(txt, 1, 1, 1)
		end
		b2:SetScript("OnEnter", function(this) b2OnEnter(this) end)
	end

	local function b2OnLeave() GameTooltip:Hide() end
	b2:SetScript("OnLeave", b2OnLeave)

	if button3 then
		b3 = CreateFrame("Button", "$parent_b3", frame)
		b3:SetSize(16, 16)
		b3:SetDisabledTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Disabled")
		b3:SetNormalTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up")
		b3:SetPushedTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Disabled")
		b3:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
		local function b3OnEnter(this)
			GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
			txt = format(L["Show %s's loot record"], f1:GetText())
			txt = string.gsub(txt, "ff0000", "ffffff")
			GameTooltip:SetText(txt, 1, 1, 1)
		end
		b3:SetScript("OnEnter", function(this) b3OnEnter(this) end)
		b3:SetScript("OnLeave", b2OnLeave)
	end

	b1:SetSize(13, 13)
	b1:SetPoint("LEFT", frame, "LEFT", LootersAid.LApWidth - 80, 0)
	b1:Show()

	if button2 == "LA_CANCEL" then
		b2:SetSize(32, 32)
		b2:SetPoint("LEFT", frame, "LEFT", LootersAid.LApWidth - 65, 0)
	else
		b2:SetSize(13, 13)
		b2:SetPoint("LEFT", frame, "LEFT", LootersAid.LApWidth - 60, 0)
	end
	b2:Show()
	if button3 then
		b3:SetSize(13, 13)
		b3:SetPoint("LEFT", b2, "RIGHT", 10, 0)
	end
	return frame
end

function LootersAid:placeLines(frame, lines, ltype)
	local b1, b2, b3, ypos, pre
	if lines == 8 then
		pre = "LAFloat_"
		ypos = -75
	else
		if ltype == "LA_ROLLS" then pre = "LARolls_"
		else pre = "LAStatic_" end
		ypos = -35
	end
	if ltype == "LA_COUNTS" then
		b1 = "LA_MINUS"
		b2 = "LA_PLUS"
		b3 = "LA_LOOT"
	elseif ltype == "LA_ROLLS" then
		b1 = "LA_WINNER"
		b2 = "LA_CANCEL"
		b3 = nil
	end
	for c = 1, lines do
		local tmp = LootersAid:createLine(frame, b1, b2, b3, format("%s%d", pre, c))
		tmp:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, ypos)
		tmp:Hide()
		ypos = ypos - 20
	end
end

function LootersAid:scrollfunction(parent)
	local disp, pre
	if parent:GetParent():GetParent() == UIParent then
		disp = 8
		pre = "LAFloat_"
	else
		disp = 10
		pre = "LAStatic_"
	end
	LootersAid:updateScroll(disp, parent, pre)
end

function LootersAid:createScrollFrame(parent, name)
	local frame = CreateFrame("ScrollFrame", name, parent, "FauxScrollFrameTemplate")
	local itemHeight = 16
	frame:SetScript("OnVerticalScroll", function(this, offset) FauxScrollFrame_OnVerticalScroll(this, offset, itemHeight, function() LootersAid:scrollfunction(frame) end) end)
	frame:EnableMouseWheel(true)
	frame:SetScript("OnMouseWheel", ScrollFrameTemplate_OnMouseWheel)
	return frame
end

function LootersAid:createPlayersFrame(parent, framename)
	local frame = CreateFrame("Frame", framename, parent)
	local sframe, lines
	local closeButton = CreateFrame("Button", "LootersAidPlayerClose", frame, "UIPanelCloseButton")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local offCheck, mainText, offText, soffset

	if parent == UIParent then
		LootersAid.fnc = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		LootersAid.pMainCheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
		mainText = LootersAid.pMainCheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		offCheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
		offText = offCheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		soffset = -75
		sframe = LootersAid:createScrollFrame(frame, framename .. "floatscroll")
		lines = 8
	else
		LootersAid.nc = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		soffset = -35
		sframe = LootersAid:createScrollFrame(frame, framename .. "staticscroll")
		lines = 10
	end

	frame:Hide()
	frame:SetMovable(false)
	frame:EnableMouse(true)
	frame:EnableKeyboard(true)
	frame:SetClampedToScreen(true)
	frame:SetHeight(LootersAid.LApHeight)
	frame:SetWidth(LootersAid.LApWidth)
	frame:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = {left = 4, right = 4, top = 4, bottom = 4}})

	sframe:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, soffset)
	sframe:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, 8)

	if (string.find(framename, "Rolls")) then LootersAid:placeLines(frame, lines, "LA_ROLLS")
	else
		LootersAid:placeLines(frame, lines, "LA_COUNTS")
		frame:SetWidth(frame:GetWidth() + 20)
	end

	local function frameOnShow(this)
		this:SetBackdropColor(0,0,0,0.9)
		if (string.find(this:GetName(), "Players")) then
			LootersAid:refreshCounts()
			LootersAid:getCount()
		else LootersAid.pFrameIsShown = 0 end
		LootersAid:scrollfunction(sframe)
	end

	if parent == UIParent then
		local function radioOnClick(chk1, chk2)
			if chk1:GetChecked() and chk2:GetChecked() then
				chk2:SetChecked(false)
				LootersAid:getCount()
				if LootersAid.pFrame:IsVisible() then
					LootersAid.pFrame:Hide()
					LootersAid.pFrame:Show()
				end
				if LootersAid.fpFrame:IsVisible() then
					LootersAid.fpFrame:Hide()
					LootersAid.fpFrame:Show()
				end
			end
		end

		LootersAid.pMainCheck:SetPoint("TOPLEFT", frame, "TOPLEFT", 25, -30)
		LootersAid.pMainCheck:SetChecked(1)
		LootersAid.pMainCheck:SetScript("OnClick", function() radioOnClick(LootersAid.pMainCheck, offCheck) end)
		mainText:SetPoint("TOPLEFT", LootersAid.pMainCheck, "TOPRIGHT", 5, -5)
		mainText:SetText(L["Main Spec"])

		offCheck:SetPoint("TOPLEFT", LootersAid.pMainCheck, "TOPLEFT", 0, -20)
		offCheck:SetScript("OnClick", function() radioOnClick(offCheck, LootersAid.pMainCheck) end)
		offText:SetPoint("TOPLEFT", offCheck, "TOPRIGHT", 5, -5)
		offText:SetText(L["Off Spec"])
	end

	frame:SetScript("OnShow", function(this) frameOnShow(this) end)

	local function closeOnClick(this)
		local parent = this:GetParent()
		if parent == LootersAid.pFrame then LootersAid.pFrameIsShown = 0 end
		parent:Hide()
	end

	closeButton:SetScript("OnClick", closeOnClick)
	closeButton:SetPoint("TOPLEFT", frame, "TOPRIGHT", -32, -2)

	if string.find(framename, "Rolls") then title:SetText(L["Rolls"])
	else title:SetText(L["Counts"]) end

	if parent == UIParent then
		LootersAid.fnc:SetPoint("CENTER", frame, "CENTER", -16, 45)
		title:SetPoint("CENTER", frame, "CENTER", -16, 110)
	else
		title:SetPoint("CENTER", frame, "CENTER", -16, 110)
		LootersAid.nc:SetPoint("CENTER", frame, "CENTER", -16, 90)
	end
	return frame
end