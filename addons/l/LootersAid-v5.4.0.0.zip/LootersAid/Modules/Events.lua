local _G = _G
local LootersAid = LootersAid
local L = LootersAid.L
local GetLootThreshold, GetNumLootItems, GetLootSlotLink = GetLootThreshold, GetNumLootItems, GetLootSlotLink
local GetSavedInstanceInfo = GetSavedInstanceInfo
local string, tonumber, select, format = string, tonumber, select, format
local table, ipairs, pairs, wipe = table, ipairs, pairs, wipe
local UIDropDownMenu_AddButton, UIParent = UIDropDownMenu_AddButton, UIParent
local ChatThrottleLib, LibStub = ChatThrottleLib, LibStub
local UnitName, RequestRaidInfo = UnitName, RequestRaidInfo
local LootersAidProgress
local ClientVersion = select(4, GetBuildInfo())

function LootersAid_getDBMBoss(event, bossmod)
	LootersAid.DBMBoss = nil
	if type(bossmod) == "table" then if bossmod.combatInfo then LootersAid.DBMBoss = bossmod.combatInfo.name end end
end

function LootersAid:lootHandler()
	local threshold = GetLootThreshold()
	local idx = 1

	if LootersAid.playerloot then return end
	if LootersAid.testmode then threshold = 0 end
	LootersAid.hasLoot = 0
	LootersAid.allLoot = {}
	LootersAid.lootPos = 1

	for slot = 1, GetNumLootItems() do
		local currentLootItem = GetLootSlotLink(slot)
		if currentLootItem then
			if LootersAid:getItemQuality(slot) >= threshold then
				if (LootersAid.lootslot or "") == "" then
					LootersAid.lootitem = currentLootItem
					LootersAid:addLoot(slot)
					LootersAid.hasLoot = 1
				end

				if LootersAid.lootitem == currentLootItem then LootersAid.lootQty = LootersAid.lootQty + 1 end
				table.insert(LootersAid.allLoot, idx, {loot = currentLootItem, slot = slot})
				idx = idx + 1
			end
		end
	end

	if LootersAid.hasLoot == 1 and LootersAid:isMasterLooter() == 1 then
		if not LootersAid.lootFrame:IsVisible() then LootersAid.lootFrame:Show() end
	end
end

function LootersAid:chatHandler(chatmessage, ...)
	if LootersAid.monitorRolls == 0 and not LootersAid.testmode then return end
	-- generic (I hope) roll matching pattern
	local rolltext = "^([^%s]+)%s.+ (%d+) %((%d+)%-(%d+)%)"
	local playername, roll, lroll, hroll = string.match(chatmessage, rolltext)
	if not playername then return end

	if LootersAid.rerolling == 1 then
		if not LootersAid.p1tmp then
			LootersAid.p1tmp = LootersAid.winner
			LootersAid.p2tmp = LootersAid.second
		end
		
		if playername == LootersAid.p1tmp or playername == LootersAid.p2tmp then --valid player
		else return end
	end

	roll = tonumber(roll)
	lroll = tonumber(lroll)
	hroll = tonumber(hroll)

	--stop people trying to cheat by using /roll 100 100
	if LootersAid.rr == 1 then
		if playername == UnitName("player") then --ML is raid rolling
		else return end --someone else if rolling on a raid roll
	elseif lroll ~= 1 or hroll ~= 100 then
		LootersAidProgress:AddMessage(format(L["Ignored illegal roll from %s (%d-%d)"], playername, lroll, hroll), 1, 0, 0, 1)
		if not LootersAid.db.profile.disableill then
			if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format(L["Ignored illegal roll from %s (%d-%d)"], playername, lroll, hroll), 0, 1, 0)
			else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(L["Ignored illegal roll from %s (%d-%d)"], playername, lroll, hroll), "RAID_WARNING", nil, nil) end
		end
		return
	end

	if not LootersAid.lootFrame:IsVisible() == nil then return end

	--check for rolls from invalid classes
	local ell
	if LootersAid.db.profile.classcheck and LootersAid.rr == 0 then ell = LootersAid:isEligibleClass(playername)
		if ell ~= 1 then
			LootersAidProgress:AddMessage(format("%s - %s (%s)", format(L["Received a roll of %d from %s"], roll, playername), L["ineligible"], _G.CLASS), 1, 0, 0, 1)
			return
		end
	end

	--check for rolls from invalid ranks
	if LootersAid.db.profile.useranks and LootersAid.rr == 0 then ell = LootersAid:isEligibleRank(playername)
		if not ell then
			LootersAidProgress:AddMessage(format("%s - %s (%s)", format(L["Received a roll of %d from %s"], roll, playername), L["ineligible"], _G.RANK), 1, 0, 0, 1)
			return
		end
	end

	if LootersAid.rr == 1 then ell = 1
	else ell = LootersAid:isEligible(playername) end

	--check for multiple LootersAid.rolls from the same player
	local dup = 0
	if LootersAid.rr == 0 then
		for i, rc in ipairs(LootersAid.rollcheck) do
			if rc == playername then --duplicate roll found	
				dup = i
				break
			end
		end
	end

	if dup ~= 0 then
		local dupl = format(L["Multiple rolls detected from %s! Last roll ignored!"], playername)
		LootersAidProgress:AddMessage(dupl, 1, 0, 0, 1)
		if not LootersAid.db.profile.disablerw then
			if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format(L["Multiple rolls detected from %s! Last roll ignored!"], playername), 0, 1, 0)
			else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(L["Multiple rolls detected from %s! Last roll ignored!"], playername), "RAID_WARNING", nil, nil) end
		end
		return
	else if LootersAid.rr == 0 then table.insert(LootersAid.rollcheck, playername) end end

	-- update the LootersAid.rolls table
	if ell or LootersAid.testmode then table.insert(LootersAid.rolls, {player = playername, playerroll = roll})
	else table.insert(LootersAid.rolls, {player = format("_%s", playername), playerroll = roll}) end

	-- show a message to prove we've spotted the roll
	local msg = format("|cff%s", LootersAid.progresscolour)
	if ell then
		msg = format("%s%s", msg, format(L["Received a roll of %d from %s"], roll, playername))
		LootersAidProgress:AddMessage(msg)
	else
		LootersAidProgress:AddMessage(format("%s - %s (%s)", format(L["Received a roll of %d from %s"], roll, playername), L["ineligible"], _G.LFG_TYPE_ZONE), 1, 0, 0, 1) 
	end

	-- look for LootersAid.rolls of 1 or 100 and display a message if required
	if ell and LootersAid.rr == 0 then
		if LootersAid.db.profile.usemaxmin then
			local maxt = LootersAid.db.profile.maxtext or ""
			local mint = LootersAid.db.profile.mintext or ""
			if roll == 1 then
				if string.match(mint, "%%s") then
					if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format(mint, playername), 0, 1, 0)
					else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(mint, playername), "RAID_WARNING", nil, nil) end
				end
			elseif roll == 100 then
				if string.match(maxt, "%%s") then
					if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format(maxt, playername), 0, 1, 0)
					else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(mint, playername), "RAID_WARNING", nil, nil) end
				end
			end
		end
	end
	LootersAid:analyseRolls()
end

-- *** prevent multiple whispers being sent out within 3 seconds ***
function LootersAid:wCheck(wplayer, wspec)
	local ok = 1
	local wtime = tonumber(date("%H%M%S"))
	if wplayer == LootersAid.wp and wspec == LootersAid.ws then if wtime - LootersAid.wt < 3 then ok = 0 end end
	return ok
end

-- *** listen for any !ms or !os whispers and respond to them ***
function LootersAid:whisperRespond(spec, player)
	local db = LootersAidDB
	local msg, pl = "", ""
	if LootersAid:wCheck(player, spec) == 0 then return end
	for p, c in pairs (db) do
		if p == "LARaidID" then --ignore this one
		else
			if string.sub(p, 1, 2) == spec and string.lower(string.sub(p, 4)) == player then
				msg = format(L["Looter's Aid: (%s) %s %d"], spec, string.sub(p,4), c)
				pl = player
				break
			end
		end
	end
	if msg == "" then msg = format(L["Looter's Aid: %s has not received any %s loot yet"], format("%s%s", string.upper(string.sub(player,1,1)), string.sub(player, 2)), spec) end
	ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, "WHISPER", nil, player)
	LootersAid.wt = tonumber(date("%H%M%S"))
	LootersAid.wp = player
	LootersAid.ws = spec
end

 -- *** incoming whisper filter ***
function LootersAid:whisperFilter(self, event, msg, author, ...)
	local mspattern = format("^!%s", L["ms"])
	local msgspattern = format("^|.-|r%%s!%s", L["ms"])	--fix required for gearscore
	local ospattern = format("^!%s", L["os"])
	local osgspattern = format("^|.-|r%%s!%s", L["os"])	--fix required for gearscore
	local retval = false
	if string.match(msg, mspattern) or string.match(msg, msgspattern) then
		LootersAid:whisperRespond(L["ms"], string.lower(author))
		retval = LootersAid.db.profile.hidewhispers == true
	elseif string.match(msg, ospattern) or string.match(msg, osgspattern) then
		LootersAid:whisperRespond(L["os"], string.lower(author))
		retval = LootersAid.db.profile.hidewhispers == true
	end
	return retval
end

-- *** outgoing whisper filter ***
function LootersAid:whisperInformFilter(self, event, msg, author, ...)
	local pattern = format("%s:", L["Looter's Aid"])
	local retval = false
	if string.match(msg, pattern) then retval = LootersAid.db.profile["hidewhispers"] == true end
	return retval
end

function LootersAid:updateRaidID()
	local tname, ttype, tdiff, tdiffname = GetInstanceInfo()
	for instance = 1, GetNumSavedInstances() do
		local iname, iid, ireset, idiff = GetSavedInstanceInfo(instance)
		if iname == tname and idiff == tdiff and ireset > 0 then --raid type matches the saved info
			LootersAid.WoWRaidID = iid
			LootersAidDB.WoWRaidID = iid
			break
		end
	end
end

local function CreateLDBMenu()
	local LDBMenu = CreateFrame("Frame", "LootersAidLDBMenu")
	local db
	local ptable = {}

	if LootersAid.testmode then db = LootersAid.testdb else db = LootersAidDB end
	LDBMenu.displayMode = "MENU"
	LDBMenu.info = {}
	LDBMenu.HideMenu = function() if UIDROPDOWNMENU_OPEN_MENU == LDBMenu then CloseDropDownMenus() end end
	LDBMenu.initialize = 
		function(self, level)
			if not level then return end
			local info = self.info
			local t = LootersAid:translate()
			if t == L["Nothing"] then t = L["Looter's Aid"] end
			wipe(info)
			if level == 1 then
				info.isTitle = 1
				info.text = t
				info.notCheckable = 1
				UIDropDownMenu_AddButton(info, level)

				info.keepShownOnClick = 1
				info.disabled = nil
				info.isTitle = nil

				info.text = L["Counts"]
				info.hasArrow = 1
				info.value = "counts"
				UIDropDownMenu_AddButton(info, level)

				info.text = L["Show loot record"]
				info.value = "lootRecord"
				info.hasArrow = 1
				UIDropDownMenu_AddButton(info, level)

				info.text = L["Rolls"]
				info.value = "rolls"
				info.hasArrow = 1
				UIDropDownMenu_AddButton(info, level)

				-- Close menu item
				info.hasArrow = nil
				info.value = nil
				info.text = _G.CLOSE
				info.func = self.HideMenu
				UIDropDownMenu_AddButton(info, level)
			elseif level == 2 then
				if UIDROPDOWNMENU_MENU_VALUE == "counts" then
					info.text = L["Show the counts window"]
					info.notCheckable = 1
					info.func =
						function()
							LootersAid.fpFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", LootersAid.db.profile["px"], LootersAid.db.profile["py"])
							LootersAid.fpFrame:Show()
							self.HideMenu()
						end
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Show in Raid chat"]
					info.hasArrow = 1
					info.value = "countsRaid"
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Show in Party chat"]
					info.value = "countsParty"
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Show in chat"]
					info.value = "countsChat"
					UIDropDownMenu_AddButton(info, level)
				elseif UIDROPDOWNMENU_MENU_VALUE == "lootRecord" then
					info.text = L["Show in Raid chat"]
					info.hasArrow = 1
					info.value = "lootRaid"
					info.notCheckable = 1
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Show in Party chat"]
					info.value = "lootParty"
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Show in chat"]
					info.value = "lootChat"
					UIDropDownMenu_AddButton(info, level)
					
					info.text = L["Show in UI"]
					info.value = "lootUI"
					info.hasArrow = nil
					info.func = function() LootersAid:showLootRecord(nil, nil, true) end
					UIDropDownMenu_AddButton(info, level)
				elseif UIDROPDOWNMENU_MENU_VALUE == "rolls" then
					info.text = L["Show in Raid chat"]
					info.hasArrow = nil
					info.value = nil
					info.notCheckable = 1
					info.func = function() LootersAid:printCounts("@@", "raid", 1); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)
					
					info.text = L["Show in Party chat"]
					info.func = function() LootersAid:printCounts("@@", "party", 1); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)
					
					info.text = L["Show in chat"]
					info.func = function() LootersAid:printCounts("@@","chat", 1); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)
				end
			elseif level == 3 then
				if UIDROPDOWNMENU_MENU_VALUE == "countsRaid" then
					info.text = L["Main Spec"]
					info.hasArrow = nil
					info.notCheckable = 1
					info.func = function() LootersAid:printCounts(L["ms"], "raid", 0); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Off Spec"]
					info.func = function() LootersAid:printCounts(L["os"], "raid", 0); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)
				elseif UIDROPDOWNMENU_MENU_VALUE == "countsParty" then
					info.text = L["Main Spec"]
					info.hasArrow = nil
					info.notCheckable = 1
					info.func = function() LootersAid:printCounts(L["ms"], "party", 0); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Off Spec"]
					info.func = function() LootersAid:printCounts(L["os"], "party", 0); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)
				elseif UIDROPDOWNMENU_MENU_VALUE == "countsChat" then
					info.text = L["Main Spec"]
					info.hasArrow = nil
					info.notCheckable = 1
					info.func = function() LootersAid:printCounts(L["ms"], "chat", 0); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)

					info.text = L["Off Spec"]
					info.func = function() LootersAid:printCounts(L["os"], "chat", 0); self.HideMenu() end
					UIDropDownMenu_AddButton(info, level)
				elseif UIDROPDOWNMENU_MENU_VALUE == "lootChat" or UIDROPDOWNMENU_MENU_VALUE == "lootParty" or UIDROPDOWNMENU_MENU_VALUE == "lootRaid" then
					local m = UIDROPDOWNMENU_MENU_VALUE
					if m == "lootChat" then m = "CHAT"
					elseif m == "lootParty" then m = "PARTY"
					elseif m == "lootRaid" then m = "RAID" end
					wipe(ptable)
					local f
					for p, c in pairs(db) do
						if p == "LARaidID" or p == "WoWRaidID" or string.sub(p,3, 3) == "_" then --ignore it
						elseif string.sub(p, 1, 4) == "loot" then
							f = nil
							for _, t in ipairs(ptable) do
								if t == c then
									f = true
									break
								end
							end
							if not f then table.insert(ptable, c) end
						end
					end

					if #ptable > 0 then table.insert(ptable, L["** Everyone"]) end
					table.sort(ptable)

					for _, c in ipairs(ptable) do
						info.text = c
						info.hasArrow = nil
						info.notCheckable = 1
						info.func = function() 
										if c == L["** Everyone"] then c = nil end
										LootersAid:showLootRecord(m, c)
										self.HideMenu()
									end
						UIDropDownMenu_AddButton(info, level)
					end
				end
			end
		end
end

local function LDBOnClick(self, button)
	if button == "LeftButton" then InterfaceOptionsFrame_OpenToCategory(LootersAid.OptionsFrame)
	else ToggleDropDownMenu(1, nil, LootersAidLDBMenu, self:GetName(), 0, 0) end --drop down menu
end

-- *** watch events ***
function LootersAid:eventHandler(self, event, arg1, ...)
	if event == "ADDON_LOADED" and arg1 == "LootersAid" then
		SLASH_LOOTERSAID_CMD1 = format("/%s", L["la"])
		SLASH_LOOTERSAID_CMD2 = format("/%s", L["lootersaid"])
		SlashCmdList["LOOTERSAID_CMD"] = function(input) LootersAid:chatCommand(input) end
		if not LootersAidDB then LootersAidDB = {} end
		ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", function(...) LootersAid:whisperFilter(...) end)
		ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER_INFORM", function(...) LootersAid:whisperInformFilter(...) end)

		--from www.deadlybossmods.com
		if DBM then if tonumber(DBM.Version) > 4.26 then DBM:RegisterCallback("kill", LootersAid_getDBMBoss) end end

		LootersAid.db = LibStub("AceDB-3.0"):New("LootersAidVars", LootersAid.defaults, "profile")
		LootersAid:createLootersAidOptions()

		--configure LDB
		CreateLDBMenu()
		local ldblib = LibStub:GetLibrary("LibDataBroker-1.1")
		local ldb = ldblib:NewDataObject(L["Looter's Aid"], {
			type = "data source", 
			text = L["Looter's Aid"],
			icon = "Interface\\Addons\\LootersAid\\la",
			OnClick = LDBOnClick			
		})
		function ldb.OnTooltipShow(tip)
			tip:AddLine(L["Looter's Aid"])
			tip:AddLine(" ")
			tip:AddLine(format("|cffffffff%s %s", _G.GAME_VERSION_LABEL, GetAddOnMetadata("LootersAid", "Version")))
		end
		LootersAid.mmicon = LibStub("LibDBIcon-1.0")
		LootersAid.mmicon:Register("LootersAid", ldb, LootersAid.db.profile.minimap)
	elseif event == "PLAYER_ENTERING_WORLD" then if ClientVersion >= 40100 then RegisterAddonMessagePrefix("LootersAid") end
	elseif event == "PLAYER_LOGIN" then
		LootersAid.lootFrame = LootersAid:createLAFrame()
		LootersAidProgress = _G.LootersAidProgress
		local function fpFrameMouseUp()
			LootersAid.fpFrame:StopMovingOrSizing()
			LootersAid.db.profile.px = LootersAid.fpFrame:GetLeft()
			LootersAid.db.profile.py =LootersAid.fpFrame:GetBottom()
		end
		LootersAid:refreshCounts()
		LootersAid.fpFrame = LootersAid:createPlayersFrame(UIParent, "LootersAidFloatingPlayers")
		LootersAid.fpFrame:SetMovable(true)
		LootersAid.fpFrame:SetScript("OnMouseDown", function() LootersAid.fpFrame:StartMoving() end)
		LootersAid.fpFrame:SetScript("OnMouseUp", fpFrameMouseUp)
		LootersAid.frame.TimeSinceLastUpdate = 0
		LootersAid.frame.Countdown = LootersAid.cdtimes[LootersAid.db.profile["cdtime"]]
		if LootersAid.testmode then LootersAid.rolls = LootersAid.testrolls; print("WARNING! Looters Aid test mode enabled!") end		
		--*****
		LootersAid:CreateLootDisplayFrame()
		--*****
	elseif event == "LOOT_OPENED"  then
		if not LootersAid.testmode then LootersAid.frame:RegisterEvent("CHAT_MSG_SYSTEM") end
		LootersAid:clearLoot()
		LootersAid:lootHandler()
	elseif event == "LOOT_SLOT_CLEARED" then
		LootersAid:clearLoot()
		LootersAid:lootHandler()
	elseif event == "LOOT_CLOSED" then
		if not LootersAid.testmode then LootersAid.frame:UnregisterEvent("CHAT_MSG_SYSTEM") end
		LootersAid.pFrame:Hide()
		LootersAid.lootFrame:Hide()
		LootersAid.monitorRolls = 0
		LootersAid.playerloot = nil
		if LootersAid.fpFrame:IsVisible() then
			LootersAid.fpFrame:Hide()
			LootersAid.fpFrame:Show()
		end
	elseif event == "CHAT_MSG_SYSTEM" then LootersAid:chatHandler(arg1, ...)
	elseif event == "RAID_INSTANCE_WELCOME" then
		RequestRaidInfo()
		LootersAid:checkRaidID()
	elseif event == "GROUP_ROSTER_UPDATE" or event == "RAID_ROSTER_UPDATE" then
		RequestRaidInfo()
		LootersAid.frame:UnregisterEvent("GROUP_ROSTER_UPDATE")
		LootersAid.frame:UnregisterEvent("RAID_ROSTER_UPDATE")
		LootersAid:checkRaidID()
		if LootersAid.pFrame:IsVisible() then
			LootersAid.pFrame:Hide()
			LootersAid.pFrame:Show()
		end
		if LootersAid.fpFrame:IsVisible() then
			LootersAid.fpFrame:Hide()
			LootersAid.fpFrame:Show()
		end
		if LootersAid.db.profile.useattendance then LootersAid:UpdateAttendance() end
		LootersAid.frame:RegisterEvent("GROUP_ROSTER_UPDATE")
		LootersAid.frame:RegisterEvent("RAID_ROSTER_UPDATE")
		LootersAid:checkRaidID()
	elseif event == "UPDATE_INSTANCE_INFO" then LootersAid:updateRaidID()
	elseif event == "CHAT_MSG_ADDON" then
		if arg1 == "LootersAid" then
			local msg, dist, sender = ...
			if dist == "RAID" then
				if string.lower(sender) ~= string.lower(UnitName("player")) then
					if msg == "end:end" then
						LootersAid.syncSender = sender
						StaticPopupDialogs["LOOTERSAID_RXSYNC"] = {
							text = format(L["%s is sending Looter's Aid data. Do you want to import it and overwrite any existing data?"], LootersAid.syncSender),
							button1 = _G.YES,
							button2 = _G.NO,
							OnAccept = function() LootersAid:receiveSync() end,
							timeout = 0,
							whileDead = 1,
							hideOnEscape = 1
						}
						StaticPopup_Show("LOOTERSAID_RXSYNC")
					else
						local x = string.find(msg, ":")
						local p = string.sub(msg, 1, x - 1)
						local c = string.sub(msg, x + 1)
						LootersAid.syncData[p] = c
					end
				end
			end
		end
	end
end