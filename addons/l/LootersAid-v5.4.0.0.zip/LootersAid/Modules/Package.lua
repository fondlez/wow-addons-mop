LootersAid = select(2, ...)
LootersAid.frame = CreateFrame("Frame")