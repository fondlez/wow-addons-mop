local _G = _G
local LootersAid = LootersAid
local LARC_NONE = 0
local LARC_PASS = 1
local LARC_FAIL = 2
local L = LootersAid.L
local string, tonumber, select, format = string, tonumber, select, format
local table, pairs, type = table, pairs, type
local GetMasterLootCandidate, GetLootSlotInfo = GetMasterLootCandidate, GetLootSlotInfo
local GetLootMethod, GetInstanceInfo = GetLootMethod, GetInstanceInfo
local GetLootSlotLink, GetNumLootItems, GetContainerItemInfo = GetLootSlotLink, GetNumLootItems, GetContainerItemInfo
local UnitName, UnitClass, IsInInstance = UnitName, UnitClass, IsInInstance
local UnitClassification, UnitIsFriend = UnitClassification, UnitIsFriend
local UnitInRaid, UnitIsCorpse = UnitInRaid, UnitIsCorpse
local GetGuildInfo, GetNumGroupMembers, GetRaidRosterInfo = GetGuildInfo, GetNumGroupMembers, GetRaidRosterInfo
local UIParent, CreateFrame = UIParent, CreateFrame
local DEFAULT_CHAT_FRAME = DEFAULT_CHAT_FRAME
local ChatThrottleLib = ChatThrottleLib
local ClientVersion = select(4, GetBuildInfo())

function LootersAid:UpdateAttendance()
	local raidid = LootersAid.testmode and "testraidid" or LootersAidDB.LARaidID
	local rm = ClientVersion < 50000 and GetNumRaidMembers or GetNumGroupMembers(_G.LE_PARTY_CATEGORY_HOME)
	local raiders = LootersAid.testmode and 5 or rm
	if not LootersAidDB.attendance then LootersAidDB.attendance = {} end
	for raider = 1, raiders do
		local player = LootersAid.testmode and LootersAid.testrolls[raider].player or UnitName(format("raid%d", raider))
		if player then
			if not LootersAidDB.attendance[player] then LootersAidDB.attendance[player] = {raidid = raidid, count = 1}
			elseif LootersAidDB.attendance[player].raidid ~= raidid then
				LootersAidDB.attendance[player] = {raidid = raidid, count = LootersAidDB.attendance[player].count + 1}
			end
		end
	end
end

function LootersAid:boolToString(value)
	local retval = value
	if type(value) == "boolean" then
		if value then retval = "True"
		else retval = "False" end
	end
	return retval
end

function LootersAid:isEligible(name)
	if not name then return end
	local ell, slot, pname
	local player = string.lower(name or "")
	if LootersAid.testmode then ell = 1
	else
		--ensure we have the right slot
		for s = 1, GetNumLootItems() do
			local currentLootItem = GetLootSlotLink(s)
			if currentLootItem == LootersAid.lootitem then
				slot = s
				break
			end
		end
		if not slot then
			if LootersAidProgess then
				LootersAidProgress:AddMessage(format("ERROR: Loot slot not found for %s", LootersAid.lootitem), 1, 0, 0, 1)
				LootersAidProgress:AddMessage(format("debug info: lootitems = %d", GetNumLootItems()), 1, 0, 0, 1)
			end
			return
		end
		--check for eligibility
		for p = 1, _G.MAX_RAID_MEMBERS do
			if ClientVersion < 50000 then pname = GetMasterLootCandidate(p)
			else pname = GetMasterLootCandidate(slot, p) end
			if pname then
				if string.lower(pname) == player then
					ell = p
					break
				end
			end
		end
	end
	return ell
end

function LootersAid:getBindType()
	local bindtext, bindtype
	LootersAid.tooltip = LootersAid.tooltip or CreateFrame("GameTooltip","LootersAid_Tooltip", UIParent, "GameTooltipTemplate")
	LootersAid.tooltip:SetOwner(UIParent, "ANCHOR_NONE")
	LootersAid.tooltip:SetHyperlink(LootersAid.lootitem)
	if LootersAid.tooltip:NumLines() > 1 then
		bindtext = LootersAid_TooltipTextLeft2:GetText()
		bindtype = (bindtext == ITEM_BIND_ON_PICKUP) and "bop" or "notbop"
	end
	LootersAid.tooltip:Hide()
	return bindtype
end

function LootersAid:isClassSpecific(class)
	local tttext, htype, hnum, ttclasses, classes
	local found, _, itemstring = string.find(LootersAid.lootitem, "^%pc%x+%pH(.+)%ph%[.*%]")
	local pattern = _G.ITEM_CLASSES_ALLOWED
	local specific = LARC_NONE

	LootersAid.tooltip = LootersAid.tooltip or CreateFrame("GameTooltip","LootersAid_Tooltip", nil, "GameTooltipTemplate")
	htype, hnum = string.split(":", itemstring)
	itemstring = htype .. ":" .. hnum .. ":0:0:0:0:0:0:0"
	LootersAid.tooltip:SetOwner(UIParent, "ANCHOR_NONE")
	LootersAid.tooltip:SetHyperlink(itemstring)
	ttclasses = _G[LootersAid.tooltip:GetName() .. "TextLeft3"]

	if LootersAid.tooltip:NumLines() > 2 then	tttext = ttclasses:GetText()
		if tttext then
			pattern = string.gsub(pattern, "%%s", "(.*)")
			classes = string.match(tttext, pattern)
			if classes then
				if string.find(classes, class) then specific = LARC_PASS
				else specific = LARC_FAIL end
			end
		end
	end

	LootersAid.tooltip:Hide()
	return specific
end

function LootersAid:isEligibleClass(name)
	local ell
	local lclass, class = UnitClass(name)
	if LootersAid:isClassSpecific(lclass) == LARC_FAIL then ell = nil
	elseif LootersAid.itemtype == _G.ARMOR or LootersAid.itemtype == _G.ENCHSLOT_WEAPON then ell = LootersAid[class][LootersAid.itemsubtype]
	else ell = 1 end
	return ell
end

function LootersAid:isEligibleRank(name)
	local guild, rank, rankid = GetGuildInfo(name)
	local ell = true
	if guild == GetGuildInfo("player") then
		if LootersAid.db.profile["LAG_" .. guild] then
			if LootersAid.db.profile["LAG_" .. guild][rank] == true then ell = false end
		end
	end
	return ell
end

function LootersAid:getCount()
	if LootersAid.mainCheck:GetChecked() == 1 then
		LootersAid.counts = LootersAid.mscounts
	else LootersAid.counts = LootersAid.oscounts end
	if LootersAid.pMainCheck:GetChecked() == 1 then LootersAid.fcounts = LootersAid.mscounts
	else LootersAid.fcounts = LootersAid.oscounts end
end

function LootersAid:getPlayerCount(player)
	local db, pc
	if LootersAid.mainCheck:GetChecked() == 1 then db = LootersAid.mscounts
	elseif LootersAid.ffaCheck:GetChecked() == 1 then return 0
	else db = LootersAid.oscounts end
	for _, c in pairs(db) do
		if c.playername == player then
			pc = c.count
			break
		end
	end
	return pc or 0
end

function LootersAid:refreshCounts()
	local player
	local found = 0
	local db

	if (LootersAid.testmode == true) then db = LootersAid.testdb
	else db = LootersAidDB end
	LootersAid.mscounts = {}
	LootersAid.oscounts = {}

	for p, c in pairs(db) do
		if p == "LARaidID" or p == "WoWRaidID" then --ignore it
		else
			player = string.sub(p, 4)
			if string.sub(p, 1, 2) == L["ms"] then table.insert(LootersAid.mscounts, {playername = player, count = c})
			elseif string.sub(p, 1, 2) == L["os"] then table.insert(LootersAid.oscounts, {playername = player, count = c})
			end
		end
	end

	local rm = ClientVersion < 50000 and GetNumRaidMembers or GetNumGroupMembers(_G.LE_PARTY_CATEGORY_HOME)
	for p = 1, rm do
		player = GetRaidRosterInfo(p)
		for _, c in pairs(LootersAid.mscounts) do
			if string.lower(c.playername) == string.lower(player) then
				found = 1
				break
			end
		end

		if found == 0 then table.insert(LootersAid.mscounts, {playername = player, count = 0}) end
		found = 0

		for _, c in pairs(LootersAid.oscounts) do
			if string.lower(c.playername) == string.lower(player) then
				found = 1
				break
			end
		end

		if found == 0 then table.insert(LootersAid.oscounts, {playername = player, count = 0}) end
	end
end

function LootersAid:printCounts(spec, loc, r)
	local msg, db, player, pc
	local ttmp = {}
	LootersAid:refreshCounts()
	LootersAid:getCount()

	if spec == L["ms"] then db = LootersAid.mscounts
	else db = LootersAid.oscounts end

	if r == 1 then
		for _, c in pairs(LootersAid.rolls) do
			if string.sub(c.player, 1, 1) ~= "_" then
				player = format("%s%s", string.upper(string.sub(c.player,1,1)), string.sub(c.player, 2))
				pc = tonumber(LootersAid:getPlayerCount(player))
				table.insert(ttmp, {player = player, roll = c.playerroll, count = pc})
			end
		end
		table.sort(ttmp, function(a, b) return LootersAid:rollSort(a, b) end)
		LootersAid:countSort(ttmp)
		db = ttmp
	end

	if #db == 0 then if r == 1 then table.insert(db, {player = "no player", count = -1, playername = "no player"}) end end

	for p, c in pairs(db) do
		if p == "LARaidID" or p == "WoWRaidID" then --ignore this one
		else
			if r == 1 then player = c.player
				if player == "no player" then msg = L["No rolls yet"]
				else
					pc = c.count
					msg = format(L["Looter's Aid: %s rolled %d"], player, c.roll)
					if pc < 0 then msg = format("%s (%d)", msg, pc) end
				end
			else
				if c.playername == "no player" then msg = L["No counts yet"]
				else msg = format(L["Looter's Aid: (%s) %s %d"], spec, c.playername, c.count) end
			end

			if loc == "chat" then DEFAULT_CHAT_FRAME:AddMessage(msg, 0, 1, 1) end
			local rm = ClientVersion < 50000 and GetNumRaidMembers or GetNumGroupMembers(_G.LE_PARTY_CATEGORY_HOME)
			if rm == 0 then return end
			if loc == "raid" then ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, "RAID", nil, nil)
			elseif loc == "party" then ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, "PARTY", nil, nil) end
		end
	end
end

function LootersAid:rollSort(a, b)
	local ra = a.roll
	local rb = b.roll
	if not ra then ra = a.playerroll end
	if not rb then rb = b.playerroll end
	return ra > rb
end

function LootersAid:countSort(table)
--bubble sort function to sort the rolls taking counts into account
	local swap
	if #table < 2 then return end
	repeat
		swap = 0
		for i = 1, #table - 1 do
			if table[i].count < table[i + 1].count then
				table[i], table[i + 1] = table[i + 1], table[i]
				swap = swap + 1
			end
		end
	until swap == 0
end

function LootersAid:getItemQuality(slot) return select(4, GetLootSlotInfo(slot)) end

function LootersAid:isMasterLooter()
	local partyMaster, raidMaster
	LootersAid.lootMethod, partyMaster, raidMaster = GetLootMethod()
	local ml = 0
	if LootersAid.lootMethod == "master" then if UnitName(format("raid%d", raidMaster)) == UnitName("player") then ml = 1 end  end
	if LootersAid.testmode then ml = 1 end
	return ml
end

function LootersAid:LAgetRaidID()
	local raidid, iname, itype, idiff
	local inInstance, instanceType = IsInInstance()
	if inInstance == 1 and instanceType == "raid" then
		iname, itype, idiff = GetInstanceInfo()
		raidid = format("%d_%s_%s", idiff, iname, date("%m%d%y"))
	else raidid = "" end
	return raidid
end

function LootersAid:checkRaidID()
	local inInstance, instanceType = IsInInstance()
	local raidid
	if inInstance == 1 and instanceType == "raid" and LootersAid:isMasterLooter() == 1 then
		raidid = LootersAid:LAgetRaidID()
		if LootersAidDB.LARaidID == raidid or LootersAidDB.WoWRaidID == LootersAid.WoWRaidID then --current raid
		else StaticPopup_Show("LOOTERSAID_RESET") end --new or different raid
	end
end

function LootersAid:GetSlotName(slot)
	local slotname = "None"
	if slot == "INVTYPE_AMMO" then slotname = "AmmoSlot"
	elseif slot == "INVTYPE_HEAD" then slotname = "HeadSlot"
	elseif slot == "INVTYPE_NECK" then slotname = "NeckSlot"
	elseif slot == "INVTYPE_SHOULDER" then slotname = "ShoulderSlot"
	elseif slot == "INVTYPE_BODY" then slotname = "ShirtSlot"
	elseif slot == "INVTYPE_CHEST" or slot == "INVTYPE_ROBE" then slotname = "ChestSlot"
	elseif slot == "INVTYPE_WAIST" then slotname = "WaistSlot"
	elseif slot == "INVTYPE_LEGS" then slotname = "LegsSlot"
	elseif slot == "INVTYPE_FEET" then slotname = "FeetSlot"
	elseif slot == "INVTYPE_WRIST" then slotname = "WristSlot"
	elseif slot == "INVTYPE_HAND" then slotname = "HandsSlot"
	elseif slot == "INVTYPE_CLOAK" then slotname = "BackSlot"
	elseif slot == "INVTYPE_SHIELD" or slot == "INVTYPE_WEAPONOFFHAND" or slot == "INVTYPE_HOLDABLE" then slotname = "SecondaryHandSlot"
	elseif slot == "INVTYPE_2HWEAPON" or slot == "INVTYPE_WEAPONMAINHAND" then slotname = "MainHandSlot"
	elseif slot == "INVTYPE_RANGED" or slot == "INVTYPE_THROWN" or slot == "INVTYPE_RANGEDRIGHT" or slot == "INVTYPE_RELIC" then slotname = "RangedSlot"
	elseif slot == "INVTYPE_TABARD" then slotname = "TabardSlot" end
	return slotname
end

function LootersAid:GetEncounter()
	local target, friendly
	local boss, dbmboss
	dbmboss = LootersAid.DBMBoss
	boss = L["encounter"]
	target = UnitClassification("target")
	if target == "worldboss" then boss = dbmboss or UnitName("target")
	else
		if UnitIsFriend("player", target) or UnitInRaid(target) then --boss = dbmboss or L["encounter"]
		elseif UnitIsCorpse("target") then boss = UnitName("target")			
		else boss = dbmboss or L["encounter"] end
	end
	return boss
end

local function bagitemCheck(bagid, slot, ...)
	local lootable = select(6, GetContainerItemInfo(bagid, slot))
	LootersAid.playerloot = lootable
end

hooksecurefunc("UseContainerItem", bagitemCheck)