local LootersAid = LootersAid
local CreateFrame, GetSpellInfo = CreateFrame, GetSpellInfo
local string = string
LootersAid.testmode = false
LootersAid.L = LibStub("AceLocale-3.0"):GetLocale("LootersAid")
LootersAid.AceGUI = LibStub("AceGUI-3.0")
local L = LootersAid.L
LootersAid.cplayer = UnitName("player")

--LootersAid.testloot = "|cff0070dd|Hitem:22397:0:0:0:0:0:0:0:0|h[Idol of Ferocity]|h|r"
--LootersAid.testloot = "|cffa335ee|Hitem:47741:0:0:0:0:0:0:0:0|h[Baelgun's Heavy Crossbow]|h|r"
--LootersAid.testloot = "|cffa335ee|Hitem:47730:0:0:0:0:0:0:0:0|h[Dexterous Brightstone Ring]|h|r"
--LootersAid.testloot = "|cffa335ee|Hitem:52025:0:0:0:0:0:0:0:0|h[Vanquisher's Mark of Sanctification]|h|r"
--LootersAid.testloot = "|cffa335ee|Hitem:52026:0:0:0:0:0:0:0:0|h[Protector's Mark of Sanctification]|h|r"
LootersAid.testloot = "|cffa335ee|Hitem:64314:0:0:0:0:0:0:0:0|h[Mantle of the Forlorn Vanquisher]|h|r"
--LootersAid.testloot = "|cffffffff|Hitem:45998:0:0:0:0:0:0:0:0|h[Battered Jungle Hat]|h|r"
LootersAid.testdb = {
	["LARaidID"] = "1_Trial of the Crusader_120109",
	["ms_Clothos"] = -1, ["ms_Tzami"] = -2, ["ms_Alekinthalas"] = -1, ["ms_Fordham"] = 0,
	["ms_Region"] = -2, ["ms_Mightyred"] = -4, ["ms_Oba"] = 0, ["ms_Omab"] = -1,
	["ms_Bergus"] = -3, ["ms_Barghalen"] = -1, ["ms_Oclusal"] = -1, ["os_Clothos"] = -1,
	["os_Bergus"] = -1, ["os_Tzami"] = -1,
	["b4_Zarathena"] = -1, ["b4_Microdude"] = -2,
	["loot001_47730"] = "Deepac",
	["loot002_45998"] = "Tzami",
	["loot003_47741"] = "Deepac",
	["loot004_22397"] = "Deepac",
	["loot005_52025"] = "Tzami",
	["loot006_52026"] = "Deepac",
	["loot007_64314"] = "Deepac",
	["loot008_45998"] = "Tzami",
	["loot009_47741"] = "Deepac",
	["loot010_47730"] = "Deepac",
	["loot011_45998"] = "Tzami",
	["loot012_47741"] = "Deepac",
	["loot013_47730"] = "Deepac",
	["loot014_45998"] = "Tzami",
	["loot015_47741"] = "Deepac",
	["loot016_47730"] = "Deepac",
	["loot017_45998"] = "Tzami",
	["loot018_47741"] = "Deepac",
}
LootersAid.testrolls = {
	{player = "Deepac", playerroll = 28},
	{player = "Goldilox", playerroll = 37},
	{player = "Clothos", playerroll = 25},
	{player = "Region", playerroll = 34},
	{player = "Fordham", playerroll = 22},
	{player = "Bergus", playerroll = 14},
	{player = "N00b", playerroll = 16},
	{player = "Wibble", playerroll = 3},
	{player = "Foxtrot", playerroll = 5},
	{player = "Turnip", playerroll = 4},
	{player = "Chipmunk", playerroll = 2},
	{player = "Arthur", playerroll = 4}
}
LootersAid.highestRoll = 0
LootersAid.winningRoll = -100000 
LootersAid.secondRoll = -100000
LootersAid.winner = ""
LootersAid.lootslot = ""
LootersAid.lootitem = ""
LootersAid.second = ""
LootersAid.wRoll = 0
LootersAid.wRollPoints = 0
LootersAid.sRoll = 0
LootersAid.sRollPoints = 0
LootersAid.winRollTrack = 0
LootersAid.hasLoot = 0
LootersAid.lootQty = 0
LootersAid.playercolour = "00ff00"
LootersAid.rollcolour = "00ffff"
LootersAid.pointscolour = "ff0000"
LootersAid.progresscolour = "ffffff"
LootersAid.monitorRolls = 0
LootersAid.rolls = {}
LootersAid.rollcheck = {}
LootersAid.wt = 999999
LootersAid.wp = ""
LootersAid.ws = ""
LootersAid.dis = 0
LootersAid.pobj = {}
LootersAid.fpobj = {}
LootersAid.WoWRaidID = 0
LootersAid.LAWidth = 400
LootersAid.LAHeight = 370
LootersAid.LApWidth = 200
LootersAid.LApHeight = 250
LootersAid.allLoot = {}
LootersAid.lootPos = 1
LootersAid.syncData = {}
LootersAid.rr = 0
LootersAid.equipslot1 = ""
LootersAid.equipslot2 = ""
LootersAid.itemtype= ""
LootersAid.itemsubtype = ""
LootersAid.emptyslot = ""
LootersAid.cdtimes = {3, 4, 5, 6, 7, 8, 9, 10}
LootersAid.pid = {}

LootersAid.frame.flashtimer = 0
LootersAid.frame:RegisterEvent("ADDON_LOADED")
LootersAid.frame:RegisterEvent("LOOT_OPENED")
LootersAid.frame:RegisterEvent("LOOT_CLOSED")
LootersAid.frame:RegisterEvent("LOOT_SLOT_CLEARED")
LootersAid.frame:RegisterEvent("RAID_INSTANCE_WELCOME")
LootersAid.frame:RegisterEvent("GROUP_ROSTER_UPDATE")
LootersAid.frame:RegisterEvent("RAID_ROSTER_UPDATE")
LootersAid.frame:RegisterEvent("UPDATE_INSTANCE_INFO")
LootersAid.frame:RegisterEvent("PLAYER_LOGIN")
LootersAid.frame:RegisterEvent("PLAYER_ENTERING_WORLD")
LootersAid.frame:RegisterEvent("CHAT_MSG_ADDON")

if LootersAid.testmode then LootersAid.frame:RegisterEvent("CHAT_MSG_SYSTEM") end
local numranks = GuildControlGetNumRanks()
LootersAid.ranks = {}
LootersAid.guildname = GetGuildInfo("player") or ""
if (numranks or 0) == 0 then numranks = 1
else for r = 1, numranks do LootersAid.ranks[r] = GuildControlGetRankName(r) end end
for r = numranks, 10 do LootersAid.ranks[r] = "<.....>" end
LootersAid.frame:SetScript("OnEvent", function(...) LootersAid:eventHandler(...) end)

--Weapon Types
LootersAid.BOWS = GetSpellInfo(264)
LootersAid.CROSSBOWS = GetSpellInfo(5011)
LootersAid.DAGGERS = GetSpellInfo(1180)
LootersAid.GUNS = GetSpellInfo(266)
LootersAid.FIST = GetSpellInfo(15590)
LootersAid.ONEAXE = GetSpellInfo(196)
LootersAid.TWOAXE = GetSpellInfo(197)
LootersAid.ONESWORD = GetSpellInfo(201)
LootersAid.POLEARMS = GetSpellInfo(200)
LootersAid.STAVES = GetSpellInfo(227)
LootersAid.THROWN = GetSpellInfo(2567)
LootersAid.ONEMACE = GetSpellInfo(198)
LootersAid.TWOMACE = GetSpellInfo(199)
LootersAid.TWOSWORD = GetSpellInfo(202)
LootersAid.WANDS = GetSpellInfo(5009)

--Armour/Weapon classes
LootersAid.DEATHKNIGHT = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[L["Mail"]] = 1, 
	[L["Plate"]] = 1, 
	[LootersAid.ONEAXE] = 1, 
	[LootersAid.TWOAXE] = 1, 
	[LootersAid.POLEARMS] = 1, 
	[LootersAid.ONESWORD] = 1, 
	[LootersAid.TWOSWORD] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.TWOMACE] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.DRUID = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[L["Idols"]] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.TWOMACE] = 1, 
	[LootersAid.POLEARMS] = 1, 
	[LootersAid.DAGGERS] = 1, 
	[LootersAid.FIST] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.HUNTER = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[L["Mail"]] = 1, 
	[LootersAid.ONEAXE] = 1, 
	[LootersAid.TWOAXE] = 1, 
	[LootersAid.GUNS] = 1, 
	[LootersAid.CROSSBOWS] = 1, 
	[LootersAid.BOWS] = 1, 
	[LootersAid.FIST] = 1, 
	[LootersAid.POLEARMS] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.ONESWORD] = 1, 
	[LootersAid.TWOSWORD] = 1, 
	[LootersAid.THROWN] = 1, 
	[LootersAid.DAGGERS] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.MAGE = {
	[L["Cloth"]] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.WANDS] = 1, 
	[LootersAid.ONESWORD] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.PALADIN = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[L["Mail"]] = 1, 
	[L["Plate"]] = 1, 
	[L["Shields"]] = 1, 
	[L["Librams"]] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.TWOMACE] = 1, 
	[LootersAid.ONESWORD] = 1, 
	[LootersAid.TWOSWORD] = 1, 
	[LootersAid.ONEAXE] = 1, 
	[LootersAid.TWOAXE] = 1, 
	[LootersAid.POLEARMS] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.PRIEST = {
	[L["Cloth"]] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.DAGGERS] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.WANDS] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.ROGUE = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[LootersAid.DAGGERS] = 1, 
	[LootersAid.ONESWORD] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.FIST] = 1, 
	[LootersAid.THROWN] = 1, 
	[LootersAid.BOWS] = 1, 
	[LootersAid.CROSSBOWS] = 1, 
	[LootersAid.GUNS] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.SHAMAN = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[L["Mail"]] = 1, 
	[L["Shields"]] = 1, 
	[L["Totems"]] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.TWOMACE] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.FIST] = 1, 
	[LootersAid.ONEAXE] = 1, 
	[LootersAid.TWOAXE] = 1, 
	[LootersAid.DAGGERS] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.WARLOCK = {
	[L["Cloth"]] = 1, 
	[LootersAid.DAGGERS] = 1, 
	[LootersAid.WANDS] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.ONESWORD] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.WARRIOR = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1, 
	[L["Mail"]] = 1, 
	[L["Plate"]] = 1, 
	[L["Shields"]] = 1,
	[LootersAid.BOWS] = 1, 
	[LootersAid.CROSSBOWS] = 1, 
	[LootersAid.DAGGERS] = 1, 
	[LootersAid.GUNS] = 1, 
	[LootersAid.FIST] = 1, 
	[LootersAid.ONEAXE] = 1, 
	[LootersAid.TWOAXE] = 1, 
	[LootersAid.ONESWORD] = 1, 
	[LootersAid.POLEARMS] = 1, 
	[LootersAid.STAVES] = 1, 
	[LootersAid.THROWN] = 1, 
	[LootersAid.ONEMACE] = 1, 
	[LootersAid.TWOMACE] = 1, 
	[LootersAid.TWOSWORD] = 1,
	[_G.MISCELLANEOUS] = 1
}
LootersAid.MONK = {
	[L["Cloth"]] = 1, 
	[L["Leather"]] = 1,
	[LootersAid.FIST] = 1,
	[LootersAid.ONEAXE] = 1,
	[LootersAid.ONEMACE] = 1,
	[LootersAid.ONESWORD] = 1,
	[LootersAid.POLEARMS] = 1, 
	[LootersAid.STAVES] = 1,
	[_G.MISCELLANEOUS] = 1
}

-- configure dialogue boxes
StaticPopupDialogs["LOOTERSAID_RESET"] = {
	text = L["Do you want to reset Looter's Aid's data?"],
	button1 = _G.YES,
	button2 = _G.NO,
	OnAccept = function() LootersAid:ResetData(1) end,
	OnCancel = function() LootersAid:ResetData(0) end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

StaticPopupDialogs["LOOTERSAID_SECOND"] = {
	text = L["Award duplicate item to second place?"],
	button1 = _G.YES,
	button2 = _G.NO,
	OnAccept = function() LootersAid:awardSecond() end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

StaticPopupDialogs["LOOTERSAID_INVALID"] = {
	text = L["Disenchanter has not been set or is invalid"],
	button1 = _G.OKAY,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

StaticPopupDialogs["LOOTERSAID_TXSYNC"] = {
	text = L["Send Looter's Aid data to a new Master Looter?"],
	button1 = _G.YES,
	button2 = _G.NO,
	OnAccept = function() LootersAid:sendSync() end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

StaticPopupDialogs["LOOTERSAID_REROLL"] = {
	text = string.format(L["Rolls tied for %s and %s, reroll?"], LootersAid.winner, LootersAid.second),
	button1 = _G.YES,
	button2 = L["Award Loot"],
	OnAccept = function() LootersAid:reroll() end,
	OnCancel = function() LootersAid:awardLoot() end,
	timeout = 0,
	hideOnEscape = 0,
	whileDead = 1
}

LootersAid.defaults = {
	profile = {
		classcheck = false,
		disableill = false,
		disablerw = false,
		ffadefault = false,
		hidecheck = false,
		hidewhispers = true,
		rollstop = true,
		rwcheck = false,
		rwlist = false,
		rwwin = false,
		usecd = true,
		usemaxmin = false,
		useranks = false,
		customroll = false,
		custompen = false,
		cdtime = 7,
		useattendance = false,
		px = (UIParent:GetWidth() - LootersAid.LApWidth) / 2,
		py = (UIParent:GetHeight() - LootersAid.LApHeight) / 2,
		x = (UIParent:GetWidth() - LootersAid.LAWidth) / 2,
		y = (UIParent:GetHeight() - LootersAid.LAHeight) / 2,
		ffatext = L["Free for all roll for %s"],
		mstext = L["Main spec roll for %s"],
		ostext = L["Off spec roll for %s"],
		customtext = L["Roll for %s"],
		maxtext = "",
		mintext = "",
		guildwin = false,
		raidloot = true,
		partyloot = nil,
		chatloot = nil,
		minimap = {hide = false},
		dismess = false,
	},
}

local function lootAccept(this)
	local loc
	if LootersAidLootRaid then loc = "RAID"
	elseif LootersAidLootParty then loc = "PARTY"
	elseif LootersAidLootChat then loc = "CHAT"
	end
	LootersAid:showLootRecord(loc, LootersAid.lootrecordplayer)
end

StaticPopupDialogs["LOOTERSAID_LOOT"] = {
	text = "",
	button1 = _G.ACCEPT,
	button2 = _G.CANCEL,
	OnAccept = lootAccept,
	OnHide = 
		function(this)
			LootersAidLootRaid:Hide()
			LootersAidLootParty:Hide()
			LootersAidLootChat:Hide()
		end,
	OnShow = 
		function(this)
			local frame = this.extraFrame
			local raid, party, chat
			this.text:SetText(string.format(L["Show loot record for %s"], (LootersAid.lootrecordplayer or "")))
			raid = LootersAidLootRaid or CreateFrame("CheckButton", "LootersAidLootRaid", frame, "OptionsCheckButtonTemplate")
			LootersAidLootRaidText:SetText(L["Show in Raid chat"])
			raid:SetScript("OnClick", 
				function(this)
					LootersAid.db.profile.raidloot = (this:GetChecked() or false)
					LootersAid.db.profile.partyloot = false
					LootersAid.db.profile.chatloot = false
					if this:GetChecked() then 
						LootersAidLootParty:SetChecked(false)
						LootersAidLootChat:SetChecked(false)
					end
				end)
			raid:SetPoint("TOPLEFT", 60, 0)
			raid:SetChecked(LootersAid.db.profile.raidloot)
			raid:Show()
			party = LootersAidLootParty or CreateFrame("CheckButton", "LootersAidLootParty", frame, "OptionsCheckButtonTemplate")
			LootersAidLootPartyText:SetText(L["Show in Party chat"])
			party:SetScript("OnClick", 
				function(this)
					LootersAid.db.profile.partyloot = (this:GetChecked() or false)
					LootersAid.db.profile.raidloot = false
					LootersAid.db.profile.chatloot = false
					if this:GetChecked() then 
						LootersAidLootRaid:SetChecked(false)
						LootersAidLootChat:SetChecked(false)
					end
				end)
			party:SetPoint("TOPLEFT", 60, -20)
			party:SetChecked(LootersAid.db.profile.partyloot)
			party:Show()
			chat = LootersAidLootChat or CreateFrame("CheckButton", "LootersAidLootChat", frame, "OptionsCheckButtonTemplate")
			LootersAidLootChatText:SetText(L["Show in chat"])
			chat:SetScript("OnClick", 
				function(this)
					LootersAid.db.profile.chatloot = (this:GetChecked() or false)
					LootersAid.db.profile.partyloot = false
					LootersAid.db.profile.raidloot = false
					if this:GetChecked() then 
						LootersAidLootParty:SetChecked(false)
						LootersAidLootRaid:SetChecked(false)
					end
				end)
			chat:SetPoint("TOPLEFT", 60, -40)
			chat:SetChecked(LootersAid.db.profile.chatloot)
			chat:Show()
			frame:SetSize(140, 70)
			frame:SetPoint("TOPLEFT", this.text, "BOTTOMLEFT", 10, -5)
			frame:Show()
		end,
	timeout = 0,
	exclusive = 1,
	whileDead = 1,
	hideOnEscape = 1
}

local function PopupResize(dialog, which)
	if not dialog then return end
	if which == "LOOTERSAID_LOOT" then dialog:SetHeight(dialog:GetHeight() + 70)
	else
		dialog.editBox:ClearAllPoints()
		dialog.editBox:SetPoint("BOTTOM", 0, 45)
	end
end

hooksecurefunc("StaticPopup_Resize", PopupResize)