local _G = _G
local _ = _G._
local GetItemInfo = GetItemInfo
local LootersAid = LootersAid
local L = LootersAid.L
local string, tonumber, select, format = string, tonumber, select, format
local CreateFrame, UIParent = CreateFrame, UIParent
local UnitClass = UnitClass
local DEFAULT_CHAT_FRAME = DEFAULT_CHAT_FRAME
local ChatThrottleLib = ChatThrottleLib
local GetNumGroupMembers = GetNumGroupMembers
local table, ipairs, pairs, strsplit = table, ipairs, pairs, strsplit
local GameTooltip = GameTooltip
local GetNumLootItems, GetLootSlotLink, GetLootThreshold = GetNumLootItems, GetLootSlotLink, GetLootThreshold
local GetLootSlotInfo, GetItemQualityColor, GetMasterLootCandidate = GetLootSlotInfo, GetItemQualityColor, GetMasterLootCandidate
local GetInventorySlotInfo, GetInventoryItemID, GiveMasterLoot = GetInventorySlotInfo, GetInventoryItemID, GiveMasterLoot
local PlaySound, UnitName, NotifyInspect = PlaySound, UnitName, NotifyInspect
local StaticPopup_Show = StaticPopup_Show
local LootersAidProgress
local ClientVersion = select(4, GetBuildInfo())

function LootersAid:SetLootInfo(link) _, _, _, _, _, LootersAid.itemtype, LootersAid.itemsubtype, _, LootersAid.equipslot = GetItemInfo(link) end

function LootersAid:GetInvLink(slot)
	local link, slotid
	local rid
	local r, rn
	local itemid
	local itemstring

	NotifyInspect(LootersAid.winner)
	slotid, LootersAid.emptyslot = GetInventorySlotInfo(slot)
	LootersAid.emptyslot = "Interface\\Icons\\INV_Misc_QuestionMark"
	itemid = GetInventoryItemID(LootersAid.winner, slotid)

	if itemid then
		link = select(2, GetItemInfo(itemid))
		if not link then
			itemstring = format("item:%s:0:0:0:0:0:0:0", itemid)
			LootersAid.tooltip = LootersAid.tooltip or CreateFrame("GameTooltip","LootersAid_Tooltip", nil, "GameTooltipTemplate")
			LootersAid.tooltip:SetOwner(UIParent, "ANCHOR_NONE")
			LootersAid.tooltip:SetHyperlink(itemstring)
			link = select(2, GetItemInfo(itemid))
			LootersAid.tooltip:Hide()
		end
	end

	return link
end

function LootersAid:GetItemInfo(link) return select(10, GetItemInfo(link)) end

function LootersAid:RGBToHex(r, g, b, a)
	r = r <= 1 and r >= 0 and r or 0
	g = g <= 1 and g >= 0 and g or 0
	b = b <= 1 and b >= 0 and b or 0
	a = a <= 1 and a >= 0 and a or 0
	return format("%02x%02x%02x%02x", a*255, r*255, g*255, b*255)
end

function LootersAid:SetWinnerEquip()
	local texture
	local class, cc = UnitClass(LootersAid.winner)
	local c = "ffffffff"

	if class then
		local rcc = _G.RAID_CLASS_COLORS[cc]
		if rcc then c = LootersAid:RGBToHex(rcc.r, rcc.g, rcc.b, 1) end
		LootersAid.class:SetFormattedText("|c%s%s", c, class)
	else LootersAid.class:SetText("") end

	if LootersAid.equipslot == "INVTYPE_FINGER" then LootersAid.equipslot1 = LootersAid:GetInvLink("Finger0Slot")
		if not LootersAid.equipslot1 then texture = LootersAid.emptyslot
		else texture = LootersAid:GetItemInfo(LootersAid.equipslot1) end
		LootersAidSlot1ButtonIconTexture:SetTexture(texture)
		LootersAid.slot1Button:Show()
		LootersAid.equipslot2 = LootersAid:GetInvLink("Finger1Slot")
		if not LootersAid.equipslot2 then texture = LootersAid.emptyslot
		else texture = LootersAid:GetItemInfo(LootersAid.equipslot2) end
		LootersAidSlot2ButtonIconTexture:SetTexture(texture)
		LootersAid.slot2Button:Show()
	elseif LootersAid.equipslot == "INVTYPE_TRINKET" then
		LootersAid.equipslot1 = LootersAid:GetInvLink("Trinket0Slot")
		if not LootersAid.equipslot1 then texture = LootersAid.emptyslot
		else texture = LootersAid:GetItemInfo(LootersAid.equipslot1) end
		LootersAidSlot1ButtonIconTexture:SetTexture(texture)
		LootersAid.slot1Button:Show()
		LootersAid.equipslot2 = LootersAid:GetInvLink("Trinket1Slot")
		if not LootersAid.equipslot2 then texture = LootersAid.emptyslot
		else texture = LootersAid:GetItemInfo(LootersAid.equipslot2) end
		LootersAidSlot2ButtonIconTexture:SetTexture(texture)
		LootersAid.slot2Button:Show()
	elseif LootersAid.equipslot == "INVTYPE_WEAPON" then
		LootersAid.equipslot1 = LootersAid:GetInvLink("MainHandSlot")
		if not LootersAid.equipslot1 then texture = LootersAid.emptyslot
		else texture = LootersAid:GetItemInfo(LootersAid.equipslot1) end
		LootersAidSlot1ButtonIconTexture:SetTexture(texture)
		LootersAid.slot1Button:Show()
		LootersAid.equipslot2 = LootersAid:GetInvLink("SecondaryHandSlot")
		if not LootersAid.equipslot2 then texture = LootersAid.emptyslot
		else texture = LootersAid:GetItemInfo(LootersAid.equipslot2) end
		LootersAidSlot2ButtonIconTexture:SetTexture(texture)
		LootersAid.slot2Button:Show()
	else
		local slot = LootersAid:GetSlotName(LootersAid.equipslot)
		if slot ~= "None" then LootersAid.equipslot1 = LootersAid:GetInvLink(slot)
			if not LootersAid.equipslot1 then texture = LootersAid.emptyslot
			else texture = LootersAid:GetItemInfo(LootersAid.equipslot1) end
			LootersAidSlot1ButtonIconTexture:SetTexture(texture)
			LootersAid.slot1Button:Show()
		end
	end
end

function LootersAid:countdown(this, elapsed)
	this.TimeSinceLastUpdate = this.TimeSinceLastUpdate + elapsed
	if this.TimeSinceLastUpdate >= 1.0 then
		if this.Countdown == 0 then this:SetScript("OnUpdate", nil)
			if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(L["No more rolls accepted"], 0, 1, 0)
			elseif not LootersAid.db.profile.rollstop then
				ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", L["No more rolls accepted"], "RAID", nil, nil)
			end
			LootersAid.cdctime:Hide()
			this.Countdown = LootersAid.cdtimes[LootersAid.db.profile["cdtime"]]
			if not LootersAid.db.profile.rollstop then LootersAid.monitorRolls = 0 end
			LootersAid.announceButton:Disable()
			return
		else
			if not LootersAid.cdctime:IsVisible() then LootersAid.cdctime:Show() end
			LootersAid.cdctime:SetFormattedText("|cffffffff%d", this.Countdown)
		end
		if this.Countdown < 6 then
			if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format(L["%d"], this.Countdown), 0, 1, 0)
			else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(L["%d"], this.Countdown), "RAID", nil, nil) end
		end
		this.Countdown = this.Countdown - 1
		this.TimeSinceLastUpdate = 0
	end
end

function LootersAid:raidRoll()
	local pc = 1
	LootersAid.pid = {}
	local rm = ClientVersion < 50000 and GetNumRaidMembers or GetNumGroupMembers(_G.LE_PARTY_CATEGORY_HOME)
	for rc = 1, rm do
		local mlp = GetMasterLootCandidate(rc)
		if mlp then
			table.insert(LootersAid.pid, {player = mlp, pos = pc})
			pc = pc + 1
		end
	end

	if LootersAid.testmode then pc = 10
	elseif pc == 1 then return end
	if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(L["Raid roll"], 0, 1, 0)
	else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", L["Raid roll"], "RAID", nil, nil) end
	table.sort(LootersAid.pid, function(a, b) return a.pos > b.pos end)

	for _, rc in ipairs(LootersAid.pid) do
		local msg = format("%s = %s", rc.pid, rc.player)
		if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(msg, 0, 1, 0)
		else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, "RAID", nil, nil) end
	end

	LootersAid.rr = 1
	LootersAid.monitorRolls = 1
	local chatWindow = ChatEdit_ChooseBoxForSend()
	if chatWindow then
		chatWindow:Insert(format("/roll 1 %d", pc))
		ChatEdit_SendText(chatWindow)
	end
end

function LootersAid:getMessage()
	local msg
	local mstext = LootersAid.db.profile.mstext
	local ostext = LootersAid.db.profile.ostext
	local ffatext = LootersAid.db.profile.ffatext
	if LootersAid.mainCheck:GetChecked() then
		if string.match(mstext or "", "%%s") then msg = mstext
		else msg = L["Main spec roll for %s"] end
	else
		if string.match(ostext or "", "%%s") then msg = ostext
		else msg = L["Off spec roll for %s"] end
	end
	if LootersAid.ffaCheck:GetChecked() then
		if string.match(ffatext or "", "%%s") then msg = ffatext
		else msg = L["Free for all roll for %s"] end
	end
	return msg
end

local function cdOnEnter(this)
	GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
	GameTooltip:SetText(L["Start a countdown"], 1, 1, 1)
end

local function cdOnLeave() GameTooltip:Hide() end

function LootersAid:lootAnnounce()
	local msg = LootersAid:getMessage()

	if LootersAid.announceButton:GetText() == L["Countdown"] then
		LootersAid.frame:SetScript("OnUpdate", function(this, elapsed) LootersAid:countdown(this, elapsed) end)
		return
	end

	LootersAid.highRoll:SetFormattedText("%s:|cff%s %s", L["Highest roll"], LootersAid.playercolour, L["Nobody"])
	LootersAid.winRoll:SetFormattedText("%s:|cff%s %s", L["Winning roll"], LootersAid.playercolour, L["Nobody"])
	LootersAid.secRoll:SetFormattedText("%s:|cff%s %s", L["Second place"], LootersAid.playercolour, L["Nobody"])
	LootersAid:resetRolls()

	if not LootersAid.lootitem then return end
	if LootersAid.testmode then print("Bind type:", LootersAid:getBindType()) end
	msg = format(msg, LootersAid.lootitem)
	LootersAid.monitorRolls = 1
	LootersAid.rolls = {}
	LootersAid.rollcheck = {}

	if LootersAid.rFrame:IsVisible() then
		LootersAid.rFrame:Hide()
		LootersAid.rFrame:Show()
	end

	if LootersAid.db.profile.usecd == true then
		LootersAid.announceButton:SetText(L["Countdown"])
		LootersAid.announceButton:SetScript("OnEnter", cdOnEnter)
		LootersAid.announceButton:SetScript("OnLeave", cdOnLeave)
	else LootersAid.announceButton:Disable() end

	if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(msg, 0, 1, 0)
	else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, "RAID_WARNING", nil, nil) end
	LootersAidProgress:AddMessage(msg, 0, 0, 1, 1)
end

function LootersAid:rollReset()
	LootersAid.announceButton:SetText(_G.CHAT_ANNOUNCE)
	LootersAid.announceButton:SetScript("OnEnter", nil)
	LootersAid.announceButton:SetScript("OnLeave", nil)
	LootersAid.announceButton:Enable()
	LootersAid.highRoll:SetFormattedText("%s:|cff%s %s", L["Highest roll"], LootersAid.playercolour, L["Nobody"])
	LootersAid.winRoll:SetFormattedText("%s:|cff%s %s", L["Winning roll"], LootersAid.playercolour, L["Nobody"])
	LootersAid.secRoll:SetFormattedText("%s:|cff%s %s", L["Second place"], LootersAid.playercolour, L["Nobody"])
	LootersAid:resetRolls()
	LootersAid.rolls = {}
	LootersAid.rollcheck = {}
	LootersAid.rr = 0
end

-- *** send the awarded loot record to the raid window
function LootersAid:RecordSort(a, b) return a.p < b.p end

local function stripitem(link) return select(3, string.find(link, "|h%[(.+)%]")) end

function LootersAid:sortLootRecord(msg)
	if not LootersAid.lootdisplay then LootersAid.lootdisplay, LootersAid.lootdisplayitems = LootersAid:CreateLootDisplayFrame() end
	LootersAid.lootdisplayitems:ReleaseChildren()
	if msg then LootersAid.lootdisplay:SetTitle(string.gsub(msg, ":", "")) end
	if LootersAid.lootsort == "player" then table.sort(LootersAid.rec, function(a, b) return format("%s%s",a.p,stripitem(a.item)) < format("%s%s",b.p,stripitem(b.item)) end)
	else table.sort(LootersAid.rec, function(a, b) return format("%s%s",stripitem(a.item),a.p) < format("%s%s",stripitem(b.item),b.p) end) end
	for _, c in pairs(LootersAid.rec) do
		local l = LootersAid.AceGUI:Create("InteractiveLabel")
		l:SetText(format("%s ====> %s", c.item, c.p))
		l:SetWidth(275)
		l:SetCallback("OnClick", function(info, event, button) SetItemRef(c.item, c.item, button, LootersAid.lootdisplay.frame) end)
		LootersAid.lootdisplayitems:AddChild(l)
	end
	if not LootersAid.lootdisplay.frame:IsShown() then LootersAid.lootdisplay.frame:Show() end
end

function LootersAid:showLootRecord(loc, plyr, showframe)
	local db, info
	LootersAid.rec = {}

	if LootersAid.testmode == true then db = LootersAid.testdb
	else db = LootersAidDB end
	local msg = L["Looter's Aid Loot Record:"]
	if plyr then msg = format("%s %s", msg, plyr) end

	if not showframe then
		if LootersAid.testmode or loc == "CHAT" then DEFAULT_CHAT_FRAME:AddMessage(msg, 0, 1, 0)
		else
			ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, loc)
			local rm = ClientVersion < 50000 and GetNumRaidMembers or GetNumGroupMembers(_G.LE_PARTY_CATEGORY_HOME)
			if rm == 0 then return end
		end
	end

	--msg = nil
	local found = 0
	for p, c in pairs(db) do
		if p == "LARaidID" or p == "WoWRaidID" or string.sub(p,3, 3) == "_" then --ignore it
		else
			if string.sub(p, 1, 4) == "loot" then
				local up = string.find(p, "_")
				local loot = tonumber(string.sub(p, up + 1))
				local player = c
				if (not plyr) or string.lower(plyr) == string.lower(player) then
					info = select(2, GetItemInfo(loot))
					if info then
						--msg = format("%s --- %s", info, player)
						found = 1
						table.insert(LootersAid.rec,{item = info, p = player})
					end
				end
			end
		end
	end
	LootersAid.lootplyr = plyr
	if showframe then LootersAid:sortLootRecord(msg)
	else
		if found == 0 then
			if LootersAid.testmode or loc == "CHAT" then DEFAULT_CHAT_FRAME:AddMessage(L["No loot yet"], 0, 1, 0)
			else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", L["No loot yet"], loc) end
		else
			table.sort(LootersAid.rec, function(a,b) return LootersAid:RecordSort(a,b) end)
			for _, c in pairs(LootersAid.rec) do
				msg = format("%s ====> %s", c.item, c.p)
				if LootersAid.testmode or loc == "CHAT" then DEFAULT_CHAT_FRAME:AddMessage(msg, 0, 1, 0)
				else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, loc) end
			end
		end
	end
end

-- *** award any duplicate item to LootersAid.second place ***
function LootersAid:awardSecond()
	LootersAid.lootQty = 0
	LootersAid.winner = LootersAid.second
	LootersAid.wRoll = LootersAid.sRoll
	LootersAid:awardLoot()
end

-- *** award loot to the LootersAid.winner ***
function LootersAid:awardLoot()
	local spec, sp, lid
	local db = LootersAidDB

	if LootersAid.testmode then db = LootersAid.testdb end
	LootersAid.announceButton:SetText(_G.CHAT_ANNOUNCE)
	LootersAid.announceButton:SetScript("OnEnter", nil)
	LootersAid.announceButton:SetScript("OnLeave", nil)
	LootersAid.announceButton:Enable()

	if LootersAid.mainCheck:GetChecked() then
		spec = format("%s_", L["ms"])
		sp = L["ms"]
	else
		spec = format("%s_", L["os"])
		sp = L["os"]
	end

	--make sure we definately have the right loot item
	for c = 1, GetNumLootItems() do if GetLootSlotLink(c) == LootersAid.lootitem then lid = c end end
	if LootersAid.testmode then lid = 1 end
	if LootersAid.winner == "" or lid == nil or LootersAid.winner == nil then return end

	--ensure we have the correct raid id number for the relevant player
	local pid = LootersAid:isEligible(LootersAid.winner)

	--award the loot
	--check for requirement to add penalty
	local penalty
	if LootersAid.ffaCheck:GetChecked() or LootersAid.rr == 1 then penalty = nil --no penalty required
	else penalty = true end

	local newcount, found = 0, 0
	if penalty then --adjust the count for the LootersAid.winner
		if LootersAid.dis == 0 then
			spec = format("%s%s", spec, LootersAid.winner)
			for p, c in pairs(db) do
				if p == spec then
					newcount = c - 1
					db[spec] = newcount
					found = 1
					break
				end
			end
			if found == 0 then
				db[spec] = -1
				newcount = -1
			end
		end

		-- update the player counts frame if visible
		LootersAid:refreshCounts()

		if LootersAid.pFrame:IsVisible() then
			LootersAid.pFrame:Hide()
			LootersAid.pFrame:Show()
		end

		if LootersAid.fpFrame:IsVisible() then
			LootersAid.fpFrame:Hide()
			LootersAid.fpFrame:Show()
		end
	end

	local msg, tplayer
	if pid and LootersAid.lootitem then
		if LootersAid.dis == 1 then
			msg = format(L["Disenchanting %s"], LootersAid.lootitem)
		elseif LootersAid.rr == 1 then
			tplayer = string.upper(format("%s%s", string.sub(LootersAid.winner, 1, 1)), string.sub(LootersAid.winner, 2))
			msg = format(L["Raid roll: %s won %s"], tplayer, LootersAid.lootitem)
			LootersAid.rr = 0
		else
			if LootersAid.ffaCheck:GetChecked() then msg = format(L["%s won %s with a roll of %d"], LootersAid.winner, LootersAid.lootitem, LootersAid.wRoll)
			else msg = format(L["%s won %s with a roll of %d taking them to %d (%s)"], LootersAid.winner, LootersAid.lootitem, LootersAid.wRoll, newcount, sp) end
		end

		local gmsg = format(L["%s won %s"], LootersAid.winner, LootersAid.lootitem)
		local dest = "RAID"
		if LootersAid.db.profile.rwwin then dest = "RAID_WARNING" end

		if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format("%s (%s)", msg, dest), 0, 1, 0)
		elseif not LootersAid.db.profile.dismess then
			ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", msg, dest, nil, nil)
			GiveMasterLoot(lid, pid)
			if LootersAid.db.profile.guildwin == true then ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", gmsg, "GUILD", nil, nil) end
		end

		LootersAidProgress:AddMessage(msg, 0, 1, 0, 1)
		--record the loot
		local itemId = select(2, strsplit(":", LootersAid.lootitem))
		db[format("loot%d_%d", lid, itemId)] = LootersAid.winner
		LootersAid.lootitem = nil
	end

	LootersAid.monitorRolls = 0
	LootersAid.dis = 0

	--check for any duplicate items
	if LootersAid.lootQty > 1 then StaticPopup_Show("LOOTERSAID_SECOND") end
	LootersAid.p1tmp = nil
	LootersAid.p2tmp = nil
	LootersAid.rerolling = 0
end

function LootersAid:disLoot()
	local disenchanter = LootersAidDB.disenchanter
	local p, pid
	if disenchanter then pid = LootersAid:isEligible(disenchanter)
		if pid or LootersAid.testmode then
			LootersAid.lootQty = 0
			LootersAid.winner = disenchanter
			LootersAid.wRoll = 0
			LootersAid.dis = 1
			LootersAid:awardLoot()
		else disenchanter = nil end
	end
	if not disenchanter then StaticPopup_Show("LOOTERSAID_INVALID") end
end

function LootersAid:reroll()
	local bossName
	LootersAid.monitorRolls = 1
	LootersAid.rerolling = 1
	LootersAid:resetRolls()
	bossName = LootersAid:GetEncounter()
	if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(format(L["Rolls tied, %s and %s roll again now"], LootersAid.winner, LootersAid.second), 0, 1, 0)
	else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(L["Looter's Aid: Loot from %s"], bossName), "RAID_WARNING", nil, nil) end
end

local function getRRWinner(roll)
	local w = _G.UNKNOWN
	for _, p in ipairs(LootersAid.pid) do
		if p.pos == roll then
			w = p.player
			break
		end
	end
	return w
end

function LootersAid:analyseRolls()
	local multiplier, dbname
	local thisRoll, points
	local playername, roll

	if LootersAid.mainCheck:GetChecked() then dbname = format("%s_", L["ms"])
	else dbname = format("%s_", L["os"]) end

	for _, r in pairs(LootersAid.rolls) do
		local playername = r.player
		if LootersAid.rr == 1 then
			if playername == UnitName("player") then
				thisRoll = r.playerroll
				LootersAid.winningRoll = thisRoll
				LootersAid.winner = getRRWinner(thisRoll)
				LootersAid.wRoll = thisRoll
				LootersAid.wRollPoints = 0
				LootersAid.winRollTrack = thisRoll
				points = ""
				LootersAid.winRoll:SetFormattedText("%s:|cff%s %s|cff%s %s|cff%s %s", L["Winning roll"], LootersAid.playercolour, playername, LootersAid.rollcolour, thisRoll, LootersAid.pointscolour, points)
			end
		elseif string.sub(playername, 1, 1) ~= "_" then roll = r.playerroll
			if LootersAid.ffaCheck:GetChecked() == 1 then multiplier = 0
			else multiplier = LootersAidDB[format("%s%s", dbname, playername)] or 0 end
			if multiplier == 0 then points = ""
			else points = multiplier end
			thisRoll = roll + (tonumber(multiplier) * 100)

			if LootersAid.db.profile.useattendance then
				local attendances = LootersAidDB.attendance[playername]
				local attendance = 1
				if attendances then attendance = attendances.count end
				thisRoll = thisRoll + (attendance * 1000)
				points = format("%s (+%d)", points, attendance)
			end
			
			if roll > LootersAid.highestRoll then
				LootersAid.highestRoll = roll
				LootersAid.highRoll:SetFormattedText("%s:|cff%s %s|cff%s %s|cff%s %s", L["Highest roll"], LootersAid.playercolour, playername, LootersAid.rollcolour, roll, LootersAid.pointscolour, points)
			end

			if thisRoll > LootersAid.winningRoll then
				if LootersAid.winningRoll > LootersAid.secondRoll then
					LootersAid.secondRoll = LootersAid.winningRoll
					LootersAid.second = LootersAid.winner
					LootersAid.sRoll = roll
					LootersAid.sRoll = tonumber(multiplier)
					LootersAid.secRoll:SetFormattedText("%s:|cff%s %s|cff%s %s|cff%s %s", L["Second place"], LootersAid.playercolour, LootersAid.winner, LootersAid.rollcolour, LootersAid.winRollTrack, LootersAid.pointscolour, points)
				end
				LootersAid.winningRoll = thisRoll
				LootersAid.winner = playername
				LootersAid.wRoll = roll
				LootersAid.wRollPoints = tonumber(multiplier)
				LootersAid.winRollTrack = roll
				LootersAid.winRoll:SetFormattedText("%s:|cff%s %s|cff%s %s|cff%s %s", L["Winning roll"], LootersAid.playercolour, playername, LootersAid.rollcolour, roll, LootersAid.pointscolour, points)
				LootersAid:SetWinnerEquip()
			end

			if thisRoll < LootersAid.winningRoll and thisRoll > LootersAid.secondRoll then
				LootersAid.secondRoll = thisRoll
				LootersAid.second = playername
				LootersAid.sRoll = roll
				LootersAid.sRoll = tonumber(multiplier)
				LootersAid.secRoll:SetFormattedText("%s:|cff%s %s|cff%s %s|cff%s %s", L["Second place"], LootersAid.playercolour, playername, LootersAid.rollcolour, roll, LootersAid.pointscolour, points)
			end
		end
	end

	if LootersAid.sRoll == LootersAid.wRoll and LootersAid.sRollPoints == LootersAid.wRollPoints then --tied rolls
		if LootersAid.winner ~= "" and LootersAid.second ~= "" then
			LootersAid.tielabel:Show()
			LootersAid.awardButton:SetText(LootersAid.AWARDREROLL)
		end
	else
		LootersAid.tielabel:Hide()
		LootersAid.awardButton:SetText(L["Award Loot"])
	end
	if LootersAid.rFrame:IsVisible() then
		LootersAid.rFrame:Hide()
		LootersAid.rFrame:Show()
	end
end

function LootersAid:raidScores()
	local spec = L["os"]
	if LootersAid.mainCheck:GetChecked() then spec = L["ms"] end
	LootersAid:printCounts(spec, "raid", 0)
end

function LootersAid:chatScores()
	local spec = L["os"]
	if LootersAid.mainCheck:GetChecked() == 1 then spec = L["ms"] end
	LootersAid:printCounts(spec, "chat", 0)
end

function LootersAid:spamLoot()
	local threshold = GetLootThreshold()
	local spamLink
	local dest = "RAID"
	local bossName = LootersAid:GetEncounter()
	if LootersAid.db.profile.rwlist then dest = "RAID_WARNING" end
	if LootersAid.testmode == true then
		bossName = "Super Uber Mega Boss"
		DEFAULT_CHAT_FRAME:AddMessage(format("%s (%s)", format(L["Looter's Aid: Loot from %s"], bossName), dest), 0, 1, 0)
	else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", format(L["Looter's Aid: Loot from %s"], bossName), dest, nil, nil) end
	for slot = 0, GetNumLootItems() do
		if not GetLootSlotLink(slot) then --do nothing for now
		else
			if LootersAid:getItemQuality(slot) >= threshold then spamLink = GetLootSlotLink(slot)
				if LootersAid.testmode then DEFAULT_CHAT_FRAME:AddMessage(spamLink, 0, 1, 0)
				else ChatThrottleLib:SendChatMessage("NORMAL", "LootersAid", spamLink, dest, nil, nil) end
			end
		end
	end
end

function LootersAid:GetTTLink(slot)
	local link
	if LootersAid.testmode and slot == "loot" then link = select(2, GetItemInfo(LootersAid.testloot))
	else
		if slot == "loot" then link = LootersAid.ttlink
		elseif slot == "equip1" then link = LootersAid.equipslot1
		elseif slot == "equip2" then link = LootersAid.equipslot2
		end
	end
	return link
end

function LootersAid:progressframeOnUpdate(this, elapsed)
	local flash = LootersAidEndFlash
	local flashtimer = LootersAid.frame.flashtimer + elapsed
	if LootersAidProgress:AtBottom() then
		if flash:IsShown() then flash:Hide() end
		LootersAid.frame:SetScript("OnUpdate", nil)
	elseif flashtimer < _G.CHAT_BUTTON_FLASH_TIME then LootersAid.frame.flashtimer = flashtimer
	else LootersAid.frame.flashtimer = 0
		if flash:IsShown() then flash:Hide()
		else flash:Show() end
	end
end

local function checkTie()
	if LootersAid.wRoll == LootersAid.sRoll and LootersAid.wRollPoints == LootersAid.sRollPoints then --tied roll
		if LootersAid.winner ~= "" and LootersAid.second ~= "" then StaticPopup_Show("LOOTERSAID_REROLL") end
	else LootersAid:awardLoot() end --no tie
end

function LootersAid:createLAFrame()
	local frame = CreateFrame("Frame", "LootersAidMain", UIParent)
	LootersAid.lootButton = CreateFrame("Button", "LootersAidLootButton", frame,"LootersAidButtonTemplate")
	LootersAid.slot1Button = CreateFrame("Button", "LootersAidSlot1Button", frame,"LootersAidButtonTemplate")
	LootersAid.slot2Button = CreateFrame("Button", "LootersAidSlot2Button", frame,"LootersAidButtonTemplate")
	local winneritems = LootersAid.slot1Button:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local rscoresButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	local cscoresButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	LootersAid.lootName = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.mainCheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	LootersAid.offCheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local mainText = LootersAid.mainCheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local offText = LootersAid.offCheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.ffaCheck = CreateFrame("CheckButton", nil, frame, "OptionsCheckButtonTemplate")
	local ffaText = LootersAid.ffaCheck:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local scoresText = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.announceButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	LootersAid.awardButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	local clearButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	LootersAid.disButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	local specFrame = CreateFrame("Frame", nil, frame)
	local winFrame = CreateFrame("Frame", nil, frame)
	local specTex = specFrame:CreateTexture()
	local winTex = specFrame:CreateTexture()
	local playersButton = CreateFrame("Button", nil, frame, nil)
	local rollsButton = CreateFrame("Button", nil, frame, nil)
	local spamButton = CreateFrame("Button", nil, frame, nil)
	local lootUp = CreateFrame("Button", nil, frame, nil)
	local lootDown = CreateFrame("Button", nil, frame, nil)
	local recordButton = CreateFrame("Button", nil, frame, nil)
	local tc = "|cff568bff"
	local progressframe = CreateFrame("ScrollingMessageFrame", "LootersAidProgress", frame)
	local upbutton = CreateFrame("Button", "ScrollAlertFrameUpBtn", frame)
	local downbutton = CreateFrame("Button","ScrollAlertFrameDownBtn", frame)
	local endbutton = CreateFrame("Button", "ScrollAlertFrameEndBtn", frame)
	local endflash = endbutton:CreateTexture("LootersAidEndFlash", "OVERLAY")
	LootersAid.cdctime = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.class = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.tielabel = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	LootersAid.pFrame = LootersAid:createPlayersFrame(frame, "LootersAidPlayers")
	LootersAid.rFrame = LootersAid:createPlayersFrame(frame, "LootersAidRolls")
	LootersAid.highRoll = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.winRoll = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	LootersAid.secRoll = frame:CreateFontString(nil, "ARWORK", "GameFontNormal")

	local function frameMouseUp()
		frame:StopMovingOrSizing()
		LootersAid.db.profile.x = frame:GetLeft()
		LootersAid.db.profile.y = frame:GetBottom()
	end

	frame:Hide()
	frame:SetMovable(true)
	frame:EnableMouse(true)
	frame:EnableKeyboard(true)
	frame:SetClampedToScreen(true)
	frame:SetFrameStrata("DIALOG")
	frame:SetHeight(LootersAid.LAHeight)
	frame:SetWidth(LootersAid.LAWidth)
	frame:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = {left = 4, right = 4, top = 4, bottom = 4}})
	frame:SetScript("OnMouseDown", function() frame:StartMoving() end)
	frame:SetScript("OnMouseUp", function() frameMouseUp() end)
	frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", LootersAid.db.profile["x"], LootersAid.db.profile["y"])
	frame:EnableMouseWheel(true)

	local function frameOnShow()
		frame:SetBackdropColor(0,0,0,0.9)
		if LootersAid.announceButton:GetText() == L["Countdown"] then
			LootersAid.announceButton:SetText(_G.CHAT_ANNOUNCE)
			LootersAid.announceButton:SetScript("OnEnter", nil)
			LootersAid.announceButton:SetScript("OnLeave", nil)
			LootersAid.announceButton:Enable()
		end

		if LootersAid.db.profile.ffadefault then
			LootersAid.ffaCheck:SetChecked(1)
			LootersAid.mainCheck:Hide()
			LootersAid.offCheck:Hide()
			rscoresButton:Hide()
			cscoresButton:Hide()
			scoresText:Hide()
			LootersAid.pFrame:Hide()
			playersButton:Hide()
		else
			LootersAid.ffaCheck:SetChecked(nil)
			LootersAid.mainCheck:Show()
			LootersAid.offCheck:Show()
			rscoresButton:Show()
			cscoresButton:Show()
			scoresText:Show()
			playersButton:Show()
			if LootersAid.pFrameIsShown == 1 then LootersAid.pFrame:Show() end
		end

		if LootersAid.testmode then
			local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(LootersAid.testloot)
			SetItemButtonTextureVertexColor(LootersAid.lootButton, 1.0, 1.0, 1.0)
			SetItemButtonNormalTextureVertexColor(LootersAid.lootButton, 1.0, 1.0, 1.0)
			LootersAidLootButtonIconTexture:SetTexture(itemTexture)
			LootersAid.lootName:SetFormattedText("|cff9335ee%s", (itemName or _G.UNKNOWN))
			LootersAid.lootitem = LootersAid.testloot
			LootersAid:SetLootInfo(LootersAid.lootitem)
		end
		LootersAid.tielabel:Hide()
	end

	frame:SetScript("OnShow", frameOnShow)
	frame:SetScript("OnHide", function() if frame.isResizing then frame:StopMovingOrSizing(); frame.isResizing = false; end end)
	frame:SetScript("OnHide", function() if frame.isMoving then frame:StopMovingOrSizing(); frame.isMoving = false; end end)
	frame:SetPoint("CENTER", UIParent, "CENTER", 0, 250)

	local function lbOnEnter(this, slottype)
		local link = LootersAid:GetTTLink(slottype)
		local anchor
		if slottype == "loot" then anchor = "ANCHOR_LEFT"
		else anchor = "ANCHOR_BOTTOM" end
		if (link or "") ~= "" then
			GameTooltip:SetOwner(this, anchor)
			GameTooltip:SetHyperlink(link)
			CursorUpdate(this)
		end
	end

	LootersAid.lootButton:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -10)
	LootersAid.lootButton:SetScript("OnEnter", function(this) lbOnEnter(this, "loot") end)
	LootersAidLootButtonStock:Hide()
	LootersAidLootButtonCount:Hide()
	LootersAidLootButtonNameFrame:Hide()
	LootersAid.lootName:SetPoint("TOPLEFT", LootersAid.lootButton, "TOPRIGHT", 10, -10)
	LootersAid.lootName:SetFont(GameFontNormal:GetFont(), 14)

	lootUp:SetWidth(40)
	lootUp:SetHeight(40)
	lootUp:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -35, -1)
	lootUp:SetDisabledTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Disabled")
	lootUp:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Up")
	lootUp:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-Down")
	lootUp:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollUpButton-HighLight")

	local function lootUpOnClick()
		local numItems = #LootersAid.allLoot
		local l
		if numItems > 1 then
			if LootersAid.lootPos > 1 then
				LootersAid.lootPos = LootersAid.lootPos - 1
				l = LootersAid.allLoot[LootersAid.lootPos]
				LootersAid.lootitem = l.loot
				LootersAid.lootslot = l.slot
				LootersAid:addLoot(LootersAid.lootslot)
			end
		end
	end

	lootUp:SetScript("OnClick", lootUpOnClick)

	local function lootUpOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["Previous item"], 1, 1, 1)
	end

	local function lootUpOnLeave() GameTooltip:Hide() end

	lootUp:SetScript("OnEnter", function(this) lootUpOnEnter(this) end)
	lootUp:SetScript("OnLeave", lootUpOnLeave)

	lootDown:SetWidth(40)
	lootDown:SetHeight(40)
	lootDown:SetPoint("TOPLEFT", lootUp, "BOTTOMLEFT", 0, 13)
	lootDown:SetDisabledTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Disabled")
	lootDown:SetNormalTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
	lootDown:SetPushedTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Down")
	lootDown:SetHighlightTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-HighLight")

	local function lootDownOnClick()
		local numItems = #LootersAid.allLoot
		local l
		if numItems > 1 then
			if LootersAid.lootPos < numItems then
				LootersAid.lootPos = LootersAid.lootPos + 1
				l = LootersAid.allLoot[LootersAid.lootPos]
				LootersAid.lootitem = l.loot
				LootersAid.lootslot = l.slot
				LootersAid:addLoot(LootersAid.lootslot)
			end
		end
	end

	lootDown:SetScript("OnClick", lootDownOnClick)

	local function lootDownOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["Next item"], 1, 1, 1)
	end

	local function lootDownOnLeave() GameTooltip:Hide() end
	lootDown:SetScript("OnEnter", function(this) lootDownOnEnter(this) end)
	lootDown:SetScript("OnLeave", lootUpOnLeave)

	local function frameOnMouseWheel(this, direction)
		if direction == 1 then lootUpOnClick()
		else lootDownOnClick() end
	end

	frame:SetScript("OnMouseWheel", frameOnMouseWheel)
	spamButton:SetWidth(16)
	spamButton:SetHeight(16)
	spamButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -15, -13)
	spamButton:SetDisabledTexture("Interface\\Buttons\\UI-GuildButton-MOTD-Disabled")
	spamButton:SetNormalTexture("Interface\\Buttons\\UI-GuildButton-MOTD-Up")
	spamButton:SetPushedTexture("Interface\\Buttons\\UI-GuildButton-MOTD-Disabled")
	spamButton:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
	spamButton:SetScript("OnClick", function() LootersAid:spamLoot() end)

	local function spamOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["List the available loot"], 1, 1, 1)
	end

	local function spamOnLeave() GameTooltip:Hide() end
	spamButton:SetScript("OnEnter", function(this) spamOnEnter(this) end)
	spamButton:SetScript("OnLeave", spamOnLeave)

	local function recordOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["Show loot record"], 1, 1, 1)
	end

	local function recordOnLeave() GameTooltip:Hide() end
	recordButton:SetWidth(16)
	recordButton:SetHeight(16)
	recordButton:SetPoint("TOPRIGHT", spamButton, "BOTTOMRIGHT", 0, -10)
	recordButton:SetDisabledTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Disabled")
	recordButton:SetNormalTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up")
	recordButton:SetPushedTexture("Interface\\Buttons\\UI-GuildButton-PublicNote-Disabled")
	recordButton:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
	recordButton:SetScript("OnClick", function() LootersAid:showLootRecord("RAID") end)
	recordButton:SetScript("OnEnter", function(this) recordOnEnter(this) end)
	recordButton:SetScript("OnLeave", recordOnLeave)

	specFrame:SetPoint("TOPLEFT", LootersAid.lootButton, "TOPLEFT", 0, -50)
	specFrame:SetHeight(180)
	specFrame:SetWidth(130)
	specFrame:SetBackdrop({edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16})
	specFrame:SetBackdropBorderColor(0.6, 0.6, 0.6, 0.6)
	specTex:SetAllPoints(specFrame)

	winFrame:SetPoint("TOPLEFT", specFrame, "TOPLEFT", 135, 0)
	winFrame:SetHeight(180)
	winFrame:SetWidth(245)
	winFrame:SetBackdrop({edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 16})
	winFrame:SetBackdropBorderColor(0.6, 0.6, 0.6, 0.6)
	winTex:SetAllPoints(winFrame)

	LootersAid.tielabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 70, -40)
	LootersAid.tielabel:SetWidth(240)
	LootersAid.tielabel:SetFormattedText("|cffff6600%s", L["Rolls tied"])
	LootersAid.tielabel:Hide()
	LootersAid.pFrame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 2, 0)

	local function playersClick()
		if not LootersAid.pFrame:IsVisible() then
			LootersAid.rFrame:Hide()
			LootersAid.pFrame:Show()
			LootersAid.pFrameIsShown = 1
		end
	end

	playersButton:SetWidth(32)
	playersButton:SetHeight(32)
	playersButton:SetPoint("TOPLEFT", winFrame, "TOPRIGHT", -35, -3)
	playersButton:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Disabled")
	playersButton:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
	playersButton:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Down")
	playersButton:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	playersButton:SetScript("OnClick", playersClick)

	local function playersOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["Edit counts"], 1, 1, 1)
	end

	local function playersOnLeave() GameTooltip:Hide() end
	playersButton:SetScript("OnEnter", function(this) playersOnEnter(this) end)
	playersButton:SetScript("OnLeave", playersOnLeave)

	LootersAid.mainCheck:SetPoint("TOPLEFT", LootersAid.lootButton, "TOPLEFT", 5, -55)
	mainText:SetPoint("TOPLEFT", LootersAid.mainCheck, "TOPRIGHT", 10, -8)
	mainText:SetText(L["Main Spec"])
	LootersAid.mainCheck:SetChecked(1)

	local function radioOnClick(chk1, chk2)
		if chk1:GetChecked() and chk2:GetChecked() then
			chk2:SetChecked(false)
			LootersAid:getCount()
			if LootersAid.pFrame:IsVisible() then
				LootersAid.pFrame:Hide()
				LootersAid.pFrame:Show()
			end
		end
	end

	LootersAid.mainCheck:SetScript("OnClick", function() radioOnClick(LootersAid.mainCheck, LootersAid.offCheck) end)
	LootersAid.offCheck:SetPoint("TOPLEFT", LootersAid.mainCheck, "TOPLEFT", 0, -20)
	offText:SetPoint("TOPLEFT", LootersAid.offCheck, "TOPRIGHT", 10, -8)
	offText:SetText(L["Off Spec"])
	LootersAid.offCheck:SetScript("OnClick", function() radioOnClick(LootersAid.offCheck, LootersAid.mainCheck) end)

	local function ffaOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["No -1 penalties counted or incurred"], 1, 1, 1)
	end

	local function ffaOnLeave() GameTooltip:Hide() end

	local function ffaOnClick()
		if LootersAid.announceButton:GetText() == L["Countdown"] then
			LootersAid.announceButton:SetText(_G.CHAT_ANNOUNCE)
			LootersAid.announceButton:SetScript("OnEnter", nil)
			LootersAid.announceButton:SetScript("OnLeave", nil)
			LootersAid.announceButton:Enable()
		end

		if LootersAid.ffaCheck:GetChecked() then
			LootersAid.mainCheck:Hide()
			LootersAid.offCheck:Hide()
			rscoresButton:Hide()
			cscoresButton:Hide()
			scoresText:Hide()
			LootersAid.pFrame:Hide()
			playersButton:Hide()
		else
			LootersAid.mainCheck:Show()
			LootersAid.offCheck:Show()
			rscoresButton:Show()
			cscoresButton:Show()
			scoresText:Show()
			playersButton:Show()
			if LootersAid.pFrameIsShown == 1 then LootersAid.pFrame:Show() end
		end
	end

	LootersAid.ffaCheck:SetPoint("TOPLEFT", LootersAid.offCheck, "TOPLEFT", 0, -20)
	ffaText:SetPoint("TOPLEFT", LootersAid.ffaCheck, "TOPRIGHT", 10, -8)
	ffaText:SetText(L["Free for all"])
	LootersAid.ffaCheck:SetScript("OnEnter", ffaOnEnter)
	LootersAid.ffaCheck:SetScript("OnLeave", ffaOnLeave)
	LootersAid.ffaCheck:SetScript("OnClick", ffaOnClick)

	LootersAid.cdctime:SetPoint("TOPLEFT", LootersAid.ffaCheck, "TOPLEFT", 50, -22)
	LootersAid.cdctime:Hide()

	LootersAid.highRoll:SetPoint("TOPLEFT", mainText, "TOPLEFT", 100, 0)
	LootersAid.highRoll:SetFormattedText("%s:|cff%s %s", L["Highest roll"], LootersAid.playercolour, L["Nobody"])
	LootersAid.winRoll:SetPoint("TOPLEFT", offText, "TOPLEFT", 100, 0)
	LootersAid.winRoll:SetFormattedText("%s:|cff%s %s", L["Winning roll"], LootersAid.playercolour, L["Nobody"])
	LootersAid.secRoll:SetPoint("TOPLEFT", LootersAid.winRoll, "TOPLEFT", 0, -20)
	LootersAid.secRoll:SetFormattedText("%s:|cff%s %s", L["Second place"], LootersAid.playercolour, L["Nobody"])

	winneritems:SetFormattedText("%s%s", tc, L["Winner's current gear"])
	winneritems:SetWidth(100)
	winneritems:SetHeight(62)
	winneritems:SetPoint("TOPLEFT", LootersAid.secRoll, "BOTTOMLEFT", 0, 0)

	LootersAid.class:SetWidth(100)
	LootersAid.class:SetPoint("TOPLEFT", winneritems, "BOTTOMLEFT", 0, 12)

	LootersAid.slot1Button:SetPoint("TOPLEFT", winneritems, "TOPRIGHT", 5, -18)
	LootersAid.slot1Button:SetScript("OnEnter", function(this) lbOnEnter(this, "equip1") end)
	LootersAidSlot1ButtonStock:Hide()
	LootersAidSlot1ButtonCount:Hide()
	LootersAidSlot1ButtonNameFrame:Hide()

	LootersAid.slot2Button:SetPoint("TOPLEFT", LootersAid.slot1Button, "TOPRIGHT", 10, 0)
	LootersAid.slot2Button:SetScript("OnEnter", function(this) lbOnEnter(this, "equip2") end)
	LootersAidSlot2ButtonStock:Hide()
	LootersAidSlot2ButtonCount:Hide()
	LootersAidSlot2ButtonNameFrame:Hide()

	LootersAid.slot1Button:Hide()
	LootersAid.slot2Button:Hide()

	LootersAid.announceButton:SetPoint("TOPLEFT", LootersAid.ffaCheck, "TOPLEFT", 3, -60)
	LootersAid.announceButton:SetHeight(30)
	LootersAid.announceButton:SetWidth(114)
	LootersAid.announceButton:SetText(_G.CHAT_ANNOUNCE)
	LootersAid.announceButton:SetScript("OnDoubleClick", function() end)
	LootersAid.announceButton:SetScript("OnClick", function() LootersAid:lootAnnounce() end)

	clearButton:SetPoint("TOPLEFT", LootersAid.announceButton, "TOPLEFT", 0, -33)
	clearButton:SetHeight(30)
	clearButton:SetWidth(114)
	clearButton:SetText(_G.RESET)
	clearButton:SetScript("OnClick", function() LootersAid:rollReset() end)

	LootersAid.awardButton:SetPoint("TOPLEFT", clearButton, "TOPRIGHT", 20, 0)
	LootersAid.awardButton:SetHeight(30)
	LootersAid.awardButton:SetWidth(114)
	LootersAid.awardButton:SetText(L["Award Loot"])
	LootersAid.awardButton:SetScript("OnClick", checkTie)

	LootersAid.disButton:SetPoint("TOPLEFT", LootersAid.awardButton, "TOPRIGHT", 2, 0)
	LootersAid.disButton:SetHeight(30)
	LootersAid.disButton:SetWidth(114)
	LootersAid.disButton:SetText(L["Disenchant"])
	LootersAid.disButton:SetScript("OnClick", function() LootersAid:disLoot() end)

	LootersAid.rFrame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 2, 0)

	local function rollsClick()
		if not LootersAid.rFrame:IsVisible() == nil then
			LootersAid.pFrame:Hide()
			LootersAid.rFrame:Show()
		end
	end

	rollsButton:SetWidth(32)
	rollsButton:SetHeight(32)
	rollsButton:SetPoint("TOPLEFT", playersButton, "TOPLEFT", 0, -85)
	rollsButton:SetDisabledTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Disabled")
	rollsButton:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
	rollsButton:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Down")
	rollsButton:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	rollsButton:SetScript("OnClick", rollsClick)

	local function rollsOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["Edit rolls"], 1, 1, 1)
	end

	local function rollsOnLeave() GameTooltip:Hide() end
	rollsButton:SetScript("OnEnter", function(this) rollsOnEnter(this) end)
	rollsButton:SetScript("OnLeave", rollsOnLeave)

	progressframe:SetWidth(LootersAid.LAWidth - 55)
	progressframe:SetHeight(80)
	progressframe:EnableMouse(true)
	progressframe:EnableMouseWheel(true)
	progressframe:SetJustifyV("BOTTOM")
	progressframe:SetJustifyH("LEFT")
	progressframe:SetFadeDuration(60)
	progressframe:SetMaxLines(100)
	progressframe:SetPoint("TOPLEFT", specFrame, "BOTTOMLEFT", 5, -5)
	progressframe:SetFont("Fonts\\FRIZQT__.TTF", 10)
	progressframe:SetScript("OnHyperlinkClick", function(this, link, text, button) SetItemRef(link, text, button) end)
	LootersAidProgress = progressframe

	local function supOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(_G.COMBAT_TEXT_SCROLL_UP, 1, 1, 1)
	end

	local function supOnLeave() GameTooltip:Hide() end

	local function supOnClick()
		PlaySound("UChatScrollButton")
		progressframe:ScrollUp()
		if LootersAid.frame:GetScript("OnUpdate") == nil then
			LootersAid.frame:SetScript("OnUpdate", function(this, elapsed) LootersAid:progressframeOnUpdate(this, elapsed) end)
		end
	end

	upbutton:SetHeight(28)
	upbutton:SetWidth(28)
	upbutton:SetPoint("TOPRIGHT", progressframe, "TOPRIGHT", 25, 0)
	upbutton:SetScript("OnClick", supOnClick)
	upbutton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Up")
	upbutton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Down")
	upbutton:SetDisabledTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Disabled")
	upbutton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	upbutton:SetScript("OnEnter", function(this) supOnEnter(this) end)
	upbutton:SetScript("OnLeave", supOnLeave)
	upbutton:SetScript("OnClick", supOnClick)

	local function sdownOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(_G.COMBAT_TEXT_SCROLL_DOWN, 1, 1, 1)
	end

	local function sdownOnLeave() GameTooltip:Hide() end

	local function sdownOnClick()
		PlaySound("UChatScrollButton")
		progressframe:ScrollDown()
	end

	downbutton:SetHeight(28)
	downbutton:SetWidth(28)
	downbutton:SetPoint("TOP", upbutton, "TOP", 0, -27)
	downbutton:SetScript("OnClick", sdownOnClick)
	downbutton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
	downbutton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Down")
	downbutton:SetDisabledTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Disabled")
	downbutton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	downbutton:SetScript("OnEnter", function(this) sdownOnEnter(this) end)
	downbutton:SetScript("OnLeave", sdownOnLeave)
	downbutton:SetScript("OnClick", sdownOnClick)

	local function progressframeOnMouseWheel(this, direction)
		if direction == 1 then supOnClick()
		else sdownOnClick() end
	end

	progressframe:SetScript("OnMouseWheel", progressframeOnMouseWheel)

	local function sendOnEnter(this)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
		GameTooltip:SetText(_G.KEY_END, 1, 1, 1)
	end

	local function sendOnLeave() GameTooltip:Hide() end

	local function sendOnClick()
		PlaySound("UChatScrollButton")
		progressframe:ScrollToBottom()
		endflash:Hide()
		LootersAid.frame:SetScript("OnUpdate", nil) 
	end

	endbutton:SetHeight(28)
	endbutton:SetWidth(28)
	endbutton:SetPoint("TOP", downbutton, "TOP", 0, -27)
	endbutton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Up")
	endbutton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Down")
	endbutton:SetDisabledTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Disabled")
	endbutton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	endbutton:SetScript("OnEnter", function(this) sendOnEnter(this) end)
	endbutton:SetScript("OnLeave", sendOnLeave)
	endbutton:SetScript("OnClick", sendOnClick)

	endflash:Hide()
	endflash:SetHeight(28)
	endflash:SetWidth(28)
	endflash:SetPoint("TOP", downbutton, "TOP", 0, -27)
	endflash:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-BlinkHilight")

	scoresText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 20, 20)
	scoresText:SetText(L["Show counts in:"])

	rscoresButton:SetPoint("TOPLEFT", scoresText, "TOPRIGHT", 25, 7)
	rscoresButton:SetHeight(30)
	rscoresButton:SetWidth(100)
	rscoresButton:SetText(_G.CALENDAR_TYPE_RAID)
	rscoresButton:SetScript("OnClick", function() LootersAid:raidScores() end)

	cscoresButton:SetPoint("TOPLEFT", rscoresButton, "TOPRIGHT", 40, 0)
	cscoresButton:SetHeight(30)
	cscoresButton:SetWidth(100)
	cscoresButton:SetText(_G.CHAT)
	cscoresButton:SetScript("OnClick", function() LootersAid:chatScores() end)

	return frame
end

function LootersAid:addLoot(slot)
	local button = LootersAid.lootButton
	local texture, item, _, quality, locked = GetLootSlotInfo(slot)
	local colour = format("|c%s", select(4, GetItemQualityColor(quality)))
	LootersAid.ttlink = GetLootSlotLink(slot)
	LootersAid:SetLootInfo(LootersAid.lootitem)
	LootersAidLootButtonIconTexture:SetTexture(texture)
	if locked then
		SetItemButtonTextureVertexColor(button, 0.9, 0, 0)
		SetItemButtonNormalTextureVertexColor(button, 0.9, 0, 0)
	else
		SetItemButtonTextureVertexColor(button, 1.0, 1.0, 1.0)
		SetItemButtonNormalTextureVertexColor(button, 1.0, 1.0, 1.0)
	end
	LootersAid.lootslot = slot
	LootersAid.lootName:SetFormattedText("%s%s", colour, item)
	button:Show()
end

function LootersAid:resetRolls()
	LootersAid.winner = ""
	LootersAid.highestRoll = 0
	LootersAid.winningRoll = -100000
	LootersAid.secondRoll = -100000
	LootersAid.winRollTrack = 0
	LootersAid.wRoll = 0
	LootersAid.wRollPoints = 0
	LootersAid.sRollPoints = 0
	LootersAid.sRoll = 0
	LootersAid.slot1Button:Hide()
	LootersAid.slot2Button:Hide()
	LootersAid.equipslot1 = ""
	LootersAid.equipslot2 = ""
	LootersAid.tielabel:Hide()
end

function LootersAid:clearLoot()
	if LootersAid.lootFrame then
		LootersAid.highRoll:SetFormattedText("%s:|cff%s %s", L["Highest roll"], LootersAid.playercolour, L["Nobody"])
		LootersAid.winRoll:SetFormattedText("%s:|cff%s %s", L["Winning roll"], LootersAid.playercolour, L["Nobody"])
		LootersAid.secRoll:SetFormattedText("%s:|cff%s %s", L["Second place"], LootersAid.playercolour, L["Nobody"])
		LootersAidLootButtonIconTexture:SetTexture(nil)
		LootersAid.lootName:SetText("")
	end

	LootersAid.lootslot = ""
	LootersAid.lootitem = ""
	LootersAid.slot1Button:Hide()
	LootersAid.slot2Button:Hide()
	LootersAid.equipslot1 = ""
	LootersAid.equipslot2 = ""
	LootersAid.equipslot = ""
	LootersAid.lootQty = 0
	LootersAid.hasLoot = 0
	LootersAid.dis = 0
	LootersAid:resetRolls()
end