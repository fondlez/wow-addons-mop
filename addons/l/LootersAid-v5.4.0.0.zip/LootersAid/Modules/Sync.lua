local LootersAid = LootersAid
local L = LootersAid.L
local pairs, format = pairs, format
local SendAddonMessage = SendAddonMessage

function LootersAid:sendSync()
	local pre = "LootersAid"
	for p,c in pairs(LootersAidDB) do SendAddonMessage(pre, format("%s:%s", p, c), "RAID") end
	SendAddonMessage(pre, "end:end", "RAID")
end

function LootersAid:receiveSync()
	LootersAidDB = {}
	for p, c in pairs(LootersAid.syncData) do LootersAidDB[p] = c end
	DEFAULT_CHAT_FRAME:AddMessage(L["Looter's Aid data import complete"], 0, 1, 1)
end