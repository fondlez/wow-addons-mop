local _G = _G
local LootersAid = LootersAid
local AceConfig = LibStub("AceConfig-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local AceDBOptions = LibStub("AceDBOptions-3.0")
local L = LootersAid.L
local CreateFrame, StaticPopup_Show = CreateFrame, StaticPopup_Show
local string, tonumber, table, ipairs, format = string, tonumber, table, ipairs, format

local function createMainPanel()
	local frame = CreateFrame("Frame", "LootersAidOptionsMain")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local version = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local author = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetFormattedText("|T%s:%d|t %s", "Interface\\Addons\\LootersAid\\la", 48, L["Looter's Aid"])
	title:SetPoint("CENTER", frame, "CENTER", 0, 170)	
	version:SetFormattedText("%s %s", _G.GAME_VERSION_LABEL, GetAddOnMetadata("LootersAid", "Version"))
	version:SetPoint("CENTER", frame, "CENTER", 0, 130)
	author:SetFormattedText("%s: Deepac", L["Author"])
	author:SetPoint("CENTER", frame, "CENTER", 0, 100)
	return frame
end

function LootersAid:translate()
	local dungeon = L["Nothing"]
	local raidid = LootersAidDB["LARaidID"] or ""
	local diff, inst, rdate, ds, mon
	local mstr = L["Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec"]	
	local months = {}
	mstr:gsub("([^,]*),", function(c) table.insert(months, c) end)
	if raidid ~= "" then diff = string.sub(raidid, 1, 1)
		if diff == "1" then diff = format("5/10 %s %s", _G.PLAYER, L["Normal"])
		elseif diff == "2" then diff = format("5 %s %s / 25 %s %s", _G.PLAYER, L["Heroic"], _G.PLAYER, L["Normal"])
		elseif diff == "3" then diff = format("10 %s %s", _G.PLAYER, L["Heroic"])
		elseif diff == "4" then diff = format("25 %s %s", _G.PLAYER, L["Heroic"]) end
		inst = string.match(raidid, "^%d_(.+)_")
		rdate = string.match(raidid, "^%d_.+_(%d+)")
		mon = tonumber(string.sub(rdate, 1, 2))
		if inst and rdate and mon then
			ds = format("%s %s 20%s", string.sub(rdate,3, 4), months[tonumber(string.sub(rdate, 1, 2))], string.sub(rdate, 5, 6))
			dungeon = format("%s - %s (%s)", inst, ds, diff)
		end
	end
	return dungeon
end

local checkPanel = {
	order = 1,
	type = "group",
	name = _G.MAIN_MENU,
	args = {
		showMinimapIcon = {
				order = 1,
				type = "toggle",
				width = "full",
				name = L["Minimap Icon"],
				desc = L["Toggle Minimap icon"],
				get = function() return not LootersAid.db.profile.minimap.hide end,
				set = function(info, value)
					LootersAid.db.profile.minimap.hide = not value
					if value then LootersAid.mmicon:Show("LootersAid")
					else LootersAid.mmicon:Hide("LootersAid") end
				end,
		},
		hidecheck = {
			order = 2,
			type = "toggle",
			name = L["Hide Looter's Aid whispers"],
			width = "full",
			get = function() return LootersAid.db.profile.hidewhispers end,
			set = function(info, value) LootersAid.db.profile.hidewhispers = value end,
		},
		rwcheck = {
			order = 3,
			type = "toggle",
			name = L["Disable raid warnings for multiple rolls"],
			width = "full",
			get = function() return LootersAid.db.profile.disablerw end,
			set = function(info, value) LootersAid.db.profile.disablerw = value end,
		},
		illcheck = {
			order = 4,
			type = "toggle",
			name = L["Disable raid warnings for illegal rolls"],
			width = "full",
			get = function() return LootersAid.db.profile.disableill end,
			set = function(info, value) LootersAid.db.profile.disableill = value end,
		},
		ffadefault = {
			order = 5,
			type = "toggle",
			name = L["Set Free For All as default"],
			width = "full",
			get = function() return LootersAid.db.profile.ffadefault end,
			set = function(info, value) LootersAid.db.profile.ffadefault = value end,
		},
		classcheck = {
			order = 6,
			type = "toggle",
			name = L["Ignore rolls from invalid classes"],
			width = "full",
			get = function() return LootersAid.db.profile.classcheck end,
			set = function(info, value) LootersAid.db.profile.classcheck = value end,
		},
		guildchatwin = {
			order = 7,
			type = "toggle",
			name = L["Display winner in Guild chat"],
			width = "full",
			get = function() return LootersAid.db.profile.guildwin end,
			set = function(info, value) LootersAid.db.profile.guildwin = value end,
		},
		disablemessages = {
			order = 8,
			type = "toggle",
			name = L["Do not display messages about loot winners"],
			width = "full",
			get = function() return LootersAid.db.profile.dismess end,
			set = function(info, value) LootersAid.db.profile.dismess = value end,
		},
		useattendance = {
			order = 8.5,
			type = "toggle",
			name = L["Use attendance statistics"],
			desc = L["Use raid attendance between Looters Aid resets to adjust winning roll weightings"],
			width = "full",
			get = function() return LootersAid.db.profile.useattendance end,
			set = function(info, value) LootersAid.db.profile.useattendance = value end,
		},			
		rollstop = {
			order = 9,
			type = "toggle",
			name = L["Do not disable rolls when the countdown expires"],
			width = "full",
			get = function() return LootersAid.db.profile.rollstop end,
			set = function(info, value) LootersAid.db.profile.rollstop = value end,
		},
		usecd = {
			order = 10,
			type = "toggle",
			name = L["Use the countdown timer"],
			width = "full",
			get = function() return LootersAid.db.profile.usecd end,
			set = function(info, value) LootersAid.db.profile.usecd = value end,
		},
		cdselect = {
			order = 11,
			type = "select",
			name = L["Countdown Time (Seconds)"],
			hidden = function() return not LootersAid.db.profile.usecd end,
			get = function() return LootersAid.db.profile.cdtime end,
			set = function(info, name) LootersAid.db.profile.cdtime = name end,
			values = LootersAid.cdtimes,
		},
		spacer1 = {
			order = 12,
			type = "description",
			name = "\n",
		},
		disbox = {
			order = 13,
			type = "input",
			name = L["Set the raid disenchanter"],
			get = function() return LootersAidDB.disenchanter end,
			set = function(info, newvalue)
				local player
				if ((newvalue ~= nil) and (newvalue ~= "")) then
					if (string.len(newvalue) > 1) then
						player = string.upper(string.sub(newvalue,1,1)) .. string.sub(newvalue,2)
						LootersAidDB.disenchanter = player
					end
				else LootersAidDB.disenchanter = nil end
			end,
		},
	},
}

local laMessagePanel = {
	order = 2,
	type = "group",
	name = L["Messages"],
	args = {
		rwtext = {
			order = 1,
			type = "description",
			name = L["To set a custom raid warning message you MUST place %s where you want the loot to appear. If you do not, your setting will be ignored."],
		},
		mstext = {
			order = 2,
			type = "input",
			name = L["Main Spec"],
			width = "full",
			get = function() return LootersAid.db.profile.mstext end,
			set = function(info, value) LootersAid.db.profile.mstext = value end,
		},
		ostext = {
			order = 3,
			type = "input",
			name = L["Off Spec"],
			width = "full",
			get = function() return LootersAid.db.profile.ostext end,
			set = function(info, value) LootersAid.db.profile.ostext = value end,
		},
		ffa = {
			order = 4,
			type = "input",
			name = L["Free for all"],
			width = "full",
			get = function() return LootersAid.db.profile.ffatext end,
			set = function(info, value) LootersAid.db.profile.ffatext = value end,
		},
		rwopts = {
			order = 6,
			type = "description",
			name = L["Use Raid Warnings instead of the Raid frame for the following:"],
		},
		listcheck = {
			order = 7,
			type = "toggle",
			name = L["List the available loot"],
			width = "full",
			get = function() return LootersAid.db.profile.rwlist end,
			set = function(info, value) LootersAid.db.profile.rwlist = value end,
		},
		wincheck = {
			order = 8,
			type = "toggle",
			name = L["Winning roll"],
			width = "full",
			get = function() return LootersAid.db.profile.rwwin end,
			set = function(info, value) LootersAid.db.profile.rwwin = value end,
		},
		usecheck = {
			order = 9,
			type = "toggle",
			name = L["Issue min/max roll raid warnings"],
			width = "full",
			get = function() return LootersAid.db.profile.usemaxmin end,
			set = function(info, value) LootersAid.db.profile.usemaxmin = value end,
		},
		highlowtext = {
			order = 10,
			type = "description",
			name = L["To issue a raid warning when someone rolls 1 or 100, enter a message below. Use %s instead of the player's name, e.g. %s rolled 100. Gz!"],
			hidden = function() return not LootersAid.db.profile.usemaxmin end,
		},
		maxtext = {
			order = 11,
			type = "input",
			width = "full",
			name = L["Roll of 100"],
			hidden = function() return not LootersAid.db.profile.usemaxmin end,
			get = function() return LootersAid.db.profile.maxtext end,
			set = function(info, value) LootersAid.db.profile.maxtext = value end,
		},
		mintext = {
			order = 12,
			type = "input",
			width = "full",
			name = L["Roll of 1"],
			hidden = function() return not LootersAid.db.profile.usemaxmin end,
			get = function() return LootersAid.db.profile.mintext end,
			set = function(info, value) LootersAid.db.profile.mintext = value end,
		},
	},
}

local laRaidsPanel = {
	order = 3,
	type = "group",
	name = L["Data"],
	args = {
		rwtext = {
			order = 1,
			type = "description",
			name = format("%s\n", L["Currently holding data for:"]),
		},
		dungeon = {
			order = 2,
			type = "description",
			name = function() return LootersAid:translate() end,
		},
		spacer1 = {
			order = 3,
			type = "description",
			name = "\n",
		},
		rbutton = {
			order = 4,
			type = "execute",
			name = L["Reset data"],
			func = function() StaticPopup_Show("LOOTERSAID_RESET") end,
		},
		spacer2 = {
			order = 5,
			type = "description",
			name = "\n",
		},
		syncbutton = {
			order = 6,
			type = "execute",
			name = L["Sync Data"],
			func = function() StaticPopup_Show("LOOTERSAID_TXSYNC") end,
		},
	},
}

local laGuildPanel = {
	order = 4,
	type = "group",
	name = LootersAid.guildname,
	args = {
		useranks = {
			order = 1,
			type = "toggle",
			width = "full",
			name = L["Prevent selected Guild ranks from rolling"],
			get = function() return LootersAid.db.profile.useranks end,
			set = function(info, value) LootersAid.db.profile.useranks = value end,
		},
		guildtext = {
			order = 2,
			type = "header",
			name = "",
		},
		rank1 = {
			order = 3,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[1],
			hidden = function() return (LootersAid.ranks[1] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[1]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[1]] = value
			end,
		},
		rank2 = {
			order = 4,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[2],
			hidden = function() return (LootersAid.ranks[2] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[2]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[2]] = value
			end,
		},
		rank3 = {
			order = 5,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[3],
			hidden = function() return (LootersAid.ranks[3] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[3]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[3]] = value
			end,
		},
		rank4 = {
			order = 6,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[4],
			hidden = function() return (LootersAid.ranks[4] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[4]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[4]] = value
			end,
		},
		rank5 = {
			order = 7,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[5],
			hidden = function() return (LootersAid.ranks[5] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[5]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[5]] = value
			end,
		},
		rank6 = {
			order = 8,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[6],
			hidden = function() return (LootersAid.ranks[6] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[6]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[6]] = value
			end,
		},
		rank7 = {
			order = 9,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[7],
			hidden = function() return (LootersAid.ranks[7] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[7]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[7]] = value
			end,
		},
		rank8 = {
			order = 10,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[8],
			hidden = function() return (LootersAid.ranks[8] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[8]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[8]] = value
			end,
		},
		rank9 = {
			order = 11,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[9],
			hidden = function() return (LootersAid.ranks[9] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[9]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[9]] = value
			end,
		},
		rank10 = {
			order = 12,
			type = "toggle",
			width = "full",
			name = LootersAid.ranks[10],
			hidden = function() return (LootersAid.ranks[10] == "<.....>" or not LootersAid.db.profile.useranks) end,
			get = function() 
				local ret
				if LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then
					ret = (LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[10]]) or false
				else ret = false end
				return ret
			end,
			set = function(info, value)
				if not LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] then LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)] = {} end
				LootersAid.db.profile[format("LAG_%s", LootersAid.guildname)][LootersAid.ranks[10]] = value
			end,
		},
	},
}

function LootersAid:createLootersAidOptions()
	local mainPanel = createMainPanel()
	mainPanel.name = L["Looter's Aid"]
	InterfaceOptions_AddCategory(mainPanel)
	AceConfig:RegisterOptionsTable("LootersAidCheck", checkPanel)
	AceConfig:RegisterOptionsTable("LootersAidMP", laMessagePanel)
	AceConfig:RegisterOptionsTable("LootersAidRP", laRaidsPanel)
	AceConfig:RegisterOptionsTable("LootersAidGP", laGuildPanel)
	AceConfig:RegisterOptionsTable("LootersAidProfiles", AceDBOptions:GetOptionsTable(LootersAid.db))
	LootersAid.OptionsFrame = AceConfigDialog:AddToBlizOptions("LootersAidCheck", _G.MAIN_MENU, L["Looter's Aid"])
	AceConfigDialog:AddToBlizOptions("LootersAidMP", L["Messages"], L["Looter's Aid"])
	AceConfigDialog:AddToBlizOptions("LootersAidRP", L["Data"], L["Looter's Aid"])
	AceConfigDialog:AddToBlizOptions("LootersAidGP", _G.CHAT_MSG_GUILD, L["Looter's Aid"])
	AceConfigDialog:AddToBlizOptions("LootersAidProfiles", L["Profiles"], L["Looter's Aid"])
end