local _G = _G
local LootersAid = LootersAid
local L = LootersAid.L
local table, string, pairs, ipairs, format = table, string, pairs, ipairs, format
local tonumber, StaticPopup_Show = tonumber, StaticPopup_Show
local DEFAULT_CHAT_FRAME = DEFAULT_CHAT_FRAME

function LootersAid:forgetRoll(forgetName)
	local playername = string.lower(forgetName)
	for p,r in pairs(LootersAid.rolls) do
		if string.lower(r.player) == playername or string.lower(r.player) == format("_%s", playername) then
			table.remove(LootersAid.rolls, p)
			for i, rc in ipairs(LootersAid.rollcheck) do
				if string.lower(rc) == playername or string.lower(rc) == format("_%s", playername) then table.remove(LootersAid.rollcheck, i) end
			end
			playername = format("%s%s", string.upper(string.sub(playername,1,1)), string.sub(playername,2))
			LootersAid.highRoll:SetFormattedText("%s:|cff%s %s", L["Highest roll"], LootersAid.playercolour, L["Nobody"])
			LootersAid.winRoll:SetFormattedText("%s:|cff%s %s", L["Winning roll"], LootersAid.playercolour, L["Nobody"])
			LootersAid.secRoll:SetFormattedText("%s:|cff%s %s", L["Second place"], LootersAid.playercolour, L["Nobody"])
			LootersAid.winner = ""
			LootersAid.highestRoll = 0
			LootersAid.winningRoll = -100000
			LootersAid.secondRoll = -100000
			LootersAid.winRollTrack = 0
			LootersAid.wRoll = 0
			LootersAid.sRoll = 0
			LootersAid:analyseRolls()
			break
		end
	end
end

function LootersAid:setWinner(winName)
	local findName = string.lower(winName)
	local name, playername
	for p = 1, 80 do
		name = GetRaidRosterInfo(p)
		if string.lower(name) == findName then
			playername = findName
			break
		end
	end
	if LootersAid.testmode then playername = winName end
	if playername then
		playername = format("%s%s", string.upper(string.sub(playername,1,1)), string.sub(playername,2))
		LootersAid.winner = playername
		LootersAid.winRoll:SetFormattedText("%s:|cff%s %s", L["Winning roll"], LootersAid.playercolour, playername)
		LootersAid.rr = 0
	end
end

function LootersAid:ResetData(reset)
	local raidid
	raidid = LootersAid:LAgetRaidID()
	if reset == 1 then LootersAidDB = {} end
	LootersAidDB.LARaidID = raidid
	LootersAid.counts = {}
	LootersAid.mscounts = {}
	LootersAid.oscounts = {}
	InterfaceOptionsFrame:Hide()
end

function LootersAid:showHelp()
	local f = DEFAULT_CHAT_FRAME
	local c1, c2 = "|cff4682b4", "|cffeedd82"
	f:AddMessage(L["Looter's Aid slash commands"], 0, 1, 1)
	f:AddMessage(format("%s { %s | %s | %s | %s | %s | %s | %s | %s}", L["Usage: /la or /lootersaid"], L["change"], string.lower(_G.CLOSE), L["forget"], L["ms"], L["os"], string.lower(_G.RESET), L["rolls"], L["winner"]), 0, 1 ,1)
	f:AddMessage(format(" - %s %s<%s> <%s/%s> <%s> %s: %s", L["change"], c1, string.lower(_G.PLAYER), L["ms"], L["os"], L["count"], c2, L["Change a player's count"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s: %s", string.lower(_G.CLOSE), c2, L["Close the interface window"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s: %s", L["counts"], c2, L["Show the counts window"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s<%s> %s: %s", L["dis"], c1, string.lower(_G.PLAYER), c2, L["Set the raid disenchanter"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s<%s> %s: %s", L["forget"], c1, string.lower(_G.PLAYER), c2, L["Forget a player's roll"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s: %s", string.lower(_G.KEY_INSERT_MAC), c2, L["Display help"]), 0, 1, 1)
	f:AddMessage(format(" - loot %s<%s/%s/%s> <%s> <ui> %s: %s", c1, string.lower(_G.CHAT), string.lower(_G.RAID), string.lower(_G.PARTY), string.lower(_G.PLAYER), c2, L["Show loot record"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s<%s/%s/%s> %s: %s", L["ms"], c1, string.lower(_G.CHAT), string.lower(_G.RAID), string.lower(_G.PARTY), c2, L["Show main spec counts"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s<%s/%s/%s> %s: %s", L["os"], c1, string.lower(_G.CHAT), string.lower(_G.RAID), string.lower(_G.PARTY), c2, L["Show off spec counts"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s: %s", string.lower(_G.RESET), c2, L["Reset data"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s<%s/%s/%s> %s: %s", L["rolls"], c1, string.lower(_G.CHAT), string.lower(_G.RAID), string.lower(_G.PARTY), c2, L["Show current/last rolls"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s: %s", L["sync"], c2, L["Send Looter's Aid data to a new Master Looter"]), 0, 1, 1)
	f:AddMessage(format(" - %s %s<%s> %s: %s", L["winner"], c1, string.lower(_G.PLAYER), c2, L["Change the winner"]), 0, 1, 1)
end

function LootersAid:chatCommand(input)
	local command = string.lower(input or "")
	local space = string.find(command, " ")
	local nextspace, spec, i, rc, p, r, loc
	local params, playername, rollnum, name, p, r = "", "", 0, "", "", ""
	local pfound = 0

	if space then
		params = string.lower(string.sub(command, space + 1))
		command = string.sub(command, 1, space - 1)
	end

	if command == L["ms"] then
		if params == string.lower(_G.RAID) then loc = "raid"
		elseif params == string.lower(_G.PARTY) then loc = "party"
		else loc = "chat" end
		LootersAid:printCounts(L["ms"], loc, 0)
	elseif command == "loot" then
		--space = string.find(params, " ")
		local pars = {string.split(" ", params)}
		--if space then
		--	playername = string.lower(string.sub(params, space + 1))
		--	params = string.sub(params, 1, space - 1)
		--else playername = nil end
		local ui
		if #pars == 2 then
			params = pars[1]
			playername = pars[2]
			if pars[1] == "ui" then
				params = ""
				ui = true
				playername = pars[2]
			elseif pars[2] == "ui" then
				playername = pars[1]
				params = ""
				ui = true
			end
		end
		if params == "ui" then LootersAid:showLootRecord(nil, nil, true); return
		elseif playername and ui then LootersAid:showLootRecord(nil, playername, true); return
		elseif params == string.lower(_G.RAID) then loc = "RAID"
		elseif params == string.lower(_G.PARTY) then loc = "PARTY"
		else loc = "CHAT" end
		LootersAid:showLootRecord(loc, playername)
	elseif command == L["os"] then
		if params == string.lower(_G.RAID) then loc = "raid"
		elseif params == string.lower(_G.PARTY) then loc = "party"
		else loc = "chat" end
		LootersAid:printCounts(L["os"], loc, 0)
	elseif command == string.lower(_G.RESET) then StaticPopup_Show("LOOTERSAID_RESET")
	elseif command == string.lower(_G.CLOSE) then
		LootersAid.pFrame:Hide()
		LootersAid.fpFrame:Hide()
		LootersAid.lootFrame:Hide()
	elseif command == L["counts"] then
		LootersAid.fpFrame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", LootersAid.db.profile["px"], LootersAid.db.profile["py"])
		LootersAid.fpFrame:Show()
	elseif command == L["winner"] then LootersAid:setWinner(params)
	elseif command == L["forget"] then LootersAid:forgetRoll(params)
	elseif command == L["change"] then 
		space = string.find(params, " ")
		if not space then return end
		playername = string.sub(params, 1, space - 1)
		params = string.sub(params, space + 1)
		nextspace = string.find(params, " ")
		if not nextspace then return end
		spec = string.sub(params, 1, nextspace -1)
		rollnum = tonumber(string.sub(params, nextspace + 1))
		if not rollnum then return end
		rollnum = abs(rollnum)

		for p = 1, GetNumRaidMembers() do
			name = GetRaidRosterInfo(p)
			if string.lower(name) == playername then pfound = 1 end
		end

		if (pfound == 1 or LootersAid.testmode) and rollnum then
			playername = format("%s%s", string.upper(string.sub(playername, 1, 1)), string.sub(playername, 2))
			spec = format("%s_%s", spec, playername)
			rollnum = rollnum * -1
			if rollnum == 0 then LootersAidDB[spec] = nil
			else LootersAidDB[spec] = rollnum end
			DEFAULT_CHAT_FRAME:AddMessage(format("%s: %s", L["Looter's Aid"], format(L["%s's count changed to %d"], playername, rollnum)), 0, 1, 1)
			LootersAid:refreshCounts()

			if LootersAid.pFrame:IsVisible() then
				LootersAid.pFrame:Hide()
				LootersAid.pFrame:Show()
			end

			if LootersAid.fpFrame:IsVisible() then
				LootersAid.fpFrame:Hide()
				LootersAid.fpFrame:Show()
			end
		end
	elseif command == L["rolls"] then
		if params == string.lower(_G.RAID) then loc = "raid"
		elseif params == string.lower(_G.PARTY) then loc = "party"
		else loc = "chat" end
		LootersAid:printCounts("@@", loc, 1)
	elseif command == string.lower(_G.HELP_LABEL) then LootersAid:showHelp()
	elseif command == L["dis"] then
		if params then
			params = format("%s%s", string.upper(string.sub(params, 1, 1)), string.sub(params, 2))
			LootersAidDB["disenchanter"] = params
			DEFAULT_CHAT_FRAME:AddMessage(string.format(L["Looter's Aid: Raid disenchanter set to %s"], params), 0, 1, 1)
		end
	elseif command == L["sync"] then StaticPopup_Show("LOOTERSAID_TXSYNC")
	else LootersAid:showHelp() end
end