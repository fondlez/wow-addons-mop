--[[
Copyright 2009-2013 João Cardoso
Levelland is distributed under the terms of the GNU General Public License (or the Lesser GPL).
This file is part of Levelland.

Levelland is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Levelland is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Levelland. If not, see <http://www.gnu.org/licenses/>.
--]]

local function GetQuestLevel(index, isLink)
	return strmatch(isLink and index or GetQuestLink(index) or '', 'quest:%d+:(%d+)')
end

local function GetSafeQuestName(name)
	return name:gsub('%-', '%%-'):gsub('%.', '%%.'):gsub('%?', '%%?')
end


--[[ Quest Log ]]--

local ResizeLine = QuestLogTitleButton_Resize
function QuestLogTitleButton_Resize(line)
	local tag = line.tag:IsShown() and strmatch(line.tag:GetText() or '', '%((.+)%)')
	local index = line:GetID()
	
	local isComplete = select(7, GetQuestLogTitle(index))
	local level = GetQuestLevel(index)
	
	if level and not isComplete then
		if tag then
			line.tag:SetFormattedText('(%d %s)', level, tag)
		else
			line:SetFormattedText('%s (%d)', line:GetText(), level)
		end
	end

	return ResizeLine(line)
end


--[[ Quest Watch ]]--

WatchFrame_AddObjectiveHandler(function(parent, lastLine, maxHeight, maxWidth)
	local i = 1
	
	for index = 1, GetNumQuestWatches() do
		local index = GetQuestIndexForWatch(index)
		local level = index and GetQuestLevel(index)
		
		if level then
			local title = GetSafeQuestName(GetQuestLogTitle(index) or '')
			
			while i <= #WATCHFRAME_QUESTLINES do
				local line = WATCHFRAME_QUESTLINES[i].text
				local text = line:GetText() or ''
				
				if strmatch(text, title) then
					line:SetFormattedText('%s (%d)', text, level)
					maxWidth = max(maxWidth, line:GetWidth())
					break
				else
					i = i + 1
				end
			end
		end
	end
	
	return lastLine, maxWidth, 0, 0
end)

hooksecurefunc('WatchFrame_SetWidth', function()
	WATCHFRAME_EXPANDEDWIDTH = WATCHFRAME_EXPANDEDWIDTH + 10
	WATCHFRAME_MAXLINEWIDTH = WATCHFRAME_MAXLINEWIDTH + 10
	
	if WatchFrame:IsShown() and not WatchFrame.collapsed then
		WatchFrame:SetWidth(WATCHFRAME_EXPANDEDWIDTH)
		WatchFrame_Update()
	end
end)


--[[ Gossip ]]--

local function HookGossipLines(func, n)
	hooksecurefunc(func, function(...)
		local start = GossipFrame.buttonIndex - select('#', ...) / n - 1
		
		for i = start, GossipFrame.buttonIndex - 2 do
			local level = select((i - start) * n + 2, ...)
			
			if level > -1 then
				local line = _G['GossipTitleButton'..i]
				line:SetFormattedText('%s (%d)', line:GetText(), level)
			end
		end
	end)
end

TRIVIAL_QUEST_DISPLAY = NORMAL_QUEST_DISPLAY
HookGossipLines('GossipFrameAvailableQuestsUpdate', 6)
HookGossipLines('GossipFrameActiveQuestsUpdate', 5)


--[[ Quest Greeting ]]--

QuestFrameGreetingPanel:HookScript('OnShow', function()
	local numActiveQuests = GetNumActiveQuests()
	
	for i= 1, numActiveQuests + GetNumAvailableQuests() do
		local level = i > numActiveQuests and GetAvailableLevel(i) or GetActiveLevel(i)
		local line = _G['QuestTitleButton'..i]
		
		line:SetFormattedText('%s (%d)', line:GetText(), level)
	end
end)


--[[ World Map ]]--

hooksecurefunc('WorldMapFrame_UpdateQuests', function()
	for i = 1, MAX_NUM_QUESTS do
		local frame = _G['WorldMapQuestFrame'..i]
		if not frame then
			break
		end
		
		local level = GetQuestLevel(frame.questLogIndex)
		if level then
			frame.title:SetFormattedText('%s (%d)', frame.title:GetText(), level)
		end
	end
end)

hooksecurefunc('WorldMapQuestPOI_SetTooltip', function(_, index)
	local level = GetQuestLevel(index)
	if level then
		WorldMapTooltipTextLeft1:SetFormattedText('%s (%d)', WorldMapTooltipTextLeft1:GetText(), level)
		WorldMapTooltip:Show()
	end
end)


--[[ Tooltip Links ]]--

local TooltipMeta = getmetatable(CreateFrame('GameTooltip')).__index
hooksecurefunc(TooltipMeta, 'SetHyperlink', function(tooltip, link)
	local level = GetQuestLevel(link, true)
	if level then
		local line = _G[tooltip:GetName()..'TextLeft1']
		line:SetFormattedText('%s (%d)', line:GetText() or '', level)
		tooltip:Show()
	end
end)