--Translated by Lanthi visit http://www.lanthi.es/
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("AutoLog", "esES")
if not L then return end

L["10 Players heroic raid instances where you want to log combat"] = "Guarda el combatlog de Raid 10 jugadores Modo Heroico" -- Needs review
L["10 Players Heroic Raids"] = "Raids Heroico 10 Jugadores"
L["10 Players raid instances where you want to log combat"] = "Guarda el combatlog de Raid 10 jugadores" -- Needs review
L["10 Players Raids"] = "Raids 10 Jugadores"
L["25 Players heroic raid instances where you want to log combat"] = "Guarda el combatlog de Raid 25 jugadores Modo Heroico" -- Needs review
L["25 Players Heroic Raids"] = "Raids Heroico 25 Jugadores"
L["25 Players raid instances where you want to log combat"] = "Guarda el combatlog de Raid 25 jugadores" -- Needs review
L["25 Players Raids"] = "Raids 25 Jugadores"
L["AutoLog Disabled"] = "AutoLog Desativado"
L["Auto turn on/off combat logging based on raid instances"] = "Auto turn on/off combat logging based on raid instances" -- Requires localization
L["Checked if combat logging is currently on"] = "Activado guarda combate actual"
L["Combat logging turned off"] = "Guardar CombatLog desactivado"
L["Combat logging turned on"] = "Guardar CombatLog activado"
L["Enable auto logging"] = "Activar auto Logs"
L["Flex raid instances where you want to log combat"] = "Flex raid instances where you want to log combat" -- Requires localization
L["Flex Raids"] = "Flex Raids" -- Requires localization
L["If unchecked, AutoLog will never enable Combat Logging"] = "Si estamarcado, guadar\195\161 automaticamente todos los LOGs de combate en instaces"
L["LFR Raids"] = "LFR Raids" -- Requires localization
L[" loaded."] = " cargando."
L["Log 5 player challenge mode instances"] = "Log 5 player challenge mode instances" -- Requires localization
L["Log 5 player heroic instances"] = "Log casos heroico 5 jugadores" -- Needs review
L["Logging state"] = "Estado de log"
L["Only log guild runs"] = "Only log guild runs" -- Requires localization
L["Raid finder instances where you want to log combat"] = "Raid finder instances where you want to log combat" -- Requires localization
L["Start/Stop logging"] = "Start/Stop logging" -- Requires localization

