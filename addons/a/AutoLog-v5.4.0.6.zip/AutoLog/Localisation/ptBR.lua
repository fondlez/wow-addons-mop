local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("AutoLog", "ptBR")
if not L then return end

--@localization(locale="prBR", format="lua_additive_table", handle-unlocalized="english", escape-non-ascii=true, table-name="L", same-key-is-true=true)@
