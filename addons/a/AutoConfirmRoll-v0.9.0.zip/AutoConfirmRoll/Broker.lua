local NAME, S = ...
local ACR = AutoConfirmRoll
local ACD = LibStub("AceConfigDialog-3.0")
local L = S.L

	---------------------
	--- LibDataBroker ---
	---------------------

local dataobject = {
	type = "launcher",
	icon = "Interface\\Buttons\\UI-GroupLoot-Dice-Up",
	text = NAME,
	OnClick = function(clickedframe, button)
		if IsModifierKeyDown() then
			ACR:SlashCommand(ACR:IsEnabled() and "0" or "1")
		else
			ACD[ACD.OpenFrames.AutoConfirmRoll_Main and "Close" or "Open"](ACD, "AutoConfirmRoll_Main")
		end
	end,
	OnTooltipShow = function(tt)
		tt:AddLine("|cffADFF2F"..NAME.."|r")
		tt:AddLine(L.BROKER_CLICK)
		tt:AddLine(L.BROKER_SHIFT_CLICK)
	end,
}

LibStub("LibDataBroker-1.1"):NewDataObject(NAME, dataobject)
