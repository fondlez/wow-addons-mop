-------------------------------------------
--- Author: Ketho (EU-Boulderfist)		---
--- License: Public Domain				---
--- Created: 2011.11.21					---
--- Version: 0.9.0 [2013.05.26]			---
-------------------------------------------
--- Curse			http://www.curse.com/addons/wow/autoconfirmroll
--- WoWInterface	http://www.wowinterface.com/downloads/info20516-AutoConfirmRoll.html

local NAME = ...
local VERSION = GetAddOnMetadata(NAME, "Version")

AutoConfirmRoll = LibStub("AceAddon-3.0"):NewAddon(NAME, "AceEvent-3.0", "AceConsole-3.0")
local ACR = AutoConfirmRoll

local ACR2 = LibStub("AceConfigRegistry-3.0")
local ACD = LibStub("AceConfigDialog-3.0")

local profile

	---------------
	--- Options ---
	---------------

local rollTypes = {} -- cache

local remap = {
	Need = 1,
	Greed = 2,
	Disenchant = 3,
}

local ITEM_QUALITY = {}

for i = 2, 4 do
	ITEM_QUALITY[i] = format("%s%s|r", ITEM_QUALITY_COLORS[i].hex, _G["ITEM_QUALITY"..i.."_DESC"])
end

local defaults = {
	profile = {
		Need = true,
		Greed = true,
		Disenchant = true,
		Loot = true,
		Threshold = 4,
		Party = true,
		Raid = true,
	},
}

local options = {
	type = "group",
	name = format("%s |cffADFF2Fv%s|r", NAME, VERSION),
	handler = ACR,
	args = {
		inline1 = {
			type = "group", order = 1,
			name = " ",
			inline = true,
			get = "GetValue", set = "SetValueRoll",
			args = {
				Need = {
					type = "toggle", order = 1,
					width = "full", descStyle = "",
					name = "|TInterface\\Buttons\\UI-GroupLoot-Dice-Up:16:16|t "..NEED,
				},
				Greed = {
					type = "toggle", order = 2,
					width = "full", descStyle = "",
					name = "|TInterface\\Buttons\\UI-GroupLoot-Coin-Up:16:16|t "..GREED,
				},
				Disenchant = {
					type = "toggle", order = 3,
					width = "full", descStyle = "",
					name = "|TInterface\\Buttons\\UI-GroupLoot-DE-Up:16:16|t "..ROLL_DISENCHANT,
				},
				Loot = {
					type = "toggle", order = 4,
					width = "full", desc = "|cff71D5FFAutoConfirmLoot|r\n"..LOOT_NO_DROP,
					name = "|TInterface\\Cursor\\Pickup:16:16:1|t "..LOOT,
					set = "SetValue"
				},
			},
		},
		spacing = {type = "description", order = 2, name = ""},
		inline2 = {
			type = "group", order = 3,
			name = FILTERS,
			inline = true,
			get = "GetValue", set = "SetValue",
			args = {
				Threshold = {
					type = "select", order = 1,
					descStyle = "",
					name = " "..LOOT_THRESHOLD,
					values = ITEM_QUALITY,
				},
				spacing = {type = "description", order = 2, name = " "},
				Party = {
					type = "toggle", order = 3,
					width = "full", descStyle = "",
					name = " |cffA8A8FF"..PARTY.."|r",
				},
				Raid = {
					type = "toggle", order = 4,
					width = "full", descStyle = "",
					name = " |cffFF7F00"..RAID.."|r",
				},
			},
		},
	},
}

function ACR:GetValue(i)
	return profile[i[#i]]
end

function ACR:SetValue(i, v)
	profile[i[#i]] = v
end

function ACR:SetValueRoll(i, v)
	profile[i[#i]] = v
	rollTypes[remap[i[#i]]] = v
end

	---------------------------
	--- Ace3 Initialization ---
	---------------------------

function ACR:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("AutoConfirmRollDB", defaults, true)
	
	self.db.RegisterCallback(self, "OnProfileChanged", "RefreshDB")
	self.db.RegisterCallback(self, "OnProfileCopied", "RefreshDB")
	self.db.RegisterCallback(self, "OnProfileReset", "RefreshDB")
	self:RefreshDB()
	
	self.db.global.version = VERSION
	
	ACR2:RegisterOptionsTable("AutoConfirmRoll_Main", options)
	
	local profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
	ACR2:RegisterOptionsTable("AutoConfirmRoll_Profiles", profiles)
	
	ACD:AddToBlizOptions("AutoConfirmRoll_Main", NAME)
	ACD:AddToBlizOptions("AutoConfirmRoll_Profiles", profiles.name, NAME)
	
	ACD:SetDefaultSize("AutoConfirmRoll_Main", 280, 385)
	
	for _, v in ipairs({"acr", "autoconfirm", "autoconfirmroll"}) do
		self:RegisterChatCommand(v, "SlashCommand")
	end
end

function ACR:OnEnable()
	self:RegisterEvent("CONFIRM_LOOT_ROLL", "CONFIRM_ROLL")
	self:RegisterEvent("CONFIRM_DISENCHANT_ROLL", "CONFIRM_ROLL")
	self:RegisterEvent("LOOT_BIND_CONFIRM")
end

function ACR:RefreshDB()
	profile = self.db.profile

	rollTypes = {
		profile.Need,
		profile.Greed,
		profile.Disenchant,
	}
end

local enable = {
	["1"] = true,
	on = true,
	enable = true,
	load = true,
}

local disable = {
	["0"] = true,
	off = true,
	disable = true,
	unload = true,
}

function ACR:SlashCommand(input)
	if strtrim(input) == "" then
		ACD:Open("AutoConfirmRoll_Main")
	elseif enable[input] then
		self:Enable()
		self:Print("|cffADFF2F"..VIDEO_OPTIONS_ENABLED.."|r")
	elseif disable[input] then
		self:Disable()
		self:Print("|cffFF2424"..VIDEO_OPTIONS_DISABLED.."|r")
	end
end

	--------------------
	--- Confirm Roll ---
	--------------------

local function IsGroup()
	local isRaid = IsInRaid()
	local isParty = IsInGroup()
	
	local raid = profile.Raid and isRaid
	local party = profile.Party and (not isRaid and isParty)
	
	return raid or party
end

function ACR:CONFIRM_ROLL(event, id, lootType)
	local qualityThreshold = select(4, GetLootRollItemInfo(id)) <= profile.Threshold
	if rollTypes[lootType] and qualityThreshold and IsGroup() then
		ConfirmLootRoll(id, lootType)
		-- WisdomWolf: Manually hiding StaticPopup for compatibility with ElvUI (and alike)
		StaticPopup_Hide("CONFIRM_LOOT_ROLL")
	end
end

	--------------------
	--- Confirm Loot ---
	--------------------

-- you can only ConfirmLootSlot() straight after the respective LootSlot()
-- problem is that LOOT_BIND_CONFIRM fires in quick succession, and need to wait at least for a single OnUpdate

local f = CreateFrame("Frame")
local checkList = {}

function f:DelayedConfirm(elapsed)
	for slot in pairs(checkList) do
		LootSlot(slot)
		ConfirmLootSlot(slot)
	end
	wipe(checkList) -- all LOOT_BIND_CONFIRM events should have already fired before the OnUpdate
	StaticPopup_Hide("LOOT_BIND")
	self:SetScript("OnUpdate", nil)
end

function ACR:LOOT_BIND_CONFIRM(event, slot)
	local qualityThreshold = select(4, GetLootSlotInfo(slot)) <= profile.Threshold
	if profile.Loot and qualityThreshold and not checkList[slot] then
		checkList[slot] = true -- don't reprocess the slot when LootSlot is called again
		f:SetScript("OnUpdate", f.DelayedConfirm)
		StaticPopup_Hide("LOOT_BIND") -- in contrary to ConfirmLootRoll, ConfirmLootSlot doesn't include hiding the StaticPopup
	end
end
