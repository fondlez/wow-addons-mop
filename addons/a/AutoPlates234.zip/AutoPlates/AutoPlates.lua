--[[
*************************************************************************
AutoPlates 
v2.34



v1.0 - v1.51 by evil.oz
v2.0+ by Hotrian



Credits:
Original code by evil.oz
used instance names from Metamap Written by MetaHawk - aka Urshuraks
completely miss TBC instance names
*************************************************************************

2.34
---
	getnumparty error fixed
	
2.33
---
	toc bump
	
2.32
---
	toc bump

2.31
---
	toc bump

2.3
---
	usual this self fix for 4.0.1
	need to type "/console bloattest 1" in order to make it work, see http://forums.worldofwarcraft.com/thread.html?topicId=27191405308&pageNo=1&sid=1

2.2
----
	fixed onload error with timer beign null

2.1
----
	Hauled a good 80% of code, reformatted a ton of things

	NamePlates triggered when any unit was in combat, now only triggers for
		player, pet, party, party pet, raid, raid pet, focus, and target

	Added Friendly/Hostile plate switches
	
	Fixed slash commands and value caps
	
	Fixed descriptions
	
	Made the event code streamline, and removed a bunch of useless if then elses
	
2.0
----
	Cleaned up the code a ton, Fixed a bunch of errors

]]--



function AutoPlates_OnLoad(this)
	AutoPlates_inInstance = false;
	AutoPlates_inCombat = false;
	AutoPlates_isVisible = false;
	modeDesc = {
		[1]="Always toggle autoplates",
		[2]="Toggle, but in instances always show nameplates",
		[3]="Toggle, but leave manual control in instances",
		[4]="Always off",
		[5]="Always turn on autoplates",
	};

	this:RegisterEvent("PLAYER_REGEN_DISABLED");
	this:RegisterEvent("PLAYER_REGEN_ENABLED");
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
	this:RegisterEvent("ZONE_CHANGED");
	this:RegisterEvent("ZONE_CHANGED_INDOORS");
	this:RegisterEvent("ZONE_CHANGED_NEW_AREA");
	this:RegisterEvent("UNIT_COMBAT");

	SLASH_APCMD1 = "/ap"; SLASH_APCMD2 = "/autoplates";
	SLASH_APCMDDELAY1 = "/apdelay"; SLASH_APCMDDELAY2 = "/autoplatesdelay";
	
	SlashCmdList["APCMD"] = function(msg) AutoPlates_cmd(msg); end
	SlashCmdList["APCMDDELAY"] = function(msg) AutoPlates_cmddelay(msg); end
end

function AutoPlates_OnUpdate(this)
	if  timer and ( (time() - timer ) > 0) then
		timer = time();
		AutoPlates_Timed();
	end
end

function AutoPlates_Timed()
	if ( timer_hideplates > 0) then
		timer_hideplates = timer_hideplates - 1;
		AutoPlates_Debug( "Hiding plates in " .. tostring( timer_hideplates), 1);
		if ( timer_hideplates == 0) then
			AutoPlates_Debug( "Hiding plates", 1);
			AutoPlates_Hide();		
		end
	end
end

function AutoPlates_HidePlates()
	if ( AutoPlates_mode ~= 5) then
		if ( AutoPlates_delay == 0) then AutoPlates_Hide();	else timer_hideplates = AutoPlates_delay;
			AutoPlates_Debug( "Hiding plates in " .. tostring( timer_hideplates), 1);
		end
	end
end


function AutoPlates_OnEvent(event, ...)
	if (event == "VARIABLES_LOADED") then
		if ( AutoPlates_hostile == nil) then AutoPlates_hostile = true; end
		if ( AutoPlates_friendly == nil) then AutoPlates_friendly = false; end
		if ( AutoPlates_mode == nil) then AutoPlates_mode = 2; end
		if ( AutoPlates_delay == nil) then AutoPlates_delay = 30; end
		timer = time();
		timer_hideplates = 0;
		debug = false;
		AutoPlates_Print( "AutoPlates v2.0 loaded sucessful. Type /ap or /autoplates for options. Current mode is " .. AutoPlates_mode .. " (" .. modeDesc [AutoPlates_mode] .. ") and Current delay is " .. AutoPlates_delay .. " seconds", 0);
	end
	
	if (AutoPlates_mode == 4) then
		AutoPlates_Hide();
		return;
	end

	if ( ( AutoPlates_inInstance and AutoPlates_mode == 2) or AutoPlates_mode == 5) then
		AutoPlates_Debug( "Forcing NamePlates ON", 1);
		AutoPlates_Show();
		return;
	end

	if (event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS" or event == "ZONE_CHANGED_NEW_AREA") then
		if ( AutoPlates_inInstance) then AutoPlates_Debug( "Zone Changed (Instance)", 1); else AutoPlates_Debug( "Zone Changed (Non-instance)", 1); end
		if ( (timer_hideplates == 0 and AutoPlates_inCombat == false) or event == "ZONE_CHANGED_NEW_AREA") then AutoPlates_Hide(); end
	end

	if (event == "PLAYER_ENTERING_WORLD") then
		AutoPlates_inInstance = IsInInstance();
		if ( AutoPlates_inInstance) then AutoPlates_Debug( "Entering World (Instance)", 1); else AutoPlates_Debug( "Entering World (Non-instance)", 1); end
		AutoPlates_Hide();
	end

	if ( event == "PLAYER_REGEN_DISABLED") then
		timer_hideplates = 0;
		AutoPlates_inCombat = true;
		AutoPlates_Debug( "Entering Combat", 1);
		AutoPlates_Show();
	end

	if ( event == "PLAYER_REGEN_ENABLED") then
		AutoPlates_inCombat = false;
		AutoPlates_Debug( "Leaving Combat", 1);
		AutoPlates_HidePlates();	
	end
	
	if (event == "UNIT_COMBAT") then
		if ( AutoPlates_isVisible == true or arg2 == "HEAL" or AutoPlates_mode == 5) then return; end
		
		a = 0;
		if (arg1 == "player" or arg1 == "pet" or arg1 == "target" or arg1 == "focus") then a = 1; end
		if ( GetNumGroupMembers() > 0) then
			if ( a == 0) then for i=1,4 do if ( arg1 == "party" .. i) then a = 2; end end end
			if ( a == 0) then for i=1,4 do if ( arg1 == "partypet" .. i) then a = 3; end end end
		end
		if ( IsInRaid() ) then
			if ( a == 0) then for i=1,40 do if ( arg1 == "raid" .. i) then a = 4; end end end
			if ( a == 0) then for i=1,40 do if ( arg1 == "raidpet" .. i) then a = 5; end end end
		end
		if ( a > 0) then
			AutoPlates_Show();
			timer_hideplates = 0;
			AutoPlates_HidePlates();
		end
	end
end

function AutoPlates_cmd( parm)
	if ( parm == "") then AutoPlates_PrintArray( { "", "usage: /ap <mode> or /autoplates <mode>", "  1 - " .. modeDesc[1], "  2 - " .. modeDesc[2], "  3 - " .. modeDesc[3], "  4 - " .. modeDesc[4], "  5 - " .. modeDesc[5], "  friendly - Toggles friendly plates", "  hostile - Toggles hostile plates", "  (use /apdelay or /autoplatesdelay for setting delay time)", "  current mode is " .. AutoPlates_mode .. " (" .. modeDesc [AutoPlates_mode] ..")" }); return; end
	parm_tostring = tostring( parm); parm_tonumber = tonumber( parm_tostring);
	
	if ( parm_tostring == "debug") then
		if ( debug) then debug = false; else debug = true; end
		AutoPlates_Print( "Debug set to " .. tostring( debug));
		AutoPlates_DebugArray( { "-", "AutoPlates_mode: " .. tostring( AutoPlates_mode), "AutoPlates_delay: " .. tostring( AutoPlates_delay), "timer_hideplates: " .. tostring( timer_hideplates), "timer: " .. tostring( timer) });
		return;
	end
	if ( parm_tostring == "friendly") then
		if ( AutoPlates_friendly) then AutoPlates_friendly = false; else AutoPlates_friendly = true; end
		AutoPlates_Print( "Showing friendly plates = " .. tostring( AutoPlates_friendly));
		AutoPlates_Print( "Current mode" .. tostring( AutoPlates_mode));
		if ( AutoPlates_mode == 5) then AutoPlates_Show(); else AutoPlates_Hide(); end
		return;
	end
	
	if ( parm_tostring == "hostile") then
		if ( AutoPlates_hostile) then AutoPlates_hostile = false; else AutoPlates_hostile = true; end
		AutoPlates_Print( "Showing hostile plates = " .. tostring( AutoPlates_hostile));
		if ( AutoPlates_mode == 5) then AutoPlates_Show(); else AutoPlates_Hide(); end
		return;
	end
	
	if (parm_tonumber >= 1 and parm_tonumber <= 5) then
		AutoPlates_mode = parm_tonumber;
		AutoPlates_Print( "Switched to mode " .. AutoPlates_mode, 1);
		if ( parm_tonumber ~= 5) then AutoPlates_Hide(); else AutoPlates_Show(); end
	else
		AutoPlates_Print( "Values must be between 1 and 5", 1);
	end
	
end

function AutoPlates_cmddelay( parm)
	if ( parm == "") then AutoPlates_Print( " Usage: /apdelay <time> or /autoplatesdelay <delay>, where <delay> is delay (in seconds) to wait for plates to fade off after combat. Current delay is " .. AutoPlates_delay .. " seconds" ); return; end
	parm_tostring = tostring( parm); parm_tonumber = tonumber( parm_tostring);
	
	if ( parm_tonumber >= 1 and parm_tonumber <= 3000) then
		AutoPlates_delay = parm_tonumber;
		AutoPlates_Print( "New delay is "  .. AutoPlates_delay .. " seconds", 0);
	else
		AutoPlates_Print( "Values must be between 1 and 3000", 1);
	end
end

function AutoPlates_Show()
	AutoPlates_isVisible = true;
	if ( AutoPlates_friendly) then SetCVar( "nameplateShowFriends", 1); else SetCVar( "nameplateShowFriends", 0); end
	if ( AutoPlates_hostile) then SetCVar( "nameplateShowEnemies", 1); else SetCVar( "nameplateShowEnemies", 0); end
end

function AutoPlates_Hide()
	AutoPlates_isVisible = false;
	SetCVar( "nameplateShowFriends", 0);
	SetCVar( "nameplateShowEnemies", 0);
end

function AutoPlates_Print( str, val)
	if ( str ~= "-") then
		if ( tonumber( val) == 1) then str = "AutoPlates: " .. str; end
		DEFAULT_CHAT_FRAME:AddMessage(str, 0, 1, 1);
	end
end
function AutoPlates_PrintArray( arr) for k,v in ipairs( arr) do AutoPlates_Print( v, k) end end

function AutoPlates_Debug( str, val)
	if ( debug and str ~= "-") then
		if ( tonumber( val) == 1) then str = "AutoPlates Debug: " .. str; end
		DEFAULT_CHAT_FRAME:AddMessage(str, 0, 1, .7);
	end
end
function AutoPlates_DebugArray( arr) for k,v in ipairs( arr) do AutoPlates_Debug( v, k) end end
function AutoPlates_Message(msg) UIErrorsFrame:AddMessage(msg, 1.0, 0, 0, 1.0, 1); end