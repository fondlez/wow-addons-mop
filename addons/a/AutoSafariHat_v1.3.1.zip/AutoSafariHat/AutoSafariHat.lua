--------------------------------------------
--         Author: Simca@Malfurion        --
-- Special Thanks: durandal42 and yinzara --
--------------------------------------------

-- Set addon name and namespace
local addonname, ASH = ...

-- Localized functions and function returns to reduce run time for OnEvent and OnUpdate triggers
local _G = _G
local tonumber = _G.tonumber
local strlower = _G.string.lower
local strfind = _G.string.find
local sub = _G.strsub
local InCombat = _G.InCombatLockdown
local HasControl = _G.HasFullControl
local UnitIsWildBattlePet = _G.UnitIsWildBattlePet
local UnitExists = _G.UnitExists
local UnitGUID = _G.UnitGUID
local InPetBattle = _G.C_PetBattles.IsInBattle
local GetItemInfo = _G.GetItemInfo
local GetInventoryItemID = _G.GetInventoryItemID
local HelmSlot = _G.GetInventorySlotInfo("HEADSLOT")
local TabardSlot = _G.GetInventorySlotInfo("TABARDSLOT")
local SetAbility = C_PetJournal.SetAbility
local SetPetLoadOutInfo = _G.C_PetJournal.SetPetLoadOutInfo
local GetPetLoadOutInfo = _G.C_PetJournal.GetPetLoadOutInfo
local GetPetInfoByPetID = _G.C_PetJournal.GetPetInfoByPetID
local GetPetInfoBySpeciesID = _G.C_PetJournal.GetPetInfoBySpeciesID
local GetPetAbilityInfo = _G.C_PetJournal.GetPetAbilityInfo

-- Constants
local MAX_UPDATE_ATTEMPTS = 11
local UPDATE_DELAY = 1.0
local SAFARI_HAT = 92738
local HALF_TABARD = 69209
local FULL_TABARD = 69210
local PLACEHOLDER_SPECIES_ID = 5 -- a fake ID used for designating "tamer" battles
local EMPTY_PET = "0x0000000000000000"

-- Variables used to store Hat, Tabard, and Pet Teams
local realHat = false
local realTabard = false
local foundTabard = false
local realSelectedTeam = false
local realPets = {}

-- Other Variables
local attemptType = "N"             -- State Machine variable used to guide hat equip/unequip behavior
local updateAttempts = 0            -- Used to track attempts
local tamerlist = {}                -- List of pet tamers
local PetBattleType = false         -- Variable to check what type of fight it is (needed for TARGET_CHANGED detection pre-battle and post-battle)
local lastGUID = false              -- Used to check after a pet battle whether the target changed during the pet battle
local ASH_Time = UPDATE_DELAY + 1   -- Used to store time for OnUpdate function (starts above max so it will instantly try once)
ASH.LibStub = false                 -- Used to access LibStub; used to check if PetBattleTeams is detected and integration is supported

-- Create event handling frame and register events
local ASH_Events = CreateFrame("FRAME", "AutoSafariHat_Handler")
ASH_Events:RegisterEvent("ADDON_LOADED")
ASH_Events:RegisterEvent("GOSSIP_SHOW")
ASH_Events:RegisterEvent("PET_BATTLE_CLOSE")
ASH_Events:RegisterEvent("PLAYER_CONTROL_LOST")
ASH_Events:RegisterEvent("PLAYER_LOGIN")
ASH_Events:RegisterEvent("PLAYER_REGEN_DISABLED")
ASH_Events:RegisterEvent("PLAYER_REGEN_ENABLED")
ASH_Events:RegisterEvent("PLAYER_TARGET_CHANGED")
ASH_Events:RegisterEvent("QUEST_COMPLETE")
ASH_Events:RegisterEvent("QUEST_DETAIL")
ASH_Events:RegisterEvent("QUEST_PROGRESS")

local function ASH_Output(outputText)
    if AutoSafariHatOptions.DisableText or not outputText then
        return
    end

    print("ASH: " .. outputText)
end

local function ASH_EquipPetBattleTeam(speciesID, rememberTeam)
    if not AutoSafariHatOptions.AutoPetBattleTeams or not ASH.LibStub then
        return
    end

    local TeamManager = ASH.LibStub("AceAddon-3.0"):GetAddon("PetBattleTeams"):GetModule("TeamManager")
    if not TeamManager then
        return
    end

    local name = strlower(UnitName("target"))
    if not name then
        return
    end

    local numTeams = TeamManager:GetNumTeams()
    
    if rememberTeam then
        -- Reset variables in case we don't have a matching team (or it's already selected) so we don't try to swap back some previous team after the battle
        realPets = {}
        realSelectedTeam = false
    end

    for teamIndex = 1, numTeams do

        if TeamManager:TeamExists(teamIndex) then
            local teamName = strlower(TeamManager:GetTeamName(teamIndex))

            if strfind(teamName, name) or teamName == name then

                -- Don't do anything if team was already selected
                if not TeamManager:IsSelected(teamIndex) then

                    if rememberTeam then
                        realSelectedTeam = TeamManager:GetSelected()
                    end

                    if not AutoSafariHatOptions.DisableText then
                        ASH_Output("Equipping team named '" .. TeamManager:GetTeamName(teamIndex) .. "'.")
                    end

                    if rememberTeam then
                        -- Save the current pets and abilities to restore after the battle is over
                        for petIndexInTeam = 1, 3 do
                            local petGUID, ability1, ability2, ability3, locked = GetPetLoadOutInfo(petIndexInTeam)
                            if petGUID and not locked then
                                realPets[petIndexInTeam] = { petGUID = petGUID, ability1 = ability1, ability2 = ability2, ability3 = ability3 }
                                local petName = select(2,GetPetInfoByPetID(petGUID))
                                if not petName then
                                    petName = select(8,GetPetInfoByPetID(petGUID))
                                end
                                -- ASH_Output("Saving pet '" .. petName .. "' in slot " .. petIndexInTeam)

                            else -- There is no pet in this slot or the slot is not yet available (the user doesn't have high enough level pets)
                                realPets[petIndexInTeam] = false
                                -- ASH_Output("Saving no pet to slot " .. petIndexInTeam)
                            end
                        end
                    end

                    TeamManager:SetSelected(teamIndex)
                end

                return
            end
        end
    end

    -- Inform the user only if we know it is an unobtainable species or a tamer fight
    if speciesID and ((speciesID == PLACEHOLDER_SPECIES_ID) or not select(11, GetPetInfoBySpeciesID(speciesID))) then
        ASH_Output("No existing team named '" .. UnitName("target") .. "'.  To auto-select a team, name a team containing the name of the tamer/pet you are fighting.")
    end
end

local function ASH_UnequipPetBattleTeam()
    if not realSelectedTeam or not AutoSafariHatOptions.AutoPetBattleTeams or not ASH.LibStub then
        return
    end

    local TeamManager = ASH.LibStub("AceAddon-3.0"):GetAddon("PetBattleTeams"):GetModule("TeamManager")
    if not TeamManager then
        return
    end

    if TeamManager and not TeamManager:IsSelected(realSelectedTeam) then
        -- Here we are setting the selected team for TeamManager but we don't want to bind the pets, we're going to do that manually
        local prevSelected = TeamManager:GetSelected()
        TeamManager.db.global.selected = realSelectedTeam
        TeamManager.callbacks:Fire("TEAM_UPDATED",prevSelected)
        TeamManager.callbacks:Fire("SELECTED_TEAM_CHANGED",realSelectedTeam)

        ASH_Output("Setting selected team to " .. TeamManager:GetTeamName(realSelectedTeam) .. "'.")
    end

    -- Let's restore the pets and abilities
    for petIndexInTeam = 1, 3 do
        local petGUID, ability1, ability2, ability3, locked = GetPetLoadOutInfo(petIndexInTeam)
        local realPet = realPets[petIndexInTeam]
        if realPet then
            local logMessage = "Pet in slot " .. petIndexInTeam .. " set to "
            local changed = false
            if realPet.petGUID ~= petGUID then
                changed = true
                SetPetLoadOutInfo(petIndexInTeam, realPet.petGUID)
                local petName = select(2,GetPetInfoByPetID(realPet.petGUID)) or select(8,GetPetInfoByPetID(realPet.petGUID))
                logMessage = logMessage .. "\"" ..  petName .. "\" "
            end

            if (realPet.ability1 ~= ability1) then
                changed = true
                SetAbility(petIndexInTeam,1,realPet.ability1)
                logMessage = logMessage .. " 1=" .. (GetPetAbilityInfo(realPet.ability1)) .. " "
            end

            if (realPet.ability2 ~= ability2) then
                changed = true
                SetAbility(petIndexInTeam,2,realPet.ability2)
                logMessage = logMessage .. " 2=" .. (GetPetAbilityInfo(realPet.ability2)) .. " "
            end

            if (realPet.ability3 ~= ability3) then
                changed = true
                SetAbility(petIndexInTeam,3,realPet.ability3)
                logMessage = logMessage .. " 3=" .. (GetPetAbilityInfo(realPet.ability3))
            end

            if changed then
                ASH_Output(logMessage)
            else
                local petName = select(2,GetPetInfoByPetID(realPet.petGUID)) or select(8,GetPetInfoByPetID(realPet.petGUID))
                ASH_Output("Pet '" .. petName .. "' in slot " .. petIndexInTeam .. " was already correct")
            end
        elseif not locked and petGUID and petGUID ~= EMPTY_PET then
            SetPetLoadOutInfo(petIndexInTeam, EMPTY_PET)
            ASH_Output("Removing pet from slot " .. petIndexInTeam)
        else
            ASH_Output("Pet in slot " .. petIndexInTeam .. " is either locked or is already empty")
        end
    end

    if PetJournal_UpdatePetLoadOut then
        PetJournal_UpdatePetLoadOut()
    end

    realSelectedTeam = false
    realPets = {}
end

local function CeaseUpdateAttempts()
    ASH_Events:SetScript("OnUpdate", nil)
    attemptType = "N"
    ASH_Time = UPDATE_DELAY + 1
    updateAttempts = 0
end

-- Delayed equipping/unequipping code
local function ASH_OnUpdate(self, elapsed)
    -- Update elapsed time (occurs every frame)
    ASH_Time = ASH_Time + elapsed

    -- Don't run more than once per UPDATE_DELAY
    if ASH_Time > UPDATE_DELAY then

        -- Stop future tries if too many attempts
        if updateAttempts < MAX_UPDATE_ATTEMPTS then
            local ASHI = AutoSafariHatOptions.Items -- Just for readability and to speed up access slightly

            -- If we're trying to equip
            if attemptType == "E" then

                -- If wearing normal hat
                if (ASHI == 1 or ASHI == 3) and GetInventoryItemID("player", HelmSlot) ~= SAFARI_HAT then
                    realHat = _G.GetInventoryItemLink("player", HelmSlot)

                    _G.EquipItemByName(SAFARI_HAT)
                end

                -- For this to work we must have found a tabard when this OnUpdate event was originally commissioned
                if tabardType and (ASHI == 2 or ASHI == 3) and GetInventoryItemID("player", TabardSlot) ~= tabardType then
                    _G.EquipItemByName(tabardType)
                end

                -- Advanced conditional: if wearing safari hat and 1; if wearing guild tabard and 2; if wearing hat and tabard and 3; if 4
                if (ASHI == 1 and GetInventoryItemID("player", HelmSlot) == SAFARI_HAT) or (ASHI == 2 and (not tabardType or GetInventoryItemID("player", TabardSlot) == tabardType)) or (ASHI == 3 and GetInventoryItemID("player", HelmSlot) == SAFARI_HAT and (not tabardType or GetInventoryItemID("player", TabardSlot) == tabardType)) or (ASHI == 4) then
                    -- Equip was successful
                    CeaseUpdateAttempts()
                end

            -- If we're trying to unequip
            elseif attemptType == "U" then

                -- If wearing safari hat
                if (ASHI == 1 or ASHI == 3) and GetInventoryItemID("player", HelmSlot) == SAFARI_HAT then
                    _G.EquipItemByName(realHat)
                end

                -- If wearing guild tabard
                if (ASHI == 2 or ASHI == 3) and (GetInventoryItemID("player", TabardSlot) == HALF_TABARD or GetInventoryItemID("player", TabardSlot) == FULL_TABARD) then
                    _G.EquipItemByName(realTabard)
                end

                -- Advanced conditional: if not wearing safari hat and 1; if not wearing guild tabard and 2; if not wearing hat and tabard and 3; if 4
                if (ASHI == 1 and GetInventoryItemID("player", HelmSlot) ~= SAFARI_HAT) or (ASHI == 2 and GetInventoryItemID("player", TabardSlot) ~= HALF_TABARD and GetInventoryItemID("player", TabardSlot) ~= FULL_TABARD) or (ASHI == 3 and GetInventoryItemID("player", HelmSlot) ~= SAFARI_HAT and GetInventoryItemID("player", TabardSlot) ~= HALF_TABARD and GetInventoryItemID("player", TabardSlot) ~= FULL_TABARD) or (ASHI == 4) then
                    -- Unequip was successful
                    CeaseUpdateAttempts()
                end
            end
        else
            -- We've tried many times, but have always failed
            CeaseUpdateAttempts()
        end

        -- Increment attempt counter and reset time to 0
        updateAttempts = updateAttempts + 1
        ASH_Time = 0
    end
end

local function ASH_EquipItem()

    -- Equip Safari Hat
    if (AutoSafariHatOptions.Items == 1 or AutoSafariHatOptions.Items == 3) and GetInventoryItemID("player", HelmSlot) ~= SAFARI_HAT then
        realHat = _G.GetInventoryItemLink("player", HelmSlot)

        _G.EquipItemByName(SAFARI_HAT)
    end

    -- Equip Guild Tabard
    if (AutoSafariHatOptions.Items == 2 or AutoSafariHatOptions.Items == 3) and GetInventoryItemID("player", TabardSlot) ~= HALF_TABARD and GetInventoryItemID("player", TabardSlot) ~= FULL_TABARD then
        realTabard = _G.GetInventoryItemLink("player", TabardSlot)

        tabardType = false

        -- Iterate bags to find your best tabard type
        for bag = 0, 4 do
            for slot = 1, _G.GetContainerNumSlots(bag) do
                local itemID = _G.GetContainerItemID(bag, slot)
                if itemID == FULL_TABARD then
                    tabardType = FULL_TABARD
                    break
                elseif itemID == HALF_TABARD then
                    tabardType = HALF_TABARD
                end
            end
        end

        -- Equip tabard
        if tabardType then
            _G.EquipItemByName(tabardType)
        elseif not AutoSafariHatOptions.DisableText then
            -- Inform user they don't have a tabard
            ASH_Output("While you have the option for a guild tabard set, I could not find a guild reputation tabard in your bags. You must have either the Illustrious Guild Tabard or the Renowned Guild Tabard for this option to function correctly.")
        end
    end

    -- Start OnUpdate system to check if equipment is correct and fix if not
    if attemptType == "U" then
        -- Attempt to Equip but use existing OnUpdate run
        attemptType = "E"
    elseif attemptType ~= "E" then
        -- Attempt to Equip and start OnUpdate
        attemptType = "E"
        ASH_Events:SetScript("OnUpdate", ASH_OnUpdate)
    end
end

local function ASH_UnequipItem()
    -- Equip original Hat
    if (AutoSafariHatOptions.Items == 1 or AutoSafariHatOptions.Items == 3) and GetInventoryItemID("player", HelmSlot) == SAFARI_HAT then
        _G.EquipItemByName(realHat)
    end

    -- Equip original Tabard
    if (AutoSafariHatOptions.Items == 2 or AutoSafariHatOptions.Items == 3) and (GetInventoryItemID("player", TabardSlot) == HALF_TABARD or GetInventoryItemID("player", TabardSlot) == FULL_TABARD) then
        _G.EquipItemByName(realTabard)
    end

    -- Start OnUpdate system to check if equipment is correct and fix if not)
    if attemptType == "E" then
        -- Attempt to Unequip but use existing OnUpdate run
        attemptType = "U"
    elseif attemptType ~= "U" then
        -- Attempt to Unequip and start OnUpdate
        attemptType = "U"
        ASH_Events:SetScript("OnUpdate", ASH_OnUpdate)
    end

    -- Check if config option changed and erase tabard/hat if needed
    if AutoSafariHatOptions.Items ~= 1 and AutoSafariHatOptions.Items ~= 3 then
        realHat = false
    end
    if AutoSafariHatOptions.Items ~= 2 and AutoSafariHatOptions.Items ~= 3 then
        realTabard = false
    end
end

local function ASH_OnEvent(self, event, ...)
    if event == "ADDON_LOADED" and ... == addonname then
        -- Set options to defaults if not already found
        if not AutoSafariHatOptions then
            AutoSafariHatOptions = {}
            AutoSafariHatOptions.Items = 1
            AutoSafariHatOptions.WildPetHat = true
            AutoSafariHatOptions.TamerPetHat = true
            AutoSafariHatOptions.AutoQuestAccept = true
            AutoSafariHatOptions.AutoQuestComplete = true
            AutoSafariHatOptions.AttemptCombatFix = true
            AutoSafariHatOptions.AutoPetBattleTeams = true
            AutoSafariHatOptions.DisableText = false
        end

        -- Set new option to defaults if not already found
        if not AutoSafariHatOptions.Items then
            AutoSafariHatOptions.Items = 1
        end

        -- Set option to see when user last changed options
        if AutoSafariHatOptions.ManualChange == nil then
            AutoSafariHatOptions.ManualChange = false
        end

        -- Unregister event since no further need to check addon loading
        ASH_Events:UnregisterEvent("ADDON_LOADED")

    elseif event == "PLAYER_LOGIN" then
        -- Set up conditions for possible later integration with PetBattleTeams
        local _, _, _, enabled, loadable = _G.GetAddOnInfo("PetBattleTeams")

        if (enabled or loadable) and _G["LibStub"] then
            -- Since we only need LibStub to integrate with other addons that already use LibStub,
            -- We can rely on LibStub existing and hook into it without including it in this addon.
            ASH.LibStub = _G["LibStub"]
        end

    -- WildPetHat event and unequipping on target change for all events
    elseif event == "PLAYER_TARGET_CHANGED" then
        if InPetBattle() or InCombat() or not HasControl() or PetBattleType == "tamer" then
            return
        end

        if UnitIsWildBattlePet("target") and AutoSafariHatOptions.WildPetHat then
            PetBattleType = "wild"
            ASH_EquipPetBattleTeam(UnitBattlePetSpeciesID("target"), true)
            ASH_EquipItem()
        elseif PetBattleType or attemptType == "E" then
            PetBattleType = false
            ASH_UnequipPetBattleTeam()
            ASH_UnequipItem()
        end

    -- TamerPetHat, AutoQuestAccept, and AutoQuestComplete events
    elseif event == "GOSSIP_SHOW" or event == "QUEST_DETAIL" or event == "QUEST_PROGRESS" or event == "QUEST_COMPLETE" then
        if _G.IsShiftKeyDown() then
            return
        end

        local unitType = nil

        if UnitExists("npc") then -- (Fixes edge case)
            local tamerID = tonumber(UnitGUID("npc"):sub(6, 10), 16)

            if tamerlist[tamerID] then
                unitType = "tamer" -- IMPROVE SOON FOR DYNAMIC, TOOLTIP-BASED TAMER/TRAINER DETECTION, COMPLETE WITH BACKUP LIST IF TOOLTIPS FAIL/TAKE TOO MUCH TIME
            end
        elseif UnitExists("target") then
            local tamerID = tonumber(UnitGUID("target"):sub(6, 10), 16)

            if tamerlist[tamerID] then
                unitType = "tamer" -- IMPROVE SOON FOR DYNAMIC, TOOLTIP-BASED TAMER/TRAINER DETECTION, COMPLETE WITH BACKUP LIST IF TOOLTIPS FAIL/TAKE TOO MUCH TIME
            end
        end

        if unitType then
            -- Cease any unequip attempts now (fixes edge case)
            if attemptType == "U" then
                CeaseUpdateAttempts()
            end

            if event == "GOSSIP_SHOW" then
                -- Check if any quests are completable
                local questindex
                if AutoSafariHatOptions.AutoQuestComplete and _G.GetGossipActiveQuests() then
                    -- Check if any quests are completable
                    local questcomp
                    for i = 1, _G.GetNumGossipActiveQuests() do
                        questcomp = select(4 + ((i - 1) * 5), _G.GetGossipActiveQuests())
                        if questcomp then
                            questcompleted = true
                            questindex = i
                            break
                        end
                    end
                end

                -- First check available quests, then check if there are active quests AND we know it is completed (questindex), then lastly auto-battle
                if AutoSafariHatOptions.AutoQuestAccept and _G.GetGossipAvailableQuests() then
                    _G.SelectGossipAvailableQuest(1)
                    _G.CloseGossip()
                elseif AutoSafariHatOptions.AutoQuestAccept and _G.GetGossipActiveQuests() and questindex then
                    _G.SelectGossipActiveQuest(questindex)
                    _G.CloseGossip()
                elseif AutoSafariHatOptions.TamerPetHat and GetGossipOptions() then
                    if HasControl() and not InCombat() and not InPetBattle() and unitType == "tamer" then
                        -- Determine gossip battle option
                        local gossipOptions = { _G.GetGossipOptions() }
                        local battleOption
                        for i = #gossipOptions, 1, -1 do
                            if gossipOptions[i] and gossipOptions[i] ~= "gossip" then
                                battleOption = i
                                break
                            end
                        end

                        -- Select gossip battle option, equip items, start battle see improvement #3), set battle type, close gossip window
                        if battleOption then
                            _G.SelectGossipOption(1)
                            PetBattleType = "tamer"
                            ASH_EquipPetBattleTeam(PLACEHOLDER_SPECIES_ID, true)
                            ASH_EquipItem()
                            StaticPopup1Button1:Click()
                            _G.CloseGossip()
                        end
                    end
                end
            elseif AutoSafariHatOptions.AutoQuestAccept and event == "QUEST_DETAIL" then
                _G.AcceptQuest()
                _G.CloseGossip()
            elseif AutoSafariHatOptions.AutoQuestComplete and event == "QUEST_PROGRESS" and _G.IsQuestCompletable() then
                _G.CompleteQuest()
                _G.CloseGossip()
            elseif AutoSafariHatOptions.AutoQuestComplete and event == "QUEST_COMPLETE" and _G.GetNumQuestChoices() < 2 then
                _G.GetQuestReward(_G.GetNumQuestChoices())
                _G.CloseGossip()
            end
        end

    -- Unequipping on pet battle end for all events
    elseif event == "PET_BATTLE_CLOSE" then
        if HasControl() and not InCombat() then
            if UnitIsWildBattlePet("target") and AutoSafariHatOptions.WildPetHat then
                PetBattleType = "wild"
                ASH_EquipPetBattleTeam(UnitBattlePetSpeciesID("target"), false)
                ASH_EquipItem()
            else
                PetBattleType = false
                ASH_UnequipPetBattleTeam()
                ASH_UnequipItem()
            end
        end

    -- Abandon attempts to equip or unequip if we enter combat
    elseif (event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_CONTROL_LOST") and attemptType ~= "N" then
        CeaseUpdateAttempts()

    -- Restart attempts to equip or unequip after leaving combat
    elseif AutoSafariHatOptions.AttemptCombatFix and event == "PLAYER_REGEN_ENABLED" then
        if HasControl() and not InCombat() and not InPetBattle() then
            if UnitIsWildBattlePet("target") and AutoSafariHatOptions.WildPetHat then
                PetBattleType = "wild"
                ASH_EquipPetBattleTeam(UnitBattlePetSpeciesID("target"), true)
                ASH_EquipItem()
            else
                PetBattleType = false
                ASH_UnequipPetBattleTeam()
                ASH_UnequipItem()
            end
        end
    end
end

-- Set our event handler function
ASH_Events:SetScript("OnEvent", ASH_OnEvent)

-- Create slash commands
SLASH_AUTOSAFARIHAT1 = "/autosafarihat"
SLASH_AUTOSAFARIHAT2 = "/ash"
SlashCmdList["AUTOSAFARIHAT"] = function(message)

    if string.lower(message) == "dismiss" then
        AutoSafariHatOptions.DisableText = true
    else
        InterfaceOptionsFrame:Show()
        InterfaceOptionsFrameTab2:Click()

        local i = 1
        local currAddon = "InterfaceOptionsFrameAddOnsButton" .. i
        while _G[currAddon] do
            if _G[currAddon]:GetText() == "Auto Safari Hat" then
                _G[currAddon]:Click()
                break
            end
            i = i + 1
            currAddon = "InterfaceOptionsFrameAddOnsButton" .. i
        end
    end
end

-- Array of tamer NPC IDs defined down here for readability's sake
tamerlist[63194] = true
tamerlist[64330] = true
tamerlist[65648] = true
tamerlist[65651] = true
tamerlist[65655] = true
tamerlist[65656] = true
tamerlist[66126] = true
tamerlist[66135] = true
tamerlist[66136] = true
tamerlist[66137] = true
tamerlist[66352] = true
tamerlist[66372] = true
tamerlist[66412] = true
tamerlist[66422] = true
tamerlist[66436] = true
tamerlist[66442] = true
tamerlist[66452] = true
tamerlist[66466] = true
tamerlist[66478] = true
tamerlist[66512] = true
tamerlist[66515] = true
tamerlist[66518] = true
tamerlist[66520] = true
tamerlist[66522] = true
tamerlist[66550] = true
tamerlist[66551] = true
tamerlist[66552] = true
tamerlist[66553] = true
tamerlist[66557] = true
tamerlist[66635] = true
tamerlist[66636] = true
tamerlist[66638] = true
tamerlist[66639] = true
tamerlist[66675] = true
tamerlist[66730] = true
tamerlist[66733] = true
tamerlist[66734] = true
tamerlist[66738] = true
tamerlist[66739] = true
tamerlist[66741] = true
tamerlist[66815] = true
tamerlist[66819] = true
tamerlist[66822] = true
tamerlist[66824] = true
tamerlist[66918] = true
tamerlist[67370] = true
tamerlist[68462] = true
tamerlist[68463] = true
tamerlist[68464] = true
tamerlist[68465] = true
tamerlist[71924] = true
tamerlist[71926] = true
tamerlist[71927] = true
tamerlist[71929] = true
tamerlist[71930] = true
tamerlist[71931] = true
tamerlist[71932] = true
tamerlist[71933] = true
tamerlist[71934] = true
tamerlist[73626] = true
