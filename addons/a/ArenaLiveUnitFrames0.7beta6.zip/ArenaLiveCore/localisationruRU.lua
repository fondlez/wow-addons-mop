local _, L = ...;

if ( GetLocale() == "ruRU" ) then
	L["FONTSTYLE"] = [[Fonts\FRIZQT___CYR.TTF]];
end