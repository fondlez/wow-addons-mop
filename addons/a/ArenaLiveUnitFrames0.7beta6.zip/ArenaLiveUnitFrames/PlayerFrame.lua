local addonName = ...;


function ALUF_PlayerFrame:Initialise()
		
		
	local prefix = self:GetName();
	local frameType = "PlayerFrame";
	local onRightClick = "togglemenu";
	local healthBar = _G[prefix.."HealthBar"];
	local powerBar = _G[prefix.."PowerBar"];
	local portrait = _G[prefix.."Portrait"];
	local name = _G[prefix.."Name"];
	local levelText = _G[prefix.."LevelText"];
	local icon1 = _G[prefix.."Icon1"];
	local icon2 = _G[prefix.."Icon2"];
	local ccIndicator = _G[prefix.."PortraitOverlay"];
	local scale = ArenaLiveCore:GetDBEntry(addonName, "PlayerFrame/Scale"); 
	scale = scale / 100; 
		
	self:SetScale(scale);
		
	ArenaLiveCore:AddFrame(self, "UnitFrame", addonName, frameType, onRightClick, false);
	ArenaLiveCore:AddFrame(healthBar, "HealthBar", self, true);
	ArenaLiveCore:AddFrame (_G[prefix.."HealthBarText"], "StatusBarText", "HealthBarText", "DEAD_OR_GHOST", nil, true, self)
	ArenaLiveCore:AddFrame(powerBar, "PowerBar", self, true);
	ArenaLiveCore:AddFrame (_G[prefix.."PowerBarText"], "StatusBarText", "PowerBarText", nil, true, nil, self)
	ArenaLiveCore:AddFrame(portrait, "Portrait", _G[prefix.."PortraitTexture"], _G[prefix.."Portrait3D"], self);
	ArenaLiveCore:AddFrame(name, "NameText", self);
	ArenaLiveCore:AddFrame(levelText, "LevelText", nil, "(%s)", self);
	ArenaLiveCore:AddFrame(icon1, "Icon", _G[prefix.."Icon1Texture"], _G[prefix.."Icon1Cooldown"], _G[prefix.."Icon1CooldownText"], self);
	ArenaLiveCore:AddFrame(icon2, "Icon", _G[prefix.."Icon2Texture"], _G[prefix.."Icon2Cooldown"], _G[prefix.."Icon2CooldownText"], self);
	ArenaLiveCore:AddFrame(ccIndicator, "CCIndicator", _G[prefix.."PortraitOverlayIcon"], _G[prefix.."PortraitOverlayCooldown"], _G[prefix.."PortraitOverlayCooldownText"], self);
	ArenaLiveCore:AddFrame(_G[prefix.."CastBar"], "CastBar", _G[prefix.."CastBarBorder"], _G[prefix.."CastBarBorderShieldGlow"], _G[prefix.."CastBarIcon"], _G[prefix.."CastBarText"], _G[prefix.."CastBarAnimationGroup"], _G[prefix.."CastBarAnimationGroupFadeOutAnimation"], true, true, self);
	ArenaLiveCore:AddFrame(_G[prefix.."CastHistory"], "CastHistory", "ArenaLive_CastHistoryIconTemplate", self);
	ArenaLiveCore:AddFrame (_G[prefix.."AuraFrame"], "Aura", _G[prefix.."AuraFrameBuffFrame"], _G[prefix.."AuraFrameDebuffFrame"], "ArenaLive_BuffTemplate", "ArenaLive_DebuffTemplate", self);
	ArenaLiveCore:AddFrame(_G[prefix.."PVPIcon"], "PvPIcon", 24, 24, "HORIZONTAL", self);
	ArenaLiveCore:AddFrame(_G[prefix.."LeaderIcon"], "LeaderIcon", 16, 16, "HORIZONTAL", self);
	ArenaLiveCore:AddFrame(_G[prefix.."MasterLooterIcon"], "MasterLooterIcon", 16, 16, "HORIZONTAL", self);
	ArenaLiveCore:AddFrame(_G[prefix.."RoleIcon"], "RoleIcon", 16, 16, "HORIZONTAL", self);
	ArenaLiveCore:AddFrame(_G[prefix.."StatusIcon"], "StatusIcon", 18, 18, "HORIZONTAL", self);
	ArenaLiveCore:AddFrame(_G[prefix.."SpeakerFrame"], "VoiceChat", _G[prefix.."SpeakerFrameOn"], _G[prefix.."SpeakerFrameFlash"], _G[prefix.."SpeakerFrameMuted"], self);
	ArenaLiveCore:AddFrame(_G[prefix.."MultiGroupFrame"], "MultiGroupIcon", _G[prefix.."MultiGroupFrameHomePartyIcon"], _G[prefix.."MultiGroupFrameInstancePartyIcon"], self);
	ArenaLiveCore:AddFrame(_G[prefix.."ReadyCheck"], "ReadyCheck", self);
	ArenaLiveCore:AddFrame(_G[prefix.."AbsorbBar"], "AbsorbBar", _G[prefix.."AbsorbBarOverlay"], 32, _G[prefix.."AbsorbBarFullHPIndicator"], self);
	ArenaLiveCore:AddFrame(_G[prefix.."HealPredictionBar"], "HealPredictionBar", self);
	ArenaLiveCore:AddFrame(_G[prefix.."Mover"], "FrameMover", _G[prefix.."MoverText"], self);
end

function ALUF_PlayerFrame:Toggle()
	local enabled = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", self.frameType.."/Enabled");
	
	if ( enabled ) then
		if ( not self.unit ) then
			self:SetUnit("player");
		end
	else
		self:ResetUnit();
	end

end

function ALUF_PlayerFrame:OnEvent(event, ...)
	local unit = ...;
	if ( event == "PLAYER_SPECIALIZATION_CHANGED" and unit == "player" and IsAddOnLoaded(addonName) ) then
		ALUF_PlayerFrame:UpdateAttachements();
	end
end

local ownAltPowerBars = false;
function ALUF_PlayerFrame:UpdateAttachements()
	
	local enabled = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/Enabled");
	local castBarEnabled = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/CastBar/Enabled");
	local castBarPosition = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/CastBar/Position");
	local castHistoryEnabled = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/CastHistory/Position");
	local auraFrameEnabled = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/AuraFrame/Enabled");
	local auraFramePosition = ArenaLiveCore:GetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/AuraFrame/Position");
	local altPowerBar;
	local altPowerBaryOffset = 0;
	
	local _, class = UnitClass("player");	
	if ( class == "WARLOCK" ) then
		altPowerBar = WarlockPowerFrame:IsShown();
	elseif ( class == "SHAMAN" ) then
		altPowerBar = true;
	elseif ( class == "DRUID" ) then
			altPowerBar = EclipseBarFrame:IsShown();
		if ( GetSpecialization() == 4 ) then
			altPowerBar = true;
		end
	elseif ( class == "PALADIN" ) then
		altPowerBar = PaladinPowerBar:IsShown();
	elseif ( class == "DEATHKNIGHT" ) then
		altPowerBar = RuneFrame:IsShown();
	elseif ( class == "PRIEST" ) then
		altPowerBar = PriestBarFrame:IsShown();
	elseif ( class == "MONK" ) then
		altPowerBar = MonkHarmonyBar:IsShown();
	end

	if ( not ownAltPowerBars and enabled ) then
		ALUF_PlayerFrame:GetAltPowerBars();
	end
	
	if ( altPowerBar ) then
		if ( class == "PALADIN" ) then
			altPowerBaryOffset = -37; -- HolyPower is pretty large
		else
			altPowerBaryOffset = -27;
		end
	end
	-- Reset all points
	self.castBar:ClearAllPoints();
	self.castHistory:ClearAllPoints();
	self.auraFrame:ClearAllPoints();
	
	-- Set new castbar position
	if ( castBarPosition == auraFramePosition ) then
		if ( castBarPosition == "BELOW" ) then
			self.castBar:SetPoint("TOPLEFT", self.auraFrame, "BOTTOMLEFT", 21, -3)
		elseif ( castBarPosition == "ABOVE" ) then
			self.castBar:SetPoint("BOTTOMLEFT", self.auraFrame, "TOPLEFT", 21, 3)
		end
	else
		if ( castBarPosition == "BELOW" ) then
			self.castBar:SetPoint("TOPRIGHT", self, "BOTTOMRIGHT", -10, altPowerBaryOffset-3)
		elseif ( castBarPosition == "ABOVE" ) then
			self.castBar:SetPoint("BOTTOMRIGHT", self, "TOPRIGHT", -10, 3)
		end	
	end
	
	-- Set new casthistory position
	if ( castBarPosition == "BELOW" ) then
		self.castHistory:SetPoint("TOPLEFT", self.castBar.border, "BOTTOMLEFT", 0, -2);
	elseif ( castBarPosition == "ABOVE" ) then
		self.castHistory:SetPoint("BOTTOMLEFT", self.castBar.border, "TOPLEFT", 0, 2);
	end	
	
	-- Set new auraframe position
	if ( auraFramePosition == "BELOW" ) then
		self.auraFrame:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 33, altPowerBaryOffset+3);
		ArenaLiveCore:SetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/AuraFrame/GrowUpwards", false);
	elseif ( auraFramePosition == "ABOVE" ) then
		self.auraFrame:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 33, 2);
		ArenaLiveCore:SetDBEntry("ArenaLiveUnitFrames", "PlayerFrame/AuraFrame/GrowUpwards", true);
	end	
	
end

local function UpdateTotemFramePosition()
	local _, class = UnitClass("player");
	if ( class == "DRUID" ) then
		-- Resto Druid Mushroom Display
		TotemFrame:ClearAllPoints();
		TotemFrame:SetPoint("TOPRIGHT", ALUF_PlayerFrame, "BOTTOMRIGHT", 25, 15 );
	end
end

function ALUF_PlayerFrame:GetAltPowerBars()
	
	-- Use the Blizzard AltPowerBars and attach them to our PlayerFrame.
	local _, class = UnitClass("player");	
	if ( class == "WARLOCK" ) then
		WarlockPowerFrame:SetParent(ALUF_PlayerFrame);
		WarlockPowerFrame:ClearAllPoints();
		WarlockPowerFrame:SetPoint("TOP", ALUF_PlayerFrame, "BOTTOM", 0, 9 );
	elseif ( class == "SHAMAN" ) then
		TotemFrame:SetParent(ALUF_PlayerFrame);
		TotemFrame:ClearAllPoints();
		TotemFrame:SetPoint("TOP", ALUF_PlayerFrame, "BOTTOM", 0, 9 );
	elseif ( class == "DRUID" ) then
		EclipseBarFrame:SetParent(ALUF_PlayerFrame);
		EclipseBarFrame:ClearAllPoints();
		EclipseBarFrame:SetPoint("TOPLEFT", ALUF_PlayerFrame, "BOTTOMLEFT", 0, 12 );
		-- Resto Druid Mushroom Display
		TotemFrame:SetParent(ALUF_PlayerFrame);
		TotemFrame:ClearAllPoints();
		TotemFrame:SetPoint("TOPRIGHT", ALUF_PlayerFrame, "BOTTOMRIGHT", 25, 15 );
		hooksecurefunc("TotemFrame_Update", UpdateTotemFramePosition);
	elseif ( class == "PALADIN" ) then
		PaladinPowerBar:SetParent(ALUF_PlayerFrame);
		PaladinPowerBar:ClearAllPoints();
		PaladinPowerBar:SetPoint("TOP", ALUF_PlayerFrame, "BOTTOM", 0, 9 );
	elseif ( class == "DEATHKNIGHT" ) then
		RuneFrame:SetParent(ALUF_PlayerFrame);
		RuneFrame:ClearAllPoints();
		RuneFrame:SetPoint("TOP", ALUF_PlayerFrame, "BOTTOM", 0, 2 );
	elseif ( class == "PRIEST" ) then
		PriestBarFrame:SetParent(ALUF_PlayerFrame);
		PriestBarFrame:ClearAllPoints();
		PriestBarFrame:SetPoint("TOP", ALUF_PlayerFrame, "BOTTOM", 50, 9 );
	elseif ( class == "MONK" ) then
		MonkHarmonyBar:SetParent(ALUF_PlayerFrame);
		MonkHarmonyBar:ClearAllPoints();
		MonkHarmonyBar:SetPoint("TOPRIGHT", ALUF_PlayerFrame, "BOTTOMRIGHT", -70, 25 );
	end
	
	ownAltPowerBars = true;

end

ALUF_PlayerFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED");
ALUF_PlayerFrame:SetScript("OnEvent", ALUF_PlayerFrame.OnEvent);