local addonName,adapt = ...
local settings

local opt = CreateFrame("Frame","AdaptOptions",InterfaceOptionsFramePanelContainer)

-- todo: replace this with xml
local template = {
	[1] = {"label",GetAddOnMetadata(addonName,"Title"),"GameFontNormalLarge","TOPLEFT",0,"TOPLEFT",16,-16},
	[2] = {"label","version "..GetAddOnMetadata(addonName,"Version"),"GameFontNormalSmall","BOTTOMLEFT",1,"BOTTOMRIGHT",4,0},
	[3] = {"label","This addon animates the unit frames of (nearly) any UI.","GameFontHighlightSmall","TOPLEFT",1,"BOTTOMLEFT",0,-8},
	[4] = {"label","These options affect how portraits are displayed:","GameFontNormal","TOPLEFT",3,"BOTTOMLEFT",0,-24},
	[5] = {"check","Square","Square portraits","TOPLEFT",4,"BOTTOMLEFT",8,-12},
	[6] = {"radio","HeadModel","Head portrait","TOPLEFT",0,"TOP",-64,-110,1},
	[7] = {"label","Background color","GameFontHighlight","TOPLEFT",5,"BOTTOMLEFT",24,-11},
	[8] = {"label","or","GameFontHighlight","TOPLEFT",7,"BOTTOMLEFT",12,-4},
	[9] = {"check","ColorByClass","Color background by class","TOPLEFT",5,"BOTTOMLEFT",0,-36},
	[10]= {"label","These options allow you to turn off the animation of some portraits:","GameFontNormal","TOPLEFT",9,"BOTTOMLEFT",-8,-32},
	[11]= {"label","Some addons do not name their potraits. Put an \124TInterface\\RAIDFRAME\\ReadyCheck-NotReady:16\124t here to not animate them:","GameFontNormalSmall","TOPLEFT",10,"BOTTOMLEFT",8,-16},
	[12]= {"check","BlacklistAnonymous","Anonymous portraits","TOPLEFT",11,"BOTTOMLEFT",14,-4},
	[13]= {"label","To prevent a named portrait from animating, put an \124TInterface\\RAIDFRAME\\ReadyCheck-NotReady:16\124t beside its name:","GameFontNormalSmall","TOPLEFT",11,"BOTTOMLEFT",-0,-36},
	[14]= {"color","BackColor",16,16,"RIGHT",7,"LEFT",-4,0},
	[15]= {"image","Interface\\AddOns\\Adapt\\CircleBorder","OVERLAY",112,112,"TOPRIGHT",0,"TOPRIGHT",-80,-80},
	[16]= {"radio","TorsoModel","Torso portrait","TOPLEFT",6,"BOTTOMLEFT",0,-4,2},
	[17]= {"radio","FullModel","Full model","TOPLEFT",16,"BOTTOMLEFT",0,-4,3},
}

function adapt:InitializeOptions(savedvar,defaultvar)
	settings = AdaptSettings
	opt:Hide()
	opt.name = addonName
	opt.widgets = {} -- indexed by template number, the checkboxes, labels, etc themselves
	opt.portraitList = {} -- list of named portraits for blacklist candidates
	opt:BuildUI()
	InterfaceOptions_AddCategory(opt)
end

function opt:refresh()
	local widget
	for k,v in pairs(template) do
		widget = opt.widgets[k]
		if v[1]=="check" then
			widget:SetChecked(settings[v[2]])
		elseif v[1]=="color" then
			local color = settings.BackColor
			widget.color:SetVertexColor(color.r,color.g,color.b,color.a)
		end
	end
	opt:RefreshRadios()
	SetPortraitTexture(AdaptOptionsPortrait,"player")
	opt:ShapeOptionsPortraitBorder()

	-- rebuild blacklist in case any new portraits seen
	wipe(opt.portraitList)
	for texture,portrait in pairs(adapt.portraits) do
		local name = texture:GetName()
		if name and portrait.cx>28 and texture~=AdaptOptionsPortrait then
			table.insert(opt.portraitList,name)
		end
	end
	for name in pairs(settings.Blacklist) do
		if not tContains(opt.portraitList,name) then
			table.insert(opt.portraitList,name)
		end
	end
	table.sort(opt.portraitList)
	opt:BlacklistScrollFrameUpdate()
end

--[[ Widget builders ]]

function opt:CreateText(text,font,anchorPoint,relativeTo,relativePoint,xoff,yoff)
	local fontstring = opt:CreateFontString(nil,"BACKGROUND",font)
	relativeTo = relativeTo==0 and opt or opt.widgets[relativeTo]
	fontstring:SetPoint(anchorPoint,relativeTo,relativePoint,xoff,yoff)
	fontstring:SetJustifyH("LEFT")
	fontstring:SetText(text)
	return fontstring
end

function opt:CreateCheck(variable,text,anchorPoint,relativeTo,relativePoint,xoff,yoff)
	local check = CreateFrame("CheckButton",nil,opt,"UICheckButtonTemplate")
	relativeTo = relativeTo==0 and opt or opt.widgets[relativeTo]
	check.variable = variable
	check:SetSize(26,26)
	check:SetPoint(anchorPoint,relativeTo,relativePoint,xoff,yoff)
	check.text:SetFontObject("GameFontHighlight")
	check.text:SetText(text)
	check:SetScript("OnClick",opt[variable.."OnClick"])
	return check
end

function opt:CreateRadio(variable,text,anchorPoint,relativeTo,relativePoint,xoff,yoff,id)
	local radio = CreateFrame("CheckButton",nil,opt,"UIRadioButtonTemplate")
	relativeTo = relativeTo==0 and opt or opt.widgets[relativeTo]
	radio.variable = variable
	radio:SetSize(18,18)
	radio:SetPoint(anchorPoint,relativeTo,relativePoint,xoff,yoff)
	radio.text:SetFontObject("GameFontHighlight")
	radio.text:SetText(text)
	radio:SetScript("OnClick",opt.ModelRadioOnClick)
	radio:SetID(id)
	return radio
end

function opt:CreateColorSwatch(ctable,cx,cy,anchorPoint,relativeTo,relativePoint,xoff,yoff)
	local swatch = CreateFrame("Button",nil,opt)
	relativeTo = relativeTo==0 and opt or opt.widgets[relativeTo]
	swatch:SetSize(cx,cy)
	swatch:SetPoint(anchorPoint,relativeTo,relativePoint,xoff,yoff)
	swatch.bg = swatch:CreateTexture(nil,"BACKGROUND")
	swatch.bg:SetAllPoints(true)
	swatch.bg:SetTexture("Interface\\ChatFrame\\ChatFrameBackground")
	swatch.bg:SetVertexColor(.65,.65,.65)
	swatch.mid = swatch:CreateTexture(nil,"BORDER")
	swatch.mid:SetAllPoints(true)
	swatch.mid:SetTexture("Interface\\FriendsFrame\\Battlenet-WoWicon")
	swatch.color = swatch:CreateTexture(nil,"ARTWORK")
	swatch.color:SetPoint("TOPLEFT",swatch,"TOPLEFT",-1,1)
	swatch.color:SetPoint("BOTTOMRIGHT",swatch,"BOTTOMRIGHT",1,-1)
	swatch.color:SetTexture("Interface\\ChatFrame\\ChatFrameColorSwatch")
	swatch:SetScript("OnEnter",function(self) self.bg:SetVertexColor(1,.82,0) end)
	swatch:SetScript("OnLeave",function(self) self.bg:SetVertexColor(.65,.65,.65) end)
	swatch:SetScript("OnClick",opt[ctable.."OnClick"])
	return swatch
end

function opt:CreateImage(texture,layer,cx,cy,anchorPoint,relativeTo,relativePoint,xoff,yoff)
	local image = opt:CreateTexture(nil,layer)
	relativeTo = relativeTo==0 and opt or opt.widgets[relativeTo]
	image:SetSize(cx,cy)
	image:SetPoint(anchorPoint,relativeTo,relativePoint,xoff,yoff)
	image:SetTexture(texture)
	return image
end

function opt:BuildUI()
	for i=1,#template do
		local widgetType = template[i][1]
		if widgetType=="label" then
			self.widgets[i] = self:CreateText(select(2,unpack(template[i])))
		elseif widgetType=="check" then
			self.widgets[i] = self:CreateCheck(select(2,unpack(template[i])))
		elseif widgetType=="radio" then
			self.widgets[i] = self:CreateRadio(select(2,unpack(template[i])))
		elseif widgetType=="color" then
			self.widgets[i] = self:CreateColorSwatch(select(2,unpack(template[i])))
		elseif widgetType=="image" then
			self.widgets[i] = self:CreateImage(select(2,unpack(template[i])))
		end
		self.widgets[i].id = i
	end

	local portrait = opt:CreateTexture("AdaptOptionsPortrait","ARTWORK")
	portrait:SetPoint("TOPLEFT",self.widgets[15],"TOPLEFT",5,-5)
	portrait:SetPoint("BOTTOMRIGHT",self.widgets[15],"BOTTOMRIGHT",-5,5)

	self.widgets[12]:SetCheckedTexture("Interface\\RAIDFRAME\\ReadyCheck-NotReady")

	opt:CreateBlacklist()
end

--[[ OnClicks ]]

function opt:SquareOnClick()
	settings.Square = self:GetChecked()
	opt:ShapeOptionsPortraitBorder()
	adapt.ShapeAllModels()
end

function opt:ShapeOptionsPortraitBorder()
	opt.widgets[15]:SetTexture(settings.Square and "Interface\\AddOns\\Adapt\\SquareBorder" or "Interface\\AddOns\\Adapt\\CircleBorder")
end

function opt:FullModelOnClick()
	settings.FullModel = self:GetChecked()
	adapt.SetAllCameras()
end

function opt:ColorByClassOnClick()
	settings.ColorByClass = self:GetChecked()
	adapt.ColorAllBackLayers()
end

function opt:BlacklistAnonymousOnClick()
	settings.BlacklistAnonymous = self:GetChecked()
end

-- not actually a click; sometimes an option wants to check/uncheck another option
function opt:SetCheckedByName(name,checked)
	for i=1,#template do
		if template[i][2]==name then
			opt.widgets[i]:SetChecked(checked)
		end
	end
end

-- the widget template is an abomination. what was i thinking?
function opt:ModelRadioOnClick()
	local id = self:GetID()
	if id == 1 then
		settings.ModelZoom = 1
	elseif id==2 then
		settings.ModelZoom = .5
	else
		settings.ModelZoom = 0
	end
	opt:RefreshRadios()
	adapt.SetAllCameras()
end

function opt:RefreshRadios()
	local zoom = settings.ModelZoom
	opt.widgets[6]:SetChecked(zoom==1)
	opt.widgets[16]:SetChecked(zoom==.5)
	opt.widgets[17]:SetChecked(zoom==0)
end

--[[ Color swatch ]]

function opt:BackColorChanged(...)
	local back = settings.BackColor
	back.r, back.g, back.b = ColorPickerFrame:GetColorRGB()
	back.a = 1-OpacitySliderFrame:GetValue()
	adapt.ColorAllBackLayers()
	opt.widgets[opt.modalwidget].color:SetVertexColor(back.r,back.g,back.b,back.a)
end

function opt:BackColorCancelled(...)
	local back = settings.BackColor
	back.r, back.g, back.b, back.a = unpack(ColorPickerFrame.previousValues)
	settings.ColorByClass = opt.oldColorByClass
	opt:SetCheckedByName("ColorByClass",settings.ColorByClass)
	adapt.ColorAllBackLayers()
	opt.widgets[opt.modalwidget].color:SetVertexColor(back.r,back.g,back.b,back.a)
end

function opt:BackColorOnClick()
	opt.changed = 1
	opt.oldColorByClass = settings.ColorByClass
	settings.ColorByClass = nil
	opt:SetCheckedByName("ColorByClass",nil)
	local saved = settings.BackColor
	ColorPickerFrame.func = opt.BackColorChanged
	ColorPickerFrame.opacityFunc = opt.BackColorChanged
	ColorPickerFrame.cancelFunc = opt.BackColorCancelled
	opt.modalwidget = self.id
	ColorPickerFrame.hasOpacity = true
	ColorPickerFrame.opacity = 1-saved.a
	ColorPickerFrame.previousValues = {saved.r,saved.g,saved.b,saved.a}
	ColorPickerFrame:SetColorRGB(saved.r,saved.g,saved.b)
	ColorPickerFrame:Hide()
	ColorPickerFrame:Show()
end

--[[ Blacklist ]]

function opt:CreateBlacklist()
	opt.list = CreateFrame("Frame",nil,opt)
	opt.list:SetSize(300,176)
	opt.list:SetPoint("TOPLEFT",opt.widgets[13],"BOTTOMLEFT",8,-8)
	opt.list:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", insets={left=4,right=4,top=4,bottom=4}, tileSize=16, tile=true, edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=16})
	opt.list:SetBackdropBorderColor(.5,.5,.5,1)
	for i=1,8 do
		opt.list[i] = CreateFrame("CheckButton",nil,opt.list,"UICheckButtonTemplate")
		opt.list[i]:SetSize(24,24)
		opt.list[i]:SetPoint("TOPLEFT",8,(i-1)*-20-6)
		opt.list[i].text:SetFontObject("GameFontHighlight")
		opt.list[i].text:SetPoint("LEFT",opt.list[i],"RIGHT",2,1)
		opt.list[i]:SetHitRectInsets(0,-240,0,0)
		opt.list[i]:SetCheckedTexture("Interface\\RAIDFRAME\\ReadyCheck-NotReady")
		opt.list[i]:SetScript("OnClick",opt.BlacklistCheckOnClick)
	end
	opt.list.scrollFrame = CreateFrame("ScrollFrame","AdaptBlacklistScrollFrame",opt.list,"FauxScrollFrameTemplate")
	opt.list.scrollFrame:SetPoint("TOPLEFT",0,-8)
	opt.list.scrollFrame:SetPoint("BOTTOMRIGHT",-28,6)

	opt.list.scrollFrame:SetScript("OnShow",opt.BlacklistScrollFrameUpdate)
	opt.list.scrollFrame:SetScript("OnVerticalScroll",function(self,offset)
		FauxScrollFrame_OnVerticalScroll(self,offset,20,opt.BlacklistScrollFrameUpdate)
	end)
end

function opt:BlacklistCheckOnClick()
	local portraitName = self.text:GetText()
	settings.Blacklist[portraitName] = self:GetChecked()
	adapt.RefreshAll()
end

function opt:BlacklistScrollFrameUpdate()
	local offset = FauxScrollFrame_GetOffset(opt.list.scrollFrame)
	FauxScrollFrame_Update(opt.list.scrollFrame, #opt.portraitList, 8, 20)
	for i=1,8 do
		local idx = offset+i
		if idx<=#opt.portraitList then
			local portraitName = opt.portraitList[idx]
			opt.list[i].text:SetText(portraitName)
			opt.list[i]:SetChecked(settings.Blacklist[portraitName])
			opt.list[i]:Show()
		else
			opt.list[i]:Hide()
		end
	end
end
