local addonName,adapt = ...

AdaptSettings = {} -- saved variables
Adapt = adapt -- global for access outside this addon

adapt.defaults = {	-- default settings
	ModelZoom=1,
	ColorByClass=1,
	BackColor={r=0.5,g=0.5,b=0.5,a=1},
	Blacklist={} -- texture (names) that are not to be animated
}

adapt.portraits = {} -- this is indexed by the original texture objects

adapt.runway = {} -- queue for models to be drawn

adapt.main = CreateFrame("Frame",nil,UIParent)
adapt.main:Hide()
adapt.main:SetScript("OnEvent",function(self,event,unit)
	if event=="UNIT_MODEL_CHANGED" then
		for texture,portrait in pairs(adapt.portraits) do
			if portrait.unit==unit then
				adapt.AddToRunway(texture,"low")
			end
		end
	elseif event=="UNIT_EXITED_VEHICLE" and unit=="player" and PlayerPortrait and adapt.portraits[PlayerPortrait] then
		-- for client bug with sliding PlayerPortrait when exiting vehicles (model set, not rendered)
		adapt.portraits[PlayerPortrait].modelLayer:SetScript("OnUpdate",function(self,elapsed)
			self:SetScript("OnUpdate",nil)
			adapt.AddToRunway(PlayerPortrait,"low")
		end)
	elseif event=="PLAYER_LOGIN" then
		adapt.CheckSavedVariables()
		adapt.UpdateBlackcache()
		adapt:InitializeOptions(AdaptSettings,adapt.defaults)
		hooksecurefunc("SetPortraitTexture",adapt.NewSetPortraitTexture)
		self:SetScript("OnUpdate",adapt.WalkRunway)
		self:RegisterEvent("UNIT_MODEL_CHANGED")
		self:RegisterEvent("UNIT_EXITED_VEHICLE")
	end
end)
adapt.main:RegisterEvent("PLAYER_LOGIN")

-- when priority is "high" (guid change), SetUnit will happen on next frame
-- for low priority updates (UNIT_MODEL_CHANGED), we can afford to wait
function adapt.AddToRunway(texture,priority)
	if adapt.runway[texture]=="high" then
		return -- already here on high priority
	end
	adapt.runway[texture] = priority
	adapt.main.timer = 0
	adapt.main:Show()
end

function adapt.WalkRunway(self,elapsed)
	-- process high priority updates right away
	for texture,priority in pairs(adapt.runway) do
		if priority=="high" then
			adapt.SetUnit(texture)
			adapt.runway[texture] = nil
		end
	end
	self.timer = self.timer + elapsed
	if self.timer > .25 then
		for texture,priority in pairs(adapt.runway) do
			adapt.SetUnit(texture)
		end
		self:Hide()
		self.timer = 0
		wipe(adapt.runway) -- show is over!
	end
end

-- sets SavedVariables to default if first run or variable deleted
function adapt.CheckSavedVariables()
	if not AdaptSettings or not next(AdaptSettings) then
		AdaptSettings = AdaptSettings or {}
		wipe(AdaptSettings)
		for k,v in pairs(adapt.defaults) do
			if type(v)=="table" then
				AdaptSettings[k] = {}
				for x,y in pairs(v) do
					AdaptSettings[k][x] = y
				end
			else
				AdaptSettings[k] = v
			end
		end
	end
	-- change setting for 2.0.11
	if AdaptSettings.FullModel then
		AdaptSettings.ModelZoom = 0
	end
	if not AdaptSettings.ModelZoom then
		AdaptSettings.ModelZoom = 1
	end
end

function adapt.UpdateBlackcache()
	adapt.Blackcache = adapt.Blackcache or {}
	wipe(adapt.Blackcache)
	for texture in pairs(AdaptSettings.Blacklist) do
		if _G[texture] then
			adapt.Blackcache[_G[texture]] = 1
		end
	end
end

-- primary hook. when SetPortraitTexture happens, this function is also called
-- and creates a model to take its place.
function adapt.NewSetPortraitTexture(texture,unit)
	if UnitExists(unit) and not adapt.Blackcache[texture] then
		local portrait = adapt.portraits[texture] or adapt.CreateModel(texture,unit)
		local guid = UnitGUID(unit)
		if guid~=portrait.guid then
			adapt.AddToRunway(texture,"high")
		end
		portrait.guid = guid
	end
end

-- creates a model to mimic the intended texture and unit
function adapt.CreateModel(texture,unit)
	adapt.portraits[texture] = {}
	local portrait = adapt.portraits[texture]

	-- store attributes of the original texture we'll need later
	portrait.unit = unit
	local drawLayer = texture:GetDrawLayer()
	portrait.cx = texture:GetWidth()
	portrait.cy = texture:GetHeight()

	-- create a backLayer whose parent is the old texture's parent
	portrait.backLayer = texture:GetParent():CreateTexture(nil,drawLayer=="OVERLAY" and "ARTWORK" or drawLayer)
	portrait.backLayer:Hide()
	portrait.backLayer:SetTexture("Interface\\AddOns\\Adapt\\Adapt-ModelBack")
	portrait.backLayer:SetWidth(portrait.cx)
	portrait.backLayer:SetHeight(portrait.cy)
	for i=1,texture:GetNumPoints() do
		portrait.backLayer:SetPoint(texture:GetPoint(i))
	end

	-- create a modelLayer whose parent is the old texture's parent, with useParentLevel="true"
	portrait.modelLayer = CreateFrame("PlayerModel",nil,texture:GetParent(),"AdaptModelLevelTemplate")
	portrait.modelLayer:Hide()
	portrait.modelLayer.parentTexture = texture

	local parent = texture:GetParent()
	parent.adaptPortrait = adapt.portraits[texture]
	parent:HookScript("OnShow",function(self) adapt.AddToRunway(self.adaptPortrait.modelLayer.parentTexture,"high") end)

	adapt.ShapeModel(texture)

	return adapt.portraits[texture]
end

-- when shown, models sometimes need their camera reset
function adapt.ModelOnShow(self)
	local parent = self.parentTexture
	if adapt.portraits[parent] then
		adapt.AddToRunway(parent,"high")
	end
end

-- draws the unit for a texture which is now a model
function adapt.SetUnit(texture)
	local portrait = adapt.portraits[texture]
	local unit = portrait.unit
	local parent = texture:GetParent()

	local textureName = texture:GetName()
	if unit and UnitIsVisible(unit) and parent:IsVisible() and (not parent.unit or parent.unit==unit) and (not AdaptSettings.BlacklistAnonymous or textureName) and (not textureName or not AdaptSettings.Blacklist[textureName]) and portrait.cx>=30	 then
		portrait.modelLayer:SetUnit(unit)
		adapt.SetCamera(texture)
		adapt.ColorBackLayer(texture,unit)
		portrait.backLayer:Show()
		portrait.modelLayer:Show()
		texture:Hide()
	else
		portrait.backLayer:Hide()
		portrait.modelLayer:Hide()
		texture:Show()
	end
end

function adapt.ShapeModel(texture)
	local portrait = adapt.portraits[texture]
	local xoff,yoff,toff = 0,0,0.2
	if not AdaptSettings.Square then
		xoff = 0.0985*portrait.cx -- circle portrait has model slightly smaller
		yoff = 0.0985*portrait.cy
		toff = 0 -- and full texcoord of background texture
	end
	portrait.modelLayer:SetPoint("TOPLEFT",portrait.backLayer,"TOPLEFT",xoff,-yoff)
	portrait.modelLayer:SetPoint("BOTTOMRIGHT",portrait.backLayer,"BOTTOMRIGHT",-xoff,yoff)
	portrait.backLayer:SetTexCoord(toff,1-toff,toff,1-toff)
end

function adapt.ShapeAllModels()
	for texture in pairs(adapt.portraits) do
		adapt.ShapeModel(texture)
	end
end

function adapt.SetCamera(texture)
	local zoom = 1
	adapt.portraits[texture].modelLayer:SetPortraitZoom(AdaptSettings.ModelZoom)
--	adapt.portraits[texture].modelLayer:SetPortraitZoom(.6)
end

function adapt.SetAllCameras()
	for texture,portrait in pairs(adapt.portraits) do
		adapt.SetCamera(texture)
	end
end

function adapt.ColorBackLayer(texture,unit)
	unit = unit or adapt.portraits[texture].unit
	local color,mute = AdaptSettings.BackColor,1
	if AdaptSettings.ColorByClass then
		color,mute = RAID_CLASS_COLORS[select(2,UnitClass(unit))],0.65
	end
	if color then
		adapt.portraits[texture].backLayer:SetVertexColor(color.r*mute,color.g*mute,color.b*mute,color.a or 1)
	else
		adapt.portraits[texture].backLayer:SetVertexColor(5,.5,.5,1)
	end
end

function adapt.ColorAllBackLayers()
	for texture in pairs(adapt.portraits) do
		adapt.ColorBackLayer(texture)
	end
end

function adapt.RefreshAll()
	adapt.ShapeAllModels()
	adapt.ColorAllBackLayers()
	for texture,portrait in pairs(adapt.portraits) do
		if portrait.modelLayer:GetParent():IsVisible() then
			adapt.AddToRunway(portrait.modelLayer.parentTexture,"high")
		end
	end
end

-- /adapt slash command to show options
SlashCmdList["ADAPT"] = function(msg)
	if msg=="debug" then
		print("__ Defined portraits __")
		for texture,portrait in pairs(adapt.portraits) do
			local model = portrait.modelLayer:GetModel() or ""
			model = model:len()>1 and model:match(".+\\(.-)$") or ""
			print(texture:GetName() or "nil child of "..(texture:GetParent():GetName() or "nil"),"\""..model.."\"")
		end
	else
		InterfaceOptionsFrame_OpenToCategory(addonName)
		if not AdaptOptionsPortrait:IsVisible() then -- need to go to it again if it didn't really open
			InterfaceOptionsFrame_OpenToCategory(addonName)
		end
	end
end
SLASH_ADAPT1 = "/adapt"
