-- ChatSubs 2.34
-- by Travis S. Casey (efindel@gmail.com)

-- detect whether ChatSubs has already been loaded
if GetAddOnMetadata("ChatSubs", "Version") then
  local version = tonumber(GetAddOnMetadata("ChatSubs", "Version"))
  if version then
    -- if version is nil, it's an older version using the x.y.z 
    -- version numbering, so we're a newer version
    local myversion = tonumber(GetAddOnMetadata("AddEmote", "Version"))
    if myversion and ( myversion <= version ) then
      -- we can use the loaded ChatSubs, so don't load this one
      -- "return" when you aren't in a function should just exit 
      -- the current file
      return
    end
  end
end
-- if we make it here, then either ChatSubs isn't there, it's an older
-- version, or this *is* ChatSubs, not AddEmote

-- set up a namespace for our non-local functions
ChatSubs = {}

-- string declarations for various functions to use
local Nominative = { "it", "he", "she" }
local Objective = { "it", "him", "her" }
local Possessive = { "its", "his", "her" }
local Possessive2 = { "its", "his", "hers" }
local Noun = { "unknown sex", "male", "female" }

local RaidIcon = { 
	"yellow star",
	"orange circle",
	"purple diamond",
	"green triangle",
	"crescent moon",
	"blue square",
	"red X",
	"skull",
}

local capstring = "%%%w+"

-- do we have all the units we need to do this? If no, return nil
-- if yes, return how many units that is
function ChatSubs.ValidUnits (emotestring)
  -- return 1 by default (the player)
  local valid = 1
  emotestring = string.lower(emotestring)

  if string.find(emotestring, "%%t") or string.find(emotestring, "<target") then
    if UnitExists("target") then 
      valid = valid + 1
    else
      return nil
    end
  end
  if string.find(emotestring, "%%f") or string.find(emotestring, "<focus") then
    if UnitExists("focus") then
      valid = valid + 1
    else 
      return nil
    end
  end
  if string.find(emotestring, "%%m") or string.find(emotestring, "<pet") then
    if UnitExists("pet") then
      valid = valid + 1
    else
      return nil
    end
  end
  -- we don't have to check %p or <player -- there's always a player

  return valid
end

-- count the number of substitution units we have
function ChatSubs.CountSubs(string)
  local count = 0
  local match
  for match in string.gmatch(string, capstring) do
    count = count + 1
  end
  for match in string.gmatch(string, "<%w+>") do
    count = count + 1
  end
  return count
end

-- pass the text string we want <text> to use to ChatSubs
function ChatSubs.SetText(string)
  ChatSubs.CurrentText = string
end

-- UnitSex throws an error if we have no target, so let's wrap it...
local function Sex( who )
  if not UnitName(who) then
    return 1
  else
    return UnitSex(who)
  end
end

local function Capitalize( str )
  if str == "" or not str then return "" end
  return string.upper(str:sub(1, 1))..str:sub(2, -1)
end

-- expand our short target strings
function ChatSubs.whichtarget( str )
  local which
  which = str:sub(1, 1)
  if which == "t" or which == "target" then 
    return "target"
  elseif which == "f" then
    return "focus"
  elseif which == "m" then
    return "pet"
  elseif which == "o" then
    return "mouseover"
  else
    return "player"
  end
end

-- mobs don't have races, they have creature types
function ChatSubs.getrace( who )
  return UnitRace(who) or UnitCreatureType(who) or "unknown race"
end

-- for the %wt syntax
function ChatSubs.substitute( str )
  local who, token

  -- remove % from the front
  str = str:sub(2, -1)
  -- get the target type from the first char
  who = ChatSubs.whichtarget( str )
  if not UnitExists(who) then
    who = "noone"
  end
  -- get the token
  token = str:sub(2, -1)
  if ChatSubs[string.lower(token)] then
    if token == string.upper(token) then
      return Capitalize( ChatSubs[string.lower(token)](who) )
    else 
      return ChatSubs[token](who)
    end
  else
    return ""
  end
end

-- for the <whowhat> syntax
function ChatSubs.newsubstitute( str )
  local who, what

  -- temporary convert to lowercase, to ease our searching
  local testwho = string.lower(str)

  -- get the who part
  if string.find( testwho, "<player" ) then
    who = "player"
  elseif string.find( testwho, "<target" ) then
    who = "target"
  elseif string.find( testwho, "<pet" ) then
    who = "pet"
  elseif string.find( testwho, "<focus" ) then
    who = "focus"
  elseif string.find( testwho, "<mouseover" ) then
    who = "mouseover"
  else
    -- didn't match any of those?  okay, let's see
    -- if we just have a "what"
    who = ""
  end
  -- now that we know the who part, the rest is the what part
  what = string.sub( str, string.len(who)+2, -2 )
  if who == "" then who = "player" end

-- uncomment for debugging
-- print(what.."-"..who)
  if not UnitExists(who) then
    who = "noone"
  end

  if ChatSubs[string.lower(what)] == nil then
    return str
  end

  local firstletter = string.sub( what, 1, 1 )
  if firstletter == string.upper(firstletter) then
    return Capitalize( ChatSubs[string.lower(what)](who) )
  else
    return ChatSubs[string.lower(what)](who)
  end
end

ChatSubs[""] = function (who)
  if who == "noone" then return "everyone" end
  return UnitName(who)
end

ChatSubs["name"] = ChatSubs[""]

ChatSubs["n"] = function (who)
  return Nominative[Sex(who)]
end

ChatSubs["heshe"] = ChatSubs["n"]

ChatSubs["o"] = function (who)
  return Objective[Sex(who)]
end

ChatSubs["himher"] = ChatSubs["o"]

ChatSubs["p"] = function (who)
  return Possessive[Sex(who)]
end

ChatSubs["hisher"] = ChatSubs["p"]

ChatSubs["p2"] = function (who)
  return Possessive2[Sex(who)]
end

ChatSubs["hishers"] = ChatSubs["p2"]

ChatSubs["s"] = function (who)
  return Noun[Sex(who)]
end

ChatSubs["sex"] = ChatSubs["s"]

ChatSubs["t"] = function (who)
  return string.lower((UnitCreatureFamily(who) or ""))
end

ChatSubs["type"] = ChatSubs["t"]

ChatSubs["text"] = function ()
  return ChatSubs.CurrentText
end

-- this works for English, but would have to be changed for localized versions
ChatSubs["c"] = function (who)
  local class
  _, class = UnitClass(who)
  if class == "DEATHKNIGHT" then 
    class = "death knight"
  end
  if class then 
    return string.lower(class) 
  else
    return "unknown class"
  end
end

ChatSubs["class"] = ChatSubs["c"]

ChatSubs["r"] = function (who)
  return string.lower(ChatSubs.getrace(who))
end

ChatSubs["race"] = ChatSubs["r"]

ChatSubs["l"] = function (who)
  return UnitLevel(who) or "unknown level"
end

ChatSubs["level"] = ChatSubs["l"]

ChatSubs["pvp"] = function (who)
  if UnitIsPVP(who) then
    return "flagged"
  else
    return "unflagged"
  end
end

ChatSubs["m"] = function (who)
  return RaidIcon[GetRaidTargetIndex(who)] or "no icon"
end

ChatSubs["mark"] = ChatSubs["m"]

ChatSubs["os"] = function(who)
  local x, y = GetPlayerMapPosition("player")
  return string.sub(x*100, 1, 4) .."," .. string.sub(y*100, 1, 4)
end

ChatSubs["position"] = ChatSubs["os"]

ChatSubs["h"] = function (who)
  return math.ceil(UnitHealth(who)/UnitHealthMax(who)*100) .. "%"
end

ChatSubs["health"] = ChatSubs["h"]

-- declarations done, here's where we actually do the work.  It's 
-- pretty simple

-- save Blizzard's SendChatMessage so we can use it
local oldSendChatMessage = SendChatMessage

-- declare our own SendChatMessage
function SendChatMessage(msg, ...)
  -- search for substrings starting with % and the following letters
  -- and numbers, then substitute for them
  msg = string.gsub(msg, capstring, ChatSubs.substitute)
  -- search substrings of the pattern <something>, subtitute for them
  msg = string.gsub(msg, "<%w+>", ChatSubs.newsubstitute)
  -- use blizzard's SendChatMessage to send the changed message
  oldSendChatMessage(msg, ...)
end
