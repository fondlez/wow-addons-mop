if ( GetLocale() == "zhTW" ) then

AUTO_INVITE_MOD_LOADED_SUCCESSFULLY="Mod loaded successfully. Version: %d. /ai for help.";

AUTO_INVITE_CLASS={
   DRUID = "德魯伊",
   HUNTER = "獵人",
   MAGE = "法師",
   PALADIN = "聖騎士",
   SHAMAN = "薩滿",
   PRIEST = "牧師",
   ROGUE = "盜賊",
   WARRIOR = "戰士",
   WARLOCK = "術士",
};
AUTO_INVITE_UNKNOWN_ENTITY="未知";

-- the GUI Main Frame
AUTO_INVITE_COMPLETELIST="名單列表(%d)";
AUTO_INVITE_NUMBER_OF_PLAYERS="玩家人數: %d/%d";
AUTO_INVITE_TO_GROUP="組隊邀請";
AUTO_INVITE_WISPER_PLAYER_IF_IN_GROUP="密語通知已有組隊的玩家";
AUTO_INVITE_WISPER_PLAYER_IF_IN_GROUP_DESC_HEADER="密語通知玩家";
AUTO_INVITE_WISPER_PLAYER_IF_IN_GROUP_DESC_BODY="當你要組隊時，若被邀請玩家已有隊伍，則發出密語通知該玩家。";
AUTO_INVITE_MOD_ACTIVE="Mod active";
AUTO_INVITE_MOD_ACTIVE_DESC_HEADER="Mod Active";
AUTO_INVITE_MOD_ACTIVE_DESC_BODY="載入此MOD。您可使用此MOD追蹤並儲存組隊設定。";
AUTO_INVITE_RAID_INVITE="團隊邀請";
AUTO_INVITE_RAID_INVITE_DESC_HEADER="團隊邀請";
AUTO_INVITE_RAID_INVITE_DESC_BODY="開始組隊邀請並將隊伍轉換為團隊。您可以關閉視窗，組隊邀請仍會在背景中執行。再按一次會停止組隊邀請。";
AUTO_INVITE_GROUP_INVITE="組隊邀請";
AUTO_INVITE_GROUP_INVITE_DESC_HEADER="組隊邀請";
AUTO_INVITE_GROUP_INVITE_DESC_BODY="開始組隊。您可以關閉視窗，組隊邀請仍會在背景中執行。再按一次會停止組隊邀請。";
AUTO_INVITE_READ_GROUPS="讀取隊伍";
AUTO_INVITE_READ_GROUPS_DESC_HEADER="讀取隊伍";
AUTO_INVITE_READ_GROUPS_DESC_BODY="讀取目前的隊伍配置(即各玩家在哪個小隊)。可以在稍後使用 讀取-儲存功能時，自動將玩家放至目前的小隊配置中。";
AUTO_INVITE_MOVE_GROUPS="移動隊伍";
AUTO_INVITE_MOVE_GROUPS_DESC_HEADER="移動隊伍";
AUTO_INVITE_MOVE_GROUPS_DESC_BODY="移動小隊中的玩家。";
AUTO_INVITE_LOAD_SAVE="讀取-儲存";
AUTO_INVITE_LOAD_SAVE_DESC_HEADER="讀取-儲存";
AUTO_INVITE_LOAD_SAVE_DESC_BODY="開啟一個新的框架使您輸入，讀取並儲存隊伍設定。";
AUTO_INVITE_UPDATE="更新";
AUTO_INVITE_UPDATE_DESC_HEADER="更新";
AUTO_INVITE_UPDATE_DESC_BODY="輸入玩家名單-目前已在隊伍中，但不在MOD中者。";
AUTO_INVITE_CLEAR="清除";
AUTO_INVITE_CLEAR_DESC_HEADER="清除";
AUTO_INVITE_CLEAR_DESC_BODY="將目前已不在隊伍中的玩家從名單列表中移除。";
AUTO_INVITE_ADD="增加";
AUTO_INVITE_ADD_DESC_HEADER="增加";
AUTO_INVITE_ADD_DESC_BODY="將目前選定玩家加入名單列表中或開啟新視窗輸入玩家ID。";
AUTO_INVITE_SORT="排序";
AUTO_INVITE_SORT_DESC_HEADER="排序";
AUTO_INVITE_SORT_DESC_BODY="是否依照字母順序排列名單列表。";
AUTO_INVITE_GET_STATE="取得狀態";
AUTO_INVITE_GET_STATE_DESC_HEADER="取得狀態";
AUTO_INVITE_GET_STATE_DESC_BODY="檢查名單中的玩家是否在線上。在線上則標示綠色。這個選項只對您公會的玩家有效。";
AUTO_INVITE_LOCK="鎖定";
AUTO_INVITE_LOCK_DESC_HEADER="鎖定";
AUTO_INVITE_LOCK_DESC_BODY="是否能在名單列表中按右鍵移除玩家。";
AUTO_INVITE_CLOSE="關閉";
AUTO_INVITE_CLOSE_DESC_HEADER="關閉";
AUTO_INVITE_CLOSE_DESC_BODY="關閉視窗。";
AUTO_INVITE_LOAD_GUILD="讀取公會資料";
AUTO_INVITE_LOAD_GUILD_DESC_HEADER="讀取公會資料";
AUTO_INVITE_LOAD_GUILD_DESC_BODY="將您公會的所有玩家輸入至名單列表中。";

-- Description for the lists
AUTO_INVITE_COMPLETE_LIST_HEADER="名單列表";
AUTO_INVITE_COMPLETE_LIST_DESC_BODY="按左鍵將玩家加入至目前的隊伍配置中。按右鍵移除玩家。";
AUTO_INVITE_LEFT_LIST_HEADER="職業列表";
AUTO_INVITE_LEFT_LIST_DESC_BODY="按左鍵將玩家從目前配置中移除。按右鍵可定義隊伍編號。";

-- Frame Add Player
AUTO_INVITE_ADDMEMBER_LABEL="要加入至名單列表中的姓名:";
AUTO_INVITE_CLASS_LABEL="職業";
AUTO_INVITE_NAME_LABEL="姓名";

-- Frame Save Groupsetup
AUTO_INVITE_SAVEDESCRPTION_LABEL="描述目前的隊伍配置";

-- Frame Load Save Config
AUTO_INVITE_LOAD_SAVE_CONFIG="讀取儲存設定";
AUTO_INVITE_SAVE_NEW="另存新檔";
AUTO_INVITE_SAVE_NEW_DESC_HEADER="另存新檔";
AUTO_INVITE_SAVE_NEW_DESC_BODY="儲存目前設定。您可以輸入任何您想要的名稱並儲存。";
AUTO_INVITE_IMPORT_CSV="輸入 CSV";
AUTO_INVITE_IMPORT_CSV_DESC_HEADER="輸入 CSV";
AUTO_INVITE_IMPORT_CSV_DESC_BODY="開啟一個新視窗讓您可以 複製+貼上 您的CSV 列表。";
AUTO_INVITE_LOAD="讀取";
AUTO_INVITE_LOAD_DESC_HEADER="讀取";
AUTO_INVITE_LOAD_DESC_BODY="讀取該設定";
AUTO_INVITE_SAVE="儲存";
AUTO_INVITE_SAVE_DESC_HEADER="儲存";
AUTO_INVITE_SAVE_DESC_BODY="用這個名稱儲存您目前的設定";
AUTO_INVITE_DEL="刪除";
AUTO_INVITE_DEL_DESC_HEADER="刪除";
AUTO_INVITE_DEL_DESC_BODY="刪除這個設定";

-- Frame Import CSV
AUTO_INVITE_TITLE_IMPORT_CSV="輸入 CSV";
AUTO_INVITE_ENTER_NAME_FOR_PROFILE="輸入名稱以命名此檔案:";
AUTO_INVITE_COPY_CSV_HERE="在這裡按 CTRL+v 複製 CSV:";
AUTO_INVITE_IMPORT="輸入";
AUTO_INVITE_IMPORT_DESC_HEADER="輸入";
AUTO_INVITE_IMPORT_DESC_BODY="輸入已複製貼上之設定";

-- Shortcut Menu for WoW
BINDING_HEADER_AUTOINVITE="自動邀請";
BINDING_NAME_AISHOW="顯示或隱藏此設定視窗";
BINDING_NAME_AIINVITE="邀請玩家";
BINDING_NAME_AIADD="將目標加入至列表";

-- Text which must be parsed to get player status must be localized!
AUTO_INVITE_DECLINES_YOUR_INVITATION     ="%a+ 拒絕您的組隊邀請。";
AUTO_INVITE_DECLINES_YOUR_INVITATION_FIND="^(.+) 拒絕您的組隊邀請。";
AUTO_INVITE_IGNORES_YOUR_INVITATION="%a+ 忽略您的訊息。";
AUTO_INVITE_IGNORES_YOUR_INVITATION_FIND="^(.+) 忽略您的訊息。";

AUTO_INVITE_IS_ALREADY_IN_GROUP="%a+ 已經有隊伍了。";
AUTO_INVITE_IS_ALREADY_IN_GROUP_FIND="^(.+) 已經有隊伍了。";
AUTO_INVITE_SEND_MESSAGE_ALREADY_IN_GROUP="您已經有隊伍了，請先離隊。";

AUTO_INVITE_GROUP_LEAVE="%a+ 離開隊伍。";
AUTO_INVITE_GROUP_LEAVE_FIND="(.+) 離開隊伍。";
AUTO_INVITE_RAID_LEAVE="%a+ 已經離開團隊。";
AUTO_INVITE_RAID_LEAVE_FIND="(.+) 已經離開團隊。";

AUTO_INVITE_INVITED="您已經邀請 %w+ 加入隊伍。";
AUTO_INVITE_INVITED_FIND="您已經邀請 (.+) 加入隊伍。";
AUTO_INVITE_GROUP_DISBANDED="您的隊伍已解散。";
AUTO_INVITE_GROUP_DISBANDED2="您離開隊伍了。";
AUTO_INVITE_RAID_DISBANDED="您已經離開團隊了。";

AUTO_INVITE_GONE_OFFLINE="%a+ 已離線";
AUTO_INVITE_IS_OFFLINE="找不到玩家 '%a+'.";
AUTO_INVITE_IS_OFFLINE_FIND="找不到玩家 '(.+)'.";

-- Chat messages send to GUI
AUTO_INVITE_NEED_ADDON_QUEUE_WHO="Can only read status for players in guild\nYou need the addon QueueWho to use this feature for all players, see the readme.txt";
AUTO_INVITE_AUTOINVITEGETMEMBERBYNAME_ERROR="AutoInvite ERROR in autoInviteGetMemberByName: Player %s is unknown";
AUTO_INVITE_ERROR_FOUND_NO_ID="Error with player: %s found no ID";
AUTO_INVITE_PLAYER_IGNORES_YOU="User: %s ignores you";
AUTO_INVITE_PLAYER_IS_ALREADY_IN_GROUP="User: %s is already in Group";
AUTO_INVITE_ERROR_ADDING_PLAYER_CONTACT_AUTHOR="Error in adding player: %s please contact the author of this mod";
AUTO_INVITE_PLAYER_LEFT_THE_GROUP="User: %s left the group";
AUTO_INVITE_PLAYER_LEFT_THE_RAID="User: %s left the raid";
AUTO_INVITE_COMMAND_HELP1="/ai show: show the configuration window";
AUTO_INVITE_COMMAND_HELP2="/ai add: add the corrent target to the complete list";
AUTO_INVITE_COMMAND_HELP3="/ai debug: view some debugging variables";
AUTO_INVITE_COMMAND_HELP4="/ai dump: save debugging info to file, please always do it when reporting bugs";
AUTO_INVITE_COMMAND_HELP5="/ai cleardump: clear the debug infos from the file";
AUTO_INVITE_COMMAND_HELP6="/ai verbose: de-/activate verbose mode";
AUTO_INVITE_COMMAND_HELP7="/ai reset: reset all values to default";
AUTO_INVITE_COMMAND_HELP8="/ai guild: add all guild members to the complete list";
AUTO_INVITE_NO_TARGET_SELECTED_SKIPPING="No target selected, skipping";
AUTO_INVITE_DEBUG_CALLED="DEBUG called, dump variables";
AUTO_INVITE_DUMP_CALLED="DUMP called, dump variables to file";
AUTO_INVITE_CLEAR_DUMP_CALLED="CLEARDUMP called, empty dump field";
AUTO_INVITE_VERBOSE_MOD_ACTIVE="VERBOSE mod activated";
AUTO_INVITE_VERBOSE_MOD_DEACTIVE="VERBOSE mod deactivated";
AUTO_INVITE_ADD_PLAYER_XXX_TO_LIST="Adding %s %d %s to list"
AUTO_INVITE_PLAYER_ALREADY_IN_LIST="Player %s is already in the list, skipping";
AUTO_INVITE_GOT_UNKOWN_SKIPPING="Got playername Unknown, skipping";
AUTO_INVITE_ADD_PLAYER_NOT_IN_TARGET="Player is not in target, got no information about it, added %s to list";
AUTO_INVITE_NO_INFO_AVAILABLE_MOVE_DRUIDE="No information about player %s available, move it to DRUIDE";
AUTO_INVITE_READ_GROUP_SETUP="Read Group Setup";
AUTO_INVITE_DONE="done.";
AUTO_INVITE_IM_NOT_THE_RAID_LEADER_SKIPPING="I am not the Raid Leader, skipping.";
AUTO_INVITE_FOR_XXX_NO_GROUP_DEFINED="For player %s no group defined, define it and try again";
AUTO_INVITE_PLAYER_MARKED_FOR_MOVING="Player %s is marked for moving";
AUTO_INVITE_START_TO_MOVE_PLAYERS="Start to move players...";
AUTO_INVITE_MOVING_FINISHED="Moving finished";
AUTO_INVITE_CANNOT_MOVE_PLAYER_GROUP_IS_FULL="Cannot move %s wish group is full";
AUTO_INVITE_LIST_LOADED="List has been loaded";
AUTO_INVITE_SUCCESSFULLY_SAVED="Successfully saved";
AUTO_INVITE_SUCCESSFULLY_DELETED="Successfully deleted";
AUTO_INVITE_NO_NAME_FOR_PROFILE_DONT_SAVE_IT="No name for profile is given, don't save it.";
AUTO_INVITE_GENERATE_DUMP="Generate dump...";
AUTO_INVITE_DUMP_SUCCESSFULLY_SEND_TO="dump successfully generated send the following file to 'idefix@fechner.net':";
AUTO_INVITE_DUMP_SEND_FILE="<WOW-DiR>\\WTF\\Account\\%s\\%s\\%s\\SavedVariables\\AutoInvite.lua";
AUTO_INVITE_THX_FOR_HELP="Thanks a lot for help!";
AUTO_INVITE_TO_SAVE_DUMP="To save the dump, exit the game or press <ENTER> and write: '/console reloadui'";
AUTO_INVITE_CLEAR_DUMP_LOG="Clear debug log...";
AUTO_INVITE_CHECK_ONLINE_STATUS_WITH_WHO="Check online status of player %s with the /who command...";
AUTO_INVITE_ALL_SETTINGS_RESETED="All settings resetted.";
AUTO_INVITE_IMPORT_GUILD_MEMBERS="Importing guild members";

end