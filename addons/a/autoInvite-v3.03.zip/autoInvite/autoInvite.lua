-- $Id$

-- Definition of autoInvite.control object
--
-- array autoInvite.control.member[]
--  the keys of this array are the names of the members
--  runtime information about the members in AutoInviteCompleteList
--      string status
--          "unknown" = default status, nothing done to the player yet
--          "invited" = user has been invited, but did not react yet
--          "offline" = user has been offline during last invite
--          "declined" = user declined our invite
--          "ignored" = user is ignoring us (d'oh! How dare he?)
--          "grouped" = user is already in a group
--          "joined" = user has joined our raid/group
--      integer lastChecked
--          GetTime()*1000 when AI has last interacted with the player - aka time of last information
--      bool show
--        true = show player in complete list
--        false = do not show player in complete list
--      bool inZone
--        true = player is in same zone like myself
--        false = player is not in the same zone
--
-- boolean autoInvite.control.isLoaded
--  true = AI is fully initialized
--  false = guess what
--
-- boolean autoInvite.control.changeToRaid
--  true = convert group to raid as soon as possible (set by pressing the Start-Invite button)
--  false = don't do
--
-- integer autoInvite.control.lastUpdate
--  contains the last GetTime() * 1000 that autoInvite_OnUpdate() ran
--
-- boolean autoInvite.control.doInvites
--  true = _OnUpdate() should do inviting (set by pressing the Start-Invite button)
--  false = go figure...

autoInvite = {};

-- Initialization
if(AutoInviteConfig == nil) then
   AutoInviteConfig={};
end
if(AutoInviteSavedList == nil) then
   AutoInviteSavedList={};
end

if(AutoInviteChatLog == nil) then
   AutoInviteChatLog={};
end

autoInvite.groupCount = { 
   DRUID       = 0,
   HUNTER      = 0,
   MAGE        = 0,
   PALADIN     = 0,
   PRIEST      = 0,
   ROGUE       = 0,
   WARRIOR     = 0,
   WARLOCK     = 0,
   SHAMAN      = 0;
   DEATHKNIGHT = 0;
   MONK        = 0;
};
CALENDAR_EVENTTYPE_RAID    = 1;
CALENDAR_EVENTTYPE_DUNGEON = 2;
CALENDAR_EVENTTYPE_PVP     = 3;
CALENDAR_EVENTTYPE_MEETING = 4;
CALENDAR_EVENTTYPE_OTHER   = 5;

CALENDAR_INVITESTATUS_INVITED   = 1;
CALENDAR_INVITESTATUS_ACCEPTED  = 2;
CALENDAR_INVITESTATUS_DECLINED  = 3;
CALENDAR_INVITESTATUS_CONFIRMED = 4;
CALENDAR_INVITESTATUS_OUT       = 5;
CALENDAR_INVITESTATUS_STANDBY   = 6;

AutoInviteDebugOn=false;
autoInvite.saveChatMsg=false;

autoInvite.ADDON_NAME="AutoInvite";
autoInvite.version=0;

autoInvite.maxlevel=90;
autoInvite.checkTime=60000;
autoInvite.inviteDelay=2000;

autoInvite.yellowColor = { r=1, g=1, b=0 };
autoInvite.greyColor = { r=0.5, g=0.5, b=0.5 };
autoInvite.greenColor = { r=0.1, g=1, b=0.1 };
autoInvite.redColor = { r=1, g=0.1, b=0.1 };
autoInvite.blueColor = { r=0.1, g=0.1, b=1 };

autoInvite.groupCountLimit = { 0, 0, 0, 0, 0, 0, 0, 0};

autoInvite.checkOnlineState=false;
autoInvite.checkOnlineLastId=1;
autoInvite.checkOnlineMaxId=1;

-- variable for moving players in groups
autoInvite.movePlayersActive=false;
autoInvite.needMovePlayers=0;

StaticPopupDialogs["AUTOINVITE_ENTERDESCRIPTION"] = {
   text = TEXT(AUTO_INVITE_SAVEDESCRPTION_LABEL),
   button1 = TEXT(ACCEPT),
   button2 = TEXT(CANCEL),
   hasEditBox=1,
   maxLetters=50,
   OnAccept = function(self)
                 local editBox=_G[self:GetParent():GetName().."EditBox"];
                 autoInvite:loadSaveFrameSave(self,editBox:GetText());
              end,
   OnShow = function(self)
               _G[self:GetName().."EditBox"]:SetFocus();
            end,
   OnHide = function(self)
               --if(ChatFrameEditBox:IsVisible()) then
               --   ChatFrameEditBox:SetFocus();
               --end
               _G[self:GetName().."EditBox"]:SetText("");
            end,
   EditBoxOnEnterPressed = function(self)
                              local editBox=getglobal(self:GetParent():GetName().."EditBox");
                              autoInvite:loadSaveFrameSave(self,editBox:GetText());
                              self:GetParent():Hide();
                           end,
   timeout=0,
   exclusive=1,
   hideOnEscape=1
};

function autoInvite:addPlayerClassOnLoad(self)
   autoInvite:debugMsg("Init Player class dropdown list");
   UIDropDownMenu_Initialize(self, autoInvite.addPlayerClassInitialize);
   --   self:chatMsg("Set Selected Value in dropdown list");
   --   UIDropDownMenu_SetSelectedValue(self, "");
   --    self:chatMsg("Add tooltip in dropdown list");
   --    autoInviteAddPlayerFrameDropDownClass.tooltip = "You are viewing this player's bank contents.";
   autoInvite:debugMsg("Set width in dropdown list");
   UIDropDownMenu_SetWidth(autoInviteAddPlayerFrameDropDownClass, 120);
end

function autoInvite:addPlayerClassOnClick(arg1, arg2, checked)
   -- UIDropDownMenu_SetSelectedValue(ACUI_MyBankDropDown, self.value);
   --autoInvite:debugMsg("self: "..self);
   if ( self.value ) then
      autoInvite:chatMsg("Class: "..self.value);
      UIDropDownMenu_SetSelectedValue(autoInviteAddPlayerFrameDropDownClass, self.value);
   end
end

function autoInvite:addPlayerClassInitialize()
   local selectedValue = UIDropDownMenu_GetSelectedValue(autoInviteAddPlayerFrameDropDownClass);
   local info = UIDropDownMenu_CreateInfo();
   info.text = "";
   info.value = "";
   info.func = autoInvite.addPlayerClassOnClick;
   if ( selectedValue == info.value ) then
      info.checked = 1;
   else
      info.checked = nil;
   end
   UIDropDownMenu_AddButton(info);
   for key, value in pairs(AUTO_INVITE_CLASS) do
      info = UIDropDownMenu_CreateInfo();
      info.text = value;
      info.value = key;
      info.func = autoInvite.addPlayerClassOnClick;
      if ( selectedValue == info.value ) then
         info.checked = 1;
      else
         info.checked = nil;
      end
      UIDropDownMenu_AddButton(info);
   end
end

function autoInvite:init(self)
   autoInvite:debugMsg("in function init");
   -- if we don't have a config, initialize the arrays
   if(AutoInviteCompleteList == nil) then
      AutoInviteCompleteList= { };
   end
   if(AutoInviteConfig == nil) then
      AutoInviteConfig={};
   end
   if(AutoInviteConfig['oldVersion']==nil) then
      AutoInviteConfig['oldVersion']=false;
   end
   if(AutoInviteSavedList == nil) then
      AutoInviteSavedList={};
   end
   autoInvite:resetControlObject();
   -- we always start deactivated
   AutoInviteConfig['modActive']=0;
   -- Register for our events
   autoInvite:registerEvents(self);

   --MyAddon = {};
   --MyAddon.panel = CreateFrame( "Frame", "MyAddonPanel", UIParent );
   ---- Register in the Interface Addon Options GUI
   ---- Set the name for the Category for the Options Panel
   --MyAddon.panel.name = "Auto Invite".." "..autoInvite.version;
   ---- Add the panel to the Interface Options
   --InterfaceOptions_AddCategory(MyAddon.panel);
   --
   ---- Make a child panel
   --MyAddon.childpanel = CreateFrame( "Frame", "MyAddonChild", MyAddon.panel);
   --MyAddon.childpanel.name = "General";
   ---- Specify childness of this panel (this puts it under the little red [+], instead of giving it a normal AddOn category)
   --MyAddon.childpanel.parent = MyAddon.panel.name;
   ---- Add the child to the Interface Options
   --InterfaceOptions_AddCategory(MyAddon.childpanel);

end

function autoInvite:resetControlObject()
   autoInvite:debugMsg("autoInvite:resetControlObject called");
   -- Initialize the controlobject
   autoInvite.control = {
      isLoaded = true,
      changeToRaid = false,
      doInvites = false,
      lastUpdate = GetTime() * 1000,
      
      member = {}
   }
   
   -- map the loaded members into the control object with status unknown and never checked
   for i,v in pairs(AutoInviteCompleteList) do
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']] = { status = "unknown", online = false, inGuild=false, lastChecked = 0, errorMessage="", show=true, inZone=false };
   end
end

function autoInvite:registerEvents(self)
   self:RegisterEvent("CHAT_MSG_SYSTEM");
   self:RegisterEvent("GROUP_ROSTER_UPDATE");
end

function autoInvite:unregisterEvents(self)
   self:UnregisterEvent("CHAT_MSG_SYSTEM");
   self:UnregisterEvent("GROUP_ROSTER_UPDATE");
end

function autoInvite:onLoad(self)
   autoInvite.version=_G.GetAddOnMetadata(autoInvite.ADDON_NAME, "Version");
   autoInvite:debugMsg("In function autoInvite:onLoad()");

   self:RegisterEvent("ADDON_LOADED");
   self:RegisterForDrag("LeftButton");

   -- those are needed so we can deactivate events during zoning, which helps lowering reloadtime a lot
   self:RegisterEvent("PLAYER_ENTERING_WORLD");
   self:RegisterEvent("PLAYER_LEAVING_WORLD");
   --   GameTooltip:SetOwner(self, "ANCHOR_RIGHT");
   --   GameTooltip:ClearLines();
end

-- Manages the invites over time
function autoInvite:onUpdate()
   --autoInvite:debugMsg("OnUpdate Ping!: "..GetTime());

   -- bail out early if we are not active at all 
   if (AutoInviteConfig['modActive'] == 0) then
      return;
   end

   local curTime = GetTime() * 1000;
   -- if less then 0,5 secs passed since the last update, we just bail out - don't overstress the system
   -- if the mod ain't active right now - nothing to do for us!
   if ( curTime - autoInvite.control.lastUpdate < autoInvite.inviteDelay ) then
      return;
   end;

   -- Last update is more the 0,5 secs ago, set current time as last update time
   autoInvite.control.lastUpdate = curTime;

   --   autoInviteDebugMsg("OnUpdate Ping!: "..GetTime());

   -- change group to raid if more then one member is present in group and we are not in raid yet
   if (autoInvite.control.changeToRaid == true and GetNumGroupMembers() >= 2 and (not UnitInRaid("player"))) then
      autoInvite:debugMsg("OnUpdate: autoInvite.control.changeToRaid was true and Party is available - converting");
      autoInvite.control.changeToRaid = false;
      ConvertToRaid();
      return;
   end

   -- iterate through the control object
   -- - manage the timeouts
   -- - do an invite
   -- local helper boolean to remember if we already did our invite for this pass
   local notYetInvited = true;
   for i=1,table.getn(AutoInviteCompleteList) do
      name=AutoInviteCompleteList[i]['name'];
      realm=AutoInviteCompleteList[i]['realm'];
      if (name and realm and notYetInvited and autoInvite.control.doInvites and AutoInviteCompleteList[i]['inGroup'] and autoInvite.control.member[name..'-'..realm]['status'] == "unknown") then
         notYetInvited = false;
         autoInvite:debugMsg("Invite: "..name);
         if(AutoInviteConfig['oldVersion'])then
            InviteByName(name);
         else
            autoInvite:chatMsg("DEBUG INVITE: "..name);
			--local presenceID, presenceName, battleTag, isBattleTagPresence, toonName, toonID = BNGetFriendInfo(2);
            --autoInvite:chatMsg(presenceID..":".. presenceName..":".. battleTag..":".. toonName..":".. toonID);
            --BNInviteFriend(30);
            
            InviteUnit(name..'-'..realm);
         end
         autoInvite.control.member[name..'-'..realm]['lastChecked'] = curTime;
         autoInvite.control.member[name..'-'..realm]['status'] = "invited";
      end;
      if (autoInvite.control.member[name..'-'..realm]['status'] ~= "joined"
          and autoInvite.control.member[name..'-'..realm]['status'] ~= "unknown"
          and curTime - autoInvite.control.member[name..'-'..realm]['lastChecked'] > autoInvite.checkTime) then
         -- disabled because getting error here
         --         autoInvite:debugMsg("In OnUpdate: status timeout after 60 secs, resetting entry "..AutoInviteCompleteList[i]['name']);
         autoInvite.control.member[name..'-'..realm]['lastChecked'] = curTime;
         autoInvite.control.member[name..'-'..realm]['status'] = "unknown";
         -- refresh the frame
         autoInvite:buildGroups()
      end;
   end

end

function autoInvite:getMemberByName(memberName)
   for i=1,table.getn(AutoInviteCompleteList) do
      if AutoInviteCompleteList[i]['name'] == memberName then
         return AutoInviteCompleteList[i]
      end
   end
   autoInvite:chatMsg(format(AUTO_INVITE_AUTOINVITEGETMEMBERBYNAME_ERROR,memberName));
end

-- Event handler
function autoInvite_OnEvent(self, event, arg1, arg2, arg3, ...)
   --   if(event=="PLAYER_ENTERING_WORLD") then
   --      autoInviteInit();
   --autoInvite:debugMsg("In function OnEvent");
   if(event) then
      --autoInvite:debugMsg("Event: "..event);
   end
   if(arg1) then
      --autoInvite:debugMsg("Arg1: "..arg1);
   end
   if (event == "ADDON_LOADED" and arg1 == "AutoInvite") then
      autoInvite:chatMsg(format(AUTO_INVITE_MOD_LOADED_SUCCESSFULLY,autoInvite.version));
      autoInvite:debugMsg("Set shortcuts");
      SlashCmdList["AUTOINVITE"]= function(msg) autoInvite:command(self, msg) end;
      SLASH_AUTOINVITE1="/autoinvite";
      SLASH_AUTOINVITE2="/ai";
      autoInvite:init(self);
      --      autoInvite:showConfigFrame();
      autoInvite:debugMsg("Update saved values");
      autoInvite:completeList_Update();
      autoInvite:buildGroups();
      autoInvite:updateGroupCount();
      autoInvite:ifWisperOnLoad();
      autoInvite:sortCompleteListOnLoad();
      autoInvite:lockCompleteListOnLoad();
      autoInvite:updateMainHeader();
      
   elseif (event == "GROUP_ROSTER_UPDATE") then
      autoInvite:debugMsg("Event GROUP_ROSTER_CHANGED triggered");
      if(AutoInviteConfig['modActive']==1) then
         if(autoInvite.movePlayersActive) then
            autoInvite:debugMsg("Sort players from event");
            autoInvite:movePlayers();
         end
         autoInvite:memberJoinedParty();
         autoInvite:memberJoinedRaid();
      end

   elseif (event == "CHAT_MSG_CHANNEL_JOIN") then
      --autoInvite:debugMsg("Channel joined was called, arg1: "..arg1.." arg2: "..arg2.." arg3: "..arg3.." arg4: "..arg4.." arg5: "..arg5);

   elseif (event == "CHAT_MSG_SYSTEM") then
      autoInvite:debugMsg("Event CHAT_MSG_SYSTEM triggered");
      if(AutoInviteConfig['modActive']==1) then
         if(string.find(arg1,AUTO_INVITE_DECLINES_YOUR_INVITATION)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_DECLINES_YOUR_INVITATION matched!");
            local _,_,playerName = string.find(arg1,AUTO_INVITE_DECLINES_YOUR_INVITATION_FIND);
            --           autoInvite:chatMsg("dummy1: "..dummy1);
            --           autoInvite:chatMsg("dummy2: "..dummy2);
            autoInvite:debugMsg("Player: "..playerName.." declined invitiation");
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil); -- @todo fix this
            autoInvite:chatMsg(format(AUTO_INVITE_ERROR_FOUND_NO_ID,playerName));
            if(id==0) then
               -- player is not in complete list, add him
               autoInvite:completeAdd(self,playerName);
               id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
               AutoInviteCompleteList[id]["inGroup"]=true;
            end
            autoInvite.control.member[playerName]["status"]="declined";
            autoInvite:debugMsg("User: "..playerName.." declined invitation");
            autoInvite:buildGroups();
         elseif (string.find(arg1,AUTO_INVITE_IGNORES_YOUR_INVITATION)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_IGNORES_YOUR_INVITATION matched!");
            local dummy,dummy,playerName=string.find(arg1,AUTO_INVITE_IGNORES_YOUR_INVITATION_FIND);
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
            if(id==0) then
               -- player is not in complete list, add him
               autoInvite:completeAdd(self,playerName);
               id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
               AutoInviteCompleteList[id]["inGroup"]=true;
            end
            autoInvite.control.member[playerName]["status"]="ignored";
            autoInvite:chatMsg(format(AUTO_INVITE_PLAYER_IGNORES_YOU,playerName));
            autoInvite:buildGroups();
         elseif (string.find(arg1,AUTO_INVITE_IS_ALREADY_IN_GROUP)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_IS_ALREADY_IN_GROUP matched!");
            local dummy,dummy,playerName=string.find(arg1,AUTO_INVITE_IS_ALREADY_IN_GROUP_FIND);
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
            if(id==0) then
               -- player is not in complete list, add him
               autoInvite:completeAdd(self,playerName);
               id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
               -- @bug attempt to index field '?' (a nil value)
               AutoInviteCompleteList[id]["inGroup"]=true;
            end
            -- check if player is in our group
            if(autoInvite:playerIsInGroup(playerName)) then
               autoInvite.control.member[playerName]["status"]="joined";
            else
               autoInvite.control.member[playerName]["status"]="grouped";
               autoInvite:chatMsg(format(AUTO_INVITE_PLAYER_IS_ALREADY_IN_GROUP,playerName));
               if(AutoInviteConfig['ifWisper']==1) then
                  SendChatMessage(AUTO_INVITE_SEND_MESSAGE_ALREADY_IN_GROUP, "WHISPER", self.language, playerName);
               end
            end
            autoInvite:buildGroups();
         elseif (string.find(arg1,AUTO_INVITE_INVITED)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_INVITE_INVITED matched!");
            local dummy,dummy,playerName=string.find(arg1,AUTO_INVITE_INVITED_FIND);
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
            if(id==0) then
               -- player is not in complete list, add him
               autoInvite:completeAdd(self,playerName);
               id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
               if(id<=0) then
                  autoInvite:chatMsg(format(AUTO_INVITE_ERROR_ADDING_PLAYER_CONTACT_AUTHOR,playerName)); -- and send the file
                  return;
               end
               AutoInviteCompleteList[id]["inGroup"]=true;
            end
            autoInvite.control.member[playerName]["status"]="invited";
            autoInvite:debugMsg("User: "..playerName.." invited to group");
            autoInvite:buildGroups();
         elseif (string.find(arg1,AUTO_INVITE_GROUP_LEAVE)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_GROUP_LEAVE matched!");
            local dummy,dummy,playerName=string.find(arg1,AUTO_INVITE_GROUP_LEAVE_FIND);
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
            if(id==0) then
               -- player is not in complete list, add him
               autoInvite:completeAdd(self,playerName);
               id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
               -- @bug Error message attempt to index field '?' (a nil value)
               AutoInviteCompleteList[id]["inGroup"]=true;
            end
            autoInvite.control.member[playerName]["status"]="unknown";
            autoInvite:chatMsg(format(AUTO_INVITE_PLAYER_LEFT_THE_GROUP,playerName));
            autoInvite:buildGroups();
         elseif (string.find(arg1,AUTO_INVITE_RAID_LEAVE)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_RAID_LEAVE matched!");
            local dummy,dummy,playerName=string.find(arg1,AUTO_INVITE_RAID_LEAVE_FIND);
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
            if(id==0) then
               -- player is not in complete list, add him
               autoInvite:completeAdd(self,playerName);
               id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
               AutoInviteCompleteList[id]["inGroup"]=true;
            end
            autoInvite.control.member[playerName]["status"]="unknown";
            autoInvite:chatMsg(format(AUTO_INVITE_PLAYER_LEFT_THE_RAID,playerName));
            autoInvite:buildGroups();
         elseif (string.find(arg1,AUTO_INVITE_IS_OFFLINE)) then
            autoInvite:debugMsg("In OnEvent: AUTO_INVITE_IS_OFFLINE matched!");
            -- do something when he is offline
            local _,_,playerName=string.find(arg1,AUTO_INVITE_IS_OFFLINE_FIND);
            autoInvite:debugMsg("Player is: "..playerName);
            local id=autoInvite:getId(AutoInviteCompleteList,playerName, nil);
            autoInvite.control.member[playerName]["status"]="offline";
         elseif (string.find(arg1,AUTO_INVITE_GROUP_DISBANDED) or string.find(arg1,AUTO_INVITE_GROUP_DISBANDED2) or string.find(arg1,AUTO_INVITE_RAID_DISBANDED)) then
            -- reset the status of all known members - better safe then sorry
            for name in pairs(autoInvite.control.member) do
               autoInvite.control.member[name]["status"]="unknown";
            end
            autoInvite:debugMsg("Group or Raid was dispanded");
            --      autoInviteBuildGroups();
         elseif (event == "PLAYER_LEAVING_WORLD") then
            autoInvite:unregisterEvents(self);
         elseif (event == "PLAYER_ENTERING_WORLD") then
            autoInvite:registerEvents(self);
         end
         -- update the complete list
         autoInvite:buildGroups();
         autoInvite:completeList_Update();
         autoInvite:updateGroupCount();
      end
   end
end

function autoInvite:dropDownCLASS_OnLoad(self)
   autoInvite:debugMsg(self:GetName().." dropDownClass_OnLoad "..self:GetID());
   UIDropDownMenu_Initialize(self, autoInvite.dropDownCLASS_Init, "MENU");
end

function autoInvite:dropDownCLASS_Init()
   autoInvite:debugMsg("Init class dropdown. "..self:GetName().." dropDownClass_Init "..self:GetID());
   local id=self:GetID();
   autoInvite:debugMsg("Set Callback for ID: " .. id.." Name "..self:GetName());
   info = UIDropDownMenu_CreateInfo();
   info.text = AUTO_INVITE_TO_GROUP;
   info.isTitle = 1;
   info.justifyH = "CENTER";
   info.notCheckable=1;
   UIDropDownMenu_AddButton(info);

   info = UIDropDownMenu_CreateInfo();
   info.text = "-";
   info.notCheckable=1;
   if(self:GetID()==0) then
      info.value = _G[self:GetName().."TextLabelName"]:GetText();
   end
   info.func = autoInvite.dropDownCLASS_OnClick;
   UIDropDownMenu_AddButton(info);

   local i=1;
   while(i<=8) do
      info = UIDropDownMenu_CreateInfo();
      info.text = i;
      info.notCheckable = 1;
      autoInvite:debugMsg("BASE: "..self:GetName().." ID: "..self:GetID());
      if(self:GetID()==0) then
         info.value = _G[self:GetName().."TextLabelName"]:GetText();
      end
      info.func = autoInvite.dropDownCLASS_OnClick;
      if(autoInvite.groupCountLimit[i]>=5) then
         info.text="Full";
         info.isTitle=1;
      end
      UIDropDownMenu_AddButton(info);
      i=i+1;
   end
end

function autoInvite:dropDownCLASS_OnClick()
   autoInvite:debugMsg("Clicked "..self:GetName().." id: "..self:GetID().." group "..self.value);
   -- split the received value into userName and realmName
   local userName, realmName;
   userName, realmName=autoInvite:splitNameRealm(self.value);

   local id=autoInvite:getId(AutoInviteCompleteList, userName, realmName);

   if(id==0) then
      autoInvite:chatMsg("User not found clicked on, break here");
      return;
   end
   autoInvite:debugMsg("ID: "..id);
   if(self:GetID()==2) then
      AutoInviteCompleteList[id]["group"]="-";
   else
      AutoInviteCompleteList[id]["group"]=self:GetID()-2;
   end
   autoInvite:updateGroupCount();
   autoInvite:buildGroups();
end

-- Count who much player are in each group
function autoInvite:updateGroupCount()
   autoInvite:debugMsg("in function autoInvite:updateGroupCount()");
   local max=table.getn(AutoInviteCompleteList);
   local i=1;
   autoInvite:debugMsg("Count group members");
   autoInvite.groupCountLimit[1] = 0;
   autoInvite.groupCountLimit[2] = 0;
   autoInvite.groupCountLimit[3] = 0;
   autoInvite.groupCountLimit[4] = 0;
   autoInvite.groupCountLimit[5] = 0;
   autoInvite.groupCountLimit[6] = 0;
   autoInvite.groupCountLimit[7] = 0;
   autoInvite.groupCountLimit[8] = 0;
   while i<= max do
      if(AutoInviteCompleteList[i]["group"]~="-") then
         --   autoInvite:debugMsg("List: "..AutoInviteCompleteList[i]["group"]);
         autoInvite.groupCountLimit[AutoInviteCompleteList[i]["group"]]=autoInvite.groupCountLimit[AutoInviteCompleteList[i]["group"]]+1;
      end
      i=i+1;
   end
end

function autoInvite:onDragStart()
   autoInviteMainConfigFrame:StartMoving();
end

function autoInvite:onDragStop()
   autoInviteMainConfigFrame:StopMovingOrSizing();
end

-- displayes the given message on the screen
function autoInvite:chatMsg(msg)
   if( DEFAULT_CHAT_FRAME ) then
      DEFAULT_CHAT_FRAME:AddMessage(string.format("|cff00ff00AI: |cffff0000 %s",msg));
   end
   if(autoInvite.saveChatMsg) then
      table.insert(AutoInviteChatLog, msg);
   end
   --   ChatFrame1:AddMessage(msg,1.0,1.0,0.0);
   --   UIErrorsFrame:AddMessage(msg, 0.0, 0.0, 1.0, 1.0, UIERRORS_HOLD_TIME);
   --    GameTooltip:AddLine(msg, 0, 0, 1);
   --    GameTooltip:Show();
   --   UIErrorsFrame:AddMessage(string.format("|cff00ff00AI: |cffff0000 %s",msg), 0,0,0,0,UIERRORS_HOLD_TIME);
end

-- displayes messages if debug==true
function autoInvite:debugMsg(msg)
   if(AutoInviteDebugOn) then
      autoInvite:chatMsg(msg);
   end
end

-- toggle the main window
function autoInvite:showConfigFrame()
   if(autoInviteMainConfigFrame:IsVisible()) then
      autoInviteMainConfigFrame:Hide();
   else
      autoInviteMainConfigFrame:Show();
      autoInvite:countMembersInGroup();
   end
end   

-- the function is called if the user enter /ai <command>
function autoInvite:command(self, msg)
   autoInvite:debugMsg("in autoInvite:command Command: "..msg);
   if (msg=="show") then 
      autoInvite:showConfigFrame();
   elseif (msg=="add") then 
      autoInvite:debugMsg("Playername to add: "..autoInvite:getUnitName("target")); 
      if(autoInvite:getUnitName("target")) then
         autoInvite:completeAdd(self,autoInvite:getUnitName("target"));
         autoInvite:completeList_Update(self);
      else
         autoInvite:chatMsg(AUTO_INVITE_NO_TARGET_SELECTED_SKIPPING);
      end
   elseif (msg=="debug") then
      autoInvite:chatMsg(AUTO_INVITE_DEBUG_CALLED);
      autoInvite:dumpVariables();
   elseif (msg=="dump") then
      autoInvite:chatMsg(AUTO_INVITE_DUMP_CALLED);
      autoInvite:saveDebug();
   elseif (msg=="cleardump") then
      autoInvite:chatMsg(AUTO_INVITE_CLEAR_DUMP_CALLED);
      autoInvite:clearDebug();
   elseif (msg=="guild") then
      autoInvite:chatMsg(AUTO_INVITE_IMPORT_GUILD_MEMBERS);
      autoInvite:importGuildMembers();
   elseif (msg=="verbose") then
      if(AutoInviteDebugOn) then
         AutoInviteDebugOn=false;
         autoInvite.saveChatMsg=false;   
         autoInvite:chatMsg(AUTO_INVITE_VERBOSE_MOD_DEACTIVE);
      else
         AutoInviteDebugOn=true;
         autoInvite.saveChatMsg=true;   
         autoInvite:chatMsg(AUTO_INVITE_VERBOSE_MOD_ACTIVE);
      end
   elseif (msg=="reset") then
      autoInvite:reset(self);
   else
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP1);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP2);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP3);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP4);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP5);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP6);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP7);
      autoInvite:chatMsg(AUTO_INVITE_COMMAND_HELP8);
   end
end

-- Add the playerName to the completelist
function autoInvite:completeAdd(self,playerRealmName,class)
   autoInvite:debugMsg("In function autoInvite:completeAdd("..playerRealmName..")");
   --   autoInvite:chatMsg("Adding the target to the complete List");
   -- If playername is defined, add playername to list else add target to list
   if(playerRealmName and playerRealmName~="") then
      autoInvite:debugMsg("Add Player: -"..playerRealmName.."-");
      if(playerRealmName == AUTO_INVITE_UNKNOWN_ENTITY) then
         autoInvite:chatMsg(AUTO_INVITE_GOT_UNKOWN_SKIPPING);
         return;
      end
      -- split the playerRealmName into playerName and realmName
      local userName, realmName;
      userName, realmName=autoInvite:splitNameRealm(playerRealmName);

      --      autoInvite:chatMsg("Unit exists");
      if(UnitIsPlayer("target") and string.lower(autoInvite:getUnitName("target"))==string.lower(userName) and string.lower(autoInvite:getRealmName("target"))==string.lower(realmName)) then
         -- autoInvite:chatMsg("Unit is player");
         for _, pname in pairs(AutoInviteCompleteList) do
            if(userName == pname["name"] and realmName == pname["realm"]) then
               autoInvite:debugMsg("Selected Player "..name.."-"..realmName.." is in list, skipping");
               return;
            end
         end
         local class,eClass=UnitClass("target");
         local level=UnitLevel("target");
         autoInvite:chatMsg(format(AUTO_INVITE_ADD_PLAYER_XXX_TO_LIST,name,level,class));
         table.insert(AutoInviteCompleteList,{ ["group"]='-', ["name"]=userName, ["realm"]=realmName, ["level"]=level, ["eClass"]=eClass, ["inGroup"]=false });
         autoInvite.control.member[name] = { lastChecked = 0, status = "unknown", online = false, inGuild=false, errorMessage="", show=true };
      else
         -- Not possible because blizzard not allows to read this in big distance
         --  if(UnitIsPlayer("target")) then
         for _, pname in pairs(AutoInviteCompleteList) do
            if(string.lower(userName) == string.lower(pname["name"]) and string.lower(realmName) == string.lower(pname["realm"])) then
               autoInvite:chatMsg(format(AUTO_INVITE_PLAYER_ALREADY_IN_LIST, userName.."-"..realmName));
               return;
            end
         end
         if(playerRealmName == AUTO_INVITE_UNKNOWN_ENTITY) then
            autoInvite:chatMsg(AUTO_INVITE_GOT_UNKOWN_SKIPPING);
            return;
         end
         if(class and class ~="") then
            local level=0;
            autoInvite:chatMsg(format(AUTO_INVITE_ADD_PLAYER_XXX_TO_LIST,playerRealmName,level,AUTO_INVITE_CLASS[class]));
            table.insert(AutoInviteCompleteList,{ ["group"]='-', ["name"]=userName, ["realm"]=realmName, ["level"]=0, ["eClass"]=class, ["inGroup"]=false });
         else
            autoInvite:chatMsg(format(AUTO_INVITE_ADD_PLAYER_NOT_IN_TARGET,playerRealmName));
            table.insert(AutoInviteCompleteList,{ ["group"]='-', ["name"]=userName, ["realm"]=realmName, ["level"]=0, ["eClass"]="DRUID", ["inGroup"]=false });
         end
         autoInvite.control.member[userName.."-"..realmName] = { lastChecked = 0, status = "unknown", online = false, inGuild=false, errorMessage="", show=true };
         --  end
      end
   end
   --   autoInvite:chatMsg("Number of items in list: "..table.getn(AutoInviteCompleteList));
   autoInvite:sortCompleteList();
   autoInvite:completeList_Update();
end

function autoInvite:sortCompleteList()
   autoInvite:debugMsg("In function autoInvite:sortCompleteList");
   autoInvite:debugMsg("check if sorting is enabled");
   if(AutoInviteConfig['sortComplete']==1) then
      autoInvite:debugMsg("Sort complete list");
      table.sort(AutoInviteCompleteList,
                 function (v1, v2)
                    return v1.name < v2.name
                 end
              );
   end
end

-- The Event which is called if in the list the user clicks with the mouse
function autoInvite:completeListClick(self,button,text)
   autoInvite:debugMsg("In function autoInvite:completeListeClick");
   local btnName=_G[self:GetName().."TextLabelName"];
   local btnRealm=_G[self:GetName().."TextLabelRealm"];
   local btnLevel=_G[self:GetName().."TextLabelLevel"];
   local btnClass=_G[self:GetName().."TextLabelClass"];
   local user=btnName:GetText();
   local realm=btnRealm:GetText();
   local idToRemove;
   local oldCount=table.getn(AutoInviteCompleteList);

   autoInvite:sortCompleteList();
   if(button == "LeftButton") then
      autoInvite:debugMsg("Left Click");
      local j,k=string.find(self:GetName(),"CompleteList");
      if(j) then
         -- Click was in Complete List
         if(user) then
            autoInvite:debugMsg("Left Click: "..user..'-'..realm);
            autoInvite:addToGroup(user, realm);
         end
      else
         if(user) then
            autoInvite:removeFromGroup(user, realm);
            -- close all dropdown menus
            CloseDropDownMenus(1, nil, autoInviteDropDownDRUID);
            CloseDropDownMenus(1, nil, autoInviteDropDownHUNTER);
            CloseDropDownMenus(1, nil, autoInviteDropDownMAGE);
            CloseDropDownMenus(1, nil, autoInviteDropDownPALADIN);
            CloseDropDownMenus(1, nil, autoInviteDropDownPRIEST);
            CloseDropDownMenus(1, nil, autoInviteDropDownROGUE);
            CloseDropDownMenus(1, nil, autoInviteDropDownWARRIOR);
            CloseDropDownMenus(1, nil, autoInviteDropDownWARLOCK);
            CloseDropDownMenus(1, nil, autoInviteDropDownDEATHKNIGHT);
            CloseDropDownMenus(1, nil, autoInviteDropDownMONK);
         end
      end

   elseif (button == "RightButton") then
      autoInvite:debugMsg("Right Click");
      local j,k=string.find(self:GetName(),"CompleteList");
      if(j) then
         -- Click was in Complete List
         if(user and AutoInviteConfig['lockComplete']==0) then
            autoInvite:chatMsg("Remove player "..user.." from complete list");
            idToRemove=autoInvite:getId(AutoInviteCompleteList, user, realm);
            autoInvite.control.member[user]=nil;
            table.remove(AutoInviteCompleteList,idToRemove);
            autoInvite:completeList_Update(oldCount);
         end
      else
         if(user) then
            local id=autoInvite:getId(AutoInviteCompleteList, user, realm);
            autoInvite:debugMsg("User: "..id);
            autoInvite:debugMsg("User-class: "..AutoInviteCompleteList[id]["eClass"]);
            if(AutoInviteCompleteList[id]["eClass"]=="DRUID") then
               autoInviteDropDownDRUID.relativeTo="autoInviteMainConfigFrameDRUIDListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownDRUID,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="HUNTER") then
               autoInviteDropDownHUNTER.relativeTo="autoInviteMainConfigFrameHUNTERListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownHUNTER,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="MAGE") then
               autoInviteDropDownMAGE.relativeTo="autoInviteMainConfigFrameMAGEListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownMAGE,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="PALADIN") then
               autoInviteDropDownPALADIN.relativeTo="autoInviteMainConfigFramePALADINListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownPALADIN,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="SHAMAN") then
               autoInviteDropDownSHAMAN.relativeTo="autoInviteMainConfigFrameSHAMANListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownSHAMAN,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="PRIEST") then
               autoInviteDropDownPRIEST.relativeTo="autoInviteMainConfigFramePRIESTListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownPRIEST,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="ROGUE") then
               autoInviteDropDownROGUE.relativeTo="autoInviteMainConfigFrameROGUEListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownROGUE,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="WARRIOR") then
               autoInviteDropDownWARRIOR.relativeTo="autoInviteMainConfigFrameWARRIORListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownWARRIOR,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="WARLOCK") then
               autoInviteDropDownWARLOCK.relativeTo="autoInviteMainConfigFrameWARLOCKListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownWARLOCK,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="DEATHKNIGHT") then
               autoInviteDropDownDEATHKNIGHT.relativeTo="autoInviteMainConfigFrameDEATHKNIGHTListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownDEATHKNIGHT,self);
            elseif (AutoInviteCompleteList[id]["eClass"]=="MONK") then
               autoInviteDropDownDEATHKNIGHT.relativeTo="autoInviteMainConfigFrameMONKListSlot01";
               ToggleDropDownMenu(1, nil, autoInviteDropDownMONK,self);
            end
         end
      end
      
   elseif (button == "MiddleButton") then
      autoInvite:debugMsg("MiddleClick");
   end
end

-- Update the complete list
function autoInvite:completeList_Update(oldCount)
   autoInvite:debugMsg("In function autoInvite:completeList_Update");
   local baseName = "autoInviteMainConfigFrameCompleteList";
   local maxCount=table.getn(AutoInviteCompleteList);
   local maxDisplay=20;
   local i=0;
   local index=0;
   local id="";
   local offset=0;
   autoInvite:countMembersInGroup();
   local scrollOffset=FauxScrollFrame_GetOffset(autoInviteMainConfigFrameCompleteListScrollFrame);
   local displayNames={};
   local j=0;

   --   autoInvite:chatMsg("Create list to display");
   for i=1, maxCount do
      --      autoInvite:chatMsg("Check player: "..AutoInviteCompleteList[i]["name"]);
      if(AutoInviteCompleteList[i]["inGroup"]==false and autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["show"]==true) then
         --  autoInvite:chatMsg("Display player: "..AutoInviteCompleteList[i]["name"]);
         j=j+1;
         displayNames[j]={};
         displayNames[j]["name"]=AutoInviteCompleteList[i]["name"];
         displayNames[j]["realm"]=AutoInviteCompleteList[i]["realm"];
         displayNames[j]["level"]=AutoInviteCompleteList[i]["level"];
         displayNames[j]["eClass"]=AutoInviteCompleteList[i]["eClass"];
      end
   end
   --   autoInvite:chatMsg("ScrollOffset: "..scrollOffset);

   --   autoInvite:chatMsg("Display the created list");
   for i=1, maxDisplay do
      local linePlusOffset=i+scrollOffset;
      id=i;
      if(i<10) then
         id="0"..i;
      end
      if(displayNames[linePlusOffset]) then
         autoInvite:debugMsg("Display: "..displayNames[linePlusOffset]["name"]);
         autoInvite:debugMsg("DisplayRealm: "..displayNames[linePlusOffset]["realm"]);
      end
      -- autoInvite:debugMsg("Id: "..id);
      if(linePlusOffset <= maxCount and displayNames[linePlusOffset]) then
         autoInvite:debugMsg("Display: "..displayNames[linePlusOffset]["name"]);
         _G[baseName.."Slot"..id.."TextLabelName"]:SetText(displayNames[linePlusOffset]["name"]);
         _G[baseName.."Slot"..id.."TextLabelRealm"]:SetText(displayNames[linePlusOffset]["realm"]);
         _G[baseName.."Slot"..id.."TextLabelLevel"]:SetText(displayNames[linePlusOffset]["level"]);
         _G[baseName.."Slot"..id.."TextLabelClass"]:SetText(AUTO_INVITE_CLASS[displayNames[linePlusOffset]["eClass"]]);
         _G[baseName.."Slot"..id.."TextLabelBackground"]:Hide();
         if(autoInvite.control['member'][displayNames[linePlusOffset]["name"]..'-'..displayNames[linePlusOffset]["realm"]]['online']) then
            _G[baseName.."Slot"..id.."TextLabelName"]:SetVertexColor(autoInvite.greenColor.r, autoInvite.greenColor.g, autoInvite.greenColor.b);
            _G[baseName.."Slot"..id.."TextLabelLevel"]:SetVertexColor (autoInvite.greenColor.r, autoInvite.greenColor.g, autoInvite.greenColor.b);
            _G[baseName.."Slot"..id.."TextLabelClass"]:SetVertexColor(autoInvite.greenColor.r, autoInvite.greenColor.g, autoInvite.greenColor.b);
         else
            _G[baseName.."Slot"..id.."TextLabelName"]:SetVertexColor (NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
            _G[baseName.."Slot"..id.."TextLabelLevel"]:SetVertexColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
            _G[baseName.."Slot"..id.."TextLabelClass"]:SetVertexColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
         end
      else
         --  autoInvite:chatMsg("Empty");
         _G[baseName.."Slot"..id.."TextLabelName"]:SetText("");
         _G[baseName.."Slot"..id.."TextLabelRealm"]:SetText("");
         _G[baseName.."Slot"..id.."TextLabelLevel"]:SetText("");
         _G[baseName.."Slot"..id.."TextLabelClass"]:SetText("");
         _G[baseName.."Slot"..id.."TextLabelBackground"]:Show();

         _G[baseName.."Slot"..id.."TextLabelName"]:SetVertexColor (NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
         _G[baseName.."Slot"..id.."TextLabelLevel"]:SetVertexColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
         _G[baseName.."Slot"..id.."TextLabelClass"]:SetVertexColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
      end
   end
end

-- return the internal id, search string is the userName
function autoInvite:getId(searchStr, user, realm)
   local i;
   autoInvite:debugMsg("User: "..user.." Realm: "..realm);

   for i=1, table.getn(searchStr) do
      autoInvite:debugMsg(i..": Compare: "..user.." Realm: "..realm.." with: "..searchStr[i]["name"].." Realm: "..searchStr[i]['realm']);
      -- handle the case the realm parameter was given in function call
      if(user==searchStr[i]['name'] and realm==searchStr[i]['realm']) then
         autoInvite:debugMsg("found: "..i);
         return i;
      end
   end
   return 0;
end

-- Add the user to the raid/group list and refreshes the window
function autoInvite:addToGroup(user, realm)
   local userId=autoInvite:getId(AutoInviteCompleteList, user, realm);
   AutoInviteCompleteList[userId]["inGroup"]=true;
   autoInvite:buildGroups();
   autoInvite:completeList_Update();
   --   autoInvite:chatMsg("Base: "..baseName);
end

-- Remove the user from the raid/group list and refreshes the window
function autoInvite:removeFromGroup(user, realm)
   autoInvite:debugMsg("In function autoInvite:removeFromGroup("..user..")");
   local userId=autoInvite:getId(AutoInviteCompleteList,user, realm);
   AutoInviteCompleteList[userId]["inGroup"]=false;
   -- should we really delete the current saved group?
   AutoInviteCompleteList[userId]["group"]="-";
   autoInvite.control.member[user..'-'..realm]["status"]="unknown";
   -- if removed player is in group, maybe remove him XXXX

   autoInvite:buildGroups();
   autoInvite:completeList_Update();
   autoInvite:updateGroupCount();
end

-- Refresh the raid/group list on the window
function autoInvite:buildGroups()
   autoInvite:debugMsg("In function autoInvite:buildGroups()");
   local max=table.getn(AutoInviteCompleteList);
   local i=0;
   local v=0;
   local class;

   -- Clear all buttons in the raid/group list
   --   autoInvite:chatMsg("Try to clean the Buttons");
   for i,v in pairs(autoInvite.groupCount) do
      if(v~=0) then
         local baseName="autoInviteMainConfigFrame";
         class=i;
         local lBaseName=baseName..class.."List";
         -- autoInvite:chatMsg("i: "..i.." v: "..v);
         for j=1,v do
            local id=""..j;
            if(j<10) then
               id="0"..j;
            end
            if(j<=10) then
               local btnGroup = _G[lBaseName.."Slot"..id.."TextLabelGroup"];
               local btnName =  _G[lBaseName.."Slot"..id.."TextLabelName"];
               local btnRealm =  _G[lBaseName.."Slot"..id.."TextLabelRealm"];
               local btnLevel = _G[lBaseName.."Slot"..id.."TextLabelLevel"];
               local btnBack =  _G[lBaseName.."Slot"..id.."TextLabelBackground"];
               --               staticDebugMg("In function autoInviteBuildGroups()");
               --               autoInvite:chatMsg(lBaseName.."Slot"..id.."TextLabelName");
               btnGroup:SetText("");
               btnName:SetText("");
               btnRealm:SetText("");
               btnLevel:SetText("");
               btnBack:Show();
            end
         end
      end
   end

   autoInvite.groupCount["DRUID"]=0;
   autoInvite.groupCount["HUNTER"]=0;
   autoInvite.groupCount["MAGE"]=0;
   autoInvite.groupCount["PALADIN"]=0;
   autoInvite.groupCount["PRIEST"]=0;
   autoInvite.groupCount["ROGUE"]=0;
   autoInvite.groupCount["WARRIOR"]=0;
   autoInvite.groupCount["WARLOCK"]=0;
   autoInvite.groupCount["SHAMAN"]=0;
   autoInvite.groupCount["DEATHKNIGHT"]=0;
   autoInvite.groupCount["MONK"]=0;
   _G["autoInviteMainConfigFrameDRUIDListLabel"]:SetText(AUTO_INVITE_CLASS["DRUID"].." (0)");
   _G["autoInviteMainConfigFrameHUNTERListLabel"]:SetText(AUTO_INVITE_CLASS["HUNTER"].." (0)");
   _G["autoInviteMainConfigFrameMAGEListLabel"]:SetText(AUTO_INVITE_CLASS["MAGE"].." (0)");
   _G["autoInviteMainConfigFramePALADINListLabel"]:SetText(AUTO_INVITE_CLASS["PALADIN"].." (0)");
   _G["autoInviteMainConfigFrameSHAMANListLabel"]:SetText(AUTO_INVITE_CLASS["SHAMAN"].." (0)");
   _G["autoInviteMainConfigFramePRIESTListLabel"]:SetText(AUTO_INVITE_CLASS["PRIEST"].." (0)");
   _G["autoInviteMainConfigFrameROGUEListLabel"]:SetText(AUTO_INVITE_CLASS["ROGUE"].." (0)");
   _G["autoInviteMainConfigFrameWARRIORListLabel"]:SetText(AUTO_INVITE_CLASS["WARRIOR"].." (0)");
   _G["autoInviteMainConfigFrameWARLOCKListLabel"]:SetText(AUTO_INVITE_CLASS["WARLOCK"].." (0)");
   _G["autoInviteMainConfigFrameDEATHKNIGHTListLabel"]:SetText(AUTO_INVITE_CLASS["DEATHKNIGHT"].." (0)");
   _G["autoInviteMainConfigFrameMONKListLabel"]:SetText(AUTO_INVITE_CLASS["MONK"].." (0)");

   for i=1, max do
      if(AutoInviteCompleteList[i]["inGroup"]==true) then
         local baseName="autoInviteMainConfigFrame";
         --         autoInvite:chatMsg("Group-Insert: "..AutoInviteCompleteList[i]["name"]);
         if(not AutoInviteCompleteList[i]["eClass"])then
            autoInvite:chatMsg(format(AUTO_INVITE_NO_INFO_AVAILABLE_MOVE_DRUIDE,AutoInviteCompleteList[i]["name"]));
            AutoInviteCompleteList[i]["eClass"]="DRUID";
         end
         --         autoInvite:chatMsg("Debug: "..AutoInviteCompleteList[i]["eClass"]);
         local eClass=AutoInviteCompleteList[i]["eClass"];
         baseName=baseName..eClass.."List";
         --         autoInvite:chatMsg("eClass: "..eClass);
         autoInvite.groupCount[eClass]=autoInvite.groupCount[eClass]+1;
         local id=""..autoInvite.groupCount[eClass];
         if(autoInvite.groupCount[eClass]<10) then
            id="0"..autoInvite.groupCount[eClass];
         end
         -- Update Count for each group
         _G[baseName.."Label"]:SetText(AUTO_INVITE_CLASS[eClass].." ("..autoInvite.groupCount[eClass]..")");

         if(autoInvite.groupCount[eClass]<=10) then
            local btnGroup = _G[baseName.."Slot"..id.."TextLabelGroup"];
            local btnName =  _G[baseName.."Slot"..id.."TextLabelName"];
            local btnRealm =  _G[baseName.."Slot"..id.."TextLabelRealm"];
            local btnLevel = _G[baseName.."Slot"..id.."TextLabelLevel"];
            local btnBack =  _G[baseName.."Slot"..id.."TextLabelBackground"];
            --   autoInvite:chatMsg(baseName.."Slot"..id.."TextLabelName");
            if(AutoInviteCompleteList[i]["group"]==nil) then
               autoInvite:debugMsg("Add key to array");
               AutoInviteCompleteList[i]["group"]='-';
            end
            btnGroup:SetText(AutoInviteCompleteList[i]["group"]);
            btnName:SetText(AutoInviteCompleteList[i]["name"]);
            btnRealm:SetText(AutoInviteCompleteList[i]["realm"]);
            btnLevel:SetText(AutoInviteCompleteList[i]["level"]);
            --   btnName:SetVertexColor(color.r, color.g, color.b);
            if(autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]==nil) then
               autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]="unknown";
            end
            if(autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="invited") then
               -- is invited set color to yellow
               btnGroup:SetVertexColor(autoInvite.yellowColor.r, autoInvite.yellowColor.g, autoInvite.yellowColor.b);
               btnName:SetVertexColor(autoInvite.yellowColor.r, autoInvite.yellowColor.g, autoInvite.yellowColor.b);
               btnLevel:SetVertexColor(autoInvite.yellowColor.r, autoInvite.yellowColor.g, autoInvite.yellowColor.b);
            elseif (autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="unknown") then
               -- not invited set color to grey
               btnGroup:SetVertexColor(autoInvite.greyColor.r, autoInvite.greyColor.g, autoInvite.greyColor.b);
               btnName:SetVertexColor(autoInvite.greyColor.r, autoInvite.greyColor.g, autoInvite.greyColor.b);
               btnLevel:SetVertexColor(autoInvite.greyColor.r, autoInvite.greyColor.g, autoInvite.greyColor.b);
            elseif (autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="joined") then
               -- joined the group set color to green
               btnGroup:SetVertexColor(autoInvite.greenColor.r, autoInvite.greenColor.g, autoInvite.greenColor.b);
               btnName:SetVertexColor (autoInvite.greenColor.r, autoInvite.greenColor.g, autoInvite.greenColor.b);
               btnLevel:SetVertexColor(autoInvite.greenColor.r, autoInvite.greenColor.g, autoInvite.greenColor.b);
            elseif (autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="ignored"
                    or autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="declined"
                       or autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="offline") then
               -- will not join the group set color to red
               btnGroup:SetVertexColor(autoInvite.redColor.r, autoInvite.redColor.g, autoInvite.redColor.b);
               btnName:SetVertexColor (autoInvite.redColor.r, autoInvite.redColor.g, autoInvite.redColor.b);
               btnLevel:SetVertexColor(autoInvite.redColor.r, autoInvite.redColor.g, autoInvite.redColor.b);
            elseif (autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="grouped") then
               -- is allready in group set color to blue
               btnGroup:SetVertexColor(autoInvite.blueColor.r, autoInvite.blueColor.g, autoInvite.blueColor.b);
               btnName:SetVertexColor(autoInvite.blueColor.r, autoInvite.blueColor.g, autoInvite.blueColor.b);
               btnLevel:SetVertexColor(autoInvite.blueColor.r, autoInvite.blueColor.g, autoInvite.blueColor.b);
            end
            btnBack:Hide();
         end
      end
   end
   autoInvite:countMembersInGroup();
end

-- invite the people, which are in the list
function autoInvite:invite(self)
   autoInvite:debugMsg("In function autoInvite:invite()");
   -- activate the mod
   autoInvite:activate();
   local max=table.getn(AutoInviteCompleteList);
   local i;
   --local id=autoInviteGetId(AutoInviteCompleteList,autoInvite:getUnitName("player"));
   if(autoInvite:getId(AutoInviteCompleteList,autoInvite:getUnitName("player"),autoInvite:getRealmName("player"))==0) then
      --      autoInvite:chatMsg("Player is not in complete list");
      autoInvite:completeAdd(self,autoInvite:getUnitName("player"));
   end
   autoInvite:addToGroup(autoInvite:getUnitName("player"), autoInvite:getRealmName("player"));
   
   for i=1, max do
      if(AutoInviteCompleteList[i]["inGroup"]==true) then
         --  autoInvite:chatMsg("Invite "..AutoInviteCompleteList[i]['name']);
         if(autoInvite:getUnitName("player")==AutoInviteCompleteList[i]['name']) then
            --            autoInvite:chatMsg("Invite myself");
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['status']="joined";
            autoInvite:buildGroups();
         elseif (autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['status']=="joined") then
            --            autoInvite:chatMsg("Player "..AutoInviteCompleteList[i]['name'].." already in group, dont invite him or her");
         else
            if(AutoInviteConfig['oldVersion'])then
               InviteByName(AutoInviteCompleteList[i]['name']);
            else
               InviteUnit(AutoInviteCompleteList[i]['name']);
            end
         end
      end
   end
end

-- Event which is triggered if a member leaves or joins the group
function autoInvite:memberJoinedParty(self)
   autoInvite:debugMsg("In function autoInvite:memberJoinedParty()");
   local memberCount=GetNumGroupMembers();
   local i, name, realm;

   for i=0, memberCount do
      -- autoInvite:chatMsg("Count: "..i.." from "..memberCount);
      if(i==0) then
         name=autoInvite:getUnitName("player");
         realm=autoInvite:getRealmName("player");
      else
         name=autoInvite:getUnitName("party"..i);
         realm=autoInvite:getRealmName("player");
      end
      if(name and realm) then
         -- autoInvite:chatMsg("Member "..name..", Realm " .. realm .. " joined");
         local id=autoInvite:getId(AutoInviteCompleteList, name, realm);
         if(id==0) then
            -- player is not in complete list, add him
            autoInvite:debugMsg("Player "..name.." has no ID, create it");
            autoInvite:completeAdd(self, name.."-"..realm);
            id=autoInvite:getId(AutoInviteCompleteList, name, realm);
         end
         if(id~=0) then
            autoInvite.control.member[AutoInviteCompleteList[id]['name']..'-'..AutoInviteCompleteList[id]['realm']]["status"]="joined";
            AutoInviteCompleteList[id]["inGroup"]=true;
            autoInvite:debugMsg("Level: "..AutoInviteCompleteList[id]["level"].." name: "..AutoInviteCompleteList[id]["name"].." name2: "..name);
            --   if(AutoInviteCompleteList[id]["level"]==0) then
            --      autoInvite:chatMsg("Read player information");
            local class,eClass,level;
            if(i==0) then
               class,eClass=UnitClass("player");
               level=UnitLevel("player");
            else
               class,eClass=UnitClass("party"..i);
               level=UnitLevel("party"..i);
            end
            --      autoInvite:chatMsg("Read class: "..class.." eClass: "..eClass);
            --      autoInvite:chatMsg("Readed level: "..level);
            -- always read player information   
            if(level~=0) then
               --            if(level>AutoInviteCompleteList[id]["level"]) then
               AutoInviteCompleteList[id]["level"]=level;
            end
            AutoInviteCompleteList[id]["eClass"]=eClass;
            --   end
            --   end
         end
      end
   end
   autoInvite:buildGroups();
end

-- Event which is called if a member joins or leaves the raid
function autoInvite:memberJoinedRaid(self)
end

-- count how much players are in the raid group, how much are really invited and statistic for each group
function autoInvite:countMembersInGroup()
   autoInvite:debugMsg("In function autoInvite:countMembersInGroup()");
   local complete=0;
   local completeInvited=0;
   local max=table.getn(AutoInviteCompleteList);
   local i;

   for i=1, max do
      if(AutoInviteCompleteList[i]["inGroup"]==true) then
         if(autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]=="joined") then
            completeInvited=completeInvited+1;
         end
         complete=complete+1;
      end
   end
   -- autoInvite:chatMsg("Corrent Count: "..complete.." invited: "..completeInvited);

   local textCompleteStatistic = _G["autoInviteMainConfigFramePlayerStatistic"];
   textCompleteStatistic:SetText(format(AUTO_INVITE_NUMBER_OF_PLAYERS,completeInvited,complete));
   -- Check if all players are invited and if yes, disable the invite process
   if(completeInvited>=complete and autoInvite.control.doInvites) then
      if(autoInvite.control.changeToRaid) then
         -- disable raid invite button
         autoInvite:chatMsg("Raid Invite complete, disable addon");
         autoInvite:inviteButton_OnClick(_G["autoInviteMainConfigFrameButtonInviteRaid"], "raid");
      else
         -- disable group invite button
         autoInvite:chatMsg("Group Invite complete, disable addon");
         autoInvite:inviteButton_OnClick(_G["autoInviteMainConfigFrameButtonInviteGroup"]);
      end
   end

   FauxScrollFrame_Update(autoInviteMainConfigFrameCompleteListScrollFrame, max-complete,20,20);
   _G["autoInviteMainConfigFrameCompleteListLabel"]:SetText(format(AUTO_INVITE_COMPLETELIST,max-complete));
   --   FauxScrollFrame_Update(autoInviteMainConfigFrameCompleteListScrollFrame, max-completeInvited-complete,20,20);
   --   _G["autoInviteMainConfigFrameCompleteListLabel"]:SetText(AUTO_INVITE_COMPLETELIST.."("..max-completeInvited-complete..")");
end

-- Read the current groupsetup and save it
function autoInvite:readGroupSetup()
   autoInvite:chatMsg(AUTO_INVITE_READ_GROUP_SETUP);
   -- check if in raid
   -- ??? dont know how to do it XXXX
   local i;
   local max=table.getn(AutoInviteCompleteList);
   for i=1, max do
      autoInvite:debugMsg("Reset member: "..i);
      AutoInviteCompleteList[i]["group"]="-";
   end
   
   -- maybe at first read members?
   local memberCount=GetNumGroupMembers();
   for i=1, memberCount do
      local name,rank,subgroup,level,class,eClass=GetRaidRosterInfo(i);
      if(name) then
         local id=autoInvite:getId(AutoInviteCompleteList,name, nil); -- @todo fix this
         if(level>=1 or level<=autoInvite.maxlevel) then
            if(not AutoInviteCompleteList[id]) then
               AutoInviteCompleteList[id]={};
            end
            AutoInviteCompleteList[id]["level"]=level;
            AutoInviteCompleteList[id]["eClass"]=eClass;
            AutoInviteCompleteList[id]["group"]=subgroup;
         end
      end
   end
   autoInvite:updateGroupCount();
   autoInvite:buildGroups();
   autoInvite:chatMsg(AUTO_INVITE_DONE);
end

-- the function IsRaidLeader() from Blizzard in version 1.12x is buggy, so use our own function
function autoInvite:checkIfRaidLeader()
   local count=GetNumGroupMembers();
   local i;
   -- check if we are in a raid
   if(count>0) then
      -- now search my raidID
      local myName=autoInvite:getUnitName("player");
      autoInvite:debugMsg("My name is: "..myName);
      for i=1, count do
         local name,rank,subgroup,level,class,eClass=GetRaidRosterInfo(i);
         if(name==myName) then
            if(rank==2) then
               autoInvite:debugMsg("I am the readleader");
               return true;
            else
               autoInvite:debugMsg("I am NOT the readleader");
               return false;
            end
         end
      end
   end
   return false;
end

-- set the saved group setup and move players in defined groups
function autoInvite:movePlayers(forceMove)
   autoInvite:debugMsg("In function autoInvite:movePlayers()");
   
   -- the game has problems with the function maybe 2 call can solve it
   if(not autoInvite:checkIfRaidLeader()) then
      if(not forceMove) then
         autoInvite:chatMsg(AUTO_INVITE_IM_NOT_THE_RAID_LEADER_SKIPPING);
         do return end;
      end
   end
   local memberCount=GetNumGroupMembers();
   local i, j;
   autoInvite.needMovePlayers=0;

   autoInvite:chatMsg(memberCount.." players are analysed");
   -- mark players, which need to be moved
   for i=1, memberCount do
      local name,rank,subgroup,level,class,eClass=GetRaidRosterInfo(i);
      if(name) then
         local id=autoInvite:getId(AutoInviteCompleteList,name, nil); -- @todo fix this
         if(AutoInviteCompleteList[id]["group"]=="-") then
            autoInvite:chatMsg(format(AUTO_INVITE_FOR_XXX_NO_GROUP_DEFINED,name));
            return;
         elseif (AutoInviteCompleteList[id]["group"]==subgroup) then
            autoInvite.control['member'][name]["needMove"]=false;
         else
            autoInvite.control['member'][name]["needMove"]=true;
            autoInvite.needMovePlayers=autoInvite.needMovePlayers+1;
            autoInvite:chatMsg("Player "..name.." is marked for moving");
         end
      end
   end
   autoInvite:chatMsg("Analyse done.");
   if(autoInvite.needMovePlayers>0) then
      autoInvite:chatMsg(AUTO_INVITE_START_TO_MOVE_PLAYERS);
      autoInvite.movePlayersActive=true;
      autoInvite:doMovePlayers();
   else
      autoInvite:chatMsg(AUTO_INVITE_MOVING_FINISHED);
      autoInvite.movePlayersActive=false;
   end
end

function autoInvite:doMovePlayers()
   autoInvite:debugMsg("In function autoInvite:doMovePlayers");
   local memberCount=GetNumGroupMembers();
   local i, j;

   if (autoInvite.needMovePlayers>1) then
      autoInvite:chatMsg("Starting to swap players...");
      -- swap players
      for i=1, memberCount do
         local name,rank,subgroup,level,class,eClass=GetRaidRosterInfo(i);
         if(name) then
            local id=autoInvite:getId(AutoInviteCompleteList,name, nil); -- @todo fix this
            if(autoInvite.control['member'][name]["needMove"]==true) then
               for j=1, memberCount do
                  local name2,rank2,subgroup2,level2,class2,eClass2=GetRaidRosterInfo(j);
                  if(name2) then
                     local id2=autoInvite:getId(AutoInviteCompleteList,name2, nil); -- @todo fix this
                     if(autoInvite.control['member'][name2]["needMove"]==true and AutoInviteCompleteList[id2]["group"]==subgroup) then
                        SwapRaidSubgroup(i,j);
                        autoInvite.control['member'][name2]["needMove"]=false;
                        autoInvite:debugMsg("Swap player "..name.." and "..name2);
                        autoInvite.needMovePlayers=autoInvite.needMovePlayers-1;
                        if(AutoInviteCompleteList[id]['group']==subgroup2) then
                           autoInvite:debugMsg("Both players are in correct group, reduce count");
                           autoInvite.control['member'][name]["needMove"]=false;
                           autoInvite.needMovePlayers=autoInvite.needMovePlayers-1;
                        end
                        autoInvite:debugMsg("Player swaped exit");
                        do return end;
                     end
                  end
               end
            end
         end
      end
      autoInvite:chatMsg("Finished Swap players");
   end

   autoInvite:chatMsg("Check if players need moving...");
   if (autoInvite.needMovePlayers>0) then
      autoInvite:chatMsg("Starting to move players...");
      -- check if needMove is left
      for i=1, memberCount do
         local name,rank,subgroup,level,class,eClass=GetRaidRosterInfo(i);
         if(name) then
            local id=autoInvite:getId(AutoInviteCompleteList,name, nil); -- @todo fix this
            if(autoInvite.control['member'][name]["needMove"]==true) then
               local countWishGroup=0;
               -- count wishgroup
               for j=1, memberCount do
                  local name2,rank2,subgroup2,level2,class2,eClass2=GetRaidRosterInfo(j);
                  local id2=autoInvite:getId(AutoInviteCompleteList,name2, nil); -- @todo fix this
                  if(AutoInviteCompleteList[id2]["group"]==subgroup) then
                     countWishGroup=countWishGroup+1;
                  end
               end
               if(countWishGroup<5) then
                  autoInvite:chatMsg("Move player "..name.." to group "..AutoInviteCompleteList[id]["group"]);
                  SetRaidSubgroup(i,AutoInviteCompleteList[id]["group"]);
                  autoInvite.control['member'][name]["needMove"]=false;
                  autoInvite.needMovePlayers=autoInvite.needMovePlayers-1;
                  do return end;
               else
                  autoInvite:chatMsg(format(AUTO_INVITE_CANNOT_MOVE_PLAYER_GROUP_IS_FULL,name));
               end
            end
         end
      end
      autoInvite:chatMsg("Finished moving players");
   end
   autoInvite.movePlayersActive=false;
   --   autoInvite:movePlayers();
end

function autoInvite:ifWisperOnLoad()
   local baseName="autoInviteMainConfigFrame";
   local btnWisper = _G[baseName.."CheckButtonWisper"];
   if(AutoInviteConfig['ifWisper']==1) then
      -- set check
      btnWisper:SetChecked(1);
   else
      -- remove check
      AutoInviteConfig['ifWisper']=0;
      btnWisper:SetChecked(0);
   end
end

function autoInvite:ifWisperOnClick()
   local baseName="autoInviteMainConfigFrame";
   local btnWisper = _G[baseName.."CheckButtonWisper"];
   local state=btnWisper:GetChecked();
   if(state == 1) then
      --      autoInvite:chatMsg("Button was not selected, select it now");
      AutoInviteConfig['ifWisper']=1;
      btnWisper:SetChecked(1);
   else
      --      autoInvite:chatMsg("Button was selected, unselect it now");
      AutoInviteConfig['ifWisper']=0;
      btnWisper:SetChecked(0);
   end
end

function autoInvite:loadSaveConfig()
   if(autoInviteLoadSaveFrame:IsVisible()) then
      autoInviteLoadSaveFrame:Hide();
   else
      autoInviteLoadSaveFrame:Show();
      autoInvite:loadSaveScrollBar_Update();
   end
end

function autoInvite:loadSaveScrollBar_Update()
   local i, index, item;
   local baseName="autoInviteLoadSaveFrame";
   local max=table.getn(AutoInviteSavedList);
   --   autoInvite:chatMsg("Max: "..max);
   -- function FauxScrollFrame_Update(frame, numItems, numToDisplay, valueStep, button, smallWidth, bigWidth, highlightFrame, smallHighlightWidth, bigHighlightWidth )
   FauxScrollFrame_Update(autoInviteLoadSaveScrollFrame, max,8,8);
   
   for i=1,8 do
      index = i + FauxScrollFrame_GetOffset(autoInviteLoadSaveScrollFrame);
      if index <= max then
         --  autoInvite:chatMsg("Index: "..index);
         --  autoInvite:chatMsg("Set: "..AutoInviteSavedList[index].name);
         _G[baseName.."LoadSaveDetail"..i.."_Index"]:SetText(index);
         _G[baseName.."LoadSaveDetail"..i.."_Description"]:SetText(AutoInviteSavedList[index].description);
         _G[baseName.."LoadSaveDetail"..i.."_Dummy"]:SetText(AutoInviteSavedList[index].text);
         _G[baseName.."LoadSaveDetail"..i]:Show();
      else
         _G[baseName.."LoadSaveDetail"..i]:Hide();
      end
   end
   --   end
   
end

function autoInvite:loadSaveFrameLoadButton_OnClick(self)
   autoInvite:debugMsg("Load button clicked, in function autoInvite:loadSaveFrameLoadButton_OnClick");
   local name=self:GetName();
   local searchIndex=string.find(name,"_");
   local class=string.sub(name,1,searchIndex-1);
   local index=tonumber(_G[class.."_Index"]:GetText());
   autoInvite:debugMsg("index: "..index);
   local userCount=table.getn(AutoInviteSavedList[index]["list"]);
   autoInvite:debugMsg("Count: "..userCount);
   AutoInviteCompleteList={};
   for i=1,userCount do
      autoInvite:debugMsg("i: "..i);
      AutoInviteCompleteList[i]={};
      AutoInviteCompleteList[i]['group']=AutoInviteSavedList[index]['list'][i]['group'];
      AutoInviteCompleteList[i]['eClass']=AutoInviteSavedList[index]['list'][i]['eClass'];
      AutoInviteCompleteList[i]['name']=AutoInviteSavedList[index]['list'][i]['name'];
      AutoInviteCompleteList[i]['realm']=AutoInviteSavedList[index]['list'][i]['realm'];
      AutoInviteCompleteList[i]['inGroup']=AutoInviteSavedList[index]['list'][i]['inGroup'];
      AutoInviteCompleteList[i]['status']=AutoInviteSavedList[index]['list'][i]['status'];
      AutoInviteCompleteList[i]['level']=AutoInviteSavedList[index]['list'][i]['level'];
      AutoInviteCompleteList[i]['invited']=AutoInviteSavedList[index]['list'][i]['invited'];
      AutoInviteCompleteList[i]['comment']=AutoInviteSavedList[index]['list'][i]['comment'];
   end
   autoInvite:resetControlObject();
   autoInvite:chatMsg(AUTO_INVITE_LIST_LOADED);
   autoInvite:loadSaveConfig();
   -- update groups
   autoInvite:sortCompleteList();
   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:updateGroupCount();
end

function autoInvite:loadSaveFrameWriteButton_OnClick(self)
   autoInvite:debugMsg("Overwrite it");
   local name=self:GetName();
   local index=string.find(name,"_");
   local class=string.sub(name,1,index-1);
   local id=tonumber(_G[class.."_Index"]:GetText());
   autoInvite:debugMsg("ID: "..id);

   local countUser=table.getn(AutoInviteCompleteList);
   AutoInviteSavedList[id]['list']={};
   for i=1,countUser do
      AutoInviteSavedList[id]['list'][i]={};
      AutoInviteSavedList[id]['list'][i]['group']=AutoInviteCompleteList[i]['group'];
      AutoInviteSavedList[id]['list'][i]['eClass']=AutoInviteCompleteList[i]['eClass'];
      AutoInviteSavedList[id]['list'][i]['name']=AutoInviteCompleteList[i]['name'];
      AutoInviteSavedList[id]['list'][i]['realm']=AutoInviteCompleteList[i]['realm'];
      AutoInviteSavedList[id]['list'][i]['inGroup']=AutoInviteCompleteList[i]['inGroup'];
      AutoInviteSavedList[id]['list'][i]['status']=AutoInviteCompleteList[i]['status'];
      AutoInviteSavedList[id]['list'][i]['level']=AutoInviteCompleteList[i]['level'];
      AutoInviteSavedList[id]['list'][i]['invited']=AutoInviteCompleteList[i]['invited'];
      AutoInviteSavedList[id]['list'][i]['comment']=AutoInviteCompleteList[i]['comment'];
   end
   autoInvite:loadSaveScrollBar_Update();
   autoInvite:loadSaveConfig();
   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:updateGroupCount();
   autoInvite:chatMsg(AUTO_INVITE_SUCCESSFULLY_SAVED);
end

function autoInvite:loadSaveFrameSave(description)
   autoInvite:debugMsg("Got description: "..description);
   local max=table.getn(AutoInviteSavedList);
   local countUser=table.getn(AutoInviteCompleteList);
   AutoInviteSavedList[max+1]={};
   AutoInviteSavedList[max+1]['description']=description;
   AutoInviteSavedList[max+1]['list']={};
   for i=1,countUser do
      AutoInviteSavedList[max+1]['list'][i]={};
      AutoInviteSavedList[max+1]['list'][i]['group']=AutoInviteCompleteList[i]['group'];
      AutoInviteSavedList[max+1]['list'][i]['eClass']=AutoInviteCompleteList[i]['eClass'];
      AutoInviteSavedList[max+1]['list'][i]['name']=AutoInviteCompleteList[i]['name'];
      AutoInviteSavedList[max+1]['list'][i]['realm']=AutoInviteCompleteList[i]['realm'];
      AutoInviteSavedList[max+1]['list'][i]['inGroup']=AutoInviteCompleteList[i]['inGroup'];
      AutoInviteSavedList[max+1]['list'][i]['status']=AutoInviteCompleteList[i]['status'];
      AutoInviteSavedList[max+1]['list'][i]['level']=AutoInviteCompleteList[i]['level'];
      AutoInviteSavedList[max+1]['list'][i]['invited']=AutoInviteCompleteList[i]['invited'];
      AutoInviteSavedList[max+1]['list'][i]['comment']=AutoInviteCompleteList[i]['comment'];
   end
   autoInvite:loadSaveScrollBar_Update();
   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:updateGroupCount();
end

function autoInvite:loadSaveFrameDelButton_OnClick(self)
   autoInvite:debugMsg("Delete it");
   local name=self:GetName();
   local index=string.find(name,"_");
   local class=string.sub(name,1,index-1);
   local id=tonumber(_G[class.."_Index"]:GetText());
   autoInvite:debugMsg("ID: "..id);
   
   local count=table.getn(AutoInviteSavedList);
   local i;
   if(id<count) then
      autoInvite:debugMsg("Delete entry before");
      AutoInviteSavedList[id]={};
      for i=id,count do
         AutoInviteSavedList[i]=AutoInviteSavedList[i+1];
      end
      AutoInviteSavedList[count]=nil;
   else
      autoInvite:debugMsg("Delete last entry in list");
      AutoInviteSavedList[id]=nil;
   end
   
   autoInvite:loadSaveScrollBar_Update();
   autoInvite:loadSaveConfig();
   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:updateGroupCount();
   autoInvite:chatMsg(AUTO_INVITE_SUCCESSFULLY_DELETED);
end

function autoInvite:switchPowerStatus()
   local baseName="autoInviteMainConfigFrame";
   local btnActive = _G[baseName.."CheckButtonModActive"];
   local state=btnActive:GetChecked();
   if(state == 1) then
      --      autoInvite:chatMsg("Button was not selected, select it now");
      AutoInviteConfig['modActive']=1;
      btnActive:SetChecked(1);
   else
      --      autoInvite:chatMsg("Button was selected, unselect it now");
      --      autoInvite:chatMsg("kick everyone out of the groupsetup");
      for i=1, table.getn(AutoInviteCompleteList) do
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]='unknown';
      end

      -- need to maybe remove the lines to disable the button in function autoInvite_InviteButton_OnClick(status)
      local raidBtn=_G["autoInviteMainConfigFrameButtonInviteRaid"];
      local groupBtn=_G["autoInviteMainConfigFrameButtonInviteGroup"];
      raidBtn:GetNormalFontObject():SetTextColor(1,0.82,0);
      raidBtn:SetText(AUTO_INVITE_RAID_INVITE);
      groupBtn:GetNormalFontObject():SetTextColor(1,0.82,0);
      groupBtn:SetText(AUTO_INVITE_GROUP_INVITE);
      autoInvite.control.doInvites = false;

      -- Update to group display
      autoInvite:buildGroups();
      AutoInviteConfig['modActive']=0;
      btnActive:SetChecked(0);
   end
end

function autoInvite:activate()
   AutoInviteConfig['modActive']=1;
   local baseName="autoInviteMainConfigFrame";
   local btnActive = _G[baseName.."CheckButtonModActive"];
   btnActive:SetChecked(1);
end

-- return true if playerName is in group otherwise return false
function autoInvite:playerIsInGroup(playerName)
   autoInvite:debugMsg("In function autoInvite:playerIsInGroup(playerName)");
   local memberCount=GetNumGroupMembers();
   local i, name;
   autoInvite:debugMsg("Check if player "..playerName.." is in group...");
   for i=1,memberCount do
      name=autoInvite:getUnitName("party"..i);
      if(name and name==playerName) then
         autoInvite:debugMsg("Player is in group");
         do return true end;
      else
         autoInvite:debugMsg("Player is NOT in group");
         do return false end;
      end
   end
end

-- function is called if the update button is clicked
-- Update the complete interface from the mod
function autoInvite:updateButton_OnClick()
   autoInvite:debugMsg("In function autoInvite:updateButton_OnClick()");
   autoInvite:memberJoinedParty();
   autoInvite:memberJoinedRaid();
   -- disabled because is called in autoInviteJoinedParty and autoInviteJoinedRaid
   --   autoInviteBuildGroups();
   autoInvite:completeList_Update();
   autoInvite:updateGroupCount();
   autoInvite:sortCompleteList();
end

-- function is called if the Clear button is clicked
-- move all player back to the complete list
function autoInvite:clearButton_OnClick()
   autoInvite:debugMsg("In function autoInvite:clearButton_OnClick()");
   for i=1, table.getn(AutoInviteCompleteList) do
      AutoInviteCompleteList[i]["inGroup"]=false;
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]["status"]="unknown";
   end
   autoInvite:updateButton_OnClick();
end

-- function is called if Raid-Invite/Group-Invite button is clicked
function autoInvite:inviteButton_OnClick(self, status)
   if (status=="raid" and GetNumGroupMembers() == 0) then
      autoInvite.control.changeToRaid = true;
   else
      autoInvite.control.changeToRaid = false;
   end
   -- standard color: <Color r="1.0" g="0.82" b="0"/>
   -- standard highlightcolor: <Color r="1.0" g="1.0" b="1.0"/>
   if (autoInvite.control.doInvites == false) then
      self:GetNormalFontObject():SetTextColor(0,1,0);
      self:SetText(AUTO_INVITE_INVITE_RUNNING);
      --self:SetHighlightTextColor(0,1,0); -- disabled because Blizzard has changed API again
      autoInvite.control.doInvites = true;
      autoInvite:activate();
   elseif (autoInvite.control.doInvites == true) then
      self:GetNormalFontObject():SetTextColor(1,0.82,0);
      if(status=="raid") then
         self:SetText(AUTO_INVITE_RAID_INVITE);
      else
         self:SetText(AUTO_INVITE_GROUP_INVITE);
      end
      --self:SetHighlightTextColor(1,1,1); -- disabled because Blizzard has changed API again
      autoInvite.control.doInvites = false;
   end
   autoInvite:switchPowerStatus();
end


function autoInvite:updateMainHeader()
   autoInvite:debugMsg("In function autoInvite:updateMainHeader()");
   local header = _G["autoInviteMainConfigFrameVersionText"];
   local text=header:GetText();

   text=text..autoInvite.version;
   header:SetText(text);
end

function autoInvite:loadCSV()
   autoInvite:debugMsg("In function autoInvite:loadCSV(msg)");
   if(autoInviteLoadCSVFrame:IsVisible()) then
      autoInviteLoadCSVFrame:Hide();
   else
      autoInviteLoadCSVFrame:Show();
      --      autoInviteLoadCSVScrollBar_Update();
   end
end

function autoInvite:importCSVData()
   autoInvite:debugMsg("In function autoInvite:importCSVData()");
   local base="autoInviteLoadCSVFrame";
   local description=_G[base.."EditBoxProfileName"]:GetText();
   local data=_G[base.."EditBoxCSVDataText"]:GetText().."\n";

   local pos;
   local array={};
   while(string.find(data,"\n")) do
      pos=string.find(data,"\n");
      autoInvite:debugMsg("Found line: "..string.sub(data,0,pos-1));
      table.insert(array,string.sub(data,0,pos-1));
      data=string.sub(data,pos+1,-1);
   end

   -- clear current lists
   AutoInviteCompleteList={};
   autoInvite:resetControlObject();
   local max=table.getn(array);
   autoInvite:debugMsg("Found "..max.." entries in CSV import");
   local _,_,name,eClass,level,inGroup,group,comment;
   for i=1, max do
      -- build the new group array here with the description and the function
      if(AutoInviteConfig['oldVersion'])then
         autoInvite:debugMsg("Using old version parser");
         _,_,name,eClass,level,inGroup,group,comment=string.find(array[i],"^(.-):(.-):(.-):(.-):(.-):(.-)$");
      else
         autoInvite:debugMsg("Using new version parser");
         name,eClass,level,inGroup,group,comment,comment2=strsplit(":",array[i]);
         autoInvite:debugMsg("Found name "..name);
      end
      if(comment and comment2)then
         comment=comment..": "..comment2;
      end
      if(name and eClass and level and inGroup and group) then
         AutoInviteCompleteList[i]={};
         -- split the name into playerName and realmName
         local userName, realmName;
         userName, realmName=autoInvite:splitNameRealm(name);

         autoInvite:debugMsg("Name: ->"..name.."<-");
         autoInvite:debugMsg("Realm: ->"..realm.."<-");
         autoInvite:debugMsg("Class: ->"..eClass.."<-");
         autoInvite:debugMsg("level: ->"..level.."<-");
         autoInvite:debugMsg("inGroup: ->"..inGroup.."<-");
         autoInvite:debugMsg("group: ->"..group.."<-");
         autoInvite:debugMsg("comment: ->"..comment.."<-");
         AutoInviteCompleteList[i]['name']=name;
         AutoInviteCompleteList[i]['eClass']=eClass;
         AutoInviteCompleteList[i]['level']=tonumber(level);
         AutoInviteCompleteList[i]['comment']=comment;
         if(inGroup=="1") then
            AutoInviteCompleteList[i]['inGroup']=true;
         else
            AutoInviteCompleteList[i]['inGroup']=false;
         end
         if(group=='1' or group=='2' or group=='3' or group=='4' or
            group=='5' or group=='6' or group=='7' or group=='8') then
            AutoInviteCompleteList[i]['group']=tonumber(group);
         else
            autoInvite:debugMsg("Group invalid, set group to -");
            AutoInviteCompleteList[i]['group']='-';
         end
         if (not autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]) then
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']] = {};
         end
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['status']="unknown";
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['online']=false;
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['inGuild']=false;
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['lastChecked']=0;
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['errorMessage']="";
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['show']=true;
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['inZone']=false;
         autoInvite:debugMsg("Read name: "..AutoInviteCompleteList[i]['name']..
                             ", Realm: "..AutoInviteCompleteList[i]['realm']..
                             ", eClass: "..AutoInviteCompleteList[i]['eClass']..
                                ", level: "..AutoInviteCompleteList[i]['level']..
                                ", group: "..AutoInviteCompleteList[i]['group']..
                                ", online: false "..
                                ", inGuild: false "..
                                ", saved posiotion: "..i);
      end
   end
   if(description~="") then
      autoInvite:debugMsg("Description is: *"..description.."*");
      autoInvite:loadSaveFrameSave(description);
   else
      autoInvite:chatMsg(AUTO_INVITE_NO_NAME_FOR_PROFILE_DONT_SAVE_IT)
   end
   -- Close the load-save window
   autoInvite:loadSaveConfig();
   -- update groups
   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:updateGroupCount();
end

function autoInvite:displayTooltip(self,text,body)
   GameTooltip_SetDefaultAnchor(GameTooltip, self)
   GameTooltip:SetText(text, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
   GameTooltip:AddLine(body, NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b, 1);
   GameTooltip:Show();
end

function autoInvite:hideTooltip(self,text)
   self.updateTooltip=nil;
   GameTooltip:Hide();
   ResetCursor();
end

-- ifComplete==true if in complete list else ifComplete==false
function autoInvite:playerButton_OnEnter(self,ifComplete)
   local btnName=_G[self:GetName().."TextLabelName"];
   local btnRealm=_G[self:GetName().."TextLabelRealm"];
   local btnLevel=_G[self:GetName().."TextLabelLevel"];
   local btnClass=_G[self:GetName().."TextLabelClass"];
   local user=btnName:GetText();
   local realm=btnRealm:GetText();
   if(user) then
      if(ifComplete) then
         GameTooltip_SetDefaultAnchor(GameTooltip, self)
         GameTooltip:SetText(AUTO_INVITE_COMPLETE_LIST_HEADER, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
         GameTooltip:AddLine(AUTO_INVITE_COMPLETE_LIST_DESC_BODY, NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b, 1);
      else
         GameTooltip:SetOwner(self, "ANCHOR_RIGHT");
         local max=table.getn(AutoInviteCompleteList);
         local i;
         
         for i=1, max do
            if(AutoInviteCompleteList[i]["name"]==user and AutoInviteCompleteList[i]['realm']==realm) then
               GameTooltip:SetText(user..'-'..realm..":");
               if(AutoInviteCompleteList[i]["comment"]) then
                  -- splitt text on <br> and add several lines
                  test = AutoInviteCompleteList[i]["comment"];
                  -- we must remove the || because blizzard seems to escape the character now
                  test=string.gsub(test,"||","|");
                  if string.find(test,"<br>",1,true) then
                     while string.find(test,"<br>",1,true) do
                        pos=string.find(test,"<br>",1,true);
                        line=string.sub(test,1,pos-1);
                        GameTooltip:AddLine(line, 1, 1, 1, nil);
                        test=string.sub(test,pos+4,string.len(test));
                     end
                     GameTooltip:AddLine(test, 1, 1, 1, nil);
                  else
                     GameTooltip:AddLine(test, 1, 1, 1, nil);
                  end
               end
               break;
            end
         end
         GameTooltip:AddLine(" ");
         GameTooltip:AddLine(AUTO_INVITE_LEFT_LIST_HEADER, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
         GameTooltip:AddLine(AUTO_INVITE_LEFT_LIST_DESC_BODY, NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b, 1);
      end
      GameTooltip:Show();
   end
end

function autoInvite:generateDump()

   debugOutput={};
   table.insert(debugOutput,"---START---");
   table.insert(debugOutput,"-Dump AutoInviteCompleteList-");
   -- dump complete list
   for number in pairs(AutoInviteCompleteList) do
      if(AutoInviteCompleteList[number]["name"]) then
         name=AutoInviteCompleteList[number]["name"];
      else
         name="ERROR";
      end
      if(AutoInviteCompleteList[number]["realm"]) then
         realm=AutoInviteCompleteList[number]["realm"];
      else
         realm="ERROR";
      end
      if(AutoInviteCompleteList[number]["inGroup"]) then
         inGroup="true";
      else
         inGroup="false";
      end
      if(AutoInviteCompleteList[number]["group"]) then
         group=AutoInviteCompleteList[number]["group"];
      else
         group="ERROR";
      end
      if(AutoInviteCompleteList[number]["level"]) then
         level=AutoInviteCompleteList[number]["level"];
      else
         level="ERROR";
      end
      if(AutoInviteCompleteList[number]["eClass"]) then
         eClass=AutoInviteCompleteList[number]["eClass"];
      else
         eClass="ERROR";
      end
      table.insert(debugOutput,"Number="..number..", Name="..name..", Realm="..realm..", inGroup="..inGroup..", group="..group..", level="..level..", eClass="..eClass);
   end

   -- dump control list
   table.insert(debugOutput,"-Dump autoInvite.controlList-");
   if(autoInvite.control.isLoaded) then
      table.insert(debugOutput,"autoInvite.control.isLoaded=true");
   else
      table.insert(debugOutput,"autoInvite.control.isLoaded=false");
   end
   if(autoInvite.control.changeToRaid) then
      table.insert(debugOutput,"autoInvite.control.changeToRaid=true");
   else
      table.insert(debugOutput,"autoInvite.control.changeToRaid=false");
   end
   table.insert(debugOutput,"autoInvite.control.lastUpdate:"..autoInvite.control.lastUpdate);
   if(autoInvite.control.doInvites) then
      table.insert(debugOutput,"autoInvite.control.doInvites=true");
   else
      table.insert(debugOutput,"autoInvite.control.doInvites=false");
   end
   for name in pairs(autoInvite.control.member) do
      online="false";
      if(autoInvite.control["member"][name]["online"]) then
         online="true";
      end
      inGuild="false";
      if(autoInvite.control["member"][name]["inGuild"]) then
         inGuild="true";
      end
      if(autoInvite.control["member"][name]["show"]) then
         showPlayer="true";
      end
      table.insert(debugOutput,"name="..name..", status="..autoInvite.control["member"][name]["status"]..", show="..showPlayer..", inGuild="..inGuild..", online="..online..", errorMessage="..autoInvite.control['member'][name]['errorMessage']..", lastCheck="..autoInvite.control["member"][name]["lastChecked"]);
   end

   -- dump combined complete-control list

   --   autoInvite:chatMsg("");
   --   autoInvite:chatMsg("");
   table.insert(debugOutput,"---STOP---");
   return(debugOutput);
end

function autoInvite:dumpVariables()
   autoInvite.saveChatMsg=true;   
   debugOutput=autoInvite:generateDump();
   for i,line in pairs(debugOutput) do
      autoInvite:chatMsg(line);
   end
   autoInvite.saveChatMsg=false;   
end

function autoInvite:saveDebug()
   autoInvite.saveChatMsg=true;   
   autoInvite:chatMsg(AUTO_INVITE_GENERATE_DUMP);
   AutoInviteDebug=autoInvite:generateDump();
   autoInvite:chatMsg(AUTO_INVITE_DUMP_SUCCESSFULLY_SEND_TO);
   
   autoInvite:debugMsg(GetCVar("accountName"));
   autoInvite:debugMsg(GetRealmName());
   autoInvite:debugMsg(autoInvite:getUnitName("player"));

   autoInvite:chatMsg(format(AUTO_INVITE_DUMP_SEND_FILE,GetCVar("accountName"),GetRealmName(),autoInvite:getUnitName("player")));
   autoInvite:chatMsg(AUTO_INVITE_THX_FOR_HELP);
   autoInvite:chatMsg(AUTO_INVITE_TO_SAVE_DUMP);
   autoInvite.saveChatMsg=false;   
end

function autoInvite:clearDebug()
   autoInvite:chatMsg(AUTO_INVITE_CLEAR_DUMP_LOG);
   AutoInviteDebug=nil;
   autoInvite:chatMsg(AUTO_INVITE_DONE);
end

function autoInvite:sortCompleteListOnLoad()
   local baseName="autoInviteMainConfigFrame";
   local btnWisper = _G[baseName.."CompleteListCheckButtonSortCompleteList"];
   if(AutoInviteConfig['sortComplete']==1) then
      -- set check
      btnWisper:SetChecked(1);
   else
      -- remove check
      AutoInviteConfig['sortComplete']=0;
      btnWisper:SetChecked(0);
   end
end

function autoInvite:sortCompleteListOnClick(self)
   autoInvite:debugMsg(self:GetName().." autoInvite:sortCompleteListOnClick "..self:GetID());

   local baseName=self:GetName();
   local btnSort = _G[baseName];
   local state=btnSort:GetChecked();
   if(state == 1) then
      autoInvite:debugMsg("Button was not selected, select it now");
      AutoInviteConfig['sortComplete']=1;
      btnSort:SetChecked(1);
      autoInvite:sortCompleteList(); -- sort the list itself
      autoInvite:completeList_Update(); -- refresh the complete list
      autoInvite:buildGroups(); -- refresh the group lists
   else
      autoInvite:debugMsg("Button was selected, unselect it now");
      AutoInviteConfig['sortComplete']=0;
      btnSort:SetChecked(0);
   end
end

function autoInvite:lockCompleteListOnLoad()
   local baseName="autoInviteMainConfigFrame";
   local btnWisper = _G[baseName.."CompleteListCheckButtonLockCompleteList"];
   if(AutoInviteConfig['lockComplete']==1) then
      -- set check
      btnWisper:SetChecked(1);
   else
      -- remove check
      AutoInviteConfig['lockComplete']=0;
      btnWisper:SetChecked(0);
   end
end

function autoInvite:lockCompleteListOnClick(self)
   autoInvite:debugMsg(self:GetName().." autoInvite:lockCompleteListOnClick "..self:GetID());

   local baseName=self:GetName();
   local btnSort = _G[baseName];
   local state=btnSort:GetChecked();
   if(state == 1) then
      autoInvite:debugMsg("Button was not selected, select it now");
      AutoInviteConfig['lockComplete']=1;
      btnSort:SetChecked(1);
   else
      autoInvite:debugMsg("Button was selected, unselect it now");
      AutoInviteConfig['lockComplete']=0;
      btnSort:SetChecked(0);
   end
end

-- Trigger the online check function, send /who and use WoW Events to upate
-- the list which is player is online
function autoInvite:checkOnlineOfflineState()
   autoInvite:debugMsg("In function autoInvite:checkOnlineOfflineState");
   autoInvite:debugMsg("Enable the mod");
   autoInvite:switchPowerStatus();

   -- read information about player which are in the guild
   FriendsFrame:UnregisterEvent("GUILD_ROSTER_UPDATE");
   GuildRoster();
   FriendsFrame:RegisterEvent("GUILD_ROSTER_UPDATE");
   local guildCount=GetNumGuildMembers();
   -- go through guild list and mark players in the AutoInviteCompleteList if the are in the guild
   autoInvite:debugMsg("found "..guildCount.." guildmembers");
   for i=1, guildCount do
      local name, rank, rankIndex, level, class, zone, note, officernote, online, status = GetGuildRosterInfo(i);
      autoInvite:debugMsg("Check player "..name);
      local id=autoInvite:getId(AutoInviteCompleteList,name, nil); -- @todo fix this
      if(id ~= 0) then
         autoInvite:debugMsg("Player "..name.." is in the guild, flag him");
         autoInvite.control['member'][name]['inGuild']=true;
         if(online) then
            autoInvite:debugMsg("Guildplayer "..name.." is online, set online flag");
            autoInvite.control['member'][name]['online']=true;
         end
      end
   end
   autoInvite:completeList_Update();

   if(IsAddOnLoaded("QueueWho")) then
      -- need to check if QueueWho is installed
      local max=table.getn(AutoInviteCompleteList);
      autoInvite.checkOnlineState=true;
      autoInvite.checkOnlineLastId=1;
      autoInvite.checkOnlineMaxId=0;

      for i=1, max do
         local name=AutoInviteCompleteList[i]['name'];
         if(autoInvite.control['member'][name]['inGuild']==false and AutoInviteCompleteList[i]['inGroup']==false) then
            autoInvite:chatMsg(format(AUTO_INVITE_CHECK_ONLINE_STATUS_WITH_WHO,name));
            autoInvite.checkOnlineMaxId=autoInvite.checkOnlineMaxId+1;
            QueueWho:AddWhoRequest(name, autoInvite.getOnlineStatus, name);
         end
      end
   else
      autoInvite:chatMsg(AUTO_INVITE_NEED_ADDON_QUEUE_WHO);
   end
   autoInvite:debugMsg("Finished autoInviteCheckOnlineOfflineState");
end

function autoInvite:getOnlineStatus(playerName)
   autoInvite:debugMsg("In function autoInvite:getOnlineStatus");
   
   if(autoInvite.CheckOnlineState) then
      if(playerName) then
         autoInvite:debugMsg("Check Player "..playerName);
         numWhos, totalCount=GetNumWhoResults();
         autoInvite:debugMsg("Got "..numWhos.." results");
         for i=1, numWhos do
            autoInvite:debugMsg("Check i:"..i);
            charname, guildname, level, race, class, zone, unknown = GetWhoInfo(i);
            autoInvite:debugMsg("Compare "..charname.." with "..playerName);
            if(charname and charname == playerName) then
               autoInvite:debugMsg("Set online to true");
               autoInvite.control['member'][playerName]['online']=true;
            end
         end
         -- check if we reached the end or we need to check more players
         autoInvite:debugMsg("Check if we need to trigger more events for the update check");
         if(autoInvite.CheckOnlineLastId<autoInvite.CheckOnlineMaxId) then
            autoInvite:debugMsg("Need more online checks, they are allready queued");
            autoInvite.CheckOnlineLastId=autoInvite.CheckOnlineLastId+1;
         else
            autoInvite:chatMsg(AUTO_INVITE_DONE);
            autoInvite.CheckOnlineState=false;
         end
         autoInvite:completeList_Update();
      end
   end
end

-- reset all values to default
function autoInvite:reset(self)
   autoInvite:debugMsg("In function autoInvite:reset()");
   AutoInviteCompleteList=nil;
   AutoInviteConfig=nil;
   AutoInviteSavedList=nil;
   
   autoInvite:init(self);
   autoInvite:clearDebug();
   AutoInviteConfig['ifWisper']=0;
   AutoInviteConfig['modActive']=0;
   AutoInviteConfig['sortComplete']=0;
   autoInvite:ifWisperOnLoad();
   local baseName="autoInviteMainConfigFrame";
   local btnActive = _G[baseName.."CheckButtonModActive"];
   btnActive:SetChecked(0);
   autoInvite:sortCompleteListOnLoad();

   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:chatMsg(AUTO_INVITE_ALL_SETTINGS_RESETED);
end

function autoInvite:importGuildMembers()
   GuildRoster();
   local name, rank, rankIndex, level, class, zone, note, officernote, online;
   local numGuildMembers = GetNumGuildMembers(true);
   local gname = GetGuildInfo("player");
   local num = 0;

   if (gname == nil or numGuildMembers == 0) then
      autoInvite:chatMsg("No guild members to add");
      -- DEFAULT_CHAT_FRAME:AddMessage("No guild members to add",0.3,0.3,1);
      return;
   end

   AutoInviteCompleteList={};
   autoInvite:resetControlObject();

   for i=1, numGuildMembers do
      local name, rank, rankIndex, level, eeClass, zone, comment, officernote, online = GetGuildRosterInfo(i);

      -- translate all classes to english names
      autoInvite:debugMsg("Class is: "..eeClass);
      if(eeClass=="J\195\164ger" or eeClass=="J\195\164gerin") then
         eeClass="Jaeger";
         autoInvite:debugMsg("Found german class Hunter, using work-around");
      end
      if(eeClass=="Pr\195\170tre" or eeClass=="Pr\195\170tresse") then
         eeClass="Pretre";
         autoInvite:debugMsg("Found french class Priest, using work-around");
      end
      if(eeClass=="Guerri\195\168re") then
         eeClass="Guerrier";
         autoInvite:debugMsg("Found french class Warrior, using work-around");
      end
      if(eeClass=="D\195\169moniste") then
         eeClass="Demoniste";
         autoInvite:debugMsg("Found french class Warlock, using work-around");
      end

      -- replace spaces with _
      eeClass = string.gsub(eeClass, " ", "_");

      eClass=AUTO_INVITE_CLASS_TO_ENGLISH[strupper(eeClass)];
      if(not eClass) then
         autoInvite:chatMsg("Could not translate class -"..eeClass.."-. Please report that to the author, thanks.");
         break;
      end
      autoInvite:debugMsg("Translated class is: "..eClass);

      AutoInviteCompleteList[i]={};
      AutoInviteCompleteList[i]['name']=name;
      AutoInviteCompleteList[i]['realm']="N/A"; -- @todo set correct realm here
      AutoInviteCompleteList[i]['eClass']=strupper(eClass);
      AutoInviteCompleteList[i]['level']=tonumber(level);
      AutoInviteCompleteList[i]['comment']=comment;
      AutoInviteCompleteList[i]['inGroup']=false;
      AutoInviteCompleteList[i]['group']='-';

      if (not autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]) then
         autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']] = {};
      end

      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['status']="unknown";
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['online']=false;
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['inGuild']=false;
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['lastChecked']=0;
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['errorMessage']="";
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['show']=true;
      autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['inZone']=true;
   end

   -- update groups
   --   autoInvite:buildGroups();
   --   autoInvite:completeList_Update();
   --   autoInvite:updateGroupCount();
   --   autoInvite:sortCompleteList();
   autoInvite:updateButton_OnClick();
end

-- function is called when text in the filter completeList EditBox is changed or inserted
function autoInvite:filterCompleteList(textToFilter)
   autoInvite:debugMsg("In function filterCompleteList: "..textToFilter);
   if(textToFilter) then
      local maxCount=table.getn(AutoInviteCompleteList);
      -- interate to complete list and mark player without string matching with filter=true
      for i=1, maxCount do
         autoInvite:debugMsg("Check filter on: "..AutoInviteCompleteList[i]["name"].." Class: "..AutoInviteCompleteList[i]['eClass']);
         if(string.find(string.lower(AutoInviteCompleteList[i]["name"]), string.lower(textToFilter)) or
            string.find(string.lower(AUTO_INVITE_CLASS[AutoInviteCompleteList[i]["eClass"]]), string.lower(textToFilter)) or
            string.find(string.lower(AutoInviteCompleteList[i]["level"]), string.lower(textToFilter))
            ) then
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['show']=true;
         else
            autoInvite:debugMsg("Hide player: "..AutoInviteCompleteList[i]["name"]);
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['show']=false;
         end            

      end
      autoInvite:completeList_Update();
   end
end

-- function to display raid members that are not in your zone
function autoInvite:checkRaidPlayerZones()
   -- get my own zone
   local myZone=GetRealZoneText();
   autoInvite:chatMsg("My Zone is: "..myZone);

   local memberCount=GetNumGroupMembers();
   local i,ready=1;
   for i=1, memberCount do
      local name,rank,subgroup,level,class,eClass,zone,online,isDead,isML=GetRaidRosterInfo(i);

      if(name) then
         if(online and online==1 and myZone and zone and myZone==zone) then
            autoInvite:debugMsg("Player "..name.." is in my zone ("..zone..")");
            autoInvite.control.member[name]['inZone']=true;
         else
            ready=0;
            autoInvite:debugMsg("Player "..name.." is NOT in my Zone.");
            autoInvite:chatMsg("Player "..name.." is NOT in my Zone: "..myZone);
            autoInvite.control.member[name]['inZone']=false;
         end
      else
         ready=0;
         autoInvite:chatMsg("An ERROR happened, please repeat that function");
         return;
      end
   end
   if(ready==1) then
      autoInvite:chatMsg("Everyone IS in your zone");
   end
end

-- function to import data from the guild calendar
function autoInvite:importCalendar()
   -- get calendar entries for next 5 days
   local month, year, days, firstday = CalendarGetMonth(0);
   autoInvite:debugMsg("Month: "..month.." year: "..year.." days: "..days.." firstday: "..firstday);
   local weekdayToday, monthToday, dayToday, yearToday = CalendarGetDate();

   --   for day=1, days do
   --      for i=1, CalendarGetNumDayEvents(0, day) do
   --         local title, hour, minute, calendarType, sequenceType, eventType, texture, modStatus, inviteStatus, invitedBy, difficulty = CalendarGetDayEvent(0, day, i);
   --         if(eventType == CALENDAR_EVENTTYPE_RAID or eventType == CALENDAR_EVENTTYPE_DUNGEON) then
   --            autoInvite:chatMsg("title: "..title.." hour: "..hour.." minute: "..minute.." cType: "..calendarType.." sType: "..sequenceType.." eType: "..eventType.." texture: "..texture.." modStatus: "..modStatus.." inviteStatus: "..inviteStatus.." invitedBy: "..invitedBy.." difficulty: "..difficulty);
   --         end
   --      end
   --   end

   -- we only import data from today
   local title, hour, minute, calendarType, sequenceType, eventType, texture, modStatus, inviteStatus, invitedBy, difficulty = CalendarGetDayEvent(0, dayToday, 1);
   if(eventType == CALENDAR_EVENTTYPE_RAID or eventType == CALENDAR_EVENTTYPE_DUNGEON) then
      autoInvite:debugMsg("title: "..title.." hour: "..hour.." minute: "..minute.." cType: "..calendarType.." sType: "..sequenceType.." eType: "..eventType.." texture: "..texture.." modStatus: "..modStatus.." inviteStatus: "..inviteStatus.." invitedBy: "..invitedBy.." difficulty: "..difficulty);

      -- clear current list
      AutoInviteCompleteList={};
      autoInvite:resetControlObject();

      -- open the event
      CalendarOpenEvent(0, dayToday, 1);
      local inviteCount = CalendarEventGetNumInvites();
      autoInvite:debugMsg("count of invites: "..inviteCount);
      for i=1, inviteCount do
         local name, level, className, classFilename, inviteStatus, modStatus = CalendarEventGetInvite(i)
         autoInvite:debugMsg("Name: "..name.." lvl: "..level.." className: "..className.." cFileName: "..classFilename.." iStatus: "..inviteStatus.." mStatus: "..modStatus);
         if(name and classFilename and level and inviteStatus) then
            AutoInviteCompleteList[i]={};
            AutoInviteCompleteList[i]['name']=name;
            AutoInviteCompleteList[i]['realm']="N/A"; -- @todo set correct realm here
            AutoInviteCompleteList[i]['eClass']=classFilename;
            AutoInviteCompleteList[i]['level']=level;
            AutoInviteCompleteList[i]['comment']='';
            if(inviteStatus == CALENDAR_INVITESTATUS_ACCEPTED or inviteStatus == CALENDAR_INVITESTATUS_CONFIRMED) then
               AutoInviteCompleteList[i]['inGroup']=true;
            else
               AutoInviteCompleteList[i]['inGroup']=false;
            end
            AutoInviteCompleteList[i]['group']='-';
            if (not autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]) then
               autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']] = {};
            end
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['status']="unknown";
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['online']=false;
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['inGuild']=false;
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['lastChecked']=0;
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['errorMessage']="";
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['show']=true;
            autoInvite.control.member[AutoInviteCompleteList[i]['name']..'-'..AutoInviteCompleteList[i]['realm']]['inZone']=false;

         end
      end
   else
      autoInvite:chatMsg("No calendar entry for today found");
   end
   
   -- close the load-save window
   autoInvite:loadSaveConfig();
   -- update groups
   autoInvite:completeList_Update();
   autoInvite:buildGroups();
   autoInvite:updateGroupCount();
end

function autoInvite:getUnitName(unit)
   autoInvite:debugMsg("In function getUnitName with parameter "..unit);
   local playerName,realmName=UnitName(unit);
   if(playerName) then
      autoInvite:debugMsg("Got name: *"..playerName.."*");
   end
   return playerName;
end

function autoInvite:getRealmName(unit)
   autoInvite:debugMsg("In function getRealmName with parameter "..unit);
   local userAndRealm = GetUnitName(unit, true);
   if(userAndRealm) then
      autoInvite:debugMsg("userAndRealm: "..userAndRealm);
   end
   local userName, realmName;
   userName, realmName=autoInvite:splitNameRealm(userAndRealm);

   return realmName;
end

function autoInvite:splitNameRealm(userAndRealm)
   local userName, realmName;
   local realmSeparator=string.find(userAndRealm, "-");
   if(realmSeparator) then
      userName=string.sub(userAndRealm, 1, realmSeparator-1);
      realmName=string.sub(userAndRealm, realmSeparator+1);
   else
      userName=name;
      realmName='N/A';
   end
   return userName, realmName;
end