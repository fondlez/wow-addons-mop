<?php
/******************************
 * EQdkp RaidPlan
 * (c) 2005 - 2007
 * past dev by Urox, A.Stranger
 * continued by Wallenium 
 * ---------------------------
 * $Id: export.class.php 1012 2007-12-07 08:26:05Z wallenium $
 ******************************/

if ( !defined('EQDKP_INC') ){
    header('HTTP/1.0 404 Not Found');exit;
}

class RaidplanExport {
  function strto_wowutf($str){
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  	$find[] = '�';
  
  	$replace[]			= '\195\160';
  	$replace[]			= '\195\161';
  	$replace[]			= '\195\162';
  	$replace[]			= '\195\163';
  	$replace[]			= '\195\164';
  	$replace[]			= '\195\166';
  	$replace[]			= '\195\167';
  	$replace[]			= '\195\132';
  	$replace[]			= '\195\150';
  	$replace[]			= '\195\156';
  	$replace[]			= '\195\159';
  	$replace[]			= '\195\168';
  	$replace[]			= '\195\169';
  	$replace[]			= '\195\170';
  	$replace[]			= '\195\171';
  	$replace[]			= '\195\172';
  	$replace[]			= '\195\173';
  	$replace[]			= '\195\174';
  	$replace[]			= '\195\175';
  	$replace[]			= '\195\177';
  	$replace[]			= '\195\178';
  	$replace[]			= '\195\179';
  	$replace[]			= '\195\180';
  	$replace[]			= '\195\181';
  	$replace[]			= '\195\182';
  	$replace[]			= '\195\184';
  	$replace[]			= '\195\185';
  	$replace[]			= '\195\186';
  	$replace[]			= '\195\187';
  	$replace[]			= '\195\188';
  	$replace[]			= '\195\138';
  
  	$str_encoded = str_replace($find, $replace , $str);
  
  	return $str_encoded;
  }
  
  function CreateCVSFile($raid_id, $printlua, $downloader){
     global $db, $eqdkp_root_path, $user, $SID, $conf, $rpclass;
    
     $output = "<br><br><b>".$user->lang['rp_cvs_output']."</b><br>";
     
     // must use here * because group is a reserved sql word and so the command "select ... ,group from <table> where ..." will not work
     $sql = 'SELECT *
  	   FROM ' . RP_ATTENDEES_TABLE . "
  	   WHERE raid_id='" . $raid_id . "' AND attendees_subscribed ='0'";
     $result = $db->query($sql);
     
     while($data = $db->fetch_record($result))   {
        $sql2 = "SELECT member_name, member_race_id, member_class_id, member_level FROM ".MEMBERS_TABLE." WHERE member_id=".$data['member_id']."";
        $result2 = $db->query($sql2);
        while($data2 = $db->fetch_record($result2))
        {
  	 $output .= $data2['member_name'].":";
  
  	 $sql3 = "SELECT class_name FROM ".CLASS_TABLE." WHERE class_id=".$data2['member_class_id']."";
  	 $result3 = $db->query($sql3);
  	 while($data3 = $db->fetch_record($result3))
  	 {
  	    $tempclass = $this->strto_wowutf(strtoupper($rpclass->convert_classname($data3['class_name'])));
  	    $output .= $tempclass.":";
  	 }
  	 $output .= $data2['member_level'].":";
  	 $output .= "1:";
	 if($data['group']>=1)
	 {
            $output .= $data['group'].":";
         }else{
  	    $output .= "-:";
         }
  	 $output .= 'W�rfelergebnis: |CFFB700B7';
         // replace \r\n with <br> so multiline comments are displayed in auto_invite
         $data['attendees_note']=str_replace("\r\n","&lt;br&gt;",$data['attendees_note']);
  	 $output .= "{$data['attendees_random']}|r&lt;br&gt;{$data['attendees_note']}\n";
        }
     }
     $db->free_result($result);
     
     $sql = 'SELECT *
  	   FROM ' . RP_ATTENDEES_TABLE . "
  	   WHERE raid_id='" . $raid_id . "' AND (attendees_subscribed ='1' OR attendees_subscribed='3')";
     $result = $db->query($sql);
     
     while($data = $db->fetch_record($result))
     {
        $sql2 = "SELECT member_name, member_race_id, member_class_id, member_level FROM ".MEMBERS_TABLE." WHERE member_id=".$data['member_id']."";
        $result2 = $db->query($sql2);
        while($data2 = $db->fetch_record($result2))
        {
  	 $output .= $data2['member_name'].":";
  
  	 $sql3 = "SELECT class_name FROM ".CLASS_TABLE." WHERE class_id=".$data2['member_class_id']."";
  	 $result3 = $db->query($sql3);
  	 while($data3 = $db->fetch_record($result3)){
  	    $tempclass = strtoupper($rpclass->convert_classname($data3['class_name']));
  	    $output .= $tempclass.":";
  	 }
  	 $output .= $data2['member_level'].":";
  	 $output .= "0:";
	 if($data['group']>=1)
	 {
            $output .= $data['group'].":";
         }else{
  	    $output .= "-:";
         }
  	 $output .= 'W�rfelergebnis: |CFFB700B7';
         // replace \r\n with <br> so multiline comments are displayed in auto_invite
         $data['attendees_note']=str_replace("\r\n","&lt;br&gt;",$data['attendees_note']);
  	 $output .= "{$data['attendees_random']}|r&lt;br&gt;{$data['attendees_note']}\n";
        }
     }
     $db->free_result($result);
     $output.="\n";
     
  
     
     if($printlua == true && $downloader == false){
        $output = str_replace("\n","<br>",$output);
        $output = str_replace("\t","&nbsp;&nbsp;&nbsp;&nbsp;",$output);
        return $output;
     }
    
  } // End of CVS Function
  
  function MacroListing($raid_id){
      global $db, $eqdkp_root_path, $user, $SID, $conf, $group_structure;
    // Set table names
    $text = "<b>".$group_structure[$_GET['group']]."</b><br/>";
  
    $sql = 'SELECT raid_id, member_id, `group`
  	   			FROM ' . RP_ATTENDEES_TABLE . "
  	   			WHERE raid_id='" .(int) $raid_id . "'";
  	if($_GET['group'] == 99 ){
  		$sql .= " AND attendees_subscribed ='1' OR attendees_subscribed ='3'";
  	}elseif($_GET['group'] == 100 ){
  		$sql .= " AND attendees_subscribed ='0'";
  		$sql .= " AND `group`='' OR `group`='0'";
  	}else{
  		$sql .= " AND attendees_subscribed ='0'";
  		$sql .= ($_GET['group']) ? " AND `group`='".$_GET['group']."'": "";
  	}
  	$sql .=	" GROUP BY member_id";
  	$result = $db->query($sql);
    
    // the guests
    $sql = "SELECT tempm.*, class_name
						FROM (" . RP_TEMPMEMBERS_TABLE . " as tempm, " . CLASS_TABLE . " as classes)
						WHERE raid_id='" . (int) $raid_id . "'
						AND classes.class_id=tempm.class";

  	if($_GET['group'] == 100 ){
  		$sql .= " AND `group`='' OR `group`='0'";
  	}else{
  		$sql .= ($_GET['group']) ? " AND `group`='".$_GET['group']."'": "";
  	}
  	$gresult = $db->query($sql);
  	
    $text .= "<textarea name='group".rand()."' cols='60' rows='10' onfocus='this.select()' readonly>";
    while($data = $db->fetch_record($result)){
  	  $sql2 = "SELECT member_name, member_race_id, member_class_id FROM ".MEMBERS_TABLE." WHERE member_id=".$data['member_id']." LIMIT 1";
  	  $result2 = $db->query($sql2);
  	  while($data2 = $db->fetch_record($result2)){
        //$membername =  $this->strto_wowutf($data2['member_name']);
        $membername =  $data2['member_name'];
  		  $text .= "/i ".$membername."\n";
  	  }
    }
    $db->free_result($result);
    while ($row = $db->fetch_record($gresult)){
  		  $text .= "/i ".$row['membername']."\n";
    }
    $db->free_result($gresult);
    
  	$text .= "</textarea>";
  
    $text .= '<br/>'.$user->lang['rp_copypaste_ig']."</b>";
    return $text;
  } // end MacroList Function
  
  function CreateLuaFile($raid_id, $printlua, $downloader){
    global $db, $eqdkp_root_path, $user, $SID, $conf, $rpclass;
  	$filereadable = false;
   
  if($printlua == false && $downloader == false){
    $houtput = '<br/><br/><font color="green"><b>'.$user->lang['rp_lua_created'].'. </b></font><br/><br/> <a class="RP-luaout" href="'.$conf['rp_auto_path'].'AutoInvite.lua"><b> '.$user->lang['rp_download'].' </b></a> '.$user->lang['rp_dl_autoinv_add'];
    $fname = $conf['rp_auto_path'].'AutoInvite.lua';
    if(is_writable($fname) || !file_exists($fname)){
    	$file = fopen($fname,'w');
    	$filereadable = true;
    }
  }
  if($downloader == false && $printlua == true)
  {
    $houtput .= "<br/><br/><b>".$user->lang['rp_lua_output']."</b><br/>";
  }
  
  $output = "
  
  AutoInviteCompleteList = {";
  
  $player_counter = 1;
  
  $sql = 'SELECT raid_id, member_id, attendees_random, attendees_note
  	   FROM ' . RP_ATTENDEES_TABLE . "
  	   WHERE raid_id='" . $raid_id . "' AND attendees_subscribed ='0'";
  	   $result = $db->query($sql);
  
  while($data = $db->fetch_record($result))
  {
  	$sql2 = "SELECT member_name, member_race_id, member_class_id, member_level FROM ".MEMBERS_TABLE." WHERE member_id=".$data['member_id']."";
  	$result2 = $db->query($sql2);
  	while($data2 = $db->fetch_record($result2))
  	{
  		$membername = $this->strto_wowutf($data2['member_name']);
  		$membernote = $this->strto_wowutf($data['attendees_note']);
  
  		$output .= "\n\t\t[".$player_counter."] = {\n";
  		$output .= "\t\t\t[\"name\"] = \"{$membername}\",\n";
  		$output .= "\t\t\t[\"inGroup\"] = true,\n";
  		$output .= "\t\t\t[\"level\"] = {$data2['member_level']},\n";
  
  		$output .= "\t\t\t[\"comment\"] = \"";
  		$output .= 'W\195\188rfelergebnis: |CFFB700B7';
  		$output .= "{$data['attendees_random']} |CFFFF50FF {$membernote}\",\n";
  
  		$sql3 = "SELECT class_name FROM ".CLASS_TABLE." WHERE class_id=".$data2['member_class_id']."";
  		$result3 = $db->query($sql3);
  		while($data3 = $db->fetch_record($result3))
  		{
  				$tempclass = $this->strto_wowutf(strtoupper($rpclass->convert_classname($data3['class_name'])));
  				$output .= "\t\t\t[\"eClass\"] = \"{$tempclass}\",\n";
  		}
  		$db->free_result($result3);
  		$output .= "\t\t},\n";
  		$player_counter = $player_counter + 1;
  	}
  	$db->free_result($result2);
  }
  $db->free_result($result);
  $sql = 'SELECT raid_id, member_id, attendees_random, attendees_note, attendees_subscribed
  	   FROM ' . RP_ATTENDEES_TABLE . "
  	   WHERE raid_id='" . $raid_id . "' 
  	   AND attendees_subscribed ='1'
  	   OR attendees_subscribed ='3'";
  	   $result = $db->query($sql);
  
  while($data = $db->fetch_record($result))
  {
  	$sql2 = "SELECT member_name, member_race_id, member_class_id, member_level FROM ".MEMBERS_TABLE." WHERE member_id=".$data['member_id']."";
  	$result2 = $db->query($sql2);
  	while($data2 = $db->fetch_record($result2))
  	{
  		
  		$membername = $this->strto_wowutf($data2['member_name']);
  		$membernote = $this->strto_wowutf($data['attendees_note']);
  
  		$output .= "\n\t\t[".$player_counter."] = {\n";
  		$output .= "\t\t\t[\"name\"] = \"{$membername}\",\n";
  		$output .= "\t\t\t[\"inGroup\"] = false,\n";
  		$output .= "\t\t\t[\"status\"] = \"unknown\",\n"; 
  		$output .= "\t\t\t[\"group\"] = \"-\",\n";
  		$output .= "\t\t\t[\"level\"] = {$data2['member_level']},\n";
  
  		$output .= "\t\t\t[\"comment\"] = \"";
  
  		If ($data['attendees_subscribed'] == 1)
  		{ $output .= '|CFFFFFFFF Angemeldet'; }
  		else
  		{ $output .= '|CFFFFFFFF Ersatzbank'; }
  
  		$output .= '|CFFFF50FF W\195\188rfelergebnis: |CFFB700B7';
  		$output .= "{$data['attendees_random']} |CFFFF50FF {$membernote}\",\n";
  
  		$sql3 = "SELECT class_name FROM ".CLASS_TABLE." WHERE class_id=".$data2['member_class_id']."";
  		$result3 = $db->query($sql3);
  		while($data3 = $db->fetch_record($result3))
  		{
  				$tempclass = strtoupper($rpclass->convert_classname($data3['class_name']));
  				$output .= "\t\t\t[\"eClass\"] = \"{$tempclass}\",\n";
  		}
  		$db->free_result($result3);
  		$output .= "\t\t},";
  		$player_counter = $player_counter + 1;
  	}
  	$db->free_result($result2);
  }
  $db->free_result($result);
  
  $output .= "}";
  
  $output .='
  AutoInviteConfig = {
  	["ifWisper"] = 1,
  	["modActive"] = 0,
  	}
  AutoInviteSavedList = {}';
  if($printlua == false && $downloader == false && $filereadable)
  {
    fwrite($file,$output);//write to file
  }else{
  	$houtput .= '<br/><br/><font color="red"><b>'.$user->lang['rp_lua_notreadable'].'</b></font>';
  }
  return $houtput;
  } // End of Lua Function
  
  
  function SelectOutput(){
    global $db, $eqdkp_root_path, $user, $SID, $conf;
    $output = $user->lang['rp_export_text'];
    return $output;
  }
}
?>
