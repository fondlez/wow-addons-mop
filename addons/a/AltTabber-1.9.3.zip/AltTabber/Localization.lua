local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "enUS", true, debug)

if not L then return end

L["BGSNDON"] = "Enabling sound in background so you can hear ready checks while alt-tabbed."
L["ENABLESOUNDSYSTEM"] = "Sound system is not enabled.  Sound system must be enabled to hear sounds.  Enabling sound system (should not notice a difference in sounds that are played)."
L["MASTERSOUNDOFF"] = "Master sound is set to 0.  You need to adjust the sliders for the Master sound volume in order to hear anything."
L["ToC/Description"] = "Plays sound when a ready check, LFG queue, battleground queue, or world battleground queue pops even if you have sounds turned off in game."
L["ToC/Title"] = "Alt-Tabber"


L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "deDE", false)

if not L then return end

L["BGSNDON"] = "Aktiviere Sound im Hintergrund, damit du Bereitschaftschecks hören kannst, wenn du Alt-tabbed bist."
L["ENABLESOUNDSYSTEM"] = "Sound ist nicht aktiviert. Sound muss aktiviert sein, um etwas zu hören. Aktiviere Sound."
L["MASTERSOUNDOFF"] = "Gesamtlautstärke ist auf 0 gestellt. Du musst den Schieberegler für die Gesamtlautstärke anpassen, um etwas zu hören."
L["ToC/Description"] = "Spielt Soundeffekte, wenn ein Bereitschaftscheck, eine LFG-Warteschlagen oder BG-Warteschlange aufpoppt, sogar wenn Sounds im Spiel deaktiviert sind."
L["ToC/Title"] = "Alt-Tabber"


L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "frFR", false)

if not L then return end



L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "zhCN", false)

if not L then return end

L["BGSNDON"] = "启用背景声音，让你在关闭所有音乐、音效时可以听到准备确认。"
L["ENABLESOUNDSYSTEM"] = "禁用系统声音" -- Needs review
L["MASTERSOUNDOFF"] = "主音量设置为最" -- Needs review
L["ToC/Description"] = "当系统音量处于禁音时，团队检查，组队队列，战场队列，事件队列弹出时播放声音" -- Needs review
L["ToC/Title"] = "Alt-Tabber" -- Needs review


L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "zhTW", false)

if not L then return end

L["BGSNDON"] = "啟用背景聲音，讓你在關閉所有音樂、音效時可以聽到準備確認。"
L["ToC/Title"] = "Alt-Tabber" -- Needs review


L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "koKR", false)

if not L then return end

L["BGSNDON"] = "배경 소리 사용"


L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "esES", false)

if not L then return end



L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "esMX", false)

if not L then return end



L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "ptBR", false)

if not L then return end



L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "itIT", false)

if not L then return end



L = LibStub("AceLocale-3.0"):NewLocale("AltTabber", "ruRU", false)

if not L then return end

