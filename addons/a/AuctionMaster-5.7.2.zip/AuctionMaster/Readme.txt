AuctionMaster

Please have a look at http://www.curse.com/addons/wow/vendor for a detailed description and usage information.

Addon developers who want to use some AuctionMaster functionality should have a look at the Readme.txt file in the src/api directory.
