local L = LibStub("AceLocale-3.0"):NewLocale("AuctionMaster", "esMX", false)
if (L) then
--@START   
--@END
end
