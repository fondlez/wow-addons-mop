local L = LibStub("AceLocale-3.0"):NewLocale("AuctionMaster", "esES", false)
if (L) then
--@START   
--@END
end
