local L = LibStub("AceLocale-3.0"):NewLocale("AuctionMaster", "itIT", false)
if (L) then
--@START   
--@END
end
