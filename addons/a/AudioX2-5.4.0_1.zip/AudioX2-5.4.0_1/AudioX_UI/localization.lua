AX.ui_BEGIN		= "      /%s <num> Continue search beginning at the specified sample index. E.g. /%s 3000"
AX.ui_CLOSE		= "Close AudioX UI"
AX.ui_CMDTITLE		= "Search box commands:"
AX.ui_FAVICON		= "      Click the star icon to toggle between SoundLib and Favourite searching."  -- in use?
AX.ui_FONT		= "      /f <num> Change font size, where <num> between 6 and 28. E.g. /f 14"
AX.ui_FOOTER		= '%d - %d of %d found for "%s"'
AX.ui_FOOTER2		= 'and "%s"'
AX.ui_INSTRUCTION	= "Instructions:"
AX.ui_LINKICON		= "      Click on the chain-link icon to link a sample to another player using AudioX."
AX.ui_MATCH		= "      /%s <num> Continue search from a specific search match. /%s 15"
AX.ui_MOTIVE		= "UI development encouraged by Thorinair of EU Ragnaros"
AX.ui_MUSTSEARCH	= "You must perform a search before you can do that."
AX.ui_NB_LOADED		= "Loaded: |c%sAudioX II UI|r. Open with %s %s."
AX.ui_NEXTICON		= "      To show the next page of results press the > icon."
AX.ui_OPT_FONTSIZE	= "Fontsize: %dpt"
AX.ui_PENDING		= "<pending>"
AX.ui_PLAYICON		= "      Click the trumpet icon to the left of a sample to play it."
AX.ui_PREVICON		= "      To show the previous page of results press the < icon."
AX.ui_QUIETICON		= "      Click the red circle icon to silence all sample playback."
AX.ui_SEARCHBOX		= "      Type a search keyword (e.g. Hello) into the text box in the top left of the UI. Try #512."
AX.ui_SEARCHICON	= "      Press the Enter key of click on the magnifying glass to start the search."
AX.ui_TIPDOWN		= "Next line"
AX.ui_TIPFAV		= "Toggle favourite searching"
AX.ui_TIPFAVSFX		= "Toggle Favourite"
AX.ui_TIPINTERPRET	= "Toggle pre-search translating"
AX.ui_TIPKEYWORD	= "Enter search keyword here"
AX.ui_TIPLINK1		= "Link to chat"
AX.ui_TIPLINK2		= "Alt+Click for /script"
AX.ui_TIPNEXT		= "Next page of results"
AX.ui_TIPOPTIONS	= "Toggle Options"
AX.ui_TIPPLAY		= "Play sample"
AX.ui_TIPPREV		= "Previous page of results"
AX.ui_TIPQUIET		= "Reset audio"
AX.ui_TIPRESIZE1	= "Resize AudioX"
AX.ui_TIPRESIZE2	= "Click and drag this corner"
AX.ui_TIPSEARCH1	= "Search"
AX.ui_TIPSEARCH2	= "Shift+Click to refresh"
AX.ui_TIPUP		= "Previous line"

-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.ui_BEGIN			= "      /%s <zahl> Beginne mit der Suche an angegebenen Index. E.g. /%s 3000"
  AX.ui_CLOSE			= "Schliesse die AudioX Oberfl\195\164che"
  AX.ui_CMDTITLE		= "Befehle f\195\188r das Suchfeld:"
  AX.ui_FAVICON			= "      Klicke auf das Stern-Icon um zwischen SoundLib- und Favouritensuche umzuschalten."
  AX.ui_FONT			= "      /f <zahl> Setze Schriftgr\195\182\195\159e, <zahl> muss zwischen 6 und 28 liegen. Z.B.: /f 14"
  AX.ui_FOOTER			= "%d - %d von %d  gefunden f\195\188r \"%s\""
  AX.ui_FOOTER2			= "und \"%s\""
  AX.ui_INSTRUCTION		= "Anleitung:"
  AX.ui_LINKICON		= "      Klicke auf das Ketten-Symbol um einen Link zu diesem Ton f\195\188r einen anderen AudioX benutzenden Spieler zu erstellen."
  AX.ui_MATCH			= "      /%s <zahl> F\195\188hre Suche an einem bestimmen Suchergebniss weiter. /%s  15"
  AX.ui_MOTIVE			= "Oberfl\195\164chen-Entwicklung von Thorinair auf EU Ragnaros unterst\195\188tzt."
  AX.ui_MUSTSEARCH		= "Du musst eine Suche durchf\195\188hren bevor du das tun kannst."
  AX.ui_NB_LOADED		= "Geladen: |c%sAudioX II UI|r. \195\150ffnen \195\188ber %s %s."
  AX.ui_NEXTICON		= "      Um die n\195\164chste Seite der Ergebnisse anzuzeigen, klicke auf das > Icon"
  AX.ui_OPT_FONTSIZE		= "Schriftgr\195\182\195\159e: %dpt"
  AX.ui_PENDING			= "<anstehend>"
  AX.ui_PLAYICON		= "      Klicke auf das Trompeten-Symbol neben einem Eintrag um diesen abzuspielen."
  AX.ui_PREVICON		= "      Um die vorherige Seite der Ergebnisse anzuzeigen, klicke auf das < Icon"
  AX.ui_QUIETICON		= "      Klicke auf den roten Kreis um jegliche Wiedergabe anzuhalten."
  AX.ui_SEARCHBOX		= "      Gebe den gew\195\188nschten Suchbegriff (z.B. Hallo) in das Suchfeld im oberen linken Bereich der Oberfl\195\164che ein. Versuche es mit #512"
  AX.ui_SEARCHICON		= "      Dr\195\188cke die Eingabe-Taste oder klicke auf die Lupe um die Suche zu starten."
  AX.ui_TIPDOWN			= "N\195\164chste Zeile"
  AX.ui_TIPFAV			= "Schalte Favoritensuche um"
  AX.ui_TIPFAVSFX		= "Schalte Favorit um"
  AX.ui_TIPINTERPRET		= "Schalte \195\156bersetzung vor der Suche um"
  AX.ui_TIPKEYWORD		= "Gib hier den Suchbegriff ein"
  AX.ui_TIPLINK1		= "In Chat verlinken"
  AX.ui_TIPLINK2		= "Alt+Klick f\195\188r /script"
  AX.ui_TIPNEXT			= "N\195\164chste Seite der Ergebnisse"
  AX.ui_TIPOPTIONS		= "Zeige/Verstecke Optionen"
  AX.ui_TIPPLAY			= "Tondatei abspielen"
  AX.ui_TIPPREV			= "Vorherige Seite der Ergebnisse"
  AX.ui_TIPQUIET		= "Wiedergabe zur\195\188cksetzen"
  AX.ui_TIPRESIZE1		= "AudioX-Gr\195\182\195\159e ver\195\164ndern"
  AX.ui_TIPRESIZE2		= "Klicke und ziehe diese Ecke"
  AX.ui_TIPSEARCH1		= "Suche"
  AX.ui_TIPSEARCH2		= "Shift+Klick um zu neu zu laden"
  AX.ui_TIPUP			= "Vorherige Zeile"

elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end