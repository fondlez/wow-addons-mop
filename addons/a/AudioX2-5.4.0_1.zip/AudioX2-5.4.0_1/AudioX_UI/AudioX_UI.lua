--[[
===========================================================================
                              AudioX II UI
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================
]]--


local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(addon)
  if addon ~= "AudioX_UI" then
    return
  else
    self:UnregisterEvent("ADDON_LOADED")
    AX:UI_Initialise()
  end
end


f:SetScript("OnEvent", function(self, event, ...)
  self[event](self, ...)
end)


-- =========================== Initialisation ==========================


function AX:UI_InitVars()
  AX.ui_footerfrom = 1
  AX.ui_footerto = 1
  AX.ui_footermax = 20
  AX.ui_firstsearch = true
  AX.ui_active = false
  AX.ui_rowcount = 1
  AX.ui_rowheight = 16
  AX.ui_rowfont = "ChatFontNormal"
  AX.ui_shownrows = 0
  AX.ui_maxrows = 0
  AX.ui_shownbgtiles = 0
  AX.ui_maxbgtiles = 0
  -- AX.ui_verbosestore = AUDIOX_CONFIG.verbose  -- in use?
  AX.ui_showindexnum = AUDIOX_CONFIG.idxinresults
  AX.ui_pathdepth = AUDIOX_CONFIG.pathdepth
  AX.ui_hidefileext = AUDIOX_CONFIG.hideext
  AX.ui_interpret = AUDIOX_CONFIG.interpret
  AX.ui_regex = AUDIOX_CONFIG.regex
  AX.ui_titleapdx = ""
  AX.ui_apiout = AX.api_out
  AX.ui_timesinceupdate = 0
  AX.ui_updateinterval = 0.5
  AX.ui_fontsize_min = 6
  AX.ui_fontsize_max = 36
  AX.ui_opt_timesinceupdate = 0
  AX.ui_opt_updateinterval = 0.5
  AX.ui_sliderhidden = true
  AX.ui_windowresized = true
  AX.ui_gametipself = nil
  AX.ui_gametiptype = 1
  
  AX.ui_sliderchanged = false
  --
  AX.ui_config_defaults = {
    ["fwidth"] = 740,
    ["fheight"] = (AX.ui_rowheight * 20) + 82,  --402
    ["fpoint"] = "CENTER",
    ["frelpt"] = "CENTER",
    ["fxoff"] = 0,
    ["fyoff"] = 0,
    ["fontsize"] = 14,
  }
end


function AX:UI_Initialise()
  AX:UI_InitVars()
  --
  local mt = {}
  if type(axui_config) == "nil" then
    axui_config = AX.ui_config_defaults
  else
    setmetatable(axui_config,mt)
    mt.__index = AX.ui_config_defaults
  end
  AX.ui_fontsize = axui_config.fontsize
  AX.ui_rowheight = axui_config.fontsize + 2
  --
  AX:UI_BuildUI()
  AX:UI_BuildOptions()
  --
  -- Makes ESC key close BankItems
  tinsert(UISpecialFrames, "AudioX_Frame")
  --
  --
  AX:UI_LineHook()
  AX:UI_FootHook()
  AX:UI_NoticeHook()
  AX:Print(string.format(AX.ui_NB_LOADED,AX.linkcolour,SLASH_AUDIOX1,AX.s_CMD_GUI))
  --
  AX.ui_loaded = true
  AX:API_UIOutput()
  AX:UI_Show()
end



-- =========================== UI Constructs =============================


function AX.UI_OnUpdate(self,elapsed)
  AX.ui_timesinceupdate = AX.ui_timesinceupdate + elapsed
  while AX.ui_timesinceupdate > AX.ui_updateinterval do
    local refresh = false
    if not((AudioX_FavButton:GetChecked() == 1) == (AUDIOX_CONFIG.favs)) then
      AX:UI_FavList(false)
    end
    if AX.opt_loaded then
      if not((AudioX_OptionsButton:GetChecked() == 1) == (InterfaceOptionsFrame:IsShown())) then
        AudioX_OptionsButton:SetChecked(InterfaceOptionsFrame:IsShown())
      end
    else
      AudioX_OptionsButton:SetChecked(false)
    end
    if AX.ui_showindexnum ~= AUDIOX_CONFIG.idxinresults then
      refresh = true
      AX.ui_showindexnum = AUDIOX_CONFIG.idxinresults
    end
    if (AX.ui_pathdepth ~= AUDIOX_CONFIG.pathdepth) then
      refresh = true
      AX.ui_pathdepth = AUDIOX_CONFIG.pathdepth
    end
    if (AX.ui_hidefileext ~= AUDIOX_CONFIG.hideext) then
      refresh = true
      AX.ui_hidefileext = AUDIOX_CONFIG.hideext
    end
    if (AX.ui_regex ~= AUDIOX_CONFIG.regex) then
      AX:UI_SearchWrapper(AX.s_CMD_SEARCH,AX.s_userkeyword)
      refresh = false
      AX.ui_regex = AUDIOX_CONFIG.regex
    end
    AudioX_InterpretCheck:SetChecked(AUDIOX_CONFIG.interpret)
    if AX.ui_interpret ~= AUDIOX_CONFIG.interpret then
      AX:UI_SearchWrapper(AX.s_CMD_SEARCH,AX.s_userkeyword)
      refresh = false
      AX.ui_interpret = AUDIOX_CONFIG.interpret
    end
    if refresh then
      AX:UI_SearchWrapper(AX.s_CMD_REFRESH,"")
    end
    if (AX.ui_apiout ~= AX.api_out) then
      AX:UI_UpdateTitle(AX.ui_titleapdx)
      AX.ui_apiout = AX.api_out
    end
    if (AX.ui_fontsize ~= axui_config.fontsize) then
      AX:UI_ChangeFontSize(axui_config.fontsize)
      AX.ui_fontsize = axui_config.fontsize
    end
    if AX.ui_sliderchanged then
      AX:UI_SearchWrapperCore(AX.s_CMD_REFRESH,"")
      AX.ui_sliderchanged = false
    end
    if AX.ui_windowresized then
      AX:UI_ResizeBGTiles()
      AX:UI_ResizeRows()
      AX:UI_ConditionalSlider()
      AX.UI_refreshsearch = true
      AX.ui_windowresized = false
    end
    if AX.ui_gametipself ~= nil then
      if AX.ui_gametiptype == 3 then
        AX:UI_BodyTip()
      elseif AX.ui_gametiptype == 2 then
        AX:UI_TwoUp()
      elseif AX.ui_gametiptype == 1 then
        AX:UI_Generic()
      end
      AX.ui_gametipself = nil
    end  
    AX.ui_timesinceupdate = AX.ui_timesinceupdate - elapsed
  end
end


function AX:UI_BuildUI()
  AX.ui_rowheight = axui_config.fontsize + 2
  local fwidth = 740
  local fheight = (AX.ui_rowheight * 20) + 82  --402
  
  AudioX_Frame = CreateFrame("Frame","AudioX_Frame",UIParent)
  AudioX_Frame:Hide()
  AudioX_Frame:SetMovable(true)
  AudioX_Frame:SetResizable(true)
  AudioX_Frame:SetMinResize(278,98)
  AudioX_Frame:EnableMouse(true)
  AudioX_Frame:SetFrameStrata("MEDIUM")
  AudioX_Frame:SetToplevel(true)
  AudioX_Frame:SetWidth(fwidth)
  AudioX_Frame:SetHeight(fheight)
  AudioX_Frame:SetPoint("CENTER",UIParent,"CENTER",0,0)

  -- AudioX_Backgnd01, AudioX_Backgnd02 etc
  AX:UI_ResizeBGTiles()

  AudioX_BorderTL = AudioX_Frame:CreateTexture("AudioX_BorderTL","BORDER")
  AudioX_BorderTL:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopLeft")
  AudioX_BorderTL:SetWidth(64)
  AudioX_BorderTL:SetHeight(64)
  AudioX_BorderTL:SetPoint("TOPLEFT")
  AudioX_BorderTL:SetTexCoord(0,0.5,0,0.25)

  AudioX_BorderTR = AudioX_Frame:CreateTexture("AudioX_BorderTR","BORDER")
  AudioX_BorderTR:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopRight")
  AudioX_BorderTR:SetWidth(64)
  AudioX_BorderTR:SetHeight(64)
  AudioX_BorderTR:SetPoint("TOPRIGHT",0,0)
  AudioX_BorderTR:SetTexCoord(0.296875,0.546875,0,0.25)

  AudioX_BorderTM = AudioX_Frame:CreateTexture("AudioX_BorderTM","BORDER")
  AudioX_BorderTM:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-Top")
  AudioX_BorderTM:SetHeight(64)
  AudioX_BorderTM:SetPoint("TOPLEFT",AudioX_BorderTL,"TOPRIGHT",0,0)
  AudioX_BorderTM:SetPoint("TOPRIGHT",AudioX_BorderTR,"TOPLEFT",0,0)
  AudioX_BorderTM:SetTexCoord(0.3,0.35,0,0.25)
  
  AudioX_BorderBL = AudioX_Frame:CreateTexture("AudioX_BorderBL","BORDER")
  AudioX_BorderBL:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-BotLeft")
  AudioX_BorderBL:SetWidth(64)
  AudioX_BorderBL:SetHeight(36)
  AudioX_BorderBL:SetPoint("BOTTOMLEFT",0,0)
  AudioX_BorderBL:SetTexCoord(0,0.5,0.53225,0.671875)

  AudioX_BorderBR = AudioX_Frame:CreateTexture("AudioX_BorderBR","BORDER")
  AudioX_BorderBR:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-BotRight")
  AudioX_BorderBR:SetWidth(64)
  AudioX_BorderBR:SetHeight(36)
  AudioX_BorderBR:SetPoint("BOTTOMRIGHT")
  AudioX_BorderBR:SetTexCoord(0.296875,0.546875,0.53125,0.671875)

  AudioX_BorderBM = AudioX_Frame:CreateTexture("AudioX_BorderBM","BORDER")
  AudioX_BorderBM:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-BotLeft")
  AudioX_BorderBM:SetHeight(36)
  AudioX_BorderBM:SetPoint("TOPLEFT",AudioX_BorderBL,"TOPRIGHT")
  AudioX_BorderBM:SetPoint("TOPRIGHT",AudioX_BorderBR,"TOPLEFT")
  AudioX_BorderBM:SetTexCoord(0.25,0.5,0.53125,0.671875)
  
  AudioX_BorderML = AudioX_Frame:CreateTexture("AudioX_BorderML","BORDER")
  AudioX_BorderML:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopLeft")
  AudioX_BorderML:SetWidth(64)
  AudioX_BorderML:SetHeight(10)
  AudioX_BorderML:SetPoint("TOPLEFT",AudioX_BorderTL,"BOTTOMLEFT",0,0)
  AudioX_BorderML:SetPoint("BOTTOMLEFT",AudioX_BorderBL,"TOPLEFT",0,0)
  AudioX_BorderML:SetTexCoord(0,0.5,0.9375,1)

  AudioX_BorderMR = AudioX_Frame:CreateTexture("AudioX_BorderMR","BORDER")
  AudioX_BorderMR:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopRight")
  AudioX_BorderMR:SetWidth(64)
  AudioX_BorderMR:SetHeight(10)
  AudioX_BorderMR:SetPoint("TOPRIGHT",AudioX_BorderTR,"BOTTOMRIGHT")
  AudioX_BorderMR:SetPoint("BOTTOMRIGHT",AudioX_BorderBR,"TOPRIGHT")
  AudioX_BorderMR:SetTexCoord(0.296875,0.546875,0.9375,1)
  
  AudioX_BorderMC = AudioX_Frame:CreateTexture("AudioX_BorderMC","BORDER")
  AudioX_BorderMC:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopLeft")
  AudioX_BorderMC:SetPoint("TOPLEFT",AudioX_BorderML,"TOPRIGHT")
  AudioX_BorderMC:SetPoint("BOTTOMRIGHT",AudioX_BorderMR,"BOTTOMLEFT")
  AudioX_BorderMC:SetTexCoord(0.25,0.5,0.25,0.5)
  
  AudioX_TitleText = AudioX_Frame:CreateFontString("AudioX_TitleText","DIALOG","GameFontNormal")
  AudioX_TitleText:SetPoint("TOP", 0, -6)
  AudioX_TitleText:SetText("AudioX II")
  AudioX_TitleText:SetPoint("TOPLEFT",AudioX_Frame,"TOPLEFT",8,-6)
  AudioX_TitleText:SetPoint("TOPRIGHT",AudioX_Frame,"TOPRIGHT",-24,-6)
  AudioX_TitleText:SetFont("Fonts\\FRIZQT__.TTF",math.min(axui_config.fontsize,12))

  AudioX_CloseButton = CreateFrame("Button","AudioX_CloseButton",AudioX_Frame,"UIPanelCloseButton")
  AudioX_CloseButton:SetPoint("TOPRIGHT",5,4)
  AudioX_CloseButton:SetScript("OnClick",function() AX:UI_Hide(); end)
  AudioX_CloseButton:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_CloseButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_CloseButton.tooltiptext = AX.ui_CLOSE
  
  AudioX_SearchBox = CreateFrame("EditBox","AudioX_SearchBox",AudioX_Frame,"InputBoxTemplate")
  AudioX_SearchBox:SetAutoFocus(false)
  AudioX_SearchBox:SetWidth(80)
  AudioX_SearchBox:SetHeight(32)
  AudioX_SearchBox:SetPoint("TOPLEFT",AudioX_Frame,"TOPLEFT",18,-24)
  AudioX_SearchBox:SetHistoryLines(25)
  AudioX_SearchBox:AddHistoryLine(".+ogg$")
  AudioX_SearchBox:AddHistoryLine(".+mp3$")
  AudioX_SearchBox:AddHistoryLine("music")
  AudioX_SearchBox:SetScript("OnShow",function()
   AX:UI_UpdateKeyword()
  end)
  AudioX_SearchBox:SetScript("OnEnterPressed",function()
    AudioX_SearchBox:ClearFocus()
    AudioX_SearchBox:AddHistoryLine(AudioX_SearchBox:GetText()) 
    AX:UI_Search()
  end)
  AudioX_SearchBox:SetScript("OnEscapePressed",function()
    AX:UI_Hide()
  end)
  AudioX_SearchBox:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_SearchBox:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_SearchBox.tooltiptext = AX.ui_TIPKEYWORD

  AudioX_InterpretCheck = CreateFrame("CheckButton","AudioX_InterpretCheck",AudioX_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_InterpretCheck:SetPoint("TOPLEFT",AudioX_SearchBox,"TOPRIGHT",0,-4)
  AudioX_InterpretCheck:SetHitRectInsets(0, 0, 0, 0)
  AudioX_InterpretCheck:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.interpret = AX:S_SetBool_Quietly(AUDIOX_CONFIG.interpret,(self:GetChecked() == 1))  
  end)
  AudioX_InterpretCheck:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_InterpretCheck:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_InterpretCheck.tooltiptext = AX.ui_TIPINTERPRET

  AudioX_SearchButton = CreateFrame("Button","AudioX_SearchButton",AudioX_Frame)
  AudioX_SearchButton:SetNormalTexture("Interface\\Minimap\\TRACKING\\None")
  AudioX_SearchButton:SetPushedTexture("Interface\\Minimap\\TRACKING\\None","ADD")
  AudioX_SearchButton:SetHighlightTexture("Interface\\Minimap\\TRACKING\\None","ADD")
  AudioX_SearchButton:SetPoint("TOPLEFT",AudioX_InterpretCheck,"TOPRIGHT",-4,1)
  AudioX_SearchButton:SetWidth(28)
  AudioX_SearchButton:SetHeight(28)
  AudioX_SearchButton:SetScript("OnClick",function() AX:UI_SearchOrRefresh(); end)
  AudioX_SearchButton:SetScript("OnEnter",AX.UI_TwoUp_OnEnter)
  AudioX_SearchButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_SearchButton.tooltiptext1 = AX.ui_TIPSEARCH1
  AudioX_SearchButton.tooltiptext2 = AX.ui_TIPSEARCH2

  AudioX_PrevButton = CreateFrame("Button","AudioX_PrevButton",AudioX_Frame)
  AudioX_PrevButton:SetNormalTexture("Interface\\BUTTONS\\UI-SpellbookIcon-PrevPage-Up")
  AudioX_PrevButton:SetPushedTexture("Interface\\BUTTONS\\UI-SpellbookIcon-PrevPage-Up","ADD")
  AudioX_PrevButton:SetHighlightTexture("Interface\\BUTTONS\\UI-SpellbookIcon-PrevPage-Down","ADD")
  AudioX_PrevButton:SetDisabledTexture("Interface\\BUTTONS\\UI-SpellbookIcon-PrevPage-Disabled")
  AudioX_PrevButton:SetPoint("TOPLEFT",AudioX_SearchButton,"TOPRIGHT",-2,1)
  AudioX_PrevButton:SetWidth(28)
  AudioX_PrevButton:SetHeight(28)
  AudioX_PrevButton:Disable()
  AudioX_PrevButton:SetScript("OnClick",function() AX:UI_Prev(); end)
  AudioX_PrevButton:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_PrevButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_PrevButton.tooltiptext = AX.ui_TIPPREV
  
  AudioX_NextButton = CreateFrame("Button","AudioX_NextButton",AudioX_Frame)
  AudioX_NextButton:SetNormalTexture("Interface\\BUTTONS\\UI-SpellbookIcon-NextPage-Up")
  AudioX_NextButton:SetPushedTexture("Interface\\BUTTONS\\UI-SpellbookIcon-NextPage-Up","ADD")
  AudioX_NextButton:SetHighlightTexture("Interface\\BUTTONS\\UI-SpellbookIcon-NextPage-Down","ADD")
  AudioX_NextButton:SetDisabledTexture("Interface\\BUTTONS\\UI-SpellbookIcon-NextPage-Disabled")
  AudioX_NextButton:SetPoint("TOPLEFT",AudioX_PrevButton,"TOPRIGHT",-4)
  AudioX_NextButton:SetWidth(28)
  AudioX_NextButton:SetHeight(28)
  AudioX_NextButton:Disable()
  AudioX_NextButton:SetScript("OnClick",function() AX:UI_Next(); end)
  AudioX_NextButton:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_NextButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_NextButton.tooltiptext = AX.ui_TIPNEXT

  AudioX_QuietButton = CreateFrame("Button","AudioX_QuietButton",AudioX_Frame)
  AudioX_QuietButton:SetNormalTexture("Interface\\BUTTONS\\UI-GroupLoot-Pass-Up")
  AudioX_QuietButton:SetPushedTexture("Interface\\BUTTONS\\UI-GroupLoot-Pass-Down")
  AudioX_QuietButton:SetHighlightTexture("Interface\\BUTTONS\\UI-GroupLoot-Pass-Highlight","ADD")
  AudioX_QuietButton:SetPoint("TOPLEFT",AudioX_NextButton,"TOPRIGHT",-2,-1)
  AudioX_QuietButton:SetWidth(24)
  AudioX_QuietButton:SetHeight(24)
  AudioX_QuietButton:SetScript("OnClick",function() AX:UI_Quiet(); end)
  AudioX_QuietButton:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_QuietButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_QuietButton.tooltiptext = AX.ui_TIPQUIET

  AudioX_FavButton = CreateFrame("CheckButton","AudioX_FavButton",AudioX_Frame)
  AudioX_FavButton:SetNormalTexture("SPELLS\\STAR.BLP")
  AudioX_FavButton:SetPushedTexture("SPELLS\\STAR.BLP","ADD")
  AudioX_FavButton:SetCheckedTexture("SPELLS\\T_Star3.blp","ADD")
  AudioX_FavButton:SetHighlightTexture("SPELLS\\T_Star3.blp","ADD")
  AudioX_FavButton:SetPoint("TOPLEFT",AudioX_QuietButton,"TOPRIGHT",-2,-1)
  AudioX_FavButton:SetWidth(22)
  AudioX_FavButton:SetHeight(22)
  AudioX_FavButton:SetChecked(AUDIOX_CONFIG.favs)
  AudioX_FavButton:SetScript("OnClick",function() AX:UI_FavList(true); end)
  AudioX_FavButton:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_FavButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_FavButton.tooltiptext = AX.ui_TIPFAV

  AudioX_OptionsButton = CreateFrame("CheckButton","AudioX_OptionsButton",AudioX_Frame)
  AudioX_OptionsButton:SetNormalTexture("Interface\\Vehicles\\UI-VEHICLES-RAID-ICON.BLP")
  AudioX_OptionsButton:SetPushedTexture("Interface\\Vehicles\\UI-VEHICLES-RAID-ICON.BLP","ADD")
  AudioX_OptionsButton:SetCheckedTexture("Interface\\Vehicles\\UI-VEHICLES-RAID-ICON.BLP","ADD")
  AudioX_OptionsButton:SetHighlightTexture("Interface\\Vehicles\\UI-VEHICLES-RAID-ICON.BLP","ADD")
  AudioX_OptionsButton:SetPoint("TOPLEFT",AudioX_FavButton,"TOPRIGHT",0,1)
  AudioX_OptionsButton:SetWidth(28)
  AudioX_OptionsButton:SetHeight(28)
  AudioX_OptionsButton:SetChecked(InterfaceOptionsFrame:IsShown())
  AudioX_OptionsButton:SetScript("OnClick",function()
    if AX.opt_loaded then
      AX:Options_Toggle()
    else
      if AX:Load_AudioX_Plugin("AudioX_Options") then
        AX:Options_Toggle()
      end
    end
  end)
  AudioX_OptionsButton:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_OptionsButton:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_OptionsButton.tooltiptext = AX.ui_TIPOPTIONS
  AudioX_FooterButton = CreateFrame("Button","AudioX_FooterButton",AudioX_Frame)
  AudioX_FooterButton:SetHeight(18)
  AudioX_FooterButton:SetPoint("LEFT", AudioX_OptionsButton, "RIGHT")
  AudioX_FooterButton:SetPoint("RIGHT",AudioX_Frame,"RIGHT",-24,0)
  AudioX_FooterButton:Hide()

  AudioX_FooterText = AudioX_Frame:CreateFontString("AudioX_FooterText", "DIALOG", "ChatFontNormal")
  AudioX_FooterText:SetHeight(18)
  AudioX_FooterText:SetJustifyH("RIGHT")
  AudioX_FooterText:SetJustifyV("MIDDLE")
  AudioX_FooterText:SetPoint("LEFT", AudioX_OptionsButton, "RIGHT")
  AudioX_FooterText:SetPoint("RIGHT",AudioX_Frame,"RIGHT",-24,0)
  AudioX_FooterText:SetFont("Fonts\\ARIALN.TTF",math.min(axui_config.fontsize,18))
  AudioX_FooterText:SetTextColor(AudioX_TitleText:GetTextColor())
  
  AudioX_BarLeft = AudioX_Frame:CreateTexture("AudioX_BarLeft","OVERLAY")
  AudioX_BarLeft:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-HorizontalBar")
  AudioX_BarLeft:SetWidth(75)
  AudioX_BarLeft:SetHeight(8)
  AudioX_BarLeft:SetPoint("BOTTOMLEFT",AudioX_Frame,"BOTTOMLEFT",4,18)
  AudioX_BarLeft:SetTexCoord(0,0.3,0,0.25)
  
  AudioX_BarRight = AudioX_Frame:CreateTexture("AudioX_BarRight","OVERLAY")
  AudioX_BarRight:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-HorizontalBar")
  AudioX_BarRight:SetWidth(75)
  AudioX_BarRight:SetHeight(8)
  AudioX_BarRight:SetPoint("BOTTOMRIGHT",AudioX_Frame,"BOTTOMRIGHT",1,18)
  AudioX_BarRight:SetTexCoord(0,0.3,0.25,0.5)
  
  AudioX_BarMiddle =  AudioX_Frame:CreateTexture("AudioX_BarMiddle","OVERLAY")
  AudioX_BarMiddle:SetTexture("Interface\\ClassTrainerFrame\\UI-ClassTrainer-HorizontalBar")
  AudioX_BarMiddle:SetHeight(8)
  AudioX_BarMiddle:SetPoint("LEFT",AudioX_BarLeft,"RIGHT")
  AudioX_BarMiddle:SetPoint("RIGHT",AudioX_BarRight,"LEFT")
  AudioX_BarMiddle:SetTexCoord(0.3,0.9,0,0.25)
  
  AudioX_Slider_Frame = CreateFrame("Frame","AudioX_Slider_Frame",AudioX_Frame)
  AudioX_Slider_Frame:SetPoint("TOPRIGHT",AudioX_Frame,"TOPRIGHT",-2,-58)
  AudioX_Slider_Frame:SetPoint("BOTTOMRIGHT",AudioX_BarRight,"TOPRIGHT",-3,-3)
  AudioX_Slider_Frame:SetWidth(1)
  AudioX_Slider_Frame:Hide()
  
  AudioX_Slider_Up = CreateFrame("Button","AudioX_Slider_Up",AudioX_Slider_Frame,"UIPanelScrollUpButtonTemplate")
  AudioX_Slider_Up:SetHeight(16)
  AudioX_Slider_Up:SetPoint("LEFT",AudioX_Slider_Frame,"LEFT")
  AudioX_Slider_Up:SetPoint("TOPRIGHT",AudioX_Slider_Frame,"TOPRIGHT")
  AudioX_Slider_Up:SetScript("OnClick",function ()
    PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
    AudioX_Slider:SetValue(math.max(AudioX_Slider:GetValue()-1,1))
  end)
  AudioX_Slider_Up:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_Slider_Up:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_Slider_Up.tooltiptext = AX.ui_TIPUP
  
  AudioX_Slider_Down = CreateFrame("Button","AudioX_Slider_Down",AudioX_Slider_Frame,"UIPanelScrollDownButtonTemplate")
  AudioX_Slider_Down:SetHeight(16)
  AudioX_Slider_Down:SetPoint("LEFT",AudioX_Slider_Frame,"LEFT")
  AudioX_Slider_Down:SetPoint("BOTTOMRIGHT",AudioX_Slider_Frame,"BOTTOMRIGHT")
  AudioX_Slider_Down:SetScript("OnClick",function ()
    PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
    AudioX_Slider:SetValue(math.min(AudioX_Slider:GetValue()+1,select(2,AudioX_Slider:GetMinMaxValues())))
  end)
  AudioX_Slider_Down:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  AudioX_Slider_Down:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_Slider_Down.tooltiptext = AX.ui_TIPDOWN
  
  AudioX_Slider = CreateFrame("Slider","AudioX_Slider",AudioX_Slider_Frame)
  AudioX_Slider:SetPoint("TOP",AudioX_Slider_Up,"BOTTOM",0,2)
  AudioX_Slider:SetPoint("BOTTOM",AudioX_Slider_Down,"TOP")
  AudioX_Slider:SetPoint("LEFT",AudioX_Slider_Frame,"LEFT")
  AudioX_Slider:SetPoint("RIGHT",AudioX_Slider_Frame,"RIGHT")
  AudioX_Slider:SetOrientation("VERTICAL")
  AudioX_Slider:SetThumbTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
  AudioX_Slider:SetMinMaxValues(1,AX.ui_footermax-AX.ui_shownrows+1)
  AudioX_Slider:SetValue(1)
  -- AudioX_Slider:SetValueStep(1)
  AudioX_Slider:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 12,
    insets = {
      left = 0,
      right = 0,
      top = 5,
      bottom = 5
    }
  })
  AudioX_Slider:SetBackdropColor(0, 0, 0, 0.8)
  AudioX_Slider:SetScript("OnValueChanged",function(self, value)
    AX.s_redosearchpos = math.modf(value)
    AX.ui_sliderchanged = true
  end)

  -- [1] AudioX_PlayButton01, AudioX_PlayButton02 etc
  -- [2] AudioX_FavSfxButton01, AudioX_FavSfxButton02 etc
  -- [3] AudioX_LinkButton01, AudioX_LinkButton02 etc
  -- [4] AudioX_IndexText01, AudioX_IndexText02 etc
  -- [5] AudioX_IndexButton01, AudioX_IndexButton02 etc
  -- [6] AudioX_PathText01, AudioX_PathText02 etc
  -- [7] AudioX_PathButton01, AudioX_PathButton02 etc
  -- [8] AudioX_RowBackgnd01, AudioX_RowBackgnd02 etc
  AX:UI_ResizeRows()
  
  AudioX_Resize = CreateFrame("Button","AudioX_Resize",AudioX_Frame)
  AudioX_Resize:SetNormalTexture("Interface\\Addons\\AudioX_UI\\images\\resize")
  AudioX_Resize:SetPushedTexture("Interface\\Addons\\AudioX_UI\\images\\resize")
  AudioX_Resize:SetHighlightTexture("Interface\\Addons\\AudioX_UI\\images\\resize")
  AudioX_Resize:SetWidth(14)
  AudioX_Resize:SetHeight(14)
  AudioX_Resize:SetPoint("BOTTOMRIGHT",AudioX_Frame,"BOTTOMRIGHT",-3,7)
  AudioX_Resize:SetScript("OnMouseDown",AX.UI_ResizeStart)
  AudioX_Resize:SetScript("OnMouseUp",AX.UI_ResizeStop)
  AudioX_Resize:SetScript("OnHide",AX.UI_ResizeStop)
  AudioX_Resize:SetScript("OnEnter",AX.UI_TwoUp_OnEnter)
  AudioX_Resize:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  AudioX_Resize.tooltiptext1 = AX.ui_TIPRESIZE1
  AudioX_Resize.tooltiptext2 = AX.ui_TIPRESIZE2
  
  AudioX_NoticeText = AudioX_Frame:CreateFontString("AudioX_NoticeText", "DIALOG", "ChatFontNormal")
  AudioX_NoticeText:SetHeight(14)
  AudioX_NoticeText:SetJustifyH("CENTER")
  AudioX_NoticeText:SetJustifyV("MIDDLE")
  AudioX_NoticeText:SetPoint("BOTTOMLEFT",AudioX_Frame,"BOTTOMLEFT",8,7)
  AudioX_NoticeText:SetPoint("BOTTOMRIGHT",AudioX_Frame,"BOTTOMRIGHT",-4,7)
  AudioX_NoticeText:SetFont("Fonts\\ARIALN.TTF",math.min(axui_config.fontsize,14))
  AudioX_NoticeText:SetText("")
  -- AudioX_NoticeText:SetTextColor(1,0.30078125,0.30078125)
  
  for row = 1,AX.ui_shownrows do
    name = AX:UI_MakeName("AudioX_PlayButton",row)
    _G[name]:SetWidth(1)
    name = AX:UI_MakeName("AudioX_FavSfxButton",row)
    _G[name]:SetWidth(1)
    name = AX:UI_MakeName("AudioX_LinkButton",row)
    _G[name]:SetWidth(1)
    name = AX:UI_MakeName("AudioX_IndexText",row)
    _G[name]:SetWidth(1)
    name = AX:UI_MakeName("AudioX_IndexButton",row)
    _G[name]:SetWidth(1)
  end
  
  AudioX_PathText01:SetJustifyH("CENTER")
  AudioX_PathText02:SetJustifyH("CENTER")
  AudioX_PathText03:SetJustifyH("CENTER")
  AudioX_PathText04:SetJustifyH("CENTER")
  AudioX_PathText06:SetJustifyH("CENTER")
  AudioX_PathText01:SetText("AudioX II UI")
  AudioX_PathText02:SetText(AX.version)
  AudioX_PathText03:SetText("Copyright 2009-2011 Eisa of EU Aggramar")
  AudioX_PathText04:SetText("All Rights Reserved")
  if AX.LOCALE_BY ~= "" then
    if GetLocale() == "deDE" then
      AudioX_PathText06:SetText(string.format("(%s: Weggls of EU-Todeswache/A)",AX.LOCALE_BY))
    end
  end
  AudioX_PathText07:SetText(AX.ui_INSTRUCTION)
  AudioX_PathText08:SetText(AX.ui_SEARCHBOX)
  AudioX_PathText09:SetText(AX.ui_SEARCHICON)
  AudioX_PathText10:SetText(AX.ui_PREVICON)
  AudioX_PathText11:SetText(AX.ui_NEXTICON)
  AudioX_PathText12:SetText(AX.ui_PLAYICON)
  AudioX_PathText13:SetText(AX.ui_QUIETICON)
  AudioX_PathText14:SetText(AX.ui_FAVICON)
  AudioX_PathText15:SetText(AX.ui_LINKICON)
  AudioX_PathText17:SetText(AX.ui_CMDTITLE)
  AudioX_PathText18:SetText(string.format(AX.ui_MATCH,AX.s_CMD_MATCH,AX.s_CMD_MATCH))
  AudioX_PathText19:SetText(string.format(AX.ui_BEGIN,AX.s_CMD_BEGIN,AX.s_CMD_BEGIN))
  AudioX_PathText20:SetText(AX.ui_FONT)
  
  AudioX_Frame:SetScript("OnShow",AX.UI_FrameToFront)
  AudioX_Frame:SetScript("OnMouseDown",AX.UI_OnDragStart)
  AudioX_Frame:SetScript("OnMouseUp",AX.UI_OnDragStop)
  AudioX_Frame:SetScript("OnSizeChanged",AX.UI_OnResize)
  AudioX_Frame:SetScript("OnLoad",function() self.timesinceupdate = 0; end)
  AudioX_Frame:SetScript("OnUpdate",AX.UI_OnUpdate)
  AudioX_Frame:EnableMouseWheel(true) 
  AudioX_Frame:SetScript("OnMouseWheel",function(self,delta)
    delta = delta * math.max((math.modf(AX.ui_shownrows/10)),1) -- Change /10 to /5 double speed
    if delta > 0 then
      AudioX_Slider:SetValue(math.min(AudioX_Slider:GetValue()-delta,select(2,AudioX_Slider:GetMinMaxValues())))
    else
      AudioX_Slider:SetValue(math.max(AudioX_Slider:GetValue()-delta,1))
    end
  end)
  AudioX_Frame:SetWidth(axui_config.fwidth)
  AudioX_Frame:SetHeight(axui_config.fheight)
  AudioX_Frame:ClearAllPoints()
  AudioX_Frame:SetPoint(axui_config.fpoint,WorldFrame,axui_config.frelpt,axui_config.fxoff,axui_config.fyoff)
end


-- ========================== Row Components ============================


function AX:UI_MakeRow(row)
  -- [1]
  name = AX:UI_MakeName("AudioX_PlayButton",row)
  _G[name] = CreateFrame("Button",name,AudioX_Frame)
  _G[name]:SetNormalTexture("Interface\\BUTTONS\\UI-GuildButton-MOTD-Up")
  _G[name]:SetPushedTexture("Interface\\BUTTONS\\UI-GuildButton-MOTD-Up","ADD")
  _G[name]:SetHighlightTexture("Interface\\BUTTONS\\UI-GuildButton-MOTD-Up","ADD")
  _G[name]:SetWidth(AX.ui_rowheight * 1.4)
  _G[name]:SetHeight(AX.ui_rowheight)
  if row > 1 then
    _G[name]:SetPoint("TOPLEFT",_G[AX:UI_MakeName("AudioX_PlayButton",row-1)],"BOTTOMLEFT")
  else
    _G[name]:SetPoint("TOPLEFT",AudioX_SearchBox,"BOTTOMLEFT",-8,-2)
  end
  _G[name]:Hide()
  _G[name]:SetScript("OnClick",function() AX:UI_Play(row); end)
  _G[name]:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  _G[name]:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  _G[name].tooltiptext = AX.ui_TIPPLAY

  lastname = name

  -- [2]
  name = AX:UI_MakeName("AudioX_FavSfxButton",row)
  _G[name] = CreateFrame("CheckButton",name,AudioX_Frame)
  _G[name]:SetNormalTexture("SPELLS\\STAR.BLP")
  _G[name]:SetPushedTexture("SPELLS\\STAR.BLP","ADD")
  _G[name]:SetCheckedTexture("SPELLS\\T_Star3.blp","ADD")
  _G[name]:SetHighlightTexture("SPELLS\\T_Star3.blp","ADD")
  _G[name]:SetWidth(AX.ui_rowheight)
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetPoint("TOPLEFT",_G[lastname],"TOPRIGHT")
  _G[name]:Hide()
  _G[name]:SetScript("OnClick",function() AX:UI_FavSfx(row); end)
  _G[name]:SetScript("OnEnter",AX.UI_Generic_OnEnter)
  _G[name]:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  _G[name].tooltiptext = AX.ui_TIPFAVSFX

  lastname = name
  
  -- [3]
  name = AX:UI_MakeName("AudioX_LinkButton",row)
  _G[name] = CreateFrame("Button",name,AudioX_Frame)
  _G[name]:SetNormalTexture("Interface\\TradeSkillFrame\\UI-TradeSkill-LinkButton")
  _G[name]:GetNormalTexture():SetTexCoord(0,1,0,0.5)
  _G[name]:SetPushedTexture("Interface\\TradeSkillFrame\\UI-TradeSkill-LinkButton","ADD")
  _G[name]:GetPushedTexture():SetTexCoord(0,1,0,0.5)
  -- _G[name]:GetPushedTexture():SetTexCoord(0,1,0.5,1)
  _G[name]:SetHighlightTexture("Interface\\TradeSkillFrame\\UI-TradeSkill-LinkButton","ADD")
  _G[name]:GetHighlightTexture():SetTexCoord(0,1,0,0.5)
  -- _G[name]:GetHighlightTexture():SetTexCoord(0,1,0.5,1)
  _G[name]:SetWidth(AX.ui_rowheight * 1.8)
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetPoint("TOPLEFT",_G[lastname],"TOPRIGHT")
  _G[name]:Hide()
  _G[name]:SetScript("OnClick",function() AX:UI_Link(row); end)
  _G[name]:SetScript("OnEnter",AX.UI_TwoUp_OnEnter)
  _G[name]:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  _G[name].tooltiptext1 = AX.ui_TIPLINK1
  _G[name].tooltiptext2 = AX.ui_TIPLINK2
  
  _,odd = math.modf(row/2)
  lastname = name
  
  -- [4]
  name = AX:UI_MakeName("AudioX_IndexText",row)
  _G[name] = AudioX_Frame:CreateFontString(name,"DIALOG",AX.ui_rowfont)
  _G[name]:SetWidth(AX.ui_rowheight * 2.25)
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetJustifyH("RIGHT")
  _G[name]:SetJustifyV("MIDDLE")
  _G[name]:SetPoint("LEFT",_G[lastname],"RIGHT")
  _G[name]:SetFont("Fonts\\ARIALN.TTF",axui_config.fontsize)
  if odd > 0 then
    _G[name]:SetTextColor(0.30078125,1,0.30078125)
  else
    _G[name]:SetTextColor(0.25,0.75,0.25)
  end
  
  -- [5]
  name = AX:UI_MakeName("AudioX_IndexButton",row)
  _G[name] = CreateFrame("Button",name,AudioX_Frame)
  _G[name]:SetWidth(AX.ui_rowheight * 2.25)
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetPoint("LEFT",_G[lastname],"RIGHT")
  _G[name]:Hide()
  _G[name]:SetScript("OnClick",function() AX:UI_RowAct(row); end)
  _G[name]:SetScript("OnEnter",AX.UI_BodyTip_OnEnter)
  _G[name]:SetScript("OnLeave",AX.UI_Generic_OnLeave)

  lastname = name
  
  -- [6]
  name = AX:UI_MakeName("AudioX_PathText",row)    
  _G[name] = AudioX_Frame:CreateFontString(name,"DIALOG",AX.ui_rowfont)
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetJustifyH("LEFT")
  _G[name]:SetJustifyV("MIDDLE")
  _G[name]:SetPoint("LEFT",_G[lastname],"RIGHT",8,0)
  _G[name]:SetPoint("RIGHT",AudioX_Slider_Frame,"LEFT") -- -18
  _G[name]:SetFont("Fonts\\ARIALN.TTF",axui_config.fontsize)
  if odd > 0 then
    _G[name]:SetTextColor(0.30078125,1,0.30078125)
  else
    _G[name]:SetTextColor(0.25,0.75,0.25)
  end

  -- [7]
  name = AX:UI_MakeName("AudioX_PathButton",row)
  _G[name] = CreateFrame("Button",name,AudioX_Frame)
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetPoint("LEFT",_G[lastname],"RIGHT",8,0)
  _G[name]:SetPoint("RIGHT",AudioX_Slider_Frame,"LEFT") -- -18
  _G[name]:Hide()
  _G[name]:SetScript("OnClick",function() AX:UI_RowAct(row); end)
  _G[name]:SetScript("OnEnter",AX.UI_BodyTip_OnEnter)
  _G[name]:SetScript("OnLeave",AX.UI_Generic_OnLeave)
  
  lastname = name
  
  -- [8]
  name = AX:UI_MakeName("AudioX_RowBackgnd",row)
  _G[name] = AudioX_Frame:CreateTexture(name,"ARTWORK")
  _G[name]:SetHeight(AX.ui_rowheight)
  _G[name]:SetPoint("LEFT",AudioX_Frame,"LEFT",8,0)
  _G[name]:SetPoint("RIGHT",AudioX_Slider_Frame,"LEFT") -- -18
  _G[name]:SetPoint("BOTTOM",_G[lastname],"BOTTOM",0,0)
  _G[name]:Hide()
  if odd > 0 then
    _G[name]:SetTexture(1,1,1,0.3)
    _G[name]:SetGradientAlpha("HORIZONTAL",1,1,1,0.3,1,1,1,0.03)
  else
    _G[name]:SetTexture(0,0,0,0)
    _G[name]:SetGradientAlpha("HORIZONTAL",0,0,0,0,0,0,0,0)
  end
end


-- ================== Frame Resizing & Moving Routines ===================


function AX:UI_ResizeRows()
  local height = AudioX_Frame:GetHeight() - 80
  local rowsreq = math.floor(height/AX.ui_rowheight)
  local name,lastname,textw,buttonw
  -- Create any rows that are needed but that don't already exist
  if rowsreq > AX.ui_maxrows then
    for row = (AX.ui_maxrows+1),rowsreq do
      AX:UI_MakeRow(row)
    end
    AX.ui_maxrows = rowsreq
  end
  if AX.ui_shownrows > 0 then
    if AX.ui_shownrows > rowsreq then
      -- Hide existing rows that aren't needed
      for row = AX.ui_shownrows,(rowsreq+1),-1 do
        name = AX:UI_MakeName("AudioX_PlayButton",row)
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_FavSfxButton",row)
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_LinkButton",row)
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_IndexText",row)
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_IndexButton",row)
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_PathText",row)    
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_PathButton",row)
        _G[name]:Hide()
        name = AX:UI_MakeName("AudioX_RowBackgnd",row)
        _G[name]:Hide()
      end
    else
      if not AX.ui_firstsearch then
        -- Show any needed rows. Note: Buttons remain hidden while <Pending>
        for row = (AX.ui_shownrows+1),rowsreq do
          name = AX:UI_MakeName("AudioX_PlayButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_FavSfxButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_LinkButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_IndexText",row)
          _G[name]:SetText("")
          if not AUDIOX_CONFIG.idxinresults then
            _G[name]:SetWidth(AX.ui_rowheight * 2.25)
            _G[name]:Show()
          else
            _G[name]:Hide()
            _G[name]:SetWidth(1)
          end
          name = AX:UI_MakeName("AudioX_IndexButton",row)
          if not AUDIOX_CONFIG.idxinresults then
            _G[name]:SetWidth(AX.ui_rowheight * 2.25)
            _G[name]:Show()
          else
            _G[name]:Hide()
            _G[name]:SetWidth(1)
          end
          name = AX:UI_MakeName("AudioX_PathText",row)
          _G[name]:SetText(AX.ui_PENDING)
          _G[name]:SetTextColor(0.5,0.5,0.5)
          _G[name]:Show()
          name = AX:UI_MakeName("AudioX_PathButton",row)
          _G[name]:Show()
          name = AX:UI_MakeName("AudioX_RowBackgnd",row)
          _G[name]:Show()
        end
      else
        -- Special case for pre-search resizing - show specific rows and hide rest
        for row = (AX.ui_shownrows+1),rowsreq do
           name = AX:UI_MakeName("AudioX_PlayButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_FavSfxButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_LinkButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_IndexText",row)
          _G[name]:Show()
          name = AX:UI_MakeName("AudioX_IndexButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_PathText",row)    
          _G[name]:Show()
          name = AX:UI_MakeName("AudioX_PathButton",row)
          _G[name]:Hide()
          name = AX:UI_MakeName("AudioX_RowBackgnd",row)
          _G[name]:Hide()
        end
      end
    end
  end
  AX.ui_shownrows = rowsreq
end


function AX:UI_ResizeBGTiles()
  local width = AudioX_Frame:GetWidth() - 6
  local bgtilewidth = 256  -- Width of background tile
  local bgtilespan = width/bgtilewidth
  local bgtilesreq = math.ceil(bgtilespan)
  local _,parttile = math.modf(bgtilespan)
  local name,lastname
  if bgtilesreq > AX.ui_maxbgtiles then
    -- Create any tiles that are needed but that don't exist in hidden form
    lastname = AX:UI_MakeName("AudioX_Backgnd",AX.ui_maxbgtiles)
    for idx = (AX.ui_maxbgtiles+1),bgtilesreq do
      name = AX:UI_MakeName("AudioX_Backgnd",idx)
      _G[name] = AudioX_Frame:CreateTexture(name,"BACKGROUND")
      _G[name]:SetTexture("Interface\\WorldStateFrame\\WorldStateFinalScoreFrame-TopBackground")
      _G[name]:SetWidth(256)
      _G[name]:SetHeight(64)
--      _G[name]:SetTexCoordModifiesRect(true)  -- broken by WoW 3.3.3
      if idx > 1 then
        _G[name]:SetPoint("LEFT",lastname,"RIGHT")
      else
        _G[name]:SetPoint("TOPLEFT",5,-4)
      end
      lastname = name
    end
    AX.ui_maxbgtiles = bgtilesreq
  end
  if AX.ui_shownbgtiles > 0 then
    if AX.ui_shownbgtiles > bgtilesreq then
      -- Hide existing tiles that aren't needed
      for idx = AX.ui_shownbgtiles,(bgtilesreq+1),-1 do
        name = AX:UI_MakeName("AudioX_Backgnd",idx)
        _G[name]:Hide()
      end
    else      
      -- Show any needed tiles
      for idx = AX.ui_shownbgtiles,bgtilesreq do
        name = AX:UI_MakeName("AudioX_Backgnd",idx)
        _G[name]:SetWidth(256)
        _G[name]:SetTexCoord(0,1,0,1)
        _G[name]:Show()
      end    
    end
  end
  -- Clip last background sample to size
  name = AX:UI_MakeName("AudioX_Backgnd",bgtilesreq)
  _G[name]:SetWidth(math.max(bgtilewidth*parttile,0))
  _G[name]:SetTexCoord(0,parttile,0,1)
  AX.ui_shownbgtiles = bgtilesreq
end


function AX:UI_ConditionalSlider()
  if AudioX_Slider_Frame:GetHeight() > 70 and AX.ui_footermax > AX.ui_shownrows then
    if AX.ui_sliderhidden and not(AX.ui_firstsearch) then
      AudioX_Slider_Frame:SetWidth(16)
      AudioX_Slider_Frame:Show()
      AX.ui_sliderhidden = false
    end
  else
    if not AX.ui_sliderhidden then
      AudioX_Slider_Frame:Hide()
      AudioX_Slider_Frame:SetWidth(1)
      AX.ui_sliderhidden = true
    end
  end
end


function AX:UI_OnResize()
  AX.ui_windowresized = true
end

 
function AX:UI_ResizeStart()
  self:GetParent():StartSizing()
end


function AX:UI_ResizeStop()
  self:GetParent():StopMovingOrSizing()
  if (AX.ui_firstsearch == false) and AX.UI_refreshsearch then
    AX.ui_rowcount = 1
    AX:UI_SearchWrapper(AX.s_CMD_REFRESH,"")
    AX.UI_refreshsearch = false
  end
  axui_config.fwidth = AudioX_Frame:GetWidth()
  axui_config.fheight = AudioX_Frame:GetHeight()
end


function AX:UI_OnDragStart()
  self:StartMoving()
end
  

function AX:UI_OnDragStop()
  self:StopMovingOrSizing()
  axui_config.fpoint,_,axui_config.frelpt,axui_config.fxoff,axui_config.fyoff = AudioX_Frame:GetPoint()
end


function AX:UI_JustifyPathText()
  local text,l,done
  -- Loop through all rows setting text justification to right if string is full
  -- Made much more complicated by Blizzards failure to trim left sife when text is right aligned (trims right (as in wrong) side!)
  -- Ellipsis \0133 causes issues with fontstring so using 3 fullstops
  if AX.ui_shownrows > 0 then
    for row = 1,AX.ui_shownrows do
      name = AX:UI_MakeName("AudioX_PathText",row)
      strgw = _G[name]:GetStringWidth()
      textw = _G[name]:GetWidth()
      text = _G[name]:GetText()
      done = false
      if strgw > textw then
        _G[name]:Hide()
        text = text .. "...."  -- extra . as ellipsis cut in before they are needed
        done = true
        while strgw > textw do
          l = 1 - string.len(text)
          text = string.sub(text,l)
          _G[name]:SetText(text)
          strgw = _G[name]:GetStringWidth()
        end
      end     
      if done then
        l = string.len(text) - 4
        text = "..." .. string.sub(text,1,l)
        _G[name]:SetText(text)
        _G[name]:Show()
      end      
    end
  end
end

-- ========================== Tooltip Routines ===========================

-- 4.2.0 messy workaround:
--
-- To prevent laggy tooltips, they only update when the OnUpdate window allows.
-- This works by storing the self as AX.ui_gametipself and making a note of which
-- tooltip is required by settign AX.gametiptype (1 for generic, 2 for twoup,
-- 3 for bodytip. When OnUpdate window occurs the appropriate tooltip code is
-- called copying AX.ui_gametipself back to the original routines self variable.
-- Once the tip is shown the AX.ui_gametipself is set to nil (preventing it from being
-- unncessarily refreshed).
-- OnLeave is relatively uneffected, but also sets AX.ui_gametipself to nil
-- to effectively cancel any pending tooltip opening.


function AX:UI_Generic_OnEnter()
  AX.ui_gametipself = self
  AX.ui_gametiptype = 1
end

function AX:UI_Generic()
  self = AX.ui_gametipself  -- WORKAROUND
  GameTooltip:SetOwner(self, "NONE")
  GameTooltip:SetText(self.tooltiptext, nil, nil, nil, nil, 1)
end
  
 
function AX:UI_Generic_OnLeave()
  AX.ui_gametipself = nil  -- WORKAROUND
  ResetCursor()
  GameTooltip:Hide()
end


function AX:UI_TwoUp_OnEnter()
  AX.ui_gametipself = self
  AX.ui_gametiptype = 2
end

function AX:UI_TwoUp()
  self = AX.ui_gametipself  -- WORKAROUND
  GameTooltip:SetOwner(self, "NONE")
  GameTooltip:SetText(self.tooltiptext1, nil, nil, nil, nil, 1)
  GameTooltip:AddLine(self.tooltiptext2)
  GameTooltip:Show() 
end


function AX:UI_BodyTip_OnEnter()
  AX.ui_gametipself = self
  AX.ui_gametiptype = 3
end

function AX:UI_BodyTip() 
  if not AX.ui_firstsearch then
    self = AX.ui_gametipself  -- WORKAROUND
    local row = tonumber(string.sub(self:GetName(),-2))
    row = AX:UI_IdxFromUIRow(row)
    if type(row) == "number" then
      if (row >= 1) and (row <= #_G[AX.searchmode]) then
        GameTooltip_SetDefaultAnchor(GameTooltip, self);
        GameTooltip:SetText(string.format("|c%sAudioX|r",AX.linkcolour))
        GameTooltip:AddLine(AX.TIPBODY1)
        GameTooltip:AddLine(AX.TIPBODY2)
        GameTooltip:AddLine(AX.TIPBODY3)
        GameTooltip:AddLine(AX.TIPBODY4)
        GameTooltip:AddLine(AX.TIPBODY5)
        GameTooltip:AddLine(AX.TIPBODY6)
        local pad = "  "
        local start = 1
        local path = _G[AX.searchmode][row]
        local pos = string.find(path,"\\")
        while pos ~= nil do
          GameTooltip:AddLine(string.format("|cFFCCCCCC%s%s|r",pad,string.sub(path,start,pos)))
          start = pos + 1
          pos = string.find(path,"\\",start)
          pad = pad.."  "
        end
        GameTooltip:AddLine(string.format("|cFFFFFFFF%s%s|r",pad,string.sub(path,start)))
        GameTooltip:Show()
      end
    end
  end
end
        
        
-- ========================== Handy Functions ============================



function AX:UI_UpdateTitle()
  if AX.api_out then
    AudioX_TitleText:SetText(string.format("AudioX II%s",AX.ui_titleapdx))
  else
    AudioX_TitleText:SetText(string.format("|cffff0000AudioX II%s",AX.ui_titleapdx))
  end
end


function AX:UI_MakeName(name,num)
  return name..string.sub(("00"..tostring(num)),-2)
end


function AX:UI_IdxFromUIRow(row)
  if row <= AX.ui_shownrows then
    return tonumber(_G[AX:UI_MakeName("AudioX_IndexText",row)]:GetText())
  end
end


function AX:UI_DoOnFirstSearch()
  if AX.ui_shownrows > 0 then
    for row = 1,AX.ui_maxrows do
      name = AX:UI_MakeName("AudioX_PlayButton",row)
      _G[name]:SetWidth(AX.ui_rowheight * 1.4)
      name = AX:UI_MakeName("AudioX_FavSfxButton",row)
      _G[name]:SetWidth(AX.ui_rowheight)
      name = AX:UI_MakeName("AudioX_LinkButton",row)
      _G[name]:SetWidth(AX.ui_rowheight * 1.8)
      if not AUDIOX_CONFIG.idxinresults then
        name = AX:UI_MakeName("AudioX_IndexText",row)
        _G[name]:SetWidth(AX.ui_rowheight * 2.25)
        name = AX:UI_MakeName("AudioX_IndexButton",row)
        _G[name]:SetWidth(AX.ui_rowheight * 2.25)
      end
    end
  end
  AudioX_PathText01:SetJustifyH("LEFT")
  AudioX_PathText02:SetJustifyH("LEFT")
  AudioX_PathText03:SetJustifyH("LEFT")
  AudioX_PathText04:SetJustifyH("LEFT")
  AudioX_PathText06:SetJustifyH("LEFT")
  AX.ui_firstsearch=false
  AX:UI_ConditionalSlider()
end


function AX:UI_UpdateKeyword()
  local searchbox = AudioX_SearchBox:GetText()
  if searchbox ~= "" then
    if AX.s_userkeyword ~= searchbox then
      AX:UI_SearchWrapper(AX.s_CMD_SEARCH,searchbox)
    end
  end
  if AX.s_userkeyword ~= nil then
    AudioX_SearchBox:SetText(AX.s_userkeyword)
  else
    AudioX_SearchBox:SetText("")
  end
end


function AX:UI_SearchWrapperCore(cmd,keyword)
  if cmd ~= AX.s_CMD_REFRESH then
    AX:UI_UpdateNotice("")
  end
  AX.ui_rowcount = 1
  AX:API_PageSize(AX.ui_shownrows)
  if AX:API_Search(cmd,keyword) then
    if AX.ui_firstsearch then
      AX:UI_DoOnFirstSearch()
    end
    while (AX.ui_rowcount <= AX.ui_shownrows) do
      AX:UI_UpdateRow("","")
    end
  end
  if AX.ui_footerfrom == 1 then
    AudioX_PrevButton:Disable()
    AudioX_Slider_Up:Disable()
  else
    AudioX_PrevButton:Enable()
    AudioX_Slider_Up:Enable()
  end
  if AX.ui_footerto == AX.ui_footermax then
    AudioX_NextButton:Disable()
    AudioX_Slider_Down:Disable()
  else
    AudioX_NextButton:Enable()
    AudioX_Slider_Down:Enable()
  end
  AX:UI_ConditionalSlider()
  AX:UI_JustifyPathText()
  AX:UI_UpdateKeyword()
end


function AX:UI_SearchWrapper(cmd,keyword)
  AX:UI_SearchWrapperCore(cmd,keyword)
  AudioX_Slider:SetMinMaxValues(1,math.max((AX.ui_footermax-AX.ui_shownrows)+1,1))
  AudioX_Slider:SetValue(AX.ui_footerfrom)
end


function AX:UI_ColourRow(row,favmode)
  local index = AX:UI_MakeName("AudioX_IndexText",row)
  local path = AX:UI_MakeName("AudioX_PathText",row)
  local favsfx = AX:UI_MakeName("AudioX_FavSfxButton",row)
  local _,odd = math.modf(row/2)
  if (favmode) or (AX:API_IsFav(AX:UI_IdxFromUIRow(row)) > 0) then
    _G[favsfx]:SetChecked(true)
    if odd > 0 then
      _G[index]:SetTextColor(1,0.30078125,0.30078125)
      _G[path]:SetTextColor(1,0.30078125,0.30078125)
    else
      _G[index]:SetTextColor(0.75,0.25,0.25)
      _G[path]:SetTextColor(0.75,0.25,0.25)
    end
  else
    _G[favsfx]:SetChecked(false)
    if odd > 0 then
      _G[index]:SetTextColor(0.30078125,1,0.30078125)
      _G[path]:SetTextColor(0.30078125,1,0.30078125)
    else
      _G[index]:SetTextColor(0.25,0.75,0.25)
      _G[path]:SetTextColor(0.25,0.75,0.25)
    end
  end
end


-- ================================ Font =================================


function AX:UI_ScaleToFont()
  for row = 1,AX.ui_maxrows do
    name = AX:UI_MakeName("AudioX_PlayButton",row)
    _G[name]:SetWidth(AX.ui_rowheight * 1.4)
    _G[name]:SetHeight(AX.ui_rowheight)
    name = AX:UI_MakeName("AudioX_FavSfxButton",row)
    _G[name]:SetWidth(AX.ui_rowheight)
    _G[name]:SetHeight(AX.ui_rowheight)
    name = AX:UI_MakeName("AudioX_LinkButton",row)
    _G[name]:SetWidth(AX.ui_rowheight * 1.8)
    _G[name]:SetHeight(AX.ui_rowheight)
    name = AX:UI_MakeName("AudioX_IndexText",row)
    _G[name]:SetHeight(AX.ui_rowheight)
    _G[name]:SetWidth(AX.ui_rowheight * 2.25)
    _G[name]:SetFont("Fonts\\ARIALN.TTF",axui_config.fontsize)
    name = AX:UI_MakeName("AudioX_IndexButton",row)
    _G[name]:SetHeight(AX.ui_rowheight)
    name = AX:UI_MakeName("AudioX_PathText",row)    
    _G[name]:SetHeight(AX.ui_rowheight)
    _G[name]:SetFont("Fonts\\ARIALN.TTF",axui_config.fontsize)
    name = AX:UI_MakeName("AudioX_PathButton",row)
    _G[name]:SetHeight(AX.ui_rowheight)
    name = AX:UI_MakeName("AudioX_RowBackgnd",row)
    _G[name]:SetHeight(AX.ui_rowheight)
  end
  AudioX_TitleText:SetFont("Fonts\\FRIZQT__.TTF",math.min(axui_config.fontsize,12))
  AudioX_FooterText:SetFont("Fonts\\ARIALN.TTF",math.min(axui_config.fontsize,18))
  AudioX_NoticeText:SetFont("Fonts\\ARIALN.TTF",math.min(axui_config.fontsize,14))
  AX:UI_ResizeRows()
  AX:UI_SearchWrapper(AX.s_CMD_REFRESH,"")
end


-- ===================== Various OnClick Handlers ========================


function AX:UI_Play(row)
  local music = nil
  if not AX.ui_firstsearch then
    if (IsRightShiftKeyDown()) then
      music = true
    elseif (IsRightControlKeyDown()) then
      music = false
    end
    AX:API_Play(AX:UI_IdxFromUIRow(row),music)
  else
    AudioX_NoticeText:SetText(AX.ui_MUSTSEARCH)
  end
end


function AX:UI_Link(row)
  if not AX.ui_firstsearch then
    PlaySoundFile("Sound\\Interface\\KeyRingOpen.wav")
    if (IsAltKeyDown()) then
      AX:API_LinkSlashCmd(AX:UI_IdxFromUIRow(row))
    else
      AX:API_LinkSoundPath(AX:UI_IdxFromUIRow(row))
    end
  else
    AudioX_NoticeText:SetText(AX.ui_MUSTSEARCH)
  end
end


function AX:UI_FavSfx(row)
  PlaySoundFile("Sound\\Interface\\PlaceHolder.wav")
  AX:API_ToggleFavSample(AX:UI_IdxFromUIRow(row))
  AX.searchbuilt = false
  AX:UI_SearchWrapper(AX.s_CMD_REFRESH,"")
end


function AX:UI_RowAct(row)
  if (IsLeftShiftKeyDown()) or (IsAltKeyDown()) then
    AX:UI_Link(row)
  elseif (IsLeftControlKeyDown()) then
    AX:UI_FavSfx(row)
  else
    AX:UI_Play(row)
  end
end


function AX:UI_Quiet()
  PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
  AX:API_Quiet()
end


function AX:UI_ChangeFontSize(size)
  if type(size) == "number" then
    if size >= AX.ui_fontsize_min and size <= AX.ui_fontsize_max then
      axui_config.fontsize = size
      AX.ui_rowheight = size + 2
      AX:UI_ScaleToFont()
      AX:UI_OnResize()
    end
  end
end


function AX:UI_Search()
  PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
  local text = AudioX_SearchBox:GetText()
  local font = tonumber(string.match(text,"^/f (%d+)$"))
  if font == nil then
    AX:UI_SearchWrapper(AX.s_CMD_SEARCH,text)
  else
    AX:UI_ChangeFontSize(font)
  end
end


function AX:UI_SearchOrRefresh()
  if (IsShiftKeyDown()) then
    PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
    AX:UI_SearchWrapper(AX.s_CMD_REFRESH,"")
  else
    AX:UI_Search()
  end
end


function AX:UI_Next()
  PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
  AX:UI_SearchWrapper(AX.s_CMD_PGDN,"")
end


function AX:UI_Prev()
  PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
  AX:UI_SearchWrapper(AX.s_CMD_PGUP,"")
end


function AX:UI_FavList(complywithbutton)
  if complywithbutton then
    PlaySoundFile("Sound\\Interface\\uChatScrollButton.wav")
    if AudioX_FavButton:GetChecked() == nil then
      AX:API_ToggleFavMode(false)
    else
      AX:API_ToggleFavMode(true)
    end
  else
    AudioX_FavButton:SetChecked(AUDIOX_CONFIG.favs)
  end
  AX.searchbuilt = false
  AX:UI_SearchWrapper(AX.s_CMD_SEARCH,AudioX_SearchBox:GetText())
end


function AX:UI_Hide()
  AX.ui_active = false
  AudioX_SearchBox:ClearFocus()
  PlaySoundFile("Sound\\Interface\\iQuestLogCloseA.wav")
  AudioX_Frame:Hide()
  AX:API_ChatOutput()
end


function AX:UI_Show()
  AX:API_UIOutput()
  AX.ui_active = true
  if not AX.ui_firstsearch then
    AX:UI_SearchWrapper(AX.s_CMD_REFRESH,"")
  end
  AudioX_Frame:Show()
  PlaySoundFile("Sound\\Interface\\iQuestLogOpenA.wav")
end


function AX:UI_Toggle()
  if AudioX_Frame:IsShown() then
    AX:UI_Hide()
  else
    AX:UI_Show()
  end
end


-- =================== Hooks and associated functions ====================


-- = Hook: Redirect search result rows to UI and how/hide unused buttons =

function AX:UI_UpdateRow(key,path)
  local name
  if AX.ui_rowcount <= AX.ui_shownrows then
    name = AX:UI_MakeName("AudioX_IndexText",AX.ui_rowcount)
    _G[name]:SetText(tostring(key))
    if not AUDIOX_CONFIG.idxinresults then
      _G[name]:SetWidth(AX.ui_rowheight * 2.25)
      _G[name]:Show()
    else
      _G[name]:Hide()
      _G[name]:SetWidth(1)
    end
    if AUDIOX_CONFIG.favs then
      local idx = AX:API_IndexFromPath(path,true)
      if idx > 0 then
        _G[AX:UI_MakeName("AudioX_PathText",AX.ui_rowcount)]:SetText(string.format("%s (%s)",AX:API_FilterPathAndExt(path),tostring(idx)))
      else
        _G[AX:UI_MakeName("AudioX_PathText",AX.ui_rowcount)]:SetText(AX:API_FilterPathAndExt(path))
      end
    else
      _G[AX:UI_MakeName("AudioX_PathText",AX.ui_rowcount)]:SetText(AX:API_FilterPathAndExt(path))
    end
    AX:UI_ColourRow(AX.ui_rowcount,(AudioX_FavButton:GetChecked() == 1))
    if (path == "") and (tostring(key) == "") then
      _G[AX:UI_MakeName("AudioX_PlayButton",AX.ui_rowcount)]:Hide()
      _G[AX:UI_MakeName("AudioX_FavSfxButton",AX.ui_rowcount)]:Hide()
      _G[AX:UI_MakeName("AudioX_LinkButton",AX.ui_rowcount)]:Hide()
      _G[AX:UI_MakeName("AudioX_IndexButton",AX.ui_rowcount)]:Hide()
      _G[AX:UI_MakeName("AudioX_PathButton",AX.ui_rowcount)]:Hide()
      _G[AX:UI_MakeName("AudioX_RowBackgnd",AX.ui_rowcount)]:Hide()
    else
      _G[AX:UI_MakeName("AudioX_PlayButton",AX.ui_rowcount)]:Show()
      _G[AX:UI_MakeName("AudioX_FavSfxButton",AX.ui_rowcount)]:Show()
      _G[AX:UI_MakeName("AudioX_LinkButton",AX.ui_rowcount)]:Show()
      name = AX:UI_MakeName("AudioX_IndexButton",AX.ui_rowcount)
      if not AUDIOX_CONFIG.idxinresults then
        _G[name]:SetWidth(AX.ui_rowheight * 2.25)
        _G[name]:Show()
      else
        _G[name]:Hide()
        _G[name]:SetWidth(1)
      end
      _G[AX:UI_MakeName("AudioX_PathButton",AX.ui_rowcount)]:Show()
      _G[AX:UI_MakeName("AudioX_RowBackgnd",AX.ui_rowcount)]:Show()
    end
    AX.ui_rowcount = AX.ui_rowcount + 1
  end
end


function AX:UI_LineHook()
  local API_LineOut_orig = AX.API_LineOut
  
  local function AX_LineOut(self,...)
    local key,path = ...
    if AX.ui_active then
      AX:UI_UpdateRow(key,path)
    else
      API_LineOut_orig(self,key,path)
    end
  end
  
  AX.API_LineOut = AX_LineOut
end


-- ==== Hook: Redirect results footer to AudioX_FooterText UI Object =====


function AX:UI_UpdateFooter(first,last,total,search,tsearch)
  AX.ui_footerfrom = first
  AX.ui_footerto = last
  AX.ui_footermax = total
  local footertmp = ""
  if tsearch ~= nil then
    footertmp = string.format(AX.ui_FOOTER2,tsearch)
  end
  footertmp = string.format("%s%s.",string.format(AX.ui_FOOTER,first,last,total,search),footertmp)
  AudioX_FooterText:SetText(footertmp)
  if AudioX_FooterText:GetWidth() > AudioX_FooterButton:GetWidth() then
    AX.ui_titleapdx = string.format("|cffffffff: %s",footertmp)
    AX:UI_UpdateTitle()
    AudioX_FooterText:SetText("")
  else
    AX.ui_titleapdx = ""
    AX:UI_UpdateTitle()
  end
end


function AX:UI_FootHook()
  local API_PageFooter_orig = AX.API_PageFooter
  
  local function AX_PageFooter(self,...)
    local first,last,total,search,tsearch = ...
    if AX.ui_active then
      AX:UI_UpdateFooter(first,last,total,search,tsearch)
    else
      API_PageFooter_orig(self,first,last,total,search,tsearch)
    end
  end
  
  AX.API_PageFooter = AX_PageFooter
end


-- ====== Hook: Redirect Notices to the AudioX_NoticeText UI object ======

function AX:UI_UpdateNotice(msg)
  AudioX_NoticeText:SetText(msg)
end


function AX:UI_NoticeHook()
  local API_Notice_orig = AX.API_Notice
  
  local function AX_Notice(self,...)
    local msg = ...
    if AX.ui_active then
      AX:UI_UpdateNotice(msg)
    else
      API_Notice_orig(self,msg)
    end
  end
  
  AX.API_Notice = AX_Notice
end


-- ==================== AudioX UI specific Options =======================


function AX:UI_UpdateOptions()
  AudioXUI_Options_Fontsize:SetValue(axui_config.fontsize)
end


function AX:UI_Options_OnUpdate(elapsed)
  AX.ui_opt_timesinceupdate = AX.ui_opt_timesinceupdate + elapsed
  while AX.ui_opt_timesinceupdate > AX.ui_opt_updateinterval do
    AX:UI_UpdateOptions()
    AX.ui_opt_timesinceupdate = AX.ui_opt_timesinceupdate - elapsed
  end
end


function AX:UI_BuildOptions()
  local yoffset = -4

  InterfaceOptionsFrame:SetMovable(true)
  InterfaceOptionsFrame:SetScript("OnMouseDown",function (self) self:StartMoving(); end)
  InterfaceOptionsFrame:SetScript("OnMouseUp",function (self) self:StopMovingOrSizing(); end)

  AudioXUI_Options_Frame = CreateFrame("Frame","AudioXUI_Options_Frame")
  if AX.opt_loaded then
    AudioXUI_Options_Frame.name = "UI Font"
    AudioXUI_Options_Frame.parent = "AudioX II"
  else
    AudioXUI_Options_Frame.name = "AudioX II UI Font"
  end
  AudioXUI_Options_Frame.origfontsize = axui_config.fontsize
  AudioXUI_Options_Frame.okay = function ()
    AudioXUI_Options_Frame.origfontsize = axui_config.fontsize
  end
  AudioXUI_Options_Frame.cancel = function ()
    axui_config.fontsize = AudioXUI_Options_Frame.origfontsize
  end
  AudioXUI_Options_Frame.default = function ()
    axui_config.fontsize = AX.ui_config_defaults.fontsize
  end
  AudioXUI_Options_Frame:SetWidth(300)
  AudioXUI_Options_Frame:SetHeight(410)
  AudioXUI_Options_Frame:SetFrameStrata("DIALOG")
  AudioXUI_Options_Frame:Hide()
  AudioXUI_Options_Frame:SetScript("OnUpdate",AX.UI_UpdateOptions)
  AudioXUI_Options_Frame:SetScript("OnUpdate",AX.UI_Options_OnUpdate)
  
  AudioXUI_Options_TitleText = AudioXUI_Options_Frame:CreateFontString("AudioXUI_Options_TitleText","DIALOG","GameFontNormalLarge")
  AudioXUI_Options_TitleText:SetPoint("TOPLEFT",16,-16)
  AudioXUI_Options_TitleText:SetText("AudioX II UI Options")
  
  AudioXUI_Options_Fontsize = CreateFrame("Slider","AudioXUI_Options_Fontsize",AudioXUI_Options_Frame,"OptionsSliderTemplate")
  AudioXUI_Options_Fontsize:SetWidth(380)
  AudioXUI_Options_Fontsize:SetHeight(16)
  AudioXUI_Options_Fontsize:SetPoint("TOPLEFT",AudioXUI_Options_TitleText,"BOTTOMLEFT",0,-16+yoffset)
  AudioXUI_Options_FontsizeLow:SetText(tostring(AX.ui_fontsize_min))
  AudioXUI_Options_FontsizeHigh:SetText(tostring(AX.ui_fontsize_max))
  AudioXUI_Options_Fontsize:SetMinMaxValues(AX.ui_fontsize_min,AX.ui_fontsize_max)
  AudioXUI_Options_Fontsize:SetValueStep(1)
  AudioXUI_Options_Fontsize:SetScript("OnValueChanged", function(self,value)
    axui_config.fontsize = value
    AudioXUI_Options_FontsizeText:SetFormattedText(AX.ui_OPT_FONTSIZE,value)
  end)
  
  InterfaceOptions_AddCategory(AudioXUI_Options_Frame)
end
