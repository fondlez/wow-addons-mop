LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject("AudioX", {
  type = "launcher",
  label = "AudioX",
  icon = "Interface\\Icons\\Spell_unused2.blp",
  OnClick = function(clickedframe, button)
    if button == "LeftButton" then
      if AX.ui_loaded then
        AX:UI_Toggle()
      else
        AX:Load_AudioX_Plugin("AudioX_UI")
      end
    else
      if AX.opt_loaded then
        AX:Options_Toggle()
      else
        if AX:Load_AudioX_Plugin("AudioX_Options") then
          AX:Options_Toggle()
        end
      end
    end
  end,
  OnTooltipShow = function(tooltip)
    if not tooltip or not tooltip.AddLine then return end
    tooltip:AddLine("AudioX",1,1,1)
    tooltip:AddLine(string.format("|c%s%s",AX.linkcolour,AX.ldb_LEFTCLICK))
    tooltip:AddLine(string.format("|c%s%s",AX.linkcolour,AX.ldb_RIGHTCLICK))
  end,
})
