AX.ldb_LEFTCLICK	= "Left-Click|r to open AudioX UI."
AX.ldb_RIGHTCLICK	= "Right-Click|r to open AudioX Options."

-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.ldb_LEFTCLICK		= "Linke Maustaste|r um AudioX Oberfl\195\164che zu \195\182ffnen."
  AX.ldb_RIGHTCLICK		= "Rechte Maustaste|r um die AudioX Optionen zu \195\182ffnen."

elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end