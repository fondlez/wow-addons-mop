--[[
===========================================================================
                              AudioX II Who
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================
]]--


local f = CreateFrame("Frame")
f.TimeSinceLastUpdate = 0
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(addon)
  if addon ~= "AudioX_Who" then
    return
  else
    self:UnregisterEvent("ADDON_LOADED")
    AX:Who_Initialise()
    -- Pause for 10 secs before sending inital broadcasts
    f.lastrosterupdate = 0
    f.rosterinterval = 10
    f:SetScript("OnUpdate", function(self,elapsed)
      -- Update guild roster
      self.lastrosterupdate = self.lastrosterupdate + elapsed
      if (self.lastrosterupdate >= self.rosterinterval) then
        RegisterAddonMessagePrefix("AudioX")
        if IsAddonMessagePrefixRegistered("AudioX") then
          AX:Who_Start()
        else
          AX:Print(AX.who_HALT)
        end
      end
    end)
  end
end


function f:PLAYER_LEAVING_WORLD()
  AX:Who_BroadcastToAllNow(AX.who_logout)
end


function f:GROUP_ROSTER_UPDATE(...)
  AX:Who_BroadcastToGroup(AX.who_ping)
end


function f:GUILD_ROSTER_UPDATE(...)
  AX:Who_BroadcastToGuild(AX.who_ping)
end


function f:FRIENDLIST_UPDATE(...)
  AX:Who_BroadcastToFriends(AX.who_ping)
end


function f:CHAT_MSG_ADDON(...)
  local addon,message,channel,sender = ...
  if addon ~= "AudioX" then
    return
  else
    AX:Who_Received(channel,sender,message)
  end
end


f:SetScript("OnEvent", function(self, event, ...)
  self[event](self, ...)
end)


-- ========================== Initialisation ============================


function AX:MakeSysMsgPattern(sysmsgvar)
  return string.format("^%s$",string.gsub(string.gsub(sysmsgvar,"([%$%%%^%(%)%.%[%]%*%+%-%?])","%%%1"),"%%%%s","%(%%w+%)"))
end


function AX:Who_InitVars()
  AUDIOX_WHOLIST		= {}
  --
  AX.who_loaded			= true
  --
  AX.who_delay			= 0
  AX.who_sendtimer		= 0
  AX.who_sendinterval		= 0.025  -- Minimum value of 0.025 (= 4 msgs every 0.1sec)
  AX.who_sendqueue		= {}
  --
  AX.who_senttoparty		= false
  AX.who_senttoraid		= false
  AX.who_senttobattleground	= false
  AX.who_senttoguild		= false
  AX.who_senttofriends		= false
  --
  AX.who_numinparty		= AX:Who_NumChannelOnline("PARTY")
  AX.who_numinraid		= AX:Who_NumChannelOnline("RAID")
  AX.who_numinbattleground	= AX:Who_NumChannelOnline("INSTANCE_CHAT")
  AX.who_numinguild		= AX:Who_NumChannelOnline("GUILD")
  AX.who_numinfriends		= AX:Who_NumChannelOnline("WHISPER")
  --
  AX.who_logout			= "X"
  AX.who_ping			= string.format("P%s",AX.version)
  AX.who_pong			= string.format("R%s",AX.version)
end


function AX:Who_Initialise()
  AX:Who_InitVars()
  AX:Print(string.format(AX.who_NB_LOADED,AX.linkcolour,SLASH_AUDIOX1))
end


function AX:Who_Start()
  -- Start watching for AudioX Comms
  f:RegisterEvent("CHAT_MSG_ADDON")
  f:RegisterEvent("GROUP_ROSTER_UPDATE")
  f:RegisterEvent("GUILD_ROSTER_UPDATE")
  f:RegisterEvent("FRIENDLIST_UPDATE")

  AX:Who_BroadcastToAll(AX.who_ping)

  f.lastrosterupdate = 0 
  f.rosterinterval = 15
  f.postgsendinterval = 600
  f:SetScript("OnUpdate", function(self,elapsed)
    -- Update guild roster
    self.lastrosterupdate = self.lastrosterupdate + elapsed
    if (self.lastrosterupdate >= self.rosterinterval) then
      if (AX.who_senttoguild == false) or (self.lastrosterupdate >= f.postgsendinterval) then
        if (IsInGuild()) then
          GuildRoster()
        end
        self.lastrosterupdate = 0
      end
    end
    -- Process chat queue
    if elapsed ~= nil then
      AX.Who_DoQueue(self,elapsed)
    end
  end)
end


-- ======================== Who List Management ========================


function AX:Who_NumChannelOnline(channel) -- Doesn't include self
  local online = 0
  local total,infosel,infofunc,isinchannel
  local pvpinst = select(2,IsInInstance) == "pvp"
  if channel == "GUILD" then
    total = (GetNumGuildMembers(true))
    infosel = 9
    infofunc = "GetGuildRosterInfo"
    online = -1
  elseif channel == "RAID" or channel == "INSTANCE_CHAT" then
    if channel == "INSTANCE_CHAT" and select(2,IsInInstance()) ~= "pvp" then
      channel = "skip"
    elseif channel == "RAID" and select(2,IsInInstance()) == "pvp" then
      channel = "skip"
    else
      total = (GetNumGroupMembers())
      infosel = 8
      infofunc = "GetRaidRosterInfo"
      online = -1
    end
  elseif channel == "WHISPER" then -- assume friend
    total = (GetNumFriends())
    infosel = 5
    infofunc = "GetFriendInfo"
  end
  if channel == "GUILD" or channel == "RAID" or channel == "INSTANCE_CHAT" or channel == "WHISPER" then
    if total > 0 then
      for i = 1,total do
       if select(infosel,_G[infofunc](i)) then
          online = online + 1
       end
      end
    end
  elseif channel == "PARTY" then
    total = (GetNumSubgroupMembers())
    if total > 0 then
      for i = 1,total do
        if UnitIsConnected(string.format("party%d",i)) then
          online = online + 1
        end
      end
    end
  end
  return math.max(0,online)
end


function AX:Who_Find(seeking)
  local low = 1
  local high = #AUDIOX_WHOLIST
  local mid
  while low <= high do
    mid = math.floor((high-low)/2)+low
    if seeking < AUDIOX_WHOLIST[mid][1] then      
      high = mid - 1
    elseif seeking > AUDIOX_WHOLIST[mid][1] then
      low = mid + 1
    else -- seeking == AUDIOX_WHOLIST[mid][1]
      return mid
    end
  end
  return low * -1
end


function AX:Who_IsInFriends(player)
  local ret = false
  if (GetNumFriends()) > 0 then
    for i=1,(GetNumFriends()) do
      local name,_,_,_,online = GetFriendInfo(i)
      if name == player and online ~= nil then
        ret = true
        break
      end
    end
  end
  return ret
end


function AX:Who_IsInGuild(player)
  local ret = false
  if (IsInGuild()) then
    for i = 1,GetNumGuildMembers(true) do
      local name,_,_,_,_,_,_,_,online = GetGuildRosterInfo(i)
      if name == player and online ~= nil then
        ret = true
        break
      end
    end
  end
  return ret
end


function AX:Who_IsInGrouptype(player,grouptype)  -- grouptype must be either "party" or "raid"
  local unitintype,getnumtypemembers
  if grouptype == "party" then
    unitintype = "UnitInParty"
    getnumtypemembers = "GetNumSubgroupMembers"
  else
    unitintype = "UnitInRaid"
    getnumtypemembers = "GetNumGroupMembers"
  end
  local ret = false
  if _G[unitintype]("player") then
    if _G[getnumtypemembers]() > 0 then
      for i = 1,_G[getnumtypemembers]() do
        if UnitName(string.format("%s%d",grouptype,i)) == player then
          ret = true
          break
        end
      end
    end
  end
  return ret
end


function AX:Who_CheckRosters(pos,sender)
  AUDIOX_WHOLIST[pos].friend = AX:Who_IsInFriends(sender)
  AUDIOX_WHOLIST[pos].guild = AX:Who_IsInGuild(sender)
  if select(2,IsInInstance()) ~= "pvp" then
    AUDIOX_WHOLIST[pos].battleground = false
    AUDIOX_WHOLIST[pos].raid = AX:Who_IsInGrouptype(sender,"raid")
    AUDIOX_WHOLIST[pos].party = AX:Who_IsInGrouptype(sender,"party")
  else
    AUDIOX_WHOLIST[pos].battleground = AX:Who_IsInGrouptype(sender,"raid")
    if GetNumSubgroupMembers() < 1 then
      AUDIOX_WHOLIST[pos].party = false
    end
    if GetNumGroupMembers() < 1 then
      AUDIOX_WHOLIST[pos].raid = false
    end
  end
end


function AX:Who_Add(pos,sender,msg)
  AX:Print(string.format("AudioX> %s %s",sender,AX.who_ONLINE))
  table.insert(AUDIOX_WHOLIST,pos,{
    sender; 
    friend = false,
    guild = false,
    party = false,
    raid = false,
    battleground = false,
    version = string.sub(msg,2),  -- string.sub(msg,1,1) reserved for 'commands'
  })
  AX:Who_CheckRosters(pos,sender)
end


function AX:Who_Delete(pos)
  AUDIOX_WHOLIST[pos].friend = nil
  AUDIOX_WHOLIST[pos].guild = nil
  AUDIOX_WHOLIST[pos].party = nil
  AUDIOX_WHOLIST[pos].raid = nil
  AUDIOX_WHOLIST[pos].battleground = nil
  AUDIOX_WHOLIST[pos].version = nil
  AUDIOX_WHOLIST[pos][1] = nil
  table.remove(AUDIOX_WHOLIST,pos)
end


function AX:Who_DeleteUnflagged(pos)
  if (AUDIOX_WHOLIST[pos].guild
       or AUDIOX_WHOLIST[pos].raid
       or AUDIOX_WHOLIST[pos].battleground
       or AUDIOX_WHOLIST[pos].party
       or AUDIOX_WHOLIST[pos].friend
     ) == false then
    AX:Who_Delete(pos)
  end
end

function AX:Who_SetChannelFlag(pos,channel,settrue)
-- IMPORTANT: If called from within a loop and settrue is false, the loop must iterate thru pos backwards from N to 1. *NEVER* 1 to N!
  channel = string.lower(channel)
  if channel == "whisper" then
    channel = "party"
  end
  AUDIOX_WHOLIST[pos][channel] = settrue
  if not settrue then
    AX:Who_DeleteUnflagged(pos)
  end
end


function AX:Who_UnsetChannelFlags(channel)
  if #AUDIOX_WHOLIST > 0 then
    for pos=#AUDIOX_WHOLIST,1,-1 do
      AX:Who_SetChannelFlag(pos,channel,false)
    end
  end
end


function AX:Who_SetChannelFlagByName(name,channel,settrue)
  local pos = AX:Who_Find(name)
  if pos > 0 then
    AX:Who_SetChannelFlag(pos,channel,settrue)
  end
end


function AX:Who_PreDisplayCheck()
  local name,online
  if #AUDIOX_WHOLIST > 0 then
    -- Clear all channel flags (making provision for raid + party if in a battleground)
    for i=1,#AUDIOX_WHOLIST do
      AUDIOX_WHOLIST[i].guild = false
      AUDIOX_WHOLIST[i].friend = false
      if select(2,IsInInstance()) ~= "pvp" then -- preserve pve party and pve raid flags while in battleground
        AUDIOX_WHOLIST[i].party = false
        AUDIOX_WHOLIST[i].raid = false
      else
        if GetNumSubgroupMembers() < 1 then  -- 1 because self = 0   !CHECK!
          AUDIOX_WHOLIST[i].party = false
        end
        if GetNumGroupMembers() < 2 then  -- 2 because self = 1    !CHECK!
          AUDIOX_WHOLIST[i].raid = false
        end
      end
      AUDIOX_WHOLIST[i].battleground = false
    end
    -- Guild check
    if (IsInGuild()) then
      for i=1,(GetNumGuildMembers(true)) do
        name,_,_,_,_,_,_,_,online = GetGuildRosterInfo(i)
        if online ~= nil then
          AX:Who_SetChannelFlagByName(name,"guild",true)
        end
      end
    end
    -- Friend check
    if (GetNumFriends()) > 0 then
      for i=1,(GetNumFriends()) do
        name,_,_,_,online = GetFriendInfo(i)
        if online ~= nil then
          AX:Who_SetChannelFlagByName(name,"friend",true)
        end
      end
    end
    if select(2,IsInInstance()) ~= "pvp" then  -- not in a battleground
      -- Party check
      if (UnitInParty("player")) then
        for i=1,GetNumSubgroupMembers() do
          AX:Who_SetChannelFlagByName(UnitName(string.format("party%d",i)),"party",true)
        end
      end
      -- Raid check
      if (UnitInRaid("player")) then
        for i=1,GetNumGroupMembers() do
          AX:Who_SetChannelFlagByName(UnitName(string.format("raid%d",i)),"raid",true)
        end
      end
    else  -- in a battleground
      -- Battleground check
      if (UnitInRaid("player")) then
        for i=1,GetNumGroupMembers(LE_PARTY_CATEGORY_INSTANCE) do
          AX:Who_SetChannelFlagByName(UnitName(string.format("raid%d",i)),"battleground",true)
        end
      end
    end
    -- Delete entries where guild, friends, party, raid and battleground are all false
    for i=#AUDIOX_WHOLIST,1,-1 do
      AX:Who_DeleteUnflagged(i)
    end
  end
end

function AX:Who_ChannelRGB(channel,coloured)
  local ret,tag
  if channel ~= "WHISPER" then
    tag = string.sub(channel,1,1)
  else
    tag = "F"
  end
  if coloured then
    local r = ChatTypeInfo[channel].r * 0xFF
    local g = ChatTypeInfo[channel].g * 0xFF
    local b = ChatTypeInfo[channel].b * 0xFF
    ret = string.format("|cff%02x%02x%02x%s",r,g,b,tag)
  else
    ret = string.format("|c00333333%s",tag)
  end
  return ret
end


function AX:Who_DisplayList()
  AX:Who_PreDisplayCheck()
  if #AUDIOX_WHOLIST > 0 then 
    AX:Print(AX.who_HEADER)
    local r,g,b,perp,vers
    for pos,rec in ipairs(AUDIOX_WHOLIST) do
      perp = string.sub(string.format("%s%s",AUDIOX_WHOLIST[pos][1],string.rep(" ",12)),1,12)
      vers = AUDIOX_WHOLIST[pos].version
      AX:Print(string.format("|c%s%s %s%s%s%s%s|r %s",AX.linkcolour,
        vers,
        AX:Who_ChannelRGB("WHISPER",AUDIOX_WHOLIST[pos].friend),
        AX:Who_ChannelRGB("GUILD",AUDIOX_WHOLIST[pos].guild),
        AX:Who_ChannelRGB("PARTY",AUDIOX_WHOLIST[pos].party),
        AX:Who_ChannelRGB("RAID",AUDIOX_WHOLIST[pos].raid),
        AX:Who_ChannelRGB("INSTANCE_CHAT",AUDIOX_WHOLIST[pos].battleground),
        perp)
      )
    end
  else
    AX:Print(AX.who_EMPTY)
  end
end


-- ============================ Send Queue =============================


function AX:Who_SendAddonMsg(message,channel,recipient)
  if channel ~= "WHISPER" then
    SendAddonMessage("AudioX",message,channel)
  else
    SendAddonMessage("AudioX",message,channel,recipient)
  end
end


function AX:Who_QueueRemove(ele)
  AX.who_sendqueue[ele].channel = nil
  AX.who_sendqueue[ele].message = nil
  AX.who_sendqueue[ele][1] = nil
  table.remove(AX.who_sendqueue,ele)
end


function AX:Who_QueueSend(msg,chan,name)
  chan = tostring(chan)
  if chan ~= "nil" then
    name = tostring(name)
    if name ~= "nil" or chan ~= "WHISPER" then 
      local ele = #AX.who_sendqueue + 1
      table.insert(AX.who_sendqueue,ele,{
        name;
        channel = chan,
        message = msg,
      })
    end
  end
end


function AX:Who_DoQueue(elapsed)
  AX.who_sendtimer = AX.who_sendtimer + elapsed
  if (AX.who_sendtimer >= AX.who_sendinterval) then
    if (AX.who_sendtimer >= AX.who_delay) then
      if (#AX.who_sendqueue > 0) then
        if AX.who_sendqueue[1].channel ~= "delay" then
          AX:Who_SendAddonMsg(AX.who_sendqueue[1].message,AX.who_sendqueue[1].channel,AX.who_sendqueue[1][1])
          AX.who_delay =  0
        else
          AX.who_delay = tonumber(AX.who_sendqueue[1].message) * AX.who_sendinterval
        end
        AX:Who_QueueRemove(1)
        AX.who_sendtimer = 0
      end
    end
  end
end


-- ============================= Queue Chat ============================


function AX:Who_AddDelay(numintervals)
  AX:Who_QueueSend(tostring(numintervals),"delay","")
end


function AX:Who_AddRndDelay(channel)
  local delay
  if channel == "GUILD" then
    delay = AX:Who_NumChannelOnline("GUILD")
  elseif channel == "PARTY" then
    delay = AX:Who_NumChannelOnline("PARTY")
  elseif channel == "RAID" or channel == "INSTANCE_CHAT" then
    delay = AX:Who_NumChannelOnline("RAID")
  elseif channel == "WHISPER" then -- Assume friend
    delay = AX:Who_NumChannelOnline("WHISPER")
  else
    delay = 0
  end
  if delay > 0 then
    return ((math.random(1,(delay*100))) / 100) * AX.who_sendinterval
  else
    return 0
  end
end


function AX:Who_BroadcastToGuild(message)
  if (IsInGuild()) then
    AX.who_numinguild = AX:Who_NumChannelOnline("GUILD")
  else
    AX.who_numinguild = 0
  end
  if AX.who_numinguild > 0 then
    if not AX.who_senttoguild then
      AX.who_senttoguild = true
      AX:Who_QueueSend(message,"GUILD",nil)
      AX:Who_AddDelay(AX.who_numinguild)
    end
  else
    if AX.who_senttoguild then
      AX:Who_UnsetChannelFlags("GUILD") -- Not really needed, but reduces WhoList size if player doesn't /ax who after leaving guild
      AX.who_senttoguild = false
    end
  end
end


function AX:Who_BroadcastToParty(message)
-- IMPORTANT: Don't call directly. Use AX:Who_BroadcastToGroup()
  if not AX.who_senttoparty then
    AX.who_senttoparty = true
    AX:Who_QueueSend(message,"PARTY",nil)
    AX:Who_AddDelay(AX.who_numinparty)
  end
end


function AX:Who_BroadcastToRaid(message)
-- IMPORTANT: Don't call directly. Use AX:Who_BroadcastToGroup()
  if not AX.who_senttoraid then
    AX.who_senttoraid = true
    AX:Who_QueueSend(message,"RAID",nil)
    AX:Who_AddDelay(AX.who_numinraid)
  end
end


function AX:Who_BroadcastToBattleground(message)
-- IMPORTANT: Don't call directly. Use AX:Who_BroadcastToGroup()
  if not AX.who_senttobattleground then
    AX.who_senttobattleground = true
    AX:Who_QueueSend(message,"INSTANCE_CHAT",nil)
    AX:Who_AddDelay(AX.who_numinbattleground)
  end
end


function AX:Who_BroadcastToGroup(message)
-- Note: AX:Who_RemoveChan lines in this proceedure are aren't really required as
--   AX:Who_PreDisplayCheck purges any players outside of the current group rosters. 
--   However, they remove left groups keeping memory usage down should the player fail to /ax who.
  if (UnitInRaid("player") ~= nil) then
    if select(2,IsInInstance()) == "pvp" then
      AX.who_numinbattleground = AX:Who_NumChannelOnline("INSTANCE_CHAT")
      if AX.who_numinbattleground > 0 then
        AX:Who_BroadcastToBattleground(message)
      end
    else
      if AX.who_senttobattleground then
        AX:Who_UnsetChannelFlags("INSTANCE_CHAT")
        AX.who_senttobattleground = false
      end
      AX.who_numinraid = AX:Who_NumChannelOnline("RAID")
      if AX.who_numinraid > 0 then
        AX:Who_BroadcastToRaid(message)
      end
    end
  else
    if AX.who_senttobattleground then
      AX:Who_UnsetChannelFlags("INSTANCE_CHAT")
      AX.who_senttobattleground = false
    end
    if AX.who_senttoraid then
      AX:Who_UnsetChannelFlags("RAID")
      AX.who_senttoraid = false
    end
    AX.who_numinparty = AX:Who_NumChannelOnline("PARTY")
    if AX.who_numinparty < 1 then
      if AX.who_senttoparty then
        AX:Who_UnsetChannelFlags("PARTY")
        AX.who_senttoparty = false
      end
    else
      AX:Who_BroadcastToParty(message)
    end
  end
end


function AX:Who_BroadcastToFriends(message)
  if not AX.who_senttofriends then
    AX.who_senttofriends = true
    AX.who_numinfriends = AX:Who_NumChannelOnline("WHISPER")
    if AX.who_numinfriends > 0 then 
      for i=1,(GetNumFriends()) do
        name,_,_,_,connected,_,_ = GetFriendInfo(i)
        if connected ~= nil then
          AX:Who_QueueSend(message,"WHISPER",name)
        end
      end
      AX:Who_AddDelay(AX.who_numinfriends)
    end
  end
end


function AX:Who_BroadcastToAll(message)
  AX:Who_BroadcastToGuild(message)
  AX:Who_BroadcastToGroup(message)
  AX:Who_BroadcastToFriends(message)
end


function AX:Who_BroadcastToAllNow(message)
  SendAddonMessage("AudioX",message,"GUILD")
  SendAddonMessage("AudioX",message,"PARTY")
  SendAddonMessage("AudioX",message,"RAID")
  SendAddonMessage("AudioX",message,"INSTANCE_CHAT")
  AX.who_numinfriends = AX:Who_NumChannelOnline("WHISPER")
  if AX.who_numinfriends > 0 then 
    for i=1,(GetNumFriends()) do
      name,_,_,_,connected,_,_ = GetFriendInfo(i)
      if connected ~= nil then
        SendAddonMessage("AudioX",message,"WHISPER",name)
      end
    end
  end
end


-- ========================== Recieved Chat ============================


function AX:Who_MakeSenderName(channel,sender)
  local ret = sender
  if channel == "PARTY" or channel == "RAID" or channel == "INSTANCE_CHAT" then
    local unitintype,getnumtypemembers,grouptype,realm,name
    if channel == "PARTY" then
      unitintype = "UnitInParty"
      getnumtypemembers = "GetNumSubgroupMembers"
      grouptype = "party"
    else
      unitintype = "UnitInRaid"
      getnumtypemembers = "GetNumGroupMembers"
      grouptype = "raid"
    end
    if _G[unitintype]("player") then
      if _G[getnumtypemembers]() > 0 then
        for i = 1,_G[getnumtypemembers]() do
          name,realm = UnitName(string.format("%s%d",grouptype,i))
          if name == sender then
            if realm ~= nil and realm ~= "" then
              ret = string.format("%s-%s",name,realm)
            end
            break
          end
        end
      end
    end
  end
  return ret
end


function AX:Who_Received(channel,sender,message)
  if sender ~= UnitName("player") then
    sender = AX:Who_MakeSenderName(channel,sender)
    local pos = AX:Who_Find(sender)
    if pos > 0 then  -- entry found
      if string.sub(message,1,1) ~= AX.who_logout then
        AX:Who_SetChannelFlag(pos,channel,true)
      else
        AX:Who_Delete(pos)
      end
    elseif string.sub(message,1,1) ~= AX.who_logout then  -- new audiox user discovered
      AX:Who_Add((pos * -1),sender,message)
    end
    if string.sub(message,1,1) == "P" then  -- PING
      AX:Who_AddRndDelay(channel)
      AX:Who_QueueSend(AX.who_pong,"WHISPER",sender)
    end
  end
end