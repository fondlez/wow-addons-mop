AX.who_EMPTY		= "AudioX users online:- None."
AX.who_HEADER		= "AudioX users online (in /g, /p, /ra or /bg):-"
AX.who_NB_LOADED	= "Loaded: |c%sAudioX II Who *BETA*|r. %s who to list AudioX users."
AX.who_ONLINE		= " is using AudioX."
AX.who_HALT		= "AudioX Who unable to register prefix for addon channels."

-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.who_EMPTY			= "AudioX Benutzer online:- Keine."
  AX.who_HEADER			= "AudioX Benutzer online (in /g, /p, /ra oder /bg):-"
  AX.who_NB_LOADED		= "Geladen: |c%sAudioX II Who *BETA*|r. %s wer um AudioX anzuzeigen."
  AX.who_ONLINE			= " benutzt AudioX."

elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end