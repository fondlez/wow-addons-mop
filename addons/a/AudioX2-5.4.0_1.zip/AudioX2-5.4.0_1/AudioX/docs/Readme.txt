
                                AudioX II
                  Copyright 2009-2012 Eisa of EU Aggramar
                           All Rights Reserved


AudioX provides players with the ability to explore 54,932 World of Warcraft
sound samples. It also allows you to exchange samples with other AudioX users via
chat hyperlinks. 



IMPORTANT BETA INFO FOR AUDIOX_WHO
The AudioX_Who plugin has only received limited testing and requires a public
beta to isolate any bugs. It is strongly advised that players using AudioX_Who
read the associated FAQ at:-
http://www.wowinterface.com/portal.php?id=574&a=faq&faqid=578

Translators needed - please apply localizations at:- 
http://wow.curseforge.com/addons/audiox/localization/



Current Features:

AudioX:
- Displays samples as chat links (either in text or icon form).
- Clicking on an AudioX chat-link play samples.
- AudioX links work in custom channels, without any other chat mods required.
- Exchange AudioX chat-links with other AudioX users by shift+clicking to insert the link into your outgoing message.
- Insert the full /script PlaySoundFile(...) command into an outgoing message by alt+clicking AudioX links.
- Silence audio playback by ctrl+alt+clicking any AudioX link (max of once every 5 seconds).
- Ctrl+clicking links adds them to AudioX's favourites list.
- Handles AudioX Search loading.
- Localization support.

AudioX Search (Optional):
- Search through 54,932 World of Warcraft samples.
- Sample library contains all of the samples upto and including 5.4.0.17399
- Play samples by a short index number (handy in macros).
- Define how many results AudioX returns per search.
- Crop links to limit word wrapping.
- Continue searches from the end your previous search onwards, or backwards.
- Start searching from a specific index (to skip unwanted samples).
- Create and display output to a seperate AudioX chat tab.
- Allows searching of your AudioX favourites.
- Features a miniAPI for 3rd party AudioX UI developers.
- Localization support.

AudioX Options (Optional):
- Set page length, line cropping, chat filter, index visibility, verbosity,
    chat tab and fav searching via Blizzards Addon Options panel.

AudioX UI (Optional):
- Resizable UI that lets you search, link and play.
- Scrollable search results.
- Adjustable fontsizes.
- Allows searching and management of your AudioX favourites.
- Demonstrates the use of the AudioX miniAPI.

AudioX UI Minimap Icon (Optional):
- Right-click draggable.
- Toggles AudioX UI and AudioX Options.

AudioX Broker (Optional):
- Databroker plugin for launching AudioX UI and AudioX Options.

AudioX Who *BETA* (Optional):
- Builds a list of players in your guild/party/raid/battleground and friends list
    who can currently see AudioX chat links.



Installation

- Extract the AudioX folder into World of Warcrafts Interface\Addons folder
- Enable both AudioX and AudioX_Search in Mod Settings. Note: Even though
    AudioX_Search is enabled, it will not normally load until you type
    /ax or /audiox.
- Enable any other modules in the AudioX suite that you wish to use.



Usage:

/ax s <string>        - Search for a sample patch containing the specified keyword. E.g. /ax s brew
/ax d                 - Page Down. Find next 10 results for current search. E.g. /ax d
/ax u                 - Page Up. Find previous 10 results for current search. E.g. /ax u
/ax m <number>        - Continue search from a specific search match. E.g. /ax m 15
/ax b <number>        - Continue search beginning at the specified sample index. E.g. /ax b 1500
/ax r                 - Refresh the last page of search results. E.g. /ax r
/ax i <number>        - Display path details for sample index. E.g. /ax i 12345
/ax favs [true/false] - Toggle between searching SoundLib and Favourites. E.g /ax favs false
/ax ui                - Loads / toggles and AudioX II UI. E.g. /ax ui
/ax who               - Lists who in your guild/party/raid/battleground is using AudioX II. E.g. /ax who
/ax <arg>             - Results in the equivalent of /ax s <arg>. E.g. /ax brew
/ax ??                - Help text page 2: Playing. E.g. /ax ??
/ax p <number>        - Play sample number (1 to n) from the current search. E.g. /ax p 16539
/ax pf <number>       - Play sample number (1 to n) from Favourites. E.g. /ax pf 512
/ax ps <number>       - Play sample number (1 to 20653) from SoundLib. E.g. /ax ps 15751
/ax mp <number>       - Play sample num (1 to %d) from current search as music. E.g. /ax mp 14402
/ax mpf <number>      - Play sample num (1 to %d) from Favourites as music. E.g. /ax mpf 42
/ax mps <number>      - Play sample num (1 to %d) from SoundLib as music. E.g. /ax mps 609
/ax sp <number>       - Play sample num (1 to %d) from current search as sfx. E.g. /ax sp 33400
/ax spf <number>      - Play sample num (1 to %d) from Favourites as sfx. E.g. /ax spf 512
/ax sps <number>      - Play sample num (1 to %d) from SoundLib as sfx. E.g. /ax sps 32900
/ax q                 - Quiet. Stop all sounds playing. E.g. /ax q
/ax ???               - Help text page 3: Settings. E.g. /ax ???
/ax l <number>        - Limit the number samples each search returns. E.g. /ax l 10
/ax c <number>        - Crop sound paths to last N characters. 0 = Don't crop. E.g. /ax c 0
/ax n <number>        - Limit pathname display. 0 = filename only, 11 = Show all. E.g. /ax n 11
/ax f [true/false]    - Filter chat so that sample links are clickable. E.g. /ax f true
/ax g [true/false]    - Play non-.wav sounds as looping game music. E.g. /ax g false
/ax h [true/false]    - Hide sample index numbers in search results. E.g. /ax h false
/ax x [true/false]    - Hide file extensions. E.g. /ax x false
/ax v [true/false]    - Verbose output that shows which sample is playing. E.g. /ax v false
/ax t [true/false]    - Output to AudioX chat tab. E.g. /ax t false
/ax a [true/false]    - Autoplay link samples received from other players. E.g. /ax a false
/ax z [true/false]    - Search with pattern matching. E.g. /ax z false
/ax k [true/false]    - Use icons instead of hypertext links. E.g. /ax k false
/ax o <number>        - Auto-Volume level used if music volume is off. 0 - 10. E.g. /ax o 5
/ax options           - Loads / toggles the AudioX II Options. E.g. /ax options
/ax [?]               - Help text page 1: Commands. E.g. /ax ? or /ax



Load-on-demand Macro

Several players have mentioned that they like to keep the number of enabled mods to a bare minimum.
As AudioX is hardly essential in day-to-day World of Warcraft gameplay, I created a macro to allow
you to keep the entire AudioX suite disabled (in addon options) until you need it, at which point
clicking on the macro button would load the entire suite (without any need to reload) for the
current game session. Xuerian has sinced refined this macro as follows (it's a single line):-

Minimap version:
/run for _,mod in pairs({"","_Search","_Options","_UI","_Minimap","_Who"}) do local m="AudioX"..mod EnableAddOn(m) LoadAddOn(m) DisableAddOn(m) end

Databroker version:
/run for _,mod in pairs({"","_Search","_Options","_UI","_Broker","_Who"}) do local m="AudioX"..mod EnableAddOn(m) LoadAddOn(m) DisableAddOn(m) end

Note: You can still configure the AudioX to load whenever you start the game. This macro is a way
to directly control if/when the AudioX suite loads.



Known Bugs

- Garbage Collection may reset AudioX searches if AudioX has been inactive within the game
    session for a long time. If this happens you can use /ax b <num> to resume a search from
    any desired sample index.
- Garbage Collection may affect the AudioX tab. If this occurs type /ax t true.
- Garbage Collection may effect the AudioX UI. If this occurs start a new search. 



Notes:

- AudioX is my first World of Warcraft mod.
- AudioX II uses a different link format from my original AudioX. Please upgrade to AudioX II.
- I only upload AudioX to the following sites:
    http://www.wowinterface.com/downloads/info14100-AudioX.html
    http://wow.curse.com/downloads/wow-addons/details/audiox.aspx
    http://wow.curseforge.com/addons/audiox/



Acknowledgements (in no specific order):

- Bluspacecow for Sound Commands list
    http://www.wowinterface.com/downloads/fileinfo.php?id=13194
- Krakhaan of Khaz'goroth (Oceanic) for his inspirational AFX mod
- James Whitehead II for his brilliant book
    "World of Warcraft Programming" without which this mod wouldn't exist
- Thorinair of EU Ragnaros for motivating me to create my own AudioX UI and
    accompanying API (which his AudioX UI makes use of too :) )
- Xuerian for the improved Load-On-Demand macro.
- Weggls of EU-Todeswache/Alliance for the German translation and for suggesting the
    addition of a pre-search translation table for converting localisated search terms
    into their EnUS SoundPath equivalents.



DISCLAIMER:

While every effort has been made to ensure this mod is error free, you use
this mod entirely at your own risk.
