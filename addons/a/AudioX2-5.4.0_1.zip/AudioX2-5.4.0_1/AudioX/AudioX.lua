--[[
===========================================================================
                               AudioX II
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================

NOTES:
- Lines bracketted with [1] and [/1] are workarounds for Prat arbitrarily converting links to CLINK format.
- Lines bracketted with [2] and [/2] are AudioX_Search specific and aren't directly used by AudioX (Core).
- Lines bracketted with [3] and [/3] are workarounds for ChatEdit_ParseText effects on secure commands in
    outbound chat the prevent post-hooks doing their job.
===========================================================================
]]--


local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LEAVING_WORLD")


function f:ADDON_LOADED(addon)
  if addon ~= "AudioX" then
    return
  else
    self:UnregisterEvent("ADDON_LOADED")
    AX:Initialise()
  end
end


function f:PLAYER_LEAVING_WORLD()  -- Stops music when the player logs out or exits a world area (i.e. loading screen)
  AX:BlizzOptions_DisableMusic(true)
end


-- The following block can be uncommented if background music plays at the same time as zone music. Blizzard may have fixed this issue their end.
--[[

f:RegisterEvent("ZONE_CHANGED")
f:RegisterEvent("ZONE_CHANGED_INDOORS")
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")


function f:ZONE_CHANGED()  -- Stops music when the player moves between subzones or other named areas
  AX:BlizzOptions_DisableMusic(true)
end


function f:ZONE_CHANGED_INDOORS() -- Stops music when the player moves between areas and the "indoors/outdoors" status may have changed
  AX:BlizzOptions_DisableMusic(true)
end


function f:ZONE_CHANGED_NEW_AREA() -- Stops music when the player moves between major zones or enters/exits an instance
  AX:BlizzOptions_DisableMusic(true)
end

]]--


f:SetScript("OnEvent", function(self, event, ...)
  self[event](self, ...)
end)


-- =========================== Initialisation ==========================


function AX:InitVars()
  AX.version		= "5.4.0 BETA"
  AX.linkcolour		= "ffccccff"
  AX.favcolour		= "ffffccff"

  AX.config_defaults = {
    ["filterchat"]	= true,
    ["pathcrop"]	= 0,
    ["autoplay"]	= false,
    ["playmusic"]	= false,
    ["pathdepth"]	= 0,
    ["hideext"]		= false,
    ["autovol"]		= 0.5,
    ["icons"]		= false,
-- [2]
    ["resultsperpage"]	= 10,
    ["idxinresults"]	= false,
    ["verbose"]		= false,
    ["owntab"]		= false,
    ["regex"]		= true,
    ["favs"]		= false,
    ["interpret"]	= false,
-- [/2]
  }

-- DO NOT EDIT THE FOLLOWING VALUES

  AX.channels = {
    "CHAT_MSG_SAY",
    "CHAT_MSG_WHISPER",
    "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_YELL",
    "CHAT_MSG_EMOTE",
    "CHAT_MSG_GUILD",
    "CHAT_MSG_OFFICER",
    "CHAT_MSG_PARTY",
    "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID",
    "CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_BATTLEGROUND",
    "CHAT_MSG_BATTLEGROUND_LEADER",
    "CHAT_MSG_CHANNEL",
    "CHAT_MSG_AFK",
    "CHAT_MSG_DND",
    "CHAT_MSG_BN_WHISPER",
  }

  -- [3]
  AX.safecmds = {
   "0","1","2","3","4","5","6","7","8","9",
   "bg","c","csay","e","em","emote","g","gc",
   "gmotd","gu","guild","me","o","officer",
   "osay","p","party","r","ra","raid","reply",
   "rsay","rw","s","say","send","sh","shout",
   "t","tell","w","whisper","y","yell",
  }
  -- [/3]

  AX.ui_loaded		= false
  AX.opt_loaded		= false
  AX.api_out		= false
  AX.outputframe	= DEFAULT_CHAT_FRAME
  AX.lastquiet		= 0
  AX.quietlimit		= 5
  AX.lastplayback	= 0
  AX.playbacklimit	= 0.5
  AX.lastautoplay	= 0
  AX.autoplaylimit	= 5
  AX.fileextpattern	= "%.[%w]-$"
  AX.filepathpattern	= ""
  AX.filepathmaxdepth	= 10
  AX.bgmusicplaying	= false
  AX.disablemusic	= false
  AX.zerobgmusicvol	= false

  AX.linkident		= "AudioX2"
  AX.linkclrsubst	= "COLOUR"
  AX.linkaddrsubst	= "SOUNDPATH"
  AX.linkpathsubst	= "DISPLAYTEXT"
  AX.linkdisptemplate	= string.format("|c%s|H%s:%s|h[%s]|h|r",AX.linkclrsubst,AX.linkident,AX.linkaddrsubst,AX.linkpathsubst)
  AX.linkdisppattern	= string.format("%s%s:%s","|c[^|]+|H",AX.linkident,"([^%|]+)|h%[[^%]]+%]|h|r")

  AX.linkiconsubst	= "ICONPATH"
  AX.linkiconnorm	= "Interface\\ICONS\\INV_Misc_Drum_07.blp:13:13:0:-1"
  AX.linkiconfav	= "Interface\\Icons\\INV_Misc_Drum_06.blp:13:13:0:-1"
  AX.linkdispicontemp	= string.format("|H%s:%s|h|T%s|t|h|r",AX.linkident,AX.linkaddrsubst,AX.linkiconsubst)
  AX.linkdispiconpatt	= string.format("%s%s:%s","|H",AX.linkident,"([^%|]+)|h|T[^%|]+|t|h|r")
  
  AX.linksendtemplate	= string.format("{%s:%s}",AX.linkident,AX.linkaddrsubst)
  AX.linksendpattern	= string.format("{%s:([^}]+)}",AX.linkident)
--[1]
  AX.clinkpattern	= string.format("{CLINK:%s:%s",AX.linkident,"[%x]+:([^:]+):[^}]+}")
--[/1]

  AX.lasteditbox	= ""
  AX.searchbuilt	= false
  
  AX.tabidx		= nil
  AX.chatframe		= nil
  AX.chattab		= nil
  
  AX.onhyperlinkenter_orig = {}
  AX.onhyperlinkleave_orig = {}
  AX.GameTooltip = GameTooltip
end


function AX:Initialise()

  AX:InitVars()

  local mt = {}
  if type(AUDIOX_CONFIG) == "nil" then
    AUDIOX_CONFIG = AX.config_defaults
  else
    setmetatable(AUDIOX_CONFIG,mt)
    mt.__index = AX.config_defaults
  end

  if type(AUDIOX_FAVS) == "nil" then
    AUDIOX_FAVS = {}
  end

  AX:ChatFrame_Hook()
  AX:Hyperlink_Hook()

  SLASH_AUDIOX1 = "/ax"
  SLASH_AUDIOX2 = "/audiox"
  SlashCmdList["AUDIOX"] = function(msg)
    AX:SlashHandler(msg)
  end

  AX:Set_FilePathPattern()

  hooksecurefunc('ChatEdit_OnUpdate',AX.EditBox_OnUpdate)
  hooksecurefunc('ChatEdit_ParseText',AX.EditBox_SafeSend)

  AX:HyperlinkTooltip()

  AX:Print(string.format(AX.NB_LOADED,AX.linkcolour,SLASH_AUDIOX1,SLASH_AUDIOX2))
  AX.outputframe = AX:SetOutputFrame()

end


-- =================== Functions to be overwritten =====================


function AX:SlashHandler(command)
  AX:Load_AudioXSearch(command)
end


function AX:PlayAsMusic(soundpath)
  AX:BlizzOptions_EnableMusic()
  AX.bgmusicplaying = true
  PlayMusic(soundpath)
  AX:VerboseNotice(string.format("%s: %s (%s)",AX.NB_BGPLAYING,soundpath,AX.UNKNOWNIDX))
end


function AX:PlayAsSample(soundpath)
  AX.bgmusicplaying = false
  PlaySoundFile(soundpath)
  AX:VerboseNotice(string.format("%s: %s (%s)",AX.NB_PLAYING,soundpath,AX.UNKNOWNIDX))
end


function AX:Play(soundpath)
  if AUDIOX_CONFIG.playmusic and (string.find(string.lower(soundpath),"music") ~= nil) then
    AX:PlayAsMusic(soundpath)
  else
    AX:PlayAsSample(soundpath)
  end
end


function AX:Notice(msg)
  AX:Print(string.format("AudioX> %s",msg))
end


-- =========================== General Use =============================


function AX:BlizzOptions_AutoVolume()
  if not AX.zerobgmusicvol then
    AX:RaidWarn(AX.VOL_INCREASED)
  end
  AX.zerobgmusicvol = true
  SetCVar("Sound_MusicVolume",AUDIOX_CONFIG.autovol)
  AUDIOX_CONFIG.autovol = GetCVar("Sound_MusicVolume")
end


function AX:BlizzOptions_EnableMusic()
  if ( GetCVar("Sound_MusicVolume") == "0") or (AX.zerobgmusicvol) then
    AX:BlizzOptions_AutoVolume()
  end
  if ( GetCVar("Sound_EnableMusic") == "0" ) then
    AX.disablemusic = true
    SetCVar("Sound_EnableMusic",1)
    AX:RaidWarn(MUSIC_ENABLED)
  end
end


function AX:BlizzOptions_DisableMusic(notice)
  if AX.disablemusic then
    AX.disablemusic = false
    SetCVar("Sound_EnableMusic",0)
    if notice then
      AX:Print(string.format("AudioX> %s",MUSIC_DISABLED))
    else
      AX:RaidWarn(MUSIC_DISABLED)
    end
  end
  if (AX.zerobgmusicvol) then
    if (GetCVar("Sound_MusicVolume") == AUDIOX_CONFIG.autovol) then
      SetCVar("Sound_MusicVolume",0)
      if notice then
        AX:Print(string.format("AudioX> %s",AX.VOL_DECREASED))
      else
        AX:RaidWarn(AX.VOL_DECREASED)
      end
    -- else music has been adjusted manually so leave volume alone
    end
    AX.zerobgmusicvol = false
  end
end


function AX:Load_AudioX_Plugin(plugin)
  local loaded, failreason = LoadAddOn(plugin)
  if not loaded then
    AX:Notice(string.format("%s is %s.",plugin,string.lower(tostring(failreason))))
  end
  return loaded
end


function AX:Load_AudioXSearch(command)
  local searchloaded, failreason = LoadAddOn("AudioX_Search")
  if not searchloaded then
    AX:Notice(string.format("AudioX_Search is %s.",string.lower(tostring(failreason))))
  else
    ChatFrame_OpenChat(string.format("%s %s",SLASH_AUDIOX2,command))
    ChatEdit_SendText(ChatFrame1EditBox,1)
  end
end


function AX:RaidWarn(msg)
  RaidNotice_AddMessage(RaidWarningFrame,msg,ChatTypeInfo["SYSTEM"])
end


function AX:Print(msg)
  AX:ValidateTab()
  AX.outputframe:AddMessage(msg)
end


function AX:VerboseNotice(msg)
  if AUDIOX_CONFIG.verbose or AX.api_out then
    AX:Notice(msg)
  end
end


function AX:DefNotice(msg)
  DEFAULT_CHAT_FRAME:AddMessage(string.format("AudioX> %s",msg))
end


function AX:BinarySearch(arry,seek)
  local low = 1
  local high = #_G[arry]
  local mid
  while low <= high do
    mid = math.floor((high-low)/2)+low
    if seek < _G[arry][mid] then      
      high = mid - 1
    elseif seek > _G[arry][mid] then
      low = mid + 1
    else -- seek == _G[arry][mid]
      return mid
    end
  end
  return low * -1
end


function AX:PlayLockedOut()
  local curtime = GetTime()
  local locked = true
  if ((curtime-AX.lastplayback) > AX.playbacklimit) then
    AX.lastplayback = curtime
    locked = false
  end
  return locked
end


function AX:ClickPlay(soundpath)
  if not AX:PlayLockedOut() then
    AX:Play(soundpath)
  end
end


function AX:ClickPlayMusic(soundpath)
  if not AX:PlayLockedOut() then
    AX:PlayAsMusic(soundpath)
  end
end


function AX:ClickPlaySample(soundpath)
  if not AX:PlayLockedOut() then
    AX:PlayAsSample(soundpath)
  end
end


function AX:Quiet()
  if AX.bgmusicplaying then
    StopMusic()
    AX:VerboseNotice(AX.NB_BGQUIET)
  else
    local curtime = GetTime()
    if ((curtime-AX.lastquiet) > AX.quietlimit) then
      Sound_GameSystem_RestartSoundSystem()
      AX.lastquiet = curtime
      AX:VerboseNotice(AX.NB_QUIET)
    end
  end
  AX:BlizzOptions_DisableMusic(false)
  AX.bgmusicplaying = false
end


function AX:Set_FilePathPattern()
  if AUDIOX_CONFIG.pathdepth <= AX.filepathmaxdepth then
    AX.filepathpattern = "[^\\]+$"
    if AUDIOX_CONFIG.pathdepth > 0 then
      AX.filepathpattern = string.format("%s%s",string.rep("[^\\]+\\",AUDIOX_CONFIG.pathdepth),AX.filepathpattern)
    end
  else
    AX.filepathpattern = ""
  end
end


function AX:PutInEditBox(txt)
  local editbox = ChatEdit_GetActiveWindow() 
  if (editbox) then
    -- [3]
    local curtxt = editbox:GetText()
    if not(AX:IsSafeCommand(curtxt)) then
      txt = AX:Link_AllDispToSend(txt)			-- This forces AudioX hyperlinks into there send format.
    end  
    -- [/3]
    -- editbox:Insert(AX:Link_MakeSend(txt))		-- OBSOLETE: Utterly safe, but ugly linking
    editbox:Insert(txt)					-- Requires AX:EditBox_SafeSend to convert hyperlink into safe link
  else
    -- ChatFrame_OpenChat(AX:Link_MakeSend(txt))	-- OBSOLETE: Utterly safe, but ugly linking
    ChatFrame_OpenChat(txt)				-- Requires AX:EditBox_SafeSend to convert hyperlink into safe link
  end
end


-- ======================== Chat Tab Functions =========================


function AX:ValidateTab()
  AX:SetTabVars()
  if AX.tabidx > 0 then
    if AX.chatframe:IsVisible() or AX.chattab:IsVisible() then
      if not AUDIOX_CONFIG.owntab then
        AUDIOX_CONFIG.owntab = true
        AX.outputframe = getglobal(string.format("ChatFrame%d",AX.tabidx))
        AX:DefNotice(AX.TAB_ON) 
      end
    else
      if AUDIOX_CONFIG.owntab then
        AUDIOX_CONFIG.owntab = false
        AX.outputframe = DEFAULT_CHAT_FRAME
        AX:DefNotice(AX.TAB_OFF)
      end
    end
  else
    if AUDIOX_CONFIG.owntab then
      AUDIOX_CONFIG.owntab = false
      AX.outputframe = DEFAULT_CHAT_FRAME
      AX:DefNotice(AX.TAB_OFF)
    end
  end
end


function AX:FindChatTab(tabname)
  local name = ""
  local ret = 0
  for idx = 1, NUM_CHAT_WINDOWS do
    name = (GetChatWindowInfo(idx))
    if name == tabname then
      ret = idx
      break
    end
  end
  return ret
end


function AX:MakeNewChatTab()
  FCF_OpenNewWindow(AX.TAB_NAME)
  AX:SetTabVars()
  AX:HyperlinkTooltips(AX.chatframe)
  -- ChatFrame_RemoveAllMessageGroups(AX.chatframe)
end


function AX:Unsign(num)
  if num < 0 then
    num = num * -1
  end
  return num
end


function AX:ShowChatTab()
  AX.chatframe:Show()
  AX.chattab:Show()
  SetChatWindowShown(AX.tabidx,1)
  if (AX.chatframe.isDocked) then
    FCF_DockUpdate()
    FCF_SelectDockFrame(AX.chatframe)
  else
    -- Workaround for after effects of FCF_Close(chatFrame) in Blizzard's own FrameXML where a closed frame loses it's docked status
    -- but is still saved to chat-cache.txt, meaning that if that frame is shown again it's half-docked and showing at same location
    -- as General tab (which is bad!)
    --
    local generaltab = getglobal("ChatFrame1")
    if (AX:Unsign(generaltab:GetLeft()-AX.chatframe:GetLeft())<16) and (AX:Unsign(generaltab:GetTop()-AX.chatframe:GetTop())<16) then
      FCF_DockFrame(AX.chatframe,(#FCFDock_GetChatFrames(GENERAL_CHAT_DOCK)+1),false)
      FCF_SelectDockFrame(AX.chatframe)
    end
  end
end


function AX:DisplayChatTab()
  if AX.tabidx > 0 then
    AX:ShowChatTab()
  else
    AX:MakeNewChatTab()
  end
end


function AX:HideChatTab()
  if AX.tabidx > 0 then
    AX:ShowChatTab()
    FCF_Close(AX.chatframe)
  end
end


function AX:SetTabVars()
   AX.tabidx = AX:FindChatTab(AX.TAB_NAME)
   if AX.tabidx > 0 then
     AX.chatframe = getglobal(string.format("ChatFrame%d",AX.tabidx))
     AX.chattab = getglobal(string.format("ChatFrame%dTab",AX.tabidx))
   end
end


function AX:SetOutputFrame()
  AX:SetTabVars()
  if AUDIOX_CONFIG.owntab then
    AX:DisplayChatTab()
    return AX.chatframe
  else
    AX:HideChatTab()
    return DEFAULT_CHAT_FRAME
  end
end


-- =========================== Favourites ==============================


function AX:Fav_Find(soundpath)
  return AX:BinarySearch("AUDIOX_FAVS",soundpath)
end


function AX:Fav_Toggle(soundpath)
  local pos = AX:Fav_Find(soundpath)
  if pos > 0 then
    AX:Notice(string.format(AX.FAV_REMOVE,soundpath))
    table.remove(AUDIOX_FAVS,pos)
    if AUDIOX_CONFIG.favs then
      AX.searchbuilt = false
    end
    return false
  else
    AX:Notice(string.format(AX.FAV_ADD,soundpath))
    table.insert(AUDIOX_FAVS,(pos * -1),soundpath)
    return true
  end
end


-- ======================== Link Constructors ==========================


function AX:AutoPlay(soundpath,autoplayok)
  if (AUDIOX_CONFIG.autoplay) and (autoplayok) then
    local curtime = GetTime()
    if ((curtime-AX.lastautoplay) > AX.autoplaylimit) then
      AX.lastautoplay = curtime
      AX:Play(soundpath)
    end
  end
end


function AX:Link_SendToDisp(msg,autoplayok)
  return string.gsub(msg,AX.linksendpattern,function(soundpath) AX:AutoPlay(soundpath,autoplayok); return AX:Link_MakeDisp_Chatter(soundpath) end)
end


-- [1]
function AX:Link_ClinkToDisp(msg,autoplayok) --local
  return string.gsub(msg,AX.clinkpattern,function(soundpath) AX:AutoPlay(soundpath,autoplayok); return AX:Link_MakeDisp_Chatter(soundpath) end)
end
-- [/1]


function AX:Link_DispToSend(msg) --local
  return string.gsub(msg,AX.linkdisppattern,function(soundpath) return AX:Link_MakeSend(soundpath) end)
end


function AX:Link_DispIconToSend(msg) --local
  return string.gsub(msg,AX.linkdispiconpatt,function(soundpath) return AX:Link_MakeSend(soundpath) end)
end


-- [1]
function AX:Link_ClinkToSend(msg) --local
  return string.gsub(msg,AX.clinkpattern,function(soundpath) return AX:Link_MakeSend(soundpath) end)
end
-- [/1]


function AX:Link_MakeSend(soundpath) --local
  return string.gsub(AX.linksendtemplate,AX.linkaddrsubst,soundpath)
end


function AX:Link_AllDispToSend(msg)
  if (string.find(msg,AX.linkdisppattern)) then
    msg = AX:Link_DispToSend(msg)
  elseif (string.find(msg,AX.linkdispiconpatt)) then
    msg = AX:Link_DispIconToSend(msg)
-- [1]
  elseif (string.find(msg,AX.clinkpattern)) then
    msg = AX:Link_ClinkToSend(msg)
-- [/1]
  end
  return msg
end


function AX:Link_HideExt(soundpath)
  if AUDIOX_CONFIG.hideext then
    return string.gsub(soundpath,AX.fileextpattern,"")
  else
    return soundpath
  end
end


function AX:Link_FormatPath(soundpath)
  if AUDIOX_CONFIG.pathdepth <= AX.filepathmaxdepth then
    local newsoundpath = string.match(soundpath,AX.filepathpattern)
    if newsoundpath ~= nil then
      if string.len(newsoundpath) < string.len(soundpath) then
        newsoundpath = string.format("\\%s",newsoundpath)
      end
    else
      newsoundpath = soundpath
    end
    return newsoundpath
  else
    return soundpath
  end
end


function AX:Link_MakeDisp(soundpath)
  soundpath = tostring(soundpath)
  local disppath = AX:Link_HideExt(AX:Link_FormatPath(soundpath))
  if AUDIOX_CONFIG.pathcrop > 0 then
    disppath = string.format("..%s",string.sub(soundpath,(AUDIOX_CONFIG.pathcrop*-1)))
  end
  if AX:Fav_Find(soundpath) < 1 then
    return string.gsub(string.gsub(string.gsub(AX.linkdisptemplate,AX.linkaddrsubst,soundpath),AX.linkpathsubst,disppath),AX.linkclrsubst,AX.linkcolour)
  else
    return string.gsub(string.gsub(string.gsub(AX.linkdisptemplate,AX.linkaddrsubst,soundpath),AX.linkpathsubst,disppath),AX.linkclrsubst,AX.favcolour)
  end
end


function AX:Link_MakeDisp_Chatter(soundpath)
  soundpath = tostring(soundpath)
  if not AUDIOX_CONFIG.icons then
    return AX:Link_MakeDisp(soundpath)
  else
    if AX:Fav_Find(soundpath) < 1 then
      return string.gsub(string.gsub(AX.linkdispicontemp,AX.linkaddrsubst,soundpath),AX.linkiconsubst,AX.linkiconnorm)
    else
      return string.gsub(string.gsub(AX.linkdispicontemp,AX.linkaddrsubst,soundpath),AX.linkiconsubst,AX.linkiconfav)
    end
  end
end


-- =========================== Chat Filter =============================


function AX:ChatFrame_Filter(event,msg, ...)
  if AUDIOX_CONFIG.filterchat then
    if (string.find(msg,AX.linksendpattern)) then
      msg = AX:Link_SendToDisp(msg,true)
-- [1]
    elseif (string.find(msg,AX.clinkpattern)) then
      msg = AX:Link_ClinkToDisp(msg,true)
-- [/1]
    end
    -- other filters here
    return false,msg, ...
  else
    return false
  end
end


function AX:ChatFrame_Hook()
  if (AUDIOX_CONFIG.filterchat) then
    for i,channel in ipairs(AX.channels) do
      ChatFrame_AddMessageEventFilter(channel,AX.ChatFrame_Filter)
    end
  else
    for i,channel in ipairs(AX.channels) do
      ChatFrame_RemoveMessageEventFilter(channel,AX.ChatFrame_Filter)
    end
  end
end


-- =================== Show hyperlinks in Edit Box =====================


-- [3]
function AX:IsSafeCommand(txt)
  local ret = false
  if type(txt) == "string" then
    if string.sub(txt,1,1) == "/" then
      ret = false
      local i = 1
      while i <= #AX.safecmds do
        if string.sub(txt,2,(1+#AX.safecmds[i])) == string.format("%s ",AX.safecmds[i]) then
          ret = true
          i = #AX.safecmds  -- Terminate loop
        end
        i = i + 1
      end
    else
      ret = true
    end 
  end
  return ret
end
-- [/3]


function AX.EditBox_OnUpdate(chatEntry) -- ChatEdit_OnUpdate Post-Hook forces any AudioX safelink into an AudioX hyperlink as the player is typing
  local txt = chatEntry:GetText()
  if (txt ~= AX.lasteditbox) then
    if (string.find(txt,AX.linksendpattern)) then
      -- [3]
      if AX:IsSafeCommand(txt) then
      -- [/3]
        txt = AX:Link_SendToDisp(txt,false)
      end
    end
    chatEntry:SetText(txt)
    AX.lasteditbox = txt
  end
end


-- ========== Filter custom hyperlinks out of Edit Box at send =========


function AX.EditBox_SafeSend(chatEntry,send) -- ChatEdit_ParseText Post-Hook forces any outbound AudioX hyperlink text into safelink format before sending)
  if (send == 1) then
    local msg = chatEntry:GetText()
    msg = AX:Link_AllDispToSend(msg)
    chatEntry:SetText(msg)
  end
end


-- ===================== Handle hyperlink clicks =======================


function AX:IsProhibitedChannel()
  if ChatFrame1EditBox:GetAttribute("chatType") == "CHANNEL" then
    local curchannel = ChatFrame1EditBox:GetAttribute("channelTarget")
    for idx = 1,GetNumDisplayChannels() do
      local name,_,_,channelnum,_,_,category,_,_ = GetChannelDisplayInfo(idx)
      if channelnum == curchannel then
        if category == "CHANNEL_CATEGORY_WORLD" then
          return true
        else
          return false
        end
      end
    end
  end
  return false
end


function AX:Hyperlink_Hook()
  local SetItemRef_orig = SetItemRef

  local function AX_SetItemRef(...)
    local link,text,button = ...
    if (type(link) == "string") and (strsub(link, 1, #AX.linkident) == AX.linkident) then
      local soundpath = string.sub(link,(2+#AX.linkident))
      if (IsLeftShiftKeyDown()) then
        if AX:IsProhibitedChannel() then
          AX:Notice(AX.PROBITEDCHANNEL)
        else
          local out = AX:Link_MakeDisp_Chatter(soundpath)
          AX:PutInEditBox(out)
        end
      elseif (IsLeftControlKeyDown()) and (IsAltKeyDown()) then
        AX:Quiet()
      elseif (IsAltKeyDown()) then
        local out = string.format('/script PlaySoundFile("%s")',string.gsub(soundpath,"\\","\\\\"))
        AX:PutInEditBox(out)
      elseif (IsLeftControlKeyDown()) then
        AX:Fav_Toggle(soundpath)
      else
        AX.api_out = false
        if (IsRightShiftKeyDown()) then
          AX:ClickPlayMusic(soundpath)       
        elseif (IsRightControlKeyDown()) then
          AX:ClickPlaySample(soundpath)
        else
          AX:ClickPlay(soundpath)
        end
      end
    else
      SetItemRef_orig(link,text,button)
    end
  end

  SetItemRef = AX_SetItemRef
end


-- ======================== Tooltip Functions ==========================


function AX.OnHyperlinkEnter_Hook(frame,addr,path,...)
  if string.sub(addr,1,string.len(AX.linkident)+1) == string.format("%s:",AX.linkident) then
    GameTooltip:SetOwner(frame,"ANCHOR_TOPLEFT")
    addr = string.sub(addr,string.len(AX.linkident)+2)
    if GameTooltip:NumLines() == 0 then
      GameTooltip:SetText(string.format("|c%sAudioX|r",AX.linkcolour))
    end
    GameTooltip:AddLine(AX.TIPBODY1)
    GameTooltip:AddLine(AX.TIPBODY2)
    GameTooltip:AddLine(AX.TIPBODY3)
    GameTooltip:AddLine(AX.TIPBODY4)
    GameTooltip:AddLine(AX.TIPBODY5)
    GameTooltip:AddLine(AX.TIPBODY6)
    GameTooltip:AddLine(AX.TIPBODY7)
    local pad = "  "
    local start = 1
    local pos = string.find(addr,"\\")
    while pos ~= nil do
      GameTooltip:AddLine(string.format("|cFFCCCCCC%s%s|r",pad,string.sub(addr,start,pos)))
      start = pos + 1
      pos = string.find(addr,"\\",start)
      pad = pad.."  "
    end
    GameTooltip:AddLine(string.format("|cFFFFFFFF%s%s|r",pad,string.sub(addr,start)))
    GameTooltip:Show() 
  end
  if AX.onhyperlinkenter_orig[frame] then
    return AX.onhyperlinkenter_orig[frame](frame,addr,path,...)
  end
end


function AX.OnHyperlinkLeave_Hook(frame,...)
  GameTooltip:Hide()
  if AX.onhyperlinkleave_orig[frame] then
    return AX.onhyperlinkleave_orig[frame](frame,...)
  end
end


function AX:HyperlinkTooltip()
  for i=1, NUM_CHAT_WINDOWS do
    frame = getglobal(string.format("ChatFrame%d",i))
    AX.onhyperlinkenter_orig[frame] = frame:GetScript("OnHyperlinkEnter")
    frame:SetScript("OnHyperlinkEnter",AX.OnHyperlinkEnter_Hook)
    AX.onhyperlinkleave_orig[frame] = frame:GetScript("OnHyperlinkLeave")
    frame:SetScript("OnHyperlinkLeave",AX.OnHyperlinkLeave_Hook)
  end
end
