AX = {}

-- Output tab name
AX.TAB_NAME		= "AudioX"

-- Tab validation
AX.TAB_ON		= "Chat tab detected. Tabbed output ON."
AX.TAB_OFF		= "Chat tab missing. Tabbed output OFF."

-- Misc notices
AX.NB_LOADED		= "Loaded: |c%sAudioX II|r. %s or %s for help."
AX.PROBITEDCHANNEL	= "You cannot link to world channels (General, Trade, LFG etc)."
AX.UNKNOWNIDX		= "Unknown index"
AX.NB_QUIET		= "All audio silenced!"
AX.NB_BGQUIET		= "Music stopped. Click Quiet again to silence all audio."
AX.NB_PLAYING		= "Playing sound"
AX.NB_BGPLAYING		= "Playing music"

-- Tooltip
AX.TIPBODY1		= "Click to play sound"
AX.TIPBODY2		= "L.Shift+Click to link sample"
AX.TIPBODY3		= "Alt+Click for /script"
AX.TIPBODY4		= "L.Ctrl+Click toggles favourite"
AX.TIPBODY5		= "R.Shift+Click to play as backgrnd music"
AX.TIPBODY6		= "R.Ctrl+Click to play once as soundfx"
AX.TIPBODY7		= "L.Ctrl+Alt+Click stops playback"

-- BG Music Volume
AX.VOL_INCREASED	= "Background music volume temporarily increased"
AX.VOL_DECREASED	= "Background music volume restored to OFF"

-- Favourites
AX.FAV_ADD		= "Adding Favourite: %s"
AX.FAV_REMOVE		= "Removing Favourite: %s"

AX.LOCALE_BY		= ""


-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.FAV_ADD			= "Favourit hinzugef\195\188gt: %s"
  AX.FAV_REMOVE			= "Favourit entfernt: %s"
  AX.LOCALE_BY			= "Deutsche \195\156bersetzung von"
  AX.NB_BGPLAYING		= "Spiele Musik"
  AX.NB_BGQUIET			= "Musik angehalten. Klicke erneut auf Stille um alle T\195\182ne abzuschalten."
  AX.NB_LOADED			= "Geladen: |c%sAudioX II|r. %s oder %s um die Hilfe aufzurufen."
  AX.NB_PLAYING			= "Spiele Ton"
  AX.NB_QUIET			= "Alle T\195\182ne abgeschalten."
  AX.PROBITEDCHANNEL		= "Du kannst nicht in Welt-Kan\195\164le (Allgemein, Handel, SucheNachGruppe usw.) verlinken."
  AX.TAB_NAME			= "AudioX"
  AX.TAB_OFF			= "Chat-Tab fehlt. Ausgabe in Tab AUS."
  AX.TAB_ON			= "Chat-Tab gefunden. Ausgabe in Tab AN."
  AX.TIPBODY1			= "Klicke um Tondatei abzuspielen"
  AX.TIPBODY4			= "L.Shift-Klick um Tondatei zu verlinken"
  AX.TIPBODY5			= "Alt+Klick f\195\188r /script"
  AX.TIPBODY6			= "L.Strg-Klick schaltet Favourit um"
  AX.TIPBODY7			= "L.Strg+Alt+Klick stoppt Abspielen"
  AX.UNKNOWNIDX			= "Ung\195\188ltiger Index"
  AX.VOL_DECREASED		= "Hintergrundmusik-Lautst\195\164rke wieder auf AUS gestellt"
  AX.VOL_INCREASED		= "Hintergrundmusik-Lautst\195\164rke tempor\195\164r verniedrigt"


elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo

-- Traditional Chinese Translation by zhTW (CurseForge)
elseif (GetLocale() == "zhTW") then
  AX.NB_BGPLAYING		= "\230\173\163\229\156\168\230\146\173\230\148\190\233\159\179\230\168\130" -- Needs review
  AX.NB_PLAYING			= "\230\173\163\229\156\168\230\146\173\230\148\190\232\129\178\233\159\179" -- Needs review
  AX.PROBITEDCHANNEL		= "\228\189\160\228\184\141\232\131\189\230\148\190\233\128\163\231\181\144\229\136\176\228\184\150\231\149\140\233\160\187\233\129\147(\231\182\156\229\144\136,\228\186\164\230\152\147,\231\181\132\233\154\138 \231\173\137\231\173\137)"
  AX.TIPBODY1			= "\233\187\158\230\147\138\230\146\173\230\148\190\231\175\132\228\190\139"
end
