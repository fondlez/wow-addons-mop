AX.opt_AUTOPLAY		= "Automatically play AudioX chat links"
AX.opt_AUTOVOL		= "Automatic volume %d"
AX.opt_CHATTAB		= "Redirect output to AudioX chat tab *"
AX.opt_CROP		= "Crop link text to %d right-most characters *"
AX.opt_FAVS		= "Only display favourites"
AX.opt_FILTERCHAT	= "Display AudioX hyperlinks in chat *"
AX.opt_HIDEEXT		= "Hide file extensions"
AX.opt_HIDENUM		= "Hide sound index numbers"
AX.opt_ICONLINKS	= "Use icons instead of text links"
AX.opt_INTERPRET	= "Convert keyword(s) into english before searching."
AX.opt_NB_LOADED	= "Loaded: |c%sAudioX II Options|r. %s %s to make changes."
AX.opt_NOCROP		= "No link cropping *"
AX.opt_NOEFFECT		= "Options marked with * only apply to chatframe results"
AX.opt_PAGELIM		= "Results per page %d *"
AX.opt_PATHDEPTH	= "Display right-most %d folders"
AX.opt_PATHDEPTHMAX	= "Full filepath"
AX.opt_PATHDEPTHMIN	= "Filename only"
AX.opt_PATHDEPTHOFF	= "Show complete sound paths"
AX.opt_PATHDEPTHONE	= "Display right-most folder"
AX.opt_PATHDEPTHZERO	= "Show filenames only"
AX.opt_PLAYMUSIC	= "Play paths with 'music' as looped background music"
AX.opt_REGEX		= "Search using pattern matching"
AX.opt_VERBOSE		= "Verbose output *"

-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.opt_AUTOPLAY	= "Spiele AudioX Chatlinks automatisch ab"
  AX.opt_AUTOVOL	= "Automatische Lautst\195\164rke %d"
  AX.opt_CHATTAB	= "Leite Ausgabe in das AudioX-Chat-Tab um *"
  AX.opt_CROP		= "K\195\188rze Link-Text auf %d Zeichen ab *"
  AX.opt_FAVS		= "Zeige nur Favouriten an"
  AX.opt_FILTERCHAT	= "Zeige AudioX Hyperlinks im Chat an *"
  AX.opt_HIDEEXT	= "Verstecke Dateiendungen"
  AX.opt_HIDENUM	= "Verstecke Ton-Index-Nummern"
  AX.opt_ICONLINKS	= "Benutze Icons statt Textlinks"
  AX.opt_INTERPRET	= "\195\156bersetze Suchbegriff(e) vor der Suche auf Englisch"
  AX.opt_NB_LOADED	= "Geladen: |c%sAudioX II Options|r. %s %s um \195\132nderungen durchzuf\195\188hren."
  AX.opt_NOCROP		= "K\195\188rze Links nicht ab *"
  AX.opt_NOEFFECT	= "Optionen die mit einem * markiert sind beeinflussen nur die Ausgabe im Chat"
  AX.opt_PAGELIM	= "%d Ergebnisse pro Seite *"
  AX.opt_PATHDEPTH	= "Pfadanzeige auf %d Verzeichnisse beschr\195\164nken"
  AX.opt_PATHDEPTHMAX	= "Voller Dateipfad"
  AX.opt_PATHDEPTHMIN	= "Nur Dateiname"
  AX.opt_PATHDEPTHOFF	= "Zeige komplette Tonpfade an"
  AX.opt_PATHDEPTHONE	= "Pfadanzeige auf das enthaltende Verzeichniss beschr\195\164nken"
  AX.opt_PATHDEPTHZERO	= "Nur Dateinamen anzeigen"
  AX.opt_PLAYMUSIC	= "Spiele MP3-Dateien als sich wiederholende Hintergrund-Musik ab"
  AX.opt_REGEX		= "Suche mit \195\188bereinstimmender Maske "
  AX.opt_VERBOSE	= "Vollst\195\164ndige Ausgabe *"

elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end