--[[
===========================================================================
                           AudioX II Options
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================
Dependencies: AudioX, AudioX Search
]]--


local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(addon)
  if addon ~= "AudioX_Options" then
    return
  else
    self:UnregisterEvent("ADDON_LOADED")
    AX:Options_Init()
  end
end


f:SetScript("OnEvent", function(self, event, ...)
  self[event](self, ...)
end)


-- =========================== Initialisation ==========================


function AX:Options_Init()
  AX.opt_loaded = true
  AX.opt_timesinceupdate = 0
  AX.opt_updateinterval = 0.5
  AX.opt_origconfig = AX:Options_CloneTab(AUDIOX_CONFIG)

  AX:Options_Build()

  -- InterfaceOptionsFrame_OpenToCategory(AudioX_Options_Frame.name)

  AX:Print(string.format(AX.opt_NB_LOADED,AX.linkcolour,SLASH_AUDIOX1,AX.s_CMD_OPTIONS))
end


-- ========================== UI Constructors ============================


function AX:Options_Update()
  AudioX_Options_FilterChat:SetChecked(AUDIOX_CONFIG.filterchat)
  AudioX_Options_PlayMusic:SetChecked(AUDIOX_CONFIG.playmusic)
  AudioX_Options_HideNum:SetChecked(AUDIOX_CONFIG.idxinresults)
  AudioX_Options_HideExt:SetChecked(AUDIOX_CONFIG.hideext)
  AudioX_Options_Verbose:SetChecked(AUDIOX_CONFIG.verbose)
  AudioX_Options_ChatTab:SetChecked(AUDIOX_CONFIG.owntab)
  AudioX_Options_AutoPlay:SetChecked(AUDIOX_CONFIG.autoplay)
  AudioX_Options_Favs:SetChecked(AUDIOX_CONFIG.favs)
  AudioX_Options_Regex:SetChecked(AUDIOX_CONFIG.regex)
  AudioX_Options_IconLinks:SetChecked(AUDIOX_CONFIG.icons)
  AudioX_Options_Interpret:SetChecked(AUDIOX_CONFIG.interpret)
  AudioX_Options_ResultsPerPage:SetValue(AUDIOX_CONFIG.resultsperpage)
  AudioX_Options_Crop:SetValue(AUDIOX_CONFIG.pathcrop)
  AudioX_Options_PathDepth:SetValue(AUDIOX_CONFIG.pathdepth)
  AudioX_Options_AutoVol:SetValue(AUDIOX_CONFIG.autovol*10)
end


function AX:Options_OnUpdate(elapsed)
  AX.opt_timesinceupdate = AX.opt_timesinceupdate + elapsed
  while AX.opt_timesinceupdate > AX.opt_updateinterval do
    AX:Options_Update()
    AX.opt_timesinceupdate = AX.opt_timesinceupdate - elapsed
  end
end


function AX:Options_CloneTab(tbl)
  local tmp = {}
  for k,v in pairs(tbl) do
    tmp[k] = v
  end
  return tmp
end


function AX:Options_SetAllVals(srctab)
  AUDIOX_CONFIG.filterchat = AX:S_SetBool_Quietly(AUDIOX_CONFIG.filterchat,AX[srctab].filterchat)
  AUDIOX_CONFIG.playmusic = AX:S_SetBool_Quietly(AUDIOX_CONFIG.playmusic,AX[srctab].playmusic)
  AUDIOX_CONFIG.idxinresults = AX:S_SetBool_Quietly(AUDIOX_CONFIG.idxinresults,AX[srctab].idxinresults)
  AUDIOX_CONFIG.hideext = AX:S_SetBool_Quietly(AUDIOX_CONFIG.hideext,AX[srctab].hideext)
  AUDIOX_CONFIG.verbose = AX:S_SetBool_Quietly(AUDIOX_CONFIG.verbose,AX[srctab].verbose)
  AUDIOX_CONFIG.owntab = AX:S_SetBool_Quietly(AUDIOX_CONFIG.owntab,AX[srctab].owntab)
  AUDIOX_CONFIG.autoplay = AX:S_SetBool_Quietly(AUDIOX_CONFIG.autoplay,AX[srctab].autoplay)  
  AUDIOX_CONFIG.favs = AX:S_SetBool_Quietly(AUDIOX_CONFIG.favs,AX[srctab].favs)
  AUDIOX_CONFIG.regex = AX:S_SetBool_Quietly(AUDIOX_CONFIG.regex,AX[srctab].regex)
  AUDIOX_CONFIG.icons = AX:S_SetBool_Quietly(AUDIOX_CONFIG.icons,AX[srctab].icons)
  AUDIOX_CONFIG.interpret = AX:S_SetBool_Quietly(AUDIOX_CONFIG.interpret,AX[srctab].interpret)
  AX:S_SetResultsPerPage_Quietly(AX[srctab].resultsperpage)
  AX:S_SetCrop_Quietly(AX[srctab].pathcrop)
  AX:S_SetPathDepth_Quietly(AX[srctab].pathdepth)
  AX:S_SetAutoVol_Quietly((AX[srctab].autovol)*10)
end


function AX:Options_Build()
  local yoffset = 3

  InterfaceOptionsFrame:SetMovable(true)
  InterfaceOptionsFrame:SetScript("OnMouseDown",function (self) self:StartMoving(); end)
  InterfaceOptionsFrame:SetScript("OnMouseUp",function (self) self:StopMovingOrSizing(); end)

  AudioX_Options_Frame = CreateFrame("Frame","AudioX_Options_Frame",UIParent)
  AudioX_Options_Frame:SetWidth(300)
  AudioX_Options_Frame:SetHeight(410)
  AudioX_Options_Frame:SetFrameStrata("DIALOG")
  AudioX_Options_Frame:Hide()
  AudioX_Options_Frame.name = "AudioX II"

  AudioX_Options_Frame.okay = function ()
    AX.opt_origconfig = AX:Options_CloneTab(AUDIOX_CONFIG)
  end
  AudioX_Options_Frame.cancel = function ()
    AX:Options_SetAllVals("opt_origconfig")
    AX.outputframe = AX:SetOutputFrame()
    AX:S_SetSearchMode()
  end
  AudioX_Options_Frame.default = function ()
    AX:Options_SetAllVals("config_defaults")
    AX.outputframe = AX:SetOutputFrame()
    AX:S_SetSearchMode()
  end
  
  AudioX_Options_Frame:SetScript("OnShow",AX.Options_Update)
  AudioX_Options_Frame:SetScript("OnUpdate",AX.Options_OnUpdate)

  AudioX_Options_TitleText = AudioX_Options_Frame:CreateFontString("AudioX_Options_TitleText","DIALOG","GameFontNormalLarge")
  AudioX_Options_TitleText:SetPoint("TOPLEFT",16,-8)
  AudioX_Options_TitleText:SetText("AudioX II Options")

  AudioX_Options_FilterChat = CreateFrame("CheckButton","AudioX_Options_FilterChat",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_FilterChat:SetPoint("TOPLEFT",AudioX_Options_TitleText,"BOTTOMLEFT",0,yoffset-2)
  AudioX_Options_FilterChat:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_FilterChatText:SetText(AX.opt_FILTERCHAT)
  AudioX_Options_FilterChat:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.filterchat = AX:S_SetBool_Quietly(AUDIOX_CONFIG.filterchat,(self:GetChecked() == 1))
  end)

  AudioX_Options_PlayMusic = CreateFrame("CheckButton","AudioX_Options_PlayMusic",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_PlayMusic:SetPoint("TOPLEFT",AudioX_Options_FilterChat,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_PlayMusic:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_PlayMusicText:SetText(AX.opt_PLAYMUSIC)
  AudioX_Options_PlayMusic:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.playmusic = AX:S_SetBool_Quietly(AUDIOX_CONFIG.playmusic,(self:GetChecked() == 1))
  end)

  AudioX_Options_HideNum = CreateFrame("CheckButton","AudioX_Options_HideNum",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_HideNum:SetPoint("TOPLEFT",AudioX_Options_PlayMusic,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_HideNum:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_HideNumText:SetText(AX.opt_HIDENUM)
  AudioX_Options_HideNum:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.idxinresults = AX:S_SetBool_Quietly(AUDIOX_CONFIG.idxinresults,(self:GetChecked() == 1))
  end)

  AudioX_Options_HideExt = CreateFrame("CheckButton","AudioX_Options_HideExt",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_HideExt:SetPoint("TOPLEFT",AudioX_Options_HideNum,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_HideExt:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_HideExtText:SetText(AX.opt_HIDEEXT)
  AudioX_Options_HideExt:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.hideext = AX:S_SetBool_Quietly(AUDIOX_CONFIG.hideext,(self:GetChecked() == 1))
  end)

  AudioX_Options_Verbose = CreateFrame("CheckButton","AudioX_Options_Verbose",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_Verbose:SetPoint("TOPLEFT",AudioX_Options_HideExt,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_Verbose:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_VerboseText:SetText(AX.opt_VERBOSE)
  AudioX_Options_Verbose:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.verbose = AX:S_SetBool_Quietly(AUDIOX_CONFIG.verbose,(self:GetChecked() == 1))
  end)
  
  AudioX_Options_ChatTab = CreateFrame("CheckButton","AudioX_Options_ChatTab",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_ChatTab:SetPoint("TOPLEFT",AudioX_Options_Verbose,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_ChatTab:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_ChatTabText:SetText(AX.opt_CHATTAB)
  AudioX_Options_ChatTab:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.owntab = AX:S_SetBool_Quietly(AUDIOX_CONFIG.owntab,(self:GetChecked() == 1))
    AX.outputframe = AX:SetOutputFrame()
  end)

  AudioX_Options_AutoPlay = CreateFrame("CheckButton","AudioX_Options_AutoPlay",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_AutoPlay:SetPoint("TOPLEFT",AudioX_Options_ChatTab,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_AutoPlay:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_AutoPlayText:SetText(AX.opt_AUTOPLAY)
  AudioX_Options_AutoPlay:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.autoplay = AX:S_SetBool_Quietly(AUDIOX_CONFIG.autoplay,(self:GetChecked() == 1))  
  end)

  AudioX_Options_Favs = CreateFrame("CheckButton","AudioX_Options_Favs",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_Favs:SetPoint("TOPLEFT",AudioX_Options_AutoPlay,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_Favs:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_FavsText:SetText(AX.opt_FAVS)
  AudioX_Options_Favs:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.favs = AX:S_SetBool_Quietly(AUDIOX_CONFIG.favs,(self:GetChecked() == 1))
    AX:S_SetSearchMode()
  end)
  
  AudioX_Options_Regex = CreateFrame("CheckButton","AudioX_Options_Regex",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_Regex:SetPoint("TOPLEFT",AudioX_Options_Favs,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_Regex:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_RegexText:SetText(AX.opt_REGEX)
  AudioX_Options_Regex:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.regex = AX:S_SetBool_Quietly(AUDIOX_CONFIG.regex,(self:GetChecked() == 1))
  end)
    
  AudioX_Options_IconLinks = CreateFrame("CheckButton","AudioX_Options_IconLinks",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_IconLinks:SetPoint("TOPLEFT",AudioX_Options_Regex,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_IconLinks:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_IconLinksText:SetText(AX.opt_ICONLINKS)
  AudioX_Options_IconLinks:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.icons = AX:S_SetBool_Quietly(AUDIOX_CONFIG.icons,(self:GetChecked() == 1))  
  end)

  AudioX_Options_Interpret = CreateFrame("CheckButton","AudioX_Options_Interpret",AudioX_Options_Frame,"InterfaceOptionsCheckButtonTemplate")
  AudioX_Options_Interpret:SetPoint("TOPLEFT",AudioX_Options_IconLinks,"BOTTOMLEFT",0,yoffset)
  AudioX_Options_Interpret:SetHitRectInsets(0, -300, 0, 0)
  AudioX_Options_InterpretText:SetText(AX.opt_INTERPRET)
  AudioX_Options_Interpret:SetScript("OnClick", function(self)
    PlaySound("igMainMenuOptionCheckBoxOn")
    AUDIOX_CONFIG.interpret = AX:S_SetBool_Quietly(AUDIOX_CONFIG.interpret,(self:GetChecked() == 1))  
  end)

  AudioX_Options_ResultsPerPage = CreateFrame("Slider","AudioX_Options_ResultsPerPage",AudioX_Options_Frame,"OptionsSliderTemplate")
  AudioX_Options_ResultsPerPage:SetWidth(380)
  AudioX_Options_ResultsPerPage:SetHeight(16)
  AudioX_Options_ResultsPerPage:SetPoint("TOPLEFT",AudioX_Options_Interpret,"BOTTOMLEFT",0,-16+yoffset)
  AudioX_Options_ResultsPerPageLow:SetText("1")
  AudioX_Options_ResultsPerPageHigh:SetText(tostring(AX.s_maxresperpage))
  AudioX_Options_ResultsPerPage:SetMinMaxValues(1,AX.s_maxresperpage)
  AudioX_Options_ResultsPerPage:SetValueStep(1)
  AudioX_Options_ResultsPerPage:SetScript("OnValueChanged", function(self, value)
    AudioX_Options_ResultsPerPageText:SetFormattedText(AX.opt_PAGELIM,AX:S_SetResultsPerPage_Quietly(value))
  end)

  AudioX_Options_Crop = CreateFrame("Slider","AudioX_Options_Crop",AudioX_Options_Frame,"OptionsSliderTemplate")
  AudioX_Options_Crop:SetWidth(380)
  AudioX_Options_Crop:SetHeight(16)
  AudioX_Options_Crop:SetPoint("TOPLEFT",AudioX_Options_ResultsPerPage,"BOTTOMLEFT",0,-16+yoffset)
  AudioX_Options_CropLow:SetText("0")
  AudioX_Options_CropHigh:SetText(tostring(AX.s_maxcroplen))
  AudioX_Options_Crop:SetMinMaxValues(0,AX.s_maxcroplen)
  AudioX_Options_Crop:SetValueStep(1)
  AudioX_Options_Crop:SetScript("OnValueChanged", function(self,value)
    value = AX:S_SetCrop_Quietly(value)
    if value > 0 then
      AudioX_Options_CropText:SetFormattedText(AX.opt_CROP,value)
    else
      AudioX_Options_CropText:SetFormattedText(AX.opt_NOCROP)
    end
  end)

  AudioX_Options_PathDepth = CreateFrame("Slider","AudioX_Options_PathDepth",AudioX_Options_Frame,"OptionsSliderTemplate")
  AudioX_Options_PathDepth:SetWidth(380)
  AudioX_Options_PathDepth:SetHeight(16)
  AudioX_Options_PathDepth:SetPoint("TOPLEFT",AudioX_Options_Crop,"BOTTOMLEFT",0,-16+yoffset)
  AudioX_Options_PathDepthLow:SetText(AX.opt_PATHDEPTHMIN)
  AudioX_Options_PathDepthHigh:SetText(AX.opt_PATHDEPTHMAX)
  AudioX_Options_PathDepth:SetMinMaxValues(0,(AX.filepathmaxdepth+1))
  AudioX_Options_PathDepth:SetValueStep(1)
  AudioX_Options_PathDepth:SetScript("OnValueChanged", function(self,value)
    value = AX:S_SetPathDepth_Quietly(value)
    if value <= AX.filepathmaxdepth then
      if value > 1 then
        AudioX_Options_PathDepthText:SetFormattedText(AX.opt_PATHDEPTH,value)
      elseif value == 1 then
        AudioX_Options_PathDepthText:SetFormattedText(AX.opt_PATHDEPTHONE)
      else
        AudioX_Options_PathDepthText:SetFormattedText(AX.opt_PATHDEPTHZERO)
      end
    else
      AudioX_Options_PathDepthText:SetFormattedText(AX.opt_PATHDEPTHOFF)
    end
  end)

  AudioX_Options_AutoVol = CreateFrame("Slider","AudioX_Options_AutoVol",AudioX_Options_Frame,"OptionsSliderTemplate")
  AudioX_Options_AutoVol:SetWidth(380)
  AudioX_Options_AutoVol:SetHeight(16)
  AudioX_Options_AutoVol:SetPoint("TOPLEFT",AudioX_Options_PathDepth,"BOTTOMLEFT",0,-16+yoffset)
  AudioX_Options_AutoVolLow:SetText("OFF")
  AudioX_Options_AutoVolHigh:SetText("10")
  AudioX_Options_AutoVol:SetMinMaxValues(SoundPanelOptions.Sound_MusicVolume.minValue * 10,SoundPanelOptions.Sound_MusicVolume.maxValue * 10)
  AudioX_Options_AutoVol:SetValueStep(SoundPanelOptions.Sound_MusicVolume.valueStep * 10)
  AudioX_Options_AutoVol:SetScript("OnValueChanged", function(self,value)
    value = AX:S_SetAutoVol_Quietly(value)
    AudioX_Options_AutoVolText:SetFormattedText(AX.opt_AUTOVOL,value * 10)
  end)

  AudioX_Options_NoteText = AudioX_Options_Frame:CreateFontString("AudioX_Options_NoteText","DIALOG","GameFontRed")
  AudioX_Options_NoteText:SetPoint("TOP",AudioX_Options_AutoVol,"BOTTOM",0,-16+yoffset)
  AudioX_Options_NoteText:SetText(AX.opt_NOEFFECT)

  -- Quick and dirty fixes for German localization
  if (GetLocale() == "deDE") then
    AudioX_Options_PlayMusicText:SetFont("Fonts\\FRIZQT__.TTF",11)
    AudioX_Options_NoteText:SetFont("Fonts\\FRIZQT__.TTF",10)
  end

  InterfaceOptions_AddCategory(AudioX_Options_Frame)
end


function AX:Options_Toggle()
  if ( InterfaceOptionsFrame:IsShown() ) then
    InterfaceOptionsFrame:Hide()
  else
    InterfaceOptionsFrame_OpenToCategory(AudioX_Options_Frame.name)
  end
end