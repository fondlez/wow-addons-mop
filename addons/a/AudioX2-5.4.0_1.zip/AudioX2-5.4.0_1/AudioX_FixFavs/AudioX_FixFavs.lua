local frame = CreateFrame("Frame")


local function FixFavsCo()
  AX:Notice(AX.ff_STARTED)
  local favlc,libpos,found
  local favtab = AUDIOX_FAVS
  local unreplaced = false
  for favidx,favpath in ipairs(favtab) do
    favlc = string.gsub(string.lower(favpath),".wav$",".ogg")  
    found = false
    libpos = 0
    while (libpos < #SoundLib) and (not found) do
      libpos = libpos + 1
      if string.lower(SoundLib[libpos]) == favlc then
        favtab[favidx] = SoundLib[libpos]
        found=true
      end      
    end
    if not found then
      AX:Notice(string.format(AX.ff_NOTREPLACED,favpath))
      unreplaced = true
    end
    coroutine.yield()
  end
  AUDIOX_FAVS = favtab
  table.sort(AUDIOX_FAVS)
  AX:Notice(AX.ff_COMPLETED)
  if unreplaced then
    AX:Notice(AX.ff_WARNING)
  end
  DisableAddOn("AudioX_FixFavs")
  AX:Notice(AX.ff_DISABLED)
end

  
local thread = coroutine.create(FixFavsCo)
  
 
local counter = 0
local throttle = 0.004
local resumedok, resumedebug
 
frame:SetScript("OnUpdate", function(self, elapsed)
  counter = counter + elapsed
  if counter >= throttle then
    counter = counter - throttle
    if coroutine.status(thread) ~= "dead" then
      resumedok,resumedebug = coroutine.resume(thread)
      if not resumedok then
        AX:Notice(resumedebug)
        resumedok = true
      end
    end
  end
end)
