AX.ff_STARTED		= "Favourites conversion process started. This may take a few minutes."
AX.ff_NOTREPLACED	= "No replacement found: %s"
AX.ff_COMPLETED		= "Favourites conversion process completed."
AX.ff_WARNING		= "One or more soundpaths had no replacement available. These maybe accessed when in favs mode only, and may no longer produce sound."
AX.ff_DISABLED		= "AudioX_FixFavs disabled as it should no longer be needed. Re-log advised."

if (GetLocale() == "deDE") then
  -- todo
elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end
