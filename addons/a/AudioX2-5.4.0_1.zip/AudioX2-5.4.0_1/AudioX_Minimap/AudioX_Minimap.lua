--[[
===========================================================================
                           AudioX II Minimap
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================
]]--


local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(addon)
  if addon ~= "AudioX_Minimap" then
    return
  else
    self:UnregisterEvent("ADDON_LOADED")
    AX:MM_Initialise()
  end
end


f:SetScript("OnEvent", function(self, event, ...)
  self[event](self, ...)
end)

-- ========================== Initialisation ============================


function AX:MM_InitVars()
  AX.mm_config_defaults = {
    angle = 90,
    radius = 80,
  }
end


function AX:MM_Initialise()
  AX:MM_InitVars()

  local mt = {}
  if type(axmm_config) == "nil" then
    axmm_config = AX.mm_config_defaults
  else
    setmetatable(axmm_config,mt)
    mt.__index = AX.mm_config_defaults
  end
  
  AX:MM_BuildButton()
  AX:MM_PlaceButton()

  AX:Print(string.format(AX.mm_NB_LOADED,AX.linkcolour))
end


function AX:MM_BuildButton()
  AudioX_MinimapButton = CreateFrame("Button","AudioX_MinimapButton",Minimap)
  AudioX_MinimapButton:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  AudioX_MinimapButton:SetWidth(33)
  AudioX_MinimapButton:SetHeight(33)
  AudioX_MinimapButton:SetFrameStrata("LOW")
  AudioX_MinimapButton:EnableMouse(true)
  AudioX_MinimapButton:SetMovable(true)
  AudioX_MinimapButton:RegisterForDrag("RightButton")
  AudioX_MinimapButton:SetScript("OnClick",AX.MM_OpenUI)
  AudioX_MinimapButton:SetScript("OnDragStart",function(self)
    AudioX_MinimapButton:SetFrameStrata("FULLSCREEN_DIALOG")
    self:SetScript("OnUpdate",AX.MM_CalcAngle)
  end)
  AudioX_MinimapButton:SetScript("OnDragStop",function(self)
    AudioX_MinimapButton:SetFrameStrata("LOW")
    self:SetScript("OnUpdate",nil)
  end)
  AudioX_MinimapButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("AudioX UI")
    GameTooltip:AddLine(AX.mm_CLICK)
    GameTooltip:AddLine(AX.mm_SHIFTCLICK)
    GameTooltip:AddLine(AX.mm_DRAG)
    GameTooltip:Show()
  end)
  AudioX_MinimapButton:SetScript("OnLeave", function(self)
    ResetCursor()
    GameTooltip:Hide()
  end)
  
  AudioX_MinimapButton:CreateTexture("AudioX_MinimapButtonIcon","BORDER")
  AudioX_MinimapButtonIcon:SetTexture("Interface\\Icons\\Spell_unused2.blp")
  -- AudioX_MinimapButtonIcon:SetTexture("Interface\\Icons\\INV_Gizmo_GoblinBoomBox_01.blp")
  AudioX_MinimapButtonIcon:SetPoint("CENTER",-2,1)
  AudioX_MinimapButtonIcon:SetWidth(20)
  AudioX_MinimapButtonIcon:SetHeight(20)

  AudioX_MinimapButton:CreateTexture("AudioX_MinimapButtonBorder","OVERLAY")
  AudioX_MinimapButtonBorder:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  AudioX_MinimapButtonBorder:SetPoint("TOPLEFT")
  AudioX_MinimapButtonBorder:SetWidth(52)
  AudioX_MinimapButtonBorder:SetHeight(52)
end


function AX:MM_OpenUI()
  if IsShiftKeyDown() then
    if AX.opt_loaded then
      AX:Options_Toggle()
    else
      if AX:Load_AudioX_Plugin("AudioX_Options") then
        AX:Options_Toggle()
      end
    end
  else
    if AX.ui_loaded then
      AX:UI_Toggle()
    else
      AX:Load_AudioX_Plugin("AudioX_UI")
    end
  end
end


function AX:MM_PlaceButton()
  -- Calculate the position of the minimap icon for a given angle and radius
  local iconx = math.cos(axmm_config.angle) * axmm_config.radius
  local icony = math.sin(axmm_config.angle) * axmm_config.radius
  AudioX_MinimapButton:SetPoint("CENTER","Minimap","CENTER",iconx,icony)
end


function AX:MM_CalcAngle()
  local pointerx,pointery = GetCursorPosition()
  local mapx,mapy = Minimap:GetCenter()
  
  -- Calculate angle of mouse pointer in relation to centre of minimap
  local adjacent = (pointerx / UIParent:GetScale()) - mapx
  local opposite = (pointery / UIParent:GetScale()) - mapy
  axmm_config.angle = math.atan2(opposite,adjacent)
  
  AX:MM_PlaceButton()
end
