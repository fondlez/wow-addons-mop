AX.mm_CLICK		= "Left-Click to open AudioX UI."
AX.mm_DRAG		= "Right-Click and drag to move this icon."
AX.mm_NB_LOADED		= "Loaded: |c%sAudioX II Minimap|r."
AX.mm_SHIFTCLICK	= "Shift + Left-Click to open AudioX Options."

-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.mm_CLICK			= "Linker Mausknopf um die AudioX-Oberfl\195\164che zu \195\182ffnen."
  AX.mm_DRAG			= "Rechten Mausknopf halten und bewegen um dieses Icon zu verschieben."
  ax.mm_NB_LOADED		= "Geladen: |c%sAudioX II Minimap|r."
  AX.mm_SHIFTCLICK		= "Shift + Linker Mausknopf um die AudioX-Optionen zu \195\182ffnen."

elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end
