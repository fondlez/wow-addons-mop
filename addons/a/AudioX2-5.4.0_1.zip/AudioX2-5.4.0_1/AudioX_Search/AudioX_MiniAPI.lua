--[[
===========================================================================
                           AudioX II MiniAPI
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================
]]--


function AX:API_ChatOutput()
  AX.api_out = false
end


function AX:API_UIOutput()
  AX.api_out = true
end


function AX:API_PageSize(resultsperpage)
  AX.api_resperpage = AX:S_Cardinal(resultsperpage,1,#_G[AX.searchmode])
end


function AX:API_Search(cmd,keyword)
  AX:API_UIOutput()
  return AX:S_SearchChecks(cmd,keyword)
end


function AX:API_LinkSlashCmd(sound)
  local out
  if type(sound) == "string" then
    out = string.format('/script PlaySoundFile("%s")',string.gsub(sound,"\\","\\\\"))
  else
    out = string.format('/script PlaySoundFile("%s")',string.gsub(_G[AX.searchmode][AX:S_Cardinal(sound,1,#_G[AX.searchmode])],"\\","\\\\"))
  end
  AX:PutInEditBox(out)
end


function AX:API_LinkSoundPath(sound)
  if AX:IsProhibitedChannel() then
    AX:Notice(AX.PROBITEDCHANNEL)
  else
    local link
    if type(sound) == "string" then
      link = AX:Link_MakeDisp_Chatter(sound)
    else
      link = AX:Link_MakeDisp_Chatter(_G[AX.searchmode][AX:S_Cardinal(sound,1,#_G[AX.searchmode])])
    end
    AX:PutInEditBox(link)
  end
end


function AX:API_Play(sound,...)
  local music = ...
  AX:API_UIOutput()
  if type(sound) ~= "string" then
    sound = _G[AX.searchmode][AX:S_Cardinal(sound,1,#_G[AX.searchmode])]
  end
  if music == nil then
    AX:ClickPlay(sound)
  elseif music then
    AX:ClickPlayMusic(sound)
  else
    AX:ClickPlaySample(sound)
  end
end


function AX:API_Quiet()
  AX:API_UIOutput()
  AX:Quiet()
end


function AX:API_ToggleFavSample(sound)
  if type(sound) == "string" then
    return AX:Fav_Toggle(sound)
  else
    return AX:Fav_Toggle(_G[AX.searchmode][AX:S_Cardinal(sound,1,#_G[AX.searchmode])])
  end
end


function AX:API_ToggleFavMode(bool)
  bool = tostring(bool)
  if bool ~= "boolean" then
    bool = "" -- toggle true/false
  end
  AUDIOX_CONFIG.favs = AX:S_SetBool(AUDIOX_CONFIG.favs,bool,AX.s_SET_FAVS,false)
  AX:S_SetSearchMode()
end


function AX:API_IsFav(sound)
  local temp = type(sound)
  if temp == "string" then
    return AX:Fav_Find(sound)
  elseif temp == "number" then
    return AX:Fav_Find(_G[AX.searchmode][AX:S_Cardinal(sound,1,#_G[AX.searchmode])])
  else
    return 1
  end
end


function AX:API_FilterPathAndExt(sound)
  if type(sound) == "string" then
    return AX:Link_HideExt(AX:Link_FormatPath(sound))
  else
    return AX:Link_HideExt(AX:Link_FormatPath(_G[AX.searchmode][AX:S_Cardinal(sound,1,#_G[AX.searchmode])]))
  end
end


function AX:API_IndexFromPath(soundpath,usingsoundlib)
  return AX:S_GetIdxFromPath(soundpath,usingsoundlib)
end


-- ========================= Hookable functions ==========================


function AX:API_LineOut(key,path)
  -- IMPORTANT: This function should be hooked in your AudioX plugin
end


function AX:API_PageFooter(first,last,total,search,tsearch)
  -- IMPORTANT: This function should be hooked in your AudioX plugin
end


function AX:API_Notice(msg)
  -- IMPORTANT: This function should be hooked in your AudioX plugin
end
