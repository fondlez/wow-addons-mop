-- Control links & results footer
AX.s_LINK_PGDN		= "Next"
AX.s_LINK_PGUP		= "Prev"
AX.s_LINK_REFRESH	= "Refresh"
AX.s_LINK_QUIET		= "Quiet"
AX.s_NOT_LINKABLE	= "You cannot forward the [%s] link."
AX.s_MATCHES		= '%d - %d of %d found for "%s"'
AX.s_MATCHES2		= 'and "%s"'

-- /AX commands (must be lowercase)
AX.s_CMD_SEARCH		= "s"
AX.s_CMD_PGDN		= "d"
AX.s_CMD_PGUP		= "u"
AX.s_CMD_MATCH		= "m"
AX.s_CMD_BEGIN		= "b"
AX.s_CMD_REFRESH	= "r"
AX.s_CMD_INDEX		= "i"
AX.s_CMD_PLAY		= "p"
AX.s_CMD_PLAYFAV	= "pf"
AX.s_CMD_PLAYLIB	= "ps"
AX.s_CMD_MPLAY		= "mp"
AX.s_CMD_MPLAYFAV	= "mpf"
AX.s_CMD_MPLAYLIB	= "mps"
AX.s_CMD_SPLAY		= "sp"
AX.s_CMD_SPLAYFAV	= "spf"
AX.s_CMD_SPLAYLIB	= "sps"
AX.s_CMD_QUIET		= "q"
AX.s_CMD_LIMIT		= "l"
AX.s_CMD_CROP		= "c"
AX.s_CMD_PATHDEPTH	= "n"
AX.s_CMD_FILTER		= "f"
AX.s_CMD_BGMUSIC	= "g"
AX.s_CMD_HIDENUM	= "h"
AX.s_CMD_HIDEEXT	= "x"
AX.s_CMD_VERBOSE	= "v"
AX.s_CMD_TAB		= "t"
AX.s_CMD_AUTOPLAY	= "a"
AX.s_CMD_REGEX		= "z"
AX.s_CMD_ICONLINKS	= "k"
AX.s_CMD_INTERPRET	= "e"
AX.s_CMD_AUTOVOL	= "o"
AX.s_CMD_FAVS		= "favs"
AX.s_CMD_OPTIONS	= "options"
AX.s_CMD_GUI		= "ui"
AX.s_CMD_WHO		= "who"
AX.s_CMD_HELP		= "?"
AX.s_CMD_HELP2		= "??"
AX.s_CMD_HELP3		= "???"

-- /AX help text page 1
AX.s_HELPX_STRING	= "string"
AX.s_HELPX_NUMBER	= "number"
AX.s_HELPX_ARG		= "arg"
AX.s_HELP_SEARCH	= "|c%s  /ax %s <%s> |r - Search for a sample patch containing the specified keyword. E.g. /ax %s brew"
AX.s_HELP_PGDN		= "|c%s  /ax %s |r - Page Down. Find next %d results for current search. E.g. /ax %s"
AX.s_HELP_PGUP		= "|c%s  /ax %s |r - Page Up. Find previous %d results for current search. E.g. /ax %s"
AX.s_HELP_MATCH		= "|c%s  /ax %s <%s> |r - Continue search from a specific search match. E.g. /ax %s 15"
AX.s_HELP_BEGIN		= "|c%s  /ax %s <%s> |r - Continue search beginning at the specified sample index. E.g. /ax %s 1500"
AX.s_HELP_REFRESH	= "|c%s  /ax %s |r - Refresh the last page of search results. E.g. /ax %s"
AX.s_HELP_INDEX		= "|c%s  /ax %s <%s> |r - Display path details for sample index. E.g. /ax %s 12345"
AX.s_HELP_FAVS		= "|c%s  /ax %s [%s/%s] |r - Toggle between searching SoundLib and Favourites. E.g. /ax %s %s"
AX.s_HELP_GUI		= "|c%s  /ax %s |r - Loads / toggles the AudioX II UI. E.g. /ax %s"
AX.s_HELP_WHO		= "|c%s  /ax %s |r - Lists who in your guild/party/raid/battleground is using AudioX II. E.g. /ax %s"
AX.s_HELP_DEFAULT	= "|c%s  /ax <%s> |r - Results in the equivalent of /ax %s <%s>. E.g. /ax brew"
AX.s_HELP_HELP2		= "|c%s  /ax %s |r - Help text page 2: Playing. E.g. /ax %s"

-- /AX help text page 3
AX.s_HELP_PLAY		= "|c%s  /ax %s <%s> |r - Play sample number (1 to %d) from the current search. E.g. /ax %s 16539"
AX.s_HELP_PLAYFAV	= "|c%s  /ax %s <%s> |r - Play sample number (1 to %d) from Favourites. E.g. /ax %s 512"
AX.s_HELP_PLAYLIB	= "|c%s  /ax %s <%s> |r - Play sample number (1 to %d) from SoundLib. E.g. /ax %s 15751"
AX.s_HELP_MPLAY		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from current search as music. E.g. /ax %s 14402"
AX.s_HELP_MPLAYFAV	= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from Favourites as music. E.g. /ax %s 42"
AX.s_HELP_MPLAYLIB	= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from SoundLib as music. E.g. /ax %s 609"
AX.s_HELP_SPLAY		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from current search as sfx. E.g. /ax %s 33400"
AX.s_HELP_SPLAYFAV	= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from Favourites as sfx. E.g. /ax %s 512"
AX.s_HELP_SPLAYLIB	= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from SoundLib as sfx. E.g. /ax %s 32900"
AX.s_HELP_QUIET		= "|c%s  /ax %s |r - Quiet. Stop all sounds playing. E.g. /ax %s"
AX.s_HELP_HELP3		= "|c%s  /ax %s |r - Help text page 3: Settings. E.g. /ax %s"

-- /AX help text page 2
AX.s_HELP_LIMIT		= "|c%s  /ax %s <%s> |r - Limit the number samples each search returns. E.g. /ax %s %d"
AX.s_HELP_CROP		= "|c%s  /ax %s <%s> |r - Crop sound paths to last N characters. 0 = Don't crop. E.g. /ax %s %d"
AX.s_HELP_PATHDEPTH	= "|c%s  /ax %s <%s> |r - Limit pathname display. 0 = filename only, %d = Show all. E.g. /ax %s %d"
AX.s_HELP_FILTER	= "|c%s  /ax %s [%s/%s] |r - Filter chat so that sample links are clickable. E.g. /ax %s %s"
AX.s_HELP_BGMUSIC	= "|c%s  /ax %s [%s/%s] |r - Play paths containing 'music' as looped background music. E.g. /ax %s %s"
AX.s_HELP_HIDENUM	= "|c%s  /ax %s [%s/%s] |r - Hide sample index numbers in search results. E.g. /ax %s %s"
AX.s_HELP_HIDEEXT	= "|c%s  /ax %s [%s/%s] |r - Hide file extensions. E.g. /ax %s %s"
AX.s_HELP_VERBOSE	= "|c%s  /ax %s [%s/%s] |r - Verbose output that shows which sample is playing. E.g. /ax %s %s"
AX.s_HELP_TAB		= "|c%s  /ax %s [%s/%s] |r - Output to %s chat tab. E.g. /ax %s %s"
AX.s_HELP_AUTOPLAY	= "|c%s  /ax %s [%s/%s] |r - Autoplay link samples received from other players. E.g. /ax %s %s"
AX.s_HELP_REGEX		= "|c%s  /ax %s [%s/%s] |r - Search with pattern matching. E.g. /ax %s %s"
AX.s_HELP_ICONLINKS	= "|c%s  /ax %s [%s/%s] |r - Use icons instead of hypertext links. E.g. /ax %s %s"
AX.s_HELP_INTERPRET	= "|c%s  /ax %s [%s/%s] |r - Convert localised search keyword into english prior to search. E.g. /ax %s %s"
AX.s_HELP_AUTOVOL	= "|c%s  /ax %s <%s> |r - Auto-Volume level used if music volume is off. 0 - 10. E.g. /ax %s %d"
AX.s_HELP_OPTIONS	= "|c%s  /ax %s |r - Loads / toggles AudioX II Options. E.g. /ax %s"
AX.s_HELP_HELP		= "|c%s  /ax [%s] |r - Help text page 1: Commands. E.g. /ax %s or /ax"

-- Search
AX.s_SRCH_FWDDONE	= "Cannot search further forwards than the last record!"
AX.s_SRCH_REVDONE	= "Cannot search further backwards than the first record!"

-- Values (must be all lowercase)
AX.s_VAL_TRUE		= "true"
AX.s_VAL_ON		= "on"
AX.s_VAL_FALSE		= "false"
AX.s_VAL_OFF		= "off"

-- Value Set
AX.s_SET_PGLIMIT	= "Searches limited to %d results per page"
AX.s_SET_CROP		= "Links cropped to the right most %d characters"
AX.s_SET_PATHDEPTH	= "Showing right-most %d folders"
AX.s_SET_AUTOVOL	= "Background music volume will temporarily increase to %d if OFF"

-- Switch status
AX.s_SET_VERBOSE	= "Verbosity"
AX.s_SET_FILTER		= "Filter chat"
AX.s_SET_BGMUSIC	= "Game music audio"
AX.s_SET_HIDENUM	= "Hide index numbers"
AX.s_SET_HIDEEXT	= "Hide file extensions"
AX.s_SET_TAB		= "Output to %s tab"
AX.s_SET_AUTOPLAY	= "Autoplay"
AX.s_SET_REGEX		= "Pattern matching"
AX.s_SET_ICONLINKS	= "Icon links"
AX.s_SET_INTERPRET	= "Interpret search keyword"
AX.s_SET_FAVS		= "Favourite searching"

-- Notices
AX.s_NB_CROPOFF		= "No link cropping"
AX.s_NB_LOADED		= "Loaded: |c%sAudioX II Search|r. %s %s for help."
AX.s_NB_PATHDEPTHOFF	= "Showing complete sound paths"
AX.s_NB_PATHDEPTHZERO	= "Showing filenames only"

-- Notices: Boolean value set/toggled
AX.s_NB_SET		= "set"
AX.s_NB_TOGGLED		= "toggled"

-- Errors
AX.s_ERR_BADNUM		= "Invalid integer. Whole number between %d and %d expected."

-- Keyword translations
AX.s_SRCHTRANS		= {
	{"PreCastHearthstone",	"PreCastNatureMagicHigh"},
	{"Path Of Frost",	"deathknight_iceboundfortitudeStand"},
	{"Fan Of Knives",	"bladesRingImpact"},
	{"PathOfFrost",		"deathknight_iceboundfortitudeStand"},
	{"FanOfKnives",		"bladesRingImpact"},
	{"Hearthstone",		"AstralRecall"},
	{"Chromaggus",		"Drakeadon"},
	{"Piccolo",		"Seduction_State_Head"},
	{"Silly",		"Pissed"},
	{"Joke",		"Pissed"},
}



-- Deutsche �bersetzung von: Weggls of EU-Todeswache/A
if (GetLocale() == "deDE") then
  AX.s_CMD_AUTOPLAY		= "a"
  AX.s_CMD_AUTOVOL		= "o"
  AX.s_CMD_BEGIN		= "b"
  AX.s_CMD_BGMUSIC		= "g"
  AX.s_CMD_CROP			= "c"
  AX.s_CMD_FAVS			= "favo"
  AX.s_CMD_FILTER		= "f"
  AX.s_CMD_GUI			= "oberfl"
  AX.s_CMD_HELP			= "?"
  AX.s_CMD_HELP2		= "??"
  AX.s_CMD_HIDEEXT		= "x"
  AX.s_CMD_HIDENUM		= "h"
  AX.s_CMD_ICONLINKS		= "k"
  AX.s_CMD_INDEX		= "i"
  Ax.s_CMD_INTERPRET		= "e"
  AX.s_CMD_LIMIT		= "l"
  AX.s_CMD_MATCH		= "m"
  AX.s_CMD_OPTIONS		= "optionen"
  AX.s_CMD_PATHDEPTH		= "n"
  AX.s_CMD_PGDN			= "d"
  AX.s_CMD_PGUP			= "u"
  AX.s_CMD_PLAY			= "p"
  AX.s_CMD_PLAYFAV		= "sf"
  AX.s_CMD_PLAYLIB		= "ss"
  AX.s_CMD_QUIET		= "q"
  AX.s_CMD_REFRESH		= "r"
  AX.s_CMD_REGEX		= "z"
  AX.s_CMD_SEARCH		= "s"
  AX.s_CMD_TAB			= "t"
  AX.s_CMD_VERBOSE		= "v"
  AX.s_CMD_WHO			= "wer"
  AX.s_ERR_BADNUM		= "Ung\195\188ltiger Integer. Ganzzahl zwischen %d und %d erwartet."
  AX.s_HELP_AUTOPLAY		= "|c%s /ax %s [%s/%s] |r - Spiele Links von anderen Spielern automatisch ab. Z.B.: /ax %s %s"
  AX.s_HELP_AUTOVOL		= "|c%s  /ax %s <%s> |r - Automatische Lautst\195\164rke wenn Musik abgeschalten ist. 0 - 10. Z.B.: /ax %s  %d"
  AX.s_HELP_BEGIN		= "|c%s  /ax %s <%s> |r - Fahre mit der Suche an dem angebenen Index fort. Z.B.: /ax %s  1500"
  AX.s_HELP_BGMUSIC		= "|c%s  /ax %s [%s/%s] |r - Spiele Dateien die nicht auf .wav enden als sich wiederholende Hintergrund-Musik ab. Z.B.: /ax %s %s"
  AX.s_HELP_CROP		= "|c%s  /ax %s <%s> |r - Verk\195\188rze Dateipfade auf die letzten N Buchstaben. 0 = Nicht k\195\188rzen. Z.B.: /ax %s  %d"
  AX.s_HELP_DEFAULT		= "|c%s  /ax <%s> |r - Ergebnisse im Format von /ax %s <%s>. Z.B.: /ax brew"
  AX.s_HELP_FAVS		= "|c%s  /ax %s [%s/%s] |r - Schalte Suche zwischen SoundLib und Favouriten um. Z.B.: /ax %s  %s"
  AX.s_HELP_FILTER		= "|c%s  /ax %s [%s/%s] |r - Filtere Chat um AudioX-Links anklickbar zu machen. Z.B.: /ax %s  %s"
  AX.s_HELP_GUI			= "|c%s  /ax %s |r - L\195\164dt die AudioX II Oberfl\195\164che oder schaltet ihre Anzeige um. Z.B.: /ax %s"
  AX.s_HELP_HELP		= "|c%s  /ax [%s] |r - Hilfe-Text Seite 1: Befehle. Z.B.: /ax %s or /ax"
  -- AX.s_HELP_HELP2		= "|c%s  /ax %s |r - Help text page 2: Playing. E.g. /ax %s"
  AX.s_HELP_HELP3		= "|c%s  /ax %s |r - Hilfe-Text Seite 3: Einstellungen. E.g. /ax %s"
  AX.s_HELP_HIDEEXT		= "|c%s  /ax %s [%s/%s] |r - Verstecke Datei-Erweiterungen. Z.B.: /ax %s %s"
  AX.s_HELP_HIDENUM		= "|c%s  /ax %s [%s/%s] |r - Verstecke Index-Nummern in den Such-Ergebnissen. Z.B.: /ax %s %s"
  AX.s_HELP_ICONLINKS		= "|c%s  /ax %s [%s/%s] |r - Benutze Icons statt Links. Z.B.: /ax %s %s"
  AX.s_HELP_INDEX		= "|c%s  /ax %s <%s> |r - Zeige detaillierten Pfad f\195\188r angegebenen Index. Z.B.: /ax %s 12345"
  AX.s_HELP_INTERPRET		= "|c%s  /ax %s [%s/%s] |r - Deutsches Suchwort vor der Suche auf Englisch \195\188bersetzen Z.B. /ax %s %s"
  AX.s_HELP_LIMIT		= "|c%s  /ax %s <%s> |r - Beschr\195\164nke die Anzahl der Ergebnisse pro Suche. Z.B.: /ax %s  %d"
  AX.s_HELP_MATCH		= "|c%s  /ax %s <%s> |r - F\195\188hre die Suche an angegebenen Ergebniss weiter. Z.B.: /ax %s  15"
  -- AX.s_HELP_MPLAY		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from current search as music. E.g. /ax %s 14402"
  -- AX.s_HELP_MPLAYFAV		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from Favourites as music. E.g. /ax %s 42"
  -- AX.s_HELP_MPLAYLIB		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from SoundLib as music. E.g. /ax %s 609"
  AX.s_HELP_OPTIONS		= "|c%s  /ax %s |r - L\195\164dt die AudioX II Optionen, bzw. schaltet deren Anzeige um. Z.B.: /ax %s"
  AX.s_HELP_PATHDEPTH		= "|c%s  /ax %s <%s> |r - Beschr\195\164nke die Anzeige des Pfadnamens. 0 = nur Dateinamen, %d = komplett Anzeigen. Z.B.: /ax %s %d"
  AX.s_HELP_PGDN		= "|c%s  /ax %s |r - Seite nach unten. Finde die n\195\164chsten %d Ergebnisse der aktuellen Suche. Z.B.: /ax %s"
  AX.s_HELP_PGUP		= "|c%s  /ax %s |r - Seite nach oben. Finde die n\195\164chsten %d Ergebnisse der aktuellen Suche. Z.B.: /ax %s"
  AX.s_HELP_PLAY		= "|c%s  /ax %s <%s> |r - Spiele den Ton mit der angegebenen Index-Nummer zwischen 1 und %d ab. Z.B.: /ax %s 16539"
  AX.s_HELP_PLAYFAV		= "|c%s  /ax %s <%s> |r - Spiele Tondatei Nummer (1 bis %d) aus den Favouriten. Z.B.: /ax %s 512"
  AX.s_HELP_PLAYLIB		= "|c%s  /ax %s <%s> |r - Spiele Tondatei Nummer (1 bis %d) aus der Tonbibliothek. Z.B.: /ax %s 15751"
  AX.s_HELP_QUIET		= "|c%s  /ax %s |r - Stille. H\195\164lt alle abspielenden T\195\182ne ab. Z.B.: /ax %s"
  AX.s_HELP_REFRESH		= "|c%s  /ax %s |r - Erneuere die letzte Seite der Suchergebnisse. Z.B.: /ax %s"
  AX.s_HELP_REGEX		= "|c%s  /ax %s [%s/%s] |r - Suche nach angegebener Maske. Z.B.: /ax %s %s"
  AX.s_HELP_SEARCH		= "|c%s  /ax %s <%s> |r - Suche nach mehreren T\195\182nen die das angebene Suchwort enthalten. Z.B.: /ax %s brew"
  -- AX.s_HELP_SPLAY		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from current search as sfx. E.g. /ax %s 33400"
  -- AX.s_HELP_SPLAYFAV		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from Favourites as sfx. E.g. /ax %s 512"
  -- AX.s_HELP_SPLAYLIB		= "|c%s  /ax %s <%s> |r - Play sample num (1 to %d) from SoundLib as sfx. E.g. /ax %s 32900"
  AX.s_HELP_TAB			= "|c%s  /ax %s [%s/%s] |r - Ausgabe in Chat-Tab %s. Z.B.: /ax %s %s"
  AX.s_HELP_VERBOSE		= "|c%s  /ax %s [%s/%s] |r - Vollst\195\164ndige Ausgabe die die momentan spielenden Dateien anzeigt. Z.B.: /ax %s  %s"
  AX.s_HELP_WHO			= "|c%s  /ax %s |r - Zeigt an wer in deiner Gilde/Gruppe/Schlachtzug/Schlachtfeld noch AudioX II benutzt. Z.B.: /ax %s"
  AX.s_HELPX_ARG		= "arg"
  AX.s_HELPX_NUMBER		= "nummer"
  AX.s_HELPX_STRING		= "string"
  AX.s_LINK_PGDN		= "N\195\164chstes"
  AX.s_LINK_PGUP		= "Vorheriges"
  AX.s_LINK_QUIET		= "Stille"
  AX.s_LINK_REFRESH		= "Neu laden"
  AX.s_MATCHES			= "%d - %d  von %d gefunden f\195\188r \"%s\"."
  AX.s_MATCHES2			= "und \"%s\""
  AX.s_NB_CROPOFF		= "Keine Verk\195\188rzung der Links"
  AX.s_NB_LOADED		= "Geladen: |c%sAudioX II Search|r. %s %s  um die Hilfe aufzurufen."
  AX.s_NB_PATHDEPTHOFF		= "Zeige komplette Ton-Pfade an"
  AX.s_NB_PATHDEPTHZERO		= "Zeige nur Dateipfade an"
  AX.s_NB_SET			= "setzte"
  AX.s_NB_TOGGLED		= "umgeschalten"
  AX.s_NOT_LINKABLE		= "Du kannst den Link [%s] nicht weiterschicken."
  AX.s_SET_AUTOPLAY		= "Automatisches Abspielen"
  AX.s_SET_AUTOVOL		= "Hintergrundmusik-Lautst\195\164rke wird tempor\195\164r auf %d gesetzt wenn AUS"
  AX.s_SET_BGMUSIC		= "Spielmusik"
  AX.s_SET_CROP			= "Links auf die letzten %d Buchstaben verk\195\188rzt."
  AX.s_SET_FAVS			= "Favouritensuche"
  AX.s_SET_FILTER		= "Filtere Chat"
  AX.s_SET_HIDEEXT		= "Verstecke Datei-Erweiterungen"
  AX.s_SET_HIDENUM		= "Verstecke Index-Zahlen"
  AX.s_SET_ICONLINKS		= "Icon Links"
  AX.s_SET_INTERPRET		= "Suchwort \195\188bersetzen"
  AX.s_SET_PATHDEPTH		= "Nur die letzten %d Verzeichnisse anzeigen"
  AX.s_SET_PGLIMIT		= "Suchen sind auf %d Ergebnisse pro Seite beschr\195\164nkt"
  AX.s_SET_REGEX		= "Suchmaske trifft zu" -- Needs review
  AX.s_SET_TAB			= "In Tab %s ausgeben"
  AX.s_SET_VERBOSE		= "Vollst\195\164ndigkeit"
  AX.s_SRCH_FWDDONE		= "Kann nicht hinter dem letzten Eintrag suchen!"
  AX.s_SRCH_REVDONE		= "Kann nicht vor dem ersten Eintrag suchen!"
  AX.s_VAL_FALSE		= "falsch"
  AX.s_VAL_OFF			= "aus"
  AX.s_VAL_ON			= "an"
  AX.s_VAL_TRUE			= "wahr"

  AX.s_SRCHTRANS		= {
	{"Schmiedemeister",	"Forgemaster"},
	{"Klingenschuppe",	"Razorscale"},
	{"Flammenschlund",	"Ragefire"},
	{"Schattensucher",	"Shadowseeker"},
	{"Wolkenwanderer",	"Cloudstrider"},
	{"Brandschatzer",	"Plunderer"},
	{"Fleischformer",	"Fleshcrafter"},
	{"Dekunstruktor",	"Deconstructor"},
	{"Seuchenf�rst",	"Plaguebringer"},
	{"Kreuzz�glers",	"Crusader"},
	{"Kriegsj�nger",	"Warborn"},
	{"Verschlinger",	"Devourer"},
	{"Kunstrukteur",	"Constructor"},
	{"Fleischhaken",	"Meathook"},
	{"Todesbringer",	"Deathbringer"},
	{"Traumwandler",	"Dreamwalker"},
	{"Gei�elf�rst",		"Scourgelord"},
	{"Blutk�nigin",		"Blood-Queen"},
	{"Versammlung",		"Assembly"},
	{"Todeswisper",		"Deathwhisper"},
	{"Seuchenmord",		"Putricide"},
	{"Beichtpatin",		"Confessor"},
	{"Skrupellose",		"Ruthless"},
	{"Eisenformer",		"Ironshaper"},
	{"Reflexionen",		"Reflection"},
	{"Torw�chter",		"Gatewatcher"},
	{"Beschw�rer",		"Summoner"},
	{"Leyw�chter",		"Ley-Guardian"},
	{"K�nigreich",		"Kingdom"},
	{"Magierlord",		"Mage-Lord"},
	{"Beobachter",		"Observer"},
	{"Trollgrind",		"Trollgore"},
	{"Instrukeur",		"Instructor"},
	{"Grabesleid",		"Sorrowgrave"},
	{"Blondlocke",		"Paletress"},
	{"Chronolord",		"Chrono-Lord"},
	{"Vernichter",		"Obliterator"},
	{"Luftschiff",		"Gunship"},
	{"Modermiene",		"Rotface"},
	{"Bleichhuf",		"Palehoof"},
	{"Ausmerzen",		"Culling"},
	{"Verderber",		"Corruptor"},
	{"Zitadelle",		"Citadel"},
	{"Lichtbann",		"Lightbane"},
	{"Nachtbann",		"Darkbane"},
	{"Flickwerk",		"Patchwerk"},
	{"Aufseher",		"Watcher"},
	{"Ewigkeit",		"Eternity"},
	{"Fauldarm",		"Festergut"},
	{"Befrager",		"Interrogator"},
	{"Violette",		"Violet"},
	{"Fraktion",		"Faction"},
	{"Argentum",		"Argent"},
	{"Schwarze",		"Black"},
	{"Schmiede",		"Forge"},
	{"Saphiron",		"Sapphiron"},
	{"Mark'gar",		"Marrowgar"},
	{"Aufseher",		"Controller"},
	{"Eiskrone",		"Icecrown"},
	{"Pr�fung",		"Trial"},
	{"Flammen",		"Flame"},
	{"Bestien",		"Beasts"},
	{"Festung",		"Hold"},
	{"Unreine",		"Unclean"},
	{"Nordend",		"Northrend"},
	{"H�hlen",		"Caverns"},
	{"Trauer",		"Grief"},
	{"Ernter",		"Harvester"},
	{"Blitze",		"Lightning"},
	{"Hallen",		"Halls"},
	{"Steins",		"Stone"},
	{"Seelen",		"Souls"},
	{"Urahne",		"Elder"},
	{"Ritter",		"Knight"},
	{"Ewiger",		"Infinite"},
	{"Koloss",		"Colossus"},
	{"Widder",		"Ram"},
	{"K�nig",		"King"},
	{"Prinz",		"Prince"},
	{"Grube",		"Pit"},
	{"Reine",		"Pure"},
	{"Witwe",		"Widow"},
	{"Wilde",		"Ferocious"},
	{"Kampf",		"Battle"},
	{"Katze",		"Cat"},
	{"Schaf",		"Sheep"},
	{"Gro�",		"Grand"},
	{"Burg",		"Keep"},
	{"Turm",		"Pinnacle"},
	{"Maid",		"Maiden"},
	{"Zeit",		"Time"},
	{"Auge",		"Eye"},
	{"Hund",		"Dog"},
	{"Rat",			"Council"},
  }


elseif (GetLocale() == "esES") then
  -- todo
elseif (GetLocale() == "esMX") then
  -- todo
elseif (GetLocale() == "frFR") then
  -- todo
elseif (GetLocale() == "koKR") then
  -- todo
elseif (GetLocale() == "ruRU") then
  -- todo
elseif (GetLocale() == "zhCN") then
  -- todo
elseif (GetLocale() == "zhTW") then
  -- todo
end
