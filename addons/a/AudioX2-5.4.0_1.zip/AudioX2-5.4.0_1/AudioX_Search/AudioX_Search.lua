--[[
===========================================================================
                            AudioX II Search
            Copyright 2009-2012 Eisa of EU Aggramar/Horde.
                          All Rights Reserved.
===========================================================================
NOTES:
- Lines bracketted with:
  - [1] and [/1] are workarounds for Prat arbitrarily converting links to CLINK format

==================================================================================
]]--


local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(addon)
  if addon ~= "AudioX_Search" then
    return
  else
    self:UnregisterEvent("ADDON_LOADED")
    AX:Search_Initialise()
  end
end


f:SetScript("OnEvent", function(self, event, ...)
  self[event](self, ...)
end)


-- =========================== Initialisation ==========================


function AX:Search_InitVars()
  AX.s_SET_TAB		= string.format(AX.s_SET_TAB,AX.TAB_NAME)

  AX.s_linkcmdcolour	= "ff9999cc"
  AX.s_maxresperpage	= 500
  AX.s_maxcroplen	= 256

  AX.api_resperpage	= AUDIOX_CONFIG.resultsperpage
  AX.s_resultsperpage	= AUDIOX_CONFIG.resultsperpage

  AX.s_SearchResults	= {}
  AX.s_searchkeyword	= ""
  AX.s_userkeyword	= ""
  AX.s_redosearchpos	= 1
  AX.s_searchsuccess	= false

  AX.s_linkcmdquiet	= "QUIET"
  AX.s_linkcmdpgdn	= "PGDN"
  AX.s_linkcmdpgup	= "PGUP"
  AX.s_linkcmdrefresh	= "REFRESH"

  AX.s_linkcmdident	= string.format("%s-cmd",AX.linkident)
  AX.s_linkcmdtemplate	= string.format("|c%s|H%s:%s|h[%s]|h|r",AX.linkclrsubst,AX.s_linkcmdident,AX.linkaddrsubst,AX.linkpathsubst)

  AX.s_footerlinks	= string.format("%s%s%s%s",AX:S_Link_MakeCmd(AX.s_linkcmdpgup,AX.s_LINK_PGUP),AX:S_Link_MakeCmd(AX.s_linkcmdpgdn,AX.s_LINK_PGDN),AX:S_Link_MakeCmd(AX.s_linkcmdrefresh,AX.s_LINK_REFRESH),AX:S_Link_MakeCmd(AX.s_linkcmdquiet,AX.s_LINK_QUIET))
end


function AX:Search_Initialise()
  AX:Search_InitVars()

  SLASH_AUDIOX1 = "/ax"
  SLASH_AUDIOX2 = "/audiox"
  SlashCmdList["AUDIOX"] = function(msg)
    AX:SlashHandler(msg)
  end

  AX:S_SetSearchMode()
  AX:S_Hyperlink_Hook()
  AX:Print(string.format(AX.s_NB_LOADED,AX.linkcolour,SLASH_AUDIOX1,AX.s_CMD_HELP))
  AX.outputframe = AX:SetOutputFrame()
end


function AX:S_Link_MakeCmd(cmd,disp)
  return string.gsub(string.gsub(string.gsub(AX.s_linkcmdtemplate,AX.linkclrsubst,AX.s_linkcmdcolour),AX.linkaddrsubst,cmd),AX.linkpathsubst,disp)
end


-- ======================= Overwriting functions =======================


function AX:SlashHandler(command)
  local i,j,cmd,param = string.find(command, "^([^ ]+) (.+)$");
  if not cmd then
    cmd = command
  end
  if not cmd then
    cmd = ""
  end
  cmd = string.lower(cmd)
  if not param then
    param = ""
  end
  if (cmd == AX.s_CMD_SEARCH) or (cmd == AX.s_CMD_PGUP) or (cmd == AX.s_CMD_PGDN) or (cmd == AX.s_CMD_MATCH) or (cmd == AX.s_CMD_REFRESH) or (cmd == AX.s_CMD_BEGIN) then
    AX:S_SearchPreChecks(cmd,param)
  elseif (cmd == AX.s_CMD_INDEX) then
    AX:ValidateTab()
    AX:S_DisplaySoundIndex(AX:S_Cardinal(param,1,#_G[AX.searchmode]))
  elseif (cmd == AX.s_CMD_PLAY) then
    AX:S_PlayNum(AX:S_Cardinal(param,1,#_G[AX.searchmode]),AX.searchmode)
  elseif (cmd == AX.s_CMD_PLAYFAV) then
    AX:S_PlayNum(AX:S_Cardinal(param,1,#AUDIOX_FAVS),"AUDIOX_FAVS")
  elseif (cmd == AX.s_CMD_PLAYLIB) then
    AX:S_PlayNum(AX:S_Cardinal(param,1,#SoundLib),"SoundLib")
  elseif (cmd == AX.s_CMD_MPLAY) then
    AX:S_PlayNumMusic(AX:S_Cardinal(param,1,#_G[AX.searchmode]),AX.searchmode)
  elseif (cmd == AX.s_CMD_MPLAYFAV) then
    AX:S_PlayNumMusic(AX:S_Cardinal(param,1,#AUDIOX_FAVS),"AUDIOX_FAVS")
  elseif (cmd == AX.s_CMD_MPLAYLIB) then
    AX:S_PlayNumMusic(AX:S_Cardinal(param,1,#SoundLib),"SoundLib")
  elseif (cmd == AX.s_CMD_SPLAY) then
    AX:S_PlayNumSample(AX:S_Cardinal(param,1,#_G[AX.searchmode]),AX.searchmode)
  elseif (cmd == AX.s_CMD_SPLAYFAV) then
    AX:S_PlayNumSample(AX:S_Cardinal(param,1,#AUDIOX_FAVS),"AUDIOX_FAVS")
  elseif (cmd == AX.s_CMD_SPLAYLIB) then
    AX:S_PlayNumSample(AX:S_Cardinal(param,1,#SoundLib),"SoundLib")
  elseif (cmd == AX.s_CMD_QUIET) then
    AX:Quiet()
  elseif (cmd == AX.s_CMD_LIMIT) then
    AX.s_resultsperpage = AX:S_SetResultsPerPage(param)
  elseif (cmd == AX.s_CMD_CROP) then
    AX:S_SetCrop(param)
  elseif (cmd == AX.s_CMD_PATHDEPTH) then
    AX:S_SetPathDepth(param)
  elseif (cmd == AX.s_CMD_VERBOSE) then
    AUDIOX_CONFIG.verbose = AX:S_SetBool(AUDIOX_CONFIG.verbose,param,AX.s_SET_VERBOSE,false)
  elseif (cmd == AX.s_CMD_BGMUSIC) then
    AUDIOX_CONFIG.playmusic = AX:S_SetBool(AUDIOX_CONFIG.playmusic,param,AX.s_SET_BGMUSIC,false)
  elseif (cmd == AX.s_CMD_FILTER) then
    AUDIOX_CONFIG.filterchat = AX:S_SetBool(AUDIOX_CONFIG.filterchat,param,AX.s_SET_FILTER,false)
  elseif (cmd == AX.s_CMD_HIDENUM) then
    AUDIOX_CONFIG.idxinresults = AX:S_SetBool(AUDIOX_CONFIG.idxinresults,param,AX.s_SET_HIDENUM,false)
  elseif (cmd == AX.s_CMD_HIDEEXT) then
    AUDIOX_CONFIG.hideext = AX:S_SetBool(AUDIOX_CONFIG.hideext,param,AX.s_SET_HIDEEXT,false)
  elseif (cmd == AX.s_CMD_TAB) then
    AUDIOX_CONFIG.owntab = AX:S_SetBool(AUDIOX_CONFIG.owntab,param,AX.s_SET_TAB,true)
    AX.outputframe = AX:SetOutputFrame()
  elseif (cmd == AX.s_CMD_AUTOPLAY) then
    AUDIOX_CONFIG.autoplay = AX:S_SetBool(AUDIOX_CONFIG.autoplay,param,AX.s_SET_AUTOPLAY,false)
  elseif (cmd == AX.s_CMD_REGEX) then
    AUDIOX_CONFIG.regex = AX:S_SetBool(AUDIOX_CONFIG.regex,param,AX.s_SET_REGEX,false)
  elseif (cmd == AX.s_CMD_ICONLINKS) then
    AUDIOX_CONFIG.icons = AX:S_SetBool(AUDIOX_CONFIG.icons,param,AX.s_SET_ICONLINKS,false)
  elseif (cmd == AX.s_CMD_INTERPRET) then
    AUDIOX_CONFIG.interpret = AX:S_SetBool(AUDIOX_CONFIG.interpret,param,AX.s_SET_INTERPRET,false)
  elseif (cmd == AX.s_CMD_AUTOVOL) then
    AX:S_SetAutoVol(param)
  elseif (cmd == AX.s_CMD_FAVS) then
    AUDIOX_CONFIG.favs = AX:S_SetBool(AUDIOX_CONFIG.favs,param,AX.s_SET_FAVS,false)
    AX:S_SetSearchMode()
  elseif (cmd == AX.s_CMD_WHO) then
    if AX.who_loaded ~= nil then
      AX:Who_DisplayList()
    else
      AX:Load_AudioX_Plugin("AudioX_Who")
    end
  elseif (cmd == AX.s_CMD_OPTIONS) then
    if AX.opt_loaded then
      AX:Options_Toggle()
    else
      if AX:Load_AudioX_Plugin("AudioX_Options") then
        AX:Options_Toggle()
      end
    end
  elseif (cmd == AX.s_CMD_GUI) then
    if AX.ui_loaded then
      AX:UI_Toggle()
    else
      AX:Load_AudioX_Plugin("AudioX_UI")
    end
  elseif (cmd == AX.s_CMD_HELP) or (cmd == "") then
    AX:Print(string.format("|c%sAudioX II Search %s Copyright 2009-2011 Eisa of EU Aggramar/Horde. All Rights Reserved.|r",AX.linkcolour,AX.version))
    if (AX.LOCALE_BY ~= "") then
      if (GetLocale() == "deDE") then
        AX:Print(string.format("|c%s(%s: Weggls of EU-Todeswache/A)|r",AX.linkcolour,AX.LOCALE_BY))
      end    
    end
    AX:S_QPrint("Usage:")
    AX:S_QPrint(string.format(AX.s_HELP_SEARCH,		AX.linkcolour,AX.s_CMD_SEARCH,AX.s_HELPX_STRING,		AX.s_CMD_SEARCH))
    AX:S_QPrint(string.format(AX.s_HELP_PGDN,		AX.linkcolour,AX.s_CMD_PGDN,					AUDIOX_CONFIG.resultsperpage,AX.s_CMD_PGDN))
    AX:S_QPrint(string.format(AX.s_HELP_PGUP,		AX.linkcolour,AX.s_CMD_PGUP,					AUDIOX_CONFIG.resultsperpage,AX.s_CMD_PGUP))
    AX:S_QPrint(string.format(AX.s_HELP_MATCH,		AX.linkcolour,AX.s_CMD_MATCH,AX.s_HELPX_NUMBER,			AX.s_CMD_MATCH))
    AX:S_QPrint(string.format(AX.s_HELP_BEGIN,		AX.linkcolour,AX.s_CMD_BEGIN,AX.s_HELPX_NUMBER,			AX.s_CMD_BEGIN))
    AX:S_QPrint(string.format(AX.s_HELP_REFRESH,	AX.linkcolour,AX.s_CMD_REFRESH,					AX.s_CMD_REFRESH))
    AX:S_QPrint(string.format(AX.s_HELP_INDEX,		AX.linkcolour,AX.s_CMD_INDEX,AX.s_HELPX_NUMBER,			AX.s_CMD_INDEX))
    AX:S_QPrint(string.format(AX.s_HELP_FAVS,		AX.linkcolour,AX.s_CMD_FAVS,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_FAVS,tostring(AUDIOX_CONFIG.favs)))
    AX:S_QPrint(string.format(AX.s_HELP_GUI,		AX.linkcolour,AX.s_CMD_GUI,					AX.s_CMD_GUI))
    AX:S_QPrint(string.format(AX.s_HELP_WHO,		AX.linkcolour,AX.s_CMD_WHO,					AX.s_CMD_WHO))
    AX:S_QPrint(string.format(AX.s_HELP_DEFAULT,	AX.linkcolour,AX.s_HELPX_ARG,					AX.s_CMD_SEARCH,AX.s_HELPX_ARG))
    AX:S_QPrint(string.format(AX.s_HELP_HELP2,		AX.linkcolour,AX.s_CMD_HELP2,					AX.s_CMD_HELP2))
  elseif (cmd == AX.s_CMD_HELP2) then
    AX:S_QPrint(string.format(AX.s_HELP_PLAY,		AX.linkcolour,AX.s_CMD_PLAY,AX.s_HELPX_NUMBER,			#_G[AX.searchmode],AX.s_CMD_PLAY))
    AX:S_QPrint(string.format(AX.s_HELP_PLAYFAV,	AX.linkcolour,AX.s_CMD_PLAYFAV,AX.s_HELPX_NUMBER,		#AUDIOX_FAVS,AX.s_CMD_PLAYFAV))
    AX:S_QPrint(string.format(AX.s_HELP_PLAYLIB,	AX.linkcolour,AX.s_CMD_PLAYLIB,AX.s_HELPX_NUMBER,		#SoundLib,AX.s_CMD_PLAYLIB))
    AX:S_QPrint(string.format(AX.s_HELP_MPLAY,		AX.linkcolour,AX.s_CMD_MPLAY,AX.s_HELPX_NUMBER,			#_G[AX.searchmode],AX.s_CMD_MPLAY))
    AX:S_QPrint(string.format(AX.s_HELP_MPLAYFAV,	AX.linkcolour,AX.s_CMD_MPLAYFAV,AX.s_HELPX_NUMBER,		#AUDIOX_FAVS,AX.s_CMD_MPLAYFAV))
    AX:S_QPrint(string.format(AX.s_HELP_MPLAYLIB,	AX.linkcolour,AX.s_CMD_MPLAYLIB,AX.s_HELPX_NUMBER,		#SoundLib,AX.s_CMD_MPLAYLIB))
    AX:S_QPrint(string.format(AX.s_HELP_SPLAY,		AX.linkcolour,AX.s_CMD_SPLAY,AX.s_HELPX_NUMBER,			#_G[AX.searchmode],AX.s_CMD_SPLAY))
    AX:S_QPrint(string.format(AX.s_HELP_SPLAYFAV,	AX.linkcolour,AX.s_CMD_SPLAYFAV,AX.s_HELPX_NUMBER,		#AUDIOX_FAVS,AX.s_CMD_SPLAYFAV))
    AX:S_QPrint(string.format(AX.s_HELP_SPLAYLIB,	AX.linkcolour,AX.s_CMD_SPLAYLIB,AX.s_HELPX_NUMBER,		#SoundLib,AX.s_CMD_SPLAYLIB))
    AX:S_QPrint(string.format(AX.s_HELP_QUIET,		AX.linkcolour,AX.s_CMD_QUIET,					AX.s_CMD_QUIET))
    AX:S_QPrint(string.format(AX.s_HELP_HELP3,		AX.linkcolour,AX.s_CMD_HELP3,					AX.s_CMD_HELP3))
  elseif (cmd == AX.s_CMD_HELP3) then
    AX:S_QPrint(string.format(AX.s_HELP_LIMIT,		AX.linkcolour,AX.s_CMD_LIMIT,AX.s_HELPX_NUMBER,			AX.s_CMD_LIMIT,AUDIOX_CONFIG.resultsperpage))
    AX:S_QPrint(string.format(AX.s_HELP_CROP,		AX.linkcolour,AX.s_CMD_CROP,AX.s_HELPX_NUMBER,			AX.s_CMD_CROP,AUDIOX_CONFIG.pathcrop))
    AX:S_QPrint(string.format(AX.s_HELP_PATHDEPTH,	AX.linkcolour,AX.s_CMD_PATHDEPTH,AX.s_HELPX_NUMBER,		(AX.filepathmaxdepth+1),AX.s_CMD_PATHDEPTH,AUDIOX_CONFIG.pathdepth))
    AX:S_QPrint(string.format(AX.s_HELP_FILTER,		AX.linkcolour,AX.s_CMD_FILTER,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_FILTER,tostring(AUDIOX_CONFIG.filterchat)))
    AX:S_QPrint(string.format(AX.s_HELP_BGMUSIC,	AX.linkcolour,AX.s_CMD_BGMUSIC,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_BGMUSIC,tostring(AUDIOX_CONFIG.playmusic)))
    AX:S_QPrint(string.format(AX.s_HELP_HIDENUM,	AX.linkcolour,AX.s_CMD_HIDENUM,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_HIDENUM,tostring(AUDIOX_CONFIG.idxinresults)))
    AX:S_QPrint(string.format(AX.s_HELP_HIDEEXT,	AX.linkcolour,AX.s_CMD_HIDEEXT,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_HIDEEXT,tostring(AUDIOX_CONFIG.hideext)))
    AX:S_QPrint(string.format(AX.s_HELP_VERBOSE,	AX.linkcolour,AX.s_CMD_VERBOSE,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_VERBOSE,tostring(AUDIOX_CONFIG.verbose)))
    AX:S_QPrint(string.format(AX.s_HELP_TAB,		AX.linkcolour,AX.s_CMD_TAB,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.TAB_NAME,AX.s_CMD_TAB,tostring(AUDIOX_CONFIG.owntab)))
    AX:S_QPrint(string.format(AX.s_HELP_AUTOPLAY,	AX.linkcolour,AX.s_CMD_AUTOPLAY,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_AUTOPLAY,tostring(AUDIOX_CONFIG.autoplay)))
    AX:S_QPrint(string.format(AX.s_HELP_REGEX,		AX.linkcolour,AX.s_CMD_REGEX,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_REGEX,tostring(AUDIOX_CONFIG.regex)))
    AX:S_QPrint(string.format(AX.s_HELP_ICONLINKS,	AX.linkcolour,AX.s_CMD_ICONLINKS,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_ICONLINKS,tostring(AUDIOX_CONFIG.icons)))
    AX:S_QPrint(string.format(AX.s_HELP_INTERPRET,	AX.linkcolour,AX.s_CMD_INTERPRET,AX.s_VAL_TRUE,AX.s_VAL_FALSE,	AX.s_CMD_INTERPRET,tostring(AUDIOX_CONFIG.interpret)))
    AX:S_QPrint(string.format(AX.s_HELP_AUTOVOL,	AX.linkcolour,AX.s_CMD_AUTOVOL,AX.s_HELPX_NUMBER,		AX.s_CMD_AUTOVOL,(AUDIOX_CONFIG.autovol*10)))
    AX:S_QPrint(string.format(AX.s_HELP_OPTIONS,	AX.linkcolour,AX.s_CMD_OPTIONS,					AX.s_CMD_OPTIONS))
    AX:S_QPrint(string.format(AX.s_HELP_HELP,		AX.linkcolour,AX.s_CMD_HELP,					AX.s_CMD_HELP))
  else
    param = cmd
    cmd = AX.s_CMD_SEARCH
    AX:S_SearchPreChecks(cmd,param)
  end
end


function AX:PlayAsMusic(soundpath)
  AX.bgmusicplaying = true
  AX:BlizzOptions_EnableMusic()
  if AUDIOX_CONFIG.verbose or AX.api_out then
    local soundidx = AX:S_GetIdxFromPath(soundpath,false)
    if soundidx > 0 then
      AX:Notice(string.format("%s: %s (%d)",AX.NB_BGPLAYING,soundpath,soundidx))
    else
      AX:Notice(string.format("%s: %s (%s)",AX.NB_BGPLAYING,soundpath,AX.UNKNOWNIDX))
    end
  end
  PlayMusic(soundpath)
end


function AX:PlayAsSample(soundpath)
  AX.bgmusicplaying = false
  if AUDIOX_CONFIG.verbose or AX.api_out then
    local soundidx = AX:S_GetIdxFromPath(soundpath,false)
    if soundidx > 0 then
      AX:Notice(string.format("%s: %s (%d)",AX.NB_PLAYING,soundpath,soundidx))
    else
      AX:Notice(string.format("%s: %s (%s)",AX.NB_PLAYING,soundpath,AX.UNKNOWNIDX))
    end
  end
  PlaySoundFile(soundpath)
end


function AX:Play(soundpath)
  if AUDIOX_CONFIG.playmusic and (string.find(string.lower(soundpath),"music") ~= nil) then
    AX:PlayAsMusic(soundpath)
  else
    AX:PlayAsSample(soundpath)
  end
end


function AX:Notice(msg)
  if not AX.api_out then
    AX:Print(string.format("AudioX> %s",msg))
  else
    AX:API_Notice(msg)
  end
end


-- ======================== General functions ==========================


function AX:S_QPrint(msg)
  AX.outputframe:AddMessage(msg)
end


function AX:S_GetIdxFromPath(soundpath,usingsoundlib)
  local ret
  if usingsoundlib then
    return AX:BinarySearch("SoundLib",soundpath)
  else
    return AX:BinarySearch(AX.searchmode,soundpath)
  end
end


function AX:S_Cardinal(num,min,max)
  if tonumber(num) ~= nil then
    return math.max(math.min((math.modf(math.abs(tonumber(num)))),max),min)
  else
    AX:Notice(string.format(AX.s_ERR_BADNUM,min,max,min))
    return min
  end
end


function AX:S_DisplaySoundIndex(soundidx)
  if not AX.api_out then
    if (not AUDIOX_CONFIG.idxinresults) then
      AX:S_QPrint(string.format("%d %s",soundidx,AX:Link_MakeDisp(_G[AX.searchmode][soundidx])))
    else
      AX:S_QPrint(AX:Link_MakeDisp(_G[AX.searchmode][soundidx]))
    end
  else
    AX:API_LineOut(soundidx,_G[AX.searchmode][soundidx])
  end
end


function AX:S_PlayNum(soundidx,tbl)
  AX:ClickPlay(_G[tbl][soundidx])
end


function AX:S_PlayNumMusic(soundidx,tbl)
  AX:ClickPlayMusic(_G[tbl][soundidx])
end


function AX:S_PlayNumSample(soundidx,tbl)
  AX:ClickPlaySample(_G[tbl][soundidx])
end


-- ======================== Settings functions =========================


function AX:S_SetResultsPerPage_Quietly(pagelim)
  AUDIOX_CONFIG.resultsperpage = AX:S_Cardinal(pagelim,1,AX.s_maxresperpage)
  return AUDIOX_CONFIG.resultsperpage
end


function AX:S_SetResultsPerPage(pagelim)
  pagelim = AX:S_SetResultsPerPage_Quietly(pagelim)
  AX:Notice(string.format(AX.s_SET_PGLIMIT,pagelim))
  return pagelim
end


function AX:S_SetCrop_Quietly(croplen)
  AUDIOX_CONFIG.pathcrop = AX:S_Cardinal(croplen,0,AX.s_maxcroplen)
  return AUDIOX_CONFIG.pathcrop
end


function AX:S_SetCrop(croplen)
  croplen = AX:S_SetCrop_Quietly(croplen)
  if croplen > 0 then
    AX:Notice(string.format(AX.s_SET_CROP,croplen))
  else
    AX:Notice(AX.s_NB_CROPOFF)
  end
  return croplen
end


function AX:S_SetAutoVol_Quietly(vol)
  AUDIOX_CONFIG.autovol = AX:S_Cardinal(vol,0,10) / 10
  if AX.zerobgmusicvol then
    AX:BlizzOptions_AutoVolume()
  end
  return AUDIOX_CONFIG.autovol
end


function AX:S_SetAutoVol(vol)
  vol = AX:S_SetAutoVol_Quietly(vol)
  AX:Notice(string.format(AX.s_SET_AUTOVOL,vol * 10))
  return vol
end


function AX:S_SetPathDepth_Quietly(depth)
  AUDIOX_CONFIG.pathdepth = AX:S_Cardinal(depth,0,(AX.filepathmaxdepth+1))
  AX:Set_FilePathPattern()
  return AUDIOX_CONFIG.pathdepth
end


function AX:S_SetPathDepth(depth)
  depth = AX:S_SetPathDepth_Quietly(depth)
  if depth <= AX.filepathmaxdepth then
    if depth > 0 then
      AX:Notice(string.format(AX.s_SET_PATHDEPTH,depth))
    else
      AX:Notice(AX.s_NB_PATHDEPTHZERO)
    end
  else
    AX:Notice(AX.s_NB_PATHDEPTHOFF)
  end
  return depth
end


function AX:S_SetBool_Quietly(curval,param)
  param = string.lower(tostring(param))
  if (param == AX.s_VAL_TRUE) or (param == AX.s_VAL_ON) then
    curval = true
  elseif (param == AX.s_VAL_FALSE) or (param == AX.s_VAL_OFF) then
    curval = false
  else
    curval = not curval
  end
  return curval
end


function AX:S_SetBool(curval,param,txt,defaultchat)
  param = string.lower(tostring(param))
  if (param == AX.s_VAL_TRUE) or (param == AX.s_VAL_ON) then
    curval = true
    txt = string.format("%s %s",txt,AX.s_NB_SET)
  elseif (param == AX.s_VAL_FALSE) or (param == AX.s_VAL_OFF) then
    curval = false
    txt = string.format("%s %s",txt,AX.s_NB_SET)
  else
    curval = not curval
    txt = string.format("%s %s",txt,AX.s_NB_TOGGLED)
  end
  if defaultchat then
    AX:DefNotice(string.format("%s %s",txt,tostring(curval)))
  else
    AX:Notice(string.format("%s %s",txt,tostring(curval)))
  end
  return curval
end


function AX:S_SetSearchMode()
  if AUDIOX_CONFIG.favs then
    AX.searchmode = "AUDIOX_FAVS"
  else
    AX.searchmode = "SoundLib"
  end
end


-- ========================== Search Functions =========================


function AX:S_SearchPreChecks(cmd,param)
  AX:API_ChatOutput(false)
  return AX:S_SearchChecks(cmd,param)
end


function AX:S_TranslateKeyword(keyword)
  if #AX.s_SRCHTRANS > 0 then
    local transmat = {}
    local transmatpos = 0
    local x,y,seeking,replacing,mixedcase
    local txt = string.gsub(keyword,"\t","")
    if (txt == string.lower(txt)) or (txt == string.upper(txt)) then
      mixedcase = false
      txt = string.lower(txt)
    else
      mixedcase = true
    end
    for srchtranspos=1,#AX.s_SRCHTRANS do
      if mixedcase then
        seeking = AX.s_SRCHTRANS[srchtranspos][1]
       else
        seeking = string.lower(AX.s_SRCHTRANS[srchtranspos][1])
      end
      x,y = string.find(txt,seeking,1,true) 
      while (x ~= nil) do
        transmatpos = transmatpos + 1
        transmat[transmatpos] = {x,AX.s_SRCHTRANS[srchtranspos][2]}
        x,y = string.find(txt,seeking,y+1,true)
      end
      txt = string.gsub(txt,seeking,string.rep("\t",#seeking))
    end 
    x,y = string.find(txt,"[^\t]+",1,false)
    while (x ~= nil) do
      transmatpos = transmatpos + 1
      transmat[transmatpos] = {x,string.sub(txt,x,y)}
      x,y = string.find(txt,"[^\t]+",y+1,false)
    end
    if transmatpos > 0 then
      table.sort(transmat, function(a,b) return a[1] < b[1] end)
      txt=""
      for i=1,transmatpos do
        txt=string.format("%s%s",txt,transmat[i][2])
      end
      if not mixedcase then
        txt = string.lower(txt)
      end
      keyword = txt       
    end       
  end
  return keyword
end


function AX:S_SearchChecks(cmd,param)
  AX.s_searchsuccess = false
  if not AX.api_out then
    AX.s_resultsperpage = AUDIOX_CONFIG.resultsperpage
  else
    AX.s_resultsperpage = AX.api_resperpage 
  end
  if (string.sub(param,1,1) == "#") and (cmd == AX.s_CMD_SEARCH) then
    AX:S_DisplaySoundIndex(AX:S_Cardinal(tonumber(string.sub(param,2)),1,#_G[AX.searchmode]))
    AX.s_searchsuccess = true
  else
    -- UI concessions
    local _,_,c,p = string.find(param,"^/(%a) (.+)$")
    if (c == AX.s_CMD_MATCH) or (c == AX.s_CMD_BEGIN) then
      cmd = c
      param = p
    end
    -- end UI concessions
    if (not AX.searchbuilt) and (cmd ~= AX.s_CMD_SEARCH) then
      AX:S_BuildSearchLookup()
    end
    if (cmd == AX.s_CMD_PGDN) then
      AX:S_SearchNext()
    elseif (cmd == AX.s_CMD_PGUP) then
      AX:S_SearchPrev()
    elseif (cmd == AX.s_CMD_REFRESH) then
      AX:S_SearchRefresh()
    elseif (cmd == AX.s_CMD_MATCH) then
      AX:S_SearchMatch(AX:S_Cardinal(param,1,#AX.s_SearchResults))
    elseif (cmd == AX.s_CMD_BEGIN) then
      AX:S_SearchBeginAt(AX:S_Cardinal(param,1,#_G[AX.searchmode]))
    else
      AX:S_SearchNew(param)
    end
  end
  return AX.s_searchsuccess
end


function AX:S_BuildSearchLookup()
  local oldsize = #AX.s_SearchResults
  local pos = 0
  local keyword = AX.s_searchkeyword
  if not AUDIOX_CONFIG.interpret then
    for idx,path in ipairs(_G[AX.searchmode]) do
      if (string.find(string.lower(path),keyword,1,not(AUDIOX_CONFIG.regex)) ~= nil) then
        pos = pos + 1
        AX.s_SearchResults[pos] = idx
      end  
    end
  else
    local userkeyword = string.lower(AX.s_userkeyword)
    local lowerpath
    for idx,path in ipairs(_G[AX.searchmode]) do
      lowerpath = string.lower(path)
      if (string.find(lowerpath,keyword,1,not(AUDIOX_CONFIG.regex)) ~= nil) or (string.find(lowerpath,userkeyword,1,not(AUDIOX_CONFIG.regex)) ~= nil) then
        pos = pos + 1
        AX.s_SearchResults[pos] = idx
      end  
    end
  end
  if oldsize > pos then
    for idx = (pos+1),oldsize do
      table.remove(AX.s_SearchResults)
    end
  end
  AX.searchbuilt = true
end


function AX:S_SearchSub(startpos)
  AX:ValidateTab()
  local linecount = 0
  local curpos = AX:S_Cardinal(startpos,1,#AX.s_SearchResults)
  AX.s_redosearchpos = curpos
  while (curpos <= #AX.s_SearchResults) and (linecount < AX.s_resultsperpage) do
    AX:S_DisplaySoundIndex(AX.s_SearchResults[curpos])
    linecount = linecount + 1
    curpos = curpos + 1
  end
  local userkeyword = string.lower(AX.s_userkeyword)
  if not AX.api_out then
    local out = string.format(AX.s_MATCHES,startpos,linecount-1+startpos,#AX.s_SearchResults,AX.s_searchkeyword)
    if (AUDIOX_CONFIG.interpret) and (AX.s_searchkeyword ~= userkeyword) then
      out = string.format("%s %s",out,string.format(AX.s_MATCHES2,userkeyword))
    end
    AX:Notice(string.format("%s %s.",AX.s_footerlinks,out))
  else
    if (not AUDIOX_CONFIG.interpret) or (AX.s_searchkeyword == userkeyword) then
       userkeyword = nil
    end
    AX:API_PageFooter(startpos,linecount-1+startpos,#AX.s_SearchResults,AX.s_searchkeyword,userkeyword)
  end
  AX.s_searchsuccess = true
end


function AX:S_SearchNew(keyword)
  AX.s_userkeyword = keyword
  if (AUDIOX_CONFIG.interpret) and (#AX.s_SRCHTRANS > 0) then
    keyword = AX:S_TranslateKeyword(keyword)
  end
  AX.s_searchkeyword = string.lower(keyword)
  AX.searchbuilt = false
  AX:S_BuildSearchLookup()
  AX:S_SearchSub(1)
end


function AX:S_SearchNext()
  local nextpos =  AX.s_redosearchpos + AX.s_resultsperpage
  if nextpos <= #AX.s_SearchResults then
    AX:S_SearchSub(nextpos)
  else
    AX:Notice(AX.s_SRCH_FWDDONE)
  end
end


function AX:S_SearchPrev()
  local prevpos = math.max((AX.s_redosearchpos - AX.s_resultsperpage),1)
  if AX.s_redosearchpos <= 1 then
    AX:Notice(AX.s_SRCH_REVDONE)
  else
    AX:S_SearchSub(prevpos)
  end
end


function AX:S_SearchRefresh()
  AX:S_SearchSub(AX.s_redosearchpos)
end


function AX:S_SearchMatch(match)
  AX:S_SearchSub(match)
end


function AX:S_SearchBeginAt(idx)
  local ele = 0
  local found = false
  while (ele < #AX.s_SearchResults) and (not found) do
    ele = ele + 1
    if AX.s_SearchResults[ele] >= idx then
      found = true
    end
  end
  if found then
    AX:S_SearchMatch(ele)
  end
end


-- ===================== Edit Box: Command links =======================


function AX:S_Hyperlink_Hook()
  local SetItemRef_orig = SetItemRef

  local function AX_SetItemRef(...)
    local link,text,button = ...
    if (type(link) == "string") and (strsub(link, 1, #AX.s_linkcmdident) == AX.s_linkcmdident) then
      local cmd = string.sub(link,(2+#AX.s_linkcmdident))
      if (ChatEdit_GetActiveWindow()) and (IsShiftKeyDown()) then
        if cmd == AX.s_linkcmdquiet then
          AX:Notice(string.format(AX.s_NOT_LINKABLE,AX.s_LINK_QUIET))
        elseif cmd == AX.s_linkcmdpgdn then
          AX:Notice(string.format(AX.s_NOT_LINKABLE,AX.s_LINK_PGDN))
        elseif cmd == AX.s_linkcmdpgup then
          AX:Notice(string.format(AX.s_NOT_LINKABLE,AX.s_LINK_PGUP))
        elseif cmd == AX.s_linkcmdrefresh then
          AX:Notice(string.format(AX.s_NOT_LINKABLE,AX.s_LINK_REFRESH))
        end
      elseif cmd == AX.s_linkcmdquiet then
        AX:Quiet()
      elseif cmd == AX.s_linkcmdpgdn then
        AX:S_SearchPreChecks(AX.s_CMD_PGDN,"")
      elseif cmd == AX.s_linkcmdpgup then
        AX:S_SearchPreChecks(AX.s_CMD_PGUP,"")
      elseif cmd == AX.s_linkcmdrefresh then
        AX:S_SearchPreChecks(AX.s_CMD_REFRESH,"")
      end
    else
      SetItemRef_orig(link,text,button)
    end
  end

  SetItemRef = AX_SetItemRef
end
