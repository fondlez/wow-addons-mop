﻿

AtlasQuest
维护： Thandrenn (亦称 Mystery8)
电子邮件：mystery8@gmail.com
论坛：http://www.atlasmod.com/phpBB3/viewforum.php?f=7



关于 AtlasQuest:
=================

AtlasQuest 是一个基于 Atlas 的扩展插件。它能够显示每个副本，战场和户外首领的相关任务，
并且有注释能够告诉你如何完成这个任务。而副本背景介绍和简单的boss攻略能让你的副本更轻松。

AtlasQuest的原作者是 Asurn，现在由 Thandren（亦称 Mystery8）维护更新。

AtlasQuest 中的第一手游戏数据从 WoWhead.com 和 WoWpedia.org 活得。


本地化作者：
=============
英语：Thandrenn (原由 Asurn 和 lothaer 更新)
德语：Guldukat (原由 Asurn 和 Nihlo 和 Telchar 和 Nalumis)
中文(简)：Yeachan 和 Ananhaid (原由 DIY 更新)
中文(繁)：Jill
俄语：EvgeshaH (Non-WOTLK by lorientalas)



授权许可:
========

AtlasQuest 的发布遵循 GNU通用公共许可证 (GPL).
查看该准则的详细内容请至: gpl-v2-cn.txt
