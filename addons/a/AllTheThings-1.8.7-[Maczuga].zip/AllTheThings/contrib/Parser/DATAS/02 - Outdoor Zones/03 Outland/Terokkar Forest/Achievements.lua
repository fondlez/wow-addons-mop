---------------------------------------------------
--          Z O N E S        M O D U L E        	--
---------------------------------------------------
_.Zones =
{
	{	-- Outland
		["mapID"] = 101,	-- Outland
		["groups"] = {
			{	-- Terokkar Forest
				["mapID"] = 108,	-- Terokkar Forest
				["groups"] = {
					n(-4, {	-- Achievements
						ach(1275),	-- Bombs Away
					}),
				},
			},
		},
	},
};