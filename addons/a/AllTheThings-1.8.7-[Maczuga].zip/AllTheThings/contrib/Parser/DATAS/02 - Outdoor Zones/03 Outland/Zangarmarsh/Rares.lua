_.Zones =
{
	{	-- Outland
		["mapID"] = 101,	-- Outland
		["groups"] = {
			{	-- Zangarmarsh
				["mapID"] = 102,	-- Zangarmarsh
				["groups"] = {
					n(-16,  {	-- Rares
						n(18682, {	-- Bog Lurker
							i(31248),	-- Bog Epaulets
							i(31250),	-- Bog Mantle
							i(31247),	-- Bog Pauldrons
							i(31249),	-- Bog Spaulders
						}),
						n(18681, {	-- Coilfang Emissary
							i(31246),	-- Nagahide Leggings
							i(31244),	-- Nagahide Pants
							i(31243),	-- Nagascale Legguards
							i(31242),	-- Nagascale Legplates
						}),
						n(18680, {	-- Marticar
							i(31254),	-- Striderhide Cloak
						}),
					}),
				},
			},
		},
	},
};