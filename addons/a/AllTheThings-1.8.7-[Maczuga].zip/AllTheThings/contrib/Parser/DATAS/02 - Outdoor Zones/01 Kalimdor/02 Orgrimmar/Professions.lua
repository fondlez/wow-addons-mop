---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor		
		m(85, {	-- Orgrimmar
			["groups"] = {
				n(  -38, {	-- Profession
					prof(356, { -- Fishing
						["groups"] = {
							i(34486),		-- Old Crafty
						},
						["description"] = "Go fishing for a bit in Orgrimmar.",	
					}),
				}),
			},
		}),
	}),
};
