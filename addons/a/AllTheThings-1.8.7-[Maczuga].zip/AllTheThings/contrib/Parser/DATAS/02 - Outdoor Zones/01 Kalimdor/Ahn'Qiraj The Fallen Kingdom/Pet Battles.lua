---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(327, {	-- Ahn'Qiraj: The Fallen Kingdom
			["groups"] = {
				n(-25, { 	-- Pet Battle
					desc(p(513), "Starts spawning March 20th. Stops spawning September 23rd."), -- Qiraji Guardling
					desc(p(512), "Can be found near the gates of Ahn'Qiraj, or in the un-instanced zone south of Silithus."),-- Scarab Hatchling
					p(511), 	-- Sidewinder
				}),
			},
		}),
	}),
};
