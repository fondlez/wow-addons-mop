---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(106, {	-- Bloodmyst Isle
			["groups"] = {
				n(-25, {	-- Pet Battle
					p(628),	-- Infected Fawn
					p(627),	-- Infected Squirrel
					p(417),	-- Rat
					p(465),	-- Ravager Hatchling
					p(397),	-- Skunk
				}),
			},
		}),
	}),
};
