---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(62, {	-- Darkshore
			["groups"] = {
				n(0, {	-- Zone Drop
					{	-- Pattern: Robes of Arcana
						["itemID"] = 5773,
						["u"] = 7,
						["crs"] = {
							2337,	-- Dark Strand Voidcaller (removed in cata)
						},
					},
				}),
			},
		}),
	}),
};
