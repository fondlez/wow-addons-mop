---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(97, {	-- Azuremyst Isle
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(624, {	-- Azure Watch, Azuremyst Isle [A]
						["description"] = "Azure Watch, Azuremyst Isle - Alliance Only",
						["coord"] = { 49.6, 49.2, 97 },
					}),
				}),
			},
		}),
	}),
};
