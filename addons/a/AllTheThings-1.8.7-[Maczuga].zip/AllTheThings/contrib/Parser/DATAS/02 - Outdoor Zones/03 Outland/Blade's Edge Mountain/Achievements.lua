---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Outland
		["mapID"] = 101,	-- Outland
		["g"] = {
			{	-- Blade's Edge Mountains
				["mapID"] = 105,	-- Blade's Edge Mountains
				["g"] = {
					n(-4, {		-- Achievements
						ach(1276),	-- Blade's Edge Bomberman
					}),
				},
			},
		},
	},
};