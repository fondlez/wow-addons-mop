---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(89, {	-- Darnassus
			["groups"] = {
				n(-228, {	-- Flight Path
					fp(457, {	-- Darnassus, Teldrassil [A]
						["description"] = "Darnassus, Teldrassil - Alliance Only",
						["coords"] = {
							{ 36.61, 47.82, 89 },
						},
					}),
				}),
			},
		}),
	}),
};
