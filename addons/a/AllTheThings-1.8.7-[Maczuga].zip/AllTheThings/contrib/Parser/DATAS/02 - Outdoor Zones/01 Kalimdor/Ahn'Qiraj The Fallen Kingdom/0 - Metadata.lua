---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(327, {	-- Ahn'Qiraj: The Fallen Kingdom
			["icon"] = "Interface\\Icons\\achievement_zone_silithus_01",
			["description"] = "|cff66ccffThis is an outdoor zone, a non-instanced version of Temple of Ahn'Qiraj and Ruins of Ahn'Qiraj. There are no mobs or entrances to the interior of the Ahn'Qiraj temple.|r",
		}),
	}),
};
