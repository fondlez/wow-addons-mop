---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones = 
{
	m(12, {	-- Kalimdor
		m(198, {	-- Mount Hyjal
			["groups"] = {
				n(-16, {	-- Rares	
					n(50057, { 		-- Blazewing
						dr( 100, i(67236)),	-- Blazewing's Furious Kilt
					}), 
					n(50053, { 		-- Thartuk the Exile
						dr( 100, i(67234)),	-- Thartuk's Inimitable Gauntlets
					}), 
--[[					
	--				n(54318, { 		-- Ankha 	}), 
	--				n(54320, { 		-- Ban'thalos 	}),
	--				n(54319, { 		-- Magria 	}), 
	--				n(50058, { 		-- Terrorpene 	}), 
--]]	
				}),
			},
		}),
	}),
};
