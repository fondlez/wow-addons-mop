---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(57, {	-- Teldrassil
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(456, { -- Dolanaar, Teldrassil
						["coord"] = { 55.4, 50.4, 57 },
					}),
					fp(27, { -- Rut'theran Village, Teldrassil
						["coord"] = { 55.4, 88.4, 57 },
					}),
				}),
			},
		}),
	}),
};
