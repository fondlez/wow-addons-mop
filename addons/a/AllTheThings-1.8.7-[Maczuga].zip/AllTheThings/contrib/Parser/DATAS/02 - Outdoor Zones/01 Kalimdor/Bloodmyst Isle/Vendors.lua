---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(106, {	-- Bloodmyst Isle
			["groups"] = {
				n(-2, {	-- Vendors
					n(18427, {	-- Fazu <Tradesman>
						["coord"] = { 53.4, 56.6, 106 },
						["races"] = ALLIANCE_ONLY,
						["groups"] = {
							i(22647),	-- Recipe: Crunchy Spider Surprise
						},
					}),
				}),
			},
		}),
	}),
};
