---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(76, {	-- Azshara
			["groups"] = {
				n(-4, {	-- Achievements
					ach(5448),	-- Glutton for Fiery Punishment
					ach(5546),	-- Glutton for Icy Punishment
					ach(5547),	-- Glutton for Shadowy Punishment
					h(ach(5454)),	-- Joy Ride
				}),
			},
		}),
	}),
};
