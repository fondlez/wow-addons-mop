---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(106, {	-- Bloodmyst Isle
			["groups"] = {
				n(-228, {	-- Flight Path
					fp(93, {	-- Blood Watch, Bloodmyst Isle [A]
						["description"] = "Blood Watch, Bloodmyst Isle - Alliance Only",
						["coord"] = { 57.6, 54, 106 },
					}),
				}),
			},
		}),
	}),
};
