---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(198, {	-- Mount Hyjal
			["groups"] = {
				n(-38, {	-- Profession
					prof(356, {
						o(202776, {	-- Mountain Trout School
							["groups"] = {
								i(22739),	-- Tome of Polymorph: Turtle
							},
						}),
					}),
				}),				
			},
		}),
	}),
};
