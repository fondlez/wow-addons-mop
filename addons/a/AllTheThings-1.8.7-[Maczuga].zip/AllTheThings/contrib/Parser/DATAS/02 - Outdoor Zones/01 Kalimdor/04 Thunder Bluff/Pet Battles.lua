---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor	
		m(88, {	-- Thunder Bluff
			["groups"] = {
				n(-25, {	-- Pet Battle
					p(477),	-- Gazelle Fawn
					p(385),	-- Mouse
					p(386),	-- Prairie Dog
					p(378),	-- Rabbit
				}),
			},
		}),
	}),
};
