---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(1, {	-- Durotar
			m(463, {	-- Echo Isles
				["groups"] = {
					n(-25, {	-- Pet Battle
						p(467), -- Dung Beetle
						p(466), -- Spiny Lizard
					}),
				},
			}),
		}),
	}),
};
