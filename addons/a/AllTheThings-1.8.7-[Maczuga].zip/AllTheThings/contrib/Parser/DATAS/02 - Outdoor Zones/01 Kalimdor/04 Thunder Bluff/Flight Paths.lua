---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Kalimdor
		["mapID"] = 12,	-- Kalimdor
		["g"] = {
			{	-- Thunder Bluff
				["mapID"] = 88,
				["g"] = {
					{	-- Flight Paths
						["npcID"] = -228,	-- Flight Paths
						["g"] = {
							{	-- Thunder Bluff, Mulgore
								["flightPathID"] = 22,	-- Thunder Bluff, Mulgore
								["coords"] = {
									{ 47.06, 49.59, 88 },
								},
							},
						},
					},
				},
			},
		},
	},
};
