---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(1, {	-- Durotar
			["groups"] = {
				n(-228, {	-- Flight Paths
					fp(537, {	-- Razor Hill, Durotar
						["coord"] = { 53, 43.6, 1 },
					}),
					fp(536, {	-- Sen'jin Village, Durotar
						["coord"] = { 55.4, 73.4, 1 },
					}),
				}),
			},
		}),
	}),
};
