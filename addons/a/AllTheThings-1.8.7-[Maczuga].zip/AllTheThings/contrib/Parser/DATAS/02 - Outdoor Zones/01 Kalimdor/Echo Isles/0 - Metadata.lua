---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(1, {	-- Durotar
			m(463, {	-- Echo Isles
				["maps"] = { 464 }, -- Spitescale Cavern
				["icon"] = "Interface\\Icons\\Achievement_Character_Troll_Male",
				["description"] = "|cff66ccff The Echoes Isles are the ancestral home of the Darkspear Trolls. Vol'jin, the leader of the trolls, has relocated here after tensions between Hellscream and the trolls.|r",
			}),
		}),
	}),
};
