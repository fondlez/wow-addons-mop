---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(77, {	-- Felwood
			["achievementID"] = 853,
			["lvl"] = 40,
			["description"] = "|cff66ccffFelwood is a corrupted forest filled with demons and satyrs. It is also home to one of the few remaining uncorrupted furbolg tribes, the Timbermaw. There are also new Worgen/Goblin settlements and quests dealing with the deforestation of the Irontree Woods.|r",
		}),
	}),
};
