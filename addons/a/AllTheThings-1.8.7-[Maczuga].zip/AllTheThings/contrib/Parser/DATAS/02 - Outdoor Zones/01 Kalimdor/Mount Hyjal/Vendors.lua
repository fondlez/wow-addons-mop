---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones = 
{
	m(12, {	-- Kalimdor
		m(198, {	-- Mount Hyjal
			["groups"] = {
				n( -2, {	-- Vendors
					n(50314, {	-- Provisioner Whitecloud <Guardians of Hyjal Quartermaster>
						i(65906),	-- Tabard of the Guardians of Hyjal
						i(62378),	-- Acorn of the Daughter Tree
						i(62376),	-- Mountain's Mouth
						i(62377),	-- Cloak of the Dryads
						i(62383),	-- Wrap of the Great Turtle
						i(62381),	-- Aessina- Blessed Gloves
						i(62384),	-- Belt of the Ferocious Wolf
						i(62386),	-- Cord of the Raven Queen
						i(62374),	-- Sly Fox Jerkin
						i(62380),	-- Wilderness Legguards
						i(62385),	-- Treads of Malorne
						i(62382),	-- Waywatcher's Boots
						i(62375),	-- Galrond's Band
					}),
				}),
			},
		}),
	}),
};
