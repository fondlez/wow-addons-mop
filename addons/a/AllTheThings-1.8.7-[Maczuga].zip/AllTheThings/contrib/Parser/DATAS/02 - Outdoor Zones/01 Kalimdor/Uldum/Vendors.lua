---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(249, {	-- Uldum
			["groups"] = {
				n(-2,  {	-- Vendors
					n(48617, {	-- Blacksmith Abasi <Ramkahen Quartermaster>
						["groups"] = {
							i(63044),	-- Reins of the Brown Riding Camel Mount
							i(63045),	-- Reins of the Tan Riding Camel Mount
							i(65904),	-- Tabard of Ramkahen
							i(62448),	-- Sun King's Girdle
							i(62449),	-- Sandguard Bracers
							i(62450),	-- Desert Walker Sandals
							i(62441),	-- Robes of Orsis
							i(62445),	-- Sash of Prophecy
							i(62446),	-- Quicksand Belt
							i(62437),	-- Shroud of the Dead
							i(62438),	-- Drystone Greaves
							i(62439),	-- Belt of the Stargazer
							i(62436),	-- Ammunae's Blessing
							i(62440),	-- Red Rock Band
							i(62447),	-- Gift of Nadun
						},
						["coord"] = { 54.0, 33.2, 249 },
					}),
				}),
			},
		}),
	}),
};
