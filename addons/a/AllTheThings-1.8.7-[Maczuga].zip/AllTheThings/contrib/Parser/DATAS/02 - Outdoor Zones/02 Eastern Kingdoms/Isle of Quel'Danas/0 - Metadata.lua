---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	{	-- Eastern Kingdoms
		["mapID"] = 13,	-- Eastern Kingdoms
		["g"] = {
			{	-- Isle of Quel'Danas
				["mapID"] = 122,	-- Isle of Quel'Danas
				["lvl"] = 70,	
				["achievementID"] = 868,
				--["description"] = "|cff66ccffThe Isle of Quel'Danas is an island located north of Eversong Woods. It is most commonly reached by the direct portal from Shattrath City. It is the major daily quest hub for the Shattered Sun Offensive, a group of Aldor and Scryers working together to reclaim the island from Kael'thas, who reactivated the Sunwell.|r",	
			},
		},
	},
};