---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor
		m(57, {	-- Teldrassil
			m(460, {	-- Shadowglen
				["groups"] = {
					n(-25, {	-- Pet Battle
						p(507), -- Crested Owl
						p(447), -- Fawn
					}),
				},
			}),
		}),
	}),
};
