---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones =
{
	m(12, {	-- Kalimdor		
		m(85, {	-- Orgrimmar
			["maps"] = { 86 }, -- The Drag
			["icon"] = "Interface\\Icons\\Inv_misc_tournaments_symbol_orc",
			["isRaid"] = true,
			["lvl"] = 1,
			["description"] = "|cff66ccffOrgrimmar is the capital city of the Horde, with large settlements of trolls, orcs, tauren, and goblins.|r",
		}),
	}),
};
