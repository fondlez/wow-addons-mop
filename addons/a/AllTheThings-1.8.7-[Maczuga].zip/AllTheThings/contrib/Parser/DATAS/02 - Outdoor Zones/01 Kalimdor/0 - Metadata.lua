---------------------------------------------------
--          Z O N E S        M O D U L E         --
---------------------------------------------------
_.Zones = {
	m(12, { -- Kalimdor
		["achievementID"] = 43,
		["icon"] = "Interface\\Icons\\achievement_zone_kalimdor_01",
		["description"] = "|cff66ccffKalimdor is home to the night elves, orcs, tauren, trolls, and draenei. Other races present include the ogres, centaur, naga, demons, and other, more minor races. |r",
	}),
};