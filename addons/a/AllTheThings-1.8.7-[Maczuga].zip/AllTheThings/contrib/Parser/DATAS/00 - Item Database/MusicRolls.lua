_.ItemDB = {};
local i = function(itemID, questID)
	_.ItemDB[itemID] = { ["musicRollID"] = questID };
end
