﻿# AutoRole

AutoRole sets your role based on your current specialization automatically any time you join a group or raid and updates it any time you change specializations.

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)][1]

### [Main Page][2]
The main page for AutoRole on Curse.

### [Development Page][3]
The development page for AutoRole on CurseForge.

### Addon Usage
No user interaction is required for the addon to function. Type /ar role to see your current role.

 [1]: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4XM54KBN39VLG
 [2]: http://www.curse.com/addons/wow/auto-role
 [3]: http://wow.curseforge.com/addons/auto-role
