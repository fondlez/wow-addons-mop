Atlas, a World of Warcraft instance map browser
Copyright 2005 ~ 2010 - Dan Gilbert <dan.b.gilbert@gmail.com>
Copyright 2010 - Lothaer <lothayer@gmail.com>, Atlas Team
Copyright 2011 ~ 2013 - Arith Hsu, Atlas Team <atlas.addon@gmail.com>


=====================
= About This Plugin =
=====================

This is an Atlas plug-in that display dungeons and the locations' maps.

In the past this plug-in was built-in with Atlas' core release. And right now 
we are splitting it out to be an individual addon so that you can decide 
whether to download it or not. 


=====================
= Before Installing =
=====================

Note that in order to make this addon to work properly, you will still need to 
have a latest Atlas downloaded and installed


=============
= Resources =
=============

The official Atlas website is:
http://www.atlasmod.com/

For questions or support, please visit the forums:
http://www.atlasmod.com/phpBB3/


===========
= Contact =
===========

You may contact the project owner in below address:
atlas.addon@gmail.com
Or visit our forum and leave your message.


===========
= License =
===========

Atlas is released under the GNU General Public License (GPL).
For the full license text please see: gpl-v2-enUS.txt

You can use this addon without any charge. If you would like to make some 
donation, you are welcome to do so.

You can also distribute this addon but only with no charge to your users. 
If you are going to include part of the codes, graphics, or any file(s) from 
this addon in your own product(s), please write us an email to inform us, and 
please also to include our team members�� name as part of your product credits.
