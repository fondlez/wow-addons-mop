# Changelog for "jButtonFlash"

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0-fondlez] - 2025-03-22

### Added
- addon Bartender4 support

## [1.0.0-fondlez] - 2025-01-07

Initial upload.

### Added
- README.md
- changelog.md

### Changed
- backported addon to game client versions for WoD, MoP, Cata and WotLK.