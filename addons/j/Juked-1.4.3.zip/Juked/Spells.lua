--CHANGELOG:
--I may have missed some cooldown changes, may also need to add/remove other spells just let me know
--changed strangulate to 60 sec (v1.4.3)
--changed silencing shot to 24 sec (v1.4.3)
--changed shadowstep to 20 sec (v1.4.3)
--changed blind to 120 sec (v1.4.3)
--changed shockwave to 20 sec (v1.4.3)
--changed mass entanglement to 30 sec (v1.4.3)
--changed void shift to 5 min (v1.4.3)
--changed deterrence to 180 sec (v1.4.3)
--changed astral shift to 90 sec (v1.4.3)
--changed healing tide totem to 180 sec (v1.4.3)
--changed shield wall to 180 sec (v1.4.3)
--changed bladestorm to 60 sec (v1.4.3)
--changed recklessness to 180 sec (v1.4.3)
--changed nature's vigil to 90 sec (v1.4.3)
--changed elemental mastery to 90 sec (v1.4.3)
--changed vanish to 120 sec (v1.4.3)
--changed dark simulacrum to 30 sec (v1.4.3)
--changed powershot to 45 sec (v1.4.3)
--changed alter time to 180 sec (v1.4.3)
--added bloodbath (v1.4.3)
--added marked for death (v1.4.3)
--removed Archimonde's Vengeance(v1.4.3)
--removed Readiness(v1.4.3)
--removed Dominate Mind(v1.4.3)
--Changed cloak of shadows cd to 60 sec
--Added Carrion Swarm (Thanks Shivtey)(v1.4.2)
--Added optical blast, changed ring of frost and intimidating shout for 5.1(v1.4.1)
--Added some/most new spells, may need tweaking - open to suggestions(v1.4.0)
--Removed obsolete spells for MoP (v1.3.9) 

spell_table = {
--Interrupts and Silences
{spellID=6552, time=15, prio=true},--Pummel
{spellID=23920, time=25, prio=false},--Spell Reflection
{spellID=1766, time=15, prio=true},--Kick 
{spellID=47528, time=15, prio=true},--Mind Freeze
{spellID=47476, time=60, prio=false},--Strangulate
{spellID=96231, time=15, prio=true},--Rebuke
{spellID=31935, time=15, prio=true},--Avengers Shield
{spellID=57994, time=12, prio=true},--Wind Shear
{spellID=2139, time=24, prio=true},--Counterspell
{spellID=19647, time=24, prio=true},--Spell Lock
{spellID=103967, time=12, prio=false},--Carrion Swarm
{spellID=115781, time=24, prio=false},--Optical Blast
{spellID=34490, time=24, prio=true},--Silencing Shot
{spellID=80965, time=15, prio=true},--Skull Bash
{spellID=78675, time=60, prio=true},--Solar Bream
{spellID=116705, time=15, prio=true},--Spear Hand Strike
{spellID=15487, time=45, prio=false},--Silence
{spellID=114028, time=60, prio=false},--Mass Spell Reflect

--Gap Closers
{spellID=100, time=20, prio=false},--Charge 
{spellID=49576, time=25, prio=false},--Death Grip
{spellID=36554, time=20, prio=false},--Shadowstep 
{spellID=1953, time=15, prio=false},--Blink

--CC
{spellID=51514, time=35, prio=false},--Hex 
{spellID=51485, time=30, prio=false},--Earthgrab Totem
{spellID=44572, time=30, prio=false},--Deep Freeze
{spellID=113724, time=45, prio=false},--Ring of Frost 
{spellID=19503, time=30, prio=false},--Scatter Shot
{spellID=2094, time=120, prio=false},--Blind
{spellID=51722, time=60, prio=false},--Dismantle
{spellID=20511, time=90, prio=false},--Intimidating Shout
{spellID=676, time=60, prio=false},--Disarm
{spellID=107566, time=40, prio=false},--Staggering Shout
{spellID=102060, time=40, prio=false},--Disrupting Shout
{spellID=46968, time=40, prio=false},--Shockwave
{spellID=118000, time=60, prio=false},--Dragon Roar
{spellID=5484, time=40, prio=false},--Howl of Terror
{spellID=6789, time=45, prio=false},--Mortal Coil
{spellID=30283, time=30, prio=false},--Shadowfury
{spellID=64044, time=35, prio=false},--Psychic Horror
{spellID=108921, time=45, prio=false},--Psyfiend
{spellID=108920, time=30, prio=false},--Void Tendrils
{spellID=8122, time=30, prio=false},--Psychic Scream
{spellID=20066, time=15, prio=false},--Repentance
{spellID=853, time=60, prio=false},--Hammer of Justice
{spellID=105593, time=30, prio=false},--Fist of Justice
{spellID=115750, time=120, prio=false},--Blinding Light
{spellID=91800, time=60, prio=false},--Gnaw
{spellID=108194, time=30, prio=false},--Asphyxiate
{spellID=102359, time=30, prio=false},--Mass Entanglement
{spellID=5211, time=50, prio=false},--Mighty Bash
{spellID=99, time=30, prio=false},--Disorienting Roar
{spellID=102793, time=60, prio=false},--Ursol's Vortex
{spellID=115078, time=15, prio=false},--Paralysis
{spellID=117368, time=60, prio=false},--Grapple Weapon

--Defensive
{spellID=31224, time=60, prio=false},--Cloak of Shadows
{spellID=74001, time=120, prio=false},--Combat Readiness
{spellID=47585, time=105, prio=false},--Dispersion
{spellID=112833, time=30, prio=false},--Spectral Guise
{spellID=108698, time=300, prio=false},--Void Shift
{spellID=33206, time=180, prio=false},--Pain Suppression
{spellID=48707, time=45, prio=false},--Anti-Magic Shell
{spellID=51052, time=120, prio=false},--Anti-Magic Zone
{spellID=48792, time=180, prio=false},--Icebound Fortitude
{spellID=96268, time=30, prio=false},--Death's Advance
{spellID=642, time=300, prio=false},--Divine Shield
{spellID=19263, time=180, prio=false},--Deterrence
{spellID=109304, time=120, prio=false},--Exhilaration
{spellID=48020, time=26, prio=false},--Demonic Circle: Teleport
{spellID=104773, time=180, prio=false},--Unending Resolve
{spellID=108359, time=120, prio=false},--Dark Regeneration
{spellID=110913, time=180, prio=false},--Dark Bargain
{spellID=108416, time=60, prio=false},--Sacrificial Pact
{spellID=108482, time=60, prio=false},--Unbound Will
{spellID=22812, time=60, prio=false},--Barkskin
{spellID=106922, time=180, prio=false},--Might of Ursoc
{spellID=61336, time=180, prio=false},--Survival Instincts
{spellID=108238, time=120, prio=false},--Renewal
{spellID=45438, time=300, prio=false},--Ice Block
{spellID=98008, time=180, prio=false},--Spirit Link Totem
{spellID=108271, time=90, prio=false},--Astral Shift
{spellID=108280, time=180, prio=false},--Healing Tide Totem
{spellID=108273, time=60, prio=false},--Windwalk Totem
{spellID=118038, time=120, prio=false},--Die By The Sword
{spellID=871, time=180, prio=false},--Shield Wall
{spellID=115203, time=180, prio=false},--Fortifying Brew
{spellID=115176, time=180, prio=false},--Zen Meditation


--Offensive
{spellID=46924, time=60, prio=false},--Bladestorm 
{spellID=85730, time=60, prio=false},--Deadly Calm
{spellID=1719, time=180, prio=false},--Recklessness
{spellID=12292, time=60, prio=false},--Bloodbath
{spellID=107574, time=180, prio=false},--Avatar
{spellID=32379, time=8, prio=false},--Shadow Word: Death
{spellID=51713, time=60, prio=false},--Shadow Dance
{spellID=137619, time=60, prio=false},--Marked for Death
{spellID=121471, time=180, prio=false},--Shadow Blades
{spellID=51271, time=60, prio=false},--Pillar of Frost
{spellID=31884, time=180, prio=false},--Avenging Wrath
{spellID=105809, time=120, prio=false},--Holy Avenger
{spellID=108288, time=360, prio=false},--Heart Of The Wild
{spellID=124974, time=90, prio=false},--Nature's Vigil
{spellID=106952, time=180, prio=false},--Berserk
{spellID=114049, time=180, prio=false},--Ascendance
{spellID=16166, time=90, prio=false},--Elemental Mastery
{spellID=121818, time=300, prio=false},--Stampede
{spellID=19574, time=60, prio=false},--Bestial Wrath

--Other
{spellID=85499, time=45, prio=false},--Speed of Light
{spellID=108285, time=180, prio=false},--Call of the Elements
{spellID=29166, time=180, prio=false},--Innervate
{spellID=14185, time=300, prio=false},--Preparation
{spellID=1856, time=120, prio=false},--Vanish 
{spellID=102280, time=30, prio=false},--Displacer Beast
{spellID=106731, time=180, prio=false},--Incarnation
{spellID=77606, time=30, prio=false},--Dark Simulacrum
{spellID=49039, time=120, prio=false},--Lichborne
{spellID=18499, time=30, prio=false},--Berserker Rage
{spellID=11958, time=180, prio=false},--Cold Snap
{spellID=16190, time=180, prio=false},--Mana Tide Totem
{spellID=8143, time=60, prio=false},--Tremor Totem
{spellID=89485, time=45, prio=false},--Inner Focus
{spellID=8177, time=25, prio=false},--Grounding Totem
{spellID=76577, time=180, prio=false},--Smoke Bomb
{spellID=114018, time=300, prio=false},--Shroud of Concealment
{spellID=109259, time=45, prio=false},--Powershot
{spellID=108978, time=180, prio=false},--Alter Time
}
