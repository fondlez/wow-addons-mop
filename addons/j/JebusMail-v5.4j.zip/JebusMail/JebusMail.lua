--[[ 
    JebusMail

    A mail tracking addon based on MailTo and Postman

    With many thanks to the people who wrote:
        - MailTo
        - Postman
        - Silverdragon
        - Cartographer
        - Cooldowntimers2
        - Auctioneer
    Whose code I looked through for ideas or examples.  There may or may not be snippets of code from these addons in here.
]]

-- *******************************************
-- **	Set-Up Ace3 Libraries & Stuff		**
-- *******************************************
JebusMail = LibStub("AceAddon-3.0"):NewAddon("JebusMail", "AceEvent-3.0", "AceConsole-3.0", "AceHook-3.0", "AceComm-3.0", "AceTimer-3.0");
local L = LibStub("AceLocale-3.0"):GetLocale("JebusMail", true);
--local AceConfig = LibStub("AceConfig-3.0");
local JebusMailFrame;
JebusMail.hasIcon = L["DefaultIcon"];

-- *******************************************
-- **	Declare locals, determine Factions	**
-- *******************************************
local tblGuildNames = {};
local tblFriendNames = {};

local PlayerFaction, locFaction = UnitFactionGroup("player");
local PlayerOppositeFaction = "";
if(PlayerFaction == FACTION_HORDE) then
	PlayerOppositeFaction = FACTION_ALLIANCE;
end
if(PlayerFaction == FACTION_ALLIANCE) then
	PlayerOppositeFaction = FACTION_HORDE;
end

local currentServer = GetRealmName();

-- *******************************************
-- **	Custom Drop-Down Menu stuff			**
-- **	Since there is no DewDrop Library	**
-- **	For Ace3.  							**
-- **	Thank you so much Xinhuan for your	**
-- **	tutorial on UIDropDownMenu! 		**
-- **	You Are Awesome.					** 
-- *******************************************
local JebusMail_DDMenu = CreateFrame("Frame", "JebusMail_DDMenu");
JebusMail_DDMenu.displayMode = "MENU";
local info = {};
JebusMail_DDMenu.UncheckHack = function(dropdownbutton)
	_G[dropdownbutton:GetName().."Check"]:Hide();
end
JebusMail_DDMenu.HideMenu = function()
	if UIDROPDOWNMENU_OPEN_MENU == JebusMail_DDMenu then
		CloseDropDownMenus();
	end
end
JebusMail_DDMenu.initialize = function(self, level) 
	if not level then return end
	wipe(info);
	local seperator = {};
	wipe(seperator);
	seperator.disabled = true;
	seperator.text = "------------";
	seperator.notCheckable = 1;
	
	-- determine a few factors
	local sPlayerName = UnitName("player");
	local sRealmName = GetRealmName();
	local GuildDisabled = true;
	if IsInGuild() then GuildDisabled = nil end
	local FriendsDisabled = true;
	if GetNumFriends() > 0 then FriendsDisabled = nil end
	local AltsDisabled = true;
	if #JebusMail.db.factionrealm.alts > 0 then AltsDisabled = nil end
	local OtherAltsDisabled = true;
	if #JebusMail.db.realm[PlayerOppositeFaction] > 0 then OtherAltsDisabled = nil end
	local LastDisabled = true;
	if #JebusMail.db.factionrealm.last > 0  then LastDisabled = nil end
	local OthersDisabled = true;
	if #JebusMail.db.factionrealm.others > 0 then OthersDisabled = nil end
	local XServerDisabled = true;
	local AltServerList = JebusMail:TableKeys(JebusMail.db.global.realmalts);
	table.sort(AltServerList);
	if #AltServerList > 1 then XServerDisabled = false end -- if it's 1 then the 1 is the current server, so we need more than 1

	-- Compile master list of friends if necessary for exclusion from guild list
	local tblMasterFriends = {};
	if JebusMail.db.profile.exclude == 1 then
		if GetNumFriends() > 0 then
			for i=1,GetNumFriends() do
				local sFriendName = GetFriendInfo(i);
				table.insert(tblMasterFriends, sFriendName);
			end
		end
	end
	
	-- build menu
	if level == 1 then
		info.keepShownOnClick = 1;
		info.disabled = nil;
		info.isTitle = nil;
		info.notCheckable = 1;
		info.func = self.UncheckHack;
		
		-- Guild item
		info.text = L["Guild Members"];
		info.disabled = GuildDisabled;
		info.hasArrow = 1;
		info.value = "guild";
		UIDropDownMenu_AddButton(info, level)
		-- Friends item
		info.text = L["Friends"];
		info.disabled = FriendsDisabled;
		info.hasArrow = 1;
		info.value = "friends";
		UIDropDownMenu_AddButton(info, level)
		-- Alts item
		info.text = L["Alts"];
		info.disabled = AltsDisabled;
		info.hasArrow = 1;
		info.value = "alts";
		UIDropDownMenu_AddButton(info, level)
		-- Others item
		info.text = L["Others"];
		info.disabled = OthersDisabled;
		info.hasArrow = 1;
		info.value = "others";
		UIDropDownMenu_AddButton(info, level)
		-- Last item
		info.text = L["Last"];
		info.disabled = LastDisabled;
		info.hasArrow = 1;
		info.value = "last";
		UIDropDownMenu_AddButton(info, level)
		-- Seperator
		UIDropDownMenu_AddButton(seperator, level)
		-- Remove item
		info.text = L["Remove"];
		info.disabled = nil;
		info.hasArrow = 1;
		info.value = "remove";
		UIDropDownMenu_AddButton(info, level)
		-- Seperator
		UIDropDownMenu_AddButton(seperator, level)
		-- Close item
		info.hasArrow = nil;
		info.value = nil;
		info.notCheckable = 1;
		info.text = L["Close"];
		info.func = self.HideMenu;
		UIDropDownMenu_AddButton(info, level);
	
	elseif level == 2 then
		if UIDROPDOWNMENU_MENU_VALUE == "guild" then
			if GuildDisabled ~= true then
				-- First compile a list of all guildies
				wipe(tblGuildNames);
				local mylastgroup = 0;
				JebusMail:BuildGuildTable();
				local mygrouptable = {};
				for k,v in pairs(tblGuildNames) do
					wipe(info);
					info.text = v;
					info.keepShownOnClick = 1;
					info.disabled = nil;
					info.isTitle = nil;
					info.notCheckable = 1;
					info.func = self.UncheckHack;
					if JebusMail.db.profile.splitguild then
						table.insert(mygrouptable, v);
						if ( #mygrouptable == JebusMail.db.factionrealm.vguildsplit ) or ( k == #tblGuildNames ) then
							info.text = mygrouptable[1] .. " - " .. mygrouptable[#mygrouptable];
							info.hasArrow = 1;
							info.value = "guildsection:"..mygrouptable[1]..":"..mygrouptable[#mygrouptable];
							info.disabled = GuildDisabled;
							UIDropDownMenu_AddButton(info, level);
							mygrouptable = {};
						end
					else
						-- We're not splitting the guild list, just add the member to the sub-menu
						info.keepShownOnClick = nil;
						info.notCheckable = 1;
						info.func = JebusMail.DropDownSelect;
						info.arg1 = v
						UIDropDownMenu_AddButton(info, level);
					end
				end
			end
		elseif UIDROPDOWNMENU_MENU_VALUE == "friends" then
			if FriendsDisabled ~= true then
				tblFriendNames = {};
				for i=1,GetNumFriends() do
					local sFriendName = GetFriendInfo(i);
					if not JebusMail:TableFind(tblGuildNames, sFriendName, 1) then
						table.insert(tblFriendNames, sFriendName);
					end
				end
				table.sort(tblFriendNames);
				local mylastgroup = 0;
				local mygrouptable = {};
				for k,v in pairs(tblFriendNames) do
					wipe(info);
					info.text = v;
					info.keepShownOnClick = 1;
					info.disabled = nil;
					info.isTitle = nil;
					info.notCheckable = 1;
					info.func = self.UncheckHack;
					if JebusMail.db.profile.splitfriends then
						table.insert(mygrouptable, v);
						if ( #mygrouptable == JebusMail.db.factionrealm.vfriendssplit ) or ( k == #tblFriendNames ) then
							info.text = mygrouptable[1] .. " - " .. mygrouptable[#mygrouptable];
							info.hasArrow = 1;
							info.value = "friendsection:"..mygrouptable[1]..":"..mygrouptable[#mygrouptable];
							info.disabled = FriendsDisabled;
							UIDropDownMenu_AddButton(info, level);
							mygrouptable = {};
						end
					else
						-- We're not splitting the friends list, just add the friend to the sub-menu
						info.keepShownOnClick = nil;
						info.notCheckable = 1;
						info.func = JebusMail.DropDownSelect;
						info.arg1 = v
						UIDropDownMenu_AddButton(info, level);
					end
				end
			end
		elseif UIDROPDOWNMENU_MENU_VALUE == "alts" then
			if AltsDisabled ~= true then
				for k,v in pairs(JebusMail.db.factionrealm.alts) do
					wipe(info);
					if v ~= sPlayerName then
						info.text = v;
						--info.keepShownOnClick = 1;
						info.disabled = nil;
						info.isTitle = nil;
						info.notCheckable = 1;
						info.func = JebusMail.DropDownSelect;
						info.arg1 = v
						UIDropDownMenu_AddButton(info, level);
					end
				end
				-- Create sub-menu to opposite faction alts
				wipe(info);
				info.keepShownOnClick = 1;
				info.isTitle = nil;
				info.notCheckable = 1;
				info.text = PlayerOppositeFaction;
				info.disabled = OtherAltsDisabled;
				info.hasArrow = 1;
				info.value = "otheralts";
				UIDropDownMenu_AddButton(info, level)
				-- Create sub-menu for cross server mail capabilities
				info.text = L["Cross Server"];
				info.disabled = nil;
				info.hasArrow = 1;
				info.value = "xserver";
				UIDropDownMenu_AddButton(info, level)
			end
		elseif UIDROPDOWNMENU_MENU_VALUE == "others" then
			if OthersDisabled ~= true then
				for k,v in pairs(JebusMail.db.factionrealm.others) do
					wipe(info);
					info.text = v;
					info.disabled = nil;
					info.isTitle = nil;
					info.notCheckable = 1;
					info.func = JebusMail.DropDownSelect;
					info.arg1 = v
					UIDropDownMenu_AddButton(info, level);
				end
			end
		elseif UIDROPDOWNMENU_MENU_VALUE == "last" then
			if LastDisabled ~= true then
				for k,v in pairs(JebusMail.db.factionrealm.last) do
					wipe(info);
					info.text = v;
					info.disabled = nil;
					info.isTitle = nil;
					info.notCheckable = 1;
					info.func = JebusMail.DropDownSelect;
					info.arg1 = v
					UIDropDownMenu_AddButton(info, level);
				end
			end
		elseif UIDROPDOWNMENU_MENU_VALUE == "remove" then
			-- Remove Alts
			info.text = L["Alts"];
			info.disabled = nil;
			info.notCheckable = 1;
			info.hasArrow = 1;
			info.value = "remove:alts";
			UIDropDownMenu_AddButton(info, level);
			-- Remove Others
			info.text = L["Others"];
			info.disabled = OthersDisabled;
			info.hasArrow = 1;
			info.value = "remove:others";
			UIDropDownMenu_AddButton(info, level);
		end
	
	elseif level == 3 then
		local arg1, arg2, arg3 = strsplit(":", UIDROPDOWNMENU_MENU_VALUE);
		if arg1 == "guildsection" then
			local bDisplayGuildMember = false;
			tblGuildNames = {};
			GuildRoster();
			for i=1,GetNumGuildMembers(true) do
				local sMemberName = GetGuildRosterInfo(i);
				sMemberName = strsub(sMemberName, 1, strfind(sMemberName, "-") - 1);
				if sMemberName ~= sPlayerName and not JebusMail:TableFind(JebusMail.db.factionrealm.alts, sMemberName, 2) and not JebusMail:TableFind(tblMasterFriends, sMemberName, 2) then
					table.insert(tblGuildNames, sMemberName);
				end
			end
			table.sort(tblGuildNames);	-- sort that list alphabetically
			for k,v in pairs(tblGuildNames) do
				if v == arg2 then bDisplayGuildMember = true end
				if bDisplayGuildMember == true and (v ~= sPlayerName) and not JebusMail:TableFind(JebusMail.db.factionrealm.alts, v, 2) and not JebusMail:TableFind(tblMasterFriends, v, 2) then
					wipe(info);
					info.text = v;
					info.disabled = nil;
					info.isTitle = nil;
					info.notCheckable = 1;
					info.func = JebusMail.DropDownSelect;
					info.arg1 = v;
					UIDropDownMenu_AddButton(info, level);
				end
				if v == arg3 then bDisplayGuildMember = false end
			end
		elseif arg1 == "friendsection" then
			local bDisplayFriend = false;
			local tblFriendNames = {};
			for i=1,GetNumFriends() do
				local sFriendName = GetFriendInfo(i);
				if not JebusMail:TableFind(tblGuildNames, sFriendName, 1) then
					table.insert(tblFriendNames, sFriendName);
				end
			end
			table.sort(tblFriendNames);
			for k,v in pairs(tblFriendNames) do
				if v == arg2 then bDisplayFriend = true end
				if bDisplayFriend == true and (v ~= sPlayerName) and not JebusMail:TableFind(JebusMail.db.factionrealm.alts, v, 2) and not JebusMail:TableFind(tblMasterFriends, v, 2) then
					wipe(info);
					info.text = v;
					info.notCheckable = 1;
					info.func = JebusMail.DropDownSelect;
					info.arg1 = v;
					UIDropDownMenu_AddButton(info, level);
				end
				if v == arg3 then bDisplayFriend = false end
			end
		elseif arg1 == "otheralts" then
			for k,v in pairs(JebusMail.db.realm[PlayerOppositeFaction]) do
				wipe(info);
				info.text = v;
				info.disabled = nil;
				info.isTitle = nil;
				info.notCheckable = 1;
				info.func = JebusMail.DropDownSelect;
				info.arg1 = v
				UIDropDownMenu_AddButton(info, level);
			end
		elseif arg1 == "xserver" then
			for k,v in pairs(AltServerList) do
				if not (v == sRealmName) then
					wipe(info);
					info.keepShownOnClick = 1;
					info.hasArrow = 1;
					info.text = v;
					info.disabled = nil;
					info.isTitle = nil;
					info.notCheckable = 1;
					info.value = "xserver:" .. v;
					UIDropDownMenu_AddButton(info, level);
				end
			end
		elseif arg1 == "remove" then
			local tmpTable = {};
			local remove_self = false;
			if arg2 == "alts" then
				tmpTable = JebusMail.db.factionrealm.alts;
				remove_self = true;
			elseif arg2 == "others" then
				tmpTable = JebusMail.db.factionrealm.others;
			end
			for k,v in pairs(tmpTable) do
				if (v ~= sPlayerName and remove_self == true) or (remove_self == false) then
					wipe(info);
					info.text = v;
					info.notCheckable = 1;
					info.func = JebusMail.DropDownRemove;
					info.arg1 = arg2;
					info.arg2 = k;
					info.arg3 = v;
					UIDropDownMenu_AddButton(info, level);
				end
			end
			if arg2 == "alts" then
				-- Create sub-menu to opposite faction alts, so we can remove those if necessary
				wipe(info);
				info.notCheckable = 1;
				info.text = PlayerOppositeFaction;
				info.disabled = OtherAltsDisabled;
				info.hasArrow = 1;
				info.value = "remove:alts:otheralts";
				UIDropDownMenu_AddButton(info, level)
			end
		end
	elseif level == 4 then
		local arg1, arg2, arg3 = strsplit(":", UIDROPDOWNMENU_MENU_VALUE);
		if arg1 == "xserver" then
			-- arg2 will contain server name
			-- Alliance/Horde sub menu(s) for the given server(arg2)
			local FactionList = JebusMail:TableKeys(JebusMail.db.global.realmalts[arg2]);
			table.sort(FactionList);
			for k,v in pairs(FactionList) do
				wipe(info);
				info.keepShownOnClick = 1;
				info.hasArrow = 1;
				info.text = v;
				info.disabled = nil;
				info.isTitle = nil;
				info.notCheckable = 1;
				info.value = "xserver:" .. arg2 .. ":" .. v;
				UIDropDownMenu_AddButton(info, level);
			end
		elseif arg1 == "remove" then
			if arg2 == "alts" then
				if arg3 == "otheralts" then
					for k,v in pairs(JebusMail.db.realm[PlayerOppositeFaction]) do
						wipe(info);
						info.text = v;
						info.notCheckable = 1;
						info.func = JebusMail.DropDownRemove;
						info.arg1 = "OppositeFaction";
						info.arg2 = k;
						info.arg3 = v;
						UIDropDownMenu_AddButton(info, level);
					end
				end
			end
		end
	elseif level == 5 then
		local arg1, arg2, arg3 = strsplit(":", UIDROPDOWNMENU_MENU_VALUE);
		if arg1 == "xserver" then
			-- arg2 will contain server name
			-- arg3 will contain selected faction (Alliance/Horde)
			-- Alt sub menu for given realm/faction
			for k,v in pairs(JebusMail.db.global.realmalts[arg2][arg3]) do
				wipe(info);
				info.text = v;
				info.disabled = nil;
				info.isTitle = nil;
				info.notCheckable = 1;
				info.func = JebusMail.DropDownSelect;
				info.arg1 = v .. "-" .. arg2;
				UIDropDownMenu_AddButton(info, level);
			end
		end
	end
end

-- *******************************************
-- **	OnInitialize						**
-- *******************************************
function JebusMail:OnInitialize()
	-- Set-Up DB and Defaults
	local defaults = {
		global = {
			realmalts = {},
		},
		profile = {
		    announce = {
				chat = true,
				sound = true,
			},
			splitguild = false,
			exclude = 0,
			splitfriends = false,
			p2pcomm = true,
		},
		realm = {			-- WAS server in Ace2
			Horde = {},
			Alliance = {}
		},
		factionrealm = {	-- WAS realm in Ace2
			alts = {},
			last = {},
			others = {},
			mailLog = {},
			maxLast = 15,
			vguildsplit = 15,
			vfriendssplit = 5,
		}
	}
	self.db = LibStub("AceDB-3.0"):New("JebusMailDB", defaults);
	
	-- Setup Options Table
    local tblOptions = {
        handler = self,
        type = "group",
		name = "JebusMail";
		desc = L["These options affect the behaviour of the JebusMail addon."];
        args = {
            DeliveryMsg = {
                name = L["Delivery Notification Message"],
                desc = L["Display a message when mail has arrived."],
                type = "toggle",
                get = "GetDeliveryMsg",
                set = "SetDeliveryMsg",
            },
            DeliverySound = {
                name = L["Delivery Notification Sound"],
                desc = L["Play sound when mail has arrived."],
                type = "toggle",
                get = "GetDeliverySound",
                set = "SetDeliverySound",
            },
            maxLast = {
                type = 'range',
				min = 0,
				max = 30,
				step = 1,
                name = 'MaxLast',
                desc = L["How many recipients do you want to remember?"],
--                usage = "<Your Value>",
                get = function() return self.db.factionrealm.maxLast end,
                set = function(tbl, new_value)
					self.db.factionrealm.maxLast = new_value
					JebusMail:SetmaxLast(new_value)
					self.panel.maxLast:SetValue(self.db.factionrealm.maxLast)
                end,
            },
            SplitGuild = {
                name = L["Split guild list"],
                desc = L["Split the guild list into groups.  Good for large guilds."],
                type = "toggle",
                get = "GetSplitGuild",
                set = "SetSplitGuild",
            },
            VGuildSplit = {
                name = L["Variable Guild List Split"],
                desc = L["How many guild members should be in one subfolder?"],
--                usage = "<Your Value>",
                type = "range",
				min = 5,
				max = 50,
				step = 1,
                get = function() return self.db.factionrealm.vguildsplit end,
                set = function(tbl, new_value)
						JebusMail:Setvguildsplit(new_value)
						self.panel.vguildsplit:SetValue(self.db.factionrealm.vguildsplit)
					end,
            },
			SplitFriends = {
                name = L["Split friends list"],
                desc = L["Split the friends list into groups."],
                type = "toggle",
                get = "GetSplitFriends",
                set = "SetSplitFriends",
			},
            VFriendsSplit = {
                name = L["Variable Friends List Split"],
                desc = L["How many friends should be in one subfolder?"],
                type = "range",
				min = 5,
				max = 50,
				step = 1,
                get = function() return self.db.factionrealm.vfriendssplit end,
                set = function(tbl, new_value)
						JebusMail:Setvfriendssplit(new_value)
						self.panel.vfriendssplit:SetValue(self.db.factionrealm.vfriendssplit)
					end,
            },
            Log = {
                name = L["Mail Log"],
                desc = L["Display the Mail Log"],
                type = "execute",
                func = function() self:DisplayInTransit(true) end,
            },
			P2PComm = {
				name = L["Peer to Peer Communication"],
				desc = L["If checked, will attempt to send mail notifications to sendee to sync their JebusMail notifications."],
				type = "toggle",
				get = "GetP2PComm",
				set = "SetP2PComm",
			},
			Config = {
				name = L["Config"],
				desc = L["Opens the Conifg GUI"],
				type = "execute",
				func = function() self:ShowConfig() end,
			},
        },
    }
	self.OnMenuRequest = tblOptions;
	LibStub("AceConfig-3.0"):RegisterOptionsTable("JebusMail", tblOptions, {"JebusMail", "jm"});
	
	--self:Print("PlayerFaction: " .. PlayerFaction);
	-- Only do this if the player has a faction. (Pandas don't start out with one)
	if not (PlayerFaction == FACTION_NEUTRAL) then
		local sPlayerName = UnitName("player");
		local sRealmName = GetRealmName();
		
		-- if this character's faction list is empty, copy the alt list into it.
		if(self.db.realm[PlayerFaction] ~= nil) then
			if table.getn(self.db.realm[PlayerFaction]) == 0 then
				self.db.realm[PlayerFaction] = self.db.factionrealm.alts;
			end
		end
		
		-- If this character hasn't been added to the alt list, add it now
		if not JebusMail:TableFind(self.db.factionrealm.alts, sPlayerName, -1) then
			table.insert(self.db.factionrealm.alts, sPlayerName);
			table.sort(self.db.factionrealm.alts);
			-- add to the Horde/Alliance list as well
			table.insert(self.db.realm[PlayerFaction], sPlayerName);
			table.sort(self.db.realm[PlayerFaction]);
		end
		
		-- If this realm(server) hasn't been added to the global.realmalts list, then add it now
		if not JebusMail:TableFind(self.db.global.realmalts, sRealmName, -1) then
			self.db.global.realmalts[sRealmName] = {};
			table.sort(self.db.global.realmalts);
		end
		
		if self.db.global.realmalts[sRealmName][PlayerFaction] == nil then
			-- The global realm alts list is freshly created, try copying the alts lists over
			if #self.db.realm[PlayerFaction] > 0 then
				self.db.global.realmalts[sRealmName][PlayerFaction] = {};
				for k,v in pairs(self.db.factionrealm.alts) do
					table.insert(self.db.global.realmalts[sRealmName][PlayerFaction], v);
				end
				table.sort(self.db.global.realmalts[sRealmName]);
				table.sort(self.db.global.realmalts[sRealmName][PlayerFaction]);
			end
		end
		
		if self.db.global.realmalts[sRealmName][PlayerOppositeFaction] == nil then
			-- The global realm alts list for the opposing faction is empty, try filling it with the opposing faction alts list
			if #self.db.realm[PlayerOppositeFaction] > 0 then
				self.db.global.realmalts[sRealmName][PlayerOppositeFaction] = {};
				for k,v in pairs(self.db.realm[PlayerOppositeFaction]) do
					table.insert(self.db.global.realmalts[sRealmName][PlayerOppositeFaction], v);
				end
				table.sort(self.db.global.realmalts[sRealmName]);
				table.sort(self.db.global.realmalts[sRealmName][PlayerOppositeFaction]);
			end
		end
		
		-- If this character hasn't been added to the realmalts list then add it now
		if not JebusMail:TableFind(self.db.global.realmalts[sRealmName][PlayerFaction], sPlayerName, -1) then
			table.insert(self.db.global.realmalts[sRealmName][PlayerFaction], sPlayerName);
			table.sort(self.db.global.realmalts[sRealmName][PlayerFaction]);
		end
	end

    self.reccash = {
        total  = 0,
        sales = 0,
        refun = 0,
        other = 0
    }
end

-- create a basic slider, code is a modified code from Tuller's addon 'OmniCC'
local function Slider_OnMouseWheel(self, arg1)
	local step = self:GetValueStep() * arg1
	local value = self:GetValue()
	local minVal, maxVal = self:GetMinMaxValues()

	if step > 0 then
		self:SetValue(min(value+step, maxVal))
	else
		self:SetValue(max(value+step, minVal))
	end
end

function JebusMail:CreateSlider(name, parent, low, high, step)
	local slider = CreateFrame('Slider', name, parent, 'OptionsSliderTemplate')
	slider:SetScript('OnMouseWheel', Slider_OnMouseWheel)
	slider:SetMinMaxValues(low, high)
	slider:SetValueStep(step)
	slider:EnableMouseWheel(true)
	BlizzardOptionsPanel_Slider_Enable(slider) --colors the slider properly

	--getglobal(name .. 'Text'):SetText(text)
	getglobal(name .. 'Low'):SetText('')
	getglobal(name .. 'High'):SetText('')

	local text = slider:CreateFontString(nil, 'BACKGROUND')
	text:SetFontObject('GameFontHighlightSmall')
	text:SetPoint('LEFT', slider, 'RIGHT', 7, 0)
	slider.valText = text

	return slider
end

function JebusMail:OnEnable()
    if not self.frmDropDown then
		-- This can probably be done through Ace3, but it's not broken, so I'm not fixing it.
        -- create frames
        self.frmDropDown = CreateFrame("Frame", "FrameDropDown", SendMailFrame)
        self.frmDropDown:SetWidth(24)
        self.frmDropDown:SetHeight(24)
        self.frmDropDown:SetPoint("LEFT",SendMailNameEditBox,"RIGHT",-6,0)

        self.btnDropDown = CreateFrame("Button", "ButtonDropDown", FrameDropDown)
        self.btnDropDown:SetWidth(24)
        self.btnDropDown:SetHeight(24)
        self.btnDropDown:SetPoint("LEFT", FrameDropDown)
        local textureNormal = self.btnDropDown:CreateTexture("DropDownNormal", "ARTWORK")
        textureNormal:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
        textureNormal:SetPoint("RIGHT", ButtonDropDown)
        textureNormal:SetWidth(24)
        textureNormal:SetHeight(24)
        local textureHighlight = self.btnDropDown:CreateTexture("DropDownHighlight", "ARTWORK")
        textureHighlight:SetTexture("Interface\\Buttons\\UI-Common-MouseHilight")
        textureHighlight:SetPoint("RIGHT", ButtonDropDown)
        textureHighlight:SetWidth(24)
        textureHighlight:SetHeight(24)
        local texturePushed = self.btnDropDown:CreateTexture("DropDownPushed", "ARTWORK")
        texturePushed:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Down")
        texturePushed:SetPoint("RIGHT", ButtonDropDown)
        texturePushed:SetWidth(24)
        texturePushed:SetHeight(24)
        self.btnDropDown:SetNormalTexture(textureNormal)
        self.btnDropDown:SetHighlightTexture(textureHighlight)
        self.btnDropDown:SetPushedTexture(texturePushed)

        self.btnDropDown:SetScript("OnEnter", 
			function()
				self:btnDropDown_OnEnter()
			end
		)
        self.btnDropDown:SetScript("OnLeave",
			function()
				self:btnDropDown_OnLeave()
			end
		)
        self.btnDropDown:SetScript("OnClick", 
			function()
				self:btnDropDown_OnClick()
			end
		)

        -- Create UI Options frame (WoW 2.4)
        self.panel = CreateFrame("FRAME", "OptionPanel")
        self.panel.name = "JebusMail"
        -- Title Text
        local title = self.panel:CreateFontString("JebusMailTitle", "ARTWORK", "GameFontNormalLarge")
        title:SetJustifyH("LEFT")
        title:SetJustifyV("TOP")
        title:SetPoint("TOPLEFT", 16, -16)
        title:SetText(self.panel.name)
        -- Title Sub-Text
        local subText = self.panel:CreateFontString("JebusMailSubText", "ARTWORK", "GameFontHighlightSmall")
        subText:SetJustifyH("LEFT")
        subText:SetJustifyV("TOP")
        subText:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
        subText:SetPoint("RIGHT", -32, 0)
        subText:SetNonSpaceWrap(true)
        subText:SetHeight(32)
        subText:SetWidth(0)
        subText:SetText(L["These options affect the behaviour of the JebusMail addon."])
        -- Delivery Notification checkbox
        self.panel.chkDeliveryMsg = CreateFrame("CheckButton", "chkDeliveryMsg", self.panel, "InterfaceOptionsCheckButtonTemplate")
        self.panel.chkDeliveryMsg:SetPoint("TOPLEFT", subText, "BOTTOMLEFT", 0, -8)
        getglobal(self.panel.chkDeliveryMsg:GetName().."Text"):SetText(L["Delivery Notification Message"])
        self.panel.chkDeliveryMsg.tooltipText = L["Display a message when mail has arrived."]
        self.panel.chkDeliveryMsg:SetChecked(self.db.profile.announce.chat)
        self.panel.chkDeliveryMsg.savedVar = "self.db.profile.announce.chat"
        self.panel.chkDeliveryMsg.setFunc = function(value) self:SetDeliveryMsg(value) end
        BlizzardOptionsPanel_RegisterControl(self.panel.chkDeliveryMsg, self.panel)
        -- Delivery Notification sound checkbox
        self.panel.chkDeliverySnd = CreateFrame("CheckButton", "chkDeliverySnd", self.panel, "InterfaceOptionsCheckButtonTemplate")
        self.panel.chkDeliverySnd:SetPoint("TOPLEFT", self.panel.chkDeliveryMsg, "BOTTOMLEFT", 0, -8)
        getglobal(self.panel.chkDeliverySnd:GetName().."Text"):SetText(L["Delivery Notification Sound"])
        self.panel.chkDeliverySnd.tooltipText = L["Play sound when mail has arrived."]
        self.panel.chkDeliverySnd:SetChecked(self.db.profile.announce.sound)
        self.panel.chkDeliverySnd.savedVar = "self.db.profile.announce.sound"
        self.panel.chkDeliverySnd.setFunc = function(value) self:SetDeliverySound(value) end
        BlizzardOptionsPanel_RegisterControl(self.panel.chkDeliverySnd, self.panel)
        -- Split Guild Checkbox
        self.panel.chkSplitGuild = CreateFrame("CheckButton", "chkSplitGuild", self.panel, "InterfaceOptionsCheckButtonTemplate")
        self.panel.chkSplitGuild:SetPoint("TOPLEFT", self.panel.chkDeliverySnd, "BOTTOMLEFT", 0, -8)
        getglobal(self.panel.chkSplitGuild:GetName().."Text"):SetText(L["Split guild list"])
        self.panel.chkSplitGuild.tooltipText = L["Split the guild list into groups.  Good for large guilds."]
        self.panel.chkSplitGuild:SetChecked(self.db.profile.splitguild)
        self.panel.chkSplitGuild.savedVar = "self.db.profile.splitguild"
        self.panel.chkSplitGuild.setFunc = function(value) self:SetSplitGuild(value) end
        BlizzardOptionsPanel_RegisterControl(self.panel.chkSplitGuild, self.panel)
        -- variable guild split
        self.panel.vguildsplit = JebusMail:CreateSlider("vguildsplitSlider", self.panel, 5, 50, 1)
        self.panel.vguildsplit:SetPoint("TOPLEFT", self.panel.chkSplitGuild, "BOTTOMLEFT", 0, -15)
        getglobal("vguildsplitSlider".."Text"):SetText(L["Variable Guild List Split"])
        self.panel.vguildsplit:SetValue(self.db.factionrealm.vguildsplit)
        self.panel.vguildsplit.savedVar = "self.db.factionrealm.vguildsplit"
        self.panel.vguildsplit:SetScript("OnValueChanged", function(self) JebusMail:Setvguildsplit(self:GetValue()); end)
        self.panel.vguildsplit.tooltipText = L["How many guild members should be in one subfolder?"] .. " (" .. self.db.factionrealm.vguildsplit ..")"
        BlizzardOptionsPanel_RegisterControl(self.panel.vguildsplit, self.panel)
        -- Split Friends Checkbox
        self.panel.chkSplitFriends = CreateFrame("CheckButton", "chkSplitFriends", self.panel, "InterfaceOptionsCheckButtonTemplate")
        self.panel.chkSplitFriends:SetPoint("TOPLEFT", self.panel.vguildsplit, "BOTTOMLEFT", 0, -8)
        getglobal(self.panel.chkSplitFriends:GetName().."Text"):SetText(L["Split friends list"])
        self.panel.chkSplitFriends.tooltipText = L["Split the friends list into groups."]
        self.panel.chkSplitFriends:SetChecked(self.db.profile.splitfriends)
        self.panel.chkSplitFriends.savedVar = "self.db.profile.splitfriends"
        self.panel.chkSplitFriends.setFunc = function(value) self:SetSplitFriends(value) end
        BlizzardOptionsPanel_RegisterControl(self.panel.chkSplitFriends, self.panel)
        -- variable Friends split
        self.panel.vfriendssplit = JebusMail:CreateSlider("vfriendssplitSlider", self.panel, 5, 50, 1)
        self.panel.vfriendssplit:SetPoint("TOPLEFT", self.panel.chkSplitFriends, "BOTTOMLEFT", 0, -15)
        getglobal("vfriendssplitSlider".."Text"):SetText(L["Variable Friends List Split"])
        self.panel.vfriendssplit:SetValue(self.db.factionrealm.vfriendssplit)
        self.panel.vfriendssplit.savedVar = "self.db.factionrealm.vfriendssplit"
        self.panel.vfriendssplit:SetScript("OnValueChanged", function(self) JebusMail:Setvfriendssplit(self:GetValue()); end)
        self.panel.vfriendssplit.tooltipText = L["How many friends should be in one subfolder?"] .. " (" .. self.db.factionrealm.vfriendssplit ..")"
        BlizzardOptionsPanel_RegisterControl(self.panel.vfriendssplit, self.panel)
		-- maxLast
        self.panel.maxLast = JebusMail:CreateSlider("maxLastSlider", self.panel, 0, 30, 1)
        self.panel.maxLast:SetPoint("TOPLEFT", self.panel.vfriendssplit, "BOTTOMLEFT", 0, -15)
        getglobal("maxLastSlider".."Text"):SetText(L["Remember last recipients"])
        self.panel.maxLast:SetValue(self.db.factionrealm.maxLast)
        self.panel.maxLast.savedVar = "self.db.factionrealm.maxLast"
        self.panel.maxLast:SetScript("OnValueChanged", function(self) JebusMail:SetmaxLast(self:GetValue()); end)
        self.panel.maxLast.tooltipText = L["How many recipients do you want to remember?"] .. " (" .. self.db.factionrealm.maxLast ..")"
        BlizzardOptionsPanel_RegisterControl(self.panel.maxLast, self.panel)
		-- Exclusion options
		local txtExclude = self.panel:CreateFontString("JM_Exclude", "ARTWORK", "GameFontHighlightMedium")
        txtExclude:SetJustifyH("LEFT")
        txtExclude:SetJustifyV("TOP")
        txtExclude:SetPoint("TOPLEFT", self.panel.maxLast, "BOTTOMLEFT", 0, -8)
        txtExclude:SetNonSpaceWrap(true)
        txtExclude:SetHeight(16)
        txtExclude:SetWidth(0)
        txtExclude:SetText(L["Exclude:"])
		-- Exclude: None checkbox
        self.panel.chkExclude0 = CreateFrame("CheckButton", "chkExclude0", self.panel, "UIRadioButtonTemplate")
        self.panel.chkExclude0:SetPoint("TOPLEFT", txtExclude, "TOPRIGHT", 0, 4)
        getglobal(self.panel.chkExclude0:GetName().."Text"):SetText(L["Nothing"])
        self.panel.chkExclude0.tooltipText = L["Do not remove anyone from any list."]
        self.panel.chkExclude0:SetChecked(self.db.profile.exclude == 0)
        self.panel.chkExclude0.savedVar = "self.db.profile.exclude"
        self.panel.chkExclude0:SetScript("OnClick", function(value) self:SetExclude(0, value) end)
        BlizzardOptionsPanel_RegisterControl(self.panel.chkExclude0, self.panel)
		-- Exclude: Friends from Guild checkbox
        self.panel.chkExclude1 = CreateFrame("CheckButton", "chkExclude1", self.panel, "UIRadioButtonTemplate")
        self.panel.chkExclude1:SetPoint("TOPLEFT", self.panel.chkExclude0, "BOTTOMLEFT", 0, 0)
        getglobal(self.panel.chkExclude1:GetName().."Text"):SetText(L["Friends from Guild list"])
        self.panel.chkExclude1.tooltipText = L["Removes friends from the guild members list."]
        self.panel.chkExclude1:SetChecked(self.db.profile.exclude == 1)
        self.panel.chkExclude1.savedVar = "self.db.profile.exclude"
        self.panel.chkExclude1:SetScript("OnClick", function(value) self:SetExclude(1, value) end)
        BlizzardOptionsPanel_RegisterControl(self.panel.chkExclude1, self.panel)
		-- Exclude: Guild from Friends checkbox
        self.panel.chkExclude2 = CreateFrame("CheckButton", "chkExclude2", self.panel, "UIRadioButtonTemplate")
        self.panel.chkExclude2:SetPoint("TOPLEFT", self.panel.chkExclude1, "BOTTOMLEFT", 0, 0)
        getglobal(self.panel.chkExclude2:GetName().."Text"):SetText(L["Guild members from Friends list"])
        self.panel.chkExclude2.tooltipText = L["Removes guild members from the friends list."]
        self.panel.chkExclude2:SetChecked(self.db.profile.exclude == 2)
        self.panel.chkExclude2.savedVar = "self.db.profile.exclude"
        self.panel.chkExclude2:SetScript("OnClick", function(value) self:SetExclude(2, value) end)
        BlizzardOptionsPanel_RegisterControl(self.panel.chkExclude2, self.panel)
        -- P2P Communication checkbox
        self.panel.chkP2PComm = CreateFrame("CheckButton", "chkP2PComm", self.panel, "InterfaceOptionsCheckButtonTemplate")
        self.panel.chkP2PComm:SetPoint("TOPLEFT", txtExclude, "BOTTOMLEFT", 0, -32)
        getglobal(self.panel.chkP2PComm:GetName().."Text"):SetText(L["Peer to Peer Communication"])
        self.panel.chkP2PComm.tooltipText = L["If checked, will attempt to send mail notifications to sendee to sync their JebusMail notifications."]
        self.panel.chkP2PComm:SetChecked(self.db.profile.p2pcomm)
        self.panel.chkP2PComm.savedVar = "self.db.profile.p2pcomm"
        self.panel.chkP2PComm.setFunc = function(value) self:SetP2PComm(value) end
        BlizzardOptionsPanel_RegisterControl(self.panel.chkP2PComm, self.panel)
        -- Mail Log Button
		self.panel.btnMailLog = CreateFrame("Button", "btnMailLog", self.panel, "OptionsButtonTemplate")
		self.panel.btnMailLog:SetPoint("TOPLEFT", self.panel.chkP2PComm, "BOTTOMLEFT", 0, 0)
		self.panel.btnMailLog:SetText(L["Mail Log"])
		self.panel.btnMailLog.tooltipText = L["Display the Mail Log"]
		self.panel.btnMailLog:SetScript("OnClick", function() self:DisplayInTransit(true) end)
		BlizzardOptionsPanel_RegisterControl(self.panel.btnMailLog, self.panel)
		InterfaceOptions_AddCategory(self.panel)
	else
		self.frmDropDown:Show()
	end

    -- Comm Interface
	self:RegisterComm("JebusMail", "ReceiveMessage")
    
    -- register events
    self:RegisterEvent("MAIL_CLOSED", "OnMailClosed")
    self:RegisterEvent("CHAT_MSG_SYSTEM", "OnSystemMsg")

    -- register hooks
	self:Hook("SendMailFrame_SendMail", "SendMail", true);
	self:RawHook("InboxFrame_OnClick", "TakeItem", true);
	self:HookScript(SendMailNameEditBox, "OnEditFocusGained", "FillToBox");

    -- schedule event to process messages
	self:ScheduleTimer("ProcessMailLog", 5, self)
	self:ScheduleTimer("DisplayInTransit", 5, self)
end

function JebusMail:OnDisable()
    self:UnregisterAllEvents()
    self:UnHookAll()
    self.frmDropDown:Hide()
end

function JebusMail:OnMailClosed()
	JebusMail_DDMenu:HideMenu();
    if self.reccash.total > 0 then
        local sTotal = self:getTextGSC(self.reccash.total)
        local sSales = self:getTextGSC(self.reccash.sales)
        local sRefun = self:getTextGSC(self.reccash.refun)
        local sOther = self:getTextGSC(self.reccash.other)
        self:Print(string.format(L["Received cash: Total=%s, Sales=%s, Refunds=%s, Other=%s"], sTotal, sSales, sRefun, sOther))
        self.reccash = {
            total  = 0,
            sales = 0,
            refun = 0,
            other = 0
        }
    end
end

function JebusMail:OnSystemMsg(msg)
    -- keep our eyes out for auctions that have been bought out and log for their arrival
    if string.find(msg, L["A buyer has been found for your auction of "]) then
        local sItemName = string.gsub(msg, L["A buyer has been found for your auction of "], "")    -- remove the beginning part of the message
        sItemName =string.format(L["%s sales revenue"], string.sub(sItemName, 1, -2))   -- chopping off the trailing "."
		-- JebusMail.Print("Auction sale detected..."..sItemName);
        local iWaitTime = 60 * 60
        table.insert(self.db.factionrealm.mailLog, {
            to = UnitName("player"),
            from = L["Auction House"],
            attachment = sItemName,
            t = time() + iWaitTime
        })
        if not self.NextLogCheck or self.NextLogCheck > iWaitTime then
--            self.NextLogCheck = self:ScheduleEvent(self.ProcessMailLog, iWaitTime, self)
			self.NextLogCheck = self:ScheduleTimer("ProcessMailLog", iWaitTime, self)
        end
    end
end

function JebusMail:btnDropDown_OnEnter()
	GameTooltip:SetOwner(self.btnDropDown, "ANCHOR_TOPLEFT")
	GameTooltip:SetText(L["Select a recipient"])
end

function JebusMail:btnDropDown_OnLeave()
	GameTooltip:Hide()
end

function JebusMail:btnDropDown_OnClick()
	ToggleDropDownMenu(1, nil, JebusMail_DDMenu, "ButtonDropDown", 20, 25)
end

function JebusMail:DropDownSelect(name)
    SendMailNameEditBox:SetText(name)
    SendMailSubjectEditBox:SetFocus()
	JebusMail_DDMenu:HideMenu();
end

function JebusMail:DropDownRemove(section, index)
    local name;
	local sRealmName = GetRealmName();
    if section == "alts" then
		name = JebusMail.db.factionrealm.alts[index];
		table.remove(JebusMail.db.factionrealm.alts, index);
		table.remove(JebusMail.db.realm[PlayerFaction], index);	-- Remove from realm list as well
		if JebusMail:TableFind(JebusMail.db.global.realmalts[sRealmName][PlayerFaction], name, -1) > 0 then
			table.remove(JebusMail.db.global.realmalts[sRealmName][PlayerFaction], index);	-- remove from global alt list
		end
		JebusMail:Print(string.format(L["%s removed from alt list."], name));
	elseif section == "others" then
		name = JebusMail.db.factionrealm.others[index];
		table.remove(JebusMail.db.factionrealm.others, index);
		JebusMail:Print(string.format(L["%s removed from others list."], name));
	elseif section == "OppositeFaction" then
		name = JebusMail.db.realm[PlayerOppositeFaction][index];
		table.remove(JebusMail.db.realm[PlayerOppositeFaction], index);
		if JebusMail:TableFind(JebusMail.db.global.realmalts[sRealmName][PlayerOppositeFaction], name, -1) > 0 then
			table.remove(JebusMail.db.global.realmalts[sRealmName][PlayerOppositeFaction], index);	-- remove from global alt list
		end
		JebusMail:Print(string.format(L["%s removed from other faction list."], name))
	end
	JebusMail_DDMenu:HideMenu();
end

function JebusMail:DropDownClose()
	JebusMail_DDMenu:HideMenu();
end

function JebusMail:TableFind(t,s,e)
	local ret = nil
	if (e ~= self.db.profile.exclude and self.db.profile.exclude ~= 0) or e < 0 then
		if t then
			for k,v in pairs(t) do
				if v==s then ret = k end
			end
		end
	end
    return ret
end

function JebusMail:TableKeys(t)
	local keyset={};
	local n=0;

	for k,v in pairs(t) do
	  n = n + 1;
	  keyset[n] = k;
	end
	return keyset;
end

function JebusMail:SendMail()
    local sTo = SendMailNameEditBox:GetText()
	
	if #tblGuildNames == 0 then	-- if the drop-down menu has never been initialized, then the tables will be empty
		self:BuildGuildTable()
	end

    -- don't track if sendee and sender are the same
    if (sTo == UnitName("player")) then
        self.hooks["SendMailFrame_SendMail"]()
        return
    end

    --self.db.factionrealm.lastsendto = sTo
    SendMailNameEditBox:ClearFocus()

    local iWaitTime = 60 * 60 + 20   -- wait a little longer than an hour because delivery isn't 100% accurate

    -- save sendee in Other list if it's not included in any other list
    --local inAlts = self:TableFind(self.db.factionrealm.alts, sTo, -1)
	local inAlts = tContains(self.db.factionrealm.alts, sTo)
	if not inAlts then
		-- Not in the player's faction, check opposite side to see if the name exists.  Sending Heriloom items cross-faction is allowed and instant
		--inAlts = self:TableFind(self.db.realm[PlayerOppositeFaction], sTo, -1)
		inAlts = tContains(self.db.realm[PlayerOppositeFaction], sTo)
	end
	--local inOthers = self:TableFind(self.db.factionrealm.others, sTo, -1)
	local inOthers = tContains(self.db.factionrealm.others, sTo)
    --local inGuild = self:TableFind(tblGuildNames, sTo, -1)
	local inGuild = tContains(tblGuildNames, sTo)
    --local inFriends = self:TableFind(tblFriendNames, sTo, -1)
	local inFriends = tContains(tblFriendNames, sTo)
    if not inAlts and not inOthers and not inGuild and not inFriends then
        table.insert(self.db.factionrealm.others, sTo)
        table.sort(self.db.factionrealm.others)
    end

    -- save sendee in Last list if it's not included already
    local inLast = self:TableFind(self.db.factionrealm.last, sTo, -1)
    if not inLast then
        table.insert(self.db.factionrealm.last, 1, sTo)
    else
        table.remove(self.db.factionrealm.last, inLast)
        table.insert(self.db.factionrealm.last, 1, sTo)
    end
	
	local UsingGmail = false
	if IsInGuild() and inGuild then
		local GuildLevel, _ = GetGuildLevel()	-- current level, max level
		if GuildLevel >= 17 then 
			UsingGmail = true
		end
	end

    -- prepare a notification as long as the recipient isn't an alt, those are received immediately
	-- Also don't bother with the notification if the user's in a guild and has the Guild Mail perk, mail gets delivered immediately as well
    if not (inAlts or UsingGmail) then
        -- See if we are sending an item and/or money
        local name, _, count = GetSendMailItem()    -- name, texture, count
        local amount = MoneyInputFrame_GetCopper(SendMailMoney)
        local attachment
        if name or (amount > 0) and not inAlts then
            if name then
                -- we're sending an item
                name:trim()
                if count > 1 then
                    sAttachment = count .. "x" .. name
                else
                    sAttachment = name
                end
                if amount > 0 then
                    -- and we're sending money
                    money = self:getTextGSC(amount)
                    if SendMailCODButton:GetChecked() then
                        sAttachment = sAttachment .. " for " .. money .. " (COD)"
                    else
                        sAttachment = sAttachment .. " and " .. money
                    end
                end
            else
                -- we're only sending money
                money = self:getTextGSC(amount)
                if SendMailCODButton:GetChecked() then
                    sAttachment = money .. " (COD)"
                else
                    sAttachment = money
                end
            end
            table.insert(self.db.factionrealm.mailLog, {
                to = sTo,
                from = UnitName("player"),
                attachment = sAttachment,
                t = time() + iWaitTime
            })
            self:Print(L["%s sent to %s by %s is due in %d min."]:format(sAttachment, sTo, UnitName("player"), iWaitTime / 60))
	    -- Send Comm message to receiver, that way they get a log entry as well
--		if UnitIsConnected(sTo) == 1 then
		if self.db.profile.p2pcomm then
			self:SendCommMessage("JebusMail", sAttachment, "WHISPER", sTo);
		end

            if not self.NextLogCheck then
				self.NextLogCheck = self:ScheduleTimer("ProcessMailLog", iWaitTime, self)
            end
        end
    end

    self.hooks["SendMailFrame_SendMail"]()
end

function JebusMail:getGSC(money)
    if (money == nil) then money = 0 end
    local g = math.floor(money / 10000)
    local s = math.floor((money - (g*10000)) / 100)
    local c = math.ceil(money - (g*10000) - (s*100))
    return g,s,c
end

function JebusMail:getTextGSC(money)
    if (type(money) ~= "number") then return end

    local TEXT_NONE = "0"

    local GSC_GOLD="ffd100"
    --local GSC_SILVER="e6e6e6" -- original line
    local GSC_SILVER="a0a0a0"
    local GSC_COPPER="c8602c"
    local GSC_START="|cff%s%d%s|r"
    local GSC_PART=".|cff%s%02d%s|r"
    --local GSC_NONE="|cffa0a0a0"..TEXT_NONE.."|r"  -- original line
    local GSC_NONE="|cffffffff"..TEXT_NONE.."|r"

    if (not money) then money = 0 end

    local g, s, c = self:getGSC(money)
    local gsc = ""
    local fmt = GSC_START
    if (g > 0) then gsc = gsc..string.format(fmt, GSC_GOLD, g, 'g') fmt = GSC_PART end
    if (s > 0) then gsc = gsc..string.format(fmt, GSC_SILVER, s, 's') fmt = GSC_PART end
    if (c > 0) then gsc = gsc..string.format(fmt, GSC_COPPER, c, 'c') end

    if (gsc == "") then gsc = GSC_NONE end

    return gsc
end

function JebusMail:ToBoxAutoComplete()
    local sToBox = this:GetText()

    -- check against alts
    for _, sName in pairs(self.db.factionrealm.alts) do
        if self:StringMatch(sToBox, sName) and sName ~= UnitName("player") then
            return
        end
    end
    -- check against others
    for _, sName in pairs(self.db.factionrealm.others) do
        if self:StringMatch(sToBox, sName) and sName ~= UnitName("player") then
            return
        end
    end
    self.hooks["SendMailFrame_SendeeAutocomplete"]()
end

function JebusMail:StringMatch(str1, str2)
    if str2 and str2:lower():find(str1:lower(), 1, true) == 1 then
        this:SetText(str2)
        this:HighlightText(strlen(str1), -1)
        return true
    end
    return false
end

function JebusMail:FillToBox(oToBox)
    if oToBox:GetText() == "" and self.db.factionrealm.last[1] and self.db.factionrealm.last[1] ~= UnitName("player") then
        oToBox:SetText(self.db.factionrealm.last[1])
    else
		if oToBox:GetText() == "" and self.db.factionrealm.last[2] then
			oToBox:SetText(self.db.factionrealm.last[2])
		end
    end
    oToBox:HighlightText(0,-1)
    self.hooks[oToBox].OnEditFocusGained()
end

function JebusMail:ProcessMailLog()
    local now = time()
    local bRangBell = false
    local tblDelivered = {}
    local NextCheck

    for i, mail in pairs(self.db.factionrealm.mailLog) do
        if mail.t > now then
            if not NextCheck or mail.t < NextCheck then
                NextCheck = mail.t
            end
        else
            if self.db.profile.announce.chat then
                self:Print(L["%s from %s has been delivered to %s."]:format(mail.attachment or "", mail.from, mail.to))
            end
            if self.db.profile.announce.sound and not bRangBell then
                PlaySound("AuctionWindowOpen")
                bRangBell = true
            end
            table.insert(tblDelivered, i)
        end
    end

    for k, v in pairs(tblDelivered) do
        table.remove(self.db.factionrealm.mailLog or {}, v - (k - 1))
    end
    if NextCheck then
		self.NextLogCheck = self:ScheduleTimer("ProcessMailLog", NextCheck - now, self)
    end
end

function JebusMail:DisplayInTransit(bForce)
    local now = time()
    local bDisplayed = false

    for i,mail in pairs(self.db.factionrealm.mailLog) do
        if self.db.profile.announce.chat and (mail.t - now) / 60 + 1 >= 0 then
            bDisplayed = true
            self:Print(L["%s sent to %s by %s is due in %d min."]:format(mail.attachment, mail.to, mail.from, (mail.t - now) / 60 + 1))
        end
    end
    if not bDisplayed and bForce == true then
        self:Print(L["The mail log is empty."])
    end
end

function JebusMail:GetDeliveryMsg()
    return self.db.profile.announce.chat
end

function JebusMail:SetDeliveryMsg(value)
    if type(value) == "boolean" then
        value = not self.db.profile.announce.chat
        if value then
            value = 1
        else
            value = 0
        end
    else
        value = tonumber(value)
    end
    if value and value > 0 then
        self.db.profile.announce.chat = value
        self.panel.chkDeliveryMsg:SetChecked(value)
    else
        self.db.profile.announce.chat = false
        self.panel.chkDeliveryMsg:SetChecked(0)
    end
end

function JebusMail:Setvguildsplit(value)
    JebusMail.db.factionrealm.vguildsplit = value

     local myTooltipText = L["How many guild members should be in one subfolder?"] .. ": " .. value;
     JebusMail.panel.vguildsplit.tooltipText = myTooltipText;
     GameTooltip:SetText(myTooltipText, nil, nil, nil, nil, 1);
     GameTooltip:Show();
end

function JebusMail:Setvfriendssplit(value)
    JebusMail.db.factionrealm.vfriendssplit = value

     local myTooltipText = L["How many friends should be in one subfolder?"] .. ": " .. value;
     JebusMail.panel.vfriendssplit.tooltipText = myTooltipText;
     GameTooltip:SetText(myTooltipText, nil, nil, nil, nil, 1);
     GameTooltip:Show();
end

function JebusMail:SetmaxLast(value)
    JebusMail.db.factionrealm.maxLast = value

     local myTooltipText = L["How many recipients do you want to remember?"] .. ": " .. value;
     JebusMail.panel.maxLast.tooltipText = myTooltipText;
     GameTooltip:SetText(myTooltipText, nil, nil, nil, nil, 1);
     GameTooltip:Show();
end

function JebusMail:GetDeliverySound()
    return self.db.profile.announce.sound
end

function JebusMail:SetDeliverySound(value)
    if type(value) == "boolean" then
        value = not self.db.profile.announce.sound
        if value then
            value = 1
        else
            value = 0
        end
    else
        value = tonumber(value)
    end
    if value and value > 0 then
        self.db.profile.announce.sound = value
        self.panel.chkDeliverySnd:SetChecked(value)
    else
        self.db.profile.announce.sound = false
        self.panel.chkDeliverySnd:SetChecked(0)
    end
end

function JebusMail:GetSplitGuild()
    return self.db.profile.splitguild
end

function JebusMail:SetSplitGuild(value)
    if type(value) == "boolean" then
        value = not self.db.profile.splitguild
        if value then
            value = 1
        else
            value = 0
        end
    else
        value = tonumber(value) -- value is a string?!?!
    end
    if value and value > 0 then
        self.db.profile.splitguild = value
        self.panel.chkSplitGuild:SetChecked(value)
    else
        self.db.profile.splitguild = false
        self.panel.chkSplitGuild:SetChecked(0)
    end
end

function JebusMail:GetSplitFriends()
    return self.db.profile.splitfriends
end

function JebusMail:SetSplitFriends(value)
    if type(value) == "boolean" then
        value = not self.db.profile.splitfriends
        if value then
            value = 1
        else
            value = 0
        end
    else
        value = tonumber(value) -- value is a string?!?!
    end
    if value and value > 0 then
        self.db.profile.splitfriends = value
        self.panel.chkSplitFriends:SetChecked(value)
    else
        self.db.profile.splitfriends = false
        self.panel.chkSplitFriends:SetChecked(0)
    end
end

function JebusMail:SetExclude(value, chk)
	self.db.profile.exclude = value
	
	if (value == 0) then
		self.panel.chkExclude0:SetChecked(true)
		self.panel.chkExclude1:SetChecked(false)
		self.panel.chkExclude2:SetChecked(false)
	elseif (value == 1) then
		self.panel.chkExclude0:SetChecked(false)
		self.panel.chkExclude1:SetChecked(true)
		self.panel.chkExclude2:SetChecked(false)
	elseif (value == 2) then
		self.panel.chkExclude0:SetChecked(false)
		self.panel.chkExclude1:SetChecked(false)
		self.panel.chkExclude2:SetChecked(true)
	end
end

function JebusMail:TakeItem(parentself, idx, ...)
	local buttonClicked = GetMouseButtonClicked();
	
    if buttonClicked ~= "RightButton" or IsAltKeyDown() or IsShiftKeyDown() or IsControlKeyDown() then
        self.hooks["InboxFrame_OnClick"](parentself, idx, ...)
        return
    end

    local _, _, from, subject, money, cod, expires, hasitem, wasread, _, _, _ = GetInboxHeaderInfo(idx)

    --local checked = this:GetChecked()
    local body, _, _, invoice = GetInboxText(idx)

    --this:SetChecked(checked)

    if (not hasitem) and (money == 0) and (not wasread or (body and body ~= "")) then
        self.hooks["InboxFrame_OnClick"](parentself, idx, ...)
        return
    end

    if cod and cod > 0 then
        if cod > GetMoney() then
            StaticPopup_Show("COD_ALERT")
        else
            InboxFrame.openMailID = idx
            OpenMail_Update()
            ShowUIPanel(OpenMailFrame)
            PlaySound("igSpellBookOpen")
            StaticPopup_Show("COD_CONFIRMATION")
        end
        return
    end

    local took = ""
    if money > 0 then
        --took = abacus:FormatMoneyFull(money, true)
        took = JebusMail:getTextGSC(money)
        self.reccash.total = self.reccash.total + money
        if strfind(subject, L["Outbid"]) or strfind(subject, L["Auction cancelled"]) then
            self.reccash.refun = self.reccash.refun + money
        elseif strfind(subject, L["Auction successful"]) then
            self.reccash.sales = self.reccash.sales + money
        else
            self.reccash.other = self.reccash.other + money
        end
        TakeInboxMoney(idx)
    end

    if hasitem and money == 0 then
        local name, _, count, quality = GetInboxItem(idx)	-- name, texture, count, quality, canuse
        TakeInboxItem(idx)
    end

    if not body or body == "" then
        _, _, _, _, money, _, _, hasitem = GetInboxHeaderInfo(idx)
        if not hasitem and money == 0 then
            DeleteInboxItem(idx)
        end
    end

    if took ~= "" then
        self:Print(L["Received %s from %s"]:format(took, from or L["UNKNOWN"]))
    end
end

function JebusMail:ReceiveMessage(prefix, sAttachment, distribution, sFrom, ...)
	local iWaitTime = 60 * 61;
	table.insert(self.db.factionrealm.mailLog, {
		to = UnitName("player"),
		from = sFrom,
		attachment = sAttachment,
		t = time() + iWaitTime
	})
	self:Print(L["%s sent to %s by %s is due in %d min."]:format(sAttachment, UnitName("player"), sFrom, iWaitTime / 60))
end

function JebusMail:GetP2PComm()
    return self.db.profile.p2pcomm
end

function JebusMail:SetP2PComm(value)
    if type(value) == "boolean" then
        value = not self.db.profile.p2pcomm
        if value then
            value = 1
        else
            value = 0
        end
    else
        value = tonumber(value)
    end
    if value and value > 0 then
        self.db.profile.p2pcomm = value
        self.panel.chkP2PComm:SetChecked(value)
    else
        self.db.profile.p2pcomm = false
        self.panel.chkP2PComm:SetChecked(0)
    end
end

function JebusMail:BuildGuildTable()
	GuildRoster();
	for i=1,GetNumGuildMembers(true) do
		local sMemberName = GetGuildRosterInfo(i);
		sMemberName = strsub(sMemberName, 1, strfind(sMemberName, "-") - 1);
		if sMemberName ~= sPlayerName and not JebusMail:TableFind(JebusMail.db.factionrealm.alts, sMemberName, 2) and not JebusMail:TableFind(tblMasterFriends, sMemberName, 2) then
			table.insert(tblGuildNames, sMemberName);
		end
	end
	table.sort(tblGuildNames);	-- sort that list alphabetically
end

function JebusMail:ShowConfig()
	InterfaceOptionsFrame_OpenToCategory("JebusMail")
end
