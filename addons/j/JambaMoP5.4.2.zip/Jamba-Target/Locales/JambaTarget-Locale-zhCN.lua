--[[
Jamba - Jafula's Awesome Multi-Boxer Assistant
Copyright 2008 - 2014 Michael "Jafula" Miller
Released under the MIT license.
http://jafula.com/jamba/
]]--

local L = LibStub("AceLocale-3.0"):NewLocale( "Jamba-Target", "zhCN", true )
L["Slash Commands"] = true
L["Combat"] = true
L["Target"] = true
L["Push Settings"] = true
L["Push the target settings to all characters in the team."] = true
L["Settings received from A."] = function( characterName )
	return string.format( "Settings received from %s.", characterName )
end
L["Target Options"] = true
