
--[[

Translations are maintained at http://wow.curseforge.com/projects/petleash/localization/

Please update http://wow.curseforge.com/projects/petleash/localization/frFR/
instead of modifying this file.

--]]

local L = LibStub("AceLocale-3.0"):NewLocale("PetLeash", "frFR")
if not L then return end

-- 

L["Add Current Subzone"] = "Ajouter la sous-zone courante"
L["Add Current Zone"] = "Ajouter la zone courante"
L["Auto Summon:"] = "Auto invocation:"
L["Auto Switch Pet"] = "Chang. auto du familier" -- Needs review
-- L["Auto Switch when changing maps"] = ""
L["City"] = "Ville"
L["Ctrl + Click:"] = "Ctrl + Clic:"
L["Custom Locations"] = "Lieux personnalis\195\169s"
L["Dismiss Pet"] = "Renvoyer le familier"
L["Dismiss your currently summoned pet.  Disable summoning."] = "Renvoie votre familier actuel. D\195\169sactive l'invocation."
L["Dismiss your current pet and summon another pet.  Enable summoning if needed."] = "Renvoie votre familier actuel et en incante un autre. Activez l'invocation si besoin."
L["Disable All"] = "Tout d\195\169sactiver"
L["Disabled"] = "D\195\169sactiv\195\169"
L["Dismiss When Flying"] = "Renvoyer lors d'un vol"
L["Dismiss When Stealthed or Invisible"] = "Renvoyer quand furtif ou invisible"
L["Enable All"] = "Tout activer"
L["Enable Auto-Summon"] = "Activer l'auto invocation"
L["Enabled"] = "Activ\195\169"
L["Enabled Pets"] = "Familiers activ\195\169s"
L["Enable In Battlegrounds/Arena"] = "Activer en champ de bataille/ar\195\168nes" -- Needs review
L["Enable In Combat"] = "Actif en combat" -- Needs review
-- L["Enable Timed Auto Switch"] = ""
L["Hardly Ever"] = "Presque tout le temps"
L["How long must pass before a player is considered idle enough to summon a pet."] = "Combien de temps doit s'\195\169couler avant qu'un joueur soit consid\195\169r\195\169 inoccup\195\169 pour invoquer un familier."
L["Immediate"] = "Imm\195\169diat"
L["Immediately switch pets upon zone change."] = "Change imm\195\169diatement de familier lors d'un changement de zone" -- Needs review
L["Inherits"] = "H\195\169rite" -- Needs review
L["Inherits From"] = "H\195\169rite de" -- Needs review
L["Instance"] = "Instance"
L["Left-Click:"] = "Clic gauche"
L["Locations"] = "Lieux"
L["Never"] = "Jamais"
L["Occasionally"] = "Occasionnellement"
L["Often"] = "Souvent"
L["Only Enable in Cities"] = "Actif seulement dans les villes"
-- L["Only use Timed Auto Switch in cities"] = ""
L["Open Configuration"] = "Ouvrir les param\195\168tres"
L["Open Configuration Panel"] = "Ouvrir le panneau de configuration"
-- L["Override Pet Battle Loadout"] = ""
L["Pet Menu"] = "Menu du familier"
L["Pets"] = "Familier"
-- L["Profiles"] = ""
L["Rarely"] = "Rarement"
-- L["Resummon pet after a pet has been summoned via setting the battle pet loadout."] = ""
L["Right-Click:"] = "Clic droit"
L["Seconds between switch"] = "Secondes entre les changements" -- Needs review
L["Sometimes"] = "Parfois"
L["Special Locations"] = "Lieux particuliers"
L["Special Locations are predefined areas that cover a certain type of zone."] = "Les lieux sp\195\169cifiques sont des zones pr\195\169d\195\169finies qui couvrent un certain type de zone."
L["Summon Another Pet"] = "Invoquer un autre familier"
L["Toggle Non-Combat Pet"] = "Basculer le familier en mode pas-de-combat" -- Needs review
L["Use a pet list from another location."] = "Utilise une liste de familiers d'un autre lieu."
-- L["Verbose"] = ""
L["Wait Time (Seconds)"] = "Temps d'attente (secondes)"
-- L["Weighted Pets"] = ""
-- L["You have %d pets"] = ""
-- L["You have no pets"] = ""


