
--[[

Translations are maintained at http://wow.curseforge.com/projects/petleash/localization/

Please update http://wow.curseforge.com/projects/petleash/localization/zhCN/
instead of modifying this file.

--]]

local L = LibStub("AceLocale-3.0"):NewLocale("PetLeash", "zhCN")
if not L then return end

-- 

L["Add Current Subzone"] = "\229\162\158\229\138\160\229\189\147\229\137\141\229\173\144\229\140\186\229\159\159" -- Needs review
L["Add Current Zone"] = "\229\162\158\229\138\160\229\189\147\229\137\141\229\140\186\229\159\159" -- Needs review
L["Auto Summon:"] = "\232\135\170\229\138\168\229\143\172\229\148\164:" -- Needs review
L["Auto Switch Pet"] = "\232\135\170\229\138\168\229\136\135\230\141\162\229\174\160\231\137\169" -- Needs review
L["Auto Switch when changing maps"] = "\229\189\147\232\191\155\229\133\165\228\184\141\229\144\140\229\156\176\229\155\190\229\140\186\229\159\159\230\151\182\232\135\170\229\138\168\229\136\135\230\141\162" -- Needs review
L["City"] = "\228\184\187\229\159\142" -- Needs review
L["Ctrl + Click:"] = "Ctrl + \231\130\185\229\135\187:" -- Needs review
L["Custom Locations"] = "\232\135\170\229\174\154\228\185\137\228\189\141\231\189\174" -- Needs review
L["Dismiss Pet"] = "\232\167\163\230\149\163\229\174\160\231\137\169" -- Needs review
L["Dismiss your currently summoned pet.  Disable summoning."] = "\232\167\163\230\149\163\228\189\160\231\154\132\229\189\147\229\137\141\229\174\160\231\137\169. \231\166\129\231\148\168\229\143\172\229\148\164." -- Needs review
L["Dismiss your current pet and summon another pet.  Enable summoning if needed."] = "\232\167\163\230\149\163\228\189\160\231\154\132\229\189\147\229\137\141\229\174\160\231\137\169\229\185\182\229\143\172\229\148\164\229\143\166\228\184\128\228\184\170\229\174\160\231\137\169. " -- Needs review
L["Disable All"] = "\231\166\129\231\148\168\229\133\168\233\131\168" -- Needs review
L["Disabled"] = "\231\166\129\231\148\168" -- Needs review
L["Dismiss When Flying"] = "\229\189\147\233\163\158\232\161\140\230\151\182\232\167\163\230\149\163" -- Needs review
L["Dismiss When Stealthed or Invisible"] = "\229\189\147\230\189\156\232\161\140\230\136\150\230\182\136\229\164\177\230\151\182\232\167\163\230\149\163" -- Needs review
L["Enable All"] = "\229\144\175\231\148\168\229\133\168\233\131\168" -- Needs review
L["Enable Auto-Summon"] = "\229\144\175\231\148\168\232\135\170\229\138\168\229\143\172\229\148\164" -- Needs review
L["Enabled"] = "\229\144\175\231\148\168" -- Needs review
L["Enabled Pets"] = "\229\144\175\231\148\168\229\174\160\231\137\169" -- Needs review
L["Enable In Battlegrounds/Arena"] = "\229\156\168\230\136\152\229\156\186/\231\171\158\230\138\128\229\156\186\228\184\173\229\144\175\231\148\168" -- Needs review
L["Enable In Combat"] = "\229\156\168\230\136\152\230\150\151\228\184\173\229\144\175\231\148\168" -- Needs review
L["Enable Timed Auto Switch"] = "\229\144\175\231\148\168\229\174\154\230\151\182\232\135\170\229\138\168\229\136\135\230\141\162" -- Needs review
L["Hardly Ever"] = "\229\135\160\228\185\142\228\187\142\228\184\141" -- Needs review
L["How long must pass before a player is considered idle enough to summon a pet."] = "\231\142\169\229\174\182\231\169\186\233\151\178\231\154\132\230\151\182\233\151\180\233\149\191\229\186\166\230\157\165\229\143\172\229\148\164\228\184\128\228\184\170\229\174\160\231\137\169." -- Needs review
L["Immediate"] = "\231\171\139\229\141\179" -- Needs review
L["Immediately switch pets upon zone change."] = "\229\156\176\229\155\190\229\140\186\229\159\159\230\148\185\229\143\152\229\144\142\231\171\139\229\141\179\229\136\135\230\141\162\229\174\160\231\137\169." -- Needs review
L["Inherits"] = "\231\187\167\230\137\191" -- Needs review
L["Inherits From"] = "\231\187\167\230\137\191\232\135\170" -- Needs review
L["Instance"] = "\229\137\175\230\156\172" -- Needs review
L["Left-Click:"] = "\229\183\166\233\148\174\231\130\185\229\135\187:" -- Needs review
L["Locations"] = "\228\189\141\231\189\174" -- Needs review
L["Never"] = "\228\187\142\228\184\141" -- Needs review
L["Occasionally"] = "\229\129\182\229\176\148" -- Needs review
L["Often"] = "\231\187\143\229\184\184" -- Needs review
L["Only Enable in Cities"] = "\228\187\133\229\156\168\228\184\187\229\159\142\229\144\175\231\148\168" -- Needs review
L["Only use Timed Auto Switch in cities"] = "\229\156\168\228\184\187\229\159\142\228\184\173\228\187\133\228\189\191\231\148\168\229\174\154\230\151\182\232\135\170\229\138\168\229\136\135\230\141\162" -- Needs review
L["Open Configuration"] = "\230\137\147\229\188\128\233\133\141\231\189\174" -- Needs review
L["Open Configuration Panel"] = "\230\137\147\229\188\128\233\133\141\231\189\174\233\157\162\230\157\191" -- Needs review
-- L["Override Pet Battle Loadout"] = ""
L["Pet Menu"] = "\229\174\160\231\137\169\232\143\156\229\141\149" -- Needs review
L["Pets"] = "\229\174\160\231\137\169" -- Needs review
-- L["Profiles"] = ""
L["Rarely"] = "\231\168\128\229\176\145" -- Needs review
-- L["Resummon pet after a pet has been summoned via setting the battle pet loadout."] = ""
L["Right-Click:"] = "\229\143\179\233\148\174\231\130\185\229\135\187:" -- Needs review
L["Seconds between switch"] = "\229\136\135\230\141\162\229\174\160\231\137\169\231\154\132\231\167\146\230\149\176" -- Needs review
L["Sometimes"] = "\230\156\137\230\151\182" -- Needs review
L["Special Locations"] = "\231\137\185\230\174\138\228\189\141\231\189\174" -- Needs review
L["Special Locations are predefined areas that cover a certain type of zone."] = "\231\137\185\229\174\154\229\140\186\229\159\159\230\152\175\230\140\135\230\182\181\231\155\150\228\186\134\230\159\144\228\186\155\229\140\186\229\159\159\231\177\187\229\158\139\231\154\132\229\183\178\233\162\132\229\174\154\228\185\137\231\154\132\229\140\186\229\159\159." -- Needs review
L["Summon Another Pet"] = "\229\143\172\229\148\164\229\143\166\228\184\128\228\184\170\229\174\160\231\137\169" -- Needs review
L["Toggle Non-Combat Pet"] = "\229\144\175\231\148\168/\231\166\129\231\148\168\233\157\158\230\136\152\230\150\151\229\174\160\231\137\169" -- Needs review
L["Use a pet list from another location."] = "\228\189\191\231\148\168\230\157\165\232\135\170\229\143\166\228\184\128\228\184\170\229\156\176\230\150\185\231\154\132\229\174\160\231\137\169\229\136\151\232\161\168" -- Needs review
-- L["Verbose"] = ""
L["Wait Time (Seconds)"] = "\231\173\137\229\190\133\230\151\182\233\151\180 (\230\140\137\231\167\146)" -- Needs review
L["Weighted Pets"] = "\230\155\180\229\164\154\233\128\137\233\161\185" -- Needs review
-- L["You have %d pets"] = ""
-- L["You have no pets"] = ""


