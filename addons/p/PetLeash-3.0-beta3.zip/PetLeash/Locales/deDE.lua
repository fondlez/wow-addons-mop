
--[[

Translations are maintained at http://wow.curseforge.com/projects/petleash/localization/

Please update http://wow.curseforge.com/projects/petleash/localization/deDE/
instead of modifying this file.

--]]

local L = LibStub("AceLocale-3.0"):NewLocale("PetLeash", "deDE")
if not L then return end

--

L["Add Current Subzone"] = "Aktuelles Teilgebiet zuf\195\188gen"
L["Add Current Zone"] = "Aktuelles Gebiet zuf\195\188gen"
L["Auto Summon:"] = "Automatisch herbeirufen: "
L["Auto Switch Pet"] = "Begleiter automatisch herbeirufen" -- Needs review
L["Auto Switch when changing maps"] = "Bei Kartenwechsel automatisch herbeirufen" -- Needs review
L["City"] = "Stadt"
L["Ctrl + Click:"] = "Strg + Klick:"
L["Current Pet:"] = "Aktueller Begleiter:" -- Needs review
L["Custom Locations"] = "Benutzerdefinierte \195\150rtlichkeiten"
L["Dismiss Pet"] = "Begleiter freisetzen"
L["Dismiss your currently summoned pet.  Disable summoning."] = "Deinen aktuellen Begleiter freisetzen. Herbeirufen deaktivieren."
L["Dismiss your current pet and summon another pet.  Enable summoning if needed."] = "Deinen aktuellen Begleiter freisetzen und einen anderen Begleiter herbeirufen. Falls notwedig, Herbeirufen aktivieren."
L["Disable All"] = "Alle deaktivieren"
L["Disabled"] = "Deaktiviert"
L["Dismiss In Battlegrounds/Arena"] = "Begleiter in Schlachtfeldern/Arena wegschicken" -- Needs review
L["Dismiss When Flying"] = "Beim Fliegen fortschicken"
L["Dismiss When Stealthed or Invisible"] = "Freisetzen sobald im T\195\164uschungsmodus oder unsichtbar"
L["Enable All"] = "Alle aktivieren"
L["Enable Auto-Summon"] = "Automatisches Herbeirufen aktivieren"
L["Enabled"] = "Aktiviert"
L["Enabled Pets"] = "Begleiter aktivieren"
L["Enable In Battlegrounds/Arena"] = "In Schlachtfeldern/Arena aktivieren"
L["Enable In Combat"] = "Beschw\195\182ren im Kampf aktivieren"
L["Enable Timed Auto Switch"] = "Zeitgesteuertes Herbeirufen aktivieren" -- Needs review
L["Hardly Ever"] = "Kaum"
L["How long must pass before a player is considered idle enough to summon a pet."] = "Wie lange soll gewartet werden bevor ein Begleiter beschworen wird"
L["Immediate"] = "Sofort"
L["Immediately switch pets upon zone change."] = "Begleiter beim Gebietswechsel sofort tauschen"
L["Inherits"] = "Erbt"
L["Inherits From"] = "Erbt von"
L["Instance"] = "Instanz"
L["Left-Click:"] = "Links-Klick:"
L["Locations"] = "Orte"
L["Never"] = "nie"
L["Occasionally"] = "gelegentlich"
L["Often"] = "oft"
L["Only Enable in Cities"] = "Nur in St\195\164dten aktivieren"
L["Only use Timed Auto Switch in cities"] = "Zeitgesteuertes Herbeirufen nur in St\195\164dten verwenden" -- Needs review
L["Open Configuration"] = "Konfiguration \195\182ffnen"
L["Open Configuration Panel"] = "Konfigurationsfenster \195\182ffnen"
-- L["Override Pet Battle Loadout"] = ""
L["Pet Menu"] = "Begleiter-Men\195\188"
L["Pets"] = "Begleiter"
L["Profiles"] = "Profile" -- Needs review
L["Rarely"] = "selten"
-- L["Resummon pet after a pet has been summoned via setting the battle pet loadout."] = ""
L["Right-Click:"] = "Rechts-Klick:"
L["Seconds between switch"] = "Wartezeit (Sekunden)" -- Needs review
L["Sometimes"] = "manchmal"
L["Special Locations"] = "Besondere Orte"
L["Special Locations are predefined areas that cover a certain type of zone."] = "Spezielle \195\150rtlichkeiten sind vordefinierte Gebiete, die einen bestimmten Typ Zone abdecken."
L["Summon Another Pet"] = "Einen anderen Begleiter herbeirufen"
L["Toggle Non-Combat Pet"] = "Nicht-k\195\164mpfenden Begleiter (Haustier) auswechseln"
L["Use a pet list from another location."] = "Benutze eine Liste von Begleitern einer anderen \195\150rtlichkeit."
L["Use Favorites"] = "Favoriten verwenden" -- Needs review
L["Verbose"] = "Umfangreiche Ausgaben" -- Needs review
L["Wait Time (Seconds)"] = "Wartezeit (Sekunden)"
L["Weighted Pets"] = "Besonders zu behandelnde Begleiter"
L["You have %d pets"] = "Du hast %d Begleiter" -- Needs review
L["You have no pets"] = "Du hast keine Begleiter" -- Needs review


