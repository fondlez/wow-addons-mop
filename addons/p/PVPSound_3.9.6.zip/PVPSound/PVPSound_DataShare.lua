﻿function PVPSound_DataOnLoad()
	PVPSoundDataFrame:RegisterEvent("CHAT_MSG_ADDON")
	PVPSoundDataFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
end

local CheckLimit = 3.0000

-- Names
local PlayerName
local PlayerNameSpree
local KillerName
local KillerNameServer

-- Sprees
local Spree
local DeathSpree
local MessageSpree

-- PVPSound Addon Data Sharing
function PVPSound_DataOnEvent(self, event, prefix, message, channel, sender, ...)
	if PS_DataShare == true then
		if event == "CHAT_MSG_ADDON" then
			-- If the Sent Data is from the registered prefix
			if prefix == "PVPSound" then
				-- If the sender is not nil and its not the player
				if sender ~= nil and sender ~= UnitName("player") then
					-- If the message is not nil
					if message ~= nil then
						-- Death Data Share
						if string.find(message, ":") then
							DeathSpree = tostring(string.match(message, "(.+):"))
							KillerNameServer = tostring(string.match(message, ":(.+)"))
							if KillerNameServer ~= nil then
								-- If the killer is NPC
								if string.sub(KillerNameServer, -1) == "!" then
									KillerName = KillerNameServer
								 -- If the killer is from CrossRealm
								else
									-- If not suicide
									if KillerNameServer ~= sender then
										if string.find(KillerNameServer, "-") and PS_HideServerName ~= false then
											KillerName = tostring(string.match(KillerNameServer, "(.+)-"))
											-- If from -Azjol-Nerub
											if string.find(KillerNameServer, "-") and PS_HideServerName ~= false then
												KillerName = tostring(string.match(KillerNameServer, "(.+)-"))
											end
										else
											KillerName = tostring(KillerNameServer)
										end
									end
								end
								if DeathSpree ~= nil then
									if KillerName ~= nil then
										-- If the killer is NPC
										if string.sub(KillerName, -1) == "!" then
											KillerName = string.sub(KillerName, 1, string.len(KillerName)-1)
											if SenderName ~= nil and DeathSpree ~= nil and KillerName ~= nil then
												PVPSound_PrintDeath(SenderName, DeathSpree, KillerName)
											end
										else
											-- If sender is from CrossRealm
											if string.find(sender, "-") and PS_HideServerName ~= false then
												SenderName = tostring(string.match(sender, "(.+)-"))
												-- If from -Azjol-Nerub
												if string.find(SenderName, "-") and PS_HideServerName ~= false then
													SenderName = tostring(string.match(SenderName, "(.+)-"))
													if SenderName ~= nil and DeathSpree ~= nil and KillerName ~= nil then
														PVPSound_PrintDeath(SenderName, DeathSpree, KillerName)
													end
												else
													if SenderName ~= nil and DeathSpree ~= nil and KillerName ~= nil then
														PVPSound_PrintDeath(SenderName, DeathSpree, KillerName)
													end
												end
											else
												SenderName = tostring(sender)
												if SenderName ~= nil and DeathSpree ~= nil and KillerName ~= nil then
													PVPSound_PrintDeath(SenderName, DeathSpree, KillerName)
												end
											end
										end
									end
								end
							end
						else
							-- Nil everything
							Spree = nil
							DeathSpree = nil
							MessageSpree = nil
							PlayerName = nil
							PlayerNameSpree = nil
							KillerName = nil
							KillerNameServer = nil
							WasOutOfRange = nil
						end
					end
				end
			end
		elseif event == "ZONE_CHANGED_NEW_AREA" then
			-- Nil everything
			Spree = nil
			DeathSpree = nil
			MessageSpree = nil
			PlayerName = nil
			PlayerNameSpree = nil
			KillerName = nil
			KillerNameServer = nil
			WasOutOfRange = nil
		end
	end
end

function PVPSound_PrintDeath(sender, message, killer)
	print("|cFFFF4500"..sender..Msg_S.." "..message.." "..Msg_WasOverBy.." "..killer..".|cFFFFFFFF")
end