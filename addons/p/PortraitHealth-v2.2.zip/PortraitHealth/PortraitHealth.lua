-- Global information

classDisplayName, class, classID = UnitClass("player");
PlayerClass = classID;
PlayerClassName = classDisplayName;
PlayerClassNameIndex = class;

PH_p = {}			-- Class:			ID:
PH_p[1] = "20" 		-- Warrior 			1
PH_p[2] = "20" 		-- Paladin 			2
PH_p[3] = "20" 		-- Hunter 			3
PH_p[4] = "35" 		-- Rogue			4
PH_p[5] = "20" 		-- Priest			5
PH_p[6] = "35" 		-- Death Knight		6
PH_p[7] = "10" 		-- Shaman			7
PH_p[8] = "10" 		-- Mage				8
PH_p[9] = "25" 		-- Warlock			9
PH_p[10] = "10" 	-- Monk				10
PH_p[11] = "25" 	-- Druid			11


-- Tell the player what their execute phase is set to
function DisplayClass(class)
	local class = PlayerClass;
	local className = PlayerClassName;
	local x = RAID_CLASS_COLORS[PlayerClassNameIndex];
	DEFAULT_CHAT_FRAME:AddMessage("|cffffff9aPortrait Health|r loaded. Your class: |c"..x.colorStr..""..PlayerClassName.."|r.\nExecute phase set to |cFFFF0000"..PH_p[class].."%|r");
end

-- Set the text color and update health output
function HealthPercentage()

	-- Health value to display. Whole numbers only.
	TargetPercentHealth = (UnitHealth("target") / UnitHealthMax("target") * 100);

	-- Class detection
	
	if PlayerClass == 1 and TargetPercentHealth < 20 then 			-- Warrior
		PortraitHealth_Health:SetTextColor(1,0,0);

		elseif PlayerClass == 2 and TargetPercentHealth <= 20 then 	-- Paladin
				PortraitHealth_Health:SetTextColor(1,0,0);
	
		elseif PlayerClass == 3 and TargetPercentHealth <= 20 then 	-- Hunter
				PortraitHealth_Health:SetTextColor(1,0,0);
				
		elseif PlayerClass == 4 and TargetPercentHealth < 35 then 	-- Rogue
				PortraitHealth_Health:SetTextColor(1,0,0);
		
		elseif PlayerClass == 5 and TargetPercentHealth < 20 then 	-- Priest
				PortraitHealth_Health:SetTextColor(1,0,0);
	
		elseif PlayerClass == 6 and TargetPercentHealth < 35 then 	-- Death Knight
				PortraitHealth_Health:SetTextColor(1,0,0);
				
		elseif PlayerClass == 9 and TargetPercentHealth < 20 then 	-- Warlock
				PortraitHealth_Health:SetTextColor(1,0,0);
	
		elseif PlayerClass == 10 and TargetPercentHealth <= 10 then -- Monk
				PortraitHealth_Health:SetTextColor(1,0,0);
				
		elseif PlayerClass == 11 and TargetPercentHealth <= 25 then -- Druid
				PortraitHealth_Health:SetTextColor(1,0,0);
		
		elseif TargetPercentHealth <= 10 then						-- Other classes
				PortraitHealth_Health:SetTextColor(1,0,0);
				
	else	
		PortraitHealth_Health:SetTextColor(1,1,0);
	end
	
	-- reformat health without decimals
	local h = string.format("%.0f",TargetPercentHealth);
	local i = string.format("%.1f",TargetPercentHealth);
	
	-- change the portrait to show current health
	if UnitIsDead("target") then
		PortraitHealth_Health:SetText('Dead');
	elseif
		TargetPercentHealth >= 1 then PortraitHealth_Health:SetText(h .. '%');
	elseif
		TargetPercentHealth < 1 then PortraitHealth_Health:SetText(i .. '%');
			
	end
	
end

