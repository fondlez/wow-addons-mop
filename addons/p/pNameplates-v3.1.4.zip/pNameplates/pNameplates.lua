--[[ ---------------------- ]]--
--[[ Globals            	]]--
--[[ ---------------------- ]]--

default, realm, player, C, addon_loaded = nil, nil, nil, nil, nil
size_update, text_update, font_update   = false, false, false

bkgTex = 'Interface\\Buttons\\WHITE8x8'
barTex = 'Interface\\AddOns\\pNameplates\\Textures\\bar'

COLOR_LABEL  = ColorString( 'pNameplates' )
ACCENT_LABEL = ColorString( 'p' )..'Nameplates'
COMBAT_LOCK  = UnitAffectingCombat( 'player' )

--[[ table size ]]
function tsize( table )
	local count = 0

	for k, v in pairs( table ) do
		count = count + 1
	end

	return count
end

-- [[ print with pNameplate header ]]
function pNameplates_Print( str )
	print( COLOR_LABEL..': '..str )
end

--[[ ---------------------- ]]--
--[[ Everything Else    	]]--
--[[ ---------------------- ]]--

local function GetRaidIconColor( ulx, uly )
	if ( not ulx ) then ulx = -1 end
	if ( not uly ) then uly = -1 end

	if ( uly == 0.00 ) then

		if ( ulx == 0.00 ) then return 1.00, 1.00, 0.00 end -- Star
		if ( ulx == 0.25 ) then return 1.00, 0.50, 0.00 end -- Circle
		if ( ulx == 0.50 ) then return 0.78, 0.30, 1.00 end -- Diamond
		if ( ulx == 0.75 ) then return 0.30, 1.00, 0.30 end -- Triangle

	elseif ( uly == 0.25 ) then

		if ( ulx == 0.00 ) then return 0.60, 0.60, 0.60 end -- Moon
		if ( ulx == 0.25 ) then return 0.20, 0.60, 1.00 end -- Square
		if ( ulx == 0.50 ) then return 1.00, 0.30, 0.30 end -- Cross
		if ( ulx == 0.75 ) then return 1.00, 1.00, 1.00 end -- Skull

	end

	-- default to gray
	return 0.40, 0.40, 0.40
end

local function GetElementLocation( location )
	if ( location == 'top' )     then return 'BOTTOM', 'TOP'   ,  0, 2, 'CENTER' end
	if ( location == 'left' )    then return 'RIGHT' , 'LEFT'  , -2, 0, 'RIGHT'  end
	if ( location == 'right' )   then return 'LEFT'  , 'RIGHT' ,  2, 0, 'LEFT'   end
	if ( location == 'center' )  then return 'CENTER', 'CENTER',  0, 0, 'CENTER' end
	-- if ( location == 'inleft' )  then return 'LEFT'  , 'LEFT'  ,  2, 0, 'THINOUTLINE', 'LEFT'   end
	-- if ( location == 'inright' ) then return 'RIGHT' , 'RIGHT' , -2, 0, 'THINOUTLINE', 'RIGHT'  end

	-- default to top
	return 'BOTTOM', 'TOP', 0, 2, 'CENTER'
end

local function GetApproxHealth( hp )
	if ( not hp ) then return '' end

	local div, tag
	
	if 	   ( hp < 1000 )       then return tostring( hp )
	elseif ( hp < 1000000 )    then div, tag = 1000,       'k'
	elseif ( hp < 1000000000 ) then div, tag = 1000000,    'm'
	else							div, tag = 1000000000, 'b'
	end
	
	local text = tostring( hp / div ):match( '%d+\.%d' )
	if ( text ) then return text..tag else return tag end
end

local function AbbreviateName( name )
	name_str, len, cur, abbrv = name:GetText(), 0, 0, ''
	
	for token in name_str:gmatch( '[^%s]+' ) do
		cur = token:len() + 1
		len = len + cur
		abbrv = abbrv..token:sub(1, 1)..'. '
	end
	
	len = len - cur
	return ( abbrv:sub( 1, abbrv:len() - 3 )..name_str:sub( len ) )
end

local function GetCheckSum( P )
	local alpha = tostring( P:GetAlpha() )
	alpha = alpha:sub( 1, math.min( alpha:len(), 4 ) )
	local blue = tostring( select( 3, P.old.HB:GetStatusBarColor() ) )
	blue = blue:sub( 1, math.min( blue:len(), 4 ) )
	
	local str = P.old.nam:GetText()..blue..alpha
	local n = str:len()
    local sum = 0
       
    for i = 1, n do sum = 2 * sum + str:byte( i, i ) end
    return sum
end

local function CalculateAbbreviation( P )
	P.HB.abbv_name = AbbreviateName( P.old.nam )
	P.HB.full_name = P.old.nam:GetText()
	P.HB.chop_name = C.Abbreviate and P.old.nam:GetStringWidth() > C.hpw + 10
end

local function Update_Data( P )
	local HB, CB, old = P.HB, P.CB, P.old

	P.checksum = GetCheckSum( P )
	CalculateAbbreviation( P )

	P.HB.lvl:SetTextColor( P.old.lvl:GetTextColor() )
	if ( P.old.lvl:GetText() ~= nil ) then
		P.HB.lvl:SetText( P.old.lvl:GetText()..( P.old.dgn:IsShown() and '+' or '' ) )
	end
end

local function AdjustCBPos( P )
	local x_offset = ( C.cbw - C.hpw ) / 2

	P.CB:ClearAllPoints()
	P.CB:SetPoint( 'TOPLEFT',     P.HB, 'BOTTOMLEFT',  -x_offset, -8 )
	P.CB:SetPoint( 'BOTTOMRIGHT', P.HB, 'BOTTOMRIGHT',  x_offset, -8 - C.cbh )
end

local function Update_Size( P )
	if ( not P.HB.scale ) then P.HB.scale = 1 end
	P.HB:SetSize( C.hpw * P.HB.scale, C.hph * P.HB.scale )

	local icon_w = math.max( C.cbh, C.CBIconSize )

	AdjustCBPos( P )
	P.CB.ico:SetSize( icon_w, icon_w )

	CalculateAbbreviation( P )
end

local function Update_Font( P )
	P.HB.hp:SetFont(   C.FontType_Perc,  C.FontSize_Perc,  'THINOUTLINE' )
	P.HB.nam:SetFont(  C.FontType_Name,  C.FontSize_Name,  'THINOUTLINE' )
	P.old.nam:SetFont( C.FontType_Name,  C.FontSize_Name,  'THINOUTLINE' )
	P.HB.lvl:SetFont(  C.FontType_Level, C.FontSize_Level, 'THINOUTLINE' )
	P.CB.spl:SetFont(  C.FontType_Cast,  C.FontSize_Cast,  'THINOUTLINE' )
	P.CB.tim:SetFont(  C.FontType_Cast,  C.FontSize_Cast,  'THINOUTLINE' )
end

local function Update_Text( P )
	local pt, rel, x, y, justify

	pt, rel, x, y, justify = GetElementLocation( C.Location_Perc )
	P.HB.hp:ClearAllPoints()
	P.HB.hp:SetPoint( pt, P.HB.tgt, rel, x, y )
	P.HB.hp:SetJustifyH( justify )

	pt, rel, x, y, justify = GetElementLocation( C.Location_Name )
	P.HB.nam:ClearAllPoints()
	P.HB.nam:SetPoint( pt, P.HB.tgt, rel, x, y )
	P.HB.nam:SetJustifyH( justify )

	pt, rel, x, y, justify = GetElementLocation( C.Location_Level )
	P.old.bos:ClearAllPoints()
	P.old.bos:SetPoint( pt, P.HB.tgt, rel, x, y )
	P.HB.lvl:ClearAllPoints()
	P.HB.lvl:SetPoint( pt, P.HB.tgt, rel, x, y )
	P.HB.lvl:SetJustifyH( justify )

	pt, rel, x, y, _ = GetElementLocation( C.Location_Raid )
	P.HB.ico:ClearAllPoints()
	P.HB.ico:SetPoint( pt, P.HB.tgt, rel, x, y )
end

local function SetUnitName( P )
	P.HB.nam:SetText( P.HB.chop_name and P.HB.abbv_name or P.HB.full_name )
end

local function SetUnitHealthText( P, value )
	if ( not value ) then value = P.old.HB:GetValue() end
	local _, max = P.old.HB:GetMinMaxValues()

	if ( C.ShowPercent and ( C.ShowWhenMax or value ~= max ) ) then
		local hp_string = 'hp_percent%'
		if ( C.ShowHPValue ) then hp_string = 'hp_value | '..hp_string end

		local h_value = GetApproxHealth( value )
		local percent = tostring( value / max * 100 ):match( '%d+' )

		hp_string = hp_string:gsub( '(hp_value)',   h_value )
		hp_string = hp_string:gsub( '(hp_percent)', percent )

		P.HB.hp:SetText( hp_string )
		P.HB.hp:Show()
	else
		P.HB.hp:Hide()
	end
end

local function Health_OnValue( P, value )
	if ( not value ) then value = P.old.HB:GetValue() end

	P.HB:SetValue( value )
	SetUnitHealthText( P, value )
end

local function Health_OnMinMax( P, min, max )
	if ( not min or not max ) then
		min, max = P.old.HB:GetMinMaxValues()
	end

	P.HB:SetMinMaxValues( min, max )
end

local function Health_OnShow( P )
	Update_Size( P )
	SetUnitName( P )
	Health_OnMinMax( P )
	Health_OnValue( P )
end

local function Castbar_OnValue( P, value )
	P.CB:SetValue( value )

	if ( not C.ShowCBText ) then
		P.CB.spl:Hide()
		P.CB.tim:Hide()
		return
	end

	local value_string = tostring( value ):match( '%d+\.%d' )
	
	P.CB.tim:SetText( value_string )
	P.CB.spl:Show()
	P.CB.tim:Show()
end

local function Castbar_OnMinMax( P, min, max )
	P.CB:SetMinMaxValues( min, max )
end

local function Castbar_OnShow( P )
	AdjustCBPos( P )
	P.CB:Show()

	if ( not P.old.CB.shl:IsShown() ) then P.CB:SetStatusBarColor( 1.00, 0.75, 0.00, 1 )
	else                                   P.CB:SetStatusBarColor( 0.75, 0.75, 0.75, 1 ) end

	P.CB.spl:SetText( P.old.CB.spl:GetText() and P.old.CB.spl:GetText() or '<spell>' )
end

local function Castbar_OnHide( P )
	P.CB:Hide()
end

local function SetRaidIconStatus( HB )
	HB:SetStatusBarColor( GetRaidIconColor( HB.ico:GetTexCoord() ) )
end

local function GetThreatStatus( old )
	local r, g, b = old.thr:GetVertexColor()
	local dps = C.DPSHealerMode

	if ( old.thr ~= nil and not old.thr:IsShown() ) then
		if ( dps ) then return 0, 1, 0, 1,   1, 'LOW',  3, 3
		else            return 1, 0, 0, 1, 1.2, 'HIGH', 5, 5 end
	end
	if ( g > 0 ) then   return 1, 1, 0, 1,   1, 'MED',  5, 5 end
	if ( r > 0 ) then 
		if ( dps ) then return 1, 0, 0, 1, 1.2, 'HIGH', 5, 5
		else            return 0, 1, 0, 1,   1, 'LOW',  3, 3 end
	end

	-- default to unit's hostility color
	return r, g, b, 1, 1, 'LOW', 3, 3
end

local function Update_Threat( P, HB, old )
	local r, b, g, a, scale, style, x, y = GetThreatStatus( old )

	if ( not HB.scale ) then HB.scale = scale end
	if ( HB.scale ~= scale ) then
		HB.scale = scale
		Update_Size( P )
	end

	HB:SetStatusBarColor( r, b, g, a )
	HB.thr:SetPoint( 'TOPRIGHT',   HB.bdr,  x,  y )
	HB.thr:SetPoint( 'BOTTOMLEFT', HB.bdr, -x, -y )
	HB.thr:SetTexture( 'Interface\\AddOns\\pNameplates\\Textures\\threat_'..style )
	
	if ( not HB.thr:IsVisible() ) then HB.thr:Show() end
end

local function DefaultAppearance( P, HB, old )
	if( HB.thr:IsShown() ) then
		HB.thr:Hide()
		HB.scale = 1
		Update_Size( P )
	end

	HB:SetStatusBarColor( old.HB:GetStatusBarColor() )
end

local function ShowOutline( P )
	return C.TargetBorder and UnitExists( 'target' ) and P:GetAlpha() > 0.9
end

local function Update_Main( P )
	local HB, CB, old = P.HB, P.CB, P.old

	if ( not old.CB:IsShown() and CB:IsShown() ) then CB:Hide() end

	SetUnitName( P )
	HB.ico:SetSize( C.RaidIconSize, C.RaidIconSize )

	-- HP Bar Color Filtering via priority
	if     ( C.RaidIconColor and HB.ico:IsShown() )        then SetRaidIconStatus( HB )             -- raid icon
	elseif ( select( 3, old.HB:GetStatusBarColor() ) > 0 ) then DefaultAppearance( P, HB, old )     -- tagged or friendly
	elseif ( C.ThreatEnabled and COMBAT_LOCK )             then Update_Threat( P, HB, old )         -- threat style
	else                                                        DefaultAppearance( P, HB, old ) end -- default

	if ( ShowOutline( P ) )    then HB.tgt:Show() else HB.tgt:Hide() end
	if ( old.ovr:IsShown() )   then HB.ovr:Show() else HB.ovr:Hide() end
	if ( old.bos:IsVisible() ) then HB.lvl:Hide() else HB.lvl:Show() end

	if ( size_update ) then Update_Size( P ) end -- frame size has changed
	if ( text_update ) then Update_Text( P ) end -- text location has changed
	if ( font_update ) then Update_Font( P ) end -- font size has changed
	if ( configure )   then
		Update_Data( P )
		SetUnitHealthText( P )
	end
end

local function SpawnBorder( anchor, edge )
	border = CreateFrame( 'Frame', nil, anchor )
	border:SetPoint( 'TOPLEFT', anchor, 'TOPLEFT', -edge, edge )
	border:SetPoint( 'BOTTOMRIGHT', anchor, 'BOTTOMRIGHT', edge, -edge )
	border:SetBackdrop({ 
		bgFile = nil, 
		edgeFile = bkgTex,
		tile = false, tileSize = 0, edgeSize = 1, 
		insets = { left = edge, right = edge, top = edge, bottom = edge }
	})
	
	return border
end

local function ModPlate( P )
	old_frame, old_name = P:GetChildren()
	
	old = { }
	old.nam = old_name:GetRegions()
	old.HB, old.CB = old_frame:GetChildren()
	old.thr, old.bdr, old.ovr, old.lvl, old.bos, old.ico, old.dgn = old_frame:GetRegions()
	old.CB.bar, old.CB.bdr, old.CB.shl, old.CB.ico, old.CB.spl, old.CB.shw = old.CB:GetRegions()

	old.HB:Hide()
	old.nam:Hide()
	old.bdr:Hide()
	old.lvl:SetWidth( 1 )
	old.ovr:SetTexture( 0, 0, 0, 0 )
	old.thr:SetTexture( 0, 0, 0, 0 )
	old.dgn:SetTexture( 0, 0, 0, 0 )
	old.CB:SetBackdrop( nil )
	old.CB.bar:SetTexture( 0, 0, 0, 0 )
	old.CB.bdr:SetTexture( 0, 0, 0, 0 )
    old.CB.shl:SetTexture( 0, 0, 0, 0 )
	old.CB.shw:SetTexture( 0, 0, 0, 0 )
	
	HB = CreateFrame( 'StatusBar', nil, P )
	HB:SetAttribute( 'name', 'PNPHealthbar' )
	HB:SetPoint( 'BOTTOM', P, 'BOTTOM', 0, 5 )
	HB:SetStatusBarTexture( barTex )
    HB:SetBackdrop({
        bgFile = bkgTex,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    HB:SetBackdropColor( 0, 0, 0, 0.6 )
	
	bdr = SpawnBorder( HB, 1 )
	bdr:SetBackdropBorderColor( 0, 0, 0, 0.6 )
	
	tgt = SpawnBorder( HB, 2 )
	tgt:SetBackdropBorderColor( 1, 1, 1, 1 )
	tgt:SetFrameLevel( 3 )

	thr = HB:CreateTexture( nil, 'Texture' )
	thr:SetPoint( 'TOPRIGHT',   bdr,  1,  2 )
    thr:SetPoint( 'BOTTOMLEFT', bdr, -1, -2 )
    thr:SetDrawLayer( 'BORDER' )
	
	ovr = HB:CreateTexture( nil, 'Texture' )
	ovr:SetDrawLayer( "OVERLAY", 7 )
    ovr:SetTexture( 1, 1, 1, 0.25 )
	ovr:SetPoint( "TOPLEFT", HB, "TOPLEFT", 0, 0 )
	ovr:SetPoint( "BOTTOMRIGHT", HB, "BOTTOMRIGHT", 0, 0 )
	ovr:Hide()

	nam = HB:CreateFontString( nil )
	nam:SetWordWrap( false )
	nam:SetPoint( 'BOTTOM', HB, 'TOP', 0, 3 ) 
	nam:SetFont( C.FontType_Name, C.FontSize_Name, 'THINOUTLINE' )

	old.nam:SetWordWrap( false )
	old.nam:SetFont( C.FontType_Name, C.FontSize_Name, 'THINOUTLINE' )

	lvl = HB:CreateFontString( nil )
	lvl:SetPoint( 'LEFT', HB, 'RIGHT', 3, 0 ) 
	lvl:SetFont( C.FontType_Level, C.FontSize_Level, 'THINOUTLINE' )

	old.bos:SetPoint( lvl:GetPoint() )

	old.ico:SetPoint( 'RIGHT', HB, 'LEFT', -3, 0 )
	old.ico:SetSize( C.RaidIconSize, C.RaidIconSize )

	hp  = HB:CreateFontString( nil )
	hp:SetPoint( 'CENTER', HB, 'CENTER', 0, 0 )
	hp:SetFont( C.FontType_Perc, C.FontSize_Perc, 'THINOUTLINE' )

	HB.bdr = bdr
	HB.tgt = tgt
	HB.thr = thr
	HB.ovr = ovr
	HB.nam = nam
	HB.lvl = lvl
	HB.ico = old.ico
	HB.hp  = hp
	HB.scale = 1

	HB:HookScript(     'OnShow',          function( self )           Health_OnShow( P )             end )
	old.HB:HookScript( 'OnValueChanged',  function( self, value )    Health_OnValue( P, value )     end )
	old.HB:HookScript( 'OnMinMaxChanged', function( self, min, max ) Health_OnMinMax( P, min, max ) end )
	
	CB = CreateFrame( 'StatusBar', nil, P )
	CB:SetStatusBarTexture( barTex )
    CB:SetBackdrop({
        bgFile = bkgTex,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    CB:SetBackdropColor( 0, 0, 0, 0.6 )
	
	CB_border = SpawnBorder( CB, 1 )
	CB_border:SetBackdropBorderColor( 0, 0, 0, 0.6 )

	CB.ico = old.CB.ico
	CB.ico:SetParent( CB )
	CB.ico:ClearAllPoints()
	CB.ico:SetPoint( 'TOPLEFT', CB, 'TOPRIGHT', 6, 0 )
	CB.ico:SetTexCoord( 0.1, 0.1, 0.1, 0.9, 0.9, 0.1, 0.9, 0.9 )

	-- ico_border = SpawnBorder( CB.ico, 1 )
	-- ico_border:SetBackdropBorderColor( 0, 0, 0, 0.6 )

	CB.spl = old.CB.spl
	CB.spl:SetParent( CB )
	CB.spl:ClearAllPoints()
	CB.spl:SetPoint( 'LEFT', CB, 'LEFT', 1, 0 )
	CB.spl:SetFont( C.FontType_Cast, C.FontSize_Cast, 'THINOUTLINE' )

	CB.tim = CB:CreateFontString( nil, 'HIGH' )
	CB.tim:SetPoint( 'RIGHT', CB, 'RIGHT', -1, 0 )
	CB.tim:SetFont( C.FontType_Cast, C.FontSize_Cast, 'THINOUTLINE' )

	if ( old.CB:IsShown() ) then CB:Show() else CB:Hide() end

	old.CB:HookScript( 'OnShow',          function( self )           Castbar_OnShow( P )             end )
	old.CB:HookScript( 'OnHide',          function( self )           Castbar_OnHide( P )             end )
	old.CB:HookScript( 'OnValueChanged',  function( self, value )    Castbar_OnValue( P, value )     end )
	old.CB:HookScript( 'OnMinMaxChanged', function( self, min, max ) Castbar_OnMinMax( P, min, max ) end )

	P.old = old
	P.HB = HB
	P.CB = CB
	P.mod = true

	Health_OnShow( P )

	Update_Main( P )
	Update_Data( P )
	Update_Size( P )
	Update_Font( P )
	Update_Text( P )
	
	P:HookScript( 'OnShow', function( self ) Update_Data( self ) Update_Main( self ) end )
	P:HookScript( 'OnHide', function( self ) Update_Data( self ) Update_Main( self ) end )
	P:HookScript( 'OnUpdate', function()
		if ( P:IsVisible() ) then                                    Update_Main( P ) end
		if ( not P.checksum or P.checksum ~= GetCheckSum( P ) ) then Update_Data( P ) end
	end)
	P:HookScript( 'OnEvent', function( self, event )
		if ( event == 'RAID_TARGET_UPDATE' ) then
			SetRaidIconStatus( self.HB )
		end
	end)
	
	P:RegisterEvent( 'RAID_TARGET_UPDATE' )
end

--[[ ---------------------- ]]--
--[[ Addon Initialization 	]]--
--[[ ---------------------- ]]--

local function Initialize_Defaults()
	Default = { }

	Default.NO_DELETE = 1 		-- deletion prevention
	Default.VERSION   = VERSION -- version check

	-- Fonts and Sizing
	Default.FontSize_Perc  = 12
	Default.FontSize_Name  = 10
	Default.FontSize_Cast  = 10
	Default.FontSize_Level = 12
	Default.FontType_Perc  = 'Fonts\\ARIALN.ttf'
	Default.FontType_Name  = 'Fonts\\ARIALN.ttf'
	Default.FontType_Cast  = 'Fonts\\ARIALN.ttf'
	Default.FontType_Level = 'Fonts\\ARIALN.ttf'
	Default.hpw            = 110
	Default.hph            = 14
	Default.cbw            = 110
	Default.cbh            = 10
	Default.RaidIconSize   = 24
	Default.CBIconSize     = 10
	Default.hp_string      = 'hp_value | hp_percent%'

	-- Boolean Variables
	Default.Abbreviate     = true
	Default.ShowPercent    = true
	Default.ShowWhenMax    = true
	Default.ShowHPValue    = true
	Default.ShowCBText     = true
	Default.TargetBorder   = true
	Default.ThreatEnabled  = true
	Default.DPSHealerMode  = true
	Default.RaidIconColor  = true
	Default.RecolorTagged  = true
	Default.HBCBWidthSync  = true
	
	-- Text Element Positions
	Default.Location_Raid  = 'left'
	Default.Location_Perc  = 'center'
	Default.Location_Name  = 'top'
	Default.Location_Level = 'right'
end

local function pNameplates_Initialize()
	Initialize_Defaults()

	realm = GetRealmName()
 	player = UnitName( 'player' )
 	SetCVar( 'ShowClassColorInNameplate', 1 )

 	-- grandfather in old settings
 	if ( config and config[realm] ) then
 		-- if old settings exist, copy settings to the new format and delete old version
 		if ( config[realm][player] and type( config[realm][player] ) == 'table' ) then
 			config[player..'-'..realm] = Profile_Copy( config[realm][player] )
 			config[realm][player] = nil
 		end

 		-- if realm no longer has old settings stored, delete it
 		if ( tsize( config[realm] ) == 0 ) then
 			config[realm] = nil
 		end
 	end

	if ( not config ) 				             then config = { }                                           end
	if ( not config['profiles'] ) 		         then config['profiles'] = { }                               end
	if ( not config['profiles'][realm] ) 		 then config['profiles'][realm] = { }                        end
	if ( not config['profiles'][realm][player] ) then config['profiles'][realm][player] = player..'-'..realm end

	-- update defaults for new users and new versions
	if ( not config['Default'] or config['Default'].VERSION ~= Default.VERSION ) then
		config['Default'] = Profile_Copy( Default, true )
	end

	PROFILE_STUB = config['profiles'][realm][player]

	C = { }

	UpdateProfileItems()
	Profile_Load( PROFILE_STUB )

	addon_loaded = true
end

function pNameplates_OnLoad( self )
	self:RegisterEvent( 'ADDON_LOADED' )
	self:RegisterEvent( 'PLAYER_LOGOUT' )
	self:RegisterEvent( 'PLAYER_REGEN_ENABLED' )
	self:RegisterEvent( 'PLAYER_REGEN_DISABLED' )
end

function pNameplates_OnEvent( self, event, ... )
	if ( event == 'ADDON_LOADED' ) then
		if ( select( 1, ... ) == 'pNameplates' ) then
			pNameplates_Initialize()
		end
	elseif ( event == 'PLAYER_LOGOUT' ) then
		-- Config_SaveProfile()
	else
		COMBAT_LOCK = ( event == 'PLAYER_REGEN_DISABLED' )
		collectgarbage()
	end
end

local total = 0 -- World Frame child counter
function pNameplates_OnUpdate( self, elapsed )
	if ( not addon_loaded ) then return end

	local N = WorldFrame:GetNumChildren()
	
	if ( N ~= total or configure ) then
		total = N
		
		for i = 1, N do
			local P = select( i, WorldFrame:GetChildren() )
			if ( P:GetName() and P:GetName():match( 'NamePlate' ) ) then
		  		if ( not P.mod ) then ModPlate( P ) end
		  		if ( configure ) then Update_Main( P ) end
		  	end
		end

		if ( configure ) then
			configure = false
			size_update = false
			font_update = false
			text_update = false
		end
	end
end

print( ACCENT_LABEL..' '..ColorString( '(v'..VERSION..')' )..' is loaded: |cFFFFFF55/pnp|r for help.' )