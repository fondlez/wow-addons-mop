--[[ ---------------------- ]]--
--[[ Globals            	]]--
--[[ ---------------------- ]]--

VERSION = GetAddOnMetadata( 'pNameplates', 'Version' )
DEBUG   = false
PROFILE_STUB = nil
configure = false

ColorString = function( str ) return '|cFF48D1CC'..str..'|r' end

--[[ ---------------------- ]]--
--[[ Strings            	]]--
--[[ ---------------------- ]]--

pNameplatesConfig_HEADER  = 'pNameplates'
pNameplatesConfig_VERSION = ColorString( 'v'..VERSION )
pNameplatesConfig_SUBTEXT = 'Lightweight Nameplate Addon'

--[[ ---------------------- ]]--
--[[ Local Data            	]]--
--[[ ---------------------- ]]--

local ITEM_LABEL = {
	hpw            = 'Healthbar Width',
	hph            = 'Healthbar Height',
	cbw            = 'Castbar Width',
	cbh            = 'Castbar Height',
	Abbreviate     = 'Abbreviate Name',
	TargetBorder   = 'Target Border',
	ThreatEnabled  = 'Threat Enabled',
	RaidIconColor  = 'Raid Icon Colors',
	RaidIconSize   = 'Raid Icon Size',
	CBIconSize     = 'Spell Icon Size',
	ShowPercent    = 'Show Health Text',
	ShowHPValue    = 'Show HP Value',
	ShowWhenMax    = 'Show Health at 100%',
	ShowCBText     = 'Enable',
	HBCBWidthSync  = 'Sync Width with Health',
	FontSize       = 'Font Size'
}

local MENU_LABELS = {
	DPSHealerMode = {
		[0] = 'Tank',
		[1] = 'DPS/Healer'
	},
	FontType = {
		['Fonts\\ARIALN.ttf']   = 'Arial Narrow',
		['Fonts\\FRIZQT__.ttf'] = 'Friz Quat',
		['Fonts\\MORPHEUS.ttf'] = 'Morpheus',
		['Fonts\\skurri.ttf']   = 'Skurri'
	},
	Location = {
		top    = 'Top',
		left   = 'Left',
		right  = 'Right',
		center = 'Center'
	}
}

local OPTIONS = { }

--[[ ---------------------- ]]--
--[[ Core  		          	]]--
--[[ ---------------------- ]]--

function SetOption( option, value )
	C[option] = value
	config[PROFILE_STUB][option] = value
	if ( DEBUG ) then print( 'SetOption:   '..option..'   '..tostring( C[option] ) ) end
end

function SetProfile( profile )
	for option, value in pairs( profile ) do
		SetOption( option, value )
	end
end

function RestoreDefaults()
	SetProfile( Default )
end

function pNameplatesCheckButton_OnClick( self )
	local checked = self:GetChecked() and true or false
	SetOption( self.option, checked )

	if ( self.option == 'HBCBWidthSync' and HBCBWidthSync ) then
		pNameplatesSlider_Update( _G['hpw'] )
	end

	configure = true
	size_update = true
end

function pNameplatesCheckButton_Update( self, value )
	self:SetChecked( value )
end

function pNameplatesSlider_Update( self, value )
	if ( not value ) then value = self:GetValue() end
	value = math.floor( value )

	if ( C.HBCBWidthSync ) then
		if ( self.option == 'hpw' ) then
			_G['cbw']:SetValue( value )
			SetOption( 'cbw', value )
		elseif ( self.option == 'cbw' ) then
			_G['hpw']:SetValue( value )
			SetOption( 'hpw', value )
		end
	end

	self:SetValue( value )
	SetOption( self.option, value )

	configure = true
	font_update = true
	size_update = true
	pNameplates_OnUpdate()
end

function pNameplatesDropDown_Update( item, value )
	if ( type ( value ) == 'boolean' ) then
		value = value and 1 or 0
	end

	local menu = item.option
	if     ( menu:match('FontType') ) then menu = 'FontType' 
	elseif ( menu:match('Location') ) then menu = 'Location'
	end

	UIDropDownMenu_SetSelectedValue( item, value )
	UIDropDownMenu_SetText( item, MENU_LABELS[menu][value] )
end

function TextLocationMenu_OnClick( info )
	SetOption( info.owner.option, info.value )
	UIDropDownMenu_SetSelectedValue( info.owner, info.value )

	configure = true
	text_update = true
	pNameplates_OnUpdate()
end

function TextLocationMenu_OnLoad( self )
	local info

	info       = { }
	info.text  = 'Left'
	info.value = 'left'
	info.owner = self
	info.func  = TextLocationMenu_OnClick
	info.isNotRadio = true
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'Right'
	info.value = 'right'
	info.owner = self
	info.func  = TextLocationMenu_OnClick
	info.isNotRadio = true
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'Top'
	info.value = 'top'
	info.owner = self
	info.func  = TextLocationMenu_OnClick
	info.isNotRadio = true
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'Center'
	info.value = 'center'
	info.owner = self
	info.func  = TextLocationMenu_OnClick
	info.isNotRadio = true
	UIDropDownMenu_AddButton( info )

	UIDropDownMenu_SetWidth( self, 85 )
	_G['pNameplatesConfigText_'..self.option]:SetPoint( 'BOTTOMLEFT', self, 'TOPLEFT', 15, 3 )
end

function FontSelectMenu_OnClick( info )
	SetOption( info.owner.option, info.value )
	UIDropDownMenu_SetSelectedValue( info.owner, info.value )

	configure = true
	font_update = true
	pNameplates_OnUpdate()
end

function FontSelectMenu_OnLoad( self )
	local info = { }

	info       = { }
	info.text  = 'Arial Narrow'
	info.value = 'Fonts\\ARIALN.ttf'
	info.owner = self
	info.func  = FontSelectMenu_OnClick
	info.isNotRadio = true
	info.fontObject = CreateFont( 'ARIALN' )
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'Friz Quat'
	info.value = 'Fonts\\FRIZQT__.ttf'
	info.owner = self
	info.func  = FontSelectMenu_OnClick
	info.isNotRadio = true
	info.fontObject = CreateFont( 'ARIALN' )
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'Morpheus'
	info.value = 'Fonts\\MORPHEUS.ttf'
	info.owner = self
	info.func  = FontSelectMenu_OnClick
	info.isNotRadio = true
	info.fontObject = CreateFont( 'MORPHEUS' )
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'Skurri'
	info.value = 'Fonts\\skurri.ttf'
	info.owner = self
	info.func  = FontSelectMenu_OnClick
	info.isNotRadio = true
	info.fontObject = CreateFont( 'skurri' )
	UIDropDownMenu_AddButton( info )

	UIDropDownMenu_SetWidth( self, 85 )
	_G['pNameplatesConfigText_'..self.option]:SetPoint( 'BOTTOMLEFT', self, 'TOPLEFT', 15, 3 )
end

function ThreatSelectMenu_OnClick( info )
	SetOption( info.owner.option, info.value == 1 )
	UIDropDownMenu_SetSelectedValue( info.owner, info.value )
end

function ThreatSelectMenu_OnLoad( self )
	local info

	info       = { }
	info.text  = 'Tank'
	info.value = 0
	info.owner = self
	info.func  = ThreatSelectMenu_OnClick
	info.isNotRadio = true
	UIDropDownMenu_AddButton( info )

	info       = { }
	info.text  = 'DPS/Healer'
	info.value = 1
	info.owner = self
	info.func  = ThreatSelectMenu_OnClick
	info.isNotRadio = true
	UIDropDownMenu_AddButton( info )

	UIDropDownMenu_SetWidth( self, 85 )
	pNameplatesConfigThreatSelectText:SetPoint( 'BOTTOMLEFT', self, 'TOPLEFT', 15, 3 )
end

function Config_SlashHandler( args )
	if ( not args ) then args = false end

	if ( args == 'config' ) then
		InterfaceOptionsFrame_OpenToCategory( pNameplatesConfig )
	elseif ( args == 'help' ) then
		pNameplates_Print( 'Sorry!  Slash Command configuration is '..
			   'currently disabled.  Please use the configuration interface to change options.' )
	else
		if ( DEBUG ) then InterfaceOptionsFrame_OpenToCategory( pNameplatesConfig ) end
		pNameplates_Print( 'SlashCommand|r:  Arguments to  |cFFFFFF55/pnp|r:' )
		print( '  |cFFFFFF55config|r - for configuration options.' )
		print( '  |cFFFFFF55help|r - for additional commands.' )
	end
end

function Config_RegisterItem( item, type, name, ... )
	item.type   = type
	item.option = name

	-- profiles are handled separately
	if ( name == 'Profiles' ) then return end

	if ( not OPTIONS[type] ) then
		OPTIONS[type] = { }
	end

	OPTIONS[type][name] = item

	if ( type == 'slide' ) then
		local min, max, width = ...
		_G[name..'Low']:SetText( tostring( min ) )
		_G[name..'High']:SetText( tostring( max ) )
		item:SetMinMaxValues( min, max )
		item:SetValueStep( 1 )
		item:SetWidth( width and width or 150 )
	end

	local label = name
	if ( label:match( 'FontSize' ) ) then
		label = 'FontSize'
	end

	if ( type == 'slide' or type == 'check' ) then
		_G[name..'Text']:SetText( ITEM_LABEL[label] )
	end
end

function UpdateConfigItems()
	-- check boxes
	if ( OPTIONS['check'] ) then
		for option, item in pairs( OPTIONS['check'] ) do
			if ( DEBUG ) then print( 'Updating:   '..option..'   '..tostring( C[option] ) ) end
			pNameplatesCheckButton_Update( item, C[option] )
		end
	end

	-- sliders
	if ( OPTIONS['slide'] ) then
		for option, item in pairs( OPTIONS['slide'] ) do
			if ( DEBUG ) then print( 'Updating:   '..option..'   '..tostring( C[option] ) ) end
			pNameplatesSlider_Update( item, C[option] )
		end
	end

	-- drop down menus
	if ( OPTIONS['menu'] ) then
		for option, item in pairs( OPTIONS['menu'] ) do
			if ( DEBUG ) then print( 'Updating:   '..option..'   '..tostring( C[option] ) ) end
			pNameplatesDropDown_Update( item, C[option] )
		end
	end

	collectgarbage()
end

--[[ ---------------------- ]]--
--[[ Config Initialization 	]]--
--[[ ---------------------- ]]--

function Config_OnLoad( self )
	SlashCmdList.PNAMEPLATES = Config_SlashHandler
	SLASH_PNAMEPLATES1 = '/pp'
	SLASH_PNAMEPLATES2 = '/pnp'
	SLASH_PNAMEPLATES3 = '/pnameplates'

	-- root config folder
    self.name    = 'pNameplates'
    self.default = RestoreDefaults
    self.refresh = UpdateConfigItems
    InterfaceOptions_AddCategory( self )
    InterfaceAddOnsList_Update()
end