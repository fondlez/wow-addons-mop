--[[ ---------------------- ]]--
--[[ Strings            	]]--
--[[ ---------------------- ]]--

pNameplatesProfile_SUBTEXT     = 'Manage Character Settings Profiles'
pNameplatesProfile_DESC_SELECT = 'Create a new profile or select an existing one.'
pNameplatesProfile_DESC_COPY   = 'Copy the settings of an existing profile to the active profile.'
pNameplatesProfile_DESC_DELETE = 'Delete existing or unused profiles.'

--[[ ---------------------- ]]--
--[[ Core Profile Code		]]--
--[[ ---------------------- ]]--

function UpdateProfileItems()
	if ( DEBUG ) then print( 'update profile items' ) end
	-- update active profile stub
	_G['ActiveProfile']:SetText( PROFILE_STUB )

	-- update drop down displays
	if ( config ~= nil ) then
		UIDropDownMenu_Initialize( _G['pNameplatesProfileExisting'], Existing_OnLoad )
		UIDropDownMenu_Initialize( _G['pNameplatesProfileCopyMenu'], CopyMenu_OnLoad )
		UIDropDownMenu_Initialize( _G['pNameplatesProfileDelete'],   Deletion_OnLoad )
	end

	UIDropDownMenu_SetSelectedValue( _G['pNameplatesProfileExisting'], PROFILE_STUB )
	UIDropDownMenu_SetText(          _G['pNameplatesProfileExisting'], PROFILE_STUB )
	UIDropDownMenu_SetText(          _G['pNameplatesProfileCopyMenu'], '' )
	UIDropDownMenu_SetText(          _G['pNameplatesProfileDelete'],   '' )
end

function Profile_Copy( original, override_default )
	local profile, copy = { }, { }

	if ( type( original ) == 'table' ) then
		profile = original
	else
		profile = config[original]
	end

	for option, value in pairs( profile ) do
		-- do not copy default preservation values unless specified
		if ( override_default or ( option ~= 'NO_DELETE' and option ~= 'VERSION' ) ) then
			copy[option] = value
		end
	end

	collectgarbage()

	return setmetatable( copy, getmetatable( profile ) )
end

function Profile_CopyFrom( profile )
	C = Profile_Copy( config[profile] )
end

function Profile_New( profile )
	config[profile] = Profile_Copy( 'Default' )
	Profile_CopyFrom( profile )
	PROFILE_STUB = profile

	UpdateConfigItems()
	UpdateProfileItems()
end

function Profile_Load( profile )
	if ( not config[PROFILE_STUB] ) then end


	if ( not config[profile] ) then
		Profile_New( profile )
	end

	Profile_CopyFrom( profile )
	PROFILE_STUB = profile

	UpdateConfigItems()
	UpdateProfileItems()
end

function Profile_Save( profile )
	if ( not profile ) then profile = C end

	config[PROFILE_STUB] = Profile_Copy( profile )
	config['profiles'][realm][player] = PROFILE_STUB
end

--[[ ---------------------- ]]--
--[[ Menu Events			]]--
--[[ ---------------------- ]]--

local function Menus_AddNew( profile, owner, func, notCheckable )
	local info = { }
	info.text  = profile
	info.value = profile
	info.owner = owner
	info.func  = func
	info.isNotRadio   = true
	info.notCheckable = notCheckable
	info.fontObject   = CreateFont( 'ARIALN' )

	UIDropDownMenu_AddButton( info )
end

local function Menus_Delete( value )
	UIDropDownMenu_DeleteButton( value )
end

-- menu ids
-- 0 existing
-- 1 copy
-- 2 delete
local function Menus_OnLoad( self, func, notCheckable, id )
	local default_size = tsize( config['Default'] ) - 2 -- to compare and ignore bad profiles

	for profile, _ in pairs( config ) do
		if ( not ( profile:match( '^profiles$' ) or ( config[profile] == nil ) or ( tsize( config[profile] ) < default_size )
				or ( id == 1 and profile:match( '^'..PROFILE_STUB..'$' ) ) or ( id == 2 and profile:match( '^Default$' ) ) ) ) then
			if ( DEBUG ) then print( 'Found profile:   '..profile ) end
			Menus_AddNew( profile, self, func, notCheckable )
		end
	end
end

--[[ ---------------------- ]]--
--[[ Reset Events			]]--
--[[ ---------------------- ]]--

function Reset_OnClick( self )
	Profile_CopyFrom( 'Default' )
	UpdateConfigItems()

	pNameplates_Print( 'Profile  '..PROFILE_STUB..'  has been reset.' )
end

function Reset_OnLoad( self )
	self:SetSize( 150, 25 )
	self:SetText( 'Reset Profile' )
end

--[[ ---------------------- ]]--
--[[ Selection Events		]]--
--[[ ---------------------- ]]--

function Existing_OnClick( info )
	PROFILE_STUB = info.value
	config['profiles'][realm][player] = info.value

	Profile_Load( PROFILE_STUB )
	UpdateProfileItems()
end

function Existing_OnLoad( self )
	Menus_OnLoad( self, Existing_OnClick, false, 0 )

	UIDropDownMenu_SetWidth( self, 140 )
	UIDropDownMenu_SetSelectedValue( self, PROFILE_STUB )
end

function New_Clear( self )
	self:SetText( '' )
	self:ClearFocus()
end

function New_OnEnterPressed( self )
	local profile = self:GetText()

	if ( profile:len() <= 0 ) then
		pNameplates_Print( 'Profile name cannot be blank.' )
		return
	end

	Profile_New( profile )
	New_Clear( self )

	if ( DEBUG ) then print( 'new profile: '..profile ) end
end

function New_OnLoad( self )
	self:SetAutoFocus( false )
	self:SetSize( 143, 25 )

	New_Clear( self )
end

--[[ ---------------------- ]]--
--[[ Copying Events 		]]--
--[[ ---------------------- ]]--

function CopyMenu_OnClick( info )
	local profile = info.value

	config[PROFILE_STUB] = Profile_Copy( profile )
	Profile_CopyFrom( profile )

	UpdateConfigItems()
end

function CopyMenu_OnLoad( self )
	Menus_OnLoad( self, CopyMenu_OnClick, true, 1 )

	UIDropDownMenu_SetWidth( self, 140 )
	UIDropDownMenu_SetText( self, '' )
end

--[[ ---------------------- ]]--
--[[ Deletion Events		]]--
--[[ ---------------------- ]]--

function Deletion_OnClick( info )
	local profile = info.value

	if ( profile:match( '^Default$' ) ) then
		pNameplates_Print( 'Cannot delete Default profile.' )
		return
	end

	if ( DEBUG ) then print( 'delete: '..info.value ) end

	config[profile] = nil

	if ( not config[PROFILE_STUB] ) then
		Profile_Load( 'Default' )
	end

	UpdateProfileItems()
	-- UpdateConfigItems()
end

function Deletion_OnLoad( self )
	Menus_OnLoad( self, Deletion_OnClick, true, 2 )

	UIDropDownMenu_SetWidth( self, 140 )
	UIDropDownMenu_SetText( self, '' )
end

--[[ ---------------------- ]]--
--[[ Profile Initialization ]]--
--[[ ---------------------- ]]--

function Profile_OnLoad( self )
	-- profile sub-folder
    self.name    = 'Profiles'
    self.refresh = UpdateProfileItems
    self.parent  = 'pNameplates'
    InterfaceOptions_AddCategory( self )
    InterfaceAddOnsList_Update()
end