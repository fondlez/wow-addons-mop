USING POKEDEX - TL;DR VERSION

The games Key Binding UI will contain a section for Pokedex. The only two commands you'll probably want or need to keybind are Toggle Mount and Summon Companion. Pokedex configuration can be reached through the games addons menu or by typing /pd.



NOTE FOR USERS UPGRADING FROM A VERSION BEFORE 4.0 

In order to support things like Druid forms and the Worgen racial mount, we had to make significant changes to the Toggle Mount command and as a result any keybinding you had set for Toggle Mount will have been lost and need to be reset. Also, while the /pd ToggleMount command still exists, it should not used as it does not support the new features. Instead, any macros should replace "/pd ToggleMount" with "/click PokedexToggleMountButton".



ADDON DESCRIPTION

Pokedex allows random summoning of mounts and companions using preference values set by user to influence selection. Pokedex will summon appropriate mount based on what the current location supports. Pokedex can also randomly set character's title using the same basic ranking system.

The chance of a particular item (mount, companion or title) being selected is equal to the rank you have assinged to it divided by the total of the ranks for all other elligible items. Put another way, each point of ranking is one ticket to the raffle drawing to see which mount is selected. If all items are still set to the default value, then they all have an equal chance of being selected. An item which you have assigned a value of 0 will never be selected.


ADDITIONAL FEATURES

The New Hotness - The idea behind this feature is that your most recently acquired pet/mount/title is something you're probably excited about and what to see more often than the rest of your collection. Or maybe you want to flaunt it in front of the all the people who are still trying to get, for example, their Sinister Squashling. When dealing with large numbers of pets or mounts, even setting it to ten will not cause it to show up very often. So rather than make you downrank every other item, the hotness feature acts as a way to get that one pet out more often. If there is a hot pet, we'll first do a percentile roll against the heat of hot item. If the heat is set to 50, then 50 percent of the time we would summon that hot pet. The other 50 percent of the time, we'll do the usual random selection out of the weighted pet pool.

Safe Dismount - This feature is disabled by default but can be turned on in Pokedex's options ui. This feature allows you to keep as a default behavior that of having the Auto Dismount in Flight option turned off, so that accidently trying to cast a spell in flight won't send you plummeting to your death, but allows you to choose override scenarios where you do want actions to dismount you automatically so that they can be executed.  The scenarios you can opt into are 1) when you are in combat, 2) targeting something attackable or 3) attempting to gather a resource via mining, herbalism or skinning.

Random Titles - You can also rank titles the way you do pets and mounts and have Pokedex periodically change your title.

Auto summon pet - You can have Pokedex summon a non-combat pet, if you don't already have one out, everytime you dismount or change zone.

Ghost Wolf and Druid forms support - Pokedex supports using Druid forms and the Shaman Ghost Wolf forms in the appropriate situations as part of the Toggle Mount command.

autocast Water Walking when mounting - An option exists (off by default) for shamans to cast Water Walking as they summon a mount with the Toggle Mount command. This way the buff is already in place when they encounter water so they don't have to dismount, buff and then remount (all while wondering why Death Knights get to cast Path of Frost while mounted).

autocast Horn of Winter when mounting - For Death Knights, Pokedex can cast Horn of Winter whenever you mount. This is useful for keeping the buff up while questing or resource gathering (e.g. mining).



COMMANDS

Pokedex provides a number of commands that can be executed from the chat command, placed inside a macro or (most useful) called through a keybinding. A section for Pokedex is added to the games Key Bindings UI under the Game Menu.  Chances are the only two keybinds you'll want or need are for Toggle Mount and Summon Companion.

This is the full list of commands that can be used with Pokedex.I personally bind Toggle Mount to H (for horse of course) and SummonOtherMount to both Alt-H and Ctrl-H for example.

/pd     or /pokedex                 - brings up the options UI 

/click PokedexToggleMountButton     - calls SummonMount or DismissMount depending on whether you're currently mounted; also supports forms and useful mount related spell casts
/pd dm  or /pd DismissMount         - dismiss current mount, will also exit a vehicle
/pd sm  or /pd SummonMount          - summon random mount
/pd snm or /pd SummonNextMount      - summon next mount in collection based on current mount
/pd som or /pd SummonOtherMount     - This command used to flip the result of our test for "is this a zone we can fly in" and was useful for when a blizz bug caused us to think they'd let us summon a flying mount in a ground only zone and you'd just get an error. It will now first just try to summon from the pool of mounts that we know work in all areas (like Gryphons, Wind Riders, etc). 

/pd tc  or /pd ToggleCompanion      - calls SummonCompanion of DismissCompanion depending on whether you currently have one out 
/pd dc  or /pd DismissCompanion     - dismiss current companion
/pd sc  or /pd SummonCompanion      - summon random companion
/pd snc or /pd SummonNextCompanion  - will summon next companion in collection based on current companion 

/pd ct  or /pd ChangeTitle          - randomly change title 

/pd Vendor      - will summon a mount or companion with vendor capabilities (Traveler's Tundra Mammoth, Argent Squire or Argent Gruntling) 
