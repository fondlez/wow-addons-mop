local L = LibStub("AceLocale-3.0"):NewLocale("Pokedex", "enUS", true)

-- Keybinding
L["Pokedex"] = true
L["Summon Mount"] = true
L["Dismiss Mount"] = true
L["Summon Next Mount"] = true
L["Summon Other Mount"] = true
L["Toggle Mount"] = true
L["Summon Companion"] = true
L["Dismiss Companion"] = true
L["Toggle Companion"] = true
L["Summon Next Companion"] = true
L["Summon Vendor"] = true
L["Change Title"] = true

-- Chat commands
L["pokedex"] = true
L["pd"] = true

-- Announcement channels names
L["personal"] = true
L["party"] = true
L["raid"] = true
L["emote"] = true
L["say"] = true
L["yell"] = true

-- Announcement messages, %s is name of companion or mount
L["%s, I choose you!"] = true
L["lets %s know that they have been chosen."] = true

-- mount types
L["Unidentified Mounts"] = true
L["Unusable Mounts"] = true
L["Reliable Mounts"] = true
L["Flyers"] = true
L["Runners"] = true
L["Walkers"] = true
L["Swimmers"] = true
L["Vashj'ir Seahorses"] = true
L["Qiraji Scarabs"] = true

-- Update messages
L["New mount added: %s"] = true
L["New companion added: %s"] = true
L["New title added: %s"] = true

-- drop down strings for nil cases
L["name not yet available"] = true
L["no mounts available"] = true
L["no companions available"] = true
L["no titles available"] = true
L["no hot mount"] = true
L["no hot companion"] = true
L["no hot title"] = true
L["None"] = true

-- tooltip strings checked for gathering
L["Requires"] = true
L["Mining"] = true
L["Herbalism"] = true
L["Skinnable"] = true

-- zone/subzone names
-- doesn't seem worth it to load all of LibBabble-SubZone just for one place
L["Nespirah"] = true

-- commands and options
L["retry initialization"] = true
L["Mounts"] = true
L["Companions"] = true
L["Titles"] = true
L["Ranks"] = true
L["Hotness"] = true
L["Please see the README.TXT file in the Pokedex addon folder for more information on how to use Pokedex"] = true
L["echoes out test info relevant to current feature in development"] = true
L["echoes out current speed"] = true
L["echoes out zone info"] = true
L["announce"] = true
L["(on|off) let everyone know who *you* choose"] = true
L["channel"] = true
L["channel to announce selection in"] = true
L["summon companion"] = true
L["summons a companion"] = true
L["summon next companion"] = true
L["summons next companion in collection"] = true
L["dismiss companion"] = true
L["dismisses current companion"] = true
L["select companion for ranking"] = true
L["companion whose rank you can set"] = true
L["companion rank"] = true
L["rank of current companion"] = true
L["summon mount"] = true
L["summons a mount"] = true
L["summon next mount"] = true
L["summons next mount in collection"] = true
L["dismiss mount"] = true
L["dismisses current mount"] = true
L["select mount type"] = true
L["select mount for ranking"] = true
L["mount whose rank you can set"] = true
L["mount rank"] = true
L["rank of current mount"] = true
L["set rank override"] = true
L["set a character specific value for rank"] = true
L["override rank"] = true
L["character specific rank"] = true
L["enable hot mount"] = true
L["lets you turn on|off the hot mount subfeatures"] = true
L["enable hot pet"] = true
L["lets you turn on|off the hot pet subfeatures"] = true
L["enable hot title"] = true
L["lets you turn on|off the hot title subfeatures"] = true
L["new hotness"] = true
L["always make newest mount the hot one"] = true
L["always make newest companion the hot one"] = true
L["always make newest title the hot one"] = true
L["select hot companion"] = true
L["companion to become hot one"] = true
L["companion heat"] = true
L["set hotness as a percentage - 100% means the hot pet is the only one that will be chosen"] = true
L["select hot mount"] = true
L["mount to become hot one"] = true
L["mount heat"] = true
L["set hotness as a percentage - 100% means the hot mount is the only one that will be chosen"] = true
L["Auto Summon Companion"] = true
L["Ensures a companion is accompanying you whenever you dismount or enter a new location"] = true
L["Change title on mount"] = true
L["Change title when a mount is summoned"] = true
L["change title"] = true
L["select title for ranking"] = true
L["title whose rank you can set"] = true
L["title rank"] = true
L["rank of current title"] = true
L["select hot title"] = true
L["title to become hot one"] = true
L["title heat"] = true
L["set hotness as a percentage - 100% means the hot title is the only one that will be chosen"] = true
L["toggle companion"] = true
L["toggles a companion"] = true
L["toggle mount"] = true
L["toggles a mount"] = true
L["toggle mount or companion"] = true
L["toggles mount or companion"] = true
L["summon other mount"] = true
L["if summon mount would summon flyer, will summon ground mount and vice versa"] = true
L["summon vendor"] = true
L["summons a mount or companion with vendor capabilities"] = true
L["summon train wrecker"] = true
L["summon a Lil' XT or Landro's Lil' XT to destroy a train set"] = true
L["favor ground mounts"] = true
L["ensures that in areas where flying is not allowed, we will filter out the flying mounts that are still usable (gryphons, wind riders, etc) in favor of ground only mounts (horses, kodos, etc)"] = true
L["sorting method"] = true
L["sort by name"] = true
L["sort by rank (descending)"] = true
L["sort by rank (ascending)"] = true
L["sort by chance of summons"] = true
L["mount format"] = true
L["companion format"] = true
L["title format"] = true
L["name only"] = true
L["rank - name"] = true
L["name (rank)"] = true
L["maximum rank"] = true
L["default rank"] = true

-- MountFeatures
L["Mount Features"] = true
L["This feature does not currently support any spells for this class."] = true

-- UseAsMount
L["Use As Mount"] = true
L["This feature adds mount like forms and spells to the set of mounts Pokedex summons from. They are usually only selected when a normal mount cannot be summoned, such as when you are indoors or moving."] = true
L["Druid forms"] = true
L["allow ToggleMount to select Druid forms when better than a mount or if a mount can't be summoned"] = true
L["allow ToggleMount to make use of Roll in situations when a mount cannot be summoned"] = true
L["allow ToggleMount to make use of Ghost Wolf form in situations when a mount cannot be summoned"] = true
L["allow ToggleMount to make use of Burning Rush in situations when a mount cannot be summoned"] = true

-- CastWithMount
L["Cast With Mount"] = true
L["This feature tries to refresh or apply a useful short term buff while mounting. Mount summoning is not affected by the global cooldown which lets us cast an instant spell along with the mount."] = true
L["cast Horn of Winter while mounting"] = true
L["cast Cenarion Ward while mounting"] = true
L["cast Ice Barrier while mounting"] = true
L["cast Sacred Shield while mounting"] = true
L["remove Disguise"] = true
L["remove Disguise when mounting"] = true
L["cast Water Walking while mounting"] = true
L["Water Walking"] = true
L["if Affliction, cast a Soulburned Unending Breath while mounting to gain water walking"] = true

-- CastWhenFalling 
L["Cast When Falling"] = true
L["This feature tries to use class abilities and items to prevent or reduce damage when falling. Because there is no macro condition to test for falling, this feature only works when you are out of combat."] = true
L["allow ToggleMount to cast Zen Flight when falling"] = true
L["allow ToggleMount to cast Levitate when falling"] = true
L["allow ToggleMount to cast Slow Fall when falling"] = true
L["allow ToggleMount to use Goblin Glider when falling"] = true
L["allow ToggleMount to use Flexweave Underlay when falling"] = true
L["allow ToggleMount to use Golden Glider when falling (Timeless Isle only)"] = true
L["allow ToggleMount to use Snowfall Lager when falling (Storm Peaks only)"] = true
L["Falling Avenger"] = true
L["allow ToggleMount to cast a glyphed Avenging Wrath when falling"] = true
L["allow ToggleMount to cast Hand of Protection when falling"] = true
L["allow ToggleMount to cast Divine Shield when falling"] = true
L["allow ToggleMount to equip (first click) and then use (second click) a legendary dagger when falling"] = true
L["allow ToggleMount to cast a glyphed Path of Frost when falling"] = true

-- SafeDismount
L["Safe Dismount"] = true
L["This feature works with and manages the games Auto Dismount in Flight setting to improve your experience with flying mounts. Auto dismount will be disabled unless in one of the selected conditions."] = true
L["Manage Auto Dismount"] = true
L["Enables Pokedex's management of the Auto Dismount in Flight option"] = true
L["Dismount for Combat"] = true
L["Enables Auto Dismount when in combat"] = true
L["Dismount to Attack"] = true
L["Enables Auto Dismount when targeting something attackable"] = true
L["Dismount for Gathering"] = true
L["Enables Auto Dismount when gathering a resource with mining, herbalism or skinning"] = true

-- ERRORS
L["ERROR: Pokedex failed to initialize correctly. This is usually caused when WoW has invalidated its cache and hasn't finished rebuilding it. Please try this action again later."] = true
L["ERROR: only one of Total Ranks and Summonable List was zero"] = true
L["ERROR: category selected that appears to have no mounts"] = true
L["ERROR: You have no summonable mounts."] = true
L["ERROR: mount name not available"] = true
L["ERROR: You have no summonable companions."] = true
L["ERROR: companion name not available"] = true
L["ERROR: You don't have any titles."] = true
L["ERROR: title name not available"] = true
L["ERROR: selection error"] = true
L["ERROR: type error"] = true
L["ERROR: You cannot summon %s in this area"] = true
L["ERROR: You have no mounts or pets with vendor capabilities"] = true
L["ERROR: unrecognized mount %s %s. Please submit a bug for this error."] = true
L["This function has been deprecated; please see README.txt for more information about the change to ToggleMount"] = true
L["ERROR: value must be a positive integer"] = true
L["ERROR: maximum rank cannot be less than the default rank"] = true
L["ERROR: default rank cannot be greater than the maximum rank"] = true