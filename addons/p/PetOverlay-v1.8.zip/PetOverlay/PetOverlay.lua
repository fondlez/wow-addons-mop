--PetOverlay v1.8

--v1.8
-- Fixed a possible taint issue
-- Cleaned up code
--v1.7
-- Bumped TOC for wow 5.0.5
--v1.6
-- Bumped TOC for wow 4.3
--v1.5.3
-- Bumped TOC
-- Changed GetSpellName -> GetSpellBookItemName
--v1.5.2
-- Bumped TOC for 3.3.0
--v1.5.1
-- Added a list of action buttons that use a pet macro and only updates those buttons (instead of all of them)
--v1.4
-- Added support for macro modifiers with the #pet command
--v1.3
-- Added support for nUI bars and bartender4
-- Updated toc for patch 3.2
--v1.2
-- Now utilizes WoW API for autocast overlay
--v1.1
-- Modified texture system to work on any button
--v1.0
-- Original macro code by Xelron @ Feathermoon ( http://forums.worldofwarcraft.com/thread.html?topicId=10971909982&postId=109708938639 )
-- Fixed and converted to addon by Cybermind @ Stormrage
-- Sparkle code (to replace non-existent autocast overlay) from VendorBait by Tekkub @ http://tekkub.net/addons/VendorBait


-- our global frame
PetOverlay_Frame = nil


-- list of action buttons that contain pet macros
local pet_macro_list = {}

local VERSION = GetAddOnMetadata("PetOverlay", "Version")

-- PetOverlay_OnLoad
--
-- initial function called
--
-- self:	parent frame for addon
function PetOverlay_OnLoad(self)
	-- save our frame
	PetOverlay_Frame = self
	
	-- register an event handler
	self:SetScript("OnEvent", PetOverlay_EventHandler)
	self:RegisterEvent("PET_BAR_UPDATE")

	-- register a hook for the action button update function
	hooksecurefunc("ActionButton_Update", PetOverlay_ActionButton_Update)

	-- register chat command
	SLASH_PETOVERLAY1 = "/petol"
	SlashCmdList["PETOVERLAY"] = PetOverlay_Slash

	DEFAULT_CHAT_FRAME:AddMessage("PetOverlay v"..VERSION.." initialized! Type /petol for help", 0.66, 0.1, 0.1, 2385, 5)
end


-- PetOverlay_Slash
--
-- slash command handler
function PetOverlay_Slash(s)
	DEFAULT_CHAT_FRAME:AddMessage("PetOverlay help:", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("To use, include the following in your macro:", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("  #pet skillname", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("Where 'skillname' is the name of a skill, such as", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("  #pet Call of the Wild", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("The #pet command can now accept macro modifiers like [mod:shift]", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("This will add an autocast overlay showing you the status", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("of the 'Call of the Wild' skill. To make a macro act like", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("a normal pet skill button, be sure to include a", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("/petautocasttoggle command on right click, such as:", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage(" ", 0, 0, 0, 0, 15)
	DEFAULT_CHAT_FRAME:AddMessage("  #showtooltip Call of the Wild", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("  #pet Call of the Wild", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("  /petautocasttoggle [button:2] Call of the Wild", 0.9, 0.9, 0.9, 2385, 15)
	DEFAULT_CHAT_FRAME:AddMessage("  /cast [nobutton:2] Call of the Wild", 0.9, 0.9, 0.9, 2385, 15)
end


-- PetOverlay_EventHandler
--
-- called when an event happens
function PetOverlay_EventHandler(self, event)
	if (event == "PET_BAR_UPDATE") then
		local button
		for i,v in pairs(pet_macro_list) do
			if (v) then
				button = _G[i]
				PetOverlay_ActionButton_Update(button)
			end
		end		
	end
end

-- PetOverlay_ActionButton_Update
--
-- called after ActionButton_Update, this is where we show/hide the overlays
--
-- this should now work for any button that uses the default ActionButton_Update function
--
-- self:	an individual action button object
function PetOverlay_ActionButton_Update(self)
	local action = self.action
	local actiontype, actioninfo = GetActionInfo(action)

	-- simple flags to decide whether to hide at the end of the function
	local corners_show = 0
	local shine_show = 0

	local buttonname = self:GetName()
	
	-- if this button is a macro
	if (HasAction(action) and actiontype == "macro") then

		-- check for "#pet" line in macro
		local found, _, str = string.find(GetMacroBody(actioninfo), "#pet ([^\n]*)")

		-- if line is found
		if (found) then
			pet_macro_list[buttonname] = true
			
			-- parse modifiers for spell name
			local parseString = SecureCmdOptionParse(str)
			
			-- get allowed/enabled status of autocast
			local autocastable, enabled = GetSpellAutocast(PetOverlay_GetPetSpellID(parseString), BOOKTYPE_PET)
			
			-- if allowed to autocast (meaning pet), show corners
			if (autocastable) then
				if (not self.corners) then
					self["corners"] = PetOverlay_GetAutoCastableCorners()
				end
				
				self.corners:SetParent(self)
				self.corners:SetPoint("CENTER", self, "CENTER")
				self.corners:Show()
				
				corners_show = 1
			end

			-- if autocast is enabled, show overlay sparkle textures
			if (enabled) then
				if (not self.shine) then
					self["shine"] = SpellBook_GetAutoCastShine()
				end

				self.shine:SetParent(self)
				self.shine:SetPoint("CENTER", self, "CENTER")
				self.shine:Show()
				AutoCastShine_AutoCastStart(self.shine)

				shine_show = 1
			end
		
		-- #pet line is not found, remove button from stored list
		else
			pet_macro_list[buttonname] = nil
		end
	-- no macro or button found
	else
		pet_macro_list[buttonname] = nil
	end

	-- default hide corners texture
	if (corners_show == 0) then
		if (self.corners) then
			PetOverlay_ReleaseAutoCastableCorners(self.corners)
			self.corners = nil
		end
	end

	-- default hide autocast shine
	if (shine_show == 0) then
		if (self.shine) then
			SpellBook_ReleaseAutoCastShine(self.shine)
			self.shine = nil
		end
	end
end







-- PetOverlay_GetPetSpellID
--
-- helper function to get spell id for a pet spell name
--
-- s:		string corresponding to a pet spell name
-- returns:	spell id
function PetOverlay_GetPetSpellID(s)
	local i = 1

	while true do
		local n = GetSpellBookItemName(i,BOOKTYPE_PET)
		if (s == n) then
			return i
		elseif (not n) then
			return 99
		end

		i = i + 1
	end
end


-- used by PetOverlay_GetAutoCastableCorners and PetOverlay_ReleaseAutoCastableCorners
local PetOverlay_maxCorners = 1
local PetOverlay_cornersGet = {}


-- PetOverlay_GetAutoCastableCorners
--
-- helper function to get a corner texture
-- (modeled after SpellBook_GetAutoCastShine)
--
-- returns:	a "new" corners texture
function PetOverlay_GetAutoCastableCorners()
	local corners = PetOverlay_cornersGet[1]
	
	if (corners) then
		tremove(PetOverlay_cornersGet, 1)
	else
		corners = PetOverlay_Frame:CreateTexture("AutocastableCorners"..PetOverlay_maxCorners, "OVERLAY")
		corners:SetTexture("Interface/Buttons/UI-AutoCastableOverlay")
		corners:SetWidth(58)
		corners:SetHeight(58)
		PetOverlay_maxCorners = PetOverlay_maxCorners + 1
	end
	
	return corners
end


-- PetOverlay_ReleaseAutoCastableCorners
--
-- helper function to release a corner texture
-- (modeled after SpellBook_ReleaseAutoCastShine)
function PetOverlay_ReleaseAutoCastableCorners(corners)
	if (not corners) then
		return
	end
	
	corners:Hide()
	tinsert(PetOverlay_cornersGet, corners)
end

