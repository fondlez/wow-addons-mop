if ( GetLocale() == "frFR" ) then
	PVPSB_LOADED         = "PvP Score Board VERSION chargé."
	PVPSB_GOAL           = "BUT !"
	PVPSB_GOAL_BUTTON    = "But !"
	PVPSB_STOP_BUTTON    = "Arrêter"
	PVPSB_START_BUTTON   = "Démarrer"
	PVPSB_SYNC_DISABLED  = "Synchronisation du tableau des scores désactivée."
	PVPSB_SYNC_ENABLED   = "Synchronisation activée avec PLAYER. (REAL_NAME)"	
	PVPSB_UNKNOWN_PLAYER = "Joueur inconnu"	
	PVPSB_GAME_END       = "Jeu terminé !"	
	PVPSB_GAME_RESUMED   = "C'est parti !"	
	PVPSB_GAME_PAUSED    = "Jeu suspendu"	
end           