--[[
	Version: v1.3.1.3
	Date:    2013-09-11T18:23:24Z
	Author:  lenwe-saralonde lenwe@team-go.org
]]

local PvpScoreBoard_OldChatFrame_OnEvent = nil

-- Initialize variables
function PvpScoreBoard_InitVars()
	PvpScoreBoard_SynchronizeId     = nil
	PvpScoreBoard_Version           = '1.3.1'
	PvpScoreBoard_LastUpdate        = 0
	PvpScoreBoard_AllianceScore     = 0
	PvpScoreBoard_HordeScore        = 0
	PvpScoreBoard_Timer             = 0
	PvpScoreBoard_TextAnimationTime = 0
	PvpScoreBoard_Status            = 'disabled'
end

-- Boostrap
function PvpScoreBoard_OnLoad()
	PvpScoreBoard_InitVars()
	PvpScoreBoard_UpdateFrame:RegisterEvent("VARIABLES_LOADED")
	PvpScoreBoard_UpdateFrame:RegisterEvent("CHAT_MSG_BN_WHISPER")
	PvpScoreBoard_UpdateFrame:RegisterEvent("CHAT_MSG_ADDON")
	PvpScoreBoard_UpdateFrame:RegisterEvent("PARTY_LEADER_CHANGED")
	PvpScoreBoard_UpdateFrame:RegisterEvent("GROUP_ROSTER_UPDATE")

	RegisterAddonMessagePrefix('PvpScoreBoard')

	PvpScoreBoard_UpdateFrame:SetScript("OnEvent",  PvpScoreBoard_OnEvent)
	PvpScoreBoard_UpdateFrame:SetScript("OnUpdate", PvpScoreBoard_OnUpdate)

	if PvpScoreBoard_OldChatFrame_OnEvent == nil then
		PvpScoreBoard_OldChatFrame_OnEvent = ChatFrame_MessageEventHandler
		ChatFrame_MessageEventHandler  = PvpScoreBoard_ChatFrame_OnEvent
	end

	PvpScoreBoard_ButtonGoalAlliance:SetText(PVPSB_GOAL_BUTTON)
	PvpScoreBoard_ButtonGoalHorde:SetText(PVPSB_GOAL_BUTTON)
	PvpScoreBoard_ButtonPause:SetText(PVPSB_START_BUTTON)

	-- PvpScoreBoard_AllianceScoreContainer:SetTextHeight(48)
	-- PvpScoreBoard_HordeScoreContainer:SetTextHeight(48)
end

-- Hide incoming messages from PvpScoreBoard
function PvpScoreBoard_ChatFrame_OnEvent(event, ... )
	local arg1, arg2 = ...

	if (arg2 ~= nil and string.find(arg2, "^PvpScoreBoard ")) then
		return
	end

	PvpScoreBoard_OldChatFrame_OnEvent(event, ...)
end

-- Setup Battle.net synchronization
-- @param string player
function PvpScoreBoard_SetSynchronization(player)
	if ((player == '') or (player == nil)) then
		DEFAULT_CHAT_FRAME:AddMessage(PVPSB_SYNC_DISABLED, 1, 1, 0)
		PvpScoreBoard_SynchronizeId = nil
		return
	end

	player = string.lower(player)

	local i, presenceID, presenceName, battleTag, isBattleTagPresence, toonName, toonID, client, s

	for i = 1, BNGetNumFriends(), 1 do
		presenceID, presenceName, battleTag, isBattleTagPresence, toonName, toonID, client = BNGetFriendInfo(i)

		if (client == BNET_CLIENT_WOW and toonName ~= nil and player == string.lower(toonName)) then
			PvpScoreBoard_SynchronizeId = presenceID
			s = string.gsub(PVPSB_SYNC_ENABLED, "PLAYER", toonName)
			s = string.gsub(s, "REAL_NAME", presenceName)
			DEFAULT_CHAT_FRAME:AddMessage(s, 1, 1, 0)
			return
		end
	end

	DEFAULT_CHAT_FRAME:AddMessage(PVPSB_UNKNOWN_PLAYER,1,0,0)
	PlaySoundFile("Sound\\interface\\Error.wav")
end

-- Return true if the player is group leader
-- @param string player
-- @return boolean
function PvpScoreBoard_IsLeader(player)
	-- Not in a party or a raid
	if PvpScoreBoard_GetGroupMode() == nil then
		return false
	end

	local id

	if player == nil then
		player = "player"
	else
		if PvpScoreBoard_GetGroupMode() == "RAID" then
			for i = 1, 5, 1 do
				if UnitName("party" .. i) == player then
					player = "party" .. i
					break
				end
			end
		else
			for i = 1, 40, 1 do
				if UnitName("raid" .. i) == player then
					player = "raid" .. i
					break
				end
			end
		end
	end

	return UnitIsGroupLeader(player) or UnitIsGroupAssistant(player)
end

-- Return group mode, "RAID" or "PARTY"
-- @return string
function PvpScoreBoard_GetGroupMode()
	if UnitInRaid("player") ~= nil then
		return "RAID"
	elseif UnitInParty("player") ~= nil then
		return "PARTY"
	else
		return nil
	end
end

-- Broadcast status to Battle.net and raid
-- @param string  message
-- @param boolean onlyRaid
function PvpScoreBoard_BroadcastMessage(message, onlyRaid)
	message = message .. ',' ..
	          PvpScoreBoard_AllianceScore .. ',' ..
	          PvpScoreBoard_HordeScore .. ',' ..
	          PvpScoreBoard_Timer .. ',' ..
	          PvpScoreBoard_Status

	-- Send to Battle.net buddy
	if PvpScoreBoard_SynchronizeId ~= nil and onlyRaid ~= true then
		BNSendWhisper(PvpScoreBoard_SynchronizeId, 'PvpScoreBoard ' .. message)
	end

	-- Broadcast to raid
	if onlyRaid ~= false then
		SendAddonMessage("PvpScoreBoard", message, PvpScoreBoard_GetGroupMode())
	end
end

-- Update the timer display
function PvpScoreBoard_UpdateTimer()
	local minutes = math.floor(PvpScoreBoard_Timer / 60)
	local seconds = math.floor(PvpScoreBoard_Timer) % 60

	if minutes > 0 then
		strTime = minutes .. ':' .. string.rep('0', 2 - string.len(seconds)) .. seconds
	else
		strTime = seconds
	end

	PvpScoreBoard_ScoreTimerContainer:SetText(strTime)
end

-- Update the scores display
function PvpScoreBoard_UpdateScore()
	PvpScoreBoard_AllianceScoreContainer:SetText(PvpScoreBoard_AllianceScore)
	PvpScoreBoard_HordeScoreContainer:SetText(PvpScoreBoard_HordeScore)
end

-- Refresh the whole interface
function PvpScoreBoard_RefreshInterface()
	if PvpScoreBoard_Status == 'disabled' then
		PvpScoreBoard_ScoreFrame:Hide()
		PvpScoreBoard_ButtonsFrame:Hide()
	else
		PvpScoreBoard_UpdateTimer()
		PvpScoreBoard_UpdateScore()
		PvpScoreBoard_ScoreFrame:Show()
		if (PvpScoreBoard_IsLeader()) then
			PvpScoreBoard_ButtonsFrame:Show()
			if PvpScoreBoard_Status == 'running' then
				PvpScoreBoard_ButtonPause:SetText(PVPSB_STOP_BUTTON)
				PvpScoreBoard_ButtonGoalAlliance:Enable()
				PvpScoreBoard_ButtonGoalHorde:Enable()
				PvpScoreBoard_ButtonPause:Enable()
			else
				PvpScoreBoard_ButtonPause:SetText(PVPSB_START_BUTTON)
				PvpScoreBoard_ButtonGoalAlliance:Disable()
				PvpScoreBoard_ButtonGoalHorde:Disable()
				if PvpScoreBoard_Status == 'paused' and PvpScoreBoard_Timer > 0 then
					PvpScoreBoard_ButtonPause:Enable()
				else
					PvpScoreBoard_ButtonPause:Disable()
				end
			end
		else
			PvpScoreBoard_ButtonsFrame:Hide()
		end
	end
end

-- Event handler
function PvpScoreBoard_OnEvent(this, event, ...)
	local message, allianceScore, hordeScore, timer, status, m, a, h, t, s
	local arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13 = ...

	-- Init saved variables
	if (event == "VARIABLES_LOADED") then
		DEFAULT_CHAT_FRAME:AddMessage(string.gsub(PVPSB_LOADED, "VERSION", PvpScoreBoard_Version), 1, 1, 1)
		-- Init elements transparency
		PvpScoreBoard_BlinkImage:SetAlpha(0)
		PvpScoreBoard_BlinkGlow:SetAlpha(0)
		return

	-- Raid/party roster changed
	elseif PvpScoreBoard_Status ~= 'disabled' and (event == 'PARTY_LEADER_CHANGED' or event == 'GROUP_ROSTER_UPDATE') then
		-- Player no longer in party or raid: disable
		if PvpScoreBoard_GetGroupMode() == nil then
			PvpScoreBoard_Status = 'disabled'
		end

		PvpScoreBoard_RefreshInterface()
		return

	-- Get message from raid or party
	elseif event == "CHAT_MSG_ADDON" and arg1 == "PvpScoreBoard" and arg4 ~= UnitName('player') and PvpScoreBoard_IsLeader(arg4) and arg3 == PvpScoreBoard_GetGroupMode() then
		for m, a, h, t, s in string.gmatch(arg2, "([a-z_]+)%,(%d+)%,(%d+)%,([^,]+),([a-z_]+)") do
			message = m
			allianceScore = a
			hordeScore = h
			timer = t
			status = s
		end

	-- Get message from Battle.net
	elseif event == "CHAT_MSG_BN_WHISPER" and arg13 == PvpScoreBoard_SynchronizeId then
		for m, a, h, t, s in string.gmatch(arg1, "PvpScoreBoard ([a-z_]+)%,(%d+)%,(%d+)%,([^,]+),([a-z_]+)") do
			message = m
			allianceScore = a
			hordeScore = h
			timer = t
			status = s
		end

	end

	-- Update status
	if message ~= nil and (message ~= 'update' or PvpScoreBoard_Status == 'disabled') then
		PvpScoreBoard_Status = status
		PvpScoreBoard_AllianceScore = tonumber(allianceScore)
		PvpScoreBoard_HordeScore    = tonumber(hordeScore)
		PvpScoreBoard_Timer = tonumber(timer)
		PvpScoreBoard_RefreshInterface()

		-- Forward BNet messages to party and party messages to BNet
		if PvpScoreBoard_IsLeader() and message ~= 'update' then
			PvpScoreBoard_BroadcastMessage(message, event == "CHAT_MSG_BN_WHISPER")
		end
	end

	-- Pause / resume
	if message == 'pause' or message == 'resume' then
		PvpScoreBoard_PauseAnimation()

	-- End game
	elseif message == 'end' then
		PvpScoreBoard_EndAnimation()

	-- Alliance goal
	elseif message == 'goal_alliance' then
		PvpScoreBoard_GoalAnimation('alliance')

	-- Horde goal
	elseif message == 'goal_horde' then
		PvpScoreBoard_GoalAnimation('horde')
	end
end

-- Handle frame update and timer
function PvpScoreBoard_OnUpdate(this, arg1)
	-- Perform text animation
	if PvpScoreBoard_TextAnimationTime > 0 then
		if PvpScoreBoard_TextAnimationTime >= 4.5 then
			PvpScoreBoard_BlinkText:SetTextHeight(30 + math.floor(256 * (PvpScoreBoard_TextAnimationTime - 4.5)))
			PvpScoreBoard_BlinkText:SetAlpha(1 - 2 * (PvpScoreBoard_TextAnimationTime - 4.5))
		elseif PvpScoreBoard_TextAnimationTime >= 1 then
			PvpScoreBoard_BlinkText:SetTextHeight(30)
			PvpScoreBoard_BlinkText:SetAlpha(1)
		else
			PvpScoreBoard_BlinkText:SetAlpha(PvpScoreBoard_TextAnimationTime)
		end

		PvpScoreBoard_TextAnimationTime = math.max(0, PvpScoreBoard_TextAnimationTime - arg1)

		if PvpScoreBoard_TextAnimationTime == 0 then
			PvpScoreBoard_BlinkText:SetAlpha(0)
		end
	end

	-- Send update to everybody every 5 seconds
	if PvpScoreBoard_Status ~= 'disabled' and PvpScoreBoard_IsLeader() then
		PvpScoreBoard_LastUpdate = PvpScoreBoard_LastUpdate + arg1
		if PvpScoreBoard_LastUpdate >= 5 then
			PvpScoreBoard_LastUpdate = 0
			PvpScoreBoard_BroadcastMessage('update')
		end
	end

	if PvpScoreBoard_Status ~= 'running' then
		return
	end

	PvpScoreBoard_Timer = PvpScoreBoard_Timer - arg1

	-- End game
	if PvpScoreBoard_Timer < 0 then
		PvpScoreBoard_Timer = 0
		PvpScoreBoard_Status = 'paused'
		PvpScoreBoard_RefreshInterface()
		PvpScoreBoard_EndAnimation()
		return
	end

	PvpScoreBoard_UpdateTimer()
end

-- Send goal for provided faction
-- @param string faction
function PvpScoreBoard_Goal(faction)
	if not PvpScoreBoard_IsLeader() or PvpScoreBoard_Status ~= 'running' or PvpScoreBoard_Timer <= 0 then
		return
	end

	PvpScoreBoard_Status = 'paused'

	if faction == 'alliance' then
		PvpScoreBoard_AllianceScore = PvpScoreBoard_AllianceScore + 1
		PvpScoreBoard_BroadcastMessage('goal_alliance')
	else
		PvpScoreBoard_HordeScore = PvpScoreBoard_HordeScore + 1
		PvpScoreBoard_BroadcastMessage('goal_horde')
	end

	PvpScoreBoard_RefreshInterface()
	PvpScoreBoard_GoalAnimation(faction)
end

-- Start/stop timer
function PvpScoreBoard_TogglePause()
	if not PvpScoreBoard_IsLeader() then
		return
	end

	if PvpScoreBoard_Status == 'paused' and PvpScoreBoard_Timer > 0 then
		PvpScoreBoard_Status = 'running'
		PvpScoreBoard_BroadcastMessage('resume')
		PvpScoreBoard_PauseAnimation()
		PvpScoreBoard_RefreshInterface()
	elseif PvpScoreBoard_Status == 'running' then
		PvpScoreBoard_Status = 'paused'
		PvpScoreBoard_BroadcastMessage('pause')
		PvpScoreBoard_PauseAnimation()
		PvpScoreBoard_RefreshInterface()
	end
end

-- Perform goal animation for the provided faction
-- @param string faction
function PvpScoreBoard_GoalAnimation(faction)
	local texture, textureGlow, soundFile, soundfile2

	if faction == 'alliance' then
		texture = "Interface\\AddOns\\PvpScoreBoard\\textures\\alliance.blp"
		textureGlow = "Interface\\AddOns\\PvpScoreBoard\\textures\\alliance_glow.blp"
		soundFile = "Sound\\Spells\\CrowdCheerAlliance2.wav"
		soundFile2 = "Sound\\Spells\\pvpflagcaptured.wav"
	else
		texture = "Interface\\AddOns\\PvpScoreBoard\\textures\\horde.blp"
		textureGlow = "Interface\\AddOns\\PvpScoreBoard\\textures\\horde_glow.blp"
		soundFile = "Sound\\Spells\\CrowdCheerHorde2.wav"
		soundFile2 = "Sound\\interface\\PVPFlagCapturedHordeMono.wav"
	end

	PvpScoreBoard_BlinkImage:SetAlpha(0)
	PvpScoreBoard_BlinkGlow:SetAlpha(0)
	PvpScoreBoard_BlinkAnimation:Show()

	PvpScoreBoard_BlinkImage:SetTexture(texture);
	PvpScoreBoard_BlinkGlow:SetTexture(textureGlow);

	local imageAg, glowAg, ia1, ia2, ga1, ga2

	imageAg = PvpScoreBoard_BlinkImage:CreateAnimationGroup("logo_blink")

	ia1 = imageAg:CreateAnimation("Alpha")
	ia1:SetStartDelay(.5)
	ia1:SetChange(1)
	ia1:SetDuration(0)
	ia1:SetSmoothing("OUT")

	ia2 = imageAg:CreateAnimation("Alpha")
	ia2:SetStartDelay(5)
	ia2:SetChange(-1)
	ia2:SetDuration(.5)
	ia2:SetSmoothing("OUT")

	glowAg = PvpScoreBoard_BlinkGlow:CreateAnimationGroup("glow_blink")

	ga1 = glowAg:CreateAnimation("Alpha")
	ga1:SetStartDelay(0)
	ga1:SetChange(1)
	ga1:SetDuration(.5)
	ga1:SetSmoothing("OUT")

	ga2 = glowAg:CreateAnimation("Alpha")
	ga2:SetStartDelay(.5)
	ga2:SetChange(-1)
	ga2:SetDuration(.5)
	ga2:SetSmoothing("OUT")

	imageAg:Play()
	glowAg:Play()
	PvpScoreBoard_TextAnimation(PVPSB_GOAL)
	PvpScoreBoard_TimerBlink()

	PlaySoundFile(soundFile)
	PlaySoundFile(soundFile2)
end

-- Perform text animation
-- @param string text
function PvpScoreBoard_TextAnimation(text)
	local ag, a1, a2

	PvpScoreBoard_BlinkText:SetAlpha(0)
	PvpScoreBoard_BlinkText:SetText(text)
	PvpScoreBoard_BlinkAnimation:Show()

	PvpScoreBoard_TextAnimationTime = 5
end

-- Perform game end animation
function PvpScoreBoard_EndAnimation()
	PvpScoreBoard_TimerBlink()
	PvpScoreBoard_TextAnimation(PVPSB_GAME_END)
	PlaySound("PVPTHROUGHQUEUE")
end

-- Perform pause/resume animation
function PvpScoreBoard_PauseAnimation()
	PvpScoreBoard_TimerBlink()
	if PvpScoreBoard_Status == 'paused' then
		PvpScoreBoard_TextAnimation(PVPSB_GAME_PAUSED)
		PlaySound("RaidBossEmoteWarning")
	elseif PvpScoreBoard_Status == 'running' then
		PvpScoreBoard_TextAnimation(PVPSB_GAME_RESUMED)
		PlaySound("RaidBossEmoteWarning")
	end
end

-- Perform timer blink
function PvpScoreBoard_TimerBlink()
	local ag, a1, a2

	PvpScoreBoard_ScoreBoardGlare:SetAlpha(.35)
	ag = PvpScoreBoard_ScoreBoardGlare:CreateAnimationGroup("timer_blink")

	a1 = ag:CreateAnimation("Alpha")
	a1:SetStartDelay(0)
	a1:SetChange(.65)
	a1:SetDuration(.2)
	a1:SetSmoothing("OUT")

	a2 = ag:CreateAnimation("Alpha")
	a2:SetStartDelay(.2)
	a2:SetChange(-.65)
	a2:SetDuration(.2)
	a2:SetSmoothing("OUT")

	ag:Play()
end

-- /sb 
-- Show interface
SlashCmdList["SB"] = function()
	if not PvpScoreBoard_IsLeader() then
		return
	end

	if PvpScoreBoard_Status == 'disabled' then
		PvpScoreBoard_Status = 'paused'
		PvpScoreBoard_RefreshInterface()
		PvpScoreBoard_BroadcastMessage('enable')
	else
		PvpScoreBoard_Status = 'disabled'
		PvpScoreBoard_RefreshInterface()
		PvpScoreBoard_BroadcastMessage('disable')
	end
end

-- /sbscore <Alliance score> <Horde score>
-- Set score
-- @param string strCmd
SlashCmdList["SBSCORE"] = function(strCmd)
	if not PvpScoreBoard_IsLeader() then
		return
	end

	local a, h
	for a, h in string.gmatch(strCmd, "(%d+)%s+(%d+)") do
		PvpScoreBoard_AllianceScore = a
		PvpScoreBoard_HordeScore    = h
		PvpScoreBoard_UpdateScore()
		PvpScoreBoard_BroadcastMessage('update_score')
		break
	end
end

-- /sbtimer <time>
-- Set timer
-- @param string strCmd
SlashCmdList["SBTIMER"] = function(strCmd)
	if not PvpScoreBoard_IsLeader() then
		return
	end

	local i, t

	t = 0
	for i in string.gmatch(strCmd, "(%d+)") do
		t = t * 60
		t = t + tonumber(i)
	end

	PvpScoreBoard_Timer = t
	PvpScoreBoard_RefreshInterface()
	PvpScoreBoard_BroadcastMessage('update_timer')
end

-- /sbsync
SlashCmdList["SBSYNC"] = PvpScoreBoard_SetSynchronization

-- Slash command aliases
SLASH_SB1 = "/sb"
SLASH_SBSCORE1 = "/sbscore"
SLASH_SBTIMER1 = "/sbtimer"
SLASH_SBSYNC1 = "/sbsync"