local L = LibStub("AceLocale-3.0"):NewLocale("PeaceAndQuiet", "esES", false)

if not L then return end

L["Displaying global channels"] = "Viendo los canales globales" -- Needs review
L["General"] = true -- Needs review
L["Hiding the global channels"] = "Ocultando los canales globales" -- Needs review
L["LocalDefense"] = "Defensa Local" -- Needs review
L["Manage General Channel"] = "Gestionar Canal General" -- Needs review
L["Manage Local Defense Channel"] = "Gestionar Canal Defensa Local" -- Needs review
L["Toggles the display of informational messages."] = "Habilita la visualización de mensajes informativos." -- Needs review
L["Toggles whether the General chat channel is automatically enabled/disabled."] = "Habilita que el canal de chat General es activado/desactivado automáticamente." -- Needs review
L["Toggles whether the Local Defense chat channel is automatically enabled/disabled."] = "Habilita que el canal de chat Defensa Local es activado/desactivado automáticamente." -- Needs review

