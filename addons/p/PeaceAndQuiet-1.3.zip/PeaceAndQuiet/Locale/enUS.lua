local L = LibStub("AceLocale-3.0"):NewLocale("PeaceAndQuiet", "enUS", true, false)

if not L then return end

L["Displaying global channels"] = true
L["General"] = true
L["Hiding the global channels"] = true
L["LocalDefense"] = true
L["Manage General Channel"] = true
L["Manage Local Defense Channel"] = true
L["Toggles the display of informational messages."] = true
L["Toggles whether the General chat channel is automatically enabled/disabled."] = true
L["Toggles whether the Local Defense chat channel is automatically enabled/disabled."] = true
L["Verbose"] = true

