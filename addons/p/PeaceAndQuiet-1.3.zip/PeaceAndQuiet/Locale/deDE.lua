local L = LibStub("AceLocale-3.0"):NewLocale("PeaceAndQuiet", "deDE", false)

if not L then return end

L["Displaying global channels"] = "Zeige globale Channel"
L["General"] = "allgemein"
L["Hiding the global channels"] = "Verstecke globale Channel"
L["LocalDefense"] = "lokaleverteidigung"
L["Manage General Channel"] = "Verwalte Channel Allgemein"
L["Manage Local Defense Channel"] = "Verwalte Channel Lokale Verteidigung"
L["Toggles the display of informational messages."] = "Schaltet Anzeige von Informationsnachrichten um"
L["Toggles whether the General chat channel is automatically enabled/disabled."] = "Schaltet autom. aktivieren/deaktivieren von Channel Allgemein um"
L["Toggles whether the Local Defense chat channel is automatically enabled/disabled."] = "Schaltet autom. aktivieren/deaktivieren von Channel Lokale Verteidigung um"
L["Verbose"] = "Anzeigen von Informationsnachrichten"

