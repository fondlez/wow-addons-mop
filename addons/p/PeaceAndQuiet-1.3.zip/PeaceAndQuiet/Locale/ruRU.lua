local L = LibStub("AceLocale-3.0"):NewLocale("PeaceAndQuiet", "ruRU", false)

if not L then return end


