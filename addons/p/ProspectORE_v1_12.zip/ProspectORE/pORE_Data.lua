
pORE_INFO = {
	version = "1.12",
	welcome = "|cffffff00ProspectORE has Loaded.\nType |cffffffff/ore |cffffff00or |cffffffff/prospect |cffffff00to open the display.",
	commands = "/ore |cffffff00or|cffffffff /prospect |cffffff00followed by:\n |cffffffffreset |cffffff00- Resets all Data to 0\n |cffffffffsync |cffffff00- Displays data sync menu"
}

pORE_SCANNER = {
	isRunning = false,
	atAuctionHouse = false
	}

pORE_TOOLTIPS = {
	alchemy = "Calculates if profits can be increased through the use of Alchemy.",
	enchanting = "Calculates if profits can be increased by Disenchanting.",
	metagems = "Calculates profits uses Meta Gems reguardless of material value.",
	quickscan = "Increases Auction House scanning rate. \n\n WARNING: May cause errors.",
	rawgems = "Calculates profits assuming no gems will be cut.",
	transmute = "Factors in additional Gems from Alchemy Procs."
}

pORE_ITEM_SEARCH_LIST = {
	"Primordial Ruby",
	"River's Heart",
	"Sun's Radiance",
	"Imperial Amethyst",
	"Wild Jade",
	"Vermilion Onyx",
	
	"Primal Diamond",
	
	"Ghost Iron Ore",
	"Kyparite",
	"Black Trillium",
	"White Trillium",
	
	"Spirit Dust",
	"Mysterious Essence"
}

pORE_ITEMS = {
	RARE_RED_GEM = {
		name = "Primordial Ruby",
		cut = {"Bold", "Brilliant", "Delicate", "Flashing", "Precise"},
		price = {
			raw = 0,
			bold = 0,
			brilliant = 0,
			delicate = 0,
			flashing = 0,
			precise = 0
		}
	}
,
	RARE_BLUE_GEM = {
		name = "River's Heart",
		cut = {"Rigid", "Solid", "Sparkling", "Stormy"},
		price = {
			raw = 0,
			rigid = 0,
			solid = 0,
			sparkling = 0,
			stormy = 0
		}
	}
,
	RARE_YELLOW_GEM = {
		name = "Sun's Radiance",
		cut = {"Fractured", "Mystic", "Quick", "Smooth", "Subtle"},
		price = {
			raw = 0,
			fractured = 0,
			mystic = 0,
			quick = 0,
			smooth = 0,
			subtle = 0
		}
	}
,
	RARE_PURPLE_GEM = {
		name = "Imperial Amethyst",
		cut = {"Accurate", "Assassin's", "Defender's", "Etched", "Glinting", "Guardian's", "Mysterious", "Purified", "Retaliating", "Shifting", "Sovereign", "Tense", "Timeless", "Veiled"},
		price = {
			raw = 0,
			accurate = 0,
			assassins = 0,
			defenders = 0,
			etched = 0,
			glinting = 0,
			guardians = 0,
			mysterious = 0,
			purified = 0,
			retaliating = 0,
			shifting = 0,
			sovereign = 0,
			tense = 0,
			timeless = 0,
			veiled = 0
		}
	}
,
	RARE_GREEN_GEM = {
		name = "Wild Jade",
		cut = {"Balanced", "Confounded", "Effulgent", "Energized", "Forceful", "Jagged", "Lightning", "Misty", "Nimble", "Piercing", "Puissant", "Radiant", "Regal", "Sensei's", "Shattered", "Steady", "Turbid", "Vivid", "Zen"},
		price = {
			raw = 0,
			balanced = 0,
			confounded = 0,
			effulgent = 0,
			energized = 0,
			forceful = 0,
			jagged = 0,
			lightning = 0,
			misty = 0,
			nimble = 0,
			piering = 0,
			puissant = 0,
			radiant = 0,
			regal = 0,
			seneis = 0,
			shattered = 0,
			steady = 0,
			turbid = 0,
			vivid = 0,
			zen = 0
		}
	}
,
	RARE_ORANGE_GEM = {
		name = "Vermilion Onyx",
		cut = {"Adept", "Artful", "Champion's", "Crafty", "Deadly", "Deft", "Fierce", "Fine", "Inscribed", "Keen", "Lucent", "Polished", "Potent", "Reckless", "Resolute", "Resplendent", "Skillful", "Splendid", "Stalwart", "Tenuous", "Wicked", "Willful"},
		price = {
			raw = 0,
			adept = 0,
			artful = 0,
			champions = 0,
			crafty = 0,
			deadly = 0,
			deft = 0,
			fierce = 0,
			fine = 0,
			inscribed = 0,
			keen = 0,
			lucent = 0,
			polished = 0,
			potent = 0,
			reckless = 0,
			resolute = 0,
			resplendent = 0,
			skillful = 0,
			splendid = 0,
			stalwart = 0,
			tenuous = 0,
			wicked = 0,
			willful = 0
		}
	}
,
	META_GEM = {
		name = "Primal Diamond",
		cut = {"Agile", "Austere", "Burning", "Destructive", "Effulgent", "Ember", "Enigmatic", "Eternal", "Fleet", "Forlorn", "Impassive", "Powerful", "Reverberating", "Revitalizing"},
		price = {
			raw = 0,
			agile = 0,
			austere = 0,
			burning = 0,
			destructive = 0,
			effulgent = 0,
			ember = 0,
			enigmatic = 0,
			eternal = 0,
			fleet = 0,
			forlorn = 0,
			impassive = 0,
			powerful = 0,
			reverberating = 0,
			revitalizing = 0
		}
	}
,
	ORE_1 = {
		name = "Ghost Iron Ore",
		price = 0
	}
,
	ORE_2 = {
		name = "Kyparite",
		price = 0
	}
,	
	ORE_3 = {
		name = "Black Trillium Ore",
		price = 0
	}
,
	ORE_4 = {
		name = "White Trillium Ore",
		price = 0
	}
,
	ENCHANTING_DUST = {
		name = "Spirit Dust",
		price = 0
	}
,
	ENCHANTING_ESSENCE = {
		name = "Mysterious Essence",
		price = 0
	}
,
	UNCOMMON_RED_GEM = {
		name = "Pandarian Garnet"
	}
,
	UNCOMMON_BLUE_GEM = {
		name = "Lapis Lazuli"
	}
,
	UNCOMMON_YELLOW_GEM = {
		name = "Sunstone"
	}
,
	UNCOMMON_PURPLE_GEM = {
		name = "Roguestone"
	}
,
	UNCOMMON_GREEN_GEM = {
		name = "Alexandrite"
	}
,
	UNCOMMON_ORANGE_GEM = {
		name = "Tiger Opal"
	}
,
	SAVED_STATES = {
		alchemy = true,
		transmute = true,
		forcemeta = true,
		enchant = true,
		rawonly = false,
		fastscan = true
	}
}

pORE_DEFAULT = {
	recommended =
	"     |cffff5555"..pORE_ITEMS.RARE_RED_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cff5555ff"..pORE_ITEMS.RARE_BLUE_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cffffff55"..pORE_ITEMS.RARE_YELLOW_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cffff55ff"..pORE_ITEMS.RARE_PURPLE_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cff33ff33"..pORE_ITEMS.RARE_GREEN_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cffff9933"..pORE_ITEMS.RARE_ORANGE_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cffccffff"..pORE_ITEMS.META_GEM.name.."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n\n"..
	"     |cffccffcc".."Rings & Necklaces".."...".."\n"..
	"          |cffffffff".."Please run calculate first".."\n"
}















