
SLASH_pORE_CONSOLE1 = "/ore"
SLASH_pORE_CONSOLE2 = "/prospect"

function pORE_Button_Details() end
function pORE_Button_PriceList(List) end
function pORE_Button_Recommended() end
function pORE_CalculateData() end
function pORE_DisplaySelect(Display) end
function pORE_Options_Handler() end
function pORE_Reset_GemPrices() end
function pORE_Save_GemPrices() end
function pORE_Set_Details() end
function pORE_Set_GemPrices() end
function pORE_Set_ProspectedData(Data) end
function pORE_Set_Recommended(tRed, tBlue, tYellow, tPurple, tGreen, tOrange, tMeta, Status, Disenchant) end
function pORE_Set_RevenueData(Data) end
function pORE_StartAuctionScan() end
function pORE_ToggleAddon() end
function pORE_SaveOptionStates() end

function pORE_TSM_getData() end
function pORE_Auctioneer_getData() end
function pORE_Auctionator_getData() end



