--=========================================================================--
-- upvalues
--=========================================================================--

local _G, Pokedex, LibStub, cpj = _G, Pokedex, LibStub, C_PetJournal
local format, gmatch, gsub, strfind, strsub, strtrim, strupper = format, gmatch, gsub, strfind, strsub, strtrim, strupper
local assert, loadstring, tonumber, tostring, type = assert, loadstring, tonumber, tostring, type
local ipairs, next, pairs, rawget, rawset, select, setmetatable, sort, tinsert, tremove, unpack = ipairs, next, pairs, rawget, rawset, select, setmetatable, sort, tinsert, tremove, unpack
local band, bnot, bor, max, min, mrandom = bit.band, bit.bnot, bit.bor, max, min, math.random
local fband = function(...) return 0 ~= band(...) end

local CreateFont, CreateFrame, GameTooltip, GameTooltipText, GetCVarBool, SetCVar, UIParent = CreateFont, CreateFrame, GameTooltip, GameTooltipText, GetCVarBool, SetCVar, UIParent
local GetRunningMacro, GetTime, InterfaceOptionsFrame_OpenToCategory, SecureCmdOptionParse = GetRunningMacro, GetTime, InterfaceOptionsFrame_OpenToCategory, SecureCmdOptionParse
local Dismount, GetCompanionCooldown, GetCompanionInfo, GetNumCompanions, VehicleExit = Dismount, GetCompanionCooldown, GetCompanionInfo, GetNumCompanions, VehicleExit
local GetCurrentTitle, GetNumTitles, GetTitleName, IsTitleKnown = GetCurrentTitle, GetNumTitles, GetTitleName, IsTitleKnown
local GetActiveSpecGroup, GetGlyphSocketInfo, GetProfessionInfo, GetProfessions = GetActiveSpecGroup, GetGlyphSocketInfo, GetProfessionInfo, GetProfessions
local GetCurrentMapAreaID, GetCurrentMapContinent, GetMapContinents, GetRealZoneText, GetSubZoneText, GetWintergraspWaitTime, GetZoneText, SetMapToCurrentZone = GetCurrentMapAreaID, GetCurrentMapContinent, GetMapContinents, GetRealZoneText, GetSubZoneText, GetWintergraspWaitTime, GetZoneText, SetMapToCurrentZone
local GetNumGroupMembers, IsInRaid, SendChatMessage = GetNumGroupMembers, IsInRaid, SendChatMessage
local GetItemCount, GetItemInfo, GetSpellCooldown, GetSpellInfo, IsEquippedItem, IsSpellKnown, IsUsableSpell = GetItemCount, GetItemInfo, GetSpellCooldown, GetSpellInfo, IsEquippedItem, IsSpellKnown, IsUsableSpell
local InCombatLockdown, IsFlyableArea, IsFlying, IsIndoors, IsInInstance, IsMounted, IsOutdoors, IsSwimming = InCombatLockdown, IsFlyableArea, IsFlying, IsIndoors, IsInInstance, IsMounted, IsOutdoors, IsSwimming
local GetShapeshiftForm, GetUnitSpeed, UnitAffectingCombat, UnitBuff, UnitCanAttack, UnitCastingInfo, UnitClass, UnitFactionGroup, UnitInVehicle, UnitIsDead, UnitIsDeadOrGhost, UnitOnTaxi, UnitPower, UnitRace = GetShapeshiftForm, GetUnitSpeed, UnitAffectingCombat, UnitBuff, UnitCanAttack, UnitCastingInfo, UnitClass, UnitFactionGroup, UnitInVehicle, UnitIsDead, UnitIsDeadOrGhost, UnitOnTaxi, UnitPower, UnitRace
local GLYPH_ID_MAJOR_1, GLYPH_ID_MAJOR_2, GLYPH_ID_MAJOR_3, GLYPH_ID_MINOR_1, GLYPH_ID_MINOR_2, GLYPH_ID_MINOR_3, SPELL_POWER_SOUL_SHARDS = GLYPH_ID_MAJOR_1, GLYPH_ID_MAJOR_2, GLYPH_ID_MAJOR_3, GLYPH_ID_MINOR_1, GLYPH_ID_MINOR_2, GLYPH_ID_MINOR_3, SPELL_POWER_SOUL_SHARDS

local L = LibStub("AceLocale-3.0"):GetLocale("Pokedex")

--=========================================================================--
-- global variables, constants and types
--=========================================================================--

local IS = Pokedex.Globals.Types.InitStates;     -- Initialization States
local DL = Pokedex.Globals.Types.DebugLevels;    -- Debug Levels
local SL = Pokedex.Globals.Types.SkillLevels;    -- max rank of each skill level
local SI = Pokedex.Globals.Types.SkillIds;       -- skill identifiers
local MF = Pokedex.Globals.Types.MountFlags;     -- Mount Flags
local MB = Pokedex.Globals.Types.MountBreeds;    -- Mount Breeds
local DC = {};  -- Debug Categories 
local gc = Pokedex.Globals.Constants;
local gv = Pokedex.Globals.Variables;
local gs = Pokedex.Globals.SortMethods;
local EventMonitor_PJListUpdate = Pokedex.Globals.Types.CEventMonitor:Create("PET_JOURNAL_LIST_UPDATE")

local MFS_ATV = bor(MF.Flyer, MF.NoFlyZone_Legal, MF.Underwater_Legal)
local maskClearNFZL = bnot(MF.NoFlyZone_Legal)

--=========================================================================--
-- Addon Management functions
--=========================================================================--

-- Called when the addon is loaded
function Pokedex:OnInitialize()
	Pokedex:LoadSavedSettings()

	LibStub("AceConfig-3.0"):RegisterOptionsTable("Pokedex", Pokedex.GetUIOptions)
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Pokedex", "Pokedex")

	LibStub("AceConfig-3.0"):RegisterOptionsTable("Pokedex-Profiles", LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db, true))
	self.profilesFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Pokedex-Profiles", "Profiles", "Pokedex")

	self:RegisterChatCommand("pd", "ChatCommand")
	self:RegisterChatCommand("pokedex", "ChatCommand")
end


function Pokedex:ChatCommand(input)
	if (gv.InitState ~= IS.INITIALIZED and self:Initialize("ChatCommand") == IS.UNINITIALIZED) then
		self:Print(L["ERROR: Pokedex failed to initialize correctly. This is usually caused when WoW has invalidated its cache and hasn't finished rebuilding it. Please try this action again later."]);
		return
	end

	if (GetRunningMacro()) then
		if (input) then
			local orig = input;
			input = SecureCmdOptionParse(input);
			if (DC.MISC >= DL.AV) then self:Print("Pokedex called from macro, arguments were parsed"); end
			if (DC.MISC >= DL.AV) then self:Print("from:", orig); end
			if (DC.MISC >= DL.AV) then self:Print("to:", input); end
		end
		
		-- popping up options UI from within a macro is most likely not what the user really wanted, so just exit
		if (not input or input:trim() == "") then
			return
		end
	end

	if (not input or input:trim() == "") then
		InterfaceOptionsFrame_OpenToCategory(self.optionsFrame);
	else
		LibStub("AceConfigCmd-3.0").HandleCommand(Pokedex, "pd", "Pokedex", input);
	end
end


-- Called when the addon is enabled
function Pokedex:OnEnable()
	DC = self.db.global.rgDebugInfo;

	-- check that none of our actions are blocked
	self:RegisterEvent("ADDON_ACTION_BLOCKED");

	-- check that none of our actions are forbidden
	self:RegisterEvent("ADDON_ACTION_FORBIDDEN");

	-- init data tables and register events and hooks
	self:Initialize("OnEnable");
end


-- Called when the addon is disabled
function Pokedex:OnDisable()
	self:UnregisterEvent("ADDON_ACTION_BLOCKED");
	self:UnregisterEvent("ADDON_ACTION_FORBIDDEN");

	if (gv.InitState == IS.INITIALIZED) then
		self:UnregisterEvent("LEARNED_SPELL_IN_TAB");
		self:UnregisterEvent("PLAYER_TALENT_UPDATE");
		-- self:UnregisterEvent("PLAYER_SPECIALIZATION_CHANGED");
		self:UnregisterEvent("GLYPH_ADDED");
		self:UnregisterEvent("GLYPH_REMOVED");
		
		self:UnregisterEvent("COMPANION_LEARNED");
		EventMonitor_PJListUpdate:Suspend()

		self:UnregisterEvent("KNOWN_TITLES_UPDATE");
		self:UnregisterEvent("NEW_TITLE_EARNED");
		self:UnregisterEvent("OLD_TITLE_LOST");

		-- skills
		self:UnregisterEvent("SKILL_LINES_CHANGED");

		-- dismount
		self:UnregisterEvent("CVAR_UPDATE");
		self:UnregisterEvent("PLAYER_REGEN_DISABLED");
		self:UnregisterEvent("PLAYER_REGEN_ENABLED");
		self:UnregisterEvent("PLAYER_TARGET_CHANGED");

		-- companion autosummon
		self:UnregisterEvent("ZONE_CHANGED_NEW_AREA");

		Pokedex:UnhookAll();
	end
end


-- Initialize all the pet data in the addon
function Pokedex:Initialize(strCaller)
	strCaller = (strCaller or "unknown caller");
	
	if (gv.InitState == IS.INITIALIZED) then 
		if (DC.MISC >= DL.EXCEP) then self:Print("attempt to reinitialize by " .. strCaller); end
		return IS.INITIALIZED;
	end

	if (gv.InitState == IS.INITIALIZING) then 
		if (DC.MISC >= DL.EXCEP) then self:Print("attempt to initialize during initialization by " .. strCaller); end
		return IS.INITIALIZING;
	end

	if (DC.MISC >= DL.EXCEP) then self:Print("initialization triggered by " .. strCaller); end

	-- get skills
	self:InitSkills();

	-- if we can't get names for skill, mounts, companions or titles, then 
	-- we know we're probably in the bad cache state and will have to try
	-- initializing again later
	if ( -- not self:UpdateMountInfo() or
		 -- not self:UpdateTitleInfo() or
	     not self:FUpdateCompanionInfo() ) then
	     return IS.UNINITIALIZED;
	end
	
	self:UpdateDismountSettings();

	gv.InitState = IS.INITIALIZING;

	-- create secure action button to support forms
	self:CreateMountButton();

	-- update class based forms and mount features
	self:RegisterEvent("LEARNED_SPELL_IN_TAB");
	self:RegisterEvent("PLAYER_TALENT_UPDATE");
	-- self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED");
	self:RegisterEvent("GLYPH_ADDED");
	self:RegisterEvent("GLYPH_REMOVED");

	-- update data when new mount or companion added
	self:RegisterEvent("COMPANION_LEARNED");
	EventMonitor_PJListUpdate:Resume();

	-- keep track of current mount or companion
	self:SecureHook(   "CallCompanion",    "CallCompanionHook");
	self:SecureHook("DismissCompanion", "DismissCompanionHook");

	-- update data when new title added	
	self:RegisterEvent("KNOWN_TITLES_UPDATE");
	self:RegisterEvent("NEW_TITLE_EARNED");
	self:RegisterEvent("OLD_TITLE_LOST");

	-- keep track of current title
	self:SecureHook("SetCurrentTitle", "SetCurrentTitleHook");

	-- update dismount settings if the CVAR gets changed
	self:RegisterEvent("CVAR_UPDATE");
	
	-- allow flying dismount if in combat or if you've targeted something attackable
	self:RegisterEvent("PLAYER_REGEN_DISABLED");
	self:RegisterEvent("PLAYER_REGEN_ENABLED");
	self:RegisterEvent("PLAYER_TARGET_CHANGED");

	-- companion autosummon
	self:RegisterEvent("ZONE_CHANGED_NEW_AREA");

	-- update dismount for gathering if profession gained or lost
	-- LEARNED_SPELL_IN_TAB lets us know when spell is added to general tab, but not when we drop the skill
	-- SPELLS_CHANGED seems like it would get called *all* the time, we'd be a small perf drag on the game
	-- SKILL_LINES_CHANGED even though we look at spells now, this may still be the best way to know that we should
	self:RegisterEvent("SKILL_LINES_CHANGED");

	-- hook tooltip to see if we're about to try to gather
	self:SecureHookScript(GameTooltip, "OnShow", "MainTooltipShow");
	self:SecureHookScript(GameTooltip, "OnHide", "MainTooltipHide");

	-- if (DC.MISC >= DL.BASIC) then self:EchoCounts(); end
	gv.InitState = IS.INITIALIZED;
end

function Pokedex:SafeCall(fn, ...)
	if (gv.InitState ~= IS.INITIALIZED and self:Initialize("SafeCall") == IS.UNINITIALIZED) then
		self:Print(L["ERROR: Pokedex failed to initialize correctly. This is usually caused when WoW has invalidated its cache and hasn't finished rebuilding it. Please try this action again later."]);
	else
		return fn(self, ...);
	end
end

--=========================================================================--
--=========================================================================--
--
-- DEBUG AND INFRASTRUCTURE FUNCTIONS
--
--=========================================================================--
--=========================================================================--

local function TestSpeed(fVerbose)
	local nSpeed = GetUnitSpeed("player");
	local nPercent = nSpeed - 7;
	local strOut = "";

	if (nSpeed == 0) then
		strOut = format((fVerbose and "%i yards per second" or "%i YPS"), nSpeed);
	elseif (nPercent == 0) then
		strOut = format((fVerbose and "%i yards per second, standard run speed" or "%i YPS"), nSpeed);
	elseif (nPercent > 0) then
		nPercent = ((nSpeed - 7) * 100) / 7;
		strOut = format((fVerbose and "%.2f yards per second, speed boosted by %.2f%%" or "%i YPS  %.2f%%"), nSpeed, nPercent);
	else
		nPercent = (nSpeed * 100) / 7;
		strOut = format((fVerbose and "%.2f yards per second, speed reduced to %.2f%% of run speed" or "%i YPS  %.2f%%"), nSpeed, nPercent);
	end
	
	strOut = gsub(strOut, "%.00", "");
	return strOut;
end

--[===[@debug@
local LibQTip = nil
local ldbTestDataObj = nil
local ldbTestFrame = nil
local HeaderFont = nil
local LineFont = nil

local function UpdateSpeed(frame,elapsed)
	ldbTestDataObj.text = TestSpeed(false);
end

local function TestTip_OnEnter(self)
	-- Acquire a tooltip with 3 columns, respectively aligned to left, center and right
	local tooltip = LibQTip:Acquire("PokedexTestTooltip", 5)
	self.tooltip = tooltip 
	
	tooltip:SetHeaderFont(HeaderFont);
	tooltip:SetFont(LineFont);

	tooltip:AddLine(" ");

	tooltip:AddHeader("MapID", "Continent", "Zone", "Real Zone", "SubZone");

	SetMapToCurrentZone();
	local iContinent = GetCurrentMapContinent();
	local rgstrContinents = { GetMapContinents() };
	local strContinent = format("%i  %s", iContinent, (rgstrContinents[iContinent] or "unknown"));
		
	tooltip:AddLine(GetCurrentMapAreaID(), strContinent, GetZoneText(), GetRealZoneText(), GetSubZoneText());
	
	tooltip:AddLine(" ");
	tooltip:AddSeparator();
	tooltip:AddLine(" ");

	tooltip:AddHeader("FlyableArea", "Swimming", "Outdoors", "Indoors");
	tooltip:AddLine(tostring(IsFlyableArea()), tostring(IsSwimming()), tostring(IsOutdoors()), tostring(IsIndoors()));

	tooltip:AddLine(" ");
	tooltip:AddSeparator();
	tooltip:AddLine(" ");

	tooltip:AddHeader("Red Drake", "Red M-strider", "Subdued Seahorse", "Abyssal Seahorse", "Red Scarab");
	tooltip:AddLine(tostring(1 == IsUsableSpell(gc.idSpellRedDrake)), tostring(1 == IsUsableSpell(gc.idSpellRedMechanostrider)), tostring(1 == IsUsableSpell(gc.idSpellSubduedSeahorse)), tostring(1 == IsUsableSpell(gc.idSpellAbyssalSeahorse)), tostring(1 == IsUsableSpell(gc.idSpellRedScarab)));

	tooltip:AddLine(" ");
	tooltip:AddSeparator();
	tooltip:AddLine(" ");

	local listname, flags = Pokedex:GetAreaInfo()
	tooltip:AddHeader("NoFlyZone", "Underwater", "Moving", "Indoors", "Combat");
	tooltip:AddLine(fband(flags, MF.NoFlyZone_Legal), fband(flags, MF.Underwater_Legal), fband(flags, MF.Moving_Legal), fband(flags, MF.Indoors_Legal), fband(flags, MF.Combat_Legal));

	tooltip:AddLine(" ");
	tooltip:AddSeparator();
	tooltip:AddLine(" ");

	tooltip:AddHeader(listname, "Summonable", "Rejected", "N//A");
	local fulllist = gv.Mounts.Lists[listname]
	local filtered = fulllist:Filter(flags)

	local iFiltered = 1	
	for iFull = 1, #fulllist do
		if fulllist[iFull] == filtered[iFiltered] then
			iFiltered = iFiltered + 1
			tooltip:AddLine(fulllist[iFull].name, "X");
		else
			tooltip:AddLine(fulllist[iFull].name, nil, "X");
		end
	end
	tooltip:AddLine(" ");

	-- Use smart anchoring code to anchor the tooltip to our frame
	tooltip:SmartAnchorTo(self)

	-- Show it
	tooltip:Show()
end
 
local function TestTip_OnLeave(self)
	-- Release the tooltip
	LibQTip:Release(self.tooltip)
	self.tooltip = nil
end

function Pokedex:StartTestUI()
	if (not LibQTip) then
		LibQTip = LibStub('LibQTip-1.0');
	end

	if (not ldbTestFrame) then 
		ldbTestFrame = CreateFrame("Frame", "Pokedex_Test");
		ldbTestFrame:SetScript("OnUpdate", UpdateSpeed);
	end

	if (not ldbTestDataObj) then 
		ldbTestDataObj = LibStub("LibDataBroker-1.1"):NewDataObject("Pokedex_Test", {
			type	= "data source",
			icon	= "Interface\\Icons\\inv_pet_nurturedpenguinegg.png",
			label	= "Pokedex",
			text	= "0 YPS",
			OnEnter = TestTip_OnEnter,
			OnLeave = TestTip_OnLeave,
		});
	end
	
	if (not HeaderFont) then
		HeaderFont = CreateFont("PokedexHeaderFont");
		HeaderFont:SetFont(GameTooltipText:GetFont(), 17);
		HeaderFont:SetTextColor( 255/255, 215/255, 0/255 );
	end
	
	if (not LineFont) then
		LineFont = CreateFont("PokedexLineFont");
		LineFont:SetFont(GameTooltipText:GetFont(), 15);
		LineFont:SetTextColor( 255/255, 250/255, 205/255 );
	end
end
--@end-debug@]===]

local function MFtoStr(flags)
	local strFlags = tostring(flags)
	for name, flag in pairs(MF) do
		if type(flag) == "number" and fband(flag, flags) then
			strFlags = format("%s  %s", strFlags, name)
		end
	end
	return strFlags
end

function Pokedex:EchoTest()
	if (DC.DISMOUNT >= DL.AV) then 
		self:Printf("fManageAutoDismount=%s  fDismountForGathering=%s  fDismountForCombat=%s  fDismountForAttack=%s", 
			tostring(self.db.profile.fManageAutoDismount), tostring(Pokedex.db.profile.fDismountForGathering), 
			tostring(self.db.profile.fDismountForCombat), tostring(self.db.profile.fDismountForAttack));
	end

--[===[@debug@
	-- table validation - verifies spellId and mount name match - helps catch typos in table
	-- will spam errors if on a taxi and we've ran test code just to get speed
	if (not UnitOnTaxi("player") and IsOutdoors()) then
		local listname, flagsArea = self:GetAreaInfo()
		local count = 0;

		-- self:Print("area flags", MFtoStr(flagsArea))
		local flagsArea = band(flagsArea, bnot(MF.Moving_Legal)) -- mounts return as usable spells while moving

		for k,v in pairs(gc.rgMountAttributes) do
			count = count + 1;
			local strName = GetSpellInfo(k);
			if (strName ~= v.name) then
				self:Printf("table mismatch for spellID %s, expected: %s  got: %s", tostring(k), tostring(v.name), tostring(strName));
			end

--			if (v.breed ~= MB.CloudSerpent and not fband(v.flags, MF.Vashjir) and not fband(v.flags, MF.Ahn_Qiraj)) then
			if (v.breed ~= MB.CloudSerpent and not fband(v.flags, MF.Ahn_Qiraj)) then
				local fCanUse = IsUsableSpell(k) and true or false;
				local flagsMount = v.flags
				
				if fband(flagsMount, MF.Swimmer) and (listname == "Vashjir" or listname == "WetOrder") then
					flagsMount = bor(flagsMount, MF.Underwater_Legal, MF.NoFlyZone_Legal)
				end
				if fband(flagsMount, MF.Walker) then
					flagsMount = bor(flagsMount, MF.Underwater_Legal, MF.NoFlyZone_Legal)
				end

				if k == 75207 then -- Abyssal Seahorse is buggy
					assert((listname == "Vashjir") or (fCanUse == (listname == "WetOrder")), "vashjir seahorse usable bug may be fixed")
					fCanUse = (listname == "Vashjir") or (listname == "WetOrder")
				end

				if (not fCanUse) then
					if (band(flagsMount, flagsArea) == flagsArea) and
						-- not (fband(flagsMount, MF.Vashjir) and listname ~= "Vashjir") and
						not (fband(flagsMount, MF.Swimmer) and (listname ~= "Vashjir" or listname ~= "WetOrder")) then
						-- mount isn't usable, but we didn't fail any flag checks
						-- and it wasn't a swimmer out of water
						-- this is a mount we thought we could summon, why?
						Pokedex:Printf("%6i %s %s oversold by %s", k, v.name, MFtoStr(v.flags), MFtoStr(band(flagsMount, flagsArea)))
					end
				else
					if (band(flagsMount, flagsArea) ~= flagsArea) and
						not (fband(flagsMount, MF.Vashjir) and listname ~= "Vashjir") then
						-- mount is usable, but failed a flag check
						-- and its not the seahorse lying about being usable in water outside of Vashjir
						-- this is a mount we thought we couldn't summon, why?
						Pokedex:Printf("%6i %s %s undersold without %s", k, v.name, MFtoStr(v.flags), MFtoStr(band(bnot(flagsMount), flagsArea)))
					end
				end
			end
		end
		self:Printf("Pokedex mounts table contains %s entries", tostring(count));
	end

	self:StartTestUI();
--@end-debug@]===]
end


--[===[@debug@
function Pokedex:midlist(idMin, idMax, cMax)
	-- self:Print("idMin", type(idMin), idMin, "idMax", type(idMax), idMax, "cMax", type(cMax), cMax)
	local names = {};
	for k,v in pairs(gc.rgMountAttributes) do
		if ((not idMin or idMin < k) and (not idMax or k <= idMax)) then
			tinsert( names, { id = k, name = v.name } );
		end
	end
	
	cMax = cMax or 199
	sort(names, gs.ByIdReversed);
	if (cMax < #names) then -- list needs to be trimmed down
		names = { select(-cMax, unpack(names)) }
	end
	idMin = names[#names].id
	idMax = names[1].id

	sort(names, gs.ByName);
	for k,v in ipairs(names) do
		self:Printf("%3i  %s", k, v.name);
		-- self:Printf("%3i  %6i  %s", k, v.id, v.name);
	end
	-- self:Print("cMax", cMax, "#names", #names)
	self:Printf("%i to %i   %s to %s", idMin, idMax, names[1].name, names[#names].name)
end
--@end-debug@]===]


function Pokedex:EchoCounts()
	self:Printf("Current counts are %i mounts, %i companions and %i titles", gv.Mounts.count, gv.Pets.count, gv.Titles.count);
end

function Pokedex:EchoSpeed()
	self:Print(TestSpeed(true));
end

function Pokedex:EchoZone()
	SetMapToCurrentZone();

	local rgstrContinents = { GetMapContinents() };
	local strSubZone = GetSubZoneText();
--[==[
	FOO FIX THIS
	local rgMSFiltered = self:FilterMountSpeeds();

	if (strSubZone == "") then strSubZone = nil; end
	if (#rgMSFiltered == 0) then 
		rgMSFiltered = { L["no mounts available"] };
	else
		for i = 1, #rgMSFiltered do
			rgMSFiltered[i] = gc.rgstrMountSpeedDescsShort[ rgMSFiltered[i] ];
		end
	end

	local strLocation = self:StrFromVarArg(nil, unpack( { rgstrContinents[GetCurrentMapContinent()], GetZoneText(), strSubZone } ));
	local strMountList = self:StrFromVarArg(" ", unpack(rgMSFiltered));
	
	self:Printf("%s.  Mount order: %s.", strLocation, strMountList);
--]==]
end

function Pokedex:ADDON_ACTION_BLOCKED(_, culprit, action, ...)
	if (culprit ~= "Pokedex") then return end
	self:Printf("ERROR: ADDON_ACTION_BLOCKED calling %s  %s", action, self:StrFromVarArg(nil, ...));
end

function Pokedex:ADDON_ACTION_FORBIDDEN(_, culprit, action, ...)
	if (culprit ~= "Pokedex") then return end
	self:Printf("ERROR: ADDON_ACTION_BLOCKED calling %s  %s", action, self:StrFromVarArg(nil, ...));
end


function Pokedex:SetDebug(info, value)
	local strName, strValue, index = self:GetArgs(value, 2);
	
	if (strName == nil) then
		self:DebugValues();
		return;
	end

	if (index ~= 1e9) then
		self:Print("ERROR: too many parameters passed");
		self:DebugUsage();
		return;
	end

	local iValue = tonumber(strValue)
	if (iValue == nil) then
		self:Print("ERROR: no value given for debug level");
		self:DebugUsage();
		return;
	elseif (iValue < DL.NONE or iValue > DL.MAX) then
		self:Printf("ERROR: level_value must be number between %i and %i", DL.NONE, DL.MAX);
		self:DebugUsage();
		return;
	end

	strName = strupper(strName);
	if (strName == "ALL") then
		for k in pairs(DC) do
			DC[k] = iValue;
		end
	elseif (DC[strName] ~= nil) then
			DC[strName] = iValue;
	else
		self:Print("ERROR: level_name not recognized. Must match an existing value or ALL.");
		self:DebugUsage();
		return;
	end

	self:DebugValues();
end

function Pokedex:DebugValues()
	self:Print("current debug levels:");
	for k,v in pairs(DC) do
		self:Printf("value: %i  name: %s", v, k);
		-- self:Printf("lvalue:%i pvalue:%i name:%s", DL[v.category], v, k);
	end
end

function Pokedex:DebugUsage()
	self:Print("to see current debug levels:");
	self:Print("  /pd debug ");
	self:Print("to set a level:");
	self:Print("  /pd debug level_name level_value");
end


function Pokedex:PrintTable(table, tableName)
	tableName = tableName or tostring(table);
	if (table == nil) then 
		self:Print("'table' is nil");
	elseif (type(table) ~= "table") then
		self:Printf("'table' is actually of type %s", type(table));
	else
		self:Printf("key/value pairs for table %s", tableName);
		for k,v in pairs(table) do
			self:Printf("key(%s): %s   value(%s): %s", type(k), tostring(k), type(v), tostring(v));
		end
	end
end

function Pokedex:StrFromVarArg(strDelim, ...)
	if (select("#", ...) == 0) then return ""; end
	strDelim = strDelim or "  "

	local strOut = tostring(select(1, ...));
	for i=2, select("#", ...), 1 do
		strOut = format("%s%s%s", strOut, strDelim, tostring(select(i, ...)));
	end

	return strOut;	
end

local function NewCounter(iStart)
	local i = 0
	return function()
		i = i + 1
		return i
	end
end

--=========================================================================--
--=========================================================================--
--
-- BUTTON FUNCTIONS
--
--=========================================================================--
--=========================================================================--

function Pokedex:LEARNED_SPELL_IN_TAB(event, spellID, ...)
	-- self:Print(event, spellID, ...)
	if (gc.rgidMonitoredSpell[spellID]) then 
		self:UpdateMountInfo();
		LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
	end
end

function Pokedex:PLAYER_SPECIALIZATION_CHANGED(...)
	-- self:Print(...)
	self:UpdateMountInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:PLAYER_TALENT_UPDATE(...)
	-- self:Print(...)
	self:UpdateMountInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:GLYPH_ADDED(...)
	-- self:Print(...)
	self:UpdateMountInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:GLYPH_REMOVED(...)
	-- self:Print(...)
	self:UpdateMountInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:CreateMountButton()
	gv.btnToggleMount = CreateFrame("Button", "PokedexToggleMountButton", UIParent, "SecureActionButtonTemplate");
	if not gv.btnToggleMount then self:Print("btnToggleMount is nil") end

	_G["BINDING_NAME_CLICK PokedexToggleMountButton:LeftButton"] = L["Toggle Mount"];

	gv.btnToggleMount:SetAttribute("type", "macro");

	gv.btnToggleMount:SetScript("PreClick",  Pokedex.ToggleMountPreClick);
	gv.btnToggleMount:SetScript("PostClick", Pokedex.ToggleMountPostClick);
	Pokedex.ToggleMountPostClick(gv.btnToggleMount);

end

Pokedex.ToggleMountPreClick = function(btn)
	if InCombatLockdown() then return end
	local player = Pokedex.Globals.Constants.Player
	local strMacro = nil

	if (Pokedex:IsMounted()) then	-- not true when in a mount form ... by design
		strMacro = player.strCombatMacro
	else
		local mount = Pokedex:SelectMount()
		strMacro = format("%s%s", 
			(mount.fOnGCD) and "" or player.strCastOnMount, 
			(mount.strMacro) and mount.strMacro or "/Pokedex ToggleMount")
	end

	btn:SetAttribute("macrotext", strMacro)
	-- Pokedex:Print("ToggleMount macro\r", strMacro)
end

Pokedex.ToggleMountPostClick = function(btn)
	if InCombatLockdown() then return end
	btn:SetAttribute("macrotext", Pokedex.Globals.Constants.Player.strCombatMacro);
end


--=========================================================================--
--=========================================================================--
--
-- SKILL FUNCTIONS
--
--=========================================================================--
--=========================================================================--

local function GetSkills()
	if (not gc.metaSkills) then 
		local t = {}
		for _, skill in pairs(SI) do
			t[skill] = 0
		end
		gc.metaSkills = { __index = t }
	end

	local function GetSkillRanks(...)
		local t = {}
		for i = 1, 2 do  -- first two values returned are the two professions
			local iProf = select(i, ...)
			if iProf then
				local name, _, rank, maxRank, _, _, idSkill = GetProfessionInfo(iProf);
				local skill = SI[idSkill]
				if skill then
					t[skill] = rank
				else
					assert(skill ~= nil, tostring(idSkill).."  "..tostring(name))
				end
			end
		end
		return t
	end

	-- find out what skills are known
	skills = GetSkillRanks(GetProfessions());

	skills.fHerbalist = nil ~= skills.Herbalism
	skills.fSkinner   = nil ~= skills.Skinning
	skills.fMiner     = nil ~= skills.Mining
	skills.fGatherer  = skills.fHerbalist or skills.fSkinner or skills.Miner


	-- determine our riding skill level
	for _,v in ipairs(gc.rgRidingSkills) do
		if (IsSpellKnown(v.id)) then
			skills.Riding = v.level
			break
		end
	end

	return setmetatable(skills, gc.metaSkills)
end

function Pokedex:InitSkills()
	-- find out what skills are known
	gv.Skills = GetSkills()

	if (DC.MISC >= DL.BASIC) then 
		local msg = format("SKILLS  Riding:%s  fGatherer:%s", gc.rgstrSkillRankName[gv.Skills.Riding], tostring(gv.Skills.fGatherer))
		for _, skill in pairs(SI) do
			local rank = rawget(gv.Skills, skill)
			if rank ~= nil then
				msg = format("%s  %s:%i", msg, skill, rank)
			end
		end
		self:Print(msg); 
	end
end

function Pokedex:SKILL_LINES_CHANGED(...)
	-- if (DC.MISC >= DL.AV) then self:Printf("SKILL_LINES_CHANGED  %s", self:StrFromVarArg(nil, ...)); end

	local oldSkills = gv.Skills;
	gv.Skills = GetSkills()

	-- did we gain a new level of riding skill
	if gv.Skills.Riding > oldSkills.Riding then
		if (DC.MISC >= DL.BASIC) then self:Printf("skill for %s riding earned", gc.rgstrSkillRankName[gv.Skills.Riding]); end
		self:UpdateMountInfo();
		LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
	end

	if (gv.Skills.fGatherer ~= oldSkills.fGatherer) then
		if (self.db.profile.fDismountForGathering and not gv.Skills.fGatherer) then
			if (DC.MISC >= DL.BASIC) then self:Print("we no longer have a gathering skill and so will disable dismount for gathering"); end
			self.db.profile.fDismountForGathering = false;
		end
		LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
	end
end


--=========================================================================--
--=========================================================================--
--
-- MOUNT AND COMPANION SHARED FUNCTIONS
--
--=========================================================================--
--=========================================================================--

function Pokedex:SummonVendor()
	local strFaction = UnitFactionGroup("player")
	local sidArgentMinion = gc.tblArgentMinion[strFaction]
	local sidMammoth = gc.tblTravelersTundraMammoth[strFaction]

	local petArgentMinion = gv.Pets.BySID[sidArgentMinion]
	local mountMammoth = gv.Mounts.BySID[sidMammoth]
	local mountYak = gv.Mounts.BySID[gc.idSpellGrandExpeditionYak]

	if (IsOutdoors()) then 
		if (mountYak ~= nil) then
			if (not mountYak.fActive) then self:SummonSelectedMount(mountYak.index) end
		elseif (mountMammoth ~= nil) then
			if (not mountMammoth.fActive) then self:SummonSelectedMount(mountMammoth.index) end
		elseif (petArgentMinion ~= nil) then
			if (petArgentMinion ~= self:GetCurrentPet()) then self:SummonSelectedPet(petArgentMinion); end
		else
			self:Print(L["ERROR: You have no mounts or pets with vendor capabilities"]);
		end
	else
		if (petArgentMinion ~= nil) then
			if (petArgentMinion ~= self:GetCurrentPet()) then self:SummonSelectedPet(petArgentMinion); end
		elseif (mountYak ~= nil) then
			self:Printf(L["ERROR: You cannot summon %s in this area"], mountYak.name);
		elseif (mountMammoth ~= nil) then
			self:Printf(L["ERROR: You cannot summon %s in this area"], mountMammoth.name);
		else
			self:Print(L["ERROR: You have no mounts or pets with vendor capabilities"]);
		end
	end
end

function Pokedex:COMPANION_LEARNED(...)
	if (DC.MOUNTS >= DL.BASIC or DC.PETS >= DL.BASIC) then self:Print("COMPANION_LEARNED  " .. self:StrFromVarArg(nil, ...)); end

	self:UpdateMountInfo()
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:CallCompanionHook(type, index)
	-- print("CallCompanionHook", type, index)
	if (type == "CRITTER" ) then
		-- self:SetCurrentCompanion(index)
		return
	elseif (type == "MOUNT") then
		gv.Mounts:SetCurrent(gv.Mounts.ByIndex[index])
	else
		self:Print(L["ERROR: type error"])
	end
end


function Pokedex:DismissCompanionHook(type)
	if (type == "CRITTER" ) then
		-- self:SetCurrentCompanion(0)
		return
	elseif (type == "MOUNT") then
		gv.Mounts:SetCurrent(gc.nomount)
	else
		self:Print(L["ERROR: type error"])
	end
end


function Pokedex:AnnounceSummon(strName)
	if (not self.db.profile.fAnnounce) then return end

	local iChannel = self.db.profile.iChannel

	-- if not in raid, try sending it to party
	if (3 == iChannel and not IsInRaid()) then
		iChannel = 2
	end
	-- if not in a party, just send it to yourself
	if (2 == iChannel and 0 == GetNumGroupMembers()) then
		iChannel = 1
	end

	local strOut
	if (iChannel == 4) then
		strOut = format(L["lets %s know that they have been chosen."], strName);
	else
		strOut = format(L["%s, I choose you!"], strName);
	end

	if (iChannel == 1) then
		self:Print(strOut);
	else
		SendChatMessage(strOut, gc.rgstrChannels[iChannel]);
	end

end


--=========================================================================--
--=========================================================================--
--
-- MOUNT FUNCTIONS
--
--=========================================================================--
--=========================================================================--

function Pokedex:IsMounted()
	return (IsMounted() or UnitInVehicle("player"));
end

function Pokedex:ToggleMount()
	if (Pokedex:IsMounted()) then
		self:DismissMount()
	else
		self:SummonMount()
	end
end

function Pokedex:DismissMount()
	if UnitInVehicle("player") then
		VehicleExit()
		if (self.db.profile.fAutoSummonCompanion and self:GetCurrentPet() == gc.nopet and gv.Pets.count > 0) then
			self:SummonCompanion()
		end
	elseif IsMounted() then
		-- TODO find if this goes through dismiss companion hook for tracking
		Dismount()
		if (self.db.profile.fAutoSummonCompanion and self:GetCurrentPet() == gc.nopet and gv.Pets.count > 0) then
			self:SummonCompanion()
		end
	end
end

function Pokedex:SummonMount(...)
	local mount = self:SelectMount(true, ...);
	if (mount and mount.index > 0) then
		self:SummonSelectedMount(mount.index);
	end
end

function Pokedex:SummonNextMount()
	local CurMount = gv.Mounts:GetCurrent()
	local iCurrent = CurMount and CurMount.index or 0
	local rgMounts = gv.Mounts.ByIndex

	-- print(CurMount.name and CurMount.index)
	for i = iCurrent+1, #rgMounts do
		local mount = rgMounts[i]
		if mount.sid ~= gc.idSpellAbyssalSeahorse then
			if IsUsableSpell(mount.sid) and not fband(mount.flags, MF.Unusable) then
				self:SummonSelectedMount(mount.index)
				return
			end
		end
	end
	
	for i = 1, iCurrent-1 do
		local mount = rgMounts[i]
		if mount.sid ~= gc.idSpellAbyssalSeahorse then
			if IsUsableSpell(mount.sid) then
				self:SummonSelectedMount(mount.index)
				return
			end
		end
	end
end

function Pokedex:SummonSafeMount()
	local mount = gv.Mounts.Types.ATVs:SelectMount(true) or gc.nomount
	if (mount and mount.index > 0) then
		self:SummonSelectedMount(mount.index);
	end
end


function Pokedex:SummonPassengerMount()
	-- fNoSpecials, fPassengers, fWaterWalkers)
	Pokedex:SummonMount(true)
end

function Pokedex:SummonWaterWalker()
	-- fNoSpecials, fPassengers, fWaterWalkers)
	Pokedex:SummonMount(false, true)
end

function Pokedex:SummonSelectedMount(iMount)
	local mount = gv.Mounts.ByIndex[iMount]
	if not mount then
		if (DC.MOUNTS >= DL.BASIC) then self:Print("ERROR - bad companion index"); end
		return
	end

	_G.CallCompanion("MOUNT", iMount);
	--self:AnnounceSummon(mount.name);

	-- change title on load, unless its heroic maloriak temporary title in which case revel in the glory
	if (self.db.profile.fChangeTitleOnMount and GetCurrentTitle() ~= gc.idTitleMinionSlayer) then 
		self:ChangeTitle(); 
	end
end

-- works through buckets to find a usable mount/form
function Pokedex:SelectMount(...)
	local listname, flags = self:GetAreaInfo()
	local buckets = gv.Mounts.Lists[listname]
	
	return buckets:Filter(flags):SelectMount(...) or gc.nomount
end


function Pokedex:TestMount()
	self:Print("test mount")
	local mount = self:SelectMount()
	self:Print(format("%s%s", 
			(mount.fOnGCD) and "" or gc.Player.strCastOnMount, 
			(mount.strMacro) and mount.strMacro or "/Pokedex ToggleMount"))
end

--=========================================================================--
--=========================================================================--
--
-- NEW MOUNT FUNCTIONS NEW NEW
--
--=========================================================================--
--=========================================================================--

function Pokedex:UpdateMountInfo()
	gc.Player:UpdatePlayerInfo()
	gv.Mounts:UpdateMounts()
end

local function UpdateMountFlags(mount)
	local flags = mount.rawflags

	-- user has no riding skill
	if (gv.Skills.Riding == SL.None) then
		flags = MF.Unusable;
	end

	-- check if its a mount that has a skill requirement
	if (mount.skill and gv.Skills[mount.skill.name] < mount.skill.rank) then
		flags = MF.Unusable;  -- failed required skill check
	end

	-- check whether they have training required for a Cloud Serpent
	if (mount.cloudserpent and not IsSpellKnown(gc.idSpellCloudSerpentRiding)) then
		flags = MF.Unusable;
	end

	-- adjust flags of flying mounts
	if fband(flags, MF.Flyer) then
		if fband(flags, MF.NoFlyZone_Legal) then
			if (Pokedex.db.profile.fFavorGroundMounts) then
				-- remove ground flag from flying mounts if user favors ground mounts
				flags = band(flags, maskClearNFZL);
			end
		elseif (gv.Skills.Riding < SL.Expert) then
			-- user does not have flying skill and mount is flyer that cannot run in ground only zone
			flags = band(flags, MF.Unknown); -- keep the unknown flag if set
			flags = bor(flags, MF.Unusable);
		end
	end

	mount.flags = flags
end

-- returns: rawflags, skill requirements, requires cloudserpent training
local function GetMountAttributes(idSpell, gameflags)
	local mount = gc.rgMountAttributes[idSpell]
	
	-- if its not in the table, make a guess based on the flags they gave, but also include Unknown to flag it
	if (not mount) then
		if (fband(gameflags, 0x2)) then       -- the 0x1 bit has been true on flying mounts that 
			return bor(MF.Unknown, MF.Flyer); -- don't work in ground zones so assume flyer only
		elseif (fband(gameflags, 0x1)) then
			return bor(MF.Unknown, MF.NoFlyZone_Legal); -- since it can't fly assume it works in ground zones
		elseif (fband(gameflags, 0x8)) then
			return bor(MF.Unknown, MF.Swimmer); -- if it can't fly or run but can swim, then assume it must do that well
		else
			return bor(MF.Unknown, MF.Unusable);
		end
	end

	return mount.flags, gc.rgSkillMounts[idSpell], mount.breed == MB.CloudSerpent;
end

--=====================================================================--
-- CLASS DEFINITION FOR STANDARD MOUNTS AND SPECIAL MOUNTS
--=====================================================================--

local metaMount = {
	__lt = gs.MountsByName,
	__index = function(t,k)
			if (k == "rank") then
				return t.char_rank or t.profile_rank
			elseif (k == "char_rank") then
				return Pokedex.db.char.mounts.ranks[t.name]
			elseif (k == "profile_rank") then
				return Pokedex.db.profile.mounts.ranks[t.name] or Pokedex.db.profile.mounts.iDefaultRank
			elseif (k == "fActive") then
				return select(5, GetCompanionInfo("MOUNT", t.index))
			elseif (k == "fHas") then
				return true
			elseif (k == "fCan") then
				-- return IsUsableSpell(t.sid)
				return true
			elseif (k == "fOnGCD") then
				return false
			elseif (k == "strMacro") then
				return format("/run Pokedex:SummonSelectedMount(%i);", t.index)
			else
				return nil
			end
		end,
	__newindex = function(t,k,v)
			if (k == "char_rank") then
				Pokedex.db.char.mounts.ranks[t.name] = v
			elseif (k == "profile_rank") then
				Pokedex.db.profile.mounts.ranks[t.name] = (Pokedex.db.profile.mounts.iDefaultRank ~= v) and v or nil
			else
				Pokedex:Print("unexpected table assingment", t.name, k, v)
			end
		end,
}

--=====================================================================--
-- CLASS DEFINITION FOR RUNNING WILD, WORGEN MOUNT FORM
--=====================================================================--

local function NewRunningWild()
	-- if player is Worgen this is the mount meta to use post initialization
	local metaRunningWild ={
		__lt = gs.MountsByName,
		__index = function(t,k)
				if (k == "rank") then
					return t.char_rank or t.profile_rank
				elseif (k == "char_rank") then
					return Pokedex.db.char.mounts.ranks[t.name]
				elseif (k == "profile_rank") then
					return Pokedex.db.profile.mounts.ranks[t.name] or Pokedex.db.profile.mounts.iDefaultRank
				elseif (k == "fActive") then
					return UnitBuff("player", t.name);
				elseif (k == "fHas") then
					if (IsSpellKnown(t.sid)) then
						rawset(t, k, true);
						return true;
					else
						return false;
					end
				end
				return nil;
			end,
		__newindex = function(t,k,v)
				if (k == "char_rank") then
					Pokedex.db.char.mounts.ranks[t.name] = v
				elseif (k == "profile_rank") then
					Pokedex.db.profile.mounts.ranks[t.name] = (Pokedex.db.profile.mounts.iDefaultRank ~= v) and v or nil
				else
					Pokedex:Print("unexpected table assingment for Running Wild", k, v)
				end
			end,
	}

	-- Delay inits table. Executes on first table access and replaces itself.
	local metaInit = { 
	__index = function(t,k)
			setmetatable( t, nil );
			local spellName = GetSpellInfo(t.sid) or "Running Wild";
			t.name = spellName

			local _, race = UnitRace("player");
			if (race ~= "Worgen") then 
				t.fHas = false;  -- setting this alone should really be enough
				t.flags = 0
				return t[k];
			end

			t.strMacro = format("/cast %s", spellName)
			t.fCan = true;
			t.fOnGCD = false;
			t.flags = bor(MF.NoFlyZone_Legal, MF.Underwater_Legal)
			t.rawflags = bor(MF.NoFlyZone_Legal, MF.Underwater_Legal)

			setmetatable( t, metaRunningWild )
			return t[k];
		end,
	}

	return setmetatable( { sid = 87840 }, metaInit );
end

--=====================================================================--
-- CLASS DEFINITION FOR DRAGONWRATH, TARECGOSA'S VISAGE
--=====================================================================--

local function NewTarecgosa()
	local metaTarecgosa = {
		__lt = gs.MountsByName,
		__index = function(t,k)
				if (k == "rank") then
					return t.char_rank or t.profile_rank
				elseif (k == "char_rank") then
					return Pokedex.db.char.mounts.ranks[t.name]
				elseif (k == "profile_rank") then
					return Pokedex.db.profile.mounts.ranks[t.name] or Pokedex.db.profile.mounts.iDefaultRank
				elseif (k == "fActive") then
					return UnitBuff("player", t.name);
				elseif (k == "fCan") then 	-- true if item is equipped
					return (IsEquippedItem(71086));
				elseif (k == "fHas") then	-- true if item is in inventory or bank
					return (GetItemCount(71086, true) > 0);
				end
			return nil;
		end,
		__newindex = function(t,k,v)
				if (k == "char_rank") then
					Pokedex.db.char.mounts.ranks[t.name] = v
				elseif (k == "profile_rank") then
					Pokedex.db.profile.mounts.ranks[t.name] = (Pokedex.db.profile.mounts.iDefaultRank ~= v) and v or nil
				else
					Pokedex:Print("unexpected table assingment for Tarecgosa's Visage", k, v)
				end
			end,
	}

	-- Delay inits table. Called on first table access as the __index metamethod.
	local metaInit = {
		__index = function(t,k)
			setmetatable(t, nil);

			t.name = GetSpellInfo(t.sid) or "Tarecgosa's Visage";
			t.strMacro = format("/use %s", GetItemInfo(71086) or "Dragonwrath, Tarecgosa's Rest")
			t.fOnGCD = false;
			t.flags = bor(MF.Flyer, MF.NoFlyZone_Legal, MF.Underwater_Legal)
			t.rawflags = bor(MF.Flyer, MF.NoFlyZone_Legal, MF.Underwater_Legal)

			setmetatable(t, metaTarecgosa);
			return t[k];
		end,
	}

	return setmetatable( { sid = 101641 }, metaInit );
end

--=====================================================================--
-- CLASS DEFINITION FOR MAGIC BROOM
--=====================================================================--

local function NewMagicBroom()
	local metaMagicBroom = {
		__lt = gs.MountsByName,
		__index = function(t,k)
				if (k == "rank") then
					return t.char_rank or t.profile_rank
				elseif (k == "char_rank") then
					return Pokedex.db.char.mounts.ranks[t.name]
				elseif (k == "profile_rank") then
					return Pokedex.db.profile.mounts.ranks[t.name] or Pokedex.db.profile.mounts.iDefaultRank
				elseif (k == "fHas") then	-- true if item is in inventory or bank
					return (GetItemCount(37011, true) > 0);
				elseif (k == "fCan") then 	-- true if item is in inventory only
					return (GetItemCount(37011, false) > 0);
				elseif (k == "fActive") then
					return UnitBuff("player", t.name);
				end
			return nil;
		end,
		__newindex = function(t,k,v)
				if (k == "char_rank") then
					Pokedex.db.char.mounts.ranks[t.name] = v
				elseif (k == "profile_rank") then
					Pokedex.db.profile.mounts.ranks[t.name] = (Pokedex.db.profile.mounts.iDefaultRank ~= v) and v or nil
				else
					Pokedex:Print("unexpected table assingment for MagicBroom's Visage", k, v)
				end
			end,
	}

	-- Delay inits table. Called on first table access as the __index metamethod.
	local metaInit = {
		__index = function(t,k)
			setmetatable(t, nil);

			t.name = GetSpellInfo(t.sid) or "Magic Broom";
			t.strMacro = format("/use %s", GetItemInfo(37011) or "Magic Broom")
			t.fOnGCD = false;
			t.flags = bor(MF.Flyer, MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Moving_Legal)
			t.rawflags = bor(MF.Flyer, MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Moving_Legal)

			setmetatable(t, metaMagicBroom);
			return t[k];
		end,
	}

	return setmetatable( { sid = 47977 }, metaInit );
end


--=====================================================================--
-- MOUNT BUCKETS 
--=====================================================================--

local metaFormBucket = {}
metaFormBucket.__lt = gs.ByOrder
metaFormBucket.__index = metaFormBucket

function metaFormBucket:IsEmpty()
	return not self.mount.fHas
end

function metaFormBucket:IsNotEmpty()
	return self.mount.fHas
end

function metaFormBucket:MountQualifies()
	return false
end

function metaFormBucket:MountInBucket(mount)
	return self.mount == mount
end

function metaFormBucket:GetFirstMount()
	return self.mount
end

function metaFormBucket:SelectMount(fNoSpecials)
	return (not fNoSpecials and self.mount.fCan) and self.mount or nil
end


local metaMountBucket = {}
metaMountBucket.__lt = gs.ByOrder
metaMountBucket.__index = metaMountBucket

function metaMountBucket:IsEmpty()
	return next(self.mounts) == nil
end

function metaMountBucket:IsNotEmpty()
	return next(self.mounts) ~= nil
end

function metaMountBucket:MountQualifies(mount)
	return self.flagsIncluded and self.flagsIncluded == band(mount.flags, self.flagsIncluded)
end

function metaMountBucket:MountInBucket(mount)
	return self.mounts[mount] ~= nil
end

function metaMountBucket:GetFirstMount()
	if not self.first then
		for mount,name in pairs(self.mounts) do
			if not self.first or self.first.name > name then
				self.first = mount
			end
		end		
	end

	return self.first
end

function metaMountBucket:SelectMount(fNoSpecials, fPassengers, fWaterWalkers)
	local strCurCast = UnitCastingInfo("player")
	if (strCurCast ~= nil) then
		if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("currently casting %s; summon will fail for this reason so ignore this summons attempt", strCurCast); end
		return;
	end

	local CurMount = gv.Mounts:GetCurrent();
	
	local rgFiltered = {};
	local cTotalRanks = 0;
	local fSkippedCur = false;
	local fSkippedHot = false;

	for mount,name in pairs(self.mounts) do 
		-- if a mount is flagging itself as disabled
		if (not mount.fCan) then
			if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("%s skipped for returning disabled", mount.name); end
		-- cannot call specials from inside any of the old summoning methods
		elseif (fNoSpecials and mount.index == nil) then
			if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("%s skipped for not being summonable from this method", mount.name); end
		elseif (fPassengers and not gc.rgPassengerMounts[mount.sid]) then
			if (DC.MOUNTS >= DL.AV) then Pokedex:Printf("%s skipped for not carrying passengers", mount.name); end
		elseif (fWaterWalkers and not gc.rgWaterWalkingMounts[mount.sid]) then
			if (DC.MOUNTS >= DL.AV) then Pokedex:Printf("%s skipped for not water walking", mount.name); end
		-- if its ranked as 0, then it gets skipped
		elseif (mount.rank == 0) then
			if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("%s skipped for having rank of 0", mount.name); end
		-- if its the current mount, then it is skipped
		elseif (mount == CurMount) then
			if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("%s skipped for being current mount", mount.name); end
			fSkippedCur = true;
		-- if hot mount and hotness is enabled then don't add to list, it will be handled seperately
		elseif (Pokedex.db.char.fEnableHotness and mount == gv.HotMount) then
			if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("%s skipped for being hot mount", mount.name); end
			fSkippedHot = true;
		-- else its put into the pool of summonables
		else
			tinsert(rgFiltered, mount)
			cTotalRanks = cTotalRanks + mount.rank;
			if (DC.MOUNTS >= DL.AV) then Pokedex:Printf("%s added to list of summonable mounts with a rank of %i. Total rank count is %i", mount.name, mount.rank, cTotalRanks); end
		end
	end
	if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("list built: %i with a total rank of %i", #rgFiltered, cTotalRanks); end

	-- if we skipped the hot mount while building a list, nows the time for its heat check
	if (fSkippedHot) then
		local iHeatCheck = mrandom(1,100);
		if (Pokedex.db.char.mounts.iHeat >= iHeatCheck) then
			if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("%s passed heat check (rolled %i, needed %i or less) and will be summoned", gv.HotMount.name, iHeatCheck, Pokedex.db.char.mounts.iHeat); end
			return gv.HotMount;
		end

		if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("%s skipped for failing heat check (rolled %i, needed %i or less) as hot mount", gv.HotMount.name, iHeatCheck, Pokedex.db.char.mounts.iHeat); end
	end

	-- selection returned 0 mounts to choose from	
	if (#rgFiltered == 0 or cTotalRanks == 0) then 
		-- both values should be in sync
		if (#rgFiltered ~= cTotalRanks) then Pokedex:Print("ERROR: only one of #rgFiltered and cTotalRanks was zero"); end

		if (fSkippedHot) then
			if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("hot mount %s failed heat check but is apparently only one summonable", gv.HotMount.name); end
			return gv.HotMount;
		end

		if (fSkippedCur) then
			if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("current mount %s is apparently only one summonable; doing nothing", CurMount.name); end
			return; -- only summonable mount is already summoned
		end

		-- don't throw a no mounts error if they have a class form for movement
		if (not (gc.Player.GhostWolf.fHas and gc.Player.GhostWolf.fCan) and 
		    not (gc.Player.CatForm.fHas and gc.Player.CatForm.fCan)) then
			Pokedex:Print(L["ERROR: You have no summonable mounts."]);
		end
		return;
	end

	
	-- only one mount to choose from
	if (#rgFiltered == 1) then
		local mount = rgFiltered[1];
		if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("%s is apparently only one summonable", mount.name); end
		return rgFiltered[1];
	end		

	-- multiple mounts
	local cRank = mrandom(1,cTotalRanks);
	if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("random roll from 1 to %i produced %i", cTotalRanks, cRank); end
	for _, mount in ipairs(rgFiltered) do
		cRank = cRank - mount.rank;
		if (DC.MOUNTS >= DL.AV) then Pokedex:Printf("%s's rank of %i brings total down to %i", mount.name, mount.rank, cRank); end
		if (cRank <= 0) then -- found our slot
			if (DC.MOUNTS >= DL.BASIC) then Pokedex:Printf("random selection has chosen %s", mount.name); end
			return mount;
		end
	end

	if (cRank > 0) then Pokedex:Print(L["ERROR: selection error"]); end
end

--=====================================================================--
-- MOUNT BUCKETS COLLECTION
--=====================================================================--

local metaBucketList = {}
metaBucketList.__index = metaBucketList

function metaBucketList:AddBucket(bucket)
	if bucket:IsNotEmpty() then
		tinsert(self, bucket)
	end
end

--[==[
function metaBucketList:AddMount(mount)
	for _,bucket in ipairs(self) do
		if bucket:MountQualifies(mount) then
			bucket.mounts[mount] = mount.name
		end
	end
end
--]==]

function metaBucketList:SelectMount(...)
	for _,bucket in ipairs(self) do
		local mount = bucket:SelectMount(...)
		if mount then 
			-- Pokedex:Printf("selected %s from %s", mount.name, bucket.name)
			return mount 
		end
	end
end

function metaBucketList:Filter(flagsRequired)
	-- print("bucket list filter called with flags", flagsRequired)
	local filteredList = setmetatable( {}, metaBucketList )
	if type(flagsRequired) == "number" then
		for order,bucket in ipairs(self) do
			if bucket.flagsSupported and band(bucket.flagsSupported, flagsRequired) == flagsRequired then
				-- print("matched bucket", order, bucket.name)
				tinsert(filteredList, bucket)
			end
		end
	end
	return filteredList
end


--=====================================================================--
-- MOUNTS COLLECTION CLASS DEFINITION
--=====================================================================--

local function MakeMountBucket(name, flagsIncluded, flagsSupported)
	return setmetatable( { name = name, flagsIncluded = flagsIncluded, flagsSupported = flagsSupported }, metaMountBucket )
end

local CMounts = { 
	numOwned = -1, count = 0, sidLastSeen = 0, 
	specials = { 
			RunningWild = NewRunningWild(), 
			Tarecgosa = NewTarecgosa(),
		 }, 
	Types = {
			        ATVs = MakeMountBucket( L["Reliable Mounts"],       nil,                                       bor(MF.NoFlyZone_Legal, MF.Underwater_Legal) ),
			WaterWalkers = MakeMountBucket(   "WaterWalkers",           nil,                                       bor(MF.NoFlyZone_Legal, MF.Underwater_Legal) ),
			      Flyers = MakeMountBucket( L["Flyers"],                MF.Flyer,                                      0                                        ),
			     Runners = MakeMountBucket( L["Runners"],               MF.NoFlyZone_Legal,                            MF.NoFlyZone_Legal                       ),
			     Scarabs = MakeMountBucket( L["Qiraji Scarabs"],        MF.Ahn_Qiraj,                              bor(MF.NoFlyZone_Legal, MF.Ahn_Qiraj)        ),
			     Vashjir = MakeMountBucket( L["Vashj'ir Seahorses"],    MF.Vashjir,                                bor(MF.NoFlyZone_Legal, MF.Underwater_Legal) ),
			    Swimmers = MakeMountBucket( L["Swimmers"],              MF.Swimmer,                                bor(MF.NoFlyZone_Legal, MF.Underwater_Legal) ),
			 Hydroplanes = MakeMountBucket(   "Hydroplanes",        bor(MF.Underwater_Legal, MF.Flyer),                MF.Underwater_Legal                      ),
			 Hydroponies = MakeMountBucket(   "Hydroponies",        bor(MF.Underwater_Legal, MF.NoFlyZone_Legal),  bor(MF.NoFlyZone_Legal, MF.Underwater_Legal) ),
			Unidentified = MakeMountBucket( L["Unidentified Mounts"],   MF.Unknown,                                    nil                                      ),
			    Unusable = MakeMountBucket( L["Unusable Mounts"],       MF.Unusable,                                   nil                                      ),
		},
}

gv.Mounts = setmetatable( {}, CMounts )

-- metamethod ensures that when we want mount information that it is up to date
CMounts.__index = function(t,k)
	local fUpdated = false

	local numOwned = GetNumCompanions("MOUNT") + CMounts:GetNumSpecialMounts();
	if (CMounts.numOwned ~= numOwned) then
		if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Printf("Building mount list from %i mounts to %i mounts for key access %s", CMounts.numOwned, numOwned, tostring(k)); end
		fUpdated = true
		CMounts:UpdateMounts()
	end
	return (k == "fUpdated") and fUpdated or CMounts[k]
end

function CMounts:GetNumSpecialMounts()
	local count = 0
	for name,mount in pairs(self.specials) do
		if mount.fHas then
			count = count + 1
		end
	end
	return count
end

function CMounts:GetMounts()
	local fInitialized  = (self.count > 0)  -- count instead of numOwned because you can own unusable mounts and we want that to be same as owning nothing

	self.BySID   = { [0] = gc.nomount }  -- key(number) is spellID     value(table)  is mount
	self.ByName  = { [0] = gc.nomount }  -- key(string) is mount name  value(table)  is mount
	self.ByIndex = { [0] = gc.nomount }  -- key(number) is name order  value(table)  is mount

	-- find and add standard mounts
	local numOwned = GetNumCompanions("MOUNT")
	for index=1, numOwned do
		local cid, name, sid, icon, active, gameflags = GetCompanionInfo("MOUNT", index)

		if (not fInitialized) then
			if (name == nil) then
				-- TODO: retest scenario where cache has been deleted
				if (DC.MISC >= DL.BASIC) then Pokedex:Print("unable to initialize, missing mount names"); end
				return false;
			end

			if (not gc.rgMountAttributes[sid]) then
				Pokedex:Printf(L["ERROR: unrecognized mount %s %s. Please submit a bug for this error."], tostring(sid), name)
			end
			
			-- sanity checks that unique ids really are, only do on first pass
			assert(self.ByName[name] == nil, "duplicate mount name found")
			assert(self.BySID[sid] == nil, "duplicate mount spellID found")
		end

		local mount = { name = name, sid = sid, index = index }
		mount.rawflags, mount.skill, mount.cloudserpent = GetMountAttributes(sid, gameflags)
		mount.flags = mount.rawflags -- setting a value here so we don't have to worry about __newindex later
		mount = setmetatable( mount, metaMount )

		self.BySID[sid] = mount
		self.ByName[name] = mount
		self.ByIndex[index] = mount
	end
	
	for key, mount in pairs(self.specials) do
		if mount.fHas then
			numOwned = numOwned + 1
			self.BySID[mount.sid] = mount
			self.ByName[mount.name] = mount
		end
	end

	self.numOwned = numOwned

	-- if first pass this session, build known table
	if not fInitialized then
		local strknown = Pokedex.db.char.mounts.known
		local known = {}
		
		-- if first pass ever then build known out of BySID
		if (strknown == nil) then
			local strknown = ""
			for sid in pairs(self.BySID) do
				known[sid] = true
				strknown = format("%i %s", sid, strknown)
			end
			Pokedex.db.char.mounts.known = strknown
		else
			for sid in gmatch(strknown, "(%d+)") do
				known[tonumber(sid)] = true
			end
		end
		
		self.known = known
	end
end

function CMounts:UpdateMounts()
	if (self.numOwned ~= (GetNumCompanions("MOUNT") + self:GetNumSpecialMounts())) then
		self:GetMounts()
	end

	local sidCurSelection = gv.SelectedMount.sid
	local mountActive
	local mountNew

	gv.HotMount = self.BySID[Pokedex.db.char.mounts.idHot]

	self.count   = 0   -- number of usable mounts
	self.HotList = { [gc.nomount] = L["no hot mount"] }  -- key(table)  is mount  value(string) is mount name
	self.sidLastSeen = 0

	for k, bucket in pairs(self.Types) do
		bucket.mounts = {}
	end

	for sid, mount in pairs(self.BySID) do
		if sid ~= 0 then
			-- update flags - skills or settings (favor ground mounts) may have changed
			UpdateMountFlags(mount)
			local fUsableMount = not fband(mount.flags, MF.Unusable)

			-- place mounts in appropriate buckets (flyer, hydroplane, etc)
			for k, bucket in pairs(self.Types) do
				if bucket:MountQualifies(mount) then
					-- Pokedex:Printf("%s added to bucket %s", mount.name, k)
					bucket.mounts[mount] = mount.name
				end
			end

			if fUsableMount then
				self.count = self.count + 1
				self.HotList[mount] = mount.name

				-- ATV list built out of rawflags
				if band(mount.rawflags, MFS_ATV) == MFS_ATV then
					self.Types.ATVs.mounts[mount] = mount.name
				end
			end

			if mount.fActive then
				mountActive = mount
				self.sidLastSeen = sid
			end
			
			if not self.known[sid] then 
				if (DC.MOUNTS >= DL.BASIC) then Pokedex:Print("new mount found", mount.name, sid); end
				Pokedex.db.char.mounts.known = format("%i %s", sid, Pokedex.db.char.mounts.known)
				self.known[sid] = true
				mountNew = mount

				if fUsableMount and Pokedex.db.char.fEnableHotness and Pokedex.db.char.fNewHotness then
					Pokedex.db.char.mounts.idHot = sid
					gv.HotMount = mount
				end
			end
		end
	end

	-- WaterWalker bucket
	for sid in pairs(gc.rgWaterWalkingMounts) do
		local mount = self.BySID[sid]
		if mount and not fband(mount.flags, MF.Unusable) then
			self.Types.WaterWalkers.mounts[mount] = mount.name
		end
	end


	self:MakeLists()

	-- new mount > what's already selected > nomount if we have no summonable mounts > first
	self:SetSelectedMount(mountNew or mountActive or self.BySID[sidCurSelection])   -- will set gv.SelectedMountBucket and gv.SelectedMount
end


--[==[
	okay ... maybe we start to trust IsFlyableArea, NoFlyZone_Legal will be not IsFlyableArea ..
	but the flag for underwater legal will be set off of RedDrake type fFlyable
	
	Underwater_Legal  -- asked for when not flyable and isswimming         -- could be underwater or at surface of no fly zone ... those should be same for our purposes
	NoFlyZone_Legal   -- asked for when not flyable and not IsFlyableArea  -- unless fFlyable is true in which case shouldn't we believe that? so (not(fFlyable or IsFlyableArea))
--]==]

function CMounts:MakeLists()
	local types = self.Types
	local forms = gc.Player

	local MB = NewMagicBroom()
	local FlyingBroom = setmetatable( { mount = MB, name = MB.name, flagsSupported = MF.Moving_Legal }, metaFormBucket )
	local  MagicBroom = setmetatable( { mount = MB, name = MB.name, flagsSupported = MB.flags }, metaFormBucket )

	self.Lists = {}

	-- easiest way right now to deal with AhnQiraj and Vashjir, and keeping them in sync with the dry 
	-- and wet lists, is to build the standard lists out of them omitting scarabs and vashjir. easier 
	-- to omit than to insert and keeps them in sync


	-- AhnQiraj
	local AhnQiraj = setmetatable( {}, metaBucketList )
	AhnQiraj:AddBucket(forms.FlightForm)
	AhnQiraj:AddBucket(MagicBroom)
	AhnQiraj:AddBucket(types.Flyers)
	AhnQiraj:AddBucket(types.Scarabs)
	AhnQiraj:AddBucket(types.Runners)
	AhnQiraj:AddBucket(types.ATVs)
	AhnQiraj:AddBucket(forms.ZenFlight)
	AhnQiraj:AddBucket(forms.TravelForm)
	AhnQiraj:AddBucket(forms.CatForm)
	AhnQiraj:AddBucket(forms.GhostWolf)
	AhnQiraj:AddBucket(forms.BurningRush)
	AhnQiraj:AddBucket(forms.MonkRoll)
	self.Lists.AhnQiraj = AhnQiraj

	local DryOrder = setmetatable( {}, metaBucketList )
	for _, bucket in ipairs(AhnQiraj) do
		if bucket ~= types.Scarabs then
			tinsert(DryOrder, bucket)
		end
	end
	self.Lists.DryOrder = DryOrder


	-- bucket order when swimming - filtered by Underwater_Legal and NoFlyZone_Legal flags
	local Vashjir = setmetatable( {}, metaBucketList )
	local AF = forms.AquaticForm
	Vashjir:AddBucket(FlyingBroom)			-- skipped by Underwater_Legal or NoFlyZone_Legal
	Vashjir:AddBucket(types.Flyers)			-- skipped by Underwater_Legal or NoFlyZone_Legal
	if AF.glyphed then Vashjir:AddBucket(AF) end
	Vashjir:AddBucket(types.Vashjir)
	if not AF.glyphed then Vashjir:AddBucket(AF) end
	Vashjir:AddBucket(types.Swimmers)
	Vashjir:AddBucket(MagicBroom)		
	Vashjir:AddBucket(types.Hydroplanes)	-- skipped by NoFlyZone_Legal
	Vashjir:AddBucket(types.Runners)		-- skipped by Underwater_Legal
	Vashjir:AddBucket(types.WaterWalkers)
	Vashjir:AddBucket(types.Hydroponies)
	Vashjir:AddBucket(types.ATVs)
	Vashjir:AddBucket(forms.GhostWolf)
	Vashjir:AddBucket(forms.MonkRoll)
	self.Lists.Vashjir = Vashjir

	local WetOrder = setmetatable( {}, metaBucketList )
	for _, bucket in ipairs(Vashjir) do
		if bucket ~= types.Vashjir then
			tinsert(WetOrder, bucket)
		end
	end
	self.Lists.WetOrder = WetOrder
	
	-- TODO: ocean floor list to deal with buffs that give fast run speed on ocean floor?


	-- UI list - sets the order of 
	local UITypesOrder = setmetatable( {}, metaBucketList )
	UITypesOrder:AddBucket(types.Flyers)
	UITypesOrder:AddBucket(types.Runners)
	UITypesOrder:AddBucket(types.Swimmers)
	UITypesOrder:AddBucket(types.Vashjir)
	UITypesOrder:AddBucket(types.Scarabs)
	-- UITypesOrder:AddBucket(types.ATVs)
	UITypesOrder:AddBucket(types.Unidentified)
	UITypesOrder:AddBucket(types.Unusable)
	if #UITypesOrder == 0 then  -- if we have a no displayable buckets, then add placeholder
		UITypesOrder[0] = setmetatable( { mounts = { [gc.nomount] = L["no mounts available"] }, name = L["no mounts available"], flagsSupported = 0, flagsIncluded = 0 }, metaMountBucket )
	end
	self.Lists.UITypesOrder = UITypesOrder
	
	-- now create list that can be shown in dropdown
	self.Lists.UITypesDisplay = {}
	for order, bucket in pairs(UITypesOrder) do
		bucket.order = order
		self.Lists.UITypesDisplay[bucket] = bucket.name
	end
end

-- Hooking CallCompanion and DismissCompanion ensures we'll usually know what 
-- the current state is, but if the user dismisses the mount by clicking off 
-- the buff or casting a spell, we may not get the update, so always get/set 
-- current pet through these functions.

function CMounts:SetCurrent(mount)
	if (DC.MOUNTS >= DL.EXCEP) then Pokedex:Print(format("Current mount set to: %i %s", mount.sid, mount.name)); end
	self.sidLastSeen = mount.sid;
	self:SetSelectedMount(mount);
end

function CMounts:GetCurrent()
	local mount = self.BySID[self.sidLastSeen]
	if mount.fActive then
		return mount
	end

	self.sidLastSeen = 0
	if IsMounted() then
		for sid, mount in pairs(self.BySID) do
			if mount.fActive then
				self.sidLastSeen = sid
				return mount
			end
		end
	end

	return gc.nomount;
end

function CMounts:SetSelectedMount(mount)
	if #self.Lists.UITypesOrder == 0 then
		gv.SelectedMountBucket = self.Lists.UITypesOrder[0]
		gv.SelectedMount = gc.nomount
		return
	end
	
	if mount and mount ~= gc.nomount then
		for _,bucket in ipairs(self.Lists.UITypesOrder) do
			if bucket:MountInBucket(mount) then
				gv.SelectedMountBucket = bucket
				gv.SelectedMount = mount
				return
			end
		end
	end
	
	-- mount was invalid for some reason or not given
	-- select first mount from first bucket
	gv.SelectedMountBucket = self.Lists.UITypesOrder[1]
	gv.SelectedMount = gv.SelectedMountBucket:GetFirstMount()
end


--=========================================================================--
-- Easiest way to know if we can summon specific type of mount is to just
-- check the spell for summoning a specific example of that type and to
-- see if the spell is castable. IsUsableSpell does not care whether you 
-- actually have access to that mount or not.
-- returns listname, flags
--=========================================================================--
function Pokedex:GetAreaInfo()
	--=====================================================================--
	-- The IsUsableSpell checks will "fail" if the player is in a shapeshift
	-- form and the autoUnshift behavior is turned off. Work around that by
	-- temporarily enabling autoUnshift.
	--=====================================================================--
	local fHandleCVar = (GetShapeshiftForm() > 0) and not GetCVarBool("autoUnshift")
	if fHandleCVar then SetCVar("autoUnshift", 1) end
	
	--=====================================================================--
	-- The IsUsableSpell check for a flying mount will fail for druids if 
	-- they're in flight form and Auto-Dismount in Flight has been turned 
	-- off. However, if we know that we're currently flying, then it has to 
	-- be a flyable area, right?
	--=====================================================================--
	local fFlyable  = (1 == IsUsableSpell(gc.idSpellRedDrake) or IsFlying());
	local fOutdoors = (1 == IsUsableSpell(gc.idSpellRedMechanostrider) and IsOutdoors())
	local fSwimming = (1 == IsUsableSpell(gc.idSpellAbyssalSeahorse) or IsSwimming());
	local fVashjir  = (1 == IsUsableSpell(gc.idSpellAbyssalSeahorse));
	local fAhnQiraj = (1 == IsUsableSpell(gc.idSpellRedScarab));

	local flagMoving  = (GetUnitSpeed("player") > 0) and MF.Moving_Legal or 0
	local flagIndoors = not fOutdoors and MF.Indoors_Legal or 0
	local flagCombat  =  InCombatLockdown() and MF.Combat_Legal or 0
	local flagUnderwater = (not fFlyable and fSwimming) and MF.Underwater_Legal or 0
	local flagNoFlyZone = (not fFlyable and not IsFlyableArea()) and MF.NoFlyZone_Legal or 0

	if fHandleCVar then SetCVar("autoUnshift", 0) end

	--=====================================================================--
	-- Information returned by Blizzard is sometimes wrong depending on the
	-- mount and/or zone. Do fix ups based on current location.
	--=====================================================================--

	SetMapToCurrentZone();
	local mapID = GetCurrentMapAreaID();

	-- Abyssal Seahorse incorrectly returns as usable outside of Vashjir.
	if (fVashjir) then
		fVashjir = mapID == 614 or -- Abyssal Depths
		           mapID == 610 or -- Kelp'thar Forest
		           mapID == 615;   -- Shimmering Expanse
	end

	-- IsFlyableArea incorrectly returns true inside some instances and scenarios
	if (flagNoFlyZone == 0 and
		(mapID == 874 or  -- Scarlet Monastery
		 mapID == 882 or  -- Unga Ingoo
		 mapID == 914)    -- Dagger in the Dark
		) then
		flagNoFlyZone = MF.NoFlyZone_Legal
	end


	local flags = bor(flagNoFlyZone, flagUnderwater, flagMoving, flagIndoors, flagCombat)

	if fSwimming then
		if fVashjir then
			return "Vashjir", flags
		else
			return "WetOrder", flags
		end
	else
		if fAhnQiraj then
			return "AhnQiraj", flags
		else
			return "DryOrder", flags
		end
	end
end

--=========================================================================--
--=========================================================================--
--
-- PLAYER CLASS FUNCTIONS
--
--=========================================================================--
--=========================================================================--

local function HasMajorGlyph(idSpell)
	return select(4,GetGlyphSocketInfo(GLYPH_ID_MAJOR_1)) == idSpell or 
	       select(4,GetGlyphSocketInfo(GLYPH_ID_MAJOR_2)) == idSpell or 
	       select(4,GetGlyphSocketInfo(GLYPH_ID_MAJOR_3)) == idSpell
end

local function HasMinorGlyph(idSpell)
	return select(4,GetGlyphSocketInfo(GLYPH_ID_MINOR_1)) == idSpell or 
	       select(4,GetGlyphSocketInfo(GLYPH_ID_MINOR_2)) == idSpell or 
	       select(4,GetGlyphSocketInfo(GLYPH_ID_MINOR_3)) == idSpell
end

local CPlayer = {}
gc.Player = setmetatable( CPlayer, { 
		__index = function(t,k)
			setmetatable(t,nil)
			
			local _, strClass = UnitClass("player");
			t.fDeathKnight = (strClass == "DEATHKNIGHT");
			t.fDruid       = (strClass == "DRUID");
			t.fHunter      = (strClass == "HUNTER");
			t.fMage        = (strClass == "MAGE");
			t.fMonk        = (strClass == "MONK");
			t.fPaladin     = (strClass == "PALADIN");
			t.fPriest      = (strClass == "PRIEST");
			t.fRogue       = (strClass == "ROGUE");
			t.fShaman      = (strClass == "SHAMAN");
			t.fWarlock     = (strClass == "WARLOCK");
			t.fWarrior     = (strClass == "WARRIOR");

			local MissingForm = setmetatable( { mount = { fHas = false } }, metaFormBucket )
			t.GhostWolf    = MissingForm
			t.ZenFlight    = MissingForm
			t.MonkRoll     = MissingForm
			t.BurningRush  = MissingForm
			t.FlightForm   = MissingForm
			t.AquaticForm  = MissingForm
			t.TravelForm   = MissingForm
			t.CatForm      = MissingForm

			t.getters = {}
			t.__index = function(tab,k)
					local func = tab.getters[k]
					if type(func) == "function" then
						return func(tab)
					end
					return nil
				end

			t.strCombatMacro = "/Pokedex DismissMount"
			t.strCastOnMount = ""  -- only prepended to mounts that don't use GCD -- REVIEW should we get a "regular mount" that needs a gcd then we'll have a problem working the /cancelform in right
			-- strCastOnDismount = function(self) return "" end,  -- is this needed or is always going to already be inside of Combat Macro and OnMount?
			t:UpdatePlayerInfo()
			
			setmetatable(t,t)
			return t[k];
		end,
	} );

function CPlayer:UpdatePlayerInfo()
	-- print("updating class info")

	local get_rank = function(t) return Pokedex.db.profile.mounts.iDefaultRank end
	local get_fActive = function(t) return UnitBuff("player", t.name) end

	local metaFormShared = {
		__lt = gs.MountsByName,
		__index = function(t,k)
				local getter = t.getters[k]
				if (type(getter) == "function") then
					return getter(t,k)
				elseif (type(getter) == "table") then
					return getter[k]
				else
					return getter
				end
			end,
		__newindex = function(t,k,v)
				Pokedex:Print("unexpected table assingment", t.name, k, v)
			end,
	}			
	
	if self.fDeathKnight then
		if Pokedex.db.profile.fDKCastHornWithMount and IsSpellKnown(gc.idSpellHornOfWinter) then
			self.strCastOnMount = nil
			local strCastHorn = format("/cast [nomounted, @player] %s\n", GetSpellInfo(gc.idSpellHornOfWinter))
			self.getters.strCastOnMount = function(t) return (GetSpellCooldown(gc.idSpellHornOfWinter) == 0) and strCastHorn or "" end
		end
	end

	if self.fRogue then
		local strCancelDisguise = format("/cancelaura %s\n", GetSpellInfo(gc.idSpellRogueDisguise))
		self.strCastOnMount = Pokedex.db.profile.fRogueRemoveDisguise and strCancelDisguise or ""
	end

	if self.fShaman then
		local fWaterWalk = Pokedex.db.profile.fShamanCastWaterWalkingWithMount and IsSpellKnown(gc.idSpellWaterWalking)
		local strGhostWolf = GetSpellInfo(gc.idSpellGhostWolf)
		local strWaterWalking = GetSpellInfo(gc.idSpellWaterWalking)

		-- create the Ghost Wolf Mount
		local GhostWolf = setmetatable( { 
				sid = gc.idSpellGhostWolf,
				name = strGhostWolf,
				fHas = IsSpellKnown(gc.idSpellGhostWolf),
				fCan = Pokedex.db.profile.fShamanUseGhostWolf,
				fOnGCD = true,
				flags = bor(MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Indoors_Legal, MF.Combat_Legal, MF.Moving_Legal),
				strMacro = format("/cast [nomounted] %s\n/Pokedex DismissMount", strGhostWolf),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
				},
			}, metaFormShared )
		-- create the Ghost Wolf Bucket
		self.GhostWolf = setmetatable( { mount = GhostWolf,
		                                  name = GhostWolf.name,
		                        flagsSupported = GhostWolf.flags }, metaFormBucket )

		if GhostWolf.fHas and GhostWolf.fCan then
			self.strCombatMacro = GhostWolf.strMacro
		end

		self.strCastOnMount = format("%s%s",
			(GhostWolf.fHas and GhostWolf.fCan) and "/cancelform\n" or "",
			fWaterWalk and format("/cast [nomounted, @player] %s\n", strWaterWalking) or "")
	end

	if self.fMonk then
		local strZenFlight = GetSpellInfo(gc.idSpellMonkZenFlight)
		local strMonkRoll = GetSpellInfo(gc.idSpellMonkRoll)

		-- create the Zen Flight Mount
		-- note: flight requirements should be handled seemlessly by the bucket selection code
		local ZenFlight = setmetatable( { 
				sid = gc.idSpellMonkZenFlight,
				name = strZenFlight,
				fHas = IsSpellKnown(gc.idSpellMonkZenFlight),
				fCan = Pokedex.db.profile.fMonkUseZenFlight,
				fOnGCD = true,
				flags = MF.Moving_Legal,
				strMacro = format("/cast [nomounted] %s", strZenFlight),
				-- strMacro = format("/cast [nomounted] %s\n/Pokedex DismissMount", strZenFlight),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
				},
			}, metaFormShared )
		-- create the Zen Flight Bucket
		self.ZenFlight = setmetatable( { mount = ZenFlight,
		                                  name = ZenFlight.name,
		                        flagsSupported = ZenFlight.flags }, metaFormBucket )

		-- create the Monk Roll Mount
		local MonkRoll = setmetatable( { 
				sid = gc.idSpellMonRoll,
				name = strMonkRoll,
				fHas = IsSpellKnown(gc.idSpellMonkRoll),
				fCan = Pokedex.db.profile.fMonkUseRoll,
				fOnGCD = true,
				flags = bor(MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Indoors_Legal, MF.Combat_Legal, MF.Moving_Legal),
				strMacro = format("/cast [nomounted] %s\n", strMonkRoll),
				-- strMacro = format("/cast [nomounted] %s\n/Pokedex DismissMount", strMonkRoll),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
				},
			}, metaFormShared )
		-- create the Monk Roll Bucket
		self.MonkRoll = setmetatable( { mount = MonkRoll,
		                                 name = MonkRoll.name,
		                       flagsSupported = MonkRoll.flags }, metaFormBucket )

		-- create combat macro
		-- in combat we can roll, de-cloud or dismount
		self.strCombatMacro = format("%s%s/Pokedex DismissMount",
			(MonkRoll.fHas and MonkRoll.fCan) and MonkRoll.strMacro or "",
			format("/cancelaura %s\n", strZenFlight))
	end

	if self.fWarlock then
		local fMountsWaterWalk = HasMinorGlyph(gc.idSpellGlyphOfNightmares)
		local strBurningRush = GetSpellInfo(gc.idSpellBurningRush) or "Burning Rush"
		local strMacroFormat = [==[
/cast [nomounted] %s
/cancelaura %s
/Pokedex DismissMount]==]

		-- when glyphed, warlock class mounts can walk on water
		gc.rgWaterWalkingMounts[23161] = fMountsWaterWalk or nil  -- Dreadsteed
		gc.rgWaterWalkingMounts[5784]  = fMountsWaterWalk or nil  -- Felsteed

		-- create the BurningRush Mount		
		local BurningRush = setmetatable( { 
				sid = gc.idSpellBurningRush,
				name = strBurningRush,
				fHas = IsSpellKnown(gc.idSpellBurningRush),
				fCan = Pokedex.db.profile.fWarlockUseBurningRush,
				fOnGCD = true,
				flags = bor(MF.NoFlyZone_Legal, MF.Indoors_Legal, MF.Combat_Legal, MF.Moving_Legal),
				strMacro = format(strMacroFormat, strBurningRush, strBurningRush),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
				},
			}, metaFormShared )

		-- create the BurningRush Bucket
		self.BurningRush = setmetatable( { mount = BurningRush,
		                                    name = BurningRush.name,
		                          flagsSupported = BurningRush.flags }, metaFormBucket )
		
		if BurningRush.fHas and BurningRush.fCan then
			self.strCombatMacro = BurningRush.strMacro
		end

		local strCancelRush = (BurningRush.fHas and BurningRush.fCan) and format("/cancelaura %s\n", strBurningRush) or ""
		if Pokedex.db.profile.fWarlockCastWaterWalkingWithMount and IsSpellKnown(gc.idSpellUnendingBreath) and IsSpellKnown(gc.idSpellSoulburn) then
			local strBurn   = format("/cast [nomounted, @player] %s\n", GetSpellInfo(gc.idSpellSoulburn))
			local strBreath = format("/cast [nomounted, @player] %s\n", GetSpellInfo(gc.idSpellUnendingBreath))
			local strBuffName, strBuffRank = GetSpellInfo(gc.idSpellSoulburnedUnendingBreath)

			self.strCastOnMount = nil
			self.getters.strCastOnMount = function(t)
					local expires = select(7, UnitBuff("player", strBuffName, strBuffRank)) or 0
					local fHasShards = UnitPower("player", SPELL_POWER_SOUL_SHARDS) > 2
					local fCast = fHasShards and (expires - GetTime()) < 300
					return format("%s%s%s", strCancelRush,
						fCast and strBurn   or "",
						fCast and strBreath or "")
				end
		else
			self.strCastOnMount = strCancelRush
		end
	end
	
	if self.fDruid and Pokedex.db.profile.fDruidUseForms then
		local idSpellFlight = IsSpellKnown(gc.idSpellSwiftFlightForm) and gc.idSpellSwiftFlightForm or gc.idSpellFlightForm

		-- find out which forms we have, stance numbers vary depending on what forms are known
		local cStances = NewCounter();
		local siBear    = IsSpellKnown(gc.idSpellBearForm)    and cStances() or nil;
		local siAquatic = IsSpellKnown(gc.idSpellAquaticForm) and cStances() or nil;
		local siCat     = IsSpellKnown(gc.idSpellCatForm)     and cStances() or nil;
		local siTravel  = IsSpellKnown(gc.idSpellTravelForm)  and cStances() or nil;
		local siGround  = siTravel or siCat;
		local siTreant  = IsSpellKnown(gc.idSpellTreantForm)  and cStances() or nil;
		local siMoonkin = IsSpellKnown(gc.idSpellMoonkinForm) and cStances() or nil;
		local siFlight  = IsSpellKnown(idSpellFlight)         and cStances() or nil;
		local siTree    = IsSpellKnown(gc.idSpellTreeForm)    and cStances() or nil;

		-- spell names for use in macros
		local strAquaticForm  = GetSpellInfo(gc.idSpellAquaticForm);
		local strCatForm      = GetSpellInfo(gc.idSpellCatForm);
		local strTravelForm   = GetSpellInfo(gc.idSpellTravelForm);
		local strGroundForm   = (siGround == siTravel) and strTravelForm or strCatForm;
		local strFlightForm   = GetSpellInfo(idSpellFlight);
		local strTreantForm   = GetSpellInfo(gc.idSpellTreantForm)

		-- strCastOnMount won't be called if we will be using a form, so it will only go
		-- into macro when getting on a regular mount. Use that to cancel out of any forms,
		-- like cat or bear, but let them stay in Moonkin form.
		-- /cancelform isn't working when in treant form which probably has to do with 
		-- the fact that in macros [stance:5] is false and [stance:0] is true :(
		self.strCastOnMount = format("%s/cancelform%s\r", 
			siTreant and format("/cancelaura %s\r", strTreantForm) or "",
			siMoonkin and format(" [nostance:%i]", siMoonkin) or "");

		-- this is the template used when a form is selected as the mount to be summoned, not used
		local strMacroFormat = format("%s%s%s", 
			"/Pokedex DismissMount\r",
			"/cancelform [nostance:%i]\r",
			"/cast %s\r");

		-- create Flight Form Mount
		local FlightForm = setmetatable( { 
				sid = idSpellFlight,
				name = strFlightForm,
				fHas = siFlight ~= nil,
				fOnGCD = true,
				flags = MF.Moving_Legal,
				strMacro = format(strMacroFormat, siFlight, strFlightForm),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
					fCan = function(t) return Pokedex.db.profile.fDruidUseForms and not IsSwimming() end,
				},
			}, metaFormShared )
		-- create Flight Form Bucket
		self.FlightForm = setmetatable( { mount = FlightForm,
		                                   name = FlightForm.name,
		                         flagsSupported = FlightForm.flags }, metaFormBucket )

		-- create Aquatic Form Mount
		local AquaticForm = setmetatable( { 
				sid = gc.idSpellAquaticForm,
				name = strAquaticForm,
				fHas = siAquatic ~= nil,
				fOnGCD = true,
				flags = bor(MF.Swimmer, MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Combat_Legal, MF.Moving_Legal),
				strMacro = format(strMacroFormat, siAquatic, strAquaticForm),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
					fCan = function(t) return Pokedex.db.profile.fDruidUseForms and (IsSwimming() or IsUsableSpell(gc.idSpellAquaticForm)) end,
				},
			}, metaFormShared )
		-- create Aquatic Form Bucket
		self.AquaticForm = setmetatable( { mount = AquaticForm,
		                                    name = AquaticForm.name,
		                                 glyphed = HasMinorGlyph(gc.idSpellGlyphOfAquaticForm),
		                          flagsSupported = AquaticForm.flags }, metaFormBucket )

		-- create Travel Form Mount
		local TravelForm = setmetatable( { 
				sid = gc.idSpellTravelForm,
				name = strTravelForm,
				fHas = siTravel ~= nil,
				fCan = Pokedex.db.profile.fDruidUseForms,
				fOnGCD = true,
				flags =  bor(MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Combat_Legal, MF.Moving_Legal),
				strMacro = format(strMacroFormat, siTravel, strTravelForm),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
				},
			}, metaFormShared )
		-- create Travel Form Bucket
		self.TravelForm = setmetatable( { mount = TravelForm,
		                                   name = TravelForm.name,
		                         flagsSupported = TravelForm.flags }, metaFormBucket )

		-- create Cat Form Mount
		local CatForm = setmetatable( { 
				sid = gc.idSpellCatForm,
				name = strCatForm,
				fHas = siCat ~= nil,
				fCan = Pokedex.db.profile.fDruidUseForms,
				fOnGCD = true,
				flags =  bor(MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Combat_Legal, MF.Moving_Legal, MF.Indoors_Legal),
				strMacro = format(strMacroFormat, siCat, strCatForm),
				getters = {
					rank = get_rank,
					fActive = get_fActive,
				},
			}, metaFormShared )
		-- create Cat Form Bucket
		self.CatForm = setmetatable( { mount = CatForm,
		                                name = CatForm.name,
		                      flagsSupported = CatForm.flags }, metaFormBucket )


		--=====================================================================--
		-- build big macro for use in combat
		--=====================================================================--

		local strCombatCancel = format("%s%s%s", 
			siAquatic and format("[nostance:%i,swimming]", siAquatic) or "", 
			siCat     and format("[nostance:%i,noswimming,indoors]", siCat) or "",
			siGround  and format("[nostance:%i/%i,noswimming,noindoors,nomounted]", siGround, siFlight or siGround) or "");

		local strCombatCast = format("%s%s%s", 
			siAquatic and format("[swimming]%s; ", strAquaticForm) or "", 
			siCat     and format("[indoors]%s; ", strCatForm) or "",
			siGround  and format("[%snomounted] %s", siFlight and format("nostance:%i,", siFlight) or "", strGroundForm) or "");

		self.strCombatMacro = format("%s%s%s/Pokedex DismissMount",
			(strCombatCancel ~= "") and format("/cancelform %s\n", strCombatCancel) or "",
			(strCombatCast ~= "") and format("/cast %s\n", strCombatCast) or "",
			siFlight and format("/cancelform [stance:%i]\n", siFlight) or "");
	end
end


--=========================================================================--
--=========================================================================--
--
-- COMPANION FUNCTIONS
--
--=========================================================================--
--=========================================================================--

function Pokedex:ZONE_CHANGED_NEW_AREA(...)
	-- self:Printf("ZONE_CHANGED_NEW_AREA EVENT:  %s", self:StrFromVarArg(nil, ...));
	if (self.db.profile.fAutoSummonCompanion and self:GetCurrentPet() == gc.nopet and gv.Pets.count > 0) then
		if not (IsMounted() or UnitInVehicle("player") or UnitOnTaxi("player") or UnitIsDeadOrGhost("player")) then
			self:SummonCompanion()
		end
	end
end

function Pokedex:ToggleCompanion()
	if (self:GetCurrentPet() == gc.nopet) then
		self:SummonCompanion();
	else
		self:DismissCompanion();
	end
end

function Pokedex:DismissCompanion()
	local pid = cpj.GetSummonedPetGUID()
	if (pid) then cpj.SummonPetByGUID(pid) end
	self:SetSelectedPet(gc.nopet)
end

function Pokedex:SummonCompanion(fNext)
	local pet = self:SelectPet(fNext);
	if (pet ~= nil) then
		self:SummonSelectedPet(pet);
	end
end

function Pokedex:SummonSelectedPet(pet)
	assert(pet ~= nil)
	assert(#pet.pids > 0)
	local pidSummon, strName

	if (#pet.pids == 1) then
		pidSummon = pet.pids[1]
		local _, customName = cpj.GetPetInfoByPetID(pidSummon)
		strName = customName or pet.name
	else -- multiple copies of the pet, select the best
		local function petPicker(a,b)
			-- puts best at index 1
			if ((a.customName ~= nil) ~= (b.customName ~= nil)) then
				return a.customName ~= nil
			elseif (a.fave ~= b.fave) then
				return a.fave
			else
				return a.level > b.level
			end
		end

		local pets = {}
		for i,pid in ipairs(pet.pids) do
			local _, customName, level = cpj.GetPetInfoByPetID(pid)
			local fave = cpj.PetIsFavorite(pid)
			pets[i] = { pid = pid, customName = customName, fave = fave, level = level }
		end
		sort(pets, petPicker)
		pidSummon = pets[1].pid
		strName = pets[1].customName or pet.name
	end

	if (not UnitAffectingCombat("player")) then
		cpj.SummonPetByGUID(pidSummon)
		self:AnnounceSummon(strName);
		self:SetSelectedPet(pet)
		LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
	end		
end

function Pokedex:GetCurrentPet()
	local pid = cpj.GetSummonedPetGUID() or 0
	return gv.Pets.ByPID[pid]
end

function Pokedex:SetSelectedPet(pet)
	pet = pet or gc.nopet
	if (gv.Pets.All[pet] ~= nil) then
		-- nopet is only found in All when we actually own 0 pets
		gv.SelectedPet = pet
	elseif (gv.Pets.count > 0) then
		-- Should hit this case when we own pets, but there wasn't one that
		-- called out to be set for ranking. In that case, take the first.
		gv.SelectedPet = gv.Pets.ByIndex[1]
	else
		-- should never actually get here
		assert(false, pet.name)
		gv.SelectedPet = pet
	end
end

function Pokedex:SelectPet(fNext)
--[==[
	local isUsable, notEnoughMana = IsUsableSpell(gc.idSpellBattlePet)
	if (not isUsable or notEnoughMana) then
		if (DC.PETS >= DL.BASIC) then self:Print("IsUsableSpell failed for pets", isUsable, notEnoughMana); end
	end
--]==]
	if (GetSpellCooldown(gc.idSpellBattlePet) ~= 0) then
		if (DC.PETS >= DL.BASIC) then self:Print("in cooldown, ignore this summons attempt"); end
		return
	end

	local CurPet = self:GetCurrentPet();
	local rgPets = gv.Pets.ByIndex

	local fHasSnowballs = true;  -- used to check inventory for snowballs, this could be changed to be a calender check for Winter Veil
	local rgFiltered = {};
	local cTotalRanks = 0;
	local fSkippedCur = false;
	local fSkippedHot = false;

	--=====================================================================--
	-- FilterCompanions -- Local function that builds list of pets elligible
	-- for summoning as well as providing a sum of the ranks of those pets.
	-- Best done as seperate function to support different ways of calling,
	-- next pet versus random pet, and as local function we can reference 
	-- and modify variables in the scope of the calling function.
	-- NOTE: appends to rgFiltered, so multiple calls can build bigger list
	--=====================================================================--
	local function FilterCompanions(iStart, iEnd, fFirstOnly)
		if (iStart == 0 or iStart > iEnd) then
			if (DC.PETS >= DL.EXCEP) then self:Print("invalid search range"); end
			return;
		end 

		if (DC.PETS >= DL.EXCEP) then self:Print("building list of eligible pets ..."); end
		for iPet = iStart, iEnd, 1 do
			local pet = rgPets[iPet]

			-- if its ranked as 0, then it gets skipped
			if (pet.rank == 0) then
				if (DC.PETS >= DL.EXCEP) then self:Printf("%s skipped for having rank of 0", pet.name); end
			-- if we don't have snowballs and this pet requires one, then it is skipped
			elseif (not fHasSnowballs and gc.rgNeedsSnowball[pet.sid]) then
				if (DC.PETS >= DL.EXCEP) then self:Printf("%s skipped for lack of snowballs", pet.name); end
			-- if its the current companion, then it is skipped
			elseif (pet == CurPet) then
				if (DC.PETS >= DL.EXCEP) then self:Printf("%s skipped for being current companion", pet.name); end
				fSkippedCur = true;
			-- if looking for first good value, then this is it
			elseif (fFirstOnly) then
				tinsert(rgFiltered, pet);
				cTotalRanks = cTotalRanks + pet.rank;
				if (DC.PETS >= DL.BASIC) then self:Printf("%s is Next eligible pet", pet.name); end
				return;
			-- if hot pet and hotness is enabled then don't add to list, it will be handled seperately
			elseif (self.db.char.fEnableHotness and pet == gv.HotPet) then
				if (DC.PETS >= DL.EXCEP) then self:Printf("%s skipped for being hot companion", pet.name); end
				fSkippedHot = true;
			-- else its put into the pool of summonables
			else
				tinsert(rgFiltered, pet);
				cTotalRanks = cTotalRanks + pet.rank;
				if (DC.PETS >= DL.AV) then self:Printf("%s added to list of summonable pets with a rank of %i. Total rank count is %i", pet.name, pet.rank, cTotalRanks); end
			end
		end

		if (DC.PETS >= DL.BASIC) then self:Printf("list built: %i pets with a total rank of %i", #rgFiltered, cTotalRanks); end
	end
	--=====================================================================--
	-- end of local function FilterCompanions
	-- resumption of parent function SummonCompanion
	--=====================================================================--

	-- generate filtered list of elligible pets and total ranks for list
	if (fNext and CurPet ~= gc.nopet) then
		-- We can optimize our search in this case by starting immediately after current
		FilterCompanions(CurPet.index + 1, #rgPets, true);

		-- if none were found in that portion of the list, then start new search from the front of the list
		if (cTotalRanks == 0) then FilterCompanions(1, CurPet.index, true); end
	else
		FilterCompanions(1, #rgPets, fNext);
	end


	-- if we skipped the hot pet while building a list, nows the time for its heat check
	if (fSkippedHot) then
		local iHeatCheck = mrandom(1,100);
		if (self.db.char.pets.iHeat >= iHeatCheck) then
			if (DC.PETS >= DL.BASIC) then self:Printf("%s passed heat check (rolled %i, needed %i or less) and will be summoned", gv.HotPet.name, iHeatCheck, self.db.char.pets.iHeat); end
			return gv.HotPet;
		end

		if (DC.PETS >= DL.BASIC) then self:Printf("%s skipped for failing heat check (rolled %i, needed %i or less) as hot pet", gv.HotPet.name, iHeatCheck, self.db.char.pets.iHeat); end
	end

	-- selection returned 0 pets to choose from	
	if (#rgFiltered == 0 or cTotalRanks == 0) then 
		-- both values should be in sync
		if (#rgFiltered ~= cTotalRanks) then self:Print("ERROR: only one of #rgFiltered and cTotalRanks was zero"); end

		if (fSkippedHot) then
			if (DC.PETS >= DL.BASIC) then self:Printf("hot pet %s failed heat check but is apparently only one summonable", gv.HotPet.name); end
			return gv.HotPet;
		end

		if (fSkippedCur) then
			if (DC.PETS >= DL.BASIC) then self:Printf("current companion %s is apparently only one summonable; doing nothing", CurPet.name); end
			return; -- only summonable pet is already summoned
		end

		self:Print(L["ERROR: You have no summonable companions."]);
		return;
	end


	-- only one pet to choose from
	if (#rgFiltered == 1) then
		local pet = rgFiltered[1];
		if (DC.PETS >= DL.BASIC) then self:Printf("%s is apparently only one summonable", pet.name); end
		return pet;
	end

	-- multiple pets
	local cRank = mrandom(1,cTotalRanks);
	if (DC.PETS >= DL.EXCEP) then self:Printf("random roll from 1 to %i produced %i", cTotalRanks, cRank); end
	for _, pet in ipairs(rgFiltered) do
		cRank = cRank - pet.rank;
		if (DC.PETS >= DL.AV) then self:Printf("%s's rank of %i brings total down to %i", pet.name, pet.rank, cRank); end
		if (cRank <= 0) then -- found our slot
			if (DC.PETS >= DL.BASIC) then self:Printf("random selection has chosen %s", pet.name); end
			return pet;
		end  
	end

	if (cRank > 0) then self:Print(L["ERROR: selection error"]); end
end


local cpjFilters = {}

cpjFilters.__index = cpjFilters
cpjFilters.ourFlags = {
		[_G.LE_PET_JOURNAL_FLAG_COLLECTED] = true, 
		[_G.LE_PET_JOURNAL_FLAG_FAVORITES] = false, 
		[_G.LE_PET_JOURNAL_FLAG_NOT_COLLECTED] = false, }

function cpjFilters:New()
	local t = { 
		types = {},
		sources = {},
		userFlags = {},
		strSearch = _G.SEARCH,
	}

	return setmetatable(t, cpjFilters)
end

function cpjFilters:Cache(strFlags)
	-- since our search may trigger PET_JOURNAL_LIST_UPDATE events if 
	-- any of the filters are changed, we should temporarily unregister
	EventMonitor_PJListUpdate:Suspend()

	for flag, value in pairs(self.ourFlags) do
		local userValue = not cpj.IsFlagFiltered(flag)
		self.userFlags[flag] = userValue
		if (userValue ~= value) then
			cpj.SetFlagFilter(flag, value)
		end
	end

	for i=1, cpj.GetNumPetTypes() do
		if cpj.IsPetTypeFiltered(i) then
			self.types[i] = true
			cpj.SetPetTypeFilter(i, true)
		end
	end

	for i=1, cpj.GetNumPetSources() do
		if cpj.IsPetSourceFiltered(i) then
			self.sources[i] = true
			cpj.SetPetSourceFilter(i, true)
		end
	end

	self.strSearch = (_G.PetJournalSearchBox) and _G.PetJournalSearchBox:GetText() or _G.SEARCH
	if (self.strSearch ~= _G.SEARCH) then
		cpj.ClearSearchFilter()
	end
end

function cpjFilters:Restore()
	for flag,value in pairs(self.userFlags) do
		if value ~= self.ourFlags[flag] then
			cpj.SetFlagFilter(flag, value)
		end
	end

	for i,v in ipairs(self.types) do
		if v then
			cpj.SetPetTypeFilter(i, false)
		end
	end

	for i,v in ipairs(self.sources) do
		if v then
			cpj.SetPetSourceFilter(i, false)
		end
	end

	if (self.strSearch ~= _G.SEARCH) then
		cpj.SetSearchFilter(self.strSearch)
	end

	self.inuse = false

	-- register event again
	EventMonitor_PJListUpdate:Resume()
end


local metaPet = {
	__lt = gs.PetsByName,
	__index = function(t,k)
			if (k == "rank") then
				return t.char_rank or t.profile_rank
			elseif (k == "char_rank") then
				return Pokedex.db.char.pets.ranks[t.name]
			elseif (k == "profile_rank") then
				return Pokedex.db.profile.pets.ranks[t.name] or Pokedex.db.profile.pets.iDefaultRank
			else
				return nil
			end
		end,
	__newindex = function(t,k,v)
			if (k == "char_rank") then
				Pokedex.db.char.pets.ranks[t.name] = v
			elseif (k == "profile_rank") then
				Pokedex.db.profile.pets.ranks[t.name] = (Pokedex.db.profile.pets.iDefaultRank ~= v) and v or nil
			else
				Pokedex:Print("unexpected table assingment caught by metaPet", t.name, k, v)
			end
		end,
}

local CPets = { numOwned = -1, count = 0 }

gv.Pets = setmetatable( {}, CPets )

CPets.__index = function(t,k)
	-- if the number of pets has changed, build lists
	local fUpdated = false
	local _, numOwned = cpj.GetNumPets(false);
	if (CPets.numOwned ~= numOwned) then
		if (DC.PETS >= DL.EXCEP) then Pokedex:Printf("Building Pet List from %i pets to %i pets for key access %s", CPets.numOwned, numOwned, tostring(k)); end
		fUpdated = true

		-- cache current filter and search state of PetJournal and then set flags for all user pets
		local filter = cpjFilters:New()
		filter:Cache()

		CPets:UpdatePets()

		-- restore pet journal settings	
		filter:Restore()
	end

	return (k == "fUpdated") and fUpdated or CPets[k]
end

function CPets:UpdatePets()
	local fInitialized  = (self.count > 0)  -- count instead of numOwned because you can own unusable pets and we want that to be same as owning nothing
	local fFirstRun = (Pokedex.db.char.pets.known == nil)

	local count   = 0                                -- number of pet names or species
	local All     = { [gc.nopet] = L["no companions available"] }   -- key(table)  is pet  value(string) is pet name
	local HotList = { [gc.nopet] = L["no hot companion"] }          -- key(table)  is pet  value(string) is pet name

	local BySID   = { [0] = gc.nopet }  -- key(number) is speciesID   value(table)  is pet
	local ByCID   = { [0] = gc.nopet }  -- key(number) is creatureID  value(table)  is pet
	local ByPID   = { [0] = gc.nopet }  -- key(number) is petID       value(table)  is pet
	local ByName  = { [0] = gc.nopet }  -- key(string) is pet name    value(table)  is pet
	local ByIndex = { [0] = gc.nopet }  -- key(number) is name order  value(table)  is pet

	local sidCurSelection = gv.SelectedPet.sid
	local petNew
	
	local strknown = Pokedex.db.char.pets.known or ""
	local known = fInitialized and self.known or {}
	if not fInitialized and not fFirstRun then 
		for sid in gmatch(strknown, "(%d+)") do
			known[tonumber(sid)] = true
		end
	end

	local numPets, numOwned = cpj.GetNumPets(false)
	for i=1, numPets do
		local petID, speciesID, isOwned, customName, level, favorite, _, name, _, _, creatureID = cpj.GetPetInfoByIndex(i, false);
		assert(isOwned, tostring(name))

		if (not cpj.PetIsSummonable(petID)) then
			if (DC.PETS >= DL.EXCEP) then Pokedex:Print("skipping non-summonable owned pet", name); end
		else
			local pet = ByName[name];
			if (not pet) then
				assert(BySID[speciesID] == nil)
				assert(ByCID[creatureID] == nil)

				count = count + 1
				pet = setmetatable( { name = name, cid = creatureID, sid = speciesID, index = count, pids = {} }, metaPet )

				All[pet] = name
				HotList[pet] = name

				BySID[speciesID] = pet
				ByCID[creatureID] = pet
				ByName[name] = pet
				ByIndex[count] = pet

				if not known[speciesID] then
					known[speciesID] = true
					strknown = format("%i %s", speciesID, strknown)

					if not fFirstRun then
						if (DC.PETS >= DL.BASIC) then Pokedex:Print("new pet found", name, speciesID); end
						petNew = pet

						if (Pokedex.db.char.fEnableHotness and Pokedex.db.char.fNewHotness) then
							Pokedex.db.char.pets.idHot = speciesID
						end
					end
				end

--[===[
			elseif (not fInitialized) then
				-- sanity checks that unique ids really are, only do on first pass
				local petFromSID = BySID[speciesID]
				local petFromCID = ByCID[creatureID]
				assert(pet == petFromSID)
				assert(pet == petFromCID)
				assert(petFromSID == petFromCID)
--]===]
			end

			assert(ByPID[petID] == nil)
			ByPID[petID] = pet;
			tinsert(pet.pids, petID)
		end
	end

	-- if we have pets to show in our dropdown, remove the placeholder
	if (count ~= 0) then
		All[gc.nopet] = nil
	end

	self.numOwned = numOwned
	self.count   = count
	
	self.All     = All
	self.HotList = HotList

	self.BySID   = BySID
	self.ByCID   = ByCID
	self.ByPID   = ByPID
	self.ByName  = ByName
	self.ByIndex = ByIndex
	
	self.known = known
	Pokedex.db.char.pets.known = strknown

	-- new pet > active pet > what's already selected > nopet if we have no summonable pets > first
	local pidActive = cpj.GetSummonedPetGUID()
	local petActive = pidActive and ByPID[pidActive]
	Pokedex:SetSelectedPet(petNew or petActive or BySID[sidCurSelection])  -- will set gv.SelectedPet

	gv.HotPet = BySID[Pokedex.db.char.pets.idHot]
end

function Pokedex:PET_JOURNAL_LIST_UPDATE(...)
	if (DC.PETS >= DL.AV) then self:Print(...); end
	if (gv.Pets.fUpdated) then
		LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
	end
end

function Pokedex:FUpdateCompanionInfo()
	-- Funny things can happen if you access the PetJournal before the first PET_JOURNAL_LIST_UPDATE
	-- event fires. If none of the filters are touched, including just setting one to the same value 
	-- it already has, then the PetJournal will return bad information. The number of pets will be 
	-- correct, but each one is flagged as non-summonable. Since the number is correct, we won't try
	-- to rebuild the list later when the PetJournal has updated correctly. If we touch the flags, even 
	-- just setting a flag to its current value, then GetNumPets will return 0 until its propertly updated.
	cpj.SetFlagFilter(_G.LE_PET_JOURNAL_FLAG_COLLECTED, not cpj.IsFlagFiltered(_G.LE_PET_JOURNAL_FLAG_COLLECTED))
	return true
end


--=========================================================================--
--=========================================================================--
--
-- TITLE FUNCTIONS
--
--=========================================================================--
--=========================================================================--

function Pokedex:KNOWN_TITLES_UPDATE()
	if (DC.TITLES >= DL.BASIC) then self:Print("KNOWN_TITLES_UPDATE"); end
	self:UpdateTitleInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:NEW_TITLE_EARNED(...)
	if (DC.TITLES >= DL.BASIC) then self:Printf("NTE  %s", self:StrFromVarArg(nil, ...)); end
	self:UpdateTitleInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:OLD_TITLE_LOST(...)
	if (DC.TITLES >= DL.BASIC) then self:Printf("OTL  %s", self:StrFromVarArg(nil, ...)); end
	self:UpdateTitleInfo();
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:SetCurrentTitleHook(idTitle)
	gv.SelectedTitle = gv.Titles.ByTID[idTitle] or gv.Titles.ByTID[-1];
	if gv.SelectedTitle == nil then
		gv.SelectedTitle = gv.Titles.ByTID[(GetCurrentTitle())]
	end
	if (DC.TITLES >= DL.BASIC) then 
		self:Printf("Current title set to: %i %s", idTitle, gv.SelectedTitle.name); 
	end
end

-- return first the title ID and then the sorted order index
function Pokedex:GetCurrentTitle()
	local idTitle = GetCurrentTitle();
	return idTitle, gv.Titles.ByTID[idTitle];
end

function Pokedex:ChangeTitle()
	local _, CurTitle = self:GetCurrentTitle();

	local rgFiltered = {};
	local cTotalRanks = 0;
	local fSkippedCur = false;
	local fSkippedHot = false;

	-- Builds list of elligible titles for change. For mounts and pets, this
	-- is a local function; but we have no plans for NextTitle option or any
	-- other scenarios where we have to make multiple passes at the data.
	if (DC.TITLES >= DL.EXCEP) then self:Print("building list of eligible titles ..."); end
	for title in pairs(gv.Titles.All) do
		-- if its ranked as 0, then it gets skipped
		if (title.rank == 0) then
			if (DC.TITLES >= DL.EXCEP) then self:Printf("%s skipped for having rank of 0", title.name); end
		-- if its the current title, then it is skipped
		elseif (title == CurTitle) then
			if (DC.TITLES >= DL.EXCEP) then self:Printf("%s skipped for being current title", title.name); end
			fSkippedCur = true;
		-- if hot title and hotness is enabled then don't add to list, it will be handled seperately
		elseif (self.db.char.fEnableHotness and title == gv.HotTitle and title ~= gc.notitle) then
			if (DC.TITLES >= DL.EXCEP) then self:Printf("%s skipped for being hot title", title.name); end
			fSkippedHot = true;
		-- else its put into the pool of summonables
		else
			tinsert(rgFiltered, title)
			cTotalRanks = cTotalRanks + title.rank;
			if (DC.TITLES >= DL.AV) then self:Printf("%s added to list of possible titles with a rank of %i. Total rank count is %i", title.name, title.rank, cTotalRanks); end
		end
	end

	if (DC.TITLES >= DL.BASIC) then self:Printf("list built: %i titles with a total rank of %i", #rgFiltered, cTotalRanks); end

	-- if we skipped the hot title while building a list, nows the time for its heat check
	if (fSkippedHot) then
		local iHeatCheck = mrandom(1,100);
		if (self.db.char.titles.iHeat >= iHeatCheck) then
			if (DC.TITLES >= DL.BASIC) then self:Printf("%s passed heat check (rolled %i, needed %i or less) and will be selected", gv.HotTitle.name, iHeatCheck, self.db.char.titles.iHeat); end
			_G.SetCurrentTitle(gv.HotTitle.tid);
			return;
		end

		if (DC.TITLES >= DL.BASIC) then self:Printf("%s failed heat check (rolled %i, needed %i or less) and will not be selected", gv.HotTitle.name, iHeatCheck, self.db.char.titles.iHeat); end
	end

	-- selection returned 0 titles to choose from	
	if (#rgFiltered == 0 or cTotalRanks == 0) then 
		-- both values should be in sync
		if (#rgFiltered ~= cTotalRanks) then self:Print(L["ERROR: only one of #rgFiltered and cTotalRanks was zero"]); end

		if (fSkippedHot) then
			if (DC.TITLES >= DL.BASIC) then self:Printf("%s failed heat check but is only eligible title", gv.HotTitle.name); end
			_G.SetCurrentTitle(gv.HotTitle.tid);
			return
		end

		if (fSkippedCur) then
			if (DC.TITLES >= DL.BASIC) then self:Printf("%s is only one eligible; doing nothing", CurTitle.name); end
			return; -- only selectable title is already displayed
		end

		self:Print(L["ERROR: You don't have any titles."]);
		return;
	end

	
	-- only one title to choose from
	if (#rgFiltered == 1) then
		local title = rgFiltered[1];
		if (DC.TITLES >= DL.BASIC) then self:Printf("%s is apparently only title known", title.name); end
		_G.SetCurrentTitle(title.tid);
		return;
	end

	-- multiple titles
	local cRank = mrandom(1,cTotalRanks);
	if (DC.TITLES >= DL.EXCEP) then self:Printf("random roll from 1 to %i produced %i", cTotalRanks, cRank); end

	for _, title in ipairs(rgFiltered) do
		cRank = cRank - title.rank;
		if (DC.TITLES >= DL.AV) then self:Printf("%s's rank of %i brings total down to %i", title.name, title.rank, cRank); end
		if (cRank <= 0) then -- found our slot
			if (DC.TITLES >= DL.BASIC) then self:Printf("random selection has chosen %s", title.name); end
			_G.SetCurrentTitle(title.tid);
			return;
		end
	end

	if (cRank > 0) then self:Print(L["ERROR: selection error"]); end
end

local metaTitle = {
	__lt = gs.TitlesByName,
	__index = function(t,k)
			if (k == "rank") then
				return t.char_rank or t.profile_rank
			elseif (k == "char_rank") then
				return Pokedex.db.char.titles.ranks[t.name]
			elseif (k == "profile_rank") then
				return Pokedex.db.profile.titles.ranks[t.name] or Pokedex.db.profile.titles.iDefaultRank
			else
				return nil
			end
		end,
	__newindex = function(t,k,v)
			if (k == "char_rank") then
				Pokedex.db.char.titles.ranks[t.name] = v
			elseif (k == "profile_rank") then
				Pokedex.db.profile.titles.ranks[t.name] = (Pokedex.db.profile.titles.iDefaultRank ~= v) and v or nil
			else
				Pokedex:Print("unexpected table assingment caught by metaTitle", t.name, k, v)
			end
		end,
}

local CTitles = { numTitles = -1, count = 0 }

gv.Titles = setmetatable( {}, CTitles )

CTitles.__index = function(t,k)
	-- if the number of titles has changed, build lists
	local fUpdated = false
	local numTitles = GetNumTitles();
	if (CTitles.numTitles ~= numTitles) then
		if (DC.TITLES >= DL.EXCEP) then Pokedex:Printf("Building Title List from %i titles to %i titles for key access %s", CTitles.numTitles, numTitles, tostring(k)); end
		fUpdated = true
		CTitles:UpdateTitles()
	end

	return (k == "fUpdated") and fUpdated or CTitles[k]
end

function CTitles:UpdateTitles()
	local fInitialized  = (self.count > 0)  -- count instead of numTitles because you can own unusable titles and we want that to be same as owning nothing
	local fFirstRun = (Pokedex.db.char.titles.known == nil)

	gc.notitle = setmetatable( gc.notitle, metaTitle )        -- replace simple meta table, since No Title can be ranked
	local strNoTitle = _G.PLAYER_TITLE_NONE
	local count   = 0                                         -- number of titles known

	local All     = { [gc.notitle] = strNoTitle }             -- key(table)  is title  value(string) is title name
	local HotList = { [gc.notitle] = L["no hot title"] }      -- key(table)  is title  value(string) is title name

	local ByTID   = { [gc.notitle.tid] = gc.notitle }   -- key(number) is titleID       value(table)  is title
	local ByName  = {     [strNoTitle] = gc.notitle }   -- key(string) is title name    value(table)  is title
	-- local ByIndex = { [0] = gc.notitle }  -- key(number) is name order  value(table)  is title

	local tidCurSelection = gv.SelectedTitle.tid
	local titleNew
	
	local strknown = Pokedex.db.char.titles.known or ""
	local known = fInitialized and self.known or {}
	if not fInitialized and not fFirstRun then 
		for sid in gmatch(strknown, "(%d+)") do
			known[tonumber(sid)] = true
		end
	end

	local numTitles = GetNumTitles()
	for titleID = 1, numTitles do
		if (1 == IsTitleKnown(titleID)) then
			count = count + 1
			local name = strtrim((GetTitleName(titleID)))
			local title = setmetatable( { name = name, tid = titleID }, metaTitle )
			
			All[title] = name
			HotList[title] = name

			ByTID[titleID] = title
			ByName[name] = title
			
			if not known[titleID] then
				known[titleID] = true
				strknown = format("%i %s", titleID, strknown)

				if not fFirstRun then
					if (DC.TITLES >= DL.BASIC) then Pokedex:Print("new title found", name, titleID); end
					titleNew = title

					if (Pokedex.db.char.fEnableHotness and Pokedex.db.char.fNewHotness) then
						Pokedex.db.char.titles.idHot = titleID
					end
				end
			end
		end
	end

	-- if there use does not have any titles, change the string shown in the dropdown
	if (count == 0) then
		All[gc.notitle] = L["no titles available"]
	end

	self.numTitles = numTitles
	self.count     = count
	
	self.All       = All
	self.HotList   = HotList

	self.ByTID     = ByTID
	self.ByName    = ByName
	
	self.known = known
	Pokedex.db.char.titles.known = strknown

	-- new title > active title > what's already selected > notitle if we have no summonable titles > first
	gv.SelectedTitle = titleNew or ByTID[GetCurrentTitle()] or ByTID[tidCurSelection]  -- will set gv.SelectedTitle

	gv.HotTitle = ByTID[Pokedex.db.char.titles.idHot]
end

function Pokedex:UpdateTitleInfo()
	gv.Titles:UpdateTitles()
end


--=========================================================================--
--=========================================================================--
--
-- AUTO-DISMOUNT FUNCTIONS
--
--=========================================================================--
--=========================================================================--

function Pokedex:CVAR_UPDATE(_, glstr, ...)
	if (DC.DISMOUNT >= DL.EXCEP) then self:Printf("CVAR_UPDATE EVENT:  %s %s", tostring(glstr), self:StrFromVarArg(nil, ...)); end
	if (glstr == "AUTO_DISMOUNT_FLYING_TEXT") then
		self:UpdateDismountSettings();
	end
end


function Pokedex:SetManageAutoDismount(info, value)
	if (gv.iAutoDismountFlying == 1 and value) then
		if (DC.DISMOUNT >= DL.EXCEP) then self:Print("Safe Dismount enabled, disabling Auto Dismount in Flight accordingly."); end
		gv.iAutoDismountFlying = 0;
		SetCVar("autoDismountFlying", 0); --, "AUTO_DISMOUNT_FLYING_TEXT")
	end

	Pokedex.db.profile.fManageAutoDismount = value;
end


function Pokedex:UpdateDismountSettings()
	if (GetCVarBool("autoDismountFlying")) then 
		-- even though we may be reseting it back to 0, our internal state should match reality
		gv.iAutoDismountFlying = 1;

		if (self.db.profile.fManageAutoDismount) then
			if (DC.DISMOUNT >= DL.EXCEP) then self:Print("Safe Dismount is reverting someones change to the Auto Dismount in Flight setting."); end
			SetCVar("autoDismountFlying", 0); --, "AUTO_DISMOUNT_FLYING_TEXT")
		end
	else
		gv.iAutoDismountFlying = 0;
	end
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end


function Pokedex:MainTooltipShow(...)
	-- if we have gathering skills and the feature is turned on
	-- if we're not currently flying then we don't have to worry about monkeying with the setting at all
	if (self.db.profile.fManageAutoDismount and Pokedex.db.profile.fDismountForGathering and IsFlying()) then
		-- if dismount was turned on for a different condition, tooltip scraping will only cause errors
		if ((not self.db.profile.fDismountForCombat or not gv.fCanDismountForCombat) and
		    (not self.db.profile.fDismountForAttack or not gv.fCanDismountForAttack)) then

			local fGatherable = false;
			for i=1,GameTooltip:NumLines() do
				local mytext = _G["GameTooltipTextLeft" .. i];
				local text = mytext:GetText();
				fGatherable = (gv.Skills.fMiner     and strfind(text, L["Requires"]) and strfind(text, L["Mining"])) or
				              (gv.Skills.fHerbalist and strfind(text, L["Requires"]) and strfind(text, L["Herbalism"])) or
				              (gv.Skills.fSkinner   and strfind(text, L["Skinnable"]));
			end

			if (fGatherable and gv.iAutoDismountFlying == 0) then
				if (DC.DISMOUNT >= DL.BASIC) then self:Print("turning on dismount, mousing over gatherable"); end
				gv.iAutoDismountFlying = 1;
				SetCVar("autoDismountFlying", 1); --, "AUTO_DISMOUNT_FLYING_TEXT")
			elseif (fGatherable and gv.iAutoDismountFlying == 1) then
				if (DC.DISMOUNT >= DL.EXCEP) then self:Print("WEIRD - new show, but can already dismount"); end
			elseif (not fGatherable and gv.iAutoDismountFlying == 1) then
				if (DC.DISMOUNT >= DL.BASIC) then self:Print("ERROR - can dismount, but tooltip doesn't match"); end
				gv.iAutoDismountFlying = 0;
				SetCVar("autoDismountFlying", 0); --, "AUTO_DISMOUNT_FLYING_TEXT")
			end
		end
	end
end


function Pokedex:MainTooltipHide(...)
	-- we only care if gathering feature is turned on
	if (self.db.profile.fManageAutoDismount and Pokedex.db.profile.fDismountForGathering) then
		-- if dismount is already off, we don't have to do anything
		if (gv.iAutoDismountFlying == 1) then
			-- if dismount was turned on for a different condition, tooltip scraping will only cause errors
			if ((not self.db.profile.fDismountForCombat or not gv.fCanDismountForCombat) and
			    (not self.db.profile.fDismountForAttack or not gv.fCanDismountForAttack)) then
				if (DC.DISMOUNT >= DL.BASIC) then self:Print("dismount turned off, not mousing over gatherable"); end
				gv.iAutoDismountFlying = 0;
				SetCVar("autoDismountFlying", 0); --, "AUTO_DISMOUNT_FLYING_TEXT")
			end
		end
	end	
end


function Pokedex:PLAYER_TARGET_CHANGED()
	-- if feature is turned on
	if (self.db.profile.fManageAutoDismount and self.db.profile.fDismountForAttack) then
		-- if we had an attackable target
		if (gv.fCanDismountForAttack) then
			-- then only need to change if we lost one
			if (not UnitCanAttack("player", "target") or UnitIsDead("target")) then
				gv.fCanDismountForAttack = false;

				-- if in combat, don't clear based on target
				if (not self.db.profile.fDismountForCombat or not gv.fCanDismountForCombat) then
					if (DC.DISMOUNT >= DL.BASIC) then self:Print("dismount turned off, target not attackable"); end
					gv.iAutoDismountFlying = 0;
					SetCVar("autoDismountFlying", 0); --, "AUTO_DISMOUNT_FLYING_TEXT")
				end
			end
		-- if not already tracking, then don't start unless we're mounted - hopeful optimization for instances
		elseif (IsMounted()) then
			-- if we have an attackable target
			if (UnitCanAttack("player", "target") and not UnitIsDead("target")) then
				gv.fCanDismountForAttack = true;
				
				-- don't need to set if already done for being in combat
				if (not self.db.profile.fDismountForCombat or not gv.fCanDismountForCombat) then
					if (DC.DISMOUNT >= DL.BASIC) then self:Print("turning on dismount, attackable target"); end
					gv.iAutoDismountFlying = 1;
					SetCVar("autoDismountFlying", 1); --, "AUTO_DISMOUNT_FLYING_TEXT")
				end
			end
		end
	end
end


function Pokedex:PLAYER_REGEN_DISABLED()
	-- if feature is turned on
	-- if we're not currently mounted then we don't have to worry about monkeying with the setting at all
	if (self.db.profile.fManageAutoDismount and self.db.profile.fDismountForCombat and IsMounted()) then
		gv.fCanDismountForCombat = true;

		if (gv.iAutoDismountFlying == 0) then
			if (DC.DISMOUNT >= DL.BASIC) then self:Print("turning on dismount, in combat"); end
			gv.iAutoDismountFlying = 1;
			SetCVar("autoDismountFlying", 1); --, "AUTO_DISMOUNT_FLYING_TEXT")
		end
	end
end


function Pokedex:PLAYER_REGEN_ENABLED()
	-- if feature is turned on
	if (self.db.profile.fManageAutoDismount and self.db.profile.fDismountForCombat) then
		-- out of combat, so this will no longer be the reason why we can dismount
		gv.fCanDismountForCombat = false;

		-- if can dismount is already 0, then there's nothing left to change
		if (gv.iAutoDismountFlying == 1) then
			-- if dismount can occur for attackable target, don't clear for out of combat
			if (not self.db.profile.fDismountForAttack or not gv.fCanDismountForAttack) then
				if (DC.DISMOUNT >= DL.BASIC) then self:Print("dismount turned off, out of combat"); end
				gv.iAutoDismountFlying = 0;
				SetCVar("autoDismountFlying", 0); --, "AUTO_DISMOUNT_FLYING_TEXT")
			end
		end
	end	
end

