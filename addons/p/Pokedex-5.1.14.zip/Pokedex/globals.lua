Pokedex = LibStub("AceAddon-3.0"):NewAddon("Pokedex", "AceConsole-3.0", "AceEvent-3.0", "AceHook-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("Pokedex")

-- upvalues
local _G, Pokedex, assert, pairs, setmetatable, type = _G, Pokedex, assert, pairs, setmetatable, type
local bnot, band, bor, bxor = bit.bnot, bit.band, bit.bor, bit.bxor

--=========================================================================--
-- Keybinding globals --
--=========================================================================--
BINDING_HEADER_POKEDEX = L["Pokedex"]
BINDING_NAME_POKEDEXSUMMONMOUNT = L["Summon Mount"]
BINDING_NAME_POKEDEXDISMISSMOUNT = L["Dismiss Mount"]
BINDING_NAME_POKEDEXTOGGLEMOUNT = L["Toggle Mount"]
BINDING_NAME_POKEDEXSUMMONNEXTMOUNT = L["Summon Next Mount"]
BINDING_NAME_POKEDEXSUMMONOTHERMOUNT = L["Summon Other Mount"]
BINDING_NAME_POKEDEXSUMMONCOMPANION = L["Summon Companion"]
BINDING_NAME_POKEDEXDISMISSCOMPANION = L["Dismiss Companion"]
BINDING_NAME_POKEDEXTOGGLECOMPANION = L["Toggle Companion"]
BINDING_NAME_POKEDEXSUMMONNEXTCOMPANION = L["Summon Next Companion"]
BINDING_NAME_POKEDEXSUMMONVENDOR = L["Summon Vendor"]
BINDING_NAME_POKEDEXCHANGETITLE = L["Change Title"]



Pokedex.Globals = {}

--=========================================================================--
-- (fake) Enum Types		TODO: find a way to make these constants
--=========================================================================--

Pokedex.Globals.Types = {}

local function BuildReverseSet(list)
	local set = {}
	for k, v in pairs(list) do set[v] = k end
	return set
end


-- Initialization States
local IS = {
	INITIALIZED   = 0,
	INITIALIZING  = 1,
	UNINITIALIZED = 2,
}
Pokedex.Globals.Types.InitStates = IS


-- Debug Levels
local DL = {
	NONE   = 0,   -- no debug output
	BASIC  = 1,   -- most basic level of information
	EXCEP  = 2,   -- interesting exceptions and special cases
	AV     = 3,   -- annoyingly verbose
	MAX    = 3,   -- used for range checking
}
Pokedex.Globals.Types.DebugLevels = DL


-- Skill Levels - max rank of each skill level
local SL = {
	ZenMaster   = 600,
	Illustrious = 525,
	GrandMaster = 450,
	Master      = 375,
	Artisan     = 300,
	Expert      = 225,
	Journeyman  = 150,
	Apprentice  = 75,
	None        = 0
}
Pokedex.Globals.Types.SkillLevels = SL

-- Skill Ids - skillLine constant for a profession
local SI = {
	[762] = "Riding",

	[182] = "Herbalism",
	[186] = "Mining",
	[393] = "Skinning",

	[171] = "Alchemy",
	[164] = "Blacksmithing",
	[333] = "Enchanting",
	[202] = "Engineering",
	[773] = "Inscription",
	[755] = "Jewelcrafting",
	[165] = "Leatherworking",
	[197] = "Tailoring",
}
Pokedex.Globals.Types.SkillIds = SI


-- Mount Flags
local rgstrMountFlags = {
	[0x0001] = "Unusable",
	[0x0002] = "Unknown",
	[0x0004] = "Flyer",
	[0x0008] = "Swimmer",    -- has a faster than normal swim speed. implies Underwater_Legal, REVIEW whether both flags should be set
	[0x0010] = "Walker",     -- has a slower than normal ground speed. implies NoFlyZone_Legal, REVIEW whether both flags should be set
	[0x0020] = "Vashjir",    -- abyssal seahorse
	[0x0040] = "Ahn_Qiraj",  -- quiraji scarab mounts
	[0x0080] = "NoFlyZone_Legal",
	[0x0100] = "Underwater_Legal",
	[0x0200] = "Indoors_Legal",
	[0x0400] = "Combat_Legal",
	[0x0800] = "Moving_Legal",
}
local MF = BuildReverseSet(rgstrMountFlags)
Pokedex.Globals.Types.MountFlags = MF

-- a composite flagset lets us only do the bit operation only once instead of once per mount of that type
local MFS_ATV          = bor(MF.Flyer, MF.NoFlyZone_Legal, MF.Underwater_Legal)
local MFS_Runner       = bor(MF.NoFlyZone_Legal, MF.Underwater_Legal)
local MFS_Hydroplane   = bor(MF.Flyer, MF.Underwater_Legal)
local MFS_Hydrophobe   = bor(MF.Flyer, MF.NoFlyZone_Legal)
local MFS_Black_Scarab = bor(MF.NoFlyZone_Legal, MF.Underwater_Legal, MF.Ahn_Qiraj)
local MFS_Sea_Turtle   = bor(MF.Swimmer, MF.Walker)


-- mount breeds
local rgstrMountBreeds = {
	[0] = "Unsorted",
	"Bear",
	"Camel",
	"Carpet",
	"Cloud",
	"CloudSerpent",
	"Crane",
	"Direhorn",
	"Dragonhawk",
	"DragonTurtle",
	"Drake",
	"Elekk",
	"FireHawk",
	"FlyingMachine",
	"Goat",
	"Gryphon",
	"Hawkstrider",
	"Hippogryph",
	"Horse",
	"Kite",
	"Kodo",
	"Mammoth",
	"Mechanostrider",
	"Motorcycle",
	"NetherRay",
	"Panther",
	"Phoenix",
	"ProtoDrake",
	"Quilen",
	"Ram",
	"Raptor",
	"Raven",
	"Rhino",
	"Rocket",
	"Saber",
	"Scarab",
	"Scorpion",
	"Seahorse",
	"Talbuk",
	"Tallstrider",
	"Turtle",
	"WaterStrider",
	"WindRider",
	"Wolf",
	"Yak",
}
local MB = BuildReverseSet(rgstrMountBreeds)
Pokedex.Globals.Types.MountBreeds = MB


-- event monitor class - used to temporarily ignore an event in a recursion/rentrancy safe way
local CEventMonitor = { module = Pokedex }
CEventMonitor.__index = CEventMonitor
function CEventMonitor:Create(eventName, handler)
	assert(type(eventName) == "string")
	return setmetatable( { refCount = 0, eventName = eventName, handler = handler or eventName }, CEventMonitor )
end
function CEventMonitor:Suspend()
	if self.refCount == 1 then 
		self.module:UnregisterEvent(self.eventName)
	end
	self.refCount = self.refCount - 1
end
function CEventMonitor:Resume()
	self.refCount = self.refCount + 1
	if self.refCount == 1 then 
		self.module:RegisterEvent(self.eventName, self.handler)
	end
end
Pokedex.Globals.Types.CEventMonitor = CEventMonitor


--=========================================================================--
-- global sort methods
-- tables can be sorted against each other if they each  have the same __lt metamethod
--=========================================================================--

Pokedex.Globals.SortMethods = {}
local gs = Pokedex.Globals.SortMethods

gs.ByIdReversed = function(a,b) return a.id > b.id end
gs.ByName = function(a,b) return a.name < b.name end
gs.ByOrder = function(a,b) return a.order < b.order end 

gs.MountsByName = function(a, b)
	if a.sid > 0 and b.sid > 0 then
		return a.name <  b.name
	else
		return a.sid < b.sid
	end
end

gs.PetsByName = function(a, b) 
	if a.sid > 0 and b.sid > 0 then
		return a.name <  b.name
	else
		return a.sid < b.sid
	end
end

gs.TitlesByName = function(a, b)
	if a.tid > 0 and b.tid > 0 then
		return a.name <  b.name
	else
		return a.tid < b.tid
	end
end


local nomount = setmetatable( { name = "NONE", index =  0, rank = 0, profile_rank = 0, sid = 0, flags = 0, fActive = false, fHas = false, fCan = false }, 
                              { __lt = gs.MountsByName } )
local nopet   = setmetatable( { name = "NONE", index =  0, rank = 0, profile_rank = 0, sid = 0, cid = 0, pids = {0} }, 
                              { __lt = gs.PetsByName   } )
local notitle = setmetatable( { name = "NONE", tid = -1 }, 
                              { __lt = gs.TitlesByName } )

--=========================================================================--
-- global variables
--=========================================================================--

Pokedex.Globals.Variables = {
-- addon infrastructure
	InitState = IS.UNINITIALIZED,

-- skills
	Skills = {},

-- mounts
	SelectedMountBucket,
	SelectedMount = nomount,
	HotMount = nomount,

-- companions
	SelectedPet = nopet,
	HotPet = nopet,

-- titles
	SelectedTitle = notitle,
	HotTitle = notitle,

-- dismount
	iAutoDismountFlying,
	fCanDismountForCombat = false,	-- means dismount is currently turned on because the in combat condition is true
	fCanDismountForAttack = false,	-- means dismount is currently turned on because the can attack condition is true

}

--=========================================================================--
-- "constants"				TODO: find a way to make these constants
--=========================================================================--

Pokedex.Globals.Constants = {
	strVersionedTitle = L["Pokedex"] .. "      v"  .. GetAddOnMetadata("Pokedex", "Version"),
	iCurDataFormat = 12,

	nomount = nomount,
	nopet   = nopet,
	notitle = notitle,

	rgstrChannelDescs = { L["personal"], L["party"], L["raid"], L["emote"], L["say"], L["yell"] },
	rgstrChannels = { "ERROR", "PARTY", "RAID", "EMOTE", "SAY", "YELL" }, -- CHATID types, not localized, ERROR is just placeholder

	-- reverse look up for the MF and MB enum types
	rgstrMountFlags  = rgstrMountFlags,
	rgstrMountBreeds = rgstrMountBreeds,

	rgstrSkillRankName = { [SL.ZenMaster] = _G.ZEN_MASTER, [SL.Illustrious] = _G.ILLUSTRIOUS, [SL.GrandMaster] = _G.GRAND_MASTER, [SL.Master] = _G.MASTER, [SL.Artisan] = _G.ARTISAN, [SL.Expert] = _G.EXPERT, [SL.Journeyman] = _G.JOURNEYMAN, [SL.Apprentice] = _G.APPRENTICE, [SL.None] = _G.NONE },

	rgRidingSkills = { 
		{ id = 90265, level = SL.Master },
		{ id = 34091, level = SL.Artisan },
		{ id = 34090, level = SL.Expert },
		{ id = 33391, level = SL.Journeyman },
		{ id = 33388, level = SL.Apprentice } },

	tblArgentMinion = {
		Alliance = 214,  -- speciesID for Argent Squire
		Horde = 216,     -- speciesID for Argent Gruntling
	},
	tblTravelersTundraMammoth = {
		Alliance = 61425,  -- spellID for Alliance version
		Horde = 61447,     -- spellID for Horde version
	},
	idSpellGrandExpeditionYak = 122708,

	idTitleMatron = 104,
	idTitlePatron = 105,
	idTitleMinionSlayer = 147,
	-- idSpellColdWeatherFlying = 54197,
	-- idSpellFlightMastersLicense = 90267,
	idSpellAbyssalSeahorse = 75207,
	idSpellSubduedSeahorse = 98718,
	idSpellRedDrake = 59570,
	idSpellRedMechanostrider = 10873,
	idSpellRedScarab = 26054,
	idSpellBattlePet = 118301,
	idSpellGlyphOfAquaticForm = 57856,
	idSpellGlyphOfNightmares = 56232,
	idSpellGlyphOfZenFlight = 125893,
	idSpellSoulburnedUnendingBreath = 104242,
	idSpellRogueDisguise = 121308,
	idSpellMonkZenFlight = 125883,
	idSpellMonkRoll = 109132,

	-- monitored spells - must be included in table as well
	idSpellCloudSerpentRiding = 130487,
	idSpellHornOfWinter = 57330,
	idSpellWaterWalking = 546,
	idSpellGhostWolf = 2645,
	idSpellBurningRush = 111400,
	idSpellUnendingBreath = 5697,
	idSpellSoulburn = 74434,
	idSpellBearForm = 5487,
	idSpellAquaticForm = 1066,
	idSpellCatForm = 768,
	idSpellTravelForm = 783,
	idSpellMoonkinForm = 24858,
	idSpellTreantForm = 114282,
	idSpellFlightForm = 33943,
	idSpellSwiftFlightForm = 40120,
	idSpellTreeForm = 33891,

	-- learning a spell in this table triggers an update
	rgidMonitoredSpell = { 
		[130487] = true,
		[57330] = true,
		[546] = true, 
		[2645] = true, 
		[111400] = true,
		[5697] = true,
		[74434] = true,
		[5487] = true, 
		[1066] = true, 
		[768] = true, 
		[783] = true, 
		[24858] = true, 
		[114282] = true,
		[33943] = true, 
		[40120] = true, 
		[33891] = true, 
	},

	-- array by spellId of every companion that requires a snowball to summon
	-- these no longer need a snowball but will disappear after summoning, do we want to check calender?
	rgNeedsSnowball = { [26533] = true, [26045] = true, [26541] = true },		-- [26529] = true, -- reindeer loses costume but doesn't disappear

	-- array by spellId of mounts requiring a minimum skill level to use
	rgSkillMounts = {
		 [92231] = { rank = 150, name = "Riding"      },  -- Spectral Steed
		 [92232] = { rank = 150, name = "Riding"      },  -- Spectral Wolf
		 [61451] = { rank = 300, name = "Tailoring"   },  -- Flying Carpet
		 [75596] = { rank = 425, name = "Tailoring"   },  -- Frosty Flying Carpet
		 [61309] = { rank = 425, name = "Tailoring"   },  -- Magnificent Flying Carpet
		 [44153] = { rank = 300, name = "Engineering" },  -- Flying Machine
		 [44151] = { rank = 375, name = "Engineering" },  -- Turbo-Charged Flying Machine
	},

	-- array by spellId of mounts that can walk on water
	-- glyphed warlock mounts added/removed by Player class
	rgWaterWalkingMounts = {
		[118089] = true,  -- Azure Water Strider
		[127271] = true,  -- Crimson Water Strider
		[127278] = true,  -- Golden Water Strider
		[127274] = true,  -- Jade Water Strider
		[127272] = true,  -- Orange Water Strider
	},

	-- array by spellId of mounts that can carry passengers
	rgPassengerMounts = {
		 [93326] = 1,  -- Sandstone Drake
		 [61465] = 2,  -- Grand Black War Mammoth (Alliance)
		 [61467] = 2,  -- Grand Black War Mammoth (Horde)
		 [61469] = 2,  -- Grand Ice Mammoth (Alliance)
		 [61470] = 2,  -- Grand Ice Mammoth (Horde)
		 [61425] = 2,  -- Traveler's Tundra Mammoth (Alliance)
		 [61447] = 2,  -- Traveler's Tundra Mammoth (Horde)
		 [55531] = 1,  -- Mechano-Hog
		 [60424] = 1,  -- Mekgineer's Chopper
		[121820] = 1,  -- Obsidian Nightwing
		 [75973] = 1,  -- X-53 Touring Rocket
		[122708] = 2,  -- Grand Expedition Yak
	},

	-- array by spellId of every mount with table of attributes for each
	-- [spellId] = { name=str, breed=MB, flags=MF, speed=MS, passengers=bool }
	rgMountAttributes = {
		[139595] = { name="Armored Bloodwing",                      breed=MB.Unsorted,        flags=MFS_ATV,           },
		[136400] = { name="Armored Skyscreamer",                    breed=MB.Unsorted,        flags=MFS_ATV,           },
		[148428] = { name="Ashhide Mushan Beast",                   breed=MB.Unsorted,        flags=MFS_Runner,        },
		[142641] = { name="Brawler's Burly Mushan Beast",           breed=MB.Unsorted,        flags=MFS_Runner,        },
		[139448] = { name="Clutch of Ji-Kun",                       breed=MB.Unsorted,        flags=MF.Flyer,          },
		[142878] = { name="Enchanted Fey Dragon",                   breed=MB.Unsorted,        flags=MFS_ATV,           },
		 [65917] = { name="Magic Rooster",                          breed=MB.Unsorted,        flags=MFS_Runner,        },
		[130965] = { name="Son of Galleon",                         breed=MB.Unsorted,        flags=MFS_Runner,        },
		[148392] = { name="Spawn of Galakras",                      breed=MB.Unsorted,        flags=MFS_Runner,        },
		[147595] = { name="Stormcrow",                              breed=MB.Unsorted,        flags=MFS_Runner,        },
		[134573] = { name="Swift Windsteed",                        breed=MB.Unsorted,        flags=MFS_ATV,           },
		 [49322] = { name="Swift Zhevra",                           breed=MB.Unsorted,        flags=MFS_Runner,        },
		 [98727] = { name="Winged Guardian",                        breed=MB.Unsorted,        flags=MFS_ATV,           },

		 [98204] = { name="Amani Battle Bear",                      breed=MB.Bear,            flags=MFS_Runner,        },
		 [43688] = { name="Amani War Bear",                         breed=MB.Bear,            flags=MFS_Runner,        },
		 [60114] = { name="Armored Brown Bear",                     breed=MB.Bear,            flags=MFS_Runner,        },
		 [60116] = { name="Armored Brown Bear",                     breed=MB.Bear,            flags=MFS_Runner,        },
		 [51412] = { name="Big Battle Bear",                        breed=MB.Bear,            flags=MFS_Runner,        },
		 [58983] = { name="Big Blizzard Bear",                      breed=MB.Bear,            flags=MFS_Runner,        },
		 [60118] = { name="Black War Bear",                         breed=MB.Bear,            flags=MFS_Runner,        },
		 [60119] = { name="Black War Bear",                         breed=MB.Bear,            flags=MFS_Runner,        },
		[103081] = { name="Darkmoon Dancing Bear",                  breed=MB.Bear,            flags=MFS_Runner,        },
		 [54753] = { name="White Polar Bear",                       breed=MB.Bear,            flags=MFS_Runner,        },

		 [88748] = { name="Brown Riding Camel",                     breed=MB.Camel,           flags=MFS_Runner,        },
		 [88750] = { name="Grey Riding Camel",                      breed=MB.Camel,           flags=MFS_Runner,        },
		 [88749] = { name="Tan Riding Camel",                       breed=MB.Camel,           flags=MFS_Runner,        },
		[102488] = { name="White Riding Camel",                     breed=MB.Camel,           flags=MFS_Runner,        },

		 [61451] = { name="Flying Carpet",                          breed=MB.Carpet,          flags=MFS_ATV,           },
		 [75596] = { name="Frosty Flying Carpet",                   breed=MB.Carpet,          flags=MFS_ATV,           },
		 [61309] = { name="Magnificent Flying Carpet",              breed=MB.Carpet,          flags=MFS_ATV,           },

		[130092] = { name="Red Flying Cloud",                       breed=MB.Cloud,           flags=MFS_Hydrophobe,    },

		[127170] = { name="Astral Cloud Serpent",                   breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[123992] = { name="Azure Cloud Serpent",                    breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127156] = { name="Crimson Cloud Serpent",                  breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[123993] = { name="Golden Cloud Serpent",                   breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[148619] = { name="Grievous Gladiator's Cloud Serpent",     breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127169] = { name="Heavenly Azure Cloud Serpent",           breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127161] = { name="Heavenly Crimson Cloud Serpent",         breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127164] = { name="Heavenly Golden Cloud Serpent",          breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127165] = { name="Heavenly Jade Cloud Serpent",            breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127158] = { name="Heavenly Onyx Cloud Serpent",            breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[113199] = { name="Jade Cloud Serpent",                     breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[139407] = { name="Malevolent Gladiator's Cloud Serpent",   breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[127154] = { name="Onyx Cloud Serpent",                     breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[148620] = { name="Prideful Gladiator's Cloud Serpent",     breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[129918] = { name="Thundering August Cloud Serpent",        breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[139442] = { name="Thundering Cobalt Cloud Serpent",        breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[124408] = { name="Thundering Jade Cloud Serpent",          breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[148476] = { name="Thundering Onyx Cloud Serpent",          breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[132036] = { name="Thundering Ruby Cloud Serpent",          breed=MB.CloudSerpent,    flags=MF.Flyer,          },
		[148618] = { name="Tyrannical Gladiator's Cloud Serpent",   breed=MB.CloudSerpent,    flags=MF.Flyer,          },

		[127180] = { name="Albino Riding Crane",                    breed=MB.Crane,           flags=MFS_Runner,        },
		[127174] = { name="Azure Riding Crane",                     breed=MB.Crane,           flags=MFS_Runner,        },
		[123160] = { name="Crimson Riding Crane",                   breed=MB.Crane,           flags=MFS_Runner,        },
		[127176] = { name="Golden Riding Crane",                    breed=MB.Crane,           flags=MFS_Runner,        },
		[127178] = { name="Jungle Riding Crane",                    breed=MB.Crane,           flags=MFS_Runner,        },
		[127177] = { name="Regal Riding Crane",                     breed=MB.Crane,           flags=MFS_Runner,        },

		[138424] = { name="Amber Primordial Direhorn",              breed=MB.Direhorn,        flags=MFS_Runner,        },
		[138423] = { name="Cobalt Primordial Direhorn",             breed=MB.Direhorn,        flags=MFS_Runner,        },
		[140250] = { name="Crimson Primal Direhorn",                breed=MB.Direhorn,        flags=MFS_Runner,        },
		[140249] = { name="Golden Primal Direhorn",                 breed=MB.Direhorn,        flags=MFS_Runner,        },
		[138426] = { name="Jade Primordial Direhorn",               breed=MB.Direhorn,        flags=MFS_Runner,        },
		[138425] = { name="Slate Primordial Direhorn",              breed=MB.Direhorn,        flags=MFS_Runner,        },
		[136471] = { name="Spawn of Horridon",                      breed=MB.Direhorn,        flags=MFS_Runner,        },

		 [96503] = { name="Amani Dragonhawk",                       breed=MB.Dragonhawk,      flags=MF.Flyer,          },
		[142478] = { name="Armored Blue Dragonhawk",                breed=MB.Dragonhawk,      flags=MF.Flyer,          },
		[142266] = { name="Armored Red Dragonhawk",                 breed=MB.Dragonhawk,      flags=MF.Flyer,          },
		 [61996] = { name="Blue Dragonhawk",                        breed=MB.Dragonhawk,      flags=MF.Flyer,          },
		 [61997] = { name="Red Dragonhawk",                         breed=MB.Dragonhawk,      flags=MF.Flyer,          },
		 [66088] = { name="Sunreaver Dragonhawk",                   breed=MB.Dragonhawk,      flags=MF.Flyer,          },

		[127286] = { name="Black Dragon Turtle",                    breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127287] = { name="Blue Dragon Turtle",                     breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127288] = { name="Brown Dragon Turtle",                    breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127295] = { name="Great Black Dragon Turtle",              breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127302] = { name="Great Blue Dragon Turtle",               breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127308] = { name="Great Brown Dragon Turtle",              breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127293] = { name="Great Green Dragon Turtle",              breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127310] = { name="Great Purple Dragon Turtle",             breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[120822] = { name="Great Red Dragon Turtle",                breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[120395] = { name="Green Dragon Turtle",                    breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127289] = { name="Purple Dragon Turtle",                   breed=MB.DragonTurtle,    flags=MFS_Runner,        },
		[127290] = { name="Red Dragon Turtle",                      breed=MB.DragonTurtle,    flags=MFS_Runner,        },

		 [60025] = { name="Albino Drake",                           breed=MB.Drake,           flags=MF.Flyer,          },
		 [59567] = { name="Azure Drake",                            breed=MB.Drake,           flags=MF.Flyer,          },
		 [59650] = { name="Black Drake",                            breed=MB.Drake,           flags=MF.Flyer,          },
		[107842] = { name="Blazing Drake",                          breed=MB.Drake,           flags=MFS_Hydroplane,    },
		 [59568] = { name="Blue Drake",                             breed=MB.Drake,           flags=MF.Flyer,          },
		 [59569] = { name="Bronze Drake",                           breed=MB.Drake,           flags=MF.Flyer,          },
		[110039] = { name="Experiment 12-B",                        breed=MB.Drake,           flags=MF.Flyer,          },
		[113120] = { name="Feldrake",                               breed=MB.Drake,           flags=MFS_ATV,           },
		[110051] = { name="Heart of the Aspects",                   breed=MB.Drake,           flags=MFS_ATV,           },
		[107845] = { name="Life-Binder's Handmaiden",               breed=MB.Drake,           flags=MFS_Hydroplane,    },
		 [93623] = { name="Mottled Drake",                          breed=MB.Drake,           flags=MF.Flyer,          },
		 [69395] = { name="Onyxian Drake",                          breed=MB.Drake,           flags=MF.Flyer,          },
		 [59570] = { name="Red Drake",                              breed=MB.Drake,           flags=MF.Flyer,          },
		 [59571] = { name="Twilight Drake",                         breed=MB.Drake,           flags=MF.Flyer,          },
		[107844] = { name="Twilight Harbinger",                     breed=MB.Drake,           flags=MFS_Hydroplane,    },

		 [41514] = { name="Azure Netherwing Drake",                 breed=MB.Drake,           flags=MF.Flyer,          },
		 [41515] = { name="Cobalt Netherwing Drake",                breed=MB.Drake,           flags=MF.Flyer,          },
		 [88335] = { name="Drake of the East Wind",                 breed=MB.Drake,           flags=MF.Flyer,          },
		 [88742] = { name="Drake of the North Wind",                breed=MB.Drake,           flags=MF.Flyer,          },
		 [88744] = { name="Drake of the South Wind",                breed=MB.Drake,           flags=MF.Flyer,          },
		 [88741] = { name="Drake of the West Wind",                 breed=MB.Drake,           flags=MF.Flyer,          },
		 [41513] = { name="Onyx Netherwing Drake",                  breed=MB.Drake,           flags=MF.Flyer,          },
		 [88718] = { name="Phosphorescent Stone Drake",             breed=MB.Drake,           flags=MF.Flyer,          },
		 [41516] = { name="Purple Netherwing Drake",                breed=MB.Drake,           flags=MF.Flyer,          },
		 [93326] = { name="Sandstone Drake",                        breed=MB.Drake,           flags=MFS_Hydroplane,    },
		 [41517] = { name="Veridian Netherwing Drake",              breed=MB.Drake,           flags=MF.Flyer,          },
		 [41518] = { name="Violet Netherwing Drake",                breed=MB.Drake,           flags=MF.Flyer,          },
		 [88746] = { name="Vitreous Stone Drake",                   breed=MB.Drake,           flags=MF.Flyer,          },
		 [88331] = { name="Volcanic Stone Drake",                   breed=MB.Drake,           flags=MF.Flyer,          },

		 [58615] = { name="Brutal Nether Drake",                    breed=MB.Drake,           flags=MF.Flyer,          },
		[124550] = { name="Cataclysmic Gladiator's Twilight Drake", breed=MB.Drake,           flags=MFS_Hydroplane,    },
		 [44744] = { name="Merciless Nether Drake",                 breed=MB.Drake,           flags=MF.Flyer,          },
		[101821] = { name="Ruthless Gladiator's Twilight Drake",    breed=MB.Drake,           flags=MFS_Hydroplane,    },
		 [37015] = { name="Swift Nether Drake",                     breed=MB.Drake,           flags=MF.Flyer,          },
		 [49193] = { name="Vengeful Nether Drake",                  breed=MB.Drake,           flags=MF.Flyer,          },
		[101282] = { name="Vicious Gladiator's Twilight Drake",     breed=MB.Drake,           flags=MFS_Hydroplane,    },

		 [72808] = { name="Bloodbathed Frostbrood Vanquisher",      breed=MB.Drake,           flags=MF.Flyer,          },
		 [64927] = { name="Deadly Gladiator's Frost Wyrm",          breed=MB.Drake,           flags=MF.Flyer,          },
		 [65439] = { name="Furious Gladiator's Frost Wyrm",         breed=MB.Drake,           flags=MF.Flyer,          },
		 [72807] = { name="Icebound Frostbrood Vanquisher",         breed=MB.Drake,           flags=MF.Flyer,          },
		 [67336] = { name="Relentless Gladiator's Frost Wyrm",      breed=MB.Drake,           flags=MF.Flyer,          },
		 [71810] = { name="Wrathful Gladiator's Frost Wyrm",        breed=MB.Drake,           flags=MF.Flyer,          },

		 [48027] = { name="Black War Elekk",                        breed=MB.Elekk,           flags=MFS_Runner,        },
		 [34406] = { name="Brown Elekk",                            breed=MB.Elekk,           flags=MFS_Runner,        },
		 [73629] = { name="Summon Exarch's Elekk",                  breed=MB.Elekk,           flags=MFS_Runner,        },
		 [63639] = { name="Exodar Elekk",                           breed=MB.Elekk,           flags=MFS_Runner,        },
		 [35710] = { name="Gray Elekk",                             breed=MB.Elekk,           flags=MFS_Runner,        },
		 [35713] = { name="Great Blue Elekk",                       breed=MB.Elekk,           flags=MFS_Runner,        },
		 [73630] = { name="Summon Great Exarch's Elekk",            breed=MB.Elekk,           flags=MFS_Runner,        },
		 [35712] = { name="Great Green Elekk",                      breed=MB.Elekk,           flags=MFS_Runner,        },
		 [35714] = { name="Great Purple Elekk",                     breed=MB.Elekk,           flags=MFS_Runner,        },
		 [65637] = { name="Great Red Elekk",                        breed=MB.Elekk,           flags=MFS_Runner,        },
		 [35711] = { name="Purple Elekk",                           breed=MB.Elekk,           flags=MFS_Runner,        },

		 [97560] = { name="Corrupted Fire Hawk",                    breed=MB.FireHawk,        flags=MF.Flyer,          },
		 [97501] = { name="Green Fire Hawk",                        breed=MB.FireHawk,        flags=MF.Flyer,          },
		 [97493] = { name="Pureblood Fire Hawk",                    breed=MB.FireHawk,        flags=MF.Flyer,          },

		 [44153] = { name="Flying Machine",                         breed=MB.FlyingMachine,   flags=MFS_ATV,           },
		 [63796] = { name="Mimiron's Head",                         breed=MB.FlyingMachine,   flags=MF.Flyer,          },
		[134359] = { name="Sky Golem",                              breed=MB.FlyingMachine,   flags=MF.Flyer,          },
		 [44151] = { name="Turbo-Charged Flying Machine",           breed=MB.FlyingMachine,   flags=MFS_ATV,           },

		[130138] = { name="Black Riding Goat",                      breed=MB.Goat,            flags=MFS_Runner,        },
		[130086] = { name="Brown Riding Goat",                      breed=MB.Goat,            flags=MFS_Runner,        },
		[130137] = { name="White Riding Goat",                      breed=MB.Goat,            flags=MFS_Runner,        },

		 [61229] = { name="Armored Snowy Gryphon",                  breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32239] = { name="Ebon Gryphon",                           breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32235] = { name="Golden Gryphon",                         breed=MB.Gryphon,         flags=MFS_ATV,           },
		[135416] = { name="Grand Armored Gryphon",                  breed=MB.Gryphon,         flags=MFS_ATV,           },
		[136163] = { name="Grand Gryphon",                          breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32240] = { name="Snowy Gryphon",                          breed=MB.Gryphon,         flags=MFS_ATV,           },
		[107516] = { name="Spectral Gryphon",                       breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32242] = { name="Swift Blue Gryphon",                     breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32290] = { name="Swift Green Gryphon",                    breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32292] = { name="Swift Purple Gryphon",                   breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [32289] = { name="Swift Red Gryphon",                      breed=MB.Gryphon,         flags=MFS_ATV,           },
		 [54729] = { name="Winged Steed of the Ebon Blade",         breed=MB.Gryphon,         flags=MFS_ATV,           },

		 [35022] = { name="Black Hawkstrider",                      breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [35020] = { name="Blue Hawkstrider",                       breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [35018] = { name="Purple Hawkstrider",                     breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [34795] = { name="Red Hawkstrider",                        breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [63642] = { name="Silvermoon Hawkstrider",                 breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [66091] = { name="Sunreaver Hawkstrider",                  breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [35025] = { name="Swift Green Hawkstrider",                breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [33660] = { name="Swift Pink Hawkstrider",                 breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [35027] = { name="Swift Purple Hawkstrider",               breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [65639] = { name="Swift Red Hawkstrider",                  breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [35028] = { name="Swift Warstrider",                       breed=MB.Hawkstrider,     flags=MFS_Runner,        },
		 [46628] = { name="Swift White Hawkstrider",                breed=MB.Hawkstrider,     flags=MFS_Runner,        },

		 [63844] = { name="Argent Hippogryph",                      breed=MB.Hippogryph,      flags=MFS_ATV,           },
		 [74856] = { name="Blazing Hippogryph",                     breed=MB.Hippogryph,      flags=MFS_ATV,           },
		 [43927] = { name="Cenarion War Hippogryph",                breed=MB.Hippogryph,      flags=MFS_ATV,           },
		[102514] = { name="Corrupted Hippogryph",                   breed=MB.Hippogryph,      flags=MFS_ATV,           },
		 [97359] = { name="Flameward Hippogryph",                   breed=MB.Hippogryph,      flags=MFS_ATV,           },
		 [66087] = { name="Silver Covenant Hippogryph",             breed=MB.Hippogryph,      flags=MFS_ATV,           },

		 [48778] = { name="Acherus Deathcharger",                   breed=MB.Horse,           flags=MFS_Runner,        },
		 [66906] = { name="Argent Charger",                         breed=MB.Horse,           flags=MFS_Runner,        },
		 [66907] = { name="Argent Warhorse",                        breed=MB.Horse,           flags=MFS_Runner,        },
		 [67466] = { name="Argent Warhorse",                        breed=MB.Horse,           flags=MFS_Runner,        },
		   [470] = { name="Black Stallion",                         breed=MB.Horse,           flags=MFS_Runner,        },
		 [22717] = { name="Black War Steed",                        breed=MB.Horse,           flags=MFS_Runner,        },
		   [458] = { name="Brown Horse",                            breed=MB.Horse,           flags=MFS_Runner,        },
		 [75614] = { name="Celestial Steed",                        breed=MB.Horse,           flags=MFS_ATV,           },
		  [6648] = { name="Chestnut Mare",                          breed=MB.Horse,           flags=MFS_Runner,        },
		 [73313] = { name="Crimson Deathcharger",                   breed=MB.Horse,           flags=MFS_Runner,        },
		 [68188] = { name="Crusader's Black Warhorse",              breed=MB.Horse,           flags=MFS_Runner,        },
		 [68187] = { name="Crusader's White Warhorse",              breed=MB.Horse,           flags=MFS_Runner,        },
		 [23161] = { name="Dreadsteed",                             breed=MB.Horse,           flags=MFS_Runner,        },
		  [5784] = { name="Felsteed",                               breed=MB.Horse,           flags=MFS_Runner,        },
		 [36702] = { name="Fiery Warhorse",                         breed=MB.Horse,           flags=MFS_Runner,        },
		[136505] = { name="Ghastly Charger",                        breed=MB.Horse,           flags=MFS_ATV,           },
		 [48025] = { name="Headless Horseman's Mount",              breed=MB.Horse,           flags=MFS_ATV,           },
		[142073] = { name="Hearthsteed",                            breed=MB.Horse,           flags=MFS_ATV,           },
		 [72286] = { name="Invincible",                             breed=MB.Horse,           flags=MFS_ATV,           },
		[103195] = { name="Mountain Horse",                         breed=MB.Horse,           flags=MFS_Runner,        },
		 [16082] = { name="Palomino",                               breed=MB.Horse,           flags=MFS_Runner,        },
		   [472] = { name="Pinto",                                  breed=MB.Horse,           flags=MFS_Runner,        },
		 [66090] = { name="Quel'dorei Steed",                       breed=MB.Horse,           flags=MFS_Runner,        },
		 [17481] = { name="Rivendare's Deathcharger",               breed=MB.Horse,           flags=MFS_Runner,        },
		 [92231] = { name="Spectral Steed",                         breed=MB.Horse,           flags=MFS_Runner,        },
		 [63232] = { name="Stormwind Steed",                        breed=MB.Horse,           flags=MFS_Runner,        },
		 [23214] = { name="Summon Charger",                         breed=MB.Horse,           flags=MFS_Runner,        },
		 [34767] = { name="Summon Thalassian Charger",              breed=MB.Horse,           flags=MFS_Runner,        },
		 [13819] = { name="Summon Warhorse",                        breed=MB.Horse,           flags=MFS_Runner,        },
		 [34769] = { name="Summon Thalassian Warhorse",             breed=MB.Horse,           flags=MFS_Runner,        },
		 [68057] = { name="Swift Alliance Steed",                   breed=MB.Horse,           flags=MFS_Runner,        },
		 [23229] = { name="Swift Brown Steed",                      breed=MB.Horse,           flags=MFS_Runner,        },
		 [65640] = { name="Swift Gray Steed",                       breed=MB.Horse,           flags=MFS_Runner,        },
		[103196] = { name="Swift Mountain Horse",                   breed=MB.Horse,           flags=MFS_Runner,        },
		 [23227] = { name="Swift Palomino",                         breed=MB.Horse,           flags=MFS_Runner,        },
		 [23228] = { name="Swift White Steed",                      breed=MB.Horse,           flags=MFS_Runner,        },
		[107203] = { name="Tyrael's Charger",                       breed=MB.Horse,           flags=MFS_ATV,           },
		[100332] = { name="Vicious War Steed",                      breed=MB.Horse,           flags=MFS_Runner,        },
		 [16083] = { name="White Stallion",                         breed=MB.Horse,           flags=MFS_Runner,        },

		 [64977] = { name="Black Skeletal Horse",                   breed=MB.Horse,           flags=MFS_Runner,        },
		 [17463] = { name="Blue Skeletal Horse",                    breed=MB.Horse,           flags=MFS_Runner,        },
		 [64656] = { name="Blue Skeletal Warhorse",                 breed=MB.Horse,           flags=MFS_Runner,        },
		 [17464] = { name="Brown Skeletal Horse",                   breed=MB.Horse,           flags=MFS_Runner,        },
		 [63643] = { name="Forsaken Warhorse",                      breed=MB.Horse,           flags=MFS_Runner,        },
		 [17465] = { name="Green Skeletal Warhorse",                breed=MB.Horse,           flags=MFS_Runner,        },
		 [66846] = { name="Ochre Skeletal Warhorse",                breed=MB.Horse,           flags=MFS_Runner,        },
		 [17462] = { name="Red Skeletal Horse",                     breed=MB.Horse,           flags=MFS_Runner,        },
		 [23246] = { name="Purple Skeletal Warhorse",               breed=MB.Horse,           flags=MFS_Runner,        },
		 [22722] = { name="Red Skeletal Warhorse",                  breed=MB.Horse,           flags=MFS_Runner,        },
		 [65645] = { name="White Skeletal Warhorse",                breed=MB.Horse,           flags=MFS_Runner,        },
		[146622] = { name="Vicious Skeletal Warhorse",            breed=MB.Horse,           flags=MFS_Runner,        },

		 [22718] = { name="Black War Kodo",                         breed=MB.Kodo,            flags=MFS_Runner,        },
		 [50869] = { name="Brewfest Kodo",                          breed=MB.Kodo,            flags=MFS_Runner,        },
		 [18990] = { name="Brown Kodo",                             breed=MB.Kodo,            flags=MFS_Runner,        },
		 [18989] = { name="Gray Kodo",                              breed=MB.Kodo,            flags=MFS_Runner,        },
		 [49379] = { name="Great Brewfest Kodo",                    breed=MB.Kodo,            flags=MFS_Runner,        },
		 [23249] = { name="Great Brown Kodo",                       breed=MB.Kodo,            flags=MFS_Runner,        },
		 [65641] = { name="Great Golden Kodo",                      breed=MB.Kodo,            flags=MFS_Runner,        },
		 [23248] = { name="Great Gray Kodo",                        breed=MB.Kodo,            flags=MFS_Runner,        },
		 [69826] = { name="Summon Great Sunwalker Kodo",            breed=MB.Kodo,            flags=MFS_Runner,        },
		 [23247] = { name="Great White Kodo",                       breed=MB.Kodo,            flags=MFS_Runner,        },
		 [18991] = { name="Green Kodo",                             breed=MB.Kodo,            flags=MFS_Runner,        },
		 [69820] = { name="Summon Sunwalker Kodo",                  breed=MB.Kodo,            flags=MFS_Runner,        },
		 [18992] = { name="Teal Kodo",                              breed=MB.Kodo,            flags=MFS_Runner,        },
		 [63641] = { name="Thunder Bluff Kodo",                     breed=MB.Kodo,            flags=MFS_Runner,        },
		 [64657] = { name="White Kodo",                             breed=MB.Kodo,            flags=MFS_Runner,        },

		[133023] = { name="Jade Pandaren Kite",                     breed=MB.Kite,            flags=MF.Flyer,          },
		[118737] = { name="Pandaren Kite",                          breed=MB.Kite,            flags=MF.Flyer,          },
		[130985] = { name="Pandaren Kite",                          breed=MB.Kite,            flags=MF.Flyer,          },

		 [59785] = { name="Black War Mammoth",                      breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [59788] = { name="Black War Mammoth",                      breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [61465] = { name="Grand Black War Mammoth",                breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [61467] = { name="Grand Black War Mammoth",                breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [61469] = { name="Grand Ice Mammoth",                      breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [61470] = { name="Grand Ice Mammoth",                      breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [59797] = { name="Ice Mammoth",                            breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [59799] = { name="Ice Mammoth",                            breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [61425] = { name="Traveler's Tundra Mammoth",              breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [61447] = { name="Traveler's Tundra Mammoth",              breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [59791] = { name="Wooly Mammoth",                          breed=MB.Mammoth,         flags=MFS_Runner,        },
		 [59793] = { name="Wooly Mammoth",                          breed=MB.Mammoth,         flags=MFS_Runner,        },

		 [22719] = { name="Black Battlestrider",                    breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [10969] = { name="Blue Mechanostrider",                    breed=MB.Mechanostrider,  flags=MFS_Runner,        },
	  -- [17458] = { name="Fluorescent Green Mechanostrider",       breed=MB.Mechanostrider,  flags=MFS_Runner,        }, -- only one of these ever existed, was gm error, wowhead is filtering it from search results now, so dropping it to make list verification easier
		 [63638] = { name="Gnomeregan Mechanostrider",              breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [17453] = { name="Green Mechanostrider",                   breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [17459] = { name="Icy Blue Mechanostrider Mod A",          breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [10873] = { name="Red Mechanostrider",                     breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [23225] = { name="Swift Green Mechanostrider",             breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [23223] = { name="Swift White Mechanostrider",             breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [23222] = { name="Swift Yellow Mechanostrider",            breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [65642] = { name="Turbostrider",                           breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [17454] = { name="Unpainted Mechanostrider",               breed=MB.Mechanostrider,  flags=MFS_Runner,        },
		 [15779] = { name="White Mechanostrider Mod B",             breed=MB.Mechanostrider,  flags=MFS_Runner,        },

		 [89520] = { name="Goblin Mini Hotrod",                     breed=MB.Motorcycle,      flags=MFS_Runner,        },
		 [87090] = { name="Goblin Trike",                           breed=MB.Motorcycle,      flags=MFS_Runner,        },
		 [87091] = { name="Goblin Turbo-Trike",                     breed=MB.Motorcycle,      flags=MFS_Runner,        },
		 [55531] = { name="Mechano-Hog",                            breed=MB.Motorcycle,      flags=MFS_Runner,        },
		 [60424] = { name="Mekgineer's Chopper",                    breed=MB.Motorcycle,      flags=MFS_Runner,        },

		 [39803] = { name="Blue Riding Nether Ray",                 breed=MB.NetherRay,       flags=MF.Flyer,          },
		 [39798] = { name="Green Riding Nether Ray",                breed=MB.NetherRay,       flags=MF.Flyer,          },
		 [39801] = { name="Purple Riding Nether Ray",               breed=MB.NetherRay,       flags=MF.Flyer,          },
		 [39800] = { name="Red Riding Nether Ray",                  breed=MB.NetherRay,       flags=MF.Flyer,          },
		 [39802] = { name="Silver Riding Nether Ray",               breed=MB.NetherRay,       flags=MF.Flyer,          },

		[121837] = { name="Jade Panther",                           breed=MB.Panther,         flags=MFS_ATV,           },
		[120043] = { name="Jeweled Onyx Panther",                   breed=MB.Panther,         flags=MFS_ATV,           },
		[121820] = { name="Obsidian Nightwing",                     breed=MB.Panther,         flags=MFS_ATV,           },
		[121838] = { name="Ruby Panther",                           breed=MB.Panther,         flags=MFS_ATV,           },
		[121836] = { name="Sapphire Panther",                       breed=MB.Panther,         flags=MFS_ATV,           },
		[121839] = { name="Sunstone Panther",                       breed=MB.Panther,         flags=MFS_ATV,           },

		[132117] = { name="Ashen Pandaren Phoenix",                 breed=MB.Phoenix,         flags=MFS_Hydroplane,    },
		 [40192] = { name="Ashes of Al'ar",                         breed=MB.Phoenix,         flags=MF.Flyer,          },
		[129552] = { name="Crimson Pandaren Phoenix",               breed=MB.Phoenix,         flags=MFS_Hydroplane,    },
		 [88990] = { name="Dark Phoenix",                           breed=MB.Phoenix,         flags=MF.Flyer,          },
		[132118] = { name="Emerald Pandaren Phoenix",               breed=MB.Phoenix,         flags=MFS_Hydroplane,    },
		 [32345] = { name="Peep the Phoenix Mount",                 breed=MB.Phoenix,         flags=MF.Flyer,          },
		[132119] = { name="Violet Pandaren Phoenix",                breed=MB.Phoenix,         flags=MFS_Hydroplane,    },

		 [59976] = { name="Black Proto-Drake",                      breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [59996] = { name="Blue Proto-Drake",                       breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [61294] = { name="Green Proto-Drake",                      breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [63956] = { name="Ironbound Proto-Drake",                  breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [60021] = { name="Plagued Proto-Drake",                    breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [59961] = { name="Red Proto-Drake",                        breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [63963] = { name="Rusted Proto-Drake",                     breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [60002] = { name="Time-Lost Proto-Drake",                  breed=MB.ProtoDrake,      flags=MF.Flyer,          },
		 [60024] = { name="Violet Proto-Drake",                     breed=MB.ProtoDrake,      flags=MF.Flyer,          },

		[124659] = { name="Imperial Quilen",                        breed=MB.Quilen,          flags=MFS_ATV,           },

		 [17461] = { name="Black Ram",                              breed=MB.Ram,             flags=MFS_Runner,        },
		 [22720] = { name="Black War Ram",                          breed=MB.Ram,             flags=MFS_Runner,        },
		 [43899] = { name="Brewfest Ram",                           breed=MB.Ram,             flags=MFS_Runner,        },
		  [6899] = { name="Brown Ram",                              breed=MB.Ram,             flags=MFS_Runner,        },
		 [17460] = { name="Frost Ram",                              breed=MB.Ram,             flags=MFS_Runner,        },
		  [6777] = { name="Gray Ram",                               breed=MB.Ram,             flags=MFS_Runner,        },
		 [63636] = { name="Ironforge Ram",                          breed=MB.Ram,             flags=MFS_Runner,        },
		 [23510] = { name="Stormpike Battle Charger",               breed=MB.Ram,             flags=MFS_Runner,        },
		 [43900] = { name="Swift Brewfest Ram",                     breed=MB.Ram,             flags=MFS_Runner,        },
		 [23238] = { name="Swift Brown Ram",                        breed=MB.Ram,             flags=MFS_Runner,        },
		 [23239] = { name="Swift Gray Ram",                         breed=MB.Ram,             flags=MFS_Runner,        },
		 [65643] = { name="Swift Violet Ram",                       breed=MB.Ram,             flags=MFS_Runner,        },
		 [23240] = { name="Swift White Ram",                        breed=MB.Ram,             flags=MFS_Runner,        },
		  [6898] = { name="White Ram",                              breed=MB.Ram,             flags=MFS_Runner,        },

		 [96491] = { name="Armored Razzashi Raptor",                breed=MB.Raptor,          flags=MFS_Runner,        },
		[138642] = { name="Black Primal Raptor",                    breed=MB.Raptor,          flags=MFS_Runner,        },
		 [22721] = { name="Black War Raptor",                       breed=MB.Raptor,          flags=MFS_Runner,        },
		[138640] = { name="Bone-White Primal Raptor",               breed=MB.Raptor,          flags=MFS_Runner,        },
		 [63635] = { name="Darkspear Raptor",                       breed=MB.Raptor,          flags=MFS_Runner,        },
		  [8395] = { name="Emerald Raptor",                         breed=MB.Raptor,          flags=MFS_Runner,        },
		 [84751] = { name="Fossilized Raptor",                      breed=MB.Raptor,          flags=MFS_Runner,        },
		[138643] = { name="Green Primal Raptor",                    breed=MB.Raptor,          flags=MFS_Runner,        },
		 [17450] = { name="Ivory Raptor",                           breed=MB.Raptor,          flags=MFS_Runner,        },
		 [16084] = { name="Mottled Red Raptor",                     breed=MB.Raptor,          flags=MFS_Runner,        },
		[138641] = { name="Red Primal Raptor",                      breed=MB.Raptor,          flags=MFS_Runner,        },
		 [97581] = { name="Savage Raptor",                          breed=MB.Raptor,          flags=MFS_Runner,        },
		 [23241] = { name="Swift Blue Raptor",                      breed=MB.Raptor,          flags=MFS_Runner,        },
		 [23242] = { name="Swift Olive Raptor",                     breed=MB.Raptor,          flags=MFS_Runner,        },
		 [23243] = { name="Swift Orange Raptor",                    breed=MB.Raptor,          flags=MFS_Runner,        },
		 [65644] = { name="Swift Purple Raptor",                    breed=MB.Raptor,          flags=MFS_Runner,        },
		 [24242] = { name="Swift Razzashi Raptor",                  breed=MB.Raptor,          flags=MFS_Runner,        },
		 [10796] = { name="Turquoise Raptor",                       breed=MB.Raptor,          flags=MFS_Runner,        },
		 [64659] = { name="Venomhide Ravasaur",                     breed=MB.Raptor,          flags=MFS_Runner,        },
		 [10799] = { name="Violet Raptor",                          breed=MB.Raptor,          flags=MFS_Runner,        },

		 [41252] = { name="Raven Lord",                             breed=MB.Raven,           flags=MFS_Runner,        },
		[101542] = { name="Flametalon of Alysrazor",                breed=MB.Raven,           flags=MFS_Runner,        },

		 [74918] = { name="Wooly White Rhino",                      breed=MB.Rhino,           flags=MFS_Runner,        },

		 [71342] = { name="Big Love Rocket",                        breed=MB.Rocket,          flags=MFS_ATV,           },
		[126507] = { name="Depleted-Kyparium Rocket",               breed=MB.Rocket,          flags=MFS_ATV,           },
		[126508] = { name="Geosynchronous World Spinner",           breed=MB.Rocket,          flags=MFS_ATV,           },
		 [46197] = { name="X-51 Nether-Rocket",                     breed=MB.Rocket,          flags=MFS_ATV,           },
		 [46199] = { name="X-51 Nether-Rocket X-TREME",             breed=MB.Rocket,          flags=MFS_ATV,           },
		 [75973] = { name="X-53 Touring Rocket",                    breed=MB.Rocket,          flags=MFS_ATV,           },

		 [16056] = { name="Ancient Frostsaber",                     breed=MB.Saber,           flags=MFS_Runner,        },
		 [16055] = { name="Black Nightsaber",                       breed=MB.Saber,           flags=MFS_Runner,        },
		 [22723] = { name="Black War Tiger",                        breed=MB.Saber,           flags=MFS_Runner,        },
		[129934] = { name="Blue Shado-Pan Riding Tiger",            breed=MB.Saber,           flags=MFS_Runner,        },
		 [63637] = { name="Darnassian Nightsaber",                  breed=MB.Saber,           flags=MFS_Runner,        },
		 [90621] = { name="Golden King",                            breed=MB.Saber,           flags=MFS_Runner,        },
		[129932] = { name="Green Shado-Pan Riding Tiger",           breed=MB.Saber,           flags=MFS_Runner,        },
		[129935] = { name="Red Shado-Pan Riding Tiger",             breed=MB.Saber,           flags=MFS_Runner,        },
		 [42776] = { name="Spectral Tiger",                         breed=MB.Saber,           flags=MFS_Runner,        },
		 [10789] = { name="Spotted Frostsaber",                     breed=MB.Saber,           flags=MFS_Runner,        },
		 [66847] = { name="Striped Dawnsaber",                      breed=MB.Saber,           flags=MFS_Runner,        },
		  [8394] = { name="Striped Frostsaber",                     breed=MB.Saber,           flags=MFS_Runner,        },
		 [10793] = { name="Striped Nightsaber",                     breed=MB.Saber,           flags=MFS_Runner,        },
		 [23221] = { name="Swift Frostsaber",                       breed=MB.Saber,           flags=MFS_Runner,        },
		 [23219] = { name="Swift Mistsaber",                        breed=MB.Saber,           flags=MFS_Runner,        },
		 [65638] = { name="Swift Moonsaber",                        breed=MB.Saber,           flags=MFS_Runner,        },
		 [42777] = { name="Swift Spectral Tiger",                   breed=MB.Saber,           flags=MFS_Runner,        },
		 [23338] = { name="Swift Stormsaber",                       breed=MB.Saber,           flags=MFS_Runner,        },
		 [96499] = { name="Swift Zulian Panther",                   breed=MB.Saber,           flags=MFS_Runner,        },
		 [24252] = { name="Swift Zulian Tiger",                     breed=MB.Saber,           flags=MFS_Runner,        },
		 [17229] = { name="Winterspring Frostsaber",                breed=MB.Saber,           flags=MFS_Runner,        },
		[146615] = { name="Vicious Warsaber",                       breed=MB.Saber,           flags=MFS_Runner,        },

		 [26656] = { name="Black Qiraji Battle Tank",               breed=MB.Scarab,          flags=MFS_Black_Scarab,  },
		 [25953] = { name="Blue Qiraji Battle Tank",                breed=MB.Scarab,          flags=MF.Ahn_Qiraj,      },
		 [26056] = { name="Green Qiraji Battle Tank",               breed=MB.Scarab,          flags=MF.Ahn_Qiraj,      },
		 [26054] = { name="Red Qiraji Battle Tank",                 breed=MB.Scarab,          flags=MF.Ahn_Qiraj,      },
		 [92155] = { name="Ultramarine Qiraji Battle Tank",         breed=MB.Scarab,          flags=MFS_Black_Scarab,  },
		 [26055] = { name="Yellow Qiraji Battle Tank",              breed=MB.Scarab,          flags=MF.Ahn_Qiraj,      },

		[123886] = { name="Amber Scorpion",                         breed=MB.Scorpion,        flags=MFS_Runner,        },
		 [93644] = { name="Kor'kron Annihilator",                   breed=MB.Scorpion,        flags=MFS_Runner,        },
		[148417] = { name="Kor'kron Juggernaut",                    breed=MB.Scorpion,        flags=MFS_Runner,        },

		 [75207] = { name="Abyssal Seahorse",                       breed=MB.Seahorse,        flags=MF.Vashjir,        },
		 [98718] = { name="Subdued Seahorse",                       breed=MB.Seahorse,        flags=MF.Swimmer,        },

		 [39315] = { name="Cobalt Riding Talbuk",                   breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [34896] = { name="Cobalt War Talbuk",                      breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [39316] = { name="Dark Riding Talbuk",                     breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [34790] = { name="Dark War Talbuk",                        breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [39317] = { name="Silver Riding Talbuk",                   breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [34898] = { name="Silver War Talbuk",                      breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [39318] = { name="Tan Riding Talbuk",                      breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [34899] = { name="Tan War Talbuk",                         breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [39319] = { name="White Riding Talbuk",                    breed=MB.Talbuk,          flags=MFS_Runner,        },
		 [34897] = { name="White War Talbuk",                       breed=MB.Talbuk,          flags=MFS_Runner,        },

		[102346] = { name="Swift Forest Strider",                   breed=MB.Tallstrider,     flags=MFS_Runner,        },
		[102350] = { name="Swift Lovebird",                         breed=MB.Tallstrider,     flags=MFS_Runner,        },
		[101573] = { name="Swift Shorestrider",                     breed=MB.Tallstrider,     flags=MFS_Runner,        },
		[102349] = { name="Swift Springstrider",                    breed=MB.Tallstrider,     flags=MFS_Runner,        },

		 [30174] = { name="Riding Turtle",                          breed=MB.Turtle,          flags=MFS_Sea_Turtle,    },
		 [64731] = { name="Sea Turtle",                             breed=MB.Turtle,          flags=MFS_Sea_Turtle,    },

		[118089] = { name="Azure Water Strider",                    breed=MB.WaterStrider,    flags=MFS_Runner,        },
		[127271] = { name="Crimson Water Strider",                  breed=MB.WaterStrider,    flags=MFS_Runner,        },
		[127278] = { name="Golden Water Strider",                   breed=MB.WaterStrider,    flags=MFS_Runner,        },
		[127274] = { name="Jade Water Strider",                     breed=MB.WaterStrider,    flags=MFS_Runner,        },
		[127272] = { name="Orange Water Strider",                   breed=MB.WaterStrider,    flags=MFS_Runner,        },

		 [61230] = { name="Armored Blue Wind Rider",                breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32244] = { name="Blue Wind Rider",                        breed=MB.WindRider,       flags=MFS_ATV,           },
		[135418] = { name="Grand Armored Wyvern",                   breed=MB.WindRider,       flags=MFS_ATV,           },
		[136164] = { name="Grand Wyvern",                           breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32245] = { name="Green Wind Rider",                       breed=MB.WindRider,       flags=MFS_ATV,           },
		[107517] = { name="Spectral Wind Rider",                    breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32295] = { name="Swift Green Wind Rider",                 breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32297] = { name="Swift Purple Wind Rider",                breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32246] = { name="Swift Red Wind Rider",                   breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32296] = { name="Swift Yellow Wind Rider",                breed=MB.WindRider,       flags=MFS_ATV,           },
		 [32243] = { name="Tawny Wind Rider",                       breed=MB.WindRider,       flags=MFS_ATV,           },

		 [22724] = { name="Black War Wolf",                         breed=MB.Wolf,            flags=MFS_Runner,        },
		 [64658] = { name="Black Wolf",                             breed=MB.Wolf,            flags=MFS_Runner,        },
		  [6654] = { name="Brown Wolf",                             breed=MB.Wolf,            flags=MFS_Runner,        },
		  [6653] = { name="Dire Wolf",                              breed=MB.Wolf,            flags=MFS_Runner,        },
		 [23509] = { name="Frostwolf Howler",                       breed=MB.Wolf,            flags=MFS_Runner,        },
		[100333] = { name="Kor'kron War Wolf",                      breed=MB.Wolf,            flags=MFS_Runner,        },
		 [63640] = { name="Orgrimmar Wolf",                         breed=MB.Wolf,            flags=MFS_Runner,        },
		 [16080] = { name="Red Wolf",                               breed=MB.Wolf,            flags=MFS_Runner,        },
		 [92232] = { name="Spectral Wolf",                          breed=MB.Wolf,            flags=MFS_Runner,        },
		 [23250] = { name="Swift Brown Wolf",                       breed=MB.Wolf,            flags=MFS_Runner,        },
		 [65646] = { name="Swift Burgundy Wolf",                    breed=MB.Wolf,            flags=MFS_Runner,        },
		 [23252] = { name="Swift Gray Wolf",                        breed=MB.Wolf,            flags=MFS_Runner,        },
		 [68056] = { name="Swift Horde Wolf",                       breed=MB.Wolf,            flags=MFS_Runner,        },
		 [23251] = { name="Swift Timber Wolf",                      breed=MB.Wolf,            flags=MFS_Runner,        },
		   [580] = { name="Timber Wolf",                            breed=MB.Wolf,            flags=MFS_Runner,        },
		[100333] = { name="Vicious War Wolf",                       breed=MB.Wolf,            flags=MFS_Runner,        },
		 [16081] = { name="Winter Wolf",                            breed=MB.Wolf,            flags=MFS_Runner,        },

		[127209] = { name="Black Riding Yak",                       breed=MB.Yak,             flags=MFS_Runner,        },
		[127220] = { name="Blonde Riding Yak",                      breed=MB.Yak,             flags=MFS_Runner,        },
		[127213] = { name="Brown Riding Yak",                       breed=MB.Yak,             flags=MFS_Runner,        },
		[122708] = { name="Grand Expedition Yak",                   breed=MB.Yak,             flags=MFS_Runner,        },
		[127216] = { name="Grey Riding Yak",                        breed=MB.Yak,             flags=MFS_Runner,        },
		[123182] = { name="White Riding Yak",                       breed=MB.Yak,             flags=MFS_Runner,        },
	}
}
