local L = LibStub("AceLocale-3.0"):GetLocale("Pokedex")

-- upvalues
local _G, Pokedex, LibStub, pairs, CreateFrame, GetBindingKey, InterfaceOptionsFrame_OpenToCategory, SetBindingClick, UIParent = _G, Pokedex, LibStub, pairs, CreateFrame, GetBindingKey, InterfaceOptionsFrame_OpenToCategory, SetBindingClick, UIParent
local GetCompanionInfo, GetNumCompanions, GetSpellInfo = GetCompanionInfo, GetNumCompanions, GetSpellInfo


local IS = Pokedex.Globals.Types.InitStates;     -- Initialization States
local SL = Pokedex.Globals.Types.SkillLevels;    -- minimum skill level to hold that rank of profession
local DL = Pokedex.Globals.Types.DebugLevels;    -- Debug Levels
local gc = Pokedex.Globals.Constants;
local gv = Pokedex.Globals.Variables;
local gs = Pokedex.Globals.SortMethods;


function Pokedex:LoadSavedSettings()
	-- saved settings and default values
	local defaults = {
		global = {
			rgDebugInfo = { MISC     = 0,
							MOUNTS   = 0,
							PETS     = 0,
							TITLES   = 0,
							DISMOUNT = 0,
			},
		},
		char = {
			mounts = {
				idHot = 0,
				iHeat = 50,
				ranks = {},       -- { key(string) is name of mount, value(number) is rank }
			},
			pets = {
				idHot = 0,
				iHeat = 50,
				ranks = {},       -- { key(string) is name of mount, value(number) is rank }
			},
			titles = {
				idHot = -1,
				iHeat = 50,
				ranks = {},       -- { key(string) is name of mount, value(number) is rank }
			},
			fEnableHotness = true,
			fNewHotness = true,
		},
		profile = {
			fShamanUseGhostWolf = true,
			fShamanCastWaterWalkingWithMount = false,
			fDruidUseForms = true,
			fWarlockUseBurningRush = true,
			fWarlockCastWaterWalkingWithMount = true,
			fDKCastHornWithMount = true,
			fRogueRemoveDisguise = true,
			fMonkUseZenFlight = true,
			fMonkUseRoll = false,
			fManageAutoDismount = false,
			fDismountForGathering = false,
			fDismountForCombat = false,
			fDismountForAttack = false,
			fAnnounce = true,
			iChannel = 1,
			fChangeTitleOnMount = false,
			fAutoSummonCompanion = true,
			fFavorGroundMounts = true,
			mounts = {
				iDefaultRank = 5,
				iMaximumRank = 10,
				ranks = {},       -- { key(string) is name of mount, value(number) is rank }
			},
			pets = {
				iDefaultRank = 5,
				iMaximumRank = 10,
				ranks = {},         -- { key(string) is name of pet species, value(number) is rank }
			},
			titles = {
				iDefaultRank = 5,
				iMaximumRank = 10,
				ranks = {},         -- { key(string) is name of title, value(number) is rank }
			},
		},
	}

	self.db = LibStub("AceDB-3.0"):New("PokedexDB", defaults, true) --, _G.DEFAULT)

	-- we should be able to migrate saved data formats immediately
	self:MigrateSavedData();

	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied",  "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset",   "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileDeleted", "OnProfileDeleted")
end

function Pokedex:OnProfileChanged()
	-- the profile they changed to may still need migration
	self:MigrateSavedData();

	-- rebuild internals for changes
	-- REVIEW - does this cover it?
	self:UpdateDismountSettings();
	self:UpdateMountInfo()
	LibStub("AceConfigRegistry-3.0"):NotifyChange("Pokedex");
end

function Pokedex:OnProfileDeleted(_, _, name)
	for k, v in pairs(self.db.sv.profileKeys) do
		if v == name then
			self.db.sv.profileKeys[v] = nil
		end
	end
end

-- As the addon develops and ages, there may be changes to the structure 
-- and contents of the saved data. This function migrates data between
-- data format versions to preserve the users settings.
function Pokedex:MigrateSavedData()
	-- different sections of saved settings each need to be stamped with the
	-- current Format number, i.e. db.global, db.char, db.profile, etc
	local profiledb = self.db.profile
	local  globaldb = self.db.global
	local    chardb = self.db.char

	-- If the saved format value for profile is nil, then its a brand new profile
	-- and no migration will be needed. Treat it as being stamped current.
	local iFormatProfile = profiledb.iDataFormat or gc.iCurDataFormat

	-- If the saved format values for char and global are nil, set the value equal
	-- to iFormatProfile. This lets us skip migration when there is nothing to migrate,
	-- but does allow us to do some needed work initing the new sections as part of
	-- the big profile reorg done as part of formats 11-12.
	local iFormatGlobal = globaldb.iDataFormat or iFormatProfile
	local iFormatChar   =   chardb.iDataFormat or iFormatProfile

	-- note that in a given session you might only migrate one section, 
	-- like char, as global or profile could have already been migrated
	if (gc.iCurDataFormat == iFormatProfile and 
		gc.iCurDataFormat == iFormatGlobal and
		gc.iCurDataFormat == iFormatChar) then
		-- all sections up to date, exit
		return;
	end

	-- no longer supporting migration of settings formats older than 8.
	-- some functions required in migrating some steps have been removed or changed
	-- too much over time to work in the way expected by some of the migrations steps
	if iFormatProfile < 8 then
		profiledb.idHotCritter = nil;
		profiledb.idHotCritterPref = nil;
		profiledb.rgCritterInfo = nil;
		profiledb.fChangeTitleOnLoad = nil;
		profiledb.rgDebugInfo = nil;
		profiledb.fCombineAllFastMounts = nil;
		profiledb.fCombineFastAndSlowMounts = nil;

		profiledb.rgMountInfo = {};
		profiledb.rgCompanionInfo = {};
		profiledb.rgTitleInfo = {};
	end

	-- migrate keybind from old togglemount action to new togglemount button
--[==[ REVIEW - this should really only happend if keybindindings are set to be per user
		TODO - find how to check that setting	
	if iFormatProfile < 9 then
		local bind1, bind2 = GetBindingKey("POKEDEXTOGGLEMOUNT")
		if (bind1) then SetBindingClick(bind1, "PokedexToggleMountButton", "LeftButton"); end
		if (bind2) then SetBindingClick(bind2, "PokedexToggleMountButton", "LeftButton"); end

		-- migration hasn't been working well so we'll also just toss up a warning
		local popup = CreateFrame("Frame", "PokedexFormWarning", UIParent);
		popup:SetPoint("CENTER", UIParent, "CENTER")
		popup:SetFrameStrata("DIALOG")
		popup:SetHeight(150)
		popup:SetWidth(300)
		popup:SetBackdrop({
			bgFile = "Interface/Tooltips/ChatBubble-Background",
			edgeFile = "Interface/Tooltips/ChatBubble-BackDrop",
			tile = true, tileSize = 32, edgeSize = 32,
			insets = { left = 32, right = 32, top = 32, bottom = 32 }
		})
		popup:SetBackdropColor(0,0,0, 1)

		popup.close = CreateFrame("Button", "", popup, "OptionsButtonTemplate")
		popup.close:SetText("Close")
		popup.close:SetPoint("BOTTOMRIGHT", popup, "BOTTOMRIGHT", -10, 10)
		popup.close:SetScript("OnClick", function() popup:Hide() end )

		popup.warning = popup:CreateFontString("", "OVERLAY", "GameFontNormal")
		popup.warning:SetJustifyH("LEFT")
		popup.warning:SetJustifyV("TOP")
		popup.warning:SetPoint("TOPLEFT", popup, "TOPLEFT", 10, -10)
		popup.warning:SetPoint("BOTTOMRIGHT", popup.close, "TOPRIGHT", 0, 5)
		popup.warning:SetText("POKEDEX - Please note that you will need to re-keybind the Toggle Mount command and/or edit any macros which use ToggleMount due to changes made to support new features like Druid forms. Please see the README.TXT file in the addon directory for more details.");

		popup:Show()
	end
--]==]

	-- migrate pet ranks into new format
	if iFormatProfile < 10 then
		profiledb.rgPetRanks = {}
		local iDefault = profiledb.pets.iDefaultRank
		for _, v in pairs(profiledb.rgCompanionInfo) do
			if iDefault ~= v.rank then
				profiledb.rgPetRanks[v.name] = v.rank;
			end
		end
	end


	-- reorganization of settings for profile sharing checkin
	-- new format for mount and title info
	if iFormatProfile < 11 then
		profiledb.fFirstBoot = nil

		-- migrate mount ranks into new format
		local iDefault = profiledb.mounts.iDefaultRank
		for _, v in pairs(profiledb.rgMountInfo) do
			if iDefault ~= v.rank then
				profiledb.mounts.ranks[v.name] = v.rank;
			end
		end
		
		-- remove old mount info
		profiledb.rgMountInfo = nil;

		-- move location of pet ranks
		profiledb.pets.ranks = profiledb.rgPetRanks;
		profiledb.rgPetRanks = nil;

		-- remove old pet rank format and non-migratable hotid
		profiledb.rgCompanionInfo = nil;
		profiledb.idHotCompanion = nil;


		-- migrate title ranks into new format
		local iDefault = profiledb.titles.iDefaultRank
		for _, v in pairs(profiledb.rgTitleInfo) do
			if iDefault ~= v.rank then
				profiledb.titles.ranks[v.name] = v.rank;
			end
		end

		-- fix up the No Title entry
		local none = profiledb.rgTitleInfo[0]
		if none then
			profiledb.titles.ranks[none.name] = nil
			profiledb.titles.ranks[_G.PLAYER_TITLE_NONE] = none.rank
		else
			profiledb.titles.ranks[_G.PLAYER_TITLE_NONE] = 0
		end

		-- remove old title info
		profiledb.rgTitleInfo = nil;
	end

	-- reorganization of settings for profile sharing checkin
	-- new format for mount and title info
	if iFormatChar < 11 then
		-- move pet hot id
		if chardb.sidHotPet ~= nil then
			chardb.pets.idHot = chardb.sidHotPet;
			chardb.sidHotPet = nil;
		end
		chardb.idHotCompanion = nil;

		-- only migrate and clean up an existing char - realm profile that 
		-- matches the current character
		if CurProfileName == _G.format("%s - %s", _G.UnitName("player"), _G.GetRealmName()) then
			-- move enable and new hotness settings
			if profiledb.fEnableHotness ~= nil then
				chardb.fEnableHotness = profiledb.fEnableHotness;
				profiledb.fEnableHotness = nil;
			end
			if profiledb.fNewHotness ~= nil then
				chardb.fNewHotness = profiledb.fNewHotness;
				profiledb.fNewHotness = nil;
			end

			-- move mount hot id
			if profiledb.idHotMount ~= nil then 
				chardb.mounts.idHot = profiledb.idHotMount;
				profiledb.idHotMount = nil;
			end
			
			-- move mount heat
			if profiledb.iHotMountPref ~= nil then
				chardb.mounts.iHeat = profiledb.iHotMountPref;
				profiledb.iHotMountPref = nil;
			end

			-- move pet heat
			if profiledb.iHotCompanionPref ~= nil then
				chardb.pets.iHeat = profiledb.iHotCompanionPref;
				profiledb.iHotCompanionPref = nil;
			end

			-- move title hot id
			if profiledb.idHotTitle ~= nil then
				chardb.titles.idHot = profiledb.idHotTitle;
				profiledb.idHotTitle = nil
			end

			-- move title heat
			if profiledb.iHotTitlePref ~= nil then
				chardb.titles.iHeat = profiledb.iHotTitlePref;
				profiledb.iHotTitlePref = nil;
			end
		end
	end

	-- Cause a Default profile to be created for the legacy user so that
	-- it will be in their dropdowns ready to be selected and copied into.
	if iFormatGlobal < 12 then
		local profiles = self.db:GetProfiles()
		if not profiles[_G.DEFAULT] then
			local current = self.db:GetCurrentProfile()
			self.db:SetProfile(_G.DEFAULT)
			self.db:SetProfile(current)
		end
	end

	profiledb.iDataFormat = gc.iCurDataFormat
	globaldb.iDataFormat = gc.iCurDataFormat
	chardb.iDataFormat = gc.iCurDataFormat
end


--=========================================================================--
-- Options UI definition
--=========================================================================--

local function newCounter()
	local i = 0
	return function()
		i = i + 1
		return i
	end
end

function Pokedex.GetUIOptions()
	if (gv.InitState ~= IS.INITIALIZED and Pokedex:Initialize("GetUIOptions") == IS.UNINITIALIZED) then
		return {
			name = gc.strVersionedTitle,
			handler = Pokedex,
			type = 'group',
			childGroups = "tab",
			args = {
				CtrlInitError = {
					order = 1,
					type = "description",
					name = L["ERROR: Pokedex failed to initialize correctly. This is usually caused when WoW has invalidated its cache and hasn't finished rebuilding it. Please try this action again later."],
				},
				Padding_InitError = {
					order = 2,
					type = "description",
					name = "",
				},
				CtrlRetryInit = {
					order = 3,
					type = "execute",
					name = L["retry initialization"],
					desc = L["retry initialization"],
					func = function() InterfaceOptionsFrame_OpenToCategory(Pokedex.optionsFrame); end,
				}
			}
		}
	end

	if (not Pokedex.options) then
		local count = newCounter()
		Pokedex.options = {
			name = gc.strVersionedTitle,
			handler = Pokedex,
			type = 'group',
			childGroups = "tab",
			args = {
				test = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["echoes out test info relevant to current feature in development"],
					desc = L["echoes out test info relevant to current feature in development"],
					func = function(info) Pokedex:EchoTest() end,
				},
				debug = {
					hidden = true,
					order = 0,
					type = "input",
					name = L["echoes out test info relevant to current feature in development"],
					desc = L["echoes out test info relevant to current feature in development"],
					get = function(info) return "" end,
					set = "SetDebug",
				},
				speed = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["echoes out current speed"],
					desc = L["echoes out current speed"],
					func = function(info) Pokedex:EchoSpeed() end,
				},
				zone = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["echoes out zone info"],
					desc = L["echoes out zone info"],
					func = function(info) Pokedex:EchoZone() end,
				},
				SuperToggle = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["toggle mount or companion"],
					desc = L["toggles mount or companion"],
					func = function(info) Pokedex:SuperToggle() end,
				},
				SummonMount = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon mount"],
					desc = L["summons a mount"],
					func = function(info) Pokedex:SummonMount(false) end,
				},
				sm = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon mount"],
					desc = L["summons a mount"],
					func = function(info) Pokedex:SummonMount(false) end,
				},
				DismissMount = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["dismiss mount"],
					desc = L["dismisses current mount"],
					func = function(info) Pokedex:DismissMount() end,
				},
				dm = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["dismiss mount"],
					desc = L["dismisses current mount"],
					func = function(info) Pokedex:DismissMount() end,
				},
				ToggleMount = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["toggle mount"],
					desc = L["toggles a mount"],
					func = function(info) Pokedex:ToggleMount() end,
				},
				tm = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["toggle mount"],
					desc = L["toggles a mount"],
					func = function(info) Pokedex:ToggleMount() end,
				},
				SummonNextMount = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon next mount"],
					desc = L["summons next mount in collection"],
					func = function(info) Pokedex:SummonNextMount() end,
				},
				snm = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon next mount"],
					desc = L["summons next mount in collection"],
					func = function(info) Pokedex:SummonNextMount() end,
				},
				SummonOtherMount = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon other mount"],
					desc = L["if summon mount would summon flyer, will summon ground mount and vice versa"],
					func = function(info) Pokedex:SummonSafeMount() end,
				},
				som = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon other mount"],
					desc = L["if summon mount would summon flyer, will summon ground mount and vice versa"],
					func = function(info) Pokedex:SummonSafeMount() end,
				},
				SummonCompanion = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon companion"],
					desc = L["summons a companion"],
					func = function(info) Pokedex:SummonCompanion(false) end,
				},
				sc = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon companion"],
					desc = L["summons a companion"],
					func = function(info) Pokedex:SummonCompanion(false) end,
				},
				DismissCompanion = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["dismiss companion"],
					desc = L["dismisses current companion"],
					func = function(info) Pokedex:DismissCompanion() end,
				},
				dc = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["dismiss companion"],
					desc = L["dismisses current companion"],
					func = function(info) Pokedex:DismissCompanion() end,
				},
				ToggleCompanion = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["toggle companion"],
					desc = L["toggles a companion"],
					func = function(info) Pokedex:ToggleCompanion() end,
				},
				tc = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["toggle companion"],
					desc = L["toggles a companion"],
					func = function(info) Pokedex:ToggleCompanion() end,
				},
				SummonNextCompanion = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon next companion"],
					desc = L["summons next companion in collection"],
					func = function(info) Pokedex:SummonCompanion(true) end,
				},
				snc = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon next companion"],
					desc = L["summons next companion in collection"],
					func = function(info) Pokedex:SummonCompanion(true) end,
				},
				vendor = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["summon vendor"],
					desc = L["summons a mount or companion with vendor capabilities"],
					func = function(info) Pokedex:SummonVendor() end,
				},
				ChangeTitle = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["change title"],
					desc = L["change title"],
					func = function() Pokedex:ChangeTitle() end,
				},
				ct = {
					hidden = true,
					order = 0,
					type = "execute",
					name = L["change title"],
					desc = L["change title"],
					func = function() Pokedex:ChangeTitle() end,
				},

				CtrlReadMe = {
					order = count(),
					type = "description",
					name = L["Please see the README.TXT file in the Pokedex addon folder for more information on how to use Pokedex"],
				},
				
				CtrlAnnounce = {
					order = count(),
					type = "toggle",
					name = L["announce"],
					desc = L["(on|off) let everyone know who *you* choose"],
					get = function(info) return Pokedex.db.profile.fAnnounce end,
					set = function(info, value) Pokedex.db.profile.fAnnounce = value end,
				},
				CtrlChannel = {
					order = count(),
					type = "select",
					name = L["channel"],
					desc = L["channel to announce selection in"],
					values = gc.rgstrChannelDescs,
					get = function(info) return Pokedex.db.profile.iChannel end,
					set = function(info, value) Pokedex.db.profile.iChannel = value end,
				},
				Padding_Announcements = {
					order = count(),
					type = "description",
					name = "",
				},
				CtrlEnableHotness = {
					order = count(),
					type = "toggle",
					name = L["enable hot pets"],
					desc = L["lets you turn on|off the hot pet subfeatures"],
					get = function(info) return Pokedex.db.char.fEnableHotness end,
					set = function(info, value) Pokedex.db.char.fEnableHotness = value end,
				},
				CtrlNewHotness = {
					order = count(),
					type = "toggle",
					name = L["new hotness"],
					desc = L["always make newest mount or companion the hot one"],
					disabled = function(info) return not Pokedex.db.char.fEnableHotness end,
					get = function(info) return Pokedex.db.char.fNewHotness end,
					set = function(info, value) Pokedex.db.char.fNewHotness = value end,
				},
				Padding_Hotness = {
					order = count(),
					type = "description",
					name = "",
				},

				CtrlGroupMounts = {
					order = count(),
					name = L["Mounts"],
					handler = Pokedex,
					type = 'group',
					args = {
						CtrlSummonMount = {
							order = count(),
							type = "execute",
							name = L["summon mount"],
							desc = L["summons a mount"],
							func = function(info) Pokedex:SummonMount() end,
						},
						CtrlDismissMount = {
							order = count(),
							type = "execute",
							name = L["dismiss mount"],
							desc = L["dismisses current mount"],
							func = function(info) Pokedex:DismissMount() end,
						},
						Padding_MountButtons = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlMountTypes = {
							order = count(),
							type = "select",
							name = L["select mount type"],
							desc = L["select mount type"],
							values = function(info) return gv.Mounts.Lists.UITypesDisplay end,
							disabled = function(info) return (gv.Mounts.count == 0) end,
							get = function(info) return gv.SelectedMountBucket end,
							set = function(info, value) 
									gv.SelectedMountBucket = value
									if not value:MountInBucket(gv.SelectedMount) then
										gv.SelectedMount = value:GetFirstMount()
									end
								end,
						},
						Padding_MountTypes = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlMountsOfType = {
							order = count(),
							type = "select",
							name = L["select mount for ranking"],
							desc = L["mount whose rank you can set"],
							values = function(info) return gv.SelectedMountBucket.mounts end,
							disabled = function(info) return (gv.Mounts.count == 0) end,
							get = function(info) return gv.SelectedMount end,
							set = function(info, value) gv.SelectedMount = value end,
						},
						CtrlRankingForMount = {
							order = count(),
							type = "range",
							name = L["mount rank"],
							desc = L["rank of current mount"],
							min = 0,
							max = Pokedex.db.profile.mounts.iMaximumRank,
							step = 1,
							disabled = function(info) return (gv.Mounts.count == 0) end,
							get = function(info) return gv.SelectedMount.profile_rank end,
							set = function(info, value) gv.SelectedMount.profile_rank = value end,
						},
						Padding_MountRankings = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlMountOverrideRank = {
							order = count(),
							type = "toggle",
							name = L["set rank override"],
							desc = L["set a character specific value for rank"],
							disabled = function(info) return (gv.Mounts.count == 0) end,
							get = function(info) return gv.SelectedMount.char_rank ~= nil end,
							set = function(info, value) gv.SelectedMount.char_rank = value and gv.SelectedMount.rank or nil end,
						},
						CtrlRankingForMountOverride = {
							order = count(),
							type = "range",
							name = L["override rank"],
							desc = L["character specific rank"],
							min = 0,
							max = Pokedex.db.profile.mounts.iMaximumRank,
							step = 1,
							disabled = function(info) return (gv.Mounts.count == 0 or gv.SelectedMount.char_rank == nil) end,
							get = function(info) return gv.SelectedMount.char_rank end,
							set = function(info, value) gv.SelectedMount.char_rank = value end,
						},
						Padding_MountRankingOverride = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlHotMount = {
							order = count(),
							type = "select",
							name = L["select hot mount"],
							desc = L["mount to become hot one"],
							values = function(info) return gv.Mounts.HotList end,
							disabled = function(info) return (not Pokedex.db.char.fEnableHotness or gv.Pets.count == 0) end,
							get = function(info) return gv.HotMount end,
							set = function(info, value) 
								gv.HotMount = value
								Pokedex.db.char.mounts.idHot = gv.HotMount.sid
							end,
						},
						CtrlMountHeat = {
							order = count(),
							type = "range",
							name = L["mount heat"],
							desc = L["set hotness as a percentage - 100% means the hot mount is the only one that will be chosen"],
							min = 0,
							max = 100,
							step = 5,
							disabled = function(info) return not Pokedex.db.char.fEnableHotness end,
							get = function(info) return Pokedex.db.char.mounts.iHeat end,
							set = function(info, value) Pokedex.db.char.mounts.iHeat = value end,
						},
						Padding_HotMounts = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlFavorGroundMounts = {
							order = count(),
							type = "toggle",
							width = "full",
							name = L["favor ground mounts"],
							desc = L["ensures that in areas where flying is not allowed, we will filter out the flying mount that are still usable (Gryphons, Wind Riders, etc) in favor of ground only mounts (horses, kodos, etc)"],
							get = function(info) return Pokedex.db.profile.fFavorGroundMounts end,
							set = function(info, value) 
								Pokedex.db.profile.fFavorGroundMounts = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						Padding_AutoSummonCompanion = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlUseGhostWolf = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fShaman,
							name = L["use Ghost Wolf form"],
							desc = L["allow ToggleMount to make use of Ghost Wolf form in situations when a mount cannot be summoned"],
							get = function(info) return Pokedex.db.profile.fShamanUseGhostWolf end,
							set = function(info, value) 
								Pokedex.db.profile.fShamanUseGhostWolf = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlShamanCastWaterWalking = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fShaman,
							name = L["cast Water Walking while mounting"],
							desc = L["cast Water Walking while mounting"],
							get = function(info) return Pokedex.db.profile.fShamanCastWaterWalkingWithMount end,
							set = function(info, value) 
								Pokedex.db.profile.fShamanCastWaterWalkingWithMount = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlUseBurningRush = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fWarlock,
							name = L["use Burning Rush"],
							desc = L["allow ToggleMount to make use of Burning Rush in situations when a mount cannot be summoned"],
							get = function(info) return Pokedex.db.profile.fWarlockUseBurningRush end,
							set = function(info, value) 
								Pokedex.db.profile.fWarlockUseBurningRush = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlWarlockCastWaterWalking = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fWarlock,
							name = L["cast Water Walking while mounting"],
							desc = L["if Affliction, cast a Soulburned Unending Breath while mounting to gain water walking"],
							get = function(info) return Pokedex.db.profile.fWarlockCastWaterWalkingWithMount end,
							set = function(info, value) 
								Pokedex.db.profile.fWarlockCastWaterWalkingWithMount = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlUseDruidForms = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fDruid,
							name = L["use Druid forms"],
							desc = L["allow ToggleMount to select Druid forms when better than a mount or if a mount can't be summoned"],
							get = function(info) return Pokedex.db.profile.fDruidUseForms end,
							set = function(info, value) 
								Pokedex.db.profile.fDruidUseForms = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlCastHornOfWinter = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fDeathKnight,
							name = L["cast Horn of Winter while mounting"],
							desc = L["cast Horn of Winter while mounting"],
							get = function(info) return Pokedex.db.profile.fDKCastHornWithMount end,
							set = function(info, value) 
								Pokedex.db.profile.fDKCastHornWithMount = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlRemoveDisguise = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fRogue,
							name = L["remove Disguise"],
							desc = L["remove Disguise when mounting"],
							get = function(info) return Pokedex.db.profile.fRogueRemoveDisguise end,
							set = function(info, value) 
								Pokedex.db.profile.fRogueRemoveDisguise = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlUseZenFlight = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fMonk,
							name = L["use Zen Flight"],
							desc = L["allow ToggleMount to make use of Zen Flight in situations when a mount cannot be summoned"],
							get = function(info) return Pokedex.db.profile.fMonkUseZenFlight end,
							set = function(info, value) 
								Pokedex.db.profile.fMonkUseZenFlight = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						CtrlUseRoll = {
							order = count(),
							type = "toggle",
							hidden = not gc.Player.fMonk,
							name = L["use Roll"],
							desc = L["allow ToggleMount to make use of Roll in situations when a mount cannot be summoned"],
							get = function(info) return Pokedex.db.profile.fMonkUseRoll end,
							set = function(info, value) 
								Pokedex.db.profile.fMonkUseRoll = value 
								Pokedex:UpdateMountInfo()
							end,
						},
						Padding_Forms = {
							order = count(),
							type = "description",
							name = "",
						},
					},
				},

				CtrlGroupCompanions = {
					order = count(),
					name = L["Companions"],
					handler = Pokedex,
					type = 'group',
					args = {
						CtrlSummonCompanion = {
							order = count(),
							type = "execute",
							name = L["summon companion"],
							desc = L["summons a companion"],
							func = function() Pokedex:SummonCompanion(false) end,
						},
						CtrlDismissCompanion = {
							order = count(),
							type = "execute",
							name = L["dismiss companion"],
							desc = L["dismisses current companion"],
							func = function() Pokedex:DismissCompanion() end,
						},
						Padding_CompanionButtons = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlCompanionForRanking = {
							order = count(),
							type = "select",
							name = L["select companion for ranking"],
							desc = L["companion whose rank you can set"],
							values = function(info) return gv.Pets.All end,
							disabled = function(info) return (gv.Pets.count == 0) end,
							get = function(info) return gv.SelectedPet end,
							set = function(info, value) gv.SelectedPet = value end,
						},
						CtrlRankingForCompanion = {
							order = count(),
							type = "range",
							name = L["companion rank"],
							desc = L["rank of current companion"],
							min = 0,
							max = Pokedex.db.profile.pets.iMaximumRank,
							step = 1,
							disabled = function(info) return (gv.Pets.count == 0) end,
							get = function(info) return gv.SelectedPet.profile_rank end,
							set = function(info, value) gv.SelectedPet.profile_rank = value end,
						},
						Padding_CompanionRankings = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlCompanionOverrideRank = {
							order = count(),
							type = "toggle",
							name = L["set rank override"],
							desc = L["set a character specific value for rank"],
							disabled = function(info) return (gv.Pets.count == 0) end,
							get = function(info) return gv.SelectedPet.char_rank ~= nil end,
							set = function(info, value) gv.SelectedPet.char_rank = value and gv.SelectedPet.rank or nil end,
						},
						CtrlRankingForCompanionOverride = {
							order = count(),
							type = "range",
							name = L["override rank"],
							desc = L["character specific rank"],
							min = 0,
							max = Pokedex.db.profile.pets.iMaximumRank,
							step = 1,
							disabled = function(info) return (gv.Pets.count == 0 or gv.SelectedPet.char_rank == nil) end,
							get = function(info) return gv.SelectedPet.char_rank end,
							set = function(info, value) gv.SelectedPet.char_rank = value end,
						},
						Padding_CompanionRankingOverride = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlHotCompanion = {
							order = count(),
							type = "select",
							name = L["select hot companion"],
							desc = L["companion to become hot one"],
							values = function(info) return gv.Pets.HotList end,
							disabled = function(info) return (not Pokedex.db.char.fEnableHotness or gv.Pets.count == 0) end,
							get = function(info) return gv.HotPet end,
							set = function(info, value)
								gv.HotPet = value
								Pokedex.db.char.pets.idHot = gv.HotPet.sid
							end,
						},
						CtrlCompanionHeat = {
							order = count(),
							type = "range",
							name = L["companion heat"],
							desc = L["set hotness as a percentage - 100% means the hot pet is the only one that will be chosen"],
							min = 0,
							max = 100,
							step = 5,
							disabled = function(info) return not Pokedex.db.char.fEnableHotness end,
							get = function(info) return Pokedex.db.char.pets.iHeat end,
							set = function(info, value) Pokedex.db.char.pets.iHeat = value end,
						},
						Padding_HotCompanions = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlAutoSummonCompanion = {
							order = count(),
							type = "toggle",
							width = "full",
							name = L["Auto Summon Companion"],
							desc = L["Ensures a companion is accompanying you whenever you dismount or enter a new location"],
							get = function(info) return Pokedex.db.profile.fAutoSummonCompanion end,
							set = function(info, value) Pokedex.db.profile.fAutoSummonCompanion = value end,
						},
						Padding_AutoSummonCompanion = {
							order = count(),
							type = "description",
							name = "",
						},
					},
				},

				CtrlGroupTitles = {
					order = count(),
					name = L["Titles"],
					handler = Pokedex,
					type = 'group',
					args = {
						CtrlChangeTitleOnMount = {
							order = count(),
							type = "toggle",
							name = L["Change title on mount"],
							desc = L["Change title when a mount is summoned"],
							get = function(info) return Pokedex.db.profile.fChangeTitleOnMount end,
							set = function(info, value) Pokedex.db.profile.fChangeTitleOnMount = value end,
						},
						CtrlChangeTitle = {
							order = count(),
							type = "execute",
							name = L["change title"],
							desc = L["change title"],
							func = function() Pokedex:ChangeTitle() end,
						},
						Padding_TitleButtons = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlTitleForRanking = {
							order = count(),
							type = "select",
							name = L["select title for ranking"],
							desc = L["title whose rank you can set"],
							values = function(info) return gv.Titles.All end,
							disabled = function(info) return (gv.Titles == 0) end,
							get = function(info) return gv.SelectedTitle end,
							set = function(info, value) gv.SelectedTitle = value end,
						},
						CtrlRankingForTitle = {
							order = count(),
							type = "range",
							name = L["title rank"],
							desc = L["rank of current title"],
							min = 0,
							max = Pokedex.db.profile.titles.iMaximumRank,
							step = 1,
							disabled = function(info) return (gv.Titles.count == 0) end,
							get = function(info) return gv.SelectedTitle.profile_rank end,
							set = function(info, value) gv.SelectedTitle.profile_rank = value end,
						},
						Padding_TitleRankings = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlTitleOverrideRank = {
							order = count(),
							type = "toggle",
							name = L["set rank override"],
							desc = L["set a character specific value for rank"],
							disabled = function(info) return (gv.Titles.count == 0) end,
							get = function(info) return gv.SelectedTitle.char_rank ~= nil end,
							set = function(info, value) gv.SelectedTitle.char_rank = value and gv.SelectedTitle.rank or nil end,
						},
						CtrlRankingForTitleOverride = {
							order = count(),
							type = "range",
							name = L["override rank"],
							desc = L["character specific rank"],
							min = 0,
							max = Pokedex.db.profile.titles.iMaximumRank,
							step = 1,
							disabled = function(info) return (gv.Titles.count == 0 or gv.SelectedTitle.char_rank == nil) end,
							get = function(info) return gv.SelectedTitle.char_rank end,
							set = function(info, value) gv.SelectedTitle.char_rank = value end,
						},
						Padding_TitleRankingOverride = {
							order = count(),
							type = "description",
							name = "",
						},
						CtrlHotTitle = {
							order = count(),
							type = "select",
							name = L["select hot title"],
							desc = L["title to become hot one"],
							values = function(info) return gv.Titles.HotList end,
							disabled = function(info) return (not Pokedex.db.char.fEnableHotness or gv.Titles.count == 0) end,
							get = function(info) return gv.HotTitle end,
							set = function(info, value) 
								gv.HotTitle = value
								Pokedex.db.char.titles.idHot = gv.HotTitle.tid
							end,
						},
						CtrlTitleHeat = {
							order = count(),
							type = "range",
							name = L["title heat"],
							desc = L["set hotness as a percentage - 100% means the hot pet is the only one that will be chosen"],
							min = 0,
							max = 100,
							step = 5,
							disabled = function(info) return not Pokedex.db.char.fEnableHotness end,
							get = function(info) return Pokedex.db.char.titles.iHeat end,
							set = function(info, value) Pokedex.db.char.titles.iHeat = value end,
						},
						Padding_HotTitles = {
							order = count(),
							type = "description",
							name = "",
						},
					},
				},

				CtrlGroupAutoDismount = {
					order = count(),
					name = L["Safe Dismount"],
					handler = Pokedex,
					type = 'group',
					-- hidden = function(info) return (gv.rsRidingSkill < SL.Expert) end,
					args = {
						CtrlDismountFeatureDesc = {
							order = count(),
							type = "description",
							name = L["This feature works with and manages the games Auto Dismount in Flight setting to improve your experience with flying mounts. Auto dismount will be disabled unless in one of the selected conditions."],
						},
						CtrlAutoDismount = {
							order = count(),
							type = "toggle",
							width = "full",
							name = L["Manage Auto Dismount"],
							desc = L["Enables Pokedex's management of the Auto Dismount in Flight option"],
							get = function(info) return Pokedex.db.profile.fManageAutoDismount end,
							set = "SetManageAutoDismount",
						},
						Padding_Dismount1 = {
							order = count(),
							type = "description",
							width = "full",
							name = "",
						},
						Padding_Dismount2 = {
							order = count(),
							type = "description",
							width = "full",
							name = "",
						},
						Padding_Dismount3 = {
							order = count(),
							type = "description",
							width = "full",
							name = "",
						},
						CtrlDismountCombat = {
							order = count(),
							type = "toggle",
							width = "full",
							name = L["Dismount for Combat"],
							desc = L["Enables Auto Dismount when in combat"],
							disabled = function(info) return (not Pokedex.db.profile.fManageAutoDismount) end,
							get = function(info) return Pokedex.db.profile.fDismountForCombat end,
							set = function(info, value) Pokedex.db.profile.fDismountForCombat = value end,
						},
						CtrlDismountAttack = {
							order = count(),
							type = "toggle",
							width = "full",
							name = L["Dismount to Attack"],
							desc = L["Enables Auto Dismount when targeting something attackable"],
							disabled = function(info) return (not Pokedex.db.profile.fManageAutoDismount) end,
							get = function(info) return Pokedex.db.profile.fDismountForAttack end,
							set = function(info, value) Pokedex.db.profile.fDismountForAttack = value end,
						},
						CtrlDismountGathering = {
							order = count(),
							type = "toggle",
							width = "full",
							name = L["Dismount for Gathering"],
							desc = L["Enables Auto Dismount when gathering a resource with mining, herbalism or skinning"],
							hidden = function(info) return not gv.Skills.fGatherer end,
							disabled = function(info) return (not Pokedex.db.profile.fManageAutoDismount) end,
							get = function(info) return Pokedex.db.profile.fDismountForGathering end,
							set = function(info, value) Pokedex.db.profile.fDismountForGathering = value end,
						},
					},
				},
			},
		}
	end

	return Pokedex.options;
end
