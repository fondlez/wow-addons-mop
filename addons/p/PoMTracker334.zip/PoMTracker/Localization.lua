pomnotarget = "No Target";
if ( GetLocale() == "frFR" ) then
	pomnotarget = "Pas de cible";
end
if ( GetLocale() == "deDE" ) then
	pomnotarget = "Kein Ziel";
end
if ( GetLocale() == "esES" or GetLocale() == "esMX") then
	pomnotarget = "Sin objetivo";
end
if ( GetLocale() == "itIT" ) then
	pomnotarget = "Nessun bersaglio";
end
if ( GetLocale() == "ptBR" or GetLocale() == "ptPT" ) then
	pomnotarget = "N�o-alvo";
end

