local pomname = 0
local pomonunit = 0
local pomhealcount = 0
local pomcharges = 0
local pomlooptimer = 0
local pomlatency = 1
local pomnamequeued = 0
local pomqueueseconds = 0
local pomplaycooldown = 0
local originalName = 0
local seconds = 0
local cooldown = 0
local pomoptionshow = 0;
local onesectimer = 0;
local pomflash = 0;
local pomflasher = 0;
local pomflashertimer = 0;
local pommax = 5;
PoMTracker = {}
if not pomtracker_settings then
	pomtracker_settings = {}
	pomtracker_settings.gui = "show"
	pomtracker_settings.hide = "unlock"
	pomtracker_settings.fade = "disabled"
	pomtracker_settings.sound = "enabled"
	pomtracker_settings.total = "enabled"
	pomtracker_settings.heal = "enabled"
	pomtracker_settings.t7 = "disabled"
	pomtracker_settings.scale = 10
end

function PoMTracker:OnLoad(self)
	local plClass, enClass = UnitClass("player")
	if(enClass ~= "PRIEST") then
		pomtracker_settings.gui = "hide"
		DisableAddOn("PoMTracker")
        EnableAddOn("PoMTracker")
        DisableAddOn("PoMTracker")
		return
	else
		DEFAULT_CHAT_FRAME:AddMessage("PoMTracker: Version 3.34 Loaded - /pom for options")
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		self:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		SLASH_POMTRACKER1 = "/pom"
  		SlashCmdList["POMTRACKER"] = function(msg)
			PoMTracker:tracker_SlashCommandHandler(msg)
		end
	end
end

function PoMTracker:OnEvent(self, event, ...)
	if (event == "PLAYER_ENTERING_WORLD") then
		PoMTracker:frametoggle()
	end
	if (pomtracker_settings.t7 == "enabled") then
		if (event == "UPDATE_SHAPESHIFT_FORM") then
			if (GetShapeshiftForm() == 1) then
				pomtracker_settings.gui = "hide"
				PoMTracker:frametoggle()
			else 
				pomtracker_settings.gui = "show" 
				PoMTracker:frametoggle()
			end
		end
	end
	local timestamp, combatEvent, hideCaster, sourceGUID, sourceName, sourceFlags, srcFlags2, destGUID, destName, destFlags, dstFlags2, spellId, spellName, spellSchool, spellHealed = ...
	if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		if (spellId == 123267 and sourceName == UnitName("player")) then
			if (combatEvent == "SPELL_AURA_APPLIED") then
				if (pomtracker_settings.sound == "enabled") then
					PlaySoundFile("Sound\\Spells\\CheatDeath.ogg")
				end
				pomflash = 1;
				pomflashertimer = GetTime() + 10;
			end
			if (combatEvent == "SPELL_AURA_REMOVED") then
				pomflash = 0
				if (pomtracker_settings.gui == "show") then
					UIFrameFadeIn(_G["pomtracker2"], 0.1)
				end
				PoMTracker:frametoggle()
			end
		end
		if (spellId == 33076 or spellId == 41635 or spellId == 41637 or spellId == 33110) then
			if (combatEvent == "SPELL_CAST_SUCCESS") then
				if (sourceName == UnitName("player")) then
					for i = 1, NUM_GLYPH_SLOTS do
						local enabled, glyphType, glyphTooltipIndex, glyphSpellID, icon = GetGlyphSocketInfo(i);
						if (enabled) then
							if (glyphSpellID == 55685) then
								pommax = 4;
							end
						end
					end
					originalName = destName
					pomname = PoMTracker:processname(destName)
					pomcharges = pommax
					PoMTracker:timeset()
					pomlooptimer = 1
					pomonunit = 1
					if (pomtracker_settings.sound == "enabled") then
						pomplaycooldown = 1
					end
					local class, classFileName = UnitClass(destName)
					local color = RAID_CLASS_COLORS[classFileName] or TOOLTIP_DEFAULT_BACKGROUND_COLOR
					_G["pomtracker2"]:SetBackdropColor(color.r, color.g, color.b, 0.9);
					_G["pomtracker2_Text"]:SetText(pomcharges..": "..pomname)
					if (pomtracker_settings.total == "disabled") then
						PoMTracker:clearheal()
					end
					PoMTracker:frametoggle()
				else
					if (destName == pomname) then
						PoMTracker:pomkill()
					end
				end
			end
			if (pomlooptimer == 1 and sourceName == UnitName("player")) then
				if (combatEvent == "SPELL_HEAL") then
					local pomhealed = spellHealed
					pomhealcount = pomhealcount + pomhealed
					_G["pomtracker3_Text"]:SetText("Amount Healed: "..pomhealcount)
					if (PoMTracker:processname(destName) == pomname) then
						if (pomcharges == 0) then
							PoMTracker:pomkill()
						else
							pomqueueseconds = GetTime() + (pomlatency)
							pomonunit = 0
						end
					end
				end
				if (combatEvent == "SPELL_AURA_APPLIED") then
					if (pomcharges == pommax and destName == originalName) then
						--Do Nothing
					elseif (pomcharges == 0) then
						pomcharges = pommax
					else
						pomcharges = pomcharges - 1
					end
					pomname = PoMTracker:processname(destName)
					local class, classFileName = UnitClass(destName)
					local color = RAID_CLASS_COLORS[classFileName] or TOOLTIP_DEFAULT_BACKGROUND_COLOR
					_G["pomtracker2"]:SetBackdropColor(color.r, color.g, color.b, 0.9);
					PoMTracker:settarget(pomname)					
				end
				if (combatEvent == "SPELL_AURA_REMOVED") then
					if (PoMTracker:processname(destName) == pomname) then
						pomqueueseconds = GetTime() + (pomlatency) 
						pomonunit = 0
					end
				end
			end
		end
	end
end

function PoMTracker:processname(unitname)
	if (string.find(unitname, "-") == nil) then
		return unitname
	else
		return strsplit("-", unitname)
	end
end

function PoMTracker:timeset()
	seconds = GetTime() + 30
	if (pomcharges == pommax) then
		cooldown = GetTime() + 10
	end
end

function PoMTracker:clearheal()
	pomhealcount = 0
	_G["pomtracker3_Text"]:SetText("Amount Healed: 0")
end

function PoMTracker:pomkill()
	_G["pomtrackerstatusBar"]:SetValue(0)
	_G["pomtracker2_Text"]:SetText(pomnotarget)
	_G["pomtracker2"]:SetBackdropColor(TOOLTIP_DEFAULT_BACKGROUND_COLOR.r, TOOLTIP_DEFAULT_BACKGROUND_COLOR.g, TOOLTIP_DEFAULT_BACKGROUND_COLOR.b, 0.5);
	pomname = 0
	originalName = 0
	pomlooptimer = 0
	pomcharges = 0
	pomonunit = 0
	PoMTracker:frametoggle()
	if (pomtracker_settings.sound == "enabled") then
		PlaySoundFile("Sound\\Spells\\misdirection_impact_head.wav")
	end
end

function PoMTracker:settarget(unitname)
	pomonunit = 1
	PoMTracker:timeset()
	pomname = unitname
	_G["pomtracker2_Text"]:SetText(pomcharges..": "..unitname)
end

function PoMTracker:timerstart()
	if (GetTime() > onesectimer) then
		onesectimer = GetTime() + 0.2;
		if (pomtracker_settings.gui == "show") then
			if (pomflash == 1) then
				if (pomflasher == 0) then
					UIFrameFadeOut(_G["pomtracker2"], 0.1)
					pomflasher = 1;
				else 
					UIFrameFadeIn(_G["pomtracker2"], 0.1)
					pomflasher = 0;
				end
			end
			if (pomflashertimer < GetTime() and pomflash == 1) then
				pomflash = 0;
				UIFrameFadeIn(_G["pomtracker2"], 0.1)
				PoMTracker:frametoggle()
			end
		end
	end
	if (pomlooptimer == 1) then
		local pomnewtime = GetTime()
		local pomtimer = seconds - pomnewtime
		pomtimecount = (10 / 3) * pomtimer
		_G["pomtrackerstatusBar"]:SetValue(pomtimecount)
		if (pomonunit == 0) then
			if (GetTime() >= pomqueueseconds) then
				PoMTracker:pomkill()
			end
		end
		local start, duration, enabled = GetSpellCooldown(33076);
		cooldown = GetTime() + duration
		if (GetTime() >= cooldown) then
			if (pomtracker_settings.gui == "hide") then
				_G["pomtrackerstatusBar"]:SetStatusBarColor(1, 0, 0, 0)
			else
				_G["pomtrackerstatusBar"]:SetStatusBarColor(1, 0, 0, 1)
			end
			if (pomplaycooldown == 1) then
				PlaySoundFile("Sound\\Spells\\ManaBurnImpact.wav")
				pomplaycooldown = 0
			end
		else
			if (pomtracker_settings.gui == "hide") then
				_G["pomtrackerstatusBar"]:SetStatusBarColor(0, 0, 1, 0)
			else
				_G["pomtrackerstatusBar"]:SetStatusBarColor(0, 0, 1, 1)
			end
		end
		if (GetTime() >= seconds) then
			PoMTracker:pomkill()
		end
	end
end

function PoMTracker:frametoggle()
	if not pomtracker_settings.scale then
		pomtracker_settings.scale = 10
	end
	local pomscale = tonumber(pomtracker_settings.scale)
	_G["PoMOptionFrame_Scale"]:SetValue(pomscale)
	local frame1 = _G["pomtracker1"]
	local frame2 = _G["pomtracker2"]
	local frame3 = _G["pomtracker3"]
	local frame4 = _G["pomtrackerstatus"]
	local pomwidth =  pomscale * 10 + 85
	local pomheight = pomwidth / 6
	local pomtext = pomwidth / 14
	frame2:SetWidth(pomwidth + 20)
	_G["pomtrackerstatusBar"]:SetWidth(pomwidth + 10)
	if (pomscale < 10) then
		_G["pomtrackerstatusBar"]:SetHeight(pomscale)
	else 
		_G["pomtrackerstatusBar"]:SetHeight(10)
	end
	frame2:SetHeight(pomheight)
	_G["pomtracker2_Text"]:SetFont("Fonts\\FRIZQT__.TTF", pomtext)
	if (pomtracker_settings.gui == "show") then
		if (pomtracker_settings.hide == "unlock") then
			frame1:Show()
		else
			frame1:Hide()
		end
		frame2:Show()
		if (pomtracker_settings.heal == "enabled") then
			frame3:Show()
		else
			frame3:Hide()
		end
		frame4:Show()
	else
		frame1:Hide()
		frame2:Hide()
		frame3:Hide()
		frame4:Show()
	end
	if (pomtracker_settings.fade == "enabled" and pomtracker_settings.gui == "show" and pomonunit == 0) then
		if (pomtracker_settings.hide == "unlock") then
			UIFrameFadeOut(pomtracker1, 2.1)
		end 
		UIFrameFadeOut(pomtracker2, 2.1)
		UIFrameFadeOut(pomtrackerstatus, 2.1)
		if (pomtracker_settings.heal == "enabled") then
			UIFrameFadeOut(pomtracker3, 2.1)
		end
	elseif (pomtracker_settings.fade == "enabled" and pomtracker_settings.gui == "show" and pomonunit == 1) then
		if (pomtracker_settings.hide == "unlock") then
			UIFrameFadeIn(pomtracker1, 0.5)
		end 
		UIFrameFadeIn(pomtracker2, 0.5)
		UIFrameFadeIn(pomtrackerstatus, 0.5)
		if (pomtracker_settings.heal == "enabled") then
			UIFrameFadeIn(pomtracker3, 0.5)
		end
	end	
end

function PoMTracker:OptionFrame_OnShow()
	if (pomtracker_settings.hide == "lock") then
		_G["PoMOptionFrame_CheckButton1"]:SetChecked(1)
	else
		_G["PoMOptionFrame_CheckButton1"]:SetChecked(0)
	end
	if (pomtracker_settings.fade == "enabled") then
		_G["PoMOptionFrame_CheckButton2"]:SetChecked(1)
	else
		_G["PoMOptionFrame_CheckButton2"]:SetChecked(0)
	end
	if (pomtracker_settings.sound == "enabled") then
		_G["PoMOptionFrame_CheckButton3"]:SetChecked(1)
	else
		_G["PoMOptionFrame_CheckButton3"]:SetChecked(0)
	end
	if (pomtracker_settings.total == "disabled") then
		_G["PoMOptionFrame_CheckButton4"]:SetChecked(1)
	else
		_G["PoMOptionFrame_CheckButton4"]:SetChecked(0)
	end
	if (pomtracker_settings.heal == "enabled") then
		_G["PoMOptionFrame_CheckButton5"]:SetChecked(1)
	else
		_G["PoMOptionFrame_CheckButton5"]:SetChecked(0)
	end
	if (pomtracker_settings.t7 == "enabled") then
		_G["PoMOptionFrame_CheckButton6"]:SetChecked(1)
	else
		_G["PoMOptionFrame_CheckButton6"]:SetChecked(0)
	end
end

function PoMTracker:OptionsMenuScale(self)
	pomtracker_settings.scale = self:GetValue()
	PoMTracker:frametoggle()
end
function PoMTracker:OptionsMenuShow()
	if (pomoptionshow == 0) then
		_G["PoMOptionFrame"]:Show()
		pomoptionshow = 1
	else
		_G["PoMOptionFrame"]:Hide()
		pomoptionshow = 0
	end
end

function PoMTracker:OptionsMenu()
	if (_G["PoMOptionFrame_CheckButton1"]:GetChecked()) then
		pomtracker_settings.hide = "lock"
	else
		pomtracker_settings.hide = "unlock"
	end
	if (_G["PoMOptionFrame_CheckButton2"]:GetChecked()) then
		pomtracker_settings.fade = "enabled"
	else
		pomtracker_settings.fade = "disabled"
		if (pomtracker_settings.hide == "unlock") then
			UIFrameFadeIn(pomtracker1, 0.0)
		end 
		UIFrameFadeIn(pomtracker2, 0.0)
		UIFrameFadeIn(pomtrackerstatus, 0.0)
		if (pomtracker_settings.heal == "enabled") then
			UIFrameFadeIn(pomtracker3, 0.0)
		end
	end
	if (_G["PoMOptionFrame_CheckButton3"]:GetChecked()) then
		pomtracker_settings.sound = "enabled"
	else
		pomtracker_settings.sound = "disabled"
	end
	if (_G["PoMOptionFrame_CheckButton4"]:GetChecked()) then
		pomtracker_settings.total = "disabled"
	else
		pomtracker_settings.total = "enabled"
	end
	if (_G["PoMOptionFrame_CheckButton5"]:GetChecked()) then
		pomtracker_settings.heal = "enabled"
	else
		pomtracker_settings.heal = "disabled"
	end
	if (_G["PoMOptionFrame_CheckButton6"]:GetChecked()) then
		pomtracker_settings.t7 = "enabled"
		if (GetShapeshiftForm() == 1) then
			pomtracker_settings.gui = "hide"
		end
	else
		pomtracker_settings.t7 = "disabled"
		pomtracker_settings.gui = "show" 
	end
	PoMTracker:frametoggle()
end

function PoMTracker:tracker_SlashCommandHandler(msg)
	local frame1 = _G["pomtracker1"]
	local frame2 = _G["pomtracker2"]
	local frame3 = _G["pomtracker3"]
	local frame4 = _G["pomtrackerstatus"]
	local frame5 = _G["PoMOptionFrame"]
	if (msg == "gui" or msg == nil) then
		DEFAULT_CHAT_FRAME:AddMessage("Options are 'show', 'hide', 'lock', 'unlock'")
	elseif (msg == "gui show") then
		if(  frame1:IsVisible() ) then
     		DEFAULT_CHAT_FRAME:AddMessage("PoM Frame was already being displayed")
		else
			pomtracker_settings.gui = "show"
			DEFAULT_CHAT_FRAME:AddMessage("PoM Frame is now being displayed.")
		end
	elseif (msg == "gui hide") then
 		if(  frame1:IsVisible() ) then
			pomtracker_settings.gui = "hide" 
     		DEFAULT_CHAT_FRAME:AddMessage("PoM Frame is now hidden.")
		else
     		DEFAULT_CHAT_FRAME:AddMessage("PoM Frame was already hidden.")
		end
	elseif (msg == "gui lock") then
		pomtracker_settings.hide = "lock"
		DEFAULT_CHAT_FRAME:AddMessage("PoM Frame is now locked.")
	elseif (msg == "gui unlock") then
		pomtracker_settings.hide = "unlock"
		DEFAULT_CHAT_FRAME:AddMessage("PoM Frame is now unlocked.")
	elseif (msg == "fade on") then
		DEFAULT_CHAT_FRAME:AddMessage("PoM Fade mode enabled")
		pomtracker_settings.fade = "enabled"
	elseif (msg == "fade off") then
		DEFAULT_CHAT_FRAME:AddMessage("PoM Fade mode disabled")
		pomtracker_settings.fade = "disabled"
		if (pomtracker_settings.hide == "unlock") then
			UIFrameFadeIn(pomtracker1, 0.0)
		end 
		UIFrameFadeIn(pomtracker2, 0.0)
		UIFrameFadeIn(pomtrackerstatus, 0.0)
		if (pomtracker_settings.heal == "enabled") then
			UIFrameFadeIn(pomtracker3, 0.0)
		end
	elseif (msg == "sound on") then
		DEFAULT_CHAT_FRAME:AddMessage("PoM Alert sound enabled")
		pomtracker_settings.sound = "enabled"
	elseif (msg == "sound off") then
		DEFAULT_CHAT_FRAME:AddMessage("PoM Alert sound disabled")
		pomtracker_settings.sound = "disabled"
	elseif (msg == "shadow on") then
		DEFAULT_CHAT_FRAME:AddMessage("Hide on Shadow Mode Enabled")
		pomtracker_settings.t7 = "enabled"
		if (GetShapeshiftForm() == 1) then
			pomtracker_settings.gui = "hide"
		end
	elseif (msg == "shadow off") then
		DEFAULT_CHAT_FRAME:AddMessage("Hide on Shadow Mode Disabled")
		pomtracker_settings.t7 = "disabled"
		pomtracker_settings.gui = "show" 
	elseif (msg == "total on") then
		DEFAULT_CHAT_FRAME:AddMessage("PoM Heal Totaling enabled")
		pomtracker_settings.total = "enabled"
	elseif (msg == "total off") then
		DEFAULT_CHAT_FRAME:AddMessage("PoM Heal Totaling disabled")
		pomtracker_settings.total = "disabled"
		pomhealed = 0
	elseif (msg == "options") then		
		frame5:Show()
	elseif (msg == "reset") then
		local setframe = _G["pomtracker1"]
		DEFAULT_CHAT_FRAME:AddMessage("Position Reset")
		setframe:ClearAllPoints() 
		setframe:SetPoint("CENTER",0,0)
	else
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom gui' for gui options.")
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom fade'  on/off for frame fading.")
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom sound' on/off for sound alert.")
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom total' on/off to continue totaling ALL heals.")
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom options' To open the Options menu.")
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom shadow' on/off to toggle disabling on ShadowForm.")
		DEFAULT_CHAT_FRAME:AddMessage("Type '/pom reset' Reset PoMTracker Position.")
	end
	PoMTracker:frametoggle()
end
