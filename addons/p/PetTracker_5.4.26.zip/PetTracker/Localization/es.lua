local _, Addon = ...
local L = Addon.Locals
if GetLocale():sub(1, 2) ~= 'es' then return end
	
L.CommonSearches = 'Búsquedas Comunes'
L.FilterPets = 'Filtrar Mascotas'
L.Maximized = 'Maximizado'
L.UpgradeAlert = 'Aparecieron mejoras salvajens!'