local _, Addon = ...
local L = Addon.Locals
if GetLocale() ~= 'ptBR' then return end
	
L.CommonSearches = 'Procuras Comuns'
L.FilterPets = 'Filtrar Mascotes'
L.Maximized = 'Maximizado'
L.UpgradeAlert = 'Apareceram melhorias selvagens!'