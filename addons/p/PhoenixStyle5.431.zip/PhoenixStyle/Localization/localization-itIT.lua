﻿if GetLocale() == "itIT" then



function pslocale()




end

end