﻿if GetLocale() == "esMX" then

function pslocalepanda2()

end

end