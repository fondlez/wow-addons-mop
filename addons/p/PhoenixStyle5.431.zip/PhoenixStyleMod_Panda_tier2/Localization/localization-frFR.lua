﻿if GetLocale() == "frFR" then

function pslocalepanda2()


end

end