﻿


function pslocalepandam2()

pscmrlastmoduleloadtxtp1		= "Pandaria raids, tier 2"

pszzpandattaddopttxt1	  = "Report info if someone die from"
pszzpandattaddopttxt2   = "Max stacks of %s"
pszzpandattaddopttxt3    = "removing debuff info"
pszzpandattaddopttxt4   = "Show additional info if boss was healed by Blessed Loa Spirit"
pszzpandattaddopttxt5   = "Damage from |sid138319|id during |sid134380|id"
pszzpandattaddopttxt6   = "during"
pszzpandattaddopttxt7		= "players get excess damage. Addon didn`t find who was closer than 8 yd"
pszzpandattaddopttxt8		= "got %s instead of"
pszzpandattaddopttxt9		= "Closer than 8 yd"
pszzpandattaddopttxt10    = "Dispel"

pszzpandattaddopttxt12    = "players have died from"
pszzpandattaddopttxt13    = "NO damage"
pszzpandattaddopttxt14    = "Harmful debuffs"
pszzpandattaddopttxt15    = "Helpful debuffs"
pszzpandattaddopttxt16    = "Heal from"

end

