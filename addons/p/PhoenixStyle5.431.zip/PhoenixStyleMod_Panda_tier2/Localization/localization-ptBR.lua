﻿if GetLocale() == "ptBR" then

function pslocalepanda2()

end

end