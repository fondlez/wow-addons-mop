﻿if GetLocale() == "esES" then

function pslocalepanda3()

end

end