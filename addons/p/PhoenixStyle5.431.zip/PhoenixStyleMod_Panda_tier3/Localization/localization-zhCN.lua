﻿if GetLocale() == "zhCN" then


function pslocalepanda3()




end

end