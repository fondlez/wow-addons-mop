﻿if GetLocale() == "zhTW" then


function pslocalepanda3()



end

end