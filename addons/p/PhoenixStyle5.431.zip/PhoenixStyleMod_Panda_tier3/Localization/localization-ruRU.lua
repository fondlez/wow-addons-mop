﻿if GetLocale() == "ruRU" then


function pslocalepanda3()

pscmrlastmoduleloadtxtp1		= "Рейды Пандарии, патч 3"
pszzpandatuaddopttxt2   = "Получили ближних ударов"
pszzpandatuaddopttxt3   = "Прямой урон в"

end


end