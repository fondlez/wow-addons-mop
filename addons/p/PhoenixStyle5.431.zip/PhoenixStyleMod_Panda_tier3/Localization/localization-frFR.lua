﻿if GetLocale() == "frFR" then

function pslocalepanda3()


end

end