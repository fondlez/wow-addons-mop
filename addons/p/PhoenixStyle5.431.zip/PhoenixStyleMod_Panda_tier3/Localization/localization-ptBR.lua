﻿if GetLocale() == "ptBR" then

function pslocalepanda3()

end

end