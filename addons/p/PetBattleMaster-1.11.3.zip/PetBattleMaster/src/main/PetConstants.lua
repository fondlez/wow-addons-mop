--[[
	Copyright (C) Udorn (Blackhand)
--]]

petbm = petbm or {}

petbm.PetConstants = {}

-- pet types
petbm.PetConstants.HUMANOID = 1
petbm.PetConstants.DRAGON = 2
petbm.PetConstants.FLYING = 3
petbm.PetConstants.UNDEAD = 4
petbm.PetConstants.CRITTER = 5
petbm.PetConstants.MAGICAL = 6
petbm.PetConstants.ELEMENTAL = 7
petbm.PetConstants.BEAST = 8
petbm.PetConstants.WATER = 9
petbm.PetConstants.MECHANICAL = 10