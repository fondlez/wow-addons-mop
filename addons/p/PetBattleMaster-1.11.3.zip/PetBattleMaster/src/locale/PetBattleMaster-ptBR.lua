local L = LibStub("AceLocale-3.0"):NewLocale("PetBattleMaster", "ptBR", false)
if (L) then
--@START
--@END
end
