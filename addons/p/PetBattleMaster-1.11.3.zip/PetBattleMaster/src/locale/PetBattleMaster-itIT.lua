local L = LibStub("AceLocale-3.0"):NewLocale("PetBattleMaster", "itIT", false)
if (L) then
--@START
--@END
end
