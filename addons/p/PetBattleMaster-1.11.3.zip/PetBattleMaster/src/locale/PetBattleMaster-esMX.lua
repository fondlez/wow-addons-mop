local L = LibStub("AceLocale-3.0"):NewLocale("PetBattleMaster", "esMX", false)
if (L) then
--@START
--@END
end
