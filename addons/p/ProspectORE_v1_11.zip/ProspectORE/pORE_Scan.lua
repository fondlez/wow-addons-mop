
local currentItem = 0
local currentPage = 0

local function priceCheck(OldPrice, NewPrice)
	if OldPrice == 0 then return true 
	elseif OldPrice > NewPrice then return true else return false end
end

local function collectData(Name, Count, BuyOut)
	local UnitPrice = math.floor(BuyOut / Count / 100) / 100
	if currentItem == 1 then
		if Name == pORE_ITEMS.RARE_RED_GEM.name and priceCheck(pORE_ITEMS.RARE_RED_GEM.price.raw, UnitPrice) then pORE_ITEMS.RARE_RED_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.RARE_RED_GEM.cut[1].." "..pORE_ITEMS.RARE_RED_GEM.name and priceCheck(pORE_ITEMS.RARE_RED_GEM.price.bold, UnitPrice) then pORE_ITEMS.RARE_RED_GEM.price.bold = UnitPrice end
		if Name == pORE_ITEMS.RARE_RED_GEM.cut[2].." "..pORE_ITEMS.RARE_RED_GEM.name and priceCheck(pORE_ITEMS.RARE_RED_GEM.price.brilliant, UnitPrice) then pORE_ITEMS.RARE_RED_GEM.price.brilliant = UnitPrice end
		if Name == pORE_ITEMS.RARE_RED_GEM.cut[3].." "..pORE_ITEMS.RARE_RED_GEM.name and priceCheck(pORE_ITEMS.RARE_RED_GEM.price.delicate, UnitPrice) then pORE_ITEMS.RARE_RED_GEM.price.delicate = UnitPrice end
		if Name == pORE_ITEMS.RARE_RED_GEM.cut[4].." "..pORE_ITEMS.RARE_RED_GEM.name and priceCheck(pORE_ITEMS.RARE_RED_GEM.price.flashing, UnitPrice) then pORE_ITEMS.RARE_RED_GEM.price.flashing = UnitPrice end
		if Name == pORE_ITEMS.RARE_RED_GEM.cut[5].." "..pORE_ITEMS.RARE_RED_GEM.name and priceCheck(pORE_ITEMS.RARE_RED_GEM.price.precise, UnitPrice) then pORE_ITEMS.RARE_RED_GEM.price.precise = UnitPrice end
	elseif currentItem == 2 then
		if Name == pORE_ITEMS.RARE_BLUE_GEM.name and priceCheck(pORE_ITEMS.RARE_BLUE_GEM.price.raw, UnitPrice) then pORE_ITEMS.RARE_BLUE_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.RARE_BLUE_GEM.cut[1].." "..pORE_ITEMS.RARE_BLUE_GEM.name and priceCheck(pORE_ITEMS.RARE_BLUE_GEM.price.rigid, UnitPrice) then pORE_ITEMS.RARE_BLUE_GEM.price.rigid = UnitPrice end
		if Name == pORE_ITEMS.RARE_BLUE_GEM.cut[2].." "..pORE_ITEMS.RARE_BLUE_GEM.name and priceCheck(pORE_ITEMS.RARE_BLUE_GEM.price.solid, UnitPrice) then pORE_ITEMS.RARE_BLUE_GEM.price.solid = UnitPrice end
		if Name == pORE_ITEMS.RARE_BLUE_GEM.cut[3].." "..pORE_ITEMS.RARE_BLUE_GEM.name and priceCheck(pORE_ITEMS.RARE_BLUE_GEM.price.sparkling, UnitPrice) then pORE_ITEMS.RARE_BLUE_GEM.price.sparkling = UnitPrice end
		if Name == pORE_ITEMS.RARE_BLUE_GEM.cut[4].." "..pORE_ITEMS.RARE_BLUE_GEM.name and priceCheck(pORE_ITEMS.RARE_BLUE_GEM.price.stormy, UnitPrice) then pORE_ITEMS.RARE_BLUE_GEM.price.stormy = UnitPrice end
	elseif currentItem == 3 then
		if Name == pORE_ITEMS.RARE_YELLOW_GEM.name and priceCheck(pORE_ITEMS.RARE_YELLOW_GEM.price.raw, UnitPrice) then pORE_ITEMS.RARE_YELLOW_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.RARE_YELLOW_GEM.cut[1].." "..pORE_ITEMS.RARE_YELLOW_GEM.name and priceCheck(pORE_ITEMS.RARE_YELLOW_GEM.price.fractured, UnitPrice) then pORE_ITEMS.RARE_YELLOW_GEM.price.fractured = UnitPrice end
		if Name == pORE_ITEMS.RARE_YELLOW_GEM.cut[2].." "..pORE_ITEMS.RARE_YELLOW_GEM.name and priceCheck(pORE_ITEMS.RARE_YELLOW_GEM.price.mystic, UnitPrice) then pORE_ITEMS.RARE_YELLOW_GEM.price.mystic = UnitPrice end
		if Name == pORE_ITEMS.RARE_YELLOW_GEM.cut[3].." "..pORE_ITEMS.RARE_YELLOW_GEM.name and priceCheck(pORE_ITEMS.RARE_YELLOW_GEM.price.quick, UnitPrice) then pORE_ITEMS.RARE_YELLOW_GEM.price.quick = UnitPrice end
		if Name == pORE_ITEMS.RARE_YELLOW_GEM.cut[4].." "..pORE_ITEMS.RARE_YELLOW_GEM.name and priceCheck(pORE_ITEMS.RARE_YELLOW_GEM.price.smooth, UnitPrice) then pORE_ITEMS.RARE_YELLOW_GEM.price.smooth = UnitPrice end
		if Name == pORE_ITEMS.RARE_YELLOW_GEM.cut[5].." "..pORE_ITEMS.RARE_YELLOW_GEM.name and priceCheck(pORE_ITEMS.RARE_YELLOW_GEM.price.subtle, UnitPrice) then pORE_ITEMS.RARE_YELLOW_GEM.price.subtle = UnitPrice end
	elseif currentItem == 4 then
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.raw, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[1].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.accurate, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.accurate = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[2].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.assassins, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.assassins = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[3].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.defenders, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.defenders = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[4].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.etched, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.etched = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[5].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.glinting, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.glinting = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[6].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.guardians, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.guardians = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[7].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.mysterious, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.mysterious = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[8].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.purified, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.purified = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[9].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.retaliating, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.retaliating = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[10].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.shifting, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.shifting = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[11].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.sovereign, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.sovereign = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[12].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.tense, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.tense = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[13].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.timeless, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.timeless = UnitPrice end
		if Name == pORE_ITEMS.RARE_PURPLE_GEM.cut[14].." "..pORE_ITEMS.RARE_PURPLE_GEM.name and priceCheck(pORE_ITEMS.RARE_PURPLE_GEM.price.veiled, UnitPrice) then pORE_ITEMS.RARE_PURPLE_GEM.price.veiled = UnitPrice end
	elseif currentItem == 5 then
		if Name == pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.raw, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[1].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.balanced, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.balanced = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[2].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.confounded, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.confounded = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[3].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.effulgent, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.effulgent = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[4].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.energized, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.energized = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[5].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.forceful, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.forceful = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[6].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.jagged, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.jagged = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[7].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.lightning, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.lightning = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[8].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.misty, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.misty = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[9].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.nimble, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.nimble = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[10].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.piering, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.piering = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[11].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.puissant, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.puissant = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[12].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.radiant, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.radiant = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[13].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.regal, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.regal = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[14].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.seneis, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.seneis = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[15].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.shattered, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.shattered = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[16].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.steady, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.steady = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[17].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.turbid, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.turbid = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[18].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.vivid, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.vivid = UnitPrice end
		if Name == pORE_ITEMS.RARE_GREEN_GEM.cut[19].." "..pORE_ITEMS.RARE_GREEN_GEM.name and priceCheck(pORE_ITEMS.RARE_GREEN_GEM.price.zen, UnitPrice) then pORE_ITEMS.RARE_GREEN_GEM.price.zen = UnitPrice end
	elseif currentItem == 6 then
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.raw, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[1].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.adept, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.adept = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[2].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.artful, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.artful = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[3].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.champions, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.champions = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[4].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.crafty, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.crafty = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[5].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.deadly, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.deadly = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[6].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.deft, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.deft = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[7].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.fierce, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.fierce = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[8].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.fine, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.fine = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[9].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.inscribed, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.inscribed = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[10].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.keen, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.keen = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[11].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.lucent, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.lucent = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[12].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.polished, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.polished = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[13].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.potent, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.potent = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[14].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.reckless, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.reckless = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[15].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.resolute, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.resolute = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[16].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.resplendent, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.resplendent = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[17].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.skillful, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.skillful = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[18].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.splendid, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.splendid = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[19].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.stalwart, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.stalwart = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[20].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.tenuous, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.tenuous = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[21].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.wicked, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.wicked = UnitPrice end
		if Name == pORE_ITEMS.RARE_ORANGE_GEM.cut[22].." "..pORE_ITEMS.RARE_ORANGE_GEM.name and priceCheck(pORE_ITEMS.RARE_ORANGE_GEM.price.willful, UnitPrice) then pORE_ITEMS.RARE_ORANGE_GEM.price.willful = UnitPrice end
	elseif currentItem == 7 then
		if Name == pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.raw, UnitPrice) then pORE_ITEMS.META_GEM.price.raw = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[1].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.agile, UnitPrice) then pORE_ITEMS.META_GEM.price.agile = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[2].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.austere, UnitPrice) then pORE_ITEMS.META_GEM.price.austere = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[3].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.burning, UnitPrice) then pORE_ITEMS.META_GEM.price.burning = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[4].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.destructive, UnitPrice) then pORE_ITEMS.META_GEM.price.destructive = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[5].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.effulgent, UnitPrice) then pORE_ITEMS.META_GEM.price.effulgent = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[6].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.ember, UnitPrice) then pORE_ITEMS.META_GEM.price.ember = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[7].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.enigmatic, UnitPrice) then pORE_ITEMS.META_GEM.price.enigmatic = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[8].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.eternal, UnitPrice) then pORE_ITEMS.META_GEM.price.eternal = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[9].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.fleet, UnitPrice) then pORE_ITEMS.META_GEM.price.fleet = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[10].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.forlorn, UnitPrice) then pORE_ITEMS.META_GEM.price.forlorn = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[11].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.impassive, UnitPrice) then pORE_ITEMS.META_GEM.price.impassive = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[12].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.powerful, UnitPrice) then pORE_ITEMS.META_GEM.price.powerful = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[13].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.reverberating, UnitPrice) then pORE_ITEMS.META_GEM.price.reverberating = UnitPrice end
		if Name == pORE_ITEMS.META_GEM.cut[14].." "..pORE_ITEMS.META_GEM.name and priceCheck(pORE_ITEMS.META_GEM.price.revitalizing, UnitPrice) then pORE_ITEMS.META_GEM.price.revitalizing = UnitPrice end
	elseif currentItem >= 8 then
		if Name == pORE_ITEMS.ORE_1.name and priceCheck(pORE_ITEMS.ORE_1.price, UnitPrice) then pORE_ITEMS.ORE_1.price = UnitPrice end
		if Name == pORE_ITEMS.ORE_2.name and priceCheck(pORE_ITEMS.ORE_2.price, UnitPrice) then pORE_ITEMS.ORE_2.price = UnitPrice end
		if Name == pORE_ITEMS.ORE_3.name and priceCheck(pORE_ITEMS.ORE_3.price, UnitPrice) then pORE_ITEMS.ORE_3.price = UnitPrice end
		if Name == pORE_ITEMS.ORE_4.name and priceCheck(pORE_ITEMS.ORE_4.price, UnitPrice) then pORE_ITEMS.ORE_4.price = UnitPrice end
		if Name == pORE_ITEMS.ENCHANTING_DUST.name and priceCheck(pORE_ITEMS.ENCHANTING_DUST.price, UnitPrice) then pORE_ITEMS.ENCHANTING_DUST.price = UnitPrice end
		if Name == pORE_ITEMS.ENCHANTING_ESSENCE.name and priceCheck(pORE_ITEMS.ENCHANTING_ESSENCE.price, UnitPrice) then pORE_ITEMS.ENCHANTING_ESSENCE.price = UnitPrice end
	end
end

local function setScanProgress(tAuctions)
	local TotalPages = tAuctions / 50
	if TotalPages == 0 then TotalPages = 1 end
	local Overall_ProgressPercent =  (currentPage / TotalPages / table.getn(pORE_ITEM_SEARCH_LIST)) + ((currentItem - 1) / table.getn(pORE_ITEM_SEARCH_LIST))
	local Item_ProgressPercent = currentPage / TotalPages
	
	local CompleteStatusString = ""
	local CompleteStatusStringCompleted = ""
	
	for i = 1, table.getn(pORE_ITEM_SEARCH_LIST) do
		if i == currentItem then
			CompleteStatusString = CompleteStatusString.."Scanning...\n"
			CompleteStatusStringCompleted = CompleteStatusStringCompleted.."............."..math.floor(Item_ProgressPercent * 100).."%\n"
		elseif i < currentItem then
			CompleteStatusString = CompleteStatusString..pORE_ITEM_SEARCH_LIST[i].."\n"
			CompleteStatusStringCompleted = CompleteStatusStringCompleted.."...completed!\n"
		else
			CompleteStatusString = CompleteStatusString..pORE_ITEM_SEARCH_LIST[i].."\n"
		end
	end
	
	pORE_ScanAuction_ProgressBar:SetWidth(280 * Overall_ProgressPercent)
	pORE_ScanAuction_ProgressBarText:SetText("Overall Progress ("..math.floor(Overall_ProgressPercent * 100).."%)")
	pORE_ScanAuction_ItemName:SetText(pORE_ITEM_SEARCH_LIST[currentItem])
	pORE_ScanAuction_StatusReport:SetText(CompleteStatusString)
	pORE_ScanAuction_StatusReportCompleted:SetText(CompleteStatusStringCompleted)
end

local function readAuctionData()
    local BatchAuctions, TotalAuctions = GetNumAuctionItems("list")
	local RemainingItems = TotalAuctions - BatchAuctions - (currentPage * 50)
	
    for item = 1, BatchAuctions do
        local name, texture, count, quality, canUse, level, levelColHeader, minBid, minIncrement, buyoutPrice, bidAmount, highBidder, owner, saleStatus, itemId, hasAllInfo = GetAuctionItemInfo("list", item);
		collectData(name, count, buyoutPrice)
	end
	
	if RemainingItems <= 0 or currentItem <= 0 then
		currentItem = currentItem + 1
		currentPage = 0
	else
		currentPage = currentPage + 1
	end
	
	setScanProgress(TotalAuctions)
end

function pORE_resetScan()
	pORE_DisplaySelect("Results")
	pORE_Set_GemPrices() 
	
	pORE_ItemPrices_Details:Enable()
	pORE_ItemPrices_Recommendations:Enable()
	
	pORE_SCANNER.isRunning = false
	currentItem = 0
	currentPage = 0
end

local function searchAuctionHouse(Item, Page)
	if currentItem > table.getn(pORE_ITEM_SEARCH_LIST) then
		pORE_resetScan()
		pORE_Set_GemPrices()
	else
		QueryAuctionItems(Item, 0, 0, 0, 0, 0, Page, 0, 0, 0)
	end
end

local lastCycle = 0
function pORE_ScanClock(Elapsed)
	lastCycle = lastCycle + Elapsed
	
	pORE_Options_Handler()
	
	if pORE_SCANNER.atAuctionHouse then pORE_ItemPrices_ScanAuctionHouse:Enable() else pORE_ItemPrices_ScanAuctionHouse:Disable() end
	if pORE_SCANNER.isRunning then pORE_ItemPrices_ScanAuctionHouse:Disable() end
	
	if lastCycle > 0.7 or pORE_ScanAuction_QuickScan:GetChecked() then
		if pORE_SCANNER.isRunning then
			local isReady = false;
			isReady,_ = CanSendAuctionQuery("list");
			if (isReady == 1 and pORE_SCANNER.atAuctionHouse) then
				readAuctionData()
				searchAuctionHouse(pORE_ITEM_SEARCH_LIST[currentItem], currentPage)
			end
		end
		lastCycle = 0
	end
end

















