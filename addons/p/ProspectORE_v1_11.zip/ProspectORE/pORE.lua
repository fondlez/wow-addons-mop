






local function FormatText(String)
	local FormattedString = String
	while true do  
		FormattedString, k = string.gsub(FormattedString, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k == 0) then break end
	end
	return FormattedString
end

pORE_Button_Details = function()
	if pORE_Details:IsVisible() then
		pORE_DisplaySelect("Results")
	else
		pORE_DisplaySelect("Details")
	end
end

pORE_Button_PriceList = function(List)
	if List == 1 and pORE_RedGem_PriceList:IsVisible() ~= 1 then pORE_RedGem_PriceList:Show() else pORE_RedGem_PriceList:Hide() end
	if List == 2 and pORE_BlueGem_PriceList:IsVisible() ~= 1 then pORE_BlueGem_PriceList:Show() else pORE_BlueGem_PriceList:Hide() end
	if List == 3 and pORE_YellowGem_PriceList:IsVisible() ~= 1 then pORE_YellowGem_PriceList:Show() else pORE_YellowGem_PriceList:Hide() end
	if List == 4 and pORE_PurpleGem_PriceList:IsVisible() ~= 1 then pORE_PurpleGem_PriceList:Show() else pORE_PurpleGem_PriceList:Hide() end
	if List == 5 and pORE_GreenGem_PriceList:IsVisible() ~= 1 then pORE_GreenGem_PriceList:Show() else pORE_GreenGem_PriceList:Hide() end
	if List == 6 and pORE_OrangeGem_PriceList:IsVisible() ~= 1 then pORE_OrangeGem_PriceList:Show() else pORE_OrangeGem_PriceList:Hide() end
	if List == 7 and pORE_MetaGem_PriceList:IsVisible() ~= 1 then pORE_MetaGem_PriceList:Show() else pORE_MetaGem_PriceList:Hide() end
	if List == 8 and pORE_MiscItem_PriceList:IsVisible() ~= 1 then pORE_MiscItem_PriceList:Show() else pORE_MiscItem_PriceList:Hide() end
end

pORE_Button_Recommended = function()
	if pORE_Recommendation:IsVisible() then
		pORE_DisplaySelect("Results")
	else
		pORE_DisplaySelect("Recommended")
	end
end

pORE_Options_Handler = function()
	if pORE_Options_Alchemy:GetChecked() then
		
	else
		pORE_Options_Transmute:SetChecked(false)
		pORE_Options_MetaGemOnly:SetChecked(false)
	end
end

pORE_Reset_GemPrices = function()
	pORE_ITEMS.RARE_RED_GEM.price.raw = 0
	pORE_ITEMS.RARE_RED_GEM.price.bold = 0
	pORE_ITEMS.RARE_RED_GEM.price.brilliant = 0
	pORE_ITEMS.RARE_RED_GEM.price.delicate = 0
	pORE_ITEMS.RARE_RED_GEM.price.flashing = 0
	pORE_ITEMS.RARE_RED_GEM.price.precise = 0
	
	pORE_ITEMS.RARE_BLUE_GEM.price.raw = 0
	pORE_ITEMS.RARE_BLUE_GEM.price.rigid = 0
	pORE_ITEMS.RARE_BLUE_GEM.price.solid = 0
	pORE_ITEMS.RARE_BLUE_GEM.price.sparkling = 0
	pORE_ITEMS.RARE_BLUE_GEM.price.stormy = 0
	
	pORE_ITEMS.RARE_YELLOW_GEM.price.raw = 0
	pORE_ITEMS.RARE_YELLOW_GEM.price.fractured = 0
	pORE_ITEMS.RARE_YELLOW_GEM.price.mystic = 0
	pORE_ITEMS.RARE_YELLOW_GEM.price.quick = 0
	pORE_ITEMS.RARE_YELLOW_GEM.price.smooth = 0
	pORE_ITEMS.RARE_YELLOW_GEM.price.subtle = 0
	
	pORE_ITEMS.RARE_PURPLE_GEM.price.raw = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.accurate = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.assassins = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.defenders = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.etched = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.glinting = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.guardians = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.mysterious = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.purified = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.retaliating = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.shifting = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.sovereign = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.tense = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.timeless = 0
	pORE_ITEMS.RARE_PURPLE_GEM.price.veiled = 0
	
	pORE_ITEMS.RARE_GREEN_GEM.price.raw = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.balanced = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.confounded = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.effulgent = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.energized = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.forceful = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.jagged = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.lightning = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.misty = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.nimble = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.piering = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.puissant = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.radiant = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.regal = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.seneis = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.shattered = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.steady = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.turbid = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.vivid = 0
	pORE_ITEMS.RARE_GREEN_GEM.price.zen = 0
	
	pORE_ITEMS.RARE_ORANGE_GEM.price.raw = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.adept = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.artful = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.champions = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.crafty = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.deadly = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.deft = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.fierce = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.fine = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.inscribed = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.keen = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.lucent = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.polished = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.potent = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.reckless = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.resolute = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.resplendent = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.skillful = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.splendid = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.stalwart = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.tenuous = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.wicked = 0
	pORE_ITEMS.RARE_ORANGE_GEM.price.willful = 0
	
	pORE_ITEMS.META_GEM.price.raw = 0
	pORE_ITEMS.META_GEM.price.agile = 0
	pORE_ITEMS.META_GEM.price.austere = 0
	pORE_ITEMS.META_GEM.price.burning = 0
	pORE_ITEMS.META_GEM.price.destructive = 0
	pORE_ITEMS.META_GEM.price.effulgent = 0
	pORE_ITEMS.META_GEM.price.ember = 0
	pORE_ITEMS.META_GEM.price.enigmatic = 0
	pORE_ITEMS.META_GEM.price.eternal = 0
	pORE_ITEMS.META_GEM.price.fleet = 0
	pORE_ITEMS.META_GEM.price.forlorn = 0
	pORE_ITEMS.META_GEM.price.impassive = 0
	pORE_ITEMS.META_GEM.price.powerful = 0
	pORE_ITEMS.META_GEM.price.reverberating = 0
	pORE_ITEMS.META_GEM.price.revitalizing = 0
	
	pORE_ITEMS.ORE_1.price = 0
	pORE_ITEMS.ORE_2.price = 0
	pORE_ITEMS.ORE_3.price = 0
	pORE_ITEMS.ORE_4.price = 0
	pORE_ITEMS.ENCHANTING_DUST.price = 0
	pORE_ITEMS.ENCHANTING_ESSENCE.price = 0
	
	pORE_Set_GemPrices()
end

pORE_Save_GemPrices = function()
	if pORE_SCANNER.isRunning then return end

	pORE_ITEMS.RARE_RED_GEM.price.raw = _G["pORE_RedGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.RARE_RED_GEM.price.bold = _G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.RARE_RED_GEM.price.brilliant = _G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.RARE_RED_GEM.price.delicate = _G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.RARE_RED_GEM.price.flashing = _G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[4].."Price"]:GetText()
	pORE_ITEMS.RARE_RED_GEM.price.precise = _G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[5].."Price"]:GetText()
	
	pORE_ITEMS.RARE_BLUE_GEM.price.raw = _G["pORE_BlueGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.RARE_BLUE_GEM.price.rigid = _G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.RARE_BLUE_GEM.price.solid = _G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.RARE_BLUE_GEM.price.sparkling = _G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.RARE_BLUE_GEM.price.stormy = _G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[4].."Price"]:GetText()
	
	pORE_ITEMS.RARE_YELLOW_GEM.price.raw = _G["pORE_YellowGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.RARE_YELLOW_GEM.price.fractured = _G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.RARE_YELLOW_GEM.price.mystic = _G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.RARE_YELLOW_GEM.price.quick = _G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.RARE_YELLOW_GEM.price.smooth = _G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[4].."Price"]:GetText()
	pORE_ITEMS.RARE_YELLOW_GEM.price.subtle = _G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[5].."Price"]:GetText()
	
	pORE_ITEMS.RARE_PURPLE_GEM.price.raw = _G["pORE_PurpleGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.accurate = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.assassins = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.defenders = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.etched = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[4].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.glinting = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[5].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.guardians = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[6].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.mysterious = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[7].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.purified = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[8].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.retaliating = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[9].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.shifting = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[10].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.sovereign = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[11].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.tense = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[12].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.timeless = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[13].."Price"]:GetText()
	pORE_ITEMS.RARE_PURPLE_GEM.price.veiled = _G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[14].."Price"]:GetText()
	
	pORE_ITEMS.RARE_GREEN_GEM.price.raw = _G["pORE_GreenGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.balanced = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.confounded = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.effulgent = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.energized = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[4].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.forceful = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[5].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.jagged = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[6].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.lightning = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[7].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.misty = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[8].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.nimble = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[9].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.piering = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[10].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.puissant = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[11].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.radiant = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[12].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.regal = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[13].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.seneis = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[14].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.shattered = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[15].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.steady = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[16].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.turbid = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[17].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.vivid = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[18].."Price"]:GetText()
	pORE_ITEMS.RARE_GREEN_GEM.price.zen = _G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[19].."Price"]:GetText()
	
	pORE_ITEMS.RARE_ORANGE_GEM.price.raw = _G["pORE_OrangeGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.adept = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.artful = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.champions = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.crafty = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[4].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.deadly = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[5].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.deft = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[6].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.fierce = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[7].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.fine = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[8].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.inscribed = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[9].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.keen = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[10].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.lucent = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[11].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.polished = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[12].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.potent = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[13].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.reckless = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[14].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.resolute = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[15].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.resplendent = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[16].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.skillful = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[17].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.splendid = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[18].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.stalwart = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[19].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.tenuous = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[20].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.wicked = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[21].."Price"]:GetText()
	pORE_ITEMS.RARE_ORANGE_GEM.price.willful = _G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[22].."Price"]:GetText()
	
	pORE_ITEMS.META_GEM.price.raw = _G["pORE_MetaGem_PriceList_ListFrame_RawPrice"]:GetText()
	pORE_ITEMS.META_GEM.price.agile = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[1].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.austere = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[2].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.burning = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[3].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.destructive = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[4].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.effulgent = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[5].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.ember = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[6].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.enigmatic = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[7].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.eternal = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[8].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.fleet = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[9].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.forlorn = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[10].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.impassive = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[11].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.powerful = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[12].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.reverberating = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[13].."Price"]:GetText()
	pORE_ITEMS.META_GEM.price.revitalizing = _G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[14].."Price"]:GetText()
	
	pORE_ITEMS.ORE_1.price = _G["pORE_MiscItem_PriceList_ListFrame_ORE_1Price"]:GetText()
	pORE_ITEMS.ORE_2.price = _G["pORE_MiscItem_PriceList_ListFrame_ORE_2Price"]:GetText()
	pORE_ITEMS.ORE_3.price = _G["pORE_MiscItem_PriceList_ListFrame_ORE_3Price"]:GetText()
	pORE_ITEMS.ORE_4.price = _G["pORE_MiscItem_PriceList_ListFrame_ORE_4Price"]:GetText()
	pORE_ITEMS.ENCHANTING_DUST.price = _G["pORE_MiscItem_PriceList_ListFrame_ENCHANTING_DUSTPrice"]:GetText()
	pORE_ITEMS.ENCHANTING_ESSENCE.price = _G["pORE_MiscItem_PriceList_ListFrame_ENCHANTING_ESSENCEPrice"]:GetText()
end

pORE_Set_Details = function(Red, Blue, Yellow, Purple, Green, Orange, Meta, Jewelry, Dust, Essence, Prospect, Craft, FLAGS)
	local TotalValue = math.floor(Red + Blue + Yellow)
	if FLAGS.enchanting then TotalValue = TotalValue + Dust + Essence else TotalValue = TotalValue + Jewelry end
	if FLAGS.meta then TotalValue = TotalValue + Meta else TotalValue = TotalValue + Purple + Green + Orange end

	local l_red = math.floor(Red)
	local l_blue = math.floor(Blue)
	local l_yellow = math.floor(Yellow)
	local l_purple = math.floor(Purple)
	local l_green = math.floor(Green)
	local l_orange = math.floor(Orange)
	local l_meta = math.floor(Meta)
	local l_jewelry = math.floor(Jewelry)
	local l_dust = math.floor(Dust)
	local l_essence = math.floor(Essence)
	
	local p_red = math.floor(l_red / TotalValue * 100)
	local p_blue = math.floor(l_blue / TotalValue * 100)
	local p_yellow = math.floor(l_yellow / TotalValue * 100)
	local p_purple = math.floor(l_purple / TotalValue * 100)
	local p_green = math.floor(l_green / TotalValue * 100)
	local p_orange = math.floor(l_orange / TotalValue * 100)
	local p_meta = math.floor(l_meta / TotalValue * 100)
	local p_jewelry = math.floor(l_jewelry / TotalValue * 100)
	local p_dust = math.floor(l_dust / TotalValue * 100)
	local p_essence = math.floor(l_essence / TotalValue * 100)
	
	if TotalValue <= 0 then
		p_red = 0
		p_blue = 0
		p_yellow = 0
		p_purple = 0
		p_green = 0
		p_orange = 0
		p_meta = 0
		p_jewelry = 0
		p_dust = 0
		p_essence = 0
	end
	
	if FLAGS.enchanting then
		l_jewelry = 0
		p_jewelry = 0
	else
		l_dust = 0
		p_dust = 0
		l_essence = 0
		p_essence = 0
	end
	
	if FLAGS.meta then
		l_purple = 0
		p_purple = 0
		l_green = 0
		p_green = 0
		l_orange = 0
		p_orange = 0
	else
		l_meta = 0
		p_meta = 0
	end
	
	local t_Prospect = Prospect * 4 * 3.2
	local t_Crafting = Craft * 1.9
	local t_Disenchant = Craft * 2.2
	
	if FLAGS.enchanting then else t_Disenchant = 0 end
	
	local t_Overall = t_Prospect + t_Crafting + t_Disenchant
	
	local function setTime(Time)
		if Time >= 604800 then return "|cffaaaaaaToo long..." end
		local t_Time = ""
		local Day = math.floor(Time / 86400)
		local Hour = math.floor((Time - (Day * 86400)) / 3600)
		local Minute = math.floor((Time - (Day * 86400) - (Hour * 3600)) / 60)
		local Second = math.floor(Time - (math.floor(Time / 60) * 60))
		if Day > 0 then t_Time = t_Time.."|cffffffff"..Day.."|cffedda74d " end
		if Hour > 0 then t_Time = t_Time.."|cffffffff"..Hour.."|cffedda74h " end
		if Minute > 0 then t_Time = t_Time.."|cffffffff"..Minute.."|cffedda74m " end
		if Second > 0 then t_Time = t_Time.."|cffffffff"..Second.."|cffedda74s" end
		return t_Time
	end
	
	if Prospect > 0 then t_Prospect = setTime(t_Prospect) else t_Prospect = "|cffaaaaaaN/A" end
	if Craft > 0 then t_Crafting = setTime(t_Crafting) else t_Crafting = "|cffaaaaaaN/A" end
	if FLAGS.enchanting then t_Disenchant = setTime(t_Disenchant) else t_Disenchant = "|cffaaaaaaN/A" end
	if t_Overall > 0 then t_Overall = setTime(t_Overall) else t_Overall = "|cffaaaaaaN/A" end
	
	pORE_Details_RedGem_Profit:SetText("+|cff33cc33"..FormatText(l_red).."|cffedda74g")
	pORE_Details_RedGem_Percent:SetText("|cffccccff("..p_red.."%)")
	pORE_Details_BlueGem_Profit:SetText("+|cff33cc33"..FormatText(l_blue).."|cffedda74g")
	pORE_Details_BlueGem_Percent:SetText("|cffccccff("..p_blue.."%)")
	pORE_Details_YellowGem_Profit:SetText("+|cff33cc33"..FormatText(l_yellow).."|cffedda74g")
	pORE_Details_YellowGem_Percent:SetText("|cffccccff("..p_yellow.."%)")
	pORE_Details_PurpleGem_Profit:SetText("+|cff33cc33"..FormatText(l_purple).."|cffedda74g")
	pORE_Details_PurpleGem_Percent:SetText("|cffccccff("..p_purple.."%)")
	pORE_Details_GreenGem_Profit:SetText("+|cff33cc33"..FormatText(l_green).."|cffedda74g")
	pORE_Details_GreenGem_Percent:SetText("|cffccccff("..p_green.."%)")
	pORE_Details_OrangeGem_Profit:SetText("+|cff33cc33"..FormatText(l_orange).."|cffedda74g")
	pORE_Details_OrangeGem_Percent:SetText("|cffccccff("..p_orange.."%)")
	pORE_Details_MetaGem_Profit:SetText("+|cff33cc33"..FormatText(l_meta).."|cffedda74g")
	pORE_Details_MetaGem_Percent:SetText("|cffccccff("..p_meta.."%)")
	pORE_Details_Jewelry_Profit:SetText("+|cff33cc33"..FormatText(l_jewelry).."|cffedda74g")
	pORE_Details_Jewelry_Percent:SetText("|cffccccff("..p_jewelry.."%)")
	pORE_Details_EnchantDust_Profit:SetText("+|cff33cc33"..FormatText(l_dust).."|cffedda74g")
	pORE_Details_EnchantDust_Percent:SetText("|cffccccff("..p_dust.."%)")
	pORE_Details_EnchantEssence_Profit:SetText("+|cff33cc33"..FormatText(l_essence).."|cffedda74g")
	pORE_Details_EnchantEssence_Percent:SetText("|cffccccff("..p_essence.."%)")
	
	pORE_Details_EstProspect_Time:SetText(t_Prospect)
	pORE_Details_EstCrafting_Time:SetText(t_Crafting)
	pORE_Details_EstDisenchant_Time:SetText(t_Disenchant)
	pORE_Details_EstOverall_Time:SetText(t_Overall)
end

pORE_Set_GemPrices = function()
	_G["pORE_RedGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.RARE_RED_GEM.price.raw)
	_G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.RARE_RED_GEM.price.bold)
	_G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.RARE_RED_GEM.price.brilliant)
	_G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.RARE_RED_GEM.price.delicate)
	_G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.RARE_RED_GEM.price.flashing)
	_G["pORE_RedGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_RED_GEM.cut[5].."Price"]:SetText(pORE_ITEMS.RARE_RED_GEM.price.precise)
	
	_G["pORE_BlueGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.RARE_BLUE_GEM.price.raw)
	_G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.RARE_BLUE_GEM.price.rigid)
	_G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.RARE_BLUE_GEM.price.solid)
	_G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.RARE_BLUE_GEM.price.sparkling)
	_G["pORE_BlueGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_BLUE_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.RARE_BLUE_GEM.price.stormy)
	
	_G["pORE_YellowGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.RARE_YELLOW_GEM.price.raw)
	_G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.RARE_YELLOW_GEM.price.fractured)
	_G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.RARE_YELLOW_GEM.price.mystic)
	_G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.RARE_YELLOW_GEM.price.quick)
	_G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.RARE_YELLOW_GEM.price.smooth)
	_G["pORE_YellowGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_YELLOW_GEM.cut[5].."Price"]:SetText(pORE_ITEMS.RARE_YELLOW_GEM.price.subtle)
	
	_G["pORE_PurpleGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.raw)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.accurate)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.assassins)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.defenders)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.etched)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[5].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.glinting)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[6].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.guardians)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[7].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.mysterious)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[8].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.purified)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[9].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.retaliating)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[10].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.shifting)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[11].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.sovereign)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[12].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.tense)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[13].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.timeless)
	_G["pORE_PurpleGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_PURPLE_GEM.cut[14].."Price"]:SetText(pORE_ITEMS.RARE_PURPLE_GEM.price.veiled)
	
	_G["pORE_GreenGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.raw)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.balanced)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.confounded)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.effulgent)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.energized)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[5].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.forceful)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[6].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.jagged)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[7].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.lightning)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[8].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.misty)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[9].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.nimble)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[10].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.piering)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[11].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.puissant)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[12].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.radiant)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[13].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.regal)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[14].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.seneis)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[15].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.shattered)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[16].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.steady)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[17].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.turbid)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[18].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.vivid)
	_G["pORE_GreenGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_GREEN_GEM.cut[19].."Price"]:SetText(pORE_ITEMS.RARE_GREEN_GEM.price.zen)
	
	_G["pORE_OrangeGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.raw)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.adept)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.artful)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.champions)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.crafty)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[5].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.deadly)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[6].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.deft)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[7].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.fierce)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[8].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.fine)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[9].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.inscribed)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[10].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.keen)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[11].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.lucent)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[12].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.polished)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[13].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.potent)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[14].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.reckless)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[15].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.resolute)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[16].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.resplendent)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[17].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.skillful)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[18].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.splendid)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[19].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.stalwart)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[20].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.tenuous)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[21].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.wicked)
	_G["pORE_OrangeGem_PriceList_ListFrame_"..pORE_ITEMS.RARE_ORANGE_GEM.cut[22].."Price"]:SetText(pORE_ITEMS.RARE_ORANGE_GEM.price.willful)
	
	_G["pORE_MetaGem_PriceList_ListFrame_RawPrice"]:SetText(pORE_ITEMS.META_GEM.price.raw)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[1].."Price"]:SetText(pORE_ITEMS.META_GEM.price.agile)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[2].."Price"]:SetText(pORE_ITEMS.META_GEM.price.austere)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[3].."Price"]:SetText(pORE_ITEMS.META_GEM.price.burning)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[4].."Price"]:SetText(pORE_ITEMS.META_GEM.price.destructive)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[5].."Price"]:SetText(pORE_ITEMS.META_GEM.price.effulgent)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[6].."Price"]:SetText(pORE_ITEMS.META_GEM.price.ember)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[7].."Price"]:SetText(pORE_ITEMS.META_GEM.price.enigmatic)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[8].."Price"]:SetText(pORE_ITEMS.META_GEM.price.eternal)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[9].."Price"]:SetText(pORE_ITEMS.META_GEM.price.fleet)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[10].."Price"]:SetText(pORE_ITEMS.META_GEM.price.forlorn)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[11].."Price"]:SetText(pORE_ITEMS.META_GEM.price.impassive)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[12].."Price"]:SetText(pORE_ITEMS.META_GEM.price.powerful)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[13].."Price"]:SetText(pORE_ITEMS.META_GEM.price.reverberating)
	_G["pORE_MetaGem_PriceList_ListFrame_"..pORE_ITEMS.META_GEM.cut[14].."Price"]:SetText(pORE_ITEMS.META_GEM.price.revitalizing)
	
	_G["pORE_MiscItem_PriceList_ListFrame_ORE_1Price"]:SetText(pORE_ITEMS.ORE_1.price)
	_G["pORE_MiscItem_PriceList_ListFrame_ORE_2Price"]:SetText(pORE_ITEMS.ORE_2.price)
	_G["pORE_MiscItem_PriceList_ListFrame_ORE_3Price"]:SetText(pORE_ITEMS.ORE_3.price)
	_G["pORE_MiscItem_PriceList_ListFrame_ORE_4Price"]:SetText(pORE_ITEMS.ORE_4.price)
	_G["pORE_MiscItem_PriceList_ListFrame_ENCHANTING_DUSTPrice"]:SetText(pORE_ITEMS.ENCHANTING_DUST.price)
	_G["pORE_MiscItem_PriceList_ListFrame_ENCHANTING_ESSENCEPrice"]:SetText(pORE_ITEMS.ENCHANTING_ESSENCE.price)
end

pORE_Set_ProspectedData = function(Data)
	pORE_Results_rRedGemValue:SetText(FormatText(Data[1]))
	pORE_Results_rBlueGemValue:SetText(FormatText(Data[2]))
	pORE_Results_rYellowGemValue:SetText(FormatText(Data[3]))
	pORE_Results_rPurpleGemValue:SetText(FormatText(Data[4]))
	pORE_Results_rGreenGemValue:SetText(FormatText(Data[5]))
	pORE_Results_rOrangeGemValue:SetText(FormatText(Data[6]))
	pORE_Results_rTotalValue:SetText(FormatText(Data[1] + Data[2] + Data[3] + Data[4] + Data[5] + Data[6]))
	pORE_Results_uRedGemValue:SetText(FormatText(Data[7]))
	pORE_Results_uBlueGemValue:SetText(FormatText(Data[8]))
	pORE_Results_uYellowGemValue:SetText(FormatText(Data[9]))
	pORE_Results_uPurpleGemValue:SetText(FormatText(Data[10]))
	pORE_Results_uGreenGemValue:SetText(FormatText(Data[11]))
	pORE_Results_uOrangeGemValue:SetText(FormatText(Data[12]))
	pORE_Results_uTotalValue:SetText(FormatText(Data[7] + Data[8] + Data[9] + Data[10] + Data[11] + Data[12]))
end

pORE_Set_Recommended = function(tRed, tBlue, tYellow, tPurple, tGreen, tOrange, tMeta, Status, Disenchant)
	local ForceUncut = pORE_Options_RawGemOnly:GetChecked()

	local Recommended_Text = ""
	local SellCut = ": |cffcdffdcCut the following designs..."
	local SellRaw = ": |cffffddccSell the gem raw..."
	
	local JewelryStatus = "Vendor"
	
	local RedCuts = "          |cffffffff"..tRed[1]..", "..tRed[2]..", "..tRed[3].."\n\n"
	local BlueCuts = "          |cffffffff"..tBlue[1]..", "..tBlue[2]..", "..tBlue[3].."\n\n"
	local YellowCuts = "          |cffffffff"..tYellow[1]..", "..tYellow[2]..", "..tYellow[3].."\n\n"
	local PurpleCuts = "          |cffffffff"..tPurple[1]..", "..tPurple[2]..", "..tPurple[3].."\n\n"
	local GreenCuts = "          |cffffffff"..tGreen[1]..", "..tGreen[2]..", "..tGreen[3].."\n\n"
	local OrangeCuts = "          |cffffffff"..tOrange[1]..", "..tOrange[2]..", "..tOrange[3].."\n\n"
	local MetaCuts = "          |cffffffff"..tMeta[1]..", "..tMeta[2]..", "..tMeta[3].."\n\n"
	
	local redStatus = SellRaw
	local blueStatus = SellRaw
	local yellowStatus = SellRaw
	local purpleStatus = SellRaw
	local greenStatus = SellRaw
	local orangeStatus = SellRaw
	local metaStatus = SellRaw
	
	if Status.red then redStatus = SellCut else RedCuts = "\n\n" end
	if Status.blue then blueStatus = SellCut else BlueCuts = "\n\n" end
	if Status.yellow then yellowStatus = SellCut else YellowCuts = "\n\n" end
	if Status.purple then purpleStatus = SellCut else PurpleCuts = "\n\n" end
	if Status.green then greenStatus = SellCut else GreenCuts = "\n\n" end
	if Status.orange then orangeStatus = SellCut else OrangeCuts = "\n\n" end
	if Status.meta then metaStatus = SellCut else MetaCuts = "\n\n" end
	
	if ForceUncut then
		redStatus = SellRaw RedCuts = "\n\n"
		blueStatus = SellRaw BlueCuts = "\n\n"
		yellowStatus = SellRaw YellowCuts = "\n\n"
		purpleStatus = SellRaw PurpleCuts = "\n\n"
		greenStatus = SellRaw GreenCuts = "\n\n"
		orangeStatus = SellRaw OrangeCuts = "\n\n"
		metaStatus = SellRaw MetaCuts = "\n\n"
	end
	
	if Disenchant and pORE_Options_Enchanting:GetChecked() then JewelryStatus = "Disenchant" end
	
	Recommended_Text =
	"     |cffff5555"..pORE_ITEMS.RARE_RED_GEM.name..redStatus.."\n"..
	RedCuts..
	"     |cff5555ff"..pORE_ITEMS.RARE_BLUE_GEM.name..blueStatus.."\n"..
	BlueCuts..
	"     |cffffff55"..pORE_ITEMS.RARE_YELLOW_GEM.name..yellowStatus.."\n"..
	YellowCuts..
	"     |cffff55ff"..pORE_ITEMS.RARE_PURPLE_GEM.name..purpleStatus.."\n"..
	PurpleCuts..
	"     |cff33ff33"..pORE_ITEMS.RARE_GREEN_GEM.name..greenStatus.."\n"..
	GreenCuts..
	"     |cffff9933"..pORE_ITEMS.RARE_ORANGE_GEM.name..orangeStatus.."\n"..
	OrangeCuts..
	"     |cffccffff"..pORE_ITEMS.META_GEM.name..metaStatus.."\n"..
	MetaCuts..
	"     |cffccffcc".."Rings & Necklaces"..": |cffcdffdcCraft".."\n"..
	"          |cffffffff"..JewelryStatus.." |cff00ff00uncommon|cffffffff rings and necklaces".."\n"..
	"          |cffffffff".."Sell or "..JewelryStatus.." |cff6060ffrare|cffffffff rings and necklaces".."\n"
	
	pORE_Recommendation_List:SetText(Recommended_Text)
end

pORE_Set_RevenueData = function(Data)
	pORE_EstProfit_ORE_1_Cost:SetText(Data[1])
	pORE_EstProfit_ORE_1_Revenue:SetText(Data[2])
	pORE_EstProfit_ORE_1_Profit:SetText(Data[3])
	pORE_EstProfit_ORE_2_Cost:SetText(Data[4])
	pORE_EstProfit_ORE_2_Revenue:SetText(Data[5])
	pORE_EstProfit_ORE_2_Profit:SetText(Data[6])
	pORE_EstProfit_ORE_3_Cost:SetText(Data[7])
	pORE_EstProfit_ORE_3_Revenue:SetText(Data[8])
	pORE_EstProfit_ORE_3_Profit:SetText(Data[9])
	pORE_EstProfit_ORE_4_Cost:SetText(Data[10])
	pORE_EstProfit_ORE_4_Revenue:SetText(Data[11])
	pORE_EstProfit_ORE_4_Profit:SetText(Data[12])
	pORE_EstProfit_GrandTotalValue:SetText(Data[3] + Data[6] + Data[9] + Data[12])
	
	local function setColor(Object, Dir)
		local Field = tonumber(Object:GetText())
		if Dir > 0 then R = 1 G = 0 else R = 0 G = 1 end
		if Field == 0 then Object:SetTextColor(1, 1, 1, 1)
		elseif Field > 0 then Object:SetTextColor(R, G, 0, 1)
		else Object:SetTextColor(G, R, 0, 1)
		end
		
		Object:SetText(FormatText(Field))
	end
	
	setColor(pORE_EstProfit_ORE_1_Cost, 1)
	setColor(pORE_EstProfit_ORE_1_Revenue, 0)
	setColor(pORE_EstProfit_ORE_1_Profit, 0)
	setColor(pORE_EstProfit_ORE_2_Cost, 1)
	setColor(pORE_EstProfit_ORE_2_Revenue, 0)
	setColor(pORE_EstProfit_ORE_2_Profit, 0)
	setColor(pORE_EstProfit_ORE_3_Cost, 1)
	setColor(pORE_EstProfit_ORE_3_Revenue, 0)
	setColor(pORE_EstProfit_ORE_3_Profit, 0)
	setColor(pORE_EstProfit_ORE_4_Cost, 1)
	setColor(pORE_EstProfit_ORE_4_Revenue, 0)
	setColor(pORE_EstProfit_ORE_4_Profit, 0)
	setColor(pORE_EstProfit_GrandTotalValue, 0)
end

pORE_ToggleAddon = function()
	if pORE:IsVisible() then
		pORE:Hide()
	else
		pORE:Show()
		pORE:SetPropagateKeyboardInput(true)
	end
end

pORE_DisplaySelect = function(Display)
	pORE_Details:Hide()
	pORE_ScanAuction:Hide()
	pORE_Recommendation:Hide()
	pORE_Results:Hide()
	
	if Display == "Results" then pORE_Results:Show()
	elseif Display == "ScanAuction" then pORE_ScanAuction:Show()
	elseif Display == "Recommended" then pORE_Recommendation:Show()
	elseif Display == "Details" then pORE_Details:Show()
	end
end

pORE_atAuctionHouse = function(Loc)
	pORE_SCANNER.atAuctionHouse = Loc
end

pORE_StartAuctionScan = function()
	pORE_ItemPrices_Details:Disable()
	pORE_ItemPrices_Recommendations:Disable()
	
	pORE_Reset_GemPrices()

	pORE_DisplaySelect("ScanAuction")
	pORE_SCANNER.isRunning = true
end

local function setOptionStates()
	if pORE_ITEMS.SAVED_STATES.alchemy == nil then pORE_ITEMS.SAVED_STATES.alchemy = false end
	if pORE_ITEMS.SAVED_STATES.transmute == nil then pORE_ITEMS.SAVED_STATES.transmute = false end
	if pORE_ITEMS.SAVED_STATES.forcemeta == nil then pORE_ITEMS.SAVED_STATES.forcemeta = false end
	if pORE_ITEMS.SAVED_STATES.enchant == nil then pORE_ITEMS.SAVED_STATES.enchant = false end
	if pORE_ITEMS.SAVED_STATES.rawonly == nil then pORE_ITEMS.SAVED_STATES.rawonly = false end
	if pORE_ITEMS.SAVED_STATES.fastscan == nil then pORE_ITEMS.SAVED_STATES.fastscan = false end
	pORE_Options_Alchemy:SetChecked(pORE_ITEMS.SAVED_STATES.alchemy)
	pORE_Options_Transmute:SetChecked(pORE_ITEMS.SAVED_STATES.transmute)
	pORE_Options_MetaGemOnly:SetChecked(pORE_ITEMS.SAVED_STATES.forcemeta)
	pORE_Options_Enchanting:SetChecked(pORE_ITEMS.SAVED_STATES.enchant)
	pORE_Options_RawGemOnly:SetChecked(pORE_ITEMS.SAVED_STATES.rawonly)
	pORE_ScanAuction_QuickScan:SetChecked(pORE_ITEMS.SAVED_STATES.fastscan)
end

pORE_SaveOptionStates = function()
	pORE_ITEMS.SAVED_STATES.alchemy = pORE_Options_Alchemy:GetChecked()
	pORE_ITEMS.SAVED_STATES.transmute = pORE_Options_Transmute:GetChecked()
	pORE_ITEMS.SAVED_STATES.forcemeta = pORE_Options_MetaGemOnly:GetChecked()
	pORE_ITEMS.SAVED_STATES.enchant = pORE_Options_Enchanting:GetChecked()
	pORE_ITEMS.SAVED_STATES.rawonly = pORE_Options_RawGemOnly:GetChecked()
	pORE_ITEMS.SAVED_STATES.fastscan = pORE_ScanAuction_QuickScan:GetChecked()
end










local welcomeMessage = true

SlashCmdList["pORE_CONSOLE"] = function(message)
	if message == "reset" then pORE_Reset_GemPrices()
	elseif message == "sync" then pORE_DataSyncMenu:Show()
	elseif message == "help" then print(pORE_INFO.commands)
	else pORE_ToggleAddon() end
end

local _eventListener = CreateFrame("Frame")
_eventListener:RegisterEvent("ADDON_LOADED")
_eventListener:RegisterEvent("AUCTION_HOUSE_SHOW")
_eventListener:RegisterEvent("AUCTION_HOUSE_CLOSED")

local _eventHandler = function(Frame, Event)
	if Event=="ADDON_LOADED" then pORE_Set_GemPrices() setOptionStates() if welcomeMessage then welcomeMessage = false print(pORE_INFO.welcome) end end
	if Event=="AUCTION_HOUSE_SHOW" then pORE_atAuctionHouse(true) end
	if Event=="AUCTION_HOUSE_CLOSED" then pORE_atAuctionHouse(false) pORE_resetScan() end
end

local _clockTimer = function(Self, Elapsed)
	pORE_ScanClock(Elapsed)
end

_eventListener:SetScript("OnEvent", _eventHandler)
_eventListener:SetScript("OnUpdate", _clockTimer)


