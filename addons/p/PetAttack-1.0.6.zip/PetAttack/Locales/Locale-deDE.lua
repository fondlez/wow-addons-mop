local L = LibStub("AceLocale-3.0"):NewLocale("PetAttack", "deDE")
if not L then return end

-- To help localize PetAttack please enter phrase translations on the
-- following URL:
-- http://www.wowace.com/projects/petattack/localization/
-- This file should not be edited manually!

-- L["PET IS NOT ATTACKING"] = ""

