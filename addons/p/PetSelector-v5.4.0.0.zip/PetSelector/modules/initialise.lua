local PetSelector = PetSelector
PetSelector.debug = false
PetSelector.L = LibStub("AceLocale-3.0"):GetLocale("PetSelector")

--only react to game events for Hunters - not a lot of point otherwise
if select(2, UnitClass("player")) == "HUNTER" then
	PetSelector.frame:RegisterEvent("ADDON_LOADED")
	PetSelector.frame:RegisterEvent("PLAYER_LOGIN")
	PetSelector.frame:SetScript("OnEvent", function(...) PetSelector:eventHandler(...) end)
end

local L = PetSelector.L

PetSelector.PlayerLevel = UnitLevel("player")
PetSelector.Buffs = {false}
PetSelector.talents = {}
PetSelector.exclude = {}

--List of exotic pets
PetSelector.ExoticPets = {
	L["Chimaera"],
	L["Core Hound"],
	L["Devilsaur"],
	L["Rhino"],
	L["Shale Spider"],
	L["Silithid"],
	L["Spirit Beast"],
	L["Worm"],
	L["Quilen"],
}

--Pet buff priority
PetSelector.PetBuffs = {
	[1] = {L["Core Hound"]},
	[2] = {L["Quilen"]},
	[3] = {L["Shale Spider"]},
	[4] = {L["Cat"], L["Spirit Beast"]},
	[5] = {L["Hydra"], L["Wolf"], L["Devilsaur"], L["Quilen"], L["Waterstrider"]},
	[6] = {L["Silithid"]},
	[7] = {L["Hyena"], L["Serpent"]},
	[8] = {L["Waterstrider"]},
	[9] = {L["Dragonhawk"], L["Wind Serpent"]},
	[10] = {L["Boar"], L["Ravager"], L["Rhino"], L["Worm"]},
	[11] = {L["Raptor"], L["Tallstrider"]},
	[12] = {L["Carrion Bird"], L["Bear"]},
	[13] = {L["Sporebat"], L["Fox"], L["Goat"], L["Core Hound"]},
	[14] = {L["Devilsaur"]},
}

--Spell ID of the relevant pet buff
--added pet class 1 - Ferocity, 2 - Cunning, 3 - Tenacity
PetSelector.PetInfo = {
	[1] = {L["Core Hound"], 90355, 1},
	[2] = {L["Shale Spider"], 90363, 3},
	[3] = {L["Silithid"], 90364, 2},
	[4] = {L["Raptor"], 50498, 1},
	[5] = {L["Serpent"], 128433, 2},
	[6] = {L["Devilsaur"], 90309, 1},
	[7] = {L["Wolf"], 24604, 1},
	[8] = {L["Worm"], 55749, 3},
	[9] = {L["Ravager"], 50518, 2},
	[10] = {L["Dragonhawk"], 34889, 2},
	[11] = {L["Wind Serpent"], 24844, 2},
	[12] = {L["Spirit Beast"], 128997, 1},
	[13] = {L["Cat"], 93435, 1},
	[14] = {L["Hyena"], 128432, 1},
	[15] = {L["Rhino"], 57386, 3},
	[16] = {L["Boar"], 35290, 3},
	[17] = {L["Sporebat"], 50274, 2},
	[18] = {L["Fox"], 90314, 1},
	[19] = {L["Tallstrider"], 50285, 1},
	[20] = {L["Carrion Bird"], 24423, 1},
	[21] = {L["Bear"], 50256, 3},
	[22] = {L["Bat"], 50519, 2},
	[23] = {L["Beetle"], 90339, 3},
	[24] = {L["Bird of Prey"], 91644, 2},
	[25] = {L["Chimaera"], 54644, 2},
	[26] = {L["Crab"], 50245, 3},
	[27] = {L["Crocolisk"], 50433, 3},
	[28] = {L["Dog"], 90327, 1},
	[29] = {L["Gorilla"], 26090, 3},
	[30] = {L["Monkey"], 90337, 2},
	[31] = {L["Moth"], 50318, 1},
	[32] = {L["Nether Ray"], 50479, 2},
	[33] = {L["Scorpid"], 50541, 3},
	[34] = {L["Spider"], 4167, 2},
	[35] = {L["Turtle"], 26064, 3},
	[36] = {L["Warp Stalker"], 35346, 3},
	[37] = {L["Wasp"], 56626, 1},
	[38] = {L["Waterstrider"], 126309, 1},
	[39] = {L["Hydra"], 97229, 1},
	[40] = {L["Quilen"], 126393, 1},
	[41] = {L["Goat"], 126402, 1},
	[42] = {L["Basilisk"], 126423, 1},
	[43] = {L["Crane"], 126246, 1},
	[44] = {L["Porcupine"], 126355, 1},
	[45] = {L["Direhorn"], 137798, 3},
}

--Raid buffs in priority order, who can provide them
--and what talent spec, talents they need
-- {class, tree, spellid, hordespellid}
PetSelector.PlayerBuffs = {
	[1] = {	-- Burst haste
		{"SHAMAN", nil, 32182, 2825},
		{"MAGE", nil, 80353},
		{"HUNTER", nil, L["Core Hound"]},
	},
	[2] = { -- Combat Res
		{"DEATHKNIGHT", nil, 61999},
		{"DRUID", nil, 20484},
		{"WARLOCK", nil, 20707},
		{"HUNTER", nil, L["Quilen"]},
	},
	[3] = { -- +5% Strength, agility, intellect
		{"DRUID", nil, 1126},
		{"MONK", nil, 115921},
		{"PALADIN", nil, 20217},
		{"HUNTER", nil, L["Shale Spider"]},
	},
	[4] = { -- +3000 mastery
		{"PALADIN", nil, 19740},
		{"SHAMAN", 2, 116956},
		{"HUNTER", nil, L["Cat"]},
	},
	[5] = { -- +5% Critical Strike
		{"DRUID", 2, 17007},
		{"DRUID", 3, 17007},
		{"MAGE", nil, 1459},
		{"MONK", 3, 116781},
		{"HUNTER", nil, L["Wolf"]},
	},
	[6] = { -- +10% Stamina
		{"PRIEST", nil, 21562},
		{"WARLOCK", nil, 6307},
		{"WARRIOR", nil, 469},
		{"HUNTER", nil, L["Silithid"]},
	},
	[7] = { -- +10% Attack Speed
		{"DEATHKNIGHT", 2, 55610},
		{"DEATHKNIGHT", 3, 55610},
		{"ROGUE", nil, 113742},
		{"HUNTER", nil, L["Hyena"]},
	},
	[8] = { -- +10% Spell Power
		{"MAGE", nil, 1459},
		{"SHAMAN", nil, 77747},
		{"WARLOCK", nil, 109773},
		{"HUNTER", nil, L["Waterstrider"]},
	},
	[9] = { -- +8% Spell Damage Taken
		{"WARLOCK", nil, 1490},
		{"ROGUE", 1, 58410},
		{"HUNTER", nil, L["Dragonhawk"]},
	},
	[10] = { -- +4% Physical Damage Taken
		{"DEATHKNIGHT", 2, 81328},
		{"DEATHKNIGHT", 3, 51160},
		{"PALADIN", 3, 111529},
		{"WARRIOR", 1, 86346},
		{"WARRIOR", 2, 86346},
		{"HUNTER", nil, L["Boar"]},
	},
	[11] = { -- -4% Armour (yes, I'm British, that's how we spell it here) x 3
		{"DRUID", nil, 770},
		{"WARRIOR", 1, 7386},
		{"WARRIOR", 2, 20243},
		{"ROGUE", nil, 8647},
		{"HUNTER", nil, L["Raptor"]},
	},
	[12] = { -- -10% Physical Damage dealt
		{"WARRIOR", nil, 6343},
		{"WARLOCK", nil, 109466},
		{"DRUID", 2, 106830},
		{"DRUID", 3, 77758},
		{"DEATHKNIGHT", 1, 81132},
		{"PALADIN", 2, 53595},
		{"PALADIN", 3, 53595},
		{"MONK", 1, 121253},
		{"SHAMAN", 1, 8042},
		{"SHAMAN", 2, 8042},
		{"HUNTER", nil, L["Carrion Bird"]},
	},
	[13] = { -- Casting Speed Reduction
		{"DEATHKNIGHT", nil, 73975},
		{"MAGE", 1, 31589},
		{"ROGUE", nil, 5761},
		{"WARLOCK", nil, 109466},
		{"HUNTER", nil, L["Fox"]},
	},
	[14] = { -- Healing Reduction
		{"MONK", 3, 107428},
		{"ROGUE", nil, 8679},
		{"WARRIOR", 1, 12294},
		{"WARRIOR", 2, 100130},
		{"HUNTER", nil, L["Devilsaur"]},
	},
}

StaticPopupDialogs["PETSELECTOR_STABLED"] = {
	text = "",
	button1 = _G.OKAY,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}

StaticPopupDialogs["PETSELECTOR_MACROS"] = {
	text = L["You have too many character specific macros, Pet Selector cannot create a new one"],
	button1 = _G.OKAY,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1
}