local _G = _G
local AceConfig = LibStub("AceConfig-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local AceDBOptions = LibStub("AceDBOptions-3.0")
local PetSelector = PetSelector
local L = PetSelector.L
local CreateFrame, UIParent = CreateFrame, UIParent

--First visible frame
local function createMainPanel()
	local frame = CreateFrame("Frame", "PetSelectorOptionsMain")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local version = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	local author = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetFormattedText("|T%s:%d|t %s", "Interface\\ICONS\\Ability_Hunter_BestialDiscipline", 32, "Pet Selector")
	title:SetPoint("CENTER", frame, "CENTER", 0, 170)
	version:SetText(_G.GAME_VERSION_LABEL .. " " .. GetAddOnMetadata("PetSelector", "Version"))
	version:SetPoint("CENTER", frame, "CENTER", 0, 130)
	author:SetText(L["Author"] .. ": Deepac")
	author:SetPoint("CENTER", frame, "CENTER", 0, 100)
	return frame
end

--options frame
local checkPanel = {
	order = 1,
	type = "group",
	name = _G.MAIN_MENU,
	args = {
		hidebutton = {
			order = 1,
			type = "toggle",
			name = L["Hide Pet Selector's button"],
			width = "full",
			get = function() return PetSelector.db.profile.hidebutton end,
			set = function(info, value)
					PetSelector.db.profile.hidebutton = not PetSelector.db.profile.hidebutton
					PetSelector:DisplayFrames()
				end,
		},
		hidecheck = {
			order = 2,
			type = "toggle",
			name = L["Only show when in a party"],
			width = "full",
			get = function() return PetSelector.db.profile.showinparty end,
			set = function(info, value) 
					PetSelector.db.profile.showinparty = not PetSelector.db.profile.showinparty 
					PetSelector:DisplayFrames()
				end,
		},
		stabled = {
			order = 3,
			type = "toggle",
			name = L["Include stabled pets"],
			width = "full",
			get = function() return PetSelector.db.profile.stabled end,
			set = function(info, value)
					PetSelector.db.profile.stabled = not PetSelector.db.profile.stabled
					PetSelector:SetPet()
				end,
		},
		buffsframe = {
			order = 4,
			type = "toggle",
			name = L["Show buffs frame"],
			width = "full",
			get = function() return PetSelector.db.profile.showbuffs end,
			set = function(info, value)
					PetSelector.db.profile.showbuffs = not PetSelector.db.profile.showbuffs
					PetSelector:DisplayFrames()
				end,
		},
		missing = {
			order = 5,
			type = "toggle",
			name = L["Show missing pets"],
			desc = L["Display a list of pet buffs you are not currently capable of providing"],
			width = "full",
			get = function() return PetSelector.db.profile.showmissing end,
			set = function(info, value)
					PetSelector.db.profile.showmissing = not PetSelector.db.profile.showmissing
					PetSelector:DisplayFrames()
				end,
		},
		lockcheck = {
			order = 6,
			type = "toggle",
			name = L["Lock position"],
			width = "full",
			get = function() return PetSelector.db.profile.locked end,
			set = function(info, value) PetSelector.db.profile.locked = not PetSelector.db.profile.locked end,
		},
		showMinimapIcon = {
			order = 7,
			type = "toggle",
			width = "full",
			name = L["Minimap Icon"],
			desc = L["Toggle Minimap icon"],
			get = function() return not PetSelector.db.profile.minimap.hide end,
			set = function(info, value)
					PetSelector.db.profile.minimap.hide = not value
					if value then PetSelector.mmicon:Show("PetSelector")
					else PetSelector.mmicon:Hide("PetSelector") end
				end,
		},
		solotank = {
			order = 8,
			type = "toggle",
			width = "full",
			name = L["Use tanking pet when solo"],
			desc = L["Select a tenacity pet when you are not in a group"],
			get = function() return PetSelector.db.profile.solotank end,
			set = function(info, value) PetSelector.db.profile.solotank = not PetSelector.db.profile.solotank; PetSelector:SetPet() end,
		},
		spacer1 = {
			order = 9,
			type = "description",
			name = "\n",
		},
		scale = {
			order = 10,
			type = 'range',
			name = _G.UI_SCALE,
			min = 0.25,
			max = 2.0,
			isPercent = true,
			step = 0.01,
			width = 'full',
			get = function() return PetSelector.db.profile.scale end,
			set = 
				function(info, value)
					PetSelector.db.profile.scale = value
					PetSelector.button:SetScale(value)
				end,
		},
	},
}

--respond to Default button/Profile reset
function PetSelector:profileReset()
	local f = PetSelectorMainFrame
	local b = PetSelectorBuffFrame
	f:SetScale(self.db.profile.scale)
	f:ClearAllPoints()
	f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", self.db.profile.x, self.db.profile.y)
	b:SetScale(self.db.profile.scale)
	b:ClearAllPoints()
	b:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", self.db.profile.bx, self.db.profile.by)
	PetSelector:DisplayFrames()
end

--Setup options
function PetSelector:createPetSelectorOptions()
	local mainPanel = createMainPanel()
	mainPanel.name = "Pet Selector"
	InterfaceOptions_AddCategory(mainPanel)
	--make sure Pet Selector's reset sub is called in response to a profile reset
	self.db.RegisterCallback(self, "OnProfileReset", "profileReset")
	AceConfig:RegisterOptionsTable("PetSelectorCheck", checkPanel)
	AceConfig:RegisterOptionsTable("PetSelectorProfiles", AceDBOptions:GetOptionsTable(self.db))
	self.optionschecks = AceConfigDialog:AddToBlizOptions("PetSelectorCheck", _G.MAIN_MENU, "Pet Selector")
	--make sure Pet Selector's reset function is call in response to the user clicking the Default button
	self.optionschecks.default = function() self.db:ResetProfile() end
	AceConfigDialog:AddToBlizOptions("PetSelectorProfiles", L["Profiles"], "Pet Selector")
end