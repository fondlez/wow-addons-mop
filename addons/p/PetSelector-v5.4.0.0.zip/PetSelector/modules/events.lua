local _G = _G
local L = PetSelector.L
local GetSpellInfo = GetSpellInfo
local PetSelector = PetSelector
local UIDropDownMenu_AddButton = UIDropDownMenu_AddButton
local CreateFrame, UIParent = CreateFrame, UIParent
local ipairs, select, wipe = ipairs, select, wipe
local GetNumGroupMembers = GetNumGroupMembers
local UnitFactionGroup = UnitFactionGroup
local LibStub = LibStub

function PetSelector:SetPet()
	local pet
	if self.incombat then return end
	self:UpdatePetSpec()
	self:CheckBuffs()
	pet = self:SelectPet()
	if pet then self.button.icon:SetTexture(pet.icon) end
end

--LDB functions
local function setBindMacro(petdata)
	local data, macro
	if petdata then data = petdata
	else data = PetSelector.db.profile.bindpet end
	macro = PetSelector:SetPetMacro(data)
	PetSelectorSecureFrame:SetAttribute("type1", "macro")
    PetSelectorSecureFrame:SetAttribute("macrotext1", macro)
end

local function createLDBMenu()
	local LDBMenu = CreateFrame("Frame", "PetSelectorLDBMenu")
	local pet, pets
	LDBMenu.displayMode = "MENU"
	LDBMenu.info = {}
	LDBMenu.HideMenu = function() if UIDROPDOWNMENU_OPEN_MENU == LDBMenu then CloseDropDownMenus() end end
	LDBMenu.initialize = 
		function(self, level)
			if not level then return end
			local info = self.info
			local t = L["Pet Selector"]
			wipe(info)
			if level == 1 then
				info.isTitle = 1
				info.text = t
				info.notCheckable = 1
				UIDropDownMenu_AddButton(info, level)

				info.keepShownOnClick = 1
				info.disabled = nil
				info.isTitle = nil

				info.text = L["Key bind specific pet"]
				info.hasArrow = 1
				info.value = "keybind"
				UIDropDownMenu_AddButton(info, level)

				info.text = ""
				info.func = nil
				info.hasArrow = nil
				info.value = nil
				UIDropDownMenu_AddButton(info,level)

				info.text = L["Show buffs frame"]
				info.disabled = not(PetSelector.inparty or PetSelector.debug)
				info.func = function() PetSelector.db.profile.showbuffs = true; PetSelector:DisplayFrames(); self.HideMenu() end
				UIDropDownMenu_AddButton(info, level)

				info.text = L["Show missing pets"]
				info.func = function() PetSelector.db.profile.showmissing = true; PetSelector:DisplayFrames(); self.HideMenu() end
				info.disabled = nil
				UIDropDownMenu_AddButton(info, level)

				info.text = ""
				info.func = nil
				UIDropDownMenu_AddButton(info,level)

				info.text = _G.MAIN_MENU
				info.func = function() InterfaceOptionsFrame_OpenToCategory(PetSelector.optionschecks) end
				UIDropDownMenu_AddButton(info, level)

				-- Close menu item
				info.text = _G.CLOSE
				info.func = self.HideMenu
				UIDropDownMenu_AddButton(info, level)
			elseif level == 2 then
				if UIDROPDOWNMENU_MENU_VALUE == "keybind" then
					pets = PetSelector:GetPets(false)
					for _, pet in ipairs(pets) do
						info.text = pet.name .. " |cff00bfff" .. pet.family .. "|r"
						info.checked = (PetSelector.db.profile.bindpet.slot == pet.slot)
						info.arg1 = pet
						info.func = function(data, petdata)
										PetSelector.db.profile.bindpet = petdata
										setBindMacro(petdata)
									end
						UIDropDownMenu_AddButton(info, level)
					end
				end
			end
		end
end

local function LDBOnClick(self, button) ToggleDropDownMenu(1, nil, PetSelectorLDBMenu, self:GetName(), 0, 0) end

function PetSelector:UpdatePetSpec()
	local petname = UnitName("pet")
	local family = UnitCreatureFamily("pet")
	local spec = GetSpecialization(nil, 1)
	local found
	if not spec then return end
	if not self.db.profile.petspecs then self.db.profile.petspecs = {} end
	for i, s in ipairs(self.db.profile.petspecs) do
		if s.name == petname and s.family == family then
			self.db.profile.petspecs[i].spec = spec
			found = true
			break
		end
	end
	if not found then table.insert(self.db.profile.petspecs, {name=petname, family=family, spec=spec}) end
end

--watch events
function PetSelector:eventHandler(this, event, arg1, ...)
	local activepet, ldblib
	if event == "ADDON_LOADED" and arg1 == "PetSelector" then
		if PetSelectorDB == nil then PetSelectorDB = {} end
		--configure LDB
		createLDBMenu()
		ldblib = LibStub:GetLibrary("LibDataBroker-1.1")
		self.ldb = ldblib:NewDataObject(L["Pet Selector"], {
			type = "data source", 
			text = L["Pet Selector"],
			icon = "Interface\\ICONS\\Ability_Hunter_BestialDiscipline",
			OnClick = LDBOnClick			
		})
		function self.ldb.OnTooltipShow(tip)
			local missing = self:GetMissingPets()
			local pet, buff, c
			tip:AddLine(L["Pet Selector"])
			tip:AddLine(" ")
			tip:AddLine("|cffffffff" .. _G.GAME_VERSION_LABEL .. " " .. GetAddOnMetadata("PetSelector", "Version"))
			tip:AddLine(" ")
			if #missing > 0 then
				tip:AddLine(L["Missing Pets"])
				for c, pet in ipairs(missing) do
					--if c > 12 then break end
					buff = select(3, GetSpellInfo(pet.buff))
					tip:AddLine("|T" .. buff .. ":16|t |cffffffff" .. pet.family)
				end
			else tip:AddLine(L["No missing pets"]) end
		end
		--configure binding
		BINDING_HEADER_PETSELECTOR = L["Pet Selector"]
		_G["BINDING_NAME_CLICK PetSelectorSecureFrame:LeftButton"] = L["Call Specific Pet"]
		_G["BINDING_NAME_CLICK PetSelectorSecureFrame2:LeftButton"] = L["Call Selected Pet"]
		CreateFrame("Button", "PetSelectorSecureFrame", UIParent, "SecureActionButtonTemplate")
		CreateFrame("Button", "PetSelectorSecureFrame2", UIParent, "SecureActionButtonTemplate")
		PetSelectorSecureFrame2:SetAttribute("type1", "macro")
		PetSelectorSecureFrame2:SetAttribute( "macro1", "Pet Selector")
		--v5.0.0.2
		--load blizz macro ui so constants are available
		if not IsAddOnLoaded("Blizzard_MacroUI") then LoadAddOn("Blizzard_MacroUI") end
	elseif event == "PLAYER_LOGIN" then
		--configure options
		self.defaults = {
			profile = {
			showinparty = true,
			locked = false,
			stabled = true,
			x = (UIParent:GetWidth() - 32) / 2,
			y = (UIParent:GetHeight() - 32) / 2,
			bx = ((UIParent:GetWidth() - 150) / 2) + 32,
			by = (UIParent:GetHeight() - 300) /2,
			px = ((UIParent:GetWidth() - 150) / 2),
			py = (UIParent:GetHeight() - 300) /2,
			scale = UIParent:GetScale(),
			bfskin = "Blizzard",
			bfgloss = 0,
			bfbackdrop = false,
			bfcolours = {},
			bindpet = {},
			minimap = {hide = false},
			hidebutton = false,
			solotank = false,
			},
		}
		self.frame:RegisterEvent("PLAYER_LEVEL_UP")
		self.frame:RegisterEvent("PLAYER_REGEN_ENABLED")
		self.frame:RegisterEvent("PLAYER_REGEN_DISABLED")
		self.frame:RegisterEvent("GROUP_ROSTER_UPDATE")
		self.frame:RegisterEvent("PARTY_MEMBER_DISABLED")
		self.frame:RegisterEvent("PARTY_MEMBER_ENABLED")
		self.frame:RegisterEvent("PET_STABLE_UPDATE")
		self.frame:RegisterEvent("PET_SPECIALIZATION_CHANGED")
		self.frame:RegisterEvent("UNIT_PET")
		self.frame:RegisterEvent("UNIT_LEVEL")
		self.faction = UnitFactionGroup("player")
		self.db = LibStub("AceDB-3.0"):New("PetSelectorVars", self.defaults, "profile")
		self:createPetSelectorOptions()	
		--minimap icon
		self.mmicon = LibStub("LibDBIcon-1.0")
		self.mmicon:Register("PetSelector", self.ldb, self.db.profile.minimap)
		--create main frame
		self:CreatePetFrame()
		self:CreateBuffFrame(false)
		self:CreateBuffFrame(true)
		self:DisplayFrames()
		if self.db.profile.bindpet then setBindMacro() end
	elseif event == "PLAYER_LEVEL_UP" then
		--force a rescan if the player levels up
		self.PlayerLevel = arg1
		self:SetPet()
	elseif event == "PET_STABLE_UPDATE" or event == "PET_SPECIALIZATION_CHANGED" then
		self:SetPet()
	elseif event == "UNIT_PET" then
		if arg1 == "player" then
			if not self.random then self:SetPet() end
		else self:SetPet() end
	elseif (event == "UNIT_LEVEL") and (arg1 == "pet") then
		self:SetPet()
	elseif event == "GROUP_ROSTER_UPDATE" or event == "PARTY_MEMBER_DISABLED" or event == "PARTY_MEMBER_ENABLED" then
		if GetNumGroupMembers() > 0 then self.inparty = true
		else self.inparty = nil end
		self:DisplayFrames()
		self:SetPet()
	elseif event == "PLAYER_REGEN_ENABLED" then
		self.incombat = nil
	elseif event == "PLAYER_REGEN_DISABLED" then
		self.incombat = true
	end
end