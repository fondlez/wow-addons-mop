local L = PetSelector.L
local GetStablePetInfo = GetStablePetInfo
local GetSpellInfo = GetSpellInfo
local white = "|cffffffff"
local _G = _G
local string, setmetatable, getmetatable = string, setmetatable, getmetatable
local pairs, ipairs, table, select, GetLocale = pairs, ipairs, table, select, GetLocale
local CreateMacro, EditMacro, GetMacroIndexByName, GetNumMacros, DeleteMacro = CreateMacro, EditMacro, GetMacroIndexByName, GetNumMacros, DeleteMacro

-- Returns the currently suggested pet
-- Icon, Name, Level, Family, Type (Ferocity, Cunning, Tenacity), Stable Slot, Is it exotic?

function PetSelector:GetSelectedPet()
	local pet = self.selectedpet
	if pet then return pet.icon, pet.name, pet.level, pet.family, pet.class, pet.slot, pet.exotic
	else return nil end
end

-- Attempts to create/edit a macro to summon the selected pet

--for Korean locale which uses Roman numerals in place of Arabic numbers
local function GetRN(val)
	local rn
	if val == 1 then rn = "i"
	elseif val == 2 then rn = "ii"
	elseif val == 3 then rn = "iii"
	elseif val == 4 then rn = "iv"
	elseif val == 5 then rn = "v"
	end
	return rn
end

function PetSelector:SetPetMacro(petdata)
	local pet = petdata or self.selectedpet
	local mid, body, nid
	local callmacro = L["callmacro"]
	local kr = GetLocale() == "koKR"
	if not pet then return end
	if not pet.slot then return end

	--fix for Korean locale
	if kr then callmacro = string.gsub(callmacro, "%%d", "%%s") end
	body = "" --"#show Call Pet\n"

	--pet is in the stable
	if pet.slot > 5 then 
		StaticPopupDialogs["PETSELECTOR_STABLED"].text = string.format(L["%s is stabled"], pet.name)
		body = body .. "/run StaticPopup_Show(\"PETSELECTOR_STABLED\")"
	elseif pet.slot == 0 then
		--pet is already active
		body = body .. L["revivemacro"] .. "\n" .. string.format(callmacro, (kr and GetRN(pet.slot) or pet.slot))
	else
		body = body .. L["dismissmacro"] .. "\n" .. string.format(callmacro, (kr and GetRN(pet.slot) or pet.slot))
	end

	if not petdata then
		--does the macro already exist?
		mid = GetMacroIndexByName("Pet Selector")
		--v5.0.0.2 remove macro from general macros
		if mid <= _G.MAX_ACCOUNT_MACROS then
			DeleteMacro(mid)
			mid = 0
		end
		
		if mid == 0 then
			--no extant macro, so create one
			--Ticket 5, need to check max macros
			local accnum, chrnum = GetNumMacros()
			if chrnum < _G.MAX_CHARACTER_MACROS then
				mid = CreateMacro("Pet Selector", "Ability_Hunter_BeastCall", body, 1) --char specific macro as of 5.0.0.2
			else
				StaticPopup_Show("PETSELECTOR_MACROS")
			end
		else
			--edit an existing macro
			nid = EditMacro(mid, nil, nil, body)
		end
	else return body end
end

--[[
	Returns a table of (all) the hunter's pets 
	AllPets = include stabled pets (any non-nil value)
	returns:
 [1] = {
	icon = In game pet icon,
	name = The pet's name,
	level = The pet's level,
	family = The pet's family (localised),
	class = Tenacity | Ferocity | Cunning (localised),
	slot = Stable slot (anything over 5 is with the stable master)
	exotic = Is this an exotic pet?
 }
 --]]

 local function getPetSpec(name, family)
	if not PetSelector.db.profile.petspecs then PetSelector.db.profile.petspecs = {} end
	for _, s in ipairs(PetSelector.db.profile.petspecs) do
		if s.name == name and s.family == family then return s.spec end
	end
 end
 
function PetSelector:GetPets(AllPets)
	local pets = {}
	local icon, name, level, family, class, slot
	for slot = 1, 25 do
		icon, name, level, family, class = GetStablePetInfo(slot)
		if name then
			--if self.debug then print(slot .. ": " .. name .. " l: " .. level .. " f: " .. family) end
			if ((slot > 5) and (self.db.profile.stabled or AllPets)) or (slot < 6) then
				table.insert(pets, {icon = icon, name = name, level = level, family = family, class = class, slot = slot, exotic = self:IsExotic(family), spec = getPetSpec(name, family)})
			end
		end
	end
	return pets
end

local function tcopy(t)
	local u = {}
	local k, v
	for k, v in pairs(t) do u[k] = v end
	return setmetatable(u, getmetatable(t))
end

--[[
	Returns a table of any pet buffs the hunter cannot currently provide
	returns:
 [1] = {
	family = The pet's family (localised),
	buff = The spell ID of the buff that pet can provide
 }
 --]]
 
local function isDuplicate(detail, pet)
	for _, d in ipairs(detail) do if d.family == pet then return true end end
	return false
end

local function sortPets(a, b) return a.family < b.family end

function PetSelector:GetMissingPets()
	local missing = tcopy(self.PetBuffs)
	local pets = self:GetPets(true)
	local detail = {}
	local pet, buff, ptype, hpet, buff, buffs, idx

	for idx, pet in ipairs(self.PetBuffs) do
		for _, ptype in ipairs(pet) do
			for _, hpet in ipairs(pets) do
				if hpet.family == ptype then
					missing[idx] = nil
					break
				end
			end
		end
	end

	if #missing > 0 then
		for _, pets in ipairs(missing) do
			for _, pet in ipairs(pets) do
				buff = nil
				for _, buffs in ipairs(self.PetInfo) do
					if buffs[1] == pet then buff = buffs[2] end
				end
				if not isDuplicate(detail, pet) then table.insert(detail,{family = pet, buff = buff}) end
			end
		end
	end
	--table.sort(detail, sortPets)
	return detail
end

function PetSelector:PopulateMissing()
	local missing = self:GetMissingPets()
	local pet, index, sicon
	if #missing == 0 then _G["PetSelectorPetProvider1"]:SetText(white .. L["No missing pets"])
	else 	
		for index, pet in ipairs(missing) do
			if index > 14 then break end
			sicon = select(3, GetSpellInfo(pet.buff))
			_G["PetSelectorPetIcon" .. index]:SetTexture(sicon)
			_G["PetSelectorPet" .. index].spellid = pet.buff
			_G["PetSelectorPetProvider" .. index]:SetText(white .. pet.family)
		end
	end
end

-- Returns true if petfamily is an exotic pet family
-- returns nil otherwise
-- petfamily is the localised pet family name

function PetSelector:IsExotic(petfamily)
	local exotic, family
	for _, family in ipairs(self.ExoticPets) do
		if petfamily == family then
			exotic = true
			break
		end
	end
	return exotic
end