PetSelector = select(2, ...)
PetSelector.frame = CreateFrame("Frame")