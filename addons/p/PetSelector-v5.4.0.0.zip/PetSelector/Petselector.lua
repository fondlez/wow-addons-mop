local _G = _G
local PetSelector = PetSelector
local pairs, ipairs, math, table, wipe = pairs, ipairs, math, table, wipe
local UnitCreatureType = UnitCreatureType
local GetNumGroupMembers, IsInRaid = GetNumGroupMembers, IsInRaid
local UIDropDownMenu_AddButton = UIDropDownMenu_AddButton
local ToggleDropDownMenu, CloseDropDownMenu = ToggleDropDownMenu, CloseDropDownMenu
local InterfaceOptionsFrame_OpenToCategory = InterfaceOptionsFrame_OpenToCategory
local select = select
local GameTooltip = GameTooltip
local L = PetSelector.L
local GetSpellInfo = GetSpellInfo
local GetSpecialization = GetSpecialization
local CreateFrame, UIParent = CreateFrame, UIParent
local UnitName = UnitName
local UnitClass = UnitClass
local grey = "|cff778899"
local white = "|cffffffff"
local LBM = LibStub("LibMasque", true)
local LBF

if not LBM then LBF =  LibStub("LibButtonFacade", true) end

--find an available pet that matches the supplied family
local function findPet(family, pets)
	local pet
	for _, v in ipairs(pets) do
		if v.family == family then if (v.slot < 5) or PetSelector.db.profile.stabled then pet = v end end
	end
	return pet
end

--scan the potentially available buffs and select the most
--appropriate pet
local function getPetBuff(family)
	local buff
	for pri, pbuff in ipairs(PetSelector.PetInfo) do
		if pbuff[1] == family then
			buff = pbuff[2]
			break
		end
	end
	return buff
end

local function setBuff(index, pclass, player, petfamily)
	local sicon, sid, buff, pc
	if PetSelector.debug then
		pclass = "DRUID"
		player = "TestPlayer"
	end
	if pclass then
		if pclass == "HUNTER" then sid = getPetBuff(petfamily)
		else
			buff = PetSelector.PlayerBuffs[index]
			for _, pc in ipairs(buff) do
				if pc[1] == pclass then
					sid = pc[3]
					break
				end
			end
		end
	else sid = PetSelector.PlayerBuffs[index][1][3] end
	if not sid then return end
	if (index == 1) and (PetSelector.faction == "Horde") and (pclass == "SHAMAN") then
		sid = PetSelector.PlayerBuffs[index][1][4]
		sicon = select(3, GetSpellInfo(sid))
	else sicon = select(3, GetSpellInfo(sid)) end
	_G["PetSelectorBuffIcon" .. index]:SetTexture(sicon)
	_G["PetSelectorBuff" .. index].spellid = sid
	_G["PetSelectorBuff" .. index].player = player
	if player then _G["PetSelectorBuffProvider" .. index]:SetText(white .. player)
	else _G["PetSelectorBuffProvider" .. index]:SetText(grey .. "<" .. L["not detected"] .. ">") end
end

local function getRelevantPet(pets, solo)
		local t = 1
		local rnd, pet, solotank
		--pick a random pet from those not in the stable
		if #pets == 0 then return end
		while true do
			rnd = math.random(25)
			if pets[rnd] then
				if pets[rnd].slot < 6 then solotank = true
					if solo and (pets[rnd].spec == 2) then solotank = true
					elseif solo then solotank = false end
					if PetSelector.selectedpet and solotank then
						if (PetSelector.selectedpet.name ~= pets[rnd].name) or solo then pet = pets[rnd]; break end
					elseif solotank then pet = pets[rnd]; break end
				end
			end
			--prevent an infinite loop in the event there are no pets are found
			t = t + 1
			if t > 50 then break end
		end
	return pet
end

function PetSelector:SelectPet()
	local buff, petfamily, bmpet
	local isBM = GetSpecialization() == 1
	local start = isBM and 1 or 4
	local pet, rnd, v, t, index
	local pets = self:GetPets()
	self.random = nil
	if self.inparty then
		for buff = start, #self.Buffs do
			if self.Buffs[buff] == false then
				for _, petfamily in pairs(self.PetBuffs[buff]) do
					if self:IsExotic(petfamily) then
						if isBM then bmpet = findPet(petfamily, pets) end
					else pet = findPet(petfamily, pets) end
				end
				if isBM and bmpet then pet = bmpet end
				if pet then index = buff end
			end
			if pet then break end
		end
	else --solo
		pet = getRelevantPet(pets, self.db.profile.solotank)
		self.random = true
	end
	if (not pet) and (#pets > 0) then
		pet = getRelevantPet(pets, false)
		self.random = true
	elseif pet and self.inparty then setBuff(index, "HUNTER", UnitName("player"), pet.family) end
	self.selectedpet = pet
	self:SetPetMacro()
	return pet
end

--build a table representing potentially available buffs
local function getHunterPet(pname, players, pre)
	local prefix = pre .. "pet"
	local index, p, petname, pet
	for p = 1, players do if UnitName(pre .. p) == pname then pet = UnitCreatureType(prefix .. p); break end end
	--if PetSelector.debug then print("hunter: " .. (pname or "nil") .. " pet: " .. (pet or "nil")) end
	return pet
end

local function checkHunterPet(index, pet)
	local family, found
	if not pet then return end
	for _, family in ipairs(PetSelector.PetBuffs[index]) do if family == pet then found = true; break end end
	return found
end

--[[
local function CheckTree(...)
	local t1 = select(2, ...)
	local t2 = select(3, ...)
	local t3 = select(4, ...)
	local t = 1
	if t1 == nil then return false end
	if t2 == nil then return false end
	if t3 == nil then return false end
	if t2 > t1 and t2 > t3 then t = 2 end
	if t3 > t1 and t3 > t2 then t = 3 end
	return t
end
]]--

local function IsExcluded(player, buff)
	local ex, isex
	for _, ex in ipairs(PetSelector.exclude) do if (ex.player == player) and (ex.id == buff) then isex = true; break end end
	return isex
end

function PetSelector:CheckBuffs()
	local unitid, class, pclass, pname
	local buff, n, tree, player
	local players = GetNumGroupMembers()
	local prefix = "raid"
	local sicon, pet, hbuff, s

	hbuff = {}
	if not IsInRaid() then prefix = "party" end

	--reinitialise buff table
	for buff = 1, 14 do
		self.Buffs[buff] = false
		setBuff(buff)
		hbuff[buff] = false
	end

	--no point checking the buffs if we're not in a group
	if (not self.inparty) or (players == 0) then return end

	--rebuild buff table
	for player = 1, players do
		--if (player == 1) and self.debug then print("Building buff table") end
		unitid = prefix .. player
		pname = UnitName(prefix .. player)
		class = select(2, UnitClass(prefix .. player))
		if class == "HUNTER" then pet = getHunterPet(pname, players, prefix) end
		for n, buff in pairs(self.PlayerBuffs) do
			if (not self.Buffs[n]) or hbuff[n] then
				for _, pclass in ipairs(buff) do
					if not IsExcluded(pname, n) then
						if pclass[1] == class then
							if class == "HUNTER" then
								if checkHunterPet(n, pet) then
									self.Buffs[n] = true
									hbuff[n] = true
									setBuff(n, class, pname, pet)
									--if self.debug then print(pname .. ": " .. pclass[4]) end
								end
								break
							else --if pclass[2] == nil then	--no tree **ignore trees for the time being
								self.Buffs[n] = true
								hbuff[n] = false
								setBuff(n, class, pname)
								--if self.debug then print(pname .. ": " .. pclass[4]) end
								break
							--[[
							elseif pclass[3] == nil then	--tree, but no talent
								if GetSpec(unitid) == pclass[2] then
									self.Buffs[n] = true
									hbuff[n] = false
									setBuff(n, class, pname)
									--if self.debug then print(pname .. ": " .. pclass[4]) end
									break
								end
							else	--tree and talent
								s = GetSpellInfo(pclass[3])
								if self.GT:GUIDHasTalent(guid, s) then
									self.Buffs[n] = true
									hbuff[n] = false
									setBuff(n, class, pname)
									--if self.debug then print(pname .. ": " .. pclass[4]) end
									break
								end
							]]--
							end
						end
					end
				end
			end
		end
	end
end

--retrieve basic pet info
local function getInfo(pet)
	local text, family
	local petfamily
	for _, family in ipairs(PetSelector.PetInfo) do if family[1] == pet.family then petfamily = family; break end end
	return petfamily
end

local function EnumerateTooltipLines_helper(...)
    for i = 1, select("#", ...) do
        local region = select(i, ...)
        if region and region:GetObjectType() == "FontString" then
            local text = region:GetText()
			DEFAULT_CHAT_FRAME:AddMessage(i .. ": " .. (text or "nil"), 0, 1, 0)
        end
    end
end

local function EnumerateTooltipLines(tooltip) EnumerateTooltipLines_helper(tooltip:GetRegions()) end

--main frame
function PetSelector:CreatePetFrame()
	self.button = CreateFrame("Button", nil, UIParent)
	self.button.icon = self.button:CreateTexture(nil, "BACKGROUND")
	self.button.icon:SetAllPoints()
	self.tooltip = self.tooltip or CreateFrame("GameTooltip", "PetSelector_Tooltip", nil, "GameTooltipTemplate")

	local function buttonOnEnter(this)
		local pet = PetSelector.selectedpet
		if not pet then return end
		local info = getInfo(pet)
		local regions, spellname, casttime, cd, desc
		local stabled, rand = ""
		--get the spell info
		self.tooltip:SetOwner(UIParent, "ANCHOR_NONE")
		self.tooltip:ClearLines()
		self.tooltip:SetSpellByID(info[2])
		regions = {self.tooltip:GetRegions()}
        spellname = regions[10]:GetText()

		if(regions[15]:GetText()) then
			casttime = regions[14]:GetText()
			cd = regions[15]:GetText()
			desc = regions[16]: GetText()
		else
			casttime = regions[12]:GetText()
			cd = regions[13]:GetText()
			desc = regions[14]:GetText()
		end
		--if self.debug then EnumerateTooltipLines(self.tooltip) end
		self.tooltip:Hide()
		--is the pet in the stable?
		if pet.slot > 5 then stabled = "   |cffcc3333" .. L["stabled"] .. "|r" end
		--setup the tooltip
		GameTooltip:SetOwner(this, "ANCHOR_TOP")
		GameTooltip:ClearLines()
		GameTooltip:SetText("Pet Selector")
		GameTooltip:AppendText("\r\r|cff00ff00" .. pet.name .. "|r" .. stabled)
		--is this a random selection pet?
		if self.random then GameTooltip:AddDoubleLine(pet.family, L["Random selection"], 1, 1, 1, 0.25, 0.3, 0.8)
		else GameTooltip:AddLine(pet.family, 1, 1, 1) end
		GameTooltip:AddLine(" ")
		GameTooltip:AddDoubleLine(spellname, casttime, nil, nil, nil, 1, 1, 1)
		GameTooltip:AddLine(cd, 0.1, 0.6, 1)
		GameTooltip:AddLine(desc, 1, 1, 1, true)
		GameTooltip:Show()
	end

	local function buttonOnLeave(this) GameTooltip:Hide() end

	local function frameDragStop()
		self.button:StopMovingOrSizing()
		self.db.profile.x = self.button:GetLeft()
		self.db.profile.y = self.button:GetBottom()
	end

	self.button:Hide()
	self.button:SetMovable(true)
	self.button:EnableMouse(true)
	self.button:EnableKeyboard(true)
	self.button:SetClampedToScreen(true)
	self.button:SetFrameStrata("MEDIUM")
	self.button:SetHeight(32)
	self.button:SetWidth(32)
	self.button:RegisterForDrag("LeftButton")
	self.button:SetScript("OnDragStart", function() if not self.db.profile.locked then self.button:StartMoving() end end)
	self.button:SetScript("OnDragStop", frameDragStop)
	self.button:SetScale(self.db.profile.scale)
	self.button:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", self.db.profile.x, self.db.profile.y)

	local function onClick(this, button, updown)
		if button == "LeftButton" then
			GameTooltip:Hide()
			self:SetPet()
			buttonOnEnter(this)
		else InterfaceOptionsFrame_OpenToCategory(self.optionschecks) end
	end

	self.button:SetHighlightTexture("Interface\\BUTTONS\\ButtonHilight-Square", "ADD")
	self.button:SetPushedTexture("Interface\\BUTTONS\\UI-Quickslot-Depress")
	self.button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	self.button:SetScript("OnEnter", buttonOnEnter)
	self.button:SetScript("OnLeave", buttonOnLeave)	
	self.button:SetScript("OnClick", onClick)

	if LBF or LBM then
		if LBF then
			LBF:RegisterSkinCallback("Pet Selector", self.LBFCallback, self)
			self.lbfgroup = LBF:Group("Pet Selector")
		else
			LBM:RegisterSkinCallback("Pet Selector", self.LBFCallback, self)
			self.lbfgroup = LBM:Group("Pet Selector")
		end
		self.lbfgroup:AddButton(self.button, {Pushed = self.button:GetPushedTexture(), Normal = self.button:GetNormalTexture(), Icon = self.button.icon})		
		self.lbfgroup:Skin(self.db.profile.bfskin, self.db.profile.bfgloss, self.db.profile.bfbackdrop, self.db.profile.bfcolours)
	end
end

function PetSelector:LBFCallback(skin, gloss, backdrop, group, button, colours)
	self.db.profile.bfskin = skin
	self.db.profile.bfgloss = gloss
	self.db.profile.bfbackdrop = backdrop
	self.db.profile.bfcolours = colours
end

local function createLine(lnum, parent, name)
	local frame = CreateFrame("Button", name .. lnum, parent)
	local icon = frame:CreateTexture(name .. "Icon" .. lnum)
	local provider = frame:CreateFontString(name .. "Provider" .. lnum, "ARTWORK", "GameFontNormal")

	frame:SetWidth(parent:GetWidth())
	frame:SetHeight(16)
	frame:SetID(lnum)
	frame:RegisterForClicks("AnyUp")

	local function onEnter(this)
		if not this.spellid then return end
		GameTooltip:SetOwner(this, "ANCHOR_LEFT")
		GameTooltip:ClearLines()
		GameTooltip:SetSpellByID(this.spellid)
	end

	local function onLeave(this) GameTooltip:Hide() end

	local function onClick(this, button)
		local id, provider, dd
		if name == "PetSelectorPet" then return end
		if button == "RightButton" then
			--do drop down menu
			PetSelectorMenu:SetParent(this)
			ToggleDropDownMenu(1, nil, PetSelectorMenu, "cursor", 3, -3)
		end
	end

	frame:SetScript("OnEnter", onEnter)
	frame:SetScript("OnLeave", onLeave)
	frame:SetScript("OnClick", onClick)

	icon:SetWidth(16)
	icon:SetHeight(16)
	icon:SetPoint("LEFT", frame, "LEFT")

	provider:SetWidth(frame:GetWidth() - 8 - 16 - 5)
	provider:SetHeight(16)
	provider:SetPoint("LEFT", icon, "RIGHT", 0, 0)

	return frame
end

function PetSelector:DisplayFrames(buffs)
	local db = self.db.profile
	local displaymain = ((db.showinparty and self.inparty) or (not db.showinparty))
	local displaybuffs = db.showbuffs and displaymain
	local displaymissing = db.showmissing
	local hidebutton = db.hidebutton
	if not buffs then
		if displaymain and (not hidebutton) then self.button:Show()
		else self.button:Hide() end
	end
	if (displaybuffs and (self.inparty or self.debug)) then PetSelectorBuffFrame:Show()
	else PetSelectorBuffFrame:Hide() end
	if displaymissing then
		self:PopulateMissing()
		PetSelectorPetFrame:Show()
	else PetSelectorPetFrame:Hide() end
end

function PetSelector:CreateDropDown()
	local menu = CreateFrame("Frame", "PetSelectorMenu")

	menu.displayMode = "MENU"
	menu.info = {}
	menu.HideMenu = function() if UIDROPDOWNMENU_OPEN_MENU == menu then CloseDropDownMenus() end end
	menu.initialize = 
		function(this, level)
			if not level then return end
			local info = this.info
			local id = this:GetParent():GetID()
			local ex
			wipe(info)
			if level == 1 then
				info.isTitle = 1
				info.text = "Pet Selector"
				info.notCheckable = 1
				UIDropDownMenu_AddButton(info, level)

				info.keepShownOnClick = 1
				info.disabled = nil
				info.isTitle = nil

				info.text = L["Ignore player"]
				info.hasArrow = nil
				info.func = function() table.insert(PetSelector.exclude, {id = id, player = this:GetParent().player}); this.HideMenu(); PetSelector:CheckBuffs() end
				info.disabled = (this:GetParent().player == nil)
				UIDropDownMenu_AddButton(info, level)

				info.text = L["Unignore player"]
				info.value = "unignore"
				info.disabled = true
				info.hasArrow = nil

				for _, ex in ipairs(self.exclude) do
					if ex.id == id then
						info.disabled = nil
						info.hasArrow = 1
						break
					end
				end

				UIDropDownMenu_AddButton(info, level)

				-- Close menu item
				info.hasArrow = nil
				info.value = nil
				info.text = _G.CLOSE
				info.func = this.HideMenu
				info.disabled = nil
				UIDropDownMenu_AddButton(info, level)
			elseif level == 2 then
				if (UIDROPDOWNMENU_MENU_VALUE == "unignore") then
					for _, ex in ipairs(self.exclude) do
						info.text = ex.player
						info.notCheckable = 1
						info.func = 
							function(this)
								local i, e
								for i, e in ipairs(PetSelector.exclude) do
									if e.player == this:GetText() then
										PetSelector.exclude[i] = nil
										CloseDropDownMenus()
										PetSelector:CheckBuffs()
										break
									end
								end
							end
						UIDropDownMenu_AddButton(info, level)
					end
				end
			end
		end
end

function PetSelector:CreateBuffFrame(pets)
	local frame = CreateFrame("Frame", pets and "PetSelectorPetFrame" or "PetSelectorBuffFrame", UIParent)
	local closeButton = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
	local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	local line, fname, tmp
	local ypos = -35
	
	local function frameDragStop()
		frame:StopMovingOrSizing()
		if pets then
			self.db.profile.px = frame:GetLeft()
			self.db.profile.py = frame:GetBottom()
		else
			self.db.profile.bx = frame:GetLeft()
			self.db.profile.by = frame:GetBottom()
		end
	end

	frame:Hide()
	frame:SetMovable(true)
	frame:EnableMouse(true)
	frame:EnableKeyboard(true)
	frame:SetClampedToScreen(true)
	frame:SetFrameStrata("MEDIUM")
	frame:SetHeight(320)
	frame:SetWidth(150)
	frame:RegisterForDrag("LeftButton")
	frame:SetScript("OnDragStart", function() if not self.db.profile.locked then frame:StartMoving() end end)
	frame:SetScript("OnDragStop", frameDragStop)
	frame:SetScale(self.db.profile.scale)
	frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", pets and self.db.profile.px or self.db.profile.bx, pets and self.db.profile.py or self.db.profile.by)
	frame:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = {left = 4, right = 4, top = 4, bottom = 4}})
	frame:SetBackdropColor(0, 0, 0, 1)

	local function closeClick()
		frame:Hide()
		if pets then self.db.profile.showmissing = false
		else self.db.profile.showbuffs = false end

		if (self.optionschecks:IsVisible()) then
			InterfaceOptionsFrame:Hide()
			InterfaceOptionsFrame_OpenToCategory(self.optionschecks)
		end
	end

	closeButton:SetPoint("TOPLEFT", frame, "TOPRIGHT", -32, -2)
	closeButton:SetScript("OnClick", closeClick)
	title:SetPoint("CENTER", frame, "CENTER", -16, 145)
	title:SetText(pets and L["Missing Pets"] or L["Buff Providers"])

	for line = 1, 14 do
		tmp = createLine(line, frame, pets and "PetSelectorPet" or "PetSelectorBuff")
		tmp:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, ypos)
		ypos = ypos - 20
	end

	if not pets then self:CreateDropDown() end
end