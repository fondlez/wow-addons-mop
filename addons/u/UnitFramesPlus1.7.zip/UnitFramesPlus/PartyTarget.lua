﻿--变量
local id = 1;
local _G = _G;

--队友目标
for id = 1, 4, 1 do
	local ToPFrame = CreateFrame("Button", "PartyTarget"..id, _G["PartyMemberFrame"..id], "SecureUnitButtonTemplate");
	ToPFrame:SetFrameLevel(8);
	ToPFrame:SetWidth(80);
	ToPFrame:SetHeight(16);
	ToPFrame:ClearAllPoints();
	ToPFrame:SetAttribute("unit", "party"..id.."target");
	ToPFrame:SetAttribute("*type1", "target");
	ToPFrame:SetHitRectInsets(0, 0, -8, -6);

	ToPFrame.Name = ToPFrame:CreateFontString("ToPName", "ARTWORK", "GameTooltipTextSmall");
	ToPFrame.Name:ClearAllPoints();
	ToPFrame.Name:SetPoint("TOPLEFT", ToPFrame, "TOPLEFT", 3, 4);
	ToPFrame.Name:SetTextColor(1, 0.82, 0);
	ToPFrame.Name:SetFont(GameFontNormal:GetFont(), 10, "OUTLINE");

	ToPFrame.Border = ToPFrame:CreateTexture("ToPBorder", "BORDER");
	ToPFrame.Border:SetTexture("Interface\\Tooltips\\UI-StatusBar-Border");
	ToPFrame.Border:SetWidth(80);
	ToPFrame.Border:SetHeight(16);
	ToPFrame.Border:ClearAllPoints();
	ToPFrame.Border:SetPoint("TOPLEFT", ToPFrame, "TOPLEFT", 1, -6);

	ToPFrame.HealthBar = CreateFrame("StatusBar", "ToPHealthBar", _G["PartyTarget"..id]);
	ToPFrame.HealthBar:SetStatusBarTexture("Interface\\AddOns\\UnitFramesPlus\\PartyTarget");
	ToPFrame.HealthBar:SetFrameLevel(2);
	ToPFrame.HealthBar:SetMinMaxValues(0, 100);
	ToPFrame.HealthBar:SetValue(0);
	ToPFrame.HealthBar:SetWidth(74);
	ToPFrame.HealthBar:SetHeight(10);
	ToPFrame.HealthBar:ClearAllPoints();
	ToPFrame.HealthBar:SetPoint("TOP", ToPFrame, "TOP", 1, -9);
	ToPFrame.HealthBar:SetStatusBarColor(0, 1, 0);

	ToPFrame.HealthBar.Text = ToPFrame.HealthBar:CreateFontString("ToPHealthBarText", "ARTWORK", "GameTooltipTextSmall");
	ToPFrame.HealthBar.Text:ClearAllPoints();
	ToPFrame.HealthBar.Text:SetPoint("CENTER", ToPFrame.HealthBar, "CENTER", 3, -1);
	ToPFrame.HealthBar.Text:SetTextColor(1, 1, 1);
	ToPFrame.HealthBar.Text:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");

	_G["PartyTarget"..id]:Show();
	_G["PartyTarget"..id]:SetAlpha(0);
end

hooksecurefunc("PartyMemberFrame_OnUpdate", function(self, elapsed)
	local id = self:GetID();
	self.timer = (self.timer or 0) + elapsed;
	if self.timer >= 0.2 then
		local unit = "party"..id.."target";
		if UnitExists(unit) and UnitFramesPlusDB["party"]["target"] == 1 then
			ToPNameColor = RAID_CLASS_COLORS[select(2, UnitClass(unit))] or NORMAL_FONT_COLOR;
			_G["PartyTarget"..id].Name:SetText(UnitName(unit));
			_G["PartyTarget"..id].Name:SetTextColor(ToPNameColor.r, ToPNameColor.g, ToPNameColor.b);

			pctText = math.floor((UnitHealth(unit) or 0)/max((UnitHealthMax(unit) or 1),1)*100);
			if UnitIsDead(unit) then
				_G["PartyTarget"..id].HealthBar:SetValue(0);
				_G["PartyTarget"..id].HealthBar.Text:SetText("|cffeed200"..UFPLocal_DeathText.."|r");
			else
				_G["PartyTarget"..id].HealthBar:SetValue(pctText);
				_G["PartyTarget"..id].HealthBar.Text:SetText(pctText.."%");
			end

			if UnitIsEnemy("player", unit) then
				_G["PartyTarget"..id].Border:SetVertexColor(1, 0.2, 0.2);
				_G["PartyTarget"..id].HealthBar:SetStatusBarColor(1, 0.55, 0.72);
			elseif UnitIsFriend("player", unit) then
				_G["PartyTarget"..id].Border:SetVertexColor(0, 1, 0);
				_G["PartyTarget"..id].HealthBar:SetStatusBarColor(0, 1, 0);
			else
				_G["PartyTarget"..id].Border:SetVertexColor(0.9, 0.82, 0);
				_G["PartyTarget"..id].HealthBar:SetStatusBarColor(0.65, 0.9, 0.85);
			end
			
			_G["PartyTarget"..id]:SetAlpha(1);
		else
			_G["PartyTarget"..id]:SetAlpha(0);
		end
		self.timer = 0;
	end
end)

--模块初始化
function UnitFramesPlus_PartyTargetInit()
	local xOffset;
	if UnitFramesPlusDB["party"]["hp"] == 1 and UnitFramesPlusDB["party"]["hppct"] ~= 1 then
		xOffset = 211;
	else
		xOffset = 151;
	end
	for id = 1, 4, 1 do
		_G["PartyTarget"..id]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "TOPLEFT", xOffset, -8);
	end
end
