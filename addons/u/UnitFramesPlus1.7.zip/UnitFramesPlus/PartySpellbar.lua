﻿--变量
local id = 1;
local _G = _G;

--队友施法条
for id = 1, 4, 1 do
	local PartySpellbar = CreateFrame("StatusBar", "PartySpellbar"..id, _G["PartyMemberFrame"..id], "CastingBarFrameTemplate");
	PartySpellbar:SetWidth(92);
	PartySpellbar:SetHeight(10);
	PartySpellbar:ClearAllPoints();
	PartySpellbar:SetID(id);
	PartySpellbar:SetFrameStrata("MEDIUM");
	RaiseFrameLevel(PartySpellbar);

	PartySpellbar.unit = "party"..id;
	CastingBarFrame_OnLoad(PartySpellbar, PartySpellbar.unit, false);

	PartySpellbar.Icon = _G[PartySpellbar:GetName().."Icon"];
	PartySpellbar.Icon:SetWidth(17);
	PartySpellbar.Icon:SetHeight(17);
	PartySpellbar.Icon:Show();

	PartySpellbar.Text = _G[PartySpellbar:GetName().."Text"];
	PartySpellbar.Text:SetTextHeight(13);
	PartySpellbar.Text:ClearAllPoints();
	PartySpellbar.Text:SetPoint("TOP", PartySpellbar, "TOP", 0, 4);

	PartySpellbar.Border = _G[PartySpellbar:GetName().."Border"];
	PartySpellbar.Border:SetTexture("Interface\\CastingBar\\UI-CastingBar-Border-Small");
	PartySpellbar.Border:SetWidth(126);
	PartySpellbar.Border:SetHeight(48);
	PartySpellbar.Border:ClearAllPoints();
	PartySpellbar.Border:SetPoint("TOP", PartySpellbar, "TOP", 0, 20);

	PartySpellbar.Flash = _G[PartySpellbar:GetName().."Flash"];
	PartySpellbar.Flash:SetTexture("Interface\\CastingBar\\UI-CastingBar-Flash-Small");
	PartySpellbar.Flash:SetWidth(126);
	PartySpellbar.Flash:SetHeight(48);
	PartySpellbar.Flash:ClearAllPoints();
	PartySpellbar.Flash:SetPoint("TOP", PartySpellbar, "TOP", 0, 20);

	_G["PartySpellbar"..id]:Hide();
end

function UnitFramesPlus_PartySpellbar()
	for id = 1, 4, 1 do
		if UnitFramesPlusDB["party"]["spellbar"] == 1 then
			_G["PartySpellbar"..id]:SetScript("OnShow", function(self, button)
				self:ClearAllPoints();
				if(_G["PartyMemberFrame"..self:GetID().."PetFrame"]:IsShown()) then
					self:SetPoint("BOTTOM", self:GetParent(), "BOTTOM", 5, -25);
				else
					self:SetPoint("BOTTOM", self:GetParent(), "BOTTOM", 5, -10);
				end
			end)

			_G["PartySpellbar"..id]:RegisterEvent("GROUP_ROSTER_UPDATE");
			_G["PartySpellbar"..id]:RegisterEvent("PARTY_MEMBER_ENABLE");
			_G["PartySpellbar"..id]:RegisterEvent("PARTY_MEMBER_DISABLE");
			_G["PartySpellbar"..id]:RegisterEvent("PARTY_LEADER_CHANGED");
			_G["PartySpellbar"..id]:RegisterEvent("VARIABLES_LOADED");
			_G["PartySpellbar"..id]:RegisterEvent("CVAR_UPDATE");
			_G["PartySpellbar"..id]:SetScript("OnEvent", function(self, event, ...)
				local newevent = event;
				local arg1, arg2, arg3 = ...;
				local newarg1 = arg1;
				if event == "CVAR_UPDATE" or event == "VARIABLES_LOADED" then
					if self.casting or self.channeling then
						self:Show();
					else
						self:Hide();
					end
					return;
				elseif event == "GROUP_ROSTER_UPDATE" or event == "PARTY_MEMBER_ENABLE" or event == "PARTY_MEMBER_DISABLE" or event == "PARTY_LEADER_CHANGED" then
					-- check if the new target is casting a spell
					local nameChannel = UnitChannelInfo(self.unit);
					local nameSpell = UnitCastingInfo(self.unit);
					if nameChannel then
						newevent = "UNIT_SPELLCAST_CHANNEL_START";
						newarg1 = "party"..self:GetID();
					elseif nameSpell then
						newevent = "UNIT_SPELLCAST_START";
						newarg1 = "party"..self:GetID();
					else
						self.casting = nil;
						self.channeling = nil;
						self:SetMinMaxValues(0, 0);
						self:SetValue(0);
						self:Hide();
						return;
					end
				end

				CastingBarFrame_OnEvent(self, newevent, newarg1, select(2, ...))
			end)
		else
			if _G["PartySpellbar"..id]:IsEventRegistered("GROUP_ROSTER_UPDATE") then
				_G["PartySpellbar"..id]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartySpellbar"..id]:UnregisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartySpellbar"..id]:UnregisterEvent("PARTY_MEMBER_DISABLE");
				_G["PartySpellbar"..id]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartySpellbar"..id]:UnregisterEvent("VARIABLES_LOADED");
				_G["PartySpellbar"..id]:UnregisterEvent("CVAR_UPDATE");
				_G["PartySpellbar"..id]:SetScript("OnEvent", nil);
				_G["PartySpellbar"..id]:SetScript("OnShow", nil);
				_G["PartySpellbar"..id]:Hide();
			end
		end
	end
end

function UnitFramesPlus_PartySpellbarInit()
	UnitFramesPlus_PartySpellbar();
end