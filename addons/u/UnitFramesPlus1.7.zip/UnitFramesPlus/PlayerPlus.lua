﻿--非战斗状态中允许shift+左键拖动玩家头像
local function UnitFramesPlus_PlayerShiftDrag()
	PlayerFrame:SetScript("OnMouseDown", function(self, elapsed)
		if UnitFramesPlusDB["player"]["movable"] == 1 then
			if IsShiftKeyDown() and (not InCombatLockdown()) then
				PlayerFrame:StartMoving();
				UnitFramesPlusVar["player"]["moving"] = 1;
			end
		end
	end)

	PlayerFrame:SetScript("OnMouseUp", function(self, elapsed)
		if UnitFramesPlusVar["player"]["moving"] == 1 then
			PlayerFrame:StopMovingOrSizing();
			UnitFramesPlusVar["player"]["moving"] = 0;
		end
	end)

	PlayerFrame:SetClampedToScreen(1);
end

--精英头像
function UnitFramesPlus_PlayerDragon()
	if UnitFramesPlusDB["player"]["dragon"] == 1 then
		if UnitFramesPlusDB["player"]["raretype"] == 1 then
			PlayerTexture = "Interface\\TargetingFrame\\UI-TargetingFrame-Elite";
		elseif UnitFramesPlusDB["player"]["raretype"] == 2 then
			PlayerTexture = ("Interface\\TargetingFrame\\UI-TargetingFrame-Rare-Elite");
		elseif UnitFramesPlusDB["player"]["raretype"] == 3 then
			PlayerTexture = ("Interface\\TargetingFrame\\UI-TargetingFrame-Rare");
		end
	else
		PlayerTexture = ("Interface\\TargetingFrame\\UI-TargetingFrame");
	end
	PlayerFrameTexture:SetTexture(PlayerTexture);

	--设置扩展框素材与头像素材一致
	if UnitFramesPlusDB["player"]["extbar"] == 1 then
		PlayerExtBar:SetTexture(PlayerTexture);
	end
end

--头像缩放
function UnitFramesPlus_PlayerFrameScale(oldscale, newscale)
	local oldscale = oldscale or UnitFramesPlusDB["player"]["scale"];
	local newscale = newscale or UnitFramesPlusDB["player"]["scale"];
	if not InCombatLockdown() then
		local point, relativeTo, relativePoint, offsetX, offsetY = PlayerFrame:GetPoint();
		PlayerFrame:SetScale(newscale);
		PlayerFrame:ClearAllPoints();
		PlayerFrame:SetPoint(point, relativeTo, relativePoint, offsetX*oldscale/newscale, offsetY*oldscale/newscale);
		if UnitFramesPlusVar["target"]["moved"] ~= 1 then
			TargetFrame:ClearAllPoints();
			TargetFrame:SetPoint("TOPLEFT", PlayerFrame, "TOPRIGHT", 45+96*newscale, 0);
		end
	end
end

--额外的生命值/法力值/生命值百分比
local PlayerHPMPPct = CreateFrame("Frame", "PlayerHPMPPct", PlayerFrame);
PlayerHPMPPct:SetFrameLevel(7);
PlayerHPMPPct.HP = PlayerHPMPPct:CreateFontString("PlayerHPMPPctHP", "OVERLAY", "TextStatusBarText");
PlayerHPMPPct.HP:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
PlayerHPMPPct.HP:SetTextColor(1, 0.75, 0);
PlayerHPMPPct.HP:Hide();

PlayerHPMPPct.MP = PlayerHPMPPct:CreateFontString("PlayerHPMPPctMP", "OVERLAY", "TextStatusBarText");
PlayerHPMPPct.MP:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
PlayerHPMPPct.MP:SetTextColor(1, 1, 1);
PlayerHPMPPct.MP:Hide();

PlayerHPMPPct.Pct = PlayerHPMPPct:CreateFontString("PlayerHPMPPctPct", "OVERLAY", "TextStatusBarText");
PlayerHPMPPct.Pct:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
PlayerHPMPPct.Pct:SetTextColor(0, 1, 0);
PlayerHPMPPct.Pct:Hide();

PlayerHPMPPct.PctOnHB = PlayerHPMPPct:CreateFontString("PlayerHPMPPctPctOnHB", "OVERLAY", "TextStatusBarText");
PlayerHPMPPct.PctOnHB:ClearAllPoints();
PlayerHPMPPct.PctOnHB:SetPoint("CENTER", PlayerFrameHealthBar, "CENTER", 0, -1);
PlayerHPMPPct.PctOnHB:SetJustifyH("CENTER");
PlayerHPMPPct.PctOnHB:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
PlayerHPMPPct.PctOnHB:SetTextColor(1, 1, 1);
PlayerHPMPPct.PctOnHB:Show();

--扩展框
local PlayerExtBar = PlayerFrame:CreateTexture("PlayerExtBar", "ARTWORK");
PlayerExtBar:Hide();

local PlayerExtBarBG = PlayerFrame:CreateTexture("PlayerExtBarBG", "BACKGROUND");
PlayerExtBarBG:Hide();

local fixforvehicle = CreateFrame("Frame");
function UnitFramesPlus_PlayerExtbar()
	PlayerExtBar:SetTexture(PlayerTexture);
	PlayerExtBar:SetWidth(138);
	PlayerExtBar:SetHeight(128);
	PlayerExtBar:SetTexCoord(0.3984375, 0, 0, 1);
	PlayerExtBar:ClearAllPoints();
	PlayerExtBar:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 226, 0);

	PlayerExtBarBG:SetTexture("Interface\\Tooltips\\UI-Tooltip-Background");
	PlayerExtBarBG:SetWidth(96);
	PlayerExtBarBG:SetHeight(42);
	PlayerExtBarBG:SetVertexColor(0, 0, 0, 0.5);
	PlayerExtBarBG:ClearAllPoints();
	PlayerExtBarBG:SetPoint("TOPLEFT", PlayerFrame, "TOPLEFT", 226, -23);
	if UnitFramesPlusDB["player"]["extbar"] == 1 then
		PlayerExtBar:Show();
		PlayerExtBarBG:Show();
		PlayerHPMPPct.HP:ClearAllPoints();
		PlayerHPMPPct.HP:SetPoint("CENTER", PlayerFrameHealthBar, "RIGHT", 53, -1);
		PlayerHPMPPct.HP:SetJustifyH("CENTER");
		PlayerHPMPPct.HP:Show();
		PlayerHPMPPct.MP:ClearAllPoints();
		PlayerHPMPPct.MP:SetPoint("CENTER", PlayerFrameManaBar, "RIGHT", 53, -1);
		PlayerHPMPPct.MP:SetJustifyH("CENTER");
		PlayerHPMPPct.MP:Show();
		PlayerHPMPPct.Pct:ClearAllPoints();
		PlayerHPMPPct.Pct:SetPoint("CENTER", PlayerFrameHealthBar, "RIGHT", 55, 14);
		PlayerHPMPPct.Pct:SetJustifyH("CENTER");
		PlayerHPMPPct.Pct:Show();

		--上载具后隐藏扩展框及扩展信息
		fixforvehicle:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player");
		fixforvehicle:RegisterUnitEvent("UNIT_EXITED_VEHICLE", "player");
		fixforvehicle:SetScript("OnEvent", function(self, event, ...)
			if event == "UNIT_ENTERED_VEHICLE" then
				if UnitHasVehicleUI("player") then
					PlayerExtBar:SetAlpha(0);
					PlayerExtBarBG:SetAlpha(0);
					PlayerHPMPPct.HP:SetAlpha(0);
					PlayerHPMPPct.MP:SetAlpha(0);
					PlayerHPMPPct.Pct:SetAlpha(0);
				end
			elseif event == "UNIT_EXITED_VEHICLE" then
				PlayerExtBar:SetAlpha(1);
				PlayerExtBarBG:SetAlpha(0.5);
				PlayerHPMPPct.HP:SetAlpha(1);
				PlayerHPMPPct.MP:SetAlpha(1);
				PlayerHPMPPct.Pct:SetAlpha(1);
			end;
		end)

		UnitFramesPlus_PlayerHealth();
		UnitFramesPlus_PlayerHPValueDisplayUpdate();
		UnitFramesPlus_PlayerPower();
		UnitFramesPlus_PlayerMPValueDisplayUpdate();
	else
		PlayerExtBar:Hide();
		PlayerExtBarBG:Hide();
		if fixforvehicle:IsEventRegistered("UNIT_ENTERED_VEHICLE") then
			fixforvehicle:UnregisterEvent("UNIT_ENTERED_VEHICLE");
			fixforvehicle:UnregisterEvent("UNIT_EXITED_VEHICLE");
			fixforvehicle:SetScript("OnEvent", nil);
		end
		UnitFramesPlus_PlayerHPMPPct();
	end
end

--隐藏扩展框后调整额外的生命值/法力值/生命值百分比的位置
function UnitFramesPlus_PlayerHPMPPct()
	if UnitFramesPlusDB["player"]["hpmp"] == 1 then
		PlayerHPMPPct.HP:ClearAllPoints();
		PlayerHPMPPct.HP:SetPoint("LEFT", PlayerFrameHealthBar, "RIGHT", 5, -1);
		PlayerHPMPPct.HP:SetJustifyH("LEFT");
		PlayerHPMPPct.HP:Show();
		PlayerHPMPPct.MP:ClearAllPoints();
		PlayerHPMPPct.MP:SetPoint("LEFT", PlayerFrameManaBar, "RIGHT", 5, -1);
		PlayerHPMPPct.MP:SetJustifyH("LEFT");
		PlayerHPMPPct.MP:Show();
		PlayerHPMPPct.Pct:ClearAllPoints();
		PlayerHPMPPct.Pct:SetPoint("LEFT", PlayerFrameHealthBar, "RIGHT", 5, 14);
		PlayerHPMPPct.Pct:SetJustifyH("LEFT");
		PlayerHPMPPct.Pct:Show();
	else
		PlayerHPMPPct.HP:Hide();
		PlayerHPMPPct.MP:Hide();
		PlayerHPMPPct.Pct:Hide();
	end
	UnitFramesPlus_PlayerHealth();
	UnitFramesPlus_PlayerHPValueDisplayUpdate();
	UnitFramesPlus_PlayerPower();
	UnitFramesPlus_PlayerMPValueDisplayUpdate();
end

--额外的生命值
local PlayerHealth = CreateFrame("Frame");
function UnitFramesPlus_PlayerHealth()
	if UnitFramesPlusDB["player"]["extbar"] == 0 and UnitFramesPlusDB["player"]["hpmp"] == 0 and UnitFramesPlusDB["player"]["pctonbar"] == 0 then
		if PlayerHealth:IsEventRegistered("PLAYER_ENTERING_WORLD") then
			PlayerHealth:UnregisterEvent("PLAYER_ENTERING_WORLD");
			PlayerHealth:UnregisterEvent("UNIT_HEALTH_FREQUENT");
			PlayerHealth:SetScript("OnEvent", nil);
		end
	else
		PlayerHealth:RegisterEvent("PLAYER_ENTERING_WORLD");
		PlayerHealth:RegisterUnitEvent("UNIT_HEALTH_FREQUENT", "player");
		PlayerHealth:SetScript("OnEvent", function(self, event, ...)
			UnitFramesPlus_PlayerHPValueDisplayUpdate();
		end)
	end
end

--刷新额外的生命值显示
function UnitFramesPlus_PlayerHPValueDisplayUpdate()
	local CurHP = UnitHealth("player");
	local MaxHP = UnitHealthMax("player");
	local CurHPfix, MaxHPfix = GetValueFix(CurHP, MaxHP, UnitFramesPlusDB["player"]["unit"]);
	local PctText = "";
	local PlayerExtHPText = "";

	if MaxHP > 0 then
		PctText = math.floor(100*CurHP/MaxHP).."%";
	end

	if UnitFramesPlusDB["player"]["extbar"] == 1 or UnitFramesPlusDB["player"]["hpmp"] == 1 then
		if UnitFramesPlusDB["player"]["hpmppartone"] == 1 then
			PlayerExtHPText = CurHPfix;
		elseif UnitFramesPlusDB["player"]["hpmppartone"] == 2 then
			PlayerExtHPText = MaxHPfix;
		elseif UnitFramesPlusDB["player"]["hpmppartone"] == 3 then
			PlayerExtHPText = PctText;
		end

		if UnitFramesPlusDB["player"]["hpmpparttwo"] == 1 then
			PlayerExtHPText = PlayerExtHPText.."/"..CurHPfix;
		elseif UnitFramesPlusDB["player"]["hpmpparttwo"] == 2 then
			PlayerExtHPText = PlayerExtHPText.."/"..MaxHPfix;
		elseif UnitFramesPlusDB["player"]["hpmpparttwo"] == 3 then
			PlayerExtHPText = PlayerExtHPText.."/"..PctText;
		end

		PlayerHPMPPct.HP:SetText(PlayerExtHPText);

		if UnitFramesPlusDB["player"]["hpmppartone"] == 3 or UnitFramesPlusDB["player"]["hpmpparttwo"] == 3 then
			if UnitFramesPlusDB["player"]["coord"] ~= 1 then
				PlayerHPMPPct.Pct:SetText("");
			end
		else
			if UnitFramesPlusDB["player"]["coord"] ~= 1 then
				PlayerHPMPPct.Pct:SetText(PctText);
			end
		end
	end

	if UnitFramesPlusDB["player"]["pctonbar"] == 1 then
		PlayerHPMPPct.PctOnHB:SetText(PctText);
	else
		PlayerHPMPPct.PctOnHB:SetText("");
	end
end

--玩家坐标
local coord = CreateFrame("Frame");
local x, y;
function UnitFramesPlus_PlayerCoordinate()
	if UnitFramesPlusDB["player"]["coord"] == 1 then
		coord:RegisterEvent("ZONE_CHANGED");
		coord:RegisterEvent("ZONE_CHANGED_INDOORS");
		coord:RegisterEvent("ZONE_CHANGED_NEW_AREA");
		coord:SetScript("OnEvent", function(self, event)
			SetMapToCurrentZone();
			x, y = GetPlayerMapPosition("player");
			if x~=0 and y~=0 then
				PlayerHPMPPct.Pct:SetText(format("(%.0f, %.0f)", x*100, y*100));
			end
		end)

		coord:SetScript("OnUpdate", function(self, elapsed)
			self.timer = (self.timer or 0) + elapsed;
			if self.timer >= 0.3 then
				x, y = GetPlayerMapPosition("player");
				if x~=0 and y~=0 then
					PlayerHPMPPct.Pct:SetText(format("(%.0f, %.0f)", x*100, y*100));
				end
				self.timer = 0;
			end
		end)
	else
		if coord:IsEventRegistered("ZONE_CHANGED") then
			coord:UnregisterEvent("ZONE_CHANGED");
			coord:UnregisterEvent("ZONE_CHANGED_INDOORS");
			coord:UnregisterEvent("ZONE_CHANGED_NEW_AREA");
			coord:SetScript("OnEvent", nil);
			coord:SetScript("OnUpdate", nil);
		end
	end
end

--额外的法力值/能量等
local PlayerPower = CreateFrame("Frame");
function UnitFramesPlus_PlayerPower()
	if UnitFramesPlusDB["player"]["extbar"] == 0 and UnitFramesPlusDB["player"]["hpmp"] == 0 then
		if PlayerPower:IsEventRegistered("UNIT_POWER") then
			PlayerPower:UnregisterEvent("PLAYER_ENTERING_WORLD");
			PlayerPower:UnregisterEvent("UNIT_POWER");
			PlayerPower:SetScript("OnEvent", nil);
		end
	else
		PlayerPower:RegisterEvent("PLAYER_ENTERING_WORLD");
		PlayerPower:RegisterUnitEvent("UNIT_POWER", "player");
		PlayerPower:SetScript("OnEvent", function(self, event, ...)
			UnitFramesPlus_PlayerMPValueDisplayUpdate();
		end)
	end
end

--刷新额外的法力值/能量等显示
function UnitFramesPlus_PlayerMPValueDisplayUpdate()
	local CurMP = UnitPower("player");
	local MaxMP = UnitPowerMax("player");
	local CurMPfix, MaxMPfix = GetValueFix(CurMP, MaxMP, UnitFramesPlusDB["player"]["unit"]);
	local PctText = "";
	local powerType = UnitPowerType("player");

	if powerType == 0 then
		if MaxMP > 0 then
			PctText = math.floor(100*CurMP/MaxMP).."%";
		end
	else
		PctText = CurMP;
		if PctText == 0 then PctText = "" end
	end

	if UnitFramesPlusDB["player"]["extbar"] == 1 or UnitFramesPlusDB["player"]["hpmp"] == 1 then
		if UnitFramesPlusDB["player"]["hpmppartone"] == 1 then
			PlayerExtMPText = CurMPfix;
		elseif UnitFramesPlusDB["player"]["hpmppartone"] == 2 then
			PlayerExtMPText = MaxMPfix;
		elseif UnitFramesPlusDB["player"]["hpmppartone"] == 3 then
			PlayerExtMPText = PctText;
		end

		if UnitFramesPlusDB["player"]["hpmpparttwo"] == 1 then
			PlayerExtMPText = PlayerExtMPText.."/"..CurMPfix;
		elseif UnitFramesPlusDB["player"]["hpmpparttwo"] == 2 then
			PlayerExtMPText = PlayerExtMPText.."/"..MaxMPfix;
		elseif UnitFramesPlusDB["player"]["hpmpparttwo"] == 3 then
			PlayerExtMPText = PlayerExtMPText.."/"..PctText;
		end

		PlayerHPMPPct.MP:SetText(PlayerExtMPText);
	end
end

--格式化数值显示
function GetValueFix(valueCur, valueMax, valuetype)
	local valueCurfix, valueMaxfix, unitbig, unitsmall;
	if valuetype == 1 then
		unitbig = "m";
		unitsmall = "k";
		if valueCur > 10000000 then
			valueCurfix = math.floor(valueCur/1000000)..unitbig;
		elseif valueCur > 10000 then
			valueCurfix = math.floor(valueCur/1000)..unitsmall;
		else
			valueCurfix = valueCur;
		end

		if valueMax > 10000000 then
			valueMaxfix = math.floor(valueCur/1000000)..unitbig;
		elseif valueMax > 10000 then
			valueMaxfix = math.floor(valueMax/1000)..unitsmall;
		else
			valueMaxfix = valueMax;
		end
	else
		valueCurfix = valueCur;
		valueMaxfix = valueMax;
	end
	return valueCurfix, valueMaxfix;
end

--玩家生命条染色
local chb = CreateFrame("Frame");
function UnitFramesPlus_PlayerColorHPBar()
	if UnitFramesPlusDB["player"]["colorhp"] == 1 then
		if UnitFramesPlusDB["player"]["colortype"] == 1 then
			PlayerFrameHealthBar:SetScript("OnValueChanged", nil);
			chb:RegisterEvent("PLAYER_ENTERING_WORLD");
			chb:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player");
			chb:RegisterUnitEvent("UNIT_EXITED_VEHICLE", "player");
			chb:SetScript("OnEvent", function(self, event, ...)
				UnitFramesPlus_PlayerColorHPBarDisplayUpdate();
			end)
		elseif UnitFramesPlusDB["player"]["colortype"] == 2 then
			if chb:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				chb:UnregisterEvent("PLAYER_ENTERING_WORLD");
				chb:UnregisterEvent("UNIT_ENTERED_VEHICLE");
				chb:UnregisterEvent("UNIT_EXITED_VEHICLE");
				chb:SetScript("OnEvent", nil);
			end
			PlayerFrameHealthBar:SetScript("OnValueChanged", function(self, value)
				UnitFramesPlus_PlayerColorHPBarDisplayUpdate();
			end)
		end
		PlayerFrameHealthBar.lockColor = true;
	else
		PlayerFrameHealthBar:SetScript("OnValueChanged", nil);
		if chb:IsEventRegistered("PLAYER_ENTERING_WORLD") then
			chb:UnregisterEvent("PLAYER_ENTERING_WORLD");
			chb:UnregisterEvent("UNIT_ENTERED_VEHICLE");
			chb:UnregisterEvent("UNIT_EXITED_VEHICLE");
			chb:SetScript("OnEvent", nil);
		end
		PlayerFrameHealthBar:SetStatusBarColor(0, 1, 0);
		PlayerFrameHealthBar.lockColor = nil;
	end
end

--刷新玩家生命条染色显示
function UnitFramesPlus_PlayerColorHPBarDisplayUpdate()
	if UnitFramesPlusDB["player"]["colorhp"] == 1 then
		if UnitFramesPlusDB["player"]["colortype"] == 1 then
			local HealthBarColor = RAID_CLASS_COLORS[select(2, UnitClass("player"))] or {r=0, g=1, b=0};
			if UnitHasVehicleUI("player") then HealthBarColor = {r=0, g=1, b=0} end
			PlayerFrameHealthBar:SetStatusBarColor(HealthBarColor.r, HealthBarColor.g, HealthBarColor.b);
		elseif UnitFramesPlusDB["player"]["colortype"] == 2 then
			local CurHP = UnitHealth("player");
			local MaxHP = UnitHealthMax("player");
			local Pct = math.floor(100*CurHP/MaxHP)/100;
			local r, g, b = 0, 1, 0;
			if Pct > 0.5 then
				r = (1.0-Pct)*2;
				g = 1.0;
			else
				r = 1.0;
				g = Pct*2;
			end
			if r < 0 then r = 0 end
			if g < 0 then g = 0 end
			if r > 1 then r = 1 end
			if g > 1 then g = 1 end
			PlayerFrameHealthBar:SetStatusBarColor(r, g, b);
		end
	end
end

--玩家头像内战斗信息
function UnitFramesPlus_PlayerPortraitIndicator()
	local registered = PlayerFrame:IsEventRegistered("UNIT_COMBAT");
	local petregistered = PetFrame:IsEventRegistered("UNIT_COMBAT");
	if UnitFramesPlusDB["player"]["indicator"] == 1 then
		if not registered then
			PlayerFrame:RegisterUnitEvent("UNIT_COMBAT", "player", "vehicle");
		end
		if not petregistered then
			PetFrame:RegisterUnitEvent("UNIT_COMBAT", "player", "vehicle");
		end
	else
		if registered then
			PlayerFrame:UnregisterEvent("UNIT_COMBAT");
		end
		if petregistered then
			PetFrame:UnregisterEvent("UNIT_COMBAT");
		end
	end
end

--玩家3D头像
local Player3DPortrait = CreateFrame("PlayerModel", "Player3DPortrait", PlayerFrame);
Player3DPortrait:SetWidth(51);
Player3DPortrait:SetHeight(51);
Player3DPortrait:SetFrameLevel(1);
Player3DPortrait:ClearAllPoints();
Player3DPortrait:SetPoint("CENTER", PlayerPortrait, "CENTER", 0, -1);
Player3DPortrait:Hide();
Player3DPortrait.Background = Player3DPortrait:CreateTexture("Player3DPortraitBG", "BACKGROUND");
Player3DPortrait.Background:SetTexture("Interface\\AddOns\\UnitFramesPlus\\Portrait3D");
Player3DPortrait.Background:SetWidth(64);
Player3DPortrait.Background:SetHeight(64);
Player3DPortrait.Background:ClearAllPoints();
Player3DPortrait.Background:SetPoint("CENTER", Player3DPortrait, "CENTER", 0, 0);
Player3DPortrait.Background:Hide();

local p3d = CreateFrame("Frame");
function UnitFramesPlus_Player3DPortrait()
	if UnitFramesPlusDB["player"]["p3d"] == 1 then
		PlayerPortrait:Hide();
		Player3DPortrait:Show();
		UnitFramesPlus_Player3DPortraitBGDisplayUpdate();
		p3d:RegisterEvent("PLAYER_ENTERING_WORLD");
		p3d:RegisterEvent("PLAYER_DEAD");
		p3d:RegisterEvent("PLAYER_ALIVE");
		p3d:RegisterEvent("PLAYER_UNGHOST");
		p3d:RegisterUnitEvent("UNIT_MODEL_CHANGED", "player");
		p3d:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player");
		p3d:RegisterUnitEvent("UNIT_EXITED_VEHICLE", "player");
		p3d:SetScript("OnEvent", function(self, event, ...)
			if event == "PLAYER_ENTERING_WORLD" then
				if UnitFramesPlusDB["player"]["p3dbg"] == 1 then
					local color = RAID_CLASS_COLORS[select(2, UnitClass("player"))] or NORMAL_FONT_COLOR;
					Player3DPortrait.Background:SetVertexColor(color.r/1.5, color.g/1.5, color.b/1.5, 1);
				end
				UnitFramesPlus_Player3DPortraitDisplayUpdate();
			elseif event == "UNIT_MODEL_CHANGED" or event == "UNIT_EXITED_VEHICLE" then
				UnitFramesPlus_Player3DPortraitDisplayUpdate();
			elseif event == "PLAYER_DEAD" then
				Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 0.3, 0.3);
			elseif event == "PLAYER_ALIVE" then
				if UnitIsGhost("player") then
					Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 0.25, 0.25, 0.25);
				else
					Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 1, 1);
				end
			elseif event == "PLAYER_UNGHOST" then
				Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 1, 1);
			elseif event == "UNIT_ENTERED_VEHICLE" and UnitHasVehicleUI("player") then
				Player3DPortrait:SetPortraitZoom(1);
				Player3DPortrait:ClearModel();
				Player3DPortrait:SetUnit("vehicle");
			end
		end)
	else
		PlayerPortrait:Show();
		Player3DPortrait:Hide();
		if p3d:IsEventRegistered("PLAYER_ENTERING_WORLD") then
			p3d:UnregisterEvent("PLAYER_ENTERING_WORLD");
			p3d:UnregisterEvent("PLAYER_DEAD");
			p3d:UnregisterEvent("PLAYER_ALIVE");
			p3d:UnregisterEvent("PLAYER_UNGHOST");
			p3d:UnregisterEvent("UNIT_MODEL_CHANGED");
			p3d:UnregisterEvent("UNIT_ENTERED_VEHICLE");
			p3d:UnregisterEvent("UNIT_EXITED_VEHICLE");
			p3d:SetScript("OnEvent", nil);
		end
	end
end

--刷新玩家3D头像显示
function UnitFramesPlus_Player3DPortraitDisplayUpdate()
	Player3DPortrait:SetPortraitZoom(1);
	Player3DPortrait:ClearModel();
	Player3DPortrait:SetUnit("player");
	if UnitIsGhost("player") then
		Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 0.25, 0.25, 0.25);
	elseif UnitIsDead("player") then
		Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 0.3, 0.3);
	else
		Player3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 1, 1);
	end
end

--刷新玩家3D头像背景显示
function UnitFramesPlus_Player3DPortraitBGDisplayUpdate()
	if UnitFramesPlusDB["player"]["p3d"] == 1 and UnitFramesPlusDB["player"]["p3dbg"] == 1 then
		Player3DPortrait.Background:Show();
	else
		Player3DPortrait.Background:Hide();
	end
end

--玩家资源条移动
local function UnitFramesPlus_PlayerPlusBarShiftDrag()
	local PlayerPlusBar;
 	local class = select(2, UnitClass("player"));
 	if class == "WARLOCK" then
		PlayerPlusBar = {"ShardBarFrame", "BurningEmbersBarFrame", "DemonicFuryBarFrame"};--WarlockPowerFrame;
 	elseif class == "SHAMAN" then
 		PlayerPlusBar = {"TotemFrameTotem1"};--TotemFrame;
 	elseif class == "DRUID" then
 		PlayerPlusBar = {"PlayerFrameAlternateManaBar", "EclipseBarFrame"};--EclipseBarFrame;
 	elseif class == "PALADIN" then
 		PlayerPlusBar = {"PaladinPowerBar"};--PaladinPowerBar;
 	elseif class == "DEATHKNIGHT" then
 		PlayerPlusBar = {"RuneButtonIndividual1"};--RuneFrame;
	elseif class == "PRIEST" then
		PlayerPlusBar = {"PriestBarFrame"};--PriestBarFrame;
	elseif class == "MONK" then
		PlayerPlusBar = {"PlayerFrameAlternateManaBar", "MonkHarmonyBarLightEnergy1"};--MonkHarmonyBar;
	else
		return;
 	end

	local id = 1;
	local len = table.getn(PlayerPlusBar);
	for id = 1, len, 1 do
		local BarToMove;
		if class == "MONK" and id == 2 then
			BarToMove = "MonkHarmonyBar";
		elseif class == "WARLOCK" then
			BarToMove = "WarlockPowerFrame";
		else
			BarToMove = PlayerPlusBar[id];
		end

		local _G = _G;
		local points = UnitFramesPlusVar["player"]["barposition"][BarToMove];
		if points and UnitFramesPlusDB["player"]["barmovable"] == 1 then
			_G[BarToMove]:ClearAllPoints();
			_G[BarToMove]:SetPoint(points[1], points[2],points[3],points[4],points[5]);
		end
		_G[BarToMove]:SetMovable(1);

		_G[PlayerPlusBar[id]]:SetScript("OnMouseDown", function(self, elapsed)
			if UnitFramesPlusDB["player"]["barmovable"] == 1 then
				if IsShiftKeyDown() and (not InCombatLockdown()) then
					_G[BarToMove]:StartMoving();
					UnitFramesPlusVar["player"]["barmoving"] = 1;
				end
			end
		end)

		_G[PlayerPlusBar[id]]:SetScript("OnMouseUp", function(self, elapsed)
			if UnitFramesPlusVar["player"]["barmoving"] == 1 then
				_G[BarToMove]:StopMovingOrSizing();
				local point, relativeTo, relativePoint, offsetX, offsetY = _G[BarToMove]:GetPoint();
				UnitFramesPlusVar["player"]["barposition"][BarToMove] = {point, relativeTo, relativePoint, offsetX, offsetY};
				UnitFramesPlusVar["player"]["barmoving"] = 0;
			end
		end)

		_G[BarToMove]:SetClampedToScreen(1);
	end
end

hooksecurefunc("AlternatePowerBar_SetLook", function(self)
	local class = select(2, UnitClass("player"));
	if class == "MONK" then
		local points = UnitFramesPlusVar["player"]["barposition"]["PlayerFrameAlternateManaBar"];
		if points and UnitFramesPlusDB["player"]["barmovable"] == 1 then
			PlayerFrameAlternateManaBar:ClearAllPoints();
			PlayerFrameAlternateManaBar:SetPoint(points[1], points[2],points[3],points[4],points[5]);
		end
	end
end)

--玩家头像自动隐藏
local fah = CreateFrame("Frame");
function UnitFramesPlus_PlayerFrameAutohide()
	if UnitFramesPlusDB["player"]["autohide"] == 1 then
		fah:RegisterEvent("PLAYER_ENTERING_WORLD");
		fah:RegisterEvent("PLAYER_TARGET_CHANGED");
		fah:RegisterEvent("PLAYER_REGEN_ENABLED");
		fah:RegisterEvent("PLAYER_REGEN_DISABLED");
		fah:RegisterUnitEvent("UNIT_POWER", "player");
		fah:RegisterUnitEvent("UNIT_MAXPOWER", "player");
		fah:RegisterUnitEvent("UNIT_HEALTH", "player");
		fah:RegisterUnitEvent("UNIT_MAXHEALTH", "player");
		fah:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player");
		fah:RegisterUnitEvent("UNIT_EXITED_VEHICLE", "player");
		fah:SetScript("OnEvent", function(self, event, ...)
			if event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_TARGET_CHANGED"
				or event == "PLAYER_REGEN_ENABLED" or event == "UNIT_EXITED_VEHICLE"
				or event == "UNIT_POWER" or event == "UNIT_MAXPOWER"
				or event == "UNIT_HEALTH" or event == "UNIT_MAXHEALTH" then
				UnitFramesPlus_PlayerFrameAutohideDisplayUpdate();
			elseif event == "PLAYER_REGEN_DISABLED" or event == "UNIT_ENTERED_VEHICLE" then
				PlayerFrame:SetAlpha(1);
				local class = select(2, UnitClass("player"));
				if class == "DEATHKNIGHT" then
					RuneFrame:SetAlpha(1);
				end
			end
		end)
	else
		if fah:IsEventRegistered("PLAYER_ENTERING_WORLD") then
			fah:UnregisterEvent("PLAYER_ENTERING_WORLD");
			fah:UnregisterEvent("PLAYER_TARGET_CHANGED");
			fah:UnregisterEvent("PLAYER_REGEN_ENABLED");
			fah:UnregisterEvent("PLAYER_REGEN_DISABLED");
			fah:UnregisterEvent("UNIT_POWER");
			fah:UnregisterEvent("UNIT_MAXPOWER");
			fah:UnregisterEvent("UNIT_HEALTH");
			fah:UnregisterEvent("UNIT_MAXHEALTH");
			fah:UnregisterEvent("UNIT_ENTERED_VEHICLE");
			fah:UnregisterEvent("UNIT_EXITED_VEHICLE");
			fah:SetScript("OnEvent", nil);
			UnitFramesPlus_PlayerFrameAutohideDisplayUpdate();
		end
	end
end

function UnitFramesPlus_PlayerFrameAutohideDisplayUpdate()
	if not InCombatLockdown() then
		if UnitFramesPlusDB["player"]["autohide"] == 1 then
			local powertypr = UnitPowerType("player");
			if (( powertypr == 0 or powertypr == 2 or powertypr == 3 ) and UnitPower("player") ~= UnitPowerMax("player"))
				or (( powertypr == 1 or powertypr == 6 ) and UnitPower("player") ~= 0)
				or (UnitHealth("player") ~= UnitHealthMax("player"))
				or UnitExists("target") then
				PlayerFrame:SetAlpha(1);
				local class = select(2, UnitClass("player"));
				if class == "DEATHKNIGHT" then
					RuneFrame:SetAlpha(1);
				end
				return;
			end
			PlayerFrame:SetAlpha(0);
			local class = select(2, UnitClass("player"));
			if class == "DEATHKNIGHT" then
				RuneFrame:SetAlpha(0);
			end
		else
			PlayerFrame:SetAlpha(1);
			local class = select(2, UnitClass("player"));
			if class == "DEATHKNIGHT" then
				RuneFrame:SetAlpha(1);
			end
		end
	end
end

--模块初始化
function UnitFramesPlus_PlayerInit()
	UnitFramesPlus_PlayerShiftDrag();
	UnitFramesPlus_PlayerDragon();
	UnitFramesPlus_PlayerExtbar();
	UnitFramesPlus_PlayerColorHPBar();
	UnitFramesPlus_PlayerPortraitIndicator();
	UnitFramesPlus_Player3DPortrait();
	UnitFramesPlus_PlayerCoordinate();
	UnitFramesPlus_PlayerFrameScale();
	UnitFramesPlus_PlayerPlusBarShiftDrag();
	UnitFramesPlus_PlayerFrameAutohide();
end
