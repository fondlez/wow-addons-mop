﻿--变量
local _G = _G;
local id = 1;

--队友施法条
local FocusSpellbar = CreateFrame("StatusBar", "FocusSpellbar", FocusFrame, "CastingBarFrameTemplate");
FocusSpellbar:SetWidth(150);
FocusSpellbar:SetHeight(10);
FocusSpellbar:ClearAllPoints();
FocusSpellbar:SetFrameStrata("MEDIUM");
RaiseFrameLevel(FocusSpellbar);

FocusSpellbar.unit = "focus";
CastingBarFrame_OnLoad(FocusSpellbar, FocusSpellbar.unit, false);

FocusSpellbar.Icon = _G[FocusSpellbar:GetName().."Icon"];
FocusSpellbar.Icon:SetWidth(16);
FocusSpellbar.Icon:SetHeight(16);
FocusSpellbar.Icon:Show();

FocusSpellbar.Text = _G[FocusSpellbar:GetName().."Text"];
FocusSpellbar.Text:SetTextHeight(15);
FocusSpellbar.Text:ClearAllPoints();
FocusSpellbar.Text:SetPoint("TOP", FocusSpellbar, "TOP", 0, 4);

FocusSpellbar.Border = _G[FocusSpellbar:GetName().."Border"];
FocusSpellbar.Border:SetTexture("Interface\\CastingBar\\UI-CastingBar-Border-Small");
FocusSpellbar.Border:SetWidth(196);
FocusSpellbar.Border:SetHeight(48);
FocusSpellbar.Border:ClearAllPoints();
FocusSpellbar.Border:SetPoint("TOP", FocusSpellbar, "TOP", 0, 20);

FocusSpellbar.Flash = _G[FocusSpellbar:GetName().."Flash"];
FocusSpellbar.Flash:SetTexture("Interface\\CastingBar\\UI-CastingBar-Flash-Small");
FocusSpellbar.Flash:SetWidth(196);
FocusSpellbar.Flash:SetHeight(48);
FocusSpellbar.Flash:ClearAllPoints();
FocusSpellbar.Flash:SetPoint("TOP", FocusSpellbar, "TOP", 0, 20);

FocusSpellbar:Hide();

function Focus_Spellbar_AdjustPosition(self)
	local yPos = -7;
	local xPos = 20;
	local relativeTo = "FocusFrame";

	if UnitDebuff("focus", 1) ~= nil then
		relativeTo = FocusFrame.debuffs;
		yPos = 12;
	elseif UnitBuff("focus", 1) ~= nil then
		relativeTo = FocusFrame.buffs;
		yPos = 12;
	elseif yPos < 30 and FocusFrameToT:IsShown() then
		yPos = 30;
	else
		xPos = 25;
	end

	self:ClearAllPoints();
	self:SetPoint("TOPLEFT", relativeTo, "BOTTOMLEFT", xPos, -yPos);
end

local fsb = CreateFrame("Frame");
function UnitFramesPlus_FocusSpellbar()
	if UnitFramesPlusDB["focus"]["spellbar"] == 1 then
		_G["FocusSpellbar"]:SetScript("OnShow", function(self, button)
			Focus_Spellbar_AdjustPosition(self);
		end)

		_G["FocusSpellbar"]:RegisterEvent("PLAYER_FOCUS_CHANGED");
		_G["FocusSpellbar"]:RegisterEvent("VARIABLES_LOADED");
		_G["FocusSpellbar"]:RegisterEvent("CVAR_UPDATE");
		_G["FocusSpellbar"]:SetScript("OnEvent", function(self, event, ...)
			local newevent = event;
			local arg1, arg2, arg3 = ...;
			local newarg1 = arg1;
			if event == "CVAR_UPDATE" or event == "VARIABLES_LOADED" then
				if self.casting or self.channeling then
					self:Show();
				else
					self:Hide();
				end
				return;
			elseif event == "PLAYER_FOCUS_CHANGED" then
				-- check if the new target is casting a spell
				local nameChannel = UnitChannelInfo(self.unit);
				local nameSpell = UnitCastingInfo(self.unit);
				if nameChannel then
					newevent = "UNIT_SPELLCAST_CHANNEL_START";
					newarg1 = "focus";
				elseif nameSpell then
					newevent = "UNIT_SPELLCAST_START";
					newarg1 = "focus";
				else
					self.casting = nil;
					self.channeling = nil;
					self:SetMinMaxValues(0, 0);
					self:SetValue(0);
					self:Hide();
					return;
				end
				Focus_Spellbar_AdjustPosition(self);
			end

			CastingBarFrame_OnEvent(self, newevent, newarg1, select(2, ...))
		end)
		
		fsb:SetScript("OnUpdate", function(self, elapsed)
			self.timer = (self.timer or 0) + elapsed;
			if self.timer >= 0.1 then
				Focus_Spellbar_AdjustPosition(FocusSpellbar);
				self.timer = 0;
			end
		end);
	else
		if _G["FocusSpellbar"]:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			_G["FocusSpellbar"]:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			_G["FocusSpellbar"]:UnregisterEvent("VARIABLES_LOADED");
			_G["FocusSpellbar"]:UnregisterEvent("CVAR_UPDATE");
			_G["FocusSpellbar"]:SetScript("OnEvent", nil);
			_G["FocusSpellbar"]:SetScript("OnShow", nil);
			_G["FocusSpellbar"]:Hide();
			fsb:SetScript("OnUpdate", nil);
		end
	end
end

function UnitFramesPlus_FocusSpellbarInit()
	UnitFramesPlus_FocusSpellbar();
end