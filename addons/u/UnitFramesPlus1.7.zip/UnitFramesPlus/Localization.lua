﻿
if GetLocale() == "zhCN" then
	UFPLocal_DeathText = "死亡";
	UFPLocal_GhostText = "鬼魂";
elseif GetLocale() == "zhTW" then
	UFPLocal_DeathText = "死亡";
	UFPLocal_GhostText = "鬼魂";
else
	UFPLocal_DeathText = "Death";
	UFPLocal_GhostText = "Ghost";
end