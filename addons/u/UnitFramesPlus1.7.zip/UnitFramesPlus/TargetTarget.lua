﻿--ToT
local ToTFrame = CreateFrame("Button", "ToTFrame", TargetFrame, "SecureUnitButtonTemplate");
ToTFrame:SetFrameLevel(8);
ToTFrame:SetWidth(96);
ToTFrame:SetHeight(48);
ToTFrame:ClearAllPoints();
ToTFrame:SetPoint("LEFT", TargetFrame, "RIGHT", -20, 0);
ToTFrame:SetAlpha(0);
ToTFrame:SetMovable(1);

ToTFrame.Portrait = ToTFrame:CreateTexture("ToTPortrait", "BORDER");
ToTFrame.Portrait:SetWidth(27);
ToTFrame.Portrait:SetHeight(27);
ToTFrame.Portrait:ClearAllPoints();
ToTFrame.Portrait:SetPoint("TOPLEFT", ToTFrame, "TOPLEFT", 6, -5);

ToTFrame.Texture = ToTFrame:CreateTexture("ToTTexture", "ARTWORK");
ToTFrame.Texture:SetTexture("Interface\\TargetingFrame\\UI-PartyFrame");
ToTFrame.Texture:SetWidth(96);
ToTFrame.Texture:SetHeight(48);
ToTFrame.Texture:ClearAllPoints();
ToTFrame.Texture:SetPoint("TOPLEFT", ToTFrame, "TOPLEFT", 0, -2);

ToTFrame.Name = ToTFrame:CreateFontString("ToTName", "ARTWORK", "GameFontNormalSmall");
ToTFrame.Name:ClearAllPoints();
ToTFrame.Name:SetPoint("BOTTOMLEFT", ToTFrame, "BOTTOMLEFT", 33, 39);

ToTFrame.HealthBar = CreateFrame("StatusBar", "ToTHealthBar", TargetFrame);
ToTFrame.HealthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");
ToTFrame.HealthBar:SetFrameLevel(2);
ToTFrame.HealthBar:SetMinMaxValues(0, 100);
ToTFrame.HealthBar:SetValue(0);
ToTFrame.HealthBar:SetWidth(53);
ToTFrame.HealthBar:SetHeight(6);
ToTFrame.HealthBar:ClearAllPoints();
ToTFrame.HealthBar:SetPoint("TOPLEFT", ToTFrame, "TOPLEFT", 35, -9);
ToTFrame.HealthBar:SetStatusBarColor(0, 1, 0);

ToTFrame.HPPct = ToTFrame:CreateFontString("ToTHPPct", "ARTWORK", "TextStatusBarText");
ToTFrame.HPPct:SetFont(GameFontNormal:GetFont(), 10, "OUTLINE");
ToTFrame.HPPct:SetTextColor(1, 0.75, 0);
ToTFrame.HPPct:SetJustifyH("LEFT");
ToTFrame.HPPct:ClearAllPoints();
ToTFrame.HPPct:SetPoint("LEFT", ToTFrame.HealthBar, "RIGHT", 2, -4);

ToTFrame.PowerBar = CreateFrame("StatusBar", "ToTPowerBar", TargetFrame);
ToTFrame.PowerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");
ToTFrame.PowerBar:SetFrameLevel(2);
ToTFrame.PowerBar:SetMinMaxValues(0, 100);
ToTFrame.PowerBar:SetValue(0);
ToTFrame.PowerBar:SetWidth(53);
ToTFrame.PowerBar:SetHeight(6);
ToTFrame.PowerBar:ClearAllPoints();
ToTFrame.PowerBar:SetPoint("TOPLEFT", ToTFrame, "TOPLEFT", 35, -16);
ToTFrame.PowerBar:SetStatusBarColor(0, 0, 1);

--允许点击选取目标
ToTFrame.DropDown = CreateFrame("Button", "ToTDropDown", TargetFrame, "UIDropDownMenuTemplate");
ToTFrame.DropDown:SetWidth(10);
ToTFrame.DropDown:SetHeight(10);
ToTFrame.DropDown:ClearAllPoints();
ToTFrame.DropDown:SetPoint("TOP", ToTFrame, "TOP", -20, -10);
ToTFrame.DropDown:Hide();

local showmenu = (function()
	ToggleDropDownMenu(1, nil, ToTFrame.DropDown, "ToTFrame", 40, 0);
end)
SecureUnitButton_OnLoad(ToTFrame, "targettarget", showmenu);

ToTFrame:RegisterForClicks("AnyUp");
ToTFrame:RegisterForDrag("LeftButton");

local tot = CreateFrame("Frame");
local ToTNameColor = PowerBarColor["MANA"];
local ToTPctText = "";
function UnitFramesPlus_TargetTarget()
	if UnitFramesPlusDB["target"]["tot"] == 1 then
		tot:SetScript("OnUpdate", function(self, elapsed)
			self.timer = (self.timer or 0) + elapsed;
			if self.timer >= 0.1 then
				if UnitExists("targettarget") then
					ToTFrame:SetAlpha(1);

					ToTFrame.Name:SetText(UnitName("targettarget"));

					ToTNameColor = PowerBarColor[UnitPowerType("targettarget")] or PowerBarColor["MANA"];
					ToTFrame.PowerBar:SetStatusBarColor(ToTNameColor.r, ToTNameColor.g, ToTNameColor.b);

					SetPortraitTexture(ToTFrame.Portrait, "targettarget");

					if UnitHealthMax("targettarget") > 0 then
						ToTFrame.HealthBar:SetValue(UnitHealth("targettarget") / UnitHealthMax("targettarget") * 100);
						ToTPctText = "";
						if UnitFramesPlusDB["target"]["tothppct"] == 1 then
							ToTPctText = math.floor(UnitHealth("targettarget") / UnitHealthMax("targettarget") * 100).."%";
						end
						ToTFrame.HPPct:SetText(ToTPctText);
					else
						ToTFrame.HealthBar:SetValue(0);
						ToTFrame.HPPct:SetText("");
					end

					if UnitPowerMax("targettarget") > 0 then
						ToTFrame.PowerBar:SetValue(UnitPower("targettarget") / UnitPowerMax("targettarget") * 100);
					else
						ToTFrame.PowerBar:SetValue(0);
					end
				else
					ToTFrame:SetAlpha(0);
					ToTFrame.HealthBar:SetValue(0);
					ToTFrame.PowerBar:SetValue(0);
					ToTFrame.HPPct:SetText("");
				end
				self.timer = 0;
			end
		end);
	else
		ToTFrame:SetAlpha(0);
		ToTFrame.HealthBar:SetValue(0);
		ToTFrame.PowerBar:SetValue(0);
		ToTFrame.HPPct:SetText("");
		tot:SetScript("OnUpdate", nil);
	end
end

--非战斗状态中允许shift+左键拖动ToT头像
local function UnitFramesPlus_TargetTargetShiftDrag()
	ToTFrame:SetScript("OnMouseDown", function(self, elapsed)
		if UnitFramesPlusDB["target"]["movable"] == 1 then
			if IsShiftKeyDown() and (not InCombatLockdown()) then
				ToTFrame:StartMoving();
				UnitFramesPlusVar["target"]["tmoving"] = 1;
			end
		end
	end)

	ToTFrame:SetScript("OnMouseUp", function(self, elapsed)
		if UnitFramesPlusVar["target"]["tmoving"] == 1 then
			ToTFrame:StopMovingOrSizing();
			UnitFramesPlusVar["target"]["tmoving"] = 0;
			UnitFramesPlusVar["target"]["tmoved"] = 1;
			local bottom = ToTFrame:GetBottom();
			local left = ToTFrame:GetLeft();
			local scale = ToTFrame:GetScale()*TargetFrame:GetScale();
			local bottomX = TargetFrame:GetBottom();
			local leftX = TargetFrame:GetLeft();
			local scaleX = TargetFrame:GetScale();
			ToTFrame:ClearAllPoints();
			ToTFrame:SetPoint("BOTTOMLEFT", TargetFrame, "BOTTOMLEFT", (left*scale-leftX*scaleX)/scale, (bottom*scale-bottomX*scaleX)/scale);
		end
	end)

	ToTFrame:SetClampedToScreen(1);

	--重置目标位置时同时重置ToT位置
	hooksecurefunc("TargetFrame_ResetUserPlacedPosition", function()
		if ToTFrame then
			ToTFrame:ClearAllPoints();
			ToTFrame:SetPoint("LEFT", TargetFrame, "RIGHT", -20, 0);
			UnitFramesPlusVar["target"]["tmoved"] = 0;
		end
	end)
end

--ToT debuff
local id = 1;
local UFP_MAX_TOT_DEBUFFS = 4;
for id = 1, UFP_MAX_TOT_DEBUFFS, 1 do
	local debuff;
	debuff = CreateFrame("Button", "ToTFrameDebuff"..id, ToTFrame, "PartyDebuffFrameTemplate");
	debuff:SetID(id);
	debuff:SetScript("OnEnter",function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT", 20, -20);
		GameTooltip:SetUnitDebuff("targettarget", id);
	end)
	debuff:SetScript("OnLeave",function()
		GameTooltip:Hide();
	end)
	debuff:ClearAllPoints();
	if id == 1 then
		debuff:SetPoint("BOTTOMLEFT", ToTFrame.Name, "TOPLEFT", -1, 5);
	else
		debuff:SetPoint("LEFT", "ToTFrameDebuff"..id-1, "RIGHT", 2, 0);
	end
	debuff:Hide();
end

local totdb = CreateFrame("Frame");
function UnitFramesPlus_TargetTargetDebuff()
	local _G = _G;
	if UnitFramesPlusDB["target"]["debuff"] == 1 then
		for id = 1, UFP_MAX_TOT_DEBUFFS, 1 do
			_G["ToTFrameDebuff"..id]:Show();
		end
		totdb:SetScript("OnUpdate", function(self, elapsed)
			self.timer = (self.timer or 0) + elapsed;
			if self.timer >= 0.1 then
				RefreshDebuffs(ToTFrame, "targettarget", UFP_MAX_TOT_DEBUFFS);
				self.timer = 0;
			end
		end)
	else
		for id = 1, UFP_MAX_TOT_DEBUFFS, 1 do
			_G["ToTFrameDebuff"..id]:Hide();
		end
		totdb:SetScript("OnUpdate", nil);
	end
end

--ToToT
local ToToTFrame = CreateFrame("Button", "ToToTFrame", TargetFrame, "SecureUnitButtonTemplate");
ToToTFrame:SetFrameLevel(8);
ToToTFrame:SetWidth(96);
ToToTFrame:SetHeight(48);
ToToTFrame:ClearAllPoints();
ToToTFrame:SetPoint("TOP", ToTFrame, "BOTTOM", 26, 16);
ToToTFrame:SetAlpha(0);

ToToTFrame.Portrait = ToToTFrame:CreateTexture("ToTPortrait", "BORDER");
ToToTFrame.Portrait:SetWidth(27);
ToToTFrame.Portrait:SetHeight(27);
ToToTFrame.Portrait:ClearAllPoints();
ToToTFrame.Portrait:SetPoint("TOPLEFT", ToToTFrame, "TOPLEFT", 6, -5);

ToToTFrame.Texture = ToToTFrame:CreateTexture("ToTTexture", "ARTWORK");
ToToTFrame.Texture:SetTexture("Interface\\TargetingFrame\\UI-PartyFrame");
ToToTFrame.Texture:SetWidth(96);
ToToTFrame.Texture:SetHeight(48);
ToToTFrame.Texture:ClearAllPoints();
ToToTFrame.Texture:SetPoint("TOPLEFT", ToToTFrame, "TOPLEFT", 0, -2);

ToToTFrame.Name = ToToTFrame:CreateFontString("ToTName", "ARTWORK", "GameFontNormalSmall");
ToToTFrame.Name:ClearAllPoints();
ToToTFrame.Name:SetPoint("BOTTOMLEFT", ToToTFrame, "BOTTOMLEFT", 33, 39);

ToToTFrame.HealthBar = CreateFrame("StatusBar", "ToTHealthBar", TargetFrame);
ToToTFrame.HealthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");
ToToTFrame.HealthBar:SetFrameLevel(2);
ToToTFrame.HealthBar:SetMinMaxValues(0, 100);
ToToTFrame.HealthBar:SetValue(0);
ToToTFrame.HealthBar:SetWidth(53);
ToToTFrame.HealthBar:SetHeight(6);
ToToTFrame.HealthBar:ClearAllPoints();
ToToTFrame.HealthBar:SetPoint("TOPLEFT", ToToTFrame, "TOPLEFT", 35, -9);
ToToTFrame.HealthBar:SetStatusBarColor(0, 1, 0);

ToToTFrame.PowerBar = CreateFrame("StatusBar", "ToTPowerBar", TargetFrame);
ToToTFrame.PowerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");
ToToTFrame.PowerBar:SetFrameLevel(2);
ToToTFrame.PowerBar:SetMinMaxValues(0, 100);
ToToTFrame.PowerBar:SetValue(0);
ToToTFrame.PowerBar:SetWidth(53);
ToToTFrame.PowerBar:SetHeight(6);
ToToTFrame.PowerBar:ClearAllPoints();
ToToTFrame.PowerBar:SetPoint("TOPLEFT", ToToTFrame, "TOPLEFT", 35, -16);
ToToTFrame.PowerBar:SetStatusBarColor(0, 0, 1);

local totot = CreateFrame("Frame");
local ToToTNameColor = PowerBarColor["MANA"];
function UnitFramesPlus_TargetTargetTarget()
	if UnitFramesPlusDB["target"]["tot"] == 1 and UnitFramesPlusDB["target"]["totot"] == 1 then
		totot:SetScript("OnUpdate", function(self, elapsed)
			self.timer = (self.timer or 0) + elapsed;
			if self.timer >= 0.1 then
				ToToTFrame.HealthBar:SetValue(0);
				ToToTFrame.PowerBar:SetValue(0);
				if UnitExists("targettargettarget") then
					ToToTFrame:SetAlpha(1);

					ToToTFrame.Name:SetText(UnitName("targettargettarget"));

					ToToTNameColor = PowerBarColor[UnitPowerType("targettargettarget")] or PowerBarColor["MANA"];
					ToToTFrame.PowerBar:SetStatusBarColor(ToToTNameColor.r, ToToTNameColor.g, ToToTNameColor.b);

					SetPortraitTexture(ToToTFrame.Portrait, "targettargettarget");

					if UnitHealthMax("targettargettarget") == 0 then
						ToToTFrame.HealthBar:SetValue(0);
					else
						ToToTFrame.HealthBar:SetValue(UnitHealth("targettargettarget") / UnitHealthMax("targettargettarget") * 100);
					end

					if UnitPowerMax("targettargettarget") == 0 then
						ToToTFrame.PowerBar:SetValue(0);
					else
						ToToTFrame.PowerBar:SetValue(UnitPower("targettargettarget") / UnitPowerMax("targettargettarget") * 100);
					end
				else
					ToToTFrame:SetAlpha(0);
					ToToTFrame.HealthBar:SetValue(0);
					ToToTFrame.PowerBar:SetValue(0);
				end
				self.timer = 0;
			end
		end);
	else
		ToToTFrame:SetAlpha(0);
		ToToTFrame.HealthBar:SetValue(0);
		ToToTFrame.PowerBar:SetValue(0);
		totot:SetScript("OnUpdate", nil);
	end
end

--ToT头像缩放
function UnitFramesPlus_TargetTargetScale(oldscale, newscale)
	local oldscale = oldscale or UnitFramesPlusDB["target"]["tscale"];
	local newscale = newscale or UnitFramesPlusDB["target"]["tscale"];
	if UnitFramesPlusDB["target"]["tot"] == 1 and (not InCombatLockdown()) then
		local point, relativeTo, relativePoint, offsetX, offsetY = ToTFrame:GetPoint();
		ToTFrame:SetScale(newscale);
		ToTFrame.HealthBar:SetScale(newscale);
		ToTFrame.PowerBar:SetScale(newscale);
		ToTFrame:ClearAllPoints();
		ToTFrame:SetPoint(point, relativeTo, relativePoint, offsetX*oldscale/newscale, offsetY*oldscale/newscale);
		if UnitFramesPlusDB["target"]["totot"] == 1 then
			ToToTFrame:SetScale(newscale);
			ToToTFrame.HealthBar:SetScale(newscale);
			ToToTFrame.PowerBar:SetScale(newscale);
		end
	end
end

--ToT头像位置
local function UnitFramesPlus_TargetTargetPosition()
	if UnitFramesPlusVar["target"]["tmoved"] ~= 1 then
		ToTFrame:ClearAllPoints();
		ToTFrame:SetPoint("LEFT", TargetFrame, "RIGHT", -20, 0);
	else
		local bottom = ToTFrame:GetBottom();
		local left = ToTFrame:GetLeft();
		local scale = ToTFrame:GetScale()*TargetFrame:GetScale();
		local bottomX = TargetFrame:GetBottom();
		local leftX = TargetFrame:GetLeft();
		local scaleX = TargetFrame:GetScale();
		ToTFrame:ClearAllPoints();
		ToTFrame:SetPoint("BOTTOMLEFT", TargetFrame, "BOTTOMLEFT", (left*scale-leftX*scaleX)/scale, (bottom*scale-bottomX*scaleX)/scale);
	end
end

--模块初始化
function UnitFramesPlus_TargetTargetInit()
	UnitFramesPlus_TargetTarget();
	UnitFramesPlus_TargetTargetTarget();
	UnitFramesPlus_TargetTargetShiftDrag();
	UnitFramesPlus_TargetTargetScale();
	UnitFramesPlus_TargetTargetPosition();
	UnitFramesPlus_TargetTargetDebuff();
end
