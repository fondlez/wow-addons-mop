﻿--变量
local id = 1;
local _G = _G;

--非战斗状态中允许shift+左键拖动队友头像
local function UnitFramesPlus_PartyShiftDrag()
	PartyMemberFrame1:SetScript("OnMouseDown", function(self, elapsed)
		if UnitFramesPlusDB["party"]["movable"] == 1 then
			if IsShiftKeyDown() and (not InCombatLockdown()) then
				PartyMemberFrame1:StartMoving();
				UnitFramesPlusVar["party"]["moving"] = 1;
			end
		end
	end)

	PartyMemberFrame1:SetScript("OnMouseUp", function(self, elapsed)
		if UnitFramesPlusVar["party"]["moving"] == 1 then
			PartyMemberFrame1:StopMovingOrSizing();
			UnitFramesPlusVar["party"]["moving"] = 0;
		end
	end)

	PartyMemberFrame1:SetClampedToScreen(1);
end

--队友等级
for id = 1, 4, 1 do
	local PartyLevel = CreateFrame("Frame", "PartyLevel"..id,  _G["PartyMemberFrame"..id]);
	PartyLevel.Text = _G["PartyLevel"..id]:CreateFontString("PartyMemberFrame"..id.."Level", "OVERLAY", "GameTooltipText");
	PartyLevel.Text:ClearAllPoints();
	PartyLevel.Text:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "BOTTOMLEFT", -9, 12);
	PartyLevel.Text:SetFont(GameFontNormal:GetFont(), 10, "OUTLINE");
	PartyLevel.Text:SetTextColor(1, 0.82, 0);
	PartyLevel.Text:SetJustifyH("LEFT");
end

function UnitFramesPlus_PartyLevel()
	for id = 1, 4, 1 do
		if UnitFramesPlusDB["party"]["level"] == 1 then
			_G["PartyLevel"..id]:RegisterEvent("PLAYER_ENTERING_WORLD");
			_G["PartyLevel"..id]:RegisterEvent("GROUP_ROSTER_UPDATE");
			_G["PartyLevel"..id]:RegisterEvent("PARTY_LEADER_CHANGED");
			_G["PartyLevel"..id]:RegisterEvent("PARTY_MEMBER_ENABLE");
			_G["PartyLevel"..id]:RegisterUnitEvent("UNIT_CONNECTION", "party"..id);
			_G["PartyLevel"..id]:RegisterUnitEvent("UNIT_PHASE", "party"..id);
			_G["PartyLevel"..id]:RegisterUnitEvent("UNIT_LEVEL", "party"..id);
			_G["PartyLevel"..id]:SetScript("OnEvent", function(self, event, ...)
				UnitFramesPlus_PartyLevelDisplayUpdate(id)
			end)
		else
			_G["PartyMemberFrame"..id.."Level"]:SetText("");
			if _G["PartyLevel"..id]:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				_G["PartyLevel"..id]:UnregisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyLevel"..id]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyLevel"..id]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyLevel"..id]:UnregisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartyLevel"..id]:UnregisterEvent("UNIT_CONNECTION");
				_G["PartyLevel"..id]:UnregisterEvent("UNIT_PHASE");
				_G["PartyLevel"..id]:UnregisterEvent("UNIT_LEVEL");
				_G["PartyLevel"..id]:SetScript("OnEvent", nil);
			end
		end
	end
end

--设置插件时刷新队友等级显示
function UnitFramesPlus_PartyLevelDisplayUpdate(id)
	local LevelText = "";
	if UnitExists("party"..id) then
		if UnitFramesPlusDB["party"]["level"] == 1 then
			if UnitLevel(_G["PartyMemberFrame"..id].unit) and UnitLevel(_G["PartyMemberFrame"..id].unit) >= 1 then
				LevelText = UnitLevel(_G["PartyMemberFrame"..id].unit);
			end
		end
	end
	_G["PartyLevel"..id].Text:SetText(LevelText);
end

--队友生命条染色
function UnitFramesPlus_PartyColorHPBar()
	for id = 1, 4, 1 do
		if UnitFramesPlusDB["party"]["colorhp"] == 1 then
			if UnitFramesPlusDB["party"]["colortype"] == 1 then
				_G["PartyMemberFrame"..id.."HealthBar"]:SetScript("OnValueChanged", nil);
				_G["PartyMemberFrame"..id.."HealthBar"]:RegisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyMemberFrame"..id.."HealthBar"]:RegisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyMemberFrame"..id.."HealthBar"]:RegisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyMemberFrame"..id.."HealthBar"]:RegisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartyMemberFrame"..id.."HealthBar"]:RegisterUnitEvent("UNIT_CONNECTION", "party"..id);
				_G["PartyMemberFrame"..id.."HealthBar"]:RegisterUnitEvent("UNIT_PHASE", "party"..id);
				_G["PartyMemberFrame"..id.."HealthBar"]:SetScript("OnEvent", function(self, event, ...)
					UnitFramesPlus_PartyColorHPBarDisplayUpdate(id);
				end)
			elseif UnitFramesPlusDB["party"]["colortype"] == 2 then
				if _G["PartyMemberFrame"..id.."HealthBar"]:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("UNIT_CONNECTION");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("UNIT_PHASE");
					_G["PartyMemberFrame"..id.."HealthBar"]:SetScript("OnEvent", nil);
				end
				_G["PartyMemberFrame"..id.."HealthBar"]:SetScript("OnValueChanged", function(self, value)
					UnitFramesPlus_PartyColorHPBarDisplayUpdate(id);
				end)
			end
			_G["PartyMemberFrame"..id.."HealthBar"].lockColor = true;
		else
			_G["PartyMemberFrame"..id.."HealthBar"]:SetScript("OnValueChanged", nil);
			if _G["PartyMemberFrame"..id.."HealthBar"]:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("UNIT_CONNECTION");
				_G["PartyMemberFrame"..id.."HealthBar"]:UnregisterEvent("UNIT_PHASE");
				_G["PartyMemberFrame"..id.."HealthBar"]:SetScript("OnEvent", nil);
			end
			_G["PartyMemberFrame"..id.."HealthBar"]:SetStatusBarColor(0, 1, 0);
			_G["PartyMemberFrame"..id.."HealthBar"].lockColor = nil;
		end
	end
end

--设置插件时刷新队友生命条染色显示
function UnitFramesPlus_PartyColorHPBarDisplayUpdate(id)
	if UnitExists("party"..id) then
		local color = {r=0, g=1, b=0};
		if UnitFramesPlusDB["party"]["colorhp"] == 1 then
			if UnitFramesPlusDB["party"]["colortype"] == 2 then
				local CurHP = UnitHealth("party"..id);
				local MaxHP = UnitHealthMax("party"..id);
				local Pct = math.floor(100*CurHP/MaxHP)/100;
				if Pct > 0.5 then
					color.r = (1.0-Pct)*2;
					color.g = 1.0;
				else
					color.r = 1.0;
					color.g = Pct*2;
				end
				if color.r < 0 then color.r = 0 end
				if color.g < 0 then color.g = 0 end
				if color.r > 1 then color.r = 1 end
				if color.g > 1 then color.g = 1 end
			elseif UnitFramesPlusDB["party"]["colortype"] == 1 then
				color = RAID_CLASS_COLORS[select(2, UnitClass("party"..id))];
			end
		end
		if not color then color = {r=0, g=1, b=0} end
		_G["PartyMemberFrame"..id.."HealthBar"]:SetStatusBarColor(color.r, color.g, color.b);
	end
end

--队友名字染色
for id = 1, 4, 1 do
	local PartyColorName = CreateFrame("Frame", "PartyColorName"..id,  _G["PartyMemberFrame"..id]);
end

function UnitFramesPlus_PartyColorName()
	for id = 1, 4, 1 do
		if UnitFramesPlusDB["party"]["colorname"] == 1 then
			_G["PartyColorName"..id]:RegisterEvent("PLAYER_ENTERING_WORLD");
			_G["PartyColorName"..id]:RegisterEvent("GROUP_ROSTER_UPDATE");
			_G["PartyColorName"..id]:RegisterEvent("PARTY_LEADER_CHANGED");
			_G["PartyColorName"..id]:RegisterEvent("PARTY_MEMBER_ENABLE");
			_G["PartyColorName"..id]:RegisterUnitEvent("UNIT_CONNECTION", "party"..id);
			_G["PartyColorName"..id]:RegisterUnitEvent("UNIT_PHASE", "party"..id);
			_G["PartyColorName"..id]:SetScript("OnEvent", function(self, event, ...)
				UnitFramesPlus_PartyColorNameDisplayUpdate(id)
			end)
		else
			_G["PartyMemberFrame"..id].name:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
			if _G["PartyColorName"..id]:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				_G["PartyColorName"..id]:UnregisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyColorName"..id]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyColorName"..id]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyColorName"..id]:UnregisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartyColorName"..id]:UnregisterEvent("UNIT_CONNECTION");
				_G["PartyColorName"..id]:UnregisterEvent("UNIT_PHASE");
			end
		end
	end
end

--设置插件时刷新队友名字染色显示
function UnitFramesPlus_PartyColorNameDisplayUpdate(id)
	if UnitExists("party"..id) then
		local color = NORMAL_FONT_COLOR;
		if UnitFramesPlusDB["party"]["colorname"] == 1 then
			color = RAID_CLASS_COLORS[select(2, UnitClass(_G["PartyMemberFrame"..id].unit))];
		end
		if not color then color = NORMAL_FONT_COLOR end
		_G["PartyMemberFrame"..id].name:SetTextColor(color.r, color.g, color.b);
	end
end

for id = 1, 4, 1 do
	--队友生命值百分比
	local PartyHPPct = CreateFrame("Frame", "PartyHPPct"..id,  _G["PartyMemberFrame"..id]);
	PartyHPPct.Text = PartyHPPct:CreateFontString("PartyMemberFrame"..id.."HPPct", "OVERLAY", "GameTooltipText");
	PartyHPPct.Text:ClearAllPoints();
	PartyHPPct.Text:SetPoint("LEFT", _G["PartyMemberFrame"..id.."HealthBar"], "RIGHT", 4, 0);
	PartyHPPct.Text:SetFont(GameFontNormal:GetFont(), 10, "OUTLINE");
	PartyHPPct.Text:SetTextColor(1, 0.82, 0);
	PartyHPPct.Text:SetJustifyH("LEFT");
	
	--队友死亡、灵魂提示
	local PartyDeath = CreateFrame("Frame", "PartyDeath"..id,  _G["PartyMemberFrame"..id]);
	PartyDeath:SetFrameLevel(7);
	PartyDeath.Text = PartyDeath:CreateFontString("PartyMemberFrame"..id.."DeathText", "OVERLAY", "GameTooltipText");
	PartyDeath.Text:ClearAllPoints();
	PartyDeath.Text:SetPoint("CENTER", _G["PartyMemberFrame"..id.."HealthBar"], "CENTER", 0, -5);
	PartyDeath.Text:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
	PartyDeath.Text:SetTextColor(1, 1, 1);
	PartyDeath.Text:SetJustifyH("CENTER");
end

function UnitFramesPlus_PartyHealthPct()
	for id = 1, 4, 1 do
		if UnitFramesPlusDB["party"]["hp"] == 1 then
			_G["PartyHPPct"..id]:RegisterEvent("PLAYER_ENTERING_WORLD");
			_G["PartyHPPct"..id]:RegisterEvent("GROUP_ROSTER_UPDATE");
			_G["PartyHPPct"..id]:RegisterEvent("PARTY_LEADER_CHANGED");
			_G["PartyHPPct"..id]:RegisterEvent("PARTY_MEMBER_ENABLE");
			_G["PartyHPPct"..id]:RegisterUnitEvent("UNIT_CONNECTION", "party"..id);
			_G["PartyHPPct"..id]:RegisterUnitEvent("UNIT_PHASE", "party"..id);
			_G["PartyHPPct"..id]:RegisterUnitEvent("UNIT_HEALTH_FREQUENT", "party"..id);
			_G["PartyHPPct"..id]:SetScript("OnEvent", function(self, event, ...)
				UnitFramesPlus_PartyHealthPctDisplayUpdate(id);
			end)
		else
			_G["PartyHPPct"..id].Text:SetText("");
			if _G["PartyHPPct"..id]:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				_G["PartyHPPct"..id]:UnregisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyHPPct"..id]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyHPPct"..id]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyHPPct"..id]:UnregisterEvent("PARTY_MEMBER_ENABLE");
				_G["PartyHPPct"..id]:UnregisterEvent("UNIT_CONNECTION");
				_G["PartyHPPct"..id]:UnregisterEvent("UNIT_PHASE");
				_G["PartyHPPct"..id]:UnregisterEvent("UNIT_HEALTH_FREQUENT");
				_G["PartyHPPct"..id]:SetScript("OnEvent", nil);
			end
		end
	end
end

--设置插件时刷新队友生命值百分比显示
function UnitFramesPlus_PartyHealthPctDisplayUpdate(id)
	local PctText = "";
	local DeathText = "";
	if UnitExists("party"..id) then
		local CurHP = UnitHealth("party"..id);

		if UnitFramesPlusDB["party"]["hp"] == 1 then
			local MaxHP = UnitHealthMax("party"..id);
			if MaxHP > 0 then
				if UnitFramesPlusDB["party"]["hppct"] == 1 then
					PctText = math.floor(100*CurHP/MaxHP).."%";
				else
					PctText = CurHP.."/"..MaxHP;
				end
			end
		end

		if UnitFramesPlusDB["party"]["death"] == 1 then
			if CurHP == 0 then
				DeathText = UFPLocal_DeathText;
			elseif UnitIsGhost("party"..id) then
				DeathText = UFPLocal_GhostText;
			end
		end
	end
	_G["PartyMemberFrame"..id.."HPPct"]:SetText(PctText);
	_G["PartyMemberFrame"..id.."DeathText"]:SetText(DeathText);
end

--队友头像内战斗信息
for id = 1, 4, 1 do
	local PartyPortraitIndicator = CreateFrame("Frame", "PartyPortraitIndicator"..id, _G["PartyMemberFrame"..id]);
	_G["PartyPortraitIndicator"..id]:SetFrameStrata("MEDIUM");
	_G["PartyPortraitIndicator"..id].feedbackStartTime = GetTime();
	_G["PartyPortraitIndicator"..id]:CreateFontString("PartyHitIndicator"..id, "OVERLAY", "NumberFontNormalHuge");
	_G["PartyHitIndicator"..id]:ClearAllPoints();
	_G["PartyHitIndicator"..id]:SetPoint("CENTER", _G["PartyMemberFrame"..id.."Portrait"], "CENTER", 0, 0);
	CombatFeedback_Initialize(_G["PartyPortraitIndicator"..id], _G["PartyHitIndicator"..id], 20);
end

function UnitFramesPlus_PartyPortraitIndicator()
	if UnitFramesPlusDB["party"]["indicator"] == 1 then
		for id = 1, 4, 1 do
			_G["PartyPortraitIndicator"..id]:RegisterEvent("PLAYER_ENTERING_WORLD");
			_G["PartyPortraitIndicator"..id]:RegisterEvent("GROUP_ROSTER_UPDATE");
			_G["PartyPortraitIndicator"..id]:RegisterEvent("PARTY_LEADER_CHANGED");
			_G["PartyPortraitIndicator"..id]:RegisterUnitEvent("UNIT_COMBAT", "party"..id);
			_G["PartyPortraitIndicator"..id]:RegisterUnitEvent("UNIT_CONNECTION", "party"..id);
			_G["PartyPortraitIndicator"..id]:SetScript("OnEvent", function(self, event, ...)
				local arg1, arg2, arg3, arg4, arg5 = ...;
				if event == "PLAYER_ENTERING_WORLD" or event == "GROUP_ROSTER_UPDATE" or event == "PARTY_LEADER_CHANGED" or (event == "UNIT_CONNECTION" and arg2 == false) then
					_G["PartyHitIndicator"..id]:Hide();
				elseif event == "UNIT_COMBAT" then
					CombatFeedback_OnCombatEvent(self, arg2, arg3, arg4, arg5);
				end
			end)

			_G["PartyPortraitIndicator"..id]:SetScript("OnUpdate", function(self, elapsed)
				CombatFeedback_OnUpdate(self, elapsed);
			end)
		end
	else
		for id = 1, 4, 1 do
			_G["PartyHitIndicator"..id]:Hide();
			if _G["PartyPortraitIndicator"..id]:IsEventRegistered("PLAYER_ENTERING_WORLD") then
				_G["PartyPortraitIndicator"..id]:UnregisterEvent("PLAYER_ENTERING_WORLD");
				_G["PartyPortraitIndicator"..id]:UnregisterEvent("GROUP_ROSTER_UPDATE");
				_G["PartyPortraitIndicator"..id]:UnregisterEvent("PARTY_LEADER_CHANGED");
				_G["PartyPortraitIndicator"..id]:UnregisterEvent("UNIT_COMBAT");
				_G["PartyPortraitIndicator"..id]:UnregisterEvent("UNIT_CONNECTION");
				_G["PartyPortraitIndicator"..id]:SetScript("OnUpdate", nil);
				_G["PartyPortraitIndicator"..id]:SetScript("OnEvent", nil);
			end
		end
	end
end

--队友离线检测
for id = 1, 4, 1 do
	local PartyOfflineStatus = _G["PartyMemberFrame"..id]:CreateTexture("PartyOfflineStatus"..id, "OVERLAY", _G["PartyMemberFrame"..id]);
	_G["PartyOfflineStatus"..id]:SetTexture("Interface\\CharacterFrame\\Disconnect-Icon");
	_G["PartyOfflineStatus"..id]:SetWidth(64);
	_G["PartyOfflineStatus"..id]:SetHeight(64);
	_G["PartyOfflineStatus"..id]:ClearAllPoints();
	_G["PartyOfflineStatus"..id]:SetPoint("LEFT", _G["PartyMemberFrame"..id], "LEFT", -7, -1);
	_G["PartyOfflineStatus"..id]:SetAlpha(0);
end

local pm = CreateFrame("Frame");
function UnitFramesPlus_PartyOfflineDetection()
	if UnitFramesPlusDB["party"]["onoff"] == 1 then
		pm:RegisterEvent("PLAYER_ENTERING_WORLD");
		pm:RegisterEvent("GROUP_ROSTER_UPDATE");
		pm:RegisterEvent("PARTY_LEADER_CHANGED");
		pm:RegisterEvent("PARTY_MEMBER_ENABLE");
		pm:RegisterEvent("PARTY_MEMBER_DISABLE");
		pm:RegisterEvent("UNIT_CONNECTION");
		pm:SetScript("OnEvent", function(self, event, ...)
			if event == "PLAYER_ENTERING_WORLD" or event == "GROUP_ROSTER_UPDATE" or event == "PARTY_LEADER_CHANGED" or event == "PARTY_MEMBER_ENABLE" or event == "PARTY_MEMBER_DISABLE" then
				UnitFramesPlus_PartyOfflineDetectionDisplayUpdate();
			elseif event == "UNIT_CONNECTION" then
				local unit, hasConnected = ...;
				for id = 1, 4, 1 do
					if UnitExists("party"..id) and unit == "party"..id then
						if hasConnected == false then
							_G["PartyMemberFrame"..id]:SetAlpha(0.5);
							_G["PartyOfflineStatus"..id]:SetAlpha(1);
						else
							_G["PartyMemberFrame"..id]:SetAlpha(1);
							_G["PartyOfflineStatus"..id]:SetAlpha(0);
						end
					end
				end
			end
		end)
	else
		for id = 1, 4, 1 do
			_G["PartyMemberFrame"..id]:SetAlpha(1);
			_G["PartyOfflineStatus"..id]:SetAlpha(0);
		end
		if pm:IsEventRegistered("PLAYER_ENTERING_WORLD") then
			pm:UnregisterEvent("PLAYER_ENTERING_WORLD");
			pm:UnregisterEvent("GROUP_ROSTER_UPDATE");
			pm:UnregisterEvent("PARTY_LEADER_CHANGED");
			pm:UnregisterEvent("UNIT_CONNECTION");
			pm:SetScript("OnEvent", nil);
		end
	end
end

--刷新队友离线检测显示
function UnitFramesPlus_PartyOfflineDetectionDisplayUpdate()
	for id = 1, 4, 1 do
		if UnitExists("party"..id) and UnitFramesPlusDB["party"]["onoff"] == 1 then
			if not UnitIsConnected("party"..id) then
				_G["PartyMemberFrame"..id]:SetAlpha(0.5);
				_G["PartyOfflineStatus"..id]:SetAlpha(1);
			else
				_G["PartyMemberFrame"..id]:SetAlpha(1);
				_G["PartyOfflineStatus"..id]:SetAlpha(0);
			end
		else
			_G["PartyMemberFrame"..id]:SetAlpha(1);
			_G["PartyOfflineStatus"..id]:SetAlpha(0);
		end
	end
end

--队友buff/debuff直接显示
local UFP_MAX_PARTY_BUFFS = 15;
for id = 1, 4, 1 do
	for j = 1, UFP_MAX_PARTY_BUFFS, 1 do
		local buff = CreateFrame("Button", "PartyMemberFrame"..id.."Buff"..j, _G["PartyMemberFrame"..id]);
		buff:SetWidth(15);
		buff:SetHeight(15);
		buff:SetID(j);
		buff:ClearAllPoints();
		if j == 1 then
			buff:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "TOPLEFT", 48, -32);
		else
			buff:SetPoint("LEFT", _G["PartyMemberFrame"..id.."Buff"..j-1], "RIGHT", 2, 0);
		end

		buff.Icon = buff:CreateTexture("PartyMemberFrame"..id.."Buff"..j.."Icon", "ARTWORK");
		buff.Icon:SetAllPoints(buff);

		buff:SetScript("OnUpdate", function(self, elapsed)
			if ( GameTooltip:IsOwned(self) ) then
				GameTooltip:SetUnitBuff("party"..id, j);
			end
		end)
		buff:SetScript("OnEnter",function(self)
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT");
			GameTooltip:SetUnitBuff("party"..id, j);
		end)
		buff:SetScript("OnLeave",function()
			GameTooltip:Hide();
		end)
		buff:Hide();
	end
end

--队友buff/debuff直接显示时隐藏buff鼠标提示
hooksecurefunc("PartyMemberBuffTooltip_Update", function(self)
	if UnitFramesPlusDB["party"]["buff"] == 1 then
		PartyMemberBuffTooltip:Hide();
	end
end)

hooksecurefunc("RefreshDebuffs", function(frame, unit, numDebuffs, suffix, checkCVar)
	if UnitFramesPlusDB["party"]["buff"] == 1 then
		local name = frame:GetName();
		if string.find(name, "^PartyMemberFrame%d$") then
			RefreshBuffs(frame, unit, UnitFramesPlusDB["party"]["buffnum"]);
		end
	end
end)

function UnitFramesPlus_PartyBuff()
	if UnitFramesPlusDB["party"]["buff"] == 1 then
		for id = 2, 4, 1 do
			local lowid = id - 1;
			_G["PartyMemberFrame"..id]:ClearAllPoints();
			_G["PartyMemberFrame"..id]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..lowid.."PetFrame"], "BOTTOMLEFT", -23, -18);
		end

		for id = 1, 4, 1 do
			for j = 1, UnitFramesPlusDB["party"]["buffnum"], 1 do
				_G["PartyMemberFrame"..id.."Buff"..j]:Show();
			end
			_G["PartyMemberFrame"..id.."Debuff1"]:ClearAllPoints();
			_G["PartyMemberFrame"..id.."Debuff1"]:SetPoint("BOTTOMLEFT", _G["PartyMemberFrame"..id], "TOPRIGHT", -8, 4);
			_G["PartyMemberFrame"..id.."PetFrame".."Debuff1"]:ClearAllPoints();
			_G["PartyMemberFrame"..id.."PetFrame".."Debuff1"]:SetPoint("LEFT", _G["PartyMemberFrame"..id.."PetFrame"], "RIGHT", -3, -1);
		end
	else
		for id = 2, 4, 1 do
			local lowid = id - 1;
			_G["PartyMemberFrame"..id]:ClearAllPoints();
			_G["PartyMemberFrame"..id]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..lowid.."PetFrame"], "BOTTOMLEFT", -23, -10);
		end

		for id = 1, 4, 1 do
			for j = 1, UnitFramesPlusDB["party"]["buffnum"], 1 do
				_G["PartyMemberFrame"..id.."Buff"..j]:Hide();
			end
			_G["PartyMemberFrame"..id.."Debuff1"]:ClearAllPoints();
			_G["PartyMemberFrame"..id.."Debuff1"]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "TOPLEFT", 48, -32);
			_G["PartyMemberFrame"..id.."PetFrame".."Debuff1"]:ClearAllPoints();
			_G["PartyMemberFrame"..id.."PetFrame".."Debuff1"]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id.."PetFrame"], "TOPLEFT", 24, -16);
		end
	end
end

function UnitFramesPlus_PartyBuffClear()
	if UnitFramesPlusDB["party"]["buffnum"] < UFP_MAX_PARTY_BUFFS then
		for id = 1, 4, 1 do
			if UnitExists("party"..id) then
				for j = UnitFramesPlusDB["party"]["buffnum"]+1, UFP_MAX_PARTY_BUFFS, 1 do
					_G["PartyMemberFrame"..id.."Buff"..j]:Hide();
				end
				RefreshBuffs(_G["PartyMemberFrame"..id], "party"..id, UnitFramesPlusDB["party"]["buffnum"]);
			end
		end
	end
end

--队友头像缩放
function UnitFramesPlus_PartyScale(scale)
	local scale = scale or UnitFramesPlusDB["party"]["scale"];
	if not InCombatLockdown() then
		for id = 1, 4, 1 do
			_G["PartyMemberFrame"..id]:SetScale(scale);
		end
	end
end

--模块初始化
function UnitFramesPlus_PartyInit()
	UnitFramesPlus_PartyShiftDrag();
	UnitFramesPlus_PartyOfflineDetection();
	UnitFramesPlus_PartyPortraitIndicator();
	UnitFramesPlus_PartyBuff();
	UnitFramesPlus_PartyScale();
	UnitFramesPlus_PartyColorHPBar();
	UnitFramesPlus_PartyColorName();
	UnitFramesPlus_PartyLevel();
	UnitFramesPlus_PartyHealthPct();
end
