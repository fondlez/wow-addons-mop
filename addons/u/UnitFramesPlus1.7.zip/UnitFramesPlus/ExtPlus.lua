﻿--变量
local id = 1;
local _G = _G;

--BOSS生命值百分比
for id = 1, 4, 1 do
	local BossHPPct = CreateFrame("Frame", "Boss"..id.."HPPct", _G["Boss"..id.."TargetFrameHealthBar"]);
	BossHPPct:SetWidth(50)
	BossHPPct:SetHeight(20)
	BossHPPct:ClearAllPoints();
	BossHPPct:SetPoint("LEFT", _G["Boss"..id.."TargetFrameHealthBar"], "LEFT", -51, 0)
	BossHPPct.Text = BossHPPct:CreateFontString("Boss"..id.."PercentText", "ARTWORK", "TextStatusBarText")
	BossHPPct.Text:SetAllPoints(BossHPPct)
	BossHPPct.Text:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
	BossHPPct.Text:SetTextColor(1, 0.75, 0);
	BossHPPct.Text:SetJustifyH("RIGHT")
end

function UnitFramesPlus_BossHealthPct()
	if UnitFramesPlusDB["ext"]["bosshppct"] == 1 then
		for id = 1, 4, 1 do
			_G["Boss"..id.."HPPct"]:RegisterEvent("INSTANCE_ENCOUNTER_ENGAGE_UNIT");
			_G["Boss"..id.."HPPct"]:RegisterUnitEvent("UNIT_HEALTH_FREQUENT", "boss"..id)
			_G["Boss"..id.."HPPct"]:SetScript("OnEvent", function(self, event, ...)
				UnitFramesPlus_BossHealthPctDisplayUpdate(id);
			end)
		end
	else
		for id = 1, 4, 1 do
			_G["Boss"..id.."HPPct"].Text:SetText("");
			if _G["Boss"..id.."HPPct"]:IsEventRegistered("INSTANCE_ENCOUNTER_ENGAGE_UNIT") then
				_G["Boss"..id.."HPPct"]:UnregisterEvent("INSTANCE_ENCOUNTER_ENGAGE_UNIT");
				_G["Boss"..id.."HPPct"]:UnregisterEvent("UNIT_HEALTH_FREQUENT");
				_G["Boss"..id.."HPPct"]:SetScript("OnEvent", nil);
			end
		end
	end
end
--ArenaEnemyFrame12

--刷新目标生命值百分比显示
function UnitFramesPlus_BossHealthPctDisplayUpdate(id)
	local PctText = "";
	if UnitExists("boss"..id) and UnitFramesPlusDB["ext"]["bosshppct"] == 1 then
		local CurHP = UnitHealth("boss"..id);
		local MaxHP = UnitHealthMax("boss"..id);
		if MaxHP > 0 then
			PctText = math.floor(100*CurHP/MaxHP).."%";
		end
	end
	_G["Boss"..id.."HPPct"].Text:SetText(PctText);
end

function UnitFramesPlus_ExtInit()
	UnitFramesPlus_BossHealthPct();
end
