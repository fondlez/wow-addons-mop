﻿--非战斗状态中允许shift+左键拖动焦点头像
local function UnitFramesPlus_FocusShiftDrag()
	FocusFrame:SetScript("OnMouseDown", function(self, elapsed)
		if UnitFramesPlusDB["focus"]["movable"] == 1 then
			if IsShiftKeyDown() and (not InCombatLockdown()) then
				FocusFrame:StartMoving();
				UnitFramesPlusVar["focus"]["moving"] = 1;
			end
		end
	end)

	FocusFrame:SetScript("OnMouseUp", function(self, elapsed)
		if UnitFramesPlusVar["focus"]["moving"] == 1 then
			FocusFrame:StopMovingOrSizing();
			UnitFramesPlusVar["focus"]["moving"] = 0;
		end
	end)

	FocusFrame:SetClampedToScreen(1);
end

--头像缩放
function UnitFramesPlus_FocusFrameScale(oldscale, newscale)
	local oldscale = oldscale or UnitFramesPlusDB["focus"]["scale"];
	local newscale = newscale or UnitFramesPlusDB["focus"]["scale"];
	if (not InCombatLockdown()) and UnitFramesPlusDB["focus"]["fullsize"] == 1 then
		local point, relativeTo, relativePoint, offsetX, offsetY = FocusFrame:GetPoint();
		FocusFrame:SetScale(newscale);
		FocusFrame:ClearAllPoints();
		FocusFrame:SetPoint(point, relativeTo, relativePoint, offsetX*oldscale/newscale, offsetY*oldscale/newscale);
	end
end

--登录游戏时是否自动使用放大的焦点头像
local function UnitFramesPlus_SysFocus()
	if UnitFramesPlusDB["focus"]["fullsize"] == 1 then
		SetCVar("fullSizeFocusFrame", 1, 1);
	else
		SetCVar("fullSizeFocusFrame", 0, 1);
	end
end

--焦点生命值百分比
local FocusHPPct = CreateFrame("Frame", "FocusHPPct", FocusFrame);
FocusHPPct:SetWidth(45);
FocusHPPct:SetHeight(20);
FocusHPPct:ClearAllPoints();
FocusHPPct:SetPoint("RIGHT", FocusFrameHealthBar, "LEFT", -5, -1);
FocusHPPct.Text = FocusHPPct:CreateFontString("FocusHPPctText", "ARTWORK", "TextStatusBarText");
FocusHPPct.Text:SetAllPoints(FocusHPPct);
FocusHPPct.Text:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
FocusHPPct.Text:SetTextColor(1, 0.75, 0);
FocusHPPct.Text:SetJustifyH("RIGHT");
function UnitFramesPlus_FocusHealthPct()
	if UnitFramesPlusDB["focus"]["hppct"] == 1 then
		FocusHPPct:RegisterEvent("PLAYER_FOCUS_CHANGED");
		FocusHPPct:RegisterUnitEvent("UNIT_HEALTH_FREQUENT", "focus");
		FocusHPPct:SetScript("OnEvent", function(self, event, ...)
			if UnitExists("focus") then
				UnitFramesPlus_FocusHealthPctDisplayUpdate();
			end
		end)
	else
		FocusHPPct.Text:SetText("");
		if FocusHPPct:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			FocusHPPct:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			FocusHPPct:UnregisterEvent("UNIT_HEALTH_FREQUENT");
			FocusHPPct:SetScript("OnEvent", nil);
		end
	end
end

--刷新焦点生命值百分比显示
function UnitFramesPlus_FocusHealthPctDisplayUpdate()
	local PctText = "";
	if UnitFramesPlusDB["focus"]["hppct"] == 1 then
		local CurHP = UnitHealth("focus");
		local MaxHP = UnitHealthMax("focus");
		if MaxHP > 0 then
			PctText = math.floor(100*CurHP/MaxHP).."%";
		end
	end
	FocusHPPct.Text:SetText(PctText);
end

--焦点法力值百分比
local FocusMPPct = CreateFrame("Frame", "FocusMPPct", FocusFrame);
FocusMPPct:SetWidth(45);
FocusMPPct:SetHeight(20);
FocusMPPct:ClearAllPoints();
FocusMPPct:SetPoint("RIGHT", FocusFrameManaBar, "LEFT", -5, -1);
FocusMPPct.Text = FocusMPPct:CreateFontString("FocusMPPctText", "ARTWORK", "TextStatusBarText");
FocusMPPct.Text:SetAllPoints(FocusMPPct);
FocusMPPct.Text:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
FocusMPPct.Text:SetTextColor(1, 1, 1);
FocusMPPct.Text:SetJustifyH("RIGHT");
function UnitFramesPlus_FocusManaPct()
	if UnitFramesPlusDB["focus"]["mppct"] == 1 then
		FocusMPPct:RegisterEvent("PLAYER_FOCUS_CHANGED");
		FocusMPPct:RegisterUnitEvent("UNIT_POWER", "focus");
		FocusMPPct:SetScript("OnEvent", function(self, event, ...)
			if UnitExists("focus") then
				UnitFramesPlus_FocusManaPctDisplayUpdate();
			end
		end)
	else
		FocusMPPct.Text:SetText("");
		if FocusMPPct:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			FocusMPPct:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			FocusMPPct:UnregisterEvent("UNIT_POWER");
			FocusMPPct:SetScript("OnEvent", nil);
		end
	end
end

--刷新焦点法力值百分比显示
function UnitFramesPlus_FocusManaPctDisplayUpdate()
	if UnitFramesPlusDB["focus"]["mppct"] == 1 then
		local MPPct = "";
		local CurMP = UnitPower("focus");
		local MaxMP = UnitPowerMax("focus");
		local powerType = UnitPowerType("focus");
		if powerType == 0 then
			if MaxMP > 0 then
				MPPct = math.floor(100*CurMP/MaxMP).."%";
			end
		end
		FocusMPPct.Text:SetText(MPPct);
	end
end

--焦点生命条染色
local chb = CreateFrame("Frame");
function UnitFramesPlus_FocusColorHPBar()
	if UnitFramesPlusDB["focus"]["colorhp"] == 1 then
		if UnitFramesPlusDB["focus"]["colortype"] == 1 then
			FocusFrameHealthBar:SetScript("OnValueChanged", nil);
			chb:RegisterEvent("PLAYER_FOCUS_CHANGED");
			chb:SetScript("OnEvent", function(self, event, ...)
				if UnitExists("focus") then
					UnitFramesPlus_FocusColorHPBarDisplayUpdate();
				end
			end)
		elseif UnitFramesPlusDB["focus"]["colortype"] == 2 then
			if chb:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
				chb:UnregisterEvent("PLAYER_FOCUS_CHANGED");
				chb:SetScript("OnEvent", nil);
			end
			FocusFrameHealthBar:SetScript("OnValueChanged", function(self, value)
				UnitFramesPlus_FocusColorHPBarDisplayUpdate();
			end)
		end
		FocusFrameHealthBar.lockColor = true;
	else
		FocusFrameHealthBar:SetScript("OnValueChanged", nil);
		if chb:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			chb:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			chb:SetScript("OnEvent", nil);
		end
		FocusFrameHealthBar:SetStatusBarColor(0, 1, 0);
		FocusFrameHealthBar.lockColor = nil;
	end
end

--刷新焦点生命条染色显示
function UnitFramesPlus_FocusColorHPBarDisplayUpdate()
	if UnitFramesPlusDB["focus"]["colorhp"] == 1 then
		if UnitFramesPlusDB["focus"]["colortype"] == 1 then
			local HealthBarColor = {r=0, g=1, b=0};
			if UnitIsPlayer("focus") then
				HealthBarColor = RAID_CLASS_COLORS[select(2, UnitClass("focus"))] or {r=0, g=1, b=0};
			end
			FocusFrameHealthBar:SetStatusBarColor(HealthBarColor.r, HealthBarColor.g, HealthBarColor.b);
		elseif UnitFramesPlusDB["focus"]["colortype"] == 2 then
			local CurHP = UnitHealth("focus");
			local MaxHP = UnitHealthMax("focus");
			local Pct = math.floor(100*CurHP/MaxHP)/100;
			local r, g, b = 0, 1, 0;
			if Pct > 0.5 then
				r = (1.0-Pct)*2;
				g = 1.0;
			else
				r = 1.0;
				g = Pct*2;
			end
			if r < 0 then r = 0 end
			if g < 0 then g = 0 end
			if r > 1 then r = 1 end
			if g > 1 then g = 1 end
			FocusFrameHealthBar:SetStatusBarColor(r, g, b);
		end
	end
end

--焦点种族或类型
local FocusType = FocusFrame:CreateFontString("FocusType", "ARTWORK", "TextStatusBarText");
FocusType:ClearAllPoints();
FocusType:SetPoint("BOTTOMLEFT", FocusFrameNameBackground, "TOPLEFT", 6, 2);
FocusType:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
FocusType:SetTextColor(1, 0.75, 0);

local FocusRace = FocusFrame:CreateFontString("FocusRace", "ARTWORK", "TextStatusBarText");
FocusRace:ClearAllPoints();
FocusRace:SetPoint("BOTTOMLEFT", FocusFrameNameBackground, "TOPLEFT", 6, 2);
FocusRace:SetFont(GameFontNormal:GetFont(), 12, "OUTLINE");
FocusRace:SetTextColor(1, 0.75, 0);

local tr = CreateFrame("Frame");
function UnitFramesPlus_FocusRace()
	if UnitFramesPlusDB["focus"]["race"] == 1 then
		tr:RegisterEvent("PLAYER_FOCUS_CHANGED");
		tr:SetScript("OnEvent", function(self, event)
			if UnitExists("focus") then
				UnitFramesPlus_FocusRaceDisplayUpdate();
			end
		end)
	else
		FocusType:SetText("");
		FocusRace:SetText("");
		if tr:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			tr:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			tr:SetScript("OnEvent", nil);
		end
	end
end

--刷新焦点种族或类型显示
function UnitFramesPlus_FocusRaceDisplayUpdate()
	local typeText = "";
	local raceText = "";
	if UnitFramesPlusDB["focus"]["race"] == 1 then
		if UnitIsPlayer("focus") then
			raceText = UnitRace("focus");
		elseif UnitCreatureType("focus") then
			typeText = UnitCreatureType("focus");
		end
	end
	FocusType:SetText(typeText);
	FocusRace:SetText(raceText);
end

--焦点职业图标
local ClassIcon = CreateFrame("Button", "FocusClass", FocusFrame);
ClassIcon:Hide();
ClassIcon:SetWidth(32);
ClassIcon:SetHeight(32);
ClassIcon:ClearAllPoints();
ClassIcon:SetPoint("TOPLEFT", FocusFrame, "TOPLEFT", 119, 3);
ClassIcon:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight");

ClassIcon.Border = ClassIcon:CreateTexture("FocusClassBorder", "OVERLAY");
ClassIcon.Border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder");
ClassIcon.Border:SetWidth(54);
ClassIcon.Border:SetHeight(54);
ClassIcon.Border:SetPoint("CENTER", 11, -12);

ClassIcon.Background = ClassIcon:CreateTexture("FocusClassBG", "BORDER");
ClassIcon.Background:SetTexture("Interface\\Minimap\\UI-Minimap-Background");
ClassIcon.Background:SetWidth(20);
ClassIcon.Background:SetHeight(20);
ClassIcon.Background:SetPoint("CENTER");
ClassIcon.Background:SetVertexColor(0, 0, 0, 1);

ClassIcon.Icon = ClassIcon:CreateTexture("FocusClassIcon", "ARTWORK");
ClassIcon.Icon:SetTexture("Interface\\WorldStateFrame\\Icons-Classes");
ClassIcon.Icon:SetWidth(20);
ClassIcon.Icon:SetHeight(20);
ClassIcon.Icon:SetPoint("CENTER");

local fci = CreateFrame("Frame");
function UnitFramesPlus_FocusClassIcon()
	if UnitFramesPlusDB["focus"]["classicon"] == 1 then
		fci:RegisterEvent("PLAYER_FOCUS_CHANGED");
		fci:SetScript("OnEvent", function(self, event)
			if UnitExists("focus") then
				UnitFramesPlus_FocusClassIconDisplayUpdate();
			end
		end)
	else
		ClassIcon:Hide();
		if fci:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			fci:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			fci:SetScript("OnEvent", nil);
		end
	end
end

--刷新焦点职业图标显示
function UnitFramesPlus_FocusClassIconDisplayUpdate()
	if UnitFramesPlusDB["focus"]["classicon"] == 1 then
		if UnitIsPlayer("focus") then
			local coord = CLASS_BUTTONS[select(2, UnitClass("focus"))];
			FocusClassIcon:SetTexCoord(unpack(coord));
			ClassIcon:Show();
		else
			ClassIcon:Hide();
		end
	else
		ClassIcon:Hide();
	end
end

--焦点职业图标扩展：左键观察/右键交易/中键密语/四号键跟随
local isclicked = false;
local function FocusClassIconDown()
	local point, relativeTo, relativePoint, offsetX, offsetY = FocusClassIcon:GetPoint();
	FocusClassIcon:ClearAllPoints();
	FocusClassIcon:SetPoint(point, relativeTo, relativePoint, offsetX+1, offsetY-1);
	return true;
end

ClassIcon:SetScript("OnMouseDown", function(self, button)
	if UnitFramesPlusDB["focus"]["moreaction"] == 1 then
		if (not UnitCanAttack("player", "focus")) and UnitIsPlayer("focus") then
			if button == "LeftButton" then
				if CheckInteractDistance("focus", 1) then
					isclicked = FocusClassIconDown();
					InspectUnit("focus");
				end
			elseif button == "RightButton" then
				if CheckInteractDistance("focus", 2) then
					isclicked = FocusClassIconDown();
					InitiateTrade("focus");
				end
			elseif button == "MiddleButton" then
				isclicked = FocusClassIconDown();
				local server = nil;
				local name, server = UnitName("focus");
				local fullname = name;
				if server and (not "focus" or not UnitIsSameServer("player", "focus")) then
					fullname = name.."-"..server;
				end
				ChatFrame_SendTell(fullname);
			elseif button == "Button4" then
				if CheckInteractDistance("focus",4) then
					isclicked = FocusClassIconDown();
					local server = nil;
					local name, server = UnitName("focus");
					local fullname = name;
					if server and (not "focus" or not UnitIsSameServer("player", "focus")) then
						fullname = name.."-"..server;
					end
					FollowUnit(fullname, 1);
				end
			end
		end
	end
end)

local function FocusClassIconUp()
	local point, relativeTo, relativePoint, offsetX, offsetY = FocusClassIcon:GetPoint();
	FocusClassIcon:ClearAllPoints();
	FocusClassIcon:SetPoint(point, relativeTo, relativePoint, offsetX-1, offsetY+1);
	return false;
end

ClassIcon:SetScript("OnMouseUp", function(self)
	if UnitFramesPlusDB["focus"]["moreaction"] == 1 and isclicked then
		isclicked = FocusClassIconUp();
	end
end)

--焦点头像内战斗信息
local FocusPortraitIndicator = CreateFrame("Frame", "FocusPortraitIndicator", FocusFrame);
FocusPortraitIndicator:CreateFontString("FocusHitIndicator", "OVERLAY", "NumberFontNormalHuge");
FocusHitIndicator:ClearAllPoints();
FocusHitIndicator:SetPoint("CENTER", FocusFramePortrait, "CENTER", 0, 0);
CombatFeedback_Initialize(FocusPortraitIndicator, FocusHitIndicator, 28);
function UnitFramesPlus_FocusPortraitIndicator()
	if UnitFramesPlusDB["focus"]["indicator"] == 1 then
		FocusPortraitIndicator:RegisterEvent("PLAYER_FOCUS_CHANGED");
		FocusPortraitIndicator:RegisterUnitEvent("UNIT_COMBAT", "focus");
		FocusPortraitIndicator:SetScript("OnEvent", function(self, event, ...)
			if event == "PLAYER_FOCUS_CHANGED" then
				FocusHitIndicator:Hide();
			elseif event == "UNIT_COMBAT" then
				local arg1, arg2, arg3, arg4, arg5 = ...;
				CombatFeedback_OnCombatEvent(self, arg2, arg3, arg4, arg5);
			end
		end)

		FocusPortraitIndicator:SetScript("OnUpdate", function(self, elapsed)
			CombatFeedback_OnUpdate(self, elapsed);
		end)
	else
		FocusHitIndicator:Hide();
		if FocusPortraitIndicator:IsEventRegistered("UNIT_COMBAT") then
			FocusPortraitIndicator:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			FocusPortraitIndicator:UnregisterEvent("UNIT_COMBAT");
			FocusPortraitIndicator:SetScript("OnEvent", nil);
			FocusPortraitIndicator:SetScript("OnUpdate", nil);
		end
	end
end

--快速焦点，基于slizen的Focuser
local modifierButtons = {"alt", "shift", "ctrl"};
local modifier = "alt";--默认快捷键
local mouseButton = "1";--默认按键：1-左键, 2-右键, 3-中键, 4/5-鼠标快捷键
local actionType = "focus";--默认动作：focus, target
local _G = _G;

local CreateFrame_Hook = function(type, name, parent, template)
	if name and template == "SecureUnitButtonTemplate" then
		_G[name]:SetAttribute(modifier.."-type"..mouseButton, actionType);
	end
end

local frametarget = CreateFrame("CheckButton", "ActionButtonTarget", UIParent, "SecureActionButtonTemplate");
frametarget:SetAttribute("type1", "macro");
frametarget:SetAttribute("macrotext", "/target mouseover");

hooksecurefunc("CreateFrame", CreateFrame_Hook)
local framefocus = CreateFrame("CheckButton", "ActionButton", UIParent, "SecureActionButtonTemplate");
framefocus:SetAttribute("type1", "macro");
framefocus:SetAttribute("macrotext", "/focus mouseover");

local duf = {
	PetFrame,
	PartyMemberFrame1,
	PartyMemberFrame2,
	PartyMemberFrame3,
	PartyMemberFrame4,
	PartyMemberFrame1PetFrame,
	PartyMemberFrame2PetFrame,
	PartyMemberFrame3PetFrame,
	PartyMemberFrame4PetFrame,
	PartyTarget1,
	PartyTarget2,
	PartyTarget3,
	PartyTarget4,
	TargetFrame,
	TargetFrameToT,
	TargetofTargetTargetFrame,
}

function UnitFramesPlus_FocusQuickClear(button)
	actionType = "target";
	modifier = button;
	SetOverrideBindingClick(ActionButtonTarget, true, modifier.."-BUTTON"..mouseButton, "ActionButtonTarget");
	for i, frame in pairs(duf) do
		frame:SetAttribute(modifier.."-type"..mouseButton, actionType);
	end
end

function UnitFramesPlus_FocusQuickInit()
	if UnitFramesPlusDB["focus"]["quick"] == 1 then
		actionType = "focus";
		modifier = modifierButtons[UnitFramesPlusDB["focus"]["button"]];
		SetOverrideBindingClick(ActionButton, true, modifier.."-BUTTON"..mouseButton, "ActionButton");
		for i, frame in pairs(duf) do
			frame:SetAttribute(modifier.."-type"..mouseButton, actionType);
		end
	end
end

function UnitFramesPlus_FocusQuick()
	if UnitFramesPlusDB["focus"]["quick"] == 1 then
		UnitFramesPlus_FocusQuickInit();
	else
		UnitFramesPlus_FocusQuickClear(modifierButtons[UnitFramesPlusDB["focus"]["button"]]);
	end
end

--焦点3D头像
local Focus3DPortrait = CreateFrame("PlayerModel", "Focus3DPortrait", FocusFrame);
Focus3DPortrait:SetWidth(50);
Focus3DPortrait:SetHeight(50);
Focus3DPortrait:SetFrameLevel(1);
Focus3DPortrait:ClearAllPoints();
Focus3DPortrait:SetPoint("CENTER", FocusFramePortrait, "CENTER", -1, -1);
Focus3DPortrait:Hide();
Focus3DPortrait.Background = Focus3DPortrait:CreateTexture("Focus3DPortraitBG", "BACKGROUND");
Focus3DPortrait.Background:SetTexture("Interface\\AddOns\\UnitFramesPlus\\Portrait3D");
Focus3DPortrait.Background:SetWidth(64);
Focus3DPortrait.Background:SetHeight(64);
Focus3DPortrait.Background:ClearAllPoints();
Focus3DPortrait.Background:SetPoint("CENTER", Focus3DPortrait, "CENTER", 0, 0);
Focus3DPortrait.Background:Hide();

local f3d = CreateFrame("Frame");
function UnitFramesPlus_Focus3DPortrait()
	if UnitFramesPlusDB["focus"]["p3d"] == 1 then
		FocusFramePortrait:Hide();
		Focus3DPortrait:Show();
		UnitFramesPlus_Focus3DPortraitBGDisplayUpdate();
		f3d:RegisterEvent("PLAYER_FOCUS_CHANGED");
		f3d:RegisterUnitEvent("UNIT_MODEL_CHANGED", "focus");
		f3d:RegisterUnitEvent("UNIT_CONNECTION", "focus");
		f3d:RegisterUnitEvent("UNIT_HEALTH_FREQUENT", "focus");
		f3d:SetScript("OnEvent", function(self, event, ...)
			if event == "PLAYER_FOCUS_CHANGED" then
				if UnitExists("focus") then
					if UnitFramesPlusDB["focus"]["p3dbg"] == 1 then
						local color = RAID_CLASS_COLORS[select(2, UnitClass("focus"))] or NORMAL_FONT_COLOR;
						Focus3DPortrait.Background:SetVertexColor(color.r/1.5, color.g/1.5, color.b/1.5, 1);
					end
					UnitFramesPlus_Focus3DPortraitDisplayUpdate();
				end
			elseif event == "UNIT_MODEL_CHANGED" or event == "UNIT_CONNECTION" then
				UnitFramesPlus_Focus3DPortraitDisplayUpdate();
			elseif event == "UNIT_HEALTH_FREQUENT" then
				if (not UnitIsConnected("focus")) or UnitIsGhost("focus") then
					Focus3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 0.25, 0.25, 0.25);
				elseif UnitIsDead("focus") then
					Focus3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 0.3, 0.3);
				else
					Focus3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 1, 1);
				end
			end
		end)
	else
		FocusFramePortrait:Show();
		Focus3DPortrait:Hide();
		Focus3DPortrait.Background:Hide();
		if f3d:IsEventRegistered("PLAYER_FOCUS_CHANGED") then
			f3d:UnregisterEvent("PLAYER_FOCUS_CHANGED");
			f3d:UnregisterEvent("UNIT_MODEL_CHANGED");
			f3d:UnregisterEvent("UNIT_CONNECTION");
			f3d:UnregisterEvent("UNIT_HEALTH_FREQUENT");
			f3d:SetScript("OnEvent", nil);
		end
	end
end

--刷新焦点3D头像显示
function UnitFramesPlus_Focus3DPortraitDisplayUpdate()
	if (not UnitIsConnected("focus")) or (not UnitIsVisible("focus")) then
		Focus3DPortrait:SetPortraitZoom(0);
		Focus3DPortrait:SetCamDistanceScale(0.25);
		Focus3DPortrait:SetPosition(0,0,0.5);
		Focus3DPortrait:ClearModel();
		Focus3DPortrait:SetModel("Interface\\Buttons\\TalkToMeQuestionMark.M2");
	else
		Focus3DPortrait:SetPortraitZoom(1);
		Focus3DPortrait:SetCamDistanceScale(1);
		Focus3DPortrait:SetPosition(0,0,0);
		Focus3DPortrait:ClearModel();
		Focus3DPortrait:SetUnit("focus");
		if (not UnitIsConnected("focus")) or UnitIsGhost("focus") then
			Focus3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 0.25, 0.25, 0.25);
		elseif UnitIsDead("focus") then
			Focus3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 0.3, 0.3);
		else
			Focus3DPortrait:SetLight(1, 0, 0, 0, 0, 1.0, 1, 1, 1);
		end
	end
end

--刷新焦点3D头像背景显示
function UnitFramesPlus_Focus3DPortraitBGDisplayUpdate()
	if UnitFramesPlusDB["focus"]["p3d"] == 1 and UnitFramesPlusDB["focus"]["p3dbg"] == 1 then
		Focus3DPortrait.Background:Show();
	else
		Focus3DPortrait.Background:Hide();
	end
end

--模块初始化
function UnitFramesPlus_FocusInit()
	UnitFramesPlus_FocusShiftDrag();
	UnitFramesPlus_SysFocus();
	UnitFramesPlus_FocusHealthPct();
	UnitFramesPlus_FocusManaPct();
	UnitFramesPlus_FocusRace();
	UnitFramesPlus_FocusClassIcon();
	UnitFramesPlus_FocusColorHPBar();
	UnitFramesPlus_FocusPortraitIndicator();
	UnitFramesPlus_FocusQuickInit();
	UnitFramesPlus_Focus3DPortrait();
	UnitFramesPlus_FocusFrameScale();
end
