﻿--焦点目标
local ToFFrame = CreateFrame("Button", "ToFFrame", FocusFrame, "SecureUnitButtonTemplate");
ToFFrame:SetFrameLevel(7);
ToFFrame:SetWidth(96);
ToFFrame:SetHeight(48);
ToFFrame:ClearAllPoints();
ToFFrame:SetPoint("LEFT", FocusFrame, "RIGHT", -20, 0);
ToFFrame:SetAlpha(0);
ToFFrame:SetMovable(1);

ToFFrame.Portrait = ToFFrame:CreateTexture("ToFPortrait", "BORDER");
ToFFrame.Portrait:SetWidth(27);
ToFFrame.Portrait:SetHeight(27);
ToFFrame.Portrait:ClearAllPoints();
ToFFrame.Portrait:SetPoint("TOPLEFT", ToFFrame, "TOPLEFT", 6, -5);

ToFFrame.Texture = ToFFrame:CreateTexture("ToFTexture", "ARTWORK");
ToFFrame.Texture:SetTexture("Interface\\TargetingFrame\\UI-PartyFrame");
ToFFrame.Texture:SetWidth(96);
ToFFrame.Texture:SetHeight(48);
ToFFrame.Texture:ClearAllPoints();
ToFFrame.Texture:SetPoint("TOPLEFT", ToFFrame, "TOPLEFT", 0, -2);

ToFFrame.Name = ToFFrame:CreateFontString("ToFName", "ARTWORK", "GameFontNormalSmall");
ToFFrame.Name:ClearAllPoints();
ToFFrame.Name:SetPoint("BOTTOMLEFT", ToFFrame, "BOTTOMLEFT", 33, 39);

ToFFrame.HealthBar = CreateFrame("StatusBar", "ToFHealthBar", FocusFrame);
ToFFrame.HealthBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");
ToFFrame.HealthBar:SetFrameLevel(2);
ToFFrame.HealthBar:SetMinMaxValues(0, 100);
ToFFrame.HealthBar:SetValue(0);
ToFFrame.HealthBar:SetWidth(53);
ToFFrame.HealthBar:SetHeight(6);
ToFFrame.HealthBar:ClearAllPoints();
ToFFrame.HealthBar:SetPoint("TOPLEFT", ToFFrame, "TOPLEFT", 35, -9);
ToFFrame.HealthBar:SetStatusBarColor(0, 1, 0);

ToFFrame.HPPct = ToFFrame:CreateFontString("ToFHPPct", "ARTWORK", "TextStatusBarText");
ToFFrame.HPPct:SetFont(GameFontNormal:GetFont(), 10, "OUTLINE");
ToFFrame.HPPct:SetTextColor(1, 0.75, 0);
ToFFrame.HPPct:SetJustifyH("LEFT");
ToFFrame.HPPct:ClearAllPoints();
ToFFrame.HPPct:SetPoint("LEFT", ToFFrame.HealthBar, "RIGHT", 2, -4);

ToFFrame.PowerBar = CreateFrame("StatusBar", "ToFPowerBar", FocusFrame);
ToFFrame.PowerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");
ToFFrame.PowerBar:SetFrameLevel(2);
ToFFrame.PowerBar:SetMinMaxValues(0, 100);
ToFFrame.PowerBar:SetValue(0);
ToFFrame.PowerBar:SetWidth(53);
ToFFrame.PowerBar:SetHeight(6);
ToFFrame.PowerBar:ClearAllPoints();
ToFFrame.PowerBar:SetPoint("TOPLEFT", ToFFrame, "TOPLEFT", 35, -16);
ToFFrame.PowerBar:SetStatusBarColor(0, 0, 1);

--允许点击选取目标
ToFFrame.DropDown = CreateFrame("Button", "ToFDropDown", FocusFrame, "UIDropDownMenuTemplate");
ToFFrame.DropDown:SetWidth(10);
ToFFrame.DropDown:SetHeight(10);
ToFFrame.DropDown:ClearAllPoints();
ToFFrame.DropDown:SetPoint("TOP", ToFFrame, "TOP", -20, -10);
ToFFrame.DropDown:Hide();

local showmenu = (function()
	ToggleDropDownMenu(1, nil, ToFFrame.DropDown, "ToFFrame", 40, 0);
end)
SecureUnitButton_OnLoad(ToFFrame, "focustarget", showmenu);

ToFFrame:RegisterForClicks("AnyUp");
ToFFrame:RegisterForDrag("LeftButton");

local tof = CreateFrame("Frame");
local ToFPctText = "";
function UnitFramesPlus_FocusTarget()
	if UnitFramesPlusDB["focus"]["tof"] == 1 then
		tof:SetScript("OnUpdate", function(self, elapsed)
			self.timer = (self.timer or 0) + elapsed;
			if self.timer >= 0.1 then
				if UnitExists("focustarget") then
					ToFFrame:SetAlpha(1);

					ToFFrame.Name:SetText(UnitName("focustarget"));

					ToFNameColor = PowerBarColor[UnitPowerType("focustarget")] or PowerBarColor["MANA"];
					ToFFrame.PowerBar:SetStatusBarColor(ToFNameColor.r, ToFNameColor.g, ToFNameColor.b);

					SetPortraitTexture(ToFFrame.Portrait, "focustarget");

					if UnitHealthMax("focustarget") > 0 then
						ToFFrame.HealthBar:SetValue(UnitHealth("focustarget") / UnitHealthMax("focustarget") * 100);
						ToFPctText = "";
						if UnitFramesPlusDB["focus"]["tofhppct"] == 1 then
							ToFPctText = math.floor(UnitHealth("focustarget") / UnitHealthMax("focustarget") * 100).."%";
						end
						ToFFrame.HPPct:SetText(ToFPctText);
					else
						ToFFrame.HealthBar:SetValue(0);
						ToFFrame.HPPct:SetText("");
					end

					if UnitPowerMax("focustarget") > 0 then
						ToFFrame.PowerBar:SetValue(UnitPower("focustarget") / UnitPowerMax("focustarget") * 100);
					else
						ToFFrame.PowerBar:SetValue(0);
					end
				else
					ToFFrame:SetAlpha(0);
					ToFFrame.HealthBar:SetValue(0);
					ToFFrame.PowerBar:SetValue(0);
					ToFFrame.HPPct:SetText("");
				end
				self.timer = 0;
			end
		end);
	else
		ToFFrame:SetAlpha(0);
		ToFFrame.HealthBar:SetValue(0);
		ToFFrame.PowerBar:SetValue(0);
		ToFFrame.HPPct:SetText("");
		tof:SetScript("OnUpdate", nil);
	end
end

--非战斗状态中允许shift+左键拖动焦点目标头像
local function UnitFramesPlus_FocusTargetShiftDrag()
	ToFFrame:SetScript("OnMouseDown", function(self, elapsed)
		if UnitFramesPlusDB["focus"]["movable"] == 1 then
			if IsShiftKeyDown() and (not InCombatLockdown()) then
				ToFFrame:StartMoving();
				UnitFramesPlusVar["focus"]["tmoving"] = 1;
			end
		end
	end)

	ToFFrame:SetScript("OnMouseUp", function(self, elapsed)
		if UnitFramesPlusVar["focus"]["tmoving"] == 1 then
			ToFFrame:StopMovingOrSizing();
			UnitFramesPlusVar["focus"]["tmoving"] = 0;
			UnitFramesPlusVar["focus"]["tmoved"] = 1;
			local bottom = ToFFrame:GetBottom();
			local left = ToFFrame:GetLeft();
			local scale = ToFFrame:GetScale()*FocusFrame:GetScale();
			local bottomX = FocusFrame:GetBottom();
			local leftX = FocusFrame:GetLeft();
			local scaleX = FocusFrame:GetScale();
			ToFFrame:ClearAllPoints();
			ToFFrame:SetPoint("BOTTOMLEFT", FocusFrame, "BOTTOMLEFT", (left*scale-leftX*scaleX)/scale, (bottom*scale-bottomX*scaleX)/scale);
		end
	end)

	ToFFrame:SetClampedToScreen(1);

	--重置目标位置时同时重置焦点目标位置
	hooksecurefunc("TargetFrame_ResetUserPlacedPosition", function()
		if ToFFrame then
			ToFFrame:ClearAllPoints();
			ToFFrame:SetPoint("LEFT", FocusFrame, "RIGHT", -20, 0);
			UnitFramesPlusVar["focus"]["tmoved"] = 0;
		end
	end)
end

--焦点目标头像缩放
function UnitFramesPlus_FocusTargetScale(oldscale, newscale)
	local oldscale = oldscale or UnitFramesPlusDB["focus"]["tscale"];
	local newscale = newscale or UnitFramesPlusDB["focus"]["tscale"];
	if UnitFramesPlusDB["focus"]["tof"] == 1 and (not InCombatLockdown()) then
		local point, relativeTo, relativePoint, offsetX, offsetY = ToFFrame:GetPoint();
		ToFFrame:SetScale(newscale);
		ToFFrame.HealthBar:SetScale(newscale);
		ToFFrame.PowerBar:SetScale(newscale);
		ToFFrame:ClearAllPoints();
		ToFFrame:SetPoint(point, relativeTo, relativePoint, offsetX*oldscale/newscale, offsetY*oldscale/newscale);
	end
end

--焦点目标头像位置
local function UnitFramesPlus_FocusTargetPosition()
	if UnitFramesPlusVar["focus"]["tmoved"] ~= 1 then
		ToFFrame:ClearAllPoints();
		ToFFrame:SetPoint("LEFT", FocusFrame, "RIGHT", -20, 0);
	else
		local bottom = ToFFrame:GetBottom();
		local left = ToFFrame:GetLeft();
		local scale = ToFFrame:GetScale()*FocusFrame:GetScale();
		local bottomX = FocusFrame:GetBottom();
		local leftX = FocusFrame:GetLeft();
		local scaleX = FocusFrame:GetScale();
		ToFFrame:ClearAllPoints();
		ToFFrame:SetPoint("BOTTOMLEFT", FocusFrame, "BOTTOMLEFT", (left*scale-leftX*scaleX)/scale, (bottom*scale-bottomX*scaleX)/scale);
	end
end

--模块初始化
function UnitFramesPlus_FocusTargetInit()
	UnitFramesPlus_FocusTarget();
	UnitFramesPlus_FocusTargetShiftDrag();
	UnitFramesPlus_FocusTargetScale();
	UnitFramesPlus_FocusTargetPosition();
end
