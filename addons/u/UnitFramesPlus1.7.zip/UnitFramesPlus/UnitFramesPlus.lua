﻿
--默认设置
UnitFramesPlusDefaultDB = {
	player = {
		scale = 1,		--玩家头像缩放比例
		dragon = 1,		--精英头像
		raretype = 1,	--精英头像类型：1精英头像，2银英头像，3稀有头像
		extbar = 1,		--扩展框
		hpmp = 1,		--不显示扩展框时增加生命值和法力值(百分比)显示
		hpmppartone = 1,--生命值和法力值第一部分：1当前值，2最大值，3百分比
		hpmpparttwo = 2,--生命值和法力值第二部分：1当前值，2最大值，3百分比，4不显示
		unit = 1,		--生命值和法力值单位，1为千进制(k/m)
		colorhp = 1,	--生命条染色
		colortype = 2,	--生命条染色类型：1职业，2生命值百分比
		movable = 1,	--Shift拖动头像
		barmovable = 1,	--Shift拖动资源条
		indicator = 1,	--头像内战斗信息
		p3d = 1,		--3D头像
		p3dbg = 1,		--3D头像背景
		coord = 1,		--坐标
		pettarget = 0,	--宠物目标
		ptscale = 0.8,	--宠物目标缩放比例
		pthppct = 1,	--宠物目标生命值百分比
		autohide = 0,	--玩家头像自动隐藏
	},

	target = {
		scale = 1,		--目标头像缩放比例
		statustext = 1,	--在进入游戏时自动开启系统生命/法力数值显示
		autotot = 1,	--在进入游戏时自动关闭系统ToT
		classicon = 1,	--职业图标
		moreaction = 1,	--职业图标左键观察，右键交易，中键密语，4键跟随
		race = 1,		--种族和类型
		hppct = 1,		--生命值百分比
		mppct = 1,		--法力值百分比
		colorhp = 1,	--生命条染色
		colortype = 2,	--生命条染色类型：1职业，2生命值百分比
		indicator = 1,	--头像内战斗信息
		buffsize = 1,	--调节目标buff/debuff图标大小
		mysize = 24,	--自己施放的buff/debuff大小，默认 21
		othersize = 16,	--其他人施放的buff/debuff大小，默认 17
		movable = 1,	--Shift拖动目标头像
		p3d = 1,		--3D头像
		p3dbg = 1,		--3D头像背景
		tot = 1,		--额外的ToT
		totot = 1,		--额外的ToToT
		tscale = 0.9,	--额外的ToT缩放比例
		debuff = 1,		--额外的ToT debuff
		tothppct = 1,	--额外的ToT生命值百分比
	},

	focus = {
		scale = 1,		--焦点头像缩放比例
		fullsize = 1,	--在进入游戏时自动开启系统扩大焦点框架
		quick = 1,		--快速设置焦点
		button = 1,		--快速设置焦点快捷键，1alt，2shift，3ctrl
		classicon = 1,	--职业图标
		moreaction = 1,	--职业图标左键观察，右键交易，中键密语，4键跟随
		race = 1,		--种族和类型
		hppct = 1,		--生命值百分比
		mppct = 1,		--法力值百分比
		colorhp = 1,	--生命条染色
		colortype = 2,	--生命条染色类型：1职业，2生命值百分比
		indicator = 1,	--头像内战斗信息
		movable = 1,	--Shift拖动头像
		p3d = 1,		--3D头像
		p3dbg = 1,		--3D头像背景
		tof = 1,		--焦点目标
		tscale = 0.9,	--焦点目标缩放比例
		tofhppct = 1,	--焦点目标生命值百分比
		spellbar = 0,	--焦点施法条
	},

	party = {
		level = 1,		--队友等级
		colorname = 1,	--队友名字染色
		hp = 1,			--队友生命值
		hppct = 1,		--队友生命值显示为百分比
		movable = 1,	--Shift拖动头像
		onoff = 1,		--队友离线检测
		indicator = 1,	--头像内战斗信息
		buff = 1,		--队友buff
		buffnum = 12,	--队友buff数量
		target = 1,		--队友目标
		spellbar = 1,	--队友施法条
		scale = 1,		--队友头像缩放比例
		colorhp = 1,	--生命条染色
		colortype = 1,	--生命条染色类型：1职业，2生命值百分比
		death = 1,		--队友死亡/鬼魂状态
	},

	ext = {
		bosshppct = 1,		--BOSS生命值百分比
	},

	version = 1.7,
}

UnitFramesPlusDefaultVar = {
	player = {
		moving = 0,		--玩家拖动状态
		barmoving = 0,	--玩家资源条拖动状态
		barposition = {},--玩家资源条移动后的位置
	},

	target = {
		moving = 0,		--目标拖动状态
		moved = 0,		--目标已被拖动
		tmoving = 0,	--ToT拖动状态
		tmoved = 0,		--ToT已被拖动
	},

	focus = {
		moving = 0,		--焦点拖动状态
		tmoving = 0,	--焦点目标拖动状态
		tmoved = 0,		--焦点目标已被拖动
	},

	party = {
		moving = 0,		--队友拖动状态
	},
}

--设置初始化
function UnitFramesPlus_Options_Init()
	if not UnitFramesPlusDB then
		UnitFramesPlusDB = UnitFramesPlusDefaultDB;
	end

	if not UnitFramesPlusVar then
		UnitFramesPlusVar = UnitFramesPlusDefaultVar;
	end
	
	local Version = tonumber(GetAddOnMetadata("UnitFramesPlus", "Version"));
	if (not UnitFramesPlusDB["version"]) or UnitFramesPlusDB["version"] ~= Version then
		local k, v, x, y;
		for k, v in pairs(UnitFramesPlusDefaultDB) do
			if type(v) == "table" then
				for x, y in pairs(UnitFramesPlusDefaultDB[k]) do
					if not UnitFramesPlusDB[k] then UnitFramesPlusDB[k] = {} end
					UnitFramesPlusDB[k][x] = UnitFramesPlusDB[k][x] or UnitFramesPlusDefaultDB[k][x];
				end
			else
				UnitFramesPlusDB[k] = UnitFramesPlusDB[k] or UnitFramesPlusDefaultDB[k];
			end
		end
		for k, v in pairs(UnitFramesPlusDefaultVar) do
			if type(v) == "table" then
				for x, y in pairs(UnitFramesPlusDefaultVar[k]) do
					if not UnitFramesPlusVar[k] then UnitFramesPlusVar[k] = {} end
					UnitFramesPlusVar[k][x] = UnitFramesPlusVar[k][x] or UnitFramesPlusDefaultVar[k][x];
				end
			else
				UnitFramesPlusVar[k] = UnitFramesPlusVar[k] or UnitFramesPlusDefaultVar[k];
			end
		end
		UnitFramesPlusDB["version"] = UnitFramesPlusDefaultDB["version"];
	end
end

--模块初始化
function UnitFramesPlus_Init()
	if UnitFramesPlus_PlayerInit then
		UnitFramesPlus_PlayerInit();
	end
	if UnitFramesPlus_PetTargetInit then
		UnitFramesPlus_PetTargetInit();
	end
	if UnitFramesPlus_TargetInit then
		UnitFramesPlus_TargetInit();
	end
	if UnitFramesPlus_TargetTargetInit then
		UnitFramesPlus_TargetTargetInit();
	end
	if UnitFramesPlus_FocusInit then
		UnitFramesPlus_FocusInit();
	end
	if UnitFramesPlus_FocusTargetInit then
		UnitFramesPlus_FocusTargetInit();
	end
	if UnitFramesPlus_FocusSpellbarInit then
		UnitFramesPlus_FocusSpellbarInit();
	end
	if UnitFramesPlus_PartyInit then
		UnitFramesPlus_PartyInit();
	end
	if UnitFramesPlus_PartyTargetInit then
		UnitFramesPlus_PartyTargetInit();
	end
	if UnitFramesPlus_PartySpellbarInit then
		UnitFramesPlus_PartySpellbarInit();
	end
	if UnitFramesPlus_ExtInit then
		UnitFramesPlus_ExtInit();
	end
end

--插件初始化
local ufp = CreateFrame("Frame");
ufp:RegisterEvent("ADDON_LOADED");
ufp:RegisterEvent("VARIABLES_LOADED");
ufp:RegisterEvent("PLAYER_LOGIN");
ufp:SetScript("OnEvent", function(self, event)
	if event == "ADDON_LOADED" then
		UnitFramesPlus_Options_Init();
	elseif event == "VARIABLES_LOADED" then
		print("|cFFFFFF99UnitFramesPlus loaded. Type /ufp or /unitframesplus to open the option panel.|R");
	elseif event == "PLAYER_LOGIN" then
		UnitFramesPlus_Init();
	end
end)

function UnitFramesPlus_LoadOptionPanel()
	if not IsAddOnLoaded("UnitFramesPlus_Options") then
		local _, _, _, enabled = GetAddOnInfo("UnitFramesPlus_Options");
		if not enabled then
			EnableAddOn("UnitFramesPlus_Options");
		end
		local loaded = LoadAddOn("UnitFramesPlus_Options");
		if not loaded then
			print("|cFFFF0000The option panel can't be loaded.|R");
			return false;
		end
	end
end

--设置面板
UnitFramesPlus_OptionsFrame = CreateFrame("Frame", "UnitFramesPlus_OptionsFrame", UIParent);
UnitFramesPlus_OptionsFrame:Hide();
UnitFramesPlus_OptionsFrame.name = "UnitFramesPlus";
local _, title = GetAddOnInfo("UnitFramesPlus_Options");
if title ~= nil then
	InterfaceOptions_AddCategory(UnitFramesPlus_OptionsFrame);
	UnitFramesPlus_OptionsFrame:SetScript("OnShow", function()
		local result = UnitFramesPlus_LoadOptionPanel();
		if result == false then return end
		UnitFramesPlus_OptionPanel_OnShow();
	end)
end

--命令行
SlashCmdList["UnitFramesPlus"] = function()
	local result = UnitFramesPlus_LoadOptionPanel();
	if result == false then return end
	InterfaceOptionsFrame_OpenToCategory("UnitFramesPlus");
end;
SLASH_UnitFramesPlus1 = "/unitframesplus";
SLASH_UnitFramesPlus2 = "/ufp";
