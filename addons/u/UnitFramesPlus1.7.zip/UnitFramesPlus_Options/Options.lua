﻿--变量
local id = 1;
local _G = _G;

--快速焦点快捷键下拉菜单
local QuickFocusDropDown = {"alt", "shift", "ctrl"};
local function QuickFocus_OnClick(self)
	UIDropDownMenu_SetSelectedID(UnitFramesPlus_OptionsFrame_FocusQuickDropDown, self:GetID());
	UnitFramesPlus_FocusQuickClear(QuickFocusDropDown[UnitFramesPlusDB["focus"]["button"]]);
	UnitFramesPlusDB["focus"]["button"] = self:GetID();
	UnitFramesPlus_FocusQuick();
end
local function QuickFocus_Init()
	local info, text, func;
	for id = 1, 3, 1 do
		info = {
			text = QuickFocusDropDown[id];
			func = QuickFocus_OnClick;
		};
		UIDropDownMenu_AddButton(info);
	end
end

--生命值/法力值/百分比下拉菜单
local PlayerHPMPPctDropDown = {Player_NumCur, Player_NumMax, Player_Pct, Player_None};
local function PlayerHPMPPctPartOne_OnClick(self)
	UIDropDownMenu_SetSelectedID(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne, self:GetID());
	UnitFramesPlusDB["player"]["hpmppartone"] = self:GetID();
	UnitFramesPlus_PlayerHPValueDisplayUpdate();
	UnitFramesPlus_PlayerMPValueDisplayUpdate();
end
local function PlayerHPMPPctPartOne_Init()
	local info, text, func;
	for id = 1, 3, 1 do
		info = {
			text = PlayerHPMPPctDropDown[id];
			func = PlayerHPMPPctPartOne_OnClick;
		};
		UIDropDownMenu_AddButton(info);
	end
end
local function PlayerHPMPPctPartTwo_OnClick(self)
	UIDropDownMenu_SetSelectedID(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo, self:GetID());
	UnitFramesPlusDB["player"]["hpmpparttwo"] = self:GetID();
	UnitFramesPlus_PlayerHPValueDisplayUpdate();
	UnitFramesPlus_PlayerMPValueDisplayUpdate();
end
local function PlayerHPMPPctPartTwo_Init()
	local info, text, func;
	for id = 1, 4, 1 do
		info = {
			text = PlayerHPMPPctDropDown[id];
			func = PlayerHPMPPctPartTwo_OnClick;
		};
		UIDropDownMenu_AddButton(info);
	end
end

do
	--插件介绍
	local info = UnitFramesPlus_OptionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	info:SetPoint("TOPLEFT", 16, -16);
	info:SetText("UnitFramesPlus v"..GetAddOnMetadata("UnitFramesPlus", "Version"));

	local infotext = UnitFramesPlus_OptionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
	infotext:SetPoint("TOPLEFT", info, "TOPLEFT", 0, -40);
	infotext:SetTextColor(1, 1, 1);
	infotext:SetText(UFP_InfoText);

	local infotext2 = UnitFramesPlus_OptionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
	infotext2:SetPoint("TOPLEFT", infotext, "TOPLEFT", 0, -30);
	infotext2:SetTextColor(1, 1, 1);
	infotext2:SetText(UFP_InfoText2);

	local infotext3 = UnitFramesPlus_OptionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
	infotext3:SetPoint("TOPLEFT", infotext2, "TOPLEFT", 0, -40);
	infotext3:SetTextColor(1, 1, 1);
	infotext3:SetText(UFP_InfoText3);
--[[
	--恢复默认设置
	local UnitFramesPlus_OptionsFrame_Reset = CreateFrame("Button", "UnitFramesPlus_OptionsFrame_Reset", UnitFramesPlus_OptionsFrame, "OptionsButtonTemplate");
	UnitFramesPlus_OptionsFrame_Reset:SetPoint("TOPLEFT", infotext3, "TOPLEFT", 0, -50);
	UnitFramesPlus_OptionsFrame_Reset:SetWidth(160);
	UnitFramesPlus_OptionsFrame_Reset:SetHeight(25);
	UnitFramesPlus_OptionsFrame_ResetText:SetText(UFP_Reset);
	UnitFramesPlus_OptionsFrame_Reset:SetScript("OnClick", function(self)
		UnitFramesPlusDB = UnitFramesPlusDefaultDB;
		UnitFramesPlus_Init();
		InterfaceOptionsFrame_OpenToCategory("UnitFramesPlus");
	end)
]]
	--玩家设置菜单
	local UnitFramesPlus_Player_Options = CreateFrame("Frame", "UnitFramesPlus_Player_Options", UIParent);
	UnitFramesPlus_Player_Options.name = Player_Options;
	UnitFramesPlus_Player_Options.parent = "UnitFramesPlus";
	UnitFramesPlus_Player_Options:Hide();
	InterfaceOptions_AddCategory(UnitFramesPlus_Player_Options);

	--目标设置菜单
	local UnitFramesPlus_Target_Options = CreateFrame("Frame", "UnitFramesPlus_Target_Options", UIParent);
	UnitFramesPlus_Target_Options.name = Target_Options;
	UnitFramesPlus_Target_Options.parent = "UnitFramesPlus";
	UnitFramesPlus_Target_Options:Hide();
	InterfaceOptions_AddCategory(UnitFramesPlus_Target_Options);

	--目标的目标设置菜单
	local UnitFramesPlus_TargetTarget_Options = CreateFrame("Frame", "UnitFramesPlus_TargetTarget_Options", UIParent);
	UnitFramesPlus_TargetTarget_Options.name = ToT_Options;
	UnitFramesPlus_TargetTarget_Options.parent = "UnitFramesPlus";
	UnitFramesPlus_TargetTarget_Options:Hide();
	InterfaceOptions_AddCategory(UnitFramesPlus_TargetTarget_Options);

	--焦点设置菜单
	local UnitFramesPlus_Focus_Options = CreateFrame("Frame", "UnitFramesPlus_Focus_Options", UIParent);
	UnitFramesPlus_Focus_Options.name = Focus_Options;
	UnitFramesPlus_Focus_Options.parent = "UnitFramesPlus";
	UnitFramesPlus_Focus_Options:Hide();
	InterfaceOptions_AddCategory(UnitFramesPlus_Focus_Options);

	--队友设置菜单
	local UnitFramesPlus_Party_Options = CreateFrame("Frame", "UnitFramesPlus_Party_Options", UIParent);
	UnitFramesPlus_Party_Options.name = Party_Options;
	UnitFramesPlus_Party_Options.parent = "UnitFramesPlus";
	UnitFramesPlus_Party_Options:Hide();
	InterfaceOptions_AddCategory(UnitFramesPlus_Party_Options);

	--玩家设定
	local playerconfig = UnitFramesPlus_Player_Options:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	playerconfig:SetPoint("TOPLEFT", 16, -16);
	playerconfig:SetText(Player_Options);

	--精英头像
	local UnitFramesPlus_OptionsFrame_PlayerDragonBorder = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerDragonBorder", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerDragonBorder:SetPoint("TOPLEFT", playerconfig, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorder:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderText:SetText(Player_Dragon);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorder:SetScript("OnClick", function(self)
		if UnitFramesPlusDB["player"]["dragon"] == 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider);
		end
		UnitFramesPlusDB["player"]["dragon"] = 1 - UnitFramesPlusDB["player"]["dragon"];
		UnitFramesPlus_PlayerDragon();
		self:SetChecked(UnitFramesPlusDB["player"]["dragon"]);
	end)

	--精英类型
	local UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider", UnitFramesPlus_Player_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerDragonBorder, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSliderLow:SetText(Player_Elite);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSliderHigh:SetText(Player_Rare);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetMinMaxValues(1,3);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["player"]["raretype"] = value;
		if UnitFramesPlusDB["player"]["dragon"] == 1 then
			if UnitFramesPlusDB["player"]["raretype"] == 1 then
				PlayerTexture = ("Interface\\TargetingFrame\\UI-TargetingFrame-Elite");
			elseif UnitFramesPlusDB["player"]["raretype"] == 2 then
				PlayerTexture = ("Interface\\TargetingFrame\\UI-TargetingFrame-Rare-Elite");
			elseif UnitFramesPlusDB["player"]["raretype"] == 3 then
				PlayerTexture = ("Interface\\TargetingFrame\\UI-TargetingFrame-Rare");
			end
			PlayerFrameTexture:SetTexture(PlayerTexture);
		end
	end)

	--扩展框
	local UnitFramesPlus_OptionsFrame_PlayerExtbar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerExtbar", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerExtbar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerDragonBorder, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_PlayerExtbar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerExtbarText:SetText(Player_Extbar);
	UnitFramesPlus_OptionsFrame_PlayerExtbar:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["extbar"] = 1 - UnitFramesPlusDB["player"]["extbar"];
		if UnitFramesPlusDB["player"]["extbar"] == 1 then
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerHPMPPct);
			UnitFramesPlusDB["player"]["hpmp"] = 1;
			UnitFramesPlus_OptionsFrame_PlayerHPMPPct:SetChecked(UnitFramesPlusDB["player"]["hpmp"]);
			UIDropDownMenu_EnableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne);
			UIDropDownMenu_EnableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PlayerHPMPUnit);
			UnitFramesPlus_OptionsFrame_PlayerHPMPUnitText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PlayerCoordinate);
			UnitFramesPlus_OptionsFrame_PlayerCoordinateText:SetTextColor(1, 1, 1);
		else
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PlayerHPMPPct);
			UnitFramesPlus_OptionsFrame_PlayerHPMPPctText:SetTextColor(1, 1, 1);
		end
		UnitFramesPlus_PlayerExtbar();
		self:SetChecked(UnitFramesPlusDB["player"]["extbar"]);
	end)

	--玩家坐标
	local UnitFramesPlus_OptionsFrame_PlayerCoordinate = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerCoordinate", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerCoordinate:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerExtbar, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_PlayerCoordinate:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerCoordinateText:SetText(Player_Coordinate);
	UnitFramesPlus_OptionsFrame_PlayerCoordinate:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["coord"] = 1 - UnitFramesPlusDB["player"]["coord"];
		UnitFramesPlus_PlayerCoordinate();
		UnitFramesPlus_PlayerHPValueDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["player"]["coord"]);
	end)

	--不显示扩展框时的生命值和法力值(百分比)
	local UnitFramesPlus_OptionsFrame_PlayerHPMPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerHPMPPct", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerHPMPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerExtbar, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctText:SetText(Player_HPMP);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["hpmp"] = 1 - UnitFramesPlusDB["player"]["hpmp"];
		if UnitFramesPlusDB["player"]["hpmp"] == 1 then
			UIDropDownMenu_EnableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne);
			UIDropDownMenu_EnableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PlayerHPMPUnit);
			UnitFramesPlus_OptionsFrame_PlayerHPMPUnitText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PlayerCoordinate);
			UnitFramesPlus_OptionsFrame_PlayerCoordinateText:SetTextColor(1, 1, 1);
		else
			UIDropDownMenu_DisableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne);
			UIDropDownMenu_DisableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo);
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerHPMPUnit);
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerCoordinate);
		end
		UnitFramesPlus_PlayerHPMPPct();
		self:SetChecked(UnitFramesPlusDB["player"]["hpmp"]);
	end)

	--生命值/法力值/百分比第一部分
	local UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne", UnitFramesPlus_Player_Options, "UIDropDownMenuTemplate");
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerHPMPPct, "TOPLEFT", 165, 0);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne:SetHitRectInsets(0, -100, 0, 0);
	UIDropDownMenu_SetWidth(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne,80);
	UIDropDownMenu_Initialize(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne, PlayerHPMPPctPartOne_Init);
	UIDropDownMenu_SetSelectedID(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne, UnitFramesPlusDB["player"]["hpmppartone"]);

	--斜线
	local splitline = UnitFramesPlus_Player_Options:CreateFontString(nil, "ARTWORK", "TextStatusBarText");
	splitline:SetPoint("LEFT", UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne, "RIGHT", -5, 0);
	splitline:SetText("/");

	--生命值/法力值/百分比第二部分
	local UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo", UnitFramesPlus_Player_Options, "UIDropDownMenuTemplate");
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo:SetPoint("LEFT", splitline, "RIGHT", -11, 0);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo:SetHitRectInsets(0, -100, 0, 0);
	UIDropDownMenu_SetWidth(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo,80);
	UIDropDownMenu_Initialize(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo, PlayerHPMPPctPartTwo_Init);
	UIDropDownMenu_SetSelectedID(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo, UnitFramesPlusDB["player"]["hpmpparttwo"]);

	--生命值、法力值单位
	local UnitFramesPlus_OptionsFrame_PlayerHPMPUnit = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerHPMPUnit", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerHPMPUnit:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerHPMPPct, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerHPMPUnit:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerHPMPUnitText:SetText(Player_UnitK);
	UnitFramesPlus_OptionsFrame_PlayerHPMPUnit:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["unit"] = 1 - UnitFramesPlusDB["player"]["unit"];
		UnitFramesPlus_PlayerHPValueDisplayUpdate();
		UnitFramesPlus_PlayerMPValueDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["player"]["unit"]);
	end)

	--系统状态条显示
	local UnitFramesPlus_OptionsFrame_PlayerOnBar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerOnBar", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerOnBar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerHPMPUnit, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerOnBar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerOnBarText:SetText(Player_OnBar);
	UnitFramesPlus_OptionsFrame_PlayerOnBar:SetScript("OnClick", function(self)
		InterfaceOptionsFrame_OpenToCategory(InterfaceOptionsStatusTextPanel);
		self:SetChecked(0);
	end)

	--玩家3D头像
	local UnitFramesPlus_OptionsFrame_Player3DPortrait = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_Player3DPortrait", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_Player3DPortrait:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerOnBar, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_Player3DPortrait:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_Player3DPortraitText:SetText(Portrait_3D);
	UnitFramesPlus_OptionsFrame_Player3DPortrait:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["p3d"] = 1 - UnitFramesPlusDB["player"]["p3d"];
		UnitFramesPlus_Player3DPortrait();
		if UnitFramesPlusDB["player"]["p3d"] == 1 then
			UnitFramesPlus_Player3DPortraitDisplayUpdate();
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_Player3DPortraitBG);
			UnitFramesPlus_OptionsFrame_Player3DPortraitBGText:SetTextColor(1, 1, 1);
		else
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_Player3DPortraitBG);
		end
		self:SetChecked(UnitFramesPlusDB["player"]["p3d"]);
	end)

	--玩家3D头像背景
	local UnitFramesPlus_OptionsFrame_Player3DPortraitBG = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_Player3DPortraitBG", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_Player3DPortraitBG:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_Player3DPortrait, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_Player3DPortraitBG:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_Player3DPortraitBGText:SetText(Portrait_3DBG);
	UnitFramesPlus_OptionsFrame_Player3DPortraitBG:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["p3dbg"] = 1 - UnitFramesPlusDB["player"]["p3dbg"];
		UnitFramesPlus_Player3DPortraitBGDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["player"]["p3dbg"]);
	end)

	--Shift拖动头像
	local UnitFramesPlus_OptionsFrame_PlayerShiftDrag = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerShiftDrag", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerShiftDrag:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_Player3DPortrait, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerShiftDrag:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerShiftDragText:SetText(Shift_Movable);
	UnitFramesPlus_OptionsFrame_PlayerShiftDrag:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["movable"] = 1 - UnitFramesPlusDB["player"]["movable"];
		self:SetChecked(UnitFramesPlusDB["player"]["movable"]);
	end)

	--Shift拖动资源条
	local UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerShiftDrag, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDragText:SetText(PlusBar_ShiftMovable);
	UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["barmovable"] = 1 - UnitFramesPlusDB["player"]["barmovable"];
		if UnitFramesPlusDB["player"]["barmovable"] == 0 then
			UnitFramesPlusVar["player"]["barposition"] = {};
		end
		self:SetChecked(UnitFramesPlusDB["player"]["barmovable"]);
	end)

	--玩家头像内战斗信息
	local UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerPortraitIndicatorText:SetText(Portrait_Indicator);
	UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["indicator"] = 1 - UnitFramesPlusDB["player"]["indicator"];
		UnitFramesPlus_PlayerPortraitIndicator();
		self:SetChecked(UnitFramesPlusDB["player"]["indicator"]);
	end)

	--玩家头像自动隐藏
	local UnitFramesPlus_OptionsFrame_PlayerFrameAutohide = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerFrameAutohide", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerFrameAutohide:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerFrameAutohide:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerFrameAutohideText:SetText(Player_Autohide);
	UnitFramesPlus_OptionsFrame_PlayerFrameAutohide:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["autohide"] = 1 - UnitFramesPlusDB["player"]["autohide"];
		UnitFramesPlus_PlayerFrameAutohide();
		UnitFramesPlus_PlayerFrameAutohideDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["player"]["autohide"]);
	end)

	--生命条染色
	local UnitFramesPlus_OptionsFrame_PlayerColorHP = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerColorHP", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerColorHP:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerFrameAutohide, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PlayerColorHP:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerColorHPText:SetText(ColorHP_Text);
	UnitFramesPlus_OptionsFrame_PlayerColorHP:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["colorhp"] = 1 - UnitFramesPlusDB["player"]["colorhp"];
		if UnitFramesPlusDB["player"]["colorhp"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PlayerColorHPSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_PlayerColorHPSlider);
		end
		UnitFramesPlus_PlayerColorHPBar();
		UnitFramesPlus_PlayerColorHPBarDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["player"]["colorhp"]);
	end)

	--生命条染色类型
	local UnitFramesPlus_OptionsFrame_PlayerColorHPSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PlayerColorHPSlider", UnitFramesPlus_Player_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerColorHP, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSliderLow:SetText(ColorHP_Class);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSliderHigh:SetText(ColorHP_HPPct);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetMinMaxValues(1,2);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["player"]["colortype"] = value;
		UnitFramesPlus_PlayerColorHPBar();
		UnitFramesPlus_PlayerColorHPBarDisplayUpdate();
	end)

	--头像缩放
	local UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider", UnitFramesPlus_Player_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerColorHP, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSliderText:SetText(Player_Scale..(UnitFramesPlusDB["player"]["scale"]*100).."%");
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlus_PlayerFrameScale(UnitFramesPlusDB["player"]["scale"], value/100);
		UnitFramesPlusDB["player"]["scale"] = value/100;
		if UnitFramesPlusDB["player"]["p3d"] == 1 then
			UnitFramesPlus_Player3DPortraitDisplayUpdate();
		end
		UnitFramesPlus_OptionsFrame_PlayerFrameScaleSliderText:SetText(Player_Scale..(UnitFramesPlusDB["player"]["scale"]*100).."%");
	end)

	--宠物目标
	local UnitFramesPlus_OptionsFrame_PlayerPetTarget = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerPetTarget", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerPetTarget:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider, "TOPLEFT", -30, -40);
	UnitFramesPlus_OptionsFrame_PlayerPetTarget:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetText:SetText(Player_PetTarget);
	UnitFramesPlus_OptionsFrame_PlayerPetTarget:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["pettarget"] = 1 - UnitFramesPlusDB["player"]["pettarget"];	
		if UnitFramesPlusDB["player"]["pettarget"] == 1 then
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct);
			UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPctText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider);
			UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSliderText:SetTextColor(1, 1, 1);
		else
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct);
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider);
		end
		UnitFramesPlus_PetTarget();
		self:SetChecked(UnitFramesPlusDB["player"]["pettarget"]);
	end)

	--宠物目标生命值百分比
	local UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct", UnitFramesPlus_Player_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerPetTarget, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPctText:SetText(Player_PetHPPct);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["player"]["pthppct"] = 1 - UnitFramesPlusDB["player"]["pthppct"];
		self:SetChecked(UnitFramesPlusDB["player"]["pthppct"]);
	end)

	--宠物目标缩放
	local UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider", UnitFramesPlus_Player_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PlayerPetTarget, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSliderText:SetText(Player_PetScale..(UnitFramesPlusDB["player"]["ptscale"]*100).."%");
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlus_PetTargetScale(UnitFramesPlusDB["player"]["ptscale"], value/100);
		UnitFramesPlusDB["player"]["ptscale"] = value/100;
		UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSliderText:SetText(Player_PetScale..(UnitFramesPlusDB["player"]["ptscale"]*100).."%");
	end)

	--目标设定
	local targetconfig = UnitFramesPlus_Target_Options:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	targetconfig:SetPoint("TOPLEFT", 16, -16);
	targetconfig:SetText(Target_Options);

	--目标生命/法力数值
	local UnitFramesPlus_OptionsFrame_TargetStatustext = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetStatustext", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetStatustext:SetPoint("TOPLEFT", targetconfig, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_TargetStatustext:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetStatustextText:SetText(Target_HPMP);
	UnitFramesPlus_OptionsFrame_TargetStatustext:SetScript("OnClick", function(self)
		InterfaceOptionsStatusTextPanelTarget:Click();
		UnitFramesPlusDB["target"]["statustext"] = tonumber(GetCVar("targetStatusText"));
		UnitFramesPlus_OptionsFrame_FocusStatustext:SetChecked(GetCVar("targetStatusText"));
		self:SetChecked(GetCVar("targetStatusText"));
	end)

	--系统状态条显示
	local UnitFramesPlus_OptionsFrame_TargetOnBar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetOnBar", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetOnBar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetStatustext, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetOnBar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetOnBarText:SetText(Player_OnBar);
	UnitFramesPlus_OptionsFrame_TargetOnBar:SetScript("OnClick", function(self)
		InterfaceOptionsFrame_OpenToCategory(InterfaceOptionsStatusTextPanel);
		self:SetChecked(0);
	end)

	--目标生命值百分比
	local UnitFramesPlus_OptionsFrame_TargetHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetHPPct", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetStatustext, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetHPPctText:SetText(HPPct_Text);
	UnitFramesPlus_OptionsFrame_TargetHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["hppct"] = 1 - UnitFramesPlusDB["target"]["hppct"];
		UnitFramesPlus_TargetHealthPct();
		UnitFramesPlus_TargetHealthPctDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["target"]["hppct"]);
	end)

	--目标法力值百分比
	local UnitFramesPlus_OptionsFrame_TargetMPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetMPPct", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetMPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetHPPct, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetMPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetMPPctText:SetText(MPPct_Text);
	UnitFramesPlus_OptionsFrame_TargetMPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["mppct"] = 1 - UnitFramesPlusDB["target"]["mppct"];
		UnitFramesPlus_TargetManaPct();
		UnitFramesPlus_TargetManaPctDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["target"]["mppct"]);
	end)

	--目标职业按钮
	local UnitFramesPlus_OptionsFrame_TargetClassIcon = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetClassIcon", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetClassIcon:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetHPPct, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetClassIcon:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetClassIconText:SetText(ClassIcon_Text);
	UnitFramesPlus_OptionsFrame_TargetClassIcon:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["classicon"] = 1 - UnitFramesPlusDB["target"]["classicon"];
		if UnitFramesPlusDB["target"]["classicon"] ~= 1 then
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetClassIconMore);
		else
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_TargetClassIconMore);
			UnitFramesPlus_OptionsFrame_TargetClassIconMoreText:SetTextColor(1, 1, 1);
		end
		UnitFramesPlus_TargetClassIcon();
		UnitFramesPlus_TargetClassIconDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["target"]["classicon"]);
	end)

	--职业图标左键观察，右键交易，中键密语，4键跟随
	local UnitFramesPlus_OptionsFrame_TargetClassIconMore = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetClassIconMore", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetClassIconMore:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetClassIcon, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetClassIconMore:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetClassIconMoreText:SetText(ClassIcon_MoreAction);
	UnitFramesPlus_OptionsFrame_TargetClassIconMore:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["moreaction"] = 1 - UnitFramesPlusDB["target"]["moreaction"];
		self:SetChecked(UnitFramesPlusDB["target"]["moreaction"]);
	end)

	--目标种族或类型
	local UnitFramesPlus_OptionsFrame_TargetRace = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetRace", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetRace:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetClassIcon, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetRace:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetRaceText:SetText(Race_Text);
	UnitFramesPlus_OptionsFrame_TargetRace:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["race"] = 1 - UnitFramesPlusDB["target"]["race"];
		UnitFramesPlus_TargetRace();
		UnitFramesPlus_TargetRaceDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["target"]["race"]);
	end)

	--目标3D头像
	local UnitFramesPlus_OptionsFrame_Target3DPortrait = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_Target3DPortrait", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_Target3DPortrait:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetRace, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_Target3DPortrait:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_Target3DPortraitText:SetText(Portrait_3D);
	UnitFramesPlus_OptionsFrame_Target3DPortrait:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["p3d"] = 1 - UnitFramesPlusDB["target"]["p3d"];
		UnitFramesPlus_Target3DPortrait();
		if UnitFramesPlusDB["target"]["p3d"] == 1 then
			UnitFramesPlus_Target3DPortraitDisplayUpdate();
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_Target3DPortraitBG);
			UnitFramesPlus_OptionsFrame_Target3DPortraitBGText:SetTextColor(1, 1, 1);
		else
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_Target3DPortraitBG);
		end
		self:SetChecked(UnitFramesPlusDB["target"]["p3d"]);
	end)

	--目标3D头像背景
	local UnitFramesPlus_OptionsFrame_Target3DPortraitBG = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_Target3DPortraitBG", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_Target3DPortraitBG:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_Target3DPortrait, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_Target3DPortraitBG:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_Target3DPortraitBGText:SetText(Portrait_3DBG);
	UnitFramesPlus_OptionsFrame_Target3DPortraitBG:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["p3dbg"] = 1 - UnitFramesPlusDB["target"]["p3dbg"];
		UnitFramesPlus_Target3DPortraitBGDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["target"]["p3dbg"]);
	end)

	--Shift拖动头像
	local UnitFramesPlus_OptionsFrame_TargetShiftDrag = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetShiftDrag", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetShiftDrag:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_Target3DPortrait, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetShiftDrag:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetShiftDragText:SetText(Shift_Movable);
	UnitFramesPlus_OptionsFrame_TargetShiftDrag:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["movable"] = 1 - UnitFramesPlusDB["target"]["movable"];
		self:SetChecked(UnitFramesPlusDB["target"]["movable"]);
	end)

	--目标头像内战斗信息
	local UnitFramesPlus_OptionsFrame_TargetPortraitIndicator = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetPortraitIndicator", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetPortraitIndicator:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetShiftDrag, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetPortraitIndicator:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetPortraitIndicatorText:SetText(Portrait_Indicator);
	UnitFramesPlus_OptionsFrame_TargetPortraitIndicator:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["indicator"] = 1 - UnitFramesPlusDB["target"]["indicator"];
		UnitFramesPlus_TargetPortraitIndicator();
		self:SetChecked(UnitFramesPlusDB["target"]["indicator"]);
	end)

	--目标施法条
	local UnitFramesPlus_OptionsFrame_TargetCastBar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetCastBar", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetCastBar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetPortraitIndicator, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetCastBar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetCastBarText:SetText(Target_Bastbar);
	UnitFramesPlus_OptionsFrame_TargetCastBar:SetScript("OnClick", function(self)
		InterfaceOptionsCombatPanelEnemyCastBarsOnPortrait:Click();
		self:SetChecked(GetCVar("showTargetCastbar"));
		UnitFramesPlus_OptionsFrame_TargetCastBar:SetChecked(GetCVar("showTargetCastbar"));
	end)

	--目标生命条染色
	local UnitFramesPlus_OptionsFrame_TargetColorHP = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetColorHP", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetColorHP:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetCastBar, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetColorHP:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetColorHPText:SetText(ColorHP_Text);
	UnitFramesPlus_OptionsFrame_TargetColorHP:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["colorhp"] = 1 - UnitFramesPlusDB["target"]["colorhp"];
		if UnitFramesPlusDB["target"]["colorhp"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetColorHPSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_TargetColorHPSlider);
		end
		UnitFramesPlus_TargetColorHPBar();
		UnitFramesPlus_TargetColorHPBarDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["target"]["colorhp"]);
	end)

	--生命条染色类型
	local UnitFramesPlus_OptionsFrame_TargetColorHPSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_TargetColorHPSlider", UnitFramesPlus_Target_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetColorHP, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetColorHPSliderLow:SetText(ColorHP_Class);
	UnitFramesPlus_OptionsFrame_TargetColorHPSliderHigh:SetText(ColorHP_HPPct);
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetMinMaxValues(1,2);
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["target"]["colortype"] = value;
		UnitFramesPlus_TargetColorHPBar();
		UnitFramesPlus_TargetColorHPBarDisplayUpdate();
	end)

	--调节目标buff/debuff图标大小
	local UnitFramesPlus_OptionsFrame_TargetBuffSize = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetBuffSize", UnitFramesPlus_Target_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetBuffSize:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetColorHP, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetBuffSize:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeText:SetText(Target_BuffSize);
	UnitFramesPlus_OptionsFrame_TargetBuffSize:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["buffsize"] = 1 - UnitFramesPlusDB["target"]["buffsize"];
		if UnitFramesPlusDB["target"]["buffsize"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider);
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider);
			UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSliderText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider);
			UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSliderText:SetTextColor(1, 1, 1);
		end
		self:SetChecked(UnitFramesPlusDB["target"]["buffsize"]);
	end)

	--自己施放的buff/debuff大小
	local UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider", UnitFramesPlus_Target_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetBuffSize, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSliderText:SetText(Target_MySize..UnitFramesPlusDB["target"]["mysize"]);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSliderLow:SetText("8");
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSliderHigh:SetText("32");
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetMinMaxValues(8,32);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["target"]["mysize"] = value;
		UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSliderText:SetText(Target_MySize..UnitFramesPlusDB["target"]["mysize"]);
	end)

	--其他人施放的buff/debuff大小
	local UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider", UnitFramesPlus_Target_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider, "TOPLEFT", 150, 0);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSliderText:SetText(Target_OtherSize..UnitFramesPlusDB["target"]["othersize"]);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSliderLow:SetText("8");
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSliderHigh:SetText("32");
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetMinMaxValues(8,32);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["target"]["othersize"] = value;
		UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSliderText:SetText(Target_OtherSize..UnitFramesPlusDB["target"]["othersize"]);
	end)

	--头像缩放
	local UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider", UnitFramesPlus_Target_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider, "TOPLEFT", 0, -50);
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSliderText:SetText(Target_Scale..(UnitFramesPlusDB["target"]["scale"]*100).."%");
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlus_TargetFrameScale(UnitFramesPlusDB["target"]["scale"], value/100);
		UnitFramesPlusDB["target"]["scale"] = value/100;
		if UnitFramesPlusDB["target"]["p3d"] == 1 then
			UnitFramesPlus_Target3DPortraitDisplayUpdate();
		end
		UnitFramesPlus_OptionsFrame_TargetFrameScaleSliderText:SetText(Target_Scale..(UnitFramesPlusDB["target"]["scale"]*100).."%");
	end)

	--目标的目标设定
	local totconfig = UnitFramesPlus_TargetTarget_Options:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	totconfig:SetPoint("TOPLEFT", 16, -16);
	totconfig:SetText(ToT_Options);

	--系统ToT状态
	local UnitFramesPlus_OptionsFrame_TargetSYSToT = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetSYSToT", UnitFramesPlus_TargetTarget_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetSYSToT:SetPoint("TOPLEFT", totconfig, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_TargetSYSToT:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetSYSToTText:SetText(Target_SYSToT);
	UnitFramesPlus_OptionsFrame_TargetSYSToT:SetScript("OnClick", function(self)
		InterfaceOptionsFrame_OpenToCategory(InterfaceOptionsCombatPanel);
		self:SetChecked(GetCVar("showTargetOfTarget"));
	end)

	--在进入游戏时自动关闭系统目标的目标
	local UnitFramesPlus_OptionsFrame_TargetAutoToT = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetAutoToT", UnitFramesPlus_TargetTarget_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetAutoToT:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetSYSToT, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetAutoToT:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetAutoToTText:SetText(Target_AutoToT);
	UnitFramesPlus_OptionsFrame_TargetAutoToT:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["autotot"] = 1 -UnitFramesPlusDB["target"]["autotot"];
		self:SetChecked(UnitFramesPlusDB["target"]["autotot"]);
	end)

	--目标的目标
	local UnitFramesPlus_OptionsFrame_TargetToT = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetToT", UnitFramesPlus_TargetTarget_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetToT:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetSYSToT, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetToT:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetToTText:SetText(Target_ToT);
	UnitFramesPlus_OptionsFrame_TargetToT:SetScript("OnClick", function(self)
		if UnitFramesPlusDB["target"]["tot"] == 1 then
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetToToT);
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetToTDebuff);
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetToTScaleSlider);
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetToTHPPct);
		else
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_TargetToToT);
			UnitFramesPlus_OptionsFrame_TargetToToTText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_TargetToTDebuff);
			UnitFramesPlus_OptionsFrame_TargetToTDebuffText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_TargetToTScaleSlider);
			UnitFramesPlus_OptionsFrame_TargetToTScaleSliderText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_TargetToTHPPct);
			UnitFramesPlus_OptionsFrame_TargetToTHPPctText:SetTextColor(1, 1, 1);
		end
		UnitFramesPlusDB["target"]["tot"] = 1 - UnitFramesPlusDB["target"]["tot"];
		UnitFramesPlus_TargetTarget();
		UnitFramesPlus_TargetTargetTarget();
		self:SetChecked(UnitFramesPlusDB["target"]["tot"]);
	end)

	--目标的目标的目标
	local UnitFramesPlus_OptionsFrame_TargetToToT = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetToToT", UnitFramesPlus_TargetTarget_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetToToT:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetToT, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetToToT:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetToToTText:SetText(Target_ToToT);
	UnitFramesPlus_OptionsFrame_TargetToToT:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["totot"] = 1 - UnitFramesPlusDB["target"]["totot"];
		UnitFramesPlus_TargetTargetTarget();
		self:SetChecked(UnitFramesPlusDB["target"]["totot"]);
	end)

	--目标的目标debuff
	local UnitFramesPlus_OptionsFrame_TargetToTDebuff = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetToTDebuff", UnitFramesPlus_TargetTarget_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetToTDebuff:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetToT, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_TargetToTDebuff:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetToTDebuffText:SetText(Target_Debuff);
	UnitFramesPlus_OptionsFrame_TargetToTDebuff:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["debuff"] = 1 - UnitFramesPlusDB["target"]["debuff"];
		UnitFramesPlus_TargetTargetDebuff();
		self:SetChecked(UnitFramesPlusDB["target"]["debuff"]);
	end)

	--目标的目标生命值百分比
	local UnitFramesPlus_OptionsFrame_TargetToTHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_TargetToTHPPct", UnitFramesPlus_TargetTarget_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_TargetToTHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetToTDebuff, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_TargetToTHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_TargetToTHPPctText:SetText(Target_ToTHPPct);
	UnitFramesPlus_OptionsFrame_TargetToTHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["target"]["tothppct"] = 1 - UnitFramesPlusDB["target"]["tothppct"];
		self:SetChecked(UnitFramesPlusDB["target"]["tothppct"]);
	end)

	--目标的目标缩放
	local UnitFramesPlus_OptionsFrame_TargetToTScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_TargetToTScaleSlider", UnitFramesPlus_TargetTarget_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_TargetToTDebuff, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_TargetToTScaleSliderText:SetText(Target_ToTScale..(UnitFramesPlusDB["target"]["tscale"]*100).."%");
	UnitFramesPlus_OptionsFrame_TargetToTScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_TargetToTScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlus_TargetTargetScale(UnitFramesPlusDB["target"]["tscale"], value/100);
		UnitFramesPlusDB["target"]["tscale"] = value/100;
		UnitFramesPlus_OptionsFrame_TargetToTScaleSliderText:SetText(Target_ToTScale..(UnitFramesPlusDB["target"]["tscale"]*100).."%");
	end)

	--焦点设定
	local focusconfig = UnitFramesPlus_Focus_Options:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	focusconfig:SetPoint("TOPLEFT", 16, -16);
	focusconfig:SetText(Focus_Options);

	--目标生命/法力数值
	local UnitFramesPlus_OptionsFrame_FocusStatustext = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusStatustext", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusStatustext:SetPoint("TOPLEFT", focusconfig, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_FocusStatustext:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusStatustextText:SetText(Target_HPMP);
	UnitFramesPlus_OptionsFrame_FocusStatustext:SetScript("OnClick", function(self)
		InterfaceOptionsStatusTextPanelTarget:Click();
		UnitFramesPlusDB["target"]["statustext"] = tonumber(GetCVar("targetStatusText"));
		UnitFramesPlus_OptionsFrame_TargetStatustext:SetChecked(GetCVar("targetStatusText"));
		self:SetChecked(GetCVar("targetStatusText"));
	end)

	--系统状态条显示
	local UnitFramesPlus_OptionsFrame_FocusOnBar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusOnBar", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusOnBar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusStatustext, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_FocusOnBar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusOnBarText:SetText(Player_OnBar);
	UnitFramesPlus_OptionsFrame_FocusOnBar:SetScript("OnClick", function(self)
		InterfaceOptionsFrame_OpenToCategory(InterfaceOptionsStatusTextPanel);
		self:SetChecked(0);
	end)

	--显示扩大焦点框架
	local UnitFramesPlus_OptionsFrame_FocusFullsize = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusFullsize", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusFullsize:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusStatustext, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusFullsize:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusFullsizeText:SetText(Focus_BigFocus);
	UnitFramesPlus_OptionsFrame_FocusFullsize:SetScript("OnClick", function(self)
		if UnitFramesPlusDB["focus"]["fullsize"] == 1 then
			UnitFramesPlus_FocusFrameScale(UnitFramesPlusDB["focus"]["scale"], 1);
		end
		InterfaceOptionsUnitFramePanelFullSizeFocusFrame:Click();
		UnitFramesPlusDB["focus"]["fullsize"] = tonumber(GetCVar("fullSizeFocusFrame"));
		if UnitFramesPlusDB["focus"]["p3d"] == 1 then
			UnitFramesPlus_Focus3DPortraitDisplayUpdate();
			UnitFramesPlus_Focus3DPortraitBGDisplayUpdate();
		end
		if UnitFramesPlusDB["focus"]["fullsize"] == 1 then
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider);
			UnitFramesPlusDB["focus"]["scale"] = 1;
			UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetValue(UnitFramesPlusDB["focus"]["scale"]*100);
			UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderText:SetText(Focus_Scale..(UnitFramesPlusDB["focus"]["scale"]*100).."%");
			UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderText:SetTextColor(1, 1, 1);
		else
			UnitFramesPlusDB["focus"]["scale"] = 0.75;
			UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetValue(UnitFramesPlusDB["focus"]["scale"]*100);
			UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderText:SetText(Focus_Scale..(UnitFramesPlusDB["focus"]["scale"]*100).."%");
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider);
		end
		self:SetChecked(GetCVar("fullSizeFocusFrame"));
	end)

	--头像缩放
	local UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider", UnitFramesPlus_Focus_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusFullsize, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderText:SetText(Focus_Scale..(UnitFramesPlusDB["focus"]["scale"]*100).."%");
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlus_FocusFrameScale(UnitFramesPlusDB["focus"]["scale"], value/100);
		UnitFramesPlusDB["focus"]["scale"] = value/100;
		if UnitFramesPlusDB["focus"]["p3d"] == 1 then
			UnitFramesPlus_Focus3DPortraitDisplayUpdate();
		end
		UnitFramesPlus_OptionsFrame_FocusFrameScaleSliderText:SetText(Focus_Scale..(UnitFramesPlusDB["focus"]["scale"]*100).."%");
	end)

	--快速焦点
	local UnitFramesPlus_OptionsFrame_FocusQuick = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusQuick", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusQuick:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider, "TOPLEFT", -30, -40);
	UnitFramesPlus_OptionsFrame_FocusQuick:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusQuickText:SetText(Focus_QuickFocus);
	UnitFramesPlus_OptionsFrame_FocusQuick:SetScript("OnClick", function(self)
		if UnitFramesPlusDB["focus"]["quick"] == 1 then
			UIDropDownMenu_DisableDropDown(UnitFramesPlus_OptionsFrame_FocusQuickDropDown);
		else
			UIDropDownMenu_EnableDropDown(UnitFramesPlus_OptionsFrame_FocusQuickDropDown);
		end
		UnitFramesPlusDB["focus"]["quick"] = 1 - UnitFramesPlusDB["focus"]["quick"];
		UnitFramesPlus_FocusQuick();
		self:SetChecked(UnitFramesPlusDB["focus"]["quick"]);
	end)

	--快速焦点快捷键
	local UnitFramesPlus_OptionsFrame_FocusQuickDropDown = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusQuickDropDown", UnitFramesPlus_Focus_Options, "UIDropDownMenuTemplate");
	UnitFramesPlus_OptionsFrame_FocusQuickDropDown:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusQuick, "TOPLEFT", 165, 0);
	UnitFramesPlus_OptionsFrame_FocusQuickDropDown:SetHitRectInsets(0, -100, 0, 0);
	UIDropDownMenu_SetWidth(UnitFramesPlus_OptionsFrame_FocusQuickDropDown,80);
	UIDropDownMenu_Initialize(UnitFramesPlus_OptionsFrame_FocusQuickDropDown, QuickFocus_Init);
	UIDropDownMenu_SetSelectedID(UnitFramesPlus_OptionsFrame_FocusQuickDropDown, UnitFramesPlusDB["focus"]["button"]);

	--焦点生命值百分比
	local UnitFramesPlus_OptionsFrame_FocusHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusHPPct", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusQuick, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusHPPctText:SetText(HPPct_Text);
	UnitFramesPlus_OptionsFrame_FocusHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["hppct"] = 1 - UnitFramesPlusDB["focus"]["hppct"];
		UnitFramesPlus_FocusHealthPct();
		UnitFramesPlus_FocusHealthPctDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["focus"]["hppct"]);
	end)

	--焦点法力值百分比
	local UnitFramesPlus_OptionsFrame_FocusMPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusMPPct", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusMPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusHPPct, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_FocusMPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusMPPctText:SetText(MPPct_Text);
	UnitFramesPlus_OptionsFrame_FocusMPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["mppct"] = 1 - UnitFramesPlusDB["focus"]["mppct"];
		UnitFramesPlus_FocusManaPct();
		UnitFramesPlus_FocusManaPctDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["focus"]["mppct"]);
	end)

	--焦点职业图标
	local UnitFramesPlus_OptionsFrame_FocusClassIcon = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusClassIcon", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusClassIcon:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusHPPct, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusClassIcon:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusClassIconText:SetText(ClassIcon_Text);
	UnitFramesPlus_OptionsFrame_FocusClassIcon:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["classicon"] = 1 - UnitFramesPlusDB["focus"]["classicon"];
		if UnitFramesPlusDB["focus"]["classicon"] ~= 1 then
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_FocusClassIconMore);
		else
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_FocusClassIconMore);
			UnitFramesPlus_OptionsFrame_FocusClassIconMoreText:SetTextColor(1, 1, 1);
		end
		UnitFramesPlus_FocusClassIcon();
		UnitFramesPlus_FocusClassIconDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["focus"]["classicon"]);
	end)

	--职业图标左键观察，右键交易，中键密语，4键跟随
	local UnitFramesPlus_OptionsFrame_FocusClassIconMore = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusClassIconMore", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusClassIconMore:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusClassIcon, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_FocusClassIconMore:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusClassIconMoreText:SetText(ClassIcon_MoreAction);
	UnitFramesPlus_OptionsFrame_FocusClassIconMore:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["moreaction"] = 1 - UnitFramesPlusDB["focus"]["moreaction"];
		self:SetChecked(UnitFramesPlusDB["focus"]["moreaction"]);
	end)

	--焦点种族或类型
	local UnitFramesPlus_OptionsFrame_FocusRace = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusRace", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusRace:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusClassIcon, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusRace:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusRaceText:SetText(Race_Text);
	UnitFramesPlus_OptionsFrame_FocusRace:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["race"] = 1 - UnitFramesPlusDB["focus"]["race"];
		UnitFramesPlus_FocusRace();
		UnitFramesPlus_FocusRaceDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["focus"]["race"]);
	end)

	--焦点3D头像
	local UnitFramesPlus_OptionsFrame_Focus3DPortrait = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_Focus3DPortrait", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_Focus3DPortrait:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusRace, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_Focus3DPortrait:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_Focus3DPortraitText:SetText(Portrait_3D);
	UnitFramesPlus_OptionsFrame_Focus3DPortrait:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["p3d"] = 1 - UnitFramesPlusDB["focus"]["p3d"];
		UnitFramesPlus_Focus3DPortrait();
		if UnitFramesPlusDB["focus"]["p3d"] == 1 then
			UnitFramesPlus_Focus3DPortraitDisplayUpdate();
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_Focus3DPortraitBG);
			UnitFramesPlus_OptionsFrame_Focus3DPortraitBGText:SetTextColor(1, 1, 1);
		else
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_Focus3DPortraitBG);
		end
		self:SetChecked(UnitFramesPlusDB["focus"]["p3d"]);
	end)

	--焦点3D头像背景
	local UnitFramesPlus_OptionsFrame_Focus3DPortraitBG = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_Focus3DPortraitBG", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_Focus3DPortraitBG:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_Focus3DPortrait, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_Focus3DPortraitBG:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_Focus3DPortraitBGText:SetText(Portrait_3DBG);
	UnitFramesPlus_OptionsFrame_Focus3DPortraitBG:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["p3dbg"] = 1 - UnitFramesPlusDB["focus"]["p3dbg"];
		UnitFramesPlus_Focus3DPortraitBGDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["focus"]["p3dbg"]);
	end)

	--Shift拖动头像
	local UnitFramesPlus_OptionsFrame_FocusShiftDrag = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusShiftDrag", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusShiftDrag:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_Focus3DPortrait, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusShiftDrag:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusShiftDragText:SetText(Shift_Movable);
	UnitFramesPlus_OptionsFrame_FocusShiftDrag:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["movable"] = 1 - UnitFramesPlusDB["focus"]["movable"];
		self:SetChecked(UnitFramesPlusDB["focus"]["movable"]);
	end)

	--焦点头像内战斗信息
	local UnitFramesPlus_OptionsFrame_FocusPortraitIndicator = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusPortraitIndicator", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusPortraitIndicator:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusShiftDrag, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusPortraitIndicator:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusPortraitIndicatorText:SetText(Portrait_Indicator);
	UnitFramesPlus_OptionsFrame_FocusPortraitIndicator:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["indicator"] = 1 - UnitFramesPlusDB["focus"]["indicator"];
		UnitFramesPlus_FocusPortraitIndicator();
		self:SetChecked(UnitFramesPlusDB["focus"]["indicator"]);
	end)

	--焦点施法条
	local UnitFramesPlus_OptionsFrame_FocusCastBar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusCastBar", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusCastBar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusPortraitIndicator, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusCastBar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusCastBarText:SetText(Focus_Bastbar);
	UnitFramesPlus_OptionsFrame_FocusCastBar:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["spellbar"] = 1 - UnitFramesPlusDB["focus"]["spellbar"];
		UnitFramesPlus_FocusSpellbar();
		self:SetChecked(UnitFramesPlusDB["focus"]["spellbar"]);
	end)

	--焦点生命条染色
	local UnitFramesPlus_OptionsFrame_FocusColorHP = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusColorHP", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusColorHP:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusCastBar, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_FocusColorHP:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusColorHPText:SetText(ColorHP_Text);
	UnitFramesPlus_OptionsFrame_FocusColorHP:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["colorhp"] = 1 - UnitFramesPlusDB["focus"]["colorhp"];
		if UnitFramesPlusDB["focus"]["colorhp"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_FocusColorHPSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_FocusColorHPSlider);
		end
		UnitFramesPlus_FocusColorHPBar();
		UnitFramesPlus_FocusColorHPBarDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["focus"]["colorhp"]);
	end)

	--生命条染色类型
	local UnitFramesPlus_OptionsFrame_FocusColorHPSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_FocusColorHPSlider", UnitFramesPlus_Focus_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusColorHP, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_FocusColorHPSliderLow:SetText(ColorHP_Class);
	UnitFramesPlus_OptionsFrame_FocusColorHPSliderHigh:SetText(ColorHP_HPPct);
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetMinMaxValues(1,2);
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["focus"]["colortype"] = value;
		UnitFramesPlus_FocusColorHPBar();
		UnitFramesPlus_FocusColorHPBarDisplayUpdate();
	end)

	--焦点目标
	local UnitFramesPlus_OptionsFrame_FocusToF = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusToF", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusToF:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusColorHP, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_FocusToF:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusToFText:SetText(Focus_ToF);
	UnitFramesPlus_OptionsFrame_FocusToF:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["tof"] = 1 - UnitFramesPlusDB["focus"]["tof"];
		if UnitFramesPlusDB["focus"]["tof"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_FocusToFScaleSlider);
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_FocusToFHPPct);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_FocusToFScaleSlider);
			UnitFramesPlus_OptionsFrame_FocusToFScaleSliderText:SetTextColor(1, 1, 1);
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_FocusToFHPPct);
			UnitFramesPlus_OptionsFrame_FocusToFHPPctText:SetTextColor(1, 1, 1);
		end
		UnitFramesPlus_FocusTarget();
		self:SetChecked(UnitFramesPlusDB["focus"]["tof"]);
	end)

	--焦点目标生命值百分比
	local UnitFramesPlus_OptionsFrame_FocusToFHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_FocusToFHPPct", UnitFramesPlus_Focus_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_FocusToFHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusToF, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_FocusToFHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_FocusToFHPPctText:SetText(Focus_ToFHPPct);
	UnitFramesPlus_OptionsFrame_FocusToFHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["focus"]["tofhppct"] = 1 - UnitFramesPlusDB["focus"]["tofhppct"];
		self:SetChecked(UnitFramesPlusDB["focus"]["tofhppct"]);
	end)

	--焦点目标缩放
	local UnitFramesPlus_OptionsFrame_FocusToFScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_FocusToFScaleSlider", UnitFramesPlus_Focus_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_FocusToF, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_FocusToFScaleSliderText:SetText(Focus_ToFScale..(UnitFramesPlusDB["focus"]["tscale"]*100).."%");
	UnitFramesPlus_OptionsFrame_FocusToFScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_FocusToFScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlus_FocusTargetScale(UnitFramesPlusDB["focus"]["tscale"], value/100);
		UnitFramesPlusDB["focus"]["tscale"] = value/100;
		UnitFramesPlus_OptionsFrame_FocusToFScaleSliderText:SetText(Focus_ToFScale..(UnitFramesPlusDB["focus"]["tscale"]*100).."%");
	end)

	--队伍设定
	local partyconfig = UnitFramesPlus_Party_Options:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	partyconfig:SetPoint("TOPLEFT", 16, -16);
	partyconfig:SetText(Party_Options);

	--队友等级
	local UnitFramesPlus_OptionsFrame_PartyLevel = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyLevel", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyLevel:SetPoint("TOPLEFT", partyconfig, "TOPLEFT", 0, -40);
	UnitFramesPlus_OptionsFrame_PartyLevel:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyLevelText:SetText(Party_Level);
	UnitFramesPlus_OptionsFrame_PartyLevel:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["level"] = 1 - UnitFramesPlusDB["party"]["level"];
		UnitFramesPlus_PartyLevel();
		for id = 1, 4, 1 do
			UnitFramesPlus_PartyLevelDisplayUpdate(id);
		end
		self:SetChecked(UnitFramesPlusDB["party"]["level"]);
	end)

	--队友生命值
	local UnitFramesPlus_OptionsFrame_PartyHP = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyHP", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyHP:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyLevel, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyHP:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyHPText:SetText(Party_HP);
	UnitFramesPlus_OptionsFrame_PartyHP:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["hp"] = 1 - UnitFramesPlusDB["party"]["hp"];
		local xOffset = 151;
		if UnitFramesPlusDB["party"]["hp"] == 1 then
			BlizzardOptionsPanel_CheckButton_Enable(UnitFramesPlus_OptionsFrame_PartyHPPct);
			UnitFramesPlus_OptionsFrame_PartyHPPctText:SetTextColor(1, 1, 1);
			if UnitFramesPlusDB["party"]["hppct"] ~= 1 then
				xOffset = 211;
			end
		else
			BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PartyHPPct);
		end
		for id = 1, 4, 1 do
			_G["PartyTarget"..id]:ClearAllPoints();
			_G["PartyTarget"..id]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "TOPLEFT", xOffset, -8);
			UnitFramesPlus_PartyHealthPctDisplayUpdate(id);
		end
		self:SetChecked(UnitFramesPlusDB["party"]["hp"]);
	end)

	--队友生命值百分比
	local UnitFramesPlus_OptionsFrame_PartyHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyHPPct", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyHP, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_PartyHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyHPPctText:SetText(Party_HPPct);
	UnitFramesPlus_OptionsFrame_PartyHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["hppct"] = 1 - UnitFramesPlusDB["party"]["hppct"];
		local xOffset = 151;
		if UnitFramesPlusDB["party"]["hppct"] ~= 1 then
			xOffset = 211;
		end
		for id = 1, 4, 1 do
			_G["PartyTarget"..id]:ClearAllPoints();
			_G["PartyTarget"..id]:SetPoint("TOPLEFT", _G["PartyMemberFrame"..id], "TOPLEFT", xOffset, -8);
			UnitFramesPlus_PartyHealthPctDisplayUpdate(id);
		end
		self:SetChecked(UnitFramesPlusDB["party"]["hppct"]);
	end)

	--队友名字染色
	local UnitFramesPlus_OptionsFrame_PartyColorName = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyColorName", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyColorName:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyHP, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyColorName:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyColorNameText:SetText(Party_ColorName);
	UnitFramesPlus_OptionsFrame_PartyColorName:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["colorname"] = 1 - UnitFramesPlusDB["party"]["colorname"];
		UnitFramesPlus_PartyColorName();
		for id = 1, 4, 1 do
			UnitFramesPlus_PartyColorNameDisplayUpdate(id);
		end
		self:SetChecked(UnitFramesPlusDB["party"]["colorname"]);
	end)

	--队友离线检测
	local UnitFramesPlus_OptionsFrame_PartyOfflineDetection = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyOfflineDetection", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyOfflineDetection:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyColorName, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyOfflineDetection:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyOfflineDetectionText:SetText(Party_Death);
	UnitFramesPlus_OptionsFrame_PartyOfflineDetection:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["onoff"] = 1 - UnitFramesPlusDB["party"]["onoff"];
		UnitFramesPlus_PartyOfflineDetection();
		UnitFramesPlus_PartyOfflineDetectionDisplayUpdate();
		self:SetChecked(UnitFramesPlusDB["party"]["onoff"]);
	end)

	--队友离线检测
	local UnitFramesPlus_OptionsFrame_PartyDeathGhost = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyDeathGhost", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyDeathGhost:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyOfflineDetection, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyDeathGhost:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyDeathGhostText:SetText(Party_OnOff);
	UnitFramesPlus_OptionsFrame_PartyDeathGhost:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["death"] = 1 - UnitFramesPlusDB["party"]["death"];
		self:SetChecked(UnitFramesPlusDB["party"]["death"]);
	end)

	--Shift拖动头像
	local UnitFramesPlus_OptionsFrame_PartyShiftDrag = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyShiftDrag", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyShiftDrag:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyDeathGhost, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyShiftDrag:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyShiftDragText:SetText(Shift_Movable);
	UnitFramesPlus_OptionsFrame_PartyShiftDrag:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["movable"] = 1 - UnitFramesPlusDB["party"]["movable"];
		self:SetChecked(UnitFramesPlusDB["party"]["movable"]);
	end)

	--队友头像内战斗信息
	local UnitFramesPlus_OptionsFrame_PartyPortraitIndicator = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyPortraitIndicator", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyPortraitIndicator:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyShiftDrag, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyPortraitIndicator:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyPortraitIndicatorText:SetText(Portrait_Indicator);
	UnitFramesPlus_OptionsFrame_PartyPortraitIndicator:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["indicator"] = 1 - UnitFramesPlusDB["party"]["indicator"];
		UnitFramesPlus_PartyPortraitIndicator();
		self:SetChecked(UnitFramesPlusDB["party"]["indicator"]);
	end)

	--队友目标
	local UnitFramesPlus_OptionsFrame_PartyTarget = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyTarget", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyTarget:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyPortraitIndicator, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyTarget:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyTargetText:SetText(Party_Target);
	UnitFramesPlus_OptionsFrame_PartyTarget:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["target"] = 1 - UnitFramesPlusDB["party"]["target"];
		self:SetChecked(UnitFramesPlusDB["party"]["target"]);
	end)

	--队友buff/debuff直接显示
	local UnitFramesPlus_OptionsFrame_PartyBuff = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyBuff", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyBuff:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyTarget, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyBuff:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyBuffText:SetText(Party_Buff);
	UnitFramesPlus_OptionsFrame_PartyBuff:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["buff"] = 1 - UnitFramesPlusDB["party"]["buff"];
		if UnitFramesPlusDB["party"]["buff"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PartyBuffNumSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_PartyBuffNumSlider);
			UnitFramesPlus_OptionsFrame_PartyBuffNumSliderText:SetTextColor(1, 1, 1);
		end
		UnitFramesPlus_PartyBuff();
		self:SetChecked(UnitFramesPlusDB["party"]["buff"]);
	end)

	--队友buff数量
	local UnitFramesPlus_OptionsFrame_PartyBuffNumSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PartyBuffNumSlider", UnitFramesPlus_Party_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyBuff, "TOPLEFT", 165, 0);
	UnitFramesPlus_OptionsFrame_PartyBuffNumSliderText:SetText(Party_BuffNum..UnitFramesPlusDB["party"]["buffnum"]);
	UnitFramesPlus_OptionsFrame_PartyBuffNumSliderLow:SetText("5");
	UnitFramesPlus_OptionsFrame_PartyBuffNumSliderHigh:SetText("15");
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetMinMaxValues(5,15);
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["party"]["buffnum"] = value;
		UnitFramesPlus_PartyBuff()
		UnitFramesPlus_PartyBuffClear();
		UnitFramesPlus_OptionsFrame_PartyBuffNumSliderText:SetText(Party_BuffNum..UnitFramesPlusDB["party"]["buffnum"]);
	end)

	--队友施法条
	local UnitFramesPlus_OptionsFrame_PartySpellbar = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartySpellbar", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartySpellbar:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyBuff, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartySpellbar:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartySpellbarText:SetText(Party_Spellbar);
	UnitFramesPlus_OptionsFrame_PartySpellbar:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["spellbar"] = 1 - UnitFramesPlusDB["party"]["spellbar"];
		UnitFramesPlus_PartySpellbar();
		self:SetChecked(UnitFramesPlusDB["party"]["spellbar"]);
	end)

	--生命条染色
	local UnitFramesPlus_OptionsFrame_PartyColorHP = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_PartyColorHP", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_PartyColorHP:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartySpellbar, "TOPLEFT", 0, -30);
	UnitFramesPlus_OptionsFrame_PartyColorHP:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_PartyColorHPText:SetText(ColorHP_Text);
	UnitFramesPlus_OptionsFrame_PartyColorHP:SetScript("OnClick", function(self)
		UnitFramesPlusDB["party"]["colorhp"] = 1 - UnitFramesPlusDB["party"]["colorhp"];
		if UnitFramesPlusDB["party"]["colorhp"] ~= 1 then
			BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PartyColorHPSlider);
		else
			BlizzardOptionsPanel_Slider_Enable(UnitFramesPlus_OptionsFrame_PartyColorHPSlider);
		end
		UnitFramesPlus_PartyColorHPBar();
		for id = 1, 4, 1 do
			UnitFramesPlus_PartyColorHPBarDisplayUpdate(id);
		end
		self:SetChecked(UnitFramesPlusDB["party"]["colorhp"]);
	end)

	--生命条染色类型
	local UnitFramesPlus_OptionsFrame_PartyColorHPSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PartyColorHPSlider", UnitFramesPlus_Party_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetWidth(80);
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyColorHP, "TOPLEFT", 180, 0);
	UnitFramesPlus_OptionsFrame_PartyColorHPSliderLow:SetText(ColorHP_Class);
	UnitFramesPlus_OptionsFrame_PartyColorHPSliderHigh:SetText(ColorHP_HPPct);
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetMinMaxValues(1,2);
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["party"]["colortype"] = value;
		UnitFramesPlus_PartyColorHPBar();
		for id = 1, 4, 1 do
			UnitFramesPlus_PartyColorHPBarDisplayUpdate(id);
		end
	end)

	--队友头像缩放
	local UnitFramesPlus_OptionsFrame_PartyScaleSlider = CreateFrame("Slider", "UnitFramesPlus_OptionsFrame_PartyScaleSlider", UnitFramesPlus_Party_Options, "OptionsSliderTemplate");
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetWidth(160);
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetHeight(16);
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyColorHP, "TOPLEFT", 30, -50);
	UnitFramesPlus_OptionsFrame_PartyScaleSliderText:SetText(Party_Scale..(UnitFramesPlusDB["party"]["scale"]*100).."%");
	UnitFramesPlus_OptionsFrame_PartyScaleSliderLow:SetText("50%");
	UnitFramesPlus_OptionsFrame_PartyScaleSliderHigh:SetText("150%");
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetMinMaxValues(50,150);
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetValueStep(1);
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetScript("OnValueChanged", function(self, value)
		UnitFramesPlusDB["party"]["scale"] = value/100;
		UnitFramesPlus_PartyScale(UnitFramesPlusDB["party"]["scale"]);
		UnitFramesPlus_OptionsFrame_PartyScaleSliderText:SetText(Party_Scale..(UnitFramesPlusDB["party"]["scale"]*100).."%");
	end)

	--BOSS生命值百分比
	local UnitFramesPlus_OptionsFrame_ExtBossHPPct = CreateFrame("CheckButton", "UnitFramesPlus_OptionsFrame_ExtBossHPPct", UnitFramesPlus_Party_Options, "InterfaceOptionsCheckButtonTemplate");
	UnitFramesPlus_OptionsFrame_ExtBossHPPct:SetPoint("TOPLEFT", UnitFramesPlus_OptionsFrame_PartyScaleSlider, "TOPLEFT", -30, -50);
	UnitFramesPlus_OptionsFrame_ExtBossHPPct:SetHitRectInsets(0, -100, 0, 0);
	UnitFramesPlus_OptionsFrame_ExtBossHPPctText:SetText(Ext_BossHPPct);
	UnitFramesPlus_OptionsFrame_ExtBossHPPct:SetScript("OnClick", function(self)
		UnitFramesPlusDB["ext"]["bosshppct"] = 1 - UnitFramesPlusDB["ext"]["bosshppct"];
		UnitFramesPlus_BossHealthPct();
		for id = 1, 4, 1 do
			UnitFramesPlus_BossHealthPctDisplayUpdate(id)
		end
		self:SetChecked(UnitFramesPlusDB["ext"]["bosshppct"]);
	end)
end

function UnitFramesPlus_OptionPanel_OnShow()
	UnitFramesPlus_OptionsFrame_PlayerFrameScaleSlider:SetValue(UnitFramesPlusDB["player"]["scale"]*100);
	UnitFramesPlus_OptionsFrame_PlayerDragonBorder:SetChecked(UnitFramesPlusDB["player"]["dragon"]);
	if UnitFramesPlusDB["player"]["dragon"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider);
	end
	UnitFramesPlus_OptionsFrame_PlayerDragonBorderTypeSlider:SetValue(UnitFramesPlusDB["player"]["raretype"]);
	UnitFramesPlus_OptionsFrame_PlayerExtbar:SetChecked(UnitFramesPlusDB["player"]["extbar"]);
	if UnitFramesPlusDB["player"]["extbar"] ~= 0 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerHPMPPct);
	end
	UnitFramesPlus_OptionsFrame_PlayerHPMPPct:SetChecked(UnitFramesPlusDB["player"]["hpmp"]);
	if UnitFramesPlusDB["player"]["hpmp"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerHPMPUnit);
		UIDropDownMenu_DisableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne);
		UIDropDownMenu_DisableDropDown(UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo);
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerCoordinate);
	end
	UnitFramesPlus_OptionsFrame_PlayerColorHP:SetChecked(UnitFramesPlusDB["player"]["colorhp"]);
	if UnitFramesPlusDB["player"]["colorhp"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PlayerColorHPSlider);
	end
	UnitFramesPlus_OptionsFrame_PlayerColorHPSlider:SetValue(UnitFramesPlusDB["player"]["colortype"]);
	UnitFramesPlus_OptionsFrame_PlayerOnBar:SetChecked(0);
	UnitFramesPlus_OptionsFrame_Player3DPortrait:SetChecked(UnitFramesPlusDB["player"]["p3d"]);
	if UnitFramesPlusDB["player"]["p3d"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_Player3DPortraitBG);
	end
	UnitFramesPlus_OptionsFrame_Player3DPortraitBG:SetChecked(UnitFramesPlusDB["player"]["p3dbg"]);
	UnitFramesPlus_OptionsFrame_PlayerShiftDrag:SetChecked(UnitFramesPlusDB["player"]["movable"]);
	UnitFramesPlus_OptionsFrame_PlayerPlusBarShiftDrag:SetChecked(UnitFramesPlusDB["player"]["barmovable"]);
	UnitFramesPlus_OptionsFrame_PlayerHPMPUnit:SetChecked(UnitFramesPlusDB["player"]["unit"]);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartOne:SetText(PlayerHPMPPctDropDown[UnitFramesPlusDB["player"]["hpmppartone"]]);
	UnitFramesPlus_OptionsFrame_PlayerHPMPPctPartTwo:SetText(PlayerHPMPPctDropDown[UnitFramesPlusDB["player"]["hpmpparttwo"]]);
	UnitFramesPlus_OptionsFrame_PlayerPortraitIndicator:SetChecked(UnitFramesPlusDB["player"]["indicator"]);
	UnitFramesPlus_OptionsFrame_PlayerFrameAutohide:SetChecked(UnitFramesPlusDB["player"]["autohide"]);
	UnitFramesPlus_OptionsFrame_PlayerCoordinate:SetChecked(UnitFramesPlusDB["player"]["coord"]);
	UnitFramesPlus_OptionsFrame_PlayerPetTarget:SetChecked(UnitFramesPlusDB["player"]["pettarget"]);
	if UnitFramesPlusDB["player"]["pettarget"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct);
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider);
	end
	UnitFramesPlus_OptionsFrame_PlayerPetTargetHPPct:SetChecked(UnitFramesPlusDB["player"]["pthppct"]);
	UnitFramesPlus_OptionsFrame_PlayerPetTargetScaleSlider:SetValue(UnitFramesPlusDB["player"]["ptscale"]*100);
	UnitFramesPlus_OptionsFrame_TargetFrameScaleSlider:SetValue(UnitFramesPlusDB["target"]["scale"]*100);
	UnitFramesPlus_OptionsFrame_TargetStatustext:SetChecked(GetCVar("targetStatusText"));
	UnitFramesPlus_OptionsFrame_TargetOnBar:SetChecked(0);
	UnitFramesPlus_OptionsFrame_TargetHPPct:SetChecked(UnitFramesPlusDB["target"]["hppct"]);
	UnitFramesPlus_OptionsFrame_TargetMPPct:SetChecked(UnitFramesPlusDB["target"]["mppct"]);
	UnitFramesPlus_OptionsFrame_TargetClassIcon:SetChecked(UnitFramesPlusDB["target"]["classicon"]);
	if UnitFramesPlusDB["target"]["classicon"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetClassIconMore);
	end
	UnitFramesPlus_OptionsFrame_TargetClassIconMore:SetChecked(UnitFramesPlusDB["target"]["moreaction"]);
	UnitFramesPlus_OptionsFrame_TargetRace:SetChecked(UnitFramesPlusDB["target"]["race"]);
	UnitFramesPlus_OptionsFrame_TargetSYSToT:SetChecked(GetCVar("showTargetOfTarget"));
	UnitFramesPlus_OptionsFrame_TargetAutoToT:SetChecked(UnitFramesPlusDB["target"]["autotot"]);
	UnitFramesPlus_OptionsFrame_TargetToT:SetChecked(UnitFramesPlusDB["target"]["tot"]);
	UnitFramesPlus_OptionsFrame_TargetToToT:SetChecked(UnitFramesPlusDB["target"]["totot"]);
	if UnitFramesPlusDB["target"]["tot"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetToToT);
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetToTDebuff);
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetToTScaleSlider);
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_TargetToTHPPct);
	end
	UnitFramesPlus_OptionsFrame_TargetToTDebuff:SetChecked(UnitFramesPlusDB["target"]["debuff"]);
	UnitFramesPlus_OptionsFrame_TargetToTScaleSlider:SetValue(UnitFramesPlusDB["target"]["tscale"]*100);
	UnitFramesPlus_OptionsFrame_TargetToTHPPct:SetChecked(UnitFramesPlusDB["target"]["tothppct"]);
	UnitFramesPlus_OptionsFrame_TargetBuffSize:SetChecked(UnitFramesPlusDB["target"]["buffsize"]);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider:SetValue(UnitFramesPlusDB["target"]["mysize"]);
	UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider:SetValue(UnitFramesPlusDB["target"]["othersize"]);
	if UnitFramesPlusDB["target"]["buffsize"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetBuffSizeMineSlider);
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetBuffSizeOtherSlider);
	end
	UnitFramesPlus_OptionsFrame_Target3DPortrait:SetChecked(UnitFramesPlusDB["target"]["p3d"]);
	if UnitFramesPlusDB["target"]["p3d"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_Target3DPortraitBG);
	end
	UnitFramesPlus_OptionsFrame_Target3DPortraitBG:SetChecked(UnitFramesPlusDB["target"]["p3dbg"]);
	UnitFramesPlus_OptionsFrame_TargetShiftDrag:SetChecked(UnitFramesPlusDB["target"]["movable"]);
	UnitFramesPlus_OptionsFrame_TargetPortraitIndicator:SetChecked(UnitFramesPlusDB["target"]["indicator"]);
	UnitFramesPlus_OptionsFrame_TargetCastBar:SetChecked(GetCVar("showTargetCastbar"));
	UnitFramesPlus_OptionsFrame_TargetColorHP:SetChecked(UnitFramesPlusDB["target"]["colorhp"]);
	if UnitFramesPlusDB["target"]["colorhp"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_TargetColorHPSlider);
	end
	UnitFramesPlus_OptionsFrame_TargetColorHPSlider:SetValue(UnitFramesPlusDB["target"]["colortype"]);
	UnitFramesPlus_OptionsFrame_FocusStatustext:SetChecked(GetCVar("targetStatusText"));
	UnitFramesPlus_OptionsFrame_FocusOnBar:SetChecked(0);
	UnitFramesPlus_OptionsFrame_FocusFullsize:SetChecked(UnitFramesPlusDB["focus"]["fullsize"]);	
	if UnitFramesPlusDB["focus"]["fullsize"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider);
	end
	UnitFramesPlus_OptionsFrame_FocusFrameScaleSlider:SetValue(UnitFramesPlusDB["focus"]["scale"]*100);
	UnitFramesPlus_OptionsFrame_FocusQuick:SetChecked(UnitFramesPlusDB["focus"]["quick"]);
	if UnitFramesPlusDB["focus"]["quick"] ~= 1 then
		UIDropDownMenu_DisableDropDown(UnitFramesPlus_OptionsFrame_FocusQuickDropDown);
	end
	UnitFramesPlus_OptionsFrame_FocusQuickDropDownText:SetText(QuickFocusDropDown[UnitFramesPlusDB["focus"]["button"]]);
	UnitFramesPlus_OptionsFrame_FocusHPPct:SetChecked(UnitFramesPlusDB["focus"]["hppct"]);
	UnitFramesPlus_OptionsFrame_FocusMPPct:SetChecked(UnitFramesPlusDB["focus"]["mppct"]);
	UnitFramesPlus_OptionsFrame_FocusClassIcon:SetChecked(UnitFramesPlusDB["focus"]["classicon"]);
	if UnitFramesPlusDB["focus"]["classicon"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_FocusClassIconMore);
	end
	UnitFramesPlus_OptionsFrame_FocusClassIconMore:SetChecked(UnitFramesPlusDB["focus"]["moreaction"]);
	UnitFramesPlus_OptionsFrame_FocusRace:SetChecked(UnitFramesPlusDB["focus"]["race"]);
	UnitFramesPlus_OptionsFrame_Focus3DPortrait:SetChecked(UnitFramesPlusDB["focus"]["p3d"]);
	if UnitFramesPlusDB["focus"]["p3d"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_Focus3DPortraitBG);
	end
	UnitFramesPlus_OptionsFrame_Focus3DPortraitBG:SetChecked(UnitFramesPlusDB["focus"]["p3dbg"]);
	UnitFramesPlus_OptionsFrame_FocusShiftDrag:SetChecked(UnitFramesPlusDB["focus"]["movable"]);
	UnitFramesPlus_OptionsFrame_FocusColorHP:SetChecked(UnitFramesPlusDB["focus"]["colorhp"]);
	if UnitFramesPlusDB["focus"]["colorhp"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_FocusColorHPSlider);
	end
	UnitFramesPlus_OptionsFrame_FocusColorHPSlider:SetValue(UnitFramesPlusDB["focus"]["colortype"]);
	UnitFramesPlus_OptionsFrame_FocusToF:SetChecked(UnitFramesPlusDB["focus"]["tof"]);
	if UnitFramesPlusDB["focus"]["tof"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_FocusToFScaleSlider);
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_FocusToFHPPct);
	end
	UnitFramesPlus_OptionsFrame_FocusToFHPPct:SetChecked(UnitFramesPlusDB["focus"]["tofhppct"]);
	UnitFramesPlus_OptionsFrame_FocusPortraitIndicator:SetChecked(UnitFramesPlusDB["focus"]["indicator"]);
	UnitFramesPlus_OptionsFrame_FocusCastBar:SetChecked(UnitFramesPlusDB["focus"]["spellbar"]);
	UnitFramesPlus_OptionsFrame_FocusToFScaleSlider:SetValue(UnitFramesPlusDB["focus"]["tscale"]*100);
	UnitFramesPlus_OptionsFrame_PartyLevel:SetChecked(UnitFramesPlusDB["party"]["level"]);
	UnitFramesPlus_OptionsFrame_PartyColorName:SetChecked(UnitFramesPlusDB["party"]["colorname"]);
	UnitFramesPlus_OptionsFrame_PartyHP:SetChecked(UnitFramesPlusDB["party"]["hp"]);
	if UnitFramesPlusDB["party"]["hp"] ~= 1 then
		BlizzardOptionsPanel_CheckButton_Disable(UnitFramesPlus_OptionsFrame_PartyHPPct);
	end
	UnitFramesPlus_OptionsFrame_PartyHPPct:SetChecked(UnitFramesPlusDB["party"]["hppct"]);
	UnitFramesPlus_OptionsFrame_PartyOfflineDetection:SetChecked(UnitFramesPlusDB["party"]["onoff"]);
	UnitFramesPlus_OptionsFrame_PartyDeathGhost:SetChecked(UnitFramesPlusDB["party"]["death"]);
	UnitFramesPlus_OptionsFrame_PartyShiftDrag:SetChecked(UnitFramesPlusDB["party"]["movable"]);
	UnitFramesPlus_OptionsFrame_PartyPortraitIndicator:SetChecked(UnitFramesPlusDB["party"]["indicator"]);
	UnitFramesPlus_OptionsFrame_PartyTarget:SetChecked(UnitFramesPlusDB["party"]["target"]);
	UnitFramesPlus_OptionsFrame_PartyBuff:SetChecked(UnitFramesPlusDB["party"]["buff"]);
	if UnitFramesPlusDB["party"]["buff"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PartyBuffNumSlider);
	end
	UnitFramesPlus_OptionsFrame_PartyBuffNumSlider:SetValue(UnitFramesPlusDB["party"]["buffnum"]);
	UnitFramesPlus_OptionsFrame_PartySpellbar:SetChecked(UnitFramesPlusDB["party"]["spellbar"]);
	UnitFramesPlus_OptionsFrame_PartyColorHP:SetChecked(UnitFramesPlusDB["party"]["colorhp"]);
	if UnitFramesPlusDB["party"]["colorhp"] ~= 1 then
		BlizzardOptionsPanel_Slider_Disable(UnitFramesPlus_OptionsFrame_PartyColorHPSlider);
	end
	UnitFramesPlus_OptionsFrame_PartyColorHPSlider:SetValue(UnitFramesPlusDB["party"]["colortype"]);
	UnitFramesPlus_OptionsFrame_PartyScaleSlider:SetValue(UnitFramesPlusDB["party"]["scale"]*100);
	UnitFramesPlus_OptionsFrame_ExtBossHPPct:SetChecked(UnitFramesPlusDB["ext"]["bosshppct"]);
end
