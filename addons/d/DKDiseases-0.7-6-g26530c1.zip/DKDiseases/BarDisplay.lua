local _G = getfenv(0)
local string = _G.string
local tostring = _G.tostring
local pairs = _G.pairs
local math = _G.math

local DKDiseases = LibStub("AceAddon-3.0"):GetAddon("DKDiseases")
local L = _G.LibStub("AceLocale-3.0"):GetLocale("DKDiseases", true)
local LSM = _G.LibStub:GetLibrary("LibSharedMedia-3.0")

local round = DKDiseases.round

local BarDisplay = {}
local BarDisease = {}
local MIN_UPDATE_TIME = DKDiseases.MIN_UPDATE_TIME
local displays = {}

BarDisplay.__index = BarDisplay

BarDisplay.options = {}
BarDisplay.name = "Bar"
BarDisplay.displayName = "Bar Display"

function BarDisplay:IsDiseased()
	return (self.ff and self.ff.diseased) or (self.bp and self.bp.diseased)
end

function BarDisplay:Show(force)
	if force or (DKDiseases.isDK and
		not (DKDiseases.db.profile.units[self.unit].hideooc and 
			not _G.UnitAffectingCombat("player")) 
		and DKDiseases.db.profile.specs[DKDiseases.currentSpec]
		and DKDiseases.db.profile.units[self.unit].enabled and
		(DKDiseases.hostile[self.unit] or 
		not DKDiseases.db.profile.units[self.unit].hideNotAttackable) and
		(self:IsDiseased() or 
		not DKDiseases.db.profile.units[self.unit].hideNoDiseases) and
		(not DKDiseases.inVehicle or
		not DKDiseases.db.profile.units[self.unit].hideInVehicle)) then
		self.frame:Show()
	else
		self.frame:Hide()
	end
end

function BarDisplay:Hide()
	self.frame:Hide()
end

function BarDisplay:Enable()
	self:Show()
end

function BarDisplay:Disable()
	self:Hide()
end

function BarDisplay:Lock(locked)
	if locked == nil then return end
	for name, display in pairs(displays) do
		if display then
			display.frame.lock = locked
			display.frame:EnableMouse(not locked and display.db.attached)
			if display.ff then
				display.ff.bar.lock = locked
				display.ff.bar:EnableMouse(not locked and not display.db.attached)
			end
			if display.bp then
				display.bp.bar.lock = locked
				display.bp.bar:EnableMouse(not locked and not display.db.attached)
			end
		end
	end
end

function BarDisplay:UpdateTexture()
	for name, display in pairs(displays) do
		if display then
			if display.ff then display.ff:UpdateTexture() end
			if display.bp then display.bp:UpdateTexture() end
		end
	end
end
	
function BarDisplay:GetOptions(unit)
	if not self.options[unit] then
		self.options[unit] = {
		    dimensions = {
		        order = 100,
		        type = "header",
		        name = L["Dimensions"],
			},
			width = {
				order = 110,
				name = L["Width"],
				desc = L["BarWidth_Desc"],	
				type = "range",
				min = 20,
				max = 500,
				step = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].width = val
					if displays[unit] then
						displays[unit]:Resize()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].width
				end,
			},
			height = {
				order = 120,
				name = L["Height"],
				desc = L["BarHeight_Desc"],
				type = "range",
				min = 5,
				max = 300,
				step = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].height = val
					if displays[unit] then
						displays[unit]:Resize()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].height
				end,					
			},
		    strValue = {
		        order = 200,
		        type = "header",
		        name = L["Strength Value"],
			},
			strengthFontSize = {
				order = 210,
				name = L["Font size"],
				desc = L["Font size"],
				type = "range",
				min = 8,
				max = 30,
				step = 1,
				set = function(info, val) 
					DKDiseases.db.profile.displays.Bar[unit].strengthFontSize = val
					if displays[unit] then 
						displays[unit]:ResetFonts()
					end
				end,
				get = function(info,val)
					return DKDiseases.db.profile.displays.Bar[unit].strengthFontSize
				end,
			},
			strXOffset = {
				order = 220,
				name = L["X Offset"],
				desc = L["X Offset"],	
				type = "range",
				min = -250,
				max = 250,
				step = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].strXOffset = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].strXOffset
				end,
			},
		    iconHdr = {
		        order = 250,
		        type = "header",
		        name = L["Icon"],
			},
			iconEnabled = {
				order = 251,
				name = L["Enabled"],
				desc = L["Enabled"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].iconEnabled = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end

				end,
				get = function(info)
				    return DKDiseases.db.profile.displays.Bar[unit].iconEnabled
				end,
			},
		    timerValue = {
		        order = 300,
		        type = "header",
		        name = L["Timer Value"],
			},
			timerValueEnabled = {
				order = 301,
				name = L["Enabled"],
				desc = L["Enabled"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].timerValueEnabled = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end

				end,
				get = function(info)
				    return DKDiseases.db.profile.displays.Bar[unit].timerValueEnabled
				end,
			},
			timerFontSize = {
				order = 310,
				name = L["Font size"],
				desc = L["Font size"],
				type = "range",
				min = 8,
				max = 30,
				step = 1,
				set = function(info, val) 
					DKDiseases.db.profile.displays.Bar[unit].timerFontSize = val
					if displays[unit] then
						displays[unit]:ResetFonts()
					end
				end,
				get = function(info,val)
					return DKDiseases.db.profile.displays.Bar[unit].timerFontSize
				end,
			},
		    barBkg = {
		        order = 400,
		        type = "header",
		        name = L["Bar Background"],
			},
			automaticBkg = {
				order = 410,
				name = L["Automatic"],
				desc = L["Automatic_OptDesc"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].automaticBkg = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Bar[unit].automaticBkg
				end,
			},
			bkgColorAdj = {
				order = 420,
				name = L["Color Adjustment"],
				desc = L["ColorAdj_OptDesc"],
				type = "range",
				min = 0.0,
				max = 1.0,
				step = 0.01,
				bigStep = 0.05,
				isPercent = true,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].bkgcoloradj = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].bkgcoloradj
				end,
				disabled = function()
					return not DKDiseases.db.profile.displays.Bar[unit].automaticBkg
				end,
			},
			bkgAlphaAdj = {
				order = 430,
				name = L["Alpha Adjustment"],
				desc = L["AlphaAdj_OptDesc"],
				type = "range",
				min = 0.0,
				max = 2.0,
				step = 0.01,
				bigStep = 0.05,
				isPercent = true,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].bkgalphaadj = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].bkgalphaadj
				end,
				disabled = function()
					return not DKDiseases.db.profile.displays.Bar[unit].automaticBkg
				end,
			},
			barBackgroundColor = {
				order = 440,
				name = L["Fixed Color"],
				desc = L["BarBkgColor_Desc"],
				type = "color",
				hasAlpha = true,
				set = function(info, r, g, b, a)
				    local c = DKDiseases.db.profile.displays.Bar[unit].barbkgcolor
				    c.r, c.g, c.b, c.a = r, g, b, a
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info)
			        local c = DKDiseases.db.profile.displays.Bar[unit].barbkgcolor
				    return c.r, c.g, c.b, c.a
				end,
				disabled = function(info)
					return DKDiseases.db.profile.displays.Bar[unit].automaticBkg
				end,
			},
		    layout = {
		        order = 500,
		        type = "header",
		        name = L["Layout"],
			},
			detached = {
				order = 510,
				name = L["Attached"],
				desc = L["Attached_OptDesc"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].attached = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Bar[unit].attached
				end,
			},
			x = {
				order = 520,
				name = L["X Offset"],
				desc = L["XOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenWidth()),
				softMax = math.floor(_G.GetScreenWidth()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].x = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].x
				end,
				disabled = function()
					return not DKDiseases.db.profile.displays.Bar[unit].attached
				end,
			},
			y = {
				order = 530,
				name = L["Y Offset"],
				desc = L["YOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenHeight()),
				softMax = math.floor(_G.GetScreenHeight()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit].y = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit].y
				end,
				disabled = function()
					return not DKDiseases.db.profile.displays.Bar[unit].attached
				end,
			},
		}

		local diseases = { ["Frost Fever"] = "ff", ["Blood Plague"] = "bp" }
		local i = 0
		for disease, obj in pairs(diseases) do
			self.options[unit][disease.." Header"] = {
		        order = 1000+100*i,
		        type = "header",
		        name = DKDiseases.SpellNames[disease],
			}
			self.options[unit][disease.." X"] = {
				order = 1001+100*i,
				name = L["X Offset"],
				desc = L["XOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenWidth()),
				softMax = math.floor(_G.GetScreenWidth()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit][disease].x = val
					if displays[unit] and displays[unit][obj] then
						displays[unit][obj]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit][disease].x
				end,
				disabled = function()
					return DKDiseases.db.profile.displays.Bar[unit].attached
				end,
			}
			self.options[unit][disease.." Y"] = {
				order = 1001+100*i,
				name = L["Y Offset"],
				desc = L["YOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenWidth()),
				softMax = math.floor(_G.GetScreenWidth()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Bar[unit][disease].y = val
					if displays[unit] and displays[unit][obj] then
						displays[unit][obj]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Bar[unit][disease].y
				end,
				disabled = function()
					return DKDiseases.db.profile.displays.Bar[unit].attached
				end,
			}
			i = i + 1
		end
	end
	return self.options[unit]
end

function BarDisplay:GetFF()
	return self.ff
end

function BarDisplay:GetBP()
	return self.bp
end

function BarDisplay:ClearDisplay()
	if self.ff then self.ff:OnDiseaseRemoved() end
	if self.bp then self.bp:OnDiseaseRemoved() end
end

function BarDisplay:UpdateLayout()
	self.frame:EnableMouse(self.db.attached and not self.frame.lock)
	self.frame:SetPoint("CENTER", _G.UIParent, "CENTER", self.db.x, self.db.y)
	self.frame:SetWidth(self.db.width)
	self.frame:SetHeight(self.db.height * 2)
	if self.ff then
		self.ff:UpdateLayout()
	end
	if self.bp then
		self.bp:UpdateLayout()
	end

	local alpha = _G.UnitAffectingCombat("player") and
		DKDiseases.db.profile.units[self.unit].combatAlpha
		or DKDiseases.db.profile.units[self.unit].ooc_alpha
	self.frame:SetAlpha(alpha)
end

function BarDisplay:Resize()
	self:UpdateLayout()
end

function BarDisplay:ResetFonts()
	for name, display in pairs(displays) do
		if display then
			if display.ff then display.ff:ResetFonts() end
			if display.bp then display.bp:ResetFonts() end
		end
	end
end

function BarDisplay:Create(unit)
	if displays[unit] then return displays[unit] end
	local object = _G.setmetatable({}, BarDisplay)
	object.unit = unit
	object.unitName = unit:gsub("^%l", string.upper)
	object:Initialize()
	displays[unit] = object
	return object
end

function BarDisplay:Initialize()
	self.db = DKDiseases.db.profile.displays[self.name][self.unit]
	local frame = _G.CreateFrame("Frame", 
		"DKDiseases_Bar_"..self.name.."_"..self.unitName, _G.UIParent)
	self.frame = frame
	frame.obj = self

	frame:SetPoint("CENTER", _G.UIParent, "CENTER", self.db.x, self.db.y)
	--frame.lock = self.db.locked
	frame.lock = DKDiseases.db.profile.locked
    frame:SetMovable(true)
	self:UpdateLayout()

    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",
        function(self, button)
			if not self.lock then
            	self:StartMoving()
			end
        end)
    frame:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.obj.db.x, self.obj.db.y = x, y
			self:SetUserPlaced(false);
        end)
    frame:EnableMouse(not frame.lock and self.db.attached)

	self.ff = BarDisease:Create("Frost Fever", self)
	self.bp = BarDisease:Create("Blood Plague", self)

	return self
end

function BarDisplay:OnCombatEnter()
	self.frame:SetAlpha(DKDiseases.db.profile.units[self.unit].combatAlpha)
	self:Show()
end

function BarDisplay:OnCombatLeave()
	self.frame:SetAlpha(DKDiseases.db.profile.units[self.unit].ooc_alpha)
	if DKDiseases.db.profile.units[self.unit].hideooc then
		self.frame:Hide()
	end
end

DKDiseases:RegisterDisplay("Bar", BarDisplay)

-- Bar Disease

BarDisease.__index = BarDisease

function BarDisease:Create(name, parent)
	local object = _G.setmetatable({}, BarDisease)
	object.name = name
	object.parent = parent
	object.db = DKDiseases.db.profile.displays[parent.name][parent.unit]
	object:Initialize()
	return object
end

local function onUpdateDisease(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.timer = self.timer - elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		self.lastUpdate = 0
		if self.active then
			if self.timer < 0 then
				self.timer = 0
				self.active = false
			end
			self:SetValue(self.timer)
			self.obj.time:SetText(tostring(round(self.timer)))
		else
			self:SetScript("OnUpdate", nil)
		end
	end
end

function BarDisease:Initialize()
	local baseName = self.parent.frame:GetName()
	self.varName = self.name:gsub(" ", "")
	self.diseased = false

    local bar = _G.CreateFrame("StatusBar", 
		baseName.."_"..self.name.."_Icon", self.parent.frame)
	self.bar = bar
	bar.obj = self
	bar:SetScale(1)
   	bar:SetOrientation("HORIZONTAL")
    bar:SetWidth(self.db.width)
    bar:SetHeight(self.db.height)
	local bt = LSM:Fetch("statusbar", DKDiseases.db.profile.texture)
    bar:SetStatusBarTexture(bt)
    bar:GetStatusBarTexture():SetHorizTile(false)
    bar:GetStatusBarTexture():SetVertTile(false)
    bar.bg = bar:CreateTexture(nil, "BACKGROUND")
    bar.bg:SetTexture(bt)
    bar.bg:SetAllPoints(true)

    self.value = bar:CreateFontString(nil, "OVERLAY")
    --self.value:SetPoint("CENTER")
    self.value:SetJustifyH("CENTER")

	self.time = bar:CreateFontString(nil, "OVERLAY")
    self.time:SetPoint("RIGHT")
    self.time:SetJustifyH("CENTER")
	
	self.icon = _G.CreateFrame("Frame", 
		baseName.."_"..self.name.."_Icon", bar)
    self.icon:SetWidth(self.db.height)
    self.icon:SetHeight(self.db.height)
	self.icon.texture = self.icon:CreateTexture(nil, "ARTWORK")
    self.icon.texture:SetAllPoints(self.icon)
    self.icon.texture:SetVertexColor(1, 1, 1)
	self.icon.texture:SetTexture(DKDiseases.SpellIcons[self.name])
	self.icon:SetPoint("RIGHT", self.bar, "LEFT")

	bar.lock = DKDiseases.db.profile.locked
    bar:SetMovable(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart",
        function(self, button)
			if not self.lock then
            	self:StartMoving()
			end
        end)
    bar:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.obj.db[self.obj.name].x, self.obj.db[self.obj.name].y = x, y
			self:SetUserPlaced(false);
        end)
    bar:EnableMouse(not self.db.attached and not bar.lock)

	self:ResetFonts()
	self:UpdateLayout()
	self:UpdateColor()
end

function BarDisease:Show()
	self.bar:Show()
end

function BarDisease:Hide()
	self.bar:Hide()
end

function BarDisease:UpdateColor(color)
	local c = color or DKDiseases.db.profile.reapplycolors[0]
	local cadj = self.db.bkgcoloradj and (1 + self.db.bkgcoloradj) or 1.6
	local aadj = self.db.bkgalphaadj or 1.4
	self.bar:SetStatusBarColor(c.r, c.g, c.b, c.a)
	if self.db.automaticBkg then
	   	self.bar.bg:SetVertexColor(c.r / cadj, c.g / cadj, c.b / cadj, c.a * aadj)
	else
		local b = self.db.barbkgcolor
	   	self.bar.bg:SetVertexColor(b.r, b.g, b.b, b.a)
	end
end

function BarDisease:SetValue(value)
	self.value:SetText(value)
end

function BarDisease:OnDiseaseRefreshed(duration, expires)
	self.diseased = true
	local timeLeft = expires - _G.GetTime()
	self.bar.active = true
	self.bar.timer = timeLeft
	self.bar:SetMinMaxValues(0, duration)
	self.bar:SetScript("OnUpdate", onUpdateDisease)
	if self.db.timerValueEnabled then
		self.time:Show()
	else
		self.time:Hide()
	end
	self.value:Show()
	self.parent:Show()
end

function BarDisease:OnDiseaseRemoved()
	self.diseased = false
	self.bar.active = false 
	self.bar.timer = 0
	self.bar:SetScript("OnUpdate", nil)
	self.bar:SetMinMaxValues(0, 1)
	self.bar:SetValue(1)
	self.time:Hide()
	self:UpdateColor()
	self.value:Hide()
	self.parent:Show()
end

function BarDisease:UpdateLayout()
	local bar = self.bar
	bar:EnableMouse(not self.db.attached and not bar.lock)
	bar:SetWidth(self.db.width)
	bar:SetHeight(self.db.height)
	local ordering = {
		["BF"] = {
			["Blood Plague"] = 1,
			["Frost Fever"] = 2,
		},
		["FB"] = {
			["Frost Fever"] = 1,
			["Blood Plague"] = 2,
		},
		["F"] = {
			["Frost Fever"] = 1,
			["Blood Plague"] = 0,
		},
		["B"] = {
			["Blood Plague"] = 1,
			["Frost Fever"] = 0,
		},
	}
	bar:ClearAllPoints()
	local order = ordering[DKDiseases.db.profile.diseaseOrder][self.name]

	if not self.db.attached then
		bar:SetPoint("CENTER", _G.UIParent, "CENTER", 
			self.db[self.name].x, self.db[self.name].y)
	else
		if order == 1 then
			bar:SetPoint("TOP", self.parent.frame, "TOP")
		else
			bar:SetPoint("BOTTOM", self.parent.frame, "BOTTOM")
		end
	end
	if order == 0 then
		bar:Hide()
	else
		bar:Show()
	end

    self.value:SetPoint("CENTER", bar, "CENTER", self.db.strXOffset, 0)

	if self.db.iconEnabled then
		self.icon:Show()
	else
		self.icon:Hide()
	end
end

function BarDisease:ResetFonts()
	local ff, fh, fflags = DKDiseases:GetFontSettings()
	local font = LSM:Fetch("font", ff)
    self.value:SetFont(font, self.db.strengthFontSize or fh, fflags)
	self.value:SetText(self.value:GetText())
    self.time:SetFont(font, self.db.timerFontSize or fh, fflags)
	self.time:SetText(self.time:GetText())
   	local tc = self.db.textcolor
   	self.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
   	self.time:SetTextColor(tc.r, tc.g, tc.b, tc.a)
end

function BarDisease:UpdateTexture()
    local bt = LSM:Fetch("statusbar", DKDiseases.db.profile.texture)
	self.bar:SetStatusBarTexture(bt)
	self.bar.bg:SetTexture(bt)
    self.bar:GetStatusBarTexture():SetHorizTile(false)
    self.bar:GetStatusBarTexture():SetVertTile(false)
end

