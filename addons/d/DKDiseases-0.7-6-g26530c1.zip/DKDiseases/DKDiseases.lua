local _G = getfenv(0)
local ADDON_NAME, addon = ...

-- Local versions for performance
local string = _G.string
local math = _G.math
local pairs = _G.pairs
local ipairs = _G.ipairs
local table = _G.table
local floor, ceil, min, max, abs = math.floor, math.ceil, math.min, math.max, math.abs
local tconcat, tinsert = table.concat, table.insert
local wipe = _G.wipe
local tostring = _G.tostring
local tonumber = _G.tonumber

local DKDiseases = _G.LibStub("AceAddon-3.0"):NewAddon("DKDiseases", "AceConsole-3.0", "AceEvent-3.0","AceTimer-3.0")
local L = _G.LibStub("AceLocale-3.0"):GetLocale("DKDiseases", true)
local LDB = _G.LibStub("LibDataBroker-1.1")
local LibQTip = _G.LibStub("LibQTip-1.0")
local Icon = _G.LibStub("LibDBIcon-1.0")
local LSM = _G.LibStub:GetLibrary("LibSharedMedia-3.0")
local Masque = LibStub("Masque", true)

-- Try to remove the Git hash at the end, otherwise return the passed in value.
function addon.cleanupVersion(version)
	local iter = string.gmatch(version, "(.*)-[a-z0-9]+$")
	if iter then
		local ver = iter()
		if ver and #ver >= 3 then
			return ver
		end
	end
	return version
end

addon.addonVersion = addon.cleanupVersion("0.7-6-g26530c1")
addon.addonTitle = _G.GetAddOnMetadata(ADDON_NAME, "Title")
addon.CURRENT_BUILD, addon.CURRENT_INTERNAL, 
    addon.CURRENT_BUILD_DATE, addon.CURRENT_UI_VERSION = _G.GetBuildInfo()
addon.WoD = addon.CURRENT_UI_VERSION >= 60000

local options = nil
local MIN_UPDATE_TIME = 0.05

local function round(number)
    if not number then return 0 end
    return floor(number+0.5)
end
DKDiseases.round = round

local HEXFMT = "|c%2x%2x%2x%2x"
local function chatColorCode(color)
	local a = 255
	local r = ceil(255 * color.r)
	local g = ceil(255 * color.g)
	local b = ceil(255 * color.b)
	return HEXFMT:format(a, r, g, b)
end

local millFmt = "%.0fm"
local thousandFmt = "%.0fk"
local baseFmt = "%.0f"
local function FormatNumber(number)
    if tonumber(number) == nil then
        return number
    end

    if number > 1000000 or number <= -1000000 then
        return millFmt:format(number / 1000000)
    elseif number > 1000 or number <= -1000 then
        return thousandFmt:format(number / 1000)
	else
		return baseFmt:format(number)
    end

    return number
end

DKDiseases.MIN_UPDATE_TIME = MIN_UPDATE_TIME
DKDiseases.registeredDisplays = {}
DKDiseases.displays = {
	target = nil,
	focus = nil,
}
DKDiseases.diseases = {
	target = {
		ff = nil,
		bp = nil,
	},
	focus = {
		ff = nil,
		bp = nil,
	},
}
DKDiseases.units = {"target", "focus"}
DKDiseases.playerName = UnitName("player")
DKDiseases.isDK = false
DKDiseases.currentSpec = ""
DKDiseases.current = {
	target = nil,
	focus = nil,
}
DKDiseases.hostile = {
	target = nil,
	focus = nil,
}
DKDiseases.base = {
	ff = 0,
	bp = 0,
}
DKDiseases.eff = {
	ff = 0,
	bp = 0,
}
DKDiseases.baseline = {
	ff = 0,
	bp = 0,
}
DKDiseases.ff = {}
DKDiseases.bp = {}
DKDiseases.cinderglacier = false
DKDiseases.adjustments = {
	["Tricks of the Trade"] = nil,
}
DKDiseases.adjustmentMods = {
	["Tricks of the Trade"] = 1.15,
}
DKDiseases.effectiveAP = 0
DKDiseases.mastery = 0
DKDiseases.critChance = 0
DKDiseases.spellCrit = 0
DKDiseases.damageModifier = 1.0
DKDiseases.frostVulnerability = 1.0
DKDiseases.physicalVulnerability = 1.0
DKDiseases.magicVulnerability = 1.0
DKDiseases.avgWeaponDmg = 0
DKDiseases.soulReaper1 = 0
DKDiseases.soulReaper2 = 0
DKDiseases.howlingBlast = 0
DKDiseases.soulReaperMin = 55336
DKDiseases.soulReaperMax = 64309
DKDiseases.soulReaperBase = (DKDiseases.soulReaperMin + DKDiseases.soulReaperMax) / 2
DKDiseases.soulReaperRange = nil

local Broker = _G.CreateFrame("Frame")
Broker.obj = LDB:NewDataObject(_G.GetAddOnMetadata(ADDON_NAME, "Title"), {
    type = "data source",
    icon = "Interface\\Icons\\Spell_DeathKnight_BloodPlague",
    label = _G.GetAddOnMetadata(ADDON_NAME, "Title"),
    text = _G.GetAddOnMetadata(ADDON_NAME, "Title"),
    barValue = 0,
    barR = 0,
    barG = 0,
    barB = 1,
	OnClick = function(clickedframe, button)
		if button == "RightButton" then
			local optionsFrame = _G.InterfaceOptionsFrame

			if optionsFrame:IsVisible() then
				optionsFrame:Hide()
			else
				DKDiseases:ShowOptions()
			end
		elseif button == "LeftButton" and _G.IsShiftKeyDown() then
			DKDiseases:CalculateBaseline()
        end
	end
} )

local GREEN = "|cff00ff00"
local YELLOW = "|cffffff00"
local BLUE = "|cff0198e1"
local ORANGE = "|cffff9933"
local FF_COLOR = chatColorCode({r = 0.0, g = 0.45*1.6, b = 0.6*1.6})
local BP_COLOR = chatColorCode({r = 0.5*1.6, g = 0.0, b = 0.6*1.6})
local Headers = {
	Addon = GREEN.."%s %s",
	DiseaseTick = ORANGE..L["Disease Tick Values"],
	FFBP = ORANGE.."FF / BP",
	BPFF = ORANGE.."BP / FF",
}

function Broker.obj:OnEnter()
	local tooltip = LibQTip:Acquire("DKDiseasesTooltip", 2, "LEFT", "RIGHT")
	self.tooltip = tooltip 

    tooltip:AddHeader(Headers.Addon:format(addon.addonTitle, addon.addonVersion))
    tooltip:AddLine()

    if DKDiseases.isDK then
        tooltip:AddLine(L["Shift + Left-Click to set baseline."], "", 1, 1, 1)
		tooltip:AddLine()
		tooltip:AddLine(Headers.DiseaseTick, 
			DKDiseases.db.profile.diseaseOrder == "FB" and
				Headers.FFBP or Headers.BPFF)
		tooltip:AddSeparator(1)
		local values = {
			["Base"] = DKDiseases.base,
			["Effective"] = DKDiseases.eff,
			["Baseline"] = DKDiseases.baseline,
		}
		local valueFmt = "%s%s|r / %s%s"
		for name, table in pairs(values) do
			local valStr = ""
			if DKDiseases.db.profile.diseaseOrder == "FB" then
				valStr = valueFmt:format(FF_COLOR, FormatNumber(table.ff),
					BP_COLOR, FormatNumber(table.bp))
			else
				valStr = valueFmt:format(BP_COLOR, FormatNumber(table.bp),
					FF_COLOR, FormatNumber(table.ff))
			end
			tooltip:AddLine(L[name], valStr)
		end
    end

	tooltip:SmartAnchorTo(self)
	tooltip:Show()
end

function Broker.obj:OnLeave()
	LibQTip:Release(self.tooltip)
	self.tooltip = nil
end

local LDBDataFeed = false
local DataFeed = {
    display = "",
	lastBP = 0,
}

local function UpdateLDBData()
    if DataFeed.display == "LastBP" then
        Broker.obj.text = FormatNumber(DataFeed.lastBP)
    else
        Broker.obj.text = _G.GetAddOnMetadata(ADDON_NAME, "Title")
    end
end

function DKDiseases:SetLDBDataDisplay()
	DataFeed.display = self.db.profile.LDBDataDisplay
	LDBDataFeed = DataFeed.display == "None" and false or true
	UpdateLDBData()
end

local LookupOrKeyMT = {__index = function (t,k) return k end}
local SpellIds = {
	--["Frost Fever"] = 59921,
	--["Blood Plague"] = 59879,
	--["Frost Fever Periodic"] = 55095,
	--["Blood Plague Periodic"] = 55078,
	["Plague Strike"] = 45462,
	["Outbreak"] = 77575,
	["Cinderglacier"] = 53386,
	["Tricks of the Trade"] = 57933,
	["Auto Attack"] = 6603,
	["Frost Vulnerability"] = 51714,
	["Physical Vulnerability"] = 81326,
	["Curse of Elements"] = 1490,
	["Lightning Breath"] = 24844,
	["Master Poisoner"] = 58410,
	["Howling Blast"] = 49184,
	["Soul Reaper"] = 130735,
	["Soul Reaper (Blood)"] = 114866,
	["Soul Reaper (Frost)"] = 130735,
	["Soul Reaper (Unholy)"] = 130736,
}
if addon.WoD then
	SpellIds["Frost Fever"] = 55095
	SpellIds["Blood Plague"] = 55078
	SpellIds["Frost Fever Periodic"] = 55095
	SpellIds["Blood Plague Periodic"] = 55078
else
	SpellIds["Frost Fever"] = 59921
	SpellIds["Blood Plague"] = 59879
	SpellIds["Frost Fever Periodic"] = 55095
	SpellIds["Blood Plague Periodic"] = 55078
end
local SpellNames = {}
local SpellIcons = {}
_G.setmetatable(SpellNames, LookupOrKeyMT)
local function LoadSpellNames()
	for k, v in pairs(SpellIds) do
		local name, _, icon = _G.GetSpellInfo(v)
		SpellNames[k] = name
		SpellIcons[k] = icon
	end
end
LoadSpellNames()
DKDiseases.SpellIcons = SpellIcons
DKDiseases.SpellNames = SpellNames

local frames = {}

local defaults = {
	profile = {
		minimap = {
			hide = true,
		},
		LDBDataDisplay = "None",
		locked = false,
		debug = false,
		debugBP = false,
		specs = {
			["Frost"] = true,
			["Unholy"] = true,
			["Blood"] = true,
		},
		trackDiseases = true,
		adjustments = {
			["Tricks of the Trade"] = true,
		},
		strengthValue = "Percent",
		diseaseThresholdType = "Percent",
		diseaseThreshold = 1.1,
		diseaseThresholdAmt = 1000,
		font_face = "Friz Quadrata TT",
		font_size = 13,
		fontFlags = {
			OUTLINE = true,
			THICKOUTLINE = false,
			MONOCHROME = false
		},
		texture = "Blizzard",
		border = "",
		diseaseOrder = "BF",
		reapplycolors = {
			[-1] = { r = 0.8, g = 0.1, b = 0.1, a = 0.5 },
			[0] = { r = 0.0, g = 0.0, b = 0.5, a = 0.8 },
			[1] = { r = 0.8, g = 0.8, b = 0.1, a = 0.5 },
			[2] = { r = 0.1, g = 0.8, b = 0.1, a = 0.5 },
		},
		units = {
			target = {
				enabled = true,
				hideooc = false,
				ooc_alpha = 0.5,
				combatAlpha = 1.0,
				hideNotAttackable = false,
				hideNoDiseases = false,
				hideInVehicle = true,
			},
			focus = {
				enabled = false,
				hideooc = false,
				ooc_alpha = 0.5,
				combatAlpha = 1.0,
				hideNotAttackable = false,
				hideNoDiseases = false,
				hideInVehicle = true,
			},
		},
		srFrame = {
			enabled = false,
			userPlaced = false,
			x = 0,
			y = 0,
			height = 32,
			width = 32,
			showText = true,
			percent = 0.35,
			alwaysShow = false,
			onlyShowHB = false,
			specs = {
				["Frost"] = true,
				["Unholy"] = false,
				["Blood"] = false,
			},
		},
		display = {
			target = "Block",
			focus = "Block",
		},
		displays = {
			["Block"] = {
				['**'] = {
					textcolor = { r = 1.0, g = 1.0, b = 1.0, a = 1.0 },
					timercolor = { r = 1.0, g = 1.0, b = 0.0, a = 1.0 },
					strengthFontSize = 13,
					timer = true,
					timerFontSize = 14,
					cooldown = true,
					reverseCooldown = false,
					background = true,
					x = 0,
					y = 0,
					attached = true,
					inset = 3,
					width = 35,
					height = 35,
					["Blood Plague"] = {
						x = -20,
						y = 0,
					},
					["Frost Fever"] = {
						x = 20,
						y = 0,
					},
				},
			},
			["Bar"] = {
				['**'] = {
					textcolor = { r = 1.0, g = 1.0, b = 1.0, a = 1.0 },
					x = 0,
					y = 0,
					attached = true,
					width = 100,
					height = 20,
					value = true,
					timer = true,
					strengthFontSize = 13,
					strXOffset = 0,
					iconEnabled = true,
					timerValueEnabled = true,
					timerFontSize = 13,
					automaticBkg = true,
					bkgcoloradj = 0.6,
					bkgalphaadj = 1.4,
					barbkgcolor = { r = 0.2, g = 0.2, b = 0.2, a = 0.8 },
					["Blood Plague"] = {
						x = 0,
						y = 10,
					},
					["Frost Fever"] = {
						x = 0,
						y = -10,
					},
				},
			},
		},
	},
}

function DKDiseases:GetOptions()
    if not options then
        options = {
            type = "group",
            name = _G.GetAddOnMetadata(ADDON_NAME, "Title"),
            args = {
				core = self:GetCoreOptions(),
            }
        }
		options.args.profile = _G.LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
    end
    return options
end

function DKDiseases:ShowOptions()
	_G.InterfaceOptionsFrame_OpenToCategory(self.optionsFrame.Main)
end

function DKDiseases:GetCoreOptions()
	local core = {
	    order = 1,
		name = L["General Options"],
		type = "group",
		inline = true,
		args = {
		    description = {
		        order = 1,
		        type = "description",
		        name = L["Addon_Desc"],
		    },
		    generalOptions = {
		        order = 100,
		        type = "group",
		        name = L["General Options"],
				args = self:GetGeneralOptions(),
		    },
			diseaseTracking = {
		        order = 200,
		        type = "group",
		        name = L["Disease Strength"],
				args = self:GetStrengthOptions(),
			},
			soulReaper = {
		        order = 300,
		        type = "group",
		        name = SpellNames["Soul Reaper"],
				args = self:GetSoulReaperOptions(),
			},
		    fonts = {
		        order = 600,
		        type = "group",
		        name = L["Font"],
				args = {
					font_size = {
						order = 610,
						name = L["Font size"],
						desc = L["Font size"],
						type = "range",
						min = 8,
						max = 30,
						step = 1,
						set = function(info, val) 
							self.db.profile.font_size = val
							self:ResetFonts()
						end,
						get = function(info,val) return self.db.profile.font_size end,
					},
					font_face = {
						order = 620,
						type = "select",
						name = L["Font"],
						desc = L["Font to use."],
						values = LSM:HashTable("font"),
						dialogControl = 'LSM30_Font',
						get = function() return self.db.profile.font_face end,
						set = function(info, val) 
						    self.db.profile.font_face = val
							self:ResetFonts()
						end
					},
					font_outline = {
						name = L["Outline"],
						desc = L["FontOutlineDesc"],
						type = "toggle",
						order = 630,
						set = function(info, val)
						    self.db.profile.fontFlags.OUTLINE = val
						    self:ResetFonts()
						end,
		                get = function(info)
		                    return self.db.profile.fontFlags.OUTLINE
		                end,
					},
					font_thickoutline = {
						name = L["Thick Outline"],
						desc = L["FontThickOutline_OptionDesc"],
						type = "toggle",
						order = 640,
						set = function(info, val)
						    self.db.profile.fontFlags.THICKOUTLINE = val
						    self:ResetFonts()
						end,
		                get = function(info)
		                    return self.db.profile.fontFlags.THICKOUTLINE
		                end,
					},
					font_monochrome = {
						name = L["Monochrome"],
						desc = L["FontMonochromeDesc"],
						type = "toggle",
						order = 650,
						set = function(info, val)
						    self.db.profile.fontFlags.MONOCHROME = val
						    self:ResetFonts()
						end,
		                get = function(info)
		                    return self.db.profile.fontFlags.MONOCHROME
		                end,
					},
				},
		    },
            textures = {
                order = 700,
                type = "group",
                name = L["Textures"],
				args = {
					bartexture = {
						order = 110,
						name = L["Bar Texture"],
						desc = L["BarTexture_OptionDesc"],
						type = "select",
						values = LSM:HashTable("statusbar"),
						dialogControl = 'LSM30_Statusbar',
						get = function()
						    return self.db.profile.texture
						end,
						set = function(info, val)
						    self.db.profile.texture = val
							self:UpdateTextures()
						end,
					},
					bordertexture = {
						order = 120,
						name = L["Border"],
						desc = L["Border_OptionDesc"],
						type = "select",
						values = LSM:HashTable("border"),
						dialogControl = 'LSM30_Border',
						get = function()
						    return self.db.profile.border
						end,
						set = function(info, val)
						    self.db.profile.border = val
						end,
					},
				},
            },
		},
	}

	for i, unit in ipairs(self.units) do
		local i = 100

		core.args[unit] = {
	        order = (unit == "target" and 300 or 400),
	        type = "group",
	        name = (unit == "target" and L["Target Frame"] or L["Focus Frame"]),
			args = {
				enabled = {
					order = 1,
					name = L["Enabled"],
					desc = L["Enabled"],
					type = "toggle",
					set = function(info, val)
						self.db.profile.units[unit].enabled = val
						if val then
							self:CreateOrUpdateDisplay(unit)
						elseif self.displays[unit] and self.displays[unit].Disable then
							self.displays[unit]:Disable()
						end
					end,
					get = function(info)
						return self.db.profile.units[unit].enabled
					end,
				},
				display = {
					order = 2,
					name = L["Display"],
					desc = L["Display"],
					type = "select",
					values = {
					    ["Bar"] = L["Bar"],
					    ["Block"] = L["Block"],
					},
					set = function(info, val)
					    self.db.profile.display[unit] = val
						self:CreateOrUpdateDisplay(unit)
					end,
		            get = function(info)
		                return self.db.profile.display[unit]
		            end,
				},
				ooc_alpha = {
					order = 3,
					name = L["OOC Alpha"],
					desc = L["OOCAlpha_Desc"],
					type = "range",
					min = 0,
					max = 1,
					step = 0.05,
					set = function(info, val)
					    self.db.profile.units[unit].ooc_alpha = val
						if self.displays[unit] then
							self.displays[unit]:UpdateLayout()
						end
					end,
					get = function(info, val)
					    return self.db.profile.units[unit].ooc_alpha
					end,					
				},
				combatAlpha = {
					order = 4,
					name = L["Combat Alpha"],
					desc = L["CombatAlpha_Desc"],
					type = "range",
					min = 0,
					max = 1,
					step = 0.05,
					set = function(info, val)
					    self.db.profile.units[unit].combatAlpha = val
						if self.displays[unit] then
							self.displays[unit]:UpdateLayout()
						end
					end,
					get = function(info, val)
					    return self.db.profile.units[unit].combatAlpha
					end,					
				},
				hideWhen = {
			        order = 100,
			        type = "header",
			        name = L["Hide When"],
				},
				hideooc = {
					order = 101,
					name = L["Out of Combat"],
					desc = L["Out of Combat"],
					type = "toggle",
					set = function(info, val)
					    self.db.profile.units[unit].hideooc = val
						if self.displays[unit] then
							self.displays[unit]:Show()
						end
					end,
		            get = function(info)
						return self.db.profile.units[unit].hideooc
					end,
				},
				hideNotAttackable = {
					order = 102,
					name = L["Not Attackable"],
					desc = L["Not Attackable"],
					type = "toggle",
					set = function(info, val)
					    self.db.profile.units[unit].hideNotAttackable = val
						if self.displays[unit] then
							self.displays[unit]:Show()
						end
					end,
		            get = function(info)
						return self.db.profile.units[unit].hideNotAttackable
					end,
				},
				hideNoDiseases = {
					order = 103,
					name = L["No Diseases"],
					desc = L["No Diseases"],
					type = "toggle",
					set = function(info, val)
					    self.db.profile.units[unit].hideNoDiseases = val
						if self.displays[unit] then
							self.displays[unit]:Show()
						end
					end,
		            get = function(info)
						return self.db.profile.units[unit].hideNoDiseases
					end,
				},
				hideInVehicle = {
					order = 103,
					name = L["In Vehicle"],
					desc = L["In Vehicle"],
					type = "toggle",
					set = function(info, val)
					    self.db.profile.units[unit].hideInVehicle = val
						if self.displays[unit] then
							self.displays[unit]:Show()
						end
					end,
		            get = function(info)
						return self.db.profile.units[unit].hideInVehicle
					end,
				},
			},
		}

		for name, display in pairs(self.registeredDisplays) do
			if display and display.GetOptions then
				local opts = display:GetOptions(unit)
				if opts then
					core.args[unit].args[name] = {
						order = i,
						name = name,
						type = "group",
						args = opts,
					}
					i = i + 1
				end
			end
		end
	end

	return core
end

function DKDiseases:GetGeneralOptions()
	local options = {
		locked = {
			name = L["Lock"],
			desc = L["LockDesc"],
			type = "toggle",
			order = 10,
			set = function(info, val)
				self.db.profile.locked = val
				for name, display in pairs(self.registeredDisplays) do
					if display and display.Lock then
						display:Lock(val)
					end
				end
				if self.srFrame then self.srFrame:Lock(val) end
			end,
            get = function(info)
				return self.db.profile.locked
			end,
		},
	    minimap = {
			order = 20,
            name = L["Minimap Button"],
            desc = L["Toggle the minimap button"],
            type = "toggle",
            set = function(info,val)
                	-- Reverse the value since the stored value is to hide it
                    self.db.profile.minimap.hide = not val
                	if self.db.profile.minimap.hide then
                		Icon:Hide("DKDiseasesLDB")
                	else
                		Icon:Show("DKDiseasesLDB")
                	end
                  end,
            get = function(info)
        	        -- Reverse the value since the stored value is to hide it
                    return not self.db.profile.minimap.hide
                  end,
        },
		diseaseOrder = {
			order = 30,
			name = L["Disease Order"],
			desc = L["DiseaseOrder_Desc"],
			type = "select",
			values = {
			    ["FB"] = SpellNames["Frost Fever"]..", "..SpellNames["Blood Plague"],
			    ["BF"] = SpellNames["Blood Plague"]..", "..SpellNames["Frost Fever"],
			    ["F"] = SpellNames["Frost Fever"],
			    ["B"] = SpellNames["Blood Plague"],
			},
			set = function(info, val)
			    self.db.profile.diseaseOrder = val
				self.displays.target:UpdateLayout()
			end,
            get = function(info)
                return self.db.profile.diseaseOrder
            end,
		},
		specHdr = {
	        order = 200,
	        type = "header",
	        name = L["Enabled for Specs"],
		},
		specBlood = {
			name = L["Blood"],
			desc = L["Blood"],
			type = "toggle",
			order = 210,
			set = function(info, val)
			    self.db.profile.specs["Blood"] = val
				self:CheckEnabled()
			end,
            get = function(info)
				return self.db.profile.specs["Blood"]
			end,
		},
		specFrost = {
			name = L["Frost"],
			desc = L["Frost"],
			type = "toggle",
			order = 220,
			set = function(info, val)
			    self.db.profile.specs["Frost"] = val
				self:CheckEnabled()
			end,
            get = function(info)
				return self.db.profile.specs["Frost"]
			end,
		},
		specUnholy = {
			name = L["Unholy"],
			desc = L["Unholy"],
			type = "toggle",
			order = 230,
			set = function(info, val)
			    self.db.profile.specs["Unholy"] = val
				self:CheckEnabled()
			end,
            get = function(info)
				return self.db.profile.specs["Unholy"]
			end,
		},
	    ldb = {
	        order = 300,
	        type = "header",
	        name = L["LDB"],
	    },
		LDBDataFeed = {
			order = 310,
			name = L["Data Feed"],
			desc = L["DataFeed_OptionDesc"],
			type = "select",
			values = {
			    ["None"] = L["None"],
				["LastBP"] = L["Last BP Tick"],
			},
			set = function(info, val)
			    self.db.profile.LDBDataDisplay = val
				self:SetLDBDataDisplay()
			    UpdateLDBData()
			end,
            get = function(info)
                return self.db.profile.LDBDataDisplay
            end,
		},
	}
	return options
end

function DKDiseases:GetStrengthOptions()
	local options = {
		trackDiseases = {
			name = L["Enabled"],
			desc = L["Enabled"],
			type = "toggle",
			order = 100,
			set = function(info, val)
			    self.db.profile.trackDiseases = val
				self:ToggleDiseaseTracking()
			end,
            get = function(info)
				return self.db.profile.trackDiseases
			end,
		},
		strengthValue = {
			name = L["Value"],
			desc = L["Value"],
			type = "select",
			values = {
			    ["Percent"] = L["Percent"],
			    ["Base"] = L["Base Tick"],
			    ["Effective"] = L["Effective Tick"],
				["Increase"] = L["Effective Increase"],
				["EffRef+C"] = L["Refresh + Current"],
			},
			order = 105,
			set = function(info, val)
			    self.db.profile.strengthValue = val
			end,
            get = function(info)
                return self.db.profile.strengthValue
            end,
		},
		diseaseThreshold = {
			name = L["Threshold"],
			desc = L["Threshold"],
			type = "select",
			values = {
			    ["Percent"] = L["Percent"],
			    ["Fixed"] = L["Fixed"],
			},
			order = 110,
			set = function(info, val)
			    self.db.profile.diseaseThresholdType = val
			end,
            get = function(info)
                return self.db.profile.diseaseThresholdType
            end,
		},
		diseaseThresholdPerc = {
			order = 120,
			name = L["Percent"],
			desc = L["Percent"],
			type = "range",
			min = 1.0,
			max = 3.0,
			step = 0.01,
			bigStep = 0.05,
			isPercent = true,
			set = function(info, val)
			    self.db.profile.diseaseThreshold = val
			end,
			get = function(info, val)
			    return self.db.profile.diseaseThreshold
			end,
			disabled = function()
				return self.db.profile.diseaseThresholdType ~= "Percent"
			end,
		},
		diseaseThresholdAmt = {
			order = 130,
			name = L["Amount"],
			desc = L["Amount"],
			type = "range",
			min = 0,
			max = 100000,
			step = 1,
			bigStep = 500,
			set = function(info, val)
			    self.db.profile.diseaseThresholdAmt = val
			end,
			get = function(info, val)
			    return self.db.profile.diseaseThresholdAmt
			end,
			disabled = function()
				return self.db.profile.diseaseThresholdType ~= "Fixed"
			end,
		},
		colorsHdr = {
	        order = 200,
	        type = "header",
	        name = L["Colors"],
		},
		reapplyThresh = {
			order = 210,
			name = L["ReapplyThreshold"],
			desc = L["ReapplyThreshold_Desc"],
			type = "color",
			hasAlpha = true,
			width = "full",
			set = function(info, r, g, b, a)
			    local c = self.db.profile.reapplycolors[2]
			    c.r, c.g, c.b, c.a = r, g, b, a
			end,
			get = function(info)
		        local c = self.db.profile.reapplycolors[2]
			    return c.r, c.g, c.b, c.a
			end,					
		},
		reapply = {
			order = 220,
			name = L["Reapply"],
			desc = L["Reapply_Desc"],
			type = "color",
			hasAlpha = true,
			width = "full",
			set = function(info, r, g, b, a)
			    local c = self.db.profile.reapplycolors[1]
			    c.r, c.g, c.b, c.a = r, g, b, a
			end,
			get = function(info)
		        local c = self.db.profile.reapplycolors[1]
			    return c.r, c.g, c.b, c.a
			end,					
		},
		noreapply = {
			order = 230,
			name = L["DontReapply"],
			desc = L["DontReapply_Desc"],
			type = "color",
			width = "full",
			hasAlpha = true,
			set = function(info, r, g, b, a)
			    local c = self.db.profile.reapplycolors[-1]
			    c.r, c.g, c.b, c.a = r, g, b, a
			end,
			get = function(info)
		        local c = self.db.profile.reapplycolors[-1]
			    return c.r, c.g, c.b, c.a
			end,					
		},
		nodisease = {
			order = 240,
			name = L["NoDisease"],
			desc = L["NoDisease_Desc"],
			type = "color",
			width = "full",
			hasAlpha = true,
			set = function(info, r, g, b, a)
			    local c = self.db.profile.reapplycolors[0]
			    c.r, c.g, c.b, c.a = r, g, b, a
			end,
			get = function(info)
		        local c = self.db.profile.reapplycolors[0]
			    return c.r, c.g, c.b, c.a
			end,					
		},
		adjHdr = {
	        order = 300,
	        type = "header",
	        name = L["Adjustments"],
		},
	}

	local i = 301
	for name, val in pairs(self.db.profile.adjustments) do
		options["adjust"..name] = {
			name = SpellNames[name],
			desc = SpellNames[name],
			type = "toggle",
			order = i,
			set = function(info, val)
			    self.db.profile.adjustments[name] = val
			end,
            get = function(info)
				return self.db.profile.adjustments[name]
			end,
		}
		i = i + 1
	end

	return options
end

function DKDiseases:GetSoulReaperOptions()
	local options = {
		srEnabled = {
			name = L["Enabled"],
			desc = L["Enabled"],
			type = "toggle",
			order = 100,
			set = function(info, val)
			    self.db.profile.srFrame.enabled = val
				if self.srFrame then self.srFrame:Update() end
			end,
            get = function(info)
				return self.db.profile.srFrame.enabled
			end,
		},
		showValue = {
			name = L["Value"],
			desc = L["Value"],
			type = "toggle",
			order = 110,
			set = function(info, val)
			    self.db.profile.srFrame.showText = val
				if self.srFrame then self.srFrame:Update() end
			end,
            get = function(info)
				return self.db.profile.srFrame.showText
			end,
		},
		srPercent = {
			order = 120,
			name = L["Percent"],
			desc = L["Percent"],
			type = "range",
			min = 0.01,
			max = 1.0,
			step = 0.01,
			bigStep = 0.05,
			isPercent = true,
			set = function(info, val)
			    self.db.profile.srFrame.percent = val
			end,
			get = function(info, val)
			    return self.db.profile.srFrame.percent
			end,
			disabled = function()
				return self.db.profile.srFrame.alwaysShow
			end,
		},
		alwaysShow = {
			name = L["Always Show"],
			desc = L["Always Show"],
			type = "toggle",
			order = 115,
			set = function(info, val)
			    self.db.profile.srFrame.alwaysShow = val
				self.soulReaperRange = nil
				if self.srFrame then
					if val then self.srFrame:Show() else self.srFrame:Hide() end
					self:UpdateSoulReaperCheck()
				end
			end,
            get = function(info)
				return self.db.profile.srFrame.alwaysShow
			end,
		},
		onlyShowHB = {
			name = L["Only Show HB"],
			desc = L["OnlyShowHB_Desc"],
			type = "toggle",
			order = 115,
			set = function(info, val)
			    self.db.profile.srFrame.onlyShowHB = val
			end,
            get = function(info)
				return self.db.profile.srFrame.onlyShowHB
			end,
		},
		width = {
			order = 120,
			name = L["Width"],
			desc = L["Width"],	
			type = "range",
			min = 20,
			max = 500,
			step = 1,
			set = function(info, val)
			    DKDiseases.db.profile.srFrame.width = val
				if self.srFrame then self.srFrame:SetDimensions() end
			end,
			get = function(info, val)
			    return DKDiseases.db.profile.srFrame.width
			end,
		},
		height = {
			order = 130,
			name = L["Height"],
			desc = L["Height"],	
			type = "range",
			min = 20,
			max = 500,
			step = 1,
			set = function(info, val)
			    DKDiseases.db.profile.srFrame.height = val
				if self.srFrame then self.srFrame:SetDimensions() end
			end,
			get = function(info, val)
			    return DKDiseases.db.profile.srFrame.height
			end,
		},
		x = {
			order = 140,
			name = L["X Offset"],
			desc = L["XOffset_Desc"],	
			type = "range",
			softMin = -math.floor(_G.GetScreenWidth()),
			softMax = math.floor(_G.GetScreenWidth()),
			bigStep = 1,
			set = function(info, val)
			    DKDiseases.db.profile.srFrame.x = val
				if self.srFrame then self.srFrame:SetDesiredPoint() end
			end,
			get = function(info, val)
			    return DKDiseases.db.profile.srFrame.x
			end,
		},
		y = {
			order = 150,
			name = L["Y Offset"],
			desc = L["YOffset_Desc"],	
			type = "range",
			softMin = -math.floor(_G.GetScreenHeight()),
			softMax = math.floor(_G.GetScreenHeight()),
			bigStep = 1,
			set = function(info, val)
			    DKDiseases.db.profile.srFrame.y = val
				if self.srFrame then self.srFrame:SetDesiredPoint() end
			end,
			get = function(info, val)
			    return DKDiseases.db.profile.srFrame.y
			end,
		},
	}
	return options
end

function DKDiseases:OnInitialize()
    -- Load the settings
    self.db = _G.LibStub("AceDB-3.0"):New("DKDiseasesDB", defaults, "Default")
	self:SetLDBDataDisplay()

	--self:MigrateSettings()

	-- Register for profile callbacks
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChange")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChange")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChange")
	
	Icon:Register("DKDiseasesLDB", Broker.obj, self.db.profile.minimap)
	LSM.RegisterCallback(DKDiseases, "LibSharedMedia_Registered")
end

function DKDiseases:OnProfileChange()
	--self:MigrateSettings()
	self:Reset()
end

function DKDiseases:Reset()
	--self:ResetFonts()
	--self:UpdateTextures()

	for name, display in pairs(self.registeredDisplays) do
		if display and display.Reset then
			display:Reset()
		end
	end
end

function DKDiseases:LibSharedMedia_Registered(event, mediatype, key)
	if _G.strlen(self.db.profile.font_face) > 1 and mediatype == "font" then
		if self.db.profile.font_face == key then
			self:ResetFonts()
		end
	end
	if mediatype == "statusbar" then
	    self:UpdateTextures()
	end
end

function DKDiseases:ResetFonts()
	for name, display in pairs(self.registeredDisplays) do
		if display and display.ResetFonts then
			display:ResetFonts()
		end
	end
end

function DKDiseases:UpdateTextures()
	for name, display in pairs(self.registeredDisplays) do
		if display and display.UpdateTexture then
			display:UpdateTexture()
		end
	end
end

local function splitWords(str)
  local w = {}
  local function helper(word) table.insert(w, word) return nil end
  str:gsub("(%w+)", helper)
  return w
end

local function GetNumericValue(...)
    for i = 1, _G.select("#", ...) do
        local region = _G.select(i, ...)
        if region and region:GetObjectType() == "FontString" then
            local regionText = region:GetText()
            if regionText then
                local valueText = regionText:match("[0-9,]+")
                if valueText then
					valueText = valueText:gsub(",","")
                    local value = tonumber(valueText)
                    if value then
                        return value
                    end
                end
            end
        end
    end
end

local TipFrame = nil
function DKDiseases:VerifyDiseaseDamage()
	if not TipFrame then
		TipFrame = _G.CreateFrame("GameTooltip", "DKDiseases_TipFrame", nil, "GameTooltipTemplate")
		TipFrame:SetOwner(_G.WorldFrame, "ANCHOR_NONE")
	end

	TipFrame:ClearLines()
	TipFrame:SetSpellByID(SpellIds["Frost Fever"])
	local baseFF = GetNumericValue(TipFrame:GetRegions())
	TipFrame:ClearLines()
	TipFrame:SetSpellByID(SpellIds["Blood Plague"])
	local baseBP = GetNumericValue(TipFrame:GetRegions())

	self:CalculateDiseaseDamage()
	self:Print("Tooltip vs Calculated Values:")
	local fmt = "%s: Tooltip = %d,  Calculated = %d [Effective = %d]"
	self:Print(fmt:format("Frost Fever", baseFF, 
		round(self.base.ff), round(self.eff.ff)))
	self:Print(fmt:format("Blood Plague", baseBP, 
		round(self.base.bp), round(self.eff.bp)))
end

function DKDiseases:ChatCommand(input)
    if not input or input:trim() == "" then
        self:ShowOptions()
    else
		local cmds = splitWords(input)
        if cmds[1] and cmds[1] == "debug" then
			if cmds[2] and cmds[2] == "on" then
				self.db.profile.debug = true
	            self:Print("Debugging on.  Use '/dkdiseases debug off' to disable.")
		    elseif cmds[2] and cmds[2] == "off" then
				self.db.profile.debug = false
	            self:Print("Debugging off.")
			else
				self:Print("Debugging is "..(self.db.profile.debug and "on." or "off."))
			end
        elseif cmds[1] and cmds[1] == "debugBP" then
			if cmds[2] and cmds[2] == "on" then
				self.db.profile.debugBP = true
	            self:Print("Debugging BP on.")
		    elseif cmds[2] and cmds[2] == "off" then
				self.db.profile.debugBP = false
	            self:Print("Debugging BP off.")
			else
				self:Print("Debugging BP is "..(self.db.profile.debugBP and "on." or "off."))
			end
		elseif cmds[1] and cmds[1] == "verify" then
			self:VerifyDiseaseDamage()
		elseif cmds[1] and cmds[1] == "baseline" then
			if cmds[2] and cmds[2] == "set" then
				self:CalculateBaseline()
			end
			local fmt = "Baseline: FF = %s, BP = %s"
			self:Print(fmt:format(FormatNumber(self.baseline.ff or 0), 
				FormatNumber(self.baseline.bp or 0)))
		elseif cmds[1] and cmds[1] == "srvshb" then
			local fmt = "SR vs HB: SR = %s [%s + %s], HB = %s"
			self:Print(fmt:format(
				FormatNumber((self.soulReaper1 or 0)+(self.soulReaper2 or 0)),
				FormatNumber(self.soulReaper1 or 0), 
				FormatNumber(self.soulReaper2 or 0), 
				FormatNumber(self.howlingBlast or 0)))

		end
	end
end

local MandatoryEvents = {
	"PLAYER_TALENT_UPDATE",
	"PLAYER_SPECIALIZATION_CHANGED",
	"UNIT_LEVEL",
	"PLAYER_EQUIPMENT_CHANGED",
	"UNIT_ENTERED_VEHICLE",
	"UNIT_EXITED_VEHICLE",
	"PLAYER_GAINS_VEHICLE_DATA",
	"PLAYER_LOSES_VEHICLE_DATA",
}
function DKDiseases:OnEnable()
	for i = 1, #MandatoryEvents do
		self:RegisterEvent(MandatoryEvents[i])
	end
	LoadSpellNames()
    self:CheckTalents()
	self:ToggleDiseaseTracking()
	--self:Load()
	--self:CheckEnabled()

	if not self.optionsFrame then
		-- Register Options
	    local displayName = _G.GetAddOnMetadata(ADDON_NAME, "Title")
		self:GetOptions()
	    _G.LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable(displayName, options)

	    self.optionsFrame = {}
	    local ACD = _G.LibStub("AceConfigDialog-3.0")
		self.optionsFrame.Main = ACD:AddToBlizOptions(
		    displayName, displayName, nil, "core")
		--self.optionsFrame.Layout = ACD:AddToBlizOptions(
		--    displayName, L["Layout"], displayName, "layout")
		ACD:AddToBlizOptions(
		    displayName, options.args.profile.name, displayName, "profile")
	    -- Register the chat command
	    self:RegisterChatCommand("dkdiseases", "ChatCommand")
	end
end

local WatchedEvents = {
	"PLAYER_REGEN_DISABLED",
	"PLAYER_REGEN_ENABLED",
	"PLAYER_TARGET_CHANGED",
	"PLAYER_FOCUS_CHANGED",
	"COMBAT_LOG_EVENT_UNFILTERED",
	"PLAYER_ENTERING_WORLD",
}
local WatchedUnitEvents = {
	["target"] = {"UNIT_AURA"},
	["focus"] = {"UNIT_AURA"},
}
local function EventFrame_OnEvent(frame, event, ...)
	if event == "UNIT_ATTACK_POWER" then
		DKDiseases:UNIT_ATTACK_POWER(event, ...)
	elseif event == "UNIT_STATS" then
		DKDiseases:UNIT_STATS(event, ...)
	elseif event == "UNIT_AURA" then
		DKDiseases:UNIT_AURA(event, ...)
	elseif event == "UNIT_HEALTH" then
		DKDiseases:UNIT_HEALTH(event, ...)
	end
end
local EventFrames = {}
local WatchedUnits = { "player", "target", "focus" }
for i, unit in ipairs(WatchedUnits) do
	if not EventFrames[unit] then
		local frame = _G.CreateFrame("Frame", ADDON_NAME.."_EventFrame_"..unit)
		frame:SetScript("OnEvent", EventFrame_OnEvent)
		EventFrames[unit] = frame
	end
end

function DKDiseases:Load()
	if self.isDK then
		self:CreateOrUpdateAllDisplays()
		if self.db.profile.specs[self.currentSpec] then
			for name, display in pairs(self.displays) do
				if display and display.Show then
					display:Show()
				end
			end	
			for i = 1, #WatchedEvents do
				self:RegisterEvent(WatchedEvents[i])
			end
			for unit, events in pairs(WatchedUnitEvents) do
				local eventFrame = EventFrames[unit]
				if eventFrame then
					for i, event in ipairs(events) do
						eventFrame:RegisterUnitEvent(event, unit)
					end
				else
					self:Print("Missing event frame for "..tostring(unit).."!")
				end
			end
		end
		self:CreateSoulReaperCheck()
		self:UpdateSoulReaperCheck()
	end
end

function DKDiseases:Unload()
	for i = 1, #WatchedEvents do
		self:UnregisterEvent(WatchedEvents[i])
	end
	for unit, events in pairs(WatchedUnitEvents) do
		local eventFrame = EventFrames[unit]
		if eventFrame then
			for i, event in ipairs(events) do
				eventFrame:UnregisterEvent(event)
			end
		end
	end
	self:ToggleDiseaseTracking(false)
	for name, display in pairs(self.displays) do
		if display and display.Disable then display:Disable() end
	end
end

function DKDiseases:OnDisable()
	self:Unload()
end

local StrUnitEvents = {
	["player"] = {"UNIT_ATTACK_POWER", "UNIT_STATS", "UNIT_AURA"},
}

local DiseaseStrengthEvents = {
	"PLAYER_DAMAGE_DONE_MODS",
	"COMBAT_RATING_UPDATE",
}
function DKDiseases:ToggleDiseaseTracking(flag)
	local enable = flag ~= nil and flag or self.db.profile.trackDiseases
	if self.isDK and enable then
		for i = 1, #DiseaseStrengthEvents do
			self:RegisterEvent(DiseaseStrengthEvents[i])
		end
		for unit, events in pairs(StrUnitEvents) do
			local eventFrame = EventFrames[unit]
			if eventFrame then
				for i, event in ipairs(events) do
					eventFrame:RegisterUnitEvent(event, unit)
				end
			else
				self:Print("Missing event frame for "..tostring(unit).."!")
			end
		end
		self:UpdateAllStats()
	else
		for i = 1, #DiseaseStrengthEvents do
			self:UnregisterEvent(DiseaseStrengthEvents[i])
		end
		for unit, events in pairs(StrUnitEvents) do
			local eventFrame = EventFrames[unit]
			if eventFrame then
				for i, event in ipairs(events) do
					eventFrame:UnregisterEvent(event)
				end
			end
		end
	end
end

function DKDiseases:CheckEnabled()
	if self.isDK and self.db.profile.specs[self.currentSpec] then
		self:Load()
	else
		self:Unload()
	end
end

function DKDiseases:CheckTalents()
    local class, className = _G.UnitClass("player")
    if className then
        if (className == 'DEATH KNIGHT' or className == 'DEATHKNIGHT') then
            self.isDK = true

			local activeSpecNum = _G.GetSpecialization()
			if activeSpecNum and activeSpecNum > 0 then
				local id, name, desc, texture = _G.GetSpecializationInfo(activeSpecNum)
		    	if texture == "Interface\\Icons\\Spell_Deathknight_BloodPresence" then
					self.currentSpec = "Blood"
				elseif texture == "Interface\\Icons\\Spell_Deathknight_FrostPresence" then
					self.currentSpec = "Frost"
				elseif texture == "Interface\\Icons\\Spell_Deathknight_UnholyPresence" then
					self.currentSpec = "Unholy"
				else
					self:Print("Error detecing player spec.")
					self.currentSpec = "Blood"
				end
			end
        else
            self.isDK = false
        end
    end
	
	self:CheckEnabled()

	if not _G.UnitAffectingCombat("player") then
		self:CalculateBaseline()
	end

	if self.srFrame then self.srFrame:Update() end

	if self.db.profile.debug then
		local fmt = "CheckTalents [isDK=%s,spec=%s]"
		self:Print(
			fmt:format(tostring(self.isDK), self.currentSpec))
	end
end

local fontFlags = {}
function DKDiseases:GetFontSettings()
	wipe(fontFlags)
	for k, v in pairs(self.db.profile.fontFlags) do
		if v then tinsert(fontFlags, k) end
	end
	return self.db.profile.font_face, self.db.profile.font_size, tconcat(fontFlags, ",")
end

function DKDiseases:CreateSoulReaperCheck()
	if self.srFrame then return end

	local buttonName = "DKDiseases_SRCheck"
	local frame = _G.CreateFrame("Frame", "DKDiseases_SRCheck", _G.UIParent)
	self.srFrame = frame

	frame.SetDesiredPoint = function(frame)
		frame:ClearAllPoints()
		local profile = DKDiseases.db.profile.srFrame
		local x, y = profile.x, profile.y
    	frame:SetPoint("CENTER", _G.UIParent, "CENTER", x, y)
	end
	frame:SetDesiredPoint()
	frame.SetDimensions = function(frame)
	    frame:SetWidth(DKDiseases.db.profile.srFrame.width)
	    frame:SetHeight(DKDiseases.db.profile.srFrame.height)
	end
	frame:SetDimensions()

	frame.texture = frame:CreateTexture(nil, "ARTWORK")
    frame.texture:SetAllPoints(frame)
    frame.texture:SetVertexColor(1, 1, 1)
	if SpellIcons["Soul Reaper"] then
		frame.texture:SetTexture(SpellIcons["Soul Reaper"])
	end
	frame.showing = nil

    frame.border = frame:CreateTexture(nil, "BACKGROUND")
    frame.border:SetPoint("CENTER")
    frame.border:SetWidth(frame:GetWidth())
    frame.border:SetHeight(frame:GetHeight())

	frame.value = frame:CreateFontString(nil, "OVERLAY")
    frame.value:SetPoint("TOP", frame, "BOTTOM", 0, -4)
	local ff, fh, fflags = self:GetFontSettings()
	local font = LSM:Fetch("font", ff)
    frame.value:SetFont(font, fh, fflags)
    frame.value:SetJustifyH("CENTER")
	frame.value:SetJustifyV("CENTER")

	frame.ResetFonts = function()
		local ff, fh, fontFlags = self:GetFontSettings()
		local font = LSM:Fetch("font", ff)
		frame.value:SetFont(font, fh, fontFlags)						
		frame.value:SetText(frame.value:GetText())
	end

	frame.Update = function(self)
		local profile = DKDiseases.db.profile.srFrame
		DKDiseases:UpdateSoulReaperCheck()
		if profile.showText then
			self.value:Show()
		else
			self.value:Hide()
		end
	end

	frame.locked = true
	frame.Lock = function(self, locked)
		if locked ~= nil then
			self.locked = locked
		end
		self:EnableMouse(not self.locked)
	end
	frame.IsLocked = function(self)
		return self.locked
	end

    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",
        function(self, button)
			if not self.locked then
            	self:StartMoving()
			end
        end)
    frame:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			local profile = DKDiseases.db.profile.srFrame
			profile.x, profile.y = x, y
			profile.userPlaced = true
			self:SetUserPlaced(false)
        end)
	frame:Lock()

	if Masque then
		self.MasqueGroup = Masque:Group("DKDiseases", SpellNames["Soul Reaper"])
		frame.MasqueButtonData = {
			--Button = frame
			Icon = frame.texture,
			FloatingBG = false,
			Cooldown = false,
			Flash = false,
			Pushed = false,
			Normal = false,
			Disabled = false,
			Checked = false,
			Border = frame.border,
			AutoCastable = false,
			Highlight = false,
			HotKey = false,
			Count = false,
			Name = false,
			Duration = false,
			AutoCast = false,
		}
		self.MasqueGroup:AddButton(frame, frame.MasqueButtonData)
	end
end

function DKDiseases:UpdateSoulReaperCheck()
	if not self.isDK then return end

	local eventFrame = EventFrames["target"]
	if self.db.profile.srFrame.enabled and self.currentSpec and
		self.db.profile.srFrame.specs[self.currentSpec] then
		if self.db.profile.srFrame.alwaysShow then
			if eventFrame then
				eventFrame:UnregisterEvent("UNIT_HEALTH", "target")
			end
			self:UnregisterEvent("PLAYER_DEAD")
			self:UnregisterEvent("PLAYER_ALIVE")
			if self.srFrame then self.srFrame:Show() end
		else
			if eventFrame then
				eventFrame:RegisterUnitEvent("UNIT_HEALTH", "target")
			end
			self:RegisterEvent("PLAYER_DEAD")
			self:RegisterEvent("PLAYER_ALIVE")
			if self.srFrame then self.srFrame:Hide() end
		end
	else
		if self.srFrame then self.srFrame:Hide() end
	end
end

function DKDiseases:RegisterDisplay(name, object)
	self.registeredDisplays[name] = object
end

function DKDiseases:CreateOrUpdateAllDisplays()
	for i, unit in ipairs(self.units) do
		self:CreateOrUpdateDisplay(unit)
	end
end

function DKDiseases:CreateOrUpdateDisplay(unit)
	if not unit then return end

	if not self.db.profile.units[unit].enabled then
		if self.displays[unit] then
			self.displays[unit]:Disable()
		end
		return
	end

	local prev = nil
	if self.displays[unit] then
		prev = self.displays[unit].name
	end

	local display = self.db.profile.display[unit]
	if display and display ~= prev then
		if self.displays[unit] then
			self.displays[unit]:Disable()
		end

		local settings = self.db.profile.displays[display][unit]
		local registered = self.registeredDisplays[display]
		if settings and registered then
			local obj = registered:Create(unit)
			if obj then
				self.displays[unit] = obj
				self.diseases[unit].ff = obj.ff
				self.diseases[unit].bp = obj.bp
				obj:Enable()
			end
			if not self.displays[unit] then
				self:Print("Could not create the display!")
			end
		else
			self:Print("Could not find registered display!")
		end
	elseif display and display == prev then
		if self.displays[unit] and self.displays[unit].Show then
			self.displays[unit]:Show()
		end
	end
end

-- Frost Vulnerability from Razorice is dynamic.  No need to calculate it.
-- 5.1 FF: 143 + 0.138 * AP
-- 5.1 BP: 172 + 0.138 * AP
local BASEFF = 166
local BASEBP = 197
local APMOD = 0.158
function DKDiseases:CalculateDiseaseDamage()
	local dmgmod = self.damageModifier
	for name, val in pairs(self.adjustments) do
		if name and self.db.profile.adjustments[name] and self.adjustments[name] then
			dmgmod = dmgmod / self.adjustmentMods[name]
		end
	end

	local baseFF = (BASEFF + APMOD * self.effectiveAP) * dmgmod
	local baseBP = (BASEBP + APMOD * self.effectiveAP) * dmgmod

	if self.currentSpec == "Frost" then
		baseFF = baseFF * (1 + (2.0 * self.mastery / 100))

		-- Calculate use of SR vs HB
		self.soulReaper1 = self.avgWeaponDmg * 1.3 * self.physicalVulnerability
		self.soulReaper2 = self.soulReaperBase + (1.2 * self.effectiveAP) * 
			self.magicVulnerability
		self.howlingBlast = (499 + 0.8487 * self.effectiveAP) * 
			(1 + (2.0 * self.mastery / 100)) * self.frostVulnerability * 
			self.magicVulnerability
		local fmt = "%s - %s"
		if self.srFrame and self.db.profile.srFrame.enabled then
			self.srFrame.value:SetText(fmt:format(
				FormatNumber(self.soulReaper1 + self.soulReaper2),
				FormatNumber(self.howlingBlast)))
			local useSpell = "SR"
			if self.howlingBlast * self.spellCrit > 
				(self.soulReaper1 * self.critChance + 
				 self.soulReaper2 * self.spellCrit) then
				useSpell = "HB"
			end
			if useSpell ~= self.srFrame.showing then
				self.srFrame.texture:SetTexture(
					useSpell == "SR" and SpellIcons["Soul Reaper"] or 
						SpellIcons["Howling Blast"])
				self.srFrame.showing = useSpell
			end
		end
	elseif self.currentSpec == "Unholy" then
		baseFF = baseFF * 1.6
		baseBP = baseBP * (1 + (2.5 * self.mastery / 100)) * 1.6
	end

	local effFF = baseFF * (1 + self.critChance)
	local effBP = baseBP * (1 + self.critChance)

	if self.cinderglacier then
		effFF = effFF * 1.2
		effBP = effBP * 1.2
	end

	self.base.ff = baseFF
	self.base.bp = baseBP
	self.eff.ff = effFF
	self.eff.bp = effBP

	if self.db.profile.debug then
		local fmt = "FF: %d / %d, BP: %d/ %d"
		self:Print(fmt:format(
			round(baseFF), round(effFF), round(baseBP), round(effBP)))
	end

	self:CheckDiseases("target")
	self:CheckDiseases("focus")
end

function DKDiseases:CalculateBaseline()
	local baseFF = (BASEFF + APMOD * self.effectiveAP) * self.damageModifier
	local baseBP = (BASEBP + APMOD * self.effectiveAP) * self.damageModifier
	if self.currentSpec == "Frost" then
		baseFF = baseFF * (1 + (2.0 * self.mastery / 100))
	elseif self.currentSpec == "Unholy" then
		baseFF = baseFF * 1.6
		baseBP = baseBP * (1 + (2.5 * self.mastery / 100)) * 1.6
	end
	self.baseline.ff = baseFF * (1 + self.critChance)
	self.baseline.bp = baseBP * (1 + self.critChance)
	if self.db.profile.debug then
		local fmt = "Calculated baseline FF: %d,  BP: %d"
		self:Print(fmt:format(round(self.baseline.ff),round(self.baseline.bp)))
	end
end

local percFmt = "%.0f"
local reapplyFmt = "Reapply %s on %s [%d %s %d : %d (%.1f)]"
local diseases = { "ff", "bp" }
local refreshCurrFmt = "%s / %s"
function DKDiseases:CheckDiseases(unit)
	if self.current[unit] and self.db.profile.units[unit].enabled then
		local thresholdType = self.db.profile.diseaseThresholdType
		local thresholdPerc = self.db.profile.diseaseThreshold
		local thresholdAmt = self.db.profile.diseaseThresholdAmt
		for i, disease in ipairs(diseases) do
			local snapshot = self[disease][self.current[unit]] or 0
			local reapply = 0
			local perc = 0
			if snapshot > 0 then
				reapply = 1
				perc = self.eff[disease] / snapshot * 100
				if self.eff[disease] > snapshot then
					local threshold
					if thresholdType == "Fixed" then
						threshold = snapshot + thresholdAmt
					else
						threshold = snapshot * thresholdPerc
					end
					reapply = self.eff[disease] >= threshold and 2 or 1
				elseif self.eff[disease] < snapshot then
					reapply = -1
				end
				if self.db.profile.debug and reapply ~= 0 then
					local diff = self.eff[disease] - snapshot
					self:Print(reapplyFmt:format(
						disease:upper(), unit,
						round(self.eff[disease]), 
						reapply == -1 and "<" or ">",
						round(snapshot),
						diff, diff/snapshot*100))
				end
			end
			local obj = self.diseases[unit][disease]
			if obj then
				local txt = ""
				if self.db.profile.strengthValue == "Base" then
					txt = FormatNumber(self.base[disease])
				elseif self.db.profile.strengthValue == "Effective" then
					txt = FormatNumber(self.eff[disease])
				elseif self.db.profile.strengthValue == "Increase" then
					txt = FormatNumber(round(self.eff[disease]-self.baseline[disease]))
				elseif self.db.profile.strengthValue == "EffRef+C" then
					txt = refreshCurrFmt:format(
						FormatNumber(round(self.eff[disease])),
						FormatNumber(round(snapshot)))
				else
					txt = percFmt:format(perc)
				end
				obj:SetValue(txt)
				if reapply ~= obj.reapply then
					obj:UpdateColor(self.db.profile.reapplycolors[reapply])
				end
				obj.reapply = reapply
			end
		end
	end
end

function DKDiseases:CheckSoulReaper()
	if not self.db.profile.srFrame.enabled then
		if self.srFrame then self.srFrame:Hide() end
		return
	end
	if self.hostile.target and self.currentSpec == "Frost" and 
		not _G.UnitIsDeadOrGhost("player") then
		local health = _G.UnitHealth("target") or 0
		local percent = self.targetMaxHealth > 0 and 
			health / self.targetMaxHealth or 0
		local srRange = percent < self.db.profile.srFrame.percent and health > 0
		if self.db.profile.srFrame.onlyShowHB then
			if srRange and self.srFrame.showing == "HB" then
				self.srFrame:Show()
			else
				self.srFrame:Hide()
			end
		else
			if srRange ~= self.soulReaperRange then
				if srRange then
					self.srFrame:Show()
				else
					self.srFrame:Hide()
				end
				self.soulReaperRange = srRange
			end
		end
	else
		self.srFrame:Hide()
	end
end

function DKDiseases:PLAYER_DEAD()
	if self.srFrame and not self.db.profile.srFrame.alwaysShow then
		self.srFrame:Hide()
	end
end

function DKDiseases:PLAYER_ALIVE()
	if self.srFrame and not self.db.profile.srFrame.alwaysShow then
		self.srFrame:Hide()
	end
end

function DKDiseases:UNIT_LEVEL(event, unit)
	if unit == "player" then
		self:CheckTalents()
	end
end

function DKDiseases:UNIT_ATTACK_POWER(event, unit)
	if unit == "player" then
		self:UpdateAllStats()
	end
end

function DKDiseases:UNIT_STATS(event, unit)
	if unit == "player" then
		self:UpdateAllStats()
	end
end

function DKDiseases:UNIT_HEALTH(event, unit)
	if unit == "target" then
		self:CheckSoulReaper()
	end
end

function DKDiseases:PLAYER_DAMAGE_DONE_MODS(event, unit)
	if unit == "player" then
		self:UpdateAllStats()
	end
end

function DKDiseases:COMBAT_RATING_UPDATE()
	self:UpdateAllStats()
end

function DKDiseases:UpdateAllStats()
	local update = false

	local base, posBuff, negBuff = _G.UnitAttackPower("player")
	local effAP = base + posBuff - negBuff
	if effAP ~= self.effectiveAP then
		self.effectiveAP = effAP
		update = true
	end

	local wpnSpeed = _G.select(1, _G.UnitAttackSpeed("player")) * 
		(1 + _G.GetMeleeHaste() / 100)
	local apAdj = effAP / 14 * wpnSpeed
	local min, max = _G.UnitDamage("player")
	local avgWeaponDmg = (min + max) / 2 - apAdj
	if avgWeaponDmg ~= self.avgWeaponDmg then
		self.avgWeaponDmg = avgWeaponDmg
		update = true
	end

	local dmgMod = _G.select(7, _G.UnitDamage("player")) or 1.0
	if dmgMod ~= self.damageModifier then
		if self.db.profile.debugBP then
			local fmt = "Dmg Mod: %.2f"
			self:Print(fmt:format(dmgMod))
		end
		self.damageModifier = dmgMod
		update = true
	end

	local mastery = _G.GetMastery()
	if mastery ~= self.mastery then
		self.mastery = mastery
		update = true
	end

	local critChance = _G.GetCritChance() / 100
	if critChance > 1 then critChance = 1 end
	if critChance ~= self.critChance then
		self.critChance = critChance
		update = true
	end

	-- Get the spell crit chance for the Frost school
	local spellCrit = _G.GetSpellCritChance(5) / 100
	if spellCrit > 1 then spellCrit = 1 end
	if spellCrit ~= self.spellCrit then
		self.spellCrit = spellCrit
		update = true
	end

	if update then self:CalculateDiseaseDamage() end
end

local LastBPTick = {}
function DKDiseases:PLAYER_REGEN_DISABLED()
	-- Player has entered combat.
	for unit, display in pairs(self.displays) do
		if self.displays[unit] then
			self.displays[unit]:OnCombatEnter()
		end
	end
	if self.db.profile.debugBP then wipe(LastBPTick) end
end

function DKDiseases:PLAYER_REGEN_ENABLED()
	-- Player has left combat.
	for unit, display in pairs(self.displays) do
		if self.displays[unit] then
			self.displays[unit]:OnCombatLeave()
		end
	end
end

function DKDiseases:PLAYER_TARGET_CHANGED(unit)
	self.current.target = _G.UnitGUID("target")
	self.hostile.target = _G.UnitExists("target") and 
		_G.UnitCanAttack("player", "target") and
		not _G.UnitIsDead("target")
	self.soulReaperRange = nil
	self.targetMaxHealth = _G.UnitHealthMax("target") or 0
	if self.displays.target and self.displays.target.Show then
		self.displays.target:Show()
	end
	if self.displays.target and self.db.profile.units.target.enabled then
		if not self.current.target and self.displays.target.ClearDisplay then
			self.displays.target:ClearDisplay()
		end
		self:UNIT_AURA("UNIT_AURA", "target")
		self.diseases.target.ff.reapply = nil
		self.diseases.target.bp.reapply = nil
		self:CheckDiseases("target")
	end
	if self.db.profile.srFrame.enabled and not self.db.profile.srFrame.alwaysShow then
		self:CheckSoulReaper()
	end
end

function DKDiseases:PLAYER_FOCUS_CHANGED(unit)
	self.current.focus = _G.UnitGUID("focus")
	self.hostile.focus = _G.UnitExists("target") and 
		_G.UnitCanAttack("player", "target") and
		not _G.UnitIsDead("target")
	if self.displays.focus and self.displays.focus.Show then 
		self.displays.focus:Show()
	end
	if self.displays.focus and self.db.profile.units.focus.enabled then
		if not self.current.focus and self.displays.target.ClearDisplay then
			self.displays.focus:ClearDisplay()
		end
		self:UNIT_AURA("UNIT_AURA", "focus")
		self.diseases.focus.ff.reapply = nil
		self.diseases.focus.bp.reapply = nil
		self:CheckDiseases("focus")
	end
end

local diseases
local magicDebuffs
function DKDiseases:UNIT_AURA(event, unit)
	local name, rank, icon, count, dispelType, duration, expires, 
		caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
		isBossDebuff, castByPlayer, value1, value2, value3 

	if unit == "target" or unit == "focus" then
		diseases = diseases or {
			[SpellNames["Frost Fever"]] = "ff",
			[SpellNames["Blood Plague"]] = "bp",
		}

		for spell, id in pairs(diseases) do
			local display = self.diseases[unit][id]
			if display then
				name, rank, icon, count, dispelType, duration, expires, 
				caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
				isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitDebuff(unit, spell, nil, "PLAYER")

				if name then
					local timeLeft = expires - _G.GetTime()
					display:OnDiseaseRefreshed(duration, expires)
				else
					display:OnDiseaseRemoved()
				end
			end
		end

		if unit == "target" then
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
			= _G.UnitDebuff(unit, SpellNames["Frost Vulnerability"], nil, "PLAYER")
			if name then
				self.frostVulnerability = 1 + (0.03 * (count or 0))
			else
				self.frostVulnerability = 1.0
			end

			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
			= _G.UnitDebuff(unit, SpellNames["Physical Vulnerability"])
			if name then
				self.physicalVulnerability = 1 + 0.04
			else
				self.physicalVulnerability = 1.0
			end

			magicDebuffs = magicDebuffs or {
				[SpellNames["Curse of Elements"]] = "Curse of Elements",
				[SpellNames["Lightning Breath"]] = "Lightning Breath",
				[SpellNames["Master Poisoner"]] = "Master Poisoner",
			}
			local magicVuln = false
			for spell, id in pairs(magicDebuffs) do
				name, rank, icon, count, dispelType, duration, expires, 
				caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
				isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitDebuff(unit, spell)
				if name then magicVuln = true; break end
			end
			if magicVuln then
				self.magicVulnerability = 1 + 0.05
			else
				self.magicVulnerability = 1.0
			end
		end
	elseif unit == "player" then
		local calculate = false
		if self.db.profile.trackDiseases then
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitBuff("player", SpellNames["Cinderglacier"])
			local cinder = (name ~= nil)
			if cinder ~= self.cinderglacier then
				self.cinderglacier = cinder
				calculate = true
			end
		end
		if self.db.profile.adjustments["Tricks of the Trade"] then
			name, rank, icon, count, dispelType, duration, expires, 
			caster, isStealable, shouldConsolidate, spellId, canApplyAura, 
			isBossDebuff, castByPlayer, value1, value2, value3 
				= _G.UnitBuff("player", SpellNames["Tricks of the Trade"])
			local tricks = (name ~= nil)
			if tricks ~= self.adjustments["Tricks of the Trade"] then
				self.adjustments["Tricks of the Trade"] = tricks
				calculate = true
			end
		end
		if calculate then self:CalculateDiseaseDamage() end
	end
end

function DKDiseases:PLAYER_SPECIALIZATION_CHANGED(event)
	self:CheckTalents()
end

function DKDiseases:PLAYER_TALENT_UPDATE(event)
	self:CheckTalents()
end

local AuraEvents = {
	SPELL_AURA_APPLIED = "APPLIED",
	SPELL_AURA_REFRESH = "REFRESH",
	SPELL_AURA_REMOVED = "REMOVED"
}
local DiseaseMap = nil
function DKDiseases:COMBAT_LOG_EVENT_UNFILTERED(...)
    local event, timestamp, eventtype, hideCaster, 
        srcGUID, srcName, srcFlags, srcRaidFlags, 
        destGUID, destName, destFlags, destRaidFlags, 
        param9, param10, param11, param12, param13, param14, 
        param15, param16, param17, param18, param19, param20

    event, timestamp, eventtype, hideCaster, 
    srcGUID, srcName, srcFlags, srcRaidFlags,
    destGUID, destName, destFlags, destRaidFlags,
    param9, param10, param11, param12, param13, param14, 
    param15, param16, param17, param18, param19, param20 = ...

	if srcGUID == self.playerGUID then
		if (self.db.profile.debugBP or LDBDataFeed) and 
			eventtype == "SPELL_PERIODIC_DAMAGE" and 
			param9 == SpellIds["Blood Plague Periodic"] and
			destGUID and not param18 and
			(destGUID == self.current.target or destGUID == self.current.focus) then
			if math.abs(param12 - (LastBPTick[destGUID] or 0)) > 1 then
				LastBPTick[destGUID] = param12
				if destGUID == self.current.target then
					DataFeed.lastBP = param12
					UpdateLDBData()
				end
				if self.db.profile.debugBP then
					local fmt = "New BP Tick: %d on %s"
					self:Print(fmt:format(LastBPTick[destGUID], tostring(destGUID)))
				end
			end
		end

		local auraType = AuraEvents[eventtype]
		if auraType then
			DiseaseMap = DiseaseMap or {
				[SpellIds["Frost Fever"]] = "ff",
				[SpellIds["Frost Fever Periodic"]] = "ff",
				[SpellIds["Blood Plague"]] = "bp",
				[SpellIds["Blood Plague Periodic"]] = "bp",
			}
			local disease = DiseaseMap[param9]
			if disease then
				local units = {target = false, focus = false}
				for unit, process in pairs(units) do
					if destGUID == self.current[unit] then units[unit] = true end
				end			
				if auraType == "APPLIED" or auraType == "REFRESH" then
					if disease then
						self[disease][destGUID] = self.eff[disease]
						for unit, process in pairs(units) do
							if process then
								self:CheckDiseases(unit)
							end
						end
					end
				elseif auraType == "REMOVED" then
					self[disease][destGUID] = nil
					for unit, process in pairs(units) do
						if process then
							if self.diseases[unit][disease] then
								self.diseases[unit][disease].reapply = nil
							end
						end
					end
				end
			end
		end
	end
end

function DKDiseases:PLAYER_ENTERING_WORLD(event)
	self.playerGUID = _G.UnitGUID("player") or ""
	self:UNIT_AURA("PLAYER_ENTERING_WORLD", "player")
	self:CalculateBaseline()
end

function DKDiseases:PLAYER_EQUIPMENT_CHANGED(event)
	if not _G.UnitAffectingCombat("player") then
		self:CalculateBaseline()
	end
end

function DKDiseases:CheckPlayerStatus()
	local changed = false
	local inVehicle = _G.UnitUsingVehicle("player")
	if inVehicle ~= self.inVehicle then
		self.inVehicle = inVehicle
		changed = true
	end
	if changed then
		for unit, display in pairs(self.displays) do
			if display and display.Show then
				display:Show()
			end
		end
	end
end

function DKDiseases:UNIT_ENTERED_VEHICLE(event)
	self:CheckPlayerStatus()
end

function DKDiseases:UNIT_EXITED_VEHICLE(event)
	self:CheckPlayerStatus()
end

function DKDiseases:PLAYER_GAINS_VEHICLE_DATA(event)
	self:CheckPlayerStatus()
end

function DKDiseases:PLAYER_LOSES_VEHICLE_DATA(event)
	self:CheckPlayerStatus()
end
