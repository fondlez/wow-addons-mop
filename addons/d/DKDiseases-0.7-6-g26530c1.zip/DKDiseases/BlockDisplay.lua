local _G = getfenv(0)
local string = _G.string
local pairs = _G.pairs
local math = _G.math
local tostring = _G.tostring

local DKDiseases = LibStub("AceAddon-3.0"):GetAddon("DKDiseases")
local L = _G.LibStub("AceLocale-3.0"):GetLocale("DKDiseases", true)
local LSM = _G.LibStub:GetLibrary("LibSharedMedia-3.0")

local BlockDisplay = {}
local BlockDisease = {}
local MIN_UPDATE_TIME = DKDiseases.MIN_UPDATE_TIME
local displays = {}
local round = DKDiseases.round

BlockDisplay.__index = BlockDisplay

BlockDisplay.options = {}
BlockDisplay.name = "Block"
BlockDisplay.displayName = "Block Display"

function BlockDisplay:IsDiseased()
	return (self.ff and self.ff.diseased) or (self.bp and self.bp.diseased)
end

function BlockDisplay:Show(force)
	if force or (DKDiseases.isDK and 
		not (DKDiseases.db.profile.units[self.unit].hideooc and 
			not _G.UnitAffectingCombat("player")) 
		and DKDiseases.db.profile.specs[DKDiseases.currentSpec]
		and DKDiseases.db.profile.units[self.unit].enabled and
		(DKDiseases.hostile[self.unit] or 
		not DKDiseases.db.profile.units[self.unit].hideNotAttackable) and
		(self:IsDiseased() or 
		not DKDiseases.db.profile.units[self.unit].hideNoDiseases) and
		(not DKDiseases.inVehicle or
		not DKDiseases.db.profile.units[self.unit].hideInVehicle)) then
		self.frame:Show()
	else
		self.frame:Hide()
	end
end

function BlockDisplay:Hide()
	self.frame:Hide()
end

function BlockDisplay:Enable()
	self:Show()
end

function BlockDisplay:Disable()
	self:Hide()
end

function BlockDisplay:Lock(locked)
	if locked == nil then return end
	for name, display in pairs(displays) do
		if display then
			display.frame.lock = locked
			display.frame:EnableMouse(not locked and display.db.attached)
			if display.ff then
				display.ff.frame.lock = locked
				display.ff.frame:EnableMouse(not locked and not display.db.attached)
			end
			if display.bp then
				display.bp.frame.lock = locked
				display.bp.frame:EnableMouse(not locked and not display.db.attached)
			end
		end
	end
end

function BlockDisplay:GetOptions(unit)
	if not self.options[unit] then
		self.options[unit] = {
		    dimensions = {
		        order = 100,
		        type = "header",
		        name = L["Dimensions"],
			},
			width = {
				order = 110,
				name = L["Width"],
				desc = L["BarWidth_Desc"],	
				type = "range",
				min = 20,
				max = 100,
				step = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].width = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Block[unit].width
				end,
			},
			height = {
				order = 120,
				name = L["Height"],
				desc = L["BarHeight_Desc"],
				type = "range",
				min = 5,
				max = 50,
				step = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].height = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Block[unit].height
				end,					
			},
		    strValue = {
		        order = 200,
		        type = "header",
		        name = L["Strength Value"],
			},
			strengthFontSize = {
				order = 210,
				name = L["Font size"],
				desc = L["Font size"],
				type = "range",
				min = 8,
				max = 30,
				step = 1,
				set = function(info, val) 
					DKDiseases.db.profile.displays.Block[unit].strengthFontSize = val
					if displays[unit] then
						displays[unit]:ResetFonts()
					end
				end,
				get = function(info,val)
					return DKDiseases.db.profile.displays.Block[unit].strengthFontSize
				end,
			},
		    icon = {
		        order = 300,
		        type = "header",
		        name = L["Icon"],
			},
			iconEnabled = {
				order = 310,
				name = L["Enabled"],
				desc = L["Enabled"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].cooldown = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Block[unit].cooldown
				end,
			},
			reverseCD = {
				order = 320,
				name = L["Reverse"],
				desc = L["Reverse_Desc"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].reverseCooldown = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Block[unit].reverseCooldown
				end,
			},
		    timerValue = {
		        order = 400,
		        type = "header",
		        name = L["Timer Value"],
			},
			timerEnabled = {
				order = 410,
				name = L["Enabled"],
				desc = L["Enabled"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].timer = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Block[unit].timer
				end,
			},
			timerFontSize = {
				order = 420,
				name = L["Font size"],
				desc = L["Font size"],
				type = "range",
				min = 8,
				max = 30,
				step = 1,
				set = function(info, val) 
					DKDiseases.db.profile.displays.Block[unit].timerFontSize = val
					if displays[unit] then
						displays[unit]:ResetFonts()
					end
				end,
				get = function(info,val)
					return DKDiseases.db.profile.displays.Block[unit].timerFontSize
				end,
			},
		    layout = {
		        order = 500,
		        type = "header",
		        name = L["Layout"],
			},
			background = {
				order = 505,
				name = L["Background"],
				desc = L["Background_OptDesc"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].background = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Block[unit].background
				end,
			},
			detached = {
				order = 510,
				name = L["Attached"],
				desc = L["Attached_OptDesc"],
				type = "toggle",
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].attached = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
	            get = function(info)
					return DKDiseases.db.profile.displays.Block[unit].attached
				end,
			},
			x = {
				order = 520,
				name = L["X Offset"],
				desc = L["XOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenWidth()),
				softMax = math.floor(_G.GetScreenWidth()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].x = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Block[unit].x
				end,
				disabled = function()
					return not DKDiseases.db.profile.displays.Block[unit].attached
				end,
			},
			y = {
				order = 530,
				name = L["Y Offset"],
				desc = L["YOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenHeight()),
				softMax = math.floor(_G.GetScreenHeight()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit].y = val
					if displays[unit] then
						displays[unit]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Block[unit].y
				end,
				disabled = function()
					return not DKDiseases.db.profile.displays.Block[unit].attached
				end,
			},
		}

		local diseases = { ["Frost Fever"] = "ff", ["Blood Plague"] = "bp" }
		local i = 0
		for disease, obj in pairs(diseases) do
			self.options[unit][disease.." Header"] = {
		        order = 1000+100*i,
		        type = "header",
		        name = DKDiseases.SpellNames[disease],
			}
			self.options[unit][disease.." X"] = {
				order = 1001+100*i,
				name = L["X Offset"],
				desc = L["XOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenWidth()),
				softMax = math.floor(_G.GetScreenWidth()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit][disease].x = val
					if displays[unit] and displays[unit][obj] then
						displays[unit][obj]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Block[unit][disease].x
				end,
				disabled = function()
					return DKDiseases.db.profile.displays.Block[unit].attached
				end,
			}
			self.options[unit][disease.." Y"] = {
				order = 1001+100*i,
				name = L["Y Offset"],
				desc = L["YOffset_Desc"],	
				type = "range",
				softMin = -math.floor(_G.GetScreenWidth()),
				softMax = math.floor(_G.GetScreenWidth()),
				bigStep = 1,
				set = function(info, val)
				    DKDiseases.db.profile.displays.Block[unit][disease].y = val
					if displays[unit] and displays[unit][obj] then
						displays[unit][obj]:UpdateLayout()
					end
				end,
				get = function(info, val)
				    return DKDiseases.db.profile.displays.Block[unit][disease].y
				end,
				disabled = function()
					return DKDiseases.db.profile.displays.Block[unit].attached
				end,
			}
			i = i + 1
		end
	end
	return self.options[unit]
end

function BlockDisplay:GetFF()
	return self.ff
end

function BlockDisplay:GetBP()
	return self.bp
end

function BlockDisplay:GetBlockHeight()
	if self.db.cooldown then
		return self.db.height * 2 + self.db.inset * 2
	else
		return self.db.height + self.db.inset
	end
end

function BlockDisplay:GetBlockWidth()
	return self.db.width + self.db.inset * 2
end

function BlockDisplay:ClearDisplay()
	if self.ff then self.ff:OnDiseaseRemoved() end
	if self.bp then self.bp:OnDiseaseRemoved() end
end

function BlockDisplay:UpdateLayout()
	self.frame:EnableMouse(self.db.attached and not self.frame.lock)
	self.frame:SetPoint("CENTER", _G.UIParent, "CENTER", self.db.x, self.db.y)
	self.frame:SetWidth(self:GetBlockWidth() * 2)
	self.frame:SetHeight(self:GetBlockHeight())
	if self.ff then self.ff:UpdateLayout() end
	if self.bp then self.bp:UpdateLayout() end

	local alpha = _G.UnitAffectingCombat("player") and
		DKDiseases.db.profile.units[self.unit].combatAlpha
		or DKDiseases.db.profile.units[self.unit].ooc_alpha
	self.frame:SetAlpha(alpha)
end

function BlockDisplay:ResetFonts()
	if self.ff then self.ff:ResetFonts() end
	if self.bp then self.bp:ResetFonts() end
end

function BlockDisplay:Create(unit)
	if displays[unit] then return displays[unit] end
	local object = _G.setmetatable({}, BlockDisplay)
	object.unit = unit
	object.unitName = unit:gsub("^%l", string.upper)
	object:Initialize()
	displays[unit] = object
	return object
end

function BlockDisplay:Initialize()
	self.db = DKDiseases.db.profile.displays[self.name][self.unit]
	local frame = _G.CreateFrame("Frame", 
		"DKDiseases_"..self.name.."_"..self.unitName, _G.UIParent)
	self.frame = frame
	frame.obj = self

	frame:SetPoint("CENTER", _G.UIParent, "CENTER", self.db.x, self.db.y)
	--frame.lock = self.db.locked
	frame.lock = DKDiseases.db.profile.locked
    frame:SetMovable(true)
	self:UpdateLayout()

    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",
        function(self, button)
			if not self.lock then
            	self:StartMoving()
			end
        end)
    frame:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.obj.db.x, self.obj.db.y = x, y
			self:SetUserPlaced(false);
        end)
    frame:EnableMouse(not frame.lock and self.db.attached)

	self.ff = BlockDisease:Create("Frost Fever", self)
	self.bp = BlockDisease:Create("Blood Plague", self)

	return self
end

function BlockDisplay:OnCombatEnter()
	self.frame:SetAlpha(DKDiseases.db.profile.units[self.unit].combatAlpha)
	self:Show()
end

function BlockDisplay:OnCombatLeave()
	self.frame:SetAlpha(DKDiseases.db.profile.units[self.unit].ooc_alpha)
	if DKDiseases.db.profile.units[self.unit].hideooc then
		self.frame:Hide()
	end
end

DKDiseases:RegisterDisplay("Block", BlockDisplay)

-- Block Disease

BlockDisease.__index = BlockDisease

function BlockDisease:Create(name, parent)
	local object = _G.setmetatable({}, BlockDisease)
	object.name = name
	object.parent = parent
	object.db = DKDiseases.db.profile.displays[parent.name][parent.unit]
	object:Initialize()
	return object
end

local function onUpdateDisease(self, elapsed)
	self.lastUpdate = (self.lastUpdate or 0) + elapsed
	self.timer = self.timer - elapsed
	if self.lastUpdate >= MIN_UPDATE_TIME then
		self.lastUpdate = 0
		if self.active then
			if self.timer < 0 then
				self.timer = 0
				self.active = false
			end
		
			self.time:SetText(tostring(round(self.timer)))
			self.time:Show()
		else
			self.time:SetText("0")
			self.time:Hide()
			self:SetScript("OnUpdate", nil)
		end
	end
end

function BlockDisease:Initialize()
	local baseName = self.parent.frame:GetName()
	self.varName = self.name:gsub(" ", "")
	self.diseased = false
	local frame = _G.CreateFrame("Frame", 
		baseName.."_"..self.name.."_Block", self.parent.frame)
	self.frame = frame
	frame.obj = self
	frame.parentFrame = self.parent.frame

    frame.value = frame:CreateFontString(nil, "OVERLAY")
    frame.value:SetPoint("TOP", frame, "TOP", 0, -self.db.inset * 3)
    frame.value:SetJustifyH("CENTER")
	frame.value:Hide()

    local icon = _G.CreateFrame("Frame", baseName..self.name.."_Icon", frame)
	self.icon = icon
	icon:SetAllPoints()
	icon.texture = icon:CreateTexture(nil, "ARTWORK")
    icon.texture:SetAllPoints(icon)
    icon.texture:SetVertexColor(1, 1, 1)
	icon.texture:SetTexture(DKDiseases.SpellIcons[self.name])
	icon.cd = _G.CreateFrame("Cooldown", baseName..self.name.."_IconCD", icon)
	-- Prevent other addons from adding a timer overlay
	icon.cd.noOCC = true
	icon.cd.icon = icon
	self.iconcd = icon.cd
	icon.cd:SetAllPoints()
	icon:Show()

    self.iconcd.time = self.iconcd:CreateFontString(nil, "OVERLAY")
    self.iconcd.time:SetPoint("CENTER")
    self.iconcd.time:SetJustifyH("CENTER")
	self.iconcd.time:Hide()

	self:ResetFonts()

	frame.lock = DKDiseases.db.profile.locked
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",
        function(self, button)
			if not self.lock then
            	self:StartMoving()
			end
        end)
    frame:SetScript("OnDragStop",
        function(self)
            self:StopMovingOrSizing()
			local scale = self:GetEffectiveScale() / _G.UIParent:GetEffectiveScale()
			local x, y = self:GetCenter()
			x, y = x * scale, y * scale
			x = x - _G.GetScreenWidth()/2
			y = y - _G.GetScreenHeight()/2
			x = x / self:GetScale()
			y = y / self:GetScale()
			self.obj.db[self.obj.name].x, self.obj.db[self.obj.name].y = x, y
			self:SetUserPlaced(false);
        end)
    frame:EnableMouse(self.db.attached and not frame.lock)

	self:UpdateLayout()
	self:UpdateColor()
end

function BlockDisease:Show()
	self.frame:Show()
end

function BlockDisease:Hide()
	self.frame:Hide()
end

function BlockDisease:UpdateColor(color)
	local c = color or DKDiseases.db.profile.reapplycolors[0]
	self.frame:SetBackdropColor(c.r, c.g, c.b, c.a)
end

function BlockDisease:SetValue(value)
	self.frame.value:SetText(value)
end

function BlockDisease:OnDiseaseRefreshed(duration, expires)
	self.diseased = true
	local timeLeft = expires - _G.GetTime()
	self.frame.value:Show()
	if self.db.cooldown then
		self.iconcd:SetCooldown(expires - duration, duration)
		if self.db.timer then
			self.iconcd.active = true
			self.iconcd.timer = timeLeft
			self.iconcd:SetScript("OnUpdate", onUpdateDisease)
		end
	end
	self.parent:Show()
end

function BlockDisease:OnDiseaseRemoved()
	self.diseased = false
	self.frame.value:Hide()
	self:UpdateColor()
	self.iconcd:SetCooldown(0,0)
	self.iconcd:SetScript("OnUpdate", nil)
	self.iconcd.active = false 
	self.iconcd.timer = 0
	self.iconcd.time:Hide()
	self.parent:Show()
end

function BlockDisease:UpdateLayout()
	local frame = self.frame
	frame:EnableMouse(not self.db.attached and not frame.lock)
	frame:SetWidth(self.parent:GetBlockWidth())
	frame:SetHeight(self.parent:GetBlockHeight())
	if self.db.cooldown then
		self.icon:Show()
	else
		self.icon:Hide()
	end
	self.icon:SetHeight(self.db.height)
	self.icon:SetWidth(self.db.width)
	self.icon:ClearAllPoints()
	self.icon:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 
		self.db.inset, 
		self.db.inset)

	local ordering = {
		["BF"] = {
			["Blood Plague"] = 1,
			["Frost Fever"] = 2,
		},
		["FB"] = {
			["Frost Fever"] = 1,
			["Blood Plague"] = 2,
		},
		["F"] = {
			["Frost Fever"] = 1,
			["Blood Plague"] = 0,
		},
		["B"] = {
			["Blood Plague"] = 1,
			["Frost Fever"] = 0,
		},
	}
	frame:ClearAllPoints()
	local order = ordering[DKDiseases.db.profile.diseaseOrder][self.name]

	if not self.db.attached then
		frame:SetPoint("CENTER", _G.UIParent, "CENTER", 
			self.db[self.name].x, self.db[self.name].y)
	else
		if order == 1 then
			frame:SetPoint("BOTTOMLEFT", frame.parentFrame, "BOTTOMLEFT", 0, 0)
		else
			frame:SetPoint("BOTTOMRIGHT", frame.parentFrame, "BOTTOMRIGHT", 0, 0)
		end
	end
	if order == 0 then
		frame:Hide()
	else
		frame:Show()
	end

	if not self.db.timer and self.iconcd.time then
		self.iconcd.time:Hide()
	end

	if self.db.background then
		frame:SetBackdrop({
			bgFile = "Interface\\Buttons\\WHITE8X8", 
			edgeFile = "",
			tile = true, tileSize = 16, edgeSize = 16,
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
			})
		self:UpdateColor()
	else
		frame:SetBackdrop(nil)
	end

	self.iconcd:SetReverse(self.db.reverseCooldown and true or false)
end

function BlockDisease:ResetFonts()
	local ff, fh, fflags = DKDiseases:GetFontSettings()
	local font = LSM:Fetch("font", ff)
    self.frame.value:SetFont(font, self.db.strengthFontSize or fh, fflags)
	self.frame.value:SetText(self.frame.value:GetText())
   	local tc = self.db.textcolor
   	self.frame.value:SetTextColor(tc.r, tc.g, tc.b, tc.a)
	if self.iconcd and self.iconcd.time then
	    self.iconcd.time:SetFont(font, self.db.timerFontSize or fh, fflags)
		self.iconcd.time:SetText(self.iconcd.time:GetText())
	   	local tc = self.db.timercolor
	   	self.iconcd.time:SetTextColor(tc.r, tc.g, tc.b, tc.a)
	end
end
