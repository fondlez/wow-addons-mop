DBM_Archaeology_Translations = {}

local L = DBM_Archaeology_Translations

L.TabCategory_Archaeology	= "Archaeology"
L.AreaGeneral 			= "Archaeology Settings"
L.Enable				= "Enable Archaeology"
L.DBM_LOOT_MSG			= "([^%s]+).*Hitem:(%d+)"
