if GetLocale() ~= "koKR" then return end

local L = DBM_Archaeology_Translations

L.TabCategory_Archaeology	= "Archaeology"--Translate
L.AreaGeneral 			= "Archaeology Settings"--Translate
L.Enable				= "Enable Archaeology"--Translate
L.DBM_LOOT_MSG			= "([^%s]+).*Hitem:(%d+)"--Translate?
