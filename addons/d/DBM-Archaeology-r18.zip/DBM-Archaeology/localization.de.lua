if GetLocale() ~= "deDE" then return end

local L = DBM_Archaeology_Translations

L.TabCategory_Archaeology	= "Archäologie"--Translate
L.AreaGeneral 			= "Archäologie Settings"--Translate
L.Enable				= "Enable Archäologie"--Translate
L.DBM_LOOT_MSG			= "([^%s]+).*Hitem:(%d+)"--Translate?
