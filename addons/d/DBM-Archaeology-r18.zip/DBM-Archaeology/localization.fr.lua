﻿if GetLocale() ~= "frFR" then return end

local L = DBM_Archaeology_Translations

L.TabCategory_Archaeology	= "Archéologie"--Translate
L.AreaGeneral 			= "Archaeology Settings"--Translate
L.Enable				= "Enable Archaeology"--Translate
L.DBM_LOOT_MSG			= "([^%s]+).*Hitem:(%d+)"--Translate?
