local AL = LibStub("AceLocale-3.0")

local silent = true

local L = AL:GetLocale("DXE")
if not L then
    local L = AL:NewLocale("DXE", "enUS", true, silent)
end

if L then
	-- Chat triggers
	local chat_SiegeOfOrgrimmar = AL:NewLocale("DXE Chat SiegeOfOrgrimmar", "enUS", true, silent)
	AL:GetLocale("DXE").chat_SiegeOfOrgrimmar = AL:GetLocale("DXE Chat SiegeOfOrgrimmar")
	-- NPC names
	local npc_SiegeOfOrgrimmar = AL:NewLocale("DXE NPC SiegeOfOrgrimmar", "enUS", true, silent)
	AL:GetLocale("DXE").npc_SiegeOfOrgrimmar = AL:GetLocale("DXE NPC SiegeOfOrgrimmar")
	if GetLocale() == "enUS" or GetLocale() == "enGB" then return end
end

local L = AL:NewLocale("DXE", "deDE")
if L then
	-- Chat triggers
	local chat_SiegeOfOrgrimmar = AL:NewLocale("DXE Chat SiegeOfOrgrimmar", "deDE")
	-- Immerseus
	chat_SiegeOfOrgrimmar["(Ah, you have done it!)"] = "(Ah, Ihr habt es geschafft!)"
	-- Galakras
	chat_SiegeOfOrgrimmar["(The door barring the South Tower has been breached!)"] = "(Das Tor zum Südturm ist durchbrochen!)"
	chat_SiegeOfOrgrimmar["(The door barring the North Tower has been breached!)"] = "(Das Tor zum Nordturm ist durchbrochen!)"
	chat_SiegeOfOrgrimmar["North Tower"] = "Nördlicher Turm"
	chat_SiegeOfOrgrimmar["South Tower"] = "Südlicher Turm"
	chat_SiegeOfOrgrimmar["Tower Defender"] = "Turmverteidiger"
	chat_SiegeOfOrgrimmar["(Here they come!)"] = "(Da kommen sie!)"
	chat_SiegeOfOrgrimmar["(Bring her down quick so i can wrap my fingers around her neck.)"] = "(Holt sie schnell vom Himmel, damit ich sie erwürgen kann.)"
	chat_SiegeOfOrgrimmar["(Dragonmaw, advance!)"] = "(Drachenmalklan, ausrücken!)"
	chat_SiegeOfOrgrimmar["(For Hellscream!)"] = "(Für Höllschrei!)"
	chat_SiegeOfOrgrimmar["(Next squad, push forward!)"] = "(Nächster Trupp, vorwärts!)"
	-- General Nazgrim
	chat_SiegeOfOrgrimmar["(Defend the gate!)"] = "(Verteidigt das Tor!)"
	chat_SiegeOfOrgrimmar["(Rally the forces!)"] = "(Truppen, sammelt Euch!)"
	chat_SiegeOfOrgrimmar["(Next squad, to the front!)"] = "(Nächste Staffel, nach vorn!)"
	chat_SiegeOfOrgrimmar["(Warriors, on the double!)"] = "(Krieger, im Laufschritt!)"
	chat_SiegeOfOrgrimmar["(Kor'kron, at my side!)"] = "(Kor'kron, zu mir!)"
	chat_SiegeOfOrgrimmar["(All Kor'kron... under my command... kill them... NOW!)"] = "(Alle Kor'kron unter meinem Befehl, tötet sie! Jetzt!)"
	-- Spoils Of Pandaria
	chat_SiegeOfOrgrimmar["(System resetting. Don't turn the power off, or the whole thing will probably explode.)"] = "(System wird neu gestartet. Die Energieversorgung muss stabil bleiben, sonst fliegt die ganze Chose in die Luft.)"
	-- SiegecrafterBlackfuse
	chat_SiegeOfOrgrimmar["(An Automated Shredder draws near!)"] = "(Ein automatisierter Schredder nähert sich!)"
	chat_SiegeOfOrgrimmar["(Unfinished weapons begin to roll out on the assembly line.)"] = "(Unfertige Waffen werden auf das Fabrikationsband befördert.)"
	-- Thok
	chat_SiegeOfOrgrimmar["Cage opened"] = "Käfig geöffnet"
	
	AL:GetLocale("DXE").chat_SiegeOfOrgrimmar = AL:GetLocale("DXE Chat SiegeOfOrgrimmar")
	-- NPC names
	local npc_SiegeOfOrgrimmar = AL:NewLocale("DXE NPC SiegeOfOrgrimmar", "deDE")
	--npc_SiegeOfOrgrimmar["Crawler Mine"]
	--npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"]
	--npc_SiegeOfOrgrimmar["Corrupted Fragment"]
	--npc_SiegeOfOrgrimmar["Dragonmaw Tidal Shaman"]

	AL:GetLocale("DXE").npc_SiegeOfOrgrimmar = AL:GetLocale("DXE NPC SiegeOfOrgrimmar")
	return
end

local L = AL:NewLocale("DXE", "ruRU")
if L then
	-- Chat triggers
	local chat_SiegeOfOrgrimmar = AL:NewLocale("DXE Chat SiegeOfOrgrimmar", "ruRU")
	-- Immerseus
	chat_SiegeOfOrgrimmar["(Ah, you have done it!)"] = "(У вас получилось!)"
	-- Galakras
	chat_SiegeOfOrgrimmar["(The door barring the South Tower has been breached!)"] = "(Дверь южной башни разбита!)"
	chat_SiegeOfOrgrimmar["(The door barring the North Tower has been breached!)"] = "(Дверь северной башни разбита!)"
	chat_SiegeOfOrgrimmar["North Tower"] = "Северная башня"
	chat_SiegeOfOrgrimmar["South Tower"] = "Защитник башни"
	chat_SiegeOfOrgrimmar["Tower Defender"] = "Защитник башни"
	chat_SiegeOfOrgrimmar["(Here they come!)"] = "(Вот и они!)"
	chat_SiegeOfOrgrimmar["(Bring her down quick so i can wrap my fingers around her neck.)"] = "(Сбейте ее скорее, не терпится взять ее за глотку.)"
	chat_SiegeOfOrgrimmar["(Dragonmaw, advance!)"] = "(Драконья Пасть, вперед!)"
	chat_SiegeOfOrgrimmar["(For Hellscream!)"] = "(За Гарроша!)"
	chat_SiegeOfOrgrimmar["(Next squad, push forward!)"] = "(Следующий отряд!)"
	-- General Nazgrim
	chat_SiegeOfOrgrimmar["(Defend the gate!)"] = "(Удерживайте врата!)"
	chat_SiegeOfOrgrimmar["(Rally the forces!)"] = "(Сомкнуть ряды!)"
	chat_SiegeOfOrgrimmar["(Next squad, to the front!)"] = "(Следующий отряд, вперед!)"
	chat_SiegeOfOrgrimmar["(Warriors, on the double!)"] = "(Воины, бегом!)"
	chat_SiegeOfOrgrimmar["(Kor'kron, at my side!)"] = "(Кор'крон, ко мне!)"
	chat_SiegeOfOrgrimmar["(All Kor'kron... under my command... kill them... NOW!)"] = "(Кор'кронцы... все, кто со мной! Убейте их!)"
	-- Spoils Of Pandaria
	chat_SiegeOfOrgrimmar["(System resetting. Don't turn the power off, or the whole thing will probably explode.)"] = "(Система перезагружается. Не выключать питание, иначе возможен взрыв.)"
	-- SiegecrafterBlackfuse
	chat_SiegeOfOrgrimmar["(An Automated Shredder draws near!)"] = "(Приближается автоматический крошшер!)"
	chat_SiegeOfOrgrimmar["(Unfinished weapons begin to roll out on the assembly line.)"] = "(На сборочную линию начинает поступать незаконченное оружие.)"
	-- Thok
	chat_SiegeOfOrgrimmar["Cage opened"] = "Клетка открыта"
	
	AL:GetLocale("DXE").chat_SiegeOfOrgrimmar = AL:GetLocale("DXE Chat SiegeOfOrgrimmar")
	-- NPC names
	local npc_SiegeOfOrgrimmar = AL:NewLocale("DXE NPC SiegeOfOrgrimmar", "deDE")
	npc_SiegeOfOrgrimmar["Crawler Mine"] = "Ползучая мина"
    npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"] = "Слияние скверны"
    npc_SiegeOfOrgrimmar["Corrupted Fragment"] = "Оскверненный осколок"
    npc_SiegeOfOrgrimmar["Dragonmaw Tidal Shaman"] = "Шаман приливов из клана Драконьей Пасти"
	
    npc_SiegeOfOrgrimmar["Galakras"] = "Галакрас"
    npc_SiegeOfOrgrimmar["Fallen Protectors"] = "Павшие защитники"
    npc_SiegeOfOrgrimmar["Garrosh Hellscream"] = "Гаррош Адский Крик"
    npc_SiegeOfOrgrimmar["General Nazgrim"] = "Генерал Назгрим"
    npc_SiegeOfOrgrimmar["Immersus"] = "Глубиний"
    npc_SiegeOfOrgrimmar["Iron Juggernaut"] = "Железный исполин"
    npc_SiegeOfOrgrimmar["Korkron Dark Shaman"] = "Тёмные шаманы"
    npc_SiegeOfOrgrimmar["Malkorok"] = "Малкорок"
    npc_SiegeOfOrgrimmar["Norushen"] = "Норусхен"
    npc_SiegeOfOrgrimmar["Paragons of the Klaxxi"] = "Идеалы клакси"
    npc_SiegeOfOrgrimmar["Sha of Pride"] = "Ша Гордыни"
    npc_SiegeOfOrgrimmar["Siege of Orgrimmar"] = "Сокровища пандарии"
    npc_SiegeOfOrgrimmar["Thok the Bloodthirsy"] = "Ток кровожадный"
    npc_SiegeOfOrgrimmar["Siegecrafter Blackfuse"] = "Мастер осады Черноплавс"
	
	AL:GetLocale("DXE").npc_SiegeOfOrgrimmar = AL:GetLocale("DXE NPC SiegeOfOrgrimmar")
	return
end
