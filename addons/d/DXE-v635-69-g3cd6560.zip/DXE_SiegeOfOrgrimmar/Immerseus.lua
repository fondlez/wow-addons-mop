local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 3,
		key = "Immersus",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Immersus"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-IMMERSEUS.BLP:35:35",
		triggers = {
			scan = {71543}, 
		},
		onactivate = {
			tracing = {71543,powers={true}},
			tracerstart = true,
			combatstop = true,
			delayrecombat = 45,
			--defeat = {71543},
			defeat = L.chat_SiegeOfOrgrimmar["(Ah, you have done it!)"],
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
			timeflex = 600,
			timelfr = 600,
		},
		windows = {
			proxwindow = true,
		},
		userdata = {

		},
		onstart = {
			{
				"alert",{"CorrisiveBlastcd", time = 2},
				"alert",{"Swirlcd", time = 3},
			},
			{
				"expect",{"&heroic&","==","true"},
				"alert",{"SwellingCorruptioncd", time = 2},
			},
		},
		messages = {
			mShaBolt = {
				varname = format(L.alert["%s!"],SN[143295]),
				type = "message",
				text = format(L.alert["%s!"],SN[143295]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 7985,
				icon = ST[143295],
				throttle = 2,
			},
			mCorrisiveBlast = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143436]),
				type = "message",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143436]),
				color1 = "INDIGO",
				icon = ST[143436],
				ability = 7988,
				sound = "ALERT13",
				exdps = true,
			},
			mCorrisiveBlastStacks = {
				varname = format(L.alert["%s %s %s (2)"],SN[143436],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)!"],SN[143436],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)!"],SN[143436],L.alert["on"]),
				color1 = "INDIGO",
				icon = ST[143436],
				ability = 7988,
				sound = "ALERT13",
				exdps = true,
			},			
			mSwirl = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143309]),
				type = "message",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143309]),
				color1 = "ORANGE",
				icon = ST[143309],
				ability = 7987,
				sound = "ALERT13",
			},			
		},
		alerts = {
			CorrisiveBlastcd = {
				varname = format(L.alert["%s Cooldown"],SN[143436]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143436]),
				time = 35,
				time2 = 6,
				time3 = 14,
				color1 = "GREEN",
				icon = ST[143436],
				ability = 7988,
				exdps = true,
			},
			ShaBoltcd = {
				varname = format(L.alert["%s Cooldown"],SN[143295]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143295]),
				time = 6,
				color1 = "NEWBLUE",
				icon = ST[143295],
				ability = 7985,
				enabled = false,
			},
			Swirlcd = {
				varname = format(L.alert["%s Cooldown"],SN[143309]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143309]),
				time = 48.5,
				time2 = 24,
				time3 = 20,
				color1 = "RED",
				icon = ST[143309],
				ability = 7987,
			},
			SwellingCorruptioncd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[143578]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143578]),
				time = 75,
				time2 = 17,
				color1 = "RED",
				icon = ST[143574],
				ability = 7987,
			},
			-- Alert
			wSplit = {
				varname = format(L.alert["%s!"],SN[143020]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143020]),
				time = 2,
				color1 = "INDIGO",
				icon = ST[143020],
				ability = 7992,
				sound = "ALERT14",
			},
			wReform = {
				varname = format(L.alert["%s!"],SN[143469]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143469]),
				time = 2,
				color1 = "INDIGO",
				icon = ST[143469],
				ability = 8332,
				sound = "ALERT14",
			},
			wSwellingCorruption = {
				varname = "(H) "..format(L.alert["%s!"],SN[143578]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143578]),
				time = 2,
				color1 = "RED",
				icon = ST[143574],
				ability = 7992,
				sound = "ALERT11",
			},
			wSwellingCorruptionFades = {
				varname = "(H) "..format(L.alert["%s - %s!"],SN[143578],L.alert["Removed"]),
				type = "simple",
				text = format(L.alert["%s - %s!"],SN[143578],L.alert["Removed"]),
				time = 2,
				color1 = "GREEN",
				icon = ST[143574],
				ability = 7992,
				sound = "ALERT9",
			},
			--[[wShaBolt = {
				varname = format(L.alert["%s!"],SN[143293]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143293]),
				time = 2,
				color1 = "CYAN",
				icon = ST[143293],
				sound = "ALERT10",
				ability = 7985,
				throttle = 3,
			},--]]
			-- Inform
			iShaSplash = {
				varname = format(L.alert["%s %s, %s!"],SN[143297],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[143297],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[143297],
				sound = "ALERT10",
				ability = 7985,
				throttle = 2,
				flashscreen = true,
			},	
			-- Cast
			PurifiedResidueActive = {
				varname = format(L.alert["%s Active"],SN[143524]),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143524]),
				time = 15,
				color1 = "BLUE",
				icon = ST[143524],
				ability = 7997,
				tag = "#5#",
			},
			ShaResiduoActive = {
				varname = format(L.alert["%s Active"],SN[143459]),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143459]),
				time = 10,
				color1 = "INDIGO",
				icon = ST[143459],
				ability = 7994,
				tag = "#5#",
			},					
			-- Debuff
			CorrisiveBlastDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143436]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143436]),
				text2 = format(L.alert["#5# (1): %s"],SN[143436]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143436]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143436]),
				time = 30,
				color1 = "ORANGE",
				ability = 8130,
				icon = ST[143494],
				tag = "#5#",
				exdps = true,
			},	
			--[[ShaResiduoDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143459]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143459]),
				text2 = format(L.alert["#5#: %s"],SN[143459]),
				time = 10,
				color1 = "INDIGO",
				icon = ST[143459],
				ability = 7994,
				tag = "#5#",
			},--]]
		},
		events = {
			-- CorrisiveBlast
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143436},
				execute = {
					{
						"alert","CorrisiveBlastcd",
						"message","mCorrisiveBlast",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143436},
				execute = {
					{
						"expect",{"&istargettank|#5#&","==","true"},
						"message","mCorrisiveBlastStacks",
						"invoke", {
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","CorrisiveBlastDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"CorrisiveBlastDebuff", text = 2},
							},							
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143436},
				execute = {
					{
						"expect",{"&istargettank|#5#&","==","true"},
						"message",{"mCorrisiveBlastStacks", text = 2},
						"invoke", {
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert",{"CorrisiveBlastDebuff", text = 3},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"CorrisiveBlastDebuff", text = 4},
							},							
						},
					},
				},
			},
			-- Swirl
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143309},
				execute = {
					{
						"alert","Swirlcd",
						"message","mSwirl",
					},
				},
			},
			-- ShaSplash
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143297},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iShaSplash",
					},
				},
			},
			-- Sha Residue
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143459},
				dstisplayerunit = true,
				execute = {
					{
						--"expect",{"#4#","==","&playerguid&"},
						"alert","ShaResiduoActive",
					},
				--	{
				--		"expect",{"#4#","~=","&playerguid&"},
				--		"alert",{"ShaResiduoDebuff", text = 2},
				--	},	
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143459},
				execute = {
					{
						"quash","ShaResiduoActive",
					},
				},
			},
			-- Purified Residue
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143524},
				dstisplayerunit = true,
				execute = {
					{
						--"expect",{"#4#","==","&playerguid&"},
						"alert","PurifiedResidueActive",
					},	
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143524},
				dstisplayerunit = true,
				execute = {
					{
						"quash","PurifiedResidueActive",
					},
				},
			},
			-- Sha Bolt splash
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE", -- 1st
				spellid = {143295},
				dstisplayerunit = true,
				execute = {
					{
						"alert","ShaBoltcd",
						"message","mShaBolt",
					},
				},
			},		
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_DAMAGE",
				spellid = {143297},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iShaSplash",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_MISSED",
				spellid = {143297},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iShaSplash",
					},
				},
			},
			-- Swelling Corruption
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143574},
				execute = {
					{
						"batchalert",{"SwellingCorruptioncd","wSwellingCorruption"},
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143574},
				execute = {
					{
						"alert","wSwellingCorruptionFades",
					},
				},
			},
			--[[{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							--{
							--	"expect",{"#5#","==","143293"}, -- Sha Bolt
							--	"batchalert",{"ShaBoltcd","wShaBolt"},
							--},
							{
								"expect",{"#5#","==","143578"}, -- Swelling Corruption
								"batchalert",{"SwellingCorruptioncd","wSwellingCorruption"},
							},
						},
					},
				},
			},--]]
			-- Emotes
			{
				type = "event",
				event = "EMOTE", 
				execute = {
					-- Reforms
					{
						"expect",{"#1#","find","spell:143469"}, 
						"alert","wReform",
						"alert",{"Swirlcd", time = 2},
						"alert",{"CorrisiveBlastcd", time = 3}, -- 14?
						"invoke",{
							{
								"expect",{"&heroic&","==","true"},
								"alert",{"SwellingCorruptioncd", time = 2},
							},
						},
					},
					-- Split
					{
						"expect",{"#1#","find","spell:143020"}, 
						"alert","wSplit",
						"batchquash",{"CorrisiveBlastcd","ShaBoltcd","Swirlcd","SwellingCorruptioncd"},
					},
				},
			},	
		},
	}

	DXE:RegisterEncounter(data)
end
