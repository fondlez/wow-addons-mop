local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 2,
		key = "Garrosh Hellscream",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Garrosh Hellscream"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-GARROSH HELLSCREAM.BLP:35:35",
		triggers = {
			scan = {71865}, 
		},
		onactivate = {
			tracing = {71865},
			tracerstart = true,
			combatstop = true,
			defeat = {71865},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 900,
			time25n = 900,
			time10h = 900,
			time25h = 900,
			timeflex = 900,
			timelfr = 900,
		},
		raidicons = {
			AddMark = {
				varname = L.npc_SiegeOfOrgrimmar["Farseer Wolf Rider"],
				type = "MULTIENEMY",
				persist = 60,
				unit = "<Add>",
				--id = 71983,
				reset = 7,
				icon = 1,
				total = 7,
			},
		},
		arrows = {
			TouchOfYShaarjarrow = {
				varname = SN[145065].." - "..L.alert["Free him!"],
				unit = "#5#",
				persist = 20,
				action = "TOWARD",
				msg = L.alert["Free him!"],
				spell = SN[145065],
				sound = "ALERT5",
				lockon = true,
				range1 = 1,
				range2 = 1,
				range3 = 1,
			},
		},	
		announces = { 
			Desecratesay = {
				varname = format(L.alert["%s %s %s!"],SN[144748],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[144748],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[144748],
			},
			Malicesay = {
				varname = "(H) "..format(L.alert["%s %s %s!"],SN[147209],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[147209],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[147209],
			},			
		},
		timers = {
			listTouchOfYShaarj = {
				{
					"message","mTouchOfYShaarj",
				},
			},
			listEmpTouchOfYShaarj = {
				{
					"message","EmpmTouchOfYShaarj",
				},
			},		
			timerMalice = {
				{
					"message","mMalice",
				},
			},				
		},		
		userdata = {
			phase = 1,
			firstIronStar = 0,
			mindcontrol = 0,
			wCount = 0,
			Add = "",
			Farseer = {type = "container"},
			TouchOfYShaarjunits = {type = "container", wipein = 3},
			EmpTouchOfYShaarjunits = {type = "container", wipein = 3},
			Maliceunists = {type = "container", wipein = 3},
		},
		onstart = {
			{
				"alert",{"Desecratecd", time = 2},
				"alert",{"SiegeEngineercd", time = 2},
				"alert",{"HellscreamsWarsongcd", time = 2},
				"alert",{"FarseerWolfRidercd", time = 2},
			},
		},
		messages = {
			mMalice = {
				varname = format(L.alert["%s %s %s"],SN[147209],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Maliceunists&"],SN[147209],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[147209],
			},				
			mDesecrate = {
				varname = format(L.alert["%s %s %s"],SN[144748],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[144748],L.alert["on"]),
				text2 = format(L.alert["%s!"],SN[144748]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144748],
			},
			mEmpDesecrate = {
				varname = format(L.alert["%s %s %s"],SN[144749],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[144749],L.alert["on"]),
				text2 = format(L.alert["%s!"],SN[144749]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144749],
			},			
			mTouchOfYShaarj = {
				varname = format(L.alert["%s %s %s"],SN[145065],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|TouchOfYShaarjunits&"],SN[145065],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[145065],
			},
			mEmpTouchOfYShaarj = {
				varname = format(L.alert["%s %s %s"],SN[145171],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|EmpTouchOfYShaarjunits&"],SN[145171],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[145171],
			},			
			mGrippingDispair = {
				varname = format(L.alert["%s %s %s"],SN[145183],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[145183],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[145183],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[145183],
			},
			mGrippingDispairEmp = {
				varname = format(L.alert["%s %s %s"],SN[145195],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[145195],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[145195],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[145195],
			},
			mYShaarjsProtection = {
				varname = format(L.alert["%s %s %s"],SN["ej8305"],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN["ej8305"],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8305,
				icon = EJST[8305],
			},	
			mAnnihilate = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144969]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144969]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8305,
				icon = EJST[8305],
			},
			mWhirlingCorruption = {
				varname = format(L.alert["%s %s (2)"],L.alert["Incoming"],SN[144985]),
				type = "message",
				text = format(L.alert["%s %s (<wCount>)"],L.alert["Incoming"],SN[144985]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144985],
			},	
			mEmpWhirlingCorruption = {
				varname = format(L.alert["%s %s (2)"],L.alert["Incoming"],SN[145037]),
				type = "message",
				text = format(L.alert["%s %s (<wCount>)"],L.alert["Incoming"],SN[145037]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[145037],
			},					
		},
		alerts = {
			-- Cooldowns
			FarseerWolfRidercd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8294"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8294"]),
				time = 50,
				time2 = 30,
				color1 = "NEWBLUE",
				icon = EJST[8294],
				ability = 8294,
			},
			SiegeEngineercd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8298"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8298"]),
				time = 40,
				time2 = 20,
				time3 = 45,
				color1 = "NEWBLUE",
				icon = EJST[8298],
				ability = 8298,
			},	
			TouchOfYShaarjcd = {
				varname = format(L.alert["%s Cooldown"],SN[145071]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[145071]),
				time = 45,
				time2 = 15,
				time3 = 30,
				time4 = 35,
				time4 = 42,
				color1 = "NEWBLUE",
				icon = ST[145071],
				ability = 8132,
			},	
			Desecratecd = {
				varname = format(L.alert["%s Cooldown"],SN[144748]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144748]),
				time = 35,
				time2 = 10,
				time3 = 41,
				time4 = 25,
				time5 = 21,
				color1 = "NEWBLUE",
				icon = ST[144748],
				ability = 8132,
			},
			HellscreamsWarsongcd = {
				varname = format(L.alert["%s Cooldown"],SN[144821]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144821]),
				time = 42.2,
				time2 = 22,
				color1 = "NEWBLUE",
				icon = ST[144821],
				ability = 8132,
				exdps = true,
			},
			WhirlingCorruptioncd = {
				varname = format(L.alert["%s Cooldown"],SN[144985]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144985]),
				time = 49.5,
				time2 = 30,
				time3 = 44.5,
				color1 = "NEWBLUE",
				icon = ST[144985],
				ability = 8132,
			},	
			EnterRealmcd = {
				varname = format(L.alert["%s Cooldown"],SN[144945]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144945]),
				time = 145.5,
				time2 = 25,
				color1 = "NEWBLUE",
				icon = ST[144945],
				ability = 8132,
			},			
			Bombardmentcd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[147120]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[147120]),
				time = 55,
				time2 = 70,
				color1 = "NEWBLUE",
				icon = ST[147120],
				ability = 8132,
			},		
			Malicecd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[147209]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[147209]),
				time = 29.5,
				time2 = 30,
				color1 = "NEWBLUE",
				icon = ST[147209],
				ability = 8132,
			},	
			-- Warning
			wManifestRage = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[147011]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[147011]),
				time = 2,
				color1 = "CYAN",
				icon = ST[147011],
				ability = 8132,
				sound = "ALERT10",
			},			
			wHellscreamsWarsong = {
				varname = format(L.alert["%s"],SN[144821]),
				type = "simple",
				text = format(L.alert["%s"],SN[144821]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[144821],
				ability = 8132,
				exdps = true,
				sound = "ALERT10",
			},
			wBombardment = {
				varname = "(H) "..format(L.alert["%s %s!"],L.alert["Incoming"],SN[147120]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[147120]),
				time = 2,
				color1 = "DCYAN",
				icon = EJST[8294],
				ability = 8294,
				sound = "ALERT10",
			},	
			wFarseerWolfRider = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN["ej8294"]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN["ej8294"]),
				time = 2,
				color1 = "RED",
				icon = EJST[8294],
				ability = 8294,
				sound = "ALERT10",
			},	
			wSiegeEngineer = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN["ej8298"]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN["ej8298"]),
				time = 2,
				color1 = "RED",
				icon = EJST[8298],
				ability = 8298,
				sound = "ALERT14",
			},
			Phase2 = {
				varname = format(L.alert["Phase 2"]),
				type = "simple",
				text = format(L.alert["Phase 2"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[145183],
				sound = "ALERT13",
			},
			Phase3 = {
				varname = format(L.alert["Phase 3"]),
				type = "simple",
				text = format(L.alert["Phase 3"]),
				time = 2,
				color1 = "GREEN",
				icon = ST[145037],
				sound = "ALERT13",
			},
			Phase4 = {
				varname = format(L.alert["Phase 4"]),
				type = "simple",
				text = format(L.alert["Phase 4"]),
				time = 2,
				color1 = "GREEN",
				icon = ST[147120],
				sound = "ALERT13",
			},			
		    -- Inform
			iGrippingDispairself = {
				varname = format(L.alert["%s: %s (2) %s!"],SN[145183],L.alert["already at"],L.alert["Stacks"]),
				type = "inform",
				text = format(L.alert["%s: %s (#11#) %s!"],SN[145183],L.alert["already at"],L.alert["Stacks"]),
				time = 2,
				color1 = "RED",
				sound = "ALERT14",
				icon = ST[145183],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			iGrippingDispairother = {
				varname = format(L.alert["%s: %s (2) %s!"],SN[145183],L.alert["already at"],L.alert["on"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s: %s (#11#) #5#!"],SN[145183],L.alert["already at"],L.alert["on"]),
				time = 2,
				color1 = "RED",
				sound = "ALERT14",
				icon = ST[145183],
				ability = 8132,
				exdps = true,
				exhealer = true,				
			},
			iMalice = {
				varname = "(H) "..format(L.alert["%s %s %s!"],SN[147209],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[147209],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "PURPLE",
				icon = ST[147209],
				sound = "ALERT10",
				ability = 8132,
			},			
			-- Cast
			SiegeEngineercast = {
				varname = format(L.alert["%s Active"],SN[144616]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[144616]),
				time = 15,
				color1 = "RED",
				icon = EJST[8298],
				ability = 8298,
				audiocd = true,
				audiotime = 10,
				tag = "#5#",
			},
			-- Debuff
			GrippingDispairDebuff = {
				varname = format(L.alert["%s Debuff"],SN[145183]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[145183]),
				text2 = format(L.alert["#5# (1): %s"],SN[145183]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[145183]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[145183]),
				time = 15,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[145183],
				tag = "#5#",
				exdps = true,
			},
			YShaarjsProtectionDebuff = {
				varname = format(L.alert["%s Debuff"],SN["ej8305"]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN["ej8305"]),
				text2 = format(L.alert["#5#: %s"],SN["ej8305"]),
				time = 61,
				color1 = "PURPLE",
				ability = 8305,
				icon = EJST[8305],
				tag = "#5#",
				exdps = true,
			},				
		},
		events = {
			-- YShaarjsProtection
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144945},
				execute = {
					{
						"message","mYShaarjsProtection",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","YShaarjsProtectionDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"YShaarjsProtectionDebuff", text = 2},
					},	
				},
			},
			-- TouchOfYShaarj
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145065},
				execute = {
					{
						"insert",{"TouchOfYShaarjunits","#5#"},
						"canceltimer","listTouchOfYShaarj",
						"scheduletimer",{"listTouchOfYShaarj",0.5},	
						"arrow","TouchOfYShaarjarrow",
					},
				},
			},			
			-- Emp TouchOfYShaarj
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145171},
				execute = {
					{
						"insert",{"EmpTouchOfYShaarjunits","#5#"},
						"canceltimer","listEmpTouchOfYShaarj",
						"scheduletimer",{"listEmpTouchOfYShaarj",0.5},
						"arrow","TouchOfYShaarjarrow",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {145065, 145171},
				execute = {
					{
						"removearrow","#5#",
					},							
				},
			},	
			-- MindControl
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {145065, 145171},
				execute = {
					{
						"set",{mindcontrol = "INCR|1"},
					},
					{
						"expect",{"<phase>","==","3"},
						"invoke",{
							{
								"expect",{"<mindcontrol>","==","1"},
								"alert",{"TouchOfYShaarjcd", time = 4},
							},
							{
								"expect",{"<mindcontrol>","~=","1"},
								"alert",{"TouchOfYShaarjcd", time = 5},
							},							
						},
					},
					{
						"expect",{"<phase>","~=","3"},
						"alert","TouchOfYShaarjcd",
					},
				},
			},			
			--
			{
				type = "event",
				event = "UPDATE_MOUSEOVER_UNIT",
				execute = {
					{
						"set",{Add = "&bossid|mouseover|true&"},
						"expect",{"&tabread|Farseer|<Add>&","~=","true"},
						"expect",{"&bossid|mouseover&","==","71983"}, --  Farseer Wolf Rider
						"tabinsert",{"Farseer","<Add>","true"},
						"raidicon","AddMark",
						--"debug",{"<AddMark> AddMark"},
					},
				},
			},
			-- Chain Lightning
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144584},
				execute = {
					{
						"expect",{"&tabread|Farseer|#1#&","~=","true"},
						"tabinsert",{"Farseer","#1#","true"},
						"set",{Add = "#1#"},
						"raidicon","AddMark",
					},
				},
			},
			-- Ancestral Fury
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144585},
				execute = {
					{
						"batchalert",{"wFarseerWolfRider","FarseerWolfRidercd"},
					},
					{
						"expect",{"&tabread|Farseer|#1#&","~=","true"},
						"tabinsert",{"Farseer","#1#","true"},					
						"set",{Add = "#1#"},
						"raidicon","AddMark",
					},
				},
			},	
			-- GrippingDispair
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145183},
				execute = {
					{
						"message","mGrippingDispair",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","GrippingDispairDebuff",
					},	
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"GrippingDispairDebuff", text = 2},
					},	
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {145183},
				execute = {
					{
						"message",{"mGrippingDispair", text = 2},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"GrippingDispairDebuff", text = 3},
					},	
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"GrippingDispairDebuff", text = 4},
					},	
					{
						"expect",{"#11#",">=","3"},
						"invoke", {
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","iGrippingDispairself",
							},		
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert","iGrippingDispairother",
							},
						},
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {145183, 145195},
				execute = {
					{
						"quash","GrippingDispairDebuff",
					},							
				},
			},	
			-- Emp GrippingDispair
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145195},
				execute = {
					{
						"message","mGrippingDispairEmp",
					},		
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","GrippingDispairDebuff",
					},	
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"GrippingDispairDebuff", text = 2},
					},						
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {145195},
				execute = {
					{
						"message",{"mGrippingDispairEmp", text = 2},
					},	
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"GrippingDispairDebuff", text = 3},
					},	
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"GrippingDispairDebuff", text = 4},
					},						
					{
						"expect",{"#11#",">=","3"},
						"invoke", {
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","iGrippingDispairself",
							},		
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert","iGrippingDispairother",
							},
						},
					},					
				},
			},
			-- Malice
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {147209},
				execute = {
					{
						"insert",{"Maliceunists","#5#"},
						"canceltimer","timerMalice",
						"scheduletimer",{"timerMalice",0.5},
						"schedulealert",{"Malicecd",0.5},
					},		
					{
						"expect",{"#4#","==","&playerguid&"},
						"announce","Malicesay",
						"alert","iMalice",
					},					
				},
			},	
			
			
			-- Desecrate
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144748},
				execute = {
					{
						"target",{
							source = "#1#",
							wait = 0.02,
							schedule = 16,
							--raidicon = "Sawblademark",
							--arrow = "Sawbladearrow",
							--arrowrange = 8,
							--arrowdef = "<",
							announce = "Desecratesay",
							message = "mDesecrate",
							alerts = {
								--self = "",
								--other = 
								--unknown = "",
								unknownmsg = {"mDesecrate", text = 2},
							},
						},	
					},
					{
						"expect",{"<phase>","==","1"},
						"alert",{"Desecratecd", time = 3},
					},
					{
						"expect",{"<phase>","==","2"},
						"alert","Desecratecd",
					},				
					{
						"expect",{"<phase>","==","3"},
						"alert",{"Desecratecd", time = 4},
					},					
				},
			},
			-- EmpDesecrate
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144749},
				execute = {
					{
						"target",{
							source = "#1#",
							wait = 0.02,
							schedule = 16,
							--raidicon = "Sawblademark",
							--arrow = "Sawbladearrow",
							--arrowrange = 8,
							--arrowdef = "<",
							announce = "Desecratesay",
							message = "mEmpDesecrate",
							alerts = {
								--self = "",
								--other = 
								--unknown = "",
								unknownmsg = {"mEmpDesecrate", text = 2},
							},
						},	
					},
					{
						"expect",{"<phase>","==","1"},
						"alert",{"Desecratecd", time = 3},
					},
					{
						"expect",{"<phase>","==","2"},
						"alert","Desecratecd",
					},				
					{
						"expect",{"<phase>","==","3"},
						"alert",{"Desecratecd", time = 4},
					},
				},
			},
			-- Bombardment
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {147120},
				execute = {
					{
						"batchalert",{"Bombardmentcd","wBombardment"},
					},
				},
			},
			-- Annihilate
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144969},
				execute = {
					{
						"message","mAnnihilate",
					},
				},
			},
			-- WhirlingCorruption
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144985},
				execute = {
					{
						"set",{wCount = "INCR|1"},
						"message","mWhirlingCorruption",
						"alert","WhirlingCorruptioncd",
					},
				},
			},
			-- EmpWhirlingCorruption
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {145037},
				execute = {
					{
						"set",{wCount = "INCR|1"},
						"message","mEmpWhirlingCorruption",
						"alert","WhirlingCorruptioncd",
					},
				},
			},
			-- ManifestRage
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {147011},
				execute = {
					{
						"alert","wManifestRage",
					},
				},
			},
			
			--------
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							{
								"expect",{"#5#","==","144821"}, -- warsong
								"batchalert",{"HellscreamsWarsongcd","wHellscreamsWarsong"},
							},
							{
								"expect",{"#5#","==","145235"}, -- Throw Axe At Heart
								"batchquash",{"SiegeEngineercd","FarseerWolfRidercd","Desecratecd","HellscreamsWarsongcd"},
								"alert",{"EnterRealmcd", time = 2},
							},	
							{
								"expect",{"#5#","==","144866"}, -- Enter Realm of Y'Shaarj
								"batchquash",{"TouchOfYShaarjcd","WhirlingCorruptioncd","Desecratecd"},
							},								
							{
								"expect",{"#5#","==","144956"}, -- phase 2
								"invoke",{
									{
										"expect",{"&timeleft|EnterRealmcd|0&",">","0"},
										"set",{phase = 2},
										"alert","Phase2",
									},
									{
										"expect",{"&timeleft|EnterRealmcd|0&","<","1"},
										"alert",{"Desecratecd", time = 2},
										"alert",{"TouchOfYShaarjcd", time = 2},
										"alert",{"WhirlingCorruptioncd", time = 2},
										"alert","EnterRealmcd",
										"set",{mindcontrol = 0},
										"set",{wCount = 0},								
									},
								},
							},
							{
								"expect",{"#5#","==","145647"}, -- phase 3
								"set",{phase = 3},
								"set",{mindcontrol = 0},
								"alert","Phase3",
								"batchquash",{"EnterRealmcd","TouchOfYShaarjcd","Desecratecd","WhirlingCorruptioncd"},
								"alert",{"Desecratecd", time = 5},
								"alert",{"TouchOfYShaarjcd", time = 3},
								"alert",{"WhirlingCorruptioncd", time = 3},						
							},
							{
								"expect",{"#5#","==","146984"}, -- phase 4
								"set",{phase = 4},
								"alert","Phase4",
								"batchquash",{"EnterRealmcd","TouchOfYShaarjcd","Desecratecd","WhirlingCorruptioncd"},
								"alert",{"Bombardmentcd", time = 2},
								"alert",{"Malicecd", time = 2},
							},	
						},
					},
				},
			},
			-- Emotes
			{
				type = "event",
				event = "EMOTE", 
				execute = {
					-- SiegeEngineer
					{
						"expect",{"#1#","find","spell:144616"}, 
						"batchalert",{"wSiegeEngineer","SiegeEngineercast"},					
						"invoke",{
							{
								"expect",{"<firstIronStar>","==","1"},
								"alert","SiegeEngineercd",
							},	
							{
								"expect",{"<firstIronStar>","==","0"},
								"alert",{"SiegeEngineercd", time = 3},
								"set",{firstIronStar = 1},
							},							
						},
					},
				},
			},	
		},
	}

	DXE:RegisterEncounter(data)
end
