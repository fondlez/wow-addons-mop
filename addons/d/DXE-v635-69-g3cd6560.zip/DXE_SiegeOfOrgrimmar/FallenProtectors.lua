local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 4,
		key = "Fallen Protectors",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Fallen Protectors"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-GOLDEN LOTUS COUNCIL.BLP:35:35",
		triggers = {
			scan = {71479, 71475, 71480},  --He-Softfoot, Rook Stonetoe, Sun Tenderheart
		},
		onactivate = {
			tracing = {71479, 71475, 71480},
			tracerstart = true,
			combatstop = true,
			defeat = {71479, 71475, 71480},
			unittracing = {"boss1","boss2","boss3"},
		},
		enrage = {
			time10n = 900,
			time25n = 900,
			time10h = 600,
			time25h = 600,
			timeflex = 900,
			timelfr = 900,
		},
		windows = {
			proxwindow = true,
			proxrange = 5,
		},
		userdata = {
			BaneStacks = 0,
			LingeringAnguishStacks = 0,
			InfernoStrike = 0,
			Gorroteunits = {type = "container", wipein = 3},
		},
		onstart = {
			{
				"alert",{"VengefulStrikescd", time = 2},
				"alert",{"Gorrotecd", time = 2},
				"alert",{"Banecd", time = 2},
				"alert",{"CorruptedBrewcd", time = 2},
				"alert",{"Gougecd", time = 2},
				"alert",{"Clashcd", time = 2},
				"alert",{"Calamitycd", time = 2},
			},
		},
		timers = {
			timerDarkMeditation = {
				{
					"expect",{"&unitisdead|player&","==","0"},
					"expect",{"&playerdebuff|"..SN[143564].."&","==","false"},
					"alert","iDarkMeditationGo",
					"scheduletimer",{"timerDarkMeditation",3},
				},
			},	
			listGorrote	= {
				{
					"message","mGorrote",
				},
			},		
		},
		arrows = {
			CorruptedBrewarrow = {
				varname = SN[143019],
				unit = "&upvalue&",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[143019],
				range1 = 6,
				range2 = 10,
				range3 = 12,
				ability = 8132,
				icon = ST[143019],
			},
		},		
		raidicons = {
			Banemark = {
				varname = SN[143434],
				type = "MULTIFRIENDLY",
				persist = 18,
				unit = "#5#",
				icon = 1,
				total = 5,
				reset = 5,
				ability = 8130,
				icon2 = ST[143434],
			},
			InfernoStrkemark = {
				varname = SN[143962],
				type = "FRIENDLY",
				persist = 8,
				unit = "#5#",
				icon = 8,
				ability = 8130,
				icon2 = ST[143962],
			},
		},		
		announces = { 
			markedsay = {
				varname = format(L.alert["%s %s %s!"],SN[143840],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143840],L.alert["on"],L.alert["Me"]),
				ability = 7941,
				icon = ST[143840]
			},
			CorruptionShocksay = {
				varname = format(L.alert["%s %s %s!"],SN[143958],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143958],L.alert["on"],L.alert["Me"]),
				ability = 7941,
				icon = ST[143958]
			},
			CorruptedBrewsay = {
				varname = format(L.alert["%s %s %s!"],SN[143019],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143019],L.alert["on"],L.alert["Me"]),
				ability = 7941,
				icon = ST[143019]
			},
			ShaShearsay = {
				varname = format(L.alert["%s %s %s!"],SN[143423],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143423],L.alert["on"],L.alert["Me"]),
				ability = 7941,
				icon = ST[143423]
			},				
		},
		messages = {
			mCorruptedBrew = {
				varname = format(L.alert["%s %s %s!"],SN[143019],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&!"],SN[143019],L.alert["on"]),
				color1 = "RED",
				icon = ST[143019],
				sound = "ALERT13",
				ability = 7941,
			},
			mInfernoStrke = {
				varname = format(L.alert["%s %s %s!"],SN[143962],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&!"],SN[143962],L.alert["on"]),
				color1 = "RED",
				icon = ST[143962],
				sound = "ALERT13",
				ability = 7941,
			},				
			mGouge = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143330]),
				type = "message",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143330]),
				color1 = "RED",
				icon = ST[143330],
				sound = "ALERT13",
				ability = 7902,
			},
			mBane = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143446]),
				type = "message",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143446]),
				color1 = "RED",
				icon = ST[143446],
				sound = "ALERT13",
				ability = 7902,
			},				
			mClash = {
				varname = format(L.alert["%s!"],SN[143027]),
				type = "message",
				text = format(L.alert["%s!"],SN[143027]),
				color1 = "ORANGE",
				icon = ST[143027],
				sound = "ALERT13",
				ability = 7888,
			},
			mMarkOfAnguish = {
				varname = format(L.alert["%s!"],SN[143812]),
				type = "message",
				text = format(L.alert["%s!"],SN[143812]),
				color1 = "ORANGE",
				icon = ST[143812],
				sound = "ALERT13",
				ability = 7888,
			},
			mShaShear = {
				varname = format(L.alert["%s!"],SN[143423]),
				type = "message",
				text = format(L.alert["%s!"],SN[143423]),
				color1 = "INDIGO",
				icon = ST[143423],
				sound = "ALERT13",
				ability = 7905,
				throttle = 3,
			},
			mGorrote = {
				varname = format(L.alert["%s %s %s"],SN[143198],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Gorroteunits&"],SN[143198],L.alert["on"]),
				color1 = "ORANGE",
				icon = ST[143198],
				sound = "ALERT13",
				ability = 7901,
				extank = true,
				exdps = true,
			},
			mGougeStun = {
				varname = format(L.alert["%s: %s %s!"],SN[143301],L.alert["player"],L.alert["is Stunned"]),
				type = "message",
				text = format(L.alert["%s: #5# %s!"],SN[143301],L.alert["is Stunned"]),
				color1 = "RED",
				icon = ST[143301],
				sound = "ALERT13",
				ability = 7902,
			},
			mMarked = {
				varname = format(L.alert["%s %s %s!"],SN[143840],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#!"],SN[143840],L.alert["on"]),
				color1 = "RED",
				icon = ST[143840],
				sound = "ALERT13",
				ability = 7941,
			},
			mCorruptionShock = {
				varname = format(L.alert["%s %s %s!"],SN[143958],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&!"],SN[143958],L.alert["on"]),
				color1 = "RED",
				icon = ST[143958],
				sound = "ALERT13",
				ability = 7941,
			},
			mFixate = {
				varname = format(L.alert["%s %s %s!"],SN[143292],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#!"],SN[143292],L.alert["on"]),
				color1 = "RED",
				icon = ST[143292],
				sound = "ALERT13",
				ability = 7941,
			},			
		},
		alerts = {
			CorruptedBrewcd = {
				varname = format(L.alert["%s Cooldown"],SN[143019]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143019]),
				time = 11,
				time2 = 18,
				color1 = "CYAN",
				icon = ST[143019],
				ability = 7887,
			},
			VengefulStrikescd = {
				varname = format(L.alert["%s Cooldown"],SN[144396]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144396]),
				time = 21,
				time2 = 7,
				time3 = 18,
				color1 = "INDIGO",
				icon = ST[144396],
				ability = 8145,
			},
			Clashcd = {
				varname = format(L.alert["%s Cooldown"],SN[143027]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143027]),
				time = 49,
				time2 = 45,
				time3 = 46,
				color1 = "BROWN",
				icon = ST[143027],
				ability = 7888,
			},
			DefiledGroundcd = {
				varname = format(L.alert["%s Cooldown"],SN[143961]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143961]),
				time = 10.5,
				time2 = 10,
				color1 = "INDIGO",
				icon = ST[143961],
				ability = 7958,
				exhealer = true,
				exdps = true,
			},
			Gougecd = {
				varname = format(L.alert["%s Cooldown"],SN[143330]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143330]),
				time = 30,
				time2 = 23,
				time3 = 26,
				color1 = "RED",
				icon = ST[143330],
				ability = 7902,
				exhealer = true,
				exdps = true,
			},		
			Gorrotecd = {
				varname = format(L.alert["%s Cooldown"],SN[143198]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143198]),
				time = 29,
				time2 = 15,
				time3 = 20,
				color1 = "RED",
				icon = ST[143198],
				ability = 7901,
				extank = true,
				exdps = true,
			},	
			Banecd = {
				varname = format(L.alert["%s Cooldown"],SN[143446]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143446]),
				time = 17,
				time2 = 15,
				time3 = 14,
				time4 = 13,
				color1 = "PINK",
				icon = ST[143446],
				ability = 7906,
				extank = true,
				exdps = true,
			},	
			Calamitycd = {
				varname = format(L.alert["%s Cooldown"],SN[143491]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143491]),
				time = 40,
				time2 = 31,
				time3 = 23,
				color1 = "RED",
				icon = ST[143491],
				ability = 7907,
			},
			InfernoStrikecd = {
				varname = format(L.alert["%s Cooldown"],SN[143962]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143962]),
				time = 9.5,
				time2 = 8,
				color1 = "RED",
				icon = ST[143962],
				ability = 7907,
			},					
			-- Alert
			wCorruptedBrew = {
				varname = format(L.alert["%s!"],SN[143019]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143019]),
				time = 2,
				color1 = "CYAN",
				icon = ST[143019],
				ability = 7887,
				sound = "ALERT10",
			},	
			wCorruptionKick = {
				varname = format(L.alert["%s!"],SN[143007]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143007]),
				time = 2,
				color1 = "NEWBLUE",
				icon = ST[143007],
				ability = 7887,
				sound = "ALERT11",
			},				
			--[[wBane = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143446]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143446]),
				time = 2,
				color1 = "RED",
				icon = ST[143446],
				sound = "ALERT10",
				ability = 7906,
				extank = true,
				exdps = true,
			},
			wCorruptionShock = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143958]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143958]),
				time = 2,
				color1 = "CYAN",
				icon = ST[143958],
				ability = 7957,
				sound = "ALERT10",
			},--]]
			wCalamity = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143491]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143491]),
				time = 2,
				color1 = "RED",
				icon = ST[143491],
				ability = 7907,
				sound = "ALERT11",
			},		
			wDefiledGround = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143961]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143961]),
				time = 2,
				color1 = "RED",
				icon = ST[143961],
				ability = 7958,
				sound = "ALERT10",
			},	
			wBondGoldenLotus = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143497]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143497]),
				time = 2,
				color1 = "RED",
				icon = ST[143497],
				sound = "ALERT10",
				ability = 8017,
			},
			wDarkMeditation = {
				varname = format(L.alert["%s!"],SN[143546]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143546]),
				time = 2,
				color1 = "VIOLET",
				icon = ST[143546],
				ability = 7954,
				sound = "ALERT11",
			},
			wMiserySorrowGloom = {
				varname = format(L.alert["%s!"],SN[143955]),
				type = "simple",
				text = format(L.alert["%s!"],SN[143955]),
				time = 2,
				color1 = "INDIGO",
				icon = ST[143955],
				ability = 7942,
				sound = "ALERT10",
			},
			wVengefulStrikes = {
				varname = format(L.alert["%s!"],SN[144396]),
				type = "simple",
				text = format(L.alert["%s!"],SN[144396]),
				time = 2,
				color1 = "CYAN",
				icon = ST[144396],
				ability = 8145,
				sound = "ALERT10",
			},			
			-- Inform			
			iLingeringAnguish = {
				varname = format(L.alert["%s: %s 8 %s!"],SN[144176],L.alert["already at"],L.alert["Stacks"]),
				type = "inform",
				text = format(L.alert["%s: %s 8 %s!"],SN[144176],L.alert["already at"],L.alert["Stacks"]),
				time = 2,
				color1 = "RED",
				sound = "ALERT10",
				icon = ST[144176],
				throttle = 6,
			--	flashscreen = true,
			},
			iShaShear = {
				varname = format(L.alert["%s %s %s!"],SN[143423],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143423],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "NEWBLUE",
				icon = ST[143423],
				ability = 7941,
				sound = "ALERT11",
				flashscreen = true,
			},			
			iFixate = {
				varname = format(L.alert["%s %s %s!"],SN[143292],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143292],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143292],
				ability = 7941,
				sound = "ALERT11",
				flashscreen = true,
			},
			iVengefulStrikes = {
				varname = format(L.alert["%s %s %s!"],SN[144396],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144396],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[144396],
				ability = 7941,
				sound = "ALERT10",
			},
			iMarkOfAnguish = {
				varname = format(L.alert["%s %s %s!"],SN[143812],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143812],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "TAN",
				icon = ST[143812],
				ability = 7941,
				sound = "ALERT10",
			},
			iDarkMeditationGo  = {
				varname = format(L.alert["%s %s!"],L.alert["GO TO"],SN[143546]),
				type = "inform",
				text = format(L.alert["%s %s!"],L.alert["GO TO"],SN[143546]),
				time = 2,
				color1 = "RED",
				sound = "ALERT11",
				icon = ST[143546],
				throttle = 2,
				ability = 8132,
				extank = true,
			},	
			iBane = {
				varname = format(L.alert["%s %s %s!"],SN[143434],L.alert["Dispell"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s #5#"],L.alert["Dispell"]),
				time = 2,
				color1 = "ORANGE",
				--sound = "ALERT10",
				icon = ST[143434],
				throttle = 2,
				ability = 8132,
			},	
			iNoxiousPoison = {
				varname = format(L.alert["%s %s, %s!"],SN[144367],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[144367],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144367],
				sound = "ALERT10",
				flashscreen = true,
				ability = 7958,
				throttle = 2,
			},			
			iDefiledGroundUnder = {
				varname = format(L.alert["%s %s, %s!"],SN[144357],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[144357],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144357],
				sound = "ALERT10",
				ability = 7958,
				throttle = 2,
			},
			iGougeStun = {
				varname = format(L.alert["%s %s!"],L.alert["player"],L.alert["is Stunned"]),
				type = "inform",
				text = format(L.alert["#5# %s!"],L.alert["is Stunned"]),
				time = 2,
				color1 = "CYAN",
				icon = ST[143301],
				ability = 7902,
				sound = "ALERT14",
			},
			iGouge = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143301]),
				type = "inform",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[143301]),
				time = 2,
				color1 = "RED",
				icon = ST[143301],
				ability = 7902,
				sound = "ALERT11",
				exhealer = true,
				exdps = true,
			},
			iCorruptedBrew = {
				varname = format(L.alert["%s %s %s!"],SN[143019],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143019],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143019],
				ability = 7888,
				sound = "ALERT10",
			},				
			iCorruptionShock = {
				varname = format(L.alert["%s %s %s!"],SN[143958],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143958],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143958],
				ability = 7888,
				sound = "ALERT10",
			},			
			iClash = {
				varname = format(L.alert["%s %s %s!"],SN[143027],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143027],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143027],
				ability = 7888,
				sound = "ALERT10",
			},
			iMarked = {
				varname = format(L.alert["%s %s %s!"],SN[143840],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143840],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143840],
				ability = 7941,
				sound = "ALERT11",
			},
			iInfernoStrke = {
				varname = format(L.alert["%s %s %s!"],SN[143962],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143962],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143962],
				ability = 7941,
				sound = "ALERT11",
			},
			-- Casts
			Calamitycast = {
				varname = format(L.alert["%s %s"],SN[143491],L.alert["Active"]),
				type = "centerpopup",
				text = format(L.alert["%s %s"],SN[143491],L.alert["Active"]),
				time = 5,
				color1 = "RED",
				icon = ST[143491],
				ability = 7907,
				--sound = "ALERT11",
			},
			ShaShearcast = {
				varname = format(L.alert["%s %s"],SN[143423],L.alert["Active"]),
				type = "centerpopup",
				text = format(L.alert["%s %s"],SN[143423],L.alert["Active"]),
				time = 5,
				color1 = "RED",
				icon = ST[143423],
				ability = 7907,
				--sound = "ALERT11",
			},			
			-- Debuff
			GougeStunDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143301]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143301]),
				text2 = format(L.alert["#5#: %s"],SN[143301]),
				time = 6,
				color1 = "RED",
				icon = ST[143301],
				ability = 7902,
				tag = "#5#",
			},
			MarkedDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143840]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143840]),
				text2 = format(L.alert["#5#: %s"],SN[143840]),
				time = 6,
				color1 = "RED",
				icon = ST[143840],
				ability = 7941,
				tag = "#5#",
				static = true,
				ex25 = true,
			},
			InfernoStrkeDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143962]),
				type = "debuff",
				text = format(L.alert["&upvalue&: %s"],SN[143962]),
				time = 7,
				color1 = "RED",
				icon = ST[143962],
				ability = 7902,
				tag = "#5#",
			},			
		},
		events = {
			-- InfernoStrke
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143962},
				execute = {
					{
						"alert","InfernoStrikecd",
						"set",{InfernoStrike = "0"},
					},
					{
						"target",{
							source = "#1#",
							wait = 0.6,
							schedule = 1,
							raidicon = "InfernoStrkemark",
							message = "mInfernoStrke",
							alerts = {
								self = "iInfernoStrke",
								other = "InfernoStrkeDebuff",
							},
						},
					},
				},
			},
			-- Gouge
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143330},
				execute = {
					{
						"alert","Gougecd",
						"message","mGouge",
					},
					--[[{
						"target",{
							source = "#1#",
							wait = 0.025,
							schedule = 12,
							alerts = {
								self = "iGouge",
							},
						},
					},--]]
				},
			},
			{
				type = "event",
				event = "BOSS_WHISPER", 
				execute = {
					{
						"expect",{"#1#","find","spell:143330"}, 
						"alert","iGouge",
					},				
				},
			},
			-- Bane
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143434},
				execute = {
					{
						"expect",{"&dispell|magic&","==","true"},
						"alert","iBane",
					},
					{
						"set",{BaneStacks = "&debuffstacks|#5#|"..SN[143434].."&"},
					},
					{
						"expect",{"<BaneStacks>","==","3"},
						"raidicon","Banemark",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143434},
				execute = {
					{
						"removeraidicon","#5#",
					},
				},
			},
			--[[{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143446},
				execute = {
					{
						"alert",{"Banecd", time = 3},
					},
				},
			},		--]]	
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143446},
				execute = {
					{
						"message","mBane",
					},
					{
						"expect",{"&heroic&","==","true"},
						"alert",{"Banecd", time = 4},
					},
					{
						"expect",{"&heroic&","==","false"},
						"alert","Banecd",
					},					
				},
			},
			-- Corruption Shock
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143958},
				execute = {
					{
						"target",{
							source = "#1#",
							wait = 0.025,
							schedule = 12,
							--raidicon = "FoulStreammark",
							--arrow = "MortalBarragearrow",
							--arrowrange = 9,
							announce = "CorruptionShocksay",
							message = "mCorruptionShock",
							alerts = {
								self = "iCorruptionShock",
							},
						},
					},
				}
			},
			--[[{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143958},
				execute = {
					{
						"alert","wCorruptionShock",
					},
				},
			},--]]
			-- Calamity
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143491},
				execute = {
					{
						"batchalert",{"Calamitycd","Calamitycast","wCalamity"},
					},
				},
			},
			-- DefiledGround
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143961}, 
				execute = {
					{
						"batchalert",{"DefiledGroundcd","wDefiledGround"},
					},
					--[[{
						"target",{
							source = "#1#",
							wait = 0.025,
							schedule = 12,
							--raidicon = "FoulStreammark",
							--arrow = "MortalBarragearrow",
							--arrowrange = 9,
							--announce = "CorruptionShocksay",
							--message = "mCorruptionShock",
							alerts = {
								self = "iDefiledGround",
							},
						},
					},--]]
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {144357},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iDefiledGroundUnder",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {144357},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iDefiledGroundUnder",
					},
				},
			},
			-- BondGoldenLotus
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143497},
				execute = {
					{
						"alert","wBondGoldenLotus",
					},
				},
			},
			-- Clash
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143027},
				execute = {
					{
						"alert","Clashcd",
						"message","mClash",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iClash",
					},
				},
			},
			-- ShaShear
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143423},
				execute = {
					{
						"message","mShaShear",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143423},
				dstisplayerunit = true,
				execute = {
					{
						"expect",{"<InfernoStrike>","==","1"},
						"batchalert",{"iShaShear","ShaShearcast"},
						"invoke",{
							{
								"expect",{"&lfr&","==","false"},
								"announce","ShaShearsay",
							},
						},
					},				
				},
			},
			-------------------
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"expect",{"#5#","==","143019"}, -- Corrupted Brew
						"invoke",{
							{
								"batchalert",{"CorruptedBrewcd","wCorruptedBrew"},
							},
							{
								"target",{
									source = "#1#",
									wait = 0.025,
									schedule = 12,
									arrow = "CorruptedBrewarrow",
									arrowrange = 6,
									arrowdef = "<",
									announce = "CorruptedBrewsay",
									message = "mCorruptedBrew",
									alerts = {
										self = "iCorruptedBrew",
									},
								},
							},
						},
					},
					{
						"expect",{"#1#","==","boss2"},
						"expect",{"#5#","==","143019"}, -- Corrupted Brew
						"invoke",{
							{
								"batchalert",{"CorruptedBrewcd","wCorruptedBrew"},
							},
							{
								"target",{
									source = "#1#",
									wait = 0.025,
									schedule = 12,
									arrow = "CorruptedBrewarrow",
									arrowrange = 6,
									arrowdef = "<",
									announce = "CorruptedBrewsay",
									message = "mCorruptedBrew",
									alerts = {
										self = "iCorruptedBrew",
									},
								},
							},
						},
					},
					{
						"expect",{"#1#","==","boss3"},
						"expect",{"#5#","==","143019"}, -- Corrupted Brew
						"invoke",{
							{
								"batchalert",{"CorruptedBrewcd","wCorruptedBrew"},
							},
							{
								"target",{
									source = "#1#",
									wait = 0.025,
									schedule = 12,
									arrow = "CorruptedBrewarrow",
									arrowrange = 6,
									arrowdef = "<",
									announce = "CorruptedBrewsay",
									message = "mCorruptedBrew",
									alerts = {
										self = "iCorruptedBrew",
									},
								},
							},
						},
					},
				},
			},
			-- Dark Meditation
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143546},
				execute = {
					{
						"alert","wDarkMeditation",
						"scheduletimer",{"timerDarkMeditation",3},	
						"batchquash",{"Banecd","Calamitycd"},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143546},
				execute = {
					{
						"alert",{"Calamitycd", time = 3},
						"canceltimer","timerDarkMeditation",
						"alert","Banecd",
					},
				},
			},
			-- Mark of Anguish
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143812},
				execute = {
					{
						"message","mMarkOfAnguish",
						"batchquash",{"Gorrotecd","Gougecd"},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iMarkOfAnguish",
					},		
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143812},
				execute = {
					{
						"alert",{"Gorrotecd", time = 2},
						"alert",{"Gougecd", time = 3},
					},
				},
			},
			-- Misery, Sorrow, and Gloom
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143955},
				execute = {
					{
						"alert","wMiserySorrowGloom",
						"alert",{"DefiledGroundcd", time = 2},
						"alert",{"InfernoStrikecd", time = 2},
						"batchquash",{"Clashcd","CorruptedBrewcd","VengefulStrikescd"},
						"set",{InfernoStrike = "1"},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143955},
				execute = {
					{
						"batchquash",{"DefiledGroundcd","InfernoStrikecd"},
						"alert",{"VengefulStrikescd", time = 3},
						"alert",{"CorruptedBrewcd", time = 2},
						"alert",{"Clashcd", time = 3},
						"set",{InfernoStrike = "0"},
					},
				},
			},
			-- VengefulStrikes
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144396},
				execute = {
					{
						"batchalert",{"VengefulStrikescd","wVengefulStrikes"},
					},
					{
						"target",{
							source = "#1#",
							wait = 0.025,
							schedule = 12,
							--raidicon = "FoulStreammark",
							--arrow = "MortalBarragearrow",
							--arrowrange = 9,
							--announce = "CorruptionShocksay",
							--message = "mCorruptionShock",
							alerts = {
								self = "iVengefulStrikes",
							},
						},
					},
				},
			},
			-- Gorrote
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143198},
				execute = {
					{
						--"message","mGorrote",
						"insert",{"Gorroteunits","#5#"},
						"canceltimer","listGorrote",
						"scheduletimer",{"listGorrote",1},	
					},
					{
						"expect",{"&heroic","==","true"},
						"alert",{"Gorrotecd", time = 3},
					},
					{
						"expect",{"&heroic","==","false"},
						"schedulealert",{"Gorrotecd",1},	
					},
				},
			},
			-- GougeStun
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143301},
				execute = {
					{
						"message","mGougeStun",
					},
					{
						"expect",{"&ishealer&","==","true"},
						"alert","iGougeStun",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","GougeStunDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"invoke",{
							{
								"alert",{"GougeStunDebuff", text = 2},
							},
							{
								"expect",{"&istank&","==","true"},
								"alert","iGougeStun",
							},
						},
					},					
				},
			},
			-- Marked
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143840},
				execute = {
					{
						"message","mMarked",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"batchalert",{"iMarked","MarkedDebuff"},
						"announce","markedsay",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"MarkedDebuff", text = 2},
						"openwindow",{"30","#5#"},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143840},
				execute = {
					{
						"openwindow",{"5"},
						"quash","MarkedDebuff",
					},
				},
			},			
			-- LingeringAnguish
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {144176},
				dstisplayerunit = true,
				execute = {
					{
						"expect",{"&playerdebuff|"..SN[143840].."&","==","true"},
						"expect",{"#11#",">","7"},
						"alert","iLingeringAnguish",
					},
				},
			},
			-- Fixate
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143292},
				execute = {
					{
						"message","mFixate",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iFixate",
					},
				},
			},
			-- NoxiousPoison
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {144367},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iNoxiousPoison",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {144367},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iNoxiousPoison",
					},
				},
			},	
			-- CorruptionKick
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143007},
				execute = {
					{
						"alert","wCorruptionKick",
					},
				},
			},
			--------------
			{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","71481"},
						"set",{InfernoStrike = "0"},
					},
				},
			},
		},
	}

	DXE:RegisterEncounter(data)
end
