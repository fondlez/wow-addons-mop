local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 3,
		key = "Korkron Dark Shaman",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Korkron Dark Shaman"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-KORKRON DARK SHAMAN.BLP:35:35",
		triggers = {
			scan = {71859, 71858}, 
		},
		onactivate = {
			tracing = {71859, 71858},
			tracerstart = true,
			combatstop = true,
			defeat = {71859, 71858},
			unittracing = {"boss1","boss2"},
		},
		enrage = {
			time10n = 540,
			time25n = 540,
			time10h = 540,
			time25h = 540,
			timeflex = 540,
			timelfr = 600,
		},
		windows = {
			proxwindow = true,
			--proxrange = 8,
		},
		arrows = {
			FoulStreamarrow = {
				varname = SN[144090],
				unit = "&upvalue&",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[144090],
				range1 = 8,
				range2 = 10,
				range3 = 13,
				ability = 8132,
				icon = ST[144090],
			},
			ToxicStormarrow = {
				varname = SN[144005],
				unit = "&upvalue&",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[144005],
				range1 = 8,
				range2 = 10,
				range3 = 13,
				ability = 8132,
				icon = ST[144005],
			},			
		},
		raidicons = {
			FoulStreammark = {
				varname = SN[144090],
				type = "FRIENDLY",
				persist = 10,
				unit = "&upvalue&",
				icon = 1,
				ability = 8132,
				icon2 = ST[144090],
			},
			--[[ToxicStormmark = {
				varname = SN[144005],
				type = "FRIENDLY",
				persist = 10,
				unit = "&upvalue&",
				icon = 1,
				ability = 8132,
				icon2 = ST[144005],
			},--]]			
			ToxicMistmark = {
				varname = SN[144089],
				type = "MULTIFRIENDLY",
				persist = 30,
				unit = "#5#",
				icon = 2,
				total = 8,
				reset = 5,
				ability = 8130,
				icon2 = ST[144089],
			},
		},
		timers = {
			timerToxicMist = {
				{
					"message","mToxicMist",
				},
			},
			timerIronPrison = {
				{
					"message","mIronPrisonTargets",
				},
			},			
		},
		announces = { 
			FoulStreamsay = {
				varname = format(L.alert["%s %s %s!"],SN[144090],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[144090],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[144090],
			},
			FoulGeysersay = {
				varname = format(L.alert["%s %s %s!"],SN[143990],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143990],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143990],
			},
			ToxicStormsay = {
				varname = format(L.alert["%s %s %s!"],SN[144005],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[144005],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[144005],
			},				
		},
		userdata = {
			ToxicMistunists = {type = "container", wipein = 3},
			IronPrisonunists = {type = "container", wipein = 3},
		},
		onstart = {
			{
				
			},
		},
		messages = {
			mIronPrisonTargets = {
				varname = format(L.alert["%s %s %s"],SN[144330],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|IronPrisonunists&"],SN[144330],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144330],
			},		
			mFoulStream = {
				varname = format(L.alert["%s %s %s"],SN[144090],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[144090],L.alert["on"]),
				color1 = "GREEN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144090],
			},
			mToxicMist = {
				varname = format(L.alert["%s %s %s"],SN[144089],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|ToxicMistunists&"],SN[144089],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144089],
				throttle = 4,
			},
			--[[mToxicStorm = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144005]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144005]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144005],
				throttle = 3,
			},--]]
			mFoulStream = {
				varname = format(L.alert["%s %s %s"],SN[144005],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[144005],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144005],
			},			
			mFoulGeyser = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[143990]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[143990]),
				color1 = "GREEN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143990],
			},
			mFoulGeyserTarget = {
				varname = format(L.alert["%s %s %s"],SN[143990],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[143990],L.alert["on"]),
				color1 = "GREEN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144090],
			},			
			mAshenWall = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144070]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144070]),
				color1 = "NEWBLUE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144070],
			},
			mFallingAsh = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[143973]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[143973]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143973],
			},
			mPoisonmistTotem = {
				varname = format(L.alert["%s"],SN[144288]),
				type = "message",
				text = format(L.alert["%s"],SN[144288]),
				color1 = "VIOLET",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144288],
				throttle = 3,
			},
			mFoulstreamTotem = {
				varname = format(L.alert["%s"],SN[144289]),
				type = "message",
				text = format(L.alert["%s"],SN[144289]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144289],
				throttle = 3,
			},
			mAshflareTotem = {
				varname = format(L.alert["%s"],SN[144290]),
				type = "message",
				text = format(L.alert["%s"],SN[144290]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144290],
				throttle = 3,
			},
			mFroststormStrike = {
				varname = format(L.alert["%s"],SN[144215]),
				type = "message",
				text = format(L.alert["%s"],SN[144215]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144215],
				enabled = false,
			},
			--[[mIronPrison = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144330]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144330]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144330],
			},	--]]		
			mIronTomb = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144328]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144328]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144328],
			},				
			mRend = {
				varname =  format(L.alert["%s %s %s (2)"],SN[144304],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[144304],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[144304],L.alert["on"]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144304],
			},
			mFroststormStrikeCount = {
				varname = format(L.alert["%s %s %s (2)"],SN[144215],L.alert["on"],L.alert["player"]),
				type = "message",
				--text = format(L.alert["%s %s #5# (1)"],SN[144215],L.alert["on"]),
				text = format(L.alert["%s %s #5# (#11#)"],SN[144215],L.alert["on"]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144215],
				throttle = 2,
			},
			mFroststormStrikeStacks = {
				varname = format(L.alert["%s: %s 5 %s!"],SN[144215],L.alert["already at"],L.alert["Stacks"]),
				type = "message",
				text = format(L.alert["%s: %s #11# %s!"],SN[144215],L.alert["already at"],L.alert["Stacks"]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144215],
				throttle = 3,
				exdps = true,
				exhealer = true,
			},
		},
		alerts = {
			-- Cooldows Earthbreaker Haromm
			IronTombcd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[144328]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144328]),
				time = 31.5,
				color1 = "NEWBLUE",
				icon = ST[144328],
				ability = 8132,
			},			
			FoulStreamcd = {
				varname = format(L.alert["%s Cooldown"],SN[144090]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144090]),
				time = 32.5,
				color1 = "NEWBLUE",
				icon = ST[144090],
				ability = 8132,
			},
			ToxicMistscd = {
				varname = format(L.alert["%s Cooldown"],SN[144089]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144089]),
				time = 32,
				color1 = "NEWBLUE",
				icon = ST[144089],
				ability = 8132,
			},
			FroststormStrikecd = {
				varname = format(L.alert["%s Cooldown"],SN[144215]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144215]),
				time = 6,
				color1 = "NEWBLUE",
				icon = ST[144215],
				ability = 8132,
				exhealer = true,
				exdps = true,
			},
			AshenWallcd = {
				varname = format(L.alert["%s Cooldown"],SN[144070]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144070]),
				time = 32.5,
				color1 = "NEWBLUE",
				icon = ST[144070],
				ability = 8132,
			},			
			-- Cooldows Wavebinder Kardris
			IronPrisoncd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[144330]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144330]),
				time = 31.5,
				color1 = "NEWBLUE",
				icon = ST[144330],
				ability = 8132,
			},			
			FrostStormBolcd = {
				varname = format(L.alert["%s Cooldown"],SN[144214]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144214]),
				time = 6.8,
				color1 = "NEWBLUE",
				icon = ST[144214],
				ability = 8132,
				exhealer = true,
				exdps = true,
			},
			ToxicStormcd = {
				varname = format(L.alert["%s Cooldown"],SN[144005]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144005]),
				time = 32,
				color1 = "NEWBLUE",
				icon = ST[144005],
				ability = 8132,
			},		
			FoulGeysercd = {
				varname = format(L.alert["%s Cooldown"],SN[143990]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143990]),
				time = 32.5,
				color1 = "NEWBLUE",
				icon = ST[143990],
				ability = 8132,
			},		
			FallingAshcd = {
				varname = format(L.alert["%s Cooldown"],SN[143973]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143973]),
				time = 32.5,
				color1 = "NEWBLUE",
				icon = ST[143973],
				ability = 8132,
			},					
			-- Alert
			wFoulStream = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144090]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144090]),
				time = 2,
				color1 = "GREEN",
				icon = ST[144090],
				sound = "ALERT14",
				ability = 8132,
			},
			wRustedIronTotem = {
				varname = "(H) "..format(L.alert["%s"],SN[144291]),
				type = "simple",
				text = format(L.alert["%s"],SN[144291]),
				time = 2,
				color1 = "GREEN",
				icon = ST[144291],
				sound = "ALERT14",
				ability = 8132,
				throttle = 2,
			},
			-- Inform
			iFoulStreamself = {
				varname = format(L.alert["%s %s %s!"],SN[144090],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144090],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[144090],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iToxicStormself = {
				varname = format(L.alert["%s %s %s!"],SN[144005],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144005],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[144005],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},			
			iToxicStorm = {
				varname = format(L.alert["%s %s %s!"],SN[144005],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144005],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144005],
				sound = "ALERT11",
				ability = 8132,
				flashscreen = true,
				throttle = 2,
			},
			iFroststormStrikeself = {
				varname = format(L.alert["%s: %s 5 %s!"],SN[144215],L.alert["already at"],L.alert["Stacks"]),
				type = "inform",
				text = format(L.alert["%s: %s #11# %s!"],SN[144215],L.alert["already at"],L.alert["Stacks"]),
				time = 2,
				color1 = "RED",
				sound = "ALERT14",
				icon = ST[144215],
				ability = 8132,
				flashscreen = true,
			},	
			-- Casts
			IronPrisonCast = {
				varname = format(L.alert["%s Active"],SN[144330]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[144330]),
				time = 60,
				color1 = "NEWBLUE",
				icon = ST[144330],
				ability = 8132,
				audiocd = true,
				audiotime = 6,
			},	
			-- Debuff
			ToxicMistDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144089]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[144089]),
				text2 = format(L.alert["#5#: %s"],SN[144089]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[144089],
				tag = "#5#",
			},	
			FroststormStrikeDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144215]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[144215]),
				text2 = format(L.alert["#5# (1): %s"],SN[144215]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[144215]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[144215]),
				time = 30,
				color1 = "NEWBLUE",
				ability = 8130,
				icon = ST[144215],
				tag = "#5#",
			},
			IronPrisonDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144330]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[144330]),
				text2 = format(L.alert["#5#: %s"],SN[144330]),
				time = 60,
				color1 = "TAN",
				ability = 8130,
				icon = ST[144330],
				tag = "#5#",
			},				
		},
		events = {
			-- ToxicMist
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144089},
				execute = {
					{
						"expect",{"&inrange|#5#&","<","50"},
						"invoke",{
							{
								"expect",{"&unitisplayer|#5#&","==","true"},
								"invoke",{
									{
										"raidicon","ToxicMistmark",
									},
									{
										"expect",{"#4#","==","&playerguid&"},
										"alert","ToxicMistDebuff",
									},
									{
										"expect",{"#4#","~=","&playerguid&"},
										"alert",{"ToxicMistDebuff", text = 2},
									},
									{
										"insert",{"ToxicMistunists","#5#"},
										--"tabinsert",{"ToxicMistunists","#5#","true"},
										"canceltimer","timerToxicMist",
										"scheduletimer",{"timerToxicMist",0.5},
									},
								},
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144089},
				execute = {
					{
						"removeraidicon","#5#",
					},
				},
			},
			--FoulStream
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144090},
				execute = {
					{
						"alert","wFoulStream",
						--"openwindow",{"8"},
					},
					{
						"target",{
							source = "#1#",
							wait = 0.05,
							schedule = 16,
							raidicon = "FoulStreammark",
							arrow = "FoulStreamarrow",
							arrowdef = "<",
							arrowrange = 8,
							announce = "FoulStreamsay",
							message = "mFoulStream",
							alerts = {
								self = "iFoulStreamself",
								--other = 
								--unknown = "",
							},
						},
					},
				},
			},
			--ToxicStorm
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144005},
				execute = {
					{
						"message","mToxicStorm",
						"alert","ToxicStormcd",
					},
					{
						"target",{
							source = "#1#",
							wait = 0.05,
							schedule = 16,
							--raidicon = "ToxicStormmark",
							arrow = "ToxicStormarrow",
							arrowdef = "<",
							arrowrange = 16,
							announce = "ToxicStormsay",
							message = "mFoulStream",
							alerts = {
								self = "iToxicStormself",
								--other = 
								--unknown = "",
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {144017},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicStorm",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {144017},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicStorm",
					},
				},
			},
			--FoulGeyser
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143990},
				execute = {
					{
						"message","mFoulGeyser",
						"alert","FoulGeysercd",
						--"openwindow",{"8"},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143990},
				execute = {
					{
						"expect",{"&inrange|#5#&","<","50"},
						"invoke",{
							{
								"message","mFoulGeyserTarget",
							},
							{
								"expect",{"#4#","==","&playerguid&"},
								"announce","FoulGeysersay",
							},
						},
					},
				},
			},			
			--AshenWall
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144070},
				execute = {
					{
						"message","mAshenWall",
						"alert","AshenWallcd",
						--"openwindow",{"8"},
					},
				},
			},
			--FallingAsh
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143973},
				execute = {
					{
						"message","mFallingAsh",
						"alert","FallingAshcd",
						--"openwindow",{"8"},
					},
				},
			},
			--PoisonmistTotem
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144288},
				execute = {
					{
						"message","mPoisonmistTotem",
					},
				},
			},
			--FoulstreamTotem
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144289},
				execute = {
					{
						"message","mFoulstreamTotem",
						"openwindow",{"4"},
					},
				},
			},
			--AshflareTotem
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144290},
				execute = {
					{
						"message","mAshflareTotem",
					},
				},
			},
			--FroststormStrike
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144215},
				execute = {
					{
						"message","mFroststormStrike",
						"alert","FroststormStrikecd",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144215},
				execute = {
					--{
					--	"message","mFroststormStrikeCount",
					--},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","FroststormStrikeDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"FroststormStrikeDebuff", text = 2},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {144215},
				execute = {
				--	{
				--		"message",{"mFroststormStrikeCount", text = 2},
				--	},				
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"FroststormStrikeDebuff", text = 3},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"FroststormStrikeDebuff", text = 4},
					},
					{
						"expect",{"&checkperc|#11#|2&","==","0"},
						"message","mFroststormStrikeCount",
					},
					{
						"expect",{"#11#",">","5"},
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","iFroststormStrikeself",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"message","mFroststormStrikeStacks",
							},
						},
					},
				},
			},					
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144215},
				execute = {
					{
						"quash","FroststormStrikeDebuff",
					},
				},
			},
			-- Rend
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144304},
				execute = {
					{
						"expect",{"&checkperc|1|3&","==","0"},
						"message","mRend",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {144304},
				execute = {
					{
						"expect",{"&checkperc|#11#|3&","==","0"},
						"message",{"mRend", text = 2},
					},
				},
			},
			-- IronPrison
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144330},
				execute = {
					{
						--"message","mIronPrison",
						"alert","IronPrisoncd",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144330},
				execute = {
					{
						"expect",{"&inrange|#5#&","<","100"},
						"invoke",{
							{
								"insert",{"IronPrisonunists","#5#"},
								--"tabinsert",{"IronPrisonunists","#5#","true"},
								"canceltimer","timerIronPrison",
								"scheduletimer",{"timerIronPrison",0.5},
							},
							{
								"expect",{"#4#","==","&playerguid&"},
								"batchalert",{"IronPrisonCast","IronPrisonDebuff"},
							}, 
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"IronPrisonDebuff", text = 2},
							},
						},
					},
				},
			},	
			-- IronTomb
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144328},
				execute = {
					{
						"message","mIronTomb",
						"alert","IronTombcd",
					},
				},
			},	
			--RustedIronTotem (Heroic)
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144291},
				execute = {
					{
						"alert","wRustedIronTotem",
					},
				},
			},			
		},
	}

	DXE:RegisterEncounter(data)
end
