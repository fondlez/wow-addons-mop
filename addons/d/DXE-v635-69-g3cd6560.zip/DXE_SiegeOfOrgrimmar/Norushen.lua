local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 4,
		key = "Norushen",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Norushen"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-NORUSHEN.BLP:35:35",
		triggers = {
			scan = {71967}, -- Norushen    --{72276},
			yell = L.chat_SiegeOfOrgrimmar["(Very well, I will create a field to keep your corruption quarantined.)"],
		},
		onactivate = {
			tracing = {72276},
			tracerstart = true,
			combatstop = true,
			defeat = {72276},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 445,
			time25n = 445,
			time10h = 445,
			time25h = 445,
			time25lfr = 625,
			timeflex = 445,
		},
		--windows = {
		--	proxwindow = true,
		--	proxrange = 8,
		--},
		raidicons = {
			UnleashedMark = {
				varname = L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"],
				type = "MULTIENEMY",
				persist = 120,
				unit = "<Unleashed>",
				--id = 72367,
				reset = 5,
				icon = 1,
				total = 7,
			},
		},
		timers = {
			timerIncomingPhase2 = {
				{
					"expect",{"&bossid|boss1&","==","72276"},
					"invoke",{
						{
							"expect",{"&gethp|boss1&","<","53"},
							"expect",{"<warned>","==","0"},
							"alert","wPhase2Soon",
							"set",{warned = 1},
						},
						{
							"expect",{"&gethp|boss1&",">","53"},
							"scheduletimer",{"timerIncomingPhase2",1},
						},
					},
				},
				{
					"expect",{"&bossid|boss1&","~=","72276"},
					"expect",{"<warned>","==","0"},
					"scheduletimer",{"timerIncomingPhase2",1},
				},
			},
			listTestofConfidence = {
				{
					"message","mTestofConfidence",
				},
			},
			listTestofConfidenceOver = {
				{
					"message","mTestofConfidenceOver",
				},
			},
			listTestofReliance = {
				{
					"message","mTestofReliance",
				},
			},
			listTestofRelianceOver = {
				{
					"message","mTestofRelianceOver",
				},
			},
			listTestofSerenity = {
				{
					"message","mTestofSerenity",
				},
			},
			listTestofSerenityOver = {
				{
					"message","mTestofSerenityOver",
				},
			},	
			Start = {
				{
					"alert",{"BlindHatredcd", time = 2},
				},
			},				
		},
		userdata = {
			phase = "0",
			warned = 0,
			inside = 0,
			sync = "",
			Unleashed = "",
			Unleashedunit = {type = "container"},
			TestofConfidenceunits = {type = "container", wipein = 3}, -- Tank
			TestofConfidenceunitsover = {type = "container", wipein = 3}, -- Tank
			TestofRelianceunits = {type = "container", wipein = 3}, -- Healer
			TestofRelianceunitsover = {type = "container", wipein = 3}, -- Healer
			TestofSerenityunits = {type = "container", wipein = 3}, -- Dps
			TestofSerenityunitsover = {type = "container", wipein = 3}, -- Dps
		},
		onstart = {
			{
				"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Very well, I will create a field to keep your corruption quarantined.)"]},
				"set",{phase = "RP"},
				"alert","PrePull",
				"scheduletimer",{"Start",24.8},
			},
			-- backup tracerstart
			{
				"expect",{"<phase>","==","0"},
				"alert",{"BlindHatredcd", time = 2},
			},
			{
			--	"alert","PrePull",
				--"alert",{"BlindHatredcd", time = 2},
				"scheduletimer",{"timerIncomingPhase2",1},
			},
		},
		messages = {
			mTestofConfidence = {
				varname = format(L.alert["%s %s %s"],SN[144851],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s %s"],SN[144851],L.alert["on"],"&list|TestofConfidenceunits&"),
				color1 = "ORANGE",
				icon = ST[144851],
				sound = "ALERT13",
				ability = 8132,
			},		
			mTestofConfidenceOver = {
				varname = format(L.alert["%s %s: %s"],SN[144851],L.alert["over"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s: %s"],SN[144851],L.alert["over"],"&list|TestofConfidenceunitsover&"),
				color1 = "GREEN",
				icon = ST[144851],
				sound = "ALERT13",
				ability = 8132,
			},
			mTestofReliance = {
				varname = format(L.alert["%s %s %s"],SN[144850],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s %s"],SN[144850],L.alert["on"],"&list|TestofRelianceunits&"),
				color1 = "ORANGE",
				icon = ST[144850],
				sound = "ALERT13",
				ability = 8132,
			},		
			mTestofRelianceOver = {
				varname = format(L.alert["%s %s: %s"],SN[144850],L.alert["over"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s: %s"],SN[144850],L.alert["over"],"&list|TestofRelianceunitsover&"),
				color1 = "GREEN",
				icon = ST[144850],
				sound = "ALERT13",
				ability = 8132,
			},
			mTestofSerenity = {
				varname = format(L.alert["%s %s %s"],SN[144849],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[144849],L.alert["on"],"&list|TestofSerenityunits&"),
				color1 = "ORANGE",
				icon = ST[144849],
				sound = "ALERT13",
				ability = 8132,
			},		
			mTestofSerenityOver = {
				varname = format(L.alert["%s %s: %s"],SN[144849],L.alert["over"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s: %s"],SN[144849],L.alert["over"],"&list|TestofSerenityunitsover&"),
				color1 = "GREEN",
				icon = ST[144849],
				sound = "ALERT13",
				ability = 8132,
			},
			mUnleashCorruption = {
				varname = format(L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"].." (2)"),
				type = "message",
				text = L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"],
				color1 = "INDIGO",
				icon = ST[145007],
				sound = "ALERT13",
				ability = 8132,
				counter = true,
			},
			mUnleashCorruptionDeath = {
				varname = L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"].." (2)",
				type = "message",
				text = L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"],
				color1 = "INDIGO",
				icon = ST[145007],
				sound = "ALERT13",
				ability = 8132,
				counter = true,
			},			
			mLingeringCorruption = {
				varname = format(L.alert["%s %s %s"],SN[144514],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[144514],L.alert["on"]),
				color1 = "INDIGO",
				icon = ST[144514],
				sound = "ALERT13",
				ability = 8132,
			},	
			mBlindHatred = {
				varname = format(L.alert["%s"],SN[145226]),
				type = "message",
				text = format(L.alert["%s"],SN[145226]),
				color1 = "INDIGO",
				icon = ST[145226],
				sound = "ALERT13",
				ability = 8132,
			},
			mFusion = {
				varname = format(L.alert["%s (1)"],SN[145226]),
				type = "message",
				text = format(L.alert["%s (1)"],SN[145226]),
				text2 = format(L.alert["%s (#11#)"],SN[145226]),
				color1 = "INDIGO",
				icon = ST[145226],
				sound = "ALERT13",
				ability = 8132,
			},
			mSelfDoubt = {
				varname = "(H) "..format(L.alert["%s (1)"],SN[146124]),
				type = "message",
				text = format(L.alert["%s (1)"],SN[146124]),
				text2 = format(L.alert["%s (#11#)"],SN[146124]),
				color1 = "INDIGO",
				icon = ST[146124],
				sound = "ALERT13",
				ability = 8132,
			},				
			mUnleashedAnger = {
				varname = format(L.alert["%s (2)"],SN[145216]),
				type = "message",
				text = format(L.alert["%s"],SN[145216]),
				color1 = "INDIGO",
				icon = ST[145216],
				sound = "ALERT13",
				ability = 8132,
				counter = true,
			},				
		},
		alerts = {
			PrePull = {
				varname = format(L.alert["Pre Pull"]),
				type = "dropdown",
				text = format(L.alert["Pre Pull"]),
				time = 25,
				flashtime = 10,
				color1 = "MIDGREY",
				icon = ST[3648],
			},
			-- Cooldowns
			UnleashedAngercd = {
				varname = format(L.alert["%s Cooldown"],SN[145216]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[145216]),
				time = 11,
				color1 = "NEWBLUE",
				icon = ST[145216],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			BlindHatredcd = {
				varname = format(L.alert["%s Cooldown"],SN[145226]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[145226]),
				time = 30,
				time2 = 25,
				color1 = "NEWBLUE",
				icon = ST[145226],
				ability = 8132,
				exdps = true,
			},
			TearRealitycd = { -- Dps Test
				varname = format(L.alert["%s Cooldown"],SN[144482]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144482]),
				time = 8.5,
				color1 = "NEWBLUE",
				icon = ST[144482],
				ability = 8132,
			},
			DishearteningLaughcd = { -- Healer Test
				varname = format(L.alert["%s Cooldown"],SN[146707]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[146707]),
				time = 12,
				color1 = "NEWBLUE",
				icon = ST[146707],
				ability = 8132,
			},
			LingeringCorruptioncd = { -- Healer Test
				varname = format(L.alert["%s Cooldown"],SN[144514]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144514]),
				time = 15.5,
				color1 = "NEWBLUE",
				icon = ST[144514],
				ability = 8132,
			},
			TitanicSmashcd = { -- Tank Test
				varname = format(L.alert["%s Cooldown"],SN[144628]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144628]),
				time = 14.5,
				color1 = "NEWBLUE",
				icon = ST[144628],
				ability = 8132,
			},
			PiercingCorruptioncd = { -- Tank Test
				varname = format(L.alert["%s Cooldown"],SN[144657]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144657]),
				time = 14,
				color1 = "NEWBLUE",
				icon = ST[144657],
				ability = 8132,
			},
			HurlCorruptioncd = { -- Tank Test
				varname = format(L.alert["%s Cooldown"],SN[144649]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144649]),
				time = 20,
				color1 = "NEWBLUE",
				icon = ST[144649],
				ability = 8132,
			},
			-- Warning
			wTitanicSmash = {
				varname = format(L.alert["%s %s, %s"],L.alert["Incoming"],SN[144628],L.alert["MOVE AWAY"]),
				type = "simple",
				text = format(L.alert["%s %s, %s"],L.alert["Incoming"],SN[144628],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144628],
				sound = "ALERT11",
				ability = 8132,
			},
			wHurlCorruption = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144649]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144649]),
				time = 2,
				color1 = "RED",
				icon = ST[144649],
				sound = "ALERT10",
				ability = 8132,
			},
			wTearReality = {
				varname = format(L.alert["%s %s, %s"],L.alert["Incoming"],SN[144482],L.alert["MOVE AWAY"]),
				type = "simple",
				text = format(L.alert["%s %s, %s"],L.alert["Incoming"],SN[144482],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144482],
				sound = "ALERT11",
				ability = 8132,
			},			
			wPhase2 = {
				varname = format(L.alert["Phase 2"]),
				type = "simple",
				text = format(L.alert["Phase 2"]),
				time = 2,
				color1 = "GREEN",
				icon = ST[146179],
				sound = "ALERT13",
			},
			wPhase2Soon = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],L.alert["Phase 2"]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],L.alert["Phase 2"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[146179],
				sound = "ALERT10",
			},
			wBlindHatred = {
				varname = format(L.alert["%s"],SN[145226]),
				type = "simple",
				text = format(L.alert["%s"],SN[145226]),
				time = 2,
				color1 = "RED",
				icon = ST[145226],
				sound = "ALERT11",
				ability = 8132,
			},
			wManifestation = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],L.npc_SiegeOfOrgrimmar["Unleashed Manifestation of Corruption"]),
				time = 2,
				color1 = "RED",
				icon = ST[145007],
				ability = 7958,
				sound = "ALERT10",
			},	
			-- Inform
			iLingeringCorruption = {
				varname = format(L.alert["%s %s %s!"],SN[144514],L.alert["Dispell"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s #5#"],L.alert["Dispell"]),
				time = 2,
				color1 = "ORANGE",
				--sound = "ALERT10",
				icon = ST[144514],
				throttle = 3,
				ability = 8132,
			},
			-- Cast
			BlindHatredCast = {
				varname = format(L.alert["%s Active"],SN[145226]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[145226]),
				time = 30,
				color1 = "NEWBLUE",
				icon = ST[145226],
				ability = 8132,
			},			
			-- Debuff
			TestofConfidenceDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144851]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[144851]),
				text2 = format(L.alert["#5#: %s"],SN[144851]),
				time = 60,
				color1 = "RED",
				ability = 8130,
				icon = ST[144851],
				tag = "#5#",
			},
			TestofRelianceDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144850]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[144850]),
				text2 = format(L.alert["#5#: %s"],SN[144850]),
				time = 60,
				color1 = "GREEN",
				ability = 8130,
				icon = ST[144850],
				tag = "#5#",
			},
			TestofSerenityDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144849]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[144849]),
				text2 = format(L.alert["#5#: %s"],SN[144849]),
				time = 60,
				color1 = "INDIGO",
				ability = 8130,
				icon = ST[144849],
				tag = "#5#",
				--exhealer = true,
			},	
			SelfDoubtDebuff = {
				varname = "(H) "..format(L.alert["%s Debuff"],SN[146124]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[146124]),
				text2 = format(L.alert["#5# (1): %s"],SN[146124]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[146124]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[146124]),
				time = 60,
				color1 = "TAN",
				ability = 8130,
				icon = ST[146124],
				tag = "#5#",
				exdps = true,
			},					
		},
		events = {
			{
				type = "event",
				event = "UPDATE_MOUSEOVER_UNIT",
				execute = {
					{
						"expect",{"&bossid|mouseover&","==","72264"}, -- UnleashedMark
						"set",{Unleashed = "&bossid|mouseover|true&"},
						"expect",{"&tabread|Unleashedunit|<Unleashed>&","~=","true"},
						"tabinsert",{"Unleashedunit","<Unleashed>","true"},
						"raidicon","UnleashedMark",
					},				
				},
			},
			{
				type = "event",
				event = "UNIT_TARGET",
				execute = {
					{
						"expect",{"#1#","~=","0"},
						"invoke",{
							{
								"expect",{"&unittarget|#1#&","==","72264"}, -- UnleashedMark
								"set",{Unleashed = "&unittarget|#1#|true&"},
								"expect",{"&tabread|Unleashedunit|<Unleashed>&","~=","true"},
								"tabinsert",{"Unleashedunit","<Unleashed>","true"},
								"raidicon","UnleashedMark",
							},
						},
					},					
				},
			},	
			-- Test of Confidence (TANK)
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144851}, 
				execute = {
					{
						--"message","mTestofConfidence",
						"insert",{"TestofConfidenceunits","#5#"},
						"canceltimer","listTestofConfidence",
						"scheduletimer",{"listTestofConfidence",1},						
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","TestofConfidenceDebuff",
						"set",{inside = "1"},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"TestofConfidenceDebuff", text = 2},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144851},
				execute = {
					{
						"quash","TestofConfidenceDebuff",
						--"message","mTestofConfidenceOver",
						"insert",{"TestofConfidenceunitsover","#5#"},
						"canceltimer","listTestofConfidenceOver",
						"scheduletimer",{"listTestofConfidenceOver",1},	
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"set",{inside = "0"},
					},
				},
			},
			-- Test of Reliance (HEALER)
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144850}, 
				execute = {
					{
						--"message","mTestofReliance",
						"insert",{"TestofRelianceunits","#5#"},
						"canceltimer","listTestofReliance",
						"scheduletimer",{"listTestofReliance",1},							
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","TestofRelianceDebuff",
						"set",{inside = "1"},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"TestofRelianceDebuff", text = 2},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144850},
				execute = {
					{
						"quash","TestofRelianceDebuff",
						--"message","mTestofRelianceOver",
						"insert",{"TestofRelianceunitsover","#5#"},
						"canceltimer","listTestofRelianceOver",
						"scheduletimer",{"listTestofRelianceOver",1},		
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"set",{inside = "0"},
					},
				},
			},
			-- Test of Serenity (DPS)
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144849}, 
				execute = {
					{
						--"message","mTestofSerenity",
						"insert",{"TestofSerenityunits","#5#"},
						"canceltimer","listTestofSerenity",
						"scheduletimer",{"listTestofSerenity",1},	
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","TestofSerenityDebuff",
						"set",{inside = "1"},
					},	
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"TestofSerenityDebuff", text = 2},
					},							
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144849},
				execute = {
					{
						"quash","TestofSerenityDebuff",
						--"message","mTestofSerenityOver",
						"insert",{"TestofSerenityunitsover","#5#"},
						"canceltimer","listTestofSerenityOver",
						"scheduletimer",{"listTestofSerenityOver",1},	
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"set",{inside = "0"},
					},					
				},
			},
			--TitanicSmash
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144628},
				execute = {
					{
						"batchalert",{"TitanicSmashcd","wTitanicSmash"},
					},
				},
			},
			--HurlCorruption
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144649},
				execute = {
					{
						"batchalert",{"HurlCorruptioncd","wHurlCorruption"},
					},
				},
			},
			--TearReality
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144482},
				execute = {
					{
						"batchalert",{"TearRealitycd","wTearReality"},
					},
				},
			},
			-- LingeringCorruption
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144514},
				execute = {
					{
						"message","mLingeringCorruption",
						"alert","LingeringCorruptioncd",
					},
					{
						"expect",{"&dispell|magic&","==","true"},
						"alert","iLingeringCorruption",
					},
				},
			},	
			-- BlindHatred
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145226},
				execute = {
					{
					--	"message","mBlindHatred",
						--"sync",{"mBlindHatred",2},
						--"bigwigssync",{"BlindHatred"},
						"batchalert",{"BlindHatredCast","wBlindHatred"},
					},				
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {145226},
				execute = {
					{
					--	"message","mBlindHatred",
						--"sync",{"mBlindHatred",2},
						--"bigwigssync",{"BlindHatred"},
						"alert","BlindHatredcd",
					},				
				},
			},					
			-- Fusion
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145226},
				execute = {
					{
						"message","mFusion",
					},				
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {145226},
				execute = {
					{
						"message",{"mFusion", text = 2},
					},				
				},
			},	
			-- SelfDoubt
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146124},
				execute = {
					{
						"message","mSelfDoubt",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","SelfDoubtDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"SelfDoubtDebuff", text = 2},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {146124},
				execute = {
					{
						"message",{"mSelfDoubt", text = 2},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"SelfDoubtDebuff", text = 3},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"SelfDoubtDebuff", text = 4},
					},							
				},
			},			
			--UnleashedAnger
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {145216},
				execute = {
					{
						"message","mUnleashedAnger",
					},
				},
			},
			-- Frayed Phase 2 trigger
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146179},
				execute = {
					{
						"alert","wPhase2",
					},				
				},
			},	
			-- Unleash Corruption (add)
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {145769},
				execute = {
					{
						"message","mUnleashCorruption",
					},				
				},
			},				
			--[[
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							{
								"expect",{"#5#","==","146179"}, -- Frayed Phase 2 trigger
								"alert","wPhase2",
							},
							{
								"expect",{"#5#","==","145007"}, -- Unleash Corruption (add)
								"message","mUnleashCorruption",
							},
						},
					},
				},
			},--]]
			{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","71977"}, -- Manifestation of Corruption (Dps Test)
						"quash","TearRealitycd",
					},
					{
						"expect",{"&npcid|#4#&","==","72001"}, -- Greater Corruption (Healer Test)
						"batchquash",{"LingeringCorruptioncd","DishearteningLaughcd"},
					},
					{
						"expect",{"&npcid|#4#&","==","72051"}, -- Titanic Corruption (Tank Test)
						"batchquash",{"TitanicSmashcd","HurlCorruptioncd","PiercingCorruptioncd"},
					},
					{
						"expect",{"&npcid|#4#&","==","72264"}, -- Unleashed Manifestation of Corruption
						"message","mUnleashCorruptionDeath",
					},
				},
			},
		},
	}

	DXE:RegisterEncounter(data)
end
