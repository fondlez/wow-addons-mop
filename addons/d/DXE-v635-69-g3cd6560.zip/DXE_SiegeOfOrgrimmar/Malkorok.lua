local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

--local DisplacedEnergyDebuff = GetSpellInfo(142913)
do
	local data = {
		version = 3,
		key = "Malkorok",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Malkorok"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-MALKOROK.BLP:35:35",
		triggers = {
			scan = {71454}, 
		},
		onactivate = {
			tracing = {71454,powers={true}},
			tracerstart = true,
			combatstop = true,
			defeat = {71454},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 360,
			time25n = 360,
			time10h = 360,
			time25h = 360,
			time25lfr = 720,
			timeflex = 360,
		},
		windows = {
			proxwindow = true,
			proxrange = 5,
		},
		raidicons = {
			DisplacedEnergymark = {
				varname = SN[142913],
				type = "MULTIFRIENDLY",
				persist = 60,
				unit = "#5#",
				icon = 1,
				total = 7,
				reset = 1,
				ability = 8130,
				icon2 = ST[142913],
			},
		},
		announces = { 
			DisplacedEnergysay = {
				varname = format(L.alert["%s %s %s!"],SN[142913],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[142913],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[142913],
			},		
		},
		--[[arrows = {
			Addarrow = {
				varname = L.npc_SiegeOfOrgrimmar["Living Corruption"],
				unit = "#5#",
				persist = 5,
				action = "TOWARD",
				msg = L.alert["KILL IT!"],
				spell = SN[137175],
			},
		},--]]
		timers = {
			timerDisplacedEnergy = {
				{
					"message","mDisplacedEnergy",
				},
			},
			timerImplodingEnergy = {
				{
					"message","mImplodingEnergyIncoming",
				},
			},
			timerAncientBarrier = {
				{
					"expect",{"&unitisdead|player&","==","0"},
					"invoke",{
						{
							"expect",{"&playerdebuff|"..SN[142863].."&","==","true"},
							"batchquash",{"AncientBarrierAmount","StrongAncientBarrierAmount"},
							"set",{AncientBarrier = "&debuffabsorb|"..SN[142863].."|player&"},
							"alert","WeakAncientBarrierAmount",
						},
						{
							"expect",{"&playerdebuff|"..SN[142864].."&","==","true"},
							"batchquash",{"WeakAncientBarrierAmount","StrongAncientBarrierAmount"},
							"set",{AncientBarrier = "&debuffabsorb|"..SN[142864].."|player&"},
							"alert","AncientBarrierAmount",
						},
						{
							"expect",{"&playerdebuff|"..SN[142865].."&","==","true"},
							"batchquash",{"AncientBarrierAmount","WeakAncientBarrierAmount"},
							"set",{AncientBarrier = "&debuffabsorb|"..SN[142865].."|player&"},
							"alert","StrongAncientBarrierAmount",
						},						
						{
							"scheduletimer",{"timerAncientBarrier",0.5},
						},
					},
				},
				{
					"expect",{"&unitisdead|player&","==","1"},
					"batchquash",{"AncientBarrierAmount","WeakAncientBarrierAmount","StrongAncientBarrierAmount"},
				},
			},
		},
		userdata = {
			DisplacedEnergyunists = {type = "container", wipein = 3},
			DisplacedEnergyunists2 = {type = "container"},
			DisplacedEnergyCount = 0,
			BreathCount = 0,
			SeismicSlamCount = 0,
			ArcingSmashCount = 0,
			BloodRage = 0,
			sync = "",
			AncientBarrier = 0,
			LivingCorruptionActive = 0,
			LivingCorruptionTarget = "",
		},
		onstart = {
			{
				"alert",{"BloodRagecd", time = 2},
				"scheduletimer",{"timerAncientBarrier",0.5},
			},
			{
				"expect",{"&lfr&","==","true"},
				"alert",{"SeismicSlamcd", time = 3},
				"alert",{"BreathofYShaarjcd", time = 2},
				"alert",{"ArcingSmashcd", time = 2},
			},
			{
				"expect",{"&lfr&","==","false"},
				"alert",{"ArcingSmashcd", time = 3},
				"alert",{"SeismicSlamcd", time = 2},
				"alert","BreathofYShaarjcd",
			},
		},
		messages = {
			mDisplacedEnergy = {
				varname = format(L.alert["%s %s %s"],SN[142913],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s %s"],SN[142913],L.alert["on"],"&list|DisplacedEnergyunists&"),
				color1 = "BROWN",
				icon = ST[142913],
				sound = "ALERT13",
			},
			mBloodRageOver = {
				varname = format(L.alert["%s %s"],SN[142879],L.alert["over"]),
				type = "message",
				text = format(L.alert["%s %s"],SN[142879],L.alert["over"]),
				color1 = "GREEN",
				icon = ST[142879],
				sound = "ALERT13",
			},
			mBreathofYShaarj = {
				varname = format(L.alert["%s (2)"],SN[142842]),
				type = "message",
				text = format(L.alert["%s (<BreathCount>)"],SN[142842]),
				color1 = "GREEN",
				icon = ST[142842],
				sound = "ALERT13",
			},	
			mSeismicSlam = {
				varname = format(L.alert["%s (2)"],SN[142851]),
				type = "message",
				text = format(L.alert["%s (<SeismicSlamCount>)"],SN[142851]),
				color1 = "GREEN",
				icon = ST[142851],
				sound = "ALERT13",
			},	
			mArcingSmash = {
				varname = format(L.alert["%s (2)"],SN[142826]),
				type = "message",
				text = format(L.alert["%s (<ArcingSmashCount>)"],SN[142826]),
				color1 = "GREEN",
				icon = ST[142826],
				sound = "ALERT13",
			},
			mImplodingEnergyIncoming = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[142986]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[142986]),
				color1 = "RED",
				icon = ST[142986],
				sound = "ALERT13",
				counter = true,
			},
			mFatalStrike = {
				varname = format(L.alert["%s: %s 2 %s"],SN[142990],L.alert["already at"],L.alert["Stacks"]),
				type = "message",
				text = format(L.alert["%s: %s #11# %s!"],SN[142990],L.alert["already at"],L.alert["Stacks"]),
				color1 = "ORANGE",
				icon = ST[142990],
				sound = "ALERT13",
				exdps = true,
				throttle = 3,
			},
		},
		alerts = {
			-- Might of the Kor'kron
			ArcingSmashcd = {
				varname = format(L.alert["%s Cooldown"],SN[142815]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142815]),
				time = 17.5,
				time2 = 14,
				time3 = 11,
				time4 = 19.5,
				color1 = "NEWBLUE",
				icon = ST[142815],
				ability = 8132,
			},
			SeismicSlamcd = {
				varname = format(L.alert["%s Cooldown"],SN[142851]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142851]),
				time = 17.5,
				time2 = 5,
				time3 = 7.5,
				time4 = 19.5,
				color1 = "NEWBLUE",
				icon = ST[142851],
				ability = 8132,
			},
			BreathofYShaarjcd = {
				varname = format(L.alert["%s Cooldown"],SN[142842]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142842]),
				time = 59,
				time2 = 70,
				color1 = "NEWBLUE",
				icon = ST[142842],
				ability = 8132,
			},
			------
			DisplacedEnergycd = {
				varname = format(L.alert["%s Cooldown"],SN[142913]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142913]),
				time = 11,
				time2 = 3.5,
				color1 = "NEWBLUE",
				icon = ST[142913],
				ability = 8132,
			},
			BloodRagecd = {
				varname = format(L.alert["%s Cooldown"],SN[142879]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142879]),
				time = 127.7,
				time2 = 122,
				time3 = "<BloodRage>",
				color1 = "NEWBLUE",
				icon = ST[142879],
				ability = 8132,
			},		
			-- Warning
			wBloodRage = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[142879]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[142879]),
				time = 2,
				color1 = "RED",
				icon = ST[142879],
				sound = "ALERT14",
				ability = 8132,
			},
			-- Inform
			iDisplacedEnergyself = {
				varname = format(L.alert["%s %s %s!"],SN[142913],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142913],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[142913],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iFatalStrike = {
				varname =  format(L.alert["%s - %s!"],SN[142990],L.alert["Removed"]),
				type = "inform",
				text = format(L.alert["%s - %s!"],SN[142990],L.alert["Removed"]),
				time = 2,
				color1 = "INDIGO",
				sound = "ALERT10",
				icon = ST[142990],
				exdps = true,
				ability = 8132,
				exhealer = true,
				exdps = true,
			},
			iFatalStrikeself = {
				varname = format(L.alert["%s: %s 12 %s!"],SN[136903],L.alert["already at"],L.alert["Stacks"]),
				type = "inform",
				text = format(L.alert["%s: %s #11# %s!"],SN[136903],L.alert["already at"],L.alert["Stacks"]),
				time = 2,
				color1 = "RED",
				sound = "ALERT14",
				icon = ST[136521],
				ability = 8132,
				flashscreen = true,
				exdps = true,
				exhealer = true,
				throttle = 3,
			},			
			-- Cast
			ImplodingEnergyCast = {
				varname = format(L.alert["%s %s"],SN[142986],L.alert["Incoming"]),
				type = "centerpopup",
				text = format(L.alert["%s %s"],SN[142986],L.alert["Incoming"]),
				time = 6,
				color1 = "NEWBLUE",
				icon = ST[142986],
				ability = 8132,
			},	
			BloodRageCast = {
				varname = format(L.alert["%s Active"],SN[142879]),
				type = "centerpopup",
				text = format(L.alert["%s: Active"],SN[142879]),
				time = 22.5,
				color1 = "ORANGE",
				ability = 8130,
				icon = ST[142879],
				tag = "#5#",
			},	
			WeakAncientBarrierAmount = {
				varname = format(L.alert["%s"],SN[142863]),
				type = "centerpopup",
				text = format(L.alert["%s <AncientBarrier>%s"],SN[142863],"%"),
				time = 15,
				color1 = "RED",
				ability = 8130,
				icon = ST[142863],
				tag = "#5#",
				static = true,
			},	
			AncientBarrierAmount = {
				varname = format(L.alert["%s"],SN[142864]),
				type = "centerpopup",
				text = format(L.alert["%s <AncientBarrier>%s"],SN[142864],"%"),
				time = 15,
				color1 = "ORANGE",
				ability = 8130,
				icon = ST[142864],
				tag = "#5#",
				static = true,
			},
			StrongAncientBarrierAmount = {
				varname = format(L.alert["%s"],SN[142865]),
				type = "centerpopup",
				text = format(L.alert["%s <AncientBarrier>%s"],SN[142865],"%"),
				time = 15,
				color1 = "GREEN",
				ability = 8130,
				icon = ST[142865],
				tag = "#5#",
				static = true,
			},			
			-- Debuff
			FatalStrikeDebuff = {
				varname = format(L.alert["%s Debuff"],SN[142990]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[142990]),
				text2 = format(L.alert["#5# (1): %s"],SN[142990]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[142990]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[142990]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[142990],
				tag = "#5#",
				exdps = true,
			},	
			-- Absorb
			--[[shieldoflightwarn = {
				varname = format(L.alert["%s Absorbs"],SN[67259]),
				text = SN[67259].."!",
				textformat = format("%s => %%s/%%s - %%d%%%%",L.alert["Shield"]),
				type = "absorb",
				time = 15,
				flashtime = 5,
				color1 = "YELLOW",
				color2 = "INDIGO",
				sound = "ALERT4",
				icon = ST[67259],
				npcid = 34497,
				values = {
					[67261] = 1200000,
					[67259] = 700000,
					[67260] = 300000,
					[65858] = 175000,
				},
			},		--]]
		},
		events = {
			-- LivingCorruption
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143919},
				execute = {
					{
						"expect",{"<LivingCorruptionActive>","==","0"},
						"set",{LivingCorruptionActive = "1"},
						--"set",{LivingCorruptionTarget = "#5#"},
						--"arrow","Addarrow",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","71644"}, -- Living Corruption
						--"removearrow","<LivingCorruptionTarget>",
						"set",{LivingCorruptionActive = "0"},
					},
				},
			},			
			-- Displaced Energy
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142913},
				execute = {
					{
						"expect",{"&unitisplayer|#5#&","==","true"},
						"invoke",{				
							{
								"set",{DisplacedEnergyCount = "INCR|1"},
								"insert",{"DisplacedEnergyunists","#5#"},
								--"tabinsert",{"DisplacedEnergyunists2","#5#","true"},
							--	"sinsert",{"DisplacedEnergyunists2","#5#"},
								"canceltimer","timerDisplacedEnergy",
								"scheduletimer",{"timerDisplacedEnergy",0.5},
								"raidicon","DisplacedEnergymark",
							},
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","iDisplacedEnergyself",
								"announce","DisplacedEnergysay",
								"openwindow",{"8"},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"set",{DisplacedEnergyunists2 = "&RaidDebuff|"..SN[142913].."&"},
								"openwindow",{"8","<DisplacedEnergyunists2>"},
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {142913},
				execute = {
					{
						"set",{DisplacedEnergyCount = "DECR|1"},
						"removeraidicon","#5#",
					},
					{
						"expect",{"<DisplacedEnergyCount>","==","0"},
						"closewindow",
					},					
					{
						"expect",{"<DisplacedEnergyCount>",">","0"},
						"set",{DisplacedEnergyunists2 = "&RaidDebuff|"..SN[142913].."&"},
						"openwindow",{"8","<DisplacedEnergyunists2>"},
						--"openwindow",{"8","&RaidDebuff|"..DisplacedEnergyDebuff.."&"},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {142913},
				execute = {
					{
						"alert","DisplacedEnergycd",
					},
				},
			},
			-- Fatal Strike
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142990},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","FatalStrikeDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"FatalStrikeDebuff", text = 2},
					},
				},
			},			
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {142990},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"FatalStrikeDebuff", text = 3},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"FatalStrikeDebuff", text = 4},
					},
					{
						"expect",{"#11#",">=","12"},
						--"expect",{"&checkperc|#11#|3&","==","0"},
						"message","mFatalStrike",
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","iFatalStrikeself",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"expect",{"&unitisdead|player&","==","0"},
								"expect",{"&playerdebuff|"..SN[142990].."&","==","false"},
								"alert","iFatalStrike",	
							},							
						},
					},
				},
			},
			--BloodRage
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142879},
				execute = {
					{
						"batchalert",{"BloodRageCast","wBloodRage"},
						"closewindow",
						"alert",{"DisplacedEnergycd", time = 2},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143913},
				execute = {
					{
						"set",{BloodRage = "&timeleft|BloodRagecd|2.5&"},
						"alert",{"BloodRagecd", time = 3},
					},
				},
			},
			-- ExpelMiasma (end of blood rage)
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143199},
				execute = {
					{
						"message","mBloodRageOver",
						"openwindow",{"5"},
						"quash","DisplacedEnergycd",
						"set",{BreathCount = 0},
						"alert","BloodRagecd",
					},
					{
						"expect",{"&lfr&","==","true"},
						"alert",{"SeismicSlamcd", time = 3},
						"alert",{"BreathofYShaarjcd", time = 2},
						"alert",{"ArcingSmashcd", time = 2},
					},
					{
						"expect",{"&lfr&","==","false"},
						"alert",{"ArcingSmashcd", time = 3},
						"alert",{"SeismicSlamcd", time = 2},
						"alert","BreathofYShaarjcd",
					},
				},
			},
			--BreathofYShaarj
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142842},
				execute = {
					{
						"set",{BreathCount = "INCR|1"},
						"message","mBreathofYShaarj",
					},
					{
						"expect",{"<BreathCount>","==","1"},
						"set",{SeismicSlamCount = 0},
						"invoke",{
							{
								"expect",{"&lfr&","==","true"},
								"alert",{"SeismicSlamcd", time = 3},
								"alert",{"BreathofYShaarjcd", time = 2},
								"alert",{"ArcingSmashcd", time = 2},
							},
							{
								"expect",{"&lfr&","==","false"},
								"alert",{"ArcingSmashcd", time = 3},
								"alert",{"SeismicSlamcd", time = 2},
								"alert","BreathofYShaarjcd",
							},
						},
					},
				},
			},
			-- SeismicSlam
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {142851},
				execute = {
					{
						"set",{SeismicSlamCount = "INCR|1"},
						"message","mSeismicSlam",
					},
					{
						"expect",{"<SeismicSlamCount>","<","3"},
						"invoke",{
							{
								"expect",{"&lfr&","==","false"},
								"alert","SeismicSlamcd",
							},
							{
								"expect",{"&lfr&","==","true"},
								"alert",{"SeismicSlamcd", time = 4},
							},							
						},
					},
				},
			},
			----------------------------
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"expect",{"#5#","==","142898"},
						"invoke",{
							{
								"set",{ArcingSmashCount = "INCR|1"},
								"message","mArcingSmash",
								"scheduletimer",{"timerImplodingEnergy",3},
								"alert","ImplodingEnergyCast",
							},
							{
								"expect",{"&lfr&","==","false"},
								"alert","ArcingSmashcd",
							},
							{
								"expect",{"&lfr&","==","true"},
								"alert",{"ArcingSmashcd", time = 4},
							},							
						},
					},
				},
			},
		},
	}

	DXE:RegisterEncounter(data)
end
