local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 2,
		key = "Sha of Pride",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Sha of Pride"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-SHA OF PRIDE.BLP:35:35",
		triggers = {
			scan = {71734}, 
		},
		onactivate = {
			tracing = {71734},
			tracerstart = true,
			combatstop = true,
			defeat = {71734},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
		},
		windows = {
			--proxwindow = true,
			--proxrange = 8,
		},
		raidicons = {
			TitanGiftmark = {
				varname = SN[144359],
				type = "MULTIFRIENDLY",
				persist = 30,
				unit = "#5#",
				icon = 4,
				total = 5,
				reset = 4,
				ability = 8130,
				icon2 = ST[144359],
			},
			CorruptedFragmentMark = {
				varname = L.npc_SiegeOfOrgrimmar["Corrupted Fragment"],
				type = "ENEMY",
				persist = 30,
				unit = "<CorruptedFragment>",
				--id = 72367,
				--reset = 5,
				icon = 1,
				--total = 1,
			},
			AuraOfPridemark = {
				varname = SN[146817],
				type = "MULTIFRIENDLY",
				persist = 25,
				unit = "#5#",
				icon = 1,
				total = 3,
				reset = 5,
				ability = 8130,
				icon2 = ST[146817],
			},
		},		
		announces = { 
			Imprisonsay = {
				varname = format(L.alert["%s %s %s!"],SN[144574],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[144574],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[144574],
			},
			AuraOfPridesay = {
				varname = format(L.alert["%s %s %s!"],SN[146817],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[146817],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[146817],
			},					
		},
		timers = {
			--[[timerBigAdd = {
				{
					"alert","wBigAdd",
				},
			},--]]
			timerUnitPower = {
				{
					"expect",{"&getup|boss1&",">","81"}, -- Add
					"expect",{"<warned>","==","0"},
					"alert","wBigAdd",
					"set",{warned = "1"},
				},
				{
					"expect",{"&getup|boss1&","<","81"},
					"expect",{"<warned>","==","1"},
					"set",{warned = "0"},
				},
				{
					"scheduletimer",{"timerUnitPower",1},
				},
			},
			timerBurstingPride = {
				{
					"message","mBurstingPride",
				},
			},
			--[[timerBurstingPrideMind = {
				{
					"message","mBurstingPrideMind",
				},
			},	--]]
			timerImprison = {
				{
					"message","mImprison",
				},
			},
			timerAuraOfPride = {
				{
					"message","mAuraOfPride",
				},
			},
			timerTitanGift = {
				{
					"message","mTitanGift",
				},
			},
			timerProjection = {
				{
					"message","mProjection",
				},
			},	
			timerBanishment = {
				{
					"message","mBanishment",
				},
			},
		},	
		userdata = {
			AP = 0,
			prime = 0,
			AuraOfPride = 0,
			CorruptedFragment = "",
			CorruptedFragmentunit = {type = "container"},
			RaidAPPlayers = {type = "container"},
			--MindControlled = {type = "container"},
			AuraOfPrideunists = {type = "container", wipein = 3},
			AuraOfPrideunists2 = {type = "container"},
			Imprisonunists = {type = "container", wipein = 3},
			TitanGiftunists = {type = "container", wipein = 3},
			Projectionunists = {type = "container", wipein = 3},
			Banishmentunists = {type = "container", wipein = 3},
		},
		onstart = {
			{			
				"alert",{"GiftOfTitanscd", time = 2},
				"batchalert",{"SwellingPridecd","CorruptedPrisoncd","Markcd","SelfReflectioncd","Manifestationcd"},
				"scheduletimer",{"timerUnitPower",1},
				--"scheduletimer",{"timerBigAdd",55},
			},
			{
				"expect",{"&heroic&","==","true"},
				"alert","Banishmentcd",
			},
			{
				"expect",{"&lfr&","==","false"},
				"alert",{"WoundedPridecd", time = 2},
			},
		},
		messages = {
			mBanishment = {
				varname = format(L.alert["%s %s %s"],SN[145215],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Banishmentunists&"],SN[145215],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[145215],
			},	
			mProjection = {
				varname = format(L.alert["%s %s %s"],SN[146822],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Projectionunists&"],SN[146822],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[146822],
			},	
			mTitanGift = {
				varname = format(L.alert["%s %s %s"],SN[144359],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|TitanGiftunists&"],SN[144359],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144359],
			},		
			mAuraOfPride = {
				varname = format(L.alert["%s %s %s"],SN[146817],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|AuraOfPrideunists&"],SN[146817],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[146817],
			},		
			mImprison = {
				varname = format(L.alert["%s %s %s"],SN[144574],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Imprisonunists&"],SN[144574],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144574],
			},
			mBurstingPride = {
				varname = format(L.alert["%s %s %s"],SN[144911],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s <RaidAPPlayers>"],SN[144911],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144911],
			},
			--[[mBurstingPrideMind = {
				varname = format(L.alert["%s %s %s"],SN[144843],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s <MindControlled>"],SN[144843],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144843],
			},--]]
			mUnleashed = {
				varname = format(L.alert["%s"],SN[144832]),
				type = "message",
				text = format(L.alert["%s"],SN[144832]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144832],
			},	
			mWoundedPride = {
				varname = format(L.alert["%s %s %s"],SN[144358],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[144358],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144358],
				exdps = true,
			},
			mWeakenedResolve = {
				varname = format(L.alert["%s %s %s"],SN[147207],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[147207],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[147207],
			},				
		},
		alerts = {
			GiftOfTitanscd = {
				varname = format(L.alert["%s Cooldown"],SN[144359]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144359]),
				time = 25.5,
				time2 = 7.5,
				color1 = "NEWBLUE",
				icon = ST[144359],
				ability = 8132,
			},
			Markcd = {
				varname = format(L.alert["%s Cooldown"],SN[144351]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144351]),
				time = 20.5,
				color1 = "NEWBLUE",
				icon = ST[144351],
				ability = 8132,
				exdps = true,
				extank = true,
			},
			SelfReflectioncd = {
				varname = format(L.alert["%s Cooldown"],SN[144800]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144800]),
				time = 25,
				time2 = 62,
				color1 = "NEWBLUE",
				icon = ST[144800],
				ability = 8132,
			},
			WoundedPridecd = {
				varname = format(L.alert["%s Cooldown"],SN[144358]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144358]),
				time = 30,
				time2 = 10,
				time3 = 35,
				color1 = "NEWBLUE",
				icon = ST[144358],
				ability = 8132,
				exhealer = true,
				exdps = true,
			},
			Banishmentcd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[145215]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[145215]),
				time = 37.5,
				color1 = "NEWBLUE",
				icon = ST[145215],
				ability = 8132,
			},
			CorruptedPrisoncd = {
				varname = format(L.alert["%s Cooldown"],SN[144574]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144574]),
				time = 53,
				color1 = "NEWBLUE",
				icon = ST[144574],
				ability = 8132,
			},
			Manifestationcd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8262"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8262"]),
				time = 60,
				color1 = "NEWBLUE",
				icon = EJST[8262],
				ability = 8132,
			},	
			SwellingPridecd = {
				varname = format(L.alert["%s Cooldown"],SN[144400]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144400]),
				time = 75.5,
				time2 = 75,
				color1 = "NEWBLUE",
				icon = ST[144400],
				ability = 8132,
				audiocd = true,
				audiotime = 10,
			},
			-- Warning
			wBigAdd = {
				varname = format(L.alert["%s %s!"],SN["ej8262"],L.alert["is about to SPAWN"]),
				type = "inform",
				text = format(L.alert["%s %s!"],SN["ej8262"],L.alert["is about to SPAWN"]),
				time = 2,
				color1 = "RED",
				icon = ST[144400],
				sound = "ALERT11",
				ability = 8132,
				throttle = 10,
			},
			wSelfReflection = {
				varname = format(L.alert["%s!"],SN[144800]),
				type = "inform",
				text = format(L.alert["%s!"],SN[144800]),
				time = 2,
				color1 = "RED",
				icon = ST[144800],
				sound = "ALERT18",
				ability = 8132,
			},	
			wImprison = {
				varname = format(L.alert["%s %s"],SN[144563],L.alert["Incoming"]),
				type = "simple",
				text = format(L.alert["%s %s"],SN[144563],L.alert["Incoming"]),
				time = 2,
				color1 = "INDIGO",
				icon = ST[144563],
				sound = "ALERT10",
				ability = 8132,
			},			
			-- Inform
			iBurstingPride = {
				varname = format(L.alert["%s %s, %s!"],SN[144911],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[144911],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144911],
				sound = "ALERT11",
				ability = 8132,
				flashscreen = true,
				throttle = 2,
			},
			iMarkOfArrogance = {
				varname = format(L.alert["%s %s %s!"],SN[144351],L.alert["Dispell"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s #5#"],L.alert["Dispell"]),
				time = 2,
				color1 = "GREEN",
				sound = "ALERT10",
				icon = ST[144351],
			},
			iAuraOfPride = {
				varname = format(L.alert["%s %s %s!"],SN[146817],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[146817],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[146817],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},	
			iTitanGift = {
				varname = format(L.alert["%s %s %s!"],SN[144359],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144359],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "TAN",
				icon = ST[144359],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iTitanGiftAuraOfPride = {
				varname = format(L.alert["%s + %s %s %s!"],SN[144359],SN[146817],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s + %s %s %s!"],SN[144359],SN[146817],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[144359],
				sound = "ALERT11",
				ability = 8132,
				flashscreen = true,
			},
			iProjection = {
				varname = format(L.alert["%s %s %s!"],SN[146822],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[146822],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "TAN",
				icon = ST[146822],
				sound = "ALERT10",
				ability = 8132,
			},
			iBanishment = {
				varname = format(L.alert["%s %s %s!"],SN[145215],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[145215],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "TAN",
				icon = ST[145215],
				sound = "ALERT10",
				ability = 8132,
			},				
			-- Casts
			Projectioncast = {
				varname = format(L.alert["%s Active"],SN[146822]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[146822]),
				time = 6,
				color1 = "NEWBLUE",
				icon = ST[146822],
				ability = 8132,
			},
			WeakenedResolvecast = {
				varname = format(L.alert["%s Active"],SN[147207]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[147207]),
				time = 60,
				color1 = "TAN",
				icon = ST[147207],
				ability = 8132,
			},
		}, -- 
		events = {
			-- CorruptedFragment
			{
				type = "event",
				event = "UPDATE_MOUSEOVER_UNIT",
				execute = {
					{
						"expect",{"&bossid|mouseover&","==","72569"}, 
						"set",{CorruptedFragment = "&bossid|mouseover|true&"},
						"expect",{"&tabread|CorruptedFragmentunit|<CorruptedFragment>&","~=","true"},
						"tabinsert",{"CorruptedFragmentunit","<CorruptedFragment>","true"},
						"raidicon","CorruptedFragmentMark",
					},				
				},
			},	
			{
				type = "event",
				event = "UNIT_TARGET",
				execute = {
					{
						"expect",{"#1#","~=","0"},
						"invoke",{
							{
								"expect",{"&unittarget|#1#&","==","72569"},
								"set",{CorruptedFragment = "&unittarget|#1#|true&"},
								"expect",{"&tabread|CorruptedFragmentunit|<CorruptedFragment>&","~=","true"},
								"tabinsert",{"CorruptedFragmentunit","<CorruptedFragment>","true"},
								"raidicon","CorruptedFragmentMark",
							},
						},
					},					
				},
			},	
			--Swelling Pride		
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144400},
				execute = {
					{
						"set",{AP = "&getap|player&"},
						"batchalert",{"CorruptedPrisoncd","Manifestationcd","SwellingPridecd","SelfReflectioncd"},
						--"scheduletimer",{"timerBigAdd",55},
					},
					{
						"expect",{"&lfr&","==","false"},
						"alert","WoundedPridecd",
					},
					{
						"expect",{"&heroic&","==","true"},
						"alert","Banishmentcd",
					},
					{
						"expect",{"<AP>",">","24"},
						"expect",{"<AP>","<","50"},
						"alert","iBurstingPride",
					},
					{
						"set",{RaidAPPlayers = "&getmultiraidap|24|50&"},
						"canceltimer","timerBurstingPride",
						"scheduletimer",{"timerBurstingPride",0.5},
						--"openwindow",{"5","<RaidAPPlayers>"},
					},
					--{
					--	"set",{MindControlled = "&getraidap|100&"},
					--	"canceltimer","timerBurstingPrideMind",
					--	"scheduletimer",{"timerBurstingPrideMind",0.5},
					--},
				},
			},
			-- SelfReflection
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144800},
				execute = {
					{
						"alert","wSelfReflection",
						"alert",{"SelfReflectioncd", time = 2},
					},
				}
			},				
			-- CorruptedPrison
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144563},
				execute = {
					{
						--"batchalert",{"wImprison","Imprisoncd"},
						"alert","wImprison",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144574, 144684, 144683, 144636},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"announce","Imprisonsay",
					},
					{
						"insert",{"Imprisonunists","#5#"},
						"canceltimer","timerImprison",
						"scheduletimer",{"timerImprison",0.5},
					},
				},
			},
			-- Unleashed
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144832},
				execute = {
					{
						"quash","SwellingPridecd",
						"batchalert",{"CorruptedPrisoncd","SelfReflectioncd"},
					},
					{
						"expect",{"&lfr&","==","false"},
						"alert","WoundedPridecd",
						"canceltimer","timerBigAdd",
					},
					{
						"expect",{"&heroic&","==","true"},
						"alert","Banishmentcd",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144832},
				execute = {
					{
						"message","mUnleashed",
						"quash","GiftOfTitanscd",
						"alert",{"SwellingPridecd", time = 2},
						"alert","Manifestationcd",
						--"scheduletimer",{"timerBigAdd",55},
					},
				}
			},	
			-- WoundedPride
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144358},
				execute = {
					{
						"message","mWoundedPride",
					},
					{
						"expect",{"<prime>","==","1"},
						"alert",{"WoundedPridecd", time = 3},
					},		
					{
						"expect",{"<prime>","==","0"},
						"set",{prime = 1},
						"alert","WoundedPridecd",
					},					
				}
			},	
			-- MarkOfArrogance
			{
				type = "combatevent",
				--eventtype = "SPELL_CAST_SUCCESS",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144351},
				execute = {
					{
						"expect",{"&dispell|magic&","==","true"},
						"alert","iMarkOfArrogance",
					},				
				}
			},
			-- WeakenedResolve
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {147207},
				execute = {
					{
						"message","mWeakenedResolve",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","WeakenedResolvecast",
					},
				}
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {147207},
				dstisplayerunit = true,
				execute = {
					{
						"quash","WeakenedResolvecast",
					},
				}
			},				
			-- AuraOfPride
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146817},
				execute = {
					{
						"raidicon","AuraOfPridemark",
						"insert",{"AuraOfPrideunists","#5#"},
						"canceltimer","timerAuraOfPride",
						"scheduletimer",{"timerAuraOfPride",0.5},
						"set",{AuraOfPrideunists2 = "&RaidDebuff|"..SN[146817].."&"},
						"openwindow",{"5","<AuraOfPrideunists2>"},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iAuraOfPride",
						"announce","AuraOfPridesay",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"set",{AuraOfPride = "INCR|1"},
					},					
				},
			},			
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {146817},
				execute = {
					{
						"set",{AuraOfPride = "DECR|1"},
						"removeraidicon","#5#",
					},
					{
						--"expect",{"#4#","==","&playerguid&"},
						"expect",{"<AuraOfPride>",">","0"},
						"set",{AuraOfPrideunists2 = "&RaidDebuff|"..SN[146817].."&"},
						"openwindow",{"5","<AuraOfPrideunists2>"},
					},
					{
						"expect",{"<AuraOfPride>","==","0"},
						"closewindow",
					},					
				},
			},		
			-- TitanGift
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144359, 146594},
				execute = {
					{
						"insert",{"TitanGiftunists","#5#"},
						"canceltimer","timerTitanGift",
						"scheduletimer",{"timerTitanGift",0.5},
					},				
					{
						"expect",{"#4#","==","&playerguid&"},
						"invoke",{
							{
								"expect",{"&playerdebuff|"..SN[146817].."&","==","false"},
								"alert","iTitanGift",
								"announce","TitanGiftsay",
							},
							{
								"expect",{"&playerdebuff|"..SN[146817].."&","==","true"},
								"alert","iTitanGiftAuraOfPride",
							},							
						},
					},
					{
						"expect",{"&targetdebuff|#5#|"..SN[146817].."&","==","false"},
						"raidicon","TitanGiftmark",
					},					
				},
			},		
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144359, 146594},
				execute = {
					{
						"removeraidicon","#5#",
					},				
				},
			},		
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {146595},
				execute = {
					{
						"alert","GiftOfTitanscd",
					},				
				}
			},	
			-- Projection
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146822},
				execute = {
					{
						"insert",{"Projectionunists","#5#"},
						"canceltimer","timerProjection",
						"scheduletimer",{"timerProjection",0.5},
					},				
					{
						"expect",{"#4#","==","&playerguid&"},
						"batchalert",{"Projectioncast","iProjection"},
					},				
				},
			},
			-- Banishment
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145215},
				execute = {
					{
						"insert",{"Banishmentunists","#5#"},
						"canceltimer","timerBanishment",
						"scheduletimer",{"timerBanishment",0.5},
					},				
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iBanishment",
					},				
				},
			},					
		},
	}

	DXE:RegisterEncounter(data)
end
