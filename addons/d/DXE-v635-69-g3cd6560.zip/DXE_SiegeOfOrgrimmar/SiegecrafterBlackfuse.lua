local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST
--TODO:
-- Make PatternRecognition For all or just the player
-- Laser finder
do
	local data = {
		version = 2,
		key = "Siegecrafter Blackfuse",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Siegecrafter Blackfuse"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-SIEGECRAFTER BLACKFUSE.BLP:35:35",
		triggers = {
			scan = {71504}, 
		},
		onactivate = {
			tracing = {71504},
			tracerstart = true,
			combatstop = true,
			defeat = {71504},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
		},
		windows = {
		--	proxwindow = true,
			--proxrange = 8,
		},
		arrows = {
			Sawbladearrow = {
				varname = SN[143265],
				unit = "&upvalue&",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[143265],
				range1 = 8,
				range2 = 10,
				range3 = 12,
				ability = 8132,
				icon = ST[143265],
			},		
		},
		raidicons = {
			Sawblademark = {
				varname = SN[143265],
				type = "FRIENDLY",
				persist = 10,
				unit = "&upvalue&",
				icon = 1,
				ability = 8130,
				icon2 = ST[143265],
			},
		},			
		announces = { 
			Sawbladesay = {
				varname = format(L.alert["%s %s %s!"],SN[143266],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143266],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143266],
			},	
			CrawlerMineFixatesay = {
				varname = format(L.alert["%s %s %s!"],SN["ej8212"],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN["ej8212"],L.alert["on"],L.alert["Me"]),
				ability = 8212,
				icon = EJST[8212],
				enabled = false,
			},	
			LaserFixatesay = {
				varname = format(L.alert["%s %s %s!"],SN[143828],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143828],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143828],
			},	
			DeathFromAbovesay = {
				varname = format(L.alert["%s %s %s!"],SN[144208],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[144208],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[144208],
			},				
		},		
		userdata = {
			ShockwaveMissile = 0,
		},
		onstart = {
			{
				"alert","AutomatedShreddercd",
			},
		},
		messages = {
			mSawblade = {
				varname = format(L.alert["%s %s %s"],SN[143265],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[143265],L.alert["on"]),
				text2 = format(L.alert["%s!"],SN[143265]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143265],
			},
			mDeathFromAbove = {
				varname = format(L.alert["%s %s %s"],SN[144208],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[144208],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144208],
			},			
			mCrawlerMine = {
				varname = format(L.alert["%s %s %s"],SN["ej8212"],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN["ej8212"],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8212,
				icon = EJST[8212],
				throttle = 5,
			},
			mReadyToGo = {
				varname = format(L.alert["%s %s %s"],SN[145580],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[145580],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8212,
				icon = ST[145580],
				--throttle = 5,
			},			
			mMagneticCrush = {
				varname = format(L.alert["%s"],SN[144466]),
				type = "message",
				text = format(L.alert["%s"],SN[144466]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8212,
				icon = ST[144466],
				throttle = 15,
			},
			mShockwaveMissileOver = {
				varname = format(L.alert["%s %s"],SN[143639],L.alert["over"]),
				type = "message",
				text = format(L.alert["%s %s"],SN[143639],L.alert["over"]),
				color1 = "GREEN",
				sound = "ALERT13",
				ability = 8212,
				icon = ST[143639],
			},	
			mProtectiveFrenzy = {
				varname = format(L.alert["%s %s %s"],SN[145365],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[145365],L.alert["on"]),
				--text2 = format(L.alert["%s %s #5# (#11#)"],SN[145365],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8212,
				icon = ST[145365],
				exdps = true,
			},
			mElectrostaticCharge = {
				varname = format(L.alert["%s %s %s (2)"],SN[143385],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[143385],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[143385],L.alert["on"]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8212,
				icon = ST[143385],
			},	
			mDeathFromAboveApplied = {
				varname = format(L.alert["%s"],SN[144210]),
				type = "message",
				text = format(L.alert["%s"],SN[144210]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8212,
				icon = ST[144210],
			},	
			mShockwaveMissileInc = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[143639]),
				type = "message",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[143639]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8204,
				icon = ST[143639],
			},				
			mShockwaveMissile = {
				varname = format(L.alert["%s (2)"],SN[143639]),
				type = "message",
				text = format(L.alert["%s (<ShockwaveMissile>)"],SN[143639]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8204,
				icon = ST[143639],
			},				
		},
		alerts = {
			-- Cooldowns
			LaunchSawbladecd = {
				varname = format(L.alert["%s Cooldown"],SN[143265]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143265]),
				time = 10,
				color1 = "NEWBLUE",
				icon = ST[143265],
				ability = 8132,
			},
			AutomatedShreddercd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8199"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8199"]),
				time = 35,
				time2 = 60,
				color1 = "NEWBLUE",
				icon = EJST[8199],
				ability = 8199,
			},
			DeathFromAbovecd = {
				varname = format(L.alert["%s Cooldown"],SN[144208]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144208]),
				time = 40,
				time2 = 17,
				color1 = "NEWBLUE",
				icon = ST[144208],
				ability = 8132,
				exhealer = true,
			},
			AssemblyLinecd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8202"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8202"]),
				time = 40,
				color1 = "NEWBLUE",
				icon = EJST[8202],
				ability = 8202,
			},
			ShockwaveMissilecd = {
				varname = format(L.alert["%s Cooldown"],SN[143641]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143641]),
				time = 12,
				color1 = "NEWBLUE",
				icon = ST[143641],
				ability = 8204,
			},
			ElectroStaticChargecd = {
				varname = format(L.alert["%s Cooldown"],SN[143385]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143385]),
				time = 17,
				color1 = "NEWBLUE",
				icon = ST[143385],
				ability = 8204,
				exhealer = true,
				exdps = true,
			},				
			-- Warning
			wAutomatedShredder = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN["ej8199"]),
				type = "inform",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN["ej8199"]),
				time = 2,
				color1 = "ORANGE",
				icon = EJST[8199],
				sound = "ALERT10",
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			wAssemblyLine = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN["ej8202"]),
				type = "inform",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN["ej8202"]),
				time = 2,
				color1 = "ORANGE",
				icon = EJST[8202],
				sound = "ALERT10",
				ability = 8132,
				extank = true,
				exhealer = true,
			},
			wDeathFromAbove = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[144208]),
				type = "inform",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[144208]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[144208],
				sound = "ALERT10",
				ability = 8132,
			},			
			-- Inform			
			iSawblade = {
				varname = format(L.alert["%s %s %s!"],SN[143265],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143265],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[143265],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iCrawlerMineFixate = {
				varname = format(L.alert["%s %s %s!"],SN["ej8212"],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN["ej8212"],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = EJST[8212],
				sound = "ALERT10",
				ability = 8212,
				flashscreen = true,
			},
			iLaserFixate = {
				varname = format(L.alert["%s %s %s!"],SN[143828],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143828],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143828],
				sound = "ALERT12",
				ability = 8132,
				flashscreen = true,
			},
			iSuperheated = {
				varname = format(L.alert["%s %s %s!"],SN[143856],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143856],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[143856],
				sound = "ALERT10",
				ability = 8132,
			},	
			iPatternRecognition = {
				varname = format(L.alert["%s %s %s!"],SN[144236],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144236],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[144236],
				sound = "ALERT14",
				ability = 8207,
			},
			iPatternRecognitionOver = {
				varname = format(L.alert["%s %s!"],SN[144236],L.alert["over"]),
				type = "inform",
				text = format(L.alert["%s %s!"],SN[144236],L.alert["over"]),
				time = 2,
				color1 = "GREEN",
				icon = ST[144236],
				sound = "ALERT14",
				ability = 8207,
			},				
			-- Casts
			PatternRecognitioncast = {
				varname = format(L.alert["%s Active"],SN[144236]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[144236]),
				time = 60,
				color1 = "RED",
				icon = ST[144236],
				ability = 8207,
			},
			-- Debuff
			ElectrostaticChargeDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143385]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143385]),
				text2 = format(L.alert["#5# (1): %s"],SN[143385]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143385]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143385]),				
				time = 60,
				color1 = "INDIGO",
				ability = 8130,
				icon = ST[143385],
				tag = "#5#",
				exdps = true,
			},
			ProtectiveFrenzyDebuff = {
				varname = format(L.alert["%s Debuff"],SN[145365]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[145365]),
				text2 = format(L.alert["#5#: %s"],SN[145365]),
				time = 10,
				color1 = "TAN",
				ability = 8130,
				icon = ST[145365],
				tag = "#5#",
				exdps = true,
			},				
		},
		events = {
			-- DeathFromAbove
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144208},
				execute = {
					{
						"batchalert",{"wDeathFromAbove","DeathFromAbovecd"},
					},
					{
						"target",{
							source = "#1#",
							wait = 0.1,
							schedule = 5,
							announce = "DeathFromAbovesay",
							message = "mDeathFromAbove",
						},	
					},
				},
			},
			-- DeathFromAboveApplied
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144210},
				execute = {
					{
						"message","mDeathFromAboveApplied",
					},

				},
			},					
			-- Sawblade
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143265},
				execute = {
					{
						"alert","LaunchSawbladecd",
					},
					{
						"target",{
							source = "#1#",
							wait = 0.1,
							schedule = 16,
							raidicon = "Sawblademark",
							arrow = "Sawbladearrow",
							arrowrange = 8,
							arrowdef = "<",
							--announce = "HeroicShockwavesay",
							message = "mSawblade",
							alerts = {
								--self = "iHeroicShockwaveself",
								--other = 
								--unknown = "",
								unknownmsg = {"mSawblade", text = 2},
							},
						},	
					},
				},
			},
			-- CrawlerMine   Break-in Period
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145269},
				execute = {
					{
						"message","mCrawlerMine",
					},				
				},
			},
			-- Ready to go
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145580},
				execute = {
					{
						"message","mReadyToGo",
					},				
				},
			},
			-- MagneticCrush
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144466},
				execute = {
					{
						"message","mMagneticCrush",
					},				
				},
			},	
			-- Superheated
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143856},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iSuperheated",
					},				
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143856},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iSuperheated",
					},				
				},
			},	
			-- ShockwaveMissileOver
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143639},
				execute = {
					{
						"message","mShockwaveMissileOver",
					},
				},
			},	
			{
				type = "event",
				event = "YELL",
				execute = {
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Presenting... the beautiful new ST-03 Shockwave missile turret!)"]},
						"set",{ShockwaveMissile = 0},
						"message","mShockwaveMissileInc",
						"alert","ShockwaveMissilecd",
					},
				}
			},
			{
				type = "combatevent",
				eventtype = "SPELL_SUMMON",
				spellid = {143641},
				execute = {
					{
						"set",{ShockwaveMissile = "INCR|1"},
						"message","mShockwaveMissile",
					},		
					--{
					--	"expect",{"<ShockwaveMissile>","<","3"},
					--	"alert","ShockwaveMissilecd",
					--},
				},
			},	
			-- PatternRecognition
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144236},
				dstisplayerunit = true,
				execute = {
					{
						"batchalert",{"PatternRecognitioncast","iPatternRecognition"},
					},				
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144236},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iPatternRecognitionOver",
					},				
				},
			},
			-- ProtectiveFrenzy
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145365},
				execute = {
					{
						"message","mProtectiveFrenzy",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","ProtectiveFrenzyDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"ProtectiveFrenzyDebuff", text = 2},
					},						
				},
			},
			-- ElectrostaticCharge
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143385},
				execute = {
					{
						"message","mElectrostaticCharge",
						"alert","ElectroStaticChargecd",
					},	
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","ElectrostaticChargeDebuff",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"ElectrostaticChargeDebuff", text = 2},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143385},
				execute = {
					{
						"message",{"mElectrostaticCharge", text = 2},
						"alert","ElectroStaticChargecd",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"ElectrostaticChargeDebuff", text = 3},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"ElectrostaticChargeDebuff", text = 4},
					},						
				},
			},			


			
			{
				type = "event",
				event = "BOSS_WHISPER", 
				execute = {
					-- Sawblade
					{
						"expect",{"#1#","find","spell:143266"}, 
						"alert","iSawblade",
						"announce","Sawbladesay",
					},
					-- CrawlerMineFixate 
					{
						"expect",{"#1#","find","Ability_Siege_Engineer_Detonate"}, 
						"alert","iCrawlerMineFixate",
						"announce","CrawlerMineFixatesay",
					},	
					-- LaserFixate 
					{
						"expect",{"#1#","find","Ability_Siege_Engineer_Superheated"}, 
						"alert","iLaserFixate",
						"announce","LaserFixatesay",
					},					
				},
			},
			-- Emotes
			{
				type = "event",
				event = "EMOTE", 
				execute = {
					-- Automated Shredder
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(An Automated Shredder draws near!)"]},
						"invoke",{
							{
								"alert","wAutomatedShredder",
								"alert",{"AutomatedShreddercd", time = 2},
								"alert",{"DeathFromAbovecd", time = 2},
							},
						},
					},
					-- Assembly Line
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Unfinished weapons begin to roll out on the assembly line.)"]},
						"invoke",{
							{
								"alert","wAssemblyLine",
								"alert","AssemblyLinecd",
								--"alert",{"AutomatedShreddercd", time = 2},
								--"alert",{"DeathFromAbovecd", time = 2},
							},
						},
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","71591"}, -- Shredder
						"quash","DeathFromAbovecd",
					},
				},
			},			
		},
	}

	DXE:RegisterEncounter(data)
end
