local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST
--Todo
-- The rest of _START
do
	local boss_list = {
		71152, -- Skeer the Bloodseeker
		71153, -- Hisek the Swarmkeeper
		71154, -- Ka'roz the Locust
		71155, -- Korven the Prime
		71156, -- Kaz'tik the Manipulator
		71157, -- Xaril the Poisoned Mind
		71158, -- Rik'kal the Dissector
		71160, -- Iyyokuk the Lucid
		71161  -- Kil'ruk the Wind-Reaver
	}
	local data = {
		version = 2,
		key = "Paragons of the Klaxxi",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Paragons of the Klaxxi"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-KLAXXI PARAGONS.BLP:35:35",
		triggers = {
			scan = boss_list,
		},
		onactivate = {
			--tracing = {69473},
			sortedtracing = boss_list,
			tracerstart = true,
			combatstop = true,
			--defeat = {69473},
			unittracing = {"boss1","boss2","boss3"}, --,"boss4","boss5"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
		},
		windows = {
			--proxwindow = true,
			--proxrange = 8,
		},
		raidicons = {
			Aimmark = {
				varname = SN[142948],
				type = "FRIENDLY",
				persist = 30,
				unit = "#5#",
				icon = 8,
				ability = 8130,
				icon2 = ST[142948],
			},
			Mesmerizemark = {
				varname = SN[142671],
				type = "FRIENDLY",
				persist = 30,
				unit = "#5#",
				icon = 7,
				ability = 8130,
				icon2 = ST[142671],
			},			
		},
		arrows = {
			DeathfromAbovearrow = {
				varname = SN["ej8008"],
				unit = "&upvalue&", 
				persist = 6,
				action = "AWAY",
				msg = L.alert["MOVE AWAY"],
				spell = SN["ej8008"],
				range1 = 10,
				range2 = 12,
				range3 = 14,
			},
			Whirlingaway = {
				varname = SN[143701].." - "..L.alert["MOVE AWAY!"],
				unit = "#5#",
				persist = 10,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[143701],
				range1 = 8,
				range2 = 10,
				range3 = 12,
			},
			Aimarrow = {
				varname = SN[142948],
				unit = "#5#",
				persist = 10,
				action = "TOWARD",
				--msg = format(L.alert["%s %s #5#!"],SN[142948],L.alert["on"]),
				msg = SN[142948],
				spell = SN[142948],
				sound = "ALERT5",
				lockon = true,
				--range1 = 7,
				--range2 = 10,
				--range3 = 14,
			},
		},	
		announces = {
			DeathfromAbovesay = {
				varname = format(L.alert["%s %s %s!"],SN["ej8008"],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN["ej8008"],L.alert["on"],L.alert["Me"]),
				ability = 8008,
			},
			Whirlingsay = {
				varname = format(L.alert["%s %s %s!"],SN[143701],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143701],L.alert["on"],L.alert["Me"]),
				ability = 8008,
			},
			Aimsay = {
				varname = format(L.alert["%s %s %s!"],SN[142948],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[142948],L.alert["on"],L.alert["Me"]),
				ability = 8008,
			},
			Mesmerizesay = {
				varname = format(L.alert["%s %s %s!"],SN[142671],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[142671],L.alert["on"],L.alert["Me"]),
				ability = 8008,
			},					
		},		
		timers = {
			timerCheckParagons = {
				--Xaril the Poisoned-Mind
				{
					"expect",{"&tabread|Paragons|71157&","~=","true"},
					"expect",{"&bossexist|71157&","==","true"}, 
					"tabinsert",{"Paragons","71157","true"},
					--"debug",{"Xaril"},
				},
				--Kaz'tik the Manipulator
				--{
				--	"expect",{"&tabread|Paragons|71156&","==","true"},
				--	"expect",{"&bossexist|71156&","==","true"}, 
				--	"tabinsert",{"Paragons","71156","true"},
				--},				
				--Korven the Prime
				{
					"expect",{"&tabread|Paragons|71155&","~=","true"},
					"expect",{"&bossexist|71155&","==","true"}, 
					"tabinsert",{"Paragons","71155","true"},
					"alert",{"ShieldBashcd", time = 2},
				--	"debug",{"Korven"},
				},
				--Iyyokuk the Lucid
				{
					"expect",{"&tabread|Paragons|71160&","~=","true"},
					"expect",{"&bossexist|71160&","==","true"}, 
					"tabinsert",{"Paragons","71160","true"},
					"alert","InsaneCalculationcd",
				--	"debug",{"Iyyokuk"},
				},
				--Hisek the Swarmkeeper
				{
					"expect",{"&tabread|Paragons|71153&","~=","true"},
					"expect",{"&bossexist|71153&","==","true"}, 
					"tabinsert",{"Paragons","71153","true"},
					"alert",{"Aimcd", time = 2},
					--"alert","RapidFirecd",
				--	"debug",{"Hisek"},
				},				
			},
			timerDeathfromAbove = {
				{
					"target",{
						--source = "#1#",
						npcid = 71161,
						wait = 0.25,
						schedule = 700,
						--raidicon = "Focusedmark",
						arrow = "DeathfromAbovearrow",
						arrowdef = "<",
						arrowrange = 10,
						announce = "DeathfromAbovesay",
						message = "mDeathfromAbove",
						alerts = {
							self = "iDeathfromAbove",
							--other = 
						--	unknown = "Phase4",
							unknownmsg = {"mDeathfromAbove", text = 2},
						},
					},
				},
			},
			timerWhirling = {
				{
					"message","mWhirling",
				},
			},
		},
		userdata = {
			DeathCount = 0,
			Paragons = {type = "container"},
			ToxicRedUnits = {type = "container"},
			Whirlingunists = {type = "container", wipein = 3},
		},
		onstart = {
			{
	
			},
		},
		messages = {
			mWhirling = {
				varname = format(L.alert["%s %s %s"],SN[143701],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Whirlingunists&"],SN[143701],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143701],
			},	
			mDeathfromAbove = {
				varname = format(L.alert["%s!"],SN["ej8008"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN["ej8008"],L.alert["on"]),
				text2 = format(L.alert["%s"],SN["ej8008"]),
				color1 = "RED",
				icon = EJST[8008],
				sound = "ALERT13",
				ability = 8008,
			},
			mAmber = {
				varname = format(L.alert["%s %s %s"],SN[142564],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[142564],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[142564],
			},				
		},
		alerts = {
			ToxicCatalystcd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8036"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8036"]),
				time = 33,
				color1 = "NEWBLUE",
				icon = EJST[8036],
				ability = 8036,
			},
			ShieldBashcd = {
				varname = format(L.alert["%s Cooldown"],SN[143974]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143974]),
				time = 17,
				time2 = 19,
				color1 = "NEWBLUE",
				icon = ST[143974],
				ability = 8132,
				exhealer = true,
				exdps = true,
			},
			EncaseInAmbercd = {
				varname = format(L.alert["%s Cooldown"],SN[142564]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142564]),
				time = 30,
				color1 = "NEWBLUE",
				icon = ST[142564],
				ability = 8132,
			},
			InsaneCalculationcd = {
				varname = format(L.alert["%s Cooldown"],SN[142416]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142416]),
				time = 25,
				color1 = "NEWBLUE",
				icon = ST[142416],
				ability = 8132,
			},
			Flashcd = {
				varname = format(L.alert["%s Cooldown"],SN[143709]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143709]),
				time = 62,
				time2 = 14,
				color1 = "NEWBLUE",
				icon = ST[143709],
				ability = 8132,
			},
			HurlAmbercd = {
				varname = format(L.alert["%s Cooldown"],SN[143759]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143759]),
				time = 62,
				time2 = 44,
				color1 = "NEWBLUE",
				icon = ST[143759],
				ability = 8132,
			},
			Bloodlettingcd = {
				varname = format(L.alert["%s Cooldown"],SN[143280]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143280]),
				time = 35,
				time2 = 9,
				color1 = "NEWBLUE",
				icon = ST[143280],
				ability = 8132,
			},	
			Mutatecd = {
				varname = format(L.alert["%s Cooldown"],SN[143337]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143337]),
				time = 45,
				time2 = 34,
				color1 = "NEWBLUE",
				icon = ST[143337],
				ability = 8132,
			},	
			Injectioncd = {
				varname = format(L.alert["%s Cooldown"],SN[143339]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143339]),
				time = 9.5,
				time2 = 14,
				color1 = "NEWBLUE",
				icon = ST[143339],
				audiocd = true,
				audiotime = 5,
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			Aimcd = {
				varname = format(L.alert["%s Cooldown"],SN[142948]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[142948]),
				time = 42,
				time2 = 37,
				color1 = "NEWBLUE",
				icon = ST[142948],
				ability = 8132,
			},		
			--[[RapidFirecd = { -- Heroic
				varname = format(L.alert["%s Cooldown"],SN[143243]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143243]),
				time = 30,
				color1 = "NEWBLUE",
				icon = ST[143243],
				ability = 8132,
			},	--]]
			-- Warning
			wToxicCatalystBlue = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142725]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142725]),
				time = 2,
				color1 = "BLUE",
				icon = ST[142725],
				sound = "ALERT13",
				ability = 7906,
			},
			wToxicCatalystRed = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142726]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142726]),
				time = 2,
				color1 = "RED",
				icon = ST[142726],
				sound = "ALERT13",
				ability = 7906,
			},	
			wToxicCatalystYellow = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142727]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142727]),
				time = 2,
				color1 = "YELLOW",
				icon = ST[142727],
				sound = "ALERT13",
				ability = 7906,
			},	
			wToxicCatalystOrange = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142728]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142728]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[142728],
				sound = "ALERT13",
				ability = 7906,
			},	
			wToxicCatalystPurple = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142729]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142729]),
				time = 2,
				color1 = "PURPLE",
				icon = ST[142729],
				sound = "ALERT13",
				ability = 7906,
			},
			wToxicCatalystGreen = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142730]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142730]),
				time = 2,
				color1 = "GREEN",
				icon = ST[142730],
				sound = "ALERT13",
				ability = 7906,
			},
			wInsaneCalculationFire = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142416]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN[142416]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[142416],
				sound = "ALERT13",
				ability = 7906,
			},
			-- Inform
			iAim = {
				varname = format(L.alert["%s %s %s!"],SN[142948],L.alert["on"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s %s #5#!"],SN[142948],L.alert["on"]),
				text2 = format(L.alert["%s %s %s!"],SN[142948],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[142948],
				sound = "ALERT14",
				ability = 8132,
			},
			iMesmerize = {
				varname = format(L.alert["%s %s %s!"],SN[142671],L.alert["on"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s %s #5#!"],SN[142671],L.alert["on"]),
				text2 = format(L.alert["%s %s %s!"],SN[142671],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[142671],
				sound = "ALERT11",
				ability = 8132,
			},				
			iWhirling = {
				varname = format(L.alert["%s %s %s!"],SN[143701],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143701],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143701],
				sound = "ALERT11",
				ability = 8132,
			},			
			iDeathfromAbove = {
				varname = format(L.alert["%s %s %s!"],SN["ej8008"],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN["ej8008"],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = EJST[8008],
				sound = "ALERT10",
				ability = 8008,
			},
			iToxicBlue = {
				varname = format(L.alert["%s %s %s!"],SN[142532],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142532],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "BLUE",
				icon = ST[142532],
				sound = "ALERT10",
				ability = 8132,
			},
			iToxicRed = {
				varname = format(L.alert["%s %s %s!"],SN[142533],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142533],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[142533],
				sound = "ALERT10",
				ability = 8132,
			},
			iToxicYellow = {
				varname = format(L.alert["%s %s %s!"],SN[142534],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142534],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "YELLOW",
				icon = ST[142534],
				sound = "ALERT10",
				ability = 8132,
			},
			iToxicOrange = {
				varname = format(L.alert["%s %s %s!"],SN[142547],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142547],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[142547],
				sound = "ALERT10",
				ability = 8132,
			},
			iToxicPurple = {
				varname = format(L.alert["%s %s %s!"],SN[142548],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142548],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "PURPLE",
				icon = ST[142548],
				sound = "ALERT10",
				ability = 8132,
			},	
			iToxicGreen = {
				varname = format(L.alert["%s %s %s!"],SN[142549],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[142549],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "GRREN",
				icon = ST[142549],
				sound = "ALERT10",
				ability = 8132,
			},	
			-- Cast
			Ambercast = {
				varname = format(L.alert["%s Active"],SN[142564]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[142564]),
				time = 10,
				color1 = "RED",
				icon = ST[142564],
				ability = 8298,
				audiocd = true,
				audiotime = 10,
				tag = "#5#",
			},			
		},
		events = {		
			{
                type = "event",
                event = "INSTANCE_ENCOUNTER_ENGAGE_UNIT",
                execute = {
					{
						--"debug",{"engaged #1#"},
						"scheduletimer",{"timerCheckParagons",1},
					},
				},
			},
			-- wToxicCatalystRed
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142726},
				execute = {
					{
						"batchalert",{"wToxicCatalystRed","ToxicCatalystcd"},
					},
				},
			},
			-- wToxicCatalystYellow
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142727},
				execute = {
					{
						"batchalert",{"wToxicCatalystYellow","ToxicCatalystcd"},
					},
				},
			},
			-- wToxicCatalystOrange
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142728},
				execute = {
					{
						"batchalert",{"wToxicCatalystOrange","ToxicCatalystcd"},
					},
				},
			},
			-- wToxicCatalystPurple
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142729},
				execute = {
					{
						"batchalert",{"wToxicCatalystPurple","ToxicCatalystcd"},
					},
				},
			},
			-- wToxicCatalystGreen
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142730},
				execute = {
					{
						"batchalert",{"wToxicCatalystGreen","ToxicCatalystcd"},
					},
				},
			},
			-- InsaneCalculationFire
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {142416},
				execute = {
					{
						"alert","wInsaneCalculationFire",
					},
				},
			},
			-- ToxicsRemove
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142532,142533,142534},
				dstisplayerunit = true,
				execute = {
					{
						"closewindow",
					},	
				},
			},
			-- ToxicBlue
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142532},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicBlue",
					},
					{
						"set",{ToxicRedUnits = "&RaidDebuff|"..SN[142533].."&"},
						"openwindow",{"10","<ToxicRedUnits>"},					
					},
				},
			},
			-- ToxicRed
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142533},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicRed",
					},	
				},
			},
			-- iToxicYellow
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142534},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicYellow",
					},	
					{
						"set",{ToxicRedUnits = "&RaidDebuff|"..SN[142533].."&"},
						"openwindow",{"10","<ToxicRedUnits>"},					
					},
				},
			},
		--[[
			-- iToxicOrange
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142547},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicOrange",
					},	
				},
			},
			-- ToxicPurple
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142548},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicPurple",
					},	
				},
			},			
			-- iToxicGreen
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142549},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iToxicGreen",
					},	
				},
			},	--]]
			-- Whirling
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143701},
				execute = {
					{
						"insert",{"Whirlingunists","#5#"},
						"canceltimer","timerWhirling",
						"scheduletimer",{"timerWhirling",0.5},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iWhirling",
						"announce","Whirlingsay",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"expect",{"&inrange|#5#&","<","6"},
						"arrow","Whirlingaway",
					},	
				},
			},	
			-- Aim
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142948},
				execute = {
					{
						"alert","Aimcd",
						"raidicon","Aimmark",
					},	
					{
						"expect",{"#4#","==","&playerguid&"},
						"announce","Aimsay",
						"alert",{"iAim", text = 2},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert","iAim",
						"arrow","Aimarrow",
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {142948},
				execute = {
					{
						"removeraidicon","#5#",
						"removearrow","#5#",
					},
				},
			},
			-- Amber
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142564},
				execute = {
					{
						"message","mAmber",
						"batchalert",{"Ambercast","EncaseInAmbercd"},
					},	
					--{
						--"expect",{"#4#","~=","&playerguid&"},
						
					--},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {142564},
				execute = {
					{
						"quash","Ambercast",
					},					
				},
			},
			-- Mesmerize
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {142671},
				execute = {
					{
						--"alert","Aimcd", -- cd ?
						"raidicon","Mesmerizemark",
					},	
					{
						"expect",{"#4#","==","&playerguid&"},
						"announce","Mesmerizesay",
						"alert",{"iMesmerize", text = 2},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert","iMesmerize",
					},					
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {142671},
				execute = {
					{
						"removeraidicon","#5#",
					},
				},
			},
			
			
			-- DeathfromAbove
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {142232},
				execute = {
					{
						"canceltimer","timerDeathfromAbove",
						"scheduletimer",{"timerDeathfromAbove",17},
					},	
				},
			},	
			
			
			
			
			
			
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"expect",{"#5#","==","143545"}, 
						"invoke",{
							--Kil'ruk the Wind-Reaver
							{
								"expect",{"&tabread|Paragons|71161&","~=","true"},
								"expect",{"&bossexist|71161&","==","true"}, 
								--"debug",{"Kil'ruk"},
								"tabinsert",{"Paragons","71161","true"},
								"scheduletimer",{"timerDeathfromAbove",23},
							},
							--Ka'roz the Locust
							{
								"expect",{"&tabread|Paragons|71154&","~=","true"},
								"expect",{"&bossexist|71154&","==","true"}, 
								"tabinsert",{"Paragons","71154","true"},
								"alert",{"Flashcd", time = 2},
								"alert",{"HurlAmbercd", time = 2},
								--"debug",{"Ka'roz"},
							},
							--Skeer the Bloodseeker
							{
								"expect",{"&tabread|Paragons|71152&","~=","true"},
								"expect",{"&bossexist|71152&","==","true"}, 
								"tabinsert",{"Paragons","71152","true"},
								"alert",{"Bloodlettingcd", time = 2},
							--	"debug",{"Skeer "},
							},
							--Rik'kal the Dissector
							{
								"expect",{"&tabread|Paragons|71158&","~=","true"},
								"expect",{"&bossexist|71158&","==","true"}, 
								"tabinsert",{"Paragons","71158","true"},
								"alert",{"Injectioncd", time = 2},
								"alert",{"Mutatecd", time = 2},
								--"debug",{"Rik'kal"},
							},
						},
					},
				},
				{
						"expect",{"#1#","==","boss2"},
						"expect",{"#5#","==","143545"}, 
						"invoke",{
							--Kil'ruk the Wind-Reaver
							{
								"expect",{"&tabread|Paragons|71161&","~=","true"},
								"expect",{"&bossexist|71161&","==","true"}, 
								--"debug",{"Kil'ruk"},
								"tabinsert",{"Paragons","71161","true"},
								"scheduletimer",{"timerDeathfromAbove",23},
							},
							--Ka'roz the Locust
							{
								"expect",{"&tabread|Paragons|71154&","~=","true"},
								"expect",{"&bossexist|71154&","==","true"}, 
								"tabinsert",{"Paragons","71154","true"},
								"alert",{"Flashcd", time = 2},
								"alert",{"HurlAmbercd", time = 2},
								--"debug",{"Ka'roz"},
							},
							--Skeer the Bloodseeker
							{
								"expect",{"&tabread|Paragons|71152&","~=","true"},
								"expect",{"&bossexist|71152&","==","true"}, 
								"tabinsert",{"Paragons","71152","true"},
								"alert",{"Bloodlettingcd", time = 2},
								--"debug",{"Skeer "},
							},
							--Rik'kal the Dissector
							{
								"expect",{"&tabread|Paragons|71158&","~=","true"},
								"expect",{"&bossexist|71158&","==","true"}, 
								"tabinsert",{"Paragons","71158","true"},
								"alert",{"Injectioncd", time = 2},
								"alert",{"Mutatecd", time = 2},
								--"debug",{"Rik'kal"},
							},
						},
				},
				{
						"expect",{"#1#","==","boss3"},
						"expect",{"#5#","==","143545"}, 
						"invoke",{
							--Kil'ruk the Wind-Reaver
							{
								"expect",{"&tabread|Paragons|71161&","~=","true"},
								"expect",{"&bossexist|71161&","==","true"}, 
								--"debug",{"Kil'ruk"},
								"tabinsert",{"Paragons","71161","true"},
								"scheduletimer",{"timerDeathfromAbove",23},
							},
							--Ka'roz the Locust
							{
								"expect",{"&tabread|Paragons|71154&","~=","true"},
								"expect",{"&bossexist|71154&","==","true"}, 
								"tabinsert",{"Paragons","71154","true"},
								"alert",{"Flashcd", time = 2},
								"alert",{"HurlAmbercd", time = 2},
								--"debug",{"Ka'roz"},
							},
							--Skeer the Bloodseeker
							{
								"expect",{"&tabread|Paragons|71152&","~=","true"},
								"expect",{"&bossexist|71152&","==","true"}, 
								"tabinsert",{"Paragons","71152","true"},
								"alert",{"Bloodlettingcd", time = 2},
								"debug",{"Skeer "},
							},
							--Rik'kal the Dissector
							{
								"expect",{"&tabread|Paragons|71158&","~=","true"},
								"expect",{"&bossexist|71158&","==","true"}, 
								"tabinsert",{"Paragons","71158","true"},
								"alert",{"Injectioncd", time = 2},
								"alert",{"Mutatecd", time = 2},
							--	"debug",{"Rik'kal"},
							},
						},
				},	
				{
						"expect",{"#1#","==","boss4"},
						"expect",{"#5#","==","143545"}, 
						"invoke",{
							--Kil'ruk the Wind-Reaver
							{
								"expect",{"&tabread|Paragons|71161&","~=","true"},
								"expect",{"&bossexist|71161&","==","true"}, 
							--	"debug",{"Kil'ruk"},
								"tabinsert",{"Paragons","71161","true"},
								"scheduletimer",{"timerDeathfromAbove",23},
							},
							--Ka'roz the Locust
							{
								"expect",{"&tabread|Paragons|71154&","~=","true"},
								"expect",{"&bossexist|71154&","==","true"}, 
								"tabinsert",{"Paragons","71154","true"},
								"alert",{"Flashcd", time = 2},
								"alert",{"HurlAmbercd", time = 2},
							--	"debug",{"Ka'roz"},
							},
							--Skeer the Bloodseeker
							{
								"expect",{"&tabread|Paragons|71152&","~=","true"},
								"expect",{"&bossexist|71152&","==","true"}, 
								"tabinsert",{"Paragons","71152","true"},
								"alert",{"Bloodlettingcd", time = 2},
							--	"debug",{"Skeer "},
							},
							--Rik'kal the Dissector
							{
								"expect",{"&tabread|Paragons|71158&","~=","true"},
								"expect",{"&bossexist|71158&","==","true"}, 
								"tabinsert",{"Paragons","71158","true"},
								"alert",{"Injectioncd", time = 2},
								"alert",{"Mutatecd", time = 2},
						--		"debug",{"Rik'kal"},
							},
						},
					},
				},				
			{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","71152"}, -- Skeer the Bloodseeker
						"quash","Bloodlettingcd",
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71153"}, -- Hisek the Swarmkeeper
						"quash","Aimcd",
						--"quash","RapidFirecd",
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71154"}, -- Ka'roz the Locust
						"batchquash",{"Flashcd","HurlAmbercd"},
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71155"}, -- Korven the Prime
						"batchquash",{"ShieldBashcd","EncaseInAmbercd"},
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71156"}, -- Kaz'tik the Manipulator
					--	"quash","ToxicCatalystcd",
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71157"}, -- Xaril the Poisoned Mind
						"quash","ToxicCatalystcd",
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71158"}, -- Rik'kal the Dissector
						"batchquash",{"Mutatecd","Injectioncd"},
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71160"}, -- Iyyokuk the Lucid
						"quash","InsaneCalculationcd",
						"set",{DeathCount = "INCR|1"},
					--	"scheduletimer",{"timerCheckParagons",1},
					},
					{
						"expect",{"&npcid|#4#&","==","71161"}, -- Kil'ruk the Wind-Reaver
						--"quash","TearRealitycd",
						"set",{DeathCount = "INCR|1"},
						--"scheduletimer",{"timerCheckParagons",1},
					},					
					{
						"expect",{"<DeathCount>","==","9"},
						"endcombat",
					},
				},
			},
		},
	}

	DXE:RegisterEncounter(data)
end
