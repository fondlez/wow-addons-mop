local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST
--TODO

local faction = UnitFactionGroup("player")
local Galakras_list, Galakras_list2

if faction == "Horde" then
	-- Horde npcs
	Galakras_list = {
		--72249, -- Galakras,
		--72358, -- Kor'kron Cannon
		72560, -- Lor'themar Theron
		72561, -- Lady Sylvanas Windrunner
		73909, -- Archmage Aethas Sunreaver
	}
	Galakras_list2 = {
		72249, -- Galakras,
		72560, -- Lor'themar Theron
		72561, -- Lady Sylvanas Windrunner
		73909, -- Archmage Aethas Sunreaver
	}
elseif faction == "Alliance" then
	-- Alliance npcs
	Galakras_list = {
		--72249, -- Galakras,
		--72358, -- Kor'kron Cannon
		72311, -- King Varian Wrynn
		72302, -- Lady Jaina Proudmoore
		73910, -- Vereesa Windrunner
	}
	Galakras_list2 = {
		72249, -- Galakras,
		72311, -- King Varian Wrynn
		72302, -- Lady Jaina Proudmoore
		73910, -- Vereesa Windrunner
	}		
else
	error("DXE: Unable to detect faction. Please report this bug.")
end
	
do
	local data = {
		version = 4,
		key = "Galakras",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Galakras"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-GALAKRAS.BLP:35:35",
		triggers = {
			--scan = {72249, 72560, 72311},  -- Galakras, Lor'themar Theron (Horde), King Varian Wrynn (Alliance)
			scan = Galakras_list,
			yell = L.chat_SiegeOfOrgrimmar["(Dragonmaw clan, retake the docks and push them into the sea!)"],
		},
		onactivate = {
			--tracing = {72249},
			sortedtracing = Galakras_list,
			tracerstart = true,
			combatstop = true,
			defeat = {72249},
			unittracing = {"boss1","boss2","boss3"},
			delayrecombat = 180,
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
		},
		windows = {
			--proxwindow = true,
			--proxrange = 8,
		},
		timers = {
			timerAdds = {
				{
					"alert",{"TowerDefendercd", time = 2},
					"message","mTowerDefender",
					"scheduletimer",{"timerAdds",60},	
				},
			},		
			timerForces = {
				{
					"set",{AddCount = "INCR|1"},
				},
				{
					"expect",{"<AddCount>","==","1"},
					"alert",{"Addscd", time = 3},
				},
				{
					"expect",{"<AddCount> <AddCount> <AddCount>","==","3 7 11"},
					"alert",{"Addscd", time = 4},
				},							
				{
					"expect",{"<AddCount> <AddCount> <AddCount> <AddCount>","~=","1 3 7 11"},
					"alert","Addscd",
				},
			},				
		},
		raidicons = {
			ShamanMark = {
				varname = L.npc_SiegeOfOrgrimmar["Dragonmaw Tidal Shaman"],
				type = "MULTIENEMY",
				persist = 120,
				unit = "<Shaman>",
				id = 72367,
				reset = 3,
				icon = 1,
				total = 5,
			},
			FlamesofGalakrondMark = {
				varname = SN[147068],
				type = "FRIENDLY",
				persist = 6,
				unit = "#5#",
				icon = 8,
			},
		},
		announces = { 
			--[[ArcingSmashsay = {
				varname = format(L.alert["%s %s %s!"],SN[147688],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[147688],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[147688],
			},--]]
			FlamesofGalakrondsay = {
				varname = format(L.alert["%s %s %s!"],SN[147068],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[147068],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[147068],
			},					
		},
		userdata = {
			Shaman = "",
			Shamanunit = {type = "container"},
			--DemoCount = 0,
			AddCount = 0,
		},
		onstart = {
			{
				"expect",{"&heroic&","==","true"},
				"alert","TowerDefendercd",
				"scheduletimer",{"timerAdds",6},
			},
			{
				"expect",{"&heroic&","==","false"},
				--"batchalert",{"SouthTowercd","NorthTowercd"},
				"alert","SouthTowercd",
			},
		},
		messages = {
			--[[mArcingSmash = {
				varname = format(L.alert["%s %s %s"],SN[147688],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[147688],L.alert["on"]),
				color1 = "GREEN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[147688],
			},--]]
			mChainHeal = {
				varname = format(L.alert["%s"],SN[146757]),
				type = "message",
				text = format(L.alert["%s"],SN[146757]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[146757],
			},
			mShatteringCleave = {
				varname = format(L.alert["%s"],SN[146849]),
				type = "message",
				text = format(L.alert["%s"],SN[146849]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[146849],
			},			
			mDemolisher = {
				varname = format(L.alert["%s"],SN["ej8562"]),
				type = "message",
				text = format(L.alert["%s"],SN["ej8562"]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8562,
				icon = EJST[8562],
			},		
			mTowerDefender = {
				varname = format(L.alert["%s!"],L.chat_SiegeOfOrgrimmar["Tower Defender"]),
				type = "message",
				text = format(L.alert["%s!"],L.chat_SiegeOfOrgrimmar["Tower Defender"]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[146757],
			},	
			mFlamesofGalakrond = {
				varname = format(L.alert["%s %s %s"],SN[147068],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[147068],L.alert["on"]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[147068],
				--exdps = true,
			},
			mFlamesOfGalakrondStack = {
				varname = format(L.alert["%s (1)"],SN[147029]),
				type = "message",
				text = format(L.alert["%s (1)"],SN[147029]),
				text2 = format(L.alert["%s (#11#)"],SN[147029]),
				color1 = "INDIGO",
				icon = ST[147029],
				sound = "ALERT13",
				ability = 8132,
				exdps = true,
			--	exhealer = true,
				throttle = 3,
			},		
		},
		alerts = {
			-- Cooldowns
			CrushersCallcd = {
				varname = format(L.alert["%s Cooldown"],SN[146769]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[146769]),
				time = 30,
				color1 = "NEWBLUE",
				icon = ST[146769],
				ability = 8132,
			},			
			Demolishercd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8562"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8562"]),
				time = 20,
				color1 = "NEWBLUE",
				icon = EJST[8562],
				ability = 8562,
			},
			Protocd = {
				varname = format(L.alert["%s Cooldown"],SN["ej8587"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej8587"]),
				time = 55,
				color1 = "NEWBLUE",
				icon = EJST[8587],
				ability = 8587,
			},			
			Addscd = {
				varname = format(L.alert["Next Adds: %s"],"<AddsCount>"),
				type = "dropdown",
				text = format(L.alert["Next Adds: %s"],"<AddsCount>"),
				time = 55,
				time2 = 6.5,
				time3 = 48,
				time4 = 110,
				color1 = "NEWBLUE",
				icon = ST[146769],
				ability = 8132,
			},	
			SouthTowercd = {
				varname = format(L.alert["%s Cooldown"],L.chat_SiegeOfOrgrimmar["South Tower"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],L.chat_SiegeOfOrgrimmar["South Tower"]),
				time = 116.5,
				color1 = "NEWBLUE",
				icon = EJST[8562],
				ability = 8562,
			},
			NorthTowercd = {
				varname = format(L.alert["%s Cooldown"],L.chat_SiegeOfOrgrimmar["North Tower"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],L.chat_SiegeOfOrgrimmar["North Tower"]),
				time = 150,
				color1 = "NEWBLUE",
				icon = EJST[8562],
				ability = 8562,
			},
			TowerDefendercd = { -- Grunt
				varname = format(L.alert["%s Cooldown"],L.chat_SiegeOfOrgrimmar["Tower Defender"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],L.chat_SiegeOfOrgrimmar["Tower Defender"]),
				time = 6,
				time2 = 60,
				time3 = 35,
				color1 = "NEWBLUE",
				icon = ST[88852],
				ability = 8562,
			},	
			FlamesofGalakrondcd = {
				varname = format(L.alert["%s Cooldown"],SN[147068]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[147068]),
				time = 6,
				time2 = 18.6,
				color1 = "NEWBLUE",
				icon = ST[147068],
				ability = 8132,
			},
			ShatteringCleavecd = {
				varname = format(L.alert["%s Cooldown"],SN[146849]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[146849]),
				time = 7.5,
				color1 = "NEWBLUE",
				icon = ST[146849],
				ability = 8132,
				exhealer = true,
				exdps = true,
			},					
			-- Warning
			wHealingTotem = {
				varname = format("%s!",SN[146753]),
				type = "simple",
				text = format("%s!",SN[146753]),
				time = 2,
				color1 = "RED",
				sound = "ALERT14",
				icon = ST[146753],
			},	
			wWarbanner = {
				varname = format("%s!",SN[147328]),
				type = "simple",
				text = format("%s!",SN[147328]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[147328],
			},				
			wCrushersCall = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[146769]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[146769]),
				time = 2,
				color1 = "RED",
				icon = ST[146769],
				sound = "ALERT11",
				ability = 8132,
				exhealer = true,
			},
			wArcingSmash = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[147688]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[147688]),
				time = 2,
				color1 = "RED",
				icon = ST[147688],
				sound = "ALERT11",
				ability = 8132,
			},
			iLastPhase = {
				varname = format(L.alert["%s &bossname|boss1&"],L.alert["Incoming"]),
				type = "inform",
				text = format(L.alert["%s &bossname|boss1&"],L.alert["Incoming"]),
				time = 2,
				color1 = "ORANGE",
				sound = "ALERT10",
				icon = ST[137294],
			},	
			wSouthTower = {
				varname = format("%s!",L.chat_SiegeOfOrgrimmar["South Tower"]),
				type = "simple",
				text = format("%s!",L.chat_SiegeOfOrgrimmar["South Tower"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[147328],
			},
			wNorthTower = {
				varname = format("%s!",L.chat_SiegeOfOrgrimmar["North Tower"]),
				type = "simple",
				text = format("%s!",L.chat_SiegeOfOrgrimmar["North Tower"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[147328],
			},				
			-- Inform
			iFracture = {
				varname = format(L.alert["%s %s %s!"],SN[146899],L.alert["on"],L.alert["NPC"]),
				type = "inform",
				text = format(L.alert["%s %s #5#!"],SN[146899],L.alert["on"]),
				time = 2,
				color1 = "RED",
				icon = ST[146899],
				sound = "ALERT13",
				ability = 8132,
				flashscreen = true,
				exdps = true,
				--extank = true,
			},
			iFlameArrowsAway = {
				varname = format(L.alert["%s %s %s, %s!"],SN[146765],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s %s, %s!"],SN[146765],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[146765],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iPoisonCloud = {
				varname = format(L.alert["%s %s %s, %s!"],SN[147705],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s %s, %s!"],SN[147705],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "GREEN",
				icon = ST[147705],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},	
			--[[iArcingSmashself = {
				varname = format(L.alert["%s %s %s!"],SN[147688],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[147688],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[147688],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},--]]
			iFlamesofGalakrond = {
				varname = format(L.alert["%s %s %s, %s!"],SN[147068],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s %s, %s!"],SN[147068],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[147068],
				sound = "ALERT12",
				ability = 8132,
				flashscreen = true,
			},
			iFlamesOfGalakrondStackself = {
				varname = format(L.alert["%s: %s 3 %s!"],SN[147029],L.alert["already at"],L.alert["Stacks"]),
				type = "inform",
				text = format(L.alert["%s: %s #11# %s!"],SN[147029],L.alert["already at"],L.alert["Stacks"]),
				time = 2,
				color1 = "ORANGE",
				sound = "ALERT10",
				icon = ST[147029],
				ability = 8132,
				flashscreen = true,
				exdps = true,
				exhealer = true,				
			},	
			iFlamesOfGalakrondStackOther = {
				varname = format(L.alert["%s: %s 3 %s %s %s!"],SN[147029],L.alert["already at"],L.alert["Stacks"],L.alert["on"],L.alert["player"]),
				type = "inform",
				text = format(L.alert["%s: %s #11# %s %s #5#!"],SN[147029],L.alert["already at"],L.alert["Stacks"],L.alert["on"]),
				time = 2,
				color1 = "ORANGE",
				sound = "ALERT10",
				icon = ST[147029],
				ability = 8132,
				flashscreen = true,
				exdps = true,
				exhealer = true,
				throttle = 3,
			},				
			-- Casts
			--[[FlamesofGalakrondActive = {
				varname = format(L.alert["%s Active"],SN[147068]),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[147068]),
				text2 = format(L.alert["#5#: %s"],SN[147068]),
				time = 5,
				color1 = "RED",
				icon = ST[147068],
				ability = 7902,
				tag = "#5#",
			},--]]
			-- Debuffs
			FlamesOfGalakrondStackDebuff = {
				varname = format(L.alert["%s Debuff"],SN[147029]),
				type = "debuff",
				--text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[147029]),
				--text2 = format(L.alert["#5# (1): %s"],SN[147029]),
				text = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[147029]),
				text2 = format(L.alert["#5# (#11#): %s"],SN[147029]),
				time = 15,
				color1 = "ORANGE",
				ability = 8130,
				icon = ST[147029],
				tag = "#5#",
				exdps = true,
			},		
		},
		events = {
			-- Fracture
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146899},
				execute = {
					{
						"alert","iFracture",
					},
				},
			},
			-- HealingTotem
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {146753},
				execute = {
					{
						"alert","wHealingTotem",
					},
				},
			},
			-- Tidal Wave
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {148520, 149187, 148522},
				execute = {
					{
						"expect",{"&tabread|Shamanunit|#1#&","~=","true"},
						"tabinsert",{"Shamanunit","#1#","true"},					
						"set",{Shaman = "#1#"},
						"raidicon","ShamanMark",
					},
				},
			},
			-- ChainHeal
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {146757, 146728},
				execute = {
					{
						"expect",{"&tabread|Shamanunit|#1#&","~=","true"},
						"tabinsert",{"Shamanunit","#1#","true"},
						"set",{Shaman = "#1#"},
						"raidicon","ShamanMark",
					},
					{
						"message","mChainHeal",
					},
				},
			},				
			{
				type = "event",
				event = "UPDATE_MOUSEOVER_UNIT",
				execute = {
					{
						"expect",{"&bossid|mouseover&","==","69164"}, -- ShamanMark
						"set",{Shaman = "&bossid|mouseover|true&"},
						"expect",{"&tabread|Shamanunit|<Shaman>&","~=","true"},				
						"tabinsert",{"Shamanunit","<Shaman>","true"},
						"raidicon","ShamanMark",
					},				
				},
			},
			{
				type = "event",
				event = "UNIT_TARGET",
				execute = {
					{
						"expect",{"#1#","~=","0"},
						"invoke",{
							{
								"expect",{"&unittarget|#1#&","==","69164"},
								"set",{Shaman = "&unittarget|#1#|true&"},
								"debug",{"&unittarget|#1#&"},
								"expect",{"&tabread|Shamanunit|<Shaman>&","~=","true"},
								"tabinsert",{"Shamanunit","<Shaman>","true"},
								"raidicon","ShamanMark",
							},
						},
					},					
				},
			},	
			--[[{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","72367"}, -- Dragonmaw Tidal Shaman
						"removeraidicon","#5#",
					},		
				},
			},--]]
			-- FlameArrows
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_DAMAGE",
				spellid = {146765},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iFlameArrowsAway",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_MISSED",
				spellid = {146765},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iFlameArrowsAway",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146765},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iFlameArrowsAway",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {146764},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iFlameArrowsAway",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {146764},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iFlameArrowsAway",
					},
				},
			},	
			-- Warbanner
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {147328},
				execute = {
					{
						"alert","wWarbanner",
					},
				},
			},
			-- PoisonCloud
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_DAMAGE",
				spellid = {147705},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iPoisonCloud",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_MISSED",
				spellid = {147705},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iPoisonCloud",
					},
				},
			},		
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {147705},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iPoisonCloud",
					},
				},
			},
			-- CrushersCall
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {146769},
				execute = {
					{
						"batchalert",{"wCrushersCall","CrushersCallcd"},
					},
				},
			},	
			-- ShatteringCleave
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {146849},
				execute = {
					{
						"alert","ShatteringCleavecd",
						"message","mShatteringCleave",
					},
				},
			},
			-- ArcingSmash
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {147688},
				execute = {
					{
						"alert","wArcingSmash",
					},
				--[[	{
						"target",{
							source = "#1#",
							wait = 0.025,
							schedule = 12,
							--raidicon = "FoulStreammark",
							--arrow = "MortalBarragearrow",
							--arrowrange = 9,
							announce = "ArcingSmashsay",
							message = "mArcingSmash",
							alerts = {
								self = "iArcingSmashself",
							},
						},
					},--]]
				},
			},
			-- FlamesofGalakrond
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {147068},
				execute = {
					{
						"raidicon","FlamesofGalakrondMark",
						"message","mFlamesofGalakrond",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						--"batchalert",{"FlamesofGalakrondActive","iFlamesofGalakrond"},
						"alert","iFlamesofGalakrond",
						"announce","FlamesofGalakrondsay",
						"openwindow",{"8"},
					},
				--	{
				--		"expect",{"#4#","~=","&playerguid&"},
				--		"alert",{"FlamesofGalakrondActive", text = 2},
				--	},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {147068},
				execute = {
					{
						"closewindow",
						"removeraidicon","#5#",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {147029},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","FlamesOfGalakrondStackDebuff",
						"message","mFlamesOfGalakrondStack",
						"invoke",{
							{
								"expect",{"#11#",">","5"},
								"alert","iFlamesOfGalakrondStackself",
							},
						},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"expect",{"&istank& &istargettank|#5#&","==","true true"},
						"alert",{"FlamesOfGalakrondStackDebuff", text = 2},
						"message","mFlamesOfGalakrondStack",
						"invoke",{				
							{
								"expect",{"#11#",">","5"},
								"alert","iFlamesOfGalakrondStackOther",
							},
						},
					},
			--[[		{
						"expect",{"&istargettank|#5#&","==","true"},
						"invoke",{
							{
								"message","mFlamesOfGalakrondStack",
							},
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","FlamesOfGalakrondStackDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"FlamesOfGalakrondStackDebuff", text = 2},
							},					
							{
								"expect",{"#11#",">","2"},
								"invoke",{
									{
										"expect",{"#4#","==","&playerguid&"},
										"alert","iFlamesOfGalakrondStackself",
									},
									{
										"expect",{"#4#","~=","&playerguid&"},
										"alert","iFlamesOfGalakrondStackOther",
									},
								},
							},
						},
					},--]]
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {147029},
				execute = {
					{
						"quash","FlamesOfGalakrondStackDebuff",
					},
				},
			},	
			-----
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							{
								"expect",{"#5#","==","50630"}, -- Last Phase trigger (boss)
								"alert","iLastPhase",
							--	"tracing",{72249, 72311, 72302, 73910},
								"sortedtracing",{Galakras_list2},
								"unittracing",{"boss1","boss2","boss3","boss4"},
								"batchquash",{"Protocd","Addscd"},
								"alert",{"FlamesofGalakrondcd", time = 2},
							},
						},
					},
				},
			},
			-- Emotes
			{
				type = "event",
				event = "EMOTE", 
				execute = {
					-- south towers
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(The door barring the South Tower has been breached!)"]},
						"invoke",{
							{
								--"set",{DemoCount = "INCR|1"},
								--"message","mDemolisher",
								"batchalert",{"Demolishercd","wSouthTower","NorthTowercd"},								
							},
							{
								"expect",{"&heroic&","==","true"},
								"alert",{"TowerDefendercd", time = 3},
								"scheduletimer",{"timerAdds",35},	
							},
						},
					},
					-- North Towers
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(The door barring the North Tower has been breached!)"]},
						"invoke",{
							{
								--"set",{DemoCount = "INCR|1"},
								--"message","mDemolisher",
								"batchalert",{"Demolishercd","wNorthTower"},		
							},
						},
					},					
					{
						"expect",{"#1#","find","spell:116040"},
						--"set",{DemoCount = "INCR|1"},
						"message","mDemolisher",
					},
					-- 1st wave  Ally
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Here they come!)"]},
						"scheduletimer",{"timerForces",0.1},	
					},	
					-- 1st wave  Horde
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Bring her down quick so i can wrap my fingers around her neck.)"]},
						"scheduletimer",{"timerForces",0.1},	
					},
					-- 2st wave 
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Dragonmaw, advance!)"]},
						"scheduletimer",{"timerForces",0.1},	
					},
					-- 3st wave 
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(For Hellscream!)"]},
						"scheduletimer",{"timerForces",0.1},	
					},
					-- 4st wave 
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Next squad, push forward!)"]},
						"scheduletimer",{"timerForces",0.1},	
					},
				},
			},		
		},
	}

	DXE:RegisterEncounter(data)
end
