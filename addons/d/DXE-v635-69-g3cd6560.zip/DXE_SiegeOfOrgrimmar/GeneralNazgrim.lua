local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST
--TODO

do
	local data = {
		version = 4,
		key = "General Nazgrim",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["General Nazgrim"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-GENERAL NAZGRIM.BLP:35:35",
		triggers = {
			scan = {71515}, 
		},
		onactivate = {
			-- 71515, 71715, 71516, 71517, 71518, 71519
			tracing = {71515},
			tracerstart = true,
			combatstop = true,
			defeat = {71515},
			unittracing = {"boss1"},
			--unittracing = {"boss1","boss2","boss3","boss4","boss5"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
			timeflex = 600,
			timelfr = 600,
		},
		windows = {
			proxwindow = true,
			proxrange = 10,
		},
		raidicons = {
			BoneCrackermark = {
				varname = SN[143638],
				type = "MULTIFRIENDLY",
				persist = 30,
				unit = "#5#",
				icon = 2,
				total = 3,
				reset = 3,
				ability = 8130,
				icon2 = ST[143638],
			},
			AssasinsMark = {
				varname = SN[143480],
				type = "FRIENDLY",
				persist = 90,
				unit = "#5#",
				icon = 1,
				ability = 8130,
				icon2 = ST[143480],
			},
			Addsmark = {
				varname = L.alert["Adds"],
				type = "MULTIENEMY",
				persist = 30,
				unit = "<MarkAdds>",
				icon = 5,
				total = 4,
				reset = 5,
				ability = 8130,
				icon2 = ST[143638],
			},
		},
		arrows = {
			HeroicShockwavearrow = {
				varname = SN[143500],
				unit = "&upvalue&",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[143500],
				range1 = 10,
				range2 = 12,
				range3 = 14,
				ability = 8132,
				icon = ST[143500],
			},
			Ravagerarrow = {
				varname = SN[143872],
				unit = "#5#",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[143872],
				range1 = 6,
				range2 = 8,
				range3 = 10,
				ability = 8132,
				icon = ST[143872],
			},			
		},
		timers = {
			timerBoneCracker = {
				{
					"message","mBoneCracker",
				},
			},
		},		
		userdata = {
			Boneunists = {type = "container", wipein = 3},
			ForcesCount = 0,
			MarkAdds = "",
			MarkAddsunit = {type = "container"},
		},
		onstart = {
			{
				"alert","Addscd",
				"alert",{"Sundercd", time = 2},
				"alert",{"Bonecd", time = 2},
			},
		},
		announces = { 
			HeroicShockwavesay = {
				varname = format(L.alert["%s %s %s!"],SN[143500],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143500],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143500],
			},
			Ravagersay = {
				varname = format(L.alert["%s %s %s!"],SN[143872],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143872],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143872],
			},	
			Fixatedsay = {
				varname = format(L.alert["%s %s %s!"],SN[143480],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143480],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143480],
			},
			HuntersMarksay = {
				varname = format(L.alert["%s %s %s!"],SN[143882],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143882],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143882],
			},				
		},
		messages = {
			mFixated = {
				varname = format(L.alert["%s %s %s"],SN[143480],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[143480],L.alert["on"]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143480],
			},
			mHuntersMark = {
				varname = format(L.alert["%s %s %s"],SN[143882],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[143882],L.alert["on"]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143882],
			},					
			mRavager = {
				varname = format(L.alert["%s %s %s"],SN[143872],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[143872],L.alert["on"]),
				color1 = "BROWN",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143872],
			},
			mEarthShield = {
				varname = format(L.alert["%s!"],SN[143475]),
				type = "message",
				text = format(L.alert["%s!"],SN[143475]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143475],
			},			
			mBanner = {
				varname = format(L.alert["%s!"],SN[143536]),
				type = "message",
				text = format(L.alert["%s!"],SN[143536]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143536],
			},
			mBattleStance = {
				varname = format(L.alert["%s!"],SN[143589]),
				type = "message",
				text = format(L.alert["%s!"],SN[143589]),
				color1 = "PEACH",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143589],
			},
			mBerserkerStance = {
				varname = format(L.alert["%s!"],SN[143594]),
				type = "message",
				text = format(L.alert["%s!"],SN[143594]),
				color1 = "PEACH",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143594],
			},
			mDefensiveStance = {
				varname = format(L.alert["%s!"],SN[143593]),
				type = "message",
				text = format(L.alert["%s!"],SN[143593]),
				color1 = "PEACH",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143593],
			},
			mHeroicShockwave = {
				varname = format(L.alert["%s %s %s"],SN[143500],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[143500],L.alert["on"]),
				text2 = format(L.alert["%s!"],SN[143500]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143500],
			},
			mBoneCracker = {
				varname = format(L.alert["%s %s %s"],SN[143638],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|Boneunists&"],SN[143638],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143638],
			},
			--[[mWarSong = {
				varname = format(L.alert["%s %s"],SN[143503],L.alert["Incoming"]),
				type = "message",
				text = format(L.alert["%s %s"],SN[143503],L.alert["Incoming"]),
				color1 = "NEWBLUE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143503],
				exhealer = true,
			},--]]
			mBoneCracker = {
				varname = format(L.alert["%s %s"],SN[143638],L.alert["Incoming"]),
				type = "message",
				text = format(L.alert["%s %s"],SN[143638],L.alert["Incoming"]),
				time = 2,
				color1 = "DCYAN",
				icon = ST[143638],
				sound = "ALERT13",
				ability = 8132,
				--exdps = true,
			},
			mCoolingOff = {
				varname = format(L.alert["%s!"],SN[143484]),
				type = "message",
				text = format(L.alert["%s!"],SN[143484]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143484],
			},
			
			--[[mEmpoweredChainHeal = {
				varname = format(L.alert["%s!"],SN[143473]),
				type = "message",
				text = format(L.alert["%s!"],SN[143473]),
				color1 = "GREEN",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143473],
			},--]]
		},
		alerts = {
			Executecd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[143502]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143502]),
				time = 18,
				color1 = "BROWN",
				icon = ST[143502],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},		
			Sundercd = {
				varname = format(L.alert["%s Cooldown"],SN[143494]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143494]),
				time = 30,
				time2 = 10,
				color1 = "BROWN",
				icon = ST[143494],
				ability = 8132,
				exdps = true,
			},
			Bonecd = {
				varname = format(L.alert["%s Cooldown"],SN[143638]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143638]),
				time = 30,
				time2 = 15.5,
				color1 = "NEWBLUE",
				icon = ST[143638],
				ability = 8132,
			},
			Addscd = {
				varname = format(L.alert["%s Cooldown"],SN["ej7920"]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN["ej7920"]),
				time = 45,
				color1 = "NEWBLUE",
				icon = ST[7920],
				ability = 7920,
				counter = true,
			},	
			BattleStancecd = {
				varname = format(L.alert["%s Cooldown"],SN[143589]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143589]),
				time = 60,
				color1 = "NEWBLUE",
				icon = ST[143589],
				ability = 8132,
			},
			BerserkerStancecd = {
				varname = format(L.alert["%s Cooldown"],SN[143594]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143594]),
				time = 60,
				color1 = "NEWBLUE",
				icon = ST[143594],
				ability = 8132,
			},
			DefensiveStancecd = {
				varname = format(L.alert["%s Cooldown"],SN[143593]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143593]),
				time = 60,
				color1 = "NEWBLUE",
				icon = ST[143593],
				ability = 8132,
			},	
			--[[EmpoweredChainHealcd = {
				varname = format(L.alert["%s Cooldown"],SN[143473]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143473]),
				time = 6,
				color1 = "NEWBLUE",
				icon = ST[143473],
				ability = 8132,
			},	--]]
			-- Alert
			wAdds = {
				varname = format(L.alert["%s %s!"],L.alert["Incoming"],SN["ej7920"]),
				type = "simple",
				text = format(L.alert["%s %s!"],L.alert["Incoming"],SN["ej7920"]),
				time = 2,
				color1 = "RED",
				icon = EJST[7920],
				sound = "ALERT11",
				ability = 7920,
				counter = true,
				--exdps = true,
			},
			wWarSong = {
				varname = format(L.alert["%s %s"],L.alert["Incoming"],SN[143503]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[143503]),
				time = 2,
				color1 = "RED",
				icon = ST[143503],
				sound = "ALERT11",
				ability = 8132,
			},
			wHealingTideTotem = {
				varname = format(L.alert["%s"],SN[143474]),
				type = "simple",
				text = format(L.alert["%s"],SN[143474]),
				time = 2,
				color1 = "RED",
				icon = ST[143474],
				sound = "ALERT14",
				ability = 8132,
			},
			wExecute = {
				varname = "(H) "..format(L.alert["%s %s"],L.alert["Incoming"],SN[143502]),
				type = "simple",
				text = format(L.alert["%s %s"],L.alert["Incoming"],SN[143502]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[143502],
				sound = "ALERT11",
				ability = 8132,
				exdps = true,
				exhealer = true,
			},			
			-- Inform
			iEarthShield = {
				varname = format("%s %s!",SN[143475],L.alert["Dispell"]),
				type = "inform",
				text = format("%s %s!",SN[143475],L.alert["Dispell"]),
				time = 2,
				color1 = "ORANGE",
				sound = "ALERT13",
				icon = ST[143475],
			},
			iHeroicShockwaveself = {
				varname = format(L.alert["%s %s %s!"],SN[143500],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143500],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143500],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iRavagerself = {
				varname = format(L.alert["%s %s %s!"],SN[143872],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143872],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "BROWN",
				icon = ST[143872],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iRavager = {
				varname = format("%s %s %s!",SN[143872],L.alert["Near"],L.alert["YOU"]),
				type = "inform",
				text = format("%s %s %s!",SN[143872],L.alert["Near"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				flashscreen = true,
				sound = "ALERT12",
				icon = ST[143872],
			},
			iBoneCracker = {
				varname = format("%s %s %s!",SN[143638],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format("%s %s %s!",SN[143638],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "INDIGO",
				flashscreen = true,
				sound = "ALERT11",
				icon = ST[143638],
			},
			iSunderingBlow = {
				varname = format("%s!",SN[143494]),
				type = "inform",
				text = format("%s!",SN[143494]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT13",
				icon = ST[143494],
			},
			iSunderingBlowwarn = {
				varname = format("%s %s 2!",SN[143494],L.alert["already at"]),
				type = "inform",
				text = format("%s %s #11#!",SN[143494],L.alert["already at"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[143494],
			},
			iFixated = {
				varname = format("%s %s %s!",SN[143480],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format("%s %s %s!",SN[143480],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				flashscreen = true,
				sound = "ALERT11",
				icon = ST[143480],
			},
			iHuntersMark = {
				varname = format(L.alert["%s %s %s!"],SN[143882],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143882],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143882],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},			
			-- Casts
			WarSongcast = {
				varname = format(L.alert["%s Active"],SN[143503]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[143503]),
				time = 2.95,
				color1 = "RED",
				icon = ST[143503],
				ability = 8132,
				--exdps = true,
			},
			CoolingOffCast = {
				varname = format(L.alert["%s Active"],SN[143484]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[143484]),
				time = 15,
				color1 = "RED",
				ability = 8130,
				icon = ST[143484],
				audiocd = true,
				audiotime = 5,
			},
			-- Debuff
			SunderDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143494]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143494]),
				text2 = format(L.alert["#5#: %s"],SN[143494]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[143494],
				tag = "#5#",
				exdps = true,
			},
			BoneCrackerDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143638]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143638]),
				text2 = format(L.alert["#5#: %s"],SN[143638]),
				time = 30,
				color1 = "DCYAN",
				ability = 8130,
				icon = ST[143638],
				tag = "#5#",
				exdps = true,
			},
			SunderingBlowDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143494]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143494]),
				text2 = format(L.alert["#5# (1): %s"],SN[143494]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143494]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143494]),
				time = 60,
				color1 = "BROWN",
				ability = 8130,
				icon = ST[143494],
				tag = "#5#",
				exdps = true,
			},					
		},
		events = {
			{
				type = "event",
				event = "UPDATE_MOUSEOVER_UNIT",
				execute = {
					{
						"expect",{"&bossid|mouseover&","==","71519"}, -- Shaman
						"set",{MarkAdds = "&bossid|mouseover|true&"},
						"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
						"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
						"raidicon","Addsmark",
					},
					{
						"expect",{"&bossid|mouseover&","==","71517"}, -- Arcweaver
						"set",{MarkAdds = "&bossid|mouseover|true&"},
						"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
						"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
						"raidicon","Addsmark",
					},
					{
						"expect",{"&bossid|mouseover&","==","71518"}, -- Assassin
						"set",{MarkAdds = "&bossid|mouseover|true&"},
						"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
						"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
						"raidicon","Addsmark",
					},
					{
						"expect",{"&bossid|mouseover&","==","71516"}, -- Iron Blade
						"set",{MarkAdds = "&bossid|mouseover|true&"},
						"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
						"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
						"raidicon","Addsmark",
					},
					{
						"expect",{"&bossid|mouseover&","==","71656"}, -- Sniper (Heroic)
						"set",{MarkAdds = "&bossid|mouseover|true&"},
						"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
						"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
						"raidicon","Addsmark",
					},
				},
			},
			{
				type = "event",
				event = "UNIT_TARGET",
				execute = {
					{
						"expect",{"#1#","~=","0"},
						"invoke",{
							{
								"expect",{"&unittarget|#1#&","==","71519"}, -- Shaman
								"set",{MarkAdds = "&unittarget|#1#|true&"},
								"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
								"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
								"raidicon","Addsmark",
							},
							{
								"expect",{"&unittarget|#1#&","==","71517"}, -- Arcweaver
								"set",{MarkAdds = "&unittarget|#1#|true&"},
								"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
								"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
								"raidicon","Addsmark",
							},
							{
								"expect",{"&unittarget|#1#&","==","71518"}, -- Assassin
								"set",{MarkAdds = "&unittarget|#1#|true&"},
								"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
								"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
								"raidicon","Addsmark",
							},
							{
								"expect",{"&unittarget|#1#&","==","71516"}, -- Iron Blade
								"set",{MarkAdds = "&unittarget|#1#|true&"},
								"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
								"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
								"raidicon","Addsmark",
							},
							{
								"expect",{"&unittarget|#1#&","==","71656"}, -- Sniper (Heroic)
								"set",{MarkAdds = "&unittarget|#1#|true&"},
								"expect",{"&tabread|MarkAddsunit|<MarkAdds>&","~=","true"},
								"tabinsert",{"MarkAddsunit","<MarkAdds>","true"},
								"raidicon","Addsmark",
							},									
						},
					},					
				},
			},
			-- HealingTideTotem
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143474},
				execute = {
					{
						"alert","wHealingTideTotem",
					},
				}
			},	
			-- EarthShield
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143475},
				execute = {
					{
						"message","mEarthShield",
					},
					{
						"expect",{"&ismagicdispeller&","==","true"},
						"alert","iEarthShield",
					},
				}
			},
			-- Fixate AssasinsMark
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143480},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iFixated",
						"announce","Fixatedsay",
					},				
					{
						"message","mFixated",
						"raidicon","AssasinsMark",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143480},
				execute = {
					{
						"removeraidicon","#5#",
					},
				},
			},
			-- HuntersMark
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143882},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iHuntersMark",
						"announce","HuntersMarksay",
					},				
					{
						"message","mHuntersMark",
					},
				},
			},					
			-- SunderingBlow
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143494},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"batchalert",{"iSunderingBlow","SunderingBlowDebuff"},
					},				
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"SunderingBlowDebuff", text = 2},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143494},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert",{"SunderingBlowDebuff", text = 3},
						"invoke",{
							{
								"expect",{"#11#",">","4"},
								"alert","iSunderingBlowwarn",
							},
						},
					},				
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"SunderingBlowDebuff", text = 4},
					},
				},
			},		
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143494},
				execute = {
					{
						"alert","Sundercd",
					},
				}
			},			
			-- BoneCracker
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143638},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"batchalert",{"iBoneCracker","BoneCrackerDebuff"},
					},
					{
						"raidicon","BoneCrackermark",
						"insert",{"Boneunists","#5#"},
						--"tabinsert",{"Boneunists","#5#","true"},
						"canceltimer","timerBoneCracker",
						"scheduletimer",{"timerBoneCracker",1.5},
					},					
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"BoneCrackerDebuff", text = 2},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143638},
				execute = {
					{
						"removeraidicon","#5#",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143638},
				execute = {
					{
						"message","mBoneCracker",
						--"alert","wBoneCracker",
					},
				},
			},	
			-- Cooling Off
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143484},
				execute = {
					{
						"alert","CoolingOffCast",
						"message","mCoolingOff",
					},
				},
			},
			-- BattleStance
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143589},
				execute = {
					{
						"message","mBattleStance",
						"alert","BerserkerStancecd",
					},
				}
			},
			-- BerserkerStance
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143594},
				execute = {
					{
						"message","mBerserkerStance",
						"alert","DefensiveStancecd",
					},
				}
			},
			-- DefensiveStance
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143593},
				execute = {
					{
						"message","mDefensiveStance",
						"alert","BerserkerStancecd",
					},
				}
			},		
			--WarSong
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143503},
				execute = {
					{
						--"message","mWarSong",
						"batchalert",{"WarSongcast","wWarSong"},
					},
				},
			},	
			-- Execute
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143502},
				execute = {
					{
						--"message","mWarSong",
						"batchalert",{"Executecd","wExecute"},
					},
				},
			},				
			-- Ravager
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143872},
				execute = {
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iRavagerself",
						"announce","Ravagersay",
					},
					{
						"expect",{"&inrange|#5#&","<","8"},
						"arrow","Ravagerarrow",
						"alert","iRavager",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"message","mRavager",
					},
				},
			},
			-- Banner
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143536},
				execute = {
					{
						"message","mBanner",
					},
				},
			},
			--EmpoweredChainHeal
			--[[{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {143473},
				execute = {
					{
						"message","mEmpoweredChainHeal",
						"alert","EmpoweredChainHealcd",
					},
				},
			},	--]]
			{
				type = "event",
				event = "YELL", 
				execute = {
					-- New Forces 1
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Defend the gate!)"]},
						"set",{ForcesCount = "INCR|1"},
						"batchalert",{"Addscd","wAdds"},
					},
					-- New Forces 2
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Rally the forces!)"]},
						"set",{ForcesCount = "INCR|1"},
						"batchalert",{"Addscd","wAdds"},
					},
					-- New Forces 3
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Next squad, to the front!)"]},
						"set",{ForcesCount = "INCR|1"},
						"batchalert",{"Addscd","wAdds"},
					},
					-- New Forces 4
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Warriors, on the double!)"]},
						"set",{ForcesCount = "INCR|1"},
						"batchalert",{"Addscd","wAdds"},
					},
					-- New Forces 5
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(Kor'kron, at my side!)"]},
						"set",{ForcesCount = "INCR|1"},
						"batchalert",{"Addscd","wAdds"},
					},	
					-- All Forces
					{
						"expect",{"#1#","find",L.chat_SiegeOfOrgrimmar["(All Kor'kron... under my command... kill them... NOW!)"]},
						"alert","wAdds",
					},						
				},
			},			
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							{
								"expect",{"#5#","==","143500"}, -- Heroic Shockwave
								"target",{
									source = "#1#",
									wait = 0.05,
									schedule = 16,
									--raidicon = "FoulStreammark",
									arrow = "HeroicShockwavearrow",
									arrowdef = "<",
									arrowrange = 16,
									announce = "HeroicShockwavesay",
									message = "mHeroicShockwave",
									alerts = {
										self = "iHeroicShockwaveself",
										--other = 
										--unknown = "",
										unknownmsg = {"mHeroicShockwave", text = 2},
									},
								},
							},
						},
					},
				},
			},
		},
	}

	DXE:RegisterEncounter(data)
end
