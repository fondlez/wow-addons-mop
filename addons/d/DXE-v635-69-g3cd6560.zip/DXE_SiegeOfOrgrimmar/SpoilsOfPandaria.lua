local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 1,
		key = "Spoils Of Pandaria",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Spoils Of Pandaria"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-SPOLIS OF PANDARIA.BLP:35:35",
		triggers = {
			scan = {73152, 73720, 71512}, 
		},
		onactivate = {
			tracing = {
				--73720, 71512,
				"boss1","boss2",
				--powers={true,true},
				alternate={true,true},
				alternatepower={true,true},
			},
			tracerstart = true,
			combatstop = true,
			defeat = L.chat_SiegeOfOrgrimmar["(System resetting. Don't turn the power off, or the whole thing will probably explode.)"],
			unittracing = {"boss1","boss2"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
		},
		windows = {
			proxwindow = true,
			proxrange = 3,
		},
		timers = {
			listSetToBlow = {
				{
					"message","mSetToBlow",
				},
			},
		},
		userdata = {
			SetToBlow = 0,
			SetToBlowunits = {type = "container", wipein = 3},
			SetToBlowunits2 = {type = "container"},
			--phase = "0",
		},
		onstart = {
			{

			},
		},
		messages = {
			mSetToBlow = {
				varname = format(L.alert["%s %s %s"],SN[145987],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|SetToBlowunits&"],SN[145987],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[145987],
			},
		},
		alerts = {
			-- Inform
			iPathOfBlossoms = {
				varname = format(L.alert["%s %s, %s!"],SN[146257],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[146257],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[146257],
				sound = "ALERT10",
				ability = 8132,
				throttle = 2,
			},
			iBlazingCharge = {
				varname = format(L.alert["%s %s, %s!"],SN[145715],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[145715],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "PURPLE",
				icon = ST[145715],
				sound = "ALERT10",
				ability = 8132,
				throttle = 2,
			},
			iBubblingAmber = {
				varname = format(L.alert["%s %s, %s!"],SN[145748],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[145748],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[145748],
				sound = "ALERT10",
				ability = 8132,
				throttle = 2,
			},	
			iSetToBlow = {
				varname = format(L.alert["%s %s %s!"],SN[145987],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[145987],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[145987],
				ability = 7888,
				sound = "ALERT10",
				flashscreen = true,
			},				
			-- Cast
			SetToBlowActive = {
				varname = format(L.alert["%s Active"],SN[145987]),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[145987]),
				time = 30,
				color1 = "BLUE",
				icon = ST[145987],
				ability = 7997,
				tag = "#5#",
				audiocd = true,
				audiotime = 10,	
			},			
			-- Debuffs
			SetToBlowDebuff = {
				varname = format(L.alert["%s Debuff"],SN[145987]),
				type = "debuff",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[145987]),
				text2 = format(L.alert["#5#: %s"],SN[145987]),
				time = 30,
				color1 = "INDIGO",
				icon = ST[145987],
				ability = 7994,
				tag = "#5#",
			},
		},
		events = {
			-- PathOfBlossoms
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {146257},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iPathOfBlossoms",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {146257},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iPathOfBlossoms",
					},
				},
			},	
			-- BlazingCharge
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {145715},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBlazingCharge",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {145715},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBlazingCharge",
					},
				},
			},	
			-- BubblingAmber
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145748},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBubblingAmber",
					},
				},
			},			
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {145748},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBubblingAmber",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {145748},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBubblingAmber",
					},
				},
			},
			-- SetToBlow
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145987},
				execute = {
					{
						"insert",{"SetToBlowunits","#5#"},
						"canceltimer","listSetToBlow",
						"scheduletimer",{"listSetToBlow",1.2},	
						"set",{SetToBlow = "INCR|1"},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"openwindow",{"10"},
						"batchalert",{"iSetToBlow","SetToBlowActive","SetToBlowDebuff"},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"set",{SetToBlowunists2 = "&RaidDebuff|"..SN[145987].."&"},
						"openwindow",{"12","<SetToBlowunists2>"},
						"alert",{"SetToBlowDebuff", text = 2},
					},	
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {145987},
				execute = {
					{
						"quash","SetToBlowDebuff",
						"set",{SetToBlow = "DECR|1"},
					},			
					{
						"expect",{"#4#","==","&playerguid&"},
						"quash","SetToBlowActive",
					},
					{
						"expect",{"<SetToBlow>",">","0"},
						"set",{SetToBlowunists2 = "&RaidDebuff|"..SN[145987].."&"},
						"openwindow",{"12","<SetToBlowunists2>"},
						"alert",{"SetToBlowDebuff", text = 2},
					},
					{
						"expect",{"<SetToBlow>","==","0"},
						"closewindow",
					},					
				},
			},		
		},
	}

	DXE:RegisterEncounter(data)
end
