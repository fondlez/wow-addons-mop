local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST
-- TODO
do
	local data = {
		version = 3,
		key = "Iron Juggernaut",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Iron Juggernaut"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-IRON JUGGERNAUT.BLP:35:35",
		triggers = {
			scan = {71466}, 
		},
		onactivate = {
			tracing = {71466},
			tracerstart = true,
			combatstop = true,
			defeat = {71466},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 450,
			time25h = 450,
			timeflex = 600,
			timelfr = 600,
		},
		arrows = {
			--[[MortalBarragearrow = {
				varname = SN[144553],
				unit = "&upvalue&",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[144553],
				range1 = 9,
				range2 = 11,
				range3 = 12,
				ability = 8132,
				icon = ST[144553],
			},--]]
			CutterLaserarrow = {
				varname = SN[146325],
				unit = "#5#",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[146325],
				range1 = 8,
				range2 = 10,
				range3 = 12,
				ability = 8132,
				icon = ST[146325],
			},
		},
		windows = {
			proxwindow = true,
			--proxrange = 6,
		},
		userdata = {
			siegeMode = 0,
			shockcount = 0,
			CrawlerMine = "",
			CrawlerMineunit = {type = "container"},
			LaserBurnunists = {type = "container", wipein = 3},
		},
		timers = {
			timerLaserBurn = {
				{
					"message","mLaserBurn",
				},
			},
		},
		raidicons = {
			AddMark = {
				varname = L.npc_SiegeOfOrgrimmar["Crawler Mine"],
				type = "MULTIENEMY",
				persist = 15,
				unit = "<CrawlerMine>",
				--id = 72050,
				reset = 3,
				icon = 1,
				total = 3,
			},
			CutterLasermark = {
				varname = SN[146325],
				type = "FRIENDLY",
				persist = 25,
				unit = "#5#",
				icon = 8,
				ability = 8130,
				icon2 = ST[146325],
			},
		},
		onstart = {
			{
				"alert",{"SiegeModecd", time = 2},
				"alert",{"IgniteArmorcd", time = 2},
				"batchalert",{"LaserBurncd","BorerDrillcd","CrawlerMinecd"},
			},
			{
				"expect",{"&heroic&","==","true"},
				"alert",{"Ricochetcd", time = 2},
			},
			{
				"expect",{"&lfr&","==","false"},
				"openwindow",{"6"},
			},
		},
		announces = { 
			--[[MortalBarragesay = {
				varname = format(L.alert["%s %s %s!"],SN[144553],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[144553],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[144553],
			},--]]
			CutterLasersay = {
				varname = format(L.alert["%s %s %s!"],SN[146325],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[146325],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[146325],
			},				
		},
		messages = {
			--[[mMortalBarrage = {
				varname = format(L.alert["%s %s %s"],SN[144553],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &upvalue&"],SN[144553],L.alert["on"]),
				color1 = "INDIGO",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[144553],
			},--]]
			mLaserBurn = {
				varname = format(L.alert["%s %s %s"],SN[144459],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|LaserBurnunists&"],SN[144459],L.alert["on"]),
				color1 = "BROWN",
				icon = ST[144459],
				sound = "ALERT13",
			},
			mSeismic = {
				varname = format(L.alert["%s!"],SN[144483]),
				type = "message",
				text = format(L.alert["%s!"],SN[144483]),
				color1 = "PEACH",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144483],
			},
			mCrawlerMine = {
				varname = format(L.alert["%s!"],SN[146342]),
				type = "message",
				text = format(L.alert["%s!"],SN[146342]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[146342],
			},
			mDemolisherCanons = {
				varname = format(L.alert["%s!"],SN[144154]),
				type = "message",
				text = format(L.alert["%s!"],SN[144154]),
				color1 = "GOLD",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144154],
			},
			mIgniteArmor = {
				varname = format(L.alert["%s %s %s (1)"],SN[144467],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[144467],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[144467],L.alert["on"]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144467],
			},
			mCutterLaser = {
				varname = format(L.alert["%s %s %s"],SN[146325],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[146325],L.alert["on"]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[146325],
			},	
			mBorerDrill = {
				varname = format(L.alert["%s"],SN[144209]),
				type = "message",
				text = format(L.alert["%s"],SN[144209]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144209],
			},			
			mNapalmOil = {
				varname = format(L.alert["%s"],SN[144492]),
				type = "message",
				text = format(L.alert["%s"],SN[144492]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[144492],
			},	
		},
		alerts = {
			-- Cooldowns
			ShockPulsecd = {
				varname = format(L.alert["%s Cooldown"],SN[144485]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144485]),
				time = 16.5,
				color1 = "NEWBLUE",
				icon = ST[144485],
				ability = 8132,
			},			
			AssaultModecd = {
				varname = format(L.alert["%s Cooldown"],SN[141395]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[141395]),
				time = 62,
				color1 = "NEWBLUE",
				icon = ST[141395],
				ability = 8132,
			},
			IgniteArmorcd = {
				varname = format(L.alert["%s Cooldown"],SN[144467]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144467]),
				time = 10,
				time2 = 9,
				color1 = "NEWBLUE",
				icon = ST[144467],
				ability = 8132,
				exhealer = true,
				exdps = true,
			},
			LaserBurncd = {
				varname = format(L.alert["%s Cooldown"],SN[144459]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144459]),
				time = 11.5,
				color1 = "NEWBLUE",
				icon = ST[144459],
				ability = 8132,
				extank = true,
				exdps = true,
			},
			BorerDrillcd = {
				varname = format(L.alert["%s Cooldown"],SN[144218]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144218]),
				time = 17,
				color1 = "NEWBLUE",
				icon = ST[144218],
				ability = 8132,
			},
			CrawlerMinecd = {
				varname = format(L.alert["%s Cooldown"],SN[144673]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144673]),
				time = 30,
				time2 = 25,
				time3 = 18,
				color1 = "NEWBLUE",
				icon = ST[144673],
				ability = 8132,
			},
			------------------
			SiegeModecd = {
				varname = format(L.alert["%s Cooldown"],SN[84974]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[84974]),
				time = 114,
				time2 = 120.5,
				color1 = "NEWBLUE",
				icon = ST[84974],
				ability = 8132,
			},
			DemolisherCanoncd = {
				varname = format(L.alert["%s Cooldown"],SN[144154]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144154]),
				time = 8.5,
				color1 = "NEWBLUE",
				icon = ST[144154],
				ability = 8132,
			},
			MortarBarragecd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[144554]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144554]),
				time = 30,
				time2 = 20,
				color1 = "NEWBLUE",
				icon = ST[144554],
				ability = 8132,
			},
			Ricochetcd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[144356]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144356]),
				time = 15,
				color1 = "NEWBLUE",
				icon = ST[144356],
				ability = 8132,
			},			
			NapalmOilcd = {
				varname = format(L.alert["%s Cooldown"],SN[144492]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[144492]),
				time = 30,
				time2 = 10,
				time3 = 7,
				color1 = "NEWBLUE",
				icon = ST[144492],
				ability = 8132,
			},					
			-- Alert
			--[[wBorerDrill = {
				varname = format(L.alert["%s %s!"],SN[144209],L.alert["Incoming"]),
				type = "simple",
				text = format(L.alert["%s %s!"],SN[144209],L.alert["Incoming"]),
				time = 2,
				color1 = "RED",
				icon = ST[144209],
				sound = "ALERT11",
				ability = 8132,
			},--]]
			wShockPulse = {
				varname = format(L.alert["%s %s!"],SN[144485],L.alert["Incoming"]),
				type = "simple",
				text = format(L.alert["%s %s!"],SN[144485],L.alert["Incoming"]),
				time = 2,
				color1 = "RED",
				icon = ST[144485],
				sound = "ALERT11",
				ability = 8132,
			},
			wMortarBarrage = {
				varname = "(H) "..format(L.alert["%s!"],SN[144554]),
				type = "simple",
				text = format(L.alert["%s!"],SN[144554]),
				time = 2,
				color1 = "RED",
				icon = ST[144554],
				sound = "ALERT10",
				ability = 8132,
			},			
			wMortarCannon = {
				varname = format(L.alert["%s!"],SN[144316]),
				type = "simple",
				text = format(L.alert["%s!"],SN[144316]),
				time = 2,
				color1 = "RED",
				icon = ST[144316],
				sound = "ALERT11",
				ability = 8132,
			},			
			-- Inform
			iMortalBarrageself = {
				varname = format(L.alert["%s %s %s!"],SN[144553],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[144553],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[144553],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},
			iBorerDrill = {
				varname = format(L.alert["%s %s, %s!"],SN[144218],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[144218],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144218],
				sound = "ALERT12",
				ability = 7985,
				throttle = 2,
				flashscreen = true,
			},
			iExplosiveTar = {
				varname = format(L.alert["%s %s, %s!"],SN[144498],L.alert["under you"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s, %s!"],SN[144498],L.alert["under you"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[144498],
				sound = "ALERT12",
				ability = 7985,
				throttle = 2,
				flashscreen = true,
			},			
			-- Cast
			CutterLaserCast = {
				varname = format(L.alert["%s: %s"],L.alert["player"],format(L.alert["%s Active"],SN[146325])),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],format(L.alert["%s Active"],SN[146325])),
				text2 = format(L.alert["#5#: %s"],format(L.alert["%s Active"],SN[146325])),
				time = 15,
				color1 = "RED",
				ability = 8130,
				icon = ST[146325],
				tag = "#5#",
			},
			ShockPulseCast = {
				varname = format(L.alert["%s Active"],SN[144485]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[144485]),
				time = 4,
				color1 = "RED",
				ability = 8130,
				icon = ST[144485],
				tag = "#5#",
			},				
			-- Debuff
			IgniteArmorDebuff = {
				varname = format(L.alert["%s Debuff"],SN[144467]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[144467]),
				text2 = format(L.alert["#5# (1): %s"],SN[144467]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[144467]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[144467]),
				time = 30,
				color1 = "ORANGE",
				ability = 8130,
				icon = ST[143494],
				tag = "#5#",
				exdps = true,
			},
			CuttingLaserDebuff = {
				varname = format(L.alert["%s Debuff"],SN[146325]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[146325]),
				text2 = format(L.alert["#5# (1): %s"],SN[146325]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[146325]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[146325]),
				time = 10,
				color1 = "ORANGE",
				ability = 8130,
				icon = ST[146325],
				tag = "#5#",
				exdps = true,
			},
		},
		events = {	
			--MortalBarrage
			--[[{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144553},
				execute = {
					--{
						--"alert","wFoulStream",
						--"openwindow",{"8"},
					--},
					{
						"target",{
							source = "#1#",
							wait = 0.25,
							schedule = 16,
							--raidicon = "FoulStreammark",
							arrow = "MortalBarragearrow",
							arrowrange = 9,
							announce = "MortalBarragesay",
							message = "mMortalBarrage",
							alerts = {
								self = "iMortalBarrageself",
								--other = 
								--unknown = "",
							},
						},
					},
				},
			},--]]
			-- BorerDrill
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_DAMAGE",
				spellid = {144218},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBorerDrill",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_MISSED",
				spellid = {144218},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBorerDrill",
					},
				},
			},
			--[[{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144209},
				execute = {
					{
						"alert","wBorerDrill",
					},
				},
			},	--]]
			-- ExplosiveTar
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144498},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iExplosiveTar",
					},
				},
			},
			-- LaserBurn
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144459},
				execute = {
					{
						"insert",{"LaserBurnunists","#5#"},
						"canceltimer","timerLaserBurn",
						"scheduletimer",{"timerLaserBurn",0.5},
						"alert","LaserBurncd",
					},
				},
			},		
			-- Detonation Sequence
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {144718},
				execute = {
					{
						"set",{CrawlerMine = "#1#"},
						"expect",{"&tabread|CrawlerMineunit|<CrawlerMine>&","~=","true"},
						"tabinsert",{"CrawlerMineunit","<CrawlerMine>","true"},
						"raidicon","AddMark",
					},
				},
			},
			{
				type = "event",
				event = "UPDATE_MOUSEOVER_UNIT",
				execute = {
					{
						"expect",{"&bossid|mouseover&","==","72050"}, -- Crawler Mine
						"set",{CrawlerMine = "&bossid|mouseover|true&"},
						"expect",{"&tabread|CrawlerMineunit|<CrawlerMine>&","~=","true"},
						"tabinsert",{"CrawlerMineunit","<CrawlerMine>","true"},
						"raidicon","AddMark",
					},				
				},
			},		
			-- CutterLaser
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146325},
				execute = {
					{
						"message","mCutterLaser",
						"raidicon","CutterLasermark",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","CutterLaserCast",
						"announce","CutterLasersay",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"CutterLaserCast", text = 2},
						"invoke",{
							{
								"expect",{"&inrange|#5#&","<","9"},
								"arrow","CutterLaserarrow",
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {146325},
				execute = {
					{
						"quash","CutterLaserCast",
						"removeraidicon","#5#",
						"removearrow","#5#",
					},
				},
			},
			-- IgniteArmor
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {144467},
				execute = {
					{
						"expect",{"&istargettank|#5#&","==","true"},
						"invoke",{
							{
								"message","mIgniteArmor",
							},
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","IgniteArmorDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"IgniteArmorDebuff", text = 2},
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {144467},
				execute = {
					{
						"expect",{"&istargettank|#5#&","==","true"},
						"invoke",{
							{
								"message",{"mIgniteArmor", text = 2},
							},						
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert",{"IgniteArmorDebuff", text = 3},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"IgniteArmorDebuff", text = 4},
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {144467},
				execute = {
					{
						"quash","IgniteArmorDebuff",
					},
				},
			},
			--Seismic Activity
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144483},
				execute = {
					{
						"message","mSeismic",
						"closewindow",
						"set",{shockcount = 0},
						"set",{siegeMode = 1},
						"batchquash",{"LaserBurncd","BorerDrillcd","CrawlerMinecd","Ricochetcd"},
						"batchalert",{"ShockPulsecd","AssaultModecd"},
						"alert",{"NapalmOilcd", time = 3},
					},
					{
						"expect",{"&heroic&","==","true"},
						"alert",{"MortarBarragecd", time = 2},
					},
				},
			},
			--ShockPulse
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_START",
				spellid = {144485},
				execute = {
					{
						"batchalert",{"wShockPulse","ShockPulseCast"},
						"set",{shockcount = "INCR|1"},
					},
					{
						"expect",{"<shockcount>","<","3"},
						"alert","ShockPulsecd",
					},
				},
			},
			-----
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							{
								"expect",{"#5#","==","145407"}, -- MortarCannon
								"invoke",{
									{
										"expect",{"&isranged&","==","true"},
										"alert","wMortarCannon",
									},
								},
							},
							{
								"expect",{"#5#","==","144198"}, -- DemolisherCanon
								"message","mDemolisherCanons",
								"alert","DemolisherCanoncd",
							},							
							{
								"expect",{"#5#","==","144296"}, -- BorerDrill
								"alert","BorerDrillcd",
								"message","mBorerDrill",
							},
							{
								"expect",{"#5#","==","144673"}, -- Crawler Mine
								"invoke",{
									--{
									--	"expect",{"<phase>","==","1"},
									--	"message","mCrawlerMine",
									--	"alert","CrawlerMinecd",
									--},	
									{
										"expect",{"<siegeMode>","~=","1"},
										"alert","CrawlerMinecd",
									},								
								},
							},
							{
								"expect",{"#5#","==","144492"}, -- Napalm Oil
								"alert","NapalmOilcd",
								"message","mNapalmOil",
							},
							{
								"expect",{"#5#","==","146359"}, -- Regeneration
								--"set",{phase = 1},
								"quash","MortarBarragecd",
								"invoke",{
									{
										"expect",{"<siegeMode >","==","1"},
										"alert","SiegeModecd",
										"set",{siegeMode = 0},
									},
								},
								--"batchalert",{"LaserBurncd","CrawlerMinecd","BorerDrillcd","SiegeModecd"},
								--"batchquash",{"NapalmOilcd","ShockPulsecd"},
								--"openwindow",{"8"},
							},
							--[[{
								"expect",{"#5#","==","146360"}, -- Siege mode
								--"set",{phase = 2},
								"alert","ShockPulsecd",
								"alert",{"CrawlerMinecd", time = 3},
								"alert",{"NapalmOilcd", time = 2},
								"batchquash",{"LaserBurncd","SiegeModecd","BorerDrillcd","IgniteArmorcd"},
							},--]]	
							{
								"expect",{"#5#","==","144555"}, -- MortarBarrage
								"batchalert",{"MortarBarragecd","wMortarBarrage"},
							},	
							{
								"expect",{"#5#","==","144356"}, -- Ricochet
								"batchalert",{"Ricochetcd","wRicochet"},
							},								
						},
					},
				},
			},	
		},
	}

	DXE:RegisterEncounter(data)
end
