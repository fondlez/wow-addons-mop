local L,SN,ST,EJSN,EJST = DXE.L,DXE.SN,DXE.ST,DXE.EJSN,DXE.EJST

do
	local data = {
		version = 4,
		key = "Thok the Bloodthirsy",
		zone = L.zone["Siege of Orgrimmar"],
		category = L.zone["Siege of Orgrimmar"],
		name = L.npc_SiegeOfOrgrimmar["Thok the Bloodthirsy"],
		icon = "INTERFACE\\ENCOUNTERJOURNAL\\UI-EJ-BOSS-THOK THE BLOODTHIRSTY.BLP:35:35",
		triggers = {
			scan = {71529}, 
		},
		onactivate = {
			tracing = {71529},
			tracerstart = true,
			combatstop = true,
			defeat = {71529},
			unittracing = {"boss1"},
		},
		enrage = {
			time10n = 600,
			time25n = 600,
			time10h = 600,
			time25h = 600,
		},
		windows = {
			proxwindow = true,
			proxrange = 10,
		},
		userdata = {
			CorrosiveBloodUnists = {type = "container", wipein = 3},
			BurningBloodUnists = {type = "container", wipein = 3},
			FrozenSolidUnists = {type = "container", wipein = 3},
			Add = "",
			abilitycd = {13.5, 11, 7.2, 5, 3.5, 3.5, 3.5, loop = false, type = "series"},
			Acceleration = 0,
		},
		arrows = {
			Fixatearrow = {
				varname = SN[143445],
				unit = "#5#",
				persist = 5,
				action = "AWAY",
				msg = L.alert["MOVE AWAY!"],
				spell = SN[143445],
				range1 = 8,
				range2 = 10,
				range3 = 12,
				ability = 8132,
				icon = ST[143445],
			},
		},
		timers = {
			timerCorrosiveBlood = {
				{
					"message","mCorrosiveBlood",
				},
			},
			timerBurningBlood = {
				{
					"message","mBurningBlood",
				},
			},
			timerFrozenSolid = {
				{
					"message","mFrozenSolid",
				},
			},
			timerWreckingBall = {
				{
					"message","WreckingBall",
				},
			},	
			timerAdds = {
				{
					"expect",{"<Add>","==","Bats"},
					"alert","Addscd",
				},
				{
					"expect",{"<Add>","==","Yeti"},
					"alert",{"Addscd", time = 2},
				},
			},			
		},
		onstart = {
			{
				"alert","FearsomeRoarcd",
			},
			{
				"expect",{"&lfr&","==","true"},
				"alert",{"DeafeningScreechcd", time = 2},
			},
		},
		raidicons = {
			Fixatemark = {
				varname = SN[143445],
				type = "FRIENDLY",
				persist = 13,
				unit = "#5#",
				icon = 8,
				ability = 8132,
				icon2 = ST[143445],
			},
		},
		announces = { 
			Fixatesay = {
				varname = format(L.alert["%s %s %s!"],SN[143445],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143445],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143445],
			},
			BurningBloodsay = {
				varname = format(L.alert["%s %s %s!"],SN[143783],L.alert["on"],L.alert["Me"]),
				type = "SAY",
				msg = format(L.alert["%s %s %s!"],SN[143783],L.alert["on"],L.alert["Me"]),
				ability = 8132,
				icon = ST[143783],
			},				
		},
		messages = {
			mWreckingBall = {
				varname = "(H) "..format(L.alert["%s %s"],SN[148145],L.alert["soon"]),
				type = "message",
				text = format(L.alert["%s %s"],SN[148145],L.alert["soon"]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[148145],
			},	
			mCorrosiveBlood = {
				varname = format(L.alert["%s %s %s"],SN[143791],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|CorrosiveBloodUnists&"],SN[143791],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143791],
			},
			mBurningBlood = {
				varname = format(L.alert["%s %s %s"],SN[143783],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|BurningBloodUnists&"],SN[143783],L.alert["on"]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143783],
			},			
			mFrozenSolid = {
				varname = format(L.alert["%s %s %s"],SN[143777],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s &list|FrozenSolidUnists&"],SN[143777],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143777],
			},
			mSkeletonKey = {
				varname = format(L.alert["%s %s %s"],SN[146589],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[146589],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[146589],
			},	
			mSkeletonKeyOpen = {
				varname = format(L.alert["%s - %s"],SN[146589],L.chat_SiegeOfOrgrimmar["Cage opened"]),
				type = "message",
				text = format(L.alert["%s - %s"],SN[146589],L.chat_SiegeOfOrgrimmar["Cage opened"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[146589],
			},			
			mEnrage = {
				varname = format(L.alert["%s %s %s"],SN[145974],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5#"],SN[145974],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[145974],
			},	
			mAcceleration = {
				varname = format(L.alert["%s (2)"],SN[143411]),
				type = "message",
				text = format(L.alert["%s (1)"],SN[143411]),
				text2 = format(L.alert["%s (#11#)"],SN[143411]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143411],
			},
			mFearsomeRoar = {
				varname = format(L.alert["%s %s %s (2)"],SN[143766],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[143766],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[143766],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143766],
			},	
			mFearsomeRoarStacks = {
				varname = format("%s %s #11# %s %s!",SN[143766],L.alert["already at"],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format("%s %s #11# %s #5#!",SN[143766],L.alert["already at"],L.alert["on"]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143766],
				extank = true,
				exdps = true,
			},
			mAcidBreath = {
				varname = format(L.alert["%s %s %s (2)"],SN[143780],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[143780],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[143780],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143780],
			},	
			mAcidBreathStacks = {
				varname = format("%s %s #11# %s %s!",SN[143780],L.alert["already at"],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format("%s %s #11# %s #5#!",SN[143780],L.alert["already at"],L.alert["on"]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143780],
				extank = true,
				exdps = true,
			},
			mFrostBreath = {
				varname = format(L.alert["%s %s %s (2)"],SN[143773],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[143773],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[143773],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143773],
			},	
			mFrostBreathStacks = {
				varname = format("%s %s #11# %s %s!",SN[143773],L.alert["already at"],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format("%s %s #11# %s #5#!",SN[143773],L.alert["already at"],L.alert["on"]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143773],
				extank = true,
				exdps = true,
			},
			mScorchingBreath = {
				varname = format(L.alert["%s %s %s (2)"],SN[143767],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[143767],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[143767],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143767],
			},	
			mScorchingBreathStacks = {
				varname = format("%s %s #11# %s %s!",SN[143767],L.alert["already at"],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format("%s %s #11# %s #5#!",SN[143767],L.alert["already at"],L.alert["on"]),
				color1 = "ORANGE",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143767],
				extank = true,
				exdps = true,
			},	
			mBloodFrenzy = {
				varname = format(L.alert["%s %s %s (2)"],SN[143442],L.alert["on"],L.alert["player"]),
				type = "message",
				text = format(L.alert["%s %s #5# (1)"],SN[143442],L.alert["on"]),
				text2 = format(L.alert["%s %s #5# (#11#)"],SN[143442],L.alert["on"]),
				color1 = "PURPLE",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143442],
			},
			mBloodFrenzyOver = {
				varname = format(L.alert["%s %s"],SN[143440],L.alert["Over"]),
				type = "message",
				text = format(L.alert["%s %s"],SN[143440],L.alert["Over"]),
				color1 = "RED",
				sound = "ALERT13",
				ability = 8130,
				icon = ST[143440],
			},	
			mDeafeningScreech = {
				varname = format(L.alert["%s"],SN[143343]),
				type = "message",
				text = format(L.alert["%s"],SN[143343]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143343],
			},
			mTailLash = {
				varname = format(L.alert["%s"],SN[143428]),
				type = "message",
				text = format(L.alert["%s"],SN[143428]),
				color1 = "TAN",
				sound = "ALERT13",
				ability = 8132,
				icon = ST[143428],
				enabled = false,
			},			
		},
		alerts = {
			FearsomeRoarcd = {
				varname = format(L.alert["%s Cooldown"],SN[143766]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143766]),
				time = 11,
				color1 = "NEWBLUE",
				icon = ST[143766],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			DeafeningScreechcd = {
				varname = format(L.alert["%s Cooldown"],SN[143343]),
				type = "centerpopup",
				text = format(L.alert["%s Cooldown"],SN[143343]),
				time = 13,
				time2 = 19,
				time3 = "<abilitycd>",
				color1 = "NEWBLUE",
				icon = ST[143343],
				ability = 8132,
			},
			TailLashcd = {
				varname = format(L.alert["%s Cooldown"],SN[143428]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143428]),
				time = 10,
				color1 = "NEWBLUE",
				icon = ST[143428],
				ability = 8132,
				enabled = false,
			},
			BloodFrenzycd = {
				varname = format(L.alert["%s Cooldown"],SN[143442]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143442]),
				time = 5,
				color1 = "NEWBLUE",
				icon = ST[143442],
				ability = 8132,
			},
			AcidBreathcd = {
				varname = format(L.alert["%s Cooldown"],SN[143780]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143780]),
				time = 11,
				color1 = "NEWBLUE",
				icon = ST[143780],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			CorrosiveBloodcd = {
				varname = format(L.alert["%s Cooldown"],SN[143791]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143791]),
				time = 3.5,
				time2 = 6,
				color1 = "NEWBLUE",
				icon = ST[143791],
				ability = 8132,
				enabled = false,
			},	
			FrostBreathcd = {
				varname = format(L.alert["%s Cooldown"],SN[143773]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143773]),
				time = 9.5,
				time2 = 6,
				color1 = "NEWBLUE",
				icon = ST[143773],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},	
			ScorchingBreathcd = {
				varname = format(L.alert["%s Cooldown"],SN[143767]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143767]),
				time = 11,
				color1 = "NEWBLUE",
				icon = ST[143767],
				ability = 8132,
				exdps = true,
				exhealer = true,
			},
			BurningBloodcd = {
				varname = format(L.alert["%s Cooldown"],SN[143783]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[143783]),
				time = 3.5,
				time2 = 8,
				color1 = "NEWBLUE",
				icon = ST[143783],
				ability = 8132,
				enabled = false,
			},
			WreckingBallcd = {
				varname = "(H) "..format(L.alert["%s Cooldown"],SN[148145]),
				type = "dropdown",
				text = format(L.alert["%s Cooldown"],SN[148145]),
				time = 15,
				color1 = "RED",
				icon = ST[148145],
				ability = 8132,
			},	
			Addscd = {
				varname = "(H) "..format(L.alert["Next Adds: %s"],"<Add>"),
				type = "dropdown",
				text = format(L.alert["Next Adds: %s"],"<Add>"),
				time = 13,
				time2 = 10,
				color1 = "NEWBLUE",
				icon = ST[143440],
				ability = 8132,
			},
			-- Warning
			wBloodFrenzy = {
				varname = format("%s!",SN[144067]),
				type = "simple",
				text = format("%s!",SN[144067]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT13",
				icon = ST[144067],
			},
			wAcidPustules = {
				varname = format("%s!",SN[143971]),
				type = "simple",
				text = format("%s!",SN[143971]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT13",
				icon = ST[143971],
			},
			wFrostPustules = {
				varname = format("%s!",SN[143968]),
				type = "simple",
				text = format("%s!",SN[143968]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT13",
				icon = ST[143968],
			},
			wFirePustules = {
				varname = format("%s!",SN[143970]),
				type = "simple",
				text = format("%s!",SN[143970]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT13",
				icon = ST[143970],
			},
			-- Inform
			iFearsomeRoar = {
				varname = format("%s %s 2!",SN[143766],L.alert["already at"]),
				type = "inform",
				text = format("%s %s #11#!",SN[143766],L.alert["already at"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[143766],
				exdps = true,
				exhealer = true,
			},
			iAcidBreath = {
				varname = format("%s %s 2!",SN[143780],L.alert["already at"]),
				type = "inform",
				text = format("%s %s #11#!",SN[143780],L.alert["already at"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[143780],
				exdps = true,
				exhealer = true,
			},
			iFrostBreath = {
				varname = format("%s %s 2!",SN[143773],L.alert["already at"]),
				type = "inform",
				text = format("%s %s #11#!",SN[143773],L.alert["already at"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[143773],
				exdps = true,
				exhealer = true,
			},
			iScorchingBreath = {
				varname = format("%s %s 2!",SN[143767],L.alert["already at"]),
				type = "inform",
				text = format("%s %s #11#!",SN[143767],L.alert["already at"]),
				time = 2,
				color1 = "BROWN",
				sound = "ALERT14",
				icon = ST[143767],
				exdps = true,
				exhealer = true,
			},	
			iFixate = {
				varname = format(L.alert["%s %s %s!"],SN[143445],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143445],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "RED",
				icon = ST[143445],
				sound = "ALERT11",
				ability = 8132,
				flashscreen = true,
			},
			iBurningBlood = {
				varname = format(L.alert["%s %s %s!"],SN[143783],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[143783],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "ORANGE",
				icon = ST[143783],
				sound = "ALERT10",
				ability = 8132,
				--flashscreen = true,
			},
			iBurningBloodAway = {
				varname = format(L.alert["%s %s %s, %s!"],SN[143783],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				type = "inform",
				text = format(L.alert["%s %s %s, %s!"],SN[143783],L.alert["on"],L.alert["YOU"],L.alert["MOVE AWAY"]),
				time = 2,
				color1 = "RED",
				icon = ST[143783],
				sound = "ALERT10",
				ability = 8132,
				flashscreen = true,
			},				
			iIcyBlood = {
				varname = format("%s %s 2!",SN[143800],L.alert["already at"]),
				type = "inform",
				text = format("%s %s #11#!",SN[143800],L.alert["already at"]),
				time = 2,
				color1 = "RED",
				sound = "ALERT11",
				icon = ST[143800],
			},	
			iSkeletonKey = {
				varname = format(L.alert["%s %s %s!"],SN[146589],L.alert["on"],L.alert["YOU"]),
				type = "inform",
				text = format(L.alert["%s %s %s!"],SN[146589],L.alert["on"],L.alert["YOU"]),
				time = 2,
				color1 = "GREY",
				icon = ST[146589],
				sound = "ALERT14",
				ability = 8132,
				flashscreen = true,
			},
			-- Casts
			FixateCast = {
				varname = format(L.alert["%s Active"],SN[143445]),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[143445]),
				text2 = format(L.alert["#5#: %s"],SN[143445]),
				time = 12,
				color1 = "RED",
				icon = ST[143445],
				ability = 8132,
			},	
			SkeletonKeyCast = {
				varname = format(L.alert["%s Active"],SN[146589]),
				type = "centerpopup",
				text = format(L.alert["%s: %s"],L.alert["YOU"],SN[146589]),
				text2 = format(L.alert["#5#: %s"],SN[146589]),
				time = 60,
				color1 = "RED",
				icon = ST[146589],
				ability = 8132,
			},
			WreckingBallCast = {
				varname = format(L.alert["%s Active"],SN[148145]),
				type = "centerpopup",
				text = format(L.alert["%s Active"],SN[148145]),
				time = 15,
				color1 = "GREEN",
				icon = ST[148145],
				ability = 8132,
			},				
			-- Debuff
			FearsomeRoarDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143766]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143766]),
				text2 = format(L.alert["#5# (1): %s"],SN[143766]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143766]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143766]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[143766],
				tag = "#5#",
				exdps = true,
			},
			AcidBreathDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143780]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143780]),
				text2 = format(L.alert["#5# (1): %s"],SN[143780]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143780]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143780]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[143780],
				tag = "#5#",
				exdps = true,
			},
			FrostBreathDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143773]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143773]),
				text2 = format(L.alert["#5# (1): %s"],SN[143773]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143773]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143773]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[143773],
				tag = "#5#",
				exdps = true,
			},	
			ScorchingBreathDebuff = {
				varname = format(L.alert["%s Debuff"],SN[143767]),
				type = "debuff",
				text = format(L.alert["%s (1): %s"],L.alert["YOU"],SN[143767]),
				text2 = format(L.alert["#5# (1): %s"],SN[143767]),
				text3 = format(L.alert["%s (#11#): %s"],L.alert["YOU"],SN[143767]),
				text4 = format(L.alert["#5# (#11#): %s"],SN[143767]),
				time = 30,
				color1 = "PURPLE",
				ability = 8130,
				icon = ST[143767],
				tag = "#5#",
				exdps = true,
			},				
		},
		events = {
			-- Acceleration
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143411},
				execute = {
					{
						"message","mAcceleration",
						"set",{Acceleration = "1"},
					},
				},
			},
			-- DeafeningScreech
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143343},
				execute = {
					{
						"expect",{"&lfr&","==","true"},
						"alert",{"DeafeningScreechcd", time = 2},
					},
					{
						"expect",{"&lfr&","==","false"},
						--"expect",{"<Acceleration>","<","8"},
						"alert",{"DeafeningScreechcd", time = 3},
						--"message","mDeafeningScreech",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143411},
				execute = {
					{
						"message",{"mAcceleration", text = 2},
						"set",{Acceleration = "#11#"},
					},
				},
			},
			--[[{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143411},
				execute = {
					{
						"alert","DeafeningScreechcd",
						"openwindow",{"10"},
					},
				},
			},	--]]
			-- FearsomeRoar
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143766},
				execute = {
					{
						"alert","FearsomeRoarcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message","mFearsomeRoar",
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","FearsomeRoarDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"FearsomeRoarDebuff", text = 2},
							},	
						},
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143766},
				execute = {
					{
						"alert","FearsomeRoarcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message",{"mFearsomeRoar", text = 2},
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert",{"FearsomeRoarDebuff", text = 3},
								"invoke",{
									{
										"expect",{"#11#",">=","2"},
										"alert","iFearsomeRoar",
									},
								},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"FearsomeRoarDebuff", text = 4},
								"invoke",{
									{
										"expect",{"#11#",">=","2"},
										"message","mFearsomeRoarStacks",
									},
								},	
							},	
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143766},
				execute = {
					{
						"quash","FearsomeRoarDebuff",
					},
				},
			},	
			-- AcidBreath
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143780},
				execute = {
					{
						"alert","AcidBreathcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message","mAcidBreath",
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","AcidBreathDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"AcidBreathDebuff", text = 2},
							},	
						},
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143780},
				execute = {
					{
						"alert","AcidBreathcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message",{"mAcidBreath", text = 2},
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert",{"AcidBreathDebuff", text = 3},
								"invoke",{
									{
										"expect",{"#11#",">=","2"},
										"alert","iAcidBreath",
									},
								},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"AcidBreathDebuff", text = 4},
								"invoke",{
									{
										"expect",{"#11#",">=","2"},
										"message","mAcidBreathStacks",
									},
								},	
							},	
						},
					},	
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143780},
				execute = {
					{
						"quash","AcidBreathDebuff",
					},
				},
			},	
			-- FrostBreath
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143773},
				execute = {
					{
						"alert","FrostBreathcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message","mFrostBreath",
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","FrostBreathDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"FrostBreathDebuff", text = 2},
							},	
						},
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143773},
				execute = {
					{
						"alert","FrostBreathcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message",{"mFrostBreath", text = 2},
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert",{"FrostBreathDebuff", text = 3},
								"invoke",{
									{
										"expect",{"#11#",">=","3"},
										"alert","iFrostBreath",
									},
								},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"FrostBreathDebuff", text = 4},
								"invoke",{
									{
										"expect",{"#11#",">=","3"},
										"message","mFrostBreathStacks",
									},
								},	
							},	
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143773},
				execute = {
					{
						"quash","FrostBreathDebuff",
					},
				},
			},	
			-- ScorchingBreath
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143767},
				execute = {
					{
						"alert","ScorchingBreathcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message","mScorchingBreath",
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert","ScorchingBreathDebuff",
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"ScorchingBreathDebuff", text = 2},
							},	
						},
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143767},
				execute = {
					{
						"alert","ScorchingBreathcd",
					},
					{
						"expect",{"&istargettank|#5#|boss1&","==","true"},
						"message",{"mScorchingBreath", text = 2},
						"invoke",{
							{
								"expect",{"#4#","==","&playerguid&"},
								"alert",{"ScorchingBreathDebuff", text = 3},
								"invoke",{
									{
										"expect",{"#11#",">=","3"},
										"alert","iScorchingBreath",
									},
								},
							},
							{
								"expect",{"#4#","~=","&playerguid&"},
								"alert",{"ScorchingBreathDebuff", text = 4},
								"invoke",{
									{
										"expect",{"#11#",">=","3"},
										"message","mScorchingBreathStacks",
									},
								},	
							},	
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143767},
				execute = {
					{
						"quash","ScorchingBreathDebuff",
					},
				},
			},
			-- BloodFrenzy
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143440},
				execute = {
					{
						"alert","BloodFrenzycd",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143440},
				execute = {
					{
						"quash","BloodFrenzycd",
					},
					{
						"expect",{"&lfr&","==","true"},
						"alert",{"DeafeningScreechcd", time = 2},
					},
					{
						"openwindow",{"10"},
						"message","mBloodFrenzyOver",
						"set",{
							abilitycd = {13.5, 11, 7.2, 5, 3.5, 3.5, 3.5, loop = false, type = "series"},
						},
						"set",{Acceleration = 0},
					},
					{
						"expect",{"&heroic&","==","true"},
						"scheduletimer",{"timerAdds",10},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143442},
				execute = {
					{
						"message","mBloodFrenzy",
						"alert","BloodFrenzycd",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143442},
				execute = {
					{
						"message",{"mBloodFrenzy", text = 2},
						"alert","BloodFrenzycd",
					},
					--{
					--	"expect",{"&checkperc|#11#|2&","==","0"},
					--	"message","mBloodFrenzy",
					--},					
				},
			},			
			-- Fixate
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143445},
				execute = {
					{
						"message","mFixate",
						"raidicon","Fixatemark",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"batchalert",{"FixateCast","iFixate"},
						"announce","Fixatesay",
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"FixateCast", text = 2},		
						"arrow","Fixatearrow",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {143445},
				execute = {
					{
						"quash","FixateCast",
					},
				},
			},
			-- CorrosiveBlood
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143791},
				execute = {
					{
						"insert",{"CorrosiveBloodUnists","#5#"},
						"canceltimer","timerCorrosiveBlood",
						"scheduletimer",{"timerCorrosiveBlood",0.5},
					},
				},
			},	
			-- FrozenSolid
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {143777},
				execute = {
					{
						"insert",{"FrozenSolidUnists","#5#"},
						"canceltimer","timerFrozenSolid",
						"scheduletimer",{"timerFrozenSolid",1},
					},
				},
			},
			-- Enrage
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {145974},
				execute = {
					{
						"expect",{"&istank&","==","true"},
						"message","mEnrage",
					},
					{
						"expect",{"&istank&","~=","true"},
						"expect",{"&removeenrage&","==","true"},
						"message","mEnrage",
					},
				},
			},
			-- IcyBlood
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED_DOSE",
				spellid = {143800},
				dstisplayerunit = true,
				execute = {
					{
						"expect",{"#11#",">=","3"},
						"alert","iIcyBlood",
					},
				},
			},	
			-- SkeletonKey
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {146589},
				execute = {
					{
						"message","mSkeletonKey",
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"batchalert",{"SkeletonKeyCast","iSkeletonKey"},
					},
					{
						"expect",{"#4#","~=","&playerguid&"},
						"alert",{"SkeletonKeyCast", text = 2},
					},					
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_REMOVED",
				spellid = {146589},
				execute = {
					{
						"message","mSkeletonKeyOpen",
						"quash","SkeletonKeyCast",
					},
				},
			},
			-- Wrecking Ball (heroic yeti charge)
			{
				type = "combatevent",
				eventtype = "SPELL_AURA_APPLIED",
				spellid = {148145},
				execute = {
					{
						"scheduletimer",{"timerWreckingBall",15},
						"batchalert",{"WreckingBallcd","WreckingBallCast"},
					},					
				},
			},	
			-- BurningBlood
			{
				type = "combatevent",
				eventtype = "SPELL_DAMAGE",
				spellid = {143783},
				execute = {
					{
						"insert",{"BurningBloodUnists","#5#"},
						"canceltimer","timerBurningBlood",
						"scheduletimer",{"timerBurningBlood",1},
						"schedulealert",{"BurningBloodcd",0.5},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iBurningBlood",
						"announce","BurningBloodsay",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_MISSED",
				spellid = {143783},
				execute = {
					{
						"insert",{"BurningBloodUnists","#5#"},
						"canceltimer","timerBurningBlood",
						"scheduletimer",{"timerBurningBlood",1},
						"schedulealert",{"BurningBloodcd",0.5},
					},
					{
						"expect",{"#4#","==","&playerguid&"},
						"alert","iBurningBlood",
						"announce","BurningBloodsay",
					},
				},
			},	
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_DAMAGE",
				spellid = {143784},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBurningBloodAway",
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "SPELL_PERIODIC_MISSED",
				spellid = {143784},
				dstisplayerunit = true,
				execute = {
					{
						"alert","iBurningBloodAway",
					},
				},
			},
			------------
			{
                type = "event",
                event = "UNIT_SPELLCAST_SUCCEEDED",
                execute = {
					{
						"expect",{"#1#","==","boss1"},
						"invoke",{
							{
								"expect",{"#5#","==","144067"}, -- Blood Frenzy
								"batchquash",{"FearsomeRoarcd","AcidBreathcd","FrostBreathcd","ScorchingBreathcd","TailLashcd"},
								"batchalert",{"wBloodFrenzy","TailLashcd"},
								"closewindow",
							},
							{
								"expect",{"#5#","==","143971"}, -- Acid Pustules
								"quash","BurningBloodcd",
								"batchalert",{"wAcidPustules","AcidBreathcd"},
								"alert",{"CorrosiveBloodcd", time = 2},
							},
							{
								"expect",{"#5#","==","143968"}, -- Frost Pustules
								"batchquash",{"BurningBloodcd","CorrosiveBloodcd"},
								"alert","wFrostPustules",
								"alert",{"FrostBreathcd", time = 2},
							},
							{
								"expect",{"#5#","==","143970"}, -- Fire Pustules
								"quash","CorrosiveBloodcd",
								"batchalert",{"wFirePustules","ScorchingBreathcd"},
								"alert",{"BurningBlood", time = 2},
							},
						},
					},
				},
			},
			{
				type = "combatevent",
				eventtype = "UNIT_DIED",
				execute = {
					{
						"expect",{"&npcid|#4#&","==","71744"},  -- Bats
						"set",{Add = "Bats"},
					},
					{
						"expect",{"&npcid|#4#&","==","71749"},  -- Yeti
						"set",{Add = "Yeti"},
					},
					{
						"expect",{"&npcid|#4#&","==","73526"},  -- Starved Yeti
						"set",{Add = "none"},
						"canceltimer","timerAdds",
					},
				},
			},

			-- TailLash
			{
				type = "combatevent",
				eventtype = "SPELL_CAST_SUCCESS",
				spellid = {143428},
				execute = {
					{
						"alert","TailLashcd",
						"message","mTailLash",
					},
				},
			},
		},
	}

	DXE:RegisterEncounter(data)
end
