-------------------
-- Binding Labes --
-------------------

_G["BINDING_HEADER_DARC_H_ARCH"]     = "Archaeology"
_G["BINDING_NAME_SPELL Survey"]      = "Survey"
_G["BINDING_NAME_SPELL Archaeology"] = "Archaeology Frame"
