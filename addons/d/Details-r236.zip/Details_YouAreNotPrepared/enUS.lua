local Loc = LibStub("AceLocale-3.0"):NewLocale ("Details_YouAreNotPrepared", "enUS", true) 

if (not Loc) then
	return 
end 

Loc ["STRING_PLUGIN_NAME"] = "You Are Not Prepared"
Loc ["STRING_PLUGIN_ALERT"] = "|cFFFFFF00YANP|r: click to see the death log "

