local Loc = LibStub("AceLocale-3.0"):NewLocale("Details_RaidInfo-ThroneOfThunder", "ptBR") 

if (not Loc) then
	return 
end 

Loc ["PLUGIN_NAME"] = "Info da Raide Trono do Trovao"
Loc ["STRING_RAID_NAME"] = "Trono do Trovao"

---------------------------------------------------------------------------------------------------

