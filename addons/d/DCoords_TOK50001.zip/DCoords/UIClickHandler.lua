

-- #######################################################
-- Handle left click
-- Handle right click
-- Handle drag
-- #######################################################
function handleMouseDown(self, buttonName)    
    -- Prevent activation when in combat
		if (InCombatLockdown() == 1) then
			return;
		end
		

		-- Handle left button clicks
    if (buttonName == "LeftButton") then
    	--trace("DCoords: handleMouseDown() - Left clicked");
    
    	if (DCEnableDrag == 1) then
    		DCoords:StartMoving();
    		trace("DCoords: Hold left click and drag, to move.");
    	else
   			trace("DCoords: If you are trying to move DCoords, open the menu and tick the enable drag box first. Right click DCoords bar for menu.");
    	end
    end
    
    
    -- Handle right button clicks
    if (buttonName == "RightButton") then    	
    	
    	--trace("DCoords: handleMouseDown() - Right clicked");
    	
    	if (DCMenuVisible == 1) then
    		-- attempt to hide menu
    		trace("DCoords: Hide menu.");
    		DCoordsMenu:Hide()
    		DCoordsMenuVisible = false
    	else
    		-- attempt to show menu
    		trace("DCoords: Show menu.");
    		DCoordsMenu:Show()
    		DCoordsMenuVisible = true
    	end
    	
    	
    end
end
-- #######################################################





-- #######################################################
function handleMouseUp(self, button)
	DCoords:StopMovingOrSizing();
end
-- #######################################################







-- #######################################################
function handleDragTickBoxClick(self, button, down)
	if (DCoordsEnableDrag == false) then
		trace("DCoords: Location bar can now be dragged.");
		DCoordsEnableDrag = true;
	else
		trace("DCoords: Location bar is now locked in place.");
		DCoordsEnableDrag = false;
	end
end
-- #######################################################








-- #######################################################
function handleCloseButtonClick()
	trace("DCoords: Hide menu.");
	DCoordsMenu:Hide()
  DCoordsMenuVisible = false
end
-- #######################################################


