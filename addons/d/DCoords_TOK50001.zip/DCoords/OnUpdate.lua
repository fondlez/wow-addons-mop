-- #######################################################
-- OnUpdate Handler (Coordinates calculations + )
-- #######################################################


-- #######################################################
-- WORLD MAP Coordinates OnUpdate
-- #######################################################
local fontSize = 10;
local fontStyle = "Fonts\\FRIZQT__.TTF";
local fontOutline = "OUTLINE";
-- #######################################################




function handleOnUpdate(self, elapsed)

	updateCoordinatesVariables();
	zoneText = GetZoneText();
	subZoneText = GetSubZoneText();

	-- Show all
	if (DCShowZone==1) and (DCShowSubZone==1) then
		if (subZoneText == nil) then
			DCoordsLocationText:SetText(zoneText .. " - [" .. playerX .. " - " .. playerY .. "]");
		else
			DCoordsLocationText:SetText(zoneText .. " - " .. subZoneText .. " - [" .. playerX .. " - " .. playerY .. "]");
		end
	end
	
	-- Show just the main zone
	if (DCShowZone==1) and (DCShowSubZone==0) then
		DCoordsLocationText:SetText(zoneText .. " - [" .. playerX .. " - " .. playerY .. "]");
	end
	
	-- Show just the sub zone
	if (DCShowZone==0) and (DCShowSubZone==1) then
		DCoordsLocationText:SetText(subZoneText .. " - [" .. playerX .. " - " .. playerY .. "]");
	end
	
	-- Show just the coordinates
	if (DCShowZone==0) and (DCShowSubZone==0) then
		DCoordsLocationText:SetText(playerX .. " - " .. playerY);
	end
	
	
	-- Update text color
	--DCoordsLocationText:SetTextColor(DCR,DCG,DCB);
	
	
	
	-- WORLD MAP	
	-- Partial fix for advanced (fullscreen worldmap) allow last coordinates at open to be visible but no update
	-- Coordinates_worldMapText:SetText("DCoords doesn't support full screen map mode - dissable world map coords via /dc menu");
	
	if (CoordinatesDB["worldmap"] and WorldMapFrame:IsVisible()) then
	
	--local stra = GetCVar("advancedWorldMap");
	--local strb = GetCVar("miniWorldMap");
		
	
				-- World map calc
		 		local mapscale = WorldMapDetailFrame:GetEffectiveScale();
		 		local cursorX, cursorY = GetCursorPosition();
		 		cursorX = cursorX / mapscale;
		 		cursorY = cursorY / mapscale;
		 		local width = WorldMapDetailFrame:GetWidth();
		 		local height = WorldMapDetailFrame:GetHeight();
				local left = WorldMapDetailFrame:GetLeft();
				local top = WorldMapDetailFrame:GetTop();
				
				cursorX = (cursorX - left) / width * 100;
				cursorY = (top - cursorY) / height * 100;
				
				local dccursorpos = "";
				if (DCSingleDecimal==0) then
		 			dccursorpos = "Cursor: "..format("%.2f , %.2f ", cursorX, cursorY);
		 		else 
		 			dccursorpos = "Cursor: "..format("%.1f , %.1f ", cursorX, cursorY);
		 		end
		
					
			
				-- Set world map text
				scaledFontSize = fontSize / mapscale;
				Coordinates_worldMapText:SetFont(fontStyle, scaledFontSize, fontOutline);
				--Coordinates_worldMapText:SetText("Player location: " .. dccursorpos);
				
				--trace("GetCVar(advancedWorldMap) = " .. GetCVar("advancedWorldMap"));
				Coordinates_worldMapText:SetText("You: [" .. playerX .. " - " .. playerY .. "]     " .. dccursorpos);
				
		
	end

end
-- #######################################################





ax = 0;
ay = 0;



-- #######################################################
-- Coordinates calculations
-- #######################################################
function updateCoordinatesVariables()
	
	ax, ay = GetPlayerMapPosition("player");
	acx = ax;
	acy = ay;
	
	-- Prevent processing of negative numbers
	if (ax < 0 and ay  < 0) then
		return
	end
	
	
	if (DCSingleDecimal==0) then
		playerX = string.format("%.2f", (ax*100));
		playerY = string.format("%.2f", (ay*100));
	else
		playerX = string.format("%.1f", (ax*100));
		playerY = string.format("%.1f", (ay*100));
	end
end
-- #######################################################


