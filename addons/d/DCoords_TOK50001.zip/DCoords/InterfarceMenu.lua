-- ############################################################################################################################################################
function setupInterfaceMenu()

	-- Create menu in interface panel (I dont like this want it without going through all those menus)
	--local DcoordsInterfaceMenuFrame = CreateFrame("Frame", "DCoordsConfig", InterfaceOptionsFramePanelContainer);
	--DcoordsInterfaceMenuFrame.name = "DCoords";
	--InterfaceOptions_AddCategory(DcoordsInterfaceMenuFrame);
	
	-- Create a new frame
	-- local DcoordsInterfaceMenuFrame = CreateFrame("Frame", "DCMenuFrame", UIParent);
	-- DcoordsInterfaceMenuFrame.name = "DCoordsMenu";
	-- DcoordsInterfaceMenuFrame:SetWidth(428) -- Set these to whatever height/width is needed 
	-- DcoordsInterfaceMenuFrame:SetHeight(164) -- for your Texture

	-- local t = DCMenuFrame:CreateTexture(nil,"BACKGROUND");
	-- t:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Factions.blp");
	-- t:SetAllPoints(DcoordsInterfaceMenuFrame)
	-- DcoordsInterfaceMenuFrame.texture = t;
	-- DcoordsInterfaceMenuFrame:SetPoint("LEFT",0,0);
	-- DcoordsInterfaceMenuFrame:Show();
	
	-- Use xml frame
	local DcoordsInterfaceMenuFrame = _G["DCoordsMenu"];
	
	-- Titles
	local DcoordsConfigTitle1 = dcTextField(DcoordsInterfaceMenuFrame,"DcoordsConfigTitle1","DCoords v3.01",14,"TOPLEFT",16,-16,1,1,1);
	local DcoordsConfigTitle2 = dcTextField(DcoordsInterfaceMenuFrame,"DcoordsConfigTitle2","Darcey.Lloyd@gmail.com",7.2,"TOPLEFT",17,-30,1,1,1);
	
	-- Checkboxes
	xstep = 14;
	ystep = -45;
	cbEnableDrag = dcCheckBox(DcoordsInterfaceMenuFrame,"cbEnableDrag","Enable drag",11,"TOPLEFT",xstep,ystep,1,1,1); 	
	ystep = ystep - 25;
	
	cbShowZone = dcCheckBox(DcoordsInterfaceMenuFrame,"cbShowZone","Show zone",11,"TOPLEFT",xstep,ystep,1,1,1);	
	ystep = ystep - 25;
	
	cbShowSubZone = dcCheckBox(DcoordsInterfaceMenuFrame,"cbShowSubZone","Show sub zone",11,"TOPLEFT",xstep,ystep,1,1,1);
	
	ystep = ystep - 25;
	cbSingleDecimal = dcCheckBox(DcoordsInterfaceMenuFrame,"cbSingleDecimal","Round coordinates to 1 decimal place",11,"TOPLEFT",14,ystep,1,1,1);
	
	ystep = ystep - 25;
	cbShowBackground = dcCheckBox(DcoordsInterfaceMenuFrame,"cbShowBackground","Show background",11,"TOPLEFT",xstep,ystep,1,1,1);
	
	ystep = ystep - 25;
	cbShowCoordinates = dcCheckBox(DcoordsInterfaceMenuFrame,"cbShowCoordinates","Show in game coordinates",11,"TOPLEFT",xstep,ystep,1,1,1);
	
	ystep = ystep - 25;
	cbShowWorldMapCoordinates = dcCheckBox(DcoordsInterfaceMenuFrame,"cbShowWorldMapCoordinates","Show world map coordinates",11,"TOPLEFT",xstep,ystep,1,1,1);
	
	

	
	
	
	
	local inGameFrameConfigTitle = dcTextField(DcoordsInterfaceMenuFrame,"InGameCoordinatesFrameConfigTitle","In game coordinates bar settings",12,"TOPLEFT",275,-45,0.5,1,1);
	
	-- Sliders
	xstep = 275;	ystep = -80;
	local sliderBgAlpha = dcHSlider(DcoordsInterfaceMenuFrame,"sliderBgAlpha",xstep,ystep,0,1,1.0,"Background alpha",100,1,1,1);
	
	xstep = xstep + 120;
	local sliderFrameScale = dcHSlider(DcoordsInterfaceMenuFrame,"sliderFrameScale",xstep,ystep,0.1,2,1.0,"Scale",100,1,1,1);		
	
	xstep = xstep + 120;
	local sliderAlpha = dcHSlider(DcoordsInterfaceMenuFrame,"sliderAlpha",xstep,ystep,0,1,1.0,"Alpha",100,1,1,1);
	
	xstep = 275;	ystep = -140;
	local sliderFrameWidth = dcHSlider(DcoordsInterfaceMenuFrame,"sliderFrameWidth",xstep,ystep,20,1000,DCWidth,"Width",340,1,1,1);
	
	
	
	
	xstep = 275; ystep = -180;
	local CoordinatesColourTitle = dcTextField(DcoordsInterfaceMenuFrame,"CoordinatesColourTitle","Coordinates text colour",12,"TOPLEFT",xstep,ystep,0.5,1,1);
	
	xstep = 275;	ystep = -220;
	local sliderTextR = dcHSlider(DcoordsInterfaceMenuFrame,"sliderTextR",xstep,ystep,0,1,1.0,"RED",100,1,1,1);
	
	xstep = xstep + 120;
	local sliderTextG = dcHSlider(DcoordsInterfaceMenuFrame,"sliderTextG",xstep,ystep,0,1,1.0,"GREEN",100,1,1,1);
	
	xstep = xstep + 120;
	local sliderTextB = dcHSlider(DcoordsInterfaceMenuFrame,"sliderTextB",xstep,ystep,0,1,1.0,"BLUE",100,1,1,1);
	

	
		
	
	-- World map enable / dissable DCoords (event is not in scope) TO DO
	-- cbEnableDrag = dcCheckBox(WorldMapButton,"DCoordsWorldMapCB","DCoords",14,"BOTTOMRIGHT",-430,-37,1,1,1); 	
	
	
	
end
-- ############################################################################################################################################################




