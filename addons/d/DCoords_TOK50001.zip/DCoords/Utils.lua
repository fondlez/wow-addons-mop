


-- #######################################################
-- Darcey's debug function & utilitie
-- #######################################################
function trace(msg)
	DEFAULT_CHAT_FRAME:AddMessage(msg);
end

function returnNiceBoolean(arg)
	if (arg == true) then
		return true;
	else
		return false;
	end
end

function traceboolean(arg)
	if (arg == true) then
		trace(true);
	else
		trace(false);
	end
end


function round(n, precision)
  local m = 10^(precision or 0)
  return floor(m*n + 0.5)/m
end


function dcPlayTickSound()
	PlaySound("igMainMenuOptionCheckBoxOn")
end


function dcTextField(frame,id,label,size,anchor,x,y,r,g,b)
	-- Some fonts for default frames are: GameFontHighlight or GameFontNormalLarge
	local txt = frame:CreateFontString(id, "ARTWORK", "GameFontNormalLarge");
	txt:SetPoint(anchor, x, y);
	txt:SetText(label);
	txt:SetTextColor(r, g, b)
	txt:SetFont("Fonts\\FRIZQT__.TTF", size, "OUTLINE");
	return txt
end


function dcCheckBox(frame,id,label,size,anchor,x,y,r,g,b)
	local checkbox = CreateFrame("CheckButton", id, frame);
	checkbox:SetWidth(26);
	checkbox:SetHeight(26);
	checkbox:SetPoint(anchor, x, y);
	
	checkbox:SetHitRectInsets(0, -200, 0, 0);
	checkbox:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up");
	checkbox:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down");
	checkbox:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight");
	checkbox:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check");
	
	local description = checkbox:CreateFontString(id.."Label", "ARTWORK", "GameFontHighlight");
	description:SetPoint("LEFT", checkbox, "RIGHT", 0, 1);
	description:SetText(label);
	description:SetTextColor(r, g, b);
	description:SetFont("Fonts\\FRIZQT__.TTF", size, "OUTLINE");
	
	
	checkbox:SetScript("OnClick", function(frame)
		local tick = frame:GetChecked();
		if tick then
			dcPlayTickSound();
			checkBoxEvent(id,1);
		else
			dcPlayTickSound();
			checkBoxEvent(id,0);
		end
	end)	
	
	return checkbox;
	
end
-- #######################################################




function dcHSlider(frame,id,x,y,min,max,default,label,size,r,g,b)

	local MySlider = CreateFrame("Slider", id, frame, "OptionsSliderTemplate");
	MySlider:ClearAllPoints();
	MySlider:SetWidth(size);
	MySlider:SetHeight(20);
	MySlider:SetOrientation('HORIZONTAL');
	MySlider:SetPoint("TOPLEFT", x, y);
	MySlider:SetMinMaxValues(min,max);
	MySlider:SetValue(default);
	--MySlider.tooltipText = 'This is the Tooltip hint'
	getglobal(MySlider:GetName() .. 'Low'):SetText(min);
	getglobal(MySlider:GetName() .. 'High'):SetText(max);
	getglobal(MySlider:GetName() .. 'Text'):SetText(string.format("%.2f",default));
	MySlider:Show();
	MySlider:SetScript("OnValueChanged", function(self, value)
      local val = string.format("%.2f",value);
      getglobal(MySlider:GetName() .. 'Text'):SetText(val);
      sliderEvent(id,val);
	end)
	local sliderLabel = dcTextField(MySlider,"DcoordsConfigTitle1",label,11,"CENTER",0,-20,1,1,1);
	
	return MySlider;
	
end