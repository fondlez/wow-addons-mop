-- #######################################################
function setupSlashCommands()
	-- Setup slash commands
	SlashCmdList["DCoordsCOMMAND"] = DMCoordsSlashFunction;
	SLASH_DCoordsCOMMAND1 = "/dc";
end
-- #######################################################






-- #######################################################
-- Slash commands
-- #######################################################
function DMCoordsSlashFunction(msg)
	local DCoordsFrame = _G["DCoords"];


	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	if (msg == nil or msg == "" or string.find(msg, "help") ~= nil) then
		trace("DCoords commands:");
		trace("  /DC menu - show menu");
		trace("  /DC reset - reset positions");
		trace("  /DC show - show addon");
		trace("  /DC hide - hide addon");
	end
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 




	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	strtosearch = string.find(msg,"reset");
	if (strtosearch ~= nil) then
		trace("DCoords attempting to reset positions...");
		
		-- Ensure frame is visible
		DCoordsFrame:SetAlpha(1);
		DCoordsFrame:ClearAllPoints();
		DCoordsFrame:SetPoint("CENTER", "UIParent", "CENTER", 0, 0);
		DCoordsFrame:Show();
	end
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	
	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	strtosearch = string.find(msg,"menu");
	if (strtosearch ~= nil) then
		DCoordsMenu:Show();
	end
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	
	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	strtosearch = string.find(msg,"hide");
	if (strtosearch ~= nil) then
		DCoordsFrame:Hide();
	end
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	
	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	strtosearch = string.find(msg,"show");
	if (strtosearch ~= nil) then
		DCoordsFrame:Show();
	end
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	
	
	
	
	
	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	strtosearch = string.find(msg,"setalpha:");
	if (strtosearch ~= nil) then
		local v1,v2 = strsplit(":",msg);
		local s = tonumber(v2);
		if (s ~= null) then
			DCoordsAlpha = (s/100);
			trace("DCoords: Setting [Alpha] to ["..DCoordsAlpha..")");
			DCoordsFrame:SetAlpha(DCoordsAlpha);
		end
	end	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 



	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	strtosearch = string.find(msg,"framealpha:");
	if (strtosearch ~= nil) then
		local v1,v2 = strsplit(":",msg);
		local s = tonumber(v2);
		
		--GetBackdropColor
		--frame:SetBackdropColor(red,green,blue,alpha);
		
		local bgr,bgg,bgb,bga = DCoordsFrame:GetBackdropColor();
		--trace("bgr:"..bgr);		--trace("bgg:"..bgg);
		--trace("bgb:"..bgb);		--trace("bga:"..bga);
		
		if (s ~= null) then
			DCoordsFrameAlpha = (s/100);
			trace("DCoords: Setting frame alphas to ["..DCoordsFrameAlpha..")");
			DCoordsFrame:SetBackdropColor(1,1,1,DCoordsFrameAlpha);
			DCoordsFrame:SetBackdropBorderColor(1,1,1,DCoordsFrameAlpha);
		end
	end	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 

	
	
	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	--someText:SetTextColor(red,green,blue,alpha)
	--http://www.wowwiki.com/API_FontString_SetTextColor
	
	strtosearch = string.find(msg,"textcolor:");
	if (strtosearch ~= nil) then
		local v1,v2 = strsplit(":",msg);
		
		trace("col str = " .. v2);
		local rr,gg,bb,aa = strsplit(",",v2);
		
		if (rr ~= null) then
			trace("Found RR:" .. rr);
			if (gg ~= null) then
				trace("Found GG:" .. gg);
				if (bb ~= null) then
					trace("Found BB:" .. bb);
					if (aa ~= null) then
						trace("Found AA:" .. aa);
					
						r = tonumber(rr);
						g = tonumber(gg);
						b = tonumber(bb);
						a = tonumber(aa);
					
						trace("DCoords: Setting text color to R:"..r.." G:"..g.." B:"..b.." A:"..a);
						DCoordsLocationText:SetTextColor(r,g,b,a);
					end
				end
			end
		end
	end	
	-- | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | | 
	
	



end
-- #######################################################
