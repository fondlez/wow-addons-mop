BINDING_HEADER_DEJAMARK = "DejaMark"
_G["BINDING_NAME_CLICK DejaMark:LeftButton"] = "Show Markers(Hold)"

local DejaMarkFrame=CreateFrame("Frame","MyParent",UIParent)
	DejaMarkFrame:SetSize(100,100)
	DejaMarkFrame:SetPoint("CENTER")

local t=DejaMarkFrame:CreateTexture(nil,"ARTWORK")
	t:SetAllPoints(DejaMarkFrame)
	t:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")

	DejaMarkFrame:Hide()



--Star Marks Raid Marker 1 World Marker 5
local WMStar = CreateFrame("BUTTON", "WorldMarker5Star",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMStar:SetSize(32,32)
     	WMStar:SetPoint("TOPLEFT")
     	WMStar:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_1.png")
	WMStar:SetAlpha(0.5)
    	WMStar:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMStar:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMStar:RegisterForClicks("AnyUp")
	
	WMStar:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMStar:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",1) end\n/wm [btn:2] 5')



--Circle Marks Raid Marker 2 NO World Marker
local WMCircle = CreateFrame("BUTTON", "RaidMarker2Circle",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMCircle:SetSize(32,32)
     	WMCircle:SetPoint("TOP")
     	WMCircle:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_2.png")
	WMCircle:SetAlpha(0.5)
    	WMCircle:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMCircle:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMCircle:RegisterForClicks("AnyUp")
	
	WMCircle:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMCircle:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",2) end\n/wm [btn:2] 0')



--Diamond Marks Raid Marker 3 World Marker 3
local WMDiamond = CreateFrame("BUTTON", "WorldMarker3Diamond",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMDiamond:SetSize(32,32)
     	WMDiamond:SetPoint("TOPRIGHT")
     	WMDiamond:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_3.png")
	WMDiamond:SetAlpha(0.5)
    	WMDiamond:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMDiamond:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMDiamond:RegisterForClicks("AnyUp")
	
	WMDiamond:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMDiamond:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",3) end\n/wm [btn:2] 3')



--Triangle Marks Raid Marker 4 World Marker 2
local WMTriangle = CreateFrame("BUTTON", "WorldMarker2Triangle",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMTriangle:SetSize(32,32)
     	WMTriangle:SetPoint("LEFT")
     	WMTriangle:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_4.png")
	WMTriangle:SetAlpha(0.5)
    	WMTriangle:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMTriangle:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMTriangle:RegisterForClicks("AnyUp")
	
	WMTriangle:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMTriangle:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",4) end\n/wm [btn:2] 2')



--Skull Marks Raid Marker 8 NO World Marker
local WMSkull = CreateFrame("BUTTON", "RaidMarker8Skull",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMSkull:SetSize(32,32)
     	WMSkull:SetPoint("CENTER")
     	WMSkull:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_8.png")
	WMSkull:SetAlpha(0.5)
    	WMSkull:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMSkull:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMSkull:RegisterForClicks("AnyUp")
	
	WMSkull:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMSkull:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",8) end\n/wm [btn:2] 0')



--Square Marks Raid Marker 6 World Marker 1
local WMSquare = CreateFrame("BUTTON", "WorldMarker1Square",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMSquare:SetSize(32,32)
     	WMSquare:SetPoint("RIGHT")
     	WMSquare:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_6.png")
	WMSquare:SetAlpha(0.5)
    	WMSquare:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMSquare:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMSquare:RegisterForClicks("AnyUp")
	
	WMSquare:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMSquare:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",6) end\n/wm [btn:2] 1')



--Cross Marks Raid Marker 7 World Marker 4
local WMCross = CreateFrame("BUTTON", "WorldMarker4Cross",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMCross:SetSize(32,32)
     	WMCross:SetPoint("BOTTOMLEFT")
     	WMCross:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_7.png")
	WMCross:SetAlpha(0.5)
    	WMCross:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMCross:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMCross:RegisterForClicks("AnyUp")
	
	WMCross:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMCross:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",7) end\n/wm [btn:2] 4')



--Moon Marks Raid Marker 5 NO World Marker
local WMMoon = CreateFrame("BUTTON", "RaidMarker5Moon",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMMoon:SetSize(32,32)
     	WMMoon:SetPoint("BOTTOM")
     	WMMoon:SetNormalTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_5.png")
	WMMoon:SetAlpha(0.5)
    	WMMoon:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMMoon:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMMoon:RegisterForClicks("AnyUp")
	
	WMMoon:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMMoon:SetAttribute("macrotext",'/run if SecureCmdOptionParse("[btn:1]") then SetRaidTargetIcon("target",5) end\n/wm [btn:2] 0')



--Clear Marks Raid Marker 0 World Marker 6
local WMClear = CreateFrame("BUTTON", "WorldMarker6Clear",DejaMarkFrame, "SecureActionButtonTemplate")
     	WMClear:SetSize(32,32)
     	WMClear:SetPoint("BOTTOMRIGHT")
     	WMClear:SetNormalTexture("Interface\\BUTTONS\\UI-GroupLoot-Pass-Up")
	WMClear:SetAlpha(0.5)
    	WMClear:SetScript("OnEnter", function(self)
		self:SetAlpha(1)
	end)
    	WMClear:SetScript("OnLeave", function(self)
		self:SetAlpha(0.5)
	end)
	WMClear:RegisterForClicks("AnyUp")
	
	WMClear:SetAttribute("type","macro") -- /tm on left click, /wm on right click
	WMClear:SetAttribute("macrotext","/tm [btn:1] 0\n/cwm [btn:2] all")



-- toggle frame, has no visible parts. exists as a place to accept a click run a snippet
local toggleframe = CreateFrame("Button","DejaMark",UIParent,"SecureHandlerClickTemplate")
	toggleframe:RegisterForClicks("AnyUp", "AnyDown")
	toggleframe:SetFrameRef("ParentFrame",DejaMarkFrame)
	toggleframe:SetAttribute("_onclick",[[
	ParentFrame = self:GetFrameRef("ParentFrame")
  	if down then
		ParentFrame:SetPoint("CENTER","$cursor")
    		ParentFrame:Show()
  	else
    		ParentFrame:Hide()
  	end
]])