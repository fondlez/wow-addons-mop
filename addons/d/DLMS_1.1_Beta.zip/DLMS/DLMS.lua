local CreateFrame = CreateFrame
local CreateFontString = CreateFontString
local next,print,tinsert,gsub,strsub = next,print,tinsert,gsub,strsub

-- Saved Variables --
svdDB = {}
svOptionsDB = {}
-----------------------------

local dDBFrame = CreateFrame("Frame", nil, UIParent)

dDBFrame:RegisterEvent("ADDON_LOADED")
dDBFrame:RegisterEvent("PLAYER_LOGOUT")
dDBFrame:RegisterEvent("LOOT_OPENED")
dDBFrame:RegisterEvent("MERCHANT_SHOW")
dDBFrame:RegisterEvent("START_LOOT_ROLL")
dDBFrame:RegisterEvent("CONFIRM_LOOT_ROLL")

--local enabled = true
local default = true
local isButtonOne = true
local IsEmpty = false
local newItem = false
local BeingRolledOn = false
local AutoRoll = true

local RollID = nil
local Roll   = 2


-- Working Tables --
local OptionsDB = {}
local dDB = {}
local bNameTable = {}
local bpNameTable = {}
local bpcbNameTable = {}
local CatLinkTable = {}
local notLooted = {}
local ItemRollIDs = {}
-------------------------------------

-- Storage for option defaults --
local oDefaultsDB = {
	enabled = true,
	LBC = false,
	LBV = false,
	LBQ = false,
	ASJ = true,
	ARG = true,
	LAG = true,
	ARL = false,
	ARB = false,
	UWM = false,
	KLO = false,
}
---------------------------------
-- Static Labels --
local Static_Label_Table = {
	["DLMSPanel_Title_Label"] = {
		["Name"]					= "Title",
		["Text_Size"] 				= 24,
		["R"]						= 1.0,
		["G"]						= 1.0,
		["B"]						= 0.0,
		["A"]						= 0.8,
		["Point"]					= "TOPLEFT",
		["x"]						= 10,
		["y"]						= -10,
		["Text"]					= "Dynamic Loot Management System",
	},
	["DLMSPanel_Version_Label"] = {
		["Name"]					= "Version",
		["Text_Size"] 				= 13,
		["R"]						= 0.0,
		["G"]						= 0.6,
		["B"]						= 1.0,
		["A"]						= 0.8,
		["Point"]					= "TOPLEFT",
		["x"]						= 35,
		["y"]						= -33,
		["Text"]					= "Version 1.0 Beta by \124cFFFF7D0AAuz\124r (Eitrigg)",
	},
	["DLMSPanel_Options_Label"] = {
		["Name"]					= "Options",
		["Text_Size"] 				= 14,
		["R"]						= 1.0,
		["G"]						= 1.0,
		["B"]						= 0.0,
		["A"]						= 0.8,
		["Point"]					= "TOPLEFT",
		["x"]						= 16,
		["y"]						= -60,
		["Text"]					= "General Options",
	},	
}

-- Static Layout Panels --
local Static_Panel_Table = {
	["GO_Panel"] = {
		["Name"]					= "gOptions",
		["Point"]					= "TOPLEFT",
		["x"]						= 10,
		["y"]						= -76,
		["w"]						= 602,
		["h"]						= 143,
	},
	["LBC_Panel"] = {
		["Name"]					= "LBC",
		["Point"]					= "BOTTOMLEFT",
		["x"]						= 10,
		["y"]						= 10,
		["w"]						= 602,
		["h"]						= 290,
	},	
}

-- Strings colored by quality color, so we don't ahve to keep typing them --
local QualityStrings = {
	[0] = " \124cFF555555Disabled\124r",
	[1] = " \124cFF9d9d9dJunk\124r",
	[2] = " \124cFFffffffCommon\124r",
	[3] = " \124cFF1eff00Uncommon\124r",
	[4] = " \124cFF0070ddRare\124r",
	[5] = " \124cFFa335eeEpic\124r",
	[6] = " \124cFFff8000Legendary\124r",
}

-- Backdrop table for Static Options Panels ----
local backdrop = {
  bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",  
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true,
  tileSize = 16,
  edgeSize = 16,
  insets = { left = 3, right = 3, top = 5, bottom = 3 }
}
------------------------------------------
-- divider backdrop for catagory panel dividers --
local divider = {
  bgFile = "Interface\\ChatFrame\\ChatFrameBackground",  
  edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
  tile = true,
  tileSize = 1,
  edgeSize = 2,
  insets = { left = 1, right = 1, top = 1, bottom = 1 }
}

-- Giving credit to the Author of this function for alphabetically sorting non-numeric tables
-- not sure who the author is but, it's awesome!
-- Found here: http://www.wowwiki.com/API_sort : referencing http://lua-users.org/wiki/TableLibraryTutorial @ lua-users.org
function pairsByKeys (t, f)
	local a = {}
		for n in pairs(t) do table.insert(a, n) end
		table.sort(a, f)
		local i = 0      -- iterator variable
		local iter = function ()   -- iterator function
			i = i + 1
			if a[i] == nil then return nil
			else return a[i], t[a[i]]
			end
		end
	return iter
end

-- list our DB... for testing purposes --
local function ListDB(tbl)
	for k,v in pairsByKeys(tbl) do
		if(type(tbl[k]) == "table") then
			print("- "..tostring(k))
			for k2,v2 in pairsByKeys(tbl[k]) do
				print("-- "..k2.." = "..tostring(v2))
			end
		else 
			print(k.." = "..tostring(v))
		end
	end
end

-- General Label Creator --
local function CreateLabel(parent,name,tS,r,b,g,a,p,x,y,txt)
	
	local fs

		-- CheckButtons/Buttons have an internal fontstring object... use it, don't create a new one...
	if(parent:GetObjectType() == "CheckButton") then 
		--print("Making checkbox...")
		fs = _G[parent:GetName().."Text"]
	else
		fs = parent:CreateFontString(name.."_Label")
	end
	--print(parent:GetObjectType())
	--print("Button Panel Label Name: "..fs:GetName())
	fs:SetFont("Fonts\\ARIALN.TTF", tS, nil)
	fs:SetTextColor(r,b,g,a)
	fs:SetPoint(p,x,y)
	fs:SetText(txt)
	fs:Show()
	
end

local function CreatePanelDivider(parent,name,p,x,y,w,h)
	local f = CreateFrame("Frame", name, parent)
	f:SetPoint(p,x,y)
	f:SetSize(w,h)
	f:SetAlpha(0.3)
	f:SetBackdrop(divider)
	f:Show()
end

-- Make our static labels... 
local function Generate_Static_Labels(parent)
	local tmp = Static_Label_Table
	for k in pairs(tmp) do
		local p,n,ts  = parent,tmp[k]["Name"],tmp[k]["Text_Size"]
		local r,g,b,a = tmp[k]["R"],tmp[k]["G"],tmp[k]["B"],tmp[k]["A"]
		local point,x,y,t = tmp[k]["Point"],tmp[k]["x"],tmp[k]["y"],tmp[k]["Text"]
		CreateLabel(p,n,ts,r,g,b,a,point,x,y,t)
	end
	wipe(tmp)
end

-- Make our static panels...
local function Generate_Static_Panels(parent)
	local tmp = Static_Panel_Table
	for k in pairs(tmp) do
		local f = CreateFrame("Frame",tmp[k]["Name"].."_Panel", parent)
		f:SetPoint(tmp[k]["Point"], tmp[k]["x"], tmp[k]["y"])
		f:SetWidth(tmp[k]["w"])
		f:SetHeight(tmp[k]["h"])
		f:SetBackdrop(backdrop)
		f:Show()
	end
	wipe(tmp)
end

-- General Checkbox factory function...
local function MakeCheckBox(name,parent,txt,p,x,y,tooltip)
	local cb = CreateFrame("CheckButton", name, parent, "ChatConfigCheckButtonTemplate")
	CreateLabel(cb, name, 15, 1.0, 1.0, 0.0, 0.8, "TOPLEFT", 23, -5, txt)
	if(tooltip) then cb.tooltip = tooltip end
	cb:SetPoint(p,x,y)
	cb:SetHitRectInsets(0,0,0,0) -- Set so only the actual checkbox gets mouse input...
								 --	keeps text labels from looking as though they are being pressed
								 -- and makes layout easier as they don't overlap.. default for right side is (-)145 px.. 
								 -- which can be frustrating...
end



local function CreateCBHandlers(cb,cat,type)
	_G[cb]:SetScript("OnClick",
		function()
			dDB[cat][type] = _G[cb]:GetChecked() and true or false
			print(dDB[cat][type] and "Looting: "..cat.." - "..type or "Not looting: "..cat.." - "..type)
		end
	)
	
end

local cb_count = 1
local cb_pos_x = 8
local cb_pos_y = -45
local cb_x_inc = 148
local cb_y_inc = 30

local function CreateCatagoryCheckboxes(f,bname)
	for k,v in pairsByKeys(CatLinkTable) do
		if(k == bname) then
			for k2,v2 in pairsByKeys(dDB[k]) do
				
				local bpcbName = f:GetName().."_"..k2.."_checkbox"
				
				tinsert(bpcbNameTable, bpcbName) -- saving a reference to my checkbox names incase I need them...
				
				MakeCheckBox(bpcbName, f, k2, "TOPLEFT", cb_pos_x, cb_pos_y, false)
				
				_G[bpcbName]:SetChecked(dDB[bname][k2])
				
				if(OptionsDB["LBC"]) then _G[bpcbName]:Enable() else _G[bpcbName]:Disable(); _G[bpcbName.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
				
				CreateCBHandlers(bpcbName,bname,k2)
				
				cb_pos_x = cb_pos_x + cb_x_inc
				cb_count = cb_count + 1
				
				if(cb_count == 5) then
					cb_count = 1
					cb_pos_x = 8
					cb_pos_y = cb_pos_y - cb_y_inc
				end
				
			end
		end
	end
	
	cb_count = 1
	cb_pos_x = 8
	cb_pos_y = -45
	
end

-- attempting to make our panels Show() or Hide() depending on which button was pressed... our "Tabs" :P
local function CreateHandlers(bpName,b,f)
	b:SetScript("OnClick",
		function()
			if(not f:IsVisible()) then f:Show() end
			for k,v in pairs(bpNameTable) do
				if(v ~= bpName) then
					_G[v]:Hide()
				end
			end
		end
	)
end

-- Make our catagory panels to go with our catagory buttons
local function MakeButtonPanels(b, bname)
	local bpName = b:GetName().."_panel"
	tinsert(bpNameTable, bpName) -- May be unnessicary since I created the table below but... things are working right now.. will try to clean it up later..
	CatLinkTable[bname] = bpName -- Saving a link between catagory button and its associated panel
	local f = CreateFrame("Frame", bpName, LBC_Panel)
	f:SetAllPoints()
	CreateLabel(f, bpName, 20, 1.0, 1.0, 0.0, 0.8, "TOPLEFT", 10, -10, bname.." Item Types")
	
	if(isButtonOne) then
		f:Show()
		isButtonOne = false
	else
		f:Hide()
	end
	
	CreateHandlers(bpName,b,f) -- hmm.. I feel like Italian... where does this noodle go??... oh, wait.. I'm so confused...
	if(next(dDB[bname]) == nil) then
		CreateLabel(f, bpName.."_Empty_Label", 24, 1.0, 1.0, 0.0, 0.8, "CENTER", 10, -10, "Nothing under "..bname.." yet, keep looting!")
	else
		CreateCatagoryCheckboxes(f,bname)
	end
end

local b_count = 1
local b_pos_x = 11
local b_pos_y = 325
local b_x_inc = 100
local b_y_inc = 25

-- Generate our buttons -- 
local function MakeButtons(parent, bname)
	local button_name = bname.."_button"
	tinsert(bNameTable, button_name)
	local b = CreateFrame("Button", button_name, parent, "UIPanelButtonTemplate")
	b:SetWidth(100)
	b:SetHeight(25)
	local fs = _G[b:GetName().."Text"]
	fs:SetFont("Fonts\\ARIALN.TTF", 14, nil)
	fs:SetTextColor(1.0,1.0,0.0,0.8)
	
	b:SetPoint("BOTTOMLEFT", b_pos_x, b_pos_y)
	
	b_pos_x = b_pos_x + b_x_inc
	b_count = b_count + 1

	if(b_count == 7) then
		b_count = 1
		b_pos_x = 11
		b_pos_y = b_pos_y - b_y_inc
	end

	b:SetText(bname)
	b:RegisterForClicks("AnyUp")
	if(OptionsDB["LBC"]) then _G[button_name]:Enable() else _G[button_name]:Disable(); _G[button_name.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
	MakeButtonPanels(b, bname)
end

local function GenerateCatagories(parent)
	if(IsEmpty) then
		CreateLabel(LBC_Panel, "No_Catagory_Label", 18, 1.0, 1.0, 0.0, 0.8, "CENTER", 0, 0, "Oops! No Catagories yet... Go loot something!")
	else
		for k in pairsByKeys(dDB) do
			if(type(dDB[k]) == "table") then
				MakeButtons(parent, tostring(k))
			end
		end
	end
end

local function de_select_all(switch)

	for k,v in pairs(bpNameTable) do
		if(_G[v]:IsVisible()) then
			for k2,v2 in pairs(bpcbNameTable) do
				if(strfind(v2,v) ~= nil) then
					local checkbox = _G[v2]
					local checked = checkbox:GetChecked()
					if(switch == "select" and not checked) then 
						checkbox:Click("LeftButton", false)
					else
						if(switch == "deselect" and checked) then
							checkbox:Click("LeftButton", false)
						end
					end
				end
			end
		end
	end

end

-- Build our options --
local function DLMSBuildOptions()

	-- build options panel...
	
	local DLMS_Options = {}
	DLMS_Options.panel = CreateFrame( "Frame", "DLMS_Options_Panel", UIParent )
	
	local DLMSPanel = DLMS_Options.panel
	
	Generate_Static_Labels(DLMSPanel)
	Generate_Static_Panels(DLMSPanel)
	CreatePanelDivider(LBC_Panel, "LBC_Divider1", "TOPLEFT", 10, -32, 582, 4)
	CreatePanelDivider(LBC_Panel, "LBC_Divider2", "BOTTOMLEFT", 10, 32, 582, 4)
	
	-- Loot all and go! checkbox --
	MakeCheckBox("LAG_checkbox",DLMSPanel,"Loot All and GO!","TOPRIGHT",-165,-15,"Loot EVERYTHING and GO!")
	
	LAG_checkbox:SetSize(56,56)
	
	LAG_checkboxText:SetFont("Fonts\\ARIALN.TTF", 24, nil)
	LAG_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
	LAG_checkboxText:SetPoint("TOPLEFT", 52, -15)
		
	MakeCheckBox("LBC_checkbox",LBC_Panel, "Loot by Catagory", "TOPRIGHT", -116, -7, false)
	MakeCheckBox("DIS_checkbox",gOptions_Panel, "Disable DLMS", "TOPLEFT", 10, -5, false)
	MakeCheckBox("MSG_checkbox",gOptions_Panel, "Use WoW Messages", "TOPLEFT", 130, -5, false)
	MakeCheckBox("KLO_checkbox",gOptions_Panel, "Keep Loot Window Open", "TOPLEFT", 10, -30, false)
	
	MakeCheckBox("ARL_checkbox",gOptions_Panel, "Auto Roll Greed On \124cFF1eff00Uncommon\124r", "TOPRIGHT", -200, -30, "Will auto roll greed on all \124cFF1eff00Uncommon\124r items.")
	MakeCheckBox("ARB_checkbox",ARL_checkbox, "Roll Greed on \124cFF0070ddRare\124r", "TOPLEFT", 20, -20, "Will auto roll greed on all \124cFF0070ddRare\124r items.")
	MakeCheckBox("ARP_checkbox",ARL_checkbox, "Auto Pass", "TOPLEFT", 140, -20, "Will auto pass on all loot rolls.")
	
	MakeCheckBox("ARG_checkbox",gOptions_Panel, "Auto Repair", "TOPRIGHT", -200, -5, false)
	MakeCheckBox("ASJ_checkbox",gOptions_Panel, "Auto Sell Junk", "TOPRIGHT", -96, -5, "Will auto sell all sellable grey items.")
	
	ARB_checkbox:SetSize(16,16)
	ARB_checkboxText:SetFont("Fonts\\ARIALN.TTF", 12, nil)
	ARB_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
	ARB_checkboxText:SetPoint("TOPLEFT", 17, -2)
	
	ARP_checkbox:SetSize(16,16)
	ARP_checkboxText:SetFont("Fonts\\ARIALN.TTF", 12, nil)
	ARP_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
	ARP_checkboxText:SetPoint("TOPLEFT", 17, -2)	
		
-- Making our Select and Deselect All buttons --

	local select_all_button = CreateFrame("Button", "select_all", LBC_Panel, "UIPanelButtonTemplate")
	select_all_button:SetWidth(100)
	select_all_button:SetHeight(25)
	select_all_button:SetPoint("BOTTOMLEFT", 8, 6)
	
	
	select_allText:SetFont("Fonts\\ARIALN.TTF", 14, nil)
	select_allText:SetTextColor(1.0,1.0,0.0,0.8)
	select_allText:SetText("Select All")
	
	if(OptionsDB["LBC"]) then select_all_button:Enable() else select_all_button:Disable(); select_allText:SetTextColor(0.5,0.5,0.5,0.8); end
	
	
	local deselect_all_button = CreateFrame("Button", "deselect_all", LBC_Panel, "UIPanelButtonTemplate")
	deselect_all_button:SetWidth(100)
	deselect_all_button:SetHeight(25)
	deselect_all_button:SetPoint("BOTTOMLEFT", 108, 6)

	
	deselect_allText:SetFont("Fonts\\ARIALN.TTF", 14, nil)
	deselect_allText:SetTextColor(1.0,1.0,0.0,0.8)
	deselect_allText:SetText("Deselect All")
	
	if(OptionsDB["LBC"]) then deselect_all_button:Enable() else deselect_all_button:Disable(); deselect_allText:SetTextColor(0.5,0.5,0.5,0.8); end
	
-- END ------------------------------------------------------------------------------

-- Value Slider --
	local lbvSlider = CreateFrame("Slider", "LBV_Slider", gOptions_Panel, "OptionsSliderTemplate")
		
	CreateLabel(gOptions_Panel, "ValueHeader", 14, 1.0, 1.0, 0.0, 0.8, "TOPLEFT", 15, -68, "Loot by Value (0 disables)")
	
	 _G[lbvSlider:GetName().."Low"]:SetText("") 
	 _G[lbvSlider:GetName().."High"]:SetText("")
	 _G[lbvSlider:GetName().."Text"]:SetText("")
		
	lbvSlider:SetWidth(582)
	lbvSlider:SetMinMaxValues(0, 10000)
		
	lbvSlider:SetValue(OptionsDB["LBV"] and OptionsDB["LBV"] or 0)
	lbvSlider:SetPoint("TOPLEFT", 10, -83)
	CreateLabel(gOptions_Panel, "Value", 14, 1.0, 1.0, 0.0, 0.8, "TOPRIGHT", -15, -73, OptionsDB["LBV"] and GetCoinTextureString(OptionsDB["LBV"],10) or QualityStrings[0])
	lbvSlider:Show()
 -- END --

-- Quality Slider --
	local lbqSlider = CreateFrame("Slider", "LBQ_Slider", gOptions_Panel, "OptionsSliderTemplate")
		
	CreateLabel(gOptions_Panel, "QualityHeader", 14, 1.0, 1.0, 0.0, 0.8, "TOPLEFT", 15, -100, "Loot by Item Quality")
	
	 _G[lbqSlider:GetName().."Low"]:SetText("   Disable") 
	 _G[lbqSlider:GetName().."High"]:SetText("")
	 _G[lbqSlider:GetName().."Text"]:SetText("")
		
	lbqSlider:SetWidth(582)
	lbqSlider:SetMinMaxValues(0, 4)
		
	-- work around to fix bug where label would not show without actually clicking the slider in some way... 
	--------------------------------------------------------------
	local lbQuality = OptionsDB["LBQ"] and OptionsDB["LBQ"]+1 or 0	
	lbqSlider:SetValue(lbQuality)
	local tmpstr = QualityStrings[lbQuality]
	--------------------------------------------------------------
		
	CreateLabel(gOptions_Panel, "Quality", 14, 1.0, 1.0, 0.0, 0.8, "TOPRIGHT", -15, -104, tmpstr)
		
	lbqSlider:SetPoint("TOPLEFT", 10, -114)
	lbqSlider:Show()
-- END --

	if(LAG_checkbox:GetChecked()) then lbvSlider:Disable() else lbvSlider:Enable() end
	if(LAG_checkbox:GetChecked()) then lbqSlider:Disable() else lbqSlider:Enable() end

-- Catagory Button "Tab" Panel ----------
	GenerateCatagories(DLMSPanel)
---------------------------------

	LAG_checkbox:SetChecked(OptionsDB["LAG"])
	LBC_checkbox:SetChecked(OptionsDB["LBC"])
	ARG_checkbox:SetChecked(OptionsDB["ARG"])
	ASJ_checkbox:SetChecked(OptionsDB["ASJ"])
	KLO_checkbox:SetChecked(OptionsDB["KLO"])
	

-- Set Initial Addon load states for catagory elements, etc... --

	local aRoll = OptionsDB["ARL"]
	ARB_checkbox:SetChecked(OptionsDB["ARB"])
	
	if(aRoll ~= false) then
		ARL_checkbox:SetChecked(true)
		if(aRoll == 0) then
			ARL_checkbox:Disable()
			ARB_checkbox:Disable()
			ARP_checkbox:SetChecked(true)
		elseif(aRoll == 3) then
			ARB_checkbox:SetChecked(true)
		end
	else
		ARB_checkbox:Disable()
		ARP_checkbox:Disable()
	end

	-- if our DB is empty, go ahead and setup to Loot All so we can build our catagory DB...
	if(IsEmpty) then
		OptionsDB["LAG"] = true
		LAG_checkbox:SetChecked(true)
	end
	-- end --
		if(OptionsDB["LAG"]) then
			OptionsDB["LBC"] = false
			LBC_checkbox:SetChecked(false)
			LBC_checkbox:Disable()
			lbvSlider:Disable()
			lbqSlider:Disable()
			
			LBC_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
			ValueHeader_Label:SetTextColor(0.5,0.5,0.5,0.8)
			QualityHeader_Label:SetTextColor(0.5,0.5,0.5,0.8)
			Value_Label:Hide()
			Quality_Label:Hide()
		else
			if(not IsEmpty) then
				LBC_checkbox:Enable()
				LBC_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
			end
			ValueHeader_Label:SetTextColor(1.0,1.0,0.0,0.8)
			QualityHeader_Label:SetTextColor(1.0,1.0,0.0,0.8)
			lbvSlider:Enable()
			lbqSlider:Enable()
			Value_Label:Show()
			Quality_Label:Show()
		end
		
		if(OptionsDB["LBC"]) then 
			select_all_button:Enable(); 
			deselect_all_button:Enable();
			select_allText:SetTextColor(1.0,1.0,0.0,0.8);
			deselect_allText:SetTextColor(1.0,1.0,0.0,0.8); 
			
			for k,v in pairs(bNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
			for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(1.0,1.0,0.0,0.8); end
			for k,v in pairs(bpcbNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
		else 
			select_all_button:Disable(); 
			deselect_all_button:Disable();
			select_allText:SetTextColor(0.5,0.5,0.5,0.8);  
			deselect_allText:SetTextColor(0.5,0.5,0.5,0.8);

			for k,v in pairs(bNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
			for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(0.5,0.5,0.5,0.8); end
			for k,v in pairs(bpcbNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
		end
-- END --

	-- Event Handlers --
	select_all_button:SetScript("OnClick",
		function()
			de_select_all("select")
		end
	)

	deselect_all_button:SetScript("OnClick",
		function()
			de_select_all("deselect")
		end
	)
	
	MSG_checkbox:SetScript("OnClick",
		function()
			OptionsDB["UWM"] = MSG_checkbox:GetChecked() and true or false
			print(OptionsDB["UWM"] and "\124cFFAA00FFDLMS:\124r is using WoW messages.." or "\124cFFAA00FFDLMS:\124r is using DLMS messages.")
		end
	)
	
	DIS_checkbox:SetScript("OnClick",
		function()
			OptionsDB["enabled"] = (DIS_checkbox:GetChecked() == nil) and true or false
			print(OptionsDB["enabled"] and "\124cFFAA00FFDLMS:\124r Is \124cFFffff00enabled\124r." or "\124cFFAA00FFDLMS:\124r Is \124cFFffff00disabled\124r.")
			
			if(OptionsDB["enabled"]) then
				if(not IsEmpty) then
					LBC_checkbox:Enable()				
					LBC_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				end
				LAG_checkbox:Enable()
				ARG_checkbox:Enable()
				ASJ_checkbox:Enable()
				ARL_checkbox:Enable()
				ARP_checkbox:Enable()
				MSG_checkbox:Enable()
				
				ValueHeader_Label:SetTextColor(1.0,1.0,0.0,0.8)
				QualityHeader_Label:SetTextColor(1.0,1.0,0.0,0.8)
				
				LAG_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				ARG_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				ASJ_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				ARL_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				ARP_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				MSG_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				
				lbvSlider:Enable()
				lbqSlider:Enable()
				Value_Label:Show()
				Quality_Label:Show()
			
				if(OptionsDB["LBC"]) then 
					select_all_button:Enable(); 
					deselect_all_button:Enable();
					select_allText:SetTextColor(1.0,1.0,0.0,0.8);
					deselect_allText:SetTextColor(1.0,1.0,0.0,0.8); 
					
					for k,v in pairs(bNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
					for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(1.0,1.0,0.0,0.8); end
					for k,v in pairs(bpcbNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
				end
				
			else
				LAG_checkbox:Disable()
				ARG_checkbox:Disable()
				ASJ_checkbox:Disable()
				ARL_checkbox:Disable()
				ARP_checkbox:Disable()
				MSG_checkbox:Disable()

				LBC_checkbox:Disable()
				lbvSlider:Disable()
				lbqSlider:Disable()
				
				LBC_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				ValueHeader_Label:SetTextColor(0.5,0.5,0.5,0.8)
				QualityHeader_Label:SetTextColor(0.5,0.5,0.5,0.8)

				LAG_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				ARG_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				ASJ_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				ARL_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				ARP_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				MSG_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)

				Value_Label:Hide()
				Quality_Label:Hide()
			
				select_all_button:Disable(); 
				deselect_all_button:Disable();
				select_allText:SetTextColor(0.5,0.5,0.5,0.8);  
				deselect_allText:SetTextColor(0.5,0.5,0.5,0.8);

				for k,v in pairs(bNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
				for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(0.5,0.5,0.5,0.8); end
				for k,v in pairs(bpcbNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
			end
		end
	)
	
	LAG_checkbox:SetScript("OnClick", 
		function()
			
			OptionsDB["LAG"] = LAG_checkbox:GetChecked() and true or false
			print(OptionsDB["LAG"] and "\124cFFAA00FFDLMS:\124r LOOTING EVERYTHING!" or "\124cFFAA00FFDLMS:\124r Looting based on options below.")

			if(LAG_checkbox:GetChecked()) then
				OptionsDB["LBC"] = false
				LBC_checkbox:SetChecked(false)
				LBC_checkbox:Disable()
				lbvSlider:Disable()
				lbqSlider:Disable()
				
				LBC_checkboxText:SetTextColor(0.5,0.5,0.5,0.8)
				ValueHeader_Label:SetTextColor(0.5,0.5,0.5,0.8)
				QualityHeader_Label:SetTextColor(0.5,0.5,0.5,0.8)
				Value_Label:Hide()
				Quality_Label:Hide()
			else
				if(not IsEmpty) then
					LBC_checkbox:Enable()
					
					LBC_checkboxText:SetTextColor(1.0,1.0,0.0,0.8)
				end
				ValueHeader_Label:SetTextColor(1.0,1.0,0.0,0.8)
				QualityHeader_Label:SetTextColor(1.0,1.0,0.0,0.8)
				lbvSlider:Enable()
				lbqSlider:Enable()
				Value_Label:Show()
				Quality_Label:Show()
			end
			
			if(OptionsDB["LBC"]) then 
				select_all_button:Enable(); 
				deselect_all_button:Enable();
				select_allText:SetTextColor(1.0,1.0,0.0,0.8);
				deselect_allText:SetTextColor(1.0,1.0,0.0,0.8); 
				
				for k,v in pairs(bNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
				for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(1.0,1.0,0.0,0.8); end
				for k,v in pairs(bpcbNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
			else 
				select_all_button:Disable(); 
				deselect_all_button:Disable();
				select_allText:SetTextColor(0.5,0.5,0.5,0.8);  
				deselect_allText:SetTextColor(0.5,0.5,0.5,0.8);

				for k,v in pairs(bNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
				for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(0.5,0.5,0.5,0.8); end
				for k,v in pairs(bpcbNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
			end

		end
	)

	LBC_checkbox:SetScript("OnClick", 
		function()
			OptionsDB["LBC"] = LBC_checkbox:GetChecked() and true or false

			if(OptionsDB["LBC"]) then 
				select_all_button:Enable(); 
				deselect_all_button:Enable();
				select_allText:SetTextColor(1.0,1.0,0.0,0.8);
				deselect_allText:SetTextColor(1.0,1.0,0.0,0.8); 
				
				for k,v in pairs(bNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
				for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(1.0,1.0,0.0,0.8); end
				for k,v in pairs(bpcbNameTable) do _G[v]:Enable(); _G[v.."Text"]:SetTextColor(1.0,1.0,0.0,0.8); end
			else 
				select_all_button:Disable(); 
				deselect_all_button:Disable();
				select_allText:SetTextColor(0.5,0.5,0.5,0.8);  
				deselect_allText:SetTextColor(0.5,0.5,0.5,0.8);

				for k,v in pairs(bNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
				for k,v in pairs(bpNameTable) do _G[v.."_Label"]:SetTextColor(0.5,0.5,0.5,0.8); end
				for k,v in pairs(bpcbNameTable) do _G[v]:Disable(); _G[v.."Text"]:SetTextColor(0.5,0.5,0.5,0.8); end
			end
			
		end
	)

	ARL_checkbox:SetScript("OnClick", 
		function()
			OptionsDB["ARL"] = ARL_checkbox:GetChecked() and 2 or false
			
			if(ARL_checkbox:GetChecked()) then
				ARB_checkbox:Enable()
				ARP_checkbox:Enable()
			else
				ARB_checkbox:SetChecked(false)
				ARB_checkbox:Disable()
				ARP_checkbox:SetChecked(false)
				ARP_checkbox:Disable()
			end
			
			print(OptionsDB["ARL"] and "\124cFFAA00FFDLMS:\124r Will roll greed on all "..QualityStrings[OptionsDB["ARL"]+1].." items." 
									or "\124cFFAA00FFDLMS:\124r Auto Loot Rolls Disabled")
		end
	)

	ARB_checkbox:SetScript("OnClick", 
		function()
		
			OptionsDB["ARL"] = ARB_checkbox:GetChecked() and 3 or 2
			OptionsDB["ARB"] = ARB_checkbox:GetChecked() and true or false
			print(OptionsDB["ARL"] and "\124cFFAA00FFDLMS:\124r Will roll greed on all "..QualityStrings[OptionsDB["ARL"]+1].." items." 
									or "\124cFFAA00FFDLMS:\124r Will roll greed on all "..QualityStrings[OptionsDB["ARL"]+1].." items.")
		end
	)

	ARP_checkbox:SetScript("OnClick", 
		function()
			if(ARP_checkbox:GetChecked()) then 
				OptionsDB["ARL"] = 0
				ARL_checkbox:Disable()
				ARB_checkbox:Disable()
				print("\124cFFAA00FFDLMS:\124r Auto Passing on ALL Loot Rolls")
			else 
				ARL_checkbox:Enable()
				ARB_checkbox:Enable()
				
				if(ARB_checkbox:GetChecked()) then 
					OptionsDB["ARL"] = 3
					print("\124cFFAA00FFDLMS:\124r Will roll greed on all "..QualityStrings[OptionsDB["ARL"]+1].." items.")
				else 
					OptionsDB["ARL"] = 2 
					print("\124cFFAA00FFDLMS:\124r Will roll greed on all "..QualityStrings[OptionsDB["ARL"]+1].." items.")
				end
			end
		end
	)

	ARG_checkbox:SetScript("OnClick", 
		function()
			OptionsDB["ARG"] = ARG_checkbox:GetChecked() and true or false
			print(OptionsDB["ARG"] and "\124cFFAA00FFDLMS:\124r Auto Repair Enabled" or "\124cFFAA00FFDLMS:\124r Auto Repair Disabled")
		end
	)

	ASJ_checkbox:SetScript("OnClick", 
		function()
			OptionsDB["ASJ"] = ASJ_checkbox:GetChecked() and true or false
			print(OptionsDB["ASJ"] and "\124cFFAA00FFDLMS:\124r Auto Selling ALL sellable grey items." or "\124cFFAA00FFDLMS:\124r Auto Sell Disabled")
		end
	)

	KLO_checkbox:SetScript("OnClick", 
		function()
			OptionsDB["KLO"] = KLO_checkbox:GetChecked() and true or false
			print(OptionsDB["KLO"] and "\124cFFAA00FFDLMS:\124r Will keep the loot window open." or "\124cFFAA00FFDLMS:\124r Will auto close the loot window.")
		end
	)
	
	lbvSlider:SetScript("OnValueChanged",
		function(self, value)
			value = floor(value)
			self:SetValue(value)
			if(value == 0) then 
				Value_Label:SetTextColor(0.5,0.5,0.5,0.8)
				Value_Label:SetText("Disabled")
			else
				Value_Label:SetTextColor(1.0,1.0,0.0,0.8)
				Value_Label:SetText(GetCoinTextureString(value,10))
			end
			OptionsDB["LBV"] = (value > 0) and value or false
		end
	)

	lbqSlider:SetScript("OnValueChanged",
			function(self, value)
				value = floor(value)
				self:SetValue(value)
				if(value == 0) then 
					Quality_Label:SetTextColor(0.5,0.5,0.5,0.8)
					Quality_Label:SetText("Disabled")
				else
					Quality_Label:SetTextColor(1.0,1.0,0.0,0.8)
					Quality_Label:SetText(QualityStrings[value])
				end
				OptionsDB["LBQ"] = ((value-1) >= 0) and (value-1) or false
			end
	)
		
	DLMSPanel.name = "DLMS"
	InterfaceOptions_AddCategory(DLMSPanel)
end

-- Core Routines/Functions --

local function PickItUp(slot)
	LootSlot(slot)
	ConfirmLootSlot(slot)
end

local function UpdateDB(t,s)
	if(IsEmpty or dDB[t] == nil) then
		print("\124cFFAA00FFDLMS:\124r Adding \124cFFffff00"..t.. " - "..s.."\124r to the database, setting default and looting item.")
		dDB[t] = {}
		dDB[t][s] = default
		newItem = true
	elseif(dDB[t][s] == nil) then
		print("\124cFFAA00FFDLMS:\124r Adding \124cFFffff00"..s.."\124r to the database under catagory: \124cFFffff00"..t.."\124r - Setting default and looting item.")
		dDB[t][s] = default
		newItem = true
	end
end

local function IsWantedItem(t,s)
	UpdateDB(t,s)
	return dDB[t][s]
end

local function dDB_OnEvent(self, event, ...)
	
	if(event == "ADDON_LOADED") then
		for i=1,select("#", ...) do
			local AddOnName = select(i, ...)
			if(AddOnName == "DLMS") then
				print("\124cFFAA00FFDLMS:\124r v1.0 loading...")
				dDB = svdDB
				if(next(dDB) == nil) then IsEmpty = true end
				if(next(svOptionsDB) == nil) then
					OptionsDB = oDefaultsDB
				else
					OptionsDB = svOptionsDB
				end
				
				if(IsEmpty) then
					print("\124cFFAA00FFDLMS:\124r Empty Database. Catagories Disabled.")
					print("\124cFFAA00FFDLMS:\124r Setting \"Loot All and GO!\" as default.")
					print("\124cFFAA00FFDLMS:\124r Go loot! so that I can build the Catagories database.")
				else
					print("\124cFFAA00FFDLMS:\124r Found existing database, building catagory options...")
				end
				DLMSBuildOptions()
				print("\124cFFAA00FFDLMS:\124r Load done! Options located under \124cFFFFFF00Interface\\Addons\\DLMS\124r")
				if(not OptionsDB["enabled"]) then print("\124cFFAA00FFDLMS:\124r Is currently disabled.") end
			end
		end
	end	

	if(event == "PLAYER_LOGOUT") then
		svdDB = dDB
		svOptionsDB = OptionsDB
	end
		
	if(OptionsDB["enabled"]) then	
	-- Auto Sell/Repair Block --
		if(event == "MERCHANT_SHOW") then
		
			--if MerchantFrame:IsVisible() then
			
				-- Auto Repair --
				if(OptionsDB["ARG"]) then
					local rCost, mCanRepair = GetRepairAllCost()
					local pFunds = GetMoney()
					
					if(mCanRepair) then
						if(IsInGuild() and CanGuildBankRepair()) then
							print("\124cFFAA00FFDLMS:\124r \124cFF00ff00Repairing with guild funds...\124r")
							RepairAllItems(1)
						elseif(rCost <= pFunds) then
							print("\124cFFAA00FFDLMS:\124r \124cFF00ff00Repairing with player funds...\124r")
							RepairAllItems()
						else
							print("\124cFFAA00FFDLMS:\124r \124cFF00ff00Unable to repair at this time...\124r")
						end
					end
				end
				-- END --
				
				-- Auto Sell --
				if(OptionsDB["ASJ"]) then
					
					local tsVal = 0
					local tItems = 0
					
					for bag=0,4 do
					
						for slot=0,GetContainerNumSlots(bag) do
						
							local link = GetContainerItemLink(bag, slot)
							
							if(link and (select(3, GetItemInfo(link)) == 0) and (select(11, GetItemInfo(link)) > 0)) then
							
								local stackSize = select(2,GetContainerItemInfo(bag, slot))
								local iVal = select(11, GetItemInfo(link))
								local sVal = iVal * stackSize
								
								--print(iVal.." * "..stackSize.." = "..sVal)
								--print(stackSize)
								--print(sVal)
								
								tItems = tItems + 1
								if(tItems == 1) then print("\124cFFAA00FFDLMS:\124r \124cFFffff00Selling Junk...\124r") end
								tsVal = tsVal + sVal
								print("\124cFFffff00 > Selling:\124r "..link.." x "..stackSize)  --.." ("..GetCoinTextureString(sVal,10)..")")
								ShowMerchantSellCursor(1)
								UseContainerItem(bag, slot)
								
							end
							
						end
						
					end
					
					if(tItems > 0) then
						print("\124cFFffff00 > Sold "..tItems.." item(s) totaling:\124r "..GetCoinTextureString(tsVal,10))
					end	
				end
				-- END --
			--end
		end
-- END --

-- Checking for loot rolls.. --
		if(event == "START_LOOT_ROLL") then
			RollID = select(1,...)
			tinsert(ItemRollIDs, RollID)

			local _,N,_,Q,BoP = GetLootRollItemInfo(RollID)
			local lrILink = GetLootRollItemLink(RollID)
			if(OptionsDB["ARL"] ~= false) then
				if(OptionsDB["ARL"] > 0) then
					if((Q <= OptionsDB["ARL"])) then
						print("\124cFFAA00FFDLMS:\124r Auto Rolling \"\124cFFffff00Greed\124r\" on "..lrILink.."\124r...")
						ConfirmLootRoll(RollID, 2)
					end
				else 
					print("\124cFFAA00FFDLMS:\124r Passing on "..lrILink)
					ConfirmLootRoll(RollID, 0)
				end
			end
		end
		
		if(event == "CONFIRM_LOOT_ROLL") then
			if(Options["ARL"]) then ConfirmLootSlot(select(1,...)) end
		end


-- Loot Block --
		if(event == "LOOT_OPENED" and arg1 ~= 1 and not IsShiftKeyDown()) then
					
			for i = 1, GetNumLootItems() do
								
				local looted = false
				local LootIsCurrency = (GetLootSlotType(i) > 1) and true or false
					
				local _, _, stackSize, quality, _ = GetLootSlotInfo(i)
				
				if(LootIsCurrency) then
					PickItUp(i)
				else
				
					local itemName, itemLink, itemQuality, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount,
						itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(GetLootSlotLink(i))
						
					if(IsInGroup()) then
						for k,v in pairs(ItemRollIDs) do
							local _,name,_,_,_ = GetLootRollItemInfo(ItemRollIDs[k])
							if(itemName == name) then
								print("\124cFFAA00FFDLMS:\124r "..itemLink.." is currently being rolled for.")
								looted = true
							end
						end
					end
						
					-- Just loot all --
					if(OptionsDB["LAG"] and not looted) then
						UpdateDB(itemType,itemSubType)
						PickItUp(i)
						looted = true
					end
					
					if(OptionsDB["LBC"] and IsWantedItem(itemType,itemSubType) and not looted) then
						PickItUp(i)
						looted = true
					end
					
					if(OptionsDB["LBV"] and not looted) then
						if((itemSellPrice*itemStackCount) >= OptionsDB["LBV"]) then
							PickItUp(i)
							looted = true
						end
					end
					
					if(OptionsDB["LBQ"] and not looted) then 
						if(itemQuality >= OptionsDB["LBQ"]) then
							PickItUp(i)
							looted = true
						end
					end
				end
			end
			if(newItem) then print("New item(s) added. Use \"/ui reload\" or \"/reload\" to rebuild catagory options."); newItem = false end
		end
		if(not OptionsDB["KLO"] and not IsShiftKeyDown()) then CloseLoot() end
	end
-- END --
end

-- attempt to suppress the "You receive loot:" messages --
local function DLMSLoot(self, event, arg1, ...)

	if(OptionsDB["UWM"] or not OptionsDB["enabled"]) then
		return false, arg1, ...
	else
		arg1 = gsub(arg1, "You receive loot:", "\124cFFAA00FFDLMS: \124cFFFFFF00Looted:\124r ")
		arg1 = gsub(arg1, "(x)(%d+)"," \124cFFffffff %1 %2\124r") 
		arg1 = "\124cFF00aa00"..arg1.."\124r"
		return false, arg1, ...
	end
end

local function DLMSMoney(self, event, arg1, ...)
	if(OptionsDB["UWM"] or not OptionsDB["enabled"]) then
		return false, arg1, ...
	else
		local g,s,c = strsub(GOLD_AMOUNT,3), strsub(SILVER_AMOUNT,3), strsub(COPPER_AMOUNT,3)
		arg1 = gsub(arg1,"You loot", "\124cFFAA00FFDLMS:\124r \124cFFffff00Picked up:\124r ")
		arg1 = gsub(arg1,"Your share of the loot is", "\124cFFAA00FFDLMS:\124r \124cFFffff00Picked up:\124r")
		arg1 = gsub(arg1, "," ,"")
		arg1 = "\124cFFffffff"..arg1
		arg1 = gsub(arg1,c,"\124TInterface\\MoneyFrame\\UI-CopperIcon:12:12:2:0\124t" )
		arg1 = gsub(arg1,s,"\124TInterface\\MoneyFrame\\UI-SilverIcon:12:12:2:0\124t" )
		arg1 = gsub(arg1,g,"\124TInterface\\MoneyFrame\\UI-GoldIcon:12:12:2:0\124t" )
		arg1 = arg1.."\124r"
		return false, arg1, ...
	end
end

dDBFrame:SetScript("OnEvent", dDB_OnEvent)
ChatFrame_AddMessageEventFilter("CHAT_MSG_LOOT", DLMSLoot)
ChatFrame_AddMessageEventFilter("CHAT_MSG_MONEY", DLMSMoney)
