if GetLocale() ~= "ruRU" then return end
local L = DBM_SpellsUsed_Translations

L.TabCategory_SpellsUsed	= "Восстановления заклинаний/навыков"
L.AreaGeneral 			= "Основные настройки для восст. заклинаний/навыков"
L.Enable 			= "Включить таймеры восстановлений"
L.Show_LocalMessage 		= "Показать локальное сообщение при применении"
L.Enable_inRaid			= "Показывать восстановление только от участников рейда"
L.Enable_inBattleground		= "Показывать восстановления на полях боя"
L.Enable_Portals		= "Показать длительность порталов"
L.Reset				= "Сброс на по умолчанию"
L.Local_CastMessage 		= "Обнаружено применение: %s"
L.AreaAuras 			= "Настройки заклинаний/навыков"
L.SpellID 			= "ID заклинания"
L.BarText 			= "Текст полосы (по умолчанию: %spell: %player)"
L.Cooldown 			= "Восстановление"
L.Error_FillUp			= "Пожалуйста, заполните все поля перед добавлением нового"




