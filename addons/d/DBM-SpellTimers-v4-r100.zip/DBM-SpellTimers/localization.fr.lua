﻿if GetLocale() ~= "frFR" then return end
local L = DBM_SpellsUsed_Translations

-- Initial translation by ckeurk
-- Last update: 12/27/2010 (by Sasmira)

L.TabCategory_SpellsUsed	= "incantation/Capacit\195\169 temps de recharge"
L.AreaGeneral        		= "Options générales"
L.Enable					= "Activer le compteur pour le temps de recharge"
L.Show_LocalMessage			= "Voir le message local d'incantation"
L.Enable_inRaid				= "Afficher les temps de recharge des membres du raid"
L.Enable_inBattleground		= "Afficher les temps de recharge aussi dans les champs de bataille"
L.Enable_Portals			= "Dur\195\169es des portails"
L.Reset						= "Remettre \195\160 z\195\169ro"
L.Local_CastMessage			= "D\195\169tecte les incant: %s"
L.AreaAuras					= "Syst\195\168me des sorts / compétences"
L.SpellID					= "ID du sort"
L.BarText					= "Barre de texte (par défaut: %sort: %joueur)"
L.Cooldown					= "Temps de recharge"
L.Error_FillUp				= "merci de remplir tous les champs avant d'ajouter un nouveau"



