﻿--[[-----------------------------------------------------------------------------------
 Original Drathals HUD (c) 2006 by Markus Inger / Drathal / Silberklinge / Silbersegen
 DHUD for WotLK and later expansions (c) 2013 by MADCAT (EU-Гордунни, Мадкат)
 (http://eu.battle.net/wow/en/character/гордунни/Мадкат/advanced)
---------------------------------------------------------------------------------------
 This file contains user settings and notifies other objects about settings change
 @author: MADCAT
-----------------------------------------------------------------------------------]]--

--------------------
-- Settings Event --
--------------------

--- Class for settings event, it will be fired by settings manager
DHUDSettingsEvent = MCCreateSubClass(MADCATEvent, {
	-- name of the changed setting
	setting = "",
	-- dispatched when dhud settings addon starts to change some value
	EVENT_START_PREVIEW = "previewStart",
	-- dispatched when dhud settings addon stops to change some value
	EVENT_STOP_PREVIEW = "previewStop",
	-- dispatched when some setting changed
	EVENT_SETTING_CHANGED = "settingChanged",
	-- prefix for event that will be dispatched when some group of the settings was changed
	EVENT_SPECIFIC_GROUP_SETTING_CHANGED_PREFIX = "groupSettingChanged_",
	-- prefix for event that will be dispatched when specific setting changed
	EVENT_SPECIFIC_SETTING_CHANGED_PREFIX = "settingChanged_",
})

--- Create new settings event
-- @param type type of the event
function DHUDSettingsEvent:new(type)
	local o = self:defconstructor();
	o:constructor(type);
	return o;
end

--- Constructor for settings event
-- @param type type of the event
function DHUDSettingsEvent:constructor(type)
	-- call super constructor
	MADCATEvent.constructor(self, type);
end

--------------
-- Settings --
--------------

--- Class to notify about settings change and manage saved vars (only difference is saved)
DHUDSettings = MCCreateSubClass(MADCATEventDispatcher, {
	-- type of the setting, that should be saved by value
	SETTING_TYPE_VALUE = 0,
	-- type of the setting, that holds another set of settings, containers will not be used in actual settings table, instead they will be used as part of the name
	SETTING_TYPE_CONTAINER = 1,
	-- type of the setting that will be used only as reference to possible values
	SETTING_TYPE_CONTAINER_REFERENCE = 2,
	-- type of the setting, that holds array in which order of elements and it's size matter
	SETTING_TYPE_ARRAY_FIXEDORDERSIZE = 3,
	-- type of the setting, that holds array in which order and size is irrelevant
	SETTING_TYPE_ARRAY_NOORDERSIZE = 4,
	-- type of the setting, that holds array with spellids in default table, but will use spellnames in settings table
	SETTING_TYPE_ARRAY_SPELLIDTONAME = 5,
	-- type of the setting that holds key value combinations
	SETTING_TYPE_TABLE = 6,
	-- type of the setting, that holds array in which order of elements matter
	SETTING_TYPE_ARRAY_FIXEDORDER = 7,
	-- default settings table in following format: setting = value, settingType, additionalData table or nil
	default = {
		-- settings group to hide/show blizzard frames
		["blizzardFrames"] = { {
			-- allows to show or hide blizzard player frame
			["playerFrame"] = { true, 0 },
			-- allows to show or hide blizzard target frame
			["targetFrame"] = { true, 0 },
			-- allows to show or hide blizzard casting frame
			["castingFrame"] = { false, 0 },
			-- allows to change alpha of SpellActivationOverlayFrame
			["spellActivationFrameAlpha"] = { 0.5, 0, { range = { 0, 1, 0.1 } } },
			-- allows to change alpha of SpellActivationOverlayFrame
			["spellActivationFrameScale"] = { 1, 0, { range = { 0.2, 2, 0.1 } } },
		}, 1 },
		-- allows to apply text outlines to the text frames
		["outlines"] = { {
			-- change outline of the text corresponding to inner left big bar
			["leftBigBar1"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to outer left big bar
			["leftBigBar2"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to inner left small bar
			["leftSmallBar1"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to outer left small bar
			["leftSmallBar2"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to inner right big bar
			["rightBigBar1"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to outer right big bar
			["rightBigBar2"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to inner right small bar
			["rightSmallBar1"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to outer right small bar
			["rightSmallBar2"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to target info
			["targetInfo1"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the text corresponding to target of target info
			["targetInfo2"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the time text in the spell circles
			["spellCirclesTime"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the stacks text in in the spell circles
			["spellCirclesStacks"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the time text in the spell rectangles
			["spellRectanglesTime"] = { 1, 0, { range = { 0, 2, 1 } } },
			-- change outline of the stacks text in in the spell rectangles
			["spellRectanglesStacks"] = { 1, 0, { range = { 0, 2, 1 } } },
			-- change outline of the time text on resource frames, e.g. death knight rune time left
			["resourceTime"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the time text in cast bars
			["castBarsTime"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change outline of the delay text in cast bars
			["castBarsDelay"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- change  outline of the spell text in cast bars
			["castBarsSpell"] = { 0, 0, { range = { 0, 2, 1 } } },
		}, 1 },
		-- allows to change scale of the frames or change font size
		["scale"] = { {
			-- changes scale of the whole bar
			["main"] = { 1.0, 0, { range = { 0.2, 2.0, 0.1 } } },
			-- changes scale of the spell circles
			["spellCircles"] = { 1.0, 0, { range = { 0.2, 2.0, 0.1 } } },
			-- changes scale of the spell rectangles
			["spellRectangles"] = { 1.0, 0, { range = { 0.2, 2.0, 0.1 } } },
			-- changes scale of the resource indication, such as runes or combo-points
			["resource"] = { 1.0, 0, { range = { 0.2, 2.0, 0.1 } } },
			-- change text size of the text corresponding to inner left big bar
			["leftBigBar1"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to outer left big bar
			["leftBigBar2"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to inner left small bar
			["leftSmallBar1"] = { 9, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to outer left small bar
			["leftSmallBar2"] = { 9, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to inner right big bar
			["rightBigBar1"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to outer right big bar
			["rightBigBar2"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to inner right small bar
			["rightSmallBar1"] = { 9, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to outer right small bar
			["rightSmallBar2"] = { 9, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to target info
			["targetInfo1"] = { 12, 0, { range = { 6, 30, 1 } } },
			-- change text size of the text corresponding to target of target info
			["targetInfo2"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the time text in the spell circles
			["spellCirclesTime"] = { 12, 0, { range = { 6, 30, 1 } } },
			-- change text size of the stacks text in in the spell circles
			["spellCirclesStacks"] = { 8, 0, { range = { 6, 30, 1 } } },
			-- change text size of the time text in the spell rectangles
			["spellRectanglesTime"] = { 8, 0, { range = { 6, 30, 1 } } },
			-- change text size of the stacks text in in the spell rectangles
			["spellRectanglesStacks"] = { 6, 0, { range = { 6, 30, 1 } } },
			-- change text size of the time text on resource frames, e.g. death knight rune time left
			["resourceTime"] = { 12, 0, { range = { 6, 30, 1 } } },
			-- change text size of the time text in cast bars
			["castBarsTime"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the delay text in cast bars
			["castBarsDelay"] = { 10, 0, { range = { 6, 30, 1 } } },
			-- change text size of the spell text in cast bars
			["castBarsSpell"] = { 12, 0, { range = { 6, 30, 1 } } },
		}, 1 },
		-- allows to show or hide frames with icons
		["icons"] = { {
			-- allows to show resting icon when in the inn
			["restingIcon"] = { true, 0 },
			-- allows to show combat icon when in combat
			["combatIcon"] = { true, 0 },
			-- allows to show player pvp icon when flagged for pvp
			["playerPvPIcon"] = { true, 0 },
			-- allows to show target pvp icon when target is flagged for pvp
			["targetPvPIcon"] = { true, 0 },
			-- allows to show elite icon for target creatures
			["targetEliteIcon"] = { true, 0 },
			-- allows to show target raid icon
			["targetRaidIcon"] = { true, 0 },
			-- allows to show target spec role (players only)
			["targetSpecRoleIcon"] = { true, 0 },
			-- allows to show target spec (players only)
			["targetSpecIcon"] = { true, 0 },
		}, 1 },
		-- allows to change alpha when certain conditions are met
		["alpha"] = { {
			-- alpha when in combat
			["combat"] = { 0.8, 0, { range = { 0.0, 1.0, 0.1 } } },
			-- alpha when out of combat, but has target
			["hasTarget"] = { 0.5, 0, { range = { 0.0, 1.0, 0.1 } } },
			-- alpha when out of combat, without target, but resources are regenerating
			["regen"] = { 0.3, 0, { range = { 0.0, 1.0, 0.1 } } },
			-- alpha when out of combat and no other condition is met
			["outOfCombat"] = { 0.0, 0, { range = { 0.0, 1.0, 0.1 } } },
		}, 1 },
		-- allows to change position of the bars and text
		["offsets"] = { {
			-- allows to reposition hud
			["hud"] = { { 0, 0 }, 3 },
			-- allows to increase or decrease distance between bars
			["barDistance"] = { 0, 0 },
			-- allows to offset target info frames
			["targetInfo"] = { { 0, 0 }, 3 },
			-- allows to offset target of target info frames
			["targetInfo2"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to inner left big bar
			["leftBigBar1"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to outer left big bar
			["leftBigBar2"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to inner left small bar
			["leftSmallBar1"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to outer left small bar
			["leftSmallBar2"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to inner right big bar
			["rightBigBar1"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to outer right big bar
			["rightBigBar2"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to inner right small bar
			["rightSmallBar1"] = { { 0, 0 }, 3 },
			-- change text position of the text corresponding to outer right small bar
			["rightSmallBar2"] = { { 0, 0 }, 3 },
		}, 1 },
		-- allows to change color when colorizing bars and spell icons
		["colors"] = { {
			-- list with colors to visualize player data on bars
			["player"] = { {
				-- allows to change color of player health on bars
				["health"] = { { "00FF00", "FFFF00", "FF0000" }, 3 },
				-- allows to change color of player health shield on bars
				["healthShield"] = { { "FFFFFF", "FFFFFF", "FFFFFF" }, 3 },
				-- allows to change color of player health absorbed on bars
				["healthAbsorb"] = { { "FF0080", "FF0080", "FF0080" }, 3 },
				-- allows to change color of player health incoming heal on bars
				["healthHeal"] = { { "0000FF", "0000FF", "0000FF" }, 3 },
				-- allows to change color of player mana on bars
				["mana"] = { { "00FFFF", "0000FF", "FF00FF" }, 3 },
				-- allows to change color of player rage on bars
				["rage"] = { { "FF0000", "FF0000", "FF0000" }, 3 },
				-- allows to change color of player energy on bars
				["energy"] = { { "FFFF00", "FFFF00", "FFFF00" }, 3 },
				-- allows to change color of player runic power on bars
				["runicPower"] = { { "0080c0", "0080c0", "0080c0" }, 3 },
				-- allows to change color of player focus on bars
				["focus"] = { { "aa4400", "aa4400", "aa4400" }, 3 },
				-- allows to change color of player druid eclipse on bars
				["eclipse"] = { { "fcea1e", "d89d3f", "d29835", "ffffff", "4c80ba", "79c9ec", "d9ffff" }, 3 },
				-- allows to change color of player warlock burining embers on bars
				["burningEmbers"] = { { "00FFFF", "0000FF", "FF00FF" }, 3 },
				-- allows to change color of player warlock demonic fury on bars
				["demonicFury"] = { { "00FFFF", "0000FF", "FF00FF" }, 3 },
				-- allows to change color of player tank vengeance on bars
				["vengeance"] = { { "FF00FF", "FF00FF", "FF00FF" }, 3 },
				-- allows to change color of player monk stagger on bars
				["stagger"] = { { "FF8000", "FFFF00", "80FF00" }, 3 },
			}, 1 },
			-- list with colors to visualize target data on bars
			["target"] = { {
				-- allows to change color of target health on bars
				["health"] = { { "00aa00", "aaaa00", "aa0000" }, 3 },
				-- allows to change color of target health shield on bars
				["healthShield"] = { { "aaaaaa", "aaaaaa", "aaaaaa" }, 3 },
				-- allows to change color of target health absorbed on bars
				["healthAbsorb"] = { { "aa0055", "aa0055", "aa0055" }, 3 },
				-- allows to change color of target health incoming heal on bars
				["healthHeal"] = { { "0000aa", "0000aa", "0000aa" }, 3 },
				-- allows to change color of target health on bars when target is not tapped by player
				["healthNotTapped"] = { { "cccccc", "bbbbbb", "aaaaaa" }, 3 },
				-- allows to change color of target mana on bars
				["mana"] = { { "00aaaa", "0000aa", "aa00aa" }, 3 },
				-- allows to change color of target rage on bars
				["rage"] = { { "aa0000", "aa0000", "aa0000" }, 3 },
				-- allows to change color of target energy on bars
				["energy"] = { { "aaaa00", "aaaa00", "aaaa00" }, 3 },
				-- allows to change color of target runic power on bars
				["runicPower"] = { { "004060", "004060", "004060" }, 3 },
				-- allows to change color of target focus on bars
				["focus"] = { { "aa4400", "aa4400", "aa4400" }, 3 },
			}, 1 },
			-- list with colors to visualize pet data on bars
			["pet"] = { {
				-- allows to change color of pet health on bars
				["health"] = { { "00FF00", "FFFF00", "FF0000" }, 3 },
				-- allows to change color of pet health shield on bars
				["healthShield"] = { { "FFFFFF", "FFFFFF", "FFFFFF" }, 3 },
				-- allows to change color of pet health absorbed on bars
				["healthAbsorb"] = { { "FF0080", "FF0080", "FF0080" }, 3 },
				-- allows to change color of pet health incoming heal on bars
				["healthHeal"] = { { "0000FF", "0000FF", "0000FF" }, 3 },
				-- allows to change color of target mana on bars
				["mana"] = { { "00FFFF", "0000FF", "FF00FF" }, 3 },
				-- allows to change color of pet focus on bars
				["focus"] = { { "aa4400", "aa4400", "aa4400" }, 3 },
				-- allows to change color of pet energy on bars
				["energy"] = { { "FFFF00", "FFFF00", "FFFF00" }, 3 },
			}, 1 },
			-- list with colors to visualize self castbars
			["selfCastbar"] = { {
				-- allows to change color of castbar when casting
				["cast"] = { { "00FF00", "88FF00", "FFFF00" }, 3 },
				-- allows to change color of castbar when channeling
				["channel"] = { { "E0E0FF", "C0C0FF", "A0A0FF" }, 3 },
				-- allows to change color of castbar when casting can't be interrupted
				["lockedCast"] = { { "00FF00", "88FF00", "FFFF00" }, 3 },
				-- allows to change color of castbar when channel can't be interrupted
				["lockedChannel"] = { { "E0E0FF", "C0C0FF", "A0A0FF" }, 3 },
				-- allows to change color of castbar when cast was interrupted
				["interrupted"] = { { "FF0000", "FF0000", "FF0000" }, 3 },
			}, 1 },
			-- list with colors to visualize target castbars
			["targetCastbar"] = { {
				-- allows to change color of castbar when casting
				["cast"] = { { "00FF00", "88FF00", "FFFF00" }, 3 },
				-- allows to change color of castbar when channeling
				["channel"] = { { "E0E0FF", "C0C0FF", "A0A0FF" }, 3 },
				-- allows to change color of castbar when casting can't be interrupted
				["lockedCast"] = { { "0000FF", "0000FF", "0000FF" }, 3 },
				-- allows to change color of castbar when channel can't be interrupted
				["lockedChannel"] = { { "0000FF", "0000FF", "0000FF" }, 3 },
				-- allows to change color of castbar when cast was interrupted
				["interrupted"] = { { "FF0000", "FF0000", "FF0000" }, 3 },
			}, 1 },
			-- list with colors to visualize spell circles that are showing self auras
			["selfShortAuras"] = { {
				-- allows to change color of spell circle when it shows buff
				["buff"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
				-- allows to change color of spell circle when it shows debuff
				["debuff"] = { { "FFFF00", "FFFF00", "FFFF00" }, 3 },
				-- allows to change color of spell circle when it shows magic debuff
				["debuffMagic"] = { { "3397ff", "3397ff", "3397ff" }, 3 },
				-- allows to change color of spell circle when it shows curse debuff
				["debuffCurse"] = { { "9900ff", "9900ff", "9900ff" }, 3 },
				-- allows to change color of spell circle when it shows disease debuff
				["debuffDisease"] = { { "996400", "996400", "996400" }, 3 },
				-- allows to change color of spell circle when it shows poison debuff
				["debuffPoison"] = { { "009700", "009700", "009700" }, 3 },
			}, 1 },
			-- list with colors to visualize spell circles that are showing target auras
			["targetShortAuras"] = { {
				-- allows to change color of spell circle when it shows debuff
				["buff"] = { { "FFFF00", "FFFF00", "FFFF00" }, 3 },
				-- allows to change color of spell circle when it shows buff
				["debuff"] = { { "FFFF00", "FFFF00", "FFFF00" }, 3 },
				-- allows to change color of player applied spells
				["appliedByPlayer"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
			}, 1 },
			-- list with colors to visualize spell rectangles that are showing self cooldowns
			["selfCooldowns"] = { {
				-- allows to change color of spell circle when it shows spell cooldown
				["spell"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
				-- allows to change color of spell circle when it shows item cooldown
				["item"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
			}, 1 },
			-- list with colors to visualize spell rectangles that are showing self guardians
			["selfGuardians"] = { {
				-- allows to change color of spell circle when it shows passive guardian
				["passive"] = { { "808080", "808080", "808080" }, 3 },
				-- allows to change color of spell circle when it shows active guardian
				["active"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
			}, 1 },
			-- list with colors to visualize spell rectangles that are showing self auras
			["selfAuras"] = { {
				-- allows to change color of spell circle when it shows buff
				["buff"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
				-- allows to change color of spell circle when it shows debuff
				["debuff"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
			}, 1 },
			-- list with colors to visualize spell rectangles that are showing target auras
			["targetAuras"] = { {
				-- allows to change color of spell circle when it shows debuff
				["buff"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
				-- allows to change color of spell circle when it shows buff
				["debuff"] = { { "ffffff", "ffffff", "eeeeee" }, 3 },
			}, 1 },
		}, 1 },
		-- allows to change text formatting in the text fields
		["unitTexts"]  = { {
			-- list with texts to visualize player data in text fields
			["player"] = { {
				-- allows to change - what to output to player health textField
				["health"] = { "@default", 0, { default = { "@health4" }, }, },
				-- allows to change - what to output to player power textField
				["power"] = { "@default", 0, { default = { "@power4", ["ROGUE"] = "@power1", ["WARRIOR"] = "@power1", ["DEATHKNIGHT"] = "@power1" } }, },
				-- allows to change - what to output to player alternative power textField
				["altpower"] = { "@default", 0, { default = { "@power1", ["WARLOCK"] = "@power6" } }, },
				-- allows to change - what to output to player other data type textField (stagger, vengeance, etc)
				["other"] = { "@default", 0, { default = { "@power1" } }, },
				-- allows to change - what to output to player cast time textField
				["castTime"] = { "@default", 0, { default = { "@castTime2" } }, },
				-- allows to change - what to output to player cast delay textField
				["castDelay"] = { "@default", 0, { default = { "@castDelay1" } }, },
				-- allows to change - what to output to player cast spell name textField
				["castSpellName"] = { "@default", 0, { default = { "@castSpellName1" } }, },
			}, 1 },
			-- list with texts to visualize target data in text fields
			["target"] = { {
				-- allows to change - what to output to target health textField
				["health"] = { "@default", 0, { default = { "@health4" } }, },
				-- allows to change - what to output to target power textField
				["power"] = { "@default", 0, { default = { "@power3" } }, },
				-- allows to change - what to output to target info textField
				["info"] = { "@default", 0, { default = { "@unitInfo2" } }, },
				-- allows to change - what to output to target cast time textField
				["castTime"] = { "@default", 0, { default = { "@castTime2" } }, },
				-- allows to change - what to output to target cast delay textField
				["castDelay"] = { "@default", 0, { default = { "@castDelay1" } }, },
				-- allows to change - what to output to target cast spell name textField
				["castSpellName"] = { "@default", 0, { default = { "@castSpellName1" } }, },
			}, 1 },
			-- list with texts to visualize target of target data in text fields
			["targettarget"] = { {
				-- allows to change - what to output to target of target info textField
				["info"] = { "@default", 0, { default = { "@unitInfo2" } }, },
			}, 1 },
			-- list with texts to visualize target data in text fields
			["pet"] = { {
				-- allows to change - what to output to pet health textField
				["health"] = { "@default", 0, { default = { "@health1" } }, },
				-- allows to change - what to output to pet power textField
				["power"] = { "@default", 0, { default = { "@power1" } }, },
			}, 1 },
		}, 1 },
		-- predefines list of texts to be shown in text fields
		["unitTextsPredefined"] = { {
			-- empty text
			["empty"] = "",
			-- health amount only
			["health1"] = "<color_amount><amount></color><color_amount_habsorb><amount_habsorb(\" - \")></color><color_amount_extra><amount_extra(\" + \")></color><color_amount_hincome><amount_hincome(\" + \")></color>",
			-- health amount with health max amount
			["health2"] = "<color_amount><amount></color>/<amount_max><color_amount_habsorb><amount_habsorb(\" - \")></color><color_amount_extra><amount_extra(\" + \")></color><color_amount_hincome><amount_hincome(\" + \")></color>",
			-- health percent only
			["health3"] = "<color_amount><amount_percent>%</color><color_amount_habsorb><amount_habsorb(\" - \")></color><color_amount_extra><amount_extra(\" + \")></color><color_amount_hincome><amount_hincome(\" + \")></color>",
			-- health amount with health percent
			["health4"] = "<color_amount><amount></color> <color(\"999999\")>(</color><amount_percent>%<color(\"999999\")>)</color><color_amount_habsorb><amount_habsorb(\" - \")></color><color_amount_extra><amount_extra(\" + \")></color><color_amount_hincome><amount_hincome(\" + \")></color>";
			-- health amount with health max amount and percent
			["health5"] = "<color_amount><amount>/<amount_max></color> <color(\"999999\")>(</color><amount_percent>%<color(\"999999\")>)</color><color_amount_habsorb><amount_habsorb(\" - \")></color><color_amount_extra><amount_extra(\" + \")></color><color_amount_hincome><amount_hincome(\" + \")></color>",
			-- power amount only
			["power1"] = "<color_amount><amount></color>",
			-- power amount with power max amount
			["power2"] = "<color_amount><amount></color>/<amount_max>",
			-- power percent only
			["power3"] = "<color_amount><amount_percent>%</color>",
			-- power amount with power percent
			["power4"] = "<color_amount><amount></color> <color(\"999999\")>(</color><amount_percent>%<color(\"999999\")>)</color>",
			-- power amount with power max amount and percent
			["power5"] = "<color_amount><amount>/<amount_max></color> <color(\"999999\")>(</color><amount_percent>%<color(\"999999\")>)</color>",
			-- power amount only with precision to 1 digit
			["power6"] = "<color_amount><amount(nil, 1)></color>",
			-- maximum user info
			["unitInfo1"] = "<color_level><level><elite></color> <color_reaction><name></color> [<color_class><class></color>] <guild(\"<\",\">\")> <pvp>",
			-- medium user info
			["unitInfo2"] = "<color_level><level><elite></color> <color_reaction><name></color> [<color_class><class></color>] <pvp>",
			-- minimum user info
			["unitInfo3"] = "<color_level><level><elite></color> <color_reaction><name></color> <pvp>",
			-- cast time text
			["castTime1"] = "<color(\"ffff00\")><time></color>",
			-- cast time remaining time
			["castTime2"] = "<color(\"ffff00\")><time_remain></color>",
			-- cast delay text
			["castDelay1"] = "<color(\"ff0000\")><delay(\"+ \", \"- \")></color>",
			-- cast spell name text
			["castSpellName1"] = "<color(\"ffffff\")><spellname(\"|cff\" .. \"0099CC\" .. \"Canceled\" .. \"|\" .. \"r\", \"|cff\" .. \"FF3399\" .. \"Interrupted\", \"|cff\" .. \"66FF00\" .. \"Interrupted by Me\" .. \"|\" .. \"r\", \" by \", \"|\" .. \"r\")></color>",
		}, 2 },
		-- allows to change bar textures
		["textures"] = { {
			-- holds number of the texture to use for bars (default 2 = bubbles)
			["barTexture"] = { 2, 0, { range = { 1, 5, 1 } } },
			-- allows to show or hide hud background texture
			["barBackground"] = { true, 0 },
		}, 1 },
		-- list with options for short auras and cooldowns
		["shortAurasOptions"] = { {
			-- allows to show auras with charges, regardless of time left
			["aurasWithCharges"] = { true, 0 },
			-- maximum time left on aura to be shown in short auras
			["aurasTimeLeftMax"] = { 60, 0, { range = { 0, 3600, 1 } } },
			-- allows to show player debuffs along with player buffs
			["playerDebuffs"] = { true, 0 },
			-- allows to colorize player debuffs according to debuff type
			["colorizePlayerDebuffs"] = { true, 0 },
			-- allows to show auras from this list, regardless of time or charges
			["playerAurasWhiteList"] = { { }, 5 },
			-- allows to not show auras from this list, regardless of time or charges
			["playerAurasBlackList"] = { { }, 5 },
			-- allows to set priority for spell appearance in spell circles
			["playerAurasPriorityList"] = { { }, 5 },
			-- allows to show auras from this list, regardless of time or charges
			["targetAurasWhiteList"] = { { -- druid symbiosis spells are named the same, no point in including them
				48792, -- DK: Icebound Fortitude, prevents stuns on target, reduces all damage by 20%
				48707, -- DK: Anti-Magic Shell, prevents all magic damage to target
				33786, -- Druid: Cyclone, prevents any damage to target
				61336, -- Druid: Survival Instincts, reduces all gamage by 50%
				19263, -- Hunter: Deterrence, prevents all damage to target
				45438, -- Mage: Ice block, prevents all damage to target
				108978, -- Mage: Alter Time, reverts all damage done to target after 6 seconds
				122464, -- Monk: Dematerialize, causes all abilities to miss
				1022, -- Paladin: Hand of protection, prevents physical damage to target
				642, -- Paladin: Divine Shield, prevents all damage to target
				47585, -- Priest: Dispersion, reduces damage by 90%
				33206, -- Priest: Pain Supression, reduces all damage by 40%
				31224, -- Rogue: Cloak of Shadows, prevents all magic damage to target
				5277, -- Rogue: Evasion, increased dodge chance by 100%
				30823, -- Shaman: Shamanistic Rage, reduces all damage by 30%
				110913, -- Warlock: Dark Bargain, prevents all damage, 50% of the damage will be dealed after buff expires
				104773, -- Warlock: Unending Resolve, reduces all damage by 40%
				871, -- Warrior: Shield Wall, reduces damage by 60%
				118038, -- Warrior: Die by the Sword, reduces damage by 20% and increases parry by 100%
			}, 5 },
			-- allows to not show auras from this list, regardless of time or charges
			["targetAurasBlackList"] = { { }, 5 },
			-- allows to set priority for spell appearance in spell circles
			["targetAurasPriorityList"] = { { }, 5 },
			-- minimum cooldown duration to be shown in short cooldowns
			["cooldownsDurationMin"] = { 0, 0, { range = { 0, 3600, 1 } } },
			-- maximum cooldown duration to be shown in short cooldowns
			["cooldownsDurationMax"] = { 3600, 0, { range = { 0, 3600, 1 } } },
			-- allows to show item cooldowns
			["cooldownsItem"] = { true, 0 },
			-- allows to show cooldowns from this list, regardless of time
			["cooldownsWhiteList"] = { { }, 5 },
			-- allows to not show cooldowns from this list, regardless of time
			["cooldownsBlackList"] = { { }, 5 },
			-- allows to set priority for spell appearance in spell circles
			["cooldownsPriorityList"] = { { }, 5 },
			-- allows to colorize player cooldowns according to spell lock type
			["colorizeCooldownsLock"] = { true, 0 },
		}, 1 },
		-- list with options for all auras
		["aurasOptions"] = { {
			-- allows to show tooltips when mouse is over some aura
			["showTooltips"] = { true, 0 },
			-- allows to show timers on target buffs
			["showTimersOnTargetBuffs"] = { true, 0 },
			-- allows to show timers on target debuffs
			["showTimersOnTargetDeBuffs"] = { true, 0 },
		}, 1 },
		-- list with options for health
		["healthBarOptions"] = { {
			-- allows to show shield on health bars, (0 = do not display, 1 = display in WoW style, 2 = display in LoL style)
			["showShields"] =  { 2, 0, { range = { 0, 2, 1 } } },
			-- allows to show how much of the health will be absorbed by heal
			["showHealAbsorb"] = { true, 0 },
			-- allows to show incoming heal
			["showHealIncoming"] = { true, 0 },
		}, 1 },
		-- what data to display on bars, not filled if not custom
		["framesData"] = { {
			-- layout to use, 0 = custom, all unset settings will be readed from layout specified
			["layout"] = { 1, 0, { range = { 1, 2, 1 } } },
			-- what to show in inner left big bar
			["leftBigBar1"] = { false, 7 },
			-- what to show on outer left big bar
			["leftBigBar2"] = { false, 7 },
			-- what to show on inner left small bar
			["leftSmallBar1"] = { false, 7 },
			-- what to show on outer left small bar
			["leftSmallBar2"] = { false, 7 },
			-- what to show on inner right big bar
			["rightBigBar1"] = { false, 7 },
			-- what to show on outer right big bar
			["rightBigBar2"] = { false, 7 },
			-- what to show on inner right small bar
			["rightSmallBar1"] = { false, 7 },
			-- what to show on outer right small bar
			["rightSmallBar2"] = { false, 7 },
			-- what to show in inner left big cast bar
			["leftBigCastBar1"] = { false, 7 },
			-- what to show on outer left big cast bar
			["leftBigCastBar2"] = { false, 7 },
			-- what to show on inner right big cast bar
			["rightBigCastBar1"] = { false, 7 },
			-- what to show on outer right big cast bar
			["rightBigCastBar2"] = { false, 7 },
			-- what to show on the left outer side info
			["leftOuterSideInfo"] =  { false, 7 },
			-- what to show on the left inner side info
			["leftInnerSideInfo"] =  { false, 7 },
			-- what to show on the right outer side info
			["rightOuterSideInfo"] =  { false, 7 },
			-- what to show on the right inner side info
			["rightInnerSideInfo"] =  { false, 7 },
			-- what to show on the top unit info plate
			["centerUnitInfo1"] =  { false, 7 },
			-- what to show on the bottom unit info plate
			["centerUnitInfo2"] =  { false, 7 },
			-- what to show on the left rectangle frames
			["leftRectangles"] = { false, 7 },
			-- what to show on the right rectangle frames
			["rightRectangles"] = { false, 7 },
			-- position of icons
			["iconPositions"] = { {
				-- position of dragon
				["dragon"] = { false, 0 },
				-- position of self state icons
				["selfState"] = { false, 0 },
				-- position of target state icons
				["targetState"] = { false, 0 },
			}, 1 },
		}, 1 },
		-- sources of data for frames, settings addon should check if data tracker is not nil, as some of them are class specific
		["framesDataSources"] = { {
			-- table with references to actual data trackers, filled in runtime
			["dataTrackersMap"] = { },
			-- data that can be shown on bars
			["bars"] = { "playerHealth", "playerPower", "targetHealth", "targetPower", "petHealth", "petPower",
						 "characterInVehicleHealth", "characterInVehiclePower", "druidMana", "druidEnergy", "druidEclipse",
						 "monkMana", "monkEnergy", "warlockBurningEmbers", "warlockDemonicFury", "tankVengeance", "monkStagger" },
			-- data that can be shown on cast bars
			["castBars"] = { "playerCastBar", "targetCastBar" },
			-- data that can be shown on side slots
			["sideSlots"] = { "playerComboPoints", "playerShortAuras", "targetShortAuras", "playerCooldowns", "monkChi", "warlockSoulShards", "paladinHolyPower", "priestShadowOrbs", "deathKnightRunes", "shamanTotems" },
			-- data that can be shown on spell rectangles
			["spellRectangles"] = { "targetBuffs", "targetDebuffs" },
			-- data that can be shown in unit info frames
			["unitInfo"] = { "targetInfo", "targetOfTargetInfo" },
			-- available position for certain frames
			["positions"] = {
				-- position of dragon
				["dragon"] = { "LEFT", "RIGHT" },
				-- position of self state icons
				["selfState"] = { "LEFT", "RIGHT" },
				-- position of target state icons
				["targetState"] = { "CENTER" },
			},
		}, 2 },
		-- list with default layouts
		["layouts"] = { {
			-- default layout that was used by dhud
			["layout1"] = {
				{
					-- what to show on inner left big bar
					["leftBigBar1"] = { "playerHealth" },
					-- what to show on outer left big bar
					["leftBigBar2"] = { "targetHealth" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehicleHealth", "petHealth" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { },
					-- what to show on inner right big bar
					["rightBigBar1"] = { "playerPower" },
					-- what to show on outer right big bar
					["rightBigBar2"] = { "targetPower" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "petPower" },
					-- what to show on outer right small bar
					["rightSmallBar2"] = { },
					-- what to show in inner left big cast bar
					["leftBigCastBar1"] = { },
					-- what to show on outer left big cast bar
					["leftBigCastBar2"] = { },
					-- what to show on inner right big cast bar
					["rightBigCastBar1"] = { "playerCastBar" },
					-- what to show on outer right big cast bar
					["rightBigCastBar2"] = { "targetCastBar" },
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "playerComboPoints" },
					-- what to show on the left inner side info
					["leftInnerSideInfo"] = { "playerCooldowns" },
					-- what to show on the right outer side info
					["rightOuterSideInfo"] = { "playerShortAuras" },
					-- what to show on the right inner side info
					["rightInnerSideInfo"] = { "targetShortAuras" },
					-- what to show on the top unit info plate
					["centerUnitInfo1"] =  { "targetInfo" },
					-- what to show on the bottom unit info plate
					["centerUnitInfo2"] =  { "targetOfTargetInfo" },
					-- what to show on the left rectangle frames
					["leftRectangles"] = { "targetBuffs" },
					-- what to show on the right rectangle frames
					["rightRectangles"] = { "targetDebuffs" },
					-- position of icons
					["iconPositions"] = {
						-- position of dragon icon
						["dragon"] = "LEFT",
						-- position of self state icons
						["selfState"] = "LEFT",
						-- position of target state icons
						["targetState"] = "CENTER",
					},
				},
				-- druid overrides
				["DRUID"] = {
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehicleHealth", "tankVengeance", "petHealth" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "druidMana", "druidEclipse", "petPower" },
				},
				-- monk overrides
				["MONK"] = {
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "monkChi", "playerComboPoints" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehicleHealth", "monkStagger", "petHealth" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "monkMana", "petPower" },
				},
				-- warlock overrides
				["WARLOCK"] = {
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "warlockSoulShards", "playerComboPoints" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "warlockBurningEmbers", "warlockDemonicFury", "petPower" },
				},
				-- warrior overrides
				["WARRIOR"] = {
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "tankVengeance" },
				},
				-- paladin overrides
				["PALADIN"] = {
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "paladinHolyPower", "playerComboPoints" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "petPower" },
				},
				-- priest overrides
				["PRIEST"] = {
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "priestShadowOrbs", "playerComboPoints" },
				},
				-- death knight overrides
				["DEATHKNIGHT"] = {
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "deathKnightRunes", "playerComboPoints" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "petPower" },
				},
				-- shaman overrides
				["SHAMAN"] = {
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "shamanTotems", "playerComboPoints" },
				},
			},
			-- layout that shows player on the left and target on the right
			["layout2"] = {
				{
					-- what to show on inner left big bar
					["leftBigBar1"] = { "playerPower" },
					-- what to show on outer left big bar
					["leftBigBar2"] = { "playerHealth" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehicleHealth", "petHealth" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehiclePower", "petPower" },
					-- what to show on inner right big bar
					["rightBigBar1"] = { "targetPower" },
					-- what to show on outer right big bar
					["rightBigBar2"] = { "targetHealth" },
					-- what to show on inner right small bar
					["rightSmallBar1"] = { },
					-- what to show on outer right small bar
					["rightSmallBar2"] = { },
					-- what to show in inner left big cast bar
					["leftBigCastBar1"] = { "playerCastBar" },
					-- what to show on outer left big cast bar
					["leftBigCastBar2"] = { },
					-- what to show on inner right big cast bar
					["rightBigCastBar1"] = { "targetCastBar" },
					-- what to show on outer right big cast bar
					["rightBigCastBar2"] = { },
					-- what to show on the left outer side info
					["leftOuterSideInfo"] = { "playerShortAuras" },
					-- what to show on the left inner side info
					["leftInnerSideInfo"] = { "targetShortAuras" },
					-- what to show on the right outer side info
					["rightOuterSideInfo"] = { "playerComboPoints" },
					-- what to show on the right inner side info
					["rightInnerSideInfo"] = { "playerCooldowns" },
					-- what to show on the top unit info plate
					["centerUnitInfo1"] =  { "targetInfo" },
					-- what to show on the bottom unit info plate
					["centerUnitInfo2"] =  { "targetOfTargetInfo" },
					-- what to show on the left rectangle frames
					["leftRectangles"] = { "targetBuffs" },
					-- what to show on the right rectangle frames
					["rightRectangles"] = { "targetDebuffs" },
					-- position of icons
					["iconPositions"] = {
						-- position of dragon icon
						["dragon"] = "RIGHT",
						-- position of self state icons
						["selfState"] = "LEFT",
						-- position of target state icons
						["targetState"] = "CENTER",
					},
				},
				-- druid overrides
				["DRUID"] = {
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehiclePower", "druidMana", "druidEclipse", "petPower" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehicleHealth", "tankVengeance", "petHealth" },
				},
				-- druid overrides
				["MONK"] = {
					-- what to show on the left outer side info
					["rightOuterSideInfo"] = { "monkChi", "playerComboPoints" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "monkMana", "petPower" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehicleHealth", "monkStagger", "petHealth" },
				},
				-- warlock overrides
				["WARLOCK"] = {
					-- what to show on the left outer side info
					["rightOuterSideInfo"] = { "warlockSoulShards", "playerComboPoints" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehiclePower", "warlockBurningEmbers", "warlockDemonicFury", "petPower" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehicleHealth", "petHealth" },
				},
				-- warrior overrides
				["WARRIOR"] = {
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "petPower" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehicleHealth", "petHealth" },
				},
				-- paladin overrides
				["PALADIN"] = {
					-- what to show on the left outer side info
					["rightOuterSideInfo"] = { "paladinHolyPower", "playerComboPoints" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "petPower" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehicleHealth", "petHealth" },
				},
				-- priest overrides
				["PRIEST"] = {
					-- what to show on the left outer side info
					["rightOuterSideInfo"] = { "priestShadowOrbs", "playerComboPoints" },
				},
				-- death knight overrides
				["DEATHKNIGHT"] = {
					-- what to show on the left outer side info
					["rightOuterSideInfo"] = { "deathKnightRunes", "playerComboPoints" },
					-- what to show on inner left small bar
					["leftSmallBar1"] = { "characterInVehiclePower", "tankVengeance", "petPower" },
					-- what to show on outer left small bar
					["leftSmallBar2"] = { "characterInVehicleHealth", "petHealth" },
				},
				-- shaman overrides
				["SHAMAN"] = {
					-- what to show on the left outer side info
					["rightOuterSideInfo"] = { "shamanTotems", "playerComboPoints" },
				},
			},
		}, 2 },
		-- all other settings that didn't fit to other groups
		["misc"] = { {
			-- allows to animate bars
			["animateBars"] = { true, 0 },
			-- allows to reverse casting bar animation
			["reverseCastingBars"] = { false, 0 },
			-- allows all timers to show milliseconds instead of seconds (when 10 or less seconds left)
			["textTimerShowMilliSeconds"] = { true, 0 },
			-- allows all numbers to be shortened (for numbers that use more than 5 chars)
			["textShortNumbers"] = { true, 0 },
			-- allows to show what you are casting
			["showPlayerCastBarInfo"] = { false, 0 },
			-- allows to show background behind cast bars even if unit wasn't casting any spells
			["alwaysShowCastBarBackground"] = { false, 0 },
			-- allows to store combo-points on targets that are no longer selected
			["storeComboPoints"] = { true, 0 },
			-- allows to show DHUD icon on minimap
			["minimapIcon"] = { true, 0 },
			-- allows to hide DHUD during pet battles
			["hideInPetBattles"] = { true, 0 },
		}, 1 },
		-- service settings that do not affect dhud addon but may contain interesting settings that are provided by some other addons
		["service"] = { {
			-- allows to change level of ui errors, 0 - all errors shown, 1 - ui errors hidden, 2 - ui error frame is hidden (including quest messages)
			["uiErrorFilter"] = { 0, 0, { range = { 0, 2, 1 } } },
			-- lua code to be executed when addon is loaded, can be used to increase camera max distance and set other things
			["luaStartUp"] = { "SetCVar(\"cameraDistanceMaxFactor\", 4);", 0 },
		}, 1 },
	},
	-- settings table in following format: setting = value
	settings = {
	},
	-- custom setters
	setters = {
	},
	-- custom getters
	getters = {
	},
	-- defines if settings preview is active
	previewActive = false,
	-- numeric version of the addon at which saved vars was saved last time
	savedVarsVersion = 0,
	-- table name where additional saved vars are saved
	SAVED_VARS_ADDITIONAL_TABLE_NAME = "_additional",
	-- reference to created frames with settings for blizzard interface addon tab
	blizzardInterfaceAddonTab = nil,
})

--- Custom getter to read frames data settings
function DHUDSettings:getFramesData(name)
	local valueStored = self.settings[name];
	-- setting not exists?
	if (valueStored == nil) then
		return nil;
	end
	-- check not default
	if (valueStored ~= false) then
		return valueStored;
	end
	-- read default table data
	local defaultTable = self:getValueDefaultTable(name);
	local tableInfo = defaultTable[3];
	local groups = tableInfo.groups;
	local lastName = tableInfo.lastName;
	-- read layout data
	local layout = self.settings["framesData_layout"];
	local layoutData = self.default["layouts"][1]["layout" .. layout];
	-- check for class specific value
	local value = nil;
	local class = DHUDDataTrackers.helper.playerClass;
	local table = layoutData[class];
	if (table ~= nil) then
		for i = 2, #groups, 1 do
			table = table[groups[i]];
			if (table == nil) then
				break;
			end
		end
		if (table ~= nil) then
			value = table[lastName];
		end
	end
	if (value ~= nil) then
		return value;
	end
	-- read value for any class
	local table = layoutData[1];
	for i = 2, #groups, 1 do
		table = table[groups[i]];
	end
	value = table[lastName];
	return value;
end

--- Custom setter to set frames layout setting
function DHUDSettings:setFramesDataLayout(name, value)
	local layoutData = self.default["layouts"][1];
	-- layout not exists?
	if (layoutData["layout" .. value] == nil) then
		return;
	end
	-- set layout
	self:setValueInternal(name, value);
	-- set all frames data to default
	local table = self.default["framesData"][1];
	self:resetFramesDataSettings(table);
end

--- helper function for setFramesDataLayout to reset all frame data settings once layout has changed
-- @param table table to reset setting in
function DHUDSettings:resetFramesDataSettings(table)
	for k, v in pairs(table) do
		if (v[2] == self.SETTING_TYPE_CONTAINER) then
			self:resetFramesDataSettings(v[1]);
		else
			local fullname = v[3].fullName;
			if (fullname ~= "framesData_layout") then
				self:setValueInternal(fullname, nil);
			end
		end
	end
end

--- Custom getter to read unit texts settings
function DHUDSettings:getUnitTexts(name)
	local value = self.settings[name];
	if (value == nil) then
		return nil;
	end
	-- check first symbol
	local firstSymbol = value:sub(1, 1);
	if (firstSymbol ~= "@") then
		return value;
	end
	-- check if it uses default value
	if (value == "@default") then
		local infoDefault = self:getValueDefaultTable(name)[3].default;
		local class = DHUDDataTrackers.helper.playerClass;
		if (infoDefault[class] ~= nil) then
			value = infoDefault[class];
		else
			value = infoDefault[1];
		end
	end
	-- return predefined value
	local predefinedName = value:sub(2);
	local predefinedValues = self.default["unitTextsPredefined"][1];
	local predefinedValue = predefinedValues[predefinedName];
	if (predefinedValue ~= nil) then
		return predefinedValue;
	end
	return value;
end

--- Search for custom setter or getter of setting specified
-- @param settingName name of the setting
-- @param funcList list with functions (setters or getters)
-- @return reference to function or nil if no function found
function DHUDSettings:searchCustomSetterOrGetter(settingName, funcList)
	-- search for setting specified
	local func = funcList[settingName];
	if (func ~= nil) then
		return func;
	end
	-- not found, search for rewritten groups
	local groups = { strsplit("_", settingName) };
	table.remove(groups);
	while (#groups > 0) do
		func = funcList[table.concat(groups, "_")];
		if (func ~= nil) then
			return func;
		end
		table.remove(groups);
	end
	return nil;
end

--- Get default value of setting
-- @param settingName name of the setting
-- @param tableDefault this setting default table or nil
-- @return real default value and table default value
function DHUDSettings:getSettingDefaultValue(settingName, tableDefault)
	tableDefault = tableDefault or self:getValueDefaultTable(settingName);
	tableValue = tableDefault[1];
	-- search for getter
	local getter = self:searchCustomSetterOrGetter(settingName, self.getters)
	if (getter == nil) then
		return tableValue, tableValue;
	end
	-- get current value
	local currentVar = self.settings[settingName];
	-- set setting to default and invoke getter
	self.settings[settingName] = tableValue;
	local getterValue = getter(self, settingName);
	-- restore value
	self.settings[settingName] = currentVar;
	-- return calculated default value
	return getterValue, tableValue;
end

--- Defines if settings is set to default value
-- @return true if setting is default, false otherwise
function DHUDSettings:isSettingDefaultValue(settingName)
	local valueStored = self.settings[settingName];
	--print("isSettingDefaultValue settingName " .. settingName .. ", valueStored " .. MCTableToString(valueStored));
	-- setting not exists?
	if (valueStored == nil) then
		return true;
	end
	local tableDefault = self:getValueDefaultTable(settingName);
	--print("isSettingDefaultValue tableDefault[1] " .. MCTableToString(tableDefault[1]));
	return MCCompareTables(valueStored, tableDefault[1]);
end

--- Set value of the setting
-- @param name name of the setting
-- @param value value to set
function DHUDSettings:setValue(name, value)
	local custom = self:searchCustomSetterOrGetter(name, self.setters);
	-- has custom getter?
	if (custom ~= nil) then
		custom(self, name, value);
		return;
	end
	-- set value
	self:setValueInternal(name, value);
end

--- Internal function to set value of the setting, should not be invoked from other classes
-- @param name name of the setting
-- @param value value to set, pass nil for default value
function DHUDSettings:setValueInternal(name, value)
	-- process default value if required
	if (value == nil) then
		self:processDefaultSettingValue(name, self:getValueDefaultTable(name));
		local defaultVar = self.settings[name];
		if (defaultVar ~= nil) then
			self:setValueInternal(name, defaultVar);
		end
	end
	-- value to be saved in saved vars table
	local valueForSavedVars = nil;
	-- get default table
	local tableDefault = self:getValueDefaultTable(name);
	if (tableDefault == nil) then
		return; -- attempt to set setting that doesn't exists
	end
	local tableValue, tableOrigValue = self:getSettingDefaultValue(name, tableDefault);
	local tableType = tableDefault[2];
	local tableInfo = tableDefault[3];
	-- allow to set specific values for some settings that return different value
	if (value == tableOrigValue) then
		value = tableValue;
	end
	-- apply restrictions to value
	value = self:applyRestrictionsToValue(value, tableValue, tableDefault);
	if (value == nil) then
		return; -- attempt to set value that can't be processed
	end
	-- switch by setting type
	-- setting contains single value
	if (tableType == self.SETTING_TYPE_VALUE) then
		-- compare values
		if (value ~= tableValue) then
			valueForSavedVars = value;
		end
	-- setting contains array of fixed size and order
	elseif (tableType == self.SETTING_TYPE_ARRAY_FIXEDORDERSIZE or tableType == self.SETTING_TYPE_ARRAY_FIXEDORDER) then
		-- check array lenghts
		if (#value ~= #tableValue) then
			-- values are different
			valueForSavedVars = value;
		else
			-- compare arrays
			for i, v in ipairs(value) do
				if (v ~= tableValue[i]) then
					-- values are different
					valueForSavedVars = value;
					break;
				end
			end
		end
	-- setting contains list or map, saved vars should contain only difference from it
	elseif (tableType == self.SETTING_TYPE_ARRAY_NOORDERSIZE or tableType == self.SETTING_TYPE_ARRAY_SPELLIDTONAME or tableType == self.SETTING_TYPE_TABLE) then
		local added = { };
		local removed = { };
		local key;
		-- search for removed items
		for i, v in pairs(tableValue) do
			if (tableType == self.SETTING_TYPE_ARRAY_SPELLIDTONAME) then
				v = DHUDDataTrackers.helper:getSpellName(v);
			end
			key = MCFindValueInTable(value, v);
			-- value no longer in table
			if (key == nil) then
				table.insert(removed, v);
			end
		end
		-- search for added items
		for i, v in pairs(value) do
			key = nil;
			-- search if items that were present, using cycle instead of function as we are required to change spellIds to spellNames
			for i2, v2 in pairs(tableValue) do
				if (tableType == self.SETTING_TYPE_ARRAY_SPELLIDTONAME) then
					v2 = DHUDDataTrackers.helper:getSpellName(v2);
				end
				-- check values
				if (v2 == v) then
					key = i2;
					break;
				end
			end
			-- value was not in table
			if (key == nil) then
				table.insert(added, v);
			end
			-- list is changed?
			if (#added > 0 or #removed > 0) then
				valueForSavedVars = { added, removed };
			end
		end
	end
	-- save saved var
	self:getSavedVars()[name] = valueForSavedVars;
	--print("valueForSavedVars " .. MCTableToString(valueForSavedVars));
	-- save
	if (valueForSavedVars ~= nil) then
		self.settings[name] = value;
	else
		self.settings[name] = tableOrigValue;
	end
	-- dispatch events
	-- setting changed event
	self.eventSettingChanged.setting = name;
	self:dispatchEvent(self.eventSettingChanged);
	-- specific setting changed event
	self.eventSpecificSettingChanged.setting = name;
	self.eventSpecificSettingChanged.type = DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. name;
	self:dispatchEvent(self.eventSpecificSettingChanged);
	-- group setting changed event
	self.eventSpecificGroupChanged.setting = name;
	local groupName;
	local parent = tableDefault;
	while (true) do
		parent = parent[3].parent;
		if (parent == nil) then
			break;
		end
		groupName = parent[3].fullName;
		self.eventSpecificGroupChanged.type = DHUDSettingsEvent.EVENT_SPECIFIC_GROUP_SETTING_CHANGED_PREFIX .. groupName;
		self:dispatchEvent(self.eventSpecificGroupChanged);
	end
end

--- Apply restrictions to value
-- @param value value that is going to be saved
-- @param tableValue value in defaults table
-- @param defaultTable table with default data, that contains restrictions on value
-- @return value with restrictions, or nil if value can't be set
function DHUDSettings:applyRestrictionsToValue(value, tableValue, defaultTable)
	local tableType = defaultTable[2];
	local tableInfo = defaultTable[3];
	-- switch by setting type
	-- setting contains single value
	if (tableType == self.SETTING_TYPE_VALUE) then
		-- check if type of variables are the same
		if (type(value) ~= type(tableValue)) then
			return nil;
		end
		-- check if setting has range
		local rangeData = tableInfo.range;
		if (rangeData ~= nil) then
			local minValue = rangeData[1];
			local maxValue = rangeData[2];
			if (value > maxValue) then
				value = maxValue;
			elseif (value < minValue) then
				value = minValue;
			end
		end
	-- all other variables are tables
	else
		if ("table" ~= type(value)) then
			return nil;
		end
		-- setting contains array of fixed size and order
		if (tableType == self.SETTING_TYPE_ARRAY_FIXEDORDERSIZE) then
			-- array lengths should be the same
			if (#value ~= #tableValue) then
				return nil;
			end
			-- variable types should also be the same
			for i, v in ipairs(value) do
				if (type(v) ~= type(tableValue[i])) then
					return nil;
				end
			end
		end
	end
	return value;
end

--- Get value of the setting
-- @param name name of the setting
-- @return value of the setting
function DHUDSettings:getValue(name)
	local custom = self:searchCustomSetterOrGetter(name, self.getters);
	-- has custom getter?
	if (custom ~= nil) then
		return custom(self, name);
	end
	return self.settings[name];
end

--- Get default value of the table
-- @param name name of the setting
-- @return table with default data about this setting
function DHUDSettings:getValueDefaultTable(name)
	local groups = { strsplit("_", name) };
	-- first iteration
	setting = self.default[groups[1]];
	if (setting == nil) then
		return nil;
	end
	-- iterate further
	for i = 2, #groups, 1 do
		setting = setting[1][groups[i]];
		if (setting == nil) then
			return nil;
		end
	end
	return setting;
end

--- Get reference to data tracker by name
-- @param dataTrackerName name of the data tracker
-- @return reference to data tracker
function DHUDSettings:getDataTrackerByName(dataTrackerName)
	local trackersTable = self.default.framesDataSources[1].dataTrackersMap;
	return trackersTable[dataTrackerName];
end

--- Convert data tracker names array to reference array, always constructs new table
-- @param namesArray array with names
-- @return array with references
function DHUDSettings:convertDataTrackerNamesArrayToReferenceArray(namesArray)
	local refArray = { };
	for i, v in ipairs(namesArray) do
		local dt = self:getDataTrackerByName(v);
		if (dt ~= nil and dt[1] ~= nil) then
			table.insert(refArray, dt);
		end
	end
	return refArray;
end

--- Map data trackers to table values
function DHUDSettings:mapDataTrackers()
	local trackersTable = self.default.framesDataSources[1].dataTrackersMap;
	trackersTable["playerHealth"] = { DHUDDataTrackers.ALL.selfHealth };
	trackersTable["targetHealth"] = { DHUDDataTrackers.ALL.targetHealth };
	trackersTable["characterInVehicleHealth"] = { DHUDDataTrackers.ALL.selfCharInVehicleHealth };
	trackersTable["petHealth"] = { DHUDDataTrackers.ALL.petHealth };
	trackersTable["playerPower"] = { DHUDDataTrackers.ALL.selfPower };
	trackersTable["targetPower"] = { DHUDDataTrackers.ALL.targetPower };
	trackersTable["characterInVehiclePower"] = { DHUDDataTrackers.ALL.selfCharInVehiclePower };
	trackersTable["petPower"] = { DHUDDataTrackers.ALL.petPower };
	trackersTable["playerComboPoints"] = { DHUDDataTrackers.ALL.selfComboPoints };
	trackersTable["playerCooldowns"] = { DHUDDataTrackers.ALL.selfCooldowns, DHUDTimersFilterHelperSettingsHandler.filterPlayerCooldowns };
	trackersTable["playerShortAuras"] = { DHUDDataTrackers.ALL.selfAuras, DHUDTimersFilterHelperSettingsHandler.filterPlayerShortAuras };
	trackersTable["targetShortAuras"] = { DHUDDataTrackers.ALL.targetAuras, DHUDTimersFilterHelperSettingsHandler.filterTargetShortAuras };
	trackersTable["targetInfo"] = { DHUDDataTrackers.ALL.targetInfo };
	trackersTable["targetOfTargetInfo"] = { DHUDDataTrackers.ALL.targetOfTargetInfo };
	trackersTable["targetBuffs"] = { DHUDDataTrackers.ALL.targetAuras, DHUDTimersFilterHelperSettingsHandler.filterBuffAuras };
	trackersTable["targetDebuffs"] = { DHUDDataTrackers.ALL.targetAuras, DHUDTimersFilterHelperSettingsHandler.filterDebuffAuras };
	trackersTable["playerCastBar"] = { DHUDDataTrackers.ALL.selfCast };
	trackersTable["targetCastBar"] = { DHUDDataTrackers.ALL.targetCast };
	trackersTable["tankVengeance"] = { DHUDDataTrackers.ALL.vengeanceInfo };
	-- specific to druid
	trackersTable["druidMana"] = { DHUDDataTrackers.DRUID.selfMana };
	trackersTable["druidEnergy"] = { DHUDDataTrackers.DRUID.selfEnergy };
	trackersTable["druidEclipse"] = { DHUDDataTrackers.DRUID.selfEclipse };
	-- specific to monk
	trackersTable["monkMana"] = { DHUDDataTrackers.MONK.selfMana };
	trackersTable["monkEnergy"] = { DHUDDataTrackers.MONK.selfEnergy };
	trackersTable["monkChi"] = { DHUDDataTrackers.MONK.selfChi };
	trackersTable["monkStagger"] = { DHUDDataTrackers.MONK.selfStagger };
	-- specific to warlock
	trackersTable["warlockSoulShards"] = { DHUDDataTrackers.WARLOCK.selfSoulShards };
	trackersTable["warlockBurningEmbers"] = { DHUDDataTrackers.WARLOCK.selfBurningEmbers };
	trackersTable["warlockDemonicFury"] = { DHUDDataTrackers.WARLOCK.selfDemonicFury };
	-- specific to paladin
	trackersTable["paladinHolyPower"] = { DHUDDataTrackers.PALADIN.selfHolyPower };
	-- specific to priest
	trackersTable["priestShadowOrbs"] = { DHUDDataTrackers.PRIEST.selfShadowOrbs };
	-- specific to death knight
	trackersTable["deathKnightRunes"] = { DHUDDataTrackers.DEATHKNIGHT.selfRunes };
	-- specific to shaman
	trackersTable["shamanTotems"] =  { DHUDDataTrackers.SHAMAN.selfTotems, DHUDTimersFilterHelperSettingsHandler.filterTotemGuardians };
end

--- Initialize single setting from table
-- @param tableName name of the table
-- @param tableContent table contents to be processed
-- @param parent table, that is parent to this setting
-- @param groupArray array with groups that are parents to this setting
function DHUDSettings:processDefaultSetting(tableName, tableContent, parent, groupArray)
	--print("tableName " .. tableName);
	local tableValue = tableContent[1];
	local tableType = tableContent[2];
	local tableInfo = tableContent[3];
	-- update value full name and groups list
	if (tableInfo == nil) then
		tableInfo = { };
		tableContent[3] = tableInfo;
	end
	local fullName = tableName;
	if (#groupArray > 0) then
		fullName = table.concat(groupArray, "_") .. "_" .. tableName;
	end
	tableInfo["groups"] = groupArray;
	tableInfo["lastName"] = tableName;
	tableInfo["fullName"] = fullName;
	tableInfo["parent"] = parent;
	-- references should not be copied
	if (tableType == self.SETTING_TYPE_CONTAINER_REFERENCE) then
		return;
	-- containers should be processed further
	elseif (tableType == self.SETTING_TYPE_CONTAINER) then
		local containerGroup = MCCreateTableCopy(groupArray);
		table.insert(containerGroup, tableName);
		-- process
		for i, v in pairs(tableValue) do
			self:processDefaultSetting(i, v, tableContent, containerGroup);
		end
		return;
	end
	self:processDefaultSettingValue(fullName, tableContent);
end

--- Save contents of default table to settings table
-- @param fullName fullName of the setting
-- @param defaultTableContent table with default data about setting
function DHUDSettings:processDefaultSettingValue(fullName, defaultTableContent)
	local tableValue = defaultTableContent[1];
	local tableType = defaultTableContent[2];
	-- process setting if required
	if (tableType ~= self.SETTING_TYPE_VALUE) then
		tableValue = MCCreateTableDeepCopy(tableValue);
	end
	-- process spell ids
	if (tableType == self.SETTING_TYPE_ARRAY_SPELLIDTONAME) then
		for i, v in ipairs(tableValue) do
			tableValue[i] = DHUDDataTrackers.helper:getSpellName(v);
		end
	end
	-- save to settings table
	self.settings[fullName] = tableValue;
end

--- Initialize settings table with default table
function DHUDSettings:processDefaultSettingsTable()
	for i, v in pairs(self.default) do
		self:processDefaultSetting(i, v, nil, { });
	end
end

--- Process saved vars table and fill settings table with changes from it
function DHUDSettings:processSavedVars()
	local savedVars = self:getSavedVars();
	-- read version
	local version = savedVars["version"] or 0;
	-- process saved vars
	local defaultTable, settingType, settingDefaultValue, settingInfo;
	-- iterate
	for k, v in pairs(savedVars) do
		-- get default table
		defaultTable = self:getValueDefaultTable(k);
		-- value exists?
		if (defaultTable ~= nil) then
			settingType = defaultTable[2];
			settingDefaultValue = self:getSettingDefaultValue(k, tableDefault);
			settingInfo = defaultTable[3];
			-- apply restrictions
			v = self:applyRestrictionsToValue(v, settingDefaultValue, defaultTable);
			if (v ~= nil) then
				-- standard setting?
				if (settingType == self.SETTING_TYPE_VALUE or settingType == self.SETTING_TYPE_ARRAY_FIXEDORDERSIZE or settingType == self.SETTING_TYPE_ARRAY_FIXEDORDER) then
					self.settings[k] = v;
				-- list setting, variable contains arrays with added and removed values
				else
					local list = self.settings[k];
					local added = v[1];
					local removed = v[2];
					local key;
					-- process removed vars
					for i2, v2 in ipairs (removed) do
						key = MCFindValueInTable(list, v2);
						if (key ~= nil) then
							table.remove(list, key);
						end
					end
					-- process added vars
					for i2, v2 in ipairs (added) do
						key = MCFindValueInTable(list, v2);
						if (key == nil) then
							table.insert(list, v2);
						end
					end
					-- save
					self.settings[k] = list;
				end
			end
		-- setting no longer exists
		else
			-- remove unused setting
			if (k ~= self.SAVED_VARS_ADDITIONAL_TABLE_NAME) then
				savedVars[k] = nil;
			end
		end
	end
	-- save version
	savedVars["version"] = DHUDMain.versionInt;
end

--- Initialize custom setters and getters
function DHUDSettings:initCustomSettersAndGetters()
	self.getters["framesData"] = self.getFramesData;
	self.getters["unitTexts"] = self.getUnitTexts;
	self.setters["framesData_layout"] = self.setFramesDataLayout;
end

--- Initialize settings hadler, addon saved variables are loaded at this moment
function DHUDSettings:init()
	-- construct event dispatcher
	self:constructor();
	-- create table with settings if none
	if (not DHUD_SavedVars) then
        DHUD_SavedVars = { };
    end
	-- create events
	self.eventSettingChanged = DHUDSettingsEvent:new(DHUDSettingsEvent.EVENT_SETTING_CHANGED);
	self.eventSpecificSettingChanged = DHUDSettingsEvent:new(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX);
	self.eventSpecificGroupChanged = DHUDSettingsEvent:new(DHUDSettingsEvent.EVENT_SPECIFIC_GROUP_SETTING_CHANGED_PREFIX);
	self.eventStartPreview = DHUDSettingsEvent:new(DHUDSettingsEvent.EVENT_START_PREVIEW);
	self.eventStopPreview = DHUDSettingsEvent:new(DHUDSettingsEvent.EVENT_STOP_PREVIEW);
	-- init settings
	self:mapDataTrackers();
	self:processDefaultSettingsTable();
	self:initCustomSettersAndGetters();
	-- read saved vars
	self:processSavedVars();
	-- init non-addon specific settings handler
	DHUDNonAddonSettingsHandler:init();
	-- init timer filter functions
	DHUDTimersFilterHelperSettingsHandler:init();
end

--- Print contents of the table specified to string, used for debugging purposes
-- @param name name of the table
-- @param settings table with settings to print
function DHUDSettings:printSettingTableToString(name, settings)
	local result = "Contents of " .. name .. ":";
	-- sort keys
	local keys = { };
	for k, v in pairs(settings) do
		table.insert(keys, k);
	end
	table.sort(keys);
	-- print values
	for i, k in ipairs(keys) do
		result = result .. "\n  " .. k .. ": " .. MCTableToString(settings[k]);
	end
	return result;
end

--- Function to reset settings to default values
function DHUDSettings:resetToDefaults()
	for k, v in pairs(self.settings) do
		self:setValueInternal(k, nil);
	end
end

--- Function to reload saved vars, they can be modified by dhud options addon
function DHUDSettings:reloadSavedVars()
	-- copy setting table
	local settingsCopy = MCCreateTableDeepCopy(self.settings);
	-- read saved vars
	self:processDefaultSettingsTable();
	self:processSavedVars();
	-- redispatch events for required settings
	for k, v in pairs(settingsCopy) do
		if (MCCompareTables(v, self.settings[k]) == false) then
			self:setValueInternal(k, self.settings[k]);
		end
	end
end

--- Start preview of current settings
function DHUDSettings:previewStart()
	if (self.previewActive) then
		return;
	end
	self.previewActive = true;
	self:dispatchEvent(self.eventStartPreview);
end

--- Stop preview of current settings
function DHUDSettings:previewStop()
	if (not self.previewActive) then
		return;
	end
	self.previewActive = false;
	self:dispatchEvent(self.eventStopPreview);
end

--- Function to get table with additional saved vars, it may contain other addon data or some statistic data
-- @param tableName name of the sub table, pass nil to get whole additional saved vars table
-- @return table with additional saved vars
function DHUDSettings:getAdditionalSavedVars(tableName)
	local savedVars = self:getSavedVars();
	local additional = savedVars[self.SAVED_VARS_ADDITIONAL_TABLE_NAME];
	if (additional == nil) then
		additional = { };
		savedVars[self.SAVED_VARS_ADDITIONAL_TABLE_NAME] = additional;
	end
	if (tableName == nil) then
		return additional;
	end
	local subTable = additional[tableName];
	if (subTable == nil) then
		subTable = { };
		additional[tableName] = subTable;
	end
	return subTable;
end

-- temprorary variable for saved vars
DHUD_SAVED_VARS_TEMP = { ["scale_main"] = 0.8, ["scale_resource"] = 1.0, ["scale_spellCircles"] = 1.0, ["shortAurasOptions_targetAurasWhiteList"] = { {"CustomSpell1"}, {"spellName48792"} }, ["shortAurasOptions_aurasTimeLeftMax"] = 240,
						["outlines_spellCirclesTime"] = 0, ["outlines_spellCirclesStacks"] = 0, ["shortAurasOptions_cooldownsBlackList"] = { {"<slot:10>"}, { } }, };

--- get table with saved vars
function DHUDSettings:getSavedVars()
	--return DHUD_SAVED_VARS_TEMP;
	return DHUD_SavedVars;
end

--------------------------
-- Timers filter helper --
--------------------------

--- Class to filter timers trackers according to settings
DHUDTimersFilterHelperSettingsHandler = {
	-- white list with player auras
	whiteListPlayerAuras = {
	},
	-- black list with player auras
	blackListPlayerAuras = {
	},
	-- priority list with player auras
	priorityListPlayerAuras = {
	},
	-- white list with target auras
	whiteListTargetAuras = {
	},
	-- black list with target auras
	blackListTargetAuras = {
	},
	-- priority list with target auras
	priorityListTargetAuras = {
	},
	-- white list with target cooldowns
	whiteListPlayerCooldowns = {
	},
	-- black list with player cooldowns
	blackListPlayerCooldowns = {
	},
	-- priority list with player cooldowns
	priorityListPlayerCooldowns = {
	},
	-- show auras with charges?
	aurasWithCharges = false,
	-- allows to show item cooldowns
	cooldownsItem = false,
	-- auras maximum time left
	aurasTimeLeftMax = 0,
	-- allows to show short player debuffs
	playerDebuffs = false,
	-- cooldowns minimum duration
	cooldownsDurationMin = 0,
	-- cooldowns maximum duration
	cooldownsDurationMax = 0,
}

--- Filter player auras list to show only short auras (not a class function, self is nil!)
-- @param timer timer to filter { type, timeLeft, duration, id, tooltipId, name, stacks, texture, exists, iterating, sortOrder }
-- @return nil if timer is not required or number for timer sorting order
function DHUDTimersFilterHelperSettingsHandler.filterPlayerShortAuras(timer)
	local self = DHUDTimersFilterHelperSettingsHandler;
	local name = timer[6];
	-- check blacklist
	if (self.blackListPlayerAuras[name] ~= nil) then
		return nil;
	end
	-- check white list
	if (self.whiteListPlayerAuras[name] == nil) then
		-- do not show debuffs?
		if (not self.playerDebuffs and (bit.band(timer[1], DHUDAurasTracker.TIMER_TYPE_MASK_DEBUFF) ~= 0)) then
			return nil;
		end
		-- if duration is too high or stack count is low - return
		if ((timer[2] > self.aurasTimeLeftMax or timer[2] < 0) and (not self.aurasWithCharges or timer[7] < 1)) then
			return nil;
		end
	end
	local priority = self.priorityListPlayerAuras[name];
	if (priority ~= nil) then
		return priority;
	end
	return (bit.band(timer[1], DHUDAurasTracker.TIMER_TYPE_MASK_BUFF) ~= 0) and 1001 or 1002;
end

--- Filter target auras list to show only short auras (not a class function, self is nil!)
-- @param timer timer to filter { type, timeLeft, duration, id, tooltipId, name, stacks, texture, exists, iterating, sortOrder }
-- @return nil if timer is not required or number for timer sorting order
function DHUDTimersFilterHelperSettingsHandler.filterTargetShortAuras(timer)
	local self = DHUDTimersFilterHelperSettingsHandler;
	local name = timer[6];
	-- check blacklist
	if (self.blackListTargetAuras[name] ~= nil) then
		return nil;
	end
	-- check white list
	if (self.whiteListTargetAuras[name] == nil) then
		-- show only player applied spells
		local mask = DHUDAurasTracker.TIMER_TYPE_MASK_IS_CAST_BY_PLAYER; -- DHUDAurasTracker.TIMER_TYPE_MASK_DEBUFF + 
		--print("name is " .. timer[6] .. ", type is " .. timer[1]);
		if (bit.band(timer[1], mask) ~= mask) then
			return nil;
		end
		-- if duration is too high or stack count is low - return
		if ((timer[2] > self.aurasTimeLeftMax or timer[2] < 0) and (not self.aurasWithCharges or timer[7] < 1)) then
			return nil;
		end
	end
	local priority = self.priorityListTargetAuras[name];
	if (priority ~= nil) then
		return priority;
	end
	return (bit.band(timer[1], DHUDAurasTracker.TIMER_TYPE_MASK_IS_CAST_BY_PLAYER) ~= 0) and 1001 or 1002;
end

--- Filter only buff auras
-- @param timer timer to filter { type, timeLeft, duration, id, tooltipId, name, stacks, texture, exists, iterating, sortOrder }
-- @return nil if timer is not required or number for timer sorting order
function DHUDTimersFilterHelperSettingsHandler.filterBuffAuras(timer)
	local self = DHUDTimersFilterHelperSettingsHandler;
	if (bit.band(timer[1], DHUDAurasTracker.TIMER_TYPE_MASK_BUFF) == 0) then
		return nil;
	end
	return 1;
end

--- Filter only debuff auras
-- @param timer timer to filter { type, timeLeft, duration, id, tooltipId, name, stacks, texture, exists, iterating, sortOrder }
-- @return nil if timer is not required or number for timer sorting order
function DHUDTimersFilterHelperSettingsHandler.filterDebuffAuras(timer)
	local self = DHUDTimersFilterHelperSettingsHandler;
	if (bit.band(timer[1], DHUDAurasTracker.TIMER_TYPE_MASK_DEBUFF) == 0) then
		return nil;
	end
	--print("name is " .. timer[6] .. ", type is " .. timer[1]);
	return 1;
end

--- Filter player cooldowns list to show only short cooldowns (not a class function, self is nil!)
-- @param timer timer to filter { type, timeLeft, duration, id, tooltipId, name, stacks, texture, exists, iterating, sortOrder }
-- @return nil if timer is not required or number for timer sorting order
function DHUDTimersFilterHelperSettingsHandler.filterPlayerCooldowns(timer)
	local self = DHUDTimersFilterHelperSettingsHandler;
	local name = timer[6];
	local isItem = bit.band(timer[1], DHUDCooldownsTracker.TIMER_TYPE_MASK_ITEM) ~= 0;
	local slotId = timer[5];
	--print("timer is " .. MCTableToString(timer));
	--print("item black list " .. MCTableToString(self.blackListPlayerCooldowns["_slot"]) .. ", id " .. MCTableToString(timer[5]) .. ", isBlacklisted " .. MCTableToString(self.blackListPlayerCooldowns["_slot"][timer[5]] == true));
	-- check blacklist
	if (self.blackListPlayerCooldowns[name] ~= nil or (isItem and self.blackListPlayerCooldowns["_slot"][slotId] ~= nil)) then
		return nil;
	end
	-- check white list
	if (self.whiteListPlayerCooldowns[name] == nil and ((not isItem) or self.whiteListPlayerCooldowns["_slot"][slotId] == nil)) then
		-- if duration is too high or too low then return
		if (timer[3] < self.cooldownsDurationMin or timer[3] > self.cooldownsDurationMax or (isItem and (not self.cooldownsItem))) then
			return nil;
		end
	end
	--print("priorityListPlayerCooldowns " .. MCTableToString(self.priorityListPlayerCooldowns));
	local priority = self.priorityListPlayerCooldowns[name] or (isItem and self.priorityListPlayerCooldowns["_slot"][slotId] or nil);
	if (priority ~= nil) then
		return priority;
	end
	return (bit.band(timer[1], DHUDCooldownsTracker.TIMER_TYPE_MASK_SPELL) ~= 0) and 1001 or 1002;
end

--- Filter totem guardians
-- @param timer timer to filter { type, timeLeft, duration, id, tooltipId, name, stacks, texture, exists, iterating, sortOrder }
-- @return nil if timer is not required or number for timer sorting order
function DHUDTimersFilterHelperSettingsHandler.filterTotemGuardians(timer)
	local self = DHUDTimersFilterHelperSettingsHandler;
	return (bit.band(timer[1], DHUDGuardiansTracker.TIMER_TYPE_MASK_ACTIVE) ~= 0) and 1 or 2;
end

--- Process setting with white or black list
-- @param settingName name of the setting
-- @param tableName name of the table to fill
-- @param additionalProcessFunc function to make additional list processing (invoked with table argument)
function DHUDTimersFilterHelperSettingsHandler:processSpellListSetting(settingName, tableName, additionalProcessFunc)
	local process = function(self, e)
		local list = DHUDSettings:getValue(settingName);
		local table = self[tableName];
		-- remove all previous values
		for k, v in pairs(table) do
			table[k] = nil;
		end
		-- save new values
		for i, v in ipairs(list) do
			table[v] = i;
		end
		-- process table
		if (additionalProcessFunc ~= nil) then
			additionalProcessFunc(self, table);
		end
		--print("settingName " .. settingName .. ", table " .. MCTableToString(table));
	end
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. settingName, self, process);
	process(self, nil);
end

--- Process setting with condition
-- @param settingName name of the setting
-- @param varName name of the variable to fill
function DHUDTimersFilterHelperSettingsHandler:processConditionSetting(settingName, varName)
	local process = function(self, e)
		self[varName] = DHUDSettings:getValue(settingName);
	end
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. settingName, self, process);
	process(self, nil);
end

--- Process table with spells, adding items list
-- @param t name of the setting
function DHUDTimersFilterHelperSettingsHandler:processItemSlotList(t)
	local slots = { };
	--print("item table " .. MCTableToString(t));
	for k, v in pairs(t) do
		-- check syntaxis
		local indexS, indexE = strfind(k, "<slot:.->", 0); -- search for "<slot:13>" text
		if (indexS ~= nil) then
			local slot = strsub(k, indexS + 6, indexE - 1);
			slot = tonumber(slot); -- required as number
			--print("found slot " .. slot);
			slots[slot] = v;
		end
	end
	t["_slot"] = slots;
end

--- initialize timers filter settings handler
function DHUDTimersFilterHelperSettingsHandler:init()
	-- spell lists
	self:processSpellListSetting("shortAurasOptions_playerAurasWhiteList", "whiteListPlayerAuras");
	self:processSpellListSetting("shortAurasOptions_playerAurasBlackList", "blackListPlayerAuras");
	self:processSpellListSetting("shortAurasOptions_playerAurasPriorityList", "priorityListPlayerAuras");
	self:processSpellListSetting("shortAurasOptions_targetAurasWhiteList", "whiteListTargetAuras");
	self:processSpellListSetting("shortAurasOptions_targetAurasBlackList", "blackListTargetAuras");
	self:processSpellListSetting("shortAurasOptions_targetAurasPriorityList", "priorityListTargetAuras");
	self:processSpellListSetting("shortAurasOptions_cooldownsWhiteList", "whiteListPlayerCooldowns", self.processItemSlotList);
	self:processSpellListSetting("shortAurasOptions_cooldownsBlackList", "blackListPlayerCooldowns", self.processItemSlotList);
	self:processSpellListSetting("shortAurasOptions_cooldownsPriorityList", "priorityListPlayerCooldowns", self.processItemSlotList);
	-- conditions
	self:processConditionSetting("shortAurasOptions_aurasWithCharges", "aurasWithCharges");
	self:processConditionSetting("shortAurasOptions_aurasTimeLeftMax", "aurasTimeLeftMax");
	self:processConditionSetting("shortAurasOptions_playerDebuffs", "playerDebuffs");
	self:processConditionSetting("shortAurasOptions_cooldownsDurationMin", "cooldownsDurationMin");
	self:processConditionSetting("shortAurasOptions_cooldownsDurationMax", "cooldownsDurationMax");
	self:processConditionSetting("shortAurasOptions_cooldownsItem", "cooldownsItem");
end

-------------------------------------
-- Settings slash commands handler --
-------------------------------------

--- Initialize slash commands handling
function DHUDSettings:SlashCommandHandlerInit()
	
end

--- Handler for commands passed from chat using "/dhud"
-- @param args string with variable to set or read
function DHUDSettings:SlashCommandHandler(args)
	if (args == nil) then
		args = "";
	end
	local removeLeadingAndTrailingWhiteSpace = "^%s*(.-)%s*$";
	-- process arguments
	local indexOfEquals = string.find(args, "=");
	local variableName;
	local variableValue;
	-- found equals sign?
	if (indexOfEquals ~= nil) then
		variableName = string.sub(args, 1, indexOfEquals - 1);
		variableValue = string.sub(args, indexOfEquals + 1);
		variableValue = variableValue:match(removeLeadingAndTrailingWhiteSpace);
	else
		variableName = args;
		variableValue = nil;
	end
	variableName = variableName:match(removeLeadingAndTrailingWhiteSpace);
	-- check variable existance
	if (self.settings[variableName] == nil) then
		print("Requested variable not found, printing setting table...");
		print(self:printSettingTableToString("settings", self.settings));
		return;
	end
	-- set variable?
	if (variableValue ~= nil) then
		print("Setting variable " .. variableName .. " to: " .. variableValue);
		local evalFunc = loadstring("return " .. variableValue, "DHUD settings text input");
		if (evalFunc ~= nil) then
			variableValue = evalFunc();
		end
		self:setValue(variableName, variableValue);
		print("Variable " .. variableName .. " is set to: " .. MCTableToString(self:getValue(variableName)));
	else
		print("Reading variable " .. variableName .. ": " .. MCTableToString(self:getValue(variableName)));
	end
end

-----------------------------
-- Blizzard interface menu --
-----------------------------

--- Create addon tab in blizzard interface menu
function DHUDSettings:createBlizzardInterfaceOptions()
	-- frame with settings
	local frame = CreateFrame("Frame", "DHUD_InterfaceOptions");
	frame.name = "DHUD";
	-- title frame
	local textField = frame:CreateFontString("DHUD_InterfaceOptions_TitleText", "ARTWORK", "GameFontNormalLarge");
	textField:SetText("DHUD");
	textField:SetJustifyH("LEFT");
	textField:SetJustifyV("TOP");
	textField:SetPoint("TOPLEFT", 16, -16);
	frame.titleTextField = textField;
	-- open options button
	local button = CreateFrame("Button", "DHUD_InterfaceOptions_OpenOptionsButton", frame, "OptionsButtonTemplate");
	button:SetText("Open Options");
	button:SetWidth(180);
	button:SetHeight(22);
	button:SetPoint("TOPLEFT", frame.titleTextField, "BOTTOMLEFT", 0, -10);
	button:SetScript("OnClick", function()
		InterfaceOptionsFrame_Show();
		HideUIPanel(GameMenuFrame);
		DHUDMain:openSettings();
	end)
	-- slash command text
	local textField = frame:CreateFontString("DHUD_InterfaceOptions_SlashTipText", "ARTWORK", "GameFontNormalSmall");
	textField:SetText("/dhud");
	textField:SetNonSpaceWrap(true);
	textField:SetPoint("LEFT", button, "RIGHT", 10, 0);
	textField:SetTextColor(1, 1, 0.49, 1);
	frame.slashTextField = command;
	
	-- add to options
	self.blizzardInterfaceAddonTab = frame;
	InterfaceOptions_AddCategory(frame);
end

-----------------------------------------
-- Non Addon Specific Settings Handler --
-----------------------------------------

--- Class to handle settings that are not addon specific, e.g. showing/hiding blizzard frames
DHUDNonAddonSettingsHandler = {
	-- events frame to listen to game events
	eventsFrame = nil,
	-- required alpha for blizzard power auras, this value will be set to frame when required
	blizzardPowerAurasAlpha = 1,
	-- required scale for blizzard power auras, this value will be set to frame when required
	blizzardPowerAurasScale = 1,
	-- name of the setting that changes visibility of the player frame
	SETTING_NAME_BLIZZARD_PLAYER = "blizzardFrames_playerFrame",
	-- name of the setting that changes visibility of the target frame
	SETTING_NAME_BLIZZARD_TARGET = "blizzardFrames_targetFrame",
	-- name of the setting that changes visibility of the castbar frame
	SETTING_NAME_BLIZZARD_CASTBAR = "blizzardFrames_castingFrame",
	-- name of the setting that changes alpha of SpellActivationOverlayFrame
	SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_ALPHA = "blizzardFrames_spellActivationFrameAlpha",
	-- name of the setting that changes scale of SpellActivationOverlayFrame
	SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_SCALE = "blizzardFrames_spellActivationFrameScale",
	-- name of the setting that changes level of ui errors filtering
	SETTING_NAME_SERVICE_UI_ERROR_FILTER = "service_uiErrorFilter",
	-- name of the setting that contains code to be executed on start up
	SETTING_NAME_SERVICE_LUA_START_UP = "service_luaStartUp",
}

-- value of the setting has changed
function DHUDNonAddonSettingsHandler:onBlizzardPlayerFrameChange(e)
	local val = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_PLAYER);
	if (val) then
		self:showBlizzardPlayerFrame();
	else
		self:hideBlizzardPlayerFrame();
	end
end

-- value of the setting has changed
function DHUDNonAddonSettingsHandler:onBlizzardTargetFrameChange(e)
	local val = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_TARGET);
	if (val) then
		self:showBlizzardTargetFrame();
	else
		self:hideBlizzardTargetFrame();
	end
end

-- value of the setting has changed
function DHUDNonAddonSettingsHandler:onBlizzardCastbarFrameChange(e)
	local val = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_CASTBAR);
	if (val) then
		self:showBlizzardCastingFrame();
	else
		self:hideBlizzardCastingFrame();
	end
end

-- value of the setting has changed
function DHUDNonAddonSettingsHandler:onBlizzardSpellActivationFrameAlphaChange(e)
	self.blizzardPowerAurasAlpha = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_ALPHA);
	-- update frame
	self:updateBlizzardPowerAurasFrame();
end

-- value of the setting has changed
function DHUDNonAddonSettingsHandler:onBlizzardSpellActivationFrameScaleChange(e)
	self.blizzardPowerAurasScale = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_SCALE);
	-- update frame
	self:updateBlizzardPowerAurasFrame();
end

-- value of the setting has changed
function DHUDNonAddonSettingsHandler:onServiceUIErrorLevelChange(e)
	local val = DHUDSettings:getValue(self.SETTING_NAME_SERVICE_UI_ERROR_FILTER);
	self:changeServiceUIErrorFiltering(val);
end

--- initialize non addon specific settings handler
function DHUDNonAddonSettingsHandler:init()
	-- events frame
	self.eventsFrame = MCCreateBlizzEventFrame();
	-- read settings
	local playerFrameVisible = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_PLAYER);
	local targetFrameVisible = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_TARGET);
	local castbarFrameVisible = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_CASTBAR);
	local uiErrorsLevel = DHUDSettings:getValue(self.SETTING_NAME_SERVICE_UI_ERROR_FILTER);
	local luaStartUp = DHUDSettings:getValue(self.SETTING_NAME_SERVICE_LUA_START_UP);
	self.blizzardPowerAurasAlpha = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_ALPHA);
	self.blizzardPowerAurasScale = DHUDSettings:getValue(self.SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_SCALE);
	-- listen to events
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. self.SETTING_NAME_BLIZZARD_PLAYER, self, self.onBlizzardPlayerFrameChange);
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. self.SETTING_NAME_BLIZZARD_TARGET, self, self.onBlizzardTargetFrameChange);
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. self.SETTING_NAME_BLIZZARD_CASTBAR, self, self.onBlizzardCastbarFrameChange);
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. self.SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_ALPHA, self, self.onBlizzardSpellActivationFrameAlphaChange);
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. self.SETTING_NAME_BLIZZARD_SPELL_ACTIVATION_SCALE, self, self.onBlizzardSpellActivationFrameScaleChange);
	DHUDSettings:addEventListener(DHUDSettingsEvent.EVENT_SPECIFIC_SETTING_CHANGED_PREFIX .. self.SETTING_NAME_SERVICE_UI_ERROR_FILTER, self, self.onServiceUIErrorLevelChange);
	-- register to power auras event
	self.eventsFrame:RegisterEvent("SPELL_ACTIVATION_OVERLAY_SHOW");
	-- process power auras event
	function self.eventsFrame:SPELL_ACTIVATION_OVERLAY_SHOW()
		DHUDNonAddonSettingsHandler:updateBlizzardPowerAurasFrame();
	end
	self:updateBlizzardPowerAurasFrame();
	-- hide frames if required
	if (not playerFrameVisible) then
		self:hideBlizzardPlayerFrame();
	end
	if (not targetFrameVisible) then
		self:hideBlizzardTargetFrame();
	end
	if (not castbarFrameVisible) then
		self:hideBlizzardCastingFrame();
	end
	-- process service settings if required
	if (uiErrorsLevel ~= 0) then
		self:changeServiceUIErrorFiltering(uiErrorsLevel);
	end
	if (luaStartUp ~= "") then
		self:processLuaStartUpCode(luaStartUp);
	end
end

--- Function to show blizzard player frame
function DHUDNonAddonSettingsHandler:showBlizzardPlayerFrame()
	PlayerFrame:RegisterEvent("UNIT_LEVEL");
    PlayerFrame:RegisterEvent("UNIT_COMBAT");
    PlayerFrame:RegisterEvent("UNIT_SPELLMISS");
    PlayerFrame:RegisterEvent("UNIT_PVP_UPDATE");
    PlayerFrame:RegisterEvent("UNIT_MAXMANA");
    PlayerFrame:RegisterEvent("PLAYER_ENTER_COMBAT");
    PlayerFrame:RegisterEvent("PLAYER_LEAVE_COMBAT");
    PlayerFrame:RegisterEvent("PLAYER_UPDATE_RESTING");
    PlayerFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
    PlayerFrame:RegisterEvent("PARTY_LEADER_CHANGED");
    PlayerFrame:RegisterEvent("PARTY_LOOT_METHOD_CHANGED");
    PlayerFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
    PlayerFrame:RegisterEvent("PLAYER_REGEN_DISABLED");
    PlayerFrame:RegisterEvent("PLAYER_REGEN_ENABLED");
    PlayerFrameHealthBar:RegisterEvent("UNIT_HEALTH");
    PlayerFrameHealthBar:RegisterEvent("UNIT_MAXHEALTH");
    PlayerFrameManaBar:RegisterEvent("UNIT_POWER");
    PlayerFrameManaBar:RegisterEvent("UNIT_DISPLAYPOWER");
    PlayerFrame:RegisterEvent("UNIT_NAME_UPDATE");
    PlayerFrame:RegisterEvent("UNIT_PORTRAIT_UPDATE");
    PlayerFrame:RegisterEvent("UNIT_DISPLAYPOWER");
    PlayerFrame:Show();
	if (DHUDDataTrackers.helper.playerClass == "DEATHKNIGHT") then
		RuneFrame:Show();
	end
end

--- Function to hide blizzard player frame
function DHUDNonAddonSettingsHandler:hideBlizzardPlayerFrame()
	PlayerFrame:UnregisterEvent("UNIT_LEVEL");
	PlayerFrame:UnregisterEvent("UNIT_COMBAT");
	PlayerFrame:UnregisterEvent("UNIT_SPELLMISS");
	PlayerFrame:UnregisterEvent("UNIT_PVP_UPDATE");
	PlayerFrame:UnregisterEvent("UNIT_MAXMANA");
	PlayerFrame:UnregisterEvent("PLAYER_ENTER_COMBAT");
	PlayerFrame:UnregisterEvent("PLAYER_LEAVE_COMBAT");
	PlayerFrame:UnregisterEvent("PLAYER_UPDATE_RESTING");
	PlayerFrame:UnregisterEvent("PARTY_MEMBERS_CHANGED");
	PlayerFrame:UnregisterEvent("PARTY_LEADER_CHANGED");
	PlayerFrame:UnregisterEvent("PARTY_LOOT_METHOD_CHANGED");
	PlayerFrame:UnregisterEvent("PLAYER_ENTERING_WORLD");
	PlayerFrame:UnregisterEvent("PLAYER_REGEN_DISABLED");
	PlayerFrame:UnregisterEvent("PLAYER_REGEN_ENABLED");
	PlayerFrameHealthBar:UnregisterEvent("UNIT_HEALTH");
	PlayerFrameHealthBar:UnregisterEvent("UNIT_MAXHEALTH");
	PlayerFrameManaBar:UnregisterEvent("UNIT_POWER");
	PlayerFrameManaBar:UnregisterEvent("UNIT_DISPLAYPOWER");
	PlayerFrame:UnregisterEvent("UNIT_NAME_UPDATE");
	PlayerFrame:UnregisterEvent("UNIT_PORTRAIT_UPDATE");
	PlayerFrame:UnregisterEvent("UNIT_DISPLAYPOWER");
	PlayerFrame:Hide();
	RuneFrame:Hide();
end

--- Function to show blizzard casting frame
function DHUDNonAddonSettingsHandler:showBlizzardCastingFrame()
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_START");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_STOP");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_FAILED");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_DELAYED");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE");
	CastingBarFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP");
end

--- Function to hide blizzard casting frame
function DHUDNonAddonSettingsHandler:hideBlizzardCastingFrame()
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_START");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_STOP");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_FAILED");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_INTERRUPTED");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_DELAYED");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_CHANNEL_START");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE");
	CastingBarFrame:UnregisterEvent("UNIT_SPELLCAST_CHANNEL_STOP");
	CastingBarFrame:Hide();
end

--- Function to show blizzard target frame
function DHUDNonAddonSettingsHandler:showBlizzardTargetFrame()
	TargetFrame:RegisterEvent("PLAYER_TARGET_CHANGED");
	TargetFrame:RegisterEvent("UNIT_HEALTH");
	TargetFrame:RegisterEvent("UNIT_LEVEL");
	TargetFrame:RegisterEvent("UNIT_FACTION");
	TargetFrame:RegisterEvent("UNIT_CLASSIFICATION_CHANGED");
	TargetFrame:RegisterEvent("UNIT_AURA");
	TargetFrame:RegisterEvent("PLAYER_FLAGS_CHANGED");
	TargetFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
	TargetFrame:RegisterEvent("PLAYER_FOCUS_CHANGED");
	if (DHUDDataTrackers.helper.isTargetAvailable) then
		TargetFrame:Show();
	end
	ComboFrame:RegisterEvent("PLAYER_TARGET_CHANGED");
	ComboFrame:RegisterEvent("UNIT_COMBO_POINTS");
end

--- Function to show blizzard target frame
function DHUDNonAddonSettingsHandler:hideBlizzardTargetFrame()
	TargetFrame:UnregisterEvent("PLAYER_TARGET_CHANGED");
	TargetFrame:UnregisterEvent("UNIT_HEALTH");
	TargetFrame:UnregisterEvent("UNIT_LEVEL");
	TargetFrame:UnregisterEvent("UNIT_FACTION");
	TargetFrame:UnregisterEvent("UNIT_CLASSIFICATION_CHANGED");
	TargetFrame:UnregisterEvent("UNIT_AURA");
	TargetFrame:UnregisterEvent("PLAYER_FLAGS_CHANGED");
	TargetFrame:UnregisterEvent("PARTY_MEMBERS_CHANGED");
	TargetFrame:UnregisterEvent("PLAYER_FOCUS_CHANGED");
	TargetFrame:Hide();
	ComboFrame:UnregisterEvent("PLAYER_TARGET_CHANGED");
	ComboFrame:UnregisterEvent("UNIT_COMBO_POINTS");
	ComboFrame:Hide();
end

--- Function to show blizzard target frame
function DHUDNonAddonSettingsHandler:updateBlizzardPowerAurasFrame()
	-- change alpha and scale of blizzard power auras
	SpellActivationOverlayFrame:SetAlpha(self.blizzardPowerAurasAlpha);
	SpellActivationOverlayFrame:SetScale(self.blizzardPowerAurasScale);
end

--- Function to filter ui error messages of blizzard interface
-- @param level level of ui error filtering, 0 - all errors shown, 1 - ui errors hidden, 2 - ui error frame is hidden (including quest messages)
function DHUDNonAddonSettingsHandler:changeServiceUIErrorFiltering(level)
	if (level == 0) then
		UIErrorsFrame:RegisterEvent("UI_ERROR_MESSAGE");
		UIErrorsFrame:Show();
	elseif (level == 1) then
		UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE");
		UIErrorsFrame:Show();
	elseif (level == 2) then
		UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE");
		UIErrorsFrame:Hide();
	end
end

--- Function to process lua start up code
-- @param code code to be executed on startup
function DHUDNonAddonSettingsHandler:processLuaStartUpCode(code)
	self.onProcessLuaStartUpCode = function(self, e)
		DHUDDataTrackers.helper:removeEventListener(DHUDDataTrackerHelperEvent.EVENT_UPDATE_FREQUENT, self, self.onProcessLuaStartUpCode);
		--DHUDMain:print("Lua start up code: " .. code);
		local evalFunc, error = loadstring(code, "DHUD onLoad text input");
		if (evalFunc ~= nil) then
			evalFunc();
		else
			DHUDMain:print("Lua start up code contains errors: " .. error);
		end
	end
	-- execute function on first timer tick to not break initialization if code contains errors
	DHUDDataTrackers.helper:addEventListener(DHUDDataTrackerHelperEvent.EVENT_UPDATE_FREQUENT, self, self.onProcessLuaStartUpCode);
end
