-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local Sp = addonTable.Spells
local L = addonTable.L
local game = DeepDownBelow
local Col = addonTable.Colors

local auras = addonTable.auras
local skills = addonTable.skills

-- store the serializable indexes (obsolete since I decided to save only the character as of 0.2a)
--table.foreach(auras, function(k) table.insert(addonTable.SerializeVars, k) end)
--table.foreach(skills, function(k) if not tContains(addonTable.SerializeVars, k) then table.insert(addonTable.SerializeVars, k) end end)

function game.buttonSetSkill(btn, skill)
 btn.skill = skill
 btn.icon:SetTexture(Sp[skill].icon)
end

function game:AddSkill(u, skill)
 if not u.Skills then u.Skills = {} end
 table.foreach(u.Skills, function(k,v) 
   if v.name == skill then
    return
   end
  end)
 table.insert(u.Skills, { name = skill, data = skills[skill] })
end

function game:RemoveSkill(u, skill)
 for k,v in pairs(u.Skills) do
  if v.name == skill then
   table.remove(u.Skills, k)
   return
  end
 end
end

function game:FireSkill(u, skill, skillname, ...)
 local sx,sy = ...
 local tile = game.GameData.Map:GetTile(sx, sy)
 
 if strfind(skill.t, "p") then
  sx,sy = u.x, u.y
 elseif game:HasLos(u.x, u.y, sx, sy) then
  if strfind(skill.t, "t") then
   --
  elseif strfind(skill.t, "u") and tile.unit and tile.unit ~= u then
   --
  else
   return
  end
 else
  return
 end
  
 if strfind(skill.t , "h") then -- self heal
  game:Do_Heal(u, u, game:ApplyDamageBonus(u, u, skill.dam, skill.damsource), "spell", skill)
 else
  local x,y = u.x, u.y
  local range = 0
  local distx, disty = abs(sx - x), abs(sy - y)
  local horiz

  while (distx > 0 or disty > 0) and range <= skill.range do
   local tx, ty = (x < sx and x + 1 or x - 1), (y < sy and y + 1 or y - 1)
   if distx > disty then
    horiz = true
   else
    horiz = false
   end
 
   if horiz then
    x = tx
   else
    y = ty
   end
   distx, disty = abs(sx - x), abs(sy - y)
   local tile = game.GameData.Map:GetTile(x,y)
   if game:IsObstacle(tile, true) then break end
   if tile and tile.unit and tile.unit ~= u then
    if strfind(skill.t, "s") then -- single target
	 if skill.AppliesAura then
	  table.foreach(skill.AppliesAura, function(k,v)
        game:ApplyAura(tile.unit, v, u)
	   end)
	 end
	 local target = tile.unit
	 if skill.OnHit then skill:OnHit(u, target) end
     game:Do_Damage(u, target, game:ApplyDamageBonus(u, target, skill.dam, skill.damsource), "spell", skillname) 
	 local ex,ey = game:GetRealPos(x, y, u)
	 game:CreateEffect(ex, ey, skillname.."_hit")
     if not skill.pierce then break end
  	end
   end
   range = range + 1
  end
  
  if strfind(skill.t, "a") then -- aoe
   for xx = x - skill.radius, x + skill.radius do
    for yy = y - skill.radius, y + skill.radius do
     local tile = game.GameData.Map:GetTile(xx,yy)
     if tile and tile.visibility > 0 and game:HasLos(x, y, xx, yy) then
	  local ex,ey = game:GetRealPos(xx, yy)
      game:CreateEffect(ex, ey, skillname.."_splash", "anchored")
	  if tile.unit and tile.unit ~= u then
	   if skill.AppliesAura then
        table.foreach(skill.AppliesAura, function(k,v)
         game:ApplyAura(tile.unit, v, u)
	    end)
	   end
       if skill.OnHit then skill:OnHit(u, tile.unit) end
       -- apply the AoE damage
       game:Do_Damage(u, tile.unit, game:ApplyDamageBonus(u, tile.unit, skill.dam, skill.damsource), "spell", skillname)
	  end
	 end
	end
   end
  end
  local tx,ty = game:GetRealPos(x, y, u)
  x,y = game:GetRealPos(u.x, u.y, u)
  game:CreateEffect(x, y, skillname.."_missile", "missile", 5, tx, ty)
 end
 
 return true
end

function game:ApplyAura(u, aura, sender)
 if game:AuraExists(u, aura) then
  game:RemoveAura(u, aura)
 end
 
 u.Auras[aura] = {}
 table.foreach(auras[aura], function(k,v)
  if k == "Stats" then
   u.Auras[aura][k] = {}
   table.foreach(auras[aura][k], function(i,j) 
     u.Auras[aura][k][i] = j
    end)
  else
   u.Auras[aura][k] = v
  end
 end)

 u.Auras[aura].sender = sender
 
 if u == game.GameData.Player then
  game.GameFrame.BuffsFrame:CreateAuraFrame(aura, u.Auras[aura])
 end

 if u.Auras[aura].Stats then
  u:AffectStats(u.Auras[aura])
 end

 local x,y = game:GetRealPos(u.x, u.y)
 game:CreateFloatingText(x, y, "|cff00FF00+"..Sp[aura].name.."|r", 0.8,"scrollup")
 game:CreateAuraEffect(u, aura)
 game.Log(string.format(L["buff_gain"], u.Name, Sp[aura].name))
end

function game:AuraExists(u, aura)
 if not u.Auras then return 
 else return u.Auras[aura] end
end

function game:RemoveAura(u, aura)
 if not u.Auras or not u.Auras[aura] then return end
 
 if u.Auras[aura].Stats and u == game.GameData.Player then
  u:UnAffectStats(u.Auras[aura])
 end
 
 u.Auras[aura] = nil
 
 local x,y = game:GetRealPos(u.x, u.y)
 game:CreateFloatingText(x, y, "|cffFF0000-"..Sp[aura].name.."|r", 0.8, "scrollup")
 game.GameFrame.BuffsFrame:RemoveAuraFrame(aura)
 game.Log(string.format(L["buff_lose"], u.Name, Sp[aura].name))
end