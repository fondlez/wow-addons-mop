-- Deep Down Below by Fluffies
-- EU - Well of Eternity
-- widgets constructors
local addonName, addonTable = ...
local L = addonTable.L
local T = addonTable.Textures
local game = DeepDownBelow

local STRATA_MODELS = "HIGH"

local btnwidth = 120
local btnheight = 25

-- Mainframe
function game:GenerateMainframe()
 local f = game:CreateFrame("Frame", "DDBMainframe", UIParent)
 f:CreateDDBTexture()
 f.tex:SetAllPoints()
 f.tex:SetTexture(0,0,0,1)
 f:SetSize(800,700)
 f:SetPoint("CENTER")
 f:EnableMouse(true)
 f:SetMovable(true)
 f:RegisterForDrag("LeftButton")
 f:SetScript("OnDragStart", function(self) self:StartMoving() end)
 f:SetScript("OnDragStop",  function(self) self:StopMovingOrSizing() end)
 f:SetScript("OnUpdate", function() game.CurrentScreen.Update() end)
 f:EnableMouse(true)
 f:Hide()
 game.mainframe = f

 -- loading screen
 f = game:CreateFrame("Frame", "DDBLoadFrame", game.mainframe)
 f:SetAllPoints()
 f:EnableMouse(true)
 f:SetFrameStrata("DIALOG")
 f:CreateDDBTexture()
 f.tex:SetAllPoints()
 f.tex:SetTexture("Interface\\GLUES\\LoadingScreens\\LoadScreenGilneasBG")
 f.header = f:CreateFontString()
 f.header:SetFont("Fonts\\ARIALN.ttf", 20, "")
 f.header:SetPoint("CENTER", f, "CENTER", 0, 50)
 f.header:SetText(L["loading"])
 f:CreateDDBText()
 f.text:SetFont("Fonts\\ARIALN.ttf", 20, "")
 f.text:SetPoint("CENTER")
 f.text:SetText("")
 f:Hide()
 game.LoadingScreen = f
end

-- Menu Screen Widgets
function game:GenerateMenuframe()
 local f = CreateFrame("Frame", "DDBMenuFrame", game.mainframe)
 f:SetAllPoints()
 
  local function createmenubutton(i)
   local result = game:CreateFrame("Button", "DDBMainMenubtn"..i, f, "UIPanelButtonTemplate")
   result:SetSize(120,25)
   -- result:SetNormalTexture("Interface\\BUTTONS\\BLUEGRAD64")
   result:SetHighlightTexture("Interface\\MINIMAP\\UI-QuestBlobMinimap-Inside")
   _G["DDBMainMenubtn"..i.."Text"]:SetTextColor(1,1,1)
   result:Hide()
   return result
  end
 
 f.buttons = {}
 for i = 0,4 do
  f.buttons[i] = createmenubutton(i)
 end
 
 local btn = game:CreateFrame("DressUpModel", "DDBMainMenuDressModel", f)
 local _, fileName = UnitRace("player")
 local texture = DressUpTexturePath(fileName)
 btn:CreateDDBTexture("BACKGROUND")
 btn.tex:SetAllPoints()
 btn.tex:SetTexture(texture..1)
 btn:SetSize(200,300)
 f.dressmodel = btn
 btn:SetScript("OnShow", function() game:RefreshPlayerModel(f.dressmodel) end)
 btn:Hide()
 
 f.title = f:CreateFontString()
 f.title:SetFont("Fonts\\ARIALN.ttf", 24, "")
 f.title:Hide()
 f.header = f:CreateFontString()
 f.header:SetFont("Fonts\\ARIALN.ttf", 20, "")
 f.header:Hide()
 f.about = f:CreateFontString()
 f.about:SetFont("Fonts\\ARIALN.ttf", 12, "")
 f.about:Hide()
 
 f.classicon = f:CreateTexture()
 f.classicon:SetPoint("TOPLEFT", f.dressmodel, "TOPRIGHT", 10, 0)
 f.classicon:SetSize(35,35)
 f.classicon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES")
 local lc, class = UnitClass("player")
 local cc = RAID_CLASS_COLORS[class].colorStr
 local coords = CLASS_ICON_TCOORDS[class]
 f.classicon:SetTexCoord(unpack(coords))
 
 f.playername = f:CreateFontString()
 f.playername:SetFont("Fonts\\ARIALN.ttf", 24, "")
 f.playername:SetPoint("LEFT", f.classicon, "RIGHT", 5, 0)
 f.playername:SetText(game.GameData.Player.Name)
 
 f.playerclass = f:CreateFontString()
 f.playerclass:SetFont("Fonts\\ARIALN.ttf", 18, "")
 f.playerclass:SetPoint("TOP", f.playername, "BOTTOM")
 f.playerclass:SetText("|c"..cc..lc.."|r")
 
 f.playerlevel = f:CreateFontString()
 f.playerlevel:SetFont("Fonts\\ARIALN.ttf", 14, "")
 f.playerlevel:SetPoint("TOP", f.playerclass, "BOTTOM")
 
 f.playerstats = {}
 
 local lasticon
 local function createstatlabel(s)
  f.playerstats[s] = {}
  f.playerstats[s].icon = f:CreateTexture()
  f.playerstats[s].icon:SetSize(16,16)
  f.playerstats[s].icon:SetTexture(T[s])
  if lasticon then
   f.playerstats[s].icon:SetPoint("TOPLEFT", lasticon, "BOTTOMLEFT", 0, -2)
  else
   f.playerstats[s].icon:SetPoint("TOPLEFT", f.classicon, "BOTTOMLEFT", 0, -40)
  end
  f.playerstats[s].text = f:CreateFontString()
  f.playerstats[s].text:SetFont("Fonts\\ARIALN.ttf", 16, "")
  f.playerstats[s].text:SetPoint("LEFT", f.playerstats[s].icon, "RIGHT", 2, 0)
   
  lasticon = f.playerstats[s].icon
 end
 
 createstatlabel("Str")
 createstatlabel("Agi")
 createstatlabel("Int")
 createstatlabel("Sta")
 createstatlabel("BonusMelee")
 createstatlabel("BonusSpell")
 
 game.MenuFrame = f
end

--- game frame
local function unitSetModel(u, id)
 local f = u.frame

 --f:ClearModel()
 --f:SetUnit("none")
-- f:SetModel("interface\\buttons\\talktomequestionmark.m2")

 if u == game.GameData.Player then
  f:SetUnit("player")
 else
  if type(u.Model) == "string" then
   f:SetModel(u.Model)
  else
   f:SetDisplayInfo(u.Model)
  end
 end
 ---

 --if not f:HasCustomCamera() then 
-- end

 f:SetPosition(unpack(u.ModelPosition))
 --if u.CameraPosition then
  --f:SetCustomCamera(1)
  --if f:HasCustomCamera() then
   --f:SetCameraDistance(1)
   --f:SetCameraPosition(unpack(u.CameraPosition))
  --end
 --end
 f:SetAlpha(1)
 f:SetAnimation(0)
end

--[[
function game:shortSTR(s, l)
 local result = string.sub(s, 1, l-2)
 if strlen(result) ~= strlen(s) then
  result = result..".."
 end
 return result
end
]]--


function game:CreateObjectFrame(o)
 local f = game:CreateFrame("DressUpModel", nil, game.MapFrame.tilescontainer)
 f:SetSize(unpack(o.ModelSize))
 f:SetFrameStrata(STRATA_MODELS)
 --[[ debug text
 f:CreateDDBText(nil, "HIGH")
 f.text:SetFont("Fonts\\ARIALN.ttf", 12, "OUTLINE")
 f.text:SetText("|cff00FFFF"..o.Name.."|r")
 f.text:SetPoint("BOTTOM", f, "TOP", 0, 1)]]
 f:Hide()
 o.frame = f
 o.SetModel = unitSetModel
 o:SetVisualPos()
 o:SetModel()
 o.frame:SetScript("OnShow", function() o:SetModel() o:SetState() end)
end

function game:CreateUnitFrame(u)
 local f = game:CreateFrame("DressUpModel", nil, game.MapFrame.tilescontainer)
 f:SetSize(unpack(u.ModelSize))
 f:SetFrameStrata(STRATA_MODELS)
 if u == game.GameData.Player then
   SetPortraitTexture(game.GameFrame.PlayerFrame.portrait, "player")
   u.Name = UnitName("player")
 end
 --[[f:CreateDDBTexture()
 f.tex:SetAllPoints()
 f.tex:SetTexture(0,1,0,0.2)]]

 f:Hide()
 u.frame = f
 u.SetModel = unitSetModel
 u:SetVisualPos()
 u:SetModel()
 if u == game.GameData.Player then
  u.frame:SetScript("OnShow", function() game:RefreshPlayerModel(u.frame) end)
 else
  u.frame:SetScript("OnShow", function(self) u:SetModel() end)
 end
end

function game:GenerateGameframe()
 -- Map Frame
 local function createmapframe()
   if not game.MapFrame then
   -- scrollframe
   local f = game:CreateFrame("Frame", "DDBMapFrame", game.GameFrame)
   f:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
                         edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                         tile = true, tileSize = 4, edgeSize = 4, 
                         insets = { left = 4, right = 4, top = 4, bottom = 4 }})
   f:SetBackdropColor(0,0,0,1)
   local framew = game.GameFrame:GetWidth()
   f:SetWidth(framew)
   f:SetHeight(400)
   f:SetPoint("CENTER")
  -- eventuale background del mapframe

  -- tiles frame
   local tilescontainer = game:CreateFrame("Frame", nil, f) 
   tilescontainer:SetPoint("CENTER")
   tilescontainer:SetHeight(400 - addonTable.TileHeight * 2)
   tilescontainer:SetWidth(framew - addonTable.TileWidth * 2)
   tilescontainer.tiles = {}
   addonTable.Htiles = tilescontainer:GetWidth() / addonTable.TileWidth + 2
   addonTable.Vtiles = tilescontainer:GetHeight() / addonTable.TileHeight + 2
   addonTable.mapoffsetX = -addonTable.TileWidth -- tiles position shenanigans
   addonTable.mapoffsetY = addonTable.TileHeight / 2 -- tiles position shenanigans
   local x,y
   local anchor = game:CreateFrame("Frame", nil, tilescontainer)
   anchor:SetPoint("TOPLEFT", tilescontainer, "TOPLEFT", -1 * addonTable.TileWidth, addonTable.TileHeight)
   anchor:SetSize(1,1)
   anchor:Show()
   f.tilesanchor = anchor
   for x = -1,addonTable.Htiles do
    for y = -1,addonTable.Vtiles do
     tilescontainer.tiles[x.."-"..y] = game:CreateFrame("Frame", nil, anchor)
	 local tilef = tilescontainer.tiles[x.."-"..y]
	 
	  local function onenter()
       local camoffsetX = -floor(game.Camera.gapX / addonTable.TileWidth)
       local camoffsetY =  floor(game.Camera.gapY / addonTable.TileHeight)
	   local realx = x + camoffsetX
       local realy = y + camoffsetY
	   local tile = game.GameData.Map:GetTile(realx, realy)
	   local u = tile.unit and tile.unit or tile.object
	   local ic = table.getn(tile.items)
	   if not u and ic == 0 then return end
	   GameTooltip:SetOwner(tilef, "TOP", 0, 5)
       addonTable.tttarget = tilef
	   GameTooltip:ClearLines()
	   if u then
        u:FillTooltip()
	   else
	    local i
		for i = 1,ic do
		 tile.items[i]:FillTooltip()
		 GameTooltip:AddLine(" ")
		end
	   end
       GameTooltip:Show()
	  end
     tilef:SetScript("OnEnter", onenter)
     tilef.OnEnter = onenter

      tilef:SetScript("OnLeave", function()
       addonTable.tttarget = nil
	   GameTooltip:Hide()
	  end)
	  
	 tilef:SetScript("OnMouseUp", function(self, button)
       local camoffsetX = -floor(game.Camera.gapX / addonTable.TileWidth)
       local camoffsetY =  floor(game.Camera.gapY / addonTable.TileHeight)
	   local realx = x + camoffsetX
       local realy = y + camoffsetY
	   if button == "LeftButton" then
	    DeepDownBelow.GameData.Player:Act(DeepDownBelow.GameData.Player:FindPath(x -floor(game.Camera.gapX / addonTable.TileWidth), y + floor(game.Camera.gapY / addonTable.TileHeight)))
	   elseif button == "RightButton" then
	    game.GameData.Player:UseSkill(game.GameData.Player.SelectedSkill, x + camoffsetX, y + camoffsetY)
	   end
	  end)
	  
	  
     tilef:SetPoint("TOPLEFT", anchor, "TOPLEFT", x * addonTable.TileWidth, -y * addonTable.TileHeight)
	 tilef:SetSize(addonTable.TileWidth, addonTable.TileHeight)
	 tilef:CreateDDBTexture()
	 tilef.tex:SetAllPoints()
	 tilef:CreateDDBText()
	 tilef.text:SetFont("Fonts\\ARIALN.ttf", 14, "")
	 tilef.text:SetAllPoints()
	 -- lighting vars
	 tilef.r = 1
	 tilef.g = 1
	 tilef.b = 1
	end
   end
   f.tilescontainer = tilescontainer
   game.MapFrame = f
  end
 end

 -- game frame components
 local f = CreateFrame("Frame", "DDBGameFrame", game.mainframe)
 f:SetAllPoints()
 f:EnableKeyboard(true)
 f:SetScript("OnKeyDown", function(self, key)
  if not game.isPlayerMoving then
   if key == "W" or key == "A" or key == "S" or key == "D" or key == "LEFT" or key == "RIGHT" or key == "UP" or key == "DOWN" then
    game.GameData.Player:Act(key)
   elseif key == "1" then
    game.GameFrame.SkillBar["button0"]:Fire()
   elseif key == "2" then
    game.GameFrame.SkillBar["button1"]:Fire()
   elseif key == "3" then
    game.GameFrame.SkillBar["button2"]:Fire()
   elseif key == "4" then
    game.GameFrame.SkillBar["button3"]:Fire()
   elseif key == "5" then
    game.GameFrame.SkillBar["button4"]:Fire()
   elseif key == "C" then
    game:ToggleCharacterFrame()
   elseif key == "Q" then
    game.GameData.Player:PickUpItem()
   elseif key == "SPACE" then
    game:EndTurn()
	--[[
   elseif key == "Z" then
   game.GameData.Player:LevelUp(game.GameData.Player.Level + 1, false)
   game:SetMobsLevel(game.GameData.Player.Level)
   elseif key == "X" then
    game:GenerateLoot(game.GameData.Player)
	]]
   elseif key == "DELETE" then
    game:DeleteSelectedItem()
   elseif key == "ESCAPE" then
    game.mainframe:Hide()
	game.CharacterFrame:Hide()
	game.InventoryFrame:Hide()
   elseif key == "ENTER" then
    local edt = ChatFrame1EditBox
	edt:Show()
	edt:SetFocus()
   end
  end
 end)

 game.GameFrame = f
 createmapframe()
 game:CreateUserInterface()
 game:CreateUnitFrame(game.GameData.Player)
 game:CharacterFrame_Init()
 game.Camera:CenterToPlayer(true)
end