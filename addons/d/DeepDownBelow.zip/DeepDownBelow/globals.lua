-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local T = addonTable.Textures
local L = addonTable.L

local game = DeepDownBelow
game.GameData = {} -- all savegame data stored here
local gamedata = game.GameData
game.GameData.Turn = 1
game.TurnStartDelay = 0.1
local turndelay = 0.1

function game:Error(s)
 print("|cffFF0000DDB Error |cffFFFFFF"..s.."|r")
end

function game:SysMessage(s)
 game:CreateFloatingText(10, 0, s, 5, nil, "Fonts\\MORPHEUS.ttf", 64, "OUTLINE")
end

function game:ResetGame()
 game.GameData.Map:Dispose()
end

local function UpdateAuras(u)
 table.foreach(u.Auras, function(k,v) 
   
  if v.type == "dot" then
   game:Do_Damage(v.sender, u, game:ApplyDamageBonus(v.sender, u, v.dam, v.damsource), "spell", k)
  elseif v.type == "hot" then
   game:Do_Heal(v.sender, u, game:ApplyDamageBonus(v.sender, u, v.dam, v.damsource), "spell", k)
  end
   
  if v.duration ~= -1 then
   v.duration = v.duration - 1
   if v.duration <= 0 then
    game:RemoveAura(u, k)
   end
  end
 end)
 
 if u.Skills then
  table.foreach(u.Skills, function(_,v)
   if v.data.cd and v.data.cd > 0 then v.data.cd = v.data.cd - 1 end
  end)
 end
end

function game:foreach(t, func)
 for k,v in pairs(t) do
   func(k,v)
 end
end

-- End turn method
function game:PrepareEndTurn()
 game.EndTurnReady = true
 game:RefreshPowerBars()
 game.TurnStartDelay = GetTime() + turndelay
end

local function OnScreenCheck(u)
 local t = game.GameData.Map:GetTile(u.x, u.y)
 if t.visibility == 2 then -- if it's in a visible tile
  u.frame:Show()
 else
  u.frame:Hide()
 end
end

function game:EndTurn()
 local p = game.GameData.Player

 if p.Target == nil then
  game.GameFrame.TargetFrame:Hide()
 else
  game.GameFrame.TargetFrame:Show()
 end

 UpdateAuras(p)
 p:CheckStats()
 p:GenerateMana("endturn")
 p:GenerateHP("endturn")
 
 local mobsfound
 local k, u
 table.foreach(game.GameData.Map.units, function(k,u)
   -- AI
   if game:isOnScreen(u.x, u.y) then
    if u.Status ~= "dead" and u.Status ~= "stunned" then
	 if u:CanSee(p) then
      -- the mob can see the player, full aggro
      if u.aggro < addonTable.aggro_max then
	   if u.aggro == 0 then
	    game:CreateChatBubble({L["dlg_aggro0"]}, u, 1)
 	    game:PlayRandomSound(u.sounds.aggro)
	   end
	   u.aggro = addonTable.aggro_max
	  end
     else
      if u.aggro == addonTable.aggro_max - 1 then
       game:CreateChatBubble({L["dlg_aggro1"]}, u, 1)
	  elseif u.aggro == math.floor(addonTable.aggro_max) / 2 then
       game:CreateChatBubble({L["dlg_aggro2"]}, u, 1)
	  elseif u.aggro == 1 then
	   game:CreateChatBubble({L["dlg_aggro3"]}, u, 1)
	  end
	  u.aggro = u.aggro > 0 and u.aggro - 1 or 0
	 end
	 
     if u.aggro > 0 and u:CanAct() then
	  local dir = u:FindPath(p.x, p.y)
	  if not u:Act(dir) then
 	  if addonTable:distance(u.x, u.y, p.x, p.y) < addonTable.aggro_max then
	   -- rifinire la path se e' dentro il range base ma ostacolato
	   end
	  end
	 end
	 mobsfound = true
	end
    OnScreenCheck(u)
   else
    u.frame:Hide()
   end
   UpdateAuras(u)
   u:CheckStats()
  end)
  
 for k,u in pairs(game.GameData.Map.objects) do
  if game:isOnScreen(u.x, u.y) then
   OnScreenCheck(u)
  else
   u.frame:Hide()
  end
 end
 game.TurnStartDelay = GetTime() + (mobsfound and turndelay or 0)
 game.GameFrame.BuffsFrame:RefreshAuraFrames()
 game:RefreshPowerBars()
 game:RefreshPlayerStats()
 game:RefreshTooltip()
 game.GameData.Turn = game.GameData.Turn + 1
 -- turn text disabled as of 0.3a
 --game.GameFrame.TurnText:SetText(L["turn"].." "..game.GameData.Turn)
 game:HandleTileAnchors(true)
 if game.GameData.Turn % 10 == 1 then collectgarbage() end
 
 p:IncStatistic("game_turns_total", 1)
 game:SavePlayer()
end
--

function game:RefreshTooltip()
 if addonTable.tttarget then
  addonTable.tttarget:OnEnter()
 end
end

function game:StatFillTooltip(s)
 local p = game.GameData.Player
 GameTooltip:AddDoubleLine(L[s], "|T"..T[s]..":24|t")
end

-- utils
function game:Dice(d)

 local result = d
 if type(d) == "table" then
  result = math.random(d[1], d[2])
 end

--[[
 local result,i = 0
 if type(d) == "table" then
  for i = 1,d[1] do
   result = result + math.random(1,d[2])
  end
 else 
  result = d
 end]]
 return result
end

function game:Do_Damage(s, t, dam, source, ...)

 if s.Stats["DamageMultiplier"] then dam = dam * s.Stats["DamageMultiplier"] end
 if t.Stats["DamageReduction"] then dam = dam * t.Stats["DamageReduction"] end
 
 dam = math.ceil(dam)
 t.HPcurr = t.HPcurr - dam

 local x,y = game:GetRealPos(t.x, t.y, t)
 local FTtext = t == game.GameData.Player and "|cffFF0000"..dam.."|r" or dam
 x,y = game:GetRealPos(t.x, t.y)
 game:CreateFloatingText(x, y, FTtext, 0.6, "anchored", "Fonts\\MORPHEUS.ttf", 32, "")
 if source == "hit" then
  game:Log(string.format(L["unit_hits"], s.Name, t.Name, dam))
  --game:PlayRandomSound(s.sounds.hit[t.ArmorType]) -- suono dell'unita' colpita
 elseif source == "spell" then
  local spell = ...
  game:Log(string.format(L["unit_hits_spell"], s.Name, ..., t.Name, dam))
 end

 if t.HPcurr <= 0 then
  game:SetUnitDead(t)
  if t ~= game.GameData.Player then -- drop loot
   if math.random(100) <= 50 then
    game:GenerateLoot(t)
   end
  end
  if s then
   game:Log(string.format(L["unit_killedby"], s.Name, t.Name))
   if s ~= game.GameData.Player then
    s:StartAnimation(68) -- cheer
   else
    s:GainXP(s:CalcXp(t))
   end
  else
   game:Log(string.format(L["unit_dead"], t.Name))
  end
 end
end

function game:Do_Heal(s, t, dam, source, ...)
 t.HPcurr = t.HPcurr + dam
 if t.HPcurr > t.HPmax then t.HPcurr = t.HPmax end
 
 local x,y = game:GetRealPos(t.x, t.y, t)
 local FTtext = t == game.GameData.Player and "|cff00FF00"..dam.."|r" or dam
 x,y = game:GetRealPos(t.x, t.y)
 game:CreateFloatingText(x, y, FTtext, 0.6, "", "Fonts\\MORPHEUS.ttf", 32, "")
 -- game:PlayRandomSound(s.sounds.hit[t.ArmorType]) -- generare suono dell'unita' colpita
 game:CreateEffect(x, y, "heal")
 game:Log(string.format(L["unit_heals"], s.Name, t.Name, dam))
end
--

-- camera gap
game.Camera = 
{
 gapX = 0, gapY = 0,
 gapXdest = 0, gapYdest = 0,
 speed = 3,
 isMoving = false
}
local cam = game.Camera

local function round(number, decimals)
 return (("%%.%df"):format(decimals)):format(number)
end

function game.Camera:CenterToPlayer(istant)
 local p = game.GameData.Player
 local x = -round(p.x * addonTable.TileWidth - game.MapFrame:GetWidth() / 2,0)
 local y = round(p.y * addonTable.TileHeight - game.MapFrame:GetHeight() / 2,0)
 cam.gapXdest = x
 cam.gapYdest = y
 if istant then
  cam.gapX = x - 0.1 -- force a camera update
  cam.gapY = y
 end
end

function addonTable:distance(x1,y1,x2,y2)
 local xs, ys = 0, 0
 xs = x2 - x1
 xs = xs * xs
 ys = y2 - y1
 ys = ys * ys
 return math.sqrt(xs + ys)
end

function game.Camera:Update()
 if cam.gapX == cam.gapXdest and
    cam.gapY == cam.gapYdest then
  return
 end

 local dx = cam.gapXdest - cam.gapX
 local dy = cam.gapYdest - cam.gapY
 dist = addonTable:distance(cam.gapX,cam.gapY,cam.gapXdest,cam.gapYdest)
 if dist > cam.speed then
  dx = dx / dist
  dy = dy / dist
  cam.gapX = cam.gapX + dx * cam.speed
  cam.gapY = cam.gapY + dy * cam.speed
  game:HandleTileAnchors()
 else
  cam.gapX = round(cam.gapXdest,0)
  cam.gapY = round(cam.gapYdest,0)
  game:HandleTileAnchors()
 end
end

-- map constants
addonTable.TileWidth = 32
addonTable.TileHeight = 32