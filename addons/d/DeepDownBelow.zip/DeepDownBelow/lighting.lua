-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local L = addonTable.L
addonTable.ambientlight = 0.1

addonTable.mapAddLightSource = function(m, x, y, radius, intensity, color)
 local l = {x = x, y = y, radius = radius, intensity = intensity, color = color}
 table.insert(m.lightsources, l)
 DeepDownBelow:HandleTileAnchors(true)
 return l
end

addonTable.mapRemoveLightSource = function(m, l)
 local found
 table.foreach(m.lightsources, function(k, v) 
  if v == l then 
   found = k
  end
 end)
 if found then table.remove(m.lightsources, found) end
 DeepDownBelow:HandleTileAnchors(true)
end

addonTable.unitAddLight = function(u, ...)
 u.Light = DeepDownBelow.GameData.Map:AddLightSource(u.x, u.y, ...)
end

addonTable.unitRemoveLight = function(u)
 DeepDownBelow.GameData.Map:RemoveLightSource(u.Light)
 u.Light = nil
end