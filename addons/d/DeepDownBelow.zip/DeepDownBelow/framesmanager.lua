-- Deep Down Below by Fluffies
-- EU - Weel of Eternity
-- frames management
local addonName, addonTable = ...
local L = addonTable.L
local game = DeepDownBelow

local pool = {}

local function createtext(f, ...)
 if not f.text then
  f.text = f:CreateFontString(...)
 end
 f.text:ClearAllPoints()
 f.text:SetAlpha(1)
end

local function createtexture(f, ...)
 if not f.tex then
  f.tex = f:CreateTexture(...)
 end
 f.tex:ClearAllPoints()
 f.tex:SetAlpha(1)
end

function game:CreateFrame(...)
 local t, _, p = ...

 local k,v
 for k,v in pairs(pool) do
  if v.t == t then
   table.remove(pool, k)
   v:SetParent(p)
   v:Show()
   return v
  end
 end

 local result = CreateFrame(...)
 result.t = t
 result.CreateDDBTexture = createtexture
 result.CreateDDBText = createtext
 return result
end

function game:DisposeFrame(f)
 f:Hide()
 f:SetParent(nil)
 f:ClearAllPoints()
 f:SetScript("OnEnter", nil)
 f:SetScript("OnLeave", nil)
 f:SetScript("OnMouseUp", nil)
 f:SetScript("OnShow", nil)
 if f.t == "PlayerModel" or f.t == "DressUpModel" then
  f:SetScript("OnAnimFinished", nil)
 end
 f:SetScript("OnUpdate", nil)
 table.insert(pool, f)
end