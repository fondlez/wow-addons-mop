-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

local abs, rnd = math.abs, math.random
local pflimit = 8 -- pathfinding tiles distance limit
addonTable.aggro_max = 10

-- pathfinding
function game:FindDir(x1, y1, x2, y2)
  local function moveHoriz()
   if x1 < x2 then
	return "RIGHT"
   elseif x1 > x2 then
	return "LEFT"
   end
   return
  end

  local function moveVert()
   if y1 < y2 then
	return "DOWN"
   elseif y1 > y2 then
	return "UP"
   end
   return
  end

  local dir
  if rnd(100) <= 50 then
   dir = moveHoriz()
   if not dir then
    dir = moveVert()
   end
  else
   dir = moveVert()
   if not dir then
    dir = moveHoriz()
   end
  end

  return dir
end

function addonTable.unitFindPath(u, x, y)
 if abs(u.x - x) > pflimit or 
    abs(u.y - y) > pflimit then
   return end

 local cX, cY = u.x, u.y
 local result = game:FindDir(u.x, u.y, x, y)
 return result
end