﻿-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow
local L = addonTable.L
local C = addonTable.Colors

local min, max, random, getn, abs, floor, ceil = math.min, math.max, math.random, table.getn, math.abs, math.floor, math.ceil

local function round(i)
 return tonumber((("%%.%df"):format(decimals)):format(i))
end

local function SetItemBaseStats(i, lvl)
 table.foreach(addonTable:GetItemBudgetType(i), function(k, v)
  if strfind(k, "_"..lvl.."_") then
   if i.Type == "Weapon" and not i.Damage then
    --i.Damage = {ceil((lvl * (i.Quality / 10 + 1)) / 5), ceil((lvl * (i.Quality / 10 + 1)) / 3)}
	i.Damage = {round((lvl * (i.Quality / 10 + 1)) * 1.5), round((lvl * (i.Quality / 10 + 1) * 2))}
   end
  end
 end)
end

local function SetItemStats(i, lvl)

 if not i then return end

 if i.Quality <= 1 then return end
 
 local function setstat(stat, v)
  i.Stats[stat] = round(v * (i.Quality / 10 + 1))
 end

 local function calcleveldifference(s)
  return lvl * s + sqrt(lvl * s) --+ random(2) * lvl
 end

 table.foreach(addonTable:GetItemBudgetType(i), function(k, v)
  if strfind(k, "_"..lvl.."_") then
   if strfind(i.StatsAllowed, "s") then setstat("Str", calcleveldifference(v.mainstat)) end
   if strfind(i.StatsAllowed, "a") then setstat("Agi", calcleveldifference(v.mainstat)) end
   if strfind(i.StatsAllowed, "i") then setstat("Int", calcleveldifference(v.mainstat)) end
   if strfind(i.StatsAllowed, "h") then
    local rnd = random(3)
	if rnd == 1 then
	 setstat("Str", calcleveldifference(v.mainstat, v))
	elseif rnd == 2 then
	 setstat("Agi", calcleveldifference(v.mainstat, v))
	else 
	 setstat("Int", calcleveldifference(v.mainstat, v))
	end
   end
   if strfind(i.StatsAllowed, "m") then setstat("Sta", calcleveldifference(v.stamina)) end
   if strfind(i.StatsAllowed, "j") then setstat(random(2) == 1 and "BonusMelee" or "BonusSpell", calcleveldifference(v.power)) end
   if strfind(i.StatsAllowed, "k") then setstat("BonusMelee", calcleveldifference(v.power)) end
   if strfind(i.StatsAllowed, "l") then setstat("BonusSpell", calcleveldifference(v.power)) end
  end
 end)

--[[
-- s = str, a = agi, i = int, m = stam, k = melee, l = spell
-- h = str/agi/int a random one
-- j = spell/melee a random one
]]
end

local function getrandomitem(t)
 local id = random(getn(t))
 
 if t[id] then
  local i = {}
  table.foreach(addonTable.TemplateItem, function(k,v)
   i[k] = t[id][k] and t[id][k] or v
  end)
  game:SetItemVars(i, true)
  game:SetItemMethods(i)
  return i
 else
  game:Error(L["err2"].." ("..id..")")
  return
 end
end

function game:PlaceNewItem(lvl, x, y, legendarychance)
 local t
 local source = random(10000) / 100 <= legendarychance and addonTable.Items_Legendary or addonTable.Items

 table.foreach(source, function(k, v)
  if strfind(k, "_"..lvl.."_") then
   t = v
  end
 end)

 if not t then return end

 local i = getrandomitem(t)
 
 if i.Quality <= 2 and i.Type ~= "Junk" then
  i.Quality = random(3) - 1
  if i.Quality == 2 and random(100) <= 5 then
   i.Quality = 3
  end
  if lvl > 8 then
   i.Quality = min(i.Quality + 2, 4)
  end
 end
 i.Itemlevel = i.Itemlevel + lvl
 SetItemBaseStats(i, lvl)
 SetItemStats(i, lvl)
 
 if not i then return end

 i:SetPos(x, y, true)
 return i
end

-- Generate Loot
function game:GenerateLoot(u)
 local lev = u.Level + random(5) - 4
 lev = max(1, min(20, lev))
 
 local tile, x, y
 local counter = 0
 while not tile do
  x,y = u.x + random(3) - 2, u.y + random(3) - 2
  local t = game.GameData.Map:GetTile(x, y)
  if t and not game:IsObstacle(t) then
   if counter > 10 or not t.items[1] then
    tile = t
   end
  end
  counter = counter + 1
 end

 if not tile then tile = game.GameData.Map:GetTile(u.x, u.y) end

 local i = game:PlaceNewItem(lev, x, y, 5)
 if not i then return end
 x,y = game:GetRealPos(x, y, u)
 if i.Quality == 5 then
  game:CreateEffect(x, y, "loot_dropped_leg", "anchored")
 else
  game:CreateEffect(x, y, "loot_dropped", "anchored")
 end
end

local function itemSetPos(i, x, y)
 game.GameData.Map:GetTile(i.x, i.y):RemoveItem(i)
 i.x = x
 i.y = y
 if i.Light then
  i.Light.x = i.x
  i.Light.y = i.y
 end
 table.insert(game.GameData.Map:GetTile(i.x, i.y).items, i)
end

local function isWearable(i)
 return i.EQSlot ~= "junk"
end

local function itemFillTooltip(i)
 local w,y,g = "|cffFFFFFF","|cffffcc00","|cff00FF00"
 -- item name
 GameTooltip:AddLine(C["item_q"..i.Quality]..i.Name.."|r")
 -- itemlevel
 GameTooltip:AddLine(y..STAT_AVERAGE_ITEM_LEVEL.." "..i.Itemlevel)
 -- soulbound fixed string since there are no other types :p
 GameTooltip:AddLine(w..ITEM_SOULBOUND)
 -- slot
 GameTooltip:AddDoubleLine(w..string.gsub(i.EQSlot, i.EQSlot == "Trinket0Slot" and "0Slot" or "Slot", ""), i.SubType)
 -- damage
 if i.Type == "Weapon" then
  GameTooltip:AddLine(w..i.Damage[1].." - "..i.Damage[2].." Damage")
 end
 local k,v
 for k,v in pairs(i.Stats) do
  if v ~= 0 then
   GameTooltip:AddLine(w..(v < 0 and "" or "+")..v.." "..L[k])
  end
 end
 
 -- item enchants
 for k,v in pairs(addonTable.ItemEnchants[i.Enchant].Stats) do
  GameTooltip:AddLine(g.."Ench: "..addonTable.ItemEnchants[i.Enchant].Name.." "..(v < 0 and "-" or "+")..v.." "..k)
 end
 if i.Desc ~= "" then
  GameTooltip:AddDoubleLine("|cffCCCC00\""..i.Desc.."\"|r")
 end
end

function game:SetItemVars(i, resettables)
 i.x = 0
 i.y = 0
 i.visX = 0
 i.visY = 0
 if resettables then i.Stats = {} end
end

function game:SetItemMethods(i)
 i.Dispose = itemDispose
 i.SetPos = itemSetPos
 i.SetVisualPos = itemSetVisualPos
 i.Update = itemUpdate
 i.isWearable = isWearable
 i.FillTooltip = itemFillTooltip
 -- same light methods as units, this is not an error
 i.AddLight = addonTable.unitAddLight -- lighting.lua
 i.RemoveLight = addonTable.unitRemoveLight -- lighting.lua
end