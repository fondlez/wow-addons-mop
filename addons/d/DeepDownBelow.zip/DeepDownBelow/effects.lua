-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

local effects_pulse = 1

local effects = 
{
 -- Warrior
 ["heroic_strike_hit"] = {  size  = {64,64},
                            model = "SPELLS\\Warrior_WildStrike_Base.M2", },
 ["heroic_strike_aura"] = {  size  = {48,48},
                            model = "SPELLS\\Shout_Cast.M2", },
["heroic_throw_missile"]={  size  = {256,256},
                            model = "spells\\missile_wrench.m2", },
 ["whirlwind_act"]     = {  size  = {96,96},
                            model = "SPELLS\\Cleave_Cast_Base.M2", },
 ["berserker_rage_cast"] = {size  = {128,128},
                            model = "spells\\endlessrage_state_head.m2"},
-- berserker_rage_aura ?

 -- Paladin
 ["judgement_hit"] =     {  size  = {64,64},
                            model = "spells\\judgement_impact_chest.m2", },
 ["holy_light_cast"]   = {  size  = {64,64}, -- doesn't work
                            model = "spells\\healrag_state_chest.m2",},
["consecration_cast"]=   {  size  = {128,128},
                            model = "spells\\consecration_impact_base.m2",
							pos   = {-20, 0, -10}},
 ["divine_shield_aura"] = { size  = {64,64},
                            model = "spells\\holywordshield_state_base.m2",
							pos   = {-1.5, 0, 0}},
 ["avenging_wrath_aura"] = { size = {64,64}, 
                             model = "spells\\avengingwrath_state_chest.m2",
							 pos   = {0, 0.3, 1.4}},
 -- Death Knight
 ["death_strike_hit"] = { size = {48,48},
                          model = "spells\\deathknight_bloodstrike.m2"},
 ["howling_blast_splash"]= { size  = {96,96},
                            model = "spells\\deathknight_howlingblastsecondary.m2", },
 ["death_coil_missile"] = {  size  = {48,48},
                            model = "spells\\deathknight_deathcoil_missile.m2", },
 -- death grip chain?
 ["anti_magic_shell_aura"] = { size  = {64,64},
                              model = "spells\\antimagic_state_base.m2",
							  pos   = {-1.5, 0, 0}},
 -- Rogue
 ["sinister_strike_hit"] = { size  = {64,64},
                             model = "spells\\sinisterstrike_base_cast.m2", },
 ["recuperate_cast"]    = {  size  = {64,64},
                             model = "spells\\rogue_recuperate_01.m2",},
["fan_of_knives_cast"]=   {  size  = {128,128},
                            model = "spells\\fanofknives_impact.m2",},
 ["shuriken_toss_missile"] = { size  = {64,64},
                            model = "spells\\spell_shuriken.m2"},
 ["combat_readiness_aura"] = { size = {64,64}, 
                             model = "spells\\rogue_combatreadiness_01.m2",},
-- Monk
 ["blackout_kick_hit"] = { size  = {64,64},
                             model = "spells\\monk_blackoutkick_state.m2",
							 pos = {-5, 1, -2}},
 ["surging_mist_cast"]    = {  size  = {64,64},
                             model = "spells\\monk_surgingmists_impact.m2",
							 pos = {-4,0,0}},
["spinning_crane_kick_cast"]=   {  size  = {128,128},
                                   model = "spells\\goldenlotus_cranekick_state.m2",
								  pos   = {-8, 0, 2}},
                            --model = "spells\\monk_cranekick_state.m2",},
 ["jade_lightning_hit"] = { size  = {64,64},-- not working
                            model = "spells\\shaman_thunder.m2"},
 ["fortifying_brew_aura"] = { size = {64,64}, -- not working
                             model = "spells\\bubble_drunk.m2",},							 
 -- Hunter
 ["binding_shot_hit"]       = { size = {48,48},-- not working
                                model = "spells\\ice_impactdd_low_chest.m2",},
 ["bandage_self_cast"]      = { size  = {64,64}, -- not working
                                model = "spells\\firstaid__impact_base.m2",},
 ["volley_splash"]          = { size  = {48,48},
                                model = "spells\\xplosion_dust_impact.m2",
								pos = {-6,0,-3}},
 ["explosive_shot_aura"]    = { size  = {64,64},-- not working
                                model = "spells\\explosive_shot_impact.m2",}, 
 ["deterrence_aura"]        = { size = {64,64},
                                model = "spells\\deterrence_state_chest.m2",
							    pos   = {-1.5, 0, 0}},
 -- Druid
 ["moonfire_hit"]       = { size = {48,48},-- not working
                                model = "spells\\moonfire_impact_base.m2",},
 ["rejuvenation_aura"]      = { size  = {64,64},-- not working
                                model = "spells\\druid_flourish.m2",},
 ["hurricane_splash"]          = { size  = {48,48},-- not working
                                model = "spells\\druid_hurricane_funnels_v2.m2",
								pos = {-6,0,-3}},
 ["starfire_hit"]    = { size  = {64,64},-- not working
                                model = "spells\\druid_starsurge_impact.m2",}, 
 ["barkskin_aura"]        = { size = {64,64},-- not working
                                model = "spells\\barkskin_state_base.m2",
							    pos   = {-1.5, 0, 0}},
 -- Priest
 ["smite_hit"]              = { size = {48,48},
                                model = "spells\\cleave_circle_holy.m2",
								pos = {-1.5,0,0}},
 ["greater_heal_cast"]      = { size  = {64,64}, -- not working
                                model = "spells\\holylight_low_head.m2",},
 ["holy_nova_cast"]         = { size  = {128,128},
                                model = "spells\\holynova_impact_base.m2",
				  			    pos   = {-20, 0, -10}},
 ["shadow_word_pain_aura"]  = { size  = {64,64},
                                model = "spells\\ball_of_shadow.m2",},
 ["power_word_shield_aura"] = { size = {64,64},
                                model = "spells\\holywordshield_state_base.m2",
							    pos   = {-1.5, 0, 0}},
 -- Warlock
 ["incinerate_hit"]         = { size = {48,48},
                                model = "spells\\Shaman_lavaburst.m2"},
 ["ember_tap_cast"]         = { size  = {64,64},
                                model = "spells\\Warlock_destructioncharge_impact_base.m2",},
 ["rain_of_fire_splash"]    = { size  = {128,128},
                                model = "spells\\Rainoffire_missile.m2",
				  			    pos   = {0,0,-5}},
 ["immolate_aura"]          = { size  = {64,64},
                                model = "spells\\Immolate_state.m2",},
 ["demon_skin_aura"]        = { size = {64,64},
                                model = "spells\\Warlock_undyingresolve_chest.m2",
							    pos   = {-1.5, 0, 0}},
 -- Mage
  ["fireball_hit"]         = { size = {48,48},
                                model = "spells\\Shaman_lavaburst.m2"},
 ["evocation_cast"]         = { size  = {64,64},
                                model = "spells\\Warlock_destructioncharge_impact_base.m2",},
 ["flamestrike_splash"]    = { size  = {96,96},
                                model = "spells\\Rag_firenova_area.m2",
				  			    pos   = {0,0,-5}},
 ["pyroblast_hit"]          = { size  = {96,96},
                                model = "spells\\Hellfire_firepuff_caster_base.m2",
								pos   = {-2,0,-2}},
 ["mana_shield_aura"]        = { size = {64,64},
                                model = "spells\\manashield_state_chest.m2"},
 -- Shaman
  ["lightning_bolt_hit"]         = { size = {48,48},
                                model = "spells\\Shaman_stormstrike.m2"},
 ["healing_surge_cast"]         = { size  = {64,64},
                                model = "spells\\Shaman_spiritwalkersgrace.m2",},
 ["thunderstorm_cast"]    = { size  = {96,96},
                                model = "spells\\Jinyu_lightning_storm_impact30.m2",
				  			    pos   = {0,0,-5}},
 ["earth_shock_hit"]          = { size  = {96,96},
                                model = "spells\\Shaman_stormstrike.m2"},
 ["ancestral_guidance_aura"]        = { size = {64,64},
                                model = "spells\\Shaman_ancestralawakening.m2"},

 ["loot_dropped"]       = { size = {64, 64},
                            model = "spells\\manashield_state_chest.m2", },
 ["loot_dropped_leg"]   = { size = {64, 64},
                            model = "spells\\metamorphosis.m2",
                            pos   = {-1, 0, 0} },
 ["levelup"]            = { size  = {64,64},
                            model = "Spells\\LevelUp\\LevelUp.M2",
                            pos   = {0, 0, -3} },
}

--[[
spells\\priest_leapoffaith_target_purple.m2

spells\\deathknight_death_siphon_missile.m2
world\expansion01\\doodads\\tempestkeep\\passivedoodads\\prisonfx\\tk_lightning_ball.m2
world\\expansion02\\doodads\\ulduar\\ul_lightning_blue01.m2
-- ground cracks
groundcrack_

hunter_glaiveleft_impact

spells\monk_cracklinglightning_impact.m2
--new
spells\goldenlotus_cranekick_state.m2
spells\goldenlotus_darkmeditation_antimagiczone.m2
spells\goo_flow_state.m2
spells\goo_flow_stateblue.m2
spells\goo_flow_statered.m2
spells\goo_flow_statefire.m2
spells\impact_template_world_01.m2
spells\impact_template_base_01.m2
spells\intervene_impact_chest.m2
spells\kidneyshot_base_cast.m2
spells\lash_cast_base.m2
spells\learn_impact_base.m2
spells\lifetap_state_chest.m2
spells\manashield_state_chest.m2
spells\maulcasterbase.m2
spells\\metamorphosis.m2
spells\steam.m2
spells\swipeimpact.m2
--
"SPELLS\\SavageBlow_Impact_Chest.M2"
"SPELLS\\Lacerate_Impact.M2"
SPELLS\\BloodyExplosion.M2
spells\curseofweakness_head.m2
spells\cyclonefire_state.m2
spells\cyclone_state.m2
spells\deathknight_corpseexplosion.m2
spells\deathknight_deathcoil_missile.m2
spells\deathwing_body_fire.m2
spells\decimate_impact_chest.m2
spells\demoralizingshout_impact_head.m2   -- aggro effect?
spells\rampage_ impact _head.m2
spells\killcommand_impact_head.m2 
spells\rogue_shurikentoss_missile.m2
spells\priest_halo_missile.m2
spells\paladin_lightshammer_missile.m2
Particles\\BloodSpurts\\Bloodspurt.M2
]]
function game:CreateEffect(x, y, effect, ...)
 local eff = effects[effect]
 if not eff then return end
 local f = game:CreateFrame("PlayerModel", nil, game.MapFrame.tilescontainer)
 local w,h = unpack(eff.size)
 f:SetSize(w,h)
 f:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", x - w / 2, -y + h / 2)
 f:SetModel(eff.model)
 local behavior, speed, destX, destY, aura = ...
 if behavior == "missile" then
  local offX,offY = x, y
  local i = 0
  f:SetScript("OnUpdate", function(self)
   i = i > effects_pulse and 0 or i + 1
   if i < effects_pulse then return end
   self:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", (offX - w / 2), (-offY + h / 2))
   if offX < destX then
    offX = offX + speed
   elseif offX > destX then
    offX = offX - speed
   end
   if offY < destY then
    offY = offY + speed
   elseif offY > destY then
    offY = offY - speed
   end
   local xx, yy = math.abs(offX - destX), math.abs(offY - destY)
   if xx <= speed then offX = destX end
   if yy <= speed then offY = destY end

   if offX == destX and offY == destY then
    game:DisposeFrame(self)
   end
  end)
 elseif behavior == "anchored" then
  local camoffsetX, camoffsetY = game.Camera.gapX, game.Camera.gapY
  local i = 0
  f:SetScript("OnUpdate", function(self) 
    i = i > effects_pulse and 0 or i + 1
    if i < effects_pulse then return end
    self:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", (x - w / 2) - (camoffsetX - game.Camera.gapX), (-y + h / 2) - (camoffsetY - game.Camera.gapY))
   end)
  f:SetScript("OnAnimFinished", function(self) game:DisposeFrame(self) end)
 elseif behavior == "aura" then
  local i = 0
  f:SetScript("OnUpdate", function(self) 
    if not speed then game:DisposeFrame(self) return end
	-- we use speed to store the source unit
    local X, Y = speed.visX + addonTable.TileWidth / 2, speed.visY + addonTable.TileHeight / 2	
	local camoffsetX, camoffsetY = game.Camera.gapX, game.Camera.gapY
    i = i > effects_pulse and 0 or i + 1
    if i < effects_pulse then return end
    self:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", (X - w / 2) - (camoffsetX - game.Camera.gapX), (-Y + h / 2) - (camoffsetY - game.Camera.gapY))
   end)
  f:SetScript("OnAnimFinished", function(self) 
    f:SetScript("OnAnimFinished", function(self) if speed and speed.Status ~= "dead" and aura and aura.duration > 0 then self:Show() else game:DisposeFrame(self) end end)
   end)
 else
  f:SetScript("OnAnimFinished", function(self) game:DisposeFrame(self) end)
 end
 if eff.pos then f:SetPosition(unpack(eff.pos)) end
 f:SetFrameStrata("HIGH")
 f:Show()
 return f
end

function game:CreateAuraEffect(u, aura)
 if not u or not game:AuraExists(u, aura) then return end

 game:CreateEffect(0, 0, aura.."_aura", "aura", u, _, _, u.Auras[aura])
end


--- Floating Text ---
function game:CreateFloatingText(x, y, s, t, behavior, ...)
 --local x, y = game:GetRealPos(u.x, u.y)
 local f = game:CreateFrame("Frame", nil, game.MapFrame.tilescontainer)
 local duration = t and t or 0.8
 local accel = 10
 local startTime = GetTime()
 f:SetSize(1,1)
 f:SetFrameStrata("DIALOG")
 f:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", x, -y)
 --if f.tex then f.tex:Hide() end
 f:CreateDDBText()
 if ... then
  f.text:SetFont(...)
 else -- default font
  f.text:SetFont("Fonts\\ARIALN.ttf", 16, "")
 end
 f.text:SetText(s)
 f.text:SetPoint("TOPLEFT")
 
 local camoffsetX, camoffsetY = game.Camera.gapX, game.Camera.gapY
 f:SetScript("OnUpdate", function(self, elapsed)
  if GetTime() > startTime + duration then
   self:SetScript("OnUpdate", nil)
   game:DisposeFrame(self)
  elseif behavior == "scrollup" then
   self:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", x, -y + (GetTime() - startTime) * accel)
  elseif behavior == "anchored" then
   self:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", x - (camoffsetX - game.Camera.gapX), -y - (camoffsetY - game.Camera.gapY))
  end
  self.text:SetAlpha(1 - (GetTime() - startTime) / duration)
  accel = accel + 2
 end)
end
---

--[[
SetSequenceTime?
]]