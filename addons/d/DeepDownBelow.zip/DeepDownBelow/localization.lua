-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
DeepDownBelow = {}

addonTable.Colors = {
 ["item_q0"] = "|c"..select(4, GetItemQualityColor(0)),
 ["item_q1"] = "|c"..select(4, GetItemQualityColor(1)),
 ["item_q2"] = "|c"..select(4, GetItemQualityColor(2)),
 ["item_q3"] = "|c"..select(4, GetItemQualityColor(3)),
 ["item_q4"] = "|c"..select(4, GetItemQualityColor(4)),
 ["item_q5"] = "|c"..select(4, GetItemQualityColor(5)),
 ["item_q6"] = "|c"..select(4, GetItemQualityColor(6)),
 ["Skill"] = "|cff00EEFF",
}

addonTable.Textures = {
 ["Str"] = "Interface\\Icons\\Ability_Warrior_IntensifyRage",
 ["Agi"] = "Interface\\Icons\\ability_rogue_vigor",
 ["Int"] = "Interface\\Icons\\Ability_Mage_ConjureWater11",
 ["Sta"] = "Interface\\Icons\\Ability_Warrior_BullRush",
 ["BonusMelee"] = "Interface\\Icons\\Ability_Iyyokuk_Sword_White",
 ["BonusSpell"] = "Interface\\Icons\\Spell_Fire_BlueFlameStrike",
}

addonTable.Help = {
 ["movement"] = {"You can move your character around with |cff00FF00WASD|r keys or |cff00FF00Arrows|r",
                 "or by |cff00FF00Left-Clicking|r the tiles"},
 ["combat"]   = {"Your character has a basic melee attack which can be used by moving towards an enemy in melee range",
                 "Special Abilities can be selected by the |cff00FF001-5|r keys or |cff00FF00Left-Clicking|r on them",
				 "and then used by |cff00FF00Right-Clicking|r on an appropriate target"},
 ["items"]    = {"You can collect items using the |cff00FF00Q|r key",
                 "Collected items go into your inventory.",
				 "You can open your inventory and character sheet with the |cff00FF00C|r key",
				 "|cff00FF00Right-Clicking|r on an item in your inventory or character sheet will equip/unequip it",
				 "To delete an item in your |cff00FF99inventory|r, move the cursor over the item and press |cff00FF00DEL|r"}
}

addonTable.L = {
 ["DDB_Title"]       = "Deep Down Below",
 ["about"]           = "by |cff00FF96Fluffies|r\n EU - Well of Eternity",
 ["err0"]            = "#0 Screen not found",
 ["err1"]            = "#1 Monster not found",
 ["err2"]            = "#2 Item not found",
 ["err3"]            = "#3 Object not found",
 ["err4"]            = "#4 Inventory slot frame missing",
 -- menu
 ["btnnew"]          = "New Game",
 ["btnreset"]        = "Reset Character",
 ["btnexit"]         = "Exit Game",
 ["btnleave"]        = "Leave Game",
 ["btnreleasespirit"]= "Release Spirit",
 ["btnback"]         = "Back",
 ["loading"]         = "Loading..",
 ["mainmenu"]        = "Main Menu",
 ["help_screen"]     = "Help (Mouseover the buttons)",
 ["btnmovement"]     = "Movement",
 ["btncombat"]       = "Combat",
 ["btnitems"]        = "Items",
 ["btnhelp"]         = "Help",
 ["reset_confirm"]   = "|cffFF0000You will lose all progress for this character, are you sure?|r",
 ["yes"]             = "Yes",
 ["no"]              = "No",
 ["turn"]            = "Turn",
 ["level"]           = "Level",
 -- loading screen
 ["disposingmap"]    = "Disposing Map..",
 -- character frame
 ["delete_item_inv"] = "|cff00FF96Press *DEL* to delete this item.",
 -- combat log
 ["unit_hits"]       = "%s |cff999999hits |r %s |cff999999for |cff00FF00 %d |cff999999 damage!|r",
 ["unit_hits_spell"] = "%s's |cff00EEFF%s |cff999999hits |r %s |cff999999for|cff00FF00 %d |cff999999 damage!|r",
 ["unit_heals"]      = "%s heals %s |cff999999for|cff00FF00 %d |cff999999|r.",
 ["unit_killedby"]   = "|cff9400D3%s killed %s.|r",
 ["unit_dead"]       = "|cff9400D3%s dies.|r",
 ["item_pickup"]     = "You pick up %s",
 ["item_notexists"]  = "There are no items here.",
 ["buff_gain"]       = "|cff00aaFF%s gains buff |r%s",
 ["buff_lose"]       = "|cff00aaFF%s loses buff |r%s",
 ["xp_gained"]       = "|cffffcc00You gained |cffFFCC00%d|cffffcc00 XP.|r",
 
 -- dialogues
 ["dlg_aggro0"]      = "|cffFF0000!|r",
 ["dlg_aggro1"]      = "|cffFFFF00?|r",
 ["dlg_aggro2"]      = "|cffFFFF00Where did it go?|r",
 ["dlg_aggro3"]      = "|cff00FF00Oh.. Nevermind|r",
["dlg_skillnotready"]= "It's not ready",
["dlg_notenoughpower"]= "Not enough power",
 
 -- tilesets
 ["select_tileset"]  = "Select a tileset:",
 ["tileset_pirates"] = "Pirates Cove",
["tileset_firelands"]= "Firelands",
 ["tileset_garden"]  = "Garden",
 
 -- stat names
 ["Str"]             = SPELL_STAT1_NAME,
 ["Agi"]             = SPELL_STAT2_NAME,
 ["Int"]             = SPELL_STAT4_NAME,
 ["Sta"]             = SPELL_STAT3_NAME,
 ["BonusMelee"]      = STAT_ATTACK_POWER,
 ["BonusSpell"]      = STAT_SPELLPOWER,
 ["Armor"]           = RESISTANCE0_NAME,
}
