-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local L = addonTable.L
local game = DeepDownBelow

local floor = math.floor
local _, class = UnitClass("player")
local name = UnitName("player")

-- player creation in units.lua
game.GameData.Player =
{
   Name = name,
   Class = class,
   portrait = "Interface\\icons\\Achievement_Leader_King_Varian_Wrynn",
   ModelSize = {addonTable.UnitWidth, addonTable.UnitHeight},
   ModelPosition = {-0.8,0,0},
   db = addonTable.UnitsCore[class],
   ArmorType = "flesh",
   SkillSet = class,
   Statistics = {},
   Auras = {},
}
local p = game.GameData.Player

function p:Spawn(x, y)
 game:LoadPlayer()
 p:SetPos(x, y, true)
 p.Light = game.GameData.Map:AddLightSource(x, y, 6, 1, {0.8,0.8,0.8})
 p:StartAnimation(0)
 game:HandleTileAnchors(true)
 table.foreach(game.GameData.Map.units, function(k,u)
   if game:isOnScreen(u.x, u.y) then
    u.frame:Show()
   else
	u.frame:Hide()
   end
  end)
 table.foreach(game.GameData.Map.objects, function(k, o)
   o:SetPos(o.x, o.y)
  end)
 p.frame:Show()
end

function p:Respawn()
 if p.Status ~= "dead" then return end
 p:RemoveLight()
 p:Spawn(game.startX,game.startY)
 game:PrepareEndTurn()
end

function p:SelectSkill(skill)
 p.SelectedSkill = skill
 game:UpdateSkillBarOverlays()
end

function p:LearnSkills()
 local ss = addonTable.SkillSets[p.SkillSet]
 if not ss then return end
 wipe(p.Skills)
 table.foreach(ss, function(k, v)
  game:AddSkill(p, v) --auras.lua
 end)
end

function p:GenerateHP(arg)
 if arg == "endturn" then
  p.HPcurr = math.min(p.HPmax, p.HPcurr + math.ceil(p.HPmax / 100))
 end
end

function p:GenerateMana(arg)
 local result = 0
 if arg == "attack" then
  if p.Class == "warrior" then -- generate some rage per attack
   result = 4
  end
 elseif arg == "endturn" then
  if p.Class ~= "warrior" then
   result = 2
  end
 end

 p.Manacurr = p.Manacurr + result
 if p.Manacurr > p.Manamax then p.Manacurr = p.Manamax end
end

function p:GenerateBasicItems()

 local function deepcopy(t)
  local r = {}
  table.foreach(t, function(k,v) 
   if type(v) == "table" then
    r[k] = deepcopy(v)
   else
    r[k] = v
   end
  end)
  return r
 end
 
 p.Equipped["MainHandSlot"] = deepcopy(addonTable.Items["playerbase"]["1hsword"])
 p.Equipped["ChestSlot"] = deepcopy(addonTable.Items["playerbase"]["chest"])
 p.Equipped["LegsSlot"] = deepcopy(addonTable.Items["playerbase"]["legs"])
end

function p:Reset()
 p.Name = name
 p.portrait = "Interface\\icons\\Achievement_Leader_King_Varian_Wrynn"
 p.ModelSize = {addonTable.UnitWidth, addonTable.UnitHeight}
 p.ModelPosition = {-0.8,0,0}
 p.db = addonTable.UnitsCore[class]
 p.ArmorType = "flesh"
 game:SetUnitMethods(p) -- units.lua
 game:SetUnitVars(p, true) -- units.lua
 SelectedSkill = nil
 p:LearnSkills()
 p.XP = 0
 p:LevelUp(1, true)
 p.Light = nil
 p.Status = "normal"
 wipe(p.Statistics)
 wipe(p.Inventory)
 wipe(p.Equipped)
 p:GenerateBasicItems()
end
--p:Reset()

function game:RefreshPlayerModel(f)
  f:Undress()
  local _, i
  for _, i in pairs(p.Equipped) do
   if i.Type == "Weapon" and i.Enchant > 0 then
    local _, link = GetItemInfo(i.Model)
	if link then
	 local linkType, itemId, enchantId,
     jewelId1, jewelId2, jewelId3, jewelId4,
     suffixId, uniqueId = strsplit(":", link)
     link = linkType..":"..itemId..":"..i.Enchant..":"..jewelId1..":"..jewelId2..":"..jewelId3..":"..jewelId4..":"..suffixId..":"..uniqueId
     f:TryOn(link)
	end
   else
    f:TryOn(i.Model)
   end
  end
end

function game:RefreshPlayerModels()
 if p.frame then
  p:SetModel()
  game:RefreshPlayerModel(p.frame)
 end
 
 if game.CharacterFrame and game.CharacterFrame:IsVisible() then
  game:RefreshPlayerModel(game.CharacterFrame.PlayerModel)
 end
 if game.MenuFrame.dressmodel and game.MenuFrame.dressmodel:IsShown() then
  game:RefreshPlayerModel(game.MenuFrame.dressmodel)
 end
end


-- XP related
local XPCurve = {400,1300,2300,3500,6300,9900,14400,19800,26300,33900, -- 1 to 10
                 56300,80300,105800,133000,161900} -- 11 to 15
--                 56300,80300,105800,133000,161900,192400,224600,258500,294800,333600} -- 11 to 20
function game:MaxLevel()
 return table.getn(XPCurve)
end

local function UpdatePlayerLevel()
 local last = 0
 
 if p.XP > XPCurve[table.getn(XPCurve)] then p.XP = XPCurve[table.getn(XPCurve)] - 1 end
 
 for lvl, xp in pairs(XPCurve) do
  if lvl ~= p.Level and p.XP < xp and p.XP >= last then
   p:LevelUp(lvl)
   -- set all the mobs at the same level
   game:SetMobsLevel(lvl)
   break
  end
  last = xp
 end
end

-- max xp for current level
function p:LevelXP(lvl)
 return XPCurve[lvl] and XPCurve[lvl] or 0
end

function p:GainXP(xp)
 xp = xp / 2
 p.XP = p.XP + xp
 UpdatePlayerLevel()
 if p.XP >= p:LevelXP(p.Level) and p.Level >= game:MaxLevel() then p.XP = p:LevelXP(p.Level) - 1 end
 game:Log(string.format(L["xp_gained"], xp))
end

function p:CalcXp(tar)
 local l = p.Level
 local t = tar.Level
 local result = 0
 
 if t == l then
  result = (l * 5) + 45
 end
 if ( t > l ) then
  result = ((l * 5) + 45) * (1 + 0.05 * (t - l))
 end

 if ( t < l ) then
   if (l < 6) then g = 0; end
   if (l > 5 and l < 40) then
    g = l - 5 - floor(l / 10)
   end
   if l > 39 then
    g = l - 1 - floor(l / 5)
   end
   if (t > g) then
    if (l < 8) then z = 5 end
    if (l > 7 and l < 10) then z = 6 end
    if (l > 9 and l < 12 ) then z = 7 end
    if (l > 11 and l < 16 ) then z = 8 end
    if (l > 15 and l < 20 ) then z = 9 end
    if (l > 19 and l < 40 ) then z = 9 + floor(l / 10) end
    if (l > 39) then z = 5 + floor(l / 5) end
    result = (l * 5 + 45) * (1 - (l - t) / z)
   else -- target level too low
    result = 0
   end
  end

 result = floor(result + 0.5)

 if (tar.unittype == "elite") then
  result = result * 2
 end

 return p.Level >= game:MaxLevel() and 0 or result
end
--

-- Inventory
function p:SetDamageReduction()
 -- damreduction data da
 -- tipoarmatura * numero indossati - leveldifference*fattore
 p.Stats["DamageReduction"] = 1
 table.foreach(p.Equipped, function(k,v)
  if v.Type == "Armor" then
   local mod = v.SubType == "Plate" and 0.04 or v.SubType == "Leather" and 0.03 or v.SubType == "Cloth" and 0.02 or 0
   p.Stats["DamageReduction"] = p.Stats["DamageReduction"] - mod
  end
 end)
end

local function getEmptySlot()
 local i = 1
 while i < p.InvCapacity and p.Inventory[i] do
  i = i + 1
 end
 return i <= p.InvCapacity and i or nil
end

function p:AffectStats(i)

 if i.Stats then
  for k,v in pairs(i.Stats) do
   if type(v) == "number" then
    p.Stats[k] = p.Stats[k] + v
   else
    local s = string.gsub(v, "%%", "")
	s = tonumber(s)
	p.Stats[k] = p.Stats[k] * (1 + s / 100)
   end
  end
 end

 -- item enchants
 if i.Enchant then
  for k,v in pairs(addonTable.ItemEnchants[i.Enchant].Stats) do
   p.Stats[k] = p.Stats[k] + v
  end
 end
end

function p:UnAffectStats(i)

 if i.Stats then
  for k,v in pairs(i.Stats) do
   if type(v) == "number" then
    p.Stats[k] = p.Stats[k] - v
   else
    local s = string.gsub(v, "%%", "")
	s = tonumber(s)
	p.Stats[k] = (p.Stats[k] / (1 + s / 100))
   end
  end
 end

 -- item enchants
 if i.Enchant then
  for k,v in pairs(addonTable.ItemEnchants[i.Enchant].Stats) do
   p.Stats[k] = p.Stats[k] - v
  end
 end
end

function p:EquipItem(invslot)
 if not p:CanAct() then return end

 if not invslot then return end
 local i = p.Inventory[invslot + 1]
 if not i or not i:isWearable() then return end

 if not p.Equipped[i.EQSlot] then
  p.Inventory[invslot + 1] = nil
  p.Equipped[i.EQSlot] = i
  p:AffectStats(i)
  game:RefreshPlayerModels()
  game:PrepareEndTurn()
  p:SetDamageReduction()
  return i
 end
end

function p:UnEquipItem(eqslot)
 if not p:CanAct() then return end

 if not eqslot then return end
 local i = p.Equipped[eqslot]
 local invslot = getEmptySlot()
 if not i or not invslot then return end

 p.Inventory[invslot] = i
 p.Equipped[eqslot] = nil
 p:UnAffectStats(i)
 game:RefreshPlayerModels()
 game:RefreshPlayerStats()
 p:CheckStats()
 --game:PrepareEndTurn()
 p:SetDamageReduction()
 return i, invslot - 1
end

function p:PickUpItem()
 if not p:CanAct() then return end

 local tile = game.GameData.Map:GetTile(p.x, p.y)
 if table.getn(tile.items) > 0 then
  local invslot = getEmptySlot()
  
  if not invslot then game:Log("Inventario pieno") return end
  
  local i = tile.items[1]
  tile:RemoveItem(i)
  game.GameData.Map:RemoveLightSource(i.Light)
  p.Inventory[invslot] = i
  local invslotframe = _G["DDBCFInvSlot"..invslot - 1]
  if not invslotframe then game:Error() return end
  invslotframe.tex:SetTexture(i.Texture)
  invslotframe.Item = i
  p:IncStatistic("items_pickedup", 1)
  if i.Quality == 5 then
   p:IncStatistic("items_pickedup_leg", 1)
  end
  game:Log(string.format(L["item_pickup"], i.Name))
  game:PrepareEndTurn()
  game:HandleTileAnchors(true)
 else
  game:Log(L["item_notexists"])
 end
end

-- Statistics
function p:IncStatistic(s, i)
 if not p.Statistics[s] then p.Statistics[s] = 0 end

 p.Statistics[s] = p.Statistics[s] + i
end