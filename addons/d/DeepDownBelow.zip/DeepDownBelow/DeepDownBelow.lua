-- Deep Down Below by Fluffies
-- EU - Well of Eternity
-- All rights reserved.
 
local addonName, addonTable = ...
local L = addonTable.L

--[[
TODO:
 - mobs' skills
 - quests
 - a* pathfinding?
 - traps?
 - bosses
]]

-- v1.0.0
addonTable.version = 1000
DeepDownBelow_Saves = {}

local function ShowMainframe()
 if not DeepDownBelow.mainframe then
  DeepDownBelow:GenerateMainframe()
  DeepDownBelow:SetScreen("menu")
 end
 if DeepDownBelow.mainframe:IsVisible() then
  DeepDownBelow.mainframe:Hide()
 else
  DeepDownBelow.mainframe:Show()
 end
end

local eventframe = CreateFrame("Frame")
eventframe:RegisterEvent("VARIABLES_LOADED")
local function eventhandler(self, event, ...)
 if event == "VARIABLES_LOADED" then
  if not DeepDownBelow_Character then
   DeepDownBelow:SavePlayer()
  end
 end
end
eventframe:SetScript("OnEvent", eventhandler)

-- slash commands
SLASH_DEEPDOWNBELOW1 = "/ddb"
SLASH_DEEPDOWNBELOW2 = "/deepdownbelow"
SlashCmdList["DEEPDOWNBELOW"] = ShowMainframe