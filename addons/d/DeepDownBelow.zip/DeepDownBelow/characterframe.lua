-- Deep Down Below by Fluffies
-- EU - Well of Eternity
-- character sheet, equipped items & inventory
local addonName, addonTable = ...
local game = DeepDownBelow
local L = addonTable.L
local w,h = 300,400
local modelw,modelh = 200,300
local p

 -- "Interface\\Buttons\\UI-Quickslot"  possibile slot vuoto per inventario
 
 function game:ToggleCharacterFrame()
 if game.CharacterFrame:IsVisible() then
  game.CharacterFrame:Hide()
  game.InventoryFrame:Hide()
 else
  game.CharacterFrame:Show()
  game.InventoryFrame:Show()
 end
end
 
local mouseovereditem
function game:CharacterFrame_Init()
 p = game.GameData.Player
 -- Character Frame
 local cf = game:CreateFrame("Frame", "DeepDownBelowCharacterFrame", UIParent)
 cf:EnableMouse(true)
 cf:SetMovable()
 cf:RegisterForDrag("LeftButton")
 cf:SetScript("OnDragStart", function(self) self:StartMoving() end)
 cf:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
 cf:SetClampedToScreen(true)
 cf:SetFrameStrata("DIALOG")
 cf:SetPoint("LEFT")
 cf:SetSize(w,h)
 cf:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
                         edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                         tile = true, tileSize = 4, edgeSize = 4, 
                         insets = { left = 6, right = 6, top = 6, bottom = 6 }})
 cf:SetBackdropColor(0,0,0,0.99)
 
 cf:CreateDDBTexture()
 cf.tex:SetAllPoints()
 --cf.tex:SetTexture(0.1,0.1,0.1)
 
 -- possibili background
 --cf.tex:SetTexture("Interface\\CharacterFrame\\Char-Paperdoll-Parts")
 --cf.tex:SetTexCoord(0.00390625, 0.66406250, 0.00781250, 0.36718750)
 --
 --cf.tex:SetTexture("Interface\\CharacterFrame\\Char-Stat-Middle")
 --cf.tex:SetTexCoord(0.00390625, 0.66406250, 0.00000000, 1.00000000)
 --
 
 cf.EquippedSlots = {}
 cf.InventorySlots = {}
 cf:Show() -- temporaneo
 game.CharacterFrame = cf

 -- Player Model
 local d = game:CreateFrame("DressUpModel", "DDBCFPlayerModel", cf)
 d:SetSize(modelw,modelh)
 d:SetPoint("TOPLEFT", cf, "TOPLEFT", 50, -50)
 local _, fileName = UnitRace("player")
 local texture = DressUpTexturePath(fileName)
 d:CreateDDBTexture("BACKGROUND")
 d.tex:SetAllPoints()
 d.tex:SetTexture(texture..1)
 d:SetUnit("player") -- come duplicare il modello del pg direttamente?
 cf.PlayerModel = d
 d:SetScript("OnShow", function() game:RefreshPlayerModel(cf.PlayerModel) end)
 --f.BackgroundTopRight:SetTexture(texture..2)
 --f.BackgroundBotLeft:SetTexture(texture..3)
 --f.BackgroundBotRight:SetTexture(texture..4)

 -- basic item slot
 local function setupslot(slot, t)
  slot:SetSize(35,35)
  slot:CreateDDBTexture()
  slot.tex:SetAllPoints()
  slot.Refresh = function(self) 
    if slot.Item then
	 slot.tex:SetTexture(slot.Item.Texture)
	else
	 slot.tex:SetTexture(slot.baseTex)
	end
   end
  slot:SetScript("OnEnter", function(self)
    if not self.Item then return end
    GameTooltip:SetOwner(slot, "TOP", 0, 5)
    GameTooltip:ClearLines()
	self.Item:FillTooltip()
    if t == "inv" then
	 mouseovereditem = self
	 GameTooltip:AddLine(L["delete_item_inv"])
	end
	GameTooltip:Show()
   end)
  slot:SetScript("OnLeave", function() mouseovereditem = nil GameTooltip:Hide() end)
  slot:SetScript("OnMouseUp", function(self, btn)
    if self.Item then
     if btn == "RightButton" then
	  local p = game.GameData.Player
	  local eqslot, invslot
	  if t == "inv" then
	   if p.Equipped[self.Item.EQSlot] then
        local i, inv = p:UnEquipItem(self.Item.EQSlot)
	    if i then
	     invslot = cf.InventorySlots[inv]
	  	 eqslot = cf.EquippedSlots[self.Item.EQSlot]
         invslot.Item = i
         eqslot.Item = nil
		 invslot:Refresh()
		 eqslot:Refresh()
	    end
	   end
 	   local i = p:EquipItem(self.id)
	   if i then
	    eqslot = cf.EquippedSlots[self.Item.EQSlot]
		invslot = self
        eqslot.Item = i
        invslot.Item = nil
        invslot:Refresh()
        eqslot:Refresh()
	   end
	  else
       local i, inv = p:UnEquipItem(self.id)
	   if i then
	    invslot = cf.InventorySlots[inv]
		eqslot = self
        invslot.Item = i
        eqslot.Item = nil
        invslot:Refresh()
        eqslot:Refresh()
	   end
     end
	end
   end
  end)
 end

 -- Equipped Items Slots
  local function createEQslot(slot)
   local result = game:CreateFrame("Button", "DDBCF"..slot, cf, "ItemButtonTemplate")
   setupslot(result, "eq")
   local _, textureName = GetInventorySlotInfo(slot)
   result.id = slot
   result.tex:SetTexture(textureName)
   result.baseTex = textureName
   cf.EquippedSlots[slot] = result
   return result
  end
 
 local f = createEQslot("HeadSlot")
 f:SetPoint("TOPRIGHT", d, "TOPLEFT", -5, 0)
 f = createEQslot("NeckSlot")
 f:SetPoint("TOPRIGHT", d, "TOPLEFT", -5, -40)
 f = createEQslot("ShoulderSlot")
 f:SetPoint("TOPRIGHT", d, "TOPLEFT", -5, -80)
 f = createEQslot("ChestSlot")
 f:SetPoint("TOPRIGHT", d, "TOPLEFT", -5, -120)
 f = createEQslot("HandsSlot")
 f:SetPoint("TOPLEFT", d, "TOPRIGHT", 5, 0)
 f = createEQslot("LegsSlot")
 f:SetPoint("TOPLEFT", d, "TOPRIGHT", 5, -40)
 f = createEQslot("FeetSlot")
 f:SetPoint("TOPLEFT", d, "TOPRIGHT", 5, -80)
 f = createEQslot("Trinket0Slot")
 f:SetPoint("TOPLEFT", d, "TOPRIGHT", 5, -120)
 f = createEQslot("MainHandSlot")
 f:SetPoint("TOP", d, "BOTTOM", -20, -5)
 --f = createEQslot("SecondaryHandSlot")
 --f:SetPoint("TOP", d, "BOTTOM", 20, -5)

 cf.RefreshEquipped = function()
  table.foreach(cf.EquippedSlots, function(k,v)
    if not p.Equipped[k] then
	 v.Item = nil
     v:Refresh()
    elseif v.Item ~= p.Equipped[k] then
     v.Item = p.Equipped[k]
     v:Refresh()
    end
   end)
  end
 
 -- Inventory
 d = game:CreateFrame("Frame", "DDBCFInventoryFrame", UIParent)
 d:CreateDDBTexture()
 d.tex:SetAllPoints()
 d:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
                         edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                         tile = true, tileSize = 4, edgeSize = 4, 
                         insets = { left = 6, right = 6, top = 6, bottom = 6 }})
 d:SetBackdropColor(0,0,0,0.99)
 d:SetSize(w, 150)
 d:SetPoint("TOP", cf, "BOTTOM")
 d:SetFrameStrata("DIALOG")
 d:EnableMouse(true)
 --d:SetMovable()
 --d:RegisterForDrag("LeftButton")
 --d:SetScript("OnDragStart", function(self) self:StartMoving() end)
 --d:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
 --d:SetClampedToScreen(true)
 game.InventoryFrame = d

 -- Equipped Items Slots
  local function createINVslot(slot)
   local result = game:CreateFrame("Button", "DDBCFInvSlot"..slot, d, "ItemButtonTemplate")
   setupslot(result, "inv")
   local _, textureName = GetInventorySlotInfo("Bag0Slot")
   result.id = slot
   result.baseTex = textureName
   result.tex:SetTexture(textureName)
   cf.InventorySlots[slot] = result
   return result
  end
  
  cf.RefreshInventory = function()
   table.foreach(cf.InventorySlots, function(k,v)
    if not p.Inventory[k+1] then
	 v.Item = nil
	 v:Refresh()
    elseif v.Item ~= p.Inventory[k+1] then
	 v.Item = p.Inventory[k+1]
	 v:Refresh()
	end
   end)
  end

  local row, itemsperrow, i = 0, math.floor(w / 35)
  for i = 0,game.GameData.Player.InvCapacity - 1 do
   f = createINVslot(i)
   f:SetPoint("TOPLEFT", d, "TOPLEFT", 5 + 35 * (i % itemsperrow), -5 - (row * 35))
   row = row + (i % itemsperrow == itemsperrow - 1 and 1 or 0)
  end
 --
 
 --[[cf:SetScript("OnShow", function()
  cf:RefreshEquipped()
  cf:RefreshInventory()
 end)]]
 
 cf:Hide()
 d:Hide()
end

function game:DeleteSelectedItem()
 if mouseovereditem then
  mouseovereditem.Item = nil
  mouseovereditem:Refresh()
  p.Inventory[mouseovereditem.id + 1] = nil
  p:IncStatistic("items_deleted", 1)
 end
end