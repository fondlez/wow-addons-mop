-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local Sp = addonTable.Spells
local T = addonTable.Textures
local L = addonTable.L
local game = DeepDownBelow

local STRATA_UI = "HIGH"
local STRATA_PANELS = "HIGH"

local powerbarcolor = PowerBarColor[UnitPowerType("player")]

function game:CreateUserInterface()

 local gf = game.GameFrame

 -- User Interface frames
 local function createuiframe()
  local result = game:CreateFrame("Frame", nil, gf)
  result:CreateDDBTexture("BACKGROUND")
  result.tex:SetAllPoints()
  result:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
                         edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                         tile = true, tileSize = 4, edgeSize = 4, 
                         insets = { left = 6, right = 6, top = 6, bottom = 6 }})
  result:SetBackdropColor(0,0,0,1)
  return result
 end
 
 local function createunitframe()
  local f = createuiframe()
  f:SetSize(200,50)
  -- portrait
  f.portrait = f:CreateTexture("ARTWORK")
  f.portrait:SetSize(40,40)
  f.portrait:SetPoint("LEFT")
  -- hp bar
  f.hpbackground = f:CreateTexture("ARTWORK")
  f.hpbackground:SetSize(100,20)
  f.hpbackground:SetPoint("TOPRIGHT", f, "TOPRIGHT", -10, -4)
  f.hpbackground:SetTexture(0,1,0,0.2)
  f.hpforeground = f:CreateTexture("OVERLAY")
  f.hpforeground:SetSize(100,20)
  f.hpforeground:SetPoint("TOPLEFT", f.hpbackground, "TOPLEFT")
  f.hpforeground:SetTexture(0,1,0,1)
  -- power bar
  f.manabackground = f:CreateTexture("ARTWORK")
  f.manabackground:SetSize(100,20)
  f.manabackground:SetPoint("TOP", f.hpbackground, "BOTTOM", 0, -2)
  f.manabackground:SetTexture(0.2,0.2,0.2,0.2)
  f.manaforeground = f:CreateTexture("ARTWORK")
  f.manaforeground:SetSize(100,20)
  f.manaforeground:SetPoint("TOPLEFT", f.manabackground, "TOPLEFT")
  --if addonTable.powerbarcolors and addonTable.powerbarcolors[game.GameData.Player.Class] then
   --f.manaforeground:SetTexture(unpack(addonTable.powerbarcolors[game.GameData.Player.Class]))
  --else
   --f.manaforeground:SetTexture(0,0,1,1)
  --end
  f.manaforeground:SetTexture(powerbarcolor.r, powerbarcolor.g, powerbarcolor.b)
  -- xp bar
  f.xpbackground = f:CreateTexture("ARTWORK")
  f.xpbackground:SetSize(100,10)
  f.xpbackground:SetPoint("TOP", f.manabackground, "BOTTOM", 0, -2)
  f.xpbackground:SetTexture(1,0,1,0.2)
  f.xpforeground = f:CreateTexture("ARTWORK")
  f.xpforeground:SetSize(100,10)
  f.xpforeground:SetPoint("TOPLEFT", f.xpbackground, "TOPLEFT")
  f.xpforeground:SetTexture(1,0,1,1)
  return f
 end

 -- Leave Game Button
 local f = game:CreateFrame("Button", "DDBGameFrameBtn1", gf, "UIPanelButtonTemplate")
 f:SetSize(120, 25)
 f:SetPoint("TOPRIGHT", gf, "TOPRIGHT", -5, -5)
 f:SetNormalTexture("Interface\\BUTTONS\\BlueGRAD64")
 f:SetHighlightTexture("Interface\\MINIMAP\\UI-QuestBlobMinimap-Inside")
 DDBGameFrameBtn1Text:SetTextColor(1,1,1)
 f:SetScript("OnClick", function(self) game:SetScreen("menu") end)
 f:SetText(L["btnleave"])
 -- Player Frame
 f = createunitframe()
 f:SetPoint("BOTTOMLEFT", gf, "BOTTOMLEFT", 5, 5)
 gf.PlayerFrame = f
 -- target frame
 f = createunitframe()
 f:SetPoint("BOTTOMRIGHT", gf, "BOTTOMRIGHT", -5, 5)
 f.manabackground:Hide()
 f.manaforeground:Hide()
 f.xpbackground:Hide()
 f.xpforeground:Hide()
 f:Hide()
 gf.TargetFrame = f
 -- skillbar
 f = createuiframe()
 f:SetSize(200, 45)
 f:SetPoint("BOTTOM", gf, "BOTTOM", 0, 5)
 local i
 for i = 0,4 do
  local btn = game:CreateFrame("Button", nil, f)
  btn:SetSize(35,35)
  btn:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", i * 35 + i + 5, 5)
  btn.icon = btn:CreateTexture()
  btn.icon:SetAllPoints()
  btn.icon:SetTexture(0,0,0,1)
  btn.SetSkill = game.buttonSetSkill

  btn:SetScript("OnEnter", function(self)
   GameTooltip:ClearLines()
   GameTooltip:SetOwner(self, "ANCHOR_TOP")
   GameTooltip:AddLine(Sp[self.skill].name)
   GameTooltip:Show()
  end)
  btn:SetScript("OnClick", function(self)
   self:Fire()
  end)
  btn:SetScript("OnLeave", function(self)
   GameTooltip:Hide()
  end)

  btn.Fire = function(self) 
    game.GameData.Player:SelectSkill(self.skill)
   end
  if game.GameData.Player.Skills[i + 1] then
   btn:SetSkill(game.GameData.Player.Skills[i + 1].name)
  end
  
  f["button"..i] = btn
 end
 gf.SkillBar = f

 -- combat log
 f = createuiframe()
 f:SetSize(400, 90)
 f:SetPoint("TOPLEFT", gf, "TOPLEFT", -5, 5)
 f:CreateDDBText()
 f.text:SetFont("Fonts\\FRIZQT__.ttf", 14, "")
 f.text:SetAllPoints()
 f.text:SetJustifyH("LEFT")
 f.text:SetJustifyV("BOTTOM")
 f:SetFrameStrata("DIALOG")
 f.lines = {}
 f.RefreshText = function()
   f.text:SetText("")
   local s = ""
   local numlines = table.getn(f.lines)
   local i = numlines
   local wraph = 0
   while f.text:GetStringHeight() < f:GetHeight() and i > 0 do
    s = "   "..f.lines[i].."\n"..s
	f.text:SetText(s)
    i = i - 1
   end
  end

 f:SetScript("OnEnter", function(self) self:SetHeight(400) self.large = true self:RefreshText() end)
 f:SetScript("OnLeave", function(self) self:SetHeight(90) self.large = false self:RefreshText() end)
 f.Clear = function()
   wipe(f.lines)
  end
 f.AddLine = function(self, l)
   table.insert(f.lines, l)
   if table.getn(f.lines) > 27 then
    table.remove(f.lines, 1)
   end
   f:RefreshText()
  end
 game.Log = f.AddLine
 gf.CombatLog = f
 
 --[[
 -- turn text disabled as of 0.3a
 gf.TurnText = f:CreateFontString()
 gf.TurnText:SetFont("Fonts\\skurri.ttf", 20, "")
 gf.TurnText:SetPoint("TOP", gf, "TOP", 0, -20)
 gf.TurnText:SetText(L["turn"].." "..game.GameData.Turn)
 ]]
 
 -- map side panels
 -- mostly to cover the disappearing edge tiles
 --left
 local panel = game:CreateFrame("Frame", nil, game.MapFrame)
 panel:SetPoint("TOPLEFT", game.MapFrame, "TOPLEFT")
 panel:SetPoint("BOTTOMLEFT", game.MapFrame, "BOTTOMLEFT")
 panel:SetWidth(addonTable.TileWidth * 2)
 panel:CreateDDBTexture()
 panel.tex:SetAllPoints()
 panel.tex:SetTexture(0,0,0)
 panel:SetFrameStrata(STRATA_PANELS)
 game.MapFrame.leftpanel = panel
 --right
 panel = game:CreateFrame("Frame", nil, game.MapFrame)
 panel:SetPoint("TOPRIGHT", game.MapFrame, "TOPRIGHT")
 panel:SetPoint("BOTTOMRIGHT", game.MapFrame, "BOTTOMRIGHT")
 panel:SetWidth(addonTable.TileWidth * 2)
 tex = panel:CreateDDBTexture()
 panel.tex:SetAllPoints()
 panel.tex:SetTexture(0,0,0)
 panel:SetFrameStrata(STRATA_PANELS)
 game.MapFrame.rightpanel = panel
 --top
 panel = game:CreateFrame("Frame", nil, game.MapFrame)
 panel:SetPoint("TOPLEFT", game.MapFrame, "TOPLEFT", 0, addonTable.TileHeight)
 panel:SetPoint("TOPRIGHT", game.MapFrame, "TOPRIGHT", 0, addonTable.TileHeight)
 panel:SetHeight(addonTable.TileHeight * 2)
 panel:CreateDDBTexture()
 panel.tex:SetAllPoints()
 panel.tex:SetTexture(0,0,0)
 panel:SetFrameStrata(STRATA_PANELS)
 game.MapFrame.toppanel = panel
 --bottom
 panel = game:CreateFrame("Frame", nil, game.MapFrame)
 panel:SetPoint("BOTTOMLEFT", game.MapFrame, "BOTTOMLEFT", 0, -addonTable.TileHeight)
 panel:SetPoint("BOTTOMRIGHT", game.MapFrame, "BOTTOMRIGHT", 0, -addonTable.TileHeight)
 panel:SetHeight(addonTable.TileHeight * 2)
 panel:CreateDDBTexture()
 panel.tex:SetAllPoints()
 panel.tex:SetTexture(0,0,0)
 panel:SetFrameStrata(STRATA_PANELS)
 game.MapFrame.bottompanel = panel
 --
 
 -- release spirit button
 local btn = game:CreateFrame("Button", nil, game.MapFrame.toppanel, "UIPanelButtonTemplate")
 btn:SetPoint("CENTER")
 btn:SetSize(150, 25)
 btn:SetText(L["btnreleasespirit"])
 btn:SetScript("OnClick", function(self)
  self:Hide()
  game.GameData.Player:Respawn()
 end)
 btn:Hide()
 game.BTNReleaseSpirit = btn

 -- buffs frame 
 local buffs = game:CreateFrame("Frame", nil, game.MapFrame.toppanel)
 buffs:SetPoint("RIGHT", game.MapFrame.bottompanel, "RIGHT", -5, 0)
 buffs:SetFrameStrata(STRATA_UI)
 buffs:SetSize(1,1)
 buffs.Frames = {}
 buffs.count = 0
 buffs:Show()

 local function refresh(bf)
  if bf.aura then
   bf.text:SetText(bf.aura.duration > 0 and bf.aura.duration or "*")
  end
 end
 
 local function createauraframe(p, i, aura)
  if p.Frames[i] then return end
  local result = game:CreateFrame("Frame", nil, p)
  p.Frames[i] = result
  p.count = p.count + 1
  result.aura = aura
  result:SetSize(25,25)
  result:CreateDDBTexture()
  result.tex:SetAllPoints()
  result.tex:SetTexture(Sp[aura.id].icon)
  result:CreateDDBText()
  result.text:SetPoint("TOP", result, "BOTTOM")
  result.text:SetFont("Fonts\\ARIALN.ttf", 12, "")
  refresh(result)
  result:Show()
 end

 local function removeauraframe(p, i)
  local f = p.Frames[i]
  if f == nil then return end
  p.Frames[i] = nil
  p.count = p.count - 1
  game:DisposeFrame(f)
 end
 
 local function refreshauraframes(p)
  local counter = 0
  for _,j in pairs(p.Frames) do
   j:SetPoint("RIGHT", p, "RIGHT", -(counter * 25), 0)
   counter = counter + 1
   refresh(j)
  end
 end

 buffs.CreateAuraFrame = createauraframe
 buffs.RemoveAuraFrame = removeauraframe
 buffs.RefreshAuraFrames = refreshauraframes
 gf.BuffsFrame = buffs
 
 --
 -- stats frame
 local lev = game.MapFrame.toppanel:CreateFontString()
 lev:SetFont("Fonts\\ARIALN.ttf", 16, "")
 lev:SetPoint("LEFT", game.MapFrame.bottompanel, "LEFT", 5, 0)
 gf.leveltext = lev
 local stats = game:CreateFrame("Frame", nil, game.MapFrame.toppanel)
 stats:SetPoint("LEFT", lev, "RIGHT", 5, 0)
 stats:SetFrameStrata(STRATA_UI)
 stats:SetSize(1,1)
 stats.Frames = {}
 stats:Show()

 local function addstat(s)
  local result = game:CreateFrame("Frame", nil, stats)
  stats.Frames[s] = result
  result.aura = aura
  result:SetSize(16,16)
  if laststat then
   result:SetPoint("LEFT", laststat, "RIGHT", 10, 0)
  else
   result:SetPoint("LEFT", stats, "RIGHT", 10, 0)
  end

  result:CreateDDBTexture()
  result.tex:SetAllPoints()
  result.tex:SetTexture(T[s])
  result:CreateDDBText()
  result.text:SetPoint("LEFT", result.tex, "RIGHT")
  result.text:SetFont("Fonts\\ARIALN.ttf", 16, "")

   local function onenter()
    GameTooltip:ClearLines()
    GameTooltip:SetOwner(result, "TOP", 0, 5)
    game:StatFillTooltip(s) -- globals.lua
    GameTooltip:Show()
   end
  
  result:SetScript("OnEnter", onenter)
  result:SetScript("OnLeave", function() GameTooltip:Hide() end)  
  
  result:Show()
  laststat = result.text
 end

 addstat("Str")
 addstat("Agi")
 addstat("Int")
 addstat("Sta")
 addstat("BonusMelee")
 addstat("BonusSpell")
 gf.StatsFrame = stats
end
--

function game:UpdateSkillBarOverlays()
 local f = game.GameFrame.SkillBar
 for i = 0,4 do
  if  f["button"..i].skill == game.GameData.Player.SelectedSkill then
   ActionButton_ShowOverlayGlow(f["button"..i])
  else
   ActionButton_HideOverlayGlow(f["button"..i])
  end
 end
end

function game:RefreshPlayerStats()
 local function refreshlabel(s)
  game.GameFrame.StatsFrame.Frames[s].text:SetText("|cff00FF00"..(game.GameData.Player.Stats[s] and game.GameData.Player.Stats[s] or 0).."|r")
 end
 
 game.GameFrame.leveltext:SetText(L["level"]..": |cff00FFaa"..game.GameData.Player.Level.."|r")
 refreshlabel("Str")
 refreshlabel("Agi")
 refreshlabel("Int")
 refreshlabel("Sta")
 refreshlabel("BonusMelee")
 refreshlabel("BonusSpell") 
end

local lasthp, lastmana, lastxp = 0,0,0
function game:RefreshPowerBars()
 local f = game.GameFrame.PlayerFrame
 local p = game.GameData.Player
 local t = p.Target

 -- player frame
 if lasthp ~= p.HPcurr then
  f.hpforeground:SetWidth(p.HPcurr / p.HPmax * 100)
 end
 if lastmana ~= p.Manacurr then
  f.manaforeground:SetWidth(p.Manacurr / p.Manamax * 100)
 end
 if lastxp ~= p.XP then
  local curr = p.XP - p:LevelXP(p.Level - 1)
  local tot = p:LevelXP(p.Level) - p:LevelXP(p.Level - 1)
  f.xpforeground:SetWidth(curr / tot * 100)
 end

 lasthp = p.HPcurr
 lastmana = p.Manacurr
 lastxp = p.XP

 -- target frame
 if not t then return end
 f = game.GameFrame.TargetFrame
 f.hpforeground:SetWidth(t.HPcurr / t.HPmax * 100)
-- f.manaforeground:SetWidth(0)

 --f.portrait:SetTexture(t.portrait)
end