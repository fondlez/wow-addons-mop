-- Deep Down Below by Fluffies
-- EU - Weel of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

local backdrop = {bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
                         edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                         tile = true, tileSize = 16, edgeSize = 16, 
                         insets = { left = 4, right = 4, top = 4, bottom = 4 }}

local counter = 0
function game:CreateChatBubble(s, u, duration)
 local f = game:CreateFrame("GameTooltip", "DDBChatBubble"..counter, nil, "GameTooltipTemplate")
 local t = GetTime()
 counter = counter + 1
 f:SetOwner(u.frame,"ANCHOR_TOP")
 --f:SetPoint("CENTER",u.frame,"CENTER")
 f:SetFrameStrata("TOOLTIP")
 --f:SetPoint("BOTTOM", u.frame, "TOP", 0, 10)
 f:ClearLines()
 table.foreach(s, function(_,v) f:AddLine("|cffFFFFFF"..v.."\|r") end)
 f:SetScript("OnUpdate", function(self) 
   if not u or not u.frame or GetTime() > t + (duration and duration or 3) then
	counter = counter - 1
    game:DisposeFrame(self)
   end
   self:SetAlpha(1 - (GetTime() - t) / duration)
  end)
 f:SetBackdrop(backdrop)
 f:SetBackdropColor(0,0,0,0.8)
 f:Show()
end
