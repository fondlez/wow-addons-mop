-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow
local L = addonTable.L

local min, max, floor, abs = math.min, math.max, math.floor, math.abs

-- used tile types
local current_tileset = addonTable.tilesets["prison"]

game.GameData.Map = {}
local m = game.GameData.Map

--[[ one map only as of 0.2a

function game:GetUnitMap(u)
 return game.GameData.Maps[u.Map]
end

function game.GameData.Map
 return game.GameData.Maps[game.GameData.CurrentMap]
end

function game:SetMap(id)
 if game.GameData.Map then
  --game:SaveMap(game.GameData.Map)
  DisposeMap(game.GameData.Map.id)
 end
 game.GameData.CurrentMap = id
end ]]--

local function gettile(m, x, y)
 return m.tiles[x.."-"..y]
end

function game:GetAdjacentTile(x, y, dir)
 local destX, destY = x, y
 if dir == "LEFT" then
  destX = destX - 1
 elseif dir == "RIGHT" then
  destX = destX + 1
 elseif dir == "UP" then
  destY = destY - 1
 elseif dir == "DOWN" then
  destY = destY + 1
 else 
  return
 end
 local m = game.GameData.Map
 return m and m:GetTile(destX, destY) or nil,destX, destY
end

-- Line of Sight
function game:HasLos(x1, y1, x2, y2)
 local horiz
 local distx, disty = abs(x1 - x2), abs(y1 - y2)
 local safecounter = 0
 while (distx > 1 or disty > 1) and safecounter < 50 do
  local tx, ty = (x1 < x2 and x1 + 1 or x1 - 1), (y1 < y2 and y1 + 1 or y1 - 1)
  if distx > disty then -- or (distx < disty and disty > 0 and game.GameData.Map:GetTile(x1, ty):isObstacle()) then
   horiz = true
  else --if distx < disty  or (distx > 0 and game.GameData.Map:GetTile(tx, y1):isObstacle()) then
   horiz = false
  end
  
  --if distx > disty and distx > 0 and game.GameData.Map:GetTile(tx, y1):isObstacle() then
   --horiz = false
  --end
  
  if horiz then
   x1 = tx
  else
   y1 = ty
  end

  if game:IsObstacle(game.GameData.Map:GetTile(x1, y1), true) then
   return
  end
  distx, disty = abs(x1 - x2), abs(y1 - y2)
  safecounter = safecounter + 1
 end
 return true
end
--

-- visual/movement obstacle parameter?
function game:IsObstacle(tile, VisualOnly)
 if not tile then return end
 if VisualOnly then
  return tile.tiletype == "Wall" or (tile.object and tile.object.Status == "closed")
 else
  return tile.tiletype == "Wall" or tile.unit or (tile.object and tile.object.Status == "closed")
 end
end

local function tileRemoveItem(t, i)
 for k,v in pairs(t.items) do
  if v == i then
   table.remove(t.items, k)
   return
  end
 end
end

-- map generation types and templates:
-- 0  = procedural BSP Tree
function game:GenerateMap(Type, w, h, id, tileset)
 if m and m.Dispose then m:Dispose() end

 if addonTable.tilesets[tileset] then
  current_tileset = addonTable.tilesets[tileset]
 end
 
 m.Width  = w
 m.Height = h
 
 m.tiles = {}
 m.units = {}
 m.objects = {}
 m.lightsources = {}

 for x = 0,w do
  for y = 0,h do
   m.tiles[x.."-"..y] = {}
   m.tiles[x.."-"..y].items = {}
   m.tiles[x.."-"..y].RemoveItem = tileRemoveItem
   m.tiles[x.."-"..y].tiletype = "Wall"
   m.tiles[x.."-"..y].visibility = 0 -- obscured
  end
 end
 -- lighting.lua
 m.AddLightSource = addonTable.mapAddLightSource
 m.RemoveLightSource = addonTable.mapRemoveLightSource
 m.GetTile = gettile
 -- dispose methods
 m.Dispose = function()
  game:StartLoadProcess(L["disposingmap"], function()
   if m.objects[1] then
    m.objects[1]:RemoveLight()
    m.objects[1]:Dispose(1)
   end
   if m.units[1] then
    m.units[1]:RemoveLight()
    m.units[1]:Dispose(1)
   end
 end, function() return m.units[1] == nil and m.objects[1] == nil end)
 game.PostLoad = function()
   wipe(m.objects)
   wipe(m.units)
   wipe(m.lightsources)
   wipe(m)
   collectgarbage()
  end
 end
 m.DisposeUnits = function()
  while table.getn(m.units) > 0 do
   m.units[1]:RemoveLight()
   m.units[1]:Dispose(1)
  end
  wipe(m.units)
 end
 m.DisposeObjects = function()
  while table.getn(m.objects) > 0 do
   m.objects[1]:RemoveLight()
   m.objects[1]:Dispose(1)
  end
  wipe(m.objects)
 end
 --
 if Type == 0 then
  game:GenerateRandomMap(m, current_tileset)
 end

  m.Populate = function()
  m:DisposeUnits()
 
  local cm = game.GameData.Map
  local i = 150
  local db = current_tileset.mobs1
  local rnd = table.getn(db)
  while i > 0 do
   local x, y = math.random(1, cm.Width), math.random(1, cm.Height)
   local tile = cm:GetTile(x,y)
   if not tile.unit and not game:IsObstacle(cm.tiles[x.."-"..y]) and addonTable:distance(x, y, game.GameData.Player.x, game.GameData.Player.y) > 10 then
    game:PlaceNewUnit(db[math.random(rnd)], x, y, 1, "base")
    i = i - 1
   end
  end
 end
 
 return m
end

function game:isOnScreen(x, y, affectedbylight)
 local result
 local cam = game.Camera
 local left = -floor(cam.gapX / addonTable.TileWidth) +1
 local top = floor(cam.gapY / addonTable.TileHeight) +1
 local right = -floor(cam.gapX / addonTable.TileWidth) + addonTable.Htiles -1
 local bottom = floor(cam.gapY / addonTable.TileHeight) + addonTable.Vtiles -1

 if affectedbylight then
  local camoffsetX = -floor(cam.gapX / addonTable.TileWidth)
  local camoffsetY =  floor(cam.gapY / addonTable.TileHeight)
  local fakex = x - camoffsetX
  local fakey = y - camoffsetY
  local tilef = game.MapFrame.tilescontainer.tiles[fakex.."-"..fakey] -- tile frame
  if not tilef then return end
  return tilef:GetAlpha() > 0 and true or false
 end
 
 return x > left and x < right and y > top and y < bottom
end

local lastgapX, lastgapY = 0,0
function game:HandleTileAnchors(forced)
 local currentmap = game.GameData.Map
 if not currentmap then return end
  
 local Htiles = addonTable.Htiles
 local Vtiles = addonTable.Vtiles
 local cam = game.Camera
 local offsetX = cam.gapX % addonTable.TileWidth + addonTable.mapoffsetX
 local offsetY = cam.gapY % addonTable.TileHeight + addonTable.mapoffsetY
 local camoffsetX = -floor(cam.gapX / addonTable.TileWidth)
 local camoffsetY =  floor(cam.gapY / addonTable.TileHeight)
 game.MapFrame.tilesanchor:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", offsetX, offsetY)

 if (math.abs(lastgapX - camoffsetX) >= 1 or
     math.abs(lastgapY - camoffsetY) >= 1) or forced then
  local x,y
  -- draw visible tiles
  for x = -1,Htiles do
   for y = -1,Vtiles do
    local realx = x + camoffsetX
    local realy = y + camoffsetY
    local tilef = game.MapFrame.tilescontainer.tiles[x.."-"..y] -- tile frame
    local tile = currentmap:GetTile(realx,realy)-- tile info
    --tilef.text:SetText(realx.."-"..realy)
	tilef:Hide()
    if tile then
	 tile.visibility = tile.visibility == 0 and 0 or 1
     if x < 0 or x > Htiles - 1 or y > Vtiles - 1 or y < 0 then -- out of bounds
      if tile.unit then tile.unit.tilef = nil end
      --
     else
	  local tt = current_tileset.tt[tile.tiletype]
	  if table.getn(tile.items) > 0 then
	   tilef.tex:SetTexture(tile.items[1].Texture)
	  else
	   tilef.tex:SetTexture(tt and tt.tex or "Interface\\Icons\\INV_Misc_QuestionMark")
	  end
      if tile.visibility == 1 then -- fog of war
	   if not tilef.tex:SetDesaturated(true) then
	    tilef.tex:SetVertexColor(0.4,0.4,0.4)
	   end
	   tilef.tex:SetAlpha(addonTable.ambientlight)
	   tilef:Show()
	  else
	   tilef.tex:SetAlpha(0)
	  end
	  tilef.r = 0
	  tilef.g = 0
	  tilef.b = 0
	   -- store the unit's tile frame to easily adjust its color/alpha related to the tile
	   -- it's faster than changing the unit's parent everytime
	  if tile.unit then tile.unit.tilef = tilef end
     end
    end
   end
  end
  
  local p = game.GameData.Player
  
  -- tiles lighting
  table.foreach(currentmap.lightsources, function(k, l)
    local cX, cY = l.x - camoffsetX, l.y - camoffsetY
    if cX > -1 and cY > - 1 and cX < Htiles and cY < Vtiles then
     for x = cX - l.radius, cX + l.radius do
      for y = cY - l.radius, cY + l.radius do
 	   local realx = x + camoffsetX
       local realy = y + camoffsetY
       local tilef = game.MapFrame.tilescontainer.tiles[x.."-"..y] -- tile frame 
	   local tile = currentmap:GetTile(realx,realy)-- tile info
	   local pdist = addonTable:distance(realx, realy, p.x, p.y)
	   local dist = addonTable:distance(realx, realy, l.x, l.y)
	   local los = tile and game:HasLos(realx, realy, l.x, l.y)
	   if tilef then
	    local a = tilef.tex:GetAlpha() + (1 - math.min(1, dist / l.radius))
	    if los and a > 0 then
         tilef.tex:SetDesaturated(false)
	     a = math.max(addonTable.ambientlight, a)
	     tilef.tex:SetAlpha(a)
	     tile.visibility = 2 -- visible
	 	 tilef:Show()
 	     local r,g,b = unpack(l.color) 
	     tilef.r = math.max(tilef.r, r)
	     tilef.g = math.max(tilef.g, g)
	     tilef.b = math.max(tilef.b, b)
	     tilef.tex:SetVertexColor(tilef.r,tilef.g,tilef.b)
		 if tile.unit then
		  if tile.unit == p then
		   p.frame:SetAlpha(1)
		  else
		   tile.unit.frame:SetAlpha(a * 2)
		   tile.unit.frame:Show()
		  end
	     end
		 if tile.object then
          tile.object.frame:SetAlpha(a * 2)
		  tile.object.frame:Show()
		 end
	    end
	    if tile and (not los or dist >= l.radius) then
	     if tile.object then tile.object.frame:Hide() end
	     if tile.unit then
		  if tile.unit == p then
		   p.frame:SetAlpha(0.2)
		  else
		   tile.unit.frame:Hide()
		  end
		 end
		 --tile.visibility = tile.visibility == 2 and 1 or 0
	    end
	   end
	  end
    end	
   end
  end)
  lastgapX = camoffsetX
  lastgapY = camoffsetY
 end
end