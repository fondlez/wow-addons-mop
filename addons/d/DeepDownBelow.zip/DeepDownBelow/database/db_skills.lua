-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

-- spell
 -- t
  -- p = centered on player / u = targeted unit / t = targeted tile
  -- a = AoE / s = single target / h = self heal
 -- damsource : w = weapon, s = str modifier, a = agi, i = int, p = percent(overrides the others),  strfind will determine the damage components
 --             e = bonusmelee, k = bonusspell, l = level
 --             uppercase means full benefit, else just half of it
 
addonTable.skills =
{
--* *****************
-- AppliesAura per buff e debuff
-- ***************

 -------------- Warrior --------------
 ["heroic_strike"] = { cost = 9,
					   cooldown = 2,
                       activation = {aura = "heroic_strike",
									 deactivatable = true} },
 ["enraged_regeneration"] = {
                   cost = 25,
				   activation = {aura = "enraged_regeneration",
				                 anim = 106},
                   spell = {t = "ph",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["whirlwind"] = {
                   cost = 20,
				   activation = {anim = 126},
                   spell = {t = "ap",
				            damsource = "WS",
				            dam = 2,
							radius = 1} },
 ["heroic_throw"] = {
                   cost = 5,
				   activation = {anim = 53},
                   spell = { t = "st",
				             damsource = "WS", 	
				             dam = 1,
							 range = 6} },
 ["berserker_rage"] = {
                       cost = -15,
					   cooldown = 16,
                       activation = {aura = "berserker_rage",
									 anim = 106,} },
 -------------- Paladin --------------
 ["judgement"] = {
                   cost = 10,
				   cooldown = 3,
				   activation = {anim = 53},
                   spell = {t = "su",
				            damsource = "Sk",
				            dam = 1,
							range = 3} },
 ["holy_light"] = {
                   cost = 15,
				   cooldown = 3,
				   activation = {anim = 106},
                   spell = {t = "ph",
				            damsource = "KL",
				            dam = 0,
							range = 1} },
 ["consecration"] = {
                   cost = 20,
				   cooldown = 5,
				   activation = {anim = 106},
                   spell = {t = "ap",
				            damsource = "sk",
				            dam = 2,
							radius = 2,
							range = 2} },
 ["avenging_wrath"] = { 
                       cost = 30,
					   cooldown = 15,
                       activation = {aura = "avenging_wrath",
									 anim = 106,} },
 ["divine_shield"] = { 
                       cost = 60,
					   cooldown = 16,
                       activation = {aura = "divine_shield",
									 anim = 106,} },
 -------------- Death Knight --------------
 ["death_strike"] = {
                       cost = 5,
					   cooldown = 2,
					   activation = {anim = 58},
					   spell = {t = "su",
					            damsource = "WS",
								dam = 2,
								range = 1,
					            OnHit = function(_, u, t)
					                     if not t then return end
								         game:Do_Heal(u, u, game:ApplyDamageBonus(u, u, 2, "ws"), "spell", "death_strike")
					                    end } },
 ["death_grip"] = {
                   cost = 5,
				   cooldown = 6,
				   activation = {anim = 53},
                   spell = {t = "su",
				            damsource = "",
				            dam = 0,
							range = 6,
							OnHit = function(_, u, t)
							         if not t then return end
									 local x1, y1 = u.x, u.y
									 local x2, y2 = t.x, t.y
									 local mx = x1 > x2 and -1 or x1 < x2 and 1 or 0
									 local my = y1 > y2 and -1 or y1 < y2 and 1 or 0
									 
									 local tile = game.GameData.Map:GetTile(x1 + mx, y1 + my)
									 if tile and not tile.unit and not game:IsObstacle(tile) then
									  t:SetPos(x1 + mx, y1 + my)
									 end
									end } },
 ["howling_blast"] = {
                   cost = 30,
				   activation = {anim = 53},
				   cooldown = 2,
                   spell = {t = "at",
				            damsource = "wsK",
				            dam =12,
							range = 6,
							radius = 1} },
["death_coil"] = {
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            damsource = "sK",
				            dam = 1,
							range = 6 }, },
 ["anti_magic_shell"] = {
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "anti_magic_shell",
									 anim = 106,} },
 -------------- Rogue --------------
 ["sinister_strike"] = { 
                       cost = 10,
                       activation = {anim = 58},
					   spell = {t = "su",
					            damsource = "WA",
								dam = 2,
								range = 1} },
 ["recuperate"] = {
                   cost = 25,
                   activation = {aura = "recuperate",
				                 anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["fan_of_knives"] = {
                   cost = 20,
				   activation = {anim = 126},
                   spell = {t = "ap",
				            damsource = "wa",
				            dam = 2,
							radius = 1} },
 ["shuriken_toss"] = {
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            damsource = "wa",
				            dam = 1,
							range = 6} },
 ["combat_readiness"] = {
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "combat_readiness",
									 anim = 106,} },
 -------------- Monk --------------
 ["blackout_kick"] = {
                       cost = 10,
                       activation = {anim = 95},
					   spell = {t = "su",
					            damsource = "WA",
								dam = 2,
								range = 1} },
 ["surging_mist"] = {
                   cost = 25,
				   activation = {anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["spinning_crane_kick"] = {
                   cost = 20,
				   activation = {anim = 126},
                   spell = {t = "ap",
				            damsource = "wa",
				            dam = 2,
							radius = 1} },
 ["jade_lightning"] = {
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            damsource = "wa",
				            dam = 1,
							range = 6} },
 ["fortifying_brew"] = {
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "fortifying_brew",
									 anim = 106,} },
 -------------- Hunter --------------
 ["binding_shot"] = {
                       cost = 10,
                       activation = {anim = 110},
					   spell = {t = "su",
					            damsource = "WA",
								dam = 2,
								range = 8} },
 ["bandage_self"] = {
                   cost = 25,
				   activation = {anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["volley"] = {
                   cost = 20,
				   activation = {anim = 110},
                   spell = {t = "at",
				            damsource = "wa",
				            dam = 2,
							radius = 1,
							range = 6} },
 ["explosive_shot"] = {
                   cost = 15,
				   activation = {anim = 110},
                   spell = {t = "st",
				            AppliesAura = {"explosive_shot"},
				            damsource = "wa",
				            dam = 1,
							range = 8} },
 ["deterrence"] = {
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "deterrence",
									 anim = 106,} },
-------------- Druid --------------
 ["moonfire"] = { 
                       cost = 10,
                       activation = {anim = 53},
					   spell = {t = "su",
					            damsource = "WI",
								dam = 2,
								range = 8} },
 ["rejuvenation"] = { 
                   cost = 25,
				   activation = {aura = "rejuvenation",
				                 anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["hurricane"] = { 
                   cost = 20,
				   activation = {anim = 53},
                   spell = {t = "at",
				            damsource = "wi",
				            dam = 2,
							radius = 1,
							range = 6} },
 ["starfire"] = { 
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            damsource = "wi",
				            dam = 1,
							range = 8} },
 ["barkskin"] = { 
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "barkskin",
									 anim = 106,} },
-------------- Priest --------------
 ["smite"] = {         cost = 10,
                       activation = {anim = 53},
					   spell = {t = "su",
					            damsource = "IL",
								dam = 2,
								range = 8} },
 ["greater_heal"] = { 
                   cost = 25,
				   activation = {anim = 106},
                   spell = {t = "hp",
				            damsource = "il",
				            dam = 6,
							range = 1} },
 ["holy_nova"] = { 
                   cost = 20,
				   activation = {anim = 106},
                   spell = {t = "ap",
				            damsource = "li",
				            dam = 2,
							radius = 1} },
 ["shadow_word_pain"] = { 
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            AppliesAura = {"shadow_word_pain"},
				            damsource = "l",
				            dam = 1,
							range = 8} },
 ["power_word_shield"] = { 
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "power_word_shield",
									 anim = 106,} },
-------------- Warlock --------------
 ["incinerate"] = { 
                       cost = 10,
                       activation = {anim = 53},
					   spell = {t = "su",
					            damsource = "WI",
								dam = 2,
								range = 1,
								OnHit = function(u, t) 
								 -- if t ha immolate, danno aggiuntivo
								end} },
 ["ember_tap"] = { 
                   cost = 25,
				   activation = {anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["rain_of_fire"] = { 
                   cost = 20,
				   activation = {anim = 53},
                   spell = {t = "at",
				            damsource = "wi",
				            dam = 2,
							radius = 1,
							range = 8} },
 ["immolate"] = { 
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            AppliesAura = {"immolate"},
				            damsource = "wi",
				            dam = 1,
							range = 8} },
 ["demon_skin"] = { 
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "demon_skin",
									 anim = 106,} },
-------------- Mage --------------
 ["fireball"] = { 
                       cost = 10,
                       activation = {anim = 53},
					   spell = {t = "su",
					            damsource = "WI",
								dam = 2,
								range = 1} },
 ["evocation"] = { 
                   cost = 25,
				   activation = {anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10, -- 100% mana
							range = 1} },
 ["flamestrike"] = { 
                   cost = 20,
				   activation = {anim = 53},
                   spell = {t = "at",
				            damsource = "wi",
				            dam = 2,
							radius = 1,
							range = 6} },
 ["pyroblast"] = { 
                   cost = 15,
				   activation = {anim = 53},
                   spell = {t = "st",
				            damsource = "wa",
				            dam = 1,
							range = 6} },
 ["mana_shield"] = { 
                       cost = 40,
					   cooldown = 16, -- danni su mana invece di hp
                       activation = {aura = "mana_shield",
									 anim = 106,} },
-------------- Shaman --------------
 ["lightning_bolt"] = { 
                       cost = 10,
                       activation = {anim = 53},
					   spell = {t = "su", -- fulmination stacks
					            damsource = "WI",
								dam = 2,
								range = 8} },
 ["healing_surge"] = { 
                   cost = 25,
				   activation = {anim = 106},
                   spell = {t = "hp",
				            damsource = "p",
				            dam = 10,
							range = 1} },
 ["thunderstorm"] = { 
                   cost = 20,
				   activation = {anim = 53},
                   spell = {t = "ap",
				            damsource = "wi",
				            dam = 2,
							radius = 1} },
 ["earth_shock"] = { 
                   cost = 15,
				   activation = {anim = 53}, -- additional fulmination damage
                   spell = {t = "st",
				            damsource = "wi",
				            dam = 1,
							range = 8} },
 ["ancestral_guidance"] = { 
                       cost = 40,
					   cooldown = 16,
                       activation = {aura = "ancestral_guidance",
									 anim = 106,} },
}

addonTable.SkillSets =
{
 ["WARRIOR"]     = {"heroic_strike", "enraged_regeneration", "whirlwind", "heroic_throw", "berserker_rage"},
 ["PALADIN"]     = {"judgement", "holy_light", "consecration", "avenging_wrath", "divine_shield"},
 ["DEATHKNIGHT"] = {"death_strike","death_grip","howling_blast","death_coil","anti_magic_shell"},
 ["ROGUE"]       = {"sinister_strike","recuperate","fan_of_knives","shuriken_toss","combat_readiness"},
 ["MONK"]        = {"blackout_kick","surging_mist","spinning_crane_kick","jade_lightning","fortifying_brew"},
 ["HUNTER"]      = {"binding_shot","bandage_self","volley","explosive_shot","deterrence"},
 ["DRUID"]       = {"moonfire","rejuvenation","hurricane","starfire","barkskin"},
 ["PRIEST"]      = {"smite","greater_heal","holy_nova","shadow_word_pain","power_word_shield"},
 ["WARLOCK"]     = {"incinerate","ember_tap","rain_of_fire","immolate","demon_skin"},
 ["MAGE"]        = {"fireball","evocation","flamestrike","pyroblast","mana_shield"},
 ["SHAMAN"]      = {"lightning_bolt","healing_surge","thunderstorm","earth_shock","ancestral_guidance"}
}

-- for names and icons
local SpellIDs = 
{
 heroic_strike = 78,
 enraged_regeneration = 55694,
 whirlwind = 15578,
 heroic_throw = 57755,
 berserker_rage = 18499,
 judgement = 20271,
 holy_light = 635, 
 consecration = 26573, 
 avenging_wrath = 31884,
 divine_shield = 40733,
 death_strike = 49998,
 death_grip = 49576,
 howling_blast = 61061,
 death_coil = 122282,
 anti_magic_shell = 31662,
 sinister_strike = 14873,
 recuperate = 73651,
 fan_of_knives = 142163,
 shuriken_toss = 137586,
 combat_readiness = 74001,
 blackout_kick = 100784,
 surging_mist = 123273,
 spinning_crane_kick = 117640,
 jade_lightning = 123333,
 fortifying_brew = 115203,
 binding_shot = 109248,
 bandage_self = 72925,
 volley = 130790,
 explosive_shot = 53301,
 deterrence = 19263,
 moonfire = 8921,
 rejuvenation = 774,
 hurricane = 16914,
 starfire = 2912,
 barkskin = 22812,
 smite = 71841,
 greater_heal = 2060,
 holy_nova = 132157,
 shadow_word_pain = 46560,
 power_word_shield = 17,
 incinerate = 29722,
 ember_tap = 114635,
 rain_of_fire = 5740,
 immolate = 11962,
 demon_skin = 20798,
 fireball = 133,
 evocation = 12051,
 flamestrike = 2120,
 pyroblast = 11366,
 mana_shield = 46151,
 lightning_bolt = 403,
 healing_surge = 8004,
 thunderstorm = 51490,
 earth_shock = 8042,
 fulmination = 88766,
 ancestral_guidance = 108281,
}

addonTable.Spells = {}

table.foreach(SpellIDs, function(k,v)
 local n, _, i = GetSpellInfo(v)
 addonTable.Spells[k] = {name = n and n or "", icon = i and i or ""}
end)