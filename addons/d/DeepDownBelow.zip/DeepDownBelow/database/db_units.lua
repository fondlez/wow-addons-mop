-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow
local S = addonTable.S -- sounds

addonTable.units_speed = 3 -- units animation speed
addonTable.UnitWidth = 64
addonTable.UnitHeight = 64

-- scaling
addonTable.UnitsCore =
{
 -- monsters
 ["base"] =
  {
   swing   = {1,3},  -- base swing
   hp      = 15, -- base hp
   sta     = 3,
   stalvl  = 6,
  },
 ["elite"] =
  {
   swing = {1,4},
   hp    = 25, -- base hp
   sta     = 4,
   stalvl = 7,
  },
 ["boss"] =
  {
   swing = {2,3},
   hp    = 50, -- base hp
   sta     = 6,
   stalvl = 9,
  },
 -- player class templates
 ["WARRIOR"] =
  {
   swing         = {2,2},
   hp            = 25,    -- base hp
   str           = 4,     -- base strength
   agi           = 1,     -- base agility
   int           = 1,     -- base intellect
   sta           = 4,     -- base stamina
   bonusmelee    = 4,     -- base bonusmelee
   bonusspell    = 0,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 1,     -- agility per level
   intlvl        = 0,     -- intellect per level
   stalvl        = 4,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 0,     -- bonusspell per level
  },
 ["PALADIN"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 4,     -- base strength
   agi           = 1,     -- base agility
   int           = 3,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 1,     -- agility per level
   intlvl        = 1,     -- intellect per level
   stalvl        = 3,     -- stamina per level
   bonusmeleelvl = 1,     -- bonusmelee per level
   bonusspelllvl = 1,     -- bonusspell per level
  },
 ["DEATHKNIGHT"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 4,     -- base strength
   agi           = 1,     -- base agility
   int           = 2,     -- base intellect
   sta           = 3,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 1,     -- agility per level
   intlvl        = 1,     -- intellect per level
   stalvl        = 3,     -- stamina per level
   bonusmeleelvl = 1,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["ROGUE"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["MONK"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["HUNTER"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["DRUID"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["PRIEST"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["WARLOCK"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["MAGE"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
 ["SHAMAN"] =
  {
   swing         = {1,4},
   hp            = 25,    -- base hp
   str           = 2,     -- base strength
   agi           = 2,     -- base agility
   int           = 2,     -- base intellect
   sta           = 2,     -- base stamina
   bonusmelee    = 2,     -- base bonusmelee
   bonusspell    = 2,     -- base bonusspell
   strlvl        = 2,     -- strength per level
   agilvl        = 2,     -- agility per level
   intlvl        = 2,     -- intellect per level
   stalvl        = 2,     -- stamina per level
   bonusmeleelvl = 2,     -- bonusmelee per level
   bonusspelllvl = 2,     -- bonusspell per level
  },
}
local core = addonTable.UnitsCore

-- Monsters db
addonTable.Monsters = {
 ["TEMPLATE"] = 
             {
		      Name = "Template Monster",
			  portrait = "Interface\\Icons\\INV_Misc_QuestionMark",
			  Model = 0,
			  ModelSize = {addonTable.UnitWidth, addonTable.UnitHeight},
              ModelPosition = {-1,0,0},
			  Status = "normal",
			  sounds = S["None"],
			  ArmorType = "flesh",
			 },
    ["dummy"] =
             {
			  Name = "a training dummy",
			  Model = "creature\\object\\woodendummy.m2",
			  Status = "stunned",
             },
 -- prison
 ["thief"] =
             {
			  Name = "a thief",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 35073,
			  ModelSize = {80,80},
			  sounds = S["Pirate"],
             },
 ["pirate_captain"] =
             {
			  Name = "a pirate captain",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 4429,
			  ModelSize = {80,80},
			  sounds = S["Pirate"],
             },
 ["thug"] =
             {
			  Name = "a thug",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 34331,
			  ModelSize = {80,80},
			  sounds = S["Pirate"],
             },
["pirate_swashbuckler"] =
             {
			  Name = "a pirate swashbuckler",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 796,
			  sounds = S["Pirate"],
             },
["mastiff"] =
             {
			  Name = "a hungry mastiff",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 30211,
			  ModelSize = {80,80},
			  sounds = S["Mastiff"],
             },
 --
 -- firelands
 ["fire_elemental"] =
             {
			  Name = "a fire elemental",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 35372,
			  --ModelSize = {80,80},
			  sounds = S["Elemental"],
             },
 ["dragon"] =
             {
			  Name = "a young red dragon",
			  portrait = "Interface\\Icons\\INV_Misc_Head_Dragon_01",
			  Model = 24875,
			  ModelSize = {100,100},
			  sounds = S["Dragon"],
             },
 --
 ["zandalari_champ"] =
             {
			  Name = "a zandalari champion",
			  portrait = "Interface\\Icons\\RACIAL_TROLL_BERSERK",
			  Model = 31745,
			  sounds = S["Troll"],
             },
 ["teddy_bear"] =
             {
			  Name = "an enraged bear",
			  portrait = "Interface\\Icons\\Spell_druid_bearhug",
			  Model = 820,
			  sounds = S["Bear"],
             },
["illidan"] =
             {
			  Name = "Illidan Stormrage",
			  portrait = "Interface\\Icons\\Achievement_Boss_Illidan",
			  Model = 21135,
			  ModelSize = {100,100},
			  sounds = S["Illidan"],
             },
}
--[[
-- candidati tutorial
creature\cat\cat_hallowsend.m2
creature\cupid\cupid.m2
creature\firedancer\firedancer.m2
creature\firekitty\firekitty.m2
-- creature varie
creature\etherial\etherial.m2
 -- tileset pirates/bandits
creature\humanthief\humanthief.m2
creature\humanmalepiratecaptain\humanmalepiratecaptain.m2
creature\humanmalepiratecrewman\humanmalepiratecrewman.m2
creature\humanmalepirateswashbuckler\humanmalepirateswashbuckler.m2
creature\mastiff\mastiff.m2
 -- tileset construct
creature\arcanetitan\arcanetitan.m2
creature\deepholmgolem\deepholmgolem.m2
creature\goblinbombbot\goblinbombbot.m2
creature\golemiron\golemiron.m2
creature\irondwarf\irondwarf.m2
 -- tileset holy
creature\avengingangel\avengingangel.m2
 -- tileset garden
creature\gronn\gronn.m2
creature\gnoll\gnoll.m2
creature\bear\bear.m2
creature\boar\boar.m2
creature\bogbeast\bogbeast.m2
creature\crystalsatyr\crystalsatyr.m2
creature\direwolf\direwolf.m2
creature\ettin\ettin.m2
creature\monkey\monkey.m2
creature\murloc\murloc.m2
creature\alliancelionmount\alliancelion.m2
creature\ancientofwar\ancientofwar.m2
creature\ancientprotector\ancientprotector.m2
creature\armadillo\armadillo.m2
creature\beaver\beaver.m2
creature\bogbeast\bogbeast.m2
creature\crane\crane.m2
 -- tileset demon
creature\demonform\demonform.m2
creature\diablo\diablofunsized.m2
creature\doomguardoutland\doomguardoutland.m2
creature\demonhunter\demonhunter.m2
creature\infernal\infernal.m2
creature\felbeastshadowmoon\felbeastshadowmoon.m2
 -- tileset firelands
creature\fandralfirecat\fandralfirecatnoarmor.m2
creature\fandralfirescorpion\fandralfirescorpion.m2
 creature\darkhound\darkhound.m2
creature\hellhound\hellhound.m2
creature\moltengiant\moltengiant.m2
creature\boundfireelemental\unboundfireelementallord.m2
creature\felboar\felboar.m2
creature\firehawk\firehawk.m2
 -- tileset scourge
creature\northrendgeist\northrendgeist.m2
creature\lich\lich.m2
creature\ghost\ghost.m2
creature\ghoul\ghoul.m2
creature\coldwraith\coldwraith.m2
creature\fleshgolem\fleshgolem.m2
creature\darkhound\darkhound.m2
creature\bonegolem\bonegolem.m2
creature\bonespider\bonespider.m2
creature\beholder\beholder.m2
character\skeleton\male\skeletonmale.m2
creature\bear\spectralbear.m2

-- boss
creature\arthaslichking\arthaslichking.m2
creature\deathwing\deathwing.m2
creature\boneguard\boneguard.m2
creature\dragondarkshade\dragondarkshade.m2
creature\ettin\throngus.m2
creature\fandralstaghelm\fandralstaghelm.m2
creature\haremmatron\haremmatron.m2
creature\kargath\kargath.m2
creature\deathwing\deathwing.m2


creature\deathwingdungeon\deathwingdungeon.m2

creature\illidan_past\illidan_past.m2
creature\illidanglaive\creature_illidansglaive.m2 -- item

-- new
creature\felbeastshadowmoon\felbeastshadowmoon.m2
]]

--[[
-- candidati tutorial
creature\cat\cat_hallowsend.m2
creature\cupid\cupid.m2
creature\firedancer\firedancer.m2
creature\firekitty\firekitty.m2
-- creature varie
creature\etherial\etherial.m2
FANTASMINO 20894
 -- tileset construct
creature\arcanetitan\arcanetitan.m2
TITAN GUARDIAN - AQ EGITTO 35386
MECHANOLORD VIOLA MECHANAR 19162  
creature\deepholmgolem\deepholmgolem.m2
STONE GOLEM ROSSO - GRIGIO 33073
creature\goblinbombbot\goblinbombbot.m2
CRAWLER MINE 49134
BOMBA CHE CAMMINA ULDUAR 19139
creature\golemiron\golemiron.m2
STONE GOLEM BLU - GRIGIO 26140
creature\irondwarf\irondwarf.m2
NANO DI PIETRA 26092
NANO BREWFEST 22461

 -- tileset holy
creature\avengingangel\avengingangel.m2
AVENGING ANGEL 35572
 -- tileset garden
creature\gronn\gronn.m2
GRONN ROSSO 47215
GRONN MARRONE 18645
creature\gnoll\gnoll.m2
AZZURRO BRETELLE ROSSE 494
VERDE CON ARMATURA 3199
creature\boar\boar.m2
LILLA CARINO!! 20831
NORMALE 503
creature\bogbeast\bogbeast.m2
VERDE TELDRASSIL 1081
creature\crystalsatyr\crystalsatyr.m2
SATYR LILLA - ROSA 2011
creature\direwolf\direwolf.m2
BIANCO - GRIGIO 802
FANTSMA SEMI TRASPARENTE 17283
creature\ettin\ettin.m2
MARRONE 2 TESTE 34706
creature\monkey\monkey.m2
30184
creature\murloc\murloc.m2
BABY BLU 15393
ADULTO BLU - VERDE - GIALLO 983
creature\alliancelionmount\alliancelion.m2
LEONE 37168
creature\ancientofwar\ancientofwar.m2
ALBERO 1461
creature\ancientprotector\ancientprotector.m2
ALBERO PELOSO VIOLA 2429
creature\armadillo\armadillo.m2
36591
creature\beaver\beaver.m2
41832
creature\crane\crane.m2
VERDE 43868
 -- tileset demon
creature\demonform\demonform.m2
21322
creature\diablo\diablofunsized.m2
10992
creature\doomguardoutland\doomguardoutland.m2
16269
creature\demonhunter\demonhunter.m2
39027
creature\infernal\infernal.m2
20721
creature\felbeastshadowmoon\felbeastshadowmoon.m2
4716
 -- tileset firelands
CANE CHE BRUCIA 38450
creature\fandralfirecat\fandralfirecatnoarmor.m2
38150
creature\fandralfirescorpion\fandralfirescorpion.m2
37539
creature\darkhound\darkhound.m2
3916
creature\hellhound\hellhound.m2
38223
creature\moltengiant\moltengiant.m2
38765
creature\boundfireelemental\unboundfireelementallord.m2
38520
creature\felboar\felboar.m2
19249
creature\firehawk\firehawk.m2
38446
 -- tileset scourge
creature\northrendgeist\northrendgeist.m2
creature\lich\lich.m2
creature\ghost\ghost.m2
creature\ghoul\ghoul.m2
creature\coldwraith\coldwraith.m2
creature\fleshgolem\fleshgolem.m2
creature\darkhound\darkhound.m2
creature\bonegolem\bonegolem.m2
creature\bonespider\bonespider.m2
creature\beholder\beholder.m2
character\skeleton\male\skeletonmale.m2
creature\bear\spectralbear.m2

-- boss
ANIMA GOLEM 48838
creature\arthaslichking\arthaslichking.m2
creature\deathwing\deathwing.m2
creature\boneguard\boneguard.m2
creature\dragondarkshade\dragondarkshade.m2
creature\ettin\throngus.m2
creature\fandralstaghelm\fandralstaghelm.m2
creature\haremmatron\haremmatron.m2
creature\kargath\kargath.m2
creature\deathwing\deathwing.m2


creature\deathwingdungeon\deathwingdungeon.m2

creature\illidan_past\illidan_past.m2
creature\illidanglaive\creature_illidansglaive.m2 -- item
]]