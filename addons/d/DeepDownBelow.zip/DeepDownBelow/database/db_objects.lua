-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow
local S = addonTable.S -- sounds

-- Objects db
addonTable.Objects = {
 ["TEMPLATE"] = 
             {
		      Name = "Template Object",
			  Model = 0,
			  ModelSize = {32,32},
			  ModelPosition = {-0.9,0,0},
			  Type = "junk",
			  Status = "closed", -- door state
			  InverseAnim = false,
			  sounds = {},
			 },
 ["door"] =
             {
			  Name = "a door",
			  Type = "door",
			  Model = "world\\azeroth\\karazahn\\activedoodads\\karazahn_bridgedoors.m2",
             },
 ["gate"] =
             {
			  Name = "a gate",
			  Type = "door",
			  Model = "world\\azeroth\\karazahn\\activedoodads\\karazahnportcullis.m2",
			  InverseAnim = true,
             },
 ["greenfield"] =
             {
			  Name = "a slimy door",
			  Type = "door",
			  Model = "world\\azeroth\\zulgurub\\activedoodads\\doors\\zulgurubforcefield.m2",
             },
["lava"] = -- unused
             {
			  Name = "lava waterfall?",
			  Model = "world\\blackwingv2\\passivedoodads\\blackwingdescent_lava_library_01.m2",
			  ModelPosition = {-10, 10,-110},
             },
}

--[[
-- doors
world\azeroth\zulgurub\activedoodads\doors\zulgurub_pendoor_gate.m2
world\dungeon\orgrimmarraid\ograid_bossdoor.m2
world\dungeon\orgrimmarraid\ograid_door_01.m2
world\dungeon\orgrimmarraid\ograid_small_door_01.m2
world\expansion01\doodads\hellfirecitadel\activedoodads\doors\hf_mag_door.m2
world\expansion01\doodads\pvp\activedoodads\doors\pvp_lordaeron_door.m2
world\expansion01\doodads\zulaman\doors\zulaman_entrancegate.m2

-- generic
world\dungeon\challenge\challengemode_wall_flat.m2
world\dungeon\challenge\challengemode_wall_dome.m2
world\expansion01\doodads\zulaman\waterfalls\zulamanwaterfalls.m2
world\expansion02\doodads\chamber_aspects_black\aspects_lavafalls\chamber_lavafalls_06.m2
world\expansion02\doodads\chamber_aspects_black\aspects_lavafalls\chamber_lavafalls_03.m2
world\expansion02\doodads\dragonblight\waterfalls\dragonblight_combin_waterfall_07.m2
world\expansion02\doodads\icecrown\lights\icecrown_blue_fire.m2
world\expansion02\doodads\icecrown\lights\icecrown_blueglow_01.m2
world\expansion02\doodads\icecrown\lights\icecrown_greenglow_01.m2
world\expansion02\doodads\icecrown\lights\icecrown_greenpillar_fire.m2
world\expansion02\doodads\icecrown\lights\icecrown_redglow_01.m2
world\expansion02\doodads\scholazar\waterfalls\sholazar_dirty_waterfall.m2
world\expansion02\doodads\zuldrak\lightfx\zuldrak_blue_fire02.m2
-- fog
world\expansion02\doodads\scholazar\fog\sholazarbasin_fog_warm.m2
world\expansion02\doodads\scholazar\fog\sholazarbasin_fog_cool.m2

-- fields
world\azeroth\zulgurub\activedoodads\doors\zulgurubforcefield.m2
world\dungeon\easttemple\waterdoor\pa_easttemple_waterdoor_01.m2
world\dungeon\easttemple\waterdoor\pa_easttemple_waterdoor_02.m2
world\expansion01\doodads\zulaman\doors\zulaman_firedoor.m2
world\expansion01\doodads\zulaman\doors\zulaman_winddoor.m2

world\goober\ud_foamsword_01.m2
]]--