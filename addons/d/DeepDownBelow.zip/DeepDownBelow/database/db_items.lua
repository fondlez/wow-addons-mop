-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

-- Item Enchants
addonTable.ItemEnchants = {
 [0]   = { Name = "", Stats = {}},
 [803] = { Name = "Fiery Weapon",
           Stats = {["BonusMelee"] = 5}, }
}

 --[[
 "HeadSlot","NeckSlot","ShoulderSlot","ChestSlot","HandsSlot","LegsSlot","FeetSlot","Trinket0Slot","MainHandSlot","SecondaryHandSlot"
 ]]
 
-- Item Weights
local mid_budget_IW = 
{ 
 ["_1_2_3_4_"] =
  { 
    armor = 5,
    mainstat = 3,
    stamina = 4,
    power = 0,
   -- weapons
    dice = 0.5,
	damage = 0.8,
  },
 ["_5_6_7_8_9_"] =
 {
    armor = 5,
	mainstat = 3,
    stamina = 4,
    power = 0.1,
	-- weapons
    dice = 0.5,
	damage = 0.8,
 },
 ["_10_11_12_13_14_"] =
 {
    armor = 5,
	mainstat = 3,
    stamina = 4,
    power = 0.2,
	-- weapons
    dice = 0.5,
	damage = 0.8,
 },
  ["_15_"] =
 {
    armor = 5,
	mainstat = 3,
    stamina = 4,
    power = 0.2,
	-- weapons
    dice = 0.5,
	damage = 0.8,
 },
} -- mid budget end

local high_budget_IW = 
{
 ["_1_2_3_4_"] =
  { 
    armor = 7,
    mainstat = 3.5,
    stamina = 5,
    power = 0,
	-- weapons
    dice = 0.5,
	damage = 0.8,
  },
  ["_5_6_7_8_9_"] =
  {
	armor = 7,
	mainstat = 3.5,
    stamina = 5,
    power = 0.1,
	-- weapons
    dice = 0.5,
	damage = 0.8,
  },  
  ["_10_11_12_13_14_"] =
  {
	armor = 7,
	mainstat = 3.5,
    stamina = 5,
    power = 0.2,
	-- weapons
    dice = 0.5,
	damage = 0.8,
  }, 
  ["_15_"] =
  {
	armor = 8,
	mainstat = 4,
    stamina = 6,
    power = 0.3,
	-- weapons
    dice = 0.6,
	damage = 0.9,
  }, 
} -- high budget end

function addonTable:GetItemBudgetType(i)
 if i.EQSlot == "HeadSlot" or i.EQSlot == "ShoulderSlot" or i.EQSlot == "ChestSlot" or i.EQSlot == "LegsSlot" or i.EQSlot == "HeadSlot" then
	return high_budget_IW
 else --if i.EQSlot == "NeckSlot" or i.EQSlot == "HandsSlot" or i.EQSlot == "FeetSlot" or i.EQSlot == "Trinket0Slot" or i.EQSlot == "HeadSlot"
      --or  i.EQSlot == "MainHandSlot" or  i.EQSlot == "SecondaryHandSlot" then
	 return mid_budget_IW
 end
end

addonTable.TemplateItem = 
             {
		      Name = "Template Item",
			  Desc = "",
			  Texture = "Interface\\Icons\\INV_Misc_QuestionMark",
			  Itemlevel = 0, -- this value will be added to the drop level (for max level tiers)
			  Model = 0, 
			  Enchant = 0,
			  Type = "Armor",
			  SubType = "",
			  Quality = 0,
			  EQSlot = "",
			  Stats = {},
			  StatsAllowed = "",
			  Damage = false,
			 }

-- Items db
addonTable.Items = {}
addonTable.Items_Legendary = {}

-- StatsAllowed
-- s = str, a = agi, i = int, m = stam, k = melee, l = spell
-- h = str/agi/int a random one
-- j = spell/melee a random one
------------------------------------------------------------
-------------------- level 1 player base gear --------------
------------------------------------------------------------
addonTable.Items["playerbase"] =
{
 -- Weapons
  ["1hsword"] = {
  Name = "a training sword",
  Desc = "",
  Texture = "Interface\\Icons\\inv_sword_47",
  Model = 77256,
  Itemlevel = 1,
  Quality = 0,
  Type = "Weapon",
  SubType = "1h",
  Damage = {1,6},
  Stats = {},
  StatsAllowed = "",
  Enchant = 0,
  EQSlot = "MainHandSlot",
 },
 ["chest"] = {
  Name = "apprentice's shirt",
  Texture = "Interface\\Icons\\inv_shirt_14",
  Desc = "",
  Model = 49514,
  SubType = "Cloth",
  EQSlot = "ChestSlot",
  StatsAllowed = "",
  Itemlevel = 1,
  Quality = 0,
  Type = "Armor",
  SubType = "",
  Stats = {},
  StatsAllowed = "",
  Enchant = 0,
 },
 ["legs"] = {
  Name = "apprentice's pants",
  Desc = "",
  Texture = "Interface\\Icons\\inv_pants_02",
  Model = 49515,
  SubType = "Cloth",
  EQSlot = "LegsSlot",
  StatsAllowed = "",
  Itemlevel = 1,
  Quality = 0,
  Type = "Armor",
  SubType = "",
  Stats = {},
  StatsAllowed = "",
  Enchant = 0,
 },
}

------------------------------------------------------------
-------------------- level 1 to 4 tiers --------------------
------------------------------------------------------------
addonTable.Items["_1_2_3_4_"] =
{
 -- Weapons
 {
  Model = 25401,
  Type = "Weapon",
  SubType = "1h",
  StatsAllowed = "sm",
 },
 {
  Model = 90811,
  Type = "Weapon",
  SubType = "1h",
  StatsAllowed = "am",
 },
 {
  Model = 25404,
  Type = "Weapon",
  SubType = "2h",
  StatsAllowed = "im",
 },
 {
  Model = 6256,
  Type = "Weapon",
  SubType = "2h",
  StatsAllowed = "m",
 },
 -- Strength
 {
  Model = 8092,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 8094,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 8091,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 8093,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 8089,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 -- Agility
 {
  Model = 25354,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 25349,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 25353,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 25355,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 25351,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 -- Intellect
 {
  Model = 8746,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 3799,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 3796,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 3797,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 3793,
  SubType = "Cloth",
  StatsAllowed = "iml",
 }
}
------------------------------------------------------------
-------------------- level 5 to 9 tiers --------------------
------------------------------------------------------------
addonTable.Items["_5_6_7_8_9_"] =
{
 -- Weapons
 {
  Model = 82971,
  StatsAllowed = "skml",
 },
 {
  Model = 101226,
  StatsAllowed = "ikml",
 },
 {
  Model = 94028,
  StatsAllowed = "akm",
 },
 -- Strength
 {
  Model = 7934,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 7918,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 7930,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 7919,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 7921,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 7933,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
-- Agility
 {
  Model = 15129,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 18528,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 4243,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 2312,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 7921,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 2307,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- Intellect
 {
  Model = 24657,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 24659,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 24655,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 24656,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 24658,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 24654,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- Accessories
 {
  Name = "A Common Necklace",
  Type = "Miscellaneous",
  Texture = "Interface\\Icons\\inv_jewelry_necklace_66",
  EQSlot = "NeckSlot",
  StatsAllowed = "hjm",
 },
 {
  Name = "A Common Trinket",
  Type = "Miscellaneous",
  Texture = "Interface\\Icons\\inv_misc_gem_variety_02",
  EQSlot = "Trinket0Slot",
  StatsAllowed = "hjm",
 },
}
------------------------------------------------------------
-------------------- level 10 to 14 tiers --------------------
------------------------------------------------------------
addonTable.Items["_10_11_12_13_14_"] =
{
 -- Weapons
 -- Strength
 {
  Model = 84595,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 88092,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 100992,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 100995,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 100997,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 100994,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
-- Agility
 {
  Model = 101207,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 101209,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 101204,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 101206,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 101208,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 101205,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- Intellect
 {
  Model = 101075,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 101078,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 101077,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 101074,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 101076,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 101073,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- Accessories
 {
  Name = "Dragon's Blood Necklace",
  Type = "Miscellaneous",
  Texture = "Interface\\Icons\\inv_jewelry_necklace_02",
  EQSlot = "NeckSlot",
  StatsAllowed = "hjm",
 },
 {
  Name = "Price of Progress",
  Type = "Miscellaneous",
  Texture = "Interface\\Icons\\inv_jewelry_trinket_18",
  EQSlot = "Trinket0Slot",
  StatsAllowed = "hjm",
 },
}

addonTable.Items["_15_16_17_18_19_"] =
{
 -- Strength
 -- chest
 {
  Model = 31630,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 97782,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 45225,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 60354,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 -- legs
 {
  Model = 29774,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 97780,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 28854,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 27870,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 -- gloves
 {
  Model = 25009,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 28832,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 31583,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 37363,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 -- head
 {
  Model = 97654,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 28225,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 37633,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 40827,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 -- shoulders
 {
  Model = 16476,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 97787,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 27771,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 117025,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 -- boots
 {
  Model = 13259,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 8141,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 16725,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
 {
  Model = 77922,
  SubType = "Plate",
  StatsAllowed = "skml",
 },
-- Agility
-- boots
 {
  Model = 1121,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 14589,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 7754,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 9398,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- chest
 {
  Model = 28051,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 77821,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 23226,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 24711,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- legs
 {
  Model = 9652,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 15060,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 78258,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 77668,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- gloves
 {
  Model = 24760,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 13184,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 15438,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 16499,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- shulders
 {
  Model = 7445,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 9389,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 14596,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 15441,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- head
 {
  Model = 77635,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 10741,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 28348,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
 {
  Model = 31658,
  SubType = "Leather",
  StatsAllowed = "akm",
 },
-- Intellect
-- chests
 {
  Model = 27824,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 14315,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- boots
 {
  Model = 6562,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 29808,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 25792,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 96707,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 95963,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
-- pants
{
  Model = 22700,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 99416,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 8113,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 14317,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 14308,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 22652,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- gloves
{
  Model = 8110,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 9491,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 13253,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 11634,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 42103,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- heads
{
  Model = 17602,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 28413,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 51178,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 45464,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 78701,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- shoulders
{
  Model = 14538,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 23256,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 16695,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 22405,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 35343,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 34210,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 {
  Model = 65573,
  SubType = "Cloth",
  StatsAllowed = "iml",
 },
 -- trinket
 {
  Model = 105396,
  Type = "Miscellaneous",
  StatsAllowed = "hjm",
 },
{
  Model = 105383,
  Type = "Miscellaneous",
  StatsAllowed = "saijm",
 },
 {
  Model = 105366,
  Type = "Miscellaneous",
  StatsAllowed = "hjm",
 },
{
  Model = 105360,
  Type = "Miscellaneous",
  StatsAllowed = "saijm",
 },
 {
  Model = 105319,
  Type = "Miscellaneous",
  StatsAllowed = "hjm",
 },
 -- Necks
  {
  Model = 102749,
  Type = "Miscellaneous",
  StatsAllowed = "hjm",
 },
{
  Model = 96909,
  Type = "Miscellaneous",
  StatsAllowed = "saijm",
 },
 {
  Model = 96762,
  Type = "Miscellaneous",
  StatsAllowed = "hjm",
 },
{
  Model = 96429,
  Type = "Miscellaneous",
  StatsAllowed = "saijm",
 },
 {
  Model = 95177,
  Type = "Miscellaneous",
  StatsAllowed = "hjm",
 },
 -- weapons
  {
  Type = "Weapon",
  SubType = "1h",
  Model = 4977,
  StatsAllowed = "sm",
 },
{
  Type = "Weapon",
  SubType = "1h",
  Model = 10823,
  StatsAllowed = "sm",
 },
 {
   Type = "Weapon",
  SubType = "1h",
  Model = 16345,
  StatsAllowed = "am",
 },
{
  Type = "Weapon",
  SubType = "1h",
  Model = 19964,
  StatsAllowed = "am",
 },
 {
   Type = "Weapon",
  SubType = "1h",
  Model = 19890,
  StatsAllowed = "sm",
 },
  {
    Type = "Weapon",
  SubType = "1h",
  Model = 21466,
  StatsAllowed = "imk",
 },
{
  Type = "Weapon",
  SubType = "1h",
  Model = 22988,
  StatsAllowed = "imk",
 },
 {
   Type = "Weapon",
  SubType = "1h",
  Model = 27426,
  StatsAllowed = "hjm",
 },
}

-- Legendaries
 addonTable.Items_Legendary["_1_2_3_4_"] = 
 {
            { -- tmp
			  Name = "Trollsmasher",
			  Texture = "Interface\\Icons\\INV_Legendary_Sword",
			  Model = 105691,
			  Type = "Weapon",
			  SubType = "1h",
			  Quality = 5,
			  EQSlot = "MainHandSlot",
			  Damage = {5,15},
			  StatsAllowed = "hjm",
			 },
}

local function convertEQSlot(s)
 if s == "INVTYPE_2HWEAPON" or s == "INVTYPE_WEAPON" or s == "INVTYPE_THROWN" or s == "INVTYPE_RANGED" or 
    s == "INVTYPE_WEAPONMAINHAND" or s == "INVTYPE_WEAPONOFFHAND" then return "MainHandSlot"
 elseif s == "INVTYPE_BODY" or s == "INVTYPE_CHEST" or s == "INVTYPE_ROBE" then return "ChestSlot"
 elseif s == "INVTYPE_SHOULDER" then return "ShoulderSlot"
 elseif s == "INVTYPE_HEAD" then return "HeadSlot"
 elseif s == "INVTYPE_HAND" then return "HandsSlot"
 elseif s == "INVTYPE_NECK" then return "NeckSlot"
 elseif s == "INVTYPE_FEET" then return "FeetSlot"
 elseif s == "INVTYPE_FINGER" then return "RingSlot"
 elseif s == "INVTYPE_TRINKET" then return "Trinket0Slot"
 elseif s == "INVTYPE_LEGS" then return "LegsSlot"
 end
end

local function generateItems()

local todo = {}
local function insertitem(k, v)
 table.insert(todo, v)
end
table.foreach(addonTable.Items["_1_2_3_4_"], insertitem)
table.foreach(addonTable.Items["_5_6_7_8_9_"], insertitem)
table.foreach(addonTable.Items["_10_11_12_13_14_"], insertitem)
table.foreach(addonTable.Items["_15_16_17_18_19_"], insertitem)
table.foreach(addonTable.Items_Legendary["_1_2_3_4_"], insertitem)

 for i = 1,table.getn(todo) do
  if todo[i].Model then
   local itemName, itemLink, _, _, _, itemType, itemSubType, _, itemEquipLoc, itemTexture = GetItemInfo(todo[i].Model)
   if (itemLink) then
    local itemID = todo[i].Model
    local item = todo[i]
	if not item.Name then item.Name = itemName end
	if not item.Texture then item.Texture = itemTexture end
	if not item.Type then item.Type = itemType end
	if not item.EQSlot then item.EQSlot = convertEQSlot(itemEquipLoc) end
   end
  end
 end
end

generateItems()

local f = CreateFrame("Frame")
f:RegisterEvent("GET_ITEM_INFO_RECEIVED")
f:SetScript("OnEvent", generateItems)