-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

-- tilesets
-- mobs1 = normal mobs
-- mobs2 = elite mobs
-- mobs3 = bosses available (one is chosen)
addonTable.tilesets = {
 ["pirates"]   =  { tt    = {["Grass"] = { tex = "dungeons\\psdtextures\\scholomance\\mm_duskwood_wood_floor_01_new",},
                            ["Wall"] =  { tex = "Dungeons\\Textures\\Brick\\BM_BARROWS_BRICK01"}},
                   doors = {"door"},
                   mobs1 = {"pirate_swashbuckler","thug","mastiff","thief"},
                   mobs2 = {"pirate_captain"} },

 ["firelands"] = { tt    = {["Grass"] = { tex = "tileset\\expansion03\\firelands\\fl_volcanicrock05",},
                            ["Wall"] =  { tex = "tileset\\expansion03\\firelands\\fl_redrock02"}},
				   doors = {"gate"},
				   mobs1 = {"fire_elemental"},
                   mobs2 = {"dragon"}, },
    ["garden"] = { tt    = {["Grass"] = { tex = "tileset\\alteracmtns\\alteracgrassbase.blp",},
                            ["Wall"] =  { tex = "tileset\\alteracmtns\\alteracrockroadbase.blp"}},
				   doors = {"greenfield"},
                   mobs1 = {"zandalari_champ"},
                   mobs2 = {"teddy_bear"},				   },
}