-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

addonTable.S =
{
 -- mobs
 ["None"] =
  { },
 ["Troll"] =
  {
   attack = {"Sound\\Creature\\Troll\\TrollAttackA.ogg",
             "Sound\\Creature\\Troll\\TrollAttackB.ogg",
             "Sound\\Creature\\Troll\\TrollAttackC.ogg"},
   aggro  = {"Sound\\Creature\\Troll\\TrollAggroA.ogg"},
   death  = {"Sound\\Creature\\Troll\\TrollDeathA.ogg"},
  },
 ["Pirate"] = {
   attack = {"Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateAttackC.ogg",
             "Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateAttackA.ogg",
             "Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateAttackB.ogg"},
   aggro  = {"Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateAggroA.ogg"},
   death  = {"Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateDeathA.ogg"}
--"Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateWoundA.ogg")
--"Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateWoundB.ogg")
--"Sound\\character\\Human\\MaleNPC\\HumanMalePirate\\HumanMalePirateWoundC.ogg")
  },
 ["Mastiff"] = {
   attack = {"Sound\\creature\\Mastiff\\Mastiff_Attack_01.ogg",
             "Sound\\creature\\Mastiff\\Mastiff_Attack_02.ogg",
             "Sound\\creature\\Mastiff\\Mastiff_Attack_03.ogg",
			 "Sound\\creature\\Mastiff\\Mastiff_Attack_04.ogg",
			 "Sound\\creature\\Mastiff\\Mastiff_Attack_05.ogg",
             "Sound\\creature\\Mastiff\\Mastiff_Attack_06.ogg"},
--   aggro  = {},
   death  = {"Sound\\creature\\Mastiff\\Mastiff_Death.ogg"}
--"Sound\\creature\\Mastiff\\Mastiff_Wound_01.ogg")
--"Sound\\creature\\Mastiff\\Mastiff_Wound_02.ogg")
--"Sound\\creature\\Mastiff\\Mastiff_Wound_03.ogg")
--"Sound\\creature\\Mastiff\\Mastiff_Wound_04.ogg")
--"Sound\\creature\\Mastiff\\Mastiff_Wound_05.ogg")
 },
 ["Dragon"] =
  {
   attack = {"Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_01.ogg",
             "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_02.ogg",
             "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_03.ogg",
			 "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_04.ogg",
			 "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_05.ogg",
			 "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_06.ogg",
			 "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_07.ogg",
			 "Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Attack_08.ogg",},
   aggro  = {"Sound\\Creature\\Dragon_Medium\\Dragon_Medium_Aggro_05.ogg"},
  },
 ["Elemental"] =
  {
   attack = {"Sound\\creature\\ElementalFire\\FireElementalAttackA.ogg",
             "Sound\\creature\\ElementalFire\\FireElementalAttackB.ogg",
			 "Sound\\creature\\ElementalFire\\FireElementalAttackC.ogg"},
   aggro  = {"Sound\\creature\\ElementalFire\\FireElementalAggro.ogg"},
   death  = {"Sound\\creature\\ElementalFire\\FireElementalDeathA.ogg"},
  },
 ["Bear"] =
  {
   attack = {"Sound\\Creature\\Bear\\mBearAttackA.ogg",
             "Sound\\Creature\\Bear\\mBearAttackB.ogg",
             "Sound\\Creature\\Bear\\mBearAttackD.ogg",},
   aggro  = {"Sound\\Creature\\Bear\\mBearAggroA.ogg"},
  }, 
  ["Illidan"] =
  {
   attack = {"Sound\\Creature\\Illidan\\BLACK_Illidan_Attack01.ogg",
             "Sound\\Creature\\Illidan\\BLACK_Illidan_Attack02.ogg",
             "Sound\\Creature\\Illidan\\BLACK_Illidan_Attack03.ogg",},
   aggro  = {--"Sound\\Creature\\Illidan\\BLACK_Illidan_13.ogg",
             "Sound\\Creature\\Illidan\\BLACK_Illidan_04.ogg"},
  },
  
 -- spells
 ["heroic_strike"] = {"Sound/SPELLS/ArmorKitBuffSound.ogg"},
 ["enraged_regeneration"] = {"Sound/SPELLS/Warrior_Safeguard.ogg"},
 ["whirlwind"] = {"Sound/SPELLS/WhirlwindShort.ogg"},
 ["heroic_throw"] = {"Sound/SPELLS/Warrior_Heroic_Throw_Impact1.ogg"},
 ["berserker_rage"] = {"Sound/SPELLS/Warrior_Safeguard.ogg"},
 ["judgement"] = {"Sound/SPELLS/JudgmentsoftheWiseImpact.ogg"},
 ["holy_light"] = {"Sound/SPELLS/HolyLight_Low_Head.ogg"},
 ["consecration"] = {"Sound/SPELLS/DirectDamage/HolyImpactDDLow.ogg"},
 ["avenging_wrath"] = {"Sound/SPELLS/avengingwrath_impact_base.ogg"},
 ["divine_shield"] = {"Sound/SPELLS/DivineShield.ogg"},
 ["death_strike"] = {"Sound/SPELLS/Deathknight_Deathstrike1.ogg",
                     "Sound/SPELLS/Deathknight_Deathstrike2.ogg",
                     "Sound/SPELLS/Deathknight_Deathstrike3.ogg",
                     "Sound/SPELLS/Deathknight_Deathstrike4.ogg",},
 ["death_grip"] = {"sound\\spells\\deathcoiltarget.ogg"},
 ["howling_blast"] = {"Sound/SPELLS/DeathKnight_HowlingBlastPrimary.ogg"},
 ["death_coil"] = {"sound\\spells\\deathcoiltarget.ogg"},
 ["anti_magic_shell"] = {"Sound/SPELLS/AntiMagicShellImpact.ogg"},
 ["sinister_strike"] = {"Sound/SPELLS/SinisterStrikeImpact.ogg"},
 ["recuperate"] = {"Sound/SPELLS/SPELL_RO_Recuperate_State_01.ogg"},
 ["fan_of_knives"] = {"Sound/SPELLS/BladesRingImpact.ogg"},
 ["shuriken_toss"] = {"Sound/SPELLS/Spell_RO_ShurikenToss_Cast01.OGG"},
 ["combat_readiness"] = {"Sound\\spells\\spell_pr_shadowyapparition_impact_05.ogg"},
 ["blackout_kick"] = {"Sound/SPELLS/SPELL_MK_BLACKOUTKICK_CAST_01.OGG"},
 ["surging_mist"] = {"Sound/SPELLS/SPELL_MK_RESUSCITATE.OGG"},
 ["spinning_crane_kick"] = { "Sound/SPELLS/SPELL_MK_CHITORPEDO_CAST01.OGG",
                             "Sound/SPELLS/SPELL_MK_CHITORPEDO_CAST02.OGG",
                             "Sound/SPELLS/SPELL_MK_CHITORPEDO_CAST03.OGG",
                             "Sound/SPELLS/SPELL_MK_CHITORPEDO_CAST04.OGG",
                              --"Sound/SPELLS/SPELL_MK_SPINNINGCRANEKICK_STATE.OGG",
                           },
 ["jade_lightning"] = {"Sound\\spells\\spell_mk_cracklinglightning_cast_05.ogg"},
 ["fortifying_brew"] = {"Sound\\spells\\spell_mk_brew_drink01.ogg"},
 ["binding_shot"] = {"sound\\item\\weapons\\bow\\bowrelease03.ogg"},
 ["bandage_self"] = {"Sound/Item/UseSounds/UseBandage.ogg"},
 ["volley"] = {"Sound\\spells\\spell_mk_grapple_cast02.ogg"},
 ["explosive_shot"] = {"Sound\\doodad\\g_barrelexplodecustom0.ogg"},
 ["deterrence"] = {"Sound\\spells\\disarm.ogg"},
 ["moonfire"] = {"Sound\\spells\\moonfireimpact.ogg"},
 ["rejuvenation"] = {"Sound\\spells\\rejuvenation.ogg"},
 ["hurricane"] = {"Sound\\spells\\envelopingwindloop.ogg"},
 ["starfire"] = {"Sound\\spells\\starfireimpact.ogg"}, 
 ["barkskin"] = {"Sound\\spells\\restorationimpact.ogg"},
 ["smite"] = {"Sound\\spells\\holybolt.ogg"},
 ["greater_heal"] = {"/Sound\\spells\\greaterheal_low_base.ogg"},
 ["holy_nova"] = {"Sound\\spells\\directdamage\\holyimpactddhigh.ogg"},
 ["shadow_word_pain"] = { "Sound\\SPELLS\\ShadowWordPainTarget.ogg", },
 ["power_word_shield"] = {"Sound\\spells\\divineshield.ogg"},
 ["incinerate"] = {"Sound\\spells\\incinerate_impact_base.ogg"},
 ["ember_tap"] = {"Sound\\spells\\spell_wl_embertap_cast.ogg"},
 ["rain_of_fire"] = {"Sound\\spells\\spell_flamethrower_channel_loop_02.ogg"},
 ["immolate"] = {"Sound\\spells\\immolate.ogg"},
 ["demon_skin"] = {"Sound\\spells\\demonarmor.ogg"},
 ["fireball"] = {"Sound\\spells\\spell_uni_firecast_01.ogg"},
 ["evocation"] = {"Sound\\spells\\precastmagelow.ogg"},
 ["flamestrike"] = {"Sound\\spells\\flamestrike.ogg"},
 ["pyroblast"] = {"Sound\\spells\\spell_uni_firecast_04.ogg"},
 ["mana_shield"] = {"Sound\\spells\\divineshield.ogg"},
 ["lightning_bolt"] = {"Sound\\spells\\spell_lightningbolt_impact_02.ogg"},
 ["healing_surge"] = {"Sound\\spells\\restorationimpact.ogg"},
 ["thunderstorm"] = {"Sound\\spells\\shaman_thunder.ogg"},
 ["earth_shock"] = {"Sound\\spells\\lightningboltimpact.ogg"},
 ["fulmination"] = {""},
 ["ancestral_guidance"] = {"Sound\\spells\\fx_waterbolt_cast_04.ogg"},
 
--Porte di legno Sound\\item\\weapons\\bow\\bowpullback.ogg
--Sound\\item\\weapons\\bow\\bowpullback02.ogg")
}


local function generaterace(r, s)
 local result = {}
 local dir
 local file
 
 dir = "Sound\\Character\\PlayerExertions\\"..r..s.."Final\\"
 file = r..s
 
 if r == "Pandaren" then
  dir = "Sound\\Character\\PC"..r..s.."\\"
  file = "VO_PC"..r..s.."_"
 elseif r == "Goblin" or r == "Worgen" then
  dir = "Sound\\creature\\"..r..s.."\\"
  file = r..s.."_"
 elseif r == "BloodElf" or r == "Draenei" then
  dir = "Sound\\Character\\"..r..s.."PC\\"
  file = r..s.."PC"
 elseif r == "Scourge" then -- is this real?
  dir = "Sound\\Character\\PlayerExertions\\Undead"..s.."Final\\"
  if s == "Female" then
   file = "Undead"..s.."Final"
  else
   file = "Undead"..s
  end
 elseif r == "Tauren" and s == "Female" then
  file = r..s.."Final"
 end
 if file == "HumanFemale" then file = "HumanFeamle" end -- this is..
 if file == "TrollFemale" then file = "TrollFemal" end -- ..sadly true
 --

 if r == "Pandaren" or r == "Goblin" then
  result.attack = {dir..file.."Attack01.ogg",
                   dir..file.."Attack02.ogg",
                   dir..file.."Attack03.ogg",
                   dir..file.."Attack04.ogg",}
  result.death  = {dir..file.."DeathA.ogg",}
 elseif r == "Worgen" then
  result.attack = {dir..file.."Attack_01.ogg",
                   dir..file.."Attack_02.ogg",
                   dir..file.."Attack_03.ogg",
                   dir..file.."Attack_04.ogg",}
  result.death  = {dir..file.."DeathA.ogg",}
 elseif r == "BloodElf" or (r == "Scourge" and s == "Female") or r == "Draenei" or (r == "Tauren" and s == "Female") then
  result.attack = {dir..file.."AttackA.ogg",
                   dir..file.."AttackB.ogg",
				   dir..file.."AttackC.ogg",
				   dir..file.."AttackD.ogg",}
  result.death  = {dir..file.."DeathA.ogg",}
 else
  result.attack = {dir..file.."MainAttackA.ogg",
                   dir..file.."MainAttackB.ogg",
				   dir..file.."MainAttackC.ogg",
				   dir..file.."MainAttackD.ogg",}
  result.death  = {dir..file.."DeathA.ogg",}
 end

 addonTable.S[r..s] = result
end

-- player races
generaterace("Human", "Male")
generaterace("Human", "Female")
generaterace("NightElf", "Male")
generaterace("NightElf", "Female")
generaterace("Gnome", "Male")
generaterace("Gnome", "Female")
generaterace("Dwarf", "Male")
generaterace("Dwarf", "Female")
generaterace("Draenei", "Male")
generaterace("Draenei", "Female")
generaterace("Worgen", "Male")
generaterace("Worgen", "Female")

generaterace("Orc", "Male")
generaterace("Orc", "Female")
generaterace("Tauren", "Male")
generaterace("Tauren", "Female")
generaterace("BloodElf", "Male")
generaterace("BloodElf", "Female")
generaterace("Goblin", "Male")
generaterace("Goblin", "Female")
generaterace("Scourge", "Male")
generaterace("Scourge", "Female")
generaterace("Troll", "Male")
generaterace("Troll", "Female")

generaterace("Pandaren", "Male")
generaterace("Pandaren", "Female")