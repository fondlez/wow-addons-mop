-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local L = addonTable.L
local game = DeepDownBelow

--- menu related
local MENU_MAIN           = 0
local TILESET_SELECTION   = 1
local RESETPLAYER_CONFIRM = 2
local HELP_SCREEN         = 3
local menu_index = 0

-- Methods
local function newgame(tileset)
 local p = game.GameData.Player
 game:SetScreen("game")
 local map = game:GenerateMap(0, 80, 80, "DDBMap", tileset)
 game:LoadPlayer()
 local playerplaced
 while not playerplaced do
  local x,y = math.random(0, map.Width), math.random(0, map.Height)
  if not game:IsObstacle(map.tiles[x.."-"..y]) then
   p:Spawn(x,y)
   game.startX = x
   game.startY = y
   playerplaced = true
  end
 end
 map:Populate()
 game:SetMobsLevel(game.GameData.Player.Level)
 game.GameData.Turn = 0
 game:PrepareEndTurn()
 p:IncStatistic("game_gamescreated", 1)
end

local function exitgameclick()
 game.mainframe:Hide()
end

local function resetplayer()
 game.GameData.Player:Reset()
 game:SavePlayer()
 game:RefreshPlayerModels()
 game:SetScreen("menu")
end

local function Menu_SetupButtons(i)
 local f = game.MenuFrame
 if not f then return end
 
 local p = game.GameData.Player
  
  local function setbtntooltip(b, ...)
   local args = {...}
   b:SetScript("OnEnter", function()
    GameTooltip:ClearLines()
	GameTooltip:SetOwner(b, "TOP", 0, 5)
	for k,v in pairs(args) do
	 GameTooltip:AddLine(v)
	end
	GameTooltip:Show()
   end)
   b:SetScript("OnLeave", function()
    GameTooltip:Hide()
   end)
  end
  
  local function resetbutton(b)
   b:SetScript("OnClick", nil)
   b:SetScript("OnEnter", nil)
   b:SetScript("OnLeave", nil)
   b:SetNormalTexture("Interface\\BUTTONS\\BLUEGRAD64")
   b:ClearAllPoints()
   b:Hide()
  end

 for i = 0,4 do
  resetbutton(f.buttons[i])
 end

 -- dress model
 f.dressmodel:SetPoint("CENTER", f, "CENTER")
 f.dressmodel:SetUnit("player")
 f.dressmodel:Show()
 -- header
 f.header:SetPoint("BOTTOM", f.dressmodel, "TOP", 0, 10)
 f.header:SetText(L["about"])
 f.header:Show()
 -- title
 f.title:SetPoint("BOTTOM", f.header, "TOP", 0, 10)
 f.title:SetText(L["DDB_Title"])
 f.title:Show()
 -- about me
 f.about:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
 f.about:SetText(L["about"])
 f.about:Show()
 -- refresh player stats
 
  local function refreshlabel(s)
   f.playerstats[s].text:SetText(L[s]..": |cff00FF00"..(p.Stats[s] and p.Stats[s] or 0).."|r")
  end

 f.playerlevel:SetText(L["level"]..": |cff00FFaa"..p.Level.."|r")
 refreshlabel("Str")
 refreshlabel("Agi")
 refreshlabel("Int")
 refreshlabel("Sta")
 refreshlabel("BonusMelee")
 refreshlabel("BonusSpell") 
 
 -- Main Menu
 if i == MENU_MAIN then
  -- header text
  f.header:SetText(L["mainmenu"])
  -- new game
  f.buttons[0]:SetPoint("TOPRIGHT", f.dressmodel, "TOPLEFT", -10, -10)
  f.buttons[0]:SetText(L["btnnew"])
  f.buttons[0]:SetScript("OnClick", function() game:SetScreen("tileset_sel") end)
  f.buttons[0]:Show()
  -- reset player
  f.buttons[1]:SetPoint("TOP", f.buttons[0], "BOTTOM", 0, -5)
  f.buttons[1]:SetText(L["btnreset"])
  f.buttons[1]:SetScript("OnClick", function() game:SetScreen("resetplayer_confirm") end)
  f.buttons[1]:Show()
  -- help screen
  f.buttons[2]:SetPoint("TOP", f.buttons[1], "BOTTOM", 0, -5)
  f.buttons[2]:SetText(L["btnhelp"])
  f.buttons[2]:SetScript("OnClick", function() game:SetScreen("help_screen") end)
  f.buttons[2]:Show()
  -- exit game
  f.buttons[3]:SetPoint("TOP", f.buttons[2], "BOTTOM", 0, -35)
  f.buttons[3]:SetText(L["btnexit"])
  f.buttons[3]:SetScript("OnClick", exitgameclick)
  f.buttons[3]:Show()
 elseif i == TILESET_SELECTION then
  f.header:SetText(L["select_tileset"])
   -- tileset1
  f.buttons[0]:SetPoint("TOPRIGHT", f.dressmodel, "TOPLEFT", -10, -10)
  f.buttons[0]:SetText(L["tileset_pirates"])
  f.buttons[0]:SetScript("OnClick", function() newgame("pirates") end)
  f.buttons[0]:Show()
  -- tileset2
  f.buttons[1]:SetPoint("TOP", f.buttons[0], "BOTTOM", 0, -5)
  f.buttons[1]:SetText(L["tileset_firelands"])
  f.buttons[1]:SetScript("OnClick", function() newgame("firelands") end)
  f.buttons[1]:Show()
  -- tileset3
  f.buttons[2]:SetPoint("TOP", f.buttons[1], "BOTTOM", 0, -5)
  f.buttons[2]:SetText(L["tileset_garden"])
  f.buttons[2]:SetScript("OnClick", function() newgame("garden") end)
  f.buttons[2]:Show()
  -- back
  f.buttons[3]:SetPoint("TOP", f.buttons[2], "BOTTOM", 0, -35)
  f.buttons[3]:SetText(L["btnback"])
  f.buttons[3]:SetScript("OnClick", function() game:SetScreen("menu") end)
  f.buttons[3]:Show()
 elseif i == HELP_SCREEN then
  f.header:SetText(L["help_screen"])
   -- movement
  f.buttons[0]:SetPoint("TOPRIGHT", f.dressmodel, "TOPLEFT", -10, -10)
  f.buttons[0]:SetText(L["btnmovement"])
  f.buttons[0]:SetNormalTexture("Interface\\CharacterFrame\\BarFill")
  setbtntooltip(f.buttons[0], L["btnmovement"], unpack(addonTable.Help["movement"]))
  f.buttons[0]:Show()
  -- combat
  f.buttons[1]:SetPoint("TOP", f.buttons[0], "BOTTOM", 0, -5)
  f.buttons[1]:SetNormalTexture("Interface\\CharacterFrame\\BarFill")
  f.buttons[1]:SetText(L["btncombat"])
  setbtntooltip(f.buttons[1], L["btncombat"], unpack(addonTable.Help["combat"]))
  f.buttons[1]:Show()
  -- items
  f.buttons[2]:SetPoint("TOP", f.buttons[1], "BOTTOM", 0, -5)
  f.buttons[2]:SetNormalTexture("Interface\\CharacterFrame\\BarFill")
  f.buttons[2]:SetText(L["btnitems"])
  setbtntooltip(f.buttons[2], L["btnitems"], unpack(addonTable.Help["items"]))
  f.buttons[2]:Show()
  -- back
  f.buttons[3]:SetPoint("TOP", f.buttons[2], "BOTTOM", 0, -35)
  f.buttons[3]:SetText(L["btnback"])
  f.buttons[3]:SetScript("OnClick", function() game:SetScreen("menu") end)
  f.buttons[3]:Show()
 elseif i == RESETPLAYER_CONFIRM then
  f.header:SetText(L["reset_confirm"])
  -- no
  f.buttons[1]:SetPoint("BOTTOMRIGHT", f.dressmodel, "BOTTOMLEFT", -10, 0)
  f.buttons[1]:SetText(L["no"])
  f.buttons[1]:SetNormalTexture("Interface\\BUTTONS\\REDGRAD64")
  f.buttons[1]:SetScript("OnClick", function() game:SetScreen("menu") end)
  f.buttons[1]:Show()
   -- yes
  f.buttons[0]:SetPoint("BOTTOM", f.buttons[1], "TOP", 0, 5)
  f.buttons[0]:SetText(L["yes"])
  f.buttons[0]:SetNormalTexture("Interface\\BUTTONS\\GREENGRAD64")
  f.buttons[0]:SetScript("OnClick", function() resetplayer() end)
  f.buttons[0]:Show()
 end
end

---
local readytoend
local Screens = {
-- Menus
 ["menu"] = 
             {
              Clear =      function()
                            game.MenuFrame:Hide()
                           end,
              Initialize = function()
                            if not game.MenuFrame then
			                game:GenerateMenuframe()
			               end
						    game:LoadPlayer(true)
							menu_index = MENU_MAIN
						    Menu_SetupButtons(menu_index)
			                game.MenuFrame:Show()
                           end,
              Update =     function()

                           end
              },
 ["tileset_sel"] = {
              Clear =      function()
                            game.MenuFrame:Hide()
                           end,
              Initialize = function()
                            if not game.MenuFrame then
			                game:GenerateMenuframe()
			               end
							menu_index = TILESET_SELECTION
						    Menu_SetupButtons(menu_index)
			                game.MenuFrame:Show()
                           end,
              Update =     function()

                           end
              },
["resetplayer_confirm"] = {
              Clear =      function()
                            game.MenuFrame:Hide()
                           end,
              Initialize = function()
                            if not game.MenuFrame then
			                game:GenerateMenuframe()
			               end
							menu_index = RESETPLAYER_CONFIRM
						    Menu_SetupButtons(menu_index)
			                game.MenuFrame:Show()
                           end,
              Update =     function()

                           end
              },

["help_screen"] = {
              Clear =      function()
                            game.MenuFrame:Hide()
                           end,
              Initialize = function()
                            if not game.MenuFrame then
			                game:GenerateMenuframe()
			               end
							menu_index = HELP_SCREEN
						    Menu_SetupButtons(menu_index)
			                game.MenuFrame:Show()
                           end,
              Update =     function()

                           end
              },
-- Game
 ["game"] =
              {
               Clear =      function()
			                 game:ResetGame()
                             game.GameFrame:Hide()
							 game.CharacterFrame:Hide()
							 game.InventoryFrame:Hide()
                            end,
               Initialize = function()
                             if not game.GameFrame then
			                  game:GenerateGameframe()
							 else
                              game.GameFrame:Show()
			                 end
                            end,
               Update =     function()
			                 game.Camera:Update()
							 game.GameData.Player:Update()
							 table.foreach(game.GameData.Map.units, function(_,u)
							  u:Update()
							 end)
                             table.foreach(game.GameData.Map.objects, function(_,u)
							  u:Update()
							 end)
							 if game.EndTurnReady and game.TurnStartDelay <= GetTime() then
							  game.EndTurnReady = false
							  game:EndTurn()
							 end
                            end
              }
}

-- Methods
function game:SetScreen(screen)
 if game.CurrentScreen then
  game.CurrentScreen:Clear()
 end

 local s = type(screen) == "string" and Screens[screen] or screen

 if s then
  game.CurrentScreen = s
 else
  game:Error(L["err0"])
  return
 end

 game.CurrentScreen:Initialize()
 collectgarbage()
end
--