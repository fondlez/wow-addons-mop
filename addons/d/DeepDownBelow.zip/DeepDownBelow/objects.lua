-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local L = addonTable.L -- localization
local S = addonTable.S -- sounds
local game = DeepDownBelow
local Objects = addonTable.Objects

local function getobject(id)
 if Objects[id] then
  local o = {}
  table.foreach(Objects["TEMPLATE"], function(k,v)
   o[k] = Objects[id][k] and Objects[id][k] or v
  end)
  game:SetObjectVars(o)
  game:SetObjectMethods(o)
  return o
 else
  game:Error(L["err3"].." ("..id..")")
  return
 end
end

function game:CreateTemplateObject()
 local o = getobject("TEMPLATE")
 o.ID = "TEMPLATE"
 game:SetObjectMethods(o)
 game:SetObjectVars(o)
 game:CreateObjectFrame(o)
 return o
end

function game:PlaceNewObject(id, x, y, map)
 local o = getobject(id)

 if not o then return end
 local m = map and map or game.GameData.Map

 if m:GetTile(x, y).object then return end
 o.Map = m.id

 table.insert(m.objects, o)
 game:CreateObjectFrame(o)

 o:SetPos(x, y, true)
 return o
end

-- methods
local function objStartAnimation(o, anim)
 o.frame:SetAnimation(anim)
end

local function getRotation(dir)
 if dir == "LEFT" then
  return 270
 elseif dir == "DOWN" then
  return 0
 elseif dir == "RIGHT" then
  return 90
 elseif dir == "UP" then
  return 180
 end
end

local function objSetState(o)
 if o.Status == "closing" then
  o.Status = "closed"
 elseif o.Status == "opening" then
  o.Status = "open"
 end

 if o.Status == "open" then
  --o.frame:SetAnimation(o.InverseAnim and 147 or 149)
  o:Dispose()
 elseif o.Status == "closed" then
  o.frame:SetAnimation(o.InverseAnim and 149 or 147)
 end
end

local function objInteract(o, u, dir)
 if o.Type == "door" then
  if o.Status == "closed" then
   o.frame:SetAnimation(o.InverseAnim and 146 or 148)
   o.Status = "opening"
   o.frame:SetScript("OnAnimFinished", function() o:SetState() end)
   game:HandleTileAnchors(true) -- one less obstacle in our los
  elseif o.Status == "open" then
   o.frame:SetAnimation(o.InverseAnim and 148 or 146)
   o.Status = "closing"
   o.frame:SetScript("OnAnimFinished", function() o:SetState() end)
  end
 end
end

local function objCanSee(o, t)
 return game:HasLos(o.x, o.y, t.x, t.y)
end

-- setpos
local function objSetPos(o, x, y)
 game.GameData.Map:GetTile(o.x, o.y).object = nil
 o.x = x
 o.y = y
 if o.Light then
  o.Light.x = x
  o.Light.y = y
 end
 game.GameData.Map:GetTile(x, y).object = o
 local X, Y = game:GetRealPos(x, y)
 o.visX = X
 o.visY = Y
 o:SetVisualPos()
end

-- sets the unit's frame position
local function objSetVisualPos(o)
 local x = o.visX-- - math.max(0,(addonTable.UnitWidth - addonTable.TileWidth)/2) 
 local y = o.visY-- - math.max(0,(addonTable.UnitHeight - addonTable.TileHeight)/2)
 o.frame:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", x, -y)
end
--

-- frame movement
local function objCheckFrameAnimation(u)
 local tX, tY = game:GetRealPos(u.x, u.y)
  
 if u.visX == tX and u.visY == tY then
  if u.isAnimating then
   u.isAnimating = false
   --u:StartAnimation(0, true)
   o.frame:SetAnimation(o.InverseAnim and 146 or 148)
  end
  return

 end

 if u.visX < tX then
  u.visX = u.visX + addonTable.units_speed
 elseif u.visX > tX then
  u.visX = u.visX - addonTable.units_speed
 end
 if u.visY < tY then
  u.visY = u.visY + addonTable.units_speed
 elseif u.visY > tY then
  u.visY = u.visY - addonTable.units_speed
 end
 if math.abs(u.visX - tX) <= addonTable.units_speed then
  u.visX = tX
 end
 if math.abs(u.visY - tY) <= addonTable.units_speed then
  u.visY = tY
 end
 u:SetVisualPos()
end

local function CheckUnitRotation(o)

 if o.destRotation == o.Rotation then return end

 local speed = 10
 
 if o.Rotation == 0 and o.destRotation == 270 then 
  o.Rotation = 360
 elseif o.Rotation == 270 and o.destRotation == 0 then 
  o.destRotation = 360
 end
 
 if o.Rotation == o.destRotation then return end
 if o.Rotation < o.destRotation then
  o.Rotation = o.Rotation + speed
 else
  o.Rotation = o.Rotation - speed
 end

 dist = math.abs(o.Rotation - o.destRotation)

 if dist <= speed then
  o.Rotation = o.destRotation
  if o.Rotation == 360 then 
   o.Rotation = 0 
   if o.destRotation == 360 then
    o.destRotation = 0
   end
  end
 end

 o.frame:SetRotation(math.rad(o.Rotation))
end

local function objUpdate(o)
 o:CheckFrameAnimation()
 CheckUnitRotation(o)
end

local function objDispose(o, i)
 local found = i
 if not found then
  table.foreach(game.GameData.Map.objects, function(k,v)
   if v == o then found = k end
  end)
 end
 if found then table.remove(game.GameData.Map.objects, found) end
 game.GameData.Map:GetTile(o.x, o.y).object = nil
 o.frame:ClearModel()
 game:DisposeFrame(o.frame)
 o.frame = nil
end

local function objFillTooltip(o)
 local w,r,g = "|cffFFFFFF","|cffFF0000","|cff00FF00"
 GameTooltip:ClearLines()
 GameTooltip:AddLine(w.."Object: "..g..o.Name.."|r")
 GameTooltip:AddLine(w.."Status: "..r..o.Status.."|r")
end

function game:SetObjectVars(o)
 o.x = 0
 o.y = 0
 o.visX = 0
 o.visY = 0
end

function game:SetObjectMethods(o)
 o.Dispose = objDispose
 o.Interact = objInteract
 o.SetState = objSetState
 o.SetPos = objSetPos
 o.SetVisualPos = objSetVisualPos
 o.CheckFrameAnimation = objCheckFrameAnimation
 o.Update = objUpdate
 o.StartAnimation = objStartAnimation
 o.CanSee = objCanSee
 o.FillTooltip = objFillTooltip
 o.AddLight = addonTable.unitAddLight -- lighting.lua
 o.RemoveLight = addonTable.unitRemoveLight -- lighting.lua
end