-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local L = addonTable.L -- localization
local S = addonTable.S -- sounds
local Sp = addonTable.Spells
local game = DeepDownBelow
local Monsters = addonTable.Monsters

local UnitsCore = addonTable.UnitsCore

local function getmonster(id, core)
 if Monsters[id] then
  local m = {}
  table.foreach(Monsters["TEMPLATE"], function(k,v)
   m[k] = Monsters[id][k] and Monsters[id][k] or v
  end)
  m.ID = id
  m.db = addonTable.UnitsCore[core]
  game:SetUnitMethods(m)
  game:SetUnitVars(m)
  return m
 else
  game:Error(L["err1"].." ("..id..")")
  return
 end
end

function game:CreateTemplateUnit()
 local m = getmonster("TEMPLATE", "base")
 m.ID = "TEMPLATE"
 game:SetUnitMethods(m)
 game:SetUnitVars(m)
 game:CreateUnitFrame(m)
 return m
end

function game:PlaceNewUnit(id, x, y, lvl, core)
 local u = getmonster(id, core)

 if not u then return end
 
 
 u:LevelUp(lvl, true)
 table.insert(game.GameData.Map.units, u)
 game:CreateUnitFrame(u)

 u:SetPos(x, y, true)
 return u
end

-- methods
local function unitStartAnimation(u, anim)
 u.frame:SetAnimation(anim)
end

local function opposedDir(dir)
 if dir == "LEFT" then
  return "RIGHT"
 elseif dir == "DOWN" then
  return "UP"
 elseif dir == "RIGHT" then
  return "LEFT"
 elseif dir == "UP" then
  return "DOWN"
 end
end

local function getRotation(dir)
 if dir == "LEFT" then
  return 270
 elseif dir == "DOWN" then
  return 0
 elseif dir == "RIGHT" then
  return 90
 elseif dir == "UP" then
  return 180
 end
end
-- move
local function unitMove(u, dir)
 local destTile, destX, destY = game:GetAdjacentTile(u.x, u.y, dir)
 
 if not u:CanMove(destTile) then return end
 
 if destTile then
  if not u.isAnimating then
   u.isAnimating = true
   u:StartAnimation(4)
  end
  u:SetPos(destX, destY, false)
  if u == game.GameData.Player then
   game.Camera:CenterToPlayer()
  end
  return true
 end
end

-- attack
function unitGetSwing(u)
 if not u.db then return 1 end

 if u ~= game.GameData.Player then
  return game:Dice(u.db.swing) * u.Level
 end

 if u.Equipped and u.Equipped["MainHandSlot"] then
  return game:Dice(u.Equipped["MainHandSlot"].Damage)
 else
  return 1
 end
end

local function calculatemeleedamage(u, tar)
 --local bonus = u == game.GameData.Player and u.Stats["BonusMelee"] or 0
 local bonus = 0
 local mod = 0
 if u.Class == "WARRIOR" or u.Class == "DEATHKNIGHT" or u.Class == "PALADIN" then
  mod = u.Stats["Str"] / 5
 elseif u.Class == "ROGUE" or u.Class == "HUNTER" or u.Class == "MONK" or u.Class == "DRUID" then
  mod = u.Stats["Agi"] / 5
 elseif u.Class == "PRIEST" or u.Class == "MAGE" or u.Class == "WARLOCK" or u.Class == "SHAMAN" then
  mod = u.Stats["Int"] / 5
 end
 bonus = bonus + mod
 -- check for damage buffs
 table.foreach(u.Auras, function(k,aura)
  if aura.OnMelee then
   if aura.effect then
    local x,y = game:GetRealPos(tar.x, tar.y, tar)
    game:CreateEffect(x, y, k.."_hit")
   end
   if aura.charges ~= -1 then
    aura.charges = aura.charges - 1
    if aura.charges <= 0 then
     game:RemoveAura(u, k)
    end
   end
  end
 end)
 return math.floor(u:GetSwing() + bonus)
end

local function unitAttack(u, dir)
 local destTile, destX, destY = game:GetAdjacentTile(u.x, u.y, dir)

 if not destTile then return end
 
 local tar = destTile.unit

 if destTile and tar and tar.Status ~= "dead" and tar.Side ~= u.Side then
  local dam = calculatemeleedamage(u, tar)
  u:StartAnimation(26) -- attack stance
  u.Target = tar
  u:StartAnimation(57) -- attack
  game:PlayRandomSound(u.sounds.attack, 50)
  game:Do_Damage(u, tar, dam, "hit")
  -- generate rage if warrior
  if dam > 0 and u == game.GameData.Player then
   u:GenerateMana("attack")
  end
  return true
 end
end

-- interact with map objects
local function unitInteract(u, dir)
 local destTile, destX, destY = game:GetAdjacentTile(u.x, u.y, dir)
 
 -- check for friendly units?
  
 local o = destTile.object

 if destTile and o then
  o:Interact(u, dir)
  return true
 end
end

-- act towards <dir>
local function unitAct(u, dir)
 if not dir then return end
 if dir == "W" then
  dir = "UP"
 elseif dir == "A" then
  dir = "LEFT"
 elseif dir == "S" then
  dir = "DOWN"
 elseif dir == "D" then
  dir = "RIGHT"
 end
 
 local result = false
 if u:CanAct() then
  u.Target = nil
  table.foreach(u.Auras, function(k,aura)
   if aura.OnMove then
    aura.OnMove(u, dir)
    result = true
   end
  end)
  if result then -- do nothing
  elseif u:Move(dir) then     result = true  -- check if we can move ..
  elseif u:Attack(dir) then   result = true  -- .. if not, maybe there is something to attack ..
  elseif u:Interact(dir) then result = true end -- .. well.. try to interact with an object then

  if result == true then
   u.destRotation = getRotation(dir)
   if u == game.GameData.Player then
    game:PrepareEndTurn()
   end
  end
 end
 return result
end

local function unitCanSee(u, t)
 return game:HasLos(u.x, u.y, t.x, t.y)
end

local function unitCanAct(u)
 if game.TurnStartDelay > GetTime() then
  return
 else
  return not u.isAnimating and u.Status ~= "dead" and u.Status ~= "stunned"
 end
end

local function unitCanMove(u, destTile)
 if destTile and not game:IsObstacle(destTile) then
  return true
 end
end

-- setpos
local function unitSetPos(u, x, y, istant)
 game.GameData.Map:GetTile(u.x, u.y).unit = nil
 u.x = x
 u.y = y
 if u.Light then
  u.Light.x = u.x
  u.Light.y = u.y
 end
 game.GameData.Map:GetTile(x, y).unit = u
 if istant then
  if u == game.GameData.Player then
   game.Camera:CenterToPlayer(true)
  end
  local X, Y = game:GetRealPos(u.x, u.y)
  u.visX = X
  u.visY = Y
  u:SetVisualPos()
 end
end

-- sets the unit's frame position
local function unitSetVisualPos(u)
 local x = u.visX - math.max(0,(u.frame:GetWidth() - addonTable.TileWidth)/2) 
 local y = u.visY - math.max(0,(u.frame:GetHeight() - addonTable.TileHeight)/2)
 u.frame:SetPoint("TOPLEFT", game.MapFrame.tilescontainer, "TOPLEFT", x, -y)
end
--

function game:GetRealPos(x, y, centeredunit)
 local tX = x * addonTable.TileWidth + game.Camera.gapX + addonTable.mapoffsetX
 local tY = y * addonTable.TileHeight - game.Camera.gapY - addonTable.mapoffsetY
 --[[ if centeredunit then
  tX = tX + centeredunit.frame:GetWidth() / 2
  tY = tY + centeredunit.frame:GetHeight() / 2
 end]]--
 if centeredunit then
  tX = tX + addonTable.TileWidth / 2
  tY = tY + addonTable.TileHeight / 2
 end
 return tX, tY
end

-- frame movement
local function unitCheckFrameAnimation(u)
 local tX, tY = game:GetRealPos(u.x, u.y)
  
 if u.visX == tX and u.visY == tY then
  if u.isAnimating then
   u.isAnimating = false
   u:StartAnimation(0, true)
  end
  return
 end

 if u.visX < tX then
  u.visX = u.visX + addonTable.units_speed
 elseif u.visX > tX then
  u.visX = u.visX - addonTable.units_speed
 end
 if u.visY < tY then
  u.visY = u.visY + addonTable.units_speed
 elseif u.visY > tY then
  u.visY = u.visY - addonTable.units_speed
 end
 if math.abs(u.visX - tX) <= addonTable.units_speed then
  u.visX = tX
 end
 if math.abs(u.visY - tY) <= addonTable.units_speed then
  u.visY = tY
 end
 u:SetVisualPos()
end

local function CheckUnitRotation(u)

 if u.destRotation == u.Rotation then return end

 local speed = 10
 
 if u.Rotation == 0 and u.destRotation == 270 then 
  u.Rotation = 360
 elseif u.Rotation == 270 and u.destRotation == 0 then 
  u.destRotation = 360
 end

 if u.Rotation == u.destRotation then return end
 if u.Rotation < u.destRotation then
  u.Rotation = u.Rotation + speed
 else
  u.Rotation = u.Rotation - speed
 end

 dist = math.abs(u.Rotation - u.destRotation)

 if dist <= speed then
  u.Rotation = u.destRotation
  if u.Rotation == 360 then 
   u.Rotation = 0 
   if u.destRotation == 360 then
    u.destRotation = 0
   end
  end
 end

 u.frame:SetRotation(math.rad(u.Rotation))
end

local function unitUpdate(u)
 u:CheckFrameAnimation()
 CheckUnitRotation(u)
end

local function canAfford(u, skill)
 return u.Manacurr >= skill.cost
end

function game:ApplyDamageBonus(u, tar, dam, damsource)
 local result = dam
 
 if not u or not u.Stats then return result end
 
 if strfind(damsource, "p") then -- percent
  result = tar.HPmax * dam / 100
 else
  if strfind(damsource, "w") then result = result + u:GetSwing() / 2 end
  if strfind(damsource, "s") then result = result + (u.Stats["Str"] / 2) end
  if strfind(damsource, "a") then result = result + (u.Stats["Agi"] / 2) end
  if strfind(damsource, "i") then result = result + (u.Stats["Int"] / 2) end
  if strfind(damsource, "e") then result = result + (u.Stats["BonusMelee"] / 2) end
  if strfind(damsource, "k") then result = result + (u.Stats["BonusSpell"] / 2) end
  if strfind(damsource, "l") then result = result + (u.Level) end
  
  if strfind(damsource, "W") then result = result + u:GetSwing() end
  if strfind(damsource, "S") then result = result + (u.Stats["Str"]) end
  if strfind(damsource, "A") then result = result + (u.Stats["Agi"]) end
  if strfind(damsource, "I") then result = result + (u.Stats["Int"]) end
  if strfind(damsource, "E") then result = result + (u.Stats["BonusMelee"]) end
  if strfind(damsource, "K") then result = result + (u.Stats["BonusSpell"]) end
  if strfind(damsource, "L") then result = result + (u.Level * 2) end
 end
 return math.floor(result)
end

local function unitGetSkill(u, skill)
 local result
 table.foreach(u.Skills, function(k,v) if v.name == skill then result = v.data end end)
 return result
end

local function unitUseSkill(u, skill, ...)
 if not u:CanAct() then return end
 local s = u:GetSkill(skill) 
 if not s then 
  --print("DDB - unit "..u.Name.." tried to use "..skill.." but he can't")
  return
 end

 local success 
 local act = s.activation
 local spell = s.spell
 local x,y = game:GetRealPos(u.x, u.y, u)
 
 if act and game:AuraExists(u, act.aura) and act.deactivatable then
  game:RemoveAura(u, act.aura)
  return
 end

 if s.cd and s.cd > 0 then
  game:CreateChatBubble({L["dlg_skillnotready"]}, u, 3)
  return
 end
 
 if canAfford(u, s) then
  if act then -- on activation duties
   if act.aura then -- apply aura
    game:ApplyAura(u, act.aura, u)
   end
   if act.anim then -- apply unit animation
    u:StartAnimation(act.anim)
	u.frame:SetScript("OnAnimFinished", function() u:StartAnimation(0) end)
   end
   game:CreateEffect(x, y, skill.."_act")
   success = true
  end
  if spell then
   success = game:FireSkill(u, spell, skill, ...)
  end
  if success then
   game:PlayRandomSound(S[skill], 100)
  end
 else
  game:CreateChatBubble({L["dlg_notenoughpower"]}, u, 3)
 end
 
 if success then
  u.Manacurr = u.Manacurr - s.cost
  game:CreateEffect(x, y, skill.."_cast", "anchored")
  game:PrepareEndTurn()
  if s.cooldown then s.cd = s.cooldown end
  return true
 else return
 end
end

function game:SetMobsLevel(lvl)
 table.foreach(game.GameData.Map.units, function(k,v)
  if v ~= game.GameData.Player then v:LevelUp(lvl, true) end
 end)
end

local function unitLevelUp(u, lvl, hidden)

 local function setstat(s, n)
  if not n or not u.Stats[s] then return end
  
  -- remove the old level bonuses..
  u.Stats[s] = u.Stats[s] - n * (u.Level - 1)
  -- ..and replace them with the new level ones
  u.Stats[s] = u.Stats[s] + n * (lvl - 1)
 end

 if not hidden then
  local x,y = game:GetRealPos(u.x, u.y, u)
  game:CreateEffect(x, y, "levelup")
  game:SysMessage("|cff00FF00Level UP!|r ("..lvl..")")
  game:CreateChatBubble({"Ding!"}, u, 5)
  game:Log(u.Name.." is now level "..lvl)
 end

 setstat("Str", u.db.strlvl)
 setstat("Agi", u.db.agilvl)
 setstat("Int", u.db.intlvl)
 setstat("Sta", u.db.stalvl)
 setstat("BonusMelee", u.db.bonusmeleelvl)
 setstat("BonusSpell", u.db.bonusspelllvl)
 
 u.Level = lvl
 
 u:CheckStats()
 
 u.HPcurr = u.HPmax
 u.Manacurr = u.Manamax
end

local function unitDispose(u, i)
 local found = i
 if not found then
  table.foreach(game.GameData.Map.units, function(k,v)
   if v == u then found = k end
  end)
 end
 if found then table.remove(game.GameData.Map.units, found) end
 local tu = game.GameData.Map:GetTile(u.x, u.y)
 if tu.unit == u then tu.unit = nil end
 u.frame:ClearModel()
 game:DisposeFrame(u.frame)
 u.frame = nil
end

function game:SetUnitDead(u)
 u.HPcurr = 0
 u.Status = "dead"
 --u.portrait = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_01"
 u:StartAnimation(1)
 table.foreach(u.Auras, function(k,v)
  game:RemoveAura(u, k)
 end)
 game:PlayRandomSound(u.sounds.death)
 game.GameData.Map:GetTile(u.x, u.y).unit = nil
 if u ~= game.GameData.Player then
  u.frame:SetScript("OnAnimFinished", function() 
   u:RemoveLight()
   u:Dispose()
   end)
  u.frame:SetScript("OnShow", function()
    u:RemoveLight()
    u:Dispose()
   end)
 else
  game.BTNReleaseSpirit:Show() 
 end
end

local function unitFillTooltip(u)
 local w,r,g = "|cffFFFFFF","|cffFF0000","|cff00FF00"
 GameTooltip:ClearLines()
 --GameTooltip:AddDoubleLine("|T"..u.portrait..":24|t", w..u.Name.."|r")
 GameTooltip:AddLine(w..u.Name.."|r")
 GameTooltip:AddLine(w.."HP: "..g..u.HPcurr.."/"..u.HPmax.."|r")
 GameTooltip:AddLine(w.."Status: "..r..u.Status.."|r")
 GameTooltip:AddLine(w.."Level: "..r..u.Level.."|r")
 GameTooltip:AddLine(" ")
 
--[[
 if u == game.GameData.Player then
  local k,v
  for k,v in pairs(u.Stats) do
   GameTooltip:AddLine(g..k..": "..w..(v < 0 and "-" or "")..v)
  end
  GameTooltip:AddLine(w.."XP: "..r..u.XP.."|r")
 end
]]

 table.foreach(u.Auras, function(k,v)
  GameTooltip:AddLine(w..g.."|T"..Sp[k].icon..":24|t "..Sp[k].name)
 end)
end

local function resolvegender(s)
 return s == 3 and "Female" or "Male"
end

local function unitCheckStats(u)
 u.HPmax = u.db.hp + (u.Stats["Sta"] and (u.Stats["Sta"] * 10) or 0)
 if u.HPcurr > u.HPmax then u.HPcurr = u.HPmax end
end

function game:SetUnitVars(u, reset)

 local function setstat(stat, v)
  if reset then 
   u[stat] = v 
  else
   if not u[stat] then 
    u[stat] = v
   end
  end
 end

 setstat("x", 0)
 setstat("y", 0)
 setstat("visX", 0)
 setstat("visY", 0) 
 setstat("Rotation", 0)
 setstat("destRotation", 0)
 setstat("aggro", 0)
 setstat("Level", 1)
 setstat("Auras", {})
 setstat("Status", "normal")
 setstat("Stats", {["Str"] = u.db.str and u.db.str or 0,
                   ["Agi"] = u.db.agi and u.db.agi or 0,
				   ["Int"] = u.db.int and u.db.int or 0,
				   ["Sta"] = u.db.sta and u.db.sta or 0,
                   ["BonusMelee"] = u.db.bonusmelee and u.db.bonusmelee or 0,
				   ["BonusSpell"] = u.db.bonusspell and u.db.bonusspell or 0,
				   ["DamageReduction"] = 1,
				   ["DamageMultiplier"] = 1})
 if u == game.GameData.Player then
  setstat("sounds", S[select(2,UnitRace("player"))..resolvegender(UnitSex("player"))])
  setstat("Manamax", 100)
  setstat("Manacurr", 100)
  setstat("LightRadius", 7)
  setstat("LightColor", {1,1,1})
  setstat("XP", 0)
  setstat("Skills", {})
  setstat("Inventory", {})
  setstat("InvCapacity", 20)
  setstat("Equipped", {})
  setstat("Side", "player")
 else
  setstat("Side", "hostile")
 end
 setstat("HPmax", u.db.hp + (u.Stats["Sta"] and (u.Stats["Sta"] * 10) or 0))
 u.HPcurr = u.HPmax
end


-- sul caricamento:
-- rendere rotation = a destRotation
-- rendere visxy = xy

function game:SetUnitMethods(u)
 u.Dispose = unitDispose
 u.Attack = unitAttack
 u.Interact = unitInteract
 u.Move = unitMove
 u.CanMove = unitCanMove
 u.GetSwing = unitGetSwing
 u.Act = unitAct
 u.CanAct = unitCanAct
 u.SetPos = unitSetPos
 u.SetVisualPos = unitSetVisualPos
 u.GetSkill = unitGetSkill
 u.UseSkill = unitUseSkill
 u.CheckStats = unitCheckStats
 u.CheckFrameAnimation = unitCheckFrameAnimation
 u.Update = unitUpdate
 u.StartAnimation = unitStartAnimation
 u.FindPath = addonTable.unitFindPath -- AI.lua
 u.LevelUp = unitLevelUp
 u.CanSee = unitCanSee
 u.FillTooltip = unitFillTooltip
 u.AddLight = addonTable.unitAddLight -- lighting.lua
 u.RemoveLight = addonTable.unitRemoveLight -- lighting.lua
end