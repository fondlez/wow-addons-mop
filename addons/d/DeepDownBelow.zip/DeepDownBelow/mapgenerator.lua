-- Deep Down Below by Fluffies
-- EU - Weel of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

local rnd = math.random
local minLeafSize = 8
local m
local current_tileset

-- BSP tree
local function CreateLeaf(x, y, w, h)
  
 local leaf = {}
 leaf.x = x
 leaf.y = y
 leaf.w = w 
 leaf.h = h

 local splitH = rnd(0,100) < 50
 if w > h and h / w >= 0.05 then
  splitH = false
 elseif h > w and w / h >= 0.05 then
  splitH = true
 end
 
 local maxsize = (splitH and h or w) - minLeafSize
 if maxsize <= minLeafSize then

 else
  local split = rnd(minLeafSize, maxsize)
  if splitH then
   leaf.leftChild = CreateLeaf(x, y, w, split)
   leaf.rightChild = CreateLeaf(x, y + split, w, h - split)
  else
   leaf.leftChild = CreateLeaf(x, y, split, h)
   leaf.rightChild = CreateLeaf(x + split, y, w - split, h)
  end
 end
 return leaf
end

local function getRoom(leaf)
 if leaf.room then return leaf.room end
 local lRoom, rRoom
 if leaf.leftChild then
  lRoom = getRoom(leaf.leftChild)
 end
 if leaf.rightChild then
  rRoom = getRoom(leaf.rightChild)
 end
 if not lRoom and not rRoom then
  return
 elseif not rRoom then
  return lRoom
 elseif not lRoom then
  return rRoom
 elseif rnd(0,100) < 50 then
  return lRoom
 else
  return rRoom
 end
end

local function connect(l, r)
 local sx, sy = rnd(l[1] + 1, l[1] + l[3] - 1), rnd(l[2] + 1, l[2] + l[4] - 1)
 local tx, ty = rnd(r[1] + 1, r[1] + r[3] - 1), rnd(r[2] + 1, r[2] + r[4] - 1)

 local x,y = sx, sy

 local db = current_tileset.doors
 local rnd = table.getn(db)
 
 while x ~= tx or y ~= ty do
  local _, destX, destY = game:GetAdjacentTile(x, y, game:FindDir(x, y, tx, ty))
  x = destX
  y = destY
  if (x == l[1]-1 and y >= l[2] and y <= l[2] + l[4]) or -- left
     (x == r[1]-1 and y >= r[2] and y <= r[2] + r[4]) or
     (y == l[2]-1 and x >= l[1] and x <= l[1] + l[3]) or -- top
     (y == r[2]-1 and x >= r[1] and x <= r[1] + r[3]) or
	 (x == l[1] + l[3]+1 and y >= l[2] and y <= l[2] + l[4]) or -- right
     (x == r[1] + r[3]+1 and y >= r[2] and y <= r[2] + r[4]) or
     (y == l[2] + l[4]+1 and x >= l[1] and x <= l[1] + l[3]) or -- bottom
     (y == r[2] + r[4]+1 and x >= r[1] and x <= r[1] + r[3]) then
  
   game:PlaceNewObject(db[math.random(rnd)], x, y, m)
  end
  m.tiles[x.."-"..y].tiletype = "Grass"
 end
end

local function createRoom(leaf)
 if leaf.leftChild and leaf.rightChild then
  connect(getRoom(leaf.leftChild), getRoom(leaf.rightChild))
 else
  local rw, rh = rnd(3, leaf.w - 2), rnd(3, leaf.h - 2)
  local rx, ry = rnd(1, leaf.w - rw - 1), rnd(1, leaf.h - rh - 1)
  leaf.room = {leaf.x + rx, leaf.y + ry, rw, rh}
 end
end

local function setTilesProperties(leaf)
 if leaf.leftChild and leaf.rightChild then return end

 local x,y
 for x = leaf.room[1], leaf.room[1] + leaf.room[3] do
  for y = leaf.room[2], leaf.room[2] + leaf.room[4] do
   m.tiles[x.."-"..y].tiletype = "Grass"
  end
 end
end

local function CycleLeaves(leaf, func)
 if leaf.leftChild and leaf.rightChild then
  CycleLeaves(leaf.leftChild, func)
  CycleLeaves(leaf.rightChild, func)
 end
 func(leaf)
end

function game:GenerateRandomMap(map, tileset)
 m = map
 current_tileset = tileset
 local w = m.Width
 local h = m.Height
 roomcount = 0
 local root = CreateLeaf(0,0,w,h)
 CycleLeaves(root, createRoom)
 CycleLeaves(root, setTilesProperties)
end