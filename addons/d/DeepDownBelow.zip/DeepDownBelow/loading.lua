﻿-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow

------------------------ Loading Screen ------------------------

local function EndLoadProcess()
 game.LoadingScreen:SetScript("OnUpdate", nil)
 if game.PostLoad then game.PostLoad() end
 game.LoadingScreen:Hide()
end

function game:StartLoadProcess(t, f, cond)
 game.LoadingScreen.text:SetText(t)
 game.LoadingScreen:Show()
 game.LoadingScreen:SetScript("OnUpdate", function() 
  for i = 0,10 do
   f()
  end
  if cond() then EndLoadProcess() end
 end)
end

------------------------ Savegame data ------------------------

-- Serialize only these variables
addonTable.SerializeVars = {
								  -- Units
								  "Level","XP","Stats",
                                  "LightRadius","LightColor","Inventory","Equipped",
								  "Str","Agi","Int","Sta","BonusMelee","BonusSpell","DamageReduction","DamageMultiplier",
								  -- Items
								  "HeadSlot","NeckSlot","ShoulderSlot","ChestSlot","HandsSlot","LegsSlot","FeetSlot","Trinket0Slot",
								  "MainHandSlot","SecondaryHandSlot","Enchant","Type","SubType","Quality","EQSlot","Damage","Model","Name","Desc",
								  "Texture","Itemlevel",
								  -- Lights
								  "Light","radius","intensity","color",
								  -- Player Statistics
								  "Statistics",
								  "game_turns_total","game_gamescreated",
								  "items_pickedup","items_pickedup_leg","items_deleted",
								  }

function game:SavePlayer()
 --wipe(DeepDownBelow_Character)

 -- Serialize Player
 local p = game.GameData.Player
 for k,v in pairs(p.Auras) do
  p:UnAffectStats(v) 
 end
 -- store it without buffs
 DeepDownBelow_Character = game:Serialize(p)
 
 for k,v in pairs(p.Auras) do
  p:AffectStats(v)
 end
end

function game:LoadPlayer(frommenu)
 local data = game.GameData
 local save = DeepDownBelow_Character

 local result = {}

 data.Player:Reset()

  _, result = game:Deserialize(save)
 table.foreach(result, function(k,v)
  if k == "Light" and not frommenu then
   data.Player:AddLight(v.radius, v.intensity, v.color)
  else
   data.Player[k] = v
  end
 end)
 for k,v in pairs(data.Player.Inventory) do
  game:SetItemMethods(v)
  game:SetItemVars(v, false)
 end
 for k,v in pairs(data.Player.Equipped) do
  game:SetItemMethods(v)
  game:SetItemVars(v, false)
 end
 data.Player:CheckStats()
 data.Player.HPcurr = data.Player.HPmax
 data.Player.Manacurr = data.Player.Manamax
 if not frommenu then
  game.CharacterFrame:RefreshInventory()
  game.CharacterFrame:RefreshEquipped()
  game.GameData.Player:SetPos(game.GameData.Player.x, game.GameData.Player.y, true)
 end
 collectgarbage()
end