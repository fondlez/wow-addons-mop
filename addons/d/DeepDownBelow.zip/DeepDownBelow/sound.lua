-- Deep Down Below by Fluffies
-- EU - Well of Eternity
local addonName, addonTable = ...
local game = DeepDownBelow
local rnd = math.random

function game:PlayRandomSound(t, chance)
 if not t then return end
 if chance and rnd(100) > chance then return end
 PlaySoundFile(t[rnd(1, table.getn(t))])
end