﻿# RETabBinder

[Curse](http://www.curse.com/addons/wow/retabbinder)

[WoWInterface](http://www.wowinterface.com/downloads/info19089-RETabBinder.html)

## COPYRIGHT

All Rights Reserved unless otherwise explicitly stated.

Copyright (c) 2013-2014 Paweł Jastrzębski <pawelj@iosphe.re>