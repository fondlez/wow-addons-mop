Roguedar by Sockseven

I wrote this addon origionally for personal use as I found rouges to be the bane of my PVP experience.
It simply detects any stealth or cloaking spells and notifies you when someone uses them near you.
The detection range is as large as the range for the combat log. I hope you like my little addon
and it serves you well. If you have any problems with it, if it breaks with a
new patch or just to let me know what you think, please email me at info@sockseven.com

--Commands--
Click and drag to move the Roguedar window.

"/rd" or "/roguedar" for help

"/rd off" to disable addon.
"/rd on" to enable addon.

"/rd soundoff" to disable sound.
"/rd soundon" to enable sound.


--Current bugs--
The right click menu is not yet implemented. Clicking on the RD window with any mouse button will
display the "Menu not implemented" message. As such, options can only be set via the /rd command


--To Do--
Right click menu.

I have been recently experimenting with range checking to enable Roguedar to tell you where the
threat is, or at least how far away. However, Blizzard seem to have gone to great lengths to
prevent range checking addons and as such I can only get the range of pets,party/raid members
or enemies that you are targeting, all of which are inadequate for my uses. I will keep looking
for ways to get the range of an untargeted enemy, but as it stands range checking won't be
added any time soon.


--Change log--
v1.5.1
Minor update to bring in line with 5.4 and ensure project does not become abandoned.
I've begun playing World of Warcraft more often again and will resume proper
development of this addon.

v1.5
Updated for 5.0.
Fixed green background bug caused by Mists of Pandaria release.
Refined user interface (thinner frame borders).
A few spelling errors in the code.

v1.4
Updated for patch 4.2. The 4.2 patch changed the combat log slightly causing Roguedar to fail to
function correctly. However, as it did not return any errors, I didn't notice this fault until
recently.

v1.3
Updated for Patch 4.1.

V1.2
Added hunter Camouflage detection.

V1.1
Rank messages now correctly removed.

V1.0
Updated for Cataclysm.
Removed ranks from messages.
Cleaned up code for release.


--Special Thanks--
A special thanks to all my guild mates of Acta Sanctorum (Darkmoon Faire) who helped me test this
addon, especially the rogues and druids.