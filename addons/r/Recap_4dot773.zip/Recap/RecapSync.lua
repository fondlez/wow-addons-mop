﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ Synchronization functions ]]

local math_floor = _G.math.floor
local math_max = _G.math.max
local math_min = _G.math.min
local string_find = _G.string.find
local pairs = _G.pairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ local functions (precede first use) ]]

local function Recap_SyncExtractNameGUID(nameServer)
	local _, name
	-- format is name_GUID_server
	_, _, name = string_find(nameServer, "^(.+)_.-$")
	return name
end

local function GetCurrentGroupDistribution()
	local inInstance, instanceType = IsInInstance()
	if inInstance and ((instanceType == "pvp") or (instanceType == "arena")) then
		return "BATTLEGROUND"
	elseif IsInRaid() then -- updated for 5.04
		return "RAID"
	elseif (GetNumSubgroupMembers() > 0) then
		return "PARTY"
	else
		-- not in a valid group, won't be able to send any sync messages
		return nil
	end
end

local function Recap_RememberInvite(timestamp, leader, mergePets, name, server, recapVersion, newOngoing)
	local rTemp = _G.recap_temp
	rTemp.SyncInviteTimestamp = timestamp
	rTemp.SyncInviteLeader = leader
	rTemp.SyncInviteLeaderName = name
	rTemp.SyncInviteLeaderServer = server
	rTemp.SyncInviteLeaderRecapVersion = recapVersion
	rTemp.SyncInviteMergePets = mergePets
	rTemp.SyncInviteWhen = math_floor(1000*GetTime()) -- integer thousandths
	rTemp.SyncInviteNewOngoing = newOngoing
end

local function Recap_RememberSyncData(timestamp, Name, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags)
	local rTemp = _G.recap_temp
	if not rTemp.SyncData[Name] then
		rTemp.SyncData[Name] = {}
	end
	local iName = rTemp.SyncData[Name]
	iName.Timestamp = timestamp
	iName.Time = math_max((iName.Time or 0), (Time or 0))
	iName.TimeIn = math_max((iName.TimeIn or 0), (TimeIn or 0))
	iName.TimeHeal = math_max((iName.TimeHeal or 0), (TimeHeal or 0))
	iName.DmgOut = math_max((iName.DmgOut or 0), (DmgOut or 0))
	iName.DmgIn = math_max((iName.DmgIn or 0), (DmgIn or 0))
	iName.RawHeal = math_max((iName.RawHeal or 0), (RawHeal or 0))
	iName.OverHeal = math_max((iName.OverHeal or 0), (OverHeal or 0))
	iName.MaxHit = math_max((iName.MaxHit or 0), (MaxHit or 0))
	iName.Deaths = math_max((iName.Deaths or 0), (Deaths or 0))
	if Seen and (Seen > 0) then
		-- only use the value if we don't have one already
		if (iName.Seen == nil) or (iName.Seen == 0) then
			iName.Seen = Seen
		end
	end
	if Flags and (Flags > 0) then
		iName.Flags = Flags
	end
	iName.When = math_floor(1000*GetTime()) -- integer thousandths
end

local function Recap_JoinSync(timestamp, leader, mergePets, name, server, recapVersion)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	rUser.SyncState = "Member"
	rUser.SyncTimestamp = timestamp
	rUser.SyncLeader = leader
	rUser.SyncLeaderName = name
	rUser.SyncLeaderServer = server
	rUser.SyncMergePets = mergePets
	rUser.SyncUpdateWhen = math_floor(1000*GetTime()) -- integer thousandths
	rTemp.SyncData = wipe(rTemp.SyncData)
	rTemp.SyncMembers = wipe(rTemp.SyncMembers)
	Recap_UpdateSyncMember(name, server, recapVersion)
	Recap_UpdateSyncMember(rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap_SetSyncDisplay()

	-- reset All Fights
	RecapPanel_Hide(1)
	RecapRecent_Hide(1)
	RecapLoad_Hide()
	Recap_ResetAllCombatants(true) -- force reset even of locked combatants
	RecapGraph_InitializeLiveLists()
	Recap_MakeFriends(true)

	-- perhaps remove pet effects
	if rUser.SyncMergePets == "off" then
		Recap_RemovePetEffects()
	end

	-- display
	Recap_SetState(false)
	Recap_SetView()

end

local function Recap_AskJoinSync(timestamp, leader, mergePets, name, server, recapVersion, newOngoing)

	local rTemp = _G.recap_temp
	local msg, textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		-- free the spinlock
		rTemp.AskingJoinSync = false
		return
	end

	msg = rTemp.Recap..": "..Recap_NameOnlyFromCombatant(name).." ("..server..") "..rLocalize.InvitesYouToSynchronize
	if mergePets == "on" then
		msg = msg.."  ("..rLocalize.MergePetsOn..")"
	else
		msg = msg.."  ("..rLocalize.MergePetsOff..")"
	end
	if newOngoing == "new" then
		msg = msg.."\n\n--  "..rLocalize.NewSynchronization.."  --"
	else
		msg = msg.."\n\n--  "..rLocalize.OngoingSynchronization.."  --"
	end
	StaticPopupDialogs["rTemp.ASKJOINSYNC"] = {
		text = msg,
		button1 = ACCEPT,
		button2 = CANCEL,
		OnAccept = function(self)
			-- join the synchronization
			Recap_JoinSync(timestamp, leader, mergePets, name, server, recapVersion)
			-- send accept message
			textToSend = Recap:Serialize(rTemp.Accept, Recap_Sync_Version, timestamp, leader, mergePets, rTemp.PlayerGUID, rTemp.Server, Recap_Version)
			Recap:SendCommMessage("Recap", textToSend, distribution)
			-- free the spinlock
			rTemp.AskingJoinSync = false
		end,
		OnCancel = function(self)
			-- send decline message
			textToSend = Recap:Serialize(rTemp.Decline, Recap_Sync_Version, timestamp, leader, mergePets, rTemp.PlayerGUID, rTemp.Server, Recap_Version)
			Recap:SendCommMessage("Recap", textToSend, distribution)
			-- free the spinlock
			rTemp.AskingJoinSync = false
		end,
		timeout = 30,
		showAlert = 1,
		whileDead = 1
	}
	StaticPopup_Show("rTemp.ASKJOINSYNC") -- Note: NOT a blocking call

end

local function Recap_SendNewInvite()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	-- issue invitation (version, timestamp, leader, mergePets, name, server, recapVersion)
	textToSend = Recap:Serialize(rTemp.NewInvite, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets, rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")
end

local function Recap_SendOngoingInvite()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	-- issue invitation (version, timestamp, leader, mergePets, name, server, recapVersion)
	textToSend = Recap:Serialize(rTemp.OngoingInvite, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets, rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")
end

local function Recap_SendSummary()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, iCombatant, textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			-- skip combatants with all combat data nil (but send every group member even if their data is entirely nil)
			if iCombatant.TotalTime or iCombatant.TotalTimeIn or iCombatant.TotalTimeHeal or iCombatant.TotalDmgOut or iCombatant.TotalDmgIn or
			   iCombatant.TotalRawHeal or iCombatant.TotalOverHeal or iCombatant.TotalMaxHit or iCombatant.TotalDeaths or rTemp.InGroup[i] then
				-- one message per combatant (version, timestamp, leader, mergePets, summary values)
				-- send times as integer thousandths for more compact transmission
				textToSend = Recap:Serialize(rTemp.Summary, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets,
									   i,
									   math_floor(1000*(iCombatant.TotalTime or 0)), math_floor(1000*(iCombatant.TotalTimeIn or 0)), math_floor(1000*(iCombatant.TotalTimeHeal or 0)),
									   (iCombatant.TotalDmgOut or 0), (iCombatant.TotalDmgIn or 0), (iCombatant.TotalRawHeal or 0), (iCombatant.TotalOverHeal or 0),
									   (iCombatant.TotalMaxHit or 0), (iCombatant.TotalDeaths or 0), (iCombatant.Seen or 0), (iCombatant.Flags or 0))
				Recap:SendCommMessage("Recap", textToSend, distribution)
			end
		end
	end

	-- NOTE: removed sync of fight start and end times, and total duration (Blizzard event times are not adequately synchronized among clients)

	-- turn on sync status light blink
	if rTemp.SyncStatusLightBlink == 0 then
		rTemp.SyncStatusLightBlink = 1
	end

	-- update our own heartbeat as leader
	Recap_UpdateSyncMember(rTemp.PlayerGUID, rTemp.Server, Recap_Version)

	-- remember the local time of the latest update activity
	rUser.SyncUpdateWhen = math_floor(1000*GetTime()) -- integer thousandths
	Recap_SetSyncDisplay()

	-- start a timer to detect when synchronization activity is over
	rTemp.EndSyncDelayTimer = 0

	-- turn on sync status light blink
	if rTemp.SyncStatusLightBlink == 0 then
		rTemp.SyncStatusLightBlink = 1
	end
end

local function Recap_GetSummaries()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	textToSend = Recap:Serialize(rTemp.GetSummaries, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets)
	Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")
end

local function Recap_ProcessSummary(NameGUID, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local upTime, upTimeIn, upTimeHeal, upDmgOut, upDmgIn, upRawHeal, upOverHeal, upMaxHit, upDeaths, upSeen, upFlags, iCombatant, textToSend, distribution
	upTime = false
	upTimeIn = false
	upTimeHeal = false
	upDmgOut = false
	upDmgIn = false
	upRawHeal = false
	upOverHeal = false
	upMaxHit = false
	upDeaths = false
	upSeen = false
	upFlags = false

	-- removed sync of fight start and end, and total duration (Blizzard event times are not adequately synchronized among clients)

	if not rCombatants[NameGUID] then
		-- new combatant
		Recap_CreateBlankCombatant(NameGUID, Seen, Flags)
	end

	-- if an incoming value is larger than our value, it replaces our value
	-- if our value is larger, we'll send that out
	-- the times come in as integer thousandths for more compact transmission
	iCombatant = rCombatants[NameGUID]
	if iCombatant.TotalTime and (math_floor(1000*iCombatant.TotalTime) > Time) then
		upTime = math_floor(1000*iCombatant.TotalTime)
	elseif (Time > 0) then
		iCombatant.TotalTime = Time/1000
	end
	if iCombatant.TotalTimeIn and (math_floor(1000*iCombatant.TotalTimeIn) > TimeIn) then
		upTimeIn = math_floor(1000*iCombatant.TotalTimeIn)
	elseif (TimeIn > 0) then
		iCombatant.TotalTimeIn = TimeIn/1000
	end
	if iCombatant.TotalTimeHeal and (math_floor(1000*iCombatant.TotalTimeHeal) > TimeHeal) then
		upTimeHeal = math_floor(1000*iCombatant.TotalTimeHeal)
	elseif (TimeHeal > 0) then
		iCombatant.TotalTimeHeal = TimeHeal/1000
	end
	if iCombatant.TotalDmgOut and (iCombatant.TotalDmgOut > DmgOut) then
		upDmgOut = iCombatant.TotalDmgOut
	elseif (DmgOut > 0) then
		iCombatant.TotalDmgOut = DmgOut
	end
	if iCombatant.TotalDmgIn and (iCombatant.TotalDmgIn > DmgIn) then
		upDmgIn = iCombatant.TotalDmgIn
	elseif (DmgIn > 0) then
		iCombatant.TotalDmgIn = DmgIn
	end
	if iCombatant.TotalRawHeal and (iCombatant.TotalRawHeal > RawHeal) then
		upRawHeal = iCombatant.TotalRawHeal
	elseif (RawHeal > 0) then
		iCombatant.TotalRawHeal = RawHeal
	end
	if iCombatant.TotalOverHeal and (iCombatant.TotalOverHeal > OverHeal) then
		upOverHeal = iCombatant.TotalOverHeal
	elseif (OverHeal > 0) then
		iCombatant.TotalOverHeal = OverHeal
	end
	if iCombatant.TotalMaxHit and (iCombatant.TotalMaxHit > MaxHit) then
		upMaxHit = iCombatant.TotalMaxHit
	elseif (MaxHit > 0) then
		iCombatant.TotalMaxHit = MaxHit
	end
	if iCombatant.TotalDeaths and (iCombatant.TotalDeaths > Deaths) then
		upDeaths = iCombatant.TotalDeaths
	elseif (Deaths > 0) then
		iCombatant.TotalDeaths = Deaths
	end
	if Seen and (Seen > 0) then
		-- only use the value if we don't have one already
		if (iCombatant.Seen == nil) or (iCombatant.Seen == 0) then
			iCombatant.Seen = Seen
		end
	else
		-- for some reason the incoming data doesn't seem to have a value for Seen (unlikely), so send them one if we have one
		if iCombatant.Seen and (iCombatant.Seen > 0) then
			upSeen = iCombatant.Seen
		end
	end
	if iCombatant.Flags and (iCombatant.Flags > 0) and ((not Flags) or (Flags == 0)) then
		-- we have flags and sender doesn't
		upFlags = iCombatant.Flags
	elseif Flags and (Flags > 0) then
		-- we accept sender's flags, which may not always be the latest value (tough)
		iCombatant.Flags = Flags
	end

	-- silently adjust overhealing number if necessary (could leave us out of strict sync)
	if iCombatant.TotalOverHeal and (iCombatant.TotalOverHeal > 0) and iCombatant.TotalRawHeal and (iCombatant.TotalRawHeal > 0) then
		iCombatant.TotalOverHeal = math_min(iCombatant.TotalOverHeal, iCombatant.TotalRawHeal)
	end

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, send no messages
	else
		-- okay to send messages
		if upTime or upTimeIn or upTimeHeal or upDmgOut or upDmgIn or upRawHeal or upOverHeal or upMaxHit or upDeaths or upSeen or upFlags then
			-- one message per combatant (version, timestamp, leader, mergePets, summary values)
			-- values that do not need updating are sent as 'false'
			textToSend = Recap:Serialize(rTemp.Reply, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets,
								   NameGUID, upTime, upTimeIn, upTimeHeal, upDmgOut, upDmgIn, upRawHeal, upOverHeal, upMaxHit, upDeaths, upSeen, upFlags)
			Recap:SendCommMessage("Recap", textToSend, distribution)
		else
			-- we're not sending any update for this combatant
			-- if this is a summary record for the leader of the synchronization (i.e. only once per Summary set),
			--   then send a Heartbeat to show that we are still here
			local _, tempName
			_, _, tempName = string_find(rUser.SyncLeader, "^([%a%-]+)") -- modified to allow embedded hyphens
			if NameGUID == tempName then
				Recap_SendSyncHeartbeat()
			end
		end
	end

	-- derivative calculated values
	if iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
		iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
	end
	if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
		iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
	end
	if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
		iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
	end

	-- update our own heartbeat as member
	Recap_UpdateSyncMember(rTemp.PlayerGUID, rTemp.Server, Recap_Version)

	-- remember the local time of the latest update activity
	rUser.SyncUpdateWhen = math_floor(1000*GetTime()) -- integer thousandths
	Recap_SetSyncDisplay()

	-- start a timer to detect when synchronization activity is over
	rTemp.EndSyncDelayTimer = 0

	-- turn on sync status light blink
	if rTemp.SyncStatusLightBlink == 0 then
		rTemp.SyncStatusLightBlink = 1
	end
end

local function Recap_ProcessReply(NameGUID, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	-- removed sync of fight start and end, and total duration (Blizzard event times are not adequately synchronized among clients)

	if not rCombatants[NameGUID] then
		-- new combatant
		Recap_CreateBlankCombatant(NameGUID, Seen, Flags)
	end

	-- if an incoming value is false, it is ignored
	-- if it is larger than our value, it replaces our value
	-- if our value is larger, we don't reply (we would have done so in response to the initial Summary)
	-- the times come in as integer thousandths for more compact transmission
	local iCombatant = rCombatants[NameGUID]
	if Time and (Time > 0) then
		if Time > math_floor(1000*(iCombatant.TotalTime or 0)) then
			iCombatant.TotalTime = Time/1000
		end
	end
	if TimeIn and (TimeIn > 0) then
		if TimeIn > math_floor(1000*(iCombatant.TotalTimeIn or 0)) then
			iCombatant.TotalTimeIn = TimeIn/1000
		end
	end
	if TimeHeal and (TimeHeal > 0) then
		if TimeHeal > math_floor(1000*(iCombatant.TotalTimeHeal or 0)) then
			iCombatant.TotalTimeHeal = TimeHeal/1000
		end
	end
	if DmgOut and (DmgOut > 0) then
		if DmgOut > (iCombatant.TotalDmgOut or 0) then
			iCombatant.TotalDmgOut = DmgOut
		end
	end
	if DmgIn and (DmgIn > 0) then
		if DmgIn > (iCombatant.TotalDmgIn or 0) then
			iCombatant.TotalDmgIn = DmgIn
		end
	end
	if RawHeal and (RawHeal > 0) then
		if RawHeal > (iCombatant.TotalRawHeal or 0) then
			iCombatant.TotalRawHeal = RawHeal
		end
	end
	if OverHeal and (OverHeal > 0) then
		if OverHeal > (iCombatant.TotalOverHeal or 0) then
			iCombatant.TotalOverHeal = OverHeal
		end
	end
	if MaxHit and (MaxHit > 0) then
		if MaxHit > (iCombatant.TotalMaxHit or 0) then
			iCombatant.TotalMaxHit = MaxHit
		end
	end
	if Deaths and (Deaths > 0) then
		if Deaths > (iCombatant.TotalDeaths or 0) then
			iCombatant.TotalDeaths = Deaths
		end
	end
	if Seen and (Seen > 0) then
		-- only use the value if we don't have one already
		if (iCombatant.Seen == nil) or (iCombatant.Seen == 0) then
			iCombatant.Seen = Seen
		end
	end
	if Flags and (Flags > 0) then
		-- we accept sender's flags, which may not always be the latest value (tough)
		iCombatant.Flags = Flags
	end

	-- silently adjust overhealing number if necessary (could leave us out of strict sync)
	if iCombatant.TotalOverHeal and (iCombatant.TotalOverHeal > 0) and iCombatant.TotalRawHeal and (iCombatant.TotalRawHeal > 0) then
		iCombatant.TotalOverHeal = math_min(iCombatant.TotalOverHeal, iCombatant.TotalRawHeal)
	end

	-- derivative calculated values
	if iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
		iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
	end
	if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
		iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
	end
	if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
		iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
	end

	-- remember the local time of the latest update activity
	rUser.SyncUpdateWhen = math_floor(1000*GetTime()) -- integer thousandths
	Recap_SetSyncDisplay()

	-- start a timer to detect when synchronization activity is over
	rTemp.EndSyncDelayTimer = 0

	-- turn on sync status light blink
	if rTemp.SyncStatusLightBlink == 0 then
		rTemp.SyncStatusLightBlink = 1
	end
end


--[[ global functions ]]

function Recap_SetSyncDisplay()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	if not rTemp.Loaded then
		return
	end

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	if rOpt.IgnoreGUIDs.value then
		-- if ignoring GUIDs, disallow sync
		rOpt.EnableSync.value = false
		rUser.SyncState = "Ignore"
	end

	if rUser.SyncState == "Ignore" then
		RecapOpt_SyncState:SetText(RECAP_SYNC_STATE_IGNORE)
		RecapOpt_SyncStateDetail:SetText("")
		RecapOpt_SyncStateLastUpdate:SetText("")
		RecapStartSyncMergePetsOffButton:Disable()
		RecapStartSyncMergePetsOnButton:Disable()
		RecapManualSyncButton:Disable()
		RecapBecomeLeaderButton:Disable()
		RecapListMembersButton:Disable()
		RecapClearInactiveMembersButton:Disable()
		RecapSkipNextFightButton:Enable()
	elseif rUser.SyncState == "Ready" then
		RecapOpt_SyncState:SetText(RECAP_SYNC_STATE_READY)
		RecapOpt_SyncStateDetail:SetText("")
		RecapOpt_SyncStateLastUpdate:SetText("")
		RecapStartSyncMergePetsOffButton:Enable()
		RecapStartSyncMergePetsOnButton:Enable()
		RecapManualSyncButton:Disable()
		RecapBecomeLeaderButton:Disable()
		RecapListMembersButton:Disable()
		RecapClearInactiveMembersButton:Disable()
		RecapSkipNextFightButton:Enable()
	elseif rUser.SyncState == "Member" then
		RecapOpt_SyncState:SetText(RECAP_SYNC_STATE_MEMBER)
		Recap_SetSyncStateDetail()
		RecapStartSyncMergePetsOffButton:Enable()
		RecapStartSyncMergePetsOnButton:Enable()
		RecapManualSyncButton:Disable()
		RecapBecomeLeaderButton:Enable()
		RecapListMembersButton:Enable()
		RecapClearInactiveMembersButton:Enable()
		RecapSkipNextFightButton:Disable()
	elseif rUser.SyncState == "Leader" then
		RecapOpt_SyncState:SetText(RECAP_SYNC_STATE_LEADER)
		Recap_SetSyncStateDetail()
		RecapStartSyncMergePetsOffButton:Enable()
		RecapStartSyncMergePetsOnButton:Enable()
		RecapManualSyncButton:Enable()
		RecapBecomeLeaderButton:Disable()
		RecapListMembersButton:Enable()
		RecapClearInactiveMembersButton:Enable()
		RecapSkipNextFightButton:Enable()
	else
		-- safety code
		rOpt.EnableSync.value = false
		rUser.SyncState = "Ignore"
		-- clear all sync values (including the spinlock)
		rUser.SyncTimestamp = false
		rUser.SyncLeader = false
		rUser.SyncLeaderName = false
		rUser.SyncLeaderServer = false
		rUser.SyncMergePets = false
		rUser.SyncUpdateWhen = false
		rTemp.SyncInviteTimestamp = false
		rTemp.SyncInviteLeader = false
		rTemp.SyncInviteLeaderName = false
		rTemp.SyncInviteLeaderServer = false
		rTemp.SyncInviteLeaderRecapVersion = false
		rTemp.SyncInviteMergePets = false
		rTemp.SyncInviteWhen = false
		rTemp.SyncInviteNewOngoing = false
		rTemp.AskingJoinSync = false
		rTemp.SyncData = wipe(rTemp.SyncData)
		rTemp.SyncMembers = wipe(rTemp.SyncMembers)
		rTemp.OnCommReceived = false
		RecapOpt_SyncState:SetText(RECAP_SYNC_STATE_IGNORE)
		RecapOpt_SyncStateDetail:SetText("")
		RecapOpt_SyncStateLastUpdate:SetText("")
		RecapStartSyncMergePetsOffButton:Disable()
		RecapStartSyncMergePetsOnButton:Disable()
		RecapManualSyncButton:Disable()
		RecapBecomeLeaderButton:Disable()
		RecapListMembersButton:Disable()
		RecapClearInactiveMembersButton:Disable()
		RecapSkipNextFightButton:Enable()
	end
end

function Recap_SetSyncStateDetail()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local text

	text = ""
	if rUser.SyncTimestamp then
		text = text..rLocalize.Timestamp..": "..tostring(rUser.SyncTimestamp)
	end
	if rUser.SyncState and (rUser.SyncState == "Member") and rUser.SyncLeader then
		-- somehow (don't know how) SyncLeader is losing its value
		-- details for leader distinguished by not listing leader
		text = text.."   "..rLocalize.Leader..": "..Recap_NameOnlyFromCombatant(rUser.SyncLeaderName).." ("..rUser.SyncLeaderServer..")"
	end
	if rUser.SyncMergePets and (rUser.SyncMergePets == "on") then
		text = text.."  ("..rLocalize.MergePetsOn..")"
	else
		text = text.."  ("..rLocalize.MergePetsOff..")"
	end
	RecapOpt_SyncStateDetail:SetText(text)
	text = ""
	if rUser.SyncUpdateWhen then
		text = rLocalize.LastUpdateWas..": "..Recap_FormatTime(GetTime()-(rUser.SyncUpdateWhen/1000)).." "..rLocalize.Ago
	end
	RecapOpt_SyncStateLastUpdate:SetText(text)
end

function Recap_UpdateSyncMember(name, server, recapVersion)
	local rTemp = _G.recap_temp
	if not rTemp.SyncMembers[name..server] then
		rTemp.SyncMembers[name..server] = {}
	end
	local iMember = rTemp.SyncMembers[name..server]
	iMember.Name = name
	iMember.Server = server
	iMember.RecapVersion = recapVersion
	iMember.When = math_floor(1000*GetTime())
	iMember.Ago = 0
end

function Recap_StartSync(mergePets)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	-- paranoia check
	if rUser.SyncState == "Ignore" then
		-- bail if ignoring synchronization
		return
	end

	if (rUser.State == "Stopped") then
		-- we've got Recap turned off at the moment (okay to start if Recap is in combat, invitation will be presented when people are out of combat)
		PlaySound("igQuestFailed")
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then
		PlaySound("igQuestFailed")
		return
	end
	rTemp.OnCommReceived = true

	-- abandon existing synchronization (if any), start a new one as leader
	rUser.SyncState = "Leader"
	rUser.SyncTimestamp = math_floor(1000*GetTime()) -- integer thousandths
	rUser.SyncLeader = rTemp.PlayerGUID.."_"..rTemp.Server
	rUser.SyncLeaderName = rTemp.PlayerGUID
	rUser.SyncLeaderServer = rTemp.Server
	rUser.SyncMergePets = mergePets
	rUser.SyncUpdateWhen = rUser.SyncTimestamp
	rTemp.AskingJoinSync = false
	rTemp.SyncData = wipe(rTemp.SyncData)
	rTemp.SyncMembers = wipe(rTemp.SyncMembers)
	Recap_UpdateSyncMember(rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap_SetSyncDisplay()

	-- reset All Fights
	RecapPanel_Hide(1)
	RecapRecent_Hide(1)
	RecapLoad_Hide()
	Recap_ResetAllCombatants(true) -- force reset even of locked combatants
	RecapGraph_InitializeLiveLists()
	Recap_MakeFriends(true)

	-- perhaps remove pet effects
	if rUser.SyncMergePets == "off" then
		Recap_RemovePetEffects()
	end

	-- display
	Recap_SetState(false)
	Recap_SetView()

	-- invite
	Recap_SendNewInvite()

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_ManualSync()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	-- paranoia check
	if not (rUser.SyncState == "Leader") then
		-- bail if not Leader
		return
	end

	if (rUser.State == "Active") then
		-- we are in combat
		PlaySound("igQuestFailed")
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then
		PlaySound("igQuestFailed")
		return
	end
	rTemp.OnCommReceived = true

	-- ongoing invite (i.e. this is not a new synch)
	Recap_SendOngoingInvite()

	-- send a standard Summary
	Recap_SendSummary()

	-- ask everyone else to send a standard Summary (old versions of Recap will simply not respond to this message)
	Recap_GetSummaries()

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_BecomeLeader()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	-- paranoia check
	if not (rUser.SyncState == "Member") then
		-- bail if not Member
		return
	end

	if (rUser.State == "Active") then
		-- we've got Recap turned off at the moment, or are in combat
		PlaySound("igQuestFailed")
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then
		PlaySound("igQuestFailed")
		return
	end
	rTemp.OnCommReceived = true

	-- take over an existing synchronization as leader
	rUser.SyncState = "Leader"
	rUser.SyncLeader = rTemp.PlayerGUID.."_"..rTemp.Server
	rUser.SyncLeaderName = rTemp.PlayerGUID
	rUser.SyncLeaderServer = rTemp.Server
	Recap_SetSyncDisplay()

	-- ongoing invite (i.e. this is not a new synch)
	Recap_SendOngoingInvite()

	-- do a synchronization to let other players know about the change of leader
	Recap_SendSummary()

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_SendPauseAll()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	-- ask all members to pause (sent at higher priority)
	textToSend = Recap:Serialize(rTemp.PauseAll, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets, rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")
end

function Recap_SendResumeAll()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	-- ask all members to resume (sent at higher priority)
	-- TODO: will probably cause something to work incorrectly if a save is in progress
	textToSend = Recap:Serialize(rTemp.ResumeAll, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets, rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")
end

-- standard receipt of Recap synchronization messages
function Recap:OnCommReceived(prefix, textToReceive, distribution, sender)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local found, request, version, timestamp, leader, mergePets, Name, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags

	found, request, version, timestamp, leader, mergePets, Name, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags = Recap:Deserialize(textToReceive)

	if found == false then
		-- error in Deserialize
		print(rTemp.Recap..":", "error in Deserialize:", request)
		return
	end

	-- in some contexts (Invite, Accept, Decline, Heartbeat) two parameters have different meanings
	local Server = Time
	local RecapVersion = TimeIn

	if rUser.SyncState == "Ignore" then
		-- we're ignoring synchronization
		-- (optimisation could be to dynamically Register and Unregister from the channel)
		return
	end

	-- note, we allow synchronization activity to complete while Recap is paused (state = "Stopped")

	-- between AceComm (r47060) and AceComm (r48940) there is a serious incompatibility, so that good values
	--   sent using the former are received via the latter as nils -- bad Ace !
	--   and later (r66043) as false with sync supposedly turned off -- damn you Ace !
	if (request == nil) or (version == nil) or (timestamp == nil) or (leader == nil) or (mergePets == nil) or
	   (request == false) or (version == false) or (timestamp == false) or (leader == false) then
		-- silently ignore messages with nil or false for a selection of parameters
		return
	end

	if not (version == Recap_Sync_Version) then
		-- incompatible version (at moment exact match required)
		if version and Recap_Sync_Version and tonumber(version) and tonumber(Recap_Sync_Version) and (tonumber(version) > tonumber(Recap_Sync_Version)) then
			-- running an outdated version
			print(rTemp.Recap..":", rLocalize.OutOfDateSyncVersion)
		end
		return
	end

	if sender == rTemp.Player then
		-- ignore messages from self (note that this will cause problems on the rare occasion of two people with the same name (but from different servers) in the same synchronization
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then return end
	rTemp.OnCommReceived = true

	-- State machine based on SyncState and request

	-- Pause message (Member, Leader)
	if request == rTemp.PauseAll then
		if not (rUser.State=="Stopped") then
			local msg = rTemp.Recap..": "..Recap_NameOnlyFromCombatant(Name).." ("..Server..") "..rLocalize.AsksYouToPause
			StaticPopupDialogs["rTemp.ASKPAUSE"] = {
				text = msg,
				button1 = ACCEPT,
				button2 = CANCEL,
				OnAccept = function(self)
					-- pause
--print("(Recap) EndFight due to request from sync")
					Recap_EndFight(true)
					if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
						-- hostile boss present, schedule a save of the last fight, to begin on the next tick
						rTemp.FlagSavePhase = 1
						rTemp.FlagSaveLastOnly = true
						rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
						rTemp.BossList = ""
						rTemp.FlagSavePriorState = "Stopped"
					end
					Recap_SetState("Stopped")
					-- update live numbers
					Recap_UpdateMinimizedDPS()
					Recap_DisplayMinimizedDPS()
					Recap_SetButtons()
				end,
				OnCancel = function(self)
				end,
				timeout = 30,
				showAlert = 1,
				whileDead = 1
			}
			StaticPopup_Show("rTemp.ASKPAUSE") -- Note: NOT a blocking call
		end
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- Resume message (Member, Leader)
	-- TODO: will probably cause something to work incorrectly if a save is in progress
	if request == rTemp.ResumeAll then
		if (rUser.State=="Stopped") then
			local msg = rTemp.Recap..": "..Recap_NameOnlyFromCombatant(Name).." ("..Server..") "..rLocalize.AsksYouToResume
			StaticPopupDialogs["rTemp.ASKRESUME"] = {
				text = msg,
				button1 = ACCEPT,
				button2 = CANCEL,
				OnAccept = function(self)
					-- resume
					Recap_ClearAsIfEndOfFight()
					Recap_SetState("Idle")
					Recap_SetButtons()
				end,
				OnCancel = function(self)
				end,
				timeout = 30,
				showAlert = 1,
				whileDead = 1
			}
			StaticPopup_Show("rTemp.ASKRESUME") -- Note: NOT a blocking call
		end
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- Invite messages (Ready, Member, Leader)
	if request == rTemp.NewInvite then
		if rUser.State == "Active" then
			-- in combat, remember the request (overwrites any earlier memo)
			Recap_RememberInvite(timestamp, leader, mergePets, Name, Server, RecapVersion, "new")
		elseif rUser.State == "Idle" then
			-- idle (not in combat), okay to pop the question (but only if not already asking it)
			if not rTemp.AskingJoinSync then
				rTemp.AskingJoinSync = true
				Recap_AskJoinSync(timestamp, leader, mergePets, Name, Server, RecapVersion, "new")
			end
		end
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- Ready (OngoingInvite)
	if rUser.SyncState == "Ready" then
		-- not currently a member of a synchronization
		if request == rTemp.OngoingInvite then
			if rUser.State == "Active" then
				-- in combat, remember the invitation for later (overwrites any earlier memo)
				Recap_RememberInvite(timestamp, leader, mergePets, sender, Recap_SyncExtractServer(leader), rLocalize.Unknown, "ongoing")
			else
				-- idle (not in combat), okay to pop the question (but only if not already asking it)
				if not rTemp.AskingJoinSync then
					rTemp.AskingJoinSync = true
					Recap_AskJoinSync(timestamp, leader, mergePets, sender, Recap_SyncExtractServer(leader), rLocalize.Unknown, "ongoing")
				end
			end
			-- note that until the player actually accepts the invite, the Summary data are discarded
		end
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end
	-- assert: Member or Leader only

	-- if in synch, ignore ongoing invites
	if request == rTemp.OngoingInvite then
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- assert: further processing must match on timestamp
	if not (rUser.SyncTimestamp == timestamp) then
		-- no match, bail early
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- Heartbeat message
	if request == rTemp.Heartbeat then
		-- note this person as part of the sync
		Recap_UpdateSyncMember(Name, Server, RecapVersion)
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- Accept and Decline messages (only reported to leader)
	if request == rTemp.Accept then
		if rUser.SyncState == "Leader" then
			print(rTemp.Recap..":", Recap_NameOnlyFromCombatant(Name), "("..Server..")", rLocalize.AcceptedSync)
		end
		-- note this person as part of the sync
		Recap_UpdateSyncMember(Name, Server, RecapVersion)
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end
	if request == rTemp.Decline then
		if rUser.SyncState == "Leader" then
			print(rTemp.Recap..":", Recap_NameOnlyFromCombatant(Name), "("..Server..")", rLocalize.DeclinedSync)
		end
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- SkipNextFight message
	if request == rTemp.SkipNextFight then
		-- skip next fight
		rUser.SkipNextFight = true
		print(rTemp.Recap..": ", rLocalize.SkipNextFightBegins)
		if rUser.State=="Active" then
			-- already in a fight, catch up by changing the status light colour to amber
			RecapStatusTexture:SetVertexColor(1,0.75,0)
		end
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end
	-- assert: Reply or Summary or GetSummaries messages only

	if not ((request == rTemp.Reply) or (request == rTemp.Summary) or (request == rTemp.GetSummaries)) then
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- assert: everyone needs to be on the same page for synchronization to work reliably
	-- assert: the All Fights panel is stable from the end of one fight until just before the accumulation at the end of the next fight
	-- assert: we're going to be extra cautious, and only process and respond to updates until the beginning of the next fight
	-- assert: short inter-fight gaps will probably mean incomplete synchronization

	-- if we're in combat, remember the data for later on (whether Summary or Reply) (overwrites any earlier memo)
	if rUser.State == "Active" then
		Recap_RememberSyncData(timestamp, Name, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags)
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- Reply messages
	if request == rTemp.Reply then
		-- ignore any possible new leader information from a Reply in case it is stale-dated
		Recap_ProcessReply(Name, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags)
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end
	-- assert: Summary or GetSummaries messages only

	if not ((request == rTemp.Summary) or (request == rTemp.GetSummaries)) then
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- check for new leader (important to have right if we are replying to a GetSummaries)
	if not (rUser.SyncLeader == leader) then
		-- new leader (if we were the Leader, we silently become a Member)
		rUser.SyncState = "Member"
		rUser.SyncLeader = leader
		rUser.SyncLeaderName = Recap_SyncExtractNameGUID(leader)
		rUser.SyncLeaderServer = Recap_SyncExtractServer(leader)
		Recap_SetSyncDisplay()
	end

	-- GetSummaries messages
	if request == rTemp.GetSummaries then
		-- send our own standard Summary event as requested
		Recap_SendSummary() -- be sure not to claim that we are a new leader
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end
	-- assert: Summary messages only

	if not (request == rTemp.Summary) then
		rTemp.OnCommReceived = false -- unlock OnCommReceived event
		return
	end

	-- and finally, process the Summary update
	Recap_ProcessSummary(Name, Time, TimeIn, TimeHeal, DmgOut, DmgIn, RawHeal, OverHeal, MaxHit, Deaths, Seen, Flags)

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_CheckJoinSync()
	-- see if there is an outstanding invitation to a synchronization that we saved during combat
	-- called immediately after EndFight

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	if rUser.SyncState == "Ignore" then
		-- we're ignoring synchronization
		return
	end

	if (rUser.State == "Stopped") or (rUser.State == "Active") then
		-- we are paused or in combat
		return
	end

	if not (rTemp.SyncInviteTimestamp and rTemp.SyncInviteLeader and rTemp.SyncInviteLeaderName and rTemp.SyncInviteLeaderServer and rTemp.SyncInviteLeaderRecapVersion and rTemp.SyncInviteMergePets and rTemp.SyncInviteWhen and rTemp.SyncInviteNewOngoing) then
		-- paranoia check that the saved invite info is present and complete
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then return end
	rTemp.OnCommReceived = true

	if (GetTime()-(rTemp.SyncInviteWhen/1000)) <= 180 then
		-- within the time limit (in seconds)
		-- pop the question (we were out of combat when Recap_CheckJoinSync was called)
		local timestamp, leader, name, server, recapVersion, mergePets, newOngoing
		timestamp = rTemp.SyncInviteTimestamp
		leader = rTemp.SyncInviteLeader
		name = rTemp.SyncInviteLeaderName
		server = rTemp.SyncInviteLeaderServer
		recapVersion = rTemp.SyncInviteLeaderRecapVersion
		mergePets = rTemp.SyncInviteMergePets
		newOngoing = rTemp.SyncInviteNewOngoing
		rTemp.SyncInviteTimestamp = false
		rTemp.SyncInviteLeader = false
		rTemp.SyncInviteLeaderName = false
		rTemp.SyncInviteLeaderServer = false
		rTemp.SyncInviteLeaderRecapVersion = false
		rTemp.SyncInviteMergePets = false
		rTemp.SyncInviteWhen = false
		rTemp.SyncInviteNewOngoing = false
		rTemp.AskingJoinSync = true
		Recap_AskJoinSync(timestamp, leader, mergePets, name, server, recapVersion, newOngoing)
	end

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_CheckSendSyncSummary()
	-- see if we as leader need to broadcast a Summary
	-- called immediately after EndFight

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	if not (rUser.SyncState == "Leader") then
		-- bail if not Leader
		return
	end

	if (rUser.State == "Active") then
		-- we are in combat
		return
	end

	if rUser.SkipNextFight == true then
		-- we've been skipping this fight, so don't send a summary
		return
	end

	if math_max(1+GetNumSubgroupMembers(),GetNumGroupMembers()) == 1 then
		-- we're not in a group, skip the summary (can still send one manually)
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then return end
	rTemp.OnCommReceived = true

	-- ongoing invite (i.e. this is not a new synch)
	Recap_SendOngoingInvite()

	-- do it
	Recap_SendSummary()

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_CheckProcessSyncData()
	-- see if we need to process any remembered updates that were saved during combat
	-- could include Summary or Reply data, and we treat both kinds of update data as if it were Summary data (so in this case we might Reply to a Reply)
	-- called immediately after EndFight

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local Name, i, iName

	if ((rUser.SyncState == "Ignore") or (rUser.SyncState == "Ready")) then
		-- we're not in synchronization
		return
	end

	if (rUser.State == "Active") then
		-- we are in combat
		return
	end

	-- lock OnCommReceived event
	if rTemp.OnCommReceived == true then return end
	rTemp.OnCommReceived = true

	-- scan for saved SyncData
	for Name, iName in pairs(rTemp.SyncData) do
		if iName.Timestamp then
			-- data present
			if iName.Timestamp == rUser.SyncTimestamp then
				-- data matches our timestamp (paranoia check)
				if (GetTime()-(iName.When/1000)) <= 180 then
					-- within the time limit (in seconds)
					Recap_ProcessSummary(Name, iName.Time, iName.TimeIn, iName.TimeHeal,
										iName.DmgOut, iName.DmgIn, iName.RawHeal,
										iName.OverHeal, iName.MaxHit, iName.Deaths, iName.Seen, iName.Flags)
				end
			end
		end
		-- clear the data
		for i in pairs(iName) do
			iName[i] = nil
		end
	end

	-- unlock OnCommReceived event
	rTemp.OnCommReceived = false
end

function Recap_SendSyncHeartbeat()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local textToSend, distribution

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	textToSend = Recap:Serialize(rTemp.Heartbeat, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets,
						   rTemp.PlayerGUID, rTemp.Server, Recap_Version)
	Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")
end

function Recap_WarnNotAllowedDuringSync()
	local rTemp = _G.recap_temp
	StaticPopupDialogs["rTemp.NOTDURINGSYNC"] = {
		text = rLocalize.NotAllowedDuringSync,
		button1 = OKAY,
		OnAccept = function(self)
		end,
		timeout = 30,
		showAlert = 1,
		whileDead = 1
	}
	StaticPopup_Show("rTemp.NOTDURINGSYNC")
end

function Recap_ListSyncMembers()

	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local list_time, i, index, iMember, inactive

	list_time = GetTime()
	index = 0
	print(rTemp.Recap..":", rLocalize.SyncMembers)
	-- three passes
	-- first calculate time ago in seconds
	for i, iMember in pairs(rTemp.SyncMembers) do
		iMember.Ago = list_time-(iMember.When/1000)
	end
	-- second list members active within the past ten seconds
	for i, iMember in pairs(rTemp.SyncMembers) do
		if iMember.Ago <= 10 then
			index = index + 1
			print(rTemp.Recap..":", tostring(index)..":", Recap_NameOnlyFromCombatant(iMember.Name), "("..iMember.Server..")", "["..tostring(iMember.RecapVersion).."]", rLocalize.LastUpdateWas, Recap_FormatTime(list_time-(iMember.When/1000)), rLocalize.Ago)
		end
	end
	-- third list members not active within the past ten seconds
	inactive = false
	for i, iMember in pairs(rTemp.SyncMembers) do
		if iMember.Ago > 10 then
			index = index + 1
			if inactive == false then
				inactive = true
				print(rTemp.Recap..": ", rLocalize.InactiveSyncMembers)
			end
			print(rTemp.Recap..":", tostring(index)..":", Recap_NameOnlyFromCombatant(iMember.Name), "("..iMember.Server..")", "["..tostring(iMember.RecapVersion).."]", rLocalize.LastUpdateWas, Recap_FormatTime(list_time-(iMember.When/1000)).." "..rLocalize.Ago)
		end
	end
end

-- remove from the list members who have not been active within the past ten seconds
function Recap_SyncClearInactiveMembers()

	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local list_time, i, j, iMember

	list_time = GetTime()
	-- calculate time ago in seconds
	for i, iMember in pairs(rTemp.SyncMembers) do
		iMember.Ago = list_time-(iMember.When/1000)
	end
	-- delete members not active within the past ten seconds
	j = 0
	for i, iMember in pairs(rTemp.SyncMembers) do
		if iMember.Ago > 10 then
			rTemp.SyncMembers[i] = nil
			j = j + 1
		end
	end
	print(rTemp.Recap..": ", tostring(j), rLocalize.InactiveSyncMembers, rLocalize.Removed)
end

-- skip the next fight (or the rest of the current one if already in combat)
-- TODO: maybe: at the moment this message is sent once, so would not be received by someone in sync who happened to be offline at the time
-- TODO: maybe: there is no way at the moment to directly cancel a Skip
function Recap_SkipNextFight()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	-- bail if we haven't actually initialized data yet
	if (rTemp.FlagDataInitializationCompleted == false) then
		return
	end

	local textToSend, distribution

	if (rUser.State == "Stopped") then
		-- we've got Recap turned off at the moment
		PlaySound("igQuestFailed")
		return
	end

	-- paranoia check
	if (rUser.SyncState == "Member") then
		-- bail if Member
		PlaySound("igQuestFailed")
		return
	end

	-- skip our own next fight (works for people not in sync)
	rUser.SkipNextFight = true
	print(rTemp.Recap..": ", rLocalize.SkipNextFightBegins)
	if rUser.State=="Active" then
		-- already in a fight, catch up by changing the status light colour to amber
		RecapStatusTexture:SetVertexColor(1,0.75,0)
	end

	-- preceding code works in all situations
	-- following code only applies when in sync

	distribution = GetCurrentGroupDistribution()
	if distribution == nil then
		-- not in bg or raid or party, bail
		return
	end

	if (rUser.SyncState == "Leader") then
		-- if Leader of a sync, tell others to skip next fight

		-- lock OnCommReceived event
		if rTemp.OnCommReceived == true then
			PlaySound("igQuestFailed")
			return
		end
		rTemp.OnCommReceived = true

		textToSend = Recap:Serialize(rTemp.SkipNextFight, Recap_Sync_Version, rUser.SyncTimestamp, rUser.SyncLeader, rUser.SyncMergePets)
		Recap:SendCommMessage("Recap", textToSend, distribution, nil, "ALERT")

		-- unlock OnCommReceived event
		rTemp.OnCommReceived = false
	end
end

function Recap_SyncExtractServer(nameServer)
	local _, server
	-- format is name_GUID_server
	_, _, server = string_find(nameServer, "^.+_(.-)$")
	return server
end

RecapSync_lua_4773 = true
