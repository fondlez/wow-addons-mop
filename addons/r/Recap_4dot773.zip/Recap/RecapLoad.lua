﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ RecapLoad.lua (functions for a popup panel for loaded data sets) ]]

local math_max = _G.math.max
local math_min = _G.math.min
local string_format = _G.string.format
local string_gsub = _G.string.gsub
local table_remove = _G.table.remove
local table_sort = _G.table.sort
local pairs = _G.pairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ local tables ]]

local dockoffset = { ["TOPRIGHTTOPLEFT"] = { x=-4,y=0 },
					 ["BOTTOMRIGHTBOTTOMLEFT"] = { x=-4,y=0 },
					 ["TOPLEFTTOPRIGHT"] = { x=4,y=0 },
					 ["BOTTOMLEFTBOTTOMRIGHT"] = { x=4,y=0 },
					 ["TOPRIGHTBOTTOMRIGHT"] = { x=0,y=-4 },
					 ["BOTTOMRIGHTTOPRIGHT"] = { x=0,y=4 },
					 ["TOPLEFTBOTTOMLEFT"] = { x=0,y=-4 },
					 ["BOTTOMLEFTTOPLEFT"] = { x=0,y=4 } }

-- colors for the gauges (also defines what can be gauged)
local gaugecolor = { ["DmgIn"] = { 0.66,0.25,0.25 }, ["DmgOut"] = { 0.25,0.66,0.35 }, ["Heal"] = { 0.25,0.5,0.85 },
					 ["Time"] = { 0.25,0.66,0.35 }, ["Deaths"] = { 0.75,0.75,0.75 }, ["MaxHit"] = { 0.25,0.66,0.35 },
					 ["DPS"] = { 0.25,0.66,0.35 }, ["DPSPerGear"] = { 0.25,0.66,0.35 }, ["Over"] = { 0.25,0.5,0.85 },
					 ["TimeIn"] = { 0.66,0.25,0.25 }, ["TimeHeal"] = { 0.25,0.5,0.85 }, ["DPSIn"] = { 0.66,0.25,0.25 },
					 ["HPS"] = { 0.25,0.5,0.85 }, ["Dispels"] = { 0.85,0.85,0.85 }, ["Interrupts"] = { 0.85,0.85,0.85 } }


--[[ local functions (precede first use) ]]

local function RecapLoad_SetButtons()

	RecapLoadCloseButton:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
	RecapLoadCloseButton:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")

end

local function RecapLoad_TitleBar()

	local rTemp = _G.recap_temp
	local cx, text

	cx = RecapLoad:GetWidth()
	if cx then
		if cx>260 then
			text = rLocalize.DataSet..": "..rTemp.LoadedDataSet
		else
			text = rTemp.LoadedDataSet
		end
	else
		text = rTemp.LoadedDataSet
	end

	RecapLoadTitle:SetText(text)
	RecapLoadView:Show()
end

local function RecapLoad_SetTitleBackground()

	RecapLoadTitleBack:SetVertexColor(.66,0,0)
	RecapLoadTitleBack:Show()
end

-- this resizes the window width to the columns defined in options
-- this calls SetView which in turn calls ConstructLoadList
local function RecapLoad_SetColumns()

	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, j, cx, item, subitem, iOpt
	local recentWidth = 55

	cx = rTemp.ScrollAndEdgeWidth + rTemp.NameWidth

	-- general view
	for i in pairs(rOpt) do
		iOpt = rTemp.DefaultOpt[i]
		if iOpt and iOpt.width then
			if rOpt[i].value then
				-- column will appear
				item = _G["RecapLoadHeader_"..i]
				item:SetWidth(iOpt.width)
				item:Show()
				item = _G["RecapLoadTotals_"..i]
				item:SetWidth(iOpt.width)
				item:Show()
				-- Faction and Level always show and hide together
				if i == "Faction" then
					-- split the width (hardcoded numbers)
					item:SetWidth(14)
					subitem = _G["RecapLoadTotals_Level"]
					subitem:SetWidth(18)
					subitem:Show()
				end
				for j=1,15 do
					item = _G["RecapLoadList"..j.."_"..i]
					item:SetWidth(iOpt.width)
					item:Show()
					-- Faction and Level always show and hide together
					if i == "Faction" then
						-- split the width (hardcoded numbers)
						item:SetWidth(14)
						subitem = _G["RecapLoadList"..j.."_Level"]
						subitem:SetWidth(18)
						subitem:Show()
					end
				end
				cx = cx + iOpt.width
			else
				-- column will not appear
				item = _G["RecapLoadHeader_"..i]
				item:SetWidth(1)
				item:Hide()
				-- Ranks, Faction, Class, and Level column fix (see below)
				if (i == "Ranks") or (i == "Faction") or (i == "Class") then
					item:Show()
				end
				-- there is no header for Level
				item = _G["RecapLoadTotals_"..i]
				item:SetWidth(1)
				item:Hide()
				-- Ranks, Faction, Class, and Level column fix (see below)
				if (i == "Ranks") or (i == "Faction") or (i == "Class") then
					item:Show()
				end
				-- Faction and Level always show together
				if i == "Faction" then
					subitem = _G["RecapLoadTotals_Level"]
					subitem:SetWidth(1)
					subitem:Show()
					cx = cx + 1 -- two columns here, not just one
				end
				for j=1,15 do
					item = _G["RecapLoadList"..j.."_"..i]
					item:SetWidth(1)
					item:Hide()
					-- Ranks, Faction, Class, and Level column fix
					--   To fix a display bug these columns always appear, even if
					--   only blank (or transparent black) and one column wide.
					--   See also RecapLoadScrollBar_Update and RecapLoad_ConstructList.
					if (i == "Ranks") or (i == "Faction") or (i == "Class") then
						item:Show()
					end
					-- Faction and Level always show together
					if i == "Faction" then
						subitem = _G["RecapLoadList"..j.."_Level"]
						subitem:SetWidth(1)
						subitem:Show()
					end
				end
				cx = cx + 1
			end
		end
	end

	for i=1,15 do
		_G["RecapLoadList"..i]:Show()
		_G["RecapLoadList"..i]:SetWidth(cx - rTemp.ScrollAndEdgeWidth + 6) -- extra 6 since it doesn't seem quite wide enough
	end

	RecapLoadTotals:Show()
	RecapLoadGroupTotalButton_Text:SetTextColor(unpack(rColor.Green))
	RecapLoadGroupTotalButton:Show()
	RecapLoadNonGroupTotalButton_Text:SetTextColor(unpack(rColor.White))
	RecapLoadNonGroupTotalButton:Show()
	RecapLoadHeader_Name:Show()

	-- the name slot on the Total line is much narrower
	RecapLoadTotals_Name:SetWidth(rTemp.NameWidth-102)
	RecapLoadTotals:SetWidth(cx-142)

	if rOpt.GrowLeftwards.value and RecapLoad then
		i = RecapLoad:GetRight()
		j = RecapLoad:GetTop()
		if i and j then
			RecapLoad:ClearAllPoints()
			RecapLoad:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(i-cx-rTemp.RecentButtonWidth,0),math_max(j,0)) -- *** i not defined sometimes :( **  [ if frame has not been dragged since reloadui ]
		else
			-- default behaviour if any undefined
			RecapLoad:ClearAllPoints()
			RecapLoad:SetPoint("CENTER","UIParent","CENTER")
		end
	end

	RecapLoadTopBar:SetWidth(cx-8+rTemp.RecentButtonWidth)
	RecapLoadBottomBar:SetWidth(cx-16+rTemp.RecentButtonWidth)
	RecapLoad:SetWidth(cx+rTemp.RecentButtonWidth)
	RecapLoadScrollBar:SetWidth(cx-16+rTemp.RecentButtonWidth)

	rTemp.LoadGaugeWidth = cx - rTemp.ScrollAndEdgeWidth - 12 -
								( ((((rOpt.Faction.value and rOpt.Faction.width) or 1) +
									((rOpt.Class.value and rOpt.Class.width) or 1) +
									((rOpt.Ranks.value and rOpt.Ranks.width) or 1)) or 0) or 0)

	RecapLoad_SetView()
	RecapLoadScrollBar_Update()

end

local function RecapLoad_SetHeight(newcy)

	local rOpt = _G.recap_temp.Opt
	local i,j

	if rOpt.GrowUpwards.value and RecapLoad then
		i = RecapLoad:GetBottom()
		j = RecapLoad:GetLeft()
		if i and j then
			RecapLoad:ClearAllPoints()
			RecapLoad:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(j,0),math_max(i+newcy,0))
		else
			-- default behaviour if any undefined
			RecapLoad:ClearAllPoints()
			RecapLoad:SetPoint("CENTER","UIParent","CENTER")
		end
	end

	RecapLoad:SetHeight(newcy)

end

local function RecapLoad_SetClassIcon(id,class)

	local rTemp = _G.recap_temp
	local item

	item = _G["RecapLoadList"..id.."_Class"]
	if class and rTemp.ClassIcons[class] then
		item:SetTexCoord(rTemp.ClassIcons[class].left,rTemp.ClassIcons[class].right,rTemp.ClassIcons[class].top,rTemp.ClassIcons[class].bottom)
	else
		item:SetTexCoord(.9,1,.9,1)
	end
end

local function RecapLoad_SetFactionIcon(id,faction)

	local rTemp = _G.recap_temp
	local item

	item = _G["RecapLoadList"..id.."_Faction"]
	if faction and rTemp.FactionIcons[faction] then
		item:SetTexture(rTemp.FactionIcons[faction])
	else
		item:SetTexture("")
	end
end

--[[ Initialization ]]

local function RecapLoad_DefineGauges()

	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, thisCombatant

	rTemp.LoadGaugeMax = 0

	if rTemp.LoadListSize>1 then
		rTemp.LoadGaugeBy = string_gsub(rTemp.LoadSortBy,"P$","")
		rTemp.LoadGaugeBy = rTemp.LoadGaugeBy=="DPSvsAll" and "DmgOut" or rTemp.LoadGaugeBy
		if not gaugecolor[rTemp.LoadGaugeBy] then
			rTemp.LoadGaugeBy = false
		else
			for i=1,rTemp.LoadListSize-1 do
				thisCombatant = rTemp.LoadList[i].Name
				if thisCombatant and rLoad[thisCombatant] and rLoad[thisCombatant].Friend and rTemp.LoadGaugeBy then
					rTemp.LoadGaugeMax = math_max(rTemp.LoadList[i][rTemp.LoadGaugeBy],rTemp.LoadGaugeMax)
				end
			end
			for i=1,15 do
				_G["RecapLoadList"..i.."_Gauge"]:SetVertexColor(unpack(gaugecolor[rTemp.LoadGaugeBy]))
			end
		end
	end
end

local function RecapLoad_GetSelectedByName(name)

	local rTemp = _G.recap_temp
	local sel, i = 0
	local thisCombatant

	if name and rTemp.LoadListSize>1 then
		for i=1,rTemp.LoadListSize-1 do
			thisCombatant = rTemp.LoadList[i].Name
			if thisCombatant and (thisCombatant==name) then
				sel = i
			end
		end
	end

	return sel
end

--[[ Sorting functions ]]

local function RecapLoad_SortDown(e1,e2)
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	if rTemp.LoadSortBy=="Class" then
		-- special case for Class, which is an icon ('texture')
		local c1 = rLoad[e1.Name]
		local c2 = rLoad[e2.Name]
		if not (c1 and c1.Class) and (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return false
		end
		if (c1 and c1.Class) and not (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return true
		end
		if c1 and c2 and c1.Class and c2.Class then
			if ( c1.Class < c2.Class ) then
				return true
			else
				return false
			end
		else
			return false
		end
	elseif rTemp.LoadSortBy=="Name" then
		-- special case for Name, which we need without GUIDs, and for which we sort identical names in "First Seen" order
		if e1.Name and e2.Name then
			local e1Name = Recap_StripGUIDsFromCombatant(e1.Name)
			local e2Name = Recap_StripGUIDsFromCombatant(e2.Name)
			if ( e1Name < e2Name ) then
				return true
			elseif ( e1Name == e2Name ) then
				if e1.Seen and e2.Seen then
					if ( e1.Seen < e2.Seen ) then
						return true
					else
						return false
					end
				else
					return false
				end
			else
				return false
			end
		else
			return false
		end
	else
		if e1[rTemp.LoadSortBy] and e2[rTemp.LoadSortBy] then
			-- bypass a problem with mixed strings and numbers
			if type(e1[rTemp.LoadSortBy]) == type(e2[rTemp.LoadSortBy]) then
				-- types match, normal compare
				if ( e1[rTemp.LoadSortBy] < e2[rTemp.LoadSortBy] ) then
					return true
				else
					return false
				end
			else
				-- types don't match, force string compare
				-- this may be due to a damaged saved variables file, but bypass it anyway
				if ( tostring(e1[rTemp.LoadSortBy]) < tostring(e2[rTemp.LoadSortBy]) ) then
					return true
				else
					return false
				end
			end
		else
			return false
		end
	end

end

local function RecapLoad_SortUp(e1,e2)
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	if rTemp.LoadSortBy=="Class" then
		-- special case for Class, which is an icon ('texture')
		local c1 = rLoad[e1.Name]
		local c2 = rLoad[e2.Name]
		if not (c1 and c1.Class) and (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return false
		end
		if (c1 and c1.Class) and not (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return true
		end
		if c1 and c2 and c1.Class and c2.Class then
			if ( c1.Class > c2.Class ) then
				return true
			else
				return false
			end
		else
			return false
		end
	elseif rTemp.LoadSortBy=="Name" then
		-- special case for Name, which we need without GUIDs, and for which we sort identical names in "First Seen" order
		if e1.Name and e2.Name then
			local e1Name = Recap_StripGUIDsFromCombatant(e1.Name)
			local e2Name = Recap_StripGUIDsFromCombatant(e2.Name)
			if ( e1Name > e2Name ) then
				return true
			elseif ( e1Name == e2Name ) then
				if e1.Seen and e2.Seen then
					if ( e1.Seen > e2.Seen ) then
						return true
					else
						return false
					end
				else
					return false
				end
			else
				return false
			end
		else
			return false
		end
	else
		if e1[rTemp.LoadSortBy] and e2[rTemp.LoadSortBy] then
			-- bypass a problem with mixed strings and numbers
			if type(e1[rTemp.LoadSortBy]) == type(e2[rTemp.LoadSortBy]) then
				-- types match, normal compare
				if ( e1[rTemp.LoadSortBy] > e2[rTemp.LoadSortBy] ) then
					return true
				else
					return false
				end
			else
				-- types don't match, force string compare
				-- this may be due to a damaged saved variables file, but bypass it anyway
				if ( tostring(e1[rTemp.LoadSortBy]) > tostring(e2[rTemp.LoadSortBy]) ) then
					return true
				else
					return false
				end
			end
		else
			return false
		end
	end

end

-- perform stable insertion sort on the list
local function RecapLoad_SortFriends()

	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, j, iList, other

	if rTemp.LoadListSize>2 then
		for i=2,(rTemp.LoadListSize-1) do
			iList = rTemp.LoadList[i]
			if (iList) and (iList.Name) and (rLoad[iList.Name]) and (rLoad[iList.Name].Friend) then
				j=i
				while (j>1) do
					other = rTemp.LoadList[j-1]
					if (other) and (other.Name) and (rLoad[other.Name]) and (not rLoad[other.Name].Friend) then
						rTemp.LoadList[j] = other
						j = j - 1
					else
						break
					end
				end
				rTemp.LoadList[j] = iList
			end
		end
	end

end

-- initial sort by field done with table.sort for speed, then
-- friends shifted to top with an insertion sort for "stable" list
local function RecapLoad_SortList()

	local rTemp = _G.recap_temp
	local temp, tempname

	if (rTemp.LoadSelected ~= 0) and (rTemp.LoadSelected ~= rTemp.GroupIndex) and (rTemp.LoadSelected ~= rTemp.NonGroupIndex) then
		tempname = rTemp.LoadList[rTemp.LoadSelected].Name
	else
		-- nil for Group total or Non-Group total
		tempname = nil
	end

	-- remember the last ('Total') element
	temp = rTemp.LoadList[rTemp.LoadListSize]

	-- remove the last element from the 'List' table in case it could confuse 'table.sort'
	table_remove(rTemp.LoadList) -- without second parameter this defaults to last element

	if rTemp.LoadSortBy then
		if rTemp.LoadSortDir then
			table_sort(rTemp.LoadList,RecapLoad_SortDown)
		else
			table_sort(rTemp.LoadList,RecapLoad_SortUp)
		end
		RecapLoad_SortFriends()
	end

	-- restore the last ('Total') element
	rTemp.LoadList[rTemp.LoadListSize] = temp

	RecapLoad_DefineGauges()
	rTemp.LoadSelected = RecapLoad_GetSelectedByName(tempname)

end

local function RecapLoad_CombatantIsTrash(thisCombatant)

	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, count, name, owner

	-- shortcuts
	if rLoad[thisCombatant].Friend then -- redundant check, call it paranoia
		return false
	end
	if rLoad[thisCombatant].Trash == false then
		-- marked as not trash, take that as definitive
		return false
	end
	if rLoad[thisCombatant].Level and tonumber(rLoad[thisCombatant].Level)==-1 then
		-- if this is a high level boss (level is -1) then mark it as not trash
		rLoad[thisCombatant].Trash = false
		return false
	end
	if rLoad[thisCombatant].Trash == true then
		-- marked as trash, but if it is a pet of a combatant who is marked as not trash, change the pet to not trash also
		owner = Recap_ExtractOwner(thisCombatant)
		if owner and rLoad[owner] and (rLoad[owner].Trash ~= nil) and (rLoad[owner].Trash == false) then
			rLoad[thisCombatant].Trash = false
			return false
		end
		return true
	end

	-- we don't know about this combatant, count the hard way
	count = 0
	name = Recap_NameOnlyFromCombatant(thisCombatant)
	for i in pairs(rLoad) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			if (Recap_NameOnlyFromCombatant(i) == name) then
				count = count + 1
				if count > 1 then
					-- we have found more than one of this combatant, mark this one as trash
					rLoad[i].Trash = true
					-- we carry on looping to mark any others
					-- the first one we found may not be marked yet
				end
			end
		end
	end

	if count > 1 then
		rLoad[thisCombatant].Trash = true
		return true
	else
		-- only found one, and can't tell whether it is trash or not
		return false
	end
end

local function RecapLoad_ClearGrandTotal(thisTotal)

	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	if type(rLoad[thisTotal]) == "table" then
		rLoad[thisTotal] = wipe(rLoad[thisTotal])
	else
		rLoad[thisTotal] = {}
	end
	if thisTotal == rTemp.GroupTotal then
		rLoad[thisTotal].Friend = true
	else
		rLoad[thisTotal].Friend = false
	end
end

local function RecapLoad_AccumulateDetails(iTotalDetail, iDetail)

	local j, jDetail

	if iDetail then
		for j, jDetail in pairs(iDetail) do
			if (j == "Effect") then
				-- ignore entirely
			elseif (j == "Element") then
				-- fancy merge
				iTotalDetail[j] = Recap_MergeEntries(iTotalDetail[j], jDetail)
			elseif (j == "SpellID") then
				-- fancy merge
				iTotalDetail[j] = Recap_MergeEntries(iTotalDetail[j], jDetail)
			elseif (j == "Attribute") then
				-- direct copy (not a composite string)
				iTotalDetail[j] = jDetail
			elseif (j == "PrevTime") or (j == "PrevTimeDur") then
				-- ignore
			elseif (j == "GlancesMin") or (j == "HitsMin") or (j == "TicksMin") or (j == "CritsMin") or (j == "CrushMin") then
				-- minima
				iTotalDetail[j] = Recap_Min(iTotalDetail[j], jDetail)
			elseif (j == "GlancesMax") or (j == "HitsMax") or (j == "TicksMax") or (j == "CritsMax") or (j == "CrushMax") then
				-- maxima
				iTotalDetail[j] = math_max((iTotalDetail[j] or 0), jDetail)
			else
				-- everything else is a straight sum
				iTotalDetail[j] = (iTotalDetail[j] or 0) + jDetail
			end
		end
	end
end

local function RecapLoad_AccumulateGrandTotal(thisTotal, thisCombatant, LoadOutgoingDetail, LoadIncomingDetail, LoadOtherDetail)

	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, j, iTotal, iCombatant

	iTotal = rLoad[thisTotal]
	iCombatant = rLoad[thisCombatant]

	-- accumulate across all combatants into a single hidden combatant named "Group Total"
	if iCombatant[LoadOutgoingDetail] then
		for i in pairs(iCombatant[LoadOutgoingDetail]) do
			if not iTotal[LoadOutgoingDetail] then
				iTotal[LoadOutgoingDetail] = {}
			end
			if not iTotal[LoadOutgoingDetail][i] then
				iTotal[LoadOutgoingDetail][i] = {}
			end
			RecapLoad_AccumulateDetails(iTotal[LoadOutgoingDetail][i], iCombatant[LoadOutgoingDetail][i])
		end
	end
	if iCombatant[LoadIncomingDetail] then
		for i in pairs(iCombatant[LoadIncomingDetail]) do
			if not iTotal[LoadIncomingDetail] then
				iTotal[LoadIncomingDetail] = {}
			end
			if not iTotal[LoadIncomingDetail][i] then
				iTotal[LoadIncomingDetail][i] = {}
			end
			RecapLoad_AccumulateDetails(iTotal[LoadIncomingDetail][i], iCombatant[LoadIncomingDetail][i])
		end
	end
	if iCombatant[LoadOtherDetail] then
		for i in pairs(iCombatant[LoadOtherDetail]) do
			if not iTotal[LoadOtherDetail] then
				iTotal[LoadOtherDetail] = {}
			end
			if not iTotal[LoadOtherDetail][i] then
				iTotal[LoadOtherDetail][i] = {}
			end
			RecapLoad_AccumulateDetails(iTotal[LoadOtherDetail][i], iCombatant[LoadOtherDetail][i])
		end
	end

	-- include some total values
	j = (iTotal.TotalTime or 0) + (iCombatant.TotalTime or 0)
	if j>0 then
		iTotal.TotalTime = j
	end
	j = (iTotal.TotalTimeIn or 0) + (iCombatant.TotalTimeIn or 0)
	if j>0 then
		iTotal.TotalTimeIn = j
	end
	j = (iTotal.TotalTimeHeal or 0) + (iCombatant.TotalTimeHeal or 0)
	if j>0 then
		iTotal.TotalTimeHeal = j
	end
	j = math_max((iTotal.TotalMaxHit or 0), (iCombatant.TotalMaxHit or 0))
	if j>0 then
		iTotal.TotalMaxHit = j
	end
	j = (iTotal.TotalDeaths or 0) + (iCombatant.TotalDeaths or 0)
	if j>0 then
		iTotal.TotalDeaths = j
	end
	j = (iTotal.TotalDispels or 0) + (iCombatant.TotalDispels or 0)
	if j>0 then
		iTotal.TotalDispels = j
	end
	j = (iTotal.TotalInterrupts or 0) + (iCombatant.TotalInterrupts or 0)
	if j>0 then
		iTotal.TotalInterrupts = j
	end
	j = (iTotal.TotalRawHeal or 0) + (iCombatant.TotalRawHeal or 0)
	if j>0 then
		iTotal.TotalRawHeal = j
	end
	j = (iTotal.TotalOverHeal or 0) + (iCombatant.TotalOverHeal or 0)
	if j>0 then
		iTotal.TotalOverHeal = j
	end
	j = (iTotal.TotalDmgIn or 0) + (iCombatant.TotalDmgIn or 0)
	if j>0 then
		iTotal.TotalDmgIn = j
	end
	j = (iTotal.TotalDmgOut or 0) + (iCombatant.TotalDmgOut or 0)
	if j>0 then
		iTotal.TotalDmgOut = j
	end
end

local function RecapLoad_DoGrandTotal(thisTotal)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, iCombatant, iTotal

	local LoadOutgoingDetail = "OutgoingDetail"
	local LoadIncomingDetail = "IncomingDetail"
	local LoadOtherDetail = "OtherDetail"

	-- accumulate
	if rTemp.Load then
		for i, iCombatant in pairs(rLoad) do
			if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
				if ((iCombatant.TotalDmgOut==nil or iCombatant.TotalDmgOut==0) and
					(iCombatant.TotalDmgIn==nil or iCombatant.TotalDmgIn==0) and
					(iCombatant.TotalRawHeal==nil or iCombatant.TotalRawHeal==0)) or
				   (rOpt.HideOthers.value and (not iCombatant.Friend)) or
				   (rOpt.HideGroup.value and (not Recap_CheckForSelf(i)) and iCombatant.Friend) or
				   (rOpt.HideYardTrash.value and not iCombatant.Friend and RecapLoad_CombatantIsTrash(i)) or
				   (iCombatant.Ignore) then
					-- ignore unwanted combatants (if-statement code duplicated from earlier)

				else
					if not rOpt.HideZero.value or ((iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime)) or
														(iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime)) or
														(iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime))) then
						if (thisTotal == rTemp.GroupTotal) and iCombatant.Friend then
							-- this is a valid group combatant; add their Outgoing, Incoming, and Other Details to a hidden combatant called "Group Total"
							RecapLoad_AccumulateGrandTotal(thisTotal, i, LoadOutgoingDetail, LoadIncomingDetail, LoadOtherDetail)
						elseif (thisTotal == rTemp.NonGroupTotal) and not iCombatant.Friend then
							-- this is a valid non-group combatant; add their Outgoing, Incoming, and Other Details to a hidden combatant called "Non-Group Total"
							RecapLoad_AccumulateGrandTotal(thisTotal, i, LoadOutgoingDetail, LoadIncomingDetail, LoadOtherDetail)
						end
					end
				end
			end
		end
	end

	-- per second values
	iTotal = rLoad[thisTotal]
	if iTotal.TotalTime and (iTotal.TotalTime > rTemp.MinTime) and ((iTotal.TotalDmgOut or 0) > 0) then
		iTotal.TotalDPS = Recap_Div1((iTotal.TotalDmgOut or 0), iTotal.TotalTime)
	end
	if iTotal.TotalTimeIn and (iTotal.TotalTimeIn > rTemp.MinTime) and ((iTotal.TotalDmgIn or 0) > 0) then
		iTotal.TotalDPSIn = Recap_Div1((iTotal.TotalDmgIn or 0), iTotal.TotalTimeIn)
	end
	if iTotal.TotalTimeHeal and (iTotal.TotalTimeHeal > rTemp.MinTime) and (((iTotal.TotalRawHeal or 0) - (iTotal.TotalOverHeal or 0)) > 0) then
		iTotal.TotalHPS = Recap_Div1(((iTotal.TotalRawHeal or 0) - (iTotal.TotalOverHeal or 0)), iTotal.TotalTimeHeal)
	end

end

local function RecapLoad_PostSpamRows(myType, postFriends)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, text, nLines
	local headertext = nil -- keep as nil
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local iType = string_gsub(myType, "P$","") -- strip trailing P from % ids

	chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
	if chatchan=="Self" then
		print_chat = Recap_Print
	end

	-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
	if Recap_WIMFindFocus() then
		print_chat = Recap_WIM_Print
	end

	-- If the Clipboard is open, post there instead of to chat or console
	if RecapClipEditBox:IsVisible() then
		print_chat = Recap_LineToClipboard
		maxLines = rTemp.MaxLinesToClipboard
	end

	headertext = "__ Recap ("..rLocalize.DataSet..": '"..rTemp.LoadedDataSet.."') ("..Recap_PetsMergedText().."): "..rLocalize.LinkRank[iType].." __"
	nLines = 0
	for i=1, 1000 do
		if rTemp.LoadList[i] and rTemp.LoadList[i].Name then
			local thisCombatant = rTemp.LoadList[i].Name
			if (i<rTemp.LoadListSize) and thisCombatant and rLoad[thisCombatant] and ((rLoad[thisCombatant].Friend and postFriends) or
																					 ((not rLoad[thisCombatant].Friend) and (not postFriends))) then
				text = nil
				if iType == "Name" then
					text = i..". "..Recap_StripGUIDsFromCombatant(thisCombatant)
				else
					if rTemp.LoadList[i][iType] and rTemp.LoadList[i][iType] > 0 then
						local listCombatant = rTemp.LoadList[i]
						local iName = i..". "..Recap_StripGUIDsFromCombatant(thisCombatant)
						text = Recap_FormatNameFirstStat(iName, iType, listCombatant)..Recap_FormatRemainingStats(iType, listCombatant)
					end
				end
				if text then
					if headertext then
						if print_chat(headertext, chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						headertext = nil -- keep as nil
					end
					if print_chat(text, chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					nLines = nLines + 1
					if nLines >= maxLines then
						break
					end
				end
			end
		end
	end

	if RecapClipEditBox:IsVisible() then
		RecapClipEditBox:HighlightText()
		RecapClipEditBox:SetFocus()
	end
end

local function RecapLoad_MoveMinimize()

	RecapLoadCloseButton:ClearAllPoints()
	RecapLoadCloseButton:SetPoint("TOPRIGHT", "RecapLoad", "TOPRIGHT", -6, -6)

end

local function RecapLoad_ConstructList()

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, entry, overallDuration, thisCombatant, iCombatant, iList, iTotal
	local maxhit = 0
	local dmgin = 0
	local dmgout = 0
	local deaths = 0
	local dispels = 0
	local interrupts = 0
	local rawheal = 0
	local overheal = 0
	local duration = 0
	local durationIn = 0
	local durationHeal = 0
	local overallDPS = 0
	local tempname = nil
	local temptotal = 0

	-- remember possible state for Panel
	if rOpt.ShowPanel.value then
		if (rTemp.LoadSelected ~= 0) and (rTemp.LoadSelected ~= rTemp.GroupIndex) and (rTemp.LoadSelected ~= rTemp.NonGroupIndex) then
			tempname = rTemp.LoadList[rTemp.LoadSelected].Name
		else
			temptotal = rTemp.LoadSelected
		end
	end

	overallDuration = rTemp.LoadTotalDuration

	-- clear the 'List' table entirely
	rTemp.LoadListSize = 1
	rTemp.LoadList = wipe(rTemp.LoadList)

	if rTemp.Load then
		for i, iCombatant in pairs(rLoad) do
			if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
				if not rTemp.LoadList[rTemp.LoadListSize] then
					rTemp.LoadList[rTemp.LoadListSize] = {}
				end
				entry = false

				iList = rTemp.LoadList[rTemp.LoadListSize]

				if ((iCombatant.TotalDmgOut==nil or iCombatant.TotalDmgOut==0) and
					(iCombatant.TotalDmgIn==nil or iCombatant.TotalDmgIn==0) and
					(iCombatant.TotalRawHeal==nil or iCombatant.TotalRawHeal==0)) or
				   (rOpt.HideOthers.value and (not iCombatant.Friend)) or
				   (rOpt.HideGroup.value and (not Recap_CheckForSelf(i)) and iCombatant.Friend) or
				   (rOpt.HideYardTrash.value and not iCombatant.Friend and RecapLoad_CombatantIsTrash(i)) or
				   (iCombatant.Ignore) then
					entry = false -- strip out unwanted combatants

				else
					if not rOpt.HideZero.value or ((iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime)) or
														(iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime)) or
														(iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime))) then
						iList.Name = i
						iList.Seen = (iCombatant.Seen or 0)
						iList.Time = (iCombatant.TotalTime or 0)
						iList.TimeIn = (iCombatant.TotalTimeIn or 0)
						iList.TimeHeal = (iCombatant.TotalTimeHeal or 0)
						iList.MaxHit = (iCombatant.TotalMaxHit or 0)
						iList.DmgIn = (iCombatant.TotalDmgIn or 0)
						iList.DmgOut = (iCombatant.TotalDmgOut or 0)
						iList.HPS = (iCombatant.TotalHPS or 0)
						iList.DPSIn = (iCombatant.TotalDPSIn or 0)
						iList.DPS = (iCombatant.TotalDPS or 0)
						-- one hidden variable
						iList.GearValue = iCombatant.GearValue
						if iList.GearValue and (iList.GearValue > 0) then
							iList.DPSPerGear = Recap_Div0(10000 * iList.DPS, iList.GearValue)
						else
							iList.DPSPerGear = 0
						end
						iList.DPSvsAll = (overallDuration>rTemp.MinTime and Recap_Div1((iCombatant.TotalDmgOut or 0), overallDuration)) or 0
						iList.Deaths = (iCombatant.TotalDeaths or 0)
						iList.Dispels = (iCombatant.TotalDispels or 0)
						iList.Interrupts = (iCombatant.TotalInterrupts or 0)
						-- two hidden variables
						iList.RawHeal = (iCombatant.TotalRawHeal or 0)
						iList.OverHeal = (iCombatant.TotalOverHeal or 0)
						-- calculated rather than assigned
						iList.Heal = (iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)
						if iList.RawHeal > 0 then
							iList.Over = Recap_Div0(100*iList.OverHeal, iList.RawHeal)
						else
							iList.Over = 0
						end
						entry = true
					end
				end

				if entry then
					thisCombatant = iList.Name
					if thisCombatant and rLoad[thisCombatant] and rLoad[thisCombatant].Friend then
						duration = duration + iList.Time
						durationIn = durationIn + iList.TimeIn
						durationHeal = durationHeal + iList.TimeHeal
						if iList.MaxHit > maxhit then
							maxhit = iList.MaxHit
						end
						dmgin = dmgin + iList.DmgIn
						dmgout = dmgout + iList.DmgOut
						deaths = deaths + iList.Deaths
						dispels = dispels + iList.Dispels
						interrupts = interrupts + iList.Interrupts
						-- two hidden variables
						rawheal = rawheal + iList.RawHeal
						overheal = overheal + iList.OverHeal
						overallDPS = overallDPS + iList.DPS
					end
					rTemp.LoadListSize = rTemp.LoadListSize + 1
				end
			end
		end
	end

	if not rTemp.LoadList[rTemp.LoadListSize] then
		rTemp.LoadList[rTemp.LoadListSize] = {}
	end

	-- the final entry is the totals
	iTotal = rTemp.LoadList[rTemp.LoadListSize]
	iTotal.Name = rLocalize.Totals
	iTotal.Time = duration
	RecapLoadTotals_Time:SetText(Recap_FormatTime(duration))
	iTotal.TimeIn = durationIn
	RecapLoadTotals_TimeIn:SetText(Recap_FormatTime(durationIn))
	iTotal.TimeHeal = durationHeal
	RecapLoadTotals_TimeHeal:SetText(Recap_FormatTime(durationHeal))
	iTotal.MaxHit = maxhit
	RecapLoadTotals_MaxHit:SetText(maxhit)
	iTotal.DmgIn = dmgin
	RecapLoadTotals_DmgIn:SetText(dmgin)
	iTotal.DmgOut = dmgout
	RecapLoadTotals_DmgOut:SetText(dmgout)
	iTotal.Deaths = deaths
	RecapLoadTotals_Deaths:SetText(deaths)
	iTotal.Dispels = dispels
	RecapLoadTotals_Dispels:SetText(dispels)
	iTotal.Interrupts = interrupts
	RecapLoadTotals_Interrupts:SetText(interrupts)
	-- two hidden variables
	rawheal = Recap_Round0(rawheal) -- paranoia 5.0.4
	overheal = Recap_Round0(overheal) -- paranoia 5.0.4
	iTotal.RawHeal = rawheal
	iTotal.OverHeal = overheal
	-- calculated rather than assigned
	iTotal.Heal = rawheal - overheal
	RecapLoadTotals_Heal:SetText(rawheal - overheal)
	if (iTotal.RawHeal > 0) then
		iTotal.Over = Recap_Div0(100*iTotal.OverHeal,iTotal.RawHeal)
	else
		iTotal.Over = 0
	end
	RecapLoadTotals_Over:SetFormattedText("%d%%",Recap_Round0(iTotal.Over))

	-- three calculations of total group DPS, DPS In, and HPS
	if duration > rTemp.MinTime then
		iTotal.TotDPSOut = Recap_Div1(dmgout,duration)
	else
		iTotal.TotDPSOut = 0
	end
	if durationIn > rTemp.MinTime then
		iTotal.TotDPSIn = Recap_Div1(dmgin,durationIn)
	else
		iTotal.TotDPSIn = 0
	end
	if durationHeal > rTemp.MinTime then
		iTotal.TotHPS = Recap_Div1((rawheal - overheal),durationHeal)
	else
		iTotal.TotHPS = 0
	end

	if iTotal.TotHPS<1000 then
		RecapLoadTotals_HPS:SetFormattedText("%.1f",iTotal.TotHPS)
	else
		RecapLoadTotals_HPS:SetFormattedText("%d",Recap_Round0(iTotal.TotHPS))
	end
	if iTotal.TotDPSIn<1000 then
		RecapLoadTotals_DPSIn:SetFormattedText("%.1f",iTotal.TotDPSIn)
	else
		RecapLoadTotals_DPSIn:SetFormattedText("%d",Recap_Round0(iTotal.TotDPSIn))
	end
	if iTotal.TotDPSOut<1000 then
		RecapLoadTotals_DPS:SetFormattedText("%.1f",iTotal.TotDPSOut)
	else
		RecapLoadTotals_DPS:SetFormattedText("%d",Recap_Round0(iTotal.TotDPSOut))
	end
	RecapLoadTotals_DPSPerGear:SetText("")
	if iTotal.TotDPSOut<1000 then
		RecapLoadTotals_DPSvsAll:SetFormattedText("%.1f",iTotal.TotDPSOut)
	else
		RecapLoadTotals_DPSvsAll:SetFormattedText("%d",Recap_Round0(iTotal.TotDPSOut))
	end

	-- Class column fix set to black, see also RecapLoadScrollBar_Update and RecapLoad_SetColumns.
	RecapLoadTotals_Class:SetTexCoord(.9,1,.9,1)

	-- calculate percentages
	for i=1,rTemp.LoadListSize-1 do
		iList = rTemp.LoadList[i]
		iList.HealP = 0
		iList.DmgInP = 0
		iList.DmgOutP = 0
		thisCombatant = iList.Name
		if thisCombatant and rLoad[thisCombatant] and rLoad[thisCombatant].Friend then
			if iTotal.Heal>0 then
				iList.HealP = Recap_Div0(100*iList.Heal,iTotal.Heal)
			end
			if iTotal.DmgIn>0 then
				iList.DmgInP = Recap_Div0(100*iList.DmgIn,iTotal.DmgIn)
			end
			if iTotal.DmgOut>0 then
				-- give this column an extra digit of significance
				iList.DmgOutP = Recap_Div1(100*iList.DmgOut,iTotal.DmgOut)
			end
		end
	end

	-- two hidden variables for total line only
	iTotal.OverallDuration = overallDuration
	iTotal.OverallDPS = overallDPS

	RecapLoad_SortList()

	-- restore Panel state if possible
	if rOpt.ShowPanel.value then
		if tempname then
			rTemp.LoadSelected = RecapLoad_GetSelectedByName(tempname)
		else
			rTemp.LoadSelected = temptotal
		end
		if (rTemp.PanelSource == "Load") then
			if (rTemp.LoadSelected == 0) then
				-- Panel not valid, make sure it goes away
				RecapPanel_Hide()
			elseif (rTemp.LoadSelected == rTemp.GroupIndex) then
				-- show Group total panel
				RecapLoad_ClearGrandTotal(rTemp.GroupTotal)
				RecapLoad_DoGrandTotal(rTemp.GroupTotal)
				RecapPanel_Show(rTemp.GroupTotal)
			elseif (rTemp.LoadSelected == rTemp.NonGroupIndex) then
				-- show Non-Group total panel
				RecapLoad_ClearGrandTotal(rTemp.NonGroupTotal)
				RecapLoad_DoGrandTotal(rTemp.NonGroupTotal)
				RecapPanel_Show(rTemp.NonGroupTotal)
			else
				-- show combatant panel
				RecapPanel_Show(tempname)
			end
		else
			-- Panel was not for us, do nothing
		end
	end

	RecapLoadScrollBar_Update()

end


--[[ global functions ]]


--[[ Window appearance functions ]]

function RecapLoad_Hide()
	local rTemp = _G.recap_temp
	if not rTemp.Loaded then
		if not Recap_Initialize() then
			return false
		end
	end

	PlaySound("GAMEGENERICBUTTONPRESS")

	-- for loaded data sets, hide implies reset
	RecapPanel_Hide(1)
	RecapLoad_ResetAllCombatants(false)
	rTemp.LoadedDataSet = ""
	rTemp.LoadSelected = 0
	if (rTemp.PanelSource == "Load") then
		RecapPanel_Hide()
		if (rTemp.RecentSource == "Details") then
			RecapRecent_Hide()
		end
	end
	RecapLoad:SetAlpha(1)
	RecapLoad:Hide()
end

function RecapLoad_Show()

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	if not rTemp.Loaded then
		if not Recap_Initialize() then
			return false
		end
	end

	local i, iOpt

	RecapLoad_SetColumns() -- this calls SetView which in turn calls ConstructList

	RecapLoadCloseButton:SetWidth(16)
	RecapLoadCloseButton:Show()

	RecapLoadTopBar:Show()
	RecapLoadBottomBar:Show()

	RecapLoadScrollBar:Show()

	RecapLoadTotals:Show()
	RecapLoadGroupTotalButton:Show()
	RecapLoadNonGroupTotalButton:Show()
	RecapLoadHeader_Name:Show()

	if rOpt.OpaqueBackground.value then
		RecapLoad:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
	else
		RecapLoad:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
	end
	RecapLoad_MoveMinimize()

	RecapLoad:Show()

end

function RecapLoad_SetView()
	local rTemp = _G.recap_temp
	RecapLoad_SetButtons()
	RecapLoad_ConstructList()
	RecapLoad_TitleBar()
	RecapLoadHeader_Name:SetText((rTemp.LoadListSize-1).." "..rLocalize.Combatants)
	RecapLoad_SetTitleBackground()
end

function RecapLoad_SetColors()

	local rColor = _G.recap_temp.Color
	local i

	RecapLoadTotals_DmgIn:SetTextColor(unpack(rColor.DmgIn))
	RecapLoadTotals_DmgOut:SetTextColor(unpack(rColor.DmgOut))
	RecapLoadTotals_HPS:SetTextColor(unpack(rColor.Heal))
	RecapLoadTotals_DPSIn:SetTextColor(unpack(rColor.DmgIn))
	RecapLoadTotals_DPS:SetTextColor(unpack(rColor.DmgOut))
	RecapLoadTotals_DPSPerGear:SetTextColor(unpack(rColor.DmgOut))
	RecapLoadTotals_DPSvsAll:SetTextColor(unpack(rColor.DmgOut))
	RecapLoadTotals_MaxHit:SetTextColor(unpack(rColor.DmgOut))
	RecapLoadTotals_Heal:SetTextColor(unpack(rColor.Heal))
	RecapLoadTotals_Over:SetTextColor(unpack(rColor.Heal))
	RecapLoadTotals_Time:SetTextColor(unpack(rColor.DmgOut))
	RecapLoadTotals_TimeIn:SetTextColor(unpack(rColor.DmgIn))
	RecapLoadTotals_TimeHeal:SetTextColor(unpack(rColor.Heal))
	for i=1,15 do
		_G["RecapLoadList"..i.."_HealP"]:SetTextColor(unpack(rColor.Heal))
		_G["RecapLoadList"..i.."_Over"]:SetTextColor(unpack(rColor.Heal))
		_G["RecapLoadList"..i.."_DmgInP"]:SetTextColor(unpack(rColor.DmgIn))
		_G["RecapLoadList"..i.."_DmgOutP"]:SetTextColor(unpack(rColor.DmgOut))
	end
	RecapLoad_SetTitleBackground()
end

function RecapLoadScrollBar_Update()

	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, j, index, item, item2, item3
	local listsize = rTemp.LoadListSize
	local thisCombatant, iCombatant, iList

	i = 72 + (math_max(math_min(listsize-1,rOpt.MaxRows.value),1 )*14 )
	RecapLoad_SetHeight(i)
	RecapLoadScrollBar:SetHeight(i-63)
	FauxScrollFrame_Update(RecapLoadScrollBar,listsize-1,rOpt.MaxRows.value,14)

	for i=1,rOpt.MaxRows.value do
		index = i + FauxScrollFrame_GetOffset(RecapLoadScrollBar)

		if index < listsize then
			iList = rTemp.LoadList[index]
			thisCombatant = iList.Name
			if thisCombatant then
				iCombatant = rLoad[thisCombatant]
				if iCombatant then
					if rOpt.Ranks.value then
						-- Ranks will appear
						_G["RecapLoadList"..i.."_Ranks"]:SetText(index)
					else
						-- Ranks needs to be set to blank
						_G["RecapLoadList"..i.."_Ranks"]:SetText("")
					end
					if rOpt.Faction.value then
						-- Faction and Level will appear
						RecapLoad_SetFactionIcon(i, iCombatant.Faction)
						if iCombatant.Level and tonumber(iCombatant.Level)>0 then
							_G["RecapLoadList"..i.."_Level"]:SetText(iCombatant.Level)
						elseif iCombatant.Level and tonumber(iCombatant.Level)==-1 then
							_G["RecapLoadList"..i.."_Level"]:SetText("??")
						else
							_G["RecapLoadList"..i.."_Level"]:SetText("")
						end
					else
						-- Faction icon needs to be set to black, and Level to blank
						RecapLoad_SetFactionIcon(i, nil)
						_G["RecapLoadList"..i.."_Level"]:SetText("")
					end
					if rOpt.Class.value then
						-- Class will appear
						RecapLoad_SetClassIcon(i, iCombatant.Class)
					else
						-- Class icon needs to be set to black
						RecapLoad_SetClassIcon(i, nil)
					end

					item = _G["RecapLoadList"..i.."_Name"]
					item:SetText(Recap_StripGUIDsFromCombatant(thisCombatant))
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_Gauge"]
					if rOpt.ShowGauges.value and rTemp.LoadGaugeMax>0 and rTemp.LoadGaugeBy and iCombatant.Friend then
						item:SetWidth(1+rTemp.LoadGaugeWidth*iList[rTemp.LoadGaugeBy]/rTemp.LoadGaugeMax)
						item:Show()
					else
						item:Hide()
					end

					_G["RecapLoadList"..i.."_Seen"]:SetText(Recap_FormatTimeSeen((iList.Seen or 0)/1000))

					_G["RecapLoadList"..i.."_Deaths"]:SetText(iList.Deaths)

					_G["RecapLoadList"..i.."_Dispels"]:SetText(iList.Dispels)

					_G["RecapLoadList"..i.."_Interrupts"]:SetText(iList.Interrupts)

					item = _G["RecapLoadList"..i.."_Time"]
					item:SetText(Recap_FormatTime(iList.Time))
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_DmgOut"]
					item2 = _G["RecapLoadList"..i.."_DmgOutP"]
					item:SetText(iList.DmgOut)
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
						item2:SetText(iList.DmgOutP.."%")
						item2:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
						item2:SetText("")
						item2:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_MaxHit"]
					item:SetText(iList.MaxHit)
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_DPS"]
					if iList.DPS<1000 then
						item:SetFormattedText("%.1f",iList.DPS)
					else
						item:SetFormattedText("%d",Recap_Round1(iList.DPS))
					end
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_DPSPerGear"]
					item:SetFormattedText("%d",iList.DPSPerGear)
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_DPSvsAll"]
					if iList.DPSvsAll<1000 then
						item:SetFormattedText("%.1f",iList.DPSvsAll)
					else
						item:SetFormattedText("%d",Recap_Round1(iList.DPSvsAll))
					end
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgOut))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_TimeIn"]
					item:SetText(Recap_FormatTime(iList.TimeIn))
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgIn))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_DmgIn"]
					item2 = _G["RecapLoadList"..i.."_DmgInP"]
					item:SetText(iList.DmgIn)
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgIn))
						item2:SetText(iList.DmgInP.."%")
						item2:SetTextColor(unpack(rColor.DmgIn))
					else
						item:SetTextColor(unpack(rColor.White))
						item2:SetText("")
						item2:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_DPSIn"]
					if iList.DPSIn<1000 then
						item:SetFormattedText("%.1f",iList.DPSIn)
					else
						item:SetFormattedText("%d",Recap_Round1(iList.DPSIn))
					end
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.DmgIn))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_TimeHeal"]
					item:SetText(Recap_FormatTime(iList.TimeHeal))
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.Heal))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_Heal"]
					item2 = _G["RecapLoadList"..i.."_HealP"]
					item3 = _G["RecapLoadList"..i.."_Over"]
					item:SetText(iList.RawHeal - iList.OverHeal)
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.Heal))
						item2:SetText(iList.HealP.."%")
						item2:SetTextColor(unpack(rColor.Heal))
						item3:SetText(iList.Over.."%")
						item3:SetTextColor(unpack(rColor.Heal))
					else
						item:SetTextColor(unpack(rColor.White))
						item2:SetText("")
						item2:SetTextColor(unpack(rColor.White))
						item3:SetText("")
						item3:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i.."_HPS"]
					if iList.HPS<1000 then
						item:SetFormattedText("%.1f",iList.HPS)
					else
						item:SetFormattedText("%d",Recap_Round1(iList.HPS))
					end
					if iCombatant.Friend then
						item:SetTextColor(unpack(rColor.Heal))
					else
						item:SetTextColor(unpack(rColor.White))
					end

					item = _G["RecapLoadList"..i]
					item:Show()
					if rTemp.LoadSelected == index then
						item:LockHighlight()
					else
						item:UnlockHighlight()
					end
				end
			end
		else
			_G["RecapLoadList"..i]:Hide()
			_G["RecapLoadList"..i]:UnlockHighlight()
		end

		for i=rOpt.MaxRows.value+1,15 do
			_G["RecapLoadList"..i]:Hide()
		end
	end
end


--[[ Window movement functions ]]

function RecapLoad_OnMouseDown(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapLoad:StartMoving()
	end
end

function RecapLoad_OnMouseUp(frame, button)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapLoad:StopMovingOrSizing()

		-- check for docking
		rUser.LoadAnchor.value = false

		if Recap_Near(RecapFrame:GetRight(),RecapLoad:GetLeft()) then
			if Recap_Near(RecapFrame:GetTop(),RecapLoad:GetTop()) then
				rUser.LoadAnchor = { value=true, Main="TOPRIGHT", Load="TOPLEFT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapLoad:GetBottom()) then
				rUser.LoadAnchor = { value=true, Main="BOTTOMRIGHT", Load="BOTTOMLEFT"}
			end
		elseif Recap_Near(RecapFrame:GetLeft(),RecapLoad:GetRight()) then
			if Recap_Near(RecapFrame:GetTop(),RecapLoad:GetTop()) then
				rUser.LoadAnchor = { value=true, Main="TOPLEFT", Load="TOPRIGHT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapLoad:GetBottom()) then
				rUser.LoadAnchor = { value=true, Main="BOTTOMLEFT", Load="BOTTOMRIGHT" }
			end
		elseif Recap_Near(RecapFrame:GetRight(),RecapLoad:GetRight()) then
			if Recap_Near(RecapFrame:GetTop(),RecapLoad:GetBottom()) then
				rUser.LoadAnchor = { value=true, Main="TOPRIGHT", Load="BOTTOMRIGHT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapLoad:GetTop()) then
				rUser.LoadAnchor = { value=true, Main="BOTTOMRIGHT", Load="TOPRIGHT" }
			end
		elseif Recap_Near(RecapFrame:GetLeft(),RecapLoad:GetLeft()) then
			if Recap_Near(RecapFrame:GetTop(),RecapLoad:GetBottom()) then
				rUser.LoadAnchor = { value=true, Main="TOPLEFT", Load="BOTTOMLEFT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapLoad:GetTop()) then
				rUser.LoadAnchor = { value=true, Main="BOTTOMLEFT", Load="TOPLEFT" }
			end
		end

		if rUser.LoadAnchor.value then
			RecapLoad:ClearAllPoints()
			RecapLoad:SetPoint(rUser.LoadAnchor.Load,"RecapFrame",rUser.LoadAnchor.Main,Recap_LoadOffset("x"),Recap_LoadOffset("y"))
		end

	end
end

function Recap_LoadOffset(axis)

	local rUser = _G.recap_user
	local anchor

	anchor = rUser.LoadAnchor.Main..rUser.LoadAnchor.Load
	if dockoffset[anchor] and axis then
		return dockoffset[anchor][axis]
	else
		return 0
	end
end


--[[ Dialog control functions ]]

function RecapLoadHeader_OnEnter(frame)

	local line1,line2

	local header=string_gsub(frame:GetName(),"RecapLoadHeader_","Header")
	if header=="HeaderName" then
		-- special case
		line1,line2 = Recap_GetTooltip("LoadName")
		if line1 and line2 then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostAltTooltip)
		end
	else
		line1,line2 = Recap_GetTooltip(header)
		if line1 and line2 then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostAltTooltip)
		end
	end
end

function RecapLoadHeader_OnMouseUp(frame, button)
end

-- sort column, toggle dir for new headers, name=ascending, rest=descending
function RecapLoadHeader_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local text = ""
	local header = string_gsub(frame:GetName(),"RecapLoadHeader_","")

	if not IsShiftKeyDown() then
		if rTemp.LoadSortBy==string_gsub(header,"P$","") then
			rTemp.LoadSortDir = not rTemp.LoadSortDir
		else
			rTemp.LoadSortBy = string_gsub(header,"P$","")
			if header=="Name" then
				rTemp.LoadSortDir = true
			else
				rTemp.LoadSortDir = false
			end
		end
		RecapLoad_SortList()
		RecapLoadScrollBar_Update()

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and rTemp.LoadListSize>1 then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rTemp.LoadSortBy = header
		if header=="Name" then
			rTemp.LoadSortDir = true
		else
			rTemp.LoadSortDir = false
		end
		RecapLoad_SortList()
		RecapLoadScrollBar_Update()
		RecapLoad_PostSpamRows(header, true)

	elseif IsShiftKeyDown() and IsAltKeyDown() and rTemp.LoadListSize>1 then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rTemp.LoadSortBy = header
		if header=="Name" then
			rTemp.LoadSortDir = true
		else
			rTemp.LoadSortDir = false
		end
		RecapLoad_SortList()
		RecapLoadScrollBar_Update()
		RecapLoad_PostSpamRows(header, false)

	elseif IsShiftKeyDown() then
		local editBox = ChatEdit_GetActiveWindow()
		if not editBox then
			-- short help message
			print(rLocalize.RankUsage)
		end
	end
end

function RecapLoad_List_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local id, index, thisCombatant

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapLoadScrollBar)

	if (index < rTemp.LoadListSize) then
		thisCombatant = rTemp.LoadList[index].Name
		rTemp.OutgoingDetailSelected = 0
		rTemp.IncomingDetailSelected = 0
		rTemp.OtherDetailSelected = 0
		rTemp.PanelRecentSelected = 0

		if (rTemp.Selected ~= 0) then
			local id2
			id2 = rTemp.Selected - FauxScrollFrame_GetOffset(RecapScrollBar)
			if (id2 >= 1) and (id2 <= 15) then
				-- only unlock the other highlight if it is visible
				_G["RecapList"..id2]:UnlockHighlight()
			end
			rTemp.Selected = 0
		end

		if (rTemp.LoadSelected == index) then
			rTemp.LoadSelected = 0
			_G["RecapLoadList"..id]:UnlockHighlight()
			RecapPanel_Hide()
		else
			rTemp.LoadSelected = index
			RecapLoadScrollBar_Update()
			rTemp.PanelSource = "Load"
			RecapPanel_Show(thisCombatant)
		end

		if IsShiftKeyDown() and (not IsAltKeyDown()) and (not IsAltKeyDown()) then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			Recap_InsertChat(string_format(rLocalize.VerboseLinkStart,
								"("..rLocalize.DataSet..": '"..rTemp.LoadedDataSet.."') (".. Recap_PetsMergedText()..")",
								Recap_StripGUIDsFromCombatant(thisCombatant),
								_G["RecapLoadList"..id.."_DmgIn"]:GetText(),
								_G["RecapLoadList"..id.."_TimeIn"]:GetText(),
								_G["RecapLoadList"..id.."_DPSIn"]:GetText(),
								_G["RecapLoadList"..id.."_Deaths"]:GetText(),
								_G["RecapLoadList"..id.."_DmgOut"]:GetText(),
								_G["RecapLoadList"..id.."_Time"]:GetText(),
								_G["RecapLoadList"..id.."_DPS"]:GetText(),
								_G["RecapLoadList"..id.."_MaxHit"]:GetText(),
								_G["RecapLoadList"..id.."_Heal"]:GetText(),
								_G["RecapLoadList"..id.."_TimeHeal"]:GetText(),
								_G["RecapLoadList"..id.."_HPS"]:GetText() ) )
			-- note: the DPS/Gear value is omitted as it only makes sense when examining the entire column
		end
	end
end

-- allow click reporting off the totals line
function RecapLoad_List_Totals_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local i, thisCombatant

	rTemp.OutgoingDetailSelected = 0
	rTemp.IncomingDetailSelected = 0
	rTemp.OtherDetailSelected = 0
	rTemp.PanelRecentSelected = 0
	for i=1,15 do
		_G["RecapLoadList"..i]:UnlockHighlight()
	end

	if IsShiftKeyDown() and (not IsAltKeyDown()) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rTemp.LoadSelected = 0
		RecapPanel_Hide()
		Recap_InsertChat(string_format(rLocalize.VerboseGroupTotalStart,
							"("..rLocalize.DataSet..": '"..rTemp.LoadedDataSet.."') (".. Recap_PetsMergedText()..")",
							_G["RecapLoadTotals_DmgIn"]:GetText(),
							_G["RecapLoadTotals_TimeIn"]:GetText(),
							_G["RecapLoadTotals_DPSIn"]:GetText(),
							_G["RecapLoadTotals_Deaths"]:GetText(),
							_G["RecapLoadTotals_DmgOut"]:GetText(),
							_G["RecapLoadTotals_Time"]:GetText(),
							_G["RecapLoadTotals_DPS"]:GetText(),
							_G["RecapLoadTotals_MaxHit"]:GetText(),
							_G["RecapLoadTotals_Heal"]:GetText(),
							_G["RecapLoadTotals_TimeHeal"]:GetText(),
							_G["RecapLoadTotals_HPS"]:GetText() ) )
		Recap_InsertChat("+")
		-- create totals for the other (non-group) combatants
		local dmgin, deaths, dmgout, heal, maxhit, duration, durationIn, durationHeal
		dmgin = 0
		deaths = 0
		dmgout = 0
		heal = 0
		maxhit = 0
		duration = rTemp.LoadTotalDuration
		durationIn = rTemp.LoadTotalDurationIn
		durationHeal = rTemp.LoadTotalDurationHeal
		if duration>0 or durationIn>0 or durationHeal>0 then
			for j=1,rTemp.LoadListSize-1 do
				thisCombatant = rTemp.LoadList[j].Name
				if thisCombatant and rLoad[thisCombatant] and not rLoad[thisCombatant].Friend then
					if rTemp.LoadList[j].MaxHit > maxhit then
						maxhit = rTemp.LoadList[j].MaxHit
					end
					dmgin = dmgin + rTemp.LoadList[j].DmgIn
					deaths = deaths + rTemp.LoadList[j].Deaths
					dmgout = dmgout + rTemp.LoadList[j].DmgOut
					heal = heal + rTemp.LoadList[j].Heal
				end
			end
			Recap_InsertChat(string_format(rLocalize.VerboseNonGroupTotalStart,
								"("..rLocalize.DataSet..": '"..rTemp.LoadedDataSet.."') (".. Recap_PetsMergedText()..")",
								dmgin,
								_G["RecapLoadTotals_TimeIn"]:GetText(),
								(((durationIn>0) and Recap_Div1(dmgin,durationIn)) or 0),
								deaths,
								dmgout,
								_G["RecapLoadTotals_Time"]:GetText(),
								(((duration>0) and Recap_Div1(dmgout,duration)) or 0),
								maxhit,
								heal,
								_G["RecapLoadTotals_TimeHeal"]:GetText(),
								(((durationHeal>0) and Recap_Div1(heal,durationHeal)) or 0)) )
		end
	end
end

function RecapLoad_GroupTotal_OnClick(frame, button, down)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rOpt.ShowPanel.value then
		if (rTemp.LoadSelected == rTemp.GroupIndex) and RecapPanel:IsShown() then
			-- toggle off
			rTemp.LoadSelected = 0
			RecapPanel_Hide()
		else
			-- calculate our special combatant "Group Total" (on demand only, since it takes a significant amount of time)
			RecapLoad_ClearGrandTotal(rTemp.GroupTotal)
			RecapLoad_DoGrandTotal(rTemp.GroupTotal)
			rTemp.Selected = 0
			rTemp.LoadSelected = rTemp.GroupIndex -- non-zero value to keep the panel showing and indicate which total we are showing
			RecapLoadScrollBar_Update()
			rTemp.PanelSource = "Load"
			RecapPanel_Populate(rTemp.GroupTotal)
			RecapPanel:Show()
		end
	end
end

function RecapLoad_NonGroupTotal_OnClick(frame, button, down)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rOpt.ShowPanel.value then
		if (rTemp.LoadSelected == rTemp.NonGroupIndex) and RecapPanel:IsShown() then
			-- toggle off
			rTemp.LoadSelected = 0
			RecapPanel_Hide()
		else
			-- calculate our special combatant "Non-Group Total" (on demand only, since it takes a significant amount of time)
			RecapLoad_ClearGrandTotal(rTemp.NonGroupTotal)
			RecapLoad_DoGrandTotal(rTemp.NonGroupTotal)
			rTemp.Selected = 0
			rTemp.LoadSelected = rTemp.NonGroupIndex -- non-zero value to keep the panel showing and indicate which total we are showing
			RecapLoadScrollBar_Update()
			rTemp.PanelSource = "Load"
			RecapPanel_Populate(rTemp.NonGroupTotal)
			RecapPanel:Show()
		end
	end
end


--[[ Tooltip functions ]]

function RecapLoad_List_OnEnter(frame)

	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local index, id, secondLine, thirdLine, fourthLine, fifthLine, line99, thisCombatant, iCombatant

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapLoadScrollBar)

	thisCombatant = rTemp.LoadList[index].Name
	if thisCombatant then
		iCombatant = rLoad[thisCombatant]
		secondLine = ""
		if iCombatant.Class and rLocalize.ClassName[iCombatant.Class] then
			secondLine = rLocalize.ClassName[iCombatant.Class]
		end
		if iCombatant.Faction and rLocalize.FactionName[iCombatant.Faction] then
			secondLine = secondLine.." (".. rLocalize.FactionName[iCombatant.Faction]..")"
		end
		if Recap_ExtractOwner(thisCombatant) then
			secondLine = secondLine.." ("..rLocalize.OwnedBy.." "..Recap_NameFromNameGUID(Recap_ExtractOwner(thisCombatant))..")"
		elseif rLoad[thisCombatant].OwnedBy then
			secondLine = secondLine.." ("..rLocalize.OwnedBy.." "..Recap_NameFromNameGUID(rLoad[thisCombatant].OwnedBy)..")"
		end
		thirdLine = ""
		if iCombatant.MinMaxHealth then
			if iCombatant.MinMaxHealth == iCombatant.MaxMaxHealth then
				thirdLine = rLocalize.Max.." "..rLocalize.PowerName[-2]..":  "..iCombatant.MinMaxHealth
			else
				thirdLine = rLocalize.Max.." "..rLocalize.PowerName[-2]..":  "..iCombatant.MinMaxHealth..".."..iCombatant.MaxMaxHealth
			end
		end
		fourthLine = ""
		if iCombatant.MinMaxPower and iCombatant.PowerType then
			if iCombatant.MinMaxPower == iCombatant.MaxMaxPower then
				if tonumber(iCombatant.MinMaxPower) > 0 then
					fourthLine = rLocalize.Max.." "..rLocalize.PowerName[tonumber(iCombatant.PowerType)]..":  "..iCombatant.MinMaxPower
				end
			else
				fourthLine = rLocalize.Max.." "..rLocalize.PowerName[tonumber(iCombatant.PowerType)]..":  "..iCombatant.MinMaxPower..".."..iCombatant.MaxMaxPower
			end
		end
		fifthLine = ""
		if iCombatant.GearValue and (iCombatant.GearValue > 0) and (iCombatant.GearValue ~= 10000) then
			fifthLine = rLocalize.MaxGearValue..":  "..iCombatant.GearValue
		end
		line99 = "\n"..rLocalize.PostRowTooltip
		Recap_MultilineTooltip(frame, Recap_NameOnlyFromCombatant(thisCombatant), secondLine, thirdLine, fourthLine, fifthLine, line99)
	end
	if (index<rTemp.LoadListSize) and rTemp.Selected==0 and rTemp.LoadSelected==0 then
		-- mouseover display of panel only if it isn't locked by being selected
		if thisCombatant then
			rTemp.PanelSource = "Load"
			RecapPanel_Show(thisCombatant)
		end
	end
end

function RecapLoad_Totals_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local i, thisCombatant, iTotal
	local group_kills = 0

	if rOpt.ShowTooltips.value then

		if rOpt.TooltipFollow.value then
			rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
		else
			GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
		end

		rTemp.RecapTooltip:AddLine(rLocalize.Totals.." "..rLocalize.For.." "..rLocalize.DataSet..": '"..rTemp.LoadedDataSet.."'")

		if rTemp.LoadListSize>1 then

			for i=1,(rTemp.LoadListSize-1) do
				thisCombatant = rTemp.LoadList[i].Name
				if thisCombatant and rLoad[thisCombatant] and (not rLoad[thisCombatant].Friend) then
					group_kills = group_kills + rTemp.LoadList[i].Deaths
				end
			end
			iTotal = rTemp.LoadList[rTemp.LoadListSize]
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddDoubleLine(rLocalize.Combatants..":",rTemp.LoadListSize-1,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.DmgOut)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DAMAGE_OUT..":",iTotal.DmgOut,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_TIME_FIGHTING..":",Recap_FormatTime(iTotal.Time),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DPS_OUT..":",string_format("%.1f",iTotal.TotDPSOut),r,g,b,r,g,b)
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_MAX_HIT..":",iTotal.MaxHit,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_KILLS..":",group_kills,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.DmgIn)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DAMAGE_IN..":",iTotal.DmgIn,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_TIME_DAMAGED..":",Recap_FormatTime(iTotal.TimeIn),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DPS_IN..":",string_format("%.1f",iTotal.TotDPSIn),r,g,b,r,g,b)
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DEATHS..":",iTotal.Deaths,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.Heal)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_HEALS..":",iTotal.Heal,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_TIME_HEALING..":",Recap_FormatTime(iTotal.TimeHeal),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_HPS_OUT..":",string_format("%.1f",iTotal.TotHPS),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.DmgOut)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_GROUP_FIGHT_TIME..":",Recap_FormatTime(iTotal.OverallDuration),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_GROUP_DPS..":",string_format("%.1f",iTotal.OverallDPS),r,g,b,r,g,b)
		else
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddLine(rLocalize.Combatants..": "..rLocalize.None,r,g,b)
		end

		if rOpt.ShowClickHints.value then
			rTemp.RecapTooltip:AddLine(rLocalize.TotalsRowTooltip, .565, .565, 1.0, 1)
		end

		rTemp.RecapTooltip:Show()
	end
end


RecapLoad_lua_4773 = true
