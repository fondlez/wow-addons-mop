﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

if not ((GetLocale() == "deDE") or (GetLocale() == "zhCN") or (GetLocale() == "zhTW") or (GetLocale() == "ptBR")) then

--[[ Miscellaneous variables and localization strings for Recap ]]

recap_temp = {} -- other global values (not saved to SavedVariables)

--[[ Tooltips, option indexes ]]

-- when adding or removing Options:
--   update all of the localization files appropriately (note the need to preserve the order strictly for the first set of entries in OptList)
--   update RecapOptions.lua and RecapOptions.xml appropriately to add or remove an option
--	  in some cases there will be no changes needed to RecapOptions, in some cases significant changes, depending on circumstances
--   for author testing increment Recap_Version in Recap.lua, such as by adding one in the third decimal place, to trigger proper update processing
--   add specific code to RecapAux.lua to handle any special case processing of the added or removed option
--	  update the function Recap_SetUpOptions and associated sub-functions

-- First field each line MUST NOT CHANGE (they are option ids)
-- the order MUST NOT CHANGE until the item 'HeaderClass'.  They are in the order of GetID values
recap_temp.OptList = {
	{ "ShowClickHints", "Show Click Hints", "When checked, and when the preceding 'Show Tooltips' option is also checked, the portion of tooltips that gives click hints will be shown, for example:\n\n|cFF9090FFClick Hints:\n•• Click this check box to enable or disable this option." }, -- 1
	{ "GrowUpwards", "Expand Window Up", "When checked, the window's bottom edge will remain anchored while the top edge resizes." },
	{ "GrowLeftwards", "Expand Window Left", "When checked, the window's right edge will remain anchored while the left edge resizes." },
	{ "ShowTooltips", "Show Tooltips", "When checked, tooltips like the one you're reading will be shown." },
	{ "AutoHide", "Auto Hide Entering Combat", "When checked, and the window isn't minimized, it will hide when a fight begins and reappear when the fight ends." },
	{ "AutoFade", "Auto Fade Window", "When checked, and the window isn't minimized, the window will fade after your mouse leaves the window.\n\nTo bring the window back after it has faded, type '/recap'." },
	{ "LimitFights", "Limit Fights to Combat", "When checked, fight logging will not begin until you enter combat mode.  Recommended Off unless you don't want to log fights around you." },
	{ "HideZero", "Show Only Combatants with Duration", "When checked, combatants who have fought for only a short time (currently under 3 seconds) will not be shown on the Fights panels.  They are still tracked.  Use this to hide totems, critters, etc." },
	{ "HideOthers", "Hide Other Combatants", "When checked, hides all other combatants who are not in the group.  This will include allies, neutrals, and foes.\n\nThis option should normally be turned off.\n\nNote that this option can not be enabled at the same times as both Store Only Displayed Combatants and Auto Save Boss Fights." },
	{ "IdleFight", "End Fight if Idle", "When checked, fights will end if no hits or healing happen for a length of time." }, -- 10
	{ "Time", "Display Time Damage Out", "When checked, each combatants' time doing damage will be displayed in the list." },
	{ "MaxHit", "Display Max Hit", "When checked, each combatants' max hit will be displayed in the list." },
	{ "DmgIn", "Display Damage In", "When checked, each combatants' total damage received will be displayed in the list." },
	{ "DmgOut", "Display Damage Out", "When checked, each combatants' total damage done to others will be displayed in the list." },
	{ "DPSIn", "Display DPS In", "When checked, each combatants' damage per second received will be displayed in the list." },
	{ "DPS", "Display DPS Out", "When checked, each combatants' damage per second done to others will be displayed in the list." },
	{ "MinStatus", "Display Status While Minimized", "When checked, the status light will remain visible while minimized." },
	{ "MinView", "Display Last/All While Minimized", "When checked, a small label indicating if you are watching the Last Fight or All Fights will be visible while minimized." },
	{ "MinYourDPS", "Display Your DPS Out While Minimized", "When checked, the damage per second that you done will be displayed in minimized view." },
	{ "MinDPSIn", "Display Total DPS In While Minimized", "When checked, the total damage per second combatants in the group received will be displayed in minimized view." }, -- 20
	{ "MinDPSOut", "Display Total DPS Out While Minimized", "When checked, the total damage per second combatants in the group done to others will be displayed in minimized view." },
	{ "MinButtons", "Display Buttons While Minimized", "When checked, the buttons along the top-right edge (Close, Pin, Pause, Options, Last/All) will remain visible in minimized view." },
	{ "TooltipFollow", "Tooltips At Pointer", "When checked, tooltips will follow the pointer instead of using the default tooltip placement. Note: Many mods override default tooltip behavior." },
	{ "SaveGroup", "Save Group Only", "When checked, only combatants currently marked as a being in the group will be saved to fight data sets.  To change the group status of a combatant, right-click their name." },
	{ "AutoSaveBossFights", "Auto Save Boss Fights", "When checked, Recap will automatically save every fight that is identified as a boss fight.  A boss fight is one with a 'skull' boss present.  A boss who is not 'skull' to you will not be automatically saved.\n\nWarning: If this option is enabled, and if you don't visit the Options / Data Sets tab frequently to delete unwanted data sets, the amount of memory used by Recap will grow rapidly.\n\nNote that this option can not be enabled at the same times as both Hide Other Combatants and Store Only Displayed Combatants." },
	{ "Heal", "Display Heals", "When checked, each combatants' healing done (actual) will be displayed in the list.  Overhealing has been subtracted from this value." },
	{ "Deaths", "Display Deaths", "When checked, the number of deaths for each combatant will be displayed in the list." },
	{ "HideYardTrash", "Show Only Unique Combatants", "When checked, combatants not in the group that have more than one with the same name will be hidden.  Useful in single instance runs to hide yard trash or common mobs." },
	{ "PauseOutsideInstances", "Pause Outside Instances", "When checked, Recap will automatically pause whenever it detects that it has left an instance, and resume whenever it detects that it has entered an instance." },
	{ "Faction", "Display Faction/Level", "When checked, if a combatant's faction and level are known they will be displayed by their name." }, -- 30
	{ "Class", "Display Class", "When checked, if a combatant's class is known its icon will be displayed by their name." },
	{ "HealP", "Display Heals %", "When checked, a percentage of total healing (actual) will be displayed for each combatant in the group." },
	{ "DmgInP", "Display Damage In %", "When checked, a percentage of total damage received will be displayed for each combatant in the group." },
	{ "DmgOutP", "Display Damage Out %", "When checked, a percentage of total damage done to others will be displayed for each combatant in the group." },
	{ "AutoPost", "Auto Post Results", "When checked, a summary will be reported at the end of each fight to the channel selected below." },
	{ "MinBack", "Display Back While Minimized", "When checked, the background will remain opaque in minimized view." },
	{ "MergePets", "Merge Pets with Owners", "When checked, from that point on, all pet damage will be credited to its owner.  When unchecked, from that point on, all pet damage will be credited to the pet." },
	{ "AutoMinimize", "Auto Minimize", "When checked, the window will minimize automically when the pointer leaves the window, and expand when the pointer enters the window.  Holding the Shift key or selecting a combatant will override this behavior." },
	{ "ShowPanel", "Show Details", "When checked, a popup panel showing more detailed information will be shown as you move the pointer over combatants.  Select a combatant to lock the panel.  In Light Data Mode, only the Summary details will be available." },
	{ "LightData", "Light Data Mode", "When checked, extra information such as misses and damage breakdowns will not be collected or stored.\n\nWhen unchecked, misses and damage details will accumulate into the Details panel.\n\nNote: For now, Personal Details will not accumulate while in Light Data Mode." }, -- 40
	{ "ShowGauges", "Show Gauges", "When checked, gauges will appear behind combatants in the group for a visual indicator of damage, healing, or other.\n\nTo choose which gauge to show, sort on a column by left-clicking on the header above the column." },
	{ "AutoLeader", "Auto Post New Leaders", "When checked, changes in leadership of the stat chosen below will be automatically posted to the selected channel." },
	{ "Ranks", "Numbered List", "When checked, the list will be numbered." },
	{ "DPSvsAll", "Display DPS vs All", "When checked, a DPS value will be displayed reflecting each individual's damage over the total time everyone was doing damage." },
	{ "Over", "Overhealing", "When checked, an overhealing percentage will be displayed for every combatant in the group for All Fights.  The overhealing is not part of the values in the Heal column.\n\nUse with caution as an indication of healer capability or contribution." },
	{ "HTML", "Format in HTML", "When checked, logs written to WoWChatLog.txt or the clipboard will be formatted into a simple HTML table." },
	{ "WriteGroup", "Write Only Group", "When checked, reports will only be written for combatants in the group." },
	{ "ETotal", "Display Totals", "When checked, the total damage or healing for each effect will be shown in personal details." },
	{ "ETotalP", "Display Total Contribution", "When checked, the contribution of this effect to the whole will be shown in personal details." },
	{ "EHits", "Display Hits", "When checked, the number of non-crit non-glance hits will be shown in personal details." }, -- 50
	{ "EHitsAvg", "Display Average Hit", "When checked, the average non-crit non-glance hit will be shown in personal details." },
	{ "EHitsMax", "Display Max Hit", "When checked, the maximum non-crit non-glance hit will be shown in personal details." },
	{ "ETicks", "Display Ticks", "When checked, the number of ticks will be shown in personal details." },
	{ "ETicksAvg", "Display Average Tick", "When checked, the average tick amount will be shown in personal details." },
	{ "ETicksMax", "Display Max Tick", "When checked, the maximum tick amount will be shown in personal details." },
	{ "ECrits", "Display Crits", "When checked, the number of crits will be shown in personal details." },
	{ "ECritsAvg", "Display Average Crit", "When checked, the average crit will be shown in personal details." },
	{ "ECritsMax", "Display Max Crit", "When checked, the maximum crit will be shown in personal details." },
	{ "ECritsP", "Display Crit Rate", "When checked, the crit rate for each effect will be shown in personal details." },
	{ "EMiss", "Display Misses", "When checked, the number of misses for each effect will be shown in personal details.  For non-melee this is miss, deflects and resists.  For melee this includes block, parry and dodge." }, -- 60
	{ "EMissP", "Display Miss Rate", "When checked, the miss rate for each effect will be shown in personal details." },
	{ "EMaxAll", "Display Maximum Damage", "When checked, the maximum damage from a single hit, tick or crit for each effect will be shown in personal details." },
	{ "WarnData", "Warn When Data Grows Too Large", "When checked, a message will remind you on login when your live data contains more than 2000 combatants; or when your saved Data Sets exceed 40 Mbytes.\n\nRecap can function perfectly fine with over 2000 combatants; or with more than 40 Mbytes of saved data sets.  Some users may not be aware that they are accumulating a lot of data they may not be interested in." },
	{ "HPS", "Display HPS Out", "When checked, each combatants' healing (actual) per second delivered will be displayed in the list." },
	{ "MergeAllPetsIntoOne", "Merge All Pets into One Pet", "When checked, and if Merge Pets with Owners is on, all pets for a combatant are merged into one single pet, called 'Pet'.\n\nThis applies to permanent pets, temporary pets, traps, totems, controlled mobs, vehicles, and so on.\n\nUse with caution." },
	{ "RecentData", "Recent Data Mode", "When checked, recent events are remembered.\n\nWhen this option is enabled, to see recent Outgoing and Incoming events for a combatant, click on the Recent button to the right of their name on the Outgoing Details or Incoming Details tabs.  You can also double-click on the combatant's row.  If you hold the control key down while clicking then the recent events will show dispels and interrupts only.\n\nFor recent Incoming and Outgoing events for a spell or ability for a combatant, click on the Recent button to the right of the spell or ability, either in the Personal Details panel or in the Outgoing Details or Incoming Details tabs.\n\nRecap does not write the events to disk.  Recap starts with an empty buffer whenever you log in or reload the UI.\n\nThe slider can only be changed when Recent Data Mode is not active.\n\nWarning: When active, Recent Data Mode uses additional memory." },
	{ "IgnoreGUIDs", "Ignore Global Unique Identifiers", "When checked, ignore the global unique identifiers provided for combatants with WoW patch 2.4 and later.  This will give behaviour similar to older versions of Recap, and will use significantly less memory.\n\nChanging this option forces a Reset.\n\nIf this option is checked then synchronization is not allowed." },
	{ "HideGroup", "Hide Group", "When checked, hides other combatants in the group (and their pets if any).  Group includes a party of five or a raid of forty.  Group also includes any combatant that you have added using the right-click dropdown menu.\n\nThis option should normally be turned off." },
	{ "EElement", "Display Element", "When checked, the element (Arcane, Fire, etc.) for each effect will be shown in personal details." },
	{ "TimeIn", "Display Time Damage In", "When checked, each combatants' time taking damage will be displayed in the list." }, -- 70
	{ "TimeHeal", "Display Time Healing", "When checked, each combatants' time healing will be displayed in the list." },
	{ "EnableSync", "Enable Synchronization", "When checked, Recap will be ready to initiate or receive synchronization with other players.  You will be invited to join any new or ongoing synchronization within your group.\n\nWhen unchecked, Recap will leave any current synchronization, and will ignore any future synchronization requests.\n\nNot allowed if the Ignore Global Unique Identifiers option is checked." },
	{ "OpaqueBackground", "Opaque Background", "When checked, all panels have an opaque black background." },
	{ "MinimizeOnEscape", "Minimize on Escape", "When checked, the main Recap panel will minimize when the Escape key is pressed.  Other Recap panels will close." },
	{ "MinSyncStatus", "Display Sync Status While Minimized", "When checked, the sync status light will remain visible while minimized." },
	{ "RemindGroupStatus", "Remind on Join or Leave Group", "When checked, a popup message will show whenever you join or leave a group, to remind you to do whatever it is that you wanted to be reminded to do.  Perhaps you wanted to Reset every time you join a group." },
	{ "Seen", "First Seen", "When checked, the time that this combatant was first seen in the combat log will be displayed in the list." },
	{ "LiveData", "Live Data Mode", "When checked, Recap will track outgoing DPS, incoming DPS, and outgoing HPS live, in a graph or text display.\n\nWARNING: When active, this mode uses some additional memory, and takes significant additional CPU time. On some machines this may slow your game by an unacceptable amount.\n\nWhen this option is enabled, the graph and text listing panel will automatically appear when anyone in your group does damage or takes damage." },
	{ "OtherData", "Other Data Mode", "When checked, Recap will track events that neither damage nor heal.  These include spell casts, debuffs/losses, and buffs/gains.\n\nIf this option is enabled, the information can be found on the Other Details tab of the popup panel.\n\nThis information is not tracked if the Light Data Mode option is enabled." },
	{ "EHitsMin", "Display Min Hit", "When checked, the minimum non-crit non-glance hit will be shown in personal details." },  -- 80
	{ "ETicksMin", "Display Min Tick", "When checked, the minimum tick amount will be shown in personal details." },
	{ "ECritsMin", "Display Min Crit", "When checked, the minimum crit will be shown in personal details." },
	{ "EGlances", "Display Glances", "When checked, the number of glances will be shown in personal details." },
	{ "EGlancesMin", "Display Min Glance", "When checked, the minimum glance will be shown in personal details." },
	{ "EGlancesAvg", "Display Average Glance", "When checked, the average glance will be shown in personal details." },
	{ "EGlancesMax", "Display Max Glance", "When checked, the maximum glance will be shown in personal details." },
	{ "RemindInstanceStatus", "Remind on Enter or Leave Instance", "When checked, a popup message will show whenever you enter or leave an instance, to remind you to do whatever it is that you wanted to be reminded to do.  Perhaps you wanted to Reset or Save every time you enter an instance." },
	{ "StoreOnlyDisplayed", "Store Only Displayed Combatants", "When checked, data for combatants who are hidden as a result of turning on Hide Group or Hide Other Combatants will not be tracked and stored.\n\nData already stored for a combatant who is currently hidden will not be removed.\n\nThis option is ignored during synchronization.\n\nWarning: Sometimes Blizzard and Recap will not immediately determine that a combatant is in the group, or is a player's pet.  If there is a delay the early data may be lost.\n\nRecommended Off unless you are desperate to save computer memory.\n\nNote that this option can not be enabled at the same times as both Hide Other Combatants and Auto Save Boss Fights." },
	{ "MinYourHPS", "Display Your HPS While Minimized", "When checked, the healing per second that you do will be displayed in minimized view." },
	{ "MinHPS", "Display Total HPS While Minimized", "When checked, the total healing per second combatants in the group do will be displayed in minimized view." },  -- 90
	{ "MatrixData", "Matrix Data Mode", "When checked, Recap will track who damaged who, who healed who, who was damaged by whom, and who was healed by whom.\n\nIf this option is enabled, the information can be found on the Target of Outgoing Details (shield leaning left) and Source of Incoming Details (sword pointing left) tabs of the popup panel.\n\nThis information is not tracked if the Light Data Mode option is enabled." },
	{ "SetScale", "Set Scale", "Set the scale of the Recap panels." },
	{ "MinYourPetPercent", "Display the Percentage of Your Damage Done by Your Pet(s)", "When checked, the percentage of your damage done by your pet(s) will be displayed in minimized view." },
	{ "ResetOnLogout", "Reset on Logout", "When checked, Recap will automatically Reset All Fights on logout.\n\nWarning: This means that your All Fights data goes away.  If you logout by accident, it still goes away." },
	{ "Dispels", "Display Dispels", "When checked, the number of dispels for each combatant will be displayed in the list.  This includes both desirable dispels and undesirable dispels." },
	{ "LDBSupport", "LibDataBroker Support", "When checked, Recap will make live numbers available for display by LibDataBroker display addons.\n\nDisabling this setting will reload your UI." },
	{ "TabDelimited", "Tab-Delimited Report Format", "When checked, logs written to WoWChatLog.txt or the clipboard will be formatted in a simple tab-delimited format, suitable for pasting into a spreadsheet." },
	{ "PauseInsideBattlegrounds", "Pause Inside Battlegrounds", "When checked, Recap will automatically pause whenever it detects that it has entered a battleground instance, and resume whenever it detects that it has left a battleground instance." },
	{ "PostInColumns", "Post in Columns", "When checked, multi-item posts such as DPS will be spaced so that the items align in columns (default).  When not checked, the items will be separated by single spaces only." },
	{ "DPSPerGear", "Display DPS Out / Gear Value Ratio", "When checked, each combatants' damage per second done to others, divided by gear value, will be displayed in the list.\n\nNote: I'm aware of how superficial this ratio can be, involving as it does DPS (itself a matter of debate) and gear value (rather subjective). Use at your own risk.\n\nWarning: For All Fights data the gear value used will be the highest one seen by Recap for that combatant." },  -- 100
	{ "Interrupts", "Display Interrupts", "When checked, the number of interrupts for each combatant will be displayed in the list.  This includes both desirable interrupts and undesirable interrupts." },
	{ "LimitToEncounters", "Limit Fights to Encounters only", "NOT CURRENTLY RECOMMENDED FOR USE: When checked, fight logging will only begin on a Blizzard encounter start event.  Logging will end on a Blizzard encounter end event (plus end fight delay)." },

	-- tooltips that don't change can go below in any order. Ensure future options go above these
	{ "HeaderClass", "Class", "This is an icon representing the class of this combatant, if known." },
	{ "HeaderSeen", "First Seen", "This is the time that this combatant was first seen in the combat log." },
	{ "HeaderTime", "Time Doing Damage", "This is the time each combatant fought from their first point of damage to their last." },
	{ "HeaderTimeIn", "Time Taking Damage", "This is the time each combatant took damage from their first point of receiving damage to their last." },
	{ "HeaderTimeHeal", "Time Healing", "This is the time each combatant healed from their first point of healing to their last." },
	{ "HeaderMaxHit", "Max Hit", "This is the maximum damage each combatant done to others in a single hit or spell." },
	{ "HeaderDmgIn", "Damage In", "This is the damage received (tanked) by each combatant." },
	{ "HeaderDmgOut", "Damage Out", "This is the damage done to others by each combatant." },
	{ "HeaderHPS", "Individual HPS Out", "This is the personal Healing Per Second (actual) delivered by each combatant, based on the duration from their first to last attempted point of healing." },
	{ "HeaderDPSIn", "Individual DPS In", "This is the personal Damage Per Second received by each combatant, based on the duration from their first to last point of damage received." },
	{ "HeaderDPS", "Individual DPS Out", "This is the personal Damage Per Second done to others by each combatant, based on the duration from their first to last attempted point of damage done." },
	{ "HeaderDPSPerGear", "Individual DPS Out / Gear Value", "This is the personal Damage Per Second done to others by each combatant, divided by gear value.\n\nWarning: For All Fights data the gear value used will be the highest one recorded." },
	{ "HeaderHeal", "Heals Out", "This is the hit points healed (actual) by this combatant (actual heal is the spell amount minus the overheal amount)." },
	{ "HeaderDeaths", "Death Count", "This is the number of times this combatant died within logging distance." },
	{ "HeaderDispels", "Dispels Count", "This is the number of times this combatant dispelled an effect within logging distance." },
	{ "HeaderInterrupts", "Interrupts Count", "This is the number of times this combatant interrupted an effect within logging distance." },
	{ "Options", "Open Options", "Summon or dismiss the options window to change settings or manage fight data sets." },
	{ "SyncStatus", "Synchronization Status", "This light is blue if you are in a synchronization, and is grey otherwise.  The blue light will blink while synchronization data is being exchanged." },
	{ "TooltipMinYourDPS", "Your DPS Out", "This is your personal DPS done, including pet." },
	{ "TooltipMinYourPetPercent", "Your Pet Percent", "This is the percent of your damage done by your pet." },
	{ "TooltipMinDPSIn", "Total DPS In", "This is the total damage per second received by combatants in the group." },
	{ "TooltipMinDPSOut", "Total DPS Out", "This is the total damage per second done to others from combatants in the group." },
	{ "TooltipMinYourHPS", "Your HPS", "This is your personal healing per second done, including pet." },
	{ "TooltipMinHPS", "Total HPS", "This is the total healing per second done by combatants in the group." },
	{ "AutoFadeSlider", "Auto Fade Timer", "This is the time before the window fades after you leave it if Auto Fade Window is checked." },
	{ "SetScaleSlider", "Set Scale", "This is the scale of the Recap panels, from small (0.5) to large (2.0).\n\nChanging the scale will move the Recap panels into the centre of the screen, and you will need to move them back to where you want them." },
	{ "IdleFightSlider", "Fight Idle Timer", "This is the idle time before a fight will end if End Fight if Idle is checked." },
	{ "EndFightDelaySlider", "End of Fight Delay", "A fight will not be ended until this time has elapsed after the player left combat.  This prevents short 'out of combat' gaps from ending a fight prematurely.\n\nIf your group continues in combat then your 'current fight' may not end even if you enter and leave combat multiple times.  If this causes you problems, reduce this delay.  If the delay is set to zero than the behaviour is the same as in earlier versions of Recap." },
	{ "RecentEventCountSlider", "Recent Event Count", "This is the number of recent events that can be remembered.\n\nThe slider can only be changed when Recent Data Mode is not active.\n\nWarning: The larger this number, the more memory that Recap will need." },
	{ "ExitRecap", "Exit Recap", "Fight monitoring is suspended. Click here to shut down Recap completely." },
	{ "HideWindow", "Hide Window", "Continue monitoring fights, but hide this window.  To show it again type '/recap'." },
	{ "ExpandWindow", "Expand Window", "Expand window to show fight details." },
	{ "MinimizeWindow", "Minimize Window", "Minimize window and hide fight details." },
	{ "UnPinWindow", "Unpin Window", "Allow window to be moved." },
	{ "PinWindow", "Pin Window", "Prevent window from being moved." },
	{ "Resume", "Resume Monitoring", "Fight logging is currently suspended.  Click here to start watching fights.  Will do nothing if a save is in progress." },
	{ "PauseMonitoring", "Pause Monitoring", "Click here to stop watching fights.  If you dismiss Recap while paused, it will not attempt to log any fights until you summon it using '/recap'." },
	{ "ShowAllFights", "Show All Fights", "Currently the window is displaying the result of the last fight.  Click here to show all fights since last reset." },
	{ "ShowLastFight", "Show Last Fight", "Currently the window is displaying all fights since the last reset.  Click here to show only the last fight." },
	{ "CombatLast", "Combatants for Last Fight", "This is a list of all combatants that did damage, took damage, or healed in the last fight.  To change group status, right-click the name." },
	{ "CombatAll", "Combatants for All Fights", "This is a list of all combatants that did damage, took damage, or healed since your last reset.  To change group status, right-click the name." },
	{ "ResetLastFight", "Reset Last Fight", "This will SUBTRACT the fight data for the last fight.  Note: Max hits and Overheals can only be reset by resetting All Fights." },
	{ "ResetAllFights", "Reset All Fights", "This will wipe all active fight data for all combatants, except for those stored in Fight Data Sets and Personal Details.  Fight Data Sets can only be deleted from within Options / Data Sets.  Personal Details can only be reset while they are visible." },
	{ "SaveAllSet", "Save All Fights Data Set", "Click here to save the current fight data for All Fights.  Not permitted if already doing a save, or in combat (Blizzard InCombatLockdown)." },
	{ "SaveLastSet", "Save Last Fight Data Set", "Click here to save the current fight data for Last Fight.  Not permitted if already doing a save, or in combat (Blizzard InCombatLockdown)." },
	{ "LoadSet", "Load Fight Data Set", "Click here to load the selected fight data to a separate loaded Data Set panel." },
	{ "LoadSetIntoAllFights", "Load Fight Data Set into All Fights", "Click here to load the selected fight data into the All Fights panel.\n\nWarning: Loading a data set here will overwrite your current All Fights data." },
	{ "DeleteSet", "Delete Fight Data Set(s)", "Click here to delete the selected fight data set(s).\n\nYou can select one fight data set by clicking on it.\n\nYou can select a range of fight data sets by shift+clicking on a second fight data set." },
	{ "DeleteAllSets", "Delete All Fight Data Sets", "Click here to delete all of the fight data sets." },
	{ "RenameSet", "Rename Fight Data Set", "Click here to bring up a dialog box to rename the selected fight data set." },
	{ "DataSetEdit", "Fight Data Set Name", "Select a data set listed above or enter a new name here to create a new data set." },
	{ "OptOk", "Close", "Close the options panel." },
	{ "HeaderHealP", "% Heals", "This is the percent of total healing (actual) for each combatant in the group." },
	{ "HeaderDmgInP", "% Damage In", "This is the percent of total for each combatants' damage received." },
	{ "HeaderDmgOutP", "% Damage Out", "This is the percent of total for each combatants' damage done to others." },
	{ "OptTab1", "Display Options", "These options define what elements of the window to display in its various forms.\n\nNote: None of the display settings affect data.  You can turn off everything for normal use, and later reveal elements you want to see." },
	{ "OptTab2", "General Settings", "These options define window behavior, limits to data and miscellaneous options." },
	{ "OptTab3", "Fight Data Sets", "Here you can manage Fight Data Sets.  Fight Data Sets are compact archives of the 'All Fights' view or of the 'Last Fight' view." },
	{ "OptTab4", "Reporting Options", "Here you can set options for reporting, initiate chat logging, and send reports to a clipboard." },
	{ "OptTab5", "Synchronization", "Here you can manage synchronization for Recap.  Recap synchronizes the All Fights summary information at the end of each fight.  Other Recap information is not currently synchronized." },
	{ "OptTab6", "Ignore Effects", "Here you can arrange to ignore the damage and healing due to specific effects.  You will need to know the numerical spell ID of each effect that you wish to ignore.  Note that the list of effects to ignore is shared among all characters." },
	{ "MaxRowsSlider", "Maximum Rows", "Adjust this to change the maximum rows the window can hold." },
	{ "MaxRankSlider", "Maximum Lines", "This adjusts a limit on how many lines to report to chat." },
	{ "PanelClose", "Close Panel", "Hide this details panel.  Information will still be accumulated while this is hidden.  To stop accumulating detailed information, check 'Light Data Mode' in options." },
	{ "PanelTab1", "Incoming Details: Tanking", "This tab will show information on incoming damage, healing, and misses to this combatant." },
	{ "PanelTab2", "Source of Incoming", "This tab will show information on the sources of incoming damage and healing to this combatant.\n\nThe option to track this information is off by default.  To track this information enable the Matrix Data Mode on the Options / Settings panel." },
	{ "PanelTab3", "Outgoing Details: Damage", "This tab will show information on outgoing damage and healing from this combatant." },
	{ "PanelTab4", "Target of Outgoing", "This tab will show information on the targets of outgoing damage and healing from this combatant.\n\nThe option to track this information is off by default.  To track this information enable the Matrix Data Mode on the Options / Settings panel." },
	-- Note: the white in the following tooltip is deliberately exaggerated for contrast
	{ "PanelTab5", "Other Details: Casts Debuffs/Losses Buffs/Gains", "This tab will show information on |cFF40D940casts (in green)|cFFBFBFBF, |cFFFF4C4Cdebuffs and losses (in red)|cFFBFBFBF, |cFF4C8CD9buffs and gains (in blue)|cFFBFBFBF, and |cFFF0F0F0effects whose exact type is unknown (in white)|cFFBFBFBF.\n\nThese include almost all Blizzard effects that neither damage nor heal.\n\nThe option to track this information is off by default.  To track this information enable the Other Data Mode on the Options / Settings panel." },
	{ "PanelTab6", "All Details: Summary", "This tab will show a summary of information about this combatant." },
	{ "PanelTabDisabled1", "Incoming Details: Tanking (Disabled)", "You are currently in Light Data Mode.  Tanking details are not collected.\n\nUncheck Light Data Mode in options to collect incoming damage and misses to each combatant." },
	{ "PanelTabDisabled2", "Source of Incoming (Disabled)", "You are currently in Light Data Mode.  Source details are not collected.\n\nUncheck Light Data Mode in options to collect incoming damage and misses to each combatant." },
	{ "PanelTabDisabled3", "Outgoing Details: Damage (Disabled)", "You are currently in Light Data Mode.  Damage details are not collected.\n\nUncheck Light Data Mode in options to collect outgoing damage details for each combatant." },
	{ "PanelTabDisabled4", "Target of Outgoing (Disabled)", "You are currently in Light Data Mode.  Target details are not collected.\n\nUncheck Light Data Mode in options to collect outgoing damage details for each combatant." },
	{ "PanelTabDisabled5", "Other Details: Casts Debuffs/Losses Buffs/Gains (Disabled)", "You are currently in Light Data Mode.  Other details are not collected.\n\nUncheck Light Data Mode in options to collect other details for each combatant." },
	{ "RecentClose", "Close Panel", "Hide this details panel.  Information will still be accumulated while this is hidden." },
	{ "RecentTab1", "Recent Incoming Events", "This tab will show recent events that happened to this combatant or to these combatants, perhaps filtered by effect; and perhaps limited to dispels and interrupts." },
	{ "RecentTab2", "Recent Outgoing Events", "This tab will show recent events generated by this combatant, perhaps filtered by effect." },
	{ "PanelEntry25", "Time Out (Last Fight)", "Time doing damage in last fight." },
	{ "PanelEntry26", "Max Hit (Last Fight)", "Maximum hit done in last fight." },
	{ "PanelEntry27", "Deaths (Last Fight)", "Number of times died in last fight." },
	{ "PanelEntry28", "Heals (Last Fight)", "Total healed (actual) in last fight." },
	{ "PanelEntry29", "Damage In (Last Fight)", "Total damage received in last fight." },
	{ "PanelEntry30", "DPS In (Last Fight)", "DPS In for last fight." },
	{ "PanelEntry31", "Damage Out (Last Fight)", "Total damage done to others in last fight." },
	{ "PanelEntry32", "DPS Out (Last Fight)", "DPS Out for last fight." },
	{ "PanelEntry33", "HPS Out (Last Fight)", "HPS Out (actual) for last fight." },
	{ "PanelEntry34", "HPS Out (All Fights)", "HPS Out (actual) for all fights." },
	{ "PanelEntry35", "Time Out (All Fights)", "Time doing damage in all fights." },
	{ "PanelEntry36", "Max Hit (All Fights)", "Maximum hit done in all fights." },
	{ "PanelEntry37", "Deaths (All Fights)", "Number of times died in all fights." },
	{ "PanelEntry38", "Heals (All Fights)", "Total healed (actual) in all fights." },
	{ "PanelEntry39", "Damage In (All Fights)", "Total damage received in all fights." },
	{ "PanelEntry40", "DPS In (All Fights)", "DPS In for all fights." },
	{ "PanelEntry41", "Damage Out (All Fights)", "Total damage done to others in all fights." },
	{ "PanelEntry42", "DPS Out (All Fights)", "DPS Out for all fights." },
	{ "PanelEntry45", "Total Damage or Healing", "Total damage done or healing done by this effect." },
	{ "PanelEntry46", "Number of Hits", "Number of times this effect landed without a crit, glance, or crush." },
	{ "PanelEntry47", "Number of Crits", "Number of times this effect landed with a crit." },
	{ "PanelEntry48", "Average Hit", "The average non-crit, non-glance, non-crush damage or healing from this effect." },
	{ "PanelEntry49", "Average Crit", "The average crit damage or healing from this effect." },
	{ "PanelEntry50", "Max Hit", "The maximum non-crit, non-glance, non-crush damage or healing from this effect." },
	{ "PanelEntry51", "Max Crit", "The maximum crit damage or healing from this effect." },
	{ "PanelEntry52", "Average Tick", "The average damage or healing this effect applied per tick." },
	{ "PanelEntry53", "Max Tick", "The maximum damage or healing this effect applied per tick." },
	{ "PanelEntry54", "Element", "The element (Arcane, Fire, etc.) for this effect." },
	{ "PanelEntry55", "Missed", "These are the misses from others' attacks." },
	{ "PanelEntry56", "Dodged", "These are the dodges from others' attacks." },
	{ "PanelEntry57", "Parried", "These are the parries from others' attacks." },
	{ "PanelEntry58", "Blocked", "These are the blocks from others' attacks." },
	{ "PanelEntry59", "Absorbed", "This is a combatant absorbing another's attack." },
	{ "PanelEntry60", "Evaded", "This is a combatant evading another's attack." },
	{ "PanelEntry61", "Deflected", "This is a combatant deflecting another's attack." },
	{ "PanelEntry62", "Resisted", "This is a combatant resisting another's attack." },
	{ "PanelEntry63", "Reflected", "This is a combatant reflecting another's attack." },
	{ "PanelEntry64", "Immune", "This is a combatant being immune to another's attack." },
	{ "PanelEntry65", "Crit Rate", "The relative amount of crits per hits attempted." },
	{ "PanelEntry66", "Number of Ticks", "Number of times someone suffered damage or gained health as a result of this effect." },
	{ "PanelEntry67", "Total Miss Rate", "The relative amount of misses per hits attempted.  This is the total of all of the kinds of miss detailed below." },
	{ "PanelEntry68", "Total Casts", "The total number of casts or swings attempted for this attack.  This number includes the misses." },
	{ "PanelEntry70", "Missed", "This is a combatant's spell or ability missing." },
	{ "PanelEntry71", "Dodged", "This is a combatant's spell or ability being dodged." },
	{ "PanelEntry72", "Parried", "This is a combatant's spell or ability being parried." },
	{ "PanelEntry73", "Blocked", "This is a combatant's spell or ability being blocked." },
	{ "PanelEntry74", "Absorbed", "This is a combatant's spell or ability being absorbed." },
	{ "PanelEntry75", "Evaded", "This is a combatant's spell or ability being evaded." },
	{ "PanelEntry76", "Deflected", "This is a combatant's spell or ability being deflected." },
	{ "PanelEntry77", "Resisted", "This is a combatant's spell or ability being resisted." },
	{ "PanelEntry78", "Reflected", "This is a combatant's spell or ability being reflected." },
	{ "PanelEntry79", "Immune", "This is a combatant's spell or ability missing because the target is immune." },
	{ "PanelEntry80", "Time In (Last Fight)", "Time taking damage in last fight." },
	{ "PanelEntry81", "Time In (All Fights)", "Time taking damage in all fights." },
	{ "PanelEntry82", "Time Heal (Last Fight)", "Time healing in last fight." },
	{ "PanelEntry83", "Time Heal (All Fights)", "Time healing in all fights." },
	{ "PanelEntry90", "Number of Crushes", "Number of times this effect landed as a crushing blow." },
	{ "PanelEntry91", "Average Crush", "The average crushing damage from this effect." },
	{ "PanelEntry92", "Max Crush", "The maximum crushing damage from this effect." },
	{ "PanelEntry93", "Crush Rate", "The relative amount of crushes per hits attempted." },
	{ "PanelEntry94", "Attribute", "The attribute gained or lost for this effect." },
	{ "PanelEntry95", "Total", "The total amount gained or lost for this effect.  For a debuff or buff that stacks, the total number of stack levels of the debuff or buff." },
	{ "PanelEntry96", "Hits", "The number of times that this effect occurred." },
	{ "PanelEntry97", "Average", "The average gain or loss for this effect.  For a debuff or buff that stacks, the average stack height reached by the debuff or buff." },
	{ "PanelEntry98", "Maximum", "The maximum gain or loss for this effect.  For a debuff or buff that stacks, the maximum stack height reached by the debuff or buff." },
	{ "PanelEntry99", "Dispels", "The number of times this effect has been dispelled." },
	{ "PanelEntry100", "Interval Count", "The number of time intervals sampled between occurrences of this effect." },
	{ "PanelEntry101", "Estimated Interval", "The estimated average time interval (in seconds) between occurrences of this effect.  This is an estimate only.\n\nNote: In an attempt to avoid problems from bad data points, Recap will ignore any interval over 130 seconds." },
	{ "PanelEntry102", "Misses", "The number of times this effect missed for any reason.  Recap does not currently track the reason." },
	{ "PanelEntry103", "Duration Count", "The number of time durations sampled for this effect." },
	{ "PanelEntry104", "Estimated Avg, Duration", "The estimated average time duration (in seconds) for this effect.  This is an estimate only.\n\nNote: In an attempt to avoid problems from bad data points, Recap will ignore any duration over 130 seconds." },
	-- Note: the white in the following tooltip is deliberately exaggerated for contrast
	{ "PanelEntry105", "Other Effect", "If this effect is shown in |cFF40D940green, it is a cast|cFFBFBFBF; if shown in |cFFFF4C4Cred, it is a debuff or a loss|cFFBFBFBF; if shown in |cFF4C8CD9blue it is a buff or a gain|cFFBFBFBF; and if shown in |cFFF0F0F0white it is either a debuff or a buff|cFFBFBFBF, but Recap can't tell which." },
	{ "PanelEntry106", "Number of Glances", "Number of times this effect landed as a glancing blow." },
	{ "PanelEntry107", "Average Glance", "The average glancing damage from this effect." },
	{ "PanelEntry108", "Max Glance", "The maximum glancing damage from this effect." },
	{ "PanelEntry109", "Glance Rate", "The relative amount of glancing blows per hits attempted." },
	{ "PanelEntry110", "Partial Absorbs", "The number of partial absorbs (does not include complete absorbs)." },
	{ "PanelEntry111", "Partial Absorbs Average", "The average amount of damage absorbed by partial absorbs (does not include complete absorbs)." },
	{ "PanelEntry112", "Partial Blocks", "The number of partial blocks (does not include complete blocks)." },
	{ "PanelEntry113", "Partial Blocks Average", "The average amount of damage blocked by partial blocks (does not include complete blocks)." },
	{ "PanelEntry114", "Partial Resists", "The number of partial resists (does not include complete resists)." },
	{ "PanelEntry115", "Partial Resists Average", "The average amount of damage resisted by partial resists (does not include complete resists)." },
	{ "PanelEntry116", "Partial Resistance", "The average percentage resistance by partial resists (does not include complete resists)." },
	{ "PanelEntry117", "Tick Crit Rate", "The relative amount of crits per ticks." },
	{ "place_holder_118", "", "" },
	{ "place_holder_119", "", "" },
	{ "PanelEntry120", "Steals", "The number of times this effect has been stolen." },
	{ "PanelEntry122", "Min Glance", "The minimum glancing damage or healing from this effect." },
	{ "PanelEntry123", "Min Hit", "The minimum non-crit, non-glance, non-crush damage or healing from this effect." },
	{ "PanelEntry124", "Min Crit", "The minimum crit damage or healing from this effect." },
	{ "PanelEntry125", "Min Crush", "The minimum crushing damage or healing from this effect." },
	{ "PanelEntry126", "Min Tick", "The minimum damage or healing this effect applied per tick." },
	{ "PanelEntry127", "Partial Absorbs Total", "The total amount of damage absorbed by partial absorbs (does not include complete absorbs)." },
	{ "PanelEntry128", "Partial Blocks Total", "The total amount of damage blocked by partial blocks (does not include complete blocks)." },
	{ "PanelEntry129", "Partial Resists Total", "The total amount of damage resisted by partial resists (does not include complete resists)." },
	{ "place_holder_130", "", "" },
	{ "place_holder_131", "", "" },
	{ "PanelEntry133", "Estimated Total Resisted", "This is an estimate of the total amount of damage resisted (and a resistance percentage), including both complete resists and partial resists.  This is an estimate only.\n\nThe percentage can be used as an estimate of the overall effectiveness of resistance." },
	{ "PanelEntry134", "Spell ID", "This is the spell ID for this effect." },
	{ "PanelEntryOverheal", "Overhealing", "This is the total of healing points that landed but didn't heal.  For example, a warrior at 4750/5000 life receives a heal for 1000, bringing them to 5000/5000.  750 were overhealed: 1000 spell heal minus 250 actual heal." },
	{ "OpenLog", "Open Log", "This will open the file named WoWChatLog.txt in WoW's Logs folder.\n\nYou may need to click the button a second time." },
	{ "ReportToLog", "Report to Log", "This will save a report on the current combatants, and a report on the player's personal details, to a file named WoWChatLog.txt in WoW's Logs folder.  It has some limitations imposed by the game:\n-The results will only be available at the end of a session when you log out. UI Reloads won't force a write.\n- You can report several times and they will append to the end.\n\nFor raid results or large lists, use Report to Clipboard instead." },
	{ "CloseLog", "Close Log", "This will close the file named WoWChatLog.txt.\n\nNote: if you have been using Recap dump, it can take a long time for the last of the data to be sent to WoWChatLog.txt, so wait as long as possible before closing the file." },
	{ "UseOneSettings", "Use Global Settings", "By default, settings are saved per character.  Checking this option will use a global set of settings for all characters.\n\nSwitching to or from global settings will trigger a reload of your UI." },
	{ "MenuAdd", "Add to Group", "Add this combatant to the list of group combatants." },
	{ "MenuDrop", "Drop from Group", "Remove this combatant from the list of group combatants." },
	{ "MenuReset", "Reset Combatant", "Reset this combatant.  In All Fights view this will reset their totals and details.  In Last Fight view it will just remove the last fight from totals." },
	{ "MenuIgnore", "Ignore Combatant", "Remove this combatant and ignore future occurrrences until reset." },
	{ "MenuLock", "Lock Combatant", "Lock this combatant and their pets.  While locked, they will not be removed when you reset all other combatants." },
	{ "RecapAnchorTopLeft", "Anchor Top Left", "Anchor the window to grow from the top left." },
	{ "RecapAnchorTopRight", "Anchor Top Right", "Anchor the window to grow from the top right." },
	{ "RecapAnchorBottomLeft", "Anchor Bottom Left", "Anchor the window to grow from the bottom left." },
	{ "RecapAnchorBottomRight", "Anchor Bottom Right", "Anchor the window to grow from the bottom right." },
	{ "Total", "Effects", "This is the total damage or healing (actual, which is raw healing minus overhealing) this effect accumulated since last reset." },
	{ "TotalDmg", "Dmg Effects", "This is the total damage this effect accumulated since last reset." },
	{ "TotalHeal", "Heal Effects", "This is the total healing (actual, which is raw healing minus overhealing) this effect accumulated since last reset." },
	{ "Max", "Max Hit", "This is the maximum damage or healing this effect done in one attack since last reset." },
	{ "Avg", "Average Hit", "This is the average damage or healing this effect done in one attack since last reset." },
	{ "CritP", "Crit Rate", "This is the average crit rate of this effect since last reset." },
	{ "MissPOverP", "Miss Rate/Overhealing Rate", "For damage effects, this is the miss rate of the effect.  For healing, this is the overheal rate of the effect." },
	{ "TotalPS", "Damage or Healing per second", "For damage, this is DPS.  For healing, this is HPS." },
	{ "TotalPSDmg", "Damage per second", "Damage per second (DPS)." },
	{ "TotalPSHeal", "Healing per second", "Healing per second (HPS)." },
	{ "Contribution", "Contribution", "This is the relative amount each effect contributed to the combatant's damage or healing." },
	{ "OtherHits", "Hits", "The number of times this effect occurred." },
	{ "OtherTotal", "Total", "The total amount gained or lost for this effect.  For some effects this simply echoes the number of hits." },
	{ "Attribute", "Attribute", "The attribute gained or lost for this effect." },
	{ "HeaderDPSvsAll", "DPS vs All", "This is the Damage Per Second each combatant, done over the total duration of everyone doing damage." },
	{ "HeaderOver", "Overhealing", "This is an overhealing percentage per combatant in the group for All Fights.\n\nUse with caution as an indication of healer capability or contribution." },
	{ "ReportFightsToClipboard", "Report Fights to Clipboard", "This will report on the current combatants to a window from which you can copy to other programs like Notepad, TextEdit, or web forums." },
	{ "ReportDetailsToClipboard", "Report Details to Clipboard", "This will report on the player's personal details to a window from which you can copy to other programs like Notepad, TextEdit, or web forums." },
	{ "ShowSelfView", "Show Personal Details", "This will display your damage and healing details in the main window." },
	{ "HideSelfView", "Hide Personal Details", "This will dismiss your personal damage and healing details and return to all combatants in the main window." },
	{ "ResetSelfView", "Reset Personal Details", "This will wipe all personal damage and healing details accumulated in this window.  Your information in the detail panel will not be affected." },
	{ "ResetEffect", "Reset Effect", "This will reset this effect only from personal details." },
	{ "HeaderEName", "Spell or Ability", "These are the effects you've used since you last reset.  Damaging effects are green, healing effects are blue." },
	{ "HeaderEElement", "Effect Element", "This is the element (Arcane, Fire, Holy, etc.) of this effect." },
	{ "HeaderETotal", "Effect Totals", "This is the total amount of each effects' damage or healing (theoretical) since you last reset." },
	{ "HeaderETotalP", "Effect Contributions", "This is the contribution of each effect to the total damage or healing (theoretical) since you last reset." },
	{ "HeaderEMaxAll", "Max Damage or Heal", "This is the maximum damage or healing (theoretical) done by each effect in one hit, tick or crit." },
	{ "HeaderEGlances", "Number of Glances", "This is the number of times each effect hit as a glancing blow." },
	{ "HeaderEGlancesAvg", "Average Glance", "This is the average damage per glancing blow." },
	{ "HeaderEGlancesMax", "Max Glance", "This is the maximum damage in a single glancing blow." },
	{ "HeaderEHits", "Number of Hits", "This is the number of times each effect hit without a crit." },
	{ "HeaderEHitsAvg", "Average Hit", "This is the average damage or healing (theoretical) per non-crit hit of each effect." },
	{ "HeaderEHitsMax", "Max Hit", "This is the maximum damage or healing (theoretical) in a single non-crit hit of each effect." },
	{ "HeaderETicks", "Number of Ticks", "This is the number of times each effect ticked for damage or healing (theoretical)." },
	{ "HeaderETicksAvg", "Average Tick", "This is the average damage or healing (theoretical) per tick of each effect." },
	{ "HeaderETicksMax", "Max Tick", "This is the maximum damage or healing (theoretical) from a single tick of each effect." },
	{ "HeaderECrits", "Number of Crits", "This is the number of times each effect crit." },
	{ "HeaderECritsAvg", "Average Crit", "This is the average damage or healing (theoretical) per crit of each effect." },
	{ "HeaderECritsMax", "Max Crit", "This is the maximum damage or healing (theoretical) from a single crit of each effect." },
	{ "HeaderECritsP", "Crit Rate", "This is the crit rate of each effect, a percentage of hits attempted.  Ticks cannot crit and are not included." },
	{ "HeaderEMiss", "Misses", "This is the number of times each effect missed.  This includes miss, resist and deflect for non-melee, and also dodge, parry and block for melee." },
	{ "HeaderEMissP", "Miss Rate", "This is the percentage of attempted hits that missed for each effect." },
	{ "HeaderEGlancesMin", "Min Glance", "This is the minimum damage in a single glancing blow." },
	{ "HeaderEHitsMin", "Min Hit", "This is the minimum damage or healing (theoretical) in a single non-crit hit of each effect." },
	{ "HeaderETicksMin", "Min Tick", "This is the minimum damage or healing (theoretical) from a single tick of each effect." },
	{ "HeaderECritsMin", "Min Crit", "This is the minimum damage or healing (theoretical) from a single crit of each effect." },
	{ "StartSync", "Start Synchronization", "This button will broadcast an invitation to synchronize to the group, with you as synchronization leader.  You will leave your current synchronization, and Recap will Reset All Fights.  You will receive notification of players accepting or declining your invitation.\n\nAnyone in a group may start a synchronization." },
	{ "ManualSync", "Manual Synchronization", "This button will synchronize immediately.  Normally Recap synchronizes automatically at the end of each fight, but sometimes you may wish to synchronize manually.\n\nDoes nothing if Recap is in combat.\n\nIn addition, causes all members of the synchronization to send their own summary data, which will result in every member having all combatants." },
	{ "BecomeLeader", "Become Leader", "This button will make you leader of the synchronization, to replace a missing leader, and will do a manual synchronization to broadcast the fact.\n\nDoes nothing if Recap is in combat." },
	{ "ListMembers", "List Members", "This button will display a list of the members of the synchronization on your console.  Those who are active will be listed first, followed by those who are inactive (that is, not heard from within the past ten seconds)." },
	{ "ClearInactiveMembers", "Clear Inactive Members", "Remove from the list those who have not been heard from within the past ten seconds.  Removing them from your list does not exclude them from the synchronization.  If they become active again they will reappear on the list.  Removing them from your list does not remove them from any other player's list." },
	{ "SkipNextFight", "Skip Next Fight", "This button will skip the next fight.  Recap will automatically resume tracking following the end of the next fight.\n\nEnabled for the leader of the synchronization.\n\nIf pressed during combat, only the remainder of the current fight will be skipped.\n\nThis button could be used, for example, to skip the chess event in Karazhan.\n\nThe button is also enabled for people who are not in a synchronization." },
	{ "TargetTotal", "Target of Outgoing", "This is the damage or healing done to this target since last reset." },
	{ "SourceTotal", "Source of Incoming", "This is the damage or healing received from this source since last reset." },
	{ "ContributionWhom", "Contribution", "This is the relative amount contributed to the target's or source's damage or healing." },
	{ "RecentIncomingEvents", "Recent Incoming Events (or Deaths) (or detail entries)", "These are recent events that happened to this combatant or to these combatants, perhaps filtered by effect; and perhaps limited to dispels and interrupts.\n\nAlso used for a summary of recent deaths.\n\nAlso used for detail entries." },
	{ "RecentOutgoingEvents", "Recent Outgoing Events", "These are recent events generated by this combatant, perhaps filtered by effect." },
	{ "ShowRecent", "Show Recent Events", "Requires Recent Data Mode.\n\nShow a panel with recent incoming and outgoing events for a combatant, or for a spell or ability for a combatant.\n\nThis feature can be enabled or disabled using the Recent Data Mode check box on the Options / Settings tab." },
	{ "ShowRecentEffect", "Show Recent Events for Effect", "Requires Recent Data Mode.\n\nShow a panel with recent incoming and outgoing events for this spell or ability for a combatant.\n\nThis feature can be enabled or disabled using the Recent Data Mode check box on the Options / Settings tab." },
	{ "ShowGroupTotal", "Show Group Total", "Show a panel with total combined details for combatants in the group." },
	{ "ShowNonGroupTotal", "Show Non-Group Total", "Show a panel with total combined details for combatants not in the group." },
	{ "IgnoreEdit", "Effect to Ignore", "Enter a new effect to add to the ignore list by typing the spell ID here; or select an effect listed above for removal.\n\nTo add a new effect you need to know its spell ID.\n\nIgnored effects will no longer count towards damage or healing, but will still show up in other contexts.\n\nIgnoring an effect does not remove existing data for the effect.\n\nNote that the list of effects to ignore is shared among all characters." },
	{ "AddIgnore", "Add Effect to Ignores", "Add this effect to the list of effects to ignore." },
	{ "RemoveIgnore", "Remove Effect from Ignores", "Remove this effect from the list of effects to ignore." },
	{ "AddSuggestedIgnores", "Add Suggested Effects to Ignores", "Add to this list all of the Recap recommended effects to ignore.  At the moment these are effects which causes a player to heal a boss, thus distorting numbers in the Heal column.  If you don't use the Heal column, then don't bother." },
	{ "CloseLoad", "Close Loaded Data Set Panel", "Close the panel.  To view the panel again, load the same Data Set, or a new Data Set, from the Options / Data Sets tab." },
	{ "Name", "Combatants", "This is a list of all combatants that did damage, took damage, or healed in this fight or set of fights." },
	{ "LoadName", "Combatants", "This is a list of all combatants that did damage, took damage, or healed in this loaded Data Set." },
	{ "StartingHints", "Getting started:\n\nEasy:   Check out the tooltips\nMedium:   See Recap_Quick_Start.rtf in the Recap\\Docs folder\nAdvanced:   Study readme_FAQ.txt in the Recap\\Docs folder", "|cFF9090FF\nTo post Recap information to others:\n\n•• Open almost any chat edit box (for example '/p', '/g', or '/w Hawksy'), and leave it open.\n\n•• Then shift+click on almost anything in Recap that highlights in light yellow when you mouse over it.  The Recap information will be posted to that chat.\n\n•• To post to your own console, shift+click without having a chat edit box open.\n\n•• To post directly to the Recap clipboard (for export), hold down the control key as well, that is, use control+shift+click." },
	{ "CopyGlobalSettingsToCharacter", "Copy Global Settings to this Character", "The global settings will be copied and used in future for this character.\n\nIf Use Global Settings is currently off, your UI will be reloaded." },
	{ "RecentEvents", "Report All Recent Events", "Requires Recent Data Mode.\n\nIf the Recent Data Mode is enabled, clicking this button will bring up a panel with all recent events (damage, healing, dispels, interrupts, and deaths)." },
	{ "RecentDispelsAndInterrupts", "Report Recent Dispels and Interrupts", "Requires Recent Data Mode.\n\nIf the Recent Data Mode is enabled, clicking this button will bring up a panel with all recent dispels and interrupts." },
	{ "RecentDeaths", "Report Recent Deaths", "Requires Recent Data Mode.\n\nIf the Recent Data Mode is enabled, clicking this button will post the last sources of damage received before death for group combatants who have died within the last few fights." },
	{ "PreviousEOF", "Previous End of Fight", "Position recent events to the previous end of fight, showing all events." },
	{ "NextEOF", "Next End of Fight", "Position recent events to the next end of fight, showing all events." },
	{ "CloseClipboard", "Close Clipboard", "Close this clipboard panel." },
	{ "ShowRecap", "Show Recap", "Show the Recap main panel." },
	{ "ForceShowRecap", "Force Show Recap", "For emergency use if you can't find the Recap main panel anywhere.\n\nShow the Recap main panel; all Recap panels are centred; the Recap scale is reset to 1.0; and Recap is resumed if it was paused." },
	{ "ShowRecapOptions", "Show Recap Options", "Show the Recap Options panel." },
	{ "LiveGraphAndText", "Show Live Graph & Text", "Requires Live Data Mode.\n\nIf the Live Data Mode is enabled, clicking this button will bring up a panel with a graph of live outgoing DPS, incoming DPS, or outgoing HPS for group combatants for the current fight.\n\nThe panel can also show live text listings for the same information." },
	{ "CloseGraph", "Close Live Graph & Text", "Close this live graph and text listing panel.\n\nOnce closed, the panel will open again automatically at the beginning of the next fight involving group combatants.\n\nThere is a button at the bottom of the main Fights panel for opening or re-opening the Live Graph & Text panel manually.\n\nIf you want the panel to go away permanently, turn off the Live Data Mode option on the Options / Setting tab." },
	{ "GraphCheckbox", "Show or Hide this Combatant", "When checked, this combatant will be shown in the live graphs and live text listings." },
	{ "GraphCombatant", "Add or Remove Featuring for this Combatant", "Clicking a checked combatant will highlight the combatant by dimming other combatant live graph and live text entries.  Clicking a second time will remove the dimming.\n\nMore than one combatant can be highlighted at a time." },
	{ "ShowDPSOut", "Show DPS Out for Live Graph & Text", "Clicking on this button will set the live graph and the live text to show outgoing DPS for group combatants." },
	{ "ShowDPSIn", "Show DPS In for Live Graph & Text", "Clicking on this button will set the live graph and the live text to show incoming DPS for group combatants." },
	{ "ShowHPSOut", "Show HPS Out for Live Graph & Text", "Clicking on this button will set the live graph and the live text to show outgoing HPS for group combatants." },
	{ "CheckAll", "Check All Combatants", "Clicking on this button will mark all checkboxes to show all group combatants on the live graph and the live text listing (for whichever of outgoing DPS, incoming DPS, or outgoing HPS is currently selected).\n\nWARNING: If you are looking at a graph, selecting all 25 combatants in a raid will approximately double the amount of addon CPU time used by Recap.  There is much less of an increase if you are only looking at a text listing.\n\nWhen looking at graphs, select only the combatants that you need to be watching (unless you have a top end computer)." },
	{ "UncheckAll", "Uncheck All Combatants", "Clicking on this button will clear all checkboxes to hide all group combatants on the live graph and the live text (for whichever of outgoing DPS, incoming DPS, or outgoing HPS is currently selected)." },
	{ "ShowLiveGraph", "Show Live Graph", "Clicking on this button will switch to the live graph view.  You will see live graph traces for group combatants." },
	{ "ShowLiveText", "Show Live Text", "Clicking on this button will switch to the live text view.  You will see live text entries for group combatants." },
	{ "ShowGraphOptions", "Show Combatant Options", "Clicking on this button will show a panel with combatant options for the live graph and live text displays.\n\nYou can choose which combatants to display per graph & text type; and highlight one or more combatants by dimming all other combatants.\n\nGroup combatants appear in descending order of total damage dealt, damage received, or healing done (taken from the All Fights panel), so the order may change for subsequent fights.  If there are no total numbers yet, combatants appear in alphabetical order." },
	{ "HideGraphOptions", "Hide Combatant Options", "Clicking on this button will hide the panel with combatant options for the live graph and live text displays." },
	{ "GraphHeadingName", "Combatant Name", "This is the name of the group combatant." },
	{ "GraphHeadingTotal", "Total Dmg Out, Dmg In, or Healing Out", "Total damage dealt, total damage received, or total healing done so far in this live fight for this combatant.\n\nGroup combatants appear in descending order of total damage dealt, damage received, or healing done (taken from the All Fights panel), so the order may change from fight to fight.  If there are no total numbers available yet, combatants appear in alphabetical order." },
	{ "GraphHeadingPeak", "Peak Dmg Out, Dmg In, or Healing Out", "Peak outgoing DPS, peak incoming DPS, or peak outgoing HPS so far in this live fight for this combatant.  These values are averages using a moving 6-second window." },
	{ "GraphHeadingAvg", "Average Dmg Out, Dmg In, or Healing Out", "Average effective outgoing DPS, average incoming DPS, or average effective outgoing HPS so far in this live fight for this combatant.\n\nThese values are the total amount divided by the overall fight time, and as a result will differ from the values shown in the Recap Fight panel." },
	{ "GraphOpaqueBackground", "Graph Opaque Background", "When checked, the Live Graph & Text panel has an opaque black background.\n\nThis option will always begin turned off when logging in or reloading the UI, for better visibility during combat." },
	{ "GraphPause", "Pause Data Collection for Live Graph & Text", "Click here to stop data collection for live graphs and text listings.  This is to allow you to continue to examine the current graphs and text listings.\n\nPausing and resuming live data collection does not affect other Recap functions.\n\nWarning: If you pause live data collection and if a new fight begins, you will not be collecting data for that new fight.  When you resume later, then the data that you collect, and the graphs and text listings that you then see, will have bits of the fight missing." },
	{ "GraphResume", "Resume Data Collection for Live Graph & Text", "The collection of data for live graphs and text listings is currently suspended.  Click here to resume data collection.\n\nPausing and resuming live data collection does not affect other Recap functions.\n\nNote that any fight involving the group will not be recorded while live data collection is paused, and those parts of the fight will not appear in subsequent live graphs and text listings." },
};


--[[ localized strings for the xml labels ]]

-- Bindings.xml (names generated in Bindings.xml)
BINDING_HEADER_RECAP = "Recap"
BINDING_NAME_RECAP_HIDE_SHOW = "Hide / Show"
BINDING_NAME_RECAP_PAUSE_RESUME = "Pause / Resume"
BINDING_NAME_RECAP_TOGGLE_FIGHTS = "Toggle Last/All Fights"
BINDING_NAME_RECAP_OPTIONS = "Recap Options"
BINDING_NAME_RECAP_RESET_ALL = "Reset All Fights"
BINDING_NAME_RECAP_RESET_LAST = "Reset Last Fight"
BINDING_NAME_RECAP_RESET_DETAILS = "Reset Personal Details"
BINDING_NAME_RECAP_RESET_FIGHTS_DETAILS = "Reset Fights and Details"
BINDING_NAME_RECAP_SAVE_ALL_FIGHTS = "Save All Fights"
BINDING_NAME_RECAP_SAVE_LAST_FIGHT = "Save Last Fight"
BINDING_NAME_RECAP_SKIP_NEXT_FIGHT = "Skip Next Fight"

-- Bindings.xml
RECAP_ALL_FIGHTS_RESET = "All Fights reset"
RECAP_LAST_FIGHT_RESET = "Last Fight reset"
RECAP_DETAILS_RESET = "Personal Details reset"
RECAP_FIGHTS_DETAILS_RESET = "Fights and Details reset"
RECAP_SYNCHRONIZATION_RESET = "Sychronization reset"
RECAP_ALL_FIGHTS_SAVED = "All Fights saved"

-- Recap.xml
RECAP_RECAP = "Recap"
RECAP_RESET = "Reset"
RECAP_EVENTS = "Events"
RECAP_DISPELS_AND_INTERRUPTS = "Dispels & Interrupts"
RECAP_COMBATANTS = "Combatants"
RECAP_SEEN = "Seen"
RECAP_DIED = "Died"
RECAP_TIME = "Time Out"
RECAP_TIME_IN = "Time In"
RECAP_TIME_HEAL = "Time Heal"
RECAP_HEAL = "Heal"
RECAP_DMG_IN = "Dmg In"
RECAP_DMG_OUT = "Dmg Out"
RECAP_MAX = "Max"
RECAP_HPS = "HPS"
RECAP_DPS_IN = "DPS In"
RECAP_DPS = "DPS"
RECAP_DPS_PER_GEAR = "DPS/Gear"
RECAP_DPS_ALL = "DPS+"
RECAP_MISS = "Miss"
RECAP_RECENT = "Recent"
RECAP_RECENT_COLON = "Recent:"
RECAP_TOTAL_DETAILS = "Total"

-- RecapOptions.xml : Display
RECAP_DATA_SET_NAME = "Data Set Name"
RECAP_SAVED = "Saved"
RECAP_RECAP_OPTIONS = "Recap Options"
RECAP_DISPLAY = "Display"
RECAP_SETTINGS = "Settings"
RECAP_DATA_SETS = "Data Sets"
RECAP_REPORTS = "Reports"
RECAP_OK = "Ok"
RECAP_DISPLAY_IN_LIST = "Display in List"
RECAP_NUMBERED_LIST = "Numbered List"
RECAP_FACTION_LEVEL = "Faction/Level"
RECAP_CLASS = "Class"
RECAP_FIRST_SEEN = "First Seen"
RECAP_DEATHS = "Deaths"
RECAP_HEALS = "Heals"
RECAP_HEALS_P = "Heals %"
RECAP_DAMAGE_IN = "Damage In"
RECAP_DAMAGE_IN_P = "Damage In %"
RECAP_DAMAGE_OUT = "Damage Out"
RECAP_DAMAGE_OUT_P = "Damage Out %"
RECAP_HEALS_OUT = "Heals Out"
RECAP_MAX_HIT = "Max Hit"
RECAP_DPS_VS_ALL = "DPS vs All"
RECAP_OVERHEALING = "Overhealing"
RECAP_DISPLAY_MINIMIZED = "Display Minimized"
RECAP_STATUS_LIGHT = "Status Light"
RECAP_SYNC_LIGHT = "Sync Light"
RECAP_LAST_ALL = "Last/All"
RECAP_YOUR_DPS = "Your DPS Out"
RECAP_YOUR_PET_PERCENT = "Your Pet Percent"
RECAP_MIN_DPS_IN = "Total DPS In"
RECAP_MIN_DPS_OUT = "Total DPS Out"
RECAP_YOUR_HPS = "Your HPS"
RECAP_MIN_HPS = "Total HPS"
RECAP_BUTTONS = "Buttons"
RECAP_BACKGROUND = "Background"
RECAP_MAXIMUM_ROWS = "Maximum Rows"
RECAP_SHOW_GAUGES = "Show Gauges"
RECAP_ANCHOR = "Anchor"
RECAP_DISPLAY_PERSONAL_DETAILS = "Personal Details"
RECAP_SELF_EELEMENT = "Element"
RECAP_SELF_ETOTAL = "Total"
RECAP_SELF_ETOTALP = "Total %"
RECAP_SELF_EGLANCES = "Glances"
RECAP_SELF_EGLANCESMIN = "Min Glance"
RECAP_SELF_EGLANCESAVG = "Avg Glance"
RECAP_SELF_EGLANCESMAX = "Max Glance"
RECAP_SELF_EHITS = "Hits"
RECAP_SELF_EHITSMIN = "Min Hit"
RECAP_SELF_EHITSAVG = "Avg Hit"
RECAP_SELF_EHITSMAX = "Max Hit"
RECAP_SELF_ETICKS = "Ticks"
RECAP_SELF_ETICKSMIN = "Min Tick"
RECAP_SELF_ETICKSAVG = "Avg Tick"
RECAP_SELF_ETICKSMAX = "Max Tick"
RECAP_SELF_ECRITS = "Crits"
RECAP_SELF_ECRITSMIN = "Min Crit"
RECAP_SELF_ECRITSAVG = "Avg Crit"
RECAP_SELF_ECRITSMAX = "Max Crit"
RECAP_SELF_ECRITSP = "Crit %"
RECAP_SELF_EMISS = "Misses"
RECAP_SELF_EMISSP = "Miss %"
RECAP_SELF_EMAXALL = "Max Damage"
-- RecapOptions.xml : Settings
RECAP_WINDOW_OPTIONS = "Window Options"
RECAP_SHOW_TOOLTIPS = "Show Tooltips"
RECAP_SHOW_CLICK_HINTS = "Show Click Hints"
RECAP_TOOLTIPS_AT_POINTER = "Tooltips at Pointer"
RECAP_SHOW_DETAILS = "Show Details"
RECAP_OPAQUE_BACKGROUND = "Opaque Background"
RECAP_MINIMIZE_ON_ESCAPE = "Minimize on Escape"
RECAP_AUTO_HIDE_IN_COMBAT = "Auto Hide in Combat"
RECAP_AUTO_MINIMIZE = "Auto Minimize"
RECAP_AUTO_FADE_WINDOW = "Auto Fade Window"
RECAP_SCALING = "Scaling"
RECAP_FIGHT_OPTIONS = "Fight Options"
RECAP_LIMIT_FIGHTS_TO_COMBAT = "Limit Fights to Combat"
RECAP_LIMIT_FIGHTS_TO_ENCOUNTERS = "Limit Fights to Encounters"
RECAP_ONLY_COMBATANTS_WITH_DURATION = "Only Combatants with Duration"
RECAP_ONLY_UNIQUE_COMBATANTS = "Only Unique Combatants"
RECAP_HIDE_GROUP = "Hide Group"
RECAP_HIDE_OTHERS = "Hide Other Combatants"
RECAP_STORE_ONLY_DISPLAYED_COMBATANTS = "Store Only Displayed Combatants"
RECAP_MERGE_PETS_WITH_OWNERS = "Merge Pets with Owners"
RECAP_MERGE_ALL_PETS_INTO_ONE_PET = "Merge All Pets into One Pet"
RECAP_IGNORE_GLOBAL_UNIQUE_IDENTIFIERS = "Ignore Global Unique Identifiers"
RECAP_LIBDATABROKER_SUPPORT = "LibDataBroker Support"
RECAP_END_FIGHT_IF_IDLE = "End Fight if Idle"
RECAP_END_FIGHT_DELAY = "End Fight Delay"
RECAP_DATA_OPTIONS = "Data Options"
RECAP_LIGHT_DATA_MODE = "Light Data Mode"
RECAP_OTHER_DATA_MODE = "Other Data Mode"
RECAP_MATRIX_DATA_MODE = "Matrix Data Mode"
RECAP_RECENT_DATA_MODE = "Recent Data Mode"
RECAP_LIVE_DATA_MODE = "Live Data Mode"
RECAP_WARN_DATA = "Warn on Data Growing Too Large"
RECAP_OTHER_OPTIONS = "Other Options"
RECAP_REMIND_GROUP_STATUS = "Remind on Join or Leave Group"
RECAP_REMIND_INSTANCE_STATUS = "Remind on Enter or Leave Instance"
RECAP_PAUSE_OUTSIDE_INSTANCES = "Pause Outside Instances"
RECAP_PAUSE_INSIDE_BATTLEGROUNDS = "Pause Inside Battlegrounds"
RECAP_RESET_ON_LOGOUT = "Reset on Logout"
RECAP_USE_GLOBAL_SETTINGS = "Use Global Settings"
RECAP_COPY_GLOBAL_TO_CHARACTER = "Copy Global to Character"
-- RecapOptions.xml : Data Sets
RECAP_FIGHT_DATA_SETS = "Fight Data Sets"
RECAP_SAVE_GROUP_COMBATANTS_ONLY = "Save Group Combatants Only"
RECAP_AUTOMATICALLY_SAVE_BOSS_FIGHTS = "Automatically Save Boss Fights"
RECAP_SAVE_ALL = "Save All"
RECAP_SAVE_LAST = "Save Last"
RECAP_LOAD = "Load"
RECAP_LOAD_INTO_ALL_FIGHTS = "Load into All Fights"
RECAP_DELETE = "Delete"
RECAP_DELETE_ALL = "Delete All"
RECAP_RENAME = "Rename"
-- RecapOptions.xml : Reports
RECAP_FIGHT_REPORTING = "Fight Reporting"
RECAP_REPORT_RANKS_IN_MULTIPLE_ROWS = "Report in Multiple Rows (Shift+Click and Autopost)"
RECAP_POST_IN_COLUMNS = "Post in Columns"
RECAP_AUTOMATICALLY_POST_RANKS_AFTER_EACH_FIGHT = "Automatically Post Ranks After Each Fight"
RECAP_AUTOMATICALLY_POST_CHANGES_IN_LEADERSHIP = "Automatically Post Changes in Leadership"
RECAP_AUTOMATICALLY_POST = "Automatically Post:"
RECAP_AUTOMATICALLY_POST_TO = "To Channel:"
RECAP_WOWCHATLOG_TXT = "Report to WoWChatLog.txt"
RECAP_OPEN_WOWCHATLOG_TXT = "Open"
RECAP_ACQUIRING_CHANNEL = "Acquiring channel..."
RECAP_CHANNEL_JOINED = "Channel joined"
RECAP_REPORT_TO_WOWCHATLOG_TXT = "Report"
RECAP_CLOSE_WOWCHATLOG_TXT = "Close"
-- RecapOptions.xml : Clipboard
RECAP_CLIP_EXPLANATION = "|cFF9090FFSelect some text. CTRL+A selects it all.\nPress CTRL+C to copy the selected text.\nThen go to another text window and CTRL+V to paste it there.  Press ESC or click the X when done."
RECAP_CLIPBOARD = "Clipboard"
RECAP_REPORT_FIGHTS_TO_CLIPBOARD = "Report Fights"
RECAP_REPORT_DETAILS_TO_CLIPBOARD = "Report Details"
RECAP_WRITE_ONLY_GROUP = "Report Only Combatants in Group"
RECAP_FORMAT_IN_HTML = "Report Format in HTML"
RECAP_TAB_DELIMITED_FORMAT = "Tab-Delimited Report Format"
-- RecapOptions.xml : Synchronization
RECAP_SYNC = "Sync"
RECAP_SYNCHRONIZATION = "Synchronization"
RECAP_ENABLE_SYNC = "Enable Synchronization"
RECAP_SYNC_STATE_IGNORE = "Ignoring synchronization"
RECAP_SYNC_STATE_READY = "Waiting for synchronization"
RECAP_SYNC_STATE_MEMBER = "Member of a synchronization"
RECAP_SYNC_STATE_LEADER = "Leader of a synchronization"
RECAP_START_SYNC = "Start Synchronization"
RECAP_MERGE_PETS_OFF = "<== with Merge Pets off"
RECAP_MERGE_PETS_ON = "<== with Merge Pets on"
RECAP_MANUAL_SYNC = "Manual Synchronization"
RECAP_BECOME_LEADER = "Become Leader"
RECAP_LIST_MEMBERS = "List Members"
RECAP_CLEAR_INACTIVE_MEMBERS = "Clear Inactive Members"
RECAP_SKIP_NEXT_FIGHT = "Skip Next Fight"
-- RecapOptions.xml : Effects to Ignore
RECAP_IGNORES = "Ignores"
RECAP_SPELLID = "Spell ID"
RECAP_SPELLNAME = "Spell Name"
RECAP_IGNORED_EFFECTS = "Ignored Effects"
RECAP_ADD = "Add"
RECAP_REMOVE = "Remove"
RECAP_ADD_SUGGESTED_IGNORES = "Add Suggested Ignores"
-- RecapOptions as shown in the Blizzard Addons pane
RECAP_SHOW_RECAP = "Show Recap"
RECAP_FORCE_SHOW_RECAP = "Force Show Recap"
RECAP_SHOW_RECAP_OPTIONS = "Show Recap Options"

-- RecapPanel.xml
RECAP_DAMAGE = "Damage"
RECAP_GLANCES = "Glances"
RECAP_HITS = "Hits"
RECAP_CRITS = "Crits"
RECAP_CRUSHES = "Crushes"
RECAP_AVERAGE = "Average"
RECAP_MISSED_DETAILS = "Missed Details"
RECAP_MISSED = "Missed"
RECAP_DODGED = "Dodged"
RECAP_PARRIED = "Parried"
RECAP_BLOCKED = "Blocked"
RECAP_ABSORBED = "Absorbed"
RECAP_DEFLECTED = "Deflected"
RECAP_EVADED = "Evaded"
RECAP_RESISTED = "Resisted"
RECAP_REFLECTED = "Reflected"
RECAP_IMMUNE = "Immune"
RECAP_SPELL_OR_ABILITY = "Spell or Ability"
RECAP_INCOMING_SPELL_OR_ABILITY = "Incoming Spell or Ability"
RECAP_OUTGOING_SPELL_OR_ABILITY = "Outgoing Spell or Ability"
RECAP_MISSES = "Misses"
RECAP_CASTS = "Casts"
RECAP_MIN = "Min"
RECAP_AVG = "Avg"
RECAP_SUMMARY = "Summary"
RECAP_LAST_FIGHT = "Last Fight"
RECAP_ALL_FIGHTS = "All Fights"
RECAP_TICKS = "Ticks"
RECAP_INCOMING = "Incoming"
RECAP_OUTGOING = "Outgoing"
RECAP_OTHER_EFFECTS = "Other Effects"
RECAP_TOTAL = "Total"
RECAP_ATTRIBUTE = "Attribute"
RECAP_DISPELS = "Dispels"
RECAP_INTERRUPTS = "Interrupts"
RECAP_STEALS = "Steals"
RECAP_TIMINGS = "Timings"
RECAP_INTERVALS = "Intervals"
RECAP_SECONDS = "seconds"
RECAP_SECS = "secs"
RECAP_DURATIONS = "Durations"
RECAP_INTERRUPT = "Interrupt"
RECAP_ESTIMATED_INTERVAL = "estimated interval"
RECAP_ESTIMATED_DURATION = "estimated duration"
RECAP_PARTIALS = "Partials"
RECAP_ABSORBS = "Absorbs"
RECAP_BLOCKS = "Blocks"
RECAP_RESISTS = "Resists"
RECAP_PART_RESIST = "Part Resist"
RECAP_ESTIMATED_TOTAL_RESISTED = "Estimated Total Resisted"
RECAP_TARGET_OF_OUTGOING = "Target of Outgoing"
RECAP_SOURCE_OF_INCOMING = "Source of Incoming"
RECAP_DETAIL_ENTRIES = "Detail Entries"

-- RecapRecent.xml
RECAP_RECENT_INCOMING_EVENTS = "Recent Incoming Events"
RECAP_RECENT_OUTGOING_EVENTS = "Recent Outgoing Events"
RECAP_RECENT_INCOMING_EFFECTS = "Recent Incoming Effects"
RECAP_RECENT_OUTGOING_EFFECTS = "Recent Outgoing Effects"
RECAP_RECENT_EVENTS = "Recent Events"
RECAP_RECENT_DISPELS_AND_INTERRUPTS = "Recent Dispels and Interrupts"
RECAP_RECENT_DEATHS = "Recent Deaths"

-- more miscellaneous display strings
RECAP_TIME_FIGHTING = "Time Doing Damage"
RECAP_TIME_DAMAGED = "Time Taking Damage"
RECAP_TIME_HEALING = "Time Healing"
RECAP_KILLS = "Kills"
RECAP_DPS_OUT = "DPS Out"
RECAP_DPS_IN = "DPS In"
RECAP_HPS_OUT = "HPS Out"
RECAP_TOTAL_DPS_OUT = "Total DPS Out"
RECAP_TOTAL_DPS_IN = "Total DPS In"
RECAP_CRIT_RATE = "Crit Rate"
RECAP_TEN_ROWS = "10 rows"
RECAP_FIVE_SECONDS = "5 seconds"
RECAP_TEN_SECONDS = "10 seconds"
RECAP_ONE_THOUSAND_EVENTS = "1000 events"
RECAP_GROUP_FIGHT_TIME = "Group Fight Time"
RECAP_GROUP_DPS = "Group DPS"
RECAP_ONE = "1.0"
RECAP_DURATION = "Duration"
RECAP_GRAPH = "Graph"
RECAP_TEXT = "Text"
RECAP_PEAK = "Peak"
RECAP_MORE_RIGHT = "more >"
RECAP_LESS_RIGHT = "< less"
RECAP_MORE_LEFT = "< more"
RECAP_LESS_LEFT = "less >"
RECAP_CHECK_ALL = "Check All"
RECAP_UNCHECK_ALL = "Uncheck All"
RECAP_LIVE_GRAPH_AND_TEXT = "Live Graph & Text"


--[[ miscellaneous localized strings ]]

recap_temp.Localize = {}
recap_temp.Localize.LastAll = { Last="Last Fight", All="All Fights" }
recap_temp.Localize.LastAllShort = { Last="Last", All="All" }
recap_temp.Localize.StoppedActiveIdle = { Stopped="Stopped", Active="Active", Idle="Idle" }
recap_temp.Localize.RankTop = "Rank Top"
recap_temp.Localize.None = "none"
recap_temp.Localize.Totals = "Totals"
recap_temp.Localize.Details = "Details"
recap_temp.Localize.Status = "Status"
recap_temp.Localize.NewLeader = "New leader"
recap_temp.Localize.With = "with"
recap_temp.Localize.Of = "of"
recap_temp.Localize.For = "for"
recap_temp.Localize.And = "and"
recap_temp.Localize.Max = "Max"
recap_temp.Localize.At = "At"
recap_temp.Localize.Seconds = "seconds"
recap_temp.Localize.Events = "events"
recap_temp.Localize.Rows = "rows"
recap_temp.Localize.Subtotal = "Subtotal"
recap_temp.Localize.Total = "Total"
recap_temp.Localize.Group = "Group"
recap_temp.Localize.NonGroup = "Non-Group"
recap_temp.Localize.ElementOther = "Other" --  Damage element not specified
recap_temp.Localize.ElementHealing = "Healing" --  Healing element not specified
recap_temp.Localize.Melee = "Melee"
recap_temp.Localize.Environment = "Environment"
recap_temp.Localize.OtherEffects = "Other Effects"
recap_temp.Localize.OwnedBy = "owned by"
recap_temp.Localize.VerboseLinkStart = "Recap %s: %s took %s damage over %s for %s DPS In (%s deaths); did %s damage over %s for %s DPS Out (max hit %d); did %s actual healing over %s for %s HPS Out"
recap_temp.Localize.VerboseGroupTotalStart = "Recap %s: Combatants in group took %s damage over %s for %s DPS In (%s deaths); did %s damage over %s for %s DPS Out (max hit %d); did %s actual healing over %s for %s HPS Out"
recap_temp.Localize.VerboseNonGroupTotalStart = "Recap %s: Combatants not in group took %s damage over %s for %s DPS In (%s deaths); did %s damage over %s for %s DPS Out (max hit %d); did %s healing over %s for %s HPS Out"
recap_temp.Localize.LinkRank = { Name="Combatant", Time="Time Doing Damage", TimeIn="Time Taking Damage", TimeHeal="Time Healing", MaxHit="Max Hit", DmgIn="Damage Taken", DmgOut="Damage Done", DPS="DPS Out", DPSPerGear="DPS/Gear", DPSIn="DPS In", Heal="Healing", HPS="Healing Per Second", Deaths="Deaths", HealP="Healing", DmgInP="Damage Taken", DmgOutP="Damage Done", DPSvsAll="DPS vs All", Over="Overhealing", Seen="First Seen", Dispels="Dispels", Class="Class", Interrupts="Interrupts" }
recap_temp.Localize.StatusTooltip = "When this light is red, fight monitoring is suspended.\n\nWhen this light is green, a fight is currently being monitored.\n\nWhen this light is off, Recap is idle and waiting for a fight to begin.\n"
recap_temp.Localize.RankUsage = "To post a recap to chat, open a chat window and leave it open, then shift+click the item that you wish to post, as follows:\n|cFFAAAAFF/p (shift+click on Time Out column header)|cFFFFFFFF <- sends a ranking of times to /p\n|cFFFF8000/ra (shift+click on DPS column header)|cFFFFFFFF <- sends a ranking of DPS Out to /ra\n\nOn the main or load panel, holding down the alt key (option key on a Mac) while shift+clicking a column header will post non-friendly combatants."
recap_temp.Localize.SkipChannels = { "General", "Trade", "WorldDefense", "LocalDefense", "LookingForGroup" }
recap_temp.Localize.OutgoingHealDetailLink = "Recap %s: %s: %s (%s) healed %s hp (%s of %s healing) (%s HPS)"
recap_temp.Localize.OutgoingHealDetailLinkNoElement = "Recap %s: %s: %s healed %s hp (%s of %s damage) (%s HPS)"
recap_temp.Localize.OutgoingDamageDetailLink = "Recap %s: %s: %s (%s) damaged %s hp (%s of %s damage) (%s DPS)"
recap_temp.Localize.OutgoingDamageDetailLinkNoElement = "Recap %s: %s: %s damaged %s hp (%s of %s damage) (%s DPS)"
recap_temp.Localize.TargetHealDetailLink = "Recap %s: %s healed %s %s hp (%s of %s healing)"
recap_temp.Localize.TargetDamageDetailLink = "Recap %s: %s damaged %s %s hp (%s of %s damage)"
recap_temp.Localize.IncomingHealDetailLink = "Recap %s: %s (%s) healed %s %s hp (%s of %s healing) (%s HPS)"
recap_temp.Localize.IncomingHealDetailLinkNoElement = "Recap %s: %s healed %s %s hp (%s of %s healing) (%s HPS)"
recap_temp.Localize.IncomingDamageDetailLink = "Recap %s: %s (%s) damaged %s %s hp (%s of %s damage) (%s DPS)"
recap_temp.Localize.IncomingDamageDetailLinkNoElement = "Recap %s: %s damaged %s %s hp (%s of %s damage) (%s DPS)"
recap_temp.Localize.SourceHealDetailLink = "Recap %s: %s healed %s %s hp (%s of %s healing)"
recap_temp.Localize.SourceDamageDetailLink = "Recap %s: %s damaged %s %s hp (%s of %s damage)"
recap_temp.Localize.OtherDetailLink = "Recap %s: %s: %s: %s occurred %s times %s"
recap_temp.Localize.OtherDetailType = { "Cast", "Cast", "Debuff/Loss", "Debuff/Loss", "Buff/Gain", "Buff/Gain", "Debuff/Buff/Other", "Debuff/Buff/Other" }
recap_temp.Localize.ConfirmLightData = "You've chosen to enable Light Data Mode."
recap_temp.Localize.ConfirmHeavyData = "You've chosen to disable Light Data Mode."
recap_temp.Localize.ConfirmLastReset = "You've chosen to reset the Last Fight.\n\nIf you accept, the information for the Last Fight will be SUBTRACTED from the All Fights data.  Be certain this is what you want.\n\nThis reset is not simply a clear command.\n\nIf you meant instead to reset All Fights, the middle button below will do that for you."
recap_temp.Localize.ConfirmLastResetCombatant = "You've chosen to reset the Last Fight.\n\nIf you accept, the information for the Last Fight will be SUBTRACTED from the All Fights data.  Be certain this is what you want.\n\nThis reset is not simply a clear command."
recap_temp.Localize.ConfirmLoadIntoAllFights = "Are you certain that you want to load the saved Data Set into the All Fights panel?  If you accept, your current All Fights data will be overwritten."
recap_temp.Localize.ConfirmDeleteFightDataSet = "Are you certain that you want to delete the selected saved Data Sets?\n\nThis action cannot be undone."
recap_temp.Localize.ConfirmDeleteAllFightDataSets = "Are you certain that you want to delete ALL of your saved Data Sets?\n\nThis action cannot be undone."
recap_temp.Localize.ConfirmRenameFightDataSet = "Modify the text in the edit box to rename the selected saved Data Set, then click Accept."
recap_temp.Localize.LastFightSaved = "Last Fight saved"
recap_temp.Localize.LogHeader = "__ Recap [%.3f] (%s): generated by %s for %s on %s in %s __"
recap_temp.Localize.LogFormat = "%35s ! %2s %3s !%10s %8s %6s %5s %7s %8s !%10s %8s %4s %7s !%10s %8s %4s %5s %7s %7s %6s"
recap_temp.Localize.LogFormatTabDelimited = "%35s	%2s	%3s	%10s	%8s	%6s	%5s	%7s	%8s	%10s	%8s	%4s	%7s	%10s	%8s	%4s	%5s	%7s	%7s	%6s"
recap_temp.Localize.Log = { "Name", "Lv", "Cls", "Time Out", "Damage", "%%", "Max", "DPS", "DPS/Gear", "Time In", "Tanking", "%%", "DPS In", "Time Heal", "Healing", "%%", "Over", "HPS", "Dispels", "Interrupts", "Deaths" }
recap_temp.Localize.HTMLHeader = "<tr><td colspan=\"15\">Recap [%.3f] (%s): generated by %s for %s on %s in %s</td></tr>"
recap_temp.Localize.HTMLFormat1 = "<tr align=\"right\"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
recap_temp.Localize.HTMLFormat2 = "<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
recap_temp.Localize.HTMLPrefix = "<table CELLPADDING=\"2\">"
recap_temp.Localize.HTMLSuffix = "</table>"
recap_temp.Localize.DetailHeader = "__ Recap %s generated with personal details for %s on %s in %s __"
recap_temp.Localize.DetailFormat = "%30s %18s !%8s %5s !%8s !%7s %6s %6s %6s !%5s %6s %6s %6s !%5s %6s %6s %6s !%5s %6s %6s %6s %7s !%4s %7s"
recap_temp.Localize.DetailFormatTabDelimited = "%30s	%18s	%8s	%5s	%8s	%7s	%6s	%6s	%6s	%5s	%6s	%6s	%6s	%5s	%6s	%6s	%6s	%5s	%6s	%6s	%6s	%7s	%4s	%7s"
recap_temp.Localize.Detail = { "Effect", "Element", "Total", "Pct", "Max", "Glances", "Min", "Avg", "Max", "Hits", "Min", "Avg", "Max", "Ticks", "Min", "Avg", "Max", "Crits", "Min", "Avg", "Max", "Pct", "Miss", "Pct" }
recap_temp.Localize.HTMLDetailHeader = "<tr><td colspan=\"24\">Recap %s generated by %s on %s in %s</td></tr>"
recap_temp.Localize.HTMLDetailFormat1 = "<tr align=\"right\"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
recap_temp.Localize.HTMLDetailFormat2 = "<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
recap_temp.Localize.HTMLDetailFormat3 = "<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
recap_temp.Localize.NoFreeChannels = "There are no channels free to create a log.  Leave a channel and try again."
recap_temp.Localize.NoChannelNumber = "Unable to acquire a channel number."
recap_temp.Localize.LogWritten = "Recap report written to WoWChatLog.txt"
recap_temp.Localize.ConfirmGlobalSettings = "You've chosen to enable global settings.\n\nIf you accept, the UI will be reloaded and a single global set of settings will be used."
recap_temp.Localize.ConfirmSeparateSettings = "You've chosen to disable global settings.\n\nIf you accept, the UI will be reloaded and every character will have their own settings."
recap_temp.Localize.LotsOfDataWarning = "Recap has %d combatants in the data for\n\n==>  %s  <==\n\nThis message doesn't mean you are out of memory.  It is just for your information.  You can turn this warning off on the Options / Settings tab.\n"
recap_temp.Localize.SavedDataSetsSizeWarning = "Recap has more than %d Mbytes of saved Data Sets.\n\nYou may wish to delete saved Data Sets that you no longer need (see Options / Data Sets).\n\nYou can turn this warning off on the Options / Settings tab.\n"
recap_temp.Localize.DamagedDataWarning = "Recap has detected possible damage to the saved settings and combatant data for %s.\n\nThe settings have been restored from backup.\n\nThe combatant data has not been restored.  If you are a bit of a computer geek you can rescue the data file now, before logging out.  Check in the folder\n\nWorld of Warcraft/WTF/Account/<account name>/%s/%s/SavedVariables\n\nfor the Recap.lua data file and copy it to a safe place.\n\nIf you edit the file using a text editor, you might be able to rescue most of the combatant data.  Try deleting some of the recap_combatants table.\n"
recap_temp.Localize.VersionCheck = "Recap program files may be damaged.  Try removing the Recap folder, then re-installing from a freshly downloaded copy of Recap."
recap_temp.Localize.ConfirmIgnoreGUIDs = "You've chosen to ignore global unique identifiers.\n\nIf you accept, Recap will be reset and synchronization will not be allowed."
recap_temp.Localize.ConfirmUseGUIDs = "You've chosen to use global unique identifiers.\n\nIf you accept, Recap will be reset."
recap_temp.Localize.ConfirmDisableLDBSupport = "You've chosen to disable LibDataBroker support.\n\nIf you accept, the UI will be reloaded."
recap_temp.Localize.NotAllowedDuringCombat = "Recap: Not allowed during combat"
recap_temp.Localize.InvitesYouToSynchronize = "invites you to synchronize"
recap_temp.Localize.NewSynchronization = "new synchronization"
recap_temp.Localize.OngoingSynchronization = "ongoing synchronization"
recap_temp.Localize.AcceptedSync = "accepted your invitation to synchronize"
recap_temp.Localize.DeclinedSync = "declined your invitation to synchronize"
recap_temp.Localize.AsksYouToPause = "asks you to pause Recap"
recap_temp.Localize.AsksYouToResume = "asks you to resume Recap"
recap_temp.Localize.MergePetsOff = "Merge Pets off"
recap_temp.Localize.MergePetsOn = "Merge Pets on"
recap_temp.Localize.IgnoreGUIDsOn = "Ignore GUIDs on"
recap_temp.Localize.Timestamp = "Timestamp"
recap_temp.Localize.Leader = "Leader"
recap_temp.Localize.LastUpdateWas = "Last update was"
recap_temp.Localize.Ago = "(hh:mm:ss) ago"
recap_temp.Localize.SkipNextFightBegins = "Skip Next Fight begins"
recap_temp.Localize.SkipNextFightEnds = "Skip Next Fight ends"
recap_temp.Localize.NotAllowedDuringSync = "Recap: Not allowed during synchronization."
recap_temp.Localize.RemindJoinGroup = "Recap: You have just joined a group.  This is your reminder to do whatever it is that you wanted to be reminded to do.\n\nA button to Reset All Fights is enabled if you aren't in a synchronization."
recap_temp.Localize.RemindLeaveGroup = "Recap: You have just left a group.  This is your reminder to do whatever it is that you wanted to be reminded to do."
recap_temp.Localize.RemindEnterInstance = "Recap: You have just entered an instance.  This is your reminder to do whatever it is that you wanted to be reminded to do.\n\nA button to Reset All Fights is enabled if you aren't in a synchronization."
recap_temp.Localize.RemindLeaveInstance = "Recap: You have just left an instance.  This is your reminder to do whatever it is that you wanted to be reminded to do."
recap_temp.Localize.NoBackupSettings = "Recap: So sorry, I've checked behind the refrigerator and underneath the karaoke machine, but I can't seem to find any backed up settings for this character.  Default settings have been used."
recap_temp.Localize.DataSetNameAlreadyExists = "Recap: Your proposed data set name already exists (or is blank)."
recap_temp.Localize.OutOfDateSyncVersion = "You are unable to join a synchronization because you have an older and incompatible version of Recap."
recap_temp.Localize.SynchronizationComplete = "Synchronization complete."
recap_temp.Localize.SyncMembers = "Synchronization members"
recap_temp.Localize.InactiveSyncMembers = "Inactive synchronization members"
recap_temp.Localize.InSync = "in sync"
recap_temp.Localize.Unknown = "Unknown"
recap_temp.Localize.Removed = "removed"
recap_temp.Localize.OtherDataModeNotEnabled = "Other Data Mode is not enabled"
recap_temp.Localize.MatrixDataModeNotEnabled = "Matrix Data Mode is not enabled"
recap_temp.Localize.RecentDataModeNotEnabled = "Recent Data Mode is not enabled"
recap_temp.Localize.LiveDataModeNotEnabled = "Live Data Mode is not enabled"
recap_temp.Localize.NotAvailable = "Not available"
recap_temp.Localize.Entities = "Entities"
recap_temp.Localize.Attacks = "Attacks"
recap_temp.Localize.Dispels = "Dispels"
recap_temp.Localize.Dispelled = "Dispelled"
recap_temp.Localize.Cast = "Cast"
recap_temp.Localize.Fail = "Fail"
recap_temp.Localize.Interrupts = "Interrupts"
recap_temp.Localize.Durability = "Durability"
recap_temp.Localize.Interrupted = "Interrupted"
recap_temp.Localize.Died = "died"
recap_temp.Localize.Killed = "killed"
recap_temp.Localize.TimeWindow = "Time Window"
recap_temp.Localize.AllCombatants = "All Combatants"
recap_temp.Localize.SpellIDNotRecognized = "Spell ID not recognized"
recap_temp.Localize.DataSet = "Data Set"
recap_temp.Localize.DataSetSelected = "Data Set Selected"
recap_temp.Localize.DataSetsSelected = "Data Sets Selected"
recap_temp.Localize.IncompatibleCombination = "Recap: Having all three of 'Hide Other Combatants', 'Store Only Displayed Combatants', and 'Auto Save Boss Fights' enabled at the same time is not supported."
recap_temp.Localize.GhoulMinion = "Ghoul Minion" -- name for amalgamated death knight ghouls summoned using Raise Dead
recap_temp.Localize.ReportOnRecentDeaths = "report on recent deaths"
recap_temp.Localize.Combatants = "Combatants"
recap_temp.Localize.Damage = "Damage"
recap_temp.Localize.Heal = "Heal"
recap_temp.Localize.Overheal = "Overheal"
recap_temp.Localize.Absorbed = "Absorbed"
recap_temp.Localize.Hits = "Hits"
recap_temp.Localize.Misses = "Misses"
recap_temp.Localize.Steals = "Steals"
recap_temp.Localize.MaxGearValue = "Max Gear Value"
recap_temp.Localize.GraphListVerboseLinkStart = "Recap %s: %s %s was %s; %s was %s; %s was %s"

-- click hints
recap_temp.Localize.MinimizedTooltip = "\nClick Hints:\n•• Right-click to see a menu of items to display in this minimized bar."
recap_temp.Localize.MainRowTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for this combatant. Control+double-click for dispels and interrupts only.\n•• Right-click to see a dropdown menu."
recap_temp.Localize.TotalsRowTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for all combatants. Control+double-click for dispels and interrupts only."
recap_temp.Localize.PostRowTooltip = "Click Hints:\n•• Shift+click to post this row."
recap_temp.Localize.PostRowsTooltip = "\nClick Hints:\n•• Shift+click to post these rows."
recap_temp.Localize.ColumnTooltip = "\nClick Hints:\n•• Click to change sorting order."
recap_temp.Localize.ColumnPostTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column."
recap_temp.Localize.ColumnPostAltTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Alt+shift+click (option+shift+click on a Mac) to post this column for non-friendly combatants."
recap_temp.Localize.ColumnMenuTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Right-click to see a menu of columns."
recap_temp.Localize.ColumnPostMenuTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Right-click to see a menu of columns."
recap_temp.Localize.ColumnPostMenuAltTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Right-click to see a menu of columns.\n•• Alt+shift+click (option+shift+click on a Mac) to post this column for non-friendly combatants."
recap_temp.Localize.ColumnGraphPostTooltip = "\nClick Hints:\n•• Click to begin sorting by this column.  Click again to stop sorting.\n•• Shift+click to post this column."
recap_temp.Localize.EffectRowTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for this effect."
recap_temp.Localize.EffectRowMenuTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for this effect.\n•• Right-click to see a dropdown menu."
recap_temp.Localize.DetailEntryTooltip = "\nClick Hints:\n•• Shift+click to post this detail entry."
recap_temp.Localize.DetailEntryReportGroupTooltip = "\nClick Hints:\n•• Shift+click to post this detail entry.\n•• Double-click to get a report of this detail entry for all group combatants."
recap_temp.Localize.DetailEntryReportNonGroupTooltip = "\nClick Hints:\n•• Shift+click to post this detail entry.\n•• Double-click to get a report of this detail entry for all combatants who are not in the group."
recap_temp.Localize.RecentRowTooltip = "Click Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for all combatants, centred on this event."
recap_temp.Localize.RecentButtonTooltip = "\nClick Hints:\n•• Control+click for dispels and interrupts only."


-- menus
recap_temp.Localize.ColumnMenu = { {Text="Numbered List",Info="Ranks"}, {Text="Faction/Level",Info="Faction"}, {Text="Class",Info="Class"},
								{Text="First Seen",Info="Seen"}, {Text="Deaths",Info="Deaths"},
								{Text="Time Out",Info="Time"}, {Text="Damage Out",Info="DmgOut"}, {Text="Damage Out %",Info="DmgOutP"}, {Text="Max Hit",Info="MaxHit"}, {Text="DPS Out",Info="DPS"},
								{Text="DPSPerGear",Info="DPSPerGear"}, {Text="DPS vs All",Info="DPSvsAll"},
								{Text="Time In",Info="TimeIn"}, {Text="Damage In",Info="DmgIn"}, {Text="Damage In %",Info="DmgInP"}, {Text="DPS In",Info="DPSIn"},
								{Text="Time Heal",Info="TimeHeal"}, {Text="Heal",Info="Heal"}, { Text="Heal %",Info="HealP"}, {Text="Overheal",Info="Over"}, {Text="HPS",Info="HPS"},
								{Text="Dispels",Info="Dispels"}, {Text="Interrupts",Info="Interrupts"} }
recap_temp.Localize.MinMenu = { {Text="Lock Window", Info="Pin"}, {Text="Status Light",Info="MinStatus"}, {Text="Sync Light",Info="MinSyncStatus"}, {Text="Last/All",Info="MinView"},
								{Text="Your DPS",Info="MinYourDPS"}, {Text="Your Pet Percent",Info="MinYourPetPercent"}, {Text="Total DPS In",Info="MinDPSIn"}, {Text="Total DPS Out",Info="MinDPSOut"},
								{Text="Your HPS",Info="MinYourHPS"}, {Text="Total HPS",Info="MinHPS"},
								{Text="Buttons",Info="MinButtons"}, {Text="Background",Info="MinBack"} }
recap_temp.Localize.AddMenu = { {Text="Add to Group",Info="MenuAdd"}, {Text="Reset",Info="MenuReset"}, {Text="Ignore",Info="MenuIgnore"} }
recap_temp.Localize.AddLockMenu = { {Text="Add to Group",Info="MenuAdd"}, {Text="Reset",Info="MenuReset"}, {Text="Ignore",Info="MenuIgnore"}, {Text="Lock",Info="MenuLock"} }
recap_temp.Localize.AddUnlockMenu = { {Text="Add to Group",Info="MenuAdd"}, {Text="Reset",Info="MenuReset"}, {Text="Ignore",Info="MenuIgnore"}, {Text="Unlock",Info="MenuUnlock"} }
recap_temp.Localize.DropMenu = { {Text="Drop from Group",Info="MenuDrop"}, {Text="Reset",Info="MenuReset"}, {Text="Ignore",Info="MenuIgnore"} }
recap_temp.Localize.DropLockMenu = { {Text="Drop from Group",Info="MenuDrop"}, {Text="Reset",Info="MenuReset"}, {Text="Ignore",Info="MenuIgnore"}, {Text="Lock",Info="MenuLock"} }
recap_temp.Localize.DropUnlockMenu = { {Text="Drop from Group",Info="MenuDrop"}, {Text="Reset",Info="MenuReset"}, {Text="Ignore",Info="MenuIgnore"}, {Text="Unlock",Info="MenuUnlock"} }
recap_temp.Localize.DetailTitle = { ["Total"] = "Total", ["TotalDmg"] = "Total Dmg", ["TotalHeal"] = "Total Heal", ["TotalPS"] = "per sec", ["TotalPSDmg"] = "DPS", ["TotalPSHeal"] = "HPS",
									["Avg"] = "Avg", ["Max"] = "Max", ["CritP"] = "Crit %", ["MissPOverP"] = "Miss / Over %" }
recap_temp.Localize.DetailMenu = { {Text="Total Damage or Healing",Info="Total"}, {Text="Total Damage only",Info="TotalDmg"}, {Text="Total Healing only",Info="TotalHeal"},
								   {Text="Total per sec",Info="TotalPS"}, {Text="Total DPS only",Info="TotalPSDmg"}, {Text="Total HPS only",Info="TotalPSHeal"}, {Text="Average Hit",Info="Avg"},
								   {Text="Max Hit",Info="Max"}, {Text="Crit Rate",Info="CritP"}, {Text="Miss Rate/Overheal Rate",Info="MissPOverP"} }
recap_temp.Localize.EffectMenu = { {Text="Reset Effect",Info="ResetEffect"} }
recap_temp.Localize.EffectOptMenu = { {Text="Element",Info="EElement"}, {Text="Total",Info="ETotal"}, {Text="Total %",Info="ETotalP"},
									{Text="Max Dmg",Info="EMaxAll"}, {Text="Glances",Info="EGlances"}, {Text="Min Glance",Info="EGlancesMin"}, {Text="Avg Glance",Info="EGlancesAvg"},
									{Text="Max Glance",Info="EGlancesMax"}, {Text="Hits",Info="EHits"}, {Text="Min Hit",Info="EHitsMin"}, {Text="Avg Hit",Info="EHitsAvg"},
									{Text="Max Hit",Info="EHitsMax"}, {Text="Ticks",Info="ETicks"}, {Text="Min Tick",Info="ETicksMin"}, {Text="Avg Tick",Info="ETicksAvg"},
									{Text="Max Tick",Info="ETicksMax"}, {Text="Crits",Info="ECrits"}, {Text="Min Crit",Info="ECritsMin"}, {Text="Avg Crit",Info="ECritsAvg"},
									{Text="Max Crit",Info="ECritsMax"}, {Text="Crit Rate",Info="ECritsP"}, {Text="Misses",Info="EMiss"},
									{Text="Miss Rate",Info="EMissP"} }

-- auto-post drop down choices
recap_temp.Localize.StatDropList = { "DPS", "Damage", "Tanking", "Healing" }
recap_temp.Localize.ChannelDropList = { "Self", "Party", "Say", "Raid", "Guild" }

recap_temp.Localize.MissTypes = { ["Missed"] = "Missed", ["Dodged"] = "Dodged", ["Parried"] = "Parried", ["Blocked"] = "Blocked", ["Deflected"] = "Deflected",
								 ["Resisted"] = "Resisted", ["Reflected"] = "Reflected", ["Absorbed"] = "Absorbed", ["Immune"] = "Immune", ["Evaded"] = "Evaded" }

recap_temp.Localize.ClassName = { ["WARRIOR"] = "Warrior", ["MAGE"] = "Mage", ["ROGUE"] = "Rogue", ["DRUID"] = "Druid",
								 ["HUNTER"] = "Hunter", ["SHAMAN"] = "Shaman", ["PRIEST"] = "Priest", ["WARLOCK"] = "Warlock",
								 ["PALADIN"] = "Paladin", ["Pet"] = "Pet", ["DEATHKNIGHT"] = "Death Knight", ["MONK"] = "Monk" }
recap_temp.Localize.ClassAbbr = { ["WARRIOR"] = "War", ["MAGE"] = "Mag", ["ROGUE"] = "Rog", ["DRUID"] = "Dru",
								 ["HUNTER"] = "Hnt", ["SHAMAN"] = "Shm", ["PRIEST"] = "Pri", ["WARLOCK"] = "Wlk",
								 ["PALADIN"] = "Pal", ["Pet"] = "Pet", ["DEATHKNIGHT"] = "DKt", ["MONK"] = "Mnk" }
recap_temp.Localize.FactionName = { ["Alliance"] = "Alliance", ["Horde"] = "Horde" }
recap_temp.Localize.SchoolName = { [0] = "None", [1] = "Physical", [2] = "Holy", [4] = "Fire", [8] = "Nature", [16] = "Frost", [32] = "Shadow", [64] = "Arcane" }
recap_temp.Localize.PowerName = { [0] = "Mana", [1] = "Rage", [2] = "Focus", [3] = "Energy", [4] = "Happiness", [5] = "Runes", [6] = "Runic", [7] = "Shards", [8] = "Solar", [-8] = "Lunar", [9] = "Holy", [-2] = "Health",
								  [10] = "Alt", [11] = "Dark", [12] = "Light", [13] = "Orbs", [14] = "Embers", [15] = "Fury" }
recap_temp.Localize.Difficulty = { [0] = "None", [1] = "N5", [2] = "H5", [3] = "N10", [4] = "N25", [5] = "H10", [6] = "H25", [7] = "RF25", [8] = "C5", [9] = "N40", [10] = "N20", [11] = "HScen", [12] = "NScen", [13] = "S3", [14] = "Flex", [15] = "Other" }
-- 10 and 13 are probably no longer used as of patch 5.4


-- channels to block when posting Recent Combat Event information (lower case) (English, French)
recap_temp.Localize.BlockChannels = { "general", "général",
									"trade", "commerce",
									"localdefense", "défenselocale",
									"worlddefense", "défenseuniverselle",
									"guildrecruitment", "recrutementdeguilde",
									"yell", "crier",
									"lookingforgroup", "recherchegroupe" }

end -- of the localization



--[[ -------- DO NOT LOCALIZE THE FOLLOWING SECTION --------- ]]

--[[ Defaults ]]

recap_temp.DefaultOpt = {
		-- window state settings
		["OutgoingPanelDetail"] =	{ type="Flag", value="Total" }, -- chosen outgoing detail stat column
		["IncomingPanelDetail"] =	{ type="Flag", value="Total" }, -- chosen incoming detail stat column
		["GrowUpwards"] =		{ type="Flag", value=false },
		["GrowLeftwards"] =		{ type="Flag", value=true },
		-- user settings options
		["ShowTooltips"]=		{ type="Check", value=true },
		["ShowClickHints"]=		{ type="Check", value=true },
		["TooltipFollow"] =		{ type="Check", value=false },
		["AutoHide"] =			{ type="Check", value=false },
		["AutoFade"] =			{ type="Check", value=false },
		["AutoFadeTimer"] =		{ type="Slider", value=5 },
		["SetScale"] =			{ type="Slider", value=100 },
		["LimitFights"] =		{ type="Check", value=false },
		["LimitToEncounters"] =	{ type="Check", value=false },
		["HideZero"] =			{ type="Check", value=false },
		["HideYardTrash"] =		{ type="Check", value=false },
		["HideGroup"] =			{ type="Check", value=false },
		["HideOthers"] =		{ type="Check", value=false },
		["StoreOnlyDisplayed"] =	{ type="Check", value=false },
		["MergePets"] =			{ type="Check", value=true },
		["MergeAllPetsIntoOne"] =	{ type="Check", value=false },
		["IgnoreGUIDs"] =		{ type="Check", value=false },
		["LDBSupport"] =		{ type="Check", value=false },
		["TabDelimited"] =		{ type="Check", value=false },
		["IdleFight"] =			{ type="Check", value=true },
		["IdleFightTimer"] =	{ type="Slider", value=8 },
		["EndFightDelay"] =		{ type="Slider", value=3 },
		["MaxRows"] =			{ type="Slider", value=10 },
		["PostInColumns"] =		{ type="Check", value=true },
		["AutoMinimize"] =		{ type="Check", value=false },
		["ShowPanel"] =			{ type="Check", value=true },
		["OpaqueBackground"] =	{ type="Check", value=false },
		["MinimizeOnEscape"] =	{ type="Check", value=false },
		["ShowGauges"] =		{ type="Check", value=true },
		["LightData"] =			{ type="Check", value=false },
		["OtherData"] =			{ type="Check", value=false },
		["MatrixData"] =		{ type="Check", value=false },
		["RecentData"] =		{ type="Check", value=false },
		["RecentEventCount"] =	{ type="Slider", value=2000 },
		["LiveData"] =			{ type="Check", value=false },
		["AutoLeader"] =		{ type="Check", value=false },
		["HTML"] =				{ type="Check", value=false },
		["WriteGroup"] =		{ type="Check", value=false },
		["WarnData"] =			{ type="Check", value=true },
		["RemindGroupStatus"] =	{ type="Check", value=false },
		["RemindInstanceStatus"] =	{ type="Check", value=false },
		["PauseOutsideInstances"] =	{ type="Check", value=false },
		["PauseInsideBattlegrounds"] =	{ type="Check", value=false },
		["ResetOnLogout"] =		{ type="Check", value=false },

		-- fight reporting
		["MaxRank"] =			{ type="Slider", value=10 },
		["AutoPost"] =			{ type="Check", value=false, Channel="Self", Stat="DPS" },
		-- fight data sets
		["SaveGroup"] =			{ type="Check", value=false },
		["AutoSaveBossFights"] =	{ type="Check", value=false },
		-- synchronization
		["EnableSync"] =		{ type="Check", value=false }, -- default is to ignore synchronization
		-- list elements
		["Ranks"] =				{ type="Check", value=false, width=32 },
		["Faction"] =			{ type="Check", value=false, width=32 },
		["Class"] =				{ type="Check", value=true, width=14 },
		["Seen"] =				{ type="Check", value=false, width=62 },
		["Deaths"] =			{ type="Check", value=false, width=31 },
		["Dispels"] =			{ type="Check", value=false, width=45 },
		["Interrupts"] =		{ type="Check", value=false, width=60 },
		["Time"] =				{ type="Check", value=true, width=62 },
		["TimeIn"] =			{ type="Check", value=false, width=62 },
		["TimeHeal"] =			{ type="Check", value=false, width=62 },
		["Heal"] =				{ type="Check", value=true, width=92 },
		["HealP"] =				{ type="Check", value=false, width=32 },
		["Over"] =				{ type="Check", value=false, width=32 },
		["DmgIn"] =				{ type="Check", value=true, width=92 },
		["DmgInP"] =			{ type="Check", value=false, width=32 },
		["DmgOut"] =			{ type="Check", value=true, width=92 },
		["DmgOutP"] =			{ type="Check", value=false, width=40 },
		["MaxHit"] =			{ type="Check", value=true, width=57 },
		["HPS"] =				{ type="Check", value=false, width=57 },
		["DPSIn"] =				{ type="Check", value=false, width=57 },
		["DPS"] =				{ type="Check", value=true, width=57 },
		["DPSPerGear"] =		{ type="Check", value=false, width=80 },
		["DPSvsAll"] =			{ type="Check", value=false, width=57 },
		-- minimized elements
		["MinStatus"] =			{ type="Check", value=true, minwidth=16 }, -- width of status light
		["MinSyncStatus"] =		{ type="Check", value=true, minwidth=18 }, -- width of sync status light
		["MinView"] =			{ type="Check", value=false, minwidth=35 },
		["MinYourDPS"] =		{ type="Check", value=true, minwidth=80 },
		["MinYourPetPercent"] =	{ type="Check", value=false, minwidth=48 },
		["MinDPSIn"] =			{ type="Check", value=false, minwidth=96 },
		["MinDPSOut"] =			{ type="Check", value=false, minwidth=96 },
		["MinYourHPS"] =		{ type="Check", value=false, minwidth=80 },
		["MinHPS"] =			{ type="Check", value=false, minwidth=96 },
		["MinButtons"] =		{ type="Check", value=false },
		["MinBack"] =			{ type="Check", value=true },
		-- personal details elements
		["EElement"] =			{ type="Check", value=true, ewidth=84 },
		["ETotal"] =			{ type="Check", value=true, ewidth=84 },
		["ETotalP"] =			{ type="Check", value=true, ewidth=32 },
		["EMaxAll"] =			{ type="Check", value=true, ewidth=60 },
		["EGlances"] =			{ type="Check", value=false, ewidth=70 },
		["EGlancesMin"] =		{ type="Check", value=false, ewidth=46 },
		["EGlancesAvg"] =		{ type="Check", value=false, ewidth=46 },
		["EGlancesMax"] =		{ type="Check", value=false, ewidth=60 },
		["EHits"] =				{ type="Check", value=false, ewidth=60 },
		["EHitsMin"] =			{ type="Check", value=false, ewidth=46 },
		["EHitsAvg"] =			{ type="Check", value=false, ewidth=46 },
		["EHitsMax"] =			{ type="Check", value=false, ewidth=60 },
		["ETicks"] =			{ type="Check", value=false, ewidth=60 },
		["ETicksMin"] =			{ type="Check", value=false, ewidth=46 },
		["ETicksAvg"] =			{ type="Check", value=false, ewidth=46 },
		["ETicksMax"] =			{ type="Check", value=false, ewidth=60 },
		["ECrits"] =			{ type="Check", value=false, ewidth=60 },
		["ECritsMin"] =			{ type="Check", value=false, ewidth=46 },
		["ECritsAvg"] =			{ type="Check", value=false, ewidth=46 },
		["ECritsMax"] =			{ type="Check", value=false, ewidth=60 },
		["ECritsP"] =			{ type="Check", value=true, ewidth=40 },
		["EMiss"] =				{ type="Check", value=false, ewidth=60 },
		["EMissP"] =			{ type="Check", value=true, ewidth=55 },
};

recap_temp.ClassIcons = {
	["WARRIOR"] = { left=0.025, right=0.225, top=0.025, bottom=0.225 },
	["MAGE"] = { left=0.275, right=0.475, top=0.025, bottom=0.225 },
	["ROGUE"] = { left=0.525, right=0.725, top=0.025, bottom=0.225 },
	["DRUID"] = { left=0.775, right=0.975, top=0.025, bottom=0.225 },
	["HUNTER"] = { left=0.025, right=0.225, top=0.275, bottom=0.475 },
	["SHAMAN"] = { left=0.275, right=0.475, top=0.275, bottom=0.475 },
	["PRIEST"] = { left=0.525, right=0.725, top=0.275, bottom=0.475 },
	["WARLOCK"] = { left=0.775, right=0.975, top=0.275, bottom=0.475 },
	["PALADIN"] = { left=0.025, right=0.225, top=0.525, bottom=0.725 },
	["Pet"] = { left=0.275, right=0.475, top=0.525, bottom=0.725 },
	["DEATHKNIGHT"] = { left=0.525, right=0.725, top=0.525, bottom=0.725 },
	["MONK"] = { left=0.775, right=0.975, top=0.525, bottom=0.725 }
}

recap_temp.FactionIcons = {
	["Alliance"] = "Interface\\TargetingFrame\\UI-PVP-Alliance",
	["Horde"] = "Interface\\TargetingFrame\\UI-PVP-Horde"
}

-- to help keep saved sets from bloat, commonly used strings will be replaced
-- with indexes to this table.  The indexes need to remain in this order.  Add
-- new keys to the end.
recap_temp.Keys = {
	"Alliance", "Horde",
	"WARRIOR", "MAGE", "ROGUE", "DRUID", "HUNTER",
	"SHAMAN", "PRIEST", "WARLOCK", "PALADIN", "Pet",
	"DEATHKNIGHT", "MONK"
}



-- shield registration storage
recap_temp.ShieldRegistration = {}



-- correction of bad UnitClass values for NPCs in the Faction Champions fight in ToGC
recap_temp.FacChampsClass = { [34461] = "DEATHKNIGHT", [34460] = "DRUID", [34469] = "DRUID", [34467] = "HUNTER", [34468] = "MAGE", [34465] = "PALADIN", [34471] = "PALADIN",
							  [34466] = "PRIEST", [34473] = "PRIEST", [34472] = "ROGUE", [34463] = "SHAMAN", [34470] = "SHAMAN", [34474] = "WARLOCK", [34475] = "WARRIOR",
							  [34458] = "DEATHKNIGHT", [34451] = "DRUID", [34459] = "DRUID", [34448] = "HUNTER", [34449] = "MAGE", [34445] = "PALADIN", [34456] = "PALADIN",
							  [34447] = "PRIEST", [34441] = "PRIEST", [34454] = "ROGUE", [34455] = "SHAMAN", [34444] = "SHAMAN", [34450] = "WARLOCK", [34453] = "WARRIOR" }


-- adjustment of specific NPC melee to distinguish it from other melee (e.g. Vengeful Shade, Blood Beast)
recap_temp.SpecialMelee = { [38222] = true, -- Vengeful Shade
							[38508] = true, -- Blood Beast
						  }

-- two near-bosses in the Spine fight
recap_temp.SpecialBosses = { [56341] = true, -- one Burning Tendons
							 [56575] = true, -- other Burning Tendons
						   }


-- table used when logging recent events
-- the table has a fixed length array (a circular buffer) of strings, and two numerical indexes for the first and last events
--   each string represents an event, and has a timestamp, source combatant, destination combatant, effect, amount (or missType or 'miss'), and whether it is a crit or crush, and any overheal amount
recap_temp.Recent = { First = true, Last = true, Time = true }
recap_temp.RecentFindString = "^(.-)%>(.-)%>(.-)%>(.-)%>(.-)%>(.-)%>(.-)%>(.-)%>$"
-- table used for logging recent death events for group combatants, used to speed up Deaths processing
recap_temp.RecentFriendDeaths = {}


--[[ Misc variables ]]

recap_temp.Recap = "Recap"
recap_temp.Loaded = false
recap_temp.Player = false
recap_temp.PlayerGUID = false
recap_temp.Server = false
recap_temp.InstanceDifficulty = 15 -- set at start of fight, for use when saving boss fights in instances, default is "Other"
recap_temp.p = false -- for use with recap[] -- without GUID
recap_temp.s = false -- for use with recap.Self[] -- without GUID
recap_temp.InGroup = {} -- records whether combatant is part of the strict group (the Group set can be smaller than the Friend set) (includes pets)
recap_temp.InFriend = {} -- records whether combatant is a Friend (optimization) (the Friend set can be larger than the Group set if members have been added by hand)
recap_temp.Last = {} -- active last fight indexed by name
recap_temp.LastPlayerPets = {} -- pets of the player, pets who are in the last fight
recap_temp.List = {} -- constructed display list, numerically indexed
recap_temp.ListSize = 0 -- number of .List values
recap_temp.SelfList = {} -- list for damage breakdown
recap_temp.SelfListSize = 0
recap_temp.Load = {} -- parallel to recap_combatants, but for a loaded data set
recap_temp.LoadList = {} -- constructed display list, numerically indexed, for the loaded data set
recap_temp.LoadListSize = 0 -- number of .LoadList values
recap_temp.LoadedDataSet = "" -- name of loaded data set
recap_temp.LoadedDetails = false -- whether Outgoing/Target/Incoming/Source/Other loaded yet
recap_temp.LoadSortBy = "DPS" -- sorting for loaded data set
recap_temp.LoadSortDir = true -- sorting for loaded data set
recap_temp.OutgoingDetailSortBy = "Hits" -- sorting for Outgoing Details tab on Panel
recap_temp.TargetDetailSortBy = "Hits" -- sorting for Target Details tab on Panel
recap_temp.IncomingDetailSortBy = "Hits" -- sorting for Incoming Details tab on Panel
recap_temp.SourceDetailSortBy = "Hits" -- sorting for Source Details tab on Panel
recap_temp.OtherDetailSortBy = "Hits" -- sorting for Other Details tab on Panel
recap_temp.ActiveLastFight = "1" -- alternates between 1 and 2
recap_temp.DisplayLastFight = "2" -- alternates between 2 and 1
recap_temp.FightStart = 0 -- group time fight started
recap_temp.FightEnd = 0 -- group time fight ended
recap_temp.FightStartIn = 0 -- group time fight started (for damage taken)
recap_temp.FightEndIn = 0 -- group time fight ended (for damage taken)
recap_temp.FightStartHeal = 0 -- group time fight started (for healing)
recap_temp.FightEndHeal = 0 -- group time fight ended (for healing)
recap_temp.BossList = "" -- list of hostile bosses, if any, in the last fight
recap_temp.StartupState = "Stopped" -- when first logging in, remember the state that we will eventually come up in
recap_temp.PeriodicUpdateTick = 0.5 -- how often we call the periodic update, in seconds (should probably not be set to higher than 1 second, and the library minimum is 0.1 seconds)
recap_temp.SkipPeriodicUpdate = false -- whether we skip periodic update code (poor man's spinlock for a couple of functions that might conflict)
recap_temp.StartupDelayTimer = -1 -- 0+ = time since we are first initialized before we get combatant data, display Recap, and (possibly) resume Recap
recap_temp.IdleTimer = -1 -- 0+ = time since last hit or heal happened (user can set to trigger after N seconds)
recap_temp.HiddenIdleTimer = -1 -- 0+ = time since last hit or heal happened (hard coded to trigger after 10 minutes)
recap_temp.FadeTimer = -1 -- 0+ = time since mouse left window
recap_temp.EndFightDelayTimer = -1 -- 0+ = time since end-of-fight was triggered
recap_temp.EndSyncDelayTimer = -1 -- 0+ = time since end-of-sync was triggered
recap_temp.SyncStatusLightBlink = 0 -- 0 to 3, used to blink the sync light on data transmission
recap_temp.SyncHeartbeat = 0 -- 0 to 9, used to send our name and server to everyone in the sync once every five seconds
recap_temp.LiveUpdateTimer = 0 -- time since last calculation of live update numbers (so we can make it less often than every half second)
recap_temp.Color = {}
recap_temp.Color.Red =	 { 1.0, 0.3, 0.3 }
recap_temp.Color.RedPale =  { 1.0, 0.55, 0.55 }
recap_temp.Color.Green =  { 0.25, 0.85, 0.25 }
recap_temp.Color.GreenPale = { 0.5, 0.85, 0.5 }
recap_temp.Color.Blue =	 { 0.3, 0.55, 0.85 }
recap_temp.Color.BluePale =	 { 0.55, 0.75, 0.85 }
recap_temp.Color.White =  { 0.85, 0.85, 0.85 }
recap_temp.Color.None =   { 1.0, 0.82, 0.0 }
recap_temp.Color.Cyan =   { 0.25, 0.7, 0.85 }
recap_temp.Color.LightCyan =   { 0.5, 0.85, 0.9 }
recap_temp.Color.Yellow = { 1.0, 1.0, 0.55 }
recap_temp.Color.Lime =   { 0.6, 1.0, 0.6 }
recap_temp.Color.Pink =   { 1.0, 0.65, 1.0 }
recap_temp.Color.WoWDefault =   { 1.0, 0.82, 0.0 } -- had to synthesize this, couldn't figure out how to get the 'default' colour
recap_temp.FightSets = {} -- list of fight data sets
recap_temp.FightSetsSize = 1 -- size of fight list
recap_temp.FightSetSelected = 0
recap_temp.FightSetSelectedOther = 0 -- can select a range of data sets [Selected..SelectedOther] for deletion
recap_temp.Ignores = {} -- list of ignores for scroll box (recap_ignore is where they are really stored)
recap_temp.IgnoresSize = 1 -- size of recap_temp.Ignores list
recap_temp.IgnoreSelected = 0
recap_temp.MinTime = 3.0 -- threshhold to calculate DPS, DPSIn, or HPS (time still accumulates) (also used to determine if combatant appears in Fights panel)
recap_temp.DeemedTime = 1.5 -- any damage or healing in a fight will have an associated duration of at least this
recap_temp.PlayerDPSLast = 0 -- live player dps for last fight
recap_temp.PlayerDPSAll = 0 -- live player dps for all fights
recap_temp.PlayerDmgLast = 0
recap_temp.PlayerDmgAll = 0
recap_temp.PlayerPetPercentLast = 0
recap_temp.PlayerPetPercentAll = 0
recap_temp.PlayerMaxHitLast = 0
recap_temp.PlayerMaxHitAll = 0
recap_temp.PlayerDmgInLast = 0
recap_temp.PlayerDmgInAll = 0
recap_temp.PlayerHPSLast = 0 -- live player hps for last fights
recap_temp.PlayerHPSAll = 0 -- live player hps for all fights
recap_temp.PlayerHealingLast = 0
recap_temp.PlayerHealingAll = 0
recap_temp.PlayerOverhealingLast = 0
recap_temp.PlayerOverhealingAll = 0
recap_temp.TotalGroupDmgIn = 0 -- pre-calculated group damage in for all fights (for calculating live numbers)
recap_temp.TotalGroupDmgOut = 0 -- pre-calculated group damage out for all fights (for calculating live numbers)
recap_temp.TotalGroupHeal = 0 -- pre-calculated group healing out for all fights (for calculating live numbers)
recap_temp.GroupDPSOutLast = 0 -- live group dps out for last fight
recap_temp.GroupDPSInLast = 0 -- live group dps in for last fight
recap_temp.GroupHPSLast = 0 -- live group hps out for last fight
recap_temp.GroupDPSOutAll = 0 -- live group dps out for all fights
recap_temp.GroupDPSInAll = 0 -- live group dps in for all fights
recap_temp.GroupHPSAll = 0 -- live group hps out for all fights
recap_temp.PanelSource = "" -- whether the source for panel is the main fights panel or the loaded data sets panel
recap_temp.Selected = 0 -- index in .List of currently selected combatant, 0 for none, special values (GroupIndex and NonGroupIndex) for grand totals
recap_temp.LoadSelected = 0 -- index in .LoadList of currently selected combatant, 0 for none, special values (GroupIndex and NonGroupIndex) for grand totals
recap_temp.RecentSource = "" -- whether the source for panel is a recent event per se, or deaths or detail entries
recap_temp.RecentSelected = 0 -- index of currently selected Recent button matching .List of combatants (or of effects)
recap_temp.PanelRecentSelected = 0 -- index of currently selected Recent button matching .List of details
recap_temp.OutgoingDetailSelected = 0 -- index in .OutgoingDetail of currently selected detail, 0 for none
recap_temp.OutgoingDetailLoaded = 0 -- index in .OutgoingDetail of detail loaded into bottom half of panel
recap_temp.TargetDetailSelected = 0 -- index in .TargetDetail of currently selected detail, 0 for none
recap_temp.IncomingDetailSelected = 0 -- index in .IncomingDetail of currently selected detail, 0 for none
recap_temp.IncomingDetailLoaded = 0 -- index in .IncomingDetail of detail loaded into bottom half of panel
recap_temp.SourceDetailSelected = 0 -- index in .SourceDetail of currently selected detail, 0 for none
recap_temp.OtherDetailSelected = 0 -- index in .OtherDetail of currently selected detail, 0 for none
recap_temp.OtherDetailLoaded = 0 -- index in .OtherDetail of detail loaded into bottom half of panel
recap_temp.RecentIncomingSelected = 0 -- index in .RecentIncoming of currently selected detail, 0 for none
recap_temp.RecentOutgoingSelected = 0 -- index in .RecentOutgoing of currently selected detail, 0 for none
recap_temp.OutgoingDetailsListSize = 0 -- number of Outgoing detail entries
recap_temp.TargetDetailsListSize = 0 -- number of Target detail entries
recap_temp.IncomingDetailsListSize = 0 -- number of Incoming detail entries
recap_temp.SourceDetailsListSize = 0 -- number of Source detail entries
recap_temp.OtherDetailsListSize = 0 -- number of Other detail entries
recap_temp.RecentIncomingListSize = 0 -- number of Recent Incoming detail entries
recap_temp.RecentOutgoingListSize = 0 -- number of Recent Outgoing detail entries
recap_temp.GaugeWidth = 100 -- max width of gauges
recap_temp.GaugeMax = 0 -- highest value from which gauges are adjusted
recap_temp.GaugeBy = false -- "DmgInP" "DmgOutP" or "HealP"
recap_temp.LoadGaugeWidth = 100 -- max width of gauges for loaded data sets
recap_temp.LoadGaugeMax = 0 -- highest value from which gauges are adjusted for loaded data sets
recap_temp.LoadGaugeBy = false -- "DmgInP" "DmgOutP" or "HealP" for loaded data sets
recap_temp.StatLeader = false -- name of current stat leader
recap_temp.MaxLogLines = 100 -- maximum number of lines to write to log
recap_temp.MaxLinesToClipboard = 1000 -- maximum number of lines to write to the clipboard (with 4.62 there is apparently no limit to the number of letters in the clipboard, so in theory we could remove this limit entirely -- leave for the moment)
recap_temp.OnCommReceived = false -- whether we are already processing an OnCommReceived event (poor man's spinlock)
recap_temp.OnError = false -- whether we are already processing an error event (poor man's spinlock)
recap_temp.ScrollAndEdgeWidth = 48 -- now a global -- 8(edge)+32(scroll)+8(edge)
recap_temp.NameWidth = 144 -- now a global and increased from 120 to 144
recap_temp.LogChatnum = false -- set to the channel number if we have a channel to log to
recap_temp.ResetWasInCurrent = false -- so that we set WasInCurrent only once in a fight
recap_temp.LastFightSignificant = false -- to note whether the Last Fight was significant enough to update the existing Last Fight data
recap_temp.LastFightSignificantTime = 5.0 -- a fight in which no combatant does or receives damage for longer than this number will not be deemed significant
recap_temp.Menu = false -- current dropdown menu
recap_temp.MaxMenuLines = 25 -- context menus, used by Recap_CreateMenu(), currently 23 in use
recap_temp.GroupTotal = "Group Total" -- name of a hidden combatant
recap_temp.NonGroupTotal = "Non-Group Total" -- name of a hidden combatant
recap_temp.GroupIndex = 665 -- special value to indicate selection of group hidden combatant
recap_temp.NonGroupIndex = 666 -- special value to indicate selection of non-group hidden combatant
-- set of flags for managing several aspects of data initialization
recap_temp.FlagDataSizeDialogDone = false
recap_temp.FlagDataInitializationCompleted = false
-- flag for doing a save one tick after EndFight (to avoid running out of time with end fight and auto-save back to back)
-- starting with 4.77, doing it in seven phases: basic plus five kinds of details, plus a final phase
recap_temp.FlagSavePhase = false
recap_temp.FlagSaveLastOnly = false
recap_temp.FlagSaveSetName = false
recap_temp.FlagSavePriorState = false
-- The following needed to translate channel names back into canonical names for use by WoW
recap_temp.CanonicalChannelDropList = { "Self", "Party", "Say", "Raid", "Guild" }
recap_temp.RecentButtonWidth = 55 -- amount needed for the 'Recent' button
recap_temp.RecentIndex = 0 -- offset of Recent event selected for display ByIndex (0 if none)
recap_temp.OutgoingPriorRecentIndex = 0 -- the previous Recent index clicked (used for detecting double clicks)
recap_temp.OutgoingPriorClickTime = 0 -- the previous time that a Recent index was clicked (used for detecting double clicks)
recap_temp.IncomingPriorRecentIndex = 0 -- the previous Recent index clicked (used for detecting double clicks)
recap_temp.IncomingPriorClickTime = 0 -- the previous time that a Recent index was clicked (used for detecting double clicks)
recap_temp.CombatantPriorCombatant = "" -- the previous Combatant (All Fights or Last Fight) clicked (used for detecting double clicks)
recap_temp.CombatantPriorClickTime = 0 -- the previous time that a Combatant (All Fights or Last Fight) was clicked (used for detecting double clicks)
recap_temp.SelfPriorEffect = "" -- the previous Effect (Self) clicked (used for detecting double clicks)
recap_temp.SelfPriorClickTime = 0 -- the previous time that an Effect (Self) was clicked (used for detecting double clicks)
recap_temp.OutgoingEffectPriorEffect = "" -- the previous Effect (OutgoingDetail) clicked (used for detecting double clicks)
recap_temp.OutgoingEffectPriorClickTime = 0 -- the previous time that an Effect (OutgoingDetail) was clicked (used for detecting double clicks)
recap_temp.IncomingEffectPriorEffect = "" -- the previous Effect (IncomingDetail) clicked (used for detecting double clicks)
recap_temp.IncomingEffectPriorClickTime = 0 -- the previous time that an Effect (IncomingDetail) was clicked (used for detecting double clicks)
recap_temp.PriorDetailEntry = "" -- the previous detail entry clicked (used for detecting double clicks)
recap_temp.DetailEntryPriorClickTime = 0 -- the previous time that a detail entry was clicked (used for detecting double clicks)
recap_temp.UnexpectedErrorMessageCount = 0 -- count of number of unexpected event error messages emitted, stopping after some number such as 10
-- effects to ignore:		   Drawn Soul____  Mark of the Fallen Champion___________________________________  Mutated Plague________________
-- TODO: CATA: these might change for Cataclysm and later
recap_temp.SuggestedIgnores = { [40903] = true, [72260] = true, [72278] = true, [72279] = true, [72280] = true, [72745] = true, [72746] = true }
recap_temp.TimestampDeltaSum = 0 -- total of differences between event timestamps and GetTime()
recap_temp.TimestampDeltaCount = 0 -- number of differences, the two used to calculate an average

-- assorted output tables
recap_temp.OutgoingTotals = {}
recap_temp.OutgoingDetailsList = {}
recap_temp.TargetDetailsList = {}
recap_temp.IncomingTotals = {}
recap_temp.IncomingDetailsList = {}
recap_temp.SourceDetailsList = {}
recap_temp.OtherDetailsList = {}
recap_temp.RecentIncomingList = {}
recap_temp.RecentOutgoingList = {}

-- intermediate results table used for detail entries across all group combatants
recap_temp.PartialDetailEntryTable = {}

-- WIM (WoW Instant Messenger) support
recap_temp.WIMType = true -- if a WIM edit box has the focus, this is the type (e.g. say, party, raid, whisper, etc.)
recap_temp.WIMWho = true -- if a WIM edit box has the focus, and if the type is whisper, this is the target of the whisper

-- variables to support remembering sync requests until after combat
recap_temp.SyncInviteTimestamp = false -- timestamp of the sync
recap_temp.SyncInviteLeader = false -- leader of the sync
recap_temp.SyncInviteMergePets = false -- whether Merge Pets is: 'off' or 'on'
recap_temp.SyncInviteWhen = false -- local time we received the invitation (for ignoring stale invitations)
recap_temp.SyncInviteNewOngoing = false -- whether the invitation was for a new sync, or an ongoing sync
recap_temp.AskingJoinSync = false -- spinlock so we don't ask the question multiple times
recap_temp.SyncData = {} -- synchronization Summary data indexed by name
recap_temp.SyncMembers = {} -- people we have noticed in our synchronization, the sync version they are running, and when we last heard from them
recap_temp.NewInvite = "I"
recap_temp.OngoingInvite = "O"
recap_temp.Accept = "A"
recap_temp.Decline = "D"
recap_temp.Summary = "S"
recap_temp.GetSummaries = "G"
recap_temp.Reply = "R"
recap_temp.Heartbeat = "H"
recap_temp.SkipNextFight = "X"
recap_temp.PauseAll = "Y"
recap_temp.ResumeAll = "Z"

-- variables for live graphs and lists
recap_temp.Graph = {}
recap_temp.Graph.Paused = false -- whether we are collecting live data for graph and text listings -- if paused during combat involving the group, we will be missing data
recap_temp.Graph.TextToggle = "graph" -- "graph" or "text"
recap_temp.Graph.Statistic = RECAP_DPS_OUT -- "DPS Out", "DPS In", or "HPS Out"
recap_temp.Graph.GroupInvolved = false -- true only if group members have been involved in the fight
recap_temp.Graph.FightSignificant = false -- true only if group members have been involved for "long enough"
recap_temp.Graph.ProcessLockStatus = "unlock" -- "lock" block calculation from raw to display; "unlock" allow calculation from raw to display; "neutral" allow calculation and locking
recap_temp.Graph.BinsInitialized = false -- whether RecapGraph_InitializeLiveLists has been run
recap_temp.Graph.BinSize = 2 -- two second bin size
recap_temp.Graph.NBins = 3 -- number of bins to average (in this case giving us a moving 6 second window) (current code in RecapCombat is hard-coded for 3 bins)
recap_temp.Graph.StartTime = 0 -- time of start of current fight (only filled in at end of fight group was involved in)
recap_temp.Graph.EndTime = 0 -- time of end of current fight (only filled in at end of fight group was involved in)
recap_temp.Graph.CombatantsDPSOut = {} -- semi-permanent info about combatants, such as whether their display is turned off, or dimmed -- note that this info gets lost on logout or reloadui -- for outgoing DPS
recap_temp.Graph.CombatantsDPSIn = {} -- semi-permanent info about combatants, such as whether their display is turned off, or dimmed -- note that this info gets lost on logout or reloadui -- for incoming DPS
recap_temp.Graph.CombatantsHPSOut = {} -- semi-permanent info about combatants, such as whether their display is turned off, or dimmed -- note that this info gets lost on logout or reloadui -- for outgoing HPS
recap_temp.Graph.LiveDmgOutBins = {} -- unsorted list of combatants for collecting DPS Out data, and graphical display
recap_temp.Graph.LiveDmgOutSorted = {} -- matching sorted list for display
recap_temp.Graph.LiveDPSOutMax = { 0, 0 } -- highest values seen so far (max per second and max bins)
recap_temp.Graph.LiveDmgInBins = {} -- unsorted list of combatants for collecting DPS In data, and graphical display
recap_temp.Graph.LiveDmgInSorted = {} -- matching sorted list for display
recap_temp.Graph.LiveDPSInMax = { 0, 0 } -- highest values seen so far (max per second and max bins)
recap_temp.Graph.LiveHealingBins = {} -- unsorted list of combatants for collecting HPS Out data, and graphical display
recap_temp.Graph.LiveHealingSorted = {} -- matching sorted list for display
recap_temp.Graph.LiveHPSOutMax = { 0, 0 } -- highest values seen so far (max per second and max bins)
recap_temp.Graph.ListScrollingOffset = 0 -- position of live list so we can keep the scrolling position constant
recap_temp.Graph.OpaqueBackground = false -- background for the live panel (always starts up in the default transparent state, but can be changed to opaque)
recap_temp.Graph.TextList = {} -- Graph List entries
recap_temp.Graph.TextListSize = 0 -- number of Graph List detail entries
recap_temp.Graph.TextSorting = "Total" -- whether live text listings are sorted dynamically ("none", "Total", "Peak", "Avg")
recap_temp.Graph.TextGaugeWidth = 275 -- max width of gauges
recap_temp.Graph.TextGaugeMax = 0 -- highest value from which gauges are adjusted

-- a few other globals
recap_temp.Original_ErrorHandler = true -- global to store the original Error Handler
recap_temp.Original_ReloadUI = true -- global to store the original ReloadUI
recap_temp.Original_ConsoleExec = true -- global to store the original ConsoleExec

recap_temp.DoingReloadUI = false -- variable to detect if we are doing a reloadui rather than a logout

recap_temp.Opt = true -- pointer to the options in use, usually recap_user.Opt (recap.GlobalOpt if UseOneSettings is on)

localization_lua_4773 = true
