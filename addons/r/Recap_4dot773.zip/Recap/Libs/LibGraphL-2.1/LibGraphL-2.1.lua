--[[
Name: LibGraphL-2.1
Revision: $Rev: 41 $
Author(s): Cryect (cryect@gmail.com), Xinhuan
Website: http://www.wowace.com/
Documentation: http://www.wowace.com/wiki/GraphLib
SVN: http://svn.wowace.com/root/trunk/GraphLib/
Description: Allows for easy creation of graphs
]]

-- 2010-April-18 Hawksy modified, slimmed, and renamed from LibGraph to LibGraphL for use by Recap

--Thanks to Nelson Minar for catching several errors where width was being used instead of height (damn copy and paste >_>)

local major = "LibGraphL-2.1"
local minor = 90000 + tonumber(("$Revision: 42 $"):match("(%d+)"))


--Search for just Addon\\ at the front since the interface part often gets trimmed
--Do this before anything else, so if it errors, any existing loaded copy of LibGraphL-2.1
--doesn't get modified with a newer revision (this one)
local TextureDirectory
do
	local path = string.match(debugstack(1,1,0), "AddOns\\(.+)LibGraphL%-2%.1%.lua")
	if path then
		TextureDirectory = "Interface\\AddOns\\"..path
	else
		error(major.." cannot determine the folder it is located in because the path is too long and got truncated in the debugstack(1,1,0) function call")
	end
end


if not LibStub then error(major .. " requires LibStub") end

local lib, oldLibMinor = LibStub:NewLibrary(major, minor)
if not lib then return end

local GraphLFunctions={}

local tinsert, tremove = tinsert, tremove
local pairs, ipairs = pairs, ipairs
local math_max = math.max
local math_min = math.min
local math_ceil = math.ceil
local math_floor = math.floor
local math_fmod = math.fmod
local math_huge = math.huge
local table_getn = table.getn

-- lib upgrade stuff
lib.RegisteredGraphLine        = lib.RegisteredGraphLine        or {}



--------------------------------------------------------------------------------
--Graph Creation Functions
--------------------------------------------------------------------------------

--Line Graph
local function SetupGraphLineFunctions(graph)
	local self = lib

	--Set the various functions
	graph.SetXAxis=GraphLFunctions.SetXAxis
	graph.SetYAxis=GraphLFunctions.SetYAxis
	graph.AddDataSeries=GraphLFunctions.AddDataSeries
	graph.ResetData=GraphLFunctions.ResetData
	graph.RefreshGraph=GraphLFunctions.RefreshLineGraph
	graph.CreateGridlines=GraphLFunctions.CreateGridlines
	graph.SetAxisDrawing=GraphLFunctions.SetAxisDrawing
	graph.SetGridSpacing=GraphLFunctions.SetGridSpacing
	graph.SetAxisColor=GraphLFunctions.SetAxisColor
	graph.SetGridColor=GraphLFunctions.SetGridColor
	graph.SetAutoScale=GraphLFunctions.SetAutoScale
	graph.SetYLabels=GraphLFunctions.SetYLabels
	graph.OnUpdate=GraphLFunctions.OnUpdateGraph

	graph.LockXMin=GraphLFunctions.LockXMin
	graph.LockXMax=GraphLFunctions.LockXMax
	graph.LockYMin=GraphLFunctions.LockYMin
	graph.LockYMax=GraphLFunctions.LockYMax

	graph.DrawLine=self.DrawLine
	graph.DrawHLine=self.DrawHLine
	graph.DrawVLine=self.DrawVLine
	graph.HideLines=self.HideLines
	graph.HideFontStrings=GraphLFunctions.HideFontStrings
	graph.FindFontString=GraphLFunctions.FindFontString

	--Set the update function
	graph:SetScript("OnUpdate", graph.OnUpdate)
end

function lib:CreateGraphLine(name,parent,relative,relativeTo,offsetX,offsetY,Width,Height)
	local graph
	graph = CreateFrame("Frame",name,parent)

	graph:SetPoint(relative,parent,relativeTo,offsetX,offsetY)
	graph:SetWidth(Width)
	graph:SetHeight(Height)
	graph:Show()

	SetupGraphLineFunctions(graph)

	graph.NeedsUpdate=false

	--Initialize Data
	graph.YMax=1
	graph.YMin=-1
	graph.XMax=1
	graph.XMin=-1
	graph.AxisColor={1.0,1.0,1.0,1.0}
	graph.GridColor={0.5,0.5,0.5,0.5}
	graph.XGridInterval=0.25
	graph.YGridInterval=0.25
	graph.XAxisDrawn=true
	graph.YAxisDrawn=true

	graph.LockOnXMin=false
	graph.LockOnXMax=false
	graph.LockOnYMin=false
	graph.LockOnYMax=false
	graph.Data={}

	tinsert(self.RegisteredGraphLine, graph)
	return graph
end



-------------------------------------------------------------------------------
--Functions for Line Graph Data
-------------------------------------------------------------------------------

function GraphLFunctions:AddDataSeries(points,color,n2)
	local data, k, v
	--Make sure there is data points
	if not points then
		return
	end

	data=points
	if n2==nil then
		n2=false
	end
	if n2 or (table_getn(points)==2 and table_getn(points[1])~=2) then
		data={}
		for k,v in ipairs(points[1]) do
			tinsert(data,{v,points[2][k]})
		end
	end

	tinsert(self.Data,{Points=data;Color=color})

	self.NeedsUpdate=true
end

function GraphLFunctions:ResetData()
	self.Data={}

	self.NeedsUpdate=true
end

function GraphLFunctions:HideFontStrings(C)
	local k, t
	if not C.FontStrings then
		C.FontStrings={}
	end
	for k, t in pairs(C.FontStrings) do
		t:Hide()
	end
end

--Make sure to show a fontstring after you grab it or its free for anyone else to grab
function GraphLFunctions:FindFontString(C)
	local k, t, g
	for k, t in pairs(C.FontStrings) do
		if not t:IsShown() then
			return t
		end
	end

	g=C:CreateFontString(nil,"OVERLAY")
	tinsert(C.FontStrings,g)
	return g
end




-------------------------------------------------------------------------------
--Axis Setting Functions
-------------------------------------------------------------------------------
function GraphLFunctions:SetYMax(ymax)
	if ymax==self.YMax then
		return
	end

	self.YMax=ymax

	self.NeedsUpdate=true
end

function GraphLFunctions:SetYAxis(ymin,ymax)
	if self.YMin==ymin and self.YMax==ymax then
		return
	end

	self.YMin=ymin
	self.YMax=ymax

	self.NeedsUpdate=true
end

function GraphLFunctions:SetMinMaxY(val)
	if self.MinMaxY==val then
		return
	end

	self.MinMaxY=val
	self.NeedsUpdate=true
end

function GraphLFunctions:SetXAxis(xmin,xmax)
	if self.XMin==xmin and self.XMax==xmax then
		return
	end

	self.XMin=xmin
	self.XMax=xmax

	self.NeedsUpdate=true
end

function GraphLFunctions:SetAutoScale(auto)
	self.AutoScale=auto

	self.NeedsUpdate=true
end

--The various Lock Functions let you use Autoscale but holds the locked points in place
function GraphLFunctions:LockXMin(state)
	if state==nil then
		self.LockOnXMin = not self.LockOnXMin
		return
	end
	self.LockOnXMin = state
end

function GraphLFunctions:LockXMax(state)
	if state==nil then
		self.LockOnXMax = not self.LockOnXMax
		return
	end
	self.LockOnXMax = state
end

function GraphLFunctions:LockYMin(state)
	if state==nil then
		self.LockOnYMin = not self.LockOnYMin
		return
	end
	self.LockOnYMin = state
end

function GraphLFunctions:LockYMax(state)
	if state==nil then
		self.LockOnYMax = not self.LockOnYMax
		return
	end
	self.LockOnYMax = state
end



-------------------------------------------------------------------------------
--Grid & Axis Drawing Functions
-------------------------------------------------------------------------------
function GraphLFunctions:SetAxisDrawing(xaxis, yaxis)
	if xaxis==self.XAxisDrawn and self.YAxisDrawn==yaxis then
		return
	end

	self.XAxisDrawn=xaxis
	self.YAxisDrawn=yaxis

	self.NeedsUpdate=true
end

function GraphLFunctions:SetGridSpacing(xspacing,yspacing)
	if xspacing==self.XGridInterval and self.YGridInterval==yspacing then
		return
	end

	self.XGridInterval=xspacing
	self.YGridInterval=yspacing

	self.NeedsUpdate=true
end

function GraphLFunctions:SetAxisColor(color)
	if self.AxisColor[1]==color[1] and self.AxisColor[2]==color[2] and self.AxisColor[3]==color[3] and self.AxisColor[4]==color[4] then
		return
	end

	self.AxisColor=color

	self.NeedsUpdate=true
end

function GraphLFunctions:SetGridColor(color)
	if self.GridColor[1]==color[1] and self.GridColor[2]==color[2] and self.GridColor[3]==color[3] and self.GridColor[4]==color[4] then
		return
	end

	self.GridColor=color

	self.NeedsUpdate=true
end

function GraphLFunctions:SetYLabels(Left,Right)
	self.YLabelsLeft=Left
	self.YLabelsRight=Right

	self.NeedsUpdate=true
end


function GraphLFunctions:CreateGridlines()
	local Width=self:GetWidth()
	local Height=self:GetHeight()
	local i
	self:HideLines(self)
	self:HideFontStrings(self)

	if self.YGridInterval then
		local LowerYGridLine,UpperYGridLine,TopSpace
		LowerYGridLine=self.YMin/self.YGridInterval
		LowerYGridLine=math_max(math_floor(LowerYGridLine),math_ceil(LowerYGridLine))
		UpperYGridLine=self.YMax/self.YGridInterval
		UpperYGridLine=math_min(math_floor(UpperYGridLine),math_ceil(UpperYGridLine))
		TopSpace=Height*(1-(UpperYGridLine*self.YGridInterval-self.YMin)/(self.YMax-self.YMin))
		for i=LowerYGridLine,UpperYGridLine do
			if i~=0 or not self.YAxisDrawn then
				local YPos,T,F
				YPos=Height*(i*self.YGridInterval-self.YMin)/(self.YMax-self.YMin)
				T=self:DrawLine(self,0,YPos,Width,YPos,24,self.GridColor,"BACKGROUND")

				if (i~=UpperYGridLine) or (TopSpace>12) then
					if self.YLabelsLeft then
						F=self:FindFontString(self)
						F:SetFontObject("GameFontHighlightSmall")
						F:SetTextColor(1,1,1)
						F:ClearAllPoints()
						F:SetPoint("BOTTOMLEFT",T,"LEFT",2,2)
						F:SetText(i*self.YGridInterval)
						F:Show()
					end

					if self.YLabelsRight then
						F=self:FindFontString(self)
						F:SetFontObject("GameFontHighlightSmall")
						F:SetTextColor(1,1,1)
						F:ClearAllPoints()
						F:SetPoint("BOTTOMRIGHT",T,"RIGHT",-2,2)
						F:SetText(i*self.YGridInterval)
						F:Show()
					end
				end
			end
		end
	end

	if self.XGridInterval then
		local LowerXGridLine,UpperXGridLine
		LowerXGridLine=self.XMin/self.XGridInterval
		LowerXGridLine=math_max(math_floor(LowerXGridLine),math_ceil(LowerXGridLine))
		UpperXGridLine=self.XMax/self.XGridInterval
		UpperXGridLine=math_min(math_floor(UpperXGridLine),math_ceil(UpperXGridLine))

		for i=LowerXGridLine,UpperXGridLine do
			if i~=0 or not self.XAxisDrawn then
				local XPos
				XPos=Width*(i*self.XGridInterval-self.XMin)/(self.XMax-self.XMin)
				self:DrawLine(self,XPos,0,XPos,Height,24,self.GridColor,"BACKGROUND")
			end
		end
	end

	if self.YAxisDrawn and self.YMax>=0 and self.YMin<=0 then
		local YPos,T, F

		YPos=Height*(-self.YMin)/(self.YMax-self.YMin)
		T=self:DrawLine(self,0,YPos,Width,YPos,24,self.AxisColor,"BACKGROUND")

		if self.YLabelsLeft then
			F=self:FindFontString(self)
			F:SetFontObject("GameFontHighlightSmall")
			F:SetTextColor(1,1,1)
			F:ClearAllPoints()
			F:SetPoint("BOTTOMLEFT",T,"LEFT",2,2)
			F:SetText("0")
			F:Show()
		end
		if self.YLabelsRight then
			F=self:FindFontString(self)
			F:SetFontObject("GameFontHighlightSmall")
			F:SetTextColor(1,1,1)
			F:ClearAllPoints()
			F:SetPoint("BOTTOMRIGHT",T,"RIGHT",-2,2)
			F:SetText("0")
			F:Show()
		end
	end

	if self.XAxisDrawn and self.XMax>=0 and self.XMin<=0 then
		local XPos;

		XPos=Width*(-self.XMin)/(self.XMax-self.XMin)
		self:DrawLine(self,XPos,0,XPos,Height,24,self.AxisColor,"BACKGROUND")
	end

	self.NeedsUpdate=true
end



--------------------------------------------------------------------------------
--Refresh functions
--------------------------------------------------------------------------------

function GraphLFunctions:OnUpdateGraph()
	if self.NeedsUpdate and self.RefreshGraph then
		self:RefreshGraph()
		self.NeedsUpdate=false
	end
end

--Line Graph
function GraphLFunctions:RefreshLineGraph()
	local k1, k2, series, point
	self:HideLines(self)

	if self.AutoScale and self.Data then
		local MinX, MaxX, MinY, MaxY = math_huge, -math_huge, math_huge, -math_huge
		--Go through line data first
		for k1, series in pairs(self.Data) do
			for k2, point in pairs(series.Points) do
				MinX=math_min(point[1],MinX)
				MaxX=math_max(point[1],MaxX)
				MinY=math_min(point[2],MinY)
				MaxY=math_max(point[2],MaxY)
			end
		end

		local XBorder, YBorder

		XBorder=0.1*(MaxX-MinX)
		YBorder=0.1*(MaxY-MinY)

		if not self.LockOnXMin then
			self.XMin=MinX-XBorder
		end
		if not self.LockOnXMax then
			self.XMax=MaxX+XBorder
		end
		if not self.LockOnYMin then
			self.YMin=MinY-YBorder
		end
		if not self.LockOnYMax then
			self.YMax=MaxY+YBorder
		end
	end

	self:CreateGridlines()

	local Width=self:GetWidth()
	local Height=self:GetHeight()

	for k1, series in pairs(self.Data) do
		local LastPoint
		LastPoint=nil

		for k2, point in pairs(series.Points) do
			if LastPoint then
				local TPoint={x=point[1];y=point[2]}

				TPoint.x=Width*(TPoint.x-self.XMin)/(self.XMax-self.XMin)
				TPoint.y=Height*(TPoint.y-self.YMin)/(self.YMax-self.YMin)

				self:DrawLine(self,LastPoint.x,LastPoint.y,TPoint.x,TPoint.y,32,series.Color)

				LastPoint=TPoint
			else
				LastPoint={x=point[1];y=point[2]}
				LastPoint.x=Width*(LastPoint.x-self.XMin)/(self.XMax-self.XMin)
				LastPoint.y=Height*(LastPoint.y-self.YMin)/(self.YMax-self.YMin)
			end
		end
	end
end





--Copied from Blizzard's TaxiFrame code and modifed for IMBA then remodified for GraphLib

-- The following function is used with permission from Daniel Stephens <iriel@vigilance-committee.org>
local TAXIROUTE_LINEFACTOR = 128/126; -- Multiplying factor for texture coordinates
local TAXIROUTE_LINEFACTOR_2 = TAXIROUTE_LINEFACTOR / 2; -- Half of that

-- T        - Texture
-- C        - Canvas Frame (for anchoring)
-- sx,sy    - Coordinate of start of line
-- ex,ey    - Coordinate of end of line
-- w        - Width of line
-- relPoint - Relative point on canvas to interpret coords (Default BOTTOMLEFT)
function lib:DrawLine(C, sx, sy, ex, ey, w, color, layer)
	local relPoint = "BOTTOMLEFT"

	if sx==ex then
		if sy==ey then
			return
		else
			return self:DrawVLine(C,sx,sy,ey,w, color, layer)
		end
	elseif sy==ey then
		return self:DrawHLine(C,sx,ex,sy,w, color, layer)
	end

	if not C.GraphLib_Lines then
		C.GraphLib_Lines={}
		C.GraphLib_Lines_Used={}
	end

	local T = tremove(C.GraphLib_Lines) or C:CreateTexture(nil, "ARTWORK")
	T:SetTexture(TextureDirectory.."line")
	tinsert(C.GraphLib_Lines_Used,T)

	T:SetDrawLayer(layer or "ARTWORK")

	T:SetVertexColor(color[1],color[2],color[3],color[4]);
	-- Determine dimensions and center point of line
	local dx,dy = ex - sx, ey - sy;
	local cx,cy = (sx + ex) / 2, (sy + ey) / 2;

	-- Normalize direction if necessary
	if (dx < 0) then
		dx,dy = -dx,-dy;
	end

	-- Calculate actual length of line
	local l = sqrt((dx * dx) + (dy * dy));

	-- Sin and Cosine of rotation, and combination (for later)
	local s,c = -dy / l, dx / l;
	local sc = s * c;

	-- Calculate bounding box size and texture coordinates
	local Bwid, Bhgt, BLx, BLy, TLx, TLy, TRx, TRy, BRx, BRy;
	if (dy >= 0) then
		Bwid = ((l * c) - (w * s)) * TAXIROUTE_LINEFACTOR_2;
		Bhgt = ((w * c) - (l * s)) * TAXIROUTE_LINEFACTOR_2;
		BLx, BLy, BRy = (w / l) * sc, s * s, (l / w) * sc;
		BRx, TLx, TLy, TRx = 1 - BLy, BLy, 1 - BRy, 1 - BLx;
		TRy = BRx;
	else
		Bwid = ((l * c) + (w * s)) * TAXIROUTE_LINEFACTOR_2;
		Bhgt = ((w * c) + (l * s)) * TAXIROUTE_LINEFACTOR_2;
		BLx, BLy, BRx = s * s, -(l / w) * sc, 1 + (w / l) * sc;
		BRy, TLx, TLy, TRy = BLx, 1 - BRx, 1 - BLx, 1 - BLy;
		TRx = TLy;
	end

	-- Thanks Blizzard for adding (-)10000 as a hard-cap and throwing errors!
	-- The cap was added in 3.1.0 and I think it was upped in 3.1.1
	--  (way less chance to get the error)
	if TLx > 10000 then TLx = 10000 elseif TLx < -10000 then TLx = -10000 end
	if TLy > 10000 then TLy = 10000 elseif TLy < -10000 then TLy = -10000 end
	if BLx > 10000 then BLx = 10000 elseif BLx < -10000 then BLx = -10000 end
	if BLy > 10000 then BLy = 10000 elseif BLy < -10000 then BLy = -10000 end
	if TRx > 10000 then TRx = 10000 elseif TRx < -10000 then TRx = -10000 end
	if TRy > 10000 then TRy = 10000 elseif TRy < -10000 then TRy = -10000 end
	if BRx > 10000 then BRx = 10000 elseif BRx < -10000 then BRx = -10000 end
	if BRy > 10000 then BRy = 10000 elseif BRy < -10000 then BRy = -10000 end

	-- Set texture coordinates and anchors
	T:ClearAllPoints();
	T:SetTexCoord(TLx, TLy, BLx, BLy, TRx, TRy, BRx, BRy);
	T:SetPoint("BOTTOMLEFT", C, relPoint, cx - Bwid, cy - Bhgt);
	T:SetPoint("TOPRIGHT", C, relPoint, cx + Bwid, cy + Bhgt);
	T:Show()
	return T
end

--Thanks to Celandro
function lib:DrawVLine(C, x, sy, ey, w, color, layer)
	local relPoint = "BOTTOMLEFT"

	if not C.GraphLib_Lines then
		C.GraphLib_Lines={}
		C.GraphLib_Lines_Used={}
	end

	local T = tremove(C.GraphLib_Lines) or C:CreateTexture(nil, "ARTWORK")
	T:SetTexture(TextureDirectory.."sline");
	tinsert(C.GraphLib_Lines_Used,T);

	T:SetDrawLayer(layer or "ARTWORK")

	T:SetVertexColor(color[1],color[2],color[3],color[4]);

	if sy>ey then
		sy, ey = ey, sy
	end

	-- Set texture coordinates and anchors
	T:ClearAllPoints();
	T:SetTexCoord(1, 0, 0, 0, 1, 1, 0, 1);
	T:SetPoint("BOTTOMLEFT", C, relPoint, x-w/2, sy);
	T:SetPoint("TOPRIGHT", C, relPoint, x+w/2, ey);
	T:Show()
	return T
end

function lib:DrawHLine(C, sx, ex, y, w, color, layer)
	local relPoint = "BOTTOMLEFT"

	if not C.GraphLib_Lines then
		C.GraphLib_Lines={}
		C.GraphLib_Lines_Used={}
	end

	local T = tremove(C.GraphLib_Lines) or C:CreateTexture(nil, "ARTWORK")
	T:SetTexture(TextureDirectory.."sline");
	tinsert(C.GraphLib_Lines_Used,T);

	T:SetDrawLayer(layer or "ARTWORK")

	T:SetVertexColor(color[1],color[2],color[3],color[4]);

	if sx>ex then
		sx, ex = ex, sx
	end

	-- Set texture coordinates and anchors
	T:ClearAllPoints();
	T:SetTexCoord(0, 0, 0, 1, 1, 0, 1, 1);
	T:SetPoint("BOTTOMLEFT", C, relPoint, sx, y-w/2);
	T:SetPoint("TOPRIGHT", C, relPoint, ex, y+w/2);
	T:Show()
	return T
end

function lib:HideLines(C)
	local i
	if C.GraphLib_Lines then
		for i = #C.GraphLib_Lines_Used, 1, -1 do
			C.GraphLib_Lines_Used[i]:Hide()
			tinsert(C.GraphLib_Lines,tremove(C.GraphLib_Lines_Used))
		end
	end
end
