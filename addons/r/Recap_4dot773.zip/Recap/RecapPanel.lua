﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ RecapPanel.lua (a popup panel showing details) ]]

local math_max = _G.math.max
local math_min = _G.math.min
local string_find = _G.string.find
local string_format = _G.string.format
local string_len = _G.string.len
local string_lower = _G.string.lower
local string_sub = _G.string.sub
local table_sort = _G.table.sort
local pairs = _G.pairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ local tables ]]

local dockoffset = { ["TOPRIGHTTOPLEFT"] = { x=-4,y=0 },
					 ["BOTTOMRIGHTBOTTOMLEFT"] = { x=-4,y=0 },
					 ["TOPLEFTTOPRIGHT"] = { x=4,y=0 },
					 ["BOTTOMLEFTBOTTOMRIGHT"] = { x=4,y=0 },
					 ["TOPRIGHTBOTTOMRIGHT"] = { x=0,y=-4 },
					 ["BOTTOMRIGHTTOPRIGHT"] = { x=0,y=4 },
					 ["TOPLEFTBOTTOMLEFT"] = { x=0,y=-4 },
					 ["BOTTOMLEFTTOPLEFT"] = { x=0,y=4 } }

--[[ local functions (precede first use) ]]

local function Recap_AmalgamateTotal(iTotal, iDetail)

	-- subtotal and total Element is always blank
	iTotal.Element = ""

	-- start accumulating details into the total
	if iDetail.CritsEvents and iDetail.CritsEvents>0 then
		iTotal.CritsEvents = (iTotal.CritsEvents or 0) + iDetail.CritsEvents
	end
	if iDetail.Hits and iDetail.Hits>0 then
		iTotal.Hits = (iTotal.Hits or 0) + iDetail.Hits
	end
	if iDetail.HitsDmg and iDetail.HitsDmg>0 then
		iTotal.HitsDmg = (iTotal.HitsDmg or 0) + iDetail.HitsDmg
	end
	if iDetail.HitsMax and iDetail.HitsMax>0 then
		iTotal.HitsMax = math_max((iTotal.HitsMax or 0), iDetail.HitsMax)
	end
	if iDetail.HitsMin and iDetail.HitsMin>0 then
		iTotal.HitsMin = Recap_Min(iTotal.HitsMin, iDetail.HitsMin)
	end
	if iDetail.Crits and iDetail.Crits>0 then
		iTotal.Crits = (iTotal.Crits or 0) + iDetail.Crits
	end
	if iDetail.CritsDmg and iDetail.CritsDmg>0 then
		iTotal.CritsDmg = (iTotal.CritsDmg or 0) + iDetail.CritsDmg
	end
	if iDetail.CritsMax and iDetail.CritsMax>0 then
		iTotal.CritsMax = math_max((iTotal.CritsMax or 0), iDetail.CritsMax)
	end
	if iDetail.CritsMin and iDetail.CritsMin>0 then
		iTotal.CritsMin = Recap_Min(iTotal.CritsMin, iDetail.CritsMin)
	end
	if iDetail.Ticks and iDetail.Ticks>0 then
		iTotal.Ticks = (iTotal.Ticks or 0) + iDetail.Ticks
	end
	if iDetail.CritTicks and iDetail.CritTicks>0 then
		iTotal.CritTicks = (iTotal.CritTicks or 0) + iDetail.CritTicks
	end
	if iDetail.TicksDmg and iDetail.TicksDmg>0 then
		iTotal.TicksDmg = (iTotal.TicksDmg or 0) + iDetail.TicksDmg
	end
	if iDetail.TicksMax and iDetail.TicksMax>0 then
		iTotal.TicksMax = math_max((iTotal.TicksMax or 0), iDetail.TicksMax)
	end
	if iDetail.TicksMin and iDetail.TicksMin>0 then
		iTotal.TicksMin = Recap_Min(iTotal.TicksMin, iDetail.TicksMin)
	end
	if iDetail.Glances and iDetail.Glances>0 then
		iTotal.Glances = (iTotal.Glances or 0) + iDetail.Glances
	end
	if iDetail.GlancesDmg and iDetail.GlancesDmg>0 then
		iTotal.GlancesDmg = (iTotal.GlancesDmg or 0) + iDetail.GlancesDmg
	end
	if iDetail.GlancesMax and iDetail.GlancesMax>0 then
		iTotal.GlancesMax = math_max((iTotal.GlancesMax or 0), iDetail.GlancesMax)
	end
	if iDetail.GlancesMin and iDetail.GlancesMin>0 then
		iTotal.GlancesMin = Recap_Min(iTotal.GlancesMin, iDetail.GlancesMin)
	end
	if iDetail.Crushes and iDetail.Crushes>0 then
		iTotal.Crushes = (iTotal.Crushes or 0) + iDetail.Crushes
	end
	if iDetail.CrushDmg and iDetail.CrushDmg>0 then
		iTotal.CrushDmg = (iTotal.CrushDmg or 0) + iDetail.CrushDmg
	end
	if iDetail.CrushMax and iDetail.CrushMax>0 then
		iTotal.CrushMax = math_max((iTotal.CrushMax or 0), iDetail.CrushMax)
	end
	if iDetail.CrushMin and iDetail.CrushMin>0 then
		iTotal.CrushMin = Recap_Min(iTotal.CrushMin, iDetail.CrushMin)
	end

	if iDetail.Missed and iDetail.Missed>0 then
		iTotal.Missed = (iTotal.Missed or 0) + iDetail.Missed
	end
	if iDetail.Dodged and iDetail.Dodged>0 then
		iTotal.Dodged = (iTotal.Dodged or 0) + iDetail.Dodged
	end
	if iDetail.Parried and iDetail.Parried>0 then
		iTotal.Parried = (iTotal.Parried or 0) + iDetail.Parried
	end
	if iDetail.Blocked and iDetail.Blocked>0 then
		iTotal.Blocked = (iTotal.Blocked or 0) + iDetail.Blocked
	end
	if iDetail.Absorbed and iDetail.Absorbed>0 then
		iTotal.Absorbed = (iTotal.Absorbed or 0) + iDetail.Absorbed
	end
	if iDetail.Deflected and iDetail.Deflected>0 then
		iTotal.Deflected = (iTotal.Deflected or 0) + iDetail.Deflected
	end
	if iDetail.Evaded and iDetail.Evaded>0 then
		iTotal.Evaded = (iTotal.Evaded or 0) + iDetail.Evaded
	end
	if iDetail.Resisted and iDetail.Resisted>0 then
		iTotal.Resisted = (iTotal.Resisted or 0) + iDetail.Resisted
	end
	if iDetail.Reflected and iDetail.Reflected>0 then
		iTotal.Reflected = (iTotal.Reflected or 0) + iDetail.Reflected
	end
	if iDetail.Immune and iDetail.Immune>0 then
		iTotal.Immune = (iTotal.Immune or 0) + iDetail.Immune
	end

	if iDetail.PAbsorbs and iDetail.PAbsorbs>0 then
		iTotal.PAbsorbs = (iTotal.PAbsorbs or 0) + iDetail.PAbsorbs
	end
	if iDetail.PAbsorbsDmg and iDetail.PAbsorbsDmg>0 then
		iTotal.PAbsorbsDmg = (iTotal.PAbsorbsDmg or 0) + iDetail.PAbsorbsDmg
	end
	if iDetail.PBlocks and iDetail.PBlocks>0 then
		iTotal.PBlocks = (iTotal.PBlocks or 0) + iDetail.PBlocks
	end
	if iDetail.PBlocksDmg and iDetail.PBlocksDmg>0 then
		iTotal.PBlocksDmg = (iTotal.PBlocksDmg or 0) + iDetail.PBlocksDmg
	end
	if iDetail.PResists and iDetail.PResists>0 then
		iTotal.PResists = (iTotal.PResists or 0) + iDetail.PResists
	end
	if iDetail.PResistsDmg and iDetail.PResistsDmg>0 then
		iTotal.PResistsDmg = (iTotal.PResistsDmg or 0) + iDetail.PResistsDmg
	end
	if iDetail.PResistsRaw and iDetail.PResistsRaw>0 then
		iTotal.PResistsRaw = (iTotal.PResistsRaw or 0) + iDetail.PResistsRaw
	end

	if iDetail.EstResistedDmg and iDetail.EstResistedDmg>0 then
		iTotal.EstResistedDmg = (iTotal.EstResistedDmg or 0) + iDetail.EstResistedDmg
	end
	if iDetail.EstResistableDmg and iDetail.EstResistableDmg>0 then
		iTotal.EstResistableDmg = (iTotal.EstResistableDmg or 0) + iDetail.EstResistableDmg
	end

	if iDetail.ICount and iDetail.ICount>0 then
		iTotal.ICount = (iTotal.ICount or 0) + iDetail.ICount
	end
	if iDetail.ITotal and iDetail.ITotal>0 then
		iTotal.ITotal = (iTotal.ITotal or 0) + iDetail.ITotal
	end

	-- PrevTime is not used by subtotals or totals
end

local function RecapPanel_AmalgamateOutgoingTotals(iCombatant, AllLastOutgoingDetail)

	local rTemp = _G.recap_temp
	local i, iDetail, iEffect, iType, _, effectName, iTotal

	-- clear the totals
	rTemp.OutgoingTotals = wipe(rTemp.OutgoingTotals)

	-- create new table (OutgoingTotals) for amalgamated subtotals and totals
	--   this code is not strictly necessary if we are not merging pets, but is done for merge pets both on and off for consistency
	--   this costs some time and memory
	if iCombatant and iCombatant[AllLastOutgoingDetail] then
		for i, iDetail in pairs(iCombatant[AllLastOutgoingDetail]) do
			iEffect = i
			iType = tonumber(string_sub(iEffect,1,1))
			if (iType == 5) or (iType == 6) or (iType == 7) or (iType == 8) then
				if (iType == 5) or (iType == 7) then
					-- owner total, iEffect is already correct
				elseif (iType == 6) or (iType == 8) then
					-- pet total, calculate owner effect
					iType = tostring(iType - 1)
					_, _, effectName = string_find(iEffect, "^.-: (.+)$")
					iEffect = tostring(iType)..effectName
				end
				-- initialize if necessary
				if not rTemp.OutgoingTotals[iEffect] then
					rTemp.OutgoingTotals[iEffect] = {}
				end
				iTotal = rTemp.OutgoingTotals[iEffect]
				Recap_AmalgamateTotal(iTotal, iDetail)
			end
		end
	end
end

local function RecapPanel_DetailsTotalSort(e1,e2)

	local effect1,effect2

	if e1.Effect then
		effect1 = string_sub(e1.Effect,1,1)
	else
		effect1 = "0"
	end
	if e2.Effect then
		effect2 = string_sub(e2.Effect,1,1)
	else
		effect2 = "0"
	end
	if not e1.Total then
		e1.Total = 0
	end
	if not e2.Total then
		e2.Total = 0
	end

	if ((e1.Total>e2.Total) and (effect1==effect2)) or (effect1<effect2) then
		return true
	else
		return false
	end
end

local function RecapPanel_DetailsHitsSort(e1,e2)

	local effect1,effect2

	if e1.Effect then
		effect1 = string_sub(e1.Effect,1,1)
	else
		effect1 = "0"
	end
	if e2.Effect then
		effect2 = string_sub(e2.Effect,1,1)
	else
		effect2 = "0"
	end
	if not e1.Hits then
		e1.Hits = 0
	end
	if not e2.Hits then
		e2.Hits = 0
	end

	if ((e1.Hits>e2.Hits) and (effect1==effect2)) or (effect1<effect2) then
		return true
	else
		return false
	end
end

local function RecapPanel_DetailsToFromSort(e1,e2)

	local whom1,whom2

	if e1.Whom then
		whom1 = string_sub(e1.Whom,1,1)
	else
		whom1 = "0"
	end
	if e2.Whom then
		whom2 = string_sub(e2.Whom,1,1)
	else
		whom2 = "0"
	end
	if not e1.Total then
		e1.Total = 0
	end
	if not e2.Total then
		e2.Total = 0
	end

	if ((e1.Total>e2.Total) and (whom1==whom2)) or (whom1<whom2) then
		return true
	else
		return false
	end
end

local function RecapPanel_DetailsToFromWhomSort(e1,e2)

	local whom1,whom2,name1,name2

	if e1.Whom then
		whom1 = string_sub(e1.Whom,1,1)
		name1 = string_sub(e1.Whom,2)
	else
		whom1 = "0"
	end
	if e2.Whom then
		whom2 = string_sub(e2.Whom,1,1)
		name2 = string_sub(e2.Whom,2)
	else
		whom2 = "0"
	end
	if not e1.Total then
		e1.Total = 0
	end
	if not e2.Total then
		e2.Total = 0
	end
	if ((name1<name2) and (whom1==whom2)) or (whom1<whom2) then
		return true
	else
		return false
	end
end

local function RecapPanel_DetailsEffectSort(e1,e2)

	local effect1,effect2,name1,name2

	if e1.Effect then
		effect1 = string_sub(e1.Effect,1,1)
		name1 = string_sub(e1.Effect,2)
	else
		effect1 = "0"
		name1 = ""
	end
	if e2.Effect then
		effect2 = string_sub(e2.Effect,1,1)
		name2 = string_sub(e2.Effect,2)
	else
		effect2 = "0"
		name2 = ""
	end

	if ((name1<name2) and (effect1==effect2)) or (effect1<effect2) then
		return true
	else
		return false
	end
end


local function RecapPanel_ConstructOutgoingDetails(iCombatant, iLast, AllLastOutgoingDetail)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local dmgtotal, healtotal, subtotaldmgtotal = 0,0,0
	local i, iList, iEffect, iType
	local amount, landed, attempted, overheal, missed, critted, count, subtotal

	-- clear the details
	rTemp.OutgoingDetailsListSize = 1
	rTemp.OutgoingDetailsList = wipe(rTemp.OutgoingDetailsList)

	-- first the non-totals
	if iCombatant and iCombatant[AllLastOutgoingDetail] then
		for i, iEffect in pairs(iCombatant[AllLastOutgoingDetail]) do
			if not rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize] then
				rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize] = {}
			end
			iList = rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize]
			iType = tonumber(string_sub(i,1,1))

			-- with 4.71 we have two new Total menu choices, one with damage only, one with healing only
			-- if using either, skip entries of the opposite type
			if (((iType == 1) or (iType == 2)) and (rOpt.OutgoingPanelDetail.value ~= "TotalHeal") and (rOpt.OutgoingPanelDetail.value ~= "TotalPSHeal")) or
			   (((iType == 3) or (iType == 4)) and (rOpt.OutgoingPanelDetail.value ~= "TotalDmg") and (rOpt.OutgoingPanelDetail.value ~= "TotalPSDmg")) then

				-- ignore types 5, 6, 7, and 8 -- they have already been amalgamated into a separate table
				iList.Effect = i
				if iEffect.Effect then
					-- stripped pure effect
					iList.PureEffect = iEffect.Effect -- hidden field
				end
				iList.FullyQualifiedEffect = i -- hidden field
				iList.SpellID = iEffect.SpellID
				amount = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
				iList.Total = amount -- if healing, this is the total raw healing (actual healing + overhealing)
				if (iType == 1) or (iType == 2) then
					-- damage done
					if rUser.View=="Last" and iCombatant.WasInLast then
						-- use times for Last fight
						if iCombatant["LastTime_"..iLast] and (iCombatant["LastTime_"..iLast] > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant["LastTime_"..iLast])
						else
							iList.TotalPS = 0
						end
					else
						-- use times for All fights
						if iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTime)
						else
							iList.TotalPS = 0
						end
					end
				else
					-- healing
					if rUser.View=="Last" and iCombatant.WasInLast then
						-- use times for Last fight
						if iCombatant["LastTimeHeal_"..iLast] and (iCombatant["LastTimeHeal_"..iLast] > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant["LastTimeHeal_"..iLast])
						else
							iList.TotalPS = 0
						end
					else
						-- use times for All fights
						if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTimeHeal)
						else
							iList.TotalPS = 0
						end
					end
				end
				iList.Max = math_max(iEffect.TicksMax or 0,math_max(iEffect.HitsMax or 0,math_max(iEffect.CritsMax or 0,math_max(iEffect.CrushMax or 0,iEffect.GlancesMax or 0))))
				landed = (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0) + (iEffect.Ticks or 0)
				critted = (iEffect.Crits or 0)
				iList.Avg = string_format("%d",(landed>0 and Recap_Div0(amount, landed) or 0))

				-- misses or overhealing
				attempted = 0
				if (iType == 1) or (iType == 2) then
					missed = (iEffect.Missed or 0) + (iEffect.Blocked or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0)
					attempted = missed + (iEffect.CritsEvents or 0)
					if (missed > 0) and (missed == attempted) then
						-- adjust for rare cases with immune or other misses for effects that are ticks only
						attempted = attempted + (iEffect.Ticks or 0)
					end
					if (attempted > 0) then
						iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*missed, attempted))
						iList.Casts = attempted
					end
				elseif (iType == 3) or (iType == 4) then
					attempted = (iEffect.CritsEvents or 0)
					-- overhealing (stored in the miss slot) calcs
					overheal = (iEffect.Missed or 0)
					if (amount > 0) then
						iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*overheal, amount))
					end
					if (attempted > 0) then
						iList.Casts = attempted
					end
					-- change the total to be actual healing, not raw healing
					amount = math_max(amount - overheal, 0)
					iList.Total = amount
					if rUser.View=="Last" and iCombatant.WasInLast then
						-- use times for Last fight
						if iCombatant["LastTimeHeal_"..iLast] and (iCombatant["LastTimeHeal_"..iLast] > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant["LastTimeHeal_"..iLast])
						else
							iList.TotalPS = 0
						end
					else
						-- use times for All fights
						if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTimeHeal)
						else
							iList.TotalPS = 0
						end
					end
				end

				-- crit % (only for hit damage, not for tick damage)
				if attempted>0 then
					iList.CritP = string_format("%.1f%%",Recap_Div1(100*critted, attempted))
				else
					iList.CritP = "--"
				end

				-- subtotals for percentage calcs
				if (iType == 1) or (iType == 2) then
					dmgtotal = dmgtotal + amount
				elseif (iType == 3) or (iType == 4) then
					healtotal = healtotal + amount
				end

				-- add element to the list (hide question mark values)
				if iEffect.Element and (iEffect.Element ~= "?") then
					iList.Element = iEffect.Element
				else
					iList.Element = ""
				end

				-- one hidden column for Interval (parallel code populates the fine details)
				count = (iEffect.ICount or 0)
				if count>0 then
					iList.Interval = string_format("%.1f",Recap_Div1((iEffect.ITotal or 0), 1000*count))
				else
					iList.Interval = "--"
				end

				rTemp.OutgoingDetailsListSize = rTemp.OutgoingDetailsListSize + 1
			end
		end
	end

	-- second the subtotals and totals (will only be iType 5 or 7)
	for i, iEffect in pairs(rTemp.OutgoingTotals) do
		if not rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize] then
			rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize] = {}
		end
		iList = rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize]
		iType = tonumber(string_sub(i,1,1))

		-- with 4.71 we have two new Total menu choices, one with damage only, one with healing only
		-- if using either, skip entries of the opposite type
		if ((iType == 5) and (rOpt.OutgoingPanelDetail.value ~= "TotalHeal") and (rOpt.OutgoingPanelDetail.value ~= "TotalPSHeal")) or
		   ((iType == 7) and (rOpt.OutgoingPanelDetail.value ~= "TotalDmg") and (rOpt.OutgoingPanelDetail.value ~= "TotalPSDmg")) then

			iList.Effect = i
			amount = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
			iList.Total = amount -- if healing, this is the total raw healing (actual healing + overhealing)
			if (iType == 5) then
				-- damage done
				if rUser.View=="Last" and iCombatant.WasInLast then
					-- use times for Last fight
					if iCombatant["LastTime_"..iLast] and (iCombatant["LastTime_"..iLast] > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant["LastTime_"..iLast])
					else
						iList.TotalPS = 0
					end
				else
					-- use times for All fights
					if iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTime)
					else
						iList.TotalPS = 0
					end
				end
			else
				-- healing
				if rUser.View=="Last" and iCombatant.WasInLast then
					-- use times for Last fight
					if iCombatant["LastTimeHeal_"..iLast] and (iCombatant["LastTimeHeal_"..iLast] > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant["LastTimeHeal_"..iLast])
					else
						iList.TotalPS = 0
					end
				else
					-- use times for All fights
					if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTimeHeal)
					else
						iList.TotalPS = 0
					end
				end
			end
			iList.Max = math_max(iEffect.TicksMax or 0,math_max(iEffect.HitsMax or 0,math_max(iEffect.CritsMax or 0,math_max(iEffect.CrushMax or 0,iEffect.GlancesMax or 0))))
			landed = (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0) + (iEffect.Ticks or 0)
			critted = (iEffect.Crits or 0)
			iList.Avg = string_format("%d",(landed>0 and Recap_Div0(amount, landed) or 0))

			-- misses or overhealing
			attempted = 0
			if (iType == 5) or ((iType == 7) and (string_find(i, rLocalize.Damage, 1, true))) then
				missed = (iEffect.Missed or 0) + (iEffect.Blocked or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) +
						(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
						(iEffect.Immune or 0) + (iEffect.Evaded or 0)
				attempted = missed + (iEffect.CritsEvents or 0)
				if (missed > 0) and (missed == attempted) then
					-- adjust for rare cases with immune or other misses for effects that are ticks only
					attempted = attempted + (iEffect.Ticks or 0)
				end
				if (attempted > 0) then
					iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*missed, attempted))
					iList.Casts = attempted
				end
			elseif ((iType == 7) and (string_find(i, rLocalize.ElementHealing, 1, true))) then
				attempted = (iEffect.CritsEvents or 0)
				-- overhealing (stored in the miss slot) calcs
				overheal = (iEffect.Missed or 0)
				if (amount > 0) then
					iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*overheal, amount))
				end
				if (attempted > 0) then
					iList.Casts = attempted
				end
				-- change the total to be actual healing, not raw healing
				amount = math_max(amount - overheal, 0)
				iList.Total = amount
				if rUser.View=="Last" and iCombatant.WasInLast then
					-- use times for Last fight
					if iCombatant["LastTimeHeal_"..iLast] and (iCombatant["LastTimeHeal_"..iLast] > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant["LastTimeHeal_"..iLast])
					else
						iList.TotalPS = 0
					end
				else
					-- use times for All fights
					if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTimeHeal)
					else
						iList.TotalPS = 0
					end
				end
			end

			-- crit % (only for hit damage, not for tick damage)
			if attempted>0 then
				iList.CritP = string_format("%.1f%%",Recap_Div1(100*critted, attempted))
			else
				iList.CritP = "--"
			end

			-- subtotals for percentage calcs
			if (iType == 5) then
				subtotaldmgtotal = subtotaldmgtotal + amount
			elseif (iType == 7) then
				-- do nothing, answer is always 100%
			end

			-- Subtotal and Total element always blank
			iList.Element = ""

			-- one hidden column for Interval (parallel code populates the fine details)
			count = (iEffect.ICount or 0)
			if count>0 then
				iList.Interval = string_format("%.1f",Recap_Div1((iEffect.ITotal or 0), 1000*count))
			else
				iList.Interval = "--"
			end

			rTemp.OutgoingDetailsListSize = rTemp.OutgoingDetailsListSize + 1
		end
	end
	rTemp.OutgoingDetailsList[rTemp.OutgoingDetailsListSize] = nil -- keep as nil

	for i=1, rTemp.OutgoingDetailsListSize-1 do
		iList = rTemp.OutgoingDetailsList[i]
		iType = tonumber(string_sub(iList.Effect,1,1))
		if (iType == 1) or (iType == 2) then
			subtotal = dmgtotal
		elseif (iType == 3) or (iType == 4) then
			subtotal = healtotal
		elseif (iType == 5) or (iType == 6) then
			subtotal = subtotaldmgtotal
		elseif (iType == 7) or (iType == 8) then
			-- answer is always 100%
			subtotal = iList.Total
		end
		if subtotal>0 then
			iList.TotalP = Recap_Div1(100*iList.Total, subtotal)
		else
			iList.TotalP = 0
		end
	end

	if (rTemp.OutgoingDetailSortBy == "Hits") then
		table_sort(rTemp.OutgoingDetailsList,RecapPanel_DetailsTotalSort)
	else
		table_sort(rTemp.OutgoingDetailsList,RecapPanel_DetailsEffectSort)
	end

end

local function RecapPanel_ConstructTargetDetails(name, iCombatant, AllLastTargetDetail)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local dmgtotal, healtotal = 0,0
	local i, j, iList, iWhom, iType, sourceName, targetName, amount, subtotal

	-- clear the details
	rTemp.TargetDetailsListSize = 1
	rTemp.TargetDetailsList = wipe(rTemp.TargetDetailsList)

	-- placebo when data not available
	if not rOpt.MatrixData.value then
		if not rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] then
			rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] = {}
		end
		iList = rTemp.TargetDetailsList[rTemp.TargetDetailsListSize]
		iList.Whom = "0"..rLocalize.MatrixDataModeNotEnabled
		rTemp.TargetDetailsListSize = rTemp.TargetDetailsListSize + 1
	elseif (name == rTemp.GroupTotal) or (name == rTemp.NonGroupTotal) then
		if not rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] then
			rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] = {}
		end
		iList = rTemp.TargetDetailsList[rTemp.TargetDetailsListSize]
		iList.Whom = "0"..rLocalize.NotAvailable
		rTemp.TargetDetailsListSize = rTemp.TargetDetailsListSize + 1
	else
		if iCombatant and iCombatant[AllLastTargetDetail] then
			for i, iWhom in pairs(iCombatant[AllLastTargetDetail]) do
				if iWhom then
					iType = tonumber(string_sub(i,1,1))
					if iType then
						targetName = Recap_StripGUIDsFromCombatant(string_sub(i,2))
						for j in pairs(iWhom) do
							if (iWhom[j] > 0) then
								if not rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] then
									rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] = {}
								end
								iList = rTemp.TargetDetailsList[rTemp.TargetDetailsListSize]
								if (j == "Total") then
									-- owner
									sourceName = Recap_StripGUIDsFromCombatant(name)
								else
									-- pet
									sourceName = Recap_StripGUIDsFromCombatant(j)
								end
								iList.Whom = tostring(iType)..sourceName.." ==> "..targetName
								amount = (iWhom[j] or 0)
								iList.Total = amount
								-- subtotals for percentage calcs
								if (iType == 1) or (iType == 2) then
									dmgtotal = dmgtotal + amount
								elseif (iType == 3) or (iType == 4) then
									healtotal = healtotal + amount
								end
								rTemp.TargetDetailsListSize = rTemp.TargetDetailsListSize + 1
							end
						end
					end
				end
			end
		end
	end
	rTemp.TargetDetailsList[rTemp.TargetDetailsListSize] = nil -- keep as nil

	for i=1, rTemp.TargetDetailsListSize-1 do
		iList = rTemp.TargetDetailsList[i]
		if iList then
			iType = tonumber(string_sub(iList.Whom,1,1))
			if (iType == 1) or (iType == 2) then
				subtotal = dmgtotal
			elseif (iType == 3) or (iType == 4) then
				subtotal = healtotal
			end
			if iList.Total then
				if subtotal>0 then
					iList.TotalP = Recap_Div1(100*iList.Total, subtotal)
				else
					iList.TotalP = 0
				end
			else
				iList.Total = nil
				iList.TotalP = nil
			end
		end
	end

	if (rTemp.TargetDetailSortBy == "Hits") then
		table_sort(rTemp.TargetDetailsList,RecapPanel_DetailsToFromSort)
	else
		table_sort(rTemp.TargetDetailsList,RecapPanel_DetailsToFromWhomSort)
	end

end

local function RecapPanel_AmalgamateIncomingTotals(iCombatant, AllLastIncomingDetail)

	local rTemp = _G.recap_temp
	local i, iDetail, iEffect, iType, _, effectName, iTotal

	-- clear the totals
	rTemp.IncomingTotals = wipe(rTemp.IncomingTotals)

	-- create new table (IncomingTotals) for amalgamated subtotals and totals
	--   this code is not strictly necessary if we are not merging pets, but is done for merge pets both on and off for consistency
	--   this costs some time and memory
	if iCombatant and iCombatant[AllLastIncomingDetail] then
		for i, iDetail in pairs(iCombatant[AllLastIncomingDetail]) do
			iEffect = i
			iType = tonumber(string_sub(iEffect,1,1))
			if (iType == 5) or (iType == 6) or (iType == 7) or (iType == 8) then
				if (iType == 5) or (iType == 7) then
					-- owner total, iEffect is already correct
				elseif (iType == 6) or (iType == 8) then
					-- pet total, calculate owner effect
					iType = tostring(iType - 1)
					_, _, effectName = string_find(iEffect, "^.-: (.+)$")
					iEffect = tostring(iType)..effectName
				end
				-- initialize if necessary
				if not rTemp.IncomingTotals[iEffect] then
					rTemp.IncomingTotals[iEffect] = {}
				end
				iTotal = rTemp.IncomingTotals[iEffect]
				Recap_AmalgamateTotal(iTotal, iDetail)
			end
		end
	end
end

local function RecapPanel_ConstructIncomingDetails(iCombatant, iLast, AllLastIncomingDetail)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local dmgtotal, healtotal, subtotaldmgtotal = 0,0,0
	local i, iList, iEffect, iType
	local amount, landed, attempted, overheal, missed, critted, count, subtotal

	-- clear the details
	rTemp.IncomingDetailsListSize = 1
	rTemp.IncomingDetailsList = wipe(rTemp.IncomingDetailsList)

	-- first the non-totals
	if iCombatant and iCombatant[AllLastIncomingDetail] then
		for i, iEffect in pairs(iCombatant[AllLastIncomingDetail]) do
			if not rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize] then
				rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize] = {}
			end
			iList = rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize]
			iType = tonumber(string_sub(i,1,1))

			-- with 4.71 we have two new Total menu choices, one with damage only, one with healing only
			-- if using either, skip entries of the opposite type
			if (((iType == 1) or (iType == 2)) and (rOpt.IncomingPanelDetail.value ~= "TotalHeal") and (rOpt.IncomingPanelDetail.value ~= "TotalPSHeal")) or
			   (((iType == 3) or (iType == 4)) and (rOpt.IncomingPanelDetail.value ~= "TotalDmg") and (rOpt.IncomingPanelDetail.value ~= "TotalPSDmg")) then

				-- ignore types 5, 6, 7, and 8 -- they have already been amalgamated into a separate table
				iList.Effect = i
				if iEffect.Effect then
					-- stripped pure effect
					iList.PureEffect = iEffect.Effect -- hidden field
				end
				iList.FullyQualifiedEffect = i -- hidden field
				iList.SpellID = iEffect.SpellID
				amount = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
				iList.Total = amount -- if healing, this is the total raw healing (actual healing + overhealing)
				if (iType == 1) or (iType == 2) then
					-- damage taken
					if rUser.View=="Last" and iCombatant.WasInLast then
						-- use times for Last fight
						if iCombatant["LastTimeIn_"..iLast] and (iCombatant["LastTimeIn_"..iLast] > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant["LastTimeIn_"..iLast])
						else
							iList.TotalPS = 0
						end
					else
						-- use times for All fights
						if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) then
							iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTimeIn)
						else
							iList.TotalPS = 0
						end
					end
				else
					-- healing received (HPS not possible since we don't keep a time for this)
					iList.TotalPS = 0
				end
				iList.Max = math_max(iEffect.TicksMax or 0,math_max(iEffect.HitsMax or 0,math_max(iEffect.CritsMax or 0,math_max(iEffect.CrushMax or 0,iEffect.GlancesMax or 0))))
				landed = (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0) + (iEffect.Ticks or 0)
				critted = (iEffect.Crits or 0)
				iList.Avg = string_format("%d",(landed>0 and Recap_Div0(amount, landed) or 0))

				-- misses or overhealing
				attempted = 0
				if (iType == 1) or (iType == 2) then
					missed = (iEffect.Missed or 0) + (iEffect.Blocked or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0)
					attempted = missed + (iEffect.CritsEvents or 0)
					if (missed > 0) and (missed == attempted) then
						-- adjust for rare cases with immune or other misses for effects that are ticks only
						attempted = attempted + (iEffect.Ticks or 0)
					end
					if (attempted > 0) then
						iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*missed, attempted))
						iList.Casts = attempted
					end
				elseif (iType == 3) or (iType == 4) then
					attempted = (iEffect.CritsEvents or 0)
					-- overhealing (stored in the miss slot) calcs
					overheal = (iEffect.Missed or 0)
					if (amount > 0) then
						iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*overheal, amount))
					end
					if (attempted > 0) then
						iList.Casts = attempted
					end
					-- change the total to be actual healing, not raw healing
					amount = math_max(amount - overheal, 0)
					iList.Total = amount
					-- healing received (HPS not possible since we don't keep a time for this)
					iList.TotalPS = 0
				end

				-- crit % (only for hit damage, not for tick damage)
				if attempted>0 then
					iList.CritP = string_format("%.1f%%",Recap_Div1(100*critted, attempted))
				else
					iList.CritP = "--"
				end

				-- subtotals for percentage calcs
				if (iType == 1) or (iType == 2) then
					dmgtotal = dmgtotal + amount
				elseif (iType == 3) or (iType == 4) then
					healtotal = healtotal + amount
				end

				-- add element to the list (hide question mark values)
				if iEffect.Element and (iEffect.Element ~= "?") then
					iList.Element = iEffect.Element
				else
					iList.Element = ""
				end

				-- one hidden column for Interval (parallel code populates the fine details)
				count = (iEffect.ICount or 0)
				if count>0 then
					iList.Interval = string_format("%.1f",Recap_Div1((iEffect.ITotal or 0), 1000*count))
				else
					iList.Interval = "--"
				end

				rTemp.IncomingDetailsListSize = rTemp.IncomingDetailsListSize + 1
			end
		end
	end

	-- second the subtotals and totals (will only be iType 5 or 7)
	for i, iEffect in pairs(rTemp.IncomingTotals) do
		if not rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize] then
			rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize] = {}
		end
		iList = rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize]
		iType = tonumber(string_sub(i,1,1))

		-- with 4.71 we have two new Total menu choices, one with damage only, one with healing only
		-- if using either, skip entries of the opposite type
		if ((iType == 5) and (rOpt.IncomingPanelDetail.value ~= "TotalHeal") and (rOpt.IncomingPanelDetail.value ~= "TotalPSHeal")) or
		   ((iType == 7) and (rOpt.IncomingPanelDetail.value ~= "TotalDmg") and (rOpt.IncomingPanelDetail.value ~= "TotalPSDmg")) then

			iList.Effect = i
			amount = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
			iList.Total = amount -- if healing, this is the total raw healing (actual healing + overhealing)
			if (iType == 5) then
				-- damage taken
				if rUser.View=="Last" and iCombatant.WasInLast then
					-- use times for Last fight
					if iCombatant["LastTimeIn_"..iLast] and (iCombatant["LastTimeIn_"..iLast] > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant["LastTimeIn_"..iLast])
					else
						iList.TotalPS = 0
					end
				else
					-- use times for All fights
					if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) then
						iList.TotalPS = Recap_Div1(amount, iCombatant.TotalTimeIn)
					else
						iList.TotalPS = 0
					end
				end
			else
				-- healing received (HPS not possible since we don't keep a time for this)
				iList.TotalPS = 0
			end
			iList.Max = math_max(iEffect.TicksMax or 0,math_max(iEffect.HitsMax or 0,math_max(iEffect.CritsMax or 0,math_max(iEffect.CrushMax or 0,iEffect.GlancesMax or 0))))
			landed = (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0) + (iEffect.Ticks or 0)
			critted = (iEffect.Crits or 0)
			iList.Avg = string_format("%d",(landed>0 and Recap_Div0(amount, landed) or 0))

			-- misses or overhealing
			attempted = 0
			if (iType == 5) or ((iType == 7) and (string_find(i, rLocalize.Damage, 1, true))) then
				missed = (iEffect.Missed or 0) + (iEffect.Blocked or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) +
						(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
						(iEffect.Immune or 0) + (iEffect.Evaded or 0)
				attempted = missed + (iEffect.CritsEvents or 0)
				if (missed > 0) and (missed == attempted) then
					-- adjust for rare cases with immune or other misses for effects that are ticks only
					attempted = attempted + (iEffect.Ticks or 0)
				end
				if (attempted > 0) then
					iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*missed, attempted))
					iList.Casts = attempted
				end
			elseif ((iType == 7) and (string_find(i, rLocalize.ElementHealing, 1, true))) then
				attempted = (iEffect.CritsEvents or 0)
				-- overhealing (stored in the miss slot) calcs
				overheal = (iEffect.Missed or 0)
				if (amount > 0) then
					iList.MissPOverP = string_format("%.1f%%",Recap_Div1(100*overheal, amount))
				end
				if (attempted > 0) then
					iList.Casts = attempted
				end
				-- change the total to be actual healing, not raw healing
				amount = math_max(amount - overheal, 0)
				iList.Total = amount
				-- healing received (HPS not possible since we don't keep a time for this)
				iList.TotalPS = 0
			end

			-- crit % (only for hit damage, not for tick damage)
			if attempted>0 then
				iList.CritP = string_format("%.1f%%",Recap_Div1(100*critted, attempted))
			else
				iList.CritP = "--"
			end

			-- subtotals for percentage calcs
			if (iType == 5) then
				subtotaldmgtotal = subtotaldmgtotal + amount
			elseif (iType == 7) then
				-- do nothing, answer is always 100%
			end

			-- Subtotal and Total element always blank
			iList.Element = ""

			-- one hidden column for Interval (parallel code populates the fine details)
			count = (iEffect.ICount or 0)
			if count>0 then
				iList.Interval = string_format("%.1f",Recap_Div1((iEffect.ITotal or 0), 1000*count))
			else
				iList.Interval = "--"
			end

			rTemp.IncomingDetailsListSize = rTemp.IncomingDetailsListSize + 1
		end
	end
	rTemp.IncomingDetailsList[rTemp.IncomingDetailsListSize] = nil -- keep as nil

	for i=1, rTemp.IncomingDetailsListSize-1 do
		iList = rTemp.IncomingDetailsList[i]
		iType = tonumber(string_sub(iList.Effect,1,1))
		if (iType == 1) or (iType == 2) then
			subtotal = dmgtotal
		elseif (iType == 3) or (iType == 4) then
			subtotal = healtotal
		elseif (iType == 5) or (iType == 6) then
			subtotal = subtotaldmgtotal
		elseif (iType == 7) or (iType == 8) then
			-- answer is always 100%
			subtotal = iList.Total
		end
		if subtotal>0 then
			iList.TotalP = Recap_Div1(100*iList.Total, subtotal)
		else
			iList.TotalP = 0
		end
	end

	if (rTemp.IncomingDetailSortBy == "Hits") then
		table_sort(rTemp.IncomingDetailsList,RecapPanel_DetailsTotalSort)
	else
		table_sort(rTemp.IncomingDetailsList,RecapPanel_DetailsEffectSort)
	end

end

local function RecapPanel_ConstructSourceDetails(name, iCombatant, AllLastSourceDetail)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local dmgtotal, healtotal = 0,0
	local i, j, iList, iWhom, iType, sourceName, targetName, amount, subtotal

	-- clear the details
	rTemp.SourceDetailsListSize = 1
	rTemp.SourceDetailsList = wipe(rTemp.SourceDetailsList)

	-- placebo when data not available
	if not rOpt.MatrixData.value then
		if not rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] then
			rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] = {}
		end
		iList = rTemp.SourceDetailsList[rTemp.SourceDetailsListSize]
		iList.Whom = "0"..rLocalize.MatrixDataModeNotEnabled
		rTemp.SourceDetailsListSize = rTemp.SourceDetailsListSize + 1
	elseif (name == rTemp.GroupTotal) or (name == rTemp.NonGroupTotal) then
		if not rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] then
			rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] = {}
		end
		iList = rTemp.SourceDetailsList[rTemp.SourceDetailsListSize]
		iList.Whom = "0"..rLocalize.NotAvailable
		rTemp.SourceDetailsListSize = rTemp.SourceDetailsListSize + 1
	else
		if iCombatant and iCombatant[AllLastSourceDetail] then
			for i, iWhom in pairs(iCombatant[AllLastSourceDetail]) do
				if iWhom then
					iType = tonumber(string_sub(i,1,1))
					if iType then
						sourceName = Recap_StripGUIDsFromCombatant(string_sub(i,2))
						for j in pairs(iWhom) do
							if (iWhom[j] > 0) then
								if not rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] then
									rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] = {}
								end
								iList = rTemp.SourceDetailsList[rTemp.SourceDetailsListSize]
								if (j == "Total") then
									-- owner
									targetName = Recap_StripGUIDsFromCombatant(name)
								else
									-- pet
									targetName = Recap_StripGUIDsFromCombatant(j)
								end
								iList.Whom = tostring(iType)..sourceName.." ==> "..targetName
								amount = (iWhom[j] or 0)
								iList.Total = amount
								-- subtotals for percentage calcs
								if (iType == 1) or (iType == 2) then
									dmgtotal = dmgtotal + amount
								elseif (iType == 3) or (iType == 4) then
									healtotal = healtotal + amount
								end
								rTemp.SourceDetailsListSize = rTemp.SourceDetailsListSize + 1
							end
						end
					end
				end
			end
		end
	end
	rTemp.SourceDetailsList[rTemp.SourceDetailsListSize] = nil -- keep as nil

	for i=1, rTemp.SourceDetailsListSize-1 do
		iList = rTemp.SourceDetailsList[i]
		if iList then
			iType = tonumber(string_sub(iList.Whom,1,1))
			if (iType == 1) or (iType == 2) then
				subtotal = dmgtotal
			elseif (iType == 3) or (iType == 4) then
				subtotal = healtotal
			end
			if iList.Total then
				if subtotal>0 then
					iList.TotalP = Recap_Div1(100*iList.Total, subtotal)
				else
					iList.TotalP = 0
				end
			else
				iList.Total = nil
				iList.TotalP = nil
			end
		end
	end

	if (rTemp.SourceDetailSortBy == "Hits") then
		table_sort(rTemp.SourceDetailsList,RecapPanel_DetailsToFromSort)
	else
		table_sort(rTemp.SourceDetailsList,RecapPanel_DetailsToFromWhomSort)
	end

end

local function RecapPanel_ConstructOtherDetails(iCombatant, AllLastOtherDetail)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, count, iList, iEffect, iType

	-- clear the details
	rTemp.OtherDetailsListSize = 1
	rTemp.OtherDetailsList = wipe(rTemp.OtherDetailsList)

	-- placebo when data not available
	if (not rOpt.OtherData.value) then
		if not rTemp.OtherDetailsList[rTemp.OtherDetailsListSize] then
			rTemp.OtherDetailsList[rTemp.OtherDetailsListSize] = {}
		end
		iList = rTemp.OtherDetailsList[rTemp.OtherDetailsListSize]
		iList.Effect = "0"..rLocalize.OtherDataModeNotEnabled
		rTemp.OtherDetailsListSize = rTemp.OtherDetailsListSize + 1
	else
		if iCombatant and iCombatant[AllLastOtherDetail] then
			for i, iEffect in pairs(iCombatant[AllLastOtherDetail]) do
				if not rTemp.OtherDetailsList[rTemp.OtherDetailsListSize] then
					rTemp.OtherDetailsList[rTemp.OtherDetailsListSize] = {}
				end
				iList = rTemp.OtherDetailsList[rTemp.OtherDetailsListSize]
				iType = string_sub(i,1,1)
				iList.Effect = tostring(iType)..Recap_StripOwnerAndGUIDsFromEffect(string_sub(i,2))
				if iEffect.Effect then
					-- stripped pure effect
					iList.PureEffect = iEffect.Effect -- hidden field
				end
				iList.FullyQualifiedEffect = i -- hidden field
				iList.SpellID = iEffect.SpellID
				iList.Hits = (iEffect.Hits or 0)
				iList.Total = (iEffect.Total or "--")
				iList.Attribute = (iEffect.Attribute or "--")
				-- two hidden columns for Interval and Duration (parallel code populates the fine details)
				count = (iEffect.ICount or 0)
				if count>0 then
					iList.Interval = string_format("%.1f",Recap_Div1((iEffect.ITotal or 0),1000*count))
				else
					iList.Interval = "--"
				end
				count = (iEffect.DCount or 0)
				if count>0 then
					iList.Duration = string_format("%.1f",Recap_Div1((iEffect.DTotal or 0),1000*count))
				else
					iList.Duration = "--"
				end

				rTemp.OtherDetailsListSize = rTemp.OtherDetailsListSize + 1
			end
		end
	end
	rTemp.OtherDetailsList[rTemp.OtherDetailsListSize] = nil -- keep as nil

	if (rTemp.OtherDetailSortBy == "Hits") then
		table_sort(rTemp.OtherDetailsList,RecapPanel_DetailsHitsSort)
	else
		table_sort(rTemp.OtherDetailsList,RecapPanel_DetailsEffectSort)
	end

end

local function RecapPanel_PopulateOutgoingDetails(iCombatant, sel)

	local rUser = _G.recap_user
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local effect, i, j, miss, totalmiss, iEffect, iType

	if (not sel) or (sel < 0) then
		return
	end

	RecapPanelOutgoingEffectText:SetText("--")
	RecapPanelOutgoingSpellIDText:SetText("--")
	RecapPanelOutgoingElementText:SetText("--")
	RecapPanelOutgoingDamageText:SetText("--")
	RecapPanelOutgoingGlancesText:SetText("--")
	RecapPanelOutgoingHitsText:SetText("--")
	RecapPanelOutgoingCritsText:SetText("--")
	RecapPanelOutgoingCrushesText:SetText("--")
	RecapPanelOutgoingTicksText:SetText("--")
	RecapPanelOutgoingGlancesMinText:SetText("--")
	RecapPanelOutgoingHitsMinText:SetText("--")
	RecapPanelOutgoingCritsMinText:SetText("--")
	RecapPanelOutgoingCrushMinText:SetText("--")
	RecapPanelOutgoingTicksMinText:SetText("--")
	RecapPanelOutgoingGlancesAvgText:SetText("--")
	RecapPanelOutgoingHitsAvgText:SetText("--")
	RecapPanelOutgoingCritsAvgText:SetText("--")
	RecapPanelOutgoingCrushAvgText:SetText("--")
	RecapPanelOutgoingTicksAvgText:SetText("--")
	RecapPanelOutgoingGlancesMaxText:SetText("--")
	RecapPanelOutgoingHitsMaxText:SetText("--")
	RecapPanelOutgoingCritsMaxText:SetText("--")
	RecapPanelOutgoingCrushMaxText:SetText("--")
	RecapPanelOutgoingTicksMaxText:SetText("--")
	RecapPanelOutgoingMissMissedText:SetText("--")
	RecapPanelOutgoingMissDodgedText:SetText("--")
	RecapPanelOutgoingMissParriedText:SetText("--")
	RecapPanelOutgoingMissBlockedText:SetText("--")
	RecapPanelOutgoingMissAbsorbedText:SetText("--")
	RecapPanelOutgoingMissEvadedText:SetText("--")
	RecapPanelOutgoingMissDeflectedText:SetText("--")
	RecapPanelOutgoingMissResistedText:SetText("--")
	RecapPanelOutgoingMissReflectedText:SetText("--")
	RecapPanelOutgoingMissImmuneText:SetText("--")
	RecapPanelOutgoingMissPText:SetText("--")
	RecapPanelOutgoingCastsText:SetText("--")
	RecapPanelOutgoingGlancePText:SetText("--")
	RecapPanelOutgoingCritPText:SetText("--")
	RecapPanelOutgoingCrushPText:SetText("--")
	RecapPanelOutgoingCritTickPText:SetText("--")
	RecapPanelOutgoingPartAbsorbsText:SetText("--")
	RecapPanelOutgoingPartAbsorbsTotalText:SetText("--")
	RecapPanelOutgoingPartAbsorbsAvgText:SetText("--")
	RecapPanelOutgoingPartBlocksText:SetText("--")
	RecapPanelOutgoingPartBlocksTotalText:SetText("--")
	RecapPanelOutgoingPartBlocksAvgText:SetText("--")
	RecapPanelOutgoingPartResistsText:SetText("--")
	RecapPanelOutgoingPartResistsTotalText:SetText("--")
	RecapPanelOutgoingPartResistsAvgText:SetText("--")
	RecapPanelOutgoingPartResistsPercentText:SetText("--")
	RecapPanelOutgoingEstimatedTotalResistedText:SetText("--")
	RecapPanelOutgoingIntervalCountText:SetText("--")
	RecapPanelOutgoingIntervalAvgText:SetText("--")

	if sel == 0 then
		-- BLAH is this preventing column menu showing for Load ?
		return
	end

	if not rTemp.OutgoingDetailsList then
		return
	end

	if not rTemp.OutgoingDetailsList[sel] then
		return
	end

	effect = rTemp.OutgoingDetailsList[sel].Effect

	if not effect then
		return
	end

	iType = string_sub(effect,1,1)

	-- details come from different places depending on whether we are dealing with a non-total, or with a subtotal or total
	if (iType=="1") or (iType=="2") or (iType=="3") or (iType=="4") then
		if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
			-- main Last
			local theDetail = "LastOutgoingDetail_"..rTemp.DisplayLastFight
			if iCombatant and iCombatant[theDetail] and iCombatant[theDetail][effect] then
				iEffect = iCombatant[theDetail][effect]
			else
				return
			end
		else
			-- main All, or loaded data set
			if iCombatant and iCombatant.OutgoingDetail and iCombatant.OutgoingDetail[effect] then
				iEffect = iCombatant.OutgoingDetail[effect]
			else
				return
			end
		end
	else
		if rTemp.OutgoingTotals and rTemp.OutgoingTotals[effect] then
			iEffect = rTemp.OutgoingTotals[effect]
		else
			return
		end
	end

	if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(effect, rLocalize.Damage, 1, true))) then
		RecapPanelOutgoingDamageLabel:SetText(rLocalize.Damage)
		RecapPanelOutgoingMissPLabel:SetText(rLocalize.Misses)
	else
		RecapPanelOutgoingDamageLabel:SetText(rLocalize.Heal)
		RecapPanelOutgoingMissPLabel:SetText(rLocalize.Overheal)
	end

	-- effect (repeated so we know which effect we are viewing)
	RecapPanelOutgoingEffectText:SetText(Recap_StripOwnerAndGUIDsFromEffect(string_sub(effect,2)))
	if (iType=="1") or (iType=="2") then
		RecapPanelOutgoingEffectText:SetTextColor(unpack(rColor.DmgOut))
	elseif (iType=="3") or (iType=="4") then
		RecapPanelOutgoingEffectText:SetTextColor(unpack(rColor.Heal))
	elseif (iType=="5") or (iType=="6") then
		RecapPanelOutgoingEffectText:SetTextColor(unpack(rColor.DmgOutPale))
	elseif (iType=="7") or (iType=="8") then
		if string_find(effect, rLocalize.ElementHealing, 1, true) then
			RecapPanelOutgoingEffectText:SetTextColor(unpack(rColor.HealPale))
		else
			RecapPanelOutgoingEffectText:SetTextColor(unpack(rColor.DmgOutPale))
		end
	end

	-- spellID
	if iEffect.SpellID then
		RecapPanelOutgoingSpellIDText:SetText("["..iEffect.SpellID.."]")
	else
		RecapPanelOutgoingSpellIDText:SetText("--")
	end

	-- element (hide question mark values)
	if iEffect.Element and (iEffect.Element ~= "?") then
		RecapPanelOutgoingElementText:SetText(iEffect.Element)
	else
		RecapPanelOutgoingElementText:SetText("")
	end

	-- damage
	RecapPanelOutgoingDamageText:SetText((iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0))

	-- glances
	i = (iEffect.Glances or 0)
	if i>0 then
		RecapPanelOutgoingGlancesText:SetText(i)
		RecapPanelOutgoingGlancesMinText:SetText(iEffect.GlancesMin or "--")
		RecapPanelOutgoingGlancesAvgText:SetFormattedText("%d",Recap_Div0((iEffect.GlancesDmg or 0),i))
		RecapPanelOutgoingGlancesMaxText:SetText(iEffect.GlancesMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelOutgoingGlancesText:SetText(0)
	end

	-- hits
	i = (iEffect.Hits or 0)
	if i>0 then
		RecapPanelOutgoingHitsText:SetText(i)
		RecapPanelOutgoingHitsMinText:SetText(iEffect.HitsMin or "--")
		RecapPanelOutgoingHitsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.HitsDmg or 0),i))
		RecapPanelOutgoingHitsMaxText:SetText(iEffect.HitsMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelOutgoingHitsText:SetText(0)
	end

	-- crits
	i = (iEffect.Crits or 0)
	if i>0 then
		RecapPanelOutgoingCritsText:SetText(i)
		RecapPanelOutgoingCritsMinText:SetText(iEffect.CritsMin or "--")
		RecapPanelOutgoingCritsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.CritsDmg or 0),i))
		RecapPanelOutgoingCritsMaxText:SetText(iEffect.CritsMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelOutgoingCritsText:SetText(0)
	end

	-- crushes
	i = (iEffect.Crushes or 0)
	if i>0 then
		RecapPanelOutgoingCrushesText:SetText(i)
		RecapPanelOutgoingCrushMinText:SetText(iEffect.CrushMin or "--")
		RecapPanelOutgoingCrushAvgText:SetFormattedText("%d",Recap_Div0((iEffect.CrushDmg or 0),i))
		RecapPanelOutgoingCrushMaxText:SetText(iEffect.CrushMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelOutgoingCrushesText:SetText(0)
	end

	-- ticks
	i = (iEffect.Ticks or 0)
	if i>0 then
		RecapPanelOutgoingTicksText:SetText(i)
		RecapPanelOutgoingTicksMinText:SetText(iEffect.TicksMin or "--")
		RecapPanelOutgoingTicksAvgText:SetFormattedText("%d",Recap_Div0((iEffect.TicksDmg or 0),i))
		RecapPanelOutgoingTicksMaxText:SetText(iEffect.TicksMax or 0)
	elseif iEffect.TicksMax then
		RecapPanelOutgoingTicksText:SetText(0)
	end

	-- miss or overheal % (and crit % and crush % and glance % calcs)
	if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(effect, rLocalize.Damage, 1, true))) then
		-- miss
		miss = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
				(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
				(iEffect.Immune or 0) + (iEffect.Evaded or 0)
		i = miss + (iEffect.CritsEvents or 0)
		if (miss > 0) and (miss == i) then
			-- adjust for rare cases with immune or other misses for effects that are ticks only
			i = i + (iEffect.Ticks or 0)
		end
		if i>0 then
			RecapPanelOutgoingGlancePText:SetText(((i==iEffect.Glances) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Glances or 0),i)))
			RecapPanelOutgoingCritPText:SetText(((i==iEffect.Crits) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Crits or 0),i)))
			RecapPanelOutgoingCrushPText:SetText(((i==iEffect.Crushes) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Crushes or 0),i)))
			if (miss==i) then
				RecapPanelOutgoingMissPText:SetText(i.." (100%)")
			else
				RecapPanelOutgoingMissPText:SetFormattedText("%d (%.1f%%)",miss,Recap_Div1(100*miss,i))
			end
			RecapPanelOutgoingCastsText:SetText(i)
		end
		i = (iEffect.Ticks or 0)
		if i>0 then
			RecapPanelOutgoingCritTickPText:SetText(((i==iEffect.CritTicks) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.CritTicks or 0),i)))
		end
	else
		-- crits for heals
		i = (iEffect.CritsEvents or 0)
		if i>0 then
			RecapPanelOutgoingCritPText:SetText(((i==iEffect.Crits) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Crits or 0),i)))
			RecapPanelOutgoingCastsText:SetText(i)
		end
		-- effect numbers are full heals, not actual heals
		local heal, overheal
		heal = (iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0)
		overheal = (iEffect.Missed or 0)
		if heal>0 then
			RecapPanelOutgoingMissPText:SetFormattedText("%d (%d%%)",iEffect.Missed or 0,Recap_Div0(100*overheal,heal))
		end
		i = (iEffect.Ticks or 0)
		if i>0 then
			RecapPanelOutgoingCritTickPText:SetText(((i==iEffect.CritTicks) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.CritTicks or 0),i)))
		end
	end

	if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(effect, rLocalize.Damage, 1, true))) then
		-- non-healing misses
		totalmiss = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
					(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
					(iEffect.Immune or 0) + (iEffect.Evaded or 0)
		i = totalmiss + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
		if (totalmiss > 0) and (totalmiss == i) then
			-- adjust for rare cases with immune or other misses for effects that are ticks only
			i = i + (iEffect.Ticks or 0)
		end
		if i>0 then
			if iEffect.Missed and (iEffect.Missed > 0) then
				RecapPanelOutgoingMissMissedText:SetFormattedText("%d (%.1f%%)", iEffect.Missed, Recap_Div1(100*iEffect.Missed,i))
			end
			if iEffect.Dodged and (iEffect.Dodged > 0) then
				RecapPanelOutgoingMissDodgedText:SetFormattedText("%d (%.1f%%)", iEffect.Dodged, Recap_Div1(100*iEffect.Dodged,i))
			end
			if iEffect.Parried and (iEffect.Parried > 0) then
				RecapPanelOutgoingMissParriedText:SetFormattedText("%d (%.1f%%)", iEffect.Parried, Recap_Div1(100*iEffect.Parried,i))
			end
			if iEffect.Blocked and (iEffect.Blocked > 0) then
				RecapPanelOutgoingMissBlockedText:SetFormattedText("%d (%.1f%%)", iEffect.Blocked, Recap_Div1(100*iEffect.Blocked,i))
			end
			if iEffect.Deflected and (iEffect.Deflected > 0) then
				RecapPanelOutgoingMissDeflectedText:SetFormattedText("%d (%.1f%%)", iEffect.Deflected, Recap_Div1(100*iEffect.Deflected,i))
			end
			if iEffect.Resisted and (iEffect.Resisted > 0) then
				RecapPanelOutgoingMissResistedText:SetFormattedText("%d (%.1f%%)", iEffect.Resisted, Recap_Div1(100*iEffect.Resisted,i))
			end
			if iEffect.Reflected and (iEffect.Reflected > 0) then
				RecapPanelOutgoingMissReflectedText:SetFormattedText("%d (%.1f%%)", iEffect.Reflected, Recap_Div1(100*iEffect.Reflected,i))
			end
			if iEffect.Absorbed and (iEffect.Absorbed > 0) then
				RecapPanelOutgoingMissAbsorbedText:SetFormattedText("%d (%.1f%%)", iEffect.Absorbed, Recap_Div1(100*iEffect.Absorbed,i))
			end
			if iEffect.Immune and (iEffect.Immune > 0) then
				RecapPanelOutgoingMissImmuneText:SetFormattedText("%d (%.1f%%)", iEffect.Immune, Recap_Div1(100*iEffect.Immune,i))
			end
			if iEffect.Evaded and (iEffect.Evaded > 0) then
				RecapPanelOutgoingMissEvadedText:SetFormattedText("%d (%.1f%%)", iEffect.Evaded, Recap_Div1(100*iEffect.Evaded,i))
			end
		end
	end

	-- partials
	i = (iEffect.PAbsorbs or 0)
	if i>0 then
		RecapPanelOutgoingPartAbsorbsText:SetText(i)
		RecapPanelOutgoingPartAbsorbsTotalText:SetText(iEffect.PAbsorbsDmg or 0)
		RecapPanelOutgoingPartAbsorbsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.PAbsorbsDmg or 0),i))
	end
	i = (iEffect.PBlocks or 0)
	if i>0 then
		RecapPanelOutgoingPartBlocksText:SetText(i)
		RecapPanelOutgoingPartBlocksTotalText:SetText(iEffect.PBlocksDmg or 0)
		RecapPanelOutgoingPartBlocksAvgText:SetFormattedText("%d",Recap_Div0((iEffect.PBlocksDmg or 0),i))
	end
	i = (iEffect.PResists or 0)
	if i>0 then
		RecapPanelOutgoingPartResistsText:SetText(i)
		RecapPanelOutgoingPartResistsTotalText:SetText(iEffect.PResistsDmg or 0)
		RecapPanelOutgoingPartResistsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.PResistsDmg or 0),i))
		if iEffect.PResistsRaw and (iEffect.PResistsRaw > 0) then
			RecapPanelOutgoingPartResistsPercentText:SetFormattedText("%.1f%%", Recap_Div1(100*(iEffect.PResistsDmg or 0),iEffect.PResistsRaw))
		end
	end

	-- estimated total resistance and percentage
	i = (iEffect.EstResistedDmg or 0)
	j = (iEffect.EstResistableDmg or 0)
	if (i>0) and (j>0) then
		RecapPanelOutgoingEstimatedTotalResistedText:SetFormattedText("%d (%.1f%%)", Recap_Round0(i), Recap_Div1(100*i,j))
	end

	-- interval count and average (parallel code populates the list)
	i = (iEffect.ICount or 0)
	if i>0 then
		RecapPanelOutgoingIntervalCountText:SetText(i)
		RecapPanelOutgoingIntervalAvgText:SetFormattedText("%.2f",Recap_Div2((iEffect.ITotal or 0),1000*i))
	end

	-- remember which index we loaded
	rTemp.OutgoingDetailLoaded = sel
end

local function RecapPanel_PopulateIncomingDetails(iCombatant, sel)

	local rUser = _G.recap_user
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local effect, i, j, miss, totalmiss, iEffect, iType

	if (not sel) or (sel < 0) then
		return
	end

	RecapPanelIncomingEffectText:SetText("--")
	RecapPanelIncomingSpellIDText:SetText("--")
	RecapPanelIncomingElementText:SetText("--")
	RecapPanelIncomingDamageText:SetText("--")
	RecapPanelIncomingGlancesText:SetText("--")
	RecapPanelIncomingHitsText:SetText("--")
	RecapPanelIncomingCritsText:SetText("--")
	RecapPanelIncomingCrushesText:SetText("--")
	RecapPanelIncomingTicksText:SetText("--")
	RecapPanelIncomingGlancesMinText:SetText("--")
	RecapPanelIncomingHitsMinText:SetText("--")
	RecapPanelIncomingCritsMinText:SetText("--")
	RecapPanelIncomingCrushMinText:SetText("--")
	RecapPanelIncomingTicksMinText:SetText("--")
	RecapPanelIncomingGlancesAvgText:SetText("--")
	RecapPanelIncomingHitsAvgText:SetText("--")
	RecapPanelIncomingCritsAvgText:SetText("--")
	RecapPanelIncomingCrushAvgText:SetText("--")
	RecapPanelIncomingTicksAvgText:SetText("--")
	RecapPanelIncomingGlancesMaxText:SetText("--")
	RecapPanelIncomingHitsMaxText:SetText("--")
	RecapPanelIncomingCritsMaxText:SetText("--")
	RecapPanelIncomingCrushMaxText:SetText("--")
	RecapPanelIncomingTicksMaxText:SetText("--")
	RecapPanelIncomingMissMissedText:SetText("--")
	RecapPanelIncomingMissDodgedText:SetText("--")
	RecapPanelIncomingMissParriedText:SetText("--")
	RecapPanelIncomingMissBlockedText:SetText("--")
	RecapPanelIncomingMissAbsorbedText:SetText("--")
	RecapPanelIncomingMissEvadedText:SetText("--")
	RecapPanelIncomingMissDeflectedText:SetText("--")
	RecapPanelIncomingMissResistedText:SetText("--")
	RecapPanelIncomingMissReflectedText:SetText("--")
	RecapPanelIncomingMissImmuneText:SetText("--")
	RecapPanelIncomingMissPText:SetText("--")
	RecapPanelIncomingCastsText:SetText("--")
	RecapPanelIncomingGlancePText:SetText("--")
	RecapPanelIncomingCritPText:SetText("--")
	RecapPanelIncomingCrushPText:SetText("--")
	RecapPanelIncomingCritTickPText:SetText("--")
	RecapPanelIncomingPartAbsorbsText:SetText("--")
	RecapPanelIncomingPartAbsorbsTotalText:SetText("--")
	RecapPanelIncomingPartAbsorbsAvgText:SetText("--")
	RecapPanelIncomingPartBlocksText:SetText("--")
	RecapPanelIncomingPartBlocksTotalText:SetText("--")
	RecapPanelIncomingPartBlocksAvgText:SetText("--")
	RecapPanelIncomingPartResistsText:SetText("--")
	RecapPanelIncomingPartResistsTotalText:SetText("--")
	RecapPanelIncomingPartResistsAvgText:SetText("--")
	RecapPanelIncomingPartResistsPercentText:SetText("--")
	RecapPanelIncomingEstimatedTotalResistedText:SetText("--")
	RecapPanelIncomingIntervalCountText:SetText("--")
	RecapPanelIncomingIntervalAvgText:SetText("--")

	if sel == 0 then
		return
	end

	if not rTemp.IncomingDetailsList then
		return
	end

	if not rTemp.IncomingDetailsList[sel] then
		return
	end

	effect = rTemp.IncomingDetailsList[sel].Effect

	if not effect then
		return
	end

	iType = string_sub(effect,1,1)

	-- details come from different places depending on whether we are dealing with a non-total, or with a subtotal or total
	if (iType=="1") or (iType=="2") or (iType=="3") or (iType=="4") then
		if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
			-- main Last
			local theDetail = "LastIncomingDetail_"..rTemp.DisplayLastFight
			if iCombatant and iCombatant[theDetail] and iCombatant[theDetail][effect] then
				iEffect = iCombatant[theDetail][effect]
			else
				return
			end
		else
			-- main All, or loaded data set
			if iCombatant and iCombatant.IncomingDetail and iCombatant.IncomingDetail[effect] then
				iEffect = iCombatant.IncomingDetail[effect]
			else
				return
			end
		end
	else
		if rTemp.IncomingTotals and rTemp.IncomingTotals[effect] then
			iEffect = rTemp.IncomingTotals[effect]
		else
			return
		end
	end

	if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(effect, rLocalize.Damage, 1, true))) then
		RecapPanelIncomingDamageLabel:SetText(rLocalize.Damage)
		RecapPanelIncomingMissPLabel:SetText(rLocalize.Misses)
	else
		RecapPanelIncomingDamageLabel:SetText(rLocalize.Heal)
		RecapPanelIncomingMissPLabel:SetText(rLocalize.Overheal)
	end

	-- effect (repeated so we know which effect we are viewing)
	RecapPanelIncomingEffectText:SetText(Recap_StripOwnerAndGUIDsFromEffect(string_sub(effect,2)))
	if (iType=="1") or (iType=="2") then
		RecapPanelIncomingEffectText:SetTextColor(unpack(rColor.DmgIn))
	elseif (iType=="3") or (iType=="4") then
		RecapPanelIncomingEffectText:SetTextColor(unpack(rColor.Heal))
	elseif (iType=="5") or (iType=="6") then
		RecapPanelIncomingEffectText:SetTextColor(unpack(rColor.DmgInPale))
	elseif (iType=="7") or (iType=="8") then
		if string_find(effect, rLocalize.ElementHealing, 1, true) then
			RecapPanelIncomingEffectText:SetTextColor(unpack(rColor.HealPale))
		else
			RecapPanelIncomingEffectText:SetTextColor(unpack(rColor.DmgInPale))
		end
	end

	-- spellID
	if iEffect.SpellID then
		RecapPanelIncomingSpellIDText:SetText("["..iEffect.SpellID.."]")
	else
		RecapPanelIncomingSpellIDText:SetText("--")
	end

	-- element (hide question mark values)
	if iEffect.Element and (iEffect.Element ~= "?") then
		RecapPanelIncomingElementText:SetText(iEffect.Element)
	else
		RecapPanelIncomingElementText:SetText("")
	end

	-- damage
	RecapPanelIncomingDamageText:SetText((iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0))

	-- glances
	i = (iEffect.Glances or 0)
	if i>0 then
		RecapPanelIncomingGlancesText:SetText(i)
		RecapPanelIncomingGlancesMinText:SetText(iEffect.GlancesMin or "--")
		RecapPanelIncomingGlancesAvgText:SetFormattedText("%d",Recap_Div0((iEffect.GlancesDmg or 0),i))
		RecapPanelIncomingGlancesMaxText:SetText(iEffect.GlancesMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelIncomingGlancesText:SetText(0)
	end

	-- hits
	i = (iEffect.Hits or 0)
	if i>0 then
		RecapPanelIncomingHitsText:SetText(i)
		RecapPanelIncomingHitsMinText:SetText(iEffect.HitsMin or "--")
		RecapPanelIncomingHitsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.HitsDmg or 0),i))
		RecapPanelIncomingHitsMaxText:SetText(iEffect.HitsMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelIncomingHitsText:SetText(0)
	end

	-- crits
	i = (iEffect.Crits or 0)
	if i>0 then
		RecapPanelIncomingCritsText:SetText(i)
		RecapPanelIncomingCritsMinText:SetText(iEffect.CritsMin or "--")
		RecapPanelIncomingCritsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.CritsDmg or 0),i))
		RecapPanelIncomingCritsMaxText:SetText(iEffect.CritsMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelIncomingCritsText:SetText(0)
	end

	-- crushes
	i = (iEffect.Crushes or 0)
	if i>0 then
		RecapPanelIncomingCrushesText:SetText(i)
		RecapPanelIncomingCrushMinText:SetText(iEffect.CrushMin or "--")
		RecapPanelIncomingCrushAvgText:SetFormattedText("%d",Recap_Div0((iEffect.CrushDmg or 0),i))
		RecapPanelIncomingCrushMaxText:SetText(iEffect.CrushMax or 0)
	elseif iEffect.CritsEvents then
		RecapPanelIncomingCrushesText:SetText(0)
	end

	-- ticks
	i = (iEffect.Ticks or 0)
	if i>0 then
		RecapPanelIncomingTicksText:SetText(i)
		RecapPanelIncomingTicksMinText:SetText(iEffect.TicksMin or "--")
		RecapPanelIncomingTicksAvgText:SetFormattedText("%d",Recap_Div0((iEffect.TicksDmg or 0),i))
		RecapPanelIncomingTicksMaxText:SetText(iEffect.TicksMax or 0)
	elseif iEffect.TicksMax then
		RecapPanelIncomingTicksText:SetText(0)
	end

	-- miss or overheal % (and crit % and crush % and glance % calcs)
	if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(effect, rLocalize.Damage, 1, true))) then
		-- miss
		miss = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
				(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
				(iEffect.Immune or 0) + (iEffect.Evaded or 0)
		i = miss + (iEffect.CritsEvents or 0)
		if (miss > 0) and (miss == i) then
			-- adjust for rare cases with immune or other misses for effects that are ticks only
			i = i + (iEffect.Ticks or 0)
		end
		if i>0 then
			RecapPanelIncomingGlancePText:SetText(((i==iEffect.Glances) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Glances or 0),i)))
			RecapPanelIncomingCritPText:SetText(((i==iEffect.Crits) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Crits or 0),i)))
			RecapPanelIncomingCrushPText:SetText(((i==iEffect.Crushes) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Crushes or 0),i)))
			if (miss==i) then
				RecapPanelIncomingMissPText:SetText(i.." (100%)")
			else
				RecapPanelIncomingMissPText:SetFormattedText("%d (%.1f%%)",miss,Recap_Div1(100*miss,i))
			end
			RecapPanelIncomingCastsText:SetText(i)
		end
		i = (iEffect.Ticks or 0)
		if i>0 then
			RecapPanelIncomingCritTickPText:SetText(((i==iEffect.CritTicks) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.CritTicks or 0),i)))
		end
	else
		-- crits for heals
		i = (iEffect.CritsEvents or 0)
		if i>0 then
			RecapPanelIncomingCritPText:SetText(((i==iEffect.Crits) and "100%") or string_format("%.1f%%",Recap_Div1(100*(iEffect.Crits or 0),i)))
			RecapPanelIncomingCastsText:SetText(i)
		end
		-- effect numbers are full heals, not actual heals
		local heal, overheal
		heal = (iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0)
		overheal = (iEffect.Missed or 0)
		if heal>0 then
			RecapPanelIncomingMissPText:SetFormattedText("%d (%d%%)",iEffect.Missed or 0,Recap_Div0(100*overheal,heal))
		end
	end

	if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(effect, rLocalize.Damage, 1, true))) then
		-- non-healing misses
		totalmiss = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
					(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
					(iEffect.Immune or 0) + (iEffect.Evaded or 0)
		i = totalmiss + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
		if (totalmiss > 0) and (totalmiss == i) then
			-- adjust for rare cases with immune or other misses for effects that are ticks only
			i = i + (iEffect.Ticks or 0)
		end
		if i>0 then
			if iEffect.Missed and (iEffect.Missed > 0) then
				RecapPanelIncomingMissMissedText:SetFormattedText("%d (%.1f%%)", iEffect.Missed, Recap_Div1(100*iEffect.Missed,i))
			end
			if iEffect.Dodged and (iEffect.Dodged > 0) then
				RecapPanelIncomingMissDodgedText:SetFormattedText("%d (%.1f%%)", iEffect.Dodged, Recap_Div1(100*iEffect.Dodged,i))
			end
			if iEffect.Parried and (iEffect.Parried > 0) then
				RecapPanelIncomingMissParriedText:SetFormattedText("%d (%.1f%%)", iEffect.Parried, Recap_Div1(100*iEffect.Parried,i))
			end
			if iEffect.Blocked and (iEffect.Blocked > 0) then
				RecapPanelIncomingMissBlockedText:SetFormattedText("%d (%.1f%%)", iEffect.Blocked, Recap_Div1(100*iEffect.Blocked,i))
			end
			if iEffect.Deflected and (iEffect.Deflected > 0) then
				RecapPanelIncomingMissDeflectedText:SetFormattedText("%d (%.1f%%)", iEffect.Deflected, Recap_Div1(100*iEffect.Deflected,i))
			end
			if iEffect.Resisted and (iEffect.Resisted > 0) then
				RecapPanelIncomingMissResistedText:SetFormattedText("%d (%.1f%%)", iEffect.Resisted, Recap_Div1(100*iEffect.Resisted,i))
			end
			if iEffect.Reflected and (iEffect.Reflected > 0) then
				RecapPanelIncomingMissReflectedText:SetFormattedText("%d (%.1f%%)", iEffect.Reflected, Recap_Div1(100*iEffect.Reflected,i))
			end
			if iEffect.Absorbed and (iEffect.Absorbed > 0) then
				RecapPanelIncomingMissAbsorbedText:SetFormattedText("%d (%.1f%%)", iEffect.Absorbed, Recap_Div1(100*iEffect.Absorbed,i))
			end
			if iEffect.Immune and (iEffect.Immune > 0) then
				RecapPanelIncomingMissImmuneText:SetFormattedText("%d (%.1f%%)", iEffect.Immune, Recap_Div1(100*iEffect.Immune,i))
			end
			if iEffect.Evaded and (iEffect.Evaded > 0) then
				RecapPanelIncomingMissEvadedText:SetFormattedText("%d (%.1f%%)", iEffect.Evaded, Recap_Div1(100*iEffect.Evaded,i))
			end
		end
	end

	-- partials
	i = (iEffect.PAbsorbs or 0)
	if i>0 then
		RecapPanelIncomingPartAbsorbsText:SetText(i)
		RecapPanelIncomingPartAbsorbsTotalText:SetText(iEffect.PAbsorbsDmg or 0)
		RecapPanelIncomingPartAbsorbsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.PAbsorbsDmg or 0),i))
	end
	i = (iEffect.PBlocks or 0)
	if i>0 then
		RecapPanelIncomingPartBlocksText:SetText(i)
		RecapPanelIncomingPartBlocksTotalText:SetText(iEffect.PBlocksDmg or 0)
		RecapPanelIncomingPartBlocksAvgText:SetFormattedText("%d",Recap_Div0((iEffect.PBlocksDmg or 0),i))
	end
	i = (iEffect.PResists or 0)
	if i>0 then
		RecapPanelIncomingPartResistsText:SetText(i)
		RecapPanelIncomingPartResistsTotalText:SetText(iEffect.PResistsDmg or 0)
		RecapPanelIncomingPartResistsAvgText:SetFormattedText("%d",Recap_Div0((iEffect.PResistsDmg or 0),i))
		if iEffect.PResistsRaw and (iEffect.PResistsRaw > 0) then
			RecapPanelIncomingPartResistsPercentText:SetFormattedText("%.1f%%", Recap_Div1(100*(iEffect.PResistsDmg or 0),iEffect.PResistsRaw))
		end
	end

	-- estimated total resistance and percentage
	i = (iEffect.EstResistedDmg or 0)
	j = (iEffect.EstResistableDmg or 0)
	if (i>0) and (j>0) then
		RecapPanelIncomingEstimatedTotalResistedText:SetFormattedText("%d (%.1f%%)", Recap_Round0(i), Recap_Div1(100*i,j))
	end

	-- interval count and average (parallel code populates the list)
	i = (iEffect.ICount or 0)
	if i>0 then
		RecapPanelIncomingIntervalCountText:SetText(i)
		RecapPanelIncomingIntervalAvgText:SetFormattedText("%.2f",Recap_Div2((iEffect.ITotal or 0),1000*i))
	end

	-- remember which index we loaded
	rTemp.IncomingDetailLoaded = sel
end

local function RecapPanel_PopulateOtherDetails(iCombatant, sel)

	local rUser = _G.recap_user
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local effect, i, iEffect, iType

	if (not sel) or (sel < 0) then
		return
	end

	RecapPanelOtherEffectText:SetText("--")
	RecapPanelOtherSpellIDText:SetText("--")
	RecapPanelOtherAttributeText:SetText("--")
	RecapPanelOtherTotalText:SetText("--")
	RecapPanelOtherHitsText:SetText("--")
	RecapPanelOtherAvgText:SetText("--")
	RecapPanelOtherMaxText:SetText("--")
	RecapPanelOtherMissesText:SetText("--")
	RecapPanelOtherDispelsText:SetText("--")
	RecapPanelOtherStealsText:SetText("--")
	RecapPanelOtherIntervalCountText:SetText("--")
	RecapPanelOtherIntervalAvgText:SetText("--")
	RecapPanelOtherDurationCountText:SetText("--")
	RecapPanelOtherDurationAvgText:SetText("--")

	if sel == 0 then
		return
	end

	if not rTemp.OtherDetailsList then
		return
	end

	if not rTemp.OtherDetailsList[sel] then
		return
	end

	effect = rTemp.OtherDetailsList[sel].Effect

	if not effect then
		return
	end

	iType = string_sub(effect,1,1)

	if (iType=="0") then
		return
	end

	if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
		-- main Last
		local theDetail = "LastOtherDetail_"..rTemp.DisplayLastFight
		if iCombatant and iCombatant[theDetail] and iCombatant[theDetail][rTemp.OtherDetailsList[sel].FullyQualifiedEffect] then
			iEffect = iCombatant[theDetail][rTemp.OtherDetailsList[sel].FullyQualifiedEffect]
		else
			return
		end
	else
		-- main All, or loaded data set
		if iCombatant and iCombatant.OtherDetail and iCombatant.OtherDetail[rTemp.OtherDetailsList[sel].FullyQualifiedEffect] then
			iEffect = iCombatant.OtherDetail[rTemp.OtherDetailsList[sel].FullyQualifiedEffect]
		else
			return
		end
	end

	-- effect (repeated so we know which effect we are viewing)
	RecapPanelOtherEffectText:SetText(Recap_StripOwnerAndGUIDsFromEffect(string_sub(effect,2)))
	if (iType=="1") or (iType=="2") then
		RecapPanelOtherEffectText:SetTextColor(unpack(rColor.DmgOut))
	elseif  (iType=="3") or (iType=="4") then
		RecapPanelOtherEffectText:SetTextColor(unpack(rColor.DmgIn))
	elseif (iType=="5") or (iType=="6") then
		RecapPanelOtherEffectText:SetTextColor(unpack(rColor.Heal))
	elseif (iType=="7") or (iType=="8") then
		RecapPanelOtherEffectText:SetTextColor(unpack(rColor.White))
	end

	-- spellID
	if iEffect.SpellID then
		RecapPanelOtherSpellIDText:SetText("["..iEffect.SpellID.."]")
	else
		RecapPanelOtherSpellIDText:SetText("--")
	end

	-- attribute
	if iEffect.Attribute then
		RecapPanelOtherAttributeText:SetText(iEffect.Attribute)
	end

	-- total, hits, misses, average, max
	i = (iEffect.Hits or 0)
	if i>0 then
		RecapPanelOtherHitsText:SetText(i)
		RecapPanelOtherMissesText:SetText((iEffect.Missed or 0))
		RecapPanelOtherTotalText:SetText(iEffect.Total or 0)
		RecapPanelOtherAvgText:SetFormattedText("%d",Recap_Div0((iEffect.Total or 0),i))
		RecapPanelOtherMaxText:SetText(iEffect.Max or 0)
	else
		RecapPanelOtherHitsText:SetText(0)
	end

	-- dispels
	if iEffect.Dispels and (iEffect.Dispels>0) then
		RecapPanelOtherDispelsText:SetText(iEffect.Dispels)
	end

	-- steals
	if iEffect.Steals and (iEffect.Steals>0) then
		RecapPanelOtherStealsText:SetText(iEffect.Steals)
	end

	-- interval count and average (parallel code populates the list)
	i = (iEffect.ICount or 0)
	if i>0 then
		RecapPanelOtherIntervalCountText:SetText(i)
		RecapPanelOtherIntervalAvgText:SetFormattedText("%.2f",Recap_Div2((iEffect.ITotal or 0),1000*i))
	end

	-- duration count and average (parallel code populates the list)
	i = (iEffect.DCount or 0)
	if i>0 then
		RecapPanelOtherDurationCountText:SetText(i)
		RecapPanelOtherDurationAvgText:SetFormattedText("%.2f",Recap_Div2((iEffect.DTotal or 0),1000*i))
	end

	-- remember which index we loaded
	rTemp.OtherDetailLoaded = sel
end

-- shows Blizzard spell tooltips if available
local function RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, iCombatant, sel)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local effect, iEffect, iType, _, spellID

	if (not sel) or (sel < 0) then
		return
	end

	if sel == 0 then
		return
	end

	if not rTemp.OutgoingDetailsList then
		return
	end

	if not rTemp.OutgoingDetailsList[sel] then
		return
	end

	effect = rTemp.OutgoingDetailsList[sel].Effect

	if not effect then
		return
	end

	iType = string_sub(effect,1,1)

	-- details come from different places depending
	if (iType=="1") or (iType=="2") or (iType=="3") or (iType=="4") then
		if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
			-- main Last
			local theDetail = "LastOutgoingDetail_"..rTemp.DisplayLastFight
			if iCombatant and iCombatant[theDetail] and iCombatant[theDetail][effect] then
				iEffect = iCombatant[theDetail][effect]
			else
				return
			end
		else
			-- main All, or loaded data set
			if iCombatant and iCombatant.OutgoingDetail and iCombatant.OutgoingDetail[effect] then
				iEffect = iCombatant.OutgoingDetail[effect]
			else
				return
			end
		end
	else
		-- types 5,6,7,8 are subtotal or total, no tooltip
		return
	end

	-- spellID
	if iEffect and iEffect.SpellID then
		if rOpt.ShowTooltips.value then
			_, _, spellID = string_find(iEffect.SpellID, "([0-9]+)") -- does first only, if there are multiple IDs
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			if spellID and (tonumber(spellID) > 0) then
				rTemp.RecapTooltip:SetHyperlink("spell:"..tostring(spellID))
			else
				rTemp.RecapTooltip:SetText("Spell tooltip not available")
			end
			if rOpt.ShowClickHints.value then
				if rTemp.PanelSource == "Load" then
					rTemp.RecapTooltip:AddLine("\n"..rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
				else
					rTemp.RecapTooltip:AddLine(rLocalize.EffectRowTooltip, .565, .565, 1.0, 1)
				end
			end
			rTemp.RecapTooltip:Show()
		end
	else
		if rOpt.ShowTooltips.value then
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			rTemp.RecapTooltip:SetText("Spell tooltip not available")
			if rOpt.ShowClickHints.value then
				if rTemp.PanelSource == "Load" then
					rTemp.RecapTooltip:AddLine("\n"..rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
				else
					rTemp.RecapTooltip:AddLine(rLocalize.EffectRowTooltip, .565, .565, 1.0, 1)
				end
			end
			rTemp.RecapTooltip:Show()
		end
	end
end
local function RecapPanel_ShowIncomingDetailsSpellTooltip(frame, iCombatant, sel)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local effect, iEffect, iType, _, spellID

	if (not sel) or (sel < 0) then
		return
	end

	if sel == 0 then
		return
	end

	if not rTemp.IncomingDetailsList then
		return
	end

	if not rTemp.IncomingDetailsList[sel] then
		return
	end

	effect = rTemp.IncomingDetailsList[sel].Effect

	if not effect then
		return
	end

	iType = string_sub(effect,1,1)

	-- details come from different places
	if (iType=="1") or (iType=="2") or (iType=="3") or (iType=="4") then
		if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
			-- main Last
			local theDetail = "LastIncomingDetail_"..rTemp.DisplayLastFight
			if iCombatant and iCombatant[theDetail] and iCombatant[theDetail][effect] then
				iEffect = iCombatant[theDetail][effect]
			else
				return
			end
		else
			-- main All, or loaded data set
			if iCombatant and iCombatant.IncomingDetail and iCombatant.IncomingDetail[effect] then
				iEffect = iCombatant.IncomingDetail[effect]
			else
				return
			end
		end
	else
		-- types 5,6,7,8 are subtotal or total, no tooltip
		return
	end

	-- spellID
	if iEffect and iEffect.SpellID then
		if rOpt.ShowTooltips.value then
			_, _, spellID = string_find(iEffect.SpellID, "([0-9]+)") -- does first only, if there are multiple IDs
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			if spellID and (tonumber(spellID) > 0) then
				rTemp.RecapTooltip:SetHyperlink("spell:"..tostring(spellID))
			else
				rTemp.RecapTooltip:SetText("Spell tooltip not available")
			end
			if rOpt.ShowClickHints.value then
				if rTemp.PanelSource == "Load" then
					rTemp.RecapTooltip:AddLine("\n"..rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
				else
					rTemp.RecapTooltip:AddLine(rLocalize.EffectRowTooltip, .565, .565, 1.0, 1)
				end
			end
			rTemp.RecapTooltip:Show()
		end
	else
		if rOpt.ShowTooltips.value then
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			rTemp.RecapTooltip:SetText("Spell tooltip not available")
			if rOpt.ShowClickHints.value then
				if rTemp.PanelSource == "Load" then
					rTemp.RecapTooltip:AddLine("\n"..rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
				else
					rTemp.RecapTooltip:AddLine(rLocalize.EffectRowTooltip, .565, .565, 1.0, 1)
				end
			end
			rTemp.RecapTooltip:Show()
		end
	end
end
local function RecapPanel_ShowOtherDetailsSpellTooltip(frame, iCombatant, sel)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local effect, iEffect, iType, _, spellID

	if (not sel) or (sel < 0) then
		return
	end

	if sel == 0 then
		return
	end

	if not rTemp.OtherDetailsList then
		return
	end

	if not rTemp.OtherDetailsList[sel] then
		return
	end

	effect = rTemp.OtherDetailsList[sel].Effect

	if not effect then
		return
	end

	iType = string_sub(effect,1,1)

	if (iType=="0") then
		return
	end

	if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
		-- main Last
		local theDetail = "LastOtherDetail_"..rTemp.DisplayLastFight
		if iCombatant and iCombatant[theDetail] and iCombatant[theDetail][rTemp.OtherDetailsList[sel].FullyQualifiedEffect] then
			iEffect = iCombatant[theDetail][rTemp.OtherDetailsList[sel].FullyQualifiedEffect]
		else
			return
		end
	else
		-- main All, or loaded data set
		if iCombatant and iCombatant.OtherDetail and iCombatant.OtherDetail[rTemp.OtherDetailsList[sel].FullyQualifiedEffect] then
			iEffect = iCombatant.OtherDetail[rTemp.OtherDetailsList[sel].FullyQualifiedEffect]
		else
			return
		end
	end

	-- spellID
	if iEffect.SpellID then
		if rOpt.ShowTooltips.value then
			_, _, spellID = string_find(iEffect.SpellID, "([0-9]+)") -- does first only, if there are multiple IDs
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			if spellID and (tonumber(spellID) > 0) then
				rTemp.RecapTooltip:SetHyperlink("spell:"..tostring(spellID))
			else
				rTemp.RecapTooltip:SetText("Spell tooltip not available")
			end
			if rOpt.ShowClickHints.value then
				rTemp.RecapTooltip:AddLine("\n"..rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
			end
			rTemp.RecapTooltip:Show()
		end
	else
		if rOpt.ShowTooltips.value then
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			rTemp.RecapTooltip:SetText("Spell tooltip not available")
			if rOpt.ShowClickHints.value then
				rTemp.RecapTooltip:AddLine("\n"..rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
			end
			rTemp.RecapTooltip:Show()
		end
	end
end


--[[ global functions ]]

function RecapPanel_Populate(thisCombatant)
	-- rOpt.IncomingPanelDetail.value and rOpt.OutgoingPanelDetail.value contain the do-not-translate titles
	--   We need to convert them when creating header lines

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local iLast = _G.recap_temp.DisplayLastFight
	local iCombatant, fightText

	if rTemp.PanelSource == "Main" then
		iCombatant = rCombatants[thisCombatant]
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		iCombatant = rLoad[thisCombatant]
		fightText = rLocalize.DataSet
	else
		return
	end

	if iCombatant and not rOpt.LightData.value then

		local AllLastOutgoingDetail = "OutgoingDetail"
		local AllLastIncomingDetail = "IncomingDetail"
		local AllLastOtherDetail = "OtherDetail"
		local AllLastTargetDetail = "TargetDetail"
		local AllLastSourceDetail = "SourceDetail"
		if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
			-- from the display set of Last Fight details
			AllLastOutgoingDetail = "LastOutgoingDetail_"..iLast
			AllLastIncomingDetail = "LastIncomingDetail_"..iLast
			AllLastOtherDetail = "LastOtherDetail_"..iLast
			AllLastTargetDetail = "LastTargetDetail_"..iLast
			AllLastSourceDetail = "LastSourceDetail_"..iLast
		end

		--[[ Populate Panel 1: Incoming details ]]

		rTemp.IncomingDetailSelected = 0
		RecapPanel_AmalgamateIncomingTotals(iCombatant, AllLastIncomingDetail)
		RecapPanel_ConstructIncomingDetails(iCombatant, iLast, AllLastIncomingDetail)
		if rTemp.IncomingDetailsListSize>1 then
			RecapPanel_PopulateIncomingDetails(iCombatant, 1)
		else
			RecapPanel_PopulateIncomingDetails(nil, 0)
		end
		RecapPanelIncomingTotalLabel:SetText(rLocalize.DetailTitle[rOpt.IncomingPanelDetail.value])
		RecapPanelIncomingDetailsScrollBar_Update()

		--[[ Populate Panel 2: Source details ]]

		rTemp.SourceDetailSelected = 0
		RecapPanel_ConstructSourceDetails(thisCombatant, iCombatant, AllLastSourceDetail)
		RecapPanelSourceTotalLabel:SetText(rLocalize.Total)
		RecapPanelSourceDetailsScrollBar_Update()

		--[[ Populate Panel 3: Outgoing details ]]

		rTemp.OutgoingDetailSelected = 0
		RecapPanel_AmalgamateOutgoingTotals(iCombatant, AllLastOutgoingDetail)
		RecapPanel_ConstructOutgoingDetails(iCombatant, iLast, AllLastOutgoingDetail)
		if rTemp.OutgoingDetailsListSize>1 then
			RecapPanel_PopulateOutgoingDetails(iCombatant, 1)
		else
			RecapPanel_PopulateOutgoingDetails(nil, 0)
		end
		RecapPanelOutgoingTotalLabel:SetText(rLocalize.DetailTitle[rOpt.OutgoingPanelDetail.value])
		RecapPanelOutgoingDetailsScrollBar_Update()

		--[[ Populate Panel 4: Target details ]]

		rTemp.TargetDetailSelected = 0
		RecapPanel_ConstructTargetDetails(thisCombatant, iCombatant, AllLastTargetDetail)
		RecapPanelTargetTotalLabel:SetText(rLocalize.Total)
		RecapPanelTargetDetailsScrollBar_Update()

		--[[ Populate Panel 5: Other details (buffs, debuffs, procs, and so on) ]]

		rTemp.OtherDetailSelected = 0
		RecapPanel_ConstructOtherDetails(iCombatant, AllLastOtherDetail)
		if rTemp.OtherDetailsListSize>1 then
			RecapPanel_PopulateOtherDetails(iCombatant, 1)
		else
			RecapPanel_PopulateOtherDetails(nil, 0)
		end
		RecapPanelOtherDetailsScrollBar_Update()

	end

	-- populate elements that work in and out of light data mode
	-- do none of these, at the moment, for the hidden combatants "Group Total" and "Non-Group Total"

	if iCombatant then

		--[[ Populate common elements ]]

		if (thisCombatant == rTemp.GroupTotal) then
			-- special title bar contents
			RecapPanelFaction:SetTexture("")
			RecapPanelLevel:SetText(" ")
			RecapPanelClass:SetTexCoord(.9,1,.9,1)
			RecapPanelTitle:SetTextColor(unpack(rColor.DmgOut))
			RecapPanelTitle:SetText(rLocalize.Group.." "..rLocalize.Combatants)
			RecapPanelName:SetText(rLocalize.Group.." "..rLocalize.Combatants)
			RecapPanelFullyQualifiedName:SetText(rLocalize.Group.." "..rLocalize.Combatants)
			RecapPanelGroup:SetText(rLocalize.Group)
		elseif (thisCombatant == rTemp.NonGroupTotal) then
			-- special title bar contents
			RecapPanelFaction:SetTexture("")
			RecapPanelLevel:SetText(" ")
			RecapPanelClass:SetTexCoord(.9,1,.9,1)
			RecapPanelTitle:SetTextColor(unpack(rColor.White))
			RecapPanelTitle:SetText(rLocalize.NonGroup.." "..rLocalize.Combatants)
			RecapPanelName:SetText(rLocalize.NonGroup.." "..rLocalize.Combatants)
			RecapPanelFullyQualifiedName:SetText(rLocalize.NonGroup.." "..rLocalize.Combatants)
			RecapPanelGroup:SetText(rLocalize.NonGroup)
		else
			-- normal title bar contents
			if iCombatant.Faction and rTemp.FactionIcons[iCombatant.Faction] then
				RecapPanelFaction:SetTexture(rTemp.FactionIcons[iCombatant.Faction])
			else
				RecapPanelFaction:SetTexture("")
			end
			if iCombatant.Level and tonumber(iCombatant.Level)>0 then
				RecapPanelLevel:SetText(iCombatant.Level)
			elseif iCombatant.Level and tonumber(iCombatant.Level)==-1 then
				RecapPanelLevel:SetText("??")
			else
				RecapPanelLevel:SetText(" ")
			end
			if iCombatant.Class and rTemp.ClassIcons[iCombatant.Class] then
				RecapPanelClass:SetTexCoord(rTemp.ClassIcons[iCombatant.Class].left,rTemp.ClassIcons[iCombatant.Class].right,rTemp.ClassIcons[iCombatant.Class].top,rTemp.ClassIcons[iCombatant.Class].bottom)
			else
				RecapPanelClass:SetTexCoord(.9,1,.9,1)
			end
			if iCombatant.Friend then
				RecapPanelTitle:SetTextColor(unpack(rColor.DmgOut))
				RecapPanelGroup:SetText(rLocalize.Group)
			else
				RecapPanelTitle:SetTextColor(1,1,1)
				RecapPanelGroup:SetText(rLocalize.NonGroup)
			end
			RecapPanelTitle:SetText(fightText..": "..Recap_StripGUIDsFromCombatant(thisCombatant))
			RecapPanelName:SetText(Recap_StripGUIDsFromCombatant(thisCombatant))
			RecapPanelFullyQualifiedName:SetText(thisCombatant)
		end

		--[[ Populate Panel 4: Summary ]]

		RecapPanelLastTimeText:SetText(Recap_FormatTime(iCombatant["LastTime_"..iLast] or 0))
		RecapPanelLastTimeInText:SetText(Recap_FormatTime(iCombatant["LastTimeIn_"..iLast] or 0))
		RecapPanelLastTimeHealText:SetText(Recap_FormatTime(iCombatant["LastTimeHeal_"..iLast] or 0))
		RecapPanelLastMaxText:SetText(iCombatant["LastMaxHit_"..iLast] or 0)
		RecapPanelLastDeathsText:SetText(iCombatant["LastDeaths_"..iLast] or 0)
		RecapPanelLastHealsText:SetText((iCombatant["LastRawHeal_"..iLast] or 0) - (iCombatant["LastOverHeal_"..iLast] or 0))
		RecapPanelLastHPSText:SetFormattedText("%.1f", (iCombatant["LastHPS_"..iLast] or 0))
		RecapPanelLastDmgInText:SetText(iCombatant["LastDmgIn_"..iLast] or 0)
		RecapPanelLastDPSInText:SetFormattedText("%.1f", (iCombatant["LastDPSIn_"..iLast] or 0))
		RecapPanelLastDmgOutText:SetText(iCombatant["LastDmgOut_"..iLast] or 0)
		RecapPanelLastDPSText:SetFormattedText("%.1f", (iCombatant["LastDPS_"..iLast] or 0))

		RecapPanelAllTimeText:SetText(Recap_FormatTime(iCombatant.TotalTime or 0))
		RecapPanelAllTimeInText:SetText(Recap_FormatTime(iCombatant.TotalTimeIn or 0))
		RecapPanelAllTimeHealText:SetText(Recap_FormatTime(iCombatant.TotalTimeHeal or 0))
		RecapPanelAllMaxText:SetText(iCombatant.TotalMaxHit or 0)
		RecapPanelAllDeathsText:SetText(iCombatant.TotalDeaths or 0)
		RecapPanelAllHealsText:SetText((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0))
		RecapPanelAllHPSText:SetFormattedText("%.1f", (iCombatant.TotalHPS or 0))
		RecapPanelAllDmgInText:SetText(iCombatant.TotalDmgIn or 0)
		RecapPanelAllDPSInText:SetFormattedText("%.1f", (iCombatant.TotalDPSIn or 0))
		RecapPanelAllDmgOutText:SetText(iCombatant.TotalDmgOut or 0)
		RecapPanelAllDPSText:SetFormattedText("%.1f", (iCombatant.TotalDPS or 0))

		if iCombatant.Friend then
			RecapPanelLastTimeText:SetTextColor(unpack(rColor.DmgOut))
			RecapPanelAllTimeText:SetTextColor(unpack(rColor.DmgOut))
			RecapPanelLastTimeInText:SetTextColor(unpack(rColor.DmgIn))
			RecapPanelAllTimeInText:SetTextColor(unpack(rColor.DmgIn))
			RecapPanelLastTimeHealText:SetTextColor(unpack(rColor.Heal))
			RecapPanelAllTimeHealText:SetTextColor(unpack(rColor.Heal))
			RecapPanelLastHealsText:SetTextColor(unpack(rColor.Heal))
			RecapPanelAllHealsText:SetTextColor(unpack(rColor.Heal))
			RecapPanelLastHPSText:SetTextColor(unpack(rColor.Heal))
			RecapPanelAllHPSText:SetTextColor(unpack(rColor.Heal))
			RecapPanelLastDmgInText:SetTextColor(unpack(rColor.DmgIn))
			RecapPanelAllDmgInText:SetTextColor(unpack(rColor.DmgIn))
			RecapPanelLastDPSInText:SetTextColor(unpack(rColor.DmgIn))
			RecapPanelAllDPSInText:SetTextColor(unpack(rColor.DmgIn))
			RecapPanelLastDmgOutText:SetTextColor(unpack(rColor.DmgOut))
			RecapPanelAllDmgOutText:SetTextColor(unpack(rColor.DmgOut))
			RecapPanelLastDPSText:SetTextColor(unpack(rColor.DmgOut))
			RecapPanelAllDPSText:SetTextColor(unpack(rColor.DmgOut))
		else
			RecapPanelLastTimeText:SetTextColor(1,1,1)
			RecapPanelAllTimeText:SetTextColor(1,1,1)
			RecapPanelLastTimeInText:SetTextColor(1,1,1)
			RecapPanelAllTimeInText:SetTextColor(1,1,1)
			RecapPanelLastTimeHealText:SetTextColor(1,1,1)
			RecapPanelAllTimeHealText:SetTextColor(1,1,1)
			RecapPanelLastHealsText:SetTextColor(1,1,1)
			RecapPanelAllHealsText:SetTextColor(1,1,1)
			RecapPanelLastHPSText:SetTextColor(1,1,1)
			RecapPanelAllHPSText:SetTextColor(1,1,1)
			RecapPanelLastDmgInText:SetTextColor(1,1,1)
			RecapPanelAllDmgInText:SetTextColor(1,1,1)
			RecapPanelLastDPSInText:SetTextColor(1,1,1)
			RecapPanelAllDPSInText:SetTextColor(1,1,1)
			RecapPanelLastDmgOutText:SetTextColor(1,1,1)
			RecapPanelAllDmgOutText:SetTextColor(1,1,1)
			RecapPanelLastDPSText:SetTextColor(1,1,1)
			RecapPanelAllDPSText:SetTextColor(1,1,1)
		end
	end
end

function RecapPanel_Show(name)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	if rOpt.ShowPanel.value then

		if rTemp.Selected ~= 0 then
			if rTemp.Selected == rTemp.GroupIndex then
				name = rTemp.GroupTotal
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				name = rTemp.NonGroupTotal
			else
				name = rTemp.List[rTemp.Selected].Name
			end
		elseif rTemp.LoadSelected ~= 0 then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				name = rTemp.GroupTotal
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				name = rTemp.NonGroupTotal
			else
				name = rTemp.LoadList[rTemp.LoadSelected].Name
			end

			-- if Details have not yet been loaded, load them now
			-- a bit complicated in RecapPanel_Populate to load only specific types of details
			if rTemp.LoadedDetails == false then
				Recap_LoadCombatantsDetails()
			end
		end

		RecapPanel_Populate(name)
		RecapPanel:Show()
	end
end

function RecapPanel_Hide(clear)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if clear then
		rTemp.OutgoingDetailSelected = 0
		rTemp.TargetDetailSelected = 0
		rTemp.IncomingDetailSelected = 0
		rTemp.SourceDetailSelected = 0
		rTemp.OtherDetailSelected = 0
		rTemp.PanelRecentSelected = 0
		if RecapRecent:IsVisible() then
			-- other popup is visible, so simply hide
			RecapPanel:Hide()
		else
			rTemp.Selected = 0
			rTemp.LoadSelected = 0
			rTemp.RecentSelected = 0
			if not rUser.Minimized then
				RecapScrollBar_Update()
			end
			RecapLoadScrollBar_Update()
		end
	end

	if (rTemp.Selected == 0) and (rTemp.LoadSelected == 0) then
		RecapPanel:Hide()
	end
end

function RecapPanel_SwitchPanels(panel)

	local rUser = _G.recap_user
	local i

	for i=1,6 do
		_G["RecapPanelTab"..i]:UnlockHighlight()
		_G["RecapSubPanel"..i]:Hide()
	end
	_G["RecapPanelTab"..rUser.PanelView]:LockHighlight()
	_G["RecapSubPanel"..rUser.PanelView]:Show()
end


function RecapPanel_GetOneDetailEntry(iTable, thisCombatant, thisTab, effectTypeName, id)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local rLast = rTemp.DisplayLastFight
	local iSubTable, theDetail

	-- clear the table in which we return our data
	rTemp.PartialDetailEntryTable = wipe(rTemp.PartialDetailEntryTable)

	-- details come from different places depending on whether we are dealing with a non-total, or with a subtotal or total
	if (rTemp.PanelSource == "Main") and (rUser.View == "Last") then
		-- main Last
		if (thisTab == "Outgoing") then
			theDetail = "LastOutgoingDetail_"..rLast
		elseif (thisTab == "Incoming") then
			theDetail = "LastIncomingDetail_"..rLast
		elseif (thisTab == "Other") then
			theDetail = "LastOtherDetail_"..rLast
		else
			return nil
		end
		if iTable[thisCombatant] and iTable[thisCombatant][theDetail] then
			iSubTable = iTable[thisCombatant][theDetail]
		else
			return nil
		end
	else
		-- main All, or loaded data set
		if (thisTab == "Outgoing") then
			if iTable[thisCombatant] and iTable[thisCombatant].OutgoingDetail then
				iSubTable = iTable[thisCombatant].OutgoingDetail
			else
				return nil
			end
		elseif (thisTab == "Incoming") then
			if iTable[thisCombatant] and iTable[thisCombatant].IncomingDetail then
				iSubTable = iTable[thisCombatant].IncomingDetail
			else
				return nil
			end
		elseif (thisTab == "Other") then
			if iTable[thisCombatant] and iTable[thisCombatant].OtherDetail then
				iSubTable = iTable[thisCombatant].OtherDetail
			else
				return nil
			end
		else
			return nil
		end
	end

	-- fnd the matching entries, and then format based on what they want -- very fiddly
	-- the magic numbers match the PanelEntry99 lines in the localization file

	local i, j, k, m, n, searchType, searchEffectName, found, _, first, second, iType, iEffect, matchType
	local combatantName = Recap_StripGUIDsFromCombatant(thisCombatant)

	-- what are we looking for ?
	searchType = string_sub(effectTypeName,1,1)
	searchEffectName = string_sub(effectTypeName,2)
	-- in the search string replace any parentheses by percent-parenthesis (for e.g. Cat (Mangle))
	found, _, first, second = string_find(searchEffectName, "^(.+)%((.+)%)$")
	if found then
		searchEffectName = first.."%("..second.."%)"
	end

	-- look for all matching effects, and return them -- rather fiddly
	-- the magic numbers match the PanelEntry99 lines in the localization file
	for m in pairs(iSubTable) do
		iType = string_sub(m,1,1)
		if string_find(m, "^.-"..searchEffectName.."$") then
			matchType = false
			if (thisTab == "Outgoing") or (thisTab == "Incoming") then
				if ((searchType == "1") or (searchType == "2")) and ((iType == "1") or (iType == "2")) then
					-- damage by combatant or pet
					matchType = true
				elseif ((searchType == "3") or (searchType == "4")) and ((iType == "3") or (iType == "4")) then
					-- healing by combatant or pet
					matchType = true
				elseif ((searchType == "5") or (searchType == "6")) and ((iType == "5") or (iType == "6")) then
					-- subtotal
					matchType = true
				elseif ((searchType == "7") or (searchType == "8")) and ((iType == "7") or (iType == "8")) then
					-- total
					matchType = true
				end
			elseif (thisTab == "Other") then
				-- tests for Outgoing, Incoming, and Other are identical, but keep them separate in case this changes
				if ((searchType == "1") or (searchType == "2")) and ((iType == "1") or (iType == "2")) then
					-- cast by combatant or pet
					matchType = true
				elseif ((searchType == "3") or (searchType == "4")) and ((iType == "3") or (iType == "4")) then
					-- debuff on combatant or pet
					matchType = true
				elseif ((searchType == "5") or (searchType == "6")) and ((iType == "5") or (iType == "6")) then
					-- buff on combatant or pet
					matchType = true
				elseif ((searchType == "7") or (searchType == "8")) and ((iType == "7") or (iType == "8")) then
					-- other for combatant or pet
					matchType = true
				end
			end
			if matchType then
				-- this entry matches on effect name and type, add it to the table that we return
				i = nil
				j = nil
				k = nil
				iEffect = iSubTable[m]
				if (id == 45) then
					i = (iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0)
				elseif (id == 46) then
					i = (iEffect.Hits or 0)
				elseif (id == 47) then
					i = (iEffect.Crits or 0)
				elseif (id == 48) then
					i = (iEffect.Hits or 0)
					j = (iEffect.HitsDmg or 0)
				elseif (id == 49) then
					i = (iEffect.Crits or 0)
					j = (iEffect.CritsDmg or 0)
				elseif (id == 50) then
					i = (iEffect.HitsMax or 0)
				elseif (id == 51) then
					i = (iEffect.CritsMax or 0)
				elseif (id == 52) then
					i = (iEffect.Ticks or 0)
					j = (iEffect.TicksDmg or 0)
				elseif (id == 53) then
					i = (iEffect.TicksMax or 0)
				elseif (id == 55) or (id == 70) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Missed or 0)
					end
				elseif (id == 56) or (id == 71) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Dodged or 0)
					end
				elseif (id == 57) or (id == 72) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Parried or 0)
					end
				elseif (id == 58) or (id == 73) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Blocked or 0)
					end
				elseif (id == 59) or (id == 74) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Absorbed or 0)
					end
				elseif (id == 60) or (id == 75) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Evaded or 0)
					end
				elseif (id == 61) or (id == 76) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Deflected or 0)
					end
				elseif (id == 62) or (id == 77) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Resisted or 0)
					end
				elseif (id == 63) or (id == 78) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Reflected or 0)
					end
				elseif (id == 64) or (id == 79) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.Glances or 0) + (iEffect.Hits or 0) + (iEffect.Crits or 0) + (iEffect.Crushes or 0)
						j = (iEffect.Immune or 0)
					end
				elseif (id == 65) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.CritsEvents or 0)
						j = (iEffect.Crits or 0)
					else
						i = (iEffect.CritsEvents or 0)
						j = (iEffect.Crits or 0)
					end
				elseif (id == 66) then
					i = (iEffect.Ticks or 0)
				elseif (id == 67) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						j = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0)
						i = j + (iEffect.CritsEvents or 0) -- yes, bizarre as this looks, it is correct -- ratio is j/i
					else
						i = (iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0)
						j = (iEffect.Missed or 0)
					end
				elseif (id == 68) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.CritsEvents or 0)
					else
						i = (iEffect.CritsEvents or 0)
					end
				elseif (id == 90) then
					i = (iEffect.Crushes or 0)
				elseif (id == 91) then
					i = (iEffect.Crushes or 0)
					j = (iEffect.CrushDmg or 0)
				elseif (id == 92) then
					i = (iEffect.CrushMax or 0)
				elseif (id == 93) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.CritsEvents or 0)
						j = (iEffect.Crushes or 0)
					end
				elseif (id == 100) then
					i = (iEffect.ICount or 0)
				elseif (id == 101) then
					i = (iEffect.ICount or 0)
					j = (iEffect.ITotal or 0)
				elseif (id == 106) then
					i = (iEffect.Glances or 0)
				elseif (id == 107) then
					i = (iEffect.Glances or 0)
					j = (iEffect.GlancesDmg or 0)
				elseif (id == 108) then
					i = (iEffect.GlancesMax or 0)
				elseif (id == 109) then
					if (iType=="1") or (iType=="2") or (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(m, rLocalize.Damage, 1, true))) then
						i = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
							(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
							(iEffect.Immune or 0) + (iEffect.Evaded or 0) + (iEffect.CritsEvents or 0)
						j = (iEffect.Glances or 0)
					end
				elseif (id == 110) then
					i = (iEffect.PAbsorbs or 0)
				elseif (id == 111) then
					i = (iEffect.PAbsorbs or 0)
					j = (iEffect.PAbsorbsDmg or 0)
				elseif (id == 112) then
					i = (iEffect.PBlocks or 0)
				elseif (id == 113) then
					i = (iEffect.PBlocks or 0)
					j = (iEffect.PBlocksDmg or 0)
				elseif (id == 114) then
					i = (iEffect.PResists or 0)
				elseif (id == 115) then
					i = (iEffect.PResists or 0)
					j = (iEffect.PResistsDmg or 0)
				elseif (id == 116) then
					i = (iEffect.PResistsRaw or 0)
					j = (iEffect.PResistsDmg or 0)
				elseif (id == 117) then
					i = (iEffect.Ticks or 0)
					j = (iEffect.CritTicks or 0)
				elseif (id == 122) then
					i = (iEffect.GlancesMin or 0)
				elseif (id == 123) then
					i = (iEffect.HitsMin or 0)
				elseif (id == 124) then
					i = (iEffect.CritsMin or 0)
				elseif (id == 125) then
					i = (iEffect.CrushMin or 0)
				elseif (id == 126) then
					i = (iEffect.TicksMin or 0)
				elseif (id == 127) then
					i = (iEffect.PAbsorbsDmg or 0)
				elseif (id == 128) then
					i = (iEffect.PBlocksDmg or 0)
				elseif (id == 129) then
					i = (iEffect.PResistsDmg or 0)
				elseif (id == 133) then
					i = (iEffect.EstResistableDmg or 0)
					j = (iEffect.EstResistedDmg or 0)
				-- following are from Other
				elseif (id == 95) then
					i = (iEffect.Total or 0)
					k = iEffect.Attribute
				elseif (id == 96) then
					i = (iEffect.Hits or 0)
					k = iEffect.Attribute
				elseif (id == 97) then
					i = (iEffect.Hits or 0)
					j = (iEffect.Total or 0)
					k = iEffect.Attribute
				elseif (id == 98) then
					i = (iEffect.Max or 0)
					k = iEffect.Attribute
				elseif (id == 99) then
					i = (iEffect.Dispels or 0)
				elseif (id == 102) then
					i = (iEffect.Missed or 0)
				elseif (id == 103) then
					i = (iEffect.DCount or 0)
				elseif (id == 104) then
					i = (iEffect.DCount or 0)
					j = (iEffect.DTotal or 0)
				elseif (id == 120) then
					i = (iEffect.Steals or 0)
				end

				-- perhaps add an entry to the table
				n = Recap_StripOwnerAndGUIDsFromEffect(string_sub(m, 2))

				if ((id >= 45) and (id <= 47)) or (id == 50) or (id == 51) or (id == 53) or (id == 66) or (id == 68) or (id == 90) or (id == 92) or
				   (id == 99) or (id == 100) or (id == 102) or (id == 103) or (id == 106) or (id == 108) or (id == 110) or (id == 112) or (id == 114) or
				   (id == 120) or ((id >= 122) and (id <= 129)) then
					if i>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = i, v2 = "" }
					end
				elseif (id == 48) or (id == 49) or (id == 52) or (id == 91) or (id == 107) or (id == 111) or (id == 113) or (id == 115) then
					if i>0 and j>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = Recap_Div0(j,i), v2 = "" }
					end
				elseif ((id >= 55) and (id <= 64)) or (id == 67) or ((id >= 70) and (id <= 79)) then
					if i>0 and j>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = Recap_Div1(100*j,i), v2 = "%.1f%%", v3 = j }
					end
				elseif (id == 65) or (id == 93) or (id == 109) or (id == 116) or (id == 117) or (id == 133) then
					if i>0 and j>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = Recap_Div1(100*j,i), v2 = "%.1f%%" }
					end
				elseif (id == 101) or (id == 104) then
					if i>0 and j>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = Recap_Div2(j,1000*i), v2 = "%.2f", v3 = "seconds" }
					end
				elseif (id == 95) or (id == 96) or (id == 98) then
					if i>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = i, v2 = "", v3 = k }
					end
				elseif (id == 97) then
					if i>0 and j>0 then
						rTemp.PartialDetailEntryTable[n] = { v1 = Recap_Div0(j,i), v2 = "", v3 = k }
					end
				end
			end
		end
	end

	-- result is in recap_temp.PartialDetailEntryTable
end

function RecapPanelOutgoingHeader_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local line1,line2 = Recap_GetTooltip(rOpt.OutgoingPanelDetail.value)
	if line1 and line2 then
		if rTemp.PanelSource == "Load" then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostTooltip)
		else
			-- tooltip for Panel "Total" column headers has an extra hint if from main fight panel rather than from Load
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostMenuTooltip)
		end
	end
end

function RecapPanelTargetHeader_OnEnter(frame)

	local line1,line2 = Recap_GetTooltip("TargetTotal")
	if line1 and line2 then
		Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostTooltip)
	end
end

function RecapPanelIncomingHeader_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local line1,line2 = Recap_GetTooltip(rOpt.IncomingPanelDetail.value)
	if line1 and line2 then
		if rTemp.PanelSource == "Load" then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostTooltip)
		else
			-- tooltip for Panel "Total" column headers has an extra hint if from main fight panel rather than from Load
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostMenuTooltip)
		end
	end
end

function RecapPanelSourceHeader_OnEnter(frame)

	local line1,line2 = Recap_GetTooltip("SourceTotal")
	if line1 and line2 then
		Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostTooltip)
	end
end

function RecapPanelOtherHeader_OnEnter(frame, header)

	local line1,line2 = Recap_GetTooltip(header)
	if line1 and line2 then
		Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostTooltip)
	end
end

-- tooltips for individual entries
function RecapPanel_Entry_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()

	if id and id>0 then
		if (id == 134) and rOpt.ShowTooltips.value then
			-- special code for spell ID tooltip
			local spellText, _, spellID, line1, line2
			spellText = ""
			if string_find(frame:GetName(), "Outgoing", 1, true) and rTemp.OutgoingDetailsListSize>1 then
				spellText = RecapPanelOutgoingSpellIDText:GetText()
			elseif string_find(frame:GetName(), "Incoming", 1, true) and rTemp.IncomingDetailsListSize>1 then
				spellText = RecapPanelIncomingSpellIDText:GetText()
			elseif string_find(frame:GetName(), "Other", 1, true) and rTemp.OtherDetailsListSize>1 then
				spellText = RecapPanelOtherSpellIDText:GetText()
			end
			_, _, spellID = string_find(spellText, "([0-9]+)") -- does first only, if there are multiple IDs
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			if spellID and (tonumber(spellID) > 0) then
				rTemp.RecapTooltip:SetHyperlink("spell:"..tostring(spellID))
			else
				rTemp.RecapTooltip:SetText("Spell tooltip not available")
			end
			line1, line2 = Recap_GetTooltip("PanelEntry"..id)
			if line1 and line2 then
				rTemp.RecapTooltip:AddLine(" ", 1, 1, 1, 1) -- blank line
				if _G[frame:GetName().."Text"]:GetText() then
					line1 = line1..": ".._G[frame:GetName().."Text"]:GetText()
				end
				rTemp.RecapTooltip:AddLine(line1, 1, 1, 1, 1)
				rTemp.RecapTooltip:AddLine(line2, .75, .75, .75, 1)
			end
			if rOpt.ShowClickHints.value then
				rTemp.RecapTooltip:AddLine(rLocalize.DetailEntryTooltip, .565, .565, 1.0, 1)
			end
			rTemp.RecapTooltip:Show()
		elseif (id == 54) or (id == 94) or (id>=25 and id<=42) or (id>=80 and id<=83) then
			local line1,line2 = Recap_GetTooltip("PanelEntry"..id, _G[frame:GetName().."Text"]:GetText())
			if line1 and line2 then
				Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.DetailEntryTooltip)
			end
		elseif (id == 105) then
			local line1,line2 = Recap_GetTooltip("PanelEntry"..id, _G[frame:GetName().."Text"]:GetText())
			if line1 and line2 then
				Recap_MultilineTooltip(frame, line1, line2)
			end
		else
			local line1, line2
			if frame:GetName()=="RecapPanelOutgoingMissP" and RecapPanelOutgoingMissPLabel:GetText()==rLocalize.Overheal then
				line1,line2 = Recap_GetTooltip("PanelEntryOverheal", _G[frame:GetName().."Text"]:GetText())
			else
				line1,line2 = Recap_GetTooltip("PanelEntry"..id, _G[frame:GetName().."Text"]:GetText())
			end
			if line1 and line2 then
				if (RecapPanelGroup:GetText() == rLocalize.Group) then
					Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.DetailEntryReportGroupTooltip)
				else
					Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.DetailEntryReportNonGroupTooltip)
				end
			end
		end
	end
end

-- clicks on individual fields (the 'magic numbers' here are messy)
function RecapPanel_Entry_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local id, header, text, combatantName, fightText, doFriends
	local i, j, k

	if rTemp.PanelSource == "Main" then
		-- popup based on main fights panel
		if rTemp.Selected ~= 0 then
			if rTemp.Selected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.List[rTemp.Selected].Name)
			end
		else
			combatantName = "?"
		end
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- popup based on loaded data set panel
		if rTemp.LoadSelected ~= 0 then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.LoadList[rTemp.LoadSelected].Name)
			end
		else
			combatantName = "?"
		end
		fightText = rLocalize.DataSet
	else
		return
	end
	doFriends = (RecapPanelGroup:GetText() == rLocalize.Group)

	id = frame:GetID()
	if id and id>0 then
		header = Recap_GetTooltip("PanelEntry"..id)
		if header then

			-- detect double-click
			local isDoubleClick = false
			local thisClickTime = GetTime()
			if (header == rTemp.PriorDetailEntry) then
				-- another click on the same detail entry
				if (thisClickTime - rTemp.DetailEntryPriorClickTime) < 0.3 then
					-- two clicks on the same detail entry within less than 0.3 seconds, call it a double-click
					isDoubleClick = true
				end
			end
			rTemp.PriorDetailEntry = header
			rTemp.DetailEntryPriorClickTime = thisClickTime

			if IsShiftKeyDown() and (not IsAltKeyDown()) and not isDoubleClick then

				if IsControlKeyDown() then
					-- open Clipboard if necessary so we post there
					RecapClipFrame:Show()
				end

				if _G[frame:GetName().."Text"]:GetText()~=" " and _G[frame:GetName().."Text"]:GetText()~="--" and _G[frame:GetName().."Text"]:GetText()~="?" then
					if (id>=70 and id<=79) then
						-- an Outgoing miss, post all miss entries
						local noData = true
						text = "Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..rLocalize.Misses
						text = text.." "..rLocalize.For.." "..RecapPanelOutgoingEffectText:GetText()..":"
						for j in pairs(rLocalize.MissTypes) do
							k = _G["RecapPanelOutgoingMiss"..j.."Text"]:GetText()
							if (k ~= "--") and (k ~= "0 (0.0%)") then
								text = text.." "..rLocalize.MissTypes[j].." "..k
								noData = false
							end
						end
						if noData then
							text = text.." 0"
						end
					elseif (id>=55 and id<=64) then
						-- an Incoming miss, post all miss entries not just one
						local noData = true
						text = "Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..RECAP_INCOMING.." "..rLocalize.Misses
						text = text.." "..rLocalize.For.." "..RecapPanelIncomingEffectText:GetText()..":"
						for j in pairs(rLocalize.MissTypes) do
							k = _G["RecapPanelIncomingMiss"..j.."Text"]:GetText()
							if (k ~= "--") and (k ~= "0 (0.0%)") then
								text = text.." "..rLocalize.MissTypes[j].." "..k
								noData = false
							end
						end
						if noData then
							text = text.." 0"
						end
					elseif ((id>=25 and id<=42) or (id>=80 and id<=83)) then
						text = "Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..header
						text = text..": ".._G[frame:GetName().."Text"]:GetText()
					else
						if ((frame:GetName()=="RecapPanelOutgoingMissP" and RecapPanelOutgoingMissPLabel:GetText()==rLocalize.Overheal) or
							(frame:GetName()=="RecapPanelIncomingMissP" and RecapPanelIncomingMissPLabel:GetText()==rLocalize.Overheal)) then
							header = rLocalize.Overheal
						end
						text = ""
						-- the magic numbers are for PanelEntry..id
						if ((id>=45 and id<=54) or (id>=65 and id<=68) or (id>=90 and id<=104) or (id>=106 and id<=134)) then
							-- I think the 'Outgoing' and 'Incoming' trigger off the xml names, so don't need localization
							if string_find(frame:GetName(), "Outgoing", 1, true) and rTemp.OutgoingDetailsListSize>1 then
								text = "Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..RECAP_OUTGOING.." "..header
								text = text.." "..rLocalize.For.." "..RecapPanelOutgoingEffectText:GetText()
							elseif string_find(frame:GetName(), "Incoming", 1, true) and rTemp.IncomingDetailsListSize>1 then
								text = "Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..RECAP_INCOMING.." "..header
								text = text.." "..rLocalize.For.." "..RecapPanelIncomingEffectText:GetText()
							elseif string_find(frame:GetName(), "Other", 1, true) and rTemp.OtherDetailsListSize>1 then
								text = "Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..rLocalize.OtherEffects..": "..header
								text = text.." "..rLocalize.For.." "..RecapPanelOtherEffectText:GetText()
								if RecapPanelOtherAttributeText:GetText() ~= "" then
									text = text.." "..RecapPanelOtherAttributeText:GetText()
								end
							end
						elseif (id == 105) then
							-- do nothing when "Other Effect" detail entry is clicked
							return
						end
						if _G[frame:GetName().."Text"]:GetText() then
							text = text..": ".._G[frame:GetName().."Text"]:GetText()
						end
						-- tack on a spell link if available
						if (id == 134) then
							local spellText, _, spellID
							spellText = _G[frame:GetName().."Text"]:GetText()
							if spellText then
								_, _, spellID = string_find(_G[frame:GetName().."Text"]:GetText(), "([0-9]+)") -- does first only, if there are multiple IDs
								if spellID and (tonumber(spellID) > 0) then
									text = text.." • • • "..GetSpellLink(spellID)
								end
							end
						end
					end
					Recap_InsertChat(text)
				end

			elseif (not IsShiftKeyDown()) and isDoubleClick then

				local index, iType, effectTypeName

				if (id == 54) or (id == 94) or (id == 105) or (id == 134) then
					-- these numbers intentionally do not give group summaries, hide the window
					RecapRecent:Hide()
				else
					if string_find(frame:GetName(), "Outgoing", 1, true) and rTemp.OutgoingDetailsListSize>1 then
						index = rTemp.OutgoingDetailLoaded
						iType = string_sub(rTemp.OutgoingDetailsList[index].Effect,1,1)
						if rTemp.OutgoingDetailsList[index].PureEffect then -- new with 4.36
							effectTypeName = iType..rTemp.OutgoingDetailsList[index].PureEffect
						else
							-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
							effectTypeName = rTemp.OutgoingDetailsList[index].Effect
						end
						RecapRecent:Hide()
						RecapRecent_PopulateByDetailEntry("Outgoing", doFriends, effectTypeName, id, nil)
						RecapRecent:Show()

					elseif string_find(frame:GetName(), "Incoming", 1, true) and rTemp.IncomingDetailsListSize>1 then
						index = rTemp.IncomingDetailLoaded
						iType = string_sub(rTemp.IncomingDetailsList[index].Effect,1,1)
						if rTemp.IncomingDetailsList[index].PureEffect then -- new with 4.36
							effectTypeName = iType..rTemp.IncomingDetailsList[index].PureEffect
						else
							-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
							effectTypeName = rTemp.IncomingDetailsList[index].Effect
						end
						RecapRecent:Hide()
						RecapRecent_PopulateByDetailEntry("Incoming", doFriends, effectTypeName, id, nil)
						RecapRecent:Show()

					elseif string_find(frame:GetName(), "Other", 1, true) and rTemp.OtherDetailsListSize>1 then
						index = rTemp.OtherDetailLoaded
						iType = string_sub(rTemp.OtherDetailsList[index].Effect,1,1)
						if rTemp.OtherDetailsList[index].PureEffect then -- new with 4.36
							effectTypeName = iType..rTemp.OtherDetailsList[index].PureEffect
						else
							-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
							effectTypeName = rTemp.OtherDetailsList[index].Effect
						end
						RecapRecent:Hide()
						RecapRecent_PopulateByDetailEntry("Other", doFriends, effectTypeName, id, rTemp.OtherDetailsList[index].Attribute)
						RecapRecent:Show()
					end
				end
			end
		end
	end
end

function RecapPanelTab_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local id = frame:GetID()

	if id and id>0 then
		if rOpt.LightData.value and id<6 then
			Recap_Tooltip(frame, "PanelTabDisabled"..id)
		else
			Recap_Tooltip(frame, "PanelTab"..id)
		end
	end
end

function RecapPanelTab_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local id = frame:GetID()
	if rOpt.LightData.value then
		id = 6
	end
	rUser.PanelView = id
	RecapPanel_SwitchPanels(id)
end

function RecapPanelOutgoingDetailsScrollBar_Update()

	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, iType, index, item, theColor, iList

	if rTemp.Loaded and rTemp.OutgoingDetailsListSize then

		FauxScrollFrame_Update(RecapPanelOutgoingDetailsScrollBar,rTemp.OutgoingDetailsListSize-1,7,14)

		for i=1,7 do
			index = i + FauxScrollFrame_GetOffset(RecapPanelOutgoingDetailsScrollBar)
			if index < rTemp.OutgoingDetailsListSize then
				iList = rTemp.OutgoingDetailsList[index]
				iType = string_sub(iList.Effect,1,1)
				if (iType=="0") then
					theColor = rColor.White
				elseif (iType=="1") or (iType=="2") then
					theColor = rColor.DmgOut
				elseif (iType=="3") or (iType=="4") then
					theColor = rColor.Heal
				elseif (iType=="5") or (iType=="6") then
					theColor = rColor.DmgOutPale
				elseif (iType=="7") or (iType=="8") then
					if string_find(iList.Effect, rLocalize.ElementHealing, 1, true) then
						theColor = rColor.HealPale
					else
						theColor = rColor.DmgOutPale
					end
				end
				_G["RecapPanelOutgoingDetail"..i.."_Name"]:SetText(Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2)))
				_G["RecapPanelOutgoingDetail"..i.."_Name"]:SetTextColor(unpack(theColor))
				_G["RecapPanelOutgoingDetail"..i.."_FullyQualifiedName"]:SetText(string_sub(iList.Effect,2)) -- hidden field
				local selvalue = rOpt.OutgoingPanelDetail.value -- with 4.71 support damage only or healing only
				if (selvalue=="TotalDmg") or (selvalue=="TotalHeal") then
					selvalue = "Total"
				end
				if (selvalue=="TotalPSDmg") or (selvalue=="TotalPSHeal") then
					selvalue = "TotalPS"
				end
				_G["RecapPanelOutgoingDetail"..i.."_Total"]:SetText(iList[selvalue]) -- load the menu-chosen value for this column
				if (selvalue=="Total") or (selvalue=="TotalPS") then
					_G["RecapPanelOutgoingDetail"..i.."_Total"]:SetTextColor(unpack(theColor))
				else
					_G["RecapPanelOutgoingDetail"..i.."_Total"]:SetTextColor(unpack(rColor.White))
				end
				_G["RecapPanelOutgoingDetail"..i.."_TotalP"]:SetText(iList.TotalP.."%")
				_G["RecapPanelOutgoingDetail"..i.."_TotalP"]:SetTextColor(unpack(theColor))
				item = _G["RecapPanelOutgoingDetail"..i]
				item:Show()
				if rTemp.OutgoingDetailSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
				item = _G["RecapPanelOutgoingRecent"..i]
				if (iType=="5") or (iType=="6") or (iType=="7") or (iType=="8") or (rTemp.PanelSource ~= "Main") then
					-- subtotal or total or Load, no recent events
					item:Hide()
				else
					_G["RecapPanelOutgoingRecent"..i.."_Text"]:SetTextColor(unpack(theColor))
					_G["RecapPanelOutgoingRecent"..i.."_SaveColor"]:SetTextColor(unpack(theColor)) -- saves chosen colour
					if rOpt.RecentData.value then
						item:Enable()
					else
						_G["RecapPanelOutgoingRecent"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapPanelOutgoingRecent"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5) -- saves chosen colour
						item:Disable()
					end
					item:Show()
				end
			else
				item = _G["RecapPanelOutgoingDetail"..i]
				item:Hide()
				item:UnlockHighlight()
				item = _G["RecapPanelOutgoingRecent"..i]
				item:Hide()
			end
		end
	end
end

function RecapPanelTargetDetailsScrollBar_Update()

	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, iType, index, item, theColor, iList, iWhom

	if rTemp.Loaded and rTemp.TargetDetailsListSize then

		FauxScrollFrame_Update(RecapPanelTargetDetailsScrollBar,rTemp.TargetDetailsListSize-1,25,14)

		for i=1,25 do
			index = i + FauxScrollFrame_GetOffset(RecapPanelTargetDetailsScrollBar)
			if index < rTemp.TargetDetailsListSize then
				iList = rTemp.TargetDetailsList[index]
				iType = string_sub(iList.Whom,1,1)
				if (iType=="0") then
					theColor = rColor.White
				elseif (iType=="1") or (iType=="2") then
					theColor = rColor.DmgOut
				elseif (iType=="3") or (iType=="4") then
					theColor = rColor.Heal
				end
				iWhom = string_sub(iList.Whom,2)
				_G["RecapPanelTargetDetail"..i.."_Name"]:SetText(iWhom) -- should have GUIDs already stripped
				_G["RecapPanelTargetDetail"..i.."_Name"]:SetTextColor(unpack(theColor))
				_G["RecapPanelTargetDetail"..i.."_Total"]:SetText(iList.Total)
				_G["RecapPanelTargetDetail"..i.."_Total"]:SetTextColor(unpack(theColor))
				if iList.TotalP then
					_G["RecapPanelTargetDetail"..i.."_TotalP"]:SetText(iList.TotalP.."%")
				else
					_G["RecapPanelTargetDetail"..i.."_TotalP"]:SetText("")
				end
				_G["RecapPanelTargetDetail"..i.."_TotalP"]:SetTextColor(unpack(theColor))
				item = _G["RecapPanelTargetDetail"..i]
				item:Show()
				if rTemp.TargetDetailSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapPanelTargetDetail"..i]
				item:Hide()
				item:UnlockHighlight()
			end
		end
	end
end

function RecapPanelIncomingDetailsScrollBar_Update()

	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, iType, index, item, theColor, iList

	if rTemp.Loaded and rTemp.IncomingDetailsListSize then

		FauxScrollFrame_Update(RecapPanelIncomingDetailsScrollBar,rTemp.IncomingDetailsListSize-1,7,14)

		for i=1,7 do
			index = i + FauxScrollFrame_GetOffset(RecapPanelIncomingDetailsScrollBar)
			if index < rTemp.IncomingDetailsListSize then
				iList = rTemp.IncomingDetailsList[index]
				iType = string_sub(iList.Effect,1,1)
				if (iType=="0") then
					theColor = rColor.White
				elseif (iType=="1") or (iType=="2") then
					theColor = rColor.DmgIn
				elseif (iType=="3") or (iType=="4") then
					theColor = rColor.Heal
				elseif (iType=="5") or (iType=="6") then
					theColor = rColor.DmgInPale
				elseif (iType=="7") or (iType=="8") then
					if string_find(iList.Effect, rLocalize.ElementHealing, 1, true) then
						theColor = rColor.HealPale
					else
						theColor = rColor.DmgInPale
					end
				end
				_G["RecapPanelIncomingDetail"..i.."_Name"]:SetText(Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2)))
				_G["RecapPanelIncomingDetail"..i.."_Name"]:SetTextColor(unpack(theColor))
				_G["RecapPanelIncomingDetail"..i.."_FullyQualifiedName"]:SetText(string_sub(rTemp.IncomingDetailsList[index].Effect,2)) -- hidden field
				local selvalue = rOpt.IncomingPanelDetail.value -- with 4.71 support damage only or healing only
				if (selvalue=="TotalDmg") or (selvalue=="TotalHeal") then
					selvalue = "Total"
				end
				if (selvalue=="TotalPSDmg") or (selvalue=="TotalPSHeal") then
					selvalue = "TotalPS"
				end
				_G["RecapPanelIncomingDetail"..i.."_Total"]:SetText(iList[selvalue]) -- load the menu-chosen value for this column
				if (selvalue=="Total") or (selvalue=="TotalPS") then
					_G["RecapPanelIncomingDetail"..i.."_Total"]:SetTextColor(unpack(theColor))
				else
					_G["RecapPanelIncomingDetail"..i.."_Total"]:SetTextColor(unpack(rColor.White))
				end
				_G["RecapPanelIncomingDetail"..i.."_TotalP"]:SetText(iList.TotalP.."%")
				_G["RecapPanelIncomingDetail"..i.."_TotalP"]:SetTextColor(unpack(theColor))
				item = _G["RecapPanelIncomingDetail"..i]
				item:Show()
				if rTemp.IncomingDetailSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
				item = _G["RecapPanelIncomingRecent"..i]
				if (iType=="5") or (iType=="6") or (iType=="7") or (iType=="8") or (rTemp.PanelSource ~= "Main") then
					-- subtotal or total, no recent events
					item:Hide()
				else
					_G["RecapPanelIncomingRecent"..i.."_Text"]:SetTextColor(unpack(theColor))
					_G["RecapPanelIncomingRecent"..i.."_SaveColor"]:SetTextColor(unpack(theColor)) -- saves chosen colour
					if rOpt.RecentData.value then
						item:Enable()
					else
						_G["RecapPanelIncomingRecent"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapPanelIncomingRecent"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5) -- saves chosen colour
						item:Disable()
					end
					item:Show()
				end
			else
				item = _G["RecapPanelIncomingDetail"..i]
				item:Hide()
				item:UnlockHighlight()
				item = _G["RecapPanelIncomingRecent"..i]
				item:Hide()
			end
		end
	end
end

function RecapPanelSourceDetailsScrollBar_Update()

	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, iType, index, item, theColor, iList, iWhom

	if rTemp.Loaded and rTemp.SourceDetailsListSize then

		FauxScrollFrame_Update(RecapPanelSourceDetailsScrollBar,rTemp.SourceDetailsListSize-1,25,14)

		for i=1,25 do
			index = i + FauxScrollFrame_GetOffset(RecapPanelSourceDetailsScrollBar)
			if index < rTemp.SourceDetailsListSize then
				iList = rTemp.SourceDetailsList[index]
				iType = string_sub(iList.Whom,1,1)
				if (iType=="0") then
					theColor = rColor.White
				elseif (iType=="1") or (iType=="2") then
					theColor = rColor.DmgIn
				elseif (iType=="3") or (iType=="4") then
					theColor = rColor.Heal
				end
				iWhom = string_sub(iList.Whom,2)
				_G["RecapPanelSourceDetail"..i.."_Name"]:SetText(iWhom) -- should have GUIDs already stripped
				_G["RecapPanelSourceDetail"..i.."_Name"]:SetTextColor(unpack(theColor))
				_G["RecapPanelSourceDetail"..i.."_Total"]:SetText(iList.Total)
				_G["RecapPanelSourceDetail"..i.."_Total"]:SetTextColor(unpack(theColor))
				if iList.TotalP then
					_G["RecapPanelSourceDetail"..i.."_TotalP"]:SetText(iList.TotalP.."%")
				else
					_G["RecapPanelSourceDetail"..i.."_TotalP"]:SetText("")
				end
				_G["RecapPanelSourceDetail"..i.."_TotalP"]:SetTextColor(unpack(theColor))
				item = _G["RecapPanelSourceDetail"..i]
				item:Show()
				if rTemp.SourceDetailSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapPanelSourceDetail"..i]
				item:Hide()
				item:UnlockHighlight()
			end
		end
	end
end

function RecapPanelOtherDetailsScrollBar_Update()

	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, index, item, theColor, iType, iList

	if rTemp.Loaded and rTemp.OtherDetailsListSize then

		FauxScrollFrame_Update(RecapPanelOtherDetailsScrollBar,rTemp.OtherDetailsListSize-1,7,14)

		for i=1,7 do
			index = i + FauxScrollFrame_GetOffset(RecapPanelOtherDetailsScrollBar)
			if index < rTemp.OtherDetailsListSize then
				iList = rTemp.OtherDetailsList[index]
				iType = string_sub(iList.Effect,1,1)
				-- 1 is outgoing spells, usually non-damaging, being cast
				-- 3 is debuffs or losses (e.g. mana)
				-- 5 is buffs or gains (e.g. mana, extra attacks, happiness)
				-- 7 is debuff or buff, but we don't know which
				if (iType=="0") then
					theColor = rColor.White
				elseif (iType=="1") or (iType=="2") then
					theColor = rColor.DmgOut
				elseif  (iType=="3") or (iType=="4") then
					theColor = rColor.DmgIn
				elseif (iType=="5") or (iType=="6") then
					theColor = rColor.Heal
				elseif (iType=="7") or (iType=="8") then
					theColor = rColor.White
				end
				_G["RecapPanelOtherDetail"..i.."_Name"]:SetText(Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2)))
				_G["RecapPanelOtherDetail"..i.."_Name"]:SetTextColor(unpack(theColor))
				_G["RecapPanelOtherDetail"..i.."_Hits"]:SetText(iList.Hits)
				_G["RecapPanelOtherDetail"..i.."_Hits"]:SetTextColor(unpack(theColor))
				_G["RecapPanelOtherDetail"..i.."_Total"]:SetText(iList.Total)
				_G["RecapPanelOtherDetail"..i.."_Total"]:SetTextColor(unpack(theColor))
				_G["RecapPanelOtherDetail"..i.."_Attribute"]:SetText(iList.Attribute)
				_G["RecapPanelOtherDetail"..i.."_Attribute"]:SetTextColor(unpack(theColor))
				item = _G["RecapPanelOtherDetail"..i]
				item:Show()
				if rTemp.OtherDetailSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapPanelOtherDetail"..i]
				item:Hide()
				item:UnlockHighlight()
			end
		end
	end
end

function RecapPanel_OutgoingDetail_OnEnter(frame)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelOutgoingDetailsScrollBar)

	if (index<rTemp.OutgoingDetailsListSize) and (rTemp.OutgoingDetailSelected==0) then
		-- we moused over a detail, and we haven't got a specific detail locked
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_PopulateOutgoingDetails(rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_PopulateOutgoingDetails(rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateOutgoingDetails(rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_PopulateOutgoingDetails(rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_PopulateOutgoingDetails(rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateOutgoingDetails(rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
	end

	-- special display of WoW spell tooltip if available
	if (index<rTemp.OutgoingDetailsListSize) then
		-- we are on a detail
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_ShowOutgoingDetailsSpellTooltip(frame, rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
	end
end

-- clicks on individual effect lines
function RecapPanel_OutgoingDetail_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelOutgoingDetailsScrollBar)
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		fightText = rLocalize.DataSet
	else
		return
	end

	if index<rTemp.OutgoingDetailsListSize then

		local iType = string_sub(rTemp.OutgoingDetailsList[index].Effect,1,1)

		-- detect double-click
		local isDoubleClick = false
		local thisEffect = _G["RecapPanelOutgoingDetail"..id.."_FullyQualifiedName"]:GetText()
		local thisClickTime = GetTime()
		if thisEffect == rTemp.OutgoingEffectPriorEffect then
			-- another click on the same Effect
			if (thisClickTime - rTemp.OutgoingEffectPriorClickTime) < 0.3 then
				-- two clicks on the same Effect within less than 0.3 seconds, call it a double-click
				isDoubleClick = true
			end
		end
		rTemp.OutgoingEffectPriorEffect = thisEffect
		rTemp.OutgoingEffectPriorClickTime = thisClickTime

		if IsShiftKeyDown() and (not IsAltKeyDown()) and (not isDoubleClick) then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			if (iType=="3") then
				-- healing, ordinary, owner
				Recap_InsertChat(string_format(rLocalize.OutgoingHealDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									RecapPanelName:GetText(),
									_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText(),
									rTemp.OutgoingDetailsList[index].Element,
									rTemp.OutgoingDetailsList[index].Total,
									_G["RecapPanelOutgoingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.OutgoingDetailsList[index].TotalPS))

			elseif (iType=="4") then
				-- healing, ordinary, pet
				Recap_InsertChat(string_format(rLocalize.OutgoingHealDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									Recap_StripGUIDsFromCombatant(Recap_PetFromFromPetEffect(_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText())),
									Recap_EffectFromFromPetEffect(_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText()),
									rTemp.OutgoingDetailsList[index].Element,
									rTemp.OutgoingDetailsList[index].Total,
									_G["RecapPanelOutgoingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.OutgoingDetailsList[index].TotalPS))

			elseif (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(rTemp.OutgoingDetailsList[index].Effect, rLocalize.Damage, 1, true))) then
				-- damage, subtotal or total
				Recap_InsertChat(string_format(rLocalize.OutgoingDamageDetailLinkNoElement,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									RecapPanelName:GetText(),
									_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText(),
									rTemp.OutgoingDetailsList[index].Total,
									_G["RecapPanelOutgoingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.OutgoingDetailsList[index].TotalPS))

			elseif (((iType=="7") or (iType=="8")) and (string_find(rTemp.OutgoingDetailsList[index].Effect, rLocalize.ElementHealing, 1, true))) then
				-- healing, subtotal or total
				Recap_InsertChat(string_format(rLocalize.OutgoingHealDetailLinkNoElement,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									RecapPanelName:GetText(),
									_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText(),
									rTemp.OutgoingDetailsList[index].Total,
									_G["RecapPanelOutgoingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.OutgoingDetailsList[index].TotalPS))

			elseif (iType=="1") then
				-- damage, ordinary, owner
				Recap_InsertChat(string_format(rLocalize.OutgoingDamageDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									RecapPanelName:GetText(),
									_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText(),
									rTemp.OutgoingDetailsList[index].Element,
									rTemp.OutgoingDetailsList[index].Total,
									_G["RecapPanelOutgoingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.OutgoingDetailsList[index].TotalPS))

			elseif (iType=="2") then
				-- damage, ordinary, pet
				Recap_InsertChat(string_format(rLocalize.OutgoingDamageDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									Recap_StripGUIDsFromCombatant(Recap_PetFromFromPetEffect(_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText())),
									Recap_EffectFromFromPetEffect(_G["RecapPanelOutgoingDetail"..id.."_Name"]:GetText()),
									rTemp.OutgoingDetailsList[index].Element,
									rTemp.OutgoingDetailsList[index].Total,
									_G["RecapPanelOutgoingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.OutgoingDetailsList[index].TotalPS))

			else
				-- shouldn't be anything else
			end

		elseif (not IsShiftKeyDown()) and isDoubleClick then
			if ((iType=="1") or (iType=="2") or (iType=="3") or (iType=="4")) and (rTemp.PanelSource == "Main") then
				-- only for non-total lines
				local sourceName, effectName
				sourceName = RecapPanelFullyQualifiedName:GetText()
				if rTemp.OutgoingDetailsList[index].PureEffect then -- new with 4.36
					effectName = rTemp.OutgoingDetailsList[index].PureEffect
				else
					-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
					effectName = string_sub(rTemp.OutgoingDetailsList[index].Effect,2)
				end
				RecapRecent:Hide()
				RecapRecent_PopulateByEffect(true, sourceName, effectName)
				RecapRecent:Show()
			else
				PlaySound("igQuestFailed")
			end

		elseif (rTemp.OutgoingDetailSelected == index) then
			rTemp.OutgoingDetailSelected = 0
			RecapPanel_PopulateOutgoingDetails(nil, 0)
			RecapPanelOutgoingDetailsScrollBar_Update()

		else
			rTemp.OutgoingDetailSelected = index
			if rTemp.PanelSource == "Main" then
				if rTemp.Selected == rTemp.GroupIndex then
					RecapPanel_PopulateOutgoingDetails(rCombatants[rTemp.GroupTotal], index)
				elseif rTemp.Selected == rTemp.NonGroupIndex then
					RecapPanel_PopulateOutgoingDetails(rCombatants[rTemp.NonGroupTotal], index)
				else
					RecapPanel_PopulateOutgoingDetails(rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
				end
			elseif rTemp.PanelSource == "Load" then
				if rTemp.LoadSelected == rTemp.GroupIndex then
					RecapPanel_PopulateOutgoingDetails(rLoad[rTemp.GroupTotal], index)
				elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
					RecapPanel_PopulateOutgoingDetails(rLoad[rTemp.NonGroupTotal], index)
				else
					RecapPanel_PopulateOutgoingDetails(rLoad[RecapPanelFullyQualifiedName:GetText()], index)
				end
			end
			RecapPanelOutgoingDetailsScrollBar_Update()
		end
	end
end

function RecapPanel_TargetDetail_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelTargetDetailsScrollBar)
	local isTotal

	isTotal = false
	if (rTemp.Selected == rTemp.GroupIndex) or (rTemp.Selected == rTemp.NonGroupIndex) or (rTemp.LoadSelected == rTemp.GroupIndex) or (rTemp.LoadSelected == rTemp.NonGroupIndex) then
		isTotal = true
	end

	if rOpt.MatrixData.value and (not isTotal) then
		if (index<rTemp.TargetDetailsListSize) then
			if rOpt.ShowTooltips.value and rOpt.ShowClickHints.value then
				rTemp.RecapTooltip:ClearAllPoints()
				if not rOpt.TooltipFollow.value then
					GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
				else
					rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
				end
				rTemp.RecapTooltip:SetText(rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
				rTemp.RecapTooltip:Show()
			end
		end
	end
end

-- clicks on individual effect lines
function RecapPanel_TargetDetail_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelTargetDetailsScrollBar)
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		fightText = rLocalize.DataSet
	else
		return
	end

	if IsShiftKeyDown() and (not IsAltKeyDown()) and index<rTemp.TargetDetailsListSize then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		local iType = string_sub(rTemp.TargetDetailsList[index].Whom,1,1)
		local found, _, iSource, iTarget
		found,_,iSource,iTarget = string_find(_G["RecapPanelTargetDetail"..id.."_Name"]:GetText(), "^(.+) ==> (.+)$")
		if (iType=="0") then
			-- do nothing
		elseif (iType=="3") or (iType=="4") then
			-- healing
			Recap_InsertChat(string_format(rLocalize.TargetHealDetailLink,
								"("..Recap_PetsMergedText()..") ("..fightText..")",
								iSource,
								iTarget,
								rTemp.TargetDetailsList[index].Total,
								_G["RecapPanelTargetDetail"..id.."_TotalP"]:GetText(),
								RecapPanelName:GetText() ))
		else
			-- damage
			Recap_InsertChat(string_format(rLocalize.TargetDamageDetailLink,
								"("..Recap_PetsMergedText()..") ("..fightText..")",
								iSource,
								iTarget,
								rTemp.TargetDetailsList[index].Total,
								_G["RecapPanelTargetDetail"..id.."_TotalP"]:GetText(),
								RecapPanelName:GetText() ))
		end

	elseif rTemp.TargetDetailSelected==index then
		rTemp.TargetDetailSelected = 0
		RecapPanelTargetDetailsScrollBar_Update()

	else
		rTemp.TargetDetailSelected = index
		RecapPanelTargetDetailsScrollBar_Update()
	end
end

function RecapPanel_IncomingDetail_OnEnter(frame)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelIncomingDetailsScrollBar)

	if (index<rTemp.IncomingDetailsListSize) and (rTemp.IncomingDetailSelected==0) then
		-- we moused over a detail, and we haven't got a specific detail locked
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_PopulateIncomingDetails(rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_PopulateIncomingDetails(rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateIncomingDetails(rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_PopulateIncomingDetails(rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_PopulateIncomingDetails(rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateIncomingDetails(rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
	end

	-- special display of WoW spell tooltip if available
	if (index<rTemp.IncomingDetailsListSize) then
		-- we are on a detail
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_ShowIncomingDetailsSpellTooltip(frame, rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_ShowIncomingDetailsSpellTooltip(frame, rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_ShowIncomingDetailsSpellTooltip(frame, rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_ShowIncomingDetailsSpellTooltip(frame, rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_ShowIncomingDetailsSpellTooltip(frame, rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_ShowIncomingDetailsSpellTooltip(frame, rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
	end
end

-- clicks on individual effect lines
function RecapPanel_IncomingDetail_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelIncomingDetailsScrollBar)
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		fightText = rLocalize.DataSet
	else
		return
	end

	if index<rTemp.IncomingDetailsListSize then
		local iType = string_sub(rTemp.IncomingDetailsList[index].Effect,1,1)

		-- detect double-click
		local isDoubleClick = false
		local thisEffect = _G["RecapPanelIncomingDetail"..id.."_FullyQualifiedName"]:GetText()
		local thisClickTime = GetTime()
		if thisEffect == rTemp.IncomingEffectPriorEffect then
			-- another click on the same Effect
			if (thisClickTime - rTemp.IncomingEffectPriorClickTime) < 0.3 then
				-- two clicks on the same Effect within less than 0.3 seconds, call it a double-click
				isDoubleClick = true
			end
		end
		rTemp.IncomingEffectPriorEffect = thisEffect
		rTemp.IncomingEffectPriorClickTime = thisClickTime

		if IsShiftKeyDown() and (not IsAltKeyDown()) and (not isDoubleClick) then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			if (iType=="3") then
				-- healing, ordinary, owner
				Recap_InsertChat(string_format(rLocalize.IncomingHealDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText(),
									rTemp.IncomingDetailsList[index].Element,
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].Total,
									_G["RecapPanelIncomingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].TotalPS))

			elseif (iType=="4") then
				-- healing, ordinary, pet
				Recap_InsertChat(string_format(rLocalize.IncomingHealDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									Recap_EffectFromFromPetEffect(_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText()),
									rTemp.IncomingDetailsList[index].Element,
									Recap_StripGUIDsFromCombatant(Recap_PetFromFromPetEffect(_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText())),
									rTemp.IncomingDetailsList[index].Total,
									_G["RecapPanelIncomingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].TotalPS))

			elseif (iType=="5") or (iType=="6") or (((iType=="7") or (iType=="8")) and (string_find(rTemp.IncomingDetailsList[index].Effect, rLocalize.Damage, 1, true))) then
				-- damage, subtotal or total
				Recap_InsertChat(string_format(rLocalize.IncomingDamageDetailLinkNoElement,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].Total,
									_G["RecapPanelIncomingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].TotalPS))

			elseif (((iType=="7") or (iType=="8")) and (string_find(rTemp.IncomingDetailsList[index].Effect, rLocalize.ElementHealing, 1, true))) then
				-- healing, subtotal or total
				Recap_InsertChat(string_format(rLocalize.IncomingHealDetailLinkNoElement,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].Total,
									_G["RecapPanelIncomingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].TotalPS))

			elseif (iType=="1") then
				-- damage, ordinary, owner
				Recap_InsertChat(string_format(rLocalize.IncomingDamageDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText(),
									rTemp.IncomingDetailsList[index].Element,
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].Total,
									_G["RecapPanelIncomingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].TotalPS))

			elseif (iType=="2") then
				-- damage, ordinary, pet
				Recap_InsertChat(string_format(rLocalize.IncomingDamageDetailLink,
									"("..Recap_PetsMergedText()..") ("..fightText..")",
									Recap_EffectFromFromPetEffect(_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText()),
									rTemp.IncomingDetailsList[index].Element,
									Recap_StripGUIDsFromCombatant(Recap_PetFromFromPetEffect(_G["RecapPanelIncomingDetail"..id.."_Name"]:GetText())),
									rTemp.IncomingDetailsList[index].Total,
									_G["RecapPanelIncomingDetail"..id.."_TotalP"]:GetText(),
									RecapPanelName:GetText(),
									rTemp.IncomingDetailsList[index].TotalPS))

			else
				-- shouldn't be anything else
			end

		elseif (not IsShiftKeyDown()) and isDoubleClick then
			if ((iType=="1") or (iType=="2") or (iType=="3") or (iType=="4")) and (rTemp.PanelSource == "Main") then
				-- only for non-total lines
				local sourceName, effectName
				sourceName = RecapPanelFullyQualifiedName:GetText()
				if rTemp.IncomingDetailsList[index].PureEffect then -- new with 4.36
					effectName = rTemp.IncomingDetailsList[index].PureEffect
				else
					-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
					effectName = string_sub(rTemp.IncomingDetailsList[index].Effect,2)
				end
				RecapRecent:Hide()
				RecapRecent_PopulateByEffect(false, sourceName, effectName)
				RecapRecent:Show()
			else
				PlaySound("igQuestFailed")
			end

		elseif (rTemp.IncomingDetailSelected == index) then
			rTemp.IncomingDetailSelected = 0
			RecapPanel_PopulateIncomingDetails(nil, 0)
			RecapPanelIncomingDetailsScrollBar_Update()

		else
			rTemp.IncomingDetailSelected = index
			if rTemp.PanelSource == "Main" then
				if rTemp.Selected == rTemp.GroupIndex then
					RecapPanel_PopulateIncomingDetails(rCombatants[rTemp.GroupTotal], index)
				elseif rTemp.Selected == rTemp.NonGroupIndex then
					RecapPanel_PopulateIncomingDetails(rCombatants[rTemp.NonGroupTotal], index)
				else
					RecapPanel_PopulateIncomingDetails(rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
				end
			elseif rTemp.PanelSource == "Load" then
				if rTemp.LoadSelected == rTemp.GroupIndex then
					RecapPanel_PopulateIncomingDetails(rLoad[rTemp.GroupTotal], index)
				elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
					RecapPanel_PopulateIncomingDetails(rLoad[rTemp.NonGroupTotal], index)
				else
					RecapPanel_PopulateIncomingDetails(rLoad[RecapPanelFullyQualifiedName:GetText()], index)
				end
			end
			RecapPanelIncomingDetailsScrollBar_Update()
		end
	end
end

function RecapPanel_SourceDetail_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelSourceDetailsScrollBar)
	local isTotal

	isTotal = false
	if (rTemp.Selected == rTemp.GroupIndex) or (rTemp.Selected == rTemp.NonGroupIndex) or (rTemp.LoadSelected == rTemp.GroupIndex) or (rTemp.LoadSelected == rTemp.NonGroupIndex) then
		isTotal = true
	end

	if rOpt.MatrixData.value and (not isTotal) then
		if (index<rTemp.SourceDetailsListSize) then
			if rOpt.ShowTooltips.value and rOpt.ShowClickHints.value then
				rTemp.RecapTooltip:ClearAllPoints()
				if not rOpt.TooltipFollow.value then
					GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
				else
					rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
				end
				rTemp.RecapTooltip:SetText(rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
				rTemp.RecapTooltip:Show()
			end
		end
	end
end

-- clicks on individual effect lines
function RecapPanel_SourceDetail_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelSourceDetailsScrollBar)
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		fightText = rLocalize.DataSet
	else
		return
	end

	if IsShiftKeyDown() and (not IsAltKeyDown()) and index<rTemp.SourceDetailsListSize then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		local iType = string_sub(rTemp.SourceDetailsList[index].Whom,1,1)
		local found, _, iSource, iTarget
		found,_,iSource,iTarget = string_find(_G["RecapPanelSourceDetail"..id.."_Name"]:GetText(), "^(.+) ==> (.+)$")
		if (iType=="0") then
			-- do nothing
		elseif (iType=="3") or (iType=="4") then
			-- healing
			Recap_InsertChat(string_format(rLocalize.SourceHealDetailLink,
								"("..Recap_PetsMergedText()..") ("..fightText..")",
								iSource,
								iTarget,
								rTemp.SourceDetailsList[index].Total,
								_G["RecapPanelSourceDetail"..id.."_TotalP"]:GetText(),
								RecapPanelName:GetText() ))
		else
			-- damage
			Recap_InsertChat(string_format(rLocalize.SourceDamageDetailLink,
								"("..Recap_PetsMergedText()..") ("..fightText..")",
								iSource,
								iTarget,
								rTemp.SourceDetailsList[index].Total,
								_G["RecapPanelSourceDetail"..id.."_TotalP"]:GetText(),
								RecapPanelName:GetText() ))
		end

	elseif rTemp.SourceDetailSelected==index then
		rTemp.SourceDetailSelected = 0
		RecapPanelSourceDetailsScrollBar_Update()

	else
		rTemp.SourceDetailSelected = index
		RecapPanelSourceDetailsScrollBar_Update()
	end
end

function RecapPanel_OtherDetail_OnEnter(frame)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelOtherDetailsScrollBar)

	if (index<rTemp.OtherDetailsListSize) and (rTemp.OtherDetailSelected==0) then
		-- we are on a detail, and we haven't got a specific detail locked
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_PopulateOtherDetails(rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_PopulateOtherDetails(rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateOtherDetails(rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_PopulateOtherDetails(rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_PopulateOtherDetails(rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateOtherDetails(rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
	end

	-- special display of WoW spell tooltip if available
	if (index<rTemp.OtherDetailsListSize) then
		-- we are on a detail
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_ShowOtherDetailsSpellTooltip(frame, rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_ShowOtherDetailsSpellTooltip(frame, rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_ShowOtherDetailsSpellTooltip(frame, rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_ShowOtherDetailsSpellTooltip(frame, rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_ShowOtherDetailsSpellTooltip(frame, rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_ShowOtherDetailsSpellTooltip(frame, rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
	end
end

-- clicks on individual effect lines
function RecapPanel_OtherDetail_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapPanelOtherDetailsScrollBar)
	local linkformat = rLocalize.OtherDetailLink
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		fightText = rLocalize.DataSet
	else
		return
	end

	if IsShiftKeyDown() and (not IsAltKeyDown()) and (index<rTemp.OtherDetailsListSize) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		local iList, iType, typeText, effectText
		iList = rTemp.OtherDetailsList[index]
		iType = string_sub(iList.Effect,1,1)
		if (iType=="0") then
			-- do nothing
		else
			typeText = rLocalize.OtherDetailType[tonumber(iType)]
			effectText = _G["RecapPanelOtherDetail"..id.."_Name"]:GetText()
			if iList.Attribute ~= "--" then
				effectText = effectText.." "..iList.Attribute
			end
			-- Note: considerable variability in the message output
			local variableBit = ""
			if iList.Total and (iList.Total ~= "--") then
				variableBit = "("..string_lower(rLocalize.Total).." "..iList.Total
				if iList.Attribute ~= "--" then
					variableBit = variableBit.." "..iList.Attribute
				end
			end
			if iList.Interval and (iList.Interval ~= "--") then
				if (variableBit == "") then
					variableBit = "("
				else
					variableBit = variableBit..", "
				end
				variableBit = variableBit..RECAP_ESTIMATED_INTERVAL.." "..iList.Interval.." s"
			end
			if iList.Duration and (iList.Duration ~= "--") then
				if (variableBit == "") then
					variableBit = "("
				else
					variableBit = variableBit..", "
				end
				variableBit = variableBit..RECAP_ESTIMATED_DURATION.." "..iList.Duration.." s"
			end
			if (variableBit ~= "") then
				variableBit = variableBit..")"
			end
			Recap_InsertChat(string_format(linkformat,
											"("..Recap_PetsMergedText()..") ("..fightText..")",
											RecapPanelName:GetText(),
											typeText,
											effectText,
											iList.Hits,
											variableBit ))

			-- currently Other details are not included in Recent Data

		end

	elseif rTemp.OtherDetailSelected==index then
		rTemp.OtherDetailSelected = 0
		RecapPanelOtherDetailsScrollBar_Update()
		RecapPanel_PopulateOtherDetails(nil, 0)

	else
		rTemp.OtherDetailSelected = index
		if rTemp.PanelSource == "Main" then
			if rTemp.Selected == rTemp.GroupIndex then
				RecapPanel_PopulateOtherDetails(rCombatants[rTemp.GroupTotal], index)
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				RecapPanel_PopulateOtherDetails(rCombatants[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateOtherDetails(rCombatants[RecapPanelFullyQualifiedName:GetText()], index)
			end
		elseif rTemp.PanelSource == "Load" then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				RecapPanel_PopulateOtherDetails(rLoad[rTemp.GroupTotal], index)
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				RecapPanel_PopulateOtherDetails(rLoad[rTemp.NonGroupTotal], index)
			else
				RecapPanel_PopulateOtherDetails(rLoad[RecapPanelFullyQualifiedName:GetText()], index)
			end
		end
		RecapPanelOtherDetailsScrollBar_Update()
	end
end

function RecapPanel_Recent_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id, index
	local sourceName, effectName

	id = frame:GetID()

	if rOpt.RecentData.value and (rTemp.PanelSource == "Main") then
		if rUser.PanelView==1 then
			-- incoming
			index = id + FauxScrollFrame_GetOffset(RecapPanelIncomingDetailsScrollBar)
			if index<rTemp.IncomingDetailsListSize then
				RecapRecent:Hide()
				if rTemp.PanelRecentSelected==index then
					rTemp.PanelRecentSelected = 0
				else
					rTemp.PanelRecentSelected = index
					sourceName = RecapPanelFullyQualifiedName:GetText()
					if rTemp.IncomingDetailsList[index].PureEffect then -- new with 4.36
						effectName = rTemp.IncomingDetailsList[index].PureEffect
					else
						-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
						effectName = string_sub(rTemp.IncomingDetailsList[index].Effect,2)
					end
					RecapRecent_PopulateByEffect(false, sourceName, effectName)
					RecapRecent:Show()
				end
			end
		else
			index = id + FauxScrollFrame_GetOffset(RecapPanelOutgoingDetailsScrollBar)
			if index<rTemp.OutgoingDetailsListSize then
				RecapRecent:Hide()
				if rTemp.PanelRecentSelected==index then
					rTemp.PanelRecentSelected = 0
				else
					rTemp.PanelRecentSelected = index
					sourceName = RecapPanelFullyQualifiedName:GetText()
					if rTemp.OutgoingDetailsList[index].PureEffect then -- new with 4.36
						effectName = rTemp.OutgoingDetailsList[index].PureEffect
					else
						-- does not work in all total versus individual situations (pet contributions appear in the totals but not accumulated with the individuals)
						effectName = string_sub(rTemp.OutgoingDetailsList[index].Effect,2)
					end
					RecapRecent_PopulateByEffect(true, sourceName, effectName)
					RecapRecent:Show()
				end
			end
		end
	else
		PlaySound("igQuestFailed")
	end
end

function RecapPanel_OnMouseDown(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapPanel:StartMoving()
	end
end

function RecapPanel_OnMouseUp(frame, button)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapPanel:StopMovingOrSizing()

		-- check for docking
		rUser.PanelAnchor.value = false

		if Recap_Near(RecapFrame:GetRight(),RecapPanel:GetLeft()) then
			if Recap_Near(RecapFrame:GetTop(),RecapPanel:GetTop()) then
				rUser.PanelAnchor = { value=true, Main="TOPRIGHT", Panel="TOPLEFT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapPanel:GetBottom()) then
				rUser.PanelAnchor = { value=true, Main="BOTTOMRIGHT", Panel="BOTTOMLEFT"}
			end
		elseif Recap_Near(RecapFrame:GetLeft(),RecapPanel:GetRight()) then
			if Recap_Near(RecapFrame:GetTop(),RecapPanel:GetTop()) then
				rUser.PanelAnchor = { value=true, Main="TOPLEFT", Panel="TOPRIGHT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapPanel:GetBottom()) then
				rUser.PanelAnchor = { value=true, Main="BOTTOMLEFT", Panel="BOTTOMRIGHT" }
			end
		elseif Recap_Near(RecapFrame:GetRight(),RecapPanel:GetRight()) then
			if Recap_Near(RecapFrame:GetTop(),RecapPanel:GetBottom()) then
				rUser.PanelAnchor = { value=true, Main="TOPRIGHT", Panel="BOTTOMRIGHT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapPanel:GetTop()) then
				rUser.PanelAnchor = { value=true, Main="BOTTOMRIGHT", Panel="TOPRIGHT" }
			end
		elseif Recap_Near(RecapFrame:GetLeft(),RecapPanel:GetLeft()) then
			if Recap_Near(RecapFrame:GetTop(),RecapPanel:GetBottom()) then
				rUser.PanelAnchor = { value=true, Main="TOPLEFT", Panel="BOTTOMLEFT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapPanel:GetTop()) then
				rUser.PanelAnchor = { value=true, Main="BOTTOMLEFT", Panel="TOPLEFT" }
			end
		end

		if rUser.PanelAnchor.value then
			RecapPanel:ClearAllPoints()
			RecapPanel:SetPoint(rUser.PanelAnchor.Panel,"RecapFrame",rUser.PanelAnchor.Main,Recap_PanelOffset("x"),Recap_PanelOffset("y"))
		end

	end
end

function Recap_PanelOffset(axis)

	local rUser = _G.recap_user
	local anchor

	anchor = rUser.PanelAnchor.Main..rUser.PanelAnchor.Panel
	if dockoffset[anchor] and axis then
		return dockoffset[anchor][axis]
	else
		return 0
	end
end

-- returns true if the two values are close to each other
function Recap_Near(point1, point2)

	local isnear = false

	if (math_max(point1,point2)-math_min(point1,point2)) < 15 then
	isnear = true
	end

	return isnear
end

function RecapOutgoingDetailHeader_OnMouseUp(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.PanelSource == "Main" then
		-- no menu if from Load
		if (button == "RightButton") and not IsShiftKeyDown() then
			Recap_CreateMenu(frame, rLocalize.DetailMenu, nil, true)
		end
	end
end

function RecapIncomingDetailHeader_OnMouseUp(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.PanelSource == "Main" then
		-- no menu if from Load
		if (button == "RightButton") and not IsShiftKeyDown() then
			Recap_CreateMenu(frame, rLocalize.DetailMenu, nil, false)
		end
	end
end

-- for sending a single line of output, possibly a long one
-- this substitutes ChatFrame1EditBox:Insert.  Sends the 'msg' over the current chatType
-- using as many lines as needed, breaking lines by 'delimiter', a single-character
-- string.  (if no delimiter is given it will use "]").  If a delim1ter isn't found, it
-- will hard-break every 255 characters (changed to 245 to leave room for colour escapes).
function Recap_InsertChat(msg, delimiter, escapeColor)

	local cx, i, m_start, m_end, done, newMsg
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID

	delimiter = string_sub(delimiter or "]",1,1)

	chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
	if chatchan=="Self" then
		print_chat = Recap_Print
	end
	-- assert: we either have a recognized chatchan (with a value for ChatEdit_GetActiveWindow), or are 'Self'

	-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
	if Recap_WIMFindFocus() then
		print_chat = Recap_WIM_Print
	end

	-- If the Clipboard is open, post there instead of to chat or console
	if RecapClipEditBox:IsVisible() then
		print_chat = Recap_LineToClipboard
	end

	local editBox = ChatEdit_GetActiveWindow()
	if editBox then
		-- this will presumably usually return zero
		cx = string_len(editBox:GetText())
	else
		cx = 0
	end

	if cx+string_len(msg)<245 then
		newMsg = msg
		if (chatchan=="Self") and escapeColor then
			-- colour to our console
			newMsg = escapeColor..newMsg
		end
		if print_chat(newMsg, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
	else
		if cx>0 and editBox then
			if print_chat(editBox:GetText(), chatchan, nil, chatnum, presenceID) then
				-- a non-nil return indicates clipboard full
				-- should not happen as of 4.62, but leave the if statement in case
			end
			editBox:SetText("")
		end

		cx = string_len(msg)
		m_start = 1

		while not done do
			m_end = false
			for i=m_start,cx do
				if ((string_sub(msg,i,i)==delimiter and (i-m_start)<245)) or ((i-m_start<245) and i==cx) then
					m_end = i
				end
				if (i-m_start)>244 and not m_end then
					m_end = i
				end
			end
			newMsg = string_sub(msg,m_start,m_end)
			if (chatchan=="Self") and escapeColor then
				-- colour to our console
				newMsg = escapeColor..newMsg
			end
			if print_chat(newMsg, chatchan, nil, chatnum, presenceID) then
				-- a non-nil return indicates clipboard full
				-- should not happen as of 4.62, but leave the if statement in case
			end
			m_start = m_end+1
			if m_start>cx then
				done = true
			end
		end
	end

	if RecapClipEditBox:IsVisible() then
		RecapClipEditBox:HighlightText()
		RecapClipEditBox:SetFocus()
	end
end

-- click on header on detail panel, send that header info for all effects
function RecapOutgoingDetailHeader_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno, combatantName, iList
	local text, alltext = "",""
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		if rTemp.Selected ~= 0 then
			if rTemp.Selected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.List[rTemp.Selected].Name)
			end
		end
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		if rTemp.LoadSelected ~= 0 then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.LoadList[rTemp.LoadSelected].Name)
			end
		end
		fightText = rLocalize.DataSet
	else
		return
	end

	if (not IsShiftKeyDown()) and (rTemp.OutgoingDetailsListSize>1) then
		-- toggle the sorting
		-- slightly misleading, in this context "Hits" actually means "Total"
		if (rTemp.OutgoingDetailSortBy == "Hits") then
			table_sort(rTemp.OutgoingDetailsList,RecapPanel_DetailsEffectSort)
			RecapPanelOutgoingDetailsScrollBar_Update()
			rTemp.OutgoingDetailSortBy = "Name"
		else
			table_sort(rTemp.OutgoingDetailsList,RecapPanel_DetailsTotalSort)
			RecapPanelOutgoingDetailsScrollBar_Update()
			rTemp.OutgoingDetailSortBy = "Hits"
		end

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.OutgoingDetailsListSize>1) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
		if chatchan=="Self" then
			print_chat = Recap_Print
		end

		-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
		if Recap_WIMFindFocus() then
			print_chat = Recap_WIM_Print
		end

		-- If the Clipboard is open, post there instead of to chat or console
		if RecapClipEditBox:IsVisible() then
			print_chat = Recap_LineToClipboard
			maxLines = rTemp.MaxLinesToClipboard
		end

		alltext = "__ Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..Recap_GetTooltip(rOpt.OutgoingPanelDetail.value).." __"
		lineno = 0
		if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
		local transition = 0
		for i=1, math_min(rTemp.OutgoingDetailsListSize-1, maxLines) do
			iList = rTemp.OutgoingDetailsList[i]
			local selvalue = rOpt.OutgoingPanelDetail.value -- with 4.71 support damage only or healing only
			if (selvalue=="TotalDmg") or (selvalue=="TotalHeal") then
				selvalue = "Total"
			end
			if (selvalue=="TotalPSDmg") or (selvalue=="TotalPSHeal") then
				selvalue = "TotalPS"
			end
			if iList[selvalue] and iList[selvalue]~="0.0%" and iList[selvalue]~="--" then
				local iType = string_sub(iList.Effect,1,1)

				if (transition==0) then
					-- remember first category encountered
					if ((iType=="1") or (iType=="2")) then
						transition = 1
					elseif ((iType=="3") or (iType=="4")) then
						transition = 2
					else
						transition = 3
					end
				elseif (transition==1) then
					-- extra line between categories
					if ((iType=="1") or (iType=="2")) then
						-- no change
					elseif ((iType=="3") or (iType=="4")) then
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 2
					else
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 3
					end
				elseif (transition==2) then
					-- extra line between categories
					if ((iType=="1") or (iType=="2")) then
						-- no change
					elseif ((iType=="3") or (iType=="4")) then
						-- no change
					else
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 3
					end
				end
				if selvalue == "Total" then
					text = Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList[selvalue].." ("..iList.TotalP.."%) ("..iList.TotalPS.."/s)"
				elseif selvalue == "TotalPS" then
					text = Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList[selvalue].."/s ("..iList.TotalP.."%)"
				else
					text = Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList[selvalue]
				end
				lineno = lineno + 1
				text = tostring(lineno)..". "..text
				if print_chat(text, chatchan, nil, chatnum, presenceID) then
					-- a non-nil return indicates clipboard full
					-- should not happen as of 4.62, but leave the if statement in case
				end
			end
		end

		if RecapClipEditBox:IsVisible() then
			RecapClipEditBox:HighlightText()
			RecapClipEditBox:SetFocus()
		end
	end
end

-- click on header on detail panel, send that header info for all combatants
function RecapTargetDetailHeader_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno, combatantName, iList
	local text, alltext = "",""
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		if rTemp.Selected ~= 0 then
			if (rTemp.Selected == rTemp.GroupIndex) or (rTemp.Selected == rTemp.NonGroupIndex) then
				return
			end
			combatantName = Recap_StripGUIDsFromCombatant(rTemp.List[rTemp.Selected].Name)
		end
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		if rTemp.LoadSelected ~= 0 then
			if (rTemp.LoadSelected == rTemp.GroupIndex) or (rTemp.LoadSelected == rTemp.NonGroupIndex) then
				return
			end
			combatantName = Recap_StripGUIDsFromCombatant(rTemp.LoadList[rTemp.LoadSelected].Name)
		end
		fightText = rLocalize.DataSet
	else
		return
	end

	if (not IsShiftKeyDown()) and (rTemp.TargetDetailsListSize>1) and (rOpt.MatrixData.value) then
		-- toggle the sorting
		if (rTemp.TargetDetailSortBy == "Hits") then
			table_sort(rTemp.TargetDetailsList,RecapPanel_DetailsToFromWhomSort)
			RecapPanelTargetDetailsScrollBar_Update()
			rTemp.TargetDetailSortBy = "Name"
		else
			table_sort(rTemp.TargetDetailsList,RecapPanel_DetailsToFromSort)
			RecapPanelTargetDetailsScrollBar_Update()
			rTemp.TargetDetailSortBy = "Hits"
		end

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.TargetDetailsListSize>1) and (rOpt.MatrixData.value) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
		if chatchan=="Self" then
			print_chat = Recap_Print
		end

		-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
		if Recap_WIMFindFocus() then
			print_chat = Recap_WIM_Print
		end

		-- If the Clipboard is open, post there instead of to chat or console
		if RecapClipEditBox:IsVisible() then
			print_chat = Recap_LineToClipboard
			maxLines = rTemp.MaxLinesToClipboard
		end

		alltext = "__ Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..Recap_GetTooltip("TargetTotal").." __"
		lineno = 0
		if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
		local transition = 0
		for i=1, math_min(rTemp.TargetDetailsListSize-1, maxLines) do
			iList = rTemp.TargetDetailsList[i]
			if iList.Total and iList.Total~="0.0%" and iList.Total~="--" then
				local iType = string_sub(iList.Whom,1,1)

				if (transition==0) then
					-- remember first category encountered
					if ((iType=="1") or (iType=="2")) then
						transition = 1
					else
						transition = 2
					end
				elseif (transition==1) then
					-- extra line between categories
					if ((iType=="1") or (iType=="2")) then
						-- no change
					else
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 2
					end
				end

				text = string_sub(iList.Whom,2)..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList.Total.." ("..iList.TotalP.."%)"
				lineno = lineno + 1
				text = tostring(lineno)..". "..text
				if print_chat(text, chatchan, nil, chatnum, presenceID) then
					-- a non-nil return indicates clipboard full
					-- should not happen as of 4.62, but leave the if statement in case
				end
			end
		end

		if RecapClipEditBox:IsVisible() then
			RecapClipEditBox:HighlightText()
			RecapClipEditBox:SetFocus()
		end
	end
end

-- click on header on detail panel, send that header info for all effects
function RecapIncomingDetailHeader_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno, combatantName, iList
	local text, alltext = "",""
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		if rTemp.Selected ~= 0 then
			if rTemp.Selected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.List[rTemp.Selected].Name)
			end
		end
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		if rTemp.LoadSelected ~= 0 then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.LoadList[rTemp.LoadSelected].Name)
			end
		end
		fightText = rLocalize.DataSet
	else
		return
	end

	if (not IsShiftKeyDown()) and (rTemp.IncomingDetailsListSize>1) then
		-- toggle the sorting
		-- slightly misleading, in this context "Hits" actually means "Total"
		if (rTemp.IncomingDetailSortBy == "Hits") then
			table_sort(rTemp.IncomingDetailsList,RecapPanel_DetailsEffectSort)
			RecapPanelIncomingDetailsScrollBar_Update()
			rTemp.IncomingDetailSortBy = "Name"
		else
			table_sort(rTemp.IncomingDetailsList,RecapPanel_DetailsTotalSort)
			RecapPanelIncomingDetailsScrollBar_Update()
			rTemp.IncomingDetailSortBy = "Hits"
		end

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.IncomingDetailsListSize>1) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
		if chatchan=="Self" then
			print_chat = Recap_Print
		end

		-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
		if Recap_WIMFindFocus() then
			print_chat = Recap_WIM_Print
		end

		-- If the Clipboard is open, post there instead of to chat or console
		if RecapClipEditBox:IsVisible() then
			print_chat = Recap_LineToClipboard
			maxLines = rTemp.MaxLinesToClipboard
		end

		alltext = "__ Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..RECAP_INCOMING.." "..Recap_GetTooltip(rOpt.IncomingPanelDetail.value).." __"
		lineno = 0
		if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
		local transition = 0
		for i=1, math_min(rTemp.IncomingDetailsListSize-1, maxLines) do
			iList = rTemp.IncomingDetailsList[i]
			local selvalue = rOpt.IncomingPanelDetail.value -- with 4.71 support damage only or healing only
			if (selvalue=="TotalDmg") or (selvalue=="TotalHeal") then
				selvalue = "Total"
			end
			if (selvalue=="TotalPSDmg") or (selvalue=="TotalPSHeal") then
				selvalue = "TotalPS"
			end
			if iList[selvalue] and iList[selvalue]~="0.0%" and iList[selvalue]~="--" then
				local iType = string_sub(iList.Effect,1,1)

				if (transition==0) then
					-- remember first category encountered
					if ((iType=="1") or (iType=="2")) then
						transition = 1
					elseif ((iType=="3") or (iType=="4")) then
						transition = 2
					else
						transition = 3
					end
				elseif (transition==1) then
					-- extra line between categories
					if ((iType=="1") or (iType=="2")) then
						-- no change
					elseif ((iType=="3") or (iType=="4")) then
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 2
					else
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 3
					end
				elseif (transition==2) then
					-- extra line between categories
					if ((iType=="1") or (iType=="2")) then
						-- no change
					elseif ((iType=="3") or (iType=="4")) then
						-- no change
					else
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 3
					end
				end
				if selvalue == "Total" then
					text = Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList[selvalue].." ("..iList.TotalP.."%) ("..iList.TotalPS.."/s)"
				elseif selvalue == "TotalPS" then
					text = Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList[selvalue].."/s) ("..iList.TotalP.."%)"
				else
					text = Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList[selvalue]
				end
				lineno = lineno + 1
				text = tostring(lineno)..". "..text
				if print_chat(text, chatchan, nil, chatnum, presenceID) then
					-- a non-nil return indicates clipboard full
					-- should not happen as of 4.62, but leave the if statement in case
				end
			end
		end

		if RecapClipEditBox:IsVisible() then
			RecapClipEditBox:HighlightText()
			RecapClipEditBox:SetFocus()
		end
	end
end

-- click on header on detail panel, send that header info for all effects
function RecapSourceDetailHeader_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno, combatantName, iList
	local text, alltext = "",""
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		if rTemp.Selected ~= 0 then
			if (rTemp.Selected == rTemp.GroupIndex) or (rTemp.Selected == rTemp.NonGroupIndex) then
				return
			end
			combatantName = Recap_StripGUIDsFromCombatant(rTemp.List[rTemp.Selected].Name)
		end
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		if rTemp.LoadSelected ~= 0 then
			if (rTemp.LoadSelected == rTemp.GroupIndex) or (rTemp.LoadSelected == rTemp.NongIndex) then
				return
			end
			combatantName = Recap_StripGUIDsFromCombatant(rTemp.LoadList[rTemp.LoadSelected].Name)
		end
		fightText = rLocalize.DataSet
	else
		return
	end

	if (not IsShiftKeyDown()) and (rTemp.SourceDetailsListSize>1) and (rOpt.MatrixData.value) then
		-- toggle the sorting
		if (rTemp.SourceDetailSortBy == "Hits") then
			table_sort(rTemp.SourceDetailsList,RecapPanel_DetailsToFromWhomSort)
			RecapPanelSourceDetailsScrollBar_Update()
			rTemp.SourceDetailSortBy = "Name"
		else
			table_sort(rTemp.SourceDetailsList,RecapPanel_DetailsToFromSort)
			RecapPanelSourceDetailsScrollBar_Update()
			rTemp.SourceDetailSortBy = "Hits"
		end

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.SourceDetailsListSize>1) and (rOpt.MatrixData.value) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
		if chatchan=="Self" then
			print_chat = Recap_Print
		end

		-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
		if Recap_WIMFindFocus() then
			print_chat = Recap_WIM_Print
		end

		-- If the Clipboard is open, post there instead of to chat or console
		if RecapClipEditBox:IsVisible() then
			print_chat = Recap_LineToClipboard
			maxLines = rTemp.MaxLinesToClipboard
		end

		alltext = "__ Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..Recap_GetTooltip("SourceTotal").." __"
		lineno = 0
		if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
		local transition = 0
		for i=1, math_min(rTemp.SourceDetailsListSize-1, maxLines) do
			iList = rTemp.SourceDetailsList[i]
			if iList.Total and iList.Total~="0.0%" and iList.Total~="--" then
				local iType = string_sub(iList.Whom,1,1)
				if (transition==0) and ((iType=="1") or (iType=="2")) then
					-- remember if we saw damage
					transition = 1
				end
				if (transition==1) and ((iType=="3") or (iType=="4")) then
					-- extra line between damage and healing
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 2
				end
				text = string_sub(iList.Whom,2)..": "..(((iType=="3") or (iType=="4")) and "+" or "")..iList.Total.." ("..iList.TotalP.."%)"
				lineno = lineno + 1
				text = tostring(lineno)..". "..text
				if print_chat(text, chatchan, nil, chatnum, presenceID) then
					-- a non-nil return indicates clipboard full
					-- should not happen as of 4.62, but leave the if statement in case
				end
			end
		end

		if RecapClipEditBox:IsVisible() then
			RecapClipEditBox:HighlightText()
			RecapClipEditBox:SetFocus()
		end
	end
end

-- click on header on detail panel, send that header info for all effects
function RecapOtherDetailHeader_OnClick(colName)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno, combatantName, iList
	local text, alltext = "",""
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID, iType, typeText
	local maxLines = rOpt.MaxRank.value
	local fightText

	if rTemp.PanelSource == "Main" then
		-- from fights panel
		if rTemp.Selected ~= 0 then
			if rTemp.Selected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.Selected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.List[rTemp.Selected].Name)
			end
		end
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		-- from loaded data set panel
		if rTemp.LoadSelected ~= 0 then
			if rTemp.LoadSelected == rTemp.GroupIndex then
				combatantName = rLocalize.Group.." "..rLocalize.Combatants
			elseif rTemp.LoadSelected == rTemp.NonGroupIndex then
				combatantName = rLocalize.NonGroup.." "..rLocalize.Combatants
			else
				combatantName = Recap_StripGUIDsFromCombatant(rTemp.LoadList[rTemp.LoadSelected].Name)
			end
		end
		fightText = rLocalize.DataSet
	else
		return
	end

	if (not IsShiftKeyDown()) and (rTemp.OtherDetailsListSize>1) and (rOpt.OtherData.value) then
		-- toggle the sorting
		if (rTemp.OtherDetailSortBy == "Hits") then
			table_sort(rTemp.OtherDetailsList,RecapPanel_DetailsEffectSort)
			RecapPanelOtherDetailsScrollBar_Update()
			rTemp.OtherDetailSortBy = "Name"
		else
			table_sort(rTemp.OtherDetailsList,RecapPanel_DetailsHitsSort)
			RecapPanelOtherDetailsScrollBar_Update()
			rTemp.OtherDetailSortBy = "Hits"
		end

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.OtherDetailsListSize>1) and (rOpt.OtherData.value) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
		if chatchan=="Self" then
			print_chat = Recap_Print
		end

		-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
		if Recap_WIMFindFocus() then
			print_chat = Recap_WIM_Print
		end

		-- If the Clipboard is open, post there instead of to chat or console
		if RecapClipEditBox:IsVisible() then
			print_chat = Recap_LineToClipboard
			maxLines = rTemp.MaxLinesToClipboard
		end

		alltext = "__ Recap ("..Recap_PetsMergedText()..") ("..fightText.."): "..combatantName..": "..rLocalize.OtherEffects..": "..(((colName == "Hits") and rLocalize.Hits) or ((colName == "Total") and rLocalize.Total)).." __"
		lineno = 0
		if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
		local transition = 0
		for i=1, math_min(rTemp.OtherDetailsListSize-1, maxLines) do
			iList = rTemp.OtherDetailsList[i]
			iType = string_sub(iList.Effect,1,1)
			typeText = rLocalize.OtherDetailType[tonumber(iType)]

			if (transition==0) then
				-- remember first category encountered
				if ((iType=="1") or (iType=="2")) then
					transition = 1
				elseif ((iType=="3") or (iType=="4")) then
					transition = 2
				elseif ((iType=="5") or (iType=="6")) then
					transition = 3
				else
					transition = 4
				end
			elseif (transition==1) then
				-- extra line between categories
				if ((iType=="1") or (iType=="2")) then
					-- no change
				elseif ((iType=="3") or (iType=="4")) then
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 2
				elseif ((iType=="5") or (iType=="6")) then
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 3
				else
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 4
				end
			elseif (transition==2) then
				-- extra line between categories
				if ((iType=="1") or (iType=="2")) then
					-- no change
				elseif ((iType=="3") or (iType=="4")) then
					-- no change
				elseif ((iType=="5") or (iType=="6")) then
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 3
				else
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 4
				end
			elseif (transition==3) then
				-- extra line between categories
				if ((iType=="1") or (iType=="2")) then
					-- no change
				elseif ((iType=="3") or (iType=="4")) then
					-- no change
				elseif ((iType=="5") or (iType=="6")) then
					-- no change
				else
					if print_chat("+", chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					transition = 4
				end
			end

			if (colName == "Hits") then
				text = typeText..": "..Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..iList.Hits
			elseif (colName == "Total") then
				text = typeText..": "..Recap_StripOwnerAndGUIDsFromEffect(string_sub(iList.Effect,2))..": "..iList.Total
				if iList.Attribute ~= "--" then
					text = text.." "..iList.Attribute
				end
			end
			lineno = lineno + 1
			text = tostring(lineno)..". "..text
			if print_chat(text, chatchan, nil, chatnum, presenceID) then
				-- a non-nil return indicates clipboard full
				-- should not happen as of 4.62, but leave the if statement in case
			end
		end

		if RecapClipEditBox:IsVisible() then
			RecapClipEditBox:HighlightText()
			RecapClipEditBox:SetFocus()
		end
	end
end

RecapPanel_lua_4773 = true
