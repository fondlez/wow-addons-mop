﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ RecapGraph.lua (functions for the popup panel for Graphs) ]]

local bit_band = _G.bit.band
local bit_bor = _G.bit.bor
local math_max = _G.math.max
local math_min = _G.math.min
local math_floor = _G.math.floor
local math_log10 = _G.math.log10
local string_format = _G.string.format
local string_gsub = _G.string.gsub
local table_sort = _G.table.sort
local table_insert = _G.table.insert
local table_remove = _G.table.remove
local pairs = _G.pairs
local tonumber = _G.tonumber
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize
local rGraph = _G.recap_temp.Graph

-- for LibGraphL
local recapLineGraph = nil
local recapLineGraphPanel = nil
function Recap_EnableGraph()
	if recapLineGraphPanel == nil then
		recapLineGraph = LibStub:GetLibrary("LibGraphL-2.1")
		recapLineGraphPanel = recapLineGraph:CreateGraphLine("RecapGraph_GraphGraph",RecapGraphGraph,"TOPLEFT","TOPLEFT",10,-6,360,150)
		recapLineGraphPanel:ResetData()
		recapLineGraphPanel:SetXAxis(0, 36)
		recapLineGraphPanel:SetYAxis(0, 22)
		recapLineGraphPanel:LockYMin(true)
		recapLineGraphPanel:SetYLabels(true,true)
		recapLineGraphPanel:SetGridSpacing(6, 4)
		recapLineGraphPanel:SetAxisDrawing(true,true)
		recapLineGraphPanel:SetAutoScale(false)
		recapLineGraphPanel:SetGridColor({0.5,0.5,0.5,0.5})
		recapLineGraphPanel:SetAxisColor({0.85,0.85,0.85,0.5})
	end
end


--[[ local tables ]]

local dockoffset = { ["TOPRIGHTTOPLEFT"] = { x=-4,y=0 },
					 ["BOTTOMRIGHTBOTTOMLEFT"] = { x=-4,y=0 },
					 ["TOPLEFTTOPRIGHT"] = { x=4,y=0 },
					 ["BOTTOMLEFTBOTTOMRIGHT"] = { x=4,y=0 },
					 ["TOPRIGHTBOTTOMRIGHT"] = { x=0,y=-4 },
					 ["BOTTOMRIGHTTOPRIGHT"] = { x=0,y=4 },
					 ["TOPLEFTBOTTOMLEFT"] = { x=0,y=-4 },
					 ["BOTTOMLEFTTOPLEFT"] = { x=0,y=4 } }

local nColors = 13
local liveColors =
{	{ 1.0, 0, 0 }, -- red
	{ 1.0, 0.5, 0 }, -- orange
	{ 1.0, 1.0, 0 }, -- yellow
	{ 0.5, 1.0, 0 }, -- chartreuse
	{ 0, 1.0, 0 }, -- green
	{ 0, 1.0, 0.5 }, -- spring green
	{ 0, 1.0, 1.0 }, -- cyan
	{ 0, 0.5, 1.0 }, -- azure
	{ 0.1, 0.1, 1.0 }, -- blue (slightly lightened for greater visibility especially against black background)
	{ 0.5, 0, 1.0 }, -- violet
	{ 1.0, 0, 1.0 }, -- magenta
	{ 1.0, 0, 0.5 }, -- rose
	{ 1.0, 1.0, 1.0 } -- white
}

-- colors for the gauges
local gaugeOut = { 0.47,0.87,0.47 }
local gaugeIn = { 1.0,0.55,0.65 }
local gaugeHeal = { 0.4,0.6,0.9 }


--[[ local functions (precede first use) ]]

--[[ Sorting functions ]]

-- : I don't understand why the > and < are reversed from what they are in Recap.lua

local function RecapGraph_SortDown(e1,e2)
	if e1[3] and e2[3] then
		if ( e1[3] > e2[3] ) then
			return true
		else
			return false
		end
	else
		return false
	end
end

local function RecapGraph_SortUp(e1,e2)
	if e1[2] and e2[2] then
		if ( e1[2] < e2[2] ) then
			return true
		else
			return false
		end
	else
		return false
	end
end

local function RecapGraph_GraphClear()

	local rTemp = _G.recap_temp

	if not rTemp.Loaded then
		return
	end

	_G.RecapGraph:Hide()

	-- light the chosen buttons
	if (rGraph.TextToggle == "graph") then
		_G["RecapGraphGraphTab"]:LockHighlight()
		_G["RecapGraphTextTab"]:UnlockHighlight()
	else
		_G["RecapGraphGraphTab"]:UnlockHighlight()
		_G["RecapGraphTextTab"]:LockHighlight()
	end
	_G["RecapGraphShowDPSOutButton"]:Hide()
	_G["RecapGraphShowDPSInButton"]:Hide()
	_G["RecapGraphShowHPSOutButton"]:Hide()
	if rGraph.Statistic == RECAP_DPS_OUT then
		_G["RecapGraphShowDPSOutButton"]:LockHighlight()
		_G["RecapGraphShowDPSInButton"]:UnlockHighlight()
		_G["RecapGraphShowHPSOutButton"]:UnlockHighlight()
	elseif rGraph.Statistic == RECAP_DPS_IN then
		_G["RecapGraphShowDPSOutButton"]:UnlockHighlight()
		_G["RecapGraphShowDPSInButton"]:LockHighlight()
		_G["RecapGraphShowHPSOutButton"]:UnlockHighlight()
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		_G["RecapGraphShowDPSOutButton"]:UnlockHighlight()
		_G["RecapGraphShowDPSInButton"]:UnlockHighlight()
		_G["RecapGraphShowHPSOutButton"]:LockHighlight()
	end
	_G["RecapGraphShowDPSOutButton"]:Show()
	_G["RecapGraphShowDPSInButton"]:Show()
	_G["RecapGraphShowHPSOutButton"]:Show()

	-- display with zero data
	_G.RecapGraphLabel:SetText("...")
	recapLineGraphPanel:ResetData()
	recapLineGraphPanel:SetXAxis(0, 36)
	recapLineGraphPanel:SetYAxis(0, 22)
	recapLineGraphPanel:LockYMin(true)
	recapLineGraphPanel:SetYLabels(true,true)
	recapLineGraphPanel:SetGridSpacing(6, 4)
	recapLineGraphPanel:SetAxisDrawing(true,true)
	recapLineGraphPanel:SetAutoScale(false)
	recapLineGraphPanel:SetGridColor({0.5,0.5,0.5,0.5})
	recapLineGraphPanel:SetAxisColor({0.85,0.85,0.85,0.5})
	RecapGraph_GraphOptionsRefresh()
	_G.RecapGraph:Show()
end

local function RecapGraph_ProcessBins(rMax, unsortedList, optionList)

	local i, j, iCombatant, rawBins, displayBins, startingBin, amount, timeOfWindow, windowLength, thisPerSecond

	windowLength = rGraph.BinSize * rGraph.NBins
	for i, iCombatant in pairs(rGraph[unsortedList]) do
		-- only process this combatant if the player has selected this combatant
		if rGraph[optionList][i] and rGraph[optionList][i].Checked then
			-- combatant is selected
			iCombatant.Total = iCombatant.RawTotal -- copy accumulated total so far to the display spot
			rawBins = iCombatant.Raw -- data from here
			displayBins = iCombatant.Display -- gets processed and stored here

			if #rawBins == 0 then
				-- no data for this combatant at the moment
			else
				-- in the following we go back 4 bins, being cautious (monitoring suggests that 2 bins should normally be sufficient)
				startingBin = math_max((math_min(#rawBins,#displayBins,iCombatant.Highwater) - 4), 1)
				for j = startingBin, #rawBins do

					-- damage
					amount = (rawBins[j] or 0)
					thisPerSecond = Recap_Div0(amount, windowLength)

					-- remember peak value, both for this combatant and overall
					iCombatant.Peak = math_max(tonumber(iCombatant.Peak), thisPerSecond)
					rMax[1] = math_max(rMax[1], thisPerSecond)

					-- the time of this window (centre of first bin is defined as time = 0)
					timeOfWindow = (j - 1) * rGraph.BinSize

					-- load into display table (creates bins as necessary)
					if displayBins[j] then
						displayBins[j][2] = thisPerSecond
					else
						displayBins[j] = { timeOfWindow, thisPerSecond }
					end
				end
				rMax[2] = math_max(rMax[2], #rawBins)
			end
		end
	end
end

local function RecapGraph_ShowAmountPerSecond(rMax, unsortedList, sortedList)

	local rTemp = _G.recap_temp
	local i, j, iCombatant, fqName
	local lastBin, displayBins, maxPerSecond, windowLength
	local startTime, maxTime
	local maxBins, maxX, maxY, spaceX, spaceY, iOptions

	-- check whether there is something to display
	if rMax[2] == 0 then
		RecapGraph_GraphClear()
		return
	end

	-- how many bins should we have?
	if (rGraph.StartTime > 0) and (rGraph.EndTime > 0) then
		-- we have our own saved numbers, use them
		startTime = rGraph.StartTime
		maxTime = rGraph.EndTime - startTime
	else
		-- otherwise use the current fight numbers
		startTime = rTemp.FightStart
		maxTime = rTemp.FightEnd - startTime
	end
	-- adjust in case our number of bins is longer than the fight time
	maxBins = 0
	for i in pairs(rGraph[unsortedList]) do
		maxBins = math_max(maxBins, #rGraph[unsortedList][i].Display)
	end
	maxTime = math_max(maxTime, ((maxBins - 1) * rGraph.BinSize))

	-- fight is significant, or we are paused (in which case we act as if the fight is significant)
	if (rGraph.FightSignificant == true) or (rGraph.Paused == true) then
		-- fill out all bins as necessary
		rMax[2] = math_max(rMax[2], (math_floor(maxTime / rGraph.BinSize) + 1))
		for i, iCombatant in pairs(rGraph[unsortedList]) do
			displayBins = iCombatant.Display
			lastBin = #iCombatant.Display
			if lastBin == 0 then
				-- nothing yet for this combatant
			else
				-- add bins as necessary
				if rMax[2] > lastBin then
					for j = lastBin + 1, rMax[2] do
						displayBins[j] = { ((j - 1) * rGraph.BinSize), 0 }
					end
				end
			end
		end
	end

	-- display as appropriate
	-- Note: we may end up plotting more than one point to a pixel, which is technically wrong -- tough

	-- axes
	windowLength = rGraph.BinSize * rGraph.NBins
	-- time maximum rounded up to the nearest 30 seconds
	maxX = 30 * (math_floor(maxTime / 30) + 1)
	spaceX = maxX / 6
	-- per second maximum rounded up by approximate factors of two
	maxPerSecond = rMax[1]
	maxY = 2 ^ (math_floor(3.321928 * math_log10(maxPerSecond)) + 1)
	if maxY < 130 then
		-- round down to the nearest multiple of 10
		maxY = 10 * math_floor(maxY / 10)
	elseif maxY < 1000 then
		-- round down to the nearest multiple of 50 (i.e. 256 -> 250 and 512 -> 500)
		maxY = 50 * math_floor(maxY / 50)
	else
		-- round down to the nearest multiple of 1000
		maxY = 1000 * math_floor(maxY / 1000)
	end
	-- can we adjust maxY value to use more of the graph vertically?
	if maxY >= 250 then
		-- only when the axis values will be integers (initial maxY a multiple of 25)
		if maxPerSecond <= (3 * maxY / 5) then
			maxY = 3 * maxY / 5
		elseif maxPerSecond <= (4 * maxY / 5) then
			maxY = 4 * maxY / 5
		end
	end
	maxY = math_max(maxY, 20) -- scale to at least 20 value per second
	spaceY = maxY / 5
	-- allow room above top grid line for top grid line label (also allows for the truncation that we just did on maxY)
	maxY = math_floor(1.1 * maxY)

	_G.RecapGraph:Hide()

	-- titles and tabs
	_G.RecapGraphLabel:SetText(rLocalize.At.." "..Recap_FormatTimeSeen(startTime).." "..rLocalize.For.." "..Recap_Round0(maxTime).." "..RECAP_SECS.."  "..RECAP_PEAK..": "..Recap_Round0(maxPerSecond))

	-- X axis labels the hard way (since these do not seem to be supported by LibGraphL)
	for i = 0, 6 do
		_G["RecapGraphXAxisText_"..i]:SetText(i * spaceX)
		_G["RecapGraphXAxisText_"..i]:SetTextColor(1.0,1.0,1.0,0.85)
	end

	-- graph
	recapLineGraphPanel:ResetData()
	recapLineGraphPanel:SetXAxis(0, maxX)
	recapLineGraphPanel:SetYAxis(0, maxY)
	recapLineGraphPanel:LockYMin(true)
	recapLineGraphPanel:SetYLabels(true,true)
	recapLineGraphPanel:SetGridSpacing(spaceX, spaceY)
	recapLineGraphPanel:SetAxisDrawing(true,true)
	recapLineGraphPanel:SetAutoScale(false)
	recapLineGraphPanel:SetGridColor({0.5,0.5,0.5,0.5})
	recapLineGraphPanel:SetAxisColor({0.85,0.85,0.85,0.5})

	-- data
	for i in pairs(rGraph[sortedList]) do
		-- this is in the sorting order established at start of fight (either based on earlier total damage, or alphabetical)

		if (i > 25) then
			-- maximum of 25 supported at the moment
			break
		end

		-- colours
		j = 1 + ((i - 1) % nColors)

		-- fully qualified name
		fqName = rGraph[sortedList][i][1]

		-- which set of options?
		if rGraph.Statistic == RECAP_DPS_OUT then
			iOptions = rGraph.CombatantsDPSOut[fqName]
		elseif rGraph.Statistic == RECAP_DPS_IN then
			iOptions = rGraph.CombatantsDPSIn[fqName]
		elseif rGraph.Statistic == RECAP_HPS_OUT then
			iOptions = rGraph.CombatantsHPSOut[fqName]
		end

		-- show data
		iCombatant = rGraph[unsortedList][fqName]
		lastBin = #iCombatant.Display
		if (lastBin > 0) and (iOptions.Checked == true) then
			-- showing this one
			if (iOptions.Dimmed == true) then
				recapLineGraphPanel:AddDataSeries(iCombatant.Display, { liveColors[j][1], liveColors[j][2], liveColors[j][3], 0.2 } )
			else
				-- full colour
				recapLineGraphPanel:AddDataSeries(iCombatant.Display, { liveColors[j][1], liveColors[j][2], liveColors[j][3], 1.0 } )
			end
		end
	end

	-- names and colours (has a second loop)
	RecapGraph_GraphOptionsRefresh()
	_G.RecapGraph:Show()
end

local function RecapGraph_DefineGauges()

	local i, gaugeColour

	if rGraph.Statistic == RECAP_DPS_OUT then
		gaugeColour = gaugeOut
	elseif rGraph.Statistic == RECAP_DPS_IN then
		gaugeColour = gaugeIn
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		gaugeColour = gaugeHeal
	end

	rGraph.TextGaugeMax = 0
	for i=1,rGraph.TextListSize-1 do
		if (rGraph.TextList[i][rGraph.TextSorting] ~= "--") then
			rGraph.TextGaugeMax = math_max(rGraph.TextList[i][rGraph.TextSorting], rGraph.TextGaugeMax)
		end
	end
	for i=1,11 do
		_G["RecapGraphList"..i.."_Gauge"]:SetVertexColor(unpack(gaugeColour))
	end
end

-- for sorting dynamically by column
local function RecapGraph_DynamicSort(e1,e2)

	local item1 = e1[rGraph.TextSorting]
	local item2 = e2[rGraph.TextSorting]

	if (not item1) or (item1 == "--") then
		item1 = 0
	end
	if (not item2) or (item2 == "--") then
		item2 = 0
	end

	if (item1>item2) then
		return true
	else
		return false
	end
end

local function RecapGraph_ConstructTextListing(unsortedList, sortedList)

	local i, j, iList, iCombatant, fightTime, iOptions, fqName

	-- clear the list
	rGraph.TextListSize = 1
	rGraph.TextList = wipe(rGraph.TextList)

	for i in pairs(rGraph[sortedList]) do
		-- this is in the sorting order established at start of fight (either based on earlier total damage, or alphabetical)

		-- unlike the graph, which is limited to 25 combatants, the text listing is not limited

		-- colours
		j = 1 + ((i - 1) % nColors)

		-- fully qualified name
		fqName = rGraph[sortedList][i][1]

		-- which set of options?
		if rGraph.Statistic == RECAP_DPS_OUT then
			iOptions = rGraph.CombatantsDPSOut[fqName]
		elseif rGraph.Statistic == RECAP_DPS_IN then
			iOptions = rGraph.CombatantsDPSIn[fqName]
		elseif rGraph.Statistic == RECAP_HPS_OUT then
			iOptions = rGraph.CombatantsHPSOut[fqName]
		end

		-- show data
		if (iOptions.Checked == true) then
			-- showing this one

			if not rGraph.TextList[rGraph.TextListSize] then
				rGraph.TextList[rGraph.TextListSize] = {}
			end
			iList = rGraph.TextList[rGraph.TextListSize]

			iCombatant = rGraph[unsortedList][fqName]
			iList.Name = rGraph[sortedList][i][2]
			iList.Total = iCombatant.Total
			iList.Peak = iCombatant.Peak
			-- take time from number of bins minus the 'empty' ones that don't correspond to raw data
			fightTime = (#iCombatant.Display - rGraph.NBins + 1) * rGraph.BinSize
			if (fightTime >= 6) then
				-- only calculate a long term average if the combat is 6 seconds or longer
				iList.Avg = Recap_Div0(iCombatant.Total, fightTime)
			else
				iList.Avg = "--"
			end
			if (iOptions.Dimmed == true) then
				iList.Colour = { liveColors[j][1], liveColors[j][2], liveColors[j][3], 0.4 }
			else
				-- full colour
				iList.Colour = { liveColors[j][1], liveColors[j][2], liveColors[j][3], 1.0 }
			end
			rGraph.TextListSize = rGraph.TextListSize + 1
		end
	end
	rGraph.TextList[rGraph.TextListSize] = nil -- keep as nil

	-- if requested, dynamically sort
	if (rGraph.TextSorting ~= "none") and (rGraph.TextListSize > 1) then
		table_sort(rGraph.TextList,RecapGraph_DynamicSort)

		RecapGraph_DefineGauges()
	end
end

local function RecapGraph_PopulateTextListing(rMax, unsortedList, sortedList)

	local rTemp = _G.recap_temp
	local sbOffset, startTime, maxTime

	-- title
	if (rGraph.StartTime > 0) and (rGraph.EndTime > 0) then
		startTime = rGraph.StartTime
		maxTime = rGraph.EndTime - startTime
	else
		startTime = rTemp.FightStart
		maxTime = rTemp.FightEnd - startTime
	end
	_G.RecapGraphLabel:SetText(rLocalize.At.." "..Recap_FormatTimeSeen(startTime).." "..rLocalize.For.." "..Recap_Round0(maxTime).." "..RECAP_SECS.."  "..RECAP_PEAK..": "..Recap_Round0(rMax[1]))

	RecapGraph_ConstructTextListing(unsortedList, sortedList)
	-- remembered scrolling offset
	sbOffset = rGraph.ListScrollingOffset
	FauxScrollFrame_SetOffset(RecapGraphListScrollBar, sbOffset)
	RecapGraphListScrollBar_Update()
	RecapGraphListScrollBarScrollBar:SetValue(sbOffset*14)
end

local function RecapGraph_SortLiveLists()

	local rCombatants = _G.recap_combatants
	local i, sortByAmount, iSorted, iCombatant, amount

	-- update amounts, see if there are amounts greater than zero, and if so sort by descending amount (otherwise alphabetically)
	sortByAmount = false
	for i, iSorted in pairs(rGraph.LiveDmgOutSorted) do
		iSorted[3] = 0
		iCombatant = rCombatants[iSorted[1]]
		if iCombatant then
			amount = (iCombatant.TotalDmgOut or 0)
			iSorted[3] = amount
			if amount > 0 then
				sortByAmount = true
			end
		end
	end
	if sortByAmount then
		table_sort(rGraph.LiveDmgOutSorted,RecapGraph_SortDown)
	else
		table_sort(rGraph.LiveDmgOutSorted,RecapGraph_SortUp)
	end

	sortByAmount = false
	for i, iSorted in pairs(rGraph.LiveDmgInSorted) do
		iSorted[3] = 0
		iCombatant = rCombatants[iSorted[1]]
		if iCombatant then
			amount = (iCombatant.TotalDmgIn or 0)
			iSorted[3] = amount
			if amount > 0 then
				sortByAmount = true
			end
		end
	end
	if sortByAmount then
		table_sort(rGraph.LiveDmgInSorted,RecapGraph_SortDown)
	else
		table_sort(rGraph.LiveDmgInSorted,RecapGraph_SortUp)
	end

	sortByAmount = false
	for i, iSorted in pairs(rGraph.LiveHealingSorted) do
		iSorted[3] = 0
		iCombatant = rCombatants[iSorted[1]]
		if iCombatant then
			amount = (iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)
			iSorted[3] = amount
			if amount > 0 then
				sortByAmount = true
			end
		end
	end
	if sortByAmount then
		table_sort(rGraph.LiveHealingSorted,RecapGraph_SortDown)
	else
		table_sort(rGraph.LiveHealingSorted,RecapGraph_SortUp)
	end
end

local function RecapGraphText_PostSpamRows(myType)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, text, nLines
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local headertext, headerLabel

	chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
	if chatchan=="Self" then
		print_chat = Recap_Print
	end

	-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
	if Recap_WIMFindFocus() then
		print_chat = Recap_WIM_Print
	end

	-- If the Clipboard is open, post there instead of to chat or console
	if RecapClipEditBox:IsVisible() then
		print_chat = Recap_LineToClipboard
		maxLines = rTemp.MaxLinesToClipboard
	end

	if rGraph.Statistic == RECAP_DPS_OUT then
		if myType == "Total" then
			headerLabel = RECAP_TOTAL.." "..RECAP_DMG_OUT
		elseif myType == "Peak" then
			headerLabel = RECAP_PEAK.." "..RECAP_DPS_OUT
		elseif myType == "Avg" then
			headerLabel = RECAP_AVG.." "..RECAP_DPS_OUT
		end
	elseif rGraph.Statistic == RECAP_DPS_IN then
		if myType == "Total" then
			headerLabel = RECAP_TOTAL.." "..RECAP_DMG_IN
		elseif myType == "Peak" then
			headerLabel = RECAP_PEAK.." "..RECAP_DPS_IN
		elseif myType == "Avg" then
			headerLabel = RECAP_AVG.." "..RECAP_DPS_IN
		end
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		if myType == "Total" then
			headerLabel = RECAP_TOTAL.." "..RECAP_HEALS_OUT
		elseif myType == "Peak" then
			headerLabel = RECAP_PEAK.." "..RECAP_HPS_OUT
		elseif myType == "Avg" then
			headerLabel = RECAP_AVG.." "..RECAP_HPS_OUT
		end
	end

	headertext = "__ Recap ("..Recap_PetsMergedText().."): "..headerLabel.." __"
	nLines = 0
	for i=1, 1000 do
		if rGraph.TextList[i] and rGraph.TextList[i].Name then
			if (i<rGraph.TextListSize) then
				if rGraph.TextList[i][myType] and (rGraph.TextList[i][myType] ~= "--") and (rGraph.TextList[i][myType] > 0) then
					local listCombatant = rGraph.TextList[i]
					local iName = i..". "..rGraph.TextList[i].Name
					text = Recap_FormatNameFirstStat(iName, myType, listCombatant)
					if headertext then
						if print_chat(headertext, chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						headertext = nil -- keep as nil
					end
					if print_chat(text, chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					nLines = nLines + 1
					if nLines >= maxLines then
						break
					end
				end
			end
		end
	end

	if RecapClipEditBox:IsVisible() then
		RecapClipEditBox:HighlightText()
		RecapClipEditBox:SetFocus()
	end
end


--[[ global functions ]]

function RecapGraph_InitializeLiveLists()

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local i, j, iCombatant

	if not rOpt.LiveData.value then
		return
	end

	-- make sure we can collect data
	rGraph.Paused = false

	-- initialize any existing combatants
	for i, iCombatant in pairs(rGraph.LiveDmgOutBins) do
		iCombatant.Highwater = 0
		iCombatant.RawTotal = 0
		iCombatant.Raw = wipe(iCombatant.Raw)
		-- Display bins are not touched at this time
		for j in pairs(rGraph.LiveDmgOutSorted) do
			-- update the matching sorted entry
			if (rGraph.LiveDmgOutSorted[j][1] == i) then
				if rCombatants[i] then
					rGraph.LiveDmgOutSorted[j][3] = (rCombatants[i].TotalDmgOut or 0)
				else
					rGraph.LiveDmgOutSorted[j][3] = 0
				end
				break
			end
		end
	end
	for i, iCombatant in pairs(rGraph.LiveDmgInBins) do
		iCombatant.Highwater = 0
		iCombatant.RawTotal = 0
		iCombatant.Raw = wipe(iCombatant.Raw)
		-- Display bins are not touched at this time
		for j in pairs(rGraph.LiveDmgInSorted) do
			-- update the matching sorted entry
			if (rGraph.LiveDmgInSorted[j][1] == i) then
				if rCombatants[i] then
					rGraph.LiveDmgInSorted[j][3] = (rCombatants[i].TotalDmgIn or 0)
				else
					rGraph.LiveDmgInSorted[j][3] = 0
				end
				break
			end
		end
	end
	for i, iCombatant in pairs(rGraph.LiveHealingBins) do
		iCombatant.Highwater = 0
		iCombatant.RawTotal = 0
		iCombatant.Raw = wipe(iCombatant.Raw)
		-- Display bins are not touched at this time
		for j in pairs(rGraph.LiveHealingSorted) do
			-- update the matching sorted entry
			if (rGraph.LiveHealingSorted[j][1] == i) then
				if rCombatants[i] then
					rGraph.LiveHealingSorted[j][3] = (iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)
				else
					rGraph.LiveHealingSorted[j][3] = 0
				end
				break
			end
		end
	end

	-- update to add and remove combatants
	RecapGraph_UpdateLiveLists()

	-- indicate that we've initialized
	rGraph.BinsInitialized = true
end

function RecapGraph_InitializeDisplayLists()

	local rOpt = _G.recap_temp.Opt
	local i, iCombatant

	if not rOpt.LiveData.value then
		return
	end

	rGraph.StartTime = 0
	rGraph.EndTime = 0

	-- initialize the Display bins
	for i, iCombatant in pairs(rGraph.LiveDmgOutBins) do
		iCombatant.Total = 0
		iCombatant.Peak = 0
		iCombatant.Display = wipe(iCombatant.Display)
	end
	rGraph.LiveDPSOutMax[1] = 0
	rGraph.LiveDPSOutMax[2] = 0
	for i, iCombatant in pairs(rGraph.LiveDmgInBins) do
		iCombatant.Total = 0
		iCombatant.Peak = 0
		iCombatant.Display = wipe(iCombatant.Display)
	end
	rGraph.LiveDPSInMax[1] = 0
	rGraph.LiveDPSInMax[2] = 0
	for i, iCombatant in pairs(rGraph.LiveHealingBins) do
		iCombatant.Total = 0
		iCombatant.Peak = 0
		iCombatant.Display = wipe(iCombatant.Display)
	end
	rGraph.LiveHPSOutMax[1] = 0
	rGraph.LiveHPSOutMax[2] = 0

	-- allow processing from raw bins to display bins
	rGraph.ProcessLockStatus = "unlock"
end

function RecapGraph_AddToOneLiveList(fqName, shortName, unsortedList, sortedList, optionList)

	local rTemp = _G.recap_temp
	local j

	if not rGraph[unsortedList][fqName] then
		rGraph[unsortedList][fqName] = {} -- unsorted
		rGraph[unsortedList][fqName].Highwater = 0 -- highest bin with data
		rGraph[unsortedList][fqName].RawTotal = 0 -- total so far
		rGraph[unsortedList][fqName].Total = 0 -- total so far (display field)
		rGraph[unsortedList][fqName].Peak = 0 -- peak DPS so far (display field)
		rGraph[unsortedList][fqName].Raw = {} -- raw data bins
		rGraph[unsortedList][fqName].Display = {} -- display data bins (unsorted, indexed by fully qualified combatant name)
		-- the following table will be sorted by prior total and is used to govern order of display
		table_insert(rGraph[sortedList], { fqName, shortName, 0, rGraph[unsortedList][fqName] } ) -- full name (in case we need to go backwards), short name, prior total damage (default 0), pointer to unsorted bin
	end
	if not rGraph[optionList][fqName] then
		-- set up default semi-permanent info for combatants
		-- if Checked, then show this combatant
		-- if Featured, this combatant will be shown normal, all others dim
		--   (needed to allow a click on a Featured combatant to turn the feature off without having to check that everyone else is dim)
		-- if Dimmed, this combatant will be shown dim (if shown at all)
		rGraph[optionList][fqName] = { Checked = false, Featured = false, Dimmed = false }
		-- the player is always initially checked
		if fqName == rTemp.PlayerGUID then
			rGraph[optionList][fqName].Checked = true
		end
		-- is anyone featured?
		for j in pairs(rGraph[optionList]) do
			if rGraph[optionList][j].Featured then
				rGraph[optionList][fqName].Dimmed = true
				break
			end
		end
	end
end

function RecapGraph_UpdateLiveLists()

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, j, name

	if rGraph.Paused then
		-- not collecting live data at the moment, bail (we don't want the list of combatants to change on us)
		return
	end

	Recap_MakeFriends(false)

	-- first scan the existing lists, and remove anyone no longer in rTemp.InGroup
	for i in pairs(rGraph.CombatantsDPSOut) do
		if not rTemp.InGroup[i] then
			if rGraph.LiveDmgOutBins[i] then
				rGraph.LiveDmgOutBins[i] = nil
			end
			for j in pairs(rGraph.LiveDmgOutSorted) do
				if rGraph.LiveDmgOutSorted[j][1] == i then
					table_remove(rGraph.LiveDmgOutSorted, j)
					break
				end
			end
			rGraph.CombatantsDPSOut[i] = nil
		end
	end
	for i in pairs(rGraph.CombatantsDPSIn) do
		if not rTemp.InGroup[i] then
			if rGraph.LiveDmgInBins[i] then
				rGraph.LiveDmgInBins[i] = nil
			end
			for j in pairs(rGraph.LiveDmgInSorted) do
				if rGraph.LiveDmgInSorted[j][1] == i then
					table_remove(rGraph.LiveDmgInSorted, j)
					break
				end
			end
			rGraph.CombatantsDPSIn[i] = nil
		end
	end
	for i in pairs(rGraph.CombatantsHPSOut) do
		if not rTemp.InGroup[i] then
			if rGraph.LiveHealingBins[i] then
				rGraph.LiveHealingBins[i] = nil
			end
			for j in pairs(rGraph.LiveHealingSorted) do
				if rGraph.LiveHealingSorted[j][1] == i then
					table_remove(rGraph.LiveHealingSorted, j)
					break
				end
			end
			rGraph.CombatantsHPSOut[i] = nil
		end
	end

	-- second scan InGroup and add anyone who isn't in a list
	for i in pairs(rTemp.InGroup) do
		if Recap_ExtractOwner(i) or (rCombatants[i] and rCombatants[i].OwnedBy) or (i == rTemp.GroupTotal) or (i == rTemp.NonGroupTotal) or
			(rCombatants[i] and rCombatants[i].Flags and (bit_band(rCombatants[i].Flags, bit_bor(COMBATLOG_OBJECT_TYPE_OBJECT, COMBATLOG_OBJECT_TYPE_GUARDIAN, COMBATLOG_OBJECT_TYPE_PET)) ~= 0)) then
			-- pet, or total, ignore
			-- could be problematic for vehicles, not sure
		else
			-- not a pet
			name = Recap_StripGUIDsFromCombatant(i)
			-- check the various tables and add entries as appropriate
			RecapGraph_AddToOneLiveList(i, name, "LiveDmgOutBins", "LiveDmgOutSorted", "CombatantsDPSOut")
			RecapGraph_AddToOneLiveList(i, name, "LiveDmgInBins", "LiveDmgInSorted", "CombatantsDPSIn")
			RecapGraph_AddToOneLiveList(i, name, "LiveHealingBins", "LiveHealingSorted", "CombatantsHPSOut")
		end
	end

	-- third update prior amounts and sort the Sorted lists
	RecapGraph_SortLiveLists()

	-- if Options panel is visible, hide then show to get an update
	if RecapGraphOptions:IsVisible() then
		RecapGraphOptions:Hide()
		RecapGraphOptions:Show()
	end
end

function RecapGraph_ClearLiveLists()

	rGraph.LiveDmgOutBins = wipe(rGraph.LiveDmgOutBins)
	rGraph.LiveDmgOutSorted = wipe(rGraph.LiveDmgOutSorted)
	rGraph.LiveDPSOutMax = { 0, 0 }
	rGraph.LiveDmgInBins = wipe(rGraph.LiveDmgInBins)
	rGraph.LiveDmgInSorted = wipe(rGraph.LiveDmgInSorted)
	rGraph.LiveDPSInMax = { 0, 0 }
	rGraph.LiveHealingBins = wipe(rGraph.LiveHealingBins)
	rGraph.LiveHealingSorted = wipe(rGraph.LiveHealingSorted)
	rGraph.LiveHPSOutMax = { 0, 0 }
	rGraph.CombatantsDPSOut = wipe(rGraph.CombatantsDPSOut)
	rGraph.CombatantsDPSIn = wipe(rGraph.CombatantsDPSIn)
	rGraph.CombatantsHPSOut = wipe(rGraph.CombatantsHPSOut)

	-- clear graph
	RecapGraph_GraphClear()

	-- clear options side panel
	for i = 1, 25 do
		_G["RecapGraphCombatantCheck"..i]:SetChecked(0)
		_G["RecapGraphCombatantList"..i.."_FullyQualifiedName"]:SetText("")
		_G["RecapGraphCombatantList"..i.."_Text"]:SetText("")
	end

	-- indicate that we're no longer initialized
	rGraph.BinsInitialized = false
end

function RecapGraph_SetOptionsPanel()

	-- put label, option button, and option panel to left or to right as necessary
	if (_G["RecapGraph"]:GetLeft() + _G["RecapGraph"]:GetRight()) < (GetScreenWidth() / RecapGraph:GetScale()) then -- factors of 2 cancel out
		-- put stuff out to the right
		RecapGraphLabel:SetPoint("TOPLEFT", 8, -30)
		RecapGraphOptionsButton:SetPoint("TOPLEFT", 266, -29)
		RecapGraphOptions:SetPoint("TOPLEFT", "RecapGraph", "TOPRIGHT", -3, 0)
		if RecapGraphOptions:IsVisible() then
			RecapGraphOptionsButton:SetText(RECAP_LESS_RIGHT)
		else
			RecapGraphOptionsButton:SetText(RECAP_MORE_RIGHT)
		end
	else
		-- put stuff out to the left
		RecapGraphLabel:SetPoint("TOPLEFT", 67, -30)
		RecapGraphOptionsButton:SetPoint("TOPLEFT", 6, -29)
		RecapGraphOptions:SetPoint("TOPLEFT", "RecapGraph", "TOPLEFT", -217, 0)
		if RecapGraphOptions:IsVisible() then
			RecapGraphOptionsButton:SetText(RECAP_LESS_LEFT)
		else
			RecapGraphOptionsButton:SetText(RECAP_MORE_LEFT)
		end
	end
end

function RecapGraph_GraphUpdate()

	local rOpt = _G.recap_temp.Opt

	if rOpt.LiveData.value then

		-- we only process combatants that the player wants to look at (to save processing and memory)
		-- to support continuing to examine results until a new "significant" fight has begun, we have a three-state lock on processing
		--   the downside is that if the player hadn't yet looked at a combatant, and if a new fight has begun (thereby locking processing), and if the player now selects that combatant, then displaying that newly selected combatant will give incomplete results (usually empty, but potentially truncated)
		--	  that newly selected combatant will only have complete results to display when the next fight becomes significant
		-- if we are paused, we act as if the fight to display is significant
		if ((rGraph.FightSignificant == true) and (rGraph.ProcessLockStatus ~= "lock")) or (rGraph.Paused == true) then
			-- fight is significant, and processing is not locked, do main processing
			RecapGraph_ProcessBins(rGraph.LiveDPSOutMax, "LiveDmgOutBins", "CombatantsDPSOut")
			RecapGraph_ProcessBins(rGraph.LiveDPSInMax, "LiveDmgInBins", "CombatantsDPSIn")
			RecapGraph_ProcessBins(rGraph.LiveHPSOutMax, "LiveHealingBins", "CombatantsHPSOut")
		end

		_G.RecapGraphGraph:Hide()
		_G.RecapGraphText:Hide()
		_G.RecapGraph:Hide()
		if (rGraph.TextToggle == "graph") then
			if rGraph.Statistic == RECAP_DPS_OUT then
				RecapGraph_ShowAmountPerSecond(rGraph.LiveDPSOutMax, "LiveDmgOutBins", "LiveDmgOutSorted")
			elseif rGraph.Statistic == RECAP_DPS_IN then
				RecapGraph_ShowAmountPerSecond(rGraph.LiveDPSInMax, "LiveDmgInBins", "LiveDmgInSorted")
			elseif rGraph.Statistic == RECAP_HPS_OUT then
				RecapGraph_ShowAmountPerSecond(rGraph.LiveHPSOutMax, "LiveHealingBins", "LiveHealingSorted")
			end
			_G.RecapGraphGraph:Show()
			_G.RecapGraphGraphTab:LockHighlight()
			_G.RecapGraphTextTab:UnlockHighlight()
		else
			if rGraph.Statistic == RECAP_DPS_OUT then
				RecapGraph_PopulateTextListing(rGraph.LiveDPSOutMax, "LiveDmgOutBins", "LiveDmgOutSorted")
			elseif rGraph.Statistic == RECAP_DPS_IN then
				RecapGraph_PopulateTextListing(rGraph.LiveDPSInMax, "LiveDmgInBins", "LiveDmgInSorted")
			elseif rGraph.Statistic == RECAP_HPS_OUT then
				RecapGraph_PopulateTextListing(rGraph.LiveHPSOutMax, "LiveHealingBins", "LiveHealingSorted")
			end

			-- highlight (or otherwise) the text listing column headers if we are sorting dynamically
			_G.RecapGraphListHeader_Total:UnlockHighlight()
			_G.RecapGraphListHeader_Peak:UnlockHighlight()
			_G.RecapGraphListHeader_Avg:UnlockHighlight()
			if (rGraph.TextSorting ~= "none") then
				_G["RecapGraphListHeader_"..rGraph.TextSorting]:LockHighlight()
			end

			-- display
			_G.RecapGraphText:Show()
			_G.RecapGraphGraphTab:UnlockHighlight()
			_G.RecapGraphTextTab:LockHighlight()
		end

		-- light the chosen buttons in the top bar
		_G.RecapGraphShowDPSOutButton:Hide()
		_G.RecapGraphShowDPSInButton:Hide()
		_G.RecapGraphShowHPSOutButton:Hide()
		_G.RecapGraphShowDPSOutButton:UnlockHighlight()
		_G.RecapGraphShowDPSInButton:UnlockHighlight()
		_G.RecapGraphShowHPSOutButton:UnlockHighlight()
		if rGraph.Statistic == RECAP_DPS_OUT then
			_G.RecapGraphShowDPSOutButton:LockHighlight()
		elseif rGraph.Statistic == RECAP_DPS_IN then
			_G.RecapGraphShowDPSInButton:LockHighlight()
		elseif rGraph.Statistic == RECAP_HPS_OUT then
			_G.RecapGraphShowHPSOutButton:LockHighlight()
		end
		_G.RecapGraphShowDPSOutButton:Show()
		_G.RecapGraphShowDPSInButton:Show()
		_G.RecapGraphShowHPSOutButton:Show()

		-- adjust the options stuff right or left as appropriate
		RecapGraph_SetOptionsPanel()

		_G.RecapGraph:Show()
	end
end

function RecapGraph_GraphOptionsRefresh()

	local i, j, sortedList, fqName, shortName, shortNameNoRealm, iOptions, wasVisible

	wasVisible = RecapGraphOptions:IsVisible()
	if wasVisible then
		_G.RecapGraphOptions:Hide()
	end

	if rGraph.Statistic == RECAP_DPS_OUT then
		sortedList = "LiveDmgOutSorted"
	elseif rGraph.Statistic == RECAP_DPS_IN then
		sortedList = "LiveDmgInSorted"
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		sortedList = "LiveHealingSorted"
	end

	-- first, clear options side panel
	for i = 1, 25 do
		_G["RecapGraphCombatantCheck"..i]:SetChecked(0)
		_G["RecapGraphCombatantList"..i.."_FullyQualifiedName"]:SetText("")
		_G["RecapGraphCombatantList"..i.."_Text"]:SetText("")
	end

	-- update names and colours for the options, for situations where there are no data
	for i in pairs(rGraph[sortedList]) do
		if (i > 25) then
			-- maximum of 25 supported at the moment (doesn't handle a raid 40)
			break
		end

		-- colours
		j = 1 + ((i - 1) % nColors)

		-- fully qualified name (so that from a click we can identify the combatant)
		fqName = rGraph[sortedList][i][1]
		_G["RecapGraphCombatantList"..i.."_FullyQualifiedName"]:SetText(fqName)

		-- short name (may include realm)
		shortName = rGraph[sortedList][i][2]

		-- very short name (no realm -- ambiguity will occasionally arise -- tough)
		shortNameNoRealm = Recap_NameFromNameRealm(shortName)

		-- which set of options?
		if rGraph.Statistic == RECAP_DPS_OUT then
			iOptions = rGraph.CombatantsDPSOut[fqName]
		elseif rGraph.Statistic == RECAP_DPS_IN then
			iOptions = rGraph.CombatantsDPSIn[fqName]
		elseif rGraph.Statistic == RECAP_HPS_OUT then
			iOptions = rGraph.CombatantsHPSOut[fqName]
		end

		-- colour things up
		if (iOptions.Checked == true) then
			-- showing this one
			_G["RecapGraphCombatantCheck"..i]:SetChecked(1)

			if (iOptions.Dimmed == true) then
				_G["RecapGraphCombatantList"..i.."_Text"]:SetText("  "..shortNameNoRealm) -- indented as well as dimmed
				_G["RecapGraphCombatantList"..i.."_Text"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 0.6)
				_G["RecapGraphCombatantList"..i.."_SaveColor"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 0.6)
			else
				-- full colour
				_G["RecapGraphCombatantList"..i.."_Text"]:SetText(shortNameNoRealm)
				_G["RecapGraphCombatantList"..i.."_Text"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 1.0)
				_G["RecapGraphCombatantList"..i.."_SaveColor"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 1.0)
			end
		else
			-- not showing this one
			_G["RecapGraphCombatantCheck"..i]:SetChecked(0)

			if (iOptions.Dimmed == true) then
				_G["RecapGraphCombatantList"..i.."_Text"]:SetText("  "..shortNameNoRealm) -- indented as well as dimmed
				_G["RecapGraphCombatantList"..i.."_Text"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 0.6)
				_G["RecapGraphCombatantList"..i.."_SaveColor"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 0.6)
			else
				-- full colour
				_G["RecapGraphCombatantList"..i.."_Text"]:SetText(shortNameNoRealm)
				_G["RecapGraphCombatantList"..i.."_Text"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 1.0)
				_G["RecapGraphCombatantList"..i.."_SaveColor"]:SetTextColor(liveColors[j][1], liveColors[j][2], liveColors[j][3], 1.0)
			end
		end
	end

	if wasVisible then
		_G.RecapGraphOptions:Show()
	end
end

function RecapGraphListScrollBar_Update()

	local rTemp = _G.recap_temp
	local i, index, iList, item

	if rTemp.Loaded and rGraph.TextListSize then

		FauxScrollFrame_Update(RecapGraphListScrollBar,rGraph.TextListSize-1,11,14)
		-- get the scrolling offset
		rGraph.ListScrollingOffset = FauxScrollFrame_GetOffset(RecapGraphListScrollBar)

		for i=1,11 do
			index = i + rGraph.ListScrollingOffset
			if index < rGraph.TextListSize then
				iList = rGraph.TextList[index]
				item = _G["RecapGraphList"..i.."_Name"]
				item:SetText(iList.Name)
				item:SetTextColor(iList.Colour[1], iList.Colour[2], iList.Colour[3], iList.Colour[4])
				item = _G["RecapGraphList"..i.."_Total"]
				item:SetText(iList.Total)
				item:SetTextColor(iList.Colour[1], iList.Colour[2], iList.Colour[3], iList.Colour[4])
				item = _G["RecapGraphList"..i.."_Peak"]
				item:SetText(iList.Peak)
				item:SetTextColor(iList.Colour[1], iList.Colour[2], iList.Colour[3], iList.Colour[4])
				item = _G["RecapGraphList"..i.."_Avg"]
				item:SetText(iList.Avg)
				item:SetTextColor(iList.Colour[1], iList.Colour[2], iList.Colour[3], iList.Colour[4])

				-- gauges
				item = _G["RecapGraphList"..i.."_Gauge"]
				if (rGraph.TextGaugeMax > 0) and (rGraph.TextSorting ~= "none") and (iList[rGraph.TextSorting] ~= "--") then
					item:SetWidth(1+rGraph.TextGaugeWidth*iList[rGraph.TextSorting]/rGraph.TextGaugeMax)
					item:Show()
				else
					item:Hide()
				end

				item = _G["RecapGraphList"..i]
				item:Show()
			else
				item = _G["RecapGraphList"..i]
				item:Hide()
			end
		end

	end
end


--[[ support functions ]]

function RecapGraph_Close()
	RecapGraph_GraphClear()
	_G.RecapGraph:Hide()
end

-- TODO: have not figured out whether or not this will work properly if a save is in progress
function RecapGraph_GraphPauseResume()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local button = _G["RecapGraphPauseButton"]

	if rGraph.Paused then
		rGraph.Paused = false
		button:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
		button:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
		RecapGraph_UpdateLiveLists()
		PlaySound("GnomeExploration")
	else
		rGraph.Paused = true
		if rUser.State=="Active" then
			-- if currently in combat, grab the current start and end times
			if (rTemp.FightStart > 0) and (rTemp.FightStartIn > 0) then
				rGraph.StartTime = math_min(rTemp.FightStart, rTemp.FightStartIn)
			else
				rGraph.StartTime = math_max(rTemp.FightStart, rTemp.FightStartIn)
			end
			rGraph.EndTime = math_max(rTemp.FightEnd, rTemp.FightEndIn)
		end
		button:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
		button:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
		PlaySound("GnomeExploration")
	end
end

function RecapGraph_OnMouseDown(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapGraph:StartMoving()
	end
end

function RecapGraph_OnMouseUp(frame, button)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapGraph:StopMovingOrSizing()
		-- this panel does not dock
		if rUser.GraphAnchor.value then
			RecapGraph:ClearAllPoints()
			RecapGraph:SetPoint(rUser.GraphAnchor.Graph,"RecapFrame",rUser.GraphAnchor.Main,Recap_GraphOffset("x"),Recap_GraphOffset("y"))
		end

		-- have the options swap sides if necessary
		RecapGraph:Hide()
		RecapGraph_SetOptionsPanel()
		RecapGraph:Show()
	end
end

function Recap_GraphOffset(axis)

	local rUser = _G.recap_user
	local anchor

	anchor = rUser.GraphAnchor.Main..rUser.GraphAnchor.Graph
	if dockoffset[anchor] and axis then
		return dockoffset[anchor][axis]
	else
		return 0
	end
end

function RecapGraph_SwitchGraphText()

	_G["RecapGraphGraphTab"]:Hide()
	_G["RecapGraphTextTab"]:Hide()
	if rGraph.TextToggle == "graph" then
		_G["RecapGraphGraphTab"]:LockHighlight()
		_G["RecapGraphTextTab"]:UnlockHighlight()
		_G.RecapGraphText:Hide()
		_G.RecapGraphGraph:Show()
	else
		_G["RecapGraphGraphTab"]:UnlockHighlight()
		_G["RecapGraphTextTab"]:LockHighlight()
		_G.RecapGraphGraph:Hide()
		_G.RecapGraphText:Show()
	end
	_G["RecapGraphGraphTab"]:Show()
	_G["RecapGraphTextTab"]:Show()
end

function RecapGraphOptions_OnClick(frame, button)

	RecapGraph_GraphOptionsRefresh()

	if not RecapGraphOptions:IsVisible() then
		RecapGraphOptions:Show()
	else
		RecapGraphOptions:Hide()
	end

	RecapGraph:Hide()
	RecapGraph_SetOptionsPanel()
	RecapGraph:Show()
end

function RecapGraph_CheckUncheckAll(checkValue)

	local i, iOptions

	-- which set of options?
	if rGraph.Statistic == RECAP_DPS_OUT then
		iOptions = rGraph.CombatantsDPSOut
	elseif rGraph.Statistic == RECAP_DPS_IN then
		iOptions = rGraph.CombatantsDPSIn
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		iOptions = rGraph.CombatantsHPSOut
	end

	for i in pairs(iOptions) do
		iOptions[i].Checked = checkValue
		iOptions[i].Featured = false
		iOptions[i].Dimmed = false
	end

	-- redisplay the extension panel
	RecapGraph_GraphOptionsRefresh()
	RecapGraph_GraphUpdate()
end

function RecapGraphCheck_OnClick(frame, button, down)

	local id = frame:GetID()
	local i, iOptions, checkState, thisCombatant, anyoneFeatured

	-- which set of options?
	if rGraph.Statistic == RECAP_DPS_OUT then
		iOptions = rGraph.CombatantsDPSOut
	elseif rGraph.Statistic == RECAP_DPS_IN then
		iOptions = rGraph.CombatantsDPSIn
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		iOptions = rGraph.CombatantsHPSOut
	end

	checkState = _G["RecapGraphCombatantCheck"..id]:GetChecked()
	thisCombatant = _G["RecapGraphCombatantList"..id.."_FullyQualifiedName"]:GetText()
	if thisCombatant and iOptions[thisCombatant] then
		if checkState == 1 then
			iOptions[thisCombatant].Checked = true
			-- assume couldn't have been featured, so keep old dimmed state
		else
			iOptions[thisCombatant].Checked = false
			if iOptions[thisCombatant].Featured then
				-- combatant was featured, make any necessary changes
				iOptions[thisCombatant].Featured = false
				iOptions[thisCombatant].Dimmed = true -- will be cleared later if nobody else is featured
				-- is anyone featured?
				anyoneFeatured = false
				for i in pairs(iOptions) do
					if iOptions[i].Featured then
						anyoneFeatured = true
						break
					end
				end
				-- set the dimmed state
				if not anyoneFeatured then
					-- nobody featured, make sure everyone is not dimmed
					for i in pairs(iOptions) do
						iOptions[i].Dimmed = false
					end
				end
			else
				-- not featured, no change needed, keep old dimmed state
			end
		end
		RecapGraph_GraphUpdate()
	else
		-- ignore since there is no combatant
		PlaySound("igQuestFailed")
		_G["RecapGraphCombatantCheck"..id]:SetChecked(0)
	end

	-- redisplay the extension panel
	RecapGraph_GraphOptionsRefresh()
end

function RecapGraphOpaqueBackground_OnClick(frame, button, down)

	local checkState

	checkState = _G["RecapGraphOpaqueBackground_Check"]:GetChecked()
	if checkState == 1 then
		rGraph.OpaqueBackground = true
	else
		rGraph.OpaqueBackground = false
	end
	RecapGraph_GraphUpdate()

	-- redisplay the extension panel
	RecapGraph_GraphOptionsRefresh()
end

function RecapGraphCombatant_OnClick(frame, button, down)

	local id = frame:GetID()
	local i, iOptions, thisCombatant, checked, featured, anyoneFeatured

	-- which set of options?
	if rGraph.Statistic == RECAP_DPS_OUT then
		iOptions = rGraph.CombatantsDPSOut
	elseif rGraph.Statistic == RECAP_DPS_IN then
		iOptions = rGraph.CombatantsDPSIn
	elseif rGraph.Statistic == RECAP_HPS_OUT then
		iOptions = rGraph.CombatantsHPSOut
	end

	-- now with multiple "featured" support
	thisCombatant = _G["RecapGraphCombatantList"..id.."_FullyQualifiedName"]:GetText()
	if thisCombatant and iOptions[thisCombatant] then
		checked = iOptions[thisCombatant].Checked
		featured = iOptions[thisCombatant].Featured
		if checked then
			if featured then
				-- was featured, turn featured off for this combatant
				iOptions[thisCombatant].Featured = false
				iOptions[thisCombatant].Dimmed = true -- will be cleared later if nobody else is featured
				-- is anyone still featured?
				anyoneFeatured = false
				for i in pairs(iOptions) do
					if iOptions[i].Featured then
						anyoneFeatured = true
						break
					end
				end
				-- if nobody featured, turn off dimmed for everyone
				if not anyoneFeatured then
					for i in pairs(iOptions) do
						iOptions[i].Dimmed = false
					end
				end
			else
				-- is anyone already featured?
				anyoneFeatured = false
				for i in pairs(iOptions) do
					if iOptions[i].Featured then
						anyoneFeatured = true
						break
					end
				end
				-- if nobody is featured yet, dim everyone
				if not anyoneFeatured then
					for i in pairs(iOptions) do
						iOptions[i].Dimmed = true
					end
				end
				-- in either case, turn on featured for this combatant only
				iOptions[thisCombatant].Featured = true
				iOptions[thisCombatant].Dimmed = false
			end
		else
			-- ignore this combatant (alternative would be to turn them on and feature them -- not an obvious choice which would be better)
			PlaySound("igQuestFailed")
		end

		RecapGraph_GraphUpdate()
	end

	-- redisplay the extension panel
	RecapGraph_GraphOptionsRefresh()
end

function RecapGraphListHeader_OnEnter(frame)

	local line1,line2
	local header=string_gsub(frame:GetName(),"RecapGraphListHeader_","GraphHeading")

	line1,line2 = Recap_GetTooltip(header)
	if line1 and line2 then
		Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnGraphPostTooltip)
	end
end

function RecapGraphListHeader_OnClick(frame, button, down)

	local myType = string_gsub(frame:GetName(),"RecapGraphListHeader_","")

	if (not IsShiftKeyDown()) and (not IsAltKeyDown()) and (myType ~= "Name") then
		-- toggle text sorting
		if rGraph.TextSorting == myType then
			-- we were currently sorting dynamically by this method, turn it off
			rGraph.TextSorting = "none"
		else
			-- start sorting dynamically this way
			rGraph.TextSorting = myType
		end
		-- redisplay the text listing with the new sorting
		RecapGraph_GraphUpdate()

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and (rGraph.TextListSize > 1) and (myType ~= "Name") then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rGraph.TextSorting = myType
		RecapGraph_GraphUpdate()
		RecapGraphText_PostSpamRows(myType)
	end
end

function RecapGraphList_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapGraphListScrollBar)

	if (index<rGraph.TextListSize) then
		if rOpt.ShowTooltips.value and rOpt.ShowClickHints.value then
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			rTemp.RecapTooltip:SetText(rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
			rTemp.RecapTooltip:Show()
		end
	end
end

function RecapGraphList_OnClick(frame, button, down)

	local id, index
	local totalLabel, peakLabel, avgLabel

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapGraphListScrollBar)

	if (index < rGraph.TextListSize) then

		if IsShiftKeyDown() and (not IsAltKeyDown()) then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			if rGraph.Statistic == RECAP_DPS_OUT then
				totalLabel = RECAP_TOTAL.." "..RECAP_DMG_OUT
				peakLabel = RECAP_PEAK.." "..RECAP_DPS_OUT
				avgLabel = RECAP_AVG.." "..RECAP_DPS_OUT
			elseif rGraph.Statistic == RECAP_DPS_IN then
				totalLabel = RECAP_TOTAL.." "..RECAP_DAMAGE_IN
				peakLabel = RECAP_PEAK.." "..RECAP_DPS_IN
				avgLabel = RECAP_AVG.." "..RECAP_DPS_IN
			elseif rGraph.Statistic == RECAP_HPS_OUT then
				totalLabel = RECAP_TOTAL.." "..RECAP_HEALS_OUT
				peakLabel = RECAP_PEAK.." "..RECAP_HPS_OUT
				avgLabel = RECAP_AVG.." "..RECAP_HPS_OUT
			end

			Recap_InsertChat(string_format(rLocalize.GraphListVerboseLinkStart,
								"(".. Recap_PetsMergedText()..")",
								_G["RecapGraphList"..id.."_Name"]:GetText(),
								totalLabel,
								_G["RecapGraphList"..id.."_Total"]:GetText(),
								peakLabel,
								_G["RecapGraphList"..id.."_Peak"]:GetText(),
								avgLabel,
								_G["RecapGraphList"..id.."_Avg"]:GetText() ))
		end
	end
end


RecapGraph_lua_4773 = true
