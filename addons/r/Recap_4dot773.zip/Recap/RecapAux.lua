﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ Auxiliary functions, assorted ]]

local bit_band = _G.bit.band
local math_floor = _G.math.floor
local math_max = _G.math.max
local math_min = _G.math.min
local string_find = _G.string.find
local string_format = _G.string.format
local string_gmatch = _G.string.gmatch
local string_gsub = _G.string.gsub
local string_len = _G.string.len
local string_sub = _G.string.sub
local string_lower = _G.string.lower
local string_upper = _G.string.upper
local string_rep = _G.string.rep
local table_insert = _G.table.insert
local table_concat = _G.table.concat
local pairs = _G.pairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ local tables ]]

-- keys for (det)ails
local detkey =	{ ["HitsDmg"]="d", ["Hits"]="n", ["HitsMax"]="x", ["CritsDmg"]="D", ["Crits"]="N",
				  ["CritsMax"]="X", ["CritsEvents"]="e", ["Missed"]="m", ["TicksDmg"]="t", ["TicksMax"]="T", ["Ticks"]="i",
				  ["Dodged"]="G", ["Parried"]="P", ["Blocked"]="B", ["Absorbed"]="A", ["Deflected"]="F",
				  ["Evaded"]="V", ["Resisted"]="R", ["Reflected"]="S", ["Immune"]="I",
				  ["Crushes"]="r", ["CrushDmg"]="s", ["CrushMax"]="u",
				  ["Total"]="v", ["Max"]="w", ["Dispels"]="y", ["PrevTime"]="z", ["ICount"]="a", ["ITotal"]="b", ["DCount"]="c",
				  ["DTotal"]="f", ["PrevTimeDur"]="g", ["GlancesDmg"]="h", ["Glances"]="j", ["GlancesMax"]="k",
				  ["PAbsorbs"]="l", ["PAbsorbsDmg"]="o", ["PBlocks"]="p", ["PBlocksDmg"]="q",
				  ["GlancesMin"]="Q", ["HitsMin"]="U", ["CritsMin"]="W", ["CrushMin"]="Y", ["TicksMin"]="Z",
				  ["EstResistedDmg"]="aa", ["EstResistableDmg"]="bb", ["Steals"]="C", ["SpellID"]="E",
				  ["PResists"]="cc", ["PResistsDmg"]="dd", ["PResistsRaw"]="ee", ["CritTicks"]="ff" }

--[[ local functions (precede first use) ]]

-- this function is called only for player, party, or raid members, and their pets
-- if this is a pet, pass owner's name via ownerUnit
-- caller has already checked that thisCombatant is not nil
local function Recap_AddFriend(thisCombatant, combatantUnit, ownerUnit)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local thisOwner = nil

	if ownerUnit and UnitExists(ownerUnit) then
		thisOwner = Recap_GetUnitNameRealm(ownerUnit)
	end

	if not rOpt.IgnoreGUIDs.value then
		-- using GUIDs (the normal case)
		local g
		if thisOwner then
			g = (UnitGUID(ownerUnit))
			if g then
				thisOwner = thisOwner.."_"..Recap_TrimGUID(g)
			end
		end
	end

	if thisOwner then
		-- creating a pet (force them to be friends, and in group if necessary)
		Recap_CreatePet(thisCombatant, nil, thisOwner, nil, true, 0, false)
	else
		-- creating a combatant that is not a pet
		if not rCombatants[thisCombatant] then
			Recap_CreateBlankCombatant(thisCombatant, 0, nil)
		end
		if not rTemp.Last[thisCombatant] then
			Recap_InitializeLastFight(thisCombatant)
		end
		rCombatants[thisCombatant].Friend = true
		rTemp.InFriend[thisCombatant] = true
		-- remember as part of the group (i.e. a true friend not just a combatant marked as a friend)
		rTemp.InGroup[thisCombatant] = true
	end
end

-- this function could get a gear value from a number of sources
local function Recap_GetGearValue(thisCombatant, unit)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local thisName, thisRealm, gearValue

	-- extra guard
	if not UnitExists(unit) then
		return
	end
	thisName, thisRealm = UnitName(unit)

	if (thisRealm == nil) or (thisRealm == "") then
		thisRealm = rTemp.Server
	end
	if thisName and (thisName ~= "") and (thisName ~= UNKNOWNOBJECT) then
		if  rCombatants[thisCombatant] and rCombatants[thisCombatant].GearValue and (rCombatants[thisCombatant].GearValue > 0) then
			-- already a valid gear value, begin with that
			gearValue = rCombatants[thisCombatant].GearValue
		else
			gearValue = 0 -- default value
		end

		-- TODO: could generalize to other gear value sources

		-- ask GearScore addon for a value
		-- TODO: this is fragile in that GearScore could change its globals, on the other hand it is only a few lines of code
		if GS_Data then
			if GS_Data[thisRealm] and GS_Data[thisRealm].Players and GS_Data[thisRealm].Players[thisName] then
				gearValue = (GS_Data[thisRealm].Players[thisName].GearScore or 0)
			else
				-- GearScore is present, but not for this combatant
				gearValue = 0 -- force zero gear value
			end
		end

		if rCombatants[thisCombatant] then
			rCombatants[thisCombatant].GearValue = math_max((rCombatants[thisCombatant].GearValue or 0), gearValue)
		end
		if rTemp.Last[thisCombatant] then
			rTemp.Last[thisCombatant].GearValue = math_max((rTemp.Last[thisCombatant].GearValue or 0), gearValue)
		end
	end
end

local function Recap_SaveOldOpt(user)

	local rRecap = _G.recap
	local i, j, text

	if user and string_len(user)>0 then
		rRecap[user].Opt = {}
		local oldOpt = rRecap.Opt
		for i in pairs(oldOpt) do
			if oldOpt[i] then
				text = ""
				for j in pairs(oldOpt[i]) do
					text = text..tostring(j).."="..tostring(oldOpt[i][j]).." "
				end
				rRecap[user].Opt[i] = text
			end
		end
	end
end

local function Recap_MakeKey(thisIndex)

	local rTemp = _G.recap_temp
	local i
	local key = 0

	local rKeys = rTemp.Keys
	for i in pairs(rKeys) do
		if thisIndex == rKeys[i] then
			key = i
		end
	end
	return key
end

local function Recap_GetKey(thisIndex)

	local rTemp = _G.recap_temp
	local key = nil -- keep as nil

	local rKeys = rTemp.Keys
	if not thisIndex or not tonumber(thisIndex) or thisIndex==0 then
		key = nil -- keep as nil
	else
		key = rKeys[tonumber(thisIndex)]
	end
	return key
end

local function Recap_LoadSelf()

	local rTemp = _G.recap_temp

	if not _G.recap.Self then
		_G.recap.Self = {}
	end
	if not _G.recap.Self[rTemp.s] then
		_G.recap.Self[rTemp.s] = {}
	end
	-- not at the moment being done for the player's pets

	rTemp.SelfListSize = 1
	rTemp.SelfList = wipe(rTemp.SelfList)
end

local function Recap_StripOwnerAndGUIDsFromCombatant(thisCombatant)
	local found, _, pet
	found, _, pet = string_find(thisCombatant, "^.+:.+:(.+)$")
	if found then
		-- "owner:owner:pet"
		return Recap_NameFromNameGUID(pet)
	else
		found, _, pet = string_find(thisCombatant, "^.+:(.+)$")
		if found then
			-- "owner:pet"
			return Recap_NameFromNameGUID(pet)
		else
			-- "combatant"
			return Recap_NameFromNameGUID(thisCombatant)
		end
	end
end

local function Recap_EstimateSavedCombatantSize(iCombatant)

	local estSize, j, jItem, k

	estSize = 0
	for j, jItem in pairs(iCombatant) do
		-- we already know that this is a table of strings
		if type(jItem) == "string" then
			estSize = estSize + string_len(jItem)
		else
			-- table of table of strings
			for k in pairs(jItem) do
				estSize = estSize + string_len(jItem[k])
			end
		end
	end
	return estSize
end
local function Recap_EstimateSavedDataSetSize(filen)

	local rSet = _G.recap_set
	local estSize, i

	estSize = 0
	if rSet[filen].Combatant then
		local setCombatant = rSet[filen].Combatant
		for i in pairs(setCombatant) do
			-- iterating over combatants
			if (type(setCombatant[i]) == "string") then
				-- everything is in a single string
				estSize = estSize + string_len(setCombatant[i])
			else
				-- multiple strings
				estSize = estSize + Recap_EstimateSavedCombatantSize(setCombatant[i])
			end
		end
	end
	return estSize
end

local function Recap_FindInList(thisCombatant)

	local rTemp = _G.recap_temp
	local i

	for i = 1, (rTemp.ListSize-1) do
		if (rTemp.List[i].Name == thisCombatant) then
			return i
		end
	end

	return nil
end


--[[ global functions ]]

--[[ assorted auxiliary functions ]]

function Recap_Round0(a)
	return math_floor(a + 0.5)
end
function Recap_Round2(a)
	return math_floor(a * 100 + 0.5) / 100
end
function Recap_Div0(a, b)
	return math_floor(a/b + 0.5)
end
function Recap_Round1(a)
	return math_floor(a * 10 + 0.5) / 10
end
function Recap_Div1(a, b)
	return math_floor(a/b * 10 + 0.5) / 10
end
function Recap_Div2(a, b)
	return math_floor(a/b * 100 + 0.5) / 100
end
function Recap_Min(a, b)
	if a and b then
		return math_min(a, b)
	elseif a then
		return a
	else
		return b
	end
end

function Recap_PetsMerged()
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
		if rUser.SyncMergePets == "on" then
			-- synchronization active and merge pets is on
			return true
		end
	else
		if rOpt.MergePets.value then
			-- synchronization not active and merge pets is on
			return true
		end
	end
	return false
end

function Recap_PetsMergedText()
	if Recap_PetsMerged() then
		return rLocalize.MergePetsOn
	else
		return rLocalize.MergePetsOff
	end
	return false
end

-- do our own error display since WoW 2.1 will have lua error display off by default
function Recap_TrapError(message, frame)

	local rTemp = _G.recap_temp

	-- lock OnError events
	if rTemp.OnError == true then return end

	if string_find(message, "Recap", 1, true) then
		-- this is an error with the string "Recap" in it, pretend it is ours
		-- I currently figure that a console message is about the right amount of user annoyance for a Recap error (to get them to report it without unduly inconveniencing them)
		print("Please report the following error to Hawksy at the curse.com site:") -- TODO not localized and contains an author name
		print(message)
		PlaySound("igQuestFailed")
		if rTemp.snap or Recap_IsRecapAuthor() then
			Screenshot()
		end
	end

	-- unlock OnError events
	rTemp.OnError = false

	-- pass it on to the original error handler (will only show if Display Lua Errors is enabled)
	if rTemp.Original_ErrorHandler and (rTemp.Original_ErrorHandler ~= true) then
		return rTemp.Original_ErrorHandler(message, frame)
	end
end

-- dump combat events to WoWChatLog.txt
function Recap_DumpMessage(printable)
	local rRecap = _G.recap
	local rTemp = _G.recap_temp
	if rTemp.LogChatnum then
		-- have a log channel, WoWChatLog should be open
		-- include a line count so that we can detect if any lines get dropped
		rRecap.dumplines = (rRecap.dumplines or 0) + 1
		SendChatMessage(tostring(rRecap.dumplines)..", "..printable, "CHANNEL", nil, rTemp.LogChatnum) -- let Blizz truncate the line as necessary
	else
		-- TODO: this puppy is not localized
		rRecap.dump = false
		print("WoWChatLog.txt file is not open.  Please open it on the Options / Reports tab.  Recap dump has been turned OFF.")
	end
end


-- is this the player (or pet)?
function Recap_CheckForSelf(combatant)

	local rTemp = _G.recap_temp
	local okayToShow = false

	if combatant == rTemp.PlayerGUID then
		-- player
		okayToShow = true
	else
		if Recap_IsOwnedBy(combatant, rTemp.PlayerGUID) then
			-- is or was controlled by player
			okayToShow = true
		end
	end

	return okayToShow
end


--[[ Misc functions ]]

function Recap_IsRecapAuthor()
	local rTemp = _G.recap_temp
	-- if someone else takes over development, you might want to update this code for your own toons
	if (rTemp.p == "Hawksy_Elune") or (rTemp.p == "Galassa_Elune") or (rTemp.p == "Metrognome_Elune") then
		return true
	else
		return false
	end
end

-- creates a new .Combatant[thisCombatant]
function Recap_CreateBlankCombatant(thisCombatant, seen, flags)

-- a number of fields have been commented out to save space for combatants who don't use them -- they will be created as needed by other code
-- TotalTime, TotalTimeIn, TotalTimeHeal, TotalDmgIn, TotalDmgOut, TotalDPS, TotalDPSIn, TotalHPS, TotalMaxHit, TotalDeaths, TotalRawHeal, TotalOverHeal
-- Seen, Trash, Locked, Ignore, OwnedBy, Class, Faction, Level
-- Controlled (flags whether Blizzard flags said this combatant was controlled as a pet while also OwnedBy)
-- OutgoingDetail, TargetDetail, IncomingDetail, SourceDetail, OtherDetail

-- we have two sets of Last Fight numbers, and we swap between them at the end of any 'significant' fight (avoids extra copying)
-- the 'hard coded' 1 and 2 are less pure but match the hierarchical structure of OutgoingDetail etc. for easier parallel coding elsewhere
-- LastTime_1, LastTimeIn_1, LastTimeHeal_1, LastMaxHit_1, LastDmgIn_1, LastDmgOut_1, LastHPS_1, LastDPSIn_1, LastDPS_1, LastDeaths_1, LastRawHeal_1, LastOverHeal_1
-- LastOutgoingDetail_1, LastTargetDetail_1, LastIncomingDetail_1, LastSourceDetail_1, LastOtherDetail_1
-- LastTime_2, LastTimeIn_2, LastTimeHeal_2, LastMaxHit_2, LastDmgIn_2, LastDmgOut_2, LastHPS_2, LastDPSIn_2, LastDPS_2, LastDeaths_2, LastRawHeal_2, LastOverHeal_2
-- LastOutgoingDetail_2, LastTargetDetail_2, LastIncomingDetail_2, LastSourceDetail_2, LastOtherDetail_2

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	if not rCombatants[thisCombatant] then
		rCombatants[thisCombatant] = { WasInLast = false, WasInCurrent = false, Friend = false }
	end

	if seen and seen>0 then
		rCombatants[thisCombatant].Seen = seen
	end

	if flags and flags>0 then
		rCombatants[thisCombatant].Flags = flags
	end

	if not rTemp.Last[thisCombatant] then
		Recap_InitializeLastFight(thisCombatant)
	end
end

-- note that the following function is called every half second during combat (gear value is collected less often)
function Recap_MakeFriends(getGearValue)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local oldInGroup
	local i, j, thisCombatant

	-- take a copy of the current group members
	oldInGroup = {}
	for i in pairs(rTemp.InGroup) do
		oldInGroup[i] = true
	end

	-- clear list of group members
	rTemp.InGroup = wipe(rTemp.InGroup)

	-- the following strict ordering is probably not necessary with patch 2.4 if always using GUIDs

	-- to avoid anomalies when players have the same names as pets, do pets first, then players
	-- what then happens is that NAME is marked as a pet (by Recap_AddFriend), then re-marked as a player (by Recap_AddFriend)
	if UnitExists("pet") then
		thisCombatant = Recap_GetUnitInfo("pet")
		if thisCombatant then
			Recap_AddFriend(thisCombatant, "pet", "player")
			-- no gear for pets
		end
	end

	-- create blank entries for group pets if we are in sync, or if we are including group, or if we are storing everyone
	if (not rOpt.HideGroup.value) or (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") or (not rOpt.StoreOnlyDisplayed.value) then
		for i=1,4 do
			j = "partypet"..i
			if UnitExists(j) then
				thisCombatant = Recap_GetUnitInfo(j)
				if thisCombatant then
					Recap_AddFriend(thisCombatant, j, "party"..i)
					-- no gear for pets
				end
			end
		end
		if IsInRaid() then -- updated for 5.04
			for i=1,40 do
				j = "raidpet"..i
				if UnitExists(j) then
					thisCombatant = Recap_GetUnitInfo(j)
					if thisCombatant then
						Recap_AddFriend(thisCombatant, j, "raid"..i)
						-- no gear for pets
					end
				end
			end
		end
	end

	-- now do players (player with same name as pet might overwrite the pet designation) (should be rare or non-existent with patch 2.4)
	thisCombatant = Recap_GetUnitInfo("player")
	if thisCombatant then
		j = "player"
		Recap_AddFriend(thisCombatant, j, nil)
		if getGearValue then
			Recap_GetGearValue(thisCombatant, j)
		end
	end

	-- create blank entries for group members if we are in sync, or if we are including group, or if we are storing everyone
	if (not rOpt.HideGroup.value) or (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") or (not rOpt.StoreOnlyDisplayed.value) then
		for i=1,4 do
			j = "party"..i
			if UnitExists(j) then
				thisCombatant = Recap_GetUnitInfo(j)
				if thisCombatant then
					Recap_AddFriend(thisCombatant, j, nil)
					if getGearValue then
						Recap_GetGearValue(thisCombatant, j)
					end
				end
				-- get information on this group member's current target (to get class and level for most enemy mobs)
				j = j.."target"
				if UnitExists(j) then
					Recap_GetUnitInfo(j)
				end
			end
		end
		if IsInRaid() then -- updated for 5.04
			for i=1,40 do
				j = "raid"..i
				if UnitExists(j) then
					thisCombatant = Recap_GetUnitInfo(j)
					if thisCombatant then
						Recap_AddFriend(thisCombatant, j, nil)
						if getGearValue then
							Recap_GetGearValue(thisCombatant, j)
						end
					end
					-- get information on this group member's current target (to get class and level for most enemy mobs)
					j = j.."target"
					if UnitExists(j) then
						Recap_GetUnitInfo(j)
					end
				end
			end
		end
	end

	-- remove new members from old list
	for i in pairs(rTemp.InGroup) do
		if oldInGroup[i] then
			oldInGroup[i] = nil
		end
	end

	-- check remaining old members to see if they are pets of group members, and if so, add them
	-- loop until nothing changes
	local changed = true
	while changed do
		changed = false
		for i in pairs(oldInGroup) do
			if rCombatants[i] then
				if rCombatants[i].OwnedBy and rTemp.InGroup[rCombatants[i].OwnedBy] then
					rTemp.InGroup[i] = true
					oldInGroup[i] = nil
					changed = true
					break
				end
				local rootOwner = Recap_RootOwner(i)
				if rootOwner and (rootOwner ~= i) and rTemp.InGroup[rootOwner] then
					rTemp.InGroup[i] = true
					oldInGroup[i] = nil
					changed = true
					break
				end
			end
		end
	end
end

-- if petFlags is nil this is called from MakeFriends
-- if petFlags is not nil this is called from SummonOrCreate (which does not include Mind Control)
function Recap_CreatePet(petNameGUID, petFlags, ownerNameGUID, ownerFlags, forceFriend, seen, DKRaiseDead)

	local rSelf = _G.recap.Self
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local ownerPetNameGUID

	-- if not already a Combatant, add an entry for the pet
	if not rCombatants[petNameGUID] then
		Recap_CreateBlankCombatant(petNameGUID, seen, petFlags)
	end
	if not rTemp.Last[petNameGUID] then
		Recap_InitializeLastFight(petNameGUID)
	end

	-- pet could potentially do damage without owner, so add owner if not already present
	if not rCombatants[ownerNameGUID] then
		Recap_CreateBlankCombatant(ownerNameGUID, seen, ownerFlags)
	end
	if not rTemp.Last[ownerNameGUID] then
		Recap_InitializeLastFight(ownerNameGUID)
	end
	if forceFriend then
		rCombatants[ownerNameGUID].Friend = true
		rTemp.InFriend[ownerNameGUID] = true
	end
	-- if the owner is a friend, then the pet is too
	if forceFriend or rCombatants[ownerNameGUID].Friend then
		rCombatants[petNameGUID].Friend = true
		rTemp.InFriend[petNameGUID] = true
	end
	-- if the owner is in group, then the pet is too
	if rTemp.InGroup[ownerNameGUID] then
		rTemp.InGroup[petNameGUID] = true
	end

	-- set the pet to point to its new (and current) owner
	-- this unqualified pet combatant will probably not track anything
	rCombatants[petNameGUID].OwnedBy = ownerNameGUID

	-- create the fully qualified pet name which is "owner:pet"
	-- this is the combatant for which Recap will actually track damage and healing
	ownerPetNameGUID = ownerNameGUID..":"..petNameGUID
	if not rCombatants[ownerPetNameGUID] then
		Recap_CreateBlankCombatant(ownerPetNameGUID, seen, petFlags)
	end
	if not rTemp.Last[ownerPetNameGUID] then
		Recap_InitializeLastFight(ownerPetNameGUID)
	end
	-- if the owner is a friend, then the fully qualified pet name is too
	if forceFriend or rCombatants[ownerNameGUID].Friend then
		rCombatants[ownerPetNameGUID].Friend = true
		rTemp.InFriend[ownerPetNameGUID] = true
	end
	-- if the owner is in group, then the fully qualified pet name is too
	if rTemp.InGroup[ownerNameGUID] then
		rTemp.InGroup[ownerPetNameGUID] = true
	end
	-- if the owner is a death knight and got this pet using Raise Dead, mark the pet specially (multi-named pets will be amalgamated into one)
	if DKRaiseDead then
		rCombatants[ownerPetNameGUID].DKRaiseDead = true
	end

	-- BLAH EXPERIMENTAL set the owned pet also to point to its new (and current) owner
	-- BLAH could be good, could be HUGE mistake, can't tell
	rCombatants[ownerPetNameGUID].OwnedBy = ownerNameGUID

	-- we do not currently keep a list of the owner's pets

	-- TODO: we had some code in here to try to improve assignment of 'pets' and mind-control victims to owners, but it didn't seem to help with the few glitches
	--		 if needed again, go to version 4.10 to retrieve it
	-- With 4.20 and later we are still getting occasional orphan pets, usually for only a few hits before they are recognized and turn into owned pets

	-- if the pet belongs to player, ensure that Self is set up for this pet (not qualified by GUID -- all Self info will amalgamate by name, ignoring GUID)
	if ownerNameGUID == rTemp.PlayerGUID then
		local petIndex
		if Recap_PetsMerged() and rOpt.MergeAllPetsIntoOne.value then
			-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
			petIndex = rTemp.s..":"..rLocalize.ClassName.Pet
		else
			if Recap_PetsMerged() and DKRaiseDead then
				-- death knight special pet name ("Ghoul Minion" or localized equivalent) (only if pets are merged)
				petIndex = rTemp.s..":"..rLocalize.GhoulMinion
			else
				-- normal pet name
				petIndex = rTemp.s..":"..Recap_NameOnlyFromCombatant(petNameGUID)
			end
		end
		if not rSelf[petIndex] then
			-- note this can create empty pets if there turn out to be no data
			rSelf[petIndex] = {}
		end
	end
end

function Recap_InitializeLastFight(thisCombatant)
	local rTemp = _G.recap_temp
	rTemp.Last[thisCombatant] = { StartOut = 0, EndOut = 0, StartIn = 0, EndIn = 0, StartHeal = 0, EndHeal = 0, DmgIn = 0, DmgOut = 0, PetsDmgOut = 0, MaxHit = 0, Deaths = 0, RawHeal = 0, OverHeal = 0, Dispels = 0, Interrupts = 0 }
end

-- returns a string of seconds converted to 0:00:00 format
function Recap_FormatTime(rawTime)

	local hours, minutes, seconds

	seconds = Recap_Round0(rawTime)
	hours = math_floor(seconds/3600)
	seconds = seconds - hours*3600
	minutes = math_floor(seconds/60)
	seconds = seconds - minutes*60

	return ((hours>0) and (hours..":") or "") .. string_format("%02d:",minutes) .. string_format("%02d",seconds)
end

-- returns a string of seconds converted to 00:00:00.0 format (nearest tenth of a second)
function Recap_FormatTimeRecent(rawTime)

	local days, hours, minutes, seconds, deciseconds

	seconds = math_floor(rawTime)
	deciseconds = Recap_Round0(10 * (rawTime - seconds))
	if deciseconds == 10 then
		seconds = seconds + 1
		deciseconds = 0
	end
	hours = math_floor(seconds/3600)
	seconds = seconds - hours*3600
	minutes = math_floor(seconds/60)
	seconds = seconds - minutes*60

	days = math_floor(hours/24)
	hours = hours - days*24

	return string_format("%02d:",hours) .. string_format("%02d:",minutes) .. string_format("%02d",seconds) .. string_format(".%01d",deciseconds)
end

-- returns a string of seconds converted to 00:00:00 format
function Recap_FormatTimeSeen(rawTime)

	local days, hours, minutes, seconds, deciseconds

	seconds = math_floor(rawTime)
	deciseconds = Recap_Round0(10 * (rawTime - seconds))
	if deciseconds == 10 then
		seconds = seconds + 1
		deciseconds = 0
	end
	hours = math_floor(seconds/3600)
	seconds = seconds - hours*3600
	minutes = math_floor(seconds/60)
	seconds = seconds - minutes*60

	days = math_floor(hours/24)
	hours = hours - days*24

	return string_format("%02d:",hours) .. string_format("%02d:",minutes) .. string_format("%02d",seconds)
end

-- returns a string of seconds converted to 000 format (nearest second)
function Recap_FormatTimeSeconds(rawTime)
	return string_format("%d",Recap_Round0(rawTime))
end

-- returns a string of seconds converted to 000.0 format (nearest tenth of a second)
function Recap_FormatTimeSecondsTenths(rawTime)

	local seconds, deciseconds

	seconds = math_floor(rawTime)
	deciseconds = Recap_Round0(10 * (rawTime - seconds))
	if deciseconds == 10 then
		seconds = seconds + 1
		deciseconds = 0
	end

	return string_format("%d",seconds) .. string_format(".%01d",deciseconds)
end

-- returns a formatted string for type stat ("DPS" "Time" etc) for combatant (listCombatant is a pointer to either recap_temp.List[i] or recap_temp.LoadList[i]; or could be nil)
-- the first one returns a name and the first stat
-- we push our luck by reducing all widths of 8 to 7, and all widths of 6 to 5, and so on
function Recap_FormatNameFirstStat(iName, myType, listCombatant)

	if listCombatant then
		local iType = string_gsub(myType,"P$","")
		if iType=="DPS" then
			return Recap_FormatNameInteger(iName, listCombatant.DPS, 5, "")
		elseif iType=="DPSPerGear" then
			return Recap_FormatNameInteger(iName, listCombatant.DPSPerGear, 5, "")
		elseif iType=="DPSIn" then
			return Recap_FormatNameInteger(iName, listCombatant.DPSIn, 5, "")
		elseif iType=="HPS" then
			return Recap_FormatNameInteger(iName, listCombatant.HPS, 5, "")
		elseif iType=="DPSvsAll" then
			return Recap_FormatNameInteger(iName, listCombatant.DPSvsAll, 5, "")
		elseif iType=="Time" then
			return Recap_FormatNameTime(iName, listCombatant.Time)
		elseif iType=="TimeIn" then
			return Recap_FormatNameTime(iName, listCombatant.TimeIn)
		elseif iType=="TimeHeal" then
			return Recap_FormatNameTime(iName, listCombatant.TimeHeal)
		elseif iType=="DmgOut" then
			return Recap_FormatNameInteger(iName, listCombatant.DmgOut, 7, "")
		elseif iType=="DmgIn" then
			return Recap_FormatNameInteger(iName, listCombatant.DmgIn, 7, "")
		elseif iType=="Heal" then
			return Recap_FormatNameInteger(iName, listCombatant.Heal, 7, "")
		elseif iType=="Over" then
			return Recap_FormatNameInteger(iName, listCombatant.Over, 4, "%>")
		elseif iType=="Seen" then
			return Recap_FormatNameSeen(iName, (listCombatant.Seen or tonumber(0))/1000)
		-- following three are from GraphList
		elseif iType=="Total" then
			return Recap_FormatNameInteger(iName, listCombatant.Total, 7, "")
		elseif iType=="Peak" then
			return Recap_FormatNameInteger(iName, listCombatant.Peak, 5, "")
		elseif iType=="Avg" then
			return Recap_FormatNameInteger(iName, listCombatant.Avg, 5, "")
		else
			return Recap_FormatNameText(iName, listCombatant[iType])
		end
	end

	return ""
end
-- the second one returns the remaining stats (if any)
function Recap_FormatRemainingStats(myType, listCombatant)

	if listCombatant then
		local rOpt = _G.recap_temp.Opt
		local iType = string_gsub(myType,"P$","")
		local iSpace = "   "
		if rOpt.PostInColumns.value == false then
			iSpace = ""
		end
		if iType=="DPS" then
			return iSpace..Recap_FormatInteger(listCombatant.DmgOut, 7, "")..iSpace..Recap_FormatInteger(listCombatant.DmgOutP, 3, "%")
		elseif iType=="DPSPerGear" then
			return iSpace.."  ("..Recap_Round0(listCombatant.DPS).."/"..Recap_Round0(listCombatant.GearValue)..")"
		elseif iType=="DPSIn" then
			return iSpace..Recap_FormatInteger(listCombatant.DmgIn, 7, "")..iSpace..Recap_FormatInteger(listCombatant.DmgInP, 3, "%")
		elseif iType=="HPS" then
			return iSpace..Recap_FormatInteger(listCombatant.Heal, 7, "")..iSpace..Recap_FormatInteger(listCombatant.HealP, 3, "%")..iSpace..Recap_FormatInteger(listCombatant.Over, 4, "%>")
		elseif iType=="DmgOut" then
			return iSpace..Recap_FormatInteger(listCombatant.DmgOutP, 3, "%")..iSpace..Recap_FormatInteger(listCombatant.DPS, 5, "")
		elseif iType=="DmgIn" then
			return iSpace..Recap_FormatInteger(listCombatant.DmgInP, 3, "%")..iSpace..Recap_FormatInteger(listCombatant.DPSIn, 5, "")
		elseif iType=="Heal" then
			return iSpace..Recap_FormatInteger(listCombatant.HealP, 3, "%")..iSpace..Recap_FormatInteger(listCombatant.HPS, 5, "")..iSpace..Recap_FormatInteger(listCombatant.Over, 4, "%>")
		else
			return ""
		end
	end

	return ""
end

-- format numbers for leader change
local function Recap_FormatStat(myType, listCombatant)

	local iType = string_gsub(myType,"P$","")

	if iType=="DPS" then
		return string_format("%d",Recap_Round0(listCombatant.DPS))
	elseif iType=="DmgOut" then
		return listCombatant.DmgOut.." ("..listCombatant.DmgOutP.."%)"
	elseif iType=="DmgIn" then
		return listCombatant.DmgIn.." ("..listCombatant.DmgInP.."%)"
	elseif iType=="Heal" then
		return listCombatant.Heal.." ("..listCombatant.HealP.."%)".." ("..listCombatant.Over.."%>)"
	else
		return ""
	end
end

-- maximum length of player name is 12 chars
function Recap_FormatNameInteger(iName, iNumber, iLength, iSuffix)
	local rOpt = _G.recap_temp.Opt
	RecapInvisibleText:SetText(string_rep(" ", 50))
	local spacePixels = RecapInvisibleText:GetStringWidth() / 50
	RecapInvisibleText:SetText("99. Momomomomomo"..string_rep("9", iLength))
	local maxNameIntegerPixels = RecapInvisibleText:GetStringWidth()
	local formattedNumber = Recap_Round0(iNumber)
	RecapInvisibleText:SetText(iName..formattedNumber)
	local iNameIntegerPixels = RecapInvisibleText:GetStringWidth()
	local spacesNeeded = Recap_Div0(math_max((maxNameIntegerPixels - iNameIntegerPixels), 0), spacePixels)
	if rOpt.PostInColumns.value == false then
		spacesNeeded = 1
	end
	return iName..":"..string_rep(" ", spacesNeeded)..formattedNumber..iSuffix
end

function Recap_FormatNameTime(iName, iTime)
	local rOpt = _G.recap_temp.Opt
	RecapInvisibleText:SetText(string_rep(" ", 50))
	local spacePixels = RecapInvisibleText:GetStringWidth() / 50
	RecapInvisibleText:SetText("99. Momomomomomo".."9:99:99")
	local maxNameTimePixels = RecapInvisibleText:GetStringWidth()
	local formattedTime = Recap_FormatTime(iTime)
	RecapInvisibleText:SetText(iName..formattedTime)
	local iNameTimePixels = RecapInvisibleText:GetStringWidth()
	local spacesNeeded = Recap_Div0(math_max((maxNameTimePixels - iNameTimePixels), 0), spacePixels)
	if rOpt.PostInColumns.value == false then
		spacesNeeded = 1
	end
	return iName..":"..string_rep(" ", spacesNeeded)..formattedTime
end

function Recap_FormatNameSeen(iName, iSeen)
	local rOpt = _G.recap_temp.Opt
	RecapInvisibleText:SetText(string_rep(" ", 50))
	local spacePixels = RecapInvisibleText:GetStringWidth() / 50
	RecapInvisibleText:SetText("99. Momomomomomo".."99:99:99")
	local maxNameSeenPixels = RecapInvisibleText:GetStringWidth()
	local formattedSeen = Recap_FormatTimeSeen(iSeen)
	RecapInvisibleText:SetText(iName..formattedSeen)
	local iNameSeenPixels = RecapInvisibleText:GetStringWidth()
	local spacesNeeded = Recap_Div0(math_max((maxNameSeenPixels - iNameSeenPixels), 0), spacePixels)
	if rOpt.PostInColumns.value == false then
		spacesNeeded = 1
	end
	return iName..":"..string_rep(" ", spacesNeeded)..formattedSeen
end

function Recap_FormatNameText(iName, iText)
	local rOpt = _G.recap_temp.Opt
	RecapInvisibleText:SetText(string_rep(" ", 50))
	local spacePixels = RecapInvisibleText:GetStringWidth() / 50
	RecapInvisibleText:SetText("99. Momomomomomo")
	local maxNamePixels = RecapInvisibleText:GetStringWidth()
	RecapInvisibleText:SetText(iName)
	local iNamePixels = RecapInvisibleText:GetStringWidth()
	local spacesNeeded = Recap_Div0(math_max((maxNamePixels - iNamePixels), 0), spacePixels)
	if rOpt.PostInColumns.value == false then
		spacesNeeded = 1
	end
	return iName..":"..string_rep(" ", spacesNeeded)..iText
end

function Recap_FormatInteger(iNumber, iLength, iSuffix)
	local rOpt = _G.recap_temp.Opt
	RecapInvisibleText:SetText(string_rep(" ", 50))
	local spacePixels = RecapInvisibleText:GetStringWidth() / 50
	RecapInvisibleText:SetText(string_rep("9", iLength))
	local maxNumberPixels = RecapInvisibleText:GetStringWidth()
	local formattedNumber = Recap_Round0(iNumber)
	RecapInvisibleText:SetText(formattedNumber)
	local iNumberPixels = RecapInvisibleText:GetStringWidth()
	local spacesNeeded = Recap_Div0(math_max((maxNumberPixels - iNumberPixels), 0), spacePixels)
	if rOpt.PostInColumns.value == false then
		spacesNeeded = 1
	end
	return string_rep(" ", spacesNeeded)..formattedNumber..iSuffix
end

function Recap_SetClassIcon(id,class)

	local rTemp = _G.recap_temp
	local item

	item = _G["RecapList"..id.."_Class"]
	if class and rTemp.ClassIcons[class] then
		item:SetTexCoord(rTemp.ClassIcons[class].left,rTemp.ClassIcons[class].right,rTemp.ClassIcons[class].top,rTemp.ClassIcons[class].bottom)
	else
		item:SetTexCoord(.9,1,.9,1)
	end
end

function Recap_SetFactionIcon(id,faction)

	local rTemp = _G.recap_temp
	local item

	item = _G["RecapList"..id.."_Faction"]
	if faction and rTemp.FactionIcons[faction] then
		item:SetTexture(rTemp.FactionIcons[faction])
	else
		item:SetTexture("")
	end
end

function Recap_SetRecapFrameBackdrop()
	local rUser = _G.recap_user
	if RecapFrame then
		local rOpt = _G.recap_temp.Opt
		if rUser.Minimized then
			if rOpt.MinBack.value then
				RecapFrame:SetBackdropColor(1,1,1,1)
				RecapFrame:SetBackdropBorderColor(.5,.5,.5,1)
			else
				RecapFrame:SetBackdropColor(0,0,0,0)
				RecapFrame:SetBackdropBorderColor(0,0,0,0)
			end
		else
			if rOpt.OpaqueBackground.value then
				-- took quite a while to find an actual solid black background file
				RecapFrame:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
										tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			else
				RecapFrame:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
										tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			end
		end
		if rOpt.OpaqueBackground.value then
			-- took quite a while to find an actual solid black background file
			RecapOptFrame:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapClipFrame:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapPanel:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapRecent:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapGraph:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
		else
			RecapOptFrame:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapClipFrame:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapPanel:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapRecent:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
			RecapGraph:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
									tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
		end
	end
end

function Recap_GetInstanceDifficulty()
	local rTemp = _G.recap_temp
	local _, kind, difficulty, maxPlayers

	_, kind, difficulty, _, maxPlayers = GetInstanceInfo()

	if (kind == "none") then
		return 0
	elseif (kind == "pvp") then
		return 11
	elseif (kind == "arena") then
		return 12
	elseif (kind == "scenario") then
		return 13
	elseif (kind == "party") or (kind == "raid") then
		if (maxPlayers == 20) then
			return 10
		elseif (maxPlayers == 5) or (maxPlayers == 10) or (maxPlayers == 25) or (maxPlayers == 40) then
			return difficulty
		end
	end

	return 15 -- call it "Other"
end

-- not that as well as player, party, raid, and pet, the argument 'unit' could also be "target" or "mouseover"
-- we now also call for the target of every member of the party or raid (but not for targets of their pets)
function Recap_GetUnitInfo(unit)

	local rCombatants = _G.recap_combatants

	-- extra guard
	if not UnitExists(unit) then
		return nil
	end

	-- put them in a single statement to minimize conflicting answers (not sure this is needed)
	-- the second value from Unit Class returns a standard all-caps English class (2009-December-03 some addon is breaking UnitClass, returning the wrong answer sometimes in Faction Champions)
	local thisName, thisGUID, thisClass, thisFaction, thisLevel, thisMaxHealth, thisMaxPower, thisPowerType, thisCreatureFamily =
		Recap_GetUnitNameRealm(unit), UnitGUID(unit), select(2, UnitClass(unit)), select(2, UnitFactionGroup(unit)), UnitLevel(unit), UnitHealthMax(unit), UnitPowerMax(unit), UnitPowerType(unit), UnitCreatureFamily(unit)

	if thisName then

		local rOpt = _G.recap_temp.Opt
		local rTemp = _G.recap_temp

		if not rOpt.IgnoreGUIDs.value then
			-- using GUIDs (the normal case)
			if thisGUID then
				thisName = thisName.."_"..Recap_TrimGUID(thisGUID)
			end
		end

		local iCombatant = rCombatants[thisName]

		if iCombatant then

			-- note that Recap will not pick up this information unless the combatant has been moused over,
			--   or targeted, by someone in the group (so that they become one of the "unit" types), PLUS
			--   they have become a combatant

			-- correction of bad class values returned by UnitClass for the NPCs in the Faction Champions fight
			local unitType = tonumber(string_sub(thisGUID, 5, 5), 16) % 8
			if (unitType == 3) then
				local npcID = tonumber(string_sub(thisGUID, 9, 12), 16) -- note that this appears to be the old location (the advertised change with patch 3.3 presumably did not take place)
				local correctedClass = rTemp.FacChampsClass[npcID]
				if correctedClass then
					thisClass = correctedClass
				end
			end
			-- end of correction

			iCombatant.Class = thisClass

			iCombatant.Faction = thisFaction
			if thisCreatureFamily and iCombatant.Faction then
				iCombatant.Class = "Pet"
			end
			iCombatant.Level = tonumber(thisLevel)

			-- check if this is a boss, and if so update the maximum instance difficulty (but only if in an instance)
			if iCombatant.Level and (tonumber(iCombatant.Level) == -1) and IsInInstance() then
				rTemp.InstanceDifficulty = Recap_GetInstanceDifficulty()
			end

			-- If we already have this unit for any reason, see if we can get health and power
			-- remember min and max of health (will be displayed in tooltip)
			if thisMaxHealth then
				thisMaxHealth = tonumber(thisMaxHealth)
				if iCombatant.MinMaxHealth then
					iCombatant.MinMaxHealth = math_min(iCombatant.MinMaxHealth, thisMaxHealth)
				else
					iCombatant.MinMaxHealth = thisMaxHealth
				end
				if iCombatant.MaxMaxHealth then
					iCombatant.MaxMaxHealth = math_max(iCombatant.MaxMaxHealth, thisMaxHealth)
				else
					iCombatant.MaxMaxHealth = thisMaxHealth
				end
			end
			-- similarly for power (i.e. mana, rage, energy)
			if thisMaxPower then
				thisMaxPower = tonumber(thisMaxPower)
				if iCombatant.MinMaxPower then
					iCombatant.MinMaxPower = math_min(iCombatant.MinMaxPower, thisMaxPower)
				else
					iCombatant.MinMaxPower = thisMaxPower
				end
				if iCombatant.MaxMaxPower then
					iCombatant.MaxMaxPower = math_max(iCombatant.MaxMaxPower, thisMaxPower)
				else
					iCombatant.MaxMaxPower = thisMaxPower
				end
				-- remember what kind of power it is
				if thisPowerType then
					iCombatant.PowerType = tonumber(thisPowerType)
				end
			end
		end

		if (unit ~= "mouseover") and (not string_find(unit, "target", 1, true)) then

			-- create the 'recap_temp.Last' table for this unit (used to be so we could calculate overhealing on the fly)
			--   The code will add party members or raid members, who would normally soon become combatants anyway.  We're just doing it a bit early.
			--   See also the call to Recap_MakeFriends in Recap_StartFight.
			if not iCombatant then
				Recap_CreateBlankCombatant(thisName, 0, nil)
			end
			if not rTemp.Last[thisName] then
				Recap_InitializeLastFight(thisName)
			end
			-- if this is a new group member, we won't get health and power and so on till the next call to this function
		end

		-- and return this Combatant's name+guid
		return thisName
	else
		return nil
	end
end

function Recap_GetUnitNameRealm(unit)

	local rTemp = _G.recap_temp
	local thisName, thisRealm

	-- extra guard
	if not UnitExists(unit) then
		return nil
	end
	thisName, thisRealm = UnitName(unit)

	if thisName and (thisName ~= "") and (thisName ~= UNKNOWNOBJECT) then
		if thisRealm and (thisRealm ~= "") and (thisRealm ~= rTemp.Server) then
			-- if combatant is from a different realm, append the realm name the way Blizzard does
			thisName = thisName.."-"..thisRealm
		end
		return thisName
	end
	return nil
end

-- Saves current data to data set "filen"
-- TODO: optimization measurements 2009-February-21
--		 replacing all combatant names with abbreviations would save approximately 11-12% (measured) of the Data Set length for large data sets
--		 replacing all effect names, approximately 10-11% (measured)
--		 element names a smaller amount, plus the word "Total" could be abbreviated, for a combined effect of approximately 3% (measured)
--		 those together might save about 20-25% net (need tables to store the strings and their abbreviations)
--		 I'm not sure it's worth the cost (programming effort, execution time, file opacity)
--		 savings would be somewhat higher for e.g. German which has longer combatant names and effect names
function Recap_SaveCombatantsBasic(setname, lastfightonly)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local iLast = rTemp.DisplayLastFight
	local target
	local i, iCombatant, setCombatant

	target = rSet[setname]

	-- Windows lua code does not support %e
	target.TimeStamp = date("%Y-%m-%d %H:%M %a")
	-- version when this file was saved, to support future data conversion
	target.SavedAtVersion = Recap_Version
	if not lastfightonly then
		target.TotalDuration = rUser.TotalDuration
		target.TotalDurationIn = rUser.TotalDurationIn
		target.TotalDurationHeal = rUser.TotalDurationHeal
	else
		target.TotalDuration = rUser.LastDuration
		target.TotalDurationIn = rUser.LastDurationIn
		target.TotalDurationHeal = rUser.LastDurationHeal
	end
	target.MergePets = Recap_PetsMerged() -- not 100% reliable if the user changed the setting after the data was collected
	target.IgnoreGUIDs = rOpt.IgnoreGUIDs.value -- not 100% reliable if the user changed the setting after the data was collected
	target.Combatant = {}

	local AllLastOutgoingDetail = "OutgoingDetail"
	local AllLastIncomingDetail = "IncomingDetail"
	local AllLastOtherDetail = "OtherDetail"
	local AllLastTargetDetail = "TargetDetail"
	local AllLastSourceDetail = "SourceDetail"
	if lastfightonly then
		-- we save from the displayed Last Fight details (not from the details being actively accumulated)
		AllLastOutgoingDetail = "LastOutgoingDetail_"..iLast
		AllLastIncomingDetail = "LastIncomingDetail_"..iLast
		AllLastOtherDetail = "LastOtherDetail_"..iLast
		AllLastTargetDetail = "LastTargetDetail_"..iLast
		AllLastSourceDetail = "LastSourceDetail_"..iLast
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) and
		   (not lastfightonly or iCombatant.WasInLast) then

			setCombatant = target.Combatant

			-- the value of Seen is too large for %u
			local highSeen, lowSeen
			lowSeen = (iCombatant.Seen or 0)
			highSeen = math_floor(lowSeen / 2147483648)
			lowSeen = lowSeen - highSeen * 2147483648

			-- the value of Flags is too large for %u
			local highFlags, lowFlags
			lowFlags = (iCombatant.Flags or 0)
			highFlags = math_floor(lowFlags / 2147483648)
			lowFlags = lowFlags - highFlags * 2147483648

			if not lastfightonly then
				-- we exclude 'combatants' with no real data (at the moment, dispels and interrupts don't count)
				if ((iCombatant.TotalDmgIn == nil) or (iCombatant.TotalDmgIn == 0)) and
				   ((iCombatant.TotalDmgOut == nil) or (iCombatant.TotalDmgOut == 0)) and
				   ((iCombatant.TotalRawHeal == nil) or (iCombatant.TotalRawHeal == 0)) and
				   ((iCombatant.TotalDeaths == nil) or (iCombatant.TotalDeaths == 0)) and
				   (iCombatant.OwnedBy == nil) and
				   (iCombatant[AllLastOutgoingDetail] == nil) and
				   (iCombatant[AllLastIncomingDetail] == nil) and
				   (iCombatant[AllLastOtherDetail] == nil) and
				   (iCombatant[AllLastTargetDetail] == nil) and
				   (iCombatant[AllLastSourceDetail] == nil) then
					-- no damage in or out, no healing, no details, don't save
					-- 2014 June save everything with owners
				else

					-- the values for TotalDmgIn, TotalDmgOut, TotalMaxHit, TotalRawHeal, TotalOverHeal are too large for %u
					local highDmgIn, highDmgOut, highMaxHit, highRawHeal, highOverHeal, lowDmgIn, lowDmgOut, lowMaxHit, lowRawHeal, lowOverHeal
					lowDmgIn = (iCombatant.TotalDmgIn or 0)
					highDmgIn = math_floor(lowDmgIn / 2147483648)
					lowDmgIn = lowDmgIn - highDmgIn * 2147483648
					lowDmgOut = (iCombatant.TotalDmgOut or 0)
					highDmgOut = math_floor(lowDmgOut / 2147483648)
					lowDmgOut = lowDmgOut - highDmgOut * 2147483648
					lowMaxHit = (iCombatant.TotalMaxHit or 0)
					highMaxHit = math_floor(lowMaxHit / 2147483648)
					lowMaxHit = lowMaxHit - highMaxHit * 2147483648
					lowRawHeal = (iCombatant.TotalRawHeal or 0)
					highRawHeal = math_floor(lowRawHeal / 2147483648)
					lowRawHeal = lowRawHeal - highRawHeal * 2147483648
					lowOverHeal = (iCombatant.TotalOverHeal or 0)
					highOverHeal = math_floor(lowOverHeal / 2147483648)
					lowOverHeal = lowOverHeal - highOverHeal * 2147483648

					setCombatant[i] = {}
					setCombatant[i].Base = string_format("%s %s \"%s\" %d %d %d %d %d %d %d %d %d %d %d %d %d %.3f %.3f %.3f %d %d %d %d ~%d %d %d %d %d %d %d %d %d",
											tostring(iCombatant.Friend),
											tostring(rTemp.InGroup[iCombatant]),
											tostring(iCombatant.OwnedBy),
											highDmgIn, lowDmgIn,
											highDmgOut, lowDmgOut,
											highMaxHit, lowMaxHit,
											highRawHeal, lowRawHeal,
											highOverHeal, lowOverHeal,
											(iCombatant.TotalDeaths or 0),
											(iCombatant.TotalDispels or 0),
											(iCombatant.TotalInterrupts or 0),
											(iCombatant.TotalTime or 0),
											(iCombatant.TotalTimeIn or 0),
											(iCombatant.TotalTimeHeal or 0),
											highSeen, lowSeen, highFlags, lowFlags,
											Recap_MakeKey(iCombatant.Faction),
											Recap_MakeKey(iCombatant.Class),
											(iCombatant.Level or 0),
											(iCombatant.MinMaxHealth or -9),(iCombatant.MaxMaxHealth or -9),(iCombatant.MinMaxPower or -9),(iCombatant.MaxMaxPower or -9),(iCombatant.PowerType or -9),
											(iCombatant.GearValue or 0))
				end
			else
				-- added to write Last Fight data only
				-- we exclude 'combatants' with no real data
				if ((iCombatant["LastDmgIn_"..iLast] == nil) or (iCombatant["LastDmgIn_"..iLast] == 0)) and
				   ((iCombatant["LastDmgOut_"..iLast] == nil) or (iCombatant["LastDmgOut_"..iLast] == 0)) and
				   ((iCombatant["LastRawHeal_"..iLast] == nil) or (iCombatant["LastRawHeal_"..iLast] == 0)) and
				   ((iCombatant["LastDeaths_"..iLast] == nil) or (iCombatant["LastDeaths_"..iLast] == 0)) and
				   (iCombatant.OwnedBy == nil) and
				   (iCombatant[AllLastOutgoingDetail] == nil) and
				   (iCombatant[AllLastIncomingDetail] == nil) and
				   (iCombatant[AllLastOtherDetail] == nil) and
				   (iCombatant[AllLastTargetDetail] == nil) and
				   (iCombatant[AllLastSourceDetail] == nil) then
					-- no damage in or out, no healing, no details, don't save
					-- 2014 June save everything with owners
				else

					-- the values for LastDmgIn, LastDmgOut, LastMaxHit, LastRawHeal, LastOverHeal are too large for %u
					local highDmgIn, highDmgOut, highMaxHit, highRawHeal, highOverHeal, lowDmgIn, lowDmgOut, lowMaxHit, lowRawHeal, lowOverHeal
					lowDmgIn = (iCombatant["LastDmgIn_"..iLast] or 0)
					highDmgIn = math_floor(lowDmgIn / 2147483648)
					lowDmgIn = lowDmgIn - highDmgIn * 2147483648
					lowDmgOut = (iCombatant["LastDmgOut_"..iLast] or 0)
					highDmgOut = math_floor(lowDmgOut / 2147483648)
					lowDmgOut = lowDmgOut - highDmgOut * 2147483648
					lowMaxHit = (iCombatant["LastMaxHit_"..iLast] or 0)
					highMaxHit = math_floor(lowMaxHit / 2147483648)
					lowMaxHit = lowMaxHit - highMaxHit * 2147483648
					lowRawHeal = (iCombatant["LastRawHeal_"..iLast] or 0)
					highRawHeal = math_floor(lowRawHeal / 2147483648)
					lowRawHeal = lowRawHeal - highRawHeal * 2147483648
					lowOverHeal = (iCombatant["LastOverHeal_"..iLast] or 0)
					highOverHeal = math_floor(lowOverHeal / 2147483648)
					lowOverHeal = lowOverHeal - highOverHeal * 2147483648

					setCombatant[i] = {}
					setCombatant[i].Base = string_format("%s %s \"%s\" %d %d %d %d %d %d %d %d %d %d %d %d %d %.3f %.3f %.3f %d %d %d %d ~%d %d %d %d %d %d %d %d %d",
											tostring(iCombatant.Friend),
											tostring(rTemp.InGroup[iCombatant]),
											tostring(iCombatant.OwnedBy),
											highDmgIn, lowDmgIn,
											highDmgOut, lowDmgOut,
											highMaxHit, lowMaxHit,
											highRawHeal, lowRawHeal,
											highOverHeal, lowOverHeal,
											(iCombatant["LastDeaths_"..iLast] or 0),
											(iCombatant["LastDispels_"..iLast] or 0),
											(iCombatant["LastInterrupts_"..iLast] or 0),
											(iCombatant["LastTime_"..iLast] or 0),
											(iCombatant["LastTimeIn_"..iLast] or 0),
											(iCombatant["LastTimeHeal_"..iLast] or 0),
											highSeen, lowSeen, highFlags, lowFlags,
											Recap_MakeKey(iCombatant.Faction),
											Recap_MakeKey(iCombatant.Class),
											(iCombatant.Level or 0),
											(iCombatant.MinMaxHealth or -9),(iCombatant.MaxMaxHealth or -9),(iCombatant.MinMaxPower or -9),(iCombatant.MaxMaxPower or -9),(iCombatant.PowerType or -9),
											(iCombatant["LastGearValue_"..iLast] or 0))
				end
			end
		end
	end
end
local function Recap_SaveCombatantOutgoing(iDetail, setCombatant)

	local byteLimit = 65000
	local j, k, allDetails, allDetailsLength, oneDetail, oneDetailLength, detail, pureEffect

	allDetails = {}
	allDetailsLength = 0
	for j in pairs(iDetail) do
		if iDetail[j].Effect then
			-- new with 4.36
			pureEffect = iDetail[j].Effect
		else
			pureEffect = Recap_StripOwnerAndPetFromEffect(string_sub(j,2))
		end
		oneDetail = {}
		oneDetailLength = 0
		for k in pairs(iDetail[j]) do
			if (k~="Element") and (k~="Effect") then
				if oneDetailLength == 0 then
					-- prefix for entire Detail
					if iDetail[j].Element then
						detail = "["..j..">"..iDetail[j].Element..">"..pureEffect..">"
					else
						detail = "["..j..">".."?"..">"..pureEffect..">"
					end
					table_insert(oneDetail, detail)
					oneDetailLength = oneDetailLength + string_len(detail)
				end
				detail = detkey[k]..iDetail[j][k]
				table_insert(oneDetail, detail)
				oneDetailLength = oneDetailLength + string_len(detail)
			end
		end
		if oneDetailLength > 0 then
			-- detail to add to the string
			if (allDetailsLength + oneDetailLength + 1) > byteLimit then
				-- new string would be over the limit
				if not setCombatant.Out then
					-- if Out is not already a table, make it one
					setCombatant.Out = {}
				end
				-- add the previous accumulated string, which was under the limit, to the table
				table_insert(setCombatant.Out, table_concat(allDetails))
				-- fresh start for the accumulated string
				allDetails = {}
				allDetailsLength = 0
			end
			-- add the latest detail to the accumulated string
			table_insert(oneDetail, "]") -- terminator for the entire Detail
			oneDetailLength = oneDetailLength + 1
			table_insert(allDetails, table_concat(oneDetail))
			allDetailsLength = allDetailsLength + oneDetailLength
		end
	end
	if allDetailsLength > 0 then
		-- we have an accumulated string
		if not setCombatant.Out then
			-- if Out is not already a table, make it one
			setCombatant.Out = {}
		end
		table_insert(setCombatant.Out, table_concat(allDetails))
	end
end
function Recap_SaveCombatantsOutgoing(setname, lastfightonly)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local iLast = rTemp.DisplayLastFight
	local target, i, iCombatant

	target = rSet[setname]

	local AllLastOutgoingDetail = "OutgoingDetail"
	if lastfightonly then
		-- we save from the displayed Last Fight details (not from the details being actively accumulated)
		AllLastOutgoingDetail = "LastOutgoingDetail_"..iLast
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) and
		   (not lastfightonly or iCombatant.WasInLast) then
			if iCombatant[AllLastOutgoingDetail] then
				Recap_SaveCombatantOutgoing(iCombatant[AllLastOutgoingDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantTarget(iDetail, setCombatant)

	local byteLimit = 65000
	local j, k, allDetails, allDetailsLength, oneDetail, oneDetailLength, detail, pureEffect

	allDetails = {}
	allDetailsLength = 0
	for j in pairs(iDetail) do
		oneDetail = {}
		oneDetailLength = 0
		for k in pairs(iDetail[j]) do
			-- name, amount pairs where name (k) is "Total" or a pet name (which may include colons)
			if oneDetailLength == 0 then
				-- prefix for entire Detail
				detail = "@"..j..">"
				table_insert(oneDetail, detail)
				oneDetailLength = oneDetailLength + string_len(detail)
			end
			detail = k..iDetail[j][k]
			table_insert(oneDetail, detail)
			oneDetailLength = oneDetailLength + string_len(detail)
		end
		if oneDetailLength > 0 then
			-- detail to add to the string
			if (allDetailsLength + oneDetailLength + 1) > byteLimit then
				-- new string would be over the limit
				if not setCombatant.Target then
					-- if Target is not already a table, make it one
					setCombatant.Target = {}
				end
				-- add the previous accumulated string, which was under the limit, to the table
				table_insert(setCombatant.Target, table_concat(allDetails))
				-- fresh start for the accumulated string
				allDetails = {}
				allDetailsLength = 0
			end
			-- add the latest detail to the accumulated string
			table_insert(oneDetail, "@") -- terminator for the entire Detail
			oneDetailLength = oneDetailLength + 1
			table_insert(allDetails, table_concat(oneDetail))
			allDetailsLength = allDetailsLength + oneDetailLength
		end
	end
	if allDetailsLength > 0 then
		-- we have an accumulated string
		if not setCombatant.Target then
			-- if Out is not already a table, make it one
			setCombatant.Target = {}
		end
		table_insert(setCombatant.Target, table_concat(allDetails))
	end
end
function Recap_SaveCombatantsTarget(setname, lastfightonly)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local iLast = rTemp.DisplayLastFight
	local target, i, iCombatant

	target = rSet[setname]

	local AllLastTargetDetail = "TargetDetail"
	if lastfightonly then
		-- we save from the displayed Last Fight details (not from the details being actively accumulated)
		AllLastTargetDetail = "LastTargetDetail_"..iLast
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) and
		   (not lastfightonly or iCombatant.WasInLast) then
			if iCombatant[AllLastTargetDetail] then
				Recap_SaveCombatantTarget(iCombatant[AllLastTargetDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantIncoming(iDetail, setCombatant)

	local byteLimit = 65000
	local j, k, allDetails, allDetailsLength, oneDetail, oneDetailLength, detail, pureEffect

	allDetails = {}
	allDetailsLength = 0
	for j in pairs(iDetail) do
		if iDetail[j].Effect then
			-- new with 4.36
			pureEffect = iDetail[j].Effect
		else
			pureEffect = Recap_StripOwnerAndPetFromEffect(string_sub(j,2))
		end
		oneDetail = {}
		oneDetailLength = 0
		for k in pairs(iDetail[j]) do
			if (k~="Element") and (k~="Effect") then
				if oneDetailLength == 0 then
					-- prefix for entire Detail
					if iDetail[j].Element then
						detail = "*"..j..">"..iDetail[j].Element..">"..pureEffect..">"
					else
						detail = "*"..j..">".."?"..">"..pureEffect..">"
					end
					table_insert(oneDetail, detail)
					oneDetailLength = oneDetailLength + string_len(detail)
				end
				detail = detkey[k]..iDetail[j][k]
				table_insert(oneDetail, detail)
				oneDetailLength = oneDetailLength + string_len(detail)
			end
		end
		if oneDetailLength > 0 then
			-- detail to add to the string
			if (allDetailsLength + oneDetailLength + 1) > byteLimit then
				-- new string would be over the limit
				if not setCombatant.In then
					-- if In is not already a table, make it one
					setCombatant.In = {}
				end
				-- add the previous accumulated string, which was under the limit, to the table
				table_insert(setCombatant.In, table_concat(allDetails))
				-- fresh start for the accumulated string
				allDetails = {}
				allDetailsLength = 0
			end
			-- add the latest detail to the accumulated string
			table_insert(oneDetail, "*") -- terminator for the entire Detail
			oneDetailLength = oneDetailLength + 1
			table_insert(allDetails, table_concat(oneDetail))
			allDetailsLength = allDetailsLength + oneDetailLength
		end
	end
	if allDetailsLength > 0 then
		-- we have an accumulated string
		if not setCombatant.In then
			-- if In is not already a table, make it one
			setCombatant.In = {}
		end
		table_insert(setCombatant.In, table_concat(allDetails))
	end
end
function Recap_SaveCombatantsIncoming(setname, lastfightonly)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local iLast = rTemp.DisplayLastFight
	local target, i, iCombatant

	target = rSet[setname]

	local AllLastIncomingDetail = "IncomingDetail"
	if lastfightonly then
		-- we save from the displayed Last Fight details (not from the details being actively accumulated)
		AllLastIncomingDetail = "LastIncomingDetail_"..iLast
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) and
		   (not lastfightonly or iCombatant.WasInLast) then
			if iCombatant[AllLastIncomingDetail] then
				Recap_SaveCombatantIncoming(iCombatant[AllLastIncomingDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantSource(iDetail, setCombatant)

	local byteLimit = 65000
	local j, k, allDetails, allDetailsLength, oneDetail, oneDetailLength, detail, pureEffect

	allDetails = {}
	allDetailsLength = 0
	for j in pairs(iDetail) do
		oneDetail = {}
		oneDetailLength = 0
		for k in pairs(iDetail[j]) do
			-- name, amount pairs where name (k) is "Total" or a pet name (which may include colons)
			if oneDetailLength == 0 then
				-- prefix for entire Detail
				detail = "&"..j..">"
				table_insert(oneDetail, detail)
				oneDetailLength = oneDetailLength + string_len(detail)
			end
			detail = k..iDetail[j][k]
			table_insert(oneDetail, detail)
			oneDetailLength = oneDetailLength + string_len(detail)
		end
		if oneDetailLength > 0 then
			-- detail to add to the string
			if (allDetailsLength + oneDetailLength + 1) > byteLimit then
				-- new string would be over the limit
				if not setCombatant.Source then
					-- if Source is not already a table, make it one
					setCombatant.Source = {}
				end
				-- add the previous accumulated string, which was under the limit, to the table
				table_insert(setCombatant.Source, table_concat(allDetails))
				-- fresh start for the accumulated string
				allDetails = {}
				allDetailsLength = 0
			end
			-- add the latest detail to the accumulated string
			table_insert(oneDetail, "&") -- terminator for the entire Detail
			oneDetailLength = oneDetailLength + 1
			table_insert(allDetails, table_concat(oneDetail))
			allDetailsLength = allDetailsLength + oneDetailLength
		end
	end
	if allDetailsLength > 0 then
		-- we have an accumulated string
		if not setCombatant.Source then
			-- if Source is not already a table, make it one
			setCombatant.Source = {}
		end
		table_insert(setCombatant.Source, table_concat(allDetails))
	end
end
function Recap_SaveCombatantsSource(setname, lastfightonly)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local iLast = rTemp.DisplayLastFight
	local target, i, iCombatant

	target = rSet[setname]

	local AllLastSourceDetail = "SourceDetail"
	if lastfightonly then
		-- we save from the displayed Last Fight details (not from the details being actively accumulated)
		AllLastSourceDetail = "LastSourceDetail_"..iLast
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) and
		   (not lastfightonly or iCombatant.WasInLast) then
			if iCombatant[AllLastSourceDetail] then
				Recap_SaveCombatantSource(iCombatant[AllLastSourceDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantOther(iDetail, setCombatant)

	local byteLimit = 65000
	local j, k, allDetails, allDetailsLength, oneDetail, oneDetailLength, detail, pureEffect

	allDetails = {}
	allDetailsLength = 0
	for j in pairs(iDetail) do
		if iDetail[j].Effect then
			-- new with 4.36
			pureEffect = iDetail[j].Effect
		else
			pureEffect = Recap_StripOwnerAndPetFromEffect(string_sub(j,2))
		end
		oneDetail = {}
		oneDetailLength = 0
		for k in pairs(iDetail[j]) do
			if (k~="Attribute") and (k~="Effect") then
				if oneDetailLength == 0 then
					-- prefix for entire Detail
					if iDetail[j].Attribute then
						detail = "#"..j..">"..iDetail[j].Attribute..">"..pureEffect..">"
					else
						detail = "#"..j..">".."?"..">"..pureEffect..">"
					end
					table_insert(oneDetail, detail)
					oneDetailLength = oneDetailLength + string_len(detail)
				end
				detail = detkey[k]..iDetail[j][k]
				table_insert(oneDetail, detail)
				oneDetailLength = oneDetailLength + string_len(detail)
			end
		end
		if oneDetailLength > 0 then
			-- detail to add to the string
			if (allDetailsLength + oneDetailLength + 1) > byteLimit then
				-- new string would be over the limit
				if not setCombatant.Other then
					-- if Other is not already a table, make it one
					setCombatant.Other = {}
				end
				-- add the previous accumulated string, which was under the limit, to the table
				table_insert(setCombatant.Other, table_concat(allDetails))
				-- fresh start for the accumulated string
				allDetails = {}
				allDetailsLength = 0
			end
			-- add the latest detail to the accumulated string
			table_insert(oneDetail, "#") -- terminator for the entire Detail
			oneDetailLength = oneDetailLength + 1
			table_insert(allDetails, table_concat(oneDetail))
			allDetailsLength = allDetailsLength + oneDetailLength
		end
	end
	if allDetailsLength > 0 then
		-- we have an accumulated string
		if not setCombatant.Other then
			-- if Other is not already a table, make it one
			setCombatant.Other = {}
		end
		table_insert(setCombatant.Other, table_concat(allDetails))
	end
end
function Recap_SaveCombatantsOther(setname, lastfightonly)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local iLast = rTemp.DisplayLastFight
	local target, i, iCombatant

	target = rSet[setname]

	local AllLastOtherDetail = "OtherDetail"
	if lastfightonly then
		-- we save from the displayed Last Fight details (not from the details being actively accumulated)
		AllLastOtherDetail = "LastOtherDetail_"..iLast
	end

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) and
		   (not lastfightonly or iCombatant.WasInLast) then
			if iCombatant[AllLastOtherDetail] then
				Recap_SaveCombatantOther(iCombatant[AllLastOtherDetail], target.Combatant[i])
			end
		end
	end
end

-- duplicate functions for saving compressed version, only called at logout or reloadui
local function Recap_SaveCombatantsBasicCompressed()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local target
	local i, iCombatant, setCombatant

	target = recap_compressed

	-- Windows lua code does not support %e
	target.TimeStamp = date("%Y-%m-%d %H:%M %a")
	-- version when this file was saved, to support future data conversion
	target.SavedAtVersion = Recap_Version
	target.TotalDuration = rUser.TotalDuration
	target.TotalDurationIn = rUser.TotalDurationIn
	target.TotalDurationHeal = rUser.TotalDurationHeal
	target.MergePets = Recap_PetsMerged() -- not 100% reliable if the user changed the setting after the data was collected
	target.IgnoreGUIDs = rOpt.IgnoreGUIDs.value -- not 100% reliable if the user changed the setting after the data was collected
	target.Combatant = {}

	local AllLastOutgoingDetail = "OutgoingDetail"
	local AllLastIncomingDetail = "IncomingDetail"
	local AllLastOtherDetail = "OtherDetail"
	local AllLastTargetDetail = "TargetDetail"
	local AllLastSourceDetail = "SourceDetail"

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) then

			setCombatant = target.Combatant

			-- the value of Seen is too large for %u
			local highSeen, lowSeen
			lowSeen = (iCombatant.Seen or 0)
			highSeen = math_floor(lowSeen / 2147483648)
			lowSeen = lowSeen - highSeen * 2147483648

			-- the value of Flags is too large for %u
			local highFlags, lowFlags
			lowFlags = (iCombatant.Flags or 0)
			highFlags = math_floor(lowFlags / 2147483648)
			lowFlags = lowFlags - highFlags * 2147483648

			-- we exclude 'combatants' with no real data (at the moment, dispels and interrupts don't count)
			if ((iCombatant.TotalDmgIn == nil) or (iCombatant.TotalDmgIn == 0)) and
			   ((iCombatant.TotalDmgOut == nil) or (iCombatant.TotalDmgOut == 0)) and
			   ((iCombatant.TotalRawHeal == nil) or (iCombatant.TotalRawHeal == 0)) and
			   ((iCombatant.TotalDeaths == nil) or (iCombatant.TotalDeaths == 0)) and
			   (iCombatant.OwnedBy == nil) and
			   (iCombatant[AllLastOutgoingDetail] == nil) and
			   (iCombatant[AllLastIncomingDetail] == nil) and
			   (iCombatant[AllLastOtherDetail] == nil) and
			   (iCombatant[AllLastTargetDetail] == nil) and
			   (iCombatant[AllLastSourceDetail] == nil) then
				-- no damage in or out, no healing, no details, don't save
				-- 2014 June save everything with owners
			else

				-- the values for TotalDmgIn, TotalDmgOut, TotalMaxHit, TotalRawHeal, TotalOverHeal are too large for %u
				local highDmgIn, highDmgOut, highMaxHit, highRawHeal, highOverHeal, lowDmgIn, lowDmgOut, lowMaxHit, lowRawHeal, lowOverHeal
				lowDmgIn = (iCombatant.TotalDmgIn or 0)
				highDmgIn = math_floor(lowDmgIn / 2147483648)
				lowDmgIn = lowDmgIn - highDmgIn * 2147483648
				lowDmgOut = (iCombatant.TotalDmgOut or 0)
				highDmgOut = math_floor(lowDmgOut / 2147483648)
				lowDmgOut = lowDmgOut - highDmgOut * 2147483648
				lowMaxHit = (iCombatant.TotalMaxHit or 0)
				highMaxHit = math_floor(lowMaxHit / 2147483648)
				lowMaxHit = lowMaxHit - highMaxHit * 2147483648
				lowRawHeal = (iCombatant.TotalRawHeal or 0)
				highRawHeal = math_floor(lowRawHeal / 2147483648)
				lowRawHeal = lowRawHeal - highRawHeal * 2147483648
				lowOverHeal = (iCombatant.TotalOverHeal or 0)
				highOverHeal = math_floor(lowOverHeal / 2147483648)
				lowOverHeal = lowOverHeal - highOverHeal * 2147483648

				setCombatant[i] = {}
				setCombatant[i].Base = string_format("%s %s \"%s\" %d %d %d %d %d %d %d %d %d %d %d %d %d %.3f %.3f %.3f %d %d %d %d ~%d %d %d %d %d %d %d %d %d",
										tostring(iCombatant.Friend),
										tostring(rTemp.InGroup[iCombatant]),
										tostring(iCombatant.OwnedBy),
										highDmgIn, lowDmgIn,
										highDmgOut, lowDmgOut,
										highMaxHit, lowMaxHit,
										highRawHeal, lowRawHeal,
										highOverHeal, lowOverHeal,
										(iCombatant.TotalDeaths or 0),
										(iCombatant.TotalDispels or 0),
										(iCombatant.TotalInterrupts or 0),
										(iCombatant.TotalTime or 0),
										(iCombatant.TotalTimeIn or 0),
										(iCombatant.TotalTimeHeal or 0),
										highSeen, lowSeen, highFlags, lowFlags,
										Recap_MakeKey(iCombatant.Faction),
										Recap_MakeKey(iCombatant.Class),
										(iCombatant.Level or 0),
										(iCombatant.MinMaxHealth or -9),(iCombatant.MaxMaxHealth or -9),(iCombatant.MinMaxPower or -9),(iCombatant.MaxMaxPower or -9),(iCombatant.PowerType or -9))
			end
		end
	end
end
local function Recap_SaveCombatantsOutgoingCompressed()

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local target, i, iCombatant

	target = recap_compressed

	local AllLastOutgoingDetail = "OutgoingDetail"

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) then
			if iCombatant[AllLastOutgoingDetail] then
				Recap_SaveCombatantOutgoing(iCombatant[AllLastOutgoingDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantsTargetCompressed()

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local target, i, iCombatant

	target = recap_compressed

	local AllLastTargetDetail = "TargetDetail"

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) then
			if iCombatant[AllLastTargetDetail] then
				Recap_SaveCombatantTarget(iCombatant[AllLastTargetDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantsIncomingCompressed()

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local target, i, iCombatant

	target = recap_compressed

	local AllLastIncomingDetail = "IncomingDetail"

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) then
			if iCombatant[AllLastIncomingDetail] then
				Recap_SaveCombatantIncoming(iCombatant[AllLastIncomingDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantsSourceCompressed()

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local target, i, iCombatant

	target = recap_compressed

	local AllLastSourceDetail = "SourceDetail"

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) then
			if iCombatant[AllLastSourceDetail] then
				Recap_SaveCombatantSource(iCombatant[AllLastSourceDetail], target.Combatant[i])
			end
		end
	end
end
local function Recap_SaveCombatantsOtherCompressed()

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local target, i, iCombatant

	target = recap_compressed

	local AllLastOtherDetail = "OtherDetail"

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) and
		   (not rOpt.SaveGroup.value or iCombatant.Friend) then
			if iCombatant[AllLastOtherDetail] then
				Recap_SaveCombatantOther(iCombatant[AllLastOtherDetail], target.Combatant[i])
			end
		end
	end
end
function Recap_CompressCombatants()

	local rOpt = _G.recap_temp.Opt
	local i, count

	recap_compressed = {}
	Recap_SaveCombatantsBasicCompressed()
	-- How many combatants?
	count = 0
	for i in pairs(recap_compressed.Combatant) do
		count = count + 1
	end
	if count == 0 then
		-- set is empty after all, don't save it
		recap_compressed = nil
	else
		recap_compressed.ListSize = count
		if not rOpt.LightData.value then
			-- save details (note, not phased, so there is a risk of a Blizzard timeout, but this is only done on logout)
			Recap_SaveCombatantsOutgoingCompressed()
			Recap_SaveCombatantsTargetCompressed()
			Recap_SaveCombatantsIncomingCompressed()
			Recap_SaveCombatantsSourceCompressed()
			Recap_SaveCombatantsOtherCompressed()
		end
	end
end

local function Recap_LoadOutgoingDetails(iCombatant, tranche)

	local j, k, found, _, set_name, set_element, set_effect, set_rest, needArray
	local sd = {} -- temp holding place for fields that may not exist

	set_effect = nil
	-- process Outgoing Detail: [name>element>a000b000c000]
	for j in string_gmatch(tranche, "%[.-%]") do
		sd = wipe(sd)
		found,_,set_name,set_element,set_effect,set_rest = string_find(j, "%[(.-)%>(.-)%>(.-)%>(.*)")
		if not found then
			found,_,set_name,set_element,set_rest = string_find(j, "%[(.-)%>(.-)%>(.*)")
		end
		if found then -- new saved method
			-- fix to allow multi-letter keys
			-- prefix the string j with a digit and use digits to delimit the keys
			-- set_rest contains the details for one ability, so will be relatively short
			set_rest = "1"..set_rest
			for k in pairs(detkey) do
				_,_,sd[k] = string_find(set_rest, "%d"..detkey[k].."(%d+)")
			end
			-- skip effects that have zero damage
			local total
			total = (sd.GlancesDmg or 0) + (sd.HitsDmg or 0) + (sd.CritsDmg or 0) + (sd.CrushDmg or 0) + (sd.TicksDmg or 0)
			if total == 0 then
				found = false
			end
		end
		if found then
			needArray = true
			for k in pairs(sd) do
				if sd[k] and tonumber(sd[k])>0 then
					if needArray then
						if not iCombatant.OutgoingDetail then
							iCombatant.OutgoingDetail = {}
						end
						iCombatant.OutgoingDetail[set_name] = {}
						iCombatant.OutgoingDetail[set_name].Element = set_element
						if set_effect then
							iCombatant.OutgoingDetail[set_name].Effect = set_effect
						end
						needArray = false
					end
					iCombatant.OutgoingDetail[set_name][k] = tonumber(sd[k])
				end
			end
		end
	end
end

local function Recap_LoadTargetDetails(iCombatant, tranche)

	local j, k, m, found, _, set_name, set_petname, set_rest, needArray

	for j in string_gmatch(tranche, "%@.-%@") do
		-- Target Detail: @name>tgt000tgt000tgt000@
		--   tgt can be 'Total', owner:pet, or owner:owner:pet (without GUIDs)
		--   legacy abbreviation of 'v' needs to be replaced by 'Total'
		found,_,set_name,set_rest = string_find(j, "%@(.-)%>(.*)")
		if found then
			needArray = true
			for k,m in string_gmatch(set_rest, "([^%d]+)(%d+)") do
				-- relies on tgt containing no digits
				if needArray then
					if not iCombatant.TargetDetail then
						iCombatant.TargetDetail = {}
					end
					iCombatant.TargetDetail[set_name] = {}
					needArray = false
				end
				if (k == "v") then
					iCombatant.TargetDetail[set_name]["Total"] = tonumber(m)
				else
					iCombatant.TargetDetail[set_name][k] = tonumber(m)
				end
			end
		end
	end
end

local function Recap_LoadIncomingDetails(iCombatant, tranche)

	local j, k, found, _, set_name, set_element, set_effect, set_rest, needArray
	local sd = {} -- temp holding place for fields that may not exist

	-- process Incoming Detail: *name>element>effect>a000b000c000* or *name>element>a000b000c000*
	set_effect = nil
	for j in string_gmatch(tranche, "%*.-%*") do
		sd = wipe(sd)
		found,_,set_name,set_element,set_effect,set_rest = string_find(j, "%*(.-)%>(.-)%>(.-)%>(.*)")
		if not found then
			found,_,set_name,set_element,set_rest = string_find(j, "%*(.-)%>(.-)%>(.*)")
		end
		if found then -- new saved method
			-- fix to allow multi-letter keys
			-- prefix the string j with a digit and use digits to delimit the keys
			-- set_rest contains the details for one ability, so will be relatively short
			set_rest = "1"..set_rest
			for k in pairs(detkey) do
				_,_,sd[k] = string_find(set_rest, "%d"..detkey[k].."(%d+)")
			end
			-- skip effects that have zero damage
			local total
			total = (sd.GlancesDmg or 0) + (sd.HitsDmg or 0) + (sd.CritsDmg or 0) + (sd.CrushDmg or 0) + (sd.TicksDmg or 0)
			if total == 0 then
				found = false
			end
		end
		if found then
			needArray = true
			for k in pairs(sd) do
				if sd[k] and tonumber(sd[k])>0 then
					if needArray then
						if not iCombatant.IncomingDetail then
							iCombatant.IncomingDetail = {}
						end
						iCombatant.IncomingDetail[set_name] = {}
						iCombatant.IncomingDetail[set_name].Element = set_element
						if set_effect then
							iCombatant.IncomingDetail[set_name].Effect = set_effect
						end
						needArray = false
					end
					iCombatant.IncomingDetail[set_name][k] = tonumber(sd[k])
				end
			end
		end
	end
end

local function Recap_LoadSourceDetails(iCombatant, tranche)

	local j, k, m, found, _, set_name, set_petname, set_rest, needArray

	for j in string_gmatch(tranche, "%&.-%&") do
		-- Source Detail: &name>src000src000src000&
		--   src can be 'Total', owner:pet, or owner:owner:pet (without GUIDs)
		--   legacy abbreviation of 'v' needs to be replaced by 'Total'
		found,_,set_name,set_rest = string_find(j, "%&(.-)%>(.*)")
		if found then
			needArray = true
			for k,m in string_gmatch(set_rest, "([^%d]+)(%d+)") do
				-- relies on src containing no digits
				if needArray then
					if not iCombatant.SourceDetail then
						iCombatant.SourceDetail = {}
					end
					iCombatant.SourceDetail[set_name] = {}
					needArray = false
				end
				if (k == "v") then
					iCombatant.SourceDetail[set_name]["Total"] = tonumber(m)
				else
					iCombatant.SourceDetail[set_name][k] = tonumber(m)
				end
			end
		end
	end
end

local function Recap_LoadOtherDetails(iCombatant, tranche)

	local j, k, found, _, set_name, set_attribute, set_effect, set_rest, needArray
	local sd = {} -- temp holding place for fields that may not exist

	-- process Other Detail: #name>attribute>a000b000c000#
	set_effect = nil
	for j in string_gmatch(tranche, "%#.-%#") do
		sd = wipe(sd)
		found,_,set_name,set_attribute,set_effect,set_rest = string_find(j, "%#(.-)%>(.-)%>(.-)%>(.*)")
		if not found then
			found,_,set_name,set_attribute,set_rest = string_find(j, "%#(.-)%>(.-)%>(.*)")
		end
		if found then -- new saved method
			-- fix to allow multi-letter keys
			-- prefix the string j with a digit and use digits to delimit the keys
			-- set_rest contains the details for one ability, so will be relatively short
			set_rest = "1"..set_rest
			for k in pairs(detkey) do
				_,_,sd[k] = string_find(set_rest, "%d"..detkey[k].."(%d+)")
			end
			needArray = true
			for k in pairs(sd) do
				if sd[k] and tonumber(sd[k])>0 then
					if needArray then
						if not iCombatant.OtherDetail then
							iCombatant.OtherDetail = {}
						end
						iCombatant.OtherDetail[set_name] = {}
						if set_attribute ~= "?" then
							iCombatant.OtherDetail[set_name].Attribute = set_attribute
						end
						if set_effect then
							iCombatant.OtherDetail[set_name].Effect = set_effect
						end
						needArray = false
					end
					iCombatant.OtherDetail[set_name][k] = tonumber(sd[k])
				end
			end
		end
	end
end

-- load to All Fights, does both core and details
function Recap_LoadCombatantsToAllFights(filen)

	local rTemp = _G.recap_temp
	local rSet = _G.recap_set
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local target, i, j, k, m, iCombatant, setCombatant, iEffect
	local found, _, set_friend, set_ingroup, set_ownedby, set_dmgin, set_dmgout, set_maxhit, set_rawheal, set_overheal, set_heal, set_deaths, set_dispels, set_interrupts, set_timeOut, set_timeIn, set_timeHeal, set_highseen, set_lowseen, set_highflags, set_lowflags, set_faction, set_class, set_level
	local set_lowhealth, set_highhealth, set_lowpower, set_highpower, set_powertype, set_gearvalue
	local set_highdmgin, set_lowdmgin, set_highdmgout, set_lowdmgout, set_highmaxhit, set_lowmaxhit, set_highrawheal, set_lowrawheal, set_highoverheal, set_lowoverheal
	local myBase, myOut, myTarget, myIn, mySource, myOther

	if not filen or string_len(filen)<1 or not rSet[filen] then
		return
	end

	Recap_ResetAllCombatants(false)

	target = rSet[filen]

	-- overall durations
	rUser.TotalDuration = target.TotalDuration
	rUser.TotalDurationIn = target.TotalDurationIn
	rUser.TotalDurationHeal = target.TotalDurationHeal

	-- silent repair
	if not target.Combatant then
		target.Combatant = {}
	end
	rTemp.InFriend = wipe(rTemp.InFriend)
	setCombatant = target.Combatant
	for i in pairs(setCombatant) do

		if not rCombatants[i] then
			Recap_CreateBlankCombatant(i, 0, nil)
		end
		iCombatant = rCombatants[i]
		myBase = setCombatant[i].Base

		if myBase then
			-- format from 4.77 and later
			-- TODO: may need to add a dummy at the end of the list to somehow trigger on mismatch -- I had at case where 'found' was returning true when the format alignment was wrong.
			found,_,set_friend,set_ingroup,set_ownedby,set_highdmgin,set_lowdmgin,set_highdmgout,set_lowdmgout,set_highmaxhit,set_lowmaxhit,set_highrawheal,set_lowrawheal,set_highoverheal,set_lowoverheal,set_deaths,set_dispels,set_interrupts,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%w+) \"([^\"]+)\" (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
			if found then
				if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
					iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
				end
				if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
					iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
				end
				if set_friend == "true" then
					iCombatant.Friend = true
					rTemp.InFriend[i] = true
				end
				if set_ingroup == "true" then
					rTemp.InGroup[i] = true
				end
				if set_ownedby == "nil" then
					-- do nothing
				else
					iCombatant.OwnedBy = set_ownedby
				end
				if (tonumber(set_highmaxhit) > 0) or (tonumber(set_lowmaxhit) > 0) then
					set_maxhit = 2147483648 * set_highmaxhit + set_lowmaxhit
					if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
						iCombatant.TotalMaxHit = tonumber(set_maxhit)
					end
				end
				if (tonumber(set_highdmgin) > 0) or (tonumber(set_lowdmgin) > 0) then
					set_dmgin = 2147483648 * set_highdmgin + set_lowdmgin
					iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
				end
				if (tonumber(set_highdmgout) > 0) or (tonumber(set_lowdmgout) > 0) then
					set_dmgout = 2147483648 * set_highdmgout + set_lowdmgout
					iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
				end
				if (tonumber(set_deaths) > 0) then
					iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
				end
				if (tonumber(set_dispels) > 0) then
					iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
				end
				if (tonumber(set_interrupts) > 0) then
					iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + tonumber(set_interrupts)
				end
				if (tonumber(set_highrawheal) > 0) or (tonumber(set_lowrawheal) > 0) then
					set_rawheal = 2147483648 * set_highrawheal + set_lowrawheal
					iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
					set_overheal = 0
					if (tonumber(set_highoverheal) > 0) or (tonumber(set_lowoverheal) > 0) then
						set_overheal = 2147483648 * set_highoverheal + set_lowoverheal
					end
					m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
					if m>0 then
						iCombatant.TotalOverHeal = m
					end
				end
				if (tonumber(set_timeOut) > 0) then
					iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
				end
				if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
					iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
				end
				if (tonumber(set_timeIn) > 0) then
					iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
				end
				if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
					iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
				end
				if (tonumber(set_timeHeal) > 0) then
					iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
				end
				if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
					iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
				end
			else
				-- format from 4.75 and later
				-- TODO: may need to add a dummy at the end of the list to somehow trigger on mismatch -- I had at case where 'found' was returning true when the format alignment was wrong.
				found,_,set_friend,set_highdmgin,set_lowdmgin,set_highdmgout,set_lowdmgout,set_highmaxhit,set_lowmaxhit,set_highrawheal,set_lowrawheal,set_highoverheal,set_lowoverheal,set_deaths,set_dispels,set_interrupts,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
				if found then
					if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
						iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
					end
					if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
						iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
					end
					if set_friend == "true" then
						iCombatant.Friend = true
						rTemp.InFriend[i] = true
					end
					if (tonumber(set_highmaxhit) > 0) or (tonumber(set_lowmaxhit) > 0) then
						set_maxhit = 2147483648 * set_highmaxhit + set_lowmaxhit
						if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
							iCombatant.TotalMaxHit = tonumber(set_maxhit)
						end
					end
					if (tonumber(set_highdmgin) > 0) or (tonumber(set_lowdmgin) > 0) then
						set_dmgin = 2147483648 * set_highdmgin + set_lowdmgin
						iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
					end
					if (tonumber(set_highdmgout) > 0) or (tonumber(set_lowdmgout) > 0) then
						set_dmgout = 2147483648 * set_highdmgout + set_lowdmgout
						iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
					end
					if (tonumber(set_deaths) > 0) then
						iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
					end
					if (tonumber(set_dispels) > 0) then
						iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
					end
					if (tonumber(set_interrupts) > 0) then
						iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + tonumber(set_interrupts)
					end
					if (tonumber(set_highrawheal) > 0) or (tonumber(set_lowrawheal) > 0) then
						set_rawheal = 2147483648 * set_highrawheal + set_lowrawheal
						iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
						set_overheal = 0
						if (tonumber(set_highoverheal) > 0) or (tonumber(set_lowoverheal) > 0) then
							set_overheal = 2147483648 * set_highoverheal + set_lowoverheal
						end
						m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
						if m>0 then
							iCombatant.TotalOverHeal = m
						end
					end
					if (tonumber(set_timeOut) > 0) then
						iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
					end
					if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
						iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
					end
					if (tonumber(set_timeIn) > 0) then
						iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
					end
					if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
						iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
					end
					if (tonumber(set_timeHeal) > 0) then
						iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
					end
					if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
						iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
					end
				else
					-- format from 4.25 and later
					found,_,set_friend,set_dmgin,set_dmgout,set_maxhit,set_rawheal,set_overheal,set_deaths,set_dispels,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
					if found then
						if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
							iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
						end
						if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
							iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
						end
						if set_friend == "true" then
							iCombatant.Friend = true
							rTemp.InFriend[i] = true
						end
						if (tonumber(set_maxhit) > 0) then
							if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
								iCombatant.TotalMaxHit = tonumber(set_maxhit)
							end
						end
						if (tonumber(set_dmgin) > 0) then
							iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
						end
						if (tonumber(set_dmgout) > 0) then
							iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
						end
						if (tonumber(set_deaths) > 0) then
							iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
						end
						if (tonumber(set_dispels) > 0) then
							iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
						end
						if (tonumber(set_rawheal) > 0) then
							iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
							m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
							if m>0 then
								iCombatant.TotalOverHeal = m
							end
						end
						if (tonumber(set_timeOut) > 0) then
							iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
						end
						if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
							iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
						end
						if (tonumber(set_timeIn) > 0) then
							iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
						end
						if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
							iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
						end
						if (tonumber(set_timeHeal) > 0) then
							iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
						end
						if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
							iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
						end
					end
				end
			end

			found,_,set_faction,set_class,set_level,set_lowhealth,set_highhealth,set_lowpower,set_highpower,set_powertype,set_gearvalue = string_find(myBase, "~(%d+) (%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%d+)")
			if not found then
				found,_,set_faction,set_class,set_level,set_lowhealth,set_highhealth,set_lowpower,set_highpower,set_powertype = string_find(myBase, "~(%d+) (%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+)")
			end
			if not found then
				found,_,set_faction,set_class,set_level = string_find(myBase, "~(%d+) (%d+) (%-?%d+)")
			end
			if not found then
				found,_,set_faction,set_class = string_find(myBase, "~(%d+) (%d+)")
			end
			if found then
				if set_faction and (tonumber(set_faction) > 0) then
					iCombatant.Faction = Recap_GetKey(set_faction)
				end
				if set_class and (tonumber(set_class) > 0) then
					iCombatant.Class = Recap_GetKey(set_class)
				end
				if set_level and (tonumber(set_level) ~= 0) then
					iCombatant.Level = iCombatant.Level or tonumber(set_level)
				end
				if set_lowhealth and (tonumber(set_lowhealth) ~= -9) then
					iCombatant.MinMaxHealth = iCombatant.MinMaxHealth or tonumber(set_lowhealth)
				end
				if set_highhealth and (tonumber(set_highhealth) ~= -9) then
					iCombatant.MaxMaxHealth = iCombatant.MaxMaxHealth or tonumber(set_highhealth)
				end
				if set_lowpower and (tonumber(set_lowpower) ~= -9) then
					iCombatant.MinMaxPower = iCombatant.MinMaxPower or tonumber(set_lowpower)
				end
				if set_highpower and (tonumber(set_highpower) ~= -9) then
					iCombatant.MaxMaxPower = iCombatant.MaxMaxPower or tonumber(set_highpower)
				end
				if set_powertype and (tonumber(set_powertype) ~= -9) then
					iCombatant.PowerType = iCombatant.PowerType or tonumber(set_powertype)
				end
				if set_gearvalue then
					iCombatant.GearValue = iCombatant.GearValue or tonumber(set_gearvalue)
				end
			end
		end

		if not rOpt.LightData.value then

			-- Outgoing Details
			myOut = setCombatant[i].Out
			if myOut then
				if type(myOut) == "string" then
					Recap_LoadOutgoingDetails(iCombatant, myOut)
				else
					-- table of strings
					for j in pairs(myOut) do
						Recap_LoadOutgoingDetails(iCombatant, myOut[j])
					end
				end
			end

			-- Target Details
			myTarget = setCombatant[i].Target
			if myTarget then
				if type(myTarget) == "string" then
					Recap_LoadTargetDetails(iCombatant, myTarget)
				else
					-- table of strings
					for j in pairs(myTarget) do
						Recap_LoadTargetDetails(iCombatant, myTarget[j])
					end
				end
			end

			-- Incoming Details
			myIn = setCombatant[i].In
			if myIn then
				if type(myIn) == "string" then
					Recap_LoadIncomingDetails(iCombatant, myIn)
				else
					-- table of strings
					for j in pairs(myIn) do
						Recap_LoadIncomingDetails(iCombatant, myIn[j])
					end
				end
			end

			-- Source Details
			mySource = setCombatant[i].Source
			if mySource then
				if type(mySource) == "string" then
					Recap_LoadSourceDetails(iCombatant, mySource)
				else
					-- table of strings
					for j in pairs(mySource) do
						Recap_LoadSourceDetails(iCombatant, mySource[j])
					end
				end
			end

			-- Other Details
			myOther = setCombatant[i].Other
			if myOther then
				if type(myOther) == "string" then
					Recap_LoadOtherDetails(iCombatant, myOther)
				else
					-- table of strings
					for j in pairs(myOther) do
						Recap_LoadOtherDetails(iCombatant, myOther[j])
					end
				end
			end
		end
	end
end

-- loads to Load, just does core stuff, details are loaded on demand (to reduce time outs during combat)
function Recap_LoadCombatantsCore(filen)

	local rSet = _G.recap_set
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rLoad = _G.recap_temp.Load
	local target, i, m, iCombatant, setCombatant
	local found, _, set_friend, set_ingroup, set_ownedby, set_dmgin, set_dmgout, set_maxhit, set_rawheal, set_overheal, set_heal, set_deaths, set_dispels, set_interrupts, set_timeOut, set_timeIn, set_timeHeal, set_highseen, set_lowseen, set_highflags, set_lowflags, set_faction, set_class, set_level
	local set_lowhealth, set_highhealth, set_lowpower, set_highpower, set_powertype, set_gearvalue
	local set_highdmgin, set_lowdmgin, set_highdmgout, set_lowdmgout, set_highmaxhit, set_lowmaxhit, set_highrawheal, set_lowrawheal, set_highoverheal, set_lowoverheal
	local myBase

	if not filen or string_len(filen)<1 or not rSet[filen] then
		return
	end

	RecapLoad_ResetAllCombatants()

	-- set initial sorting as a clone of the main panel sorting
	if rTemp.LoadSortBy == nil then
		rTemp.LoadSortBy = rUser.SortBy
	end
	if rTemp.LoadSortDir == nil then
		rTemp.LoadSortDir = rUser.SortDir
	end

	target = rSet[filen]

	-- overall durations
	rTemp.LoadTotalDuration = target.TotalDuration
	rTemp.LoadTotalDurationIn = target.TotalDurationIn
	rTemp.LoadTotalDurationHeal = target.TotalDurationHeal

	-- silent repair
	if not target.Combatant then
		target.Combatant = {}
	end
	setCombatant = target.Combatant
	for i in pairs(setCombatant) do

		if not rLoad[i] then
			RecapLoad_CreateBlankCombatant(i)
		end
		iCombatant = rLoad[i]
		myBase = setCombatant[i].Base

		if myBase then
			-- format from 4.77 and later
			-- TODO: may need to add a dummy at the end of the list to somehow trigger on mismatch -- I had at case where 'found' was returning true when the format alignment was wrong.
			found,_,set_friend,set_ingroup,set_ownedby,set_highdmgin,set_lowdmgin,set_highdmgout,set_lowdmgout,set_highmaxhit,set_lowmaxhit,set_highrawheal,set_lowrawheal,set_highoverheal,set_lowoverheal,set_deaths,set_dispels,set_interrupts,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%w+) \"([^\"]+)\" (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
			if found then
				if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
					iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
				end
				if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
					iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
				end
				if set_friend == "true" then
					iCombatant.Friend = true
				end
				if set_ingroup == "true" then
					rTemp.InGroup[i] = true
				end
				if set_ownedby == "nil" then
					-- do nothing
				else
					iCombatant.OwnedBy = set_ownedby
				end
				if (tonumber(set_highmaxhit) > 0) or (tonumber(set_lowmaxhit) > 0) then
					set_maxhit = 2147483648 * set_highmaxhit + set_lowmaxhit
					if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
						iCombatant.TotalMaxHit = tonumber(set_maxhit)
					end
				end
				if (tonumber(set_highdmgin) > 0) or (tonumber(set_lowdmgin) > 0) then
					set_dmgin = 2147483648 * set_highdmgin + set_lowdmgin
					iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
				end
				if (tonumber(set_highdmgout) > 0) or (tonumber(set_lowdmgout) > 0) then
					set_dmgout = 2147483648 * set_highdmgout + set_lowdmgout
					iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
				end
				if (tonumber(set_deaths) > 0) then
					iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
				end
				if (tonumber(set_dispels) > 0) then
					iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
				end
				if (tonumber(set_interrupts) > 0) then
					iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + tonumber(set_interrupts)
				end
				if (tonumber(set_highrawheal) > 0) or (tonumber(set_lowrawheal) > 0) then
					set_rawheal = 2147483648 * set_highrawheal + set_lowrawheal
					iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
					set_overheal = 0
					if (tonumber(set_highoverheal) > 0) or (tonumber(set_lowoverheal) > 0) then
						set_overheal = 2147483648 * set_highoverheal + set_lowoverheal
					end
					m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
					if m>0 then
						iCombatant.TotalOverHeal = m
					end
				end
				if (tonumber(set_timeOut) > 0) then
					iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
				end
				if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
					iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
				end
				if (tonumber(set_timeIn) > 0) then
					iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
				end
				if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
					iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
				end
				if (tonumber(set_timeHeal) > 0) then
					iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
				end
				if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
					iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
				end
			else
				-- format from 4.75 and later
				-- TODO: may need to add a dummy at the end of the list to somehow trigger on mismatch -- I had at case where 'found' was returning true when the format alignment was wrong.
				found,_,set_friend,set_highdmgin,set_lowdmgin,set_highdmgout,set_lowdmgout,set_highmaxhit,set_lowmaxhit,set_highrawheal,set_lowrawheal,set_highoverheal,set_lowoverheal,set_deaths,set_dispels,set_interrupts,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
				if found then
					if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
						iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
					end
					if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
						iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
					end
					if set_friend == "true" then
						iCombatant.Friend = true
					end
					if (tonumber(set_highmaxhit) > 0) or (tonumber(set_lowmaxhit) > 0) then
						set_maxhit = 2147483648 * set_highmaxhit + set_lowmaxhit
						if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
							iCombatant.TotalMaxHit = tonumber(set_maxhit)
						end
					end
					if (tonumber(set_highdmgin) > 0) or (tonumber(set_lowdmgin) > 0) then
						set_dmgin = 2147483648 * set_highdmgin + set_lowdmgin
						iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
					end
					if (tonumber(set_highdmgout) > 0) or (tonumber(set_lowdmgout) > 0) then
						set_dmgout = 2147483648 * set_highdmgout + set_lowdmgout
						iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
					end
					if (tonumber(set_deaths) > 0) then
						iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
					end
					if (tonumber(set_dispels) > 0) then
						iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
					end
					if (tonumber(set_interrupts) > 0) then
						iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + tonumber(set_interrupts)
					end
					if (tonumber(set_highrawheal) > 0) or (tonumber(set_lowrawheal) > 0) then
						set_rawheal = 2147483648 * set_highrawheal + set_lowrawheal
						iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
						set_overheal = 0
						if (tonumber(set_highoverheal) > 0) or (tonumber(set_lowoverheal) > 0) then
							set_overheal = 2147483648 * set_highoverheal + set_lowoverheal
						end
						m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
						if m>0 then
							iCombatant.TotalOverHeal = m
						end
					end
					if (tonumber(set_timeOut) > 0) then
						iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
					end
					if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
						iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
					end
					if (tonumber(set_timeIn) > 0) then
						iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
					end
					if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
						iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
					end
					if (tonumber(set_timeHeal) > 0) then
						iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
					end
					if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
						iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
					end
				else
					-- format from 4.25 and later
					found,_,set_friend,set_dmgin,set_dmgout,set_maxhit,set_rawheal,set_overheal,set_deaths,set_dispels,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
					if found then
						if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
							iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
						end
						if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
							iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
						end
						if set_friend == "true" then
							iCombatant.Friend = true
						end
						if (tonumber(set_maxhit) > 0) then
							if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
								iCombatant.TotalMaxHit = tonumber(set_maxhit)
							end
						end
						if (tonumber(set_dmgin) > 0) then
							iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
						end
						if (tonumber(set_dmgout) > 0) then
							iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
						end
						if (tonumber(set_deaths) > 0) then
							iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
						end
						if (tonumber(set_dispels) > 0) then
							iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
						end
						if (tonumber(set_rawheal) > 0) then
							iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
							m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
							if m>0 then
								iCombatant.TotalOverHeal = m
							end
						end
						if (tonumber(set_timeOut) > 0) then
							iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
						end
						if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
							iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
						end
						if (tonumber(set_timeIn) > 0) then
							iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
						end
						if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
							iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
						end
						if (tonumber(set_timeHeal) > 0) then
							iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
						end
						if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
							iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
						end
					end
				end
			end

			found,_,set_faction,set_class,set_level,set_lowhealth,set_highhealth,set_lowpower,set_highpower,set_powertype,set_gearvalue = string_find(myBase, "~(%d+) (%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%d+)")
			if not found then
				found,_,set_faction,set_class,set_level,set_lowhealth,set_highhealth,set_lowpower,set_highpower,set_powertype = string_find(myBase, "~(%d+) (%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+)")
			end
			if not found then
				found,_,set_faction,set_class,set_level = string_find(myBase, "~(%d+) (%d+) (%-?%d+)")
			end
			if not found then
				found,_,set_faction,set_class = string_find(myBase, "~(%d+) (%d+)")
			end
			if found then
				if set_faction and (tonumber(set_faction) > 0) then
					iCombatant.Faction = Recap_GetKey(set_faction)
				end
				if set_class and (tonumber(set_class) > 0) then
					iCombatant.Class = Recap_GetKey(set_class)
				end
				if set_level and (tonumber(set_level) ~= 0) then
					iCombatant.Level = iCombatant.Level or tonumber(set_level)
				end
				if set_lowhealth and (tonumber(set_lowhealth) ~= -9) then
					iCombatant.MinMaxHealth = iCombatant.MinMaxHealth or tonumber(set_lowhealth)
				end
				if set_highhealth and (tonumber(set_highhealth) ~= -9) then
					iCombatant.MaxMaxHealth = iCombatant.MaxMaxHealth or tonumber(set_highhealth)
				end
				if set_lowpower and (tonumber(set_lowpower) ~= -9) then
					iCombatant.MinMaxPower = iCombatant.MinMaxPower or tonumber(set_lowpower)
				end
				if set_highpower and (tonumber(set_highpower) ~= -9) then
					iCombatant.MaxMaxPower = iCombatant.MaxMaxPower or tonumber(set_highpower)
				end
				if set_powertype and (tonumber(set_powertype) ~= -9) then
					iCombatant.PowerType = iCombatant.PowerType or tonumber(set_powertype)
				end
				if set_gearvalue then
					iCombatant.GearValue = iCombatant.GearValue or tonumber(set_gearvalue)
				end
			end
		end

		-- as of 4.76, details are only loaded on demand (see Recap_LoadCombatantsDetails)

	end
end

function Recap_LoadCombatantsDetails()

	local rSet = _G.recap_set
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local rOpt = _G.recap_temp.Opt
	local rLoad = _G.recap_temp.Load
	local target, i, j, iCombatant, setCombatant
	local myOut, myTarget, myIn, mySource, myOther

	filen = rTemp.LoadedDataSet

	-- guard
	if not filen or string_len(filen)<1 or not rSet[filen] then
		return
	end

	target = rSet[filen]

	setCombatant = target.Combatant
	for i in pairs(setCombatant) do

		iCombatant = rLoad[i]

		if not rOpt.LightData.value then

			-- Outgoing Details
			myOut = setCombatant[i].Out
			if myOut then
				if type(myOut) == "string" then
					Recap_LoadOutgoingDetails(iCombatant, myOut)
				else
					-- table of strings
					for j in pairs(myOut) do
						Recap_LoadOutgoingDetails(iCombatant, myOut[j])
					end
				end
			end

			-- Target Details
			myTarget = setCombatant[i].Target
			if myTarget then
				if type(myTarget) == "string" then
					Recap_LoadTargetDetails(iCombatant, myTarget)
				else
					-- table of strings
					for j in pairs(myTarget) do
						Recap_LoadTargetDetails(iCombatant, myTarget[j])
					end
				end
			end

			-- Incoming Details
			myIn = setCombatant[i].In
			if myIn then
				if type(myIn) == "string" then
					Recap_LoadIncomingDetails(iCombatant, myIn)
				else
					-- table of strings
					for j in pairs(myIn) do
						Recap_LoadIncomingDetails(iCombatant, myIn[j])
					end
				end
			end

			-- Source Details
			mySource = setCombatant[i].Source
			if mySource then
				if type(mySource) == "string" then
					Recap_LoadSourceDetails(iCombatant, mySource)
				else
					-- table of strings
					for j in pairs(mySource) do
						Recap_LoadSourceDetails(iCombatant, mySource[j])
					end
				end
			end

			-- Other Details
			myOther = setCombatant[i].Other
			if myOther then
				if type(myOther) == "string" then
					Recap_LoadOtherDetails(iCombatant, myOther)
				else
					-- table of strings
					for j in pairs(myOther) do
						Recap_LoadOtherDetails(iCombatant, myOther[j])
					end
				end
			end
		end
	end

	rTemp.LoadedDetails = true

end

-- similar to LoadCombatants, loads from user_compressed, and only needs to match versions 4.29 and later
-- we only do this if recap_user is empty and recap_compressed has data (we work out the logic before we call)
-- Note, this function loads both Core and all Details, leave it like that
function Recap_DecompressCombatants()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rCompressed = _G.recap_compressed
	local rTemp = _G.recap_temp
	local i, j, m, iCombatant, setCombatant
	local found, _, set_friend, set_ingroup, set_ownedby, set_dmgin, set_dmgout, set_maxhit, set_rawheal, set_overheal, set_heal, set_deaths, set_dispels, set_interrupts, set_timeOut, set_timeIn, set_timeHeal, set_highseen, set_lowseen, set_highflags, set_lowflags, set_faction, set_class, set_level
	local set_lowhealth, set_highhealth, set_lowpower, set_highpower, set_powertype, set_gearvalue
	local set_highdmgin, set_lowdmgin, set_highdmgout, set_lowdmgout, set_highmaxhit, set_lowmaxhit, set_highrawheal, set_lowrawheal, set_highoverheal, set_lowoverheal
	local isSplit, myBase, myOut, myTarget, myIn, mySource, myOther

	Recap_ResetAllCombatants(true) -- in this context we don't need to save 'locked' combatants, they were saved

	rUser.TotalDuration = rUser.TotalDuration + (rCompressed.TotalDuration or 0)
	if rCompressed.TotalDurationIn then
		rUser.TotalDurationIn = rUser.TotalDurationIn + (rCompressed.TotalDurationIn or 0)
	else
		rUser.TotalDurationIn = rUser.TotalDurationIn + (rCompressed.TotalDuration or 0)
	end
	if rCompressed.TotalDurationHeal then
		rUser.TotalDurationHeal = rUser.TotalDurationHeal + (rCompressed.TotalDurationHeal or 0)
	else
		rUser.TotalDurationHeal = rUser.TotalDurationHeal + (rCompressed.TotalDuration or 0)
	end

	-- silent repair
	if not rCompressed.Combatant then
		rCompressed.Combatant = {}
	end
	rTemp.InFriend = wipe(rTemp.InFriend)
	setCombatant = rCompressed.Combatant
	for i in pairs(setCombatant) do

		if not rCombatants[i] then
			Recap_CreateBlankCombatant(i, 0, nil)
		end
		iCombatant = rCombatants[i]
		myBase = setCombatant[i].Base

		if myBase then
			-- format from 4.77 and later
			found,_,set_friend,set_ingroup,set_ownedby,set_highdmgin,set_lowdmgin,set_highdmgout,set_lowdmgout,set_highmaxhit,set_lowmaxhit,set_highrawheal,set_lowrawheal,set_highoverheal,set_lowoverheal,set_deaths,set_dispels,set_interrupts,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%w+) \"([^\"]+)\" (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
			if found then
				if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
					iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
				end
				if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
					iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
				end
				if set_friend == "true" then
					iCombatant.Friend = true
					rTemp.InFriend[i] = true
				end
				if set_ingroup == "true" then
					rTemp.InGroup[i] = true
				end
				if set_ownedby == "nil" then
					-- do nothing
				else
					iCombatant.OwnedBy = set_ownedby
				end
				if (tonumber(set_highmaxhit) > 0) or (tonumber(set_lowmaxhit) > 0) then
					set_maxhit = 2147483648 * set_highmaxhit + set_lowmaxhit
					if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
						iCombatant.TotalMaxHit = tonumber(set_maxhit)
					end
				end
				if (tonumber(set_highdmgin) > 0) or (tonumber(set_lowdmgin) > 0) then
					set_dmgin = 2147483648 * set_highdmgin + set_lowdmgin
					iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
				end
				if (tonumber(set_highdmgout) > 0) or (tonumber(set_lowdmgout) > 0) then
					set_dmgout = 2147483648 * set_highdmgout + set_lowdmgout
					iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
				end
				if (tonumber(set_deaths) > 0) then
					iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
				end
				if (tonumber(set_dispels) > 0) then
					iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
				end
				if (tonumber(set_interrupts) > 0) then
					iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + tonumber(set_interrupts)
				end
				if (tonumber(set_highrawheal) > 0) or (tonumber(set_lowrawheal) > 0) then
					set_rawheal = 2147483648 * set_highrawheal + set_lowrawheal
					iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
					set_overheal = 0
					if (tonumber(set_highoverheal) > 0) or (tonumber(set_lowoverheal) > 0) then
						set_overheal = 2147483648 * set_highoverheal + set_lowoverheal
					end
					m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
					if m>0 then
						iCombatant.TotalOverHeal = m
					end
				end
				if (tonumber(set_timeOut) > 0) then
					iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
				end
				if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
					iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
				end
				if (tonumber(set_timeIn) > 0) then
					iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
				end
				if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
					iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
				end
				if (tonumber(set_timeHeal) > 0) then
					iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
				end
				if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
					iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
				end
			else
				-- format from 4.75 and later
				found,_,set_friend,set_highdmgin,set_lowdmgin,set_highdmgout,set_lowdmgout,set_highmaxhit,set_lowmaxhit,set_highrawheal,set_lowrawheal,set_highoverheal,set_lowoverheal,set_deaths,set_dispels,set_interrupts,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
				if found then
					if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
						iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
					end
					if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
						iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
					end
					if set_friend == "true" then
						iCombatant.Friend = true
						rTemp.InFriend[i] = true
					end
					if (tonumber(set_highmaxhit) > 0) or (tonumber(set_lowmaxhit) > 0) then
						set_maxhit = 2147483648 * set_highmaxhit + set_lowmaxhit
						if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
							iCombatant.TotalMaxHit = tonumber(set_maxhit)
						end
					end
					if (tonumber(set_highdmgin) > 0) or (tonumber(set_lowdmgin) > 0) then
						set_dmgin = 2147483648 * set_highdmgin + set_lowdmgin
						iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
					end
					if (tonumber(set_highdmgout) > 0) or (tonumber(set_lowdmgout) > 0) then
						set_dmgout = 2147483648 * set_highdmgout + set_lowdmgout
						iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
					end
					if (tonumber(set_deaths) > 0) then
						iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
					end
					if (tonumber(set_dispels) > 0) then
						iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
					end
					if (tonumber(set_interrupts) > 0) then
						iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + tonumber(set_interrupts)
					end
					if (tonumber(set_highrawheal) > 0) or (tonumber(set_lowrawheal) > 0) then
						set_rawheal = 2147483648 * set_highrawheal + set_lowrawheal
						iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
						set_overheal = 0
						if (tonumber(set_highoverheal) > 0) or (tonumber(set_lowoverheal) > 0) then
							set_overheal = 2147483648 * set_highoverheal + set_lowoverheal
						end
						m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
						if m>0 then
							iCombatant.TotalOverHeal = m
						end
					end
					if (tonumber(set_timeOut) > 0) then
						iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
					end
					if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
						iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
					end
					if (tonumber(set_timeIn) > 0) then
						iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
					end
					if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
						iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
					end
					if (tonumber(set_timeHeal) > 0) then
						iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
					end
					if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
						iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
					end
				else
					-- format from 4.25 and later
					found,_,set_friend,set_dmgin,set_dmgout,set_maxhit,set_rawheal,set_overheal,set_deaths,set_dispels,set_timeOut,set_timeIn,set_timeHeal,set_highseen,set_lowseen,set_highflags,set_lowflags = string_find(myBase, "(%w+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+%.?%d+) (%d+) (%d+) (%d+) (%d+)")
					if found then
						if (tonumber(set_highseen) > 0) or (tonumber(set_lowseen) > 0) then
							iCombatant.Seen = 2147483648 * set_highseen + set_lowseen
						end
						if (tonumber(set_highflags) > 0) or (tonumber(set_lowflags) > 0) then
							iCombatant.Flags = 2147483648 * set_highflags + set_lowflags
						end
						if set_friend == "true" then
							iCombatant.Friend = true
							rTemp.InFriend[i] = true
						end
						if (tonumber(set_maxhit) > 0) then
							if tonumber(set_maxhit) > (iCombatant.TotalMaxHit or 0) then
								iCombatant.TotalMaxHit = tonumber(set_maxhit)
							end
						end
						if (tonumber(set_dmgin) > 0) then
							iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + tonumber(set_dmgin)
						end
						if (tonumber(set_dmgout) > 0) then
							iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + tonumber(set_dmgout)
						end
						if (tonumber(set_deaths) > 0) then
							iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + tonumber(set_deaths)
						end
						if (tonumber(set_dispels) > 0) then
							iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + tonumber(set_dispels)
						end
						if (tonumber(set_rawheal) > 0) then
							iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + tonumber(set_rawheal)
							m = math_min(((iCombatant.TotalOverHeal or 0) + tonumber(set_overheal)), (iCombatant.TotalRawHeal or 0))
							if m>0 then
								iCombatant.TotalOverHeal = m
							end
						end
						if (tonumber(set_timeOut) > 0) then
							iCombatant.TotalTime = (iCombatant.TotalTime or 0) + tonumber(set_timeOut)
						end
						if  iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
							iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
						end
						if (tonumber(set_timeIn) > 0) then
							iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + tonumber(set_timeIn)
						end
						if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
							iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
						end
						if (tonumber(set_timeHeal) > 0) then
							iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + tonumber(set_timeHeal)
						end
						if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
							iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
						end
					end
				end
			end

			found,_,set_faction,set_class,set_level,set_lowhealth,set_highhealth,set_lowpower,set_highpower,set_powertype,set_gearvalue = string_find(myBase, "~(%d+) (%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%d+)")
			if not found then
				found,_,set_faction,set_class,set_level,set_lowhealth,set_highhealth,set_lowpower,set_highpower,set_powertype = string_find(myBase, "~(%d+) (%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+) (%-?%d+)")
			end
			if not found then
				found,_,set_faction,set_class,set_level = string_find(myBase, "~(%d+) (%d+) (%-?%d+)")
			end
			if not found then
				found,_,set_faction,set_class = string_find(myBase, "~(%d+) (%d+)")
			end
			if found then
				if set_faction and (tonumber(set_faction) > 0) then
					iCombatant.Faction = Recap_GetKey(set_faction)
				end
				if set_class and (tonumber(set_class) > 0) then
					iCombatant.Class = Recap_GetKey(set_class)
				end
				if set_level and (tonumber(set_level) ~= 0) then
					iCombatant.Level = iCombatant.Level or tonumber(set_level)
				end
				if set_lowhealth and (tonumber(set_lowhealth) ~= -9) then
					iCombatant.MinMaxHealth = iCombatant.MinMaxHealth or tonumber(set_lowhealth)
				end
				if set_highhealth and (tonumber(set_highhealth) ~= -9) then
					iCombatant.MaxMaxHealth = iCombatant.MaxMaxHealth or tonumber(set_highhealth)
				end
				if set_lowpower and (tonumber(set_lowpower) ~= -9) then
					iCombatant.MinMaxPower = iCombatant.MinMaxPower or tonumber(set_lowpower)
				end
				if set_highpower and (tonumber(set_highpower) ~= -9) then
					iCombatant.MaxMaxPower = iCombatant.MaxMaxPower or tonumber(set_highpower)
				end
				if set_powertype and (tonumber(set_powertype) ~= -9) then
					iCombatant.PowerType = iCombatant.PowerType or tonumber(set_powertype)
				end
				if set_gearvalue then
					iCombatant.GearValue = iCombatant.GearValue or tonumber(set_gearvalue)
				end
			end
		end

		-- Outgoing Details
		myOut = setCombatant[i].Out
		if myOut then
			if type(myOut) == "string" then
				Recap_LoadOutgoingDetails(iCombatant, myOut)
			else
				-- table of strings
				for j in pairs(myOut) do
					Recap_LoadOutgoingDetails(iCombatant, myOut[j])
				end
			end
		end

		-- Target Details
		myTarget = setCombatant[i].Target
		if myTarget then
			if type(myTarget) == "string" then
				Recap_LoadTargetDetails(iCombatant, myTarget)
			else
				-- table of strings
				for j in pairs(myTarget) do
					Recap_LoadTargetDetails(iCombatant, myTarget[j])
				end
			end
		end

		-- Incoming Details
		myIn = setCombatant[i].In
		if myIn then
			if type(myIn) == "string" then
				Recap_LoadIncomingDetails(iCombatant, myIn)
			else
				-- table of strings
				for j in pairs(myIn) do
					Recap_LoadIncomingDetails(iCombatant, myIn[j])
				end
			end
		end

		-- Source Details
		mySource = setCombatant[i].Source
		if mySource then
			if type(mySource) == "string" then
				Recap_LoadSourceDetails(iCombatant, mySource)
			else
				-- table of strings
				for j in pairs(mySource) do
					Recap_LoadSourceDetails(iCombatant, mySource[j])
				end
			end
		end

		-- Other Details
		myOther = setCombatant[i].Other
		if myOther then
			if type(myOther) == "string" then
				Recap_LoadOtherDetails(iCombatant, myOther)
			else
				-- table of strings
				for j in pairs(myOther) do
					Recap_LoadOtherDetails(iCombatant, myOther[j])
				end
			end
		end
	end
end

-- function to estimate combined size of saved data sets (and save answer first time we do this)
function Recap_EstimateSavedDataSetsSize()

	local rSet = _G.recap_set
	local estSize, filen

	estSize = 0
	for filen in pairs(rSet) do
		if not rSet[filen].EstimatedDataSetSize then
			-- we haven't calculated this before
			rSet[filen].EstimatedDataSetSize = Recap_EstimateSavedDataSetSize(filen)
		end
		estSize = estSize + rSet[filen].EstimatedDataSetSize
	end
	return estSize
end

function Recap_ResetAllCombatants(overrideLocks)

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local current_state = rUser.State
	rTemp.SkipPeriodicUpdate = true -- skip periodic update
	rUser.State = "Stopped"
	rUser.SkipNextFight = false
	rUser.PrevTimeBase = nil

	-- scan combatants and save a copy of any combatant marked as Locked (unless in synchronization)
	local i
	local local_save = {}
	if not overrideLocks then
		for i in pairs(rCombatants) do
			if rCombatants[i].Locked then
				local_save[i] = rCombatants[i]
			end
		end
	end
	-- clear all combatants
	recap_combatants = wipe(recap_combatants)
	-- restore the saved combatants (unless in synchronization)
	if not overrideLocks then
		for i in pairs(local_save) do
			rCombatants[i] = local_save[i]
		end
	end
	rTemp.Last = wipe(rTemp.Last)
	for i in pairs(rCombatants) do
		Recap_InitializeLastFight(i)
	end
	-- Note that LastDuration (etc.) refers only to a displayed Last Fight
	rUser.LastDuration = 0
	rUser.LastDurationIn = 0
	rUser.LastDurationHeal = 0
	rUser.TotalDuration = 0
	rUser.TotalDurationIn = 0
	rUser.TotalDurationHeal = 0
	rTemp.FightStart = 0
	rTemp.FightEnd = 0
	rTemp.FightStartIn = 0
	rTemp.FightEndIn = 0
	rTemp.FightStartHeal = 0
	rTemp.FightEndHeal = 0
	rTemp.ListSize = 0
	rTemp.List = wipe(rTemp.List)

	-- clear variables for live DPS and HPS
	rTemp.PlayerDPSLast = 0
	rTemp.PlayerDPSAll = 0
	rTemp.PlayerDmgLast = 0
	rTemp.PlayerDmgAll = 0
	rTemp.PlayerPetPercentLast = 0
	rTemp.PlayerPetPercentAll = 0
	rTemp.PlayerMaxHitLast = 0
	rTemp.PlayerMaxHitAll = 0
	rTemp.PlayerDmgInLast = 0
	rTemp.PlayerDmgInAll = 0
	rTemp.PlayerHPSLast = 0
	rTemp.PlayerHPSAll = 0
	rTemp.PlayerHealingLast = 0
	rTemp.PlayerHealingAll = 0
	rTemp.PlayerOverhealingLast = 0
	rTemp.PlayerOverhealingAll = 0
	rTemp.TotalGroupDmgIn = 0
	rTemp.TotalGroupDmgOut = 0
	rTemp.TotalGroupHeal = 0
	rTemp.GroupDPSOutLast = 0
	rTemp.GroupDPSInLast = 0
	rTemp.GroupHPSLast = 0
	rTemp.GroupDPSOutAll = 0
	rTemp.GroupDPSInAll = 0
	rTemp.GroupHPSAll = 0

	-- let the plugins know if necessary
	Recap_DisplayMinimizedDPS()

	-- if Recent Data Mode is active, clear the buffers
	if rOpt.RecentData.value then
		Recap_CreateRecent()
	else
		rTemp.Recent = wipe(rTemp.Recent)
		rTemp.RecentFriendDeaths = wipe(rTemp.RecentFriendDeaths)
	end

	-- clear the special case registration tables
	rTemp.ShieldRegistration = {}

	-- make sure end of fight delay timer is off
	rTemp.EndFightDelayTimer = -1

	-- need to set idle timer if we were in combat
	if current_state == "Active" then
		-- start idle timers
		if not rOpt.LimitFights.value and rOpt.IdleFight.value then
			rTemp.IdleTimer = 0
		end
		if not rOpt.LimitFights.value then
			rTemp.HiddenIdleTimer = 0
		end
	end

	-- set the option count on every reset
	if not rRecap.UserOptionsCount then
		rRecap.UserOptionsCount = {}
	end
	rRecap.UserOptionsCount[rTemp.p] = Recap_CountOptions()

	rUser.State = current_state
	rTemp.SkipPeriodicUpdate = false -- resume periodic update
end

function RecapLoad_ResetAllCombatants()
	local rTemp = _G.recap_temp
	rTemp.Load = wipe(rTemp.Load)
	rTemp.LoadTotalDuration = 0
	rTemp.LoadTotalDurationIn = 0
	rTemp.LoadTotalDurationHeal = 0
	rTemp.LoadListSize = 0
	rTemp.LoadList = wipe(rTemp.LoadList)
end

-- creates a new .Load[thisCombatant]
function RecapLoad_CreateBlankCombatant(thisCombatant)
	local rLoad = _G.recap_temp.Load
	if not rLoad[thisCombatant] then
		rLoad[thisCombatant] = { Friend = false }
	end
end

function Recap_CloneOpt(iOptSource, iOptTarget)

	local i, j

	for i in pairs(iOptSource) do
		if not iOptTarget[i] then
			iOptTarget[i] = {}
			for j in pairs(iOptSource[i]) do
				iOptTarget[i][j] = iOptSource[i][j]
			end
		end
	end

	-- TODO: there are a couple of options that have caused problems by being unexpectedly missing (for no reason I have been able to diagnose), so add bandaid fixes here
	if not iOptTarget.IgnoreGUIDs then
		iOptTarget.IgnoreGUIDs = { type="Check", value=false }
	end
	if not iOptTarget.LDBSupport then
		iOptTarget.LDBSupport = { type="Check", value=false }
	end
end

function Recap_ProcessObsoleteOptions(iOpt)

	local rUser = _G.recap_user

	-- fix for 4.36 and later
	if iOpt.CollectGarbage then
		iOpt.CollectGarbage = nil
	end
	if iOpt.UseColor then
		iOpt.UseColor = nil
	end
	if iOpt.Kills then
		iOpt.Deaths = { type="Check", value=iOpt.Kills.value, width=31 }
		iOpt.Kills = nil
	end
end

function Recap_SetUpOptions()

	local rRecap = _G.recap
	local rSet = _G.recap_set
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, j, k, dataset

	-- this function includes some data conversion which is not strictly options-related, but which can be done now

	-- data integrity check
	-- saved options count is filled in as each character logs off, and is used to detect if recap_user has maybe been borked
	if not rRecap.UserOptionsCount then
		rRecap.UserOptionsCount = {}
	end
	if rRecap.UserOptionsCount[rTemp.p] and (rRecap.UserOptionsCount[rTemp.p] ~= Recap_CountOptions()) then
		-- count mismatch, possible damaged data
		-- always restore settings from backup
		Recap_RestoreCharacterSettings(false)
		-- warn the user to consider copying their SavedVariables data file
		StaticPopupDialogs["rTemp.DAMAGEDDATAWARNING"] = {
			text = string_format(rLocalize.DamagedDataWarning, rTemp.Player, rTemp.Server, rTemp.Player),
			button1 = OKAY,
			OnAccept = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.DAMAGEDDATAWARNING")
	end
	-- note that the above dialog is non-blocking

	-- OBSOLETE: one time only, handle old style 'in memory' options, removed with 4.77
	-- OBSOLETE: assert: after one execution of Recap there are no more 'in memory' options

	-- check whether we have new format options
	if rUser.Opt then
		-- yes, process any obsolete options
		-- note that we do this every time, since per character data is only upgraded when accessed
		Recap_ProcessObsoleteOptions(rUser.Opt)
	else
		-- no, start with an empty table
		rUser.Opt = {}
	end

	-- add any options that are missing (to avoid error messages about 'nil' values)
	-- note that we do this every time, since per character data is only upgraded when accessed
	Recap_CloneOpt(rTemp.DefaultOpt, rUser.Opt)

	-- special setting of End Fight Delay default to 3 seconds, starting with version 4.36
	--	 note that going to 0 seconds segments ordinary fights too easily, at least with Spirit of Redemption happening
	--	 setting it to 2 seconds with version 4.31 still allowed spurious segmentation, trying 3 now (seems to work better)
	if (rUser.DataVersion == nil) or (rUser.DataVersion < 4.36) then
		rUser.Opt.EndFightDelay.value = rTemp.DefaultOpt.EndFightDelay.value
	end


	-- TODO: here we would do any other future version upgrades for recap_user


	-- make sure a few non-option fields are present
	rUser.LastDuration = (rUser.LastDuration or 0)
	rUser.LastDurationIn = (rUser.LastDurationIn or 0)
	rUser.LastDurationHeal = (rUser.LastDurationHeal or 0)
	rUser.TotalDuration = (rUser.TotalDuration or 0)
	rUser.TotalDurationIn = (rUser.TotalDurationIn or 0)
	rUser.TotalDurationHeal = (rUser.TotalDurationHeal or 0)
	-- the following used to be 'options'
	-- note this is being done to make these flags continue to be user-specific when UseOneSettings is turned on
	if rUser.SortBy == nil then
		rUser.SortBy = "Name"
	end
	if rUser.SortDir == nil then
		rUser.SortDir = true
	end
	if rUser.ESortBy == nil then
		rUser.ESortBy = "ETotal"
	end
	if rUser.ESortDir == nil then
		rUser.ESortDir = true
	end
	if rUser.State == nil then
		rUser.State = "Idle"
	end
	if rUser.Visible == nil then
		rUser.Visible = true
	end
	if rUser.NumPartyMembers == nil then
		rUser.NumPartyMembers = 1 -- for figuring out when we join a party (transition from 1 to 2+)
	end
	if rUser.InsideInstance == nil then
		rUser.InsideInstance = false -- for figuring out when we enter an instance (transition from false to true)
	end
	if rUser.InsideBattleground == nil then
		rUser.InsideBattleground = false -- for figuring out when we enter a battleground (transition from false to true)
	end
	if rUser.SyncState == nil then
		rUser.SyncState = "Ignore" -- Ignore, Ready, Member, Leader
	end
	if rUser.SyncTimestamp == nil then
		rUser.SyncTimestamp = false -- only belong to a synchronization with this timestamp (integer thousandths)
	end
	if rUser.SyncLeader == nil then
		rUser.SyncLeader = false -- the leader of the synchronization (Name_GUID_Server)
	end
	if rUser.SyncLeaderName == nil then
		rUser.SyncLeaderName = false -- the name of the leader of the synchronization
	end
	if rUser.SyncLeaderServer == nil then
		rUser.SyncLeaderServer = false -- the server of the leader of the synchronization
	end
	if rUser.SyncMergePets == nil then
		rUser.SyncMergePets = false -- whether the synchronization runs with Merge Pets: 'off' or 'on'
	end
	if rUser.SyncUpdateWhen == nil then
		rUser.SyncUpdateWhen = false -- local time of latest update (integer thousandths)
	end
	if rUser.Minimized == nil then
		rUser.Minimized = false
	end
	if rUser.Pinned == nil then
		rUser.Pinned = false
	end
	if rUser.SelfView == nil then
		rUser.SelfView = false
	end
	if rUser.View == nil then
		rUser.View = "All"
	end
	if rUser.PanelView == nil then
		rUser.PanelView = 1 -- current panel tab
	end
	if rUser.RecentView == nil then
		rUser.RecentView = 1 -- current recent tab
	end
	if rUser.PanelAnchor == nil then
		rUser.PanelAnchor = { value=false, Main="TOPLEFT", Panel="TOPRIGHT" }
	end
	if rUser.RecentAnchor == nil then
		rUser.RecentAnchor = { value=false, Main="TOPLEFT", Panel="TOPRIGHT" }
	end
	if rUser.LoadAnchor == nil then
		rUser.LoadAnchor = { value=false, Main="TOPLEFT", Panel="TOPRIGHT" }
	end
	if rUser.GraphAnchor == nil then
		rUser.GraphAnchor = { value=false, Main="TOPLEFT", Panel="TOPRIGHT" }
	end
	if rUser.ClipFrameAnchor == nil then
		rUser.ClipFrameAnchor = { value=false, Main="TOPLEFT", Panel="TOPRIGHT" }
	end

	-- we might have changed the number of options if we had a version upgrade, so write that (for the integrity check)
	-- note that we do this every time, since per character data is only upgraded when accessed
	rRecap.UserOptionsCount[rTemp.p] = Recap_CountOptions()

	-- set up global options if needed, point recap_temp.Opt at the set to use
	if rRecap.UseOneSettings then
		-- a single set of options for all users
		if not rRecap.GlobalOpt then
			rRecap.GlobalOpt = {}
		end
		-- add missing options (initializes with defaults if the list was empty)
		Recap_CloneOpt(rTemp.DefaultOpt, rRecap.GlobalOpt)
		-- get rid of any obsolete options
		Recap_ProcessObsoleteOptions(rRecap.GlobalOpt)
		recap_temp.Opt = rRecap.GlobalOpt
	else
		recap_temp.Opt = rUser.Opt
	end


	-- now for combatants similarly
	-- advantage is that there is generally less data lying around
	-- advantage is that there is no conversion to and from strings when switching users
	-- disadvantage is that if one user's combatants have a data load problem (before VARIABLES_LOADED) it will take down the user's options also
	-- disadvantage is that a bit more disk space is needed since combatant data is no longer stored in compressed format when not in use

	-- OBSOLETE: one time only, handle old style 'in memory' combatants (code removed with 4.77)
	-- OBSOLETE: assert: after one execution of Recap there are no more 'in memory' combatants (i.e. no recap.Combatant)

	-- we have two situations at this point
	-- a) recap_combatants has combatants (recap_compressed should have none)
	-- b) recap_compressed has combatants in compressed form (recap_combatants should have none)
	if recap_compressed then
		-- if we have compressed data, overwrite any uncompressed data that we happen to have
		Recap_DecompressCombatants()
		-- assert: the compressed data are still there so that they won't be lost if we happen to disconnect instead of saving recap_combatants
	end


	-- Here we do any version upgrades for recap_combatants


	-- update our user
	rRecap.User = rTemp.p

	-- update our data versions
	rUser.DataVersion = Recap_Version
	rRecap.DataVersion = Recap_Version

end

function Recap_CountOptions()

	local rUser = _G.recap_user
	local i, j

	if not rUser.Opt then
		return nil
	end
	if type(rUser.Opt) ~= "table" then
		return nil
	end

	j = 0
	for i in pairs(rUser.Opt) do
		j = j + 1
	end

	return j
end

-- copy per character options (expects copyTo to be an empty table)
function Recap_CopyUserSettings(copyFrom, copyTo)

	local i, j, k

	for i in pairs(copyFrom) do
		if type(copyFrom[i]) == "table" then
			-- sub-table
			copyTo[i] = {}
			for j in pairs(copyFrom[i]) do
				if type(copyFrom[i][j]) == "table" then
					-- sub-sub-table
					copyTo[i][j] = {}
					for k in pairs(copyFrom[i][j]) do
						-- simple data (we hope)
						copyTo[i][j][k] = copyFrom[i][j][k]
					end
				else
					-- simple data
					copyTo[i][j] = copyFrom[i][j]
				end
			end
		else
			-- simple data
			copyTo[i] = copyFrom[i]
		end
	end
end

local function Recap_WarnNoBackupSettings()
	local rTemp = _G.recap_temp
	StaticPopupDialogs["rTemp.NOBACKUPSETTINGS"] = {
		text = rLocalize.NoBackupSettings,
		button1 = OKAY,
		OnAccept = function(self)
		end,
		timeout = 30,
		showAlert = 1,
		whileDead = 1
	}
	StaticPopup_Show("rTemp.NOBACKUPSETTINGS")
end

function Recap_RestoreCharacterSettings(reload)
	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if recap_back and recap_back[rTemp.p] and (type(recap_back[rTemp.p]) == "table") then
		-- start with a clean slate
		recap_user = wipe(recap_user)
		Recap_CopyUserSettings(recap_back[rTemp.p], rUser)
		if not rRecap.UserOptionsCount then
			rRecap.UserOptionsCount = {}
		end
		rRecap.UserOptionsCount[rTemp.p] = Recap_CountOptions()
		if reload then
			ReloadUI()
		end
	else
		-- there doesn't seem to be a backup available, so at least create some default options
		if not rUser.Opt then
			-- create an empty table
			rUser.Opt = {}
		end
		Recap_CloneOpt(rTemp.DefaultOpt, rUser.Opt)
		if not rRecap.UserOptionsCount then
			rRecap.UserOptionsCount = {}
		end
		rRecap.UserOptionsCount[rTemp.p] = Recap_CountOptions()
		PlaySound("igQuestFailed")
		Recap_WarnNoBackupSettings()
	end
end

-- check new data set for oversize, pop dialog as necessary, nuke data if requested, and return a flag saying that the user has completed the dialog
-- note that this function will return immediately, before the user has had a chance to interact with any dialog, because dialogs are not blocking
-- the function PeriodicUpdate will continually check the flags and do the full data initialization when the flags say it is good to go
function Recap_WarnDataSize()

	local rRecap = _G.recap
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, j, combCount, estSize, _, user

	-- recap_combatants contains data for the new user

	combCount = 0
	for i in pairs(rCombatants) do
		for j in pairs(rCombatants[i]) do
			-- count only combatants with data
			combCount = combCount + 1
			break
		end
	end

	if combCount > 2000 then
		if rRecap.User then
			_, _, user = string_find(rRecap.User, "^([^_]*)_[^_]*$")
			if not user then
				user = rLocalize.Unknown
			end
		else
			user = rLocalize.Unknown
		end
		StaticPopupDialogs["rTemp.LOTSOFDATAWARNING"] = {
			text = string_format(rLocalize.LotsOfDataWarning, combCount, user),
			button1 = BINDING_NAME_RECAP_RESET_ALL,
			button2 = OKAY,
			OnAccept = function(self)
				-- nuke recap_combatants
				PlaySound("GnomeExploration")
				Recap_ResetAllCombatants(false)
				rTemp.FlagDataSizeDialogDone = true
			end,
			OnHide = function(self)
				rTemp.FlagDataSizeDialogDone = true
			end,
			OnCancel = function(self)
				rTemp.FlagDataSizeDialogDone = true
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.LOTSOFDATAWARNING")
	else
		-- data is within limits
		rTemp.FlagDataSizeDialogDone = true
	end

	-- combined size of saved data sets

	estSize = Recap_Div0(Recap_EstimateSavedDataSetsSize(), 990000) -- we assume an additional overhead of about 1%

	if estSize > 40 then
		StaticPopupDialogs["rTemp.SAVEDDATASETSSIZEWARNING"] = {
			text = string_format(rLocalize.SavedDataSetsSizeWarning, estSize),
			button1 = OKAY,
			OnAccept = function(self)
			end,
			OnHide = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.SAVEDDATASETSSIZEWARNING")
	end
end

function Recap_ReloadUI()
	local rTemp = _G.recap_temp
	rTemp.DoingReloadUI = true
	-- execute the original reloadui
	rTemp.Original_ReloadUI()
end

function Recap_ConsoleExec(command)
	local rTemp = _G.recap_temp
	if command and string_find(string_lower(command), "reloadui", 1, true) then
		rTemp.DoingReloadUI = true
	end
	-- execute the original console command
	rTemp.Original_ConsoleExec(command)
end

function Recap_InitializeDataAndDisplay()

	local rRecap = _G.recap
	local rCombatants = _G.recap_combatants
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, j, count, iCombatant

	-- we have the right data already in recap_combatants

	-- do a few repairs

	for i in pairs(rCombatants) do
		Recap_InitializeLastFight(i)

		-- special case correction for some damage:healing DoT:HoT spells
		iCombatant = rCombatants[i]
		Recap_CorrectDualDoTHoT(iCombatant, "OutgoingDetail", "IncomingDetail") -- no need to do for Last, which should be empty
	end

	Recap_LoadSelf()

	-- clean out empty Self entries
	local rSelf = _G.recap.Self
	for i in pairs(rSelf) do
		count = 0
		for j in pairs(rSelf[i]) do
			count = count + 1
		end
		if count==0 then
			-- nothing left, clear it out entirely
			rSelf[i] = nil -- keep as nil
		end
	end

	-- special case correction for some damage:healing DoT:HoT spells
	Recap_CorrectDualDoTHoTForSelf()

	-- other general setup for processing and display

	for i, iCombatant in pairs(rCombatants) do
		iCombatant.WasInCurrent = false
		iCombatant.WasInLast = false
		-- clear both of the Last Fight detail data structures before we start
		iCombatant.LastTime_1 = nil
		iCombatant.LastTimeIn_1 = nil
		iCombatant.LastTimeHeal_1 = nil
		iCombatant.LastMaxHit_1 = nil
		iCombatant.LastDmgIn_1 = nil
		iCombatant.LastDmgOut_1 = nil
		iCombatant.LastHPS_1 = nil
		iCombatant.LastDPSIn_1 = nil
		iCombatant.LastDPS_1 = nil
		iCombatant.LastGearValue_1 = nil
		iCombatant.LastDeaths_1 = nil
		iCombatant.LastDispels_1 = nil
		iCombatant.LastInterrupts_1 = nil
		iCombatant.LastRawHeal_1 = nil
		iCombatant.LastOverHeal_1 = nil
		iCombatant.LastOutgoingDetail_1 = nil
		iCombatant.LastTargetDetail_1 = nil
		iCombatant.LastIncomingDetail_1 = nil
		iCombatant.LastSourceDetail_1 = nil
		iCombatant.LastOtherDetail_1 = nil
		iCombatant.LastTime_2 = nil
		iCombatant.LastTimeIn_2 = nil
		iCombatant.LastTimeHeal_2 = nil
		iCombatant.LastMaxHit_2 = nil
		iCombatant.LastDmgIn_2 = nil
		iCombatant.LastDmgOut_2 = nil
		iCombatant.LastHPS_2 = nil
		iCombatant.LastDPSIn_2 = nil
		iCombatant.LastDPS_2 = nil
		iCombatant.LastGearValue_2 = nil
		iCombatant.LastDeaths_2 = nil
		iCombatant.LastDispels_2 = nil
		iCombatant.LastInterrupts_2 = nil
		iCombatant.LastRawHeal_2 = nil
		iCombatant.LastOverHeal_2 = nil
		iCombatant.LastOutgoingDetail_2 = nil
		iCombatant.LastTargetDetail_2 = nil
		iCombatant.LastIncomingDetail_2 = nil
		iCombatant.LastSourceDetail_2 = nil
		iCombatant.LastOtherDetail_2 = nil
	end
	rTemp.ActiveLastFight = "1" -- set the Last Fight variables that we will begin storing into
	rTemp.DisplayLastFight = "2" -- set the Last Fight variables that we will begin displaying from
	-- Note that I think LastDuration (etc.) should refer only to a displayed Last Fight
	rUser.LastDuration = 0
	rUser.LastDurationIn = 0
	rUser.LastDurationHeal = 0
	-- silent repair
	if not rSelf[rTemp.s] then
		rSelf[rTemp.s] = {}
	end
	-- not at the moment being done for the player's pets

	-- initialize Recent Events storage
	if rOpt.RecentData.value then
		Recap_CreateRecent()
	else
		rTemp.Recent = wipe(rTemp.Recent)
		rTemp.RecentFriendDeaths = wipe(rTemp.RecentFriendDeaths)
	end

	Recap_SetColors()
	RecapLoad_SetColors()

	-- was 82 now 144
	RecapTotals_Name:SetWidth(rTemp.NameWidth)

	Recap_InitDataSets()
	Recap_InitIgnores()

	if rOpt.LightData.value then
		rUser.SelfView = false
		RecapSelfViewButton:Hide()
	end

	if rUser.Minimized then
		Recap_SetButtons()
		Recap_ConstructList()
		Recap_Minimize()
	else
		Recap_Maximize()
	end

	Recap_Register_CombatEvents()

	-- more setup
	Recap_ClearAsIfEndOfFight()
	Recap_SetState(false)
	Recap_InitializeOptions()
	Recap_MoveMinimize()
	Recap_SetRecapFrameBackdrop()

	-- initialize panel
	rTemp.Selected = 0
	rTemp.RecentSelected = 0
	if rOpt.LightData.value then
		rUser.PanelView = 6
		RecapPanelTab1:SetAlpha(.5)
		RecapPanelTab2:SetAlpha(.5)
		RecapPanelTab3:SetAlpha(.5)
		RecapPanelTab4:SetAlpha(.5)
		RecapPanelTab5:SetAlpha(.5)
	end
	RecapPanel_SwitchPanels(rUser.PanelView)
	if rUser.PanelAnchor.value then
		RecapPanel:ClearAllPoints()
		RecapPanel:SetPoint(rUser.PanelAnchor.Panel,"RecapFrame",rUser.PanelAnchor.Main,Recap_PanelOffset("x"),Recap_PanelOffset("y"))
	end

	-- initialize Recent
	RecapRecent_SwitchRecents(false, false)
	if rUser.RecentAnchor.value then
		RecapRecent:ClearAllPoints()
		RecapRecent:SetPoint(rUser.RecentAnchor.Recent,"RecapFrame",rUser.RecentAnchor.Main,Recap_RecentOffset("x"),Recap_RecentOffset("y"))
	end

	-- initialize Load
	if rUser.LoadAnchor.value then
		RecapLoad:ClearAllPoints()
		RecapLoad:SetPoint(rUser.LoadAnchor.Load,"RecapFrame",rUser.LoadAnchor.Main,Recap_LoadOffset("x"),Recap_LoadOffset("y"))
	end

	-- initialize Graph
	RecapGraph_SwitchGraphText()
	if rUser.GraphAnchor.value then
		RecapGraph:ClearAllPoints()
		RecapGraph:SetPoint(rUser.GraphAnchor.Graph,"RecapFrame",rUser.GraphAnchor.Main,Recap_GraphOffset("x"),Recap_GraphOffset("y"))
	end

	-- initialize clipboard
	if rUser.ClipFrameAnchor.value then
		RecapClipFrame:ClearAllPoints()
		RecapClipFrame:SetPoint(rUser.ClipFrameAnchor.ClipFrame,"RecapFrame",rUser.ClipFrameAnchor.Main,Recap_ClipFrameOffset("x"),Recap_ClipFrameOffset("y"))
	end

	-- clear any Sync values dependent on time, since we can't get times that are good across reboots
	if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
		rUser.SyncUpdateWhen = math_floor(1000*GetTime()) -- integer thousandths
		rTemp.SyncData = wipe(rTemp.SyncData)
		rTemp.SyncInviteTimestamp = false
		rTemp.SyncInviteLeader = false
		rTemp.SyncInviteMergePets = false
		rTemp.SyncInviteWhen = false
		rTemp.SyncInviteNewOngoing = false
		rTemp.AskingJoinSync = false
		rTemp.OnCommReceived = false
	end

	if rUser.Visible then
		RecapFrame_Show()
	else
		RecapFrame_Hide()
	end

	-- set frames that need to see the Escape key
	table_insert(UISpecialFrames, "RecapOptFrame")
	table_insert(UISpecialFrames, "RecapClipFrame")
	table_insert(UISpecialFrames, "RecapPanel")
	table_insert(UISpecialFrames, "RecapRecent")
	table_insert(UISpecialFrames, "RecapLoad")
	-- Note that RecapGraph is not made a special frame, since we need to have it stay up when displaying live
	table_insert(UISpecialFrames, "RecapGraphOptions")

	-- added main frame so that we can trap Escape and minimize instead
	if rUser.Minimized or not rOpt.MinimizeOnEscape.value then
		-- a dummy if we are minimized or have Minimize on Escape turned off, so that we don't capture Escape when minimized
		table_insert(UISpecialFrames, "RecapFrameDummy")
	else
		table_insert(UISpecialFrames, "RecapFrame")
	end

	-- hook ReloadUI so we can distinguish between logout and reloadui
	rTemp.Original_ReloadUI = ReloadUI
	rTemp.DoingReloadUI = false
	hooksecurefunc("ReloadUI", Recap_ReloadUI);

	-- similarly hook ConsoleExec so we can distinguish between logout and reloadui
	rTemp.Original_ConsoleExec = ConsoleExec
	hooksecurefunc("ConsoleExec", Recap_ConsoleExec);

	-- enable LDB support if appropriate
	if rOpt.LDBSupport.value then
		Recap_EnableLDBSupport()
	end

	-- enable live Graph support, but don't show the live panel
	if rOpt.LiveData.value then
		if (recapLineGraph == nil) or (recapLineGraphPanel == nil) then
			Recap_EnableGraph()
		end
		RecapGraph_InitializeLiveLists()
	end

	-- special calculation of initial 'live' numbers
	Recap_StartupMinimizedDPS()
	Recap_DisplayMinimizedDPS() -- also sends to plugins

end



--[[ Fight report functions ]]

function Recap_AutoPostGetStatID(myType)

	if myType=="Damage" then
		return "DmgOut"
	elseif myType=="Tanking" then
		return "DmgIn"
	elseif myType=="Healing" then
		return "Heal"
	end
	return "DPS"
end

function Recap_PostFight()
	local rOpt = _G.recap_temp.Opt
	Recap_PostSpamRows(Recap_AutoPostGetStatID(rOpt.AutoPost.Stat), true, true)
end

function Recap_PostLeader()
	-- hmm, this had been broken in more than one way since at least Gello's 3.32 -- only found and fixed 2010-May-17 -- my fix might still be a bit messy still, I haven't double-checked for optimization

	local rCombatants = _G.recap_combatants
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local print_chat = SendChatMessage
	local i, chatchan, _, chatnum, newLeader, statid, thisCombatant

	if rTemp.ListSize>2 then
		chatchan = rOpt.AutoPost.Channel
		-- de-localize the channel name
		for i=1,5 do -- hardcoded
			if chatchan == rLocalize.ChannelDropList[i] then
				chatchan = rTemp.CanonicalChannelDropList[i]
				break
			end
		end
		if not chatchan then
			chatchan = "Self"
		end
		_,_,chatnum = string_find(chatchan, "(%d+)")
		if chatnum then
			chatchan = "CHANNEL"
		end
		if chatchan=="Self" then
			print_chat = Recap_Print
		end

		-- 2012-Dec-08 TODO no provision for whispering or BN whispering, so no presenceID, no call to Recap_SendChatMessage

		-- If the Clipboard is open, post there instead of to chat or console
		if RecapClipEditBox:IsVisible() then
			print_chat = Recap_LineToClipboard
		end

		statid = Recap_AutoPostGetStatID(rOpt.AutoPost.Stat)

		if not rCombatants[rTemp.StatLeader] then -- in case leader reset
			rTemp.StatLeader = false
		end
		if rTemp.StatLeader then
			-- is leader still in List ?
			if not Recap_FindInList(rTemp.StatLeader) then
				rTemp.StatLeader = false
			end
		end

		if (not rTemp.StatLeader) then
			thisCombatant = rTemp.List[1].Name
			if thisCombatant and rCombatants[thisCombatant] and rCombatants[thisCombatant].Friend then
				rTemp.StatLeader = thisCombatant
				newLeader = thisCombatant -- start with first friendly player on list (if any), since we didn't have a leader
			end
		end
		-- assert: newLeader will be nil if previous leader has disappeared and we haven't got a possible replacement
		-- assert: if rTemp.StatLeader exists then rTemp.StatLeader is in the List

		if rTemp.StatLeader and rCombatants[rTemp.StatLeader] then
			local iLeader = Recap_FindInList(rTemp.StatLeader)
			local listLeader = rTemp.List[iLeader]
			for i in pairs(rTemp.InFriend) do
				if rCombatants[i] then
					-- find this combatant in the list
					local iCombatant = Recap_FindInList(i)
					if iCombatant then
						local listCombatant = rTemp.List[iCombatant]
						if listCombatant[statid] and listLeader[statid] and (listCombatant[statid] > listLeader[statid]) then
							rTemp.StatLeader = i
							iLeader = Recap_FindInList(i)
							listLeader = rTemp.List[iLeader]
							newLeader = i
						end
					end
				end
			end
			-- assert: newLeader will be nil if no change
			if newLeader then
				rTemp.StatLeader = newLeader
				iLeader = Recap_FindInList(newLeader)
				listLeader = rTemp.List[iLeader]
				if print_chat(string_format(rLocalize.NewLeader.." "..rLocalize.For.." %s ("..rLocalize.LastAll[rUser.View].."): %s "..recap_temp.Localize.With.." %s",rOpt.AutoPost.Stat,Recap_StripGUIDsFromCombatant(newLeader),Recap_FormatStat(statid,listLeader)), chatchan, nil, chatnum) then
					-- a non-nil return indicates clipboard full
					-- should not happen as of 4.62, but leave the if statement in case
				end
			end
		end

		if RecapClipEditBox:IsVisible() then
			RecapClipEditBox:HighlightText()
			RecapClipEditBox:SetFocus()
		end
	end
end

-- function to package channel info calculation
function Recap_GetChannelInfo(recapAuto, forceSelf)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, chatchan, _, chatnum, presenceID

	chatchan = false
	chatnum = false
	presenceID = false
	if recapAuto then
		chatchan = rOpt.AutoPost.Channel
		-- de-localize the channel name
		for i=1,5 do -- hardcoded
			if chatchan == rLocalize.ChannelDropList[i] then
				chatchan = rTemp.CanonicalChannelDropList[i]
				break
			end
		end
	else
		if forceSelf then
			chatchan = "Self"
		else
			local editBox = ChatEdit_GetActiveWindow()
			if editBox then
				chatchan = string_upper(editBox:GetAttribute("chatType"))
				if chatchan=="WHISPER" then
					chatnum = editBox:GetAttribute("tellTarget")
				elseif chatchan=="BN_WHISPER" then
					chatnum = editBox:GetAttribute("tellTarget") -- 'chatnum' should contain a string
					presenceID = BNet_GetPresenceID(chatnum)
					if not presenceID then
						-- anomaly, change to Self rather than emit error message
						chatchan = "Self"
					end
				elseif chatchan=="CHANNEL" then
					chatnum = editBox:GetAttribute("channelTarget")
				elseif chatchan=="BN_CONVERSATION" then
					chatnum = editBox:GetAttribute("channelTarget")
					local conversationInfo = BNGetConversationInfo(chatnum - MAX_WOW_CHAT_CHANNELS) -- returns text "conversation" if okay
					if not conversationInfo then
						-- anomaly, change to Self rather than emit error message
						chatchan = "Self"
					end
				end
			end
		end
	end
	if not chatchan then
		chatchan = "Self"
	end
	if not chatnum then
		_,_,chatnum = string_find(chatchan, "(%d+)")
		if chatnum then
			chatchan = "CHANNEL"
		end
	end

	return chatchan, chatnum, presenceID
end

-- to handle BN whispers and regular messages
function Recap_SendChatMessage(msg, chatchan, language, chatnum, presenceID)

	if (chatchan == "BN_WHISPER") and presenceID then
		BNSendWhisper(presenceID, msg)
		-- in theory if BN_WHISPER then presenceID should be non-nil, and vice-versa
	elseif (chatchan == "BN_CONVERSATION") then
		BNSendConversationMessage(chatnum, msg)
	else
		SendChatMessage(msg, chatchan, nil, chatnum)
	end
end

-- type = stat to report by (DPS, DmgOut, etc)
function Recap_PostSpamRows(myType, recapAuto, postFriends)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, thisCombatant, text, nLines
	local headertext = nil -- keep as nil
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value
	local iType = string_gsub(myType, "P$","") -- strip trailing P from % ids

	chatchan, chatnum, presenceID = Recap_GetChannelInfo(recapAuto, nil)
	if chatchan=="Self" then
		print_chat = Recap_Print
	end

	-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
	if Recap_WIMFindFocus() then
		print_chat = Recap_WIM_Print
	end

	-- If the Clipboard is open, post there instead of to chat or console
	if RecapClipEditBox:IsVisible() then
		print_chat = Recap_LineToClipboard
		maxLines = rTemp.MaxLinesToClipboard
	end

	headertext = "__ Recap ("..rLocalize.LastAll[rUser.View]..") ("..Recap_PetsMergedText().."): "..rLocalize.LinkRank[iType].." __"
	nLines = 0
	for i=1, 1000 do
		if rTemp.List[i] and rTemp.List[i].Name then
			thisCombatant = rTemp.List[i].Name
			if (i<rTemp.ListSize) and thisCombatant and rCombatants[thisCombatant] and ((rCombatants[thisCombatant].Friend and postFriends) or
																					   ((not rCombatants[thisCombatant].Friend) and (not postFriends))) then
				text = nil
				if iType == "Name" then
					text = i..". "..Recap_StripGUIDsFromCombatant(thisCombatant)
				else
					if rTemp.List[i][iType] and rTemp.List[i][iType] > 0 then
						local listCombatant = rTemp.List[i]
						local iName = i..". "..Recap_StripGUIDsFromCombatant(thisCombatant)
						text = Recap_FormatNameFirstStat(iName, iType, listCombatant)..Recap_FormatRemainingStats(iType, listCombatant)
					end
				end
				if text then
					if headertext then
						if print_chat(headertext, chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						headertext = nil -- keep as nil
					end
					if print_chat(text, chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
					nLines = nLines + 1
					if nLines >= maxLines then
						break
					end
				end
			end
		end
	end

	if RecapClipEditBox:IsVisible() then
		RecapClipEditBox:HighlightText()
		RecapClipEditBox:SetFocus()
	end
end

-- filterType can be "Group" or "NonGroup"
function Recap_FormatRecentEvent(i, outgoing, filterCombatant, filterEffect, filterType)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local found, _, eventTime, source, dest, effect, effectType, printEffect, printElement, printAmount, printCrit
	local printTime, amountNumeric

	found,_,eventTime,source,dest,effect,printElement,printAmount,printCrit = string_find(rTemp.Recent[i], rTemp.RecentFindString)
	if not found then
		-- anomalous
		return nil
	end

	effectType = string_sub(effect, 1, 1)
	printEffect = string_sub(effect, 2)
	printTime = Recap_FormatTimeRecent(tonumber(eventTime))
	if (printElement == "") then
		printElement = "?"
	end
	amountNumeric = string_find(printAmount, "^(%d+)$")

	local okayCombatant = false
	if filterType and filterType=="Group" then
		if outgoing and filterEffect and (source ~= "") and rCombatants[source] and rCombatants[source].Friend then
			okayCombatant = true
		elseif (not outgoing) and filterEffect and (dest ~= "") and rCombatants[dest] and rCombatants[dest].Friend then
			okayCombatant = true
		end
	elseif filterType and filterType=="NonGroup" then
		if outgoing and filterEffect and (source ~= "") and rCombatants[source] and (not rCombatants[source].Friend) then
			okayCombatant = true
		elseif (not outgoing) and filterEffect and (dest ~= "") and rCombatants[dest] and (not rCombatants[dest].Friend) then
			okayCombatant = true
		end
	else
		if filterCombatant then
			-- filtering by combatant
			if Recap_PetsMerged() then
				if outgoing then
					if (source ~= "") then
						if Recap_IsOwnedBy(source, filterCombatant) then
							okayCombatant = true
						end
					end
				else
					if (dest ~= "") then
						if Recap_IsOwnedBy(dest, filterCombatant) then
							okayCombatant = true
						end
					end
				end
			end
			-- check the combatant
			if outgoing and (source ~= "") and (filterCombatant == source) then
				okayCombatant = true
			elseif not outgoing and (filterCombatant == dest) then
				okayCombatant = true
			end
			-- if not already chosen, check death event since we want deaths to show up on both incoming and outgoing panels
			if not okayCombatant then
				if (effectType == "5") and (filterCombatant == dest) then
					okayCombatant = true
				end
			end
		else
			-- no filtering by combatant
			okayCombatant = true
		end
	end

	if okayCombatant == false then
		return nil
	end

	-- filter by effect
	if filterEffect and (filterEffect ~= printEffect) then
		return nil
	end

	-- trim the source and dest to remove GUIDs
	if (source ~= "") then
		source = Recap_StripGUIDsFromCombatant(source)
	end
	if (dest ~= "") then
		dest = Recap_StripGUIDsFromCombatant(dest)
	else
		-- needed if Store Only Displayed Combatants is enabled; and also for some SPELL_CAST_FAILED events
		dest = "?"
	end

	-- prepare the message
	if (source ~= "") then
		if amountNumeric then
			if effectType == "1" then
				-- damage
				if (printEffect == printElement) or (printElement == rLocalize.ElementOther) then
					return printTime.." "..source.." ("..printEffect..") ==> "..dest.." ( -"..printAmount..printCrit.." )"
				else
					return printTime.." "..source.." ("..printEffect.." ("..printElement..")) ==> "..dest.." ( -"..printAmount..printCrit.." )"
				end
			else
				-- heal or absorb
				if effectType == "3" then
					-- heal
					if (printEffect == printElement) or (printElement == rLocalize.ElementOther) then
						return printTime.." "..source.." ("..printEffect..") ==> "..dest.." ( +"..printAmount..printCrit.." )"
					else
						return printTime.." "..source.." ("..printEffect.." ("..printElement..")) ==> "..dest.." ( +"..printAmount..printCrit.." )"
					end
				else
					-- absorb
					if (printEffect == printElement) or (printElement == rLocalize.ElementOther) then
						return printTime.." "..source.." ("..printEffect..") ==> "..dest.." ( +"..printAmount..printCrit.." )"
					else
						return printTime.." "..source.." ("..printEffect.." ("..printElement..")) ==> "..dest.." ( "..rLocalize.Absorbed.." "..printAmount..printCrit.." )"
					end
				end
			end
		else
			if effectType == "5" then
				-- death
				return printTime.." "..source.." ("..printEffect..") ==> "..dest
			elseif effectType == "6" then
				-- dispel (should have source and dest) (in this context the Effect is the name of whatever is doing the dispelling, and the Element is whatever is being dispelled)
				return printTime.." "..source.." ("..printEffect..") "..rLocalize.Dispels.." ==> "..dest.." ("..printElement..")"
			elseif effectType == "7" then
				-- interrupt (should have source and dest) (in this context the Effect is the name of whatever is doing the interrupting, and the Element is whatever is being interrupted)
				return printTime.." "..source.." ("..printEffect..") "..rLocalize.Interrupts.." ==> "..dest.." ("..printElement..")"
			elseif effectType == "8" then
				-- dispel cast (should have source and dest) (in this context the Effect is the name of whatever is doing the dispelling, and the Element is whatever is being dispelled)
				return printTime.." "..source.." ("..printEffect..") "..rLocalize.Cast.." ==> "..dest.." ("..printElement..")"
			elseif effectType == "9" then
				-- cast or dispel fail (should have source and dest) (in this context the Effect is the name of whatever is doing the dispelling, and the Element is either the effect that could not be dispelled, or the reason for the spell cast failure)
				return printTime.." "..source.." ("..printEffect..") "..rLocalize.Fail..": "..printElement.." ==> "..dest
			elseif printAmount == "cast" then
				-- successful cast, target not available, not sure how best to display this
				return printTime.." "..source.." ("..printEffect..") ==> "..dest
			else
				return printTime.." "..source.." ("..printEffect..") ==> "..dest.." ( "..printAmount.." )"
			end
		end
	else
		if amountNumeric then
			if effectType == "1" then
				-- damage
				if (printEffect == printElement) or (printElement == rLocalize.ElementOther) then
					return printTime.." ("..printEffect..") ==> "..dest.." ( -"..printAmount..printCrit.." )"
				else
					return printTime.." ("..printEffect.." ("..printElement..")) ==> "..dest.." ( -"..printAmount..printCrit.." )"
				end
			else
				-- heal or absorb
				if effectType == "3" then
					-- heal
					if (printEffect == printElement) or (printElement == rLocalize.ElementOther) then
						return printTime.." ("..printEffect..") ==> "..dest.." ( +"..printAmount..printCrit.." )"
					else
						return printTime.." ("..printEffect.." ("..printElement..")) ==> "..dest.." ( +"..printAmount..printCrit.." )"
					end
				else
					-- absorb
					if (printEffect == printElement) or (printElement == rLocalize.ElementOther) then
						return printTime.." ("..printEffect..") ==> "..dest.." ( +"..printAmount..printCrit.." )"
					else
						return printTime.." ("..printEffect.." ("..printElement..")) ==> "..dest.." ( "..rLocalize.Absorbed.." "..printAmount..printCrit.." )"
					end
				end
			end
		else
			if effectType == "5" then
				-- death
				return printTime.." "..dest.." ( "..printEffect.." )"
			else
				if printAmount == "cast" then
					-- successful cast, target not available, not sure how best to display this
					return printTime.." ("..printEffect..") ==> "..dest
				else
					return printTime.." ("..printEffect..") ==> "..dest.." ( "..printAmount.." )"
				end
			end
		end
	end
end

-- the purpose of this function is to ignore three arguments
function Recap_Print(text)
	print(text)
	return nil -- return nil as success indicator
end

function Recap_WIMFindFocus()

	local rTemp = _G.recap_temp
	local i, wwa

	rTemp.WIMType = true
	rTemp.WIMWho = true

	if not WIM then
		return false
	end
	if not WIM.windows then
		return false
	end
	if not WIM.windows.active then
		return false
	end
	wwa = WIM.windows.active

	-- search the WIM active windows to see if any of them has the focus
	if wwa.chat then
		for i in pairs(wwa.chat) do
			if _G[wwa.chat[i]:GetName().."MsgBox"]:HasFocus() then
				if (wwa.chat[i].chatType == "say") or (wwa.chat[i].chatType == "guild") or (wwa.chat[i].chatType == "officer") or (wwa.chat[i].chatType == "party") or (wwa.chat[i].chatType == "raid") or (wwa.chat[i].chatType == "battleground") then
					-- a channel we are prepared to allow posting to
					rTemp.WIMType = wwa.chat[i].chatType
					return true
				end
				return false
			end
		end
	end
	if wwa.whisper then
		for i in pairs(wwa.whisper) do
			if _G[wwa.whisper[i]:GetName().."MsgBox"]:HasFocus() then
				rTemp.WIMType = "whisper"
				rTemp.WIMWho = wwa.whisper[i].theUser
				return true
			end
		end
	end
	return false
end

function Recap_WIM_Print(text)
	local rTemp = _G.recap_temp
	-- post as appropriate based on which WIM chat edit box has the focus
	if (rTemp.WIMType == "whisper") then
		-- a whisper
		SendChatMessage(tostring(text), "WHISPER", nil, rTemp.WIMWho)
	else
		-- a channel
		SendChatMessage(tostring(text), rTemp.WIMType)
	end
	return nil -- return nil as success indicator
end


--[[ Assorted repair / migration functions ]]

-- Special case for combined DoT:HoT spells where the healing event comes as if it were a non-HoT
-- This code is designed to correct existing errors after the fact
-- TODO: at the moment it doesn't correct the element subtotal
function Recap_CorrectDualDoTHoT(iCombatant, AllLastOutgoingDetail, AllLastIncomingDetail)

	local thisTypeEffect, thisType, healEffect, damageEffect, iHealEffect

	if iCombatant[AllLastOutgoingDetail] then
		for thisTypeEffect in pairs(iCombatant[AllLastOutgoingDetail]) do
			-- checking every effect for every combatant
			thisType = tonumber(string_sub(thisTypeEffect,1,1))
			if (thisType == 3) or (thisType == 4) then
				-- only check from healing effects
				healEffect = thisTypeEffect
				iHealEffect = iCombatant[AllLastOutgoingDetail][healEffect]
				-- compute the matching damage effect, and see if it exists
				damageEffect = tostring(thisType-2)..string_sub(healEffect,2)
				if iCombatant[AllLastOutgoingDetail][damageEffect] then
					-- there is a matching damage effect, so this is a dual damage:healing effect
					if iCombatant[AllLastOutgoingDetail][damageEffect].TicksDmg and iHealEffect.HitsDmg then
						-- the damage half of the effect is a DoT and the healing half is (incorrectly) non-HoT healing
						-- convert the healing half of the effect into a HoT
						iHealEffect.Ticks = (iHealEffect.Ticks or 0) + (iHealEffect.CritsEvents or 0)
						iHealEffect.Hits = nil -- keep as nil
						iHealEffect.CritsEvents = nil -- keep as nil
						iHealEffect.TicksDmg = (iHealEffect.TicksDmg or 0) + (iHealEffect.HitsDmg or 0)
						iHealEffect.HitsDmg = nil -- keep as nil
						iHealEffect.TicksMax = math_max((iHealEffect.TicksMax or 0),(iHealEffect.HitsMax or 0))
						iHealEffect.HitsMax = nil -- keep as nil
						iHealEffect.TicksMin = Recap_Min(iHealEffect.TicksMin,iHealEffect.HitsMin)
						iHealEffect.HitsMin = nil -- keep as nil
					end
				end
			end
		end
	end
	if iCombatant[AllLastIncomingDetail] then
		for thisTypeEffect in pairs(iCombatant[AllLastIncomingDetail]) do
			-- checking every effect for every combatant
			thisType = tonumber(string_sub(thisTypeEffect,1,1))
			if (thisType == 3) or (thisType == 4) then
				-- only check from healing effects
				healEffect = thisTypeEffect
				iHealEffect = iCombatant[AllLastIncomingDetail][healEffect]
				-- compute the matching damage effect (in the *Outgoing* table), and see if it exists
				damageEffect = tostring(thisType-2)..string_sub(healEffect,2)
				if iCombatant[AllLastOutgoingDetail] and iCombatant[AllLastOutgoingDetail][damageEffect] then
					-- there is a matching damage effect, so this is a dual damage:healing effect
					if iCombatant[AllLastOutgoingDetail][damageEffect].TicksDmg and iHealEffect.HitsDmg then
						-- the damage half of the effect is a DoT and the healing half is (incorrectly) non-HoT healing
						-- convert the healing half of the effect into a HoT
						iHealEffect.Ticks = (iHealEffect.Ticks or 0) + (iHealEffect.CritsEvents or 0)
						iHealEffect.Hits = nil -- keep as nil
						iHealEffect.CritsEvents = nil -- keep as nil
						iHealEffect.TicksDmg = (iHealEffect.TicksDmg or 0) + (iHealEffect.HitsDmg or 0)
						iHealEffect.HitsDmg = nil -- keep as nil
						iHealEffect.TicksMax = math_max((iHealEffect.TicksMax or 0),(iHealEffect.HitsMax or 0))
						iHealEffect.HitsMax = nil -- keep as nil
						iHealEffect.TicksMin = Recap_Min(iHealEffect.TicksMin,iHealEffect.HitsMin)
						iHealEffect.HitsMin = nil -- keep as nil
					end
				end
			end
		end
	end
end
function Recap_CorrectDualDoTHoTForSelf()

	local rSelf = _G.recap.Self
	local rTemp = _G.recap_temp
	local thisTypeEffect, thisType, healEffect, damageEffect, iHealEffect

	-- for the Self table (is Outgoing only)
	if rSelf[rTemp.s] then
		for thisTypeEffect in pairs(rSelf[rTemp.s]) do
			thisType = tonumber(string_sub(thisTypeEffect,1,1))
			if (thisType == 3) or (thisType == 4) then
				-- only check from healing effects
				healEffect = thisTypeEffect
				iHealEffect = rSelf[rTemp.s][healEffect]
				-- compute the matching damage effect, and see if it exists
				damageEffect = tostring(thisType-2)..string_sub(healEffect,2)
				if rSelf[rTemp.s][damageEffect] then
					-- there is a matching damage effect, so this is a dual damage:healing effect
					if rSelf[rTemp.s][damageEffect].TicksDmg and iHealEffect.HitsDmg then
						-- the damage half of the effect is a DoT and the healing half is non-HoT healing
						-- convert the healing half of the effect into a HoT
						iHealEffect.Ticks = (iHealEffect.Ticks or 0) + (iHealEffect.CritsEvents or 0)
						iHealEffect.Hits = nil -- keep as nil
						iHealEffect.CritsEvents = nil -- keep as nil
						iHealEffect.TicksDmg = (iHealEffect.TicksDmg or 0) + (iHealEffect.HitsDmg or 0)
						iHealEffect.HitsDmg = nil -- keep as nil
						iHealEffect.TicksMax = math_max((iHealEffect.TicksMax or 0),(iHealEffect.HitsMax or 0))
						iHealEffect.HitsMax = nil -- keep as nil
						iHealEffect.TicksMin = Recap_Min(iHealEffect.TicksMin,iHealEffect.HitsMin)
						iHealEffect.HitsMin = nil -- keep as nil
					end
				end
			end
		end
	end
end


--[[ Functions directly or indirectly related to the GUIDs ]]

-- throw away leading '0x' and leading zeroes
function Recap_TrimGUID(longGUID)
	local _, shortGUID
	_, _, shortGUID = string_find(longGUID, "^0x0*(%x%x-)$")
	if shortGUID then
		return shortGUID
	else
		return "666" -- distinctive value if GUID format was bad
	end
end

-- format could be "owner:owner:pet" or "owner:owner:pet" or "owner:pet" or "combatant", and each of those could be "name" or "name_GUID"
-- have examples like player:vehicle:pool of tar
function Recap_NameOnlyFromCombatant(thisCombatant)
	local found, _, pet
	found, _, pet = string_find(thisCombatant, "^.+:.+:(.+)$")
	if found then
		-- "owner:owner:pet"
		return Recap_NameFromNameGUID(pet)
	else
		-- "owner:pet" or "combatant"
		found, _, pet = string_find(thisCombatant, "^.+:(.+)$")
		if found then
			-- "owner:pet"
			return Recap_NameFromNameGUID(pet)
		else
			-- "combatant"
			return Recap_NameFromNameGUID(thisCombatant)
		end
	end
end

function Recap_StripGUIDsFromCombatant(thisCombatant)
	local found, _, firstOwner, secondOwner, pet
	found, _, firstOwner, secondOwner, pet = string_find(thisCombatant, "^(.+):(.+):(.+)$")
	if found then
		-- "owner:owner:pet"
		return Recap_NameFromNameGUID(firstOwner)..":"..Recap_NameFromNameGUID(secondOwner)..":"..Recap_NameFromNameGUID(pet)
	else
		found, _, firstOwner, pet = string_find(thisCombatant, "^(.+):(.+)$")
		if found then
			-- "owner:pet"
			return Recap_NameFromNameGUID(firstOwner)..":"..Recap_NameFromNameGUID(pet)
		else
			-- "combatant"
			return Recap_NameFromNameGUID(thisCombatant)
		end
	end
end

-- format could be "effect" or "name_GUID: effect" or "owner_GUID:name_GUID: effect" or "owner_GUID:owner_GUID:name_GUID: effect"
--   (where effect itself could be, for example, "Shadow Word: Pain")
function Recap_StripOwnerAndGUIDsFromEffect(thisEffect)
	local found, _, iPet, effectFirstPart, effectSecondPart, iEffect
	found, _, iPet, effectFirstPart, effectSecondPart = string_find(thisEffect, "^(.+): (.+): (.+)$")
	if found then
		-- "pet: effectFirstPart: effectSecondPart"
		-- iPet must be a combatant, strip out the GUIDs
		return Recap_StripOwnerAndGUIDsFromCombatant(iPet)..": "..effectFirstPart..": "..effectSecondPart
	else
		found, _, iPet, iEffect = string_find(thisEffect, "^(.+): (.+)$")
		if found then
			-- "owner_GUID:owner_GUID:name_GUID: effect" or "owner_GUID:name_GUID: effect" or "name_GUID: effect" or "effectFirstPart: effectSecondPart"
			-- the following code does the right thing no matter which of the above it is (!)
			return Recap_StripOwnerAndGUIDsFromCombatant(iPet)..": "..iEffect
		else
			-- simple "effect"
			return thisEffect
		end
	end
end

-- format could be "effect" or "name_GUID: effect" or "owner_GUID:name_GUID: effect" or "owner_GUID:owner_GUID:name_GUID: effect"
--   (where effect itself could be, for example, "Shadow Word: Pain")
function Recap_StripOwnerAndPetFromEffect(thisEffect)
	local rCombatants = _G.recap_combatants
	local found, _, iPet, effectFirstPart, effectSecondPart, iEffect
	found, _, iPet, effectFirstPart, effectSecondPart = string_find(thisEffect, "^(.+): (.+): (.+)$")
	if found then
		-- "pet: effectFirstPart: effectSecondPart"
		-- iPet must be a combatant
		return effectFirstPart..": "..effectSecondPart
	else
		found, _, iPet, iEffect = string_find(thisEffect, "^(.+): (.+)$")
		if found then
			-- "owner_GUID:owner_GUID:name_GUID: effect" or "owner_GUID:name_GUID: effect" or "name_GUID: effect" or "effectFirstPart: effectSecondPart"
			-- test explicitly for Ghoul Minion, since there will not be a combatant by that name
			-- also test explicitly for Pet, since there will not be a combatant by that name
			-- the following test for pets, versus two-part effects, is heuristic only
			if rCombatants[iPet] or (Recap_NameOnlyFromCombatant(iPet) == rLocalize.GhoulMinion) or (Recap_NameOnlyFromCombatant(iPet) == rLocalize.ClassName.Pet) then
				return iEffect
			else
				return thisEffect
			end
		else
			-- simple "effect"
			return thisEffect
		end
	end
end

-- format is "name_GUID: effect" where effect itself could be, for example, "Shadow Word: Pain"
function Recap_PetFromFromPetEffect(thisEffect)
	local found, _, iPet, effectFirstPart, effectSecondPart
	found, _, iPet, effectFirstPart, effectSecondPart = string_find(thisEffect, "^(.+): (.+): (.+)$")
	if found then
		-- "name_GUID: effectFirstPart: effectSecondPart"
		return Recap_NameFromNameGUID(iPet)
	else
		-- "name_GUID: effect"
		found, _, iPet = string_find(thisEffect, "^(.+): .+$")
		return Recap_NameFromNameGUID(iPet)
	end
end

-- format is "name_GUID: effect" where effect itself could be, for example, "Shadow Word: Pain"
function Recap_EffectFromFromPetEffect(thisEffect)
	local found, _, effectFirstPart, effectSecondPart, iEffect
	found, _, effectFirstPart, effectSecondPart = string_find(thisEffect, "^.+: (.+): (.+)$")
	if found then
		-- "name_GUID: effectFirstPart: effectSecondPart"
		return effectFirstPart..": "..effectSecondPart
	else
		-- "name_GUID: effect" or "effect"
		found, _, iEffect = string_find(thisEffect, "^.+: (.+)$")
		return iEffect
	end
end

-- format could be "name" or "name_GUID"
function Recap_NameFromNameGUID(nameGUID)
	local found, _, name
	found, _, name = string_find(nameGUID, "^(.+)_.-$")
	if found then
		return name
	else
		-- no GUID, use nameGUID as is
		return nameGUID
	end
end

-- format could be "name" or "name_GUID"
function Recap_GUIDFromNameGUID(nameGUID)
	local found, _, thisGUID
	found, _, thisGUID = string_find(nameGUID, "^.+_(.-)$")
	if found then
		return thisGUID
	else
		-- no GUID, return nil
		return nil
	end
end

-- format could be "name" or "name-realm"
function Recap_NameFromNameRealm(nameRealm)
	local found, _, name
	found, _, name = string_find(nameRealm, "^(.+)%-.-$")
	if found then
		return name
	else
		-- no Realm, use nameRealm as is
		return nameRealm
	end
end

-- note that if we have "firstOwner:secondOwner:name" this checks against "firstOwner"
function Recap_IsOwnedBy(thisCombatant, potentialOwner)
	local found, _, firstOwner, secondOwner
	found, _, firstOwner, secondOwner = string_find(thisCombatant, "^(.+):(.+):.+$")
	if found and (firstOwner == potentialOwner) then
		return true
	else
		found, _, firstOwner = string_find(thisCombatant, "^(.+):.+$")
		if found and (firstOwner == potentialOwner) then
			return true
		else
			return false
		end
	end
end

 -- added to limit recursion when owner1 = owner2
 -- does only a single trim, we'll see how that works
 -- will probably happen only when GUIDs are turned off
function Recap_TrimOwnedBy(nameGUID)
	local rCombatants = _G.recap_combatants
	local thisCombatant, owners
	thisCombatant = rCombatants[nameGUID]
	if thisCombatant then
		owners = thisCombatant.OwnedBy
		if owners then
			local found, _, firstOwner, secondOwner, otherOwners
			found, _, firstOwner, secondOwner = string_find(owners, "^(.+):(.+)$")
			if found then
				-- exactly two owners
				if (firstOwner == secondOwner) then
					-- remove first owner
					thisCombatant.OwnedBy = secondOwner
				end
			end
			found, _, firstOwner, secondOwner, otherOwners = string_find(owners, "^(.+):(.+):(.+)$")
			if found then
				-- three or more owners
				if (firstOwner == secondOwner) then
					-- remove first owner
					thisCombatant.OwnedBy = secondOwner..":"..otherOwners
				end
			end
		end
	end
end

-- added by renews
-- his original code went into infinite loop when GUIDs were off and e.g. mob "Solar Winds" was summoning another "Solar Winds"
-- rewritten by Hawksy to not use 'while' and to support up to A:B:C:D:E:F:G
function Recap_RootOwner(nameGUID)
	local rCombatants = _G.recap_combatants
	local ownerOne = nameGUID -- actually owned, not an owner, used for code symmetry
	local ownerTwo = nil
	local ownerThree = nil
	local ownerFour = nil
	local ownerFive = nil
	local ownerSix = nil
	local ownerSeven = nil
	if rCombatants[ownerOne] and rCombatants[ownerOne].OwnedBy then
		ownerTwo = rCombatants[ownerOne].OwnedBy
		if (ownerTwo == ownerOne) then
			-- loop, exit
			return ownerTwo
		end
		if rCombatants[ownerTwo] and rCombatants[ownerTwo].OwnedBy then
			ownerThree = rCombatants[ownerTwo].OwnedBy
			if (ownerThree == ownerOne) or (ownerThree == ownerTwo) then
				-- loop, exit
				return ownerThree
			end
			if rCombatants[ownerThree] and rCombatants[ownerThree].OwnedBy then
				ownerFour = rCombatants[ownerThree].OwnedBy
				if (ownerFour == ownerOne) or (ownerFour == ownerTwo) or (ownerFour == ownerThree) then
					-- loop, exit
					return ownerFour
				end
				if rCombatants[ownerFour] and rCombatants[ownerFour].OwnedBy then
					ownerFive = rCombatants[ownerFour].OwnedBy
					if (ownerFive == ownerOne) or (ownerFive == ownerTwo) or (ownerFive == ownerThree) or (ownerFive == ownerFour) then
						-- loop, exit
						return ownerFive
					end
					if rCombatants[ownerFive] and rCombatants[ownerFive].OwnedBy then
						ownerSix = rCombatants[ownerFive].OwnedBy
						if (ownerSix == ownerOne) or (ownerSix == ownerTwo) or (ownerSix == ownerThree) or (ownerSix == ownerFour) or (ownerSix == ownerFive) then
							-- loop, exit
							return ownerSix
						end
						if rCombatants[ownerSix] and rCombatants[ownerSix].OwnedBy then
							ownerSeven = rCombatants[ownerSix].OwnedBy
							if (ownerSeven == ownerOne) or (ownerSeven == ownerTwo) or (ownerSeven == ownerThree) or (ownerSeven == ownerFour) or (ownerSeven == ownerFive) or (ownerSeven == ownerSix) then
								-- loop, exit
								return ownerSeven
							end
						else
							return ownerSix
						end
					else
						return ownerFive
					end
				else
					return ownerFour
				end
			else
				return ownerThree
			end
		else
			return ownerTwo
		end
	else
		return nil
	end
 end

-- note that if we have "firstOwner:secondOwner:name" this returns "firstOwner" (the ultimate owner)
function Recap_ExtractOwner(thisCombatant)
	local found, _, firstOwner, secondOwner
	found, _, firstOwner, secondOwner = string_find(thisCombatant, "^(.+):(.+):.+$")
	if found then
		return firstOwner
	else
		found, _, firstOwner = string_find(thisCombatant, "^(.+):.+$")
		if found then
			return firstOwner
		else
			return nil
		end
	end
end

-- returns all owners
function Recap_ExtractOwners(thisCombatant)
	local found, _, twoOwners, oneOwner
	found, _, twoOwners = string_find(thisCombatant, "^(.+:.+):.+$")
	if found then
		return twoOwners
	else
		found, _, oneOwner = string_find(thisCombatant, "^(.+):.+$")
		if found then
			return oneOwner
		else
			return nil
		end
	end
end

function Recap_ExtractCombatant(thisCombatant)
	local found, _, combatant
	found, _, combatant = string_find(thisCombatant, "^.+:.+:(.+)$")
	if found then
		return combatant
	else
		found, _, combatant = string_find(thisCombatant, "^.+:(.+)$")
		if found then
			return combatant
		else
			return nil
		end
	end
end

function Recap_CombatantIsTrash(thisCombatant)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, count, name, owner

	-- trickier than it looks, bosses who reset get new GUIDs ...

	-- shortcuts
	if rCombatants[thisCombatant].Friend then -- redundant check, call it paranoia
		return false
	end
	if rCombatants[thisCombatant].Trash == false then
		-- marked as not trash, take that as definitive
		return false
	end
	if rCombatants[thisCombatant].Level and tonumber(rCombatants[thisCombatant].Level)==-1 then
		-- if this is a high level boss (level is -1) then mark it as not trash
		rCombatants[thisCombatant].Trash = false
		return false
	end
	if rCombatants[thisCombatant].Trash == true then
		-- marked as trash, but if it is a pet of a combatant who is marked as not trash, change the pet to not trash also
		owner = Recap_ExtractOwner(thisCombatant)
		if owner and rCombatants[owner] and (rCombatants[owner].Trash ~= nil) and (rCombatants[owner].Trash == false) then
			rCombatants[thisCombatant].Trash = false
			return false
		end
		return true
	end

	-- we don't know about this combatant, count the hard way
	count = 0
	name = Recap_NameOnlyFromCombatant(thisCombatant)
	for i in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			if (Recap_NameOnlyFromCombatant(i) == name) then
				count = count + 1
				if count > 1 then
					-- we have found more than one of this combatant, mark this one as trash
					rCombatants[i].Trash = true
					-- we carry on looping to mark any others
					-- the first one we found may not be marked yet
				end
			end
		end
	end

	if count > 1 then
		rCombatants[thisCombatant].Trash = true
		return true
	else
		-- only found one, and can't tell whether it is trash or not
		return false
	end
end

function Recap_BossList()
	-- string of enemy boss names in last fight (if any are present)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local bossList, i, iCombatant, iName, iGUID, j
	bossList = ""
	for i in pairs(rTemp.Last) do
		iCombatant = rCombatants[i]
		if iCombatant and iCombatant.WasInCurrent and (not iCombatant.Friend) then
			-- must have been in the last fight, and must have been an enemy
			if iCombatant.Level and tonumber(iCombatant.Level)==-1 then
				-- this is a high level mob (level is -1), so add the name to the list
				iName = Recap_NameOnlyFromCombatant(i)
				if (bossList == "") then
					bossList = iName
				else
					-- add name
					if not string_find(bossList, iName, 1, true) then
						-- only add if not already present (could still lead to anomalies if a later name is a substring of an earlier name)
						bossList = bossList.." + "..iName
					end
				end
			end

			-- check whether it is one of two special case Burning Tendons in the Spine fight
			iGUID = Recap_GUIDFromNameGUID(i)
			if iGUID then
				j = string_sub(iGUID, 5, 5) -- fifth character of GUID
				if j then
					j = tonumber(j, 16) -- number, base sixteen
					if j then
						if bit_band(j, 7) == 3 then
							-- it is an NPC
							j = string_sub(iGUID, 9, 12)
							if j then
								local npcID = tonumber(j, 16)
								if rTemp.SpecialBosses[npcID] then
									-- one of the Burning Tendons, mark as a boss fight
									iName = "Burning Tendons" -- English name, sorry
									if (bossList == "") then
										bossList = iName
									else
										-- add name
										if not string_find(bossList, iName, 1, true) then
											-- only add if not already present (could still lead to anomalies if a later name is a substring of an earlier name)
											bossList = bossList.." + "..iName
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	return bossList
end

function Recap_FindBoss(iName)
	-- returns true if named boss is present in the current fight
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, iLast, iCombatant

	for i, iLast in pairs(rTemp.Last) do
		iCombatant = rCombatants[i]
		if (iLast.StartOut and iLast.StartOut > 0) or (iLast.StartIn and iLast.StartIn > 0) or (iLast.StartHeal and iLast.StartHeal > 0) then
			-- combatant is in this fight
			if iCombatant.Level and tonumber(iCombatant.Level)==-1 then
				-- this is a high level mob (level is -1), should be a boss, check for name
				if iName == Recap_NameFromNameGUID(i) then
					-- name matches
					return true
				end
			end
		end
	end
	return false
end

RecapAux_lua_4773 = true
