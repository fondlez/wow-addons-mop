﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ RecapRecent.lua (functions for the popup panel for Recent Events) ]]

local math_max = _G.math.max
local math_min = _G.math.min
local string_find = _G.string.find
local string_format = _G.string.format
local string_lower = _G.string.lower
local string_sub = _G.string.sub
local table_sort = _G.table.sort
local pairs = _G.pairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ local tables ]]

local dockoffset = { ["TOPRIGHTTOPLEFT"] = { x=-4,y=0 },
					 ["BOTTOMRIGHTBOTTOMLEFT"] = { x=-4,y=0 },
					 ["TOPLEFTTOPRIGHT"] = { x=4,y=0 },
					 ["BOTTOMLEFTBOTTOMRIGHT"] = { x=4,y=0 },
					 ["TOPRIGHTBOTTOMRIGHT"] = { x=0,y=-4 },
					 ["BOTTOMRIGHTTOPRIGHT"] = { x=0,y=4 },
					 ["TOPLEFTBOTTOMLEFT"] = { x=0,y=-4 },
					 ["BOTTOMLEFTTOPLEFT"] = { x=0,y=4 } }

--[[ local functions (precede first use) ]]

local function RecapRecent_ConstructRecentIncomingByIndex()

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent

	-- clear the list
	rTemp.RecentIncomingListSize = 1
	rTemp.RecentIncomingList = wipe(rTemp.RecentIncomingList)

	local i, first, last, sentEOF, index, offset, iList, message
	local found, _, eventTime, source

	if rRecent then

		first = rRecent.First
		last = rRecent.Last
		i = rTemp.RecentIndex

		-- figure out a starting position up to 200 events earlier than RecentIndex, then go forward up to 200 events later than RecentIndex
		for index=1, 200 do
			offset = index
			if (i == first) then
				-- found the earliest event, leave the loop
				break
			end
			-- increment circular pointer
			if i <= 1 then
				i = rOpt.RecentEventCount.value
			else
				i = i - 1
			end
		end

		if (i == last) and not (rRecent[i] and (rRecent[i] ~= "")) then
			-- no data at all
		else
			-- data exists, list the rows (there may be none due to filtering)
			sentEOF = true -- set to skip any initial 'end of fight' markers
			for index=1, 401 do
				if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
					rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
				end
				iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
				found,_,eventTime,source = string_find(rRecent[i], rTemp.RecentFindString)
				if not found then
					-- anomalous
					return nil
				end
				if source == "*EOF*" then
					-- maybe post an 'end of fight' marker
					if sentEOF == true then
						-- avoid sending two in a row, and avoid leading 'end of fight' indicators
					else
						-- special 'end of fight' line
						message = Recap_FormatTimeRecent(tonumber(eventTime)).." --------------------------------------------------"
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = true
					end
				else
					-- not an 'end of fight'
					message = Recap_FormatRecentEvent(i, false, nil, nil, nil)
					if message then
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = false
					end
				end
				if (i == last) then
					-- just posted the most recent one, leave the loop
					break
				end
				-- increment circular pointer
				if i >= rOpt.RecentEventCount.value then
					i = 1
				else
					i = i + 1
				end
			end
		end
	end
	rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = nil -- keep as nil

	return offset
end

local function RecapRecent_ConstructRecentOutgoingByIndex()

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent

	-- clear the list
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	local i, first, last, sentEOF, index, offset, iList, message
	local found, _, eventTime, source

	if rRecent then

		first = rRecent.First
		last = rRecent.Last
		i = rTemp.RecentIndex

		-- figure out a starting position up to 200 events earlier than RecentIndex, then go forward up to 200 events later than RecentIndex
		for index=1, 200 do
			offset = index
			if (i == first) then
				-- found the earliest event, leave the loop
				break
			end
			-- increment circular pointer
			if i <= 1 then
				i = rOpt.RecentEventCount.value
			else
				i = i - 1
			end
		end

		if (i == last) and not (rRecent[i] and (rRecent[i] ~= "")) then
			-- no data at all
		else
			-- data exists, list the rows (there may be none due to filtering)
			sentEOF = true -- set to skip any initial 'end of fight' markers
			for index=1, 401 do
				if not rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize] then
					rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize] = {}
				end
				iList = rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize]
				found,_,eventTime,source = string_find(rRecent[i], rTemp.RecentFindString)
				if not found then
					-- anomalous
					return nil
				end
				if source == "*EOF*" then
					-- maybe post an 'end of fight' marker
					if sentEOF == true then
						-- avoid sending two in a row, and avoid leading 'end of fight' indicators
					else
						-- special 'end of fight' line
						message = Recap_FormatTimeRecent(tonumber(eventTime)).." --------------------------------------------------"
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentOutgoingListSize = rTemp.RecentOutgoingListSize + 1
						sentEOF = true
					end
				else
					-- not an 'end of fight'
					message = Recap_FormatRecentEvent(i, true, nil, nil, nil)
					if message then
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentOutgoingListSize = rTemp.RecentOutgoingListSize + 1
						sentEOF = false
					end
				end
				if (i == last) then
					-- just posted the most recent one, leave the loop
					break
				end
				-- increment circular pointer
				if i >= rOpt.RecentEventCount.value then
					i = 1
				else
					i = i + 1
				end
			end
		end
	end
	rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize] = nil -- keep as nil

	return offset
end

local function RecapRecent_PopulateByIndex()

	local rUser = _G.recap_user
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local sbOffset
	local found, _, eventTime

	-- title bar contents
	RecapRecentFaction:SetTexture("")
	RecapRecentLevel:SetText("")
	RecapRecentClass:SetTexCoord(.9,1,.9,1)
	RecapRecentName:SetTextColor(unpack(rColor.WoWDefault))
	found,_,eventTime = string_find(rRecent[rTemp.RecentIndex], rTemp.RecentFindString)
	if not found then
		--anomalous
		return nil
	end
	RecapRecentName:SetText(rLocalize.TimeWindow..": "..Recap_FormatTimeRecent(tonumber(eventTime)))

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	RecapRecentIncomingLabel:SetText(RECAP_RECENT_EVENTS)

	rTemp.RecentSource = "Events"

	-- show incoming only
	rUser.RecentView = 1

	sbOffset = RecapRecent_ConstructRecentIncomingByIndex()
	-- put indexed event near the centre of the window
	sbOffset = math_max(sbOffset - 9, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- clear outgoing list just in case
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- set tabs
	RecapRecent_SwitchRecents(true, false)
end

local function RecapRecent_ConstructRecentIncoming(filterCombatant, filterEffect, filterType, filterDispelsAndInterrupts)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local i, last, sentEOF, index, iList, message
	local found, _, eventTime, source, effect, effectType

	-- clear the list
	rTemp.RecentIncomingListSize = 1
	rTemp.RecentIncomingList = wipe(rTemp.RecentIncomingList)

	-- list forwards from the first, no need to limit
	if rRecent then
		i = rRecent.First
		last = rRecent.Last
		if (i == last) and not (rRecent[i] and (rRecent[i] ~= "")) then
			-- no data at all
		else
			-- data exists, list the rows (there may be none due to filtering)
			sentEOF = true -- set to skip any initial 'end of fight' markers
			for index=1, rOpt.RecentEventCount.value do
				if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
					rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
				end
				iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
				found,_,eventTime,source,_,effect = string_find(rRecent[i], rTemp.RecentFindString)
				if not found then
					-- anomalous
					return nil
				end
				effectType = string_sub(effect, 1, 1)
				if source == "*EOF*" then
					-- maybe post an 'end of fight' marker
					if sentEOF == true then
						-- avoid sending two in a row, and avoid leading 'end of fight' indicators
					else
						-- special 'end of fight' line
						message = Recap_FormatTimeRecent(tonumber(eventTime)).." --------------------------------------------------"
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = true
					end
				else
					-- not an 'end of fight'
					if filterDispelsAndInterrupts then
						-- if posting dispels, then type 6 events only
						-- we now also include interrupts, which are type 7
						-- and also dispel casts (type 8) and dispel fails (type 9)
						if (effectType == "6") or (effectType == "7") or (effectType == "8") or (effectType == "9") then
							message = Recap_FormatRecentEvent(i, false, filterCombatant, filterEffect, filterType)
							-- if filterCombatant or filterEffect fails, the message gets returned as nil
							if message then
								iList.Event = message
								iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
								rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
								sentEOF = false
							end
						end
					else
						-- all events, including dispels
						message = Recap_FormatRecentEvent(i, false, filterCombatant, filterEffect, filterType)
						-- if filterCombatant or filterEffect fails, the message gets returned as nil
						if message then
							iList.Event = message
							iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
							rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
							sentEOF = false
						end
					end
				end
				if (i == last) then
					-- just posted the most recent one, leave the loop
					break
				end
				-- increment circular pointer
				if i >= rOpt.RecentEventCount.value then
					i = 1
				else
					i = i + 1
				end
			end
		end
	end
	rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = nil -- keep as nil
end

local function RecapRecent_ConstructRecentOutgoing(filterCombatant, filterEffect, filterType, filterDispelsAndInterrupts)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local i, last, sentEOF, index, iList, message
	local found, _, eventTime, source, effect, effectType

	-- clear the list
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- list forwards from the first, no need to limit
	if rRecent then
		i = rRecent.First
		last = rRecent.Last
		if (i == last) and not (rRecent[i] and (rRecent[i] ~= "")) then
			-- no data at all
		else
			-- data exists, list the rows (there may be none due to filtering)
			sentEOF = true -- set to skip any initial 'end of fight' markers
			for index=1, rOpt.RecentEventCount.value do
				if not rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize] then
					rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize] = {}
				end
				iList = rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize]
				found,_,eventTime,source,_,effect = string_find(rRecent[i], rTemp.RecentFindString)
				if not found then
					-- anomalous
					return nil
				end
				effectType = string_sub(effect, 1, 1)
				if source == "*EOF*" then
					-- maybe post an 'end of fight' marker
					if sentEOF == true then
						-- avoid sending two in a row, and avoid leading 'end of fight' indicators
					else
						-- special 'end of fight' line
						message = Recap_FormatTimeRecent(tonumber(eventTime)).." --------------------------------------------------"
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentOutgoingListSize = rTemp.RecentOutgoingListSize + 1
						sentEOF = true
					end
				else
					-- not an 'end of fight'
					if filterDispelsAndInterrupts then
						-- if posting dispels, then type 6 events only
						-- we now also include interrupts, which are type 7
						if (effectType == "6") or (effectType == "7") then
							message = Recap_FormatRecentEvent(i, true, filterCombatant, filterEffect, filterType)
							-- if filterCombatant or filterEffect fails, the message gets returned as nil
							if message then
								iList.Event = message
								iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
								rTemp.RecentOutgoingListSize = rTemp.RecentOutgoingListSize + 1
								sentEOF = false
							end
						end
					else
						-- all events, including dispels
						message = Recap_FormatRecentEvent(i, true, filterCombatant, filterEffect, filterType)
						-- if filterCombatant or filterEffect fails, the message gets returned as nil
						if message then
							iList.Event = message
							iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
							rTemp.RecentOutgoingListSize = rTemp.RecentOutgoingListSize + 1
							sentEOF = false
						end
					end
				end
				if (i == last) then
					-- just posted the most recent one, leave the loop
					break
				end
				-- increment circular pointer
				if i >= rOpt.RecentEventCount.value then
					i = 1
				else
					i = i + 1
				end
			end
		end
	end
	rTemp.RecentOutgoingList[rTemp.RecentOutgoingListSize] = nil -- keep as nil
end

local function RecapRecent_DetermineColor(text, outgoing)

	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp

	if string_find(text, "%(% %-%d") then
		-- damage
		if string_find(text, "%*") then
			-- crit or crush
			if outgoing then
				return unpack(rColor.DmgOut)
			else
				return unpack(rColor.DmgIn)
			end
		else
			if outgoing then
				return unpack(rColor.DmgOutPale)
			else
				return unpack(rColor.DmgInPale)
			end
		end
	elseif string_find(text, "%(% %+%d") then
		-- heal
		if string_find(text, "%*") then
			-- crit
			return unpack(rColor.Heal)
		else
			return unpack(rColor.HealPale)
		end
	else
		-- miss or cast or death
		return unpack(rColor.White)
	end
end

local function RecapRecent_PostEvents(tooltipText, eventList, listLength, outgoing, fromEnd)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno, iList, limit, omit, start
	local text, alltext = "",""
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID, _, chatname
	local escapeColor, r, g, b
	local maxLines = rOpt.MaxRank.value

	chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
	if chatnum then
		_, chatname = GetChannelName(chatnum)

		-- block posting to channels that would be excessively annoying to others
		--   (also blocks other channels that happen to have BlockChannels as substrings -- tough)
		if chatname then
			for i=1,#rLocalize.BlockChannels do
				if string_find(string_lower(chatname), rLocalize.BlockChannels[i], 1, true) then
					PlaySound("igQuestFailed")
					return
				end
			end
		end
	end
	if chatchan=="Self" then
		print_chat = Recap_Print
	end

	-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
	if Recap_WIMFindFocus() then
		print_chat = Recap_WIM_Print
	end

	-- If the Clipboard is open, post there instead of to chat or console
	-- With 4.62 there is no limit to the maximum size written to the clipboard (used to be 32000 letters max)
	if RecapClipEditBox:IsVisible() then
		print_chat = Recap_LineToClipboard
		maxLines = rTemp.MaxLinesToClipboard
	end

	-- calculate the number of lines to post (taking into account the maximum allowed)
	limit = math_min(listLength, maxLines)
	if fromEnd then
		-- standard, last N
		omit = listLength - limit
		start = 1 + omit
	else
		-- detail entries, first N
		listLength = limit
		start = 1
	end

	-- start generating output
	if outgoing then
		alltext = "__ Recap ("..Recap_PetsMergedText().."): "..RecapRecentOutgoingLabel:GetText().." __"
	else
		alltext = "__ Recap ("..Recap_PetsMergedText().."): "..RecapRecentIncomingLabel:GetText().." __"
	end
	lineno = 0
	if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
		-- a non-nil return indicates clipboard full
		-- should not happen as of 4.62, but leave the if statement in case
	end
	for i=start,listLength do
		iList = eventList[i]
		text = iList.Event
		lineno = lineno + 1
		if chatchan=="Self" then
			-- colour to our own console
			r,g,b = RecapRecent_DetermineColor(iList.Event, outgoing)
			escapeColor = string_format("|cff%02x%02x%02x", Recap_Round0(255*r), Recap_Round0(255*g), Recap_Round0(255*b))
			text = escapeColor..text
		end
		if print_chat(text, chatchan, nil, chatnum, presenceID) then
			-- a non-nil return indicates clipboard full
			-- should not happen as of 4.62, but leave the if statement in case
		end
	end

	if RecapClipEditBox:IsVisible() then
		RecapClipEditBox:HighlightText()
		RecapClipEditBox:SetFocus()
	end
end

-- scrape the colour from the text and convert to a chat escape sequence
local function RecapRecent_escapeColor(fld)
	local r, g, b, a
	r,g,b,a = fld:GetTextColor()
	return string_format("|c%02x%02x%02x%02x", Recap_Round0(255*a), Recap_Round0(255*r), Recap_Round0(255*g), Recap_Round0(255*b))
end

local function Recap_SortRecentDeaths(e1, e2)

	if e1 and e2 then
		if type(e1.Death) == type(e2.Death) then
			-- types match, normal compare
			if (e1.Death < e2.Death) then
				return true
			else
				return false
			end
		else
			-- types don't match, force string compare
			if (tostring(e1.Death) < tostring(e2.Death)) then
				return true
			else
				return false
			end
		end
	else
		-- one or both are nil
		if (not e1) and e2 then
			return true
		else
			return false
		end
	end
end

local function Recap_SortRecentDeathDamages(e1, e2)

	if e1 and e2 then
		if type(e1.Amount) == type(e2.Amount) then
			-- types match, normal compare
			if (e1.Amount > e2.Amount) then
				return true
			else
				return false
			end
		else
			-- types don't match, force string compare
			if (tostring(e1.Amount) > tostring(e2.Amount)) then
				return true
			else
				return false
			end
		end
	else
		-- one or both are nil
		if e1 and (not e2) then
			return true
		else
			return false
		end
	end
end

local function Recap_SortDetailEntries(e1, e2)

	if e1 and e2 then
		if type(e1.Amount) == type(e2.Amount) then
			-- types match, normal compare
			if (e1.Amount > e2.Amount) then
				return true
			else
				return false
			end
		else
			-- types don't match, force string compare
			if (tostring(e1.Amount) > tostring(e2.Amount)) then
				return true
			else
				return false
			end
		end
	else
		-- one or both are nil
		if (not e1) and e2 then
			return true
		else
			return false
		end
	end
end


--[[ global functions ]]

function RecapRecent_Populate(filterCombatant, filterDispelsAndInterrupts)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local iCombatant = rCombatants[filterCombatant]
	local sbOffset

	-- normal title bar contents
	if iCombatant.Faction and rTemp.FactionIcons[iCombatant.Faction] then
		RecapRecentFaction:SetTexture(rTemp.FactionIcons[iCombatant.Faction])
	else
		RecapRecentFaction:SetTexture("")
	end
	if iCombatant.Level and tonumber(iCombatant.Level)>0 then
		RecapRecentLevel:SetText(iCombatant.Level)
	elseif iCombatant.Level and tonumber(iCombatant.Level)==-1 then
		RecapRecentLevel:SetText("??")
	else
		RecapRecentLevel:SetText(" ")
	end
	if iCombatant.Class and rTemp.ClassIcons[iCombatant.Class] then
		RecapRecentClass:SetTexCoord(rTemp.ClassIcons[iCombatant.Class].left,rTemp.ClassIcons[iCombatant.Class].right,rTemp.ClassIcons[iCombatant.Class].top,rTemp.ClassIcons[iCombatant.Class].bottom)
	else
		RecapRecentClass:SetTexCoord(.9,1,.9,1)
	end
	if iCombatant.Friend then
		RecapRecentName:SetTextColor(unpack(rColor.DmgOut))
	else
		RecapRecentName:SetTextColor(1,1,1)
	end
	RecapRecentName:SetText(Recap_StripGUIDsFromCombatant(filterCombatant))
	RecapRecentFullName:SetText(filterCombatant) -- hidden field

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	if filterDispelsAndInterrupts then
		-- show incoming only
		rUser.RecentView = 1
		RecapRecentIncomingLabel:SetText(RECAP_RECENT_DISPELS_AND_INTERRUPTS)
	else
		RecapRecentIncomingLabel:SetText(RECAP_RECENT_INCOMING_EVENTS)
		RecapRecentOutgoingLabel:SetText(RECAP_RECENT_OUTGOING_EVENTS)
	end

	if filterDispelsAndInterrupts then
		rTemp.RecentSource = "DIEvents"
	else
		rTemp.RecentSource = "Events"
	end

	-- not ByIndex, so make sure that's off
	rTemp.RecentIndex = 0

	RecapRecent_ConstructRecentIncoming(filterCombatant, nil, nil, filterDispelsAndInterrupts)
	-- force initial scroll to bottom of list (showing most recent events)
	sbOffset = math_max(rTemp.RecentIncomingListSize - 1 - 18, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- only show outgoing if not restricted to dispels and interrupts
	if filterDispelsAndInterrupts then
		-- clear outgoing list just in case
		rTemp.RecentOutgoingListSize = 1
		rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

		-- set tabs
		RecapRecent_SwitchRecents(true, false)
	else
		RecapRecent_ConstructRecentOutgoing(filterCombatant, nil, nil, filterDispelsAndInterrupts)
		-- force initial scroll to bottom of list (showing most recent events)
		sbOffset = math_max(rTemp.RecentOutgoingListSize - 1 - 18, 0)
		FauxScrollFrame_SetOffset(RecapRecentOutgoingScrollBar, sbOffset)
		RecapRecentOutgoingScrollBar_Update()
		RecapRecentOutgoingScrollBarScrollBar:SetValue(sbOffset*14)

		-- set tabs
		RecapRecent_SwitchRecents(false, false)
	end
end

-- modified to only show incoming view (since the only difference is colour, avoid creating two lists)
function RecapRecent_PopulateAll(filterDispelsAndInterrupts)

	local rUser = _G.recap_user
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local sbOffset

	-- normal title bar contents
	RecapRecentFaction:SetTexture("")
	RecapRecentLevel:SetText("")
	RecapRecentClass:SetTexCoord(.9,1,.9,1)
	RecapRecentName:SetTextColor(unpack(rColor.WoWDefault))
	RecapRecentName:SetText(rLocalize.AllCombatants)

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	if filterDispelsAndInterrupts then
		RecapRecentIncomingLabel:SetText(RECAP_RECENT_DISPELS_AND_INTERRUPTS)
	else
		RecapRecentIncomingLabel:SetText(RECAP_RECENT_EVENTS)
	end

	if filterDispelsAndInterrupts then
		rTemp.RecentSource = "DIEvents"
	else
		rTemp.RecentSource = "Events"
	end

	-- show incoming only
	rUser.RecentView = 1

	-- not ByIndex, so make sure that's off
	rTemp.RecentIndex = 0

	RecapRecent_ConstructRecentIncoming(nil, nil, nil, filterDispelsAndInterrupts)
	-- force initial scroll to bottom of list (showing most recent events)
	sbOffset = math_max(rTemp.RecentIncomingListSize - 1 - 18, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- clear outgoing list just in case
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- set tabs
	RecapRecent_SwitchRecents(true, false)
end

local function Recap_CheckDeathWindowEvent(thisCombatant, innerSource, innerDest, innerEffect, innerPrintAmount, deathTable, deathTableIndex, damageTableIndex, damageEventCount)

	local k, m
	local innerEffectType, innerPrintEffect, amountNumeric

	if innerSource == "*EOF*" then
		-- ignore
	else
		if (thisCombatant == innerDest) then
			-- an incoming event for this combatant
			innerEffectType = string_sub(innerEffect, 1, 1)
			innerPrintEffect = string_sub(innerEffect, 2)
			amountNumeric = string_find(innerPrintAmount, "^(%d+)$")
			if amountNumeric then
				if (innerEffectType == "1") then
					damageEventCount = damageEventCount + 1
					-- damage, record this
					if (innerSource ~= "") then
						innerSource = Recap_StripGUIDsFromCombatant(innerSource).." ("..innerPrintEffect..")"
					else
						-- if innerSource is unknown then always include the effect
						innerSource = "? ("..innerPrintEffect..")"
					end
					-- do we already have an entry for this source ?
					k = 0
					for m = 1, damageTableIndex do
						if deathTable[deathTableIndex].Damages[m] and (deathTable[deathTableIndex].Damages[m].Source == innerSource) then
							-- found a match
							k = m
							break
						end
					end
					if k > 0 then
						-- entry was found
					else
						-- need new entry
						k = damageTableIndex
						deathTable[deathTableIndex].Damages[k] = { Source = innerSource }
						damageTableIndex = damageTableIndex + 1
					end
					deathTable[deathTableIndex].Damages[k].Amount = (deathTable[deathTableIndex].Damages[k].Amount or 0) + tonumber(innerPrintAmount)
					deathTable[deathTableIndex].Damages[k].Count = (deathTable[deathTableIndex].Damages[k].Count or 0) + 1
				else
					-- heal or absorb
					if (innerEffectType == "3") then
						-- heal, record this
						innerSource = rLocalize.ElementHealing -- healing is not broken down by source
						-- do we already have an entry for this source ?
						k = 0
						for m = 1, damageTableIndex do
							if deathTable[deathTableIndex].Damages[m] and (deathTable[deathTableIndex].Damages[m].Source == innerSource) then
								-- found a match
								k = m
								break
							end
						end
						if k > 0 then
							-- entry was found
						else
							-- need new entry
							k = damageTableIndex
							deathTable[deathTableIndex].Damages[k] = { Source = innerSource }
							damageTableIndex = damageTableIndex + 1
						end
						deathTable[deathTableIndex].Damages[k].Amount = (deathTable[deathTableIndex].Damages[k].Amount or 0) + tonumber(innerPrintAmount)
						deathTable[deathTableIndex].Damages[k].Count = (deathTable[deathTableIndex].Damages[k].Count or 0) + 1
					end
				end
			end
		end
	end

	return damageEventCount, damageTableIndex
end

-- report last few sources of damage for each combatant who has died
-- put deaths summary into the incoming view (loading apples into an orange-crate)
function RecapRecent_PopulateDeaths()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local sbOffset

	-- normal title bar contents
	RecapRecentFaction:SetTexture("")
	RecapRecentLevel:SetText("")
	RecapRecentClass:SetTexCoord(.9,1,.9,1)
	RecapRecentName:SetTextColor(unpack(rColor.WoWDefault))
	RecapRecentName:SetText(rLocalize.Group.." "..rLocalize.Combatants)

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	RecapRecentIncomingLabel:SetText(RECAP_RECENT_DEATHS)

	rTemp.RecentSource = "Deaths"

	-- always show incoming
	rUser.RecentView = 1

	-- not ByIndex, so make sure that's off
	rTemp.RecentIndex = 0

	-- summarize causes of death for group members
	local deathTable, deathTableIndex, damageTableIndex
	local lateCount, earlyCount, lateTimeWindow, earlyTimeWindow, damageEventCount

	-- create empty table for results
	deathTable = {}
	deathTableIndex = 1
	earlyCount = 8 -- number of damage events occurring prior to the death
	earlyTimeWindow = 8 -- seconds for damage events occurring prior to the death
	lateCount = 2 -- number of damage events occurring later than the death
	lateTimeWindow = 2 -- seconds for damage events occurring later than the death


	-- relatively simple in concept, relatively complex to implement (this is my third version)
	-- death events are stored in a separate table at the same time as they are added to the Recent events table
	-- a 'death window' is defined by going both ways from a death event for a combatant
	--   the 'death window' includes up to 'earlyCount' damage events prior to the death event, provided they are within 'earlyTimeWindow' seconds of the death event (scan backwards)
	--	  if while scanning backwards we encounter another death event (which is therefore earlier), we abandon recording the current (and therefore later) death event
	--	   typically this would be a priest Spirit of Redemption creating two death events, with the priest cancelling the Spirit early, so that the two death windows overlap
	--		 normal expiration of the Spirit will give a second death event that does not overlap the earlier death event -- the second will have no data, and will not be shown
	--   the 'death window' includes up to 'lateCount' damage events after the death event, provided they are within 'lateTimeWindow' seconds of the death event (scan forwards)
	--	  this is because often the combat log event for the killing blow arrives after the combat log event for the death

	local i, j, current, deathTime
	local found, _, eventTime, thisCombatant, skipThisDeath
	local innerEventTime, innerSource, innerDest, innerEffect, innerPrintAmount

	-- pre-scan for end of fight events
	current = rRecent.Last
	if (rRecent.First == current) and not (rRecent[current] and (rRecent[current] ~= "")) then
		-- no data at all
	else
		for i = 1, rOpt.RecentEventCount.value do
			found,_,eventTime,thisCombatant = string_find(rRecent[current], rTemp.RecentFindString)
			if not found then
				--anomalous
				return nil
			end
			if thisCombatant == "*EOF*" then
				-- stick end of fight events into the deaths table
				deathTable[deathTableIndex] = { Name = "*EOF*", Death = tonumber(eventTime), Index = current, Damages = {} }
				deathTableIndex = deathTableIndex + 1
			end

			if (rRecent.First == current) then
				-- just checked the earliest event, leave the loop
				break
			end
			-- decrement circular pointer
			if current <= 1 then
				current = rOpt.RecentEventCount.value
			else
				current = current - 1
			end
		end
	end


	-- scan the auxiliary table of recent group deaths
	for i in pairs(rTemp.RecentFriendDeaths) do
		-- is this death event still legitimate (i.e. still matches its recent event)?
		if (rRecent[i] == rTemp.RecentFriendDeaths[i]) then
			found,_,eventTime,_,thisCombatant = string_find(rRecent[i], rTemp.RecentFindString)
			if not found then
				-- anomalous
				return nil
			end

			-- paranoia check
			if not (rTemp.InFriend[thisCombatant] and rCombatants[thisCombatant] and (not rCombatants[thisCombatant].OwnedBy) and (not Recap_ExtractOwner(thisCombatant))) then
				-- anomalous, somehow not a non-pet friend after all
				rTemp.RecentFriendDeaths[i] = nil -- keep as nil
			else
				-- a legitimate death event of interest

				-- create a death event (might turn out to have no data)
				skipThisDeath = false
				deathTime = tonumber(eventTime)
				deathTable[deathTableIndex] = { Name = thisCombatant, Death = deathTime, Index = i }
				damageTableIndex = 1
				deathTable[deathTableIndex].Damages = {}

				-- first, scan backwards

				-- get the event immediately prior to this death event
				current = i
				if (rRecent.First == current) then
					-- oh, this already is the first event, nothing to find scanning backwards
				else
					-- decrement circular pointer so we're no longer pointing at the death event
					if current <= 1 then
						current = rOpt.RecentEventCount.value
					else
						current = current - 1
					end

					-- now scan backwards
					damageEventCount = 0
					for j = 1, rOpt.RecentEventCount.value-1 do
						found,_,innerEventTime,innerSource,innerDest,innerEffect,_,innerPrintAmount = string_find(rRecent[current], rTemp.RecentFindString)
						if not found then
							-- anomalous
							return nil
						end

						-- outside time window?
						if (tonumber(innerEventTime) < (deathTime - earlyTimeWindow)) then
							-- done for the backwards scan
							break
						end
						-- assert: still inside backwards time window

						-- if we encounter an earlier death or killed event, abandon this later one
						if (string_sub(innerEffect, 1, 1) == "5") and (thisCombatant == innerDest) then
							-- abandon
							skipThisDeath = true
							break
						end

						-- main processing for this event
						damageEventCount, damageTableIndex = Recap_CheckDeathWindowEvent(thisCombatant, innerSource, innerDest, innerEffect, innerPrintAmount, deathTable, deathTableIndex, damageTableIndex, damageEventCount)

						-- check damage event count
						if (damageEventCount >= earlyCount) then
							-- done for the backwards scan
							break
						end
						-- assert: still inside backwards time window and backwards count window

						if (rRecent.First == current) then
							-- just checked the earliest event, leave the loop
							break
						end

						-- decrement circular pointer
						if current <= 1 then
							current = rOpt.RecentEventCount.value
						else
							current = current - 1
						end
					end -- end of backwards loop
				end -- end of backwards processing

				if skipThisDeath then
					-- we found another death earlier, so ignore this later one
					deathTable[deathTableIndex] = nil
				else
					-- second, scan forwards

					-- get the event immediately following to this death event
					current = i
					if (rRecent.Last == current) then
						-- oh, this already is the last event, nothing to find scanning forwards
					else
						-- increment circular pointer so we're no longer pointing at the death event
						if current >= rOpt.RecentEventCount.value then
							current = 1
						else
							current = current + 1
						end

						-- now scan forwards
						damageEventCount = 0
						for j = 1, rOpt.RecentEventCount.value-1 do
							found,_,innerEventTime,innerSource,innerDest,innerEffect,_,innerPrintAmount = string_find(rRecent[current], rTemp.RecentFindString)
							if not found then
								-- anomalous
								return nil
							end

							-- outside time window?
							if (tonumber(innerEventTime) > (deathTime + lateTimeWindow)) then
								-- done for the forwards scan
								break
							end
							-- assert: still inside forwards time window

							damageEventCount, damageTableIndex = Recap_CheckDeathWindowEvent(thisCombatant, innerSource, innerDest, innerEffect, innerPrintAmount, deathTable, deathTableIndex, damageTableIndex, damageEventCount)

							-- check damage event count
							if (damageEventCount >= lateCount) then
								-- done for the forwards scan
								break
							end
							-- assert: still inside forwards time window and forwards count window

							if (rRecent.Last == current) then
								-- just checked the latest event, leave the loop
								break
							end

							-- increment circular pointer
							if current >= rOpt.RecentEventCount.value then
								current = 1
							else
								current = current + 1
							end
						end -- end of forwards loop
					end -- end of forwards processing

					-- point to the next death summary
					deathTableIndex = deathTableIndex + 1
				end
			end -- end of legitimate death event
		else
			-- no match, obsolete event
			rTemp.RecentFriendDeaths[i] = nil -- keep as nil
		end
	end


	-- sort by e.g. date of death
	table_sort(deathTable, Recap_SortRecentDeaths)

	-- clear the list
	rTemp.RecentIncomingListSize = 1
	rTemp.RecentIncomingList = wipe(rTemp.RecentIncomingList)

	local iList, text, firstLine
	local sentEOF = false -- collapse multiple end of fight markers down to one

	-- now scan the summary of deaths and put it into the list for the panel
	for deathTableIndex in pairs(deathTable) do

		-- is this an end of fight marker?
		if deathTable[deathTableIndex].Name == "*EOF*" then
			-- end of fight marker
			if not sentEOF then
				if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
					rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
				end
				iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
				iList.Event = Recap_FormatTimeRecent(deathTable[deathTableIndex].Death).." --------------------------------------------------"
				iList.Index = deathTable[deathTableIndex].Index  -- hidden field storing the index of the event in the Recent buffer
				rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
				sentEOF = true
			end
		else
			-- death event, with or without damage
			text = Recap_FormatTimeRecent(deathTable[deathTableIndex].Death)..": "..Recap_StripGUIDsFromCombatant(deathTable[deathTableIndex].Name).." "..rLocalize.Died
			-- is there damage to add?
			local iDamages = deathTable[deathTableIndex].Damages
			if iDamages then
				-- sort by e.g. size of damage
				table_sort(iDamages, Recap_SortRecentDeathDamages)
				firstLine = true
				for i in pairs(iDamages) do
					if firstLine then
						text = text..": "..iDamages[i].Source.." ( "..iDamages[i].Amount.."  / "..iDamages[i].Count..")"
					else
						text = text.." + "..iDamages[i].Source.." ( "..iDamages[i].Amount.."  / "..iDamages[i].Count..")"
					end
					firstLine = false
				end
			end
			if (firstLine == true) then
				-- no data for this death (perhaps second priest Spirit of Redemption death), skip it
			else
				-- prepare list entry
				if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
					rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
				end
				iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
				iList.Event = text
				iList.Index = deathTable[deathTableIndex].Index	  -- hidden field storing the index of the event in the Recent buffer
				rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
				sentEOF = false
			end
		end
	end
	rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = nil -- keep as nil

	-- force initial scroll to bottom of list (showing most recent deaths)
	sbOffset = math_max(rTemp.RecentIncomingListSize - 1 - 18, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- clear outgoing list just in case
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- set tabs
	RecapRecent_SwitchRecents(true, true)
end

function RecapRecent_PopulateByEffect(outgoing, filterCombatant, filterEffect)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local filterType, iCombatant
	local sbOffset

	-- normal title bar contents
	if filterCombatant==rLocalize.Group.." "..rLocalize.Combatants then
		-- all group
		filterType = "Group"
		RecapRecentFaction:SetTexture("")
		RecapRecentLevel:SetText(" ")
		RecapRecentClass:SetTexCoord(.9,1,.9,1)
		RecapRecentName:SetTextColor(unpack(rColor.DmgOut))
	elseif filterCombatant==rLocalize.NonGroup.." "..rLocalize.Combatants then
		-- all non-group
		filterType = "NonGroup"
		RecapRecentFaction:SetTexture("")
		RecapRecentLevel:SetText(" ")
		RecapRecentClass:SetTexCoord(.9,1,.9,1)
		RecapRecentName:SetTextColor(unpack(rColor.White))
	else
		filterType = nil
		local iCombatant = rCombatants[filterCombatant]
		if iCombatant.Faction and rTemp.FactionIcons[iCombatant.Faction] then
			RecapRecentFaction:SetTexture(rTemp.FactionIcons[iCombatant.Faction])
		else
			RecapRecentFaction:SetTexture("")
		end
		if iCombatant.Level and tonumber(iCombatant.Level)>0 then
			RecapRecentLevel:SetText(iCombatant.Level)
		elseif iCombatant.Level and tonumber(iCombatant.Level)==-1 then
			RecapRecentLevel:SetText("??")
		else
			RecapRecentLevel:SetText(" ")
		end
		if iCombatant.Class and rTemp.ClassIcons[iCombatant.Class] then
			RecapRecentClass:SetTexCoord(rTemp.ClassIcons[iCombatant.Class].left,rTemp.ClassIcons[iCombatant.Class].right,rTemp.ClassIcons[iCombatant.Class].top,rTemp.ClassIcons[iCombatant.Class].bottom)
		else
			RecapRecentClass:SetTexCoord(.9,1,.9,1)
		end
		if iCombatant.Friend then
			RecapRecentName:SetTextColor(unpack(rColor.DmgOut))
		else
			RecapRecentName:SetTextColor(1,1,1)
		end
	end
	RecapRecentName:SetText(Recap_StripGUIDsFromCombatant(filterCombatant))
	RecapRecentIncomingLabel:SetText(RECAP_RECENT_INCOMING_EFFECTS..": "..(filterEffect or ""))
	RecapRecentOutgoingLabel:SetText(RECAP_RECENT_OUTGOING_EFFECTS..": "..(filterEffect or ""))

	if outgoing then
		rUser.RecentView = 2
	else
		rUser.RecentView = 1
	end

	rTemp.RecentSource = "Events"

	-- not ByIndex, so make sure that's off
	rTemp.RecentIndex = 0

	RecapRecent_ConstructRecentIncoming(filterCombatant, filterEffect, filterType, nil)
	-- force initial scroll to bottom of list (showing most recent events)
	sbOffset = math_max(rTemp.RecentIncomingListSize - 1 - 18, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	RecapRecent_ConstructRecentOutgoing(filterCombatant, filterEffect, filterType, nil)
	-- force initial scroll to bottom of list (showing most recent events)
	sbOffset = math_max(rTemp.RecentOutgoingListSize - 1 - 18, 0)
	FauxScrollFrame_SetOffset(RecapRecentOutgoingScrollBar, sbOffset)
	RecapRecentOutgoingScrollBar_Update()
	RecapRecentOutgoingScrollBarScrollBar:SetValue(sbOffset*14)

	-- set tabs
	RecapRecent_SwitchRecents(false, false)
end

-- We have a general problem with merge pets on
-- When stuffing pet details into the owner details, we remove GUIDs from the effect string, which is a largely one-way transformation
-- With 4.36 we now also store the pure effect name as one of the details
-- For older data there will be inconsistencies between totals and details
function RecapRecent_PopulateByDetailEntry(tabType, doFriends, effectTypeName, id, attributeText)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local sbOffset, iTable, thisCombatant, iCombatant, fightText, detailEntryTable, detailEntryTableIndex, iType, detailEntryName, thisCombatant
	local detailEntryAmount, detailEntryFormat, detailEntrySecondAmount, text, who, amount, format, secondAmount, effect, index, maxIndex, iList
	local localizedTab, effectName

	-- normal title bar contents
	RecapRecentFaction:SetTexture("")
	RecapRecentLevel:SetText("")
	RecapRecentClass:SetTexCoord(.9,1,.9,1)
	RecapRecentName:SetTextColor(unpack(rColor.WoWDefault))
	-- Note, posting code depends on the name line including RECAP_DETAIL_ENTRIES
	if doFriends then
		RecapRecentName:SetText(rLocalize.Group.." "..rLocalize.Combatants..": "..RECAP_DETAIL_ENTRIES)
	else
		RecapRecentName:SetText(rLocalize.NonGroup.." "..rLocalize.Combatants..": "..RECAP_DETAIL_ENTRIES)
	end

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	if rTemp.PanelSource == "Main" then
		iTable = rCombatants
		fightText = rLocalize.LastAll[rUser.View]
	elseif rTemp.PanelSource == "Load" then
		iTable = rTemp.Load
		fightText = RecapLoadTitle:GetText()
	else
		return
	end
	if (tabType == "Outgoing") then
		localizedTab = RECAP_OUTGOING
	elseif (tabType == "Incoming") then
		localizedTab = RECAP_INCOMING
	elseif (tabType == "Other") then
		localizedTab = rLocalize.OtherEffects
	else
		return nil
	end
	effectName = string_sub(effectTypeName,2) -- the effect that we are looking to match
	text = localizedTab.." "..effectName
	if attributeText and (attributeText ~= "") then
		text = text.." "..attributeText
	end
	text = text.." "..rLocalize.For.." "..fightText
	RecapRecentIncomingLabel:SetText(text)

	rTemp.RecentSource = "Details"

	-- always show incoming
	rUser.RecentView = 1

	-- not ByIndex, so make sure that's off
	rTemp.RecentIndex = 0

	-- create empty table for results
	detailEntryTable = {}
	detailEntryTableIndex = 1

	-- name of detail entry
	iType = tonumber(string_sub(effectTypeName,1,1))
	if (id == 67) and ((iType == 3) or (iType == 4) or ((iType == 7) and (string_find(effectTypeName, rLocalize.ElementHealing, 1, true)))) then
		-- overhealing, not miss rate
		detailEntryName = Recap_GetTooltip("PanelEntryOverheal")
	else
		detailEntryName = Recap_GetTooltip("PanelEntry"..id)
	end

	-- check all combatants
	for thisCombatant, iCombatant in pairs(iTable) do
		-- do either for Friends or for non-Friends
		if (doFriends and iCombatant and iCombatant.Friend and (not iCombatant.OwnedBy) and (not Recap_ExtractOwner(thisCombatant))) or
		   ((not doFriends) and iCombatant and (not iCombatant.Friend) and (not iCombatant.OwnedBy) and (not Recap_ExtractOwner(thisCombatant))) then
			-- friends, omit pets (they will be added in by RecapPanel_GetOneDetailEntry)
			if (thisCombatant == rTemp.GroupTotal) or (thisCombatant == rTemp.NonGroupTotal) then
				-- omit synthetic total combatants
			else
				RecapPanel_GetOneDetailEntry(iTable, thisCombatant, tabType, effectTypeName, id)

				-- partial results are in recap_temp.PartialDetailEntryTable

				local i, iEntry
				for i, iEntry in pairs(rTemp.PartialDetailEntryTable) do
					if iEntry.v1 then -- probably a redundant check
						detailEntryTable[detailEntryTableIndex] = { Name = Recap_StripGUIDsFromCombatant(thisCombatant), Effect = i, Amount = iEntry.v1 }
						if iEntry.v2 and (iEntry.v2 ~= "") then
							detailEntryTable[detailEntryTableIndex].Format = iEntry.v2
						end
						if iEntry.v3 then
							detailEntryTable[detailEntryTableIndex].SecondAmount = iEntry.v3
						end
						detailEntryTableIndex = detailEntryTableIndex + 1
					end
				end
			end
		end
	end
	detailEntryTable[detailEntryTableIndex] = nil -- keep as nil

	-- sort by amount, descending
	table_sort(detailEntryTable, Recap_SortDetailEntries)

	-- clear the list
	rTemp.RecentIncomingListSize = 1
	rTemp.RecentIncomingList = wipe(rTemp.RecentIncomingList)

	-- now scan the summary and put it into the list for the panel
	index = 0
	maxIndex = detailEntryTableIndex - 1
	for detailEntryTableIndex in pairs(detailEntryTable) do
		index = index + 1
		who = detailEntryTable[detailEntryTableIndex].Name
		amount = detailEntryTable[detailEntryTableIndex].Amount
		format = detailEntryTable[detailEntryTableIndex].Format
		secondAmount = detailEntryTable[detailEntryTableIndex].SecondAmount
		if format and (format ~= "") then
			-- some amounts get formatting
			amount = string_format(format, detailEntryTable[detailEntryTableIndex].Amount)
		end
		effect = detailEntryTable[detailEntryTableIndex].Effect
		text = index.." / "..maxIndex..". "..who..": "..localizedTab.." "..detailEntryName.." "..rLocalize.For.." "..effect
		if attributeText and (attributeText ~= "") then
			text = text.." "..attributeText
		end
		text = text..": "..amount
		if secondAmount then
			-- TODO: hmm, doesn't always seem to get appended (inconsistent), not sure why
			-- AHA: for the individuals for which it doesn't appear, their own Other entries have blank Attributes -- in turn, not sure why that should be so
			-- Perhaps they cast the Cleanse (in our example) but it didn't in fact dispel anything
			text = text.." "..secondAmount
		end
		-- prepare list entry
		if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
			rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
		end
		iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
		iList.Event = text
		iList.Index = -1		-- hidden field storing the index of the event in the Recent buffer (special flag -1 to block double click)
		rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
	end
	rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = nil -- keep as nil

	-- force initial scroll to top of list
	sbOffset = 0
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- clear outgoing list just in case
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- set tabs
	RecapRecent_SwitchRecents(true, true)
end

function RecapRecent_Hide(clear)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp

	if clear then
		rTemp.RecentIncomingSelected = 0
		rTemp.RecentOutgoingSelected = 0
		if RecapPanel:IsVisible() then
			-- other popup is visible, so simply hide
			RecapRecent:Hide()
		else
			rTemp.Selected = 0
			rTemp.RecentSelected = 0
			if not rUser.Minimized then
				RecapScrollBar_Update()
			end
		end
	end

	if rTemp.Selected==0 then
		RecapRecent:Hide()
	end
end

function RecapRecentHeader_OnEnter(frame, header)

	local line1,line2 = Recap_GetTooltip(header)
	if line1 and line2 then
		Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.PostRowsTooltip)
	end
end

function RecapRecent_OutgoingList_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapRecentOutgoingScrollBar)

	if (index<rTemp.RecentOutgoingListSize) then
		-- we are on an event or death or detail or something
		if rOpt.ShowTooltips.value and rOpt.ShowClickHints.value then
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			if (rTemp.RecentSource == "Events") or (rTemp.RecentSource == "DIEvents") or (rTemp.RecentSource == "Deaths") then
				rTemp.RecapTooltip:SetText(rLocalize.RecentRowTooltip, .565, .565, 1.0, 1)
			else
				-- others, viz. Detail Entries
				rTemp.RecapTooltip:SetText(rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
			end
			rTemp.RecapTooltip:Show()
		end
	end
end

function RecapRecent_IncomingList_OnEnter(frame)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapRecentIncomingScrollBar)

	if (index<rTemp.RecentIncomingListSize) then
		-- we are on an event or death or detail or something
		if rOpt.ShowTooltips.value and rOpt.ShowClickHints.value then
			rTemp.RecapTooltip:ClearAllPoints()
			if not rOpt.TooltipFollow.value then
				GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
			else
				rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
			end
			if (rTemp.RecentSource == "Events") or (rTemp.RecentSource == "DIEvents") or (rTemp.RecentSource == "Deaths") then
				rTemp.RecapTooltip:SetText(rLocalize.RecentRowTooltip, .565, .565, 1.0, 1)
			else
				-- others, viz. Detail Entries
				rTemp.RecapTooltip:SetText(rLocalize.PostRowTooltip, .565, .565, 1.0, 1)
			end
			rTemp.RecapTooltip:Show()
		end
	end
end

function RecapRecentTab_OnEnter(frame)

	local id = frame:GetID()

	if id and id>0 then
		Recap_Tooltip(frame, "RecentTab"..id)
	end
end

function RecapRecentTab_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local id = frame:GetID()
	rUser.RecentView = id
	RecapRecent_SwitchRecents(false, false)
end

function RecapRecent_SwitchRecents(hideTabs, hidePrevNext)

	local rUser = _G.recap_user
	local i

	for i=1,2 do
		_G["RecapRecentTab"..i]:UnlockHighlight()
		_G["RecapSubRecent"..i]:Hide()
	end
	_G["RecapRecentTab"..rUser.RecentView]:LockHighlight()
	_G["RecapSubRecent"..rUser.RecentView]:Show()

	if hideTabs then
		RecapRecentTab1:Hide()
		RecapRecentTab2:Hide()
	else
		RecapRecentTab1:Show()
		RecapRecentTab2:Show()
	end
	if hidePrevNext then
		RecapRecentPreviousEndOfFightButton:Hide()
		RecapRecentNextEndOfFightButton:Hide()
	else
		RecapRecentPreviousEndOfFightButton:Show()
		RecapRecentNextEndOfFightButton:Show()
	end
end

function RecapRecentIncomingScrollBar_Update()

	local rTemp = _G.recap_temp
	local i, index, iList, item

	if rTemp.Loaded and rTemp.RecentIncomingListSize then

		FauxScrollFrame_Update(RecapRecentIncomingScrollBar,rTemp.RecentIncomingListSize-1,18,14)

		for i=1,18 do
			index = i + FauxScrollFrame_GetOffset(RecapRecentIncomingScrollBar)
			if index < rTemp.RecentIncomingListSize then
				iList = rTemp.RecentIncomingList[index]
				_G["RecapRecentIncoming"..i.."_Event"]:SetText(iList.Event)
				_G["RecapRecentIncoming"..i.."_Event"]:SetTextColor(RecapRecent_DetermineColor(iList.Event, false))
				_G["RecapRecentIncoming"..i.."_Index"]:SetText(iList.Index)
				if iList.Index == rTemp.RecentIndex then
					-- special text prefix for the RecentIndex item, and select the row
					_G["RecapRecentIncoming"..i.."_Event"]:SetText(">>>>>   "..iList.Event)
					rTemp.RecentIncomingSelected = index
				end
				item = _G["RecapRecentIncoming"..i]
				item:Show()
				if rTemp.RecentIncomingSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapRecentIncoming"..i]
				item:Hide()
				item:UnlockHighlight()
			end
		end
	end

end

function RecapRecentOutgoingScrollBar_Update()

	local rTemp = _G.recap_temp
	local i, index, iList, item

	if rTemp.Loaded and rTemp.RecentOutgoingListSize then

		FauxScrollFrame_Update(RecapRecentOutgoingScrollBar,rTemp.RecentOutgoingListSize-1,18,14)

		for i=1,18 do
			index = i + FauxScrollFrame_GetOffset(RecapRecentOutgoingScrollBar)
			if index < rTemp.RecentOutgoingListSize then
				iList = rTemp.RecentOutgoingList[index]
				_G["RecapRecentOutgoing"..i.."_Event"]:SetText(iList.Event)
				_G["RecapRecentOutgoing"..i.."_Event"]:SetTextColor(RecapRecent_DetermineColor(iList.Event, true))
				_G["RecapRecentOutgoing"..i.."_Index"]:SetText(iList.Index)
				if iList.Index == rTemp.RecentIndex then
					-- special text prefix for the RecentIndex item, and select the row
					_G["RecapRecentOutgoing"..i.."_Event"]:SetText(">>>>>   "..iList.Event)
					rTemp.RecentOutgoingSelected = index
				end
				item = _G["RecapRecentOutgoing"..i]
				item:Show()
				if rTemp.RecentOutgoingSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapRecentOutgoing"..i]
				item:Hide()
				item:UnlockHighlight()
			end
		end
	end

end

-- clicks on individual effect lines
function RecapRecent_Incoming_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapRecentIncomingScrollBar)

	if (index < rTemp.RecentIncomingListSize) then

		-- detect double-click
		local isDoubleClick = false
		local thisRecentIndex = _G["RecapRecentIncoming"..id.."_Index"]:GetText()
		local thisClickTime = GetTime()
		if thisRecentIndex == rTemp.IncomingPriorRecentIndex then
			-- another click on the same index
			if (thisClickTime - rTemp.IncomingPriorClickTime) < 0.3 then
				-- two clicks on the same index within less than 0.3 seconds, call it a double-click
				isDoubleClick = true
			end
		end
		rTemp.IncomingPriorRecentIndex = thisRecentIndex
		rTemp.IncomingPriorClickTime = thisClickTime

		-- double click on a Deaths or Detail Entry line, ignore since these aren't normal recent events after all
		if tonumber(thisRecentIndex) == -1 then
			isDoubleClick = false
		end

		if IsShiftKeyDown() and (not IsAltKeyDown()) and not isDoubleClick then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			Recap_InsertChat("Recap: ".._G["RecapRecentIncoming"..id.."_Event"]:GetText(), nil, RecapRecent_escapeColor(_G["RecapRecentIncoming"..id.."_Event"]))

		elseif not IsShiftKeyDown() and isDoubleClick then
			-- bring up a Recent events box centred on the event and holding a number of events in each direction
			-- get the index into the Recent buffer for use by the scrollbar code
			rTemp.RecentIndex = tonumber(thisRecentIndex)
			RecapRecent:Hide()
			RecapRecent_PopulateByIndex()
			RecapRecent:Show()

		elseif (rTemp.RecentIncomingSelected == index) then
			rTemp.RecentIncomingSelected = 0
			RecapRecentIncomingScrollBar_Update()

		else
			rTemp.RecentIncomingSelected = index
			RecapRecentIncomingScrollBar_Update()
		end
	end
end

-- clicks on individual effect lines
function RecapRecent_Outgoing_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapRecentOutgoingScrollBar)

	if (index < rTemp.RecentOutgoingListSize) then

		-- detect double-click
		local isDoubleClick = false
		local thisRecentIndex = _G["RecapRecentOutgoing"..id.."_Index"]:GetText()
		local thisClickTime = GetTime()
		if thisRecentIndex == rTemp.OutgoingPriorRecentIndex then
			-- another click on the same index
			if (thisClickTime - rTemp.OutgoingPriorClickTime) < 0.3 then
				-- two clicks on the same index within less than 0.3 seconds, call it a double-click
				isDoubleClick = true
			end
		end
		rTemp.OutgoingPriorRecentIndex = thisRecentIndex
		rTemp.OutgoingPriorClickTime = thisClickTime

		-- double click on a Deaths or Detail Entry line, ignore since these aren't normal recent events after all
		if tonumber(thisRecentIndex) == -1 then
			isDoubleClick = false
		end

		if IsShiftKeyDown() and (not IsAltKeyDown()) and not isDoubleClick then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			Recap_InsertChat("Recap: ".._G["RecapRecentOutgoing"..id.."_Event"]:GetText(), nil, RecapRecent_escapeColor(_G["RecapRecentOutgoing"..id.."_Event"]))

		elseif not IsShiftKeyDown() and isDoubleClick then
			-- bring up a Recent events box centred on the event and holding a number of events in each direction
			-- get the index into the Recent buffer for use by the scrollbar code
			rTemp.RecentIndex = tonumber(thisRecentIndex)
			RecapRecent:Hide()
			RecapRecent_PopulateByIndex()
			RecapRecent:Show()

		elseif (rTemp.RecentOutgoingSelected==index) then
			rTemp.RecentOutgoingSelected = 0
			RecapRecentOutgoingScrollBar_Update()

		else
			rTemp.RecentOutgoingSelected = index
			RecapRecentOutgoingScrollBar_Update()
		end
	end
end

function RecapRecent_OnMouseDown(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapRecent:StartMoving()
	end
end

function RecapRecent_OnMouseUp(frame, button)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapRecent:StopMovingOrSizing()

		-- check for docking
		rUser.RecentAnchor.value = false

		if Recap_Near(RecapFrame:GetRight(),RecapRecent:GetLeft()) then
			if Recap_Near(RecapFrame:GetTop(),RecapRecent:GetTop()) then
				rUser.RecentAnchor = { value=true, Main="TOPRIGHT", Recent="TOPLEFT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapRecent:GetBottom()) then
				rUser.RecentAnchor = { value=true, Main="BOTTOMRIGHT", Recent="BOTTOMLEFT"}
			end
		elseif Recap_Near(RecapFrame:GetLeft(),RecapRecent:GetRight()) then
			if Recap_Near(RecapFrame:GetTop(),RecapRecent:GetTop()) then
				rUser.RecentAnchor = { value=true, Main="TOPLEFT", Recent="TOPRIGHT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapRecent:GetBottom()) then
				rUser.RecentAnchor = { value=true, Main="BOTTOMLEFT", Recent="BOTTOMRIGHT" }
			end
		elseif Recap_Near(RecapFrame:GetRight(),RecapRecent:GetRight()) then
			if Recap_Near(RecapFrame:GetTop(),RecapRecent:GetBottom()) then
				rUser.RecentAnchor = { value=true, Main="TOPRIGHT", Recent="BOTTOMRIGHT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapRecent:GetTop()) then
				rUser.RecentAnchor = { value=true, Main="BOTTOMRIGHT", Recent="TOPRIGHT" }
			end
		elseif Recap_Near(RecapFrame:GetLeft(),RecapRecent:GetLeft()) then
			if Recap_Near(RecapFrame:GetTop(),RecapRecent:GetBottom()) then
				rUser.RecentAnchor = { value=true, Main="TOPLEFT", Recent="BOTTOMLEFT" }
			elseif Recap_Near(RecapFrame:GetBottom(),RecapRecent:GetTop()) then
				rUser.RecentAnchor = { value=true, Main="BOTTOMLEFT", Recent="TOPLEFT" }
			end
		end

		if rUser.RecentAnchor.value then
			RecapRecent:ClearAllPoints()
			RecapRecent:SetPoint(rUser.RecentAnchor.Recent,"RecapFrame",rUser.RecentAnchor.Main,Recap_RecentOffset("x"),Recap_RecentOffset("y"))
		end

	end
end

function Recap_RecentOffset(axis)

	local rUser = _G.recap_user
	local anchor

	anchor = rUser.RecentAnchor.Main..rUser.RecentAnchor.Recent
	if dockoffset[anchor] and axis then
		return dockoffset[anchor][axis]
	else
		return 0
	end
end

function RecapRecentPreviousEndOfFight_OnClick(frame, button)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local sbOffset, newRecentIndex
	local first, last, i, index, sentEOF, iList, message

	if not rOpt.RecentData.value then
		return nil
	end

	-- normal title bar contents
	RecapRecentFaction:SetTexture("")
	RecapRecentLevel:SetText("")
	RecapRecentClass:SetTexCoord(.9,1,.9,1)
	RecapRecentName:SetTextColor(unpack(rColor.WoWDefault))
	RecapRecentName:SetText(rLocalize.AllCombatants)

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	RecapRecentIncomingLabel:SetText(RECAP_RECENT_EVENTS)

	rTemp.RecentSource = "Events"

	-- show incoming only
	rUser.RecentView = 1

	-- clear the list
	rTemp.RecentIncomingListSize = 1
	rTemp.RecentIncomingList = wipe(rTemp.RecentIncomingList)
	sbOffset = 0

	if rRecent then

		first = rRecent.First
		last = rRecent.Last
		if rTemp.RecentIndex and (rTemp.RecentIndex ~= 0) then
			i = rTemp.RecentIndex
		else
			-- no recent index, start from last event
			i = last
		end

		-- figure out the previous end of fight, prior to RecentIndex
		newRecentIndex = -1
		for index=1, rOpt.RecentEventCount.value do
			local found, _, source
			found,_,_,source = string_find(rRecent[i], rTemp.RecentFindString)
			if not found then
				--anomalous
				return nil
			end
			if source == "*EOF*" then
				if index == 1 then
					-- this end of fight is where we started, ignore it
				else
					-- this is a different end of fight, it's the one we want
					newRecentIndex = i
					break
				end
			end
			if (i == first) then
				-- found the earliest event, leave the loop
				break
			end
			-- increment circular pointer
			if i <= 1 then
				i = rOpt.RecentEventCount.value
			else
				i = i - 1
			end
		end
		if newRecentIndex == -1 then
			-- didn't find an EOF marker, use the first event
			rTemp.RecentIndex = first
		else
			rTemp.RecentIndex = newRecentIndex
		end

		-- now go up to another 200 events earlier
		for index=1, 200 do
			sbOffset = index
			if (i == first) then
				-- found the earliest event, leave the loop
				break
			end
			-- increment circular pointer
			if i <= 1 then
				i = rOpt.RecentEventCount.value
			else
				i = i - 1
			end
		end

		if (i == last) and not (rRecent[i] and (rRecent[i] ~= "")) then
			-- no data at all
		else
			-- list up to 400 events forward from the earlier point
			sentEOF = false -- set to skip any double 'end of fight' markers
			for index=1, 401 do
				if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
					rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
				end
				iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
				local found, _, eventTime, source
				found,_,eventTime,source = string_find(rRecent[i], rTemp.RecentFindString)
				if not found then
					-- anomalous
					return nil
				end
				if source == "*EOF*" then
					-- maybe post an 'end of fight' marker
					if sentEOF == true then
						-- avoid sending two 'end of fight' indicators in a row
					else
						-- special 'end of fight' line
						message = Recap_FormatTimeRecent(tonumber(eventTime)).." --------------------------------------------------"
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = true
					end
				else
					-- not an 'end of fight'
					message = Recap_FormatRecentEvent(i, false, nil, nil, nil)
					if message then
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = false
					end
				end
				if (i == last) then
					-- just posted the most recent one, leave the loop
					break
				end
				-- increment circular pointer
				if i >= rOpt.RecentEventCount.value then
					i = 1
				else
					i = i + 1
				end
			end
		end
	end
	rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = nil -- keep as nil

	-- put indexed end of fight near the centre of the window
	sbOffset = math_max(sbOffset - 9, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- clear outgoing list just in case
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- set tabs
	RecapRecent_SwitchRecents(true, false)

end

function RecapRecentNextEndOfFight_OnClick(frame, button)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local sbOffset, newRecentIndex
	local first, last, i, index, sentEOF, iList, message

	if not rOpt.RecentData.value then
		return nil
	end

	-- normal title bar contents
	RecapRecentFaction:SetTexture("")
	RecapRecentLevel:SetText("")
	RecapRecentClass:SetTexCoord(.9,1,.9,1)
	RecapRecentName:SetTextColor(unpack(rColor.WoWDefault))
	RecapRecentName:SetText(rLocalize.AllCombatants)

	rTemp.RecentIncomingSelected = 0
	rTemp.RecentOutgoingSelected = 0
	RecapRecentIncomingLabel:SetText(RECAP_RECENT_EVENTS)

	rTemp.RecentSource = "Events"

	-- show incoming only
	rUser.RecentView = 1

	-- clear the list
	rTemp.RecentIncomingListSize = 1
	rTemp.RecentIncomingList = wipe(rTemp.RecentIncomingList)
	sbOffset = 0

	if rRecent then

		first = rRecent.First
		last = rRecent.Last
		if rTemp.RecentIndex and (rTemp.RecentIndex ~= 0) then
			i = rTemp.RecentIndex
		else
			-- no recent index, start from last event
			i = last
		end

		-- figure out the next end of fight, following RecentIndex
		newRecentIndex = -1
		for index=1, rOpt.RecentEventCount.value do
			local found, _, source
			found,_,_,source = string_find(rRecent[i], rTemp.RecentFindString)
			if not found then
				--anomalous
				return nil
			end
			if source == "*EOF*" then
				if index == 1 then
					-- this end of fight is where we started, ignore it
				else
					-- this is a different end of fight, it's the one we want
					newRecentIndex = i
					break
				end
			end
			if (i == last) then
				-- found the latest event, leave the loop
				break
			end
			-- increment circular pointer
			if i >= rOpt.RecentEventCount.value then
				i = 1
			else
				i = i + 1
			end
		end
		if newRecentIndex == -1 then
			-- didn't find an EOF marker, use the last event
			rTemp.RecentIndex = last
		else
			rTemp.RecentIndex = newRecentIndex
		end

		-- now go up to 200 events earlier
		for index=1, 200 do
			sbOffset = index
			if (i == first) then
				-- found the earliest event, leave the loop
				break
			end
			-- increment circular pointer
			if i <= 1 then
				i = rOpt.RecentEventCount.value
			else
				i = i - 1
			end
		end

		if (i == last) and not (rRecent[i] and (rRecent[i] ~= "")) then
			-- no data at all
		else
			-- list up to 400 events forward from the earlier point
			sentEOF = false -- set to skip any double 'end of fight' markers
			for index=1, 401 do
				if not rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] then
					rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = {}
				end
				iList = rTemp.RecentIncomingList[rTemp.RecentIncomingListSize]
				local found, _, eventTime, source
				found,_,eventTime,source = string_find(rRecent[i], rTemp.RecentFindString)
				if not found then
					-- anomalous
					return nil
				end
				if source == "*EOF*" then
					-- maybe post an 'end of fight' marker
					if sentEOF == true then
						-- avoid sending two 'end of fight' indicators in a row
					else
						-- special 'end of fight' line
						message = Recap_FormatTimeRecent(tonumber(eventTime)).." --------------------------------------------------"
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = true
					end
				else
					-- not an 'end of fight'
					message = Recap_FormatRecentEvent(i, false, nil, nil, nil)
					if message then
						iList.Event = message
						iList.Index = i		-- hidden field storing the index of the event in the Recent buffer
						rTemp.RecentIncomingListSize = rTemp.RecentIncomingListSize + 1
						sentEOF = false
					end
				end
				if (i == last) then
					-- just posted the most recent one, leave the loop
					break
				end
				-- increment circular pointer
				if i >= rOpt.RecentEventCount.value then
					i = 1
				else
					i = i + 1
				end
			end
		end
	end
	rTemp.RecentIncomingList[rTemp.RecentIncomingListSize] = nil -- keep as nil

	-- put indexed end of fight near the centre of the window
	sbOffset = math_max(sbOffset - 9, 0)
	FauxScrollFrame_SetOffset(RecapRecentIncomingScrollBar, sbOffset)
	RecapRecentIncomingScrollBar_Update()
	RecapRecentIncomingScrollBarScrollBar:SetValue(sbOffset*14)

	-- clear outgoing list just in case
	rTemp.RecentOutgoingListSize = 1
	rTemp.RecentOutgoingList = wipe(rTemp.RecentOutgoingList)

	-- set tabs
	RecapRecent_SwitchRecents(true, false)

end


-- click on header on detail panel, send that header info for all combatants
function RecapRecentIncomingHeader_OnClick(frame, button, down)
	local rTemp = _G.recap_temp
	if IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.RecentIncomingListSize>1) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		if string_find(RecapRecentName:GetText(), RECAP_DETAIL_ENTRIES, 1, true) then
			-- if detail entries, post the first N, not the last N
			RecapRecent_PostEvents("RecentIncomingEvents", rTemp.RecentIncomingList, rTemp.RecentIncomingListSize-1, false, false)
		else
			-- regular, post the last N
			RecapRecent_PostEvents("RecentIncomingEvents", rTemp.RecentIncomingList, rTemp.RecentIncomingListSize-1, false, true)
		end
	end
end

-- click on header on detail panel, send that header info for all effects
function RecapRecentOutgoingHeader_OnClick(frame, button, down)
	local rTemp = _G.recap_temp
	if IsShiftKeyDown() and (not IsAltKeyDown()) and (rTemp.RecentOutgoingListSize>1) then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		RecapRecent_PostEvents("RecentOutgoingEvents", rTemp.RecentOutgoingList, rTemp.RecentOutgoingListSize-1, true, true)
	end
end

RecapRecent_lua_4773 = true
