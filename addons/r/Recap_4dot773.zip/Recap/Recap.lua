﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[
		Recap - Hawksy (on Elune)
			  - original development by Gello (versions 3.32 and earlier)

		An AddOn for WoW to track and summarize all damage and healing done around the user, and most other combat-related events.
]]

Recap_Version = 4.773
Recap_Sync_Version = 465 -- used to determine compatible versions of synchronization (integer for compact transmission) (only update if Recap sync format changes so as to be incompatible)

local math_max = _G.math.max
local math_min = _G.math.min
local math_floor = _G.math.floor
local string_find = _G.string.find
local string_format = _G.string.format
local string_gmatch = _G.string.gmatch
local string_gsub = _G.string.gsub
local string_len = _G.string.len
local string_lower = _G.string.lower
local string_sub = _G.string.sub
local table_remove = _G.table.remove
local table_sort = _G.table.sort
-- note new functions with 3.0: string.split, string.join, string.concat, string.trim
local pairs = _G.pairs
local ipairs = _G.ipairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ Saved Variables ]]

recap = {} -- options and current data (saved to SavedVariables)
recap_set = {} -- fight data sets (saved to SavedVariables)
recap_ignore = {} -- ignores (saved to SavedVariables)
recap_user = {} -- options and state variables (saved to character-specific SavedVariables)
recap_combatants = {} -- combatants (saved to character-specific SavedVariables)
recap_compressed = nil -- data and combatants saved in compressed form to character-specific SavedVariables -- has to stay nil
recap_back = {} -- backup copy of all character-specific recap_user data (saved to SavedVariables)


--[[ local tables ]]

-- colors for the gauges (also defines what can be gauged)
local gaugecolor = { ["DmgIn"] = { 0.66,0.25,0.25 }, ["DmgOut"] = { 0.25,0.66,0.35 }, ["Heal"] = { 0.25,0.5,0.85 },
					 ["Time"] = { 0.25,0.66,0.35 }, ["Deaths"] = { 0.75,0.75,0.75 }, ["MaxHit"] = { 0.25,0.66,0.35 },
					 ["DPS"] = { 0.25,0.66,0.35 }, ["DPSPerGear"] = { 0.25,0.66,0.35 }, ["Over"] = { 0.25,0.5,0.85 },
					 ["TimeIn"] = { 0.66,0.25,0.25 }, ["TimeHeal"] = { 0.25,0.5,0.85 }, ["DPSIn"] = { 0.66,0.25,0.25 },
					 ["HPS"] = { 0.25,0.5,0.85 }, ["Dispels"] = { 0.85,0.85,0.85 }, ["Interrupts"] = { 0.85,0.85,0.85 } }

-- .Opt.x and its buttons
local recapbuttons = { ["Minimized"] = "RecapMinimizeButton", ["Pinned"] = "RecapPinButton",
					   ["Paused"] = "RecapPauseButton", ["SelfView"] = "RecapSelfViewButton" }


--[[ Ace3 setup ]]

-- mixin AceComm for sync purposes
Recap = LibStub("AceAddon-3.0"):NewAddon("Recap", "AceComm-3.0", "AceSerializer-3.0", "AceTimer-3.0")

-- some debuggers look for these variables
Recap.version = string_format("%.3f", Recap_Version)
Recap.revision = ""


-- LibDataBroker
local ldb = nil
local lastAll = nil
local yourDPS = nil
local yourHPS = nil
local groupDPSOut = nil
local groupHPS = nil
local yourDmgIn = nil
local yourDmgOut = nil
local yourPetPercent = nil
local yourHealing = nil
local yourMaxHit = nil
function Recap_EnableLDBSupport()
	ldb = LibStub:GetLibrary("LibDataBroker-1.1")
	lastAll = ldb:NewDataObject("Recap All / Last",
		{type = "data source",
		 tocname = "Recap",
		 text = "",
		 icon = "Interface\\AddOns\\Recap\\Images\\Recap-Status",
		 iconR = 0.5,
		 iconG = 0.5,
		 iconB = 0.5,
		 OnClick = function(clickedframe, button)
			RecapFrame_Toggle()
		 end,
		})
	yourDPS = ldb:NewDataObject("Recap Your DPS", {type = "data source", tocname = "Recap", text = "0.0"})
	yourHPS = ldb:NewDataObject("Recap Your HPS", {type = "data source", tocname = "Recap", text = "0.0"})
	groupDPSOut = ldb:NewDataObject("Recap Group DPS Out", {type = "data source", tocname = "Recap", text = "0.0"})
	groupHPS = ldb:NewDataObject("Recap Group HPS", {type = "data source", tocname = "Recap", text = "0.0"})
	yourDmgIn = ldb:NewDataObject("Recap Your Damage In", {type = "data source", tocname = "Recap", text = "0"})
	yourDmgOut = ldb:NewDataObject("Recap Your Damage Out", {type = "data source", tocname = "Recap", text = "0"})
	yourPetPercent = ldb:NewDataObject("Recap Your Pet Percent", {type = "data source", tocname = "Recap", text = "0"})
	yourHealing = ldb:NewDataObject("Recap Your Healing", {type = "data source", tocname = "Recap", text = "0"})
	yourMaxHit = ldb:NewDataObject("Recap Your Maximum Hit", {type = "data source", tocname = "Recap", text = "0"})
end


--[[ local functions (precede first use) ]]

local function Recap_JoinLeaveGroup()
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	-- remind player on joining and leaving a group
	-- GetNumSubgroupMembers returns number of *other* people, not counting you
	-- GetNumGroupMembers returns number of people, including you
	local count = math_max(1+GetNumSubgroupMembers(),GetNumGroupMembers())
	if (rUser.NumPartyMembers == 1) and (count > 1) then

		StaticPopupDialogs["rTemp.REMINDJOINGROUP"] = {
			text = rLocalize.RemindJoinGroup,
			button1 = BINDING_NAME_RECAP_RESET_ALL,
			button2 = OKAY,
			OnShow = function(self)
				if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
					-- No reset if in synchronization
					StaticPopup1Button1:Disable()
				end
			end,
			OnAccept = function(self)
				-- Reset if applicable
				if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
					-- No reset if in synchronization (button was disabled anyway)
				else
					PlaySound("GnomeExploration")
					RecapPanel_Hide(1)
					RecapRecent_Hide(1)
					RecapLoad_Hide()
					Recap_ResetAllCombatants(false)
					RecapGraph_InitializeLiveLists()
					Recap_SetView()
					Recap_MakeFriends(true)
					print(rTemp.Recap, RECAP_ALL_FIGHTS_RESET)
				end
			end,
			OnHide = function(self)
			end,
			OnCancel = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.REMINDJOINGROUP")

	elseif (rUser.NumPartyMembers > 1) and (count == 1) then
		StaticPopupDialogs["rTemp.REMINDLEAVEGROUP"] = {
			text = rLocalize.RemindLeaveGroup,
			button1 = OKAY,
			OnAccept = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.REMINDLEAVEGROUP")

	end
	rUser.NumPartyMembers = count
end

local function Recap_EnterLeaveInstance(enteredInstance, leftInstance)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	-- remind player on entering and leaving an instance
	if enteredInstance then
		StaticPopupDialogs["rTemp.REMINDENTERINSTANCE"] = {
			text = rLocalize.RemindEnterInstance,
			button1 = BINDING_NAME_RECAP_RESET_ALL,
			button2 = OKAY,
			OnShow = function(self)
				if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
					-- No reset if in synchronization
					StaticPopup1Button1:Disable()
				end
			end,
			OnAccept = function(self)
				-- Reset if applicable
				if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
					-- No reset if in synchronization (button was disabled anyway)
				else
					PlaySound("GnomeExploration")
					RecapPanel_Hide(1)
					RecapRecent_Hide(1)
					RecapLoad_Hide()
					Recap_ResetAllCombatants(false)
					RecapGraph_InitializeLiveLists()
					Recap_SetView()
					Recap_MakeFriends(true)
					print(rTemp.Recap, RECAP_ALL_FIGHTS_RESET)
				end
			end,
			OnHide = function(self)
			end,
			OnCancel = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.REMINDENTERINSTANCE")
	end

	if leftInstance then
		StaticPopupDialogs["rTemp.REMINDLEAVEINSTANCE"] = {
			text = rLocalize.RemindLeaveInstance,
			button1 = OKAY,
			OnAccept = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.REMINDLEAVEINSTANCE")
	end

end

local function Recap_CheckInstance()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local inInstance, instanceType

	inInstance, instanceType = IsInInstance()

	-- figure out if we've just entered or left an instance
	--   (note that we might be playing catch-up)
	local enteredInstance = false
	local leftInstance = false
	if inInstance then
		if rUser.InsideInstance == false then
			enteredInstance = true
			rUser.InsideInstance = true
		end
	else
		if rUser.InsideInstance == true then
			leftInstance = true
			rUser.InsideInstance = false
		end
	end

	-- figure out if we've just entered or left a battleground instance
	--   (note that we might be playing catch-up)
	local enteredBattleground = false
	local leftBattleground = false
	if inInstance and (instanceType == "pvp") then
		if rUser.InsideBattleground == false then
			enteredBattleground = true
			rUser.InsideBattleground = true
		end
	else
		if rUser.InsideBattleground == true then
			leftBattleground = true
			rUser.InsideBattleground = false
		end
	end

	-- state transition logic (this has been unusually tricky, and I'm still not 100% certain that I have it right)
	if rOpt.PauseOutsideInstances.value and (not rOpt.PauseInsideBattlegrounds.value) then
		if enteredInstance or enteredBattleground then
			-- assert: now inside an instance (of any kind)
			-- we need to be running
			if (rUser.State=="Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			else
				-- was active or idle, stay active or idle
			end
		elseif leftInstance then
			-- assert: now outside an instance (of any kind)
			-- we need to be stopped
			if (rUser.State=="Stopped") then
				-- was paused, stay paused
			else
				-- was active or idle, need to pause
--print("(Recap) EndFight due to leaving instance")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		elseif leftBattleground then
			-- assert: we didn't leave an instance, but we are no longer inside a battleground
			-- maybe anomalous, assume we are now inside an ordinary instance
			-- we need to be running
			if (rUser.State=="Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			else
				-- was active or idle, stay active or idle
			end
		end
	elseif (not rOpt.PauseOutsideInstances.value) and rOpt.PauseInsideBattlegrounds.value then
		if enteredBattleground then
			-- assert: now inside a battleground instance
			-- we need to be stopped
			if (rUser.State=="Stopped") then
				-- was paused, stay paused
			else
				-- was active or idle, need to pause
--print("(Recap) EndFight due to entering battleground")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		elseif leftBattleground then
			-- assert: now no longer in a battleground instance
			-- we need to be running
			if (rUser.State=="Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			else
				-- was active or idle, stay active or idle
			end
		elseif enteredInstance or leftInstance then
			-- assert: this was not a battleground transition
			-- we need to keep our current state unchanged
		end
	elseif rOpt.PauseOutsideInstances.value and rOpt.PauseInsideBattlegrounds.value then
		if enteredInstance and (rUser.InsideBattleground == false) then
			-- assert: now inside an ordinary instance
			-- we need to be running
			if (rUser.State=="Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			else
				-- was active or idle, stay active or idle
			end
		elseif enteredBattleground or (enteredInstance and (rUser.InsideBattleground == true)) then
			-- assert: now inside a battleground instance (either in a normal way, or maybe anomalously)
			-- we need to be stopped
			if (rUser.State=="Stopped") then
				-- was paused, stay paused
			else
				-- was active or idle, need to pause
--print("(Recap) EndFight due to entering battleground")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		elseif leftInstance then
			-- assert: now outside an instance (of any kind)
			-- the Instances setting takes precedence over the Battlegrounds setting
			-- we need to be stopped
			if (rUser.State=="Stopped") then
				-- was paused, stay paused
			else
				-- was active or idle, need to pause
--print("(Recap) EndFight due to leaving instance")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		elseif leftBattleground then
			-- assert: we didn't leave an instance, but we are no longer inside a battleground
			-- maybe anomalous, assume we are inside an ordinary instance
			-- we need to be running
			if (rUser.State=="Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			else
				-- was active or idle, stay active or idle
			end
		end
	else
		-- neither flag is set, do nothing
	end

	-- reminder too, if that option is on
	if rOpt.RemindInstanceStatus.value then
		if enteredInstance or enteredBattleground then
			Recap_EnterLeaveInstance(enteredInstance, leftInstance) -- contains a non-blocking dialog
		elseif leftInstance or leftBattleground then
			Recap_EnterLeaveInstance(enteredInstance, leftInstance) -- contains a non-blocking dialog
		end
	end

end

-- repositions RecapFrame if any part of it goes off the screen
local function Recap_CheckWindowBounds()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local frameLeft, frameTop, frameRight, frameBottom, newScale
	local parentRight, parentLeft, parentTop, parentBottom
	local needs_moved = false

	if rTemp.Loaded and RecapFrame then
		frameLeft = RecapFrame:GetLeft()
		frameTop = RecapFrame:GetTop()
		if frameLeft and frameTop then
			frameRight = RecapFrame:GetRight()
			frameBottom = RecapFrame:GetBottom()
			newScale = Recap_Div2(rOpt.SetScale.value,100)
			parentRight = UIParent:GetRight()/newScale
			parentLeft = UIParent:GetLeft()/newScale
			parentTop = UIParent:GetTop()/newScale
			parentBottom = UIParent:GetBottom()/newScale

			if frameRight and parentRight and frameRight > parentRight then
				frameLeft = frameLeft + parentRight - frameRight
				needs_moved = true
			elseif parentLeft and parentLeft > frameLeft then
				frameLeft = frameLeft + parentLeft - frameLeft
				needs_moved = true
			end

			if frameTop and frameTop > parentTop then
				frameTop = frameTop + parentTop - frameTop
				needs_moved = true
			elseif parentBottom and parentBottom > frameBottom then
				frameTop = frameTop + parentBottom - frameBottom
				needs_moved = true
			end

			if needs_moved then
				RecapFrame:ClearAllPoints()
				RecapFrame:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(frameLeft,0),math_max(frameTop,0))
			end

			rUser.WindowTop = RecapFrame:GetTop()
			rUser.WindowLeft = RecapFrame:GetLeft()
			rUser.WindowHeight = RecapFrame:GetHeight()
			rUser.WindowWidth = RecapFrame:GetWidth()

		else
			-- default behaviour if any undefined
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("CENTER","UIParent","CENTER")
		end
	end

end

-- action==1 to hide buttons, 16 to show
local function Recap_ShowButtons(action)

	RecapCloseButton:SetWidth(action)
	RecapPinButton:SetWidth(action)
	RecapPauseButton:SetWidth(action)
	RecapOptionsButton:SetWidth(action)
	RecapShowAllButton:SetWidth(action)

	if action==16 then
		RecapCloseButton:Show()
		RecapPinButton:Show()
		RecapPauseButton:Show()
		RecapOptionsButton:Show()
		RecapShowAllButton:Show()
	else
		RecapCloseButton:Hide()
		RecapPinButton:Hide()
		RecapPauseButton:Hide()
		RecapOptionsButton:Hide()
		RecapShowAllButton:Hide()
	end
end

local function Recap_SetHeight(newcy)

	local rOpt = _G.recap_temp.Opt
	local i,j

	if rOpt.GrowUpwards.value and RecapFrame then
		i = RecapFrame:GetBottom()
		j = RecapFrame:GetLeft()
		if i and j then
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(j,0),math_max(i+newcy,0))
		else
			-- default behaviour if any undefined
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("CENTER","UIParent","CENTER")
		end
	end

	RecapFrame:SetHeight(newcy)
	Recap_CheckWindowBounds()

end

--[[ Initialization ]]

local function Recap_IntegrityCheck()
	-- TODO: these statements, and the corresponding declarations, need to be updated for every version
	if not Recap_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(Recap.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapCombat_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapCombat.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapSync_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapSync.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapAux_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapAux.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapOptions_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapOptions.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapClipboard_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapClipboard.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapPanel_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapPanel.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapRecent_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapRecent.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapLoad_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapLoad.lua)")
		Recap_Shutdown()
		return false
	end
	if not RecapGraph_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapGraph.lua)")
		Recap_Shutdown()
		return false
	end
	if not Recap_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(Recap.xml)")
		Recap_Shutdown()
		return false
	end
	if not RecapOptions_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapOptions.xml)")
		Recap_Shutdown()
		return false
	end
	if not RecapClipboard_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapClipboard.xml)")
		Recap_Shutdown()
		return false
	end
	if not RecapPanel_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapPanel.xml)")
		Recap_Shutdown()
		return false
	end
	if not RecapRecent_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapRecent.xml)")
		Recap_Shutdown()
		return false
	end
	if not RecapLoad_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapLoad.xml)")
		Recap_Shutdown()
		return false
	end
	if not RecapGraph_xml_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(RecapGraph.xml)")
		Recap_Shutdown()
		return false
	end
	if not localization_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(localization.lua)")
		Recap_Shutdown()
		return false
	end
	if not localization_de_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(localization.de.lua)")
		Recap_Shutdown()
		return false
	end
	if not localization_cn_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(localization.cn.lua)")
		Recap_Shutdown()
		return false
	end
	if not localization_tw_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(localization.tw.lua)")
		Recap_Shutdown()
		return false
	end
	if not localization_br_lua_4773 then
		print("|cFFFF6666"..rLocalize.VersionCheck, "(localization.br.lua)")
		Recap_Shutdown()
		return false
	end
	return true
end

-- functions to support the live DPS (etc.) calculations

-- returns the current DPS of combatant (used only when pets not merged)
-- now also damage, max hit, damage in
local function Recap_GetCurrentLiveDmg(combatant, iLast)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local durationLast, damageLast, DPSLast, maxHitLast, damageInLast, iTotal, durationAll, damageAll, DPSAll, maxHitAll, damageInAll
	durationLast = 0
	damageLast = 0
	DPSLast = 0
	maxHitLast = 0
	damageInLast = 0
	durationAll = 0
	damageAll = 0
	DPSAll = 0
	maxHitAll = 0
	damageInAll = 0
	if iLast and (iLast.DmgOut > 0) then
		if iLast.StartOut > 0 and (iLast.EndOut > iLast.StartOut) then
			durationLast = iLast.EndOut - iLast.StartOut
		end
		damageLast = iLast.DmgOut
		maxHitLast = iLast.MaxHit
	end
	if durationLast > rTemp.MinTime then
		DPSLast = Recap_Div1(damageLast, durationLast)
	end
	if iLast then
		damageInLast = iLast.DmgIn
	end
	iTotal = rCombatants[combatant]
	if iTotal then
		durationAll = durationLast + (iTotal.TotalTime or 0)
		damageAll = damageLast + (iTotal.TotalDmgOut or 0)
		maxHitAll = math_max(maxHitLast, (iTotal.TotalMaxHit or 0))
		damageInAll = damageInLast + (iTotal.TotalDmgIn or 0)
	end
	if durationAll > rTemp.MinTime then
		DPSAll = Recap_Div1(damageAll, durationAll)
	end
	return DPSLast, DPSAll, damageLast, damageAll, maxHitLast, maxHitAll, damageInLast, damageInAll
end

-- returns the current HPS of combatant
-- now also healing, overhealing
local function Recap_GetCurrentLiveHeal(combatant, iLast)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local durationLast, healingLast, HPSLast, overhealingLast, iTotal, durationAll, healingAll, HPSAll, overhealingAll
	durationLast = 0
	healingLast = 0
	HPSLast = 0
	overhealingLast = 0
	durationAll = 0
	healingAll = 0
	HPSAll = 0
	overhealingAll = 0
	if iLast and (iLast.RawHeal > 0) then
		if (iLast.StartHeal > 0) and (iLast.EndHeal > iLast.StartHeal) then
			durationLast = iLast.EndHeal - iLast.StartHeal
		end
		overhealingLast = math_min(iLast.OverHeal, iLast.RawHeal)
		healingLast = iLast.RawHeal - overhealingLast
	end
	if durationLast > rTemp.MinTime then
		HPSLast = Recap_Div1(healingLast, durationLast)
	end
	iTotal = rCombatants[combatant]
	if iTotal then
		durationAll = durationLast + (iTotal.TotalTimeHeal or 0)
		overhealingAll = math_min((iTotal.TotalOverHeal or 0), (iTotal.TotalRawHeal or 0))
		healingAll = healingLast + (iTotal.TotalRawHeal or 0) - overhealingAll
	end
	if durationAll > rTemp.MinTime then
		HPSAll = Recap_Div1(healingAll, durationAll)
	end
	return HPSLast, HPSAll, healingLast, healingAll, overhealingLast, overhealingAll
end

local function Recap_GetCurrentLiveDmgMergePets(owner, iLastOwner)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, iLastPet, startTime, endTime, durationLast, damageLast, petsDamageLast, DPSLast, maxHitLast, damageInLast, iTotal, durationAll, damageAll, petsDamageAll, DPSAll, maxHitAll, damageInAll
	startTime = 0
	endTime = 0
	durationLast = 0
	damageLast = 0
	petsDamageLast = 0
	DPSLast = 0
	maxHitLast = 0
	damageInLast = 0
	durationAll = 0
	damageAll = 0
	petsDamageAll = 0
	DPSAll = 0
	maxHitAll = 0
	damageInAll = 0
	if iLastOwner and (iLastOwner.DmgOut > 0) then
		-- owner did damage
		startTime = iLastOwner.StartOut
		endTime = iLastOwner.EndOut
		damageLast = iLastOwner.DmgOut
		maxHitLast = iLastOwner.MaxHit
	end
	if iLastOwner then
		damageInLast = iLastOwner.DmgIn
	end
	-- optimization for a scan of Last looking for player's pets
	for i in pairs(rTemp.LastPlayerPets) do
		iLastPet = rTemp.Last[i]
		if iLastPet and (iLastPet.DmgOut > 0) then
			-- player owns or controls this one
			-- this pet did damage, merge times and add damages
			if (startTime > 0) and (iLastPet.StartOut > 0) then
				startTime = math_min(startTime, iLastPet.StartOut)
			elseif (startTime == 0) then
				startTime = iLastPet.StartOut
			end
			if (endTime > 0) then
				endTime = math_max(endTime, iLastPet.EndOut)
			else
				endTime = iLastPet.EndOut
			end
			damageLast = damageLast + iLastPet.DmgOut
			petsDamageLast = petsDamageLast + iLastPet.DmgOut
			maxHitLast = math_max(maxHitLast, (iLastPet.MaxHit or 0))
		end
		if iLastPet then
			damageInLast = damageInLast + iLastPet.DmgIn
		end
	end
	if (startTime > 0) and (endTime > startTime) then
		durationLast = endTime - startTime
	end
	if durationLast > rTemp.MinTime then
		DPSLast = Recap_Div1(damageLast, durationLast)
	end
	iTotal = rCombatants[owner]
	if iTotal then
		durationAll = durationLast + (iTotal.TotalTime or 0)
		damageAll = damageLast + (iTotal.TotalDmgOut or 0)
		petsDamageAll = petsDamageLast + (iTotal.TotalPetsDmgOut or 0)
		maxHitAll = math_max(maxHitLast, (iTotal.TotalMaxHit or 0))
		damageInAll = damageInLast + (iTotal.TotalDmgIn or 0)
	end
	if durationAll > rTemp.MinTime then
		DPSAll = Recap_Div1(damageAll, durationAll)
	end
	return DPSLast, DPSAll, damageLast, damageAll, petsDamageLast, petsDamageAll, maxHitLast, maxHitAll, damageInLast, damageInAll
end

local function Recap_GetCurrentLiveHealMergePets(owner, iLastOwner)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, iLastPet, startTime, endTime, durationLast, healingLast, HPSLast, overhealingLast, overhealingPetLast, iTotal, durationAll, healingAll, HPSAll, overhealingAll
	startTime = 0
	endTime = 0
	durationLast = 0
	healingLast = 0
	HPSLast = 0
	overhealingLast = 0
	durationAll = 0
	healingAll = 0
	HPSAll = 0
	overhealingAll = 0
	if iLastOwner and (iLastOwner.RawHeal>0) then
		-- owner did healing
		startTime = iLastOwner.StartHeal
		endTime = iLastOwner.EndHeal
		overhealingLast = math_min(iLastOwner.OverHeal, iLastOwner.RawHeal)
		healingLast = iLastOwner.RawHeal - overhealingLast
	end
	-- optimization for a scan of Last looking for player's pets
	for i in pairs(rTemp.LastPlayerPets) do
		iLastPet = rTemp.Last[i]
		if iLastPet and (iLastPet.RawHeal > 0) then
			-- player owns or controls this one
			-- this pet did healing, merge times and add healing
			if (startTime > 0) and (iLastPet.StartHeal > 0) then
				startTime = math_min(startTime,iLastPet.StartHeal)
			elseif (startTime == 0) then
				startTime = iLastPet.StartHeal
			end
			if (endTime > 0) then
				endTime = math_max(endTime,iLastPet.EndHeal)
			else
				endTime = iLastPet.EndHeal
			end
			overhealingPetLast = math_min(iLastPet.OverHeal,iLastPet.RawHeal)
			healingLast = healingLast + iLastPet.RawHeal - overhealingPetLast
			overhealingLast = overhealingLast + overhealingPetLast
		end
	end
	if startTime > 0 and (endTime > startTime) then
		durationLast = endTime - startTime
	end
	if durationLast > rTemp.MinTime then
		HPSLast = Recap_Div1(healingLast, durationLast)
	end
	iTotal = rCombatants[owner]
	if iTotal then
		durationAll = durationLast + (iTotal.TotalTimeHeal or 0)
		overhealingAll = math_min((iTotal.TotalOverHeal or 0), (iTotal.TotalRawHeal or 0))
		healingAll = healingLast + (iTotal.TotalRawHeal or 0) - overhealingAll
	end
	if durationAll > rTemp.MinTime then
		HPSAll = Recap_Div1(healingAll, durationAll)
	end
	return HPSLast, HPSAll, healingLast, healingAll, overhealingLast, overhealingAll
end

local function Recap_AddSelfListPlayerAndPets()

	local rSelf = _G.recap.Self
	local rTemp = _G.recap_temp
	local i, j, k, iSelf, iEffect, iList
	local found, _, petName
	local idx, damage, heal, miss
	idx = 1
	damage = 0
	heal = 0
	miss = 0

	-- preliminary cleanup scan, remove any entries that are empty tables
	-- one pass only, this will not remove them all due to the nature of lua tables, but if we do it every visit we will eventually get most or all of them
	for i in pairs(rSelf) do
		local foundOuterEntry = false
		for j in pairs(rSelf[i]) do
			local foundInnerEntry = false
			for k in pairs(rSelf[i][j]) do
				foundInnerEntry = true
				break
			end
			if foundInnerEntry == false then
				-- no data, remove entry
				rSelf[i][j] = nil
			end
			foundOuterEntry = true
			break
		end
		if foundOuterEntry == false then
			-- no data, remove entry
			rSelf[i] = nil
		end
	end
	-- end of preliminary cleanup scan

	-- main event
	for i, iSelf in pairs(rSelf) do
		if string_find(i, rTemp.s, 1, true) then
			-- this is the player or one of the player's pets
			for j, iEffect in pairs(iSelf) do
				if not rTemp.SelfList[idx] then
					rTemp.SelfList[idx] = {}
				end
				iList = rTemp.SelfList[idx]
				-- skip effects that have zero damage
				local total
				total = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.TicksDmg or 0)
				if total == 0 then
					iEffect = nil -- keep as nil
				else
					found,_,petName = string_find(i, "^.+:(.+)$")
					if found then
						-- one of the pets
						if string_sub(j,1,1)=="1" then
							iList.EName = "2"..petName..": "..string_sub(j,2)
						else
							iList.EName = "4"..petName..": "..string_sub(j,2)
						end
					else
						-- the player
						iList.EName = j
					end
					iList.EElement = iEffect.Element or "?"
					iList.ETotal = total
					iList.EGlances = iEffect.Glances or 0
					iList.EHits = iEffect.Hits or 0
					iList.ECrits = iEffect.Crits or 0
					iList.ETicks = iEffect.Ticks or 0
					iList.EGlancesMin = iEffect.GlancesMin or 0
					iList.EHitsMin = iEffect.HitsMin or 0
					iList.ETicksMin = iEffect.TicksMin or 0
					iList.ECritsMin = iEffect.CritsMin or 0
					iList.EGlancesMax = iEffect.GlancesMax or 0
					iList.EHitsMax = iEffect.HitsMax or 0
					iList.ETicksMax = iEffect.TicksMax or 0
					iList.ECritsMax = iEffect.CritsMax or 0
					-- make the averages into numbers (not strings) to allow for sorting
					iList.EGlancesAvg = tonumber(string_format("%d",((iList.EGlances>0) and Recap_Div0((iEffect.GlancesDmg or 0),iList.EGlances) or 0)))
					iList.EHitsAvg = tonumber(string_format("%d",((iList.EHits>0) and Recap_Div0((iEffect.HitsDmg or 0),iList.EHits) or 0)))
					iList.ETicksAvg = tonumber(string_format("%d",((iList.ETicks>0) and Recap_Div0((iEffect.TicksDmg or 0),iList.ETicks) or 0)))
					iList.ECritsAvg = tonumber(string_format("%d",((iList.ECrits>0) and Recap_Div0((iEffect.CritsDmg or 0),iList.ECrits) or 0)))
					iList.EMaxAll = math_max( iList.EHitsMax, math_max(iList.ETicksMax,iList.ECritsMax) )
					if (tonumber(string_sub(j,1,1)) == 1) or (tonumber(string_sub(j,1,1)) == 2) then -- damage event
						miss = (iEffect.Missed or 0) + (iEffect.Dodged or 0) + (iEffect.Parried or 0) + (iEffect.Blocked or 0) +
								(iEffect.Deflected or 0) + (iEffect.Resisted or 0) + (iEffect.Reflected or 0) + (iEffect.Absorbed or 0) +
								(iEffect.Immune or 0) + (iEffect.Evaded or 0)
						iList.EMiss = miss
						k = miss + iList.EGlances + iList.EHits + iList.ECrits
						iList.ECritsP = string_format("%.1f%%",(k>0) and Recap_Div1(100*iList.ECrits,k) or 0)
						iList.EMissP = string_format("%.1f%%",(k>0) and Recap_Div1(100*iList.EMiss,k) or 0)
						damage = damage + iList.ETotal
					else
						k = iList.EGlances + iList.EHits + iList.ECrits -- yeah I know, heals probably don't glance, but it doesn't hurt, and if they ever do Recap will be ready
						iList.ECritsP = string_format("%.1f%%",(k>0) and Recap_Div1(100*iList.ECrits,k) or 0)
						iList.EMiss = "--"
						iList.EMissP = "--"
						heal = heal + iList.ETotal
					end

					if iList.ETicks==0 then
						iList.ETicks = "--"
						iList.ETicksMin = "--"
						iList.ETicksAvg = "--"
						iList.ETicksMax = "--"
					end
					if not iEffect.CritsEvents then
						iList.ECrits = "--"
						iList.ECritsMin = "--"
						iList.ECritsAvg = "--"
						iList.ECritsMax = "--"
						iList.ECritsP = "--"
						iList.EHits = "--"
						iList.EHitsMin = "--"
						iList.EHitsAvg = "--"
						iList.EHitsMax = "--"
						iList.EGlances = "--"
						iList.EGlancesMin = "--"
						iList.EGlancesAvg = "--"
						iList.EGlancesMax = "--"
					end

					idx = idx + 1
				end
			end
		end
	end

	return idx, damage, heal, miss
end

-- three functions allowing the Personal Details panel to be sorted
--   by column (damage effects always appear first, healing effects second) (function
--   Recap_SelfDamageSort, which was a fixed sort, has been removed)
local function Recap_SortSelfDown(e1,e2)

	local rUser = _G.recap_user
	local effect1, effect2, value1, value2

	if e1.EName and e2.EName then
		effect1 = string_sub(e1.EName,1,1)
		effect2 = string_sub(e2.EName,1,1)
		if e1[rUser.ESortBy] and e2[rUser.ESortBy] then
			value1 = e1[rUser.ESortBy]
			if value1 == "--" then
				value1 = -1
			end
			-- turn a percentage string into a number
			if (type(value1) == "string") and (string_sub(value1, -1) == "%") then
				value1 = tonumber(string_sub(value1, 1, string_len(value1)-1))
			end
			value2 = e2[rUser.ESortBy]
			if value2 == "--" then
				value2 = -1
			end
			-- turn a percentage string into a number
			if (type(value2) == "string") and (string_sub(value2, -1) == "%") then
				value2 = tonumber(string_sub(value2, 1, string_len(value2)-1))
			end
			if (((value1 < value2) and (effect1==effect2)) or (effect1<effect2)) then
				return true
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end

end

local function Recap_SortSelfUp(e1,e2)

	local rUser = _G.recap_user
	local effect1, effect2, value1, value2

	if e1.EName and e2.EName then
		effect1 = string_sub(e1.EName,1,1)
		effect2 = string_sub(e2.EName,1,1)
		if e1[rUser.ESortBy] and e2[rUser.ESortBy] then
			value1 = e1[rUser.ESortBy]
			if value1 == "--" then
				value1 = -1
			end
			-- turn a percentage string into a number
			if (type(value1) == "string") and (string_sub(value1, -1) == "%") then
				value1 = tonumber(string_sub(value1, 1, string_len(value1)-1))
			end
			value2 = e2[rUser.ESortBy]
			if value2 == "--" then
				value2 = -1
			end
			-- turn a percentage string into a number
			if (type(value2) == "string") and (string_sub(value2, -1) == "%") then
				value2 = tonumber(string_sub(value2, 1, string_len(value2)-1))
			end
			if (((value1 > value2) and (effect1==effect2)) or (effect1<effect2)) then
				return true
			else
				return false
			end
		else
			return false
		end
	else
		return false
	end

end

local function Recap_SortSelfList()
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rUser.ESortBy then
		if rUser.ESortDir then
			table_sort(rTemp.SelfList,Recap_SortSelfDown)
		else
			table_sort(rTemp.SelfList,Recap_SortSelfUp)
		end
	end

end

local function Recap_ConstructSelf()

	local rTemp = _G.recap_temp
	local damage, heal, miss, i, j, iSelf, iType

	-- clear the 'SelfList' table entirely
	rTemp.SelfListSize = 1
	rTemp.SelfList = wipe(rTemp.SelfList)

	-- Add player, and all of player's pets
	rTemp.SelfListSize, damage, heal, miss = Recap_AddSelfListPlayerAndPets()

	if rTemp.SelfListSize>1 then
		for i=1,rTemp.SelfListSize-1 do
			iSelf = rTemp.SelfList[i]
			iType = string_sub(iSelf.EName,1,1)
			if ((iType == "1") or (iType == "2")) and damage>0 then
				iSelf.ETotalP = string_format("%d%%",Recap_Div0(100*iSelf.ETotal,damage))
			elseif ((iType == "3") or (iType == "4")) and heal>0 then
				iSelf.ETotalP = string_format("%d%%",Recap_Div0(100*iSelf.ETotal,heal))
			else
				iSelf.ETotalP = "--"
			end
		end
	end

	-- now sort the personal details by any column
	Recap_SortSelfList()
end

local function Recap_DefineGauges()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, thisCombatant

	rTemp.GaugeMax = 0

	if rTemp.ListSize>1 then
		rTemp.GaugeBy = string_gsub(rUser.SortBy,"P$","")
		rTemp.GaugeBy = rTemp.GaugeBy=="DPSvsAll" and "DmgOut" or rTemp.GaugeBy
		if not gaugecolor[rTemp.GaugeBy] then
			rTemp.GaugeBy = false
		else
			for i=1,rTemp.ListSize-1 do
				thisCombatant = rTemp.List[i].Name
				if thisCombatant and rCombatants[thisCombatant] and rCombatants[thisCombatant].Friend and rTemp.GaugeBy then
					rTemp.GaugeMax = math_max(rTemp.List[i][rTemp.GaugeBy],rTemp.GaugeMax)
				end
			end
			for i=1,15 do
				_G["RecapList"..i.."_Gauge"]:SetVertexColor(unpack(gaugecolor[rTemp.GaugeBy]))
			end
		end
	end
end

local function Recap_GetSelectedByName(name)

	local rTemp = _G.recap_temp
	local sel, i = 0
	local thisCombatant

	if name and rTemp.ListSize>1 then
		for i=1,rTemp.ListSize-1 do
			thisCombatant = rTemp.List[i].Name
			if thisCombatant and (thisCombatant==name) then
				sel = i
			end
		end
	end

	return sel
end

--[[ Sorting functions ]]

local function Recap_SortDown(e1,e2)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants

	if rUser.SortBy=="Class" then
		-- special case for Class, which is an icon ('texture')
		local c1 = rCombatants[e1.Name]
		local c2 = rCombatants[e2.Name]
		if not (c1 and c1.Class) and (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return false
		end
		if (c1 and c1.Class) and not (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return true
		end
		if c1 and c2 and c1.Class and c2.Class then
			if ( c1.Class < c2.Class ) then
				return true
			else
				return false
			end
		else
			return false
		end
	elseif rUser.SortBy=="Name" then
		-- special case for Name, which we need without GUIDs, and for which we sort identical names in "First Seen" order
		if e1.Name and e2.Name then
			local e1Name = Recap_StripGUIDsFromCombatant(e1.Name)
			local e2Name = Recap_StripGUIDsFromCombatant(e2.Name)
			if ( e1Name < e2Name ) then
				return true
			elseif ( e1Name == e2Name ) then
				if e1.Seen and e2.Seen then
					if ( e1.Seen < e2.Seen ) then
						return true
					else
						return false
					end
				else
					return false
				end
			else
				return false
			end
		else
			return false
		end
	else
		if e1[rUser.SortBy] and e2[rUser.SortBy] then
			-- bypass a problem with mixed strings and numbers
			if type(e1[rUser.SortBy]) == type(e2[rUser.SortBy]) then
				-- types match, normal compare
				if ( e1[rUser.SortBy] < e2[rUser.SortBy] ) then
					return true
				else
					return false
				end
			else
				-- types don't match, force string compare
				-- this may be due to a damaged saved variables file, but bypass it anyway
				if ( tostring(e1[rUser.SortBy]) < tostring(e2[rUser.SortBy]) ) then
					return true
				else
					return false
				end
			end
		else
			return false
		end
	end

end

local function Recap_SortUp(e1,e2)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants

	if rUser.SortBy=="Class" then
		-- special case for Class, which is an icon ('texture')
		local c1 = rCombatants[e1.Name]
		local c2 = rCombatants[e2.Name]
		if not (c1 and c1.Class) and (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return false
		end
		if (c1 and c1.Class) and not (c2 and c2.Class) then
			-- so that classless combatants sort to end
			return true
		end
		if c1 and c2 and c1.Class and c2.Class then
			if ( c1.Class > c2.Class ) then
				return true
			else
				return false
			end
		else
			return false
		end
	elseif rUser.SortBy=="Name" then
		-- special case for Name, which we need without GUIDs, and for which we sort identical names in "First Seen" order
		if e1.Name and e2.Name then
			local e1Name = Recap_StripGUIDsFromCombatant(e1.Name)
			local e2Name = Recap_StripGUIDsFromCombatant(e2.Name)
			if ( e1Name > e2Name ) then
				return true
			elseif ( e1Name == e2Name ) then
				if e1.Seen and e2.Seen then
					if ( e1.Seen > e2.Seen ) then
						return true
					else
						return false
					end
				else
					return false
				end
			else
				return false
			end
		else
			return false
		end
	else
		if e1[rUser.SortBy] and e2[rUser.SortBy] then
			-- bypass a problem with mixed strings and numbers
			if type(e1[rUser.SortBy]) == type(e2[rUser.SortBy]) then
				-- types match, normal compare
				if ( e1[rUser.SortBy] > e2[rUser.SortBy] ) then
					return true
				else
					return false
				end
			else
				-- types don't match, force string compare
				-- this may be due to a damaged saved variables file, but bypass it anyway
				if ( tostring(e1[rUser.SortBy]) > tostring(e2[rUser.SortBy]) ) then
					return true
				else
					return false
				end
			end
		else
			return false
		end
	end

end

-- perform stable insertion sort on the list
local function Recap_SortFriends()

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, j, iList, other

	if rTemp.ListSize>2 then
		for i=2,(rTemp.ListSize-1) do
			iList = rTemp.List[i]
			if (iList) and (iList.Name) and (rCombatants[iList.Name]) and (rCombatants[iList.Name].Friend) then
				j=i
				while (j>1) do
					other = rTemp.List[j-1]
					if (other) and (other.Name) and (rCombatants[other.Name]) and (not rCombatants[other.Name].Friend) then
						rTemp.List[j] = other
						j = j - 1
					else
						break
					end
				end
				rTemp.List[j] = iList
			end
		end
	end

end

-- initial sort by field done with table.sort for speed, then
-- friends shifted to top with an insertion sort for "stable" list
local function Recap_SortList()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local temp

	-- remember the last ('Total') element
	temp = rTemp.List[rTemp.ListSize]

	-- remove the last element from the 'List' table in case it could confuse 'table.sort'
	table_remove(rTemp.List) -- without second parameter this defaults to last element

	if rUser.SortBy then
		if rUser.SortDir then
			table_sort(rTemp.List,Recap_SortDown)
		else
			table_sort(rTemp.List,Recap_SortUp)
		end
		Recap_SortFriends()
	end

	-- restore the last ('Total') element
	rTemp.List[rTemp.ListSize] = temp

	Recap_DefineGauges()

end

local function Recap_ClearGrandTotal(thisTotal)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	if type(rCombatants[thisTotal]) == "table" then
		rCombatants[thisTotal] = wipe(rCombatants[thisTotal])
	else
		rCombatants[thisTotal] = {}
	end
	if thisTotal == rTemp.GroupTotal then
		rCombatants[thisTotal].Friend = true
	else
		rCombatants[thisTotal].Friend = false
	end
end

local function Recap_AccumulateDetails(iTotalDetail, iDetail)

	local j, jDetail

	if iDetail then
		for j, jDetail in pairs(iDetail) do
			if (j == "Effect") then
				-- copy (value should be same from all sources)
				iTotalDetail[j] = jDetail
			elseif (j == "Element") then
				-- fancy merge
				iTotalDetail[j] = Recap_MergeEntries(iTotalDetail[j], jDetail)
			elseif (j == "SpellID") then
				-- fancy merge
				iTotalDetail[j] = Recap_MergeEntries(iTotalDetail[j], jDetail)
			elseif (j == "Attribute") then
				-- direct copy (not a composite string)
				iTotalDetail[j] = jDetail
			elseif (j == "PrevTime") or (j == "PrevTimeDur") then
				-- ignore
			elseif (j == "GlancesMin") or (j == "HitsMin") or (j == "TicksMin") or (j == "CritsMin") or (j == "CrushMin") then
				-- minima
				iTotalDetail[j] = Recap_Min(iTotalDetail[j], jDetail)
			elseif (j == "GlancesMax") or (j == "HitsMax") or (j == "TicksMax") or (j == "CritsMax") or (j == "CrushMax") then
				-- maxima
				iTotalDetail[j] = math_max((iTotalDetail[j] or 0), jDetail)
			else
				-- everything else is a straight sum
				iTotalDetail[j] = (iTotalDetail[j] or 0) + jDetail
			end
		end
	end
end

local function Recap_AccumulateGrandTotal(thisTotal, thisCombatant, AllLastOutgoingDetail, AllLastIncomingDetail, AllLastOtherDetail)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local iLast = rTemp.DisplayLastFight
	local i, j, iTotal, iCombatant

	iTotal = rCombatants[thisTotal]
	iCombatant = rCombatants[thisCombatant]

	-- accumulate across all combatants into a single hidden combatant named "Group Total"
	if iCombatant[AllLastOutgoingDetail] then
		for i in pairs(iCombatant[AllLastOutgoingDetail]) do
			if not iTotal[AllLastOutgoingDetail] then
				iTotal[AllLastOutgoingDetail] = {}
			end
			if not iTotal[AllLastOutgoingDetail][i] then
				iTotal[AllLastOutgoingDetail][i] = {}
			end
			Recap_AccumulateDetails(iTotal[AllLastOutgoingDetail][i], iCombatant[AllLastOutgoingDetail][i])
		end
	end
	if iCombatant[AllLastIncomingDetail] then
		for i in pairs(iCombatant[AllLastIncomingDetail]) do
			if not iTotal[AllLastIncomingDetail] then
				iTotal[AllLastIncomingDetail] = {}
			end
			if not iTotal[AllLastIncomingDetail][i] then
				iTotal[AllLastIncomingDetail][i] = {}
			end
			Recap_AccumulateDetails(iTotal[AllLastIncomingDetail][i], iCombatant[AllLastIncomingDetail][i])
		end
	end
	if iCombatant[AllLastOtherDetail] then
		for i in pairs(iCombatant[AllLastOtherDetail]) do
			if not iTotal[AllLastOtherDetail] then
				iTotal[AllLastOtherDetail] = {}
			end
			if not iTotal[AllLastOtherDetail][i] then
				iTotal[AllLastOtherDetail][i] = {}
			end
			Recap_AccumulateDetails(iTotal[AllLastOtherDetail][i], iCombatant[AllLastOtherDetail][i])
		end
	end

	-- include some total values
	j = (iTotal.TotalTime or 0) + (iCombatant.TotalTime or 0)
	if j>0 then
		iTotal.TotalTime = j
	end
	j = (iTotal.TotalTimeIn or 0) + (iCombatant.TotalTimeIn or 0)
	if j>0 then
		iTotal.TotalTimeIn = j
	end
	j = (iTotal.TotalTimeHeal or 0) + (iCombatant.TotalTimeHeal or 0)
	if j>0 then
		iTotal.TotalTimeHeal = j
	end
	j = math_max((iTotal.TotalMaxHit or 0), (iCombatant.TotalMaxHit or 0))
	if j>0 then
		iTotal.TotalMaxHit = j
	end
	j = (iTotal.TotalDeaths or 0) + (iCombatant.TotalDeaths or 0)
	if j>0 then
		iTotal.TotalDeaths = j
	end
	j = (iTotal.TotalDispels or 0) + (iCombatant.TotalDispels or 0)
	if j>0 then
		iTotal.TotalDispels = j
	end
	j = (iTotal.TotalInterrupts or 0) + (iCombatant.TotalInterrupts or 0)
	if j>0 then
		iTotal.TotalInterrupts = j
	end
	j = (iTotal.TotalRawHeal or 0) + (iCombatant.TotalRawHeal or 0)
	if j>0 then
		iTotal.TotalRawHeal = j
	end
	j = (iTotal.TotalOverHeal or 0) + (iCombatant.TotalOverHeal or 0)
	if j>0 then
		iTotal.TotalOverHeal = j
	end
	j = (iTotal.TotalDmgIn or 0) + (iCombatant.TotalDmgIn or 0)
	if j>0 then
		iTotal.TotalDmgIn = j
	end
	j = (iTotal.TotalDmgOut or 0) + (iCombatant.TotalDmgOut or 0)
	if j>0 then
		iTotal.TotalDmgOut = j
	end
	if iCombatant.WasInLast then
		j = (iTotal["LastTime_"..iLast] or 0) + (iCombatant["LastTime_"..iLast] or 0)
		if j>0 then
			iTotal["LastTime_"..iLast] = j
		end
		j = (iTotal["LastTimeIn_"..iLast] or 0) + (iCombatant["LastTimeIn_"..iLast] or 0)
		if j>0 then
			iTotal["LastTimeIn_"..iLast] = j
		end
		j = (iTotal["LastTimeHeal_"..iLast] or 0) + (iCombatant["LastTimeHeal_"..iLast] or 0)
		if j>0 then
			iTotal["LastTimeHeal_"..iLast] = j
		end
		j = math_max((iTotal["LastMaxHit_"..iLast] or 0), (iCombatant["LastMaxHit_"..iLast] or 0))
		if j>0 then
			iTotal["LastMaxHit_"..iLast] = j
		end
		j = (iTotal["LastDeaths_"..iLast] or 0) + (iCombatant["LastDeaths_"..iLast] or 0)
		if j>0 then
			iTotal["LastDeaths_"..iLast] = j
		end
		j = (iTotal["LastDispels_"..iLast] or 0) + (iCombatant["LastDispels_"..iLast] or 0)
		if j>0 then
			iTotal["LastDispels_"..iLast] = j
		end
		j = (iTotal["LastInterrupts_"..iLast] or 0) + (iCombatant["LastInterrupts_"..iLast] or 0)
		if j>0 then
			iTotal["LastInterrupts_"..iLast] = j
		end
		j = (iTotal["LastRawHeal_"..iLast] or 0) + (iCombatant["LastRawHeal_"..iLast] or 0)
		if j>0 then
			iTotal["LastRawHeal_"..iLast] = j
		end
		j = (iTotal["LastOverHeal_"..iLast] or 0) + (iCombatant["LastOverHeal_"..iLast] or 0)
		if j>0 then
			iTotal["LastOverHeal_"..iLast] = j
		end
		j = (iTotal["LastDmgIn_"..iLast] or 0) + (iCombatant["LastDmgIn_"..iLast] or 0)
		if j>0 then
			iTotal["LastDmgIn_"..iLast] = j
		end
		j = (iTotal["LastDmgOut_"..iLast] or 0) + (iCombatant["LastDmgOut_"..iLast] or 0)
		if j>0 then
			iTotal["LastDmgOut_"..iLast] = j
		end
	end
end

local function Recap_DoGrandTotal(thisTotal)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local iLast = rTemp.DisplayLastFight
	local i, iCombatant, iTotal

	local AllLastOutgoingDetail = "OutgoingDetail"
	local AllLastIncomingDetail = "IncomingDetail"
	local AllLastOtherDetail = "OtherDetail"
	if rUser.View=="Last" then
		AllLastOutgoingDetail = "LastOutgoingDetail_"..iLast
		AllLastIncomingDetail = "LastIncomingDetail_"..iLast
		AllLastOtherDetail = "LastOtherDetail_"..iLast
	end

	-- accumulate
	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			if ((iCombatant["LastDmgIn_"..iLast]==nil or iCombatant["LastDmgIn_"..iLast]==0) and
				(iCombatant["LastDmgOut_"..iLast]==nil or iCombatant["LastDmgOut_"..iLast]==0) and
				(iCombatant.TotalDmgOut==nil or iCombatant.TotalDmgOut==0) and
				(iCombatant.TotalDmgIn==nil or iCombatant.TotalDmgIn==0) and
				(iCombatant["LastRawHeal_"..iLast]==nil or iCombatant["LastRawHeal_"..iLast]==0) and
				(iCombatant.TotalRawHeal==nil or iCombatant.TotalRawHeal==0)) or
			   (rOpt.HideOthers.value and (not iCombatant.Friend)) or
			   (rOpt.HideGroup.value and (not Recap_CheckForSelf(i)) and iCombatant.Friend) or
			   (rOpt.HideYardTrash.value and not iCombatant.Friend and Recap_CombatantIsTrash(i)) or
			   (iCombatant.Ignore) then
				-- ignore unwanted combatants (if-statement code duplicated from earlier)

			elseif rUser.View=="Last" and iCombatant.WasInLast then
				if not rOpt.HideZero.value or ((iCombatant["LastTime_"..iLast] and (iCombatant["LastTime_"..iLast] > rTemp.MinTime)) or
												(iCombatant["LastTimeIn_"..iLast] and (iCombatant["LastTimeIn_"..iLast] > rTemp.MinTime)) or
												(iCombatant["LastTimeHeal_"..iLast] and (iCombatant["LastTimeHeal_"..iLast] > rTemp.MinTime))) then
					if (thisTotal == rTemp.GroupTotal) and iCombatant.Friend then
						-- this is a valid group combatant; add their Outgoing, Incoming, and Other Details to a hidden combatant called "Group Total"
						Recap_AccumulateGrandTotal(thisTotal, i, AllLastOutgoingDetail, AllLastIncomingDetail, AllLastOtherDetail)
					elseif (thisTotal == rTemp.NonGroupTotal) and not iCombatant.Friend then
						-- this is a valid non-group combatant; add their Outgoing, Incoming, and Other Details to a hidden combatant called "Non-Group Total"
						Recap_AccumulateGrandTotal(thisTotal, i, AllLastOutgoingDetail, AllLastIncomingDetail, AllLastOtherDetail)
					end
				end

			elseif rUser.View=="All" then
				if not rOpt.HideZero.value or ((iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime)) or
												(iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime)) or
												(iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime))) then
					if (thisTotal == rTemp.GroupTotal) and iCombatant.Friend then
						-- this is a valid group combatant; add their Outgoing, Incoming, and Other Details to a hidden combatant called "Group Total"
						Recap_AccumulateGrandTotal(thisTotal, i, AllLastOutgoingDetail, AllLastIncomingDetail, AllLastOtherDetail)
					elseif (thisTotal == rTemp.NonGroupTotal) and not iCombatant.Friend then
						-- this is a valid non-group combatant; add their Outgoing, Incoming, and Other Details to a hidden combatant called "Non-Group Total"
						Recap_AccumulateGrandTotal(thisTotal, i, AllLastOutgoingDetail, AllLastIncomingDetail, AllLastOtherDetail)
					end
				end
			end
		end
	end

	-- per second values
	iTotal = rCombatants[thisTotal]
	if iTotal.TotalTime and (iTotal.TotalTime > rTemp.MinTime) and ((iTotal.TotalDmgOut or 0) > 0) then
		iTotal.TotalDPS = Recap_Div1((iTotal.TotalDmgOut or 0), iTotal.TotalTime)
	end
	if iTotal.TotalTimeIn and (iTotal.TotalTimeIn > rTemp.MinTime) and ((iTotal.TotalDmgIn or 0) > 0) then
		iTotal.TotalDPSIn = Recap_Div1((iTotal.TotalDmgIn or 0), iTotal.TotalTimeIn)
	end
	if iTotal.TotalTimeHeal and (iTotal.TotalTimeHeal > rTemp.MinTime) and (((iTotal.TotalRawHeal or 0) - (iTotal.TotalOverHeal or 0)) > 0) then
		iTotal.TotalHPS = Recap_Div1(((iTotal.TotalRawHeal or 0) - (iTotal.TotalOverHeal or 0)), iTotal.TotalTimeHeal)
	end
	if iTotal["LastTime_"..iLast] and (iTotal["LastTime_"..iLast] > rTemp.MinTime) and ((iTotal["LastDmgOut_"..iLast] or 0) > 0) then
		iTotal["LastDPS_"..iLast] = Recap_Div1((iTotal["LastDmgOut_"..iLast] or 0), iTotal["LastTime_"..iLast])
	end
	if iTotal["LastTimeIn_"..iLast] and (iTotal["LastTimeIn_"..iLast] > rTemp.MinTime) and ((iTotal["LastDmgIn_"..iLast] or 0) > 0) then
		iTotal["LastDPSIn_"..iLast] = Recap_Div1((iTotal["LastDmgIn_"..iLast] or 0), iTotal["LastTimeIn_"..iLast])
	end
	if iTotal["LastTimeHeal_"..iLast] and (iTotal["LastTimeHeal_"..iLast] > rTemp.MinTime) and (((iTotal["LastRawHeal_"..iLast] or 0) - (iTotal["LastOverHeal_"..iLast] or 0)) > 0) then
		iTotal["LastHPS_"..iLast] = Recap_Div1(((iTotal["LastRawHeal_"..iLast] or 0) - (iTotal["LastOverHeal_"..iLast] or 0)), iTotal["LastTimeHeal_"..iLast])
	end

end

local function RecapMenu_SetCheck(id,checked)

	if checked then
		_G["RecapMenu"..id.."_Check"]:Show()
	else
		_G["RecapMenu"..id.."_Check"]:Hide()
	end
end


--[[ global functions ]]


--[[ Callback functions ]]

function Recap:OnInitialize()
	-- Ace3, called when the addon is loaded
	-- slash commands
	SLASH_RECAP1 = "/recap"
	SlashCmdList["RECAP"] = Recap_SlashHandler
	SLASH_RECAP_RL1 = "/rl"
	SlashCmdList["RECAP_RL"] = Recap_SlashHandlerRL
end

function Recap:OnEnable()
	-- Ace3, called when the addon is enabled
	-- called on login and on reloadui
	-- recap_temp cleared, so Recap_Initialize will be called and its interior code will be executed
	local rTemp = _G.recap_temp
	if not rTemp.Loaded then
		if not Recap_Initialize() then
			return false
		end
	end

	-- register all of our general events (so that we can turn them on and off)
	Recap_Register_GeneralEvents()
end

function Recap:OnDisable()
	-- Ace3, called when the addon is disabled
	-- nothing right now
end

-- Can be called often, will immediately return if it ran through successfully
function Recap_Initialize()

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local i, x, iCombatant, newScale

	if not rTemp.Loaded then

		if not Recap_IntegrityCheck() then
			return false
		end

		if (UnitName("player")) and (UnitName("player"))~=UNKNOWNOBJECT and RecapFrame and RecapOptFrame then

			-- take control of lua error messages (WoW 2.1 defaults off) (hook)
			rTemp.Original_ErrorHandler = geterrorhandler()
			seterrorhandler(Recap_TrapError)

			rTemp.Player = (UnitName("player"))
			rTemp.Server = GetRealmName()

			-- recap index for this player
			rTemp.p = rTemp.Player.."_"..rTemp.Server -- use for stuff that can be made global -- never has GUID
			rTemp.s = rTemp.Player.."_"..rTemp.Server -- use for stuff that should never be global -- never has GUID

			-- force the dump flags to false, otherwise we could wake up spamming a channel other than our proper log channel
			rRecap.dump = false
			rTemp.LogChatnum = false
			rRecap.debug = false

			-- Hawksy: force snap on for me every time
			if Recap_IsRecapAuthor() then
				rTemp.snap = true
			end

			-- flags for data initialization
			rTemp.FlagDataSizeDialogDone = false
			rTemp.FlagDataInitializationCompleted = false

			-- set the options for the incoming player
			Recap_SetUpOptions()

			-- point at the new options
			local rOpt = _G.recap_temp.Opt

			-- version of player name with GUID appended
			rTemp.PlayerGUID = rTemp.Player
			if not rOpt.IgnoreGUIDs.value then
				-- using GUIDs (the normal case)
				local g = (UnitGUID("player"))
				if g then
					rTemp.PlayerGUID = rTemp.PlayerGUID.."_"..Recap_TrimGUID(g)
				end
			end

			-- ignoring GUIDs disallows synchronization
			if rOpt.IgnoreGUIDs.value then
				rOpt.EnableSync.value = false
				rUser.SyncState = "Ignore"
			end

			-- if we loaded in any state except 'Stopped' (i.e. perhaps logged out in mid-fight), force into idle state
			if (rUser.State == "Stopped") then
				rTemp.StartupState = "Stopped"
			else
				rTemp.StartupState = "Idle"
			end
			rUser.State = "Stopped"

			-- ensure that saving is off
			rTemp.FlagSavePhase = false

			-- create our own private tooltip
			rTemp.RecapTooltip = CreateFrame("GameTooltip", "RecapTooltip", UIParent, "GameTooltipTemplate")

			-- scale
			RecapSetScaleSlider:SetValue(rOpt.SetScale.value)
			newScale = Recap_Div2(rOpt.SetScale.value,100)
			RecapSetScaleSlider_Text:SetText(newScale)
			RecapFrame:SetScale(newScale)
			RecapOptFrame:SetScale(newScale)
			RecapClipFrame:SetScale(newScale)
			RecapPanel:SetScale(newScale)
			RecapRecent:SetScale(newScale)
			RecapLoad:SetScale(newScale)
			RecapGraph:SetScale(newScale)
			RecapMenu:SetScale(newScale)
			rTemp.RecapTooltip:SetScale(newScale)

			if RecapFrame and not rUser.WindowTop then
				RecapFrame:ClearAllPoints()
				RecapFrame:SetPoint("CENTER","UIParent","CENTER")
				RecapOptFrame:ClearAllPoints()
				RecapOptFrame:SetPoint("CENTER", "UIParent", "CENTER")
			elseif RecapFrame and rUser.WindowTop then
				RecapFrame:ClearAllPoints()
				RecapFrame:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(rUser.WindowLeft,0),math_max(rUser.WindowTop,0))
				RecapFrame:SetWidth(rUser.WindowWidth)
				RecapFrame:SetHeight(rUser.WindowHeight)
			end
			-- since we don't have meaningful data yet, make sure that our main Frame is hidden
			RecapFrame:Hide()

			-- check if either the old data or the new data is oversize
			-- also check for combined saved data set size
			-- note that this function will return before the user has been able to reply to any dialogs
			if rOpt.WarnData.value then
				Recap_WarnDataSize()
			else
				rTemp.FlagDataSizeDialogDone = true
			end

			-- full data initialization will not take place until the flags indicate that the size check dialogs are done
			-- PeriodicUpdate does that check

			rTemp.Loaded = true
			rTemp.StartupDelayTimer = 0 -- we will also delay startup by some number of seconds, this starts the timer

			-- arrange to be called periodically
			Recap:ScheduleRepeatingTimer("PeriodicUpdate", rTemp.PeriodicUpdateTick)
			Recap.nameGuidPlayer = UnitName("player") .. "_" .. Recap_TrimGUID(UnitGUID("player"))
		end
	end

	return true
end

function Recap_General_OnEvent(frame, event, ...)

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	if event=="PLAYER_REGEN_DISABLED" then
		if rTemp.FlagDataInitializationCompleted then
			if rOpt.LimitToEncounters.value then
				-- going by Blizzard encounters, ignore regen entirely
			else
				if rUser.State=="Idle" then
					Recap_PrecautionaryCleanup()
					-- start the fight
					Recap_StartFight()
				end
			end
		end

	elseif event=="ENCOUNTER_START" then
		if rTemp.FlagDataInitializationCompleted then
			if rOpt.LimitToEncounters.value then
				-- semi-experimental with 4.77, there is an option to use Blizzard encounters (only) to delimit fights
				-- they don't seem entirely useful for beginning and ending combat logging, but we give it a try
				if rUser.State=="Idle" then
					Recap_PrecautionaryCleanup()
					-- start the fight
					Recap_StartFight()
				else
					if (rUser.State == "Active") then
						-- the only way we can get here is if this is a second encounter start before the first has entirely finished
						-- we treat this as a fresh start
						if rOpt.IdleFight.value then
							rTemp.IdleTimer = 0
						end
						rTemp.HiddenIdleTimer = 0
						if rTemp.EndFightDelayTimer ~= -1 then
							-- disable the end fight timer if necessary, so we don't accidentally end the encounter prematurely
							rTemp.EndFightDelayTimer = -1
						end
print("(Recap) fight logging continued with second ENCOUNTER_START before first encounter has finished") -- BLAH
					end
				end
			else
				if (rUser.State == "Active") then
					-- we aren't using Blizzard encounters to delimit logging, nevertheless use this encounter start to reset timers
					--   (treating it as if it were a combat damage event)
					if rOpt.IdleFight.value then
						rTemp.IdleTimer = 0
					end
					rTemp.HiddenIdleTimer = 0
					if rTemp.EndFightDelayTimer ~= -1 then
						rTemp.EndFightDelayTimer = 0
					end
				end
			end
		end

	elseif event=="PLAYER_REGEN_ENABLED" then
		if rTemp.FlagDataInitializationCompleted then
			if rOpt.LimitToEncounters.value then
				-- going by encounters, ignore regen entirely
			else
				if (rUser.State == "Active") then
					-- player leaving combat, start the end of fight delay timer
					-- fight will not end until at least this amount of time has elapsed, longer if combat continues
					-- we leave the idle timer on, if it is on (and may the best timer win)
					-- note: this is the *only* way (for normal settings) that this timer can get started, so if something else blocks this event then we won't be ending fights properly
					rTemp.EndFightDelayTimer = 0
				end
			end
		end

	elseif event=="ENCOUNTER_END" then
		if rTemp.FlagDataInitializationCompleted then
			if rOpt.LimitToEncounters.value then
				if (rUser.State == "Active") then
					-- semi-experimental with 4.77, there is an option to use Blizzard encounters (only) to delimit fights
					-- end encounter, start the end of fight delay timer
					-- fight will not end until this amount of time has elapsed (further combat will be ignored, see special code in RecapCombat)
					-- we leave the idle timer on, if it is on (and may the best timer win)
					-- note: this is the *only* way (for logging limited to encounters) that this timer can get started, so if something else blocks this event then we won't be ending fights properly
					rTemp.EndFightDelayTimer = 0
				else
print("(Recap) ENCOUNTER_END without there having been any ENCOUNTER_START detected") -- BLAH
				end
			else
				if (rUser.State == "Active") then
					-- not using Blizzard encounters, treat this as if it were a combat damage event, and reset the timers
					if rOpt.IdleFight.value then
						rTemp.IdleTimer = 0
					end
					rTemp.HiddenIdleTimer = 0
					if rTemp.EndFightDelayTimer ~= -1 then
						rTemp.EndFightDelayTimer = 0
					end
				end
			end
		end

	elseif event=="GROUP_ROSTER_UPDATE" or event=="UNIT_PET" then -- changed for 5.04
		if rTemp.FlagDataInitializationCompleted then
			Recap_MakeFriends(true)
		end

	elseif event=="UNIT_NAME_UPDATE" then
		if not Recap_Initialize() then
			return
		end

	-- always registered
	elseif event=="PLAYER_ENTERING_WORLD" then
		-- called on login, after reloadui, on entering or leaving an instance, on respawning at a graveyard
		if not Recap_Initialize() then
			return
		end

	-- always registered
	elseif event=="PLAYER_LOGOUT" then
		-- called on logout and on reloadui
		-- TODO: WARNING WARNING WARNING: if there are any errors in the following code block, we won't learn about them, except perhaps later and indirectly (since we get logged out before any error message could appear)
		if rTemp.FlagDataInitializationCompleted then
			if (rTemp.DoingReloadUI == false) then
				-- looks like this is a logout rather than a reloadui
				if rOpt.ResetOnLogout.value then
					-- option to reset on logout is enabled
					Recap_ResetAllCombatants(false)
				end
				-- on a real logout, close the log file if it is open (so as to preserve any contents)
				if LoggingChat() then
					Recap_CloseLog()
				end
			end
			-- always back up the per character settings from user space into global space
			-- there is a Restore Character Settings button to do the reverse
			if rUser and (type(recap_user) == "table") then
				-- start with a clean slate
				if type(recap_back[rTemp.p]) == "table" then
					recap_back[rTemp.p] = wipe(recap_back[rTemp.p])
				else
					recap_back[rTemp.p] = {}
				end
				Recap_CopyUserSettings(rUser, recap_back[rTemp.p])
			end

			-- set the option count on every logout or reloadui
			if not rRecap.UserOptionsCount then
				rRecap.UserOptionsCount = {}
			end
			rRecap.UserOptionsCount[rTemp.p] = Recap_CountOptions()

			-- compress the per character combatant data, then reset the uncompressed data
			Recap_CompressCombatants() -- not phased, could run into Blizzard timeout

			-- TODO DEBUG: comment out the following line to leave the uncompressed (and therefore human-readable) form of the combatants data
			Recap_ResetAllCombatants(true)


			-- Note: I've had Recap up to over 300 Mbytes, with over 21,000 combatants in the active combatants set
			--   (over 14,000 in the Fights panel) with no problems other than long login times.
		end

	end
end

function Recap_Register_GeneralEvents()
	local rTemp = _G.recap_temp
	if not rTemp.GeneralEventsRegistered then
		RecapGeneralEvents:RegisterEvent("PLAYER_REGEN_DISABLED")
		RecapGeneralEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
		RecapGeneralEvents:RegisterEvent("ENCOUNTER_START") -- added for 5.43
		RecapGeneralEvents:RegisterEvent("ENCOUNTER_END") -- added for 5.43
		RecapGeneralEvents:RegisterEvent("GROUP_ROSTER_UPDATE") -- changed for 5.04
		RecapGeneralEvents:RegisterEvent("UNIT_NAME_UPDATE")
		RecapGeneralEvents:RegisterEvent("UNIT_PET")
		rTemp.GeneralEventsRegistered = true
	end
	if not rTemp.PermanentEventsRegistered then
		RecapGeneralEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
		RecapGeneralEvents:RegisterEvent("PLAYER_LOGOUT")
		rTemp.PermanentEventsRegistered = true
	end
end

function Recap_Unregister_GeneralEvents()
	local rTemp = _G.recap_temp
	if rTemp.GeneralEventsRegistered then
		RecapGeneralEvents:UnregisterEvent("PLAYER_REGEN_DISABLED")
		RecapGeneralEvents:UnregisterEvent("PLAYER_REGEN_ENABLED")
		RecapGeneralEvents:UnregisterEvent("ENCOUNTER_START") -- added for 5.43
		RecapGeneralEvents:UnregisterEvent("ENCOUNTER_END") -- added for 5.43
		RecapGeneralEvents:UnregisterEvent("GROUP_ROSTER_UPDATE") -- changed for 5.04
		RecapGeneralEvents:UnregisterEvent("UNIT_NAME_UPDATE")
		RecapGeneralEvents:UnregisterEvent("UNIT_PET")
		rTemp.GeneralEventsRegistered = false
	end
	-- we don't unregister the 'permanent' events
end

local ignoreThisArgument
function Recap:CHAT_MSG_CHANNEL_NOTICE(msgType,ignoreThisArgument,ignoreThisArgument,chanNameNum)
	local rTemp = _G.recap_temp
	if chanNameNum and string_find(chanNameNum, "recaplog"..string_lower(rTemp.Player), 1, true) and msgType=="YOU_JOINED" then
		-- we have successfully joined our private log channel

		local i, j, chatnum, chatname
		local logchat = "recaplog"..string_lower(rTemp.Player)

		chatnum = false
		for i=1,10 do
			j,chatname = GetChannelName(i)
			if chatname and string_lower(chatname)==logchat then
				chatnum=j
				break
			end
		end
		if chatnum then
			rTemp.LogChatnum = chatnum
			-- begin logging to WoWChatLog.txt
			if LoggingChat() then
				-- already on
			else
				-- toggle on
				LoggingChat(true)
			end
			-- allow Report and Close buttons
			RecapOpenLogButton:SetText(RECAP_CHANNEL_JOINED)
			RecapOpenLogButton:Disable()
			RecapReportToLogButton:Enable()
			RecapCloseLogButton:Enable()
		else
			-- oops, didn't work after all
			print(rLocalize.NoChannelNumber)
			RecapOpenLogButton:SetText(RECAP_OPEN_WOWCHATLOG_TXT)
			RecapOpenLogButton:Enable()
		end
		RecapFrame:UnregisterEvent("CHAT_MSG_CHANNEL_NOTICE")
	end
end

function Recap:PeriodicUpdate()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rSet = _G.recap_set

	-- this function is called periodically
	local tick = rTemp.PeriodicUpdateTick

	if not rTemp.Loaded then
		-- anomalous
		return
	end

	-- First thing we do is check for a save (whether automatic at EndFight, or requested), and if scheduled then do it
	-- Delayed one tick after EndFight or other request to avoid running into Blizzard's addon limiter clock, which exceeds the sum of EndFight time plus AutoSave time
	-- Starting with 4.77, doing it in seven phases
	-- Within each of these phases, we clear our current phase flag then return, which means we'll go on to the next phase on the next tick
	-- Note, we normally only start from Stopped or Idle, which should often avoid the Blizzard timeout issue
	if rTemp.FlagSavePhase == 1 then
		local i, count
		debugprofilestart() -- start internal timer
		rSet[rTemp.FlagSaveSetName] = {}
		Recap_SaveCombatantsBasic(rTemp.FlagSaveSetName, rTemp.FlagSaveLastOnly)
		-- How many combatants?
		count = 0
		for i in pairs(rSet[rTemp.FlagSaveSetName].Combatant) do
			count = count + 1
		end
		if count == 0 then
			-- set is empty after all, don't save it, skip to final phase
			rSet[rTemp.FlagSaveSetName] = nil
			rTemp.FlagSavePhase = 7
			return
		else
			rSet[rTemp.FlagSaveSetName].ListSize = count
			print(rTemp.Recap, "Save number of combatants "..count)
		end
		if rOpt.LightData.value then
			-- light data, don't save details
			rTemp.FlagSavePhase = 7
		else
			-- schedule save of details
			rTemp.FlagSavePhase = 2
		end
		return
	end
	if rTemp.FlagSavePhase == 2 then
		debugprofilestart() -- start internal timer
		Recap_SaveCombatantsOutgoing(rTemp.FlagSaveSetName, rTemp.FlagSaveLastOnly)
		rTemp.FlagSavePhase = 3
		return
	end
	if rTemp.FlagSavePhase == 3 then
		debugprofilestart() -- start internal timer
		Recap_SaveCombatantsTarget(rTemp.FlagSaveSetName, rTemp.FlagSaveLastOnly)
		rTemp.FlagSavePhase = 4
		return
	end
	if rTemp.FlagSavePhase == 4 then
		debugprofilestart() -- start internal timer
		Recap_SaveCombatantsIncoming(rTemp.FlagSaveSetName, rTemp.FlagSaveLastOnly)
		rTemp.FlagSavePhase = 5
		return
	end
	if rTemp.FlagSavePhase == 5 then
		debugprofilestart() -- start internal timer
		Recap_SaveCombatantsSource(rTemp.FlagSaveSetName, rTemp.FlagSaveLastOnly)
		rTemp.FlagSavePhase = 6
		return
	end
	if rTemp.FlagSavePhase == 6 then
		debugprofilestart() -- start internal timer
		Recap_SaveCombatantsOther(rTemp.FlagSaveSetName, rTemp.FlagSaveLastOnly)
		rTemp.FlagSavePhase = 7
		return
	end
	if rTemp.FlagSavePhase == 7 then
		debugprofilestart() -- start internal timer
		if rTemp.FlagSaveLastOnly then
			-- Last fight, should be safe to check for sync even if we didn't just end a fight
			Recap_CheckJoinSync() -- contains a non-blocking dialog
			Recap_CheckSendSyncSummary()
			Recap_CheckProcessSyncData()
			print(rTemp.Recap, rLocalize.LastFightSaved)
		else
			print(rTemp.Recap, RECAP_ALL_FIGHTS_SAVED)
		end
		RecapSetEditBox:SetText("")
		Recap_BuildFightSets()
		rTemp.FightSetSelected = 0
		rTemp.FightSetSelectedOther = 0
		RecapFightSetsScrollBar_Update()
		Recap_ClearAsIfEndOfFight()
		rTemp.FlagSavePhase = false
		rTemp.FlagSaveLastOnly = false
		rTemp.FlagSaveSetName = false
		local priorState = rTemp.FlagSavePriorState
		rTemp.FlagSavePriorState = false
		Recap_SetState(priorState) -- restore prior state
		return
	end

	if rTemp.SkipPeriodicUpdate then
		-- a couple of subroutines have to avoid conflicting with some of the following (poor man's spinlock) (not certain it's needed)
		return
	end

	-- if data size dialog still pending, do nothing
	if (rTemp.FlagDataSizeDialogDone == false) then
		return
	end

	-- for 4.29, removed a check which returned if Recap was Stopped
	-- this allows synchronization to complete while Recap is paused

	-- check for data size dialog ready, and if so do the real data initialization at last
	if rTemp.FlagDataSizeDialogDone and (rTemp.FlagDataInitializationCompleted == false) then
		-- we wait some number of seconds before actually starting up (an attempt to avoid login stalls)
		-- six seconds gives about a three second visible delay (when we have a small amount of data)
		rTemp.StartupDelayTimer = rTemp.StartupDelayTimer + tick
		if rTemp.StartupDelayTimer >= 3 then
			rTemp.StartupDelayTimer = -1
			Recap_InitializeDataAndDisplay()
			-- if we didn't log out paused, ensure that everything is set up properly before beginning
			if (rTemp.StartupState == "Idle") then
				rUser.State = "Idle"
				Recap_PrecautionaryCleanup()
			end
			-- finally add our panel to the Blizzard Interface AddOns panel
			InterfaceOptions_AddCategory(Recap_BlizzardInterfaceAddOnsPanel);
			-- indicate we've finished
			rTemp.FlagDataInitializationCompleted = true
		end
		return
	end

	-- if fighting, check for friends and get their maximum hit points and current hit points (all three can change during combat)
	-- has the side benefit of better tracking of ownership of shadowfiend, mage water elemental, hunter trap, etc.
	-- there is a gap of up to a half-second here where ownership information might be wrong, and effects might not be tracked to the right combatant
	-- with 2.4 some of this will be handled immediately by code in RecapCombat
	if rUser.State=="Active" then
		Recap_MakeFriends(false) -- do not get gear value every tick
	end

	-- if Recap is tracking, then update the live dps and hps numbers, and perhaps update the graph
	if (rUser.State=="Active") then
		rTemp.LiveUpdateTimer = rTemp.LiveUpdateTimer + tick
		if rTemp.LiveUpdateTimer >= 1 then
			-- currently updates about once a second
			rTemp.LiveUpdateTimer = 0
			Recap_UpdateMinimizedDPS()
			Recap_DisplayMinimizedDPS() -- also sends to plugins

			-- do we have the graph visible?
			if rOpt.LiveData.value and RecapGraph:IsVisible() and rTemp.Graph.GroupInvolved then
				RecapGraph_GraphUpdate()
			end
		end
	end

	-- possibly blink the sync status light (0 set to default value, 1 turn off, 2 turn on)
	if RecapFrame:IsVisible() then
		if rTemp.SyncStatusLightBlink == 0 then
			if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
				RecapMinSyncStatusTexture:SetVertexColor(0,0,1)
			else
				RecapMinSyncStatusTexture:SetVertexColor(.5,.5,.5)
			end
		elseif rTemp.SyncStatusLightBlink == 1 then
			rTemp.SyncStatusLightBlink = 2
			RecapMinSyncStatusTexture:SetVertexColor(.5,.5,.5)
		elseif rTemp.SyncStatusLightBlink == 2 then
			rTemp.SyncStatusLightBlink = 0
			RecapMinSyncStatusTexture:SetVertexColor(0,0,1)
		end

		-- update main panel title bar (for the sync member count)
		if not rUser.Minimized then
			-- if not in combat and still syncing, update the All Fights panel (i.e. once every two seconds)
			if (rUser.State ~= "Active") and (rTemp.SyncStatusLightBlink == 2) then
				Recap_ConstructList()
			end
			Recap_TitleBar()
			Recap_SetTitleBackground()
		end
	end

	-- if sync tab is visible and we're in a synchronization, update details
	if RecapOptSubFrame5:IsVisible() and ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
		Recap_SetSyncStateDetail()
	end

	-- if in sync then send a heartbeat message every five seconds
	if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
		if rTemp.SyncHeartbeat == 0 then
			Recap_SendSyncHeartbeat()
			Recap_UpdateSyncMember(rTemp.PlayerGUID, rTemp.Server, Recap_Version) -- make sure we get into our own list
		end
		rTemp.SyncHeartbeat = rTemp.SyncHeartbeat + tick
		if rTemp.SyncHeartbeat >= 5 then
			rTemp.SyncHeartbeat = 0
		end
	end

	-- timer to end idle fights if option checked
	if rTemp.IdleTimer ~= -1 and rOpt.IdleFight.value then
		rTemp.IdleTimer = rTemp.IdleTimer + tick
		if rTemp.IdleTimer >= rOpt.IdleFightTimer.value then
			rTemp.IdleTimer = -1
--print("(Recap) EndFight due to normal idle timer")
			Recap_EndFight(false)
			if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
				-- hostile boss present, schedule a save of the last fight, to begin on the next tick
				rTemp.FlagSavePhase = 1
				rTemp.FlagSaveLastOnly = true
				rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
				rTemp.BossList = ""
				rTemp.FlagSavePriorState = "Idle"
				Recap_SetState("Stopped")
			end
			-- fight has ended, turn off the flag that skips fights
			if rUser.SkipNextFight == true then
				rUser.SkipNextFight = false
				print(rTemp.Recap..": ", rLocalize.SkipNextFightEnds)
			end
			return
		end
	end

	-- hidden timer to end idle fights after 10 minutes
	if rTemp.HiddenIdleTimer ~= -1 then
		rTemp.HiddenIdleTimer = rTemp.HiddenIdleTimer + tick
		if rTemp.HiddenIdleTimer >= 600 then
			rTemp.HiddenIdleTimer = -1
--print("(Recap) EndFight due to hidden idle timer")
			Recap_EndFight(false)
			if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
				-- hostile boss present, schedule a save of the last fight, to begin on the next tick
				rTemp.FlagSavePhase = 1
				rTemp.FlagSaveLastOnly = true
				rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
				rTemp.BossList = ""
				rTemp.FlagSavePriorState = "Idle"
				Recap_SetState("Stopped")
			end
			-- fight has ended, turn off the flag that skips fights
			if rUser.SkipNextFight == true then
				rUser.SkipNextFight = false
				print(rTemp.Recap..": ", rLocalize.SkipNextFightEnds)
			end
			return
		end
	end

	-- timer to wait after an end-of-fight is triggered before actually ending the fight
	-- prevents a fight being ended prematurely when it's just a short gap
	-- with version 4.29 the fight may be ended if nobody in the group is involved, thereby calculating a last fight; then immediately start again if other combat is taking place within range
	if rTemp.EndFightDelayTimer ~= -1 then
		rTemp.EndFightDelayTimer = rTemp.EndFightDelayTimer + tick
		if rTemp.EndFightDelayTimer >= rOpt.EndFightDelay.value then
			rTemp.EndFightDelayTimer = -1
			Recap_EndFight(false)
			if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
				-- hostile boss present, schedule a save of the last fight, to begin on the next tick
				rTemp.FlagSavePhase = 1
				rTemp.FlagSaveLastOnly = true
				rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
				rTemp.BossList = ""
				rTemp.FlagSavePriorState = "Idle"
				Recap_SetState("Stopped")
			end
			-- fight has ended, turn off the flag that skips fights
			if rUser.SkipNextFight == true then
				rUser.SkipNextFight = false
				print(rTemp.Recap..": ", rLocalize.SkipNextFightEnds)
			end
			return
		end
	end

	-- timer to wait for some time after the last synchronization data has been exchanged before updating the All Fights panel one final time and sending out auto-post data
	--   (uses the existing EndFightDelay value)
	if rTemp.EndSyncDelayTimer~=-1 then
		rTemp.EndSyncDelayTimer = rTemp.EndSyncDelayTimer + tick
		if rTemp.EndSyncDelayTimer >= math_max(rOpt.EndFightDelay.value, 1) then -- at least one second
			rTemp.EndSyncDelayTimer = -1
			-- do nothing if we are in combat again
			if (rUser.State ~= "Active") then
				-- update the All Fights panel
				if rOpt.AutoPost.value then
					rUser.SortBy = Recap_AutoPostGetStatID(rOpt.AutoPost.Stat)
					rUser.SortDir = false
				end
				if (not rUser.Minimized) or rOpt.AutoPost.value or rOpt.AutoLeader.value then
					-- don't construct a list if minimized, unless we are doing one of the auto things which needs the list
					Recap_ConstructList()
				end
				Recap_TitleBar()
				RecapHeader_Name:SetText((rTemp.ListSize-1).." "..rLocalize.Combatants)
				Recap_SetTitleBackground()
				if rTemp.LastFightSignificant then
					-- send out the auto-post data
					if rOpt.AutoPost.value then
						Recap_PostFight()
					end
					if rOpt.AutoLeader.value then
						Recap_PostLeader()
					end
				end
				print(rTemp.Recap..": ", rLocalize.SynchronizationComplete)
			end
		end
	end

	-- update fade timer if option checked
	if RecapFrame:IsShown() and rOpt.AutoFade.value and not rUser.Minimized and RecapFrame:IsMouseOver() and rTemp.FadeTimer<rOpt.AutoFadeTimer.value then
		rTemp.FadeTimer = 0
	elseif (rTemp.FadeTimer ~= -1) and rOpt.AutoFade.value and (not rUser.Minimized) and (not RecapFadeFrame:IsVisible()) then
		rTemp.FadeTimer = rTemp.FadeTimer + tick
		if (rTemp.FadeTimer >= rOpt.AutoFadeTimer.value) then
			RecapFadeFrame:Show() -- start the auto fade (see Recap_AutoFade below)
		end
	end

	-- check mouse-over
	if RecapFrame:IsShown() and rOpt.AutoMinimize.value and rTemp.Selected==0 then
		if not rUser.Minimized and not RecapFrame:IsMouseOver() and not IsShiftKeyDown() then
			Recap_Minimize()
		elseif rUser.Minimized and RecapFrame:IsMouseOver() and not IsShiftKeyDown() then
			Recap_Maximize()
		end
	end

	-- check group status
	if rOpt.RemindGroupStatus.value then
		Recap_JoinLeaveGroup() -- contains a non-blocking dialog
	end

	-- figure out instance transition actions
	Recap_CheckInstance()

end

function Recap_AutoFade(frame, elapsed)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local fadeDuration = 1.5
	rTemp.FadeTimer = rTemp.FadeTimer + elapsed
	RecapFrame:SetAlpha(math_max((1 - ((rTemp.FadeTimer-rOpt.AutoFadeTimer.value) / fadeDuration)), 0.05))
	if rTemp.FadeTimer >= (rOpt.AutoFadeTimer.value + fadeDuration) then
		RecapFadeFrame:Hide() -- stop the auto fade
		RecapFrame_Hide()
	end
end

function Recap_Show()
	RecapFrame_Show()
	Recap_CheckWindowBounds()
	Recap_Maximize()
end

function Recap_Centre()
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	rOpt.SetScale.value = 100
	RecapSetScaleSlider:SetValue(rOpt.SetScale.value)
	newScale = Recap_Div2(rOpt.SetScale.value,100)
	RecapSetScaleSlider_Text:SetText(newScale)
	RecapFrame:SetScale(newScale)
	RecapOptFrame:SetScale(newScale)
	RecapClipFrame:SetScale(newScale)
	RecapPanel:SetScale(newScale)
	RecapRecent:SetScale(newScale)
	RecapLoad:SetScale(newScale)
	RecapGraph:SetScale(newScale)
	RecapMenu:SetScale(newScale)
	rTemp.RecapTooltip:SetScale(newScale)
	RecapFrame:ClearAllPoints()
	RecapFrame:SetPoint("CENTER","UIParent","CENTER")
	RecapOptFrame:ClearAllPoints()
	RecapOptFrame:SetPoint("CENTER","UIParent","CENTER")
	RecapClipFrame:ClearAllPoints()
	RecapClipFrame:SetPoint("CENTER","UIParent","CENTER")
	RecapPanel:ClearAllPoints()
	RecapPanel:SetPoint("CENTER","UIParent","CENTER")
	RecapRecent:ClearAllPoints()
	RecapRecent:SetPoint("CENTER","UIParent","CENTER")
	RecapLoad:ClearAllPoints()
	RecapLoad:SetPoint("CENTER","UIParent","CENTER")
	RecapGraph:ClearAllPoints()
	RecapGraph:SetPoint("CENTER","UIParent","CENTER")
	rUser.Pinned = false
	Recap_SetView()
	RecapFrame_Show()
	Recap_Maximize()
	RecapFrame:SetAlpha(1)
	rTemp.FadeTimer = -1
	-- TODO: these puppies aren't localized
	print("Recap has been centred, and the scaling has been reset to 1.0.")
end

function Recap_SlashHandler(slashText, ...)

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, newScale

	-- any Recap slash command will turn Recap on if it had been turned off
	if not Recap_Initialize() then
		-- TODO: these puppies aren't localized
		print("|cFFFF6666".."Recap is not initialized, try re-installing.")
		return false
	end


	-- "/recap help"
	-- describes current slash command arguments
	if slashText and string_find(slashText, "help", 1, true) then
		-- TODO: these puppies aren't localized
		print("Recap slash commands are 'help', 'centre', 'options', 'reset', 'gmin', 'debug', 'snap', 'dump', and 'rl'.")
		print("This list may change at any time.  Check the function Recap_SlashHandler in the file Recap.lua for further details on each individual command.")
		print("Only '/recap centre' and '/recap options' are of general interest.")
		print("The '/recap centre' command is for emergency use when '/recap' doesn't bring Recap back into view.")
		print("The '/recap options' command is for opening the Options panel (there is also a button at the top of the Recap main panel for doing this).")


	-- "/recap centre" or "/recap center" or "/recap cent"
	-- make the main Recap panel visible and put it in the middle of the screen
	-- also set the scale to 1.0
	elseif slashText and string_find(slashText, "cent", 1, true) then
		Recap_Centre()


	-- "/recap options" or "/recap opt"
	-- show or hide the Options panel
	elseif slashText and string_find(slashText, "opt", 1, true) then
		if RecapOptFrame:IsShown() then
			RecapOptFrame:Hide()
		else
			RecapOptFrame:Show()
			Recap_SetSyncDisplay()
		end


	-- "/recap reset"
	-- does a Reset All Fights (for the leader of a synchronization it starts a new synchronization)
	elseif slashText and string_find(slashText, "reset", 1, true) then
		if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
			if rUser.SyncState == "Leader" then
				-- for a leader, treat this as a restart sync (with existing value for merge pets)
				Recap_StartSync(rUser.SyncMergePets)
				print(rTemp.Recap, RECAP_SYNCHRONIZATION_RESET)
			else
				-- for a member, ignore if in synchronization
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			end
		else
			PlaySound("GnomeExploration")
			RecapPanel_Hide(1)
			RecapRecent_Hide(1)
			RecapLoad_Hide()
			RecapClipFrame:Hide()
			Recap_ResetAllCombatants(false)
			RecapGraph_InitializeLiveLists()
			Recap_SetView()
			Recap_MakeFriends(true)
			print(rTemp.Recap, RECAP_ALL_FIGHTS_RESET)
		end


	-- "/recap gmin on" or "/recap gmin off"
	-- always begins "off" at login or after reloadui
	-- a lightly documented setting, to always calculate gross minima for Self ("gmin on"), rather than net minima ("gmin off")
	-- affects only the minima on the Personal Details panel, and does not affect the Outgoing Details or Incoming Details minima
	-- if you hit someone for 50 and they partially block 10, the gross minimum would be 50 and the net minimum would be 40
	-- the gross minimum measures the smallest effect that you generate (corresponding for example to the low end of a spell damage range)
	-- the gross minimum is useful when you are measuring your spells and need to track the actual low end of your spells as cast, such
	--   as when trying to measure the actual coefficient used by Blizzard for the spell damage or spell healing bonus
	-- the net minimum is after the target has resisted or blocked or otherwise reduced the effect, and could be as low as 1 or perhaps even 0
	elseif slashText=="gmin" then
		if rRecap.gmin then
			print("recap.gmin is ON. To turn it off: /recap gmin off")
		else
			print("recap.gmin is OFF. To turn it on: /recap gmin on")
		end
	elseif slashText=="gmin on" then
		if rRecap.gmin then
			print("recap.gmin was on, and is still ON.")
		else
			print("recap.gmin was off, and is now ON.")
		end
		rRecap.gmin = true
	elseif slashText=="gmin off" then
		if rRecap.gmin then
			print("recap.gmin was on, and is now OFF.")
		else
			print("recap.gmin was off, and is still OFF.")
		end
		rRecap.gmin = false


	-- "/recap debug on" or "/recap debug off"
	-- always begins "off" at login or after reloadui
	-- debug setting, sends some additional debug information to your console
	-- relatively harmless
	elseif slashText=="debug" then
		if rRecap.debug then
			-- TODO: these puppies aren't localized
			print("recap.debug is ON. To turn it off: /recap debug off")
		else
			print("recap.debug is OFF. To turn it on: /recap debug on")
		end
	elseif slashText=="debug on" then
		if rRecap.debug then
			print("recap.debug was on, and is still ON.")
		else
			print("recap.debug was off, and is now ON.")
		end
		rRecap.debug = true
	elseif slashText=="debug off" then
		if rRecap.debug then
			print("recap.debug was on, and is now OFF.")
		else
			print("recap.debug was off, and is still OFF.")
		end
		rRecap.debug = false


	-- "/recap snap on" or "/recap snap off"
	-- always begins "off" at login or after reloadui
	-- debug setting, automatically takes a screenshot whenever there is an error popup
	-- mostly harmless, but if there are a lot of errors there will be a lot of screenshots filling up your "World of Warcraft/Screenshots" folder
	-- each screenshot will momentarily pause your game
	elseif slashText=="snap" then
		if rTemp.snap then
			print("recap_temp.snap is ON. To turn it off: /recap snap off")
		else
			print("recap_temp.snap is OFF. To turn it on: /recap snap on")
		end
	elseif slashText=="snap on" then
		if rTemp.snap then
			print("recap_temp.snap was on, and is still ON.")
		else
			print("recap_temp.snap was off, and is now ON.")
		end
		rTemp.snap = true
	elseif slashText=="snap off" then
		if rTemp.snap then
			print("recap_temp.snap was on, and is now OFF.")
		else
			print("recap_temp.snap was off, and is still OFF.")
		end
		rTemp.snap = false


	-- "/recap dump on" or "/recap dump off"
	-- always begins "off" at login or after reloadui
	-- debug setting, to dump combat events (as seen by Recap) to WoWChatLog.txt (which must be open, see Options / Reports) (file will show up in "World of Warcraft/Logs")
	-- potentially harmful, use with caution, as it can slow your WoW down a lot
	-- note also that Blizzard throttles chat output, so output of dumped events will fall further and further behind the actual events,
	--   sometimes half an hour behind or more, expecially if you are in an instance or battleground, so if it is important to capture
	--   specific events then try to limit your dump ON time to the smallest segment that you need to do the data capture (tough when
	--   trying to capture a rare occurrence)
	-- if you don't mind the lack of correlation between Blizzard event times and Recap event times, then you can use "/combatlog" to dump
	--   combat events as seen by Blizzard (file will show up in "World of Warcraft/Logs"), but sometimes it is necessary to have the same
	--   time stamps for Recap diagnostic output and the combat log events, in which case using Recap dump is the only option
	elseif slashText=="dump" then
		if rRecap.dump then
			print("recap.dump is ON. To turn it off: /recap dump off")
		else
			print("recap.dump is OFF. To turn it on: /recap dump on")
		end
	elseif slashText=="dump on" then
		if rTemp.LogChatnum then
			-- have a log channel, WoWChatLog should be open with logging turned on
			if rRecap.dump then
				print("recap.dump was on, and is still ON.")
			else
				print("recap.dump was off, and is now ON.")
			end

			SendChatMessage(string_format(rLocalize.LogHeader,Recap_Version,Recap_PetsMergedText(),rTemp.Player,rLocalize.LastAll[rUser.View],date("%Y-%b-%d %H:%M"),GetRealZoneText()), "CHANNEL", nil, rTemp.LogChatnum)
			rRecap.dump = true
			rRecap.dumplines = 0
		else
			print("recap.dump logging not on, please go to Options / Reports and Open the WoWChatLog.txt file.")
		end
	elseif slashText=="dump off" then
		if rRecap.dump then
			print("recap.dump was on, and is now OFF.")
		else
			print("recap.dump was off, and is still OFF.")
		end
		rRecap.dump = false

	-- when the main panel is visible, "/recap" hides it
	elseif RecapFrame:IsShown() then
		RecapFrame_Hide()
		RecapLoad_Hide()
		RecapOptFrame:Hide()
		RecapPanel_Hide(true)
		RecapRecent_Hide(true)
		RecapClipFrame:Hide()
		RecapGraph:Hide()
		-- TODO: these puppies aren't localized
		print("Recap has been hidden. To show Recap again type: /recap")


	-- when the main panel is not visible "/recap" makes it visible
	-- if Recap was paused this slash command also un-pauses (unless saving)
	else
		RecapFrame_Show()
		Recap_CheckWindowBounds()
		if rTemp.FlagSavePhase then
			-- saving
			-- TODO: these puppies aren't localized
			print("Recap is saving at the moment.  Recap has been shown, but not resumed.")
		else
			if rUser.State == "Stopped" then
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
				Recap_SetButtons()
			end
			-- TODO: these puppies aren't localized
			print("Recap has been shown.  If Recap is still not visible, try '/recap centre'.")
		end
	end
end
function Recap_SlashHandlerRL(...)
	-- added "/rl" since I'm no longer using whatever addon used to give me this
	ReloadUI()
end


--[[ Window appearance functions ]]

function Recap_SetState(state)

	local rUser = _G.recap_user

	-- perhaps the call sets the state
	if state then
		rUser.State = state
	end

	-- what we do depends on state
	if rUser.State=="Stopped" then
		rUser.SkipNextFight = false
		if recap_temp.FlagSavePhase then
			-- saving, change the status light colour to a green that varies with phase (starts at 0.9, ends at 0.3)
			RecapStatusTexture:SetVertexColor(0,0.1 * (10 - recap_temp.FlagSavePhase),0)
		else
			-- normal red for stopped
			RecapStatusTexture:SetVertexColor(1,0,0)
		end
		Recap_Unregister_CombatEvents()
		Recap_Unregister_GeneralEvents()
	elseif rUser.State=="Active" then
		if rUser.SkipNextFight == true then
			-- skipping this fight, change the status light colour to amber
			RecapStatusTexture:SetVertexColor(1,0.75,0)
		else
			-- regular active, status light colour is green
			RecapStatusTexture:SetVertexColor(0,1,0)
		end
		Recap_Register_CombatEvents()
		Recap_Register_GeneralEvents()
	elseif rUser.State=="Idle" then
		RecapStatusTexture:SetVertexColor(0.5,0.5,0.5)
		Recap_Register_CombatEvents()
		Recap_Register_GeneralEvents()
	end
	if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
		RecapMinSyncStatusTexture:SetVertexColor(0,0,1)
	else
		RecapMinSyncStatusTexture:SetVertexColor(0.5,0.5,0.5)
	end
	Recap_SetButtons()
	-- display live dps and hps numbers
	Recap_DisplayMinimizedDPS() -- also sends to plugins

end

-- changes button textures depending on their state
function Recap_SetButtons()

	local rUser = _G.recap_user
	local i, iButton

	for i, iButton in pairs(recapbuttons) do
		if rUser[i] then
			_G[iButton]:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
			_G[iButton]:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
		else
			_G[iButton]:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
			_G[iButton]:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
		end
	end

	if rUser.View=="Last" then
		RecapShowAllButton:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
		RecapShowAllButton:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
	else
		RecapShowAllButton:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
		RecapShowAllButton:SetPushedTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
	end

end

function RecapFrame_Hide()
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if not rTemp.Loaded then
		if not Recap_Initialize() then
			return false
		end
	end
	rTemp.FadeTimer = -1
	RecapFrame:SetAlpha(1)
	rUser.Visible = false
	RecapFrame:Hide()
end

function RecapFrame_Show()
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if not rTemp.Loaded then
		if not Recap_Initialize() then
			return false
		end
	end
	rUser.Visible = true
	RecapFrame:Show()
end

-- catch Escape when maximized, and do a minimize instead; and genuinely hide otherwise
function RecapFrame_HideOrMinimize()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	if not rTemp.Loaded then
		if not Recap_Initialize() then
			return false
		end
	end
	if rUser.Visible then
		-- other code wants it visible, so this must be an Escape, so minimize and show
		-- Minimize will disable the special status of RecapFrame so that it lets the Escape through
		-- Maximize will enable the special status of RecapFrame so that it captures the Escape
		if rOpt.MinimizeOnEscape.value then
			-- but only minimize if the option is set
			Recap_Minimize()
		end
		RecapFrame:Show()
	else
		-- other code wants it hidden, so let it happen (called from OnHide, so don't recurse)
	end
end

function RecapOptFrame_Hide()
	RecapOptFrame:Hide()
end

function RecapFrame_Toggle()
	if RecapFrame:IsShown() then
		RecapFrame_Hide()
		RecapOptFrame:Hide()
	else
		RecapFrame_Show()
	end
end

function Recap_Shutdown()
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	if rTemp.Loaded then
		Recap_EndFight(true) -- no auto-save here

		-- close any synchronization
		rUser.SyncState = "Ignore"
		rUser.SyncTimestamp = false
		rUser.SyncLeader = false
		rUser.SyncMergePets = false
		rUser.SyncUpdateWhen = false
		rTemp.SyncInviteTimestamp = false
		rTemp.SyncInviteLeader = false
		rTemp.SyncInviteWhen = false
		rTemp.SyncInviteNewOngoing = false
		rTemp.AskingJoinSync = false
		rTemp.SyncData = wipe(rTemp.SyncData)
		rTemp.SyncMembers = wipe(rTemp.SyncMembers)
		rTemp.OnCommReceived = false
		Recap_SetSyncDisplay()

		-- other cleanup
		Recap_SetState("Stopped")
		Recap_ClearAsIfEndOfFight()
		Recap_SetButtons()
		RecapOptFrame:Hide()
		RecapPanel_Hide(1)
		RecapClipFrame:Hide()
		RecapRecent_Hide(1)
		RecapLoad_Hide()
		RecapFrame_Hide()
	end
end

function Recap_ToggleView()
	local rUser = _G.recap_user
	if rUser.View=="All" then
		rUser.View = "Last"
	else
		rUser.View = "All"
	end
	Recap_SetView() -- this calls ConstructList
end

-- changes view mode
function Recap_SetView()
	local rTemp = _G.recap_temp
	Recap_SetButtons()
	Recap_ConstructList()
	Recap_TitleBar()
	RecapHeader_Name:SetText((rTemp.ListSize-1).." "..rLocalize.Combatants)
	Recap_SetTitleBackground()
	Recap_SetExtraBottomBar()
	-- display live dps and hps numbers
	Recap_DisplayMinimizedDPS() -- also sends to plugins
end

function Recap_TitleBar()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, cx, text

	if rUser.Minimized then
		if rOpt.MinView.value then
			text = rLocalize.LastAllShort[rUser.View]
		else
			text = " "
		end
		RecapMinTitle:SetText(text)
	else
		cx = RecapFrame:GetWidth()
		if cx then
			if rUser.SelfView then
				if cx>300 then
					text = rTemp.Player..": "..rLocalize.Details
				else
					text = rTemp.Player
				end
			else
				if cx>260 then
					text = rTemp.Recap.." "..rLocalize.Of.." "..rLocalize.LastAll[rUser.View]
				else
					text = rLocalize.LastAll[rUser.View]
				end
			end
		else
			if rUser.SelfView then
				text = rTemp.Player
			else
				text = rLocalize.LastAll[rUser.View]
			end
		end

		-- add sync member count
		if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) and not rUser.SelfView then
			local list_time, active, stale
			list_time = GetTime()
			active = 0
			stale = 0
			for i in pairs(rTemp.SyncMembers) do
				if (list_time-(rTemp.SyncMembers[i].When/1000)) <= 10 then
					active = active + 1
				else
					stale = stale + 1
				end
			end
			if stale > 0 then
				text = text.."   ("..tostring(active).."+"..tostring(stale).." "..rLocalize.InSync..")"
			else
				text = text.."   ("..tostring(active).." "..rLocalize.InSync..")"
			end
		end
		RecapTitle:SetText(text)
		RecapTitleButton:Show()
		RecapMinTitle:SetText("")
	end
	RecapMinView:Show()
end

function Recap_SetExtraBottomBar()
	local rUser = _G.recap_user
	if rUser.Minimized or rUser.SelfView then
		RecentLabelButton:Hide()
		RecapEventsButton:Hide()
		RecapDispelsAndInterruptsButton:Hide()
		RecapDeathsButton:Hide()
		RecapLiveGraphAndTextButton:Hide()
	else
		RecentLabelButton:Show()
		RecapEventsButton:Show()
		RecapDispelsAndInterruptsButton:Show()
		RecapDeathsButton:Show()
		RecapLiveGraphAndTextButton:Show()
	end
end

function Recap_SetColors()

	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i

	rColor.DmgIn = { unpack(rColor.Red) }
	rColor.DmgOut = { unpack(rColor.Green) }
	rColor.Heal = { unpack(rColor.Blue) }
	rColor.DmgInPale = { unpack(rColor.RedPale) }
	rColor.DmgOutPale = { unpack(rColor.GreenPale) }
	rColor.HealPale = { unpack(rColor.BluePale) }
	rColor.Glances = { unpack(rColor.LightCyan) }
	rColor.Hits = { unpack(rColor.Cyan) }
	rColor.Ticks = { unpack(rColor.Yellow) }
	rColor.Crits = { unpack(rColor.Lime) }
	rColor.Miss = { unpack(rColor.Pink) }

	RecapTotals_DmgIn:SetTextColor(unpack(rColor.DmgIn))
	RecapTotals_DmgOut:SetTextColor(unpack(rColor.DmgOut))
	RecapTotals_HPS:SetTextColor(unpack(rColor.Heal))
	RecapTotals_DPSIn:SetTextColor(unpack(rColor.DmgIn))
	RecapTotals_DPS:SetTextColor(unpack(rColor.DmgOut))
	RecapTotals_DPSPerGear:SetTextColor(unpack(rColor.DmgOut))
	RecapTotals_DPSvsAll:SetTextColor(unpack(rColor.DmgOut))
	RecapTotals_MaxHit:SetTextColor(unpack(rColor.DmgOut))
	RecapTotals_Heal:SetTextColor(unpack(rColor.Heal))
	RecapTotals_Over:SetTextColor(unpack(rColor.Heal))
	RecapTotals_Time:SetTextColor(unpack(rColor.DmgOut))
	RecapTotals_TimeIn:SetTextColor(unpack(rColor.DmgIn))
	RecapTotals_TimeHeal:SetTextColor(unpack(rColor.Heal))
	RecapMinYourDPS_Text:SetTextColor(unpack(rColor.DmgOut))
	RecapMinYourPetPercent_Text:SetTextColor(unpack(rColor.DmgOut))
	RecapMinDPSIn_Text:SetTextColor(unpack(rColor.DmgIn))
	RecapMinDPSOut_Text:SetTextColor(unpack(rColor.DmgOut))
	RecapMinYourHPS_Text:SetTextColor(unpack(rColor.Heal))
	RecapMinHPS_Text:SetTextColor(unpack(rColor.Heal))
	for i=1,15 do
		_G["RecapList"..i.."_HealP"]:SetTextColor(unpack(rColor.Heal))
		_G["RecapList"..i.."_Over"]:SetTextColor(unpack(rColor.Heal))
		_G["RecapList"..i.."_DmgInP"]:SetTextColor(unpack(rColor.DmgIn))
		_G["RecapList"..i.."_DmgOutP"]:SetTextColor(unpack(rColor.DmgOut))
		_G["RecapSelf"..i.."_EGlances"]:SetTextColor(unpack(rColor.Glances))
		_G["RecapSelf"..i.."_EGlancesMin"]:SetTextColor(unpack(rColor.Glances))
		_G["RecapSelf"..i.."_EGlancesAvg"]:SetTextColor(unpack(rColor.Glances))
		_G["RecapSelf"..i.."_EGlancesMax"]:SetTextColor(unpack(rColor.Glances))
		_G["RecapSelf"..i.."_EHits"]:SetTextColor(unpack(rColor.Hits))
		_G["RecapSelf"..i.."_EHitsMin"]:SetTextColor(unpack(rColor.Hits))
		_G["RecapSelf"..i.."_EHitsAvg"]:SetTextColor(unpack(rColor.Hits))
		_G["RecapSelf"..i.."_EHitsMax"]:SetTextColor(unpack(rColor.Hits))
		_G["RecapSelf"..i.."_ETicks"]:SetTextColor(unpack(rColor.Ticks))
		_G["RecapSelf"..i.."_ETicksMin"]:SetTextColor(unpack(rColor.Ticks))
		_G["RecapSelf"..i.."_ETicksAvg"]:SetTextColor(unpack(rColor.Ticks))
		_G["RecapSelf"..i.."_ETicksMax"]:SetTextColor(unpack(rColor.Ticks))
		_G["RecapSelf"..i.."_ECrits"]:SetTextColor(unpack(rColor.Crits))
		_G["RecapSelf"..i.."_ECritsMin"]:SetTextColor(unpack(rColor.Crits))
		_G["RecapSelf"..i.."_ECritsAvg"]:SetTextColor(unpack(rColor.Crits))
		_G["RecapSelf"..i.."_ECritsMax"]:SetTextColor(unpack(rColor.Crits))
		_G["RecapSelf"..i.."_ECritsP"]:SetTextColor(unpack(rColor.Crits))
		_G["RecapSelf"..i.."_EMiss"]:SetTextColor(unpack(rColor.Miss))
		_G["RecapSelf"..i.."_EMissP"]:SetTextColor(unpack(rColor.Miss))
	end
	Recap_SetTitleBackground()
end

function Recap_SetTitleBackground()
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	if (rOpt.MinBack.value or not rUser.Minimized) then
		if rUser.SelfView and not rUser.Minimized then
			RecapTitleBack:SetVertexColor(0,0,.8)
		elseif rUser.View=="Last" then
			RecapTitleBack:SetVertexColor(0,.66,0)
		else
			RecapTitleBack:SetVertexColor(.66,0,0)
		end
		RecapTitleBack:Show()
	else
		RecapTitleBack:Hide()
	end
end

function Recap_Minimize()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, j, iOpt, item
	local cx = 20 -- 8(edge)+4(space right of status)+8

	rUser.Minimized = true

	-- to support the desired Escape behaviour, obscure the special status of RecapFrame so that it doesn't capture Escape when minimized
	local k, m
	for k,m in ipairs(UISpecialFrames) do
		if m == "RecapFrame" then
			UISpecialFrames[k] = "RecapFrameDummy"
		end
	end

	for i in pairs(rOpt) do
		iOpt = rTemp.DefaultOpt[i]
		if iOpt and iOpt.minwidth then
			if rOpt[i].value then
				item = _G["Recap"..i]
				item:SetWidth(iOpt.minwidth)
				item:Show()
				cx = cx + iOpt.minwidth
			else
				item = _G["Recap"..i]
				item:SetWidth(1)
				item:Hide()
				cx = cx + 1
			end
		elseif iOpt and (iOpt.width or iOpt.ewidth) then
			_G["RecapHeader_"..i]:Hide()
		end
	end

	if rOpt.MinButtons.value then
		cx = cx + 108
		Recap_ShowButtons(16)
	else
		Recap_ShowButtons(1)
		cx = cx + 23 -- 5 + 18
	end

	RecapTopBar:Hide()
	RecapBottomBar:Hide()
	RecapExtraBottomBar:Hide()
	RecapResetButton:Hide()
	RecapTitleButton:Hide()

	for i=1,15 do
		_G["RecapList"..i]:Hide()
		_G["RecapRecentList"..i]:Hide()
		_G["RecapSelf"..i]:Hide()
		_G["RecapRecentSelf"..i]:Hide()
	end
	RecapTotals:Hide()
	RecapGroupTotalButton:Hide()
	RecapNonGroupTotalButton:Hide()
	RecentLabelButton:Hide()
	RecapEventsButton:Hide()
	RecapDispelsAndInterruptsButton:Hide()
	RecapDeathsButton:Hide()
	RecapLiveGraphAndTextButton:Hide()
	RecapHeader_Name:Hide()
	RecapHeader_EName:Hide()
	RecapScrollBar:Hide()

	if rOpt.AutoMinimize.value then
		cx = cx-15
	end

	if rOpt.GrowLeftwards.value and RecapFrame then
		i = RecapFrame:GetRight()
		j = RecapFrame:GetTop()
		if i and j then
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(i-cx,0),math_max(j,0))
		else
			-- default behaviour if any undefined
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("CENTER","UIParent","CENTER")
		end
	end
	RecapFrame:SetWidth(cx)
	Recap_SetHeight(28)

	if rOpt.MinBack.value then
		RecapFrame:SetBackdropColor(1,1,1,1)
		RecapFrame:SetBackdropBorderColor(.5,.5,.5,1)
	else
		RecapFrame:SetBackdropColor(0,0,0,0)
		RecapFrame:SetBackdropBorderColor(0,0,0,0)
	end

	RecapSelfViewButton:Hide()
	RecapPanel_Hide(1)
	RecapRecent_Hide(1)
	Recap_MoveMinimize()
	Recap_TitleBar()
	Recap_SetTitleBackground()
	Recap_DisplayMinimizedDPS()
end

function Recap_Maximize()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, iOpt, item

	rUser.Minimized = false

	Recap_SetColumns() -- this calls SetView which in turn calls ConstructList

	for i in pairs(rOpt) do
		iOpt = rTemp.DefaultOpt[i]
		if iOpt and iOpt.minwidth then
			item = _G["Recap"..i]
			item:SetWidth(iOpt.minwidth)
			item:Hide()
		end
	end
	RecapMinStatus:Show()
	RecapMinSyncStatus:Show()
	RecapMinView:Show()
	Recap_ShowButtons(16)

	RecapTopBar:Show()
	RecapBottomBar:Show()
	RecapExtraBottomBar:Show()
	RecapResetButton:Show()
	RecapTitleButton:Show()

	RecapScrollBar:Show()

	if rUser.SelfView then
		RecapTotals:Hide()
		RecapGroupTotalButton:Hide()
		RecapNonGroupTotalButton:Hide()
		RecentLabelButton:Hide()
		RecapEventsButton:Hide()
		RecapDispelsAndInterruptsButton:Hide()
		RecapDeathsButton:Hide()
		RecapLiveGraphAndTextButton:Hide()
		RecapHeader_Name:Hide()
		RecapHeader_EName:Show()
	else
		RecapTotals:Show()
		RecapGroupTotalButton:Show()
		RecapNonGroupTotalButton:Show()
		RecentLabelButton:Show()
		if rOpt.RecentData.value then
			RecapEventsButton:Enable()
			RecapDispelsAndInterruptsButton:Enable()
			RecapDeathsButton:Enable()
		else
			RecapEventsButton:Disable()
			RecapDispelsAndInterruptsButton:Disable()
			RecapDeathsButton:Disable()
		end
		RecapEventsButton:Show()
		RecapDispelsAndInterruptsButton:Show()
		RecapDeathsButton:Show()
		if rOpt.LiveData.value then
			RecapLiveGraphAndTextButton:Enable()
		else
			RecapLiveGraphAndTextButton:Disable()
		end
		RecapLiveGraphAndTextButton:Show()
		RecapHeader_Name:Show()
		RecapHeader_EName:Hide()
	end

	if rOpt.OpaqueBackground.value then
		RecapFrame:SetBackdrop({bgFile = "Interface\\CharacterFrame\\UI-Party-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
								tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
	else
		RecapFrame:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
								tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 }})
	end
	if not rOpt.LightData.value then
		RecapSelfViewButton:Show()
	end
	Recap_MoveMinimize()

	-- to support the desired Escape behaviour, make RecapFrame special so that it captures Escape when maximized (but only when we have Minimize on Escape turned on)
	if rOpt.MinimizeOnEscape.value then
		local k, m
		for k,m in ipairs(UISpecialFrames) do
			if m == "RecapFrameDummy" then
				UISpecialFrames[k] = "RecapFrame"
			end
		end
	end

end

function Recap_MoveMinimize()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt

	RecapCloseButton:ClearAllPoints()
	RecapCloseButton:SetPoint("TOPRIGHT", "RecapFrame", "TOPRIGHT", -6, -6)
	RecapMinStatus:ClearAllPoints()
	RecapMinStatus:SetPoint("TOPLEFT", "RecapFrame", "TOPLEFT", 6, -7)
	RecapResetButton:ClearAllPoints()
	RecapResetButton:SetPoint("BOTTOMLEFT", "RecapFrame", "BOTTOMLEFT", 5, 24)
	RecapMinimizeButton:ClearAllPoints()

	if rOpt.GrowLeftwards.value and not rOpt.GrowUpwards.value then -- topright
		RecapMinimizeButton:SetPoint("TOPRIGHT", "RecapFrame", "TOPRIGHT", -6, -6)
		RecapCloseButton:SetPoint("TOPRIGHT", "RecapMinimizeButton", "TOPLEFT", -2, 0)
	elseif rOpt.GrowLeftwards.value and rOpt.GrowUpwards.value then -- bottomright
		RecapMinimizeButton:SetPoint("BOTTOMRIGHT", "RecapFrame", "BOTTOMRIGHT", -6, 6)
		if rUser.Minimized then
			RecapCloseButton:SetPoint("TOPRIGHT", "RecapMinimizeButton", "TOPLEFT", -2, 0)
		end
	elseif not rOpt.GrowLeftwards.value and not rOpt.GrowUpwards.value then -- topleft
		RecapMinimizeButton:SetPoint("TOPLEFT", "RecapFrame", "TOPLEFT", 6, -6)
		RecapMinStatus:SetPoint("TOPLEFT", "RecapMinimizeButton", "TOPRIGHT", 2, -1)
	else -- bottomleft
		RecapMinimizeButton:SetPoint("BOTTOMLEFT", "RecapFrame", "BOTTOMLEFT", 6, 6)
		RecapResetButton:SetPoint("BOTTOMLEFT", "RecapFrame", "BOTTOMLEFT", 28, 24)
	end

	if rUser.Minimized and not rOpt.GrowLeftwards.value then
		RecapMinStatus:SetPoint("TOPLEFT", "RecapMinimizeButton", "TOPRIGHT", 2, -1)
	end

	if rOpt.AutoMinimize.value then
		RecapMinimizeButton:SetWidth(1)
		RecapMinimizeButton:Hide()
	else
		RecapMinimizeButton:SetWidth(16)
		RecapMinimizeButton:Show()
	end

end

function RecapScrollBar_Update()

	-- only called when not minimized

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, j, index, item, item2, item3
	local listsize = rUser.SelfView and rTemp.SelfListSize or rTemp.ListSize
	local thisCombatant, iCombatant, iList

	i = 92 + (math_max(math_min(listsize-1,rOpt.MaxRows.value),1 )*14 )
	Recap_SetHeight(i)
	RecapScrollBar:SetHeight(i-83)
	FauxScrollFrame_Update(RecapScrollBar,listsize-1,rOpt.MaxRows.value,14)

	for i=1,rOpt.MaxRows.value do
		index = i + FauxScrollFrame_GetOffset(RecapScrollBar)

		if not rUser.SelfView then
			-- general view

			if index < listsize then
				iList = rTemp.List[index]
				thisCombatant = iList.Name
				if thisCombatant then
					iCombatant = rCombatants[thisCombatant]
					if iCombatant then

						-- there is a display problem when switching from Personal Details
						--   to All Fights or Last Fight if the fights display begins with hidden
						--   columns.  The workaround appears to be to force the first four columns
						--   (Ranks, Faction, Class, and Level) to always appear (though perhaps
						--   with blank content).
						--   See more code in Recap_SetColumns and Recap_ConstructList,
						--   and a texture addition to RecapHeader_Faction.
						if rOpt.Ranks.value then
							-- Ranks will appear
							_G["RecapList"..i.."_Ranks"]:SetText(index)
						else
							-- Ranks needs to be set to blank
							_G["RecapList"..i.."_Ranks"]:SetText("")
						end
						if rOpt.Faction.value then
							-- Faction and Level will appear
							Recap_SetFactionIcon(i, iCombatant.Faction)
							if iCombatant.Level and tonumber(iCombatant.Level)>0 then
								_G["RecapList"..i.."_Level"]:SetText(iCombatant.Level)
							elseif iCombatant.Level and tonumber(iCombatant.Level)==-1 then
								_G["RecapList"..i.."_Level"]:SetText("??")
							else
								_G["RecapList"..i.."_Level"]:SetText("")
							end
						else
							-- Faction icon needs to be set to black, and Level to blank
							Recap_SetFactionIcon(i, nil)
							_G["RecapList"..i.."_Level"]:SetText("")
						end
						if rOpt.Class.value then
							-- Class will appear
							Recap_SetClassIcon(i, iCombatant.Class)
						else
							-- Class icon needs to be set to black
							Recap_SetClassIcon(i, nil)
						end

						item = _G["RecapList"..i.."_Name"]
						item:SetText(Recap_StripGUIDsFromCombatant(thisCombatant))
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_Gauge"]
						if rOpt.ShowGauges.value and rTemp.GaugeMax>0 and rTemp.GaugeBy and iCombatant.Friend then
							item:SetWidth(1+rTemp.GaugeWidth*iList[rTemp.GaugeBy]/rTemp.GaugeMax)
							item:Show()
						else
							item:Hide()
						end

						_G["RecapList"..i.."_Seen"]:SetText(Recap_FormatTimeSeen((iList.Seen or 0)/1000))

						_G["RecapList"..i.."_Deaths"]:SetText(iList.Deaths)

						_G["RecapList"..i.."_Dispels"]:SetText(iList.Dispels)

						_G["RecapList"..i.."_Interrupts"]:SetText(iList.Interrupts)

						item = _G["RecapList"..i.."_Time"]
						item:SetText(Recap_FormatTime(iList.Time))
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_DmgOut"]
						item2 = _G["RecapList"..i.."_DmgOutP"]
						item:SetText(iList.DmgOut)
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
							item2:SetText(iList.DmgOutP.."%")
							item2:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
							item2:SetText("")
						end

						item = _G["RecapList"..i.."_MaxHit"]
						item:SetText(iList.MaxHit)
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_DPS"]
						if iList.DPS<1000 then
							item:SetFormattedText("%.1f",iList.DPS)
						else
							item:SetFormattedText("%d",Recap_Round1(iList.DPS))
						end
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_DPSPerGear"]
						item:SetFormattedText("%d",iList.DPSPerGear)
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_DPSvsAll"]
						if iList.DPSvsAll<1000 then
							item:SetFormattedText("%.1f",iList.DPSvsAll)
						else
							item:SetFormattedText("%d",Recap_Round1(iList.DPSvsAll))
						end
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgOut))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_TimeIn"]
						item:SetText(Recap_FormatTime(iList.TimeIn))
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgIn))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_DmgIn"]
						item2 = _G["RecapList"..i.."_DmgInP"]
						item:SetText(iList.DmgIn)
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgIn))
							item2:SetText(iList.DmgInP.."%")
							item2:SetTextColor(unpack(rColor.DmgIn))
						else
							item:SetTextColor(unpack(rColor.White))
							item2:SetText("")
						end

						item = _G["RecapList"..i.."_DPSIn"]
						if iList.DPSIn<1000 then
							item:SetFormattedText("%.1f",iList.DPSIn)
						else
							item:SetFormattedText("%d",Recap_Round1(iList.DPSIn))
						end
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.DmgIn))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_TimeHeal"]
						item:SetText(Recap_FormatTime(iList.TimeHeal))
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.Heal))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_Heal"]
						item2 = _G["RecapList"..i.."_HealP"]
						item3 = _G["RecapList"..i.."_Over"]
						item:SetText(iList.RawHeal - iList.OverHeal)
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.Heal))
							item2:SetText(iList.HealP.."%")
							item2:SetTextColor(unpack(rColor.Heal))
							item3:SetText(iList.Over.."%")
							item3:SetTextColor(unpack(rColor.Heal))
						else
							item:SetTextColor(unpack(rColor.White))
							item2:SetText("")
							item2:SetTextColor(unpack(rColor.White))
							item3:SetText("")
							item3:SetTextColor(unpack(rColor.White))
						end

						item = _G["RecapList"..i.."_HPS"]
						if iList.HPS<1000 then
							item:SetFormattedText("%.1f",iList.HPS)
						else
							item:SetFormattedText("%d",Recap_Round1(iList.HPS))
						end
						if iCombatant.Friend then
							item:SetTextColor(unpack(rColor.Heal))
						else
							item:SetTextColor(unpack(rColor.White))
						end

						_G["RecapRecentList"..i.."_Text"]:SetTextColor(_G["RecapList"..i.."_Name"]:GetTextColor())
						_G["RecapRecentList"..i.."_SaveColor"]:SetTextColor(_G["RecapList"..i.."_Name"]:GetTextColor())
						if rOpt.RecentData.value then
							_G["RecapRecentList"..i]:Enable()
						else
							_G["RecapRecentList"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
							_G["RecapRecentList"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
							_G["RecapRecentList"..i]:Disable()
						end
						_G["RecapRecentList"..i]:Show()

						item = _G["RecapList"..i]
						item:Show()
						if rTemp.Selected == index then
							item:LockHighlight()
						else
							item:UnlockHighlight()
						end
					end
				end
			else
				_G["RecapList"..i]:Hide()
				_G["RecapList"..i]:UnlockHighlight()
				_G["RecapRecentList"..i]:Hide()
			end

			for i=rOpt.MaxRows.value+1,15 do
				_G["RecapList"..i]:Hide()
				_G["RecapRecentList"..i]:Hide()
			end

		elseif rUser.SelfView then
			-- personal view

			if index < listsize then
				iList = rTemp.SelfList[index]

				_G["RecapSelf"..i.."_EName"]:SetText(string_sub(iList.EName,2))
				_G["RecapSelf"..i.."_EElement"]:SetText(iList.EElement)
				_G["RecapSelf"..i.."_ETotal"]:SetText(iList.ETotal)
				_G["RecapSelf"..i.."_EGlances"]:SetText(iList.EGlances)
				_G["RecapSelf"..i.."_EGlancesMin"]:SetText(iList.EGlancesMin)
				_G["RecapSelf"..i.."_EGlancesAvg"]:SetText(iList.EGlancesAvg)
				_G["RecapSelf"..i.."_EGlancesMax"]:SetText(iList.EGlancesMax)
				_G["RecapSelf"..i.."_EHits"]:SetText(iList.EHits)
				_G["RecapSelf"..i.."_EHitsMin"]:SetText(iList.EHitsMin)
				_G["RecapSelf"..i.."_EHitsAvg"]:SetText(iList.EHitsAvg)
				_G["RecapSelf"..i.."_EHitsMax"]:SetText(iList.EHitsMax)
				_G["RecapSelf"..i.."_ETicks"]:SetText(iList.ETicks)
				_G["RecapSelf"..i.."_ETicksMin"]:SetText(iList.ETicksMin)
				_G["RecapSelf"..i.."_ETicksAvg"]:SetText(iList.ETicksAvg)
				_G["RecapSelf"..i.."_ETicksMax"]:SetText(iList.ETicksMax)
				_G["RecapSelf"..i.."_ECrits"]:SetText(iList.ECrits)
				_G["RecapSelf"..i.."_ECritsMin"]:SetText(iList.ECritsMin)
				_G["RecapSelf"..i.."_ECritsAvg"]:SetText(iList.ECritsAvg)
				_G["RecapSelf"..i.."_ECritsMax"]:SetText(iList.ECritsMax)
				_G["RecapSelf"..i.."_ECritsP"]:SetText(iList.ECritsP)
				_G["RecapSelf"..i.."_EMiss"]:SetText(iList.EMiss)
				_G["RecapSelf"..i.."_EMissP"]:SetText(iList.EMissP)
				_G["RecapSelf"..i.."_EMaxAll"]:SetText(iList.EMaxAll)
				_G["RecapSelf"..i.."_ETotalP"]:SetText(iList.ETotalP)
				if (string_sub(iList.EName,1,1) == "1") or (string_sub(iList.EName,1,1) == "2") then
					_G["RecapSelf"..i.."_EName"]:SetTextColor(unpack(rColor.DmgOut))
					_G["RecapSelf"..i.."_EElement"]:SetTextColor(unpack(rColor.DmgOut))
					_G["RecapSelf"..i.."_ETotal"]:SetTextColor(unpack(rColor.DmgOut))
					_G["RecapSelf"..i.."_ETotalP"]:SetTextColor(unpack(rColor.DmgOut))
				else
					_G["RecapSelf"..i.."_EName"]:SetTextColor(unpack(rColor.Heal))
					_G["RecapSelf"..i.."_EElement"]:SetTextColor(unpack(rColor.Heal))
					_G["RecapSelf"..i.."_ETotal"]:SetTextColor(unpack(rColor.Heal))
					_G["RecapSelf"..i.."_ETotalP"]:SetTextColor(unpack(rColor.Heal))
				end
				_G["RecapSelf"..i]:Show()

				item = _G["RecapRecentSelf"..i]
				_G["RecapRecentSelf"..i.."_Text"]:SetTextColor(unpack(rColor.Green))
				_G["RecapRecentSelf"..i.."_SaveColor"]:SetTextColor(unpack(rColor.Green))
				if rOpt.RecentData.value then
					item:Enable()
				else
					_G["RecapRecentSelf"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
					_G["RecapRecentSelf"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
					item:Disable()
				end
				item:Show()
			else
				_G["RecapSelf"..i]:Hide()
				_G["RecapRecentSelf"..i]:Hide()
			end

			for i=rOpt.MaxRows.value+1,15 do
				_G["RecapSelf"..i]:Hide()
				_G["RecapRecentSelf"..i]:Hide()
			end
		end
	end
end

-- the following does both DPS and HPS
-- added damage, max hit, damage in, healing, overhealing (for fubar)
-- added per percent
function Recap_UpdateMinimizedDPS()

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local i, playerDPSLast, playerHPSLast, playerDPSAll, playerHPSAll, petDPSLast, petHPSLast, petDPSAll, petHPSAll, iLastOwner, iLastPet
	local playerDmgLast, playerDmgAll, playerMaxHitLast, playerMaxHitAll, playerDmgInLast, playerDmgInAll
	local petDmgLast, petDmgAll, petMaxHitLast, petMaxHitAll, petDmgInLast, petDmgInAll
	local playerHealingLast, playerHealingAll, playerOverhealingLast, playerOverhealingAll
	local petHealingLast, petHealingAll, petOverhealingLast, petOverhealingAll
	local groupDurationLast, groupDurationInLast, groupDurationHealLast, groupDmgOutLast, groupDmgInLast, groupHealLast, overhealing
	local groupDurationAll, groupDurationInAll, groupDurationHealAll, groupDmgOutAll, groupDmgInAll, groupHealAll
	local petsDmgLast, petsDmgAll
	local groupDPS, groupDPSIn, groupHPS

	-- player live DPS and HPS
	playerDPSLast = 0
	playerDmgLast = 0
	petsDmgLast = 0
	playerMaxHitLast = 0
	playerDmgInLast = 0
	playerHPSLast = 0
	playerHealingLast = 0
	playerOverhealingLast = 0
	playerDPSAll = 0
	playerDmgAll = 0
	petsDmgAll = 0
	playerMaxHitAll = 0
	playerDmgInAll = 0
	playerHPSAll = 0
	playerHealingAll = 0
	playerOverhealingAll = 0
	iLastOwner = rTemp.Last[rTemp.PlayerGUID]
	if Recap_PetsMerged() then
		-- merge pet DPS and HPS
		playerDPSLast, playerDPSAll, playerDmgLast, playerDmgAll, petsDmgLast, petsDmgAll, playerMaxHitLast, playerMaxHitAll, playerDmgInLast, playerDmgInAll = Recap_GetCurrentLiveDmgMergePets(rTemp.PlayerGUID, iLastOwner)
		playerHPSLast, playerHPSAll, playerHealingLast, playerHealingAll, playerOverhealingLast, playerOverhealingAll = Recap_GetCurrentLiveHealMergePets(rTemp.PlayerGUID, iLastOwner)
	else
		-- add pet DPS and HPS (subtly different)
		playerDPSLast, playerDPSAll, playerDmgLast, playerDmgAll, playerMaxHitLast, playerMaxHitAll, playerDmgInLast, playerDmgInAll = Recap_GetCurrentLiveDmg(rTemp.PlayerGUID, iLastOwner)
		playerHPSLast, playerHPSAll, playerHealingLast, playerHealingAll, playerOverhealingLast, playerOverhealingAll = Recap_GetCurrentLiveHeal(rTemp.PlayerGUID, iLastOwner)
		-- optimization for a scan of Last looking for player's pets
		for i in pairs(rTemp.LastPlayerPets) do
			local iLastPet = rTemp.Last[i]
			if iLastPet then
				if (iLastPet.DmgOut>0) or (iLastPet.DmgIn>0) then
					-- this pet did damage or took damage
					petDPSLast, petDPSAll, petDmgLast, petDmgAll, petMaxHitLast, petMaxHitAll, petDmgInLast, petDmgInAll = Recap_GetCurrentLiveDmg(i, iLastPet)
					playerDPSLast = playerDPSLast + petDPSLast
					playerDPSAll = playerDPSAll + petDPSAll
					playerDmgLast = playerDmgLast + petDmgLast
					playerDmgAll = playerDmgAll + petDmgAll
					petsDmgLast = petsDmgLast + petDmgLast
					petsDmgAll = petsDmgAll + petDmgAll
					playerMaxHitLast = math_max(playerMaxHitLast, petMaxHitLast)
					playerMaxHitAll = math_max(playerMaxHitAll, petMaxHitAll)
					playerDmgInLast = playerDmgInLast + petDmgInLast
					playerDmgInAll = playerDmgInAll + petDmgInAll
				end
				if iLastPet.RawHeal>0 then
					-- this pet did healing
					petHPSLast, petHPSAll, petHealingLast, petHealingAll, petOverhealingLast, petOverhealingAll = Recap_GetCurrentLiveHeal(pet, iLastPet)
					playerHPSLast = playerHPSLast + petHPSLast
					playerHPSAll = playerHPSAll + petHPSAll
					playerHealingLast = playerHealingLast + petHealingLast
					playerHealingAll = playerHealingAll + petHealingAll
					playerOverhealingLast = playerOverhealingLast + petOverhealingLast
					playerOverhealingAll = playerOverhealingAll + petOverhealingAll
				end
			end
		end
	end

	-- group live DPS and HPS
	groupDurationLast = 0
	groupDurationInLast = 0
	groupDurationHealLast = 0
	groupDmgOutLast = 0
	groupDmgInLast = 0
	groupHealLast = 0
	groupDurationAll = 0
	groupDurationInAll = 0
	groupDurationHealAll = 0
	if (rTemp.FightStart > 0) and (rTemp.FightEnd > rTemp.FightStart) then
		groupDurationLast = rTemp.FightEnd - rTemp.FightStart
	end
	if (rTemp.FightStartIn > 0) and (rTemp.FightEndIn > rTemp.FightStartIn) then
		groupDurationInLast = rTemp.FightEndIn - rTemp.FightStartIn
	end
	if (rTemp.FightStartHeal > 0) and (rTemp.FightEndHeal > rTemp.FightStartHeal) then
		groupDurationHealLast = rTemp.FightEndHeal - rTemp.FightStartHeal
	end
	-- optimization for a scan of Last looking for Friend combatants
	for i in pairs(rTemp.InFriend) do
		local iLast = rTemp.Last[i]
		if iLast then
			groupDmgOutLast = groupDmgOutLast + (iLast.DmgOut or 0)
			groupDmgInLast = groupDmgInLast + (iLast.DmgIn or 0)
			overhealing = math_min((iLast.OverHeal or 0), (iLast.RawHeal or 0))
			groupHealLast = groupHealLast + (iLast.RawHeal or 0) - overhealing
		end
	end
	groupDurationAll = groupDurationLast + rUser.TotalDuration
	groupDurationInAll = groupDurationInLast + rUser.TotalDurationIn
	groupDurationHealAll = groupDurationHealLast + rUser.TotalDurationHeal
	-- NOTE: many numbers are NOT available except during or after a fight
	groupDmgOutAll = groupDmgOutLast + (rTemp.TotalGroupDmgOut or 0)
	groupDmgInAll = groupDmgInLast + (rTemp.TotalGroupDmgIn or 0)
	groupHealAll = groupHealLast + (rTemp.TotalGroupHeal or 0)

	-- only update if at least one number is non-zero (avoids some spurious resets to zero)
	if (playerDmgAll > 0) or (playerDmgInAll > 0) or (playerHealingAll > 0) or (playerOverhealingAll > 0) then
		rTemp.PlayerDPSAll = playerDPSAll
		rTemp.PlayerDmgAll = playerDmgAll
		if playerDmgAll == 0 then
			rTemp.PlayerPetPercentAll = 0
		else
			rTemp.PlayerPetPercentAll = math_floor((100*petsDmgAll / playerDmgAll) + 0.5)
		end
		rTemp.PlayerMaxHitAll = playerMaxHitAll
		rTemp.PlayerDmgInAll = playerDmgInAll
		rTemp.PlayerHPSAll = playerHPSAll
		rTemp.PlayerHealingAll = playerHealingAll
		rTemp.PlayerOverhealingAll = playerOverhealingAll
	end
	-- only update if at least one number is non-zero (avoids some spurious resets to zero)
	if groupDurationAll > rTemp.MinTime then
		groupDPS = Recap_Div1(groupDmgOutAll, groupDurationAll)
	else
		groupDPS = 0
	end
	if groupDurationInAll > rTemp.MinTime then
		groupDPSIn = Recap_Div1(groupDmgInAll, groupDurationInAll)
	else
		groupDPSIn = 0
	end
	if groupDurationHealAll > rTemp.MinTime then
		groupHPS = Recap_Div1(groupHealAll, groupDurationHealAll)
	else
		groupHPS = 0
	end
	if (groupDPS > 0) or (groupDPSIn > 0) or (groupHPS > 0) then
		rTemp.GroupDPSOutAll = groupDPS
		rTemp.GroupDPSInAll = groupDPSIn
		rTemp.GroupHPSAll = groupHPS
	end
	-- only update if at least one number is non-zero (avoids some spurious resets to zero)
	if (playerDmgLast > 0) or (playerDmgInLast > 0) or (playerHealingLast > 0) or (playerOverhealingLast > 0) then
		rTemp.PlayerDPSLast = playerDPSLast
		rTemp.PlayerDmgLast = playerDmgLast
		if playerDmgLast == 0 then
			rTemp.PlayerPetPercentLast = 0
		else
			rTemp.PlayerPetPercentLast = math_floor((100*petsDmgLast / playerDmgLast) + 0.5)
		end
		rTemp.PlayerMaxHitLast = playerMaxHitLast
		rTemp.PlayerDmgInLast = playerDmgInLast
		rTemp.PlayerHPSLast = playerHPSLast
		rTemp.PlayerHealingLast = playerHealingLast
		rTemp.PlayerOverhealingLast = playerOverhealingLast
	end
	-- only update if at least one number is non-zero (avoids some spurious resets to zero)
	if groupDurationLast > rTemp.MinTime then
		groupDPS = Recap_Div1(groupDmgOutLast, groupDurationLast)
	else
		groupDPS = 0
	end
	if groupDurationInLast > rTemp.MinTime then
		groupDPSIn = Recap_Div1(groupDmgInLast, groupDurationInLast)
	else
		groupDPSIn = 0
	end
	if groupDurationHealLast > rTemp.MinTime then
		groupHPS = Recap_Div1(groupHealLast, groupDurationHealLast)
	else
		groupHPS = 0
	end
	if (groupDPS > 0) or (groupDPSIn > 0) or (groupHPS > 0) then
		rTemp.GroupDPSOutLast = groupDPS
		rTemp.GroupDPSInLast = groupDPSIn
		rTemp.GroupHPSLast = groupHPS
	end
end

-- we have calculated live numbers, now display them appropriately and send them to any plugins
-- note that fubar and titan no longer access these, but read the recap_temp numbers directly
function Recap_DisplayMinimizedDPS()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	if rUser.View=="Last" then
		RecapMinYourDPS_Text:SetFormattedText("%.1f", rTemp.PlayerDPSLast)
		RecapMinYourPetPercent_Text:SetFormattedText("%d%%", rTemp.PlayerPetPercentLast)
		RecapMinYourHPS_Text:SetFormattedText("%.1f", rTemp.PlayerHPSLast)
		RecapMinDPSOut_Text:SetFormattedText("%.1f", rTemp.GroupDPSOutLast)
		RecapMinDPSIn_Text:SetFormattedText("%.1f", rTemp.GroupDPSInLast)
		RecapMinHPS_Text:SetFormattedText("%.1f", rTemp.GroupHPSLast)
	else
		RecapMinYourDPS_Text:SetFormattedText("%.1f", rTemp.PlayerDPSAll)
		RecapMinYourPetPercent_Text:SetFormattedText("%d%%", rTemp.PlayerPetPercentAll)
		RecapMinYourHPS_Text:SetFormattedText("%.1f", rTemp.PlayerHPSAll)
		RecapMinDPSOut_Text:SetFormattedText("%.1f", rTemp.GroupDPSOutAll)
		RecapMinDPSIn_Text:SetFormattedText("%.1f", rTemp.GroupDPSInAll)
		RecapMinHPS_Text:SetFormattedText("%.1f", rTemp.GroupHPSAll)
	end

	if IB_Recap_Update then
		IB_Recap_Update("DPS: "..RecapMinYourDPS_Text:GetText())
	end

	if TitanPanelRecap_Update then
		TitanPanelRecap_Update(rUser.State,RecapMinYourDPS_Text:GetText(),RecapMinDPSIn_Text:GetText(),RecapMinDPSOut_Text:GetText(),RecapMinYourHPS_Text:GetText(),RecapMinHPS_Text:GetText(),RecapMinYourPetPercent_Text:GetText())
	end

	if FuBarRecap_Update then
		FuBarRecap_Update(rUser.State,RecapMinYourDPS_Text:GetText(),RecapMinDPSIn_Text:GetText(),RecapMinDPSOut_Text:GetText(),RecapMinYourHPS_Text:GetText(),RecapMinHPS_Text:GetText(),RecapMinYourPetPercent_Text:GetText())
	end

	if rOpt.LDBSupport.value and lastAll then
		-- when enabled and initialized, put information into LibDataBroker objects
		-- note, this probably creates spurious channel activity if no addon is wanting to display this information
		if rUser.State=="Stopped" then
			lastAll.iconR = 1
			lastAll.iconG = 0
			lastAll.iconB = 0
		elseif rUser.State=="Active" then
			if rUser.SkipNextFight == true then
				lastAll.iconR = 1
				lastAll.iconG = 0.75
				lastAll.iconB = 0
			else
				lastAll.iconR = 0
				lastAll.iconG = 1
				lastAll.iconB = 0
			end
		elseif rUser.State=="Idle" then
			lastAll.iconR = 0.5
			lastAll.iconG = 0.5
			lastAll.iconB = 0.5
		end
		lastAll.text = rTemp.Recap.." "..rLocalize.LastAll[rUser.View]
		yourDPS.text = RecapMinYourDPS_Text:GetText()
		yourPetPercent.text = RecapMinYourPetPercent_Text:GetText()
		yourHPS.text = RecapMinYourHPS_Text:GetText()
		groupDPSOut.text = RecapMinDPSOut_Text:GetText()
		groupHPS.text = RecapMinHPS_Text:GetText()
		if rUser.View=="Last" then
			yourDmgIn.text = tostring(rTemp.PlayerDmgInLast)
			yourDmgOut.text = tostring(rTemp.PlayerDmgLast)
			yourHealing.text = tostring(rTemp.PlayerHealingLast)
			yourMaxHit.text = tostring(rTemp.PlayerMaxHitLast)
		else
			yourDmgIn.text = tostring(rTemp.PlayerDmgInAll)
			yourDmgOut.text = tostring(rTemp.PlayerDmgAll)
			yourHealing.text = tostring(rTemp.PlayerHealingAll)
			yourMaxHit.text = tostring(rTemp.PlayerMaxHitAll)
		end
	end

end

-- the 'live' numbers were originally created only during or after a fight
-- this variation is for generating the numbers when Recap first starts up
-- there will be no 'last fight'
local function Recap_GetStartupDmg(combatant)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local iTotal, durationAll, damageAll, petsDamageAll, DPSAll, maxHitAll, damageInAll
	durationAll = 0
	damageAll = 0
	petsDamageAll = 0
	DPSAll = 0
	maxHitAll = 0
	damageInAll = 0
	iTotal = rCombatants[combatant]
	if iTotal then
		durationAll = (iTotal.TotalTime or 0)
		damageAll = (iTotal.TotalDmgOut or 0)
		petsDamageAll = (iTotal.TotalPetsDmgOut or 0)
		maxHitAll = (iTotal.TotalMaxHit or 0)
		damageInAll = (iTotal.TotalDmgIn or 0)
	end
	if durationAll > rTemp.MinTime then
		DPSAll = Recap_Div1(damageAll, durationAll)
	end
	return DPSAll, damageAll, petsDamageAll, maxHitAll, damageInAll
end
local function Recap_GetStartupHeal(combatant)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local iTotal, durationAll, healingAll, HPSAll, overhealingAll
	durationAll = 0
	healingAll = 0
	HPSAll = 0
	overhealingAll = 0
	iTotal = rCombatants[combatant]
	if iTotal then
		durationAll =  (iTotal.TotalTimeHeal or 0)
		overhealingAll = math_min((iTotal.TotalOverHeal or 0), (iTotal.TotalRawHeal or 0))
		healingAll = (iTotal.TotalRawHeal or 0) - overhealingAll
	end
	if durationAll > rTemp.MinTime then
		HPSAll = Recap_Div1(healingAll, durationAll)
	end
	return HPSAll, healingAll, overhealingAll
end
function Recap_StartupMinimizedDPS()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, iFriend, playerDPSAll, playerHPSAll, petDPSAll, petHPSAll
	local playerDmgAll, playerMaxHitAll, playerDmgInAll
	local petDmgAll, petMaxHitAll, petDmgInAll
	local playerHealingAll, playerOverhealingAll
	local petHealingAll, petOverhealingAll
	local overhealing
	local groupDurationAll, groupDurationInAll, groupDurationHealAll, groupDmgOutAll, groupDmgInAll, groupHealAll
	local petsDamageAll

	-- player live DPS and HPS
	playerDPSAll = 0
	playerDmgAll = 0
	petsDamageAll = 0
	playerMaxHitAll = 0
	playerDmgInAll = 0
	playerHPSAll = 0
	playerHealingAll = 0
	playerOverhealingAll = 0
	-- get the player's data
	playerDPSAll, playerDmgAll, petsDamageAll, playerMaxHitAll, playerDmgInAll = Recap_GetStartupDmg(rTemp.PlayerGUID)
	playerHPSAll, playerHealingAll, playerOverhealingAll = Recap_GetStartupHeal(rTemp.PlayerGUID)
	if Recap_PetsMerged() then
		-- at Startup pets are already merged
	else
		-- add in the player's pets, checking the entire list of combatants
		for i in pairs(rCombatants) do
			if Recap_IsOwnedBy(i, rTemp.PlayerGUID) then
				-- one of the player's pets
				local petPetDmgAll -- dummy, value is ignored
				petDPSAll, petDmgAll, petPetDmgAll, petMaxHitAll, petDmgInAll = Recap_GetStartupDmg(i)
				playerDPSAll = playerDPSAll + petDPSAll
				playerDmgAll = playerDmgAll + petDmgAll
				petsDamageAll = petsDamageAll + petDmgAll
				playerMaxHitAll = math_max(playerMaxHitAll, petMaxHitAll)
				playerDmgInAll = playerDmgInAll + petDmgInAll
				petHPSAll, petHealingAll, petOverhealingAll = Recap_GetStartupHeal(i)
				playerHPSAll = playerHPSAll + petHPSAll
				playerHealingAll = playerHealingAll + petHealingAll
				playerOverhealingAll = playerOverhealingAll + petOverhealingAll
			end
		end
	end
	rTemp.PlayerDPSLast = 0
	rTemp.PlayerDPSAll = playerDPSAll
	rTemp.PlayerDmgLast = 0
	rTemp.PlayerDmgAll = playerDmgAll
	rTemp.PlayerPetPercentLast = 0
	if playerDmgAll == 0 then
		rTemp.PlayerPetPercentAll = 0
	else
		rTemp.PlayerPetPercentAll = math_floor((100*petsDamageAll / playerDmgAll) + 0.5)
	end
	rTemp.PlayerMaxHitLast = 0
	rTemp.PlayerMaxHitAll = playerMaxHitAll
	rTemp.PlayerDmgInLast = 0
	rTemp.PlayerDmgInAll = playerDmgInAll
	rTemp.PlayerHPSLast = 0
	rTemp.PlayerHPSAll = playerHPSAll
	rTemp.PlayerHealingLast = 0
	rTemp.PlayerHealingAll = playerHealingAll
	rTemp.PlayerOverhealingLast = 0
	rTemp.PlayerOverhealingAll = playerOverhealingAll

	-- group live DPS and HPS
	groupDurationAll = 0
	groupDurationInAll = 0
	groupDurationHealAll = 0
	rTemp.GroupDPSOutLast = 0
	rTemp.GroupDPSInLast = 0
	rTemp.GroupHPSLast = 0
	groupDurationAll = rUser.TotalDuration
	groupDurationInAll = rUser.TotalDurationIn
	groupDurationHealAll = rUser.TotalDurationHeal
	rTemp.TotalGroupDmgIn = 0
	rTemp.TotalGroupDmgOut = 0
	rTemp.TotalGroupHeal = 0
	-- sum these specially
	for i, iFriend in pairs(rCombatants) do
		if iFriend.Friend then
			if Recap_PetsMerged() then
				-- pets already merged, don't double-count pets
				if iFriend.OwnedBy then
					-- listed as having an owner, skip this combatant
				else
					rTemp.TotalGroupDmgIn = rTemp.TotalGroupDmgIn + (iFriend.TotalDmgIn or 0)
					rTemp.TotalGroupDmgOut = rTemp.TotalGroupDmgOut + (iFriend.TotalDmgOut or 0)
					overhealing = math_min((iFriend.TotalOverHeal or 0), (iFriend.TotalRawHeal or 0))
					rTemp.TotalGroupHeal = rTemp.TotalGroupHeal + (iFriend.TotalRawHeal or 0) - overhealing
				end
			else
				-- pets not merged, count all friends
				rTemp.TotalGroupDmgIn = rTemp.TotalGroupDmgIn + (iFriend.TotalDmgIn or 0)
				rTemp.TotalGroupDmgOut = rTemp.TotalGroupDmgOut + (iFriend.TotalDmgOut or 0)
				overhealing = math_min((iFriend.TotalOverHeal or 0), (iFriend.TotalRawHeal or 0))
				rTemp.TotalGroupHeal = rTemp.TotalGroupHeal + (iFriend.TotalRawHeal or 0) - overhealing
			end
		end
	end
	groupDmgOutAll = (rTemp.TotalGroupDmgOut or 0)
	groupDmgInAll = (rTemp.TotalGroupDmgIn or 0)
	groupHealAll = (rTemp.TotalGroupHeal or 0)
	rTemp.GroupDPSOutAll = 0
	rTemp.GroupDPSInAll = 0
	rTemp.GroupHPSAll = 0
	if groupDurationAll > rTemp.MinTime then
		rTemp.GroupDPSOutAll = Recap_Div1(groupDmgOutAll, groupDurationAll)
	end
	if groupDurationInAll > rTemp.MinTime then
		rTemp.GroupDPSInAll = Recap_Div1(groupDmgInAll, groupDurationInAll)
	end
	if groupDurationHealAll > rTemp.MinTime then
		rTemp.GroupHPSAll = Recap_Div1(groupHealAll, groupDurationHealAll)
	end
end

function Recap_GetIB_Tooltip()
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local yourdps
	if rUser.View=="Last" then
		yourdps = string_format("%.1f", rTemp.PlayerDPSLast)
	else
		yourdps = string_format("%.1f", rTemp.PlayerDPSAll)
	end
	-- note, the following displays some live numbers and several non-live numbers
	return rLocalize.LastAll[rUser.View]..":\n"..RECAP_YOUR_DPS..": "..yourdps.."\n"..RECAP_MAX_HIT..": "..RecapTotals_MaxHit:GetText().."\n"..RECAP_TOTAL_DPS_OUT..": "..RecapTotals_DPS:GetText().."\n"..RECAP_TOTAL_DPS_IN..": "..RecapTotals_TotDPSIn:GetText()
end

function Recap_ResetSelfPlayerAndPets()

	local rTemp = _G.recap_temp
	local rSelf = _G.recap.Self
	local i

	-- reset owner and pets
	for i in pairs(rSelf) do
		if string_find(i, rTemp.s, 1, true) then
			rSelf[i] = wipe(rSelf[i])
		end
	end
end

-- this resizes the window width to the columns defined in options
-- this calls SetView which in turn calls ConstructList
function Recap_SetColumns()

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, j, cx, item, subitem, iOpt
	local recentWidth = 55

	-- name width was 120 changed to 144 to allow for longer names, especially
	--   under Spells and Abilities on the "Personal Details" panel.
	-- Matching changes made in Recap.xml for parent_EName, parent_Name, RecapHeader_Name, and
	--   RecapHeader_EName.
	cx = rTemp.ScrollAndEdgeWidth + rTemp.NameWidth

	if rUser.SelfView then
		-- personal view
		for i in pairs(rOpt) do
			iOpt = rTemp.DefaultOpt[i]
			if iOpt and iOpt.ewidth then
				if rOpt[i].value then
					_G["RecapHeader_"..i]:SetWidth(iOpt.ewidth)
					_G["RecapHeader_"..i]:Show()
					for j=1,15 do
						_G["RecapSelf"..j.."_"..i]:SetWidth(iOpt.ewidth)
						_G["RecapSelf"..j.."_"..i]:Show()
					end
					cx = cx + iOpt.ewidth
				else
					_G["RecapHeader_"..i]:SetWidth(1)
					_G["RecapHeader_"..i]:Hide()
					for j=1,15 do
						_G["RecapSelf"..j.."_"..i]:SetWidth(1)
						_G["RecapSelf"..j.."_"..i]:Hide()
					end
					cx = cx + 1
				end
			elseif iOpt and iOpt.width then
				_G["RecapHeader_"..i]:Hide()
			end
		end

		RecapTotals:Hide()
		RecapGroupTotalButton:Hide()
		RecapNonGroupTotalButton:Hide()
		RecapHeader_Name:Hide()
		RecapHeader_EName:Show()

		for i=1,15 do
			_G["RecapList"..i]:Hide()
			_G["RecapRecentList"..i]:Hide()
			_G["RecapSelf"..i]:Show()
			_G["RecapSelf"..i]:SetWidth(cx - rTemp.ScrollAndEdgeWidth + 6) -- extra 6 since it doesn't seem quite wide enough
			_G["RecapRecentSelf"..i.."_Text"]:SetTextColor(unpack(rColor.Green))
			_G["RecapRecentSelf"..i.."_SaveColor"]:SetTextColor(unpack(rColor.Green)) -- saves chosen colour
			if rOpt.RecentData.value then
				_G["RecapRecentSelf"..i]:Enable()
			else
				_G["RecapRecentSelf"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
				_G["RecapRecentSelf"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
				_G["RecapRecentSelf"..i]:Disable()
			end
			_G["RecapRecentSelf"..i]:Show()
		end

	else
		-- general view
		for i in pairs(rOpt) do
			iOpt = rTemp.DefaultOpt[i]
			if iOpt and iOpt.width then
				if rOpt[i].value then
					-- column will appear
					item = _G["RecapHeader_"..i]
					item:SetWidth(iOpt.width)
					item:Show()
					item = _G["RecapTotals_"..i]
					item:SetWidth(iOpt.width)
					item:Show()
					-- Faction and Level always show and hide together
					if i == "Faction" then
						-- split the width (hardcoded numbers)
						item:SetWidth(14)
						subitem = _G["RecapTotals_Level"]
						subitem:SetWidth(18)
						subitem:Show()
					end
					for j=1,15 do
						item = _G["RecapList"..j.."_"..i]
						item:SetWidth(iOpt.width)
						item:Show()
						-- Faction and Level always show and hide together
						if i == "Faction" then
							-- split the width (hardcoded numbers)
							item:SetWidth(14)
							subitem = _G["RecapList"..j.."_Level"]
							subitem:SetWidth(18)
							subitem:Show()
						end
					end
					cx = cx + iOpt.width
				else
					-- column will not appear
					item = _G["RecapHeader_"..i]
					item:SetWidth(1)
					item:Hide()
					-- Ranks, Faction, Class, and Level column fix (see below)
					if (i == "Ranks") or (i == "Faction") or (i == "Class") then
						item:Show()
					end
					-- there is no header for Level
					item = _G["RecapTotals_"..i]
					item:SetWidth(1)
					item:Hide()
					-- Ranks, Faction, Class, and Level column fix (see below)
					if (i == "Ranks") or (i == "Faction") or (i == "Class") then
						item:Show()
					end
					-- Faction and Level always show together
					if i == "Faction" then
						subitem = _G["RecapTotals_Level"]
						subitem:SetWidth(1)
						subitem:Show()
						cx = cx + 1 -- two columns here, not just one
					end
					for j=1,15 do
						item = _G["RecapList"..j.."_"..i]
						item:SetWidth(1)
						item:Hide()
						-- Ranks, Faction, Class, and Level column fix
						--   To fix a display bug these columns always appear, even if
						--   only blank (or transparent black) and one column wide.
						--   See also RecapScrollBar_Update and Recap_ConstructList.
						if (i == "Ranks") or (i == "Faction") or (i == "Class") then
							item:Show()
						end
						-- Faction and Level always show together
						if i == "Faction" then
							subitem = _G["RecapList"..j.."_Level"]
							subitem:SetWidth(1)
							subitem:Show()
						end
					end
					cx = cx + 1
				end
			elseif iOpt and iOpt.ewidth then
				_G["RecapHeader_"..i]:Hide()
			end
		end

		for i=1,15 do
			_G["RecapSelf"..i]:Hide()
			_G["RecapRecentSelf"..i]:Hide()
			_G["RecapList"..i]:Show()
			_G["RecapList"..i]:SetWidth(cx - rTemp.ScrollAndEdgeWidth + 6) -- extra 6 since it doesn't seem quite wide enough
			_G["RecapRecentList"..i.."_Text"]:SetTextColor(_G["RecapList"..i.."_Name"]:GetTextColor())
			_G["RecapRecentList"..i.."_SaveColor"]:SetTextColor(_G["RecapList"..i.."_Name"]:GetTextColor()) -- saves chosen colour
			if rOpt.RecentData.value then
				_G["RecapRecentList"..i]:Enable()
			else
				_G["RecapRecentList"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
				_G["RecapRecentList"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
				_G["RecapRecentList"..i]:Disable()
			end
			_G["RecapRecentList"..i]:Show()
		end

		RecapTotals:Show()
		if not rOpt.LightData.value then
			RecapGroupTotalButton_Text:SetTextColor(unpack(rColor.Green))
			RecapGroupTotalButton:Show()
			RecapNonGroupTotalButton_Text:SetTextColor(unpack(rColor.White))
			RecapNonGroupTotalButton:Show()
		else
			RecapGroupTotalButton:Hide()
			RecapNonGroupTotalButton:Hide()
		end
		RecapHeader_Name:Show()
		RecapHeader_EName:Hide()

	end

	-- the name slot on the Total line is much narrower
	-- see also the offset in Recap.xml
	RecapTotals_Name:SetWidth(rTemp.NameWidth-142) -- (offset)
	RecapTotals:SetWidth(cx-182) -- (offset)

	if rOpt.GrowLeftwards.value and RecapFrame then
		i = RecapFrame:GetRight()
		j = RecapFrame:GetTop()
		if i and j then
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",math_max(i-cx-rTemp.RecentButtonWidth,0),math_max(j,0)) -- *** i not defined sometimes :( **  [ if frame has not been dragged since reloadui ]
		else
			-- default behaviour if any undefined
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("CENTER","UIParent","CENTER")
		end
	end

	RecapTopBar:SetWidth(cx-8+rTemp.RecentButtonWidth)
	RecapBottomBar:SetWidth(cx-16+rTemp.RecentButtonWidth)
	RecapExtraBottomBar:SetWidth(cx-16+rTemp.RecentButtonWidth)
	RecapFrame:SetWidth(cx+rTemp.RecentButtonWidth)
	RecapScrollBar:SetWidth(cx-16+rTemp.RecentButtonWidth)
	RecapTitleButton:SetWidth(cx-8+rTemp.RecentButtonWidth-44-164) -- 44 to avoid status lights and 164 to avoid the various control buttons (offset)

	rTemp.GaugeWidth = cx - rTemp.ScrollAndEdgeWidth - 12 -
						( (not rUser.SelfView) and
						   ((((rOpt.Faction.value and rOpt.Faction.width) or 1) +
							 ((rOpt.Class.value and rOpt.Class.width) or 1) +
							 ((rOpt.Ranks.value and rOpt.Ranks.width) or 1)) or 0) or 0)

	Recap_CheckWindowBounds()
	Recap_SetView()
	if not rUser.Minimized then
		RecapScrollBar_Update()
	end

end

function Recap_ConstructList()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local iLast = rTemp.DisplayLastFight
	local i, entry, overallDuration, thisCombatant, iCombatant, iList, iTotal
	local maxhit = 0
	local dmgin = 0
	local dmgout = 0
	local deaths = 0
	local dispels = 0
	local interrupts = 0
	local rawheal = 0
	local overheal = 0
	local duration = 0
	local durationIn = 0
	local durationHeal = 0
	local overallDPS = 0
	local tempname = nil
	local temptotal = 0

	if rUser.SelfView then
		Recap_ConstructSelf()
	else
		-- remember possible state for Panel
		if rOpt.ShowPanel.value then
			if (rTemp.Selected ~= 0) and (rTemp.Selected ~= rTemp.GroupIndex) and (rTemp.Selected ~= rTemp.NonGroupIndex) then
				tempname = rTemp.List[rTemp.Selected].Name
			else
				temptotal = rTemp.Selected
			end
		end
	end

	if rUser.View=="Last" then
		overallDuration = rUser.LastDuration
	else
		overallDuration = rUser.TotalDuration
	end

	-- clear the 'List' table entirely
	rTemp.ListSize = 1
	rTemp.List = wipe(rTemp.List)

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			if not rTemp.List[rTemp.ListSize] then
				rTemp.List[rTemp.ListSize] = {}
			end
			entry = false

			iList = rTemp.List[rTemp.ListSize]

			-- added heals, so that healers show up from the beginning, rather than only after they have received or given damage
			if ((iCombatant["LastDmgIn_"..iLast]==nil or iCombatant["LastDmgIn_"..iLast]==0) and
				(iCombatant["LastDmgOut_"..iLast]==nil or iCombatant["LastDmgOut_"..iLast]==0) and
				(iCombatant.TotalDmgOut==nil or iCombatant.TotalDmgOut==0) and
				(iCombatant.TotalDmgIn==nil or iCombatant.TotalDmgIn==0) and
				(iCombatant["LastRawHeal_"..iLast]==nil or iCombatant["LastRawHeal_"..iLast]==0) and
				(iCombatant.TotalRawHeal==nil or iCombatant.TotalRawHeal==0)) or
			   (rOpt.HideOthers.value and (not iCombatant.Friend)) or
			   (rOpt.HideGroup.value and (not Recap_CheckForSelf(i)) and iCombatant.Friend) or
			   (rOpt.HideYardTrash.value and not iCombatant.Friend and Recap_CombatantIsTrash(i)) or
			   (iCombatant.Ignore) then
				entry = false -- strip out unwanted combatants

			elseif rUser.View=="Last" and iCombatant.WasInLast then
				if not rOpt.HideZero.value or ((iCombatant["LastTime_"..iLast] and (iCombatant["LastTime_"..iLast] > rTemp.MinTime)) or
													(iCombatant["LastTimeIn_"..iLast] and (iCombatant["LastTimeIn_"..iLast] > rTemp.MinTime)) or
													(iCombatant["LastTimeHeal_"..iLast] and (iCombatant["LastTimeHeal_"..iLast] > rTemp.MinTime))) then
					iList.Name = i
					iList.Seen = (iCombatant.Seen or 0)
					iList.Time = (iCombatant["LastTime_"..iLast] or 0)
					iList.TimeIn = (iCombatant["LastTimeIn_"..iLast] or 0)
					iList.TimeHeal = (iCombatant["LastTimeHeal_"..iLast] or 0)
					iList.MaxHit = (iCombatant["LastMaxHit_"..iLast] or 0)
					iList.DmgIn = (iCombatant["LastDmgIn_"..iLast] or 0)
					iList.DmgOut = (iCombatant["LastDmgOut_"..iLast] or 0)
					iList.HPS = (iCombatant["LastHPS_"..iLast] or 0)
					iList.DPSIn = (iCombatant["LastDPSIn_"..iLast] or 0)
					iList.DPS = (iCombatant["LastDPS_"..iLast] or 0)
					-- one hidden variable
					iList.GearValue = iCombatant["LastGearValue_"..iLast]
					if iList.GearValue and (iList.GearValue > 0) then
						iList.DPSPerGear = Recap_Div0(10000 * iList.DPS, iList.GearValue)
					else
						iList.DPSPerGear = 0
					end
					iList.DPSvsAll = (overallDuration>rTemp.MinTime and Recap_Div1((iCombatant["LastDmgOut_"..iLast] or 0), overallDuration)) or 0
					iList.Deaths = (iCombatant["LastDeaths_"..iLast] or 0)
					iList.Dispels = (iCombatant["LastDispels_"..iLast] or 0)
					iList.Interrupts = (iCombatant["LastInterrupts_"..iLast] or 0)
					-- two hidden variables
					iList.RawHeal = (iCombatant["LastRawHeal_"..iLast] or 0)
					iList.OverHeal = (iCombatant["LastOverHeal_"..iLast] or 0)
					-- calculated rather than assigned
					iList.Heal = (iCombatant["LastRawHeal_"..iLast] or 0) - (iCombatant["LastOverHeal_"..iLast] or 0)
					if iList.RawHeal > 0 then
						iList.Over = Recap_Div0(100*iList.OverHeal,iList.RawHeal)
					else
						iList.Over = 0
					end
					entry = true
				end

			elseif rUser.View=="All" then
				if not rOpt.HideZero.value or ((iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime)) or
													(iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime)) or
													(iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime))) then
					iList.Name = i
					iList.Seen = (iCombatant.Seen or 0)
					iList.Time = (iCombatant.TotalTime or 0)
					iList.TimeIn = (iCombatant.TotalTimeIn or 0)
					iList.TimeHeal = (iCombatant.TotalTimeHeal or 0)
					iList.MaxHit = (iCombatant.TotalMaxHit or 0)
					iList.DmgIn = (iCombatant.TotalDmgIn or 0)
					iList.DmgOut = (iCombatant.TotalDmgOut or 0)
					iList.HPS = (iCombatant.TotalHPS or 0)
					iList.DPSIn = (iCombatant.TotalDPSIn or 0)
					iList.DPS = (iCombatant.TotalDPS or 0)
					-- one hidden variable
					iList.GearValue = iCombatant.GearValue
					if iList.GearValue and (iList.GearValue > 0) then
						iList.DPSPerGear = Recap_Div0(10000 * iList.DPS, iList.GearValue)
					else
						iList.DPSPerGear = 0
					end
					iList.DPSvsAll = (overallDuration>rTemp.MinTime and Recap_Div1((iCombatant.TotalDmgOut or 0), overallDuration)) or 0
					iList.Deaths = (iCombatant.TotalDeaths or 0)
					iList.Dispels = (iCombatant.TotalDispels or 0)
					iList.Interrupts = (iCombatant.TotalInterrupts or 0)
					-- two hidden variables
					iList.RawHeal = (iCombatant.TotalRawHeal or 0)
					iList.OverHeal = (iCombatant.TotalOverHeal or 0)
					-- calculated rather than assigned
					iList.Heal = (iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)
					if iList.RawHeal > 0 then
						iList.Over = Recap_Div0(100*iList.OverHeal, iList.RawHeal)
					else
						iList.Over = 0
					end
					entry = true
				end
			end

			if entry then
				thisCombatant = iList.Name
				if thisCombatant and rCombatants[thisCombatant] and rCombatants[thisCombatant].Friend then
					duration = duration + iList.Time
					durationIn = durationIn + iList.TimeIn
					durationHeal = durationHeal + iList.TimeHeal
					if iList.MaxHit > maxhit then
						maxhit = iList.MaxHit
					end
					dmgin = dmgin + iList.DmgIn
					dmgout = dmgout + iList.DmgOut
					deaths = deaths + iList.Deaths
					dispels = dispels + iList.Dispels
					interrupts = interrupts + iList.Interrupts
					-- two hidden variables
					rawheal = rawheal + iList.RawHeal
					overheal = overheal + iList.OverHeal
					overallDPS = overallDPS + iList.DPS
				end
				rTemp.ListSize = rTemp.ListSize + 1
			end
		end
	end

	if not rTemp.List[rTemp.ListSize] then
		rTemp.List[rTemp.ListSize] = {}
	end

	-- the final entry is the totals
	iTotal = rTemp.List[rTemp.ListSize]
	iTotal.Name = rLocalize.Totals
	iTotal.Time = duration
	RecapTotals_Time:SetText(Recap_FormatTime(duration))
	iTotal.TimeIn = durationIn
	RecapTotals_TimeIn:SetText(Recap_FormatTime(durationIn))
	iTotal.TimeHeal = durationHeal
	RecapTotals_TimeHeal:SetText(Recap_FormatTime(durationHeal))
	iTotal.MaxHit = maxhit
	RecapTotals_MaxHit:SetText(maxhit)
	iTotal.DmgIn = dmgin
	RecapTotals_DmgIn:SetText(dmgin)
	iTotal.DmgOut = dmgout
	RecapTotals_DmgOut:SetText(dmgout)
	iTotal.Deaths = deaths
	RecapTotals_Deaths:SetText(deaths)
	iTotal.Dispels = dispels
	RecapTotals_Dispels:SetText(dispels)
	iTotal.Interrupts = interrupts
	RecapTotals_Interrupts:SetText(interrupts)
	-- two hidden variables
	iTotal.RawHeal = rawheal
	iTotal.OverHeal = overheal
	-- calculated rather than assigned
	iTotal.Heal = rawheal - overheal
	RecapTotals_Heal:SetText(rawheal - overheal)
	if (iTotal.RawHeal > 0) then
		iTotal.Over = Recap_Div0(100*iTotal.OverHeal,iTotal.RawHeal)
	else
		iTotal.Over = 0
	end
	RecapTotals_Over:SetFormattedText("%d%%",Recap_Round0(iTotal.Over))

	-- three calculations of total group DPS, DPS In, and HPS
	if duration > rTemp.MinTime then
		iTotal.TotDPSOut = Recap_Div1(dmgout,duration)
	else
		iTotal.TotDPSOut = 0
	end
	if durationIn > rTemp.MinTime then
		iTotal.TotDPSIn = Recap_Div1(dmgin,durationIn)
	else
		iTotal.TotDPSIn = 0
	end
	if durationHeal > rTemp.MinTime then
		iTotal.TotHPS = Recap_Div1((rawheal - overheal),durationHeal)
	else
		iTotal.TotHPS = 0
	end

	if iTotal.TotHPS<1000 then
		RecapTotals_HPS:SetFormattedText("%.1f",iTotal.TotHPS)
	else
		RecapTotals_HPS:SetFormattedText("%d",Recap_Round0(iTotal.TotHPS))
	end
	if iTotal.TotDPSIn<1000 then
		RecapTotals_DPSIn:SetFormattedText("%.1f",iTotal.TotDPSIn)
	else
		RecapTotals_DPSIn:SetFormattedText("%d",Recap_Round0(iTotal.TotDPSIn))
	end
	if iTotal.TotDPSOut<1000 then
		RecapTotals_DPS:SetFormattedText("%.1f",iTotal.TotDPSOut)
	else
		RecapTotals_DPS:SetFormattedText("%d",Recap_Round0(iTotal.TotDPSOut))
	end
	RecapTotals_DPSPerGear:SetText("")
	if iTotal.TotDPSOut<1000 then
		RecapTotals_DPSvsAll:SetFormattedText("%.1f",iTotal.TotDPSOut)
	else
		RecapTotals_DPSvsAll:SetFormattedText("%d",Recap_Round0(iTotal.TotDPSOut))
	end

	-- Class column fix set to black, see also RecapScrollBar_Update and Recap_SetColumns.
	RecapTotals_Class:SetTexCoord(.9,1,.9,1)

	-- calculate percentages
	for i=1,rTemp.ListSize-1 do
		iList = rTemp.List[i]
		iList.HealP = 0
		iList.DmgInP = 0
		iList.DmgOutP = 0
		thisCombatant = iList.Name
		if thisCombatant and rCombatants[thisCombatant] and rCombatants[thisCombatant].Friend then
			if iTotal.Heal>0 then
				iList.HealP = Recap_Div0(100*iList.Heal,iTotal.Heal)
			end
			if iTotal.DmgIn>0 then
				iList.DmgInP = Recap_Div0(100*iList.DmgIn,iTotal.DmgIn)
			end
			if iTotal.DmgOut>0 then
				-- give this column an extra digit of significance
				iList.DmgOutP = Recap_Div1(100*iList.DmgOut,iTotal.DmgOut)
			end
		end
	end

	-- two hidden variables for total line only
	iTotal.OverallDuration = overallDuration
	iTotal.OverallDPS = overallDPS

	Recap_SortList()

	-- restore Panel state if possible
	if rOpt.ShowPanel.value then
		if tempname then
			rTemp.Selected = Recap_GetSelectedByName(tempname)
		else
			rTemp.Selected = temptotal
		end
		if (rTemp.PanelSource == "Main") then
			if (rTemp.Selected == 0) then
				-- Panel not valid, make sure it goes away
				RecapPanel_Hide()
			elseif (rTemp.Selected == rTemp.GroupIndex) then
				-- show Group total panel
				Recap_ClearGrandTotal(rTemp.GroupTotal)
				Recap_DoGrandTotal(rTemp.GroupTotal)
				RecapPanel_Show(rTemp.GroupTotal)
			elseif (rTemp.Selected == rTemp.NonGroupIndex) then
				-- show Non-Group total panel
				Recap_ClearGrandTotal(rTemp.NonGroupTotal)
				Recap_DoGrandTotal(rTemp.NonGroupTotal)
				RecapPanel_Show(rTemp.NonGroupTotal)
			else
				-- show combatant panel
				RecapPanel_Show(tempname)
			end
		else
			-- Panel was not for us, do nothing
		end
	end

	if not rUser.Minimized then
		RecapScrollBar_Update()
	end

end


--[[ Window movement functions ]]

function Recap_OnMouseDown(frame, button)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") and not rUser.Pinned then
		RecapFrame:StartMoving()
	end
end

function Recap_OnMouseUp(frame, button)
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if rTemp.Loaded then
		if (button == "LeftButton") and not rUser.Pinned then
			RecapFrame:StopMovingOrSizing()
			Recap_CheckWindowBounds()

		elseif (button == "RightButton") and not IsShiftKeyDown() and rUser.Minimized then
			Recap_CreateMenu(frame, rLocalize.MinMenu, nil, nil)
		end
	end
end


--[[ Dialog control functions ]]

function Recap_ButtonAction(frame, myType) -- clicks on buttons

	local rSet = _G.recap_set
	local rIgnore = _G.recap_ignore
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i
	local filen = RecapSetEditBox:GetText()
	local spellID = RecapIgnoresEditBox:GetText()
	local spellName

	if not rTemp.Loaded then
		return
	end

	PlaySound("GAMEGENERICBUTTONPRESS")

	if myType=="Close" then
		RecapFrame_Hide()

	elseif myType=="Minimize" then

		if rUser.Minimized then
			Recap_Maximize()
		else
			Recap_Minimize()
		end
		RecapFrame:SetAlpha(1)
		rTemp.FadeTimer = -1
		Recap_SetButtons()
		Recap_Tooltip(frame, "Minimize")

	elseif myType=="Pin" then
		rUser.Pinned = not rUser.Pinned
		Recap_SetButtons()
		Recap_Tooltip(frame, "Pin")

	elseif myType=="Pause" then
		Recap_PauseResume()
		Recap_Tooltip(frame, "Pause")

	elseif myType=="ShowAll" then
		if rUser.SelfView then
			rUser.SelfView = false
			RecapPanel_Hide(1)
			RecapRecent_Hide(1)
			Recap_SetColumns() -- this calls SetView which in turn calls ConstructList
		else
			Recap_ToggleView()
		end
		-- display live dps and hps numbers
		Recap_DisplayMinimizedDPS() -- also sends to plugins
		Recap_Tooltip(frame, "ShowAll")

	elseif myType=="Options" then
		if RecapOptFrame:IsShown() then
			RecapOptFrame:Hide()
		else
			RecapOptFrame:Show()
			Recap_SetSyncDisplay()
		end

	elseif myType=="Reset" then

		if rUser.SelfView then
			Recap_ResetSelfPlayerAndPets()
			Recap_SetView()

		elseif rUser.View=="All" then
			if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				if rUser.SyncState == "Leader" then
					-- for a leader, treat this as a restart sync (with existing value for merge pets)
					Recap_StartSync(rUser.SyncMergePets)
					print(rTemp.Recap, RECAP_SYNCHRONIZATION_RESET)
				else
					-- for a member, ignore if in synchronization
					PlaySound("igQuestFailed")
					Recap_WarnNotAllowedDuringSync()
				end
			else
				-- wipe everything --
				RecapPanel_Hide(1)
				RecapRecent_Hide(1)
				RecapLoad_Hide()
				Recap_ResetAllCombatants(false)
				RecapGraph_InitializeLiveLists()
				Recap_MakeFriends(true)
				Recap_SetView()
			end

		elseif rUser.View=="Last" then
			if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				-- ignore if in synchronization
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			else
				StaticPopupDialogs["rTemp.CONFIRMLASTRESET"] = {
					text = rLocalize.ConfirmLastReset,
					button1 = ACCEPT,
					button2 = CANCEL,
					button3 = BINDING_NAME_RECAP_RESET_ALL,
					OnAccept = function(self)
						-- SUBTRACT the last fight --
						for i in pairs(rCombatants) do
							if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
								if rCombatants[i].WasInLast then
									Recap_ResetLastFight(i)
								end
							end
						end
						rUser.TotalDuration = rUser.TotalDuration - rUser.LastDuration
						rUser.LastDuration = 0
						rUser.TotalDurationIn = rUser.TotalDurationIn - rUser.LastDurationIn
						rUser.LastDurationIn = 0
						rUser.TotalDurationHeal = rUser.TotalDurationHeal - rUser.LastDurationHeal
						rUser.LastDurationHeal = 0
						Recap_SetView()
					end,
					OnAlt = function(self)
						-- reset all fights option (button is disabled for a member of a synchronization)
						if rUser.SyncState == "Leader" then
							-- for a leader, treat this as a restart sync (with existing value for merge pets)
							Recap_StartSync(rUser.SyncMergePets)
							print(rTemp.Recap, RECAP_SYNCHRONIZATION_RESET)
						else
							-- wipe everything --
							RecapPanel_Hide(1)
							RecapRecent_Hide(1)
							RecapLoad_Hide()
							Recap_ResetAllCombatants(false)
							RecapGraph_InitializeLiveLists()
							Recap_MakeFriends(true)
							Recap_SetView()
						end
					end,
					OnShow = function(self)
						if (rUser.SyncState == "Member") then
							-- synchronization member may not reset all fights
							button3:Disable()
						end
					end,
					OnHide = function(self)
					end,
					OnCancel = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMLASTRESET")
			end
		end

	elseif myType=="SaveAllSet" then
		RecapSetEditBox:ClearFocus()
		if filen and filen~="" then
			filen = string_gsub(filen,"\"","'") -- convert " to '
			filen = string_gsub(filen,"%[","(") -- convert [ to (
			filen = string_gsub(filen,"%]",")") -- convert ] to )
		end
		RecapSetEditBox:SetText("")
		if (recap_user.State == "Idle") or (recap_user.State == "Stopped") then
			-- can only do a save if idle or stopped
			if recap_temp.FlagSavePhase or InCombatLockdown() then
				-- skip if already doing a save, or in combat according to Blizzard
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.SAVEALLBLOCKED"] = {
					text = rLocalize.NotAllowedDuringCombat,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.SAVEALLBLOCKED")
			else
				PlaySound("GnomeExploration")
				-- schedule a save of all fights, to begin on the next tick
				recap_temp.FlagSavePhase = 1
				recap_temp.FlagSaveLastOnly = false
				recap_temp.FlagSaveSetName = filen
				recap_temp.FlagSavePriorState = recap_user.State
				Recap_SetState("Stopped")
			end
		end

	-- function to save only the Last Fight data set
	elseif myType=="SaveLastSet" then
		RecapSetEditBox:ClearFocus()
		if filen and filen~="" then
			filen = string_gsub(filen,"\"","'") -- convert " to '
			filen = string_gsub(filen,"%[","(") -- convert [ to (
			filen = string_gsub(filen,"%]",")") -- convert ] to )
		end
		RecapSetEditBox:SetText("")
		if (recap_user.State == "Idle") or (recap_user.State == "Stopped") then
			-- can only do a save if idle or stopped
			if recap_temp.FlagSavePhase or InCombatLockdown() then
				-- skip if already doing a save, or in combat according to Blizzard
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.SAVELASTBLOCKED"] = {
					text = rLocalize.NotAllowedDuringCombat,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.SAVELASTBLOCKED")
			else
				PlaySound("GnomeExploration")
				-- schedule a save of all fights, to begin on the next tick
				recap_temp.FlagSavePhase = 1
				recap_temp.FlagSaveLastOnly = true
				recap_temp.FlagSaveSetName = filen
				recap_temp.FlagSavePriorState = recap_user.State
				Recap_SetState("Stopped")
			end
		end

	elseif myType=="LoadSet" then
		if filen and filen ~= "" and rSet[filen] then
			PlaySound("GAMEGENERICBUTTONPRESS")
			RecapSetEditBox:SetText("")
			RecapSetEditBox:ClearFocus()
			rTemp.OutgoingDetailSelected = 0
			rTemp.IncomingDetailSelected = 0
			rTemp.OtherDetailSelected = 0
			rTemp.Selected = 0
			rTemp.LoadSelected = 0
			rTemp.RecentSelected = 0
			rTemp.PanelRecentSelected = 0
			rTemp.FightSetSelected = 0
			rTemp.FightSetSelectedOther = 0
			RecapFightSetsScrollBar_Update()
			Recap_LoadCombatantsCore(filen) -- core only, no details, to reduce time outs
			rTemp.LoadedDataSet = filen
			rTemp.LoadedDetails = false -- no details loaded yet
			RecapPanel_Hide(1) -- keep this 'hide' so that Recap_LoadCombatantsDetails is not triggered right away
			RecapRecent_Hide(1)
			RecapLoad_Show()
			-- following not localized
			print("Recap loaded Data Set: '"..filen.."'"..((rSet[filen].MergePets and " ("..rLocalize.MergePetsOn..")") or "")..((rSet[filen].IgnoreGUIDs and " ("..rLocalize.IgnoreGUIDsOn..")") or ""))
		end

	elseif myType=="LoadSetIntoAllFights" then
		if filen and filen ~= "" and rSet[filen] then
			if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				-- ignore if in synchronization
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			else
				StaticPopupDialogs["rTemp.CONFIRMLOADOVERWRITE"] = {
					text = rLocalize.ConfirmLoadIntoAllFights,
					button1 = ACCEPT,
					button2 = CANCEL,
					OnAccept = function(self)
						RecapSetEditBox:SetText("")
						RecapSetEditBox:ClearFocus()
						rTemp.OutgoingDetailSelected = 0
						rTemp.IncomingDetailSelected = 0
						rTemp.OtherDetailSelected = 0
						rTemp.Selected = 0
						rTemp.RecentSelected = 0
						rTemp.PanelRecentSelected = 0
						rTemp.FightSetSelected = 0
						rTemp.FightSetSelectedOther = 0
						RecapFightSetsScrollBar_Update()
						Recap_LoadCombatantsToAllFights(filen) -- this is not yet split into core and details
						Recap_MakeFriends(false) -- do not overwrite saved gear values -- if combat takes place an overwrite will occur
						rUser.View = "All"
						Recap_SetView()
						RecapPanel_Hide(1)
						RecapRecent_Hide(1)
						RecapLoad_Hide()
						-- following not localized
						print("Recap loaded Data Set: '"..filen.."'"..((rSet[filen].MergePets and " ("..rLocalize.MergePetsOn..")") or "")..((rSet[filen].IgnoreGUIDs and " ("..rLocalize.IgnoreGUIDsOn..")") or ""))
					end,
					OnHide = function(self)
					end,
					OnCancel = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMLOADOVERWRITE")
			end
		end

	elseif myType=="DeleteSet" then
		StaticPopupDialogs["rTemp.CONFIRMDELETEONE"] = {
			text = rLocalize.ConfirmDeleteFightDataSet,
			button1 = ACCEPT,
			button2 = CANCEL,
			OnAccept = function(self)
				if not RecapOptSubFrame3:IsVisible() then
					-- will fail if Options / Data Sets has been closed
					PlaySound("igQuestFailed")
				else
					RecapSetEditBox:SetText("")
					RecapSetEditBox:ClearFocus()
					Recap_DeleteSomeFightDataSets()
					Recap_BuildFightSets()
					rTemp.FightSetSelected = 0
					rTemp.FightSetSelectedOther = 0
					RecapFightSetsScrollBar_Update()
				end
			end,
			OnHide = function(self)
			end,
			OnCancel = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.CONFIRMDELETEONE")

	elseif myType=="DeleteAllSets" then
		StaticPopupDialogs["rTemp.CONFIRMDELETEALL"] = {
			text = rLocalize.ConfirmDeleteAllFightDataSets,
			button1 = ACCEPT,
			button2 = CANCEL,
			OnAccept = function(self)
				if not RecapOptSubFrame3:IsVisible() then
					-- will fail if Options / Data Sets has been closed
					PlaySound("igQuestFailed")
				else
					RecapSetEditBox:SetText("")
					RecapSetEditBox:ClearFocus()
					Recap_DeleteAllFightDataSets()
					Recap_BuildFightSets()
					rTemp.FightSetSelected = 0
					rTemp.FightSetSelectedOther = 0
					RecapFightSetsScrollBar_Update()
				end
			end,
			OnHide = function(self)
			end,
			OnCancel = function(self)
			end,
			timeout = 30,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.CONFIRMDELETEALL")

	elseif myType=="RenameSet" then
		local oldName, newName
		oldName = RecapSetEditBox:GetText()
		StaticPopupDialogs["rTemp.CONFIRMRENAMESET"] = {
			text = rLocalize.ConfirmRenameFightDataSet,
			button1 = ACCEPT,
			button2 = CANCEL,
			OnAccept = function(self)
				newName = self.editBox:GetText()
				self.editBox:SetText("") -- need to clear this because it can get reused by other mods
				if not newName or (newName == "") or rSet[newName] then
					-- already exists (or is blank)
					PlaySound("igQuestFailed")
					StaticPopupDialogs["rTemp.NAMEALREADYEXISTS"] = {
						text = rLocalize.DataSetNameAlreadyExists,
						button1 = OKAY,
						OnAccept = function(self)
						end,
						timeout = 30,
						showAlert = 1,
						whileDead = 1
					}
					StaticPopup_Show("rTemp.NAMEALREADYEXISTS")
				else
					-- copy the Data Set to the new name, then delete the old Data Set
					local i, j, k, m, iNewSet, iOldSet
					rSet[newName] = {}
					iNewSet = rSet[newName]
					iOldSet = rSet[oldName]
					for i in pairs(iOldSet) do
						if type(iOldSet[i]) == "table" then -- currently the only table at this level is Combatant
							iNewSet[i] = {}
							for j in pairs(iOldSet[i]) do -- iterating over Combatant, all entries are tables
								iNewSet[i][j] = {}
								for k in pairs(iOldSet[i][j]) do -- iterating over Base, In, Out, Source, Target, Other
									if type(iOldSet[i][j][k]) == "table" then -- only if strings have had to be split
										iNewSet[i][j][k] = {}
										for m in pairs(iOldSet[i][j][k]) do -- iterating over split strings
											iNewSet[i][j][k][m] = iOldSet[i][j][k][m]
										end
									else
										-- most cases have single strings
										iNewSet[i][j][k] = iOldSet[i][j][k]
									end
								end
							end
						else
							iNewSet[i] = iOldSet[i]
						end
					end
					rSet[oldName] = nil -- keep as nil
					-- cleanup
					RecapSetEditBox:SetText("")
					RecapSetEditBox:ClearFocus()
					Recap_BuildFightSets()
					rTemp.FightSetSelected = 0
					rTemp.FightSetSelectedOther = 0
					RecapFightSetsScrollBar_Update()
				end
			end,
			OnShow = function(self)
				self.editBox:SetText(oldName)
				self.editBox:SetCursorPosition(0)
				self.editBox:ClearFocus()
			end,
			OnHide = function(self)
			end,
			OnCancel = function(self)
			end,
			hasEditBox = 1,
			timeout = 0,
			showAlert = 1,
			whileDead = 1
		}
		StaticPopup_Show("rTemp.CONFIRMRENAMESET")

	elseif myType=="SelfView" then
		rUser.SelfView = not rUser.SelfView
		if rUser.SelfView then
		else
			if rUser.View=="All" then
				rUser.View = "All"
			else
				rUser.View = "Last"
			end
		end
		RecapPanel_Hide(1)
		RecapRecent_Hide(1)
		Recap_SetColumns() -- this calls SetView which in turn calls ConstructList
		-- display live dps and hps numbers
		Recap_DisplayMinimizedDPS() -- also sends to plugins
		Recap_Tooltip(frame, "SelfView")

	elseif myType=="AddIgnore" then
		local recognized = false
		if spellID and (spellID ~= "") then
			spellID = string_gsub(spellID,"[^%d]","") -- remove any non-digit
			-- convert to a number
			spellID = tonumber(spellID)
			spellName = GetSpellInfo(spellID)
			if spellName and (spellName ~= "") then
				if (rIgnore[spellID] == nil) then
					rIgnore[spellID] = {}
				end
				rIgnore[spellID].SpellName = spellName
				recognized = true
			end
		end
		if (recognized == false) then
			PlaySound("igQuestFailed")
			StaticPopupDialogs["rTemp.SPELLIDNOTRECOGNIZED"] = {
				text = rLocalize.SpellIDNotRecognized,
				button1 = OKAY,
				OnAccept = function(self)
				end,
				timeout = 30,
				showAlert = 1,
				whileDead = 1
			}
			StaticPopup_Show("rTemp.SPELLIDNOTRECOGNIZED")
		end
		RecapIgnoresEditBox:SetText("")
		RecapIgnoresEditBox:ClearFocus()
		Recap_BuildIgnores()
		rTemp.IgnoreSelected = 0
		RecapIgnoresScrollBar_Update()

	elseif myType=="RemoveIgnore" then
		spellID = tonumber(spellID)
		rIgnore[spellID] = nil -- keep as nil
		RecapIgnoresEditBox:SetText("")
		RecapIgnoresEditBox:ClearFocus()
		Recap_BuildIgnores()
		rTemp.IgnoreSelected = 0
		RecapIgnoresScrollBar_Update()

	elseif myType=="AddSuggestedIgnores" then
		-- for each Recap suggested ignore, add if not already present
		for spellID in pairs(rTemp.SuggestedIgnores) do
			spellID = tonumber(spellID)
			spellName = GetSpellInfo(spellID)
			if spellName and (spellName ~= "") then
				if (rIgnore[spellID] == nil) then
					rIgnore[spellID] = {}
					print(rTemp.Recap..":", RECAP_ADD, RECAP_IGNORES, spellID, "=", spellName)
				end
				rIgnore[spellID].SpellName = spellName -- overwrites/updates existing name
			else
				-- skip without message if we can't find a spellName
			end
		end
		RecapIgnoresEditBox:SetText("")
		RecapIgnoresEditBox:ClearFocus()
		Recap_BuildIgnores()
		rTemp.IgnoreSelected = 0
		RecapIgnoresScrollBar_Update()

	elseif myType=="RecentEvents" then
		if rOpt.RecentData.value and rTemp.Recent then
			if RecapRecent:IsVisible() and (rTemp.RecentSource == "Events") then
				PlaySound("GAMEGENERICBUTTONPRESS")
				RecapRecent:Hide()
			else
				rTemp.Selected = 0
				RecapPanel_Hide()
				RecapRecent:Hide()
				-- show all recent events including dispels and interrupts
				RecapRecent_PopulateAll(nil)
				RecapRecent:Show()
			end
		else
			print(RECAP_RECAP..": "..rLocalize.RecentDataModeNotEnabled)
			PlaySound("igQuestFailed")
		end

	elseif myType=="RecentDispelsAndInterrupts" then
		if rOpt.RecentData.value and rTemp.Recent then
			if RecapRecent:IsVisible() and (rTemp.RecentSource == "DIEvents") then
				PlaySound("GAMEGENERICBUTTONPRESS")
				RecapRecent:Hide()
			else
				rTemp.Selected = 0
				RecapPanel_Hide()
				RecapRecent:Hide()
				-- show all dispels (which includes breaking crowd control) and interrupts
				RecapRecent_PopulateAll(true)
				RecapRecent:Show()
			end
		else
			print(RECAP_RECAP..": "..rLocalize.RecentDataModeNotEnabled)
			PlaySound("igQuestFailed")
		end

	elseif myType=="RecentDeaths" then
		if rOpt.RecentData.value and rTemp.Recent then
			if RecapRecent:IsVisible() and (rTemp.RecentSource == "Deaths") then
				PlaySound("GAMEGENERICBUTTONPRESS")
				RecapRecent:Hide()
			else
				rTemp.Selected = 0
				RecapPanel_Hide()
				RecapRecent:Hide()
				-- show all deaths
				RecapRecent_PopulateDeaths(true)
				RecapRecent:Show()
			end
		else
			print(RECAP_RECAP..": "..rLocalize.RecentDataModeNotEnabled)
			PlaySound("igQuestFailed")
		end

	elseif myType=="LiveGraphAndText" then
		if rOpt.LiveData.value then
			if RecapGraph:IsVisible() then
				PlaySound("GAMEGENERICBUTTONPRESS")
				RecapGraph_Close()
			else
				if (recapLineGraph == nil) or (recapLineGraphPanel == nil) then
					Recap_EnableGraph()
				end
				if (rTemp.Graph.BinsInitialized == false) then
					RecapGraph_InitializeLiveLists()
				else
					RecapGraph_UpdateLiveLists()
				end
				RecapGraph_GraphUpdate()
			end
		else
			print(RECAP_RECAP..": "..rLocalize.LiveDataModeNotEnabled)
			PlaySound("igQuestFailed")
		end
	end
end

function Recap_PauseResume()
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rUser.State=="Stopped" then
		if rTemp.FlagSavePhase then
			-- ignore if doing a save
			PlaySound("igQuestFailed")
		else
			-- resuming
			Recap_ClearAsIfEndOfFight()
			Recap_SetState("Idle")
			if (rUser.SyncState == "Leader") then
				-- ask other synchronization members to resume
				Recap_SendResumeAll()
			end
		end
	else
		-- pausing (as of 4.29 one can pause while in synchronization)
--print("(Recap) EndFight due to pause button click, or equivalent")
		Recap_EndFight(true)
		if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
			-- hostile boss present, schedule a save of the last fight, to begin on the next tick
			rTemp.FlagSavePhase = 1
			rTemp.FlagSaveLastOnly = true
			rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
			rTemp.BossList = ""
			rTemp.FlagSavePriorState = "Stopped"
		end
		Recap_SetState("Stopped")
		-- update live numbers
		Recap_UpdateMinimizedDPS()
		Recap_DisplayMinimizedDPS()
		if (rUser.SyncState == "Leader") then
			-- ask other synchronization members to pause
			Recap_SendPauseAll()
		end
	end
	Recap_SetButtons()
end

function Recap_PrecautionaryCleanup()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i

	rTemp.SkipPeriodicUpdate = true -- skip periodic update for the duration
	rUser.State = "Stopped" -- suspend logging to calculate

	-- clear boss list
	rTemp.BossList = ""

	Recap_MakeFriends(true)

	-- update the maximum instance difficulty (if in an instance)
	if IsInInstance() then
		rTemp.InstanceDifficulty = Recap_GetInstanceDifficulty()
	else
		-- not in an instance, call it "Other"
		rTemp.InstanceDifficulty = 15
	end

	-- clear WasInLast values
	for i in pairs(rCombatants) do
		rCombatants[i].WasInLast = false
	end

	-- clear temporaries
	rTemp.FightStart = 0
	rTemp.FightEnd = 0
	rTemp.FightStartIn = 0
	rTemp.FightEndIn = 0
	rTemp.FightStartHeal = 0
	rTemp.FightEndHeal = 0

	-- for once-only stuff during StartFight
	rTemp.ResetWasInCurrent = false

	Recap_ClearAsIfEndOfFight()

	-- one additional timer not already covered
	rTemp.EndSyncDelayTimer = -1

	Recap_SetState("Idle")

	if not rUser.Minimized then
		-- don't construct a list if minimized
		Recap_ConstructList()
	end
	Recap_TitleBar()
	RecapHeader_Name:SetText((rTemp.ListSize-1).." "..rLocalize.Combatants)
	Recap_SetTitleBackground()

	if rOpt.AutoHide.value and not rUser.Minimized then
		RecapFrame_Show()
		if rOpt.AutoFade.value then
			rTemp.FadeTimer = 0
		end
	end

	rTemp.SkipPeriodicUpdate = false -- resume periodic update
end

-- legacy call, called *only* by plugins -- DO NOT change the name of this -- also do not change the values of the myType parameter to Recap_ButtonAction
function Recap_OnClick(myType)
	Recap_ButtonAction(RecapFrame, myType)
end

function RecapHeader_OnEnter(frame)

	local line1,line2

	local header=string_gsub(frame:GetName(),"RecapHeader_","Header")

	-- tooltip for main Fights panel column headers has an extra hint (compared to Load fights panel)
	if (header == "HeaderName") then
		line1,line2 = Recap_GetTooltip("Name")
		if line1 and line2 then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostMenuAltTooltip)
		end
	else
		line1,line2 = Recap_GetTooltip(header)
		if line1 and line2 then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostMenuAltTooltip)
		end
	end
end

function RecapMinimizedHeader_OnEnter(frame, header)

	local line1,line2 = Recap_GetTooltip(header)
	if line1 and line2 then
		Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.MinimizedTooltip)
	end
end

function RecapHeader_OnMouseUp(frame, button)

	if (button == "RightButton") and not IsShiftKeyDown() then
		Recap_CreateMenu(frame, rLocalize.ColumnMenu, nil, nil)
	end
end

-- sort column, toggle dir for new headers, name=ascending, rest=descending
function RecapHeader_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local text = ""
	local header = string_gsub(frame:GetName(),"RecapHeader_","")

	if not IsShiftKeyDown() then
		if rUser.SortBy==string_gsub(header,"P$","") then
			rUser.SortDir = not rUser.SortDir
		else
			rUser.SortBy = string_gsub(header,"P$","")
			if header=="Name" then
				rUser.SortDir = true
			else
				rUser.SortDir = false
			end
		end
		Recap_SortList()
		RecapPanel_Hide()
		RecapScrollBar_Update()

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and rTemp.ListSize>1 then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rUser.SortBy = header
		if header=="Name" then
			rUser.SortDir = true
		else
			rUser.SortDir = false
		end
		Recap_SortList()
		RecapPanel_Hide()
		RecapScrollBar_Update()
		Recap_PostSpamRows(header, nil, true)

	elseif IsShiftKeyDown() and IsAltKeyDown() and rTemp.ListSize>1 then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rUser.SortBy = header
		if header=="Name" then
			rUser.SortDir = true
		else
			rUser.SortDir = false
		end
		Recap_SortList()
		RecapPanel_Hide()
		RecapScrollBar_Update()
		Recap_PostSpamRows(header, nil, false)

	elseif IsShiftKeyDown() then
		local editBox = ChatEdit_GetActiveWindow()
		if not editBox then
			-- short help message
			print(rLocalize.RankUsage)
		end
	end

end

function Recap_List_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local id, index, thisCombatant

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapScrollBar)

	if (index < rTemp.ListSize) then
		thisCombatant = rTemp.List[index].Name
		rTemp.OutgoingDetailSelected = 0
		rTemp.IncomingDetailSelected = 0
		rTemp.OtherDetailSelected = 0
		rTemp.PanelRecentSelected = 0

		if (rTemp.LoadSelected ~= 0) then
			local id2
			id2 = rTemp.LoadSelected - FauxScrollFrame_GetOffset(RecapLoadScrollBar)
			if (id2 >= 1) and (id2 <= 15) then
				-- only unlock the other highlight if it is visible
				_G["RecapLoadList"..id2]:UnlockHighlight()
			end
			rTemp.LoadSelected = 0
		end

		if (rTemp.Selected == index) then
			rTemp.Selected = 0
			rTemp.RecentSelected = 0
			_G["RecapList"..id]:UnlockHighlight()
			RecapPanel_Hide()
		else
			rTemp.Selected = index
			RecapScrollBar_Update()
			rTemp.PanelSource = "Main"
			RecapPanel_Show(thisCombatant)
		end

		-- detect double-click
		local isDoubleClick = false
		local thisClickTime = GetTime()
		if (thisCombatant == rTemp.CombatantPriorCombatant) then
			-- another click on the same Combatant
			if (thisClickTime - rTemp.CombatantPriorClickTime) < 0.3 then
				-- two clicks on the same Combatant within less than 0.3 seconds, call it a double-click
				isDoubleClick = true
			end
		end
		rTemp.CombatantPriorCombatant = thisCombatant
		rTemp.CombatantPriorClickTime = thisClickTime

		if IsShiftKeyDown() and (not IsAltKeyDown()) and not isDoubleClick then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			Recap_InsertChat(string_format(rLocalize.VerboseLinkStart,
								"("..rLocalize.LastAll[rUser.View]..") (".. Recap_PetsMergedText()..")",
								Recap_StripGUIDsFromCombatant(thisCombatant),
								_G["RecapList"..id.."_DmgIn"]:GetText(),
								_G["RecapList"..id.."_TimeIn"]:GetText(),
								_G["RecapList"..id.."_DPSIn"]:GetText(),
								_G["RecapList"..id.."_Deaths"]:GetText(),
								_G["RecapList"..id.."_DmgOut"]:GetText(),
								_G["RecapList"..id.."_Time"]:GetText(),
								_G["RecapList"..id.."_DPS"]:GetText(),
								_G["RecapList"..id.."_MaxHit"]:GetText(),
								_G["RecapList"..id.."_Heal"]:GetText(),
								_G["RecapList"..id.."_TimeHeal"]:GetText(),
								_G["RecapList"..id.."_HPS"]:GetText() ) )
			-- note: the DPS/Gear value is omitted as it only makes sense when examining the entire column

		elseif (button == "LeftButton") and not IsShiftKeyDown() and isDoubleClick then
			RecapRecent:Hide()
			if IsControlKeyDown() then
				-- with control down for the double-click, show dispels (which includes breaking crowd control)
				-- now also includes interrupts
				RecapRecent_Populate(thisCombatant, true)
			else
				-- ordinary double-click, show all recent events including dispels
				RecapRecent_Populate(thisCombatant, nil)
			end
			RecapRecent:Show()
			-- on a double-click leave the combatant selected and the panel showing
			rTemp.Selected = index
			RecapScrollBar_Update()
			rTemp.PanelSource = "Main"
			RecapPanel_Show(thisCombatant)

		elseif (button == "RightButton") and not IsShiftKeyDown() and not isDoubleClick then
			if thisCombatant and rCombatants[thisCombatant] and rCombatants[thisCombatant].Friend then
				rTemp.Selected = index
				RecapScrollBar_Update()
				if rUser.View == "Last" then
					Recap_CreateMenu(frame, rLocalize.DropMenu, 1, nil)
				elseif rCombatants[thisCombatant].Locked then
					Recap_CreateMenu(frame, rLocalize.DropUnlockMenu, 1, nil)
				else
					Recap_CreateMenu(frame, rLocalize.DropLockMenu, 1, nil)
				end
			else
				rTemp.Selected = index
				RecapScrollBar_Update()
				if rUser.View == "Last" then
					Recap_CreateMenu(frame, rLocalize.AddMenu, 1, nil)
				elseif rCombatants[thisCombatant].Locked then
					Recap_CreateMenu(frame, rLocalize.AddUnlockMenu, 1, nil)
				else
					Recap_CreateMenu(frame, rLocalize.AddLockMenu, 1, nil)
				end
			end
		end
	end
end

-- allow click reporting off the totals line
function Recap_List_Totals_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, j, thisCombatant

	rTemp.OutgoingDetailSelected = 0
	rTemp.IncomingDetailSelected = 0
	rTemp.OtherDetailSelected = 0
	rTemp.PanelRecentSelected = 0
	for i=1,15 do
		_G["RecapList"..i]:UnlockHighlight()
	end

	-- detect double-click
	local isDoubleClick = false
	local thisClickTime = GetTime()
	if (rTemp.CombatantPriorCombatant == "Recap_List_Totals_OnClick") then
		-- another click on the total line
		if (thisClickTime - rTemp.CombatantPriorClickTime) < 0.3 then
			-- two clicks on the total line within less than 0.3 seconds, call it a double-click
			isDoubleClick = true
		end
	end
	rTemp.CombatantPriorCombatant = "Recap_List_Totals_OnClick"
	rTemp.CombatantPriorClickTime = thisClickTime

	if IsShiftKeyDown() and (not IsAltKeyDown()) and not isDoubleClick then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rTemp.Selected = 0
		RecapPanel_Hide()
		Recap_InsertChat(string_format(rLocalize.VerboseGroupTotalStart,
							"("..rLocalize.LastAll[rUser.View]..") (".. Recap_PetsMergedText()..")",
							_G["RecapTotals_DmgIn"]:GetText(),
							_G["RecapTotals_TimeIn"]:GetText(),
							_G["RecapTotals_DPSIn"]:GetText(),
							_G["RecapTotals_Deaths"]:GetText(),
							_G["RecapTotals_DmgOut"]:GetText(),
							_G["RecapTotals_Time"]:GetText(),
							_G["RecapTotals_DPS"]:GetText(),
							_G["RecapTotals_MaxHit"]:GetText(),
							_G["RecapTotals_Heal"]:GetText(),
							_G["RecapTotals_TimeHeal"]:GetText(),
							_G["RecapTotals_HPS"]:GetText() ) )
		Recap_InsertChat("+")
		-- create totals for the other (non-group) combatants
		local dmgin, deaths, dmgout, heal, maxhit, duration, durationIn, durationHeal
		dmgin = 0
		deaths = 0
		dmgout = 0
		heal = 0
		maxhit = 0
		if rUser.View=="Last" then
			duration = rUser.LastDuration
			durationIn = rUser.LastDurationIn
			durationHeal = rUser.LastDurationHeal
		else
			duration = rUser.TotalDuration
			durationIn = rUser.TotalDurationIn
			durationHeal = rUser.TotalDurationHeal
		end
		if duration>0 or durationIn>0 or durationHeal>0 then
			for j=1,rTemp.ListSize-1 do
				thisCombatant = rTemp.List[j].Name
				if thisCombatant and rCombatants[thisCombatant] and not rCombatants[thisCombatant].Friend then
					if rTemp.List[j].MaxHit > maxhit then
						maxhit = rTemp.List[j].MaxHit
					end
					dmgin = dmgin + rTemp.List[j].DmgIn
					deaths = deaths + rTemp.List[j].Deaths
					dmgout = dmgout + rTemp.List[j].DmgOut
					heal = heal + rTemp.List[j].Heal
				end
			end
			Recap_InsertChat(string_format(rLocalize.VerboseNonGroupTotalStart,
								"("..rLocalize.LastAll[rUser.View]..") (".. Recap_PetsMergedText()..")",
								dmgin,
								_G["RecapTotals_TimeIn"]:GetText(),
								(((durationIn>0) and Recap_Div1(dmgin,durationIn)) or 0),
								deaths,
								dmgout,
								_G["RecapTotals_Time"]:GetText(),
								(((duration>0) and Recap_Div1(dmgout,duration)) or 0),
								maxhit,
								heal,
								_G["RecapTotals_TimeHeal"]:GetText(),
								(((durationHeal>0) and Recap_Div1(heal,durationHeal)) or 0)) )
		end

	elseif not IsShiftKeyDown() and isDoubleClick then
		-- double-click on total line shows all recent combat event information (may have to limit this since 10,000 lines could take a while and be much more than one wants to see)
		-- control+double-click on total line shows all recent dispel information (including breaking crowd control)
		rTemp.Selected = 0
		RecapPanel_Hide()
		if rOpt.RecentData.value then
			RecapRecent:Hide()
			if IsControlKeyDown() then
				-- with control down for the double-click, show all dispels (which includes breaking crowd control)
				RecapRecent_PopulateAll(true)
			else
				-- ordinary double-click, show all recent events including dispels and interrupts
				RecapRecent_PopulateAll(nil)
			end
			RecapRecent:Show()
		end
	end
end

function Recap_GroupTotal_OnClick(frame, button, down)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rOpt.ShowPanel.value then
		if (rTemp.Selected == rTemp.GroupIndex) and RecapPanel:IsShown() then
			-- toggle off
			rTemp.Selected = 0
			RecapPanel_Hide()
		else
			-- calculate our special combatant "Group Total" (on demand only, since it takes a significant amount of time)
			Recap_ClearGrandTotal(rTemp.GroupTotal)
			Recap_DoGrandTotal(rTemp.GroupTotal)
			rTemp.Selected = rTemp.GroupIndex -- non-zero value to keep the panel showing and indicate which total we are showing
			rTemp.LoadSelected = 0
			RecapScrollBar_Update()
			rTemp.PanelSource = "Main"
			RecapPanel_Populate(rTemp.GroupTotal)
			RecapPanel:Show()
		end
	end
end

function Recap_NonGroupTotal_OnClick(frame, button, down)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rOpt.ShowPanel.value then
		if (rTemp.Selected == rTemp.NonGroupIndex) and RecapPanel:IsShown() then
			-- toggle off
			rTemp.Selected = 0
			RecapPanel_Hide()
		else
			-- calculate our special combatant "Non-Group Total" (on demand only, since it takes a significant amount of time)
			Recap_ClearGrandTotal(rTemp.NonGroupTotal)
			Recap_DoGrandTotal(rTemp.NonGroupTotal)
			rTemp.Selected = rTemp.NonGroupIndex -- non-zero value to keep the panel showing and indicate which total we are showing
			rTemp.LoadSelected = 0
			RecapScrollBar_Update()
			rTemp.PanelSource = "Main"
			RecapPanel_Populate(rTemp.NonGroupTotal)
			RecapPanel:Show()
		end
	end
end

local mergeArray = {}
function Recap_MergeEntries(first, second)

	if not first then
		return second
	elseif not second then
		return first
	else
		-- need to do something fancier
		local i, result
		mergeArray = wipe(mergeArray)
		for i in string_gmatch(first, "[^%+]+") do
			mergeArray[i] = true
		end
		for i in string_gmatch(second, "[^%+]+") do
			mergeArray[i] = true
		end
		result = nil
		for i in pairs(mergeArray) do
			if result == nil then
				result = i
			else
				result = result.."+"..i
			end
		end
		return result
	end
end

function Recap_Recent_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id, index, thisCombatant

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapScrollBar)

	if rOpt.RecentData.value then
		if rUser.SelfView then
			if index < rTemp.SelfListSize then
				RecapRecent:Hide()
				if rTemp.RecentSelected==index then
					rTemp.RecentSelected = 0
				else
					rTemp.RecentSelected = index
					local sourceName, effectType, effectName, found, _, effectFirstPart, effectSecondPart, simpleEffect
					sourceName = rTemp.PlayerGUID
					effectType = string_sub(rTemp.SelfList[index].EName,1,1)
					effectName = string_sub(rTemp.SelfList[index].EName,2)
					if (effectType == "2") or (effectType == "4") then
						-- "pet: effect" or "pet: effectFirstPart: effectSecondPart"
						found, _, _, effectFirstPart, effectSecondPart = string_find(effectName, "^(.+): (.+): (.+)$")
						if found then
							-- "pet: effectFirstPart: effectSecondPart"
							effectName = effectFirstPart..": "..effectSecondPart
						else
							-- "pet: effect"
							found, _, _, simpleEffect = string_find(effectName, "^(.+): (.+)$")
							if found then
								-- "pet: effect"
								effectName = simpleEffect
							else
								-- shouldn't get here
							end
						end
					else
						-- "effect" or "effectFirstPart: effectSecondPart"
						-- effectName should already be correct
					end
					RecapRecent_PopulateByEffect(true, sourceName, effectName) -- from Self always selected Outgoing
					RecapRecent:Show()
				end
			end
		else
			if index < rTemp.ListSize then
				RecapRecent:Hide()
				if rTemp.RecentSelected==index then
					rTemp.RecentSelected = 0
				else
					rTemp.RecentSelected = index
					thisCombatant = rTemp.List[index].Name
					if IsControlKeyDown() then
						-- with control down for the double-click, show dispels (which includes breaking crowd control)
						-- now also includes interrupts
						RecapRecent_Populate(thisCombatant, true)
					else
						-- ordinary click, show recent events including dispels and interrupts
						RecapRecent_Populate(thisCombatant, nil)
					end
					RecapRecent:Show()
				end
			end
		end
	else
		PlaySound("igQuestFailed")
	end
end


--[[ Tooltip functions ]]

function Recap_TooltipAndMenuAnchor()

	local anchor = "ANCHOR_LEFT"

	if GetCursorPosition("UIParent") < (UIParent:GetWidth()/2) then
		anchor = "ANCHOR_RIGHT"
	end
	return anchor
end

function Recap_MultilineTooltip(frame, line1, line2, line3, line4, line5, line99)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and rOpt.ShowTooltips.value then
		rTemp.RecapTooltip:ClearAllPoints()
		if not rOpt.TooltipFollow.value then
			GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
		else
			rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
		end
		rTemp.RecapTooltip:SetText(line1)
		if line2 ~= "" then
			rTemp.RecapTooltip:AddLine(line2, .75, .75, .75, 1)
		end
		if line3 ~= "" then
			rTemp.RecapTooltip:AddLine(line3, .75, .75, .75, 1)
		end
		if line4 ~= "" then
			rTemp.RecapTooltip:AddLine(line4, .75, .75, .75, 1)
		end
		if line5 ~= "" then
			rTemp.RecapTooltip:AddLine(line5, .75, .75, .75, 1)
		end
		if rOpt.ShowClickHints.value then
			if line99 ~= "" then
				rTemp.RecapTooltip:AddLine(line99, .565, .565, 1.0, 1)
			end
		end
		rTemp.RecapTooltip:Show()
	end
end

function Recap_AlwaysTooltip(frame, line1, line2)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded then
		rTemp.RecapTooltip:ClearAllPoints()
		if not rOpt.TooltipFollow.value then
			GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
		else
			rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
		end
		rTemp.RecapTooltip:SetText(line1)
		if line2 ~= "" then
			rTemp.RecapTooltip:AddLine(line2, .75, .75, .75, 1)
		end
		rTemp.RecapTooltip:Show()
	end
end

-- returns line1,line2 of a tooltip for type in OptList (for generic static tooltips)
function Recap_GetTooltip(myType)

	local rOptList = _G.recap_temp.OptList
	local rTemp = _G.recap_temp
	local i

	if myType then
		for i in pairs(rOptList) do
			if rOptList[i][1]==myType then
				return rOptList[i][2],rOptList[i][3]
			end
		end
	end
end

-- type=tooltip index, addition=optional addition to header
function Recap_Tooltip(frame, myType, addition)

	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local line1, line2

	if myType=="Status" then
		Recap_MultilineTooltip(frame, rTemp.Recap.." "..rLocalize.Status..": "..rLocalize.StoppedActiveIdle[rUser.State],rLocalize.StatusTooltip)
	elseif myType=="Close" then
		if rUser.State=="Stopped" then
			Recap_Tooltip(frame, "ExitRecap")
		else
			Recap_Tooltip(frame, "HideWindow")
		end
	elseif myType=="Minimize" then
		if rUser.Minimized then
			Recap_Tooltip(frame, "ExpandWindow")
		else
			Recap_Tooltip(frame, "MinimizeWindow")
		end
	elseif myType=="Pin" then
		if rUser.Pinned then
			Recap_Tooltip(frame, "UnPinWindow")
		else
			Recap_Tooltip(frame, "PinWindow")
		end
	elseif myType=="Pause" then
		if rUser.State=="Stopped" then
			Recap_Tooltip(frame, "Resume")
		else
			Recap_Tooltip(frame, "PauseMonitoring")
		end
	elseif myType=="ShowAll" then
		if rUser.View=="Last" then
			Recap_Tooltip(frame, "ShowAllFights")
		else
			Recap_Tooltip(frame, "ShowLastFight")
		end
	elseif myType=="HeaderName" then
		if rUser.View=="Last" then
			line1,line2 = Recap_GetTooltip("CombatLast")
		else
			line1,line2 = Recap_GetTooltip("CombatAll")
		end
		if line1 and line2 then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnMenuTooltip)
		end
	elseif myType=="ShowRecent" then
		line1,line2 = Recap_GetTooltip("ShowRecent")
		if line1 and line2 then
			Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.RecentButtonTooltip)
		end
	elseif myType=="Reset" then
		if rUser.SelfView then
			Recap_Tooltip(frame, "ResetSelfView")
		elseif rUser.View=="Last" then
			Recap_Tooltip(frame, "ResetLastFight")
		else
			Recap_Tooltip(frame, "ResetAllFights")
		end

	elseif myType=="SelfView" then
		if rUser.SelfView then
			Recap_Tooltip(frame, "HideSelfView")
		else
			Recap_Tooltip(frame, "ShowSelfView")
		end

	else
		line1,line2 = Recap_GetTooltip(myType)
		if line1 and line2 then
			if addition then
				Recap_MultilineTooltip(frame, line1..": "..addition, line2)
			else
				Recap_MultilineTooltip(frame, line1, line2)
			end
		end
	end
end

function Recap_LoadBlizzardInterfaceAddOnsPanel(frame)
	local spielMajor, spielMinor
	spielMajor,spielMinor = Recap_GetTooltip("StartingHints")
	Recap_BlizzardInterfaceAddOnsPanel_Explanation:SetText(spielMajor.."\n\n"..spielMinor)
end

function Recap_List_OnEnter(frame)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local index, id, secondLine, thirdLine, fourthLine, fifthLine, line99, thisCombatant, iCombatant

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapScrollBar)
	thisCombatant = rTemp.List[index].Name
	if thisCombatant then
		iCombatant = rCombatants[thisCombatant]
		secondLine = ""
		if iCombatant.Class and rLocalize.ClassName[iCombatant.Class] then
			secondLine = rLocalize.ClassName[iCombatant.Class]
		end
		if iCombatant.Faction and rLocalize.FactionName[iCombatant.Faction] then
			secondLine = secondLine.." (".. rLocalize.FactionName[iCombatant.Faction]..")"
		end
		if Recap_ExtractOwner(thisCombatant) then
			secondLine = secondLine.." ("..rLocalize.OwnedBy.." "..Recap_NameFromNameGUID(Recap_ExtractOwner(thisCombatant))..")"
		elseif rCombatants[thisCombatant].OwnedBy then
			secondLine = secondLine.." ("..rLocalize.OwnedBy.." "..Recap_NameFromNameGUID(rCombatants[thisCombatant].OwnedBy)..")"
		end
		thirdLine = ""
		if iCombatant.MinMaxHealth then
			if iCombatant.MinMaxHealth == iCombatant.MaxMaxHealth then
				thirdLine = rLocalize.Max.." "..rLocalize.PowerName[-2]..":  "..iCombatant.MinMaxHealth
			else
				thirdLine = rLocalize.Max.." "..rLocalize.PowerName[-2]..":  "..iCombatant.MinMaxHealth..".."..iCombatant.MaxMaxHealth
			end
		end
		fourthLine = ""
		if iCombatant.MinMaxPower and iCombatant.PowerType then
			if iCombatant.MinMaxPower == iCombatant.MaxMaxPower then
				if tonumber(iCombatant.MinMaxPower) > 0 then
					fourthLine = rLocalize.Max.." "..rLocalize.PowerName[tonumber(iCombatant.PowerType)]..":  "..iCombatant.MinMaxPower
				end
			else
				fourthLine = rLocalize.Max.." "..rLocalize.PowerName[tonumber(iCombatant.PowerType)]..":  "..iCombatant.MinMaxPower..".."..iCombatant.MaxMaxPower
			end
		end
		fifthLine = ""
		if iCombatant.GearValue and (iCombatant.GearValue > 0) and (iCombatant.GearValue ~= 10000) then
			fifthLine = rLocalize.MaxGearValue..":  "..iCombatant.GearValue
		end
		line99 = rLocalize.MainRowTooltip
		Recap_MultilineTooltip(frame, Recap_NameOnlyFromCombatant(thisCombatant), secondLine, thirdLine, fourthLine, fifthLine, line99)
	end
	if (index<rTemp.ListSize) and rTemp.Selected==0 and rTemp.LoadSelected==0 then
		-- mouseover display of panel only if it isn't locked by being selected
		if thisCombatant then
			rTemp.PanelSource = "Main"
			RecapPanel_Show(thisCombatant)
		end
	end
end

function Recap_Totals_OnEnter(frame)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i, thisCombatant, iTotal
	local group_kills = 0
	local r, g, b

	if rOpt.ShowTooltips.value then

		if rOpt.TooltipFollow.value then
			rTemp.RecapTooltip:SetOwner(frame, Recap_TooltipAndMenuAnchor())
		else
			GameTooltip_SetDefaultAnchor(rTemp.RecapTooltip, frame)
		end

		rTemp.RecapTooltip:AddLine(rLocalize.Totals.." "..rLocalize.For.." "..rLocalize.LastAll[rUser.View])

		if rTemp.ListSize>1 then

			for i=1,(rTemp.ListSize-1) do
				thisCombatant = rTemp.List[i].Name
				if thisCombatant and rCombatants[thisCombatant] and (not rCombatants[thisCombatant].Friend) then
					group_kills = group_kills + rTemp.List[i].Deaths
				end
			end
			iTotal = rTemp.List[rTemp.ListSize]
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddDoubleLine(rLocalize.Combatants..":",rTemp.ListSize-1,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.DmgOut)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DAMAGE_OUT..":",iTotal.DmgOut,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_TIME_FIGHTING..":",Recap_FormatTime(iTotal.Time),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DPS_OUT..":",string_format("%.1f",iTotal.TotDPSOut),r,g,b,r,g,b)
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_MAX_HIT..":",iTotal.MaxHit,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_KILLS..":",group_kills,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.DmgIn)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DAMAGE_IN..":",iTotal.DmgIn,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_TIME_DAMAGED..":",Recap_FormatTime(iTotal.TimeIn),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DPS_IN..":",string_format("%.1f",iTotal.TotDPSIn),r,g,b,r,g,b)
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_DEATHS..":",iTotal.Deaths,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.Heal)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_HEALS..":",iTotal.Heal,r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_TIME_HEALING..":",Recap_FormatTime(iTotal.TimeHeal),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_HPS_OUT..":",string_format("%.1f",iTotal.TotHPS),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(" ") -- blank line
			r, g, b = unpack(rColor.DmgOut)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_GROUP_FIGHT_TIME..":",Recap_FormatTime(iTotal.OverallDuration),r,g,b,r,g,b)
			rTemp.RecapTooltip:AddDoubleLine(RECAP_GROUP_DPS..":",string_format("%.1f",iTotal.OverallDPS),r,g,b,r,g,b)
		else
			r, g, b = unpack(rColor.White)
			rTemp.RecapTooltip:AddLine(rLocalize.Combatants..": "..rLocalize.None,r,g,b)
		end

		if rOpt.ShowClickHints.value then
			rTemp.RecapTooltip:AddLine(rLocalize.TotalsRowTooltip, .565, .565, 1.0, 1)
		end

		rTemp.RecapTooltip:Show()
	end
end

function Recap_Self_OnEnter(frame)

	local rTemp = _G.recap_temp
	local index, id, thisEffect

	id = frame:GetID()
	index = id + FauxScrollFrame_GetOffset(RecapScrollBar)

	thisEffect = rTemp.SelfList[index].EName
	if thisEffect then
		Recap_MultilineTooltip(frame, string_sub(thisEffect,2), nil, nil, nil, nil, rLocalize.EffectRowMenuTooltip)
	end
end

--[[ Context menu functions ]]

function RecapMenu_OnUpdate(frame, elapsed)

	local rTemp = _G.recap_temp
	local i

	if not rTemp.MenuTimer or RecapMenu:IsMouseOver() then
		rTemp.MenuTimer = 0
	end

	rTemp.MenuTimer = rTemp.MenuTimer + elapsed
	if rTemp.MenuTimer > 0.5 then
		rTemp.MenuTimer = 0
		RecapMenu:Hide()
		if rTemp.SelectedEffect then
			for i=1,15 do
				_G["RecapSelf"..i]:UnlockHighlight()
			end
		end
	end
end

function RecapMenu_OnClick(frame, button, down)

	local rSelf = _G.recap.Self
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, j, pet
	local id, index = frame:GetID()

	if rTemp.Menu==rLocalize.ColumnMenu or rTemp.Menu==rLocalize.MinMenu or rTemp.Menu==rLocalize.EffectOptMenu then
		index = rTemp.Menu[id].Info -- .Info of menu item selected
		if rOpt[index] then
			rOpt[index].value = not rOpt[index].value
			_G["RecapOptCheck_"..rTemp.Menu[id].Info]:SetChecked(0)
			if rOpt[index].value then
				_G["RecapOptCheck_"..rTemp.Menu[id].Info]:SetChecked(1)
			end
			RecapMenu_SetCheck(id,rOpt[index].value)
			if rUser.Minimized then
				Recap_Minimize()
			else
				Recap_Maximize()
			end
			if RecapLoad:IsVisible() then
				RecapLoad_Show()
			end
		elseif index=="Pin" then
			rUser.Pinned = not rUser.Pinned
			Recap_SetButtons()
			RecapMenu:Hide()
		end
	end

	-- popup menu
	if (rTemp.Selected > 0) and
	   (rTemp.Menu==rLocalize.AddMenu or rTemp.Menu==rLocalize.AddLockMenu or rTemp.Menu==rLocalize.AddUnlockMenu or
		rTemp.Menu==rLocalize.DropMenu or rTemp.Menu==rLocalize.DropLockMenu or rTemp.Menu==rLocalize.DropUnlockMenu) then

		RecapMenu:Hide()

		local thisCombatant
		thisCombatant = rTemp.List[rTemp.Selected].Name -- name selected

		if id==1 and ((rTemp.Menu==rLocalize.DropMenu) or (rTemp.Menu==rLocalize.DropLockMenu) or (rTemp.Menu==rLocalize.DropUnlockMenu)) and thisCombatant~=rTemp.PlayerGUID then
			-- Make them no longer a 'group combatant'
			rCombatants[thisCombatant].Friend = false
			rTemp.InFriend[thisCombatant] = nil
			-- them and the pets they rode in on
			for pet in pairs(rCombatants) do
				if Recap_IsOwnedBy(pet, thisCombatant) then
					rCombatants[pet].Friend = false
					rTemp.InFriend[pet] = nil
				end
			end

		elseif id==1 and thisCombatant~=rTemp.PlayerGUID then
			-- Toggle their 'group combatant' status
			if rCombatants[thisCombatant].Friend then
				-- make unfriend
				rCombatants[thisCombatant].Friend = false
				rTemp.InFriend[thisCombatant] = nil
				-- them and the pets they rode in on
				for pet in pairs(rCombatants) do
					if Recap_IsOwnedBy(pet, thisCombatant) then
						rCombatants[pet].Friend = false
						rTemp.InFriend[pet] = nil
					end
				end
			else
				-- make friend
				rCombatants[thisCombatant].Friend = true
				rTemp.InFriend[thisCombatant] = true
				-- them and the pets they rode in on
				for pet in pairs(rCombatants) do
					if Recap_IsOwnedBy(pet, thisCombatant) then
						rCombatants[pet].Friend = true
						rTemp.InFriend[pet] = true
					end
				end
			end

		elseif id==2 and rUser.View=="All" then -- reset
			if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				-- ignore if in synchronization
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			else
				-- Reset a combatant, meaning force all their numbers to zero
				local seen = rCombatants[thisCombatant].Seen
				local flags = rCombatants[thisCombatant].Flags
				rCombatants[thisCombatant] = nil -- keep as nil
				Recap_CreateBlankCombatant(thisCombatant, seen, flags)
			end

		elseif id==2 and rUser.View=="Last" then -- reset
			if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				-- ignore if in synchronization
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			else
				-- Partially Reset a combatant, meaning SUBTRACT their last fight information
				if rCombatants[thisCombatant].WasInLast then
					StaticPopupDialogs["rTemp.CONFIRMLASTRESET"] = {
						text = rLocalize.ConfirmLastResetCombatant,
						button1 = ACCEPT,
						button2 = CANCEL,
						OnAccept = function(self)
							-- SUBTRACT the last fight --
							Recap_ResetLastFight(thisCombatant)
							-- force redisplay (not sure if there might not be a cheaper call)
							Recap_Maximize()
						end,
						OnHide = function(self)
						end,
						OnCancel = function(self)
						end,
						timeout = 30,
						showAlert = 1,
						whileDead = 1
					}
					StaticPopup_Show("rTemp.CONFIRMLASTRESET")
				end
			end

		elseif id==3 and thisCombatant~=rTemp.PlayerGUID then -- ignore
			if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
				-- don't ignore a combatant when in synchronization
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			else
				-- Put this combatant on 'ignore' (after forcing all their numbers to zero)
				local seen = rCombatants[thisCombatant].Seen
				local flags = rCombatants[thisCombatant].Flags
				rCombatants[thisCombatant] = nil -- keep as nil
				Recap_CreateBlankCombatant(thisCombatant, seen, flags)
				rCombatants[thisCombatant].Ignore = true
			end

		elseif id==4 then
			-- Toggle their Locked status (makes them stick around through an All Fights Reset)
			rCombatants[thisCombatant].Locked = not rCombatants[thisCombatant].Locked
			-- Set the Locked status of any pets to match
			for i in pairs(rCombatants) do
				if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
					if Recap_IsOwnedBy(i, thisCombatant) then
						rCombatants[i].Locked = rCombatants[thisCombatant].Locked
					end
				end
			end
		end

		-- deletes seem to occasionally produce an unstable list, not sure if there is an easy fix
		Recap_SetView()

	else
		-- remove this effect
		if rTemp.Menu==rLocalize.EffectMenu then
			RecapMenu:Hide()
			for i=1,15 do
				_G["RecapSelf"..i]:UnlockHighlight()
			end
			if rTemp.SelectedEffect then
				-- could be for player, or could be for one of the player's pets
				if (string_sub(rTemp.SelectedEffect,1,1)=="1") or (string_sub(rTemp.SelectedEffect,1,1)=="3") then
					-- player
					if rSelf[rTemp.s][rTemp.SelectedEffect] then
						rSelf[rTemp.s][rTemp.SelectedEffect] = nil -- keep as nil
					end
				else
					-- player's pet
					local found, _, selfType, selfName, selfEffect, selfIndex
					-- check first for TypePet: effectA: effectB
					found,_,selfType,selfName,selfEffect = string_find(rTemp.SelectedEffect, "^(.)(.+): (.+: .+)")
					if not found then
						-- now get the regular TypePet: effect
						_,_,selfType,selfName,selfEffect = string_find(rTemp.SelectedEffect, "^(.)(.+): (.+)")
					end
					selfIndex = rTemp.s..":"..selfName
					if selfType=="2" then
						selfEffect = "1"..selfEffect
					else
						selfEffect = "3"..selfEffect
					end
					if rSelf[selfIndex][selfEffect] then
						rSelf[selfIndex][selfEffect] = nil -- keep as nil
					end
					local k = 0
					for j in pairs(rSelf[selfIndex]) do
						k = k + 1
					end
					if k==0 then
						-- nothing left, clear it out entirely
						rSelf[selfIndex] = nil -- keep as nil
					end
				end
				rTemp.SelectedEffect = false
				Recap_SetView()
			end
		end

		-- other actions
		if rTemp.Menu==rLocalize.DetailMenu then
--			local selvalue = rTemp.Menu[id].Info -- with 4.71 support damage only or healing only
--			if (selvalue=="TotalDmg") or (selvalue=="TotalHeal") then
--				selvalue = "Total"
--			end
--			if (selvalue=="TotalPSDmg") or (selvalue=="TotalPSHeal") then
--				selvalue = "TotalPS"
--			end
-- BLAH remove maybe			if rTemp.OutgoingDetailsList and rTemp.OutgoingDetailsList[1] and rTemp.OutgoingDetailsList[1][selvalue] then
			if rTemp.OutgoingDetailsList then
				rOpt.OutgoingPanelDetail.value = rTemp.Menu[id].Info
				if rTemp.Selected == rTemp.GroupIndex then
					RecapPanel_Populate(rTemp.GroupTotal)
				elseif rTemp.Selected == rTemp.NonGroupIndex then
					RecapPanel_Populate(rTemp.NonGroupTotal)
				else
					RecapPanel_Populate(rTemp.List[rTemp.Selected].Name)
				end
				RecapPanelOutgoingTotalLabel:SetText(rLocalize.DetailTitle[rOpt.OutgoingPanelDetail.value])
				RecapPanelOutgoingDetailsScrollBar_Update()
			end
			RecapMenu:Hide()
		end
		if rTemp.Menu==rLocalize.DetailMenu then
--			local selvalue = rTemp.Menu[id].Info -- with 4.71 support damage only or healing only
--			if (selvalue=="TotalDmg") or (selvalue=="TotalHeal") then
--				selvalue = "Total"
--			end
--			if (selvalue=="TotalPSDmg") or (selvalue=="TotalPSHeal") then
--				selvalue = "TotalPS"
--			end
-- BLAH remove maybe			if rTemp.IncomingDetailsList and rTemp.IncomingDetailsList[1] and rTemp.IncomingDetailsList[1][selvalue] then
			if rTemp.IncomingDetailsList then
				rOpt.IncomingPanelDetail.value = rTemp.Menu[id].Info
				if rTemp.Selected == rTemp.GroupIndex then
					RecapPanel_Populate(rTemp.GroupTotal)
				elseif rTemp.Selected == rTemp.NonGroupIndex then
					RecapPanel_Populate(rTemp.NonGroupTotal)
				else
					RecapPanel_Populate(rTemp.List[rTemp.Selected].Name)
				end
				RecapPanelIncomingTotalLabel:SetText(rLocalize.DetailTitle[rOpt.IncomingPanelDetail.value])
				RecapPanelIncomingDetailsScrollBar_Update()
			end
			RecapMenu:Hide()
		end
	end
end

-- offset=1 to move window so it's under pointer
function Recap_CreateMenu(frame, menu, offset, outgoing)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, cy, x, y, lines, newScale

	rTemp.Menu = menu

	if rTemp.Menu==rLocalize.ColumnMenu or rTemp.Menu==rLocalize.MinMenu or rTemp.Menu==rLocalize.EffectOptMenu then
		for i in pairs(rTemp.Menu) do
			if rOpt[rTemp.Menu[i].Info] then
				rTemp.Menu[i].Check = rOpt[rTemp.Menu[i].Info].value
			end
		end
	end

	if rTemp.Menu==rLocalize.MinMenu then
		rTemp.Menu[1].Check = rUser.Pinned
	end

	if rTemp.Menu==rLocalize.DetailMenu then
		if (outgoing == true) then
			for i in pairs(rTemp.Menu) do
				rTemp.Menu[i].Check = (rOpt.OutgoingPanelDetail.value==rTemp.Menu[i].Info)
			end
		elseif (outgoing == false) then
			for i in pairs(rTemp.Menu) do
				rTemp.Menu[i].Check = (rOpt.IncomingPanelDetail.value==rTemp.Menu[i].Info)
			end
		end
	end

	lines = math_min(#rTemp.Menu,rTemp.MaxMenuLines)

	cy = 44 -- 12+32
	for i=1,lines do
		_G["RecapMenu"..i.."_Text"]:SetText(rTemp.Menu[i].Text)
		RecapMenu_SetCheck(i,rTemp.Menu[i].Check)
		_G["RecapMenu"..i]:Show()
		cy = cy + 14
	end
	for i=(lines+1),rTemp.MaxMenuLines do
		_G["RecapMenu"..i]:Hide()
	end

	RecapMenu:SetHeight(cy)
	RecapDropSubFrame:SetHeight(cy-32)
	RecapMenu:ClearAllPoints()

	x = GetCursorPosition("UIParent")
	newScale = Recap_Div2(rOpt.SetScale.value,100)
	x = x / UIParent:GetScale() / newScale
	if Recap_TooltipAndMenuAnchor() == "ANCHOR_LEFT" then
		if rOpt.GrowUpwards.value and not offset then
			y = frame:GetBottom()
			RecapMenu:SetPoint("BOTTOMRIGHT","UIParent","BOTTOMLEFT",(x+20)/newScale,(y-4)/newScale)
		else
			y = frame:GetTop()
			RecapMenu:SetPoint("TOPRIGHT","UIParent","BOTTOMLEFT",(x+20)/newScale,(y+(offset and 16 or 4))/newScale)
		end
	else
		if rOpt.GrowUpwards.value and not offset then
			y = frame:GetBottom()
			RecapMenu:SetPoint("BOTTOMLEFT","UIParent","BOTTOMLEFT",(x-20)/newScale,(y-4)/newScale)
		else
			y = frame:GetTop()
			RecapMenu:SetPoint("TOPLEFT","UIParent","BOTTOMLEFT",(x-20)/newScale,(y+(offset and 16 or 4))/newScale)
		end
	end

	RecapMenu:Show()

end

function RecapMenu_OnEnter(frame)
	local rTemp = _G.recap_temp
	id = frame:GetID()
	if rTemp.Menu[id] and rTemp.Menu[id].Info then
		if rTemp.Menu==rLocalize.AddLockMenu or rTemp.Menu==rLocalize.AddUnlockMenu or rTemp.Menu==rLocalize.DropLockMenu or rTemp.Menu==rLocalize.DropUnlockMenu then
			if rTemp.Selected ~= 0 then
				-- TODO: cool, by oversight the tooltip shows the appended GUID, I'm gonna leave it there since I find it useful and it is relatively obscure
				Recap_Tooltip(frame, rTemp.Menu[id].Info, rTemp.List[rTemp.Selected].Name)
			end
		elseif rTemp.Menu==rLocalize.EffectMenu and rTemp.SelectedEffect then
			Recap_Tooltip(frame, rTemp.Menu[id].Info, string_sub(rTemp.SelectedEffect,2))
		else
			Recap_Tooltip(frame, rTemp.Menu[id].Info)
		end
	end
end

function RecapEffectsHeader_OnEnter(frame)

	local _, s

	_,_,s = string_find(frame:GetName(), "RecapHeader_(.+)")
	if s then
		if (s == "EName") then
			local line1,line2 = Recap_GetTooltip("Header"..s)
			if line1 and line2 then
				Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnMenuTooltip)
			end
		else
			local line1,line2 = Recap_GetTooltip("Header"..s)
			if line1 and line2 then
				Recap_MultilineTooltip(frame, line1, line2, nil, nil, nil, rLocalize.ColumnPostMenuTooltip)
			end
		end
	end
end

function RecapSelf_OnMouseUp(frame, event, ...)
	local rTemp = _G.recap_temp
	rTemp.SelectedEffect = false
	Recap_OnMouseUp(frame, event, ...)
end

function RecapEffectsHeader_OnMouseUp(frame, button)

	if (button == "RightButton") and not IsShiftKeyDown() then
		Recap_CreateMenu(frame, rLocalize.EffectOptMenu, nil, nil)
	end
end

function RecapEffectsHeader_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, lineno
	local alltext, text = ""
	local header = string_gsub(frame:GetName(),"RecapHeader_","")
	local print_chat = Recap_SendChatMessage
	local chatchan, chatnum, presenceID
	local maxLines = rOpt.MaxRank.value

	-- new code to support sorting effects on a per column basis
	if not IsShiftKeyDown() then
		if rUser.ESortBy==string_gsub(header,"$","") then
			rUser.ESortDir = not rUser.ESortDir
		else
			rUser.ESortBy = string_gsub(header,"$","")
			if (header=="EName") or (header=="EElement") then
				rUser.ESortDir = true
			else
				rUser.ESortDir = false
			end
		end
		Recap_SortSelfList()
		RecapScrollBar_Update()

	elseif IsShiftKeyDown() and (not IsAltKeyDown()) and rTemp.SelfListSize>1 then

		if IsControlKeyDown() then
			-- open Clipboard if necessary so we post there
			RecapClipFrame:Show()
		end

		rUser.ESortBy = header

		-- only report for columns other than EName
		if rUser.ESortBy~="EName" then

			if (header=="EName") or (header=="EElement") then
				rUser.ESortDir = true
			else
				rUser.ESortDir = false
			end
			Recap_SortSelfList()
			RecapScrollBar_Update()

			chatchan, chatnum, presenceID = Recap_GetChannelInfo(nil, nil)
			if chatchan=="Self" then
				print_chat = Recap_Print
			end

			-- if the focus is on a WIM (WoW Instant Messenger) edit box, post there
			if Recap_WIMFindFocus() then
			print_chat = Recap_WIM_Print
			end

			-- If the Clipboard is open, post there instead of to chat or console
			if RecapClipEditBox:IsVisible() then
				print_chat = Recap_LineToClipboard
				maxLines = rTemp.MaxLinesToClipboard
			end

			alltext = "__ Recap ("..Recap_PetsMergedText().."): "..rTemp.Player..": "..Recap_GetTooltip("Header"..header).." __"
			lineno = 0
			if print_chat(alltext, chatchan, nil, chatnum, presenceID) then
				-- a non-nil return indicates clipboard full
				-- should not happen as of 4.62, but leave the if statement in case
			end
			local transition = 0
			for i=1, math_min(rTemp.SelfListSize-1, maxLines) do
				if rTemp.SelfList[i][header]~="0.0%" and rTemp.SelfList[i][header]~="--" and tostring(rTemp.SelfList[i][header])~="0" then
					local effectType = string_sub(rTemp.SelfList[i].EName,1,1)
					if (transition==0) and ((effectType=="1") or (effectType=="2")) then
						-- remember if we saw damage
						transition = 1
					end
					if (transition==1) and ((effectType=="3") or (effectType=="4")) then
						-- extra line between damage and healing
						if print_chat("+", chatchan, nil, chatnum, presenceID) then
							-- a non-nil return indicates clipboard full
							-- should not happen as of 4.62, but leave the if statement in case
						end
						transition = 2
					end
					text = string_sub(rTemp.SelfList[i].EName,2)..(((effectType=="3") or (effectType=="4")) and "+" or "")..": "..rTemp.SelfList[i][header]..(header=="ETotal" and (" ("..rTemp.SelfList[i].ETotalP..")") or "")
					lineno = lineno + 1
					text = tostring(lineno)..". "..text
					if print_chat(text, chatchan, nil, chatnum, presenceID) then
						-- a non-nil return indicates clipboard full
						-- should not happen as of 4.62, but leave the if statement in case
					end
				end
			end

			if RecapClipEditBox:IsVisible() then
				RecapClipEditBox:HighlightText()
				RecapClipEditBox:SetFocus()
			end
		end

	elseif IsShiftKeyDown() then
		local editBox = ChatEdit_GetActiveWindow()
		if not editBox then
			-- short help message
			print(rLocalize.RankUsage)
		end
	end
end


function RecapSelf_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index = id + FauxScrollFrame_GetOffset(RecapScrollBar)
	local linkformat = rLocalize.OutgoingDamageDetailLink
	local text = ""

	if index < rTemp.SelfListSize then

		-- detect double-click
		local isDoubleClick = false
		local thisEffect = rTemp.SelfList[index].EName
		local thisClickTime = GetTime()
		if thisEffect == rTemp.SelfPriorEffect then
			-- another click on the same Effect
			if (thisClickTime - rTemp.SelfPriorClickTime) < 0.3 then
				-- two clicks on the same Effect within less than 0.3 seconds, call it a double-click
				isDoubleClick = true
			end
		end
		rTemp.SelfPriorEffect = thisEffect
		rTemp.SelfPriorClickTime = thisClickTime

		local effectType = string_sub(rTemp.SelfList[index].EName,1,1)

		if IsShiftKeyDown() and (not IsAltKeyDown()) and not isDoubleClick then

			if IsControlKeyDown() then
				-- open Clipboard if necessary so we post there
				RecapClipFrame:Show()
			end

			if (effectType=="3") or (effectType=="4") then
				linkformat = rLocalize.OutgoingHealDetailLink
			end
			text = string_format(linkformat,
								 "("..Recap_PetsMergedText()..")",
								 rTemp.Player,
								 string_sub(rTemp.SelfList[index].EName,2),
								 (rTemp.SelfList[index].EElement or "?"),
								 rTemp.SelfList[index].ETotal,
								 rTemp.SelfList[index].ETotalP,
								 Recap_StripGUIDsFromCombatant(rTemp.PlayerGUID))..", "..RECAP_MAX_HIT..": "..rTemp.SelfList[index].EMaxAll..((rTemp.SelfList[index].ECritsP~="--") and (", "..RECAP_CRIT_RATE..": "..rTemp.SelfList[index].ECritsP) or "")
			Recap_InsertChat(text," ")

		elseif (button == "LeftButton") and not IsShiftKeyDown() and isDoubleClick then
			local sourceName, effectName, found, _, effectFirstPart, effectSecondPart, simpleEffect
			sourceName = rTemp.PlayerGUID
			effectName = string_sub(rTemp.SelfList[index].EName,2)
			if (effectType == "2") or (effectType == "4") then
				-- "pet: effect" or "pet: effectFirstPart: effectSecondPart"
				found, _, _, effectFirstPart, effectSecondPart = string_find(effectName, "^(.+): (.+): (.+)$")
				if found then
					-- "pet: effectFirstPart: effectSecondPart"
					effectName = effectFirstPart..": "..effectSecondPart
				else
					-- "pet: effect"
					found, _, _, simpleEffect = string_find(effectName, "^(.+): (.+)$")
					if found then
						-- "pet: effect"
						effectName = simpleEffect
					else
						-- shouldn't get here
					end
				end
			else
				-- "effect" or "effectFirstPart: effectSecondPart"
				-- effectName should already be correct
			end
			RecapRecent:Hide()
			RecapRecent_PopulateByEffect(true, sourceName, effectName) -- from Self always selected Outgoing
			RecapRecent:Show()

		elseif (button == "RightButton") and not IsShiftKeyDown() and not isDoubleClick then
			frame:LockHighlight()
			rTemp.SelectedEffect = rTemp.SelfList[index].EName
			Recap_CreateMenu(frame, rLocalize.EffectMenu, 1, nil)
		end
	end
end

Recap_lua_4773 = true
