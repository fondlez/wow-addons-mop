﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ RecapOptions.lua ]]

local math_max = _G.math.max
local math_min = _G.math.min
local math_abs = _G.math.abs
local string_find = _G.string.find
local string_format = _G.string.format
local string_gsub = _G.string.gsub
local string_lower = _G.string.lower
local string_sub = _G.string.sub
local string_len = _G.string.len
local table_insert = _G.table.insert
local table_sort = _G.table.sort
local pairs = _G.pairs
local ipairs = _G.ipairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize

--[[ local functions (precede first use) ]]

-- knob=nil to use current values
local function set_anchor_buttons(knob)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt

	RecapAnchorTopLeft:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
	RecapAnchorTopLeft:UnlockHighlight()
	RecapAnchorTopRight:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
	RecapAnchorTopRight:UnlockHighlight()
	RecapAnchorBottomLeft:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
	RecapAnchorBottomLeft:UnlockHighlight()
	RecapAnchorBottomRight:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Down")
	RecapAnchorBottomRight:UnlockHighlight()

	if knob=="RecapAnchorTopLeft" then
		rOpt.GrowUpwards.value = false
		rOpt.GrowLeftwards.value = false
	elseif knob=="RecapAnchorTopRight" then
		rOpt.GrowUpwards.value = false
		rOpt.GrowLeftwards.value = true
	elseif knob=="RecapAnchorBottomLeft" then
		rOpt.GrowUpwards.value = true
		rOpt.GrowLeftwards.value = false
	elseif knob=="RecapAnchorBottomRight" then
		rOpt.GrowUpwards.value = true
		rOpt.GrowLeftwards.value = true
	else
		knob = "RecapAnchor"..(rOpt.GrowUpwards.value and "Bottom" or "Top")..(rOpt.GrowLeftwards.value and "Right" or "Left")
	end
	_G[knob]:SetNormalTexture("Interface\\AddOns\\Recap\\Images\\Recap-Buttons-Up")
	_G[knob]:LockHighlight()

	Recap_MoveMinimize()
	if rUser.Minimized then
		Recap_Minimize()
	end
end

local function Recap_SetExists(text)

	local rTemp = _G.recap_temp
	local i
	local result = 0

	for i in pairs(rTemp.FightSets) do
		if rTemp.FightSets[i].Name == text then
			result = i
		end
	end

	return result
end

local function Recap_IgnoreExists(text)

	local rTemp = _G.recap_temp
	local i

	for i in pairs(rTemp.Ignores) do
		if rTemp.Ignores[i].SpellID == tonumber(text) then
			return i
		end
	end

	return 0
end

-- fight data set sort (by date)
local function Recap_SetSort(e1,e2)

	if not e1.Date then
		return false
	end
	if not e2.Date then
		return false
	end

	if ( e1.Date > e2.Date ) then
		return true
	else
		return false
	end
end

-- ignores sort (by spell name)
local function Recap_IgnoreSort(e1,e2)

	if not e1.SpellName then
		return false
	end
	if not e2.SpellName then
		return false
	end

	if ( e1.SpellName < e2.SpellName ) then
		return true
	else
		return false
	end
end

local function Recap_FormatLevel(level)

	if level and tonumber(level)>0 then
		return level
	elseif level and tonumber(level)==-1 then
		return "??"
	else
		return ""
	end
end

local function Recap_FormatClass(class)

	if class and rLocalize.ClassAbbr[class] then
		return rLocalize.ClassAbbr[class]
	else
		return ""
	end
end

local function logLine(thisIndex, clip)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local lineformat = rLocalize.LogFormat
	local str, iIndex

	if rOpt.TabDelimited.value then
		lineformat = rLocalize.LogFormatTabDelimited
	end

	if thisIndex=="FirstLine" then
		str = string_format(lineformat,rLocalize.Log[1],
							  rLocalize.Log[2],
							  rLocalize.Log[3],
							  rLocalize.Log[4],
							  rLocalize.Log[5],
							  rLocalize.Log[6],
							  rLocalize.Log[7],
							  rLocalize.Log[8],
							  rLocalize.Log[9],
							  rLocalize.Log[10],
							  rLocalize.Log[11],
							  rLocalize.Log[12],
							  rLocalize.Log[13],
							  rLocalize.Log[14],
							  rLocalize.Log[15],
							  rLocalize.Log[16],
							  rLocalize.Log[17],
							  rLocalize.Log[18],
							  rLocalize.Log[19],
							  rLocalize.Log[20],
							  rLocalize.Log[21])
	elseif thisIndex=="Spacer" then
		str = " "
	else
		iIndex = rTemp.List[thisIndex]
		str = string_format(lineformat,
							Recap_StripGUIDsFromCombatant(iIndex.Name),
							Recap_FormatLevel(rCombatants[iIndex.Name].Level),
							Recap_FormatClass(rCombatants[iIndex.Name].Class),
							Recap_FormatTimeSeconds(iIndex.Time),
							iIndex.DmgOut,
							iIndex.DmgOutP.."%%",
							iIndex.MaxHit,
							string_format("%.1f",iIndex.DPS),
							iIndex.DPSPerGear,
							Recap_FormatTimeSeconds(iIndex.TimeIn),
							iIndex.DmgIn,
							iIndex.DmgInP.."%%",
							string_format("%.1f",iIndex.DPSIn),
							Recap_FormatTimeSeconds(iIndex.TimeHeal),
							iIndex.Heal,
							iIndex.HealP.."%%",
							string_format("%3d",iIndex.Over).."%%>",
							string_format("%.1f",iIndex.HPS),
							iIndex.Dispels,
							iIndex.Interrupts,
							iIndex.Deaths)
	end

	if str then
		if clip then
			str = str.."\n"
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

-- HTML logLine split into two functions to send a single table row as two lines (due to chat max limit 255 bytes)
local function loglineHTML1(thisIndex, clip)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local lineformat = rLocalize.HTMLFormat1
	local str, iIndex
	local prefix = "<b>"
	local suffix = "</b>"

	if thisIndex=="FirstLine" then
		str = string_format(lineformat,prefix..rLocalize.Log[1]..suffix,
							  prefix..rLocalize.Log[2]..suffix,
							  prefix..rLocalize.Log[3]..suffix,
							  prefix..rLocalize.Log[4]..suffix,
							  prefix..rLocalize.Log[5]..suffix,
							  prefix..rLocalize.Log[6]..suffix,
							  prefix..rLocalize.Log[7]..suffix,
							  prefix..rLocalize.Log[8]..suffix,
							  prefix..rLocalize.Log[9]..suffix)
	elseif thisIndex=="Spacer" then
		str = string_format(lineformat," "," "," "," "," "," "," "," "," ")
	else
		iIndex = rTemp.List[thisIndex]
		str = string_format(lineformat,
							Recap_StripGUIDsFromCombatant(iIndex.Name),
							Recap_FormatLevel(rCombatants[iIndex.Name].Level),
							Recap_FormatClass(rCombatants[iIndex.Name].Class),
							Recap_FormatTimeSeconds(iIndex.Time),
							iIndex.DmgOut,
							iIndex.DmgOutP.."%%",
							iIndex.MaxHit,
							string_format("%.1f",iIndex.DPS),
							iIndex.DPSPerGear)
	end

	if str then
		if clip then
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

local function loglineHTML2(thisIndex, clip)

	local rTemp = _G.recap_temp
	local lineformat = rLocalize.HTMLFormat2
	local str, iIndex
	local prefix = "<b>"
	local suffix = "</b>"

	if thisIndex=="FirstLine" then
		str = string_format(lineformat,prefix..rLocalize.Log[10]..suffix,
							  prefix..rLocalize.Log[11]..suffix,
							  prefix..rLocalize.Log[12]..suffix,
							  prefix..rLocalize.Log[13]..suffix,
							  prefix..rLocalize.Log[14]..suffix,
							  prefix..rLocalize.Log[15]..suffix,
							  prefix..rLocalize.Log[16]..suffix,
							  prefix..rLocalize.Log[17]..suffix,
							  prefix..rLocalize.Log[18]..suffix,
							  prefix..rLocalize.Log[19]..suffix,
							  prefix..rLocalize.Log[20]..suffix,
							  prefix..rLocalize.Log[21]..suffix)
	elseif thisIndex=="Spacer" then
		str = string_format(lineformat," "," "," "," "," "," "," "," "," "," "," ")
	else
		iIndex = rTemp.List[thisIndex]
		str = string_format(lineformat,
							Recap_FormatTimeSeconds(iIndex.TimeIn),
							iIndex.DmgIn,
							iIndex.DmgInP.."%%",
							string_format("%.1f",iIndex.DPSIn),
							Recap_FormatTimeSeconds(iIndex.TimeHeal),
							iIndex.Heal,
							iIndex.HealP.."%%",
							iIndex.Over.."%%>",
							string_format("%.1f",iIndex.HPS),
							iIndex.Dispels,
							iIndex.Interrupts,
							iIndex.Deaths)
	end

	if str then
		if clip then
			str = str.."\n"
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

local function outgoingeffectline(i,clip)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local lineformat = rLocalize.DetailFormat
	local str, iIndex

	if rOpt.TabDelimited.value then
		lineformat = rLocalize.DetailFormatTabDelimited
	end

	if i=="FirstLine" then
		str = string_format(lineformat,rLocalize.Detail[1],
							  rLocalize.Detail[2],
							  rLocalize.Detail[3],
							  rLocalize.Detail[4],
							  rLocalize.Detail[5],
							  rLocalize.Detail[6],
							  rLocalize.Detail[7],
							  rLocalize.Detail[8],
							  rLocalize.Detail[9],
							  rLocalize.Detail[10],
							  rLocalize.Detail[11],
							  rLocalize.Detail[12],
							  rLocalize.Detail[13],
							  rLocalize.Detail[14],
							  rLocalize.Detail[15],
							  rLocalize.Detail[16],
							  rLocalize.Detail[17],
							  rLocalize.Detail[18],
							  rLocalize.Detail[19],
							  rLocalize.Detail[20],
							  rLocalize.Detail[21],
							  rLocalize.Detail[22],
							  rLocalize.Detail[23],
							  rLocalize.Detail[24])
	else
		iIndex = rTemp.SelfList[i]
		str = string_format(lineformat,
							string_sub(iIndex.EName,2)..(((string_sub(iIndex.EName,1,1)>="3") and "+") or ""),
							iIndex.EElement,
							iIndex.ETotal,
							iIndex.ETotalP,
							iIndex.EMaxAll,
							iIndex.EGlances,
							iIndex.EGlancesMin,
							iIndex.EGlancesAvg,
							iIndex.EGlancesMax,
							iIndex.EHits,
							iIndex.EHitsMin,
							iIndex.EHitsAvg,
							iIndex.EHitsMax,
							iIndex.ETicks,
							iIndex.ETicksMin,
							iIndex.ETicksAvg,
							iIndex.ETicksMax,
							iIndex.ECrits,
							iIndex.ECritsMin,
							iIndex.ECritsAvg,
							iIndex.ECritsMax,
							iIndex.ECritsP,
							iIndex.EMiss,
							iIndex.EMissP)
	end

	if str then
		if clip then
			str = str.."\n"
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

-- HTML logLine split into three functions to send a single table row as three lines (due to chat max limit 255 bytes)
local function outgoingeffectlineHTML1(i, clip)

	local rTemp = _G.recap_temp
	local lineformat = rLocalize.HTMLDetailFormat1
	local str, iIndex
	local prefix = "<b>"
	local suffix = "</b>"

	if i=="FirstLine" then
		str = string_format(lineformat,prefix..rLocalize.Detail[1]..suffix,
							  prefix..rLocalize.Detail[2]..suffix,
							  prefix..rLocalize.Detail[3]..suffix,
							  prefix..rLocalize.Detail[4]..suffix,
							  prefix..rLocalize.Detail[5]..suffix,
							  prefix..rLocalize.Detail[6]..suffix,
							  prefix..rLocalize.Detail[7]..suffix,
							  prefix..rLocalize.Detail[8]..suffix)
	else
		iIndex = rTemp.SelfList[i]
		str = string_format(lineformat,
							string_sub(iIndex.EName,2)..(((string_sub(iIndex.EName,1,1)>="3") and "+") or ""),
							iIndex.EElement,
							iIndex.ETotal,
							iIndex.ETotalP,
							iIndex.EMaxAll,
							iIndex.EGlances,
							iIndex.EGlancesMin,
							iIndex.EGlancesAvg)
	end

	if str then
		if clip then
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

local function outgoingeffectlineHTML2(i, clip)

	local rTemp = _G.recap_temp
	local lineformat = rLocalize.HTMLDetailFormat2
	local str, iIndex
	local prefix = "<b>"
	local suffix = "</b>"

	if i=="FirstLine" then
		str = string_format(lineformat,
							  prefix..rLocalize.Detail[9]..suffix,
							  prefix..rLocalize.Detail[10]..suffix,
							  prefix..rLocalize.Detail[11]..suffix,
							  prefix..rLocalize.Detail[12]..suffix,
							  prefix..rLocalize.Detail[13]..suffix,
							  prefix..rLocalize.Detail[14]..suffix,
							  prefix..rLocalize.Detail[15]..suffix,
							  prefix..rLocalize.Detail[16]..suffix)
	else
		iIndex = rTemp.SelfList[i]
		str = string_format(lineformat,
							iIndex.EGlancesMax,
							iIndex.EHits,
							iIndex.EHitsMin,
							iIndex.EHitsAvg,
							iIndex.EHitsMax,
							iIndex.ETicks,
							iIndex.ETicksMin,
							iIndex.ETicksAvg)
	end

	if str then
		if clip then
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

local function outgoingeffectlineHTML3(i, clip)

	local rTemp = _G.recap_temp
	local lineformat = rLocalize.HTMLDetailFormat3
	local str, iIndex
	local prefix = "<b>"
	local suffix = "</b>"

	if i=="FirstLine" then
		str = string_format(lineformat,
							  prefix..rLocalize.Detail[17]..suffix,
							  prefix..rLocalize.Detail[18]..suffix,
							  prefix..rLocalize.Detail[19]..suffix,
							  prefix..rLocalize.Detail[20]..suffix,
							  prefix..rLocalize.Detail[21]..suffix,
							  prefix..rLocalize.Detail[22]..suffix,
							  prefix..rLocalize.Detail[23]..suffix,
							  prefix..rLocalize.Detail[24]..suffix)
	else
		iIndex = rTemp.SelfList[i]
		str = string_format(lineformat,
							iIndex.ETicksMax,
							iIndex.ECrits,
							iIndex.ECritsMin,
							iIndex.ECritsAvg,
							iIndex.ECritsMax,
							iIndex.ECritsP,
							iIndex.EMiss,
							iIndex.EMissP)
	end

	if str then
		if clip then
			str = str.."\n"
			str = string_gsub(str,"%%%%","%%")
		end
		return str
	end
	return ""
end

-- if we set or cleared either pause option, set the state appropriately
-- NB: pause == Stopped
local function Recap_CheckInstanceBattleground()
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local inInstance, instanceType
	inInstance, instanceType = IsInInstance()
	if rOpt.PauseOutsideInstances.value and (not rOpt.PauseInsideBattlegrounds.value) then
		if inInstance then
			if (rUser.State == "Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			end
		else
			if (rUser.State ~= "Stopped") then
				-- was active or idle, need to pause
--print("(Recap) EndFight due to being outside instance")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		end
	elseif (not rOpt.PauseOutsideInstances.value) and rOpt.PauseInsideBattlegrounds.value then
		if inInstance and (instanceType == "pvp") then
			if (rUser.State ~= "Stopped") then
				-- was active or idle, need to pause
--print("(Recap) EndFight due to being in pvp instance")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		else
			if (rUser.State == "Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			end
		end
	elseif rOpt.PauseOutsideInstances.value and rOpt.PauseInsideBattlegrounds.value then
		if inInstance and (instanceType == "pvp") then
			if (rUser.State ~= "Stopped") then
				-- was active or idle, need to pause
--print("(Recap) EndFight due to being in pvp instance")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		elseif inInstance then
			if (rUser.State=="Stopped") then
				-- was paused, need to resume
				Recap_ClearAsIfEndOfFight()
				Recap_SetState("Idle")
			end
		else
			if (rUser.State~="Stopped") then
				-- was active or idle, need to pause
--print("(Recap) EndFight due to being outside instance")
				Recap_EndFight(true)
				if rOpt.AutoSaveBossFights.value and rTemp.BossList and (rTemp.BossList ~= "") then
					-- hostile boss present, schedule a save of the last fight, to begin on the next tick
					rTemp.FlagSavePhase = 1
					rTemp.FlagSaveLastOnly = true
					rTemp.FlagSaveSetName = rLocalize.Difficulty[rTemp.InstanceDifficulty]..": "..rTemp.BossList..": "..date("%Y-%b-%d %H:%M:%S")
					rTemp.BossList = ""
					rTemp.FlagSavePriorState = "Stopped"
				end
				Recap_SetState("Stopped")
			end
		end
	else
		-- one was off, and the other just got turned off
		if (rUser.State=="Stopped") then
			-- was paused, need to resume
			Recap_ClearAsIfEndOfFight()
			Recap_SetState("Idle")
		end
	end
end


--[[ global functions ]]

function Recap_InitializeOptions()

	local rRecap = _G.recap
	local rOpt = _G.recap_temp.Opt
	local i, chatname, _, chatid, newScale

	if not rOpt.AutoPost.Channel then
		rOpt.AutoPost.Channel = rLocalize.ChannelDropList[1] -- "Self" or equivalent
	end

	RecapAutoFadeSlider:SetValue(rOpt.AutoFadeTimer.value)
	RecapSetScaleSlider:SetValue(rOpt.SetScale.value)
	RecapIdleFightSlider:SetValue(rOpt.IdleFightTimer.value)
	RecapEndFightDelaySlider:SetValue(rOpt.EndFightDelay.value)
	RecapRecentEventCountSlider:SetValue(rOpt.RecentEventCount.value / 2000)
	RecapMaxRowsSlider:SetValue(rOpt.MaxRows.value)
	RecapMaxRankSlider:SetValue(rOpt.MaxRank.value)
	RecapOptTab1:LockHighlight()
	RecapOptSubFrame1:Show()

	RecapOpt_StatDropDownText:SetText(rOpt.AutoPost.Stat)

	-- the following, intended to pre-select the memorised channel, might fail with non-English clients since what is memorised is not canonical, and WoW goes with canonical
	_,_,chatid,chatname = string_find(rOpt.AutoPost.Channel, "(%d+)-(%w+)")
	if chatid and chatid~=GetChannelName(chatid) then
		rOpt.AutoPost.Channel = rLocalize.ChannelDropList[1] -- "Self" or equivalent
	end
	RecapOpt_ChannelDropDownText:SetText(rOpt.AutoPost.Channel)

	if rRecap.UseOneSettings then
		RecapOptCheck_UseOneSettings:SetChecked(1)
	else
		RecapOptCheck_UseOneSettings:SetChecked(0)
	end

	-- set check state for all checked options
	for i in pairs(rOpt) do
		if RecapOptFrame and rOpt[i] and rOpt[i].type=="Check" then
			if rOpt[i].value==true then
				_G["RecapOptCheck_"..i]:SetChecked(1)
			else
				_G["RecapOptCheck_"..i]:SetChecked(0)
			end
		end
	end

	-- set options for sync
	Recap_SetSyncDisplay()

	set_anchor_buttons()
end

function RecapOpt_OnMouseDown(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapOptFrame:StartMoving()
	end
end

function RecapOpt_OnMouseUp(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapOptFrame:StopMovingOrSizing()
	end
end

function Recap_AutoFadeSlider_OnValueChanged(frame, value)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and value then
		RecapAutoFadeSlider_Text:SetText(value.." "..rLocalize.Seconds)
		rOpt.AutoFadeTimer.value = value
	end
end

function Recap_SetScaleSlider_OnValueChanged(frame, value)

	local rTemp = _G.recap_temp
	local newValue, newScale

	if rTemp.Loaded then
		newScale = Recap_Div2(value, 100)
		-- feedback on value, though underlying value will not change until mouseup
		RecapSetScaleSlider_Text:SetText(newScale)
	end
end

function Recap_SetScaleSlider_OnMouseUp(frame, button)

	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local newValue, newScale

	if rTemp.Loaded then

		newValue = RecapSetScaleSlider:GetValue()
		newScale = Recap_Div2(newValue,100)

		if (newValue ~= rOpt.SetScale.value) then
			-- only do all the update stuff if there is a scale change

			-- scale everything
			rOpt.SetScale.value = newValue
			RecapSetScaleSlider_Text:SetText(newScale)
			RecapFrame:SetScale(newScale)
			RecapOptFrame:SetScale(newScale)
			RecapClipFrame:SetScale(newScale)
			RecapPanel:SetScale(newScale)
			RecapRecent:SetScale(newScale)
			RecapLoad:SetScale(newScale)
			RecapGraph:SetScale(newScale)
			RecapMenu:SetScale(newScale)
			rTemp.RecapTooltip:SetScale(newScale)

			-- because I haven't been able to figure out how to keep panels in a sensible position, move them to the centre of the screen
			RecapFrame:ClearAllPoints()
			RecapFrame:SetPoint("CENTER","UIParent","CENTER")
			RecapOptFrame:ClearAllPoints()
			RecapOptFrame:SetPoint("CENTER","UIParent","CENTER")
			RecapClipFrame:ClearAllPoints()
			if rUser.ClipFrameAnchor.value then
				RecapClipFrame:SetPoint(rUser.ClipFrameAnchor.ClipFrame,"RecapFrame",rUser.ClipFrameAnchor.Main,Recap_ClipFrameOffset("x"),Recap_ClipFrameOffset("y"))
			else
				RecapClipFrame:SetPoint("CENTER","UIParent","CENTER")
			end
			RecapPanel:ClearAllPoints()
			if rUser.PanelAnchor.value then
				RecapPanel:SetPoint(rUser.PanelAnchor.Panel,"RecapFrame",rUser.PanelAnchor.Main,Recap_PanelOffset("x"),Recap_PanelOffset("y"))
			else
				RecapPanel:SetPoint("CENTER","UIParent","CENTER")
			end
			RecapRecent:ClearAllPoints()
			if rUser.RecentAnchor.value then
				RecapRecent:SetPoint(rUser.RecentAnchor.Recent,"RecapFrame",rUser.RecentAnchor.Main,Recap_RecentOffset("x"),Recap_RecentOffset("y"))
			else
				RecapRecent:SetPoint("CENTER","UIParent","CENTER")
			end
			RecapLoad:ClearAllPoints()
			if rUser.LoadAnchor.value then
				RecapLoad:SetPoint(rUser.LoadAnchor.Load,"RecapFrame",rUser.LoadAnchor.Main,Recap_LoadOffset("x"),Recap_LoadOffset("y"))
			else
				RecapLoad:SetPoint("CENTER","UIParent","CENTER")
			end
			RecapGraph:ClearAllPoints()
			if rUser.GraphAnchor.value then
				RecapGraph:SetPoint(rUser.GraphAnchor.Graph,"RecapFrame",rUser.GraphAnchor.Main,Recap_GraphOffset("x"),Recap_GraphOffset("y"))
			else
				RecapGraph:SetPoint("CENTER","UIParent","CENTER")
			end

			-- other redisplay goodness
			rUser.Pinned = false
			Recap_SetView()
			RecapFrame_Show()
			Recap_Maximize()
			RecapFrame:SetAlpha(1)
			rTemp.FadeTimer = -1
			if RecapLoad:IsVisible() then
				RecapLoad_Show()
			end
		end
	end
end

function Recap_IdleFightSlider_OnValueChanged(frame, value)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and value then
		RecapIdleFightSlider_Text:SetText(value.." "..rLocalize.Seconds)
		rOpt.IdleFightTimer.value = value
	end
end

function Recap_EndFightDelaySlider_OnValueChanged(frame, value)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and value then
		RecapEndFightDelaySlider_Text:SetText(value.." "..rLocalize.Seconds)
		rOpt.EndFightDelay.value = value
	end
end

function Recap_RecentEventCountSlider_OnValueChanged(frame, value)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and value then
		if rOpt.RecentData.value then
			-- Recent Data Mode enabled, force slider value back to where it was
			RecapRecentEventCountSlider:SetValue(rOpt.RecentEventCount.value / 2000)
			RecapRecentEventCountSlider_Text:SetText(rOpt.RecentEventCount.value.." "..rLocalize.Events)
		else
			RecapRecentEventCountSlider_Text:SetText(2000 * value.." "..rLocalize.Events)
			rOpt.RecentEventCount.value = 2000 * value
		end
	end
end

function Recap_MaxRowsSlider_OnValueChanged(frame, value)
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and value then
		RecapMaxRowsSlider_Text:SetText(value.." "..rLocalize.Rows)
		rOpt.MaxRows.value = value
		if not rUser.Minimized then
			RecapScrollBar_Update()
		end
		if RecapLoad:IsVisible() then
			RecapLoad_Show()
		end
	end
end

function Recap_MaxRankSlider_OnValueChanged(frame, value)
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	if rTemp.Loaded and value then
		RecapMaxRankSlider_Text:SetText(value)
		rOpt.MaxRank.value = value
	end
end


function RecapOptCheck_OnEnter(frame)

	local id = frame:GetID()
	local rOptList = _G.recap_temp.OptList
	if rOptList[id][1] == "ShowTooltips" then
		-- special treatment for the "ShowTooltips" tooltip, always shown even when the option is turned off
		Recap_AlwaysTooltip(frame, rOptList[id][2], rOptList[id][3])
	else
		-- normal case
		Recap_MultilineTooltip(frame, rOptList[id][2], rOptList[id][3])
	end
end

function RecapOptCheck_OnClick(frame, button, down)

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rOptList = _G.recap_temp.OptList
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	local i
	local id = frame:GetID()

	RecapSetEditBox:ClearFocus()

	if id>0 and rOptList[id][1] then
		i = _G["RecapOptCheck_"..rOptList[id][1]]:GetChecked()
		if i==1 then
			rOpt[rOptList[id][1]].value = true
			PlaySound("igMainMenuOptionCheckBoxOn")
		else
			rOpt[rOptList[id][1]].value = false
			PlaySound("igMainMenuOptionCheckBoxOff")
		end

		-- if display list or self checks
		if ((id>=11 and id<=16) or (id>=26 and id<=27) or (id>=30 and id<=34) or (id>=43 and id<=45) or (id==64) or (id>=70 and id<=71) or (id==95) or (id==100)) then
			if not rUser.SelfView and not rUser.Minimized then
				Recap_Maximize()
			end
			if RecapLoad:IsVisible() then
				RecapLoad_Show()
			end
		elseif ((id>=48 and id<=62) or (id==69) or (id>=80 and id<=86)) and rUser.SelfView and not rUser.Minimized then
			Recap_Maximize()
		-- if display minimized checks
		elseif ((id>=17 and id<=22) or id==36 or id==75 or id==89 or id==90 or id==93) and rUser.Minimized then
			Recap_Minimize()
		elseif rOptList[id][1]=="ShowTooltips" then
			rTemp.RecapTooltip:Hide()
			Recap_Tooltip(frame, "ShowTooltips")
		elseif rOptList[id][1]=="HideGroup" then
			Recap_SetView()
			RecapLoad_SetView()
		elseif rOptList[id][1]=="HideOthers" then
			if rOpt.StoreOnlyDisplayed.value and rOpt.HideOthers.value and rOpt.AutoSaveBossFights.value then
				-- just turned this feature on, and it is incompatible with a particular combination of settings, so block and warn
				rOpt.HideOthers.value = false
				RecapOptCheck_HideOthers:SetChecked(0)
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.CONFIRMHIDEOTHERS"] = {
					text = rLocalize.IncompatibleCombination,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMHIDEOTHERS")
			else
				Recap_SetView()
				RecapLoad_SetView()
			end
		elseif rOptList[id][1]=="HideZero" then
			Recap_SetView()
			RecapLoad_SetView()
		elseif rOptList[id][1]=="HideYardTrash" then
			Recap_SetView()
			RecapLoad_SetView()
		elseif rOptList[id][1]=="StoreOnlyDisplayed" then
			if rOpt.StoreOnlyDisplayed.value and rOpt.HideOthers.value and rOpt.AutoSaveBossFights.value then
				-- just turned this feature on, and it is incompatible with a particular combination of settings, so block and warn
				rOpt.StoreOnlyDisplayed.value = false
				RecapOptCheck_StoreOnlyDisplayed:SetChecked(0)
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.CONFIRMSTOREONLY"] = {
					text = rLocalize.IncompatibleCombination,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMSTOREONLY")
			else
				-- not sure this is even necessary since it affects only future storage, and not immediate display
				Recap_SetView()
				RecapLoad_SetView()
			end
		elseif rOptList[id][1]=="AutoSaveBossFights" then
			if rOpt.StoreOnlyDisplayed.value and rOpt.HideOthers.value and rOpt.AutoSaveBossFights.value then
				-- just turned this feature on, and it is incompatible with a particular combination of settings, so block and warn
				rOpt.AutoSaveBossFights.value = false
				RecapOptCheck_AutoSaveBossFights:SetChecked(0)
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.CONFIRMSAVEBOSS"] = {
					text = rLocalize.IncompatibleCombination,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMSAVEBOSS")
			end
		elseif rOptList[id][1]=="IdleFight" then
			if rUser.State=="Active" then
				if rOpt.IdleFight.value then
					rTemp.IdleTimer = 0
				else
					rTemp.IdleTimer = -1
				end
			end
		elseif rOptList[id][1]=="TooltipFollow" then
			Recap_Tooltip(frame, "TooltipFollow")
		elseif rOptList[id][1]=="AutoHide" then
			if not rOpt.AutoHide.value then
				-- if we just turned the feature off, show the main frame regardless of combat status
				RecapFrame_Show()
			end
		elseif rOptList[id][1]=="AutoFade" then
			if (rOpt.AutoFade.value == false) then
				-- just turned off, make recap appear
				RecapFrame_Show()
			end
			rTemp.FadeTimer = -1
		elseif rOptList[id][1]=="MergePets" then
			if rOpt.MergePets.value then
				-- merging, nothing special to do
			else
				-- end of merge, remove any existing merged effects (but not if in synchronization)
				if not ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
					Recap_RemovePetEffects()
					Recap_SetView()
				end
			end

		elseif rOptList[id][1]=="IgnoreGUIDs" then
			if ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				-- ignore if in synchronization
				-- as with MergePets, there will be anomalies if a Saved Data Set is loaded from a different GUID choice
				rOpt.IgnoreGUIDs.value = not rOpt.IgnoreGUIDs.value
				if rOpt.IgnoreGUIDs.value then
					RecapOptCheck_IgnoreGUIDs:SetChecked(1)
				else
					RecapOptCheck_IgnoreGUIDs:SetChecked(0)
				end
				PlaySound("igQuestFailed")
				Recap_WarnNotAllowedDuringSync()
			else
				-- this option forces a Reset, so ask for confirmation
				if rOpt.IgnoreGUIDs.value then
					msg = rLocalize.ConfirmIgnoreGUIDs
				else
					msg = rLocalize.ConfirmUseGUIDs
				end
				StaticPopupDialogs["rTemp.CONFIRMIGNOREGUIDS"] = {
					text = msg,
					button1 = ACCEPT,
					button2 = CANCEL,
					OnAccept = function(self)
						if rOpt.IgnoreGUIDs.value then
							-- disallow sync
							rOpt.EnableSync.value = false
							rUser.SyncState = "Ignore"
							rUser.SyncTimestamp = false
							rUser.SyncLeader = false
							rUser.SyncMergePets = false
							rUser.SyncUpdateWhen = false
							rTemp.SyncInviteTimestamp = false
							rTemp.SyncInviteLeader = false
							rTemp.SyncInviteWhen = false
							rTemp.SyncInviteNewOngoing = false
							rTemp.AskingJoinSync = false
							rTemp.SyncData = wipe(rTemp.SyncData)
							rTemp.SyncMembers = wipe(rTemp.SyncMembers)
							rTemp.OnCommReceived = false
							Recap_SetSyncDisplay()
							-- shortened player name
							rTemp.PlayerGUID = rTemp.Player
						else
							-- player name with GUID
							local g = (UnitGUID("player"))
							if g then
								rTemp.PlayerGUID = rTemp.Player.."_"..Recap_TrimGUID(g)
							end
						end
						-- force a Reset
						RecapPanel_Hide(1)
						RecapRecent_Hide(1)
						RecapLoad_Hide()
						Recap_ResetAllCombatants(false)
						RecapGraph_InitializeLiveLists()
						Recap_SetView()
						Recap_MakeFriends(true)
					end,
					OnHide = function(self)
						RecapOptCheck_IgnoreGUIDs:Enable()
					end,
					OnCancel = function(self)
						rOpt.IgnoreGUIDs.value = not rOpt.IgnoreGUIDs.value
						if rOpt.IgnoreGUIDs.value then
							RecapOptCheck_IgnoreGUIDs:SetChecked(1)
						else
							RecapOptCheck_IgnoreGUIDs:SetChecked(0)
						end
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMIGNOREGUIDS")
				RecapOptCheck_IgnoreGUIDs:Disable()
			end

		elseif rOptList[id][1]=="LDBSupport" then
			if rOpt.LDBSupport.value then
				-- enable
				Recap_EnableLDBSupport()
				Recap_DisplayMinimizedDPS() -- also sends to plugins
			else
				-- disable by forcing a UI reload (doesn't seem to be any mechanism for dynamically disabling an LDB data source)
				StaticPopupDialogs["rTemp.CONFIRMDISABLELDBSUPPORT"] = {
					text = rLocalize.ConfirmDisableLDBSupport,
					button1 = ACCEPT,
					button2 = CANCEL,
					OnAccept = function(self)
						ReloadUI()
					end,
					OnCancel = function(self)
						rOpt.LDBSupport.value = true
						RecapOptCheck_LDBSupport:SetChecked(1)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMDISABLELDBSUPPORT")
			end

		elseif rOptList[id][1]=="GrowLeftwards" or rOptList[id][1]=="GrowUpwards" or rOptList[id][1]=="AutoMinimize" then
			Recap_MoveMinimize()
			if rUser.Minimized then
				Recap_Minimize()
			end
			if RecapLoad:IsVisible() then
				RecapLoad_Show()
			end
		elseif rOptList[id][1]=="ShowPanel" then
			if RecapPanel:IsVisible() then
				RecapPanel_Hide(1)
			end
		elseif rOptList[id][1]=="OpaqueBackground" then
			Recap_SetRecapFrameBackdrop()
			if RecapLoad:IsVisible() then
				RecapLoad_Show()
			end
		elseif rOptList[id][1]=="MinimizeOnEscape" then
			local k, m
			for k,m in ipairs(UISpecialFrames) do
				if rUser.Minimized or not rOpt.MinimizeOnEscape.value then
					-- a dummy if we are minimized or have Minimize on Escape turned off, so that we don't capture Escape when minimized
					if m == "RecapFrame" then
						UISpecialFrames[k] = "RecapFrameDummy"
					end
				else
					if m == "RecapFrameDummy" then
						UISpecialFrames[k] = "RecapFrame"
					end
				end
			end

		elseif rOptList[id][1]=="EnableSync" then
			if rOpt.IgnoreGUIDs.value then
				-- paranoia check, should in theory not get here
				rOpt.EnableSync.value = not rOpt.EnableSync.value
				if rOpt.EnableSync.value then
					RecapOptCheck_EnableSync:SetChecked(1)
				else
					RecapOptCheck_EnableSync:SetChecked(0)
				end
				PlaySound("igQuestFailed")
			else
				if rOpt.EnableSync.value then
					rUser.SyncState = "Ready"
				else
					rUser.SyncState = "Ignore"
				end
				-- clear all sync values (including the spinlocks)
				rUser.SyncTimestamp = false
				rUser.SyncLeader = false
				rUser.SyncMergePets = false
				rUser.SyncUpdateWhen = false
				rTemp.SyncInviteTimestamp = false
				rTemp.SyncInviteLeader = false
				rTemp.SyncInviteWhen = false
				rTemp.SyncInviteNewOngoing = false
				rTemp.AskingJoinSync = false
				rTemp.SyncData = wipe(rTemp.SyncData)
				rTemp.SyncMembers = wipe(rTemp.SyncMembers)
				rTemp.OnCommReceived = false
				Recap_SetSyncDisplay()
				Recap_SetState(false)
			end

		elseif rOptList[id][1]=="LightData" then
			if rOpt.LightData.value then
				msg = rLocalize.ConfirmLightData
			else
				msg = rLocalize.ConfirmHeavyData
			end
			StaticPopupDialogs["rTemp.CONFIRMLIGHTDATAMODE"] = {
				text = msg,
				button1 = ACCEPT,
				button2 = CANCEL,
				OnAccept = function(self)
					if rOpt.LightData.value then
						-- if going light, nuke all detailed data
						local i, iCombatant
						for i, iCombatant in pairs(rCombatants) do
							if iCombatant.OutgoingDetail then
								iCombatant.OutgoingDetail = nil -- keep as nil
							end
							if iCombatant.TargetDetail then
								iCombatant.TargetDetail = nil -- keep as nil
							end
							if iCombatant.IncomingDetail then
								iCombatant.IncomingDetail = nil -- keep as nil
							end
							if iCombatant.SourceDetail then
								iCombatant.SourceDetail = nil -- keep as nil
							end
							if iCombatant.OtherDetail then
								iCombatant.OtherDetail = nil -- keep as nil
							end
							if iCombatant.LastOutgoingDetail_1 then
								iCombatant.LastOutgoingDetail_1 = nil -- keep as nil
							end
							if iCombatant.LastTargetDetail_1 then
								iCombatant.LastTargetDetail_1 = nil -- keep as nil
							end
							if iCombatant.LastIncomingDetail_1 then
								iCombatant.LastIncomingDetail_1 = nil -- keep as nil
							end
							if iCombatant.LastSourceDetail_1 then
								iCombatant.LastSourceDetail_1 = nil -- keep as nil
							end
							if iCombatant.LastOtherDetail_1 then
								iCombatant.LastOtherDetail_1 = nil -- keep as nil
							end
							if iCombatant.LastOutgoingDetail_2 then
								iCombatant.LastOutgoingDetail_2 = nil -- keep as nil
							end
							if iCombatant.LastTargetDetail_2 then
								iCombatant.LastTargetDetail_2 = nil -- keep as nil
							end
							if iCombatant.LastIncomingDetail_2 then
								iCombatant.LastIncomingDetail_2 = nil -- keep as nil
							end
							if iCombatant.LastSourceDetail_2 then
								iCombatant.LastSourceDetail_2 = nil -- keep as nil
							end
							if iCombatant.LastOtherDetail_2 then
								iCombatant.LastOtherDetail_2 = nil -- keep as nil
							end
						end
					end
				end,
				OnHide = function(self)
					RecapOptCheck_LightData:Enable()
				end,
				OnCancel = function(self)
					rOpt.LightData.value = not rOpt.LightData.value
					if rOpt.LightData.value then
						RecapOptCheck_LightData:SetChecked(1)
					else
						RecapOptCheck_LightData:SetChecked(0)
					end
				end,
				timeout = 30,
				showAlert = 1,
				whileDead = 1
			}

			RecapOptCheck_LightData:Disable()
			StaticPopup_Show("rTemp.CONFIRMLIGHTDATAMODE")

		elseif rOptList[id][1]=="RecentData" then
			if rUser.State=="Active" then
				-- not permitted during combat
				rOpt.RecentData.value = not rOpt.RecentData.value
				if rOpt.RecentData.value then
					RecapOptCheck_RecentData:SetChecked(1)
				else
					RecapOptCheck_RecentData:SetChecked(0)
				end
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.CONFIRMRECENTDATAMODE"] = {
					text = rLocalize.NotAllowedDuringCombat,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.CONFIRMRECENTDATAMODE")
			else
				-- put into Stopped state for additional protection
				rTemp.SkipPeriodicUpdate = true -- skip periodic update
				local current_state = rUser.State
				rUser.State = "Stopped"

				if rOpt.RecentData.value then
					-- note that the number of recent events cannot be changed while Recent Data Mode is active (too messy to change circular buffer size dynamically)
					Recap_CreateRecent()
					-- immediately enable all the recent event buttons
					for i=1,15 do
						_G["RecapRecentSelf"..i.."_Text"]:SetTextColor(unpack(rColor.Green))
						_G["RecapRecentSelf"..i.."_SaveColor"]:SetTextColor(unpack(rColor.Green))
						_G["RecapRecentSelf"..i]:Enable()
						_G["RecapRecentList"..i.."_Text"]:SetTextColor(_G["RecapList"..i.."_Name"]:GetTextColor())
						_G["RecapRecentList"..i.."_SaveColor"]:SetTextColor(_G["RecapList"..i.."_Name"]:GetTextColor())
						_G["RecapRecentList"..i]:Enable()
					end
					for i=1,7 do
						_G["RecapPanelIncomingRecent"..i.."_Text"]:SetTextColor(_G["RecapPanelIncomingDetail"..i.."_Name"]:GetTextColor())
						_G["RecapPanelIncomingRecent"..i.."_SaveColor"]:SetTextColor(_G["RecapPanelIncomingDetail"..i.."_Name"]:GetTextColor())
						_G["RecapPanelIncomingRecent"..i]:Enable()
						_G["RecapPanelOutgoingRecent"..i.."_Text"]:SetTextColor(_G["RecapPanelOutgoingDetail"..i.."_Name"]:GetTextColor())
						_G["RecapPanelOutgoingRecent"..i.."_SaveColor"]:SetTextColor(_G["RecapPanelOutgoingDetail"..i.."_Name"]:GetTextColor())
						_G["RecapPanelOutgoingRecent"..i]:Enable()
					end
					RecapEventsButton:Enable()
					RecapDispelsAndInterruptsButton:Enable()
					RecapDeathsButton:Enable()
				else
					rTemp.Recent = wipe(rTemp.Recent)
					rTemp.RecentFriendDeaths = wipe(rTemp.RecentFriendDeaths)
					for i=1,15 do
						_G["RecapRecentSelf"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapRecentSelf"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapRecentSelf"..i]:Disable()
						_G["RecapRecentList"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapRecentList"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapRecentList"..i]:Disable()
					end
					for i=1,7 do
						_G["RecapPanelIncomingRecent"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapPanelIncomingRecent"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapPanelIncomingRecent"..i]:Disable()
						_G["RecapPanelOutgoingRecent"..i.."_Text"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapPanelOutgoingRecent"..i.."_SaveColor"]:SetTextColor(0.5, 0.5, 0.5)
						_G["RecapPanelOutgoingRecent"..i]:Disable()
					end
					RecapEventsButton:Disable()
					RecapDispelsAndInterruptsButton:Disable()
					RecapDeathsButton:Disable()
				end

				-- go back to whatever we were doing
				rUser.State = current_state
				rTemp.SkipPeriodicUpdate = false -- resume periodic update
			end

		elseif rOptList[id][1]=="LiveData" then
			if rOpt.LiveData.value then
				if (recapLineGraph == nil) or (recapLineGraphPanel == nil) then
					Recap_EnableGraph()
				end
				RecapGraph_InitializeLiveLists()
				RecapGraph_GraphUpdate()
				RecapLiveGraphAndTextButton:Enable()
			else
				RecapGraph_ClearLiveLists()
				RecapGraphGraph:Hide()
				RecapGraphText:Hide()
				RecapGraphOptions:Hide()
				RecapGraph:Hide()
				RecapLiveGraphAndTextButton:Disable()
			end

		elseif rOptList[id][1]=="LimitToEncounters" then
			if rUser.State=="Active" then
				-- not permitted during combat
				rOpt.LimitToEncounters.value = not rOpt.LimitToEncounters.value
				if rOpt.LimitToEncounters.value then
					RecapOptCheck_LimitToEncounters:SetChecked(1)
				else
					RecapOptCheck_LimitToEncounters:SetChecked(0)
				end
				PlaySound("igQuestFailed")
				StaticPopupDialogs["rTemp.LIMITENCOUNTERSBLOCKED"] = {
					text = rLocalize.NotAllowedDuringCombat,
					button1 = OKAY,
					OnAccept = function(self)
					end,
					timeout = 30,
					showAlert = 1,
					whileDead = 1
				}
				StaticPopup_Show("rTemp.LIMITENCOUNTERSBLOCKED")
			end

		elseif rOptList[id][1]=="ShowGauges" then
			if not rUser.Minimized then
				RecapScrollBar_Update()
			end
			if RecapLoad:IsVisible() then
				RecapLoad_Show()
			end

		elseif rOptList[id][1]=="PauseOutsideInstances" then
			-- do the right thing
			Recap_CheckInstanceBattleground()

		elseif rOptList[id][1]=="PauseInsideBattlegrounds" then
			-- do the right thing
			Recap_CheckInstanceBattleground()

		elseif rOptList[id][1]=="HTML" then
			if rOpt.HTML.value then
				-- turn off the other format option
				rOpt.TabDelimited.value = false
				RecapOptCheck_TabDelimited:SetChecked(0)
			end

		elseif rOptList[id][1]=="TabDelimited" then
			if rOpt.TabDelimited.value then
				-- turn off the other format option
				rOpt.HTML.value = false
				RecapOptCheck_HTML:SetChecked(0)
			end
		end
	end
end

function Recap_UseOneSettings_OnClick(frame, button, down)

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	local i, msg

	i = RecapOptCheck_UseOneSettings:GetChecked()
	if i==1 then
		rRecap.UseOneSettings = true
		PlaySound("igMainMenuOptionCheckBoxOn")
		msg = rLocalize.ConfirmGlobalSettings
	else
		rRecap.UseOneSettings = false
		PlaySound("igMainMenuOptionCheckBoxOff")
		msg = rLocalize.ConfirmSeparateSettings
	end

	StaticPopupDialogs["rTemp.CONFIRMONESETTING"] = {
		text = msg,
		button1 = ACCEPT,
		button2 = CANCEL,
		OnAccept = function(self)
			if rRecap.UseOneSettings then
				-- going global
				if not rRecap.GlobalOpt then
					-- create with default values
					rRecap.GlobalOpt = {}
					Recap_CloneOpt(rTemp.DefaultOpt, rRecap.GlobalOpt)
				end
				-- get rid of any obsolete options
				Recap_ProcessObsoleteOptions(rRecap.GlobalOpt)
			else
				-- going per character
				if not rUser.Opt then
					-- create with default values
					rUser.Opt = {}
					Recap_CloneOpt(rTemp.DefaultOpt, rUser.Opt)
				end
				-- get rid of any obsolete options
				Recap_ProcessObsoleteOptions(rUser.Opt)
			end
			ReloadUI()
		end,
		OnHide = function(self)
			RecapOptCheck_UseOneSettings:Enable()
		end,
		OnCancel = function(self)
			rRecap.UseOneSettings = not rRecap.UseOneSettings
			if rRecap.UseOneSettings then
				RecapOptCheck_UseOneSettings:SetChecked(1)
			else
				RecapOptCheck_UseOneSettings:SetChecked(0)
			end
		end,
		timeout = 30,
		showAlert = 1,
		whileDead = 1
	}

	RecapOptCheck_UseOneSettings:Disable()
	StaticPopup_Show("rTemp.CONFIRMONESETTING")

end

function Recap_CopyGlobalSettingsToCharacter()
	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rTemp = _G.recap_temp
	if not rRecap.GlobalOpt then
		-- create default globals
		rRecap.GlobalOpt = {}
		Recap_CloneOpt(rTemp.DefaultOpt, rRecap.GlobalOpt)
	end
	-- get rid of any obsolete options
	Recap_ProcessObsoleteOptions(rRecap.GlobalOpt)
	-- copy globals to the character
	if type(rUser.Opt) == "table" then
		rUser.Opt = wipe(rUser.Opt)
	else
		rUser.Opt = {}
	end
	Recap_CloneOpt(rRecap.GlobalOpt, rUser.Opt)
	-- following not localized
	print("Recap copied Global Settings to:", rTemp.Player)
	-- if using per character settings, reload the UI
	if not rRecap.UseOneSettings then
		ReloadUI()
	end
end

--[[ Fight Data Set functions ]]

function Recap_InitDataSets()
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	if RecapOptTitle then

		RecapFightDataSetHeader_Name:SetTextColor(unpack(rColor.None))
		RecapFightDataSetHeader_Date:SetTextColor(unpack(rColor.None))
		RecapFightDataSetHeader_Duration:SetTextColor(unpack(rColor.None))
		RecapFightDataSetHeader_Combatants:SetTextColor(unpack(rColor.None))

		RecapSaveAllButton:Disable()
		RecapSaveLastButton:Disable()
		RecapLoadButton:Disable()
		RecapLoadOverAllFightsButton:Disable()
		RecapDeleteButton:Disable()
		RecapDeleteAllButton:Enable()
		RecapRenameButton:Disable()

		Recap_BuildFightSets()

		RecapOptTitle:SetFormattedText("%s v%.3f %s %s %s %s", rTemp.Recap, Recap_Version, rLocalize.For, rTemp.Player, rLocalize.Of, rTemp.Server)
	end
end

function Recap_SetEditValidateButtons()

	local rTemp = _G.recap_temp
	local text, sel

	if rTemp.Loaded then

		-- default settings, may get overridden
		RecapSaveAllButton:Disable()
		RecapSaveLastButton:Disable()
		RecapLoadButton:Disable()
		RecapLoadOverAllFightsButton:Disable()
		RecapDeleteButton:Disable()
		RecapDeleteAllButton:Enable()
		RecapRenameButton:Disable()
		RecapOpt_DataSetSelectionMessage:SetText("")

		text = RecapSetEditBox:GetText()

		if text and text~="" then
			sel = Recap_SetExists(text)
			if sel == 0 then
				-- text doesn't match any data set, clear selections
				rTemp.FightSetSelected = 0
				rTemp.FightSetSelectedOther = 0
				-- allow saves
				RecapSaveAllButton:Enable()
				RecapSaveLastButton:Enable()
			else
				-- text matches a data set
				if (sel ~= rTemp.FightSetSelected) and (sel ~= rTemp.FightSetSelectedOther) then
					-- text doesn't match either selection, make it a single select
					rTemp.FightSetSelected = sel
					rTemp.FightSetSelectedOther = 0
				end
			end
		else
			-- no text
		end

		-- is there a selection?
		if (rTemp.FightSetSelected ~= 0) then
			if rTemp.FightSetSelectedOther == rTemp.FightSetSelected then
				-- pointers match, single select after all
				rTemp.FightSetSelectedOther = 0
			end
			-- what kind of selection?
			if rTemp.FightSetSelectedOther == 0 then
				-- single select
				-- allow load
				RecapLoadButton:Enable()
				RecapLoadOverAllFightsButton:Enable()
				-- allow deletes
				RecapDeleteButton:Enable()
				RecapDeleteAllButton:Enable()
				-- allow rename
				RecapRenameButton:Enable()
				-- message
				RecapOpt_DataSetSelectionMessage:SetText("1 "..rLocalize.DataSetSelected)
			else
				-- range select
				-- allow delete but not delete all (to minimize user misclicks)
				RecapDeleteButton:Enable()
				RecapDeleteAllButton:Disable()
				RecapOpt_DataSetSelectionMessage:SetText("")
				-- message
				local num = math_abs(rTemp.FightSetSelectedOther - rTemp.FightSetSelected) + 1
				RecapOpt_DataSetSelectionMessage:SetText(num.." "..rLocalize.DataSetsSelected)
			end
		else
			-- no selection
		end
		RecapFightSetsScrollBar_Update()
	end
end

-- populates recap_temp.FightSets with a list of existing fight sets
function Recap_BuildFightSets()

	local rSet = _G.recap_set
	local rTemp = _G.recap_temp
	local i, j, friendly

	-- make sure recap_temp.FightSets begins empty for 'table.sort'
	rTemp.FightSetsSize = 1
	rTemp.FightSets = wipe(rTemp.FightSets)

	for i in pairs(rSet) do
		if rSet[i] and not string_find(i, "^UserData:") then
			if not rTemp.FightSets[rTemp.FightSetsSize] then
				rTemp.FightSets[rTemp.FightSetsSize] = {}
			end
			rTemp.FightSets[rTemp.FightSetsSize].Name = i
			rTemp.FightSets[rTemp.FightSetsSize].Date = rSet[i].TimeStamp
			rTemp.FightSets[rTemp.FightSetsSize].Duration = Recap_FormatTime(math_max(rSet[i].TotalDuration, rSet[i].TotalDurationIn, rSet[i].TotalDurationHeal))
			friendly = 0
			if rSet[i].Combatant then
				for j in pairs(rSet[i].Combatant) do
					-- new split format from version 4.25
					if rSet[i].Combatant[j].Base then
						if string_find(rSet[i].Combatant[j].Base, "^true") then
							friendly = friendly + 1
						end
					end
				end
			end
			if rSet[i].ListSize then
				rTemp.FightSets[rTemp.FightSetsSize].Combatants = rSet[i].ListSize .. " ("..friendly..")"
			else
				-- anomalous with 5.0.4, reason not known
				-- actually, probably due to running out of time during AutoSave earlier, so this may now be fixed
				rTemp.FightSets[rTemp.FightSetsSize].Combatants = "n/a" .. " ("..friendly..")"
			end
			rTemp.FightSetsSize = rTemp.FightSetsSize + 1
		end
	end

	table_sort(rTemp.FightSets,Recap_SetSort)

	local estSize = Recap_Div0(Recap_EstimateSavedDataSetsSize(), 990000) -- we assume an additional overhead of about 1%
	RecapOptFightDataLabel:SetText(tostring(rTemp.FightSetsSize-1).." "..RECAP_FIGHT_DATA_SETS.." ("..tostring(estSize).." Mbytes)")
end

function RecapFightSetsScrollBar_Update()

	local rTemp = _G.recap_temp
	local i, index, item, selStart, selEnd

	if rTemp.Loaded then

		FauxScrollFrame_Update(RecapFightSetsScrollBar,rTemp.FightSetsSize-1,10,12)

		-- calculate selection range
		selStart = 0
		selEnd = 0
		if rTemp.FightSetSelected ~= 0 then
			-- selection
			if rTemp.FightSetSelectedOther == 0 then
				-- single select
				selStart = rTemp.FightSetSelected
				selEnd = selStart
			else
				-- range select
				if rTemp.FightSetSelected <= rTemp.FightSetSelectedOther then
					selStart = rTemp.FightSetSelected
					selEnd = rTemp.FightSetSelectedOther
				else
					selStart = rTemp.FightSetSelectedOther
					selEnd = rTemp.FightSetSelected
				end
			end
		end

		for i=1,10 do
			index = i + FauxScrollFrame_GetOffset(RecapFightSetsScrollBar)
			if index < rTemp.FightSetsSize then
				_G["RecapSetsList"..i.."Back"]:Hide()
				_G["RecapFightDataList"..i.."_Name"]:SetText(rTemp.FightSets[index].Name)
				_G["RecapFightDataList"..i.."_Date"]:SetText(rTemp.FightSets[index].Date)
				_G["RecapFightDataList"..i.."_Duration"]:SetText(rTemp.FightSets[index].Duration)
				_G["RecapFightDataList"..i.."_Combatants"]:SetText(rTemp.FightSets[index].Combatants)
				item = _G["RecapFightDataList"..i]
				item:Show()
				if (index >= selStart) and (index <= selEnd) then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapFightDataList"..i]
				item:Hide()
				item:UnlockHighlight()
				_G["RecapSetsList"..i.."Back"]:Show()
			end
		end
	end
end

function RecapFightData_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local index
	local id = frame:GetID()

	RecapSetEditBox:ClearFocus()

	index = id + FauxScrollFrame_GetOffset(RecapFightSetsScrollBar)

	if index < rTemp.FightSetsSize then

		if (rTemp.FightSetSelected ~= 0) and IsShiftKeyDown() then
			-- range select
			if index == rTemp.FightSetSelected then
				-- pointers match, single select after all
				rTemp.FightSetSelectedOther = 0
			else
				rTemp.FightSetSelectedOther = index
			end
		else
			-- single select
			if index == rTemp.FightSetSelected then
				-- this is what we had selected, de-select instead
				index = 0
			end
			rTemp.FightSetSelected = index
			rTemp.FightSetSelectedOther = 0
		end
		if index == 0 then
			RecapSetEditBox:SetText("")
		else
			RecapSetEditBox:SetText(rTemp.FightSets[index].Name)
		end
		Recap_SetEditValidateButtons()
	end
end

function Recap_DeleteSomeFightDataSets()

	local rSet = _G.recap_set
	local rTemp = _G.recap_temp
	local i, selStart, selEnd, filen

	-- calculate selection range
	selStart = 0
	selEnd = 0
	if rTemp.FightSetSelected ~= 0 then
		-- selection
		if rTemp.FightSetSelectedOther == 0 then
			-- single select
			selStart = rTemp.FightSetSelected
			selEnd = selStart
		else
			-- range select
			if rTemp.FightSetSelected <= rTemp.FightSetSelectedOther then
				selStart = rTemp.FightSetSelected
				selEnd = rTemp.FightSetSelectedOther
			else
				selStart = rTemp.FightSetSelectedOther
				selEnd = rTemp.FightSetSelected
			end
		end
	end

	-- delete range
	for i = selStart, selEnd do
		if i < rTemp.FightSetsSize then
			filen = rTemp.FightSets[i].Name
			if rSet[filen] then
				rSet[filen] = nil -- keep as nil
			end
		end
	end

	table_sort(rTemp.FightSets,Recap_SetSort)

	local estSize = Recap_Div0(Recap_EstimateSavedDataSetsSize(), 990000) -- we assume an additional overhead of about 1%
	RecapOptFightDataLabel:SetText(tostring(rTemp.FightSetsSize-1).." "..RECAP_FIGHT_DATA_SETS.." ("..tostring(estSize).." Mbytes)")
end

function Recap_DeleteAllFightDataSets()

	local rSet = _G.recap_set
	local rTemp = _G.recap_temp
	local i

	-- make sure rTemp.FightSets begins empty for 'table.sort'
	rTemp.FightSetsSize = 1
	rTemp.FightSets = wipe(rTemp.FightSets)

	for i in pairs(rSet) do
		if rSet[i] and not string_find(i, "^UserData:") then
			rSet[i] = nil -- keep as nil
		end
	end

	table_sort(rTemp.FightSets,Recap_SetSort)

	local estSize = Recap_Div0(Recap_EstimateSavedDataSetsSize(), 990000) -- we assume an additional overhead of about 1%
	RecapOptFightDataLabel:SetText(tostring(rTemp.FightSetsSize-1).." "..RECAP_FIGHT_DATA_SETS.." ("..tostring(estSize).." Mbytes)")
end

--[[ Ignores functions ]]

function Recap_InitIgnores()
	local rColor = _G.recap_temp.Color
	local rTemp = _G.recap_temp
	if RecapOptTitle then

		RecapIgnoresHeader_SpellID:SetTextColor(unpack(rColor.None))
		RecapIgnoresHeader_SpellName:SetTextColor(unpack(rColor.None))

		RecapAddIgnoreButton:Disable()
		RecapRemoveIgnoreButton:Disable()

		Recap_BuildIgnores()

		RecapOptTitle:SetFormattedText("%s v%.3f %s %s %s %s", rTemp.Recap, Recap_Version, rLocalize.For, rTemp.Player, rLocalize.Of, rTemp.Server)
	end
end

function Recap_IgnoresValidateButtons()

	local rTemp = _G.recap_temp
	local text, index

	if rTemp.Loaded then

		text = RecapIgnoresEditBox:GetText()

		if text and text~="" then
			index = Recap_IgnoreExists(text)
			if index > 0 then
				-- already there, remove is okay
				RecapAddIgnoreButton:Disable()
				RecapRemoveIgnoreButton:Enable()
				rTemp.IgnoreSelected = index
			else
				-- not there, add is okay
				RecapAddIgnoreButton:Enable()
				RecapRemoveIgnoreButton:Disable()
				rTemp.IgnoreSelected = 0
			end
		else
			RecapAddIgnoreButton:Disable()
			RecapRemoveIgnoreButton:Disable()
		end
		RecapIgnoresScrollBar_Update()
	end
end

-- populates recap_temp.Ignores with a list of existing ignores
function Recap_BuildIgnores()

	local rIgnore = _G.recap_ignore
	local rTemp = _G.recap_temp
	local i

	-- make sure recap_temp.Ignores begins empty for 'table.sort'
	rTemp.IgnoresSize = 1
	rTemp.Ignores = wipe(rTemp.Ignores)

	for i in pairs(rIgnore) do
		if rIgnore[i] then
			if not rTemp.Ignores[rTemp.IgnoresSize] then
				rTemp.Ignores[rTemp.IgnoresSize] = {}
			end
			rTemp.Ignores[rTemp.IgnoresSize].SpellID = i
			rTemp.Ignores[rTemp.IgnoresSize].SpellName = rIgnore[i].SpellName
			rTemp.IgnoresSize = rTemp.IgnoresSize + 1
		end
	end

	table_sort(rTemp.Ignores,Recap_IgnoreSort)
end

function RecapIgnoresScrollBar_Update()

	local rTemp = _G.recap_temp
	local i, index, item

	if rTemp.Loaded then

		FauxScrollFrame_Update(RecapIgnoresScrollBar,rTemp.IgnoresSize-1,10,12)

		for i=1,10 do
			index = i + FauxScrollFrame_GetOffset(RecapIgnoresScrollBar)
			if index < rTemp.IgnoresSize then
				_G["RecapIgnoresList"..i.."Back"]:Hide()
				_G["RecapIgnoresList"..i.."_SpellID"]:SetText(rTemp.Ignores[index].SpellID)
				_G["RecapIgnoresList"..i.."_SpellName"]:SetText(rTemp.Ignores[index].SpellName)
				item = _G["RecapIgnoresList"..i]
				item:Show()
				if rTemp.IgnoreSelected == index then
					item:LockHighlight()
				else
					item:UnlockHighlight()
				end
			else
				item = _G["RecapIgnoresList"..i]
				item:Hide()
				item:UnlockHighlight()
				_G["RecapIgnoresList"..i.."Back"]:Show()
			end
		end
	end
end

function RecapIgnores_OnClick(frame, button, down)

	local rTemp = _G.recap_temp
	local id = frame:GetID()
	local index

	RecapIgnoresEditBox:ClearFocus()

	index = id + FauxScrollFrame_GetOffset(RecapIgnoresScrollBar)

	if index < rTemp.IgnoresSize then
		rTemp.IgnoreSelected = index
		RecapIgnoresEditBox:SetText(rTemp.Ignores[index].SpellID)
		RecapAddIgnoreButton:Disable()
		RecapRemoveIgnoreButton:Enable()
		RecapIgnoresScrollBar_Update()
	end
end

--[[ Options tabs ]]

function RecapOptTab_OnEnter(frame)

	local id = frame:GetID()

	if id and id>0 then
		Recap_Tooltip(frame, "OptTab"..id)
	end
end

function RecapOptTab_OnClick(frame, button, down)

	local id, i = frame:GetID()

	PlaySound("GAMEGENERICBUTTONPRESS")
	if id and id>0 then
		for i=1,6 do
			_G["RecapOptTab"..i]:UnlockHighlight()
			_G["RecapOptSubFrame"..i]:Hide()
		end
		_G["RecapOptTab"..id]:LockHighlight()
		_G["RecapOptSubFrame"..id]:Show()
		Recap_SetSyncDisplay()
	end
end

--[[ drop down lists ]]

function RecapDropMenu_OnClick(frame, button, down)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local id = frame:GetID()

	if rTemp.CurrentDrop==RecapOpt_StatDropDownButton then
		rOpt.AutoPost.Stat = _G["RecapDropMenu"..id.."_Text"]:GetText()
		RecapOpt_StatDropDownText:SetText(rOpt.AutoPost.Stat)
	else
		rOpt.AutoPost.Channel = _G["RecapDropMenu"..id.."_Text"]:GetText()
		RecapOpt_ChannelDropDownText:SetText(rOpt.AutoPost.Channel)
	end
	Recap_DropMenu:Hide()
	rTemp.CurrentDrop = false

end

function RecapDropMenu_OnEnter(frame)
	-- empty function
end

function Recap_ToggleDropDown(frame)
	local rTemp = _G.recap_temp
	if Recap_DropMenu:IsVisible() and rTemp.CurrentDrop==frame then
		Recap_DropMenu:Hide()
		rTemp.CurrentDrop = nil
	elseif rTemp.CurrentDrop~=frame and frame==RecapOpt_StatDropDownButton then
		Recap_ShowStatDrop()
		rTemp.CurrentDrop = frame
	elseif rTemp.CurrentDrop~=frame then
		Recap_ShowChannelDrop()
		rTemp.CurrentDrop = frame
	end

end

function Recap_ShowStatDrop()

	Recap_DropMenu:ClearAllPoints()
	Recap_DropMenu:SetPoint("TOPLEFT","RecapOpt_StatDropDown","BOTTOMLEFT",16,8)
	-- governs the width of the box within which the text will appear when dropped down
	Recap_DropMenu:SetWidth(130)
	Recap_PopulateDrop(rLocalize.StatDropList)
end

function Recap_ShowChannelDrop()

	local i, j, c, name
	local new_list = {}

	Recap_DropMenu:ClearAllPoints()
	Recap_DropMenu:SetPoint("TOPLEFT","RecapOpt_ChannelDropDown","BOTTOMLEFT",16,8)
	-- governs the width of the box within which the text will appear when dropped down
	Recap_DropMenu:SetWidth(130)

	for i=1,#rLocalize.ChannelDropList do
		table_insert(new_list,rLocalize.ChannelDropList[i])
	end
	for i=1,10 do
		c,name = GetChannelName(i)
		if name then
			for j=1,#rLocalize.SkipChannels do
				if string_find(name, rLocalize.SkipChannels[j], 1, true) then
					name = false
					break
				end
			end
		end
		if name then
			table_insert(new_list,c.."-"..name)
		end
	end
	Recap_PopulateDrop(new_list)
end

function Recap_PopulateDrop(thisList)

	local i
	local height = 0

	for i=1,math_min(8,#thisList) do
		-- see also Recap_DropMenuTemplate in RecapOptions.xml
		_G["RecapDropMenu"..i.."_Text"]:SetText(tostring(thisList[i]))
		-- governs how wide the text is, and whether the text gets truncated
		_G["RecapDropMenu"..i.."_Text"]:SetWidth(120)
		_G["RecapDropMenu"..i]:Show()
		height = height + 16
	end
	for i=#thisList+1,8 do
		_G["RecapDropMenu"..i]:Hide()
	end

	Recap_DropMenu:SetHeight(height+4)
	Recap_DropMenu:Show()
end

function RecapDropMenu_OnUpdate(frame, elapsed)
	local rTemp = _G.recap_temp
	if not rTemp.MenuTimer or Recap_DropMenu:IsMouseOver() or
		(rTemp.CurrentDrop and rTemp.CurrentDrop:IsMouseOver()) then
		rTemp.MenuTimer = 0
	end

	rTemp.MenuTimer = rTemp.MenuTimer + elapsed
	if rTemp.MenuTimer > 0.5 then
		rTemp.MenuTimer = 0
		Recap_DropMenu:Hide()
		rTemp.CurrentDrop = false
	end
end

function Recap_ReportFightsToClipboard()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, doneGroup, thisCombatant
	local headerformat = rLocalize.LogHeader
	local RCEB = _G.RecapClipEditBox

	RecapClipFrame:Hide()
	RCEB:SetText("")

	-- guard, just in case we accidentally have two incompatible options set
	if rOpt.HTML.value then
		rOpt.TabDelimited.value = false
	end

	if rOpt.HTML.value then
		headerformat = rLocalize.HTMLHeader
		RCEB:Insert(rLocalize.HTMLPrefix)
	end

	RCEB:Insert(string_format(headerformat,Recap_Version,Recap_PetsMergedText(),rTemp.Player,rLocalize.LastAll[rUser.View],date("%Y-%b-%d %H:%M"),GetRealZoneText()).."\n")
	if rOpt.HTML.value then
		RCEB:Insert(loglineHTML1("FirstLine","clip"))
		RCEB:Insert(loglineHTML2("FirstLine","clip"))
	else
		RCEB:Insert(logLine("FirstLine","clip"))
	end

	-- create a text string for insertion into the Clipboard
	doneGroup = false
	local ginormousText = ""
	for i=1,rTemp.ListSize-1 do
		thisCombatant = rTemp.List[i].Name
		if (not doneGroup) and thisCombatant and rCombatants[thisCombatant] and (not rCombatants[thisCombatant].Friend) then
			if not rOpt.WriteGroup.value then
				if rOpt.HTML.value then
					ginormousText = ginormousText..loglineHTML1("Spacer","clip")..loglineHTML2("Spacer","clip")
				else
					ginormousText = ginormousText..logLine("Spacer","clip")
				end
			end
			doneGroup = true
		end
		if (not doneGroup) or (not rOpt.WriteGroup.value) then
			if rOpt.HTML.value then
				ginormousText = ginormousText..loglineHTML1(i,"clip")..loglineHTML2(i,"clip")
			else
				ginormousText = ginormousText..logLine(i,"clip")
			end
		end
	end
	RCEB:Insert(ginormousText)

	if rOpt.HTML.value then
		RCEB:Insert(rLocalize.HTMLSuffix.."\n")
	end

	RecapClipFrame:Show()

	-- the following used to be in RecapOptions.xml in an OnTextChanged event
	local scrollBar = _G[RCEB:GetParent():GetParent():GetName().."ScrollBar"]
	local myMax
	, myMax = scrollBar:GetMinMaxValues()
	if ( myMax > 0 and (RCEB.max ~= myMax) ) then
		RCEB.max = myMax
		scrollBar:SetValue(myMax)
	end
	-- NOTE: the preceding code doesn't do a very good job of scrolling to the end of the clipboard, perhaps because individual lines can be so long

	RCEB:HighlightText()
	RCEB:SetFocus()
end

function Recap_ReportDetailsToClipboard()

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i
	local headerformat = rLocalize.DetailHeader
	local RCEB = _G.RecapClipEditBox

	RecapClipFrame:Hide()
	RCEB:SetText("")

	-- guard, just in case we accidentally have two incompatible options set
	if rOpt.HTML.value then
		rOpt.TabDelimited.value = false
	end

	if rOpt.HTML.value then
		headerformat = rLocalize.HTMLDetailHeader
		RCEB:Insert(rLocalize.HTMLPrefix)
	end

	RCEB:Insert(string_format(headerformat,"("..Recap_PetsMergedText()..")",rTemp.Player,date("%Y-%b-%d %H:%M"),GetRealZoneText()).."\n")
	if rOpt.HTML.value then
		RCEB:Insert(outgoingeffectlineHTML1("FirstLine","clip"))
		RCEB:Insert(outgoingeffectlineHTML2("FirstLine","clip"))
		RCEB:Insert(outgoingeffectlineHTML3("FirstLine","clip"))
	else
		RCEB:Insert(outgoingeffectline("FirstLine","clip"))
	end

	-- create a text string for insertion into the Clipboard
	local ginormousText = ""
	for i=1,rTemp.SelfListSize-1 do
		if rOpt.HTML.value then
			ginormousText = ginormousText..outgoingeffectlineHTML1(i,"clip")..outgoingeffectlineHTML2(i,"clip")..outgoingeffectlineHTML3(i,"clip")
		else
			ginormousText = ginormousText..outgoingeffectline(i,"clip")
		end
	end
	RCEB:Insert(ginormousText)

	if rOpt.HTML.value then
		RCEB:Insert(rLocalize.HTMLSuffix.."\n")
	end

	RecapClipFrame:Show()

	-- the following used to be in RecapOptions.xml in an OnTextChanged event
	local scrollBar = _G[RCEB:GetParent():GetParent():GetName().."ScrollBar"]
	local myMax
	, myMax = scrollBar:GetMinMaxValues()
	if ( myMax > 0 and (RCEB.max ~= myMax) ) then
		RCEB.max = myMax
		scrollBar:SetValue(myMax)
	end
	-- NOTE: the preceding code doesn't do a very good job of scrolling to the end of the clipboard, perhaps because individual lines can be so long

	RCEB:HighlightText()
	RCEB:SetFocus()
end

function Recap_LineToClipboard(msg)
	-- prior to 4.62 we would only post if there was room (used to be 32000 letters max)
	RecapClipEditBox:Insert(msg.."\n")
	return nil
end

-- a single WriteLog function has been split into Open, ReportToLog, and Close
function Recap_OpenLog()

	local rTemp = _G.recap_temp
	local i, j, chatnum, _, chatname, freeslot, alreadyin
	local logchat = "recaplog"..string_lower(rTemp.Player)

	freeslot = false
	alreadyin = false
	rTemp.LogChatnum = false
	for i=1,10 do
		_,chatname = GetChannelName(i)
		if not chatname then
			freeslot = true
		elseif string_lower(chatname)==logchat then
			alreadyin = true
		end
	end
	if alreadyin then
		chatnum = false
		for i=1,10 do
			j,chatname = GetChannelName(i)
			if chatname and string_lower(chatname)==logchat then
				chatnum=j
				break
			end
		end
		if chatnum then
			rTemp.LogChatnum = chatnum
			-- begin logging to WoWChatLog.txt
			if LoggingChat() then
				-- already on
			else
				-- toggle on
				LoggingChat(true)
			end
			-- allow Report and Close buttons
			RecapOpenLogButton:SetText(RECAP_CHANNEL_JOINED)
			RecapOpenLogButton:Disable()
			RecapReportToLogButton:Enable()
			RecapCloseLogButton:Enable()
		else
			-- something wrong
			print(rLocalize.NoChannelNumber)
			RecapOpenLogButton:Enable()
		end
	else
		if freeslot then
			RecapFrame:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")
			JoinChannelByName(logchat)
			RecapOpenLogButton:SetText(RECAP_ACQUIRING_CHANNEL)
		else
			print(rLocalize.NoFreeChannels)
			RecapOpenLogButton:Enable()
		end
	end

end

function Recap_ReportToLog()

	local rCombatants = _G.recap_combatants
	local rUser = _G.recap_user
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, doneGroup, thisCombatant
	local lines = 0
	local headerformat = rLocalize.LogHeader
	local prefix, suffix = "", ""
	local currentView

	if rTemp.LogChatnum then

		currentView = rUser.View

		-- guard, just in case we accidentally have two incompatible options set
		if rOpt.HTML.value then
			rOpt.TabDelimited.value = false
		end

		if rOpt.HTML.value then
			headerformat = rLocalize.HTMLHeader
			prefix = "-->"
			suffix = "<!--"
			SendChatMessage(rLocalize.HTMLPrefix..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		end

		-- we're in a channel
		SendChatMessage(prefix..string_format(headerformat,Recap_Version,Recap_PetsMergedText(),rTemp.Player,rLocalize.LastAll[rUser.View],date("%Y-%b-%d %H:%M"),GetRealZoneText())..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		if rOpt.HTML.value then
			-- for HTML send as two lines to get around chat 255 byte limit
			SendChatMessage(prefix..loglineHTML1("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
			SendChatMessage(prefix..loglineHTML2("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		else
			SendChatMessage(prefix..logLine("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		end

		doneGroup = false
		for i=1,rTemp.ListSize-1 do

			if lines < rTemp.MaxLogLines then
				thisCombatant = rTemp.List[i].Name
				if (not doneGroup) and thisCombatant and rCombatants[thisCombatant] and (not rCombatants[thisCombatant].Friend) then
					if not rOpt.WriteGroup.value then
						if rOpt.HTML.value then
							-- for HTML send as two lines to get around chat 255 byte limit
							SendChatMessage(prefix..loglineHTML1("Spacer")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
							SendChatMessage(prefix..loglineHTML2("Spacer")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
						else
							SendChatMessage(prefix..logLine("Spacer")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
						end
					end
					doneGroup = true
				end

				if not doneGroup or not rOpt.WriteGroup.value then
					if rOpt.HTML.value then
						-- for HTML send as two lines to get around chat 255 byte limit
						SendChatMessage(prefix..loglineHTML1(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
						SendChatMessage(prefix..loglineHTML2(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
					else
						SendChatMessage(prefix..logLine(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
					end
				end

				lines = lines + 1
			end
		end

		if rOpt.HTML.value then
			SendChatMessage(prefix..rLocalize.HTMLSuffix, "CHANNEL", nil, rTemp.LogChatnum)
		end

		-- and again for the details
		headerformat = rLocalize.DetailHeader

		if rOpt.HTML.value then
			headerformat = rLocalize.HTMLDetailHeader
			prefix = "-->"
			suffix = "<!--"
			SendChatMessage(rLocalize.HTMLPrefix..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		end

		-- we're in a channel
		SendChatMessage(prefix..string_format(headerformat,"("..Recap_PetsMergedText()..")",rTemp.Player,date("%Y-%b-%d %H:%M"),GetRealZoneText())..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		if rOpt.HTML.value then
			-- for HTML send as three lines to get around chat 255 byte limit
			SendChatMessage(prefix..outgoingeffectlineHTML1("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
			SendChatMessage(prefix..outgoingeffectlineHTML2("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
			SendChatMessage(prefix..outgoingeffectlineHTML3("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		else
			SendChatMessage(prefix..outgoingeffectline("FirstLine")..suffix, "CHANNEL", nil, rTemp.LogChatnum)
		end

		for i=1,rTemp.SelfListSize-1 do
			if rOpt.HTML.value then
				-- for HTML send as three lines to get around chat 255 byte limit
				SendChatMessage(prefix..outgoingeffectlineHTML1(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
				SendChatMessage(prefix..outgoingeffectlineHTML2(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
				SendChatMessage(prefix..outgoingeffectlineHTML3(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
			else
				SendChatMessage(prefix..outgoingeffectline(i)..suffix, "CHANNEL", nil, rTemp.LogChatnum)
			end
		end

		if rOpt.HTML.value then
			SendChatMessage(prefix..rLocalize.HTMLSuffix, "CHANNEL", nil, rTemp.LogChatnum)
		end

		print(rLocalize.LogWritten)
	end

end

function Recap_CloseLog()
	local rTemp = _G.recap_temp
	rTemp.LogChatnum = false
	if not LoggingChat() then
		-- already off
	else
		-- toggle off
		LoggingChat(true)
	end
	LeaveChannelByName("recaplog"..rTemp.Player)
	RecapOpenLogButton:SetText(RECAP_OPEN_WOWCHATLOG_TXT)
	RecapOpenLogButton:Enable()
	RecapReportToLogButton:Disable()
	RecapCloseLogButton:Disable()

end

function RecapAnchor_OnEnter(frame)

	Recap_Tooltip(frame, frame:GetName())
end


function RecapAnchor_OnClick(frame, button, down)

	set_anchor_buttons(frame:GetName())

end

RecapOptions_lua_4773 = true
