﻿
This file contains all the release notes from Recap 3.50 through to Recap 4.55 (i.e. prior to patch 4.0.1) inclusive

Copyright 2006, 2007, 2008, 2009, 2010 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference.



__ Assorted modifications __

New: In the Personal Details view you can sort each column by left-clicking its header.  Click it once to sort by descending values or click again to reverse directions.

New: Faction icon and Level number now have separate columns.

New: You can shift+click on the totals row for the All Fights and Last Fight panels.  A pair of summaries is generated, one each for friendly and non-friendly combatants.

New: You can Lock or Unlock a combatant using the right-click popup menu on the All Fights panel.  A Locked combatant and their pets will not be cleared during a Reset All Fights.

New: To avoid anxiety, the slash command "/recap reset", which doesn't do a Reset, has been changed to "/recap centre" or "/recap center".

__ Details Panel __

New: The Personal Details view now shows healing at full value, while the fight panels continue to show actual healing (actual healing = full healing - overhealing).

New: The Damage (Outgoing Details) tab of the popup panel now shows seven lines of information.  The Tanking (Incoming Details) tab of the popup panel now tracks incoming spells and abilities in a similar way.  Both tabs now show a full breakdown of miss types for each spell or ability.

New: The fight panels track full healing and over healing behind the scenes, although at the moment only the actual healing number (the value you've always seen) is displayed.  This means that overhealing information is now available even with Light Data Mode turned on.



__ New in 4.55 __
* Bug fixes.

__ New in 4.54 __
* Updated for patch 3.3.5.  Recap will post to "Self" (a.k.a. the player's own console) whenever the chat edit box is not visible.  With patch 3.3.5 the default Blizzard Chat Style ("IM Style") has the chat edit box always visible.  If you prefer the old Recap posting behaviour (so that you can check Recap posts privately), switch to "Classic Style".  Built-in Recap posting to "Self" still works fine.
* Added gauges (bar charts) behind live text-only listings.
* Bug fixes.

__ New in 4.53 __
* Melee for some specific NPCs is given a new name, instead of the generic "Melee".  The initial list contains two NPCs, Vengeful Shade (Lady Deathwhisper in ICC) and Blood Beast (Deathbringer Saurfang in ICC).  So during the Saurfang fight you can look for "Blood Beast Melee" specifically to learn who got hit; and during the Lady Deathwhisper fight look for "Vengeful Shade Melee".  The list of NPCs is not currently user-editable, so if other NPCs need to be handled in the same way, please let me know so that I can add them.
* Bug fixes.

__ New in 4.52 __
* Increased maximum number of recent events stored to 80000.
* Bug fixes.

__ New in 4.51 __
* Bug fix.

__ New in 4.50 __
* There's a new optional data mode, Live Data Mode.  This adds a panel with live graphs for outgoing DPS, incoming DPS, and outgoing HPS for group combatants.  Also available as live text-only listings on the same panel.  Off by default, this feature is for those with spare memory, spare CPU horsepower, and a liking for live graphic goodies.  Enable Live Data Mode on the Options / Settings tab.
* Bug fixes.
* A derivative of LibGraph (2.0.1) included as LibGraphL (2.1).

__ New in 4.37 __
* Improved Recap background CPU usage.
* Bug fixes.
* Six modules from Ace3 (r907) included.

__ New in 4.36 __
* Added a new column to the fights panel, the DPS / Gear ratio.  Off by default.  This column takes the DPS number and divides it by a gear value (if available).  The initial version picks up values from the GearScore addon (if you have it installed).  Support for other gear value addons might be added later.
* Improved the Deaths panel to report all friendly combatant deaths, not just the most recent death for each combatant (the Recent Data Mode option has to be enabled).
* Added an ability to report a single detail entry for multiple combatants.  In the bottom half of the Outgoing Details, Incoming Details, or Other Effects Details tabs on the small popup panel, you can double-click on almost any item that highlights in yellow when you mouse over it.  Recap will bring up a panel showing that particular detail, either for all group combatants, or for all combatants who are not in the group.
* The Outgoing Details and Incoming Details tabs of the small popup panel now show what percentage of ticks (DoTs or HoTs) were critical ticks.
* Added an Add Suggested Ignores button to the Options / Ignores tab that will add the effects that Recap suggests you ignore.
* Healing numbers in the list in the top half of the Outgoing Details and Incoming Details tabs of the small popup panel are now actual healing (raw healing minus overhealing).
* The lists in the top half of the Incoming, Source, Outgoing, Target, and Other Details tabs of the small popup panel can now be sorted either in descending numerical order (the default) or in ascending alphabetical order.  Click on any of the highlighted headers to toggle between the two sorting sequences.
* All fields for which you can do something extra with mouse clicking have had their tooltips expanded to include a list of those extra actions, along with an option to turn these extra tooltip hints off once you have them memorized.
* The Recap clipboard has been moved off the Options / Reports tab and is now a separate small panel.
* Holding down the control key while shift+clicking to post something in Recap will open the Recap clipboard and post there, for transferring into an outside program such as a text editor or spreadsheet.
* Recap now tracks the amount absorbed during combat by the Persistent Shield created by the Scarab Brooch trinket.
* Improved death count code should (mostly) eliminate the double-counting of priest Spirit of Redemption deaths, and pick up a few deaths that Recap has hitherto been not counting due to inconsistent Blizzard combat log events related to deaths.
* Bug fixes.
* Five modules from Ace3 (r907) included.

__ New in 4.35 __
* Updated for patch 3.3.
* Added Blizzard tooltips for spells and abilities in the popup detail panel (both when mousing over the ability row in the top half of the panel, and when mousing over the spell ID in the bottom half of the panel).
* Bug fixes.

__ New in 4.34 __
* Bug fixes.

__ New in 4.33 __
* Recap now tracks an estimate of the amount absorbed during combat by the healer shield aura Protection of Ancient Kings that procs from the legendary mace Val'anyr.
* Bug fixes.

__ New in 4.32 __
* Added option to pause Recap when inside battlegrounds.
* Bug fixes.

__ New in 4.31 __
* Several adjustments aimed at improving how Recap determines the end of a fight.
* Set End Fight Delay to a new default value, 2 seconds.
* Bug fixes.

__ New in 4.30 __
* Updated for patch 3.2.
* Bug fixes.

__ New in 4.29 __
* Modified logic for detecting end of fight.  Fights should end sooner when unrelated combat is taking place nearby.  End of fight will be triggered when nobody in the group is involved in giving or receiving damage or healing.
* Added a button for renaming a stored Data Set.
* Added a button to show recent events, and a button to show recent dispels and interrupts.  These functions were formerly available, and continue to be available, as double-click and control+double-click on the totals line.
* The analysis of recent deaths is now displayed in the recent events panel, rather than posted to the console.
* For recent event displays where the incoming and outgoing events were identical except for colouring, the events are now displayed only once and are coloured as incoming.
* Added two buttons to the recent event panel.  The double up arrow will if possible scroll to the previous end of fight marker.  The double down arrow will if possible scroll to the next end of fight marker.
* Added a warning dialog if you have more than 40 Mbytes of saved Data Sets.  Increased the warning for number of combatants from 1000 to 2000.
* Per-character combatant data is now compressed on logout or reloadui, and uncompressed again upon re-entering the game.  This seems to avoid the Blizzard "block too big" problem.
* Added a setting on Options / Reports to post the two standard reports to the clipboard in tab-delimited format, suitable for pasting into a spreadsheet.  The HTML and tab-delimited options are incompatible, and enabling one will turn the other off.
* Added deaths to the Report Fights standard report on Options / Reports.
* Changed synchronization to allow pausing while in sychronization, and to allow an ongoing synchronization to complete while paused.  If the synchronization leader pauses or resumes Recap, all synchronization members will be asked to pause or resume.
* Changed Manual Synchronization to request replies (as before), plus request a summary from every member of the synchronization.  Slower, but simpler and more complete.
* Dispel casts and failures (currently for Dispel Magic, Mass Dispel, and Cleanse) are now recorded as recent events.
* Updated WIM support, should work with WIM 3.1.1.  Does not support WIM-to-WIM.
* Bug fixes.

__ New in 4.28 __
* Simplified partial resistance numbers, added an average percentage partially resisted.
* Bug fixes.

__ New in 4.27 __
* Updated for patch 3.1.
* LibDataBroker support is now an option, off by default.  Made a few improvements to LibDataBroker support.
* Added interrupts to Recent Events.  The existing control+click mechanisms for Recent Events now shows both dispels and interrupts.
* Increased the maximum number of Recent Events stored to 40,000.
* Added a count of the number of hits from each source to the Deaths posts.
* Now storing multiple spell IDs for spells and abilities.
* Now ignoring summon events that would create Fishing Bobber and Basic Campfire pets.
* Bug fixes.
* Five modules from Ace3 (r803) included.

__ New in 4.26 __
* Bug fixes.

__ New in 4.25 __
* Death knight ghouls summoned using Raise Dead, which have multiple names, will be merged into one 'Ghoul Minion' (when Merge Pets is on).  The new ghouls that appear every time you mount then dismount will not be recognized as having been summoned using Raise Dead, so this new feature only partly addresses the issue.  This feature does not adjust existing data.
* Added option (default off) to merge all pets for a combatant into one 'Pet' (when Merge Pets is on).  Use with caution, as this will lump the data for all types of pet together, including pets, vehicles, totems, traps, and controlled mobs.  This feature does not adjust existing data.
* Added a new live minimized number, the percentage of your damage done by your pet(s).  This percentage is currently only available as a live minimized number, not in any other display.  Modified RecapFu and TitanRecap to support the new live number.
* Added a new column to the main fights panel to show Dispels (when Other Data Mode is enabled), the number of times that a combatant dispelled an effect.  This number includes both desirable dispels and undesirable dispels (such as accidentally breaking crowd control).
* Added a new Deaths button to the main fights panel next to the Reset button.  The Deaths button posts a report on the last few sources of damage for every group player who has recently died.  It can assist in answering questions such as "how many people died to the fire wall?" at Sartharion.  To use this feature you need to have the Recent Data Mode option enabled.
* Chat posts for damage now include dps, and vice versa; similarly for healing.
* Added a Delete All button on the Options / Data Sets tab.
* Added the ability on the Options / Data Sets tab to select a range of data sets for deletion by clicking on one data set and shift+clicking on a second data set.
* Redesigned options and combatants so that they are stored separately for each character.  A data loss for one character (e.g. as a result of a "block too big" error on login) should not affect other characters, and should not affect stored Data Sets.  Added code to detect possible damage to a "per character" data file and put up a warning dialog.  The dialog has a button to Restore Character Settings from a backup copy (also available as a slash command, "/recap restore").
* Redesigned the global settings feature, and added a button to copy global settings to a character.  If you need to set up a number of characters with the same settings, do the following: enable Use Global Settings; set the global settings up the way you want; log on to each character for which you want to use these settings and click the Copy Global To Character button; and finally disable Use Global Settings.  Note that window positioning is always separately adjustable for each character.
* Modified format for saved data sets to reduce string lengths.
* Removed the option to automatically save and reset on logout.
* Bug fixes.
* Five modules from Ace3 (r741) included.

__ New in 4.24 __
* Recap now tracks the amount absorbed during combat by the priest abilities Power Word: Shield and Divine Aegis, and assigns the amounts actually absorbed to the priest as if they were healing.  Recap makes a best attempt to assign these absorption amounts correctly, but can not guarantee to do so in all circumstances.
* Recap similarly tracks the amount absorbed during combat by the paladin ability Sacred Shield.
* Bug fixes.

__ New in 4.23 __
* Added death knight name and icon.
* Added option (default off) to automatically save boss fights.  See the Options / Data Sets tab.  A 'boss fight' is one in which there is a 'skull' boss present.  At the moment fights with bosses who are level 81 or 82 rather than 'skull' are not automatically saved.  Caution, using this option could create many data sets, consuming memory and possibly slowing your game.  If you have this option enabled, then delete unwanted data sets frequently.
* The Load button for saved data sets now loads into a separate panel that looks similar to the main fights panel, so that you can directly compare a saved data set with either All Fights or Last Fight data.  The loaded Data Set panel has fewer functions than the main fights panel.  In particular if you need to change which columns are displayed, do that on the main fights panel.  Both panels will always show the same columns.
* Health and power numbers are now available (on the tooltip for the combatant's row) for most combatants, and are now saved with Data Sets.
* Added count of casts (hits plus misses) to the Outgoing and Incoming Details tabs.
* The optional reminder messages on joining a group or entering an instance now offer a Reset All Fights button.
* Added option (default off) to automatically pause Recap when leaving an instance, and to automatically resume Recap when entering an instance.  See the Options / Settings tab.  This option is experimental.
* Added option (default off) to automatically Save All Fights to a Data Set on logout, and then Reset All Fights.  See the Options / Settings tab.  This option is experimental.
* Added option (default off) to automatically Reset All Fights on logout.  See the Options / Settings tab.  This option is experimental.
* Fixed TitanRecap and RecapFu to work with Recap.  Added code to generate 'live' numbers for Recap's minimized bar, and for plugins, when you first log in.
* Added basic LibDataBroker support.
* Bug fixes.
* Five modules from Ace3 (r722) included.  LibDataBroker (4.04) included.

__ New in 4.22 __
* Adjusted column order and colours on Fights panels.
* Removed special case code for shaman Earth Shield.  This code is no longer needed.  The special case code for druid Improved Leader of the Pack is still required.
* Experimental:  Recap can now ignore the damage and healing of specified effects.  See the new Options / Ignores tab.  You will need the numerical spell ID of the effect you want ignored, which you can find on the Outgoing, Incoming, or Other Details tabs (or from the Internet).  Note that the list of effects to ignore is shared among all characters.
* Bug fixes.
* Five modules from Ace3 (r706) included.

__ New in 4.21 __
* Bug fixes.

__ New in 4.20 __
* Updated for patch 3.0.2.  Overheal numbers will now be exact, not estimated.  Overkill is not currently tracked.
* Added a Reset All Fights button to the data size warning popup.
* Added a Skip Next Fight button for the synchronization leader.  The button can also be used by anyone not in synchronization.  The function is also available as a key binding.
* Added key binding to Pause / Resume Recap.
* Removed special case code for priest Prayer of Mending, druid Lifebloom, and paladin Judgement of Light.  This code is no longer needed.  The special case code for shaman Earth Shield and druid Improved Leader of the Pack is still included pending further tests.
* Removed synchronization of fight start and end times, and fight duration.  The event times supplied by Blizzard are not synchronized enough to support this feature.  The values in the DPS+ column (also called "DPS vs All") will now be more accurate, but will differ somewhat between members of a synchronization.
* Bug fixes.
* Five modules from Ace3 (r81877) included.

__ New in 4.10 __
* Code to handle three new combat log event types with patch 2.4.3.
* Bug fixes.
* Five modules from Ace2 (r78794) included.

__ New in 4.09 __
* Five healing spells that Blizzard credits to the person being healed are now assigned to the original healer.  They are priest Prayer of Mending, druid Lifebloom, shaman Earth Shield, druid Improved Leader of the Pack, and paladin Judgement of Light.  Recap makes a best attempt to assign these heals correctly, but can not guarantee to do so in all circumstances.
* Quick fix for the five new combat log events with patch 2.4.3.
* Bug fixes.

__ New in 4.08 __
* Bug fixes.

__ New in 4.07 __
* Replaced four option settings (Only Friendly Combatants, Only Party Combatants, Only Player Combatant, and Store Only Friends / Party / Player) with three settings (Hide Group, Hide Other Combatants, and Store Only Displayed Combatants).  Hide Group and Hide Other Combatants are both off by default.  The group members are shown in green on the main fight panel and include party members, raid members, their pets and controlled mobs, and former members.  Most references to 'Friendly' combatants have been modified to refer to 'Group' combatants.
* Recap now omits intra-group damage (such as Shatter in Gruul's Lair) from the 'Out' column on the main fights panel, and from the Outgoing Details tab.  This removes this kind of damage, which is not representative of what the combatant can do, from their DPS.  The damage is still tracked in the 'In' column, and on the Incoming, Source, and Target Details tabs.
* Recap now tracks dispels (which includes the deliberate and accidental breaking of crowd control) with the Recent Events.  If you hold down the control key while either double-clicking the combatant row on the main fights panel, or while clicking on a combatant's Recent button, the Recent Events popup panel will be filtered to show only the dispels (Outgoing or Incoming) for that combatant.
* Double-clicking on the totals row on the main fights panel will now bring up the Recent Events popup panel with ALL recent events.  This may be slow on older machines if you have the recent events slider set to a high value.  Holding down the control key while double-clicking on the totals row will bring up the Recent Events popup panel with ALL recent dispels.  This should be fast.
* Bug fixes.

__ New in 4.06 __
* In the popup Details panel the information for same-name pets is amalgamated (with Merge Pets on).  This amalgamation will save time and memory.  Details created by earlier versions of Recap are not amalgamated.
* All multi-line posts to chat are now limited by the "Report in Multiple Rows" slider (on the Options / Reports tab, default 10 lines, maximum 100 lines).  The option to concatenate multiple lines into one long line has been removed.
* The code for generating live DPS and HPS numbers has been rewritten and should be more accurate.  There is still at least one unresolved issue.
* Bug fixes.
* Five modules from Ace2 (r67789) included.
* NOTES:
* Most mage, warlock, and hunter pet ownership issues have been resolved, but there can still be orphan elementals, pets, or totems.
* There is currently only one multiple rows slider.  If you want to auto-post 5 DPS lines at the end of each fight, and then want to post 50 recent events manually, you will have to move that slider to 50 then back to 5.

__ New in 4.05 __
* The All Fights panel no longer updates live while synchronization data is being received.  There is a new timer that will update the panel a while after the last synchronization data has been exchanged.  The timer is also used to auto-post data when synchronization is active.
* Bug fixes.

__ New in 4.04 __
* Bug fixes.

__ New in 4.03 __
* Bug fixes.

__ New in 4.02 __
* Bug fixes.
* Five modules from Ace2 (r66043) included.

__ New in 4.01 __
* Bug fixes.

__ New in 4.00 __
* Updated toc for release 2.4.  No earlier version of Recap will work with release 2.4.
* Replaced ParserLib with direct processing of the new patch 2.4 combat log events (COMBAT_LOG_EVENT_UNFILTERED).  Many thanks to Rophy for all his past work on ParserLib.
* Recap now qualifies all combatant names with their Global Unique Identifier (GUID).  This uses significantly more memory, since identically named combatants are now listed separately.
* Added an option to Ignore Global Unique Identifiers.  The default value is off.  Checking this option will combine identically named mobs in the way that Recap 3.77 and earlier did.  Checking this option is incompatible with synchronization, and will limit the ability of Recap to handle pets correctly.  Checking this option is not recommended, but can be used if you really need to limit memory usage, and if disabling other memory-using options is not enough.
* Recap now tracks pets and other controlled entities (such as totems and traps) more accurately.  If a combatant is mind-controlled then what they do while controlled is tracked separately (as a pet of the controller) from what they do while not controlled.
* Recap now partially tracks buff and debuff dispelling and breaking.  If an effect (e.g. a wand shot) dispels a debuff (e.g. breaks a sheep), the effect will be listed for the person using the effect on the Other Details tab of the popup panel, as a white effect with the total number of such 'Dispels'.  This includes both deliberate and accidental removal of a buff or a debuff.  On the Other Details tab of the combatant who had the buff or debuff the number of Dispels will be shown.  Recap does not track the linkage between the two (e.g. that my wand broke your sheep).  Recap will show that my Shoot did a dispel, and the target will show that its Polymorph was dispelled.
* Recap now partially tracks spell cast interruption.  An effect (e.g. a kick) interrupts a spell cast.  The effect will be listed for the person using the effect on the Other Details tab of the popup panel, as a white effect with the total number of such 'Interrupts'.  The combatant who had their spell cast interrupted will have their effect listed as a white event with the total number of times that it was 'Interrupted'.  Recap does not track the linkage between the two (e.g. that your kick interrupted my heal).  Recap will show that your Kick did an interrupt, and that my Greater Heal was interrupted.
* Recap now partially tracks the stealing of buffs and debuffs.  A buff or debuff now has an extra detail line counting the number of times that the aura was stolen.  Recap does not track the linkage between the two (e.g. that you stole my Divine Spirit buff).  Recap will show you casting the spell that does the stealing, and the buff or debuff stolen will show the number of times that it has been stolen.
* Recap now shows kills and deaths in Recent Events.  Note that Blizzard may report a kill or death immediately prior to reporting the killing blow.  Recap does not attempt to fix this.
* There is now a separate set of Details for Last Fight.  This information is shown in the popup panel if you have the main panel set to Last Fight.  The Details are saved along with the Last Fight information if you "Save Last" on the Options / Data Sets tab.  This gives you the ability to save multiple individual boss fights complete with the matching fight Details without having to reset Recap.  Saving individual fights is not automatic, you have to do that yourself.  You can bind Save Last Fight to a hot key to make it easier.  Recap currently only allows you to inspect past saved fights by loading them over top of your current All Fights information, so that's still a possible inconvenience.
* (removed in v 4.20) Added a Recap sync record for fight start and end times, so that the DPS vs All (DPS+) column will now be synchronized.  This is trickier than for other synchronization data, and under some circumstances Recap can get out of synchronization for the DPS vs All (DPS+) column values for All Fights.
* There is a new column on the All Fights and Last Fight panel that shows when a combatant was first seen.  The column is hidden by default, but you can make it visible.  If the panels are sorted by combatant name, identically named combatants are sub-sorted by time first seen.  For example, if the combatants are sorted in ascending alphabetical order, then the last of a set of identically named combatants will be the most recently seen (but not necessarily the most recently killed).
* For any row on the main panel or on the popup panel that has a Recent button, you can now double-click the row to bring up the Recent panel just as if you had clicked the Recent button.  Double-clicking a row on the main panel will also toggle the popup panel, which some people might find mildly irritating.
* There is a new Time Window feature for Recent events.  You can double-click on a recent event to have the Recent panel change to show a Time Window of up to 100 other recent events both before and after the time of the clicked event.  The clicked event will be highlighted and centred in the Recent panel.  You can in turn double-click on one of the recent events in the Time Window to centre the window on the new event.
* The Only Unique Combatants option has been changed from hiding non-friendly combatants who die more than once, to hiding non-friendly combatants whose name shows up more than once (i.e. combatants with the same name and different Global Unique Identifiers).  There is a glitch that I have not yet resolved.  If a boss resets then there will be two (or more) bosses with the same name, and this option will hide them all.  This option will also incorrectly hide some pets and other controlled entities.
* Added support for posting to WIM (WoW Instant Messenger).
* The maximum number of recent events recorded has been increased to 10,000.
* The number of recent events posted to chat has been reduced to 30.  If you want to share more events then you can post the events individually.
* The Maximum Event Range setting has been removed.  Blizzard says "The combat log range is now everything that you can see."
* Added Recap-specific tooltips so that changing the Recap scale will not affect non-Recap tooltips.
* Bug fixes.
* Five modules from Ace2 (r63812) included.
* CAVEATS:
* This version lists same-name-but-different-GUID mobs individually.  If this overwhelms you or your computer, then Reset frequently or use the Ignore Global Unique Identifiers option (but note that this disables synchronization, blocks some of the new pet tracking abilities, and does nothing for the Only Unique Combatants option).  A future version may have an option to merge same-name-but-different-GUID mobs for display purposes.
* Blizzard seems to be incomplete in their use of pet ownership flags and pet ownership events, so not all controlled entities will be properly assigned to their owners at the appropriate times and only at the appropriate times.  For example, if you mind control a mob then that mob's damage and healing, and that mob's pet's damage and healing, both during the mind control and outside of the mind control, will not always be assigned correctly.  While some hunter traps are correctly credited to the hunter, snake traps and their snakes are not yet credited.  Many totems are now correctly assigned to their shaman, but I have not tested them all.

__ New in 3.77 __
* Bug fixes.

__ New in 3.76 __
* Recap can now track who damaged whom and who healed whom, on two new tabs on the popup panel.  The default is off.  If this option is turned on (Matrix Data Mode on the Options / Settings tab), the Target of Outgoing tab (sword pointing left) will track who the combatant damaged or healed (with amount and percentage); and the Source of Incoming tab (shield leaning left) will track who the combatant was damaged or healed by (with amount and percentage).  The information will be partial until after a Reset All FIghts.
* Added a new popup panel to show Recent Events (if that option is enabled).  To see the new popup panel click on the Recent button to the right of a combatant's row on the All Fights or Last Fight panels.  There are two tabs on the new popup panel, one for Recent Outgoing Events and one for Recent Incoming Events.  The events are colour-coded, with brighter colours indicating crits or crushes.  The events can be posted to chat from the new popup panel in the usual manner (shift+click).  They will be colour-coded when posted to your own console, though not when posted to other chats.
* Recent Events for a combatant filtered by effect may also also shown in the new popup panel.  Click on the new Recent button to the right of an effect's row on the Personal Details panel or on the Outgoing Details or Incoming Details tabs.  The events can be posted to chat from the new popup panel in the usual manner (shift+click).
* Added two buttons at the right hand end of the total row for the All Fights and Last Fight panels, one green button to pop up total details for friendly combatants, and one white button to pop up total details for non-friendly combatants.  These buttons replace key+click combinations.
* Added a setting to change the scale of the Recap panels (see Options / Settings).  Changing the scale will reposition the panels to the centre of the screen, and can then be dragged to where you want them.
* Removed the Hold / Resume button from Last Fight panel.
* Note that all fancier key+click combinations have now been replaced.  A simple shift+click now posts to any open chat edit box, and right-click brings up menus.
* Full Traditional Chinese localization (many thanks Ariestk).
* Many bug fixes.
* ParserLib 1.1 (r57622) included.
* Five modules from Ace2 (r57245) included.

__ New in 3.75 __
* Added an estimated total amount resisted to the Outgoing and Incoming Details tabs.  Useful for evaluating the effectiveness of resistance gear.  These estimates may be inaccurate until after your first Reset All Fights.
* Various bug fixes.
* ParserLib 1.1 (r55081) included.
* Five modules from Ace2 (r56239) included.

__ New in 3.74 __
* Updated toc for release 2.3.
* Improved tracking and listing of members in synchronization, to include their server and their Recap version.  The list of members shows those who are active followed by those who are inactive (have not been heard from for ten seconds).  The count of people in synchronization in the title bar of the main panel is either "(M in sync)" or, if some players are inactive, "(M+N in sync)".  Active players broadcast their presence on the sync channel every five seconds.  There is a new "Remove Inactive Members" button next to the "List Members" button that takes inactive members off your list.
* Added personal HPS and total HPS to the minimized view.
* Various bug fixes.

__ New in 3.73 __
* Updated toc for release 2.2.
* Various bug fixes.
* ParserLib 1.1 (r52661) included.
* Five modules from Ace2 (r50175) included.

__ New in 3.72 __
* Maximum number of recent events recorded increased to 5000.
* Added an option (default off) to not store data for combatants who are not displayed.  That is, with the appropriate other options set you can store data for the player only (plus pet), the group only, or friendly players only.  Using this option is not recommended unless you are desperate to save computer memory.
* Various bug fixes.
* Five modules from Ace2 (r48940) included.

__ New in 3.71 __
* Improved estimates of overhealing, improved matching of pets to owners, improved handling of situation where players and pets have the same name.
* Added option: Remind on Enter or Leave Instance.  The default is off: if this option is turned on, Recap pops up a reminder whenever you enter or leave an instance; you still need to manually do whatever it was you wanted to be reminded about, such as perhaps Save All Fights (see next line) then Reset All Fights.  Note: Blizzard does not provide direct support for this information, so Recap does the best it can, and can sometimes be fooled.  When this option is enabled you will occasionally get the popup when you are nowhere near entering or leaving an instance.
* Added two new key bindings: Save All Fights and Save Last Fight.  These commands immediately save data sets named with the current date and time (e.g. "Last Fight Mon Jul 30 19:18:53 2007").
* Full Simplified Chinese localization (many thanks Ariestk).
* Various bug fixes.
* ParserLib 1.1 (r46963) included.
* Five modules from Ace2 (r47060) included.

__ New in 3.70 __
* Short fights in which no combatant deals damage or takes damage for more than five seconds will not replace the current Last Fight.  Similarly, a 'fight' in which only healing takes place will not replace the current Last Fight.  In all cases the information is still fully tracked, and is added into the All Fights panel.
* Added subtotals by element to the end of the Outgoing and Incoming Details tabs, plus totals for damage and healing.  These subtotals and totals may be inaccurate until after your first Reset All Fights.
* Added a panel showing a summary over all friendly combatants with cumulative Outgoing, Incoming, and Other Details tabs.  To see this panel, left-click on the total line of the Fights panel.  To get a similar summary for all non-friendly combatants, control+left-click on the total line of the Fights panel.
* These two new features combine neatly to give you grand totals by element for all friendly or non-friendly combatants, plus grand totals for damage and healing.
* The count and list of members in synchronization will now include everyone (if they are running Recap version 3.70 or later).  It will continue to include people who have since left the synchronization.  The list shows the time since they last participated.  See the file readme_FAQ.txt for more details.
* Added totals for the partial absorbs, blocks, resists, and vulnerability damage on the Outgoing and Incoming Details tabs.
* Added a new introductory document, Recap_Quick_Start.rtf.
* Various bug fixes.
* ParserLib 1.1 (r41839) included.
* Five modules from Ace2 (r43318) included.

__ New in 3.69 __
* Added glancing blows to the Outgoing and Incoming Details tabs.  These are handled similarly to critical and crushing blows.  The percentage of glancing blows may be inaccurate until after a Reset All Fights.
* Added glancing blows to the Personal Details panel.
* Added tracking of partial absorbs, blocks, resists, and vulnerability damage to the Outgoing and Incoming Details tabs.
* Added tracking of net minimum values for glances, hits, crits, crushes, and ticks on the Outgoing and Incoming Details tabs.
* Added tracking of net minimum values for glances, hits, crits, and ticks on the Personal Details panel.
* Created separate interval and duration timers for effects, and increased the maximum measurement to 130 seconds from 120 seconds.
* To avoid anxiety the slash command "/recap reset" (which doesn't in fact do a Reset, but instead brings the Recap panels to the centre of the screen) has been changed to "/recap centre" or "/recap center".
* Various bug fixes.
* ParserLib 1.1 (r39328) included.
* Five modules from Ace2 (r41513) included.

__ New in 3.68 __
* Updated toc for release 2.1.
* Added tracking of environmental damage.  The effect is called "Environment", with the types of damage being shown as the element.
* Added tracking of effects that do not directly report damage or healing (casts, including dispels, cleanses, procs, and so on; debuffs/losses; buffs/gains; and so on).  Tracking these is optional, and the default is off.  To turn this tracking on, check the "Other Data Mode" option on the Options / Settings tab.  The Other Details can be found on the popup panel -- click on the 'Sunder' icon between the 'Book' icon and the 'Sword' icon.  The Other Details are reset when you Reset All Fights, in the same way as the Outgoing and Incoming Details.  The list of Other Details can get quite long, and there are a lot of anomalies.  See the file readme_FAQ.txt for more information.
* Added tracking of intervals for damaging and healing effects on the Outgoing and Incoming Details tabs.
* For the leader of a synchronization the Reset All Fights button (and matching hotkeys) will do a Start Synchronization (which is how Recap does a reset while in synchronization).  We'll see if this causes anyone any problems.
* Added a List Members button to the Options / Sync tab.  This is an interim solution.  Because version 3.68 includes no changes to the underlying synchronization protocol (3.68 can sync with 3.61), the list may not be accurate.  It shows the members from whom you have seen synchronization messages so far.  It will continue to show members who have left the synchronization.
* Added a count of members in synchronization to the main panel title bar.  The count has the same limitations as the List Members button just mentioned.
* Pausing Recap is no longer permitted during synchronization.
* Fixed minimized display of DPS when Merge Pets is turned on.
* Added the elapsed time that the group spent fighting (rather than the sum of individual times) as "Group Fight Time" on the tooltip that pops up when you mouse over the Total line of the All Fights panel or the Last Fight panel.
* Added the total DPS from the group (rather than the average DPS) as "Group DPS" on the tooltip that pops up when you mouse over the Total line of the All Fights panel or the Last Fight panel.  Note that the All Fights total will be misleading if you replace anyone, even a pet, during the run.  The DPS of the original and of the replacement will both be added in to the total.  For example, if you replace one rogue doing 400 DPS with another rogue doing 400 DPS, the total group DPS will count both rogues, giving a combined DPS for All Fights that is 400 too high.  The total combined DPS could be misleading even for Last Fight if someone uses more than one pet during the fight.  Use cautiously.
* I note that with WoW 2.1 Shadowfiends are now often (but not always) tracked properly as priest pets.  No changes were necessary in Recap.
* Various bug fixes, and adjustments for WoW 2.1.  Recap lua errors will continue to show even with the Blizzard "Display Lua Errors" in its default off setting.
* ParserLib 1.1 (r36203) included.
* Five modules from Ace2 (r36940) included.

__ New in 3.67 __
* Recap now keeps long-term Personal Details for hunter and warlock pets, in the same way as for the player.  These pet Personal Details will appear on the player's Personal Details panel, and will not be affected when you Reset All Fights.  See the file readme_FAQ.txt for more information.
* Various bug fixes.
* Five modules from Ace2 (r34168) included.

__ New in 3.66 __
* Recap no longer tracks the Outgoing component of damage from owner to pet or vice versa.
* Recap now calculates crit percentages and crush percentages based on hits attempted rather than on hits landed.
* Various bug fixes.
* Five modules from Ace2 (r32597) included.

__ New in 3.65 __
* Option to automatically refresh the Blizzard party frame should have been off by default.

__ New in 3.64 __
* Various bug fixes.
* ParserLib 1.1 (r32137) included.
* Five modules from Ace2 (r32117) included.
* Improved garbage collection behaviour.  Added an option (on by default) to trigger a garbage collection at the end of each fight.
* Added option to automatically refresh the Blizzard party frame at the end of a fight (temporary until Blizzard fixes it).

__ New in 3.63 __
* Several bug fixes.
* Five modules from Ace2 (r30830) included.

__ New in 3.62 __
* Added crushing blows to Incoming and Outgoing Details, and to recent event data.
* Added option: Minimize on Escape (default off: if you want the Minimize on Escape behaviour for the main panel, turn this option on).
* Added option: Sync Light (default on: if you don't want to see the Sync Light when minimized, turn this option off).
* Added option: Remind on Join or Leave Group (default off: if this option is turned on, Recap pops up a reminder whenever you join or leave a group; you still need to manually do whatever it was you wanted to be reminded about, such as perhaps Reset).
* Added pet owner to combatant tooltip.
* ParserLib 1.1 (r30139) included.
* Five modules from Ace2 (r30631) included.
* Various fixes.

__ New in 3.61 __
* Recap synchronization (see Options / Sync panel).  This version synchronizes All Fights summary information.  See the file readme_FAQ.txt for more information.
* Conversion for Ace2, and ParserLib moved inside the Recap folder.  Please remove the separate ParserLib folder from the AddOns folder.
* Modifications to how overhealing is tracked.  Old data will show zero overhealing.
* Recap no longer tracks the Outgoing component of self-damage.
* Fix for deaths not being reported.
* Full German localization (many thanks Dhana).
* Some panels and fields have been enlarged to accommodate non-English translations.
* Option to have an opaque background for the panels.
* Pet effects will only show under Personal Details if Merge Pets is on (this reverts to the pre-3.59 Recap behaviour).
* Personal Details will no longer show pet incoming damage (this was never intended, and was a mistake).
* The Recap main panel now minimizes when the Escape key is pressed.
* Fixed a problem with Outgoing Details not being properly loaded from a saved Data Set from 3.58 or earlier.
* ParserLib 1.1 (r29435) included, which recognizes a number of new WoW 2.0 combat message patterns.
* Five modules from Ace2 (r29920) included.
* The Frequently Asked Question (FAQ) sections of the readme files have been separated into their own files.
* Various other fixes.

__ New in 3.60 __
* Added a delay after the player has left combat before the fight is ended.  This should help to avoid fights ending prematurely.
* Increase maximum number of lines that can show on a popup menu.
* Fixed a bug where items in the bottom half of the Outgoing and Incoming Details panels were not displaying correctly.
* ParserLib 1.1 (r28229) included.

__ New in 3.59 __
* Time In (for damage taken) and Time Heal (for healing) now displayed and reported.
* Added a column to Personal Details showing the Element (Arcane, Fire, etc.).  The Element for old spells and abilities will show as "?" until Recap gathers new data.  I'm still investigating how best to include Element in summaries and reports.
* Added a line to the Outgoing Details tab showing the Element.
* Added Element to recent event postings.
* Option to show only player (and pets) renamed "Only Player Combatant".  Moved to right hand side of Options / Settings panel.
* Added option to show only the party (and pets).
* Personal Details now always show pet effects, whether Merge Pets is on or off.
* The Incoming Details tab now includes a full list of damage and healing received.  Old data will list only Melee and Non-Melee damage.
* The Incoming Details tab now includes a full breakdown of miss types.  Old data will not have the full detailed breakdown.
* The Outgoing Details tab now includes a full breakdown of miss types.  Old data will not have the detailed breakdown.
* The right-click popup menu on the All Fights panel can now Lock or Unlock a combatant.  A Locked combatant and their pets will not be cleared during Reset All Fights.
* Added report of Personal Details as part of Report to WOWChatLog.txt.
* Added button to report Personal Details to Clipboard.
* Added posting to the Clipboard for all key+click reports.  See the file readme_FAQ.txt for more information.
* Mouseover tooltip for a combatant now shows class and faction.
* ParserLib 1.1 (r27734) included.
* Various fixes.

__ New in 3.58 __
* Added a shift+left-click report from the totals row on All Fights and Last Fight.  Includes two summaries for friendly and non-friendly combatants.
* Added a button on Options/Data Sets to save the Last Fight.  This allows you to later load in a single fight for examination.
* Added a button on Last Fight panel to hold the panel at the end of the fight.  This gives you time to examine or save the Last Fight.  Recap continues to track fights in the background.  Click to resume automatic updating of the Last Fight panel.
* Minor fixes, and added a program file integrity check.
* Please see the file readme_FAQ.txt for additional information.

__ New in 3.57 __
* For patch 2.05.
* Fix for deaths not being recorded for the player.
* Repair for miscalculation of Tick counts and averages.

__ New in 3.56 __
* Fix for some postings going to 'say' rather than to the chosen channel.

__ New in 3.55 __
* Updated toc for patch 2.03.
* ParserLib 1.1 (r24418) is now separate, and is a required dependency.
* A number of improvements to posting.

__ New in 3.54 __
* Added option to remember recent damage and healing events.  Post recent events to chat for a combatant.  Post recent events to chat for a combatant's spell or ability.
* Added option to record only for the player (and pets).
* Added additional duration and "per second" information.  Separate duration for damage received for each combatant.  Separate duration for healing done for each combatant.  Damage received per second ("DPS In") shown for each combatant.  Healing done per second ("HPS") shown for each combatant.
* Added option to set combat event logging range to maximum.
* Added hotkey support for several kinds of reset.
* Improved tracking of initial hits for HoT spells.
* Repair for some misreported HoT spells (e.g. Siphon Life).
* Posting to a chat will post to the console if no chat edit box is open.
* A number of other improvements and fixes.
* A command-line option to automatically screenshot unexpected events.

__ New in 3.53 __
* Modified to include ParserLib 1.1 (r21077).
* Fixed battleground name problem.
* Incoming detail now separates non-melee hits and non-melee ticks.
* Increased the size of the outgoing detail scroll box to six lines.
* A number of other fixes.

__ New in 3.52 __
* Several fixes.

__ New in 3.51 __
* Added ability to sort "Spell or Ability" panel by any column.
* Fixed a typo that prevented Recap storing information about misses.

__ New in 3.50 __
* This version by Hawksy (on Elune)
* Recap is fully updated for the WoW 2.01 patch with many assorted fixes.
* In addition I have made a few minor improvements as follows:
* Healers now do not have to deal or receive damage before showing up in Recap.
* The Personal Details panel ("Spell or Ability") now shows heals at full value.  The main panel ("All" or "Last Fight") continues to show the actual net healing and the overhealing percentage.
* Friendly hit points are now gathered at the start of a fight as well as at the end so that the overhealing numbers will be slightly more accurate.
* Faction icon and Level number are now no longer overlaid.
* Some fields are wider so that text will be truncated less often.


Revision history:

4.55, 2010-08-04 - Fixed "List length" error when clicking "Show Recap" and
	other buttons on the Interface/AddOns panel; fixed a problem with minimized
	numbers resetting to zero too easily; fixed wrong colours in tooltip for
	totals line on fights panel; fix for an error at RecapAux 751 which was
	source being nil for a summon or create (reported by ElrickEnonimis);
	fixes for non-existent ChatFrame1EditBox (reported by Bishelariel); removed
	Exit button from Options panel; live graph and text listing no longer
	automatically pops up when a fight begins (plus opacity is now persistent
	between reloads); fixed a (rare) error at RecapCombat 3305.

4.54, 2010-06-23 - Added gauges to live text listings (suggested by Vampyrr);
	changed default sorting for live text listings from none to Total; fixed
	broken posting for 3.3.5 (chat frame edit box change); fixed blocking of
	common channels for posting events (i.e. no recent events posted to trade).

4.53, 2010-06-12 - Fixed reporting of detail entries for all combatants which
	was posting the last N lines rather than the first N lines (reported by
	Islowlykill); fixed many missing outgoing casts such as Polymorph (have to
	use the SPELL_AURA_APPLIED and SPELL_AURA_APPLIED_DOSE events to track the
	successful casts) (note that for buff spells which have SPELL_CAST_SUCCESS
	events this will show up as N+1 casts where N is the number buffed); fixed
	detail entries which were incorrectly combining (such as adding casts and
	debuffs with the same name); fixed RecapLoad 857 error; added code to
	distinguish "Melee" for specific NPCs so that it is easy to tell who got
	hit by those NPCs, initially Vengeful Shade (Lady Deathwhisper in ICC) and
	Blood Beast (Deathbringer Saurfang in ICC); adjusted blue colour for live
	graphs to be slightly more visible against a black background.

4.52, 2010-05-21 - Increased the maximum number of Recent Events to 80000 so as
	to accommodate longer fights; reduced the size of the live panel; made the
	live panel a bit more transparent; fixed incorrect index for 20-player
	dungeon abbreviation which would break auto-save of ZG boss fights; fixed
	an error at RecapAux 4650 which broke auto posting of leader (reported by
	Bishelariel); fixed another couple of major problems with auto posting of
	leader (picking the new leader properly had never been right, and the use
	of All Fights versus Last Fights had been wrong -- both problems existed
	in Gello's version 3.32); recent event and live data buttons disabled if
	corresponding data mode is off (still show tooltips when disabled); sort
	before posting columns from live text listings.

4.51, 2010-05-09 - Fixed an initialization of the recap_temp.Localize table
	that was in the wrong place in the three non-English files (reported by
	Bishelariel and Ryne).

4.50, 2010-05-07 - Replaced a long if-then-elseif chain for combat log events
	with a dispatch table of functions for a mild speed improvement; several
	other optimizations in combat log event processing; removed tracking of
	dispel casts and fails introduced in version 4.29; any summon or create was
	counted as two casts in Other Details (the cast plus the actual summon),
	so changed the summon to be a gain of an 'entity'; removed OnEnterOnLeave
	spinlock; added more local references for globals; fixed several bugs
	found while doing that; fixed a bug that would not show the popup panel
	while simply mousing over the main panel (bug introduced in 4.36); fixed
	a bug that was preventing the Recent button on the popup panel for an
	Outgoing or Incoming effect from working properly for a pet's effect;
	added a basic options panel, for Recap, to the Blizzard Interface Addons
	panel; fixed an error with Report for WoWChatLog; added OnLoad code to
	RecapGeneralEvents and RecapCombatEvents to fix an error where Recap was
	missing the first event or two after login; in eventual response to a
	suggestion by Cuddlejam from three years ago (!) had an inspiration to use
	the Recent Events data to create a DPS and HPS graph (incoming or outgoing)
	for any combatant, for any fight which is still in the Recent Events data,
	including live update for the current fight; decided to mothball that first
	version, based on Recent Events data, in favour of a new version based on
	a new Live Data Mode with a separate data store; live multi-colour graphs
	(DPS Out, DPS In, or HPS Out) for all group combatants for the current
	fight using a moving 6-second average; added controls to hide a combatant,
	or to highlight one combatant's graph by dimming all others; matching text
	listings also updated live showing total, peak, and average; the panel with
	the graphs and texts pops up automatically when Recap is first loaded and
	at the beginning of any fight involving group combatants dealing or taking
	damage; the live panel can be set, using a checkbox on the graph options
	panel, to have an opaque background (it always begins as semi-transparent
	when Recap is first loaded; the main downsides of my second version of the
	live graph are 1) graphs are overwritten when a new fight begins (though
	not if the new fight is insignificant), 2) you can not examine earlier
	fights, 3) you can not see graphs for combatants who aren't in the group;
	created combatant option lists so the player can choose which combatants
	are shown or highlighted (highlighted by dimming other combatants) (more
	than one combatant can be highlighted at the same time) (there are separate
	sets of options for each graph / text type); renamed the LibGraph library
	to LibGraphL (slimming and fixing some bugs) to stop graph usage by other
	addons (i.e. Recount) being charged to Recap; the live panel will not
	dismiss on Escape (you have to explicitly click the close button) (the
	live options side panel will dismiss on Escape); corrected some duplicate
	strings for Deaths; the graph options panel shifts to the right side or to
	the left side as appropriate; added code so that the graph panel displays
	are not overwritten by insignificant fights; added optional column sorting
	of the live text listings; fixed instance difficulty for dynamic instances
	(e.g. ICC); slightly tricky code to allow Recap to calculate display data
	for graphs and text listings for only combatants who have been selected
	(thus saving memory and processing time); added button to pause and resume
	data collection for live graphs and text listings (also tricky); added 30
	second timeout to all dialogs; added an update of the main fight panel
	every 2 seconds if synchronization is ongoing and if out of combat; fixed
	error (from v 4.37) at RecapAux 4316 (reported by smanzo).

4.37, 2010-03-27 - Greatly improved Recap's background CPU usage by using
	AceTimer rather than an update frame for periodic processing (a factor of
	about 6 difference when not in combat); modified AutoFade in consequence;
	the main downside of the use of AceTimer is that AutoMinimize is slightly
	less responsive; fixed a problem in Sync with nil value for SendCommMessage
	distribution (trying to send sync message while not in a group) (reported
	by Bishelariel).

4.36, 2010-03-10 - Fixed a bug that left the popup details panel open after
	mousing over an entry in the main panel (reported by Joshua); upgraded
	table clearing to use wipe() (thanks to Farmbuyer for providing a pointer
	to this function); improved alignment in multi-column posts; added option
	to collapse spacing in multi-column posts to single spaces (requested by
	Kratfrotz); added UNIT_DISSIPATES event (reported by Islowlykill); removed
	calls to garbage collection, and removed corresponding option setting; added
	new DPS/Gear column (initially using gear values from GearScore) (suggested
	by tamirbankatu); removed dispels from individual combatant row postings;
	rewrite (twice) of Deaths code to report all friendly death events so that
	we can see more than one death for each combatant; defined a time for the
	'end of fight' marker in the recent events to be one second after the last
	event in the fight (will replace the '00:00:00.0' that previously appeared);
	added a sum of healing received as part of the Deaths report; added a few
	extra UnitExists guards; added a button to the Options / Ignores tab to add
	Recap's latest suggested effects to ignore; removed panel details drop down
	menu when the panel is for a Load data set, and fixed a problem with proper
	initialization of the choice in the menu; fixed a couple of problems with
	adding and removing Ignores (tripped up again over numbers that are numbers
	versus numbers that are strings); modified Outgoing Details and Incoming
	Details tabs to show actual healing (raw healing minus overhealing) in the
	Total column, rather than raw healing; added a bit of extra width to the
	minimized DPS and HPS slots; added a count of critical ticks, shown on the
	bottom detail panel for the Outgoing and Incoming detail tabs (suggested by
	ingnoon); added a fairly messy double-click function for detail entries on
	the Outgoing, Incoming, and Other details tabs, which posts non-zero numbers
	to the Recent panel for combatants (either for all friends or for all
	non-friends); add ability to sort Outgoing, Target, Incoming, Source, and
	Other details alphabetically by clicking on the headers; cleaned up a number
	of undefined local variables in all files; fixed a bug that would disable
	the popup panel for group or non-group total; fixed a bug that was
	preventing the spellID ignores from working properly; increased the end
	fight delay default value from 2 seconds up to 3 seconds; added helpful
	hints (in light blue) about mouse clicking to all relevant tooltips, plus
	a new option to turn these on and off; narrowed popup Panel by 40 pixels;
	narrowed Recent panel by 120 pixels and shortened it by two lines; narrowed
	Options panel by 60 pixels; removed the "Use Color" option; took the
	existing Clipboard from the Options panel and made a separate Clipboard
	panel; control+shift+click will open the clipboard and post there (say
	goodbye to opening the Options / Reports tab, filling the clipboard with a
	report, deleting that report, leaving the clipboard open, and then posting);
	fixed a minor bug with the Recent button on the Personal Details panel
	showing the wrong tooltip; added code to react to event UNIT_PET; added some
	special case code to correct the bad UnitClass values returned during the
	Faction Champions fight; abbreviated instance type/size in data set names;
	added duration (maximum of time out, time in, time heal) to data set list;
	changed Recent from a table of tables to a table of strings (efficiency);
	expanded the tooltip for the Fights panel top bar to give starting hints;
	rewrote Recap error reporting (improved design, and some was obsolete);
	replaced calls to DEFAULT_CHAT_FRAME:AddMessage with calls to print (catch
	up to Blizzard changes from several patches ago); added code to close
	WoWChatLog on logout if it happens to be open (so as to not lose logged
	output); added a '/recap help' command; added ability to double-click a
	line on the Deaths report and see recent events centred on that event;
	added special case code to credit absorption due to the Scarab Brooch
	trinket proc shield Persistent Shield as healing for the healer (untested
	since I don't have the trinket, but it is clone-and-edit code so probably
	works); added killed events to the Deaths processing; added code to count
	deaths better, addressing a long-standing minor annoyance; fix for miss
	percentage for any effects that are just ticks; improved behaviour of popup
	panel when end of fight happens while the panel is open, addressing another
	long-standing minor annoyance.

4.35, 2009-12-08 - Modified some posting texts; added an experimental delay
	during startup to put most initialization after the toon has entered the
	world; included absorbed healing during the Jaraxxus fight; modifed calls
	to FuBarRecap_Update and TitanPanelRecap_Update to pass extra arguments
	(own HPS, group HPS, and pet percentage); add realm name for all group
	members who are not from the player's realm, with a couple of related
	changes; as an experiment commented out all calls to garbage collection (if
	no problems will remove the calls in the next version); added Blizzard's
	tooltip for spells and abilities (requested by coani and Farmbuyer, thanks
	to Farmbuyer for giving me a pointer to the SetHyperlink function); also
	added tooltip link to posted text (suggested by Farmbuyer); Blizzard's API
	call UnitClass is broken, either by Blizzard or by an addon, and does not
	always assign the correct class to enemy NPCs (e.g. in Faction Champions);
	modified Recap_GetUnitInfo; for patch 3.3 replaced MouseIsOver with
	IsMouseOver.

4.34, 2009-11-05 - Adjusted pause option behaviour (reported by Farmbuyer);
	refined instance difficulty text for saved data sets; removed the
	PlayerInCombat variable as it was sometimes blocking live DPS numbers;
	doubled the number of events shown in the recent events panel to 400;
	changed all remaining posting code to stop before the clipboard is full;
	removed a repeated header line in RecapEffectsHeader_OnClick.

4.33, 2009-10-22 - Fixed problem with the two pause options breaking the regular
	pause and resume behaviour (reported by coani and Joshua); made the function
	Recap_UpdateSyncMember global (reported by Avanger); fixed a problem with
	global option settings not seeing new options (reported by Veis); updated
	instance difficulty; fixed Recap forgetting that it was paused at logout
	(reported by MhicAoidh); added special case code to credit absorption due
	to the legendary healing mace Val'anyr proc shield Protection of Ancient
	Kings as healing for the healer; changed Report Fights and Report Details
	to stop before the clipboard is full (reported by injury); added estimated
	combined size of data sets to Data Sets tab.

4.32, 2009-09-08 - Added option to pause Recap inside battlegrounds (suggested
	by Veis); improved code to pause outside instances; removed most limitations
	on when minimized DPS numbers are calculated and displayed; fixed a bug
	merging fight start times for combatants and their pets; fixed a bug with
	PlayerInCombat flag.

4.31, 2009-09-04 - Improvements to code for recording dungeon difficulty; tweak
	for end of fight detection to continue a fight only if combat damage events
	are occurring (not for heals and misses); force default End Fight Delay of
	2 seconds for anyone upgrading from 4.30 or earlier; changes to do pause /
	resume before the start of any fight (in response to a report by MhicAoidh);
	changes so that zero net heals (i.e. pure overheal, such as many Spirit Bond
	or Fel Armor ticks) do not start a fight.

4.30, 2009-08-22 - Fixed a situation where recap_temp.PlayerInCombat might not
	get set to true at the start of a fight, resulting in zeroes for the last
	fight live DPS numbers (reported by dtc11); added 'absorbed' parameter for
	SPELL_HEAL and SPELL_PERIODIC_HEAL (but not doing anything with it at the
	moment); added detailed effect for Deaths report (had been commented out);
	investigating healing absorption, so far can see partial absorbs but not
	total absorbs.

4.29, 2009-07-30 - If end of fight is triggered by the player leaving combat,
	the end of fight delay timer will only be restarted by damage or healing
	events that involve members of the group; added a button to rename a saved
	Data Set; added some extra code to save option count on logout or reloadui
	or reset; if no backup setting available, create default settings; moved
	the Deaths button to a new bar across the bottom of the main panel; added
	an Events button and a Dispels and Interrupts button (these duplicate the
	functions of double-click and control+double-click on the totals line, and
	make them more accessible); show only incoming tab for all recent events
	and dispels and interrupts (slightly simpler, and saves memory as incoming
	and outgoing events are identical except for colour (choice of incoming was
	arbitrary)); change deaths summary to put results into the recent incoming
	events tab also rather than simply posting them; added estimate of combined
	size of saved data sets, and a warning dialog if the size is greater than
	about 40 Mbytes; clear edit box for renaming data sets after use; since the
	saved (compressed) data sets don't appear to have the same problem with
	"block too big" errors as the normal (uncompressed) tables, compress each
	user's combatant data on logout and on reloadui, and uncompress again when
	loading in; changed event registration logic so that PLAYER_ENTERING_WORLD
	and PLAYER_LOGOUT are always registered; added an option to report to the
	clipboard and WoWChatLog.txt in tab-delimited format (this option and the
	HTML option, being incompatible, toggle each other off); added missing
	tooltip for dropdown menu item 'Lock' for combatant; report of fights to
	the clipboard now gives times in seconds, rather than hh:mm:ss; scroll the
	initial display of deaths to the earliest death; fix to capture instance
	difficulty at the start of a fight rather than at the end; added buttons
	(with custom graphics, create in AppleWorks at 36x36, save as TGA, then use
	Preview to resample to 32x32 so that Warcraft will accept it) to scroll the
	recent events display (all events) to the previous end of fight, or to the
	next end of fight; added dispel class casts, dispel cast fails, and dispel
	fails to the recent events log; search for previous end of fight will pick
	first event if no end of fight is found, and next end of fight will pick
	last event if no end of fight is found; added deaths to the report fights
	standard report; increased warning about number of combatants from 1000 to
	2000; scroll edit box for renaming data sets to beginning of name; added a
	GetSummaries synchronization message to ask for a summary from every member
	(greately simplifies ensuring that all members have the same combatants);
	send a synchronization summary record for every group member, even if they
	do not appear to have taken part in combat; modified Recap so that you can
	pause while in synchronization, and an ongoing synchronization can continue
	while Recap is paused; exiting Recap will turn off any synchronization; a
	synchronization summary is no longer an implicit invitation, each leader's
	summary message is preceded by an explicit invitation, either to a new
	synchronization or to an ongoing synchronization; added a synchronization
	completed message to the console; if the synchronization leader pauses or
	resumes Recap, then all synchronization members will pause or resume;
	researched and modified WIM support to work with WIM 3.1.1 (does scan of
	the active WIM windows to see if one of them has the focus, ignoring w2w
	windows) (reported by ColdsteelEU).

4.28, 2009-05-11 - Added some calls to auto save boss fights; removed some
	spaces in the multi-column posts (suggested by shoe_299); fixed a subtle
	timing error involving new options and the data corruption warning, which
	showed up as an LDBSupport error (reported by Farmbuyer); in the case of
	possible data corruption the character settings are always restored from
	backup (no longer a dialog choice); replaced partial resistance quantization
	with percentage partially resisted; added code to convert existing partial
	resistance numbers to the new format.

4.27, 2009-04-30 - Updated toc for patch 3.1; removed overhealing percentage
	and group DPS In from LibDataBroker to shorten the list of data sources;
	made LibDataBroker support optional, default off; added 'tocname' to LDB
	sources so Titan can properly put them under Combat; include iconR, iconG,
	and iconB at the creation of lastAll source so that the icon colours get
	shown properly by Titan; removed duplicate header in Bindings.xml (reported
	by Farmbuyer); added extra recordings of user option count (found as the
	result of a report by painstorm); added code to properly end a fight when
	solo with "Limit Fights to Combat" enabled (found as the result of a report
	by Silentbob78); tooltip for "Show Tooltips" now shows even when the option
	is off (!); fixed error at RecapPanel.lua line 1642; ignore blank source and
	dest names; ignore summon events Fishing and Basic Campfire that result in
	large numbers of irrelevant pets; fix code to allow for pets with names that
	don't begin with uppercase letters; store multiple spellIDs for each spell
	name; found an error in the Blizzard combat log events for SPELL_SUMMON for
	Raise Dead (until Blizzard fixes this, the Recap code to combine death
	knight pets as "Ghoul Minion" will do nothing); added count of number of
	hits to the deaths posts; added a Recent Events type for interrupts (in
	partial response to a suggestion by shoe_299); added interrupts to the
	control+click Recent Events display (now shows both dispels and interrupts);
	increased the maximum number of Recent Events to 40000.

4.26, 2009-03-30 - Fixed error in SetScaleSlider (reported by Maischter); fixed
	a bug in sorting of data for deaths posts; added a guard question before
	deleting saved data sets; fixed a bug with data set loading; fixed an error
	in the display of minimized live numbers (reported by shadowrm).

4.25, 2009-03-27 - Added code to block with a message having all three of Hide
	Other Combatants, Store Only Displayed Combatants, and Auto Save Boss Fights
	enabled at the same time (reported by painstorm); posting either damage or
	DPS posts both, similarly for incoming damage and healing (suggested by
	Sevenfold); added code to make a best attempt to line up the multi-column
	posted numbers (failed to find any "thin space" in WoW fonts); fixed stupid
	bug that was failing to detect when a hunter death was just a feign death
	(reported by Rizion); added "Delete All" button to Data Sets tab (suggested
	by coani); some optimization of SaveCombatants; fixed an error with display
	of popup panel details for loaded Data Sets when main fights panel was set
	to Last Fight; when Merge Pets is enabled then death knight ghouls summoned
	using Raise	Dead, which have multiple names, will appear as a single
	combined pet named "Ghoul Minion" (suggested by LostHero); added an option
	to merge all pets into one single pet named "Pet", only active if Merge Pets
	is enabled (suggested by LostHero); added dispels to main fight panel
	(suggested by Maischter); fixed an error in tracking the average stack
	height for a stackable buff or debuff; major rewrite of initialization with
	better checks for 'large' data sets; removed support for migrating data from
	versions prior to 3.2; removed option to save and reset on logout (covered
	better by new initialization code); fixed a bug with mouseover display of
	the popup details panel (reported by coani); fixed a number of related bugs;
	split the monolithic saved data set string into segments to keep all strings
	under 65000 bytes; researched the "block too big" error on login; designed
	significant changes to options data and combatants data (now stored on a per
	character basis, reducing the size of the main recap global variable) along
	with a second rewrite of the initialization code (combatants data is no
	longer compressed and decompressed) (saved data sets are still compressed)
	(thanks to coani and Inkx for assistance); corrected some duplicated dialog
	names; change so that the tooltip shows up for the Recent Data Mode slider;
	redesigned the global settings, added a button to copy a global set of
	settings to any character (in response to a suggestion by BBR from way
	back); added an integrity check for the per character data file, with a
	warning dialog with instructions for rescuing data; added a live minimized
	number, the percentage of your damage done by your pet(s) (loosely based on
	a suggestion from way back by BBR); modified RecapFu and TitanRecap to show
	this new live number; added ability to select a range of data sets on the
	Options / Data Sets tab for deletion by clicking on one data set and shift+
	clicking on a second data set; added a message showing how many data sets
	have been selected; added a button to post a report on recent deaths (when
	Recent Data Mode is enabled), which includes time of death, with sources
	and amounts of damage from the last 10 events for the combatant; added a
	Reset All Fights button to the dialog for Reset Last Fight (suggested by
	rakkarage); skip pets in recent deaths report; experimented with separating
	combatants, outgoing, incoming, other, sources, and targets, but does not
	help (no obvious magic number of tables or strings); added code to always
	save a copy of character-specific user options to the global data space;
	added a button on the damaged data warning dialog to restore character-
	specific user options from the backup; added a slash command to do the same
	thing.

4.24, 2009-02-11 - Fixed errors in RecapPanel (reported by elhana); fixed error
	with RecapLoadCloseButton (reported by elhana); fixed error with RecapLoad
	gauges; added tricky heuristic code to assign absorption (from Power Word:
	Shield and Divine Aegis) to the original priest as if it were healing; added
	similar code for paladin Sacred Shield; widened damage and healing columns
	on the main fights panel.

4.23, 2009-02-05 - Added death knights to classes (reported by LostHero); added
	death knight icon (had to convert the class icon file to TGA since I could
	not find a way of editing BLP files on my Mac) (took a long time to find an
	image editor that didn't bork the transparency); fixed error with text for
	ignore GUIDs option on loading a data set (reported by LostHero); mods to
	support RecapFu and TitanRecap with matching changes to those two plugins
	(reported by Chasim and saecula); added option (default off) to save boss
	fights automatically (prodded by clokverkorange); mods to code that collects
	unit information to support the auto save option; new code to create 'live'
	numbers when first logging in (prodded by Filius); fixed a few wrong colours;
	loading a saved data set now puts the data into recap_temp.Load, and this
	data is displayed in a separate panel similar to the main fights panel;
	closing the panel clears the data; menu functions are not available on the
	separate loaded data set panel; the popup details panel shows details for
	the selected combatant from one or the other, but not both at once; made
	health and power numbers persistent; added health and power numbers for
	mobs; added total casts to Incoming and Outgoing Details tabs (suggested
	by floe304); a Reset All Fights button provided on the popup messages when
	joining a group or when entering an instance (suggested by floe304); added
	count of Data Sets to Options / Data Sets tab; added independent sorting
	parameters for the loaded data set panel; added option to automatically
	pause when leaving an instance, and resume when entering an instance
	(suggested by floe304); doubled maximum possible number of recent event
	items stored and shown; added basic support for LibDataBroker (suggested
	by Maischter); added options to save and reset on logout, and to reset on
	logout (suggested by LostHero); added tooltip to the title bar describing
	how to post information to chat (responding to questions from Downthrow
	and others).

4.22, 2008-11-25 - Fixed bug in Report Fights button code; changed colours and
	column order on Fights panels (suggested by floe304); enabled gauging for
	all columns on Fights panel; replaced "&" by localized "and" in spell names
	because e.g. "Death & Decay" breaks the loading of stored Source Details
	(existing stored data is not cleaned up); changed column order for Report
	Fights, and added columns; fixed error with posting recent events; fixed
	opaque backgrounds, which weren't working properly (reported by Maischter);
	removed the heuristic healing code for Earth Shield that had been added in
	4.09; modified the Improved Leader of the Pack heuristic healing code to
	assign (when all else fails) based on druid healing from previous fights if
	available; status light goes amber if current fight is being skipped; added
	a feature to ignore the damage and healing of effects that are specified by
	spell ID (suggested by Farmbuyer and others); added spell ID to Outgoing,
	Incoming, and Other Details tabs.

4.21, 2008-10-14 - Imperfect deletion of heuristic healing code for Judgement
	of Light.

4.20, 2008-10-13 - Modified school translation to allow composite schools (e.g.
	40 becomes Shadow+Nature); modified unexpected event error message function
	so that it only shows the first 10 after any login or reloadui; fixed an
	error that would lead to incomplete assignment of Prayer of Mending and
	similar healing spells if Other Data Mode is turned off; fix to get scroll
	thumb for recent events panel appearing in the right place; added a "Reset
	All Fights" button to the data warning popup (suggested by Theskeptic);
	added "Skip Next Fight" button for sync leader (and for anyone not in sync)
	that skips current or next fight (suggested by MhicAoidh); made Skip Next
	Fight available as a key binding; various mods for patch 3.0.2; converted
	from Ace2 to Ace3; replaced code that estimated overhealing with code to
	use the new overheal numbers; made local all functions that could be made
	local; added new SPELL_RESURRECT combat log event; added "None" as a school
	to support "Owl's Focus" and perhaps other auras; fixed all remaining 'this'
	references; renamed the key binding "Toggle Recap" to "Hide / Show"; added
	a key binding for "Pause / Resume"; fixed a bug that was collecting too
	much data with "Limit Fights to Combat" turned on; fixed a bug that was
	collecting too much data with "Store Only Displayed Combatants" turned on;
	some of the heuristic healing code that was added in version 4.09 is no
	longer necessary (at this point still keeping Earth Shield and Improved
	Leader of the Pack pending further testing); removed fight start, fight
	end, and fight duration from data being synchronized because the event
	times supplied by Blizzard to different clients do not match; also removed
	most of the code that synchronized the Seen column.

4.10, 2008-07-30 - Fixed errors in new healing code that show up when the Store
	Only Displayed Combatants option is enabled (reported by MhicAoidh); added
	guard code for unexpected school, and translate school 40 to Fire (Blizzard
	error reported by painstorm); added code to handle the three new combat log
	event types for 2.4.3; more tweaks for Prayer of Mending and similar heals,
	including taking the youngest available migration record rather than the
	oldest.

4.09, 2008-07-15 - Added calls to collect garbage after major release of memory,
	including after a reset, after restarting a sync, after deleting a saved
	data set, or after turning off recent events (reported by fyrye, not a bug
	fix per se, allows users to see immediately how much a reset frees); fixed
	problem with pets not being in 'InGroup'; added tricky heuristic assignment
	of Prayer of Mending procs to priests; added easier heuristic assignment of
	Lifebloom final procs to druids; similarly added Earth Shield for shamans;
	similarly added medium tricky Judgement of Light for paladins; similarly
	added medium tricky Improved Leader of the Pack for druids; changed two
	combat log event types for 2.4.3, and set three new ones to ignore (will
	need code).

4.08, 2008-06-12 - Fixed an error in a German format string; fixed an error that
	was preventing many spell casts from being recorded properly in Other Data;
	reworked the code for all minimized display options in an effort to get them
	all working correctly (reported by rakkarage); added some optimization for
	math, string, and table global calls; fixed an error at Recap line 4560 when
	resetting a personal effect.

4.07, 2008-05-01 - Replaced the four settings (Only Friendly Combatants, Only
	Party Combatants, Only Player Combatant, and Store Only Friends / Party /
	Player) with three settings (Hide Group, Hide Other Combatants, and Store
	Only Displayed Combatants); modified other references to Friend to refer
	to Group; fixed a problem with combatant not staying highlighted under a
	dropdown menu; number of lines reported to WoWChatLog.txt increased to 100;
	added dispels (including the breaking of crowd control) to the recent events
	buffer; on the main fight panel holding down the control key while double-
	clicking a combatant's row, or while clicking a combatant's Recent button,
	will bring up the recent events panel with dispel events only; fixed an
	error in live DPS and HPS calculations with Merge Pets on that used min
	instead of max (reported by Chasim); fixed a couple of errors that were
	failing to load a -1 combatant level from a saved data set; now do not
	mark raid bosses (level of -1) as trash, even if there are multiple bosses
	with the same name; removed the left-click on main panel totals line that
	brought up the details panel with totals for group combatants (use the green
	Total button); added a double-click on the main panel totals line to bring
	up the recent panel with all recent events; added a control+double-click on
	the main panel totals line to bring up the recent panel with all recent
	dispels; fixed an error at RecapPanel line 1125 (reported by Sotakone);
	changed all use of 'type' as a variable since 'type' is a reserved word;
	ignore the Outgoing component of damage from one group member to another
	group member (requested by many); added one place of decimals to the damage
	out % column on the main fights panel; fixed an error at RecapAux line 929
	(reported by wilshire24148); fixed an error at RecapAux line 3024 (reported
	by Darthelas); reverted Recap_Click to Recap_OnClick (I had inadvertently
	broken RecapFu) (reported by Chasim); added code to record Blizzard flags
	for a combatant; removed code that could start tracking a fight with the
	cast of a Prayer of Mending or similar delayed effect spell; removed some
	code that was blocking tracking many casts as Other events; added a call
	to MakeFriends whenever an uncontrolled combatant becomes controlled as a
	pet; fixed an error in display of All or Last when minimized (reported by
	rakkarage).

4.06, 2008-04-14 - All multi-line posts (other than to the clipboard) now use
	the "Report in Multiple Rows" slider (on Options / Reports tab) to govern
	the maximum number of data lines posted (suggested by LostHero); the maximum
	value of the slider is now 100 lines; removed the option to have single line
	posts instead of multi-line posts; fixed an error at RecapRecent line 117;
	fixed an error at RecapAux line 2570 (reported by Tenyks); removed some
	diagnostic checks for events with zero amounts (reported by Farmbuyer);
	added some optimisations for end of fight processing to limit unnecessary
	copying of pet data with Merge Pets on; other end of fight optimisations;
	rewrote live DPS and HPS update code; changed overall fight timers to be
	for friends only, not for all combatants (this has been wrong for years!);
	fixed a situation where a pet re-appearing upon dismount and being sent to
	start a fight would not appear to be owned for the first blow they land; in
	the popup details panel the information for same-name pets is amalgamated;
	added code to correct for a summon event for an object (e.g. totem) being
	seen later than an event in which that object does something (e.g. the pet
	makes an attack); corrected Target and Source details data structure to
	properly include owner's pets; changed code to never remove ownership from
	a guardian or object even if it is apparently uncontrolled; cleaned up code
	that uses the deprecated 'this' and 'arg1'; fixed an error at RecapRecent
	line 114 (reported by Injury); save Merge Pets setting and Ignore GUIDs
	setting with a saved data set, and print the values when a data set is
	loaded.

4.05, 2008-04-02 - Fixed an error at RecapSync line 1151; improved detection of
	when a mind controlled combatant reverts to being hostile; now ignore the
	deaths of objects (e.g. totems); optimized live update value calculations,
	and reduced the frequency to once a second (based on a report by Cryect);
	fixed an error at RecapAux line 1966 (reported by baloor); the All Fights
	panel is no longer updated live during the receipt of synchronization data,
	which may remove a Recap stutter (reported by Maischter); added a timer to
	update the All Fights panel and to do any requested auto-post activity some
	while after the last synchronization data has been received (the timer uses
	the existing setting of "End of Fight Delay") (reported by Sorix); fixed
	some bad display lines and shift+click postings in Outgoing Details and
	Incoming Details; fixed an error at RecapSync 858; restored titles to
	Friendly and Non-Friendly total popup panels.

4.04, 2008-03-28 - Changes to avoid or remove empty events in Self; further
	slimming of saved data sets; fixed some anomalies with menu positions; may
	have fixed frame creep problems; increased width of Numbered List field on
	the main panel to allow for four digits; fixed a problem with loading saved
	"Target of Outgoing" data (data was saved correctly but reads back as
	zeroes); fixed an error at RecapSync line 890; added total duration to
	synchronization data and fixed some bugs in RecapSync; fixed an error at
	Recap line 4229 and added feminine German class names (reported by
	Maischter); added feminine French class names.

4.03, 2008-03-26 - Fixed an error at RecapAux line 1693 (reported by Celthay).

4.02, 2008-03-26 - Fixed an error at Recap line 1168 (reported by Celthay).

4.01, 2008-03-26 - Removed Global Unique Identifiers from some sync messages;
	set CVar scriptProfile to get addon CPU times; fix for error in RecapAux
	line 1684 (reported by LoSaH).

4.00, 2008-03-25 - Further checking shows that Windows lua strftime does not
	support the %e format, so we now use %d (thanks to Charleen for help with
	testing this); made a tooltip specifically for Recap so that changes to the
	scale of Recap do not affect other game tooltips (reported by H0PE); added
	a spacer line between damage and healing for postings of Target and Source
	lines and Personal Detail lines; fixed format of posting of healing effects
	from Personal Details; added tooltip showing effect name for Personal
	Details lines; added WIM support (if a WIM chat edit box has the focus then
	Recap will post to that person); maximum recent events increased to 10000;
	my Recap_Quick_Start file for 3.77 wouldn't open, so I fixed it, but this
	may not have affected anyone else; reduced the number of recent events
	posted to chat to 30 from 100 (suggested by elhana); fixed the tooltip for
	Clear Inactive Members button; took the period off the rank number, and
	widened the column 2 pixels; did a major rework of the combat log event
	processing for patch 2.4, replacing ParserLib with direct processing of the
	combat log events; added code for tracking buff or debuff stealing; removed
	code for tracking 'vulnerable' damage; added code to track aura breaking
	(SPELL_AURA_DISPELLED) as an unknown (white) effect doing 'Dispels' on the
	Other Details tab; added spell cast interruption as an unknown (white)
	effect doing 'Interrupts' on the Other Details tab; added a matching new
	unknown (white) effect being 'Interrupted' on the Other Details tab; added
	kills and deaths to the Recent Events; added code to count casts for HoTs
	with no direct healing component; removed the Maximum Event Range setting
	(now obsolete); added StartMoving/StopMovingOrSizing call pair to a number
	of functions, which seems to remove most Recap frame positioning issues in
	patch 2.4 when switching between windowed and full screen (don't ask me why
	it works because I don't know, this is juju); changed combatant names to be
	fully qualified by GUID; added an option (deprecated) to not use the GUID;
	added a sync record for fight start and end times so that DPS vs All is in
	sync (suggested by Diabolus666); major redesign of pet tracking; hiding
	yard trash now done by counting the number of identically named mobs, not
	their deaths; added a separate set of details for Last Fight (suggested by
	wenzie and doktorstick); added a new double-click on a recent event to show
	a new Recent panel ("Time Window") displaying events on both sides of the
	time of the clicked recent event; changing a combatant's Friend status
	using a menu will also change that combatant's pets; increased the data
	warning point from 500 combatants to 1000 combatants; added to main panel
	the time that a combatant is first seen; sorting by name will sub-sort
	identical names by time first seen; made a number of changes so Recap uses
	less memory to store its tables; added double-click to bring up the Recent
	panel for all rows that have a Recent button; (oopsie) made two sets of
	summary variables for Last Fight; track the minimum and maximum values of
	a group member's maximum health and power, and show them on the tooltip;
	fix for saved options and saved datasets with change from NameServer to
	Name_Server.

3.77, 2008-01-02 - Adjusted a date format string to avoid a Windows lua bug
	(reported by IronEagleNZ); fixed Recap_MakeFriends to not create empty
	entries when not storing data for a combatant (reported by nimrodel);
	possible fix for graphic anomaly (reported by fyrye).

3.76, 2007-12-31 - Removed the Hold / Resume button from the Last Fight panel
	(commented out so that if anyone really wants it back this can be done);
	added Matrix data mode, showing Target of Outgoing and Source of Incoming
	Details of who damaged or healed whom (requested by Maischter); picked new
	shield and sword icons for the popup panel; added a setting to change the
	scale of Recap (suggested by Razumikhin and rugger); changed date string for
	new Data Sets so that they will sort in date order as originally intended;
	upgraded display of Recent Outgoing and Incoming Events to put the events
	into a new popup panel, from which they can be posted to chat if desired;
	similarly for Recent Events for a combatant filtered by effect; replaced
	the key click combinations for displaying recent events by Recent buttons
	(intentionally always visible and large, at least for this version); fixed
	a bug with stored details that overwrote interval count with estimated
	amount resisted, and total time interval (a hidden field) with estimated
	amount resistable; fixed a bug where pet partial resistances, crush damage,
	and several other detail fields were not being copied up to the owner when
	merge pets was on; added colour to the new recent events panel, and to
	posting of recent events to the console (but not to chat channels, which
	disconnects you if you try); fixed a bug whereby effects without sources
	(such as the Void Reaver's Arcane Orbs) did not have their resists and
	dispels recorded on the Incoming Details tab as expected, but on the Other
	Details tab; relaxed key click rules so that shift+click works for posting
	to chat regardless of whether the left or right mouse button is clicked;
	added code to sort combatants by class in the fight panels; improved the
	detection of entering or leaving instances using IsInInstance(); fixed a bug
	that was preventing overhealing being included in the Total Healing data on
	the Outgoing and Incoming Details tabs; rewrote the code for handling totals
	and subtotals for Outgoing and Incoming Details so that underlying details
	will be available for subtotals and totals with Merge Pets on; fixed a bug
	that could delay the healing of a pet showing up in the owner's Incoming
	Details with Merge Pets on; fixed a problem with inconsistent row selection
	on the Outgoing and Incoming Details tabs; replaced key+click combinations
	on total row of the main panel (to pop up a panel with Friendly and Non-
	Friendly combined details) with two buttons to perform the same function.

3.75, 2007-11-29 - Fixed a typo in RecapSync; added estimated total amount of
	damage resisted (inspired by a suggestion by wenzie); removed the option to
	refresh the party frame (blocked action reported by coani); fixed a set of
	long-unreported bugs to do with nil default options.

3.74, 2007-11-13 - Added a slash command ("/recap reset") to Reset All Fights
	suggested by purabasura666); added "Looking For Group" to the list of
	channels blocked for Recent Event output; added a heartbeat message for
	synchronization that will broadcast information every five seconds from
	members of the synchronization including name, server, and Recap version;
	the count and list of members of the synchronization will separate those
	who have been heard from within the last ten seconds from those who have
	not; added personal HPS and total HPS to the minimized view (suggested by
	pfgpally); new Remove Inactive Members button removes from the list of sync
	members those who have not been heard from within the last ten seconds;
	made use of the new SetFormattedText for some reduction in memory garbage.

3.73, 2007-11-08 - Fix for sync bug (reported by painstorm) which turns out to
	have been incompatibility between revisions of AceComm; disabled general
	events when Recap is paused, to reduce memory use (reported by BBR).

3.72, 2007-09-17 - Fix for TitanRecap (I'd moved the graphics for 3.71, and
	failed to realise that TitanRecap and RecapFu use those graphics); increased
	the maximum number of recent events recorded to 5000; added an option to not
	store data for combatants who are not displayed (requested by Zosopage and
	others); truncated dump messages to shorter than 255 bytes (ChatThrottleLib
	has started to complain), and modified reporting (to WoWChatLog or clipboard)
	to send HTML report lines in multiple parts.

3.71, 2007-08-20 - Fix for an extra border around the Recap main panel (reported
	by Avanger); fix for an error posting total information to chat in European
	clients (reported by LostHero); fix for missing entries in the German
	Localize.LinkRank table (reported by Maischter); check friends (including
	their maximum and current hit points) every half second (suggested by
	wenzie); fix for an inconsistency in the display of DPS when Recap is
	minimized (reported by Rogdor); improved treatment of players and pets
	when they have the same name (reported by bobbysmith56); added an option
	to pop up a reminder whenever the player enters or leaves an instance (in
	partial satisfaction of a suggestion by Rogdor, who wanted an option for
	automatic Data Set cycling on entering an instance); added full Simplified
	Chinese localization (many thanks to Ariestk).

3.70, 2007-07-10 - Added subtotals by element to the end of the Outgoing and
	Incoming Details tabs (based on a suggestion by shinsplitter); added a
	special total panel that lists combined Outgoing, Incoming, and Other
	Details for all friendly combatants (left-click on the Fights total line);
	similarly for all non-friendly combatants (control+left-click); both special
	total panels are calculated on demand only, since they take a significant
	amount of time; improved table lookup code so Recap runs faster; the
	synchronization invite message now indicates whether the synchronization
	is new or ongoing; every synchronization member will now reply at least
	once to every set of Summary data so that the list of synchronization
	members is more accurate (based on a suggestion by Ryann); tweaked Recap
	colours; added lighter colours for subtotals and totals; modified code so
	that short fights (no combatant dealing or taking damage for longer than
	five seconds) do not overwrite the Last Fight panel numbers, but do get
	added into the All Fights data (suggested by many and with the solution
	inspired by syrixx); added total amounts for the partials on the Outgoing
	and Incoming Details tabs (suggested by wenzie); fixed bad display when
	switching between All Fights and Last Fight while minimised (reported by
	vedran_m); limit Recent Event output to the 100 most recent events if
	posting to a chat, and to the 500 most recent events if posting	to the
	clipboard; added moderately complicated code to get the subtotals and
	totals correct on the Outgoing and Incoming Details tabs when Merge Pets
	is on; wrote a new introductory document, Recap_Quick_Start.rtf; adjusted
	some default settings; added some messages (English only at the moment)
	to the slash handler.

3.69, 2007-06-23 - Increased the time limit on measuring event intervals and
	durations from 120 seconds to 130 seconds; created separate interval and
	duration timers, with interval timers reset between fights; changed dump
	to use ChatThrottleLib; added glancing blows to the Outgoing and Incoming
	Details tabs; added glancing blows to the Personal Details panel; rearranged
	the Outgoing and Incoming Details tabs; added partial absorbs, blocks,
	resists, and vulnerability damage to the Outgoing and Incoming Details
	tabs; cleaned up rounding throughout; added code in three places to handle
	incorrect values from Parser-3.0 when it overrides ParserLib (reported by
	sod and cabaluk); added minimum values for the five types of hit on the
	Outgoing and Incoming Details tabs, and for the four types of hit on the
	Personal Details panel (suggested by Tekao); added a slash command
	"/recap gmin on" to enable tracking of gross minimums (i.e. with partial
	absorbs, blocks, and resists added back in, on the Personal Details panel
	only); changed the slash command "/recap reset" to "/recap centre" (or
	"/recap center").

3.68, 2007-05-26 - Fix for Personal Details not displaying in Public Test Realm
	because of parentheses in the realm name; added error display so that Recap
	will always display lua errors (WoW 2.1 would otherwise have them off by
	default); added Recap version number to diagnostic messages; added tracking
	for other effects (casts, debuffs/losses, buffs/gains, and so on) (suggested
	by Elsia and others); added environmental damage (fire, falling, and so on);
	cleaned up OnUpdate code, so Recap should run a teensy bit faster; for the
	leader of a synchronization the Reset All Fights button (and the matching
	hotkeys) will do a Start Synchronization (suggested by Mazzlefizz); Recap
	will no longer automatically send synchronization data (for the leader of
	a synchronization, members only ever respond) if not in a group (suggested
	by Mazzlefizz); changed the format for displaying pet details on the popup
	Details panel (when Merge Pets is on) to the same format as on the Personal
	Details panel (lines in the old format will remain until the next reset);
	added more code in an ongoing attempt to fix the occasional bad Time numbers
	(reported by Ryann and others); pausing Recap is no longer permitted during
	synchronization (suggested by Ryann); added an error message if someone is
	unable to sync because they are running an older and incompatible version
	(suggested by LostHero); added a List Members button to the Options / Sync
	tab (suggested by Mazzlefizz); added a count of members in sync to the main
	panel title bar (suggested by Mazzlefizz); fixed minimized display of DPS
	when Merge Pets is on (reported by Anari-LB); added 'group fight time' and
	'group dps' to the tooltip for the total line for the fight panels (suggested
	by shisou and Ryann); extended all scroll lists on Details panel to 8 lines;
	added interval tracking for damage and healing effects; fixed occasional spam
	of sychronization invitation declined messages (reported by Beros); fixed
	FightStartIn misspelt as FightStartin (found as the result of a report by
	Burnum).

3.67, 2007-05-05 - Fix for absent source for a miss (reported by teedog); added
	first class storage of player's pet details, just as for player's Personal
	Details (originally suggested by Phaelon); fixed a bug that could display
	All Fights text outside the panel after switching from Personal Details.

3.66, 2007-04-18 - Fixed a problem with tracking unexpected events (reported
	by Azonia); ignore the Outgoing portion of damage from owner to pet (such
	as Soul Link) and vice versa, which would otherwise inflate DPS (reported
	by uitachi); calculate crit percentages and crush percentages based on hits
	attempted rather than on hits landed; de-localized channel names for auto-
	post, replacing them with the Blizzard channel names for the actual posting
	(reported by Sharrath); added guard code to function Recap_SetSyncStateDetail
	to prevent 'nil' errors (reported by Avanger); added code to ignore misses
	from ParserLib that are for non-damaging effects.

3.65, 2007-04-11 - Option to automatically refresh the Blizzard party frame
	should have been off by default.

3.64, 2007-04-09 - Fixed incorrect Escape behaviour (reported by sod); fixed
	missing update of minimized DPS (reported by flabby); added more death
	reports (suicides and similar deaths) from ParserLib; fixed some incorrect
	fight duration calculations (a problem present in version 3.32) (reported
	by Anari-LB); reset 'time elapsed since last sync update' upon login or
	reloadui, since we can not guarantee times that are good across reboots;
	added temporary option to refresh Blizzard party frame at the end of a
	fight (if party composition changes during a fight, or if you join a party
	during a fight, the party frame may not be updated properly by Blizzard);
	made Options / Data Sets fields larger; added garbage collection setpause
	110 (the future Blizzard 2.1 behaviour); added option to trigger garbage
	collection at the end of each fight (reported by Harrycanaryx).

3.63, 2007-03-23 - Fixed bug in combatant tooltip (a bug since 3.59) (reported
	by LostHero); fixed debug spam (reported by Dridzt); fixed bug with opaque
	background (reported by Maischter).

3.62, 2007-03-22 - Fixed (I hope) a bug that happened when trying to turn on
	Recent Events during combat; added Minimize on Escape option so that the
	Escape key behaviour only happens when the option is chosen (reported by
	ElrickEnonimis); added Sync Light option for the sync status light
	(suggested by LostHero); added pet owner to combatant tooltip; fixed
	incorrect unregister behaviour on shutdown (reported by shadedtactics);
	a number of fixes for the info table from ParserLib having been made non-
	traversable; added crushing blows to incoming and outgoing details, and
	to the recent events data (suggested by Mundane and others); added an
	option to pop up a reminder whenever the player joins or leaves a group
	(in partial satisfaction of a suggestion by gren99, who wanted an option
	for automatic Reset on joining a group).

3.61, 2007-03-13 - Ignore the Outgoing portion of self-damage (such as Shadow
	Word: Death) which would otherwise inflate DPS (reported by shadedtactics);
	fix for ParserLib now returning source equal to false rather than nil for
	some death events (reported by blake7); modification for Ace2; fixed
	posting of personal details to Clipboard; added several missing tooltips;
	enlarged some panels and fields to accommodate the longer text strings
	needed in German and French; added synchronization for All Fights
	summary information (suggested by many); full German localization (thanks
	Dhana); rework of healing and overhealing for synchronization (it needed
	doing some time), tables now store raw heal and overheal numbers (hidden
	columns) with actual healing for display calculated from those; overhealing
	calcs now available even in light data mode; thanks to Runabout, LostHero,
	and Harrycanaryx for help in testing sync; fixed a bug introduced in the
	early stages of this version (reported by mtrixis); raised the frameStrata
	(suggested by Maischter), and added an option to have an opaque black
	background (something I've always wanted for screenshots); fix for panels
	always showing on login even when they shouldn't be (reported by coani);
	reverted to pre-3.59 behaviour for pet effects showing up on the owner's
	personal details (they now only show up when Merge Pets is turned on);
	removed pet incoming damage from the owner's personal details (this had
	been added in error); fix for a sorting error (reported by Rabaa); fix
	for missing event registrations due to the switch to Ace2 (thanks for
	debug assistance to LostHero); the Recap main panel now minimizes when
	the Escape key is pressed (quite tricky to get right; it is something
	I have always wanted Recap to do); many thanks to LostHero for assistance
	with capturing ParserLib bugs for me and Rophy.

3.60, 2007-02-17 - Fixed menu display bug (limited to 18 items, needed 19);
	fixed Outgoing and Incoming Details panel bug (fields in lower half of
	the screen were not being cleared properly); added a delay after player
	leaves combat in an effort to prevent fights ending prematurely.

3.59, 2007-02-14 - Added an option to show only party members (and pets)
	(suggested by Zosopage); modified the existing option that tracked only
	the player (and pets) to revert to tracking all combatants but to show
	only the player (and pets); moved those options to the right hand side
	of the Options / Settings tab; added deaths to the line report for a
	combatant; added a button to report personal details ("effects") to the
	clipboard; reporting to WoWChatLong.txt now includes a report on personal
	details; pet Spells and Abilities will now always appear with the owner's
	personal details whether pets are merged or not (suggested by Phaelon);
	corrected option Only Unique Combatants which was only showing non-friendly
	combatants who had died exactly once; added a column to personal details
	showing the element (Arcane, Fire, etc.) for the effect (suggested by
	shinsplitter); added a line to the Outgoing Details tab of the popup panel
	showing the element; added the element to recent events; added ability to
	post all Recap key+click reports to the Clipboard; fixed colour of pet
	healing on Outgoing Details tab; time spent taking damage and time spent
	healing now displayed throughout; added an Incoming Spell or Ability
	table to the Incoming Details tab (similar to the existing table on the
	Outgoing Details tab; added a full breakdown of miss types to the Incoming
	Details tab; added a full breakdown of miss types to the Outgoing Details
	tab (suggested by Cuddlejam); added a Locked field to combatants, set by
	popup menu, with a Locked combatant and their pets not being removed during
	a Reset All Fights (suggested by Filius).

3.58, 2007-01-26 - Added click-reporting from the totals line for All Fights and Last
	Fight, including separate totals for the non-friendly combatants (not otherwise
	available); added a button on Options/Data Sets to save the Last Fight; added a
	button for holding the Last Fight panel so it can be examined or saved; fix for
	an over-enthusiastic attempt to round percentages (reported by jjacko); added
	a simple integrity check for program files.

3.57, 2007-01-15 - Fix for deaths not being recorded for the player (reported by
	LostHero); repair for miscalculation of Tick counts and averages (reported by
	jjacko); added a Ticks item to Details to minimise future confusion; some
	cleanup in preparation for localization.

3.56, 2007-01-12 - Fix for some postings going to 'say' rather than to chosen channel
	(reported by xenmal); format changes to the Options/Reports panel.

3.55, 2007-01-10 - ParserLib is now a separate folder; updated toc to patch 2.03;
	a number of improvements to posting, including sorting Personal Details columns
	when posting by column, and crediting "Recap" for all posts; separated
	"Write to WOWChatLog.txt" into Open, Report, and Close buttons.

3.54, 2007-01-06 - added hotkey support for "Reset All Fights", "Reset Last Fight",
	"Reset Personal Details", and "Reset Fights and Details" (suggested by Knifed);
	added separate durations for combatants for damage dealt, damage received, and
	healing done; added "HPS" (healing per second) and "DPS In" (damage received
	per second) columns to the main fight lists; added "HPS" and "DPS In" on the
	popup Summary; restored Recap's ability to remember selected combatants between
	"All Fights" and "Last Fight" lists (thanks to a report by Phaelon); fix for
	the healing half of dual damage/healing DoT/HoT spells (such as Siphon Life)
	being incorrectly reported via ParserLib as non-HoT effects; replaced
	SPELLCAST_START events with UNIT_SPELLCAST_SUCCEEDED events; added option to
	collect data only for player and player's pets (suggested by TheRealAgro);
	investigated some of the zero-healing events and will no longer issue diagnostic
	messages for them (nor for similar zero-damage events if any occur) (reported by
	LostHero); added option to remember recent events, and to post them to chat
	filtered by combatant and spell or ability (suggested by Elsia); added option
	to set combat event logging range to maximum (suggested by Zamolxis); fixed a
	problem with merging pets with owners (existing merged information may be
	inaccurate); every posting field (any field that responds to shift+left-click or
	control+left-click) should now post to the player's console if a chat edit box is
	not open; fixed a bug where pet owners might not show up on the "Last Fight"
	panel while they had "Merge Pets with Owners" turned on; added confirm
	dialogs for the Resets on the Last Fight panel.

3.53, 2006-12-28 - modified Incoming details to separate non-melee hits and
	non-melee ticks; increased size of scroll box for outgoing details to
	six lines; added German recognition of duplicate "<spellname> kritisch";
	fixed a bug that would occur if the first event for a previously unregistered
	combatant was a miss; fixed a bug at Recap 3590 (reported by Anari); modified
	Recap to include ParserLib; fixed duplicate "<combatant>'s <spellname>" for
	healing; fix to calls to UnitName (which fixes the battleground name problem,
	broken since patch 1.12, although Recap will combine two combatants with the
	same name from different realms); fixed some issues with tracking misses;
	added a debugging feature to copy everything received from ParserLib to
	WOWChatLog.txt.

Notes for 3.53 concerning ParserLib:
- Repaired by 3.54: ParserLib reports the healing side of "Siphon Life" as a
  non-HoT heal, so Recap will record it as healing 'hits' rather than as healing
  'ticks'.
- Blizzard reports many deaths twice, and to avoid recording many deaths twice
  it is necessary to occasionally miss recording a death.
- ParserLib reports resists of some non-damaging effects (e.g. "Tainted Blood
  Effect" and "Fear") as the resists of damaging spells, and Recap will record
  them that way.

3.52, 2006-12-22 - fixed sorting order error for "Outgoing Details: Damage"
	tab (reported by Anari); fixed yet another 'nil' result error (reported
	by Anari); fixed a problem with sorting columns of averages in the
	personal details (reported by Anari); fix to show 100% overhealing; fixed
	error in report dropdowns (reported by Silan).
3.51, 2006-12-21 - fixed typo that prevented main "Spell or Ability" panel
	sorting properly; fixed typo that prevented counting misses; added
	ability to sort "Spell or Ability" panel by column in the same way
	as the main ("All" or "Last Fight") panel; a fix to further reduce
	display problems after changing column selections.
3.50, 2006-12-20 - modified by Hawksy (on Elune) from lua 5.0 to lua 5.1
	for WoW 2.01; forced default values in the lua code for all options
	not already initialized; adjusted logic so that healers don't have
	to do damage, or be damaged, before they show up in Recap; assorted
	other updates (a lot of code that worked in 5.0 no longer works in 5.1,
	for example 'nil' results are no longer propagated quietly upwards);
	fix to ChatFrameEditBox code; fix to recap_temp.DropMenuTemplate; fix
	to writing to WOWChatLog.txt; workaround for bad text display when
	Class is not selected as a column; modification to show a higher
	proportion of combatants in the "Last Fight" panel; separated Faction
	icon and level number, since overlaying them made both hard to read;
	modification so that on the personal details panel heals are shown at
	full value; modification so that hit points for friends are gathered
	at the start of a battle, so that overhealing is more accurately
	calculated; fixes to clear List and SelfList tables rather than
	re-using them; increases in the widths of a number of display fields;
	fixed list redisplay after deletion (resetting) of a combatant or effect;
	doubled the time before the popup menus fade.
