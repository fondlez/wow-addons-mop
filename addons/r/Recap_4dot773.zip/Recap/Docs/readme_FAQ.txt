﻿"Frequently Asked Questions" (FAQ) for Recap

Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference.


This FAQ covers features introduced or significantly modified since version 3.32

For earlier features please see the file readme_332_FAQ.txt


Table of Contents

1) Exclusive (or nearly so) Features
2) Posting Recap data to chat channels
3) Healing
4) Overkill
5) Damage Per Second
6) DPS divided by Gear Value ratio
7) Recent Event Recording
8) Live Graphs and Text Listings
9) Saving Reports
10) Last Fight Examination and Saving
11) Synchronization
12) Pet Details
13) Other Details: Casts Debuffs/Losses Buffs/Gains
14) Crushing and Glancing Blows
15) Partial Effects
16) Resistance
17) Subtotals, Totals, and Grand Totals
18) Target of Outgoing damage and healing, Source of Incoming damage and healing
19) Healing from priest Prayer of Mending and similar healing spells
20) Power Word: Shield and similar absorption shields cast by healers
21) Detail Entries for All Group Members
22) Skip Next Fight
23) Ignoring Effects
24) Special Cases
25) Miscellaneous
26) Memory and CPU time notes


__ FAQ: 1) Exclusive (or nearly so) Features __

Q: How does Recap differ from other damage meters?

A: Recap credits the damage absorption by healer shields as if it were healing, so you can get a much better idea of how useful discipline priests are as healers.  [ With patch 4.0.1 other damage meters may now track this information. ]

A: With Other Data Mode enabled, Recap goes into finer detail about combat-related effects than most other addons.

A: Recap has a powerful Recent Data Mode that allows you to roam through the fight(s) just finished, examining in detail exactly what went right and what went wrong, from the perspective of any combatant or of any boss ability.

A: Recap can create a summary analysis of recent deaths for all group members.  [ In 2010 some other addons began reporting similar information. ]

A: Recap can create a summary of a single detail entry (such as maximum critical hit amount) for all group members.

A: Recap allows you to compare the current fight with a previous fight (a saved data set); or to compare two previous fights (saved data sets).

A: Recap tracks every mob and pet separately, so you can compare how one Guardian of Yogg-Saron did compared to another Guardian of Yogg-Saron.

A: Recap has tooltips for everything.

A: Recap can graph outgoing DPS live from the current fight for group combatants, as well as incoming DPS and outgoing HPS.  There is also a live text-only listing, with bar graphs.


__ FAQ: 2) Posting Recap data to chat channels __

Q: How do I report the daamge, healing, and like that to raid and guild?
A: You report from Recap in the same way that you would link a weapon or a quest or a recipe ingredient.
A: Open almost any chat window (such as "/p" or "/g" or "/ra" or "/w Hawksy") and leave it open.
A: Then shift-click on almost anything in Recap that highlights in light yellow when you mouse over it.  For example, shift+clicking on the row for a combatant posts info about that combatant to the chat that you have open; and shift+clicking on the column header "DPS" will post the top DPS numbers to the chat.  And so on.
A: You can experiment if you don't want to risk sending something unexpected to, for example, guild chat.  If you have no chat window open, and if you shift-click on something in Recap, it will post to your own console so you can see what you would get.
A: Recap will not post to General, Trade, and similar wide distribution channels.

Q: Why don't the new multi-line multi-column posts to chat line up properly?
A: In the default WoW chat font, a font with variable-width letters, is it not possible to line things up exactly unless tab settings are provided.  Blizzard does not support tab settings for the chat windows.

Q: Why did you bother trying then?
A: I found it hard to read multiple lines of three or four items of data separated only by single spaces, so I tried more and more spaces, and eventually tried to simulate separate columns as best I could.  Note that if you and your recipient are using different chat fonts, then the results that they see may not match the results that you see.

Q: With the new "IM Style" chat style introduced with patch 3.3.5, how do I post to my own console?
A: Recap posts to your console if there is no chat edit box visible.  With "IM Style" the chat edit box is always visible.  You have two choices.  Either switch to "Classic Style" for chat, or whisper to yourself.

Q: Can I post non-friendly combatant information?
A: Starting with 4.71, holding down the alt key (option key on a Mac) while shift+clicking on a column header on the main panel, or on the separate load panel, will post information for non-friendly combatants instead of for friendly combatants.


__ FAQ: 3) Healing __

Q: Do pure healers show up during a raid?
A: Yes, healers now show up on the list of combatants as soon as they heal, not just when they give or receive damage.

Q: Is the calculation of overhealing more accurate?
A: Yes, the reporting of overhealing should be more accurate since Recap now checks health (for party and raid) continually throughout a fight.  See also the next question.

Q: What about overhealing with patch 3?
A: Blizzard now provides exact overhealing amounts, so Recap no longer has to estimate these numbers.


__ FAQ: 4) Overkill __

Q: What about overkill with patch 3?
A: Blizzard now provides exact overkill amounts.  At the moment Recap does nothing with these amounts, and continues to record full damage (actual + overkill).  In most group or raid situations, especially for boss fights, it will make very little difference to the total damage done by a combatant.


__ FAQ: 5) Damage Per Second __

Q: What is DPS (damage per second)?
A: DPS is the damage that a combatant does, divided by the time in seconds that they take to do that damage.  DPS numbers should be used with caution.

Q: Why does Recap DPS differ from the DPS calculated by other combat meters?
A: Combat meters seldom differ in the damage done by a combatant, except perhaps in how they account for various kinds of 'friendly fire'.  Where they differ more is in time in combat for purposes of calculating DPS.  Each combat meter author can have a different philosophy about that time.  Comparing DPS numbers between different combat meters should be done with doubled caution.
A: In addition, the order of combat log events may vary from computer to computer, and the timestamps for the combat log events vary as well.  Thus, two people running Recap and standing next to each other will make slightly different time measurements, and consequently will calculate slightly different DPS numbers.

Q: What is Recap's philosophy?
A: Recap tries to calculate the overall average sustainable DPS contribution of a combatant to a fight.  This is similar to what is called "effective DPS" elsewhere.  Recap's calculated time in combat for a combatant will be higher, and so DPS numbers will be lower, than for a combat meter that suspends the timer if the combatant stops doing damage in the middle of a fight.

Q: Does Recap calculate DPS In (damage per second done to a combatant) and HPS (healing per second)?
A: Yes, separate durations are kept for each combatant for damage done, damage received, and healing done.  DPS, DPS In, and HPS are calculated using the corresponding durations.  You can see the raid's total DPS done to a boss in the "DPS In" column for that boss.

Q: Why does Recap show three Time columns?
A: The Time Out column is the duration for damage done.  The Time In column is the duration for damage received.  The Time Heal column is the duration for healing done.

Q: Why is the Recap DPS calculation especially good for groups and raids?
A: Because DPS classes are not penalized on the DPS calculation while they wait for the tank to gain aggro.  "Wait for three sunders"?  No problem.  Their DPS for the fight will be based on the time of the individual combatant's first and last damaging attacks.  The DPS+ column will continue to show DPS based on the overall duration of damage done by anyone for the fight.

Q: What about combatants who only get healed?
A: Recap does not track combatants who neither do damage, receive damage, nor do healing.  A minor point, but this means that a combatant who gets healed prior to doing any of those three things will not have that healing recorded on their Incoming Details tab.

Q: Can I get a detailed example of how Recap calculates the time that a combatant is in combat for DPS purposes?
A: Here is a concrete example for a warlock with a pet, with explanations of how Recap does its time calculations with Merge Pets On.
	Time 00:00 -- a battle begins as the tank pulls the mobs.
	Time 00:02 -- the warlock enters combat (their non-combat buttons dim), although neither the warlock nor the warlock's imp has done any offensive action yet.
	Time 00:07 -- the warlock banishes a mob.  Because no damage was done by the warlock, Recap does not start the timer.
	Time 00:08 -- the warlock tells the imp to attack.
	Time 00:09 -- the imp fireball damages a mob.  Recap starts the timer for the warlock + pet combination.
	Time 00:11 -- the warlock begins casting direct damage spells.
	Time 00:17 -- the imp dies, the warlock continues casting direct damage spells.  Recap continues the timer for the warlock + pet combination.
	Time 00:21 -- the warlock stops doing damage, and spends the next ten seconds banishing a mob.  The warlock has no DoTs active during this time.  Recap continues the timer.
	Time 00:31 -- the warlock summons a felguard and sends it into combat.
	Time 00:32 -- the warlock resumes doing spell damage, including DoTs.
	Time 00:41 -- the warlock dies and the felguard de-spawns.  Recap continues the timer.
	Time 00:49 -- the final tick of the warlock's last DoT.  Recap stops the timer for the warlock+pet combination.
	Time 01:50 -- battle ends, everyone leaves combat.
	Let's say that the total warlock + pet damage is exactly 20,000.
	In this example, Recap starts the timer when the imp does the first damage.
	Recap continues the timer even when the warlock stops doing damage to do some important banishing for a while in the middle of the battle.
	Recap also continues the timer after the death of the warlock because the warlock still has DoTs doing damage.
	Recap does nothing special in response to the death of the imp and the later summoning of a felguard.  They are both part of the warlock + pet combination.
	Total length of combat for the entire group is 110 seconds.
	Recap considers that the warlock + pet combination was doing damage for 40 seconds.
	So Recap will calculate 20,000 / 40 to give a value of 500 DPS for the warlock + pet combination.

Q: So Recap doesn't calculate the combatant + pet combination DPS by adding the combatant's individual DPS number plus the pet's individual DPS number?
A: No.

Q: In the example, isn't it unfair to the warlock to continue the timer during those ten seconds when the warlock was banishing a mob?
A: Yes, it might be a bit unfair.  When examining DPS numbers, always consider whether a combatant is doing something important for the raid (totems, shouts, polymorphs, traps, cleansing, etc.) that will lower their DPS.

Q: What if the combatant disconnected for 50 seconds in the middle, or went AFK for 50 seconds in the middle, instead of spending ten seconds banishing a mob?
A: Recap continues the timer.  Their total time in combat would be 80 seconds, so their DPS would drop to 250 DPS.

Q: What if the combatant died, was resurrected, and rejoined the battle.
A: Recap continues the timer.

Q: What if the combatant blew all their cooldowns or mana during the first 20 seconds of the fight, then did nothing for 40 seconds while waiting for their cooldowns or mana to come ready again, then resumed damage using cooldowns for another 20 seconds?
A: Recap continues the timer.  A combat meter that suspended the timer would be calculating an estimate of their peak DPS.  Recap is concerned with their average sustainable DPS, whether they stop doing damage in the middle for good reasons or for bad reasons.

Q: Why do other damage meters (e.g. Recount and Skada) tend to show higher DPS than Recap for long fights, but lower DPS than Recap for short fights.
A: For long fights they tend to show higher DPS because they subtract bits of time in the middle of the fight when people aren't doing DPS (for whatever reason).  This gives them a shorter combat time than Recap and thus higher DPS numbers.  For short fights, on the other hand, they add several seconds at the end of the fight after the last damage.  This gives them a longer combat time than Recap, and thus lower DPS numbers.

Q: What about the DPS+ column?
A: The regular DPS column uses the time from the first damage done by a combatant + pet, until the last damage by that combatant + pet.  In a similar way the time for the DPS+ column is from the first damage done by any combatant or pet in the group until the last damage done by any combatant or pet in the group.

Q: Any other Recap or combat log quirks?
A: A miss for any reason still triggers the damage timer.  If a melee combatant misses several times before connecting, then does damage for a while, then misses several times after doing their last damage, their time for DPS purposes will be from the first miss to the last miss.
	In the example above, if the first thing the imp fireball does is miss at time 00:09, Recap will start the timer anyway.  Similarly, if the last DoT at 00:49 misses, perhaps because it was aged, it still counts as a damage event for the DPS timer.
A: For a ranged combatant, if Recap knows that a spell or ability has done damage for them in the past, Recap starts the timer from the moment of successful cast, not from the time that the effect lands.  The timer will start even if the spell does no actual damage, perhaps because it was resisted.  The timer will not start if the spell cast is unsuccessful, perhaps because of out of range or insufficient mana.  This adds the flight time of the first spell to the time in combat for the purposes of calculating DPS, and so gives a slightly lower DPS value.  For determining whether a combatant has done damage with a particular spell, Recap only remembers which spells did damage as far back as the last Reset.
	In the example above, if the imp was known to do damage with fireballs and cast a fireball at 00:08 which landed at 00:09, the Recap timer for DPS purposes would start at 00:08.  The total time for the warlock + pet combination would then be 41 seconds instead of 40 seconds, and the DPS calculated would drop from 500 to 488.
A: For an instant kill combat, Recap will use a minimum combat time of 1.5 seconds for that combat.  This prevents unrealistically large DPS numbers.
A: The timestamps on combat log events are as received by each individual client.  They are not 'universal'.  Combat log events can appear at different clients in different orders and with different timestamps.  Thus, two copies of Recap running side by side will get different times for every event, and somewhat different time measurements, and hence somewhat different DPS numbers even with identical damage amounts.  For any of Recap's calculations that depend on the order in which events arrive (pet assignment, attribution of shields, and some others), two side by side copies of Recap may come to different answers.


__ FAQ: 6) DPS divided by Gear Value ratio __

Q: What is the new DPS/Gear ratio column?
A: This column takes the DPS number and divides it by a gear value (if available).  The initial version picks up values from the GearScore addon (if you have it installed).  Support for other gear value addons might be added later.

Q: Any quirks?
A: Use with caution.  With any particular WoW patch some classes and specs will almost always have a DPS advantage over others, and in some fights the differences will be further exaggerated.  Don't be unfair to classes and specs that have a low DPS/Gear ratio through no fault of their own.
A: GearScore or any other gear value addon is based on a particular theorycrafting, which can change; and is based only on information that the addon can gather in-game.
A: DPS scales faster than linearly with most gear value calculations.  That is, a 10% boost in gear value can give a 20% boost in DPS, so your higher-geared combatants may consistently come out ahead in the DPS/Gear ratio column even if player skill is identical.
A: The GearScore addon is at the moment in a war with spoofing addons that inject incorrect gear values.  Fortunately, the spoofer addons tend to exaggerate gear values so as to get into raids, which is exactly the wrong thing to do if they want to rock the DPS/Gear ratio column.
A: If you have All Fights data for an entire instance run, and if someone changes roles and gear, the gear value used for that combatant will be the highest one recorded, which might not match their DPS role.  For automatically saved data sets of boss fights, the gear value at the end of the fight is saved, so it will be appropriate when you load the saved data set later for inspection.
A: Use with doubled caution.  Interpreting DPS requires caution, and interpreting gear values requires caution, so interpreting the combination requires doubled caution.

Q: What about a healing per gear value ratio, or other ratios?
A: None planned at the moment.


__ FAQ: 7) Recent Event Recording __

Q: Does Recap remember recent events?
A: Yes, there is an options setting "Recent Data Mode" that remembers up to 80000 recent damaging or healing events.  Warning: Use of the Recent Data Mode takes additional memory, and can slow down Recap.  Note that Recap starts the recent event storage fresh every time you log in or reload your UI, so if you want to examine recent events then do so before logging out.

Q: What use are recent events?
A: This feature allows you, for example, to check in detail the last moments of a boss or of a main tank or of a dps who pulled aggro.

Q: How do I examine the recent Incoming or Outgoing damage or healing events for a combatant?
A: Click the "Recent" button to the right of a combatant on the "All Fights" or "Last Fight" panel.  A popup panel will appear, with one tab for recent Incoming events and one tab for recent Outgoing events.  You can also double-click the row to bring up the recent events.

Q: What do the colours in these lists mean?
A: Pale green is for outgoing damage, bright green for outgoing crits or crushes.  Pale red is for incoming damage, bright red for incoming crits or crushes.  Pale blue is for heals, bright blue for crit heals.

Q: How do I post recent events to chat?
A: From the new recent events tabs you can post to chat in the usual way, using a shift+click on a row or on the header.  If you have a chat edit box open the post goes to that channel, otherwise to your own console.  Be restrained about posting to shared channels.  Bulk posting is limited to the most recent events by the value of the "Report in Multiple Rows" slider.  You can post additional events by shift+clicking them individually.  If you are posting to your own console, the posted lines are colour-coded, but they will appear in white when posted to a chat channel.

Q: How do I examine the recent Outgoing damage or healing events for a particular spell or ability for a combatant?
A: Click the "Recent" button to the right of a spell or ability (aka 'effect') on the "Personal Details" panel for you or on the "Outgoing Details" or "Incoming Details" tabs for a combatant.  The recent events for that combatant will be shown, filtered to show just that spell or ability.  This feature allows you, for example, to see the time between uses of a spell or ability by a boss (examine the timestamps).  The timestamps show hours, minutes, seconds, and tenths of a second.  On spell or ability rows that have "Recent" buttons, you can also double-click the row to bring up the recent events for that spell or ability.

Q: Can I annoy people by posting huge lists of recent events that fill up people's chat panels?
A: Unfortunately yes.  There is no easy way for Recap to decide which chat channels to exclude.  Recap will refuse to post recent events to the channels Yell, General, Trade, LocalDefense, WorldDefense, GuildRecruitment, and LookingForGroup (and corresponding French, German, and Chinese channels).

Q: How are critical and crushing blows indicated in the postings?
A: Critical blows are indicated by a single asterisk ('*'), and crushing blows by a double asterisk ('**').  They are also indicated by brighter colours.

Q: Can we see when one combatant killed another, and when one combatant died?
A: With Recap 4.00 kills and deaths are shown in the recent Incoming and Outgoing events.  Kill and death messages appear in white.  Thes events are included in the order that Blizzard sends them, and sometimes the kill or death event precedes the event that does the fatal damage.

Q: What does a report of Incoming damage and healing look like?
A: Here is the last ten seconds of a boss fight, showing the damage that the group is doing to Kargath.
	__ Recap (Merge pets off): Recent Incoming Event __
	Recap: 08:32.2 Cyshaden (Melee) ==> Warchief Kargath Bladefist ( -130 )
	Recap: 08:32.5 Pauladin (Greater Blessing of Sanctuary (Holy)) ==> Warchief Kargath Bladefist ( -49 )
	Recap: 08:32.5 Pauladin (Holy Shield (Holy)) ==> Warchief Kargath Bladefist ( -172 )
	Recap: 08:32.5 Pauladin (Damage Shield (Holy)) ==> Warchief Kargath Bladefist ( -27 )
	Recap: 08:32.5 Pauladin (Damage Shield (Nature)) ==> Warchief Kargath Bladefist ( -26 )
	Recap: 08:32.7 Pauladin (Melee) ==> Warchief Kargath Bladefist ( -123 )
	Recap: 08:32.7 Pauladin (Melee) ==> Warchief Kargath Bladefist ( parry )
	Recap: 08:32.9 Cyshaden (Ferocious Bite) ==> Warchief Kargath Bladefist ( -730 )
	Recap: 08:33.2 Cyshaden (Melee) ==> Warchief Kargath Bladefist ( -280* )
	Recap: 08:34.2 Pauladin (Holy Vengeance (Holy)) ==> Warchief Kargath Bladefist ( -190 )
	Recap: 08:34.2 Cyshaden (Damage Shield (Holy)) ==> Warchief Kargath Bladefist ( -27 )
	Recap: 08:34.9 Hawksy (Damage Shield (Holy)) ==> Warchief Kargath Bladefist ( -28 )
	Recap: 08:35.5 Esthero (Frostbolt (Frost)) ==> Warchief Kargath Bladefist ( -1278 )
	Recap: 08:36.2 Percs (Damage Shield (Nature)) ==> Warchief Kargath Bladefist ( -26 )
	Recap: 08:36.5 Percs (Damage Shield (Nature)) ==> Warchief Kargath Bladefist ( -27 )
	Recap: 08:37.1 Pauladin (Holy Vengeance (Holy)) ==> Warchief Kargath Bladefist ( -190 )
	Recap: 08:37.4 Percs (Damage Shield (Nature)) ==> Warchief Kargath Bladefist ( -20 )
	Recap: 08:38.2 Hawksy (Damage Shield (Holy)) ==> Warchief Kargath Bladefist ( -27 )
	Recap: 08:38.2 Cyshaden (Damage Shield (Holy)) ==> Warchief Kargath Bladefist ( -28 )
	Recap: 08:38.2 Percs (Damage Shield (Nature)) ==> Warchief Kargath Bladefist ( -26 )
	Recap: 08:39.0 Hawksy (Damage Shield (Holy)) ==> Warchief Kargath Bladefist ( -28 )
	Recap: 08:41.6 Cyshaden (Melee) ==> Warchief Kargath Bladefist ( -100 )
	Recap: 08:41.7 Cyshaden (Mangle (Cat)) ==> Warchief Kargath Bladefist ( -499 )
	Recap: 08:42.7 Cyshaden (Melee) ==> Warchief Kargath Bladefist ( -115 )
	Recap: 08:42.9 Pauladin (Melee) ==> Warchief Kargath Bladefist ( -230* )
	Recap: 08:43.4 Cyshaden (Mangle (Cat)) ==> Warchief Kargath Bladefist ( -500 )
	Recap: 08:43.6 Esthero (Frostbolt (Frost)) ==> Warchief Kargath Bladefist ( -2547* )
	Recap: 08:43.6 Esthero (killed) ==> Warchief Kargath Bladefist
	Recap: 08:43.7 Warchief Kargath Bladefist ( died )
	Recap: 09:08.1 --------------------------------------------------

Q: What does a report of Outgoing damage and healing look like?
A: Here is the last ten seconds of the same boss fight, showing the damage that Kargath is doing to the group.
	__ Recap (Merge pets off): Recent Outgoing Event __
	Recap: 08:32.2 Warchief Kargath Bladefist (Sweeping Strikes) ==> Cyshaden ( -1084 )
	Recap: 08:32.9 Warchief Kargath Bladefist (Sweeping Strikes) ==> Cyshaden ( -656 )
	Recap: 08:33.6 Warchief Kargath Bladefist (Blade Dance) ==> Pauladin ( dodge )
	Recap: 08:33.7 Warchief Kargath Bladefist (Blade Dance) ==> Cyshaden ( -1018 )
	Recap: 08:34.2 Warchief Kargath Bladefist (Blade Dance) ==> Hawksy ( absorb )
	Recap: 08:34.5 Warchief Kargath Bladefist (Blade Dance) ==> Hawksy ( -532 )
	Recap: 08:35.8 Warchief Kargath Bladefist (Blade Dance) ==> Percs ( -966 )
	Recap: 08:36.2 Warchief Kargath Bladefist (Blade Dance) ==> Hawksy ( miss )
	Recap: 08:36.2 Warchief Kargath Bladefist (Blade Dance) ==> Percs ( -857 )
	Recap: 08:37.0 Warchief Kargath Bladefist (Blade Dance) ==> Percs ( -895 )
	Recap: 08:37.8 Warchief Kargath Bladefist (Blade Dance) ==> Hawksy ( -1114 )
	Recap: 08:37.8 Warchief Kargath Bladefist (Blade Dance) ==> Cyshaden ( -1340 )
	Recap: 08:37.8 Warchief Kargath Bladefist (Blade Dance) ==> Percs ( -949 )
	Recap: 08:38.5 Warchief Kargath Bladefist (Blade Dance) ==> Hawksy ( -1250 )
	Recap: 08:42.5 Warchief Kargath Bladefist (Melee) ==> Pauladin ( parry )
	Recap: 09:08.1 --------------------------------------------------

Q: How did you get those reports out of WoW and into this text file?
A: See the next section, "FAQ: 9) Saving Reports".  When posting recent events to the Clipboard the maximum number of lines posted is 400 (the most recent 400).

Q: How can I inspect other recent events around the time of a particular recent event?
A: If you double-click a recent event then the Recent panel will change to present a Time Window, showing up to 400 other recent events both before and after the time of the clicked event.  You can use this feature, if you wish, to 'page' forwards and backwards through the entire Recent history.  If you use the double-click feature while combat is going on you could end up with unexpected results if the Recent events buffer wraps around.

Q: Can I see recent dispels and breakage of crowd control?
A: Yes.  Dispels (which include deliberate and accidental breaking of crowd control) will appear among the Recent Events.  Dispel messages appear in white.

Q: Can I see just the recent dispels?
A: Yes.  If you hold the control key down when you click the Recent button for a combatant, then the recent events will be filtered to show just the recent dispels for that combatant.  You can get the same result if you hold the control key down while double-clicking the combatant's row.

Q: Can I see all recent dispels, not just those for one combatant at a time?
A: Yes.  If you hold the control key down while double-clicking the totals row on the main fight panel, the Recent Events popup panel will include all recent dispels.  There is now also a Dispels & Interrupts button at the bottom of the main fights panel that does this.  If you double-click the totals row without holding down the control key you will see ALL recent events.  There is now also an Events button that does this.  Caution: if you have a slow machine and have selected a high count for the number of recent events stored this could be slow.

Q: Can I see why my dispel didn't work during the Steelbreaker fight in Ulduar?
A: Maybe.  Version 4.29 has an experimental feature in which selected dispel casts and failures are recorded as recent events.  At the moment the set of dispels being tracked comprises Dispel Magic, Mass Dispel, and Cleanse.  Note: 2009-November: the Blizzard developers are investigating whether or not there is a bug preventing some dispels from working properly during the Steelbreaker fight.

Q: How many people died to the fire wall at Sartharion?
A: There is a Deaths button at the bottom of the main fight panel.  This button will place into the recent events panel an analysis of the death events for group players during the last few fights.  It requires that the Recent Data Mode be enabled.  The code looks for a 'window' of damage events both before and after each death event, limited by both count and time.  These damage events are summarized, and any healing events that fall within the damage window are also summarized.  The amounts from multiple damage events from the same source (ignoring GUID) are added together.  The report lines are sorted from oldest death to most recent death, and on each line the sources of damage for the combatant are reported in descending order of the amount of damage.  The number of events for each source is also shown, so "Auriaya (4256 / 2)" means that Auriaya hit the combatant twice for a total of 4256 damage.  The deaths analysis does not indicate which is the killing blow.  For that, check the recent events for the combatant.  If you double-click on a death on this report, Recap will present a Time Window, showing up to 400 recent events both before and after the time of the clicked death, so that you can examine events surrounding the death in detail.
A: There is an anomaly with Ruby Sanctum, in that death events inside are not reported outside, and vice versa.  Consequently death reports in Ruby Sanctum may be missing or incomplete.  Nothing can be done until Blizzard fixes their combat log events.

Q: Can I quickly scroll up to see the events at the beginning of this fight?
A: If you are saving enough recent events, then yes.  There are two new buttons at the top of the recent events panel.  The double up arrow will if possible scroll to the previous end of fight marker, and the double down arrow will if possible scroll to the next end of fight marker.  In both cases all recent events will be shown (no filtering).  This is a second way to 'page' forwards or backwards through the entire Recent history.

Note: The "Events", "Dispels & Interrupts", and "Deaths" buttons, if clicked while the corresponding popup panels are open, will close those panels.


__ FAQ: 8) Live Graphs and Text Listings __

Q: Can I see DPS and other information reported live during combat?
A: Recap already allows you to see your personal average DPS, percentage of DPS due to your pet, personal average HPS, group average DPS, group average DPS In, and group average HPS live on the minimized Recap bar.  Now there is an additional option.
A: With version 4.50 you can see live graphs and live text listings.  Recap can simultaneously graph any combination of group combatants for the current fight (for outgoing Damage per Second, incoming Damage per Second, and outgoing Healing per Second).  If you prefer, Recap can instead show a live text listing of similar information, with bar graphs (like the 'gauges' on the main fights panel) in the background on each line.  This feature is off by default.  To use this feature, enable "Live Data Mode" on the Options / Settings tab.

Q: How do I see the new Live Graph & Text panel?
A: if "Live Data Mode" is enabled, you can open the panel using the "Live Graph & Text" button at the bottom of the Recap main panel.

Q: How do I turn graphs on and off for group combatants?
A: On the Live Graph & Text panel there is a "more >" button.  Clicking the "more >" button will bring up a side panel listing options for the group combatants.  By default, your personal graph line is turned on and the graph lines for all other group combatants are turned off.  You can turn on the graph line for a combatant by clicking the checkbox next to their name.  You can also turn all combatants off or on using the "Check All" and "Uncheck All" buttons at the bottom of the side panel.  There are three independent sets of options for the three graph types (outgoing DPS, incoming DPS, and outgoing HPS).
A: One way of using this is as follows.  You might turn on all combatants for the DPS Out graph, and then turn off the tanks and healers.  You might turn on the tanks for the DPS In graph.  You might turn on the healers for the HPS Out graph.
A: in cross-realm situations, the names on the side panel will not include realm.  Occasionally this might lead to two combatants (from different realms) appearing to have the same name.
A: There is only room for 25 combatants on the side panel, and Recap will only graph the top 25 combatants.  If you are in a 40-person raid, the bottom 15 combatants will not be graphed, and you will not be able to turn them on and off individually (the "Check All" and "Uncheck All" buttons will still affect them).  The text listing can show all 40 raid combatants.
A: Note that settings for Live Graphs and Text Listings will always reset to the defaults when you log out or reload your UI.

Q: Okay, I turned on all the group combatants and now the graph is chock full of lines.  How can I pick out my graph line?
A: If you open the side panel and click on your name (i.e. not on the checkbox) then the names and graph lines of all other combatants will be dimmed, so that your name and graph line will stand out.  Click on your name a second time to turn off the highlighting of your graph line.  In a similar way you can highlight more than one combatant at a time.

Q: What happens if I'm looking at a graph and a new fight begins?
A: Recap will not overwrite any of the live graphs and text listings unless the new fight is "significant".  That means the fight must involve a group member dealing or taking damage, and must last at least 5 seconds.  This also means that if you haven't fought anything since the last reset, relog, or reload UI, no graph will appear until a fight becomes "significant".
A: To save resources, Recap only calculates display data for combatants that you have selected.  If a new fight involving group members begins, and if you then select a new combatant, Recap will not be able to calculate display data (for the previous fight) for that new combatant (unless you had paused live data collection before the new fight began, see later questions).

Q: If a new fight begins and is "significant", is there any way that I can still look at the previous live graph?
A: No.  The new significant fight will overwrite the previous graphs and text listings (unless you had paused live data collection before the new fight began, see next questions).

Q: What does the pause / resume button on the Live Graph & Text panel do?
A: This button pauses and resumes live data collection only, and does not affect any other Recap function.

Q: Why would I pause live data collection?
A: If you are examining live graphs or text listings, and do not want them to be affected if a new fight begins, you can pause live data collection.  You can then examine the live graphs and text listings at your leisure.  Ongoing combat will not affect them.  The best time to pause live data collection is after the end of a fight, and before the next fight begins.  When you resume live data collection, any combat that occurred while live data collection was paused will be missing, and the corresponding live graphs and text listings will have bits missing.  So this if for when examining the graph of the most recent fight is more important than collecting live data for the graph of the next fight.

Q: How do you calculate the live outgoing DPS?
A: The live outgoing DPS for any combatant is calculated using a 6-second moving average.  Six seconds is chosen as being just long enough to smooth out potentially misleading spikes in damage while still showing the variation in DPS during a fight.  Incoming DPS and outgoing HPS also use a 6-second moving average.

Q: The colour of my graph line changed.  What is going on?
A: Recap attempts to display combatant graph lines in a spectrum order (from red through to rose and white, then cycling back to red again).  To do this Recap sorts the group combatants in descending order of total damage done since the last reset.  This order should correlate fairly well with the DPS order, so that the top DPS graph line will generally be shown in red.  If there are no total damage done numbers available, the combatants are sorted alphabetically.  At the beginning of a raid, after a reset, the combatants will be in alphabetical order, with colours to match.  For the first few fights, as the order of total damage done varies, the order of combatants will change, and the graph colour for each combatant will change.  As the raid progesses, the total damage done order should become relatively stable, and the colours assigned will similarly settle down.  The order and the colour assignment will not change during a fight, only between fights.  The order of combatants for the DPS In graph is similarly based on total damage taken, so the main tank should be at the top of the list, displayed in red.  The order of combatants for the HPS Out graph is similarly based on total healing done, so the healers should be at the top of the list, with the top healer displayed in red.

Q: Can I choose a specific colour for my personal graph line?
A: No.

Q: Can I have the text listings sort by total, by peak, or by average?
A: Yes.  By default the text listings appear sorted by total.  If you click on a column header (Total, Peak, or Avg (average)) the text listings will be actively sorted by this column value during combat.  The combatant colours will not change during a fight, though their order in the text listing will change.  To turn active sorting off, click on the column header a second time, and the order will then be the same as on the side panel (i.e. in order of total damage done so far, or damage taken, or healing done).

Q: Can I see live graphs and text listings for combatants who aren't in the group?
A: No.

Q: What about pets?
A: If the "Merge Pets with Owners" option is on, pets are included as part of their owners.  If the option is off, pets do not show up on the live graphs and text listings.

Q: What about the "Opaque Background" checkbox on the options side panel?
A: When checked, this turns the background of the Live Graph & Text panel black.  When you first log on, or reload your UI, or open the Live Graph & Text panel after having closed it, this option will revert to the default semi-transparent appearance, for better visibility during combat.  You have to make a deliberate decision to turn the panel to opaque black.

Q: Does the Live Graph & Text panel disappear when I hit Escape?
A: No, though the side options panel will close.  Recap assumes that if you have "Live Data Mode" turned on you wish the panel to stay open during combat.  You can close the panel manually if you wish.

Q: What does the new "Live Data Mode" cost?
A: When enabled, live graphs and text listings can take a significant amount of CPU time, depending on how fast your computer is, and how many combatants you are graphing at once.  Live text listings are less expensive than live graphs.  The additional memory required is relatively small.
A: Be cautious about enabling this feature, and cautious about how many graphs you turn on, until you have a feeling for whether your computer can handle it during raids.

Q: I'm a math nerd, what does the new "Live Data Mode" cost in actual numbers?
A: With "Other", "Matrix", and "Recent" data modes turned on, with about 70 Mbytes of saved data sets, on my computer, in a 25 raid, Recap takes about 1.5% of the elapsed time.  With "Live" data mode also turned on, but with no lines being graphed, Recap takes about 1.6% of the elapsed time.  Every line being graphed adds about 0.085%, so when graphing DPS for all 25 group combatants Recap takes about 3.7% of the elapsed time.

Q: What does that mean in terms of performance?
A: In a 10 raid with everything turned on, on my computer, it doesn't affect my game play.  In a 25 raid with everything turned on, on my computer, I definitely notice the slowdown and have to turn off most of the graph lines.

Q: Is there any way that I can reduce the cost of live graphs?
A: Yes.  You could display one or two essential graph lines during the combat, or display text listings instead, then turn on the other graph lines of interest at the end of the fight.  You can also pause live data collection before the next fight begins (see earlier questions).

Note: The "Live Graph & Text" button, if clicked while the popup panel is open, will close the panel.


__ FAQ: 9) Saving Reports __

Q: Can I save all recent events to a file for later examination?
A: You can save your console chat (chat logging), including your posting of recent events and other Recap key+click reports, to WoWChatLog.txt (in the World of Warcraft/Logs folder) for examination after you log out.  Go to the Options / Reports panel and click the "Open" button.  When the button text changes to "Channel joined" logging will begin, and continue until you log out or click the "Close" button.  If the button text continues to read "Acquiring channel..." for a while, try clicking it a second time.  If the button text then changes to "Channel joined", proceed as before.  Otherwise press the "Close" button and try again.

Q: How can I copy Recap postings, including multi-line postings, for use outside WoW, without having to log out to get them?
A: You can send your posts of recent events and other Recap key+click reports to the Clipboard.  Hold down the control key while shift-clicking and the post will go to the Clipboard.  You can append multiple posts.  Then select the text in the Clipboard, copy it, and paste it outside WoW, perhaps into a text editor such as Notepad or TextEdit.
	__ Recap: Hawksy: Effect Totals __
	1. Smite: 20444 (35%)
	2. Holy Fire: 12883 (22%)
	3. Mind Blast: 10398 (18%)
	4. Shadow Word: Pain: 10368 (18%)
	5. Shadow Word: Death: 2578 (4%)
	6. Shoot: 972 (2%)

Q: Any limitations?
A: Key+click reports sent to the Clipboard ignore the setting of the "Report Format in HTML" option, and will post in non-HTML format.  The number of rows posted to the Clipboard is limited to 1000 rows.
A: When the Clipboard has a lot of characters in it, clipboard operations can be very slow.

Q: Can I get the "Report Fights" and "Report Details" standard reports to the Clipboard in a format suitable for pasting into a spreadsheet?
A: With version 4.29 there is an option to report in "Tab-Delimited Report Format".


__ FAQ: 10) Last Fight Examination and Saving __

Q: Can I save the information for a single boss fight?
A: Yes, on the Options / Data Sets panel you can save the Last Fight as well as All Fights.  This allows you to later load the data from a single fight for examination.  Details are saved for All Fights or Last Fight as appropriate.

Q: Can you just ignore short (trash) fights and not have them overwrite the Last Fight information?
A: Short fights (defined as no combatant doing or taking damage for more than five seconds, or fights in which only healing takes place) will be otherwise fully tracked in the background, but will not replace the Last Fight information.  This means that someone killing a toad, falling off a cliff, or healing, will no longer overwrite the Last Fight.  The information will still be tracked as part of the All Fights data, just not treated as a new "Last Fight".

Q: What if a major new fight happens before I get a chance to save the Last Fight?
A: You have until just before the end of the new fight to save the Last Fight on the Options / Data Sets tab, or use a Key Binding for "Save Last Fight".  If you haven't saved it by then, you are out of luck.

Q: Does Recap support the timelines (multiple last fights) that some other combat analysis addons have?
A: In part.  Recap has a new "Automatically Save Boss Fights" option on the Options / Data Sets tab.  The default is off.  If this option is enabled, then for any last fight in which Recap detected the presence of a hostile boss (skull, level -1), Recap will automatically save that last fight as a data set with the name of the boss or bosses.  Caution, with automatic saving of fights the number of saved data sets could become very large, taking a lot of memory and possibly slowing your game, unless you frequently visit the Options / Data Sets tab and delete unwanted data sets.  Recap will issue a warning if you have more than 40 Mbytes of saved data sets.
A: You can bind a key to "Save Last Fight" (see the WoW Key Bindings), and then at the end of any significant fight you can simply hit that key and Recap will save the fight.  You can save as many last fights as you wish.
A: You can later load one of those last fights (see the Options / Data Sets tab) to examine it.  The loaded data set is now displayed in a separate panel very similar to the main fights panel.  Some functions, such as menus, are not available on this separate panel.  For example, to change whether a column is displayed, make the change on the main fights panel and the auxiliary panel will echo the change.
A: There is a second load button for loading a saved data set into the All Fights table.  This is the old Recap behaviour, and is not the usual choice.  Doing so will overwrite your current All Fights data.  If you want to keep your current data then be sure to save it first.
A: There is also now a Delete All button for deleting all saved data sets.
A: Note that automatically saved boss fights are not synchronized (they are based on Last Fight data, which is not synchronized).

Q: Any anomalies?
A: Thorim fights that wipe during phase 1 will not be automatically saved unless you happen to have moused over Thorim, or targeted Thorim, during phase 1.  Unless you do that, Recap has no way of knowing that Thorim is nearby and is part of the fight.


__ FAQ: 11) Synchronization __

Q: Is synchronization required?
A: No.  Any Recap user may opt out of synchronization.  In fact, the default is to be opted out.  To participate in synchronization go to the new Options / Sync panel and turn on Enable Synchronization.  When this option is off, Recap ignores all synchronization.

Q: What information is synchronized?
A: The numbers on the All Fights panel (Times, Damage Done, Maximum Hit, Damage Taken, Healing, OverHealing, and Deaths) are synchronized among all participating Recap users in the group (which means Battleground, Raid, or Party as appropriate).  At the end of every fight the leader of the synchronization will automatically broadcast their data about every combatant.  Members will in turn broadcast any larger numbers they have.

Q: What about the numbers on the Last Fight panel, and the Outgoing, Incoming, and Other Details for combatants?
A: These are not synchronized.

Q: Is synchronization still useful since patch 2.4?
A: Synchronization is less important than it used to be.  With patch 2.4 Blizzard greatly increased the combat log range to include "everything that you can see" (whatever that means exactly, since it clearly includes many events that take place well out of your line of sight).  As a result, unless your group is widely spread out, almost every copy of Recap in the group will now see the same damaging and healing events and will get the same All Fights numbers.  As a result the need for synchronization is much lower.

Q: What about battlegrounds?
A: Many battlegrounds are much larger than the combat log range.  Most people in battlefields are interested in individual performance rather than group performance, and will not need to synchronize.   You would probably only synchronize in a battleground if tracking group performance really mattered to you.

Q: What about the Flame Leviathan trash?
A: The combat area for the trash prior to Flame Leviathan is very large.  Unsynchronized copies of Recap will probably differ, unless everyone sticks fairly close together.  The Flame Leviathan trash is somewhat like a battleground.

Q: What about the Thorim fight?
A: The far end of the tunnel is out of combat log range of the arena (and vice versa), so if you want an accurate Recap for the Thorim fight you need at least one person in the tunnel, and at least one person in the arena, to be in synchronization.  To save the synchronized fight for Thorim, see the answer to the question "Okay, so how can I save a synchronized fight for a boss?" later in this section.

Q: How do I join a synchronization?
A: Once you have enabled synchronization, you will get an invitation (as a popup panel) when someone starts a synchronization, or when the leader of an existing synchronization next broadcasts an update.  You can accept or decline that invitation.

Q: What happens when I join?
A: When you first join, your All Fights and Last Fight numbers will be Reset to zero.  Note that this Reset upon joining a synchronization ignores any 'locks' that you may have placed on combatants.  Your numbers will be updated at the next broadcast of an update (either at the end of the next fight, or when someone does a Manual Synchronization).

Q: How do I know if I'm in a synchronization?
A: There is a button next to the Recap status button that is blue when you are in a synchronization.  You can also see your synchronization details on the Options / Sync panel.  The blue button will blink while you are sending or receiving synchronization data.

Q: How do I start a synchronization?
A: Anyone running Recap can start a synchronization.  It is not restricted to the group leader.  If you start a synchronization, other players will see a popup panel inviting them to join your synchronization.  If they happen to be in combat, that popup invitation panel will be delayed until after they have left combat.  You will see messages on your console when players accept or decline your invitation.

Q: What happens if someone who is already in a synchronization declines my invitation?
A: They continue in their existing synchronization.  There can be multiple Recap synchronizations running within the group at the same time.  They are independent of each other.

Q: How do you manage that?
A: Each synchronization has a unique timestamp, along with a synchronization version number, the name of the leader of the synchronization, and the setting for the Merge Pets override.

Q: What's the deal about starting a synchronization with Merge Pets off, or with Merge Pets on?
A: Recap can't mix data from Merge Pets off and Merge Pets on.  The player starting the synchronization must choose which to use.  The synchronization choice is a temporary override, and when a player is no longer in a synchronization they will revert to using their own setting for Merge Pets.

Q: I just joined an existing synchronization, and all my numbers are zero.  How do I catch up?
A: Simply wait for the next end of fight, when you will catch up automatically.  If for some reason you don't want to wait, ask the leader of the synchronization to do a Manual Synchronization.

Q: Why does it take so long after the end of a fight to completely synchronize?
A: The software (AceComm) used to handle the communication over Blizzard's hidden channels deliberately slows down all communications so that people don't get disconnected.  Blizzard deliberately disconnects anyone who sends too much information over a channel in a short time.  As a result, it can take a long time (several minutes) to complete a large synchronization.  A Manual Synchronization will take even longer.  Synchronization for a single boss fight should be relatively quick.

Q: Does the fact that Recap does not synchronize Last Fight data mean that automatically saved boss fights are never synchronized?
A: Yes, because the automatically saved boss fights are based on the Last Fight, and synchronization is done for All Fights.

Q: Okay, so how can I save a synchronized fight for a boss?
A: Start a new synchronization just before the boss fight starts.  After the end of the boss fight, wait until you are out of combat, then wait for synchronization to complete (the blue light stops blinking, and the green light remains grey).  Recap will post a "Synchronization complete" message to your console when it thinks synchronization has completed.  Then Save All Fights by hand (see Options / Data Sets).

Q: What if there is an ongoing combat nearby that prevents synchronization from completing because we almost immediately enter combat again?
A: You can pause Recap until the synchronization is complete.  When the leader of the synchronization pauses Recap, other members of the synchronization will be asked if they want to pause Recap.  They would normally accept.  Similarly for when the leader of the synchronization resumes Recap.

Q: Does that mean that I can't have both a synchronized All Fights record for the entire evening, as well as synchronized versions for individual bosses?
A: Correct, unless some Recap users in the group keep the synchronized record for the entire evening, and a different set of Recap users in the group keep the individual synchronized boss records.  This can be done by having multiple synchronizations as described later in this section.

Q: I joined a synchronization with Merge Pets off, but now I want to join a different synchronization with Merge Pets on.  How do I do that?
A: This is a bit trickier.  Recap does not allow you to directly choose which synchronization to join if there is more than one.  Turn off Enable Synchronization.  This will leave the synchronization that you don't want.  Wait until some time after the end of a fight, until the normal exchange of synchronization messages has died down.  Turn Enable Synchronization on again, and ask the leader of the synchronization that you want to join to do a Manual Synchronization.  If you get a synchronization invitation from them, accept it.  If you happen to get an invitation to the wrong synchronization, decline it and repeat the process just described.

Q: Can the leader of the synchronization Reset my copy of Recap?
A: No, not after the initial Reset that happened when you first accepted the invitation to join the synchronization.

Q: What if the leader wants to Reset everyone?
A: The leader must start a new synchronization.  The leader can do that from the Options / Sync panel, or by clicking the Reset All Fights button, or by using a hotkey (if one has been bound).  Players who accept the invitation to join the new synchronization will have their All Fights numbers Reset to zero.  Players who decline the invitation will stay with the original synchronization.  The players who decline can still join the new synchronization later by turning Enable Synchronization off, then on again.  They will automatically get an invitation to join on the next end of fight, or when the leader does a Manual Synchronization.

Q: What happens to those players who choose to stay in the old synchronization, if the leader of their synchronization has gone away to a new synchronization?
A: Any of the players in the old synchronization can become the leader, by clicking the Become Leader button (which includes a synchronization).

Q: What if the leader of a synchronization disconnects, or goes AFK, or isn't in a fight for whatever reason, or quits the group?
A: Anyone can take over the role of leader by clicking the Become Leader button.  If nobody notices that the old leader has gone missing and claims leadership, there will be no synchronization updates.  On the Options / Sync panel you can see how long it has been since the last synchronization update, but there is no automated detection of this situation, no automated warning, and no automated promotion of a member to leader.  You might also notice that the blue light, which normally blinks at the end of a fight to indicate that synchronization data is being sent or received, does not blink as usual at the end of a fight.

Q: I have a combatant in my All Fights display that nobody else has, and it is important that everyone see the numbers for this combatant.  How can I get the other members of the synchronization to see that combatant?
A: Ask the leader of the synchronization to click their Manual Synchronization button.

Q: So what does Manual Synchronization do?
A: Clicking the Manual Synchronization button broadcasts a summary of the fight data by the leader of the synchronization, and also causes every member of the synchronization to broadcast their own summaries.  The result is to ensure that all members of the synchronization have the same list of combatants, and that everyone is up to date.  The leader should wait until everyone is out of combat, and until all the blue lights have stopped blinking, before clicking the Manual Synchronization.  Note that a Manual Synchronization does more than a normal synchronization, and may take much longer to complete.
A: Recap does not guarantee that all messages will be processed by all copies of Recap, so very occasionally members will not have exactly the same All Fights numbers.  The leader might choose to do one or more Manual Synchronizations to get everyone to exactly the same numbers.  This is usually overkill since it is seldom important to be exactly matched, and the person who has missed a few numbers will catch up at the next end of fight.

Q: Why doesn't Recap always do what a Manual Synchronization does?
A: Most of the time people are only interested in the All Fights numbers for members of the group, and the regular (and faster) synchronization handles that.  It is only when you need for some reason to have everyone in the synchronization see the same complete set of non-group combatants that a Manual Synchronization would become necessary.

Q: Can I abuse the group members who are using Recap with synchronization enabled, by pressing one of the Start Synchronization buttons repeatedly?
A: Yes.  How the other members of the group deal with your barrage of popup invitation panels is up to them.

Q: Can I abuse the synchronization I'm in by pressing the Become Leader button unnecessarily?
A: Yes.  How the other members of the synchronization, and the former leader of the synchronization, deal with this is up to them.

Q: Can I abuse the group members who are using Recap with synchronization enabled, when I am the leader of the synchronization, by pausing and resuming Recap repeatedly?
A: Yes.  How the other members of the group deal with your barrage of popup pause and resume panels is up to them.

Q: What might not work as expected?
A: This design of synchronization tries to keep everything simple and lightweight.  Accordingly there is no guarantee that everyone in a synchronization will receive and process every update message.  Also, if the gaps between fights are too short then not all Recap update activity will have a chance to complete before the next fight begins.  If you need to fix discrepancies so that everyone has the same numbers, do one or more Manual Synchronizations during a longer gap between fights.
A: If the synchronization leader gets out of range of a fight, or relogs, or disconnects, then synchronization members might track additional combatants that the synchronization leader will not see and which will not be included in the sychronization.  A member who has seen the missing combatants can get them added to the synchronization by asking the leader to do a Manual Synchronization.
A: The All Fights main panel is not updated live to reflect incoming synchronization data.  There is a new timer that will update the panel a while after the last synchronization data has been exchanged.  The live DPS and HPS numbers that are displayed when the main panel is minimized, and the live numbers that are sent to plugins, are not updated to reflect synchronization updates.
A: The Dispels and Interrupts columns on the All Fights main panel are not synchronized.

Q: Anything else I need to know?
A: When you are in synchronization nothing will happen (except a sound and a popup panel) if you press Reset All Fights, Reset Last Fight, or Load into All Fights; or Reset an individual combatant.  For the leader of a synchronization the Reset All Fights button will start a new synchronization.  If you need to use these blocked functions, turn off Enable Synchronization, do whatever you wish to do, then join the synchronization again as described above.  Oh, and one more thing -- during synchronization the popup menu choice to ignore a combatant does nothing, and if you had earlier ignored a combatant the only effect during synchronization will be to hide them on your display; their damage and healing will still be tracked and synchronized in the background.

Q: How can we keep track of All Fights for the entire instance, and also keep track of individual boss fights?
A: Select half of the raid to join a synchronization that will last for the entire instance.  The other half of the raid will begin a new synchronization before each individual boss fight, and at the end of that fight the synchronization leader will save All Fights (not Last Fight, so automatically saving boss fights will not do what you want here) on the Options / Data Sets panel.  The drawback is that people who are in the synchronization that will last for the entire instance will have to repeatedly decline the invitations to join the individual boss fight synchronizations.

Q: Why is that so complicated?
A: Because Recap only synchronizes All Fights data, and does not synchronize Last Fight data.

Q: How do I know who is in the synchronization?
A: There is a count displayed in the title bar of the main panel, and there is a List Members button on the Options / Sync panel.  The count (M+N) shows the number of members who have been heard from within the past ten seconds (M), possibly followed by the number who have not and who may have left the synchronization, the group, or the game (+N).  Similarly the list shows those who have been heard from within the past ten seconds, followed by those who have not.  There is a new "Remove Inactive Members" button to remove inactive players members from the list.  Every member of the synchronization broadcasts a message every five seconds to show that they are still active.

Q: Why isn't synchronization defaulted to be on?
A: My philosophy is to have significant new features of Recap defaulted off.  This includes synchronization.  I realise that this adds one additional step for Recap users who wish to use synchronization.

Q: Why isn't synchronization restricted to raid leaders and assistants?  Why can't a synchronization leader force a Reset for everyone in the synchronization?
A: My philosophy is that every individual needs to be able to retain direct personal control over their use of synchronization.

Q: Why does Recap not turn synchronization on and off automatically?
A: My notion of 'automatic' might not match other people's notions of automatic.  If you are not in a group then having synchronization turned on costs almost nothing.  If you are in a group and nobody else happens to be in your synchronization, then the cost of keeping your synchronization active is very low.  Having your synchronization active allows anyone who joins the group later to join your synchronization, and to catch up on "the story so far", without you having to do anything.

Q: Can I get detailed messages in the main title bar saying things like "Now receiving sync data from Hawksy"?
A: I'm still thinking about that.  I can see that it could be informative for some people, and annoying for other people.

Q: Does Recap synchronize the total fight duration so that the DPS+ column (aka "DPS vs All") will say the same thing for all members of the synchronization?
A: No longer.  Recap did for a while, but after determining that the event times supplied by Blizzard could differ significantly between clients, leading to bad values for fight durations and the DPS+ column, this feature was removed.

Q: Can Recap synchronize with SWStats, DamageMeters, or Recount?
A: No.  I have no plans at the moment to sync Recap with other combat analysis addons.  I can't see how the benefits would repay the increase in resource usage, and the increase in program size and complexity.  See also the earlier answer about the change to combat log range that came with patch 2.4.


__ FAQ: 12) Pet Details __

Q: Can I see long-term Personal Details for hunter and warlock pets?
A: Each of the player's pets has their own Personal Details, stored in the same way as the player's Personal Details.  These details will always appear on the player's Personal Details panel (regardless of the value of the merge pets option), with pet damage following player damage, and pet healing following player healing.  These details are not affected when you Reset All Fights.  They are reset when you Reset Personal Details, and can be reset individually (using the right-click popup menu for each effect line).  The pet Personal Details are done only for the player; no personal details are available for other players, nor for the pets of other players.  The pet Personal Details are also shown (and this can be a mild nuisance) for pets such as temporary priest Mind Control victims, or (for example) Gan'arg mobs temporarily controlled by any player in Netherstorm.

Q: How do I prevent those temporary pets showing up in my Personal Details?
A: At the moment you can't.  You can get rid of those details one by one by right-clicking on each of them and selecting Reset from the popup menu.

Q: What about the "ghoul with a thousand names" that is summoned by a death knight using the Raise Dead spell?
A: With version 4.25 Recap makes a best attempt to lump all these ghouls under one name 'Ghoul Minion' (when Merge Pets is on).  Recap is only able to do this for ghouls that are summoned within range of Recap.  It works well in instances, but less well outside.  If you mount then dismount, the ghoul that appears after you dismount is not the same ghoul that was there before you mounted, so Recap does not know that this is a summoned pet that should be included as a 'Ghoul Minion'.  If there are still too many ghouls for you not included under 'Ghoul Minion', consider whether the Merge All Pets into One Pet option might work for you (see next question).
A: Note that with patch 3.1 Blizzard broke their combat log event for summon, and as a result the Recap code to identify Ghoul Minions will only work some of the time.  As of patch 3.3.5 I have not checked to see whether this has yet been fixed.

Q: I want to lump all my pets together.
A: With version 4.25 Recap provides a Merge All Pets into One Pet option (default is off) to do this.  All pets will be merged under one name 'Pet' (when Merge Pets is on).  This includes all pets of any kind, including permanent pets, temporary pets, vehicles, totems, traps, and combatants that you control temporarily.  Be certain that you don't mind everything being lumped in together before you enable this option.


__ FAQ: 13) Other Details: Casts Debuffs/Losses Buffs/Gains __

Q: Does Recap track events that neither damage nor heal?
A: Yes, Recap can track casts, debuffs/losses, and buffs/gains.  There is an Other Details tab on the details popup panel.  Click the new "Sunder" icon that is between the "Book" icon and the "Sword" icon.  This is an option that is off by default.  See the "Other Data Mode" option on the Options / Settings tab to turn it on.  Like the Outgoing and Incoming Details, the Other Details are cleared when you Reset All Fights.

Q: What is included as an Other event?
A: Virtually all Blizzard events that could be combat-related and that do not directly involve damage or healing.  This includes casts, debuffs/losses, and buffs/gains.  With WoW patch 2.4 Recap reads the combat events directly.  There is a partial overlap between the new messages (Blizzard 'cast', 'debuff', 'buff', and so on) and the messages already tracked by Recap ('hit', 'heal', and 'miss') -- so you will see some effects showing up in more than one place.  With WoW patch 2.4 Recap tracks stolen buffs or debuffs.

Q: What is not included?
A: Not tracked are failure (e.g. "Not enough mana" or "Out of range"), tradeskill, enchant, create, experience, reputation, and honour.  Recap does not currently track the start of spell casts, nor the failure of spell casts.

Q: There are entries for non-combat events such as Mining, Herb Gathering, and Summon Felsteed.  Why?
A: These are formatted by Blizzard like other 'cast', 'debuff', or 'buff' events.  Recap isn't going to second-guess Blizzard.  Recap is not going to get into the business of maintaining extensive lists of excluded events, so you'll have to put up with these non-combat events appearing on the Other Details tab.  Recap does exclude a few selected summon events that cause an excessive number of non-combat combatants to be created (such as summon Fishing Bobber, and summon Basic Campfire).

Q: What about miss types?
A: Recap does not currently track the different kinds of miss (e.g. resist, immune, and so on) for effects on the Other Details tab.  They are all lumped into a single "Misses" number.

Q: There are a lot of items in that list of effects.  How can I make sense of them?
A: The first effects listed are outgoing spell casts (in green).  Second are debuffs; or losses such as mana drains (in red).  Third are buffs; or gains such as mana/rage/energy gains, extra attacks, and pet happiness (in blue).  Fourth are effects whose debuff / buff type is unknown (in white).  The losses and gains have an Attribute listed, such as Mana.  Within each group the effects are sorted by the number of Hits.  Clicking on the header label will toggle between a numeric sort and an alphabetical sort.

Q: Why are there some effects (shown in white) for which Recap can't tell the debuff / buff type?
A: The 'cast' event sometimes lists a target for the effect, but gives no indication as to whether it is a debuff or a buff.  Recap does not attempt to figure out if they are debuffs or buffs, but simply tracks them separately (in white).  In addition, Recap now includes effects which Dispel or Interrupt in this miscellaneous (white) category.

Q: Can Recap show how often a boss casts a particular debuff, and how long that debuff lasts?
A: Recap does its best.  Here's an example where it will work well.  A boss casts a particular debuff only on the main tank.  Recap tracks the interval between successive occurrences of the debuff on the main tank.  If there is a subsequent "fade" event for each debuff, Recap can track the duration of the debuff.  Sometimes the debuff is accompanied by a Blizzard combat message about the boss casting the debuff, and in that case Recap will also track the interval for the cast on the boss's Other Details tab.  However, only a small and seemingly random selection of debuffs are accompanied by a Blizzard casting combat message.  If there is no casting message, or if the boss scatters the debuff around, then the estimates of the interval between debuffs for individual combatants will be misleading.  If the debuff is always dispelled before it can fade, then Recap can not track its duration.  If a debuff lands during one fight, and the next debuff on that combatant lands during a subsequent fight, the estimated interval between debuffs will be too high.

Q: Why does Recap limit the tracking of debuff and buff intervals and durations to 130 seconds?
A: To avoid an excessive number of bad estimates, such as those caused by tracking across different fights.  Most debuffs and buffs for which interval and duration data are interesting will occur as transient effects during individual fights.  The 130 second limit is intended to maximise the usefulness of the data for this purpose.  Recap keeps only the count of the number of intervals or durations sampled, and the total of all intervals or durations, so the average interval or duration calculated is the arithmetic mean (nothing fancy like calculating the median or removing outliers).

Q: Can Recap show dispelling?
A: For a buff or debuff Recap tracks dispelling.  The details for the buff or debuff shows the number of times the buff or debuff was dispelled as "Dispels".  The dispel event is logged as a recent event if the Recent Event Mode is enabled (see the Recent Event Recording section above).  The number of times that a combatant dispelled an effect is now available as a new Dispels column on the main fights panel.  This number includes both desirable dispels and undesirable dispels (such as someone accidentally breaking crowd control); but it does not include spell steals.

Q: Can Recap show who broke my sheep?
A: Recap tracks this information.  Recap counts the number of times that an effect dispelled a buff or debuff (as white details on the Other Details tab of the combatant who used the effect), and counts the number of times that a buff or debuff is dispelled (as a detail for the buff or debuff on the Other Details tab of the combatant who had the buff or debuff).  Both deliberate and accidental dispels are counted.  In addition, the dispel event is also tracked as a recent event if the Recent Event Mode option is enabled.

Q: Can Recap show who interrupted my spell cast?
A: With version 4.00 Recap tracks some of this information.  The actual combat log event shows which effect interrupts which spell cast, but this is an extra level of linkage that Recap is not currently set up to track.  Instead Recap counts the number of times that an effect interrupts a spell cast (as white details on the Other Details tab of the combatant who used the effect); and the number of times that a spell cast was interrupted (as white details on the Other Details tab of the combatant who was interrupted).  Interrupts are now tracked as recent events, so you may be able to see who interrupted you by clicking the Dispels & Interrupts button and checking the recent dispel and interrupt events.  There is an Interrupts column on the main panel, which counts the number of times this combatant interrupted something.

Q: Can Recap show spell stealing?
A: With version 4.00 Recap tracks spell stealing similarly to the way that it tracks dispels.  The details for the buff or debuff shows the number of times the buff or debuff was stolen as "Steals".  Spell stealing is not tracked among the recent events.

Q: Are there any anomalies?
A: Zillions.  I could write a book.

Q: Give me some examples of anomalies.
A: If you happen to go out of Blizzard's combat message distribution range at any time, you will miss events, which could distort measurements.  With patch 2.4 Blizzard greatly increased the combat message distribution range, but it is still possible to miss events.  For example, the far end of the passage in the Thorim fight is out of range of the arena area.
A: In some cases an effect may show up as both a cast and as a debuff or buff, so in effect it is being tracked more than once.  Recap does not attempt to reconcile these.
A: Sometimes an effect that does damage (on the Incoming or Outgoing tab) will also appear as a debuff with the same name on the Other Details tab.  Recap does not attempt to reconcile these.
A: Not all messages are delivered by Blizzard to all combatants.  For example, at one time (haven't checked recently) a priest does not see messages for their own casts of "Shackle Undead", but does see messages about other priests casting the spell!  Also, at longer shackle ranges the priest no longer receives the usual target shackle debuff messages!  Also, when the shackle is broken the message from Blizzard is that the debuff fades (as if it had expired), so for shackle the duration measurement is actual duration (for other debuffs and buffs the fade message appears only when the effect runs out normally or on one of the resistance checks).  There are undoubtedly many other examples of inconsistent Blizzard messages.

Q: Can I see estimated intervals and durations for effects that do cause damage or healing and that don't happen to appear on the Other Details tab?
A: On the Outgoing and Incoming Details tabs Recap tracks intervals for damaging and healing effects.  Durations are not tracked since there are no associated 'fade' (e.g. SPELL_AURA_REMOVED) events.

Q: Can I see recent cast, debuff/loss, and buff/gain events listed with Recent Events?
A: Not at the moment.

Q: Any other notes?
A: For SPELL_DRAIN and SPELL_PERIODIC_DRAIN events there is an 'extraAmount' that I don't understand and that has been zero in testing so far (i.e. at least as far as patch 3.1).
A: Recap is currently ignoring SPELL_CAST_START, SPELL_CAST_FAILED, SPELL_DISPEL_FAILED, SPELL_AURA_REMOVED_DOSE, UNIT_DESTROYED, UNIT_DISSIPATES, ENCHANT_APPLIED, ENCHANT_REMOVED, SPELL_BUILDING_DAMAGE and SPELL_BUILDING_HEAL events.


__ FAQ: 14) Crushing and Glancing Blows __

Q: Does Recap track crushing blows?
A: Yes, Recap tracks crushing blows (very similar to critical blows) for Incoming and Outgoing Details; and in Recent Event data postings.  Ticks that crush (if any) are not tracked separately.

Q: Does Recap track glancing blows?
A: Yes, Recap tracks glancing blows (in a similar manner to critical and crushing blows) for Incoming and Outgoing Details; and on the Personal Details panel.


__ FAQ: 15) Partial Effects __

Q: What about events that are partially blocked, absorbed, or resisted?
A: The primary event is already tracked by Recap in the usual way.  The information that the event was partially blocked, absorbed, or resisted is tracked separately.

Q: Does Recap track partial blocks?
A: Yes, Recap tracks partial blocks, separately from complete blocks.  To get the total number of blocks, add the number of complete blocks plus the number of partial blocks.  The total and average amount of damage blocked by a partial block is also shown.  This information can be found on the Outgoing and Incoming Details tabs.

Q: Does Recap track partial absorbs and resists?
A: Yes, the number of partial absorbs and the number of partial resists can be found on the Outgoing and Incoming Details tabs.  The total and average amount of damage partially absorbed or partially resisted is also shown.  These numbers do not include complete absorbs and complete resists.  For the partial resists Recap also shows an average percentage resisted.  Blizzard quantizes partial resists every 10%, from 10% to 90%, but Recap does not track those nine brackets individually.

Q: What about a hit that is, say, partially resisted and also partially absorbed?
A: Recap will count partial effects under all of the partial headings that apply.  So in this case, the single event will be counted as both a partial resist and also as a partial absorb.  Similarly for other combinations of partial effects.


__ FAQ: 16) Resistance __

Q: Can Recap tell me how effective my Fire Resist gear is?
A: Recap gives you an estimate on the Outgoing and Incoming Details tabs of the total amount of damage resisted, with a percentage as a proportion of the estimated total damage that could have been resisted.  Use this with the totals described in the next section for each school of damage.

Q: Why is it an estimate?
A: Recap does not know how much damage each completely resisted effect would have caused [while Blizzard seems to imply that with patch 3 this information is available in the combat log events, when last I checked it wasn't yet complete enough or consistent enough to rely on].  Recap calculates the average gross damage per effect landed, and uses that an estimate of the damage that each completely resisted effect would have caused.  Recap then estimates the total resistable damage attempted, and calculates an estimate of the percentage of resistable damage actually resisted.  The estimate assumes that individual ticks of a DoT are never completely resisted.

Q: How do you work out the Estimated Total Resisted for element subtotals and damage totals?
A: Estimating resistance directly from the amounts shown for the subtotals and totals would not give a correct answer.  Instead, for each individual effect Recap calculates the estimated damage resisted, and the estimated total resistable damage, and stores these two values.  The second value is a hidden column.  The resistance percentage is calculated when displaying.  The two values are accumulated for the subtotals and totals, and subtotal and total percentages are calculated from those accumulated values when displaying.


__ FAQ: 17) Subtotals, Totals, and Grand Totals __

Q: Can I see the total elapsed time that the group spent fighting, rather than the sum of individual times?
A: Yes, this is available as "Group Fight Time" on the tooltip that pops up when you mouse over the Total line of the All Fights panel or the Last Fight panel.  This number is calculated by each copy of Recap independently, is not sent during synchronization, and so may differ among group members.

Q: Can I see the total DPS from the group rather than the average DPS?
A: Yes, this is available as "Group DPS" on the tooltip that pops up when you mouse over the Total line of the All Fights panel or the Last Fight panel.  Note that this total can be misleading.  If you complete an instance without replacing anyone (even a pet) then it will be accurate, but if a warlock uses more than one minion (with Merge Pets off), and if you replace people during the run, this number will count the extra minions and the replacement people.  For example, if everyone in the group is replaced once, then this number would be about twice as large as it should be.  Use this total DPS number very cautiously.

Q: Can I see the total of all the various Fire damage effects done to a combatant, or done by a combatant?
A: Yes, Recap includes subtotals, by element (Fire is one of the elements), at the end of the Outgoing and Incoming Details tabs for a combatant.  Also included are an entry that totals over all types of damage, and an entry that totals over all healing.

Q: There is an entry labelled "Subtotal: Other" with just a few misses listed.  What is that?
A: For misses, the Blizzard combat messages do not include an element.  If the miss happens before the combatant has caused damage with the effect, the element for the miss is unknown, which Recap will track as "Other" when accumulating subtotals and totals.

Q: Can I see the grand total of all Melee damage done to all combatants in the group (the green combatants), or done by all combatants in the group?
A: Yes, Recap creates a grand total over all combatants in the group of all information on the Outgoing, Incoming, and Other Details tabs.  To show the panel with these details, left-click on the green Total button on the total row.

Q: Can I see the grand total of all Fire damage done to all combatants in the group, or done by all combatants in the group?
A: Yes, Recap the combination of the subtotals by element, and the grand total just mentioned, makes available a grand total of all Fire damage over all combatants in the group.  For example, to see the grand total of Fire damage done by the combatants in the group, bring up the grand total popup panel as described in the previous answer, select the Outgoing Details tab of the popup panel, and scroll down to the "Subtotal: Fire" row.

Q: Can I see the same thing for all combatants not in the group (the white combatants)?
A: Yes, Recap creates similar grand totals over all combatants not in the group.  To show the panel with these details, left-click on the white Total button on the total row.

Q: Why don't the totals on the Outgoing and Incoming Details tabs match the numbers on the All Fights panel when I'm in a synchronization?
A: The detailed data are not synchronized, and are based only on the events seen by your own character.


__ FAQ: 18) Target of Outgoing damage and healing, Source of Incoming damage and healing __

Q: Can Recap track which combatants damaged which targets, and which combatants healed which targets?
A: Yes, Recap has an option to track who damaged which target, and who healed which target, with the amount.  The default is off.  The option (see Options / Settings) is called "Matrix Data Mode".  The information can be found on two new tabs on the popup panel, called "Target of Outgoing Details" and "Source of Incoming Details".

Q: What healing amounts are shown?
A: These tabs show the actual healing (healing attempted minus overhealing).  These match the healing numbers shown on the "All Fights" and "Last Fight" panels.


__ FAQ: 19) Healing from priest Prayer of Mending and similar healing spells __

Q: Can Recap correctly assign the healing from a Prayer of Healing to the priest who cast the spell originally?
A: Code to do this, introduced with version 4.09, is no longer needed with version 4.20.  The special code for druid Lifebloom, shaman Earth Shield, and paladin Judgement of Light are also no longer needed.
A: With patch 4.0.1 the special code for Improved Leader of the Pack is no longer needed either.


__ FAQ: 20) Power Word: Shield and similar absorption shields cast by healers __

Q: Can Recap credit the absorption shields cast by priests, especially discipline priests, to the priest responsible?
A: With version 4.24 Recap makes its best effort to assign the actual amounts absorbed by five shield types to the healer as healing done by that healer, and as healing done to the combatant being shielded.
A: With patch 4.0.1 Blizzard provides much of this information almost directly, and so Recap's special case code has been replaced with code to use Blizzard's information.

Q: Where does the absorption appear?
A: On the main fights panel the actual absorption is included in the healing column as if it were healing.  There is no separate column showing absorption.  The amount healed is the actual amount absorbed.  Recap will also add healing events describing the absorption healing to the list of recent events.

Q: What about lost absorption capacity for shields?
A: If the shield aura fades without using its full absorption capacity, the additional absorption capacity is ignored.  Recap does not currently record this lost absorption capacity, so absorption healing will always appear to have zero overhealing.

Q: What about anomalies?
A: Blizzard gives useful information only for some shields.  Recap will process only the absorption for which Blizzard provides useful information.  Non-healer self-shields such as druid Savage Defense, mage Mana Shield, and mage Ice Barrier are not currently supported in this way by Blizzard's combat log events, and are therefore not assigned as healing.
A: There can often be missing damage absorption events, or missing shield reduction events, so there will seldom be full agreement between total amount absorbed and total absorption healing.
A: Sometimes more absorption happens than a shield is theoretically capable of absorbing.  There is currently a bug in the Blizzard combat system that in some circumstances subtracts an amount from a shield without absorbing any of the damage done to the target.
A: Because there can be considerable delays between damage absorption events and the corresponding shield reduction events, and they can arrive in either order, Recap has to use a very generous tolerance for delays, which could lead to mis-attributions.


__ FAQ: 21) Detail Entries for All Group Members __

Q: How do I check who got hit how many times by Malleable Goo in the Professor Putricide fight?
A: Using the small popup panel, either find one person who was hit by the Malleable Goo, or create a Group Total popup panel.  Go to the Incoming Details tab (click the right-most icon) and find the row in the list for Malleable Goo and select it.  In the bottom half of the small popup panel locate the Hits detail entry, and double-click on that entry.  A panel will appear with the number of times each group member was hit by Malleable Goo, in descending order.

	__ Recap (Merge Pets on): Detail Entries for Incoming Malleable Goo for Last Fight __
	1 / 18. G: Incoming Number of Hits for Malleable Goo: 5
	2 / 18. J: Incoming Number of Hits for Malleable Goo: 4
	3 / 18. K: Incoming Number of Hits for Malleable Goo: 4
	4 / 18. S: Incoming Number of Hits for Malleable Goo: 4
	5 / 18. E: Incoming Number of Hits for Malleable Goo: 4
	6 / 18. I: Incoming Number of Hits for Malleable Goo: 3
	7 / 18. H: Incoming Number of Hits for Malleable Goo: 3
	8 / 18. S: Incoming Number of Hits for Malleable Goo: 2

Q: Can I do that for other detail entries?
A: Yes, almost any detail entry in the lower half of the small popup panel, for Outgoing Details, Incoming Details, or Other Effects Details, can be double-clicked.

Q: What about pets?
A: For this report, pet detail entries are always reported on a separate line, regardless of whether Merge Pets with Owners is checked or not.  If you do Melee damage, and if you also have two pets who do Melee damage, any reports for Melee will have these appear on three separate lines.

Q: What about enemies?
A: If you double-click on a detail entry for a combatant not in the group, or for the Non-Group Total, the report will be for combatants who are not in the group.


__ FAQ: 22) Skip Next Fight __

Q: How do I ignore fights such as the chess event in Karazhan, or the bombing run on Quel'Danas?
A: With version 4.20 Recap allows you to skip the next fight.  There is a button on the Options / Sync tab, or you can bind a key to the function on the Blizzard Key Bindings panel.  The function is available to the leader of a synchronization, and also to anyone who is not in a synchronization.  Click the button either before the fight begins, or as early in the fight as you can.  The next fight (or current fight if one is in progress) will be skipped.  Recap will automatically resume tracking after having skipped the fight.

Q: How do I know if Recap is skipping a fight?
A: The status light will be amber during combat if you are ignoring the fight.  Recap needs to monitor the fight in order to detect when it ends.  Nothing else is being tracked.

Q: How does this differ from pausing?
A: Pausing does not automatically resume after pausing; and pausing cannot be done while in synchronization.

Q: I forgot to hit Skip Next Fight.  Can I get rid of the fight afterwards?
A: No.  If you are not in a synchronization, you can Reset Last Fight, but this only subtracts the last fight from the All Fights summary panel.  All of the detail information from the fight will remain.

Q: Oops, I hit the Skip Next Fight button by mistake.
A: Pause then resume Recap.


__ FAQ: 23) Ignoring Effects __

Q: How do I set Recap to ignore effects such the Drawn Soul healing effect during the Illidan fight?
A: With version 4.22 Recap allows you to enter the spell IDs of effects for which you want to ignore the damage and healing.  Go to the new Options / Ignores tab and enter the numerical spell ID (for Drawn Soul this is 40903).  When you ignore the Drawn Soul effect, for example, your tank will no longer be credited with healing Illidan, and on the other hand Recap won't show how much healing Illidan received as a result of the Drawn Soul effect.  The effect will continue to show up among recent events when the Recent Event Mode is enabled, and will will continue to show up on the Other Details tab when the Other Data Mode is enabled.  Note that the list of effects to ignore is shared among all your characters on the server.

Q: Where do I find the spell ID for the effect that I want to ignore?
A: You can find the numerical spell ID on the Outgoing, Incoming, or Other Details tabs.  Or you can seek it on the Internet (e.g. thottbot or wowhead).

Q: What about the Deathbringer Saurfang fight in Icecrown Citadel?
A: You might wish to ignore the Mark of the Fallen Champion healing effects, which credit raid members for healing the boss.  The spell IDs to enter are 72260, 72278, 72279, and 72280.

Q: What about the Professor Putricide fight in Icecrown Citadel?
A: You might wish to ignore the Mutated Plague healing effects, which credit raid members for healing the boss.  The spell IDs to enter are 72745 and 72746.

Q: What is the Add Suggested Ignores button on the Options / Ignores tab?
A: You can add the effects that Recap suggests that you ignore.  These include all those just mentioned.  If there are some effects that you don't want to ignore, remove them again.  At the moment these are effects which causes a player to heal a boss, thus distorting numbers in the Heal column.  If you don't use the Heal column, then don't bother.

Q: How do I get rid of effects that Recap has already recorded?
A: At the moment you can't.  The feature only affects future tracking.

Q: How does this feature work with synchronization?
A: Not very well.  Unless everyone has the same list of effects to ignore, damage and healing totals on the All Fights panel will be somewhat unpredictable.


__ FAQ: 24) Special Cases __

Q: How can I tell who got hit by Blood Beasts during the Deathbringer Saurfang fight in Icecrown Citadel?
A: With version 4.53 Recap has some special case code which replaces the generic "Melee" with "Blood Beast Melee" for these NPCs.  This will allow you to quickly check who got hit by that effect.

Q: How can I tell who got hit by Vengeful Shades during the Lady Deathwhisper fight in Icecrown Citadel?
A: Recap has similar code which replaces the generic "Melee" with "Vengeful Shade Melee" for these NPCs.  This will allow you to quickly check who got hit by that effect.

Q: What about Ysera's Gift, a passive healing ability?
A: Healing done by this spell will not be used start a fight or extend a fight, but otherwise will be recorded in the normal way.  This is hard-coded into Recap.

Q: How can I add another special case?
A: At the moment there is no way for users to do so.  Get me the information and I can add it to the next version of Recap.


__ FAQ: 25) Miscellaneous __

Q: I have Recap pinned at the top of my Warcraft window, but when I switch from full screen mode to windowed mode and back again, Recap moves away from the top of the window.  How can I keep Recap at the top of the window?
A: Go to the Blizzard Video options panel, find the "Use UI Scale" option, and turn it on.  In addition, for some reason which I do not understand this anomaly is more likely to happen on a Public Test Realm.

Q: Why doesn't Recap credit me, a shadow priest, with the damage done by my Shadowy Apparitions?
A: The Shadowy Apparitions (new with patch 4.0.1) are not credited to the priest by the Blizzard combat log events.  They cast *themselves* at an opponent, with no indication that they came from the priest.  Special case code would be unlikely to work usefully since in a small sample there could be more than a 2 second delay between the Shadow Word: Pain hit and the 'casting' of the corresponding Shadowy Apparition.
A: It might be possible to track Shadow Word: Pain on opponents, and since we know the opponent that the Shadowy Apparition attacks, work out which priests could own the Shadowy Apparition.  If there is just one priest, this would be unambiguous, but if there is more than one Shadow Word: Pain on the target from different priests then we could not assign the damage reliably.
A: Also, it is possible to track Shadowy Apparitions for the person running Recap (the "player"), but ambiguous for all others, so in keeping with Recap's philosophy of fairness I don't do that.

Q: Why doesn't Recap credit damage and healing to me for my shaman totems?  For my snake traps?
A: With patch 2.4 most shaman totems are now properly credited to the shaman, though the Greater Fire Elemental is not (this may be fixed with patch 2.4.3).  Some hunter traps are now properly credited to the hunter, although snake traps are not.
A: Some of Blizzard's combat messages give no indication as to who owns the item, and so Recap cannot credit the damage or healing to anyone.  Similarly the effects of buffs such as Thorns are attributed by the Blizzard combat messages to the person carrying those buffs rather than to the original caster.  There are many other anomalies -- for example Blizzard combat messages do not mention any damage to the warlock when a warlock casts "Life Tap".  The combat log event changes with patch 2.4 do not fix these anomalies.

Q: Does Recap show breakdowns of both Incoming and Outgoing misses?
A: Yes, on the Incoming Details and Outgoing Details tabs of the popup panel.  There are ten types of miss (absorb, block, deflect, dodge, evade, immune, miss, parry, resist, and reflect).  All ten types may occur for non-Melee effects (which include both spells and physical attacks other than Melee).  Nine of the ten (not reflect) may happen for Melee.  On both tabs misses are broken down for each effect.  There is not currently a breakdown of the different types of miss for Other Details.

Q: Does Recap track minimum values for hits?
A: Yes, Recap tracks minimum values for glances, hits, crits, crushes, and ticks on the Outgoing and Ingoing Details tabs.  Minimum hits, crits, and ticks are tracked on the Personal Details panel.  A damage minimum is the actual amount that affected the target (referred to as the net minimum), a healing minimum is the amount that was cast (uncorrected for overhealing).

Q: Does Recap track critical ticks?
A: In part.  The minimum, average, and maximum tick numbers shown lump both ordinary ticks and critical ticks together.  Recap does keep track of the percentage of ticks that are critical ticks.  This critical percentage can be found on the Outgoing Details and Incoming Details tabs of the small popup panel.  At the moment the critical ticks are not tracked on the Personal Details panel.

Q: Does Recap track environmental damage?
A: Yes, environmental damage (such as fire, falling, lava, and slime) is tracked.  The effect is called "Environment <type>".

Q: Does Recap credit healers for the healing that they do to remove the Incinerate Flesh debuff during the Jaraxxus fight?
A: Yes, absorbed healing (which as far as I know only happens in the Jaraxxus fight) is credited as if it were normal healing.

Q: Why are the number of deaths recorded for my priest sometimes too high.
A: Blizzard sometimes gives a "You die" message when your priest first dies, and a second "You die" message (the combat log events are identical) when your priest's Spirit of Redemption wears off.  But there are not always two messages, so you can't always divide the number of priest deaths by two to get the right number.  With version 4.36 Recap attempts to resolve the double death issue, so the count of priest deaths should now be much more accurate.  In general for any combatant the count of deaths is inaccurate since Blizzard's death messages are unreliable.

Q: Does Recap track self-inflicted damage?
A: Yes, Recap tracks effects like "You suffer 87 Fire damage from your Hellfire".

Q: Why are there fewer healing ticks than damage ticks for some dual damage/heal effect?
A: When a hit or tick from a dual damage/heal effect kills the target, Blizzard chooses to award no healing rather than to calculate an appropriate partial healing.

Q: Can Recap exclude from outgoing damage and DPS calculations effects such as Shatter (from the Gruul fight) in which a combatant in the group damages other combatants in the group?
A: As of version 4.07 the outgoing component of such damage is ignored.  This avoids inflating the outgoing damage and DPS of a combatant with damage that doesn't contribute to the positive outcome of the encounter.  The incoming component and the matrix component will still be tracked.  Note that the outgoing component of self-damage, and of damage between pet and owner, were already being ignored.

Q: If I'm lying dead and the group begins a new fight, why does my minimized DPS not get set to zero, since I'm not doing any damage?
A: In order to reduce the number of times that your minimized DPS gets set to zero by any new combat happening nearby (which can be an annoyance), Recap with version 4.55 will only reset your personal minimized numbers if you have personally dealt damage, taken damage, or done healing.  So the group minimized numbers will update to reflect the new fight, but your personal minimized numbers will continue to show the numbers from your previous fight.

Q: When I have the "End Fight If Idle" option turned off, sometimes Recap's green light comes on and does not go off.  Why?
A: A fight in which you don't personally enter combat mode will start, but Recap has no way of ending the fight if this option is turned off.  Well, there is a second secret timer that will end the fight if your Recap has been idle for ten minutes....

Q: Can I bind hotkeys for resetting Fights and Personal Details?
A: Yes, check the "Key Bindings" on the Blizzard Main Menu.

Q: Can I keep information for some combatants, and Reset all the rest?
A: Yes.  If you right-click a combatant's name on the All Fights panel, the popup menu will include a "Lock" choice.  If a combatant is locked then they will not be affected by an ordinary Reset All Fights.  Note that joining a synchronization will do a reset that ignores any character locks.  Alternatively, the right-click popup menu allows you to Reset an individual combatant.

Q: Can I show information for just my group?
A: Yes, there is an option (default off) called "Hide Other Combatants" that if turned on will hide combatants other than those in your group (with their pets).  Recap will hide allies who are not in your group, neutrals, and enemies.  Note: Recap continues to track everything in the background.  The group can be a party of five or a raid of forty (with their pets and temporarily controlled combatants).  The group includes former group members.  A group can also include (or exclude) selected combatants -- right-click on a combatant to add them to your Recap group (turn them green), or drop them from your Recap group (turn them white).

Q: Can I show information for just me and my pets?
A: Yes, there is the "Hide Other Combatants" option just mentioned, and an option (default off) called "Hide Group".  If both options are turned on Recap will hide all combatants except you and your pets.  Note: Recap continues to track everything in the background.

Q: Why does Recap continue to track all that information in the background when I don't want to see it?
A: That's how the original design of Recap did things.  It allows you to temporarily limit the display without any risk of missing data.

Q: What if I *really* don't want Recap to track that information in the background?
A: There is an option (default off) called "Store Only Displayed Combatants".  If you limit display by turning on "Hide Group" or "Hide Other Combatants" then the "Store Only Displayed Combatants" option will turn off the tracking of information for the hidden combatants.  Use with caution (see previous answer).  Note that enabling this option does not delete any existing hidden combatants, so if you want them to go away do a Reset as well.

Q: What is the Minimize on Escape option?
A: I wanted a consistent method of dismissing windows.  I use the Escape key (esc) for this purpose.  I wanted the Recap main panel to minimize when I hit the Escape key.  Having this option turned on will also minimize the Recap main panel in a number of other situations.  With this option on, hitting Escape will also hide other Recap panels.

Q: What is the Remind on Join or Leave Group option?
A: If this option is turned on, Recap pops up a little reminder panel whenever you first join a group, and when you leave a group.  The original suggestion was for an option to automatically Reset whenever you join a group, but I thought that was inflexible, and could lead to an undesirable explosion of different "do X on joining a group" options.  So Recap simply puts up a reminder.  The action that you then take is up to you.

Q: What is the Remind on Enter or Leave Instance option?
A: If this option is turned on, Recap pops up a little reminder panel whenever you first enter an instance or leave an instance.

Q: What is the Pause Outside Instances option?
A: If this option is turned on, Recap attempts to detect when you leave an instance, and pauses combat tracking outside instances.  Recap attempts to detect when you enter an instance, and resumes combat tracking inside instances.

Q: What is the Limit Fights to Encounters option?
A: Blizzard introduced ENCOUNTER_START and ENCOUNTER_END events starting with 5.4.2.  This option records a fight only between those two events.  This option is experimental, as there are reports of inconsistent behaviour of these events.

Q: Are the "/recap" and "/recap centre" (or "/recap center") slash commands localized for non-English clients?
A: No, none of the slash commands are localized for non-English clients, and neither are the console messages issued by slash commands.

Q: Are there any other slash commands that I can use?
A: The command "/recap options" shows or hides the Options panel.  The command "/recap reset" does a Reset All Fights (for the leader of a synchronization it instead starts a new synchronization).  There are additional slash commands that few people are likely to need to use, and that change from time to time.  If you are desperately curious, check out the function Recap_SlashHandler in the Recap.lua code file.

Q: What's the most obscure feature of Recap?
A: Perhaps the five extra columns available on the "Outgoing Details" and "Incoming Details" tabs, because you can only see one column at a time.  Right-click on the column header to get a menu to display one of the other columns.
A: Starting with 4.71, the drop-down menu allows you to show Total Damage only (not display any healing effects) or Total Healing only (not display any damage effects).
A: Starting with 4.77, the drop-down menu also allows you to select 'per second' values (e.g. DPS Out, DPS In, HPS Out)


__ FAQ: 26) Memory and CPU time notes

__ Memory Use __

Versions 3.50 and higher are a bit less memory-efficient than version 3.32, since to avoid some 'nil' problems, and problems with table.sort, there is less reuse of tables.
Versions 3.54 and higher will use significant additional memory if the Recent Event Mode is enabled.
Versions 3.59 and higher use additional memory to track Incoming Spells and Abilities, and to track the details of misses.
Versions 3.61 and higher will use additional memory, communications, and processing resources when synchronization is enabled.
Versions 3.67 and higher use a small amount of additional memory for storing Personal Details for player pets.
Versions 3.68 and higher will use significant additional data memory (about 40% more) if the Other Data Mode is enabled.
Versions 3.69 and higher use some additional memory for storing information about glancing blows, partial effects, and minimum values.
Versions 3.70 and higher use a small amount of additional memory for storing element subtotals and totals (Outgoing and Incoming Details), and a small amount for storing
	the summary totals for friendly and non-friendly combatants.
Versions 3.76 and higher will use additional data memory if the Matrix Data Mode is enabled.
Versions 4.00 and higher use significant additional memory, though this can be reduced by turning on the (deprecated) "Ignore Global Unique Identifiers" option.  Additional
	memory is also needed for the separate Last data, and as a result of the increased combat log range.  A number of optimizations reduced the existing use of memory, so
	with additional features turned off memory use might actually drop.
Versions 4.28 and higher use slightly less memory due to simpler treatment of partial resists.
Versions 4.36 and higher use slightly less memory due to conversion of the recent events table from a table of tables to a table of strings.
Versions 4.50 and higher will use additional data memory if the Live Data Mode is enabled.
Versions 4.53 and higher will use some additional data memory if the Other Data Mode is enabled, due to tracking a higher proportion of spell casts.

__ Save Data Set Size __

Versions 4.75 and higher will have larger saved data sets, due to having to split some data fields into high order and low order halves.

__ Stress Testing __

During testing for version 4.29 I had my All Fights count to over 21000 combatants (over 14000 displayable on the main panel), with Recap using over 300 Mbytes of
	addon memory, with no major problem other than slow login and logout.

__ CPU Time Use __

For version 3.70:
	With synchronization running, and with Recent Data Mode and Other Data Mode both turned on, in a sampling (N=20) (in Karazhan including Library, Aran, Illhoof,
	and Chess) Recap used 2.1% of the addon CPU time.  For comparison KLHThreatMeter (with the bar display hidden) used 9.9% of the addon CPU time, CTRA used 3.1%,
	and Decursive used 1.8%.  In a similar recent sampling (N=15) in Botanica Recap used 3.2% of the addon CPU time and KLHThreatMeter (with the bar display hidden)
	used 14.1% of the addon CPU time.  In another sampling (N=21) Recap used 3.0% of the addon CPU time and Omen used 3.6% of the addon CPU time.

For version 4.37:
	I had been wondering about Recap's CPU performance lately; did a bit more code optimization; and compared it to other addons.
	Note that the following might be misleading since library usage is attributed to the alphabetically first addon that supplies the library, and Recap is earlier
		in the alphabet than Recount and Skada.  A quick cross-check (renaming Recount to appear earlier than Recap) suggests that both benefit equally from the
		libraries that other addons supply, so in this particular case the following numbers are probably a fair comparison.
	For a number of solo Stratholme Baron mount runs Recap out of the box took 2.88% of the addon CPU time; Recount out of the box took 1.35% of the addon CPU
		time; and Skada out of the box took 1.34% of the addon CPU Time (summing over all of Skada's modules).  Live damage or dps was shown in text, but no
		other display was done for any of the addons.  Damage done generally agreed exactly, except that Recount very occasionally missed some pet hits, and
		Skada usually missed the first hit by a pet and often missed other combat log events seemingly at random (this has been noted on the web by others).
		By way of comparison RatingBuster took 11.51%, Pawn took 8.03%, sRaidFrames took 5.76%, oRA2 took 5.73%, and Omen took 4.32% of CPU time.
	In another set of Baron runs with all Recap data modes turned on (Other, Matrix, and Recent) and with 90 Mbytes in stored data sets, and with a different
		set of addons active, Recap took 2.06%, Recount took 0.92%, and Skada took 0.88%.  The eleven addons ahead of Recap in CPU time usage ranged from
		DoTimer (25.61%) through oRA2 (3.65%) to DBM-Core (2.36%).
	Other measurement runs in 10 and 25 person raids gave similar ratios among Recap, Recount, and Skada averaging 1.8, 1.0, and 0.8.
	Compared to other addon types, all of the damage meters are acceptably efficient.  I'm happy with Recap's performance, especially considering how much
		additional information Recap is storing at maximum compared to the other addons.
	With version 4.50 Recap introduced live DPS graphing.  For a similar baseline set of Baron runs without graphics, Recap took 1.8% and Recount took 0.9%.
		With graphics turned on for both addons, for a set of five runs Recap took 2.6% and Recount took 20.7% (not a misprint).

For version 4.50, measurements for live graphing:
	All of the following measure addon CPU time as a proportion of elapsed time, a measurement which is largely independent of the mix of addons.  The
		summary is based on more than a dozen sets of measurements ranging from 5 person parties to 25 person raids.
	The underlying cost of Recap (with Other, Matrix and Recent data modes enabled and an average of 70 Mbytes of Recap saved data sets) is about 0.055%
		per combatant (the actual relationship is slightly steeper than linear).  The approximate cost for a party of 5 is 0.3%, for a raid of 10 is 0.6%,
		and for a raid of 25 is 1.5%.
	The cost of collecting live data but not graphing it adds a small proportion more, so the cost for a raid of 10 is 0.65% and for a raid of 25 is 1.6%.
	The cost of graphing adds about 0.075% for each individual graph line.
	For a raid of 10 with all 10 lines being graphed, the cost is about (0.65% + 10 * 0.075%) or 1.4% of elapsed time.  For a raid of 25 with all 25 lines
		being graphed, the cost is about (1.6% + 25 * 0.085%) or 3.7% of elapsed time.
