﻿
  Recap 3.32


This AddOn will track and summarize the damage dealt and received by every participant in a fight around the user.

__ New in 3.32 __
- Displaced text back in minimized view
- Scrollwheel works on lists
- All combat events unregister when paused

__ Future Plans __

- Syncronize data with other users
- "LOD" for data: Self->Friendly->All->Incoming->Outgoing
- Rebuild the list construction method
- "Copy" effects ability, to compare effects
- More optimizations (make functions local, etc)
- Track total blocked and absorbed damage
- Change fonts in 1.7 client (swoon)
- More customization of details panel
- Ability to go back multiple fights
- Allow retroactively unmerging pets from owners
- Fight data sets for individuals
- "Quick save"/"Quick load" fight data sets
- Options to create a format for log reports
- Continually update list view

Revision history:

3.32, 1/16/06 - bug fixed: displaced text back in window, scrollwheel will scroll windows, changed: when paused, all combat events unregistered
3.31, 7/25/05 - bug fixed: display fixed going last/all while minimized in self view, correct effect always links from personal view now
3.3, 7/21/05 - optimizations: forced save/load at startup only happens on version change/new user, a data set copy of the live data will no longer be kept, ignore flag is now nil or true, added: gauges for all columns, personal details view is back, option to warn on large amounts of data (on by default), changed: grouped buttons into less blps, doubled viewable data sets, recap.DataVersion now follows current mod version, lines linked to chats that exceed 255 characters are broken into multiple chunks, bugs fixed: max hit overview includes max tick, pet tick detail stored on owner when pets merge, error fixed with pets in first fight of session, can no longer link -- entries, linking DmgIn% Out% Heal% now formats properly
3.22,7/14/05 - bug fixed: light data mode warning is back
3.21,7/12/05 - bug fixed: nil error fixed for initial conversions without data sets
3.2, 7/12/05 - added: DPS vs All column, tick damage/avg/max, overhealing column, initial casting times included in DPS durations, report to clipboard, HTML report option. optimized: idle OnUpdates only happen while fighting, initial values are nil instead of 0, data sets' incoming and detail compressed more, changed: hits vs crits vs ticks broken apart further, options drop from savedvariables if no longer used, bugs fixed: gauges always stretch full width. updated .toc
3.12 7/6/05 - bugs fixed: wowchatlog flow changed to fix spam some see, removed attempt to clean .Self for users who had errors in 3.1.
3.11 7/4/05 - bug fixed: option types load from defaults to prevent errors from .DataVersions updating but not changing types. German localization back to globalstrings for time being. Abilitity to localize variations of self pronoun.
3.1  7/2/05 - added: global settings option, #misses in damage details, right-click headers to turn columns on/off, heals clipped to actual amounts when possible, overhealing tracked per heal in details, numbered list column, ability to list/link crits/avg/max/miss in place of total damage in outgoing details, changed: gauges based off actual amounts instead of %, windows made toplevel again, rearranged outgoing details, healing is tracked outside of fights, grow left/upwards options moved to display tab as "anchors", effect to/from ignored combatants completely tossed out, long names will show a tooltip of the name, bugs fixed: (%d absorbed) won't show in effects
3.02,6/24/05 - changed: filters now convert globalstrings, test version
3.0, 6/24/05 - added: misses and damage detail tracked for all combatants, dockable details panel, auto minimize, light data mode, autopost leader, gauges, write to log. changed: minimize moves with anchor, shift+Lclick/Rclick in main window reversed, bug fixed: FD detected for hunters. removed: merge option in data sets temporarily removed.
2.64, 6/9/05 - bug fixed: when pets merge, party/raidmembers are shown correctly. added: in fight data sets, combatants are numbered x(y), y being friendly combatants in that set. toc changed to 1500
2.63, 6/6/05 - changed: German heal localization reverted to 2.6. No other changes.
2.61- 6/1/05 - bugs fixed: fixed total time reloading bug, added a few pixels back to max hit column, right-click menu works now with different scaling, French heal/death/icon localization by Fabinou.  German heal filter reordered by Maischter.
2.6 - 5/22/05 - optimized: data restructured to take up less space with greater flexibility for changes. added: merge pets option (needs 1.5 client), faction, class, % heal/dmgin/dmgout columns, maximum rows option, auto-post of ranks each fight option, option to make backdrop transparent while minimized, titan plugin, changed: right-click to toggle friends now a drop down to toggle friend, reset or ignore bugs fixed: effects with (x absorbed) won't be separate, infobar plugin will update in realtime always, effects that both damage and heal will be separate in details
2.5 - 5/6/05 - bug fixed: report by rows will work for all clients/factions, added: details view to show crits and damage/healing/effect, colored titlebars for current view, changed: infobar updates in realtime
2.43 - 5/4/05 - bug fixed: Self for first time users, added: French healing and death localization by Fabinou
2.42 - 5/4/05 - added: option to shift+click header into rows or one line, preliminary effects tracking for self/pet for localization
2.41 - 5/4/05 - bug fixed: 11th+ entry will shift+click ok now
2.4 - 5/3/05  - added: deaths and heals columns, option to hide yard trash, changed: if window hidden will remain hidden on login, reset button, shift+click of header will be much more readable, minimized dps values update in realtime, German localization update by Mojo, made data set edit box more noticable
2.31- 4/29/05 - bug fixed: german localization string by IceH
2.3 - 4/28/05 - bug fixed: verbose link. added: German localization by Mojo.
2.2 - 4/27/05 - bugs fixed: missing You suffer filter, trailing damage in absorbed hits. added: French localization by Oxman
2.0 - 4/24/05 - optimizations: data and fight flow restructured into separate tables so minimum calculations/allocations needed, changed sort method for drastic speed improvements, calculations performed only when needed. changed: window growth is no longer automatic but in options, pin button only serves to lock window now. removed: compact mode (obsolete), dps is always adjusted per combatant, reset totals for each fight removed.  added: fight data sets, idle timer to end fights, custom list views, more shift+click views, max hits,
1.42- 4/15/05 - changed: initialization delayed until UnitName("player") is valid.
1.4 - 4/14/05 - added: option to fade window, option to show only friends, option to show only fights with duration, localization.lua, /recap reset, changed: if reset totals unchecked fights begin at first hit by anyone, enabled pause during Active mode, merged pets and owners in personal DPS (white DPS), friends checked more frequently, window will grow upwards if in bottom half of screen, if pinned recap will show at startup, switched logging method from chatframe event hook to registering for every damage event.
1.3 - 4/12/05 - bugs fixed: client crash with gypsy general, infobar not updating on adjust dps change, added: myAddOn entry, fade on post-fight update, changed: made "pin" rules consistent across all views
1.2 - 4/11/05 - added plugin for Telo's Infobar to show DPS
1.1 - 4/10/05 - added option to let totals accumulate, added time column, overhauled list functionality, added shift+click to "link" DPS, added compact minimized view, added the ability to grab names from raid
1.0 - 3/28/05 - initial release


Fight Data Set format for v3.2+:

There are three segments: totals^incoming^[detail1][detail2][detail3][etc]

totals format: friend dmgin dmgout max heal kills time.f ~faction class level
example: true 100 500 50 200 1 180.541 ~0 9 60

incoming format: ^a###a###a###^
example: ^c20e1f2m2^

a:MeleeDamage
b:MeleeMax
c:MeleeHits
d:MeleeCrits
e:MeleeMissed
f:MeleeDodged
g:MeleeParried
h:MeleeBlocked
i:NonMeleeDamage
j:NonMeleeMax
k:NonMeleeHits
l:NonMeleeCrits
m:NonMeleeMissed

details format: [aName>a###a###a###]
example: [1Mind Blast>d888n1x888m2]

First a is type: 1=damage, 2=pet damage, 3=heal, 4=pet heal

d:HitsDmg
n:Hits
x:HitsMax
D:CritsDmg
N:Crits
X:CritsMax
e:CritsEvents
m:Missed
t:TicksDmg
T:TicksMax
