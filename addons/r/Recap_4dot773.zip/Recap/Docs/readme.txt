﻿
  Recap 4.773

Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference.


This AddOn will track and summarise the damage and healing dealt and received by every participant in fights around the user; as well as most other combat-related events.  Recap tracks buffs, debuffs, and the use of abilities.
Recap was originally developed by Gello, and Gello's original code is used by permission.  Recap is currently being maintained by Hawksy.
Versions 4.63, 4.64, 4.652, and 4.66 were maintained by Renews.

German translation by Dhana.
Simplified Chinese translation by Ariestk.
Traditional Chinese translation by Ariestk.
Brazilian Portuguese translation by Renews.
Editing assistance by TextWrangler, a great freeware program text editor for the Macintosh from Bare Bones Software, Inc.

**QUICK START GUIDE:**  If you are new to Recap, or wish a quick overview, check out Recap_Quick_Start.rtf.  This file is inside the Docs folder inside the Recap folder.

**FREQUENTLY ASKED QUESTIONS:**  If you wish more detailed information, check out readme_FAQ.txt for all of the features I have added or modified.  For answers about earlier (and possibly obsolete) features of Recap prior to version 3.50, check out readme_332_FAQ.txt by Gello.  These files are inside the Docs folder inside the Recap folder.

**REPORTING A BUG:**  Contact me either via the wow.curse.com comments section for the addon; via private message on www.curse.com; or e-mail me at hawksy@telus.net.  Please mention the version number, and double-check it by looking at the bottom of the Recap Options panel.

**MAKING A SUGGESTION:**  Contact me in the same way as for reporting a bug.


__ New in 4.77 __
* Split fight save into phases, to reduce the likelihood of addon timeout
	limits.
* Added 'per second' values as menu choices for the 'total' column on
	the Outgoing and Incoming tabs on the Details panel.
* Special code for Mirror Image, Soul Link, Death Pact, Spirit Link,
	Cauterize Master, and Swarming Shadows spells.
* Added option to start and end fights based on Blizzard encounters only.
	This is currently NOT RECOMMENDED, because the encounter events
	issued by Blizzard are quite inconsistent.
* Bug fixes.
* Six modules from Ace3 (r1109) included.

__ New in 4.763 __
* To persuade Curse to reset itself to 5.4.2.  No code changes.
* Six modules from Ace3 (r1104) included.

__ New in 4.76 __
* Updated for patch 5.4.
* Removed support for legacy data sets earlier than version 4.28 (May 2009).
* Changes to Load Data Set so it is less likely to run out of time if clicked
	during combat.
* Bug fixes.
* Six modules from Ace3 (r1098) included.

__ New in 4.75 __
* Updated for patch 5.3.
* Added posting to BNET whispers and conversations.
* Wider fields in many windows.
* Splitting large numbers in saved data sets.
* Click the "Events", "Dispels & Interrupts", "Deaths", or "Live Graph & Text"
	button to close the corresponding panel if it is open.
* Increase Source and Target scroll boxes on popup panel from 15 to 25 lines.
* Added Interrupts column to main panel.
* Changed code for combat log event format for absorptions.
* Bug fixes and improvements.
* Special mention of assistance by coani with in-game testing.
* Six modules from Ace3 (r1086) included.

__ New in 4.71 __
* Updated for patch 5.1.
* For main and load panels, normal behaviour when shift+clicking a column
	header is to post only friendly combatants.  New ability when holding down
	Alt (Option) while shift+clicking posts only non-friendly combatants.
* For main and load panels, ability to shift+click the name column.
* For Incoming and Outgoing Details panels, ability to limit display to damage
	only or healing only.
* Partial fix for new miss type 'misfire', which will be treated as a simple
	'miss' until someone takes over who can test changes properly.
* Registered UNIT_PET event.
* Bug fixes.
* Six modules from Ace3 (r1061) included.

__ New in 4.652
* Fix the bug where Shaman Totems doesn't merge damage with owner.

__ New in 4.65 __
* Updated for patch 4.2.
* Bug fixes.
* Six modules from Ace3 (r1032) included.

__ New in 4.62 __
* Note that combat log events do not give much help for attributing damage done
	by Shadowy Apparitions to the proper shadow priest.
* Bug fixes.
* Six modules from Ace3 (r981) included.

__ New in 4.61 __
* Bug fixes.
* Six modules from Ace3 (r971) included.

__ New in 4.60 __
* Updated for patch 4.0.1.
* Bug fixes.
* New code for shields, removes existing special case code and uses Blizzard's
	new "shield remaining" numbers.
* Six modules from Ace3 (r960) included.


Revision history:

4.77, 2014-08-06 - Workaround for patch 5.4 Blizzard slider error ignoring
	valueStep; modified code for counting deaths, including fixing a long-
	standing bug; and added ENCOUNTER_START and ENCOUNTER_END events; made
	save into seven phases to reduce chance of triggering the Blizzard
	timeout (the 'resume' button will be blocked if a save is in progress);
	fixed a couple of bugs in fight start and fight end code; added 'per
	second' values as menu choices for the 'total' column on the Outgoing
	and Incoming tabs on the Details panel; the passive healing ability
	Ysera's Gift will no longer start or extend a fight; special case code
	for Mirror Image spell (Recap will create two pets per mirror image,
	so six in total); special case code for Twilight Instability spell in
	the Ultraxion fight; special case code for Soul Link, Death Pact,
	Spirit Link, Cauterize Master, and Swarming Shadows spells; and track
	pet ownership information and group membership information across
	saves and restores.

	Most of these improvements are directly or indirectly thanks to coani's
	bug reports and suggestions and testing, for which he deserves
	considerable credit.

4.764, 2014-01-15 - Fix for error in RecapCombat line 5302 (thanks Ryne).

4.763, 2014-01-11 - To persuade Curse to reset itself to 5.4.0.

4.762, 2013-10-29 - Fix for error in Recap line 1677 (thanks Basthet, thanks
	ShadyPenguins for the fix).

4.761, 2013-10-18 - Fix for error in RecapPanel line 2404 (thanks Keryn_TB).

4.76, 2013-10-18 - Removed support for data sets and files prior to 4.28;
	split Load Data Sets so it is less likely to trigger the Blizzard timeout
	if used during combat with large data sets; fix for error in RecapAux line
	4023 (thanks Narror).

4.75, 2013-05-10 - Modifications to handle numbers over 2147483648; increased
	many field sizes; added Interrupts column to main panel; clicking "Events"
	button and similar buttons will close the corresponding panel if it is
	open; increased Source and Target scroll boxes on panel from 15 to 25
	lines; updated combat log code to handle format change for shield
	absorption; added ability to post to BNET whispers and conversations;
	other fixes and improvements; special mention of coani for assistance with
	in-game testing.

4.71, 2012-12-02 - Fixed error in Recap_AddPetDetailsToOwner (reported by
	Tenyks); updated WoW version number to 50100.

4.709 beta, 2012-09-23 - Added Combatant to the columns that you can shift+click
    to post; holding down Alt (Option) while shift+clicking a column on the Main
	panel and the Load panel will post non-friendly combatants rather than
	friendly combatants; special thanks to coani for testing for errors, and
	for both suggesting and testing the added functionality in these versions;
	updated instance difficulty code; added special case code to mark the Spine
	fight as a boss fight; added an extra decimal place to several percentages;
	fixed an infinite loop of pet owning itself (thanks coani); separated auto-
	save code from regular end of fight processing, so that it now happens a
	tick later, to avoid running into Blizzard's addon limit timer; reduced
	tick interval to half-second.

4.708 beta, 2012-10-18 - Added registration of UNIT_PET event.

4.707 beta, 2012-10-11 - Fix for Recap_RootOwner infinite loop.

4.706 beta, 2012-09-30 - Fix for new miss type 'misfire'.  Even better fix for
	the ListSize error is still in testing.

4.705 beta, 2012-09-16 - Second fix for ListSize error.

4.704 beta, 2012-09-08 - Removed split of EndFight; added two options to the
	right-click menus on the "Outgoing Details" and "Incoming Details" Total
	header, one to limit lines to damage totals only and one to limit lines to
	healing totals only.

4.703 beta, 2012-09-06 - Fixed error in RecapCombat.

4.702 beta, 2012-09-06 - Fixed error in RecapOptions.

4.701 beta, 2012-09-06 - Added new power types; forced primary event amounts to
	be integers; fixed rSet[i].ListSize nil anomaly; split EndFight into two
	since it may have been taking too long.

4.70 beta, 2012-09-02 - Updated WoW version number to 50001; fixed several
	Blizzard function names and event names and related code; added monk name
	and monk icon; did not check whether changes needed for change to
	SPELL_CAST_SUCCESS; did not check reported bug with UnitGUID.

4.65, 2011-06-04 - Added two combat log parameters for patch 4.2 (reported by
	shoe_299 and others; added a large number of declarations for _ as a local
	variable (reported by coani); added code to bypass a bug with the previous
	and next end of fight buttons (reported by acecow).

4.62, 2010-11-29 - Fixed incorrect code for interrupted spells; added code to
	store dispelled auras as Other Data; added Attribute to output from Other
	Data tab; fixed an error at RecapCombat 725; fixed several deprecated items
	that somehow escaped my attention two years ago, plus some similar updates;
	fixed a minor problem with Recap code for the Blizzard Interface AddOns
	panel; added "/rl" command to reload UI; archived older release notes to
	readme_455.txt; removed limit on size of posting to Clipboard since it
	seems that an EditBox is no longer limited to about 32000 letters; removed
	ChatThrottleLib from dumps to WoWChatLog.txt; removed ChatThrottleStats
	code (see 4.61).

4.61, 2010-10-19 - Fix WoW version number to 40000; fixed RecapCombat line 3231
	error (reported by Chasim); various adjustments and fixes to the shield
	absorption code; added code from ChatThrottleStats to help tell when log
	dumps via ChatThrottleLib have completed; modified shield code to support
	Anti-Magic Shell.

4.60, 2010-10-12 - Modifications for Cataclysm Beta and patch 4.0.1; added new
	resource names (PowerName); removed special case shield code, added new code
	to use SPELL_AURA_REFRESH and SPELL_AURA_REMOVED events to credit absorption
	by shields to the shielder (there are still many anomalies in the combat log
	events, but on average the shielding numbers should be more accurate); added
	code to reconcile Blizzard's timestamps with the times returned by GetTime();
	removed special case code for Improved Leader of the Pack.


The revision information for 3.50 through 4.55 are in readme_455.txt.

The revisions for 3.32 and earlier are by Gello (see readme_332.txt).
