﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ Fight functions ]]

local bit_band = _G.bit.band
local bit_bor = _G.bit.bor
local math_floor = _G.math.floor
local math_max = _G.math.max
local math_min = _G.math.min
local string_find = _G.string.find
local string_format = _G.string.format
local string_gmatch = _G.string.gmatch
local string_gsub = _G.string.gsub
local string_lower = _G.string.lower
local string_sub = _G.string.sub
local string_upper = _G.string.upper
local table_sort = _G.table.sort
local pairs = _G.pairs
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local print = _G.print

-- Recap-specific
local rLocalize = _G.recap_temp.Localize
local rShields = _G.recap_temp.ShieldRegistration

--[[ local functions (precede first use) ]]

local function Recap_CreateCombatantAndUpdateTimers(thisCombatant, timestamp, flags, timeType)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local iLast

	-- guard code
	if not thisCombatant then
		return
	end

	-- if thisCombatant not a .Combatant, add an entry for them
	if not rCombatants[thisCombatant] then
		Recap_CreateBlankCombatant(thisCombatant, math_floor(1000*timestamp), flags)
	end

	-- if they haven't fought this session, add a .Last entry for them (only do it once, we get called repeatedly)
	if not rTemp.Last[thisCombatant] then
		Recap_InitializeLastFight(thisCombatant)
	end

	-- If we get here for any reason we might as well start the overall fight timers
	--   (Recap 3.32 would only do so for a source doing damage, or for a spellcast start)
	--   (Is healing after a fight, thus starting a 'new' fight, any different from someone ganking a toad?)
	-- now three independent overall fight timers
	if rTemp.InFriend[thisCombatant] then
		-- overall fight timers should be for group only -- this has been in error for years !
		if timeType == "Out" then
			if rTemp.FightStart==0 then
				rTemp.FightStart = timestamp
			end
			rTemp.FightEnd = timestamp
		elseif timeType == "In" then
			if rTemp.FightStartIn==0 then
				rTemp.FightStartIn = timestamp
			end
			rTemp.FightEndIn = timestamp
		elseif timeType == "Heal" then
			if rTemp.FightStartHeal==0 then
				rTemp.FightStartHeal = timestamp
			end
			rTemp.FightEndHeal = timestamp
		end
	end

	-- three independent timers per combatant for damage dealt, damage received, and healing done
	--   (at the moment no timer for healing received)
	iLast = rTemp.Last[thisCombatant]
	if timeType == "Out" then
		if iLast.StartOut==0 then
			iLast.StartOut = timestamp
		end
		iLast.EndOut = timestamp
	elseif timeType == "In" then
		if iLast.StartIn==0 then
			iLast.StartIn = timestamp
		end
		iLast.EndIn = timestamp
	elseif timeType == "Heal" then
		if iLast.StartHeal==0 then
			iLast.StartHeal = timestamp
		end
		iLast.EndHeal = timestamp
	end

	-- anyone who does damage, takes damage, heals, or receives heals will be flagged as having been in the fight
	rCombatants[thisCombatant].WasInCurrent = true

	-- remember any of the player's pets who are involved in the Last fight (to optimize live update calculations)
	if Recap_IsOwnedBy(thisCombatant, rTemp.PlayerGUID) then
		rTemp.LastPlayerPets[thisCombatant] = true
	end
end

local function Recap_AddPetToOwner(pet, owner)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local combatantPet = rCombatants[pet]
	local combatantOwner = rCombatants[owner]
	local lastPet = rTemp.Last[pet]
	local lastOwner = rTemp.Last[owner]

	if not combatantPet then
		return
	end
	if not combatantOwner then
		return
	end
	if not lastPet then
		return
	end
	if not lastOwner then
		return
	end

	-- now three independent times, for damage, incoming, and healing
	if (combatantPet.WasInCurrent and (lastPet.StartOut > 0)) and
	   (combatantOwner.WasInCurrent and (lastOwner.StartOut > 0)) then
		-- both pet and owner were in the fight and did damage
		lastOwner.StartOut = math_min(lastPet.StartOut, lastOwner.StartOut)
		lastOwner.EndOut = math_max(lastPet.EndOut, lastOwner.EndOut)
	elseif (combatantPet.WasInCurrent and (lastPet.StartOut > 0)) and
		   (not combatantOwner.WasInCurrent or (lastOwner.StartOut == 0)) then
		-- the pet was in the fight and did damage, the owner did no damage
		lastOwner.StartOut = lastPet.StartOut
		lastOwner.EndOut = lastPet.EndOut
	end
	if (combatantPet.WasInCurrent and (lastPet.StartIn > 0)) and
	   (combatantOwner.WasInCurrent and (lastOwner.StartIn > 0)) then
		-- both pet and owner were in the fight and took damage
		lastOwner.StartIn = math_min(lastPet.StartIn, lastOwner.StartIn)
		lastOwner.EndIn = math_max(lastPet.EndIn, lastOwner.EndIn)
	elseif (combatantPet.WasInCurrent and (lastPet.StartIn > 0)) and
		   (not combatantOwner.WasInCurrent or (lastOwner.StartIn == 0)) then
		-- the pet was in the fight and took damage, the owner took no damage
		lastOwner.StartIn = lastPet.StartIn
		lastOwner.EndIn = lastPet.EndIn
	end
	if (combatantPet.WasInCurrent and (lastPet.StartHeal > 0)) and
	   (combatantOwner.WasInCurrent and (lastOwner.StartHeal > 0)) then
		-- both pet and owner were in the fight and did healing
		lastOwner.StartHeal = math_min(lastPet.StartHeal, lastOwner.StartHeal)
		lastOwner.EndHeal = math_max(lastPet.EndHeal, lastOwner.EndHeal)
	elseif (combatantPet.WasInCurrent and (lastPet.StartHeal > 0)) and
		   (not combatantOwner.WasInCurrent or (lastOwner.StartHeal == 0)) then
		-- the pet was in the fight and did healing, the owner did no healing
		lastOwner.StartHeal = lastPet.StartHeal
		lastOwner.EndHeal = lastPet.EndHeal
	end

	lastOwner.DmgIn = lastOwner.DmgIn + lastPet.DmgIn
	lastOwner.DmgOut = lastOwner.DmgOut + lastPet.DmgOut
	lastOwner.PetsDmgOut = lastOwner.PetsDmgOut + lastPet.DmgOut
	lastOwner.MaxHit = math_max(lastOwner.MaxHit, lastPet.MaxHit)
	-- no longer copy pet deaths up to owner
	-- note that since we are not accumulating pet deaths upwards, we don't bother to adjust the pet death count (see Recap_ProcessDeathEvents if we change our mind)
	-- lastOwner.Deaths = lastOwner.Deaths + lastPet.Deaths
	lastOwner.Dispels = lastOwner.Dispels + lastPet.Dispels
	lastOwner.Interrupts = lastOwner.Interrupts + lastPet.Interrupts
	lastOwner.RawHeal = lastOwner.RawHeal + lastPet.RawHeal
	lastOwner.OverHeal = math_min((lastOwner.OverHeal + lastPet.OverHeal), lastOwner.RawHeal)

	lastPet.StartOut = 0
	lastPet.EndOut = 0
	lastPet.StartIn = 0
	lastPet.EndIn = 0
	lastPet.StartHeal = 0
	lastPet.EndHeal = 0
	lastPet.DmgIn = 0
	lastPet.DmgOut = 0
	lastPet.PetsDmgOut = 0
	lastPet.MaxHit = 0
	lastPet.Deaths = 0
	if lastPet.DeathEvents then
		lastPet.DeathEvents = nil
		lastPet.DeathEventsIndex = nil
	end
	lastPet.Dispels = 0
	lastPet.Interrupts = 0
	lastPet.RawHeal = 0
	lastPet.OverHeal = 0

	combatantPet.WasInCurrent = false
	combatantOwner.WasInCurrent = true -- if the owner wasn't in the fight, the owner is now

end

local function Recap_SortDeathEvents(e1, e2)

	if e1 and e2 then
		if type(e1.Time) == type(e2.Time) then
			-- types match, normal compare
			if (e1.Time < e2.Time) then
				return true
			else
				return false
			end
		else
			-- types don't match, force string compare
			if (tostring(e1.Time) < tostring(e2.Time)) then
				return true
			else
				return false
			end
		end
	else
		-- one or both are nil
		if (not e1) and e2 then
			return true
		else
			return false
		end
	end
end

-- for each combatant in the Last fight, we have a table with death events for that combatant ("SoR" is holy priest Spirit of Redemption which can give an extra death event)
local function Recap_ProcessDeathEvents(iLast, allowDebug)

	local i
	local nDeaths = 0
	local deathTime = 0
	local deathType = ""

	table_sort(iLast.DeathEvents, Recap_SortDeathEvents)

	for i in pairs(iLast.DeathEvents) do
		if (deathTime == 0) then
			-- first death event always counts, regardless of type
			nDeaths = nDeaths + 1
			deathTime = iLast.DeathEvents[i].Time
			deathType = iLast.DeathEvents[i].Type
		else
			-- subsequent death event (state machine)
			local newDeathTime = iLast.DeathEvents[i].Time
			local newDeathType = iLast.DeathEvents[i].Type
			if (deathType == "killed") then
				if (newDeathType == "killed") then
					-- a second "killed" must be a new death, regardless of time difference
					nDeaths = nDeaths + 1
					deathTime = newDeathTime
					deathType = newDeathType
				elseif (newDeathType == "died") then
					if ((newDeathTime - deathTime) > 2) then
						-- a "died" more than two seconds after a "killed" is assumed to be a new death
						nDeaths = nDeaths + 1
						deathTime = newDeathTime
						deathType = newDeathType
					else
						-- a "died" within two seconds of a "killed" is assumed to be the same death (this is the most common combination)
					end
				elseif (newDeathType == "SoR") then
					if ((newDeathTime - deathTime) > 2) then
						-- an "SoR" more than two seconds after a "killed" is assumed to be a new death
						nDeaths = nDeaths + 1
						deathTime = newDeathTime
						deathType = newDeathType
					else
						-- an "SoR" within two seconds of a "killed" changes the state
						deathType = "SoR"
					end
				end
			elseif (deathType == "died") then
				if (newDeathType == "killed") then
				 	if ((newDeathTime - deathTime) > 2) then
						-- a "killed" more than two seconds after a "died" is assumed to be a new death
						nDeaths = nDeaths + 1
						deathTime = newDeathTime
						deathType = newDeathType
					else
						-- a "killed" within two seconds of a "died" is assumed to be the same death
						-- this will be rare, as almost invariably the "killed" event precedes the "died" event
					end
				elseif (newDeathType == "died") then
					-- a second "died" must be a new death, regardless of time difference
					nDeaths = nDeaths + 1
					deathTime = newDeathTime
					deathType = newDeathType
				elseif (newDeathType == "SoR") then
					if ((newDeathTime - deathTime) > 2) then
						-- an "SoR" more than two seconds after a "died" is assumed to be a new death
						nDeaths = nDeaths + 1
						deathTime = newDeathTime
						deathType = newDeathType
					else
						-- an "SoR" within two seconds of a "died" changes the state (allowing detection of a full term Spirit of Redemption)
						deathType = "SoR"
					end
				end
			elseif (deathType == "SoR") then
				if (newDeathType == "killed") then
					if ((newDeathTime - deathTime) > 2) then
						-- a "killed" more than two seconds after an "SoR" is assumed to be a new death
						nDeaths = nDeaths + 1
						deathTime = newDeathTime
						deathType = newDeathType
					else
						-- a "killed" within two seconds of an "SoR" is assumed to be the same death
						-- this will be rare, as usually the "killed" event precedes the "SoR" event
					end
				elseif (newDeathType == "died") then
					if ((newDeathTime - deathTime) > 23) then
						-- a "died" more than 23 seconds after an "SoR" is assumed to be a new death (glyphed Spirit of Redemption can be 21 seconds)
						nDeaths = nDeaths + 1
						deathTime = newDeathTime
						deathType = newDeathType
					else
						-- a "died" within 23 seconds of an "SoR" is assumed to be the same death (Spirit of Redemption)
					end
				elseif (newDeathType == "SoR") then
					-- a second "SoR" must be a new death, regardless of time difference
					nDeaths = nDeaths + 1
					deathTime = newDeathTime
					deathType = newDeathType
				end
			end
		end
	end

	return nDeaths
end

local function Recap_AccumulateCombatant(i, iCombatant, iLast)

	local rTemp = _G.recap_temp
	local k, lastDmgIn, lastDmgOut, lastPetsDmgOut, lastTimeOut, lastTimeIn, lastTimeHeal, lastMaxHit, lastDeaths, lastDispels, lastInterrupts, lastRawHeal, lastOverHeal

	lastDmgIn = iLast.DmgIn
	lastDmgOut = iLast.DmgOut
	lastPetsDmgOut = iLast.PetsDmgOut
	-- these three if statements shouldn't be necessary, but I'm getting paranoid about the reported bad Time values
	if iLast.StartOut > 0 and (iLast.EndOut > iLast.StartOut) then
		lastTimeOut = iLast.EndOut - iLast.StartOut
	else
		lastTimeOut = 0
	end
	if iLast.StartIn > 0 and (iLast.EndIn > iLast.StartIn) then
		lastTimeIn = iLast.EndIn - iLast.StartIn
	else
		lastTimeIn = 0
	end
	if iLast.StartHeal > 0 and (iLast.EndHeal > iLast.StartHeal) then
		lastTimeHeal = iLast.EndHeal - iLast.StartHeal
	else
		lastTimeHeal = 0
	end
	lastMaxHit = iLast.MaxHit
	lastDeaths = iLast.Deaths
	lastDispels = iLast.Dispels
	lastInterrupts = iLast.Interrupts
	lastRawHeal = iLast.RawHeal
	lastOverHeal = math_min(iLast.OverHeal, lastRawHeal)

	-- special processing to adjust the death count
	if iLast.DeathEvents then
		-- we may have death events, sort and process and adjust the Deaths count
		-- NOTE: it looks as though 'max' gets the right answer here more often than 'min' does
		lastDeaths = math_max(lastDeaths, Recap_ProcessDeathEvents(iLast, false))
	end

	-- If there is non-zero damage or healing, force the matching time to be
	--   (somewhat arbitrarily) at least as large as the global cooldown ("DeemedTime").
	--   This gives some duration to single-shot fights (which are accumulated), keeping
	--   the anomalous DPS down a bit, without displaying them or their DPS.
	if (lastDmgOut > 0) and (lastTimeOut < rTemp.DeemedTime) then
		lastTimeOut = rTemp.DeemedTime
	end
	if (lastDmgIn > 0) and (lastTimeIn < rTemp.DeemedTime) then
		lastTimeIn = rTemp.DeemedTime
	end
	if (lastRawHeal > 0) and (lastTimeHeal < rTemp.DeemedTime) then
		lastTimeHeal = rTemp.DeemedTime
	end

	if rTemp.LastFightSignificant then
		-- put the Last Fight summary data for this combatant where the display code can see it
		k = rTemp.ActiveLastFight
		if (lastDmgIn > 0) then
			iCombatant["LastDmgIn_"..k] = lastDmgIn
		end
		if (lastDmgOut > 0) then
			iCombatant["LastDmgOut_"..k] = lastDmgOut
		end
		if (lastTimeOut > 0) then
			iCombatant["LastTime_"..k] = lastTimeOut
		end
		if (lastTimeIn > 0) then
			iCombatant["LastTimeIn_"..k] = lastTimeIn
		end
		if (lastTimeHeal > 0) then
			iCombatant["LastTimeHeal_"..k] = lastTimeHeal
		end
		if (lastMaxHit > 0) then
			iCombatant["LastMaxHit_"..k] = lastMaxHit
		end
		if (lastDeaths > 0) then
			iCombatant["LastDeaths_"..k] = lastDeaths
		end
		if (lastDispels > 0) then
			iCombatant["LastDispels_"..k] = lastDispels
		end
		if (lastInterrupts > 0) then
			iCombatant["LastInterrupts_"..k] = lastInterrupts
		end
		if (lastRawHeal > 0) then
			iCombatant["LastRawHeal_"..k] = lastRawHeal
		end
		if (lastOverHeal > 0) and (lastRawHeal > 0) then
			iCombatant["LastOverHeal_"..k] = math_min(lastOverHeal, lastRawHeal)
		end
	end

	iLast.StartOut = 0
	iLast.EndOut = 0
	iLast.StartIn = 0
	iLast.EndIn = 0
	iLast.StartHeal = 0
	iLast.EndHeal = 0
	iLast.DmgIn = 0
	iLast.DmgOut = 0
	iLast.PetsDmgOut = 0
	iLast.MaxHit = 0
	iLast.Deaths = 0
	if iLast.DeathEvents then
		iLast.DeathEvents = nil
		iLast.DeathEventsIndex = nil
	end
	iLast.Dispels = 0
	iLast.Interrupts = 0
	iLast.RawHeal = 0
	iLast.OverHeal = 0

	if (lastDmgIn > 0) then
		iCombatant.TotalDmgIn = (iCombatant.TotalDmgIn or 0) + lastDmgIn
	end
	if (lastDmgOut > 0) then
		iCombatant.TotalDmgOut = (iCombatant.TotalDmgOut or 0) + lastDmgOut
	end
	if (lastPetsDmgOut > 0) then
		iCombatant.TotalPetsDmgOut = (iCombatant.TotalPetsDmgOut or 0) + lastPetsDmgOut
	end
	if (lastTimeOut > 0) then
		iCombatant.TotalTime = (iCombatant.TotalTime or 0) + lastTimeOut
	end
	if (lastTimeIn > 0) then
		iCombatant.TotalTimeIn = (iCombatant.TotalTimeIn or 0) + lastTimeIn
	end
	if (lastTimeHeal > 0) then
		iCombatant.TotalTimeHeal = (iCombatant.TotalTimeHeal or 0) + lastTimeHeal
	end
	if (lastMaxHit > 0) then
		iCombatant.TotalMaxHit = math_max((iCombatant.TotalMaxHit or 0), lastMaxHit)
	end
	if (lastDeaths > 0) then
		iCombatant.TotalDeaths = (iCombatant.TotalDeaths or 0) + lastDeaths
	end
	if (lastDispels > 0) then
		iCombatant.TotalDispels = (iCombatant.TotalDispels or 0) + lastDispels
	end
	if (lastInterrupts > 0) then
		iCombatant.TotalInterrupts = (iCombatant.TotalInterrupts or 0) + lastInterrupts
	end
	if (lastRawHeal > 0) then
		iCombatant.TotalRawHeal = (iCombatant.TotalRawHeal or 0) + lastRawHeal
	end
	if (lastOverHeal > 0) then
		iCombatant.TotalOverHeal = math_min(((iCombatant.TotalOverHeal or 0) + lastOverHeal), (iCombatant.TotalRawHeal or 0))
	end

	-- three flavours of "per second" calculation for this combatant
	if rTemp.LastFightSignificant then
		if (lastTimeOut > rTemp.MinTime) and (lastDmgOut > 0) then
			iCombatant["LastDPS_"..rTemp.ActiveLastFight] = Recap_Div1(lastDmgOut, lastTimeOut)
		end
		if (lastTimeIn > rTemp.MinTime) and (lastDmgIn > 0) then
			iCombatant["LastDPSIn_"..rTemp.ActiveLastFight] = Recap_Div1(lastDmgIn, lastTimeIn)
		end
		if (lastTimeHeal > rTemp.MinTime) and ((lastRawHeal - lastOverHeal) > 0) then
			iCombatant["LastHPS_"..rTemp.ActiveLastFight] = Recap_Div1((lastRawHeal - lastOverHeal), lastTimeHeal)
		end
	end
	if iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
		iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
	end
	if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
		iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
	end
	if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
		iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
	end

	-- copy last fight gear value
	iCombatant["LastGearValue_"..rTemp.ActiveLastFight] = (iLast.GearValue or 0)

	iCombatant.WasInCurrent = false
	if rTemp.LastFightSignificant then
		iCombatant.WasInLast = true
	end
end

local function Recap_AmalgamatePetIncomingOutgoingDetails(ownerDetail, petDetail)
	if petDetail.Hits then
		ownerDetail.Hits = (ownerDetail.Hits or 0) + petDetail.Hits
	end
	if petDetail.HitsDmg then
		ownerDetail.HitsDmg = (ownerDetail.HitsDmg or 0) + petDetail.HitsDmg
	end
	if petDetail.HitsMax then
		ownerDetail.HitsMax = math_max((ownerDetail.HitsMax or 0), petDetail.HitsMax)
	end
	if petDetail.Crits then
		ownerDetail.Crits = (ownerDetail.Crits or 0) + petDetail.Crits
	end
	if petDetail.CritsEvents then
		ownerDetail.CritsEvents = (ownerDetail.CritsEvents or 0) + petDetail.CritsEvents
	end
	if petDetail.CritsDmg then
		ownerDetail.CritsDmg = (ownerDetail.CritsDmg or 0) + petDetail.CritsDmg
	end
	if petDetail.CritsMax then
		ownerDetail.CritsMax = math_max((ownerDetail.CritsMax or 0), petDetail.CritsMax)
	end
	if petDetail.Missed then
		ownerDetail.Missed = (ownerDetail.Missed or 0) + petDetail.Missed
	end
	if petDetail.Ticks then
		ownerDetail.Ticks = (ownerDetail.Ticks or 0) + petDetail.Ticks
	end
	if petDetail.CritTicks then
		ownerDetail.CritTicks = (ownerDetail.CritTicks or 0) + petDetail.CritTicks
	end
	if petDetail.TicksDmg then
		ownerDetail.TicksDmg = (ownerDetail.TicksDmg or 0) + petDetail.TicksDmg
	end
	if petDetail.TicksMax then
		ownerDetail.TicksMax = math_max((ownerDetail.TicksMax or 0), petDetail.TicksMax)
	end
	ownerDetail.Element = Recap_MergeEntries(ownerDetail.Element, petDetail.Element)
	if ownerDetail.Element and string_find(ownerDetail.Element, "%+", 1, true) and (string_find(ownerDetail.Element, "%?", 1, true) or string_find(ownerDetail.Element, rLocalize.ElementOther, 1, true)) then
		-- strip any "?" or "Other" that isn't solo
		ownerDetail.Element = string_gsub(ownerDetail.Element, "%?%+", "")
		ownerDetail.Element = string_gsub(ownerDetail.Element, "%+%?", "")
		ownerDetail.Element = string_gsub(ownerDetail.Element, rLocalize.ElementOther.."%+", "")
		ownerDetail.Element = string_gsub(ownerDetail.Element, "%+"..rLocalize.ElementOther, "")
	end
	if petDetail.SpellID then
		ownerDetail.SpellID = Recap_MergeEntries(ownerDetail.SpellID, petDetail.SpellID)
	end
	if petDetail.Dodged then
		ownerDetail.Dodged = (ownerDetail.Dodged or 0) + petDetail.Dodged
	end
	if petDetail.Parried then
		ownerDetail.Parried = (ownerDetail.Parried or 0) + petDetail.Parried
	end
	if petDetail.Blocked then
		ownerDetail.Blocked = (ownerDetail.Blocked or 0) + petDetail.Blocked
	end
	if petDetail.Absorbed then
		ownerDetail.Absorbed = (ownerDetail.Absorbed or 0) + petDetail.Absorbed
	end
	if petDetail.Deflected then
		ownerDetail.Deflected = (ownerDetail.Deflected or 0) + petDetail.Deflected
	end
	if petDetail.Evaded then
		ownerDetail.Evaded = (ownerDetail.Evaded or 0) + petDetail.Evaded
	end
	if petDetail.Resisted then
		ownerDetail.Resisted = (ownerDetail.Resisted or 0) + petDetail.Resisted
	end
	if petDetail.Reflected then
		ownerDetail.Reflected = (ownerDetail.Reflected or 0) + petDetail.Reflected
	end
	if petDetail.Immune then
		ownerDetail.Immune = (ownerDetail.Immune or 0) + petDetail.Immune
	end
	if petDetail.ICount then
		ownerDetail.ICount = (ownerDetail.ICount or 0) + petDetail.ICount
	end
	if petDetail.ITotal then
		ownerDetail.ITotal = (ownerDetail.ITotal or 0) + petDetail.ITotal
	end
	if petDetail.Glances then
		ownerDetail.Glances = (ownerDetail.Glances or 0) + petDetail.Glances
	end
	if petDetail.GlancesDmg then
		ownerDetail.GlancesDmg = (ownerDetail.GlancesDmg or 0) + petDetail.GlancesDmg
	end
	if petDetail.GlancesMax then
		ownerDetail.GlancesMax = math_max((ownerDetail.GlancesMax or 0), petDetail.GlancesMax)
	end
	if petDetail.HitsMin then
		ownerDetail.HitsMin = Recap_Min(ownerDetail.HitsMin, petDetail.HitsMin)
	end
	if petDetail.CritsMin then
		ownerDetail.CritsMin = Recap_Min(ownerDetail.CritsMin, petDetail.CritsMin)
	end
	if petDetail.TicksMin then
		ownerDetail.TicksMin = Recap_Min(ownerDetail.TicksMin, petDetail.TicksMin)
	end
	if petDetail.GlancesMin then
		ownerDetail.GlancesMin = Recap_Min(ownerDetail.GlancesMin, petDetail.GlancesMin)
	end
	if petDetail.Crushes then
		ownerDetail.Crushes = (ownerDetail.Crushes or 0) + petDetail.Crushes
	end
	if petDetail.CrushDmg then
		ownerDetail.Hits = (ownerDetail.CrushDmg or 0) + petDetail.CrushDmg
	end
	if petDetail.CrushMax then
		ownerDetail.CrushMax = math_max((ownerDetail.CrushMax or 0), petDetail.CrushMax)
	end
	if petDetail.CrushMin then
		ownerDetail.CrushMin = Recap_Min(ownerDetail.CrushMin, petDetail.CrushMin)
	end
	if petDetail.PAbsorbs then
		ownerDetail.PAbsorbs = (ownerDetail.PAbsorbs or 0) + petDetail.PAbsorbs
	end
	if petDetail.PAbsorbsDmg then
		ownerDetail.PAbsorbsDmg = (ownerDetail.PAbsorbsDmg or 0) + petDetail.PAbsorbsDmg
	end
	if petDetail.PBlocks then
		ownerDetail.PBlocks = (ownerDetail.PBlocks or 0) + petDetail.PBlocks
	end
	if petDetail.PBlocksDmg then
		ownerDetail.PBlocksDmg = (ownerDetail.PBlocksDmg or 0) + petDetail.PBlocksDmg
	end
	if petDetail.PResists then
		ownerDetail.PResists = (ownerDetail.PResists or 0) + petDetail.PResists
	end
	if petDetail.PResistsDmg then
		ownerDetail.PResistsDmg = (ownerDetail.PResistsDmg or 0) + petDetail.PResistsDmg
	end
	if petDetail.PResistsRaw then
		ownerDetail.PResistsRaw = (ownerDetail.PResistsRaw or 0) + petDetail.PResistsRaw
	end
	if petDetail.EstResistedDmg then
		ownerDetail.EstResistedDmg = (ownerDetail.EstResistedDmg or 0) + petDetail.EstResistedDmg
	end
	if petDetail.EstResistableDmg then
		ownerDetail.EstResistableDmg = (ownerDetail.EstResistableDmg or 0) + petDetail.EstResistableDmg
	end
end

local function Recap_AmalgamatePetOtherDetails(ownerDetail, petDetail)
	if petDetail.Hits then
		ownerDetail.Hits = (ownerDetail.Hits or 0) + petDetail.Hits
	end
	if petDetail.Total then
		ownerDetail.Total = (ownerDetail.Total or 0) + petDetail.Total
	end
	if petDetail.Max then
		ownerDetail.Max = math_max((ownerDetail.Max or 0), petDetail.Max)
	end
	if petDetail.Attribute and not ownerDetail.Attribute then
		-- we arbitrarily assume that there is only one possible Attribute for this effect
		ownerDetail.Attribute = petDetail.Attribute
	end
	if petDetail.Missed then
		ownerDetail.Missed = (ownerDetail.Missed or 0) + petDetail.Missed
	end
	if petDetail.Dispels then
		ownerDetail.Dispels = (ownerDetail.Dispels or 0) + petDetail.Dispels
	end
	if petDetail.Steals then
		ownerDetail.Steals = (ownerDetail.Steals or 0) + petDetail.Steals
	end
	if petDetail.ICount then
		ownerDetail.ICount = (ownerDetail.ICount or 0) + petDetail.ICount
	end
	if petDetail.ITotal then
		ownerDetail.ITotal = (ownerDetail.ITotal or 0) + petDetail.ITotal
	end
	if petDetail.DCount then
		ownerDetail.DCount = (ownerDetail.DCount or 0) + petDetail.DCount
	end
	if petDetail.DTotal then
		ownerDetail.DTotal = (ownerDetail.DTotal or 0) + petDetail.DTotal
	end
end

-- that the format of thisPet is "owner:owner:pet" or "owner:pet"
-- we are always adding from the pet last fight to the owner
local function Recap_CreateBlankOwnerForPet(owner, seen)
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	Recap_CreateBlankCombatant(owner, seen, nil)
	if not rTemp.Last[owner] then
		Recap_InitializeLastFight(owner)
	end
	return rCombatants[owner]
end
local function Recap_AddPetDetailsToOwner(thisPet, thisOwner, ownerAllLastOutgoingDetail, ownerAllLastIncomingDetail, ownerAllLastOtherDetail, ownerAllLastTargetDetail, ownerAllLastSourceDetail,
										  petAllLastOutgoingDetail, petAllLastIncomingDetail, petAllLastOtherDetail, petAllLastTargetDetail, petAllLastSourceDetail)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i
	local petEffect
	local iType, iEffect, iTarget, iSource
	local petDetail, ownerDetail
	local combatantPet = rCombatants[thisPet]
	local combatantOwner = rCombatants[thisOwner]
	local slimPet

	if not combatantPet then
		return
	end

	-- name adjustments
	if rOpt.MergeAllPetsIntoOne.value then
		-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
		slimPet = Recap_ExtractOwners(Recap_StripGUIDsFromCombatant(thisPet))..":"..rLocalize.ClassName.Pet
	else
		if combatantPet.DKRaiseDead then
			-- special name in Details panel for death knight ghouls summoned using Raise Dead
			slimPet = Recap_ExtractOwners(Recap_StripGUIDsFromCombatant(thisPet))..":"..rLocalize.GhoulMinion
		else
			slimPet = Recap_StripGUIDsFromCombatant(thisPet)
		end
	end

	if not rOpt.LightData.value then
		if combatantPet[petAllLastOutgoingDetail] then
			for i, petDetail in pairs(combatantPet[petAllLastOutgoingDetail]) do
				iType = tonumber(string_sub(i,1,1))
				iEffect = string_sub(i,2)
				petEffect = tostring(iType+1)..slimPet..": "..iEffect
				if not combatantOwner then
					combatantOwner = Recap_CreateBlankOwnerForPet(thisOwner, combatantPet.Seen)
				end
				if not combatantOwner[ownerAllLastOutgoingDetail] then
					combatantOwner[ownerAllLastOutgoingDetail] = {}
				end
				if not combatantOwner[ownerAllLastOutgoingDetail][petEffect] then
					combatantOwner[ownerAllLastOutgoingDetail][petEffect] = {}
				end
				ownerDetail = combatantOwner[ownerAllLastOutgoingDetail][petEffect]
				Recap_AmalgamatePetIncomingOutgoingDetails(ownerDetail, petDetail)
				ownerDetail.Effect = iEffect -- new with 4.36, to support Recent effects
			end
		end

		if rOpt.MatrixData.value then
			if combatantPet[petAllLastTargetDetail] then
				for i, petDetail in pairs(combatantPet[petAllLastTargetDetail]) do
					iType = tonumber(string_sub(i,1,1))
					iTarget = tostring(iType+1)..string_sub(i,2)
					if not combatantOwner then
						combatantOwner = Recap_CreateBlankOwnerForPet(thisOwner, combatantPet.Seen)
					end
					if petDetail and petDetail.Total and (petDetail.Total > 0) then
						if not combatantOwner[ownerAllLastTargetDetail] then
							combatantOwner[ownerAllLastTargetDetail] = {}
						end
						if not combatantOwner[ownerAllLastTargetDetail][iTarget] then
							combatantOwner[ownerAllLastTargetDetail][iTarget] = {}
						end
						ownerDetail = combatantOwner[ownerAllLastTargetDetail][iTarget]
						-- with GUIDs off, a pet named 'Total' will be incorporated into the owner's details
						ownerDetail[slimPet] = (ownerDetail[slimPet] or 0) + petDetail.Total
					end
				end
			end
		end

		if combatantPet[petAllLastIncomingDetail] then
			for i, petDetail in pairs(combatantPet[petAllLastIncomingDetail]) do
				iType = tonumber(string_sub(i,1,1))
				iEffect = string_sub(i,2)
				petEffect = tostring(iType+1)..slimPet..": "..iEffect
				if not combatantOwner then
					combatantOwner = Recap_CreateBlankOwnerForPet(thisOwner, combatantPet.Seen)
				end
				if not combatantOwner[ownerAllLastIncomingDetail] then
					combatantOwner[ownerAllLastIncomingDetail] = {}
				end
				if not combatantOwner[ownerAllLastIncomingDetail][petEffect] then
					combatantOwner[ownerAllLastIncomingDetail][petEffect] = {}
				end
				ownerDetail = combatantOwner[ownerAllLastIncomingDetail][petEffect]
				Recap_AmalgamatePetIncomingOutgoingDetails(ownerDetail, petDetail)
				ownerDetail.Effect = iEffect -- new with 4.36, to support Recent effects
			end
		end

		if rOpt.MatrixData.value then
			if combatantPet[petAllLastSourceDetail] then
				for i, petDetail in pairs(combatantPet[petAllLastSourceDetail]) do
					iType = tonumber(string_sub(i,1,1))
					iSource = tostring(iType+1)..string_sub(i,2)
					if not combatantOwner then
						combatantOwner = Recap_CreateBlankOwnerForPet(thisOwner, combatantPet.Seen)
					end
					if petDetail and petDetail.Total and (petDetail.Total > 0) then
						if not combatantOwner[ownerAllLastSourceDetail] then
							combatantOwner[ownerAllLastSourceDetail] = {}
						end
						if not combatantOwner[ownerAllLastSourceDetail][iSource] then
							combatantOwner[ownerAllLastSourceDetail][iSource] = {}
						end
						ownerDetail = combatantOwner[ownerAllLastSourceDetail][iSource]
						-- with GUIDs off, a pet named 'Total' will be incorporated into the owner's details
						ownerDetail[slimPet] = (ownerDetail[slimPet] or 0) + petDetail.Total
					end
				end
			end
		end

		if rOpt.OtherData.value then
			if combatantPet[petAllLastOtherDetail] then
				for i, petDetail in pairs(combatantPet[petAllLastOtherDetail]) do
					iType = tonumber(string_sub(i,1,1))
					iEffect = string_sub(i,2)
					petEffect = tostring(iType+1)..slimPet..": "..iEffect
					if not combatantOwner then
						combatantOwner = Recap_CreateBlankOwnerForPet(thisOwner, combatantPet.Seen)
					end
					if not combatantOwner[ownerAllLastOtherDetail] then
						combatantOwner[ownerAllLastOtherDetail] = {}
					end
					if not combatantOwner[ownerAllLastOtherDetail][petEffect] then
						combatantOwner[ownerAllLastOtherDetail][petEffect] = {}
					end
					ownerDetail = combatantOwner[ownerAllLastOtherDetail][petEffect]
					Recap_AmalgamatePetOtherDetails(ownerDetail, petDetail)
				end
			end
		end
	end
end

-- clear all of the effect interval timers, since intervals are only meaningful when measured within a single fight
-- the effect duration timers, however, are not reset, since the effects can last between fights
-- but they are for the Last details
local function Recap_ClearEffectIntervalTimers()

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, j, iCombatant

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			if iCombatant.OutgoingDetail then
				for j in pairs(iCombatant.OutgoingDetail) do
					if iCombatant.OutgoingDetail[j].PrevTime then
						iCombatant.OutgoingDetail[j].PrevTime = nil
					end
				end
			end
			if iCombatant.IncomingDetail then
				for j in pairs(iCombatant.IncomingDetail) do
					if iCombatant.IncomingDetail[j].PrevTime then
						iCombatant.IncomingDetail[j].PrevTime = nil
					end
				end
			end
			if iCombatant.OtherDetail then
				for j in pairs(iCombatant.OtherDetail) do
					if iCombatant.OtherDetail[j].PrevTime then
						iCombatant.OtherDetail[j].PrevTime = nil
					end
				end
			end
			if iCombatant.LastOutgoingDetail_1 then
				for j in pairs(iCombatant.LastOutgoingDetail_1) do
					if iCombatant.LastOutgoingDetail_1[j].PrevTime then
						iCombatant.LastOutgoingDetail_1[j].PrevTime = nil
						iCombatant.LastOutgoingDetail_1[j].PrevTimeDur = nil
					end
				end
			end
			if iCombatant.LastIncomingDetail_1 then
				for j in pairs(iCombatant.LastIncomingDetail_1) do
					if iCombatant.LastIncomingDetail_1[j].PrevTime then
						iCombatant.LastIncomingDetail_1[j].PrevTime = nil
						iCombatant.LastIncomingDetail_1[j].PrevTimeDur = nil
					end
				end
			end
			if iCombatant.LastOtherDetail_1 then
				for j in pairs(iCombatant.LastOtherDetail_1) do
					if iCombatant.LastOtherDetail_1[j].PrevTime then
						iCombatant.LastOtherDetail_1[j].PrevTime = nil
						iCombatant.LastOtherDetail_1[j].PrevTimeDur = nil
					end
				end
			end
			if iCombatant.LastOutgoingDetail_2 then
				for j in pairs(iCombatant.LastOutgoingDetail_2) do
					if iCombatant.LastOutgoingDetail_2[j].PrevTime then
						iCombatant.LastOutgoingDetail_2[j].PrevTime = nil
						iCombatant.LastOutgoingDetail_2[j].PrevTimeDur = nil
					end
				end
			end
			if iCombatant.LastIncomingDetail_2 then
				for j in pairs(iCombatant.LastIncomingDetail_2) do
					if iCombatant.LastIncomingDetail_2[j].PrevTime then
						iCombatant.LastIncomingDetail_2[j].PrevTime = nil
						iCombatant.LastIncomingDetail_2[j].PrevTimeDur = nil
					end
				end
			end
			if iCombatant.LastOtherDetail_2 then
				for j in pairs(iCombatant.LastOtherDetail_2) do
					if iCombatant.LastOtherDetail_2[j].PrevTime then
						iCombatant.LastOtherDetail_2[j].PrevTime = nil
						iCombatant.LastOtherDetail_2[j].PrevTimeDur = nil
					end
				end
			end
		end
	end
end

-- we don't track the Outgoing component of damage that is from one group member to another group member (otherwise would inflate DPS)
-- this includes not tracking, for example, Shatter damage in Gruul's Lair
-- this includes not tracking self-damage (e.g. Shadow Word: Death) and damage from owner to pet (e.g. Soul Link) (both of these whether the combatant is in the group or not)
local function Recap_TrackAsOutgoing(sourceNameGUID, destNameGUID)
	local rTemp = _G.recap_temp
	-- check for self-damage
	if sourceNameGUID == destNameGUID then
		-- ignore if self-damage (whether in group or not)
		return false
	end
	-- check for group <=> group damage
	if rTemp.InGroup[sourceNameGUID] and rTemp.InGroup[destNameGUID] then
		-- ignore if both combatants are in the group (for most group pets this is faster than checking the pet the hard way)
		-- note that damage between combatants who are not in the group, but who could be allied with each other, is still counted, potentially inflating *their* DPS
		return false
	end
	-- check for owner <=> pet damage the hard way
	local sourceOwner = Recap_ExtractOwner(sourceNameGUID)
	local destOwner = Recap_ExtractOwner(destNameGUID)
	if (sourceOwner and (sourceOwner == Recap_ExtractCombatant(destNameGUID))) or (destOwner and (destOwner == Recap_ExtractCombatant(sourceNameGUID))) then
		-- ignore if source is controlled by dest, or dest is controlled by source (whether in group or not)
		return false
	end
	-- no contra-indications
	return true
end

-- six auxiliary functions for Recap_CreateEffect to create spots in the tables as necessary
local function Recap_MakeIncomingDetail(iCombatant, typeEffect, AllLastIncomingDetail)
	if not iCombatant[AllLastIncomingDetail] then
		iCombatant[AllLastIncomingDetail] = {}
	end
	if not iCombatant[AllLastIncomingDetail][typeEffect] then
		iCombatant[AllLastIncomingDetail][typeEffect] = {}
	end
end

local function Recap_MakeOutgoingDetail(iCombatant, typeEffect, AllLastOutgoingDetail)
-- TODO something comes in here as nil
	if not iCombatant[AllLastOutgoingDetail] then
		iCombatant[AllLastOutgoingDetail] = {}
	end
	if not iCombatant[AllLastOutgoingDetail][typeEffect] then
		iCombatant[AllLastOutgoingDetail][typeEffect] = {}
	end
end

local function Recap_MakeSelfDetail(selfIndex, typeEffect)
	local rSelf = _G.recap.Self
	if not rSelf[selfIndex] then
		rSelf[selfIndex] = {}
	end
	if not rSelf[selfIndex][typeEffect] then
		rSelf[selfIndex][typeEffect] = {}
	end
end

local function Recap_AddCrits(iEffect, total)
	iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
	iEffect.Crits = (iEffect.Crits or 0) + 1
	iEffect.CritsDmg = (iEffect.CritsDmg or 0) + total
	iEffect.CritsMax = math_max(total, iEffect.CritsMax or 0)
	iEffect.CritsMin = Recap_Min(total, iEffect.CritsMin)
end

local function Recap_AddCrushes(iEffect, total)
	iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
	iEffect.Crushes = (iEffect.Crushes or 0) + 1
	iEffect.CrushDmg = (iEffect.CrushDmg or 0) + total
	iEffect.CrushMax = math_max(total, iEffect.CrushMax or 0)
	iEffect.CrushMin = Recap_Min(total, iEffect.CrushMin)
end

local function Recap_AddGlances(iEffect, total)
	iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
	iEffect.Glances = (iEffect.Glances or 0) + 1
	iEffect.GlancesDmg = (iEffect.GlancesDmg or 0) + total
	iEffect.GlancesMax = math_max(total, iEffect.GlancesMax or 0)
	iEffect.GlancesMin = Recap_Min(total, iEffect.GlancesMin)
end

local function Recap_AddHits(iEffect, total)
	iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
	iEffect.Hits = (iEffect.Hits or 0) + 1
	iEffect.HitsDmg = (iEffect.HitsDmg or 0) + total
	iEffect.HitsMax = math_max(total, iEffect.HitsMax or 0)
	iEffect.HitsMin = Recap_Min(total, iEffect.HitsMin)
end

local function Recap_AddTicks(iEffect, total, did_periodic_crit)
	iEffect.Ticks = (iEffect.Ticks or 0) + 1
	if (did_periodic_crit == 1) then
		iEffect.CritTicks = (iEffect.CritTicks or 0) + 1
	end
	iEffect.TicksDmg = (iEffect.TicksDmg or 0) + total
	iEffect.TicksMax = math_max(total, iEffect.TicksMax or 0)
	iEffect.TicksMin = Recap_Min(total, iEffect.TicksMin)
end

local function Recap_AddOverhealing(iEffect, overhealing)
	if overhealing > 0 then
		-- reuse .Missed detail to store overhealing since heals never miss
		iEffect.Missed = (iEffect.Missed or 0) + overhealing
	end
end

local function Recap_AddMisses(iEffect, missType)
	if (missType == "MISS") then
		iEffect.Missed = (iEffect.Missed or 0) + 1
	elseif (missType == "ABSORB") then
		iEffect.Absorbed = (iEffect.Absorbed or 0) + 1
	elseif (missType == "DODGE") then
		iEffect.Dodged = (iEffect.Dodged or 0) + 1
	elseif (missType == "PARRY") then
		iEffect.Parried = (iEffect.Parried or 0) + 1
	elseif (missType == "BLOCK") then
		iEffect.Blocked = (iEffect.Blocked or 0) + 1
	elseif (missType == "DEFLECT") then
		iEffect.Deflected = (iEffect.Deflected or 0) + 1
	elseif (missType == "EVADE") then
		iEffect.Evaded = (iEffect.Evaded or 0) + 1
	elseif (missType == "RESIST") then
		iEffect.Resisted = (iEffect.Resisted or 0) + 1
	elseif (missType == "REFLECT") then
		iEffect.Reflected = (iEffect.Reflected or 0) + 1
	elseif (missType == "IMMUNE") then
		iEffect.Immune = (iEffect.Immune or 0) + 1
	end
end

local function Recap_AddElement(iEffect, element)
	if not iEffect.Element then
		-- no element yet, set it
		iEffect.Element = element
	else
		-- if there is a new element that is not 'Other', check whether the new and old elements are the same
		if element and (element ~= rLocalize.ElementOther) then
			if not string_find(iEffect.Element, element, 1, true) then
				-- new element not found in old element, append it
				-- for example, perhaps the combatant switched wands
				if (iEffect.Element == "?") or (iEffect.Element == rLocalize.ElementOther) then
					-- replace a "?" or "Other"
					iEffect.Element = element
				else
					-- append to anything else
					iEffect.Element = iEffect.Element.."+"..element
				end
			end
		end
	end
end

local function Recap_AddSpellID(iEffect, spellID)
	if spellID then
		if not iEffect.SpellID then
			-- no spellID yet, set it
			iEffect.SpellID = tostring(spellID)
		else
			-- check whether the new and old spellIDs are the same
			if not string_find(iEffect.SpellID, tostring(spellID), 1, true) then
				-- new spellID not found in old spellID, append it
				iEffect.SpellID = iEffect.SpellID.."+"..tostring(spellID)
			end
		end
	end
end

local function Recap_AddPartials(iEffect, total, absorb, block, resist)

	if absorb and absorb>0 then
		iEffect.PAbsorbs = (iEffect.PAbsorbs or 0) + 1
		iEffect.PAbsorbsDmg = (iEffect.PAbsorbsDmg or 0) + absorb
	end
	if block and block>0 then
		iEffect.PBlocks = (iEffect.PBlocks or 0) + 1
		iEffect.PBlocksDmg = (iEffect.PBlocksDmg or 0) + block
	end
	if resist and resist>0 then
		-- track only the average partial resistance
		iEffect.PResists = (iEffect.PResists or 0) + 1
		iEffect.PResistsDmg = (iEffect.PResistsDmg or 0) + resist
		iEffect.PResistsRaw = (iEffect.PResistsRaw or 0) + resist + total
	end
end

-- function returns two values (delta resisted damage and delta resistable damage) for accumulation into subtotals and totals
local function Recap_CalcEstimatedResistance(iEffect) -- this is for an effect other than a subtotal or total

	local PartialResistedDmg, PartialPreventedDmg, LandedDmg, Landings, CompletelyResistedDmg
	local EstimatedResistedDmg, EstimatedResistableDmg, DeltaEstimatedResistedDmg, DeltaEstimatedResistableDmg

	PartialResistedDmg = (iEffect.PResistsDmg or 0)
	PartialPreventedDmg = (iEffect.PAbsorbsDmg or 0)+(iEffect.PBlocksDmg or 0)+PartialResistedDmg
	LandedDmg = (iEffect.GlancesDmg or 0)+(iEffect.HitsDmg or 0)+(iEffect.CritsDmg or 0)+(iEffect.CrushDmg or 0)+(iEffect.TicksDmg or 0)+PartialPreventedDmg
	-- if this effect has an initial hit plus a DoT, we count only the initial hits and assume that all complete resists are of initial hits
	Landings = (iEffect.Glances or 0)+(iEffect.Hits or 0)+(iEffect.Crits or 0)+(iEffect.Crushes or 0)
	if (Landings == 0) then
		-- if this effect has ticks only, use that count instead
		Landings = (iEffect.Ticks or 0)
	end
	if (Landings == 0) then
		-- we have only complete resists, and so cannot determine meaningful resisted and resistable values
		return 0, 0
	end
	-- this is an estimate only, we cannot know what the hits would have been if not completely resisted
	CompletelyResistedDmg = (iEffect.Resisted or 0) * Recap_Div0(LandedDmg, Landings)

	-- we can calculate resisted and resistable for the effect
	-- we cannot do that for a subtotal or total
	-- instead we pass back deltas (which could go negative) and accumulate them for the subtotal or total
	EstimatedResistedDmg = PartialResistedDmg + CompletelyResistedDmg
	EstimatedResistableDmg = LandedDmg + CompletelyResistedDmg
	DeltaEstimatedResistedDmg = EstimatedResistedDmg - (iEffect.EstResistedDmg or 0)
	DeltaEstimatedResistableDmg = EstimatedResistableDmg - (iEffect.EstResistableDmg or 0)
	-- estimated resisted is a visible column, estimated resistable is a hidden column
	-- only write if non-zero
	if EstimatedResistedDmg > 0 then
		iEffect.EstResistedDmg = EstimatedResistedDmg
	end
	if EstimatedResistableDmg > 0 then
		iEffect.EstResistableDmg = EstimatedResistableDmg
	end

	return DeltaEstimatedResistedDmg, DeltaEstimatedResistableDmg
end

-- for subtotals and totals
local function Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
	-- the deltas could go negative
	if not (deltaEstResisted == 0) then
		iEffect.EstResistedDmg = (iEffect.EstResistedDmg or 0) + deltaEstResisted
	end
	if not (deltaEstResistable == 0) then
		iEffect.EstResistableDmg = (iEffect.EstResistableDmg or 0) + deltaEstResistable
	end
end

local function Recap_CalcInterval(iEffect, eventTime)
	if iEffect.PrevTime and (iEffect.PrevTime > 0) then
		local delta_time = (1000 * eventTime) - (iEffect.PrevTime or 0)
		if (delta_time > 0) and (delta_time < 130000) then
			-- only pay attention if the two events happened less than 130 seconds apart
			-- count the number of time deltas, and sum their values (will be used to produce an average)
			iEffect.ICount = (iEffect.ICount or 0) + 1
			iEffect.ITotal = (iEffect.ITotal or 0) + delta_time
		end
	end
	iEffect.PrevTime = (1000 * eventTime)
end

local function Recap_AddSelfElement(iEffect, element)
	if not iEffect.Element then
		-- no element yet, set it
		iEffect.Element = element
	else
		-- if there is a new element that is not 'Other', check whether the new and old elements are the same
		if element and (element ~= rLocalize.ElementOther) then
			if not string_find(iEffect.Element, element, 1, true) then
				-- new element not found in old element, append it
				-- for example, perhaps the combatant switched wands
				if (iEffect.Element == "?") or (iEffect.Element == rLocalize.ElementOther) then
					-- replace a "?" or "Other"
					iEffect.Element = element
				else
					-- append to anything else
					iEffect.Element = iEffect.Element.."+"..element
				end
			end
		end
	end
end

local function Recap_CreateEffect(eventTime, sourceNameGUID, destNameGUID, effect, spellID, myType, total, overheal, did_crit, is_dot, element, missType, did_crush, did_glance, did_periodic_crit, absorb, block, resist, doSelf, AllLastOutgoingDetail, AllLastIncomingDetail)

	local rRecap = _G.recap
	local rSelf = _G.recap.Self
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, iEffect, sourceCombatant, destCombatant, typeEffect, myElement, elementEffect, selfIndex, trackAsOutgoing, damageEffect, deltaEstResisted, deltaEstResistable

	-- parameter is_dot is not currently used (will be 1 or nil)

	if not effect then
		return
	end

	-- table lookup shortcuts
	if sourceNameGUID then
		sourceCombatant = rCombatants[sourceNameGUID]
	else
		sourceCombatant = nil
	end
	if destNameGUID then
		destCombatant = rCombatants[destNameGUID]
	else
		destCombatant = nil
	end

	if total then
		total = Recap_Round0(total) -- paranoia 5.0.4
	end
	if overheal then
		overheal = Recap_Round0(overheal) -- paranoia 5.0.4
	end
	if absorb then
		absorb = Recap_Round0(absorb) -- paranoia 5.0.4
	end
	if block then
		block = Recap_Round0(block) -- paranoia 5.0.4
	end
	if resist then
		resist = Recap_Round0(resist) -- paranoia 5.0.4
	end

	typeEffect = myType..effect

	-- some misses will get here with Other or "?" as the element
	myElement = element
	if missType and ((myElement == rLocalize.ElementOther) or (myElement == "?")) then
		-- if so attempt a correction by looking for a non-default element in the corresponding Outgoing effect
		if sourceCombatant and sourceCombatant[AllLastOutgoingDetail] and sourceCombatant[AllLastOutgoingDetail]["1"..effect] and sourceCombatant[AllLastOutgoingDetail]["1"..effect].Element then
			for i in string_gmatch(sourceCombatant[AllLastOutgoingDetail]["1"..effect].Element, "[^%+]+") do
				if (i ~= rLocalize.ElementOther) and (i ~= "?") then
					myElement = i
					break
				end
			end
		end
		-- if still Other or "?" then check among the corresponding Incoming effects
		if (myElement == rLocalize.ElementOther) or (myElement == "?") then
			if destCombatant and destCombatant[AllLastIncomingDetail] and destCombatant[AllLastIncomingDetail]["1"..effect] and destCombatant[AllLastIncomingDetail]["1"..effect].Element then
				for i in string_gmatch(destCombatant[AllLastIncomingDetail]["1"..effect].Element, "[^%+]+") do
					if (i ~= rLocalize.ElementOther) and (i ~= "?") then
						myElement = i
						break
					end
				end
			end
		end
		-- if still "?" then force to Other
		if myElement == "?" then
			myElement = rLocalize.ElementOther
		end
	end

	-- prepare for subtotals and totals
	if myType == 1 then
		-- keep element subtotals separate for damage and healing
		elementEffect = "5"..rLocalize.Subtotal..": "..myElement
		-- overall damage total
		damageEffect = "7"..rLocalize.Total..": "..rLocalize.Damage
	elseif myType == 3 then
		-- overall healing total
		elementEffect = "7"..rLocalize.Total..": "..rLocalize.ElementHealing
	end

	-- is the sourceNameGUID the player or one of the player's pets?
	selfIndex = nil -- keep as nil
	if sourceNameGUID then
		if sourceNameGUID == rTemp.PlayerGUID then
			selfIndex = rTemp.s
		elseif Recap_IsOwnedBy(sourceNameGUID, rTemp.PlayerGUID) then
			-- name adjustments
			if Recap_PetsMerged() and rOpt.MergeAllPetsIntoOne.value then
				-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
				selfIndex = rTemp.s..":"..rLocalize.ClassName.Pet
			else
				if Recap_PetsMerged() and sourceCombatant and sourceCombatant.DKRaiseDead then
					-- special name in Self panel for death knight ghouls summoned using Raise Dead (only if pets are merged)
					selfIndex = rTemp.s..":"..rLocalize.GhoulMinion
				else
					selfIndex = rTemp.s..":"..Recap_NameOnlyFromCombatant(sourceNameGUID)
				end
			end
		end
	end

	-- we don't track the Outgoing component of some damage (self-damage, damage between owner and pet, and damage from one group member to another group member) (otherwise would inflate DPS)
	-- we still track the Incoming component and (elsewhere) the Matrix component
	trackAsOutgoing = true
	if (myType == 1) and sourceNameGUID and destNameGUID then
		trackAsOutgoing = Recap_TrackAsOutgoing(sourceNameGUID, destNameGUID)
	end

	-- main processing block
	if (did_crit==1) then
		if sourceNameGUID and trackAsOutgoing then
			Recap_MakeOutgoingDetail(sourceCombatant, typeEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddCrits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, elementEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][elementEffect]
			Recap_AddCrits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeOutgoingDetail(sourceCombatant, damageEffect, AllLastOutgoingDetail)
				iEffect = sourceCombatant[AllLastOutgoingDetail][damageEffect]
				Recap_AddCrits(iEffect, total)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end

			-- only add when adding to AllFights (otherwise counts twice)
			if selfIndex and doSelf then
				Recap_MakeSelfDetail(selfIndex, typeEffect)
				iEffect = rSelf[selfIndex][typeEffect]
				iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
				iEffect.Crits = (iEffect.Crits or 0) + 1
				iEffect.CritsDmg = (iEffect.CritsDmg or 0) + total
				iEffect.CritsMax = math_max(total, iEffect.CritsMax or 0)
				if rRecap.gmin then
					-- for the cognoscenti, factor back in any partials to get a gross minimum
					iEffect.CritsMin = Recap_Min(total+(absorb or 0)+(block or 0)+(resist or 0),iEffect.CritsMin)
				else
					-- normal net minimum
					iEffect.CritsMin = Recap_Min(total,iEffect.CritsMin)
				end
				Recap_AddSelfElement(iEffect, myElement)
			end
		end
		if destCombatant then
			Recap_MakeIncomingDetail(destCombatant, typeEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddCrits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeIncomingDetail(destCombatant, elementEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][elementEffect]
			Recap_AddCrits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeIncomingDetail(destCombatant, damageEffect, AllLastIncomingDetail)
				iEffect = destCombatant[AllLastIncomingDetail][damageEffect]
				Recap_AddCrits(iEffect, total)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end
		end
	elseif (did_crush==1) then
		if sourceNameGUID and trackAsOutgoing then
			Recap_MakeOutgoingDetail(sourceCombatant, typeEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddCrushes(iEffect, total)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, elementEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][elementEffect]
			Recap_AddCrushes(iEffect, total)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			-- damage subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, damageEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][damageEffect]
			Recap_AddCrushes(iEffect, total)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)

			-- self and pets can never crush, so there is nothing done with Self
		end
		if destCombatant then
			Recap_MakeIncomingDetail(destCombatant, typeEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddCrushes(iEffect, total)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeIncomingDetail(destCombatant, elementEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][elementEffect]
			Recap_AddCrushes(iEffect, total)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeIncomingDetail(destCombatant, damageEffect, AllLastIncomingDetail)
				iEffect = destCombatant[AllLastIncomingDetail][damageEffect]
				Recap_AddCrushes(iEffect, total)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end
		end
	elseif (did_glance==1) then
		if sourceNameGUID and trackAsOutgoing then
			Recap_MakeOutgoingDetail(sourceCombatant, typeEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddGlances(iEffect, total)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, elementEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][elementEffect]
			Recap_AddGlances(iEffect, total)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			-- damage subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, damageEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][damageEffect]
			Recap_AddGlances(iEffect, total)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)

			-- only add when adding to AllFights (otherwise counts twice)
			if selfIndex and doSelf then
				Recap_MakeSelfDetail(selfIndex, typeEffect)
				iEffect = rSelf[selfIndex][typeEffect]
				iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
				iEffect.Glances = (iEffect.Glances or 0) + 1
				iEffect.GlancesDmg = (iEffect.GlancesDmg or 0) + total
				iEffect.GlancesMax = math_max(total, iEffect.GlancesMax or 0)
				if rRecap.gmin then
					-- for the cognoscenti, factor back in any partials to get a gross minimum
					iEffect.GlancesMin = Recap_Min(total+(absorb or 0)+(block or 0)+(resist or 0),iEffect.GlancesMin)
				else
					-- normal net minimum
					iEffect.GlancesMin = Recap_Min(total,iEffect.GlancesMin)
				end
				Recap_AddSelfElement(iEffect, myElement)
			end
		end
		if destCombatant then
			Recap_MakeIncomingDetail(destCombatant, typeEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddGlances(iEffect, total)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeIncomingDetail(destCombatant, elementEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][elementEffect]
			Recap_AddGlances(iEffect, total)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeIncomingDetail(destCombatant, damageEffect, AllLastIncomingDetail)
				iEffect = destCombatant[AllLastIncomingDetail][damageEffect]
				Recap_AddGlances(iEffect, total)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end
		end
	elseif (did_crit==false) and (did_crush==false) and (did_glance==false) then
		-- hit that could have critted (does not include misses, so that crit percentages are accurate)
		if sourceNameGUID and trackAsOutgoing then
			Recap_MakeOutgoingDetail(sourceCombatant, typeEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddHits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, elementEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][elementEffect]
			Recap_AddHits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeOutgoingDetail(sourceCombatant, damageEffect, AllLastOutgoingDetail)
				iEffect = sourceCombatant[AllLastOutgoingDetail][damageEffect]
				Recap_AddHits(iEffect, total)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end

			-- only add when adding to AllFights (otherwise counts twice)
			if selfIndex and doSelf then
				Recap_MakeSelfDetail(selfIndex, typeEffect)
				iEffect = rSelf[selfIndex][typeEffect]
				iEffect.CritsEvents = (iEffect.CritsEvents or 0) + 1
				iEffect.Hits = (iEffect.Hits or 0) + 1
				iEffect.HitsDmg = (iEffect.HitsDmg or 0) + total
				iEffect.HitsMax = math_max(total, iEffect.HitsMax or 0)
				if rRecap.gmin then
					-- for the cognoscenti, factor back in any partials to get a gross minimum
					iEffect.HitsMin = Recap_Min(total+(absorb or 0)+(block or 0)+(resist or 0),iEffect.HitsMin)
				else
					-- normal net minimum
					iEffect.HitsMin = Recap_Min(total,iEffect.HitsMin)
				end
				Recap_AddSelfElement(iEffect, myElement)
			end
		end
		if destCombatant then
			Recap_MakeIncomingDetail(destCombatant, typeEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddHits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeIncomingDetail(destCombatant, elementEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][elementEffect]
			Recap_AddHits(iEffect, total)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeIncomingDetail(destCombatant, damageEffect, AllLastIncomingDetail)
				iEffect = destCombatant[AllLastIncomingDetail][damageEffect]
				Recap_AddHits(iEffect, total)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end
		end
	elseif (total==0) then
		-- miss
		if sourceNameGUID and trackAsOutgoing then
			Recap_MakeOutgoingDetail(sourceCombatant, typeEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddMisses(iEffect, missType)
			Recap_AddElement(iEffect, myElement)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, elementEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][elementEffect]
			Recap_AddMisses(iEffect, missType)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			-- damage subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, damageEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][damageEffect]
			Recap_AddMisses(iEffect, missType)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)

			-- only add when adding to AllFights (otherwise counts twice)
			if selfIndex and doSelf then
				Recap_MakeSelfDetail(selfIndex, typeEffect)
				iEffect = rSelf[selfIndex][typeEffect]
				if (missType == "MISS") then
					iEffect.Missed = (iEffect.Missed or 0) + 1
				elseif (missType == "ABSORB") then
					iEffect.Absorbed = (iEffect.Absorbed or 0) + 1
				elseif (missType == "DODGE") then
					iEffect.Dodged = (iEffect.Dodged or 0) + 1
				elseif (missType == "PARRY") then
					iEffect.Parried = (iEffect.Parried or 0) + 1
				elseif (missType == "BLOCK") then
					iEffect.Blocked = (iEffect.Blocked or 0) + 1
				elseif (missType == "DEFLECT") then
					iEffect.Deflected = (iEffect.Deflected or 0) + 1
				elseif (missType == "EVADE") then
					iEffect.Evaded = (iEffect.Evaded or 0) + 1
				elseif (missType == "RESIST") then
					iEffect.Resisted = (iEffect.Resisted or 0) + 1
				elseif (missType == "REFLECT") then
					iEffect.Reflected = (iEffect.Reflected or 0) + 1
				elseif (missType == "IMMUNE") then
					iEffect.Immune = (iEffect.Immune or 0) + 1
				end
				Recap_AddSelfElement(iEffect, myElement)
			end
		end
		if destCombatant then
			Recap_MakeIncomingDetail(destCombatant, typeEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddMisses(iEffect, missType)
			Recap_AddElement(iEffect, myElement)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeIncomingDetail(destCombatant, elementEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][elementEffect]
			Recap_AddMisses(iEffect, missType)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeIncomingDetail(destCombatant, damageEffect, AllLastIncomingDetail)
				iEffect = destCombatant[AllLastIncomingDetail][damageEffect]
				Recap_AddMisses(iEffect, missType)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end
		end
	else
		-- hit that couldn't have critted (must be a DoT or HoT)
		-- except now these can crit, so we have a separate parameter 'did_periodic_crit' for that
		if sourceNameGUID and trackAsOutgoing then
			Recap_MakeOutgoingDetail(sourceCombatant, typeEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddTicks(iEffect, total, did_periodic_crit)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeOutgoingDetail(sourceCombatant, elementEffect, AllLastOutgoingDetail)
			iEffect = sourceCombatant[AllLastOutgoingDetail][elementEffect]
			Recap_AddTicks(iEffect, total, did_periodic_crit)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeOutgoingDetail(sourceCombatant, damageEffect, AllLastOutgoingDetail)
				iEffect = sourceCombatant[AllLastOutgoingDetail][damageEffect]
				Recap_AddTicks(iEffect, total, did_periodic_crit)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end

			-- only add when adding to AllFights (otherwise counts twice)
			if selfIndex and doSelf then
				Recap_MakeSelfDetail(selfIndex, typeEffect)
				iEffect = rSelf[selfIndex][typeEffect]
				iEffect.Ticks = (iEffect.Ticks or 0) + 1
				if (did_periodic_crit == 1) then
					iEffect.CritTicks = (iEffect.CritTicks or 0) + 1
				end
				iEffect.TicksDmg = (iEffect.TicksDmg or 0) + total
				iEffect.TicksMax = math_max(total, iEffect.TicksMax or 0)
				if rRecap.gmin then
					-- for the cognoscenti, factor back in any partials to get a gross minimum
					iEffect.TicksMin = Recap_Min(total+(absorb or 0)+(block or 0)+(resist or 0),iEffect.TicksMin)
				else
					-- normal net minimum
					iEffect.TicksMin = Recap_Min(total,iEffect.TicksMin)
				end
				Recap_AddSelfElement(iEffect, myElement)
			end
		end
		if destCombatant then
			Recap_MakeIncomingDetail(destCombatant, typeEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][typeEffect]
			Recap_AddSpellID(iEffect, spellID)
			Recap_AddTicks(iEffect, total, did_periodic_crit)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddElement(iEffect, myElement)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			deltaEstResisted, deltaEstResistable = Recap_CalcEstimatedResistance(iEffect)
			Recap_CalcInterval(iEffect, eventTime)
			-- element subtotal
			Recap_MakeIncomingDetail(destCombatant, elementEffect, AllLastIncomingDetail)
			iEffect = destCombatant[AllLastIncomingDetail][elementEffect]
			Recap_AddTicks(iEffect, total, did_periodic_crit)
			Recap_AddOverhealing(iEffect, overheal)
			Recap_AddPartials(iEffect, total, absorb, block, resist)
			Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
			Recap_CalcInterval(iEffect, eventTime)
			if myType == 1 then
				-- damage subtotal
				Recap_MakeIncomingDetail(destCombatant, damageEffect, AllLastIncomingDetail)
				iEffect = destCombatant[AllLastIncomingDetail][damageEffect]
				Recap_AddTicks(iEffect, total, did_periodic_crit)
				Recap_AddPartials(iEffect, total, absorb, block, resist)
				Recap_AccumulateEstimatedResistance(iEffect, deltaEstResisted, deltaEstResistable)
				Recap_CalcInterval(iEffect, eventTime)
			end
		end
	end
end

local function Recap_MakeTargetDetail(iCombatant, typeWhom, AllLastTargetDetail)
	if not iCombatant[AllLastTargetDetail] then
		iCombatant[AllLastTargetDetail] = {}
	end
	if not iCombatant[AllLastTargetDetail][typeWhom] then
		iCombatant[AllLastTargetDetail][typeWhom] = {}
	end
end

local function Recap_MakeSourceDetail(iCombatant, typeWhom, AllLastSourceDetail)
	if not iCombatant[AllLastSourceDetail] then
		iCombatant[AllLastSourceDetail] = {}
	end
	if not iCombatant[AllLastSourceDetail][typeWhom] then
		iCombatant[AllLastSourceDetail][typeWhom] = {}
	end
end

-- new function to store the matrices of who did what and to whom
local function Recap_AccumulateMatrixDetails(sourceNameGUID, sourceFlags, destNameGUID, destFlags, myType, total, timestamp, AllLastTargetDetail, AllLastSourceDetail)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local typeSource, typeDest, iWhom, sourceCombatant, destCombatant

	if (sourceNameGUID == nil) or (destNameGUID == nil) then
		return
	end

	-- create combatants if needed for the To / From Data Mode
	--   (even if they would not otherwise get created)
	if not rCombatants[sourceNameGUID] then
		Recap_CreateBlankCombatant(sourceNameGUID, math_floor(1000*timestamp), sourceFlags)
	end
	if not rCombatants[destNameGUID] then
		Recap_CreateBlankCombatant(destNameGUID, math_floor(1000*timestamp), destFlags)
	end

	-- table lookup shortcuts
	sourceCombatant = rCombatants[sourceNameGUID]
	destCombatant = rCombatants[destNameGUID]

	-- name adjustments
	if Recap_PetsMerged() and Recap_ExtractOwner(sourceNameGUID) then
		-- pets are merged and this is a pet
		if rOpt.MergeAllPetsIntoOne.value then
			-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
			typeSource = tostring(myType)..Recap_ExtractOwners(Recap_StripGUIDsFromCombatant(sourceNameGUID))..":"..rLocalize.ClassName.Pet
		else
			if sourceCombatant and sourceCombatant.DKRaiseDead then
				-- special name in Matrix panel for death knight ghouls summoned using Raise Dead (only if pets are merged)
				typeSource = tostring(myType)..Recap_ExtractOwners(Recap_StripGUIDsFromCombatant(sourceNameGUID))..":"..rLocalize.GhoulMinion
			else
				typeSource = tostring(myType)..Recap_StripGUIDsFromCombatant(sourceNameGUID)
			end
		end
	else
		typeSource = tostring(myType)..Recap_StripGUIDsFromCombatant(sourceNameGUID)
	end
	if Recap_PetsMerged() and Recap_ExtractOwner(destNameGUID) then
		-- pets are merged and this is a pet
		if rOpt.MergeAllPetsIntoOne.value then
			-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
			typeDest = tostring(myType)..Recap_ExtractOwners(Recap_StripGUIDsFromCombatant(destNameGUID))..":"..rLocalize.ClassName.Pet
		else
			if destCombatant and destCombatant.DKRaiseDead then
				-- special name in Details panel for death knight ghouls summoned using Raise Dead (only if pets are merged)
				typeDest = tostring(myType)..Recap_ExtractOwners(Recap_StripGUIDsFromCombatant(destNameGUID))..":"..rLocalize.GhoulMinion
			else
				typeDest = tostring(myType)..Recap_StripGUIDsFromCombatant(destNameGUID)
			end
		end
	else
		typeDest = tostring(myType)..Recap_StripGUIDsFromCombatant(destNameGUID)
	end

	Recap_MakeTargetDetail(sourceCombatant, typeDest, AllLastTargetDetail)
	iWhom = sourceCombatant[AllLastTargetDetail][typeDest]
	iWhom.Total = (iWhom.Total or 0) + total
	Recap_MakeSourceDetail(destCombatant, typeSource, AllLastSourceDetail)
	iWhom = destCombatant[AllLastSourceDetail][typeSource]
	iWhom.Total = (iWhom.Total or 0) + total
end

local function Recap_CreateMissEffect(sourceNameGUID, destNameGUID, effect, missText, AllLastOtherDetail)

	-- currently ignoring missText

	local rCombatants = _G.recap_combatants
	local typeEffect, iDetail

	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- check for the existence of a cast, buff, debuff, or unknown (in that order)
		typeEffect = nil
		iDetail = rCombatants[sourceNameGUID][AllLastOtherDetail]
		if iDetail then
			if iDetail["1"..effect] then
				typeEffect = "1"..effect
			elseif iDetail["3"..effect] then
				typeEffect = "3"..effect
			elseif iDetail["5"..effect] then
				typeEffect = "5"..effect
			elseif iDetail["7"..effect] then
				typeEffect = "7"..effect
			end
			if typeEffect then
				iDetail[typeEffect].Hits = (iDetail[typeEffect].Hits or 0) + 1
				iDetail[typeEffect].Missed = (iDetail[typeEffect].Missed or 0) + 1
			end
		end
	else
		-- misses not recorded before sourceNameGUID has been registered as a combatant
	end
	if destNameGUID and rCombatants[destNameGUID] then
		-- check for the existence of a cast, buff, debuff, or unknown (in that order)
		typeEffect = nil
		iDetail = rCombatants[destNameGUID][AllLastOtherDetail]
		if iDetail then
			if iDetail["1"..effect] then
				typeEffect = "1"..effect
			elseif iDetail["3"..effect] then
				typeEffect = "3"..effect
			elseif iDetail["5"..effect] then
				typeEffect = "5"..effect
			elseif iDetail["7"..effect] then
				typeEffect = "7"..effect
			end
			if typeEffect then
				iDetail[typeEffect].Hits = (iDetail[typeEffect].Hits or 0) + 1
				iDetail[typeEffect].Missed = (iDetail[typeEffect].Missed or 0) + 1
			end
		end
	else
		-- misses not recorded before destNameGUID has been registered as a combatant
	end
end

local function Recap_CalcOtherInterval(iEffect, eventTime)
	local rUser = _G.recap_user
	-- set a base for the timers
	if not rUser.PrevTimeBase then
		rUser.PrevTimeBase = eventTime - 1
	end
	-- adjust the time
	eventTime = eventTime - rUser.PrevTimeBase
	-- do our stuff
	if iEffect.PrevTime and (iEffect.PrevTime > 0) then
		local delta_time = (1000 * eventTime) - (iEffect.PrevTime or 0)
		if (delta_time > 0) and (delta_time < 130000) then
			-- only pay attention if the two events happened less than 130 seconds apart
			-- count the number of time deltas, and sum their values (will be used to produce an average)
			iEffect.ICount = (iEffect.ICount or 0) + 1
			iEffect.ITotal = (iEffect.ITotal or 0) + delta_time
		end
	end
	iEffect.PrevTime = (1000 * eventTime)
	-- set the timer for measuring durations
	iEffect.PrevTimeDur = (1000 * eventTime)
end

local function Recap_CalcOtherDuration(iEffect, eventTime)
	local rUser = _G.recap_user
	-- set a base for the timers
	if not rUser.PrevTimeBase then
		rUser.PrevTimeBase = eventTime - 1
	end
	-- adjust the time
	eventTime = eventTime - rUser.PrevTimeBase
	-- do our stuff
	if iEffect.PrevTimeDur and (iEffect.PrevTimeDur > 0) then
		local delta_time = (1000 * eventTime) - (iEffect.PrevTimeDur or 0)
		if (delta_time > 0) and (delta_time < 130000) then
			-- only pay attention if the apparent duration is less than 130 seconds
			-- count the number of time deltas, and sum their values (will be used to produce an average)
			iEffect.DCount = (iEffect.DCount or 0) + 1
			iEffect.DTotal = (iEffect.DTotal or 0) + delta_time
		end
	end
	-- clear the duration timer
	iEffect.PrevTimeDur = nil
end

local function Recap_MakeOtherDetail(thisCombatant, typeEffect, AllLastOtherDetail)
	local rCombatants = _G.recap_combatants
	if not rCombatants[thisCombatant][AllLastOtherDetail] then
		rCombatants[thisCombatant][AllLastOtherDetail] = {}
	end
	if not rCombatants[thisCombatant][AllLastOtherDetail][typeEffect] then
		rCombatants[thisCombatant][AllLastOtherDetail][typeEffect] = {}
	end
end

local function Recap_CreateBasicOtherDetail(thisCombatant, timestamp, myType, effect, spellID, AllLastOtherDetail)
	local rCombatants = _G.recap_combatants
	local typeEffect, iEffect
	typeEffect = myType..effect
	Recap_MakeOtherDetail(thisCombatant, typeEffect, AllLastOtherDetail)
	iEffect = rCombatants[thisCombatant][AllLastOtherDetail][typeEffect]
	Recap_AddSpellID(iEffect, spellID)
	iEffect.Hits = (iEffect.Hits or 0) + 1
	Recap_CalcOtherInterval(iEffect, timestamp)
end

local function Recap_CreateFullOtherDetail(thisCombatant, timestamp, myType, effect, spellID, total, attribute, AllLastOtherDetail)
	local rCombatants = _G.recap_combatants
	local typeEffect, iEffect
	typeEffect = myType..effect
	Recap_MakeOtherDetail(thisCombatant, typeEffect, AllLastOtherDetail)
	iEffect = rCombatants[thisCombatant][AllLastOtherDetail][typeEffect]
	Recap_AddSpellID(iEffect, spellID)
	iEffect.Hits = (iEffect.Hits or 0) + 1
	if (total == nil) then
		-- special case, refreshing a buff, probably a stackable buff
		-- use the existing maximum stack value (theory is that we only get the refresh when the stack is at maximum)
		total = (iEffect.Max or 1)
	end
	iEffect.Total = (iEffect.Total or 0) + total
	iEffect.Max = math_max(total, iEffect.Max or 1)
	if attribute then
		iEffect.Attribute = attribute
	end
	Recap_CalcOtherInterval(iEffect, timestamp)
end

local function Recap_AddRecentEvent(eventTime, sourceNameGUID, destNameGUID, effectType, effect, element, amount, crit, crush, overheal)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local i, thisSource, thisDest, thisCrit, eventText

	-- play with the pointers
	if rRecent[rRecent.Last] and (rRecent[rRecent.Last] ~= "") then
		-- events already stored, move Last pointer
		if rRecent.Last >= rOpt.RecentEventCount.value then
			rRecent.Last = 1
		else
			rRecent.Last = rRecent.Last + 1
		end
		if rRecent.First == rRecent.Last then
			-- pointers have met, move the First pointer out of the way
			if rRecent.First >= rOpt.RecentEventCount.value then
				rRecent.First = 1
			else
				rRecent.First = rRecent.First + 1
			end
		end
	else
		-- no event stored yet, store at Last
	end
	i = rRecent.Last

	-- remember the most recent time stamp encountered, for use in stamping end of fight records
	rRecent.Time = eventTime

	if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
		-- name adjustments
		if Recap_PetsMerged() and sourceNameGUID and Recap_ExtractOwner(sourceNameGUID) then
			-- pets are merged and this is a pet
			if rOpt.MergeAllPetsIntoOne.value then
				-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
				thisSource = Recap_ExtractOwners(sourceNameGUID)..":"..rLocalize.ClassName.Pet
			else
				if rCombatants[sourceNameGUID] and rCombatants[sourceNameGUID].DKRaiseDead then
					-- special name in Recent Events panel for death knight ghouls summoned using Raise Dead (only if pets are merged)
					thisSource = Recap_ExtractOwners(sourceNameGUID)..":"..rLocalize.GhoulMinion
				else
					thisSource = sourceNameGUID
				end
			end
		else
			thisSource = sourceNameGUID
		end
		if Recap_PetsMerged() and destNameGUID and Recap_ExtractOwner(destNameGUID) then
			-- pets are merged and this is a pet
			if rOpt.MergeAllPetsIntoOne.value then
				-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
				thisDest = Recap_ExtractOwners(destNameGUID)..":"..rLocalize.ClassName.Pet
			else
				if rCombatants[destNameGUID] and rCombatants[destNameGUID].DKRaiseDead then
					-- special name in Recent Events panel for death knight ghouls summoned using Raise Dead (only if pets are merged)
					thisDest = Recap_ExtractOwners(destNameGUID)..":"..rLocalize.GhoulMinion
				else
					thisDest = destNameGUID
				end
			end
		else
			thisDest = destNameGUID
		end
		if crush then
			thisCrit = "**"
		elseif crit then
			thisCrit = "*"
		else
			thisCrit = ""
		end

		-- fix up any nil values
		if (thisSource == nil) then
			thisSource = ""
		end
		if (thisDest == nil) then
			thisDest = ""
		end
		if (effect == nil) then
			effect = ""
		end
		if (element == nil) then
			element = ""
		end
		if (amount == nil) then
			amount = ""
		end
		if (overheal == nil) or (overheal == 0) then
			overheal = ""
		end

		-- fixed string format to keep memory usage and table churn down
		eventText = string_format("%.3f>%s>%s>%s>%s>%s>%s>%s>", eventTime, thisSource, thisDest, tostring(effectType)..effect, element, amount, thisCrit, overheal)
		rRecent[i] = eventText

		-- if this is a death event or killed event for a friend combatant (other than a pet), we also record it in a separate table to greatly speed up the Deaths processing
		-- note that we can get up to three records for a single death, and the Deaths processing will use the earliest
		if (effectType == 5) and rTemp.InFriend[destNameGUID] and rCombatants[destNameGUID] and (not rCombatants[destNameGUID].OwnedBy) and (not Recap_ExtractOwner(destNameGUID)) then
			-- the RecentFriendDeaths table is indexed by the same integers as the Recent table, but is sparsely populated
			rTemp.RecentFriendDeaths[i] = eventText
		end
	else
		-- if sourceNameGUID and destNameGUID are both empty strings, this represents an 'end of fight' event
		rRecent[i] = string_format("%.3f>%s>%s>%s>%s>%s>%s>%s>", eventTime, "*EOF*", "", "", "", "", "", "")
	end
end

local function Recap_AddLiveDataHelper(eventTime, thisCombatant, amount, overheal, theBins, healing)

	local rCombatants = _G.recap_combatants
	local rGraph = _G.recap_temp.Graph
	local rTemp = _G.recap_temp
	local i, fightStart, firstBinTime, targetBin, currentBin, iBin, netHeal
	local iCombatant

	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if overheal then
		overheal = Recap_Round0(overheal) -- paranoia 5.0.4
	end

	if (rTemp.FightStart == 0) and (rTemp.FightStartIn == 0) and (rTemp.FightStartHeal == 0) then
		-- fight hasn't officially started yet
		if healing then
			-- don't register this healing event as a live event if the fight hasn't officially begun
			return
		end
	end

	if rTemp.FightStart > 0 then
		fightStart = rTemp.FightStart
	elseif rTemp.FightStartIn > 0 then
		fightStart = rTemp.FightStartIn
	elseif rTemp.FightStartHeal > 0 then
		fightStart = rTemp.FightStartHeal
	else
		-- use this as the beginning of the fight
		fightStart = eventTime
	end

	firstBinTime = fightStart - (rGraph.BinSize / 2) -- puts the first event into the middle of the first bin (final event will on average be in the middle of its bin, as will any damage string starting "in media res") (avoids over-weighting the first bin)

	-- compute target bin (starts at 2 so we can store into bin 1)
	targetBin = 2 + math_floor((eventTime - firstBinTime) / rGraph.BinSize)

	if not rGraph.BinsInitialized then
		RecapGraph_InitializeLiveLists()
	end
	if not rGraph[theBins][thisCombatant] then -- added this since I got a nil value once
		RecapGraph_UpdateLiveLists()
	end

	if rGraph.ProcessLockStatus == "neutral" then
		-- we are altering raw bins, so block further processing of raw data into display data (until the fight becomes significant)
		rGraph.ProcessLockStatus = "lock"
	end

	-- point at the appropriate bins
	iCombatant = rGraph[theBins][thisCombatant]
	if (iCombatant == nil) then
		-- this combatant is not the live bins (happens only occasionally, not sure why)
		if Recap_ExtractOwner(thisCombatant) or (rCombatants[thisCombatant] and rCombatants[thisCombatant].OwnedBy) or
			(rCombatants[thisCombatant] and rCombatants[thisCombatant].Flags and (bit_band(rCombatants[thisCombatant].Flags, bit_bor(COMBATLOG_OBJECT_TYPE_OBJECT, COMBATLOG_OBJECT_TYPE_GUARDIAN, COMBATLOG_OBJECT_TYPE_PET)) ~= 0)) then
			-- pet, ignore
			return
		else
			-- add this combatant and try again
			local name = Recap_StripGUIDsFromCombatant(thisCombatant)
			RecapGraph_AddToOneLiveList(thisCombatant, name, "LiveDmgOutBins", "LiveDmgOutSorted", "CombatantsDPSOut")
			RecapGraph_AddToOneLiveList(thisCombatant, name, "LiveDmgInBins", "LiveDmgInSorted", "CombatantsDPSIn")
			RecapGraph_AddToOneLiveList(thisCombatant, name, "LiveHealingBins", "LiveHealingSorted", "CombatantsHPSOut")
			iCombatant = rGraph[theBins][thisCombatant]
		end
	end

	-- fill any intermediate bins with zeroes
	-- following is hard-coded for NBins = 3
	currentBin = math_max(iCombatant.Highwater, 1)
	iBin = iCombatant.Raw
	for i = currentBin, targetBin + 1 do
		if not iBin[i] then
			iBin[i] = 0
		end
	end

	-- fill the bins, adding the same value into three adjacent bins (saves messy accumulation later)
	if healing then
		netHeal = math_max((amount - overheal), 0)
		-- following is hard-coded for NBins = 3
		iBin[targetBin - 1] = iBin[targetBin - 1] + netHeal
		iBin[targetBin] = iBin[targetBin] + netHeal
		iBin[targetBin + 1] = iBin[targetBin + 1] + netHeal
		-- accumulate total
		iCombatant.RawTotal = iCombatant.RawTotal + netHeal
	else
		-- following is hard-coded for NBins = 3
		iBin[targetBin - 1] = iBin[targetBin - 1] + amount
		iBin[targetBin] = iBin[targetBin] + amount
		iBin[targetBin + 1] = iBin[targetBin + 1] + amount
		-- accumulate total
		iCombatant.RawTotal = iCombatant.RawTotal + amount
	end
	iCombatant.Highwater = targetBin

	-- if this is damage dealt or taken by the group, check for significance
	if not healing then
		rGraph.GroupInvolved = true
		if (rGraph.FightSignificant == false) and ((eventTime - firstBinTime) > rTemp.LastFightSignificantTime) then
			-- first event of a significan fight
			RecapGraph_InitializeDisplayLists()
			rGraph.FightSignificant = true
		end
	end
	-- note that bins might not all be filled up to targetBin, or indeed have any data at all
end

local function Recap_AddLiveData(eventTime, sourceNameGUID, destNameGUID, effectType, amount, overheal)

	local rTemp = _G.recap_temp
	local thisSource, thisDest

	if (sourceNameGUID == "") and (destNameGUID == "") then
		-- both names empty, bail
		return
	end

	if recap_temp.Graph.Paused then
		-- not collecting live data at the moment, bail
		return
	end

	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if overheal then
		overheal = Recap_Round0(overheal) -- paranoia 5.0.4
	end

	-- name adjustments
	thisSource = sourceNameGUID
	thisDest = destNameGUID
	if Recap_PetsMerged() then
		if sourceNameGUID and Recap_ExtractOwner(sourceNameGUID) then
			-- pets are merged and this is a pet, add to the owner
			thisSource = Recap_ExtractOwner(sourceNameGUID)
		end
		if destNameGUID and Recap_ExtractOwner(destNameGUID) then
			-- pets are merged and this is a pet, add to the owner
			thisDest = Recap_ExtractOwner(destNameGUID)
		end
	end
	if not rTemp.InGroup[thisSource] then
		-- not for graphing
		thisSource = ""
	end
	if not rTemp.InGroup[thisDest] then
		-- not for graphing
		thisDest = ""
	end
	-- assert: if thisSource or thisDest is not blank, that means it is a friend (or it was the pet of a friend)

	-- accumulate to the correct bins
	if effectType == 1 then
		-- damage
		if (thisSource ~= "") and (thisDest == "") then
			-- we omit outgoing damage to friends (or pets of friends)
			Recap_AddLiveDataHelper(eventTime, thisSource, amount, overheal, "LiveDmgOutBins", false)
		end
		if (thisDest ~= "") then
			Recap_AddLiveDataHelper(eventTime, thisDest, amount, overheal, "LiveDmgInBins", false)
		end

	elseif (effectType == 3) or (effectType == 4) then
		if (thisSource ~= "") then
			-- healing will not be visible if that's all that happens
			Recap_AddLiveDataHelper(eventTime, thisSource, amount, overheal, "LiveHealingBins", true)
		end
	end
end

-- Is this a hostile event? (heuristic only, we won't be able to spot all possible hostile events)
-- These are 'hostile' events in two specific contexts
--   The first is casting between an owner and its apparent pet, or from pet to apparent owner
--	   So if, for example, an owner successfully damages a pet with melee, or vice versa, we can I think safely conclude that the pet is not currently controlled by the (former) owner
--	   I'm trying to guess which events would only ever be permitted to happen by Blizzard between entities which are at that instant hostile to each other, and hence not currently in a proper owner-pet relationship
--	   Note that it is frequently the case that we don't learn the initial OwnedBy relationship and so an NPC Imp Minion (say) begins with an unknown owner
--   The second is casting between a member of the group and an apparent Friend, who may have earlier been a temporary pet (e.g. mind controlled) but who is now presumably hostile again
local function Recap_HostileEvent(eventType, eventIsCombatDamageEquivalent, sourceCombatant, destCombatant, ...)

	local spellID, auraType, spellTypeName

	if eventIsCombatDamageEquivalent or (eventType == "SPELL_INTERRUPT") then
		-- special case code to treat selected damage as non-hostile (checking over all event types)
		spellID = select(12, ...)
		if (spellID == 108446) or (spellID == 79957) or (spellID == 108415) or (spellID == 108447) or -- spellIds for Soul Link
		   (spellID == 48743) or -- spellIDs for Death Pact
		   (spellID == 98021) or -- spellIDs for Spirit Link (the Spirit Link Totem heals and damages group members)
		   (spellID == 119899) or (spellID == 119905) or (spellID == 159017) or (spellID == 137179) or (spellID == 124538) then -- spellIDs for Cauterize Master
			-- pet<=>owner or similar, benign damage, treat as non-hostile
			return false
		else
			-- we assume that this is hostile although it might be involuntary (as in Shatter damage or Fire Bloom damage)
			-- TODO BLAH should we exclude known 100% involuntary damage?
			--   This would be a significant change in Recap behaviour, and I have not been collecting spell IDs for this kind of thing.
			return true
		end
	else
		-- more complex situations (no guarantee that these are always hostile, because they might be involuntary)
		if (eventType == "SPELL_AURA_APPLIED") or (eventType == "SPELL_AURA_APPLIED_DOSE") then
			-- source debuffing dest
			auraType = select(15, ...)
			if (auraType == "DEBUFF") then
				spellID = select(12, ...)
				if (spellID == 141688) or (spellID == 108366) or (spellID == 6788) then
					-- Orb of Healing and Soul Leech seems to be mislabelled as a debuffs
					-- Weakened Soul is a debuff, but I think does not indicate hostile action
					-- Orb of Power is shown as a debuff, still researching (BLAH TODO)
					return false
				else
					-- debuff applied
					return true
				end
			end
		elseif (eventType == "SPELL_DISPEL") or (eventType == "SPELL_AURA_STOLEN") then
			-- source dispelling or stealing dest's buff
			auraType = select(15, ...)
			if (auraType == "BUFF") then
				-- buff dispelled
				return true
			end
		elseif (eventType == "SPELL_CAST_SUCCESS") then
			-- while a DoT tick could legitimately do damage between friends, I think Blizzard would not permit a successful damaging spell *cast* between friends
			spellTypeName = "1"..select(13, ...)
			if (sourceCombatant.OutgoingDetail and sourceCombatant.OutgoingDetail[spellTypeName]) or
			   (sourceCombatant.IncomingDetail and sourceCombatant.IncomingDetail[spellTypeName]) or
			   (destCombatant.OutgoingDetail and destCombatant.OutgoingDetail[spellTypeName]) or
			   (destCombatant.IncomingDetail and destCombatant.IncomingDetail[spellTypeName]) then
				spellID = select(12, ...)
				-- this is a cast of a spell which has done damage before (we check only the source and dest, not the details for all combatants, so we might miss a damaging cast)
				if (spellID == 130654) or (spellID == 124040) then
					-- Chi Burst and Chi Torpedo do both damage to enemies and healing to friends, so ignore the cast
					return false
				else
					return true
				end
			end
		end
		-- probably friendly: SPELL_HEAL, SPELL_PERIODIC_HEAL, SPELL_SUMMON, SPELL_CREATE, SPELL_ENERGIZE, SPELL_PERIODIC_ENERGIZE, ENCHANT_APPLIED, ENCHANT_REMOVED, SPELL_RESURRECT
		--   the enforced summon due to Swarming Shadows is not friendly
		-- potentially ambiguous: PARTY_KILL, SPELL_PERIODIC_DAMAGE, SPELL_PERIODIC_MISSED, DAMAGE_SPLIT, SPELL_DRAIN, SPELL_PERIODIC_DRAIN, SPELL_LEECH, SPELL_PERIODIC_LEECH
		--   for example: the SPELL_PERIODIC_DAMAGE is potentially ambiguous if I DoT someone then mind control them while the DoT is still active -- the tick will do damage but is not hostile for this purpose
		--   some misses are for healing
		-- potentially ambiguous: SPELL_CAST_START, SPELL_CAST_FAILED, SPELL_DISPEL_FAILED
		-- other: ENVIRONMENTAL_DAMAGE, UNIT_DIED, SPELL_INSTAKILL, SPELL_EXTRA_ATTACKS, SPELL_AURA_REMOVED, SPELL_AURA_REMOVED_DOSE, SPELL_DURABILITY_DAMAGE, SPELL_DURABILITY_DAMAGE_ALL, UNIT_DESTROYED
	end
	return false
end

local function Recap_ProcessCombatant(timestamp, iCombatant, combatantFlags)

	local rCombatants = _G.recap_combatants
	local wasControlled, isControlled

	-- if the combatant has no First Seen time, add it
	if (iCombatant.Seen == nil) or (iCombatant.Seen == 0) then
		iCombatant.Seen = math_floor(1000*timestamp)
	end

	-- update flags
	if combatantFlags and (combatantFlags > 0) then
		wasControlled = 0
		if iCombatant.Flags then
			wasControlled = bit_band(iCombatant.Flags, COMBATLOG_OBJECT_TYPE_PET)
		end
		isControlled = bit_band(combatantFlags, COMBATLOG_OBJECT_TYPE_PET)
		if (wasControlled == 0) and (isControlled ~= 0) then
			-- was not controlled as a pet, is now, so check friends immediately in case it is a new pet for us
			Recap_MakeFriends(false)
		end
		iCombatant.Flags = combatantFlags
	end

	-- if the combatant is Player-owned, add a Trash value of false
	-- Trash is nil if not known, true if we have counted more than one of them, and false if the combatant is Player-owned
	if (bit_band(combatantFlags, COMBATLOG_OBJECT_CONTROL_PLAYER) ~= 0) then
		iCombatant.Trash = false -- keep as false
	end
end

local function Recap_FilterDoNotStore(sourceNameGUID, destNameGUID)

	local rUser = _G.recap_user

	-- does a combatant have "do not store" status due to the setting of options?
	if (rUser.SyncState == "Member") or (rUser.SyncState == "Leader") then
		-- in synchronization, carry on as normal
	else
		local rCombatants = _G.recap_combatants
		local rOpt = _G.recap_temp.Opt
		-- note that 'friends' includes group members, former group members, hostiles controlled for a while, and combatants explicitly named as friends
		-- note that 'friends' will have been added explicitly by a call to MakeFriends, and so will already exist as combatants
		if sourceNameGUID then
			if not rCombatants[sourceNameGUID] then
				-- we don't have this combatant, must by definition be a non-friend
				if rOpt.HideOthers.value then
					-- keep them excluded
					sourceNameGUID = nil
				end
			else
				-- we already have this combatant
				if rCombatants[sourceNameGUID].Friend then
					-- it is a friend
					if rOpt.HideGroup.value and (not Recap_CheckForSelf(sourceNameGUID)) then
						-- it is not the player or player's pets, don't gather any additional information
						sourceNameGUID = nil
					end
				else
					-- it is a non-friend
					if rOpt.HideOthers.value then
						-- don't gather any additional information
						sourceNameGUID = nil
					end
				end
			end
		end
		if destNameGUID then
			if not rCombatants[destNameGUID] then
				-- we don't have this combatant, must by definition be a non-friend
				if rOpt.HideOthers.value then
					-- keep them excluded
					destNameGUID = nil
				end
			else
				-- we already have this combatant
				if rCombatants[destNameGUID].Friend then
					-- it is a friend
					if rOpt.HideGroup.value and (not Recap_CheckForSelf(destNameGUID)) then
						-- it is not the player or player's pets, don't gather any additional information
						destNameGUID = nil
					end
				else
					-- it is a non-friend
					if rOpt.HideOthers.value then
						-- don't gather any additional information
						destNameGUID = nil
					end
				end
			end
		end
	end

	return sourceNameGUID, destNameGUID
end

local ArgumentListForErrorReporting = {}

local function Recap_EventText(...)
	local timestamp, eventtype, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16
	if ... then
		-- we got an argument
		timestamp, eventtype, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16 = ...
	else
		-- no argument, stuff should be in ArgumentListForErrorReporting
		timestamp, eventtype, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13, x14, x15, x16 = unpack(ArgumentListForErrorReporting)
	end
	local printable = tostring(timestamp)..", "..tostring(eventtype)..", "..tostring(hideCaster)..", "..tostring(sourceGUID)..", "..tostring(sourceName)..", "..string_format("0x%X", (sourceFlags or 0))..", "..string_format("0x%X", (sourceRaidFlags or 0))..", "..tostring(destGUID)..", "..tostring(destName)..", "..string_format("0x%X", (destFlags or 0))..", "..string_format("0x%X", (destRaidFlags or 0))
	-- only dump extras up to the last non-nil value
	-- this does not distinguish between trailing values which are nil and trailing values which are absent
	local extras = ""
	if x16 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)..", "..tostring(x11)..", "..tostring(x12)..", "..tostring(x13)..", "..tostring(x14)..", "..tostring(x15)..", "..tostring(x16)
	elseif x15 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)..", "..tostring(x11)..", "..tostring(x12)..", "..tostring(x13)..", "..tostring(x14)..", "..tostring(x15)
	elseif x14 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)..", "..tostring(x11)..", "..tostring(x12)..", "..tostring(x13)..", "..tostring(x14)
	elseif x13 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)..", "..tostring(x11)..", "..tostring(x12)..", "..tostring(x13)
	elseif x12 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)..", "..tostring(x11)..", "..tostring(x12)
	elseif x11 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)..", "..tostring(x11)
	elseif x10 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)..", "..tostring(x10)
	elseif x9 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)..", "..tostring(x9)
	elseif x8 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)..", "..tostring(x8)
	elseif x7 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)..", "..tostring(x7)
	elseif x6 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)..", "..tostring(x6)
	elseif x5 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)..", "..tostring(x5)
	elseif x4 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)..", "..tostring(x4)
	elseif x3 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)..", "..tostring(x3)
	elseif x2 ~= nil then
		extras = tostring(x1)..", "..tostring(x2)
	elseif x1 ~= nil then
		extras = tostring(x1)
	end
	if extras ~= "" then
		printable = printable..", "..extras
	end
	return printable
end

local function Recap_CheckUnexpectedEvent(reason, ...)
	local rRecap = _G.recap
	local rTemp = _G.recap_temp
	if rTemp.UnexpectedErrorMessageCount < 8 then
		-- only emit the first few error messages after a log or reload
		local text = string_format("Recap [%.3f]: %s: %s", Recap_Version, reason, Recap_EventText(...))
		if rRecap.dump then
			Recap_DumpMessage(text)
		end
		print(text)
		if rTemp.snap or Recap_IsRecapAuthor() then
			Screenshot()
		end
		rTemp.UnexpectedErrorMessageCount = rTemp.UnexpectedErrorMessageCount + 1
	end
end

local function Recap_DecodeSchoolName(school)

-- DEBUG
--if school == nil then
--	Recap_CheckUnexpectedEvent("nil school, spell school, or extra spell school")
--	result = rLocalize.ElementOther
--	return result
--end

	local i, result
	result = ""
	if rLocalize.SchoolName[school] then
		-- shortcut, we have a simple match
		result = rLocalize.SchoolName[school]
	else
		-- perhaps it is a composite
		for i in pairs(rLocalize.SchoolName) do
			if bit_band(school, i) ~= 0 then
				if result == "" then
					result = rLocalize.SchoolName[i]
				else
					result = result.."+"..rLocalize.SchoolName[i]
				end
			end
		end
		if result == "" then
			-- still no luck
			Recap_CheckUnexpectedEvent("unexpected school, spell school, or extra spell school ("..school..")")
			result = rLocalize.ElementOther
		end
	end
	return result
end

local function Recap_CreditAbsorptionAsHealing(timestamp, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, amountAvailable, regSource, regDest)

	local rOpt = _G.recap_temp.Opt
	local rIgnore = _G.recap_ignore
	local rTemp = _G.recap_temp

	-- credit the amountAvailable as healing
	if rOpt.StoreOnlyDisplayed.value then
		sourceNameGUID, destNameGUID = Recap_FilterDoNotStore(sourceNameGUID, destNameGUID)
	end
	if sourceNameGUID or destNameGUID then

		-- we treat absorption as having zero overhealing, though that's not strictly true
		-- TODO: we don't at the moment store the overhealing amount (could treat unused shield amounts from SPELL_AURA_REMOVED as overhealing)
		local rawheal = amountAvailable
		if rawheal then
			rawheal = Recap_Round0(rawheal) -- paranoia 5.0.4
		end
		local actualheal = rawheal
		local overheal = 0
		local schoolName = rLocalize.SchoolName[2] -- we choose that all absorption healing be Holy

		if rIgnore and rIgnore[spellID] then
			-- ignore damage and healing from this effect
		else
			-- Now keeping an independent timer for healing, and setting the 'WasInCurrent' flag for the healer
			-- Now also start the timers for the recipient of a heal
			if sourceNameGUID then
				Recap_CreateCombatantAndUpdateTimers(sourceNameGUID, timestamp, sourceFlags, "Heal")
			end
			if destNameGUID then
				Recap_CreateCombatantAndUpdateTimers(destNameGUID, timestamp, destFlags, "Heal")
			end

			local iLast = rTemp.Last[sourceNameGUID]
			iLast.RawHeal = iLast.RawHeal + rawheal

			if not rOpt.LightData.value then
				-- the effect is credited with the full value of the heal, not crit-capable
				Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 3, rawheal, overheal, nil, 1, schoolName, false, nil, nil, nil, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
				Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 3, rawheal, overheal, nil, 1, schoolName, false, nil, nil, nil, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)

				if rOpt.MatrixData.value and (actualheal > 0) then
					Recap_AccumulateMatrixDetails((sourceNameGUID or rLocalize.Unknown), (sourceFlags or 0), (destNameGUID or rLocalize.Unknown), (destFlags or 0), 3, actualheal, timestamp, "TargetDetail", "SourceDetail")
					Recap_AccumulateMatrixDetails((sourceNameGUID or rLocalize.Unknown), (sourceFlags or 0), (destNameGUID or rLocalize.Unknown), (destFlags or 0), 3, actualheal, timestamp, "LastTargetDetail_"..rTemp.ActiveLastFight, "LastSourceDetail_"..rTemp.ActiveLastFight)
				end
			end

			-- live feed
			if rOpt.LiveData.value then
				Recap_AddLiveData(timestamp, sourceNameGUID, destNameGUID, 4, (rawheal or 0), 0)
			end
		end

		-- ignored effects will still show up as recent events (deliberate, so we can see them if we want)
		-- the absorption healing is a new event type 4
		if rOpt.RecentData.value then
			if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
				Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 4, spellName, schoolName, rawheal, false, false, 0)
			end
		end

		-- reduce the (previously registered, whether just now or earlier) amount absorbed
		-- we hope that under most circumstances one or more shield reductions exactly equal the amount absorbed, which would be happiness
		regDest.AmountAbsorbed = (regDest.AmountAbsorbed or 0) - amountAvailable
		if regDest.AmountAbsorbed == 0 then
			regDest.DestTimestamp = nil
		end
	end
end

-- Absorption and shields for patch 4.0.1 (pre-Cataclysm) as of 2010-October-11, updated on various dates to 2010-October-19:
-- Blizzard now includes in the combat log events SPELL_AURA_APPLIED, SPELL_AURA_REFRESH, and SPELL_AURA_REMOVED the size of the shield remaining for the buff
-- The amounts of damage absorbed were already available in combat log events for damage
-- We can determine how much damage a shield absorbed if we have 'before' and 'after' aura events (why oh why, Blizzard, do you not have something easy like a SPELL_AURA_ABSORBS event
--		with an amount absorbed plus the size of the remaining shield, a trivial number of additional bytes?)
-- Ideally the sum of damage absorbed (from single damage events) and the sum of shields consumed (from pairs of aura events) would be equal
-- If only it were that simple
-- We find that damage events or aura events might be missing entirely, whether because they take place out of range or are simply lost
-- We have modified Recap to record shield aura events that occur outside of combat
-- We find that damage events and the matching aura events might occur in either order, so we have to accommodate that by registering all related events to the target / aura / shielder combinations
-- We can match up damage absorption events and shield aura event pairs to the best of our ability
-- We note that shield aura events can arrive at least 9 seconds after the corresponding damage absorption events, so we have to allow for an unusually generous window for the reconciliation of registrations
-- We can sometimes tell that a target has a shield aura to match a damage absorption event, but without an earlier matching shield aura event to give us an accurate delta
--		(so we choose to assign all of the absorption to this shield, and furthermore to the first such shield aura event encountered -- this might not be completely accurate)
-- We note that often, but not always, the penultimate SPELL_AURA_REFRESH event and the ultimate SPELL_AURA_REMOVED event will show the same size of shield remaining (i.e. zero absorption),
--		and furthermore that the SPELL_AURA_REMOVED event can show a remaining size of zero if the shield has been entirely consumed
-- We find that if there is an absorb just before a scheduled SPELL_AURA_REMOVED event, there will sometimes be no corresponding SPELL_AURA_REFRESH event (which would have showed the reduction),
--		and neither will the SPELL_AURA_REMOVED event itself show the reduced shield (so we're hooped)
-- We find that if there is a damage at the same time as the shield is cast, sometimes the damage takes place (is not absorbed), yet the shield is reduced by the amount of the damage
-- We find that if there are a lot of damage absorption events at the same time, they might all fully absorb yet the total absorbed is far larger than the shield available (which is a good bug if you are inside that shield)
-- Non-healer personal shields of various kinds are not supported by this new combat log mechanism, and so we do not attempt to assign them as heals.  These include druid Savage Defense, mage Mana Shield, mage Ice Barrier.
-- We find that some shield auras feature *increased* shield sizes from one aura event to the next (e.g. Illuminated Healing), so presumably something boosts the shield while it is in place (not sure of the mechanism here)
-- We find that this observed increase will also occur if a new shield (of the same type from the same shielder) overwrites an existing shield
-- We wonder whether the overwriting of an existing shield by a smaller shield could ever occur, and if so whether this would produce spurious shield reductions that we would mis-interpret as absorptions
--		(probably not, we get "A more powerful spell is already active")
-- We find that sometimes multiple absorption events will be covered by a single aura event pair (e.g. absorption 12 plus absorption 15 plus absorption 9 matched by a single shield change of 36)
-- We wonder whether this aggregation of shield size changes might include both shield reductions and shield increases (if so, we would lose the ability to reliably assign absorption events to shields)
-- One aura which might represent a shield also appears to contain a secondary spell ID (we have not determined what this is and how to use it)
-- We have seen several combat log event samples with a shield reduction without a corresponding SPELL_MISSED / ABSORB event (range could not have been an issue)

-- Mechanism: a) register each absorption amount to the target, and if there is a prior registration of a shield aura change, we can do something (see step c)
--			  b) register each shield aura change (in the order encountered, not in any priority order) to the target / aura ID / shielder combination, and if there is a prior registration of an absorption amount,
--					we can do something (see step c)
--				 b1) if there is a shield aura event without a prior shield aura event (so that we cannot calculate a delta), then there is an implied infinite change, and during step c) the entire registered
--					absorption amount will be credited to this shield
--			  c) if there is a match from a) or b) then reduce both registered numbers by the lesser of the two amounts (a registration that goes to zero as a result of this is removed)
--				 c1) if there are multiple shields registered to the target, matching from an absorption amount is done on a first come, first served somewhat random basis (specifically, for the target we scan spell IDs
--					in the order handed to us by LUA, and within the spell IDs we scan in the shielder order handed to us by LUA)
--					(we do not scan spell IDs in any special case order giving priority to e.g. Power Word: Shield, which had been the deal with our pre 4.60 special case code)
--			  ideally at the end of a fight there will be no non-zero registrations left, and we can declare happiness, but this is often not the case (we don't yet fully understand all reasons for this)
--			  unmatched absorption amounts, and unmatched shield aura changes, are currently both left un-attributed to any shielder at the end of a fight (we have no feeling yet for whether or not
--					this is a significant proportion of all absorption)
--			  we expire an absorption amount registration after 12 seconds (since we have observed experimentally that it must be remembered for at least 7 seconds, so trying to be safe)
--					if there is no matching shield aura change (could expire something that Blizzard considers still active, or fail to expire something that Blizzard considers ended)
--			  we expire a shield aura change registration after 42 seconds (the longest duration shield that I know of at 30 seconds plus the same 12 second window just described)
--					if there is no matching absorption amount (could expire something that Blizzard considers still active, or fail to expire something that Blizzard considers ended)
--
-- On the plus side, we have, at least in theory, absorption / shielding numbers that we can match up unambiguously to the shielder.
-- We find that in many simple situations, this works exactly as expected and desired
-- It is a general solution, so we have removed the half dozen special case code blocks for shields that Recap was hitherto processing individually.
-- Recap will now be able to handle new shield types without any additional special case code
--
-- The jury is still out on whether our special case code was more or less accurate than the new code (we haven't done a direct comparison, and have our doubts (given the many complications listed above)
--		but choose to go ahead anyway (combat log events are hit and miss for other data too, so why be more picky about shields))
-- The previous special case code included individual aura duration code, and this is no longer available, so some expired short-duration shield auras might still be credited since we can't always know
--		that they have expired (there might be no corresponding SPELL_AURA_REMOVED event, for example)
--
-- 2013-June-10: it seems likely that not all absorb events are posted in the log, so matching them carefully to shield reductions may under-estimate shield 'healing'
--
local function Recap_AbsorptionEvent(timestamp, destNameGUID, destFlags, amount)

	local regDest, iSpell, iSource, regSource

	-- list for destinations
	if not rShields[destNameGUID] then
		rShields[destNameGUID] = {}
	end
	regDest = rShields[destNameGUID]

	-- forget any stale-dated absorption amount
	if regDest.AmountAbsorbed and (regDest.AmountAbsorbed > 0) then
		if ((timestamp - regDest.DestTimestamp) < 12) then -- 12 second window for aura changes to show up and be applied
			-- current amount, carry on
		else
			-- expired
			-- we might choose to attribute the absorption to any registered shields
			regDest.AmountAbsorbed = 0 -- zero rather than nil to avoid excess thrashing
			regDest.DestTimestamp = nil
		end
	end

	-- add the fresh absorption amount to any existing un-expired un-processed absorption amount for this target
	regDest.AmountAbsorbed = (regDest.AmountAbsorbed or 0) + amount
	-- set or renew the timestamp, which could under some circumstances lead to some mis-attribution of earlier absorption, tough
	regDest.DestTimestamp = timestamp

	-- check to see whether there is a pending absorption amount from a shield (in case the shield reduction event came prior to this absorption event)
	-- we get these in LUA table order (i.e. kind of random)
	for iSpell in pairs(regDest) do
		if type(iSpell) == "number" then
			-- this is a spell ID, rather than 'AmountAbsorbed' or 'DestTimestamp'
			for iSource in pairs(regDest[iSpell]) do
				-- source
				regSource = regDest[iSpell][iSource]
				if regSource.AbsorptionPending and (regSource.AbsorptionPending > 0) then

					-- existing amount, has it expired?
					if ((timestamp - regSource.AbsorptionPendingTimestamp) < 12) then -- a pending amount (not to be confused with a shield registration) is only carried for 12 seconds
						-- current registration

						-- there is a pending absorption amount, use it
						if regDest.AmountAbsorbed and (regDest.AmountAbsorbed > 0) then
							local amountAvailable = math_min(regSource.AbsorptionPending, regDest.AmountAbsorbed)
							Recap_CreditAbsorptionAsHealing(timestamp, iSource, regSource.SourceFlags, destNameGUID, destFlags, iSpell, regSource.SpellName, amountAvailable, regSource, regDest)

							-- adjust the pending amount (AmountAbsorbed was adjusted by Recap_CreditAbsorptionAsHealing)
							regSource.AbsorptionPending = regSource.AbsorptionPending - amountAvailable
							regSource.AbsorptionPendingTimestamp = timestamp
							if regSource.AbsorptionPending == 0 then
								regSource.AbsorptionPendingTimestamp = nil
							end
						end
					else
						-- expired pending amount, forget it (we choose, for the moment, to not credit it to the shielder)
						regSource.AbsorptionPending = 0
						regSource.AbsorptionPendingTimestamp = nil
					end
				end
			end
		end
	end

	-- we do nothing further at this time regarding crediting the absorption
	-- subsequent SPELL_AURA_REFRESH and SPELL_AURA_REMOVED events, which record reductions in shields, will normally match this absorption and allow proper credit to be given

end

local function Recap_DamageEvent(timestamp, eventType, sourceNameGUID, sourceFlags, specialMelee, destNameGUID, destFlags, spellID, spellName, spellSchool, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)

	-- currently ignoring sourceFlags, destFlags
	local rIgnore = _G.recap_ignore
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local trackAsOutgoing, iLast

	-- assert: caller has already checked that 'amount' is greater than zero

	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if absorbed then
		absorbed = Recap_Round0(absorbed) -- paranoia 5.0.4
	end

	-- TODO: at the moment we are ignoring overkill.  Most of the time the overkill amounts are 1) minimal and 2) appropriate to credit as damage for e.g. DPS purposes
	-- overkill value is often -1
	-- yes, overkill can be gamed in a few instances, such as at the end of the Razuvious fight when damage done to an Understudy becomes very high

	if rIgnore and rIgnore[spellID] then
		-- ignore damage and healing from this effect
	else
		-- let's start the timers
		if sourceNameGUID then
			Recap_CreateCombatantAndUpdateTimers(sourceNameGUID, timestamp, sourceFlags, "Out")
		end
		if destNameGUID then
			Recap_CreateCombatantAndUpdateTimers(destNameGUID, timestamp, destFlags, "In")
		end

		trackAsOutgoing = true
		if sourceNameGUID and destNameGUID then
			-- we don't track the Outgoing component of some damage (self-damage, damage between owner and pet, and damage from one group member to another group member) (otherwise would inflate DPS)
			-- we still track the Incoming component and the Matrix component
			trackAsOutgoing = Recap_TrackAsOutgoing(sourceNameGUID, destNameGUID)
		end
		if sourceNameGUID and trackAsOutgoing then
			iLast = rTemp.Last[sourceNameGUID]
			iLast.DmgOut = iLast.DmgOut + amount
			if amount > iLast.MaxHit then
				iLast.MaxHit = amount
			end
		end

		if destNameGUID then
			iLast = rTemp.Last[destNameGUID]
			iLast.DmgIn = iLast.DmgIn + amount
		end

		-- special case for selected NPC melee (e.g. Vengeful Shade, Blood Beast)
		if sourceNameGUID and specialMelee and (spellName == recap_temp.Localize.Melee) then
			spellName = Recap_NameOnlyFromCombatant(sourceNameGUID).." "..recap_temp.Localize.Melee
		end

		if not rOpt.LightData.value then
			-- determine whether it could have critted
			if string_find(eventType, "PERIODIC", 1, true) then
				-- periodic event, pass 'nil' in the crit and crush and glance slots -- keep these as 'nil', not false
				local critty
				critty = critical or false
				Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 1, amount, 0, nil, 1, schoolName, false, nil, nil, critty, absorbed, blocked, resisted, true, "OutgoingDetail", "IncomingDetail")
				Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 1, amount, 0, nil, 1, schoolName, false, nil, nil, critty, absorbed, blocked, resisted, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
			else
				-- assume all others are crit or crush or glance capable
				local critty, crushy, glancy
				critty = critical or false
				crushy = crushing or false
				glancy = glancing or false
				Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 1, amount, 0, critty, 1, schoolName, false, crushy, glancy, nil, absorbed, blocked, resisted, true, "OutgoingDetail", "IncomingDetail")
				Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 1, amount, 0, critty, 1, schoolName, false, crushy, glancy, nil, absorbed, blocked, resisted, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
			end

			if rOpt.MatrixData.value then
				Recap_AccumulateMatrixDetails((sourceNameGUID or rLocalize.Unknown), (sourceFlags or 0), (destNameGUID or rLocalize.Unknown), (destFlags or 0), 1, amount, timestamp, "TargetDetail", "SourceDetail")
				Recap_AccumulateMatrixDetails((sourceNameGUID or rLocalize.Unknown), (sourceFlags or 0), (destNameGUID or rLocalize.Unknown), (destFlags or 0), 1, amount, timestamp, "LastTargetDetail_"..rTemp.ActiveLastFight, "LastSourceDetail_"..rTemp.ActiveLastFight)
			end

		end

		-- live feed
		if rOpt.LiveData.value then
			Recap_AddLiveData(timestamp, sourceNameGUID, destNameGUID, 1, (amount or 0), 0)
		end
	end

	-- ignored effects will still show up as recent events
	if rOpt.RecentData.value then
		if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 1, spellName, schoolName, amount, critical, crushing, 0)
		end
	end


	-- code for partial absorption by a shield, the absorption becomes healing
	-- we make this appear following the damage event or miss event
	if destNameGUID and absorbed and (absorbed > 0) then
		-- absorption that might be attributable to a shield of some kind
		Recap_AbsorptionEvent(timestamp, destNameGUID, destFlags, absorbed)
	end
end

local function Recap_MissEvent(timestamp, eventType, sourceNameGUID, sourceFlags, specialMelee, destNameGUID, destFlags, spellID, spellName, school, schoolName, missType, amountMissed)

	local rIgnore = _G.recap_ignore
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local sourceCombatant, destCombatant

	if rIgnore and rIgnore[spellID] then
		-- ignore damage and healing from this effect
	else
		-- let's start the timers
		if sourceNameGUID then
			Recap_CreateCombatantAndUpdateTimers(sourceNameGUID, timestamp, sourceFlags, "Out")
		end
		if destNameGUID then
			Recap_CreateCombatantAndUpdateTimers(destNameGUID, timestamp, destFlags, "In")
		end

		-- table lookup shortcuts
		if sourceNameGUID then
			sourceCombatant = rCombatants[sourceNameGUID]
		else
			sourceCombatant = nil
		end
		if destNameGUID then
			destCombatant = rCombatants[destNameGUID]
		else
			destCombatant = nil
		end

		-- special case for selected NPC melee (e.g.  Vengeful Shade, Blood Beast)
		if sourceNameGUID and specialMelee and (spellName == recap_temp.Localize.Melee) then
			spellName = Recap_NameOnlyFromCombatant(sourceNameGUID).." "..recap_temp.Localize.Melee
		end

		if not rOpt.LightData.value then
			if (sourceNameGUID == destNameGUID) then
				-- ignore misses related to self-damage (if any)
			else
				local typeEffect, total
				typeEffect = "1"..spellName
				total = 0
				if sourceCombatant and sourceCombatant.OutgoingDetail and sourceCombatant.OutgoingDetail[typeEffect] then
					local iEffect = sourceCombatant.OutgoingDetail[typeEffect]
					total = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
				end
				local theDetail = "LastOutgoingDetail_"..rTemp.ActiveLastFight
				if sourceCombatant and sourceCombatant[theDetail] and sourceCombatant[theDetail][typeEffect] then
					local iEffect = sourceCombatant[theDetail][typeEffect]
					total = (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
				end
				-- hmm, Arcane Orb (Void Reaver fight) does damage but has no sourceNameGUID, so total from sourceNameGUID is always zero
				-- check whether the target has taken damage from this spellName
				if destCombatant and destCombatant.IncomingDetail and destCombatant.IncomingDetail[typeEffect] then
					local iEffect = destCombatant.IncomingDetail[typeEffect]
					total = total + (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
				end
				local theDetail = "LastIncomingDetail_"..rTemp.ActiveLastFight
				if destCombatant and destCombatant[theDetail] and destCombatant[theDetail][typeEffect] then
					local iEffect = destCombatant[theDetail][typeEffect]
					total = total + (iEffect.GlancesDmg or 0) + (iEffect.HitsDmg or 0) + (iEffect.CritsDmg or 0) + (iEffect.CrushDmg or 0) + (iEffect.TicksDmg or 0)
				end
				if total > 0 then
					-- this spellName has done damage, so count the miss directly
					-- register the miss as a non-crit-capable event -- keep crit and crush and glance as 'nil', not false
					Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 1, 0, 0, nil, nil, schoolName, missType, nil, nil, nil, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
					Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 1, 0, 0, nil, nil, schoolName, missType, nil, nil, nil, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
					if rOpt.RecentData.value then
						-- if this effect is being ignored then no need to record misses
						local missText = (missType or "MISS")
						if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
							Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 1, spellName, schoolName, string_lower(missText), false, false, 0)
						end
					end
				else
					-- this spellName has not done damage, treat it as a miss for any matching cast, debuff, or buff
					-- if this effect is being ignored then no need to record misses
					local missText = (missType or "MISS")
					Recap_CreateMissEffect(sourceNameGUID, destNameGUID, spellName, missText, "OtherDetail")
					Recap_CreateMissEffect(sourceNameGUID, destNameGUID, spellName, missText, "LastOtherDetail_"..rTemp.ActiveLastFight)
				end
			end
		end
	end

	-- register the absorption amount (for a full absorb) for assignment to the healing credit of the source of the shield (if any)
	-- we make the absorption event appear following the damage event or miss event
	if destNameGUID then
		if (missType == "ABSORB") and amountMissed and (amountMissed > 0) then
			-- absorption that might be attributable to a shield of some kind
			amountMissed = Recap_Round0(amountMissed) -- paranoia 5.0.4
			Recap_AbsorptionEvent(timestamp, destNameGUID, destFlags, amountMissed)
		end
	end
end

local function Recap_EnvironmentDamageEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, enviromentalType, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local effect, element, iLast

	-- note that since Environment damage has no spellID provided, Environmental effects cannot be ignored

	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if absorbed then
		absorbed = Recap_Round0(absorbed) -- paranoia 5.0.4
	end

	-- effect name is e.g. "Environment Fire"
	effect = rLocalize.Environment.." "..string_upper(string_sub(enviromentalType,1,1))..string_lower(string_sub(enviromentalType,2))

	-- start the timers
	Recap_CreateCombatantAndUpdateTimers(destNameGUID, timestamp, destFlags, "In")

	if amount and (amount > 0) then
		iLast = rTemp.Last[destNameGUID]
		iLast.DmgIn = iLast.DmgIn + amount

		if not rOpt.LightData.value then
			-- environment effect
			Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, amount, 0, false, nil, schoolName, false, false, false, nil, absorbed, blocked, resisted, true, "OutgoingDetail", "IncomingDetail")
			Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, amount, 0, false, nil, schoolName, false, false, false, nil, absorbed, blocked, resisted, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
		end

		-- live feed
		if rOpt.LiveData.value then
			Recap_AddLiveData(timestamp, "", destNameGUID, 1, (amount or 0), 0)
		end

		if rOpt.RecentData.value then
			if (destNameGUID ~= "") then
				Recap_AddRecentEvent(timestamp, "", destNameGUID, 1, effect, schoolName, amount, false, false, 0)
			end
		end
	else
		-- no actual damage, treat as a miss
		if not rOpt.LightData.value then
			if absorbed and (absorbed > 0) then
				-- entire amount absorbed
				-- register the miss as a non-crit-capable event -- keep crit and crush and glance as 'nil', not false
				-- ( this one happened, an ordinary fire that did 12 damage and was entirely absorbed )
				Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, 0, 0, nil, nil, schoolName, "ABSORB", nil, nil, nil, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
				Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, 0, 0, nil, nil, schoolName, "ABSORB", nil, nil, nil, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
			elseif blocked and (blocked > 0) then
				-- entire amount blocked
				-- ( this might never occur )
				Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, 0, 0, nil, nil, schoolName, "BLOCK", nil, nil, nil, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
				Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, 0, 0, nil, nil, schoolName, "BLOCK", nil, nil, nil, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
			elseif resisted and (resisted > 0) then
				-- entire amount resisted
				-- ( this might never occur )
				Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, 0, 0, nil, nil, schoolName, "RESIST", nil, nil, nil, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
				Recap_CreateEffect(timestamp, false, destNameGUID, effect, nil, 1, 0, 0, nil, nil, schoolName, "RESIST", nil, nil, nil, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
			else
				-- no damage and not a miss
				-- ignore at this time
			end
		end
	end

	-- code for partial absorption by a shield, the absorption becomes healing
	-- we make this appear following the damage event
	if destNameGUID and absorbed and (absorbed > 0) then
		-- absorption that might be attributable to a shield of some kind
		Recap_AbsorptionEvent(timestamp, destNameGUID, destFlags, absorbed)
	end
end

local function Recap_HealEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, overheal, critical)

	local rIgnore = _G.recap_ignore
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rawheal, actualheal, iLast

	rawheal = tonumber(amount)
	if rawheal then
		rawheal = Recap_Round0(rawheal) -- paranoia 5.0.4
	end
	if overheal then
		overheal = Recap_Round0(overheal) -- paranoia 5.0.4
	end

	if rIgnore and rIgnore[spellID] then
		-- ignore damage and healing from this effect
	else
		-- Now keeping an independent timer for healing, and setting the 'WasInCurrent' flag for the healer
		-- Now also start the timers for the recipient of a heal
		if sourceNameGUID then
			Recap_CreateCombatantAndUpdateTimers(sourceNameGUID, timestamp, sourceFlags, "Heal")
		end
		if destNameGUID then
			Recap_CreateCombatantAndUpdateTimers(destNameGUID, timestamp, destFlags, "Heal")
		end

		if rawheal and (rawheal > 0) then

			overheal = math_min(rawheal, overheal) -- paranoia, guard against negative actual healing
			actualheal = rawheal - overheal

			-- two hidden columns, gross healing (RawHeal) and overhealing (OverHeal)
			-- a calculated column, Heal, includes actual healing
			if sourceNameGUID then
				iLast = rTemp.Last[sourceNameGUID]
				iLast.RawHeal = iLast.RawHeal + rawheal
				iLast.OverHeal = math_min((iLast.OverHeal + overheal), iLast.RawHeal)
			end

			if not rOpt.LightData.value then
				-- the effect is credited with the full value of the heal
				-- determine whether it could have critted
				if string_find(eventType, "PERIODIC", 1, true) then
					-- periodic event, pass 'nil' in the crit and crush and glance slots, not false
					local critty
					critty = critical or false
					Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 3, rawheal, overheal, nil, 1, schoolName, false, nil, nil, critty, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
					Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 3, rawheal, overheal, nil, 1, schoolName, false, nil, nil, critty, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
				else
					-- assume all others are crit capable
					local critty
					critty = critical or false
					Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 3, rawheal, overheal, critty, nil, schoolName, false, false, false, nil, nil, nil, nil, true, "OutgoingDetail", "IncomingDetail")
					Recap_CreateEffect(timestamp, sourceNameGUID, destNameGUID, spellName, spellID, 3, rawheal, overheal, critty, nil, schoolName, false, false, false, nil, nil, nil, nil, false, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
				end

				if rOpt.MatrixData.value and (actualheal > 0) then
					Recap_AccumulateMatrixDetails((sourceNameGUID or rLocalize.Unknown), (sourceFlags or 0), (destNameGUID or rLocalize.Unknown), (destFlags or 0), 3, actualheal, timestamp, "TargetDetail", "SourceDetail")
					Recap_AccumulateMatrixDetails((sourceNameGUID or rLocalize.Unknown), (sourceFlags or 0), (destNameGUID or rLocalize.Unknown), (destFlags or 0), 3, actualheal, timestamp, "LastTargetDetail_"..rTemp.ActiveLastFight, "LastSourceDetail_"..rTemp.ActiveLastFight)
				end
			end
		end

		-- live feed
		if rOpt.LiveData.value then
			Recap_AddLiveData(timestamp, sourceNameGUID, destNameGUID, 3, (rawheal or 0), (overheal or 0))
		end
	end

	-- ignored effects will still show up as recent events
	if rawheal and (rawheal > 0) then
		if rOpt.RecentData.value then
			if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
				Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 3, spellName, schoolName, rawheal, critical, false, (overheal or 0))
			end
		end

		-- for each combatant who has died in this fight, a sub-table will help us get the death count as accurate as possible
		-- record the heal associated with Spirit of Redemption
		if destNameGUID and rTemp.Last[destNameGUID] and
		   ((spellID == 27827) or (spellID == 20711) or (spellID == 56176) or (spellID == 99755) or (spellID == 62371) or (spellID == 27795) or (spellID == 27792)) then
			iLast = rTemp.Last[destNameGUID]
			if iLast.DeathEvents == nil then
				iLast.DeathEvents = {}
				iLast.DeathEventsIndex = 1
			end
			iLast.DeathEvents[iLast.DeathEventsIndex] = { Time = timestamp, Type = "SoR" }
			iLast.DeathEventsIndex = iLast.DeathEventsIndex + 1
		end
	end
end

local function Recap_DispatchDeathEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local j, k, g, spot, feignDeath, groupPetDeath, iLast

	-- we often get two death events for a single death, one event with source and one without
	-- Some testing indicated that the event without the source was more reliable, so we're using that one, but we will miss some deaths
	-- With 4.77 it looks as though source is almost always nil.  Policy change to include both flavours and trust that our code 2-second windows sorts it out

	spot = nil
	feignDeath = false
	groupPetDeath = false

	-- check for Feign Death
	if rCombatants[destOwnerNameGUID] and rCombatants[destOwnerNameGUID].Class and rCombatants[destOwnerNameGUID].Class=="HUNTER" then
		if rOpt.IgnoreGUIDs.value then
			-- ignoring GUIDs
			if rTemp.Player == destOwnerNameGUID then
				spot = "player"
			end
			if not spot then
				for j=1,4 do
					k = "party"..j
					if UnitExists(k) then
						if Recap_GetUnitNameRealm(k) == destOwnerNameGUID then
							spot = k
							break
						end
					end
				end
			end
			if not spot then
				for j=1,40 do
					k = "raid"..j
					if UnitExists(k) then
						if Recap_GetUnitNameRealm(k) == destOwnerNameGUID then
							spot = k
							break
						end
					end
				end
			end
		else
			-- using GUIDs (the normal case)
			g = (UnitGUID("player"))
			if g then
				if rTemp.Player.."_"..Recap_TrimGUID(g) == destOwnerNameGUID then
					spot = "player"
				end
			end
			if not spot then
				for j=1,4 do
					k = "party"..j
					if UnitExists(k) then
						g = (UnitGUID(k))
						if g and Recap_TrimGUID(g) and Recap_GetUnitNameRealm(k) then -- Note: 2010-August-03 it is possible on zoning into a Wintergrasp raid group for "Recap_GetUnitNameRealm(k)" to be nil
							if Recap_GetUnitNameRealm(k).."_"..Recap_TrimGUID(g) == destOwnerNameGUID then
								spot = k
								break
							end
						end
					end
				end
			end
			if not spot then
				for j=1,40 do
					k = "raid"..j
					if UnitExists(k) then
						g = (UnitGUID(k))
						if g and Recap_TrimGUID(g) and Recap_GetUnitNameRealm(k) then
							if Recap_GetUnitNameRealm(k).."_"..Recap_TrimGUID(g) == destOwnerNameGUID then
								spot = k
								break
							end
						end
					end
				end
			end
		end
		if spot and UnitExists(spot) then
			-- the dest matches a member of the group
			if UnitIsFeignDeath(spot) then
				-- ignore feign deaths
				feignDeath = true
			else
			end
		end
	end

	-- is this a group pet death ?
	-- may count summoned critters that are not strictly pets
	if (not spot) and rTemp.InGroup[destOwnerNameGUID] and Recap_ExtractOwner(destOwnerNameGUID) then
		groupPetDeath = true

		-- ( we don't remove absorption registration on death, since we need to keep it around for a late shield event )
	end

	-- count real deaths for combatants other than group pets (non-group pets are still counted against their owner's death count)
	if (not feignDeath) and (not groupPetDeath) and destOwnerNameGUID and rTemp.Last[destOwnerNameGUID] then
		rTemp.Last[destOwnerNameGUID].Deaths = rTemp.Last[destOwnerNameGUID].Deaths + 1 -- note that this may be corrected later when we examine the sub-table DeathEvents

		-- ( we don't remove absorption registration on death, since we need to keep it around for a late shield event )
	end

	-- we still include group pet deaths in recent events
	if (not feignDeath) and rOpt.RecentData.value then
		-- effectType 5 is death
		if (destOwnerNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, "", destOwnerNameGUID, 5, rLocalize.Died, "", "", false, false, 0)
		end
	end

	-- for each combatant who has died in this fight, a sub-table will help us get the death count as accurate as possible
	if (not feignDeath) and destOwnerNameGUID and rTemp.Last[destOwnerNameGUID] then
		iLast = rTemp.Last[destOwnerNameGUID]
		if iLast.DeathEvents == nil then
			iLast.DeathEvents = {}
			iLast.DeathEventsIndex = 1
		end
		iLast.DeathEvents[iLast.DeathEventsIndex] = { Time = timestamp, Type = "died" }
		iLast.DeathEventsIndex = iLast.DeathEventsIndex + 1
	end
end

local function Recap_DispatchKillEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags)

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local iLast

	-- because the underlying event partially duplicates the DeathEvent, we have to be sure to not double-count deaths
	-- there is an anomaly, in that this kill event may arrive before the damage event that accomplished it (although time stamps may be identical) (shrug)
	if destOwnerNameGUID and rTemp.Last[destOwnerNameGUID] and destOwnerNameGUID and rTemp.Last[destOwnerNameGUID] then
		if rOpt.RecentData.value then
			-- effectType 5 is death
			if (destOwnerNameGUID ~= "") or (destOwnerNameGUID ~= "") then
				Recap_AddRecentEvent(timestamp, destOwnerNameGUID, destOwnerNameGUID, 5, rLocalize.Killed, "", "", false, false, 0)
			end
		end

		-- for each combatant who has died in this fight, a sub-table will help us get the death count as accurate as possible
		if destOwnerNameGUID and rTemp.Last[destOwnerNameGUID] then
			iLast = rTemp.Last[destOwnerNameGUID]
			if iLast.DeathEvents == nil then
				iLast.DeathEvents = {}
				iLast.DeathEventsIndex = 1
			end
			iLast.DeathEvents[iLast.DeathEventsIndex] = { Time = timestamp, Type = "killed" }
			iLast.DeathEventsIndex = iLast.DeathEventsIndex + 1
		end
	end
end

local function Recap_CreateCastForTicks(thisCombatant, timestamp, flags, effect, direction, doSelf, AllLastOutgoingDetail)
	local rSelf = _G.recap.Self
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local iCombatant = rCombatants[thisCombatant]
	if iCombatant[AllLastOutgoingDetail] and iCombatant[AllLastOutgoingDetail][effect] then
		if (iCombatant[AllLastOutgoingDetail][effect].GlancesDmg) or (iCombatant[AllLastOutgoingDetail][effect].HitsDmg) or
		   (iCombatant[AllLastOutgoingDetail][effect].CritsDmg) or (iCombatant[AllLastOutgoingDetail][effect].CrushDmg) then
			-- this has a direct component, so it is already being counted; do nothing
		else
			if iCombatant[AllLastOutgoingDetail][effect].TicksDmg then
				-- this is the casting of a DoT or Hot (with no direct component), so count it as a hit
				Recap_CreateCombatantAndUpdateTimers(thisCombatant, timestamp, flags, direction)
				iCombatant[AllLastOutgoingDetail][effect].Hits = (iCombatant[AllLastOutgoingDetail][effect].Hits or 0) + 1
				iCombatant[AllLastOutgoingDetail][effect].CritsEvents = (iCombatant[AllLastOutgoingDetail][effect].CritsEvents or 0) + 1
				-- is the thisCombatant the player or one of the player's pets?
				local selfIndex = nil -- keep as nil
				if thisCombatant == rTemp.PlayerGUID then
					selfIndex = rTemp.s
				elseif Recap_IsOwnedBy(thisCombatant, rTemp.PlayerGUID) then
					-- name adjustments
					if Recap_PetsMerged() and rOpt.MergeAllPetsIntoOne.value then
						-- merging all pets into "Pet" or localized equivalent (only if pets are merged)
						selfIndex = rTemp.s..":"..rLocalize.ClassName.Pet
					else
						if Recap_PetsMerged() and iCombatant.DKRaiseDead then
							-- special name in Self panel for death knight ghouls summoned using Raise Dead
							selfIndex = rTemp.s..":"..rLocalize.GhoulMinion
						else
							selfIndex = rTemp.s..":"..Recap_NameOnlyFromCombatant(thisCombatant)
						end
					end
				end

				-- only add to Self when adding to AllFights (otherwise counts twice)
				if selfIndex and doSelf then
					Recap_MakeSelfDetail(selfIndex, effect)
					rSelf[selfIndex][effect].Hits = (rSelf[selfIndex][effect].Hits or 0) + 1
					rSelf[selfIndex][effect].CritsEvents = (rSelf[selfIndex][effect].CritsEvents or 0) + 1
				end
			end
		end
	end
end


-- this registers the aura of a shield, such as Power Word: Shield
-- we ignore the cast of the aura, and register only the appearance of the BUFF on the target
local function Recap_RegisterShieldAura(timestamp, sourceNameGUID, sourceFlags, destNameGUID, spellID, spellName, amount)

	local rCombatants = _G.recap_combatants
	local regDest, regSource

	-- guard
	if not (sourceNameGUID and destNameGUID) then
		return
	end

	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end

	-- if the source casting the shield does not yet exist, create the combatant (might create a few combatants who won't eventually be needed, no big deal)
	if not rCombatants[sourceNameGUID] then
		Recap_CreateBlankCombatant(sourceNameGUID, math_floor(1000*timestamp), sourceFlags)
	end

	-- list for destinations
	if not rShields[destNameGUID] then
		rShields[destNameGUID] = {}
	end
	regDest = rShields[destNameGUID]

	-- sub-list for shield types
	-- these spellID tables will not be deleted even if all their source tables are deleted (takes a bit of memory, avoids thrashing)
	if not regDest[spellID] then
		regDest[spellID] = {}
	end
	regDest = regDest[spellID]

	-- sub-sub-list for sources (allows multiple shields of the same type, but from different sources)
	if not regDest[sourceNameGUID] then
		regDest[sourceNameGUID] = {}
	end
	regSource = regDest[sourceNameGUID]

	-- fresh registration, overwrites whatever was there without checking (we assume Blizzard enforces the rules)
	regSource.SourceTimestamp = timestamp
	regSource.ShieldRemaining = amount
	regSource.SourceFlags = sourceFlags -- needed in case we have to create a combatant later for the source
	regSource.SpellName = spellName -- yes, we know that this is being stored multiple times, once for each source rather than once per spellID
end


-- called for SPELL_AURA_REFRESH events with "shield remaining" amounts
-- this normally allows us to calculate the change in the shield remaining amount, but if the original application of
--   the aura was not detected (out of range, or prior to fight start), we then register the shield too
-- also called for SPELL_AURA_REMOVED events since they often represent additional consumption of the shield
local function Recap_RefreshOrRemoveShieldAura(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, shieldAmount)

	local rIgnore = _G.recap_ignore
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local regDest, regSource

	-- guard
	if not (sourceNameGUID and destNameGUID) then
		return
	end

	-- if the source casting the shield does not yet exist, create the combatant
	if not rCombatants[sourceNameGUID] then
		Recap_CreateBlankCombatant(sourceNameGUID, math_floor(1000*timestamp), sourceFlags)
	end

	if rShields[destNameGUID] and rShields[destNameGUID][spellID] and
	   rShields[destNameGUID][spellID][sourceNameGUID] then
		-- registration for this target / spell / shielder combination already exists
		regDest = rShields[destNameGUID]
		regSource = regDest[spellID][sourceNameGUID]

		-- is there an actual registration?
		if regSource.SourceTimestamp then
			-- has the existing registration expired?
			-- we use a generic 42 second time interval (far too long for shorter shields) to clean up any odd leftover registrations
			-- we could make the time interval a function of the shield, but that would be special case code again, plus there
			--   seems to be a need to have a 12 second grace period anyway, which would make even the short duration shields longish
			if ((timestamp - regSource.SourceTimestamp) < 42) then
				-- current registration, carry on
			else
				-- expired
				regDest[spellID][sourceNameGUID] = nil
			end
		end
	end

	if rShields[destNameGUID] and rShields[destNameGUID][spellID] and
	   rShields[destNameGUID][spellID][sourceNameGUID] then
		-- existing registration, do nothing additional right now
	else
		-- doesn't match an existing registration, treat it as an initial cast (with a very large number since the actual amount is unknown)
		Recap_RegisterShieldAura(timestamp, sourceNameGUID, sourceFlags, destNameGUID, spellID, spellName, 99999999)
	end
	regDest = rShields[destNameGUID]
	regSource = regDest[spellID][sourceNameGUID]

	-- forget any stale-dated absorption amount
	if regDest.AmountAbsorbed and (regDest.AmountAbsorbed > 0) then
		-- Urk, for reasons best known only to Blizzard they can sometimes take at least 7 seconds to emit the REFRESH that corresponds to one or more absorbs
		-- Further, they can sometimes emit the REFRESH event prior to the absorb event(s) to which it corresponds

		if ((timestamp - regDest.DestTimestamp) < 12) then -- 12 second window for aura changes to apply
			-- current absorption amount, carry on
		else
			-- expired, let it go without comment or debug statement, seldom seems to match
			local iSpell, iSource
			for iSpell in pairs(regDest) do
				if type(iSpell) == "number" then
					-- spell, rather than 'AmountAbsorbed' or 'DestTimestamp'
					for iSource in pairs(regDest[iSpell]) do
						-- source
						regSource = regDest[iSpell][iSource]
						if regSource.SourceTimestamp and ((timestamp - regSource.SourceTimestamp) > 42) then
							-- possible source match was stale too, blow it away
							regSource.ShieldRemaining = 0
							regSource.SourceTimestamp = nil
						end
					end
				end
			end

			-- we might choose to attribute the absorption to any registered shields
			-- I have examples where there had not been a proper shield reduction reported by the shield aura events, but we did have a shield with capacity available
			regDest.AmountAbsorbed = 0 -- zero rather than nil, to avoid excess table activity
			regDest.DestTimestamp = nil
		end
	end

	local shieldReduction = (regSource.ShieldRemaining - shieldAmount)
	if shieldReduction < 0 then
		-- this is the shield being increased (e.g. Illuminated Healing), or the overwriting of a shield by a larger one
		-- it is not known if an absorb and an increase might be combined in a single REFRESH to give a misleading change in shield value
		shieldReduction = 0
	end

	-- note that the shieldReduction value for a REMOVED event will sometimes be zero, since it is sometimes preceded by a REFRESH that has the same shieldReduction number

	-- if we have a shieldReduction value of zero, ignore it
	if (shieldReduction > 0) then
		if regDest.AmountAbsorbed and (regDest.AmountAbsorbed > 0) then
			-- we have an absorbed amount for this target that is not yet accounted for
			-- if we have a shieldReduction amount which is greater than the amount which was absorbed, either something is wrong or this is a refresh without a corresponding initial registration
			--   there's not a lot we can do about it, since the missing initial shield application could have happened out of range
			--   credit the entire amount absorbed to this shield, and if that's not right then tough
			-- Note: this code will create a 'healing' event that is delayed with respect to the damage absorption event
			local amountUsed = math_min(shieldReduction, regDest.AmountAbsorbed)
			Recap_CreditAbsorptionAsHealing(timestamp, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, amountUsed, regSource, regDest)

			-- if we have unused shield reduction, make it pending (AmountAbsorbed was adjusted by Recap_CreditAbsorptionAsHealing)
			local amountUnused = shieldReduction - amountUsed
			if amountUnused > 0 then
				regSource.AbsorptionPending = (regSource.AbsorptionPending or 0) + amountUnused
				regSource.AbsorptionPendingTimestamp = timestamp
			end
		else
			-- we have a shield reduction without a corresponding absorption event, create a specific absorption record with a pending amount
			if regSource.AbsorptionPending and (regSource.AbsorptionPending > 0) then
				-- existing amount, has it expired?
				if ((timestamp - regSource.AbsorptionPendingTimestamp) < 12) then -- a pending amount is only carried for 12 seconds
					-- current registration, carry on
				else
					-- expired
					regSource.AbsorptionPending = 0
					regSource.AbsorptionPendingTimestamp = nil
				end
			end

			regSource.AbsorptionPending = (regSource.AbsorptionPending or 0) + shieldReduction
			regSource.AbsorptionPendingTimestamp = timestamp
		end
	end
	-- note that there can be REMOVED events that show a shield reduction of zero when it should be non-zero, and unfortunately we are going to lose that information without credit being assigned


	-- update the shield registration
	-- even if the aura has been removed, we have to keep the registration record around in case there is an AbsorptionPending value
	if (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_AURA_REMOVED") then
		-- refresh the timestamp, since we are using it to govern a window rather than to govern the lifetime of the buff
		regSource.SourceTimestamp = timestamp
		-- refresh with the new (lower or higher) remaining shield amount
		regSource.ShieldRemaining = shieldAmount
		if regSource.ShieldRemaining == 0 then
			regSource.SourceTimestamp = nil
		end
		if (regSource.ShieldRemaining > 0) or (regSource.AbsorptionPending and (regSource.AbsorptionPending > 0)) then
			-- data present, do nothing
		else
			-- no data left, remove the record
			regDest[spellID][sourceNameGUID] = nil
		end
	end
end

local function Recap_CastEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)

	local rIgnore = _G.recap_ignore
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local damageEffect, healEffect

	-- Note that a Cast event does not trigger Recap timers per se
	-- SPELL_CAST_SUCCESS may have a lot of extra noise, such as dismounting, equipping an Argent Dawn commission, etc.

	-- However, if this is the Cast of a known DoT or HoT then it may trigger Recap timers
	if rIgnore and rIgnore[spellID] then
		-- ignore damage and healing from this effect
	else
		if sourceNameGUID and rCombatants[sourceNameGUID] then
			-- we have data for this combatant
			damageEffect = "1"..spellName
			healEffect = "3"..spellName
			if rCombatants[sourceNameGUID].OutgoingDetail and (rCombatants[sourceNameGUID].OutgoingDetail[damageEffect] or rCombatants[sourceNameGUID].OutgoingDetail[healEffect]) then -- no need to check LastOutgoingDetail

				-- this is a cast with which this combatant has done damage or healing before

				-- we used to call Recap_StartFight here, but I now think that's wrong
				-- that could have started a fight with the initial cast of a Prayer of Mending, which is not what we want
				-- this means that fights that start with e.g. a fireball will now be slightly shorter (by the flight time of the fireball)

				-- if the fight is ongoing, start or restart the idle timers
				if (spellID == 145108) then
					-- 2014-May-31: Ysera's Gift (spell ID 145108), a passive healing ability, will not start or extend a fight
					-- do nothing
				else
					if rUser.State=="Active" and rOpt.IdleFight.value then
						rTemp.IdleTimer = 0
					end
					if rUser.State=="Active" then
						rTemp.HiddenIdleTimer = 0
					end

					-- only restart the end of fight timer from zero if a member of the group is involved
					if (sourceNameGUID and rTemp.InGroup[sourceNameGUID]) or (destNameGUID and rTemp.InGroup[destNameGUID]) then
						-- if the fight is ongoing and if the end of fight delay timer is running, restart the end of fight delay timer
						--   (the player left combat, perhaps temporarily, but the fight continues)
						if rUser.State=="Active" and rTemp.EndFightDelayTimer ~= -1 then
							local count = math_max(1+GetNumSubgroupMembers(),GetNumGroupMembers()) -- number in group, 1 if solo, see Recap_JoinLeaveGroup for more comments
							if count == 1 and rOpt.LimitFights.value then
								-- if the player is not in a group, and if "Limit Fights to Combat" is checked, then do not restart the timer (we want the fight to time out as long as the player continues to do nothing)
							else
								if rOpt.LimitToEncounters.value then
									-- if we are limiting to Blizzard encounters, then if we get here the encounter must have ended
									-- so don't reset the timer due to ongoing damage
								else
									-- normally, restart the timer since the fight continues
									--   but only for damage, don't restart for healing
									if rCombatants[sourceNameGUID].OutgoingDetail[damageEffect] then
										rTemp.EndFightDelayTimer = 0
									end
								end
							end
						end
					end
				end

				-- perhaps add the combatant into the fight, and update timers
				-- this takes the time from the moment of successful cast, rather than from when it strikes the target
				if rCombatants[sourceNameGUID].OutgoingDetail[damageEffect] then		-- no need to check LastOutgoingDetail
					Recap_CreateCastForTicks(sourceNameGUID, timestamp, sourceFlags, damageEffect, "Out", true, "OutgoingDetail")
					Recap_CreateCastForTicks(sourceNameGUID, timestamp, sourceFlags, damageEffect, "Out", false, "LastOutgoingDetail_"..rTemp.ActiveLastFight)
				end

				-- for heals, similarly
				if rCombatants[sourceNameGUID].OutgoingDetail[healEffect] then		-- no need to check LastOutgoingDetail
					Recap_CreateCastForTicks(sourceNameGUID, timestamp, sourceFlags, healEffect, "Heal", true, "OutgoingDetail")
					Recap_CreateCastForTicks(sourceNameGUID, timestamp, sourceFlags, healEffect, "Heal", false, "LastOutgoingDetail_"..rTemp.ActiveLastFight)
				end
			end
		end

		if destNameGUID and rCombatants[destNameGUID] then
			if (not rOpt.LightData.value) and rOpt.OtherData.value then
				-- we don't know whether a 'cast' event with a destNameGUID is a buff or a debuff, so insert it as an unknown (will be coloured white)
				-- 'cast' events sometimes overlap with buffs and debuffs, so there will be some double counting
				Recap_CreateFullOtherDetail(destNameGUID, timestamp, "7", spellName, spellID, 1, nil, "OtherDetail")
				Recap_CreateFullOtherDetail(destNameGUID, timestamp, "7", spellName, spellID, 1, nil, "LastOtherDetail_"..rTemp.ActiveLastFight)
			end
		end
	end


	-- ignored effects will still show up as casts
	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- we have data for this combatant
		-- at risk of adding a tonne of duplicate events, and a tonne of non-combat events, record this spell as an Other event
		-- this is needed to (approximately) count the initial casts of Prayer of Mending, which would otherwise often be ignored since they do healing later
		if (not rOpt.LightData.value) and rOpt.OtherData.value then
			Recap_CreateBasicOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, "OtherDetail")
			Recap_CreateBasicOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, "LastOtherDetail_"..rTemp.ActiveLastFight)
		end
	end
end

local function Recap_SummonOrCreateEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	-- Note that a Summon or Create event does not trigger Recap timers, but could create new combatants

	if sourceNameGUID and rCombatants[sourceNameGUID] then
		if (not rOpt.LightData.value) and rOpt.OtherData.value then
			-- the summon or create is an Other event similar to a Cast, so track only if Other Data mode is enabled
			Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "5", spellName, spellID, 1, rLocalize.Entities, "OtherDetail")
			Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "5", spellName, spellID, 1, rLocalize.Entities, "LastOtherDetail_"..rTemp.ActiveLastFight)
		end
	end

	if destNameGUID and sourceNameGUID then
		-- this could be (for example) summoning a Water Elemental or creating a Magma Totem
		-- treat as the creation of a new pet (with same 'Friend' status as its owner)
		-- note that destFlags does not yet include the controlled pet flags, so we insert the controlled object flag
		-- the flags may later be overwritten with a set of flags indicating either controlled or uncontrolled (go figure) (this could produce incorrect death counts if they die while marked as uncontrolled)
		-- with patch 3.3.5 we have a report of sourceNameGUID being nil, so simply ignore such a summon until the pet or object shows up in some other context
		local petDestFlags = bit_bor(destFlags, COMBATLOG_OBJECT_TYPE_OBJECT)
		if (spellID == 46584) or (spellID == 46585) or (spellID == 52150) then -- spellIDs for Raise Dead (not sure that I have them all) (caution: there are non-Death-Knight spells with same name)
			-- special code to flag a death knight ghoul summoned using Raise Dead, so that we can amalagamate them later (they can have multiple names)
			-- if we don't witness the Raise Dead then the pet will not be flagged (Recap_AddFriend will note the pet but does not know where it came from, so tracks it under its own name)
			-- Note: the 46584 and 46585 are probably the casts, not the summonses (they have different IDs), and will probably not appear in this context
			Recap_CreatePet(destNameGUID, petDestFlags, sourceNameGUID, sourceFlags, ((sourceNameGUID and rCombatants[sourceNameGUID] and rCombatants[sourceNameGUID].Friend) or false), math_floor(1000*timestamp), true)
		else
			if (spellID == 71264) or (spellID == 71266) or (spellID == 71267) or -- spellIDs for Swarming Shadows
			   (spellID == 105297) or (spellID == 105313) then -- spellIDs for Ice Lance
				-- these appear to be summons imposed on a player by a boss, so to reduce thrashing don't create them as pets since they are actually hostile even though summoned by the player
				-- add an entry for the NPC, if necessary
				if not rCombatants[destNameGUID] then
					Recap_CreateBlankCombatant(destNameGUID, math_floor(1000*timestamp), destFlags)
				end
				if not rTemp.Last[destNameGUID] then
					Recap_InitializeLastFight(destNameGUID)
				end
			else
				-- standard code
				Recap_CreatePet(destNameGUID, petDestFlags, sourceNameGUID, sourceFlags, ((sourceNameGUID and rCombatants[sourceNameGUID] and rCombatants[sourceNameGUID].Friend) or false), math_floor(1000*timestamp), false)

				-- 2014 June: special case code for Mirror Image, in which the SUMMON is of a pet named "Mirror Image" but the pet is actually named the same as the caster
				-- ah, even more interesting, sometimes at the very beginning or very end of the pet's life, it may actually be named "Mirror Image" by Blizzard (same GUID)
				-- so we need to create *two* pets, one for each name -- if one doesn't do damage or take healing, it will be ignored
				if eventType == "SPELL_SUMMON" then
					if (spellID == 58831) or (spellID == 58833) or (spellID == 58834) or -- the cast is 55342 or perhaps 58832
					   (spellID == 88086) or (spellID == 88088) or (spellID == 88090) or -- the cast is 88092
					   (spellID == 88085) or (spellID == 88087) or (spellID == 88089) or -- the cast is 88091
					   (spellID == 110685) or (spellID == 110686) or (spellID == 110687) then -- the cast is 110684
						-- this is a summon using Mirror Image, create a new destNameGUID from caster's name and pet's GUID
						-- if no GUID, don't try to create a pet with the same name as its owner
						local iGUID = Recap_GUIDFromNameGUID(destNameGUID)
						if iGUID then
							Recap_CreatePet(Recap_NameFromNameGUID(sourceNameGUID).."_"..iGUID, petDestFlags, sourceNameGUID, sourceFlags, ((sourceNameGUID and rCombatants[sourceNameGUID] and rCombatants[sourceNameGUID].Friend) or false), math_floor(1000*timestamp), false)
						end
					end
				end
			end
		end
	end
end

local function Recap_GainEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, powerType, powerName)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	-- Note that a Gain event does not trigger Recap timers

	-- it looks as though we can ignore schoolName (the spell might be a Nature spell but the gain is Mana)
	-- we are ignoring any distinction between PERIODIC and non-PERIODIC
	if destNameGUID and rCombatants[destNameGUID] then
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "5", spellName, spellID, amount, powerName, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "5", spellName, spellID, amount, powerName, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
end

local function Recap_DrainEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, powerType, powerName, extraAmount)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	-- Note that a Drain event does not trigger Recap timers

	if destNameGUID and rCombatants[destNameGUID] then
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "3", spellName, spellID, amount, powerName, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "3", spellName, spellID, amount, powerName, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
end

local function Recap_LeechEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, powerType, powerName, extraAmount)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	-- Note that a Leech event does not trigger Recap timers

	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- this is the implicit 'cast' from the sourceNameGUID
		Recap_CreateBasicOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, "OtherDetail")
		Recap_CreateBasicOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- this is the beneficiary of the leech
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "5", spellName, spellID, amount, powerName, "OtherDetail")
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "5", spellName, spellID, amount, powerName, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
	if destNameGUID and rCombatants[destNameGUID] then
		-- this is the loser from the leech
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "3", spellName, spellID, extraAmount, powerName, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "3", spellName, spellID, extraAmount, powerName, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
end

local function Recap_ExtraAttackEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	-- Note that an Extra Attack event does not trigger Recap timers

	if destNameGUID and rCombatants[destNameGUID] then
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "5", spellName, spellID, amount, rLocalize.Attacks, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "5", spellName, spellID, amount, rLocalize.Attacks, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
end

local function Recap_BuffOrDebuffEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, auraType, doseAmount, countAsCastForSource)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local wasControlled, isControlled

	-- Note that a Buff or Debuff event does not trigger Recap timers
	-- this is where mind-control spells come (but unfortunately they don't include both source and dest)

	if rOpt.LightData.value or not rOpt.OtherData.value then
		-- only track as Other events if not in Light Data Mode, and with the Other Data Mode enabled
		return
	end

	-- added 2010-June-02 to record casts of Polymorph and similar (will multi-count some types of cast) (e.g. for buff spells which have SPELL_CAST_SUCCESS events this will show up as N+1 casts where N is the number buffed) (I could write special case code to treat the two types separately, but I don't think it would be worth it)
	if countAsCastForSource and sourceNameGUID and rCombatants[sourceNameGUID] then
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, amount, nil, "OtherDetail")
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, amount, nil, "LastOtherDetail_"..rTemp.ActiveLastFight)
	else
		-- buffs and debuffs are not recorded before sourceNameGUID has been registered as a combatant (i.e. as a result of healing, dealing damage, or taking damage)
	end

	if destNameGUID and rCombatants[destNameGUID] then
		local myType
		if auraType == "BUFF" then
			myType = "5"
		else
			myType = "3"
		end
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, myType, spellName, spellID, amount, nil, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, myType, spellName, spellID, amount, nil, "LastOtherDetail_"..rTemp.ActiveLastFight)
	else
		-- buffs and debuffs (other than shields) are not recorded before destNameGUID has been registered as a combatant (i.e. as a result of healing, dealing damage, or taking damage)
	end
end

local function Recap_RemoveEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, auraType, doseAmount)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local typeEffect

	-- Note that a Buff or Debuff Removed event does not trigger Recap timers

	if rOpt.LightData.value or not rOpt.OtherData.value then
		-- only track as Other events if not in Light Data Mode, and with the Other Data Mode enabled
		return
	end

	-- we ignore de-stacking events
	if destNameGUID and rCombatants[destNameGUID] then
		-- look for the matching buff or debuff
		if auraType == "BUFF" then
			typeEffect = "5"..spellName
		else
			typeEffect = "3"..spellName
		end
		if rCombatants[destNameGUID].OtherDetail and rCombatants[destNameGUID].OtherDetail[typeEffect] then
			-- Removal of a buff or debuff implies that it has run out, so mark its end and calculate a duration
			Recap_CalcOtherDuration(rCombatants[destNameGUID].OtherDetail[typeEffect], timestamp)
		end
		local theDetail = "LastOtherDetail_"..rTemp.ActiveLastFight
		if rCombatants[destNameGUID][theDetail] and rCombatants[destNameGUID][theDetail][typeEffect] then
			-- Removal of a buff or debuff implies that it has run out, so mark its end and calculate a duration
			Recap_CalcOtherDuration(rCombatants[destNameGUID][theDetail][typeEffect], timestamp)
		end
	end
end

local function Recap_DispelEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName, auraType)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local typeEffect

	-- Note that a Dispel event does not trigger Recap timers

	if sourceNameGUID and rTemp.Last and rTemp.Last[sourceNameGUID] then
		-- a dispel is credited to the person doing the dispelling
		rTemp.Last[sourceNameGUID].Dispels = (rTemp.Last[sourceNameGUID].Dispels or 0) + 1
	end

	-- put the dispel information into Recent events
	if rOpt.RecentData.value and sourceNameGUID and rCombatants[sourceNameGUID] then
		-- effectType 6 is dispel (the ones without a source appear to be uninteresting)
		if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 6, spellName, extraSpellName, "", false, false, 0)
		end
	end

	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		-- only track as Other events if not in Light Data Mode, and with the Other Data Mode enabled
		-- the aura being dispelled is extraSpellName, and the dispelling or breaking is being done by spellName
		if sourceNameGUID and rCombatants[sourceNameGUID] and spellName then
			-- we treat this as an unknown event since we can't tell whether dispelling the aura is a good thing or a bad thing
			-- this can include things like a DoT breaking a shackle
			Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "7", spellName, spellID, 1, rLocalize.Dispels, "OtherDetail")
			Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "7", spellName, spellID, 1, rLocalize.Dispels, "LastOtherDetail_"..rTemp.ActiveLastFight)
		end
		if destNameGUID and rCombatants[destNameGUID] and extraSpellName then
			-- we treat this as an unknown event since we can't tell whether getting dispelled is a good thing or a bad thing
			Recap_CreateFullOtherDetail(destNameGUID, timestamp, "7", extraSpellName, extraSpellId, 1, rLocalize.Dispelled, "OtherDetail")
			Recap_CreateFullOtherDetail(destNameGUID, timestamp, "7", extraSpellName, extraSpellId, 1, rLocalize.Dispelled, "LastOtherDetail_"..rTemp.ActiveLastFight)
		end
		if destNameGUID and rCombatants[destNameGUID] then
			-- look for the matching buff or debuff
			if auraType == "BUFF" then
				typeEffect = "5"..extraSpellName
			else
				typeEffect = "3"..extraSpellName
			end
			if rCombatants[destNameGUID].OtherDetail and rCombatants[destNameGUID].OtherDetail[typeEffect] then
				rCombatants[destNameGUID].OtherDetail[typeEffect].Dispels = (rCombatants[destNameGUID].OtherDetail[typeEffect].Dispels or 0) + 1
			end
			local theDetail = "LastOtherDetail_"..rTemp.ActiveLastFight
			if rCombatants[destNameGUID][theDetail] and rCombatants[destNameGUID][theDetail][typeEffect] then
				rCombatants[destNameGUID][theDetail][typeEffect].Dispels = (rCombatants[destNameGUID][theDetail][typeEffect].Dispels or 0) + 1
			end
		end
	end
end

-- a new event type that wasn't handled before patch 2.4
local function Recap_StealEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName, auraType)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local typeEffect, iDetail

	-- Note that a Steal event does not trigger Recap timers

	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		-- only track as Other events if not in Light Data Mode, and with the Other Data Mode enabled
		-- the aura being stolen is extraSpellName, and the stealing is being done by spellName
		if sourceNameGUID and rCombatants[sourceNameGUID] and extraSpellName then
			-- for consistency with the dispelling (intentional or otherwise), we report this intentional stealing as an unknown
			Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "7", spellName, spellID, 1, rLocalize.Steals, "OtherDetail")
			Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "7", spellName, spellID, 1, rLocalize.Steals, "LastOtherDetail_"..rTemp.ActiveLastFight)
		end
		if destNameGUID and rCombatants[destNameGUID] then
			-- look for the matching buff or debuff
			if auraType == "BUFF" then
				typeEffect = "5"..extraSpellName
			else
				typeEffect = "3"..extraSpellName
			end
			if rCombatants[destNameGUID].OtherDetail and rCombatants[destNameGUID].OtherDetail[typeEffect] then
				rCombatants[destNameGUID].OtherDetail[typeEffect].Steals = (rCombatants[destNameGUID].OtherDetail[typeEffect].Steals or 0) + 1
			end
			local theDetail = "LastOtherDetail_"..rTemp.ActiveLastFight
			if rCombatants[destNameGUID][theDetail] and rCombatants[destNameGUID][theDetail][typeEffect] then
				rCombatants[destNameGUID][theDetail][typeEffect].Steals = (rCombatants[destNameGUID][theDetail][typeEffect].Steals or 0) + 1
			end
		end
	end
end

local function Recap_InterruptEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp

	-- Note that an Interrupt event does not trigger Recap timers

	if sourceNameGUID and rTemp.Last and rTemp.Last[sourceNameGUID] then
		-- an interrupt is credited to the person doing the interrupting
		rTemp.Last[sourceNameGUID].Interrupts = (rTemp.Last[sourceNameGUID].Interrupts or 0) + 1
	end

	-- put the interrupt information into Recent events
	if rOpt.RecentData.value and sourceNameGUID and rCombatants[sourceNameGUID] then
		-- effectType 7 is interrupt (I'm assuming without checking that as for dispel, the ones without a source are uninteresting)
		if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 7, spellName, extraSpellName, "", false, false, 0)
		end
	end

	-- spellName does the interrupting, extraSpellName is what gets interrupted
	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- we treat this as an unknown event since we can't tell whether interrupting is a good thing or a bad thing
		-- besides, it is consistent with 'Dispels' (as 'Interrupts')
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "7", spellName, spellID, 1, rLocalize.Interrupts, "OtherDetail")
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "7", spellName, spellID, 1, rLocalize.Interrupts, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
	if destNameGUID and rCombatants[destNameGUID] then
		-- treat an incoming interrupt in a similar way (as 'Interrupted')
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "7", extraSpellName, extraSpellId, 1, rLocalize.Interrupted, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "7", extraSpellName, extraSpellId, 1, rLocalize.Interrupted, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
end

local function Recap_DurabilityEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp

	-- Note that a Buff or Debuff event does not trigger Recap timers

	if sourceNameGUID and rCombatants[sourceNameGUID] then
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, 1, rLocalize.Durability, "OtherDetail")
		Recap_CreateFullOtherDetail(sourceNameGUID, timestamp, "1", spellName, spellID, 1, rLocalize.Durability, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
	if destNameGUID and rCombatants[destNameGUID] then
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "3", spellName, spellID, 1, rLocalize.Durability, "OtherDetail")
		Recap_CreateFullOtherDetail(destNameGUID, timestamp, "3", spellName, spellID, 1, rLocalize.Durability, "LastOtherDetail_"..rTemp.ActiveLastFight)
	end
end

-- the following three functions are only called for dispel type events
local function Recap_DispelCastStartEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt

	if rOpt.RecentData.value and sourceNameGUID and rCombatants[sourceNameGUID] then
		-- we have data for this combatant
		-- record as a recent event
		-- effectType 8 is cast start (dispel, since we only call here for dispels)
		if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 8, spellName, "", "", false, false, 0)
		end
	end
end
local function Recap_DispelCastFailedEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, missType)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt

	if rOpt.RecentData.value and sourceNameGUID and rCombatants[sourceNameGUID] then
		-- we have data for this combatant
		-- record as a recent event
		-- effectType 9 is cast fail (dispel, since we only call here for dispels) (slightly ambiguous with dispel fail)
		if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 9, spellName, missType, "", false, false, 0)
		end
	end
end
local function Recap_DispelFailedEvent(timestamp, eventType, sourceNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName)

	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt

	if rOpt.RecentData.value and sourceNameGUID and rCombatants[sourceNameGUID] then
		-- we have data for this combatant
		-- record as a recent event
		-- effectType 9 is dispel fail (dispel, since we only call here for dispels) (slightly ambiguous with cast fail)
		if (sourceNameGUID ~= "") or (destNameGUID ~= "") then
			Recap_AddRecentEvent(timestamp, sourceNameGUID, destNameGUID, 9, spellName, extraSpellName, "", false, false, 0)
		end
	end
end


--[[ global functions ]]

function Recap_StartFight()

	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rGraph = _G.recap_temp.Graph
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local i, iFriend, overhealing

	if rOpt.AutoHide.value and not rUser.Minimized then
		RecapFrame_Hide()
		RecapPanel_Hide(1)
		RecapRecent_Hide(1)
		RecapLoad_Hide()
		RecapOptFrame:Hide()
	end

	rTemp.SkipPeriodicUpdate = true -- skip periodic update

	-- check group at start of fight to get group pet information.
	Recap_MakeFriends(true)

	-- determine the instance difficulty (but only if in an instance)
	if IsInInstance() then
		rTemp.InstanceDifficulty = Recap_GetInstanceDifficulty()
	else
		-- not in an instance, call it "Other"
		rTemp.InstanceDifficulty = 15
	end

	-- only clear WasInCurrent once per fight (also used for other once-per-fight actions)
	if not rTemp.ResetWasInCurrent then

		for i in pairs(rCombatants) do
			if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
				rCombatants[i].WasInCurrent = false
			end
		end

		-- clear list of player pets who are active in the last fight
		rTemp.LastPlayerPets = wipe(rTemp.LastPlayerPets)

		-- clear any existing synchronization update data (done outside the spinlock, I'm hoping that's safe)
		rTemp.SyncData = wipe(rTemp.SyncData)

		-- pre-calculate some numbers that will be used for live update calculations
		rTemp.TotalGroupDmgIn = 0
		rTemp.TotalGroupDmgOut = 0
		rTemp.TotalGroupHeal = 0
		for i in pairs(rTemp.InFriend) do
			iFriend = rCombatants[i]
			if iFriend then
				rTemp.TotalGroupDmgIn = rTemp.TotalGroupDmgIn + (iFriend.TotalDmgIn or 0)
				rTemp.TotalGroupDmgOut = rTemp.TotalGroupDmgOut + (iFriend.TotalDmgOut or 0)
				overhealing = math_min((iFriend.TotalOverHeal or 0), (iFriend.TotalRawHeal or 0))
				rTemp.TotalGroupHeal = rTemp.TotalGroupHeal + (iFriend.TotalRawHeal or 0) - overhealing
			end
		end

		-- mark that we've now done this once-only stuff
		rTemp.ResetWasInCurrent = true
	end

	-- start idle timers
	if not rOpt.LimitFights.value and rOpt.IdleFight.value then
		rTemp.IdleTimer = 0
	end
	if not rOpt.LimitFights.value then
		rTemp.HiddenIdleTimer = 0
	end

	-- make sure end of fight delay timer is off
	rTemp.EndFightDelayTimer = -1

	-- turn off flags (don't need to check whether we are in Live Data Mode)
	rGraph.GroupInvolved = false
	rGraph.FightSignificant = false

	-- update graph option lists at the start of a fight (unless paused)
	if rOpt.LiveData.value then
		RecapGraph_UpdateLiveLists()
	end

	-- resume periodic update
	rTemp.SkipPeriodicUpdate = false

	Recap_SetState("Active")
end


-- used to remove pet effects when Merge Pets has been set to off, after having been on
function Recap_RemovePetEffects()

	local rSelf = _G.recap.Self
	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local i, j, iCombatant, effectNum

	for i, iCombatant in pairs(rCombatants) do
		if (i ~= rTemp.GroupTotal) and (i ~= rTemp.NonGroupTotal) then
			if iCombatant.OutgoingDetail then
				for j in pairs(iCombatant.OutgoingDetail) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.OutgoingDetail[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.TargetDetail then
				for j in pairs(iCombatant.TargetDetail) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") then
						iCombatant.TargetDetail[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.IncomingDetail then
				for j in pairs(iCombatant.IncomingDetail) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.IncomingDetail[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.SourceDetail then
				for j in pairs(iCombatant.SourceDetail) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") then
						iCombatant.SourceDetail[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.OtherDetail then
				for j in pairs(iCombatant.OtherDetail) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.OtherDetail[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastOutgoingDetail_1 then
				for j in pairs(iCombatant.LastOutgoingDetail_1) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.LastOutgoingDetail_1[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastTargetDetail_1 then
				for j in pairs(iCombatant.LastTargetDetail_1) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") then
						iCombatant.LastTargetDetail_1[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastIncomingDetail_1 then
				for j in pairs(iCombatant.LastIncomingDetail_1) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.LastIncomingDetail_1[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastSourceDetail_1 then
				for j in pairs(iCombatant.LastSourceDetail_1) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") then
						iCombatant.LastSourceDetail_1[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastOtherDetail_1 then
				for j in pairs(iCombatant.LastOtherDetail_1) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.LastOtherDetail_1[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastOutgoingDetail_2 then
				for j in pairs(iCombatant.LastOutgoingDetail_2) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.LastOutgoingDetail_2[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastTargetDetail_2 then
				for j in pairs(iCombatant.LastTargetDetail_2) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") then
						iCombatant.LastTargetDetail_2[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastIncomingDetail_2 then
				for j in pairs(iCombatant.LastIncomingDetail_2) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.LastIncomingDetail_2[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastSourceDetail_2 then
				for j in pairs(iCombatant.LastSourceDetail_2) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") then
						iCombatant.LastSourceDetail_2[j] = nil -- keep as nil
					end
				end
			end
			if iCombatant.LastOtherDetail_2 then
				for j in pairs(iCombatant.LastOtherDetail_2) do
					effectNum = string_sub(j,1,1)
					if (effectNum == "2") or (effectNum == "4") or (effectNum == "6") or (effectNum == "8") then
						iCombatant.LastOtherDetail_2[j] = nil -- keep as nil
					end
				end
			end
		end
	end
end


function Recap_EndFight(forceEnd)

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local i, j, k, iCombatant, iLast, incomingState
	local iDurationOut, iDurationIn, iDurationHeal

	-- turn off idle and end of fight delay timers
	rTemp.IdleTimer = -1
	rTemp.HiddenIdleTimer = -1
	rTemp.EndFightDelayTimer = -1
	rTemp.EndSyncDelayTimer = -1

	-- clear boss list
	rTemp.BossList = ""

	incomingState = rUser.State
	if forceEnd or (incomingState == "Active") then

		local function_start_time = GetTime() -- GetTime only updates every frame display, so no use for subroutine internal timing
		debugprofilestart() -- start internal timer

		rTemp.SkipPeriodicUpdate = true -- skip periodic update

		Recap_MakeFriends(true)

		rUser.State = "Stopped" -- suspend logging to calculate

		-- update the maximum instance difficulty (but only if in an instance)
		if IsInInstance() then
			rTemp.InstanceDifficulty = Recap_GetInstanceDifficulty()
		end

		if rUser.SkipNextFight == true then
			-- we are skipping this fight, so do a whole bunch of nothing
			-- we might have recorded some data before setting the flag, so clear any data that is lying around
			for i, iLast in pairs(rTemp.Last) do
				iCombatant = rCombatants[i]
				iCombatant.WasInCurrent = false
				iLast.StartOut = 0
				iLast.EndOut = 0
				iLast.StartIn = 0
				iLast.EndIn = 0
				iLast.StartHeal = 0
				iLast.EndHeal = 0
				iLast.DmgIn = 0
				iLast.DmgOut = 0
				iLast.PetsDmgOut = 0
				iLast.MaxHit = 0
				iLast.Deaths = 0
				if iLast.DeathEvents then
					iLast.DeathEvents = nil
					iLast.DeathEventsIndex = nil
				end
				iLast.Dispels = 0
				iLast.Interrupts = 0
				iLast.RawHeal = 0
				iLast.OverHeal = 0
				-- Last Fight details are not cleared at this time
			end
			-- prevent switching last fight pointers
			rTemp.LastFightSignificant = false
		else
			-- do the regular end of fight stuff

			-- adjust the end fight GetTime() to match the Blizzard timestamp clock
			local adjusted_function_start_time = function_start_time
			if (rTemp.TimestampDeltaCount > 0) then
				adjusted_function_start_time = function_start_time + (rTemp.TimestampDeltaSum / rTemp.TimestampDeltaCount)
			end

			-- remove any very stale shield absorption registrations
			local iDest, regDest, regSource
			for iDest in pairs(rShields) do
				regDest = rShields[iDest]
				if regDest.DestTimestamp and ((adjusted_function_start_time - regDest.DestTimestamp) > 54) then
					-- very stale, delete
					regDest.AmountAbsorbed = 0 -- zero rather than nil to avoid excess thrashing
					regDest.DestTimestamp = nil
				end
				local iSpell, iSource
				for iSpell in pairs(regDest) do
					if type(iSpell) == "number" then
						-- spell, rather than 'AmountAbsorbed' or 'DestTimestamp'
						for iSource in pairs(regDest[iSpell]) do
							-- source
							regSource = regDest[iSpell][iSource]
							if regSource.SourceTimestamp and ((adjusted_function_start_time - regSource.SourceTimestamp) > 54) then
								-- very stale, delete
								regSource.ShieldRemaining = 0 -- zero rather than nil to avoid excess thrashing
								regSource.SourceTimestamp = nil
							end
						end
					end
				end
			end

			-- calculate the live dps and hps numbers one last time
			-- note that this will not include any synchronization updates, which happen later
			Recap_UpdateMinimizedDPS()
			Recap_DisplayMinimizedDPS() -- also sends to plugins

			-- merge pets if appropriate
			if Recap_PetsMerged() then
				-- add all pets to all ultimate owners
				-- data was tracked during a fight to the current ultimate owner, so amalgamate only to the first owner in any string of owners
				-- an entity doing something on its own behalf (when not controlled, and when Recap can work out that it wasn't controlled) will have data of its own
				-- there is a definite benefit to doing this at the end of the fight rather than during the fight, since during the fight ownership may not always be known properly
				for i in pairs(rTemp.Last) do
					if rCombatants[i].WasInCurrent then
						j = Recap_ExtractOwner(i)
						if j then
							Recap_AddPetToOwner(i, j) -- assert: clears pet's WasInCurrent, sets owner's WasInCurrent
							-- the details are always added from the last fight into the owner all fights and into the owner last fight
							k = rTemp.ActiveLastFight
							Recap_AddPetDetailsToOwner(i, j, "OutgoingDetail", "IncomingDetail", "OtherDetail", "TargetDetail", "SourceDetail",
															 "LastOutgoingDetail_"..k, "LastIncomingDetail_"..k, "LastOtherDetail_"..k, "LastTargetDetail_"..k, "LastSourceDetail_"..k)
							Recap_AddPetDetailsToOwner(i, j, "LastOutgoingDetail_"..k, "LastIncomingDetail_"..k, "LastOtherDetail_"..k, "LastTargetDetail_"..k, "LastSourceDetail_"..k,
															 "LastOutgoingDetail_"..k, "LastIncomingDetail_"..k, "LastOtherDetail_"..k, "LastTargetDetail_"..k, "LastSourceDetail_"..k)
						end
					end
				end
			end

			-- scan all combatants in Last to see if any dealt or took damage for more than the significant time
			--   If so, then we will update combatant Last Fight information
			--   If not, we won't update combatant Last Fight information, but we will still accumulate to the All Fights information
			rTemp.LastFightSignificant = false
			for i, iLast in pairs(rTemp.Last) do
				iCombatant = rCombatants[i]
				if iCombatant.WasInCurrent then
					if (iLast.DmgOut > 0) and (iLast.StartOut > 0) and ((iLast.EndOut - iLast.StartOut) > rTemp.LastFightSignificantTime) then
						-- damage dealt, for more than the significant time
						rTemp.LastFightSignificant = true
						break
					end
					if (iLast.DmgIn > 0) and (iLast.StartIn > 0) and ((iLast.EndIn - iLast.StartIn) > rTemp.LastFightSignificantTime) then
						-- damage taken, for more than the significant time
						rTemp.LastFightSignificant = true
						break
					end
				end
			end

			-- if we are going to have fresh Last Fight data, clear all WasInLast values
			if rTemp.LastFightSignificant then
				for i in pairs(rCombatants) do
					rCombatants[i].WasInLast = false
				end
			end

			if rTemp.LastFightSignificant then
				-- calculate bosses here while we still have 'last fight' data, and save the value for use later
				rTemp.BossList = Recap_BossList()
				if (rTemp.BossList ~= "") then
					print("(Recap) Boss or bosses present in last fight:", rTemp.BossList)
				end
			end

			-- accumulate all combatants who were in the Last Fight
			for i, iLast in pairs(rTemp.Last) do
				iCombatant = rCombatants[i]
				if iCombatant.WasInCurrent then
					-- this could accumulate e.g. Totems who really should be getting added to their owners via a compound name
					Recap_AccumulateCombatant(i, iCombatant, iLast) -- assert: clears WasInCurrent, sets WasInLast if LastFightSignificant

					-- special case correction for some dual damage / healing tickers
					Recap_CorrectDualDoTHoT(iCombatant, "OutgoingDetail", "IncomingDetail")
					Recap_CorrectDualDoTHoT(iCombatant, "LastOutgoingDetail_"..rTemp.ActiveLastFight, "LastIncomingDetail_"..rTemp.ActiveLastFight)
				end
				-- ensure that every combatant has their 'Last' record cleared, even if not in current fight
				iLast.StartOut = 0
				iLast.EndOut = 0
				iLast.StartIn = 0
				iLast.EndIn = 0
				iLast.StartHeal = 0
				iLast.EndHeal = 0
				iLast.DmgIn = 0
				iLast.DmgOut = 0
				iLast.PetsDmgOut = 0
				iLast.MaxHit = 0
				iLast.Deaths = 0
				if iLast.DeathEvents then
					iLast.DeathEvents = nil
					iLast.DeathEventsIndex = nil
				end
				iLast.Dispels = 0
				iLast.Interrupts = 0
				iLast.RawHeal = 0
				iLast.OverHeal = 0

				-- Last Fight details are not cleared at this time
			end

			-- update the overall (All Fights) durations (for group only)
			if rTemp.FightStart>0 and (rTemp.FightEnd > rTemp.FightStart) then
				iDurationOut = rTemp.FightEnd - rTemp.FightStart
			else
				iDurationOut = 0
			end
			if rTemp.FightStartIn>0 and (rTemp.FightEndIn > rTemp.FightStartIn) then
				iDurationIn = rTemp.FightEndIn - rTemp.FightStartIn
			else
				iDurationIn = 0
			end
			if rTemp.FightStartHeal>0 and (rTemp.FightEndHeal > rTemp.FightStartHeal) then
				iDurationHeal = rTemp.FightEndHeal - rTemp.FightStartHeal
			else
				iDurationHeal = 0
			end
			if rTemp.LastFightSignificant then
				rUser.LastDuration = iDurationOut
				rUser.LastDurationIn = iDurationIn
				rUser.LastDurationHeal = iDurationHeal
			end
			rUser.TotalDuration = rUser.TotalDuration + iDurationOut
			rUser.TotalDurationIn = rUser.TotalDurationIn + iDurationIn
			rUser.TotalDurationHeal = rUser.TotalDurationHeal + iDurationHeal
		end

		-- do one last live graph / list update
		if rOpt.LiveData.value then
			if rTemp.Graph.GroupInvolved then
				if (rTemp.Graph.FightSignificant == true) then
					if (rTemp.Graph.Paused == false) then
						-- if not paused, update the times
						if (rTemp.FightStart > 0) and (rTemp.FightStartIn > 0) then
							rTemp.Graph.StartTime = math_min(rTemp.FightStart, rTemp.FightStartIn)
						else
							rTemp.Graph.StartTime = math_max(rTemp.FightStart, rTemp.FightStartIn)
						end
						rTemp.Graph.EndTime = math_max(rTemp.FightEnd, rTemp.FightEndIn)
					end

					-- change processing from unlocked to neutral (allows processing from raw to display, and allows locking when the next fight starts)
					rTemp.Graph.ProcessLockStatus = "neutral"
				end
				RecapGraph_UpdateLiveLists() -- also done at the start of any fight
				if RecapGraph:IsVisible() then
					RecapGraph_GraphUpdate()
				end
			end
			rTemp.Graph.GroupInvolved = false
			rTemp.Graph.BinsInitialized = false
		end

		-- clear temporaries
		rTemp.FightStart = 0
		rTemp.FightEnd = 0
		rTemp.FightStartIn = 0
		rTemp.FightEndIn = 0
		rTemp.FightStartHeal = 0
		rTemp.FightEndHeal = 0

		-- clear effect interval timers
		Recap_ClearEffectIntervalTimers()

		-- for once-only stuff during StartFight
		rTemp.ResetWasInCurrent = false

		-- if Recent Data Mode is active, add an 'end of fight' event (signalled by empty string values for sourceNameGUID and destNameGUID)
		--   (added even if we are in SkipNextFight)
		--   (but only if the state was Active)
		if rOpt.RecentData.value and (incomingState == "Active") then
			-- create an 'end of fight' event if we had other events
			-- use the most recent event time encountered, and add one second
			if rTemp.Recent.Time then
				Recap_AddRecentEvent(rTemp.Recent.Time + 1, "", "", "", "", "", "", false, false, 0)
			end
		end

		-- special case correction for some dual damage:healing tickers (in active set)
		Recap_CorrectDualDoTHoTForSelf()

		-- the following should happen after all processing of the current active data has been complete (modulo any later changes due to synchronization)
		if rTemp.LastFightSignificant then
			for i, iCombatant in pairs(rCombatants) do
				-- swap the two Last Fight detail data structures, and clear the older one so it can collect the next set of fight data
				if rTemp.ActiveLastFight == "1" then
					-- we have been storing data in 1, and displaying from 2
					-- clear 2
					iCombatant.LastTime_2 = nil
					iCombatant.LastTimeIn_2 = nil
					iCombatant.LastTimeHeal_2 = nil
					iCombatant.LastMaxHit_2 = nil
					iCombatant.LastDmgIn_2 = nil
					iCombatant.LastDmgOut_2 = nil
					iCombatant.LastHPS_2 = nil
					iCombatant.LastDPSIn_2 = nil
					iCombatant.LastDPS_2 = nil
					iCombatant.LastGearValue_2 = nil
					iCombatant.LastDeaths_2 = nil
					iCombatant.LastDispels_2 = nil
					iCombatant.LastInterrupts_2 = nil
					iCombatant.LastRawHeal_2 = nil
					iCombatant.LastOverHeal_2 = nil
					iCombatant.LastOutgoingDetail_2 = nil
					iCombatant.LastTargetDetail_2 = nil
					iCombatant.LastIncomingDetail_2 = nil
					iCombatant.LastSourceDetail_2 = nil
					iCombatant.LastOtherDetail_2 = nil
				else
					-- we have been storing data in 2, and displaying from 1
					-- clear 1
					iCombatant.LastTime_1 = nil
					iCombatant.LastTimeIn_1 = nil
					iCombatant.LastTimeHeal_1 = nil
					iCombatant.LastMaxHit_1 = nil
					iCombatant.LastDmgIn_1 = nil
					iCombatant.LastDmgOut_1 = nil
					iCombatant.LastHPS_1 = nil
					iCombatant.LastDPSIn_1 = nil
					iCombatant.LastDPS_1 = nil
					iCombatant.LastGearValue_1 = nil
					iCombatant.LastDeaths_1 = nil
					iCombatant.LastDispels_1 = nil
					iCombatant.LastInterrupts_1 = nil
					iCombatant.LastRawHeal_1 = nil
					iCombatant.LastOverHeal_1 = nil
					iCombatant.LastOutgoingDetail_1 = nil
					iCombatant.LastTargetDetail_1 = nil
					iCombatant.LastIncomingDetail_1 = nil
					iCombatant.LastSourceDetail_1 = nil
					iCombatant.LastOtherDetail_1 = nil
				end
			end
			if rTemp.ActiveLastFight == "1" then
				-- swap to storing data in 2, and displaying from 1
				rTemp.ActiveLastFight = "2"
				rTemp.DisplayLastFight = "1"
			else
				-- swap to storing data in 1, and displaying from 2
				rTemp.ActiveLastFight = "1"
				rTemp.DisplayLastFight = "2"
			end
		end

		if rOpt.AutoPost.value then
			rUser.SortBy = Recap_AutoPostGetStatID(rOpt.AutoPost.Stat)
			rUser.SortDir = false
		end

		if (not rUser.Minimized) or rOpt.AutoPost.value or rOpt.AutoLeader.value then
			-- don't construct a list if minimized, unless we are doing one of the auto things which needs the list
			Recap_ConstructList()
		end
		Recap_SetState("Idle")
		Recap_TitleBar()
		RecapHeader_Name:SetText((rTemp.ListSize-1).." "..rLocalize.Combatants)
		Recap_SetTitleBackground()

		if rTemp.LastFightSignificant then
			if not ((rUser.SyncState == "Member") or (rUser.SyncState == "Leader")) then
				-- if we're not in synchronization then we do these auto-posts immediately, otherwise we will wait for the EndSyncDelayTimer to expire
				if rOpt.AutoPost.value then
					Recap_PostFight()
				end
				if rOpt.AutoLeader.value then
					Recap_PostLeader()
				end
			end
		end

		-- tell how long it took
		local elapsedMS = debugprofilestop() -- always make this second call, to stop the timer, even if we don't print the result
		if rRecap.debug then
			print("(Recap) Fight processed in "..string_format("%.3f", elapsedMS).." milliseconds")
		end
		if rRecap.dump then
			Recap_DumpMessage("(Recap) Fight processed in "..string_format("%.3f", elapsedMS).." milliseconds")
		end

		if rOpt.AutoHide.value and not rUser.Minimized then
			RecapFrame_Show()
			if rOpt.AutoFade.value then
				rTemp.FadeTimer = 0
			end
		end

		rTemp.SkipPeriodicUpdate = false -- resume periodic update
	end
end


function Recap_ClearAsIfEndOfFight()
	local rTemp = _G.recap_temp
	local i, iLast
	if not rTemp.Last then
		rTemp.Last = {}
	end
	for i, iLast in pairs(rTemp.Last) do
		-- ensure that every 'Last' record is cleared
		iLast.StartOut = 0
		iLast.EndOut = 0
		iLast.StartIn = 0
		iLast.EndIn = 0
		iLast.StartHeal = 0
		iLast.EndHeal = 0
		iLast.DmgIn = 0
		iLast.DmgOut = 0
		iLast.PetsDmgOut = 0
		iLast.MaxHit = 0
		iLast.Deaths = 0
		if iLast.DeathEvents then
			iLast.DeathEvents = nil
			iLast.DeathEventsIndex = nil
		end
		iLast.Dispels = 0
		iLast.Interrupts = 0
		iLast.RawHeal = 0
		iLast.OverHeal = 0

		-- Last Fight details are not cleared at this time
	end
	-- clear effect interval timers
	Recap_ClearEffectIntervalTimers()
	-- turn off idle and end of fight delay timers
	rTemp.IdleTimer = -1
	rTemp.HiddenIdleTimer = -1
	rTemp.EndFightDelayTimer = -1
end

-- removes combatant i from last fight
function Recap_ResetLastFight(i)

	local rCombatants = _G.recap_combatants
	local rTemp = _G.recap_temp
	local iLast = rTemp.DisplayLastFight
	local iCombatant = rCombatants[i]
	local j

	j = (iCombatant.TotalTime or 0) - (iCombatant["LastTime_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalTime = j
	end
	j = (iCombatant.TotalTimeIn or 0) - (iCombatant["LastTimeIn_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalTimeIn = j
	end
	j = (iCombatant.TotalTimeHeal or 0) - (iCombatant["LastTimeHeal_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalTimeHeal = j
	end
	j = (iCombatant.TotalDmgIn or 0) - (iCombatant["LastDmgIn_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalDmgIn = j
	end
	j = (iCombatant.TotalDmgOut or 0) - (iCombatant["LastDmgOut_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalDmgOut = j
	end
	j = (iCombatant.TotalRawHeal or 0) - (iCombatant["LastRawHeal_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalRawHeal = j
	end
	j = math_min(((iCombatant.TotalOverHeal or 0) - (iCombatant["LastOverHeal_"..iLast] or 0)), (iCombatant.TotalRawHeal or 0))
	if j>0 then
		iCombatant.TotalOverHeal = j
	end
	j = (iCombatant.TotalDeaths or 0) - (iCombatant["LastDeaths_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalDeaths = j
	end
	j = (iCombatant.TotalDispels or 0) - (iCombatant["LastDispels_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalDispels = j
	end
	j = (iCombatant.TotalInterrupts or 0) - (iCombatant["LastInterrupts_"..iLast] or 0)
	if j>0 then
		iCombatant.TotalInterrupts = j
	end
	if iCombatant.TotalTime and (iCombatant.TotalTime > rTemp.MinTime) and ((iCombatant.TotalDmgOut or 0) > 0) then
		iCombatant.TotalDPS = Recap_Div1((iCombatant.TotalDmgOut or 0), iCombatant.TotalTime)
	end
	if iCombatant.TotalTimeIn and (iCombatant.TotalTimeIn > rTemp.MinTime) and ((iCombatant.TotalDmgIn or 0) > 0) then
		iCombatant.TotalDPSIn = Recap_Div1((iCombatant.TotalDmgIn or 0), iCombatant.TotalTimeIn)
	end
	if iCombatant.TotalTimeHeal and (iCombatant.TotalTimeHeal > rTemp.MinTime) and (((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)) > 0) then
		iCombatant.TotalHPS = Recap_Div1(((iCombatant.TotalRawHeal or 0) - (iCombatant.TotalOverHeal or 0)), iCombatant.TotalTimeHeal)
	end
	iCombatant.WasInLast = false

	-- clear the currently displayed Last Fight details
	if rTemp.ActiveLastFight == "1" then
		-- we have been storing data in 1, and displaying from 2
		-- clear 2
		iCombatant.LastTime_2 = nil
		iCombatant.LastTimeIn_2 = nil
		iCombatant.LastTimeHeal_2 = nil
		iCombatant.LastMaxHit_2 = nil
		iCombatant.LastDmgIn_2 = nil
		iCombatant.LastDmgOut_2 = nil
		iCombatant.LastHPS_2 = nil
		iCombatant.LastDPSIn_2 = nil
		iCombatant.LastDPS_2 = nil
		iCombatant.LastGearValue_2 = nil
		iCombatant.LastDeaths_2 = nil
		iCombatant.LastDispels_2 = nil
		iCombatant.LastInterrupts_2 = nil
		iCombatant.LastRawHeal_2 = nil
		iCombatant.LastOverHeal_2 = nil
		iCombatant.LastOutgoingDetail_2 = nil
		iCombatant.LastTargetDetail_2 = nil
		iCombatant.LastIncomingDetail_2 = nil
		iCombatant.LastSourceDetail_2 = nil
		iCombatant.LastOtherDetail_2 = nil
	else
		-- we have been storing data in 2, and displaying from 1
		-- clear 1
		iCombatant.LastTime_1 = nil
		iCombatant.LastTimeIn_1 = nil
		iCombatant.LastTimeHeal_1 = nil
		iCombatant.LastMaxHit_1 = nil
		iCombatant.LastDmgIn_1 = nil
		iCombatant.LastDmgOut_1 = nil
		iCombatant.LastHPS_1 = nil
		iCombatant.LastDPSIn_1 = nil
		iCombatant.LastDPS_1 = nil
		iCombatant.LastGearValue_1 = nil
		iCombatant.LastDeaths_1 = nil
		iCombatant.LastDispels_1 = nil
		iCombatant.LastInterrupts_1 = nil
		iCombatant.LastRawHeal_1 = nil
		iCombatant.LastOverHeal_1 = nil
		iCombatant.LastOutgoingDetail_1 = nil
		iCombatant.LastTargetDetail_1 = nil
		iCombatant.LastIncomingDetail_1 = nil
		iCombatant.LastSourceDetail_1 = nil
		iCombatant.LastOtherDetail_1 = nil
	end

	-- we do not attempt to subtract the Last Fight details from the All Fights details -- tough
end


-- a function to support Recent Data Mode
function Recap_CreateRecent()

	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local rRecent = _G.recap_temp.Recent
	local i

	recap_temp.Recent = wipe(recap_temp.Recent)
	i = 1
	while i <= rOpt.RecentEventCount.value do
		rRecent[i] = ""
		i = i + 1
	end
	rRecent.First = 1
	rRecent.Last = 1

	rTemp.RecentFriendDeaths = wipe(rTemp.RecentFriendDeaths)
end


--[[ local functions that process combat events ]]

-- the Booleans (critical, glancing, crushing) come in as either 1 or nil (I changed Recap code to match this, so as to save unnecessary conversions)
-- similarly missType arrives as all upper-case
-- with patch 2.4.3 the schools (which are bit significant) can be multiple, e.g. Sunblade Protector spell Fel Lightning is now Shadow+Nature instead of Fire
-- Note: Raise Ally is a death knight ability that creates a Risen Ally from the body of a dead party member, and this Risen Ally is the pet of the dead party member

-- we translate the school number and the power type number to a localized name

-- in all of the following, the argument destNameGUID is used only by Recap_DispatchSpellSummonCreate

-- damaging events and misses
local function Recap_DispatchSwingDamage(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- can be non-Physical damage (e.g. Melee that lands as Shadow damage)
	local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = ...
	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if absorbed then
		absorbed = Recap_Round0(absorbed) -- paranoia 5.0.4
	end
	if amount and (amount > 0) then
		-- non-zero damage
		local schoolName = Recap_DecodeSchoolName(school)
		Recap_DamageEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destFlags, nil, rLocalize.Melee, 1, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)
	end
end
local function Recap_DispatchSwingMissed(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
-- Handle amountMissed (see RANGE_MISSED etc. below)
--	   probably only for RESIST, when the amount gives the actual amount of a 100% resist, so we could avoid having to calculate our estimate, or could even generalize to come up with one or more mitigation percentages
--	   so far, non-nil and non-zero amounts have only been captured for ABSORB and BLOCK (duels only, no instance run) (decent sample, includes everything except DEFLECT and EVADE)
--	   finally captured a RESIST with a non-zero amount, but there are a number of full RESIST events without amounts (another sample, 72 full resists, not a single amount)
-- 2013-June-15 on some unknown date in the past the absorbed amount was moved from second additional argument to third additional argument, intervening argument is 'isOffHand'
	local missType, _, amountMissed = ...
	if (missType == "MISS") or (missType == "ABSORB") or (missType == "DODGE") or (missType == "PARRY") or (missType == "BLOCK") or
	   (missType == "DEFLECT") or (missType == "EVADE") or (missType == "RESIST") or (missType == "REFLECT") or (missType == "IMMUNE") then
		-- expected, do nothing
	else
		if (missType == "MISFIRE") then
			-- semi-expected, will not try to handle it fully, paper over the problem for the moment by treating these as simple misses (Hawksy 2012-09-30) TODO
			missType = "MISS"
		else
			-- unexpected miss type
			Recap_CheckUnexpectedEvent("unexpected miss type")
			missType = "MISS"
		end
	end
	local schoolName = rLocalize.SchoolName[1] -- hardcoded to Physical
	Recap_MissEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destFlags, nil, rLocalize.Melee, 1, schoolName, missType, amountMissed)
end
local function Recap_DispatchRangeSpellDamage(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- for a wand
	-- the spellSchool is Physical but the school is e.g. Shadow, so don't check whether they differ

	-- for a spell
	-- implication is that PERIODIC damage could be critical, glancing, or crushing, but I've not seen that
	-- sometimes spellSchool does not equal school
	-- for example Warden Icoshock does a Shadowsurge with the spell being Shadow but with the damage caused being Physical
	-- we track the school according to the damage done, in this example Physical
	-- the fact that the spell is Shadow is not tracked
	-- presumably abilities that interrupt Shadow casting would block the spell
	local spellID, spellName, spellSchool, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = ...
	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if absorbed then
		absorbed = Recap_Round0(absorbed) -- paranoia 5.0.4
	end
	if amount and (amount > 0) then
		-- non-zero damage
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(school)

		-- 2014 June: Special case code for Ultraxion fight
		-- The boss has up to seven or more clones with same name but different GUIDs who do damage using the spell "Twilight Instability", but appear to do nothing else, and who have no summon or other creation spell
		-- Assign the damage for the spell directly to the boss
		if (spellID == 106374) or (spellID == 106375) or (spellID == 109176) then
			-- find the boss
			if Recap_FindBoss("Ultraxion") then
				Recap_DamageEvent(timestamp, eventType, bossNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)
			else
				-- unexpected, assign the spell to the clone
				Recap_DamageEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)
				Recap_CheckUnexpectedEvent("unable to find boss for Twilight Instability in Ultraxion fight")
			end
		else
			-- normal case
			Recap_DamageEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)
		end
	end
end
local function Recap_DispatchRangeSpellMissed(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- SPELL_PERIODIC_MISSED is, for example, a damage tick being absorbed
-- TODO: example Sinister Strike missed because of ABSORB and the absorb amount is amountMissed -- ditto for Deadly Poison -- soul link damage re-routed to minion is listed as absorbed for the lock
--	   mobs just before Curator who have mana shields show damage as absorbed
--	   if the type is MISS then amountMissed seems to be nil (on a small sample)
-- 2013-June-15 on some unknown date in the past the absorbed amount was moved from fifth additional argument to sixth additional argument, intervening argument is 'isOffHand'
	local spellID, spellName, spellSchool, missType, _, amountMissed = ...
	if (missType == "MISS") or (missType == "ABSORB") or (missType == "DODGE") or (missType == "PARRY") or (missType == "BLOCK") or
	   (missType == "DEFLECT") or (missType == "EVADE") or (missType == "RESIST") or (missType == "REFLECT") or (missType == "IMMUNE") then
		-- expected, do nothing
	else
		if (missType == "MISFIRE") then
			-- semi-expected, will not try to handle it fully, paper over the problem for the moment by treating these as simple misses (Hawksy 2012-09-30) TODO
			missType = "MISS"
		else
			-- unexpected miss type
			Recap_CheckUnexpectedEvent("unexpected miss type")
			missType = "MISS"
		end
	end
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	Recap_MissEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, missType, amountMissed)
end
local function Recap_DispatchEnvironmentalDamage(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local enviromentalType, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = ...
	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if absorbed then
		absorbed = Recap_Round0(absorbed) -- paranoia 5.0.4
	end
	if amount and (amount > 0) then
		-- non-zero damage
		local schoolName = Recap_DecodeSchoolName(school)
		Recap_EnvironmentDamageEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, enviromentalType, amount, overkill, school, schoolName, resisted, blocked, absorbed, critical, glancing, crushing)
	end
end

-- healing events
-- Combat log events HEAL_ABSORB, PERIODIC_HEAL_ABSORB, and HEAL_CRIT_ABSORB, originally proposed by Blizzard for the Jaraxxus fight, are instead part of the normal SPELL_HEAL and SPELL_PERIODIC_HEAL
-- 2014-May-31: Ysera's Gift (spell ID 145108), a passive healing ability, will not start or extend a fight
local function Recap_DispatchSpellHeal(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local spellID, spellName, spellSchool, amount, overheal, absorbed, critical = ...
	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end
	if absorbed then
		absorbed = Recap_Round0(absorbed) -- paranoia 5.0.4
	end
	-- for the Lord Jaraxxus event (patch 3.2) absorbed can be non-zero, and will have been subtracted from amount, so add it back in
	amount = (amount or 0) + (absorbed or 0)
	if amount and (amount > 0) then
		-- non-zero healing (with absorption included)
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		Recap_HealEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, overheal, critical)
	end
end

-- casting events that can affect standard data (and may add to Other data if that mode is enabled)
local function Recap_DispatchSpellCastSuccess(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- this seems to show both source and destination, so we may not need to 'remember' from SPELL_CAST_START (which used to be the case)
	-- there also exists event: UNIT_SPELLCAST_SUCCEEDED, "player", spell, rank
	local spellID, spellName, spellSchool = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	Recap_CastEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)
end
local function Recap_DispatchSpellInstakill(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- for example, a Boom Bot self-destructing; a warlock sacrificing their demon; a paladin killing themselves during Divine Intervention
	-- will count twice, once as source (green) and once as destination (white)
	local spellID, spellName, spellSchool = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	Recap_CastEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)
end

-- summoning and creating can create pets (and may add to Other data if that mode is enabled)
local function Recap_DispatchSpellSummonCreate(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- gives the GUID of a summoned creature or created object (e.g. totem or trap)
	-- we will associate these 'pets' with their owners (and if Blizzard supported it then we could do it transitively from hunter trap to snakes)
	-- this event does NOT happen for mind control
	-- happens for the Summoned Cadaver from Abracadaver, but the result does not seem to be a pet
	local spellID, spellName, spellSchool = ...

	-- we ignore create events that produce an excessive number of irrelevant pets and (indirectly) combatants
	-- Fishing that creates Fishing Bobber (7620, 7731, 7732, 18248, 33095, 51294)
	-- Basic Campfire that creates Basic Campfire (818); Fish Feast (57426); Demonic Circle: Summon (48018); MOLL-E (portable mailbox) (54710)
	-- TODO: these IDs might have changed for Cataclysm and later
	if  (spellID == 7620) or (spellID == 7731) or (spellID == 7732) or (spellID == 18248) or (spellID == 33095) or (spellID == 51294) or (spellID == 818) or (spellID == 57426) or
		(spellID == 48018) or (spellID == 54710) then
		return
	end

	-- NB: the dest uses the unqualified name (breaks with GUIDs off if we don't do this)
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	Recap_SummonOrCreateEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)
end


-- here endeth the standard events

-- here beginneth the Other events

-- an Other event does not start a fight
-- an Other event does not affect the idle timer
-- an Other event does not affect the end of fight delay timer
-- an Other event does not create a source or destination combatant (an aura on a combatant who doesn't already exist will be ignored), nor affect their combat timers

-- some Other events apply partially even in Light Data Mode and with Other Data turned off, so process them always

-- buffs and debuffs
-- these include both active casts and passive procs (and if an active cast leads to later passive procs, there is additional ambiguity)
-- 2010-June-02: to track e.g. Polymorph for which there is no SPELL_CAST_SUCCESS event, we *have* to track the SPELL_AURA_APPLIED event
--   we count all three of these events as casts for the source
--   the down side is that for effects that hit multiple targets we will count them as N casts (and as N+1 casts for effects that have a SPELL_CAST_SUCCESS event)
--   I can see no cheap way to distinguish the different types of cast, and it is probably not critical to do so (better to over-count than under-count if we have to pick one or the other)
local function Recap_DispatchSpellAuraApplied(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- source arguments were initially nil with patch 2.4
	-- 2010-June-02: I don't know exactly when this changed, but if we want to track e.g. outgoing Polymorph we now need to count this event as a cast for the source
	--   My best guess is that it changed with Recap 4.00 (late March 2008, to match patch 2.4 of Burning Crusade) with the new combat log events.  I have a data set
	--   from mid March 2008 which definitely records outgoing Polymorph, and nothing after that.  A data set from May 2008 is almost certainly not recording them.
	--   So nobody noticed for over two years.  In partial defence, when patch 2.4 first came out the source for this event was always nil, and was not added until
	--   later, so with patch 2.4 it was simply not possible to track outgoing Polymorph (and related CC).
	-- Some NPC polymorphs (e.g. those cast by "Unholy Staff" in Naxxramas) *are* being recorded since they have separate SPELL_CAST_SUCCESS events
	-- see also the next two functions
	-- Cataclysm: SPELL_AURA_APPLIED has one more (optional) argument, an amount that a shield can absorb
	--			SPELL_AURA_REFRESH gives the new number (e.g. 1898), after or before the absorb event that did the absorbing (full absorb 2126)
	--			eventually SPELL_AURA_REMOVED says that the shield has gone and had 1898 left on it

	local rTemp = _G.recap_temp

	local spellID, spellName, spellSchool, auraType, shieldAmount = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)

	if shieldAmount then
		shieldAmount = Recap_Round0(shieldAmount) -- paranoia 5.0.4
	end

	if shieldAmount and (auraType == "BUFF") then
		Recap_RegisterShieldAura(timestamp, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, spellID, spellName, shieldAmount)
	else
		local doseAmount = 1
			-- something that is not a shield and which could be a dose needs to have an implied dose of whatever the dose level was before, and if it was zero then it needs to be 1
			-- damn Blizzard, why couldn't they send the dose level, rather than scrimping on a byte or two?
			-- TODO: register all (potential) doses so we can keep track ?  might allow us to do reducing doses in a similar way ?  averages event based, or time based ?
		Recap_BuffOrDebuffEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, auraType, doseAmount, true)
	end
end
local function Recap_DispatchSpellAuraAppliedDose(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- source arguments can be nil
	-- for example Sunder Armor, a stacking debuff
	-- 2010-June-02: I am assuming that 'applied dose' represents a fresh cast (event introduced with patch 2.4.3, source data added some time after patch 3.1)
	--   There is some uncertainty as to whether the source given will be the original caster of the debuff, or the person now refreshing the debuff (since anyone can refresh a 'Sunder' stack)
	--   It is also not clear what happens when the stack is at maximum (e.g. 5 Sunders).  Is there another dose with amount 5, or does it now change to a 'refresh' event?
	-- It is clear that dose events can be not cast per se, but can be procced things (and in the sense we are counting casts by a player's gear or a player's talent similarly)

	local spellID, spellName, spellSchool, auraType, doseAmount = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)

	Recap_BuffOrDebuffEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, auraType, doseAmount, true)
end
local function Recap_DispatchSpellAuraRefresh(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- source arguments can be nil -- new with patch 2.4.3
	-- 2010-June-02: overwriting a buff or debuff with a new copy (whether from same source or from a different source) (at one time source was nil, at least as late as April 2009) (source data added patch 3.1)
	--   there are refreshes with both SPELL_AURA_REFRESH and SPELL_CAST_SUCCESS events (usually in that order)
	--   there are some casts with both an 'applied' event and a 'refresh' event, so there is additional multiple counting for these types

	local rTemp = _G.recap_temp


	local spellID, spellName, spellSchool, auraType, amount = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	local doseAmount = 0
	local shieldAmount = 0

	if amount then
		amount = Recap_Round0(amount) -- paranoia 5.0.4
	end

	if amount then
		-- shield, nothing more to do
		shieldAmount = amount
	else
		-- must be dose only
		shieldAmount = nil
		-- something that is not a shield and which will eventually become a dose needs to have an implied dose of 1
		-- same comment as during APPLIED
		doseAmount = 1
	end

	if shieldAmount and (auraType == "BUFF") then
		Recap_RefreshOrRemoveShieldAura(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, shieldAmount)
	else
		-- other aura
		Recap_BuffOrDebuffEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, auraType, doseAmount, false)
	end
end

-- other buff and debuff related events
local function Recap_DispatchSpellAuraRemoved(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- source arguments can be nil

	local rTemp = _G.recap_temp

	local spellID, spellName, spellSchool, auraType, shieldAmount = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	local doseAmount = 0

	if shieldAmount then
		shieldAmount = Recap_Round0(shieldAmount) -- paranoia 5.0.4
	end

	if shieldAmount and (auraType == "BUFF") then
		Recap_RefreshOrRemoveShieldAura(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, shieldAmount)
	else
		-- other aura
		Recap_RemoveEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, auraType, 0)
	end
end
local function Recap_DispatchSpellDispel(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- the first spell is the one causing the aura to be dispelled or otherwise cancelled, and the *extra* is the name of the aura that is being dispelled
	local spellID, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool, auraType = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local extraSpellName = string_gsub(extraSpellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	local extraSchoolName = Recap_DecodeSchoolName(extraSpellSchool)
	Recap_DispelEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName, auraType)
end
local function Recap_DispatchSpellAuraBrokenSpell(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- okay, this one (new with patch 2.4.3) is backwards compared to SPELL_DISPEL, just to keep us addon authors on our toes
	-- the first spell is the name of the aura that is being dispelled, and the *extra* is the one causing the aura to be broken
	local spellID, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool, auraType = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local extraSpellName = string_gsub(extraSpellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	local extraSchoolName = Recap_DecodeSchoolName(extraSpellSchool)
	Recap_DispelEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName, spellID, spellName, spellSchool, schoolName, auraType)
end
local function Recap_DispatchSpellAuraBroken(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- new with patch 2.4.3
	-- I interpret this event as a physical attack (arbitrarily chosen to be 'Melee') dispelling an aura
	local extraSpellId, extraSpellName, extraSpellSchool, auraType = ...
	local extraSpellName = string_gsub(extraSpellName, "%&", rLocalize.And)
	local schoolName = rLocalize.SchoolName[1] -- hardcoded to Physical
	local extraSchoolName = Recap_DecodeSchoolName(extraSpellSchool)
	Recap_DispelEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, nil, rLocalize.Melee, 1, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName, auraType)
end
local function Recap_DispatchSpellStolen(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	-- spellName does the stealing, extraSpellName gets stolen
	local spellID, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool, auraType = ...
	local spellName = string_gsub(spellName, "%&", rLocalize.And)
	local extraSpellName = string_gsub(extraSpellName, "%&", rLocalize.And)
	local schoolName = Recap_DecodeSchoolName(spellSchool)
	local extraSchoolName = Recap_DecodeSchoolName(extraSpellSchool)
	Recap_StealEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName, auraType)
end

-- only track the following Other events if not in Light Data Mode, and with the Other Data Mode enabled

-- resurrection, gains, drains, leeches, extra attacks
local function Recap_DispatchSpellResurrect(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		local spellID, spellName, spellSchool = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		Recap_CastEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)
	end
end
local function Recap_DispatchSpellEnergize(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		local spellID, spellName, spellSchool, amount, powerType = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		local powerName = rLocalize.PowerName[powerType]
		if not powerName then
			Recap_CheckUnexpectedEvent("unexpected power type")
			powerName = rLocalize.ElementOther
		end
		Recap_GainEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, powerType, powerName)
	end
end
local function Recap_DispatchSpellDrain(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		local spellID, spellName, spellSchool, amount, powerType, extraAmount = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		local powerName = rLocalize.PowerName[powerType]
		if not powerName then
			Recap_CheckUnexpectedEvent("unexpected power type")
			powerName = rLocalize.ElementOther
		end
		-- Note: patch 3.1 and I never captured a non-nil value for extraAmount, so I've removed the code that reported a capture
		Recap_DrainEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, powerType, powerName, extraAmount)
	end
end
local function Recap_DispatchSpellLeech(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		-- could be Dark Pact moving mana from an imp to its warlock
		-- it seems that amount is the gain for the source and extraAmount is the loss for the dest
		local spellID, spellName, spellSchool, amount, powerType, extraAmount = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		local powerName = rLocalize.PowerName[powerType]
		if not powerName then
			Recap_CheckUnexpectedEvent("unexpected power type")
			powerName = rLocalize.ElementOther
		end
		Recap_LeechEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount, powerType, powerName, extraAmount)
	end
end
local function Recap_DispatchSpellExtraAttacks(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		local spellID, spellName, spellSchool, amount = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		Recap_ExtraAttackEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, amount)
	end
end

-- interrupting
local function Recap_DispatchSpellInterrupt(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		-- spellName does the interrupting, extraSpellName is what gets interrupted
		local spellID, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local extraSpellName = string_gsub(extraSpellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		local extraSchoolName = Recap_DecodeSchoolName(extraSpellSchool)
		Recap_InterruptEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName, extraSpellId, extraSpellName, extraSpellSchool, extraSchoolName)
	end
end

-- durability
local function Recap_DispatchSpellDurabilityDamage(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, ...)
	local rOpt = _G.recap_temp.Opt
	if (not rOpt.LightData.value) and rOpt.OtherData.value then
		-- have samples of the first -- Ragnaros casts "Finger of Death", "Flight through Caverns", and "Rough Stone Statue" spells of the first type
		local spellID, spellName, spellSchool = ...
		local spellName = string_gsub(spellName, "%&", rLocalize.And)
		local schoolName = Recap_DecodeSchoolName(spellSchool)
		Recap_DurabilityEvent(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, destOwnerNameGUID, destFlags, spellID, spellName, spellSchool, schoolName)
	end
end

-- this table is an attempt to speed up the dispatch of combat events by avoiding a very long if-then-elseif sequence
local eventDispatchTable =
{	["SWING_DAMAGE"] = Recap_DispatchSwingDamage,
	["SWING_MISSED"] = Recap_DispatchSwingMissed,
	["RANGE_DAMAGE"] = Recap_DispatchRangeSpellDamage,
	["SPELL_DAMAGE"] = Recap_DispatchRangeSpellDamage,
	["SPELL_PERIODIC_DAMAGE"] = Recap_DispatchRangeSpellDamage,
	["DAMAGE_SHIELD"] = Recap_DispatchRangeSpellDamage,
	["DAMAGE_SPLIT"] = Recap_DispatchRangeSpellDamage,
	["RANGE_MISSED"] = Recap_DispatchRangeSpellMissed,
	["SPELL_MISSED"] = Recap_DispatchRangeSpellMissed,
	["SPELL_PERIODIC_MISSED"] = Recap_DispatchRangeSpellMissed,
	["DAMAGE_SHIELD_MISSED"] = Recap_DispatchRangeSpellMissed,
	["ENVIRONMENTAL_DAMAGE"] = Recap_DispatchEnvironmentalDamage,
	["SPELL_HEAL"] = Recap_DispatchSpellHeal,
	["SPELL_PERIODIC_HEAL"] = Recap_DispatchSpellHeal,
	["SPELL_CAST_SUCCESS"] = Recap_DispatchSpellCastSuccess,
	["SPELL_INSTAKILL"] = Recap_DispatchSpellInstakill,
	["SPELL_SUMMON"] = Recap_DispatchSpellSummonCreate,
	["SPELL_CREATE"] = Recap_DispatchSpellSummonCreate,
	["SPELL_AURA_APPLIED"] = Recap_DispatchSpellAuraApplied,
	["SPELL_AURA_APPLIED_DOSE"] = Recap_DispatchSpellAuraAppliedDose,
	["SPELL_AURA_REFRESH"] = Recap_DispatchSpellAuraRefresh,
	["SPELL_AURA_REMOVED"] = Recap_DispatchSpellAuraRemoved,
	["SPELL_DISPEL"] = Recap_DispatchSpellDispel,
	["SPELL_AURA_BROKEN_SPELL"] = Recap_DispatchSpellAuraBrokenSpell,
	["SPELL_AURA_BROKEN"] = Recap_DispatchSpellAuraBroken,
	["SPELL_STOLEN"] = Recap_DispatchSpellStolen,


	-- death events

	-- identical for priest death and for priest second death after Spirit of Redemption
	["UNIT_DIED"] = Recap_DispatchDeathEvent,

	-- this event partially duplicates UNIT_DIED, so is used only for Recent Events
	-- from 4.36 also used in improved death count code
	["PARTY_KILL"] = Recap_DispatchKillEvent,


	-- the following Other events will only do something if not in Light Data Mode and with Other Data Mode enabled

	["SPELL_RESURRECT"] = Recap_DispatchSpellResurrect,
	["SPELL_ENERGIZE"] = Recap_DispatchSpellEnergize,
	["SPELL_PERIODIC_ENERGIZE"] = Recap_DispatchSpellEnergize,
	["SPELL_DRAIN"] = Recap_DispatchSpellDrain,
	["SPELL_PERIODIC_DRAIN"] = Recap_DispatchSpellDrain,
	["SPELL_LEECH"] = Recap_DispatchSpellLeech,
	["SPELL_PERIODIC_LEECH"] = Recap_DispatchSpellLeech,
	["SPELL_EXTRA_ATTACKS"] = Recap_DispatchSpellExtraAttacks,
	["SPELL_INTERRUPT"] = Recap_DispatchSpellInterrupt,
	["SPELL_DURABILITY_DAMAGE"] = Recap_DispatchSpellDurabilityDamage,
	["SPELL_DURABILITY_DAMAGE_ALL"] = Recap_DispatchSpellDurabilityDamage,


	-- introduced with version 4.29 for dispels only (due to concerns about dispels on Steelbreaker)
	-- removed again with version 4.50
	["SPELL_CAST_START"] = true, -- now ignored
	["SPELL_CAST_FAILED"] = true, -- now ignored
	["SPELL_DISPEL_FAILED"] = true, -- now ignored


	-- ignored events

	-- source arguments can be nil
	-- spellID, spellName, spellSchool, auraType, amount = ...
	-- I think this is where a stacked buff or debuff loses some but not all of its stacking
	-- TODO probably shouldn't ignore, perhaps treat like an 'applied' but with the lower dose amount so as to get a better average (haven't done anything about this yet)
	["SPELL_AURA_REMOVED_DOSE"] = true,

	-- no extra arguments
	-- for example, summoned elemental ending its allotted life
	["UNIT_DESTROYED"] = true,

	-- no extra arguments
	-- for example, successful extraction of motes from clouds
	["UNIT_DISSIPATES"] = true,

	-- spellName, itemId, itemName = ...
	["ENCHANT_APPLIED"] = true,

	-- spellName, itemId, itemName = ...
	-- e.g. Flametongue 7 is removed from Merciless Gladiator's Gavel
	["ENCHANT_REMOVED"] = true,

	-- spellID, spellName, spellSchool, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = ...
	-- new with WotLK
	["SPELL_BUILDING_DAMAGE"] = true,

	-- spellID, spellName, spellSchool, amount, overheal, absorbed, critical = ...
	-- new with patch 3.2
	["SPELL_BUILDING_HEAL"] = true
}


-- main combat log event dispatcher for WoW patch 2.4
function Recap_ProcessCombatLogEvent(self, event, ...)

	local rRecap = _G.recap
	local rUser = _G.recap_user
	local rCombatants = _G.recap_combatants
	local rOpt = _G.recap_temp.Opt
	local rTemp = _G.recap_temp
	local eventIsCombatDamageEquivalent = false
	local processOOCShields = false -- used for out-of-combat processing of shield auras

	-- bail if Recap is paused
	if (rUser.State == "Stopped") then
		-- Note: if Recap is paused, useful summon information may be ignored -- tough
		return
	end

	-- dump everything as we get it
	-- doesn't tell us much that "/combatlog" wouldn't have told us, except for having the same timestamp as any diagnostic messages we output, and recording what events we actually receive
	if rRecap.dump then
		Recap_DumpMessage(Recap_EventText(...))
	end

	-- get the eleven arguments common to all events (the ellipsis is a variable pointing to a list of arguments)
	-- timestamp appears to be a flavour of UTC
	local timestamp, eventType, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags = ...

	-- we seem to get events with standard arguments equal to nil, so they need to be ignored
	if (timestamp == nil) or (eventType == nil) or (timestamp == 0) or (eventType == "") then
		return
	end

	-- calculate ongoing difference between event timestamps and GetTime()
	local delta = timestamp - GetTime()
	rTemp.TimestampDeltaSum = rTemp.TimestampDeltaSum + delta
	rTemp.TimestampDeltaCount = rTemp.TimestampDeltaCount + 1
	if rTemp.TimestampDeltaCount > 10000 then
		-- reset at 10000 so that sum doesn't become too large
		rTemp.TimestampDeltaSum = 10 * rTemp.TimestampDeltaSum / rTemp.TimestampDeltaCount
		rTemp.TimestampDeltaCount = 10
	end

	-- form the full combatant name as "name_GUID" (no prepended owners yet)
	-- we note the reuse of GUIDs for non-player mobs at server restarts
	-- the odds on a "name_GUID" combination recurring are low and would have only minor negative consequences, such as combining two Mirror Images
	local sourceNameGUID = nil
	local specialMelee = false
	if sourceName and (sourceName ~= "") then
		sourceNameGUID = sourceName
		if (not rOpt.IgnoreGUIDs.value) and sourceGUID then
			-- using GUIDs (the normal case)
			sourceNameGUID = sourceName.."_"..Recap_TrimGUID(sourceGUID)
		end
		if sourceGUID then
			-- is this a special NPC that needs its melee distinguished?
			local k = tonumber(string_sub(sourceGUID, 5, 5), 16)
			if k then
				if bit_band(k, 7) == 3 then
					-- it is an NPC
					local npcID = tonumber(string_sub(sourceGUID, 9, 12), 16)
					if rTemp.SpecialMelee[npcID] then
						specialMelee = true
					end
				end
			end
		end
	end
	local destNameGUID = nil
	if destName and (destName ~= "") then
		destNameGUID = destName
		if (not rOpt.IgnoreGUIDs.value) and destGUID then
			-- using GUIDs (the normal case)
			destNameGUID = destName.."_"..Recap_TrimGUID(destGUID)
		end
	end

	-- remember if this is combat damage (or equivalent)
	-- 2014 June removed SPELL_MISSED and SPELL_PERIODIC_MISSED, since they could be a failed heal
	if (eventType == "SWING_DAMAGE") or (eventType == "SWING_MISSED") or (eventType == "RANGE_DAMAGE") or (eventType == "RANGE_MISSED") or
	   (eventType == "SPELL_DAMAGE") or (eventType == "DAMAGE_SHIELD") or (eventType == "DAMAGE_SHIELD_MISSED") or
	   (eventType == "SPELL_PERIODIC_DAMAGE") or (eventType == "DAMAGE_SPLIT") then
		eventIsCombatDamageEquivalent = true
	end

	-- various processing for the bare names (similar happens again later with fully-qualified names)
	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- check for ignores on the name before we go any further
		if rCombatants[sourceNameGUID].Ignore then
			if (rUser.SyncState ~= "Member") and (rUser.SyncState ~= "Leader") then
				-- sourceNameGUID is an ignored combatant, not in synchronization, pretend the event didn't happen at all
				return true
			end
		end
		Recap_ProcessCombatant(timestamp, rCombatants[sourceNameGUID], sourceFlags)
	end
	if destNameGUID and rCombatants[destNameGUID] then
		-- check for ignores on the name before we go any further
		if rCombatants[destNameGUID].Ignore then
			if (rUser.SyncState ~= "Member") and (rUser.SyncState ~= "Leader") then
				-- sourceNameGUID is an ignored combatant, not in synchronization, pretend the event didn't happen at all
				return true
			end
		end
		Recap_ProcessCombatant(timestamp, rCombatants[destNameGUID], destFlags)
	end
	if sourceNameGUID and rCombatants[sourceNameGUID] and destNameGUID and rCombatants[destNameGUID] and (sourceNameGUID ~= destNameGUID) then
		-- both combatants exist, check for hostility
		-- if the source combatant is marked as Friend, and is not in the group, and is doing something hostile to someone who is in the group, then remove the Friend mark (heuristic only)
		if rCombatants[sourceNameGUID].Friend and (not rTemp.InGroup[sourceNameGUID]) and rTemp.InGroup[destNameGUID] then
			if Recap_HostileEvent(eventType, eventIsCombatDamageEquivalent, rCombatants[sourceNameGUID], rCombatants[destNameGUID], ...) then
				rCombatants[sourceNameGUID].Friend = false
				rTemp.InFriend[sourceNameGUID] = nil
			end
		end
		-- similarly if someone in the group is doing something hostile to a dest combatant marked as Friend but who is not in the group
		if rCombatants[destNameGUID].Friend and (not rTemp.InGroup[destNameGUID]) and rTemp.InGroup[sourceNameGUID] then
			if Recap_HostileEvent(eventType, eventIsCombatDamageEquivalent, rCombatants[sourceNameGUID], rCombatants[destNameGUID], ...) then
				rCombatants[destNameGUID].Friend = false
				rTemp.InFriend[destNameGUID] = nil
			end
		end
	end


	-- if this is going to be an event that does damage or healing (or equivalent), we need to check for group pet ownership before we do anything else, otherwise
	--   we can end up with orphan pets if they damage or heal before ownership is determined (e.g. a pet that appears upon dismount and is then sent to begin combat)
	if (rUser.State == "Idle") and not rOpt.LimitFights.value and not rOpt.LimitToEncounters.value then
		-- the fight hasn't started, and if we are not limiting the fight to when we are personally in combat
		--   with 4.77 don't start if we are limiting to Blizzard 'encounters'
		local start = false
		if eventIsCombatDamageEquivalent or (eventType == "ENVIRONMENTAL_DAMAGE") then
		   	start = true
		elseif (eventType == "SPELL_HEAL") or (eventType == "SPELL_PERIODIC_HEAL") then
			-- in this context, ignore heals that do zero net healing (many Fel Armor and Spirit Bond ticks, for example)
			local spellID, _, _, amount, overheal = select(12, ...)
			if amount then
				amount = Recap_Round0(amount) -- paranoia 5.0.4
			end
			if overheal then
				overheal = Recap_Round0(overheal) -- paranoia 5.0.4
			end
			if amount and overheal and ((amount - overheal) > 0) then
				if (spellID == 145108) then
					-- 2014-May-31: Ysera's Gift (spell ID 145108), a passive healing ability, will not start or extend a fight
					-- do nothing
				else
					start = true
				end
			end
		elseif (eventType == "SPELL_AURA_APPLIED") or (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_AURA_REMOVED") then
			-- track shield auras even when not in combat
			local auraType, shieldAmount = select(15, ...)
			if shieldAmount then
				shieldAmount = Recap_Round0(shieldAmount) -- paranoia 5.0.4
			end
			if shieldAmount and (auraType == "BUFF") then
				-- don't take the usual out-of-combat return that is about 100 lines down
				processOOCShields = true
-- TODO
-- print(timestamp,"OUT OF COMBAT shield aura",eventType,"target",destNameGUID,"shielder",sourceNameGUID,"spell",select(12, ...),select(11, ...),"amount",shieldAmount)
			end
		end
		if start then
			Recap_ClearAsIfEndOfFight()
			Recap_StartFight() -- calls MakeFriends
		end
	elseif (rUser.State == "Active") then
		-- the fight is ongoing
		if eventIsCombatDamageEquivalent or (eventType == "ENVIRONMENTAL_DAMAGE") then
			-- if this is a damage event, start or restart the idle timers
			if rOpt.IdleFight.value then
				rTemp.IdleTimer = 0
			end
			rTemp.HiddenIdleTimer = 0

			-- only restart the end of fight timer from zero if a member of the group is involved
			--   (this check is based on unqualified names, so we might incorrectly restart the timer if the unqualified name is not in group but the qualified name is -- I think the odds are low and the consequences minor)
			--   (it would theoretically be possible for the player to leave combat, for nothing by way of damage or healing involving the group to happen for long enough to end the fight (an extended horror for example), and then for the fight to resume -- tough)
			if (sourceNameGUID and rTemp.InGroup[sourceNameGUID]) or (destNameGUID and rTemp.InGroup[destNameGUID]) then
				-- if the end of fight delay timer is running, restart the end of fight delay timer
				--   (the player left combat, perhaps temporarily, but the fight continues) (note: the ONLY way this timer can get started in the first place is for the player to leave combat (event PLAYER_REGEN_ENABLED)) (or perhaps ENCOUNTER_START)
				if rTemp.EndFightDelayTimer ~= -1 then
					local count = math_max(1+GetNumSubgroupMembers(),GetNumGroupMembers()) -- number in group, 1 if solo, see Recap_JoinLeaveGroup for more comments
					if count == 1 and rOpt.LimitFights.value then
						-- if the player is not in a group, and if "Limit Fights to Combat" is checked, then do not restart the timer (we want the fight to time out as long as the player continues to do nothing)
					else
						if rOpt.LimitToEncounters.value then
							-- if we are limiting to Blizzard encounters, then if we get here the encounter must have ended
							-- so don't reset the timer due to ongoing damage
						else
							-- normally, restart the timer since the fight continues
							--   but only for actual combat damage events (or combat damage misses), don't restart for healing
							-- 2014 June removed SPELL_MISSED and SPELL_PERIODIC_MISSED, since they could be a failed heal
							if (eventType == "SWING_DAMAGE") or (eventType == "RANGE_DAMAGE") or (eventType == "SPELL_DAMAGE") or (eventType == "SPELL_PERIODIC_DAMAGE") or
							   (eventType == "DAMAGE_SHIELD") or (eventType == "DAMAGE_SPLIT") or (eventType == "SWING_MISSED") or (eventType == "RANGE_MISSED") or
							   (eventType == "DAMAGE_SHIELD_MISSED") then
								rTemp.EndFightDelayTimer = 0
							end
						end
					end
				end
			end
		elseif (eventType == "SPELL_HEAL") or (eventType == "SPELL_PERIODIC_HEAL") then
			-- in this context, ignore heals that do zero net healing (many Fel Armor and Spirit Bond ticks, for example) so that we do not unnecessarily extend a fight
			local spellID, _, _, amount, overheal = select(12, ...)
			if amount then
				amount = Recap_Round0(amount) -- paranoia 5.0.4
			end
			if overheal then
				overheal = Recap_Round0(overheal) -- paranoia 5.0.4
			end
			if amount and ((amount - (overheal or 0)) > 0) then
				-- if this is a positive healing event, start or restart the idle timers
				if (spellID == 145108) then
					-- 2014-May-31: Ysera's Gift (spell ID 145108), a passive healing ability, will not start or extend a fight
					-- do nothing
				else
					if rOpt.IdleFight.value then
						rTemp.IdleTimer = 0
					end
					rTemp.HiddenIdleTimer = 0
				end
				-- we do not restart the end of fight timer for heals
			end
		end
	end

	-- 2014 June two returns used to be here, moved to later in the function

	-- we seem to occasionally have orphan Searing Totems for which ownership has not been determined
	-- the cause not yet been figured out
	-- ditto for other pets on occasion
	-- some are probably related to dismounting and having the pet reappear unclaimed, but that's not the entire story, nor does it help figure out how to prevent or fix such anomalies
	-- mind control effects occur with SPELL_AURA_APPLIED but unfortunately we don't get both source and dest so that we could set up a pet immediately
	-- Note on 2013-Feb-07 some of these may have been fixed by properly registering UNIT_PET event

	-- Notes on 2010-Nov-29
	-- a pet or guardian that appears without an explicit SUMMON will not necessarily be assigned immediately; and a guardian without an explicit SUMMON and that is never 'pet' or 'partypet' or 'raidpet' will not be assigned at all (see Recap_MakeFriends)
	-- note that the unit flags would allow us to assign a guardian to the player (0x2111 for Shadowy Apparition is TYPE_GUARDIAN + CONTROL_PLAYER + REACTION_FRIENDLY + AFFILIATION_MINE) when we unexpectedly encounter one,
	--   but not reliably for other combatants (their guardians are marked as AFFILIATION_PARTY or AFFILIATION_RAID), so Recap is not doing it just for the player (which would give a biased comparison with other shadow priests, something I don't want to have Recap do)

	-- Ownership change code (Part 1)
	-- if both source and dest exist and one is recorded as controlling the other, and if the eventType is a hostile spell (heuristic only), then remove the ownership information
	--	  Comment by Hawksy 2012-September-24 this change by renews might be replacing some "owner1:owner2:pet" with "owner1:pet",
	--		which might 'fix' the shaman totems problem but with a larger hammer than ideally necessary
	Recap_TrimOwnedBy(sourceNameGUID) -- added to limit recursion of owner1 = owner2
	Recap_TrimOwnedBy(destNameGUID) -- added to limit recursion of owner1 = owner2
	local rootOwnerSource = Recap_RootOwner(sourceNameGUID)
	local rootOwnerDest = Recap_RootOwner(destNameGUID)

	if sourceNameGUID and rCombatants[sourceNameGUID] and destNameGUID and rCombatants[destNameGUID] and
	   ((rootOwnerSource == destNameGUID) or (rootOwnerDest == sourceNameGUID)) then
		if Recap_HostileEvent(eventType, eventIsCombatDamageEquivalent, sourceNameGUID, destNameGUID, ...) then
			-- remove OwnedBy information
			if (rootOwnerSource == destNameGUID) then
				rCombatants[sourceNameGUID].OwnedBy = nil
				rootOwnerSource = nil
			end
			if (rootOwnerDest == sourceNameGUID) then
				rCombatants[destNameGUID].OwnedBy = nil
				rootOwnerDest = nil
			end
		end
	end

	-- assert: at this point sourceNameGUID and destNameGUID do not have any 'owner' prepended


	-- Ownership change code (Part 2)
	-- if a combatant is controlled, replace any simple name with a fully qualified name "owner:pet"
	-- if we can tell conclusively that a combatant is no longer controlled, remove the ownership information
	local sourceOwnerNameGUID = sourceNameGUID
	local destOwnerNameGUID = destNameGUID

	if sourceNameGUID and rCombatants[sourceNameGUID] then
		-- existing combatant
		if rootOwnerSource then
			-- there is recorded ownership
			local owner =  rootOwnerSource
			local wasControlled = 0
			if rCombatants[sourceNameGUID].Flags then
				wasControlled = bit_band(rCombatants[sourceNameGUID].Flags, COMBATLOG_OBJECT_TYPE_PET)
			end
			local isControlled = bit_band(sourceFlags, COMBATLOG_OBJECT_TYPE_PET)
			if (wasControlled ~= 0) and (isControlled == 0) then
				-- the combatant was flagged as a controlled pet but is no longer, so remove ownership information
				-- note that we never do this for guardians and objects (which always remain pets)
				rCombatants[sourceNameGUID].OwnedBy = nil
			else
				-- probably still controlled, so slap the owner of record in front
				-- note that this could now be "owner:pet" or "owner:owner:pet" (and possibly stacked even higher though we haven't seen one yet, and our code doesn't currently handle triple-decker owners)
				sourceOwnerNameGUID = owner..":"..sourceNameGUID

				-- the following might be obsolete comments (as of 2010-Nov-29)
				-- we don't yet have Hunter owning Snake Trap, and Snake Trap owning Viper, but we're ready
				-- Midnight summons Attumen who summons Attumen-on-horseback, three different GUIDs, leading to "owner:owner:pet"
				-- Illhoof summons Fiendish Portal which summons Fiendish Imps
				-- mind controlling someone who has a pet does not gain ownership of the pet, which becomes instead hostile to its now-mind-controlled former owner
				-- no examples so far of a mind controlled entity being able to summon a pet
			end
		else
			-- no recorded ownership, do nothing even if they are flagged as controlled
		end
	end
	if destNameGUID and rCombatants[destNameGUID] then
		-- existing combatant
		if rootOwnerDest then
			-- there is recorded ownership
			local owner = rootOwnerDest
			local wasControlled = 0
			if rCombatants[destNameGUID].Flags then
				wasControlled = bit_band(rCombatants[destNameGUID].Flags, COMBATLOG_OBJECT_TYPE_PET)
			end
			local isControlled = bit_band(destFlags, COMBATLOG_OBJECT_TYPE_PET)
			if (wasControlled ~= 0) and (isControlled == 0) then
				-- the combatant was flagged as a controlled pet but is no longer, so remove ownership information
				-- note that we never do this for guardians and objects (which always remain pets)
				rCombatants[destNameGUID].OwnedBy = nil
			else
				-- probably still controlled, so slap the owner of record in front
				-- note that this could now be "owner:pet" or "owner:owner:pet" (and possibly stacked even higher though we haven't seen one yet, and our code doesn't currently handle triple-decker owners)
				destOwnerNameGUID = owner..":"..destNameGUID
			end
		else
			-- no recorded ownership, do nothing even if they are flagged as controlled (would be an unknown owner)
		end
	end

	-- at this point we have both sourceNameGUID and sourceOwnerNameGUID (which may have no owner), and similarly for dest
	-- we use destOwnerNameGUID for everything that follows *except* for a summon or create event for which we must have an unqualified name

	-- various processing for the fully-qualified names (already happened for the bare names)
	if sourceOwnerNameGUID and rCombatants[sourceOwnerNameGUID] and (sourceOwnerNameGUID ~= sourceNameGUID) then
		-- a name we did not process earlier
		-- check for ignores on the name before we go any further
		if rCombatants[sourceOwnerNameGUID].Ignore then
			if (rUser.SyncState ~= "Member") and (rUser.SyncState ~= "Leader") then
				-- sourceOwnerNameGUID is an ignored combatant, not in synchronization, pretend the event didn't happen at all
				return true
			end
		end
		Recap_ProcessCombatant(timestamp, rCombatants[sourceOwnerNameGUID], sourceFlags)
	end
	if destOwnerNameGUID and rCombatants[destOwnerNameGUID] and (destOwnerNameGUID ~= destNameGUID) then
		-- a name we did not process earlier
		-- check for ignores on the name before we go any further
		if rCombatants[destOwnerNameGUID].Ignore then
			if (rUser.SyncState ~= "Member") and (rUser.SyncState ~= "Leader") then
				-- destOwnerNameGUID is an ignored combatant, not in synchronization, pretend the event didn't happen at all
				return true
			end
		end
		Recap_ProcessCombatant(timestamp, rCombatants[destOwnerNameGUID], destFlags)
	end
	if sourceOwnerNameGUID and rCombatants[sourceOwnerNameGUID] and destOwnerNameGUID and rCombatants[destOwnerNameGUID] and (sourceOwnerNameGUID ~= destOwnerNameGUID) and
		((sourceOwnerNameGUID ~= sourceNameGUID) or (destOwnerNameGUID ~= destNameGUID)) then
		-- a combination of names we did not process earlier
		-- both combatants exist, check for hostility
		-- if the source combatant is marked as Friend, and is not in the group, and is doing something hostile to someone who is in the group, then remove the Friend mark (heuristic only)
		if rCombatants[sourceOwnerNameGUID].Friend and (not rTemp.InGroup[sourceOwnerNameGUID]) and rTemp.InGroup[destOwnerNameGUID] then
			if Recap_HostileEvent(eventType, eventIsCombatDamageEquivalent, rCombatants[sourceOwnerNameGUID], rCombatants[destOwnerNameGUID], ...) then
				rCombatants[sourceOwnerNameGUID].Friend = false
				rTemp.InFriend[sourceOwnerNameGUID] = nil
			end
		end
		-- similarly if someone in the group is doing something hostile to a dest combatant marked as Friend but who is not in the group
		if rCombatants[destOwnerNameGUID].Friend and (not rTemp.InGroup[destOwnerNameGUID]) and rTemp.InGroup[sourceOwnerNameGUID] then
			if Recap_HostileEvent(eventType, eventIsCombatDamageEquivalent, rCombatants[sourceOwnerNameGUID], rCombatants[destOwnerNameGUID], ...) then
				rCombatants[destOwnerNameGUID].Friend = false
				rTemp.InFriend[destOwnerNameGUID] = nil
			end
		end
	end


	-- 2014 June we have moved these two returns down below the pet ownerships code (see spot marked earlier)
	-- okay, if we are limiting fights to combat, and if the fight hasn't started yet, don't track damage or healing or buffs
	-- this could lead to a few anomalies -- tough, it isn't a recommended setting anyway
	if (rUser.State == "Idle") and (rOpt.LimitFights.value or rOpt.LimitToEncounters.value) and (processOOCShields == false) then
		-- fight hasn't started yet, and we are asked to ignore fights when we aren't personally 'in combat' (the event PLAYER_REGEN_DISABLED will start a fight if necessary)
		--   with 4.77 don't continue if we are limiting to Blizzard encounters (the event ENCOUNTER_START will start a fight if necessary)

		-- 2014 June we need to record SUMMON events even when idle
		if eventType == "SPELL_SUMMON" then
			-- stick around
		else
			-- all other events
			return
		end
	end

	if (rUser.SkipNextFight == true) and (processOOCShields == false) then
		-- we are skipping this fight
		-- we've perhaps started the fight, and we've tickled the idle timers, but we won't track damage or healing or buffs or pet ownership changes (which could lead to anomalies later, tough)

		-- 2014 June we need to record SUMMON events even when skipping fights
		if eventType == "SPELL_SUMMON" then
			-- stick around
		else
			-- all other events
			return
		end
	end

	-- we now replace a long if-then-elseif chain with a dispatch table based on eventType, for a mild speed improvement
	local eventDispatchFunction = eventDispatchTable[eventType]
	if (eventDispatchFunction == true) then
		-- this is an event we want to ignore
	elseif (type(eventDispatchFunction) == "function") then
		-- this is an event we want to process
		-- check for storing only some events (do it here when we know the event is okay)
		if rOpt.StoreOnlyDisplayed.value then
			sourceOwnerNameGUID, destOwnerNameGUID = Recap_FilterDoNotStore(sourceOwnerNameGUID, destOwnerNameGUID)
		end
		if (sourceOwnerNameGUID == nil) and (destOwnerNameGUID == nil) then
			-- ignore entirely
			-- there is at least one loophole when storing only the player: the player will not get credit for shield absorption cast on someone else (is this still true with the new code for Cataclysm?)
			return
		end
		-- save our arguments for possible error message purposes (not sure if this is more or less efficient than passing it around)
		ArgumentListForErrorReporting = { ... }
		-- the argument destNameGUID is used only by Recap_DispatchSpellSummonCreate
		eventDispatchFunction(timestamp, eventType, sourceOwnerNameGUID, sourceFlags, specialMelee, destOwnerNameGUID, destNameGUID, destFlags, select(12, ...))
	else
		-- unexpected event
		Recap_CheckUnexpectedEvent("unexpected event", ...)
	end

	-- tidy up (early exits don't tidy up, no big deal)
	ArgumentListForErrorReporting = wipe(ArgumentListForErrorReporting)

end


function Recap_Register_CombatEvents()
	local rTemp = _G.recap_temp

	if not rTemp.CombatEventsRegistered then
		if rTemp.FlagDataInitializationCompleted then
			-- events for WoW patch 2.4
			RecapCombatEvents:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");

			-- two other events
			RecapCombatEvents:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
			RecapCombatEvents:RegisterEvent("PLAYER_TARGET_CHANGED")

			-- register for receiving messages on sync channel
			--   (in a sense this doesn't really belong here, oh well)
			Recap:RegisterComm("Recap", "OnCommReceived")

			rTemp.CombatEventsRegistered = true
		end
	end
end


function Recap_Unregister_CombatEvents()
	local rTemp = _G.recap_temp
	if rTemp.CombatEventsRegistered then
		RecapCombatEvents:UnregisterAllEvents()
		rTemp.CombatEventsRegistered = false
	end
end


RecapCombat_lua_4773 = true
