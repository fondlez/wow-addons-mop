﻿--[[ Copyright 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 by Hawksy, distributed under the terms of the GNU General Public License version 3, 2007-June-29, which is included by reference. ]]

--[[ RecapClipboard.lua ]]

--[[ local tables ]]

local dockoffset = { ["TOPRIGHTTOPLEFT"] = { x=-4,y=0 },
					 ["BOTTOMRIGHTBOTTOMLEFT"] = { x=-4,y=0 },
					 ["TOPLEFTTOPRIGHT"] = { x=4,y=0 },
					 ["BOTTOMLEFTBOTTOMRIGHT"] = { x=4,y=0 },
					 ["TOPRIGHTBOTTOMRIGHT"] = { x=0,y=-4 },
					 ["BOTTOMRIGHTTOPRIGHT"] = { x=0,y=4 },
					 ["TOPLEFTBOTTOMLEFT"] = { x=0,y=-4 },
					 ["BOTTOMLEFTTOPLEFT"] = { x=0,y=4 } }

--[[ global functions ]]

function Recap_ClipFrameOffset(axis)

	local anchor

	anchor = recap_user.ClipFrameAnchor.Main..recap_user.ClipFrameAnchor.ClipFrame
	if dockoffset[anchor] and axis then
		return dockoffset[anchor][axis]
	else
		return 0
	end
end

function RecapClipFrame_OnMouseDown(frame, button, which)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapClipFrame:StartMoving()
	end
end

function RecapClipFrame_OnMouseUp(frame, button)
	local rTemp = _G.recap_temp
	if rTemp.Loaded and (button == "LeftButton") then
		RecapClipFrame:StopMovingOrSizing()
		if recap_user.ClipFrameAnchor.value then
			RecapClipFrame:ClearAllPoints()
			RecapClipFrame:SetPoint(recap_user.ClipFrameAnchor.ClipFrame,"RecapFrame",recap_user.ClipFrameAnchor.Main,Recap_ClipFrameOffset("x"),Recap_ClipFrameOffset("y"))
		end
	end
end


RecapClipboard_lua_4773 = true
