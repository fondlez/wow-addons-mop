﻿if (GetLocale() == "deDE") then

-- German translations by Dhana
-- Translations updated 2008-05-14

--[[ Miscellaneous variables and localization strings for Recap ]]

recap_temp = {} -- other global values (not saved to SavedVariables)

--[[ Tooltips, option indexes ]]

-- First field of each line MUST NOT CHANGE (they are option ids)
-- the order MUST NOT CHANGE until the item "HeaderClass".  They are in the order of GetID values
recap_temp.OptList = {
	{ "ShowClickHints", "Show Click Hints", "When checked, and when the preceding 'Show Tooltips' option is also checked, the portion of tooltips that gives click hints will be shown, for example:\n\n|cFF9090FFClick Hints:\n•• Click this check box to enable or disable this option." }, -- 1
	{ "GrowUpwards", "Erweitere Dialog nach oben", "Wenn dort ein H\195\164kchen steht, wird die untere Ecke verankert bleiben, w\195\164hrend die obere Ecke in der Gr\195\182sse angepasst wird." },
	{ "GrowLeftwards", "Erweitere Dialog nach links", "Wenn dort ein H\195\164kchen steht, wird die rechte Ecke verankert bleiben, w\195\164hrend die linke Ecke in der Gr\195\182sse angepasst wird." },
	{ "ShowTooltips", "Zeige Tooltips", "Wenn dort ein H\195\164kchen steht, werden Tooltips angezeigt, wie dieser hier, den du gerade liest." },
	{ "AutoHide", "Automatisch ausblenden bei Kampfbeginn", "Wenn dort ein H\195\164kchen steht und der Dialog nicht minimiert ist, wird es ausgeblendet, sobald ein Kampf beginnt. Es erscheint wieder, wenn der Kampf beendet ist." },
	{ "AutoFade", "Dialog automatisch ausblenden", "Wenn dort ein H\195\164kchen steht und der Dialog nicht minimiert ist, wird der Dialog ausgeblendet, sobald die Maus nicht mehr in diesem Dialog ist.\n\nTo bring the window back after it has faded, type '/recap'." },
	{ "LimitFights", "Kampfstatistik nur, wenn im Kampf", "Wenn dort ein H\195\164kchen steht, wird die Kampfstatistik erst beginnen, wenn du selber im Kampf bist. Empfohlen: Aus, wenn du die K\195\164mpfe um dich herum nicht aufzeichnen willst." },
	{ "HideZero", "Zeige nur K\195\164mpfe mit Zeitdauer", "Wenn dort ein H\195\164kchen steht, werden K\195\164mpfe ohne Zeitdauer nicht gezeigt.  N\195\188tzlich, um Schaden herauszufiltern, die z.B. durch Totems oder Tiere, etc. verursacht werden." },
	{ "HideOthers", "Verstecke weitere K\195\164mpfer", "Wenn dort ein H\195\164kchen steht, werden alle weiteren K\195\164mpfer, die nicht in der Gruppe sind, versteckt. Dies beinhaltet Alliierte, Neutrale und Feinde.\n\nDiese Option solle normalerweise ausgeschaltet sein.\n\nNote that this option can not be enabled at the same times as both Store Only Displayed Combatants and Auto Save Boss Fights." },
	{ "IdleFight", "Beende Kampf, wenn unt\195\164tig", "Wenn dort ein H\195\164kchen steht, werden K\195\164mpfe beendet, wenn f\195\188r eine l\195\164ngere Zeit kein Treffer stattfindet." }, -- 10
	{ "Time", "Anzeigen der Zeit", "Wenn dort ein H\195\164kchen steht, wird die Kampfzeit jedes K\195\164mpfers in der Liste angezeigt." },
	{ "MaxHit", "Anzeigen des max. Treffers", "Wenn dort ein H\195\164kchen steht, wird der h\195\182chste Treffer jedes K\195\164mpfers in der Liste angezeigt." },
	{ "DmgIn", "Anzeigen des erhaltenen Schadens", "Wenn dort ein H\195\164kchen steht, wird der gesamte erhaltene Schaden jedes K\195\164mpfers in der Liste angezeigt." },
	{ "DmgOut", "Anzeigen des verursachten Schadens", "Wenn dort ein H\195\164kchen steht, wird der gesamte verursachten Schaden jedes K\195\164mpfers in der Liste angezeigt." },
	{ "DPSIn", "Anzeigen des erhaltenen DPS", "Wenn dort ein H\195\164kchen steht, wird der Schaden, den jeder K\195\164mpfer pro Sekunde einsteckt, in der Liste angezeigt." },
	{ "DPS", "Anzeigen der DPS", "Wenn dort ein H\195\164kchen steht, wird der Schaden, den jeder K\195\164mpfer pro Sekunde austeilt, in der Liste angezeigt." },
	{ "MinStatus", "Anzeigen des Status wenn minimiert", "Wenn dort ein H\195\164kchen steht, bleibt das Statuslicht sichtbar, auch, wenn der Dialog minimiert ist." },
	{ "MinView", "Anzeigen von 'Letzter Kampf' / 'Alle K\195\164mpfe', wenn minimiert", "Wenn dort ein H\195\164kchen steht, zeigt eine kleine Aufschrift, ob du den letzten Kampf oder alle K\195\164mpfe angezeigt bekommst, wenn der Dialog minimiert ist." },
	{ "MinYourDPS", "Anzeigen deines DPS, wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird dein Schaden pro Sekunde (DPS) im minimierten Modus angezeigt." },
	{ "MinDPSIn", "Anzeigen des erhaltenen Schadens, wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird der Schaden pro Sekunde (DPS), den alle freundlich gesonnenen K\195\164mpfer erhalten, im minimierten Modus angezeigt." }, -- 20
	{ "MinDPSOut", "Anzeigen des verursachten Schadens, wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird der Schaden pro Sekunde (DPS), den alle freundlich gesonnenen K\195\164mpfer austeilen, im minimierten Modus angezeigt." },
	{ "MinButtons", "Anzeigen der Buttons, wenn minimiert", "Wenn dort ein H\195\164kchen steht, werden die Buttons in der rechten oberen Ecke (Schliessen, Sperren, Pause, Optionen, Letzter/Alle) im minimierten Zustand sichtbar bleiben." },
	{ "TooltipFollow", "Tooltips am Mauszeiger", "Wenn dort ein H\195\164kchen steht, werden die Tooltips dem Mauszeiger folgen, statt an der normalen Stelle zu erscheinen. Achtung: Viele mods \195\188berschreiben das Standard-Tooltip-Verhalten." },
	{ "SaveGroup", "Nur Freunde speichern", "Wenn dort ein H\195\164kchen steht, werden nur K\195\164mpfer gespeichert, die gerade als Freund markiert sind. Um den Freund-Status eines K\195\164mpfers zu \195\164ndern, ist ein rechts-klick auf dessen Name n\195\182tig." },
	{ "AutoSaveBossFights", "Auto Save Boss Fights", "When checked, Recap will automatically save every fight that is identified as a boss fight.  A boss fight is one with a 'skull' boss present.  A boss who is not 'skull' to you will not be automatically saved.\n\nWarning: If this option is enabled, and if you don't visit the Options / Data Sets tab frequently to delete unwanted data sets, the amount of memory used by Recap will grow rapidly.\n\nNote that this option can not be enabled at the same times as both Hide Other Combatants and Store Only Displayed Combatants." },
	{ "Heal", "Anzeigen der Heilung", "Wenn dort ein H\195\164kchen steht, wird die verursachte Heilung jedes K\195\164mpfers in der Liste angezeigt." },
	{ "Deaths", "Anzeigen der Tode", "Wenn dort ein H\195\164kchen steht, wird die Anzahl der Tode jedes K\195\164mpfers in der Liste angezeigt." },
	{ "HideYardTrash", "Zeige nur einzelne K\195\164mpfer", "Wenn dort ein H\195\164kchen steht, werden nicht-freundliche K\195\164mpfer, die mehr als einmal mit dem gleichen Namen vorhanden sind, nicht angezeigt. N\195\188tzlich in Instanzen, in denen man alleine ist, um gew\195\182hnliche Mobs heraus zu filtern." },
	{ "PauseOutsideInstances", "Pause Outside Instances", "When checked, Recap will automatically pause whenever it detects that it has left an instance, and resume whenever it detects that it has entered an instance." },
	{ "Faction", "Anzeigen von Level/Fraktion", "Wenn dort ein H\195\164kchen steht, wird Level und Fraktion des K\195\164mpfers angezeigt, falls bekannt." }, -- 30
	{ "Class", "Anzeigen der Klasse", "Wenn dort ein H\195\164kchen steht, wird ein Icon neben dem Namen angezeigt, falls die Klasse des K\195\164mpfers bekannt ist." },
	{ "HealP", "Anzeiger der Heilung in %", "Wenn dort ein H\195\164kchen steht, wird die gesamt verursachte Heilung in Prozent f\195\188r jeden befreundeten K\195\164mpfer angezeigt." },
	{ "DmgInP", "Anzeigen des erhaltenen Schadens in %", "Wenn dort ein H\195\164kchen steht, wird die Prozentzahl des erhaltenen Schadens f\195\188r jeden befreundeten K\195\164mpfer angezeigt." },
	{ "DmgOutP", "Anzeigen des verursachten Schadens in %", "Wenn dort ein H\195\164kchen steht, wird die Prozentzahl des verursachten Schadens f\195\188r jeden befreundeten K\195\164mpfer angezeigt." },
	{ "AutoPost", "Poste Rangfolgenwechsel automatisch", "Wenn dort ein H\195\164kchen steht, werden Wechsel in der Rangfolge der Statistik automatisch gepostet. Nach welcher Statistik es gerade geht, wird unter 'Bericht' festgelegt und in den neben angegebenen Channel gepostet." },
	{ "MinBack", "Anzeigen des Hintergrunds, wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird der Hintergrund undurchsichtig bleiben im minimierten Zustand." },
	{ "MergePets", "Fasse Pets mit Eigent\195\188mer zusammen", "Wenn dort ein H\195\164kchen steht, wird der verursachte Schaden des Pets, dessen Eigent\195\188mer angerechnet. Wenn dort kein H\195\164kchen steht, wird der vom Pet verursachte Schaden dem Pet zugerechnet." },
	{ "AutoMinimize", "Auto Minimieren", "Wenn dort ein H\195\164kchen steht, wird der Dialog automatisch minimiert, sobald der Mauszeiger den Dialog verl\195\164sst. Es vergr\195\182ssert sich wieder, wenn der Mauszeiger \195\188ber dem Dialog ist. Gedr\195\188ckthalten der Shift-Taste oder Auswahl eines K\195\164mpfers \195\188berschreibt dieses Verhalten." },
	{ "ShowPanel", "Zeige Details", "Wenn dort ein H\195\164kchen steht, wird eine Seitenkonsole gezeigt. Diese Seitenkonsole liefert detailiertere Informationen und erscheint, wenn der Mauszeiger \195\188ber den K\195\164mpfern steht. W\195\164hle einen K\195\164mpfer aus, um die Konsole zu sperren. Im einfachen Modus ist nur eine kurze Zusammenfassung ersichtlich." },
	{ "LightData", "Einfacher Modus", "Wenn dort ein H\195\164kchen steht, werden Zusatzinformationen, wie Verfehlungen und 'damage breakdowns' nicht gesammelt bzw. gespeichert.\n\nWenn dort KEIN H\195\164kchen steht, werden Verfehlungen und Schadens-Details in der Detailkonsole angesammelt.\n\nBeachte: Momentan werden diese Daten ber\195\188cksichtigt!" }, -- 40
	{ "ShowGauges", "Zeige Skala", "Wenn dort ein H\195\164kchen steht, eine Skala erscheint hinter befreundeten K\195\164mpfern um Schaden und Heilung besser zu visualisieren.\n\nUm zu w\195\164hlen, welche Skala benutzt werden soll, sortierung geschieht durch Links-Klicken auf den Kopf der jeweiligen Spalte." },
	{ "AutoLeader", "Poste den Anf\195\188hrerwechsel automatisch", "Wenn dort ein H\195\164kchen steht, werden Wechsel des Anf\195\188hrers automatisch gepostet." },
	{ "Ranks", "Nummerierte Liste", "Wenn dort ein H\195\164kchen steht, wird die Liste nummeriert." },
	{ "DPSvsAll", "Anzeigen von DPS vs Gesamt", "Wenn dort ein H\195\164kchen steht, wird ein DPS-Wert angezeigt, der den individuellen verursachten Schaden jedes K\195\164mpfers angibt." },
	{ "Over", "\195\156berheilung", "Wenn dort ein H\195\164kchen steht, ein gesch\195\164tzter Prozentwert an \195\156berheilung wird f\195\188r jeden befreundeten K\195\164mpfer angezeigt. (F\195\188r alle K\195\164mpfe).\n\nBeachte: Mana-effiziente Heiler nutzen die langsamen kr\195\164ftigen Heilungen.  Paladins und andere Heiler, die w\195\164hrend es Kampfes durch kleine schnelle Heilungen helfen, verf\195\164lschen oft das Bild der Mana-effizienten Heiler.\n\nNutze dies nicht als Massstab der F\195\164higkeit des Heilers." },
	{ "HTML", "Format in HTML", "Wenn dort ein H\195\164kchen steht, werden die logs, die nach WoWChatLog.txt oder in den clipboard geschrieben werden, in eine einfache HTML Tabelle konvertiert." },
	{ "WriteGroup", "Schreibe nur Gruppe", "Wenn dort ein H\195\164kchen steht, werden nur Informationen der K\195\164smpfer in der Gruppe mitprotokolliert." },
	{ "ETotal", "Gesamtanzeige", "Wenn dort ein H\195\164kchen steht, wird der gesamte Schaden, bzw die gesamte Heilung jedes Effektes in den pers\195\182nlichen Details angezeigt." },
	{ "ETotalP", "Gesamtanzeige Beitrag", "Wenn dort ein H\195\164kchen steht, wird der Beitrag dieses Effektes zum Gesamten in den pers\195\182nlichen Details angezeigt." },
	{ "EHits", "Anzeigen der Treffer", "Wenn dort ein H\195\164kchen steht, wird die Anzahl der nicht-kritischen Treffer in den personlichen Details angezeigt." }, -- 50
	{ "EHitsAvg", "Anzeigen des durchschnittlichen Treffers", "Wenn dort ein H\195\164kchen steht, wird der durchschnittliche nicht-kritische Treffer in den personlichen Details angezeigt." },
	{ "EHitsMax", "Anzeigen des max. Treffers", "Wenn dort ein H\195\164kchen steht, wird er h\195\182chste nicht-kritische Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "ETicks", "Anzeigen der Ticks", "Wenn dort ein H\195\164kchen steht, wird die Anzahl der Ticks in den pers\195\182nlichen Details angezeigt." },
	{ "ETicksAvg", "Anzeigen des durchschnittlichen Ticks", "Wenn dort ein H\195\164kchen steht, wird der durchschnittliche Tick in den pers\195\182nlichen Details angezeigt." },
	{ "ETicksMax", "Anzeigen des max. Tick", "Wenn dort ein H\195\164kchen steht, wird der h\195\182chste Tick in den pers\195\182nlichen Details angezeigt." },
	{ "ECrits", "Anzeigen der kritischen Treffer", "Wenn dort ein H\195\164kchen steht, wird die Anzahl der kritischen Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "ECritsAvg", "Anzeigen des durchschnittlichen kritischen Treffers", "Wenn dort ein H\195\164kchen steht, wird der durchschnittliche kritische Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "ECritsMax", "Anzeigen des kritischsten Treffers", "Wenn dort ein H\195\164kchen steht, wird er h\195\182chste kritische Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "ECritsP", "Anzeigen der kritischen Trefferrate", "Wenn dort ein H\195\164kchen steht, wird die kritische Trefferrate f\195\188r jeden Effekt in den pers\195\182nlichen Details angezeigt." },
	{ "EMiss", "Anzeigen der Verfehlungen", "Wenn dort ein H\195\164kchen steht, wird die Anzahl der Verfehlungen f\195\188r jeden Effekt in den pers\195\182nlichen Details angezeigt. Bei Fernkampf beinhaltet es Verfehlen, Absorbiereb und Widerstehen. Bei Nahkampf beinhaltet esBlocken, Parieren und Ausweichen." }, -- 60
	{ "EMissP", "Anzeigen der Verfehlungsrate", "Wenn dort ein H\195\164kchen steht, wird die Verfehlungsrate f\195\188r jeden Effekt in den pers\195\182nlichen Details angezeigt." },
	{ "EMaxAll", "Anzeigen des max Schadens", "Wenn dort ein H\195\164kchen steht, wird der maximale Schaden eines einzigen Schlages, 'tick' oder kritischen Treffers f\195\188r jeden Effekt in den pers\195\182nlichen Details angezeigt." },
	{ "WarnData", "Warnung, wenn Datensatz zu gross wird", "Wenn dort ein H\195\164kchen steht, wird eine Nachricht bei Spielstart eingeblendet, die daran erinnert, dass der Datensatz mehr als 2000 K\195\164mpfer beinhaltet.\n\nRecap funktioniert problemlos mit mehr als 2000 K\195\164mpfern. Jedoch denken viele Nutzer nicht daran, dass sich im Laufe der Zeit viele Daten anh\195\164ufen, an denen sie gar nicht interessiert sind." },
	{ "HPS", "Anzeigen der HPS", "Analog zu DPS gibt es f\195\188r die Heilung eine HPS-Angabe. Wenn dort ein H\195\164kchen steht, wird die gewirkte (aktuelle) Heilung pro Sekunde eines jeden K\195\164mpfers angezeigt." },
	{ "MergeAllPetsIntoOne", "Merge All Pets into One Pet", "When checked, and if Merge Pets is also enabled, all pets for a combatant are merged into one single pet, called 'Pet'.  This applies to permanent pets, temporary pets, traps, totems, controlled mobs, vehicles, and so on.\n\nUse with caution." },
	{ "RecentData", "Datenmodus 'Neuste'", "Wenn dort ein H\195\164kchen steht, werden die letzten Ereignisse gespeichert.\nUm letzte erhaltene und verursachte Ereignisse f\195\188r einen K\195\164mpfer anzuzeigen, klicke in 'Von Quelle erhalten' bzw. 'Dem Ziel zugef\195\188gt' auf den 'Neuste' Button rechts von dem Namen des K\195\164mpfers.\n\nUm letzte verursachte und erhaltene Ereignisse eines Spruchs oder F\195\164higkeit f\195\188r einen K\195\164mpfer anzuzeigen, klicke auf den 'Neuste' Button rechts von Spruch oder F\195\164higkeit des jeweiligen Dialogs.\n\nRecap schreibt diese Ereignisse nicht auf die Festplatte.  Recap startet beim Einloggen mit einem leeren Puffer. Auch ein 'ReloadUI' verursacht eine Pufferleerung.\nWarnung: Wenn dies aktiv ist, verbraucht der Datenmodus 'Neuste' viel Speicher." },
	{ "IgnoreGUIDs", "Ignoriere Global Unique Identifiers", "Wenn dort ein H\195\164kchen steht, werden 'global unique identifiers' ignoriert, die f\195\188r K\195\164mpfer mit wow patch 2.4 eingef\195\188hrt wurden. Recap wird sich vergleichbar zu fr\195\188heren Versionen verhalten und wird bedeutend weniger Speicher verbrauchen.\n\nDie \195\132nderung dieser Option hat ein Reset zur Folge.\n\nIst diese Option aktiviert, ist eine Synchronisation nicht erlaubt." },
	{ "HideGroup", "Verstecke Gruppe", "Wenn dort ein H\195\164kchen steht, werden andere K\195\164mpfer in der Gruppe (und ggf. deren Pets) versteckt. Gruppe beinhaltet f\195\188nf Leute, ein Raid vierzig. Gruppe beinhaltet auch jeden, den du manuell durch das rechts-klick Dropdown-Men\195\188 hinzugef\195\188gt hast.\n\nDiese Option sollte normalerweis ausgeschaltet sein."},
	{ "EElement", "Anzeigen des Elements", "Wenn dort ein H\195\164kchen steht, wird das Element (Arkan, Feuer, etc.) f\195\188r diesen Effekt in den pers\195\182nlichen Details angezeigt." },
	{ "TimeIn", "Anzeigen der Zeit in der Schaden genommen wurde", "Wenn dort ein H\195\164kchen steht, wird die Zeit, in der der K\195\164mpfer Schaden erhalten hat, angezeigt." }, -- 70
	{ "TimeHeal", "Anzeigen der Zeit, in der Heilung erhalten wurde", "Wenn dort ein H\195\164kchen steht, wird die Zeit, in der der K\195\164mpfer Heilung erhalten hat, angezeigt." },
	{ "EnableSync", "Synchronisation aktivieren", "Wenn dort ein H\195\164kchen steht, ist Recap bereit, die Synchronisation zu initiieren oder Synchronisations-Einladungen anderer Spieler zu empfangen. Du wirst eingeladen, einer bestehenden Synchronisation Deiner Gruppe beizutreten.\n\nIst dort kein H\195\164kchen, wird Recap jede aktuell laufende Synchronisation verlassen und weitere Synchronisations-Einladungen ignorieren.\n\nDiese Option ist nicht erlaubt, wenn die Option Ignoriere Global Unique Identifiers aktiviert ist." },
	{ "OpaqueBackground", "Undurchsichtiger Hintergrund", "Wenn dort ein H\195\164kchen steht, werden alle Dialoge mit einem undurchsichtigen schwarzen Hintergrund angezeigt." },
	{ "MinimizeOnEscape", "Minimieren bei Escape", "Wenn dort ein H\195\164kchen steht, wird beim Dr\195\188cken der Escapetaste das Hauptfenster von Recap minimiert.  Other Recap panels will close." },
	{ "MinSyncStatus", "Zeige den Synchronisationsstatus wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird das Synchronisations Status L\195\164mpchen sichtbar bleiben auch, wenn der Dialog minimiert ist." },
	{ "RemindGroupStatus", "Erinnerung bei Betreten oder Verlassen einer Gruppe", "Wenn dort ein H\195\164kchen steht, wird bei Betreten oder Verlassen einer Gruppe eine Meldung angezeigt, die dich daran erinnert, das zu tun, woran du erinnert werden wolltest.  Vielleicht wolltest du ja Recap r\195\164umen, wenn du einer Gruppe beitrittst." },
	{ "Seen", "Erstmals gesehen", "Wenn dort ein H\195\164kchen steht, wird der Zeitpunkt, bei dem der K\195\164mpfer erstmals im Kampflog gesehen wurde in der Liste angezeigt." },
	{ "LiveData", "Live Data Mode", "When checked, Recap will track outgoing DPS, incoming DPS, and outgoing HPS live, in a graph or text display.\n\nWARNING: When active, this mode uses some additional memory, and takes significant additional CPU time. On some machines this may slow your game by an unacceptable amount.\n\nWhen this option is enabled, the graph and text listing panel will automatically appear when anyone in your group does damage or takes damage." },
	{ "OtherData", "Datenmodus 'Sonstige'", "Wenn dort ein H\195\164kchen steht, wird Recap Ereignisse mitprotokollieren, die sich weder auf Schaden, noch auf Heilung beziehen. Dies beinhaltet gewirkte Spr\195\188che, Debuffs/Verlust und Buffs/Erhalt.\n\nWenn diese Option aktiviert ist, k\195\182nnen diese Informationen im Dialog 'Sonstige Details' abgerufen werden.\n\nDiese Informationen werden nicht mitprotokolliert, wenn der einfache Datenmodus aktiviert ist." },
	{ "EHitsMin", "Min Treffer anzeigen", "Wenn dort ein H\195\164kchen steht, wird der minimale nicht-kritische Treffer in den pers\195\182nlichen Details angezeigt." },  -- 80
	{ "ETicksMin", "Min Tick anzeigen", "Wenn dort ein H\195\164kchen steht, wird die minimale Anzahl der Ticks in den pers\195\182nlichen Details angezeigt." },
	{ "ECritsMin", "Min Krit anzeigen", "Wenn dort ein H\195\164kchen steht, wird der minimale kritische Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "EGlances", "Anzeigen der ber\195\188hrenden Treffer", "Wenn dort ein H\195\164kchen steht, wird die Anzahl der ber\195\188hrenden Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "EGlancesMin", "Anzeigen der min ber\195\188hrenden Treffer", "Wenn dort ein H\195\164kchen steht, wird der minimale ber\195\188hrende Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "EGlancesAvg", "Anzeigen der durchschnittl. ber\195\188hrenden Treffer", "Wenn dort ein H\195\164kchen steht, wird der durchschnittliche ber\195\188hrende Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "EGlancesMax", "Anzeigen der max ber\195\188hrenden Treffer", "Wenn dort ein H\195\164kchen steht, wird der maximale ber\195\188hrende Treffer in den pers\195\182nlichen Details angezeigt." },
	{ "RemindInstanceStatus", "Erinnere bei Betreten oder Verlassen einer Instanz", "Wenn dort ein H\195\164kchen steht, wird bei jedem Betreten oder Verlassen einer Instanz eine Nachrichtenbox erscheinen, um Dich daran zu erinnern das zu tun, woran Du erinnert werden wolltest.  Vielleicht willst Du ja Recap r\195\164umen, wenn Du eine Instanz betrittst." },
	{ "StoreOnlyDisplayed", "Speichere nur angezeigte K\195\164mpfer", "Wenn dort ein H\195\164kchen steht, werden die Daten der K\195\164mpfer, die aufgrund der drei obigen Optionen versteckt sind, nicht mitprotokolliert oder gespeichert.Wird ein K\195\164mpfer versteckt, werden die von ihm schon gespeicherten Daten nicht gel\195\182scht.\n\nDiese Option wird w\195\164hrend einer Synchronisation ignoriert.\n\nWarnung: Manchmal \195\188bermittelt Blizzard und Recap nicht sofort, dass ein K\195\164mpfer in der Gruppe, oder ein Pet des Spielers ist. Wenn eine Verz\195\182gerung auftritt, kann es sein, dass alle fr\195\188heren Daten verloren gehen.\n\nEmpfohlen: Aus. Es sei denn, Du willst unbedingt Speicher sparen.\n\nNote that this option can not be enabled at the same times as both Hide Other Combatants and Auto Save Boss Fights." },
	{ "MinYourHPS", "Zeige Deine HPS wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird die Heilung pro Sekunde, die Du verursachst bei minimierter Ansicht angezeigt." },
	{ "MinHPS", "Zeige gesamte HPS wenn minimiert", "Wenn dort ein H\195\164kchen steht, wird die gesamte Heilung pro Sekunde, die alle freundlich gesonnenen K\195\164mpfer verursachen bei minimierter Ansicht angezeigt." },  -- 90
	{ "MatrixData", "Matrix Daten Modus", "Wenn dort ein H\195\164kchen steht, wird Recap protokollieren, wer wem Schaden zuf\195\188gt hat, wer von wem Schaden zugef\195\188gt bekommen hat, und wer von wem geheilt wurde.\n\nIst diese Option aktiviert, kann diese Information in den 'Dem Ziel zugef\195\188gt'-Details (nach links geneigtes Schild) bzw. in den 'Von Quelle erhalten'-Details (nach links zeigendes Schwert) -Dialog angezeigt werden. Diese Informationen werden nicht mitprotokolliert, wenn der einfache Datenmodus aktiviert ist." },
	{ "SetScale", "Setze Skalierung", "Setzt die Skalierung des Recap Feldes." },
	{ "MinYourPetPercent", "Display the Percentage of Your Damage Done by Your Pet(s)", "When checked, the percentage of your damage done by your pet(s) will be displayed in minimized view." },
	{ "ResetOnLogout", "Reset on Logout", "When checked, Recap will automatically Reset All Fights on logout.\n\nWarning: This means that your All Fights data goes away.  If you logout by accident, it still goes away." },
	{ "Dispels", "Display Dispels", "When checked, the number of dispels for each combatant will be displayed in the list.  This includes both desirable dispels and undesirable dispels." },
	{ "LDBSupport", "LibDataBroker Support", "When checked, Recap will make live numbers available for display by LibDataBroker display addons.\n\nDisabling this setting will reload your UI." },
	{ "TabDelimited", "Tab-Delimited Report Format", "When checked, logs written to WoWChatLog.txt or the clipboard will be formatted in a simple tab-delimited format, suitable for pasting into a spreadsheet." },
	{ "PauseInsideBattlegrounds", "Pause Inside Battlegrounds", "When checked, Recap will automatically pause whenever it detects that it has entered a battleground instance, and resume whenever it detects that it has left a battleground instance." },
	{ "PostInColumns", "Post in Columns", "When checked, multi-item posts such as DPS will be spaced so that the items align in columns (default).  When not checked, the items will be separated by single spaces only." },
	{ "DPSPerGear", "Display DPS Out / Gear Value Ratio", "When checked, each combatants' damage per second done to others, divided by gear value, will be displayed in the list.\n\nNote: I'm aware of how superficial this ratio can be, involving as it does DPS (itself a matter of debate) and gear value (rather subjective). Use at your own risk.\n\nWarning: For All Fights data the gear value used will be the highest one seen by Recap for that combatant." },  -- 100
	{ "Interrupts", "Display Interrupts", "When checked, the number of interrupts for each combatant will be displayed in the list.  This includes both desirable interrupts and undesirable interrupts." },
	{ "LimitToEncounters", "Limit Fights to Encounters only", "NOT CURRENTLY RECOMMENDED FOR USE: When checked, fight logging will only begin on a Blizzard encounter start event.  Logging will end on a Blizzard encounter end event (plus end fight delay)." },

	-- tooltips that don't change can go below in any order. Ensure future options go above these
	{ "HeaderClass", "Class", "This is an icon representing the class of this combatant, if known." },
	{ "HeaderSeen", "Erstmals gesehen", "Dies ist der Zeitpunkt, als dem der K\195\164mpfer erstmals im Kampflog gesehen wurde." },
	{ "HeaderTime", "Kampfzeit", "Dies ist die Gesamtzeit, die jeder K\195\164mpfer im Kampf verbracht hat." },
	{ "HeaderTimeIn", "Schaden (Zeit)", "Dies ist die Zeit, in der jeder K\195\164mpfer Schaden erhalten hat. Angefangen vom ersten erhaltenen, bis zum letzten erhaltenen Schaden." },
	{ "HeaderTimeHeal", "Heilung (Zeit)", "Dies ist die Zeit, in der jeder K\195\164mpfer Heilung erhalten hat. Angefangen von der ersten erhaltenen, bis zur letzten erhaltenen Heilung." },
	{ "HeaderMaxHit", "Maximaler Treffer", "Dies ist der h\195\182chste Schaden, den jeder K\195\164mpfer durch einen einzigen Schlag verursacht hat." },
	{ "HeaderDmgIn", "Schaden erhalten", "Dies ist der Schaden, den jeder K\195\164mpfer einstecken musste." },
	{ "HeaderDmgOut", "Schaden verursacht", "Dies ist der Schaden, den jeder K\195\164mpfer verursacht hat." },
	{ "HeaderHPS", "Individuelle HPS verursacht", "Dies ist die pers\195\182nliche Heilung pro Sekunde (HPS), die aktuell von jedem K\195\164mpfer geleistet wird. Sie basiert auf der Dauer von der ersten bis zur letzten Heilung." },
	{ "HeaderDPSIn", "Individuelle DPS erhalten", "Dies ist der pers\195\182nliche Schaden pro Sekunde (DPS), der aktuell jeder K\195\164mpfer erh\195\164lt. Er basiert auf der Dauer vom ersten bis zum letzten erhaltenen Schaden." },
	{ "HeaderDPS", "Individueller DPS", "Dies ist der pers\195\182nliche Schaden pro Sekunde (DPS), den jeder K\195\164mpfer verursacht hat." },
	{ "HeaderDPSPerGear", "Individual DPS Out / Gear Value", "This is the personal Damage Per Second done to others by each combatant, divided by gear value.\n\nWarning: For All Fights data the gear value used will be the highest one recorded." },
	{ "HeaderHeal", "Heilung verursacht", "Dies sind die Schadenspunkte, die dieser K\195\164mpfer geheilt hat." },
	{ "HeaderDeaths", "Anzahl der Tode", "Dies ist die Anzahl, wieviele Male der K\195\164mpfer gestorben ist, seit es durch recap mitgez\195\164hlt wird." },
	{ "HeaderDispels", "Dispels Count", "This is the number of times this combatant dispelled an effect within logging distance." },
	{ "HeaderInterrupts", "Interrupts Count", "This is the number of times this combatant interrupted an effect within logging distance." },
	{ "Options", "\195\150ffne Optionen", "\195\150ffnet oder schliesst den Optionen-Dialog, um diverse Einstellungen zu ver\195\164ndern." },
	{ "SyncStatus", "Status der Synchronisation", "Dieses Licht ist blau, wenn man einer Synchronisation beigetreten ist.  Andernfalls ist es grau.  Das blaue Licht blinkt, wenn Synchronisationsdaten ausgetauscht werden." },
	{ "TooltipMinYourDPS", "Dein DPS", "Dies ist dein pers\195\182nlicher Schaden pro Sekunde (DPS), inclusive Pet." },
	{ "TooltipMinYourPetPercent", "Your Pet Percent", "This is the percent of your damage done by your pet." },
	{ "TooltipMinDPSIn", "DPS erhalten", "Dies ist der Gesamtschaden, den befreundete K\195\164mpfer erhalten haben." },
	{ "TooltipMinDPSOut", "DPS verursacht", "Dies ist der Gesamtschaden, den befreundete K\195\164mpfer verursacht haben." },
	{ "TooltipMinYourHPS", "Deine HPS", "Dies ist die durch Dich verursachte Heilung pro Sekunde inkulsive Pet." },
	{ "TooltipMinHPS", "HPS Gesamt", "Dies ist die gesamte Heilung pro Sekunde, die alle freundlich gesonnenen K\195\164mpfer verursachen." },
	{ "AutoFadeSlider", "Zeit, der automatischen Ausblendung", "Dies ist die Zeit, nachdem der Dialog verschwindet, wenn man den Dialog mit der Maus verl\195\164sst. Vorraussetzung: 'Dialog automatisch ausblenden' ist aktiviert." },
	{ "SetScaleSlider", "Set Scale", "Dies ist die Skalierung des Recap Feldes. Von klein (0.5) bis zu gross (2.0).\n\nEine \195\132nderung der Skalierung wird Recap in die Mitte des Bildschirms setzen, und Du kannst es dann an die Position schieben, wohin Du es haben magst." },
	{ "IdleFightSlider", "Zeit, des 'Beende Kampf, wenn unt\195\164tig", "Dies ist die Zeit, die verstreichen muss, bevor der Kampf von Recap als beendet gilt. Vorraussetzung: 'Beende Kampf, wenn unt\195\164tig' ist aktiviert." },
	{ "EndFightDelaySlider", "Kampf-Ende Verz\195\182gerung", "Ein Kampf wird nicht beendet, bis diese Zeit abgelaufen ist, nachdem der Spieler den Kampf verlassen hat. Dies vermeidet kurze 'nicht im Kampf' L\195\188cken, obwohl der Kampf noch l\195\164uft.\n\nWenn um dich herum K\195\164mpge stattfinden, sollte dein 'aktueller Kampf' auch nicht enden, auch, wenn du mehrmals aus und in den Kampf kommst. Wenn dies Problems bereitet, reduziere diese Verz\195\182gerung. Wenn diese Verz\195\182gerung auf Null gesetzt wird, ist das Verhalten das Gleiche, wie in fr\195\188heren Recap Versionen." },
	{ "RecentEventCountSlider", "Recent Event Count", "Dies ist die Anzahl, wieviele letzte Ereignisse gespeichert werden.\n\nDieser Schieberegler kann nur dann ver\195\164ndert werden, wenn der Datenmodus 'Neueste' nicht aktiv ist.\n\nWarnung: Je gr\195\182sser diese Zahl ist, desto mehr Speicher braucht Recap." },
	{ "ExitRecap", "Beende Recap", "Recap wird hierdurch ausgeschaltet. Es werden dann keine weiteren Daten mehr protokollieren, bis es wieder eingeschaltet wird." },
	{ "HideWindow", "Verstecke Dialog", "Protokolliere weiterhin die K\195\164mpfe, verstecke jedoch diesen Dialog." },
	{ "ExpandWindow", "Vergr\195\182ssere Dialog", "Vergr\195\182ssere den Dialog, um Kampfdetails zu sehen." },
	{ "MinimizeWindow", "Minimiere Dialog", "Minimiere den Dialog und verstecke die Kampfdetails." },
	{ "UnPinWindow", "Entsperre Dialog", "Erlaubt es, den Dialog zu verschieben." },
	{ "PinWindow", "Sperre Dialog", "Sch\195\188tzt vor versehentlichem Verschieben des Dialogs." },
	{ "Resume", "Protokollierung fortsetzen", "Momentan werden keine K\195\164mpfe protokolliert. Klicke hier, um das Protokollieren fortzusetzen.  Will do nothing if a save is in progress." },
	{ "PauseMonitoring", "Unterbreche die Protokollierung", "Klicke hier, um die Protokollierung zu unterbrechen. Wenn du Recap verl\195\164sst, w\195\164hrend es im Pause-Modus ist, wird es keine K\195\164mpfe protokollieren, bis es wieder aktiviert wird." },
	{ "ShowAllFights", "Zeige alle K\195\164mpfe", "Momentan zeigt der Dialog das Ergebnis des letzten Kampfes. Klicke hier, um alle K\195\164mpfe anzeigen zu lassen, die seit dem letzten Reset protokolliert wurden." },
	{ "ShowLastFight", "Zeige letzten Kampf", "Momentan zeigt der Dialog das Ergebnis aller K\195\164mpfe seit dem letzten Reset. Klicke hier, um nur den letzten Kampf anzeigen zu lassen." },
	{ "CombatLast", "K\195\164mpfer von 'Letzter Kampf'", "Dies ist die Liste aller K\195\164mpfer, die im letzten Kampf Schaden verursacht, Schaden erhalten oder geheilt haben. Um den Freunde-Status zu \195\164ndern, klicke rechts auf dessen Namen." },
	{ "CombatAll", "K\195\164mpfer von 'Alle K\195\164mpfe'", "Dies ist die Liste aller K\195\164mpfer, die Schaden verursacht, Schaden erhalten oder geheilt haben. Dies gilt seit des letzten Resets. Um den Freunde-Status zu \195\164ndern, klicke rechts auf dessen Namen." },
	{ "ResetLastFight", "Setze den letzten Kampf zur\195\188ck", "Dies l\195\182scht die Daten des letzten Kampfes.  Beachte: Maximaler Treffer und \195\156berheilung kann nur gel\195\182scht werden, wenn 'alle K\195\164mpfe' zur\195\188ckgesetzt werden." },
	{ "ResetAllFights", "Setze alles zur\195\188ck", "Dies l\195\182scht alle aktive Kampfdaten f\195\188r alle K\195\164mpfer, ausser denen, die in in 'pers\195\182nlichen Details' und als Datensatz gespeichert wurden. \nDie gespeicherten Datens\195\164tze k\195\182nnen nur in den Optionen gel\195\182scht werden.\nDie 'pers\195\182nliche Details' k\195\182nnen nur zur\195\188ckgesetzt werden, wenn sie sichtbar sind." },
	{ "SaveAllSet", "Speichere Datensatz 'Alle K\195\164mpfe'", "Klicke hier, um die aktuellen Kampfdaten f\195\188r 'Alle K\195\164mpfe' zu speichern.  Not permitted if already doing a save, or in combat (Blizzard InCombatLockdown)." },
	{ "SaveLastSet", "Speichere Datensatz 'Letzter Kampf'", "Klicke hier, um die aktuellen Kampfdaten f\195\188r 'Letzter Kampf' zu speichern.  Not permitted if already doing a save, or in combat (Blizzard InCombatLockdown)." },
	{ "LoadSet", "Lade Kampfdatensatz", "Klicke hier, um die Kampfdaten zu laden.\n\nWarnung: Das Laden eines Datensatzes \195\188berschreibt deine aktuellen Daten." },
	{ "LoadSetIntoAllFights", "Load Fight Data Set into All Fights", "Click here to load the selected fight data into the All Fights panel.\n\nWarning: Loading a data set here will overwrite your current All Fights data." },
	{ "DeleteSet", "L\195\182sche Kampfdatensatz", "Klicke hier, um die Kampfdaten zu l\195\182schen.\n\nYou can select one fight data set by clicking on it.\n\nYou can select a range of fight data sets by shift+clicking on a second fight data set." },
	{ "DeleteAllSets", "Delete All Fight Data Sets", "Click here to delete all of the fight data sets." },
	{ "RenameSet", "Rename Fight Data Set", "Click here to bring up a dialog box to rename the selected fight data set." },
	{ "DataSetEdit", "Kampfdatensatz-Name", "W\195\164hle einen Datensatz von obiger Liste, oder gib einen neuen Namen ein, um ein neuen Datensatz zu erstellen." },
	{ "OptOk", "Schliessen", "Schliesst den Optionen Dialog." },
	{ "HeaderHealP", "Heilung verursacht in %", "Dies ist die verursachte Gesamtheilung in Prozent f\195\188r jeden befreundeten K\195\164mpfer." },
	{ "HeaderDmgInP", "Schaden erhalten in %", "Dies ist der Gesamtschaden in Prozent, den jeder befreundete K\195\164mpfer erhalten hat." },
	{ "HeaderDmgOutP", "Schaden verursacht in %", "Dies ist der Gesamtschaden in Prozent, den jeder befreundeter K\195\164mpfer verursacht hat." },
	{ "OptTab1", "Optionen anzeigen", "Diese Optionen definieren, welche Elemente des Dialogs gezeigt werden.\n\nBeachte: Keine dieser Einstellungen beeintr\195\164chtigen die protokollierten Daten." },
	{ "OptTab2", "Einstellungen", "Diese Optionen definieren das Dialogverhalten." },
	{ "OptTab3", "Kampfdatens\195\164tze", "Hier kannst Du Kampfdatens\195\164tze verwalten. Kampfdatens\195\164tze sind kompakte Archive der Ansicht 'Alle K\195\164mpfe' oder 'Letzter Kampf'." },
	{ "OptTab4", "Bericht-Optionen", "Hier kannst Du Einstellungen f\195\188r den Bericht vornehmen, die Mitprotokollierung des Chats initiieren und den Bericht in die Zwischenablage kopieren." },
	{ "OptTab5", "Synchronisation", "Hier kannst Du die Synchronisation von Recap einstellen. Recap synchronisiert die 'Alle K\195\164mpfe' Zusammenfassung nach Beendigung jedes Kampfes. Andere Recap Informationen werden momentan nicht synchronisiert." },
	{ "OptTab6", "Ignore Effects", "Here you can arrange to ignore the damage and healing due to specific effects.  You will need to know the numerical spell ID of each effect that you wish to ignore.  Note that the list of effects to ignore is shared among all characters." },
	{ "MaxRowsSlider", "Maximale Zeilen", "Hier kannst du angeben, wieviele Zeilen der Dialog maximal anzeigen soll." },
	{ "MaxRankSlider", "Maximale Reihenfolge", "Hier kannst du anpassen, wieviele Zeilen maximal im Chat ausgegeben werden." },
	{ "PanelClose", "Schliesse Konsole", "Verstecke diese Detailkonsole. Informationen werden weiterhin protokolliert und aufsummiert.  Um dies auch zu stoppen, aktiviere 'Einfacher Modus' in den Optionen." },
	{ "PanelTab1", "Erhaltene Details: 'Getankt'", "Dies zeigt Informationen \195\188ber erhaltenen Schaden, Heilung, und Verfehlungen, die dieser K\195\164mpfer erfahren hat." },
	{ "PanelTab2", "Von Quelle erhalten", "Dies zeigt Informationen \195\188ber die Quellen des erhaltenen Schadens bzw. der erhaltenen Heilung des K\195\164mpfers an.\n\nDiese Option ist standardm\195\164ssig ausgeschaltet. Um diese Informationen zu protokollieren, muss der Matrix Daten Modus in den Optionen / Einstellungen aktiviert werden." },
	{ "PanelTab3", "Verursachte Details: 'Schaden'", "Dies zeigt Informationen \195\188ber verursachten Schaden und Heilung, des K\195\164mpfers." },
	{ "PanelTab4", "Dem Ziel zugef\195\188gt", "Dies zeigt Informationen \195\188ber den Schaden bzw. die Heilung an, die von diesem K\195\164mpfer dem Ziel zugef\195\188gt wurden.\n\nDiese Option ist standardm\195\164ssig ausgeschaltet. Um diese Informationen zu protokollieren, muss der Matrix Daten Modus in den Optionen / Einstellungen aktiviert werden." },
	-- Note: the white in the following tooltip is deliberately exaggerated for contrast
	{ "PanelTab5", "Details 'Sonstige': gewirkte Spr\195\188che, Debuffs/Verlust Buffs/Erhalt", "Dieser Dialog zeigt Informationen der gewirkten Spr\195\188che (in gr\195\188n), Debuffs und Verluste (in rot), Buffs und Erhalt (in blau), und Effekte deren exakter Typ unbekannt sind (in weiss).\n\n Dies beinhaltet nahezu alle Effekte von Blizzard, die sich weder auf Schaden noch auf Heilung beziehen.\n\nDie Option, diese Informationen anzuzeigen, ist defaultm\195\164ssig aus. Um diese Informationen mitzuprotokollieren, aktiviere den Datenmodus 'Sonstige' in den Optionen / Einstellungen." },
	{ "PanelTab6", "Alle Details: Zusammenfassung", "Dies zeigt eine Zusammenfassung der Informationen dieses K\195\164mpfers." },
	{ "PanelTabDisabled1", "Erhaltene Details: 'Getankt' (unterdr\195\188ckt)", "Du nutzt momentan den einfachen Modus. 'Getankte Details und Verfehlungen werden nicht protokolliert.\n\nEntferne das H\195\164kchen bei 'Einfacher Modus' in den Otionen, um diese Informationen auch zu protokollieren." },
	{ "PanelTabDisabled2", "Von Quelle erhalten (deaktiviert)", "Du nutzt momentan den einfachen Datenmodus. Details von den 'Quellen' werden nicht gesammelt. Entferne das H\195\164kchen bei 'Einfacher Modus' in den Optionen, um die Details des erhaltenen Schadens, etc. jedes K\195\164mpfers auch zu protokollieren." },
	{ "PanelTabDisabled3", "Verursachte Details: 'Schaden' (unterdr\195\188ckt)", "Du nutzt momentan den einfachen Modus. Schaden Details werden nicht protokolliert.\n\nEntferne das H\195\164kchen bei 'Einfacher Modus' in den Otionen, um diese Informationen auch zu protokollieren." },
	{ "PanelTabDisabled4", "Dem Ziel zugef\195\188gt (deaktiviert)", "Du nutzt momentan den einfachen Datenmodus. Details von den 'Zielen' werden nicht gesammelt. Entferne das H\195\164kchen bei 'Einfacher Modus' in den Optionen, um die Details des verursachten Schaden, etc. jedes K\195\164mpfers auch zu protokollieren." },
	{ "PanelTabDisabled5", "Details 'Sonstige': gewirkte Spr\195\188che, Debuffs/Verlust Buffs/Erhalt (deaktiviert)", "Recap l\195\164uft im einfachen Datenmodus. Sonstige Details werden nicht mitprotokolliert.\n\nSchalte den einfachen Datenmodus in den Optionen ab, um sonstige Details jedes K\195\164mpfers mitzuprotokollieren." },
	{ "RecentClose", "Schliesse Konsole", "Verstecke diese Detailkonsole. Informationen werden weiterhin protokolliert und aufsummiert." },
	{ "RecentTab1", "Neuste erhaltene Ereignisse", "Dies zeigt neuste erhaltene Ereignisse, die diesem K\195\164mpfer widerfahren sind an.  Eventuell nach Effekten gefiltert." },
	{ "RecentTab2", "Neuste verursachte Ereignisse", "Dies zeigt neuste, von diesem K\195\164mpfer verursachte Ereignisse an. Eventuell nach Effekten gefiltert." },
	{ "PanelEntry25", "Zeit (Letzter Kampf)", "Die Zeitdauer, in der man sich beim letzten Kampf 'im Kampf' befand." },
	{ "PanelEntry26", "Max Treffer (Letzter Kampf)", "Der h\195\182chste Treffer, der im letzten Kampf verursacht wurde." },
	{ "PanelEntry27", "Gestorben (Letzter Kampf)", "Die Anzahl, wie oft man w\195\164hrend des letzten Kampfes gestorben ist." },
	{ "PanelEntry28", "Heilung (Letzter Kampf)", "Die Gesamtangabe, wieviel man Andere im letzten Kampf geheilt hat." },
	{ "PanelEntry29", "Schaden erhalten (Letzter Kampf)", "Der Gesamtschaden, den man w\195\164hrend des letzten Kampfes erhalten hat." },
	{ "PanelEntry30", "Schaden verursacht (Letzter Kampf)", "Der Gesamtschaden, den man w\195\164hrend des letzten Kampfes verursacht hat." },
	{ "PanelEntry31", "DPS (Letzter Kampf)", "Schaden pro Sekunde (DPS) des letzten Kampfes." },
	{ "PanelEntry32", "DPS verursacht (Letzter Kampf)", "DPS verursacht f\195\188r 'Letzter Kampf'." },
	{ "PanelEntry33", "HPS verursacht (Letzter Kampf)", "HPS verursacht (aktuell) f\195\188r 'Letzter Kampf'." },
	{ "PanelEntry34", "HPS verursacht (Alle K\195\164mpfe)", "HPS verursacht (aktuell) f\195\188r 'Alle K\195\164mpfe'." },
	{ "PanelEntry35", "Zeit (Alle K\195\164mpfe)", "Die Zeitdauer, die man insgesamt 'im Kampf' verbracht hat." },
	{ "PanelEntry36", "Max Treffer (Alle K\195\164mpfe)", "Der h\195\182chste Treffer, der in allen K\195\164mpfen verursacht wurde." },
	{ "PanelEntry37", "Gestorben (Alle K\195\164mpfe)", "Die Anzahl, wie oft man in allen K\195\164mpfen gestorben ist." },
	{ "PanelEntry38", "Heilung (Alle K\195\164mpfe)", "Die Gesamtangabe, wieviel man Andere in allen K\195\164mpfen geheilt hat." },
	{ "PanelEntry39", "Schaden erhalten (Alle K\195\164mpfe)", "Der Gesamtschaden, den man in allen K\195\164mpfen erhalten hat." },
	{ "PanelEntry40", "Schaden verursacht (Alle K\195\164mpfe)", "Der Gesamtschaden, den man in allen K\195\164mpfen verursacht hat." },
	{ "PanelEntry41", "DPS (Alle K\195\164mpfe)", "Schaden pro Sekunde (DPS) aller K\195\164mpfe." },
	{ "PanelEntry42", "DPS verursacht (Alle K\195\164mpfe)", "DPS verursacht f\195\188r 'Alle K\195\164mpfe'." },
	{ "PanelEntry45", "Gesamt", "Der Gesamtschaden, bzw. die Gesamtheilung der durch diesen Effekt verursacht wurde." },
	{ "PanelEntry46", "Anzahl der Treffer", "Die Anzahl der Treffer, bei denen dieser Effekt - ohne kritische Treffer, ber\195\188hrende oder schmetternde Schl\195\164ge  - erfolgreich war." },
	{ "PanelEntry47", "Anzahl der Krits", "Die Anzahl der kritischen Treffer, bei denen dieser Effekt erfolgreich war." },
	{ "PanelEntry48", "Durchschnitt der nicht-kritischen Treffer", "Der durchschnittliche nicht-kritische, nicht-ber\195\188hrende, nicht-schmetternde Schaden oder Heilung, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry49", "Durchschnitt der kritischen Treffer", "Der durchschnittliche kritische Schaden, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry50", "Max Treffer", "Der h\195\182chste nicht-kritische, nicht-ber\195\188hrende, nicht-schmetternde Schaden oder Heilung, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry51", "Max Krit", "Der h\195\182chste kritische Treffer, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry52", "Durchschnittliche Tick", "Der durchschnittliche Schaden oder die durchschnittliche Heilung, den dieser Effekt per Tick verursacht hat." },
	{ "PanelEntry53", "Max Tick", "Dies zeigt den maximalen Schaden oder die maximale Heilung an, die diese Effekt pro Tick verursacht hat." },
	{ "PanelEntry54", "Element", "Das Element (Arkan, Feuer, etc.) f\195\188r diesen Effekt." },
	{ "PanelEntry55", "Erhaltener Schaden - verfehlt", "Dies ist die Anzahl der Verfehlungen des Gegners diesem Char gegen\195\188ber." },
	{ "PanelEntry56", "Erhaltener Schaden - ausgewichen", "Dies ist die Anzahl, wievielen Attacken von diesem Char ausgewichen wurden." },
	{ "PanelEntry57", "Erhaltener Schaden - parriert", "Dies ist die Anzahl, wieviele Attacken von diesem Char parriert wurden." },
	{ "PanelEntry58", "Erhaltener Schaden - geblockt", "Dies ist die Anzahl, wieviele Attacken von diesem Char geblockt wurden." },
	{ "PanelEntry59", "Erhaltener Schaden - absorbiert", "Dies ist die Anzahl, wieviele Attacken von diesem Char absorbiert wurden." },
	{ "PanelEntry60", "Erhaltener Schaden - entkommen", "Dies ist die Anzahl, wievielen Attacken von diesem Char entkommen wurden." },
	{ "PanelEntry61", "Erhaltener Schaden - abgelenkt", "Dies ist die Anzahl, wieviele Attacken von diesem Char abgelenkt wurden." },
	{ "PanelEntry62", "Erhaltener Schaden - widerstanden", "Dies ist die Anzahl, wievielen Attacken von diesem Char widerstanden wurden." },
	{ "PanelEntry63", "Erhaltener Schaden - reflektiert", "Dies ist die Anzahl, wieviele Attacken von diesem Char reflektiert wurden." },
	{ "PanelEntry64", "Erhaltener Schaden - immun", "Dies ist die Anzahl, gegen\195\188ber wievielen Attacken dieser Char immun warst." },
	{ "PanelEntry65", "Krit Rate", "Die relative Anzahl der versuchten kritischen Treffer pro Schlag." },
	{ "PanelEntry66", "Anzahl der Ticks", "Dies ist die Anzahl der Ticks, die vergehen, wenn jemand Schaden oder Heilung durch diesen Effekt erh\195\164lt." },
	{ "PanelEntry67", "Verfehlungsrate (total)", "Dies ist der relative Betrag der Verfehlungen pro Treffer. Hier sind alle unten aufgef\195\188hrten Verfehlungen ber\195\188ksichtigt, also parriert, geblockt, etc." },
	{ "PanelEntry68", "Total Casts", "The total number of casts or swings attempted for this attack.  This number includes the misses." },
	{ "PanelEntry70", "Verursachter Schaden - verfehlt", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und ihr Ziel verfehlten." },
	{ "PanelEntry71", "Verursachter Schaden - ausgewichen", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und denen ausgewichen wurde." },
	{ "PanelEntry72", "Verursachter Schaden - parriert", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und die vom Ziel parriert wurden." },
	{ "PanelEntry73", "Verursachter Schaden - geblockt", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und die vom Ziel geblockt wurden." },
	{ "PanelEntry74", "Verursachter Schaden - absorbiert", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und die vom Ziel absorbiert wurden." },
	{ "PanelEntry75", "Verursachter Schaden - entkommen", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und denen entkommen wurde." },
	{ "PanelEntry76", "Verursachter Schaden - abgelenkt", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und die vom Ziel abgelenkt wurden." },
	{ "PanelEntry77", "Verursachter Schaden - widerstanden", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und die vom Ziel widerstanden wurden." },
	{ "PanelEntry78", "Verursachter Schaden - reflektiert", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und die vom Ziel reflektiert wurden." },
	{ "PanelEntry79", "Verursachter Schaden - immun", "Dies ist die Anzahl der Attacken, die von diesem Char ausgingen und gegen die das Ziel immun war." },
	{ "PanelEntry80", "Zeit Schaden erhalten (Letzter Kampf)", "Dies ist die Zeitspanne, in der im letzten Kampf Schaden genommen wurde." },
	{ "PanelEntry81", "Zeit Schaden erhalten (Alle K\195\164mpfe)", "Dies ist die Zeitspanne, in der in allen K\195\164mpfen Schaden genommen wurde." },
	{ "PanelEntry82", "Zeit Heilung verursacht (Letzter Kampf)", "Dies ist die Zeitspanne, in der im letzten Kampf Heilung verursacht wurde." },
	{ "PanelEntry83", "Zeit Heilung verursacht (Alle K\195\164mpfe)", "Dies ist die Zeitspanne, in der in allen K\195\164mpfen Heilung verursacht wurde." },
	{ "PanelEntry90", "Anzahl der schmetternden Schl\195\164ge", "Die Anzahl, wie oft dieser Effekt einen schmetternden Schlag verursachte." },
	{ "PanelEntry91", "Durchschnittlicher schmetternder Schlag", "Der durchschnittliche Schaden, den ein schmetternder Schlag dieses Effektes verursacht hat." },
	{ "PanelEntry92", "Max schmetternder Schlag", "Der maximale Schaden, den ein schmetternder Schlag dieses Effektes verursacht hat." },
	{ "PanelEntry93", "Schmetternder Schlag Rate", "Die relative Anzahl der versuchten schmetternden Schl\195\164ge pro Treffer." },
	{ "PanelEntry94", "Attribut", "Das Attribut bzgl. Erhalt oder Verlust dieses Effektes." },
	{ "PanelEntry95", "Gesamt", "Der Gesamtbetrag bzgl. Erhalt oder Verlust dieses Effektes.  Bei einem Debuff oder Buff der stapelbar ist, ist dies die Angabe, wie oft dieser Effekt insgesamt gestapelt wurde." },
	{ "PanelEntry96", "Treffer", "Die Anzahl, wie oft dieser Effekt aufgetreten ist." },
	{ "PanelEntry97", "Durchschnitt", "Der durchschnittliche Erhalt oder Verlust dieses Effektes. Bei einem Debuff oder Buff, der stapelbar ist, ist dies die durchschnittlich erreichte H\195\182he." },
	{ "PanelEntry98", "Maximum", "Der maximale Erhalt oder Verlust dieses Effektes. Bei einem Debuff oder Buff, der stapelbar ist, ist dies die maximal erreichte H\195\182he." },
	{ "PanelEntry99", "Dispels", "Die Anzahl, wie oft dieser Effekt beseitigt wurde." },
	{ "PanelEntry100", "Intervall Z\195\164hlung", "Die Anzahl der Zeitintervalle, die zwischen dem Auftreten des Effektes vergangen sind." },
	{ "PanelEntry101", "Gesch\195\164tzter Intervalldurchschnitt", "Der gesch\195\164tzte Intervalldurchschnitt (in Sekunden) der zwischen dem Auftreten des Effektes vergangen sind. Das ist nur eine Sch\195\164tzung.\n\nAnmerkung: In dem Versuch, keine fehlerhaften Daten mit einzubeziehen, wird Recap alle Intervalle \195\188ber 130 Sekunden ignorieren." },
	{ "PanelEntry102", "Verfehlungen", "Die Anzahl, wie oft dieser Effekt, aus welchem Grund auch immer, fehlschlug. Recap protokolliert momentan den Grund nicht mit." },
	{ "PanelEntry103", "Dauer Z\195\164hlung", "Die Anzahl, wie oft die Dauer f\195\188r diesen Effekt mitgez\195\164hlt wurde." },
	{ "PanelEntry104", "Gesch\195\164tzte Durchschnittsdauer", "Die gesch\195\164tzte Durchschnittsdauer (in Sekunden) f\195\188r diesen Effekt. Das ist nur eine Sch\195\164tzung.\n\nAnmerkung: In dem Versuch, keine fehlerhaften Daten mit einzubeziehen, wird Recap jegliche Dauer \195\188ber 130 Sekunden ignorieren." },
	-- Note: the white in the following tooltip is deliberately exaggerated for contrast
	{ "PanelEntry105", "Sonstiger Effekt", "Wird dieser Effekt in gr\195\188n dargestellt, ist es ein Spruch; wird er in rot dargestellt, ist es ein Debuff oder ein Verlust; wird er in blau dargestellt, ist es ein Buff oder ein Erhalt; ist er in weiss dargestellt, kann es ein Debuff oder ein Buff sein. Recap kann dies dann nicht genauer ermitteln." },
	{ "PanelEntry106", "Anzahl der Ber\195\188hrungen", "Anzahl, wie oft dieser Effekt einen ber\195\188hrenden Schlag verursachte." },
	{ "PanelEntry107", "Durchschnitt Ber\195\188hrung", "Der durchschnittliche Schaden des Effektes 'Ber\195\188hrender Schlag'." },
	{ "PanelEntry108", "Max Ber\195\188hrung", "Der maximale Schaden des Effektes 'Ber\195\188hrender Schlag'." },
	{ "PanelEntry109", "Ber\195\188hrungsrate", "Die relative Anzahl ber\195\188hrender Schl\195\164ge pro Schlagversuche." },
	{ "PanelEntry110", "Partiell absorbiert", "Die Anzahl der partiellen Absorbierungen (beinhaltet keine kompletten Absorbierungen)." },
	{ "PanelEntry111", "Partiell absorbiert Durchschnitt", "Die durchschnittliche Anzahl des partiell absorbierten Schadens (beinhaltet keine kompletten Absorbierungen)." },
	{ "PanelEntry112", "Partiell geblockt", "Die Anzahl der partiell geblockten Schl\195\164ge (beinhaltet keine komplett geblockten Schl\195\164ge)." },
	{ "PanelEntry113", "Partiell geblockt Durchschnitt", "Die durchschnittliche Anzahl des partiell geblockten Schadens (beinhaltet keine komplett geblockten Schl\195\164ge)." },
	{ "PanelEntry114", "Partiell widerstanden", "Die Anzahl, wie oft Schaden partiell widerstanden wurde (beinhaltet keinen komplett widerstandenen Schaden)." },
	{ "PanelEntry115", "Partiell widerstanden Durchschnitt", "Die durchschnittliche Anzahl, wie oft Schaden partiell widerstanden wurde (beinhaltet keinen komplett widerstandenen Schaden)." },
	{ "PanelEntry116", "Partial Resists Percentage", "The average percentage resisted by partial resists (does not include complete resists)." },
	{ "PanelEntry117", "Tick Crit Rate", "The relative amount of crits per ticks." },
	{ "place_holder_118", "", "" },
	{ "place_holder_119", "", "" },
	{ "PanelEntry120", "Gestohlen", "Die Anzahl, die dieser Effekt gestohlen wurde." },
	{ "PanelEntry122", "Min Ber\195\188hrung", "Der minimale ber\195\188hrende Schaden bzw. Heilung, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry123", "Min Treffer", "Der minimale nicht-kritische, nicht-ber\195\188hrende, nicht-schmetternde Schaden bzw. Heilung, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry124", "Min Krit", "Der minimale kritische Schaden bzw.  Heilung, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry125", "Min Schmett", "Der minimale schmetternde Schaden bzw. Heilung, den dieser Effekt w\195\164hrend einer Attacke verursacht hat." },
	{ "PanelEntry126", "Min Tick", "Der minimale Schaden bzw. Heilung, den dieser Effekt pro Tick verursacht hat." },
	{ "PanelEntry127", "Partiell absorbiert Gesamt", "Der Gesamtbetrag des partiell absorbierten Schadens (beinhaltet keine kompletten Absorbierungen)." },
	{ "PanelEntry128", "Partiell geblockt Gesamt", "Der Gesamtbetrag des partiell geblockten Schadens (beinhaltet keine komplett geblockten Schl\195\164ge)." },
	{ "PanelEntry129", "Partiell widerstanden Gesamt", "Der Gesamtbetrag, wie oft Schaden partiell widerstanden wurde (beinhaltet keinen komplett widerstandenen Schaden)." },
	{ "place_holder_130", "", "" },
	{ "place_holder_131", "", "" },
	{ "PanelEntry133", "Gesch\195\164tzt widerstanden gesamt", "Dies ist ein Sch\195\164tzwert, der den gesamten widerstandenen Schaden anzeigt. Dieser beinhaltet sowohl komplett widerstandenen, als auch nur teilweise widerstandenen Schaden. Dies ist nur eine Sch\195\164tzung.\n\nDie Prozentangabe kann als Sch\195\164tzung der Effektivität bzgl des Widerstands verstanden werden." },
	{ "PanelEntry134", "Spell ID", "This is the spell ID for this effect." },
	{ "PanelEntryOverheal", "\195\156berheilung", "Dies ist ein gesch\195\164tzter Wert der hp, die auf den Charakter angewandt wurden, aber ihn nicht heilten. Beispiel: Ein Krieger hat 4750/5000 Lebenspunkte, und erf\195\164hrt eine Heilung von 1000 Punkten. Dies bringt ihn wieder auf 5000 Lebenspunkte. 750 hp wurden jedoch \195\188berheilt:  1000hp Heilung minus 250hp." },
	{ "OpenLog", "Log \195\182ffne", "\195\150ffnet die Datei 'WoWChatLog.txt'." },
	{ "ReportToLog", "Bericht im Log speichern", "Dies speichert aktuelle Informationen \195\188ber die K\195\164mpfer und die pers\195\182nlichen Details des Spielers in eine Datei namens 'WoWChatLog.txt'.\n- Es gibt ein paar Einschr\195\164nkungen, f\195\188r die das Spiel verantwortlich ist:\n- Das Ergebnis ist erst nachdem das Spiel beendet wurde, verf\195\188gbar. Auch durch ein UIReload ist das nicht ausl\195\182sbar.\n- Du kannst dies mehrmals durchf\195\188hren und die Informationen werden jedesmal hintenangef\195\188gt.\n\nBei langen Listen z.B. bei Raids, benutze bitte stattdessen 'Bericht in die Zwischenablage'." },
	{ "CloseLog", "Log schliessen", "Schliesst die Datei 'WoWChatLog.txt'." },
	{ "UseOneSettings", "Nutze globale Einstellungen", "Standardm\195\164ssig werden die Einstellungen und K\195\164mpfer f\195\188r jeden deiner Chars gespeichert.  Wenn hier ein H\195\164kchen steht, werden alle deine Einstellungen gespeichert und gelten f\195\188r alle Chars zusammen.\n\nBeachte: Einstellungen und K\195\164mpfer, die momentan bei anderen Chars gespeichert sind, werden damit gel\195\182scht.\n\nDiese Option hat keinen Effekt auf die 'pers\195\182nlichen Details'. Diese sind immer char-spezifisch.\n\nSwitching to or from global settings will trigger a reload of your UI." },
	{ "MenuAdd", "Zu Gruppe hinzuf\195\188gen", "F\195\188gt diesen K\195\164mpfer zu der Gruppenliste hinzu." },
	{ "MenuDrop", "Aus Gruppe entfernen", "Entfernt diesen K\195\164mpfer aus der Gruppenliste." },
	{ "MenuReset", "Reset K\195\164mpfer", "Setze diesen K\195\164mpfer zur\195\188ck. Dies wird in jeder Kampfansicht die protokollierten Daten dieses K\195\164mpfers r\195\164umen." },
	{ "MenuIgnore", "Ignoriere K\195\164mpfer", "Entferne diesen K\195\164mpfer aus deiner Liste der befreundeten K\195\164mpfer und ignoriere ihn bis zum n\195\164chsten Reset." },
	{ "MenuLock", "Lock Combatant", "Lock this combatant and their pets.  While locked, they will not be removed when you reset all other combatants." },
	{ "RecapAnchorTopLeft", "Verankere oben links", "Verankere den Dialog, so dass er nach links oben erweitert wird." },
	{ "RecapAnchorTopRight", "Verankere oben rechts", "Verankere den Dialog, so dass er nach rechts oben erweitert wird." },
	{ "RecapAnchorBottomLeft", "Verankere unten links", "Verankere den Dialog, so dass er nach links unten erweitert wird." },
	{ "RecapAnchorBottomRight", "Verankere unten rechts", "Verankere den Dialog, so dass er nach rechts unten erweitert wird." },
	{ "Total", "Effekte", "Dies ist der Gesamtschaden bzw. die Gesamtheilung, den dieser Effekt seit dem letzten Reset verursacht hat." },
	{ "TotalDmg", "Dmg Effects", "This is the total damage this effect accumulated since last reset." },
	{ "TotalHeal", "Heal Effects", "This is the total healing (actual, which is raw healing minus overhealing) this effect accumulated since last reset." },
	{ "Max", "Max Treffer", "Dies ist der h\195\182chste Wert, den dieser Effekt seit dem letzten Reset an Schaden oder Heilung w\195\164hrend einer Attacke verursacht hat." },
	{ "Avg", "Durchschnittliche Treffer", "Dies ist der durchschnittliche Wert, den dieser Effekt seit dem letzten Reset an Schaden oder Heilung w\195\164hrend einer Attacke verursacht hat." },
	{ "CritP", "Krit Rate", "Dies ist die durchschnittliche kritische Trefferrate, den dieser Effekt seit dem letzten Reset verursacht hat." },
	{ "MissPOverP", "Verfehlen-Rate/\195\156berheilung-Rate", "F\195\188r Schadenseffekte gibt dies die Verfehlen-Rate an. F\195\188r Heilungseffekte gibt dies die \195\156berheil-Rate an." },
	{ "TotalPS", "Damage or Healing per second", "For damage, this is DPS.  For healing, this is HPS." },
	{ "TotalPSDmg", "Damage per second", "Damage per second (DPS)." },
	{ "TotalPSHeal", "Healing per second", "Healing per second (HPS)." },
	{ "Contribution", "Beitrag", "Dies ist die relative Anzahl, welche dieser Effekt zum Schaden bzw. zur Heilung eines K\195\164mpfers beigetragen hat." },
	{ "OtherHits", "Treffer", "Die Anzahl, wie oft dieser Effekt aufgetreten ist." },
	{ "OtherTotal", "Gesamt", "Der Gesamtbetrag bzgl. Erhalt oder Verlust dieses Effektes. F\195\188r manche Effekte ist diese Zahl die gleiche, wie die Anzahl der Treffer." },
	{ "Attribute", "Attribut", "Das Attribut bzgl. Erhalt oder Verlust dieses Effektes." },
	{ "HeaderDPSvsAll", "DPS vs Alle", "Dies ist der Schaden pro Sekunde (DPS), den jeder K\195\164mpfer verursacht hat, bezogen auf die Gesamtdauer jedes K\195\164mpfenden." },
	{ "HeaderOver", "\195\156berheilung", "Dies ist ein gesch\195\164tzter Prozentwert an \195\156berheilung f\195\188r jeden befreundeten K\195\164mpfer. (F\195\188r alle K\195\164mpfe).\n\nBeachte: Mana-effiziente Heiler nutzen die langsamen kr\195\164ftigen Heilungen.  Paladins und andere Heiler, die w\195\164hrend es Kampfes durch kleine schnelle Heilungen helfen, verf\195\164lschen oft das Bild der Mana-effizienten Heiler.\n\nNutze dies nicht als Massstab der F\195\164higkeit des Heilers." },
	{ "ReportFightsToClipboard", "Kampf-Bericht in die Zwischenablage", "Dies kopiert die Informationen der aktuellen K\195\164mpfer in die Zwischenablage. Von dort aus kannst du sie dann in zb Notepad einf\195\188gen." },
	{ "ReportDetailsToClipboard", "Details-Bericht in die Zwischenablage", "Dies kopiert die pers\195\182nlichen Details des Spielers in die Zwischenablage. Von dort aus kannst du sie dann in zb Notepad einf\195\188gen." },
	{ "ShowSelfView", "Zeige pers\195\182nliche Details", "Dies zeigt deine Schaden- und Heilung-Details im Hauptdialog an." },
	{ "HideSelfView", "Verstecke pers\195\182nliche Details", "Dies wechselt von deinen pers\195\182nlichen Details in die \195\156bersicht \195\188ber alle K\195\164mpfer." },
	{ "ResetSelfView", "Setze pers\195\182nliche Details zur\195\188ck", "Dies l\195\182scht alle pers\195\182nlichen Schadens-und Heilungs-Details. Deine Informationen in der Detail-Konsole sind davon nicht betroffen." },
	{ "ResetEffect", "Reset Effekte", "Dies setzt diesen Effekt zur\195\188ck. (Nur bei den pers\195\182nliche Details)." },
	{ "HeaderEName", "Spruch oder F\195\164higkeit", "Dies sind die Effekte, die du seit deinem letzten Reset benutzt hast. Schadenseffekte sind gr\195\188n, Heileffekte blau dargestellt." },
	{ "HeaderEElement", "Effect (Element)", "Dies ist das Element (Arkan, Feuer, etc.) des Effekts." },
	{ "HeaderETotal", "Effekt Gesamt", "Dies ist die Gesamtzahl, die jeder Effekt an Schaden bzw. Heilung seit dem letzten Reset verursacht hat." },
	{ "HeaderETotalP", "Effekt (prozentualer Anteil)", "Dies ist der Beitrag, den jeder Effekt seit dem letzten Reset zum Gesamtergebnis von Schaden bzw, Heilung beigetragen hat." },
	{ "HeaderEMaxAll", "Max Schaden bzw. Heilung", "Dies ist der maximale Schaden, bzw. die maximale Heilung, die dieser Effekt bei einem Treffer, Tick oder Crit verursacht hat." },
	{ "HeaderEGlances", "Anzahl der ber\195\188hrenden Treffer", "Dies ist die Anzahl, wie oft jeder Effekt einen ber\195\188hrende Treffer verursachte." },
	{ "HeaderEGlancesAvg", "Durchschnittliche ber\195\188hrende Treffer", "Dies ist der durchschnittliche Schaden pro ber\195\188hrendem Treffer." },
	{ "HeaderEGlancesMax", "Max ber\195\188hrende Treffer", "Dies ist der maximale Schaden eines einzigen ber\195\188hrenden Treffers." },
	{ "HeaderEHits", "Anzahl der Treffer", "Dies ist die Anzahl der nicht-kritischen nicht-ber\195\188hrende Treffer, die jeder Effekt verursacht hat." },
	{ "HeaderEHitsAvg", "Durchschnittliche Treffer", "Dies ist die durchschnittliche Anzahl der nicht-kritischen, nicht-ber\195\188hrende Treffer, die jeder Effekt verursacht hat." },
	{ "HeaderEHitsMax", "Max Treffer", "Dies ist der maximale Schaden bzw. die maximale Heilung w\195\164hrend eines einzigen nicht-kritischen, nicht-ber\195\188hrende Treffers jeden Effektes." },
	{ "HeaderETicks", "Anzahl der Ticks", "Dies ist die Anzahl der Ticks, die w\195\164hrend eines Schadens bzw. einer Heilung vergehen. Dies ist nur bei den Effekten, die Schaden bzw. Heilung \195\188ber eine Zeitspanne verursachen (Damage Over Time) der Fall." },
	{ "HeaderETicksAvg", "Durchschnittliche Ticks", "Dies ist der durchschnittliche Schaden bzw. die durchschnittliche Heilung pro Tick bei jedem Effekt." },
	{ "HeaderETicksMax", "Max Ticks", "Dies ist der maximale Schaden bzw. die maximale Heilung, eines einzigen Ticks, bei jedem Effekt." },
	{ "HeaderECrits", "Anzahl der Krits", "Dies ist die Anzahl der kritischen Treffer, die der jeweilige Effekt verursachte." },
	{ "HeaderECritsAvg", "Durchschnittliche Krits", "Dies ist der durchschnittliche Schaden bzw. die durchschnittliche Heilung pro kritischem Treffer, die der jeweilige Effekt verursachte." },
	{ "HeaderECritsMax", "Max Krits", "Dies ist der h\195\182chste Schaden bzw. die h\195\182chste Heilung eines kritischen Treffers, die der jeweilige Effekt verursachte." },
	{ "HeaderECritsP", "Krit Rate", "Dies ist die prozentuale kritische-Trefferrate des jeweiligen Effektes basierend auf den versuchten Treffern." },
	{ "HeaderEMiss", "Verfehlungen", "Dies ist die Anzahl an Verfehlungen des jeweiligen Effektes.\n\nEs beinhaltet: Verfehlen, Widerstehen und Absorbieren bei Fernkampf und Ausweichen, Parieren und Blocken bei Nahkampf." },
	{ "HeaderEMissP", "Verfehlungsrate", "Dies ist die prozentuale Anzahl an versuchten Treffern des jeweiligen Effektes, die das Ziel verfehlten." },
	{ "HeaderEGlancesMin", "Min ber\195\188hrende Treffer", "Dies ist der minimale Schaden eines einzigen ber\195\188hrenden Treffers." },
	{ "HeaderEHitsMin", "Min Treffer", "Dies ist der (theoretische) minimale Schaden bzw. Heilung eines einzigen nicht-kritischen Treffers eines jeden Effektes." },
	{ "HeaderETicksMin", "Min Tick", "Dies ist der (theoretische) minimale Schaden bzw. Heilung eines einzigen Ticks eines jeden Effektes." },
	{ "HeaderECritsMin", "Min Krit", "Dies ist der (theoretische) minimale Schaden bzw. Heilung eines einzigen kritischen Treffers eines jeden Effektes." },
	{ "StartSync", "Synchronisation starten", "Dieser Button wird eine Synchronisations-Einladung an alle Gruppenmitglieder schicken. Du giltst dann als Leiter der Synchronisation. Sobald Du dies tust, verl\195\164sst Du die momentan laufende Synchronisation und Recap wird 'Alle K\195\164mpfe' r\195\164umen. Du erh\195\164lst die Benachrichtigung, ob der jeweilige Spieler Deine Einladung akzeptiert oder abgelehnt hat.\n\nJeder in einer Gruppe kann eine Synchronisation starten." },
	{ "ManualSync", "Manuelle Synchronisation", "Dieser Button synchronisiert sofort. Normalerweise synchronisiert Recap seine Daten am Ende eines Kampfes, aber wenn Du es manuell erledigen willst, ist es durch diesen Button m\195\182glich.\n\nDies funktioniert nicht, wenn Recap im Kampf ist.\n\nIn addition, causes all members of the synchronization to send their own summary data, which will result in every member having all combatants." },
	{ "BecomeLeader", "Leiter werden", "Durch diesen Button wirst Du der Leiter der Synchronisation. Man kann so, einen fehlenden Leiter ersetzen (der vielleicht gerade aus der Gruppe ging). Dies f\195\188hrt eine manuelle Synchronisation durch und \195\188bermittelt den neuen Leiter.\n\nDies funktioniert nicht, wenn Recap im Kampf ist." },
	{ "ListMembers", "Zeige Mitglieder", "Dieser Button gibt alle Mitglieder der Synchronisation in der Konsole aus. Diejenigen, die als aktiv eingestuft sind, werden zuerst aufgelistet, gefolgt von denen, die den Status inaktiv haben. (Inaktiv bedeutet, dass von diesen Mitgliedern innerhalb der letzten zehn Sekunden keine Nachricht erhalten wurde)." },
	{ "ClearInactiveMembers", "L\195\182sche inaktive Mitglieder", "L\195\182sche die Mitglieder von denen in den letzten zehn Sekunden keine Nachricht mehr erhalten wurde. Werden sie von der Liste gel\195\182scht, heisst das nicht, dass sie aus der Synchronisation ausgeschlossen werden. Werden sie wieder aktiv, werden sie auch wieder in der Liste angezeigt.  Werden sie von der Liste gel\195\182scht, so werden sie nur aus Deiner, nicht aber aus der Liste der anderen Spieler entfernt." },
	{ "SkipNextFight", "Skip Next Fight", "This button will skip the next fight.  Recap will automatically resume tracking following the end of the next fight.\n\nEnabled for the leader of the synchronization.\n\nIf pressed during combat, only the remainder of the current fight will be skipped.\n\nThis button could be used, for example, to skip the chess event in Karazhan.\n\nThe button is also enabled for people who are not in a synchronization." },
	{ "TargetTotal", "Dem Ziel zugef\195\188gt", "Dies ist der Schaden bzw. die Heilung, die diesem Ziel seit dem letzten Reset zugef\195\188gt wurde." },
	{ "SourceTotal", "Von Quelle erhalten", "Dies ist der Schaden bzw. die Heilung, die von dieser Quelle seit dem letzten Reset erhalten wurde." },
	{ "ContributionWhom", "Beitrag", "Dies ist der relative Betrag an Schaden bzw. Heilung, der dem Ziel zugef\195\188gt bzw. von der Quelle erhalten wurde." },
	{ "RecentIncomingEvents", "Neuste erhaltene Ereignisse", "Dies sind neuste Ereignisse, die diesem K\195\164mpfer widerfahren sind. Eventuell nach Effekten gefiltert." },
	{ "RecentOutgoingEvents", "Neuste verursachte Ereignisse", "Dies sind neuste Ereignisse, die  von diesem K\195\164mpfer verursacht wurden.  Eventuell nach Effekten gefiltert." },
	{ "ShowRecent", "Zeige neuste Ereignisse", "Requires Recent Data Mode.\n\nZeigt ein Dialog mit den neusten erhaltenen und verursachten Ereignissen an f\195\188r einen K\195\164mpfer, oder f\195\188r ein Spruch bzw. eine F\195\164higkeit eines K\195\164mpfers.\n\nDies kann aktiviert oder deaktiviert werden, in dem man den Datenmodus 'Neueste' unter Optionen / Einstellungen nutzt." },
	{ "ShowRecentEffect", "Zeige neuste Ereignisse", "Requires Recent Data Mode.\n\nZeigt ein Dialog mit den neusten erhaltenen und verursachten Ereignissen an f\195\188r einen K\195\164mpfer, oder f\195\188r ein Spruch bzw. eine F\195\164higkeit eines K\195\164mpfers.\n\nDies kann aktiviert oder deaktiviert werden, in dem man den Datenmodus 'Neueste' unter Optionen / Einstellungen nutzt." },
	{ "ShowGroupTotal", "Zeige Gruppe Gesamt", "Zeige einen Dialog aller gesamten Details der K\195\164mpfer in der Gruppe." },
	{ "ShowNonGroupTotal", "Zeige Nicht-Gruppe Gesamt", "Zeige einen Dialog aller gesamten Details der K\195\164mpfer nicht in der Gruppe." },
	{ "IgnoreEdit", "Effect to Ignore", "Enter a new effect to add to the ignore list by typing the spell ID here; or select an effect listed above for removal.\n\nTo add a new effect you need to know its spell ID.\n\nIgnored effects will no longer count towards damage or healing, but will still show up in other contexts.\n\nIgnoring an effect does not remove existing data for the effect.\n\nNote that the list of effects to ignore is shared among all characters." },
	{ "AddIgnore", "Add Effect to Ignores", "Add this effect to the list of effects to ignore." },
	{ "RemoveIgnore", "Remove Effect from Ignores", "Remove this effect from the list of effects to ignore." },
	{ "AddSuggestedIgnores", "Add Suggested Effects to Ignores", "Add to this list all of the Recap recommended effects to ignore.  At the moment these are effects which causes a player to heal a boss, thus distorting numbers in the Heal column.  If you don't use the Heal column, then don't bother." },
	{ "CloseLoad", "Close Loaded Data Set Panel", "Close the panel.  To view the panel again, load the same Data Set, or a new Data Set, from the Options / Data Sets tab." },
	{ "Name", "Combatants", "This is a list of all combatants that did damage, took damage, or healed in this fight or set of fights." },
	{ "LoadName", "Combatants", "This is a list of all combatants that did damage, took damage, or healed in this loaded Data Set." },
	{ "StartingHints", "Getting started:\n\nEasy:   Check out the tooltips\nMedium:   See Recap_Quick_Start.rtf in the Recap\\Docs folder\nAdvanced:   Study readme_FAQ.txt in the Recap\\Docs folder", "|cFF9090FF\nTo post Recap information to others:\n\n•• Open almost any chat edit box (for example '/p', '/g', or '/w Hawksy'), and leave it open.\n\n•• Then shift+click on almost anything in Recap that highlights in light yellow when you mouse over it.  The Recap information will be posted to that chat.\n\n•• To post to your own console, shift+click without having a chat edit box open.\n\n•• To post directly to the Recap clipboard (for export), hold down the control key as well, that is, use control+shift+click." },
	{ "CopyGlobalSettingsToCharacter", "Copy Global Settings to this Character", "The global settings will be copied and used in future for this character.\n\nIf Use Global Settings is off, your UI will be reloaded." },
	{ "RecentEvents", "Report All Recent Events", "Requires Recent Data Mode.\n\nIf the Recent Data Mode is enabled, clicking this button will bring up a panel with all recent events (damage, healing, dispels, interrupts, and deaths)." },
	{ "RecentDispelsAndInterrupts", "Report Recent Dispels and Interrupts", "Requires Recent Data Mode.\n\nIf the Recent Data Mode is enabled, clicking this button will bring up a panel with all recent dispels and interrupts." },
	{ "RecentDeaths", "Report Recent Deaths", "Requires Recent Data Mode.\n\nIf the Recent Data Mode is enabled, clicking this button will post the last sources of damage received before death for group combatants who have died within the last few fights." },
	{ "PreviousEOF", "Previous End of Fight", "Position recent events to the previous end of fight, showing all events." },
	{ "NextEOF", "Next End of Fight", "Position recent events to the next end of fight, showing all events." },
	{ "CloseClipboard", "Close Clipboard", "Close this clipboard panel." },
	{ "ShowRecap", "Show Recap", "Show the Recap main panel." },
	{ "ForceShowRecap", "Force Show Recap", "For emergency use if you can't find the Recap main panel anywhere.\n\nShow the Recap main panel; all Recap panels are centred; the Recap scale is reset to 1.0; and Recap is resumed if it was paused." },
	{ "ShowRecapOptions", "Show Recap Options", "Show the Recap Options panel." },
	{ "LiveGraphAndText", "Show Live Graph & Text", "Requires Live Data Mode.\n\nIf the Live Data Mode is enabled, clicking this button will bring up a panel with a graph of live outgoing DPS, incoming DPS, or outgoing HPS for group combatants for the current fight.\n\nThe panel can also show live text listings for the same information." },
	{ "CloseGraph", "Close Live Graph & Text", "Close this live graph and text listing panel.\n\nOnce closed, the panel will open again automatically at the beginning of the next fight involving group combatants.\n\nThere is a button at the bottom of the main Fights panel for opening or re-opening the Live Graph & Text panel manually.\n\nIf you want the panel to go away permanently, turn off the Live Data Mode option on the Options / Setting tab." },
	{ "GraphCheckbox", "Show or Hide this Combatant", "When checked, this combatant will be shown in the live graphs and live text listings." },
	{ "GraphCombatant", "Add or Remove Featuring for this Combatant", "Clicking a checked combatant will highlight the combatant by dimming other combatant live graph and live text entries.  Clicking a second time will remove the dimming.\n\nMore than one combatant can be highlighted at a time." },
	{ "ShowDPSOut", "Show DPS Out for Live Graph & Text", "Clicking on this button will set the live graph and the live text to show outgoing DPS for group combatants." },
	{ "ShowDPSIn", "Show DPS In for Live Graph & Text", "Clicking on this button will set the live graph and the live text to show incoming DPS for group combatants." },
	{ "ShowHPSOut", "Show HPS Out for Live Graph & Text", "Clicking on this button will set the live graph and the live text to show outgoing HPS for group combatants." },
	{ "CheckAll", "Check All Combatants", "Clicking on this button will mark all checkboxes to show all group combatants on the live graph and the live text listing (for whichever of outgoing DPS, incoming DPS, or outgoing HPS is currently selected).\n\nWARNING: If you are looking at a graph, selecting all 25 combatants in a raid will approximately double the amount of addon CPU time used by Recap.  There is much less of an increase if you are only looking at a text listing.\n\nWhen looking at graphs, select only the combatants that you need to be watching (unless you have a top end computer)." },
	{ "UncheckAll", "Uncheck All Combatants", "Clicking on this button will clear all checkboxes to hide all group combatants on the live graph and the live text (for whichever of outgoing DPS, incoming DPS, or outgoing HPS is currently selected)." },
	{ "ShowLiveGraph", "Show Live Graph", "Clicking on this button will switch to the live graph view.  You will see live graph traces for group combatants." },
	{ "ShowLiveText", "Show Live Text", "Clicking on this button will switch to the live text view.  You will see live text entries for group combatants." },
	{ "ShowGraphOptions", "Show Combatant Options", "Clicking on this button will show a panel with combatant options for the live graph and live text displays.\n\nYou can choose which combatants to display per graph & text type; and highlight one or more combatants by dimming all other combatants.\n\nGroup combatants appear in descending order of total damage dealt, damage received, or healing done (taken from the All Fights panel), so the order may change for subsequent fights.  If there are no total numbers yet, combatants appear in alphabetical order." },
	{ "HideGraphOptions", "Hide Combatant Options", "Clicking on this button will hide the panel with combatant options for the live graph and live text displays." },
	{ "GraphHeadingName", "Combatant Name", "This is the name of the group combatant." },
	{ "GraphHeadingTotal", "Total Dmg Out, Dmg In, or Healing Out", "Total damage dealt, total damage received, or total healing done so far in this live fight for this combatant.\n\nGroup combatants appear in descending order of total damage dealt, damage received, or healing done (taken from the All Fights panel), so the order may change from fight to fight.  If there are no total numbers available yet, combatants appear in alphabetical order." },
	{ "GraphHeadingPeak", "Peak Dmg Out, Dmg In, or Healing Out", "Peak outgoing DPS, peak incoming DPS, or peak outgoing HPS so far in this live fight for this combatant.  These values are averages using a moving 6-second window." },
	{ "GraphHeadingAvg", "Average Dmg Out, Dmg In, or Healing Out", "Average effective outgoing DPS, average incoming DPS, or average effective outgoing HPS so far in this live fight for this combatant.\n\nThese values are the total amount divided by the overall fight time, and as a result will differ from the values shown in the Recap Fight panel." },
	{ "GraphOpaqueBackground", "Graph Opaque Background", "When checked, the Live Graph & Text panel has an opaque black background.\n\nThis option will always begin turned off when logging in or reloading the UI, for better visibility during combat." },
	{ "GraphPause", "Pause Data Collection for Live Graph & Text", "Click here to stop data collection for live graphs and text listings.  This is to allow you to continue to examine the current graphs and text listings.\n\nPausing and resuming live data collection does not affect other Recap functions.\n\nWarning: If you pause live data collection and if a new fight begins, you will not be collecting data for that new fight.  When you resume later, then the data that you collect, and the graphs and text listings that you then see, will have bits of the fight missing." },
	{ "GraphResume", "Resume Data Collection for Live Graph & Text", "The collection of data for live graphs and text listings is currently suspended.  Click here to resume data collection.\n\nPausing and resuming live data collection does not affect other Recap functions.\n\nNote that any fight involving the group will not be recorded while live data collection is paused, and those parts of the fight will not appear in subsequent live graphs and text listings." },
};


--[[ localized strings for the xml labels ]]

-- Bindings.xml (names generated in Bindings.xml)
BINDING_HEADER_RECAP = "Recap"
BINDING_NAME_RECAP_HIDE_SHOW = "Hide / Show"
BINDING_NAME_RECAP_PAUSE_RESUME = "Pause / Resume"
BINDING_NAME_RECAP_TOGGLE_FIGHTS = "Letzter/Alle K\195\164mpfe umschalten"
BINDING_NAME_RECAP_OPTIONS = "Recap Optionen"
BINDING_NAME_RECAP_RESET_ALL = "Alle K\195\164mpfe r\195\164umen"
BINDING_NAME_RECAP_RESET_LAST = "Letzten Kampf r\195\164umen"
BINDING_NAME_RECAP_RESET_DETAILS = "Pers\195\182nliche Details r\195\164umen"
BINDING_NAME_RECAP_RESET_FIGHTS_DETAILS = "Kampf und Details r\195\164umen"
BINDING_NAME_RECAP_SAVE_ALL_FIGHTS = "Speichere alle K\195\164mpfe"
BINDING_NAME_RECAP_SAVE_LAST_FIGHT = "Speichere letzten Kampf"
BINDING_NAME_RECAP_SKIP_NEXT_FIGHT = "Skip Next Fight"

-- Bindings.xml
RECAP_ALL_FIGHTS_RESET = "Alle K\195\164mpfe zur\195\188ckgesetzt"
RECAP_LAST_FIGHT_RESET = "Letzten Kampf zur\195\188ckgesetzt"
RECAP_DETAILS_RESET = "Pers\195\182nliche Details zur\195\188ckgesetzt"
RECAP_FIGHTS_DETAILS_RESET = "Kampf und Details zur\195\188ckgesetzt"
RECAP_SYNCHRONIZATION_RESET = "Sychronisation r\195\164umen"
RECAP_ALL_FIGHTS_SAVED = "Alle K\195\164mpfe gespeichert"

-- Recap.xml
RECAP_RECAP = "Recap"
RECAP_RESET = "R\195\164umen"
RECAP_EVENTS = "Events"
RECAP_DISPELS_AND_INTERRUPTS = "Dispels & Interrupts"
RECAP_COMBATANTS = "K\195\164mpfer"
RECAP_SEEN = "Gesehen"
RECAP_DIED = "Tode"
RECAP_TIME = "Zeit-T"
RECAP_TIME_IN = "Schaden-T"
RECAP_TIME_HEAL = "Heilung-T"
RECAP_HEAL = "Heilung"
RECAP_DMG_IN = "Erhalten"
RECAP_DMG_OUT = "Verursacht"
RECAP_MAX = "Max"
RECAP_HPS = "HPS"
RECAP_DPS_IN = "DPS In"
RECAP_DPS = "DPS"
RECAP_DPS_PER_GEAR = "DPS/Gear"
RECAP_DPS_ALL = "DPS+"
RECAP_MISS = "Verfehl"
RECAP_RECENT = "Neuste"
RECAP_RECENT_COLON = "Neuste:"
RECAP_TOTAL_DETAILS = "Total"

-- RecapOptions.xml : Display
RECAP_DATA_SET_NAME = "Name"
RECAP_SAVED = "Gespeichert"
RECAP_RECAP_OPTIONS = "Recap Optionen"
RECAP_DISPLAY = "Anzeige"
RECAP_SETTINGS = "Einstellungen"
RECAP_DATA_SETS = "Datensatz"
RECAP_REPORTS = "Berichte"
RECAP_OK = "Ok"
RECAP_DISPLAY_IN_LIST = "Anzeigen in der Liste"
RECAP_NUMBERED_LIST = "Nummerierte Liste"
RECAP_FACTION_LEVEL = "Level/Fraktion"
RECAP_CLASS = "Klasse"
RECAP_FIRST_SEEN = "Erstmals gesehen"
RECAP_DEATHS = "Tode"
RECAP_HEALS = "Heilung"
RECAP_HEALS_P = "Heilung %"
RECAP_DAMAGE_IN = "Schaden erhalten"
RECAP_DAMAGE_IN_P = "Schaden erhalten %"
RECAP_DAMAGE_OUT = "Schaden verursacht"
RECAP_DAMAGE_OUT_P = "Schaden verursacht %"
RECAP_HEALS_OUT = "Heals Out"
RECAP_MAX_HIT = "Max Treffer"
RECAP_DPS_VS_ALL = "DPS vs Gesamt"
RECAP_OVERHEALING = "\195\156berheilung"
RECAP_DISPLAY_MINIMIZED = "Anzeigen minimiert"
RECAP_STATUS_LIGHT = "Statusl\195\164mpchen"
RECAP_SYNC_LIGHT = "Sync L\195\164mpchen"
RECAP_LAST_ALL = "Letzter/Alle"
RECAP_YOUR_DPS = "Dein DPS"
RECAP_YOUR_PET_PERCENT = "Your Pet Percent"
RECAP_MIN_DPS_IN = "Gesamt DPS erhalten"
RECAP_MIN_DPS_OUT = "Gesamt DPS verursacht"
RECAP_YOUR_HPS = "Deine HPS"
RECAP_MIN_HPS = "HPS Gesamt"
RECAP_BUTTONS = "Buttons"
RECAP_BACKGROUND = "Hintergrund"
RECAP_MAXIMUM_ROWS = "Maximum Zeilen"
RECAP_SHOW_GAUGES = "Zeige Skala"
RECAP_ANCHOR = "Anker"
RECAP_DISPLAY_PERSONAL_DETAILS = "Personendetails"
RECAP_SELF_EELEMENT = "Element"
RECAP_SELF_ETOTAL = "Gesamt"
RECAP_SELF_ETOTALP = "Gesamt %"
RECAP_SELF_EGLANCES = "Ber\195\188hrungen"
RECAP_SELF_EGLANCESMIN = "Min Ber\195\188hrung"
RECAP_SELF_EGLANCESAVG = "Durch Ber\195\188hrung"
RECAP_SELF_EGLANCESMAX = "Max Ber\195\188hrung"
RECAP_SELF_EHITS = "Treffer"
RECAP_SELF_EHITSMIN = "Min Treffer"
RECAP_SELF_EHITSAVG = "Durch Treffer"
RECAP_SELF_EHITSMAX = "Max Treffer"
RECAP_SELF_ETICKS = "Ticks"
RECAP_SELF_ETICKSMIN = "Min Tick"
RECAP_SELF_ETICKSAVG = "Durch Ticks"
RECAP_SELF_ETICKSMAX = "Max Tick"
RECAP_SELF_ECRITS = "Krits"
RECAP_SELF_ECRITSMIN = "Min Krit"
RECAP_SELF_ECRITSAVG = "Durch Krits"
RECAP_SELF_ECRITSMAX = "Max Krit"
RECAP_SELF_ECRITSP = "Krit %"
RECAP_SELF_EMISS = "Verfehl"
RECAP_SELF_EMISSP = "Verfehl %"
RECAP_SELF_EMAXALL = "Max Schaden"
-- RecapOptions.xml : Settings
RECAP_WINDOW_OPTIONS = "Dialog Optionen"
RECAP_SHOW_TOOLTIPS = "Zeige Tooltips"
RECAP_SHOW_CLICK_HINTS = "Show Click Hints"
RECAP_TOOLTIPS_AT_POINTER = "Tooltips am Mauszeiger"
RECAP_SHOW_DETAILS = "Zeige Details"
RECAP_OPAQUE_BACKGROUND = "Undurchsichtiger Hintergrund"
RECAP_MINIMIZE_ON_ESCAPE = "Minimieren bei Escape"
RECAP_AUTO_HIDE_IN_COMBAT = "Bei Kampf ausblenden"
RECAP_AUTO_MINIMIZE = "autom. minimieren"
RECAP_AUTO_FADE_WINDOW = "autom. ausblenden"
RECAP_SCALING = "Skalierung"
RECAP_FIGHT_OPTIONS = "Kampfoptionen"
RECAP_LIMIT_FIGHTS_TO_COMBAT = "Limitiere auf 'im Kampf'"
RECAP_LIMIT_FIGHTS_TO_ENCOUNTERS = "Limit Fights to Encounters"
RECAP_ONLY_COMBATANTS_WITH_DURATION = "Nur K\195\164mpfe mit Zeitdauer"
RECAP_ONLY_UNIQUE_COMBATANTS = "Nur einzelne K\195\164mpfer"
RECAP_HIDE_GROUP = "Verstecke Gruppe"
RECAP_HIDE_OTHERS = "Verstecke weitere K\195\164mpfer"
RECAP_STORE_ONLY_DISPLAYED_COMBATANTS = "Speichere nur angezeigte K\195\164mpfer"
RECAP_MERGE_PETS_WITH_OWNERS = "Verbinde Pet mit Eigent\195\188mer"
RECAP_MERGE_ALL_PETS_INTO_ONE_PET = "Merge All Pets into One Pet"
RECAP_IGNORE_GLOBAL_UNIQUE_IDENTIFIERS = "Ignoriere Global Unique Identifiers"
RECAP_LIBDATABROKER_SUPPORT = "LibDataBroker Support"
RECAP_END_FIGHT_IF_IDLE = "Beende Kampf, wenn unt\195\164tig"
RECAP_END_FIGHT_DELAY = "Kampf-Ende Verzoegerung"
RECAP_DATA_OPTIONS = "Daten Optionen"
RECAP_LIGHT_DATA_MODE = "Einfacher Datenmodus"
RECAP_OTHER_DATA_MODE = "Datenmodus 'Sonstige'"
RECAP_MATRIX_DATA_MODE = "Matrix Daten Modus"
RECAP_RECENT_DATA_MODE = "Datenmodus 'Neueste'"
RECAP_LIVE_DATA_MODE = "Live Data Mode"
RECAP_WARN_DATA = "Warnung, wenn Datens\195\164tze zu gross werden"
RECAP_OTHER_OPTIONS = "Weitere Optionen"
RECAP_REMIND_GROUP_STATUS = "Erinnerung bei Betreten / Verlassen Gruppe"
RECAP_REMIND_INSTANCE_STATUS = "Erinnere bei Betreten oder Verlassen Instanz"
RECAP_PAUSE_OUTSIDE_INSTANCES = "Pause Outside Instances"
RECAP_PAUSE_INSIDE_BATTLEGROUNDS = "Pause Inside Battlegrounds"
RECAP_RESET_ON_LOGOUT = "Reset on Logout"
RECAP_USE_GLOBAL_SETTINGS = "Nutze globale Einstellungen"
RECAP_COPY_GLOBAL_TO_CHARACTER = "Copy Global to Character"
-- RecapOptions.xml : Data Sets
RECAP_FIGHT_DATA_SETS = "Kampf-Datens\195\164tze"
RECAP_SAVE_GROUP_COMBATANTS_ONLY = "Speichere nur K\195\164mpfer der Gruppe"
RECAP_AUTOMATICALLY_SAVE_BOSS_FIGHTS = "Automatically Save Boss Fights"
RECAP_SAVE_ALL = "Speichere alles"
RECAP_SAVE_LAST = "Speichere letztes"
RECAP_LOAD = "Laden"
RECAP_LOAD_INTO_ALL_FIGHTS = "Load into All Fights"
RECAP_DELETE = "L\195\182schen"
RECAP_DELETE_ALL = "Delete All"
RECAP_RENAME = "Rename"
-- RecapOptions.xml : Reports
RECAP_FIGHT_REPORTING = "Kampfbericht"
RECAP_REPORT_RANKS_IN_MULTIPLE_ROWS = "Berichte in mehreren Zeilen (Shift+Klick)"
RECAP_POST_IN_COLUMNS = "Post in Columns"
RECAP_AUTOMATICALLY_POST_RANKS_AFTER_EACH_FIGHT = "Poste die Rangfolge automatisch nach jedem Kampf"
RECAP_AUTOMATICALLY_POST_CHANGES_IN_LEADERSHIP = "Poste den Anf\195\188hrerwechsel automatisch"
RECAP_AUTOMATICALLY_POST = "Poste automatisch:"
RECAP_AUTOMATICALLY_POST_TO = "In den Channel:"
RECAP_WOWCHATLOG_TXT = "Schreibe nach WoWChatLog.txt"
RECAP_OPEN_WOWCHATLOG_TXT = "\195\150ffnen"
RECAP_ACQUIRING_CHANNEL = "Empfange Channel..."
RECAP_CHANNEL_JOINED = "Channel beigetreten"
RECAP_REPORT_TO_WOWCHATLOG_TXT = "Bericht"
RECAP_CLOSE_WOWCHATLOG_TXT = "Schliessen"
-- RecapOptions.xml : Clipboard
RECAP_CLIP_EXPLANATION = "Dr\195\188cke CTRL+C, um den markierten Text in die Zwischenablage zu kopieren.\n Um ihn irgendwo wieder abzulegen, dr\195\188cke CTRL+V."
RECAP_CLIPBOARD = "Speichere in die Zwischenablage"
RECAP_REPORT_FIGHTS_TO_CLIPBOARD = "Schreibe K\195\164mpfe"
RECAP_REPORT_DETAILS_TO_CLIPBOARD = "Schreibe Details"
RECAP_WRITE_ONLY_GROUP = "Zeige nur K\195\164mpfer der Gruppe"
RECAP_FORMAT_IN_HTML = "Formatiere Bericht in HTML"
RECAP_TAB_DELIMITED_FORMAT = "Tab-Delimited Report Format"
-- RecapOptions.xml : Synchronization
RECAP_SYNC = "Sync"
RECAP_SYNCHRONIZATION = "Synchronisation"
RECAP_ENABLE_SYNC = "Synchronisation aktivieren"
RECAP_SYNC_STATE_IGNORE = "Ignoriere Synchronisation"
RECAP_SYNC_STATE_READY = "Warte auf Synchronisation"
RECAP_SYNC_STATE_MEMBER = "Mitglied der Synchronisation"
RECAP_SYNC_STATE_LEADER = "Leiter der Synchronisation"
RECAP_START_SYNC = "Starte Synchronisation"
RECAP_MERGE_PETS_OFF = "<== mit Pets zusammenfassen aus"
RECAP_MERGE_PETS_ON = "<== mit Pets zusammenfassen ein"
RECAP_MANUAL_SYNC = "Manuelle Synchronisation"
RECAP_BECOME_LEADER = "Leiter werden"
RECAP_LIST_MEMBERS = "Zeige Mitglieder"
RECAP_CLEAR_INACTIVE_MEMBERS = "L\195\182sche inaktive Mitglieder"
RECAP_SKIP_NEXT_FIGHT = "Skip Next Fight"
-- RecapOptions.xml : Effects to Ignore
RECAP_IGNORES = "Ignores"
RECAP_SPELLID = "Spell ID"
RECAP_SPELLNAME = "Spell Name"
RECAP_IGNORED_EFFECTS = "Ignored Effects"
RECAP_ADD = "Add"
RECAP_REMOVE = "Remove"
RECAP_ADD_SUGGESTED_IGNORES = "Add Suggested Ignores"
-- RecapOptions as shown in the Blizzard Addons pane
RECAP_SHOW_RECAP = "Show Recap"
RECAP_FORCE_SHOW_RECAP = "Force Show Recap"
RECAP_SHOW_RECAP_OPTIONS = "Show Recap Options"

-- RecapPanel.xml
RECAP_DAMAGE = "Schaden"
RECAP_GLANCES = "Ber\195\188hr"
RECAP_HITS = "Treffer"
RECAP_CRITS = "Krits"
RECAP_CRUSHES = "Schmetts"
RECAP_AVERAGE = "Durchschnittlich"
RECAP_MISSED_DETAILS = "Verfehlungen Details"
RECAP_MISSED = "Verfehlt"
RECAP_DODGED = "Ausgew"
RECAP_PARRIED = "Pariert"
RECAP_BLOCKED = "Geblockt"
RECAP_ABSORBED = "Absorbiert"
RECAP_DEFLECTED = "Abgelenkt"
RECAP_EVADED = "Entkommen"
RECAP_RESISTED = "Widerst"
RECAP_REFLECTED = "Reflektiert"
RECAP_IMMUNE = "Immun"
RECAP_SPELL_OR_ABILITY = "Spruch oder F\195\164higkeit"
RECAP_INCOMING_SPELL_OR_ABILITY = "Spruch oder F\195\164higkeit (erhalten)"
RECAP_OUTGOING_SPELL_OR_ABILITY = "Spruch oder F\195\164higkeit (verursacht)"
RECAP_MISSES = "Verfehlungen"
RECAP_CASTS = "Casts"
RECAP_MIN = "Min"
RECAP_AVG = "Durch"
RECAP_SUMMARY = "Zusammenfassung"
RECAP_LAST_FIGHT = "Letzter Kampf"
RECAP_ALL_FIGHTS = "Alle K\195\164mpfe"
RECAP_TICKS = "Ticks"
RECAP_INCOMING = "Erhalten"
RECAP_OUTGOING = "Verursacht"
RECAP_OTHER_EFFECTS = "Sonstige Effekte"
RECAP_TOTAL = "Gesamt"
RECAP_ATTRIBUTE = "Attribut"
RECAP_DISPELS = "Dispels"
RECAP_INTERRUPTS = "Interrupts"
RECAP_STEALS = "Gestohlen"
RECAP_TIMINGS = "Zeiten"
RECAP_INTERVALS = "Intervall"
RECAP_SECONDS = "Sekunden"
RECAP_SECS = "secs"
RECAP_DURATIONS = "Dauer"
RECAP_INTERRUPT = "Unterbrechungen"
RECAP_ESTIMATED_INTERVAL = "gesch\195\164tztes Intervall"
RECAP_ESTIMATED_DURATION = "gesch\195\164tzte Dauer"
RECAP_PARTIALS = "Partiell"
RECAP_ABSORBS = "Absorbiert"
RECAP_BLOCKS = "Geblockt"
RECAP_RESISTS = "Widerst"
RECAP_PART_RESIST = "Part Resist"
RECAP_ESTIMATED_TOTAL_RESISTED = "Gesch\195\164tzt widerstanden gesamt"
RECAP_TARGET_OF_OUTGOING = "Dem Ziel zugef\195\188gt"
RECAP_SOURCE_OF_INCOMING = "Von Quelle erhalten"
RECAP_DETAIL_ENTRIES = "Detail Entries"

-- RecapRecent.xml
RECAP_RECENT_INCOMING_EVENTS = "Neuste erhaltene Ereignisse"
RECAP_RECENT_OUTGOING_EVENTS = "Neuste verursachte Ereignisse"
RECAP_RECENT_INCOMING_EFFECTS = "Neuste erhaltene Effekte"
RECAP_RECENT_OUTGOING_EFFECTS = "Neuste verursachte Effekte"
RECAP_RECENT_EVENTS = "Neuste Ereignisse"
RECAP_RECENT_DISPELS_AND_INTERRUPTS = "Neuste Bannungen and Interrupts"
RECAP_RECENT_DEATHS = "Recent Deaths"

-- more miscellaneous display strings
RECAP_TIME_FIGHTING = "Zeit Schaden verursacht"
RECAP_TIME_DAMAGED = "Zeit Schaden erhalten"
RECAP_TIME_HEALING = "Zeit Heilung verursacht"
RECAP_KILLS = "Tode"
RECAP_DPS_OUT = "DPS Out"
RECAP_DPS_IN = "DPS In"
RECAP_HPS_OUT = "HPS Out"
RECAP_TOTAL_DPS_OUT = "Total DPS verursacht"
RECAP_TOTAL_DPS_IN = "Total DPS erhalten"
RECAP_CRIT_RATE = "Krit Rate"
RECAP_TEN_ROWS = "10 Zeilen"
RECAP_FIVE_SECONDS = "5 Sekunden"
RECAP_TEN_SECONDS = "10 Sekunden"
RECAP_ONE_THOUSAND_EVENTS = "1000 Ereignisse"
RECAP_GROUP_FIGHT_TIME = "Kampfzeit zusammenfassen"
RECAP_GROUP_DPS = "DPS zusammenfassen"
RECAP_ONE = "1.0"
RECAP_DURATION = "Duration"
RECAP_GRAPH = "Graph"
RECAP_TEXT = "Text"
RECAP_PEAK = "Peak"
RECAP_MORE_RIGHT = "more >"
RECAP_LESS_RIGHT = "< less"
RECAP_MORE_LEFT = "< more"
RECAP_LESS_LEFT = "less >"
RECAP_CHECK_ALL = "Check All"
RECAP_UNCHECK_ALL = "Uncheck All"
RECAP_LIVE_GRAPH_AND_TEXT = "Live Graph & Text"


--[[ miscellaneous localized strings ]]

recap_temp.Localize = {}
recap_temp.Localize.LastAll = { Last="letzter Kampf", All="alle K\195\164mpfe" }
recap_temp.Localize.LastAllShort = { Last="letzter", All="alle" }
recap_temp.Localize.StoppedActiveIdle = { Stopped="Gestoppt", Active="Aktiv", Idle="Unt\195\164tig" }
recap_temp.Localize.RankTop = "Rang Top"
recap_temp.Localize.None = "none"
recap_temp.Localize.Totals = "Total"
recap_temp.Localize.Details = "Details"
recap_temp.Localize.Status = "Status"
recap_temp.Localize.NewLeader = "Neuer Leiter"
recap_temp.Localize.With = "mit"
recap_temp.Localize.Of = "von"
recap_temp.Localize.For = "f\195\188r"
recap_temp.Localize.And = "und"
recap_temp.Localize.Max = "Max"
recap_temp.Localize.At = "At"
recap_temp.Localize.Seconds = "Sekunden"
recap_temp.Localize.Events = "Ereignisse"
recap_temp.Localize.Rows = "Zeilen"
recap_temp.Localize.Subtotal = "Teilsumme"
recap_temp.Localize.Total = "Gesamt"
recap_temp.Localize.Group = "Gruppe"
recap_temp.Localize.NonGroup = "Nicht-Gruppe"
recap_temp.Localize.ElementOther = "Anderes" --  Damage element not specified
recap_temp.Localize.ElementHealing = "Heilung" --  Healing element not specified
recap_temp.Localize.Melee = "Nahkampf"
recap_temp.Localize.Environment = "Umfeld"
recap_temp.Localize.OtherEffects = "Sonstige Effekte"
recap_temp.Localize.OwnedBy = "Besitzer:"
recap_temp.Localize.VerboseLinkStart = "Recap %s: %s erhielt %s Schaden \195\188ber %s bei %s DPS In (%s Tode); verursachte %s Schaden \195\188ber %s bei %s DPS (max Treffer %d); leistete %s Heilung \195\188ber %s bei %s HPS"
recap_temp.Localize.VerboseGroupTotalStart = "Recap %s: K\195\164mpfer der Gruppe erhielten %s Schaden \195\188ber %s bei %s DPS In (%s Tode); verursachten %s Schaden \195\188ber %s bei %s DPS (max Treffer %d); leisteten %s Heilung \195\188ber %s bei %s HPS"
recap_temp.Localize.VerboseNonGroupTotalStart = "Recap %s: K\195\164mpfer, die nicht in der Gruppe sind, erhielten %s Schaden \195\188ber %s bei %s DPS In (%s Tode); verursachten %s Schaden \195\188ber %s bei %s DPS (max Treffer %d); leisteten %s Heilung \195\188ber %s bei %s HPS"
recap_temp.Localize.LinkRank = { Name="Combatant", Time="Kampfzeit", MaxHit="Max Treffer", DmgIn="Schaden erhalten", DmgOut="Schaden verursacht", DPS="DPS", DPSPerGear="DPS/Gear", Heal="Heilung", Deaths="Tode", HealP="Heilung", DmgInP="Schaden erhalten", DmgOutP="Schaden verursacht", DPSvsAll="DPS vs Gesamt", Over="Gesch\195\164tzte \195\188berheilung", TimeIn="Zeit Schaden erhalten", TimeHeal="Zeit Heilung", DPSIn="DPS In", HPS="Heilung pro Sekunde", Seen="Erstmals gesehen", Dispels="Dispels", Class="Class", Interrupts="Interrupts" }
recap_temp.Localize.StatusTooltip = "Ist dieses Licht rot, pausiert die Kampfaufzeichnung.\n\nIst dieses Licht gr\195\188n, wird gerade ein Kampf aufgezeichnet.\n\nIst dieses Licht aus, Recap ist unt\195\164tig und wartet auf einen Kampfbeginn.\n"
recap_temp.Localize.RankUsage = "Um die Recap statistik in den chat zu kopieren, starte einen chat und dr\195\188cke shift+klick. z.B.:\n|cFFAAAAFF/p (shift+klick Zeit)|cFFFFFFFF <- sendet eine Rangfolge auf Zeit zu /p\n|cFFFF8000/ra (shift+klick DPS)|cFFFFFFFF <- sendet eine Rangfolge von DPS zu /ra\n\nOn the main or load panel, holding down the alt key (option key on a Mac) while shift+clicking a column header will post non-friendly combatants."
recap_temp.Localize.SkipChannels = { "Allgemein", "Handel", "SucheNachGruppe", "LokaleVerteidigung", "WeltVerteidigung" }
recap_temp.Localize.OutgoingHealDetailLink = "Recap %s: %s: %s (%s) heilte %s hp (%s von %s Heilungen) (%s HPS)"
recap_temp.Localize.OutgoingHealDetailLinkNoElement = "Recap %s: %s: %s heilte %s hp (%s von %s Heilungen) (%s HPS)"
recap_temp.Localize.OutgoingDamageDetailLink = "Recap %s: %s: %s (%s) schadete %s hp (%s von %s Schaden) (%s DPS)"
recap_temp.Localize.OutgoingDamageDetailLinkNoElement = "Recap %s: %s: %s schadete %s hp (%s von %s Schaden) (%s DPS)"
recap_temp.Localize.TargetHealDetailLink = "Recap %s: %s heilte %s %s hp (%s von %s Heilungen)"
recap_temp.Localize.TargetDamageDetailLink = "Recap %s: %s schadete %s %s hp (%s von %s Schaden)"
recap_temp.Localize.IncomingHealDetailLink = "Recap %s: %s (%s) heilte %s %s hp (%s von %s Heilungen) (%s HPS)"
recap_temp.Localize.IncomingHealDetailLinkNoElement = "Recap %s: %s heilte %s %s hp (%s von %s Heilungen) (%s HPS)"
recap_temp.Localize.IncomingDamageDetailLink = "Recap %s: %s (%s) schadete %s %s hp (%s von %s Schaden) (%s DPS)"
recap_temp.Localize.IncomingDamageDetailLinkNoElement = "Recap %s: %s schadete %s %s hp (%s von %s Schaden) (%s DPS)"
recap_temp.Localize.SourceHealDetailLink = "Recap %s: %s heilte %s %s hp (%s von %s Heilungen)"
recap_temp.Localize.SourceDamageDetailLink = "Recap %s: %s schadete %s %s hp (%s von %s Schaden)"
recap_temp.Localize.OtherDetailLink = "Recap %s: %s: %s: %s trat %s Mal auf %s"
recap_temp.Localize.OtherDetailType = { "Spruch", "Spruch", "Debuff/Verlust", "Debuff/Verlust", "Buff/Erhalt", "Buff/Erhalt", "Debuff/Buff/Other", "Debuff/Buff/Other" }
recap_temp.Localize.ConfirmLightData = "Du hast gew\195\164hlt, den einfachen Modus zu aktivieren."
recap_temp.Localize.ConfirmHeavyData = "Du hast gew\195\164hlt, den einfachen Modus zu deaktivieren."
recap_temp.Localize.ConfirmLastReset = "Du hast ausgew\195\164hlt, den letzten Kampf zur\195\188ckzusetzen.\n\nWenn Du best\195\164tigst, wird die Information des letzten Kampfes von 'allen K\195\164mpfen' wieder abgezogen. Sei sicher, dass Du das willst.\n\nDies ist kein einfaches L\195\182schen der Liste.\n\nIf you meant instead to reset All Fights, the middle button below will do that for you."
recap_temp.Localize.ConfirmLastResetCombatant = "Du hast ausgew\195\164hlt, den letzten Kampf zur\195\188ckzusetzen.\n\nWenn Du best\195\164tigst, wird die Information des letzten Kampfes von 'allen K\195\164mpfen' wieder abgezogen. Sei sicher, dass Du das willst.\n\nDies ist kein einfaches L\195\182schen der Liste."
recap_temp.Localize.ConfirmLoadIntoAllFights = "Are you certain that you want to load the saved Data Set into the All Fights panel?  If you accept, your current All Fights data will be overwritten."
recap_temp.Localize.ConfirmDeleteFightDataSet = "Are you certain that you want to delete the selected saved Data Sets?\n\nThis action cannot be undone."
recap_temp.Localize.ConfirmDeleteAllFightDataSets = "Are you certain that you want to delete ALL of your saved Data Sets?\n\nThis action cannot be undone."
recap_temp.Localize.ConfirmRenameFightDataSet = "Modify the text in the edit box to rename the selected saved Data Set, then click Accept."
recap_temp.Localize.LastFightSaved = "Letzten Kampf gespeichert"
recap_temp.Localize.LogHeader = "__ Recap [%.3f] (%s): generiert von %s f\195\188r %s am %s in %s __"
recap_temp.Localize.LogFormat = "%35s ! %3s %7s !%10s %8s %6s %5s %7s %8s !%10s %8s %4s %7s !%10s %8s %4s %5s %7s %7s %6s"
recap_temp.Localize.LogFormatTabDelimited = "%35s	%2s	%3s	%10s	%8s	%6s	%5s	%7s	%8s	%10s	%8s	%4s	%7s	%10s	%8s	%4s	%5s	%7s	%7s	%6s"
recap_temp.Localize.Log = { "Name", "Lvl","Klasse", "Zeit-T", "Schaden", "%%", "Max", "DPS", "DPS/Gear", "Schaden-T", "Getankt", "%%", "DPS In", "Heilung-T", "Heilung", "%%", "Over", "HPS", "Dispels", "Interrupts", "Deaths" }
recap_temp.Localize.HTMLHeader = "<tr><td colspan=\"12\">Recap [%.3f] (%s): generiert von %s f\195\188r %s am %s in %s</td></tr>"
recap_temp.Localize.HTMLFormat1 = "<tr align=\"right\"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
recap_temp.Localize.HTMLFormat2 = "<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
recap_temp.Localize.HTMLPrefix = "<table CELLPADDING=\"2\">"
recap_temp.Localize.HTMLSuffix = "</table>"
recap_temp.Localize.DetailHeader = "__ Recap %s generiert mit Details f\195\188r %s am %s in %s __"
recap_temp.Localize.DetailFormat = "%30s %18s !%8s %5s !%8s !%7s %6s %6s %6s !%5s %6s %6s %6s !%5s %6s %6s %6s !%5s %6s %6s %6s %7s !%4s %7s"
recap_temp.Localize.DetailFormatTabDelimited = "%30s	%18s	%8s	%5s	%8s	%7s	%6s	%6s	%6s	%5s	%6s	%6s	%6s	%5s	%6s	%6s	%6s	%5s	%6s	%6s	%6s	%7s	%4s	%7s"
recap_temp.Localize.Detail = { "Effekte", "Element", "Total", "Rate", "Max", "Ber\195\188hr", "Min", "Durch", "Max", "Treffer", "Min", "Durch", "Max", "Ticks", "Min", "Durch", "Max", "Krits", "Min", "Durch", "Max", "Rate", "Verfehl", "Rate" }
recap_temp.Localize.HTMLDetailHeader = "<tr><td colspan=\"24\">Recap generiert von %s am %s in %s</td></tr>"
recap_temp.Localize.HTMLDetailFormat1 = "<tr align=\"right\"><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
recap_temp.Localize.HTMLDetailFormat2 = "<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
recap_temp.Localize.HTMLDetailFormat3 = "<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
recap_temp.Localize.NoFreeChannels = "Es sind keine channels frei, um ein log zu erstellen.  Verlasse bitte einen channel und versuche es noch einmal."
recap_temp.Localize.NoChannelNumber = "Ausserstande eine Channelnummer zu erhalten."
recap_temp.Localize.LogWritten = "Recap schreibt nach WoWChatLog.txt"
recap_temp.Localize.ConfirmGlobalSettings = "Du willst die globalen Einstellungen aktivieren.\n\nWenn du das machst, wird das Interface neu geladen und die Informationen der anderen Charaktere gehen verloren."
recap_temp.Localize.ConfirmSeparateSettings = "Du willst die globalen Einstellungen deaktivieren.\n\nWenn du das machst, wird das Interface neu geladen und andere Charakter werden die Daten extra speichern."
recap_temp.Localize.LotsOfDataWarning = "Recap hat %d K\195\164mpfer in den Daten\n\n==>  %s  <==\n\nDiese Nachricht bedeutet nicht, dass der Sopeicher voll ist.  Es ist lediglich ein Hinweis.  Du kannst diese Warnung ausschalten in Optionen / Einstellungen.\n"
recap_temp.Localize.SavedDataSetsSizeWarning = "Recap has more than %d Mbytes of saved Data Sets.\n\nYou may wish to delete saved Data Sets that you no longer need (see Options / Data Sets).\n\nYou can turn this warning off on the Options / Settings tab.\n"
recap_temp.Localize.DamagedDataWarning = "Recap has detected possible damage to the saved settings and combatant data for %s.\n\nThe settings have been restored from backup.\n\nThe combatant data has not been restored.\n\nIf you don't want to try to rescue that combatant data, It is safe to now click 'Okay' and to continue to use Recap normally.  No need to relog or anything fancy.\n\nIf you are a bit of a computer geek you can rescue the data file now, before logging out.  Check in the folder\n\nWorld of Warcraft/WTF/Account/<account name>/%s/%s/SavedVariables\n\nfor the Recap.lua data file and copy it to a safe place.\n\nIf you edit the file using a text editor, you might be able to rescue most of the combatant data.  Try deleting some of the recap_combatants table.\n"
recap_temp.Localize.VersionCheck = "Die Recap Programmdatei ist evtl besch\195\164digt. Versuche dies zu beheben, indem Du den Recap Ordner l\195\182schst und dann eine frisch heruntergeladene Kopie von Recap installierst."
recap_temp.Localize.ConfirmIgnoreGUIDs = "Du willst 'global unique identifiers' nicht nutzen.\n\nAkzeptierst Du, wird Recap einen Reset durchf\195\188hren und Synchronisation wird nicht erlaubt sein."
recap_temp.Localize.ConfirmUseGUIDs = "Du willst 'global unique identifiers' nutzen.\n\nAkzeptierst Du, wird Recap einen Reset durchf\195\188hren."
recap_temp.Localize.ConfirmDisableLDBSupport = "You've chosen to disable LibDataBroker support.\n\nIf you accept, the UI will be reloaded."
recap_temp.Localize.NotAllowedDuringCombat = "Recap: Verboten w\195\164hrend Kampf"
recap_temp.Localize.InvitesYouToSynchronize = "l\195\164dt Dich ein, einer Synchronisation beizutreten"
recap_temp.Localize.NewSynchronization = "neue Synchronisation"
recap_temp.Localize.OngoingSynchronization = "laufende Synchronisation"
recap_temp.Localize.AcceptedSync = "akzeptierte Deine Einladung zur Synchronisation"
recap_temp.Localize.DeclinedSync = "lehnte Deine Einladung zur Synchronisation ab"
recap_temp.Localize.AsksYouToPause = "asks you to pause Recap"
recap_temp.Localize.AsksYouToResume = "asks you to resume Recap"
recap_temp.Localize.MergePetsOff = "Pets zusammenfassen aus"
recap_temp.Localize.MergePetsOn = "Pets zusammenfassen ein"
recap_temp.Localize.IgnoreGUIDsOn = "Ignore GUIDs on"
recap_temp.Localize.Timestamp = "Zeitstempel"
recap_temp.Localize.Leader = "Leiter"
recap_temp.Localize.LastUpdateWas = "Letztes Update war"
recap_temp.Localize.Ago = "(hh:mm:ss) zuvor"
recap_temp.Localize.SkipNextFightBegins = "Skip Next Fight begins"
recap_temp.Localize.SkipNextFightEnds = "Skip Next Fight ends"
recap_temp.Localize.NotAllowedDuringSync = "Recap: Verboten w\195\164hrend Synchronisation"
recap_temp.Localize.RemindJoinGroup = "Recap:  Du bist einer Gruppe beigetreten.  Dies ist eine Erinnerung, das zu tun, woran du erinnert werden wolltest.  A button to reset Recap is enabled if you aren't in a synchronization."
recap_temp.Localize.RemindLeaveGroup = "Recap:  Du hast die Gruppe verlassen.  Dies ist eine Erinnerung, das zu tun, woran du erinnert werden wolltest."
recap_temp.Localize.RemindEnterInstance = "Recap: Du hast gerade eine Instanz betreten.  Dies ist die Erinnerung das zu tun, woran du erinnert werden wolltest.  A button to reset Recap is enabled if you aren't in a synchronization."
recap_temp.Localize.RemindLeaveInstance = "Recap: Du hast gerade eine Instanz verlassen.  Dies ist die Erinnerung das zu tun, woran du erinnert werden wolltest."
recap_temp.Localize.NoBackupSettings = "Recap: So sorry, I've checked behind the refrigerator and underneath the karaoke machine, but I can't seem to find any backed up settings for this character.  Default settings have been used."
recap_temp.Localize.DataSetNameAlreadyExists = "Recap: Your proposed data set name already exists (or is blank)."
recap_temp.Localize.OutOfDateSyncVersion = "Du kannst der Synchronisation nicht beitreten, weil bei Dir eine \195\164ltere und inkompartible Version von Recap l\195\164uft."
recap_temp.Localize.SynchronizationComplete = "Synchronization complete."
recap_temp.Localize.SyncMembers = "Mitglieder der Synchronisation"
recap_temp.Localize.InactiveSyncMembers = "Inaktive Mitglieder der Synchronisation"
recap_temp.Localize.InSync = "In Sync"
recap_temp.Localize.Unknown = "Unbekannt"
recap_temp.Localize.Removed = "gel\195\182scht"
recap_temp.Localize.OtherDataModeNotEnabled = "Datenmodus 'Sonstige' ist nicht aktiviert"
recap_temp.Localize.MatrixDataModeNotEnabled = "Matrix Daten Modus ist nicht aktiviert"
recap_temp.Localize.RecentDataModeNotEnabled = "Recent Data Mode is not enabled"
recap_temp.Localize.LiveDataModeNotEnabled = "Live Data Mode is not enabled"
recap_temp.Localize.NotAvailable = "Nicht verf\195\188gbar"
recap_temp.Localize.Entities = "Entities"
recap_temp.Localize.Attacks = "Attacken"
recap_temp.Localize.Dispels = "Dispels"
recap_temp.Localize.Dispelled = "Dispelled"
recap_temp.Localize.Cast = "Cast"
recap_temp.Localize.Fail = "Fail"
recap_temp.Localize.Interrupts = "Unterbricht"
recap_temp.Localize.Durability = "Haltbarkeit"
recap_temp.Localize.Interrupted = "Unterbrochen"
recap_temp.Localize.Died = "gestorben"
recap_temp.Localize.Killed = "get\195\182tet"
recap_temp.Localize.TimeWindow = "Zeitfenster"
recap_temp.Localize.AllCombatants = "Alle K\195\164mpfer"
recap_temp.Localize.SpellIDNotRecognized = "Spell ID not recognized"
recap_temp.Localize.DataSet = "Data Set"
recap_temp.Localize.DataSetSelected = "Data Set Selected"
recap_temp.Localize.DataSetsSelected = "Data Sets Selected"
recap_temp.Localize.IncompatibleCombination = "Recap: Having all three of 'Hide Other Combatants', 'Store Only Displayed Combatants', and 'Auto Save Boss Fights' enabled at the same time is not supported."
recap_temp.Localize.GhoulMinion = "Ghoul Minion"
recap_temp.Localize.ReportOnRecentDeaths = "report on recent deaths"
recap_temp.Localize.Combatants = "K\195\164mpfer"
recap_temp.Localize.Damage = "Schaden"
recap_temp.Localize.Heal = "Heilung"
recap_temp.Localize.Overheal = "\195\156berheilung"
recap_temp.Localize.Absorbed = "Absorbiert"
recap_temp.Localize.Hits = "Treffer"
recap_temp.Localize.Misses = "Verfehlungen"
recap_temp.Localize.Steals = "Gestohlen"
recap_temp.Localize.MaxGearValue = "Max Gear Value"
recap_temp.Localize.GraphListVerboseLinkStart = "Recap %s: %s %s was %s; %s was %s; %s was %s"

-- click hints
recap_temp.Localize.MinimizedTooltip = "\nClick Hints:\n•• Right-click to see a menu of items to display in this minimized bar."
recap_temp.Localize.MainRowTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for this combatant. Control+double-click for dispels and interrupts only.\n•• Right-click to see a dropdown menu."
recap_temp.Localize.TotalsRowTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for all combatants. Control+double-click for dispels and interrupts only."
recap_temp.Localize.PostRowTooltip = "Click Hints:\n•• Shift+click to post this row."
recap_temp.Localize.PostRowsTooltip = "\nClick Hints:\n•• Shift+Linksklick, um diese in ein ge\195\182ffnetes Chatfenster zu posten."
recap_temp.Localize.ColumnTooltip = "\nClick Hints:\n•• Click to change sorting order."
recap_temp.Localize.ColumnPostTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Alt+shift+click (option+shift+click on a Mac) to post this column for non-friendly combatants."
recap_temp.Localize.ColumnPostAltTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Alt+shift+click (option+shift+click on a Mac) to post this column for non-friendly combatants."
recap_temp.Localize.ColumnMenuTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Right-click to see a menu of columns."
recap_temp.Localize.ColumnPostMenuTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Right-click to see a menu of columns."
recap_temp.Localize.ColumnPostMenuAltTooltip = "\nClick Hints:\n•• Click to change sorting order.\n•• Shift+click to post this column.\n•• Right-click to see a menu of columns.\n•• Alt+shift+click (option+shift+click on a Mac) to post this column for non-friendly combatants."
recap_temp.Localize.ColumnGraphPostTooltip = "\nClick Hints:\n•• Click to begin sorting by this column.  Click again to stop sorting.\n•• Shift+click to post this column."
recap_temp.Localize.EffectRowTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for this effect."
recap_temp.Localize.EffectRowMenuTooltip = "\nClick Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for this effect.\n•• Right-click to see a dropdown menu."
recap_temp.Localize.DetailEntryTooltip = "\nClick Hints:\n•• Shift+click to post this detail entry."
recap_temp.Localize.DetailEntryReportGroupTooltip = "\nClick Hints:\n•• Shift+click to post this detail entry.\n•• Double-click to get a report of this detail entry for all group combatants."
recap_temp.Localize.DetailEntryReportNonGroupTooltip = "\nClick Hints:\n•• Shift+click to post this detail entry.\n•• Double-click to get a report of this detail entry for all combatants who are not in the group."
recap_temp.Localize.RecentRowTooltip = "Click Hints:\n•• Shift+click to post this row.\n•• Double-click to show recent events for all combatants, centred on this event."
recap_temp.Localize.RecentButtonTooltip = "\nClick Hints:\n•• Control+click for dispels and interrupts only."


-- menus
recap_temp.Localize.ColumnMenu = { {Text="Nummerierte Liste",Info="Ranks"}, {Text="Level/Fraktion",Info="Faction"}, {Text="Klasse",Info="Class"},
								{Text="Erstmals gesehen",Info="Seen"}, {Text="Tode",Info="Deaths"},
								{Text="Zeit",Info="Time"}, {Text="Schaden verursacht",Info="DmgOut"}, {Text="Schaden verursacht %",Info="DmgOutP"}, {Text="Max Treffer",Info="MaxHit"}, {Text="DPS verursacht",Info="DPS"}, {Text="DPSPerGear",Info="DPSPerGear"}, {Text="DPS vs Gesamt",Info="DPSvsAll"},
								{Text="Zeit Schaden",Info="TimeIn"}, {Text="Schaden erhalten",Info="DmgIn"}, {Text="Schaden erhalten %",Info="DmgInP"}, {Text="DPS erhalten",Info="DPSIn"},
								{Text="Zeit Heilung",Info="TimeHeal"}, {Text="Heilung",Info="Heal"}, {Text="Heilung %",Info="HealP"}, {Text="\195\156berheilung",Info="Over"}, {Text="HPS",Info="HPS"},
								{Text="Dispels",Info="Dispels"}, {Text="Interrupts",Info="Interrupts"} }
recap_temp.Localize.MinMenu = { {Text="Fenster sperren", Info="Pin"}, {Text="Status Licht",Info="MinStatus"}, {Text="Sync Licht",Info="MinSyncStatus"}, {Text="Letzter/Alle",Info="MinView"},
								{Text="Dein DPS",Info="MinYourDPS"}, {Text="Your Pet Percent",Info="MinYourPetPercent"}, {Text="Total DPS erhalten",Info="MinDPSIn"}, {Text="Total DPS verursacht",Info="MinDPSOut"},
								{Text="Deine HPS",Info="MinYourHPS"}, {Text="HPS Gesamt",Info="MinHPS"},
								{Text="Buttons",Info="MinButtons"}, {Text="Hintergrund",Info="MinBack"} }
recap_temp.Localize.AddMenu = { {Text="Zu Gruppe hinzuf\195\188gen",Info="MenuAdd"}, {Text="Reset",Info="MenuReset"}, {Text="Ignorieren",Info="MenuIgnore"} }
recap_temp.Localize.AddLockMenu = { {Text="Zu Gruppe hinzuf\195\188gen",Info="MenuAdd"}, {Text="Reset",Info="MenuReset"}, {Text="Ignorieren",Info="MenuIgnore"}, {Text="Lock",Info="MenuLock"} }
recap_temp.Localize.AddUnlockMenu = { {Text="Zu Gruppe hinzuf\195\188gen",Info="MenuAdd"}, {Text="Reset",Info="MenuReset"}, {Text="Ignorieren",Info="MenuIgnore"}, {Text="Unlock",Info="MenuUnlock"} }
recap_temp.Localize.DropMenu = { {Text="Aus Gruppe entfernen",Info="MenuDrop"}, {Text="Reset",Info="MenuReset"}, {Text="Ignorieren",Info="MenuIgnore"} }
recap_temp.Localize.DropLockMenu = { {Text="Aus Gruppe entfernen",Info="MenuDrop"}, {Text="Reset",Info="MenuReset"}, {Text="Ignorieren",Info="MenuIgnore"}, {Text="Lock",Info="MenuLock"} }
recap_temp.Localize.DropUnlockMenu = { {Text="Aus Gruppe entfernen",Info="MenuDrop"}, {Text="Reset",Info="MenuReset"}, {Text="Ignorieren",Info="MenuIgnore"}, {Text="Unlock",Info="MenuUnlock"} }
recap_temp.Localize.DetailTitle = { ["Total"] = "Gesamt", ["TotalDmg"] = "Gesamt Dmg", ["TotalHeal"] = "Gesamt Heal", ["TotalPS"] = "per sec", ["TotalPSDmg"] = "DPS", ["TotalPSHeal"] = "HPS",
									["Avg"] = "Durch", ["Max"] = "Max", ["CritP"] = "Krit %", ["MissPOverP"] = "Verfehl / \195\156ber %" }
recap_temp.Localize.DetailMenu = { {Text="Schaden (gesamt)",Info="Total"}, {Text="Schaden (gesamt) Dmg",Info="TotalDmg"}, {Text="Schaden (gesamt) Heal",Info="TotalHeal"},
								   {Text="Total per sec",Info="TotalPS"}, {Text="Total DPS only",Info="TotalPSDmg"}, {Text="Total HPS only",Info="TotalPSHeal"}, {Text="Durchschnittlicher Treffer",Info="Avg"},
								   {Text="Max Treffer",Info="Max"}, {Text="Krit Rate",Info="CritP"}, {Text="Verfehlung Rate/\195\156berheilung Rate",Info="MissPOverP"} }
recap_temp.Localize.EffectMenu = { {Text="Reset Effekte",Info="ResetEffect"} }
recap_temp.Localize.EffectOptMenu = { {Text="Element",Info="EElement"}, {Text="Total",Info="ETotal"}, {Text="Total %",Info="ETotalP"},
									{Text="Max Schaden",Info="EMaxAll"}, {Text="Ber\195\188hrungen",Info="EGlances"}, {Text="Min Ber\195\188hrung",Info="EGlancesMin"}, {Text="Durch Ber\195\188hrung",Info="EGlancesAvg"},
									{Text="Max Ber\195\188hrung",Info="EGlancesMax"}, {Text="Treffer",Info="EHits"}, {Text="Min Treffer",Info="EHitsMin"}, {Text="Durch Treffer",Info="EHitsAvg"},
									{Text="Max Treffer",Info="EHitsMax"}, {Text="Ticks",Info="ETicks"}, {Text="Min Ticks",Info="ETicksMin"}, {Text="Durch Tick",Info="ETicksAvg"},
									{Text="Max Tick",Info="ETicksMax"}, {Text="Krits",Info="ECrits"}, {Text="Min Krits",Info="ECritsMin"}, {Text="Durch Krit",Info="ECritsAvg"},
									{Text="Max Krit",Info="ECritsMax"}, {Text="Krit Rate",Info="ECritsP"}, {Text="Verfehl",Info="EMiss"},
									{Text="Verfehl %",Info="EMissP"} }

-- auto-post drop down choices
recap_temp.Localize.StatDropList = { "DPS", "Schaden", "'Getankt'", "Heilung" }
recap_temp.Localize.ChannelDropList = { "Selbst", "Gruppe", "Sagen", "Raid", "Gilde" }

recap_temp.Localize.MissTypes = { ["Missed"] = "Verfehlt", ["Dodged"] = "Ausgewichen", ["Parried"] = "Parriert", ["Blocked"] = "Geblockt", ["Deflected"] = "Abgelenkt",
								["Resisted"] = "Widerstanden", ["Reflected"] = "Reflektiert", ["Absorbed"] = "Absorbiert", ["Immune"] = "Immun", ["Evaded"] = "Entkommen" }

recap_temp.Localize.ClassName = { ["WARRIOR"] = "Krieger / Kriegerin", ["MAGE"] = "Magier / Magierin", ["ROGUE"] = "Schurke / Schurkin", ["DRUID"] = "Druide / Druidin",
								 ["HUNTER"] = "J\195\164ger / J\195\164gerin", ["SHAMAN"] = "Schamane / Schamanin", ["PRIEST"] = "Priester / Priesterin", ["WARLOCK"] = "Hexenmeister / Hexenmeisterin",
								 ["PALADIN"] = "Paladin / ", ["Pet"] = "Pet", ["DEATHKNIGHT"] = "Todesritter", ["MONK"] = "M\195\182nch" }
recap_temp.Localize.ClassAbbr = { ["WARRIOR"] = "Kri", ["MAGE"] = "Mag", ["ROGUE"] = "Schk", ["DRUID"] = "Dru",
								 ["HUNTER"] = "J\195\164g", ["SHAMAN"] = "Schm", ["PRIEST"] = "Pri", ["WARLOCK"] = "Hex",
								 ["PALADIN"] = "Pal", ["Pet"] = "Pet", ["DEATHKNIGHT"] = "TRtr", ["MONK"] = "Mch" }
recap_temp.Localize.FactionName = { ["Alliance"] = "Allianz", ["Horde"] = "Horde" }
recap_temp.Localize.SchoolName = { [0] = "None", [1] = "Physisch", [2] = "Heilig", [4] = "Feuer", [8] = "Natur", [16] = "Frost", [32] = "Schatten", [64] = "Arkan" }
recap_temp.Localize.PowerName = { [0] = "Mana", [1] = "Wut", [2] = "Fokus", [3] = "Energie", [4] = "Gl\195\188ck", [5] = "Runes", [6] = "Runic", [7] = "Shards", [8] = "Solar", [-8] = "Lunar", [9] = "Holy", [-2] = "Gesundheit",
								  [10] = "Alt", [11] = "Dark", [12] = "Light", [13] = "Orbs", [14] = "Embers", [15] = "Fury" }
recap_temp.Localize.Difficulty = { [0] = "None", [1] = "N5", [2] = "H5", [3] = "N10", [4] = "N25", [5] = "H10", [6] = "H25", [7] = "RF25", [8] = "C5", [9] = "N40", [10] = "N20", [11] = "HScen", [12] = "NScen", [13] = "S3", [14] = "Flex", [15] = "Other" }


-- channels to block when posting Recent Combat Event information (lower case)
recap_temp.Localize.BlockChannels = { "allgemein", "handel", "lokaleverteidigung", "weltverteidigung", "gildenrekrutierung", "schreien", "suchenachgruppe" }

end -- of the localization

localization_de_lua_4773 = true
