local L = LibStub("AceLocale-3.0", true):NewLocale("RaidTracker", "itIT", false)
if not L then return end

-- *** functional strings (must match the game strings exactly) ***

-- naxx
-- ulduar
-- toc
-- icecrown

-- zones

-- *** non-functional (do not have to match game strings) ***

-- lib karma (menu)

-- addon messages

-- command menu

-- UI_Options
L["Wipes"] = "Sconfitte"

-- UI_Templates
L["Title"] = "Titolo"