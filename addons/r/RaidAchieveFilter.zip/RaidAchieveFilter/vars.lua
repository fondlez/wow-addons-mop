--RaidAchieveFilter Achievement IDs
--Please do not use without permission
RAF_IDs, RAF_Names = {}, {}
local uFaction
if UnitFactionGroup("player") == "Alliance" then uFaction = "A" else uFaction = "H" end
--Raids
RAF_IDs[1] = {4534,4535,4536,4537,4531,4628,4577,4538,4578,4528,4629,4582,4539,4529,4630,4579,4580,4527,4631,4601,4581,4530,4532,4636,4583}  --ICC10
RAF_IDs[2] = {4610,4611,4612,4613,4604,4632,4615,4614,4616,4605,4633,4617,4618,4606,4634,4619,4620,4607,4635,4621,4622,4597,4608,4637,4584}  --ICC25
RAF_IDs[3] = {1997,1858,562,1996,2182,566,2176,568,1856,2178,2180,564,2146,572,2184,574,576,578}  --Naxx10
RAF_IDs[4] = {2140,1859,563,2139,2183,567,2177,569,1857,2179,2181,565,2147,573,2185,575,577,579}  --Naxx25
RAF_IDs[5] = {4404,4402,4403,4396,4407,4405,4406,4397}  --Onyxia10
RAF_IDs[6] = {2148,1869,1874,622,2149,1870,1875,623}  -- Malygos
RAF_IDs[7] = {2047,624,1876,2049,2050,2051}  --Sarth10
RAF_IDs[8] = {2048,1877,625,2052,2053,2054}  --Sarth25
RAF_IDs[9] = {4817,4818,4815,4816}  --Halion
RAF_IDs[10] = {3797,3936,3996,3798,3799,3800,3917,3918}  --ToC10
RAF_IDs[11] = {3937,3813,3997,3815,3816,3916,3812}  --Toc25
RAF_IDs[12] = {2886,2888,2890,2892,2894,2909,3097,2907,2905,2911,2913,2914,2915,3056,2927,2925,2930,2919,2923,2933,2937,2931,2934,3058,2945,2947,2940,2939,2941,2953,2955,2959,2951,3006,3076,2985,2979,2980,2982,3177,3178,3179,2961,2967,2969,2963,3182,3138,2989,3180,2971,2973,2977,2975,3176,2996,3181,3008,3009,3012,3015,3014,3157,3141,3158,3159,3003,3036} --Ulduar10
RAF_IDs[13] = {2887,2889,2891,2893,2895,2910,3098,2908,2906,2912,2918,2916,2917,3057,2928,2926,2929,2921,2924,2935,2938,2932,2936,3059,2946,2948,2943,2942,2944,2954,2956,2960,2952,3007,3077,2984,3118,2981,2983,3185,3186,3187,2962,2968,2970,2965,3184,2995,3237,3189,2972,2974,2978,2976,3183,2997,3188,3010,3011,3013,3016,3017,3161,3162,3163,3164,3002,3037} --Ulduar25
RAF_IDs[14] = {5306,5307,5310,5308,5309,4849,5094,5107,5108,5109,5115,5116,4842}  --BWD
RAF_IDs[15] = {5300,4852,5311,5312,5118,5117,5119,5120,5121,4850}  --BoT
RAF_IDs[16] = {5304,5305,5122,5123,4851}  --Throne
RAF_IDs[17] = {5821,5829,5810,5813,5830,5799,5855,5807,5808,5806,5809,5805,5804,5803,5802}  --Firelands
RAF_IDs[18] = {6174,6128,6129,6175,6084,6105,6133,6180,6109,6110,6111,6112,6113,6114,6115,6116,6106,6107,6177}  --DragonSoul
RAF_IDs[19] = {6937,6936,6553,6683,6518,6922,6725,6726,6727,6728,6729,6730,6718,6845}  --Heart of Fear
RAF_IDs[20] = {6823,6674,7056,6687,7933,6686,6455,6719,6720,6721,6722,6723,6724,6458,6844} --Mogu'shan Vaults
RAF_IDs[21] = {6717,6933,6824,6825,6731,6732,6733,6734,6689} --Terrace of Endless Spring
RAF_IDs[22] = {8094,8038,8073,8077,8082,8097,8098,8037,8081,8087,8086,8090,8056,8057,8058,8059,8060,8061,8062,8063,8064,8065,8066,8067,8068,8069,8070,8071,8072} --Throne of Thunder
RAF_IDs[23] = {8536,8528,8532,8521,8530,8520,8453,8448,8538,8529,8527,8543,8531,8537,8463,8465,8466,8467,8468,8469,8470,8471,8472,8478,8479,8480,8481,8482,8458,8459,8461,8462}--Siege
if uFaction == "A" then tinsert(RAF_IDs[23], 8679) else tinsert(RAF_IDs[23], 8680) end 
--Lich King Dungeons
RAF_IDs[24] = {2038,2056,1862,481,492} --Ahn'kahet
RAF_IDs[25] = {1296,1297,1860,480,491} --Azjol'nerub
RAF_IDs[26] = {1872,1817,479,500} --Culling of Strat
RAF_IDs[27] = {2151,2057,2039,482,493} --Drak'tharon
RAF_IDs[28] = {4522,4523,4516,4519} --Forge of Souls
RAF_IDs[29] = {2058,2040,1864,2152,484,495} --Gun'drak
RAF_IDs[30] = {1834,2042,1867,486,497} --Halls of Lightning
RAF_IDs[31] = {4526,4518,4521} --Halls of Reflection
RAF_IDs[32] = {2154,1866,2155,485,496} --Halls of Stone
RAF_IDs[33] = {2150,2037,2036,478,490} --Nexus
RAF_IDs[34] = {1868,2046,2045,2044,1871,487,498} --Oculus
RAF_IDs[35] = {4524,4525,4517,4520} --Pit of Saron
if uFaction == "A" then RAF_IDs[36] = {3802,3803,3804,4296,4298}
else RAF_IDs[36] = {3802,3803,3804,3778,4297} end --Trial of Champion
RAF_IDs[37] = {1919,477,489} --Utgarde Keep
RAF_IDs[38] = {2043,1873,2156,2157,488,499} --Utgarde Pinnacle
RAF_IDs[39] = {2153,2041,1865,1816,483,494} --Violet Hold
-- Cataclysm Dungeons
RAF_IDs[40] = {5281,5282,5283,5284,4833,5060} --Blackrock Caverns
RAF_IDs[41] = {5366,5367,5368,5369,5370,5371,5083} -- Deadmines
RAF_IDs[42] = {5995,6130,6117} --End Time
RAF_IDs[43] = {5297,5298,4840,5062} --Grim Batol
RAF_IDs[44] = {5293,5294,5296,5295,4841,5065} --Halls of Origination
RAF_IDs[45] = {6132,6119} --Hour of Twilight
RAF_IDs[46] = {5291,5290,5292,4848,5066} --Lost City of Tol'vir
RAF_IDs[47] = {5503,5504,5505,5093}--Shadowfang Keep
RAF_IDs[48] = {5287,4846,5063} --Stonecore
RAF_IDs[49] = {5285,5286,4839,5061} --Throne of Tides
RAF_IDs[50] = {5289,5288,4847,5064} --Vortex Pinnacle
RAF_IDs[51] = {6127,6070,6118} --Well of Eternity
RAF_IDs[52] = {5761,5750,5858,5760,5769} --Zul'Aman
RAF_IDs[53] = {5743,5762,5765,5744,5759,5768} --Zul'gurub
-- MoP Dungeons
RAF_IDs[54] = {6479,6476,6945,6759} --Gate of the Setting Sun
RAF_IDs[55] = {6713,6478,6736,6755,6756} --Mogu'shan Palace
RAF_IDs[56] = {6684,6427,6760} --Scarlet Halls
RAF_IDs[57] = {6929,6928,6946,6761} --Scarlet Monastery
RAF_IDs[58] = {6394,6396,6531,6715,6821,6762} --Scholomance
RAF_IDs[59] = {6471,6477,6472,6469,6470} --Shado-Pan
RAF_IDs[60] = {6485,6822,6688,6763} --Siege of Niuzao Temple
RAF_IDs[61] = {6420,6400,6089,6402,6457,6456} --Stormstout Brewery
RAF_IDs[62] = {6475,6460,6671,6757,6758} --Temple of the Jade Serpent
RAF_MapIDs = {
--Raids
604,604,535,535,718,527,531,531,609,543,543,529,529,--LK-13
754,758,773,800,824,--Cata-5
897,896,886,930,953,--MoP-5
--Dungeons
522,533,521,534,601,530,525,603,526,520,528,602,542,523,524,536,--LK-16
753,756,820,757,759,819,747,764,768,767,769,816,781,793,--Cata-14
875,885,871,874,898,877,887,876,867}--MoP-9
--Scenarios
if uFaction == "A" then 
	RAF_IDs[63] = {7261,7258,7257,7252,8310}--Brewing
	RAF_IDs[64] = {7989,7990,7991,7992,7993,7988}--Patience
	RAF_IDs[65] = {7273,7272,7271}--Arena
	RAF_IDs[66] = {8016,8017}--Assault
	RAF_IDs[67] = {8347,8314,8364}--Battle
	RAF_IDs[68] = {8329,8330,8316,8312}--Blood
	RAF_IDs[69] = {6931,6930,6923}--Brewmoon
	RAF_IDs[70] = {7275,7276,8368,7522,8311}--Crypt
	RAF_IDs[71] = {7987,7984,7986,8009}--Dagger
	RAF_IDs[72] = {8319,8317,8318}--DarkHeart
	RAF_IDs[73] = {7267,7266,7265}--Greenstone
	RAF_IDs[74] = {8012,8011,8010}--Lion's
	RAF_IDs[75] = {8295,8294,8327}--Ragefire
	RAF_IDs[76] = {7526,7527,7523}--Theramore
	RAF_IDs[77] = {7231,7232,7239,7249,7248}--Unga
	local MapIDs = {878,912,899,883,940,939,884,900,914,937,880,911,938,906,882}
	for i = 1, #MapIDs do tinsert(RAF_MapIDs, MapIDs[i]) end
	for i = 1, 76 do RAF_Names[i] = GetMapNameByID(RAF_MapIDs[i]) end
	RAF_Names[65] = "Arena of Annihilation"-- (Proving Grounds)
	RAF_Names[68] = "Blood in the Snow"-- (Dun Morogh)
	RAF_Names[72] = "Dark Heart of Pandaria"-- (Vale of Eternal Blossoms)
	RAF_Names[73] = "Greenstone Village"-- (Jade Forest)
	RAF_Names[74] = "Lion's Landing"-- (Krasarang Wilds)
	RAF_Names[76] = "Theramore's Fall"-- (Dustwallow Marsh)
else
	RAF_IDs[63] = {7261,7258,7257,7252,8310}--Brewing
	RAF_IDs[64] = {7989,7990,7991,7992,7993,7988}--Patience
	RAF_IDs[65] = {7273,7272,7271}--Arena
	RAF_IDs[66] = {8016,8017}--Assault
	RAF_IDs[67] = {8347,8315,8366}--Battle
	RAF_IDs[68] = {8329,8330,8316,8312}--Blood
	RAF_IDs[69] = {6931,6930,6923}--Brewmoon
	RAF_IDs[70] = {7275,7276,8368,7522,8311}--Crypt
	RAF_IDs[71] = {7987,7984,7986,8009}--Dagger
	RAF_IDs[72] = {8319,8317,8318}--DarkHeart
	RAF_IDs[73] = {8015,8014,8013}--Domination
	RAF_IDs[74] = {7267,7266,7265}--Greenstone
	RAF_IDs[75] = {8295,8294,8327}--Ragefire
	RAF_IDs[76] = {7529,7530,7524}--Theramore
	RAF_IDs[77] = {7231,7232,7239,7249,7248}--Unga
	local MapIDs = {878,912,899,883,940,939,884,900,914,937,920,880,938,907,882}
	for i = 1, #MapIDs do tinsert(RAF_MapIDs, MapIDs[i]) end
	for i = 1, 76 do RAF_Names[i] = GetMapNameByID(RAF_MapIDs[i]) end
	RAF_Names[65] = "Arena of Annihilation"-- (Proving Grounds)
	RAF_Names[68] = "Blood in the Snow"-- (Dun Morogh)
	RAF_Names[72] = "Dark Heart of Pandaria"-- (Vale of Eternal Blossoms)
	RAF_Names[73] = "Domination Point"-- (Krasarang Wilds)
	RAF_Names[74] = "Greenstone Village"-- (Jade Forest)
	RAF_Names[76] = "Theramore's Fall"-- (Dustwallow Marsh)
end

RAF_Names[1] = RAF_Names[1].." [10]"
RAF_Names[2] = RAF_Names[2].." [25]"--ICC
RAF_Names[3] = RAF_Names[3].." [10]"
RAF_Names[4] = RAF_Names[4].." [25]"--Naxx
RAF_Names[5] = RAF_Names[5].." [10/25]"--Onyxia
RAF_Names[6] = RAF_Names[6].." [10/25]"--Malygos
RAF_Names[7] = RAF_Names[7].." [10]"
RAF_Names[8] = RAF_Names[8].." [25]"--Sarth
RAF_Names[9] = RAF_Names[9].." [10/25]"--Halion
RAF_Names[10] = RAF_Names[10].." [10]"
RAF_Names[11] = RAF_Names[11].." [25]"--ToC
RAF_Names[12] = RAF_Names[12].." [10]"
RAF_Names[13] = RAF_Names[13].." [25]"--Ulduar