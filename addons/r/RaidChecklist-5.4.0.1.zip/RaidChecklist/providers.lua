-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

local RC = RaidChecklist
local RCData = RaidChecklistData
local L = RaidChecklistStrings

if not RC then return end

-- Map from GUID to name
RC.provider_names = {}

-- Map from (de)buff key to list of GUIDs currently providing said de(buff)
RC.providers = RCData:create_provider_table ()

local function remove_provider (rguid)
  -- Iterate over all the (de)buffs
  for key,guidlist in pairs (RC.providers) do
    guidlist[rguid] = nil
  end
  if (RC.OnRefresh) then RC:OnRefresh () end
end

local function add_provider (buff, guid)
  RC.providers[buff][guid] = 3 -- "Provided"
  if (RC.OnRefresh) then RC:OnRefresh () end
end

function RC:UpdateMissing ()
  local guids = RC.is:QueuedInspections ()
  local names
  for i,guid in ipairs (guids) do
    local info = RC.is:GetCachedInfo (guid)
    if info and info.name then
      names = names and names..", "..info.name or info.name
    end
  end
  RC.missing_talents_for = names
end

function RC:OnInspectUpdate (event, guid, unit, info)
  -- Update the talent status
  self:UpdateMissing ()

  -- Clear any previous entries for this guid
  remove_provider (guid)

  -- Update the name, if necessary
  local fullname = (info.realm and info.name.."-"..info.realm) or info.name
  if not fullname or not info.class then return end
  RC.provider_names[guid] = ClassColorString (info.class)..fullname.."|r"

  -- Do matching
  local spec = RCSpecName (info.global_spec_id)
  local level = UnitLevel (unit)
  local class = L[info.class or UNKNOWN]
  local race = info.race
  for _, entry in ipairs (RCData.table) do
    if entry.c == class then
      local match = true
      if match and entry.p then match = false end -- Pets are handled elsewhere
      if match and entry.l and level < entry.l then match = false end
      if match and entry.s and spec ~= entry.s then match = false end
      if match and entry.t then
        if not info.talents or not info.talents[entry.t] then match = false end
      end
      if match and entry.g and not info.glyphs[entry.g] then match = false end
      if match then add_provider (entry.a, guid) end
    end
    if entry.e == race then add_provider (entry.a, guid) end
  end
  --print ("RC: updated talents for GUID "..(guid or "nil")..", unit "..unit)
end


function RC:OnInspectRemove (event, guid)
  -- Update the talent status
  self:UpdateMissing ()

  remove_provider (guid)
  RC.provider_names[guid] = nil
  --print ("RC: removed provider GUID "..(guid or "nil"))
end

RC.is = LibStub ("LibGroupInSpecT-1.0")
RC.is.RegisterCallback (RC, "GroupInSpecT_Update", "OnInspectUpdate")
RC.is.RegisterCallback (RC, "GroupInSpecT_Remove", "OnInspectRemove")

