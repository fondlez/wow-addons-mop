-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

local RC = RaidChecklist
local RCData = RaidChecklistData
local P = RaidChecklistPetFamilies

if not RC then return end

RC.petproviders = RCData:create_provider_table ()

local matrix = {}
for _, pet in pairs (RaidChecklistPetFamilies) do matrix[pet] = {} end
for _, entry in ipairs (RaidChecklistData.table) do
  if entry.p then table.insert (matrix[entry.p], entry.a) end
end

local function remove_petprovider (rguid)
  for key,guidlist in pairs (RC.petproviders) do
    guidlist[rguid] = nil
  end
  if (RC.OnRefresh) then RC:OnRefresh () end
end


local function add_petprovider (buff, guid)
  RC.petproviders[buff][guid] = 3 -- "Provided"
  if (RC.OnRefresh) then RC:OnRefresh () end
end


local RCB = RaidChecklist.button

-- Persistent retrying for when UnitCreatureFamily() returns nil (when it clearly shouldn't)
RC.pet_scan_needed = {}

local AT = LibStub:GetLibrary("AceTimer-3.0")
local retry_pet_scan

local function schedule_pet_rescan ()
  AT:CancelTimer (RC.pet_scan_timer, true)
  RC.pet_scan_timer = AT:ScheduleTimer (retry_pet_scan, 3)
end

retry_pet_scan = function ()
  for i,unit in ipairs (RC.is:GroupUnits ()) do
    if RC.pet_scan_needed[UnitGUID (unit)] then
      RCB:UNIT_PET (unit)
      if next (RC.pet_scan_needed) == nil then
        RC.pet_scan_timer = nil
        return
      end
    end
  end
  schedule_pet_rescan ()
end

local function clear_pending_scan (guid)
  RC.pet_scan_needed[guid] = nil
  if next (RC.pet_scan_needed) == nil and RC.pet_scan_timer then
    AT:CancelTimer (RC.pet_scan_timer, true) -- true = ignore errors
    RC.pet_scan_timer = nil
    RCB:UnregisterEvent ("GROUP_ROSTER_UPDATE")
  end
end

local function add_pending_scan (guid)
  local register = false
  if next (RC.pet_scan_needed) == nil then register = true end
  if not RC.pet_scan_needed[guid] then
    RC.pet_scan_needed[guid] = 1
    if register and not RC.pet_scan_timer then
      RCB:RegisterEvent ("GROUP_ROSTER_UPDATE")
      schedule_pet_rescan ()
    end
  end
end

local function discard_stale_scans (units)
  -- Get the roster of GUIDs still in party/raid
  local active_units = {}
  for i,unit in ipairs (RC.is:GroupUnits ()) do
    if UnitExists (unit) then
      active_units[UnitGUID(unit)] = true
    end
  end
  
  -- Evict any pending scans for GUID no longer available
  for guid,_ in pairs (RC.pet_scan_needed) do
    if not active_units[guid] then
      RC.pet_scan_needed[guid] = nil
    end
  end
end


function RCB:UNIT_PET (unit)
  -- Filter out units we don't care about
  if not UnitInRaid (unit) and not UnitInParty (unit) and unit ~= "player" then return end

  local guid = UnitGUID (unit)
  if not guid then return end
  remove_petprovider (guid)

  local pet = unit.."pet"
  if not UnitExists (pet) then
    clear_pending_scan (guid)
    return
  end

  local family = UnitCreatureFamily (pet)
  local name = UnitName (unit)
  if not family or not name then
    add_pending_scan (guid)
    return
  end

  clear_pending_scan (guid)

  local list = matrix[family]
  if not list then
    -- Maybe we haven't got the right family name, or I messed up the locale info...
    print ("RaidChecklist: missing pet family '"..(family or "nil").."' in locale "..GetLocale()..", please report this so it can be fixed!")
    matrix[family] = {} -- Suppress further messages
    return
  end
  for i,key in ipairs (list) do
    add_petprovider (key, guid)
  end
end

RCB:RegisterEvent("UNIT_PET")

function RCB:GROUP_ROSTER_UPDATE ()
  discard_stale_scans (RC.is:GroupUnits ())
end

function RCB:OnInspectRemove (event, guid)
  remove_petprovider (guid)
end
function RCB:OnInspectUpdate (event, guid, unit, info)
  -- The name might have become available, so fake a UNIT_PET event
  self:UNIT_PET(unit)
end
LibStub ("LibGroupInSpecT-1.0").RegisterCallback (RCB, "GroupInSpecT_Remove", "OnInspectRemove")
LibStub ("LibGroupInSpecT-1.0").RegisterCallback (RCB, "GroupInSpecT_Update", "OnInspectUpdate")

