-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

if not RaidChecklist then return end

local L = RaidChecklistStrings
local NAME = L["Raid Checklist"]

local ldb = LibStub:GetLibrary ("LibDataBroker-1.1")
local dataobj = ldb:NewDataObject (L["Raid Checklist"], {
    type = 'launcher',
    icon = "Interface\\AddOns\\RaidChecklist\\Textures\\button",
    OnClick = function (self, button, ...)
      RaidChecklist.button:OnClick (button, ...)
    end,
    text = NAME,
    label = NAME,
    tocname = 'RaidChecklist'
  })

dataobj.OnTooltipShow = function (tooltip)
  tooltip:AddLine (NAME, 1, 1, 1, 1)
  tooltip:AddLine (L.LDBTOOLTIP)
end

