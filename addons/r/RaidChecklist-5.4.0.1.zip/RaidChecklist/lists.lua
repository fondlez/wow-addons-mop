-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

if not RaidChecklist then return end

local RC = RaidChecklist
local RCData = RaidChecklistData
local L = RaidChecklistStrings

-- Mapping from category to localized category name
local category_names = {
  buffs = L.BUFFS,
  debuffs = L.DEBUFFS,
  dispels = L.DISPELS,
  ccs = L.CC,
  miscs = L.MISC,
  hunterpetabilities = L.HUNTERPETABILITIES,
  warlockpetabilities = L.WARLOCKPETABILITIES,
  totemsall = L.TOTEMS,
  support = L.SUPPORT,
  mcs = L.MOBILITY_CONTROL,
}

-- Helper functions for filtering based on class
local function dk_only (e) return e.c == L.DEATHKNIGHT end
local function druid_only (e) return e.c == L.DRUID end
local function hunter_only (e) return e.c == L.HUNTER end
local function mage_only (e) return e.c == L.MAGE end
local function monk_only (e) return e.c == L.MONK end
local function paladin_only (e) return e.c == L.PALADIN end
local function priest_only (e) return e.c == L.PRIEST end
local function rogue_only (e) return e.c == L.ROGUE end
local function shaman_only (e) return e.c == L.SHAMAN end
local function warlock_only (e) return e.c == L.WARLOCK end
local function warrior_only (e) return e.c == L.WARRIOR end

-- Display filters for the classes that need them.
-- Ensures abilities don't appear in both primary and secondary categories.
local function hunter_displayfilter (entry, category)
  if category == 'hunterpetabilities' then
    return entry.p ~= nil
  else
    return entry.p == nil
  end
end
local function shaman_displayfilter (entry, category)
  if category == 'buffs' or category == 'debuffs' or category == 'miscs' then
    -- Only list non-totem abilities from these categories
    return tContains (RaidChecklistData.totemsall, entry.a) == nil
  end
  return true
end
local function warlock_displayfilter (entry, category)
  if category == 'warlockpetabilities' then
    return entry.p ~= nil
  else
    return entry.p == nil
  end
end
local function warrior_displayfilter (entry, category)
  return tContains (RaidChecklistData.warriorshouts, entry.a) == nil
end


--
-- Checklist layout definitions.
--
RC.lists = {}
RC.lists.definitions = {
  default = {
    columns = {
      { backdroptint = { r = 0, g = 0, b = 1, a = 0.05 }, categories = { 'buffs', 'support' }, },
      { backdroptint = { r = 1, g = 0, b = 0, a = 0.05 }, categories = { 'debuffs', 'dispels', 'miscs' }, },
      { backdroptint = { r = 0, g = 1, b = 0, a = 0.05 }, categories = { 'ccs', 'mcs' }, }
    }
  },

  brief = {
    columns = {
      { backdroptint = { r = 0, g = 0, b = 1, a = 0.05 }, categories = { 'buffs', 'support' }, },
      { backdroptint = { r = 1, g = 0, b = 0, a = 0.05 }, categories = { 'debuffs', 'dispels' }, },
    }
  },

  DEATHKNIGHT_B = {
    columns = { { categories = { 'buffs', 'debuffs', 'support' }, } },
    entry_filter = dk_only,
  },

  DEATHKNIGHT_F = {
    columns = { { categories = { 'buffs', 'debuffs', 'support', 'mcs', 'miscs' }, }, },
    entry_filter = dk_only,
  },

  DRUID_B = {
    columns = { { categories = { 'buffs', 'debuffs', 'support', 'dispels' }, }, },
    entry_filter = druid_only,
  },

  DRUID_F = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'support', 'miscs'  }, },
      { categories = { 'ccs', 'mcs', 'dispels' }, },
    },
    entry_filter = druid_only,
  },

  HUNTER_B = {
    columns = {
      { categories = { 'hunterpetabilities' }, },
      { categories = { 'buffs', 'debuffs', 'dispels', 'mcs' } },
    },
    entry_filter = hunter_only,
    display_filter = hunter_displayfilter,
  },

  HUNTER_F = {
    columns = {
      { categories = { 'hunterpetabilities' }, },
      { categories = { 'buffs', 'debuffs', 'dispels', 'ccs', 'mcs', 'miscs' }, },
    },
    entry_filter = hunter_only,
    display_filter = hunter_displayfilter,
  },

  HUNTER_CB = {
    columns = {
      { categories = { 'buffs', 'support' }, },
      { categories = { 'debuffs', 'dispels' }, },
    },
    entry_filter = hunter_only,
  },

  HUNTER_CF = {
    columns = {
      { categories = { 'buffs', 'support', 'dispels', 'miscs' }, },
      { categories = { 'debuffs', 'ccs', 'mcs' }, },
    },
    entry_filter = hunter_only,
  },

  HUNTER_P = {
    columns = { { categories = { 'hunterpetabilities' }, }, }
  },

  MAGE_B = {
    columns = { { categories = { 'buffs', 'debuffs', 'support', 'dispels' }, }, },
    entry_filter = mage_only,
  },

  MAGE_F = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'support', 'miscs' }, },
      { categories = { 'dispels', 'ccs', 'mcs' }, },
    },
    entry_filter = mage_only,
  },

  MONK_B = {
    columns = { { categories = { 'buffs', 'debuffs', 'dispels' } } },
    entry_filter = monk_only,
  },

  MONK_F = {
    columns = {
      { categories = { 'buffs', 'debuffs' } },
      { categories = { 'dispels', 'mcs', } },
    },
    entry_filter = monk_only,
  },

  PALADIN_B = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'dispels' }, },
    },
    entry_filter = paladin_only,
  },

  PALADIN_F = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'dispels' }, },
      { categories = { 'ccs', 'mcs', 'miscs' }, },
    },
    entry_filter = paladin_only,
  },

  PRIEST_B = {
    columns = { { categories = { 'buffs', 'support', 'dispels' }, }, },
    entry_filter = priest_only,
  },

  PRIEST_F = {
    columns = {
      { categories = { 'buffs', 'support', 'dispels' }, },
      { categories = { 'ccs', 'miscs' }, },
    },
    entry_filter = priest_only,
  },

  ROGUE_B = {
    columns = { { categories = { 'buffs', 'debuffs', 'dispels' }, }, },
    entry_filter = rogue_only,
  },

  ROGUE_F = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'dispels' }, },
      { categories = { 'ccs', 'mcs', 'miscs' }, },
    },
    entry_filter = rogue_only,
  },

  SHAMAN_B = {
    columns = {
      { categories = { 'totemsall', 'buffs', 'debuffs' }, },
      { categories = { 'support', 'dispels' }, },
    },
    entry_filter = shaman_only,
    display_filter = shaman_displayfilter,
  },

  SHAMAN_F = {
    columns = {
      { categories = { 'totemsall', 'buffs', 'debuffs', 'support' }, },
      { categories = { 'dispels', 'ccs', 'miscs' }, },
    },
    entry_filter = shaman_only,
    display_filter = shaman_displayfilter,
  },

  SHAMAN_CB = {
    columns = { { categories = { 'buffs', 'debuffs', 'support', 'dispels' }, }, },
    entry_filter = shaman_only,
  },

  SHAMAN_CF = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'support' }, },
      { categories = { 'dispels', 'ccs', 'miscs' }, },
    },
    entry_filter = shaman_only,
  },

  WARLOCK_B = {
    columns = {
      { categories = { 'warlockpetabilities' }, },
      { categories = { 'buffs', 'debuffs', 'support' }, },
    },
    entry_filter = warlock_only,
    display_filter = warlock_displayfilter,
  },

  WARLOCK_F = {
    columns = {
      { categories = { 'warlockpetabilities', 'buffs', 'support' }, },
      { categories = { 'debuffs', 'ccs', 'mcs' }, },
    },
    entry_filter = warlock_only,
    display_filter = warlock_displayfilter,
  },

  WARLOCK_CB = {
    columns = { { categories = { 'buffs', 'debuffs', 'support' }, }, },
    entry_filter = warlock_only,
  },

  WARLOCK_CF = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'support' }, },
      { categories = { 'ccs', 'mcs', 'miscs' }, },
    },
    entry_filter = warlock_only,
  },

  WARLOCK_P = {
    columns = { { categories = { 'warlockpetabilities' }, }, }
  },

  WARRIOR_B = {
    columns = { { categories = { 'buffs', 'debuffs', 'support' }, }, },
    entry_filter = warrior_only,
  },

  WARRIOR_F = {
    columns = {
      { categories = { 'buffs', 'debuffs', 'support' }, },
      { categories = { 'mcs', 'miscs' }, },
    },
    entry_filter = warrior_only,
  },

}
-- End of RC.lists.definitions


-- Creates suitable "personal mode" entries for the specified class.
--
-- class - The class whose brief/full lists to link to the generic
--   personal mode entries.
function RC.lists.cfg_class (class)
  local defs = RC.lists.definitions
  defs.personal_brief = defs[class.."_B"]
  defs.personal_full = defs[class.."_F"]
end


-- Returns the config values for the standard list selector.
function RC.lists.cfg_std_values ()
  local list = {
    default = L.LIST_RAIDLEADER_FULL,
    brief = L.LIST_RAIDLEADER_BRIEF,
    personal_brief = L.LIST_PERSONAL_BRIEF,
    personal_full = L.LIST_PERSONAL_FULL,
  }
  return list
end


-- Returns the config values for the advanced list selector.
function RC.lists.cfg_adv_values ()
  local defs = RC.lists.definitions
  local list = {}
  local classes = { 'DEATHKNIGHT', 'DRUID', 'HUNTER', 'MAGE', 'MONK', 'PALADIN', 'PRIEST', 'ROGUE', 'SHAMAN', 'WARLOCK', 'WARRIOR' }
  local listtypes = { "_B", "_F", "_P", "_CB", "_CF" }
  for _,class in ipairs (classes) do
    for _,listtype in ipairs (listtypes) do
      local listname = class..listtype
      if defs[listname] then list[listname] = L[class]..L["LISTSUFFIX"..listtype] end
    end
  end
  return list
end


-- Returns the maximum required width of the cardinality field.
--
-- The cardinality field is the space to the right of an entry where the
-- number of providers is shown.
--
-- For efficiency reasons this function only computes this value once,
-- and caches the result (in RC.lists.cardinality_field_width).
-- 
-- fontstring - Optional. If provided, the font settings from it will
--   be used to recalculate the field width. Only provide if/when you
--   really want to recalculate the field width.
local function cardinality_field_width (fontstring)
  -- Use the cached value if we have it
  if RC.lists.cardinality_field_width and not fontstring then
    return RC.lists.cardinality_field_width
  end

  local f = CreateFrame ('Frame', nil, UIParent)
  local temp = f:CreateFontString (nil, 'ARTWORK', 'GameFontNormal')
  if fontstring then temp:SetFont (fontstring:GetFont ()) end
  local cardinals = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'MANY' }
  local card_width = 0
  for _, v in ipairs (cardinals) do
    temp:SetText (L[v] or "")
    card_width = max (card_width, temp:GetStringWidth ())
  end
  RC.lists.cardinality_field_width = card_width
  return card_width
end


-- Creates a new UI column/frame with the given tint color.
--
-- The UI column has the following members:
--   height - The height of the column (zero initially).
--   width - The width of the column (zero initially).
--   rows - An array to hold all entries (frames) in the column (empty initially).
--
-- parent - The parent frame which will hold the UI column/frame.
-- tintcolor - An optional table with r,g,b,a members specifying backdrop color.
local function new_ui_column (parent, tintcolor)
  local uicol = CreateFrame ('Frame', nil, parent)
  local texture = uicol:CreateTexture (nil, 'BACKGROUND')
  local c = tintcolor or { r = 0, g = 0, b = 0, a = 0.05 }
  texture:SetTexture (c.r, c.g, c.b, c.a)
  texture:SetAllPoints ()
  uicol.height = 0
  uicol.width = 0
  uicol.rows = {}
  return uicol
end


-- Indentation offset for entries.
local INDENT = 6


-- Calculates the horizontal and vertical size for a column.
--
-- Suited both for initial sizing and after font size changes.
--
-- All entries in .rows are processed.
-- Takes into account the following entry members:
--   .txt
--   .num
--
-- Updates the .desired_width member on each members, as well
-- as .width and .height of the column.
--
-- Note: the column is not actually resized, but the height of
-- the entries are!
--
-- column - The column to (re)size.
local function size_column (column)
  if not column or not column.rows then return end

  local col_width = 0
  local col_height = 0
  for _,entry in ipairs (column.rows) do
    -- Horizontal
    entry:SetWidth (1000) -- Give it enough space to give us a good estimate
    entry.desired_width = INDENT + entry.txt:GetStringWidth () * 1.07 -- it seems to underestimate, so mix in a bit of fudge
    if entry.num then
      entry.desired_width = entry.desired_width + cardinality_field_width ()
    end
    entry:SetPoint ('RIGHT', column, 'RIGHT') -- Re-anchor it where it's meant to be

    -- Vertical
    local height = entry.txt:GetStringHeight ()
    entry:SetHeight (height)

    -- Running totals
    col_height = col_height + height
    col_width = max (col_width, entry.desired_width)
  end

  column.width = col_width
  column.height = col_height
end


-- Adds an entry/row/frame to a UI column/frame.
--
-- Returns the added entry/row/frame, which has the
-- following data members:
--   txt - The font string of the entry.
--
-- uicol - The UI column/frame to add the entry to.
-- text - The text to display in the entry.
-- xoffs - The X-offset to indent the text by.
-- blank_above - True if a blank row is to be inserted above the actual entry.
local function make_entry (uicol, text, xoffs, blank_above)
  if blank_above then
    make_entry (uicol, ' ', 0, false)
  end

  local e = CreateFrame ('Frame', nil, uicol)
  local txt = e:CreateFontString (nil, 'ARTWORK', 'GameFontNormal')
  txt:SetPoint ("TOPLEFT", e, "TOPLEFT")
  txt:SetPoint ("RIGHT", e, "RIGHT")
  txt:SetJustifyH ("LEFT")
  txt:SetTextColor (0.7, 0.7, 0.7, 1)
  txt:SetText (text) 

  local last_entry = uicol.rows[#uicol.rows]
  if last_entry then
    e:SetPoint ('TOP', last_entry, 'BOTTOM')
  else
    e:SetPoint ('TOP', uicol, 'TOP')
  end
  e:SetPoint ('LEFT', uicol, 'LEFT', xoffs, 0)
  e:SetPoint ('RIGHT', uicol, 'RIGHT')

  e.txt = txt

  table.insert (uicol.rows, e)
  return e
end


-- Adds a non-interactive header entry.
--
-- Updates the .height and .width members of the uicol.
-- Appends an entry to the .rows member of the uicol.
--
-- uicol - The UI column/frame to add the entry to.
-- category - The category name for which to generate the entry.
-- top_row - True if this is the first row in the column, false otherwise.
--   If it is not the first row, a blank row is inserted before the actual
--   header entry.
local function add_header (uicol, category, top_row)
  local entry = make_entry (uicol, category_names[category], 0, not top_row)
  entry.txt:SetTextColor (1, 0.82, 0, 1)
end


-- Adds an interactive entry for an ability.
--
-- Updates the .height and .width members of the uicol.
-- Appends an entry to the .rows member of the uicol.
--
-- uicol - The UI column/frame to add the entry to.
-- ability - The ability name (e.g. CRIT, DISARM).
local function add_entry (uicol, ability)
  local entry = make_entry (uicol, L[ability], INDENT, false)

  entry:EnableMouse (true)
  local hilight = entry:CreateTexture (nil, 'HIGHLIGHT')
  hilight:SetAllPoints ()
  hilight:SetTexture ("Interface\\Tooltips\\UI-Tooltip-Background")
  hilight:SetAlpha (0.3)
  hilight:SetVertexColor (1, 1, 0, 0.8)

  local num = entry:CreateFontString (nil, "ARTWORK", "GameFontNormal")
  num:SetPoint ("TOPRIGHT", entry, "TOPRIGHT")
  num:SetJustifyH ("LEFT")
  num:SetTextColor (0.7, 0.7, 0.7, 1)
  entry.num = num

  entry.tag = ability
end


-- Default-filter if none specified for a list
local function filter_accept_all (entry, category)
  return true
end


-- Creates the columns for a given list name.
--
-- listname - The name of the list for which to build the UI columns.
-- parent - The parent frame.
local function create_columns (listname, parent)
  local ret = {} -- array of created columns
  local def = RC.lists.definitions[listname]
  if not def then return ret end

  -- First get a filtered view of the data table
  local include = def.entry_filter or filter_accept_all
  local filtered_entries = {}
  for _,entry in ipairs (RCData.table) do
    if include (entry) then
      table.insert (filtered_entries, entry)
    end
  end

  -- Filter function to determine whether an entry will be
  -- displayed under a given category.
  local display = def.display_filter or filter_accept_all

  -- Add the columns in order
  for _,col in ipairs (def.columns) do
    local uicol = new_ui_column (parent, col.backdroptint)
    local top_row = true
    -- Add the categories in order
    for _,category in ipairs (col.categories) do
      add_header (uicol, category, top_row)
      top_row = false
      -- Add the abilities in the order specified by the category,
      -- provided the ability has not been filtered out by display_filter.
      for _,ability in ipairs (RCData[category]) do
        local add = false
        for _,entry in ipairs (filtered_entries) do
          if entry.a == ability and display (entry, category) then
            add = true
            break
          end
        end
        if add then add_entry (uicol, ability) end
      end
    end
    -- Column now prepared, add it to the list to return
    table.insert (ret, uicol)

    size_column (uicol)
  end
  
  -- Hint that this should get garbage collected...
  filtered_entries = nil

  return ret
end



-- Border inset constant
local INSET = 5


-- Loads the specified list into the given frame.
-- Removes any pre-existing columns from the frame.
--
-- The loaded entries do not have any mouse handlers attached,
-- nor are the entries cached into RC.entries.
--
-- Updates frame.columns, which is guaranteed to hold a table
-- on return from this call (though possibly an empty one).
--
-- listname - The name of the list to load.
-- frame - The list frame to load into.
function RC.lists.load (listname, frame)
  -- Remove any existing columns
  if frame.columns then
    for _,col in ipairs (frame.columns) do
      col:Hide()
      col:ClearAllPoints()
    end
    frame.columns = nil
  end

  -- Install the new columns
  local max_height = 0
  local width = 0
  local cols = create_columns (listname, frame) or {}
  for i,col in ipairs (cols) do
    if i == 1 then
      col:SetPoint ('TOPLEFT', frame, 'TOPLEFT', INSET, -INSET)
    else
      col:SetPoint ('TOPLEFT', cols[i-1], 'TOPRIGHT')
    end
    col:SetPoint ('BOTTOM', frame, 'BOTTOM')
    max_height = max (max_height, col.height)
    width = width + col.width
  end
  frame:SetHeight (max_height + 3 * INSET)
  frame:SetWidth (width + 2 * INSET)
  frame.columns = cols
end


-- Resizes the given list frame and its contents.
-- Typically used after a font size change.
--
-- frame - The list frame to resize.
function RC.lists.resize (frame)
  -- Recalculate the cardinality field width to ensure we resize properly
  if frame and frame.columns and frame.columns[1] and frame.columns[1].rows and frame.columns[1].rows[1] then
    cardinality_field_width (frame.columns[1].rows[1].txt)
  end

  local width = 0
  local max_height = 0
  for _,col in ipairs (frame.columns) do
    size_column (col)
    col:SetWidth (col.width)
    col:SetHeight (col.height)
    width = width + col.width
    max_height = max (max_height, col.height)
  end
  frame:SetWidth (width + 2 * INSET)
  frame:SetHeight (max_height + 3 * INSET)
end


