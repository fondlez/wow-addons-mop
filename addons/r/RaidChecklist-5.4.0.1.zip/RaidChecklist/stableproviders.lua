-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8
local RC = RaidChecklist
local RCData = RaidChecklistData

if not RC then return end

RC.stableproviders = RCData:create_provider_table ()

-- We only run the stable provider code if the player is a hunter
local _, player_class = UnitClass ("player")
if player_class ~= "HUNTER" then return end

RaidChecklistPetCache = {}

-- Create a couple of smaller tables to avoid having to scan the full ability table all the time
local family_abilities = {}
for _, pet in pairs (RaidChecklistPetFamilies) do family_abilities[pet] = {} end
for _, entry in ipairs (RCData.table) do
  if entry.p then table.insert (family_abilities[entry.p], entry.a) end
end


-- plevel = 2 ("could be provided") or nil
local function update_stableprovider (ability, plevel)
  local guid = UnitGUID("player")
  if not guid then print("no guid in update") return end
  for key, guidlist in pairs (RC.stableproviders) do
    if key == ability then
      guidlist[guid] = plevel
    end
  end
  if (RC.OnRefresh) then RC:OnRefresh () end
end


local function clear_stableprovider ()
  local guid = UnitGUID("player")
  if not guid then print("no guid in clear") return end
  for key, guidlist in pairs (RC.stableproviders) do
    RC.stableproviders[key][guid] = nil
  end
end


local function on_cache_update ()
  clear_stableprovider ()
  for i = 1, 5 do
    local family = RaidChecklistPetCache[i]
    if family then
      local abilities_list = family_abilities[family] or {}
      for idx, ability in ipairs (abilities_list) do
        update_stableprovider (ability, 2) -- "could be provided"
      end
    end
  end
end


local stable_check = function ()
  for i = 1, 5 do -- Slots 1-5 are the Call Pet slots, actual stable slots start at 6
    _, _, _, family, _ = GetStablePetInfo (i)
    RaidChecklistPetCache[i] = family
  end
  on_cache_update ()
end


local RCB = RaidChecklist.button
RCB.PET_STABLE_SHOW = stable_check
RCB.PET_STABLE_UPDATE = stable_check
RCB.PLAYER_ENTERING_WORLD = on_cache_update

RCB:RegisterEvent("PET_STABLE_SHOW")
RCB:RegisterEvent("PET_STABLE_UPDATE")
RCB:RegisterEvent("PLAYER_ENTERING_WORLD")
