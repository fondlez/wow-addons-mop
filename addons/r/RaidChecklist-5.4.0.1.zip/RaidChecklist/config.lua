-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8
local ADDONNAME = ...
local RC = RaidChecklist

if not RC then return end

local L = RaidChecklistStrings
local NAME = L["Raid Checklist"]
local CfgHandler = {}

function CfgHandler:GetVal (info)
    local varname = info[#info]
    return RaidChecklist.db.profile[varname]
end

function CfgHandler:SetVal (info, v)
    local varname = info[#info]
    RaidChecklist.db.profile[varname] = v
    if RaidChecklist.OnConfigChange then
      RaidChecklist:OnConfigChange ()
    end
end

function CfgHandler:SetStdList (info, v)
  RaidChecklist.db.profile.advlist = nil
  self:SetVal (info, v)
end

function CfgHandler:SetAdvList (info, v)
  RaidChecklist.db.profile.stdlist = nil
  self:SetVal (info, v)
end


local config = {
  type = 'group',
  handler = CfgHandler,
  get = "GetVal", set = "SetVal",
  args = {
    about = {
      type = 'group',
      name = L.ABOUT,
      args = {
        ver = { type = 'description', name = GetAddOnMetadata("RaidChecklist", "Version"), order = 10 },
        hdr = { type = 'header', name = "Proudly brought to you by", order = 20 },
        by = { type = 'description', name = "\nAnyia of HordeYakka (Jubei'Thos) - Design, coding and research\n\n\n", order = 30 },
        hdr2 = { type = 'header', name = "With special thanks to", order = 40 },
        thanks = { type = 'description', name = "Kalliope (@ Petopia) - My muse, assistant and main tester for the 5.0.4 release\n\nAkycha (@ Petopia) - Alpha testing of the 5.0.4 release\n\nMalazee (@ Petopia) - Historical research, ability compilation, and list design\n\n\n", order = 50 },
        hdr3 = { type = 'header', name = "Current language pack provided by", order = 60 },
        translations = { type = 'description', name = L.TRANSLATORS, order = 70 },
      },
    },

    general = {
      type = 'group',
      name = L.CONFIG,
      args = {
        anchor_locked = {
          type = 'toggle', 
          name = L.ANCHORLOCKED,
          desc = L.ANCHORLOCKEDDESC,
          order = 50
        },
        show_anchor = {
          type = 'toggle',
          name = L.SHOWANCHOR,
          desc = L.SHOWANCHORDESC,
          order = 60
        },
        open_direction = {
          type = 'select',
          name = L.OPENDIRECTION,
          desc = L.OPENDIRECTIONDESC,
          values = { DOWNRIGHT = L.DOWNRIGHT, DOWNLEFT = L.DOWNLEFT, UPRIGHT = L.UPRIGHT, UPLEFT = L.UPLEFT },
          order = 100
        },
        reset_anchor = {
          type = 'execute',
          name = L.RESETANCHOR,
          desc = L.RESETANCHORDESC,
          func = function ()
            RaidChecklist.button:ClearAllPoints ()
            RaidChecklist.button:SetPoint ("CENTER", 0, 0)
            RaidChecklist.db.profile.xoffs = 0
            RaidChecklist.db.profile.yoffs = 0
          end,
          order = 120
        },
        details_side = {
          type = 'select',
          name = L.DETAILSSIDE,
          desc = L.DETAILSSIDEDESC,
          values = { RIGHT = L.RIGHT, LEFT = L.LEFT },
          order = 130
        },
        font_size = {
          type = 'select',
          name = L.FONTSIZE,
          desc = L.FONTSIZEDESC,
          values = { normal = L.NORMAL, small = L.SMALL },
          order = 150
        },
        opacity = {
          type = 'range',
          min = 0.0,
          max = 1.0,
          step = 0.05,
          name = L.OPACITY,
          desc = L.OPACITYDESC,
          order = 160
        },
        spacer = { type = 'description', name = "", order = 300 },
        stdlist = {
          type = 'select',
          name = L.STDLIST,
          desc = L.STDLISTDESC,
          -- values is filled in on PLAYER_LOGIN
          order = 350,
          set = "SetStdList"
        },
        advlist = {
          type = 'select',
          name = L.ADVLIST,
          desc = L.ADVLISTDESC,
          -- values is filled in on PLAYER_LOGIN
          order = 351,
          set = "SetAdvList"
        },
        hdr2 = { type = 'description', name = L.FILTERGROUPS, order = 401 },
        group1 = { type = 'toggle', name = L.GROUP.." 1", order = 411 },
        group2 = { type = 'toggle', name = L.GROUP.." 2", order = 412 },
        group3 = { type = 'toggle', name = L.GROUP.." 3", order = 413 },
        group4 = { type = 'toggle', name = L.GROUP.." 4", order = 414 },
        group5 = { type = 'toggle', name = L.GROUP.." 5", order = 415 },
        group6 = { type = 'toggle', name = L.GROUP.." 6", order = 416 },
        group7 = { type = 'toggle', name = L.GROUP.." 7", order = 417 },
        group8 = { type = 'toggle', name = L.GROUP.." 8", order = 418 },
      }
    },

    help = {
      type = 'group',
      name = L.HELP,
      args = {
        introhdr      = { type = 'header',      name = L.HELP_INTRO_HDR,      order = 20 },
        intro         = { type = 'description', name = L.HELP_INTRO,          order = 21 },
        colorshdr     = { type = 'header',      name = L.HELP_COLORS_HDR,     order = 30 },
        colors        = { type = 'description', name = L.HELP_COLORS,         order = 31 },
        flaghdr       = { type = 'header',      name = L.HELP_FLAG_HDR,       order = 40 },
        flag          = { type = 'description', name = L.HELP_FLAG,           order = 41 },
        hunterpetshdr = { type = 'header',      name = L.HELP_HUNTERPETS_HDR, order = 50 },
        hunterpets    = { type = 'description', name = L.HELP_HUNTERPETS,     order = 51 },
        linkinghdr    = { type = 'header',      name = L.HELP_LINKING_HDR,    order = 60 },
        linking       = { type = 'description', name = L.HELP_LINKING,        order = 61 },
        commandshdr   = { type = 'header',      name = L.HELP_COMMANDS_HDR,   order = 70 },
        commands      = { type = 'description', name = L.HELP_COMMANDS,       order = 71 },
        talentscanhdr = { type = 'header',      name = L.HELP_TALENTSCAN_HDR, order = 80 },
        talentscan    = { type = 'description', name = L.HELP_TALENTSCAN,     order = 81 },
        incombathdr   = { type = 'header',      name = L.HELP_INCOMBAT_HDR,   order = 90 },
        incombat      = { type = 'description', name = L.HELP_INCOMBAT,       order = 91 },
      },
    }
  }
}

RaidChecklist.dbdefaults = {
  profile = {
    show_anchor = true,
    anchor_locked = false,
    open_direction = "DOWNRIGHT",
    font_size = "normal",
    details_side = "RIGHT",
    anchorpoint = "CENTER",
    relpoint = "CENTER",
    x = 0,
    y = 0,
    opacity = 0.75,
    group1 = true,
    group2 = true,
    group3 = true,
    group4 = true,
    group5 = true,
    group6 = false,
    group7 = false,
    group8 = false,
  }
}


RC.button.ADDON_LOADED = function (self, name)
  if name == ADDONNAME then
    RC.db = LibStub ("AceDB-3.0"):New ("RaidChecklistDB2", RaidChecklist.dbdefaults, true)
    LibStub ("AceConfigRegistry-3.0"):RegisterOptionsTable (NAME, config)
    config.args.profiles = LibStub ("AceDBOptions-3.0"):GetOptionsTable (RaidChecklist.db)

    RC.cfgdlg = LibStub ("AceConfigDialog-3.0")
    RC.cfgdlg:AddToBlizOptions (NAME, nil, nil, "about")
    RC.settings_panel = RC.cfgdlg:AddToBlizOptions (NAME, L.SETTINGS, NAME, "general")
    RC.cfgdlg:AddToBlizOptions (NAME, L.PROFILES, NAME, "profiles")
    RC.cfgdlg:AddToBlizOptions (NAME, L.HELP, NAME, "help")

    if RaidChecklistDB then -- old-style config, migrate it
      for k,v in pairs (RaidChecklistDB.profile) do RC.db.profile[k] = v end
      RaidChecklistDB = nil
    end

    -- Translate old hunter pet mode to new advanced hunter pets-only list
    if RC.db.profile.hunterpet_mode then
      RC.db.profile.hunterpet_mode = nil
      RC.db.profile.advlist = 'HUNTER_P'
    elseif not RC.db.profile.stdlist and not RC.db.profile.advlist then
      RC.db.profile.stdlist = 'default'
    end

    RC.db.RegisterCallback (RC, "OnProfileChanged", "OnConfigChange")
    RC.db.RegisterCallback (RC, "OnProfileCopied", "OnConfigChange")
    RC.db.RegisterCallback (RC, "OnProfileReset", "OnConfigChange")

    RC:OnConfigChange ()
    self:UnregisterEvent ("ADDON_LOADED")
  end
end
RC.button:RegisterEvent ("ADDON_LOADED")


RC.button.PLAYER_LOGIN = function (self)
  local _, classfile = UnitClass ("player")
  RC.lists.cfg_class (classfile)
  -- Personal mode lists just made available, fire a config change
  RC:OnConfigChange ()

  config.args.general.args.stdlist.values = RC.lists.cfg_std_values ()
  config.args.general.args.advlist.values = RC.lists.cfg_adv_values ()
end
RC.button:RegisterEvent ("PLAYER_LOGIN")


