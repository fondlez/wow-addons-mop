-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

local RC = RaidChecklist
local RCData = RaidChecklistData

if not RC then return end

-- Pull in the localized strings
local L = RaidChecklistStrings
local P = RaidChecklistPetFamilies

-- Keybinding
BINDING_NAME_RAIDCHECKLIST_TOGGLE = L.RAIDCHECKLIST_TOGGLE
BINDING_HEADER_RAIDCHECKLIST = L["Raid Checklist"]

-- Inset constant
local INSET = 5


-- Initial setup code, can be discarded once everything's been initialized.
do

  -- Convenience function to line up a frame into a parent, with insets
  local function align_with_insets (alignto, f)
    f:ClearAllPoints ()
    f:SetPoint ("TOPLEFT", alignto, "TOPLEFT", INSET, -INSET)
    f:SetPoint ("BOTTOMRIGHT", alignto, "BOTTOMRIGHT", -INSET, INSET)
  end

  -- Creates a frame with a typical dialog box border
  --
  -- Also creates a background texture for the frame, available as the
  -- .texture member.
  --
  -- parent - The parent/owner frame.
  -- name - The name of the new frame.
  --
  -- Returns the new frame.
  local function make_bordered_frame (parent, name)
    local f = CreateFrame ("Frame", name, parent)
    f:SetBackdrop ({
      edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
      edgeSize = 16,
      insets= { left = INSET, right = INSET, top = INSET, bottom = INSET }
    })
    f.texture = f:CreateTexture (nil, "BACKGROUND")
    f.texture:SetTexture (0, 0, 0, 0.75)
    align_with_insets (f, f.texture)
    return f
  end


  -- The button for anchoring and accessing the checklist
  RC.button = CreateFrame ("Button", nil, UIParent)
  RC.button:SetNormalTexture ("Interface\\AddOns\\RaidChecklist\\Textures\\button")
  RC.button:SetHighlightTexture ("Interface\\AddOns\\RaidChecklist\\Textures\\button")
  RC.button:SetPoint ("CENTER", 0, 0)
  RC.button:SetWidth (24)
  RC.button:SetHeight (24)
  RC.button:SetMovable (true)
  RC.button:SetUserPlaced (true)
  RC.button:SetClampedToScreen (true)
  RC.button.OnClick = function (self, button)
    if button == "RightButton" then
      InterfaceOptionsFrame_OpenToCategory (RC.settings_panel)
    else
      if RC.list:IsVisible () then
        RC.list:Hide ()
      else
        RC.list:Show ()
      end
    end
  end
  RC.button:SetScript ("OnClick", RC.button.OnClick)
  RC.button:RegisterForClicks ("LeftButtonUp", "RightButtonUp")
  RC.button:SetScript ("OnEvent", function (self, event, ...)
    if self[event] then
      self[event] (self, ...)
    end
  end)


  -- The main list frame
  RC.list = make_bordered_frame (UIParent, "RaidChecklistList")
  RC.list:SetPoint ("TOPLEFT", RC.button, "BOTTOMLEFT", 0, 0)
  RC.list:Hide ()

  -- Rescan button, attached to the list frame
  RC.list.rescanbtn = CreateFrame ("Button", nil, RC.list)
  RC.list.rescanbtn:SetPoint ("TOPRIGHT", RC.list, "TOPRIGHT", -INSET, -INSET)
  RC.list.rescanbtn:SetNormalTexture ("Interface\\AddOns\\RaidChecklist\\Textures\\rescan")
  RC.list.rescanbtn:SetHighlightTexture ("Interface\\AddOns\\RaidChecklist\\Textures\\rescan")
  RC.list.rescanbtn:SetScript ("OnClick", function () RC.is:Rescan () RC:UpdateMissing() RC:OnRefresh () end)
  RC.list.rescanbtn:SetScript ("OnEnter", function ()
    GameTooltip:SetOwner (RC.list, "ANCHOR_RIGHT", 0, 0)
    GameTooltip:SetText (L.RESCAN)
    GameTooltip:AddLine (L.RESCANHELP, 0.7, 0.7, 0.7, 1)
    GameTooltip:Show ()
  end)
  RC.list.rescanbtn:SetScript ("OnLeave", function () GameTooltip:Hide () end)
  RC.list.rescanbtn:Show ()

  -- The "haven't yet seen talents for" frame
  RC.missing = make_bordered_frame (RC.list, "RaidChecklistMissing")
  RC.missing:SetPoint ("TOPLEFT", RC.list, "BOTTOMLEFT")
  RC.missing:SetPoint ("RIGHT", RC.list, "RIGHT")
  RC.missing.hdr = RC.missing:CreateFontString (nil, "ARTWORK", "GameFontNormal")
  RC.missing.hdr:SetPoint ("TOPLEFT", RC.missing, "TOPLEFT", INSET, -INSET)
  RC.missing.hdr:SetPoint ("RIGHT", RC.missing, "RIGHT", -INSET, 0)
  RC.missing.hdr:SetText (L.MISSINGTALENTS)
  RC.missing.txt = RC.missing:CreateFontString (nil, "ARTWORK", "GameFontNormal")
  RC.missing.txt:SetPoint ("TOPLEFT", RC.missing.hdr, "BOTTOMLEFT", INSET, 0)
  RC.missing.txt:SetPoint ("RIGHT", RC.missing.hdr, "RIGHT")
  RC.missing.txt:SetWordWrap (true)
  RC.missing.txt:SetTextColor (0.7, 0.7, 0.7, 1)
  RC.missing:SetScript ("OnEnter", function ()
    GameTooltip:SetOwner (RC.missing, "ANCHOR_RIGHT", 0, -RC.missing:GetHeight ())
    GameTooltip:SetText (L.INSPECTQUEUE)
    GameTooltip:AddLine (string.gsub (RC.missing_talents_for or "", ",", "\n"), 0.7, 0.7, 0.7, 1)
    if RC.missing.nowinspecting then
      GameTooltip:AddLine (L.NOWINSPECTING)
      GameTooltip:AddLine (RC.missing.nowinspecting, 0.7, 0.7, 0.7, 1)
    end
    GameTooltip:Show ()
  end)
  RC.missing:SetScript ("OnLeave", function () GameTooltip:Hide () end)
  RC.missing:Hide ()

  -- Inspection-in-progress notification
  RC.missing.inspecting = CreateFrame ("Frame", nil, RC.missing)
  RC.missing.inspecting:SetPoint ("TOPLEFT", RC.missing.hdr, "TOPLEFT")
  RC.missing.inspecting:SetSize (12, 12)
  RC.missing.inspecting.texture = RC.missing.inspecting:CreateTexture (nil, "ARTWORK")
  RC.missing.inspecting.texture:SetTexture ("Interface\\AddOns\\RaidChecklist\\Textures\\light")
  RC.missing.inspecting.texture:SetAllPoints ()
  RC.missing.inspecting:Hide ()
  RC.missing.inspecting:SetScript ("OnEvent", function (self, event, ...)
    if self[event] then
      self[event] (self, ...)
    end
  end)
  RC.missing.inspecting.INSPECT_READY = function (self)
    self:Hide ()
    RC.missing.nowinspecting = nil
  end
  RC.missing.inspecting:RegisterEvent ("INSPECT_READY")
  hooksecurefunc("NotifyInspect", function (unit)
    RC.missing.inspecting:Show ()
    RC.missing.nowinspecting = UnitName (unit)
  end)


  -- Details frame
  RC.detailshdr = make_bordered_frame (RC.list)
  RC.detailshdr:SetPoint ("TOPLEFT", RC.list, "TOPRIGHT")
  RC.detailshdr.txt = RC.detailshdr:CreateFontString (nil, "ARTWORK", "GameFontNormal")
  align_with_insets (RC.detailshdr, RC.detailshdr.txt)
  RC.detailshdr.txt:SetTextColor (1.0, 1.0, 1.0)
  RC.detailshdr:SetHeight (2*INSET + 22)
  RC.detailshdr:Hide ()
  RC.detailshdr.closebtn = CreateFrame ("Button", nil, RC.detailshdr, "UIPanelCloseButton")
  RC.detailshdr.closebtn:SetPoint ("TOPRIGHT", RC.detailshdr, "TOPRIGHT")
  RC.details = make_bordered_frame (RC.detailshdr)
  RC.details.hdr = RC.detailshdr
  RC.details.bottom_anchor = RC.list
  RC.details:SetPoint ("TOPLEFT", RC.detailshdr, "BOTTOMLEFT")
  RC.details:SetPoint ("RIGHT", RC.detailshdr, "RIGHT")
  RC.details:SetPoint ("BOTTOM", RC.list, "BOTTOM")
  -- We use a fontstring for size calculations, as the SimpleHTML doesn't provide that
  RC.details.txt = RC.details:CreateFontString (nil, "ARTWORK", "GameFontNormal")
  RC.details.display = CreateFrame ("SimpleHTML", nil, RC.details)
  RC.details.display:SetFontObject ("GameFontNormal")
  RC.details.display:SetScript ("OnHyperlinkClick", ChatFrame_OnHyperlinkShow)
  RC.details.display:SetPoint ("TOPLEFT", RC.details, "TOPLEFT", INSET, -INSET)
  RC.details.display:SetPoint ("RIGHT", RC.details, "RIGHT", -INSET, 0)
  RC.details.display:SetPoint ("BOTTOM", RC.details, "BOTTOM", 0, INSET)
  RC.details.display:SetJustifyV ("TOP")
  RC.details.display:SetJustifyH ("LEFT")
  RC.details:EnableMouse (true)
end


-- Creates a string embedding the spell icon for the given spell id.
--
-- id - The id of the spell whose icon to embed.
local function GetSpellIconEscape (id)
  local _, _, t = GetSpellInfo (id)
  return "|T"..(t or "Interface\\Icons\\INV_Misc_QuestionMark")..":0|t"
end


-- Creates a hyperlink for the given talent id.
--
-- id - The id of the talent.
local function GetTalentLink (id)
  local n = GetSpellInfo (id)
  return n and "|cff71d5ff|Hspell:"..id.."|h["..n.."]|h|r" or "|cffff0000?|r"
end


-- The text strings for the details pane are generated only when/if needed,
-- and then cached for future reuse.
local DetailedAbilityInfo = {}
setmetatable (DetailedAbilityInfo, { __index = function (table, key)
  local s = L.DETAILS.."\n"
  for _, entry in ipairs (RCData.table) do
    if entry.a == key then
      s = s.."\n "
      local id
      if entry.t then id = entry.t end
      if entry.i then id = entry.i end
      local icon = GetSpellIconEscape (id)
      if icon then s = s..icon.." " end

      s = s..(entry.c or entry.display) -- Cater for entry.e which has custom entry.display
      if entry.i then s = s.." "..GetTalentLink (entry.i) end -- GetSpellLink doesn't work with specialization skills (e.g. Mangle), so create our own links instead
      if entry.g then s = s.." "..GetTalentLink (entry.g) end -- GetSpellLink doesn't work with glyphs?
      if entry.t then s = s.." "..GetTalentLink (entry.t).." "..L.TALENT end
      if entry.p then s = s..","..L.PET..entry.p end
      if entry.l then s = s..", "..L.LEVEL.." "..entry.l end
      if entry.s then s = s.." "..entry.s end
      if entry.e then s = s..", "..L.RACIAL end
    end
  end
  rawset (table, key, s)
  return s
end })


-- Updates the details pane to show information for a given ability.
--
-- If the details pane is not tall enough to accommodate the full text,
-- it is reanchored at an offset to expand it sufficiently.
-- The calculation for this uses the "scratch" FontString self.txt, which
-- must be set to the correct font size for the resizing to work properly.
--
-- tag - The ability to display the details for.
function RC.details:ShowAbility (tag)
  self.hdr.txt:SetText (L[tag])
  local s = DetailedAbilityInfo[tag]
  self.display:SetText (s)
  self.current = tag
  self.txt:SetText (s)
  local width = self.txt:GetStringWidth () * 1.06 + INSET*2
  self.hdr:SetWidth (width)
  local height = self.txt:GetHeight ()

  -- Reanchor at alignment, then see if we need to override that
  self:SetPoint ('BOTTOM', self.bottom_anchor, 'BOTTOM')
  -- Force a size recalculation of self.display
  self:Hide()
  self:Show()
  -- See whether we need to expand the frame
  local current_height = self.display:GetHeight ()
  if height > current_height then
    local yoffs = height - current_height
    self:SetPoint ('BOTTOM', self.bottom_anchor, 'BOTTOM', 0, -yoffs)
  end
  self.hdr:Show ()
end


-- FIXME: this is ugly as...
local function merge_providers ()
  local all = {}
  for k,v in pairs (RC.providers) do
    all[k] = {}
    for guid, plevel in pairs (v) do
      all[k][guid] = plevel
    end
  end
  for k,v in pairs (RC.petproviders) do
    for guid, plevel in pairs (v) do
      if plevel > (all[k][guid] or -1) then
        all[k][guid] = plevel
      end
    end
  end
  for k,v in pairs (RC.stableproviders) do
    for guid, plevel in pairs (v) do
      if plevel > (all[k][guid] or -1) then
        all[k][guid] = plevel
      end
    end
  end
  return all
end
RC.merge_providers = merge_providers


-- We only generate the "available from" strings if they're actually used
local availablefrom = {}
setmetatable (availablefrom, {
  __index = function (table, tag)
    local s
    local last
    local NL = "\n "
    for _, entry in ipairs (RCData.table) do
      if entry.a == tag and last ~= entry.display then
        s = ((s and s..NL) or " ")..entry.display
        last = entry.display
      end
    end
    rawset (table, tag, s)
    return s
  end
})

-- Prepares and displays the tooltip for a given list entry.
--
-- entry - The list entry (row in a list column) to provide a tooltip for.
local function do_tooltip (entry)
  GameTooltip:SetOwner (entry, "ANCHOR_RIGHT", 0, -entry:GetHeight ())
  GameTooltip:SetText (L[entry.tag], 1, 1, 1, 1)
  GameTooltip:AddLine (L.AVAILABLEFROM)
  GameTooltip:AddLine (availablefrom[entry.tag])
  GameTooltip:AddLine ("\n"..L.PROVIDEDBY, 1, 0.82, 0, 1)
  local guidlist = merge_providers ()[entry.tag]
  if not next (guidlist) then
    GameTooltip:AddLine (" "..L.NOBODY, 0.7, 0.7, 0.7, 1)
  else
    local names
    for guid,_ in pairs (guidlist) do
      if names then names = names.."\n " else names = " " end
      names = names..(RC.provider_names[guid] or ("<missing name for "..guid..">"))
      local unit = RC.is:GuidToUnit (guid)
      if unit and not UnitIsConnected (unit) then
        names = names.."|cffff0000 "..L.OFFLINE
      end
    end
    GameTooltip:AddLine (names, 1, 1, 1, 1)
  end
  GameTooltip:Show ()
end


-- Hides the GameTooltip.
local function hide_tooltip ()
  GameTooltip:Hide ()
end


-- Toggles the details pane.
--
-- entry - The entry that has been activated. If this entry is already
--   being displayed, the details pane is hidden. If the pane is hidden
--   or this entry is different from what is currently displayed, the
--   details for this entry is shown in the details pane.
--   Reads entry.tag to determine which ability is under consideration.
local function toggle_details (entry)
  local details = RC.details
  if details:IsVisible () and details.current == entry.tag then
    details.hdr:Hide ()
  else
    details:ShowAbility (entry.tag)
  end
end


-- Hooks up the mouse handling scripts for the entries in a UI column/frame.
--
-- uicol - The UI column/frame.
local function attach_mouse_handling (uicol)
  for _,entry in ipairs (uicol.rows) do
    if entry:IsMouseEnabled() then
      entry:SetScript ('OnEnter', do_tooltip)
      entry:SetScript ('OnLeave', hide_tooltip)
      entry:SetScript ('OnMouseDown', toggle_details)
    end
  end
end


-- Sets the font size used by all the RCL frames.
--
-- size - Either 'normal' or 'small'
function RC:set_font_size(size)
  if not self.entries then return end -- No list initialised yet

  local normal = 'normal'
  local small = 'small'
  if size ~= normal and size ~= small then return end

  local current_entry = next (self.entries)
  if not current_entry then return end -- Huh? An empty list!

  -- Only change things if the setting is different from what we have
  -- XXX: Assumes 'normal' == 12 and 'small' == 10.
  local fontfile, fontsize = self.entries[current_entry].txt:GetFont ()
  if (fontsize < 11 and size == normal) or (fontsize > 11 and size == small) then
    if size == normal then
      fontsize = 12
    elseif size == small then
      fontsize = 10
    end

    for _,col in ipairs (self.list.columns) do
      for _,entry in ipairs (col.rows) do
        entry.txt:SetFont (fontfile, fontsize)
        if entry.num then
          entry.num:SetFont (fontfile, fontsize)
        end
      end
    end
  end

  -- Resize as necessary
  self.lists.resize (self.list)

  -- Rescan button should always fit into the top row in the column
  self.list.rescanbtn:SetHeight (fontsize)
  self.list.rescanbtn:SetWidth (fontsize)

  -- We have to treat the non-list frames separately, as they do not revert their
  -- fontsize whenever the list is switched, and we'd end up over-growing/shrinking
  -- the details frame otherwise.
  fontfile, fontsize = self.detailshdr.txt:GetFont ()
  if (fontsize < 11 and size == normal) or (fontsize > 11 and size == small) then
    local grow = size == normal
    if size == normal then
      fontsize = 12
    elseif size == small then
      fontsize = 10
    end

    self.detailshdr.txt:SetFont (fontfile, fontsize)
    self.details.txt:SetFont (fontfile, fontsize)
    self.details.display:SetFont (fontfile, fontsize)
    self.missing.txt:SetFont (fontfile, fontsize)

    -- Do horizontal resizing of the details header (which controls the details width)
    if grow then
      self.detailshdr:SetWidth (self.detailshdr:GetWidth () * 1.2)
    else
      self.detailshdr:SetWidth (self.detailshdr:GetWidth () / 1.2)
    end
  end
end


-- Switches the list frame to use a (possibly) different list.
--
-- RC.entries is reloaded with the entries from the new list and
-- the entries refreshed.
--
-- listname - The name of the list to switch to.
function RC:switch_list(listname)
  self.lists.load (listname, self.list)
  self.entries = {}
  for _,col in ipairs (self.list.columns) do
    attach_mouse_handling (col)
    -- Hook up status updates
    for _,e in ipairs (col.rows) do
      if e.tag then
        self.entries[e.tag] = e
      end
    end
  end
  self:set_font_size (RC.db.profile.font_size)
  self:OnRefresh()
  -- If we don't hide the details panel, we'd have to carefully reanchor it...
  self.details.hdr:Hide()
end


-- Calculates the effective provider level of a GUID.
--
-- Takes into account whether the unit is online/offline, and
-- whether the unit has been filtered by the group filter.
--
-- Returns an integer representing the effective provider level:
--   0 = missing,
--   1 = offline,
--   2 = filtered/could-be-provided,
--   3 = provided
local providerlevel4guid = function (guid, plevel)
  local db = RC.db
  local level = plevel
  local unit = RC.is:GuidToUnit (guid)
  if unit and level > 0 then
    local israid, _, idx = string.find (unit, "raid(%d+)")
    if israid then
      local group = "group"..select(3, GetRaidRosterInfo (idx))
      if not db.profile[group] then
        level = 2
      end
      group = nil
    end
    if not UnitIsConnected (unit) then
      level = 1
    end
  else
    level = 0
  end
  return level
end


-- Calculates the top provider level from a GUID->level map.
--
-- guidlist - A map of GUID->level entries.
--
-- Returns:
--   highest provider level found in the list,
--   total count of entries in the list,
--   flag whether the list includes the player (true if so)
local providerlevel = function (guidlist)
  local highestlevel = 0
  local count = 0
  local playerprovided = false
  for guid, plevel in pairs (guidlist) do
    local level = providerlevel4guid (guid, plevel)
    if level > highestlevel then highestlevel = level end
    count = count + 1
    if RC.is:GuidToUnit (guid) == "player" then
      playerprovided = true
    end
  end
  return highestlevel, count, playerprovided
end


-- Updates the color on each of the buff entries in the list.
--
-- Also updates the display of not-yet-performed talent scans.
function RC:OnRefresh ()
  local all = self.merge_providers ()
  local colors = {
    [0] = { r = 0.7, g = 0.7, b = 0.7 },
    [1] = { r = 0.7, g = 0.0, b = 0.0 },
    [2] = { r = 0.0, g = 0.4, b = 1.0 },
    [3] = { r = 0.0, g = 1.0, b = 0.0 }
  }
  for key,guidlist in pairs (all) do
    if self.entries[key] then
      local plevel, count, playerprovided = providerlevel (guidlist)
      local c = colors[plevel]
      self.entries[key].txt:SetTextColor (c.r, c.g, c.b, 1)
      self.entries[key].num:SetTextColor (c.r, c.g, c.b, 1)
      -- Handle non-arabic numerals (in theory at least) by translating 0-9,"MANY"
      local cardinal = L[count]
      if count > 9 then cardinal = L["MANY"] end
      -- Flag (literally) abilities that only the player provides
      if count == 1 and playerprovided then
        local flagcolor
        if plevel == 3 then
          flagcolor = "green"
        else
          flagcolor = "blue"
        end
        cardinal = "|TInterface\\AddOns\\RaidChecklist\\Textures\\"..flagcolor.."flag:0|t"
      end
      self.entries[key].num:SetText (cardinal)
    end
  end
  all = nil

  -- Show players we haven't seen talents for yet, if there are any
  if self.missing_talents_for then
    self.missing.txt:SetText (string.gsub (self.missing_talents_for, ",", ", "))
    self.missing:SetHeight (self.missing.hdr:GetHeight () * 2 + self.missing.txt:GetHeight ())
    self.missing:Show ()
  else
    self.missing:Hide ()
  end
end


-- Callback to handle configuration changes.
function RC:OnConfigChange ()
  local db = RC.db

  self:switch_list (db.profile.stdlist or db.profile.advlist or 'default')
  self:set_font_size (db.profile.font_size)

  if db.profile.show_anchor then
    self.button:Show ()
  else
    self.button:Hide ()
  end

  if db.profile.anchor_locked then
    self.button:SetScript ("OnMouseDown", nil)
    self.button:SetScript ("OnMouseUp", nil)
  else
    self.button:SetScript ("OnMouseDown", function (f) f:StartMoving () end)
    self.button:SetScript ("OnMouseUp", function (f)
      f:StopMovingOrSizing ()
      db.profile.anchorpoint, _, db.profile.relpoint, db.profile.x, db.profile.y = f:GetPoint (1)
    end)
  end

  self.list:ClearAllPoints ()
  self.missing:ClearAllPoints ()
  self.missing:SetPoint ("RIGHT", self.list, "RIGHT")
  local dir = db.profile.open_direction
  if dir == "DOWNRIGHT" then
    self.list:SetPoint ("TOPLEFT", self.button, "BOTTOMLEFT", 0, 0)
    self.missing:SetPoint ("TOPLEFT", self.list, "BOTTOMLEFT")
  elseif dir == "DOWNLEFT" then
    self.list:SetPoint ("TOPRIGHT", self.button, "BOTTOMRIGHT", 0, 0)
    self.missing:SetPoint ("TOPLEFT", self.list, "BOTTOMLEFT")
  elseif dir == "UPRIGHT" then
    self.list:SetPoint ("BOTTOMLEFT", self.button, "TOPLEFT", 0, 0)
    self.missing:SetPoint ("BOTTOMLEFT", self.list, "TOPLEFT")
  else -- UPLEFT
    self.list:SetPoint ("BOTTOMRIGHT", self.button, "TOPRIGHT", 0, 0)
    self.missing:SetPoint ("BOTTOMLEFT", self.list, "TOPLEFT")
  end

  self.detailshdr:ClearAllPoints ()
  if db.profile.details_side == "RIGHT" then
    self.detailshdr:SetPoint ("TOPLEFT", self.list, "TOPRIGHT")
  else
    self.detailshdr:SetPoint ("TOPRIGHT", self.list, "TOPLEFT")
  end

  self.button:ClearAllPoints ()
  self.button:SetPoint (db.profile.anchorpoint, UIParent, db.profile.relpoint, db.profile.x, db.profile.y)


  frames = { self.list, self.missing, self.detailshdr, self.details }
  for _, frame in ipairs (frames) do
    frame.texture:SetTexture (0, 0, 0, db.profile.opacity);
  end

  self:OnRefresh () -- In case the filtered groups changed
end


-- Enable /rcl and /raidchecklist for toggling the checklist
SlashCmdList.RAIDCHECKLIST = function ()
  if RC.list:IsVisible () then
    RC.list:Hide ()
  else
    RC.list:Show ()
  end
end
SLASH_RAIDCHECKLIST1 = "/rcl"
SLASH_RAIDCHECKLIST2 = "/raidchecklist"

