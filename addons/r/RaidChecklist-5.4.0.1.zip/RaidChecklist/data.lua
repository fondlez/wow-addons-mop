-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

if not RaidChecklist then return end

local L = RaidChecklistStrings
local P = RaidChecklistPetFamilies

RaidChecklistData = {}
local data = RaidChecklistData

--
-- Primary ability categories
--
data.buffs = {
  "CRIT", "ATTACKPWR", "PHYSHASTE",
  "SPELLPWR", "SPELLHASTE",
  "STATS", "STAM", "MASTERY",
}

data.debuffs = {
  "PHYSDMGTAKEN", "SPELLDMGTAKEN",
  "CASTSPD", "WEAKBLOWS",
  "SUNDER", "MORTALSTRIKE",
}

data.support = {
 "BURSTMANA", "BLOODLUST", "COMBATRES", "BURSTMAGICPROT"
}

data.dispels = {
  "OFFMAGIC", "DEFMAGIC",
  "DISEASE", "POISON",
  "CURSE", "ENRAGE"
}

data.ccs = {
  "CCBEASTS", "CCDEMONS", "CCDRAGONKIN", "CCELEMENTALS", "CCGIANTS", "CCHUMANOIDS", "CCUNDEAD", "CCANY",
  "FEARBEASTS", "FEARUNDEAD", "FEARANY"
}

data.mcs = {
  "KNOCKBACK", "SNARE", "AOESNARE", "ROOT", "STUN", "AOESTUN"
}

data.miscs = {
  "INTERRUPT", "INTERRUPT2", "DISARM"
}


--
-- Secondary ability categories.
--
-- All abilities in these categories here are already covered by the primary categories.
-- These groupings exist purely for display groupings.
--

data.hunterpetabilities = {
  "CRIT", "STATS", "STAM", "SPELLPWR", "SPELLHASTE", "PHYSHASTE", "MASTERY", "BLOODLUST", "COMBATRES",
  "PHYSDMGTAKEN", "SPELLDMGTAKEN", "CASTSPD", "WEAKBLOWS", "SUNDER", "MORTALSTRIKE",
  "INTERRUPT", "INTERRUPT2", "DISARM", "STUN"
}

data.warlockpetabilities = {
  "MANA", "MANAREGEN",
  "MORTALSTRIKE",
  "CCHUMANOIDS",
  "KNOCKBACK", "INTERRUPT"
}

data.totemsall = {
  "AOESNARE",
  "SPELLPWR",
  "MANAREGEN",
  "PHYSHASTE", "SPELLHASTE",
}


-- Race/class combos
L.BLOODELF_ROGUE   = L.BLOODELF.." "..L.ROGUE.."|r"
local SEP = "|r/"
L.BLOODELF_CASTER  = L.BLOODELF.." "..L.MAGE..SEP..L.PALADIN..SEP..L.PRIEST..SEP..L.WARLOCK.."|r"
L.BLOODELF_WARRIOR = L.BLOODELF.." "..L.WARRIOR.."|r"
L.BLOODELF_DEATHKNIGHT = L.BLOODELF.." "..L.DEATHKNIGHT.."|r"
L.BLOODELF_HUNTER = L.BLOODELF.." "..L.HUNTER.."|r"
L.BLOODELF_MONK = L.BLOODELF.." "..L.MONK.."|r"
L.RACIAL = select (2, GetSpellInfo (25046))


-- Abuse the metatable functionality in order to make sure any abilities referenced by the providers actually exists.
local ability_typo_checker = { __index = function (table, key)
  for i,b in ipairs (table) do
    if b == key then return key end
  end
  print ("|cffff0000>> RaidChecklist: unknown ability name: |r"..(key or "nil"))
end
}
setmetatable (data.buffs, ability_typo_checker)
setmetatable (data.debuffs, ability_typo_checker)
setmetatable (data.support, ability_typo_checker)
setmetatable (data.dispels, ability_typo_checker)
setmetatable (data.ccs, ability_typo_checker)
setmetatable (data.mcs, ability_typo_checker)
setmetatable (data.miscs, ability_typo_checker)

-- Convenience function to create a "provider" table
data.create_provider_table = function (self)
  local t = {}
  for i,b in ipairs (self.buffs)   do t[b] = {} end
  for i,b in ipairs (self.debuffs) do t[b] = {} end
  for i,b in ipairs (self.support) do t[b] = {} end
  for i,b in ipairs (self.dispels) do t[b] = {} end
  for i,b in ipairs (self.ccs)     do t[b] = {} end
  for i,b in ipairs (self.mcs)     do t[b] = {} end
  for i,b in ipairs (self.miscs)   do t[b] = {} end
  return t
end


--
-- Core ability table.
--

local B = data.buffs
local D = data.debuffs
local T = data.support
local S = data.dispels
local C = data.ccs
local O = data.mcs
local M = data.miscs

local R = { BLOODELF = "BloodElf" } -- "Filename" from UnitRace(), locale-independent

local SPEC = " "
local NOTE = "*" -- Indicates a talent which is accessible regardless of talent spec

-- Legend:
--   a - Ability
--   c - Class (localized)
--   s - Spec name (localized)
--   p - Pet family (localized)
--   l - Level requirement
--   t - Talent spell ID
--   n - Talent name, automatically looked up from 'i'
--   i - Spell/ability ID
--   e - Race-specific ability
--   g - glyph-id (ability, not create-glyph spell)
--   v - true if passive ability
--   display - Text to display for this entry
data.table = {
  { a = S.CURSE,          c = L.DRUID,        s = L.BALANCE,                          l = 24,                i = 2782                                                                   },
  { a = S.CURSE,          c = L.DRUID,        s = L.RESTODRUID,                                              i = 88423                                                                  },
  { a = S.CURSE,          c = L.MAGE,                                                 l = 30,                i = 475                                                                    },
  { a = S.CURSE,          c = L.SHAMAN,                                               l = 18,                i = 51886                                                                  },

  { a = S.DISEASE,        c = L.MONK,                                                 l = 20,                i = 115450                                                                 },
  { a = S.DISEASE,        c = L.PALADIN,                                              l = 34,                i = 4987                                                                   },
  { a = S.DISEASE,        c = L.PRIEST,       s = L.HOLYPRIEST,                       l = 22,                i = 527                                                                    },
  { a = S.DISEASE,        c = L.PRIEST,       s = L.DISCIPLINE,                       l = 22,                i = 527                                                                    },

  { a = S.ENRAGE,         c = L.DRUID,        s = L.BALANCE,                          l = 28,                i = 2908                                                                   },
  { a = S.ENRAGE,         c = L.DRUID,        s = L.RESTODRUID,                       l = 28,                i = 2908                                                                   },
  { a = S.ENRAGE,         c = L.HUNTER,                                               l = 35,                i = 19801                                                                  },
  { a = S.ENRAGE,         c = L.ROGUE,                                                l = 70,                i = 5938                                                                   },

  { a = S.DEFMAGIC,       c = L.DRUID,        s = L.RESTODRUID,                                              i = 88423                                                                  },
  { a = S.DEFMAGIC,       c = L.MONK,         s = L.MISTWEAVER,                       l = 20,                i = 115451                                                                 },
  { a = S.DEFMAGIC,       c = L.PALADIN,      s = L.HOLYPALADIN,                                             i = 53551                                                                  },
  { a = S.DEFMAGIC,       c = L.PRIEST,       s = L.HOLYPRIEST,                       l = 26,                i = 527                                                                    },
  { a = S.DEFMAGIC,       c = L.PRIEST,       s = L.DISCIPLINE,                       l = 26,                i = 527                                                                    },
  { a = S.DEFMAGIC,       c = L.PRIEST,                                               l = 72,                i = 32375                                                                  },
  { a = S.DEFMAGIC,       c = L.SHAMAN,       s = L.RESTOSHAMAN,                                             i = 77130                                                                  },
  { a = S.DEFMAGIC,       c = L.WARLOCK,                          p = P.FELHOUND,                            i = 103136                                                                 },
  { a = S.DEFMAGIC,       c = L.WARLOCK,                          p = P.FELIMP,                 t = 108499,  i = 115276                                                                 },--Talentpet
  { a = S.DEFMAGIC,       c = L.WARLOCK,                          p = P.OBSERVER,               t = 108499,  i = 115284                                                                 },--Talentpet

  { a = S.OFFMAGIC,       c = L.DEATHKNIGHT,                                                                                                                          g = 58631         },
  { a = S.OFFMAGIC,       c = L.HUNTER,                                               l = 35,                i = 19801                                                                  },
  { a = S.OFFMAGIC,       c = L.MAGE,                                                 l = 64,                i = 30449                                                                  },
  { a = S.OFFMAGIC,       c = L.PRIEST,                                               l = 26,                i = 528                                                                    },
  { a = S.OFFMAGIC,       c = L.PRIEST,                                               l = 72,                i = 32375                                                                  },
  { a = S.OFFMAGIC,       c = L.SHAMAN,                                               l = 12,                i = 370                                                                    },
  { a = S.OFFMAGIC,       c = L.WARRIOR,      s = L.PROTWARRIOR,                                                                                                      g = 58375         },

  { a = S.POISON,         c = L.DRUID,        s = L.BALANCE,                          l = 24,                i = 2782                                                                   },
  { a = S.POISON,         c = L.DRUID,        s = L.RESTODRUID,                                              i = 88423                                                                  },
  { a = S.POISON,         c = L.MONK,                                                 l = 20,                i = 115450                                                                 },
  { a = S.POISON,         c = L.PALADIN,                                              l = 18,                i = 4987                                                                   },

  { a = B.STAM,           c = L.HUNTER,       s = L.BEASTMASTER,  p = P.SILITHID,                            i = 90364                                                                  },
  { a = B.STAM,           c = L.PRIEST,                                               l = 22,                i = 21562                                                                  },
  { a = B.STAM,           c = L.WARLOCK,                                              l = 82,                i = 109773                                                                 },
  { a = B.STAM,           c = L.WARRIOR,                                              l = 68,                i = 469                                                                    },

  { a = T.BLOODLUST,      c = L.HUNTER,       s = L.BEASTMASTER,  p = P.COREHOUND,                           i = 90355                                                                  },
  { a = T.BLOODLUST,      c = L.MAGE,                                                 l = 85,                i = 80353                                                                  },
  { a = T.BLOODLUST,      c = L.SHAMAN,                                               l = 70,                i = 2825                                                                   },
  { a = T.BLOODLUST,      c = L.SHAMAN,                                               l = 70,                i = 32182                                                                  },

  { a = T.BURSTMANA,      c = L.DRUID,        s = L.BALANCE,                          l = 54,                i = 29166                                                                  },
  { a = T.BURSTMANA,      c = L.DRUID,        s = L.RESTODRUID,                       l = 54,                i = 29166                                                                  },
  { a = T.BURSTMANA,      c = L.PRIEST,                                               l = 64,                i = 64904                                                                  },
  { a = T.BURSTMANA,      c = L.SHAMAN,       s = L.RESTOSHAMAN,                      l = 56,                i = 16190                                                                  },

  { a = T.COMBATRES,      c = L.DEATHKNIGHT,                                          l = 72,                i = 61999                                                                  },
  { a = T.COMBATRES,      c = L.DRUID,                                                l = 56,                i = 20484                                                                  },
  { a = T.COMBATRES,      c = L.HUNTER,       s = L.BEASTMASTER,  p = P.QUILEN,                              i = 126393                                                                 },
  { a = T.COMBATRES,      c = L.WARLOCK,                                              l = 18,                i = 20707                                                                  },

  { a = T.BURSTMAGICPROT, c = L.DEATHKNIGHT,                                                    t = 51052                                                                               },
  { a = T.BURSTMAGICPROT, c = L.MONK,                                                 l = 82,                i = 115176                                                                 },
  { a = T.BURSTMAGICPROT, c = L.WARRIOR,                                                        t = 114028                                                                              },

  { a = B.ATTACKPWR,      c = L.DEATHKNIGHT,                                          l = 65,                i = 57330                                                                  },
  { a = B.ATTACKPWR,      c = L.HUNTER,                                               l = 39,                i = 19506,             v = true                                            },
  { a = B.ATTACKPWR,      c = L.WARRIOR,                                              l = 42,                i = 6673                                                                   },

  { a = B.CRIT,           c = L.DRUID,        s = L.FERAL,                            l = 46,                i = 17007,             v = true                                            },
  { a = B.CRIT,           c = L.DRUID,        s = L.GUARDIAN,                         l = 46,                i = 17007,             v = true                                            },
  { a = B.CRIT,           c = L.HUNTER,                           p = P.HYDRA,                               i = 97229                                                                  },
  { a = B.CRIT,           c = L.HUNTER,                           p = P.WOLF,                                i = 24604                                                                  },
  { a = B.CRIT,           c = L.HUNTER,       s = L.BEASTMASTER,  p = P.DEVILSAUR,                           i = 90309                                                                  },
  { a = B.CRIT,           c = L.HUNTER,       s = L.BEASTMASTER,  p = P.QUILEN,                              i = 126373                                                                 },
  { a = B.CRIT,           c = L.HUNTER,       s = L.BEASTMASTER,  p = P.WATERSTRIDER,                        i = 126309,            v = true                                            },
  { a = B.CRIT,           c = L.MAGE,                                                 l = 58,                i = 1459                                                                   },
  { a = B.CRIT,           c = L.MONK,         s = L.WINDWALKER,                       l = 81,                i = 116781                                                                 },

  { a = B.PHYSHASTE,      c = L.DEATHKNIGHT,  s = L.FROSTDK,                          l = 60,                i = 55610,             v = true                                            },
  { a = B.PHYSHASTE,      c = L.DEATHKNIGHT,  s = L.UNHOLY,                           l = 60,                i = 55610,             v = true                                            },
  { a = B.PHYSHASTE,      c = L.HUNTER,                           p = P.HYENA,                               i = 128432                                                                 },
  { a = B.PHYSHASTE,      c = L.HUNTER,                           p = P.SERPENT,                             i = 128433                                                                 },
  { a = B.PHYSHASTE,      c = L.ROGUE,                                                l = 30,                i = 113742,            v = true                                            },
  { a = B.PHYSHASTE,      c = L.SHAMAN,       s = L.ENHANCEMENT,                      l = 55,                i = 30809,             v = true                                            },

  { a = B.SPELLHASTE,     c = L.DRUID,        s = L.BALANCE,                          l = 16,                i = 24858                                                                  },
  { a = B.SPELLHASTE,     c = L.HUNTER,                           p = P.SPOREBAT,                            i = 135678,                                                                },
  { a = B.SPELLHASTE,     c = L.PRIEST,       s = L.SHADOW,                           l = 24,                i = 15473,             v = true                                            },
  { a = B.SPELLHASTE,     c = L.SHAMAN,       s = L.ELEMENTAL,                        l = 55,                i = 51470,             v = true                                            },

  { a = B.SPELLPWR,       c = L.MAGE,                                                 l = 58,                i = 1459                                                                   },
  { a = B.SPELLPWR,       c = L.SHAMAN,                                               l = 40,                i = 77747,             v = true                                            },
  { a = B.SPELLPWR,       c = L.WARLOCK,                                              l = 82,                i = 109773                                                                 },
  { a = B.SPELLPWR,       c = L.HUNTER,       s = L.BEASTMASTER,  p = P.WATERSTRIDER,                        i = 126309,            v = true                                            },

  { a = B.STATS,          c = L.DRUID,                                                l = 62,                i = 1126                                                                   },
  { a = B.STATS,          c = L.HUNTER,       s = L.BEASTMASTER,  p = P.SHALESPIDER,                         i = 90363                                                                  },
  { a = B.STATS,          c = L.MONK,                                                 l = 22,                i = 115921                                                                 },
  { a = B.STATS,          c = L.PALADIN,                                              l = 30,                i = 20217                                                                  },

  { a = B.MASTERY,        c = L.PALADIN,                                              l = 81,                i = 19740                                                                  },
  { a = B.MASTERY,        c = L.SHAMAN,                                               l = 80,                i = 116956,            v = true                                            },
  { a = B.MASTERY,        c = L.HUNTER,                           p = P.CAT,          l = 81,                i = 93435                                                                  },
  { a = B.MASTERY,        c = L.HUNTER,       s = L.BEASTMASTER,  p = P.SPIRITBEAST,  l = 81,                i = 128997                                                                 },

  { a = M.DISARM,         c = L.HUNTER,                           p = P.SCORPID,                             i = 50541                                                                  },
  { a = M.DISARM,         c = L.HUNTER,                           p = P.BIRDOFPREY,                          i = 91644                                                                  },
  { a = M.DISARM,         c = L.PRIEST,       s = L.SHADOW,                                                  i = 64044                                                                  },
  { a = M.DISARM,         c = L.ROGUE,                                                l = 38,                i = 51722                                                                  },
  { a = M.DISARM,         c = L.WARRIOR,                                              l = 34,                i = 676                                                                    },
  { a = M.DISARM,         c = L.WARLOCK,                          p = P.VOIDLORD,               t = 108499,  i = 124539                                                                 },--Talentpet

  { a = C.FEARBEASTS,     c = L.HUNTER,                                               l = 36,                i = 1513                                                                   },
  { a = C.FEARBEASTS,     c = L.PALADIN,                                                        t = 110301                                                                              },
  { a = C.FEARUNDEAD,     c = L.PALADIN,                                              l = 78,                i = 10326                                                                  }, -- Note: also included Demons!
  { a = C.FEARANY,        c = L.PRIEST,                                                         t = 108921                                                                              },
  { a = C.FEARANY,        c = L.WARLOCK,                                              l = 14,                i = 5782                                                                   },
  { a = C.FEARANY,        c = L.WARLOCK,                                                        t = 111397                                                                              },
  { a = C.FEARANY,        c = L.WARLOCK,                                              l = 30,                i = 5484                                                                   },

  { a = M.INTERRUPT,      c = L.DEATHKNIGHT,                                          l = 57,                i = 47528                                                                  },
  { a = M.INTERRUPT,      c = L.DRUID,        s = L.FERAL,                            l = 22,                i = 106839                                                                 }, -- 106839 = lvl64, 80964/80965 = lvl22
  { a = M.INTERRUPT,      c = L.DRUID,        s = L.GUARDIAN,                                                                                                         g = 114237        },
  { a = M.INTERRUPT,      c = L.HUNTER,                           p = P.GORILLA,                             i = 26090                                                                  },
  { a = M.INTERRUPT,      c = L.HUNTER,                                               l = 22,                i = 147362                                                                 },
--  { a = M.INTERRUPT,      c = L.HUNTER,       s = L.MARKSMAN,                                                i = 34490                                                                  },
  { a = M.INTERRUPT,      c = L.MAGE,                                                 l = 9,                 i = 2139                                                                   },
  { a = M.INTERRUPT,      c = L.MAGE,                                                           t = 102051                                                                              },
  { a = M.INTERRUPT,      c = L.MONK,                                                 l = 32,                i = 116705                                                                 },
  { a = M.INTERRUPT,      c = L.PALADIN,                                              l = 54,                i = 96231                                                                  },
  { a = M.INTERRUPT,      c = L.PALADIN,      s = L.PROTPALADIN,                                             i = 31935                                                                  },
  { a = M.INTERRUPT,      c = L.ROGUE,                                                l = 14,                i = 1766                                                                   },
  { a = M.INTERRUPT,      c = L.SHAMAN,                                               l = 16,                i = 57994                                                                  },
  { a = M.INTERRUPT,      c = L.WARLOCK,      s = L.DEMONOLOGY,                                              i = 103967                                                                 },
  { a = M.INTERRUPT,      c = L.WARLOCK,                          p = P.FELHUNTER,                           i = 19647                                                                  },
  { a = M.INTERRUPT,      c = L.WARLOCK,                          p = P.OBSERVER,               t = 108499,  i = 115781                                                                 },--Talentpet
  { a = M.INTERRUPT,      c = L.WARRIOR,                                              l = 38,                i = 6552                                                                   },

  { a = M.INTERRUPT2,     c = L.DEATHKNIGHT,                                          l = 59,                i = 47476                                                                  },
  { a = M.INTERRUPT2,     c = L.DEATHKNIGHT,                                                    t = 108194                                                                              },
  { a = M.INTERRUPT2,     c = L.DRUID,        s = L.BALANCE,                                                 i = 78675                                                                  },
  { a = M.INTERRUPT2,     c = L.PRIEST,       s = L.SHADOW,                                                  i = 15487                                                                  },
  { a = M.INTERRUPT2,     c = L.HUNTER,                           p = P.NETHERRAY,                           i = 50479                                                                  },
  { a = M.INTERRUPT2,     c = L.HUNTER,                           p = P.MOTH,                                i = 50318                                                                  },

  { a = M.INTERRUPT2,                                                                                        i = 25046,             display = L.BLOODELF_ROGUE,                         e = R.BLOODELF },
  { a = M.INTERRUPT2,                                                                                        i = 28730,             display = L.BLOODELF_CASTER,                        e = R.BLOODELF },
  { a = M.INTERRUPT2,                                                                                        i = 50613,             display = L.BLOODELF_DEATHKNIGHT,                   e = R.BLOODELF },
  { a = M.INTERRUPT2,                                                                                        i = 69179,             display = L.BLOODELF_WARRIOR,                       e = R.BLOODELF },
  { a = M.INTERRUPT2,                                                                                        i = 80483,             display = L.BLOODELF_HUNTER,                        e = R.BLOODELF },
  { a = M.INTERRUPT2,                                                                                        i = 129597,            display = L.BLOODELF_MONK,                          e = R.BLOODELF },
  { a = M.INTERRUPT2,     c = L.WARRIOR,                                                        t = 102060                                                                              },

  { a = C.CCBEASTS,       c = L.DRUID,        s = L.BALANCE,                          l = 48,                i = 2637                                                                   },
  { a = C.CCBEASTS,       c = L.DRUID,        s = L.RESTODRUID,                       l = 48,                i = 2637                                                                   },
  { a = C.CCDRAGONKIN,    c = L.DRUID,        s = L.BALANCE,                          l = 48,                i = 2637                                                                   },
  { a = C.CCDRAGONKIN,    c = L.DRUID,        s = L.RESTODRUID,                       l = 48,                i = 2637                                                                   },

  { a = C.CCBEASTS,       c = L.MAGE,                                                 l = 14,                i = 118                                                                    },
  { a = C.CCHUMANOIDS,    c = L.MAGE,                                                 l = 14,                i = 118                                                                    },

  { a = C.CCDEMONS,       c = L.PALADIN,      s = L.RETRIBUTION,                                             i = 20066                                                                  },
  { a = C.CCDRAGONKIN,    c = L.PALADIN,      s = L.RETRIBUTION,                                             i = 20066                                                                  },
  { a = C.CCGIANTS,       c = L.PALADIN,      s = L.RETRIBUTION,                                             i = 20066                                                                  },
  { a = C.CCHUMANOIDS,    c = L.PALADIN,      s = L.RETRIBUTION,                                             i = 20066                                                                  },
  { a = C.CCUNDEAD,       c = L.PALADIN,      s = L.RETRIBUTION,                                             i = 20066                                                                  },
  { a = C.CCUNDEAD,       c = L.WARLOCK,                          p = P.SHIVARRA,               t = 108499,  i = 115268                                                                 },--Talentpet

  { a = C.CCUNDEAD,       c = L.PRIEST,                                               l = 32,                i = 9484                                                                   },
  { a = C.CCHUMANOIDS,    c = L.PRIEST,                                               l = 38,                i = 605                                                                    },

  { a = C.CCBEASTS,       c = L.ROGUE,                                                l = 10,                i = 6770                                                                   },
  { a = C.CCDEMONS,       c = L.ROGUE,                                                l = 10,                i = 6770                                                                   },
  { a = C.CCDRAGONKIN,    c = L.ROGUE,                                                l = 10,                i = 6770                                                                   },
  { a = C.CCHUMANOIDS,    c = L.ROGUE,                                                l = 10,                i = 6770                                                                   },

  { a = C.CCELEMENTALS,   c = L.SHAMAN,                                               l = 64,                i = 76780                                                                  },

  { a = C.CCBEASTS,       c = L.SHAMAN,                                               l = 80,                i = 51514                                                                  },
  { a = C.CCHUMANOIDS,    c = L.SHAMAN,                                               l = 80,                i = 51514                                                                  },

  { a = C.CCBEASTS,       c = L.WARLOCK,                          p = P.SHIVARRA,               t = 108499,  i = 115268                                                                 },--Talentpet
  { a = C.CCDEMONS,       c = L.WARLOCK,                                              l = 32,                i = 710                                                                    },
  { a = C.CCDEMONS,       c = L.WARLOCK,                                              l = 30,                i = 1098                                                                   },
  { a = C.CCDRAGONKIN,    c = L.WARLOCK,                          p = P.SHIVARRA,               t = 108499,  i = 115268                                                                 },--Talentpet
  { a = C.CCGIANTS,       c = L.WARLOCK,                          p = P.SHIVARRA,               t = 108499,  i = 115268                                                                 },--Talentpet
  { a = C.CCELEMENTALS,   c = L.WARLOCK,                                              l = 32,                i = 710                                                                    },
  { a = C.CCHUMANOIDS,    c = L.WARLOCK,                          p = P.SUCCUBUS,                            i = 6358                                                                   },
  { a = C.CCHUMANOIDS,    c = L.WARLOCK,                          p = P.SHIVARRA,               t = 108499,  i = 115268                                                                 },--Talentpet

  { a = C.CCANY,          c = L.HUNTER,                                               l = 28,                i = 1499                                                                   },
  { a = C.CCANY,          c = L.HUNTER,                                                         t = 19386                                                                               },

  { a = O.ROOT,           c = L.DRUID,        s = L.BALANCE,                          l = 8,                 i = 339                                                                    },
  { a = O.ROOT,           c = L.DRUID,        s = L.RESTODRUID,                       l = 8,                 i = 339                                                                    },

  { a = O.SNARE,          c = L.DEATHKNIGHT,                                          l = 58,                i = 45524                                                                  },
  { a = O.SNARE,          c = L.DRUID,                                                          t = 106707                                                                              },
  { a = O.SNARE,          c = L.HUNTER,                                               l = 8,                 i = 5116                                                                   },
  { a = O.SNARE,          c = L.MAGE,                                                 l = 4,                 i = 116                                                                    },
  { a = O.SNARE,          c = L.MAGE,         s = L.ARCANE,                           l = 36,                i = 31589                                                                  },
  { a = O.SNARE,          c = L.MAGE,         s = L.ARCANE,                                                                                                           g = 86209         },
  { a = O.SNARE,          c = L.PRIEST,       s = L.SHADOW,                                                  i = 15407                                                                  },
  { a = O.SNARE,          c = L.ROGUE,                                                l = 20,                i = 3408                                                                   },
  { a = O.SNARE,          c = L.ROGUE,                                                                                                                                g = 56820         },
  { a = O.SNARE,          c = L.ROGUE,                                                                                                                                g = 56802         },
  { a = O.SNARE,          c = L.SHAMAN,                                               l = 22,                i = 8056                                                                   }, -- Frostshock!
  { a = O.SNARE,          c = L.WARLOCK,      s = L.AFFLICTION,                       l = 32,                i = 18223                                                                  },
  { a = O.SNARE,          c = L.WARRIOR,                                              l = 36,                i = 1715                                                                   },

  { a = O.AOESNARE,       c = L.DRUID,                                                                                                                                g = 54831         },
  { a = O.AOESNARE,       c = L.DRUID,        s = L.BALANCE,                          l = 84,                i = 78777                                                                  },
  { a = O.AOESNARE,       c = L.HUNTER,                                               l = 46,                i = 13809                                                                  },
  { a = O.AOESNARE,       c = L.HUNTER,       s = L.MARKSMAN,                         l = 30,                i = 35102                                                                  },
  { a = O.AOESNARE,       c = L.MONK,         s = L.BREWMASTER,                       l = 10,                i = 115180                                                                 },
  { a = O.AOESNARE,       c = L.WARLOCK,      s = L.DEMONOLOGY,                       l = 19,                i = 105174                                                                 },
  { a = O.AOESNARE,       c = L.WARRIOR,                                                        t = 12323                                                                               },

  { a = O.STUN,           c = L.DEATHKNIGHT,                                                    t = 108194                                                                              },
  { a = O.STUN,           c = L.DRUID,                                                          t = 5211                                                                                },
  { a = O.STUN,           c = L.HUNTER,                           p = P.BAT,                                 i = 50519                                                                  },
  { a = O.STUN,           c = L.HUNTER,                           p = P.PORCUPINE,                           i = 126355                                                                 },
  { a = O.STUN,           c = L.HUNTER,                           p = P.SHALESPIDER,                         i = 96201                                                                  },
  { a = O.STUN,           c = L.HUNTER,                           p = P.WASP,                                i = 56626                                                                  },
  { a = O.STUN,           c = L.PALADIN,                                              l = 7,                 i = 853                                                                    },
  { a = O.STUN,           c = L.PALADIN,                                                        t = 105593                                                                              },
  { a = O.STUN,           c = L.ROGUE,                                                l = 30,                i = 1833                                                                   },
  { a = O.STUN,           c = L.ROGUE,                                                l = 40,                i = 408                                                                    },
  { a = O.STUN,           c = L.WARRIOR,                                              l = 90,                i = 107570                                                                 },

  { a = O.AOESTUN,        c = L.DEATHKNIGHT,                                                    t = 108200                                                                              },
  { a = O.AOESTUN,        c = L.HUNTER,                                               l = 30,                i = 109248                                                                 },
  { a = O.AOESTUN,        c = L.MAGE,                                                 l = 45,                i = 113724                                                                 },
  { a = O.AOESTUN,        c = L.MONK,                                                           t = 119392                                                                              },
  { a = O.AOESTUN,        c = L.MONK,                                                           t = 119381                                                                              },
  { a = O.AOESTUN,        c = L.SHAMAN,                                               l = 63,                i = 108269                                                                 },
  { a = O.AOESTUN,        c = L.WARLOCK,                                                        t = 30283                                                                               },
  { a = O.AOESTUN,        c = L.WARRIOR,                                                        t = 46968                                                                               },

  { a = D.SUNDER,         c = L.DRUID,                                                l = 24,                i = 770                                                                    },
  { a = D.SUNDER,         c = L.HUNTER,                           p = P.TALLSTRIDER,                         i = 50285                                                                  },
  { a = D.SUNDER,         c = L.HUNTER,                           p = P.RAPTOR,                              i = 50498                                                                  },
  { a = D.SUNDER,         c = L.ROGUE,                                                l = 36,                i = 8647                                                                   },
  { a = D.SUNDER,         c = L.ROGUE,                                                                                                                                g = 56803         },
  { a = D.SUNDER,         c = L.WARRIOR,      s = L.ARMS,                                                                                                             g = 89003         },
  { a = D.SUNDER,         c = L.WARRIOR,      s = L.FURY,                                                                                                             g = 89003         },
  { a = D.SUNDER,         c = L.WARRIOR,      s = L.PROTWARRIOR,                      l = 18,                i = 7386                                                                   },

  { a = D.PHYSDMGTAKEN,   c = L.DEATHKNIGHT,  s = L.FROSTDK,                          l = 66,                i = 81328                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.DEATHKNIGHT,  s = L.UNHOLY,                           l = 68,                i = 51160                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.HUNTER,                           p = P.BOAR,                                i = 35290                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.HUNTER,                           p = P.RAVAGER,                             i = 50518                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.HUNTER,       s = L.BEASTMASTER,  p = P.RHINO,                               i = 57386                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.HUNTER,       s = L.BEASTMASTER,  p = P.WORM,                                i = 55749                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.PALADIN,      s = L.RETRIBUTION,                      l = 28,                i = 111529                                                                 },
  { a = D.PHYSDMGTAKEN,   c = L.WARRIOR,      s = L.ARMS,                             l = 81,                i = 86346                                                                  },
  { a = D.PHYSDMGTAKEN,   c = L.WARRIOR,      s = L.FURY,                             l = 81,                i = 86346                                                                  },

  { a = D.SPELLDMGTAKEN,  c = L.HUNTER,                           p = P.DRAGONHAWK,                          i = 34889                                                                  },
  { a = D.SPELLDMGTAKEN,  c = L.HUNTER,                           p = P.WINDSERPENT,                         i = 24844                                                                  },
  { a = D.SPELLDMGTAKEN,  c = L.ROGUE,                                                l = 64,                i = 58410                                                                  },
  { a = D.SPELLDMGTAKEN,  c = L.WARLOCK,                                              l = 52,                i = 1490                                                                   },

  { a = D.WEAKBLOWS,      c = L.DEATHKNIGHT,  s = L.BLOOD,                            l = 68,                i = 81132                                                                  },
  { a = D.WEAKBLOWS,      c = L.DRUID,        s = L.FERAL,                            l = 28,                i = 106830                                                                 },
  { a = D.WEAKBLOWS,      c = L.DRUID,        s = L.GUARDIAN,                         l = 28,                i = 77758                                                                  },
  { a = D.WEAKBLOWS,      c = L.HUNTER,                           p = P.BEAR,                                i = 50256                                                                  },
  { a = D.WEAKBLOWS,      c = L.HUNTER,                           p = P.CARRIONBIRD,                         i = 24423                                                                  },
  { a = D.WEAKBLOWS,      c = L.MONK,         s = L.BREWMASTER,                       l = 11,                i = 121253                                                                 },
  { a = D.WEAKBLOWS,      c = L.PALADIN,      s = L.PROTPALADIN,                      l = 20,                i = 53595                                                                  },
  { a = D.WEAKBLOWS,      c = L.PALADIN,      s = L.RETRIBUTION,                      l = 20,                i = 53595                                                                  },
  { a = D.WEAKBLOWS,      c = L.PALADIN,                                              l = 1,                 i = 35395                                                                  },
  { a = D.WEAKBLOWS,      c = L.ROGUE,                                                          t = 108210                                                                              },
  { a = D.WEAKBLOWS,      c = L.SHAMAN,                                               l = 5,                 i = 8042                                                                   },
  { a = D.WEAKBLOWS,      c = L.WARRIOR,                                              l = 20,                i = 6343                                                                   },

  { a = D.CASTSPD,        c = L.DEATHKNIGHT,                                          l = 83,                i = 73975                                                                  },
  { a = D.CASTSPD,        c = L.HUNTER,                           p = P.SPOREBAT,                            i = 50274                                                                  },
  { a = D.CASTSPD,        c = L.HUNTER,                           p = P.FOX,                                 i = 90314                                                                  },
  { a = D.CASTSPD,        c = L.HUNTER,                           p = P.GOAT,                                i = 126402                                                                 },
  { a = D.CASTSPD,        c = L.HUNTER,       s = L.BEASTMASTER,  p = P.COREHOUND,                           i = 58604                                                                  },
  { a = D.CASTSPD,        c = L.MAGE,         s = L.ARCANE,                           l = 36,                i = 31589                                                                  },
  { a = D.CASTSPD,        c = L.ROGUE,                                                l = 28,                i = 5761                                                                   },
  { a = D.CASTSPD,        c = L.WARLOCK,                                              l = 17,                i = 109466                                                                 },

  { a = D.MORTALSTRIKE,   c = L.HUNTER,                                               l = 40,                i = 82654                                                                  },
  { a = D.MORTALSTRIKE,   c = L.HUNTER,       s = L.BEASTMASTER,  p = P.DEVILSAUR,                           i = 54680                                                                  },
  { a = D.MORTALSTRIKE,   c = L.MONK,         s = L.WINDWALKER,                       l = 56,                i = 107428                                                                 },
  { a = D.MORTALSTRIKE,   c = L.ROGUE,                                                l = 30,                i = 8679                                                                   },
  { a = D.MORTALSTRIKE,   c = L.WARRIOR,      s = L.ARMS,                             l = 10,                i = 12294                                                                  },
  { a = D.MORTALSTRIKE,   c = L.WARRIOR,      s = L.FURY,                             l = 18,                i = 100130                                                                 },
  { a = D.MORTALSTRIKE,   c = L.WARLOCK,                          p = P.FELGUARD,                            i = 30213                                                                  },
  { a = D.MORTALSTRIKE,   c = L.WARLOCK,                          p = P.WRATHGUARD,             t = 108499,  i = 115625                                                                 },--Talentpet

  { a = O.KNOCKBACK,      c = L.DRUID,                                                          t = 132469                                                                              },
  { a = O.KNOCKBACK,      c = L.HUNTER,                                                         t = 109259                                                                              },
  { a = O.KNOCKBACK,      c = L.HUNTER,                                                                                                                               g = 119403        },
  { a = O.KNOCKBACK,      c = L.SHAMAN,       s = L.ELEMENTAL,                                               i = 51490                                                                  },
  { a = O.KNOCKBACK,      c = L.WARLOCK,      s = L.DEMONOLOGY,                                              i = 103967                                                                 },
  { a = O.KNOCKBACK,      c = L.WARLOCK,                          p = P.SUCCUBUS,                            i = 6360                                                                   },
  { a = O.KNOCKBACK,      c = L.WARLOCK,                          p = P.SHIVARRA,               t = 108499,  i = 115770                                                                 },--Talentpet
}

for _, entry in ipairs (data.table) do
  -- Common display format unless overridden in the table above
  if not entry.display then 
    local disp = entry.c
    if entry.s then disp = disp..SPEC..entry.s end
    if entry.p then disp = disp..L.PET..entry.p end
    if entry.g then disp = disp..L.GLYPH end
    if entry.t then disp = disp..L.TOOLTIP_TALENT end
    if entry.v then disp = disp..L.TOOLTIP_PASSIVE end
    entry.display = disp
  end
end

