-- vim: ts=2 sw=2 ai et enc=utf8 fenc=utf8

-- Takes a non-localized class name as argument and returns the color string for said class.
-- Example:  ClassColorString( select(2,UnitClassBase("target")) )..UnitName("target").."|r"
function ClassColorString (class)
  if not RAID_CLASS_COLORS[class] then return "|cFF000000" end -- probably "Unknown"
  return string.format ("|cFF%02x%02x%02x",
     RAID_CLASS_COLORS[class].r * 255,
     RAID_CLASS_COLORS[class].g * 255,
     RAID_CLASS_COLORS[class].b * 255)
end

