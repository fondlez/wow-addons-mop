--[[
	ReceipeKnown v0.28
	English Localization File

	This file only effects the visual aspects of the Addon, not the functionality.
	
	Revision: $Id: enUS.lua 13 2012-09-10 03:58:50z Kjasi $
]]

local rk = _G.RecipeKnown
if (not rk) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Global."..FONT_COLOR_CODE_CLOSE)
	return
end
local L = rk.Localization
if (not L) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Localization data."..FONT_COLOR_CODE_CLOSE)
	return
end

-- Message Templates
L.MSG = "|CFF57A5BB%s:"..FONT_COLOR_CODE_CLOSE.." %s"
L.ERRORMSG = "|CFFFF2020%s Error:"..FONT_COLOR_CODE_CLOSE.." %s"

-- Basic
RECIPEKNOWN_ERROR = "Error";
RECIPEKNOWN_DEBUG = "Debug";
RECIPEKNOWN_VERSIONTEXT = "Version ";
RECIPEKNOWN_ISNOWLOADED = "is now loaded!";


-- Modes
RECIPEKNOWN_MODE_SIMPLE = "Simple Mode";
RECIPEKNOWN_MODE_SELFISH = "Selfish Mode";
RECIPEKNOWN_MODE_ADVANCED = "Advanced Mode";


-- Error Messages
RECIPEKNOWN_NORECORD = "RecipeKnown does not have a record for %s (Itemid: %s). Please give this information to the development team, so they can add it.";
RECIPEKNOWN_ERROR_DATABASE_OPTIONS_OUTOFDATEANDDELETED = "Due to major database changes, your Options has been deleted. We apologize for any inconveniences.";
RECIPEKNOWN_ERROR_DATABASE_CHARDATA_OUTOFDATEANDDELETED = "Due to major database changes, your Tradeskill data  has been deleted. We apologize for any inconveniences.";

-- Tooltip Text
RECIPEKNOWN_TOOLTIP_REPORT = "RecipeKnown Report";
RECIPEKNOWN_TOOLTIP_TOONONLY = "  %s";						-- Passed Variable:  Character Name
RECIPEKNOWN_TOOLTIP_TOON = "  %s (%d/%d)";					-- Passed Variables: Character Name, Current Skill, Maximum Skill
RECIPEKNOWN_TOOLTIP_TOON_PROF = "  %s (%s, %d)";			-- Passed Variables: Character Name, Profession Name, Current Skill
RECIPEKNOWN_TOOLTIP_ALREADYKNOWN = "This is already known by %d/%d:";			-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_CANKNOW = "This can be learned by %d/%d:";					-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_DONTKNOW = "This can not yet be learned by %d/%d:";			-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_CANLOCKPICK = "This can be opened by %d/%d:";				-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_COULDLOCKPICK = "This could be opened %d/%d:";				-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_CANNOTLOCKPICK = "This can not yet be opened by %d/%d:";	-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_KNOWSPET = "This pet is known by %d/%d:";					-- Passed Variable: Known/Total
RECIPEKNOWN_TOOLTIP_DONTKNOWSPET = "This pet is not yet known by %d/%d:";		-- Passed Variable: Known/Total