--[[
	RecipeKnown Color Gnomes functions
	v0.28
	
	Revision: $Id: colorgnomes.lua 10 2012-09-05 23:44:12z Kjasi $
]]

local rk = _G.RecipeKnown
if (not rk) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Global."..FONT_COLOR_CODE_CLOSE)
	return
end
local L = rk.Localization
if (not L) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Localization data."..FONT_COLOR_CODE_CLOSE)
	return
end

local backgrounds = {
	["NameFrame"] = {0.5,0.5,0.5},
}
local nodata = false
local ItemColorData = {}

function RecipeKnown_ColorBox(itemid,colordata,bg,type)
	--RecipeKnown_Msg("Building Color data")
	local color = {1,1,1}
	local player = UnitName("player")
	local need = false
	RecipeKnown_GenerateDatabase() -- Just in case...

	-- Recipes
	if (type == "Recipe") then
		local tooncount = 0
		local kcount, ckcount, dkcount = 0,0,0
		local iname, link = GetItemInfo(itemid)
		local job, reqskill = RecipeKnown_Tooltip_GetJob(link)
		local db1 = RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"]
		local hasskill = false

		--RecipeKnown_Msg("Processing "..tostring(iname).."...")

		local tsid = RecipeKnown_Link2TsID(itemid)
		--RecipeKnown_Msg("ID Conversion successfully passed. Current TSID:"..tostring(tsid))
		
		-- Process and gather data
		local data = {}
		for toon, v in pairs(RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][job]) do
			--RecipeKnown_Msg(tostring(toon).." has "..tostring(job))
			if (not data[toon..job]) then
				data[toon..job] = {
					["name"] = toon,
					["min"] = v["data"]["current"],
					["max"] = v["data"]["max"],
					["job"] = job,
					["KnownsThis"] = false
				}
			end

			if (v["recipes"][tostring(tsid)]) then
				kcount = kcount + 1
			elseif (data[toon..job]["min"] >= tonumber(reqskill)) then
				ckcount = ckcount + 1
			elseif (data[toon..job]["min"] < tonumber(reqskill)) then
				dkcount = dkcount + 1
			end
		end

		if (tsid ~= nil) then
			if (db1[job]) and (db1[job][player]) and (db1[job][player]["recipes"][tostring(tsid)]) then
				--RecipeKnown_Msg("ColorBox TSID exists!")
				hasskill = true
			end
		end

		--RecipeKnown_Msg("hasskill:"..tostring(hasskill))

		for toon,skill in pairs(colordata) do
			tooncount = tooncount + 1
		end

		--RecipeKnown_Msg("CanKnow:"..tostring(ckcount)..", Don't Know:"..tostring(dkcount))

		-- If player has this profession...
		if (db1[job]) and (db1[job][player]) then
			if (hasskill == true) then
				--RecipeKnown_Msg("I Know it")
				color = RecipeKnown_Options["Colors"]["Known"]
			end
			if (dkcount > 0) then
				--RecipeKnown_Msg("An Alt will one day know it")
				color = RecipeKnown_Options["Colors"]["LearnAltLater"]
			end
			if (ckcount > 0) then
				--RecipeKnown_Msg("Alt can Learn it")
				color = RecipeKnown_Options["Colors"]["LearnAlt"]
			end
			if (tonumber(db1[job][player]["data"]["current"]) >= tonumber(reqskill)) and (hasskill == false) then
				--RecipeKnown_Msg("I can Learn it")
				color = RecipeKnown_Options["Colors"]["Learn"]
				need = true
			end
		else
			if (tooncount >= 1) then
				--RecipeKnown_Msg("Alts Know it")
				color = RecipeKnown_Options["Colors"]["KnownAlt"]
			end
			if (dkcount > 0) then
				--RecipeKnown_Msg("An Alt will one day know it")
				color = RecipeKnown_Options["Colors"]["LearnAltLater"]
			end
			if (ckcount > 0) then
				--RecipeKnown_Msg("Alt can Learn it")
				color = RecipeKnown_Options["Colors"]["LearnAlt"]
			end
		end
	end

	-- Done Last so it won't get over-written
	if (need == true) and (bg ~= nil) then
		--RecipeKnown_Msg("Returning Background")
		return bg[1], bg[2], bg[3]
	end

	if not color then
		color = {1,1,1}
	end
	
	return color[1], color[2], color[3]
end

function RecipeKnown_ColorGnomes(info, colorlist, colordata, type)
	--RecipeKnown_Msg("Running Color Gnomes!")

	for slot,itemid in pairs(colorlist) do
		local trueslot = slot
		while (trueslot > info["perpage"]) do
			trueslot = trueslot - info["perpage"]
		end

		for k,layer in pairs(info["colorlist"]) do
			local bg = nil
			--RecipeKnown_Msg("Trying to find:"..info["itemname"]..trueslot..layer.." for item slot:"..slot)
			local thisitem = getglobal(info["itemname"]..trueslot..layer)
			if (thisitem ~= nil) then
				local bg = nil
				if backgrounds[layer] then
					bg = backgrounds[layer]
				end
				--RecipeKnown_Msg("Found! Coloring...")
				thisitem:SetVertexColor(RecipeKnown_ColorBox(itemid,colordata[slot]["toons"],bg,type))
				if (nodata == true) then
					SetDesaturation(thisitem, 1)
				end
			end
		end
	end
end

function RecipeKnown_ColorClean(ScanType, slot)
	local info = RecipeKnown_ScanData(ScanType)

	local trueslot = slot
	while (trueslot > info["perpage"]) do
		trueslot = trueslot - info["perpage"]
	end
	
	for k2,layer in pairs(info["colorlist"]) do
		local thisitem = getglobal(info["itemname"]..trueslot..layer)

		thisitem:SetVertexColor(1,1,1)
	end
end

function RecipeKnown_BuildItemColorData(link)
	if (link == nil) then return end
	local _,link,_,_,_,itype = GetItemInfo(link)
	local id = RecipeKnown_GetItemID(link)

	-- RecipeKnown_Msg("Build ID:"..tostring(id))

	if (not id) or (itype ~= L.ITEMTYPE_RECIPE) then return end

	if (not ItemColorData[id]) then
		-- RecipeKnown_Msg("Building item data for:"..link)
		local _, _, _, k, ck, dk = RecipeKnown_Tooltip_GetInfo(link)

		ItemColorData[id] = {
			["Known"] = tonumber(k) or 0,
			["CanKnow"] = tonumber(ck) or 0,
			["DontKnow"] = tonumber(dk) or 0,
		}
	end

	-- RecipeKnown_Msg("Build Result:"..tostring(ItemColorData[id]["CanKnow"]))
end