--[[
	RecipeKnown Options File
	Version 0.28
	
	Revision: $Id: Options.lua 1 2012-09-10 18:21:11z Kjasi $
]]