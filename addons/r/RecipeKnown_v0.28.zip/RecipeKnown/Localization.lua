﻿--[[
	RecipeKnown v0.28
	Base Localization

	This file contains primary localizations needed for RecipeKnown to function in the given locale.
	Additonal localization files are for purely graphical changes.

	Revision: $Id: localization.lua 14 2012-09-05 23:57:45z Kjasi $
]]

local rk = _G.RecipeKnown
if (not rk) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Global."..FONT_COLOR_CODE_CLOSE)
	return
end

rk.Localization = {}
local L = rk.Localization
local Locale = GetLocale()

L.TITLE = "RecipeKnown"

-- English
-- Defaults to this	
	L.SKILL_ALCHEMY = "Alchemy"
	L.SKILL_BLACKSMITHING = "Blacksmithing"
	L.SKILL_COOKING = "Cooking"
	L.SKILL_ENCHANTING = "Enchanting"
	L.SKILL_ENGINEERING = "Engineering"
	L.SKILL_FIRSTAID = "First Aid"
	L.SKILL_INSCRIPTION = "Inscription"
	L.SKILL_JEWELCRAFTING = "Jewelcrafting"
	L.SKILL_LEATHERWORKING = "Leatherworking"
	L.SKILL_TAILORING = "Tailoring"
	L.SKILL_LOCKPICKING = "Lockpicking"
	
	L.ITEMTYPE_RECIPE = "Recipe"
	L.ITEMTYPE_MISC = "Miscellaneous"
	L.ITEMSUBTYPE_LOCKBOX = "Junk"
	L.ITEMSUBTYPE_PET = "Pet"
	
	L.PREFIX_DESIGN = "Design: "
	L.PREFIX_FORMULA = "Formula: "
	L.PREFIX_MANUAL = "Manual: "
	L.PREFIX_PLANS = "Plans: "
	L.PREFIX_PATTERN = "Pattern: "
	L.PREFIX_RECIPE = "Recipe: "
	L.PREFIX_SCHEMATIC = "Schematic: "
	L.PREFIX_TECHNIQUE = "Technique: "


	L.TEACHES_PET = "Use: Teaches you how to summon this companion."
	L.TEACHES_MOUNT = "Use: Teaches you how to summon this mount."

	-- This should work for most countries. Only needs to be included if the format changes for that locale.
	L.RECIPE_REQUIRES = "(%a+) %p(%d+)%p"
	
	
	L.TEACHES_PET = "Use: Teaches you how to summon this companion."
	L.TEACHES_MOUNT = "Use: Teaches you how to summon this mount."

	-- This should work for most countries. Only needs to be included if the format changes for that locale.
	L.RECIPE_REQUIRES = "(%a+) %p(%d+)%p"

-- German
if (GetLocale() == "deDE") then
	L.SKILL_ALCHEMY = "Alchimie"
	L.SKILL_BLACKSMITHING = "Schmiedekunst"
	L.SKILL_COOKING = "Kochkunst"
	L.SKILL_ENCHANTING = "Verzauberkunst"
	L.SKILL_ENGINEERING = "Ingenieurskunst"
	L.SKILL_FIRSTAID = "Erste Hilfe"
	L.SKILL_INSCRIPTION = "Inschriftenkunde"
	L.SKILL_JEWELCRAFTING = "Juwelenschleifen"
	L.SKILL_LEATHERWORKING = "Lederverarbeitung"
	L.SKILL_TAILORING = "Schneiderei"
	L.SKILL_LOCKPICKING = "Schlossknacken"

	L.ITEMTYPE_RECIPE = "Rezept"
	L.ITEMTYPE_MISC = "Verschiedenes"
	L.ITEMSUBTYPE_LOCKBOX = "Plunder"
	L.ITEMSUBTYPE_PET = "Tier"

	L.PREFIX_DESIGN = "Vorlage: "
	L.PREFIX_FORMULA = "Formel: "
	L.PREFIX_MANUAL = "Handbuch: "
	L.PREFIX_PLANS = "Pläne: "
	L.PREFIX_PATTERN = "Muster: "
	L.PREFIX_RECIPE = "Rezept: "
	L.PREFIX_SCHEMATIC = "Bauplan: "
	L.PREFIX_TECHNIQUE = "Technik: "

	L.TEACHES_PET = "Benutzen: Lehrt Euch, wie man dieses Haustier beschwört."
	L.TEACHES_MOUNT = "Benutzen: Lehrt Euch, wie man dieses Reittier beschwört."

-- French
elseif (GetLocale() == "frFR") then
	L.SKILL_ALCHEMY = "Alchimie"
	L.SKILL_BLACKSMITHING = "Forge"
	L.SKILL_COOKING = "Cuisine"
	L.SKILL_ENCHANTING = "Enchantement"
	L.SKILL_ENGINEERING = "Ingénierie"
	L.SKILL_FIRSTAID = "Premiers soins"
	L.SKILL_INSCRIPTION = "Calligraphie"
	L.SKILL_JEWELCRAFTING = "Joaillerie"
	L.SKILL_LEATHERWORKING = "Travail du cuir"
	L.SKILL_TAILORING = "Couture"
	L.SKILL_LOCKPICKING = "Crochetage"

	L.ITEMTYPE_RECIPE = "Recette"
	L.ITEMTYPE_MISC = "Divers"
	L.ITEMSUBTYPE_LOCKBOX = "Camelote"
	L.ITEMSUBTYPE_PET = "Familier"

	L.PREFIX_DESIGN = "Dessin : "
	L.PREFIX_FORMULA = "Formel : "
	L.PREFIX_MANUAL = "Manuel : "
	L.PREFIX_PLANS = "Plans : "
	L.PREFIX_PATTERN = "Patron : "
	L.PREFIX_RECIPE = "Recette : "
	L.PREFIX_SCHEMATIC = "Schéma : "
	L.PREFIX_TECHNIQUE = "Technique : "

	L.TEACHES_PET = "Utiliser : Vous apprend à invoquer cette mascotte."
	L.TEACHES_MOUNT = "Utiliser : Vous apprend à invoquer cette monture."

-- Spanish
elseif (GetLocale() == "esES") then
	L.SKILL_ALCHEMY = "Alquimia"
	L.SKILL_BLACKSMITHING = "Herrería"
	L.SKILL_COOKING = "Cocina"
	L.SKILL_ENCHANTING = "Encantamiento"
	L.SKILL_ENGINEERING = "Ingeniería"
	L.SKILL_FIRSTAID = "Primeros auxilios"
	L.SKILL_INSCRIPTION = "Inscripción"
	L.SKILL_JEWELCRAFTING = "Joyería"
	L.SKILL_LEATHERWORKING = "Peletería"
	L.SKILL_TAILORING = "Sastrería"
	L.SKILL_LOCKPICKING = "Forzar cerraduras"

	L.ITEMTYPE_RECIPE = "Receta"
	L.ITEMTYPE_MISC = "Miscelánea"
	L.ITEMSUBTYPE_LOCKBOX = "Chatarras"
	L.ITEMSUBTYPE_PET = "Mascota"

	L.PREFIX_DESIGN = "Boceto: "
	L.PREFIX_FORMULA = "Fórmula: "
	L.PREFIX_MANUAL = "Manual: "
	L.PREFIX_PLANS = "Diseño: "
	L.PREFIX_PATTERN = "Patrón: "
	L.PREFIX_RECIPE = "Receta: "
	L.PREFIX_SCHEMATIC = "Esquema: "
	L.PREFIX_TECHNIQUE = "Técnica: "

	L.TEACHES_PET = "Uso: Te enseña a invocar este compañero."
	L.TEACHES_MOUNT = "Uso: Te enseña a invocar esta montura."

-- Simple Chinese
elseif (GetLocale() == "zhCN") then
	L.SKILL_ALCHEMY = "炼金术"
	L.SKILL_BLACKSMITHING = "铁匠"
	L.SKILL_COOKING = "烹饪"
	L.SKILL_ENCHANTING = "附魔"
	L.SKILL_ENGINEERING = "工程"
	L.SKILL_FIRSTAID = "急救"
	L.SKILL_INSCRIPTION = "铭文"
	L.SKILL_JEWELCRAFTING = "珠宝加工"
	L.SKILL_LEATHERWORKING = "制皮"
	L.SKILL_TAILORING = "裁缝"
	L.SKILL_LOCKPICKING = "开锁"

	L.ITEMTYPE_RECIPE = "配方"
	L.ITEMTYPE_LOCKBOX = "杂项"
	L.ITEMSUBTYPE_LOCKBOX = "垃圾"
	L.ITEMSUBTYPE_PET = "宠物"

	L.PREFIX_DESIGN = "图鉴："
	L.PREFIX_FORMULA = "公式："
	L.PREFIX_FORMULA2 = "配方："	-- Alchemy
	L.PREFIX_MANUAL = "手册："
	L.PREFIX_PATTERN = "图样："
	L.PREFIX_PLANS = "设计图："
	L.PREFIX_RECIPE = "食谱："
	L.PREFIX_SCHEMATIC = "结构图："
	L.PREFIX_TECHNIQUE = "技巧："

	L.RECIPE_REQUIRES = "需要(.+)（(%d+)）"

	L.TEACHES_PET = "使用： 教你学会召唤这种小伙伴。"
	L.TEACHES_MOUNT = "使用： 教你学会召唤这种坐骑。"
end