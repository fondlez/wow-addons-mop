--[[
	RecipeKnown Tooltips File
	v0.28
	
	Revision: $Id: tooltips.lua 17 2012-09-05 23:54:44z Kjasi $
]]

local rk = _G.RecipeKnown
if (not rk) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Global."..FONT_COLOR_CODE_CLOSE)
	return
end
local L = rk.Localization
if (not L) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Localization data."..FONT_COLOR_CODE_CLOSE)
	return
end
local C = rk.Constants
if (not C) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Constants data."..FONT_COLOR_CODE_CLOSE)
	return
end
local DB = rk.Database
if (not DB) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Database data."..FONT_COLOR_CODE_CLOSE)
	return
end

local tooltip = RecipeKnown_Tooltip_Game
local lastlink = nil

local Color = {
	["White"] = "|cffffffff",
	["Red"] = "|cffff0000",
	["Green"] = "|cff11ff11",
}

-- Tooltip Hooks
function RecipeKnown_Tooltip_Show(self)
	local name, link = self:GetItem()
	if (not name) then
		return
	end

	if (not self:IsVisible()) then
		--RecipeKnown_Msg("Parent Tooltip is hidden!")
		RecipeKnown_Tooltip_Hide(self)
		return
	end

	--RecipeKnown_Msg("Tooltip Show")
	local returnfail = false

	local itemname,_,_,_,_,itemtype,itemsubtype = GetItemInfo(link)
	local isPet = RecipeKnown_Tooltip_Scan(link,L.TEACHES_PET)
	if ((itemtype == L.ITEMTYPE_MISC) and (itemsubtype == L.ITEMSUBTYPE_PET)) then
		isPet = true
	end
	if (isPet) then
		itemsubtype = L.ITEMSUBTYPE_PET
	end

	if (not itemname) or ((itemtype ~= L.ITEMTYPE_RECIPE) and ((itemtype ~= L.ITEMTYPE_MISC) or ((itemsubtype ~= L.ITEMSUBTYPE_LOCKBOX) and (itemsubtype ~= L.ITEMSUBTYPE_PET)))) then
		returnfail = true
	end

	if (returnfail == true) then
		--RecipeKnown_Msg("Itemtype wrong. Hiding Tooltip.")
		RecipeKnown_Tooltip_Hide(self)
		return
	end

	if self:GetName() == "GameTooltip" then
		tooltip = RecipeKnown_Tooltip_Game
	else
		tooltip = RecipeKnown_Tooltip_Item
	end

	if (tooltip:IsVisible()) and (link == lastlink) then
		return
	end

	RecipeKnown_Tooltip_PreScan(self, link)
	lastlink = link
end

function RecipeKnown_Tooltip_SetHyperlink(self, link)
	if (not link) then
		--RecipeKnown_Msg("No Hyperlink")
		return
	end

	-- RecipeKnown_Msg("Set Hyperlink")

	if (not self:IsVisible()) then
		--RecipeKnown_Msg("Parent Tooltip is hidden!")
		RecipeKnown_Tooltip_Hide(self)
		return
	end

	if self:GetName() == "GameTooltip" then
		tooltip = RecipeKnown_Tooltip_Game
	else
		tooltip = RecipeKnown_Tooltip_Item
	end

	if (tooltip:IsVisible()) then
		return
	end

	local _, type = RecipeKnown_GetItemID(link)

	if (type ~= "item") and (type ~= "enchant") then
		if (tooltip:IsVisible()) then
			--RecipeKnown_Msg("Tooltip Found. Hiding...")
			RecipeKnown_Tooltip_Hide(self)
		end
		--RecipeKnown_Msg("Itemtype wrong. Stopping...")
		return
	end

	--RecipeKnown_Msg("Setting Hyperlink \""..tostring(link).."\"...")

	if (not tooltip:IsVisible()) or (link ~= lastlink) then
		RecipeKnown_Tooltip_PreScan(self, link)
		lastlink = link
	end
end

-- Tooltip Pre-Scan Filter
function RecipeKnown_Tooltip_PreScan(self, link)
	-- RecipeKnown_Msg("Running Prescan...")
	if (not link) then
		--RecipeKnown_Msg("Cancelling Prescan: No Link")
		return
	end
	if (not self:IsVisible()) then
		--RecipeKnown_Msg("Parent Tooltip is hidden!")
		RecipeKnown_Tooltip_Hide(self)
		return
	end

	if (tooltip:IsVisible()) and (link == lastlink) then
		return
	end

	local id, type = RecipeKnown_GetItemID(link)

	local baditem = false
	if (type == "item") then
		for k,badid in pairs(DB.BadItems) do
			--RecipeKnown_Msg("BadID:"..tostring(badid)..", ID:"..id)
			if (tonumber(badid) == tonumber(id)) then
				-- RecipeKnown_Msg("Badid found:"..tostring(badid))
				baditem = true
				break
			end
		end
	end

	--RecipeKnown_Msg("Item Type:"..tostring(type))

	if (baditem == true) then
		--RecipeKnown_Msg("BadItem Found")
		tooltip:Hide()
		return
	elseif (type == "item") then
		--RecipeKnown_Msg("Type = Item")
		local itemname,_,_,_,_,itemtype,itemsubtype = GetItemInfo(link)
		local isPet = RecipeKnown_Tooltip_Scan(link,L.TEACHES_PET)
		if ((itemtype == L.ITEMTYPE_MISC) and (itemsubtype == L.ITEMSUBTYPE_PET)) then
			isPet = true
		end
		if (isPet) then
			itemsubtype = L.ITEMSUBTYPE_PET
		end
		if (not itemname) or ((itemtype ~= L.ITEMTYPE_RECIPE) and ((itemtype ~= L.ITEMTYPE_MISC) or ((itemsubtype ~= L.ITEMSUBTYPE_LOCKBOX) and (itemsubtype ~= L.ITEMSUBTYPE_PET)))) then
			if (tooltip:IsVisible()) then
				RecipeKnown_Tooltip_Hide(tooltip)
			end
			return
		end
		RecipeKnown_ItemTooltip(self, itemname, link)
		return
	elseif (type == "enchant") then
		RecipeKnown_Msg("Type = Enchant")
		local itemname,_,_,_,_,itemtype,_ = GetItemInfo(link)
		if (not itemname) or (itemtype ~= L.ITEMTYPE_RECIPE) then
			if (tooltip:IsVisible()) then
				RecipeKnown_Tooltip_Hide(tooltip)
			end
			return
		end
		RecipeKnown_EnchantTooltip(self, itemname, link)
		return
	end
	--RecipeKnown_Msg("Type ~= Item")
end

--== Main Tooltip Functions ==--
--Filter Item data for tooltip
function RecipeKnown_ItemTooltip(self, name, ilink)
	-- RecipeKnown_Msg("Running Tooltip")
	if (not iname) or (iname == nil) or (not ilink) or (ilink == nil) then
		iname, ilink = self:GetItem()
	end
	RecipeKnown_Tooltip(self, "item", iname, ilink)
end

--Filter Enchant data for tooltip
function RecipeKnown_EnchantTooltip(self, name, link)
	RecipeKnown_Tooltip(self, "enchant", name, link)
end

function RecipeKnown_Tooltip(self, type, name, link)
	--RecipeKnown_Msg("Running RK Tooltip...")

	if (self:GetName() == "GameTooltip") then
		tooltip = RecipeKnown_Tooltip_Game
	else
		tooltip = RecipeKnown_Tooltip_Item
	end

	--RecipeKnown_Msg("Setting locals")

	tooltip:SetOwner(self,"ANCHOR_NONE")
	tooltip:ClearLines()
	tooltip:AddLine(Color["White"]..RECIPEKNOWN_TOOLTIP_REPORT.."\n", 1,1,1)

	local Text = Color["White"]..RECIPEKNOWN_TOOLTIP_REPORT.."\n"

	if (type == "item") then
		local info, job, reqskill, ispet = RecipeKnown_Tooltip_GetInfo(link)
		if (not info) or info == nil then
			RecipeKnown_Msg("No Info or Info == nil")
			return
		end

		local known, canknow, dontknow = {}, {}, {}
		local color, nameonly, isLockbox
		local count, kcount, ckcount, dkcount, wkcount = 0,0,0,0,0

		--RecipeKnown_Msg("Building Arrays")
		-- Build the arrays
		for toon,data in pairs(info) do
		--RecipeKnown_Msg("Data[Min]:"..tostring(data["min"])..", Data[Max]:"..tostring(data["max"])..", Data[Known]:"..tostring(data["KnowsThis"]))	

			if (data["KnowsThis"] == true) then
				known[toon] = 1
				kcount = kcount + 1
			elseif (not ispet) and (tonumber(data["min"]) >= tonumber(reqskill)) then
				canknow[toon] = 1
				ckcount = ckcount + 1
			else
				dontknow[toon] = 1
				dkcount = dkcount + 1
			end
			count = count + 1
		end

		--RecipeKnown_Msg("Local Count: "..tostring(count)..", K:"..tostring(kcount)..", C:"..tostring(ckcount)..", D:"..tostring(dkcount))

		if (job == L.SKILL_LOCKPICKING) then
			isLockbox = true
		end
		
		--RecipeKnown_Msg("Building Message")
		-- Build the actual Message
		if (kcount > 0) then
			sort(known)
			if (ispet == true) then
				tooltip:AddLine(Color["White"]..format(RECIPEKNOWN_TOOLTIP_KNOWSPET,kcount,count))
				nameonly = true
			elseif (isLockbox == true) then
				tooltip:AddLine(Color["White"]..format(RECIPEKNOWN_TOOLTIP_CANLOCKPICK,kcount,count))
			else
				tooltip:AddLine(Color["White"]..format(RECIPEKNOWN_TOOLTIP_ALREADYKNOWN,kcount,count))
			end
			for toon,v in pairs(known) do
				if (nameonly == true) then
					tooltip:AddLine(Color["Green"]..format(RECIPEKNOWN_TOOLTIP_TOONONLY,info[toon]["name"]))
				elseif (isLockbox == true) then
					tooltip:AddLine(Color["Green"]..format(RECIPEKNOWN_TOOLTIP_TOON_PROF,info[toon]["name"],tostring(info[toon]["job"]),info[toon]["min"]))
				else
					tooltip:AddLine(Color["Green"]..format(RECIPEKNOWN_TOOLTIP_TOON,info[toon]["name"],info[toon]["min"],info[toon]["max"]))
				end
			end
		end

		-- Currently only active for recipes
		if (ckcount > 0) then
			sort(canknow)
			local st = ""
			if (kcount > 0) then st = "\n" end
			if (isLockbox == true) then
				tooltip:AddLine(st..Color["White"]..format(RECIPEKNOWN_TOOLTIP_COULDLOCKPICK,ckcount,count))
			else
				tooltip:AddLine(st..Color["White"]..format(RECIPEKNOWN_TOOLTIP_CANKNOW,ckcount,count))
			end
			for toon,v in pairs(canknow) do
				if (nameonly == true) then
					tooltip:AddLine(Color["White"]..format(RECIPEKNOWN_TOOLTIP_TOONONLY,info[toon]["name"]))
				elseif (isLockbox == true) then
					tooltip:AddLine(Color["White"]..format(RECIPEKNOWN_TOOLTIP_TOON_PROF,info[toon]["name"],tostring(info[toon]["job"]),info[toon]["min"]))
				else
					tooltip:AddLine(Color["White"]..format(RECIPEKNOWN_TOOLTIP_TOON,info[toon]["name"],info[toon]["min"],info[toon]["max"]))
				end
			end
		end

		if (dkcount > 0) then
			sort(dontknow)
			local st = ""
			if (kcount > 0) or (ckcount > 0) then st = "\n" end
			if (ispet == true) then
				tooltip:AddLine(st..Color["White"]..format(RECIPEKNOWN_TOOLTIP_DONTKNOWSPET,dkcount,count))
				nameonly = true
			elseif (isLockbox == true) then
				tooltip:AddLine(st..Color["White"]..format(RECIPEKNOWN_TOOLTIP_CANNOTLOCKPICK,dkcount,count))
			else
				tooltip:AddLine(st..Color["White"]..format(RECIPEKNOWN_TOOLTIP_DONTKNOW,dkcount,count))
			end
			for toon,v in pairs(dontknow) do
				if (nameonly == true) then
					tooltip:AddLine(Color["Red"]..format(RECIPEKNOWN_TOOLTIP_TOONONLY,info[toon]["name"]))
				elseif (isLockbox == true) then
					tooltip:AddLine(Color["Red"]..format(RECIPEKNOWN_TOOLTIP_TOON_PROF,info[toon]["name"],tostring(info[toon]["job"]),info[toon]["min"]))
				else
					tooltip:AddLine(Color["Red"]..format(RECIPEKNOWN_TOOLTIP_TOON,info[toon]["name"],info[toon]["min"],info[toon]["max"]))
				end
			end
		end

		-- Build No Data Info
		if (kcount <= 0) and (ckcount <= 0) and (dkcount <= 0) then
			--RecipeKnown_Msg("Count Fail:"..kcount..", "..ckcount..", "..dkcount)
			return
		end
	elseif (type == "enchant") then


		return
	end

	-- Set & Show Tooltip
	local Anch, AnchP

	tooltip:SetScale(UIParent:GetEffectiveScale()-0.10)

	local ttipr, rttipw, uir = self:GetRight(), tooltip:GetWidth(), UIParent:GetRight()
	if ttipr == nil then
		ttipr = 200
	end
	if rttipw == nil then
		rttipw = 200
	end
	if uir == nil then
		uir = 1024
	end

	-- MUST come after full generation of the tooltip, else GetWidth won't return the proper size.
	if (ttipr+rttipw > uir) then
		Anch = "TOPRIGHT"
		AnchP = "TOPLEFT"
	else
		Anch = "TOPLEFT"
		AnchP = "TOPRIGHT"
	end
		
	tooltip:SetPoint(Anch, self, AnchP)
	tooltip:Show()
end

function RecipeKnown_Tooltip_GetInfo(link)
	if (not link) or (link == nil) then
		--RecipeKnown_Msg("RecipeKnown_Tooltip_GetInfo Link Fail")
		return
	end
	--RecipeKnown_Msg("Getting Info")

	local isapet = nil
	local itemid = RecipeKnown_GetItemID(link)
	local itemname,_,_,_,_,itemtype,itemsubtype = GetItemInfo(link)
	local kcount, ckcount, dkcount = 0,0,0

	local isPet = RecipeKnown_Tooltip_Scan(link,L.TEACHES_PET)
	if ((itemtype == L.ITEMTYPE_MISC) and (itemsubtype == L.ITEMSUBTYPE_PET)) then
		isPet = true
	end
	if (itemtype == L.ITEMTYPE_RECIPE) then
		isPet = false
	end
	if (isPet) then
		itemsubtype = L.ITEMSUBTYPE_PET
	end

	if (not itemname) or ((itemtype ~= L.ITEMTYPE_RECIPE) and ((itemtype ~= L.ITEMTYPE_MISC) or ((itemsubtype ~= L.ITEMSUBTYPE_LOCKBOX) and (itemsubtype ~= L.ITEMSUBTYPE_PET)))) then
		return
	end

	local tsid = RecipeKnown_Link2TsID(link)
	local job, reqskill = RecipeKnown_Tooltip_GetJob(link)
	local data = {}

	--RecipeKnown_Msg("Testing Recipe for "..tostring(job).." with reqskill of "..tostring(reqskill))

	-- Pets
	if (isPet) then
		for toon, v in pairs(RecipeKnown_CharData[GetRealmName()][UnitFactionGroup("player")]["pets"]) do
			if (not data[toon.."Pet"]) then
				data[toon.."Pet"] = {
					["name"] = toon,
					["min"] = 1,
					["max"] = 1,
					["KnownsThis"] = false
				}
			end
			if (DB.Companions[tonumber(itemid)]) then
				if (v[DB.Companions[tonumber(itemid)]]) then
					kcount = kcount + 1
					data[toon.."Pet"]["KnowsThis"] = true
				else
					dkcount = dkcount + 1
				end
			else
				local msg = format(RECIPEKNOWN_NORECORD,itemname,itemid)
				if (not rk.ErrorList[msg]) then
					RecipeKnown_Msg(msg)
					rk.ErrorList[msg] = 1
				end
			end
		end

		isapet = true
	end

	-- Lockboxes
	if ((itemsubtype == L.ITEMSUBTYPE_LOCKBOX) and (job == L.SKILL_LOCKPICKING)) then
		-- Rogues
		for toon, v in pairs(RecipeKnown_CharData[GetRealmName()][UnitFactionGroup("player")]["data"]) do
			if (v["Class"] == "ROGUE") then
				local LPLevel = tonumber(v["Level"]) * 5
				if (not data[toon.."Lockpick"]) then
					data[toon.."Lockpick"] = {
						["name"] = toon,
						["min"] = LPLevel,
						["max"] = LPLevel,
						["job"] = L.SKILL_LOCKPICKING,
						["KnownsThis"] = false
					}
				end
				if (LPLevel >= tonumber(reqskill)) then
					kcount = kcount + 1
					data[toon.."Lockpick"]["KnowsThis"] = true
				else
					dkcount = dkcount + 1
				end
			end
		end
		
		-- Blacksmiths & Engineers
		for altjob, jv in pairs(RecipeKnown_CharData[GetRealmName()][UnitFactionGroup("player")]["recipes"]) do
			--RecipeKnown_Msg("Checking Job: "..tostring(altjob))
			if (altjob == L.SKILL_BLACKSMITHING) or (altjob == L.SKILL_ENGINEERING) then
				--RecipeKnown_Msg("Processing Blacksmiths and Engineers...")
				for toon, v in pairs(jv) do
					local jlvl = v["data"]["current"]
					local tjlvl = jlvl
					local skilldb, recipedb
					
					-- Set skill database depending on Job...
					if (altjob == L.SKILL_BLACKSMITHING) then
						skilldb = C.LockboxSkills_Blacksmith
						recipedb = C.LockboxSkillRecipes_Blacksmith
					elseif (altjob == L.SKILL_ENGINEERING) then
						skilldb = C.LockboxSkills_Engineer
						recipedb = C.LockboxSkillRecipes_Engineer
					end
					
					-- Find a recipe for this skill level, or stop at 1...
					while ((not skilldb[tjlvl]) and (tjlvl ~= 1)) do
						tjlvl = tjlvl - 1
					end
					-- Add data about this toon.
					if (not data[toon..altjob]) then
						data[toon..altjob] = {
							["name"] = toon,
							["min"] = jlvl,
							["max"] = v["data"]["max"],
							["job"] = altjob,
							["KnownsThis"] = false
						}
					end
					--RecipeKnown_Msg("Scanned Job Level: "..tostring(tjlvl))
					
					-- Process the data and determine if we know a recipe for this box.
					if (tjlvl >= 100) and (skilldb[tjlvl]) and (skilldb[tjlvl] >= tonumber(reqskill)) then
						-- This toon should be able to unlock it. Now we'll scan recipes to see if we know a matching recipe!
						local recipeid = recipedb[tjlvl]
						if (v["recipes"][tostring(recipeid)]) then
							-- This toon knows a recipe to unlock this box!
							kcount = kcount + 1
							data[toon..altjob]["KnowsThis"] = true
						else
							-- This toon can learn a recipe to unlock this box!
							ckcount = ckcount + 1
						end
					else
						dkcount = dkcount + 1
					end
				end
			end
		end
	end

	-- Recipes
	if (itemtype == L.ITEMTYPE_RECIPE) and (RecipeKnown_CharData[GetRealmName()][UnitFactionGroup("player")]["recipes"][job]) then
		for toon, v in pairs(RecipeKnown_CharData[GetRealmName()][UnitFactionGroup("player")]["recipes"][job]) do
			--RecipeKnown_Msg(tostring(toon).." has "..tostring(job))
			if (not data[toon..job]) then
				data[toon..job] = {
					["name"] = toon,
					["min"] = v["data"]["current"],
					["max"] = v["data"]["max"],
					["job"] = job,
					["KnownsThis"] = false
				}
			end

			if (v["recipes"][tostring(tsid)]) then
				kcount = kcount + 1
				data[toon..job]["KnowsThis"] = true
			elseif (data[toon..job]["min"] >= tonumber(reqskill)) then
				ckcount = ckcount + 1
			elseif (data[toon..job]["min"] < tonumber(reqskill)) then
				dkcount = dkcount + 1
			end
		end
	end

	return data, job, reqskill, isapet, kcount, ckcount, dkcount
end

function RecipeKnown_Tooltip_Scan(link, string)
	if (not link) or (link == nil) or (not string) or (string == nil) then
		return
	end

	RecipeKnown_Tooltip_Scanner:ClearLines()
	RecipeKnown_Tooltip_Scanner:SetHyperlink(link)

	for i=1,RecipeKnown_Tooltip_Scanner:NumLines() do
		local text = getglobal("RecipeKnown_Tooltip_ScannerTextLeft"..i):GetText()

		-- Search to see if this has the specified line
		if (strfind(text,string)) then
			return true
		end
	end
	return
end

function RecipeKnown_Tooltip_GetAlreadyKnown(link)
	if (not link) or (link == nil) then
		return
	end

	return RecipeKnown_Tooltip_Scan(link, ITEM_SPELL_KNOWN)
end


function RecipeKnown_Tooltip_GetJob(link)
	if (not link) or (link == nil) then
		-- RecipeKnown_Msg("Tooltip Scanner failed: link == nil")
		return
	end
	--RecipeKnown_Msg("Tooltip Scanner Running...")

	RecipeKnown_Tooltip_Scanner:ClearLines()
	RecipeKnown_Tooltip_Scanner:SetHyperlink(link)

	--RecipeKnown_Msg("Num Lines:"..RecipeKnown_Tooltip_Scanner:NumLines())
	for i=1,RecipeKnown_Tooltip_Scanner:NumLines() do
		--RecipeKnown_Msg("Scanning Tooltip...")
		local text = getglobal("RecipeKnown_Tooltip_ScannerTextLeft"..i):GetText()
		--RecipeKnown_Msg("Tooltip Text:"..tostring(text))

		--RecipeKnown_Msg("String: "..tostring(strfind(text,L.RECIPE_REQUIRES)))
		-- Search for Tradeskill name and required skill level
		if strfind(text, L.RECIPE_REQUIRES) then
			--RecipeKnown_Msg("String Found!")
			local job, req = strmatch(text,L.RECIPE_REQUIRES)
			--local job = strsub(strmatch(text,"%a+%s%p"),1,-3) -- Remove the space and the parentheses.
			--local req = strmatch(text,"%d+")
			--RecipeKnown_Msg("Job:"..tostring(job)..", req:"..tostring(req))
			if (job) and (job ~= nil) then
				--RecipeKnown_Msg("Found a recipe for "..tostring(job).." with a Req of "..tostring(req))
				return job, req
			end
		end
	end
end

function RecipeKnown_Tooltip_Hide(self)
	--== WoW Tooltips ==--
	if (self:GetName() == "ItemRefTooltip") or (self:GetName() == "RecipeKnown_Tooltip_Item") then
		RecipeKnown_Tooltip_Item:ClearLines()
		RecipeKnown_Tooltip_Item:Hide()
	elseif (self:GetName() == "GameTooltip") or (self:GetName() == "RecipeKnown_Tooltip_Game") then
		RecipeKnown_Tooltip_Game:ClearLines()
		RecipeKnown_Tooltip_Game:Hide()

	--== For Addons ==--
	-- AtlasLoot
	elseif (self:GetName() == "AtlasLootTooltipTEMP") then
		RecipeKnown_Tooltip_Item:ClearLines()
		RecipeKnown_Tooltip_Item:Hide()

	-- If we can't find what we're hiding, then clear & hide everything.
	else
		RecipeKnown_Tooltip_Item:ClearLines()
		RecipeKnown_Tooltip_Item:Hide()
		RecipeKnown_Tooltip_Game:ClearLines()
		RecipeKnown_Tooltip_Game:Hide()
	end
end