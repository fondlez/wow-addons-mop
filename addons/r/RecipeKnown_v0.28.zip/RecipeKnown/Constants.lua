--[[
	RecipeKnown Color Gnomes functions
	v0.28
	
	Revision: $Id: Constants.lua 1 2012-09-10 07:05:12z Kjasi $
]]

RecipeKnown = {}
local rk = RecipeKnown

rk.Constants = {}
local c = rk.Constants

-- [Job skill req] = lockpicking skill
c.LockboxSkills_Blacksmith = {
	[100] = 25,		-- Silver Skeleton Key
	[150] = 125,		-- Golden Skeleton Key
	[200] = 200,		-- Truesilver Skeleton Key
	[275] = 300,		-- Arcanite Skeleton Key
	[350] = 375,		-- Cobalt Skeleton Key
	[430] = 400,		-- Titanium Skeleton Key
	[475] = 525,		-- Obsidium Skeleton Key
}
c.LockboxSkills_Engineer = {
	[100] = 150,		-- Small Seaforium Charge
	[200] = 250,		-- Large Seaforium Charge
	[275] = 300,		-- Powerful Seaforium Charge
	[350] = 350,		-- Elemental Seaforium Charge
	[425] = 525,		-- Volatile Seaforuium Blastpack
}

c.LockboxSkillRecipes_Blacksmith = {
	[100] = 19666,		-- Silver Skeleton Key
	[150] = 19667,		-- Golden Skeleton Key
	[200] = 19668,		-- Truesilver Skeleton Key
	[275] = 19669,		-- Arcanite Skeleton Key
	[350] = 59405,		-- Cobalt Skeleton Key
	[430] = 59406,		-- Titanium Skeleton Key
	[475] = 76438,		-- Obsidium Skeleton Key
}

c.LockboxSkillRecipes_Engineer = {
	[100] = 3933,		-- Small Seaforium Charge
	[200] = 3972,		-- Large Seaforium Charge
	[275] = 23080,		-- Powerful Seaforium Charge
	[350] = 30547,		-- Elemental Seaforium Charge
	[425] = 84409,		-- Volatile Seaforuium Blastpack
}

rk.Realm = GetRealmName()
rk.Faction = UnitFactionGroup("player")
rk.CharName = UnitName("player")
local _, cn = UnitClass("player")
rk.ClassName = cn

rk.Color1 = "|CFF5555FF"
rk.Color2 = "|CFF55FF55"