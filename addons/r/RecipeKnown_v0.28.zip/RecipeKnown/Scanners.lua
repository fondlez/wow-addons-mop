--[[
	RecipeKnown Scanners & Scan Data
	v0.28
	
	Revision: $Id: scanners.lua 11 2012-09-05 23:54:36z Kjasi $
]]

local rk = _G.RecipeKnown
if (not rk) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Global."..FONT_COLOR_CODE_CLOSE)
	return
end
local L = rk.Localization
if (not L) then
	print(RED_FONT_COLOR_CODE.."Unable to find RecipeKnown's Localization data."..FONT_COLOR_CODE_CLOSE)
	return
end

local db = rk.Database

local idarray, namearray = {}, {}
local arraycount = 0

--== Scan Data functions ==--
-- Clear Search Arrays
function RecipeKnown_ScanData_Clear()
	idarray = {}
	namearray = {}
	arraycount = 0
end

-- Build searchable arrays
function RecipeKnown_ScanData_Build()
	RecipeKnown_ScanData_Clear()
	if (not RecipeKnown_CharData[rk.Realm][rk.Faction]) then return end
	for job,v in pairs(RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"]) do
		for toon,v2 in pairs(v) do
			for tsid, name in pairs(v2["recipes"]) do
				if (not idarray[tsid]) then
					idarray[tsid] = {
						["name"] = name,
						["skill"] = job,
						["toons"] = {},
					}
					arraycount = arraycount + 1
				end

				idarray[tsid]["toons"][toon] = v[toon]["data"]["current"]
				if (not namearray[name]) then
					namearray[name] = tsid
				end
			end
		end
	end
end

--== The Data Scanner Functions ==--

-- Update the Profession Numbers
function RecipeKnown_UpdateNumbers()
	local prof1, prof2, _, _, cooking, firstaid = GetProfessions()
	RecipeKnown_GenerateDatabase()

	if (prof1) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(prof1)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
	if (prof2) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(prof2)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
	if (cooking) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(cooking)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
	if (firstaid) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(firstaid)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
end

-- Gathers recipe info for all professions.
function RecipeKnown_Scan_AllRecipes()
	local prof1, prof2, _, _, cooking, firstaid = GetProfessions()
	RecipeKnown_GenerateDatabase()

	if (prof1) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(prof1)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
	if (prof2) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(prof2)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
	if (cooking) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(cooking)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
	if (firstaid) then
		local name, _, skillLevel, maxSkillLevel = GetProfessionInfo(firstaid)
		RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	end
end

--Recipe Gatherer
function RecipeKnown_Scan_Recipes(ProfID)
	local name = GetProfessionInfo(ProfID)

end

-- Update Professions Database
function RecipeKnown_BuildNumbersDB(name,skillLevel,maxSkillLevel)
	-- Build DB if it doesn't exist.
	if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name]) then
		RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name] = {}
	end
	if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name][rk.CharName]) then
		RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name][rk.CharName] = {}
	end
	if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name][rk.CharName]["data"]) then
		RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name][rk.CharName]["data"] = {
			["current"] = skillLevel,
			["max"] = maxSkillLevel,
		}
	end
	if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["data"][rk.CharName]["Professions"][name]) then
		RecipeKnown_CharData[rk.Realm][rk.Faction]["data"][rk.CharName]["Professions"][name] = skillLevel
	end

	-- Update existing DBs
	RecipeKnown_CharData[rk.Realm][rk.Faction]["data"][rk.CharName]["Professions"][name] = skillLevel
	RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name][rk.CharName]["data"]["current"] = skillLevel
	RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][name][rk.CharName]["data"]["max"] = maxSkillLevel
end

-- Old Method
function RecipeKnown_Scanner(ScanType)
	--RecipeKnown_Msg("Scanner Running...")
	if (ScanType == "Spells") then
		if (rk.ClassName == "DRUID") then
		elseif (rk.ClassName == "MAGE") then
		elseif (rk.ClassName == "PREIST") then
		elseif (rk.ClassName == "ROGUE") then
		elseif (rk.ClassName == "SHAMAN") then
		elseif (rk.ClassName == "WARLOCK") then
		end
	elseif (ScanType == "Recipes") then
		-- if Tradeskill frame is hidden, if it's a linked Tradeskill or the "Have Materials" button is checked, then fail.
		if (not TradeSkillFrame) or (not TradeSkillFrame:IsVisible()) or (IsTradeSkillLinked()) or (IsTradeSkillGuild()) then
			--RecipeKnown_Msg("Initial Failure: Tradeskill window not found, not visible, is linked.")
			return
		end

		--RecipeKnown_Msg("Scanning Recipes...")

		local tradename, tradecurrentskill, trademaxskill = GetTradeSkillLine()
		local found = false

		for k,skill in pairs(RecipeKnown_Skills) do
			if (skill == tradename) then
				found = true
				break
			end
		end
		if (found == false) then
 			--RecipeKnown_Msg("Trade Skill \""..tostring(tradename).."\" not supported.")
			return
		end

		--RecipeKnown_Msg("Trade Skill \""..tostring(tradename).."\" supported! Scanning recipes...")

		if (GetNumTradeSkills() == 0) then
			-- RecipeKnown_Msg("No Tradeskills found")
			return
		end

		RecipeKnown_GenerateDatabase()

		if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename]) then
			RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename] = {}
		end
		if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]) then
			RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName] = {
				["data"] = {
					["current"] = tradecurrentskill,
					["max"] = trademaxskill,
				},
				["recipes"] = {},
			}
		end
		if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["data"][rk.CharName]["Professions"][tradename]) then
			RecipeKnown_CharData[rk.Realm][rk.Faction]["data"][rk.CharName]["Professions"][tradename] = tradecurrentskill
		end

		local headercount = 0
		for i=1,GetNumTradeSkills() do
			local skillName, skillType = GetTradeSkillInfo(i)
			if (skillType == "header") then
				headercount = headercount + 1
			elseif (skillType ~= "header") and (headercount > 0) then
				local tsid = RecipeKnown_GetItemID(GetTradeSkillRecipeLink(i))
				--RecipeKnown_Msg("TSID:"..tostring(tsid)..", "..skillName)
				
				if (tsid) and (not RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]["recipes"][tsid]) then
					RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]["recipes"][tsid] = skillName
				end
			end
		end

		if (RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]["data"]["current"] < tradecurrentskill) then
			RecipeKnown_CharData[rk.Realm][rk.Faction]["data"][rk.CharName]["Professions"][tradename] = tradecurrentskill
			RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]["data"]["current"] = tradecurrentskill
		end
		if (RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]["data"]["max"] < trademaxskill) then
			RecipeKnown_CharData[rk.Realm][rk.Faction]["recipes"][tradename][rk.CharName]["data"]["max"] = trademaxskill
		end

		RecipeKnown_UpdateWindows()
	end
	--RecipeKnown_Msg("Scan Complete")
end

--== Pre-Scan Data Sorter ==--
-- Sets up the information needed for the Item Scanner to function properly.
function RecipeKnown_ScanData(ScanType)
	if (ScanType == nil) then return end
	local scaninfo = {
		["type"] = ScanType,
		["subtype"] = "none",
		["frame"] = nil,
		["updater"] = nil,
		["link"] = nil,
		["total"] = 0,
		["perpage"] = 0,
		["framepage"] = 0,
		["offset"] = 0,
		["itemlist"] = "none",
		["colorlist"] = {},
	}
	if (ScanType == "Merchant") then
		scaninfo["frame"] = MerchantFrame
		scaninfo["updater"] = MerchantFrame_UpdateMerchantInfo
		scaninfo["link"] = GetMerchantItemLink
		scaninfo["total"] = GetMerchantNumItems()
		scaninfo["perpage"] = MERCHANT_ITEMS_PER_PAGE
		scaninfo["framepage"] = MerchantFrame.page
		scaninfo["offset"] = 0
		scaninfo["itemname"] = "MerchantItem"
		scaninfo["colorlist"] = {
			"NameFrame",
			"SlotTexture",
			"ItemButtonIconTexture",
			"ItemButtonNormalTexture",
		}
	elseif (ScanType == "Auction") then
		local frame, itemname, updater, numpp, subtype, totalAuctions, offset

		if (AuctionFrameBrowse) and (AuctionFrameBrowse:IsVisible()) then
			--RecipeKnown_Msg("Setting Scan Data for Auction Browsing...")
			frame = AuctionFrameBrowse
			updater = AuctionFrameBrowse_Update
			numpp = NUM_BROWSE_TO_DISPLAY
			subtype = "list"
			_, totalAuctions = GetNumAuctionItems("list")
			itemname = "BrowseButton"
			offset = FauxScrollFrame_GetOffset(BrowseScrollFrame)
		elseif (AuctionFrameBid) and (AuctionFrameBid:IsVisible()) then
			--RecipeKnown_Msg("Setting Scan Data for Auction Bidding...")
			frame = AuctionFrameBid
			updater = AuctionFrameBid_Update
			numpp = NUM_BIDS_TO_DISPLAY
			subtype = "bidder"
			_, totalAuctions = GetNumAuctionItems("bidder")
			itemname = "BidButton"
			offset = FauxScrollFrame_GetOffset(BidScrollFrame)
		elseif (AuctionFrameAuctions) and (AuctionFrameAuctions:IsVisible()) then
			--RecipeKnown_Msg("Setting Scan Data for My Auctions...")
			frame = AuctionFrameAuctions
			updater = AuctionFrameAuctions_Update
			numpp = NUM_AUCTIONS_TO_DISPLAY
			subtype = "owner"
			_, totalAuctions = GetNumAuctionItems("owner")
			itemname = "AuctionsButton"
			offset = FauxScrollFrame_GetOffset(AuctionsScrollFrame)
		end

		if (frame == nil) then
			--RecipeKnown_Msg("Auction Frame = nil")
			return
		end

		scaninfo["subtype"] = subtype
		scaninfo["frame"] = frame
		scaninfo["updater"] = updater
		scaninfo["link"] = GetAuctionItemLink
		scaninfo["total"] = totalAuctions
		scaninfo["perpage"] = numpp
		scaninfo["framepage"] = (frame.page) + 1
		scaninfo["offset"] = offset
		scaninfo["itemname"] = itemname
		scaninfo["colorlist"] = {
			"ItemIconTexture",
		}
	elseif (ScanType == "TradePlayer") or (ScanType == "TradeTarget") then
		local itemname, link

		if (ScanType == "TradePlayer") then
			itemname = "TradePlayerItem"
			link = GetTradePlayerItemLink
		else
			itemname = "TradeRecipientItem"
			link = GetTradeTargetItemLink
		end

		scaninfo["frame"] = TradeFrame
		scaninfo["updater"] = TradeFrame_Update
		scaninfo["link"] = link
		scaninfo["total"] = MAX_TRADE_ITEMS
		scaninfo["perpage"] = MAX_TRADE_ITEMS
		scaninfo["framepage"] = 1
		scaninfo["offset"] = 0
		scaninfo["itemname"] = itemname
		scaninfo["colorlist"] = {
			"NameFrame",
			"SlotTexture",
			"ItemButtonIconTexture",
			"ItemButtonNormalTexture",
		}
	end

	if (scaninfo["frame"] == nil) or (scaninfo["type"] == "none") then
		return
	end

	return scaninfo
end

--== Item Scanner ==--
-- Scans the active items to see if any of them match the recorded databases.
function RecipeKnown_ScanItems(info)
	if (info == nil) then
		--RecipeKnown_Msg("Info empty")
		return
	end
	if (not info["frame"]:IsVisible()) then
		--RecipeKnown_Msg("Info[Frame] ("..tostring(info["frame"])..") not visible")
		return
	end
	local matchfound = false
	local itemlist, scanlist, colorlist, colordata = {}, {}, {}, {}

	local start = ((info["perpage"]*info["framepage"])-info["perpage"]) + 1
	local ending = start + (info["perpage"]) - 1
	if (ending > info["total"]) then ending = info["total"] end

	--RecipeKnown_Msg("Scan Items Start:"..start..", Ending:"..ending)

	-- Build current Item data
	for i=start,ending do
		local i2 = i
		local itemlink, itemid

		if (info["type"] == "Auction") then
			i2 = info["offset"] + ((i-(info["framepage"]*info["perpage"]))+info["perpage"])
			itemlink = info["link"](info["subtype"],i2)
		else
			itemlink = info["link"](i2)
		end

		--RecipeKnown_Msg("Itemlink:"..tostring(itemlink))
		itemid = RecipeKnown_GetItemID(itemlink)

		-- Determine if it's a bad item.
		local baditem = false
		for k,badid in pairs(db.BadItems) do
			if (badid == itemid) then
				baditem = true
				break
			end
		end

		-- Ignore bad items
		if (baditem == false) then
			--RecipeKnown_Msg("Item's ID:"..tostring(itemid))

			if (not itemid) or (itemid == nil) then
				--RecipeKnown_Msg("ItemID = nil")
			else
				--RecipeKnown_Msg("ItemID ~= nil")
				if (not scanlist[i]) then
					scanlist[i] = itemid
				end
			end
		end
	end

	--RecipeKnown_Msg("Comparing Recipes...")
--[[
	local slc = 0
	for k,v in pairs(scanlist) do
		slc = slc + 1
	end
	RecipeKnown_Msg("Number of Slots:"..slc)
]]

	-- Scan active slots for matching items
	for slot,itemid in pairs(scanlist) do
		--RecipeKnown_Msg("Running Data for slot:"..slot)
		local iname, ilink,_,_,_,itype = GetItemInfo(itemid)
		local tsid = nil
		itemid = tonumber(itemid)

		--RecipeKnown_Msg("iname:"..tostring(iname))

		if (itype == L.ITEMTYPE_RECIPE) then
			RecipeKnown_BuildItemColorData(ilink)

			tsid = RecipeKnown_Link2TsID(itemid)
			tsid = tostring(tsid)

			--RecipeKnown_Msg("ItemID:"..tostring(itemid)..", TSID:"..tostring(tsid)..", IDarray:"..tostring(idarray[tsid]))

			if (idarray[tsid]) then
				--RecipeKnown_Msg("ID Match Found! Recipe: "..iname)

				colorlist[slot] = itemid

				--RecipeKnown_Msg("Setting data for slot "..slot)

				if (not colordata[slot]) then
					colordata[slot] = {}
				end
				if (not colordata[slot]["toons"]) then
					colordata[slot]["toons"] = idarray[tsid]["toons"]
				end
				matchfound = "Recipe"
			elseif (RecipeKnown_Tooltip_GetAlreadyKnown(ilink) == true) then
				colorlist[slot] = itemid
				if (not colordata[slot]) then
					colordata[slot] = {}
				end
				if (not colordata[slot]["toons"]) then
					colordata[slot]["toons"] = {
						[rk.CharName] = 1,
					}
				end
			end
		end
	end

	-- If Matches found, perform coloring
	if (matchfound ~= false) then
		RecipeKnown_ColorGnomes(info, colorlist, colordata, matchfound)
	end
end

function RecipeKnown_GetSingleItemKnown(link, toon)
	if (not link) or (link == nil) then return end
	local itemid = RecipeKnown_GetItemID(link)
	local itemname, _,_,_,_,itemtype = GetItemInfo(link)
	if (not itemname) or (itemtype ~= L.ITEMTYPE_RECIPE) then return end
	local tsid = RecipeKnown_Link2TsID(itemid)
	local result

	if (tsid == nil) then
		return
	end

	-- RecipeKnown_Msg("ItemID:"..tostring(itemid)..", TSID:"..tostring(tsid)..", IDarray:"..tostring(idarray[tsid]["toons"][toon]))

	if (idarray[tostring(tsid)]) and (idarray[tostring(tsid)]["toons"][toon]) then
		-- RecipeKnown_Msg("Toon Found, Setting Results...")
		result = true
	end

	-- RecipeKnown_Msg("Results:"..tostring(result).."!")

	return result
end

function RecipeKnown_Link2TsID(itemid)
	if (itemid == nil) then
		return
	end

	--RecipeKnown_Msg("Running Link2TsID...")

	local tsid = nil
	itemid = RecipeKnown_GetItemID(itemid)
	local itemname, _,_,_,_,itemtype = GetItemInfo(itemid)
	--RecipeKnown_Msg("ItemID:"..tostring(itemid)..", Itemname:"..tostring(itemname))

	if (db.ItemEnch[tonumber(itemid)]) then
		--RecipeKnown_Msg("Item matched in ItemEnch List")
		tsid = db.ItemEnch[tonumber(itemid)]
	elseif (RecipeKnown_ItemID2TsID[tonumber(itemid)]) then
		--RecipeKnown_Msg("Item matched in ID2TsID List")
		tsid = RecipeKnown_ItemID2TsID[tonumber(itemid)]
	else
		local item = itemname
		for k,prefix in pairs(RecipeKnown_Prefixes) do
			if strfind(itemname,prefix) then
				item = gsub(itemname,prefix, "")
				-- RecipeKnown_Msg("Name Reducer:"..tostring(item))
				break
			end
		end

		RecipeKnown_ScanData_Build()

		-- RecipeKnown_Msg("Item:"..tostring(item)..", NameArray:"..tostring(namearray[item]))

		if (namearray[item]) then
			--RecipeKnown_Msg("Item matched using Namearray")
			tsid = namearray[item]
		else
			for name,id in pairs(namearray) do
				if (strmatch(name,item)) then
					--RecipeKnown_Msg("Item matched using StrMatch")
					tsid = id
					break
				end
			end
		end
		if (tsid ~= nil) and (not db.ItemEnch[tonumber(itemid)]) and (not RecipeKnown_ItemID2TsID[tonumber(itemid)]) then
			--RecipeKnown_Msg("Recording ItemID & TsID")
			RecipeKnown_ItemID2TsID[tonumber(itemid)] = tonumber(tsid)
		end
	end

	if tsid == nil then
		--RecipeKnown_Msg("Item not matched.")
	end

	--RecipeKnown_Msg("Returning TSID:"..tostring(tsid))
	return tsid
end

function RecipeKnown_ScanPets()
	local num = GetNumCompanions("CRITTER")
	
	for i=1,num do
		local _, creatureName, petspid, _, _ = GetCompanionInfo("CRITTER", i)

		if (not RecipeKnown_CharData[rk.Realm][rk.Faction]["pets"][rk.CharName][petspid]) then
			RecipeKnown_CharData[rk.Realm][rk.Faction]["pets"][rk.CharName][petspid] = creatureName
		end
	end
end

-- Return the Data Arrays
-- Used for other files that need the local data
function RecipeKnown_GetArrayData()
	RecipeKnown_ScanData_Build()
	return arraycount, idarray, namearray
end