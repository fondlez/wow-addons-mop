--Localization.zhTW.lua
--Localization by machihchung

if GetLocale() == "zhTW" then

 RareAnnouncerLocalization = {
	["71864"] = "史勒剋", -- Needs review
	["71919"] = "『餿酒』祝貢", -- Needs review
	["72045"] = "查蘭", -- Needs review
	["72048"] = "喋喋歪歪人", -- Needs review
	["73854"] = "嗜鶴虎", -- Needs review
	["72193"] = "深海之煞卡卡諾", -- Needs review
	["72245"] = "宙斯卡", -- Needs review
	["72769"] = "碧火之靈", -- Needs review
	["72775"] = "布弗", -- Needs review
	["72808"] = "薩弗卡", -- Needs review
	["72909"] = "『蟲群使者』古奇", -- Needs review
	["72970"] = "格坎納", -- Needs review
	["73157"] = "石蘚行者", -- Needs review
	["73158"] = "翡翠雄鶴", -- Needs review
	["73160"] = "鐵鬃鋼角", -- Needs review
	["73161"] = "巨型龜怒殼", -- Needs review
	["73163"] = "帝王莽蛇", -- Needs review
	["73166"] = "巨怪蟹王", -- Needs review
	["73167"] = "霍龍", -- Needs review
	["73169"] = "『歐朵勇士』賈庫爾", -- Needs review
	["73170"] = "看守者歐蘇", -- Needs review
	["73171"] = "黑焰勇士", -- Needs review
	["73172"] = "燧石劍士蓋然", -- Needs review
	["73173"] = "『灼烙者』烏篤爾", -- Needs review
	["73174"] = "火焰大祭司", -- Needs review
	["73175"] = "燼火之靈", -- Needs review
	["73277"] = "癒葉妖", -- Needs review
	["73279"] = "無盡之喉", -- Needs review
	["73281"] = "『毀滅之艦』維蘇威號", -- Needs review
	["73282"] = "血靈迦尼亞", -- Needs review
	["73704"] = "臭辮子", -- Needs review
	Name = "Name", -- Requires localization
        ago = "以前", -- Needs review
	Alive = "存活", -- Needs review
	announce = "當你選取稀有或擊殺稀有時通報", -- Needs review
	Coordinates = "座標：", -- Needs review
	Dead = "死亡", -- Needs review
	["has died"] = "已死", -- Needs review
	hidetracking = "戰鬥中隱藏追蹤視窗", -- Needs review
	Killed = "擊殺", -- Needs review
	["last killed"] = "最後擊殺", -- Needs review
	-- optionsConfig = "",
	-- optionsTracking = "",
	recentkill = "最後擊殺在一分鐘之前", -- Needs review
	respond = "回應要求", -- Needs review
	responedRT = "回應稀有擊殺紀錄要求", -- Needs review
	setTomTom = "當發現稀有時設定TomTom路徑點至目標", -- Needs review
	-- trackNotice = "",
	-- trackSelectAll = "",
	-- trackSelectNone = "",
	-- trackTypeAll = "",
	-- trackTypeAllTooltip = "",
	-- trackTypeHead = "",
	-- trackTypeNext = "",
	-- trackTypeNextTooltip = "",
	-- trackTypeSelected = "",
	-- trackTypeSelectedTooltip = "",
}
end