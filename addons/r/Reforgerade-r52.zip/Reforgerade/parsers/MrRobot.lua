do
	--lookup table from ask mr robot addon
	local REFORGE_TABLE_BASE = 112
	local REFORGE_TABLE = {
	  {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7}, {1, 8},
	  {2, 1}, {2, 3}, {2, 4}, {2, 5}, {2, 6}, {2, 7}, {2, 8},
	  {3, 1}, {3, 2}, {3, 4}, {3, 5}, {3, 6}, {3, 7}, {3, 8},
	  {4, 1}, {4, 2}, {4, 3}, {4, 5}, {4, 6}, {4, 7}, {4, 8},
	  {5, 1}, {5, 2}, {5, 3}, {5, 4}, {5, 6}, {5, 7}, {5, 8},
	  {6, 1}, {6, 2}, {6, 3}, {6, 4}, {6, 5}, {6, 7}, {6, 8},
	  {7, 1}, {7, 2}, {7, 3}, {7, 4}, {7, 5}, {7, 6}, {7, 8},
	  {8, 1}, {8, 2}, {8, 3}, {8, 4}, {8, 5}, {8, 6}, {8, 7},
	}
	
	function Reforgerade_MrRobotReforge(inputString)
		local reforgeTable = {}
		for k, v in string.gmatch(inputString, "([^=;]+)=([^;]*)") do
			if (k == 'item') then
				local slot, itemId, suffixList, upgradeId, gemColorString, gemEnchantIdString, gemIdString, enchantId, reforgeId = string.match(v, "^(%d+):(%d+):([^:]+):([^:]+):([^:]+):([^:]+):([^:]+):(%d+):(%d+)");
				local targetFrom;
				local targetTo;
				if reforgeId then
					if tonumber(reforgeId) == 0 then
						targetFrom = 0;
						targetTo = 0;
					else
						targetFrom = REFORGE_TABLE[reforgeId - REFORGE_TABLE_BASE][1];
						targetTo = REFORGE_TABLE[reforgeId - REFORGE_TABLE_BASE][2];
					end
					local itemLink = GetInventoryItemLink("player", slot+1)
					local itemName = select(1,GetItemInfo(itemLink))
					if targetFrom then --If we retrieved reforge from text and it is a known stat
						if targetTo then --If we retrieved reforge to text and it is a known stat
							if itemLink then  --This value can be nil if we don't have an item in the slot specified.
								if itemName then  --This value can be nil if itemLink is nil
									if reforgeTable[itemName] then --Reforging information already in table meas a duplicate item name
										reforgeTable[itemName][3] = targetFrom
										reforgeTable[itemName][4] = targetTo
									else
										reforgeTable[itemName] = {targetFrom,targetTo}
									end
								end
							end
						end
					end
				end
			end
		end
		return reforgeTable
	end
		
	Reforgerade:RegisterParser("Ask Mr. Robot", Reforgerade_MrRobotReforge)
end