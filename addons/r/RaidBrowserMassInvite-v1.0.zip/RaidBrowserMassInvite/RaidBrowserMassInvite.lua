local AddOnName, Engine = ...;  
local frame = CreateFrame("Frame", AddOnName)
local Elv, S = IsAddOnLoaded("ElvUI")

local function onEvent(this, event, arg1)
	if arg1 == AddOnName then
		OnInitLoad()
	end
end

if(Elv) then
	E =  unpack(ElvUI);
	S = E:GetModule('Skins')
end

function OnInitLoad()
	local btn = CreateFrame("Button","RaidBrowserMassInvite",LFRBrowseFrame,"UIPanelButtonTemplate")
	local width, height = LFRBrowseFrameInviteButton:GetSize()
	width = width*0.8
    btn:SetSize(width,height)
	LFRBrowseFrameSendMessageButton:SetSize(width, height)
	LFRBrowseFrameInviteButton:SetSize(width, height)
	LFRBrowseFrameRefreshButton:SetSize(width, height)
    btn:SetText("Mass Invite")
    btn:SetPoint("TOPLEFT", LFRBrowseFrameInviteButton, "TOPRIGHT", 3, 0)
	LFRBrowseFrameRefreshButton:ClearAllPoints()
    LFRBrowseFrameRefreshButton:SetPoint("TOPLEFT", btn, "TOPRIGHT", 3, 0)
    btn:SetScript("OnClick", function() InviteAll() end)
    btn:SetNormalFontObject(GameFontNormalSmall)
    btn:SetHighlightFontObject(GameFontHighlightSmall)
	
	if (Elv) then
		S:HandleButton(btn)
	end
end

function InviteAll()
	local i; 
	for i=1,40 do 
		if _G["LFRBrowseFrameListButton"..i] then 
			_G["LFRBrowseFrameListButton"..i]:Click(); 
			LFRBrowseFrameInviteButton:Click() 
		end 
	end
end

frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", onEvent)