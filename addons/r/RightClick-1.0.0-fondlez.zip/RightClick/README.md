# RightClick Addon for WoW
Disables right click attack on enemies. \
Disables right click targeting if an enemy is selected.
