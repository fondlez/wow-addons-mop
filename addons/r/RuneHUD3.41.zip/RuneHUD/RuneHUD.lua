--CONFIG--------------------------------------------
local x1 = 103		y1 = 23				-- Coordinate for the first blood and the second unholy rune
local x2 = 72		y2 = 61				-- Coordinate for the second blood and the first unholy rune
local x3 = 25		y3 = 80				-- Coordinate for the first and second frost runes
---------------------------------------------------------

SLASH_RUNEHUD1, SLASH_RUNEHUD2 = '/runehud', '/rh';
local function handler(msg, editbox)
local command, rest = msg:match("^(%S*)%s*(.-)$")
	if command == 's' then
		if tonumber(rest) ~= nil then 
			if tonumber(rest) > 0 then
				RHs = tonumber(rest)
				RuneFrame:SetScale(RHs)
				RuneButtonIndividual1:ClearAllPoints()
				RuneButtonIndividual1:SetPoint("CENTER", UIParent, "CENTER", -x1, y1)
			else
				print("RuneHUD: You need to use a valid value for the scale");
			end
		else
			print("RuneHUD: You need to use a valid value for the scale");
		end
	elseif command == 'aoc' then
		if tonumber(rest) ~= nil then 
			if tonumber(rest) >= 0 then
				RHaoc = tonumber(rest)
				if InCombatLockdown() == nil then
					RuneFrame:SetAlpha(RHaoc)
				end
			else
				print("RuneHUD: You need to use a valid value for the alpha");
			end
		else
			print("RuneHUD: You need to use a valid value for the alpha");
		end
	elseif command == 'aic' then
		if tonumber(rest) ~= nil then 
			if tonumber(rest) >= 0 then
				RHaic = tonumber(rest)
				if InCombatLockdown() then
					RuneFrame:SetAlpha(RHaic)
				end
			else
				print("RuneHUD: You need to use a valid value for the alpha");
			end
		else
			print("RuneHUD: You need to use a valid value for the alpha");
		end
	elseif command == 'aiv' then
		if tonumber(rest) ~= nil then 
			if tonumber(rest) >= 0 then
				RHaiv = tonumber(rest)
				if UnitInVehicle("player") then
					RuneFrame:SetAlpha(RHaiv)
				end
			else
				print("RuneHUD: You need to use a valid value for the alpha");
			end
		else
			print("RuneHUD: You need to use a valid value for the alpha");
		end
	elseif command == 'hoc' and tostring(rest) == "false" or tostring(rest) == "true" then
		RHhoc = tostring(rest)
	elseif command == 'hoc' then
		print("RuneHUD: The cooldown fading options has been disabled due to weird bugs with it");
	else
		print("RuneHUD: The available slash commands are:");
		print("RuneHUD: '/rh s <scale>' for scaling");
		print("RuneHUD: '/rh aoc <alpha>' for out of combat alpha");
		print("RuneHUD: '/rh aic <alpha>' for alpha in combat");
		print("RuneHUD: '/rh aiv <alpha>' for alpha when in a vehicle");
	end
end
SlashCmdList["RUNEHUD"] = handler;


--Clearing the old position
RuneButtonIndividual1:ClearAllPoints()
RuneButtonIndividual2:ClearAllPoints()
RuneButtonIndividual3:ClearAllPoints()
RuneButtonIndividual4:ClearAllPoints()
RuneButtonIndividual5:ClearAllPoints()
RuneButtonIndividual6:ClearAllPoints()

--Setting the new position, change the x,y  values in the end of each line to move the runes
RuneButtonIndividual1:SetPoint("CENTER", UIParent, "CENTER", -x1, y1)
RuneButtonIndividual2:SetPoint("CENTER", UIParent, "CENTER", -x2, y2)
RuneButtonIndividual5:SetPoint("CENTER", UIParent, "CENTER", -x3, y3)
RuneButtonIndividual6:SetPoint("CENTER", UIParent, "CENTER", x3, y3)
RuneButtonIndividual3:SetPoint("CENTER", UIParent, "CENTER", x2, y2)
RuneButtonIndividual4:SetPoint("CENTER", UIParent, "CENTER", x1, y1)

--Making the runes click through
RuneButtonIndividual1:EnableMouse(false)
RuneButtonIndividual2:EnableMouse(false)
RuneButtonIndividual3:EnableMouse(false)
RuneButtonIndividual4:EnableMouse(false)
RuneButtonIndividual5:EnableMouse(false)
RuneButtonIndividual6:EnableMouse(false)

RuneFrame:SetFrameStrata("HIGH")

local function Runehud_OnEvent(self, event, ...)
local arg1 = ...

	if event == "PLAYER_ENTERING_WORLD" then
		RuneFrame:SetFrameStrata("HIGH")
		RuneButtonIndividual1:ClearAllPoints()
		RuneButtonIndividual1:SetPoint("CENTER", UIParent, "CENTER", -x1, y1)
		
		if RHs == nil then
			RHs = 1.2
		end
		if RHaoc == nil then
			RHaoc = 0.1
		end
		if RHaic == nil then
			RHaic = 1
		end
		if RHaiv == nil then
			RHaiv = 0
		end
		if RHhoc == nil then
			RHhoc = "false"
		end
	end
	
	if (event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_REGEN_ENABLED") and not UnitInVehicleControlSeat("player") then
		RuneFrame:SetAlpha(RHaoc) 	
		RuneFrame:SetScale(RHs)		
	elseif event == "PLAYER_REGEN_DISABLED" and not UnitInVehicleControlSeat("player") then
		RuneFrame:SetAlpha(RHaic)
		RuneFrame:SetScale(RHs)
	end
	
	if ((event == "UNIT_ENTERING_VEHICLE") and UnitInVehicleControlSeat("player"))  then
		local unitID = ...
		if unitID == "player" then
			RuneFrame:SetAlpha(RHaiv)	
		end
	elseif event == "PLAYER_ENTERING_WORLD" then
		if InCombatLockdown() then
			RuneFrame:SetAlpha(RHaic)
			RuneFrame:SetScale(RHs)	
		else 
			RuneFrame:SetAlpha(RHaoc) 
			RuneFrame:SetScale(RHs)
		end
	elseif event == "UNIT_EXITED_VEHICLE" then
		local unitID = ...
		if unitID == "player" then
			if InCombatLockdown() then
				RuneFrame:SetAlpha(RHaic)
				RuneFrame:SetScale(RHs)
			else
				RuneFrame:SetAlpha(RHaoc) 
				RuneFrame:SetScale(RHs)
			end
		end
	end
	
	if RHhoc == "true" then
		if event == "PLAYER_REGEN_DISABLED" then 
			if GetRuneCooldown(1) > 0 then
				RuneButtonIndividual1:SetAlpha(RHaoc) else 
				RuneButtonIndividual1:SetAlpha(RHaic)
			end
			if GetRuneCooldown(2) > 0 then
				RuneButtonIndividual2:SetAlpha(RHaoc) else 
				RuneButtonIndividual2:SetAlpha(RHaic)
			end
			if GetRuneCooldown(3) > 0 then
				RuneButtonIndividual3:SetAlpha(RHaoc) else 
				RuneButtonIndividual3:SetAlpha(RHaic)
			end	
			if GetRuneCooldown(4) > 0 then
				RuneButtonIndividual4:SetAlpha(RHaoc) else 
				RuneButtonIndividual4:SetAlpha(RHaic)
			end
			if GetRuneCooldown(5) > 0 then
				RuneButtonIndividual5:SetAlpha(RHaoc) else 
				RuneButtonIndividual5:SetAlpha(RHaic)
			end
			if GetRuneCooldown(6) > 0 then
				RuneButtonIndividual6:SetAlpha(RHaoc) else 
				RuneButtonIndividual6:SetAlpha(RHaic)
			end
			
		elseif event == "RUNE_POWER_UPDATE" and InCombatLockdown() and not UnitInVehicleControlSeat("player") then
			local runeIndex, isEnergize = ...;
			local runeButton = _G["RuneButtonIndividual"..runeIndex];
			local start, duration, runeReady = GetRuneCooldown(runeIndex);
			print(GetTime(),runeIndex,start,duration,runeReady,isEnergize)
			if not runeReady and isEnergize == nil then
				
					runeButton:SetAlpha(RHaoc)
				
			else
				runeButton:SetAlpha(RHaic)
			end
		
			if isEnergize then
				runeButton:SetAlpha(RHaic)
			end
				
		elseif (event == "PLAYER_REGEN_ENABLED" and not UnitInVehicleControlSeat("player")) then
			RuneButtonIndividual1:SetAlpha(RHaic)
			RuneButtonIndividual2:SetAlpha(RHaic)
			RuneButtonIndividual3:SetAlpha(RHaic)
			RuneButtonIndividual4:SetAlpha(RHaic)
			RuneButtonIndividual5:SetAlpha(RHaic)
			RuneButtonIndividual6:SetAlpha(RHaic)
		elseif event == "UNIT_EXITED_VEHICLE" then
			local unitID = ...
			if unitID == "player" then
				RuneButtonIndividual1:SetAlpha(RHaic)
				RuneButtonIndividual2:SetAlpha(RHaic)
				RuneButtonIndividual3:SetAlpha(RHaic)
				RuneButtonIndividual4:SetAlpha(RHaic)
				RuneButtonIndividual5:SetAlpha(RHaic)
				RuneButtonIndividual6:SetAlpha(RHaic)
			end
		end
	end
end


local f = CreateFrame("Frame","RuneHUDFrame",UIParent)
f:RegisterEvent("PLAYER_REGEN_DISABLED")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("UNIT_EXITED_VEHICLE")
f:RegisterEvent("UNIT_ENTERING_VEHICLE")
f:RegisterEvent("RUNE_POWER_UPDATE")
f:RegisterEvent("RUNE_TYPE_UPDATE");
f:RegisterEvent("RUNE_REGEN_UPDATE");
f:SetScript("OnEvent", Runehud_OnEvent)
RuneFrame:SetParent(RuneHUDFrame)
