--[[
 < ResourcesOnTop v0.1 Beta >
______________________________
 Author: Spyro
License: All Rights Reserved
Contact: Spyr�  @ ArenaJunkies
         Spyro  @ WowInterface
         Spyro_ @ Curse/WowAce
������������������������������
]]

local Addon = CreateFrame("Frame") -- Addon main frame

-- Event registration
Addon:SetScript("OnEvent", function(self, event, ...) return self[event](self, ...) end)
Addon:RegisterEvent("PLAYER_LOGIN")

-- yOffset()
-- Changes the vertical offset of the anchor of a frame.
-- > Frame: Frame reference
-- > Offset: Vertical offset
local function yOffset(Frame, Offset)
  local P = { Frame:GetPoint() }
  Frame:SetPoint(P[1], P[2], P[3], P[4], Offset)
end

-- yInvertTexture()
-- Inverts a texture vertically.
-- > Texture: Texture reference
local function yInvertTexture(Texture)
  local Left, Top, _, Bottom, Right = Texture:GetTexCoord()
  Texture:SetTexCoord(Left, Right, Bottom, Top) -- Swapping parameters 3 & 4 (top & bottom)
end

-- yInvertAllTextures()
-- Inverts vertically all the child textures of a frame.
-- > Frame: Frame reference
local function yInvertAllTextures(Frame)
  for _, Region in pairs({ Frame:GetRegions() }) do
    if Region:GetObjectType() == "Texture" then yInvertTexture(Region) end
  end
end

-- Evento PLAYER_LOGIN
-- Fires after PLAYER_ENTERING_WORLD after logging in and after /reloadui.
function Addon:PLAYER_LOGIN()
  -- Paladin Holy Power
  yOffset(PaladinPowerBar, 111)
  yOffset(PaladinPowerBarRune1, -5)
  yOffset(PaladinPowerBarRune4, 3)
  yOffset(PaladinPowerBarRune5, 3)
  yOffset(PaladinPowerBarBankBG, 7)
  yInvertAllTextures(PaladinPowerBar)
  yInvertTexture(PaladinPowerBarGlowBGTexture)
  for i = 1, 5 do yInvertTexture(_G["PaladinPowerBarRune"..i.."Texture"]) end

  -- Priest Shadow Orbs
  yOffset(PriestBarFrame, 131)
  yOffset(PriestBarFrameOrb1, -16)
  yInvertAllTextures(PriestBarFrame)
  for i = 1, 3 do
    yInvertAllTextures(_G["PriestBarFrameOrb"..i])
    yOffset(_G["PriestBarFrameOrb"..i].highlight, 8)
  end

  -- Warlock Shards
  yOffset(ShardBarFrame, 69)
  for i = 1, 4 do
    yInvertAllTextures(_G["ShardBarFrameShard"..i])
    yOffset(_G["ShardBarFrameShard"..i].shardFill, -5)
  end

  -- Warlock Burning Embers
  yOffset(BurningEmbersBarFrame, 63)
  yOffset(BurningEmbersBarFrameEmber1, 14)
  yInvertTexture(BurningEmbersBarFrame.background)
  for i = 1, 4 do yInvertAllTextures(_G["BurningEmbersBarFrameEmber"..i]) end

  -- Warlock Demonic Fury
  yOffset(DemonicFuryBarFrame, 82)

  -- DK Runes
  yOffset(RuneFrame, 99)

  -- Druid Eclipse
  yOffset(EclipseBarFrame, 108)

  -- Druid/Monk AlternatePowerBar
  yInvertAllTextures(PlayerFrameAlternateManaBar)
  yOffset(PlayerFrameAlternateManaBar, 79)
  yOffset(PlayerFrameAlternateManaBar.DefaultBorder, 4)
  yOffset(PlayerFrameAlternateManaBar.MonkBorder, 4)
  yOffset(PlayerFrameAlternateManaBar.MonkBackground, 4)
  local Offset = 79
  if MonkHarmonyBar:IsShown() then Offset = 100 end
  hooksecurefunc(PlayerFrameAlternateManaBar, "SetPoint", function(Bar) yOffset(Bar, Offset) end)

  -- Monk Chi
  yOffset(MonkHarmonyBar, 20)
  yInvertAllTextures(MonkHarmonyBar)
  for i = 1, 4 do yInvertAllTextures(_G["MonkHarmonyBarLightEnergy"..i]) end

  -- Monk Stagger Bar
  yOffset(MonkStaggerBarText, -4)
  yInvertAllTextures(MonkStaggerBar)
  hooksecurefunc(MonkStaggerBar, "SetPoint", function(Bar) yOffset(Bar, 104) end)

  -- Shaman Totems / Warrior Banners
  yOffset(TotemFrame, 112)
  for i = 1, 4 do
    yOffset(_G["TotemFrameTotem"..i.."Duration"], 44)
    yInvertTexture(select(2, _G["TotemFrameTotem"..i]:GetChildren()):GetRegions())
  end
end