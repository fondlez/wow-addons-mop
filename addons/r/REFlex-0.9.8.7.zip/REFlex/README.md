﻿# REFlex

[Curse](http://www.curse.com/addons/wow/reflex-battleground-historian)

[WoWInterface](http://www.wowinterface.com/downloads/info19190-REFlex-ArenaBattlegroundHistorian.html)

## COPYRIGHT

All Rights Reserved unless otherwise explicitly stated.

Copyright (c) 2013-2014 Paweł Jastrzębski <pawelj@iosphe.re>