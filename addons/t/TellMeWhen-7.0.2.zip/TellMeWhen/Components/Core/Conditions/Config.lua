﻿-- --------------------
-- TellMeWhen
-- Originally by Nephthys of Hyjal <lieandswell@yahoo.com>

-- Other contributions by:
--		Sweetmms of Blackrock, Oozebull of Twisting Nether, Oodyboo of Mug'thol,
--		Banjankri of Blackrock, Predeter of Proudmoore, Xenyr of Aszune

-- Currently maintained by
-- Cybeloras of Aerie Peak/Detheroc/Mal'Ganis
-- --------------------


if not TMW then return end

local TMW = TMW
local L = TMW.L
local print = TMW.print

local CI = TMW.CI
local get = TMW.get

local _G = _G
local pairs, ipairs, wipe, tinsert, tremove, rawget, tonumber, tostring, type = 
	  pairs, ipairs, wipe, tinsert, tremove, rawget, tonumber, tostring, type
local strtrim, gsub, min, max = 
	  strtrim, gsub, min, max

-- GLOBALS: UIDROPDOWNMENU_MENU_LEVEL, UIDROPDOWNMENU_MENU_VALUE, UIDROPDOWNMENU_OPEN_MENU
-- GLOBALS: UIDropDownMenu_AddButton, UIDropDownMenu_CreateInfo, UIDropDownMenu_SetText, UIDropDownMenu_GetSelectedValue
-- GLOBALS: CloseDropDownMenus


TMW.HELP:NewCode("CNDT_UNIT_MISSING", 10, false)
TMW.HELP:NewCode("CNDT_UNIT_ONLYONE", 20, false)


local CNDT = TMW.CNDT -- created in TellMeWhen/conditions.lua



---------- Interface/Data ----------
function CNDT:LoadConfig(conditionSetName)
	local ConditionSet
	if conditionSetName then
		ConditionSet = CNDT.ConditionSets[conditionSetName]
	else
		ConditionSet = CNDT.CurrentConditionSet
	end
	
	CNDT.CurrentConditionSet = ConditionSet
	if not ConditionSet then return end
	
	if ConditionSet.useDynamicTab then
		if conditionSetName then
			CNDT.DynamicConditionTab:Show()
		
			-- Only click the tab if we are manually loading the conditionSet (should only happen on user input/hardware event)
			CNDT.DynamicConditionTab:ClickHandler()
			
			if ConditionSet.parentSettingType == "profile" then
				CNDT.DynamicConditionTab:SetTitleComponents(nil, nil)
			elseif ConditionSet.parentSettingType == "group" then
				CNDT.DynamicConditionTab:SetTitleComponents(nil, 1)
			else
				CNDT.DynamicConditionTab:SetTitleComponents(1, 1)
			end
			
		end
	else
		CNDT.DynamicConditionTab:Hide()
	end
	
	
	CNDT.settings = ConditionSet:GetSettings()	
	if not CNDT.settings then return end
	
	
	TMW.HELP:Hide("CNDT_UNIT_MISSING")
	
	local n = CNDT.settings.n
	
	for i = n + 1, #CNDT do
		CNDT[i]:Hide()
	end
		
	if n > 0 then
		CNDT:CreateGroups(n+1)

		for i in TMW:InNLengthTable(CNDT.settings) do
			CNDT[i]:Show()
			CNDT[i]:LoadAndDraw()
		end
	end
	
	local AddCondition = TellMeWhen_IconEditor.Conditions.Groups.AddCondition
	AddCondition:SetPoint("TOPLEFT", CNDT[n+1])
	AddCondition:SetPoint("TOPRIGHT", CNDT[n+1])
	
	CNDT:ColorizeParentheses()
end

TMW:RegisterCallback("TMW_CONFIG_ICON_LOADED", function()
	-- This is encapsulated in a function because LoadConfig excepts arg2 to be a conditionSetName,
	-- but it would end up being an event or an icon if CNDT.LoadConfig were registed as the callback.
	CNDT:LoadConfig()
end)



-- Dynamic Conditions Tab handling

CNDT.DynamicConditionTab = TMW.Classes.IconEditorTab:NewTab("CNDTDYN", 25, "Conditions")
CNDT.DynamicConditionTab:SetTitleComponents()
CNDT.DynamicConditionTab:Hide()

TMW:RegisterCallback("TMW_CONFIG_ICON_LOADED_CHANGED", function(event, icon)
	if TMW.IE.CurrentTab == CNDT.DynamicConditionTab then
		TMW.IE.MainTab:Click()
	end
end)
TMW:RegisterCallback("TMW_CONFIG_TAB_CLICKED", function(event, currentTab, oldTab)
	if oldTab == CNDT.DynamicConditionTab then
		CNDT.DynamicConditionTab:Hide()
	end
end)

local f = CreateFrame("Frame")
f:SetScript("OnUpdate", function()	
	local CurrentConditionSet = CNDT.CurrentConditionSet
	
	if CurrentConditionSet and CurrentConditionSet.useDynamicTab and CurrentConditionSet.ShouldShowTab then
		if not CurrentConditionSet:ShouldShowTab() then
			if TMW.IE.CurrentTab == CNDT.DynamicConditionTab then
				TMW.IE.MainTab:Click()
			else
				CNDT.DynamicConditionTab:Hide()
			end
		end
	else
		CNDT.DynamicConditionTab:Hide()
	end
end)



function CNDT:GetTabText(conditionSetName)
	local ConditionSet = CNDT.CurrentConditionSet
	if conditionSetName then
		ConditionSet = CNDT.ConditionSets[conditionSetName]
	end
	
	if not ConditionSet then
		return "<ERROR: SET NOT FOUND!>"
	end
	
	local Conditions = ConditionSet:GetSettings()
	local tabText = ConditionSet.tabText
	
	if not Conditions then
		return tabText .. " (0)"
	end
	
	local parenthesesAreValid, errorMessage = CNDT:CheckParentheses(Conditions)
		
	if parenthesesAreValid then
		TMW.HELP:Hide("CNDT_PARENTHESES_ERROR")
	else
		TMW.HELP:Show{
			code = "CNDT_PARENTHESES_ERROR",
			icon = nil,
			relativeTo = TellMeWhen_IconEditor.Conditions,
			x = 0,
			y = 0,
			text = format(errorMessage)
		}
	end
	
	local n = Conditions.n

	if n > 0 then
		local prefix = (not parenthesesAreValid and "|TInterface\\AddOns\\TellMeWhen\\Textures\\Alert:0:2|t|cFFFF0000" or "")
		return prefix .. tabText .. " |cFFFF5959(" .. n .. ")"
	else
		return tabText .. " (" .. n .. ")"
	end
end

function CNDT:SetTabText(conditionSetName)
	local ConditionSet = CNDT.ConditionSets[conditionSetName] or CNDT.CurrentConditionSet
	
	local tab = ConditionSet.useDynamicTab and CNDT.DynamicConditionTab or ConditionSet:GetTab()
	
	tab:SetText(CNDT:GetTabText(conditionSetName))
	TMW:TT(tab, ConditionSet.tabText, ConditionSet.tabTooltip, 1, 1)
end


TMW:NewClass("Config_Slider_Condition", "Config_Slider")
{
	GetSettingTable = function(self)
		return self:GetParent():GetConditionSettings()
	end,


}

function CNDT:ValidateLevelForCondition(level, conditionType)
	local conditionData = CNDT.ConditionsByType[conditionType]
	
	if not conditionData then
		return level
	end
	
	level = tonumber(level) or 0
	
	-- Round to the nearest step
	local step = get(conditionData.step) or 1
	level = floor(level * (1/step) + 0.5) / (1/step)
	
	-- Constrain to min/max
	local vmin = get(conditionData.min or 0)
	local vmax = get(conditionData.max)
	if vmin and level < vmin then
		level = vmin
	elseif vmax and level > vmax then
		level = vmax
	end
	
	--level = max(level, 0)
	
	return level
end



---------- Dropdowns ----------
local addedThings = {}
local usedCount = {}
local commonConditions = {
	"COMBAT",
	"VEHICLE",
	"HEALTH",
	"DEFAULT",
	"STANCE",
}

local function AddConditionToDropDown(conditionData)
	local append = TMW.debug and not conditionData:ShouldList() and "(DBG)" or ""
	
	local info = UIDropDownMenu_CreateInfo()
	
	info.func = CNDT.TypeMenu_DropDown_OnClick
	info.text = (conditionData.text or "??") .. append
	
	info.tooltipTitle = conditionData.text
	info.tooltipText = conditionData.tooltip
	info.tooltipOnButton = true
	
	info.value = conditionData.identifier
	info.arg1 = conditionData
	info.icon = get(conditionData.icon)

	info.disabled = get(conditionData.disabled)
	
	if conditionData.tcoords then
		info.tCoordLeft = conditionData.tcoords[1]
		info.tCoordRight = conditionData.tcoords[2]
		info.tCoordTop = conditionData.tcoords[3]
		info.tCoordBottom = conditionData.tcoords[4]
	end
	
	UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
end


function CNDT:TypeMenu_DropDown()	
	if UIDROPDOWNMENU_MENU_LEVEL == 1 then
		local canAddSpacer
		for k, categoryData in ipairs(CNDT.Categories) do
			
			if categoryData.spaceBefore and canAddSpacer then
				TMW.AddDropdownSpacer()
			end

			local shouldAddCategory
			local CurrentConditionSet = CNDT.CurrentConditionSet
			
			for k, conditionData in ipairs(categoryData.conditionData) do
				if not conditionData.IS_SPACER then
					local shouldAdd = conditionData:ShouldList()
					
					if CurrentConditionSet.ConditionTypeFilter then
						if not CurrentConditionSet:ConditionTypeFilter(conditionData) then
							shouldAdd = false
						end
					end
					
					if shouldAdd then
						shouldAddCategory = true
						break
					end
				end
			end
			
			local info = UIDropDownMenu_CreateInfo()
			info.text = categoryData.name
			info.value = categoryData.identifier
			info.notCheckable = true
			info.hasArrow = shouldAddCategory
			info.disabled = not shouldAddCategory
			UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
			canAddSpacer = true
			
			if categoryData.spaceAfter and canAddSpacer then
				TMW.AddDropdownSpacer()
				canAddSpacer = false
			end
		end
		
	elseif UIDROPDOWNMENU_MENU_LEVEL == 2 then
		local categoryData = CNDT.CategoriesByID[UIDROPDOWNMENU_MENU_VALUE]
		
		local queueSpacer
		local hasAddedOneCondition
		local lastButtonWasSpacer
		
		local CurrentConditionSet = CNDT.CurrentConditionSet
		
		for k, conditionData in ipairs(categoryData.conditionData) do
			if conditionData.IS_SPACER then
				queueSpacer = true
			else
				local shouldAdd = conditionData:ShouldList() --or TMW.debug
				
				if shouldAdd and not conditionData.IS_SPACER and CurrentConditionSet.ConditionTypeFilter then
					if not CurrentConditionSet:ConditionTypeFilter(conditionData) then
						shouldAdd = false
					end
				end
				
				if shouldAdd then
					if hasAddedOneCondition and queueSpacer then
						TMW.AddDropdownSpacer()
						queueSpacer = false
					end
					
					AddConditionToDropDown(conditionData)
					hasAddedOneCondition = true
				end
			end
		end
	end
end

function CNDT:TypeMenu_DropDown_OnClick(data)
	UIDROPDOWNMENU_OPEN_MENU.selectedValue = self.value
	UIDropDownMenu_SetText(UIDROPDOWNMENU_OPEN_MENU, data.text)
	
	local group = UIDROPDOWNMENU_OPEN_MENU:GetParent()
	
	local condition = group:GetConditionSettings()
	if data.defaultUnit and condition.Unit == "player" then
		condition.Unit = data.defaultUnit
	end

	get(data.applyDefaults, data, condition)

	condition.Type = self.value
	
	group:LoadAndDraw()
	
	CloseDropDownMenus()
end


function CNDT:IconMenu_DropDown()
	if UIDROPDOWNMENU_MENU_LEVEL == 2 then
		for icon in UIDROPDOWNMENU_MENU_VALUE:InIcons() do
			if icon:IsValid() and CI.icon ~= icon and not icon:IsControlled() then
				local info = UIDropDownMenu_CreateInfo()

				local text, textshort, tooltip = icon:GetIconMenuText()
				info.text = textshort
				info.tooltipTitle = text
				info.tooltipText = tooltip
				info.tooltipOnButton = true

				info.arg1 = self
				info.value = icon
				info.func = CNDT.IconMenu_DropDown_OnClick

				local group = self:GetParent()
				local condition = group:GetConditionSettings()
				info.checked = condition.Icon == icon:GetGUID()

				info.tCoordLeft = 0.07
				info.tCoordRight = 0.93
				info.tCoordTop = 0.07
				info.tCoordBottom = 0.93
				info.icon = icon.attributes.texture
				UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
			end
		end
	elseif UIDROPDOWNMENU_MENU_LEVEL == 1 then
		for group in TMW:InGroups() do
			if group:ShouldUpdateIcons() then
				local info = UIDropDownMenu_CreateInfo()
				info.text = group:GetGroupName()
				info.hasArrow = true
				info.notCheckable = true
				info.value = group
				UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)
			end
		end
	end
end

function CNDT:IconMenu_DropDown_OnClick(frame)
	CloseDropDownMenus()
	
	local icon = self.value
	local GUID = icon:GetGUID(true)
	
	frame:SetIcon(icon)

	local group = UIDROPDOWNMENU_OPEN_MENU:GetParent()
	local condition = group:GetConditionSettings()
	condition.Icon = GUID
end


function CNDT:OperatorMenu_DropDown()
	local conditionData = self:GetParent():GetConditionData()

	for k, v in pairs(TMW.operators) do
		if (not conditionData.specificOperators or conditionData.specificOperators[v.value]) then
			local info = UIDropDownMenu_CreateInfo()
			info.func = CNDT.OperatorMenu_DropDown_OnClick
			info.text = v.text
			info.value = v.value
			info.tooltipTitle = v.tooltipText
			info.tooltipOnButton = true
			info.arg1 = self
			UIDropDownMenu_AddButton(info)
		end
	end
end

function CNDT:OperatorMenu_DropDown_OnClick(frame)
	frame:SetUIDropdownText(self.value)
	TMW:TT(frame, self.tooltipTitle, nil, 1)
	
	local group = UIDROPDOWNMENU_OPEN_MENU:GetParent()
	local condition = group:GetConditionSettings()
	condition.Operator = self.value
end


---------- Runes ----------
function CNDT:RuneHandler(rune)
	local id = rune:GetID()
	local pair
	if id > 6 then
		pair = _G[gsub(rune:GetName(), "Death", "")]
	else
		pair = _G[rune:GetName() .. "Death"]
	end
	if rune:GetChecked() ~= nil then
		pair:SetChecked(nil)
	end
end

function CNDT:Rune_GetChecked()
	return self.checked
end

function CNDT:Rune_SetChecked(checked)
	self.checked = checked
	if checked then
		self.Check:SetTexture("Interface\\RAIDFRAME\\ReadyCheck-Ready")
	elseif checked == nil then
		self.Check:SetTexture(nil)
	elseif checked == false then
		self.Check:SetTexture("Interface\\RAIDFRAME\\ReadyCheck-NotReady")
	end
end


---------- Parentheses ----------
CNDT.colors = setmetatable(
	{ -- hardcode the first few colors to make sure they look good
		"|cff00ff00",
		--"|cff0026ff",
		"|cffff004d",
		"|cff009bff",
		"|cffe9ff00",
		--"|cff00ff7c",
		"|cffff6700",
		"|cffaf79ff",
		"|cffff00c2",
	},
	{ __index = function(t, k)
		-- start reusing colors
		if k < 1 then return "" end
		while k >= #t do
			k = k - #t
		end
		return rawget(t, k) or ""
end})

function CNDT:ColorizeParentheses()
	if not TellMeWhen_IconEditor.Conditions:IsShown() then return end

	CNDT.Parens = wipe(CNDT.Parens or {})

	for k, v in ipairs(CNDT) do
		if v:IsShown() then
			if v.OpenParenthesis:IsShown() then
				for k, v in ipairs(v.OpenParenthesis) do
					v.text:SetText("|cff222222" .. v.type)
					if v:GetChecked() then
						tinsert(CNDT.Parens, v)
					end
				end
			end

			if v.CloseParenthesis:IsShown() then
				for k = #v.CloseParenthesis, 1, -1 do
					local v = v.CloseParenthesis[k]
					v.text:SetText("|cff222222" .. v.type)
					if v:GetChecked() then
						tinsert(CNDT.Parens, v)
					end
				end
			end
		end
	end

	while true do
		local numopen, nestinglevel, open, currentcolor = 0, 0
		for i, v in ipairs(CNDT.Parens) do
			if v == true then
				nestinglevel = nestinglevel + 1
			elseif v == false then
				nestinglevel = nestinglevel - 1
			elseif v.type == "(" then
				numopen = numopen + 1
				nestinglevel = nestinglevel + 1
				if not open then
					open = i
					CNDT.Parens[open].text:SetText(CNDT.colors[nestinglevel] .. "(")
					currentcolor = nestinglevel
				end
			else
				numopen = numopen - 1
				nestinglevel = nestinglevel - 1
				if open and numopen == 0 then
					CNDT.Parens[i].text:SetText(CNDT.colors[currentcolor] .. ")")
					CNDT.Parens[i] = false
					break
				end
			end
		end
		if open then
			CNDT.Parens[open] = true
		else
			break
		end
	end
	for i, v in ipairs(CNDT.Parens) do
		if type(v) == "table" then
			v.text:SetText(v.type)
		end
	end

	CNDT:SetTabText()
end


---------- Condition Groups ----------
function CNDT:CreateGroups(num)
	local start = #CNDT + 1

	for i=start, num do
		TMW.Classes.CndtGroup:New("Frame", "TellMeWhen_IconEditorConditionsGroupsGroup" .. i, TellMeWhen_IconEditor.Conditions.Groups, "TellMeWhen_ConditionGroup", i)
	end
end

function CNDT:AddCondition(Conditions)
	Conditions.n = Conditions.n + 1
	
	TMW:Fire("TMW_CNDT_CONDITION_ADDED", Conditions[Conditions.n])
	
	return Conditions[Conditions.n]
end

function CNDT:DeleteCondition(Conditions, n)
	Conditions.n = Conditions.n - 1
	
	TMW:Fire("TMW_CNDT_CONDITION_DELETED", n)
	
	return tremove(Conditions, n)
end


---------- CndtGroup Class ----------
local CndtGroup = TMW:NewClass("CndtGroup", "Frame")

function CndtGroup:OnNewInstance()
	local ID = self:GetID()
	
	CNDT[ID] = self

	self:SetPoint("TOPLEFT", CNDT[ID-1], "BOTTOMLEFT", 0, -16.5)

	--[[local p, _, rp, x, y = TMW.CNDT[1].AddDelete:GetPoint()
	self.AddDelete:ClearAllPoints()
	self.AddDelete:SetPoint(p, CNDT[ID], rp, x, y)]]
	
	self:Hide()
	
	TMW:RegisterCallback("TMW_CONFIG_SAVE_SETTINGS", self.Unit, "ClearFocus")
	TMW:RegisterCallback("TMW_CONFIG_SAVE_SETTINGS", self.EditBox, "ClearFocus")
	TMW:RegisterCallback("TMW_CONFIG_SAVE_SETTINGS", self.EditBox2, "ClearFocus")
end

function CndtGroup:LoadAndDraw()
	local conditionData = self:GetConditionData()
	local conditionSettings = self:GetConditionSettings()
	
	TMW:Fire("TMW_CNDT_GROUP_DRAWGROUP", self, conditionData, conditionSettings)
end

-- LoadAndDraw handlers:
-- Unit
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)
	if conditionData then
		local unit = conditionData.unit
	
		if unit == nil then
			-- Normal unit input and configuration
			CndtGroup.Unit:Show()
			CndtGroup.Unit:SetText(conditionSettings.Unit)
			
			CndtGroup.TextUnitDef:SetText(nil)
			CndtGroup.TextUnit:SetText(L["CONDITIONPANEL_UNIT"])
			
			-- Set default behavior for the editbox. This all may be overridden by other callbacks if needed.
			TMW.SUG:EnableEditBox(CndtGroup.Unit, "units", true)
			CndtGroup.Unit.label = "|cFFFF5050" .. TMW.L["CONDITIONPANEL_UNIT"] .. "!|r"
			TMW:TT(CndtGroup.Unit, "CONDITIONPANEL_UNIT", "ICONMENU_UNIT_DESC_CONDITIONUNIT")
			
		elseif unit == false then
			-- No unit, hide editbox and static text
			CndtGroup.Unit:Hide()
			
			CndtGroup.TextUnit:SetText(nil)
			CndtGroup.TextUnitDef:SetText(nil)
			
		elseif type(unit) == "string" then
			-- Static text in place of the editbox
			CndtGroup.Unit:Hide()
			
			CndtGroup.TextUnit:SetText(L["CONDITIONPANEL_UNIT"])
			CndtGroup.TextUnitDef:SetText(unit)
		end
	else
		CndtGroup.Unit:Hide()
		
		CndtGroup.TextUnit:SetText(nil)
		CndtGroup.TextUnitDef:SetText(nil)
	end
end)

-- Type
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)
	CndtGroup.Type:Show()
	CndtGroup.TextType:SetText(L["CONDITIONPANEL_TYPE"])

	CndtGroup.Type.selectedValue = conditionSettings.Type
	UIDropDownMenu_SetText(CndtGroup.Type, conditionData and conditionData.text or conditionSettings.Type)
end)

-- Operator
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)
	if not conditionData or conditionData.nooperator then
		CndtGroup.TextOperator:SetText(nil)
		CndtGroup.Operator:Hide()
	else
		CndtGroup.TextOperator:SetText(L["CONDITIONPANEL_OPERATOR"])
		CndtGroup.Operator:Show()

		local v = CndtGroup.Operator:SetUIDropdownText(conditionSettings.Operator, TMW.operators)
		if v then
			TMW:TT(CndtGroup.Operator, v.tooltipText, nil, 1)
		end
	end
end)

-- Icon
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)

	if conditionData and conditionData.isicon then
		local GUID = conditionSettings.Icon
		CndtGroup.Icon:SetGUID(GUID)

		CndtGroup.TextIcon:SetText(L["ICONTOCHECK"])
		CndtGroup.Icon:Show()
		if conditionData.nooperator then
			CndtGroup.Icon:SetWidth(196)
		else
			CndtGroup.Icon:SetWidth(134)
		end
	else
		CndtGroup.TextIcon:SetText(nil)
		CndtGroup.Icon:Hide()
	end
end)

-- Runes
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)

	for k, rune in pairs(CndtGroup.Runes) do
		if type(rune) == "table" then
			rune:SetChecked(conditionSettings.Runes[rune:GetID()])
		end
	end
end)

-- Parentheses
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)

	for k, frame in pairs(CndtGroup.OpenParenthesis) do
		if type(frame) == "table" then
			CndtGroup.OpenParenthesis[k]:SetChecked(conditionSettings.PrtsBefore >= k)
		end
	end
	for k, frame in pairs(CndtGroup.CloseParenthesis) do
		if type(frame) == "table" then
			CndtGroup.CloseParenthesis[k]:SetChecked(conditionSettings.PrtsAfter >= k)
		end
	end
	
	if CNDT.settings.n >= 3 then
		CndtGroup.CloseParenthesis:Show()
		CndtGroup.OpenParenthesis:Show()
	else
		CndtGroup.CloseParenthesis:Hide()
		CndtGroup.OpenParenthesis:Hide()
	end
	
	if CndtGroup:GetID() == 3 and CndtGroup:IsVisible() then
		TMW.HELP:Show{
			code = "CNDT_PARENTHESES_FIRSTSEE",
			icon = nil,
			relativeTo = CNDT[1].OpenParenthesis,
			x = 0,
			y = 0,
			text = format(TMW.L["HELP_CNDT_PARENTHESES_FIRSTSEE"])
		}
	end
end)
TMW.HELP:NewCode("CNDT_PARENTHESES_FIRSTSEE", 101, true)

-- Up/Down
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)

	local ID = CndtGroup:GetID()
	local n = CNDT.settings.n
	
	if ID == 1 then
		CndtGroup.Up:Hide()
	else
		CndtGroup.Up:Show()
	end
	if ID == n then
		CndtGroup.Down:Hide()
	else
		CndtGroup.Down:Show()
	end
end)

-- And/Or
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)

	CndtGroup.AndOr:SetValue(conditionSettings.AndOr)
	
	if CndtGroup:GetID() == 2 and CndtGroup:IsVisible() then
		TMW.HELP:Show{
			code = "CNDT_ANDOR_FIRSTSEE",
			icon = nil,
			relativeTo = CndtGroup.AndOr,
			x = 0,
			y = 0,
			text = format(TMW.L["HELP_CNDT_ANDOR_FIRSTSEE"])
		}
	end
end)
TMW.HELP:NewCode("CNDT_ANDOR_FIRSTSEE", 100, true)

-- Second Row
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)
	if conditionData then
		if conditionData.name then
			CndtGroup.EditBox:Show()
			CndtGroup.EditBox:SetText(conditionSettings.Name)
		
			if type(conditionData.name) == "function" then
				conditionData.name(CndtGroup.EditBox)
				CndtGroup.EditBox:GetScript("OnTextChanged")(CndtGroup.EditBox)
			else
				TMW:TT(CndtGroup.EditBox, nil, nil)
			end
			if conditionData.check then
				conditionData.check(CndtGroup.Check)
				CndtGroup.Check:Show()
				CndtGroup.Check:SetChecked(conditionSettings.Checked)
			else
				CndtGroup.Check:Hide()
			end
			TMW.SUG:EnableEditBox(CndtGroup.EditBox, conditionData.useSUG, not conditionData.allowMultipleSUGEntires)

			CndtGroup.Slider:SetWidth(217)
			if conditionData.noslide then
				CndtGroup.EditBox:SetWidth(520)
			else
				CndtGroup.EditBox:SetWidth(295)
			end
		else
			CndtGroup.EditBox:Hide()
			CndtGroup.Check:Hide()
			CndtGroup.Slider:SetWidth(522)
			TMW.SUG:DisableEditBox(CndtGroup.EditBox)
		end
		
		if conditionData.name2 then
			CndtGroup.EditBox2:Show()
			CndtGroup.EditBox2:SetText(conditionSettings.Name2)
		
			if type(conditionData.name2) == "function" then
				conditionData.name2(CndtGroup.EditBox2)
				CndtGroup.EditBox2:GetScript("OnTextChanged")(CndtGroup.EditBox2)
			else
				TMW:TT(CndtGroup.EditBox2, nil, nil)
			end
			if conditionData.check2 then
				conditionData.check2(CndtGroup.Check2)
				CndtGroup.Check2:Show()
				CndtGroup.Check2:SetChecked(conditionSettings.Checked2)
			else
				CndtGroup.Check2:Hide()
			end
			TMW.SUG:EnableEditBox(CndtGroup.EditBox2, conditionData.useSUG, not conditionData.allowMultipleSUGEntires)
			CndtGroup.EditBox:SetWidth(250)
			CndtGroup.EditBox2:SetWidth(250)
		else
			CndtGroup.Check2:Hide()
			CndtGroup.EditBox2:Hide()
			TMW.SUG:DisableEditBox(CndtGroup.EditBox2)
		end

		

		if conditionData.noslide then
			CndtGroup.Slider:Hide()
			
			CndtGroup.TextValue:SetText(nil)
			CndtGroup.ValText:Hide()
		else
			CndtGroup.TextValue:SetText(L["CONDITIONPANEL_VALUEN"])
			
			
			
			
			


			-- Don't try and format text while changing parameters because we might get some errors trying
			-- to format unexpected values
			CndtGroup.Slider:SetTextFormatter(nil)

			CndtGroup.Slider:SetValueStep(get(conditionData.step) or 1)
			CndtGroup.Slider:SetMinMaxValues(get(conditionData.min) or 0, get(conditionData.max))

			if get(conditionData.range) then
				CndtGroup.Slider:SetMode(CndtGroup.Slider.MODE_ADJUSTING)
				CndtGroup.Slider:SetRange(get(conditionData.range))
			else
				CndtGroup.Slider:SetMode(CndtGroup.Slider.MODE_STATIC)
			end
			CndtGroup.Slider:Show()
			CndtGroup.Slider:ReloadSetting()
			CndtGroup.Slider:SaveSetting()

			TMW:TT_Update(CndtGroup.Slider)


			CndtGroup.Slider:SetTextFormatter(conditionData.formatter)

			if conditionData.midt then
				local min, max = CndtGroup.Slider:GetMinMaxValues()
				local mid = ((max-min)/2)+min
				if conditionData.midt == true then
					mid = conditionData.formatter:Format(mid)
				else
					mid = get(conditionData.midt, mid)
				end

				CndtGroup.Slider:SetStaticMidText(mid)
			else
				CndtGroup.Slider:SetStaticMidText("")
			end

			local val = CndtGroup.Slider:GetValue()
			conditionData.formatter:SetFormattedText(CndtGroup.ValText, val)
			CndtGroup.ValText:Show()
			

		end
	else
		CndtGroup.TextValue:SetText(nil)
		CndtGroup.Check:Hide()
		CndtGroup.EditBox:Hide()
		CndtGroup.Check2:Hide()
		CndtGroup.EditBox2:Hide()
		CndtGroup.Slider:Hide()
		CndtGroup.ValText:Hide()
	end

end)

-- Deprecated/Unknown
TMW:RegisterCallback("TMW_CNDT_GROUP_DRAWGROUP", function(event, CndtGroup, conditionData, conditionSettings)
	if conditionData then
		CndtGroup.Unknown:SetText()

		if conditionData.funcstr == "DEPRECATED" then
			CndtGroup.Deprecated:SetFormattedText(TMW.L["CNDT_DEPRECATED_DESC"], get(conditionData.text))

			if not CndtGroup.Deprecated:IsShown() then
				-- Need to reset the height to 0 before calling GetStringHeight
				-- for consistency. Causes weird behavior if we don't do this.
				CndtGroup.Deprecated:SetHeight(0)
				CndtGroup.Deprecated:SetHeight(CndtGroup.Deprecated:GetStringHeight())

				CndtGroup:SetHeight(CndtGroup:GetHeight() + CndtGroup.Deprecated:GetHeight())
				CndtGroup.Deprecated:Show()
			end
		else
			if CndtGroup.Deprecated:IsShown() then
				CndtGroup:SetHeight(CndtGroup:GetHeight() - CndtGroup.Deprecated:GetHeight())
				CndtGroup.Deprecated:Hide()
			end
		end
	else
		CndtGroup.Unknown:SetFormattedText(TMW.L["CNDT_UNKNOWN_DESC"], conditionSettings.Type)
	end
end)


function CndtGroup:UpOrDown(delta)
	local ID = self:GetID()
	local settings = CNDT.settings
	local curdata, destinationdata
	curdata = settings[ID]
	destinationdata = settings[ID+delta]
	settings[ID] = destinationdata
	settings[ID+delta] = curdata
	CNDT:LoadConfig()
end

function CndtGroup:DeleteHandler()
	CNDT:DeleteCondition(CNDT.settings, self:GetID())
	CNDT:LoadConfig()
end

function CndtGroup:GetConditionSettings()
	if CNDT.settings then
		return CNDT.settings[self:GetID()]
	end
end

function CndtGroup:GetConditionData()
	local condition = self:GetConditionSettings()
	if condition then
		return CNDT.ConditionsByType[condition.Type]
	end
end


