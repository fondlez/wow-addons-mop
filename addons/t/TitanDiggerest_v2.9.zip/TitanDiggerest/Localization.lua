﻿--[[
LOCALIZATION for          ЛОКАЛИЗАЦИЯ для
TitanPanel: Diggerest     TitanPanel: Адоискатель

Author/Автор:  Wishko (Вишмастер, RU-Термоштепсель)
E-mail/Мыло:   Wish1250@gmail.com
Locales/Языки: RU,EN
]]--

-- Общая
local L = LibStub("AceLocale-3.0"):NewLocale("TitanDiggerest","enUS",true)
if L then 
L["menu"]      = "|cffff0000D|cffff4f00i|cffff9900g|cffffd800g|cffeeee00er|cffffff00es|cfffffffft|r"
L["About"]     = " by |cffff8c00Wishmaster|r (ru-Thermaplugg)"
L["race"]      = "Race:"
L["total"]     = "Total:"
L["cmn"]       = "cmn   "
L["rar"]       = "rare "
L["ttl"]       = "  all "  --англ вер. отличается кол-вом пробелов!
L["frg"]       = " fragm "
L["notLearned"]= "You haven't yet learned [Archaeology] skill.\nPlease, contact the Profession teacher."
L["frag"]      = "Fragments"
L["Dwarf"]     = "Dwarf"
L["Draenei"]   = "Draenei"
L["Fossil"]    = "Fossil"
L["NightElf"]  = "Night Elf"
L["Nerubian"]  = "Nerubian"
L["Orc"]       = "Orc"
L["Tol'Vir"]   = "Tol'Vir"
L["Troll"]     = "Troll"
L["Vrykul"]    = "Vrykul"
L["Other"]     = "Other"
L["Pandaren"]  = "Pandaren"
L["Mogu"]      = "Mogu"
L["Mantid"]    = "Mantid"
L["lastUniq"]  = "Last Unique:"
L["print"]     = "Print"
L["printMSG"]  = "|cffffffffCommon |cff00ffffRare |cff00ff00Total"
L["printMSG2"] = "Common Rare Total"
L["Report"]    = "Announce"
L["Guild"]     = "Guild"
L["Party"]     = "Party"
L["Raid"]      = "Raid"
L["Say"]       = "Say"
L["Yell"]      = "Yell"
L["Whisper"]   = "Whisper"
L["BG"]        = "Battleground"
L["SendMSG"]   = "Send Message:"
L["Send"]      = "Send"
L["Cancel"]    = "Cancel"
L["Hide"]      = "Hide"
L["skill"]     = "Skill:"
L["unknown"]   = "unknown"
end

-- Русская
local L = LibStub("AceLocale-3.0"):NewLocale("TitanDiggerest","ruRU")
if L then
L["menu"]      = "|cffff0000А|cffff4f00д|cffff7F24ои|cffff9900с|cffffd800ка|cffeeee00т|cffffff00ел|cffffffffь|r"
L["About"]     = " от |cffff8c00Вишмастер|rа (ru-Термоштепсель)"
L["race"]      = "Раса: "
L["total"]     = "Всего: "
L["cmn"]       = "обыч  "
L["rar"]       = "редк"
L["ttl"]       = "  все"  --англ вер. отличается кол-вом пробелов!
L["frg"]       = "фрагм "
L["notLearned"]= "Вы еще не изучили навык [Археологии].\nОбратитесь к учителю профессии."
L["frag"]      = "Фрагменты"
L["Dwarf"]     = "Дворфы"
L["Draenei"]   = "Дренеи"
L["Fossil"]    = "Окаменелости"
L["NightElf"]  = "Ночные эльфы"
L["Nerubian"]  = "Нерубы"
L["Orc"]       = "Орки"
L["Tol'Vir"]   = "Тол'виры"
L["Troll"]     = "Тролли"
L["Vrykul"]    = "Врайкулы"
L["Other"]     = "Другие"
L["Pandaren"]  = "Пандарены"
L["Mogu"]      = "Могу"
L["Mantid"]    = "Богомолы"
L["lastUniq"]  = "Уникальный:"
L["print"]     = "Печать"
L["printMSG"]  = "|cffffffffОбычные |cff00ffffРедкие |cff00ff00Все"
L["printMSG2"] = "Обычные Редкие Все"
L["Report"]    = "Сообщить"
L["Guild"]     = "Гильдия"
L["Party"]     = "Группа"
L["Raid"]      = "Рейд"
L["Say"]       = "Сказать"
L["Yell"]      = "Крикнуть"
L["Whisper"]   = "Шепнуть"
L["BG"]        = "Поле боя"
L["SendMSG"]   = "Отправить сообщение:"
L["Send"]      = "Отправить"
L["Cancel"]    = "Отмена"
L["Hide"]      = "Скрыть"
L["skill"]     = "Навык:"
L["unknown"]   = "неизвестно"
end