--[[Name: TranqShotMonitor
Description: Gives a message when tranquilizing Shot has dispelled succesfully, together with which buff was dispelled ]]

local defaults = { Point = "TOP", relativePoint = "TOP", xOfs = 0, yOfs = -150, active = true, activechannel = false, TRchannel = "SAY", autochannel = false, silence = false, selfPrint = false, WarningColorr = 1, WarningColorg = 1, WarningColorb = 1, WarningColora = 1, fontHeight = 30 }
TSM = {}

if not TSM_DB then TSM_DB={} end
for k,v in pairs(defaults) do
   if TSM_DB[k]==nil then TSM_DB[k]=v end
end

local yourname = UnitName("player")
local tasks = {}
local prefix = "[TranqShotMonitor]"
local move = false
local channels = {"SAY", "PARTY", "BATTLEGROUND", "GUILD", "OFFICER", "YELL", "RAID", "RAID_WARNING"}
----------------------------
-- Timing Functions ------
----------------------------
local function schedule(time, func, ...)
	local t = {...}
	t.func = func
	t.time = GetTime() + time
	table.insert(tasks, t)
end

function onUpdate(self, elapsed)
	for i = #tasks, 1, -1 do
		local val = tasks[i]
		if val and val.time <= GetTime() then
			table.remove(tasks, i)
			val.func(unpack(val))
		end
	end
end

local function unschedule(func, ...)
	for i = #tasks, 1 , -1 do
		local val = tasks[i]
		if val.func == func then
			local matches = true
			for i = 1, select("#", ...) do
				if select(i, ...) ~=val[i] then
					matches = false
					break
				end
			end
			if matches then
				table.remove(tasks, i)
			end
		end
	end
end

local function TimingLib_Unschedule(func, ...)
	return unschedule(func, nil, ...)
end

local function TimingLib_Schedule(time, func, ...)
	return schedule(time, func, nil, ...)
end

---------------------------
---- Refresh Function -----
---------------------------

function TSM.OptionsRefresh()
	TranqShotMonitor_OptionsEnable:SetChecked(TSM_DB.active)
	TranqShotMonitor_OptionsWarningColorNormalTexture:SetVertexColor(TSM_DB.WarningColorr, 
		TSM_DB.WarningColorg, TSM_DB.WarningColorb, TSM_DB.WarningColora)
	TranqShotMonitor_OptionsFontHeight:SetNumber(TSM_DB.fontHeight);
	TranqShotMonitor_OptionsFontHeight:SetCursorPosition(0)
	TranqShotMonitor_OptionsChannelEnable:SetChecked(TSM_DB.activechannel)
	TranqShotMonitor_OptionsAutoChannelEnable:SetChecked(TSM_DB.autochannel)
	TranqShotMonitor_OptionsChannel:SetText(TSM_DB.TRchannel)
	TranqShotMonitor_OptionsChannel:SetCursorPosition(0)
	TranqShotMonitor_OptionsAddonNotification:SetChecked(TSM_DB.selfPrint)
	TranqShotMonitor_OptionsSilencingShot:SetChecked(TSM_DB.silence)
end

-----------------
---- frames -----
-----------------

local frame = CreateFrame("Frame","TRANQWARNINGFRAME",UIParent)
frame:ClearAllPoints()
frame:SetPoint(TSM_DB["Point"],UIParent, TSM_DB["relativePoint"],TSM_DB["xOfs"], TSM_DB["yOfs"])
frame:SetWidth(200)
frame:SetHeight(50)
frame:EnableMouse(false)
frame:SetMovable(false)
frame:Hide()

local listener = CreateFrame("Frame", "listener", UIParent)
listener:Show()
listener:SetWidth(1)
listener:SetHeight(1)
listener:EnableMouse(false)
listener:SetMovable(false) 

-----------------
-- warning ------
-----------------

local fontstring=frame:CreateFontString()
fontstring:SetPoint("BOTTOM",frame)
fontstring:SetFont(STANDARD_TEXT_FONT, TSM_DB.fontHeight)
fontstring:SetWidth(1024)
fontstring:SetJustifyH("CENTER")
fontstring:SetHeight(40)

--------------------------
--- Options functions ----
--- Checkboxes/ height ---
--- Position reset -------
--------------------------

function TSM.OnCheckEnabled(checkbox)
	local bool = checkbox:GetChecked()
	if bool == 1 then
		TSM_DB.active = true
		print(prefix.." Enabled")
	else
		TSM_DB.active = false
		print(prefix.." Disabled")
	end
end

function TSM.OnCheckChannel(checkbox)
	local bool = checkbox:GetChecked()
	if bool == 1 then
		TSM_DB.activechannel = true
		print(prefix.." Channel notices enabled")
	else
		TSM_DB.activechannel = false
		print(prefix.." Channel notices disabled")
	end
end

function TSM.OnCheckAutoChannel(checkbox)
	local bool = checkbox:GetChecked()
	if bool == 1 then
		TSM_DB.autochannel = true
		print(prefix.." When channel broadcasting using Channel based on type of group")
	else
		TSM_DB.autochannel = false
		print(prefix.." When channel broadcasting using Channel based on Warning Channel")
	end
end

function TSM.OnCheckAddonNotification(checkbox)
	local bool = checkbox:GetChecked()
	if bool == 1 then
		TSM_DB.selfPrint = true
		print(prefix.." Printing dispell addon message in chat frame enabled")
	else
		TSM_DB.selfPrint = false
		print(prefix.." Printing dispell addon message in chat frame disabled")
	end
end

function TSM.OnCheckSilencingShot(checkbox)
	local bool = checkbox:GetChecked()
	if bool == 1 then
		TSM_DB.silence = true
		print(prefix.." Silencing Shot Interrupt Warning Enabled")
	else
		TSM_DB.silence = false
		print(prefix.." Silencing Shot Interrupt Warning Disabled")
	end
end

function TSM.FontHeightChanged(box)
	local num = box:GetNumber()
	TSM_DB.fontHeight = num
	fontstring:SetFont("Fonts\\FRIZQT__.TTF", TSM_DB.fontHeight)
end

function TSM:ResetPos()
	frame:ClearAllPoints()
	frame:SetPoint("TOP",UIParent, "TOP", 0, -150)
	TSM_DB["Point"] = "TOP"
	TSM_DB["relativePoint"] = "TOP"
	TSM_DB["xOfs"] = 0
	TSM_DB["yOfs"] = -150
	print(prefix.." Warning message position reset")
end

function TSM:OnUpdate(self, elapsed)
	local e = 0
	e  = e + elapsed
	if e >= 0.5 then
		e = 0
		return TSM:onUpdate(self, elapsed)
	end
end

-----------------------
--- Color functions ---
-----------------------

local function myColorCallback(restore)
 local newR, newG, newB, newA;
 if restore then
  -- The user bailed, we extract the old color from the table created by ShowColorPicker.
  newR, newG, newB, newA = unpack(restore);
 else
  -- Something changed
  newA, newR, newG, newB = OpacitySliderFrame:GetValue(), ColorPickerFrame:GetColorRGB();
 end 
 -- Update our internal storage.
 TSM_DB.WarningColorr, TSM_DB.WarningColorg, TSM_DB.WarningColorb, TSM_DB.WarningColora = newR, newG, newB, newA;
 -- And update any UI elements that use this color...
 TranqShotMonitor_OptionsWarningColorNormalTexture:SetVertexColor(TSM_DB.WarningColorr, 
		TSM_DB.WarningColorg, TSM_DB.WarningColorb, TSM_DB.WarningColora)
 fontstring:SetTextColor(TSM_DB.WarningColorr, TSM_DB.WarningColorg, TSM_DB.WarningColorb, TSM_DB.WarningColora)		
end

function TSM.ShowColorPicker(r, g, b, a)
 ColorPickerFrame:SetColorRGB(r,g,b);
 ColorPickerFrame.hasOpacity, ColorPickerFrame.opacity = (a ~= nil), a;
 ColorPickerFrame.previousValues = {r,g,b,a};
 ColorPickerFrame.func, ColorPickerFrame.opacityFunc, ColorPickerFrame.cancelFunc = 
  myColorCallback, myColorCallback, myColorCallback;
 ColorPickerFrame:Hide(); -- Need to run the OnShow handler.
 ColorPickerFrame:Show();
end

--------------------
-- help function ---
--------------------

local function isInList(channel)
	local b = false
	for i = 1, #channels do
		if channel == channels[i] then
			b = true
		end
	end
	return b
end

local function getChatChan()
	local zoneType = select(2, IsInInstance())
	local numgroup = GetNumGroupMembers();
	local nummygroup = GetNumSubgroupMembers();
	if zoneType == "pvp" or zoneType == "arena" then
		return "BATTLEGROUND"
	elseif numgroup > 5 then
		return "RAID"
	elseif numgroup > 0 and (nummygroup + 1) < numgroup  then
		return "RAID"
	elseif nummygroup > 0  and nummygroup < 5 then
		return "PARTY"
	elseif numgroup > 1 and numgroup == (nummygroup + 1) then
		return "PARTY"
	else
		return "SAY"
	end
end

-------------------
-- event handler --
-------------------

function onEvent(self, event, ...)
	if event =="ADDON_LOADED" then
		frame:ClearAllPoints()
		frame:SetPoint(TSM_DB["Point"],UIParent, TSM_DB["relativePoint"],TSM_DB["xOfs"], TSM_DB["yOfs"])
		fontstring:SetTextColor(TSM_DB.WarningColorr, TSM_DB.WarningColorg, TSM_DB.WarningColorb, TSM_DB.WarningColora)
		frame:EnableMouse(false)
		frame:SetMovable(false) 
	end
	
	local tranqshotmsg = "Tranquilizing Shot dispelled "
	local soothemsg = "Soothe dispelled "
	local shivmsg = "Shiv dispelled "
	local timestamp, type, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags = select(1, ...)	
	if TSM_DB["active"] == true and event == "COMBAT_LOG_EVENT_UNFILTERED" and sourceName == yourname then
	
		if (type=="SPELL_DISPEL") then
			frame:Show()
			local spellId, spellName, spellSchool = select(12, ...)
			local extraSpellID, extraSpellName, extraSchool, auraType = select(15, ...)
			
			if (spellId== 19801) then
				local msg = tranqshotmsg..extraSpellName.."!"
				
				fontstring:SetText(msg)
				fontstring:Show()
				TimingLib_Schedule(3, function() fontstring:Hide() end)
				TimingLib_Schedule(3, function() frame:Hide() end)
				if TSM_DB["activechannel"] then
					-- autodetermine channel
					if TSM_DB["autochannel"] then
						SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, getChatChan())
					else
						local channel2 = TSM_DB["TRchannel"]:upper()
						-- standard blizzard channels
						if isInList(channel2) then
							SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, channel2)
						-- custom player made channels
						else
							index = GetChannelName(TSM_DB["TRchannel"])
							SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, "CHANNEL", nil, index)
							--print("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName)
						end
					end
				end
				if TSM_DB["selfPrint"] then
					print("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName)
				end
				

			end
			if (spellId == 2908) then
				local msg = soothemsg..extraSpellName.."!"
				fontstring:SetText(msg)
				fontstring:Show()
				TimingLib_Schedule(3, function() fontstring:Hide() end)
				TimingLib_Schedule(3, function() frame:Hide() end)
				if TSM_DB["activechannel"] then
					if TSM_DB["autochannel"] then
						SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, getChatChan())
					else
						local channel2 = TSM_DB["TRchannel"]:upper()
						if isInList(channel2) then
							SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, channel2)
						else
							index = GetChannelName(TSM_DB["TRchannel"])
							SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, "CHANNEL", nil, index)
						end
					end
				end
				if TSM_DB["selfPrint"] then
					print("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName)
				end
				
			end
			if (spellId == 5940) then
				local msg = shivmsg..extraSpellName.."!"
				fontstring:SetText(msg)
				fontstring:Show()
				TimingLib_Schedule(3, function() fontstring:Hide() end)
				TimingLib_Schedule(3, function() frame:Hide() end)
				if TSM_DB["activechannel"] then
					if TSM_DB["autochannel"] then
						SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, getChatChan())
					else
						local channel2 = TSM_DB["TRchannel"]:upper()
						if isInList(channel2) then
							SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, channel2)
						else
							index = GetChannelName(TSM_DB["TRchannel"])
							SendChatMessage("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName, "CHANNEL", nil, index)
						end
					end
				end
				if TSM_DB["selfPrint"] then
					print("Dispelled |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r off of "..destName)
				end
				
			end
		end
		if (type=="SPELL_INTERRUPT") and TSM_DB["silence"] then
			frame:Show()
			local spellId, spellName, spellSchool = select(12, ...)
			local extraSpellID, extraSpellName, extraSchool = select(15, ...)
			if (spellId == 34490 or spellId == 147362) then
				local msg = "You interrupted "..extraSpellName.."!"
				fontstring:SetText(msg)
				fontstring:Show()
				TimingLib_Schedule(3, function() fontstring:Hide() end)
				TimingLib_Schedule(3, function() frame:Hide() end)
				if TSM_DB["selfPrint"] then
					print("Interrupted |cff71d5ff|Hspell:"..extraSpellID.."|h["..extraSpellName.."]|h|r from "..destName)
				end
			end
		end
	end
end

---------------------------------
------ Event Registration -------
----------- Scripts -------------
---------------------------------

listener:RegisterEvent("ADDON_LOADED")
listener:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

local e = 0
listener:SetScript("OnUpdate", function(self, elapsed)
	e  = e + elapsed
	if e >= 0.5 then
		e = 0
		return onUpdate(self, elapsed)
	end
end)

listener:SetScript("OnEvent", onEvent)

frame:SetScript("OnMouseDown", function(self, button)
    if button == "LeftButton" and TSM_DB["move"] == true then
      frame:StartMoving()
    end
end)

frame:SetScript("OnMouseUp", function(self, button)
    if button == "LeftButton" and TSM_DB["move"] == true then
      local point2, trash, relpoint, x, y = frame:GetPoint()
	  TSM_DB["Point"] = point2
	  TSM_DB["relativePoint"] = relpoint
	  TSM_DB["xOfs"] = x
	  TSM_DB["yOfs"] = y
	  frame:StopMovingOrSizing()	  
    end
  end)





SLASH_TranqShotMonitor1 = "/tranqshotmonitor"
SLASH_TranqShotMonitor2 = "/tsm"

-----------------------------------
---- ---- slash commands-----------
---- /tsm enable        -----------
---- /tsm disable       -----------
---- /tsm channel enable ----------
---- /tsm channel disable ---------
---- /tsm setchannel <channel> ----
---- /tsm move enable -------------
---- /tsm move disable ------------
---- /tsm move reset   ------------
---- /tsm options     -------------
---- /tsm o           -------------
-----------------------------------

SlashCmdList["TranqShotMonitor"] = function(msg)
	local cmd, arg1, arg2, arg3 = string.split(" ", msg) --split the string
	cmd = cmd:lower()	
	if cmd == "enable" then -- /tsm enable
		TSM_DB["active"] = true
		listener:Show()
		listener:RegisterEvent("ADDON_LOADED")
		listener:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		print(prefix.." Enabled")
	elseif cmd == "disable" then -- /tsm disable
		TSM_DB["active"] = false
		listener:Hide()
		listener:UnregisterAllEvents()
		print(prefix.." Disabled")
	elseif cmd == "channel" and arg1 == "enable" then
		TSM_DB["activechannel"] = true
		print(prefix.." Channel notices enabled")
	elseif cmd == "channel" and arg1 == "disable" then
		TSM_DB["activechannel"] = false
		print(prefix.." Channel notices disabled")
	elseif cmd == "setchannel" then
		if arg1 then
			TSM_DB["TRchannel"] = arg1
			print(prefix.." Channel changed to "..arg1)
		end
	elseif cmd =="move" and arg1 == "enable" then
		TSM_DB["move"] = true
		local msg = "Tranquilizing Shot has dispelled e.g. Shadow Protection"
		frame:Show()
		fontstring:SetText(msg)
		fontstring:Show()
		frame:EnableMouse(true)
		frame:SetMovable(true)
		print(prefix.." Moving warning message enabled")
	elseif cmd =="move" and arg1 == "disable" then
		TSM_DB["move"] = false
		fontstring:Hide()
		fontstring:SetText(nil)
		frame:EnableMouse(false)
		frame:SetMovable(false)	
		frame:Hide()
		print(prefix.." Moving warning message disabled")
	elseif cmd == "move" and arg1 == "reset" then
		frame:ClearAllPoints()
		frame:SetPoint("TOP",UIParent, "TOP", 0, -150)
		TSM_DB["Point"] = "TOP"
		TSM_DB["relativePoint"] = "TOP"
		TSM_DB["xOfs"] = 0
		TSM_DB["yOfs"] = -150
		print(prefix.." Warning message position reset")
	elseif cmd =="changecolor" and arg1 and arg2 and arg3 then
		TSM_DB.WarningColorr = arg1
		TSM_DB.WarningColorg = arg2
		TSM_DB.WarningColorb = arg3
		fontstring:SetTextColor(TSM_DB.WarningColorr, TSM_DB.WarningColorg, TSM_DB.WarningColorb)
		print(prefix.." color changed")
	elseif cmd =="options" then
		TranqShotMonitor_Options:Show()
	elseif cmd =="o" then
		TranqShotMonitor_Options:Show()
	end
end