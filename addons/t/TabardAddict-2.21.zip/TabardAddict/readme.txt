﻿Tabard Addict
Addon for World of Warcraft
author: gmz323(Greg)
current version: v2.21

Description: 
============
A simple addon that shows which tabards you have or have not equipped and suggests additional tabards to help with meeting the various tabard achievements. 
Use slash commands /ta or /tabardaddict or button next to tabard slot in character frame to open and/or close the addon window.

Download locations:
===================
* wowinterface - http://goo.gl/j3xtO
* curse - http://goo.gl/1UiEN

Official AddOn Homepage:
========================
http://goo.gl/8GyYK

Usage:
======
/ta
/tabardaddict
*click button* next to tabard inventory slot in character frame

Features:
=========
* Shows all tabards that count towards equip count achievement including tabards not available to your faction or currently in game.
* Equip data comes from the server.  No need to re-equip all the tabards to update the status to addon.
* Shows suggested tabards to equip to help with meeting the tabard achievements.
* Mouse Over tabard icon - shows in game tooltip.
* Ctrl-Click tabard icon - will launch Dressing Room with tabard equipped. See what your character looks like in the other factions tabards. Also preview TCG tabards before buying.
* Shift-Click tabard icon - will insert item link into active chat edit box.
* Mouse Over tabard items in game - tooltip will show if tabard has been equipped or not.
* Click "info" button to show a dressup preview of the tabard and a wowhead url.

FAQ(s):
=======
(Q) Why show tabards not available to my character?
(*) Many people like to see what their horde character looks like in alliance tabards and vice versa in the Dressing Room.
(*) You can also see what your character looks like in TCG loot code tabards before buying a loot code.
(*) The "Suggestions" tab will show only tabards that are available to your character.

Localization Help Needed:
=========================
If you would like to help complete the Tabard Addict localizations please contact us!  Use the Tabard Addict forum threads to get in touch with us or use our contact form at: http://goo.gl/ZzEjJ

In the Tabard Addict addon folder are the following partially localized files.  They should be your starting point if you want to help out.
* Localization.esES.lua - spanish client
* Localization.ptBR.lua - portuguese(Brazil) (complete! Thanks marciobruno!)
* Localization.frFR.lua - french client (complete! Thanks Matisk!)
* Localization.deDE.lua - deutsch client (complete! Thanks Harry!)
* Localization.ruRU.lua - russian client (complete! Thanks Megul!)
* Localization.koKR.lua - Korean (Korea) client (complete! Thanks minidice!)
* Localization.trTUR.lua - turkish - requires manual file changes - see below (Thanks Baris!)

Localizations that require manual file changes
==============================================
Go to your World of Warcraft AddOns/TabardAddict folder
Replace the contents of the file Localization.enUS.lua with your language listed below
* Turkish - Localization.trTUR.lua

My Other Addons:
================
* Faction Addict - tracks how many exalted reputations you have and standings with all factions. View factions by percent to exalted.
* Below Average Items - an addon that places a small visual indicator on equipped items that are below your current iLvl average.

Changelog:
==========
v2.21 (2013-09-18)
------------------
* Added Korean (Korea) localization to release. Thanks minidice!

v2.20 (2013-09-11)
------------------
* English client should no longer display German! 

v2.19 (2013-09-11)
------------------
* Bugfix - If you played in clients other than US(enUS) you were probably getting an <eof> error. This should fix that error.

v2.18 (2013-09-10)
------------------
* Updated to support WoW 5.4
* Added 1 new tabard - Grievous Gladiator's Tabard - also currently not tracked by game

v2.17 (2013-05-21)
------------------
* Updated to support WoW 5.3
* Added 1 new tabard - Tyrannical Gladiator's Tabard - also currently not tracked by game

v2.16 (2013-03-05)
-----------------
* Updated to support wow client 5.2
* Added 3 new tabards - Shado-Pan Assault Tabard, Sunreaver Onslaught Tabard, and Kirin Tor Offensive Tabard
* NOTE! The 3 new tabards are currently not tracked if they've been equipped or not. (no criteria id's assigned in game yet)

v2.15 (2013-2-1)
----------------
* Added Portuguese(Brazil) translation to release. Thanks marciobruno!

v2.14 (2012-12-08)
------------------
* Tabard Addict now shows if you've equipped the "exalted faction required" Mists of Pandaria tabards.
* Added Theramore Tabard - reward from the Theramore's Fall Event.  This was Alliance only reward and is not currently available in game. Patch 5.1 counts Theramore Tabard towards achievements.
* Added localization file for Portuguese(Brazil) translation. Actual localization still required.

v2.13 (2012-11-28)
------------------
* Updated to support wow client 5.1
* Note: I still need the new Criteria IDs to acurately track the MoP "exalted faction required" tabards.  Workaround in place since GetAchievementCriteriaInfo() does not seem to currently work for tabard achievements.

v2.12 (2012-11-21)
------------------
* Added french client translation provided by Matisk. (Thanks Matisk!)

v2.11 (2012-10-25)
------------------
* Added the 8 new exalted faction required Mists of Pandaria tabards. (please see important note below)
* IMPORTANT NOTE!: The 8 new "exalted faction required" tabards do not count towards tabard collecting achievements.  And as such the game does not track if your character has equipped them or not. The addon may be modified in the future to track them on it's own but at this time they will be displayed as "Not Tracked by Game".

v2.10 (2012-09-30)
------------------
* Added Turkish translation - important note!! - manual file changes are required if you desire to use the Turkish translation
* To use turkish translation - go to your wow addons/TabardAddict directory - replace the contents of the file Localization.enUS.lua with the file Localization.trTUR.lua

v2.09 (2012-09-04)
------------------
* Tabard of the Scarlet Crusade - updated to now "Not Currently In Game" category - doesn't seem to be dropping with Scarlet Monastery revamp.  This cool tabard hopefully coming back someday!

v2.08 (2012-08-28)
------------------
* Updates for Mists of Pandaria expansion.

v2.07 (2012-08-05)
------------------
* Added support for russian translation provided by Megul.
* Changed files to UTF-8 encoding. Please report any issues you may see.

v2.06 (2012-2-21)
-----------------
* Added new tooltip containing list of all tabard achievements and which have been completed.  Tooltip viewed when hovering over "Next Achievement" text at bottom of addon.

v2.05 (2012-1-12)
-----------------
* [new] Added config option to hide tabards that have already been equipped. "Show Equipped Tabards" in the Tabard Filter section of the config panel.

v2.04 (2011-12-30)
------------------
* [new] The extra info window has been expanded to include a dress up view of the selected tabard on your character. There is also a check box that will show or hide your current equipment in addition to showing the selected tabard.

v2.03 (2011-11-29)
------------------
* [new] Added "info" buttons to each entry that can be clicked to show a wowhead url. Copy and paste the url to your browser.
* Update for new wow patch version 4.3.

v2.02 (2011-11-16)
------------------
* [fix] font strings at the bottom of the addon have been modified to avoid overlapping. Please report in comments if you still see this problem after the update.
* Added full Deutsch(german) client support. Thanks to Harry for the localization help!

v2.01 (2011-11-10)
------------------
* [new!] Suggestions Tab - Tabard Addict will now show you tabards than can be acquired and equipped by your character.

v1.16 (2011-10-20)
------------------
* [bugfix] Fix to address item not in local cache when trying to populate tooltip.

v1.15 (2011-10-20)
------------------
* [new] Added "Tabard - Been Equipped" indication to tooltips whenever the user hovers the mouse over a tabard item in  game. (includes tabard items in inventory, bank, merchants, etc...)

v1.14 (2011-08-07)
------------------
* Added search box / filter at the bottom right of the addon.
* Cleaned up the saved config values - note this resets all options to "on"

v1.13 (2011-07-24)
------------------
* Added partial localization for German, Spanish and French clients.
* If you would like to help us complete the localizations please get in touch!

v1.12 (2011-06-28)
------------------
* Updated for patch 4.2

v1.11 (2011-06-16)
------------------
* [new] Launcher button has been added to the character frame next to the tabard inventory slot.  
* [new] New config entry added to enable/disable the character frame launcher.
* [fix] Updated the classification of Krom'gar Tabard to not currently in game and horde only.

v1.10 (2011-05-30)
------------------
* [fix] There was an exception being thrown if you had equipped 30 or more tabards.  Updated addon to handle this situation correctly.

v1.09 (2011-05-25)
------------------
* added count of tabards shown in display to Tabards tab
* added tooltips to the Config tab
* version string has been moved to the About tab, removed from other tabs
* inital changes to addon for localization support

v1.08 (2011-05-11)
------------------
* [fix] Updated the classification of Tabard of Stormwind to not currently in game and alliance only.

v1.07 (2011-05-10)
------------------
* New Display Options - Additional display config options have been added including: PVP/Arena, Burning Crusade Faction, Wrath of the Lich King Faction, Argent Tournament Faction, Cataclysm Faction, and tabards not currently in game.
* Addon now updates current tabard counts and which have been equipped when player changes tabard equipment slot.  No longer need to close and re-open the addon.

v1.06 (2011-04-26)
------------------
* [update] Updated for patch 4.1.0.  Added the 2 new guild tabards to those that count toward tabard achievements. The Illustrious Guild Tabard and the Renowned Guild Tabard. Plus note there is an achievement for equipping 30 tabards now!

v1.05 (2011-04-20)
------------------
* [feature] NEW configuration tab added to bottom of addon. Provides ability to control which tabards are displayed. (more config options to come over time)

v1.04 (2011-03-21)
------------------
* [bugfix] additional changes to fix faction icon display issue

v1.03 (2011-03-08)
------------------
* Address issue with faction icons appearing under gold border.

v1.02 (2011-03-06)
------------------
* Added horde/alliance indicators to the horde/alliance only tabards.

v1.01 (2011-03-01)
------------------
* Initial release of Tabard Addict


