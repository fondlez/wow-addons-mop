﻿--  ===============================
--	Tabard Addict Requirement Data 
--	By: gmz323(Greg)
--  ===============================
-- Localized Strings
local L = TabardAddictLocalization;

taTabardReqmtData = {};

taTabardReqmtData[1] = {};
taTabardReqmtData[1][0] = 1;    -- available? 0=no, 1=yes
taTabardReqmtData[1][1] = 0;    -- faction? 0=both, 1=alliance, 2=horde
taTabardReqmtData[1][2] = 1;    -- requirement - 0=none, 1=reputation, 2=quest, 3=achievement, 4=currency, 5=drop
taTabardReqmtData[1][3] = 900;  -- reputation id, quest id, or achievement id
taTabardReqmtData[1][4] = 8;    -- reputation level when [2] is 1; 5=Friendly, 6=Honored, 7=Revered, 8=Exalted
                                -- quest level when [2] is 2;						
--
taTabardReqmtData[20132] = {};
taTabardReqmtData[20132][0] = 1;    
taTabardReqmtData[20132][1] = 1;    
taTabardReqmtData[20132][2] = 2;    
taTabardReqmtData[20132][3] = L.SUGG_QST_8115; 
taTabardReqmtData[20132][4] = 60;
--
taTabardReqmtData[31776] = {};
taTabardReqmtData[31776][0] = 1; 
taTabardReqmtData[31776][1] = 0; 
taTabardReqmtData[31776][2] = 1; 
taTabardReqmtData[31776][3] = 933; 
taTabardReqmtData[31776][4] = 8; 
--
taTabardReqmtData[31405] = {};
taTabardReqmtData[31405][0] = 1;   
taTabardReqmtData[31405][1] = 0;    
taTabardReqmtData[31405][2] = 2;    
taTabardReqmtData[31405][3] = L.SUGG_QST_10781;  
taTabardReqmtData[31405][4] = 68;   
--
taTabardReqmtData[28788] = {};
taTabardReqmtData[28788][0] = 0;   
taTabardReqmtData[28788][1] = 0;    
taTabardReqmtData[28788][2] = 0;    
taTabardReqmtData[28788][3] = 0;  
taTabardReqmtData[28788][4] = 0;   
--
taTabardReqmtData[35280] = {};
taTabardReqmtData[35280][0] = 1;   
taTabardReqmtData[35280][1] = 0;    
taTabardReqmtData[35280][2] = 2;    
taTabardReqmtData[35280][3] = L.SUGG_QST_11972;  -- Midsummer event quest
taTabardReqmtData[35280][4] = 65;   
--
taTabardReqmtData[5976] = {};
taTabardReqmtData[5976][0] = 1;   
taTabardReqmtData[5976][1] = 0;    
taTabardReqmtData[5976][2] = 0;    
taTabardReqmtData[5976][3] = 0;  
taTabardReqmtData[5976][4] = 0;   
--
taTabardReqmtData[31779] = {};
taTabardReqmtData[31779][0] = 1;   
taTabardReqmtData[31779][1] = 0;    
taTabardReqmtData[31779][2] = 1;    
taTabardReqmtData[31779][3] = 932;  
taTabardReqmtData[31779][4] = 8;   
--
taTabardReqmtData[20131] = {};
taTabardReqmtData[20131][0] = 1;   
taTabardReqmtData[20131][1] = 2;    
taTabardReqmtData[20131][2] = 2;    
taTabardReqmtData[20131][3] = L.SUGG_QST_8122;  
taTabardReqmtData[20131][4] = 60;   
--
taTabardReqmtData[25549] = {};
taTabardReqmtData[25549][0] = 1;   
taTabardReqmtData[25549][1] = 2;    
taTabardReqmtData[25549][2] = 2;    
taTabardReqmtData[25549][3] = L.SUGG_QST_28473;  
taTabardReqmtData[25549][4] = 50;   --paladin blood elf only
--
taTabardReqmtData[31804] = {};
taTabardReqmtData[31804][0] = 1;   
taTabardReqmtData[31804][1] = 0;    
taTabardReqmtData[31804][2] = 1;    
taTabardReqmtData[31804][3] = 942;  
taTabardReqmtData[31804][4] = 8;   
--
taTabardReqmtData[36941] = {};
taTabardReqmtData[36941][0] = 0;   
taTabardReqmtData[36941][1] = 0;    
taTabardReqmtData[36941][2] = 0;    
taTabardReqmtData[36941][3] = 0;  
taTabardReqmtData[36941][4] = 0;   
--
taTabardReqmtData[19160] = {};
taTabardReqmtData[19160][0] = 0;   
taTabardReqmtData[19160][1] = 0;    
taTabardReqmtData[19160][2] = 0;    
taTabardReqmtData[19160][3] = 0;  
taTabardReqmtData[19160][4] = 0;   
--
taTabardReqmtData[19031] = {};
taTabardReqmtData[19031][0] = 1;   
taTabardReqmtData[19031][1] = 2;    
taTabardReqmtData[19031][2] = 4;    
taTabardReqmtData[19031][3] = "2679 "..L.SUGG_CURRENCY_HONOR;  
taTabardReqmtData[19031][4] = 10;   
--
taTabardReqmtData[31404] = {};
taTabardReqmtData[31404][0] = 1;   
taTabardReqmtData[31404][1] = 0;    
taTabardReqmtData[31404][2] = 2;    
taTabardReqmtData[31404][3] = L.SUGG_QST_10781;  
taTabardReqmtData[31404][4] = 68;   
--
taTabardReqmtData[23999] = {};
taTabardReqmtData[23999][0] = 1;   
taTabardReqmtData[23999][1] = 1;    
taTabardReqmtData[23999][2] = 1;    
taTabardReqmtData[23999][3] = 946;  
taTabardReqmtData[23999][4] = 8;   
--
taTabardReqmtData[31777] = {};
taTabardReqmtData[31777][0] = 1;   
taTabardReqmtData[31777][1] = 0;    
taTabardReqmtData[31777][2] = 1;    
taTabardReqmtData[31777][3] = 989;  
taTabardReqmtData[31777][4] = 8;   
--
taTabardReqmtData[15198] = {};
taTabardReqmtData[15198][0] = 1;   
taTabardReqmtData[15198][1] = 1;    
taTabardReqmtData[15198][2] = 4;    
taTabardReqmtData[15198][3] = "100 ".. L.SUGG_CURRENCY_HONOR;  
taTabardReqmtData[15198][4] = 10;
--
taTabardReqmtData[31774] = {};
taTabardReqmtData[31774][0] = 1;   
taTabardReqmtData[31774][1] = 1;    
taTabardReqmtData[31774][2] = 1;    
taTabardReqmtData[31774][3] = 978;  
taTabardReqmtData[31774][4] = 8;   
--
taTabardReqmtData[31778] = {};
taTabardReqmtData[31778][0] = 1;   
taTabardReqmtData[31778][1] = 0;    
taTabardReqmtData[31778][2] = 1;    
taTabardReqmtData[31778][3] = 1011;  
taTabardReqmtData[31778][4] = 8;   
--
taTabardReqmtData[31773] = {};
taTabardReqmtData[31773][0] = 1;   
taTabardReqmtData[31773][1] = 2;    
taTabardReqmtData[31773][2] = 1;    
taTabardReqmtData[31773][3] = 941;  
taTabardReqmtData[31773][4] = 8;   
--
taTabardReqmtData[32828] = {};
taTabardReqmtData[32828][0] = 1;   
taTabardReqmtData[32828][1] = 0;    
taTabardReqmtData[32828][2] = 1;    
taTabardReqmtData[32828][3] = 1038;  
taTabardReqmtData[32828][4] = 8;   
--
taTabardReqmtData[15196] = {};
taTabardReqmtData[15196][0] = 1;   
taTabardReqmtData[15196][1] = 1;    
taTabardReqmtData[15196][2] = 4;    
taTabardReqmtData[15196][3] = "50 "..L.SUGG_CURRENCY_HONOR;  
taTabardReqmtData[15196][4] = 10;
--
taTabardReqmtData[15197] = {};
taTabardReqmtData[15197][0] = 1;
taTabardReqmtData[15197][1] = 2;
taTabardReqmtData[15197][2] = 4;
taTabardReqmtData[15197][3] = "50 "..L.SUGG_CURRENCY_HONOR;
taTabardReqmtData[15197][4] = 10;
--
taTabardReqmtData[31780] = {};
taTabardReqmtData[31780][0] = 1;
taTabardReqmtData[31780][1] = 0;
taTabardReqmtData[31780][2] = 1;
taTabardReqmtData[31780][3] = 934;
taTabardReqmtData[31780][4] = 8;
--
taTabardReqmtData[31781] = {};
taTabardReqmtData[31781][0] = 1;
taTabardReqmtData[31781][1] = 0;
taTabardReqmtData[31781][2] = 1;
taTabardReqmtData[31781][3] = 935;
taTabardReqmtData[31781][4] = 8;
--
taTabardReqmtData[19506] = {};
taTabardReqmtData[19506][0] = 1;
taTabardReqmtData[19506][1] = 1;
taTabardReqmtData[19506][2] = 4;
taTabardReqmtData[19506][3] = "2059 "..L.SUGG_CURRENCY_HONOR;
taTabardReqmtData[19506][4] = 10;
--
taTabardReqmtData[32445] = {};
taTabardReqmtData[32445][0] = 1;
taTabardReqmtData[32445][1] = 0;
taTabardReqmtData[32445][2] = 1;
taTabardReqmtData[32445][3] = 1031;
taTabardReqmtData[32445][4] = 8;
--
taTabardReqmtData[31775] = {};
taTabardReqmtData[31775][0] = 1;
taTabardReqmtData[31775][1] = 0;
taTabardReqmtData[31775][2] = 1;
taTabardReqmtData[31775][3] = 970;
taTabardReqmtData[31775][4] = 8;
--
taTabardReqmtData[15199] = {};
taTabardReqmtData[15199][0] = 1;
taTabardReqmtData[15199][1] = 2;
taTabardReqmtData[15199][2] = 4;
taTabardReqmtData[15199][3] = "100 "..L.SUGG_CURRENCY_HONOR;
taTabardReqmtData[15199][4] = 10;
--
taTabardReqmtData[19032] = {};
taTabardReqmtData[19032][0] = 1;
taTabardReqmtData[19032][1] = 1;
taTabardReqmtData[19032][2] = 4;
taTabardReqmtData[19032][3] = "2679 "..L.SUGG_CURRENCY_HONOR;
taTabardReqmtData[19032][4] = 10;
--
taTabardReqmtData[38312] = {}; -- TCG
taTabardReqmtData[38312][0] = 0;
taTabardReqmtData[38312][1] = 0;
taTabardReqmtData[38312][2] = 0;
taTabardReqmtData[38312][3] = 0;
taTabardReqmtData[38312][4] = 0;
--
taTabardReqmtData[23705] = {}; -- TCG
taTabardReqmtData[23705][0] = 0;
taTabardReqmtData[23705][1] = 0;
taTabardReqmtData[23705][2] = 0;
taTabardReqmtData[23705][3] = 0;
taTabardReqmtData[23705][4] = 0;
--
taTabardReqmtData[23709] = {}; -- TCG
taTabardReqmtData[23709][0] = 0;
taTabardReqmtData[23709][1] = 0;
taTabardReqmtData[23709][2] = 0;
taTabardReqmtData[23709][3] = 0;
taTabardReqmtData[23709][4] = 0;
--
taTabardReqmtData[38313] = {}; -- TCG
taTabardReqmtData[38313][0] = 0;
taTabardReqmtData[38313][1] = 0;
taTabardReqmtData[38313][2] = 0;
taTabardReqmtData[38313][3] = 0;
taTabardReqmtData[38313][4] = 0;
--
taTabardReqmtData[38309] = {}; -- TCG
taTabardReqmtData[38309][0] = 0;
taTabardReqmtData[38309][1] = 0;
taTabardReqmtData[38309][2] = 0;
taTabardReqmtData[38309][3] = 0;
taTabardReqmtData[38309][4] = 0;
--
taTabardReqmtData[11364] = {};
taTabardReqmtData[11364][0] = 0;
taTabardReqmtData[11364][1] = 0;
taTabardReqmtData[11364][2] = 0;
taTabardReqmtData[11364][3] = 0;
taTabardReqmtData[11364][4] = 0;
--
taTabardReqmtData[35279] = {};
taTabardReqmtData[35279][0] = 1;
taTabardReqmtData[35279][1] = 0;
taTabardReqmtData[35279][2] = 2;
taTabardReqmtData[35279][3] = L.SUGG_QST_11972; -- Midsummer event quest
taTabardReqmtData[35279][4] = 65;
--
taTabardReqmtData[38310] = {}; -- TCG
taTabardReqmtData[38310][0] = 0;
taTabardReqmtData[38310][1] = 0;
taTabardReqmtData[38310][2] = 0;
taTabardReqmtData[38310][3] = 0;
taTabardReqmtData[38310][4] = 0;
--
taTabardReqmtData[22999] = {};
taTabardReqmtData[22999][0] = 0;
taTabardReqmtData[22999][1] = 0;
taTabardReqmtData[22999][2] = 0;
taTabardReqmtData[22999][3] = 0;
taTabardReqmtData[22999][4] = 0;
--
taTabardReqmtData[38314] = {}; -- TCG
taTabardReqmtData[38314][0] = 0;
taTabardReqmtData[38314][1] = 0;
taTabardReqmtData[38314][2] = 0;
taTabardReqmtData[38314][3] = 0;
taTabardReqmtData[38314][4] = 0;
--
taTabardReqmtData[24344] = {};
taTabardReqmtData[24344][0] = 1;
taTabardReqmtData[24344][1] = 1;
taTabardReqmtData[24344][2] = 2;
taTabardReqmtData[24344][3] = L.SUGG_QST_9762;
taTabardReqmtData[24344][4] = 18; -- draenei only quest prereq
--
taTabardReqmtData[23192] = {};
taTabardReqmtData[23192][0] = 0; -- Tabard of the Scarlet Crusade - currently not avail
taTabardReqmtData[23192][1] = 0;
taTabardReqmtData[23192][2] = 5;
taTabardReqmtData[23192][3] = L.SUGG_MOB_6575; -- Scarlet Trainee
taTabardReqmtData[23192][4] = 30;
--
taTabardReqmtData[35221] = {};
taTabardReqmtData[35221][0] = 1;
taTabardReqmtData[35221][1] = 0;
taTabardReqmtData[35221][2] = 1;
taTabardReqmtData[35221][3] = 1077;
taTabardReqmtData[35221][4] = 8;
--
taTabardReqmtData[38311] = {}; -- TCG
taTabardReqmtData[38311][0] = 0;
taTabardReqmtData[38311][1] = 0;
taTabardReqmtData[38311][2] = 0;
taTabardReqmtData[38311][3] = 0;
taTabardReqmtData[38311][4] = 0;
--
taTabardReqmtData[24004] = {};
taTabardReqmtData[24004][0] = 1;
taTabardReqmtData[24004][1] = 2;
taTabardReqmtData[24004][2] = 1;
taTabardReqmtData[24004][3] = 947;
taTabardReqmtData[24004][4] = 8;
--
taTabardReqmtData[23388] = {};
taTabardReqmtData[23388][0] = 0;
taTabardReqmtData[23388][1] = 0;
taTabardReqmtData[23388][2] = 0;
taTabardReqmtData[23388][3] = 0;
taTabardReqmtData[23388][4] = 0;
--
taTabardReqmtData[19505] = {};
taTabardReqmtData[19505][0] = 1;
taTabardReqmtData[19505][1] = 2;
taTabardReqmtData[19505][2] = 4;
taTabardReqmtData[19505][3] = "2059 "..L.SUGG_CURRENCY_HONOR;
taTabardReqmtData[19505][4] = 10;
--
taTabardReqmtData[43300] = {};
taTabardReqmtData[43300][0] = 1;
taTabardReqmtData[43300][1] = 0;
taTabardReqmtData[43300][2] = 3;
taTabardReqmtData[43300][3] = 1681; -- 1682 horde
taTabardReqmtData[43300][4] = 80;
--
taTabardReqmtData[43348] = {};
taTabardReqmtData[43348][0] = 1;
taTabardReqmtData[43348][1] = 0;
taTabardReqmtData[43348][2] = 3;
taTabardReqmtData[43348][3] = 45;
taTabardReqmtData[43348][4] = 68;
--
taTabardReqmtData[43349] = {};
taTabardReqmtData[43349][0] = 1;
taTabardReqmtData[43349][1] = 0;
taTabardReqmtData[43349][2] = 3;
taTabardReqmtData[43349][3] = 876;
taTabardReqmtData[43349][4] = 80;
--
taTabardReqmtData[43154] = {};
taTabardReqmtData[43154][0] = 1;
taTabardReqmtData[43154][1] = 0;
taTabardReqmtData[43154][2] = 1;
taTabardReqmtData[43154][3] = 1106;
taTabardReqmtData[43154][4] = 5;
--
taTabardReqmtData[43155] = {};
taTabardReqmtData[43155][0] = 1;
taTabardReqmtData[43155][1] = 0;
taTabardReqmtData[43155][2] = 1;
taTabardReqmtData[43155][3] = 1098;
taTabardReqmtData[43155][4] = 5;
--
taTabardReqmtData[43156] = {};
taTabardReqmtData[43156][0] = 1;
taTabardReqmtData[43156][1] = 0;
taTabardReqmtData[43156][2] = 1;
taTabardReqmtData[43156][3] = 1091;
taTabardReqmtData[43156][4] = 5;
--
taTabardReqmtData[43157] = {};
taTabardReqmtData[43157][0] = 1;
taTabardReqmtData[43157][1] = 0;
taTabardReqmtData[43157][2] = 1;
taTabardReqmtData[43157][3] = 1090;
taTabardReqmtData[43157][4] = 5;
--
taTabardReqmtData[45585] = {};
taTabardReqmtData[45585][0] = 1;
taTabardReqmtData[45585][1] = 2;
taTabardReqmtData[45585][2] = 0;
taTabardReqmtData[45585][3] = 0;
taTabardReqmtData[45585][4] = 0;
--
taTabardReqmtData[45582] = {};
taTabardReqmtData[45582][0] = 1;
taTabardReqmtData[45582][1] = 2;
taTabardReqmtData[45582][2] = 0;
taTabardReqmtData[45582][3] = 0;
taTabardReqmtData[45582][4] = 0;
--
taTabardReqmtData[45583] = {};
taTabardReqmtData[45583][0] = 1;
taTabardReqmtData[45583][1] = 2;
taTabardReqmtData[45583][2] = 0;
taTabardReqmtData[45583][3] = 0;
taTabardReqmtData[45583][4] = 0;
--
taTabardReqmtData[45584] = {};
taTabardReqmtData[45584][0] = 1;
taTabardReqmtData[45584][1] = 2;
taTabardReqmtData[45584][2] = 0;
taTabardReqmtData[45584][3] = 0;
taTabardReqmtData[45584][4] = 0;
--
taTabardReqmtData[45579] = {};
taTabardReqmtData[45579][0] = 1;
taTabardReqmtData[45579][1] = 1;
taTabardReqmtData[45579][2] = 0;
taTabardReqmtData[45579][3] = 0;
taTabardReqmtData[45579][4] = 0;
--
taTabardReqmtData[45580] = {};
taTabardReqmtData[45580][0] = 1;
taTabardReqmtData[45580][1] = 1;
taTabardReqmtData[45580][2] = 0;
taTabardReqmtData[45580][3] = 0;
taTabardReqmtData[45580][4] = 0;
--
taTabardReqmtData[45578] = {};
taTabardReqmtData[45578][0] = 1;
taTabardReqmtData[45578][1] = 1;
taTabardReqmtData[45578][2] = 0;
taTabardReqmtData[45578][3] = 0;
taTabardReqmtData[45578][4] = 0;
--
taTabardReqmtData[45577] = {};
taTabardReqmtData[45577][0] = 1;
taTabardReqmtData[45577][1] = 1;
taTabardReqmtData[45577][2] = 0;
taTabardReqmtData[45577][3] = 0;
taTabardReqmtData[45577][4] = 0;
--
taTabardReqmtData[45574] = {};
taTabardReqmtData[45574][0] = 1;
taTabardReqmtData[45574][1] = 1;
taTabardReqmtData[45574][2] = 0;
taTabardReqmtData[45574][3] = 0;
taTabardReqmtData[45574][4] = 0;
--
taTabardReqmtData[45581] = {};
taTabardReqmtData[45581][0] = 1;
taTabardReqmtData[45581][1] = 2;
taTabardReqmtData[45581][2] = 0;
taTabardReqmtData[45581][3] = 0;
taTabardReqmtData[45581][4] = 0;
--
taTabardReqmtData[46817] = {};
taTabardReqmtData[46817][0] = 1;
taTabardReqmtData[46817][1] = 1;
taTabardReqmtData[46817][2] = 1;
taTabardReqmtData[46817][3] = 1094;
taTabardReqmtData[46817][4] = 8; -- plus 50 champ seals
--
taTabardReqmtData[46818] = {};
taTabardReqmtData[46818][0] = 1;
taTabardReqmtData[46818][1] = 2;
taTabardReqmtData[46818][2] = 1;
taTabardReqmtData[46818][3] = 1124;
taTabardReqmtData[46818][4] = 8; -- plus 50 champ seals
--
taTabardReqmtData[46874] = {};
taTabardReqmtData[46874][0] = 1;
taTabardReqmtData[46874][1] = 0;
taTabardReqmtData[46874][2] = 4;
taTabardReqmtData[46874][3] = "50 "..L.SUGG_CURRENCY_CHAMP;
taTabardReqmtData[46874][4] = 77;
--
taTabardReqmtData[49052] = {};
taTabardReqmtData[49052][0] = 1;
taTabardReqmtData[49052][1] = 1;
taTabardReqmtData[49052][2] = 3;
taTabardReqmtData[49052][3] = 3857;
taTabardReqmtData[49052][4] = 75;
--
taTabardReqmtData[49054] = {};
taTabardReqmtData[49054][0] = 1;
taTabardReqmtData[49054][1] = 2;
taTabardReqmtData[49054][2] = 3;
taTabardReqmtData[49054][3] = 3957;
taTabardReqmtData[49054][4] = 75;
--
taTabardReqmtData[45983] = {};
taTabardReqmtData[45983][0] = 0;
taTabardReqmtData[45983][1] = 0;
taTabardReqmtData[45983][2] = 0;
taTabardReqmtData[45983][3] = 0;
taTabardReqmtData[45983][4] = 0;
--
taTabardReqmtData[49086] = {};
taTabardReqmtData[49086][0] = 0;
taTabardReqmtData[49086][1] = 0;
taTabardReqmtData[49086][2] = 0;
taTabardReqmtData[49086][3] = 0;
taTabardReqmtData[49086][4] = 0;
--
taTabardReqmtData[40643] = {};
taTabardReqmtData[40643][0] = 1;
taTabardReqmtData[40643][1] = 0;
taTabardReqmtData[40643][2] = 3;
taTabardReqmtData[40643][3] = 1021;
taTabardReqmtData[40643][4] = 15;
--
taTabardReqmtData[52252] = {};
taTabardReqmtData[52252][0] = 1;
taTabardReqmtData[52252][1] = 0;
taTabardReqmtData[52252][2] = 2;
taTabardReqmtData[52252][3] = L.SUGG_QST_24919;
taTabardReqmtData[52252][4] = 80;
--
taTabardReqmtData[51534] = {};
taTabardReqmtData[51534][0] = 0;
taTabardReqmtData[51534][1] = 0;
taTabardReqmtData[51534][2] = 0;
taTabardReqmtData[51534][3] = 0;
taTabardReqmtData[51534][4] = 0;
--
taTabardReqmtData[65909] = {};
taTabardReqmtData[65909][0] = 1;
taTabardReqmtData[65909][1] = 2;
taTabardReqmtData[65909][2] = 1;
taTabardReqmtData[65909][3] = 1172;
taTabardReqmtData[65909][4] = 5;
--
taTabardReqmtData[65908] = {};
taTabardReqmtData[65908][0] = 1;
taTabardReqmtData[65908][1] = 1;
taTabardReqmtData[65908][2] = 1;
taTabardReqmtData[65908][3] = 1174;
taTabardReqmtData[65908][4] = 5;
--
taTabardReqmtData[65907] = {};
taTabardReqmtData[65907][0] = 1;
taTabardReqmtData[65907][1] = 0;
taTabardReqmtData[65907][2] = 1;
taTabardReqmtData[65907][3] = 1171;
taTabardReqmtData[65907][4] = 5;
--
taTabardReqmtData[65906] = {};
taTabardReqmtData[65906][0] = 1;
taTabardReqmtData[65906][1] = 0;
taTabardReqmtData[65906][2] = 1;
taTabardReqmtData[65906][3] = 1158;
taTabardReqmtData[65906][4] = 5;
--
taTabardReqmtData[65905] = {};
taTabardReqmtData[65905][0] = 1;
taTabardReqmtData[65905][1] = 0;
taTabardReqmtData[65905][2] = 1;
taTabardReqmtData[65905][3] = 1135;
taTabardReqmtData[65905][4] = 5;
--
taTabardReqmtData[65904] = {};
taTabardReqmtData[65904][0] = 1;
taTabardReqmtData[65904][1] = 0;
taTabardReqmtData[65904][2] = 1;
taTabardReqmtData[65904][3] = 1173;
taTabardReqmtData[65904][4] = 5;
--
taTabardReqmtData[64884] = {};
taTabardReqmtData[64884][0] = 1;
taTabardReqmtData[64884][1] = 2;
taTabardReqmtData[64884][2] = 0;
taTabardReqmtData[64884][3] = 0;
taTabardReqmtData[64884][4] = 0;
--
taTabardReqmtData[64882] = {};
taTabardReqmtData[64882][0] = 1;
taTabardReqmtData[64882][1] = 1;
taTabardReqmtData[64882][2] = 0;
taTabardReqmtData[64882][3] = 0;
taTabardReqmtData[64882][4] = 0;
--
taTabardReqmtData[63379] = {};
taTabardReqmtData[63379][0] = 1;
taTabardReqmtData[63379][1] = 1;
taTabardReqmtData[63379][2] = 1;
taTabardReqmtData[63379][3] = 1177;
taTabardReqmtData[63379][4] = 6; -- plus 40 tol barad marks
--
taTabardReqmtData[63378] = {};
taTabardReqmtData[63378][0] = 1;
taTabardReqmtData[63378][1] = 2;
taTabardReqmtData[63378][2] = 1;
taTabardReqmtData[63378][3] = 1178;
taTabardReqmtData[63378][4] = 6; -- plus 40 tol barad marks
--
taTabardReqmtData[56246] = {};
taTabardReqmtData[56246][0] = 0;
taTabardReqmtData[56246][1] = 0;
taTabardReqmtData[56246][2] = 0;
taTabardReqmtData[56246][3] = 0;
taTabardReqmtData[56246][4] = 0;
--
taTabardReqmtData[69209] = {};
taTabardReqmtData[69209][0] = 1;
taTabardReqmtData[69209][1] = 0;
taTabardReqmtData[69209][2] = 1;
taTabardReqmtData[69209][3] = 1168;
taTabardReqmtData[69209][4] = 5;
--
taTabardReqmtData[69210] = {};
taTabardReqmtData[69210][0] = 1;
taTabardReqmtData[69210][1] = 0;
taTabardReqmtData[69210][2] = 1;
taTabardReqmtData[69210][3] = 1168;
taTabardReqmtData[69210][4] = 6;
-- 
-- MOP
taTabardReqmtData[83080] = {};
taTabardReqmtData[83080][0] = 1;
taTabardReqmtData[83080][1] = 2;
taTabardReqmtData[83080][2] = 0;
taTabardReqmtData[83080][3] = 0;
taTabardReqmtData[83080][4] = 0;
--
taTabardReqmtData[83079] = {};
taTabardReqmtData[83079][0] = 1;
taTabardReqmtData[83079][1] = 1;
taTabardReqmtData[83079][2] = 0;
taTabardReqmtData[83079][3] = 0;
taTabardReqmtData[83079][4] = 0;
--
taTabardReqmtData[89800] = {};
taTabardReqmtData[89800][0] = 1;
taTabardReqmtData[89800][1] = 0;
taTabardReqmtData[89800][2] = 1;
taTabardReqmtData[89800][3] = 1270;
taTabardReqmtData[89800][4] = 8;
--
taTabardReqmtData[89799] = {};
taTabardReqmtData[89799][0] = 1;
taTabardReqmtData[89799][1] = 0;
taTabardReqmtData[89799][2] = 1;
taTabardReqmtData[89799][3] = 1341;
taTabardReqmtData[89799][4] = 8;
--
taTabardReqmtData[89798] = {};
taTabardReqmtData[89798][0] = 1;
taTabardReqmtData[89798][1] = 0;
taTabardReqmtData[89798][2] = 1;
taTabardReqmtData[89798][3] = 1337;
taTabardReqmtData[89798][4] = 8;
--
taTabardReqmtData[89797] = {};
taTabardReqmtData[89797][0] = 1;
taTabardReqmtData[89797][1] = 0;
taTabardReqmtData[89797][2] = 1;
taTabardReqmtData[89797][3] = 1269;
taTabardReqmtData[89797][4] = 8;
--
taTabardReqmtData[89796] = {};
taTabardReqmtData[89796][0] = 1;
taTabardReqmtData[89796][1] = 0;
taTabardReqmtData[89796][2] = 1;
taTabardReqmtData[89796][3] = 1271;
taTabardReqmtData[89796][4] = 8;
--
taTabardReqmtData[89795] = {};
taTabardReqmtData[89795][0] = 1;
taTabardReqmtData[89795][1] = 0;
taTabardReqmtData[89795][2] = 1;
taTabardReqmtData[89795][3] = 1345;
taTabardReqmtData[89795][4] = 8;
--
taTabardReqmtData[89784] = {};
taTabardReqmtData[89784][0] = 1;
taTabardReqmtData[89784][1] = 0;
taTabardReqmtData[89784][2] = 1;
taTabardReqmtData[89784][3] = 1272;
taTabardReqmtData[89784][4] = 8;
--
taTabardReqmtData[89401] = {};
taTabardReqmtData[89401][0] = 1;
taTabardReqmtData[89401][1] = 0;
taTabardReqmtData[89401][2] = 1;
taTabardReqmtData[89401][3] = 1302;
taTabardReqmtData[89401][4] = 8;
--
-- Theramore tabard
taTabardReqmtData[89196] = {};
taTabardReqmtData[89196][0] = 0;
taTabardReqmtData[89196][1] = 0;
taTabardReqmtData[89196][2] = 0;
taTabardReqmtData[89196][3] = 0;
taTabardReqmtData[89196][4] = 0;
--
-- 5.2 - Isle of Thunder
taTabardReqmtData[97131] = {};
taTabardReqmtData[97131][0] = 1;
taTabardReqmtData[97131][1] = 0;
taTabardReqmtData[97131][2] = 1;
taTabardReqmtData[97131][3] = 1435;
taTabardReqmtData[97131][4] = 8;
--
taTabardReqmtData[95592] = {};
taTabardReqmtData[95592][0] = 1;
taTabardReqmtData[95592][1] = 2;
taTabardReqmtData[95592][2] = 1;
taTabardReqmtData[95592][3] = 1388;
taTabardReqmtData[95592][4] = 8;
--
taTabardReqmtData[95591] = {};
taTabardReqmtData[95591][0] = 1;
taTabardReqmtData[95591][1] = 1;
taTabardReqmtData[95591][2] = 1;
taTabardReqmtData[95591][3] = 1387;
taTabardReqmtData[95591][4] = 8;
--
taTabardReqmtData[98162] = {};
taTabardReqmtData[98162][0] = 1;
taTabardReqmtData[98162][1] = 0;
taTabardReqmtData[98162][2] = 4;
taTabardReqmtData[98162][3] = "1000 "..L.SUGG_CURRENCY_CONQUEST;
taTabardReqmtData[98162][4] = 10;
--
taTabardReqmtData[101697] = {};
taTabardReqmtData[101697][0] = 1;
taTabardReqmtData[101697][1] = 0;
taTabardReqmtData[101697][2] = 4;
taTabardReqmtData[101697][3] = "1000 "..L.SUGG_CURRENCY_CONQUEST;
taTabardReqmtData[101697][4] = 10;
--
--
taTabardReqmtSpecial = {};
taTabardReqmtSpecial[35280] = true; -- Midsummer event quest
taTabardReqmtSpecial[35279] = true; -- Midsummer event quest
taTabardReqmtSpecial[25549] = true; -- paladin blood elf only
taTabardReqmtSpecial[24344] = true; -- draenei only
taTabardReqmtSpecial[31404] = true; -- reward from quest 10781
taTabardReqmtSpecial[31405] = true; -- reward from quest 10781