--[[
	: A simple Display of current amount of Elder Charms
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Elder Charms|r"
local buttonlabel = "Elder Charms: "
local ID = "EC"
local elapEC, EC, prevEC = 0, 0.0, -2
local GetUnitEC = 0 
local startVal = 0
local inInstance, instanceType, instanceStarted
local CurrencyIndex


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelECButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanElderCharms" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0


 --[[
	for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)				
			print(icon)		
			print(name)		
		end
]]--

	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelECButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelECButton_GetTooltipText",
		frequency = 2,
		icon = "Interface\\Icons\\inv_misc_coin_17.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	
	
	
	
	self:SetScript("OnUpdate", function(this, a1)
		elapEC = elapEC + a1
		if elapEC < 1 then return end
		
		
		
		-- "none" when outside an instance
        -- "pvp" when in a battleground
        -- "arena" when in an arena
        -- "party" when in a 5-man instance
        -- "raid" when in a raid instance 


		for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)
			--if name == "Valor Points" then
			if icon == "Interface\\Icons\\inv_misc_coin_17" then
			--print(icon)
				CurrencyIndex = i
			end
			--print(name)
			--Honor Points
			--Conquest Points
			--Valor Points
			--Justice Points
		end

		name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(CurrencyIndex)
 
		local inInstance, instanceType = IsInInstance()
		--if inInstance and instanceType == "pvp"  then
		if GetNumSubgroupMembers() > 0 then
			if instanceStarted == 0 then
				--startVal = count		--commented out so it wont reset
				--print("new group")
			end
			instanceStarted = 1
		else
			instanceStarted = 0
		end

		 EC = count
		 startVal = count
		
		
		if EC == prevEC then return end
		prevEC  = EC
		TitanPanelButton_UpdateButton(ID)
		elapEC = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelECButton_GetButtonText()
----------------------------------------------
	local ECtext, pitchtext
	if not EC then
		ECtext = "0"
	else	
		if startVal == count or startVal == 0 then
			ECtext = string.format("%.0f", EC) .."" 
		else
			if EC - startVal == 0 then
				ECtext = string.format("%.0f", EC) .."" 
			else
				ECtext = string.format("%.0f", EC) .." (+".. EC - startVal..")"
	end
	return buttonlabel, ECtext
end
	end
	return buttonlabel, ECtext
end

-----------------------------------------------
function TitanPanelECButton_GetTooltipText()
-----------------------------------------------


	return "Displays your current value "
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareECMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end