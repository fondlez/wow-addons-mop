--[[
	
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Achievement Points|r"
local buttonlabel = "Achievement Points: "
local ID = "AchP"
local elapAchP, AchP, prevAchP = 0, 0.0, -2
local GetUnitAchP = 0 
local startVal = 0
local inInstance, instanceType, instanceStarted
local CurrencyIndex


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelAchPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanAchievementPoints" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0

startVal =  GetTotalAchievementPoints()

	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelAchPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelAchPButton_GetTooltipText",
		frequency = 2,
		icon = "Interface\\Icons\\ACHIEVEMENT_GUILDPERK_MRPOPULARITY.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	
	
	
	
	self:SetScript("OnUpdate", function(this, a1)
		elapAchP = elapAchP + a1
		if elapAchP < 1 then return end
		
		
		
		

		

		 AchP =  GetTotalAchievementPoints()
		 
		
		
		if AchP == prevAchP then return end
		prevAchP  = AchP
		TitanPanelButton_UpdateButton(ID)
		elapAchP = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelAchPButton_GetButtonText()
----------------------------------------------
	local AchPtext, pitchtext
	if not AchP then
		AchPtext = "0"
	else	
		if startVal == count or startVal == 0 then
			AchPtext = string.format("%.0f", AchP) .."" 
		else
			if AchP - startVal == 0 then
				AchPtext = string.format("%.0f", AchP) .."" 
			else
				AchPtext = string.format("%.0f", AchP) .." (+".. AchP - startVal..")"
	end
	return buttonlabel, AchPtext
end
	end
	return buttonlabel, AchPtext
end

-----------------------------------------------
function TitanPanelAchPButton_GetTooltipText()
-----------------------------------------------


	return "Displays your current value "
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareAchPMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end