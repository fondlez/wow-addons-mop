local targetClassIconFrame = CreateFrame("Frame", "TargetClassIconFrame", TargetFrame)
targetClassIconFrame:SetPoint("CENTER", -124,3)
targetClassIconFrame:SetSize(42,72)

local targetClassIcon = targetClassIconFrame:CreateTexture("TargetClassIcon")
targetClassIcon:SetPoint("TOP",0,-11)
targetClassIcon:SetSize(20,20)
targetClassIcon:SetTexture("Interface\\TARGETINGFRAME\\UI-CLASSES-CIRCLES.BLP")

local targetClassIconBorder = targetClassIconFrame:CreateTexture("TargetClassIconBorder","ARTWORK", nil, 1)
targetClassIconBorder:SetPoint("CENTER",targetClassIcon)
targetClassIconBorder:SetSize(43,43)
targetClassIconBorder:SetTexture("Interface\\UNITPOWERBARALT\\WowUI_Circular_Frame.blp")

local targetFaction = targetClassIconFrame:CreateTexture("TargetFaction", "BACKGROUND")
targetFaction:SetPoint("TOP",0,-20)
targetFaction:SetSize(20,40)
targetFaction:SetTexture("Interface\\Glues\\CHARACTERCREATE\\UI-CHARACTERCREATE-BANNERS")

local targetType = targetClassIconFrame:CreateFontString()
targetType:SetFont("Fonts\\FRIZQT__.TTF",9,"OUTLINE")
targetType:SetPoint("BOTTOMLEFT",targetClassIconFrame,"TOPLEFT",10,-6)

targetClassIconFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
targetClassIconFrame:RegisterEvent("UNIT_AURA")

targetClassIconFrame:SetScript("OnEvent", 
	function (self, event, ...)
		if event == "PLAYER_TARGET_CHANGED" or (event == "UNIT_AURA" and ... == "target" ) then
			targetType:SetText(UnitCreatureType("target"))
		end

		if event == "PLAYER_TARGET_CHANGED" then

			local targetClass = select(2,UnitClass("target"))

			if targetClass == "WARRIOR" then
				targetClassIcon:SetTexCoord(0,.25,0,.25)
			elseif targetClass == "MAGE" then
				targetClassIcon:SetTexCoord(.25,.5,0,.25)
			elseif targetClass == "ROGUE" then
				targetClassIcon:SetTexCoord(.5,.74,0,.25)
			elseif targetClass == "DRUID" then
				targetClassIcon:SetTexCoord(.75,.98,0,.25)
			elseif targetClass == "HUNTER" then
				targetClassIcon:SetTexCoord(0,.25,.25,.5)
			elseif targetClass == "SHAMAN" then
				targetClassIcon:SetTexCoord(.25,.5,.25,.5)
			elseif targetClass == "PRIEST" then
				targetClassIcon:SetTexCoord(.5,.74,.25,.5)
			elseif targetClass == "WARLOCK" then
				targetClassIcon:SetTexCoord(.75,.98,.25,.5)
			elseif targetClass == "PALADIN" then
				targetClassIcon:SetTexCoord(0,.25,.5,.75)
			elseif targetClass == "DEATHKNIGHT" then
				targetClassIcon:SetTexCoord(.25,.5,.5,.75)
			elseif targetClass == "MONK" then
				targetClassIcon:SetTexCoord(.5,.74,.5,.75)
			end

			if UnitIsPlayer("target") then
				targetFaction:Show()
				if UnitFactionGroup("target") == "Alliance" then
					targetFaction:SetTexCoord(.13,.47,.38,.72)
				elseif UnitFactionGroup("target") == "Horde" then
					targetFaction:SetTexCoord(.53,.86,.39,.72)
				else
					targetFaction:Hide()
				end
				--targetPlayerString:Show()
			else
				targetFaction:Hide()
				--targetPlayerString:Hide()
			end
						--	targetFaction:Hide()

		end
	end
)

