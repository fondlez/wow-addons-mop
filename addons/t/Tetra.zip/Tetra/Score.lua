--------------------------------------------------------------------------------
--SCORE ENGINE
--------------------------------------------------------------------------------

Score = {}

Score.Create = function()
  Score.Reset();
 end

Score.Reset = function()
  Score.Score = 0;
  Score.Lines = 0;
  Score.Level = 1;
  Score.Mult = 1.0;
  Score.Update();
 end;

Score.IncreaseLevel = function()
  Score.Level = Score.Level + 1;
  Score.Mult = Score.Mult + 0.2;
  Score.Update();
 end;

Score.LandBlock = function()
  Score.Score = Score.Score + math.floor(5 * Score.Mult);
  Score.Update();
 end;

Score.LineClear = function(linecount)
  Score.Lines = Score.Lines + linecount;
  Score.Score = Score.Score + math.floor(linecount * 50 * ( linecount * 3/2 ) * Score.Mult);
  Score.Update();
 end;

Score.Update = function()
  Tetra_Score_Text:SetText(Score.Score);
  Tetra_Lines_Text:SetText(Score.Lines);
  Tetra_Level_Text:SetText(Score.Level);
 end;

function Tetra_PublishScore()
  temp = "[TETRA] " .. MyName .. " with " .. Score.Lines .. " lines has scored " .. Score.Score .. " points on level " .. Score.Level .. " in " .. Mode .. " mode.";
  SendChatMessage(temp , "GUILD", nil);
  Tetra_PublishButton:Hide();
end
