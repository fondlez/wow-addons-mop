
O = {}

 O.Create = function()
  O.Arow = 1;
  O.Acol = 5;
  O.Brow = 1;
  O.Bcol = 6;
  O.Crow = 2;
  O.Ccol = 5;
  O.Drow = 2;
  O.Dcol = 6;

  O.InPlay = false;
  O.Dir =  North;
  O.BT = BTO;
 end

 O.Throw = function()
  O.InPlay = true;
 end

 O.Down = function()


  if (O.Crow < 20)
   and (Board[O.Drow+1][O.Dcol] == BTNone)
   and (Board[O.Crow+1][O.Ccol] == BTNone)
    then

           O.DrawClear();
            O.Arow = O.Arow + 1;
            O.Brow = O.Brow + 1;
            O.Crow = O.Crow + 1;
            O.Drow = O.Drow + 1;
           O.Draw();
           result = true;
          else
            result = false;
  end
  return result;
 end;

 O.Right = function()


 if (O.Bcol < 10)
  and (Board[O.Brow][O.Bcol+1] == BTNone)
  and (Board[O.Drow][O.Dcol+1] == BTNone)
    then

           O.DrawClear();
            O.Acol = O.Acol + 1;
            O.Bcol = O.Bcol + 1;
            O.Ccol = O.Ccol + 1;
            O.Dcol = O.Dcol + 1;
           O.Draw();
    end
 end

 O.Left  = function()


 if (O.Acol > 1)
  and (Board[O.Arow][O.Acol-1] == BTNone)
  and (Board[O.Crow][O.Ccol-1] == BTNone)
    then

           O.DrawClear();
            O.Acol = O.Acol - 1;
            O.Bcol = O.Bcol - 1;
            O.Ccol = O.Ccol - 1;
            O.Dcol = O.Dcol - 1;
           O.Draw();
    end;
 end;

 O.RotateClock = function()
  end

 O.RotateCounter = function()
  end

 O.GetHighLow = function(high, low)
  high = O.Drow;
  low  = O.Arow;
 end;

 O.DrawClear = function()

  Tetra_Draw(O.Arow,O.Acol,BTNone);
  Tetra_Draw(O.Brow,O.Bcol,BTNone);
  Tetra_Draw(O.Crow,O.Ccol,BTNone);
  Tetra_Draw(O.Drow,O.Dcol,BTNone);
 end;

 O.Draw = function()
  Tetra_Draw(O.Arow,O.Acol,O.BT);
  Tetra_Draw(O.Brow,O.Bcol,O.BT);
  Tetra_Draw(O.Crow,O.Ccol,O.BT);
  Tetra_Draw(O.Drow,O.Dcol,O.BT);
 end;

 O.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreO");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreO");
  end 
 end

 O.Convert = function()

  Board[O.Arow][O.Acol] = BTO;
  Board[O.Brow][O.Bcol] = BTO;
  Board[O.Crow][O.Ccol] = BTO;
  Board[O.Drow][O.Dcol] = BTO;

 end;

 O.Lose = function()
  result = true;
   if (Board[O.Arow][O.Acol] == BTNone) and
      (Board[O.Brow][O.Bcol] == BTNone) and
      (Board[O.Crow][O.Ccol] == BTNone) and
      (Board[O.Drow][O.Dcol] == BTNone) then

      result = false
   end
  return result;
 end;