T = {}

 T.Create = function()
  T.Arow = 1; --A row
  T.Acol = 4; --A col
  T.Brow = 1; --B row
  T.Bcol = 5; --B col
  T.Crow = 1; --C row
  T.Ccol = 6; --C col
  T.Drow = 2; --D row
  T.Dcol = 5; --D col

  T.InPlay = false;
  T.Dir =  North;
  T.BT = BTT;
 end

 T.Draw = function()
  Tetra_Draw(T.Arow,T.Acol,T.BT);
  Tetra_Draw(T.Brow,T.Bcol,T.BT);
  Tetra_Draw(T.Crow,T.Ccol,T.BT);
  Tetra_Draw(T.Drow,T.Dcol,T.BT);
 end

 T.DrawClear = function()
  Tetra_Draw(T.Arow,T.Acol,BTNone);
  Tetra_Draw(T.Brow,T.Bcol,BTNone);
  Tetra_Draw(T.Crow,T.Ccol,BTNone);
  Tetra_Draw(T.Drow,T.Dcol,BTNone);
 end

 T.Throw = function()
  T.InPlay = true;
 end

 T.Down = function()
  Check = false;
 if (T.Dir == North) then
     if (T.Drow < 20) then
       if   (Board[T.Crow+1][T.Ccol] == BTNone)
        and (Board[T.Drow+1][T.Dcol] == BTNone)
        and (Board[T.Arow+1][T.Acol] == BTNone)
         then
     Check = true;
       end
     end
  end

  if (T.Dir == East) then
     if (T.Crow < 20) then
       if   (Board[T.Crow+1][T.Ccol] == BTNone)
        and (Board[T.Drow+1][T.Dcol] == BTNone)
         then  Check = true;
       end
     end
  end

  if (T.Dir == South) then
     if (T.Arow < 20) then
       if   (Board[T.Crow+1][T.Ccol] == BTNone)
        and (Board[T.Brow+1][T.Bcol] == BTNone)
        and (Board[T.Arow+1][T.Acol] == BTNone)
         then  Check = true;
       end
     end
  end

  if (T.Dir == West) then
     if (T.Arow < 20) then
       if   (Board[T.Drow+1][T.Dcol] == BTNone)
        and (Board[T.Arow+1][T.Acol] == BTNone)
         then  Check = true;
       end
     end
  end


  if (Check == true) then
           T.DrawClear();
            T.Arow = T.Arow + 1;
            T.Brow = T.Brow + 1;
            T.Crow = T.Crow + 1;
            T.Drow = T.Drow + 1;
           T.Draw();
          end;

  return Check;
 end;

T.Right = function()
 Check = false;

  if (T.Dir == North)  then
     if (T.Ccol < 10) then
       if   (Board[T.Crow][T.Ccol+1] == BTNone)
        and (Board[T.Drow][T.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
  end
  if T.Dir == East  then
     if T.Acol < 10 then
       if   (Board[T.Arow][T.Acol+1] == BTNone)
        and (Board[T.Brow][T.Bcol+1] == BTNone)
        and (Board[T.Crow][T.Ccol+1] == BTNone)
         then  Check = true;
       end
     end
  end
  if T.Dir == South  then
     if T.Acol < 10 then
       if   (Board[T.Arow][T.Acol+1] == BTNone)
        and (Board[T.Drow][T.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
  end
  if T.Dir == West  then
     if T.Dcol < 10 then
       if   (Board[T.Crow][T.Ccol+1] == BTNone)
        and (Board[T.Arow][T.Acol+1] == BTNone)
        and (Board[T.Drow][T.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
  end

  if Check == true then
           T.DrawClear();
            T.Acol = T.Acol + 1;
            T.Bcol = T.Bcol + 1;
            T.Ccol = T.Ccol + 1;
            T.Dcol = T.Dcol + 1;
           T.Draw();
          end
 end

T.Left = function()
 Check = false;

  if T.Dir == North then
    if T.Acol > 1 then
       if   (Board[T.Arow][T.Acol-1] == BTNone)
        and (Board[T.Drow][T.Dcol-1] == BTNone)
         then  Check = true;
       end
    end
  end
  if T.Dir == East then
     if T.Dcol > 1 then
       if   (Board[T.Crow][T.Ccol-1] == BTNone)
        and (Board[T.Drow][T.Dcol-1] == BTNone)
        and (Board[T.Arow][T.Acol-1] == BTNone)
         then  Check = true;
       end
    end
  end
  if T.Dir == South then
     if T.Ccol > 1 then
       if   (Board[T.Crow][T.Ccol-1] == BTNone)
        and (Board[T.Drow][T.Dcol-1] == BTNone)
         then  Check = true;
       end
    end
  end
  if T.Dir == West then
     if T.Acol > 1 then
       if   (Board[T.Arow][T.Acol-1] == BTNone)
        and (Board[T.Crow][T.Ccol-1] == BTNone)
        and (Board[T.Brow][T.Bcol-1] == BTNone)
         then  Check = true;
       end
    end
  end

  if Check == true then
           T.DrawClear();
            T.Acol = T.Acol - 1;
            T.Bcol = T.Bcol - 1;
            T.Ccol = T.Ccol - 1;
            T.Dcol = T.Dcol - 1;
           T.Draw();
          end;
 end;

 T.RotateClock = function()
  temp = T.Dir;
  T.DrawClear();
  if T.Dir == North then
   if (T.Arow > 1) and
      (Board[T.Arow-1][T.Acol+1] == BTNone) then

     temp = East;
     T.Arow = T.Arow - 1;
     T.Acol = T.Acol + 1;
     T.Crow = T.Crow + 1;
     T.Ccol = T.Ccol - 1;
     T.Drow = T.Drow - 1;
     T.Dcol = T.Dcol - 1;
    end
  end

  if T.Dir == West then
   if (T.Acol > 1) and (Board[T.Arow-1][T.Acol-1] == BTNone) then

     temp = North;
     T.Arow = T.Arow - 1;
     T.Acol = T.Acol - 1;
     T.Crow = T.Crow + 1;
     T.Ccol = T.Ccol + 1;
     T.Drow = T.Drow + 1;
     T.Dcol = T.Dcol - 1;
    end
  end

  if T.Dir == South then
   if (T.Arow < 20)
    and (Board[T.Arow+1][T.Acol-1] == BTNone) then

     temp = West;
     T.Arow = T.Arow + 1;
     T.Acol = T.Acol - 1;
     T.Crow = T.Crow - 1;
     T.Ccol = T.Ccol + 1;
     T.Drow = T.Drow + 1;
     T.Dcol = T.Dcol + 1;
    end
  end

  if T.Dir == East then
   if (T.Bcol < 10) and (Board[T.Arow+1][T.Acol+1] == BTNone) then

     temp = South;
     T.Arow = T.Arow + 1;
     T.Acol = T.Acol + 1;
     T.Crow = T.Crow - 1;
     T.Ccol = T.Ccol - 1;
     T.Drow = T.Drow - 1;
     T.Dcol = T.Dcol + 1;
    end
  end

  T.Draw();
  T.Dir = temp;

 end

T.RotateCounter = function()
  temp = dir;
  T.DrawClear();
  if T.Dir == North then
   if (T.Arow > 1) and
      (Board[T.Crow-1][T.Ccol-1] == BTNone) then

     temp = West;
     T.Arow = T.Arow + 1;
     T.Acol = T.Acol + 1;
     T.Crow = T.Crow - 1;
     T.Ccol = T.Ccol - 1;
     T.Drow = T.Drow - 1;
     T.Dcol = T.Dcol + 1;
    end
  end

  if T.Dir == West then
   if (T.Acol > 1) and (Board[T.Crow+1][T.Ccol-1] == BTNone) then

     temp = South;
     T.Arow = T.Arow - 1;
     T.Acol = T.Acol + 1;
     T.Crow = T.Crow + 1;
     T.Ccol = T.Ccol - 1;
     T.Drow = T.Drow - 1;
     T.Dcol = T.Dcol - 1;
    end
  end

  if T.Dir == South then
   if (T.Arow < 20)
    and (Board[T.Crow+1][T.Ccol+1] == BTNone) then

     temp = East;
     T.Arow = T.Arow - 1;
     T.Acol = T.Acol - 1;
     T.Crow = T.Crow + 1;
     T.Ccol = T.Ccol + 1;
     T.Drow = T.Drow + 1;
     T.Dcol = T.Dcol - 1;
    end
  end

  if T.Dir == East then
   if (T.Bcol < 10) and (Board[T.Crow-1][T.Ccol+1] == BTNone) then

     temp = North;
     T.Arow = T.Arow + 1;
     T.Acol = T.Acol - 1;
     T.Crow = T.Crow - 1;
     T.Ccol = T.Ccol + 1;
     T.Drow = T.Drow + 1;
     T.Dcol = T.Dcol + 1;
    end
  end

  T.Dir = temp;
  T.Draw();
 end


T.GetHighLow = function(high, low) --not sure if this will work since we can't pass by reference in lua
 high = 20;
 low = 1;
 if T.Dir == North then
       high = T.Drow;
       low  = T.Arow;
      end
 if T.Dir == East then
       high = T.Crow;
       low  = T.Arow;
      end
 if T.Dir == South then
       high = T.Arow;
       low  = T.Drow;
      end
 if T.Dir == West then
       high = T.Arow;
       low  = T.Crow;
      end
 end;

T.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreT");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreT");
  end 
 end

T.Lose = function()
  result = true;
   if (Board[T.Arow][T.Acol] == BTNone) and
      (Board[T.Brow][T.Bcol] == BTNone) and
      (Board[T.Crow][T.Ccol] == BTNone) and
      (Board[T.Drow][T.Dcol] == BTNone) then

      result = false
   end
  return result;
 end

T.Convert = function()
  Board[T.Arow][T.Acol] = BTT;
  Board[T.Brow][T.Bcol] = BTT;
  Board[T.Crow][T.Ccol] = BTT;
  Board[T.Drow][T.Dcol] = BTT;
 end
