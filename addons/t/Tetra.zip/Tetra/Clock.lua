 --CLOCK
 function Tetra_OnUpdate(self, elapsed)

  TimeSinceLastUpdate = TimeSinceLastUpdate + elapsed;
  CountTime = CountTime + elapsed;

  if (TimeSinceLastUpdate > Interval) then
    -- Insert your OnUpdate code here
    TimeSinceLastUpdate = 0;
    Tetra_PerformAction();
  end

  if (CountTime > DropInterval) then
    CountTime = 0;
    if (Paused == false)  then
       Tetra_BlockFall();
    end
  end

 end



