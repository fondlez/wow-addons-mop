function Tetra_OnLoad()
  SlashCmdList["Tetra_CMD_SHOW"] = Tetra_Run;
  SLASH_Tetra_CMD_SHOW1 = "/tetra";

  --CONSTANTS
  BTNone = 0;
  BTL = 1;                                                                        
  BTJ = 2;
  BTO = 3;
  BTT = 4;
  BTS = 5;
  BTZ = 6;
  BTI = 7;

  TimeSinceLastUpdate = 0.0;

  DrawSize = 26;
  OffSetX = 0;
  OffSetY = 0;

  SizeCol = 10;
  SizeRow = 20;

  NextLevel = 10;

  Mode = "Classic";
  --Mode control variables
  Mirrored = "False";

  North = 1;
  East = 2;
  South = 3;
  West = 4;

  Paused = true;
  Control = "";
  CountTime = 0;

  MyName = UnitName("player");

  Interval = 0.075;
  DropInterval = 1.200;

  Tetra_PublishButton:Hide();
  Tetra_Core:EnableKeyboard(true);
  Tetra_CreateBoard();
  Score.Create();
  Sound.Create();

  Tetra_InitMenu();
  Tetra_HideGUI();

  Tetra_LevelSel_Caption:SetTextColor(0,0,0);
  Tetra_Mode_StaticCaption:SetTextColor(0,0,0);
  Tetra_NextBlock_Caption:SetTextColor(0,0,0);
  Tetra_HoldBlock_Caption:SetTextColor(0,0,0);

end

--------------------------------------------------------------------------------
--HIDE AND SHOW GUI
--------------------------------------------------------------------------------

function Tetra_HideGUI()
  Tetra_Core:Hide();
  for row=1,20 do
    for col=1,10 do
      BoardGraphics[row][col]:Hide();
    end
  end
  PreviewBlock:Hide();
  HoldPreBlock:Hide();
  BackGroundImg:Hide();
  BorderImg:Hide();
  NextImg:Hide();
  MyDropDownMenu:Hide();
end

function Tetra_Run()
  Tetra_Core:Show();
  for row=1,20 do
    for col=1,10 do
      BoardGraphics[row][col]:Show();
    end
  end
  PreviewBlock:Show();
  HoldPreBlock:Show();
  BackGroundImg:Show();
  BorderImg:Show();
  NextImg:Show();
  MyDropDownMenu:Show();
end

--SOMETHING ELSE

function Tetra_MuteSound()
  Sound.MuteSound();
 end



function Tetra_Event()
     Tetra_MinimapButton_Reposition();
end

--------------------------------------------------------------------------------
--INITIALIZE GAME COMPONENTS
--------------------------------------------------------------------------------

 function Tetra_CreateBoard()

    Board = {}          -- create the matrix
    for row=1,20 do
      Board[row] = {}     -- create a new row
      for col=1,10 do
        Board[row][col] = BTNone;
      end
    end

    BoardGraphics = {}          -- create the matrix
    for row=1,20 do
      BoardGraphics[row] = {}     -- create a new row
      for col=1,10 do
        BoardGraphics[row][col] = CreateFrame("FRAME", Tetra_Core, UIParent);
        BoardGraphics[row][col]:SetWidth(DrawSize);
        BoardGraphics[row][col]:SetHeight(DrawSize);
        BoardGraphics[row][col]:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",col*DrawSize-11,(-row - 1)*DrawSize);

        BoardGraphics[row][col].Frame = BoardGraphics[row][col]:CreateTexture(nil, "FOREGROUND");
        BoardGraphics[row][col].Frame:SetAllPoints();
        BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\None");

        BoardGraphics[row][col]:Show();
      end
    end

        PreviewBlock = CreateFrame("FRAME", Tetra_Core, UIParent);
        PreviewBlock:SetWidth(DrawSize*4);
        PreviewBlock:SetHeight(DrawSize*4);
        PreviewBlock:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",DrawSize*12-10,-3*DrawSize+30);

        PreviewBlock.Frame = PreviewBlock:CreateTexture(nil, "FOREGROUND");
        PreviewBlock.Frame:SetAllPoints();
        PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\None");
        PreviewBlock:Show();

        HoldPreBlock = CreateFrame("FRAME", Tetra_Core, UIParent);
        HoldPreBlock:SetWidth(DrawSize*4);
        HoldPreBlock:SetHeight(DrawSize*4);
        HoldPreBlock:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",DrawSize*12-10,-3*DrawSize-85);

        HoldPreBlock.Frame = HoldPreBlock:CreateTexture(nil, "FOREGROUND");
        HoldPreBlock.Frame:SetAllPoints();
        HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\None");
        HoldPreBlock:Show();

        
        BorderImg = CreateFrame("FRAME", Tetra_Core, UIParent);
        BorderImg:SetWidth(DrawSize*11);
        BorderImg:SetHeight(DrawSize*22-13);
        BorderImg:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",3,-26);

        BorderImg.Frame = BorderImg:CreateTexture(nil, "FOREGROUND");
        BorderImg.Frame:SetAllPoints();
        BorderImg.Frame:SetTexture("interface\\addons\\Tetra\\Images\\Border");
        BorderImg:Show();


        BackGroundImg = CreateFrame("FRAME", Tetra_Core, UIParent);
        BackGroundImg:SetWidth(DrawSize*11);
        BackGroundImg:SetHeight(DrawSize*22-13);
        BackGroundImg:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",3,-26);

        BackGroundImg.Frame = BackGroundImg:CreateTexture(nil, "BACKGROUND");
        BackGroundImg.Frame:SetAllPoints();
        BackGroundImg.Frame:SetTexture("interface\\addons\\Tetra\\Images\\BG1");
        BackGroundImg:Show();



        NextImg = CreateFrame("FRAME", Tetra_Core, UIParent);
        NextImg:SetWidth(DrawSize*6);
        NextImg:SetHeight(DrawSize*22-13);
        NextImg:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",DrawSize * 11-10,-26);

        NextImg.Frame = NextImg:CreateTexture(nil, "BACKGROUND");
        NextImg.Frame:SetAllPoints();
        NextImg.Frame:SetTexture("interface\\addons\\Tetra\\Images\\NextBorder");

        NextImg:Show();

    Tetra_InitNextBlock();
    Tetra_InitHoldBlock();
    --it appears that initializing them here doesnt actually make them
    --They are instead called at reset_game
    --NextBlock.PreviewDraw(1);
    --HoldBlock.PreviewDraw(2);

 end

--------------------------------------------------------------------------------
--START/RESET/GAMEOVER
--------------------------------------------------------------------------------

function Tetra_StartAtLevel(lvl)
  for loop = 1, (lvl-1) do --increases difficulty accordingly
   Tetra_IncreaseLevel();
  end

  --fill in botton half of the screen with blocks
   for row = 12,20 do
      Count = 0;
      for col = 1,10 do
          IsBlock = math.random(3);
          if ((IsBlock == 1) or (IsBlock == 2)) and (Count < 9) then
             Count = Count + 1;
             --add a block here
             BlockType = math.random(7);
             if     BlockType == 1 then
                Board[row][col] = BTL;
                Tetra_Draw(row,col,BTL);
             elseif BlockType == 2 then
                Board[row][col] = BTJ;
                Tetra_Draw(row,col,BTJ);
             elseif BlockType == 3 then
                Board[row][col] = BTO;
                Tetra_Draw(row,col,BTO);
             elseif BlockType == 4 then
                Board[row][col] = BTT;
                Tetra_Draw(row,col,BTT);
             elseif BlockType == 5 then
                Board[row][col] = BTS;
                Tetra_Draw(row,col,BTS);
             elseif BlockType == 6 then
                Board[row][col] = BTZ;
                Tetra_Draw(row,col,BTZ);
             elseif BlockType == 7 then
                Board[row][col] = BTI;
                Tetra_Draw(row,col,BTI);
             end
           end
        end
    end
 end

 function Tetra_StartGame()
  Tetra_ResetGame();

  if UIDropDownMenu_GetSelectedValue(MyDropDownMenu) > 1 then
        Tetra_StartAtLevel(UIDropDownMenu_GetSelectedValue(MyDropDownMenu));
  end

  Tetra_ThrowBlock();
  Paused = false;
  Sound.PlayMusic(0);
  --set mode variables
  Mirrored = "False";
  if Mode == "Classic" then
      Tetra_RightPlayArea();
  elseif Mode == "-Twist-" then
      Tetra_RightPlayArea();
  end 
 end

 function Tetra_ResetGame()
  DropInterval = 1.2;
  NextLevel = 10;

    for row=1,20 do
      for col=1,10 do
        Board[row][col] = BTNone;
        BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\None");
      end
    end
  Tetra_InitNextBlock();
  Tetra_InitHoldBlock();
  NextBlock.PreviewDraw(1);
  HoldBlock.PreviewDraw(2);
  Score.Reset();
  Tetra_PublishButton:Hide();

  --set mode variables
  Mirrored = "False";
 end

 function Tetra_GameOver()
  Paused = true;
  Tetra_PublishButton:Show();
 end

--------------------------------------------------------------------------------
--GRAPHICS
--------------------------------------------------------------------------------

 function Tetra_Draw(row,col,BT)
  if (BT == BTNone) then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\None");
  end
  if (BT == BTT) then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\T");
  end
  if BT == BTS then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\S");
  end
  if BT == BTZ then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\Z");
  end
  if BT == BTL then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\L1");
  end
  if BT == BTJ then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\L2");
  end
  if BT == BTI then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\Straight");
  end
  if BT == BTO then
   BoardGraphics[row][col].Frame:SetTexture("interface\\addons\\Tetra\\Images\\Square");
  end
 end

--------------------------------------------------------------------------------
--GAME MECHANICS
--------------------------------------------------------------------------------

 function Tetra_InitNextBlock()
  RandBlock = math.random(7);
    if (RandBlock == 1) then NextBlock = T; end
    if (RandBlock == 2) then NextBlock = O; end
    if (RandBlock == 3) then NextBlock = L; end
    if (RandBlock == 4) then NextBlock = J; end
    if (RandBlock == 5) then NextBlock = I; end
    if (RandBlock == 6) then NextBlock = S; end
    if (RandBlock == 7) then NextBlock = Z; end
 end

 function Tetra_InitHoldBlock()
  RandBlock = math.random(7);
    if (RandBlock == 1) then HoldBlock = T; end
    if (RandBlock == 2) then HoldBlock = O; end
    if (RandBlock == 3) then HoldBlock = L; end
    if (RandBlock == 4) then HoldBlock = J; end
    if (RandBlock == 5) then HoldBlock = I; end
    if (RandBlock == 6) then HoldBlock = S; end
    if (RandBlock == 7) then HoldBlock = Z; end
 end

 function Tetra_SwitchHoldNext()
  TempBlock = NextBlock;
  NextBlock = HoldBlock;
  HoldBlock = TempBlock;

  NextBlock.PreviewDraw(1);
  HoldBlock.PreviewDraw(2);
 end

 function Tetra_ThrowBlock()

  RandBlock = math.random(7);

  Block = NextBlock;

    if (RandBlock == 1) then NextBlock = T; end
    if (RandBlock == 2) then NextBlock = O; end
    if (RandBlock == 3) then NextBlock = L; end
    if (RandBlock == 4) then NextBlock = J; end
    if (RandBlock == 5) then NextBlock = I; end
    if (RandBlock == 6) then NextBlock = S; end
    if (RandBlock == 7) then NextBlock = Z; end

  NextBlock.PreviewDraw(1);
  Block.Create();
  Block.Throw();
  Block.Draw();
  if Block.Lose() == true then
      Tetra_GameOver();
  end

 end

 function Tetra_HardDrop()

  repeat
  until (Block.Down() == false)
      Score.LandBlock();
      --Block.GetHighLow(high,low); --need work on passing by reference
      Block.Convert();
      Tetra_CheckLines(1,20);
      Tetra_ThrowBlock();
 end

 function Tetra_BlockFall()
   if (Block.Down() == false) then
      Score.LandBlock();
      --Block.GetHighLow(high,low); --need work on passing by reference
      Block.Convert();
      Tetra_CheckLines(1,20);
      Tetra_ThrowBlock();
   end
 end

 function Tetra_CheckLines(low,high)
  linecount = 0;
  row = high;
  while (row >= low) do
     check = true;

     for col = 1,SizeCol do
      if Board[row][col] == BTNone then
         check = false;
      end
     end

     if (check == true) then
          linecount = linecount + 1;
          Tetra_RemoveLine(row,linecount);
          low = low + 1;
         else
          row = row - 1;
     end
  end

      if (linecount > 0) then
      Score.LineClear(linecount);
      Sound.LineClear(linecount);
	if Mode == "-Twist-" then 
		Tetra_MirrorPlayArea(); 
	end
      NextLevel = NextLevel - linecount;
    end

    if (NextLevel < 1) then
      Tetra_IncreaseLevel();
    end;

 end

 function Tetra_RemoveLine(rowIn,count)
  for Xrow = 0,(rowIn-1) do
   for col = 1,SizeCol do
    if (rowIn - Xrow) > 1 then
      Board[rowIn-Xrow][col] = Board[rowIn - Xrow-1][col];
      Tetra_Draw(rowIn-Xrow,col,Board[rowIn-Xrow][col]);
    else
      Board[rowIn-Xrow][col] = BTNone;
      Tetra_Draw(rowIn-Xrow,col,BTNone);
    end
   end
  end
 end

--------------------------------------------------------------------------------
--GAME DIFFICULTY
--------------------------------------------------------------------------------


function Tetra_IncreaseLevel()
   NextLevel = NextLevel + 10;
   Score.IncreaseLevel();
   Sound.PlayMusic(Score.Level);
   if Score.Level < 21 then
      DropInterval = DropInterval - 0.050;
     end
 end

------------------
--Mode Select Form
------------------
--CAN BE ITS OWN FILE

 function Tetra_SetMode()
  Mode = NewMode;
  Paused = true;
  Tetra_ResetGame();

  Tetra_Mode_Caption:SetText(Mode);

  if Mode == "Classic" then
        Tetra_RightPlayArea();
   elseif Mode == "-  Up  -" then
        Tetra_InvertPlayArea();
  end
 end

StaticPopupDialogs["TETRAMODECHANGE"] = {
  text = "Changing the mode will reset any game currently being played. Continue?",
  button1 = "Yes",
  button2 = "No",
  OnAccept = function()
      Tetra_SetMode();
  end,
  timeout = 0,
  whileDead = 1,
  hideOnEscape = 1
};

function Tetra_RightPlayArea()
 for row = 1,20 do
  for col = 1,10 do
        BoardGraphics[row][col]:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",col*DrawSize-11,(-row - 1)*DrawSize);
  end
 end
end

function Tetra_InvertPlayArea()
 for row = 1,20 do
  for col = 1,10 do
     BoardGraphics[row][col]:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",col*DrawSize-11,(row - 1)*DrawSize - DrawSize*20 - 13);
  end
 end
end

function Tetra_MirrorPlayArea()
 if Mirrored == "False" then  
   for row = 1,20 do
    for col = 1,10 do
       BoardGraphics[row][col]:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",DrawSize*10 - col*DrawSize+16,(-row - 1)*DrawSize);
    end
   end
   temp = "True";
 else  
   for row = 1,20 do
    for col = 1,10 do
       BoardGraphics[row][col]:SetPoint("TOPLEFT", Tetra_Core, "TOPLEFT",col*DrawSize-11,(-row - 1)*DrawSize);
    end
   end
   temp = "False";
 end

Mirrored = temp;
 
end

function Tetra_Mode_SetConfirmation(InMode)
  NewMode = InMode;
  StaticPopup_Show ("TETRAMODECHANGE");
end



--------------------------------------------------------------------------------
--VISUAL CONTROLS
--------------------------------------------------------------------------------

-------------------------
--LEVEL SELECT MENU CONTROLS
-------------------------

function MyDropDownMenuItem_OnClick()
 UIDropDownMenu_SetSelectedValue(this.owner, this.value);
end

function MyDropDownMenu_Initialise()
  local info = UIDropDownMenu_CreateInfo();

for loop = 1,20 do

 info.text = loop;
 info.value = loop;
 info.func = function() MyDropDownMenuItem_OnClick() 
   --UIDropDownMenu_SetSelectedValue(self, loop);
 end;
 info.owner = self;
 info.checked = nil;
 info.icon = nil;
 UIDropDownMenu_AddButton(info, 1);

end

end

function Tetra_InitMenu()
  MyDropDownMenu = CreateFrame("Frame", "MyDropDownMenu", UIParent, "UIDropDownMenuTemplate");
  MyDropDownMenu:SetPoint("TOPLEFT","Tetra_Core",325,-528);


  UIDropDownMenu_SetWidth(MyDropDownMenu,60);
 -- UIDropDownMenu_Initialize(MyDropDownMenu, MyDropDownMenu_Initialise);
  UIDropDownMenu_SetSelectedValue(MyDropDownMenu, 1);
end

----------------
--MINIMAP BUTTON
----------------

Tetra_Settings = {
	MinimapPos = 180 -- default position of the minimap icon in degrees
}

function Tetra_MinimapButton_Reposition()
	Tetra_MinimapButton:SetPoint("TOPLEFT","Minimap","TOPLEFT",52-(80*cos(Tetra_Settings.MinimapPos)),(80*sin(Tetra_Settings.MinimapPos))-52)
end

function Tetra_MinimapButton_DraggingFrame_OnUpdate()

	local xpos,ypos = GetCursorPosition()
	local xmin,ymin = Minimap:GetLeft(), Minimap:GetBottom()

	xpos = xmin-xpos/UIParent:GetScale()+70 -- get coordinates as differences from the center of the minimap
	ypos = ypos/UIParent:GetScale()-ymin-70

	Tetra_Settings.MinimapPos = math.deg(math.atan2(ypos,xpos)) -- save the degrees we are relative to the minimap center
	Tetra_MinimapButton_Reposition() -- move the button
end

--arg1="LeftButton", "RightButton", etc
function Tetra_MinimapButton_OnClick()
	Tetra_Run();
end

function Tetra_MinimapButton_OnLeave()
 GameTooltip:Hide();
end

function Tetra_MinimapButton_OnEnter()
 		GameTooltip_SetDefaultAnchor(GameTooltip, UIParent);
		GameTooltip:SetText("Tetra", 1, 1, 1);
		GameTooltip:Show();
end









