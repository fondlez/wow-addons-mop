J = {}

 J.Create = function()
  J.Dir = North;
  J.Arow = 1;
  J.Acol = 6;
  J.Brow = 2;
  J.Bcol = 6;
  J.Crow = 3;
  J.Ccol = 6;
  J.Drow = 3;
  J.Dcol = 5;

  J.InPlay = false;
  J.Dir =  North;
  J.BT = BTJ;
 end;

 J.Throw = function()
  J.InPlay = true;
 end

 J.Down = function()

 Check = false;

 if J.Dir == North then
     if J.Drow < 20 then
       if   (Board[J.Crow+1][J.Ccol] == BTNone)
        and (Board[J.Drow+1][J.Dcol] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == East then
     if J.Crow < 20 then
       if   (Board[J.Arow+1][J.Acol] == BTNone)
        and (Board[J.Crow+1][J.Ccol] == BTNone)
        and (Board[J.Brow+1][J.Bcol] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == South then
     if J.Arow < 20 then
       if   (Board[J.Arow+1][J.Acol] == BTNone)
        and (Board[J.Drow+1][J.Dcol] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == West then
     if J.Drow < 20 then
       if   (Board[J.Drow+1][J.Dcol] == BTNone)
        and (Board[J.Brow+1][J.Bcol] == BTNone)
        and (Board[J.Arow+1][J.Acol] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           J.DrawClear();
            J.Arow = J.Arow + 1;
            J.Brow = J.Brow + 1;
            J.Crow = J.Crow + 1;
            J.Drow = J.Drow + 1;
           J.Draw();
  end;

  return Check;
 end;

 J.Right = function()

 Check = false;

 if J.Dir == North then
     if J.Acol < 10 then
       if   (Board[J.Arow][J.Acol+1] == BTNone)
        and (Board[J.Brow][J.Bcol+1] == BTNone)
        and (Board[J.Crow][J.Ccol+1] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == East then
     if J.Acol < 10 then
       if   (Board[J.Arow][J.Acol+1] == BTNone)
        and (Board[J.Drow][J.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == South then
     if J.Dcol < 10 then
       if   (Board[J.Arow][J.Acol+1] == BTNone)
        and (Board[J.Brow][J.Bcol+1] == BTNone)
        and (Board[J.Drow][J.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == West then
     if J.Ccol < 10 then
       if   (Board[J.Crow][J.Ccol+1] == BTNone)
        and (Board[J.Drow][J.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           J.DrawClear();
            J.Acol = J.Acol + 1;
            J.Bcol = J.Bcol + 1;
            J.Ccol = J.Ccol + 1;
            J.Dcol = J.Dcol + 1;
           J.Draw();
  end
 end;

 J.Left = function()

 Check = false;

 if J.Dir == North then
     if J.Dcol > 1 then
       if   (Board[J.Arow][J.Acol-1] == BTNone)
        and (Board[J.Brow][J.Bcol-1] == BTNone)
        and (Board[J.Drow][J.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == East then
     if J.Ccol > 1 then
       if   (Board[J.Crow][J.Ccol-1] == BTNone)
        and (Board[J.Drow][J.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == South then
     if J.Ccol > 1 then
       if   (Board[J.Arow][J.Acol-1] == BTNone)
        and (Board[J.Brow][J.Bcol-1] == BTNone)
        and (Board[J.Crow][J.Ccol-1] == BTNone)
         then  Check = true;
       end
     end
 end
 if J.Dir == West then
     if J.Acol > 1 then
       if   (Board[J.Arow][J.Acol-1] == BTNone)
        and (Board[J.Drow][J.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           J.DrawClear();
            J.Acol = J.Acol - 1;
            J.Bcol = J.Bcol - 1;
            J.Ccol = J.Ccol - 1;
            J.Dcol = J.Dcol - 1;
           J.Draw();
  end
 end;

 J.RotateClock = function()

  temp = J.Dir;
  J.DrawClear();
 if J.Dir == North then
   if (J.Acol < 10)
    and (Board[J.Arow+1][J.Acol+1] == BTNone)
    and (Board[J.Crow-1][J.Ccol-1] == BTNone)
    and (Board[J.Drow-2][J.Dcol] == BTNone)  then

     temp = East;
     J.Arow = J.Arow + 1;
     J.Acol = J.Acol + 1;
     J.Crow = J.Crow - 1;
     J.Ccol = J.Ccol - 1;
     J.Drow = J.Drow - 2;
    end;
 end
 if J.Dir == West then
   if   (Board[J.Arow-1][J.Acol+1] == BTNone)
    and (Board[J.Crow+1][J.Ccol-1] == BTNone)
    and (Board[J.Drow][J.Dcol-2] == BTNone) then

     temp = North;
     J.Arow = J.Arow - 1;
     J.Acol = J.Acol + 1;
     J.Crow = J.Crow + 1;
     J.Ccol = J.Ccol - 1;
     J.Dcol = J.Dcol - 2;
    end;
 end
 if J.Dir == South then
   if (J.Acol > 1)
    and (Board[J.Arow-1][J.Acol-1] == BTNone)
    and (Board[J.Crow+1][J.Ccol+1] == BTNone)
    and (Board[J.Drow+2][J.Dcol] == BTNone) then

     temp = West;
     J.Arow = J.Arow - 1;
     J.Acol = J.Acol - 1;
     J.Crow = J.Crow + 1;
     J.Ccol = J.Ccol + 1;
     J.Drow = J.Drow + 2;
    end;
 end
 if J.Dir == East then
   if (J.Arow < 20)
    and (Board[J.Arow+1][J.Acol-1] == BTNone)
    and (Board[J.Crow-1][J.Ccol+1] == BTNone)
    and (Board[J.Drow][J.Dcol+2] == BTNone) then

     temp = South;
     J.Arow = J.Arow + 1;
     J.Acol = J.Acol - 1;
     J.Crow = J.Crow - 1;
     J.Ccol = J.Ccol + 1;
     J.Dcol = J.Dcol + 2;
    end;
 end

  J.Draw();
  J.Dir = temp;

 end;

 J.RotateCounter = function()

  temp = J.Dir;
  J.DrawClear();

 if J.Dir == North then
   if (J.Acol < 10)
    and (Board[J.Arow+1][J.Acol-1] == BTNone)
    and (Board[J.Crow-1][J.Ccol+1] == BTNone)
    and (Board[J.Drow][J.Dcol+2] == BTNone)  then

     temp = West;
     J.Arow = J.Arow + 1;
     J.Acol = J.Acol - 1;
     J.Crow = J.Crow - 1;
     J.Ccol = J.Ccol + 1;
     J.Dcol = J.Dcol + 2;
    end;
 end
 if J.Dir == West then
   if   (Board[J.Arow+1][J.Acol+1] == BTNone)
    and (Board[J.Crow-1][J.Ccol-1] == BTNone)
    and (Board[J.Drow-2][J.Dcol] == BTNone) then

     temp = South;
     J.Arow = J.Arow + 1;
     J.Acol = J.Acol + 1;
     J.Crow = J.Crow - 1;
     J.Ccol = J.Ccol - 1;
     J.Drow = J.Drow - 2;
    end;
 end
 if J.Dir == South then
   if (J.Acol > 1)
    and (Board[J.Arow-1][J.Acol+1] == BTNone)
    and (Board[J.Crow+1][J.Ccol-1] == BTNone)
    and (Board[J.Drow][J.Dcol-2] == BTNone) then

     temp = East;
     J.Arow = J.Arow - 1;
     J.Acol = J.Acol + 1;
     J.Crow = J.Crow + 1;
     J.Ccol = J.Ccol - 1;
     J.Dcol = J.Dcol - 2;
    end;
 end
 if J.Dir == east then
   if   (Board[J.Arow-1][J.Acol-1] == BTNone)
    and (Board[J.Crow+1][J.Ccol+1] == BTNone)
    and (Board[J.Drow+2][J.Dcol] == BTNone) then

     temp = North;
     J.Arow = J.Arow - 1;
     J.Acol = J.Acol - 1;
     J.Crow = J.Crow + 1;
     J.Ccol = J.Ccol + 1;
     J.Drow = J.Drow + 2;
    end;
 end

  J.Dir = temp;
  J.Draw();
 end;

 J.GetHighLow = function(high,low)

 high = 20;
 low = 1;

 if J.Dir == North then
       high = J.Crow;
       low  = J.Arow;
      end;
 if J.Dir == East then
       high = J.Arow;
       low  = J.Drow;
      end;
 if J.Dir == South then
       high = J.Arow;
       low  = J.Crow;
      end;
 if J.Dir == West then
       high = J.Drow;
       low  = J.Arow;
      end;

 end;

 J.DrawClear = function()
  Tetra_Draw(J.Arow,J.Acol,BTNone);
  Tetra_Draw(J.Brow,J.Bcol,BTNone);
  Tetra_Draw(J.Crow,J.Ccol,BTNone);
  Tetra_Draw(J.Drow,J.Dcol,BTNone);
 end;

 J.Draw = function()
  Tetra_Draw(J.Arow,J.Acol,J.BT);
  Tetra_Draw(J.Brow,J.Bcol,J.BT);
  Tetra_Draw(J.Crow,J.Ccol,J.BT);
  Tetra_Draw(J.Drow,J.Dcol,J.BT);
 end;

 J.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreJ");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreJ");
  end 
 end;

 J.Convert = function()

  Board[J.Arow][J.Acol] = BTJ;
  Board[J.Brow][J.Bcol] = BTJ;
  Board[J.Crow][J.Ccol] = BTJ;
  Board[J.Drow][J.Dcol] = BTJ;

 end;

 J.Lose = function()
  result = true;
   if (Board[J.Arow][J.Acol] == BTNone) and
      (Board[J.Brow][J.Bcol] == BTNone) and
      (Board[J.Crow][J.Ccol] == BTNone) and
      (Board[J.Drow][J.Dcol] == BTNone) then

      result = false
   end
  return result;
 end;
