L = {}

 L.Create = function()

  L.Dir = North;
  L.Arow = 1;
  L.Acol = 5;
  L.Brow = 2;
  L.Bcol = 5;
  L.Crow = 3;
  L.Ccol = 5;
  L.Drow = 3;
  L.Dcol = 6;

  L.InPlay = false;
  L.Dir =  North;
  L.BT = BTL;
 end;

 L.Throw = function()
  L.InPlay = true;
 end

 L.Down = function()

 Check = false;

 if L.Dir == North then
     if L.Drow < 20 then
       if   (Board[L.Crow+1][L.Ccol] == BTNone)
        and (Board[L.Drow+1][L.Dcol] == BTNone)
         then  Check = true;
       end
     end
 end
 if L.Dir == East then
     if L.Drow < 20 then
       if   (Board[L.Arow+1][L.Acol] == BTNone)
        and (Board[L.Drow+1][L.Dcol] == BTNone)
        and (Board[L.Brow+1][L.Bcol] == BTNone)
         then  Check = true;
       end
     end
 end
 if L.Dir == South then
     if L.Arow < 20 then
       if   (Board[L.Arow+1][L.Acol] == BTNone)
        and (Board[L.Drow+1][L.Dcol] == BTNone)
         then  Check = true;
       end
     end
 end
 if L.Dir == West then
     if L.Arow < 20 then
       if   (Board[L.Crow+1][L.Ccol] == BTNone)
        and (Board[L.Brow+1][L.Bcol] == BTNone)
        and (Board[L.Arow+1][L.Acol] == BTNone)
         then  Check = true;
       end
     end
 end


  if Check == true then

           L.DrawClear();
            L.Arow = L.Arow + 1;
            L.Brow = L.Brow + 1;
            L.Crow = L.Crow + 1;
            L.Drow = L.Drow + 1;
           L.Draw();
  end

  return Check;
 end;

 L.Right = function()

 Check = false;

  if L.Dir == North then
     if L.Dcol < 10 then
       if   (Board[L.Arow][L.Acol+1] == BTNone)
        and (Board[L.Brow][L.Bcol+1] == BTNone)
        and (Board[L.Drow][L.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end
  if L.Dir == East then
     if L.Acol < 10 then
       if   (Board[L.Arow][L.Acol+1] == BTNone)
        and (Board[L.Drow][L.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end
  if L.Dir == South then
     if L.Acol < 10 then
       if   (Board[L.Arow][L.Acol+1] == BTNone)
        and (Board[L.Brow][L.Bcol+1] == BTNone)
        and (Board[L.Crow][L.Ccol+1] == BTNone)
         then  Check = true;
       end
     end
 end
  if L.Dir == West then
     if L.Ccol < 10 then
       if   (Board[L.Crow][L.Ccol+1] == BTNone)
        and (Board[L.Drow][L.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           L.DrawClear();
            L.Acol = L.Acol + 1;
            L.Bcol = L.Bcol + 1;
            L.Ccol = L.Ccol + 1;
            L.Dcol = L.Dcol + 1;
           L.Draw();
  end
 end;

 L.Left = function()

 Check = false;

  if L.Dir == North then
     if L.Acol > 1 then
       if   (Board[L.Arow][L.Acol-1] == BTNone)
        and (Board[L.Brow][L.Bcol-1] == BTNone)
        and (Board[L.Crow][L.Ccol-1] == BTNone)
         then  Check = true;
       end
     end
  end
  if L.Dir == East then
     if L.Ccol > 1 then
       if   (Board[L.Crow][L.Ccol-1] == BTNone)
        and (Board[L.Drow][L.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
  end
  if L.Dir == South then
     if L.Dcol > 1 then
       if   (Board[L.Arow][L.Acol-1] == BTNone)
        and (Board[L.Brow][L.Bcol-1] == BTNone)
        and (Board[L.Drow][L.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
  end
  if L.Dir == West then
     if L.Acol > 1 then
       if   (Board[L.Arow][L.Acol-1] == BTNone)
        and (Board[L.Drow][L.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
  end

  if Check == true then

           L.DrawClear();
            L.Acol = L.Acol - 1;
            L.Bcol = L.Bcol - 1;
            L.Ccol = L.Ccol - 1;
            L.Dcol = L.Dcol - 1;
           L.Draw();
  end
 end;

 L.RotateClock = function()

  temp = L.Dir;
  L.DrawClear();

 if L.Dir == North then
   if (L.Acol > 1)
    and (Board[L.Arow+1][L.Acol+1] == BTNone)
    and (Board[L.Crow-1][L.Ccol-1] == BTNone)
    and (Board[L.Drow][L.Dcol-2] == BTNone)  then

     temp = East;
     L.Arow = L.Arow + 1;
     L.Acol = L.Acol + 1;
     L.Crow = L.Crow - 1;
     L.Ccol = L.Ccol - 1;
     L.Dcol = L.Dcol - 2;
    end;
 end

 if L.Dir == West then
   if   (Board[L.Arow-1][L.Acol+1] == BTNone)
    and (Board[L.Crow+1][L.Ccol-1] == BTNone)
    and (Board[L.Drow+2][L.Dcol] == BTNone) then

     temp = North;
     L.Arow = L.Arow - 1;
     L.Acol = L.Acol + 1;
     L.Crow = L.Crow + 1;
     L.Ccol = L.Ccol - 1;
     L.Drow = L.Drow + 2;
    end;
 end

 if L.Dir == South then
   if (L.Acol < 10)
    and (Board[L.Arow-1][L.Acol-1] == BTNone)
    and (Board[L.Crow+1][L.Ccol+1] == BTNone)
    and (Board[L.Drow][L.Dcol+2] == BTNone) then

     temp = West;
     L.Arow = L.Arow - 1;
     L.Acol = L.Acol - 1;
     L.Crow = L.Crow + 1;
     L.Ccol = L.Ccol + 1;
     L.Dcol = L.Dcol + 2;
    end;
 end

 if L.Dir == East then
   if   (Board[L.Arow+1][L.Acol-1] == BTNone)
    and (Board[L.Crow-1][L.Ccol+1] == BTNone)
    and (Board[L.Drow-2][L.Dcol] == BTNone) then

     temp = South;
     L.Arow = L.Arow + 1;
     L.Acol = L.Acol - 1;
     L.Crow = L.Crow - 1;
     L.Ccol = L.Ccol + 1;
     L.Drow = L.Drow - 2;
    end;
 end

  L.Draw();
  L.Dir = temp;

 end;

 L.RotateCounter = function()

  temp = L.Dir;
  L.DrawClear();

 if L.Dir == North then
   if (L.Acol > 1)
    and (Board[L.Arow+1][L.Acol-1] == BTNone)
    and (Board[L.Crow-1][L.Ccol+1] == BTNone)
    and (Board[L.Drow-2][L.Dcol] == BTNone)  then

     temp = West;
     L.Arow = L.Arow + 1;
     L.Acol = L.Acol - 1;
     L.Crow = L.Crow - 1;
     L.Ccol = L.Ccol + 1;
     L.Drow = L.Drow - 2;
    end;
 end
 if L.Dir == West then
   if   (Board[L.Arow+1][L.Acol+1] == BTNone)
    and (Board[L.Crow-1][L.Ccol-1] == BTNone)
    and (Board[L.Drow][L.Dcol-2] == BTNone) then

     temp = South;
     L.Arow = L.Arow + 1;
     L.Acol = L.Acol + 1;
     L.Crow = L.Crow - 1;
     L.Ccol = L.Ccol - 1;
     L.Dcol = L.Dcol - 2;
    end;
 end

 if L.Dir == South then
   if (L.Acol < 10)
    and (Board[L.Arow-1][L.Acol+1] == BTNone)
    and (Board[L.Crow+1][L.Ccol-1] == BTNone)
    and (Board[L.Drow+2][L.Dcol] == BTNone) then

     temp = East;
     L.Arow = L.Arow - 1;
     L.Acol = L.Acol + 1;
     L.Crow = L.Crow + 1;
     L.Ccol = L.Ccol - 1;
     L.Drow = L.Drow + 2;
    end;
 end
 if L.Dir == East then
   if   (Board[L.Arow-1][L.Acol-1] == BTNone)
    and (Board[L.Crow+1][L.Ccol+1] == BTNone)
    and (Board[L.Drow][L.Dcol+2] == BTNone) then

     temp = North;
     L.Arow = L.Arow - 1;
     L.Acol = L.Acol - 1;
     L.Crow = L.Crow + 1;
     L.Ccol = L.Ccol + 1;
     L.Dcol = L.Dcol + 2;
    end;
 end

  L.Dir = temp;
  L.Draw();
 end;

 L.GetHighLow = function(high,low)

 high = 20;
 low = 1;

 if L.Dir == North then
       high = L.Crow;
       low  = L.Arow;
      end;
 if L.Dir == East then
       high = L.Drow;
       low  = L.Arow;
      end;
 if L.Dir == South then
       high = L.Arow;
       low  = L.Crow;
      end;
 if L.Dir == West then
       high = L.Arow;
       low  = L.Drow;
      end;
 end;

 L.DrawClear = function()
  Tetra_Draw(L.Arow,L.Acol,BTNone);
  Tetra_Draw(L.Brow,L.Bcol,BTNone);
  Tetra_Draw(L.Crow,L.Ccol,BTNone);
  Tetra_Draw(L.Drow,L.Dcol,BTNone);
 end;

 L.Draw = function()

  Tetra_Draw(L.Arow,L.Acol,L.BT);
  Tetra_Draw(L.Brow,L.Bcol,L.BT);
  Tetra_Draw(L.Crow,L.Ccol,L.BT);
  Tetra_Draw(L.Drow,L.Dcol,L.BT);
 end;

 L.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreL");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreL");
  end 
 end;

 L.Convert = function()

  Board[L.Arow][L.Acol] = BTL;
  Board[L.Brow][L.Bcol] = BTL;
  Board[L.Crow][L.Ccol] = BTL;
  Board[L.Drow][L.Dcol] = BTL;
 end;

 L.Lose = function()
  result = true;
   if (Board[L.Arow][L.Acol] == BTNone) and
      (Board[L.Brow][L.Bcol] == BTNone) and
      (Board[L.Crow][L.Ccol] == BTNone) and
      (Board[L.Drow][L.Dcol] == BTNone) then

      result = false
   end
  return result;
 end;