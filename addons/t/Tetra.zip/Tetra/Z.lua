Z = {}

 Z.Create = function()
  Z.Dir = North;
  Z.Arow = 1;
  Z.Acol = 5;
  Z.Brow = 1;
  Z.Bcol = 6;
  Z.Crow = 2;
  Z.Ccol = 6;
  Z.Drow = 2;
  Z.Dcol = 7;
  Z.InPlay = false;
  Z.Dir =  North;
  Z.BT = BTZ;
 end;

 Z.Throw = function()
  Z.InPlay = true;
 end

 Z.Down = function()

 Check = false;

 if Z.Dir == North then
     if Z.Drow < 20 then
       if   (Board[Z.Crow+1][Z.Ccol] == BTNone)
        and (Board[Z.Drow+1][Z.Dcol] == BTNone)
        and (Board[Z.Arow+1][Z.Acol] == BTNone)
         then  Check = true;
       end
     end
 end

 if Z.Dir == West then
     if Z.Arow < 20 then
       if   (Board[Z.Crow+1][Z.Ccol] == BTNone)
        and (Board[Z.Arow+1][Z.Acol] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           Z.DrawClear();
            Z.Arow = Z.Arow + 1;
            Z.Brow = Z.Brow + 1;
            Z.Crow = Z.Crow + 1;
            Z.Drow = Z.Drow + 1;
           Z.Draw();
  end

  return Check;
 end;

 Z.Right = function()

 Check = false;

 if Z.Dir == North then
     if Z.Dcol < 10 then
       if   (Board[Z.Brow][Z.Bcol+1] == BTNone)
        and (Board[Z.Drow][Z.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end

 if Z.Dir == West then
     if Z.Ccol < 10 then
       if   (Board[Z.Crow][Z.Ccol+1] == BTNone)
        and (Board[Z.Drow][Z.Dcol+1] == BTNone)
        and (Board[Z.Arow][Z.Acol+1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           Z.DrawClear();
            Z.Acol = Z.Acol + 1;
            Z.Bcol = Z.Bcol + 1;
            Z.Ccol = Z.Ccol + 1;
            Z.Dcol = Z.Dcol + 1;
           Z.Draw();
  end;
 end;

 Z.Left = function()

 Check = false;

 if Z.Dir == North then
     if Z.Acol > 1 then
       if   (Board[Z.Arow][Z.Acol-1] == BTNone)
        and (Board[Z.Crow][Z.Ccol-1] == BTNone)
         then  Check = true;
       end
     end
 end

 if Z.Dir == West then
     if Z.Acol > 1 then
       if   (Board[Z.Arow][Z.Acol-1] == BTNone)
        and (Board[Z.Brow][Z.Bcol-1] == BTNone)
        and (Board[Z.Drow][Z.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           Z.DrawClear();
            Z.Acol = Z.Acol - 1;
            Z.Bcol = Z.Bcol - 1;
            Z.Ccol = Z.Ccol - 1;
            Z.Dcol = Z.Dcol - 1;
           Z.Draw();
  end
 end;

 Z.RotateClock = function()

  Z.RotateCounter();
 end;

 Z.RotateCounter = function()

  temp = Z.Dir;
  Z.DrawClear();

 if Z.Dir == North then
   if (Z.Brow > 1)
    and (Board[Z.Arow+1][Z.Acol] == BTNone)
    and (Board[Z.Drow-2][Z.Dcol-1] == BTNone)  then

     temp = West;
     Z.Arow = Z.Arow + 1;
     Z.Bcol = Z.Bcol - 1;
     Z.Crow = Z.Crow - 1;
     Z.Dcol = Z.Dcol - 1;
     Z.Drow = Z.Drow - 2;
   end
 end

 if Z.Dir == West then
   if (Z.Ccol < 10)
    and (Board[Z.Crow+1][Z.Ccol] == BTNone)
    and (Board[Z.Drow+2][Z.Dcol+1] == BTNone) then

     temp = North;
     Z.Arow = Z.Arow - 1;
     Z.Bcol = Z.Bcol + 1;
     Z.Crow = Z.Crow + 1;
     Z.Dcol = Z.Dcol + 1;
     Z.Drow = Z.Drow + 2;
   end
 end

  Z.Dir = temp;
  Z.Draw();
 end;

 Z.GetHighLow = function(high,low)

 high = 20;
 low = 1;

 if Z.Dir == North then
       high = Z.Crow;
       low  = Z.Arow;
      end;
 if Z.Dir == West then
       high = Z.Arow;
       low  = Z.Drow;
      end;

 end;

 Z.DrawClear = function()
  Tetra_Draw(Z.Arow,Z.Acol,BTNone);
  Tetra_Draw(Z.Brow,Z.Bcol,BTNone);
  Tetra_Draw(Z.Crow,Z.Ccol,BTNone);
  Tetra_Draw(Z.Drow,Z.Dcol,BTNone);
 end;

 Z.Draw = function()
  Tetra_Draw(Z.Arow,Z.Acol,Z.BT);
  Tetra_Draw(Z.Brow,Z.Bcol,Z.BT);
  Tetra_Draw(Z.Crow,Z.Ccol,Z.BT);
  Tetra_Draw(Z.Drow,Z.Dcol,Z.BT);
 end;

 Z.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreZ");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreZ");
  end 
 end;

 Z.Convert = function()

  Board[Z.Arow][Z.Acol] = BTZ;
  Board[Z.Brow][Z.Bcol] = BTZ;
  Board[Z.Crow][Z.Ccol] = BTZ;
  Board[Z.Drow][Z.Dcol] = BTZ;

 end;

 Z.Lose = function()
  result = true;
   if (Board[Z.Arow][Z.Acol] == BTNone) and
      (Board[Z.Brow][Z.Bcol] == BTNone) and
      (Board[Z.Crow][Z.Ccol] == BTNone) and
      (Board[Z.Drow][Z.Dcol] == BTNone) then

      result = false
   end
  return result;
 end;