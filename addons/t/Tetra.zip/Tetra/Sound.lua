-------------------------------------------------------------------------------
--SOUND ENGINE
-------------------------------------------------------------------------------

Sound = {}

Sound.Create = function()
  Sound.Mute = false;
 end

Sound.LineClear = function(linecount)
  if Sound.Mute == false then
   if linecount > 3 then
     PlaySoundFile("Sound\\Spells\\AchievmentSound1.wav");
    else
       PlaySoundFile("Sound\\Interface\\LevelUp.wav");
   end
  end
 end

Sound.PlayMusic = function(level)

 end

Sound.MuteSound = function()
  if Sound.Mute == true then
        Sound.Mute = false;
     else
        Sound.Mute = true;
  end
 end



