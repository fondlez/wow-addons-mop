S = {}

 S.Create = function()

  S.Dir = North;
  S.Arow = 1;
  S.Acol = 5;
  S.Brow = 1;
  S.Bcol = 6;
  S.Crow = 2;
  S.Ccol = 4;
  S.Drow = 2;
  S.Dcol = 5;
  S.InPlay = false;
  S.Dir =  North;
  S.BT = BTS;
 end;

 S.Throw = function()
  S.InPlay = true;
 end

 S.Down = function()

 Check = false;

 if S.Dir == North then
     if S.Drow < 20 then
       if   (Board[S.Crow+1][S.Ccol] == BTNone)
        and (Board[S.Drow+1][S.Dcol] == BTNone)
        and (Board[S.Brow+1][S.Bcol] == BTNone)
         then  Check = true;
       end
     end
 end

 if S.Dir == West then
     if S.Crow < 20 then
       if   (Board[S.Crow+1][S.Ccol] == BTNone)
        and (Board[S.Arow+1][S.Acol] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           S.DrawClear();
            S.Arow = S.Arow + 1;
            S.Brow = S.Brow + 1;
            S.Crow = S.Crow + 1;
            S.Drow = S.Drow + 1;
           S.Draw();
  end

  return Check;
 end;

 S.Right = function()

 Check = false;

 if S.Dir == North then
     if S.Bcol < 10 then
       if   (Board[S.Brow][S.Bcol+1] == BTNone)
        and (Board[S.Drow][S.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end

 if S.Dir == West then
     if S.Ccol < 10 then
       if   (Board[S.Crow][S.Ccol+1] == BTNone)
        and (Board[S.Brow][S.Bcol+1] == BTNone)
        and (Board[S.Arow][S.Acol+1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           S.DrawClear();
            S.Acol = S.Acol + 1;
            S.Bcol = S.Bcol + 1;
            S.Ccol = S.Ccol + 1;
            S.Dcol = S.Dcol + 1;
           S.Draw();
  end

 end;

 S.Left = function()

 Check = false;

 if S.Dir == North then
     if S.Ccol > 1 then
       if   (Board[S.Arow][S.Acol-1] == BTNone)
        and (Board[S.Crow][S.Ccol-1] == BTNone)
         then  Check = true;
       end
     end
 end

 if S.Dir == West then
     if S.Acol > 1 then
       if   (Board[S.Arow][S.Acol-1] == BTNone)
        and (Board[S.Brow][S.Bcol-1] == BTNone)
        and (Board[S.Crow][S.Ccol-1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           S.DrawClear();
            S.Acol = S.Acol - 1;
            S.Bcol = S.Bcol - 1;
            S.Ccol = S.Ccol - 1;
            S.Dcol = S.Dcol - 1;
           S.Draw();
  end
 end;

 S.RotateClock = function()

  S.RotateCounter();
 end;

 S.RotateCounter = function()

  temp = S.Dir;
  S.DrawClear();

 if S.Dir == North then
   if (S.Brow > 1)
    and (Board[S.Arow][S.Acol-1] == BTNone)
    and (Board[S.Brow-1][S.Bcol-2] == BTNone)  then

     temp = West;
     S.Acol = S.Acol - 1;
     S.Bcol = S.Bcol - 2;
     S.Brow = S.Brow - 1;
     S.Ccol = S.Ccol + 1;
     S.Drow = S.Drow - 1;
   end
 end

 if S.Dir == West then
   if (S.Ccol < 10)
    and (Board[S.Crow][S.Ccol-1] == BTNone)
    and (Board[S.Brow+1][S.Bcol+2] == BTNone) then

     temp = North;
     S.Acol = S.Acol + 1;
     S.Bcol = S.Bcol + 2;
     S.Brow = S.Brow + 1;
     S.Ccol = S.Ccol - 1;
     S.Drow = S.Drow + 1;
   end
 end

  S.Dir = temp;
  S.Draw();
 end;

 S.GetHighLow = function(high,low)

 high = 20;
 low = 1;

 if S.Dir == North then
       high = S.Crow;
       low  = S.Arow;
      end;
 if S.Dir == West then
       high = S.Crow;
       low  = S.Brow;
      end;

 end;

 S.DrawClear = function()

  Tetra_Draw(S.Arow,S.Acol,BTNone);
  Tetra_Draw(S.Brow,S.Bcol,BTNone);
  Tetra_Draw(S.Crow,S.Ccol,BTNone);
  Tetra_Draw(S.Drow,S.Dcol,BTNone);
 end;

 S.Draw = function()
  Tetra_Draw(S.Arow,S.Acol,S.BT);
  Tetra_Draw(S.Brow,S.Bcol,S.BT);
  Tetra_Draw(S.Crow,S.Ccol,S.BT);
  Tetra_Draw(S.Drow,S.Dcol,S.BT);
 end;

 S.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreS");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreS");
  end 
 end;

 S.Convert = function()

  Board[S.Arow][S.Acol] = BTS;
  Board[S.Brow][S.Bcol] = BTS;
  Board[S.Crow][S.Ccol] = BTS;
  Board[S.Drow][S.Dcol] = BTS;

 end;

 S.Lose = function()
  result = true;
   if (Board[S.Arow][S.Acol] == BTNone) and
      (Board[S.Brow][S.Bcol] == BTNone) and
      (Board[S.Crow][S.Ccol] == BTNone) and
      (Board[S.Drow][S.Dcol] == BTNone) then

      result = false
   end
  return result;
 end;
