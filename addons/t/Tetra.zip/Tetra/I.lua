I = {}

 I.Create = function()

  I.Dir = North;
  I.Arow = 1;
  I.Acol = 4;
  I.Brow = 1;
  I.Bcol = 5;
  I.Crow = 1;
  I.Ccol = 6;
  I.Drow = 1;
  I.Dcol = 7;
  I.InPlay = false;
  I.Dir =  North;
  I.BT = BTI;
 end;

 I.Throw = function()
  I.InPlay = true;
 end

 I.Down = function()

 Check = false;

 if I.Dir == North then
     if I.Drow < 20 then
       if   (Board[I.Crow+1][I.Ccol] == BTNone)
        and (Board[I.Drow+1][I.Dcol] == BTNone)
        and (Board[I.Brow+1][I.Bcol] == BTNone)
        and (Board[I.Arow+1][I.Acol] == BTNone)
         then  Check = true;
       end
     end
 end

 if I.Dir == West then
     if I.Drow < 20 then
       if   (Board[I.Drow+1][I.Dcol] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           I.DrawClear();
            I.Arow = I.Arow + 1;
            I.Brow = I.Brow + 1;
            I.Crow = I.Crow + 1;
            I.Drow = I.Drow + 1;
           I.Draw();
          end;

  return Check;
 end;

 I.Right = function()

 Check = false;

 if I.Dir == North then
     if I.Dcol < 10 then
       if   (Board[I.Drow][I.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end

 if I.Dir == West then
     if I.Dcol < 10 then
       if   (Board[I.Crow][I.Ccol+1] == BTNone)
        and (Board[I.Brow][I.Bcol+1] == BTNone)
        and (Board[I.Arow][I.Acol+1] == BTNone)
        and (Board[I.Drow][I.Dcol+1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           I.DrawClear();
            I.Acol = I.Acol + 1;
            I.Bcol = I.Bcol + 1;
            I.Ccol = I.Ccol + 1;
            I.Dcol = I.Dcol + 1;
           I.Draw();
          end;
 end;

 I.Left = function()

 Check = false;

 if I.Dir == North then
     if I.Acol > 1 then
       if   (Board[I.Arow][I.Acol-1] == BTNone)
         then  Check = true;
       end
     end
 end

 if I.Dir == West then
     if I.Acol > 1 then
       if   (Board[I.Arow][I.Acol-1] == BTNone)
        and (Board[I.Brow][I.Bcol-1] == BTNone)
        and (Board[I.Crow][I.Ccol-1] == BTNone)
        and (Board[I.Drow][I.Dcol-1] == BTNone)
         then  Check = true;
       end
     end
 end

  if Check == true then

           I.DrawClear();
            I.Acol = I.Acol - 1;
            I.Bcol = I.Bcol - 1;
            I.Ccol = I.Ccol - 1;
            I.Dcol = I.Dcol - 1;
           I.Draw();
          end;
 end;

 I.RotateClock = function()

  I.RotateCounter();
 end;

 I.RotateCounter = function()

  temp = I.Dir;
  I.DrawClear();
 if I.Dir == North then
   if (I.Arow > 1) and (I.Arow < 20 - 1)
    and (Board[I.Arow-1][I.Acol+1] == BTNone)
    and (Board[I.Crow+1][I.Ccol-1] == BTNone)
    and (Board[I.Drow+2][I.Dcol-2] == BTNone)  then

     temp = West;
     I.Acol = I.Acol + 1;
     I.Arow = I.Arow - 1;
     I.Ccol = I.Ccol - 1;
     I.Crow = I.Crow + 1;
     I.Dcol = I.Dcol - 2;
     I.Drow = I.Drow + 2;
   end
 end

 if I.Dir == West then
   if (I.Bcol < 10 - 1) and (I.Acol > 1)
    and (Board[I.Arow+1][I.Acol-1] == BTNone)
    and (Board[I.Crow-1][I.Ccol+1] == BTNone)
    and (Board[I.Drow-2][I.Dcol+2] == BTNone) then

     temp = North;
     I.Acol = I.Acol - 1;
     I.Arow = I.Arow + 1;
     I.Ccol = I.Ccol + 1;
     I.Crow = I.Crow - 1;
     I.Dcol = I.Dcol + 2;
     I.Drow = I.Drow - 2;
   end
 end

  I.Dir = temp;
  I.Draw();
 end;

 I.GetHighLow = function(high,low)

 high = 20;
 low = 1;
 if I.Dir == North then
       high = I.Arow;
       low  = I.Arow;
      end;
 if I.Dir == West then
       high = I.Drow;
       low  = I.Arow;
      end;
 end;

 I.DrawClear = function()
  Tetra_Draw(I.Arow,I.Acol,BTNone);
  Tetra_Draw(I.Brow,I.Bcol,BTNone);
  Tetra_Draw(I.Crow,I.Ccol,BTNone);
  Tetra_Draw(I.Drow,I.Dcol,BTNone);
 end;

 I.Draw = function()
  Tetra_Draw(I.Arow,I.Acol,I.BT);
  Tetra_Draw(I.Brow,I.Bcol,I.BT);
  Tetra_Draw(I.Crow,I.Ccol,I.BT);
  Tetra_Draw(I.Drow,I.Dcol,I.BT);
 end;

 I.PreviewDraw = function(x)
  if (x == 1) then --Next Block
   PreviewBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreI");
  else
   HoldPreBlock.Frame:SetTexture("interface\\addons\\Tetra\\Images\\PreI");
  end 
 end;

 I.Convert = function()

  Board[I.Arow][I.Acol] = BTI;
  Board[I.Brow][I.Bcol] = BTI;
  Board[I.Crow][I.Ccol] = BTI;
  Board[I.Drow][I.Dcol] = BTI;

 end;

 I.Lose = function()
  result = true;
   if (Board[I.Arow][I.Acol] == BTNone) and
      (Board[I.Brow][I.Bcol] == BTNone) and
      (Board[I.Crow][I.Ccol] == BTNone) and
      (Board[I.Drow][I.Dcol] == BTNone) then

      result = false
   end
  return result;
 end;
