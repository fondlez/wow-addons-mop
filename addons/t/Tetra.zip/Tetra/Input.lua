 --INPUT

function Tetra_PerformAction()

 if Paused == false then
  if ( Control == "Right") then
    Block.Right();
  end

  if ( Control == "Left") then
    Block.Left();
  end

  if ( Control == "Up") then
    Block.RotateClock();
  end

  if ( Control == "Down") then
    Block.Down();
  end

  if ( Control == "E" ) then
    Block.RotateCounter();
  end
 end

end

 function Tetra_ReceiveInputtwo(key)
  Control = "";
 end

 function Tetra_ReceiveInput(key)
 if Paused == false then
  if ( key == "RIGHT") then
    Control = "Right";
    Block.Right();
    TimeSinceLastUpdate = -0.1;
  end

  if ( key == "LEFT") then
    Control = "Left";
    Block.Left();
    TimeSinceLastUpdate = -0.1;
  end

  if ( key == "UP") then
    Control = "Up";
    Block.RotateClock();
    TimeSinceLastUpdate = -0.1;
  end

  if ( key == "DOWN") then
    Control = "Down";
    Block.Down();
    TimeSinceLastUpdate = -0.1;
  end

  if ( key == "E" ) then
    Control = "E";
    Block.RotateCounter();
    TimeSinceLastUpdate = -0.1;
  end

  if (key == "0") or (key == "Z") then
    Tetra_HardDrop();
   end

  if ( key == "`") or (key == ".") then
    Tetra_SwitchHoldNext();
  end

 end
  if ( key == "ESCAPE" ) or ( key == "R") or ( key == "W") or ( key == "SPACE")or ( key == "ENTER")  or ( key == "/") then
    Tetra_HideGUI();
  end

 end
