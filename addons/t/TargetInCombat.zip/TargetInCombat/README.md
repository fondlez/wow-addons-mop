TargetInCombat
====================

Small World of Warcraft addon. Displays combat status indicators on target and focus frames.

http://wow.curseforge.com/addons/targetincombat/
https://github.com/aaronlord/wow-target-in-combat