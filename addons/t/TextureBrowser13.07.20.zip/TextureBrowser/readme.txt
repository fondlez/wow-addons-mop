Texture Browser
---------------
This is a developer tool which allows you to browse all textures within WoW's interface.

You can shift click on a texture entry to paste the path into the chat box, and then copy it from there to insert into your code.

To open, use slash command "/tb" or "/texturebrowser".

Icon Count
----------
As of patch 4.0.1a, a total of 6233 icons can be viewed using this tool.
As of patch 4.0.3a, a total of 7949 icons can be viewed using this tool.