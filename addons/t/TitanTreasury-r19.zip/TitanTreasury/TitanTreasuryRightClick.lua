-- **************************************************************************
-- * TitanTreasuryRightClick.lua
-- *
-- * By: KanadiaN (Lindarena@Laughing Skull)
-- *
-- **************************************************************************

local L = LibStub( "AceLocale-3.0" ):GetLocale( "Titan", true );
local LB = LibStub( "AceLocale-3.0" ):GetLocale( "TitanTreasury", true );

-- **************************************************************************
-- NAME : TitanPanelRightClickMenu_PrepareTreasuryMenu()
-- DESC : Builds Right Click Interactive Menu
-- **************************************************************************
function TitanPanelRightClickMenu_PrepareTreasuryMenu()
     local cRealm = TitanTreasury_ColorUtils( "GetCFaction", TitanTreasuryProfile.Faction, TitanTreasuryProfile.Realm );
     local cDelete = TitanTreasury_ColorUtils( "GetCText", "RED", LB["TITAN_TREASURY_MENU_DELETE"] );
     local devUser = ( "%s@%s" ):format( TitanTreasuryProfile.Player, TitanTreasuryProfile.Realm )
     local author = TitanTreasury_CoreUtils( "Author", devUser );
     if ( UIDROPDOWNMENU_MENU_LEVEL == 2 ) then 
          if ( UIDROPDOWNMENU_MENU_VALUE == cRealm ) then
               -- Toon Data Delete
               info = {};
               info.notCheckable = true;
               info.text = cDelete;
               info.hasArrow = 1;
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
               -- Toon Tooltip Hide
               info = {};
               info.notCheckable = true;
               info.text = LB["TITAN_TREASURY_MENU_HIDETOON"];
               info.hasArrow = 1;
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
          end
          if ( UIDROPDOWNMENU_MENU_VALUE == "Debugging" ) then
               info = {};
               info.checked = TitanTreasuryDebug.State;
               info.text = "State";
               info.value = "State";
               info.func = function() TitanTreasury_DebugUtils( "Toggle", "State" ); return; end
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
               if ( author and TitanTreasuryDebug.State ) then
                    info = {};
                    info.notCheckable = true;
                    info.text = "Tooltip";
                    info.value = "Tooltip";
                    info.func = function() TitanPanelTreasuryButton_GetTooltipText(); end
                    UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
                    info = {};
                    info.notCheckable = true;
                    info.text = "Logging";
                    info.hasArrow = true;
                    UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
               end
          end
          return;
     end
     if ( UIDROPDOWNMENU_MENU_LEVEL == 3 ) then
	  if ( UIDROPDOWNMENU_MENU_VALUE == cDelete ) then
               -- Delete Toon Data
               local dTable = TitanTreasuryCharacters[ TitanTreasuryProfile.Realm ];
               table.foreach( dTable, function( Key, Data )
                         if ( Key ~= UnitName( "player" ) ) then
                              info = {};
                              info.notCheckable = true;
                              info.text = TitanTreasury_ColorUtils( "GetCClass", Data.Class, Key );
                              info.func = function()
                                   TitanTreasuryCharacters[ TitanTreasuryProfile.Faction ][ TitanTreasuryProfile.Realm ][ Key ] = nil;
                              end;
                              UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
                         end
                    end
               );
               TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
               -- Clears All Data
               info = {};
               info.notCheckable = true;
               info.text = LB["TITAN_TREASURY_MENU_CLEARALL"];
               info.func = function()
                    TitanTreasuryCharacters[ TitanTreasuryProfile.Realm ] = {};
               end;
               info.value = LB["TITAN_TREASURY_MENU_CLEARALL"];
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
          end
          -- Hide Toon From Tooltip
          if ( UIDROPDOWNMENU_MENU_VALUE == LB["TITAN_TREASURY_MENU_HIDETOON"] ) then
               local dTable = TitanTreasuryCharacters[ TitanTreasuryProfile.Realm ];
               local tHide = 0;
               table.foreach( dTable, function( Key, Data )
                         if ( Key ~= UnitName( "player" ) ) then
                              info = {};
                              info.notCheckable = true;
                              info.text = TitanTreasury_ColorUtils( "GetCClass", Data.Class, Key );
                              info.func = function()
                                   TitanTreasuryCharacters[ TitanTreasuryProfile.Realm ][ TitanTreasuryProfile.Player ].Hide = not Data.Hide;
                                   TitanPanelButton_UpdateButton( LB["TITAN_TREASURY_CORE_ID"] );
                              end;
                              -- info.checked = Data.Hide;
                              UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
                              if ( Data.Hide ) then tHide = tHide + 1; end
                         end
                    end
               );
               -- Show All Toons
               if ( tHide > 0 ) then
                    TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
                    info = {};
                    info.notCheckable = true;
                    info.text = LB["TITAN_TREASURY_MENU_SHOWALL"];
                    info.value = LB["TITAN_TREASURY_MENU_SHOWALL"];
                    info.func = function()
                         local dTable = TitanTreasuryCharacters[ TitanTreasuryProfile.Faction ][ TitanTreasuryProfile.Realm ];
                         table.foreach( dTable, function( Key, Data )
                                   if ( Data.Hide ) then
                                        TitanTreasuryCharacters[ TitanTreasuryProfile.Faction ][ TitanTreasuryProfile.Realm ][ Key ].Hide = not Data.Hide;
                                   end;
                              end
                         );
                         TitanPanelButton_UpdateButton( LB["TITAN_TREASURY_CORE_ID"] );
                    end;
                    UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
               end
          end
          if ( UIDROPDOWNMENU_MENU_VALUE == "Logging" ) then
               info = {};
               info.checked = TitanTreasuryDebug.LogEvent;
               info.text = "Log Events";
               info.value = "Log Evets";
               info.func = function() TitanTreasury_DebugUtils( "Toggle", "LogEvent" ); end
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
               TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
               info = {};
               info.notCheckable = true;
               info.text = "Clear Event Log";
               info.value = "Clear Event Log";
               info.func = function() TitanTreasuryDebug.Log = {}; end
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
               info = {};
               info.notCheckable = true;
               info.text = "Play Event Log";
               info.value = "Playe Event Log";
               info.func = function() TitanTreasury_ArrayUtils( "playData", TitanTreasuryDebug.Log, true ); end
               UIDropDownMenu_AddButton( info, UIDROPDOWNMENU_MENU_LEVEL );
          end
	  return;
     end
     -- Tooltip Menu Title
     TitanPanelRightClickMenu_AddTitle( TitanPlugins[ LB["TITAN_TREASURY_CORE_ID"] ].menuText );
     -- Realm Menu
     info = {};
     info.notCheckable = true;
     info.text = cRealm;
     info.hasArrow = 1;
     UIDropDownMenu_AddButton( info );
     TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
     -- Settings MEnu
     info = {};
     info.notCheckable = true;
     info.text = LB["TITAN_TREASURY_MENU_SETTINGS"];
     info.value = LB["TITAN_TREASURY_MENU_SETTINGS"];
     info.func = function() TitanTreasury_InitGUI(); end
     UIDropDownMenu_AddButton( info );
     TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
     if ( author ) then
          info = {};
          info.notCheckable = true;
          info.hasArrow = true;
          info.text = "Debugging";
          UIDropDownMenu_AddButton( info );
          TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
     end
     -- Standard Menu
     TitanPanelRightClickMenu_AddToggleIcon( LB["TITAN_TREASURY_CORE_ID"] );
     TitanPanelRightClickMenu_AddToggleLabelText( LB["TITAN_TREASURY_CORE_ID"] );
     TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
     TitanPanelRightClickMenu_AddCommand( LB["TITAN_TREASURY_MENU_HIDE"], LB["TITAN_TREASURY_CORE_ID"], TITAN_PANEL_MENU_FUNC_HIDE );
     -- Custom Menu
     TitanPanelRightClickMenu_AddSpacer( UIDROPDOWNMENU_MENU_LEVEL );
     TitanPanelRightClickMenu_AddCommand( LB["TITAN_TREASURY_MENU_CLOSE"], LB["TITAN_TREASURY_CORE_ID"], function() return; end );
end