﻿--[[ TinyTip by Thrae
-- 
--
-- French Localization
-- For TinyTipChat
--
-- Any wrong words, change them here.
--
-- Note: Other localization is in TinyTipLocale_frFR.
-- 
-- Contributors:
--]]

TinyTipChatLocale = GetLocale()

if TinyTipChatLocale == "frFR" then
	-- NEED TRANSLATION
end
