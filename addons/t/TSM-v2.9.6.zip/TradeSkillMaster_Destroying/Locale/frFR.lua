-- ------------------------------------------------------------------------------ --
--                           TradeSkillMaster_Destroying                          --
--           http://www.curse.com/addons/wow/tradeskillmaster_destroying          --
--                                                                                --
--             A TradeSkillMaster Addon (http://tradeskillmaster.com)             --
--    All Rights Reserved* - Detailed license information included with addon.    --
-- ------------------------------------------------------------------------------ --

-- TradeSkillMaster_Destroying Locale - frFR
-- Please use the localization app on CurseForge to update this
-- http://wow.curseforge.com/addons/tradeskillmaster_destroying/localization/

local L = LibStub("AceLocale-3.0"):NewLocale("TradeSkillMaster_Destroying", "frFR")
if not L then return end

-- L["Days of Log Data"] = ""
-- L["Destroyed Item"] = ""
-- L["Destroying Log"] = ""
-- L["Destroying not list any items above this quality for disenchnting."] = ""
-- L["Destroy Next"] = ""
-- L["Disenchanting Options"] = ""
-- L["Enable Automatic Stack Combination"] = ""
-- L["General Options"] = ""
-- L["Hiding frame for the remainder of this session. Typing '/tsm destroy' will open the frame again."] = ""
-- L["_ Hr _ Min ago"] = ""
-- L["If checked, partial stacks of herbs/ore will automatically be combined."] = ""
-- L["If checked, the Destroying window will automatically be shown when there's items to destroy in your bags. Otherwise, you can open it up by typing '/tsm destroy'."] = ""
-- L["Ignored Item"] = ""
-- L["Ignored Items"] = ""
-- L["Ignoring all %s permanently. You can undo this in the Destroying options."] = ""
-- L["Ignoring all %s this session (until your UI is reloaded)."] = ""
-- L["Item"] = ""
-- L["Maximum Disenchant Quality"] = ""
-- L["Nothing to destroy in your bags."] = ""
-- L["now"] = ""
-- L["Opens the Destroying frame if there's stuff in your bags to be destroyed."] = ""
-- L["Options"] = ""
-- L["Removed %s from the permanent ignore list."] = ""
-- L["Result"] = ""
-- L["Right click on this row to remove this item from the permanent ignore list."] = ""
-- L["Select what format Destroying should use to display times in the Destroying log."] = ""
-- L["Show Destroying Frame Automatically"] = ""
-- L["Spell"] = ""
-- L["%sRight-Click|r to ignore this item for this session. Hold %sshift|r to ignore permanently. You can remove items from permanent ignore in the Destroying options."] = ""
-- L["Stack Size"] = ""
-- L["The destroying log will throw out any data that is older than this many days."] = ""
-- L["Time"] = ""
 
