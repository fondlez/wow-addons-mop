--[[
	Description: Titan plug-in to display professions skill level
	Author: Subwired
--]]

local ProfName = "Mining"
local menutext = "Titan|c0070DE5f "..ProfName.."|r"
local buttonlabel = ProfName..": "
local ID = "MN"
local elap, MN, prevMN = 0, 0.0, -2
local MNmax, preMNmax = 0, 0



-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelMNButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")
f:RegisterForClicks("AnyUp", "AnyDown")


f:SetScript("OnClick", function(self, button, down)
local prof = ProfName
if prof == "Mining" then prof = "Smelting" end
CastSpellByName(prof)
end)

function TitanPanelRightClickMenu_PrepareProfessionsMenu2()

    
end

function f:ADDON_LOADED(a1)

--print ("a1 = " .. a1)
	if a1 ~= "TitanMining" then 
		return 
	end
	
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelMNButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelMNButton_GetTooltipText",
		frequency = 1,
		icon = "Interface\\Icons\\Trade_"..strlower(ProfName)..".blp",
		iconWidth = 16,
		category = "Profession",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end

		--local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions();
		--local name, icon, skillLevel, maxSkillLevel, numAbilities, spelloffset, skillLine, skillModifier = GetProfessionInfo(index)
			
		local prof1, prof2, _, _, _, _ = GetProfessions();
		local name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(prof1)
		if name == ProfName then
			-- do nothign becouse we already have the data
			--print("name " .. name .. " ".. skillLevel .. " /" .. maxSkillLevel)
		else
			-- the first profession did not have it check the 2nd
			name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(prof2)
			if name == ProfName then
				-- do nothign becouse we already have the data 
			else
					-- profession not found
					skillLevel = 0
					maxSkillLevel = 0
			end
		end
	
		MN = skillLevel
		MNmax = maxSkillLevel
		
		if MN == prevMN and MNmax == preMNmax then 
			return 
		end
		
		preMNmax = MNmax
		prevMN  = MN
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end


function TitanPanelMNButton_GetButtonText()

	local MNtext, pitchtext
	if not MN then
		MNtext = "??"
	else
	
		MNtext = MN .."/"..MNmax--string.format("%.0f", MN)  
	end
	return buttonlabel, MNtext
end


function TitanPanelMNButton_GetTooltipText()
TitanPanelRightClickMenu_PrepareProfessionsMenu2()
	return "Displays your current "..ProfName.." Skill level"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareMNMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	

  local info = {}
  local i, name, icon, skillLevel, maxSkillLevel, _, TPProGath  
  local Alchemy = GetSpellInfo(2259)
  local Blacksmithing = GetSpellInfo(2018)
  local Enchanting = GetSpellInfo(7411)
  local Disenchanting = GetSpellInfo(13262)
  local Engineering = GetSpellInfo(4036)
  local Inscription = GetSpellInfo(45357)
  local Milling = GetSpellInfo(51005)
  local Jewelcrafting = GetSpellInfo(25229)
  local Prospecting = GetSpellInfo(31252)
  local Smelting = GetSpellInfo(2656)
  local Mining = GetSpellInfo(2575)
  local Leatherworking = GetSpellInfo(2108)
  local Tailoring = GetSpellInfo(3908)
  local Archaeology = GetSpellInfo(78670)
  local Survey = GetSpellInfo(80451)
  local Cooking = GetSpellInfo(2550)
  local FirstAid = GetSpellInfo(3273)
  local Fishing = GetSpellInfo(7620)
  local Herbalism = GetSpellInfo(2366)
  local Skinning = GetSpellInfo(8613)
  
    TPProGath = "Gathering Skills:"
 
 
  
  
  
	
  

  
      info.text = "Open JC Window"
      info.icon = "Interface\\Icons\\INV_Misc_Gem_02" 
      info.func = function ()CastSpellByName(Jewelcrafting) end
      UIDropDownMenu_AddButton(info, UIDROPDOWNMENU_MENU_LEVEL)    


    
    TitanPanelRightClickMenu_AddSpacer() 
    
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
	
	
  
end

