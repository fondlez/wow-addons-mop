--[[
	TitanHaste: A simple Display of current Haste value as a percent
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Haste|r"
local buttonlabel = "Haste: "
local ID = "HA"
local elap, HA, prevHA = 0, 0.0, -2
local GetUnitHA = 0 
local isMalee = 0;
local isHunter = 0;



-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelHAButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanHaste" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
			

	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelHAButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelHAButton_GetTooltipText",
		frequency = 0.5,
		icon = "Interface\\Icons\\Ability_rogue_slicedice.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		
		checkType()
		if isMalee == 1 then
			if isHunter == 1 then
				--GetCombatRating(19) / 128.125-- range haste
				HA = GetRangedHaste("player")
			else
				--HA = GetCombatRating(18) / 128.125-- malee haste
				HA = GetMeleeHaste("player")
			end			
		else
			HA =UnitSpellHaste("player")
			--HA = GetCombatRating(20) / 128.125 -- spell haste
		end
		
		
		if HA == prevHA then return end
		prevHA  = HA
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end

function checkType()

		--1. Strength
	    --2. Agility
	    --3. Stamina
	    --4. Intellect
	    --5. Spirit 
		local _, strStat = UnitStat("player",1);   
		local _, agiStat = UnitStat("player",2);   
		local _, intStat = UnitStat("player",4);

	if intStat > agiStat and intStat > strStat then 
		isMalee = 0
		--print("is caster  " .. intStat.." "..agiStat.." "..strStat)
	else
		isMalee = 1
		--print("is melee " .. intStat.." "..agiStat.." "..strStat)
	end 
	SpellCounterClass,_  = UnitClass("player");
	if (SpellCounterClass == "Hunter" ) then 
		isHunter = 1 
		--print("is hunter")
	end
	

end


----------------------------------------------
function TitanPanelHAButton_GetButtonText()
----------------------------------------------
	local HAtext, pitchtext
	if not HA then
		HAtext = "??"
	else	
		HAtext = string.format("%.2f", HA) .."%" 
	end
	return buttonlabel, HAtext
end

-----------------------------------------------
function TitanPanelHAButton_GetTooltipText()
-----------------------------------------------
	if isMalee == 1 then
			if isHunter == 1 then
				return "Displays your current range haste value as a percent"
			else
				return "Displays your current malee haste value as a percent"
			end			
		else
			return "Displays your current spell haste value as a percent"
		end

	return "Displays your current Haste value as a percent"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareHAMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end