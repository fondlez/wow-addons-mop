 --[[
	TitanValor: A simple Display of current Valor value as a percent
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Valor Points|r"
local buttonlabel = "Valor: "
local ID = "VP"
local elap, VP, prevVP = 0, 0.0, -2
local GetUnitVP = 0 
local startVal = 0
local inInstance, instanceType 
local runonce = 0
local VPw

-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelVPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanValorPoints" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0


	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelVPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelVPButton_GetTooltipText",
		frequency = 2,
		icon = "Interface\\Icons\\Pvecurrency-valor.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		
		
		
		-- "none" when outside an instance
        -- "pvp" when in a battleground
        -- "arena" when in an arena
        -- "party" when in a 5-man instance
        -- "raid" when in a raid instance 

		for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)
			--if name == "Valor Points" then
			if icon == "Interface\\Icons\\pvecurrency-valor" then
			--print(icon)
				CurrencyIndex = i
			end
			--print(name)
			--Honor Points
			--Conquest Points
			--Valor Points
			--Justice Points
		end
		
		name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(CurrencyIndex)
 
		local inInstance, instanceType = IsInInstance()
		--if inInstance and instanceType == "pvp"  then
	--	if GetNumSubgroupMembers() > 0 then
			if runonce == 0 then
				startVal = count		
				--print("new group")
			runonce = 1
			end
		--else
		--	instanceStarted = 0
		--end

		VP = count
		VPw = currentWeeklyAmount
		if VP == prevVP then return end
		prevVP  = VP
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelVPButton_GetButtonText()
----------------------------------------------
	local VPtext, pitchtext
	if not VP then
		VPtext = "0"
	else	
		if startVal == count or startVal == 0 then
			VPtext = string.format("%.0f", VP) .."" 
		else
			if VP - startVal == 0 then
				VPtext = string.format("%.0f", VP) .."" 
			else
				VPtext = string.format("%.0f", VP) .." (+".. VP - startVal..")"
	end
	return buttonlabel, VPtext
end
	end
	return buttonlabel, VPtext
end

-----------------------------------------------
function TitanPanelVPButton_GetTooltipText()
-----------------------------------------------

return "Total Valor Points:\t"..VP.."/3000\n".."Weekly Valor Points:\t"..VPw.."/1000"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareVPMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end
