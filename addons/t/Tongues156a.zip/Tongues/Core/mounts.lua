Tongues.MountTable = {
	
	["Bear"] = {
		["Language"] = "Bear",
		["Speaktype"] = "growls",
	};
	
	["Saber"] = {
		["Language"] = "Cat",
		["Speaktype"] = "murmurs",
	};
	["Tiger"] = {
		["Language"] = "Cat",
		["Speaktype"] = "murmurs",
	};
	["Dragonhawk"] = {
		["Language"] = "Dragonhawk",
		["Speaktype"] = "calls",
	};
	
	["Felsteed"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "whinnies",
	};
	["Dreadsteed"] = {
		["Language"] = "Demonic",
		["Speaktype"] = "whinnies",
	};
	

	
	["Nether Ray"] = {
		["Language"] = "Nether Ray",
		["Speaktype"] = "hisses",
	};
	["Drake"] = {
		["Language"] = "Draconic",
		["Speaktype"] = "says",
	};
	["Wyrm"] = {
		["Language"] = "Draconic",
		["Speaktype"] = "says",
	};
	
	["Turtle"] = {
		["Language"] = "Turtle",
		["Speaktype"] = "mumbles",
	};

	["Wolf"] = {
		["Language"] = "Wolf",
		["Speaktype"] = "howls",
	};
	
	["Hawkstrider"] = {
	["Language"] = "Bird",
	["Speaktype"] = "Squawks",
	};
	
	["Gryphon"] = {
	["Language"] = "Bird",
	["Speaktype"] = "calls",
	};
	
	["Windrider"] = {
	["Language"] = "Wyvern",
	["Speaktype"] = "growls",
	};
	
	["Horse"] = {
	["Language"] = "Equine",
	["Speaktype"] = "whinnies",
	};
	["Steed"] = {
	["Language"] = "Equine",
	["Speaktype"] = "whinnies",
	};
	["Charger"] = {
	["Language"] = "Equine",
	["Speaktype"] = "whinnies",
	};
	
	
	["Qiraji"] = {
	["Language"] = "Qiraji",
	["Speaktype"] = "hisses",
	};
	
	["Raven Lord"] = {
	["Language"] = "Ravenspeech",
	["Speaktype"] = "caws",
	};
	["Al'ar"] = {
	["Language"] = "Bird",
	["Speaktype"] = "caws",
	};
	["Phoenix"] = {
	["Language"] = "Bird",
	["Speaktype"] = "caws",
	};
	
["Raptor"] = {
	["Language"] = "Raptor",
	["Speaktype"] = "growls",
	};
	
	["Hippogryph"] = {
	["Language"] = "Darnassian",
	["Speaktype"] = "crys",
	};
	
	["Mechanostrider"] = {
	["Language"] = "Binary",
	["Speaktype"] = "Whirrs",
	};
	["Turbostrider"] = {
	["Language"] = "Binary",
	["Speaktype"] = "Whirrs",
	};
	["Battlestrider"] = {
	["Language"] = "Binary",
	["Speaktype"] = "Whirrs",
	};
	
	
	["Kodo"]= {
	["Language"] = "Kodo",
	["Speaktype"] = "grunts",
	};
	["Rhino"]= {
	["Language"] = "Rhino",
	["Speaktype"] = "grunts",
	};

}

