--[[
	Description: Titan plug-in to display professions skill level
	Author: Subwired
--]]

local ProfName = "Archaeology"
local menutext = "Titan|cC79C6E00 "..ProfName.."|r"
local buttonlabel = ProfName..": "
local ID = "AY"
local elap, AY, prevAY = 0, 0.0, -2
local AYmax, prevAYmax = 0, 0



-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelAYButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")

f:SetScript("OnClick", function(self, button, down)
local prof = ProfName
if prof == "Mining" then prof = "Smelting" end
CastSpellByName(prof)
end)

function f:ADDON_LOADED(a1)

--print ("a1 = " .. a1)
	if a1 ~= "TitanArchaeology" then 
		return 
	end
	
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelAYButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelAYButton_GetTooltipText",
		frequency = 1,
		icon = "Interface\\Icons\\Trade_"..strlower(ProfName)..".blp",
		iconWidth = 16,
		category = "Profession",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end

		--local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions();
		--local name, icon, skillLevel, maxSkillLevel, numAbilities, spelloffset, skillLine, skillModifier = GetProfessionInfo(index)
			
		local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions();
		
		if archaeology ~= nil then
			local name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(archaeology)
			AY = skillLevel
			AYmax = maxSkillLevel
			
			if AY == prevAY and prevAYmax == AYmax then 
				return 
			end
			
			prevAYmax = AYmax
			prevAY  = AY
			TitanPanelButton_UpdateButton(ID)
			elap = 0
		end
	end)
		
	--TitanPanelButton_OnLoad(self)
end

----------------------------------------------
function TitanPanelAYButton_GetButtonText()
----------------------------------------------
	local AYtext, pitchtext
	if not AY then
		AYtext = "??"
	else
	
		AYtext = AY .."/"..AYmax--string.format("%.0f", AY)  
	end
	return buttonlabel, AYtext
end

-----------------------------------------------
function TitanPanelAYButton_GetTooltipText()
-----------------------------------------------
	return "Displays your current "..ProfName.." Skill level"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareAYMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end