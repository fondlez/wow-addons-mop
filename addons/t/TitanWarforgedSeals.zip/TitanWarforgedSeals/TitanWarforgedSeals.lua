--[[
	: A simple Display of current amount of Warforged Seals
	Author: Subwired / mod by s1ckn3ss
--]]

local menutext = "Titan|cffff8800 Warforged Seals|r"
local buttonlabel = "Warforged Seals: "
local ID = "WS"
local elapWS, WS, prevWS = 0, 0.0, -2
local GetUnitWS = 0 
local startVal = 0
local inInstance, instanceType
local runonce = 0
local CurrencyIndex


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelWSButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanWarforgedSeals" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0


 --[[
	for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)				
			print(icon)		
			print(name)		
		end
]]--

	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelWSButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelWSButton_GetTooltipText",
		frequency = 2,
		icon = "Interface\\Icons\\inv_arcane_orb.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	
	
	
	
	self:SetScript("OnUpdate", function(this, a1)
		elapWS = elapWS + a1
		if elapWS < 1 then return end
		
		
		
		-- "none" when outside an instance
        -- "pvp" when in a battleground
        -- "arena" when in an arena
        -- "party" when in a 5-man instance
        -- "raid" when in a raid instance 


		for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)
			--if name == "Valor Points" then
			if icon == "Interface\\Icons\\inv_arcane_orb" then
			--print(icon)
				CurrencyIndex = i
			end
			--print(name)
			--Honor Points
			--Conquest Points
			--Valor Points
			--Justice Points
		end

		name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(CurrencyIndex)
 
		
		if runonce == 0 then
			startVal = count
			runonce = 1	
		end
		
		 WS = count
		 --startVal = count
		
		
		if WS == prevWS then return end
		prevWS  = WS
		TitanPanelButton_UpdateButton(ID)
		elapWS = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelWSButton_GetButtonText()
----------------------------------------------
	local WStext, pitchtext
	if not WS then
		WStext = "0"
	else	
		if startVal == count or startVal == 0 then
			WStext = string.format("%.0f", WS) .."" 
		else
			if WS - startVal <= 0 then
				WStext = string.format("%.0f", WS) .."" 
			else
				WStext = string.format("%.0f", WS) .." (+".. WS - startVal..")"
	end
	return buttonlabel, WStext
end
	end
	return buttonlabel, WStext
end

-----------------------------------------------
function TitanPanelWSButton_GetTooltipText()
-----------------------------------------------


	return "Displays your current value "
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareWSMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end