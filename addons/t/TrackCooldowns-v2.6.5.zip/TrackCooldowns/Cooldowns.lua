assert(TrackCooldowns, "TrackCooldowns not found!") 

local hero = (UnitFactionGroup("player") == "Alliance") and 32182 or 2825
local cooldowns = {

    ["DEATHKNIGHT"] = { 
        [GetSpellInfo(48707)] = { id = 48707, cd = 45 },			-- Anti-magic Shell
        [GetSpellInfo(49222)] = { id = 49222, cd = 60 },			-- Bone Shield  
        [GetSpellInfo(48792)] = { id = 48792, cd = 180 },			-- Icebound Fortitude 
        [GetSpellInfo(55233)] = { id = 55233, cd = 60 },			-- Vampiric Blood
        [GetSpellInfo(48982)] = { id = 48982, cd = 30 },			-- Rune Tap
        [GetSpellInfo(61999)] = { id = 61999, cd = 600 },			-- Raise Ally
        [GetSpellInfo(56222)] = { id = 56222, cd = 8 },				-- Dark Command
		[GetSpellInfo(49576)] = { id = 49576, cd = 25 },			-- Death Grip
		[GetSpellInfo(47528)] = { id = 47528, cd = 15, glyph = 58686, altCD = 14 },			-- Mind Freeze
		[GetSpellInfo(47476)] = { id = 47476, cd = 60 },			-- Strangulate
		[GetSpellInfo(108199)] = { id = 108199, cd = 60 },			-- Gorefiend's Grasp
		[GetSpellInfo(108200)] = { id = 108200, cd = 60 },			-- Remoreless Winter
		[GetSpellInfo(108201)] = { id = 108201, cd = 120 },			-- Desecrated Ground
		[GetSpellInfo(48743)] = { id = 48743, cd = 120 },			-- Death Pact
		[GetSpellInfo(51052)] = { id = 51052, cd = 120 },			-- Anti-Magic Zone
		[GetSpellInfo(115989)] = { id = 115989, cd = 90 },			-- Unholy Blight
		[GetSpellInfo(49039)] = { id = 49039, cd = 120 },			-- Lichborne
		[GetSpellInfo(108194)] = { id = 108194, cd = 30 },			-- Asphyxiate
		[GetSpellInfo(96268)] = { id = 96268, cd = 30 },			-- Death's Advance
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["DRUID"] = { 
        [GetSpellInfo(22812)] = { id = 22812, cd = 60 },			-- Barkskin
        [GetSpellInfo(29166)] = { id = 29166, cd = 180 },			-- Innervate  
        [GetSpellInfo(20484)] = { id = 20484, cd = 600, ora = 1 },	-- Rebirth 
        [GetSpellInfo(740)]   = { id =   740, cd = 480, spec = 105, altCD = 180 },			-- Tranquility
		[GetSpellInfo(132469)] = { id = 132469, cd = 30 },			-- Typhoon
		[GetSpellInfo(6795)]  = { id =  6795, cd = 8 },				-- Growl
		[GetSpellInfo(106839)] = { id = 106839, cd = 15, glyph = 116216, altCD = 20 },			-- Skull Bash
		[GetSpellInfo(78675)] = { id = 78675, cd = 60 },			-- Solar Beam
		[GetSpellInfo(102342)] = { id = 102342, cd = 120, spec = 105, altCD = 60 },			-- Ironbark 
		[GetSpellInfo(117679)] = { id = 117679, cd = 180 },			-- Incarnation
		[GetSpellInfo(33891)] = { id = 33891, cd = 180 },			-- Incarnation: Tree of Life
		[GetSpellInfo(102560)] = { id = 102560, cd = 180 },			-- Incarnation: Chosen of Elune
		[GetSpellInfo(102543)] = { id = 102543, cd = 180 },			-- Incarnation: King of the Jungle
		[GetSpellInfo(102558)] = { id = 102558, cd = 180 },			-- Incarnation: Son of Ursoc
		[GetSpellInfo(108288)] = { id = 108288, cd = 360 },			-- Heart of the Wild
		[GetSpellInfo(124974)] = { id = 124974, cd = 90 },			-- Nature's Vigil
		[GetSpellInfo(106922)] = { id = 106922, cd = 180, glyph = 116238, altCD = 300 },			-- Might of Ursoc
		[GetSpellInfo(112071)] = { id = 112071, cd = 180 },			-- Celestial Alignment
		[GetSpellInfo(102351)] = { id = 102351, cd = 30 },			-- Cenarion Ward
		[GetSpellInfo(102280)] = { id = 102280, cd = 30 },			-- Displacer Beast
		[GetSpellInfo(132158)] = { id = 132158, cd = 60 },			-- Nature's Swiftness
		[GetSpellInfo(108238)] = { id = 108238, cd = 120 },			-- Renewal
		[GetSpellInfo(102359)] = { id = 102359, cd = 30 },			-- Mass Entanglement
		[GetSpellInfo(33831)] = { id = 33831, cd = 60 },			-- Force of Nature
		[GetSpellInfo(102793)] = { id = 102793, cd = 60 },			-- Ursol's Vortex
		[GetSpellInfo(48505)] = { id = 48505, cd = 90 },			-- Starfall
		[GetSpellInfo(5211)] = { id = 5211, cd = 50 },				-- Mighty Bash
		[GetSpellInfo(61336)] = { id = 61336, cd = 180, glyph = 116238, altCD = 120 },				-- Survival Instincts
		[GetSpellInfo(77764)] = { id = 77764, cd = 120 },				-- Stampeding Roar
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["HUNTER"] = { 
		[GetSpellInfo(5384)]  = { id = 5384,  cd = 30 },			-- Feign Death
		[GetSpellInfo(34477)] = { id = 34477, cd = 30 },			-- Misdirection
		[GetSpellInfo(19263)] = { id = 19263, cd = 180, talent = 118675, altCD = 120 },			-- Deterrence
		[GetSpellInfo(781)] = { id = 781, cd = 20, talent = 118675, altCD = 10 },				-- Disengage
		[GetSpellInfo(34490)] = { id = 34490, cd = 24 },			-- Silencing Shot
		[GetSpellInfo(109304)] = { id = 109304, cd = 120 },			-- Exhilaration
		--[GetSpellInfo(23989)] = { id = 23989, cd = 300 },			-- Readiness
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
		--[GetSpellInfo(121818)] = { id = 121818, cd = 300 },			-- Stampede
		--[GetSpellInfo(109259)] = { id = 109259, cd = 60 },			-- Powershot
		--[GetSpellInfo(19386)] = { id = 19386, cd = 45 },			-- Wyvern Sting
		--[GetSpellInfo(131894)] = { id = 131894, cd = 120 },			-- A Murder of Crows
		--[GetSpellInfo(120360)] = { id = 120360, cd = 30 },			-- Barrage
		--[GetSpellInfo(109248)] = { id = 109248, cd = 45 },			-- Binding Shot
		--[GetSpellInfo(130392)] = { id = 130392, cd = 20 },			-- Blink Strike
		--[GetSpellInfo(120679)] = { id = 120679, cd = 30 },			-- Dire Strike
		--
		--[GetSpellInfo(82726)] = { id = 82726, cd = 30 },			-- Fervor
    },

    ["MAGE"] = {
        [GetSpellInfo(80353)] = { id = 80353, cd = 300 },			-- Time Warp
		[GetSpellInfo(45438)] = { id = 45438, cd = 300 },			-- Ice Block
		[GetSpellInfo(66)]    = { id =    66, cd = 300 },			-- Invisibility
		[GetSpellInfo(113724)] = { id = 113724, cd = 30 },			-- Ring of Frost
		[GetSpellInfo(2139)]  = { id = 2139,  cd = 24 },			-- Counterspell
		[GetSpellInfo(12042)]  = { id = 12042,  cd = 90, glyph = 62210, altCD = 180 },			-- Arcane Power
		[GetSpellInfo(11426)]  = { id = 11426,  cd = 25 },			-- Ice Barrier
		[GetSpellInfo(1463)]  = { id = 1463,  cd = 25 },			-- Incanter's Ward
		[GetSpellInfo(115610)]  = { id = 115610,  cd = 25 },			-- Temporal Shield
		[GetSpellInfo(12051)]  = { id = 12051,  cd = 120, talent = 114003, altCD = 0.1 },			-- Evocation
		[GetSpellInfo(84714)]  = { id = 84714,  cd = 60 },			-- Frozen Orb
		[GetSpellInfo(55342)]  = { id = 55342,  cd = 180 },			-- Mirror Image
		[GetSpellInfo(12043)]  = { id = 12043,  cd = 90 },			-- Presence of Mind
		[GetSpellInfo(11958)]  = { id = 11958,  cd = 180 },			-- Cold Snap
		[GetSpellInfo(108839)]  = { id = 108839,  cd = 20 },		-- Ice Floes
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["PALADIN"] = { 
        [GetSpellInfo(498)]   = { id =   498, cd = 60, talent = 114154, altCD = 30 },	-- Divine Protection  
        [GetSpellInfo(642)]   = { id =   642, cd = 300, talent = 114154, altCD = 150 },			-- Divine Shield
        [GetSpellInfo(31850)] = { id = 31850, cd = 180 },			-- Ardent Defender 
        [GetSpellInfo(1022)]  = { id =  1022, cd = 300 },			-- Hand of Protection  
        [GetSpellInfo(6940)]  = { id =  6940, cd = 120 },			-- Hand of Sacrifice 
        [GetSpellInfo(1038)]  = { id =  1038, cd = 120 },			-- Hand of Salvation 
		[GetSpellInfo(1044)]  = { id =  1044, cd = 25 },			-- Hand of Freedom 
        [GetSpellInfo(633)]   = { id =   633, cd = 600, talent = 114154, altCD = 300 },			-- Lay on Hands
        [GetSpellInfo(31821)] = { id = 31821, cd = 180 },			-- Devotion Aura
        [GetSpellInfo(54428)] = { id = 54428, cd = 120 },			-- Divine Plea
        [GetSpellInfo(62124)] = { id = 62124, cd = 8 },				-- Hand of Reckoning
		[GetSpellInfo(96231)] = { id = 96231, cd = 15 },			-- Rebuke
		[GetSpellInfo(114916)] = { id = 114916, cd = 60 },			-- Execution Sentence
		[GetSpellInfo(114917)] = { id = 114917, cd = 60 },			-- Stay of Execution
		[GetSpellInfo(114165)] = { id = 114165, cd = 20 },			-- Holy Prism
		[GetSpellInfo(114158)] = { id = 114158, cd = 60 },			-- Light's Hammer
		[GetSpellInfo(105809)] = { id = 105809, cd = 120 },			-- Holy Avenger
		[GetSpellInfo(31884)] = { id = 31884, cd = 180, spec = 70, altCD = 120 },			-- Avenging Wrath
		[GetSpellInfo(85499)] = { id = 85499, cd = 45 },			-- Speed of Light
		[GetSpellInfo(86698)] = { id = 86698, cd = 300 },			-- Guardian of Ancient Kings (Ret)

		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
		--[GetSpellInfo(86669)] = { id = 86669, cd = 300 },			-- Guardian of Ancient Kings (Holy)
		--[GetSpellInfo(86659)] = { id = 86659, cd = 180 },			-- Guardian of Ancient Kings (Protection)
		--[GetSpellInfo(86150)] = { id = 86150, cd = 180 },			-- Guardian of Ancient Kings // All specs, cannot track only protection
		
    },

    ["PRIEST"] = { 
        [GetSpellInfo(64843)] = { id = 64843, cd = 180 },			-- Divine Hymn 
        [GetSpellInfo(6346)]  = { id =  6346, cd = 180, glyph = 42399, altCD = 120 },			-- Fear Ward 
        [GetSpellInfo(47788)] = { id = 47788, cd = 180 },			-- Guardian Spirit 
        [GetSpellInfo(64901)] = { id = 64901, cd = 360 },			-- Hymn of Hope 
        [GetSpellInfo(73325)] = { id = 73325, cd = 90 },			-- Leap of Faith
        [GetSpellInfo(33206)] = { id = 33206, cd = 180 },			-- Pain Suppression 
        [GetSpellInfo(62618)] = { id = 62618, cd = 180 },			-- Power Word: Barrier 
        [GetSpellInfo(15487)] = { id = 15487, cd = 45 },			-- Silence
		[GetSpellInfo(47585)] = { id = 47585, cd = 120 },			-- Dispersion
		[GetSpellInfo(108968)] = { id = 108968, cd = 360, spec = 258, altCD = 600 },			-- Void Shift
		[GetSpellInfo(10060)] = { id = 10060, cd = 120 },			-- Power Infusion
		[GetSpellInfo(34433)] = { id = 34433, cd = 180 },			-- Shadowfiend
		[GetSpellInfo(123040)] = { id = 123040, cd = 60 },			-- Mindbender
		[GetSpellInfo(108920)] = { id = 108920, cd = 30 },			-- Void Tendrils
		[GetSpellInfo(108921)] = { id = 108921, cd = 45 },			-- Psyfiend
		[GetSpellInfo(19236)] = { id = 19236, cd = 120 },			-- Desperate Prayer
		[GetSpellInfo(120517)] = { id = 120517, cd = 40 },			-- Halo
		[GetSpellInfo(109964)] = { id = 109964, cd = 60 },			-- Spirit Shell
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["ROGUE"] = { 
        [GetSpellInfo(31224)] = { id = 31224, cd = 60 },			-- Cloak of Shadows
		[GetSpellInfo(1856)]  = { id = 1856, cd = 180 },			-- Vanish
        [GetSpellInfo(57934)] = { id = 57934, cd = 30 },			-- Tricks of the Trade
		[GetSpellInfo(1766)]  = { id = 1766,  cd = 15 },			-- Kick
		[GetSpellInfo(14185)]  = { id = 14185,  cd = 300 },			-- Preparation
		[GetSpellInfo(51722)]  = { id = 51722,  cd = 60 },			-- Dismantle
		[GetSpellInfo(5277)]  = { id = 5277,  cd = 120 },			-- Evasion
		[GetSpellInfo(36554)]  = { id = 36554,  cd = 20 },			-- Shadowstep
		[GetSpellInfo(76577)]  = { id = 76577,  cd = 180 },			-- Smoke Bomb
		[GetSpellInfo(1966)]  = { id = 1966,  cd = 0.1 },			-- Feint
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["SHAMAN"] = { 
        [GetSpellInfo(hero)]  = { id = hero,  cd = 300 },												-- Bloodlust/Heroism  
        [GetSpellInfo(16190)] = { id = 16190, cd = 180, duration = 16 },								-- Mana Tide Totem  
        [GetSpellInfo(20608)] = { id = 20608, cd = 1800, ora = 2 },										-- Reincarnation 
		[GetSpellInfo(98008)] = { id = 98008, cd = 180, duration = 6 },									-- Spirit Link Totem
		[GetSpellInfo(51490)] = { id = 51490, cd = 45, glyph = 63270, altCD = 35 },						-- Thunderstorm
		[GetSpellInfo(57994)] = { id = 57994, cd = 12, glyph = 55451, altCD = 15 },						-- Wind Shear
		[GetSpellInfo(58875)] = { id = 58875, cd = 120, spec = 263, altCD = 60 },						-- Spiritwalk
		[GetSpellInfo(108280)] = { id = 108280, cd = 180, duration = 11 },								-- Healing Tide Totem
		[GetSpellInfo(114049)] = { id = 114049, cd = 180 },												-- Ascendance
		[GetSpellInfo(108281)] = { id = 108281, cd = 120 },												-- Ancestral Guidance
		[GetSpellInfo(120668)] = { id = 120668, cd = 300, duration = 10 },								-- Stormlash Totem
		[GetSpellInfo(108270)] = { id = 108270, cd = 60, duration = 30 },								-- Stone Bulwark Totem
		[GetSpellInfo(108271)] = { id = 108271, cd = 90 },												-- Astral Shift
		[GetSpellInfo(51485)] = { id = 51485, cd = 30, duration = 20 },									-- Earthgrab Totem
		[GetSpellInfo(108273)] = { id = 108273, cd = 60, duration = 6 },								-- Windwalk Totem
		[GetSpellInfo(108285)] = { id = 108285, cd = 180 },												-- Call of the Elements
		[GetSpellInfo(16166)] = { id = 16166, cd = 90 },												-- Elemental Mastery
		[GetSpellInfo(16188)] = { id = 16188, cd = 90 },												-- Ancesteral Swiftness
		[GetSpellInfo(8143)] = { id = 8143, cd = 60, duration = 6 },									-- Tremor Totem
		[GetSpellInfo(2062)] = { id = 2062, cd = 300, duration = 60 },									-- Earth Elemental Totem
		[GetSpellInfo(2894)] = { id = 2894, cd = 300, glyph = 55455, altCD = 150, duration = 60, altDuration = 30 },				-- Fire Elemental Totem
		[GetSpellInfo(30823)] = { id = 30823, cd = 60 },												-- Shamanistic Rage
		
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["WARLOCK"] = { 
        [GetSpellInfo(20707)] = { id = 20707, cd = 600, ora = 3 },	-- Soulstone Resurrection // Possible need to track 6203
		[GetSpellInfo(698)]   = { id =   698, cd = 120 },			-- Ritual of Summoning
		[GetSpellInfo(29893)] = { id = 29893, cd = 120 },			-- Ritual of Souls
		[GetSpellInfo(19647)] = { id = 19647, cd = 24 },			-- Spell Lock
		[GetSpellInfo(108359)] = { id = 108359, cd = 120 },			-- Dark Regeneration
		[GetSpellInfo(30283)] = { id = 30283, cd = 30 },			-- Shadowfury
		[GetSpellInfo(6789)] = { id = 6789, cd = 45 },				-- Mortal Coil
		[GetSpellInfo(5484)] = { id = 5484, cd = 40 },				-- Howl of Terror
		[GetSpellInfo(108416)] = { id = 108416, cd = 60 },			-- Sacrificial Pact
		[GetSpellInfo(110913)] = { id = 110913, cd = 180 },			-- Dark Bargain
		[GetSpellInfo(108482)] = { id = 108482, cd = 60 },			-- Unbound Will
		[GetSpellInfo(108501)] = { id = 108501, cd = 120 },			-- Grimoire of Service
		[GetSpellInfo(108503)] = { id = 108503, cd = 30 },			-- Grimoire of Sacrifice
		[GetSpellInfo(108505)] = { id = 108505, cd = 120 },			-- Archimonde's Vengeance
		[GetSpellInfo(104773)] = { id = 104773, cd = 180, glyph = 146964, altCD = 120 },			-- Unending Resolve
		[GetSpellInfo(108508)] = { id = 108508, cd = 60 },			-- Mannoroth's Fury
		
		--[GetSpellInfo(119049)] = { id = 119049, cd = 60 },			-- Kil'jaeden's Cunning
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    },

    ["WARRIOR"] = { 
        [GetSpellInfo(12975)] = { id = 12975, cd = 180 },			-- Last Stand  
        [GetSpellInfo(871)]   = { id =   871, cd = 180, spec = 73, altCD = 120 },			-- Shield Wall 
        [GetSpellInfo(55694)] = { id = 55694, cd = 60 },			-- Enraged Regeneration
        [GetSpellInfo(355)]   = { id =   355, cd = 8 },				-- Taunt
		[GetSpellInfo(97462)] = { id = 97462, cd = 180 },			-- Rallying Cry
		[GetSpellInfo(6552)]  = { id = 6552,  cd = 15 },			-- Pummel
		[GetSpellInfo(114203)]  = { id = 114203,  cd = 180 },		-- Demoralizing Banner
		[GetSpellInfo(114207)]  = { id = 114207,  cd = 180 },		-- Skull Banner
		[GetSpellInfo(102060)]  = { id = 102060,  cd = 40 },		-- Disrupting Shout
		[GetSpellInfo(107566)]  = { id = 107566,  cd = 40 },		-- Staggering Shout
		[GetSpellInfo(46924)]  = { id = 46924,  cd = 60 },			-- Bladestorm
		[GetSpellInfo(118000)]  = { id = 118000,  cd = 60 },		-- Dragon Roar
		--[GetSpellInfo(46968)]  = { id = 46968,  cd = 40 },			-- Shockwave
		[GetSpellInfo(114028)]  = { id = 114028,  cd = 60 },		-- Mass Spell Reflection
		[GetSpellInfo(114029)]  = { id = 114029,  cd = 30 },		-- Safeguard
		[GetSpellInfo(114030)]  = { id = 114030,  cd = 120 },		-- Vigilance
		[GetSpellInfo(107574)]  = { id = 107574,  cd = 180 },		-- Avatar
		[GetSpellInfo(12292)]  = { id = 12292,  cd = 60 },			-- Bloodbath
		[GetSpellInfo(107570)]  = { id = 107570,  cd = 30 },		-- Stormbolt
		[GetSpellInfo(118038)]  = { id = 118038,  cd = 120 },		-- Die by the Sword
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    }, 
	
	["MONK"] = { 
        [GetSpellInfo(115310)] = { id = 115310, cd = 180 },			-- Revival
		[GetSpellInfo(116849)] = { id = 116849, cd = 120 },			-- Life Cocoon
		[GetSpellInfo(115399)] = { id = 115399, cd = 90 },			-- Chi Brew
		[GetSpellInfo(119381)] = { id = 119381, cd = 45 },			-- Leg Sweep
		[GetSpellInfo(119392)] = { id = 119392, cd = 30 },			-- Charging Ox Wave
		[GetSpellInfo(122278)] = { id = 122278, cd = 90 },			-- Dampen Harm
		[GetSpellInfo(122783)] = { id = 122783, cd = 90 },			-- Diffuse Magic
		[GetSpellInfo(116847)] = { id = 116847, cd = 30 },			-- Rushing Jade Wind
		[GetSpellInfo(123904)] = { id = 123904, cd = 180 },			-- Invoke Xuen, the White Tiger
		[GetSpellInfo(115203)] = { id = 115203, cd = 180 },			-- Fortifying Brew
		[GetSpellInfo(115176)] = { id = 115176, cd = 180 },			-- Zen Meditation
		[GetSpellInfo(115213)] = { id = 115213, cd = 180 },			-- Avert Harm
		
		--[GetSpellInfo(6262)] = { id = 6262, cd = 120 },				-- Healthstone
    }, 
}

local resetCooldowns = {
	[14185] = {
		5277, 51722, 1856,
	},
	[108285] = {
		8143, 108273, 51485, 108270,
	},
	[48518] = {
		48505
	},
	--[23989] = {
	--	5384, 34477, 19263, 781, 34490, 109304
	--},
	[11958] = {
		45438
	},
}

local totems = {
	51485, 108280, 108270, 108273, 108269, 2062, 2484, 2894, 8177, 5394, 120668, 8143
}

-- Role constants:
-- HEALER
-- DAMAGER
-- TANK

TrackCooldowns.cooldowns = cooldowns
TrackCooldowns.resetCooldowns = resetCooldowns
TrackCooldowns.totems = totems