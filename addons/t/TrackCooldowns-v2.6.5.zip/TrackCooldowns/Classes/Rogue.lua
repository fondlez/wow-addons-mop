assert(TrackCooldowns, "TrackCooldowns not found!")
if (select(2, UnitClass("player"))) ~= "ROGUE" then return end

local mod = TrackCooldowns:NewModule("Rogue", TrackCooldowns.ModuleBase, "AceConsole-3.0", "AceEvent-3.0")
mod.cooldowns = TrackCooldowns.cooldowns["ROGUE"]