assert(TrackCooldowns, "TrackCooldowns not found!")
if (select(2, UnitClass("player"))) ~= "MAGE" then return end

local mod = TrackCooldowns:NewModule("Mage", TrackCooldowns.ModuleBase, "AceConsole-3.0", "AceEvent-3.0")
mod.cooldowns = TrackCooldowns.cooldowns["MAGE"]