--[[
	Titan Panel [Recap]: Titan plugin for Recap stats
	copyright 2006 by Gello (gello_biafra@hotmail.com)
	and chicogrande (jluzier@gmail.com)
	and hawksy (hawksy@telus.net)
	for use with Recap 4.50 and later
]]

-- globals
TITAN_RECAP_ID = "Recap";
TITAN_RECAP_VERSION = "2.461";
TITAN_RECAP_BUTTON_ARTWORK_PATH = "Interface\\AddOns\\Recap\\Images\\";
TITAN_RECAP_BUTTON_TOGGLE_MONITOR = "TitanPanelRecap_TogglePause";

-- colors
local TITAN_RECAP_COLOUR = {};
TITAN_RECAP_COLOUR["red"] = { r = 1.0, g = 0.0, b = 0.0 }
TITAN_RECAP_COLOUR["green"] = { r = 0.0, g = 1.0, b = 0.0 }
TITAN_RECAP_COLOUR["blue"] = { r = 0.0, g = 0.0, b = 1.0 }
TITAN_RECAP_COLOUR["white"] = { r = 1.0, g = 1.0, b = 1.0 }
TITAN_RECAP_COLOUR["magenta"] = { r = 1.0, g = 0.0, b = 1.0 }
TITAN_RECAP_COLOUR["yellow"] = { r = 1.0, g = 1.0, b = 0.0 }
TITAN_RECAP_COLOUR["cyan"] = { r = 0.0, g = 1.0, b = 1.0 }
TITAN_RECAP_COLOUR["gray"] = { r = 0.7, g = 0.7, b = 0.7 }
TITAN_RECAP_COLOUR["orange"] = { r = 1.0, g = 0.6, b = 0.0 }

local state = "Idle";
local yourdps = 0;
local yourhps = 0;
local yourpetpercent = 0;
local maxhit = 0;
local dpsout = 0;
local dpsin = 0;
local healing = 0;
local overheal = "0%";
local viewtype = 0;

-- access values in Recap to display in the plugin
function TitanPanelRecap_Update()
	local rTemp = _G.recap_temp
	state = recap_user.State
	if rTemp then
		viewtype = rTemp.Localize.LastAll[recap_user.View]
		if recap_user.View == "Last" then
			yourdps = rTemp.PlayerDPSLast
			yourhps = rTemp.PlayerHPSLast
			yourpetpercent = rTemp.PlayerPetPercentLast
			maxhit = rTemp.PlayerMaxHitLast
			dpsout = rTemp.GroupDPSOutLast
			dpsin = rTemp.GroupDPSInLast
			healing = rTemp.PlayerHealingLast
			if ((rTemp.PlayerHealingLast + rTemp.PlayerOverhealingLast) > 0) then
				overheal = tostring(math.floor((100*rTemp.PlayerOverhealingLast / (rTemp.PlayerHealingLast + rTemp.PlayerOverhealingLast)) + 0.5)).."%"
			else
				overheal = 0
			end
		else
			if recap_user.View == "All" then
				yourdps = rTemp.PlayerDPSAll
				yourhps = rTemp.PlayerHPSAll
				yourpetpercent = rTemp.PlayerPetPercentAll
				maxhit = rTemp.PlayerMaxHitAll
				dpsout = rTemp.GroupDPSOutAll
				dpsin = rTemp.GroupDPSInAll
				healing = rTemp.PlayerHealingAll
				if ((rTemp.PlayerHealingAll + rTemp.PlayerOverhealingAll) > 0) then
					overheal = tostring(math.floor((100*rTemp.PlayerOverhealingAll / (rTemp.PlayerHealingAll + rTemp.PlayerOverhealingAll)) + 0.5)).."%"
				else
					overheal = 0
				end
			end
		end
	end
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecapButton_OnLoad(self,frame)
	if( DEFAULT_CHAT_FRAME ) then
		DEFAULT_CHAT_FRAME:AddMessage("Titan Panel [Recap] v"..TITAN_RECAP_VERSION.." loaded");
	end
	self.registry = { 
		id = "Recap",
		menuText = "Recap",
        category = "Combat",
		version = TITAN_RECAP_VERSION, 
		buttonTextFunction = "TitanPanelRecapButton_GetButtonText", 
		tooltipTitle = "Recap v"..tostring(Recap_Version),
		tooltipTextFunction = "TitanPanelRecapButton_GetTooltipText";
		icon = TITAN_RECAP_BUTTON_ARTWORK_PATH.."Recap-Status";
		iconWidth = 16;
		savedVariables = {
			ShowLabelText = 1,  -- Default to 1
			ShowYourDps = 1;
			ShowYourHps = 1;
			ShowYourPetPercent = 1;
			ShowMaxHit = 1;
			ShowDpsOut = 1;
			ShowDpsIn = 1;
			ShowHealing = 1;
			ShowOverheal = 1;
			ShowIcon = 1;
		}
	};
end

function TitanPanelRecapButton_GetButtonText(id)
	-- If id not nil, return corresponding plugin button
	-- Otherwise return this button and derive the real id
	local button, id = TitanUtils_GetButton(id, true);
	local recapRichText = "";
	-- format the colored status bubble
	if (TitanGetVar(TITAN_RECAP_ID, "ShowIcon")) then
		recapIcon =	getglobal(button:GetName().."Icon");
		if state=="Idle" then
			recapIcon:SetVertexColor(.5,.5,.5)
		elseif state=="Active" then
			recapIcon:SetVertexColor(0,1,0)
		elseif state=="Stopped" then
			recapIcon:SetVertexColor(1,0,0)
		end
	end
		
	-- create the string to return to the display
	-- dps
	if (TitanGetVar(TITAN_RECAP_ID, "ShowYourDps")) then
		recapRichText = TitanUtils_GetHighlightText(yourdps).." ";
	end
	-- hps
	if (TitanGetVar(TITAN_RECAP_ID, "ShowYourHps")) then
		recapRichText = recapRichText..TitanUtils_GetColoredText(yourhps, TITAN_RECAP_COLOUR["cyan"]).." ";
	end
	-- pet%
	if (TitanGetVar(TITAN_RECAP_ID, "ShowYourPetPercent")) then
		recapRichText = recapRichText..TitanUtils_GetHighlightText(yourpetpercent).."% ";
	end
	-- maxhit
	if (TitanGetVar(TITAN_RECAP_ID, "ShowMaxHit")) then
		recapRichText = recapRichText..TitanUtils_GetColoredText(maxhit, TITAN_RECAP_COLOUR["orange"]).." ";
	end
	-- dpsout
	if (TitanGetVar(TITAN_RECAP_ID, "ShowDpsOut")) then
		recapRichText = recapRichText..TitanUtils_GetGreenText(dpsout).." ";
	end
	-- dpsin	
	if (TitanGetVar(TITAN_RECAP_ID, "ShowDpsIn")) then
		recapRichText = recapRichText..TitanUtils_GetRedText(dpsin).." "
	end
	-- healing
	if (TitanGetVar(TITAN_RECAP_ID, "ShowHealing")) then
		recapRichText = recapRichText..TitanUtils_GetColoredText(healing, TITAN_RECAP_COLOUR["cyan"]).." ";
	end	
	-- overhealing
	if (TitanGetVar(TITAN_RECAP_ID, "ShowOverheal")) then
		recapRichText = recapRichText..TitanUtils_GetColoredText(overheal, TITAN_RECAP_COLOUR["cyan"]).." ";
	end				
	-- adding some space if the user elects to not show label text	
	if (TitanGetVar(TITAN_RECAP_ID, "ShowLabelText")) then
		return TITAN_RECAP_BUTTON_LABEL, recapRichText;
	else
		recapRichText = TITAN_RECAP_BUTTON_NO_LABEL..recapRichText;	
		return TITAN_RECAP_BUTTON_LABEL, recapRichText;
	end
end

function TitanPanelRecap_OnMouseUp(frame, button)
	if button=="LeftButton" then
		RecapFrame_Toggle();
	end
end

function TitanPanelRightClickMenu_PrepareRecapMenu()
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[TITAN_RECAP_ID].menuText);

	-- dps
	local info = {};
	info.text = TITAN_RECAP_BUTTON_SHOWDPS;
	info.func = TitanPanelRecap_ToggleYourDPS;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowYourDps");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);

	-- hps
	local info = {};
	info.text = TITAN_RECAP_BUTTON_SHOWHPS;
	info.func = TitanPanelRecap_ToggleYourHPS;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowYourHps");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);

	-- pet percent
	local info = {};
	info.text = TITAN_RECAP_BUTTON_SHOW_PET_PERCENT;
	info.func = TitanPanelRecap_ToggleYourPetPercent;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowYourPetPercent");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);
	
	-- maxhit
	info.text = TITAN_RECAP_BUTTON_SHOWMAXHIT_TEXT;
	info.func = TitanPanelRecap_ToggleMaxHit;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowMaxHit");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);												
	
	-- dps out
	info.text = TITAN_RECAP_BUTTON_SHOWDPS_OUT;
	info.func = TitanPanelRecap_ToggleDPSOut;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowDpsOut");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);
	
	-- dps in
	info.text = TITAN_RECAP_BUTTON_SHOWDPS_IN;
	info.func = TitanPanelRecap_ToggleDPSIn;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowDpsIn");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);
	
	-- healing
	info.text = TITAN_RECAP_BUTTON_SHOWHEALING_TEXT;
	info.func = TitanPanelRecap_ToggleHealing;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowHealing");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);
	
	-- overhealing
	info.text = TITAN_RECAP_BUTTON_SHOWOVERHEAL_TEXT;
	info.func = TitanPanelRecap_ToggleOverheal;
	info.checked = TitanGetVar(TITAN_RECAP_ID, "ShowOverheal");
	info.keepShownOnClick = 1;
	UIDropDownMenu_AddButton(info);

	TitanPanelRightClickMenu_AddSpacer();

	-- toggle monitoring
	if (recap_user and recap_user.Paused == true) then
		TitanPanelRightClickMenu_AddCommand(TITAN_RECAP_BUTTON_START_TEXT, TITAN_RECAP_ID, TITAN_RECAP_BUTTON_TOGGLE_MONITOR);
	else
		TitanPanelRightClickMenu_AddCommand(TITAN_RECAP_BUTTON_PAUSE_TEXT, TITAN_RECAP_ID, TITAN_RECAP_BUTTON_TOGGLE_MONITOR);
	end

	TitanPanelRightClickMenu_AddSpacer();
	TitanPanelRightClickMenu_AddToggleIcon(TITAN_RECAP_ID);	
	TitanPanelRightClickMenu_AddToggleLabelText(TITAN_RECAP_ID);	
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, TITAN_RECAP_ID, TITAN_PANEL_MENU_FUNC_HIDE);

end

function TitanPanelRecapButton_GetTooltipText()
	local richTooltipText = "";
	richTooltipText = state.."\n";
	richTooltipText = richTooltipText..viewtype..":\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_DPS.."\t"..TitanUtils_GetHighlightText(yourdps).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_HPS.."\t"..TitanUtils_GetColoredText(yourhps, TITAN_RECAP_COLOUR["cyan"]).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_PET_PERCENT.."\t"..TitanUtils_GetHighlightText(yourpetpercent).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_MAXHIT.."\t"..TitanUtils_GetColoredText(maxhit, TITAN_RECAP_COLOUR["orange"] ).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_TOTALDPS_OUT.."\t"..TitanUtils_GetGreenText(dpsout).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_TOTALDPS_IN.."\t"..TitanUtils_GetRedText(dpsin).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_HEALING.."\t"..TitanUtils_GetColoredText(healing, TITAN_RECAP_COLOUR["cyan"]).."\n";
	richTooltipText = richTooltipText..TITAN_RECAP_TOOLTIP_OVERHEAL.."\t"..TitanUtils_GetColoredText(overheal, TITAN_RECAP_COLOUR["cyan"]).."\n";
	richTooltipText = richTooltipText..TitanUtils_GetGreenText(TITAN_RECAP_BUTTON_HINT_TEXT);
	return richTooltipText;
end

function TitanPanelRecap_ToggleYourDPS()
	TitanToggleVar(TITAN_RECAP_ID, "ShowYourDps");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleYourHPS()
	TitanToggleVar(TITAN_RECAP_ID, "ShowYourHps");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleYourPetPercent()
	TitanToggleVar(TITAN_RECAP_ID, "ShowYourPetPercent");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleMaxHit()
	TitanToggleVar(TITAN_RECAP_ID, "ShowMaxHit");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleDPSOut()
	TitanToggleVar(TITAN_RECAP_ID, "ShowDpsOut");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleDPSIn()
	TitanToggleVar(TITAN_RECAP_ID, "ShowDpsIn");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleHealing()
	TitanToggleVar(TITAN_RECAP_ID, "ShowHealing");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_ToggleOverheal()
	TitanToggleVar(TITAN_RECAP_ID, "ShowOverheal");
	TitanPanelButton_UpdateButton(TITAN_RECAP_ID);
end

function TitanPanelRecap_TogglePause()
	Recap_OnClick("Pause");
end
