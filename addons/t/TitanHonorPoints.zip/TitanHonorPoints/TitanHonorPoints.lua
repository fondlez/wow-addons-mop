--[[
	TitanHonor: A simple Display of current Honor value as a percent
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Honor Points|r"
local buttonlabel = "Honor: "
local ID = "HO"
local elap, HO, prevHO = 0, 0.0, -2
local GetUnitHO = 0 
local startVal = 0
local inInstance, instanceType, instanceStarted
local HPw

-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelHOButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanHonorPoints" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0
	local myicon = ""
	local mycheck = ""
	
	if UnitFactionGroup("Player") == "Horde" then
		myicon = "Interface\\Icons\\pvpcurrency-honor-horde.blp"
		mycheck = "Interface\\Icons\\PVPCurrency-Honor-Horde"
	else
		myicon = "Interface\\Icons\\pvpcurrency-honor-alliance.blp"
		mycheck ="Interface\\Icons\\PVPCurrency-Honor-Alliance"
	end
 


	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelHOButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelHOButton_GetTooltipText",
		frequency = 2,
		icon = myicon,
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,

		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		-- "none" when outside an instance
        -- "pvp" when in a battleground
        -- "arena" when in an arena
        -- "party" when in a 5-man instance
        -- "raid" when in a raid instance 


		for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)
			--if name == "Honor Points" then
			if icon == mycheck then
				CurrencyIndex = i
			end
			--print(name)
			--Honor Points
			--Conquest Points
			--Valor Points
			--Justice Points
		end
		
		name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(CurrencyIndex)
 
		local inInstance, instanceType = IsInInstance()
		--if inInstance and instanceType == "pvp"  then
		--if GetNumSubgroupMembers() > 0 then
			if instanceStarted == 0 then
				startVal = count		
				--print("new group")
			end
			instanceStarted = 1
		--else
		--	instanceStarted = 0
		--end

		 HO = count
		HPw = maximum /100
		
		if HO == prevHO then return end
		prevHO  = HO
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelHOButton_GetButtonText()
----------------------------------------------
	local HOtext, pitchtext
	if not HO then
		HOtext = "??"
	else	
		if startVal == count or startVal == 0 then
			HOtext = string.format("%.0f", HO) .."" 
		else
			if HO - startVal == 0 then
				HOtext = string.format("%.0f", HO) .."" 
			else
				HOtext = string.format("%.0f", HO) .." (+".. HO - startVal..")"
			end
			
		end
	end
	return buttonlabel, HOtext
end

-----------------------------------------------
function TitanPanelHOButton_GetTooltipText()
-----------------------------------------------


return "Total Honor Points:\t"..HO.."/"..HPw

end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareHOMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end