--[[
	TitanMC: A simple Display of current MC value
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Melee Crit|r"
local buttonlabel = "Crit: "
local ID = "MC"
local elap, MC, prevMC = 0, 0.0, -2
local GetUnitMC = 0 

local base, posBuff, negBuff = UnitAttackPower("player");
local effective = base + posBuff + negBuff;


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelMCButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanMC" then 
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelMCButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelMCButton_GetTooltipText",
		frequency = 0.5,
		icon = "Interface\\Icons\\Ability_rogue_feigndeath.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end

		
	
		MC = GetCritChance(); -- fix
		if MC == prevMC then return end
		prevMC  = MC
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end

----------------------------------------------
function TitanPanelMCButton_GetButtonText()
----------------------------------------------
	local MCtext, pitchtext
	if not MC then
		MCtext = "??"
	else
	
		MCtext = string.format("%.2f", MC) .."%" 
	end
	return buttonlabel, MCtext
end

-----------------------------------------------
function TitanPanelMCButton_GetTooltipText()
-----------------------------------------------
	return "Displays your current Melee Crit value"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareMCMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end