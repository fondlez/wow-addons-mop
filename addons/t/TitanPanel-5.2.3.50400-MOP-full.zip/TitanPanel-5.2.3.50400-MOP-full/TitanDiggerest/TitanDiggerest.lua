﻿--[[
  TITAN PANEL: DIGGEREST    ТИТАН ПАНЕЛЬ: АДОИСКАТЕЛЬ

  Description/Описание:
• en: Shows number of collected artifacts and some archaeology statistics
• ru: Показывает количество собранных артефактов и некоторую информацию об археологии

Author/Автор:     Вишмастер (RU-Термоштепсель)
E-mail/Мыло:      Wish1250@gmail.com
Created/Создан:   07.01.2011
Locales/Языки:    RU,EN                  
]]--

local TITAN_DIGGEREST_ID = "Diggerest";
local TITAN_DIGGEREST_VERSION = "2.9";
local updateTable = {TITAN_DIGGEREST_ID, TITAN_PANEL_UPDATE_ALL};
local L = LibStub("AceLocale-3.0"):GetLocale("TitanDiggerest", true);
local AceTimer = LibStub("AceTimer-3.0")
local updateTimer = nil;
------------------------------------------------------------------------
function TitanPanelDiggerestButton_OnLoad(self)
	self.registry = {
		id = TITAN_DIGGEREST_ID,
		category = "Information",
        version = TITAN_DIGGEREST_VERSION,
		menuText = L["menu"],
		buttonTextFunction = "TitanPanelDiggerest_GetButtonText",
        tooltipTitle = L["menu"],
        tooltipTextFunction = "TitanPanelDiggerest_GetTooltipText",
		icon = "Interface\\AddOns\\TitanDiggerest\\shovel",
		iconWidth = 16,
		savedVariables = {
		 ShowIcon = true,
		 ShowLabelText = true,
         FragInfo = true}
         }; 
    DEFAULT_CHAT_FRAME:AddMessage("Titan"..L["menu"]..L["About"], 1, 1, 1)
end
------------------------------------------------------------------------
function TitanPanelDiggerestButton_OnShow()
if not updateTimer then updateTimer = AceTimer.ScheduleRepeatingTimer("TitanPanelDiggerest", TitanPanelDiggerestButton_OnUpdate, 1) end
end
function TitanPanelDiggerestButton_OnHide()
AceTimer.CancelTimer("TitanPanelDiggerest", updateTimer, true);
updateTimer = nil;
end
function TitanPanelDiggerestButton_OnUpdate(self)
TitanPanelPluginHandle_OnUpdate(updateTable);
end
function TitanPanelDiggerestButton_OnClick(self, button)
if button == "LeftButton" then CastSpellByName(GetArchaeologyInfo()) end
end
-- ТЕКСТ КНОПКИ 
function TitanPanelDiggerest_GetButtonText() 
return L["menu"]
end
--********************************************************************
--***                        ГЛАВНАЯ ЧАСТЬ                         ***
--********************************************************************
function TitanPanelDiggerest_GetTooltipText()
local _,_,profArch = GetProfessions(); --детект профы

if profArch then
RequestArtifactCompletionHistory() --запрос истории завершенных артефактов

local g = "|cff00ff00" -- зеленый
local b = "|cff00ffff" -- голубой
local l = "|cff00bfff" -- синий
local w = "|cffffffff" -- белый
local y = "|cffffff00" -- желтый
local o = "|cffff8a00" -- оранжевый
local e = "|cffdcdcdc" -- серый
------------------------------------------------------------------------
-- АРТЕФАКТЫ
------------------------------------------------------------------------
local name = {L["Dwarf"],L["Draenei"],L["Fossil"],L["NightElf"],L["Nerubian"],L["Orc"],L["Tol'Vir"],L["Troll"],L["Vrykul"],L["Mantid"],L["Pandaren"],L["Mogu"]};

local complCom = {0;0;0;0;0;0;0;0;0;0;0;0;0}--ОБЫЧНЫЕ
local reqCom = {27;8;12;18;7;9;7;14;5;8;10;10;0}
local totalReqCom = 135;

local complRar = {0;0;0;0;0;0;0;0;0;0;0;0;0}--РЕДКИЕ
local reqRar = {4;2;5;7;2;1;6;3;2;2;2;2;0}
local totalReqRar = 38;

local total = {0;0;0;0;0;0;0;0;0;0;0;0;0}--ВСЕГО
local totalArt = 0;
------------------------------------------------------------------------
  for x=1,12 do 
    local c=GetNumArtifactsByRace(x); 
    local a=0;  
    for y=1,c do 
         local t=select(9,GetArtifactInfoByRace(x,y)); 
         name[x] = GetArchaeologyRaceInfo(x); 
         a=a+t; 
         end;  
    if(c>1) then total[x] = a; end; 
    totalArt = totalArt+total[x];
  end;
------------------------------------------------------------------------
  local LastCompl = 0

  for raceIndex = 1,12 do
	local artIndex = 1;
	local done = false;
	local com = 0;
    local rar = 0;
   -- local total = 0;

   repeat
	 local name, _, rarity, _,_,_,_, firstComplTime, complCount = GetArtifactInfoByRace(raceIndex, artIndex);
	  artIndex = artIndex + 1;
      if name then
       if firstComplTime then if firstComplTime >= LastCompl then LastCompl = firstComplTime; end; end;
       if complCount > 0 then 
         if rarity == 0 then com = com + 1; else rar = rar + 1; end; 
       end;
	   else done = true; end; 
    until done
	 complCom[raceIndex] = com;
	 complRar[raceIndex] = rar;
	end;
------------------------------------------------------------------------
  local LastComlTime = e..L["unknown"];
  if LastCompl > 0 then LastComlTime = date("%d/%m/%y %X",LastCompl); end;
------------------------------------------------------------------------
    local totalComplCom = 0
    local totalComplRar = 0
    local artProg = {0;0;0;0;0;0;0;0;0;0;0;0;}
    local artRecFrag = {0;0;0;0;0;0;0;0;0;0;0;0;}
    local artReqFrag = {0;0;0;0;0;0;0;0;0;0;0;0;}
    local spacer = {" ", " ", " ", " ", " ", " ", " ", " ", " "," "," "," ", ""}--13й для заглавия
    local ArtInfoFullTooltip = {}
    
    --local check = false;
    --local startArtNum = 1;
    
    for x=1,12 do 
     --if check == false then startArtNum = 1; check = true; end;
     ---------------
     totalComplCom = totalComplCom+complCom[x]; 
     totalComplRar = totalComplRar+complRar[x]; 
     SetSelectedArtifact(x);
     artRecFrag[x], _, artReqFrag[x] = GetArtifactProgress()
     ---------------
 --!!! где-то здесь ошибка, нужно пересмотреть и исправить    
     if total[x] > 9 then
       if total[x] > 999 then spacer[x] = ""; spacer[14] = "   ";--более 999
       elseif (total[x] > 99) and (total[x] <= 999) then spacer[x] = ""; spacer[14] = "   ";--100-999
       else spacer[x] = "   "; spacer[14] = "   "; end;--10-99
     else spacer[x] = "   "; spacer[14] = "  "; end--0-9
     
     ---------------
     if TitanGetVar(TITAN_DIGGEREST_ID, "FragInfo") == 1 then
     if artRecFrag[x]<10 then spacer[x] = spacer[x].."   " end;
     ArtInfoFullTooltip[x] = o..name[x]..": \t"..w..complCom[x].."/"..reqCom[x].."  "..b..complRar[x].."/"..reqRar[x].."  "..g..total[x]..spacer[x].." "..e..artRecFrag[x].."/"..artReqFrag[x]
     else ArtInfoFullTooltip[x] = o..name[x]..": \t"..w..complCom[x].."/"..reqCom[x].."  "..b..complRar[x].."/"..reqRar[x].."  "..g..total[x]..spacer[x] end;
    end
    
    --SetSelectedArtifact(startArtNum);
    --check = false;
------------------------------------------------------------------------
-- ОПОВЕЩЕНИЕ
------------------------------------------------------------------------
-- ПЕЧАТЬ
function TitanPanelDiggerest_Print()
               DEFAULT_CHAT_FRAME:AddMessage(o..L["race"].." "..L["printMSG"])
 for i=1,12 do DEFAULT_CHAT_FRAME:AddMessage(o..name[i]..": "..w..complCom[i].."/"..reqCom[i].."  "..b..complRar[i].."/"..reqRar[i].."  "..g..total[i]) end
               DEFAULT_CHAT_FRAME:AddMessage(L["total"]..w..totalComplCom.."/"..totalReqCom.."  "..b..totalComplRar.."/"..totalReqRar.."  "..g..totalArt)

--[[if not (TitanGetVar(TITAN_DIGGEREST_ID, "FragInfo")) then PlaySoundFile("Sound\\Creature\\YoggSaron\\UR_YoggSaron_PhaseTwo01.wav"); 
               DEFAULT_CHAT_FRAME:AddMessage("|cffea8df7I am the Lucid Dream...") end--ну надо же сюда чего-нить интересненького)...]]--
end
-- ОПОВЕЩЕНИЕ
function TitanDiggerReportTo(channel,target)
if (channel ~= nil) then
               SendChatMessage(L["race"].." "..L["printMSG2"],channel,nil,target)
 for i=1,12 do SendChatMessage(name[i]..": "..complCom[i].."/"..reqCom[i].."  "..complRar[i].."/"..reqRar[i].."  "..total[i],channel,nil,target) end
               SendChatMessage(L["total"]..totalComplCom.."/"..totalReqCom.."  "..totalComplRar.."/"..totalReqRar.."  "..totalArt,channel,nil,target)
end
end
------------------------------------------------------------------------
-- ТЕКСТ ПОДСКАЗКИ
------------------------------------------------------------------------
local fragm = '';
if TitanGetVar(TITAN_DIGGEREST_ID, "FragInfo") == 1 then fragm = e..L["frg"] end;

local _, _, skillLevel, maxSkillLevel = GetProfessionInfo(profArch);

 return 
 " \n"..w..L["race"].." \t"..w..L["cmn"]..b..L["rar"]..g..L["ttl"]..spacer[14]..fragm.."\n"
 ..ArtInfoFullTooltip[3].." \n"--Окаменелости
 ..ArtInfoFullTooltip[4].." \n"--Ночные Эльфы
 ..ArtInfoFullTooltip[1].." \n"--Дворфы
 ..ArtInfoFullTooltip[8].." \n"--Тролли
 ..ArtInfoFullTooltip[7].." \n"--Толвиры
 ..ArtInfoFullTooltip[2].." \n"--Дренеи
 ..ArtInfoFullTooltip[6].." \n"--Орки
 ..ArtInfoFullTooltip[5].." \n"--Нерубы
 ..ArtInfoFullTooltip[9].." \n"--Врайкулы
 ..ArtInfoFullTooltip[11].." \n"--Пандарены
 ..ArtInfoFullTooltip[12].." \n"--Могу
 ..ArtInfoFullTooltip[10].." \n"--Богомолы
 .." \n"
 ..L["total"].."\t"..w..totalComplCom.."/"..totalReqCom.."  "..b..totalComplRar.."/"..totalReqRar.."  "..g..totalArt.." \n"
 ..L["lastUniq"].."\t"..y..LastComlTime.." \n"
 .." \n"
 ..L["skill"].." \t"..w..skillLevel.."|r/"..w..maxSkillLevel

else return L["notLearned"] end
end

--********************************************************************
--***                        МЕНЮ                                  ***
--********************************************************************
function TitanPanelRightClickMenu_PrepareDiggerestMenu()
local info;
 if ( UIDROPDOWNMENU_MENU_LEVEL == 2 ) then
 
 if ( UIDROPDOWNMENU_MENU_VALUE == "report" ) then
    if IsInGuild() then
    info = {};
    info.notCheckable = true
   	info.text = "|cff00ff00"..L["Guild"]
    if UnitFactionGroup("player") == "Horde" then info.icon = "INTERFACE\\ICONS\\achievement_pvp_h_h" else info.icon = "INTERFACE\\ICONS\\achievement_pvp_a_a" end
    info.func = function() TitanDiggerReportTo("GUILD","GUILD")
    TitanPanelRightClickMenu_Close(1) end;
    UIDropDownMenu_AddButton(info,2); else end
    
    if UnitInRaid("player") then
    info = {};
    info.notCheckable = true
   	info.text = "|cffff8c00"..L["Raid"]
    info.icon = "INTERFACE\\ICONS\\inv_helmet_22"
    info.func = function() TitanDiggerReportTo("RAID","RAID") 
    TitanPanelRightClickMenu_Close(1) end;
    UIDropDownMenu_AddButton(info,2); else end
    
    if GetNumGroupMembers()>0 then
    info = {};
    info.notCheckable = true
   	info.text = "|cff00ffff"..L["Party"]
    info.icon = "INTERFACE\\ICONS\\spell_holy_championsbond"
    info.func = function() TitanDiggerReportTo("PARTY","PARTY") 
    TitanPanelRightClickMenu_Close(1) end;
    UIDropDownMenu_AddButton(info,2); else end

    info = {};
    info.notCheckable = true
   	info.text = "|cffffffff"..L["Say"]
    info.icon = "INTERFACE\\ICONS\\achievement_character_human_male"
    info.func = function() TitanDiggerReportTo("SAY","SAY") 
    TitanPanelRightClickMenu_Close(1) end;
    UIDropDownMenu_AddButton(info,2);

    info = {};
    info.notCheckable = true
   	info.text = "|cffff0000"..L["Yell"]
    info.icon = "INTERFACE\\ICONS\\ability_warrior_rallyingcry"
    info.func = function() TitanDiggerReportTo("YELL","YELL") 
    TitanPanelRightClickMenu_Close(1) end;
    UIDropDownMenu_AddButton(info,2);

    info = {};
    info.notCheckable = true
	info.text = "|cffff99ff"..L["Whisper"]
    info.icon = "INTERFACE\\ICONS\\spell_shadow_shadesofdarkness"
	info.func = function()
	StaticPopupDialogs["DiggerWDialog"] = {
    text    = L["SendMSG"], 
    button1 = L["Send"], 
    button2 = L["Cancel"],
	OnAccept = function(self) TitanDiggerReportTo("WHISPER",self.editBox:GetText()); end,
	timeout  = 45, 
    whileDead  = true, 
    hasEditBox = true, 
    enterClicksFirstButton = true, 
    hideOnEscape = true};
	StaticPopup_Show("DiggerWDialog"); 
    TitanPanelRightClickMenu_Close(1) end
    UIDropDownMenu_AddButton(info,2);
    
    if GetNumBattlefieldScores()>0 then
    info = {};
    info.notCheckable = true
   	info.text = "|cffffe4c4"..L["BG"]
    info.icon = "INTERFACE\\ICONS\\achievement_bg_winwsg"
    info.func = function() TitanDiggerReportTo("BATTLEGROUND","BATTLEGROUND") 
    TitanPanelRightClickMenu_Close(1) end;
    UIDropDownMenu_AddButton(info,2); else end

    local ChanList = {GetChannelList()}
	for i=1,getn(ChanList)/2 do
	info = {};
    info.notCheckable = true
	info.text = "|cffffe4c4"..ChanList[i*2-1]..". "..ChanList[i*2]
	info.func = function() TitanDiggerReportTo("CHANNEL",ChanList[i*2-1]) 
    TitanPanelRightClickMenu_Close(1) end
	UIDropDownMenu_AddButton(info,2); end
    end
    else
 
    TitanPanelRightClickMenu_AddTitle(L["menu"].."  |cffdcdcdcv"..TITAN_DIGGEREST_VERSION)
  
    local _,_,profArch = GetProfessions()
    
    info = {};
    info.notCheckable = true
   	info.text = L["Report"]
    info.value = "report"
     if not profArch then info.disabled = 1 end
     if profArch then info.hasArrow = 1 else end
    UIDropDownMenu_AddButton(info);
    
    info = {};
    info.notCheckable = true
   	info.text = L["print"]
    info.icon = "INTERFACE\\ICONS\\inv_misc_note_02"
    if not profArch then info.disabled = 1 end
    info.func = function() 
      TitanPanelDiggerestButton_OnUpdate()
      TitanPanelDiggerest_Print() end;
    UIDropDownMenu_AddButton(info);
   
    TitanPanelRightClickMenu_AddSpacer()
    
     info = {};
     info.text = L["frag"]
     info.checked = TitanGetVar(TITAN_DIGGEREST_ID, "FragInfo");
   --info.icon = "Interface\\Icons\\trade_archaeology_nerubian_artifactfragment"
     info.func = function() 
     TitanToggleVar(TITAN_DIGGEREST_ID, "FragInfo");
     TitanPanelPluginHandle_OnUpdate(updateTable);
     TitanPanelRightClickMenu_Close(1) end;
     UIDropDownMenu_AddButton(info);
 
  --TitanPanelRightClickMenu_AddSpacer()
 
    TitanPanelRightClickMenu_AddToggleIcon(TITAN_DIGGEREST_ID) 
    TitanPanelRightClickMenu_AddCommand(L["Hide"], TITAN_DIGGEREST_ID, TITAN_PANEL_MENU_FUNC_HIDE)
end end