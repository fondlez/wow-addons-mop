﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","koKR",false)
-- Translated by Gomntep
if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "장비를 전환" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "전리품 전문화를 전환" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "전문화를 전환" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "전문성과 장비 전환" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "장비" -- Needs review
L["TITAN_SPEC_HINT"] = "힌트 : 활성 사양 및 기어를 변경하려면 왼쪽 버튼을 클릭하십시오.\n     Shift + 만 사양을 변경하려면 왼쪽 버튼을 클릭하십시오.\n     Alt + 만 기어를 변경하려면 왼쪽 버튼을 클릭하십시오.\n     Ctrl + 전리품 전문화를 변경하려면 왼쪽 클릭." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "힌트를 표시" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "전체 이름을 표시" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "전문화 번호 만 표시" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "재능 빌드 표시" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "계층을 표시" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "인재 정보" -- Needs review

end
