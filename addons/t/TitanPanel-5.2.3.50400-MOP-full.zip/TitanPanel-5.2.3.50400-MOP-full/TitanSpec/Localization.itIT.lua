﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","itIT",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Cambiare Attrezzatura" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "Passare Bottino Specializzazione" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "Passare Specializzazione" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Passare Specializzazione e Attrezzature" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "Attrezzatura" -- Needs review
L["TITAN_SPEC_HINT"] = "Suggerimento: tasto sinistro del mouse per cambiare spec attiva e ingranaggi.\n     Maiusc + pulsante sinistro del mouse per cambiare solo spec.\n     Alt + click-sinistro per cambiare marcia solo.\n     Ctrl + click-sinistro per cambiare bottino specializzazione." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "Mostra Suggerimento" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Mostrare Nomi Completi" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Mostrare il Numero di Specializzazione Solo" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "Mostrare Talento Struttura" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Mostrare Fila" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Talento Informazioni" -- Needs review


end
