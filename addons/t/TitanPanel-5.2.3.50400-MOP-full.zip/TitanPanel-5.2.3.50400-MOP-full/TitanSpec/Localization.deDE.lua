﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","deDE",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Ausrüstungsset wechseln" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "Wechseln Beute Spezialisierung" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "Spezialisierung wechseln" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Spezialisierung und Ausrüstung wechseln" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "Ausrüstungsset"
L["TITAN_SPEC_HINT"] = "Tipp: Links-Klick um aktive Spezialisierung und Ausrüstung zu wechseln.\n     Shift + Links-Klick um nur die Spezialisierung zu wechseln.\n     Alt + Links-Klick um nur die Ausrüstung zu wechseln.\n     Ctrl + Links-Klick um beute spezialisierung ändern." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "Zeige Hinweis" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Zeigen Vollen Namen" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Zeigen Spezialisierung Zahl Nur" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "Zeigen Talent Gestalt" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Zeigen Rang" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Talentinfo"

end
