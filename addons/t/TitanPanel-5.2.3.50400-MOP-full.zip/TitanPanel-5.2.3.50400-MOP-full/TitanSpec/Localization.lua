﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","enUS",true)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Switch Gear"
L["TITAN_SPEC_BINDINGS_SPEC"] = "Switch Spec"
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Switch Spec and Gear"
L["TITAN_SPEC_GEAR_SET"] = "Gear Set"
L["TITAN_SPEC_HINT"] = "Hint: Left-click to change active spec and gear.\n     Shift + left-click to change only spec.\n     Alt + left-click to change only gear.\n     Ctrl + left-click to change loot spec."
L["TITAN_SPEC_SHOW_HINT"] = "Show Hint"
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Show Full Names"
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Show Spec Number Only"
L["TITAN_SPEC_SHOW_TALENTS"] = "Show Talent Build"
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Show Tier %s"
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Talent Info"
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "Switch Loot Spec"
end
