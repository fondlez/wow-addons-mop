--[[
	TitanIronpawToken: A simple Display of current Conquest value as a percent
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Ironpaw Token|r"
local buttonlabel = "Ironpaw: "
local ID = "IP"
local elap, IP, prevIP = 0, 0.0, -2
local GetUnitIP = 0 




-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelIPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanIronpawToken" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0
	local myicon = ""
	
	if UnitFactionGroup("Player") == "Horde" then
		myicon = "Interface\\Icons\\inv_relics_idolofferocity.blp"
	else
		myicon = "Interface\\Icons\\inv_relics_idolofferocity.blp"
	end
 


	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelIPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelIPButton_GetTooltipText",
		frequency = 2,
		icon = myicon,
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		
		
		
		-- "none" when outside an instance
        -- "pvp" when in a battleground
        -- "arena" when in an arena
        -- "party" when in a 5-man instance
        -- "raid" when in a raid instance 


		for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)
			if name == "Ironpaw Token" then
				CurrencyIndex = i
			end
			--print(name)
			--Honor Points
			--Conquest Points
			--Valor Points
			--Justice Points
		end
		
		name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(CurrencyIndex)
 
		 local inInstance, instanceType = IsInInstance()
		--if inInstance and instanceType == "pvp"  then
		if GetNumSubgroupMembers() > 0 then
			if instanceStarted == 0 then
				startVal = count		
				--print("new group")
			end
			instanceStarted = 1
		else
			instanceStarted = 0
		end

		 IP = count
		
		
		if IP == prevIP then return end
		prevIP  = IP
		 
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelIPButton_GetButtonText()
----------------------------------------------
	local IPtext, pitchtext
	if not IP then
		IPtext = "??"
	else	
		if startVal == count or startVal == 0 then
			IPtext = string.format("%.0f", IP) .."" 
		else
			if IP - startVal == 0 then
				IPtext = string.format("%.0f", IP) .."" 
			else
				IPtext = string.format("%.0f", IP) .." (+".. IP - startVal..")"
	end
			
   end
	end
	return buttonlabel, IPtext
end

-----------------------------------------------
function TitanPanelIPButton_GetTooltipText()
-----------------------------------------------


	return "Displays your current Ironpaw Tokens "
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareIPMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end