-- default strings
TITAN_RECAP_BUTTON_LABEL = "DPS: ";
TITAN_RECAP_BUTTON_NO_LABEL = " ";
TITAN_RECAP_BUTTON_SHOWDPS = "Show your DPS";
TITAN_RECAP_BUTTON_SHOWHPS = "Show your HPS";
TITAN_RECAP_BUTTON_SHOW_PET_PERCENT = "Show your Pet Percent";
TITAN_RECAP_BUTTON_SHOWMAXHIT_TEXT = "Show your Max Hit";
TITAN_RECAP_BUTTON_SHOWDPS_OUT = "Show group DPS out";
TITAN_RECAP_BUTTON_SHOWDPS_IN = "Show group DPS in";
TITAN_RECAP_BUTTON_SHOWHEALING_TEXT = "Show your Healing";
TITAN_RECAP_BUTTON_SHOWOVERHEAL_TEXT = "Show your Overhealing %";
TITAN_RECAP_BUTTON_HINT_TEXT = "Hint: Left-click to toggle Recap";
TITAN_RECAP_BUTTON_PAUSE_TEXT = "Pause Monitoring";
TITAN_RECAP_BUTTON_START_TEXT = "Resume Monitoring";
--tooltip labels
TITAN_RECAP_TOOLTIP_DPS = "Your DPS: ";
TITAN_RECAP_TOOLTIP_HPS = "Your HPS: ";
TITAN_RECAP_TOOLTIP_PET_PERCENT = "Your Pet Percent: ";
TITAN_RECAP_TOOLTIP_MAXHIT = "Your Max Hit: ";
TITAN_RECAP_TOOLTIP_TOTALDPS_OUT = "Total DPS Out: ";
TITAN_RECAP_TOOLTIP_TOTALDPS_IN = "Total DPS In: ";
TITAN_RECAP_TOOLTIP_HEALING = "Your Healing: ";
TITAN_RECAP_TOOLTIP_OVERHEAL = "Your Overhealing %: "

if ( GetLocale() == "deDE" ) then
	-- need localization
	TITAN_RECAP_BUTTON_SHOWDPS = "Show your DPS";
	TITAN_RECAP_BUTTON_SHOWHPS = "Show your HPS";
	TITAN_RECAP_BUTTON_SHOW_PET_PERCENT = "Show your Pet Percent";
	TITAN_RECAP_BUTTON_SHOWMAXHIT_TEXT = "Show your Max Hit";
	TITAN_RECAP_BUTTON_SHOWDPS_OUT = "Show group DPS out";
	TITAN_RECAP_BUTTON_SHOWDPS_IN = "Show group DPS in";
	TITAN_RECAP_BUTTON_SHOWHEALING_TEXT = "Show your Healing";
	TITAN_RECAP_BUTTON_SHOWOVERHEAL_TEXT = "Show your Overhealing %";
	TITAN_RECAP_BUTTON_HINT_TEXT = "Hint: Left-click to toggle Recap";
	TITAN_RECAP_BUTTON_PAUSE_TEXT = "Pause Monitoring";
	TITAN_RECAP_BUTTON_START_TEXT = "Resume Monitoring";
	--tooltip labels	
	TITAN_RECAP_TOOLTIP_DPS = "Your DPS: ";
	TITAN_RECAP_TOOLTIP_HPS = "Your HPS: ";
	TITAN_RECAP_TOOLTIP_PET_PERCENT = "Your Pet Percent: ";
	TITAN_RECAP_TOOLTIP_MAXHIT = "Your Max Hit: ";
	TITAN_RECAP_TOOLTIP_TOTALDPS_OUT = "Total DPS Out: ";
	TITAN_RECAP_TOOLTIP_TOTALDPS_IN = "Total DPS In: ";
	TITAN_RECAP_TOOLTIP_HEALING = "Your Healing: ";
	TITAN_RECAP_TOOLTIP_OVERHEAL = "Your Overhealing %: "		
end

-- French by Feu
if ( GetLocale() == "frFR" ) then
	TITAN_RECAP_BUTTON_SHOWDPS = "Montrer les DPS";
	TITAN_RECAP_BUTTON_SHOWHPS = "Montrer les HPS";
	TITAN_RECAP_BUTTON_SHOW_PET_PERCENT = "Show votre Pet Percent";
	TITAN_RECAP_BUTTON_SHOWMAXHIT_TEXT = "Montrer votre Max Hit";
	TITAN_RECAP_BUTTON_SHOWDPS_OUT = "Montrer les DPS faits";
	TITAN_RECAP_BUTTON_SHOWDPS_IN = "Montrer les DPS re/195/167us";
	TITAN_RECAP_BUTTON_SHOWHEALING_TEXT = "Montrer votre Healing";
	TITAN_RECAP_BUTTON_SHOWOVERHEAL_TEXT = "Montrer votre Overhealing %";
	TITAN_RECAP_BUTTON_HINT_TEXT = "Conseil : clic-gauche pour afficher/cacher Recap";
	TITAN_RECAP_BUTTON_PAUSE_TEXT = "Mettre en pause";
	TITAN_RECAP_BUTTON_START_TEXT = "Reprendre";
	--tooltip labels	
	TITAN_RECAP_TOOLTIP_DPS = "Votre DPS: ";
	TITAN_RECAP_TOOLTIP_HPS = "Votre HPS: ";
	TITAN_RECAP_TOOLTIP_PET_PERCENT = "Votre Pet Percent: ";
	TITAN_RECAP_TOOLTIP_MAXHIT = "Votre Max Hit: ";
	TITAN_RECAP_TOOLTIP_TOTALDPS_OUT = "Total DPS Out: ";
	TITAN_RECAP_TOOLTIP_TOTALDPS_IN = "Total DPS In: ";
	TITAN_RECAP_TOOLTIP_HEALING = "Votre Healing: ";
	TITAN_RECAP_TOOLTIP_OVERHEAL = "Votre Overhealing %: "					 		
end