--[[
	TitanSP: A simple Display of current SP value
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Spell Power|r"
local buttonlabel = "SP: "
local ID = "SP"
local elap, SP, prevSP = 0, 0, -2
local GetUnitSP = 0 

--local base, posBuff, negBuff = UnitSpellPower("player");
--local effective = base + posBuff + negBuff;


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelSPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanSP" then 
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelSPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelSPButton_GetTooltipText",
		frequency = 0.5,
		icon = "Interface\\Icons\\Inv_qiraj_jewelblessed.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		local base = GetSpellBonusDamage(2);
local effective = base ;

		SP = effective -- fix
		if SP == prevSP then return end
		prevSP  = SP
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end

function TitanPanelSPButton_GetButtonText()
	local SPtext, pitchtext
	if not SP then
		SPtext = "??"
	else
		SPtext = SP 
	end
	return buttonlabel, SPtext
end

function TitanPanelSPButton_GetTooltipText()
	return "Displays your current Spell Power value"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end

function TitanPanelRightClickMenu_PrepareSPMenu()
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end