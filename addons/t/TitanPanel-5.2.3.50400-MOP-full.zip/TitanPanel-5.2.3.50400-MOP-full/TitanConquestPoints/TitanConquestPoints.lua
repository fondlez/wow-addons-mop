--[[
	TitanConquest: A simple Display of current Conquest value as a percent
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Conquest Points|r"
local buttonlabel = "Conquest: "
local ID = "CP"
local elap, CP, prevCP = 0, 0.0, -2
local GetUnitCP = 0 
local CPw




-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelCPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanConquestPoints" then -- needs to be the name of the folder that the addon is in
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	local name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown
	local i = 0
	local CurrencyIndex = 0
	local myicon = ""
	local mycheck = ""
	
	if UnitFactionGroup("Player") == "Horde" then
		myicon = "Interface\\Icons\\pvpcurrency-conquest-horde.blp"		
		mycheck = "Interface\\Icons\\PVPCurrency-Conquest-Horde"
	else
		myicon = "Interface\\Icons\\pvpcurrency-conquest-alliance.blp"
		mycheck ="Interface\\Icons\\PVPCurrency-Conquest-Alliance"
	end
 


	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelCPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelCPButton_GetTooltipText",
		frequency = 2,
		icon = myicon,
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		
		
		
		-- "none" when outside an instance
        -- "pvp" when in a battleground
        -- "arena" when in an arena
        -- "party" when in a 5-man instance
        -- "raid" when in a raid instance 


		for i = 1, GetCurrencyListSize(), 1 do
			 name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(i)
			--if name == "Conquest Points" then
			if icon == mycheck then
				CurrencyIndex = i
			end
			--print(name)
			--Honor Points
			--Conquest Points
			--Valor Points
			--Justice Points
		end
		
		name, isHeader, isExpanded, isUnused, isWatched, count, icon, maximum, hasWeeklyLimit, currentWeeklyAmount, unknown = GetCurrencyListInfo(CurrencyIndex)
 
		 local inInstance, instanceType = IsInInstance()
		--if inInstance and instanceType == "pvp"  then
		if GetNumSubgroupMembers() > 0 then
			if instanceStarted == 0 then
				startVal = count		
				--print("new group")
			end
			instanceStarted = 1
		else
			instanceStarted = 0
		end

		 CP = count
		CPw =  maximum /100
		
		if CP == prevCP then return end
		prevCP  = CP
		 
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end



----------------------------------------------
function TitanPanelCPButton_GetButtonText()
----------------------------------------------
	local CPtext, pitchtext
	if not CP then
		CPtext = "??"
	else	
		if startVal == count or startVal == 0 then
			CPtext = string.format("%.0f", CP) .."" 
		else
			if CP - startVal == 0 then
				CPtext = string.format("%.0f", CP) .."" 
			else
				CPtext = string.format("%.0f", CP) .." (+".. CP - startVal..")"
	end
			
   end
	end
	return buttonlabel, CPtext
end

-----------------------------------------------
function TitanPanelCPButton_GetTooltipText()
-----------------------------------------------

return "Total Conquest Points:\t"..CP
	--return "Displays your current Conquest Points "
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareCPMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end