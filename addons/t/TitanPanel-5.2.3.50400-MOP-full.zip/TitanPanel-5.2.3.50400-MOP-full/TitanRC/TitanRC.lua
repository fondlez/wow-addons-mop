--[[
	TitanRC: A simple Display of current RC value
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Ranged Crit|r"
local buttonlabel = "Crit: "
local ID = "RC"
local elap, RC, prevRC = 0, 0.0, -2
local GetUnitRC = 0 

local base, posBuff, negBuff = UnitAttackPower("player");
local effective = base + posBuff + negBuff;


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelRCButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanRC" then 
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelRCButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelRCButton_GetTooltipText",
		frequency = 0.5,
		icon = "Interface\\Icons\\Ability_rogue_feigndeath.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end

		
	
		RC = GetRangedCritChance(); -- fix
		if RC == prevRC then return end
		prevRC  = RC
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end

----------------------------------------------
function TitanPanelRCButton_GetButtonText()
----------------------------------------------
	local RCtext, pitchtext
	if not RC then
		RCtext = "??"
	else
	
		RCtext = string.format("%.2f", RC) .."%" 
	end
	return buttonlabel, RCtext
end

-----------------------------------------------
function TitanPanelRCButton_GetTooltipText()
-----------------------------------------------
	return "Displays your current Ranged Crit value"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareRCMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end