--[[
	Description: Titan plug-in to display professions skill level
	Author: Subwired
--]]

local ProfName = "Cooking"
local menutext = "Titan|cC79C6E00 "..ProfName.."|r"
local buttonlabel = ProfName..": "
local ID = "CO"
local elap, CO, prevCO = 0, 0.0, -2
local COmax, prevCOmax = 0, 0



-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelCOButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")

f:SetScript("OnClick", function(self, button, down)
local prof = ProfName
if prof == "Mining" then prof = "Smelting" end
CastSpellByName(prof)
end)

function f:ADDON_LOADED(a1)

--print ("a1 = " .. a1)
	if a1 ~= "TitanCooking" then 
		return 
	end
	
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelCOButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelCOButton_GetTooltipText",
		frequency = 1,
		icon = "Interface\\Icons\\Inv_misc_food_15.blp",
		iconWidth = 16,
		category = "Profession",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end

		--local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions();
		--local name, icon, skillLevel, maxSkillLevel, numAbilities, spelloffset, skillLine, skillModifier = GetProfessionInfo(index)
			
		local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions();
		
		if cooking ~= nil then
			local name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(cooking)
			CO = skillLevel
			COmax = maxSkillLevel
			
			if CO == prevCO and prevCOmax == COmax then 
				return 
			end
			
			prevCOmax = COmax
			prevCO  = CO
			TitanPanelButton_UpdateButton(ID)
			elap = 0
		end
	end)
		
	--TitanPanelButton_OnLoad(self)
end

----------------------------------------------
function TitanPanelCOButton_GetButtonText()
----------------------------------------------
	local COtext, pitchtext
	if not CO then
		COtext = "??"
	else
	
		COtext = CO .."/"..COmax--string.format("%.0f", CO)  
	end
	return buttonlabel, COtext
end

-----------------------------------------------
function TitanPanelCOButton_GetTooltipText()
-----------------------------------------------
	return "Displays your current "..ProfName.." Skill level"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareCOMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end