local L = LibStub("AceLocale-3.0"):NewLocale("Titan","deDE")
if not L then return end

-- German by El Rico on Curse Gaming --
L["TITAN_DEFENSE_STRINGS_MODNAME"] = "Titan Panel [Verteidigung]";
L["TITAN_DEFENSE_STRINGS_MODDESC"] = "Verteidigungs Tracker plugin f\195\188r Titan Panel";
L["TITAN_DEFENSE_STRINGS_BARFRAMENAME"] = "TitanPanelVerteidigungSchaltfl\195\164che";
L["TITAN_DEFENSE_STRINGS_MENUTEXT"] = "Verteidigungs Tracker";
L["TITAN_DEFENSE_STRINGS_TOOLTIP"] = "Verteidigungs Tracker";
L["TITAN_DEFENSE_STRINGS_NEWZONE1"] = "Verteidigungs-Tracker: Neue Subzone gefunden ";
L["TITAN_DEFENSE_STRINGS_NEWZONE2"] = ", �berpr�fe die SavedVariables.lua und uploade den TitanDefense_newSubzones Variablen Block ins addons@goldshire.com!";
L["TITAN_DEFENSE_STRINGS_WDCHANNAME"] = "WeltVerteidigung";
L["TITAN_DEFENSE_STRINGS_LDCHANNAME"] = "LokaleVerteidigung";
L["TITAN_DEFENSE_STRINGS_ATTACKTEXT"] = "1 Angriff";
L["TITAN_DEFENSE_STRINGS_ATTACKSTEXT"] = " Angriffe";
L["TITAN_DEFENSE_STRINGS_NOATTACKS"] = "Kein Angriff";
L["TITAN_DEFENSE_STRINGS_SECONDS"] = " sek";
L["TITAN_DEFENSE_STRINGS_MINUTES"] = " min";
L["TITAN_DEFENSE_STRINGS_HOUR"] = " Stunde";
L["TITAN_DEFENSE_STRINGS_SZTIMETITLE"] = "Zuletzt angegriffene Subzonen"
L["TITAN_DEFENSE_STRINGS_ZTIMETITLE"] = "Zuletzt angegriffene Zonen";
L["TITAN_DEFENSE_STRINGS_SZFRQTITLE"] = "Am h�ufigsten angegriffene Subzonen";
L["TITAN_DEFENSE_STRINGS_ZFRQTITLE"] = "Am h�ufigsten angegriffene Zonen";
L["TITAN_DEFENSE_STRINGS_LOCALHEADER"] = "|cffff0000Lokal|r: ";
L["TITAN_DEFENSE_STRINGS_AGOENDER"] = " vor�ber";
L["TITAN_DEFENSE_STRINGS_UNKNOWNZONE"] = "Unbekannte Zone";     
