-- Titan Panel support

FB_Titan = {};

FB_Titan.OnLoad = function(self)
   if not TitanPanelButton_UpdateButton then
      return;
   end

   self.registry = {
      id = FBConstants.ID,
      menuText = FBConstants.NAME,
      version = FBConstants.VERSION,
      category = "Profession",
      icon = "Interface\\AddOns\\FishingBuddy\\Icons\\Fishing-Icon",
      iconWidth = 16,
      tooltipTitle = FBConstants.NAME,
      tooltipTextFunction = "TitanPanelFishingBuddyButton_GetTooltipText",
      savedVariables = {
	     ShowIcon = 1,
      }
   };	

   self:RegisterEvent("PLAYER_ENTERING_WORLD");
   tinsert(TITAN_PANEL_NONMOVABLE_PLUGINS, FBConstants.ID);
end

FB_Titan.OnClick = function(self, button)
	if ( button == "LeftButton" ) then
		if ( FishingBuddy.IsSwitchClick() ) then
			FishingBuddy.Command(FBConstants.SWITCH);
		else
			FishingBuddy.Command("");
		end
	end
end

FB_Titan.OnEvent = function(self, event, ...)
   if TitanPanelButton_UpdateButton then
      TitanPanelButton_UpdateButton(FBConstants.ID);	
      TitanPanelButton_UpdateTooltip();
   end
end

function TitanPanelFishingBuddyButton_GetTooltipText()
   return FishingBuddy.TooltipBody("ClickToSwitch");
end

function TitanPanelRightClickMenu_PrepareFishingBuddyMenu(frame, level, menuList)
	local ID = FBConstants.ID;
	if (level == 1) then
		TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText);
	end

	if (FishingBuddy.DropDownInitFunc) then
		frame.switchText = FBConstants.CLICKTOSWITCH_ONOFF
		frame.switchSetting = "ClickToSwitch"
		FishingBuddy.DropDownInitFunc(frame, level)

		if (level == 1) then
			TitanPanelRightClickMenu_AddSpacer()
			TitanPanelRightClickMenu_AddToggleIcon(ID, level)
			TitanPanelRightClickMenu_AddToggleLabelText(ID, level)
			TitanPanelRightClickMenu_AddToggleVar("Show Item Name", ID, "ShowItem", nil, level)
			TitanPanelRightClickMenu_AddSpacer()
			if (FishingBuddy.Debugging) then
				TitanPanelRightClickMenu_AddToggleVar("Debug", ID, "debug", nil, level)
			end
			TitanPanelRightClickMenu_AddCommand("Hide", ID, TITAN_PANEL_MENU_FUNC_HIDE, level)
		end
	else
		FishingBuddy.MakeDropDown(FBConstants.CLICKTOSWITCH_ONOFF, "ClickToSwitch");

		TitanPanelRightClickMenu_AddSpacer();
		TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE,
										 FBConstants.ID,
										 TITAN_PANEL_MENU_FUNC_HIDE);
	end
end

