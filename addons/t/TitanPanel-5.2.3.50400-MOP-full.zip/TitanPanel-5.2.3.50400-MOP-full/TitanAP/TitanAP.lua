--[[
	TitanAP: A simple Display of current AP value
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Melee Attack Power|r"
local buttonlabel = "AP: "
local ID = "AP"
local elap, AP, prevAP = 0, 0, -2
local GetUnitAP = 0 



-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelAPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanAP" then 
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelAPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelAPButton_GetTooltipText",
		frequency = 0.5,
		icon = "Interface\\Icons\\Ability_warrior_battleshout.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		local base, posBuff, negBuff = UnitAttackPower("player");
		local effective = base + posBuff + negBuff;

		AP = effective -- fix
		if AP == prevAP then return end
		prevAP  = AP
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end

----------------------------------------------
function TitanPanelAPButton_GetButtonText()
----------------------------------------------
	local APtext, pitchtext
	if not AP then
		APtext = "??"
	else
		APtext = AP 
	end
	return buttonlabel, APtext
end

-----------------------------------------------
function TitanPanelAPButton_GetTooltipText()
-----------------------------------------------
	return "Displays your current Melee Attack Power value"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareAPMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end