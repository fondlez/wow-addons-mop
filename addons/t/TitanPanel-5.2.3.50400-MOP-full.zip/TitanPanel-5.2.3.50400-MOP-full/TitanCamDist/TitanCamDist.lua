﻿--[[                  
 TITAN PANEL: CAMERA DISTANCE
 Описание: CameraDistance - плагин для TitanPanel, с помощью которого можно устанавливать максимальную дистанцию обзора камеры: от  0 метров (вид от первого лица) до 50 метров (и изменять некоторые Опции Камеры)

 Автор: Вишмастер (RU-Термоштепсель)
  Мыло: Wish1250@gmail.com
Создан: 9.06.2010
 Языки: RU,EN
]]--
local VERSION = "2.5"
local ID = "CamDist"
local updateTable = {ID, TITAN_PANEL_UPDATE_ALL};
local L = LibStub("AceLocale-3.0"):GetLocale("TitanCamDist", true)
local AceTimer = LibStub("AceTimer-3.0")
local camTimer = nil;
------------------------------------------------------------------------
function TitanPanelCamDistButton_OnLoad(self)
	self.registry = {
		id = ID,
		category = "Interface",
        version = VERSION,
		menuText = L["TITLE"],
		buttonTextFunction = "TitanPanelCamDist_GetButtonText",
        tooltipTitle = L["TITLE"],
        tooltipTextFunction = "TitanPanelCamDist_GetTooltipText",
		icon = "Interface\\Icons\\Ability_Hunter_MarkedForDeath",
		iconWidth = 15,
		savedVariables = {
		    ShowIcon = true,
            ShowLabelText = true,
            CameraAutoZoom = true,
			}}; 
DEFAULT_CHAT_FRAME:AddMessage(L["About"], 1, 1, 1)
end
--Автообновление
function TitanPanelCamDistButton_OnShow()
if not camTimer then camTimer = AceTimer.ScheduleRepeatingTimer("TitanPanelCamDist", TitanPanelCamDistButton_OnUpdate, 1) end
end
function TitanPanelCamDistButton_OnHide()
AceTimer.CancelTimer("TitanPanelCamDist", camTimer, true)
camTimer = nil
end
function TitanPanelCamDistButton_OnUpdate(self) 
TitanPanelPluginHandle_OnUpdate(updateTable)
end
------------------------------------------------------------------------
-- ФУНКЦИИ
------------------------------------------------------------------------
--Отдаление/приближение камеры
function TitanPanelCamDistButton_OnClick(self, button)
if (button == "LeftButton") and (IsAltKeyDown() or IsControlKeyDown() or IsShiftKeyDown()) then CameraZoomIn(50)
elseif (button == "LeftButton") then CameraZoomOut(50) end
end
--Кнопка
function TitanPanelCamDist_GetButtonText()
return --[["|cffffffff"..]]L["BUTTON"],"|cff00ff00"..floor(GetCVar("cameraDistanceMax"))
end
--Подсказка
function TitanPanelCamDist_GetTooltipText()
return L["TOOLTIP1"].." \n".." \n"
                    .."|cffffffff"..L["BUTTON"].."\t|cff00ff00"..floor(GetCVar("cameraDistanceMax")).."|cffffffff"..L["M"]
                    .."\n".."|cffffffff"..L["MOVE"]..":\t|cffffffffx|cff00ff00"..floor(GetCVar("cameraDistanceMoveSpeed")/10).."|cffffffff"
                    .."\n".."|cffffffff"..L["YAW"] ..":\t|cff00ff00"..floor(GetCVar("cameraYawMoveSpeed")).."|cffffffff%\n"
                    .." \n"
                    ..L["TOOLTIP2"]
end

-- Автоизм. дистанции
local function CamDistAutoZoom()
TitanToggleVar(ID, "CameraAutoZoom");
MoveViewOutStop()
TitanPanelPluginHandle_OnUpdate(updateTable)
end

--сообщение
local function MSG(msg)
DEFAULT_CHAT_FRAME:AddMessage(msg)
end
------------------------------------------------------------------------
-- МЕНЮ
------------------------------------------------------------------------
function TitanPanelRightClickMenu_PrepareCamDistMenu()
local info;
------------------------------------------------------------------------
-- 3й УРОВЕНЬ
------------------------------------------------------------------------
        -- Меню 3 уровня, ОПЦИИ
        if ( UIDROPDOWNMENU_MENU_LEVEL == 3 ) then
        
        -- Cкорость прокуртки (1-45)
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOptMove" ) then
        for i=1,8 do
        info = {};
        --info.notCheckable = true
		info.text = "x|cff00ff00"..(i/2).."|r"
        info.func = function() 
        SetCVar("cameraDistanceMoveSpeed",i*5)
        MSG(L["TITAN"]..L["MOVE"]..": |cff00ff00"..(i*5).."|r") end
        if floor(GetCVar("cameraDistanceMoveSpeed")) == i*5 then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,3) end
        end
        
        -- Скорость поворота (1-360)
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOptYaw" ) then
        for i=1,6 do
        info = {};
        --info.notCheckable = true
        info.text = "|cff00ff00"..(i*60).."|r%"
        info.func = function() 
        SetCVar("cameraYawMoveSpeed",i*60)
        MSG(L["TITAN"]..L["YAW"]..": |cff00ff00"..(i*60).."|r%")
        end
        if floor(GetCVar("cameraYawMoveSpeed")) == (i*60) then info.checked = 1 end;
        UIDropDownMenu_AddButton(info,3)
        end end
        
        -- Выравнивание (0-никогда,2-всегда,4-только при движении,3-горизонт.,1-горизонт. при движении,5-горизонт. мгновенное)
        if  ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOptSmooth" ) then
         local num={2,0,4,3,5,1}
         for i=1,#num do
          info = {};
          --info.notCheckable = true
		  info.text = (L["SMOOTH_"..num[i]])
          info.func = function() SetCVar("cameraSmoothStyle",num[i]) MSG(L["TITAN"]..L["SMOOTH"]..": "..L["SMOOTH_"..num[i]]) end;
          if floor(GetCVar("cameraSmoothStyle")) == num[i] then info.checked = 1 end;
		  UIDropDownMenu_AddButton(info,3)
         end
        end 
        
        -- Брызги воды
        if  ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOptWColl" ) then
        info = {};
        --info.notCheckable = true
		info.text = ("|cff00ffff"..L["ON"])
        info.func = function() SetCVar("cameraWaterCollision",1) MSG(L["TITAN"]..L["WCOLL"]..": "..L["ON"]) end;
        if floor(GetCVar("cameraWaterCollision")) == 1 then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,3)
        
        info = {};
        --info.notCheckable = true
		info.text = (L["OFF"])
        info.func = function() SetCVar("cameraWaterCollision",0) MSG(L["TITAN"]..L["WCOLL"]..": "..L["OFF"]) end;
        if floor(GetCVar("cameraWaterCollision")) == 0 then info.checked = 0 end;
		UIDropDownMenu_AddButton(info,3)
        end
        
        -- Следование рельефу
        if  ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOptTerTilt" ) then
        info = {};
        --info.notCheckable = true
		info.text = (L["ON"])
        info.func = function() SetCVar("cameraTerrainTilt",1) MSG(L["TITAN"]..L["TERTILT"]..": "..L["ON"]) end;
        if floor(GetCVar("cameraTerrainTilt")) == 1 then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,3)
        
        info = {};
        --info.notCheckable = true
		info.text = (L["OFF"])
        info.func = function() SetCVar("cameraTerrainTilt",0) MSG(L["TITAN"]..L["BOBBING"]..": "..L["OFF"]) end;
        if floor(GetCVar("cameraTerrainTilt")) == 0 then info.checked = 0 end;
		UIDropDownMenu_AddButton(info,3)
        end
        
        -- Покачивание головы
        if  ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOptBobbing" ) then
        info = {};
        --info.notCheckable = true
		info.text = (L["ON"])
        info.func = function() SetCVar("cameraBobbing",1) MSG(L["TITAN"]..L["BOBBING"]..": "..L["ON"]) end;
        if floor(GetCVar("cameraBobbing")) == 1 then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,3)
        
        info = {};
        --info.notCheckable = true
		info.text = (L["OFF"])
        info.func = function() SetCVar("cameraBobbing",0) MSG(L["TITAN"]..L["BOBBING"]..": "..L["OFF"]) end;
        if floor(GetCVar("cameraBobbing")) == 0 then info.checked = 0 end;
		UIDropDownMenu_AddButton(info,3)
        end
------------------------------------------------------------------------
-- 2й УРОВЕНЬ
------------------------------------------------------------------------ 
        -- Меню 2го уровня,ДИСТАНЦИИ
        elseif ( UIDROPDOWNMENU_MENU_LEVEL == 2 ) then   
        -- 2й ур., Дистанции 1-9 
		if ( UIDROPDOWNMENU_MENU_VALUE == "CamDist0" ) then
        for i=1,9 do
        info = {};
        --info.notCheckable = true
		info.text = ("|cff00ff00"..i.."|r"..L["METER"].."")
        info.func = function() 
        SetCVar("cameraDistanceMaxFactor",1)
        SetCVar("cameraDistanceMax",i)
        TitanPanelRightClickMenu_Close(1);
        if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(0.5) end end;
        if floor(GetCVar("cameraDistanceMax"))== i then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,2)
        end
        end

        -- 2й ур., Дистанции 11-19  
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDist10" ) then
        for i=11,19 do
        info = {};
        --info.notCheckable = true
		info.text = ("|cff00ff00"..i.."|r"..L["METER"].."")
        info.func = function() 
        SetCVar("cameraDistanceMaxFactor",1)
        SetCVar("cameraDistanceMax",i)
        TitanPanelRightClickMenu_Close(1);
        if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(1) end end;
        if floor(GetCVar("cameraDistanceMax"))== i then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,2)
        end 
        end
   
        -- 2й ур., Дистанции 21-29          
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDist20" ) then
		for i=21,29 do
        info = {};
        --info.notCheckable = true
		info.text = ("|cff00ff00"..i.."|r"..L["METER"].."")
        info.func = function() 
        SetCVar("cameraDistanceMaxFactor",1)
        SetCVar("cameraDistanceMax",i)
        TitanPanelRightClickMenu_Close(1);
        if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(1.5) end end;
        if floor(GetCVar("cameraDistanceMax"))== i then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,2)
        end
        end
        
        -- 2й ур., Дистанции 31-39         
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDist30" ) then
        for i=31,39 do
        info = {};
        --info.notCheckable = true
		info.text = ("|cff00ff00"..i.."|r"..L["METER"].."")
        info.func = function() 
        SetCVar("cameraDistanceMaxFactor",1)
        SetCVar("cameraDistanceMax",i)
        TitanPanelRightClickMenu_Close(1);
        if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(2) end end;
        if floor(GetCVar("cameraDistanceMax"))== i then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,2)
        end
        end
        
        -- 2й ур., Дистанции 41-49         
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDist40" ) then
        for i=41,49 do
        info = {};
        --info.notCheckable = true
		info.text = ("|cff00ff00"..i.."|r"..L["METER"].."")
        info.func = function() 
        SetCVar("cameraDistanceMaxFactor",1)
        SetCVar("cameraDistanceMax",i)
        TitanPanelRightClickMenu_Close(1);
        if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(2.5) end end;
        if floor(GetCVar("cameraDistanceMax"))== i then info.checked = 1 end;
		UIDropDownMenu_AddButton(info,2)
        end
        end 
          
        -- Меню 2го уровня, ОПЦИИ КАМЕРЫ
        if ( UIDROPDOWNMENU_MENU_VALUE == "CamDistOpt" ) then
        -- 2й ур., "Выравнивание камеры"
        info = {};
        info.notCheckable = true
		info.text = L["OPT_SMOOTH"]
        info.value = "CamDistOptSmooth"
        info.hasArrow = 1;
		UIDropDownMenu_AddButton(info,2)
        
        --2й ур., "Скорость прокуртки камеры" 
        info = {};
        info.notCheckable = true
		info.text = L["MOVE"]
        info.value = "CamDistOptMove"
        info.hasArrow = 1;
		UIDropDownMenu_AddButton(info,2)
        
        -- 2й ур., "Скорость поворота камеры"
        info = {};
        info.notCheckable = true
		info.text = L["YAW"]
        info.value = "CamDistOptYaw"
        info.hasArrow = 1;
		UIDropDownMenu_AddButton(info,2)
        
        -- 2й ур., "Брызги воды"
        info = {};
        info.notCheckable = true
		info.text = L["WCOLL"]
        info.value = "CamDistOptWColl"
        info.hasArrow = 1;
		UIDropDownMenu_AddButton(info,2)
        
        -- 2й ур., Покачивание
        info = {};
        info.notCheckable = true
		info.text = L["BOBBING"] 
        info.value = "CamDistOptBobbing"
        info.hasArrow = 1;
		UIDropDownMenu_AddButton(info,2)
        
        -- 2й ур., Следование рельефу
        info = {};
        info.notCheckable = true
		info.text = L["TERTILT"]
        info.value = "CamDistOptTerTilt"
        info.hasArrow = 1;
		UIDropDownMenu_AddButton(info,2) 
        
        -- 2й ур., пустая строка
        TitanPanelRightClickMenu_AddSpacer(2)
        
        -- 2й ур., Сброс в стандарт
        info = {};
        info.notCheckable = true
		info.text = L["RESET"]
        --info.hasArrow = 1;
        info.func = function()
           TitanPanelRightClickMenu_Close(1);
           StaticPopupDialogs["TCamDistResetDialog"] = {
           text    = L["RES_QST"],
           button1 = L["RES_ACP"], button2 = L["Cancel"],
	       OnAccept = function(self)
             SetCVar("cameraYawMoveSpeed",200) 
             SetCVar("cameraSmoothStyle",4) 
             SetCVar("cameraDistanceMoveSpeed",10) 
             SetCVar("cameraBobbing",0) 
             SetCVar("cameraTerrainTilt",0) 
             SetCVar("cameraWaterCollision",1) 
             SetCVar("cameraDistanceMax",15) 
             MoveViewOutStart(1)
             MSG(L["TITAN"]..L["RES_MSG"])
             TitanPanelRightClickMenu_Close(1) 
             TitanPanelPluginHandle_OnUpdate(updateTable)
           end,
	       timeout  = 30, whileDead  = true, enterClicksFirstButton = true, hideOnEscape = true};
	       StaticPopup_Show("TCamDistResetDialog");
           end;
		UIDropDownMenu_AddButton(info,2)
        end 
        else       
------------------------------------------------------------------------
-- 1й УРОВЕНЬ
------------------------------------------------------------------------
    -- Дистанции 0,10,20,30,40,50.
    TitanPanelRightClickMenu_AddTitle(L["BUTTON"])

    info = {};
    --info.notCheckable = true
   	info.text = ("  |cff00ff000|r"..L["METER"].."")
    info.value = "CamDist0"
    info.func = function()
    SetCVar("cameraDistanceMax",0)
    SetCVar("cameraDistanceMaxFactor",1)
    TitanPanelRightClickMenu_Close(1);
    if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(1) end end;
    info.hasArrow = 1;
    if floor(GetCVar("cameraDistanceMax"))== 0 then info.checked = 1 end;
    UIDropDownMenu_AddButton(info);
    
    for i=1,5 do
    info = {};
    --info.notCheckable = true
   	info.text = ("|cff00ff00"..(i*10).."|r"..L["METER"].."")
    info.value = "CamDist"..(i*10)
    info.func = function()
    SetCVar("cameraDistanceMax",(i*10))
    SetCVar("cameraDistanceMaxFactor",1)
    TitanPanelRightClickMenu_Close(1);
    if (TitanGetVar(ID, "CameraAutoZoom")) then  MoveViewOutStart(i) end end;
    if i<5 then info.hasArrow = 1 end;
    if floor(GetCVar("cameraDistanceMax"))/10 == i then info.checked = 1 end;
    UIDropDownMenu_AddButton(info);
    end

    TitanPanelRightClickMenu_AddSpacer()
    
    -- Доп. опции
    info = {};
    info.notCheckable = true
   	info.text = L["OPT"]
    info.value = "CamDistOpt"
    info.hasArrow = 1;
    UIDropDownMenu_AddButton(info);
    
    info = {};
	info.text = L["AUTOZOOM"];
    info.func = function() CamDistAutoZoom() end;
    info.checked = TitanGetVar(ID, "CameraAutoZoom");
    UIDropDownMenu_AddButton(info)

	TitanPanelRightClickMenu_AddToggleIcon(ID); 
    TitanPanelRightClickMenu_AddToggleLabelText(ID);
    TitanPanelRightClickMenu_AddCommand(L["Hide"], ID, TITAN_PANEL_MENU_FUNC_HIDE)
end
end

-- Ну надо же было добавить сюда чего-нибудь интересного, вот и придумал это)):
SLASH_TITANCAMDIST1 = "/CamDist"
SlashCmdList["TITANCAMDIST"] = TITANCommand
local sfuncoff, sfuncon
if GetLocale() == "ruRU" then sfuncoff = "Секретная функция |cffff0000Отключена|r. Спасибо за использование этого Аддона. /Вишмастер" else sfuncoff = "Secret function |cffff0000OFF|r. Thanks for using this Addon. /Wishmaster" end
if GetLocale() == "ruRU" then sfuncon  = "Незнаю как, но Вы |cff00ff00Включили|r Секретную функцию. =) Чтобы отключить ее напишите |cff00ff00/camdist off|r" else sfuncon = "It's not known how, but you have turn |cff00ff00ON|r a Secret function. =) To turn off it write |cff00ff00/camdist off|r" end
function TITANCommand(msg)
-- отключение
if msg == "off" then
MSG(L["TITAN"]..sfuncoff)
SetCVar("cameraDistanceMax",25)
MoveViewLeftStop()
MoveViewOutStop()
SetView(4)
-- включение
else
MSG(L["TITAN"]..sfuncon)
SetView(1)
SetCVar("cameraDistanceMax",50)
MoveViewLeftStart(0.1)
MoveViewOutStart(0.1)
end
end 

--P.S.: С этим аддоном мне помогли: Мизи и ЗлойКот(ака Русский во всех его формах и проявлениях): дефолтные настройки клиента 
