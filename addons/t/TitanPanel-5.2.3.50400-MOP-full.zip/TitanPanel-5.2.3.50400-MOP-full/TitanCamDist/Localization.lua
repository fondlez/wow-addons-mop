﻿--[[ 
LOCALIZATION for               ЛОКАЛИЗАЦИЯ для
TitanPanel: CameraDistance     ТитанПанель: ДистанцияКамеры 

Author/Автор:  Wishmaster (EU-Thermoplugg)/ Вишмастер (RU-Термоштепсель)
E-mail/Мыло:   Wish1250@gmail.com
Locales/Языки: RU,EN
]]--

-- Общая
local L = LibStub("AceLocale-3.0"):NewLocale("TitanCamDist","enUS",true)
if L then 
L["TITLE"]       = "Camera Distance"
L["TOOLTIP1"]    = "|cffffd700Changing maximum camera distance"
L["TOOLTIP2"]    = "|cff00ffffRight-click |cff00ff00to select camera distance\n|cff00ffffLeft-click |cff00ff00for zoom out\n|cff00ffffLeft-click+Shift, Ctrl |cff00ff00or |cff00ffffAlt |cff00ff00for zoom in|r"
L["BUTTON"]      = "Distance: "
L["METER"]       = " yard"
L["AUTOZOOM"]    = "AutoZoom"
L["OPT"]         = "Camera Options"
L["OPT_MOVE"]    = "Move"
L["OPT_YAW"]     = "Yaw"
L["OPT_SMOOTH"]  = "Smooth Style"
L["SMOOTH"]      = "Smooth Style"
L["SMOOTH_0"]    = "Never"
L["SMOOTH_1"]    = "Horizontal when Moving"
L["SMOOTH_2"]    = "Always"
L["SMOOTH_3"]    = "Horizontal"
L["SMOOTH_4"]    = "When Moving"
L["SMOOTH_5"]    = "Horizontal Instantly"
L["YAW"]         = "Yaw Speed"
L["MOVE"]        = "Move Speed"
L["DEFAULT"]     = "Default"
L["ON"]          = "|cff00ff00On"
L["OFF"]         = "|cffff0000Off"
L["WCOLL"]       = "Water Collision"
L["TERTILT"]     = "Terrain Tilt"
L["BOBBING"]     = "Bobbing"
L["TITAN"]       = "|cff00ff00[TitanCamDist]|r: "
L["RESET"]       = "|cffff0000Reset|r to default"
L["RES_ACP"]     = "Reset"
L["RES_MSG"]     = "All camera options are |cffff0000reset|r to default"
L["RES_QST"]     = "|cffff0000Reset|r all current camera options to default?"
L["Hide"]        = "Hide"
L["Cancel"]      = "Cancel"
L["M"]           = "y"
L["About"]       = "Titan|cff00ff00CamDist|r by |cffff8c00Wishmaster|r  (EU-Thermaplugg)"
end

-- Русская
local L = LibStub("AceLocale-3.0"):NewLocale("TitanCamDist","ruRU")
if L then 
L["TITLE"]       = "Дистанция камеры"
L["TOOLTIP1"]    = "|cffffd700Изменение максимальной дистанции камеры"
L["TOOLTIP2"]    = "|cff00ffffПКМ |cff00ff00для выбора дистанции\n|cff00ffffЛКМ |cff00ff00для отдаления камеры\n|cff00ffffЛКМ+Shift, Ctrl |cff00ff00или |cff00ffffAlt |cff00ff00для приближения камеры|r"
L["BUTTON"]      = "Дистанция: "
L["METER"]       = " метр"
L["AUTOZOOM"]    = "Автоизменение"
L["OPT"]         = "Опции камеры"
L["OPT_MOVE"]    = "Прокрутка"
L["OPT_YAW"]     = "Поворот"
L["OPT_SMOOTH"]  = "Выравнивание"
L["SMOOTH"]      = "Стиль выравнивания"
L["SMOOTH_0"]    = "Никогда"
L["SMOOTH_1"]    = "Гориз. при движении"
L["SMOOTH_2"]    = "Всегда"
L["SMOOTH_3"]    = "Горизонтальное"
L["SMOOTH_4"]    = "При движении"
L["SMOOTH_5"]    = "Гориз. мгновенно"
L["YAW"]         = "Скорость поворота"
L["MOVE"]        = "Скорость прокрутки"
L["DEFAULT"]     = "По умолчанию"
L["ON"]          = "|cff00ff00Вкл."
L["OFF"]         = "|cffff0000Откл."
L["WCOLL"]       = "Граница воды"
L["TERTILT"]     = "Следование рельефу"
L["BOBBING"]     = "Покачивание головы"
L["TITAN"]       = "|cff00ff00[TitanCamDist]|r: "
L["RESET"]       = "|cffff0000Сброс|r в стандарт"
L["RES_ACP"]     = "Сбросить"
L["RES_MSG"]     = "Все опции камеры |cffff0000сброшены|r в стандарт"
L["RES_QST"]     = "|cffff0000Сбросить|r все опции камеры в стандарт?"
L["Hide"]        = "Скрыть"
L["Cancel"]      = "Отмена"
L["M"]           = "м"
L["About"]       = "Titan|cff00ff00CamDist|r от |cffff8c00Вишмастер|rа  (EU-Термоштепсель)"
end