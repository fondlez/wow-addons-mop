--[[
	Description: Titan plug-in to display professions skill level
	Author: Subwired...
--]]

local PROFNAME_LW = "Leatherworking"
local addon = "TitanLeatherworking"
--local L = LibStub("AceLocale-3.0"):GetLocale("TitanProfLocalization", true)
local menutext = "Titan|cF58CBA00 "..PROFNAME_LW.."|r"
local buttonlabel =  PROFNAME_LW..": "
local ID = "LW"
local elap, LW, prevLW = 0, 0.0, -2
local LWmax, preLWmax = 0, 0



-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelLWButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")

f:SetScript("OnClick", function(self, button, down)
	CastSpellByName(PROFNAME_LW)
end)

function f:ADDON_LOADED(a1)

--print ("a1 = " .. a1)
	if a1 ~= addon then 
		return 
	end
	
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelLWButton_GetButtonText",
		tooltipTitle = PROFNAME_LW,
		tooltipTextFunction = "TitanPanelLWButton_GetTooltipText",
		frequency = 1,
		icon = "Interface\\Icons\\Trade_leatherworking.blp",
		iconWidth = 16,
		category = "Profession",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end

		--local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions();
		--local name, icon, skillLevel, maxSkillLevel, numAbilities, spelloffset, skillLine, skillModifier = GetProfessionInfo(index)
			
		local prof1, prof2, _, _, _, _ = GetProfessions();
		local name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(prof1)
		
		if not(name == PROFNAME_LW) then
			name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(prof2)
			if not(name == PROFNAME_LW) then
				skillLevel = 0
				maxSkillLevel = 0
			end
		end
		
		--[[
		if name == PROFNAME_LW then
			-- do nothign becouse we already have the data
			--print("name " .. name .. " ".. skillLevel .. " /" .. maxSkillLevel)
		else
			-- the first profession did not have it check the 2nd
			name, _, skillLevel, maxSkillLevel, _, _, _, _ = GetProfessionInfo(prof2)
			if name == PROFNAME_LW then
				-- do nothign becouse we already have the data 
			else
					-- profession not found
					skillLevel = 0
					maxSkillLevel = 0
			end
		end
		]]--
	
		LW = skillLevel
		LWmax = maxSkillLevel
		
		if LW == prevLW and LWmax == preLWmax then 
			return 
		end
		
		preLWmax = LWmax
		prevLW  = LW
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end

----------------------------------------------
function TitanPanelLWButton_GetButtonText()
----------------------------------------------
	local LWtext, pitchtext
	if not LW then
		LWtext = "??"
	else
	
		LWtext = LW .."/"..LWmax--string.format("%.0f", LW)  
	end
	return buttonlabel, LWtext
end

-----------------------------------------------
function TitanPanelLWButton_GetTooltipText()
-----------------------------------------------
	return "Click to open "..PROFNAME_LW
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end
----------------------------------------------------
function TitanPanelRightClickMenu_PrepareLWMenu()
----------------------------------------------------
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end