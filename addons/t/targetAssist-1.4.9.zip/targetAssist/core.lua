--[[
Name: targetAssist
Author: Sonora (The Dragonflight, US Kirin Tor)
Website & SVN: http://wow.curseforge.com/addons/targetassist/
License: GNU General Public License v3
]]
local ADDON, NS = ...
NS.Utils = {}
NS.Auto = {}
NS.ClassColors = {}
local classColors = NS.ClassColors
local autoAdds = NS.Auto
local util = NS.Utils

--Ugly global namespace bindings for binding.xml
_G[("BINDING_HEADER_%s"):format(ADDON)] = ADDON
_G[("BINDING_NAME_%s_ADDTARGET"):format(ADDON)] = "Add current target"
_G[("BINDING_NAME_%s_CLEARTARGETS"):format(ADDON)] = "Clear all targets"

--Ace3 addon application object & Libraries
local AceConfig = LibStub("AceConfig-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local LibRange = LibStub("LibRangeCheck-2.0")
local LGIST = LibStub("LibGroupInSpecT-1.0")
local addon = LibStub("AceAddon-3.0"):NewAddon(ADDON, "AceConsole-3.0", "AceComm-3.0", "AceSerializer-3.0", "AceEvent-3.0", "AceTimer-3.0")
_G[ADDON] = addon
addon.LibRange = LibRange
addon.Prefix = 'ta.bT'

--upvalues
local ipairs,pairs,unpack,floor,format,tostring,tinsert,tremove,wipe,tsort =
ipairs,pairs,unpack,floor,format,tostring,tinsert,tremove,wipe,table.sort
local UnitName,UnitIsUnit,UnitGroupRolesAssigned,UnitHealth,UnitHealthMax,UnitClass,UnitGUID,UnitIsFriend,UnitIsPlayer =
UnitName,UnitIsUnit,UnitGroupRolesAssigned,UnitHealth,UnitHealthMax,UnitClass,UnitGUID,UnitIsFriend,UnitIsPlayer
local IsInGroup,GetNumGroupMembers,GetNumSubgroupMembers,GetRaidRosterInfo,GetPartyAssignment,GetRaidTargetIndex =
IsInGroup,GetNumGroupMembers,GetNumSubgroupMembers,GetRaidRosterInfo,GetPartyAssignment,GetRaidTargetIndex
local RAID_CLASS_COLORS
local partyUnit,partyPet = {},{}
for i=1,MAX_PARTY_MEMBERS do
	partyUnit[i] = ("party%d"):format(i)
	partyPet[i] = ("partypet%d"):format(i)
end
local raidUnit,raidPet = {},{}
for i=1,MAX_RAID_MEMBERS do
	raidUnit[i] = ("raid%d"):format(i)
	raidPet[i] = ("raidpet%d"):format(i)
end
local dbName = ("%sDb"):format(ADDON)
local barName = ("%s.Bar"):format(ADDON)
local featuresName = ("%s.Features"):format(ADDON)
local appearanceName = ("%s.Appearance"):format(ADDON)
local profilesName = ("%s.Profiles"):format(ADDON)
local consoleName = ("%s.Console"):format(ADDON)
local ctxMenuName = ("%sContextMenu"):format(ADDON)

-- addon methods
function addon:OnInitialize() -- ADDON_LOADED(ADDON)

	--Addon wide data structures
	self.roster = {} --{unitName=unitID,}
	self.mainassists = {}
	self.tanks = {}

	self.buttonWidth = 0
	self.postCombatCalls = {}
	self.previousBroadcasts = {} --{{fromPlayer, channel, targets},}

	--Setup a default profile table for the database
	local defaultProfileDb = {
		profile = {
			config = util.deepcopy(self.defaultConfig)
		}
	}

	--Setup database communication
	self.db = LibStub("AceDB-3.0"):New(dbName, defaultProfileDb)
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, 'OnNewProfile', 'OnNewProfile')

	--Two variables determine whether or not the addon is shown & events are registered
	self.hide = false --managed by addon based on whether or not the player is in a group and we auto-hide out of group

end

function addon:OnEnable() -- PLAYER_LOGIN
	--Register us as receivers of our AceComm messages
	self:RegisterComm(self.Prefix, 'targetReceiver')

	--If SharedMedia is loaded, share our media
	if IsAddOnLoaded("SharedMedia") then
		local lib = LibStub("LibSharedMedia-3.0")
		lib:Register(lib.MediaType.STATUSBAR, barName, ([=[Interface\Addons\%s\media\barTex]=]):format(ADDON))
	end
	RAID_CLASS_COLORS = CUSTOM_CLASS_COLORS or _G.RAID_CLASS_COLORS
	if not next(classColors) then
		for k,v in pairs(RAID_CLASS_COLORS) do
			classColors[k]=v
		end
		classColors["UNKNOWN"] = {r=0.8,g=0.8,b=0.8,colorStr="ffcccccc"}
		classColors["PET"] = {r=0.8,g=0.8,b=0.0,colorStr="ffcccc00"}
	end
	-- This call in turn handles changes to targetAssist.config and config GUI construction
	self:OnProfileChanged(nil, self.db, self.db:GetCurrentProfile())

	-- Event registration
	self:RegisterEvent('GROUP_ROSTER_UPDATE')
	self:RegisterEvent('GROUP_JOINED')
	self:RegisterEvent('UNIT_PET')
	self:RegisterEvent('PLAYER_ROLES_ASSIGNED')

	-- Setup timers
	self.repeatingTimer = self:ScheduleRepeatingTimer('onUpdate', self.config.updateInterval)

	-- Range checks setup
	if LibRange then
		if self.config.fadeOutOfRange then
			self.enemyOutOfRangeChecker = LibRange:GetHarmMinChecker(self.config.enemyRange)
			self.friendOutOfRangeChecker = LibRange:GetFriendMinChecker(self.config.friendRange)
		end
		LibRange.RegisterCallback(self,"CHECKERS_CHANGED", "rangeCheckUpdate")
	end

	if LGIST then
		LGIST.RegisterCallback(self,"GroupInSpecT_Update", "roleUpdated")
	end

	-- oRA3 event notification
	if oRA3 and oRA3.GetSortedTanks then
		oRA3.RegisterCallback(self, "oRA3_TanksUpdated")
		self:oRA3_TanksUpdated(nil, oRA3:GetSortedTanks())
	end

	-- Update our shown state
	self:updateEnabled()

	-- Setup the user interface, and fire events which don't on their own at log in
	self:buildUI()
end

function addon:OnDisable()
	self:UnregisterEvent('PLAYER_ROLES_ASSIGNED')
	self:UnregisterEvent('UNIT_PET')
	self:UnregisterEvent('GROUP_JOINED')
	self:UnregisterEvent('GROUP_ROSTER_UPDATE')
	if self.repeatingTimer then self:CancelTimer(self.repeatingTimer) end
	if oRA3 and oRA3.UnregisterCallback then
		oRA3.UnregisterCallback(self,"oRA3_TanksUpdated")
	end
	if LibRange and LibRange.UnregisterCallback then
		LibRange.UnregisterCallback(self,"CHECKERS_CHANGED")
	end
	if LGIST and LGIST.UnregisterCallback then
		LGIST.UnregisterCallback(self,"GroupInSpecT_Update")
	end
	self:UnregisterComm('ta.bT', 'targetReceiver')
end

function addon:rangeCheckUpdate()
	if self.config.fadeOutOfRange then
		self.enemyOutOfRangeChecker = LibRange:GetHarmMinChecker(self.config.enemyRange)
		self.friendOutOfRangeChecker = LibRange:GetFriendMinChecker(self.config.friendRange)
	end
end

function addon:roleUpdated(_,unit,guid,info)
	if self.config.includeSpecTanks then
		local name = info and info.name
		local role = info and info.spec_role
		if name and unit and self.roster[name] and UnitIsUnit(unit,self.roster[name]) and role and role == 'TANK' then
			if not util.hasValue(self.tanks,name) then
				tinsert(self.tanks,name)
				if self.config.autoAddTargets then
					if not util.hasValue(self.config.targets,name) then
						tinsert(self.config.targets,name)
						autoAdds[name] = true
						self:updateConfig()
					end
				end
			end
		end
	end
end

function addon:__updateFrameState(stateCall)
	return function()
		if self.headerFrame then
			self.headerFrame[stateCall](self.headerFrame)
			if self.targetButtons then
				for _, buttonFrame in pairs(self.targetButtons) do
					buttonFrame[stateCall](buttonFrame)
				end
			end
		end
	end
end
function addon:updateEnabled()

	if (self.hide or self.config.userDisabled) then
		self:registerPostCombatCall(self:__updateFrameState('Hide'))
		self.enabled = false
	else
		self:registerPostCombatCall(self:__updateFrameState('Show'))
		self.enabled = true
		self:Enable()
	end
end

function addon:buildUI()

	if self.optionsBaseFrame then return end
	--Setup options panels
	AceConfig:RegisterOptionsTable(ADDON, self:createBasePanel())
	self.optionsBaseFrame = AceConfigDialog:AddToBlizOptions(ADDON, ADDON)

	AceConfig:RegisterOptionsTable(featuresName, self:createFeaturesPanel())
	AceConfigDialog:AddToBlizOptions(featuresName, "Features", ADDON)

	AceConfig:RegisterOptionsTable(appearanceName, self:createAppearancePanel())
	AceConfigDialog:AddToBlizOptions(appearanceName, "Appearance", ADDON)

	AceConfig:RegisterOptionsTable(profilesName, LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db))
	AceConfigDialog:AddToBlizOptions(profilesName, "Profiles", ADDON)

	--Setup command line options
	AceConfig:RegisterOptionsTable(consoleName, self:createConsoleOptions(), {ADDON, "ta"})

	--Build a context menu
	self.contextMenu = CreateFrame("Frame", ctxMenuName, UIParent, "UIDropDownMenuTemplate")

end

function addon:targetReceiver(prefix, message, distribution, sender)

	if not UnitIsUnit('player',sender) then -- comment out for debug

		local success, newTargets = self:Deserialize(message)

		if #self.previousBroadcasts == self.config.broadcastHistory then
			tremove(self.previousBroadcasts, 1)
		end
		tinsert(self.previousBroadcasts, {sender, distribution, newTargets})

		if self.config.autoAcceptBroadcasts then
			self.config.targets = newTargets
			self:updateConfig()
		else
			self:yesnoBox(("A set of assist targets has been sent by %s. Would you like to change to this new target list?"):format(sender),
			function()
				self.config.targets = newTargets
				self:updateConfig()
			end
			)
		end

	end
end

function addon:upgradeDatabase(config)

	if config.dbVersion == self.currentDbVersion then return config
	else
		local nextVersion = config.dbVersion + 1
		local migrationCall = self.migrationPaths[nextVersion]

		if migrationCall then migrationCall(config) end

		config.dbVersion = nextVersion
		return self:upgradeDatabase(config)
	end

end

function addon:OnProfileChanged(eventName, db, newProfile)

	self.config = db.profile.config

	if self.config then

		--Unversioned databases are set to v. 1
		if self.config.dbVersion == nil then self.config.dbVersion = 1 end

		--Handle database version checking and upgrading if necessary
		local startVersion = self.config.dbVersion
		self:upgradeDatabase(self.config)
		if startVersion ~= self.config.dbVersion then
			print(("%s configuration database upgraded from v.%s to v.%s"):format(ADDON,startVersion,self.config.dbVersion))
		end

	end

	self:updateRoster()
	self:updateConfig()

end

function addon:OnNewProfile(eventName, db, profile)

	--Set the dbVersion to the most recent, as defaults for the new profile should be up-to-date
	db.profile.config.dbVersion = self.currentDbVersion

end

function addon:updateConfig() self.updateConfigPostCombat = true end

function addon:__updateConfig()
	self.updateConfigPostCombat = false
	self:createHeaderFrame()
	self:createTargetButtons()
end

function addon:addTanks(auto)

	tsort(self.tanks)
	for i, tankName in ipairs(self.tanks) do
		if not util.hasValue(self.config.targets, tankName) then
			tinsert(self.config.targets, i, tankName)
			autoAdds[tankName] = auto -- use 'not not auto' to cast to boolean
		end
	end
	self:updateConfig()

end

function addon:addMainAssists(auto)

	tsort(self.mainassists)
	for i, assistName in ipairs(self.mainassists) do
		if not util.hasValue(self.config.targets, assistName) then
			tinsert(self.config.targets, i, assistName)
			autoAdds[assistName] = auto
		end
	end
	self:updateConfig()

end
function addon:addTarget()

	local unitName = util.unitname('target')
	if unitName then
		if not UnitIsFriend('player', 'target') then
			unitName = util.unitname('targettarget')
		end
		if not util.hasValue(self.config.targets, unitName) then
			tinsert(self.config.targets, 1, unitName)
			autoAdds[unitName] = nil
		end
	end
	self:updateConfig()

end
function addon:addAll()
	local unitNames = util.keys(self.roster)
	for _, unitName in ipairs(unitNames) do
		if not util.hasValue(self.config.targets, unitName) then
			tinsert(self.config.targets, unitName)
			autoAdds[unitName] = nil
		end
	end
	self:updateConfig()
end
function addon:addParty()
	for i=1,GetNumSubgroupMembers() do
		local unitName = util.unitname(partyUnit[i])
		if unitName and not util.hasValue(self.config.targets, unitName) then
			tinsert(self.config.targets, unitName)
			autoAdds[unitName] = nil
		end
	end
	self:updateConfig()
end
function addon:clearAll()
	wipe(self.config.targets)
	wipe(self.previousBroadcasts)
	wipe(autoAdds)
	self:updateConfig()
end
function addon:invertTargetOrder()
	self.config.invertTargetOrder = not self.config.invertTargetOrder
	self:updateConfig()
end

function addon:updateRoster()
	wipe(autoAdds)
	for _, v in ipairs(self.mainassists) do autoAdds[v] = false end
	for _, v in ipairs(self.tanks) do autoAdds[v] = false end

	wipe(self.mainassists or {})
	wipe(self.tanks or {})

	wipe(self.roster or {})  --{unitName = unitID,}

	if self.config.showPets then
		local petName = util.unitname('pet')
		if petName then
			petName = ("%s (your pet)"):format(petName)
			self.roster[petName] = 'pet'
		end
	end

	local playerName = util.unitname('player')
	local playerGUID = UnitGUID('player')
	if self.config.includePlayer then
		self.roster[playerName] = 'player'
	end

	if IsInGroup() then
		if IsInRaid() then -- raid
			for i=1,GetNumGroupMembers() do
				local unitid = raidUnit[i]
				local notMe = not UnitIsUnit('player',unitid)
				local unitName = util.unitname(unitid)
				local guid = UnitGUID(unitid)
				if unitName then
					if notMe then self.roster[unitName] = unitid end
					local _,_,_,_,_,_,_,_,_,role,_, assignedRole = GetRaidRosterInfo(i) -- role = 'MAINTANK|MAINASSIST', assignedRole = 'TANK|HEALER|DAMAGER|NONE'
					local info = guid and LGIST:GetCachedInfo(guid)
					if self.config.includeRaidAssists and role and role == 'MAINASSIST' and (notMe or self.config.includePlayer) then
						tinsert(self.mainassists,unitName)
					end
					if self.config.includeRaidTanks and role and role == 'MAINTANK' and (notMe or self.config.includePlayer) then
						tinsert(self.tanks,unitName)
					end
					if self.config.includeRoleTanks and assignedRole and assignedRole == 'TANK' and (notMe or self.config.includePlayer) then
						tinsert(self.tanks,unitName)
					end
					if self.config.includeSpecTanks and info and info.spec_role and info.spec_role == 'TANK' and (notMe or self.config.includePlayer) then
						tinsert(self.tanks,unitName)
					end
					if self.config.showPets and notMe then
						local petid = raidPet[i]
						local petName = util.unitname(petid)
						if petName then
							petName = ("%s |r(%s\'s pet)"):format(petName,util.decoratedName(unitName))
							self.roster[petName] = petid
						end
					end
				end
			end
		else -- party
			for i=1,GetNumSubgroupMembers() do
				local unitid = partyUnit[i]
				local unitName = util.unitname(unitid)
				local guid = UnitGUID(unitid)
				if unitName then
					self.roster[unitName] = unitid
					local role,assignedRole
					if ( GetPartyAssignment('MAINTANK', unitid) ) then
						role = 'MAINTANK'
					elseif ( GetPartyAssignment('MAINASSIST', unitid) ) then
						role = 'MAINASSIST'
					end
					assignedRole = UnitGroupRolesAssigned(unitid)
					local info = guid and LGIST:GetCachedInfo(guid)
					if self.config.includeRaidAssists and role and role == 'MAINASSIST' then
						tinsert(self.mainassists,unitName)
					end
					if self.config.includeRaidTanks and role and role == 'MAINTANK' then
						tinsert(self.tanks,unitName)
					end
					if self.config.includeRoleTanks and assignedRole and assignedRole == 'TANK' then
						tinsert(self.tanks,unitName)
					end
					if self.config.includeSpecTanks and info and info.spec_role and info.spec_role == 'TANK' then
						tinsert(self.tanks,unitName)
					end
					if self.config.showPets then
						local petid = partyPet[i]
						local petName = util.unitname(petid)
						if petName then
							petName = ("%s |r(%s\'s pet)"):format(petName,util.decoratedName(unitName))
							self.roster[petName] = petid
						end
					end
				end
			end
			if self.config.includePlayer then
				local role,assignedRole
				local unitName = playerName
				if ( GetPartyAssignment('MAINTANK', 'player') ) then
					role = 'MAINTANK'
				elseif ( GetPartyAssignment('MAINASSIST', 'player')) then
					role = 'MAINASSIST'
				end
				assignedRole = UnitGroupRolesAssigned('player')
				local info = playerGUID and LGIST:GetCachedInfo(playerGUID)
				if self.config.includeRaidAssists and role and role == 'MAINASSIST' then
					tinsert(self.mainassists,unitName)
				end
				if self.config.includeRaidTanks and role and role == 'MAINTANK' then
					tinsert(self.tanks,unitName)
				end
				if self.config.includeRoleTanks and assignedRole and assignedRole == 'TANK' then
					tinsert(self.tanks,unitName)
				end
				if self.config.includeSpecTanks and info and info.spec_role and info.spec_role == 'TANK' then
					tinsert(self.tanks,unitName)
				end
			end
		end
		if oRA3 and self.oRA3Tanks and self.config.includeORA3 then
			for _, unitName in ipairs(self.oRA3Tanks) do
				tinsert(self.tanks,unitName)
			end
		end -- inserts done, remove duplicates
		self.tanks = util.unique(self.tanks)
		self.mainassists = util.unique(self.mainassists)
		--Purge targets we previously auto-added but are now missing
		if self.config.purgeAutoAdds then
			for unitName,currentAdd in pairs(autoAdds) do
				if not currentAdd then
					tremove(self.config.targets, util.tableIndex(self.config.targets, unitName))
				end
			end
		end
		if self.config.autoAddTargets then
			self:addTanks(true)
			self:addMainAssists(true)
		end

		if self.hide then
			self.hide = false
			self:updateEnabled()
		end
	else -- solo
		if self.config.hideOutOfGroup then
			if not self.hide then
				self.hide = true
				self:updateEnabled()
			end
		else
			if self.hide then
				self.hide = false
				self:updateEnabled()
			end
		end
	end

	if self.contextMenu and self.contextMenu:IsShown() then self.contextMenu:Hide() end

	self:updateConfig()
end

local function getUnitHealth(unitID)
	-- returns percentage
	local hpMax = UnitHealthMax(unitID)
	if not hpMax or (hpMax <= 0) then return 1.0 end -- pets sometimes return 0 after taxi-landing / portal summon
	return UnitHealth(unitID) / hpMax
end

function addon:registerPostCombatCall(call) tinsert(self.postCombatCalls, call) end

local function addUnitID(trackingTable, unitID)
	for foundingTargetID, count in pairs(trackingTable) do
		if UnitIsUnit(unitID, foundingTargetID) then
			trackingTable[foundingTargetID] = trackingTable[foundingTargetID]+1
			return foundingTargetID
		end
	end

	trackingTable[unitID] = 1
	return unitID
end
local function getFoundingTargetID(trackingTable, unitID)
	for foundingTargetID, count in pairs(trackingTable) do
		if UnitIsUnit(unitID, foundingTargetID) then
			return foundingTargetID
		end
	end
end

local friendlyTargets,hostileTargets = {},{}
function addon:onUpdate()
	--[[
	A big ugly function:  keeping everything inline here to help keep track
	of the processing which is happening on each update cylce.
	]]--
	if not InCombatLockdown() then
		if self.updateConfigPostCombat then self:__updateConfig() end

		for _, call in ipairs(self.postCombatCalls) do call() end
		wipe(self.postCombatCalls or {})
		if not self.enabled then self:Disable() end
	end

	if not self.enabled then return end

	wipe(friendlyTargets) --{foundingTargetID = count,}
	wipe(hostileTargets)
	for unitName, unitID in pairs(self.roster) do
		local targetid = ("%starget"):format(unitID)
		if UnitIsFriend('player', targetid) then
			addUnitID(friendlyTargets, targetid)
		else
			addUnitID(hostileTargets, targetid)
		end
	end
	if UnitIsFriend('player','playertarget') then
		addUnitID(friendlyTargets, 'playertarget')
	else
		addUnitID(hostileTargets, 'playertarget')
	end

	local maxCount, maxHostile = 1, nil
	for foundingTargetID, count in pairs(hostileTargets) do
		if count > maxCount then
			maxCount = count
			maxHostile = foundingTargetID
		end
	end

	local maxCount, maxFriendly = 1, nil
	for foundingTargetID, count in pairs(friendlyTargets) do
		if count > maxCount then
			maxCount = count
			maxFriendly = foundingTargetID
		end
	end

	for targetName, buttonFrame in pairs(self.targetButtons or {}) do
		local unitName = buttonFrame.unitID and util.unitname(buttonFrame.unitID)
		if unitName then
			buttonFrame.unitName = unitName

			local unitHealth = getUnitHealth(buttonFrame.unitID)

			-- Style the targeted unit's buttons
			if UnitIsUnit('playertarget', buttonFrame.unitID) then
				buttonFrame.texture:SetVertexColor(unpack(self.config.myTargetColor))
				if self.config.showFriendlyHealthPercent then
					buttonFrame.fontString:SetFormattedText('%s\n%d%%',unitName,floor(unitHealth*100))
				else
					buttonFrame.fontString:SetText(unitName)
				end

				-- Style friendly unit buttons
			elseif UnitIsFriend('player', buttonFrame.unitID) then
				local r,g,b,a
				if self.config.colorFriendlyTargetsByClass and UnitIsPlayer(buttonFrame.unitID) then
					local _, stdClassName = UnitClass(buttonFrame.unitID)
					local classColor = RAID_CLASS_COLORS[stdClassName]
					if classColor then
						r,g,b,a = classColor.r, classColor.g, classColor.b, self.config.friendlyTargetColor[4]
					else
						r,g,b,a = unpack(self.config.friendlyTargetColor)
					end
				else
					r,g,b,a = unpack(self.config.friendlyTargetColor)
				end
				if self.config.fadeOutOfRange and (self.friendOutOfRangeChecker and not self.friendOutOfRangeChecker(buttonFrame.unitID)) and not UnitIsUnit(buttonFrame.unitID,'player') then
					a = max(0.1, a - self.config.outOfRangeAlphaOffset)
				end
				buttonFrame.texture:SetVertexColor(r,g,b,a)

				if self.config.showFriendlyHealthPercent then
					buttonFrame.fontString:SetFormattedText('%s\n%d%%',unitName,floor(unitHealth*100))
				else
					buttonFrame.fontString:SetText(unitName)
				end

				-- Style hostile unit buttons
			else
				local r,g,b,a, fontColor
				if self.config.colorHostileTargetsByClass and UnitIsPlayer(buttonFrame.unitID) then
					local _, stdClassName = UnitClass(buttonFrame.unitID)
					local classColor = RAID_CLASS_COLORS[stdClassName]
					r,g,b,a = classColor.r, classColor.g, classColor.b, self.config.hostileTargetColor[4]
					fontColor = self.config.hostileTargetColor
				else
					r,g,b,a = unpack(self.config.hostileTargetColor)
					fontColor = self.config.fontColor
				end

				if self.config.fadeOutOfRange and (self.enemyOutOfRangeChecker and not self.enemyOutOfRangeChecker(buttonFrame.unitID)) then
					a = max(0.1, a - self.config.outOfRangeAlphaOffset)
				end
				buttonFrame.texture:SetVertexColor(r,g,b,a)
				buttonFrame.fontString:SetTextColor(unpack(fontColor))

				if self.config.showHostileHealthPercent then
					buttonFrame.fontString:SetFormattedText('%s\n%d%%',unitName,floor(unitHealth*100))
				else
					buttonFrame.fontString:SetText(unitName)
				end

			end

			if self.config.showHealth then
				local width = unitHealth * self.buttonWidth
				if width > 0 then
					buttonFrame.texture:SetWidth( width )
				else
					buttonFrame.texture:SetWidth( self.buttonWidth )
					buttonFrame.texture:SetVertexColor(unpack(self.config.missingColor))
				end
			end

			if buttonFrame.raidIcon then
				local iconIdx = GetRaidTargetIndex(buttonFrame.unitID)
				if iconIdx then
					buttonFrame.raidIcon:SetTexture(self.config.raidIcons[iconIdx][2])
					buttonFrame.raidIcon:Show()
				else
					buttonFrame.raidIcon:Hide()
				end
			end

			if buttonFrame.mostTargetedIcon and buttonFrame.targetCountString then
				if UnitIsFriend('player', buttonFrame.unitID) then
					local foundingTargetID = getFoundingTargetID(friendlyTargets, buttonFrame.unitID)
					if foundingTargetID then
						if self.config.markMostTargetedFriendly and foundingTargetID == maxFriendly then
							buttonFrame.mostTargetedIcon:SetTexture(self.config.raidIcons[4][2])
							buttonFrame.mostTargetedIcon:Show()
						else
							buttonFrame.mostTargetedIcon:Hide()
						end
						if self.config.trackNumberTargetingFriendlies then
							buttonFrame.targetCountString:SetText(tostring(friendlyTargets[foundingTargetID]))
						else
							buttonFrame.targetCountString:SetText('')
						end
					else
						buttonFrame.mostTargetedIcon:Hide()
						buttonFrame.targetCountString:SetText('')
					end
				else
					local foundingTargetID = getFoundingTargetID(hostileTargets, buttonFrame.unitID)
					if self.config.markMostTargetedHostile and foundingTargetID == maxHostile then
						buttonFrame.mostTargetedIcon:SetTexture(self.config.raidIcons[8][2])
						buttonFrame.mostTargetedIcon:Show()
					else
						buttonFrame.mostTargetedIcon:Hide()
					end
					if self.config.trackNumberTargetingHostiles then
						buttonFrame.targetCountString:SetText(tostring(hostileTargets[foundingTargetID]))
					else
						buttonFrame.targetCountString:SetText('')
					end
				end
			end

		else
			buttonFrame.fontString:SetText('')
			buttonFrame.texture:SetVertexColor(unpack(self.config.missingColor))
			if buttonFrame.raidIcon then buttonFrame.raidIcon:Hide() end
			if buttonFrame.mostTargetedIcon then buttonFrame.mostTargetedIcon:Hide() end
			if buttonFrame.targetCountString then buttonFrame.targetCountString:SetText('') end
			buttonFrame.texture:SetWidth( self.buttonWidth )
		end
	end
end

--Event handlers
function addon:GROUP_ROSTER_UPDATE() self:updateRoster() end
function addon:GROUP_JOINED() self:updateRoster() end
function addon:UNIT_PET() if self.config.showPets then self:updateRoster() end end
function addon:PLAYER_ROLES_ASSIGNED() if self.config.includeRoleTanks then self:updateRoster() end end
function addon:oRA3_TanksUpdated(event, tankNames)
	if not self.config.includeORA3 then return end
	self.oRA3Tanks = tankNames
	self:updateRoster()
end

--[[
Notes:
5.4
local relationship = UnitRealmRelationship(unit)
LE_REALM_RELATION_VIRTUAL
LE_REALM_RELATION_COALESCED
LE_REALM_RELATION_SAME

Logic:
- Manual additions (add target|party|all|tanks|assists from the context menu or the keybinds persist /reloadui to next session)
- Manual additions that exist as auto additions overwrite the flag and become manual.
- Manual clears remove persistence.
- Automatic additions are checked against the roster on roster updates and those not present are removed, they also do not persist /reloadui or get saved.
Decide on how to save the source flag as part of the structure without affecting sorting.
]]