--Utilities
local ADDON,NS = ...
local util = NS.Utils
local addon = _G[ADDON]
local classColors = NS.ClassColors
local INLINE_PET = "|TInterface\\RaidFrame\\UI-RaidFrame-Pets:0|t"
local INLINE_MAINTANK = "|TInterface\\RaidFrame\\UI-RaidFrame-MainTank:0|t"
local INLINE_MAINASSIST = "|TInterface\\RaidFrame\\UI-RaidFrame-MainAssist:0|t"
local tsort = table.sort
local UnitClass,UnitIsPlayer = UnitClass,UnitIsPlayer

function util.deepcopy(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for index, value in pairs(object) do
            new_table[_copy(index)] = _copy(value)
        end
        return setmetatable(new_table, _copy(getmetatable(object)))
    end
    return _copy(object)
end
function util.hasValue(t, value)
    for _, v in ipairs(t) do
        if v == value then return true end
    end
    for k, v in pairs(t) do
        if v == value then return true end
    end
end
function util.keys(t)
    local temp_t = {}
    for k,_ in pairs(t) do tinsert(temp_t, k) end
    return temp_t
end
function util.keyFromValue(t, value)
    for k,v in pairs(t) do
        if v == value then return k end
    end
end
function util.tableIndex(t, value)
    for idx, v in ipairs(t) do
        if v == value then return idx end
    end
end
function util.unique(t) -- arrays only
	local temp_t,i = {}
	tsort(t)
    for k,v in ipairs(t) do
    	temp_t[#temp_t+1] = i~=v and v or nil
	    i=v
    end
    return temp_t
end
function util.inverted(t)
    local temp_t = {}
    for i = 0,#t-1 do
        tinsert(temp_t, t[#t-i])
    end
    return temp_t
end
function util.unitname(unit)
	local name, server = UnitName(unit)
	if server and server~="" then
		name = ("%s-%s"):format(name,server)
	end
	return name
end
function util.decoratedName(unitName)
    local name = unitName
    local unit = addon.roster[unitName]
    if not UnitIsPlayer(unit) then
        name = ("%s|c%s%s"):format(INLINE_PET,classColors["PET"].colorStr,name)
    else
        local _,eClass = UnitClass(addon.roster[unitName])
        local colorStr = classColors[eClass] and classColors[eClass].colorStr or classColors["UNKNOWN"].colorStr
        if util.hasValue(addon.tanks,unitName) then
            name = ("%s|c%s%s|r"):format(INLINE_MAINTANK,colorStr,name)
        elseif util.hasValue(addon.mainassists,unitName) then
            name = ("%s|c%s%s|r"):format(INLINE_MAINASSIST,colorStr,name)
        else
            name = ("|c%s%s|r"):format(colorStr,name)
        end
    end
    return name
end