--[[
Name: targetAssist
Author: Sonora (The Dragonflight, US Kirin Tor)
Website & SVN: http://wow.curseforge.com/addons/targetassist/
License: GNU General Public License v3
]]
local ADDON,NS = ...
local addon = _G[ADDON]
local STANDARD_TEXT_FONT = STANDARD_TEXT_FONT
--Runs in application namespace
setfenv(1, addon)

--This table should be serializable
defaultConfig = {
    
    --Header frame configuration
    headerHeight = 15,
    headerAnchor = {'CENTER', 0, 0},
    headerTexture = ([=[Interface\Addons\%s\media\barTex]=]):format(ADDON),
    headerColor = {0.24, 0.24, 0.24, 1.0},
    headerBackdrop = {
       bgFile = [=[Interface\Tooltips\UI-Tooltip-Background]=],
       insets = {top = -1, left = -1, bottom = -1, right = -1}
    },
    headerUnlocked = true,
    hideOutOfGroup = true,
    hideAddonName = false,
    autoHideHeader = true,
    
    --Target button configuration
    targetHeight = 25,
    targetWidth = 100, --NEW in db 2.0
    targetTexture = ([=[Interface\Addons\%s\media\barTex]=]):format(ADDON),
    targetBackdrop = {
       bgFile = [=[Interface\Tooltips\UI-Tooltip-Background]=],
       insets = {top = -1, left = -1, bottom = -1, right = -1}
    },
    targetBackdropColor = {0.15, 0.15, 0.15},
    
    colorFriendlyTargetsByClass = false,
    friendlyTargetColor = {0.44, 0.37, 0.62, 0.9},
    colorHostileTargetsByClass = false,
    hostileTargetColor = {0.62, 0.27, 0.34, 0.9},
    missingColor = {0.1,0.1,0.1,0},
    myTargetColor = {0.35,0.70,0.42,0.9},
    
    targetButtonAnchor = {'TOPLEFT','BOTTOMLEFT',-2}, --{buttonAnchorPoint, headerAnchorPoint, verticalOffset} (headerAnchorPoint may be point on previous button)
    
    showHealth = true,
    showFriendlyHealthPercent = false,
    showHostileHealthPercent = false,
    
    --Applies to all text
    fontName = STANDARD_TEXT_FONT, --v3
    fontHeight = 11,
    fontColor = {1,1,1},
    
    --Distance between assist target and assist target target frames
    spacingOffset = 1,
    
    --Features
    autoAcceptBroadcasts = false,
    purgeAutoAdds = true,
    autoAddTargets = true,  --v3
    includeRaidAssists = true, --v3
    includeRaidTanks = true, --v3
    includeRoleTanks = true, --v3
    includeSpecTanks = false, --v3
    includeORA3 = false, --v3
    
    showTargetTarget = false,
    showPets = true,
    
    trackNumberTargetingHostiles = true,
    markMostTargetedHostile = true,
    
    trackNumberTargetingFriendlies = true,
    markMostTargetedFriendly = true,
    
    fadeOutOfRange = true,
    enemyRange = 30, -- v3
    friendRange = 30, -- v3
    outOfRangeAlphaOffset = 0.5,
    
    includePlayer = false,
    invertTargetOrder = false,
    
    --Processing and efficiency
    updateInterval = 0.1,
    broadcastHistory = 10,
    userDisabled = false,
    
    disableClique = false,
    
    --We persist targets between UI loads
    targets = {},

    --Will these ever change?  Here just in case.
    raidIcons = {  --{{Name, texturePath},}
        {'Star',[[Interface\TargetingFrame\UI-RaidTargetingIcon_1]]},
        {'Circle',[[Interface\TargetingFrame\UI-RaidTargetingIcon_2]]},
        {'Diamond',[[Interface\TargetingFrame\UI-RaidTargetingIcon_3]]},
        {'Triangle',[[Interface\TargetingFrame\UI-RaidTargetingIcon_4]]},
        {'Moon',[[Interface\TargetingFrame\UI-RaidTargetingIcon_5]]},
        {'Square',[[Interface\TargetingFrame\UI-RaidTargetingIcon_6]]},
        {'Cross',[[Interface\TargetingFrame\UI-RaidTargetingIcon_7]]},
        {'Skull',[[Interface\TargetingFrame\UI-RaidTargetingIcon_8]]},
    },
}

--[[
Database version migration logic.

migrationPaths = { [dbVersion] = function(config) ... end, }

dbVersion is an incremented integer.

Functions should update config in-place to update from the previous integer
version.  Updates are automatically cascaded across multiple versions when 
needed.
]]--

currentDbVersion = 3

migrationPaths = {
    [2] = function(config) 
            --Convert .headerWidth to .targetWidth
            if config.headerWidth then config.targetWidth = config.headerWidth/2 end
        end,
    [3] = function(config)
    		if config.classRangeChecks then config.classRangeChecks = nil end
    		if config.autoUpdateORA2 then config.autoUpdateORA2 = nil end
    		if config.fontName == "Fonts\\FRIZQT__.TTF" then config.fontName = STANDARD_TEXT_FONT end
    		if config.autoUpdateMainAssists or config.autoUpdateTanks or config.autoUpdateORA3 then 
    			config.autoAddTargets = true
    			if config.autoUpdateMainAssists then
    				config.includeRaidAssists = true
    			end
    			if config.autoUpdateTanks or config.autoUpdateORA3 then
    				config.includeRaidTanks = true
    				config.includeRoleTanks = true
    				config.includeSpecTanks = true
    				config.includeORA3 = true
    			end
    		end
    		config.autoUpdateMainAssists = nil; config.autoUpdateTanks = nil; config.autoUpdateORA3 = nil
    		config.enemyRange = config.enemyRange or 30
    		config.friendRange = config.friendRange or 30
    	end,
}

