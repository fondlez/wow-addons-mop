-- **************************************************************************
--   TitanClan.lua
--  
--   By: KanadiaN
--        (Lindarena@Laughing Skull)
-- **************************************************************************

local L = LibStub( "AceLocale-3.0" ):GetLocale( "Titan", true );
local LB = LibStub( "AceLocale-3.0" ):GetLocale( "TitanClan", true );

-- **************************************************************************
-- NAME : TitanClan_Init( state )
-- DESC : For first time addon use
-- **************************************************************************
function TitanClan_Init( state )
     if ( state == "checkDB" ) then
          checkDB = true;
          TitanClanInit = false;
     elseif ( state == "init" ) then
          checkDB = false;
     end
     if ( not TitanClan or TitanClan == nil ) then TitanClan = {}; end
     if ( not TitanClanInit or TitanClanInit == nil ) then
          if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 24, LB["TITAN_CLAN_MENU_CHECKDB"] ); end
          if ( not TitanClanStaticArrays or TitanClanStaticArrays == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 26, LB["TITAN_CLAN_ARRAY"]:format( "TitanClanStaticArrays" ) ); end
               TitanClanStaticArrays = {};
          end
          if ( not TitanClanLocals or TitanClanLocals == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 30, LB["TITAN_CLAN_ARRAY"]:format( "TitanClanLocals" ) ); end
               TitanClanLocals = {};
          end
          if ( not TitanClanStaticArrays.presets or TitanClanStaticArrays.presets == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 34, LB["TITAN_CLAN_STATICARRAY_FIXED"]:format( "presets" ) ); end
               TitanClanStaticArrays.presets = { LB["TITAN_CLAN_CONFIG_NONE"], "!s (!l) !p ~ !z !c !r", "!s (!l) !uc ~ !z !r", };
          end
          if ( not TitanClanStaticArrays.sortTypes or TitanClanStaticArrays.sortTypes == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 38, LB["TITAN_CLAN_STATICARRAY_FIXED"]:format( "sortTypes" ) ); end
               TitanClanStaticArrays.sortTypes = { LB["TITAN_CLAN_CONFIG_NAME"], LB["TITAN_CLAN_CONFIG_ZONE"], LB["TITAN_CLAN_CONFIG_RANK"], LB["TITAN_CLAN_CONFIG_LEVEL"], LB["TITAN_CLAN_CONFIG_CLASS"], };
          end
          if ( not TitanClanStaticArrays.sortMethod or TitanClanStaticArrays.sortMethod == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 42, LB["TITAN_CLAN_STATICARRAY_FIXED"]:format( "sortMethod" ) ); end
               TitanClanStaticArrays.sortMethod = { LB["TITAN_CLAN_CONFIG_ASCENDING"], LB["TITAN_CLAN_CONFIG_DESCENDING"], };
          end
          if ( not TitanClanLocals.LocalClass or TitanClanLocals.LocalClass == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 46, LB["TITAN_CLAN_LOCALSARRAY_FIXED"]:format( "LocalClass" ) ); end
               TitanClanLocals.LocalClass = {};
          end
          if ( not TitanClanLocals.ColorClass or TitanClanLocals.ColorClass == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 50, LB["TITAN_CLAN_LOCALSARRAY_FIXED"]:format( "ColorClass" ) ); end
               TitanClanLocals.ColorClass = {};
          end
          if ( not TitanClanLocals.ToEnglish or TitanClanLocals.ToEnglish == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 54, LB["TITAN_CLAN_LOCALSARRAY_FIXED"]:format( "ToEnglish" ) ); end
               TitanClanLocals.ToEnglish = {};
          end
          if ( not TitanClanGuild or TitanClanGuild ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 58, LB["TITAN_CLAN_ARRAY"]:format( "TitanClanGuild" ) ); end
               TitanClanGuild = {};
          end
          if ( not TitanClanDebug or TitanClanDebug == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 62, LB["TITAN_CLAN_ARRAY"]:format( "TitanClanDebug" ) ); end
               TitanClanDebug = {
                    State = false,
                    Event = false,
                    LogEvent = false,
                    dLine = "",
                    FormatToRemove = LB["TITAN_CLAN_CONFIG_NONE"], 
                    Temp = {},
                    Log = {},
               };
          end
          if ( not TitanClan.Settings or TitanClan.Settings == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 74, LB["TITAN_CLAN_ARRAY_FIXED"]:format( "Settings" ) ); end
               TitanClan.Settings = {
                    ShowMem = true,
                    DisplayB = true,
                    tFormat = "!s (!l) !uc ~ !z !r",
                    sFormat = ( "<%s>" ):format( LB["TITAN_CLAN_CONFIG_AWAY"] ),
                    dFormat = ( "<%s>" ):format( LB["TITAN_CLAN_CONFIG_DND"] ),
                    sType = LB["TITAN_CLAN_CONFIG_NAME"],
                    sMethod = LB["TITAN_CLAN_CONFIG_ASCENDING"],
                    maxTooltip = 30,
                    Version = LB["TITAN_CLAN_CORE_VERSION"],
                    ArrayVersion = LB["TITAN_CLAN_CORE_AVER"],
                    sessID = 0,
                    iCount = 0,
               };
          end
          if ( not TitanClan.AddAuth or TitanClan.AddAuth == nil ) then
               if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 89, LB["TITAN_CLAN_ARRAY_FIXED"]:format( "AddAuth" ) ); end
               TitanClan.AddAuth = {};
          end
          TitanClanInit = true;
          if ( checkDB ) then TitanClan_DebugUtils( "Info", "TitanClan", 93, LB["TITAN_CLAN_MENU_CHECKDB_FINSIHED"] ); end
     end
     TitanClanDebug.FormatToRemove = LB["TITAN_CLAN_CONFIG_NONE"];
end

-- **************************************************************************
-- NAME : TitanPanelClanButton_OnEvent()
-- DESC : Event Handler
-- **************************************************************************
function TitanPanelClanButton_OnEvent( self, event, ... )
     local arg1 = ...
     if ( event == "ADDON_LOADED" and arg1 == "TitanClan" ) then
          TitanClan_Init( "init" );
     elseif ( event == "PLAYER_ENTERING_WORLD" ) then
          TitanClan.Settings.sessID = 0;
          TitanClan.Settings.iCount = 0;
          if ( TitanClan.Settings.DisplayB ) then TitanClan_CoreUtils( "Banner" ); end
     elseif ( event == "PLAYER_CAMPING" ) then
          TitanClanStaticArrays.Stream = {};
          TitanClanProfile = nil;
     elseif ( event == "GUILD_RANKS_UPDATE" and IsInGuild() ) then
          TitanClan_GuildUtils( "buildRanks" );
     elseif ( event == "GUILD_ROSTER_UPDATE" and IsInGuild() ) then
          TitanClan_CoreUtils( "setUser" );
          TitanPanelButton_UpdateButton( LB["TITAN_CLAN_CORE_ID"] );
          TitanPanelButton_UpdateTooltip( self );
     end
     if ( not TitanClan.Settings.iCount or TitanClan.Settings.iCount < 6 ) then
          TitanClan_CoreUtils( "setIcon" );
     end
end

-- **************************************************************************
-- NAME : TitanPanelClanButton_GetButtonText()
-- DESC : Build Button Text
-- **************************************************************************
function TitanPanelClanButton_GetButtonText()
     local buttonRichText, buttonRichLabel, numT, numO, RnumT, RnumO;
     if ( IsInGuild() ) then
          numT, numO = GetNumGuildMembers();
          RnumT = TitanClan_ColorUtils( "cText", "white", numT );
          RnumO = TitanClan_ColorUtils( "cText", "green", numO );
          buttonRichLabel = LB["TITAN_CLAN_BUTTON_LABEL"]:format( GetGuildInfo( "player" ) );
          buttonRichText = LB["TITAN_CLAN_BUTTON_TEXT"]:format( RnumO, RnumT );
     else
          buttonRichLabel = "";
          buttonRichText = LB["TITAN_CLAN_BUTTON_CLANLESS"];
     end
     return buttonRichLabel, buttonRichText;
end

-- **************************************************************************
-- NAME : TitanPanelClanButton_OnClick()
-- DESC : Toggles Friends Dialog
-- **************************************************************************
function TitanPanelClanButton_OnClick( self, button )
     if ( button == "LeftButton" ) then
          ToggleGuildFrame();
     else
          TitanPanelButton_OnClick( self, button );
     end
end