local L = LibStub("AceLocale-3.0"):NewLocale("Titan","enUS",true)

-- English (Default)
L["TITAN_DEFENSE_STRINGS_MODNAME"] = "Titan Panel [Defense]";
L["TITAN_DEFENSE_STRINGS_MODDESC"] = "Summarize WorldDefense spam for Titan Panel";
L["TITAN_DEFENSE_STRINGS_BARFRAMENAME"] = "TitanPanelDefenseButton";
L["TITAN_DEFENSE_STRINGS_MENUTEXT"] = "Titan Defense";
L["TITAN_DEFENSE_STRINGS_TOOLTIP"] = "Titan Defense";
L["TITAN_DEFENSE_STRINGS_ZONEATTACKSEARCH"] = string.gsub(ZONE_UNDER_ATTACK, "%%[^%s]+", "(.+)") -- "|cffffff00%s is under attack!|r";
L["TITAN_DEFENSE_STRINGS_NEWZONE1"] = "TitanDefense: New subzone found ";
L["TITAN_DEFENSE_STRINGS_NEWZONE2"] = ", please send your WTF\Account\<username>\TitanDefense.lua file which includes the TitanDefense_newSubzones variable block to honorgog@titanpanel.org!";
L["TITAN_DEFENSE_STRINGS_WDCHANNAME"] = "WorldDefense";
L["TITAN_DEFENSE_STRINGS_LDCHANNAME"] = "LocalDefense";
L["TITAN_DEFENSE_STRINGS_ATTACKTEXT"] = "1 Attack";
L["TITAN_DEFENSE_STRINGS_ATTACKSTEXT"] = " Attacks";
L["TITAN_DEFENSE_STRINGS_NOATTACKS"] = "No Attacks";
L["TITAN_DEFENSE_STRINGS_SECONDS"] = " sec";
L["TITAN_DEFENSE_STRINGS_MINUTES"] = " min";
L["TITAN_DEFENSE_STRINGS_HOUR"] = " hour";
L["TITAN_DEFENSE_STRINGS_SZTIMETITLE"] = "Most Recently Attacked Subzones";
L["TITAN_DEFENSE_STRINGS_ZTIMETITLE"] = "Most Recently Attacked Zones";
L["TITAN_DEFENSE_STRINGS_SZFRQTITLE"] = "Most Frequently Attacked Subzones";
L["TITAN_DEFENSE_STRINGS_ZFRQTITLE"] = "Most Frequently Attacked Zones";
L["TITAN_DEFENSE_STRINGS_LOCALHEADER"] = "|cffff0000Local|r: ";
L["TITAN_DEFENSE_STRINGS_AGOENDER"] = " ago";
L["TITAN_DEFENSE_STRINGS_UNKNOWNZONE"] = "Unknown Zone";
