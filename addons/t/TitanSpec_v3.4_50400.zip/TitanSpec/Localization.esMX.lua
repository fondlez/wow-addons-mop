﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","esMX",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Cambiar Conjunto de Equipaje" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "Cambiar la Especialización Botín" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "Cambiar la Especialización" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Cambiar la Especialización y Conjunto de Equipaje" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "Conjunto de equipaje"
L["TITAN_SPEC_HINT"] = "Consejo: Clic-izquierdo para cambiar especialización y equipo.\n     Shift + Clic-izquierdo solo para cambiar especialización activa.\n     Alt + Clic-izquierdo solo para cambiar de equipo.\n     Ctrl + Clic-izquierdo para cambiar la especialización botín." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "Mostrar Pista" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Mostrar los Nombres Completos" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Mostrar el Número de Especialización Sólo" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "El Talento de Construir" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Mostrar fila" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Información de Talentos"

end
