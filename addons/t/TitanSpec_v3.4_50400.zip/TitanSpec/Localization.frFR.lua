﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","frFR",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Contacteur de marche" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "Passer Spécialisation de Butin" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "Mettez spécialisation" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Mettez spécialisation et de vitesse" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "Set d'équipement"
L["TITAN_SPEC_HINT"] = "Astuce : Clic gauche pour changer de spécialisation et d'équipement.\n     Maj + Clic gauche pour changer de spécialisation active.\n     Alt + Clic gauche pour changer l'équipement.\n     Ctrl + cliquez pour changer la spécialisation de butin." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "Afficher les conseils" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Afficher les noms complets" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Afficher le numéro de spécialisation uniquement" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "Montrer le talent construire" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Montrer niveaux" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Infos talents"


end
