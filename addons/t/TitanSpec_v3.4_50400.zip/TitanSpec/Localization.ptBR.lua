﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","ptBR",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Trocar Equipamentos" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "Mudar Especialização Saque" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "Mudar Especialização" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Mudar de Especialização e Equipamentos" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "Equipamento" -- Needs review
L["TITAN_SPEC_HINT"] = "Dica: Clique com o botão esquerdo para mudar a especialização e os equipamentos.\n     Shift + botão esquerdo para alterar apenas specialização.\n     Alt + botão esquerdo para mudar apenas os equipamentos.\n     Ctrl + botão esquerdo para mudar especialização saque." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "Mostrar Dica" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Mostrar Nomes Completos" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Mostrar Apenas o Número da Especialização" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "Mostrar Arvore de Talentos" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Mostram Níveis" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Informações do Talento" -- Needs review

end
