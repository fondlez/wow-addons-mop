﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","zhCN",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "开关设备" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "切换战利品专业化" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "切换专业化" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "切换专业化和设备" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "换装"
L["TITAN_SPEC_HINT"] = "左键 转换天赋和换装.\n     Shift + 左键 转换天赋.\n     Alt + 单击要更改的设备.\n     Ctrl + 左键点击改变战利品专业化." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "显示提示" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "显示全名" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "只显示专业化号" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "显示人才建设" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "显示层" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "天赋信息"

end
