﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","zhTW",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "開關設備" -- Needs review
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "切換戰利品專業化" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "切換專業化" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "切換專業化和設備" -- Needs review
L["TITAN_SPEC_GEAR_SET"] = "換裝"
L["TITAN_SPEC_HINT"] = "左鍵 轉換天賦和換裝.\n     Shift + 提示: 左鍵 轉換天賦.\n     Alt + 單擊要更改的設備.\n     Ctrl + 左鍵點擊改變戰利品專業化." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "顯示提示" -- Needs review
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "顯示全名" -- Needs review
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "只顯示專業化號" -- Needs review
L["TITAN_SPEC_SHOW_TALENTS"] = "顯示人才建設" -- Needs review
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "顯示層" -- Needs review
L["TITAN_SPEC_TOOLTIP_TITLE"] = "天賦信息"


end
