-- ************************************************************************** --
-- * TitanSpec.lua                                                         
-- *                                                                        
-- * Original Author: Rothpada   
-- * Maintainer: Nasapunk88                                                       
-- ************************************************************************** --

local TITAN_SPEC_ID = "TitanSpec";
local TITANSPEC_MENUTEXT = "DualSpec"; --L["TITAN_SPEC_MENU_TEXT"] independent on language now
local TITANSPEC_VERSION = GetAddOnMetadata("TitanSpec", "Version") or "Unknown Version"
local L = LibStub("AceLocale-3.0"):GetLocale("TitanSpec", true);
local LT = LibStub("AceLocale-3.0"):GetLocale("Titan", true);
local TITANSPEC_BUTTON_ICON = "Interface\\AddOns\\TitanSpec\\TitanSpec";
local AceTimer = LibStub("AceTimer-3.0"); 
local IS_DEBUGGING = ( UnitName("player") == "XXXXXX" and GetRealmName() == "Shadowsong" )
						or ( UnitName("player") == "XXXXX" and GetRealmName() == "Uther" );
						
--Key Bindings
BINDING_HEADER_TITAN_SPEC = TITANSPEC_MENUTEXT;--L["TITAN_SPEC_MENU_TEXT"];
BINDING_NAME_TITAN_SPEC_SPEC_GEAR = L["TITAN_SPEC_BINDINGS_SPEC_GEAR"];
BINDING_NAME_TITAN_SPEC_SPEC = L["TITAN_SPEC_BINDINGS_SPEC"];
BINDING_NAME_TITAN_SPEC_GEAR = L["TITAN_SPEC_BINDINGS_GEAR"];
BINDING_NAME_TITAN_SPEC_LOOT_SPEC = L["TITAN_SPEC_BINDINGS_LOOT_SPEC"];
BINDING_NAME_TITAN_SPEC_SHOW_HELM = SHOW_HELM;


local TitanSpec_Icon = "";
local TitanSpec_Equipped = "";
local TitanSpec_BuildName = {"","",};
local TitanSpec_Primary_Icon = "";
local TitanSpec_Secondary_Icon = "";
local TitanSpec_RotateSet = 1;
local TitanSpec_SwitchGear = true;
local TitanSpec_LootSpec = 0;
local TitanSpec_LootSpecIds = {"","","","",};
local TitanSpec_Timer = false;
local TitanSpec_locked = false;

-- ************************************************************************** --
-- ******************************** Spec Change Chat Filter ************************* --
-- ************************************************************************** --
local f = CreateFrame"Frame" 

local orgSetActiveSpecGroup = _G.SetActiveSpecGroup 

local spam1 = gsub(ERR_LEARN_ABILITY_S:gsub("%.", "%."), "%%s", "(.*)") 
local spam2 = gsub(ERR_LEARN_SPELL_S:gsub("%.", "%."), "%%s", "(.*)") 
local spam3 = gsub(ERR_SPELL_UNLEARNED_S:gsub("%.", "%."), "%%s", "(.*)") 
local spam4 = gsub(ERR_LEARN_PASSIVE_S:gsub("%.", "%."), "%%s", "(.*)") 

local function SpamFilter(self, event, msg) 
    if strfind(msg, spam1) or strfind(msg, spam2) or strfind(msg, spam3) or strfind(msg, spam4) then return true end 
end 

function SetActiveSpecGroup(...) 
    f:RegisterEvent"UNIT_SPELLCAST_SUCCEEDED" 
    f:RegisterEvent"UNIT_SPELLCAST_STOP" 
    ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", SpamFilter) 
    return orgSetActiveSpecGroup(...) 
end 

f:SetScript("OnEvent", function(self, event, unit) 
    if unit ~= "player" then return end 
    self:UnregisterEvent"UNIT_SPELLCAST_SUCCEEDED" 
    self:UnregisterEvent"UNIT_SPELLCAST_STOP" 
    ChatFrame_RemoveMessageEventFilter("CHAT_MSG_SYSTEM", SpamFilter) 
end)  															
								
-- ************************************************************************** --
-- ******************************** Titan Functions ************************* --
-- ************************************************************************** --

function TitanPanelTitanSpecButton_OnLoad(self)
	self.registry = {
		id = TITAN_SPEC_ID,
		version = TITANSPEC_VERSION,
		menuText = TITANSPEC_MENUTEXT,
		buttonTextFunction = "TitanPanelTitanSpecButton_GetButtonText",
		tooltipTitle = L["TITAN_SPEC_TOOLTIP_TITLE"],
		tooltipTextFunction = "TitanPanelTitanSpecButton_GetTooltipText",
		controlVariables = {
			ShowIcon = true,
			ShowLabelText = true,
			DisplayOnRightSide = true;
			--ShowRegularText = false,
			--ShowColoredText = true,
		},
		savedVariables = {
			DisplayOnRightSide = false,
			ShowIcon = true,
			ShowLabelText = true,
			ShowNumberOnly = false,
			ShowColours = true,
			ShowGearSet = true,
			ShowSpec = true,
			ShowHint = true,
			ShowTooltipIcon = true,
			ShowLongTalent = false,
			ShowTalents = true,
			ShowLootSpec = true;
			ShowLootSpecIcon = false;
		}	
	};
	self:RegisterEvent("ADDON_LOADED");
    --self:RegisterEvent("PLAYER_LOGOUT");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED");
	self:RegisterEvent("EQUIPMENT_SETS_CHANGED");
	self:RegisterEvent("PLAYER_EQUIPMENT_CHANGED");
	self:RegisterEvent("PLAYER_TALENT_UPDATE");
	self:RegisterEvent("PLAYER_LOOT_SPEC_UPDATED");
	
	--TitanSpec_output(TITAN_SPEC_ID.." by Rothpada (Shadow Council)");
	TitanPanelButton_UpdateButton(TITAN_SPEC_ID);
	TitanPanelPluginHandle_OnUpdate({TITAN_SPEC_ID, TITAN_PANEL_UPDATE_ALL});
	AceTimer.ScheduleTimer(TITAN_SPEC_ID, function() 
            TitanSpec_refresh();
            TitanPanelPluginHandle_OnUpdate({TITAN_SPEC_ID, TITAN_PANEL_UPDATE_ALL});
        end, 6);
end

function TitanPanelTitanSpecButton_OnClick(self, button)
	if ( button == "LeftButton" ) then
		if ( GetNumSpecGroups() > 1 ) then
				if ( IsShiftKeyDown() ) then
						TitanSpec_Toggle_Spec();
				elseif ( IsAltKeyDown() ) then
						TitanSpec_Toggle_Gear();
				elseif ( IsControlKeyDown() ) then
						TitanSpec_Toggle_Loot_Spec();
				else
						TitanSpec_Toggle_Spec_Gear();
				end
		else
			if ( IsAltKeyDown() ) then
				TitanSpec_Toggle_Gear();
			end
			if ( IsControlKeyDown() ) then
				TitanSpec_Toggle_Loot_Spec();
			end
		end
	end
end

function TitanPanelTitanSpecButton_OnEvent(self, event, ...)
	if event == "ADDON_LOADED" and ... == "TitanSpec" then
		TitanSpec_ShowHelm = TitanSpec_ShowHelm or {"","",};
		TitanSpec_EquipmentSet = TitanSpec_EquipmentSet or {"","",};
		TitanSpec_CustomLabel = TitanSpec_CustomLabel or {"","",};
		TitanSpec_TalentSet = TitanSpec_TalentSet or {{"","","","","","",},{"","","","","","",},};
		TitanSpec_ShowSelectTalents = TitanSpec_ShowSelectTalents or {{1,1,1,1,1,1},{1,1,1,1,1,1,},};
		TitanSpec_ShowTalents = TitanSpec_ShowTalents or {0,0,};
		TitanSpec_ShowLongTalents = TitanSpec_ShowLongTalents or {0,0,};
		TitanSpec_getLootSpecs();
		self:UnregisterEvent("ADDON_LOADED");
    elseif event == "ACTIVE_TALENT_GROUP_CHANGED" then
		TitanSpec_toggleHelm();
		if ( TitanSpec_SwitchGear) then
			if ( TitanSpec_EquipmentSet ~= nil and 
					TitanSpec_EquipmentSet[GetActiveSpecGroup()] ~= nil and 
					TitanSpec_EquipmentSet[GetActiveSpecGroup()] ~= "" ) then
							UseEquipmentSet(TitanSpec_EquipmentSet[GetActiveSpecGroup()]);
							TitanSpec_Equipped = TitanSpec_EquipmentSet[GetActiveSpecGroup()];
			end
		else
			TitanSpec_SwitchGear = true;
		end
	elseif event == "EQUIPMENT_SETS_CHANGED" then
		CheckGearSets();
	elseif event == "PLAYER_LOOT_SPEC_UPDATED" then
		AceTimer.ScheduleTimer(TITAN_SPEC_ID, function() 
			if ( TitanSpec_LootSpec == 0 ) then
				lootSpecName = format( LOOT_SPECIALIZATION_DEFAULT , TitanSpec_BuildName[GetActiveSpecGroup()]);
				TitanSpec_output(TitanSpec_getColouredText(format(ERR_LOOT_SPEC_CHANGED_S,lootSpecName),"yellow"));
			end
		end, 2);
	end
	TitanSpec_refresh();
end

function TitanSpec_refresh()	
	--TitanSpec_debug("Refreshing...");
	--Update Build Names
	if (TitanSpec_BuildName ~=nil or TitanSpec_BuildName ~= "") then
		TitanSpec_BuildName[1] = TitanSpec_getBuildName(1);
		TitanSpec_BuildName[2] = TitanSpec_getBuildName(2);
	end
	TitanSpec_LootSpec = GetLootSpecialization();
	
	--Update Spec Icon
	TitanSpec_Primary_Icon = TitanSpec_getBuildIcon(1);
	TitanSpec_Secondary_Icon = TitanSpec_getBuildIcon(2);
	--Update Currently Equipped Set
	TitanSpec_Equipped = TitanSpec_getEquipped();
	TitanSpec_getTalentNames();
	TitanPanelButton_UpdateButton(TITAN_SPEC_ID);
end

function TitanSpec_toggleHelm()
	if ( TitanSpec_ShowHelm[GetActiveSpecGroup()] ~= "" ) then
			if (TitanSpec_ShowHelm[GetActiveSpecGroup()] == "show") then
				ShowHelm(true);
			else
				ShowHelm(false);
			end
	end
end

--Store the spec id's
function TitanSpec_getLootSpecs()
	local classID = select(3,UnitClass("player"));
	local specMax = 3;
	if ( classID == 11 ) then
		specMax = 4;
	end
	TitanSpec_LootSpecIds[0] = 0;
	for i=1,specMax do
		TitanSpec_LootSpecIds[i] = select(1,GetSpecializationInfoForClassID(classID, i));
	end
end
--Return the spec name for the specnumber given
--specName = GetSpecializationNameForClassID(classId, specIndex) NEW
function TitanSpec_getBuildName(index) 		
	local g = GetSpecialization(false,false,index);
	if ( g ~= nil ) then
		return select(2,GetSpecializationInfo(g))
	else 
		return "";
	end
end

--Return the spec icon for the specnumber given
function TitanSpec_getBuildIcon(index) 		
	local g = GetSpecialization(false,false,index);
	if ( g ~= nil ) then
		return select(4,GetSpecializationInfo(g));
	else 
		return "";
	end
end

--Return the name of currently equipped set
function TitanSpec_getEquipped() 
	local numSets = GetNumEquipmentSets();
	for i=1,numSets do
		local name, _, _, isEquipped, _, _, _, _, _ = GetEquipmentSetInfo(i);
		if (isEquipped) then
			return name;
		end
	end
	return "";	
end
--Get TalentNames for each spec
function TitanSpec_getTalentNames()
	local g = GetSpecialization(false,false,1);
	if ( g ~= nil ) then
		TitanSpec_getTalentNamesForSpec(1);
	end
	g = GetSpecialization(false,false,2);
	if ( g ~= nil ) then
		TitanSpec_getTalentNamesForSpec(2);
	end
end

--Fill TalentNames Table for spec
function TitanSpec_getTalentNamesForSpec(index)
	local num = GetNumTalents(index);
	local i = 1;
	while i<num do
		local talentname1,_,tier1,_,chosen1,_ = GetTalentInfo(i, false,index,nil,nil);
		local talentname2,_,tier2,_,chosen2,_ = GetTalentInfo((i+1), false,index,nil,nil);
		local talentname3,_,tier3,_,chosen3,_ = GetTalentInfo((i+2), false,index,nil,nil);
		if (chosen1) then
			TitanSpec_TalentSet[index][tier1] = talentname1;
		elseif (chosen2) then
			TitanSpec_TalentSet[index][tier2] = talentname2;
		elseif (chosen3) then
			TitanSpec_TalentSet[index][tier3] = talentname3;
		else
			TitanSpec_TalentSet[index][tier1] = "";
		end
		i = i+ 3;
	end
end

function TitanPanelTitanSpecButton_GetButtonText(id)
	local label = TITANSPEC_MENUTEXT;
	local buildText = "";
	--If they have no specialization then return DualSpec Title
	if ( TitanSpec_BuildName[1] == nil or TitanSpec_BuildName[1] == "") then
		--Add Equipment
		if ( TitanGetVar(TITAN_SPEC_ID, "ShowGearSet") and TitanSpec_Equipped ~= "") then
			buildText = TitanSpec_Equipped;
		end
		--Add LootSpec
		if ( TitanGetVar(TITAN_SPEC_ID, "ShowLootSpec")) then
			local lootSpecName = "";
			if ( TitanSpec_LootSpec == 0 ) then
				lootSpecName = CHAT_DEFAULT;
			else
				local _, lootname, _, looticon, _, _ = GetSpecializationInfoByID(TitanSpec_LootSpec);
				lootSpecName = lootname;
			end
			if ( buildText ~= "") then
				buildText = buildText.." ";
			end
			buildText = buildText.."|TInterface\\Minimap\\Tracking\\Banker:16|t"..lootSpecName;
		end
		--Append a colon if text comes after
		if ( buildText ~= "") then
				label = label..":";
		else
		--Add Default- no options selected text (DualSpec)
			if (TitanGetVar(TITAN_SPEC_ID, "ShowLabelText")) then
				buildText = "";
			else
				buildText = TITANSPEC_MENUTEXT;
			end
		end
		return label, TitanSpec_getColouredText(buildText, "white");
	end
	
	local specNum = GetActiveSpecGroup();
	--Add Button Label
	if ( specNum == 1 ) then
		label = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1;
	else
		label = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2;
	end

	--Add Spec
	if ( TitanGetVar(TITAN_SPEC_ID, "ShowSpec")) then
			-- Add Custom Name
			if ( TitanSpec_CustomLabel[specNum] == nil or TitanSpec_CustomLabel[specNum] == "" ) then
				buildText = " "..TitanSpec_BuildName[specNum];
			else
				--Else Add Default Name
				buildText = " "..TitanSpec_CustomLabel[specNum];
			end
	end
	--Add Talents
	local talent_text = "";
	if (TitanSpec_ShowTalents[specNum]==1) then
		local addedtalents = false
		--Loop through each tier talents
		for i=1,6 do
			if (TitanSpec_ShowSelectTalents[specNum][i] == 1 and TitanSpec_TalentSet[specNum][i] ~= "") then
				talent_text = talent_text..(addedtalents and ', ' or ' (');
				addedtalents = true;	
				--Check if it should show Long name
				if (TitanSpec_ShowLongTalents[specNum] == 1) then
					talent_text = talent_text..TitanSpec_TalentSet[specNum][i];
				else
					for word in string.gmatch(TitanSpec_TalentSet[specNum][i], "[^%s]+") do 
						talent_text = talent_text..string.match(word, string.match(TitanSpec_TalentSet[specNum][i],"[%s]+") and "^." or "^...")
					end
				end
			end
		end
		if (addedtalents) then 
			talent_text = talent_text..')' 
		end
		buildText = buildText..talent_text;
	end
		
	--Add Equipment
	if ( TitanGetVar(TITAN_SPEC_ID, "ShowGearSet")) then
		if ( TitanSpec_Equipped ~= "") then
			if ( TitanSpec_EquipmentSet[GetActiveSpecGroup()] ~= nil and
				TitanSpec_EquipmentSet[GetActiveSpecGroup()] ~= "" and 
				TitanSpec_EquipmentSet[GetActiveSpecGroup()] ~= TitanSpec_Equipped) then
				--Color text Red for "wrong" current gear
				buildText = format("%s [".."|cffff0000".."%s".."|cffffffff".."]", buildText, TitanSpec_Equipped);
			else
				buildText = format("%s [%s]", buildText, TitanSpec_Equipped);
			end
		end
	end
	
	--Add Icon
	if ( TitanGetVar(TITAN_SPEC_ID, "ShowIcon")) then
		local icon = "";
		if ( specNum == 1 ) then
			icon = "|T"..TitanSpec_Primary_Icon..":19|t";
		else
			icon = "|T"..TitanSpec_Secondary_Icon..":19|t";
		end
	    buildText = icon..buildText;
	end
	
	--Add LootSpec
	--Icon |TInterface\\Minimap\\Tracking\\Banker:16|t
	local lootSpecIcon = "";
	local lootSpecName = "";
	if ( TitanSpec_LootSpec == 0 ) then
		lootSpecName = CHAT_DEFAULT;
		if ( specNum == 1 ) then
			lootSpecIcon = "|T"..TitanSpec_Primary_Icon..":19|t";
		else
			lootSpecIcon = "|T"..TitanSpec_Secondary_Icon..":19|t";
		end
	else
		local _, lootname, _, looticon, _, _ = GetSpecializationInfoByID(TitanSpec_LootSpec);
		lootSpecName = lootname;
		lootSpecIcon = "|T"..looticon..":19|t";
	end
	-- Add LootIcon
	if ( TitanGetVar(TITAN_SPEC_ID, "ShowLootSpecIcon") ) then
		buildText = buildText.." "..lootSpecIcon.." ";
	else
		if ( TitanGetVar(TITAN_SPEC_ID, "ShowLootSpec")) then
			buildText = buildText.." |TInterface\\Minimap\\Tracking\\Banker:16|t";
		end
	end
	--Add LootSpec
	if ( TitanGetVar(TITAN_SPEC_ID, "ShowLootSpec")) then
		buildText = buildText..lootSpecName;
	end
	
	--Shorten to just number
	if (TitanGetVar(TITAN_SPEC_ID, "ShowNumberOnly")) then
		label = format("%d",specNum);
	end
	--Append a colon if text comes after
	if ( buildText ~= "") then
			label = label..":";
	else
	--Add Default- no options selected text (DualSpec)
		if (TitanGetVar(TITAN_SPEC_ID, "ShowLabelText")) then
			buildText = "";
		else
			buildText = TITANSPEC_MENUTEXT;
		end
	end
	return label, TitanSpec_getColouredText(buildText, "white");
end

function TitanPanelTitanSpecButton_GetTooltipText(self)
	local t1 = "";
	local t2 = "";
	--If They have atleast 1 spec
	if ( TitanSpec_BuildName[1] ~= nil and TitanSpec_BuildName[1] ~= "") then
		--Add Spec 1 Label and Icon
		if (TitanGetVar(TITAN_SPEC_ID, "ShowTooltipIcon")) then
			t1 = " |T"..TitanSpec_Primary_Icon..":20|t "..COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1..": ";	
		else
			t1 = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1..": ";
		end
		--Add Spec 1 Custom Label
		if (TitanSpec_CustomLabel[1] ~= nil and strtrim(TitanSpec_CustomLabel[1]) ~= "" ) then
			t1 = t1..TitanSpec_CustomLabel[1].." - ";
		end
		--Add Spec 1 Default Label
		if (TitanSpec_BuildName[1] ~= nil and strtrim(TitanSpec_BuildName[1]) ~= "" ) then
			t1 = t1..TitanSpec_BuildName[1];
		end
		--Add Equipment 1 Icon and Name
		local equipSet = "";
		local icon1 = select(1,GetEquipmentSetInfoByName(TitanSpec_EquipmentSet[1]));
		if ( TitanSpec_EquipmentSet[1] ~= nil and strtrim(TitanSpec_EquipmentSet[1]) ~= "" ) then
			equipSet = TitanSpec_getColouredText(L["TITAN_SPEC_GEAR_SET"]..": ", "white");
			if ( TitanGetVar(TITAN_SPEC_ID, "ShowColours")) then
				if ( GetActiveSpecGroup() == 1 and TitanSpec_EquipmentSet[1]  ~= TitanSpec_Equipped) then
					--Color text Red for "wrong" current gear
					equipSet = equipSet..TitanSpec_getColouredText(TitanSpec_EquipmentSet[1], "red");
				else
					equipSet = equipSet..TitanSpec_getColouredText(TitanSpec_EquipmentSet[1], "white");
				end
			else
				equipSet = equipSet..TitanSpec_getColouredText(TitanSpec_EquipmentSet[1], "white");
			end
			if (TitanGetVar(TITAN_SPEC_ID, "ShowTooltipIcon")) then
				equipSet = "|TInterface\\Icons\\"..icon1..":19|t  "..equipSet;
			end   
		end
		if (equipSet ~= "") then
			t1 = t1.."\n        "..equipSet;
		end
		
		--If they have Dual Spec
		if ( GetNumSpecGroups() == 2 ) then
			--Add Spec 2 Label and Icon
			if (TitanGetVar(TITAN_SPEC_ID, "ShowTooltipIcon")) then
				t2 = " |T"..TitanSpec_Secondary_Icon..":20|t "..COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2..": ";
			else
				t2 = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2..": ";
			end
			--Add Spec 2 Custom Label
			if (TitanSpec_CustomLabel[2] ~= nil and strtrim(TitanSpec_CustomLabel[2]) ~= "" ) then
				t2 = t2..TitanSpec_CustomLabel[2].." - ";
			end
			--Add Spec 2 Default Label
			if (TitanSpec_BuildName[2] ~= nil and strtrim(TitanSpec_BuildName[2]) ~= "" ) then
				t2 = t2..TitanSpec_BuildName[2];
			end
			--Add Equipment Icon and Name
			equipSet = "";
			local icon2 = select(1,GetEquipmentSetInfoByName(TitanSpec_EquipmentSet[2]));
			if ( TitanSpec_EquipmentSet[2] ~= nil and strtrim(TitanSpec_EquipmentSet[2]) ~= "" ) then
				equipSet = TitanSpec_getColouredText(L["TITAN_SPEC_GEAR_SET"]..": ", "white");
				if ( TitanGetVar(TITAN_SPEC_ID, "ShowColours")) then
					if ( GetActiveSpecGroup() == 2 and TitanSpec_EquipmentSet[2]  ~= TitanSpec_Equipped) then
						--Color text Red for "wrong" current gear
						equipSet = equipSet..TitanSpec_getColouredText(TitanSpec_EquipmentSet[2], "red");
					else
						equipSet = equipSet..TitanSpec_getColouredText(TitanSpec_EquipmentSet[2], "white");
					end
				else
					equipSet = equipSet..TitanSpec_getColouredText(TitanSpec_EquipmentSet[2], "white");
				end
				if (TitanGetVar(TITAN_SPEC_ID, "ShowTooltipIcon")) then
					equipSet = "|TInterface\\Icons\\"..icon2..":19|t  "..equipSet;
				end   
			end
			
			if (equipSet ~= "") then
				t2 = t2.."\n        "..equipSet;
			end
			
			--Color Text with Active Spec
			if ( TitanGetVar(TITAN_SPEC_ID, "ShowColours")) then
				if ( GetActiveSpecGroup() == 1) then
					t1 = TitanSpec_getColouredText(t1, "green");
					t2 = TitanSpec_getColouredText(t2, "yellow");
				else
					t1 = TitanSpec_getColouredText(t1, "yellow");
					t2 = TitanSpec_getColouredText(t2, "green");
				end
			end
		--No 2nd spec
		else
			--Color Text with no spec 2
			if ( TitanGetVar(TITAN_SPEC_ID, "ShowColours")) then
				t1 = TitanSpec_getColouredText(t1, "green");
				t2 = "";
			end
		end
	--No spec at all
	else
		--Color Red
		t1 = ERR_SPEC_WIPE_ERROR;
		if ( TitanGetVar(TITAN_SPEC_ID, "ShowColours")) then
			t1 = TitanSpec_getColouredText(t1, "red");
		end
		--Add Loot Spec
		local lootSpec = "";
		if ( TitanSpec_LootSpec == 0 ) then
			lootSpec = CHAT_DEFAULT;
		else
			local _, lootSpecName, _, icon, _, _ = GetSpecializationInfoByID(TitanSpec_LootSpec);
			lootSpec = lootSpecName;
		end
		lootSpec = "\n".."\n"..SELECT_LOOT_SPECIALIZATION..": "..lootSpec;
		--Add Hint
		local hint = "";
		if (TitanGetVar(TITAN_SPEC_ID, "ShowHint")) then
			hint = "\n".."\n"..L["TITAN_SPEC_HINT"];
		end
		return "  \n"..t1..lootSpec..hint;
	end
	
	--Combine text
	local tooltip = "";
	if (t2 == "") then
		tooltip = t1.."\n";
	else
		tooltip = t1.."\n \n"..t2.."\n";	
	end
	
	--Add LootSpec
	local lootSpec = "";
	if ( TitanSpec_LootSpec == 0 ) then
		lootSpec = format( LOOT_SPECIALIZATION_DEFAULT , TitanSpec_BuildName[GetActiveSpecGroup()]);
	else
		local _, lootSpecName, _, icon, _, _ = GetSpecializationInfoByID(TitanSpec_LootSpec);
		lootSpec = lootSpecName;
	end
	local lootSpecTxt = SELECT_LOOT_SPECIALIZATION..": ";
	--color text
	if ( TitanGetVar(TITAN_SPEC_ID, "ShowColours")) then
		--lootSpecTxt = TitanSpec_getColouredText(lootSpecTxt, "white");
		if (TitanSpec_LootSpec == 0 or TitanSpec_BuildName[GetActiveSpecGroup()] == lootSpec) then
			lootSpec = TitanSpec_getColouredText(lootSpec, "white");
		else
			lootSpec = TitanSpec_getColouredText(lootSpec, "red");
		end
	else
		lootSpec = TitanSpec_getColouredText(lootSpec, "white");
	end
	lootSpecTxt = "  \n"..lootSpecTxt..lootSpec;
	
	--Add Hint
	local hint = "";
	if (TitanGetVar(TITAN_SPEC_ID, "ShowHint")) then
		hint = "\n \n"..L["TITAN_SPEC_HINT"];
	end
	
	return "  \n"..tooltip..lootSpecTxt..hint;
end

function TitanPanelRightClickMenu_PrepareTitanSpecMenu()		
	--Level 3 Menu
	local info = {};
	if ( UIDROPDOWNMENU_MENU_LEVEL == 3 ) then
		--Talent Options
		if ( UIDROPDOWNMENU_MENU_VALUE == "Talent Options" ) then
			--title Spec 1
			info.text = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1;
			info.notClickable = 1;
			info.isTitle = 1;
			info.notCheckable = true;
			UIDropDownMenu_AddButton(info, 3);
			--Toggle Talents 1
			info = {};
			info.text = ENABLE;
			info.func = function()
				local show = TitanSpec_ShowTalents;
				show[1] = (show[1] + 1) % 2;
				TitanSpec_ShowTalents = show;
				TitanSpec_refresh();
			end
			info.checked = (TitanSpec_ShowTalents[1] == 1);
			info.keepShownOnClick = true;
			UIDropDownMenu_AddButton(info, 3);
			
			--Toggle Long Talents  1
			info = {};
			info.text = L["TITAN_SPEC_SHOW_LONG_TALENTS"];
			info.func = function()
				local show = TitanSpec_ShowLongTalents;
				show[1] = (show[1] + 1) % 2;
				TitanSpec_ShowLongTalents = show;
				TitanSpec_refresh();
			end
			info.checked = (TitanSpec_ShowLongTalents[1] == 1);
			info.keepShownOnClick = true;
			UIDropDownMenu_AddButton(info, 3);
			--Toggle for Tiers 1
			for i=1,6 do
				if (TitanSpec_ShowSelectTalents[1][i] ~= nil and TitanSpec_TalentSet[1][i] ~= "") then
					info = {};
					info.text = format(L["TITAN_SPEC_SHOW_TALENT_TIER"], i);
					info.func = function()
							local show = TitanSpec_ShowSelectTalents[1];
							show[i] = (show[i] + 1) % 2;
							TitanSpec_ShowSelectTalents[1] = show;
							TitanSpec_refresh();
					end
					info.checked = (TitanSpec_ShowSelectTalents[1][i] == 1);
					info.keepShownOnClick = true;
					UIDropDownMenu_AddButton(info, 3);
				end
			end
			--If they have a 2nd spec
			if (GetNumSpecGroups() == 2) then
				TitanPanelRightClickMenu_AddSpacer(3);
				--Title Spec 2
				info = {};
				info.text = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2;
				info.notClickable = 1;
				info.isTitle = 1;
				info.notCheckable = true;
				UIDropDownMenu_AddButton(info, 3);
				--Toggle Talents 2
				info = {};
				info.text =ENABLE;
				info.func = function()
					local show = TitanSpec_ShowTalents;
					show[2] = (show[2] + 1) % 2;
					TitanSpec_ShowTalents = show;
					TitanSpec_refresh();
				end
				info.checked = (TitanSpec_ShowTalents[2] == 1);
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 3);
				
				--Toggle Long Talents  2
				info = {};
				info.text = L["TITAN_SPEC_SHOW_LONG_TALENTS"];
				info.func = function()
					local show = TitanSpec_ShowLongTalents;
					show[2] = (show[2] + 1) % 2;
					TitanSpec_ShowLongTalents = show;
					TitanSpec_refresh();
				end
				info.checked = (TitanSpec_ShowLongTalents[2] == 1);
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 3);
				--Toggle for Tiers 1
				for i=1,6 do
					if (TitanSpec_ShowSelectTalents[2][i] ~= nil and TitanSpec_TalentSet[2][i] ~= "") then
						info = {};
						info.text = format(L["TITAN_SPEC_SHOW_TALENT_TIER"], i);
						info.func = function()
								local show = TitanSpec_ShowSelectTalents[2];
								show[i] = (show[i] + 1) % 2;
								TitanSpec_ShowSelectTalents[2] = show;
								TitanSpec_refresh();
						end
						info.checked = (TitanSpec_ShowSelectTalents[2][i] == 1);
						info.keepShownOnClick = true;
						UIDropDownMenu_AddButton(info, 3);
					end
				end
			end
		end
		return;
	end
	--Level 2 Menu
	if ( UIDROPDOWNMENU_MENU_LEVEL == 2 ) then
		--Assign Set 1
		if ( UIDROPDOWNMENU_MENU_VALUE == "TITAN_SPEC_ASSIGN_EQUIPMENT_SET" ) then
				--Title
				info = {};
				info.text = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1.." - "..TitanSpec_BuildName[1];
				info.notClickable = 1;
				info.isTitle = 1;
				info.notCheckable = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--None
				info = {};
				info.text = "<"..NONE..">";
				info.func = function()
					TitanSpec_EquipmentSet[1] = "";
					TitanSpec_refresh();
				end
				info.checked = (TitanSpec_EquipmentSet[1] == "");
				UIDropDownMenu_AddButton(info, 2);
				
		        local numSets = GetNumEquipmentSets();
		        for i=1,numSets do
		                local setName = select(1,GetEquipmentSetInfo(i));
		                info = {};
						info.text = setName;
						if ( TitanSpec_EquipmentSet[1] == setName ) then
								info.text = "|cff00ff00"..info.text..FONT_COLOR_CODE_CLOSE;
								info.checked = true;
						end
		                info.func = function()
                                    TitanSpec_EquipmentSet[1] = setName;
									if (setName == TitanSpec_Equipped) then
										TitanSpec_refresh();
									else 
										if (GetActiveSpecGroup() == 1) then
											UseEquipmentSet(setName);
											TitanSpec_Equipped = setName;
										end
									end
		                end
		                UIDropDownMenu_AddButton(info, 2);
		        end
		end
		--Assing Set 2
		if ( UIDROPDOWNMENU_MENU_VALUE == "TITAN_SPEC_ASSIGN_EQUIPMENT_SET_2" ) then
					--Title
					info = {};
					info.text = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2.." - "..TitanSpec_BuildName[2];
					info.notClickable = 1;
					info.isTitle = 1;
					info.notCheckable = true;
					UIDropDownMenu_AddButton(info, 2);
					--None
					info = {};
					info.text = "<"..NONE..">";
					info.func = function()
						TitanSpec_EquipmentSet[2] = "";
						TitanSpec_refresh();
					end
					info.checked = (TitanSpec_EquipmentSet[2] == "");
					UIDropDownMenu_AddButton(info, 2);
					
					local numSets = GetNumEquipmentSets();
					for i=1,numSets do
							local setName = select(1,GetEquipmentSetInfo(i));
							info = {};
							info.text = setName;
							if ( TitanSpec_EquipmentSet[2] == setName ) then
									info.text = "|cff00ff00"..info.text..FONT_COLOR_CODE_CLOSE;
									info.checked = true;
							end
							info.func = function()
										TitanSpec_EquipmentSet[2] = setName;
										if (setName == TitanSpec_Equipped) then
											TitanSpec_refresh();
										else 
											if (GetActiveSpecGroup() == 2) then
												UseEquipmentSet(setName);
												TitanSpec_Equipped = setName;
											end
										end
							end
							UIDropDownMenu_AddButton(info, 2);
					end
		end
		--Equip Set
        if ( UIDROPDOWNMENU_MENU_VALUE == "TITAN_SPEC_EQUIP_EQUIPMENT_SET" ) then
					info = {};
					info.text = EQUIPSET_EQUIP;
					info.notClickable = 1;
					info.isTitle = 1;
					info.notCheckable = true;
					UIDropDownMenu_AddButton(info, 2);
					info = {};
					local numSets = GetNumEquipmentSets();
					for i=1,numSets do
							local setName = select(1,GetEquipmentSetInfo(i));
							info = {};
							info.text = setName;
							info.notCheckable = true;
							info.func = function()
									if (setName == TitanSpec_Equipped) then
										TitanSpec_refresh();
									else
										UseEquipmentSet(setName);
										TitanSpec_Equipped = setName;
									end
							end
							UIDropDownMenu_AddButton(info, 2);
					end
		end
		--Button Options
		if (UIDROPDOWNMENU_MENU_VALUE == "Button Options") then
				--Title
				info = {};
				info.text = LT["TITAN_PANEL_OPTIONS"]..": "..LT["TITAN_XP_MENU_SIMPLE_BUTTON_TITLE"];
				info.notClickable = 1;
				info.isTitle = 1;
					info.notCheckable = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--Label Text
				info = {};
				info.text = LT["TITAN_PANEL_MENU_SHOW_LABEL_TEXT"];
				info.func = function()
					local label = not TitanGetVar(TITAN_SPEC_ID,"ShowLabelText");
					TitanSetVar(TITAN_SPEC_ID, "ShowLabelText", label);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowLabelText");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--Label Only Number
				info = {};
				info.text = L["TITAN_SPEC_SHOW_NUMBER_ONLY"];
				info.func = function()
					local label = not TitanGetVar(TITAN_SPEC_ID,"ShowNumberOnly");
					TitanSetVar(TITAN_SPEC_ID, "ShowNumberOnly", label);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowNumberOnly") ;
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);

				--Icon
				info = {};
				info.text = LT["TITAN_PANEL_MENU_SHOW_ICON"];
				info.func = function()
					local icon = not TitanGetVar(TITAN_SPEC_ID,"ShowIcon");
					TitanSetVar(TITAN_SPEC_ID, "ShowIcon", icon);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowIcon");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--Spec
				info = {};
				info.text = SHOW.." "..NAME;
				info.func = function()
					local spec = not TitanGetVar(TITAN_SPEC_ID,"ShowSpec");
					TitanSetVar(TITAN_SPEC_ID, "ShowSpec", spec);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowSpec");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--GearSet
				info = {};
				info.text = SHOW.." "..CURRENTLY_EQUIPPED;
				info.func = function()
					local gear = not TitanGetVar(TITAN_SPEC_ID,"ShowGearSet");
					TitanSetVar(TITAN_SPEC_ID, "ShowGearSet", gear);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowGearSet");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--LootSpec
				info = {};
				info.text = SHOW.." "..SELECT_LOOT_SPECIALIZATION;
				info.func = function()
					local lootSpec = not TitanGetVar(TITAN_SPEC_ID,"ShowLootSpec");
					TitanSetVar(TITAN_SPEC_ID, "ShowLootSpec", lootSpec);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowLootSpec");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--LootSpecIcon
				info = {};
				info.text = SHOW.." "..SELECT_LOOT_SPECIALIZATION.." "..EMBLEM_SYMBOL;
				info.func = function()
					local lootSpecIcon = not TitanGetVar(TITAN_SPEC_ID,"ShowLootSpecIcon");
					TitanSetVar(TITAN_SPEC_ID, "ShowLootSpecIcon", lootSpecIcon);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowLootSpecIcon");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--If They have atleast 1 spec
				if ( TitanSpec_BuildName[1] ~= nil and TitanSpec_BuildName[1] ~= "") then
					--Talents
					info = {};
					info.text = L["TITAN_SPEC_SHOW_TALENTS"];
					info.value = "Talent Options";
					info.hasArrow = 1;
					info.notCheckable = true;
					-- info.func = function()
						-- local talents = not TitanGetVar(TITAN_SPEC_ID,"ShowTalents");
						-- TitanSetVar(TITAN_SPEC_ID, "ShowTalents", talents);
						--Enable ShowTalent for Current Spec
						-- if (talents) then 
							-- TitanSpec_ShowTalents[GetActiveSpecGroup()] = 1;
						-- end
						-- TitanSpec_refresh();
					-- end
					--info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowTalents");
					info.keepShownOnClick = true;
					UIDropDownMenu_AddButton(info, 2);
				end
        end
		--Tooltip Options
		if (UIDROPDOWNMENU_MENU_VALUE == "Tooltip Options") then
				--Title
				info = {};
				info.text = LT["TITAN_PANEL_OPTIONS"]..": "..LT["TITAN_TRANS_CONTROL_TITLE_TOOLTIP"];
				info.notClickable = 1;
				info.isTitle = 1;
				info.notCheckable = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--Color
				info = {};
				info.text = LT["TITAN_PANEL_MENU_SHOW_COLORED_TEXT"];
				info.func = function()
					local colors = not TitanGetVar(TITAN_SPEC_ID,"ShowColours");
					TitanSetVar(TITAN_SPEC_ID, "ShowColours", colors);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowColours");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
				
				--Icons
				info = {};
				info.text = LT["TITAN_PANEL_MENU_SHOW_ICON"];
				info.func = function()
					local colors = not TitanGetVar(TITAN_SPEC_ID,"ShowTooltipIcon");
					TitanSetVar(TITAN_SPEC_ID, "ShowTooltipIcon", colors);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowTooltipIcon");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);

				--Hint
				info = {};
				info.text = L["TITAN_SPEC_SHOW_HINT"];
				info.func = function()
					local hint = not TitanGetVar(TITAN_SPEC_ID,"ShowHint");
					TitanSetVar(TITAN_SPEC_ID, "ShowHint", hint);
					TitanSpec_refresh();
				end
				info.checked = TitanGetVar(TITAN_SPEC_ID,"ShowHint");
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info, 2);
		end
		return;
	end
	-- Level 1 menu
	if ( UIDROPDOWNMENU_MENU_LEVEL == 1 ) then
		--Title
		TitanPanelRightClickMenu_AddTitle(TitanPlugins[TITAN_SPEC_ID].menuText);
		
		--Rename if they have a specialization
		if ( TitanSpec_BuildName[1] ~= nil and TitanSpec_BuildName[1] ~= "") then
			TitanPanelRightClickMenu_AddSpacer();
			TitanPanelRightClickMenu_AddTitle(PET_RENAME);
			--Rename Spec 1
			info = {};
			info.text = SPECIALIZATION_PRIMARY;
			info.notCheckable = true;
			info.func = function(self)
					StaticPopupDialogs["TITAN_SPEC_RENAME_DIALOG"] = {
					  text = PET_RENAME..": "..COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1.." - "..TitanSpec_BuildName[1],
					  button1 = ACCEPT,
					  button2 = CANCEL,
					  OnAccept = function (self, ...)
							local newName = self.editBox:GetText();
							local labels = TitanSpec_CustomLabel;
							labels[1] = newName;
							TitanSpec_CustomLabel = labels;
							TitanSpec_refresh();
					  end,
					  timeout = 0,
					  whileDead = 1,
					  hideOnEscape = 1,
					  hasEditBox = 1,
					  enterClicksFirstButton = 1
					};
					StaticPopup_Show("TITAN_SPEC_RENAME_DIALOG");
			end
			UIDropDownMenu_AddButton(info,1);
			
			--If they have Dual Spec
			if ( GetNumSpecGroups() == 2 ) then 
				--Rename Spec 2
				info = {};
				info.text = SPECIALIZATION_SECONDARY;
				info.notCheckable = true;
				info.func = function(self)
						StaticPopupDialogs["TITAN_SPEC_RENAME_DIALOG_2"] = {
						  text = PET_RENAME..": "..COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2.." - "..TitanSpec_BuildName[2],
						  button1 = ACCEPT,
						  button2 = CANCEL,
						  OnAccept = function (self, ...)
								local newName = self.editBox:GetText();
								local labels = TitanSpec_CustomLabel;
								labels[2] = newName;
								TitanSpec_CustomLabel = labels;
								TitanSpec_refresh();
						  end,
						  timeout = 0,
						  whileDead = 1,
						  hideOnEscape = 1,
						  hasEditBox = 1,
						  enterClicksFirstButton = 1
						};
						StaticPopup_Show("TITAN_SPEC_RENAME_DIALOG_2");
				end
				UIDropDownMenu_AddButton(info,1);
			end
		end
		--Assign Equipment
		if ( GetNumEquipmentSets() > 0 ) then
			TitanPanelRightClickMenu_AddSpacer();
			TitanPanelRightClickMenu_AddTitle(GEARSETS_TITLE);
			--If they have Dual Spec
			if ( GetNumSpecGroups() == 2 ) then 
				--Assign Equipment 1
				info = {};
				info.text = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC1;
				info.value = "TITAN_SPEC_ASSIGN_EQUIPMENT_SET";
				info.notCheckable = true;
				info.hasArrow = 1;
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info,1);
				--Assign Equipment 2
				info = {};
				info.text = COMPACT_UNIT_FRAME_PROFILE_AUTOACTIVATESPEC2;
				info.value = "TITAN_SPEC_ASSIGN_EQUIPMENT_SET_2";
				info.hasArrow = 1;
				info.notCheckable = true;
				info.keepShownOnClick = true;
				UIDropDownMenu_AddButton(info,1);
			end
			
			--Equip
			info = {};
			info.text = EQUIPSET_EQUIP;
			info.value = "TITAN_SPEC_EQUIP_EQUIPMENT_SET";
			info.hasArrow = 1;
			info.keepShownOnClick = true;
			info.notCheckable = true;
			UIDropDownMenu_AddButton(info,1);
		end
		
		TitanPanelRightClickMenu_AddSpacer();
		--Options title
		TitanPanelRightClickMenu_AddTitle(LT["TITAN_PANEL_OPTIONS"] );
		
		--Button Options
		info = {};
		info.text = LT["TITAN_XP_MENU_SIMPLE_BUTTON_TITLE"];
		info.value = "Button Options";
		info.notCheckable = true;
		info.hasArrow = 1;
		info.keepShownOnClick = true;
		UIDropDownMenu_AddButton(info,1);
		
		--Tooltip Options
		info = {};
		info.text = LT["TITAN_TRANS_CONTROL_TITLE_TOOLTIP"];
		info.value = "Tooltip Options";
		info.notCheckable = true;
		info.hasArrow = 1;
		info.keepShownOnClick = true;
		UIDropDownMenu_AddButton(info,1);

		TitanPanelRightClickMenu_AddSpacer();
		--Close
		info = {};
		info.text = CLOSE_CHAT_WINDOW;
		info.value = "Close";
		info.hasArrow = false;
		info.notCheckable = true;
		UIDropDownMenu_AddButton(info, 1);
			
		TitanPanelRightClickMenu_AddSpacer();
		--Reset
		info = {};
		info.text = RESET;	
		info.notCheckable = true;
		info.func = function()
					StaticPopupDialogs["TITAN_SPEC_RENAME_WARNING"] = {
					  text = GREEN_FONT_COLOR_CODE..SERVER_MESSAGE_COLON.."  "..FONT_COLOR_CODE_CLOSE..CONFIRM_RESET_SETTINGS,
					  button1 = ACCEPT,
					  button2 = CANCEL,
					  OnAccept = function (self)
							TitanSetVar(TITAN_SPEC_ID, "ShowLabelText", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowNumberOnly", false);
							TitanSetVar(TITAN_SPEC_ID, "ShowColours", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowGearSet", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowIcon", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowSpec", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowHint", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowTooltipIcon", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowTalents", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowLootSpec", true);
							TitanSetVar(TITAN_SPEC_ID, "ShowLootSpecIcon", false);
							TitanSpec_ShowHelm = {"","",};
							TitanSpec_EquipmentSet = {"","",};
							TitanSpec_CustomLabel = {"","",};
							TitanSpec_TalentSet = {{"","","","","","",},{"","","","","","",},};
							TitanSpec_ShowSelectTalents ={{1,1,1,1,1,1,},{1,1,1,1,1,1},};
							TitanSpec_ShowTalents = {0,0,};
							TitanSpec_ShowLongTalents ={0,0,};
							TitanSpec_refresh();
					  end,
					  timeout = 0,
					  whileDead = 1,
					  hideOnEscape = 1,
					  enterClicksFirstButton = 1
					};
					StaticPopup_Show("TITAN_SPEC_RENAME_WARNING");
		end
		UIDropDownMenu_AddButton(info,1);
		--Hide
		TitanPanelRightClickMenu_AddCommand(HIDE, TITAN_SPEC_ID, TITAN_PANEL_MENU_FUNC_HIDE);
		return;
	end
	return;
end

-- Determine the currently equiped gear name
function CheckGearSets()
	local numSets = GetNumEquipmentSets();
	if ( numSets < 1 ) then
		TitanSpec_EquipmentSet = {"","",};
	else 
		local has1 = false;
		local has2 = false;
		for i=1,numSets do
			local setName = select(1,GetEquipmentSetInfo(i));
			if ( TitanSpec_EquipmentSet[1] == setName) then
				has1 = true;
			end
			if ( TitanSpec_EquipmentSet[2] == setName) then
				has2 = true;
			end
		end
		if (not has1) then
			TitanSpec_EquipmentSet[1] = "";
		end
		if (not has2) then
			TitanSpec_EquipmentSet[2] = "";
		end
	end
end

-- Toggle functions for Mouse Clicks and Keybindings
function TitanSpec_Toggle_Loot_Spec()
	if (not TitanSpec_locked) then
		TitanSpec_locked = true;
		AceTimer.ScheduleTimer(TITAN_SPEC_ID, function() 
			TitanSpec_Toggle_Loot_Spec_Timer();
			end, 1);
	end
end

function TitanSpec_Toggle_Loot_Spec_Timer()
	local maxSpec = 3;
	if ( select(3,UnitClass("player")) == 11) then
		maxSpec = 4;
	end
	local lootNum = 0;
	for i=0,maxSpec do
		if (TitanSpec_LootSpec == TitanSpec_LootSpecIds[i]) then
			lootNum = i;
			break;
		end
	end
	lootNum = mod((lootNum + 1), (maxSpec+ 1));
	--local lootSpecName = "";
	--if ( lootNum == 0 ) then
	--	lootSpecName = format( LOOT_SPECIALIZATION_DEFAULT , TitanSpec_BuildName[GetActiveSpecGroup()]);
	--	TitanSpec_output(TitanSpec_getColouredText(format(ERR_LOOT_SPEC_CHANGED_S,lootSpecName),"yellow"));
	--else
	--	local _, lootname, _, looticon, _, _ = GetSpecializationInfoByID(TitanSpec_LootSpecIds[lootNum]);
	--	lootSpecName = lootname;
	--end
	--TitanSpec_output(TitanSpec_getColouredText(format(ERR_LOOT_SPEC_CHANGED_S,lootSpecName),"green"));
	
	SetLootSpecialization(TitanSpec_LootSpecIds[lootNum]);
	TitanSpec_locked = false;
	
	--TitanSpec_LootSpec = TitanSpec_LootSpecIds[lootNum];
	--if (not TitanSpec_Timer) then
	--	TitanSpec_Timer = true;
	--	AceTimer.ScheduleTimer(TITAN_SPEC_ID, function() 
	--			TitanSpec_locked = true;
	--			TitanSpec_Timer = false;
	--			AceTimer.ScheduleTimer(TITAN_SPEC_ID, function() 
	--				SetLootSpecialization(TitanSpec_LootSpec);
	--				TitanSpec_locked = false;
	--				end, 1.10);
	--		end, 2.30);
	--end
end

-- Toggle for spec + gear change 
function TitanSpec_Toggle_Spec_Gear()
	local idx = mod(GetActiveSpecGroup(), GetNumSpecGroups()) + 1;
	SetActiveSpecGroup(idx);
end

--Toggle for only Spec change
function TitanSpec_Toggle_Spec()
	local idx = mod(GetActiveSpecGroup(), GetNumSpecGroups()) + 1;
	TitanSpec_SwitchGear = false;
	SetActiveSpecGroup(idx);
end

--Toggle for only gear changge
function TitanSpec_Toggle_Gear()
	if ( TitanSpec_EquipmentSet ~=nil and
		TitanSpec_EquipmentSet[1] ~="" and TitanSpec_EquipmentSet[2] ~= "") then
		local set = nil;
		if ( TitanSpec_Equipped == TitanSpec_EquipmentSet[1]) then
			set = TitanSpec_EquipmentSet[2];
		elseif ( TitanSpec_Equipped == TitanSpec_EquipmentSet[2]) then
			set = TitanSpec_EquipmentSet[1];
		else
			set = TitanSpec_EquipmentSet[GetActiveSpecGroup()];
		end
		if ( set ~= nil and set ~= "" ) then
				UseEquipmentSet(set);
				TitanSpec_Equipped = set;
		end
	elseif (GetNumEquipmentSets() > 1) then 
		if (TitanSpec_RotateSet <= GetNumEquipmentSets()) then
			local name = select(1,GetEquipmentSetInfo(TitanSpec_RotateSet));
			if (name == TitanSpec_Equipped) then
				name = select(1,GetEquipmentSetInfo(TitanSpec_RotateSet+1));
			end
			if (name ~= nil and name ~= "") then
				UseEquipmentSet(name);
			end
			TitanSpec_Equipped = name;
			TitanSpec_RotateSet = TitanSpec_RotateSet+1;
		else
			TitanSpec_RotateSet = 1;
			local name = select(1,GetEquipmentSetInfo(TitanSpec_RotateSet));
			if (name == TitanSpec_Equipped) then
				name = select(1,GetEquipmentSetInfo(TitanSpec_RotateSet+1));
			end
			if (name ~= nil and name ~= "") then
				UseEquipmentSet(name);
			end
			TitanSpec_Equipped = name;
			TitanSpec_RotateSet = TitanSpec_RotateSet+1;
		end		
	elseif (GetNumEquipmentSets() == 1) then
		local name = select(1,GetEquipmentSetInfo(1));
		UseEquipmentSet(name);
		TitanSpec_Equipped = name;
	end
end

function TitanSpec_Set_Show_Helm()
	local isShowing = ShowingHelm();
	ShowHelm(not isShowing);
	if (not isShowing) then
		TitanSpec_ShowHelm[GetActiveSpecGroup()] = "show";
	else
		TitanSpec_ShowHelm[GetActiveSpecGroup()] = "hide";
	end
end
-- ************************************************************************** --
-- ******************************** User Functions ************************** --
-- ************************************************************************** --

function TitanSpec_debug(msg)
	if ( msg == nil ) then
		msg = "<nil>";
	end
	if IS_DEBUGGING then
		TitanDebug("TitanSpec> "..msg);
	end
end

function TitanSpec_output(msg)
    DEFAULT_CHAT_FRAME:AddMessage(msg, 1, 1, 1);
end

function TitanSpec_getColouredText(msg, colour)
	local colourCode = "";
	
	if ( colour == nil or colour == "default" ) then
		return msg;
	elseif ( colour == "red" ) then
		colourCode = "|cffff0000";
	elseif ( colour == "green" ) then
		colourCode = "|cff00ff00";
	elseif ( colour == "blue" ) then
		colourCode = "|cff0000ff";
	elseif ( colour == "yellow" ) then
		colourCode = "|cffffff00";
	elseif ( colour == "white" ) then
		colourCode = "|cffffffff";
	elseif ( colour == "black" ) then
		colourCode = "|cff000000";
	else
		colourCode = "|cff"..colour;
	end
        
	return colourCode..msg..FONT_COLOR_CODE_CLOSE;
end

