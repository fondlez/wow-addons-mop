﻿local L = LibStub("AceLocale-3.0"):NewLocale("TitanSpec","ruRU",false)

if L then
L["TITAN_SPEC_BINDINGS_GEAR"] = "Сменить экипировку"
L["TITAN_SPEC_BINDINGS_LOOT_SPEC"] = "переключения добычу специализации" -- Needs review
L["TITAN_SPEC_BINDINGS_SPEC"] = "Сменить таланты"
L["TITAN_SPEC_BINDINGS_SPEC_GEAR"] = "Сменить таланты и экипировку"
L["TITAN_SPEC_GEAR_SET"] = "Экипировка"
L["TITAN_SPEC_HINT"] = "Совет: ЛКМ - сменить таланты и экипировку.\n     Shift + ЛКМ сменить только таланты.\n     Alt + ЛКМ сменить только экипировку.\n     Ctrl + левый щелчок, чтобы изменить добычу специализации." -- Needs review
L["TITAN_SPEC_SHOW_HINT"] = "Совет"
L["TITAN_SPEC_SHOW_LONG_TALENTS"] = "Показывать полные названия"
L["TITAN_SPEC_SHOW_NUMBER_ONLY"] = "Показывать только номер специализации"
L["TITAN_SPEC_SHOW_TALENTS"] = "Показывать набор талантов"
L["TITAN_SPEC_SHOW_TALENT_TIER"] = "Показывать таланты уровня %s"
L["TITAN_SPEC_TOOLTIP_TITLE"] = "Информация о талантах"

end
