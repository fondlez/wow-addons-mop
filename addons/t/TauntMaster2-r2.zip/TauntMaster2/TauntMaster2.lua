﻿local defaults = {
    height = 30,
    width = 75,
    maxColumns = 4,
    unitsPerColumn = 10,
    MinimapPos = 45,
    checked = nil,
    soloCheck = nil,
    showTank = nil,
    showFriendly = nil,
    showOOM = nil,
    showTankTarget = nil,
    OOMlevel = 10,
    hideTM = nil,
    hideTMMM = nil,
    showTaunts = nil,
    showTaunts2 = nil,
    Alpha1 = 75,
    Alpha2 = 35,
    Alpha3 = 35,
    Alpha4 = 15,
    TMHorsemen = 3,
    TMGluth = 3,
    TMToravon = 4,
    TMGormok = 3,
    TMRazorscale = 3,
    TMThorim = 1,
    TMAlgalon = 4,
    TMDeathwhisper = 2,
    TMDeathbringer = 1,
	TMDogs = 6,
    TMFestergut = 9,
    TMPutricide = 2,
    TMSindragosa = 4,
    TMLichKing = 1,
    TMWspWarn = 1,
    TMSayWarn = nil, 
    TMRaidWarn = nil,
    TMRaidWarnWarn = nil,
    TARGET1 = "Click to Select",
    SHIFTTARGET1 = "Click to Select",
    CTRLTARGET1 = "Click to Select",
    ALTTARGET1 = "Click to Select",
    TARGET2 = "Click to Select",
    SHIFTTARGET2 = "Click to Select",
    CTRLTARGET2 = "Click to Select",
    ALTTARGET2 = "Click to Select",
    TARGET3 = "Click to Select",
    SHIFTTARGET3 = "Click to Select",
    CTRLTARGET3 = "Click to Select",
    ALTTARGET3 = "Click to Select",
    TARGET4 = "Click to Select",
    SHIFTTARGET4 = "Click to Select",
    CTRLTARGET4 = "Click to Select",
    ALTTARGET4 = "Click to Select",
    TARGET5 = "Click to Select",
    SHIFTTARGET5 = "Click to Select",
    CTRLTARGET5 = "Click to Select",
    ALTTARGET5 = "Click to Select",
    SPELL1 = "",
    SHIFTSPELL1 = "",
    CTRLSPELL1 = "",
    ALTSPELL1 = "",
    SPELL2 = "",
    SHIFTSPELL2 = "",
    CTRLSPELL2 = "",
    ALTSPELL2 = "",
    SPELL3 = "",
    SHIFTSPELL3 = "",
    CTRLSPELL3 = "",
    ALTSPELL3 = "",
    SPELL4 = "",
    SHIFTSPELL4 = "",
    CTRLSPELL4 = "",
    ALTSPELL4 = "",
    SPELL5 = "",
    SHIFTSPELL5 = "",
    CTRLSPELL5 = "",
    ALTSPELL5 = "",
	TMMacroCheck = nil,
	TMSpellCheck = 1,
	TMSetButton = 1,
	TMMacroShiftCheck = nil,
	TMSpellShiftCheck = 1,
	TMSetShiftButton = 1,
	TMMacroCtrlCheck = nil,
	TMSpellCtrlCheck = 1,
	TMSetCtrlButton = 1,
	TMMacroAltCheck = nil,
	TMSpellAltCheck = 1,
	TMSetAltButton = 1,
	TMMacroCheck2 = nil,
	TMSpellCheck2 = 1,
	TMSetButton2 = 1,
	TMMacroShiftCheck2 = nil,
	TMSpellShiftCheck2 = 1,
	TMSetShiftButton2 = 1,
	TMMacroCtrlCheck2 = nil,
	TMSpellCtrlCheck2 = 1,
	TMSetCtrlButton2 = 1,
	TMMacroAltCheck2 = nil,
	TMSpellAltCheck2 = 1,
	TMSetAltButton2 = 1,
	TMMacroCheck3 = nil,
	TMSpellCheck3 = 1,
	TMSetButton3 = 1,
	TMMacroShiftCheck3 = nil,
	TMSpellShiftCheck3 = 1,
	TMSetShiftButton3 = 1,
	TMMacroCtrlCheck3 = nil,
	TMSpellCtrlCheck3 = 1,
	TMSetCtrlButton3 = 1,
	TMMacroAltCheck3 = nil,
	TMSpellAltCheck3 = 1,
	TMSetAltButton3 = 1,
	TMMacroCheck4 = nil,
	TMSpellCheck4 = 1,
	TMSetButton4 = 1,
	TMMacroShiftCheck4 = nil,
	TMSpellShiftCheck4 = 1,
	TMSetShiftButton4 = 1,
	TMMacroCtrlCheck4 = nil,
	TMSpellCtrlCheck4 = 1,
	TMSetCtrlButton4 = 1,
	TMMacroAltCheck4 = nil,
	TMSpellAltCheck4 = 1,
	TMSetAltButton4 = 1,
	TMMacroCheck5 = nil,
	TMSpellCheck5 = 1,
	TMSetButton5 = 1,
	TMMacroShiftCheck5 = nil,
	TMSpellShiftCheck5 = 1,
	TMSetShiftButton5 = 1,
	TMMacroCtrlCheck5 = nil,
	TMSpellCtrlCheck5 = 1,
	TMSetCtrlButton5 = 1,
	TMMacroAltCheck5 = nil,
	TMSpellAltCheck5 = 1,
	TMSetAltButton5 = 1,
}

local paladindefaults = {
    height = 30,
    width = 75,
    maxColumns = 4,
    unitsPerColumn = 10,
    MinimapPos = 45,
    checked = nil,
    soloCheck = nil,
    showTank = nil,
    showFriendly = nil,
    showOOM = nil,
    showTankTarget = nil,
    OOMlevel = 10,
    hideTM = nil,
    hideTMMM = nil,
    showTaunts = nil,
    showTaunts2 = nil,
    Alpha1 = 75,
    Alpha2 = 35,
    Alpha3 = 35,
    Alpha4 = 15,
    TMHorsemen = 3,
    TMGluth = 3,
    TMToravon = 4,
    TMGormok = 3,
    TMRazorscale = 3,
    TMAlgalon = 4,
    TMDeathwhisper = 2,
    TMDeathbringer = 1,
    TMFestergut = 9,
    TMPutricide = 2,
    TMSindragosa = 4,
    TMLichKing = 1,
	TMDogs = 6,
    TMWspWarn = 1,
    TMSayWarn = nil, 
    TMRaidWarn = nil,
    TMRaidWarnWarn = nil,
    SPELL1 = GetSpellInfo(62124),--reckoning
    SHIFTSPELL1 = GetSpellInfo(1044),--Hand of Freedom
    CTRLSPELL1 = GetSpellInfo(6940),--Hand of Sacrifice
    ALTSPELL1 = GetSpellInfo(633),--Lay on Hands 
    TARGET1 = "[@mouseovertarget]",
    SHIFTTARGET1 = "[@mouseover]",
    CTRLTARGET1 = "[@mouseover]",
    ALTTARGET1 = "[@mouseover]",
    SPELL2 = GetSpellInfo(1038),--Hand of Salvation
    SHIFTSPELL2 = "",
    CTRLSPELL2 = GetSpellInfo(1022),--Hand of Protection
    ALTSPELL2 = "",
    TARGET2 = "[@mouseover]",
    SHIFTTARGET2 = "Click to Select",
    CTRLTARGET2 = "[@mouseover]",
    ALTTARGET2 = "Click to Select",
    SPELL3 = "",
    SHIFTSPELL3 = "",
    CTRLSPELL3 = "",
    ALTSPELL3 = "",
    TARGET3 = "Click to Select",
    SHIFTTARGET3 = "Click to Select",
    CTRLTARGET3 = "Click to Select",
    ALTTARGET3 = "Click to Select",
    SPELL4 = "",
    SHIFTSPELL4 = "",
    CTRLSPELL4 = "",
    ALTSPELL4 = "",
    TARGET4 = "Click to Select",
    SHIFTTARGET4 = "Click to Select",
    CTRLTARGET4 = "Click to Select",
    ALTTARGET4 = "Click to Select",
    SPELL5 = "",
    SHIFTSPELL5 = "",
    CTRLSPELL5 = "",
    ALTSPELL5 = "",
    TARGET5 = "Click to Select",
    SHIFTTARGET5 = "Click to Select",
    CTRLTARGET5 = "Click to Select",
    ALTTARGET5 = "Click to Select",
	TMMacroCheck = nil,
	TMSpellCheck = 1,
	TMSetButton = 0,
	TMMacroShiftCheck = nil,
	TMSpellShiftCheck = 1,
	TMSetShiftButton = 0,
	TMMacroCtrlCheck = nil,
	TMSpellCtrlCheck = 1,
	TMSetCtrlButton = 1,
	TMMacroAltCheck = nil,
	TMSpellAltCheck = 1,
	TMSetAltButton = 1,
	TMMacroCheck2 = nil,
	TMSpellCheck2 = 1,
	TMSetButton2 = 0,
	TMMacroShiftCheck2 = nil,
	TMSpellShiftCheck2 = 1,
	TMSetShiftButton2 = 1,
	TMMacroCtrlCheck2 = nil,
	TMSpellCtrlCheck2 = 1,
	TMSetCtrlButton2 = 1,
	TMMacroAltCheck2 = nil,
	TMSpellAltCheck2 = 1,
	TMSetAltButton2 = 1,
	TMMacroCheck3 = nil,
	TMSpellCheck3 = 1,
	TMSetButton3 = 0,
	TMMacroShiftCheck3 = nil,
	TMSpellShiftCheck3 = 1,
	TMSetShiftButton3 = 1,
	TMMacroCtrlCheck3 = nil,
	TMSpellCtrlCheck3 = 1,
	TMSetCtrlButton3 = 1,
	TMMacroAltCheck3 = nil,
	TMSpellAltCheck3 = 1,
	TMSetAltButton3 = 1,
	TMMacroCheck4 = nil,
	TMSpellCheck4 = 1,
	TMSetButton4 = 1,
	TMMacroShiftCheck4 = nil,
	TMSpellShiftCheck4 = 1,
	TMSetShiftButton4 = 1,
	TMMacroCtrlCheck4 = nil,
	TMSpellCtrlCheck4 = 1,
	TMSetCtrlButton4 = 1,
	TMMacroAltCheck4 = nil,
	TMSpellAltCheck4 = 1,
	TMSetAltButton4 = 1,
	TMMacroCheck5 = nil,
	TMSpellCheck5 = 1,
	TMSetButton5 = 1,
	TMMacroShiftCheck5 = nil,
	TMSpellShiftCheck5 = 1,
	TMSetShiftButton5 = 1,
	TMMacroCtrlCheck5 = nil,
	TMSpellCtrlCheck5 = 1,
	TMSetCtrlButton5 = 1,
	TMMacroAltCheck5 = nil,
	TMSpellAltCheck5 = 1,
	TMSetAltButton5 = 1,
}

local warriordefaults = {
    height = 30,
    width = 75,
    maxColumns = 4,
    unitsPerColumn = 10,
    MinimapPos = 45,
    checked = nil,
    soloCheck = nil,
    showTank = nil,
    showFriendly = nil,
    showOOM = nil,
    showTankTarget = nil,
    OOMlevel = 10,
    hideTM = nil,
    hideTMMM = nil,
    showTaunts = nil,
    showTaunts2 = nil,
    Alpha1 = 75,
    Alpha2 = 35,
    Alpha3 = 35,
    Alpha4 = 15,
    TMHorsemen = 3,
    TMGluth = 3,
    TMToravon = 4,
    TMGormok = 3,
    TMRazorscale = 3,
    TMAlgalon = 4,
	TMDogs = 6,
    TMDeathwhisper = 2,
    TMDeathbringer = 1,
    TMFestergut = 9,
    TMPutricide = 2,
    TMSindragosa = 4,
    TMLichKing = 1,
    TMWspWarn = 1,
    TMSayWarn = nil, 
    TMRaidWarn = nil,
    TMRaidWarnWarn = nil,
    SPELL1 = GetSpellInfo(355), --taunt
    SHIFTSPELL1 = "",
    CTRLSPELL1 = GetSpellInfo(6673), --Battle Shout
    ALTSPELL1 = GetSpellInfo(871), --Shield Wall
    TARGET1 = "[@mouseovertarget]",
    SHIFTTARGET1 = "Click to Select",
    CTRLTARGET1 = "[@mouseover]",
    ALTTARGET1 = "[@mouseover]",
    SPELL2 = GetSpellInfo(3411),--intervene
    SHIFTSPELL2 = "",
    CTRLSPELL2 = "",
    ALTSPELL2 = "",
    TARGET2 = "[@mouseovertarget]",
    SHIFTTARGET2 = "Click to Select",
    CTRLTARGET2 = "Click to Select",
    ALTTARGET2 = "Click to Select",
    SPELL3 = "",
    SHIFTSPELL3 = "",
    CTRLSPELL3 = "",
    ALTSPELL3 = "",
    TARGET3 = "Click to Select",
    SHIFTTARGET3 = "Click to Select",
    CTRLTARGET3 = "Click to Select",
    ALTTARGET3 = "Click to Select",
    SPELL4 = "",
    SHIFTSPELL4 = "",
    CTRLSPELL4 = "",
    ALTSPELL4 = "",
    TARGET4 = "Click to Select",
    SHIFTTARGET4 = "Click to Select",
    CTRLTARGET4 = "Click to Select",
    ALTTARGET4 = "Click to Select",
    SPELL5 = "",
    SHIFTSPELL5 = "",
    CTRLSPELL5 = "",
    ALTSPELL5 = "",
    TARGET5 = "Click to Select",
    SHIFTTARGET5 = "Click to Select",
    CTRLTARGET5 = "Click to Select",
    ALTTARGET5 = "Click to Select",
	TMMacroCheck = nil,
	TMSpellCheck = 1,
	TMSetButton = 0,
	TMMacroShiftCheck = nil,
	TMSpellShiftCheck = 1,
	TMSetShiftButton = 0,
	TMMacroCtrlCheck = nil,
	TMSpellCtrlCheck = 1,
	TMSetCtrlButton = 1,
	TMMacroAltCheck = nil,
	TMSpellAltCheck = 1,
	TMSetAltButton = 1,
	TMMacroCheck2 = nil,
	TMSpellCheck2 = 1,
	TMSetButton2 = 0,
	TMMacroShiftCheck2 = nil,
	TMSpellShiftCheck2 = 1,
	TMSetShiftButton2 = 1,
	TMMacroCtrlCheck2 = nil,
	TMSpellCtrlCheck2 = 1,
	TMSetCtrlButton2 = 1,
	TMMacroAltCheck2 = nil,
	TMSpellAltCheck2 = 1,
	TMSetAltButton2 = 1,
	TMMacroCheck3 = nil,
	TMSpellCheck3 = 1,
	TMSetButton3 = 1,
	TMMacroShiftCheck3 = nil,
	TMSpellShiftCheck3 = 1,
	TMSetShiftButton3 = 1,
	TMMacroCtrlCheck3 = nil,
	TMSpellCtrlCheck3 = 1,
	TMSetCtrlButton3 = 1,
	TMMacroAltCheck3 = nil,
	TMSpellAltCheck3 = 1,
	TMSetAltButton3 = 1,
	TMMacroCheck4 = nil,
	TMSpellCheck4 = 1,
	TMSetButton4 = 1,
	TMMacroShiftCheck4 = nil,
	TMSpellShiftCheck4 = 1,
	TMSetShiftButton4 = 1,
	TMMacroCtrlCheck4 = nil,
	TMSpellCtrlCheck4 = 1,
	TMSetCtrlButton4 = 1,
	TMMacroAltCheck4 = nil,
	TMSpellAltCheck4 = 1,
	TMSetAltButton4 = 1,
	TMMacroCheck5 = nil,
	TMSpellCheck5 = 1,
	TMSetButton5 = 1,
	TMMacroShiftCheck5 = nil,
	TMSpellShiftCheck5 = 1,
	TMSetShiftButton5 = 1,
	TMMacroCtrlCheck5 = nil,
	TMSpellCtrlCheck5 = 1,
	TMSetCtrlButton5 = 1,
	TMMacroAltCheck5 = nil,
	TMSpellAltCheck5 = 1,
	TMSetAltButton5 = 1,
}

local deathknightdefaults = {
    height = 30,
    width = 75,
    maxColumns = 4,
    unitsPerColumn = 10,
    MinimapPos = 45,
    checked = nil,
    soloCheck = nil,
    showTank = nil,
    showFriendly = nil,
    showOOM = nil,
    showTankTarget = nil,
    OOMlevel = 10,
    hideTM = nil,
    hideTMMM = nil,
    SPELL1 = GetSpellInfo(56222),--dark command
    SHIFTSPELL1 = GetSpellInfo(48707),--Anti-Magic Shell
    CTRLSPELL1 = GetSpellInfo(57330),--Horn of Winter
    ALTSPELL1 = GetSpellInfo(48982),--Rune Tap
    showTaunts = nil,
    showTaunts2 = nil,
    Alpha1 = 75,
    Alpha2 = 35,
    Alpha3 = 35,
    Alpha4 = 15,
    TMHorsemen = 3,
    TMGluth = 3,
    TMToravon = 4,
    TMGormok = 3,
    TMRazorscale = 3,
    TMAlgalon = 4,
    TMDeathwhisper = 2,
    TMDeathbringer = 1,
	TMDogs = 6,
    TMFestergut = 9,
    TMPutricide = 2,
    TMSindragosa = 4,
    TMLichKing = 1,
    TMWspWarn = 1,
    TMSayWarn = nil, 
    TMRaidWarn = nil,
    TMRaidWarnWarn = nil,
    TARGET1 = "[@mouseovertarget]",
    SHIFTTARGET1 = "[@mouseover]",
    CTRLTARGET1 = "[@mouseover]",
    ALTTARGET1 = "[@mouseover]",
    SPELL2 = GetSpellInfo(49576),--death grip
    SHIFTSPELL2 = GetSpellInfo(108196),--Death Siphon
    CTRLSPELL2 = GetSpellInfo(48792),--Icebound Fortitude
    ALTSPELL2 = GetSpellInfo(55233),--Vampiric Blood
    TARGET2 = "[@mouseovertarget]",
    SHIFTTARGET2 = "[@mouseover]",
    CTRLTARGET2 = "[@mouseover]",
    ALTTARGET2 = "[@mouseover]",
    SPELL3 = "",
    SHIFTSPELL3 = "",
    CTRLSPELL3 = "",
    ALTSPELL3 = "",
    TARGET3 = "Click to Select",
    SHIFTTARGET3 = "Click to Select",
    CTRLTARGET3 = "Click to Select",
    ALTTARGET3 = "Click to Select",
    SPELL4 = "",
    SHIFTSPELL4 = "",
    CTRLSPELL4 = "",
    ALTSPELL4 = "",
    TARGET4 = "Click to Select",
    SHIFTTARGET4 = "Click to Select",
    CTRLTARGET4 = "Click to Select",
    ALTTARGET4 = "Click to Select",
    SPELL5 = "",
    SHIFTSPELL5 = "",
    CTRLSPELL5 = "",
    ALTSPELL5 = "",
    TARGET5 = "Click to Select",
    SHIFTTARGET5 = "Click to Select",
    CTRLTARGET5 = "Click to Select",
    ALTTARGET5 = "Click to Select",
	TMMacroCheck = nil,
	TMSpellCheck = 1,
	TMSetButton =0 ,
	TMMacroShiftCheck = nil,
	TMSpellShiftCheck = 1,
	TMSetShiftButton = 1,
	TMMacroCtrlCheck = nil,
	TMSpellCtrlCheck = 1,
	TMSetCtrlButton = 1,
	TMMacroAltCheck = nil,
	TMSpellAltCheck = 1,
	TMSetAltButton = 1,
	TMMacroCheck2 = nil,
	TMSpellCheck2 = 1,
	TMSetButton2 = 0,
	TMMacroShiftCheck2 = nil,
	TMSpellShiftCheck2 = 1,
	TMSetShiftButton2 = 1,
	TMMacroCtrlCheck2 = nil,
	TMSpellCtrlCheck2 = 1,
	TMSetCtrlButton2 = 1,
	TMMacroAltCheck2 = nil,
	TMSpellAltCheck2 = 1,
	TMSetAltButton2 = 1,
	TMMacroCheck3 = nil,
	TMSpellCheck3 = 1,
	TMSetButton3 = 1,
	TMMacroShiftCheck3 = nil,
	TMSpellShiftCheck3 = 1,
	TMSetShiftButton3 = 1,
	TMMacroCtrlCheck3 = nil,
	TMSpellCtrlCheck3 = 1,
	TMSetCtrlButton3 = 1,
	TMMacroAltCheck3 = nil,
	TMSpellAltCheck3 = 1,
	TMSetAltButton3 = 1,
	TMMacroCheck4 = nil,
	TMSpellCheck4 = 1,
	TMSetButton4 = 1,
	TMMacroShiftCheck4 = nil,
	TMSpellShiftCheck4 = 1,
	TMSetShiftButton4 = 1,
	TMMacroCtrlCheck4 = nil,
	TMSpellCtrlCheck4 = 1,
	TMSetCtrlButton4 = 1,
	TMMacroAltCheck4 = nil,
	TMSpellAltCheck4 = 1,
	TMSetAltButton4 = 1,
	TMMacroCheck5 = nil,
	TMSpellCheck5 = 1,
	TMSetButton5 = 1,
	TMMacroShiftCheck5 = nil,
	TMSpellShiftCheck5 = 1,
	TMSetShiftButton5 = 1,
	TMMacroCtrlCheck5 = nil,
	TMSpellCtrlCheck5 = 1,
	TMSetCtrlButton5 = 1,
	TMMacroAltCheck5 = nil,
	TMSpellAltCheck5 = 1,
	TMSetAltButton5 = 1,
}

local druiddefaults = {
    height = 30,
    width = 75,
    maxColumns = 4,
    unitsPerColumn = 10,
    MinimapPos = 45,
    checked = nil,
    soloCheck = nil,
    showTank = nil,
    showFriendly = nil,
    showOOM = nil,
    showTankTarget = nil,
    OOMlevel = 10,
    hideTM = nil,
    hideTMMM = nil,
    showTaunts = nil,
    showTaunts2 = nil,
    Alpha1 = 75,
    Alpha2 = 35,
    Alpha3 = 35,
    Alpha4 = 15,
    TMHorsemen = 3,
    TMGluth = 3,
    TMToravon = 4,
    TMGormok = 3,
    TMRazorscale = 3,
    TMAlgalon = 4,
    TMDeathwhisper = 2,
    TMDeathbringer = 1,
	TMDogs = 6,
    TMFestergut = 9,
    TMPutricide = 2,
    TMSindragosa = 4,
    TMLichKing = 1,
    TMWspWarn = 1,
    TMSayWarn = nil, 
    TMRaidWarn = nil,
    TMRaidWarnWarn = nil,
    SPELL1 = GetSpellInfo(6795),--growl
    SHIFTSPELL1 = "",
    CTRLSPELL1 = GetSpellInfo(22842),--Frenzied Regeneration
    ALTSPELL1 = GetSpellInfo(102352),--Cenarion Ward
    TARGET1 = "[@mouseovertarget]",
    SHIFTTARGET1 = "Click to Select",
    CTRLTARGET1 = "[@mouseover]",
    ALTTARGET1 = "[@mouseovertarget]",
    SPELL2 = GetSpellInfo(22812),--Barkskin
    SHIFTSPELL2 = "",
    CTRLSPELL2 = "",
    ALTSPELL2 = GetSpellInfo(29166),--Innervate
    TARGET2 = "[@mouseover]",
    SHIFTTARGET2 = "Click to Select",
    CTRLTARGET2 = "Click to Select",
    ALTTARGET2 = "[@mouseovertarget]",
    SPELL3 = "",
    SHIFTSPELL3 = "",
    CTRLSPELL3 = "",
    ALTSPELL3 = "",
    TARGET3 = "Click to Select",
    SHIFTTARGET3 = "Click to Select",
    CTRLTARGET3 = "Click to Select",
    ALTTARGET3 = "Click to Select",
    SPELL4 = "",
    SHIFTSPELL4 = "",
    CTRLSPELL4 = "",
    ALTSPELL4 = "",
    TARGET4 = "Click to Select",
    SHIFTTARGET4 = "Click to Select",
    CTRLTARGET4 = "Click to Select",
    ALTTARGET4 = "Click to Select",
    SPELL5 = "",
    SHIFTSPELL5 = "",
    CTRLSPELL5 = "",
    ALTSPELL5 = "",
    TARGET5 = "Click to Select",
    SHIFTTARGET5 = "Click to Select",
    CTRLTARGET5 = "Click to Select",
    ALTTARGET5 = "Click to Select",
	TMMacroCheck = nil,
	TMSpellCheck = 1,
	TMSetButton = 0,
	TMMacroShiftCheck = nil,
	TMSpellShiftCheck = 1,
	TMSetShiftButton = 1,
	TMMacroCtrlCheck = nil,
	TMSpellCtrlCheck = 1,
	TMSetCtrlButton = 1,
	TMMacroAltCheck = nil,
	TMSpellAltCheck = 1,
	TMSetAltButton = 1,
	TMMacroCheck2 = nil,
	TMSpellCheck2 = 1,
	TMSetButton2 = 0,
	TMMacroShiftCheck2 = nil,
	TMSpellShiftCheck2 = 1,
	TMSetShiftButton2 = 1,
	TMMacroCtrlCheck2 = nil,
	TMSpellCtrlCheck2 = 1,
	TMSetCtrlButton2 = 1,
	TMMacroAltCheck2 = nil,
	TMSpellAltCheck2 = 1,
	TMSetAltButton2 = 1,
	TMMacroCheck3 = nil,
	TMSpellCheck3 = 1,
	TMSetButton3 = 1,
	TMMacroShiftCheck3 = nil,
	TMSpellShiftCheck3 = 1,
	TMSetShiftButton3 = 1,
	TMMacroCtrlCheck3 = nil,
	TMSpellCtrlCheck3 = 1,
	TMSetCtrlButton3 = 1,
	TMMacroAltCheck3 = nil,
	TMSpellAltCheck3 = 1,
	TMSetAltButton3 = 1,
	TMMacroCheck4 = nil,
	TMSpellCheck4 = 1,
	TMSetButton4 = 1,
	TMMacroShiftCheck4 = nil,
	TMSpellShiftCheck4 = 1,
	TMSetShiftButton4 = 1,
	TMMacroCtrlCheck4 = nil,
	TMSpellCtrlCheck4 = 1,
	TMSetCtrlButton4 = 1,
	TMMacroAltCheck4 = nil,
	TMSpellAltCheck4 = 1,
	TMSetAltButton4 = 1,
	TMMacroCheck5 = nil,
	TMSpellCheck5 = 1,
	TMSetButton5 = 1,
	TMMacroShiftCheck5 = nil,
	TMSpellShiftCheck5 = 1,
	TMSetShiftButton5 = 1,
	TMMacroCtrlCheck5 = nil,
	TMSpellCtrlCheck5 = 1,
	TMSetCtrlButton5 = 1,
	TMMacroAltCheck5 = nil,
	TMSpellAltCheck5 = 1,
	TMSetAltButton5 = 1,
}

local monkdefaults = {
    height = 30,
    width = 75,
    maxColumns = 4,
    unitsPerColumn = 10,
    MinimapPos = 45,
    checked = nil,
    soloCheck = nil,
    showTank = nil,
    showFriendly = nil,
    showOOM = nil,
    showTankTarget = nil,
    OOMlevel = 10,
    hideTM = nil,
    hideTMMM = nil,
    showTaunts = nil,
    showTaunts2 = nil,
    Alpha1 = 75,
    Alpha2 = 35,
    Alpha3 = 35,
    Alpha4 = 15,
    TMHorsemen = 3,
    TMGluth = 3,
    TMToravon = 4,
    TMGormok = 3,
    TMRazorscale = 3,
    TMAlgalon = 4,
	TMDogs = 6,
    TMDeathwhisper = 2,
    TMDeathbringer = 1,
    TMFestergut = 9,
    TMPutricide = 2,
    TMSindragosa = 4,
    TMLichKing = 1,
    TMWspWarn = 1,
    TMSayWarn = nil, 
    TMRaidWarn = nil,
    TMRaidWarnWarn = nil,
    SPELL1 = GetSpellInfo(115546), --Provoke
    SHIFTSPELL1 = "",
    CTRLSPELL1 = "",
    ALTSPELL1 = "",
    TARGET1 = "[@mouseovertarget]",
    SHIFTTARGET1 = "Click to Select",
    CTRLTARGET1 = "Click to Select",
    ALTTARGET1 = "Click to Select",
    SPELL2 = GetSpellInfo(115546),--Provoke
    SHIFTSPELL2 = "",
    CTRLSPELL2 = "",
    ALTSPELL2 = "",
    TARGET2 = "[@mouseovertarget]",
    SHIFTTARGET2 = "Click to Select",
    CTRLTARGET2 = "Click to Select",
    ALTTARGET2 = "Click to Select",
    SPELL3 = "",
    SHIFTSPELL3 = "",
    CTRLSPELL3 = "",
    ALTSPELL3 = "",
    TARGET3 = "Click to Select",
    SHIFTTARGET3 = "Click to Select",
    CTRLTARGET3 = "Click to Select",
    ALTTARGET3 = "Click to Select",
    SPELL4 = "",
    SHIFTSPELL4 = "",
    CTRLSPELL4 = "",
    ALTSPELL4 = "",
    TARGET4 = "Click to Select",
    SHIFTTARGET4 = "Click to Select",
    CTRLTARGET4 = "Click to Select",
    ALTTARGET4 = "Click to Select",
    SPELL5 = "",
    SHIFTSPELL5 = "",
    CTRLSPELL5 = "",
    ALTSPELL5 = "",
    TARGET5 = "Click to Select",
    SHIFTTARGET5 = "Click to Select",
    CTRLTARGET5 = "Click to Select",
    ALTTARGET5 = "Click to Select",
	TMMacroCheck = nil,
	TMSpellCheck = 1,
	TMSetButton = 0,
	TMMacroShiftCheck = nil,
	TMSpellShiftCheck = 1,
	TMSetShiftButton = 0,
	TMMacroCtrlCheck = nil,
	TMSpellCtrlCheck = 1,
	TMSetCtrlButton = 1,
	TMMacroAltCheck = nil,
	TMSpellAltCheck = 1,
	TMSetAltButton = 1,
	TMMacroCheck2 = nil,
	TMSpellCheck2 = 1,
	TMSetButton2 = 0,
	TMMacroShiftCheck2 = nil,
	TMSpellShiftCheck2 = 1,
	TMSetShiftButton2 = 1,
	TMMacroCtrlCheck2 = nil,
	TMSpellCtrlCheck2 = 1,
	TMSetCtrlButton2 = 1,
	TMMacroAltCheck2 = nil,
	TMSpellAltCheck2 = 1,
	TMSetAltButton2 = 1,
	TMMacroCheck3 = nil,
	TMSpellCheck3 = 1,
	TMSetButton3 = 1,
	TMMacroShiftCheck3 = nil,
	TMSpellShiftCheck3 = 1,
	TMSetShiftButton3 = 1,
	TMMacroCtrlCheck3 = nil,
	TMSpellCtrlCheck3 = 1,
	TMSetCtrlButton3 = 1,
	TMMacroAltCheck3 = nil,
	TMSpellAltCheck3 = 1,
	TMSetAltButton3 = 1,
	TMMacroCheck4 = nil,
	TMSpellCheck4 = 1,
	TMSetButton4 = 1,
	TMMacroShiftCheck4 = nil,
	TMSpellShiftCheck4 = 1,
	TMSetShiftButton4 = 1,
	TMMacroCtrlCheck4 = nil,
	TMSpellCtrlCheck4 = 1,
	TMSetCtrlButton4 = 1,
	TMMacroAltCheck4 = nil,
	TMSpellAltCheck4 = 1,
	TMSetAltButton4 = 1,
	TMMacroCheck5 = nil,
	TMSpellCheck5 = 1,
	TMSetButton5 = 1,
	TMMacroShiftCheck5 = nil,
	TMSpellShiftCheck5 = 1,
	TMSetShiftButton5 = 1,
	TMMacroCtrlCheck5 = nil,
	TMSpellCtrlCheck5 = 1,
	TMSetCtrlButton5 = 1,
	TMMacroAltCheck5 = nil,
	TMSpellAltCheck5 = 1,
	TMSetAltButton5 = 1,
}

function TauntMaster2_Button_OnLoad(self)
         TMbuttonNames = self:GetName()
   self:RegisterForDrag("LeftButton")
   self:RegisterForClicks("AnyUp")
   self:RegisterEvent("GROUP_ROSTER_UPDATE")
   self:RegisterEvent("GROUP_ROSTER_UPDATE")
   self:RegisterEvent("PLAYER_ENTERING_WORLD")
   self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
   self.healthbar = getglobal(self:GetName().."_HealthBar")
   self.name = getglobal(self:GetName().."_Name")
   self.tankicon = getglobal(self:GetName().."_TM_Tank_Icon")
   self.healicon = getglobal(self:GetName().."_TM_Friendly_Icon")
   self.oomicon = getglobal(self:GetName().."_TM_OOM_Icon")
   self.taunticon = getglobal(self:GetName().."_TM_Taunt_Icon")
   self.cshouticon = getglobal(self:GetName().."_TM_cShout_Icon")
   self.mblowicon = getglobal(self:GetName().."_TM_mBlow_Icon")
   self.horeckoningicon = getglobal(self:GetName().."_TM_HoReckoning_Icon")
   self.rdefenseicon = getglobal(self:GetName().."_TM_rDefense_Icon")
   self.dcommandicon = getglobal(self:GetName().."_TM_dCommand_Icon")
   self.dgripicon = getglobal(self:GetName().."_TM_dGrip_Icon")
   self.growlicon = getglobal(self:GetName().."_TM_Growl_Icon")
   self.croaricon = getglobal(self:GetName().."_TM_cRoar_Icon")
   self:SetAttribute("type", "macro")
   self:SetAttribute("alt-ctrl-macrotext*", "/assist mouseover")
   local class = select(2, UnitClass('player'))
   self:RegisterEvent('ADDON_LOADED')
   self:RegisterEvent('PLAYER_LOGIN')
   self:RegisterEvent("PLAYER_TARGET_CHANGED")
   self:RegisterEvent("UNIT_SPELLCAST_SENT")
   self:RegisterEvent("PLAYER_REGEN_DISABLED")
   self:RegisterEvent("PLAYER_REGEN_ENABLED")
   self:RegisterEvent("UNIT_TARGET")
end

function TauntMaster2_Button_OnEvent(self, event, ...)
    if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end				
        else
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
       end
       self:SetWidth(TauntMaster2DB.width)
       self:SetHeight(TauntMaster2DB.height)
        local SPELL1 = TauntMaster2_EditBox:GetText()
        local SHIFTSPELL1 = TauntMaster2_ShiftEditBox:GetText()
        local CTRLSPELL1 = TauntMaster2_CtrlEditBox:GetText()
        local ALTSPELL1 = TauntMaster2_AltEditBox:GetText()
        local SPELL2 = TauntMaster2_EditBox2:GetText()
        local SHIFTSPELL2 = TauntMaster2_ShiftEditBox2:GetText()
        local CTRLSPELL2 = TauntMaster2_CtrlEditBox2:GetText()
        local ALTSPELL2 = TauntMaster2_AltEditBox2:GetText()
        local SPELL3 = TauntMaster2_EditBox3:GetText()
        local SHIFTSPELL3 = TauntMaster2_ShiftEditBox3:GetText()
        local CTRLSPELL3 = TauntMaster2_CtrlEditBox3:GetText()
        local ALTSPELL3 = TauntMaster2_AltEditBox3:GetText()
        local SPELL4 = TauntMaster2_EditBox4:GetText()
        local SHIFTSPELL4 = TauntMaster2_ShiftEditBox4:GetText()
        local CTRLSPELL4 = TauntMaster2_CtrlEditBox4:GetText()
        local ALTSPELL4 = TauntMaster2_AltEditBox4:GetText()
        local SPELL5 = TauntMaster2_EditBox5:GetText()
        local SHIFTSPELL5 = TauntMaster2_ShiftEditBox5:GetText()
        local CTRLSPELL5 = TauntMaster2_CtrlEditBox5:GetText()
        local ALTSPELL5 = TauntMaster2_AltEditBox5:GetText()
        local TARGET1 = DropDown_Button:GetText()
        local SHIFTTARGET1 = ShiftDropDown_Button:GetText()
        local CTRLTARGET1 = CtrlDropDown_Button:GetText()
        local ALTTARGET1 = AltDropDown_Button:GetText()
        local TARGET2 = DropDown2_Button:GetText()
        local SHIFTTARGET2 = ShiftDropDown2_Button:GetText()
        local CTRLTARGET2 = CtrlDropDown2_Button:GetText()
        local ALTTARGET2 = AltDropDown2_Button:GetText()
        local TARGET3 = DropDown3_Button:GetText()
        local SHIFTTARGET3 = ShiftDropDown3_Button:GetText()
        local CTRLTARGET3 = CtrlDropDown3_Button:GetText()
        local ALTTARGET3 = AltDropDown3_Button:GetText()
        local TARGET4 = DropDown4_Button:GetText()
        local SHIFTTARGET4 = ShiftDropDown4_Button:GetText()
        local CTRLTARGET4 = CtrlDropDown4_Button:GetText()
        local ALTTARGET4 = AltDropDown4_Button:GetText()
        local TARGET5 = DropDown5_Button:GetText()
        local SHIFTTARGET5 = ShiftDropDown5_Button:GetText()
        local CTRLTARGET5 = CtrlDropDown5_Button:GetText()
        local ALTTARGET5 = AltDropDown5_Button:GetText()
        self:SetAttribute("macrotext1", "/cast "..TARGET1 ..SPELL1)
        self:SetAttribute("shift-macrotext1", "/cast "..SHIFTTARGET1 ..SHIFTSPELL1)
        self:SetAttribute("ctrl-macrotext1", "/cast "..CTRLTARGET1 ..CTRLSPELL1)
        self:SetAttribute("alt-macrotext1", "/cast "..ALTTARGET1 ..ALTSPELL1)
        self:SetAttribute("macrotext2", "/cast "..TARGET2 ..SPELL2)
        self:SetAttribute("shift-macrotext2", "/cast "..SHIFTTARGET2 ..SHIFTSPELL2)
        self:SetAttribute("ctrl-macrotext2", "/cast "..CTRLTARGET2 ..CTRLSPELL2)
        self:SetAttribute("alt-macrotext2", "/cast "..ALTTARGET2 ..ALTSPELL2)
        self:SetAttribute("macrotext3", "/cast "..TARGET3 ..SPELL3)
        self:SetAttribute("shift-macrotext3", "/cast "..SHIFTTARGET3 ..SHIFTSPELL3)
        self:SetAttribute("ctrl-macrotext3", "/cast "..CTRLTARGET3 ..CTRLSPELL3)
        self:SetAttribute("alt-macrotext3", "/cast "..ALTTARGET3 ..ALTSPELL3)
        self:SetAttribute("macrotext4", "/cast "..TARGET4 ..SPELL4)
        self:SetAttribute("shift-macrotext4", "/cast "..SHIFTTARGET4 ..SHIFTSPELL4)
        self:SetAttribute("ctrl-macrotext4", "/cast "..CTRLTARGET4 ..CTRLSPELL4)
        self:SetAttribute("alt-macrotext4", "/cast "..ALTTARGET4 ..ALTSPELL4)
        self:SetAttribute("macrotext5", "/cast "..TARGET5 ..SPELL5)
        self:SetAttribute("shift-macrotext5", "/cast "..SHIFTTARGET5 ..SHIFTSPELL5)
        self:SetAttribute("ctrl-macrotext5", "/cast "..CTRLTARGET5 ..CTRLSPELL5)
        self:SetAttribute("alt-macrotext5", "/cast "..ALTTARGET5 ..ALTSPELL5)
        self.healicon:Hide()
        self.tankicon:Hide()
        self.oomicon:Hide()
        self.taunticon:Hide()
        self.cshouticon:Hide()
        self.mblowicon:Hide()
        self.horeckoningicon:Hide()
        self.rdefenseicon:Hide()
        self.dcommandicon:Hide()
        self.dgripicon:Hide()
        self.growlicon:Hide()
        self.croaricon:Hide()
        if TauntMaster2DBChar.hideTM == nil then
            TauntMaster2_Header:Show()
        elseif TauntMaster2DBChar.hideTM == 1 then
            TauntMaster2_Header:Hide()
        end
        if TauntMaster2DBChar.hideTMMM == nil then
            MiniMap_MinimapButton:Show()
        elseif TauntMaster2DBChar.hideTMMM == 1 then
            MiniMap_MinimapButton:Hide()
        end
    end
    --local unit = ...

    if event == "PLAYER_LOGIN" then
       DEFAULT_CHAT_FRAME:AddMessage("TauntMaster2: Type /tm to customize the addon.")
       DEFAULT_CHAT_FRAME:AddMessage("TauntMaster2 RESTORED I'm sorry that it was shut down i really didn't think a lot used it as there was no issue reports when there is a lot of issues! I would like to welcome trrecordings back i will be working with him to make this addon more amazing! Maybe even bring back Raid warning! ")
    end
    
	 if event=="PLAYER_ENTERING_WORLD" or event=="GROUP_ROSTER_UPDATE" or event=="GROUP_ROSTER_UPDATE" then
        TauntMaster2_Button_OnShow(self)
    end
    
    
    local unit = self:GetAttribute("unit")
    


end

function TauntMaster2_Button_OnShow(self)
  local unit = self:GetAttribute("unit")
  if unit then
    local class, key = select(2, UnitClass(unit)) or "WARRIOR"  
    local color = RAID_CLASS_COLORS[class]   
    self.name:SetText(UnitName(unit))
    self.name:SetTextColor(color.r, color.g, color.b)
  end
end

local total = 0


function TauntMaster2_Button_OnUpdate(self, elapsed)
    if TauntMaster2DB.showTaunts == nil and TauntMaster2DB.showTaunts2 ~= nil then
        local sTaunt, dTaunt, eTaunt = GetSpellCooldown(355);
        local sCShout, dCShout, eCShout = GetSpellCooldown(1161);
        local sMBlow, dMBlow, eMBlow = GetSpellCooldown(694);
        local sHReckoning, dHReckoning, eHReckoning = GetSpellCooldown(62124);
        local sRDefense, dRDefense, eRDefense = GetSpellCooldown(31789);
        local sDCommand, dDCommand, eDCommand = GetSpellCooldown(56222);
        local sDGrip, dDGrip, eDGrip = GetSpellCooldown(49576);
        local sGrowl, dGrowl, eGrowl = GetSpellCooldown(6795);
        local sCRoar, dCRoar, eCRoar = GetSpellCooldown(5209);
        local class = select(2, UnitClass('player'))
        if class == "WARRIOR" then
            if (sTaunt == 0 and dTaunt == 0) then
                self.taunticon:Show()
            else
                self.taunticon:Hide()
            end
            if (sCShout == 0 and dCShout == 0) then
                self.cshouticon:Show()
            else
                self.cshouticon:Hide()
            end
            if (sMBlow == 0 and dMBlow == 0) then
                self.mblowicon:Show()
            else
                self.mblowicon:Hide()
            end
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
        if class == "PALADIN" then
            if (sHReckoning == 0 and dHReckoning == 0) then
                self.horeckoningicon:Show()
            else
                self.horeckoningicon:Hide()
            end
            if (sRDefense == 0 and dRDefense == 0) then
                self.rdefenseicon:Show()
            else
                self.rdefenseicon:Hide()
            end
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
        if class == "DEATHKNIGHT" then
            if (sDCommand == 0 and dDCommand == 0) then
                self.dcommandicon:Show()
            else
                self.dcommandicon:Hide()
            end
            if (sDGrip == 0 and dDGrip == 0) then
                self.dgripicon:Show()
            else
                self.dgripicon:Hide()
            end
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
        if class == "DRUID" then
            if (sGrowl == 0 and dGrowl == 0) then
                self.growlicon:Show()
            else
                self.growlicon:Hide()
            end
            if (sCRoar == 0 and dCRoar == 0) then
                self.croaricon:Show()
            else
                self.croaricon:Hide()
            end
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
        end
        if class == "WARLOCK" or class == "MAGE" or class == "SHAMAN" or class == "PRIEST" or class == "ROGUE" or class == "HUNTER" then
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
    end
    if TauntMaster2DB.showTaunts2 == nil and TauntMaster2DB.showTaunts ~= nil then
        local sTaunt, dTaunt, eTaunt = GetSpellCooldown(355);
        local sCShout, dCShout, eCShout = GetSpellCooldown(1161);
        local sMBlow, dMBlow, eMBlow = GetSpellCooldown(694);
        local sHReckoning, dHReckoning, eHReckoning = GetSpellCooldown(62124);
        local sRDefense, dRDefense, eRDefense = GetSpellCooldown(31789);
        local sDCommand, dDCommand, eDCommand = GetSpellCooldown(56222);
        local sDGrip, dDGrip, eDGrip = GetSpellCooldown(49576);
        local sGrowl, dGrowl, eGrowl = GetSpellCooldown(6795);
        local sCRoar, dCRoar, eCRoar = GetSpellCooldown(5209);
        local class = select(2, UnitClass('player'))
        if class == "WARRIOR" then
            if (sTaunt == 0 and dTaunt == 0) then
                self.taunticon:Hide()
            else
                self.taunticon:Show()
            end
            if (sCShout == 0 and dCShout == 0) then
                self.cshouticon:Hide()
            else
                self.cshouticon:Show()
            end
            if (sMBlow == 0 and dMBlow == 0) then
                self.mblowicon:Hide()
            else
                self.mblowicon:Show()
            end
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
        if class == "PALADIN" then
            if (sHReckoning == 0 and dHReckoning == 0) then
                self.horeckoningicon:Hide()
            else
                self.horeckoningicon:Show()
            end
            if (sRDefense == 0 and dRDefense == 0) then
                self.rdefenseicon:Hide()
            else
                self.rdefenseicon:Show()
            end
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
        if class == "DEATHKNIGHT" then
            if (sDCommand == 0 and dDCommand == 0) then
                self.dcommandicon:Hide()
            else
                self.dcommandicon:Show()
            end
            if (sDGrip == 0 and dDGrip == 0) then
                self.dgripicon:Hide()
            else
                self.dgripicon:Show()
            end
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
        if class == "DRUID" then
            if (sGrowl == 0 and dGrowl == 0) then
                self.growlicon:Hide()
            else
                self.growlicon:Show()
            end
            if (sCRoar == 0 and dCRoar == 0) then
                self.croaricon:Hide()
            else
                self.croaricon:Show()
            end
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
        end
        if class == "WARLOCK" or class == "MAGE" or class == "SHAMAN" or class == "PRIEST" or class == "ROGUE" or class == "HUNTER" then
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end
    end
    
    
    if TauntMaster2DB.showTaunts2 == nil and TauntMaster2DB.showTaunts == nil then
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
    end

    if TauntMaster2DB.showTaunts2 ~= nil and TauntMaster2DB.showTaunts ~= nil then
        local class = select(2, UnitClass('player'))
        if class == "WARRIOR" then
                self.taunticon:Show()
                self.cshouticon:Show()
                self.mblowicon:Show()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        elseif class == "PALADIN" then
                self.horeckoningicon:Show()
                self.rdefenseicon:Show()
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        elseif class == "DEATHKNIGHT" then
                self.dcommandicon:Show()
                self.dgripicon:Show()
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        elseif class == "DRUID" then
                self.growlicon:Show()
                self.croaricon:Show()
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
        elseif class == "WARLOCK" or class == "MAGE" or class == "SHAMAN" or class == "PRIEST" or class == "ROGUE" or class == "HUNTER" then
            self.taunticon:Hide()
            self.cshouticon:Hide()
            self.mblowicon:Hide()
            self.horeckoningicon:Hide()
            self.rdefenseicon:Hide()
            self.dcommandicon:Hide()
            self.dgripicon:Hide()
            self.growlicon:Hide()
            self.croaricon:Hide()
        end

    end

    local unit = self:GetAttribute("unit")
    if unit then
      local r, g, b = GetThreatStatusColor(UnitThreatSituation(unit))
      self.healthbar:SetStatusBarColor(r, g, b)
    end
    if self:GetAttribute("unit") == unit then
        self.healthbar:SetValue(UnitHealth(unit))
        self.healthbar:SetMinMaxValues(0, UnitHealthMax(unit))
    end
    

          
          
 if TauntMaster2DB.showTank == nil then
    local bloodPresence = GetSpellInfo(48263)
    local righteousFury = GetSpellInfo(25781)
    local bearForm = GetSpellInfo(5487)
    local StanceoftheSturdyOx = GetSpellInfo(115069)
            if UnitInParty(unit) or UnitInRaid(unit) or UnitIsPlayer(unit) then
                local unitClass = select(2, UnitClass(unit))
                if unitClass == "WARRIOR" then
                    local shieldLink = GetInventoryItemLink(unit, 17)
                    if shieldLink then
                    local sName, sLink, iRarity, iLevel, iMinLevel, sType, sSubType, iStackCount = GetItemInfo(shieldLink)
                        if sSubType == "Shields" then
                            self.tankicon:Show()
                            self.tankicon:SetAllPoints(self.healthbar)
                        else
                            self.tankicon:Hide()
                        end
                    end
                elseif unitClass == "DEATHKNIGHT" then
                    if UnitBuff(unit, bloodPresence)then
                        self.tankicon:Show()
                        self.tankicon:SetAllPoints(self.healthbar)
                    else
                        self.tankicon:Hide()
                    end
                elseif unitClass == "PALADIN" then
                    if UnitBuff(unit, righteousFury) then
                        self.tankicon:Show()
                        self.tankicon:SetAllPoints(self.healthbar)
                    else
                        self.tankicon:Hide()
                    end
                elseif unitClass == "MONK" then
                    if UnitBuff(unit, StanceoftheSturdyOx) then
                        self.tankicon:Show()
                        self.tankicon:SetAllPoints(self.healthbar)
                    else
                        self.tankicon:Hide()
                    end					
                elseif unitClass == "DRUID" then
                    if UnitBuff(unit, bearForm) then
                        self.tankicon:Show()
                        self.tankicon:SetAllPoints(self.healthbar)
                    else
                        self.tankicon:Hide()
                    end
                else
                    self.tankicon:Hide()
                end
            else
                self.tankicon:Hide()
            end
        else
            self.tankicon:Hide()
        end
  if TauntMaster2DB.showOOM == nil then
    if UnitInParty(unit) or UnitInRaid(unit) or UnitIsPlayer(unit) then
        local unitsClass = select(2, UnitClass(unit))
        if unitsClass == "PALADIN" or unitsClass == "PRIEST" or unitsClass == "SHAMAN" or unitsClass == "DRUID" or unitsClass == "WARLOCK" or unitsClass == "HUNTER"or unitsClass == "MONK" then
        local power = UnitPower(unit)
        local maxpower = UnitPowerMax(unit)
        local powerType = UnitPowerType(unit)
            if not UnitIsDeadOrGhost(unit) then
              if powerType == 0 then
               if TauntMaster2_EditBox_OOM:GetText() ~= "" then
                if power <= (maxpower * (TauntMaster2_EditBox_OOM:GetText() / 100)) then
                    self.oomicon:Show()
                    self.oomicon:SetAllPoints(self.healthbar)
                else
                    self.oomicon:Hide()
                end
               end
              else
                self.oomicon:Hide()
              end
            else
                self.oomicon:Hide()
            end
        else
            self.oomicon:Hide()
        end
    end
  else
      self.oomicon:Hide()
  end
    if TauntMaster2DB.showFriendly == nil then
        if UnitIsFriend(unit, unit.."target") then
            self.healicon:SetAllPoints(self.healthbar)
            self.healicon:Show()
        else
            self.healicon:Hide()
        end
    else
        self.healicon:Hide()
    end
    if InCombatLockdown() then
        local class = select(2, UnitClass('player'))
        if class == "WARLOCK" then
            local lockSpell = GetSpellInfo(5697)
            local inRange = IsSpellInRange(lockSpell,unit.."target")
                if UnitExists(unit.."target") then
                    if inRange == 1 then
                        if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                            self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                        end
                    elseif inRange == 0 then
                        if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                            self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                        end
                    end  
                else
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "WARRIOR" then
                    local warriorSpell = GetSpellInfo(355)

            local inRange = IsSpellInRange(warriorSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "PALADIN" then
            local paladinSpell = GetSpellInfo(62124)

            local inRange = IsSpellInRange(paladinSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "MAGE" then
             local mageSpell = GetSpellInfo(130)

            local inRange = IsSpellInRange(mageSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "PRIEST" then
             local priestSpell = GetSpellInfo(6346)

            local inRange = IsSpellInRange(priestSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "SHAMAN" then
             local shamanSpell = GetSpellInfo(131)

            local inRange = IsSpellInRange(shamanSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "DEATHKNIGHT" then
             local dkSpell = GetSpellInfo(47476)

            local inRange = IsSpellInRange(dkSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "DRUID" then
              local druidSpell = GetSpellInfo(6795)

            local inRange = IsSpellInRange(druidSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "ROGUE" then
              local rogueSpell = GetSpellInfo(26679)

            local inRange = IsSpellInRange(rogueSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        elseif class == "MONK" then
              local monkSpell = GetSpellInfo(100780)

            local inRange = IsSpellInRange(monkSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end				
        elseif class == "HUNTER" then
              local hunterSpell = GetSpellInfo(5116)

            local inRange = IsSpellInRange(hunterSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha2:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha2:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha1:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha1:GetText() / 100))
                    end
                end
        end
        
    else
        local class = select(2, UnitClass('player'))
        if class == "WARLOCK" then
                    local lockSpell = GetSpellInfo(5697)

            local inRange = IsSpellInRange(lockSpell,unit.."target")
                if UnitExists(unit.."target") then
                    if inRange == 1 then
                        if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                            self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                        end
                    elseif inRange == 0 then
                        if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                            self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                        end
                    end
                else
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "WARRIOR" then
            local warriorSpell = GetSpellInfo(355)

            local inRange = IsSpellInRange(warriorSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "PALADIN" then
             local paladinSpell = GetSpellInfo(62124)

            local inRange = IsSpellInRange(paladinSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "MAGE" then
             local mageSpell = GetSpellInfo(130)

            local inRange = IsSpellInRange(mageSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "PRIEST" then
             local priestSpell = GetSpellInfo(6346)

            local inRange = IsSpellInRange(priestSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "SHAMAN" then
             local shamanSpell = GetSpellInfo(131)

            local inRange = IsSpellInRange(shamanSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "DEATHKNIGHT" then
             local dkSpell = GetSpellInfo(47476)

            local inRange = IsSpellInRange(dkSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "DRUID" then
              local druidSpell = GetSpellInfo(6795)

            local inRange = IsSpellInRange(druidSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "ROGUE" then
              local rogueSpell = GetSpellInfo(26679)

            local inRange = IsSpellInRange(rogueSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        elseif class == "MONK" then
              local monkSpell = GetSpellInfo(100780)

            local inRange = IsSpellInRange(monkSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end				
        elseif class == "HUNTER" then
              local hunterSpell = GetSpellInfo(5116)

            local inRange = IsSpellInRange(hunterSpell,unit.."target")
                if inRange == 1 then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                elseif inRange == 0 then
                    if TauntMaster2_EditBox_Alpha4:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha4:GetText() / 100))
                    end
                elseif inRange == nil then
                    if TauntMaster2_EditBox_Alpha3:GetText() ~= "" then
                        self.healthbar:SetAlpha((TauntMaster2_EditBox_Alpha3:GetText() / 100))
                    end
                end
        end

        self:SetWidth(Width:GetValue())
        self:SetHeight(Height:GetValue())
        total = total + elapsed
        if total >= 1 then
            local SPELL1 = TauntMaster2_EditBox:GetText()
            local SHIFTSPELL1 = TauntMaster2_ShiftEditBox:GetText()
            local CTRLSPELL1 = TauntMaster2_CtrlEditBox:GetText()
            local ALTSPELL1 = TauntMaster2_AltEditBox:GetText()
            local SPELL2 = TauntMaster2_EditBox2:GetText()
            local SHIFTSPELL2 = TauntMaster2_ShiftEditBox2:GetText()
            local CTRLSPELL2 = TauntMaster2_CtrlEditBox2:GetText()
            local ALTSPELL2 = TauntMaster2_AltEditBox2:GetText()
            local SPELL3 = TauntMaster2_EditBox3:GetText()
            local SHIFTSPELL3 = TauntMaster2_ShiftEditBox3:GetText()
            local CTRLSPELL3 = TauntMaster2_CtrlEditBox3:GetText()
            local ALTSPELL3 = TauntMaster2_AltEditBox3:GetText()
            local SPELL4 = TauntMaster2_EditBox4:GetText()
            local SHIFTSPELL4 = TauntMaster2_ShiftEditBox4:GetText()
            local CTRLSPELL4 = TauntMaster2_CtrlEditBox4:GetText()
            local ALTSPELL4 = TauntMaster2_AltEditBox4:GetText()
            local SPELL5 = TauntMaster2_EditBox5:GetText()
            local SHIFTSPELL5 = TauntMaster2_ShiftEditBox5:GetText()
            local CTRLSPELL5 = TauntMaster2_CtrlEditBox5:GetText()
            local ALTSPELL5 = TauntMaster2_AltEditBox5:GetText()
            local TARGET1 = DropDown_Button:GetText()
            local SHIFTTARGET1 = ShiftDropDown_Button:GetText()
            local CTRLTARGET1 = CtrlDropDown_Button:GetText()
            local ALTTARGET1 = AltDropDown_Button:GetText()
            local TARGET2 = DropDown2_Button:GetText()
            local SHIFTTARGET2 = ShiftDropDown2_Button:GetText()
            local CTRLTARGET2 = CtrlDropDown2_Button:GetText()
            local ALTTARGET2 = AltDropDown2_Button:GetText()
            local TARGET3 = DropDown3_Button:GetText()
            local SHIFTTARGET3 = ShiftDropDown3_Button:GetText()
            local CTRLTARGET3 = CtrlDropDown3_Button:GetText()
            local ALTTARGET3 = AltDropDown3_Button:GetText()
            local TARGET4 = DropDown4_Button:GetText()
            local SHIFTTARGET4 = ShiftDropDown4_Button:GetText()
            local CTRLTARGET4 = CtrlDropDown4_Button:GetText()
            local ALTTARGET4 = AltDropDown4_Button:GetText()
            local TARGET5 = DropDown5_Button:GetText()
            local SHIFTTARGET5 = ShiftDropDown5_Button:GetText()
            local CTRLTARGET5 = CtrlDropDown5_Button:GetText()
            local ALTTARGET5 = AltDropDown5_Button:GetText()
            self:SetAttribute("macrotext1", "/cast "..TARGET1 ..SPELL1)
            self:SetAttribute("shift-macrotext1", "/cast "..SHIFTTARGET1 ..SHIFTSPELL1)
            self:SetAttribute("ctrl-macrotext1", "/cast "..CTRLTARGET1 ..CTRLSPELL1)
            self:SetAttribute("alt-macrotext1", "/cast "..ALTTARGET1 ..ALTSPELL1)
            self:SetAttribute("macrotext2", "/cast "..TARGET2 ..SPELL2)
            self:SetAttribute("shift-macrotext2", "/cast "..SHIFTTARGET2 ..SHIFTSPELL2)
            self:SetAttribute("ctrl-macrotext2", "/cast "..CTRLTARGET2 ..CTRLSPELL2)
            self:SetAttribute("alt-macrotext2", "/cast "..ALTTARGET2 ..ALTSPELL2)
            self:SetAttribute("macrotext3", "/cast "..TARGET3 ..SPELL3)
            self:SetAttribute("shift-macrotext3", "/cast "..SHIFTTARGET3 ..SHIFTSPELL3)
            self:SetAttribute("ctrl-macrotext3", "/cast "..CTRLTARGET3 ..CTRLSPELL3)
            self:SetAttribute("alt-macrotext3", "/cast "..ALTTARGET3 ..ALTSPELL3)
            self:SetAttribute("macrotext4", "/cast "..TARGET4 ..SPELL4)
            self:SetAttribute("shift-macrotext4", "/cast "..SHIFTTARGET4 ..SHIFTSPELL4)
            self:SetAttribute("ctrl-macrotext4", "/cast "..CTRLTARGET4 ..CTRLSPELL4)
            self:SetAttribute("alt-macrotext4", "/cast "..ALTTARGET4 ..ALTSPELL4)
            self:SetAttribute("macrotext5", "/cast "..TARGET5 ..SPELL5)
            self:SetAttribute("shift-macrotext5", "/cast "..SHIFTTARGET5 ..SHIFTSPELL5)
            self:SetAttribute("ctrl-macrotext5", "/cast "..CTRLTARGET5 ..CTRLSPELL5)
            self:SetAttribute("alt-macrotext5", "/cast "..ALTTARGET5 ..ALTSPELL5)
            if LockTauntMaster2:GetChecked() == nil then
                self:RegisterForDrag("LeftButton")
            elseif LockTauntMaster2:GetChecked() == 1 then
                self:RegisterForDrag(nil)
            end
            total = 0
        end
 

          
    end
end


function TauntMaster2_Button_OnDragStart(self, button)
  TauntMaster2_Header:StartMoving()
  TauntMaster2_Header.isMoving = true
end

function TauntMaster2_Button_OnDragStop(self, button)
  if TauntMaster2_Header.isMoving then
    TauntMaster2_Header:StopMovingOrSizing()
  end
end

function TauntMaster2_Button_val1_OnLoad(self,vText,Min,Max,Step)
    self.text = vText;
    getglobal(self:GetName().."Text"):SetText(vText);
    getglobal(self:GetName().."Low"):SetText(Min);
    getglobal(self:GetName().."High"):SetText(Max);
    self:SetMinMaxValues(Min,Max);
    self:SetValueStep(Step);
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
	    TauntMaster2DB = TauntMaster2DB or {}
	    for option, value in pairs(defaults) do
	      if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
	    end
        self:SetValue(TauntMaster2DB.height)
        self:SetObeyStepOnDrag(true)
        FontString6:SetText(TauntMaster2DB.height)
	  end
    end)
end

function TauntMaster2_Button_val2_OnLoad(self,vText,Min,Max,Step)
    self.text = vText;
    getglobal(self:GetName().."Text"):SetText(vText);
    getglobal(self:GetName().."Low"):SetText(Min);
    getglobal(self:GetName().."High"):SetText(Max);
    self:SetMinMaxValues(Min,Max);
    self:SetValueStep(Step);
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetValue(TauntMaster2DB.width)
        self:SetObeyStepOnDrag(true)
        FontString7:SetText(TauntMaster2DB.width)
	  end
    end)
end

function TauntMaster2_Button_val1_OnValueChanged(self)
    TauntMaster2DB.height = Height:GetValue()
    FontString6:SetText(self:GetValue())
end

function TauntMaster2_Button_val2_OnValueChanged(self)
    TauntMaster2DB.width = Width:GetValue()
    FontString7:SetText(self:GetValue())
end

function TauntMaster2_Options_OnDragStart(self, button)
  TMConfig:StartMoving()
  TMConfig.isMoving = true
end

function TauntMaster2_Options_OnDragStop(self, button)
  if TMConfig.isMoving then
    TMConfig:StopMovingOrSizing()
  end
end

function TauntMaster2_Button_val4_OnLoad(self,vText,Min,Max,Step)
    self.text = vText;
    getglobal(self:GetName().."Text"):SetText(vText);
    getglobal(self:GetName().."Low"):SetText(Min);
    getglobal(self:GetName().."High"):SetText(Max);
    self:SetMinMaxValues(Min,Max);
    self:SetValueStep(Step);
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetValue(TauntMaster2DB.maxColumns)
        self:SetObeyStepOnDrag(true)
        FontString8:SetText(TauntMaster2DB.maxColumns)
	  end
    end)
end

function TauntMaster2_Button_val5_OnLoad(self,vText,Min,Max,Step)
    self.text = vText;
    getglobal(self:GetName().."Text"):SetText(vText);
    getglobal(self:GetName().."Low"):SetText(Min);
    getglobal(self:GetName().."High"):SetText(Max);
    self:SetMinMaxValues(Min,Max);
    self:SetValueStep(Step);
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetValue(TauntMaster2DB.unitsPerColumn)
        self:SetObeyStepOnDrag(true)
        FontString9:SetText(TauntMaster2DB.unitsPerColumn)
	  end
    end)
end

function TauntMaster2_Button_Cols_OnUpdate(self)
    TauntMaster2_Header:SetAttribute("maxColumns", TauntMaster2DB.maxColumns)
    TauntMaster2_Header:SetAttribute("unitsPerColumn", TauntMaster2DB.unitsPerColumn)
end

function TauntMaster2_Button_val3_OnValueChanged(self)
    TauntMaster2DB.maxColumns = maxColumns:GetValue()
    FontString8:SetText(self:GetValue())
    TauntMaster2_Header:SetAttribute("maxColumns", TauntMaster2DB.maxColumns)
end

function TauntMaster2_Button_val4_OnValueChanged(self)
    TauntMaster2DB.unitsPerColumn = unitsPerColumn:GetValue()
    FontString9:SetText(self:GetValue())
    TauntMaster2_Header:SetAttribute("unitsPerColumn", TauntMaster2DB.unitsPerColumn)
end

SLASH_TauntMaster2_SLASH_COMMAND1 = "/TauntMaster2";
SLASH_TauntMaster2_SLASH_COMMAND2 = "/tm";
local function handler(msg, editbox)
 if msg == 'display' then
  TMConfig:Show();
 elseif msg == 'spells' then
  TauntMaster2MouseButtons:Show();
 elseif msg == 'show' then
  TauntMaster2_Header:Show();
  TauntMaster2DBChar.hideTM = nil
 elseif msg == 'hide' then
  TauntMaster2_Header:Hide();
  TauntMaster2DBChar.hideTM = 1
 elseif msg == 'toggle' then
  if TauntMaster2DBChar.hideTM == 1 then
    TauntMaster2_Header:Show();
    TauntMaster2DBChar.hideTM = nil
  elseif TauntMaster2DBChar.hideTM == nil then
    TauntMaster2_Header:Hide();
    TauntMaster2DBChar.hideTM = 1
  end
 else
  TMOptionsMenu:Show();
 end
end
SlashCmdList["TauntMaster2_SLASH_COMMAND"] = handler;

function MiniMapButton_OnLoad()
   MiniMap_MinimapButton:RegisterForClicks("LeftButtonUp","RightButtonUp")
   MiniMap_MinimapButton:RegisterForDrag("LeftButton","RightButton")
   MiniMap_MinimapButton:RegisterEvent('ADDON_LOADED')
   MiniMap_MinimapButton:SetScript('OnEvent', function(self, event, ...)
     if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
	   TauntMaster2DB = TauntMaster2DB or {}
       MiniMap_MinimapButton:SetPoint("TOPLEFT","Minimap","TOPLEFT",52-(80*cos(TauntMaster2DB.MinimapPos)),(80*sin(TauntMaster2DB.MinimapPos))-52)
	 end
   end)
end

function MiniMap_MinimapButton_Reposition()
	MiniMap_MinimapButton:SetPoint("TOPLEFT","Minimap","TOPLEFT",52-(80*cos(TauntMaster2DB.MinimapPos)),(80*sin(TauntMaster2DB.MinimapPos))-52)
end


function MiniMap_MinimapButton_DraggingFrame_OnUpdate()

	local xpos,ypos = GetCursorPosition()
	local xmin,ymin = Minimap:GetLeft(), Minimap:GetBottom()

	xpos = xmin-xpos/UIParent:GetScale()+70 
	ypos = ypos/UIParent:GetScale()-ymin-70

	TauntMaster2DB.MinimapPos = math.deg(math.atan2(ypos,xpos)) 
	MiniMap_MinimapButton_Reposition()
end

function LockTauntMaster2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetChecked(TauntMaster2DB.checked)
	  end
    end)
end

function TMEditBox_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end				
        else
                TauntMaster2DBChar = TauntMaster2DBChar or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
       end
      self:SetText(TauntMaster2DBChar.SPELL1)        
	  end
    end)
end

function TMEditBox_OnCursorChanged(self)
    TauntMaster2DBChar.SPELL1 = self:GetText()
end

function TMShiftEditBox_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTSPELL1)        
	  end
    end)
end

function TMShiftEditBox_OnCursorChanged(self)
    TauntMaster2DBChar.SHIFTSPELL1 = self:GetText()
end

function TMCtrlEditBox_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLSPELL1)        
	  end
    end)
end

function TMCtrlEditBox_OnCursorChanged(self)
    TauntMaster2DBChar.CTRLSPELL1 = self:GetText()
end

function TMAltEditBox_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTSPELL1)        
	  end
    end)
end

function TMAltEditBox_OnCursorChanged(self)
    TauntMaster2DBChar.ALTSPELL1 = self:GetText()
end

function DropDown_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end      
        self:SetText(TauntMaster2DBChar.TARGET1)        
	  end
    end)
end

function ShiftDropDown_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTTARGET1)    
	  end
    end)
end

function CtrlDropDown_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLTARGET1)        
	  end
    end)
end

function AltDropDown_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTTARGET1)        
	  end
    end)
end

function TauntMaster2_LeftButton_OnDragStart(self, button)
  LeftButtonFrame:StartMoving()
  LeftButtonFrame.isMoving = true
end

function TauntMaster2_LeftButton_OnDragStop(self, button)
  if LeftButtonFrame.isMoving then
    LeftButtonFrame:StopMovingOrSizing()
  end
end

function TMEditBox2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SPELL2)
	  end
    end)
end

function TMEditBox2_OnCursorChanged(self)
    TauntMaster2DBChar.SPELL2 = self:GetText()
end

function TMShiftEditBox2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTSPELL2)        
	  end
    end)
end

function TMShiftEditBox2_OnCursorChanged(self)
    TauntMaster2DBChar.SHIFTSPELL2 = self:GetText()
end

function TMCtrlEditBox2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLSPELL2)        
	  end
    end)
end

function TMCtrlEditBox2_OnCursorChanged(self)
    TauntMaster2DBChar.CTRLSPELL2 = self:GetText()
end

function TMAltEditBox2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTSPELL2)        
	  end
    end)
end

function TMAltEditBox2_OnCursorChanged(self)
    TauntMaster2DBChar.ALTSPELL2 = self:GetText()
end

function DropDown2_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.TARGET2)        
	  end
    end)
end

function ShiftDropDown2_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTTARGET2)    
	  end
    end)
end

function CtrlDropDown2_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLTARGET2)        
	  end
    end)
end

function AltDropDown2_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTTARGET2)        
	  end
    end)
end

function TauntMaster2_RightButton_OnDragStart(self, button)
  RightButtonFrame:StartMoving()
  RightButtonFrame.isMoving = true
end

function TauntMaster2_RightButton_OnDragStop(self, button)
  if RightButtonFrame.isMoving then
    RightButtonFrame:StopMovingOrSizing()
  end
end

function TMEditBox3_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SPELL3)        
	  end
    end)
end

function TMEditBox3_OnCursorChanged(self)
    TauntMaster2DBChar.SPELL3 = self:GetText()
end

function TMShiftEditBox3_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTSPELL3)        
	  end
    end)
end

function TMShiftEditBox3_OnCursorChanged(self)
    TauntMaster2DBChar.SHIFTSPELL3 = self:GetText()
end

function TMCtrlEditBox3_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLSPELL3)        
	  end
    end)
end

function TMCtrlEditBox3_OnCursorChanged(self)
    TauntMaster2DBChar.CTRLSPELL3 = self:GetText()
end

function TMAltEditBox3_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTSPELL3)        
	  end
    end)
end

function TMAltEditBox3_OnCursorChanged(self)
    TauntMaster2DBChar.ALTSPELL3 = self:GetText()
end

function DropDown3_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.TARGET3)        
	  end
    end)
end

function ShiftDropDown3_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTTARGET3)    
	  end
    end)
end

function CtrlDropDown3_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLTARGET3)        
	  end
    end)
end

function AltDropDown3_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTTARGET3)        
	  end
    end)
end

function TauntMaster2_Button3_OnDragStart(self, button)
  ButtonFrame3:StartMoving()
  ButtonFrame3.isMoving = true
end

function TauntMaster2_Button3_OnDragStop(self, button)
  if ButtonFrame3.isMoving then
    ButtonFrame3:StopMovingOrSizing()
  end
end

function TMEditBox4_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SPELL4)        
	  end
    end)
end

function TMEditBox4_OnCursorChanged(self)
    TauntMaster2DBChar.SPELL4 = self:GetText()
end

function TMShiftEditBox4_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTSPELL4)        
	  end
    end)
end

function TMShiftEditBox4_OnCursorChanged(self)
    TauntMaster2DBChar.SHIFTSPELL4 = self:GetText()
end

function TMCtrlEditBox4_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLSPELL4)        
	  end
    end)
end

function TMCtrlEditBox4_OnCursorChanged(self)
    TauntMaster2DBChar.CTRLSPELL4 = self:GetText()
end

function TMAltEditBox4_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTSPELL4)        
	  end
    end)
end

function TMAltEditBox4_OnCursorChanged(self)
    TauntMaster2DBChar.ALTSPELL4 = self:GetText()
end

function DropDown4_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.TARGET4)        
	  end
    end)
end

function ShiftDropDown4_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTTARGET4)    
	  end
    end)
end

function CtrlDropDown4_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLTARGET4)        
	  end
    end)
end

function AltDropDown4_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTTARGET4)        
	  end
    end)
end

function TauntMaster2_Button4_OnDragStart(self, button)
  ButtonFrame4:StartMoving()
  ButtonFrame4.isMoving = true
end

function TauntMaster2_Button4_OnDragStop(self, button)
  if ButtonFrame4.isMoving then
    ButtonFrame4:StopMovingOrSizing()
  end
end

function TMEditBox5_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SPELL5)        
	  end
    end)
end

function TMEditBox5_OnCursorChanged(self)
    TauntMaster2DBChar.SPELL5 = self:GetText()
end

function TMShiftEditBox5_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTSPELL5)        
	  end
    end)
end

function TMShiftEditBox5_OnCursorChanged(self)
    TauntMaster2DBChar.SHIFTSPELL5 = self:GetText()
end

function TMCtrlEditBox5_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLSPELL5)        
	  end
    end)
end

function TMCtrlEditBox5_OnCursorChanged(self)
    TauntMaster2DBChar.CTRLSPELL5 = self:GetText()
end

function TMAltEditBox5_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTSPELL5)        
	  end
    end)
end

function TMAltEditBox5_OnCursorChanged(self)
    TauntMaster2DBChar.ALTSPELL5 = self:GetText()
end

function DropDown5_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.TARGET5)        
	  end
    end)
end

function ShiftDropDown5_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.SHIFTTARGET5)    
	  end
    end)
end

function CtrlDropDown5_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.CTRLTARGET5)        
	  end
    end)
end

function AltDropDown5_Button_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
      self:SetText(TauntMaster2DBChar.ALTTARGET5)        
	  end
    end)
end

function TauntMaster2_Button5_OnDragStart(self, button)
  ButtonFrame5:StartMoving()
  ButtonFrame5.isMoving = true
end

function TauntMaster2_Button5_OnDragStop(self, button)
  if ButtonFrame5.isMoving then
    ButtonFrame5:StopMovingOrSizing()
  end
end

function TauntMaster2_Button_ShowSolo_OnLoad(self)
   self:RegisterEvent('ADDON_LOADED')
   self:SetScript('OnEvent', function(self, event, ...)
     if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
       TauntMaster2DB = TauntMaster2DB or {}
       for option, value in pairs(defaults) do
         if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
       end
       self:SetChecked(TauntMaster2DB.soloCheck)
        if TauntMaster2DB.soloCheck == nil then
            TauntMaster2_Header:SetAttribute("showSolo", true)
        else
            TauntMaster2_Header:SetAttribute("showSolo", false)
        end
     end
   end)
end

function TauntMaster2_Button_ShowSolo_OnClick(self)
   TauntMaster2DB.soloCheck = self:GetChecked()
end

function TauntMaster2_Button_ShowSolo_PostClick(self)
    if TauntMaster2DB.soloCheck == nil then
        TauntMaster2_Header:SetAttribute("showSolo", true)
    else
        TauntMaster2_Header:SetAttribute("showSolo", false)
    end
end

function TauntMaster2_ShowTankBorder_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetChecked(TauntMaster2DB.showTank)
	  end
    end)
end

function TauntMaster2_ShowFriendlyBorder_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetChecked(TauntMaster2DB.showFriendly)
	  end
    end)
end

function TauntMaster2_ShowOOMBorder_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetChecked(TauntMaster2DB.showOOM)
	  end
    end)
end

function TauntMaster2_ShowTauntIcons_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetChecked(TauntMaster2DB.showTaunts)
	  end
    end)
end

function TauntMaster2_ShowTauntIcons2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        TauntMaster2DB = TauntMaster2DB or {}
        for option, value in pairs(defaults) do
          if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
        end
        self:SetChecked(TauntMaster2DB.showTaunts2)
	  end
    end)
end

function TMEditBox_OOM_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end				
        else
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
       end
      self:SetText(TauntMaster2DB.OOMlevel)        
	  end
    end)
end

function TMEditBox_OOM_OnTextChanged(self)
    TauntMaster2DB.OOMlevel = self:GetText()
end

function TMEditBox_Alpha1_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end				
        else
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
       end
      self:SetText(TauntMaster2DB.Alpha1)        
	  end
    end)
end

function TMEditBox_Alpha1_OnTextChanged(self)
    TauntMaster2DB.Alpha1 = self:GetText()
end

function TMEditBox_Alpha2_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end				
        else
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
       end
      self:SetText(TauntMaster2DB.Alpha2)        
	  end
    end)
end

function TMEditBox_Alpha2_OnTextChanged(self)
    TauntMaster2DB.Alpha2 = self:GetText()
end

function TMEditBox_Alpha3_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end				
        else
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
       end
      self:SetText(TauntMaster2DB.Alpha3)        
	  end
    end)
end

function TMEditBox_Alpha3_OnTextChanged(self)
    TauntMaster2DB.Alpha3 = self:GetText()
end

function TMEditBox_Alpha4_OnLoad(self)
    self:RegisterEvent('ADDON_LOADED')
    self:SetScript('OnEvent', function(self, event, ...)
      if event == 'ADDON_LOADED' and ... == 'TauntMaster2' then
        local class = select(2, UnitClass('player'))
        if class == "PALADIN" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(paladindefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "WARRIOR" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(warriordefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DEATHKNIGHT" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(deathknightdefaults) do
                    if not TauntMaster2DBChar[option] then TauntMaster2DBChar[option] = value end
                end
        elseif class == "DRUID" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(druiddefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
        elseif class == "MONK" then
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(monkdefaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
        else
                TauntMaster2DB = TauntMaster2DB or {}
                for option, value in pairs(defaults) do
                    if not TauntMaster2DB[option] then TauntMaster2DB[option] = value end
                end
       end
      self:SetText(TauntMaster2DB.Alpha4)        
	  end
    end)
end

function TMEditBox_Alpha4_OnTextChanged(self)
    TauntMaster2DB.Alpha4 = self:GetText()
end


 
