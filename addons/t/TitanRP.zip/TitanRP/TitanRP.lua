--[[
	TitanRP: A simple Display of current RP value
	Author: Subwired
--]]

local menutext = "Titan|cffff8800 Ranged Attack Power|r"
local buttonlabel = "RP: "
local ID = "RP"
local elap, RP, prevRP = 0, 0, -2
local GetUnitRP = 0 


-- Main button frame and addon base
local f = CreateFrame("Button", "TitanPanelRPButton", CreateFrame("Frame", nil, UIParent), "TitanPanelComboTemplate")
f:SetFrameStrata("FULLSCREEN")
f:SetScript("OnEvent", function(this, event, ...) this[event](this, ...) end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(a1)
--print ("a1 = " .. a1)
	if a1 ~= "TitanRP" then 
	return 
	end
	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil
	
	
	self.registry = {
		id = ID,
		menuText = menutext,
		buttonTextFunction = "TitanPanelRPButton_GetButtonText",
		tooltipTitle = ID,
		tooltipTextFunction = "TitanPanelRPButton_GetTooltipText",
		frequency = 0.5,
		icon = "Interface\\Icons\\Spell_nature_ravenform.blp",
		iconWidth = 16,
		category = "Information",
		savedVariables = {
			ShowIcon = 1,
			ShowLabelText = false,
			
		},
	}
	self:SetScript("OnUpdate", function(this, a1)
		elap = elap + a1
		if elap < 1 then return end
		local base, posBuff, negBuff = UnitRangedAttackPower("player");
		local effective = base + posBuff + negBuff;

	

		RP = effective -- fix
		if RP == prevRP then return end
		prevRP  = RP
		TitanPanelButton_UpdateButton(ID)
		elap = 0
	end)
		
	--TitanPanelButton_OnLoad(self)
end


function TitanPanelRPButton_GetButtonText()
	local RPtext, pitchtext
	if not RP then
		RPtext = "??"
	else
		RPtext = RP 
	end
	return buttonlabel, RPtext
end

function TitanPanelRPButton_GetTooltipText()
	return "Displays your current Ranged Attack Power value"
end

local temp = {}
local function UIDDM_Add(text, func, checked, keepShown)
	temp.text, temp.func, temp.checked, temp.keepShownOnClick = text, func, checked, keepShown
	UIDropDownMenu_AddButton(temp)
end

function TitanPanelRightClickMenu_PrepareRPMenu()
	TitanPanelRightClickMenu_AddTitle(TitanPlugins[ID].menuText)
	
	TitanPanelRightClickMenu_AddToggleIcon(ID)
	TitanPanelRightClickMenu_AddToggleLabelText(ID)
	TitanPanelRightClickMenu_AddSpacer()
	TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, ID, TITAN_PANEL_MENU_FUNC_HIDE)
end