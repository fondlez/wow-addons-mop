-- Create a frame to register and handle events
local istframe = CreateFrame("Frame", "IAEventFrame", UIParent);
istframe:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
istframe:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
istframe:RegisterEvent("UNIT_SPELLCAST_FAILED")
--iaframe:RegisterEvent("UNIT_AURA")

local ignoredSpells = {
  ["Shoot"] = true,
}

local function OnSpellCastInterrupted(self, event, unit, spellName, spellRank, spellId)
  if unit == "player" then
    -- if ignoredSpells[spellName] then
    --   print("Debug: Ignored spell - ", spellName)
    --   return
    -- end
    --PlaySound("MapPing")
  end
end

local function OnCombatLogEvent(self, event, ...)
  local timestamp, subevent, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags, spellId, spellName, spellSchool, auraType, amount = ...
  -- these are not aligned properly. but whatever'
  --print(subevent, sourceName, spellName, destName, amount)

  if (subevent == "SPELL_CAST_FAILED") then
    if (sourceName == UnitName("player")) then
      print("SPELL_CAST_FAILED")
      --PlaySound("MapPing")
    end
  end
end

local function OnSpellCastFailed(self, event, ...)
  local unit, spellName, spellRank, spellId = ...
  if unit == "player" then
    print("UNIT_SPELLCAST_FAILED")
    PlaySound("MapPing")
  end
end


local function OnEvent(self, event, ...)
  if (event == "UNIT_SPELLCAST_INTERRUPTED") then
    OnSpellCastInterrupted(self, event, ...)
  elseif (event == "COMBAT_LOG_EVENT_UNFILTERED") then
    OnCombatLogEvent(self, event, ...)
  elseif (event == "UNIT_AURA") then
    OnUnitAura(self, event, ...)
  elseif (event == "UNIT_SPELLCAST_FAILED") then
    OnSpellCastFailed(self, event, ...)
  end
end

-- Set the script to run when the event fires
istframe:SetScript("OnEvent", OnEvent)