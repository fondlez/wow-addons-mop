icicle
======

Adds enemy cooldowns to their nameplates!

/icicle or ingame menu for options.

In cases where spells have variable cooldown times I've used the lowest possible that I'm aware of, So please remember that in some cases the cooldown shown is a guideline not concrete.

Icicle uses the combat log so if cooldowns are used out of its range or are otherwise hidden from it they will not show up.

Original Addon found on http://www.wowinterface.com/downloads/info19148-Icicle.html
