local REFRESH_RATE = 0.1
local BAR_W = 120
local BAR_H = 20
local ICON_SIZE = BAR_H

local SHUFFLE_MAX = 24
local ELUSIVE_MAX = 15
local VENGEANCE_MAX = 20
local GUARD_MAX = 30

local ICONS = {
    Stagger = 'Interface\\Icons\\priest_icon_chakra_green',
}

local SPELL_IDS = {
    Stagger = 124255,
    Vengeance = 132365,
    ElusiveBrew_Stacks = 128939,
    ElusiveBrew_Buff = 115308,
    Shuffle = 115307,
    Guard = 123402,
    ZenSphere = 124081,
    DampenHarm = 122278,
    FortifyingBrew = 120954,
}
------------------------------------------------------------------

local function GetAuraData (aura)
    -- Returns time remaining, value, duration
    local name, _, _, _, _, duration, expires, _, _, _, _, _, _, _, value2 = UnitAura ('player', aura)
    if name==nil then
        return 0,0
    else
        return expires-GetTime(), value2, duration
    end
end

------------------------------------------------------------------

local function ShortNumber (n)
    if n<1000 then
        return tostring(n)
    elseif n<1000000 then
        return tostring(floor((n+500)/1000))..'K'
    else
        return tostring(floor((n+500000)/1000000))..'M'
    end
end

------------------------------------------------------------------

local function ScanPlayerAuras ()
    -- Returns a table where the keys are spell IDs and each value is a table containing name, duration, expires, value2
    local i=1
    local ret = {}
    local name, count, duration, expires, spellID, value2, _
    
    -- Scan buffs
    while true do
        local name,_,_,count,_, duration, expires,_,_,_,spellID,_,_,_, value2 = UnitBuff('player', i)
        i = i+1
        if name then
            ret[spellID] = {duration=duration, expires=expires, value2=value2, name=name, count=count}
        else
            break
        end        
    end
    
    -- Scan debuffs
    while true do
        local name,_,_,count,_, duration, expires,_,_,_,spellID,_,_,_, value2 = UnitDebuff('player', i)
        i = i+1
        if name then
            ret[spellID] = {duration=duration, expires=expires, value2=value2, name=name, count=count}
        else
            break
        end        
    end
    
    return ret
end

------------------------------------------------------------------

local _,_, class = UnitClass('player')
if class==10 then
    local f = CreateFrame ("Frame", 'frmIntoxicated', UIParent)
    f:SetSize (BAR_W + ICON_SIZE, BAR_H)
    f:SetPoint ("CENTER",UIParent,"CENTER")

    -- CreateBar!
    function f:CreateBar (spellId, barType, color, displayName)
        -- barType should be 'time', 'value' or 'stacks'
        local f = CreateFrame ("StatusBar", nil, self)
        f:SetSize (BAR_W, BAR_H)
        f:SetMinMaxValues (0,1)
        f:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        f:SetOrientation ('HORIZONTAL')
        if color then
            f:SetStatusBarColor (unpack(color))
        end
        
        f.spellId = spellId
        f.type = barType
        
        f.txt = f:CreateFontString(nil, "HIGH", "GameFontNormal")
        f.txt:SetAllPoints (f)
        f.txt:SetTextColor (1.0,1.0,1.0)
        f.txt:SetJustifyH ("CENTER")
        f.txt:SetTextHeight (11)
        
        f.tex = f:CreateTexture ("Texture", "HIGH")
        f.tex:SetSize (ICON_SIZE, ICON_SIZE)
        f.tex:SetPoint ("RIGHT", f, "LEFT")
        
        local name,_,icon = GetSpellInfo (spellId)
        f.tex:SetTexture (icon)
        f.name = displayName or name
        
        function f:Update (tblAuras)
            local valBar, valText, valMax
            if tblAuras[self.spellId] then
                if self.type == 'time' then
                    valText = format ('%.1f', tblAuras[self.spellId]['expires'] - GetTime())
                elseif self.type == 'value' then
                    valText = ShortNumber(tblAuras[self.spellId]['value2'])
                elseif self.type == 'stacks' then
                    valText = tblAuras[self.spellId]['count']
                end
                valBar = tblAuras[self.spellId]['expires'] - GetTime()
                valMax = tblAuras[self.spellId]['duration']
            else
                valBar, valText, valMax = 0,0,1
            end
            
            self:SetMinMaxValues (0, valMax)
            self:SetValue (valBar)
            self.txt:SetText (valText)
        end
        
        function f:SetTooltipText (txt)
            self:SetScript("OnEnter", function (self,motion,...)
                GameTooltip:SetOwner (self, "ANCHOR_RIGHT")
                GameTooltip:SetText (txt)
                GameTooltip:Show ()
            end)
            
            self:SetScript("OnLeave", function (self,motion,...)
                GameTooltip:Hide ()
            end)
        end
        
        return f
    end
    
    -- Background
    f.bg = CreateFrame ("Frame", nil, f)
    f.bg:SetPoint ("TOPLEFT", f, "TOPLEFT", -6, 6)
    f.bg:SetPoint ("BOTTOMRIGHT", f, "BOTTOMRIGHT", 6, -6)
    f.bg:SetBackdrop ({
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 12,
    })
    
    -- Stagger bar is special, I'm afraid
    f.stagger = f:CreateBar()
    f.stagger:SetPoint ("TOPRIGHT", f, "TOPRIGHT")
    f.stagger.tex:SetTexture (ICONS.Stagger)
    f.stagger.name = GetSpellInfo (SPELL_IDS['Stagger'])

    function f.stagger:UpdateMinMax ()
        self.maxval = UnitHealthMax ('player')*0.6  -- Honestly, if your stagger is 60% or 80% of your max HP it doesn't matter :P
        self:SetMinMaxValues (0, self.maxval)
    end
    f.stagger:UpdateMinMax ()

    function f.stagger:Update ()
        local val = UnitStagger ('player')
        
        self:SetValue (val)
        self.txt:SetText (ShortNumber(floor(val)))
        
        if val < 0.35*self.maxval then
            self:SetStatusBarColor (0, 0.7, 0)
        elseif val < 0.7*self.maxval then
            self:SetStatusBarColor (1, 1, 0)
        else
            self:SetStatusBarColor (1, 0, 0)
        end        
    end
    
    -- The rest of the bars:    
    f.shuffle       = f:CreateBar (SPELL_IDS['Shuffle'],            'time',     {0.5 , 0.7, 1.0})
    f.elusiveStacks = f:CreateBar (SPELL_IDS['ElusiveBrew_Stacks'], 'stacks',   {1.0 , 0.8, 0.5}, 'Elusive Brew (stacks)')
    f.elusiveBuff   = f:CreateBar (SPELL_IDS['ElusiveBrew_Buff'],   'time',     {1.0 , 0.9, 0.7}, 'Elusive Brew (buff)')
    f.vengeance     = f:CreateBar (SPELL_IDS['Vengeance'],          'value',    {1.0 , 0.0, 0.0})
    f.guard         = f:CreateBar (SPELL_IDS['Guard'],              'value',    {1.0 , 0.8, 0.0})
    f.zensphere     = f:CreateBar (SPELL_IDS['ZenSphere'],          'time',     {0.7 , 0.85,1.0})
    f.dampenHarm    = f:CreateBar (SPELL_IDS['DampenHarm'],         'stacks',   {0.4 , 1.0 ,0.9})
    f.fortifyingBrew= f:CreateBar (SPELL_IDS['FortifyingBrew'],     'time',     {0.85, 0.8 ,0.0})
    
    
    -- Do stuff to all bars
    f.bars = {f.stagger, f.shuffle, f.elusiveStacks, f.elusiveBuff, f.vengeance, f.guard, f.zensphere, f.dampenHarm, f.fortifyingBrew}
    for i=2,#f.bars do
        f.bars[i]:SetPoint ("TOP", f.bars[i-1], "BOTTOM")
    end
    f:SetHeight (BAR_H * #f.bars)
    
    -- Set tooltips and stuff
    f.enabled = {}
    for i=1,#f.bars do
        f.bars[i]:SetTooltipText (f.bars[i].name)
        f.enabled[i] = true
    end
    
    -- General update function
    function f:UpdateMinMax ()
        self.stagger:UpdateMinMax ()
    end
    
    function f:Update ()
        local tblAuras = ScanPlayerAuras()
        for i,v in ipairs(f.bars) do
            v:Update(tblAuras)
        end
    end
    
    -- Make movable
    f:SetMovable (true)
    f:RegisterForDrag ("LeftButton")
    f:SetUserPlaced (true)
    f:SetClampedToScreen (true)
    f:EnableMouse (true)
    for k,v in pairs(f.bars) do
        v:SetScript("OnMouseDown", function(self, button)
            if button=='LeftButton' then
                frmIntoxicated:StartMoving ()
            elseif button=='RightButton' then
                frmIntoxicated:ShowContextMenu ()
            end
        end)
        v:SetScript("OnMouseUp", function(self)
            frmIntoxicated:StopMovingOrSizing ()
        end)
    
    end
    
    f.elapsed = 0
    f:SetScript ("OnUpdate", function (self, elapsed,...)
        -- Hide the stupid default bar!
        MonkStaggerBar:Hide()
    
        self.elapsed = self.elapsed + elapsed
        if self.elapsed > REFRESH_RATE then
            self.elapsed = 0
            self:Update ()
        end
    end)
    
    f:RegisterEvent ('UNIT_AURA')
    f:RegisterEvent ('PLAYER_SPECIALIZATION_CHANGED')
    f:RegisterEvent ('PLAYER_LOGIN')
    f:RegisterEvent ('PLAYER_ENTERING_WORLD')
    f:SetScript ("OnEvent", function (self, event,...)
        if event=='UNIT_AURA' then
            self:UpdateMinMax ()
        elseif event=='PLAYER_SPECIALIZATION_CHANGED' or event=='PLAYER_LOGIN' then
            if GetSpecialization()==1 then
                self:Show()
            else
                self:Hide()
            end
        elseif event=='PLAYER_ENTERING_WORLD' then
            if g_enabledBars then
                self.enabled = g_enabledBars
            else
                g_enabledBars = self.enabled
            end  
            self:UpdateBars()
        end
    end)
    
    -- Context menu
    f.tblMenu = {
        { 
            text = "Options", 
            isTitle = true,
            notCheckable = true,
        },
    }
    for i,bar in ipairs(f.bars) do
        table.insert (f.tblMenu, {
            text = bar.name,
            notCheckable = false,
            arg1 = i,
            func = function (self, arg1) 
                frmIntoxicated.enabled[arg1] = not frmIntoxicated.enabled[arg1]
                frmIntoxicated:UpdateBars()
            end 
        })
    end

    f.frmMenu = CreateFrame("Frame", "frmIntoxicated_ContextMenu", UIParent, "UIDropDownMenuTemplate")
    
    function f:ShowContextMenu ()
        for i=1,#self.bars do
            self.tblMenu[i+1]['checked'] = self.enabled[i]
        end
        
        EasyMenu (self.tblMenu, self.frmMenu, "cursor", 0 , 20, "MENU");
    end
    
    function f:UpdateBars ()
        local shown = {}
        for i=1,#self.bars do
            g_enabledBars[i] = self.enabled[i]
            
            if self.enabled[i] then
                self.bars[i]:Show()
                table.insert (shown, self.bars[i])
            else
                self.bars[i]:Hide()
            end
            self.bars[i]:ClearAllPoints()
        end
        
        if #shown==0 then
            print ('If you really think hiding all bars is a good idea, you must be drunk as a monk!')
            shown[1] = self.bars[1]
            self.bars[1]:Show()
            self.enabled[1] = true
        end
        
        shown[1]:SetPoint ("TOPRIGHT", self, "TOPRIGHT")
        for i=2,#shown do
            shown[i]:SetPoint ("TOPRIGHT", shown[i-1], "BOTTOMRIGHT")
        end
        self:SetHeight (BAR_H * #shown)
    end
end

--[[
code for making a pretty screenshot

INTOX_TEST_STAGGER = 194000
INTOX_TEST_SHUFFLE_EXPIRE = 9.7
INTOX_TEST_ELUSIVE_COUNT = 11
INTOX_TEST_VENGEANCE_VALUE = 86000
INTOX_TEST_VENGEANCE_EXPIRE = 18.2
INTOX_TEST_GUARD_VALUE = 171000
INTOX_TEST_GUARD_EXPIRE = 14.1

]]