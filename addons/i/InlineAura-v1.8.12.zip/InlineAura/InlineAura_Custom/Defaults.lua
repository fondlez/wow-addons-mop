--[[
Custom presets
]]

-- GLOBALS: InlineAura_LoadCustomDefaults
function InlineAura_LoadCustomDefaults()

	-- Customize there

end
