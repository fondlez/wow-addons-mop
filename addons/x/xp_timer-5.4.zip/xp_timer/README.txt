This is a really simple addon that answers the question, how long till I reach the next lvl.
What is does it figures out how much xp you are getting per second and uses this to give you a time to next lvl. It has been accurate for me on both a new  lvl 1 and my lvl 61.

Every time you gain XP it will simply add the amount of time left to the chat window. If the time is increasing it means you are slowing down and should kill faster or move to a new area. 

I use it to figure out how much time I need to log before the weekend so I can join my guild in dungeons.

How to use:
/xpt
/xpt help


I am always looking for suggestions and feature requests so don�t be shy to contact me at addon (at) phansoft.ca
