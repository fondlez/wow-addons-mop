﻿-- Author      : jjacob
-- Create Date : 10/19/2008 5:28:33 PM
-- Updated	   : 07/05/2009 


local xpt = {};
local xpt_global_data_defaults = {};
local xpt_character_data_defaults = {};
local xpt_frame = CreateFrame("Frame");
xpt_frame:RegisterEvent("ADDON_LOADED");
xpt_frame:RegisterEvent("PLAYER_XP_UPDATE");
xpt_frame:RegisterEvent("PLAYER_LOGIN");
xpt_frame:RegisterEvent("PLAYER_MONEY");
xpt_frame:SetScript("OnEvent",
function(self,event,...) 
	if xpt[event] and type(xpt[event]) == "function" then
		return xpt[event](xpt,...)
	end
end)


local xp_util = {}

function xp_util.to_hms(seconds)
  hours = math.floor (seconds / 3600);
  seconds = seconds - (hours * 3600);
  minutes = math.floor (seconds / 60);
  seconds = math.floor (seconds - (minutes * 60));
  return hours,minutes,seconds;
end --to_hms

function xp_util.to_hms_string(seconds)
  return string.format("%d:%.2d:%.2d", xp_util.to_hms(seconds));
end --to_hms_string


function xp_util.to_gsc(copper)
	local positive = 1;
	if copper < 0 then
		positive = -1;
	end
	copper = copper * positive;
	gold = math.floor (copper / 10000);
	copper = copper - (gold * 10000);
	silver = math.floor (copper / 100);
	copper = math.floor (copper - (silver * 100));
	return gold,silver,copper;
end --to_hms

function xp_util.to_gsc_string(copper)
  local ret = string.format("|cffFFD700%dG|r |cffC0C0C0%dS|r |cffB87333%dC|r", xp_util.to_gsc(copper));
  if (copper < 0) then
	ret = "-" .. ret;
  end
  return ret;
end

function xpt:handle_slashes(msg)
  local command, rest = msg:match("^(%S*)%s*(.-)$");
				--DEFAULT_CHAT_FRAME:AddMessage("^"..command.."^");
				--DEFAULT_CHAT_FRAME:AddMessage(rest);
				if command == "" then
					self:default();
				else
					if self[command] and type(self[command]) == "function"  then
						return self[command](self,rest)
					else
					   DEFAULT_CHAT_FRAME:AddMessage("Unknown Command");
					end
				end
end



--local old_xp,start_time,xp_gained,xp_diff

function xpt:ADDON_LOADED(...)
	local addon = ...
	--DEFAULT_CHAT_FRAME:AddMessage("Loading: "..addon,0.18,0.3,0.29);
	if addon == "xp_timer" then
		if type(xpt_global_data) ~= "table" then
			xpt_global_data  = xpt_global_data_defaults;
		end
		if type(xpt_character_data) ~= "table" then
			xpt_character_data  = xpt_character_data_defaults;
		end
		if not SlashCmdList["XPTIMER"] then -- make sure we don't overwrite default if Blizz decides to use same name
				SlashCmdList["XPTIMER"] = function(msg)
				   xpt:handle_slashes(msg);
				end -- end function
				SLASH_XPTIMER1 = "/xpt";
				SLASH_XPTIMER2 = "/xp_timer";
		end -- end if 
		if not SlashCmdList["CASHTIMER"] then -- make sure we don't overwrite default if Blizz decides to use same name
				SlashCmdList["CASHTIMER"] = function(msg)
				   xpt:ct(msg);
				end -- end function
				SLASH_CASHTIMER1 = "/ct";
				SLASH_CASHTIMER2 = "/cash_timer";
		end -- end if 
	end
end



function xpt:PLAYER_LOGIN(...)
	self:cash_timer_setup()
	self:reset();
	DEFAULT_CHAT_FRAME:AddMessage("XP Timer has updated type '/xpt help' for more information");
end

function xpt:PLAYER_XP_UPDATE(...)
	local xp_cur = UnitXP("player");
	local xp_diff_old = self.xp_diff;
	self.xp_diff = xp_cur - self.old_xp;
	if (self.xp_diff < 0) then -- lvled up
		self.xp_diff = xp_diff_old; -- assume that the xp gained was the same as before, this will quickly factor out over time.
	end
	--track total xp gained
	self.xp_gained = self.xp_gained + self.xp_diff;
	-- find amount of time playing
	local time_diff = GetTime() - self.start_time;
	if (time_diff > 0) then -- incase xp is gained instantly upon login devide by zero is not fun
		if (xpt_global_data.show_time_on_xp) then
			local xp_last_checked_time = self.xp_checked_time; -- last time we got XP
			self.xp_checked_time = GetTime();
			local time_since_last_xp = self.xp_checked_time  - xp_last_checked_time;
			local last_estimated_time = self.time_till_next_level - time_since_last_xp; -- estimate minus the time change
			local xp_per_second = self.xp_gained / time_diff;
			self.time_till_next_level = (UnitXPMax("player") - xp_cur) / xp_per_second
			local estimate_inacuracy = last_estimated_time - self.time_till_next_level;
			-- if estimate inacuracy is > 0 then the person is leveling faster than before if it is negative then they are going slower
			--DEFAULT_CHAT_FRAME:AddMessage(string.format("estimate_inacuracy: |cffff0000%s|r %s",xp_util.to_hms_string(estimate_inacuracy),estimate_inacuracy),0.38,0.58,0.92);
			if estimate_inacuracy > 60 then
			-- fast
			DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level down to: |cff00ff00%s|r",xp_util.to_hms_string(self.time_till_next_level)),0.38,0.58,0.92);
--			DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level down to: |cff00ff00%s|r good job you trimmed %s of the estimated time",xp_util.to_hms_string(self.time_till_next_level),xp_util.to_hms_string(estimate_inacuracy)),0.38,0.58,0.92);
			else
				if estimate_inacuracy < -60 then
				DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level increasing: |cffff0000%s|r kill faster or change zones",xp_util.to_hms_string(self.time_till_next_level)),0.38,0.58,0.92);
				else
				DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level: %s",xp_util.to_hms_string(self.time_till_next_level)),0.38,0.58,0.92);
				end
			end
			
			--DEFAULT_CHAT_FRAME:AddMessage(string.format("Last Estimated: |cffff0000%s|r",xp_util.to_hms_string(last_estimated_time)),0.38,0.58,0.92);
			--DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level: |cffff0000%s|r",xp_util.to_hms_string(self.time_till_next_level)),0.38,0.58,0.92);
		end
		self.old_xp = xp_cur;
	end -- time has passed:
end

function xpt:default()
    local time_diff = GetTime() - self.start_time;
	DEFAULT_CHAT_FRAME:AddMessage("Time Logged IN: "..xp_util.to_hms_string(time_diff));
	DEFAULT_CHAT_FRAME:AddMessage("XP Gained total: "..self.xp_gained);
	DEFAULT_CHAT_FRAME:AddMessage("XP Gained: "..self.xp_diff);
	local xp_per_second = self.xp_gained / time_diff;
	DEFAULT_CHAT_FRAME:AddMessage("XP per second: "..xp_per_second);
	local xp_cur = UnitXP("player");
	local kills_to_lvl = math.ceil((UnitXPMax("player") - xp_cur) / self.xp_diff);
	DEFAULT_CHAT_FRAME:AddMessage("Kills to next level: "..kills_to_lvl);
	DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level: |cffff0000%s|r",xp_util.to_hms_string((UnitXPMax("player") - xp_cur) / xp_per_second)));
end


function xpt:hour()
    local time_diff = GetTime() - self.start_time;
	--DEFAULT_CHAT_FRAME:AddMessage("Time Logged IN: "..xp_util.to_hms_string(time_diff));
	--DEFAULT_CHAT_FRAME:AddMessage("XP Gained total: "..self.xp_gained);
	--DEFAULT_CHAT_FRAME:AddMessage("XP Gained: "..self.xp_diff);
	if time_diff >= (3600) then
		local xp_per_hour = (self.xp_gained / time_diff) * 3600;
		DEFAULT_CHAT_FRAME:AddMessage("XP per hour: "..xp_per_hour);
	else
		DEFAULT_CHAT_FRAME:AddMessage("You have not been logged in without a reset for an hour");
		DEFAULT_CHAT_FRAME:AddMessage("Time Logged IN: "..xp_util.to_hms_string(time_diff));
	end
	--local xp_cur = UnitXP("player");
	--local kills_to_lvl = math.ceil((UnitXPMax("player") - xp_cur) / self.xp_diff);
	--DEFAULT_CHAT_FRAME:AddMessage("Kills to next level: "..kills_to_lvl);
	--DEFAULT_CHAT_FRAME:AddMessage(string.format("Time to next level: |cffff0000%s|r",xp_util.to_hms_string((UnitXPMax("player") - xp_cur) / xp_per_second)));

end

function xpt:PLAYER_MONEY(...)
		
	    local current_time = math.floor(GetTime());
		--DEFAULT_CHAT_FRAME:AddMessage("You where paid at "..xp_util.to_hms_string(current_time));
		local cash_time_diff = current_time - self.cash_time_last_paid ;
		self.cash_time_last_paid = current_time;
		xpt_character_data.cash_running_time = xpt_character_data.cash_running_time + cash_time_diff;
		--DEFAULT_CHAT_FRAME:AddMessage("You where last paid "..xp_util.to_hms_string(cash_time_diff).." ago.");
		local current_cash = GetMoney(); 
		local cash_diff = current_cash - self.cash_last_known ;
		self.cash_last_known = current_cash;
		if xpt_global_data["show_cash_on_earn"] then
			if ( cash_diff > 0) then
				DEFAULT_CHAT_FRAME:AddMessage("You just made "..xp_util.to_gsc_string(cash_diff));
			else
				DEFAULT_CHAT_FRAME:AddMessage("You just lost "..xp_util.to_gsc_string(cash_diff));			
			end
		end
		--DEFAULT_CHAT_FRAME:AddMessage("You have "..xp_util.to_gsc_string(GetMoney()));
		if (xpt_character_data.cash_values_array[xpt_character_data.cash_running_time] == nil) then
			xpt_character_data.cash_values_array[xpt_character_data.cash_running_time] = cash_diff
		else
			xpt_character_data.cash_values_array[xpt_character_data.cash_running_time] = xpt_character_data.cash_values_array[xpt_character_data.cash_running_time]+ cash_diff;
		end
		--DEFAULT_CHAT_FRAME:AddMessage("You recieved "..xp_util.to_gsc_string(xpt_character_data.cash_values_array[xpt_character_data.cash_running_time]).."this second.");
end


function xpt:ct(...)
	local timespan = ...;
	local include_timespan  = false;
	if tonumber(timespan) ~= nil then
		include_timespan = true;
		timespan = tonumber(timespan) * 60;
	end
	if (timespan == "off") then
		xpt_global_data.show_cash_on_earn = false;
		DEFAULT_CHAT_FRAME:AddMessage("Cash display |cffff0000disabled|r");
	end
	if (timespan == "on") then
		xpt_global_data.show_cash_on_earn = true;
		DEFAULT_CHAT_FRAME:AddMessage("Cash display |cff00ff00enabled|r");
	end
	local current_time = math.floor(GetTime());
	local cash_time_diff = current_time - self.cash_time_last_paid ;
	self.cash_time_last_paid = current_time;
	xpt_character_data.cash_running_time = xpt_character_data.cash_running_time + cash_time_diff;
	local cash_in_last_minute = 0;
	local cash_in_last_hour = 0;
	local cash_in_last_day = 0;
	local cash_in_timespan = 0;
	for cash_time,cash_made in pairs(xpt_character_data.cash_values_array) do
	--DEFAULT_CHAT_FRAME:AddMessage("calculating: "..to_gsc_string(cash_made).." at "..to_hms_string(cash_time));
	 local timeOffset = xpt_character_data.cash_running_time - cash_time
	 if (timeOffset < 300)then
		cash_in_last_minute = cash_in_last_minute + cash_made;
	 end
	 if (timeOffset < 3600) then 
		cash_in_last_hour = cash_in_last_hour + cash_made;		
	 end
	 if (timeOffset < 86400) then
		cash_in_last_day = cash_in_last_day + cash_made;
	 end
	 if (include_timespan and timeOffset <= timespan) then
		cash_in_timespan = cash_in_timespan + cash_made
	 end
	 --memory cleanup
	 if (timeOffset > 86400) then
		table.remove(xpt_character_data.cash_values_array,cash_time);
		--DEFAULT_CHAT_FRAME:AddMessage("cleaned time: "..cash_time,1.0,0.0,0.0);
	 end
	 --done memory cleanup
	end
	--DEFAULT_CHAT_FRAME:AddMessage("Running time: "..xp_util.to_hms_string(xpt_character_data.cash_running_time));
	DEFAULT_CHAT_FRAME:AddMessage("Cash in last 5 minutes: "..xp_util.to_gsc_string(cash_in_last_minute));
	DEFAULT_CHAT_FRAME:AddMessage("Cash in last hour: "..xp_util.to_gsc_string(cash_in_last_hour));
	DEFAULT_CHAT_FRAME:AddMessage("Cash in last day: "..xp_util.to_gsc_string(cash_in_last_day));
	if (include_timespan) then
		DEFAULT_CHAT_FRAME:AddMessage(string.format("Cash in last |cff00ff00%d|r minutes: %s ",timespan/60,xp_util.to_gsc_string(cash_in_timespan)));
	end
end
function xpt:cash(...)
	xpt:ct(...)
end

function xpt:optimize()
	
	for cash_time,cash_made in pairs(cash_values_array) do
		local timeOffset = xpt_character_data.cash_running_time - cash_time
		if (timeOffset > 86400) then
			table.remove(cash_values_array,cash_time);
		end
	end
end

function xpt:reset()
	DEFAULT_CHAT_FRAME:AddMessage("XP Timer reset");
	self.old_xp = UnitXP("player");
	self.start_time = GetTime(); 
	self.xp_checked_time = self.start_time;
	self.time_till_next_level = 86400;
	self.xp_gained = 1;
	self.xp_diff = 1;
    if (self.how_time_on_xp == nil) then
        xpt_global_data.show_time_on_xp = true;
    end
end

function xpt:help(msg)
	DEFAULT_CHAT_FRAME:AddMessage("XP Timer Usage:");
	DEFAULT_CHAT_FRAME:AddMessage("/xpt help -- this help");
	DEFAULT_CHAT_FRAME:AddMessage("/xpt -- Get information about the XP you have gained sinse");
	DEFAULT_CHAT_FRAME:AddMessage("/xpt reset -- reset your xp timer. great for you leave town or start a dungeon");
	DEFAULT_CHAT_FRAME:AddMessage("/xpt hour -- xp gained average per hour if logged in for more than an hour");
	DEFAULT_CHAT_FRAME:AddMessage("/xpt cash OR /ct -- show how much gold you have gained in the past 24 hours");
	DEFAULT_CHAT_FRAME:AddMessage("/xpt off OR /xpt on -- disbale or enable the status message on new xp");
	DEFAULT_CHAT_FRAME:AddMessage("/ct time -- How much gold in the last 'time' minutes. Max 24 hours");
	DEFAULT_CHAT_FRAME:AddMessage("/ct on OR /ct off -- turn on (off by default) reports on gold earned to blizzard style");
	
	
	
end

function xpt:cash_timer_setup()
	DEFAULT_CHAT_FRAME:AddMessage("Cash Timer setup");
	if (xpt_character_data.cash_values_array == nil) then
		xpt_character_data.cash_values_array  = {}; -- first run on install
	end
	if (xpt_character_data.cash_running_time == nil) then
		xpt_character_data.cash_running_time = 0; -- first run on install
	end
	if (xpt_global_data.show_cash_on_earn == nill) then
		xpt_global_data.show_cash_on_earn = false;
	end
	
	self.cash_last_known = GetMoney();
	self.cash_time_last_paid = math.floor(GetTime());
end

function xpt:off()
    xpt_global_data.show_time_on_xp = false;
    self:status();
end


function xpt:on()
    xpt_global_data.show_time_on_xp =  true;
    self:status();
end

function xpt:status()
    if xpt_global_data.show_time_on_xp then
		DEFAULT_CHAT_FRAME:AddMessage("Time updates |cff00ff00will be|r shown every time you gain XP");
	else
		DEFAULT_CHAT_FRAME:AddMessage("Time updates will |cffff0000not|r show every time you gain XP");
	end
	
	if xpt_global_data.show_cash_on_earn then
		DEFAULT_CHAT_FRAME:AddMessage("Cash updates |cff00ff00will be|r shown every time you gain gold");
	else
		DEFAULT_CHAT_FRAME:AddMessage("Cash updates will |cffff0000not|r show every time you gain gold");
	end
end


