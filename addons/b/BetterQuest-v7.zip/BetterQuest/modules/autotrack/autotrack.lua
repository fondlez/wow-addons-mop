local quixote = LibStub("LibQuixote-2.0")
local core = LibStub("AceAddon-3.0"):GetAddon("BetterQuest")
local module = core:NewModule("AutoTrack", "AceEvent-3.0")
module.events = LibStub("CallbackHandler-1.0"):New(module)

local Debug = core.Debug
local GetCoord, GetXY

local db
function module:OnModuleInitialize()
	self.db = core.db:RegisterNamespace("AutoTrack", {
		profile = {
			poi = 15,
			gained = false,
			progress = true,
			removeCompleted = false,
			enabled = true,
		},
		char = {
			autotracked = {},
		}
	})
	db = self.db
	self.menu = {
		poi = {name = "POI", type = "range", desc = "Track quests when you're within X% of the zone of their Point of Interest", min = 0, max = 100, step = 1},
		progress = {name = "Progress", type = "toggle", desc = "Track quests when you make progress on them",},
		gained = {name = "Gained", type = "toggle", desc = "Track quests when you pick them up",},
		removeCompleted = {name = "Remove completed", type = "toggle", desc = "Stop tracking quests when you complete them",},
	}
end

function module:Watch(uid, auto)
	if db.profile.removeCompleted and select(7, quixote:GetQuestByUid(uid)) then
		return
	end
	db.char.autotracked[uid] = auto or nil
	quixote:AddQuestWatchByUid(uid)
end

function module:Unwatch(uid)
	db.char.autotracked[uid] = nil
	quixote:RemoveQuestWatchByUid(uid)
end

function module:OnModuleEnable()
	self:RegisterEvent("MINIMAP_ZONE_CHANGED", "OnZoneChange")
	self:RegisterEvent("ZONE_CHANGED", "OnZoneChange")
	self:RegisterEvent("ZONE_CHANGED_INDOORS", "OnZoneChange")
	self:RegisterEvent("ZONE_CHANGED_NEW_AREA", "OnZoneChange")
	self:RegisterEvent("QUEST_POI_UPDATE", "UpdatePOIs")
	self:RegisterEvent("QUEST_LOG_UPDATE", "UpdatePOIs")
	quixote.RegisterCallback(self, "Objective_Update")
	quixote.RegisterCallback(self, "Quest_Gained")
	quixote.RegisterCallback(self, "Quest_Complete")
	quixote.RegisterCallback(self, "Quest_Lost")
	quixote.RegisterCallback(self, "Update")
end

function module:OnZoneChange()
	if not db.profile.enabled then return end
	if UnitIsDead("player") then return end

	self:UpdatePOIs()
	self:CheckPOIs()
end
module.OnSettingsUpdate = module.OnZoneChange

function module:Update()
	self:OnZoneChange()
	quixote.UnregisterCallback(self, "Update")
	quixote.RegisterCallback(self, "Update", "UpdatePOIs")
end

function module:Objective_Update(event, title, uid)
	if AUTO_QUEST_WATCH=="0" and db.profile.progress then
		self:Watch(uid, false)
	end
end

function module:Quest_Gained(event, title, uid, objectives, zone)
	if db.profile.gained then
		self:Watch(uid, false)
	end
end

function module:Quest_Complete(event, title, uid)
	if db.profile.removeCompleted then
		self:Unwatch(uid)
	end
end

function module:Quest_Lost(event, title, uid)
	db.char.autotracked[uid] = nil
end

local pois = {}

do
	local poiupdate = CreateFrame("Frame")
	local time_since = 0
	poiupdate:SetScript("OnUpdate", function(this, t)
		time_since = time_since + t
		if time_since > 2 then
			time_since = 0
			module:CheckPOIs()
		end
	end)
end

function module:CheckPOIs()
	if not db.profile.enabled then return end
	local x, y = GetPlayerMapPosition('player')
	if x <= 0 or y <= 0 then
		return
	end
	local distance_threshold = (db.profile.poi / 100) ^ 2
	for uid, coord in pairs(pois) do
		-- Debug("POI", uid, coord)
		if db.char.autotracked[uid] or not core.db.char.tracked[uid] then
			local px, py = GetXY(coord)
			local distance = (x-px)^2 + (y-py)^2
			if distance <= distance_threshold then
				if not core.db.char.tracked[uid] then
					Debug(" watching")
					self:Watch(uid, true)
				end
			elseif core.db.char.tracked[uid] then
				-- this was autotracked, and is no longer close enough to remain so
				Debug(" unwatching")
				self:Unwatch(uid)
			end
		end
	end
end

function module:UpdatePOIs()
	if not db.profile.enabled then return end
	local x, y = GetPlayerMapPosition('player')
	if (x or 0) <= 0 or (y or 0) <= 0 then
		-- Means that this was probably a change triggered by the world map being
		-- opened and browsed around. Since this is the case, we won't update any POIs for now.
		return
	end
	wipe(pois)
	-- Interestingly, even if this isn't called, *some* POIs will show up. Not sure why.
	QuestPOIUpdateIcons()
	local numEntries = QuestMapUpdateAllQuests()
	for i=1, numEntries do
		local questId, questLogIndex = QuestPOIGetQuestIDByVisibleIndex(i)
		local _, posX, posY, objective = QuestPOIGetIconInfo(questId)
		if posX and posY then
			pois[questId] = GetCoord(posX, posY)
		end
	end
end

--- location utility functions

local floor = math.floor
function GetCoord(x, y)
	return floor(x * 10000 + 0.5) * 10000 + floor(y * 10000 + 0.5)
end

function GetXY(coord)
	return floor(coord / 10000) / 10000, (coord % 10000) / 10000
end

