local L = LibStub("AceLocale-3.0"):NewLocale("BloodShieldTracker", "frFR", false)

if not L then return end


