local L = BigWigs:NewBossLocale("Wise Mari", "itIT")
if not L then return end
if L then
	L.engage_say = "Chi osa disturbare queste acque? Affogherete!."
end

