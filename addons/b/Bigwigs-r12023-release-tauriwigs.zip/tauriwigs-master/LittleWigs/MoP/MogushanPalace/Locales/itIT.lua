local L = BigWigs:NewBossLocale("Trial of the King", "itIT")
if not L then return end
if L then
	L.win_emote = "tesoro"
end

local L = BigWigs:NewBossLocale("Gekkan", "itIT")
if not L then return end
if L then
	L.engage_yell = "Addossso!"
end

local L = BigWigs:NewBossLocale("Xin the Weaponmaster", "itIT")
if not L then return end
if L then
	L.engage_yell = "Non è la prima volta che mi sfidano, e non sarà certo neanche l'ultima."
end