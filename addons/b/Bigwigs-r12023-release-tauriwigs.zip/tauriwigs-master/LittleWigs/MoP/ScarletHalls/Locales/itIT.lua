local L = BigWigs:NewBossLocale("Houndmaster Braun", "itIT")
if not L then return end
if L then
	L.engage_say = "Hmm, avete fiutato qualcosa?"
end

local L = BigWigs:NewBossLocale("Armsmaster Harlan", "itIT")
if not L then return end
if L then
	L.engage_yell = "Ah-hah! Un'altra occasione per provare la mia forza."
end

local L = BigWigs:NewBossLocale("Flameweaver Koegler", "itIT")
if not L then return end
if L then
	L.engage_yell = "Tutto deve bruciare!"
end