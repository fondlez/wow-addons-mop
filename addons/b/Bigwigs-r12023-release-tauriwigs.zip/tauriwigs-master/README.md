# TauriWigs
BigWigs with timers and mechanics adjusted to [Tauri](https://tauriwow.com/)



### Status
T16 is largely WiP, T15 was already properly adjusted by Lexi 
