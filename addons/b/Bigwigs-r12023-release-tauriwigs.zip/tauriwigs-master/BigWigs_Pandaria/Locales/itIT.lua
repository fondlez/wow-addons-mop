local L = BigWigs:NewBossLocale("Nalak", "itIT")
if L then
	L.engage_yell = "Sentite il vento gelido soffiare? La tempesta sta arrivando..."

	L.ability = "Prossima Abilità"
	L.ability_desc = "Timer di Recupero per la prossima abilità."
end

L = BigWigs:NewBossLocale("Salyis's Warband", "itIT")
if L then
	L.engage_yell = "Portatemi i loro cadaveri!"
end

L = BigWigs:NewBossLocale("Ordos", "itIT")
if L then
	L.engage_yell = "Prenderete il mio posto nel braciere eterno."

	L.burning_soul_bar = "Esplosioni"
	--L.burning_soul_self_bar = "You explode!"
end

