local L = BigWigs:NewBossLocale("Nalak", "ptBR")
if L then
	--L.engage_yell = "Can you feel a chill wind blow? The storm is coming..."

	--L.ability = "Next ability"
	--L.ability_desc = "Cooldown timer for the next ability."
end

L = BigWigs:NewBossLocale("Salyis's Warband", "ptBR")
if L then
	--L.engage_yell = "Bring me their corpses!"
end

L = BigWigs:NewBossLocale("Ordos", "ptBR")
if L then
	--L.engage_yell = "You will take my place on the eternal brazier."

	--L.burning_soul_bar = "Explosions"
	--L.burning_soul_self_bar = "You explode!"
end

