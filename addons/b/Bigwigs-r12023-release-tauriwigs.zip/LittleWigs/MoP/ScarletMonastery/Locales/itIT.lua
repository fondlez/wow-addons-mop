local L = BigWigs:NewBossLocale("Thalnos the Soulrender", "itIT")
if not L then return end
if L then
	L.engage_yell = "La mia eterna agonia sarà anche la vostra!"
end

local L = BigWigs:NewBossLocale("Brother Korloff", "itIT")
if not L then return end
if L then
	L.engage_yell = "Vi spezzo in due."
end

local L = BigWigs:NewBossLocale("High Inquisitor Whitemane", "itIT")
if not L then return end
if L then
	L.engage_yell = "La mia leggenda comincia ORA!"
end