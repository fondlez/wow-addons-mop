--------------------------------------------------------------------------------
-- Module Declaration
--

local mod, CL = BigWigs:NewBoss("Armsmaster Harlan", 871, 654)
if not mod then return end
mod:RegisterEnableMob(58632)

local helpCount = 1

--------------------------------------------------------------------------------
-- Localization
--

local L = mod:NewLocale("enUS", true)
if L then
	L.engage_yell = "Ah-hah! Another chance to test my might."

	L.cleave = EJ_GetSectionInfo(5377) .. " (".. mod:SpellName(15284) ..")" -- 15284 = "Cleave"
	L.cleave_desc = select(2, EJ_GetSectionInfo(5377))
	L.cleave_icon = 111217

	L.blades, L.blades_desc = EJ_GetSectionInfo(5376)
	L.blades_icon = 111216

	L.help, L.help_desc = EJ_GetSectionInfo(5378)
	L.help_icon = 6673
end
L = mod:GetLocale()

--------------------------------------------------------------------------------
-- Initialization
--

function mod:GetOptions()
	return {"cleave", {"blades", "FLASH"}, "help", "bosskill"}
end

function mod:OnBossEnable()
	self:Log("SPELL_CAST_SUCCESS", "Cleave", 111217)
	self:Log("SPELL_CAST_START", "BladesCastStart", 111216)
	self:Log("SPELL_AURA_APPLIED", "BladesChannel", 111216)
	self:Log("SPELL_AURA_REMOVED", "BladesEnd", 111216)

	self:RegisterEvent("INSTANCE_ENCOUNTER_ENGAGE_UNIT", "CheckBossStatus")

	--|TInterface\\Icons\\ability_warrior_battleshout.blp:20|tArmsmaster Harlan calls on two of his allies to join the fight!
	self:Emote("Adds", "ability_warrior_battleshout")

	self:Death("Win", 58632)
end

function mod:OnEngage()
	self:Bar("blades", 41, L["blades"], 111216)
	self:Bar("cleave", 7.1, 845) -- Cleave
	self:Bar("help", 20, L["help"], 6673)
	helpCount = 1
end

--------------------------------------------------------------------------------
-- Event Handlers
--

function mod:Cleave(args)
	self:Message("cleave", "Attention", nil, 845)
	self:Bar("cleave", 7.1, 845) -- 7.2 - 7.3
end

function mod:BladesCastStart(args)
	self:Message("blades", "Urgent", "Alert", CL["casting"]:format(args.spellName), args.spellId)
	self:Bar("blades", 6, CL["cast"]:format(args.spellName), args.spellId)
	self:Flash("blades")
	self:StopBar(845)
end

function mod:BladesChannel(args)
	self:Message("blades", "Urgent", nil, CL["duration"]:format(args.spellName, "22"), args.spellId)
	self:Bar("blades", 22, args.spellId)
end

function mod:BladesEnd(args)
	self:Message("blades", "Attention", nil, CL["over"]:format(args.spellName), args.spellId)
	self:Bar("blades", 33, args.spellId)
end

do
	local timers = {30, 25, 22, 20, 18, 16, 14}
	function mod:Adds()
		self:Message("help", "Urgent", "Info", L["help"], 6673)
		self:Bar("help", timers[helpCount] or 13, L["help"], 6673)
		helpCount = helpCount + 1
	end
end