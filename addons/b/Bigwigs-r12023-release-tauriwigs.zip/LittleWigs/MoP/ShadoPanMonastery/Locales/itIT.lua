local L = BigWigs:NewBossLocale("Gu Cloudstrike", "itIT")
if not L then return end
if L then
	L.engage_say = "Lasciate che vi mostri il mio potere."
end

local L = BigWigs:NewBossLocale("Master Snowdrift", "itIT")
if not L then return end
if L then
	L.engage_yell = "Fate del vostro meglio. Perché io lo farò."
	
	L.phase3_yell = "ero un cucciolo"
end

local L = BigWigs:NewBossLocale("Sha of Violence", "itIT")
if not L then return end
if L then
	L.engage_yell = "Non verrò rinchiuso di nuovo. Questi Shandaren non mi possono fermare. E neanche voi!"
end

local L = BigWigs:NewBossLocale("Taran Zhu", "itIT")
if not L then return end
if L then
	L.engage_yell = "L'odio consumerà e conquisterà tutto!"
end