local L = BigWigs:NewBossLocale("Jin'rokh the Breaker", "ptBR")
if not L then return end
if L then

end

L = BigWigs:NewBossLocale("Horridon", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Council of Elders", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Tortos", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Megaera", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Ji-Kun", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Durumu the Forgotten", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Primordius", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Dark Animus", "ptBR")
if L then

end
L = BigWigs:NewBossLocale("Iron Qon", "ptBR")
if L then

end
L = BigWigs:NewBossLocale("Twin Consorts", "ptBR")
if L then

end
L = BigWigs:NewBossLocale("Lei Shen", "ptBR")
if L then

end
L = BigWigs:NewBossLocale("Ra-den", "ptBR")
if L then

end

L = BigWigs:NewBossLocale("Throne of Thunder Trash", "ptBR")
if L then

end

