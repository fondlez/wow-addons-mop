
if GetLocale() ~= "ruRU" then return end
local _, tbl = ...
local L = tbl.L


