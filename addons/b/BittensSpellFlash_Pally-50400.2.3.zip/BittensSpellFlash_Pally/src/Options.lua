local c = BittensGlobalTables.GetTable("BittensSpellFlashLibrary")

c.AddRotationSwitches()
c.AddSoloSwitch()
c.RegisterAddon()
