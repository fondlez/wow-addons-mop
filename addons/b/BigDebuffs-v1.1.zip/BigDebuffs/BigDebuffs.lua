
-- BigDebuffs by Jordon

LoadAddOn("Blizzard_CompactRaidFrames")

-- Debuffs to make bigger, higher numbers take precedence regardless of duration
local DispelList = {
	["Cyclone"] = 99,
	["Deep Freeze"] = 5,
	["Scatter Shot"] = 3,
	["Intimidating Shout"] = 3,
	["Hex"] = 3,
	["Psychic Scream"] = 3,
	["Polymorph"] = 3,
	["Freezing Trap"] = 3,
	["Hammer of Justice"] = 3,
	["Silence"] = 3,
	["Strangulate"] = 3,
	["Spell Lock"] = 3,
	["Mortal Coil"] = 3,
	["Psychic Horror"] = 3,
	["Dominate Mind"] = 3,
	["Fear"] = 3,
	["Howl of Terror"] = 3,
	["Mesmerize"] = 3,
	["Psychic Terror"] = 3,
	["Ring of Frost"] = 3,
	["Static Charge"] = 3,
	["Fist of Justice"] = 3,
	["Shadowfury"] = 3,
	["Hibernate"] = 3,
	["Turn Evil"] = 3,
	["Lullaby"] = 3,
	["Blinding Light"] = 3,
	["Blinding Shot"] = 3,
	["Scare Beast"] = 3,
	["Blood Horror"] = 3,
	["Sap"] = 3,
	["Frostjaw"] = 3,
	["Kidney Shot"] = 3,
	["Garrote - Silence"] = 3,
	["Wyvern Sting"] = 3,
	["Silenced - Improved Counterspell"] = 3,
	["Asphyxiate"] = 3,
	["Shockwave"] = 3,
	["Gouge"] = 3,
	["Blind"] = 3,
	["Cheap Shot"] = 3,
	["Leg Sweep"] = 3,
	["Repentance"] = 3,
	["Paralysis"] = 3,
	["Scare Beast"] = 3,
	["Shackle Undead"] = 3,
	["Dragon's Breath"] = 3,
	["Sin and Punishment"] = 3,
	["Charge Stun"] = 3,
	["Pounce"] = 3,
	["Soul Reaper"] = 2,
	["Mind Flay (Insanity)"] = 2,
	["Solar Beam"] = 1,
	["Devouring Plague"] = 1,
	["Smoke Bomb"] = 1,
}

local Blizzard = { CompactUnitFrame_UtilIsPriorityDebuff = CompactUnitFrame_UtilIsPriorityDebuff }

-- Make sure we see these debuffs, but don't make them bigger
local PriorityDebuffs = {
	"Unstable Affliction",
	"Vampiric Touch",
	"Faerie Fire",
}

-- Show these when a big debuff is displayed
local AdditionalDebuffs = {
	"Smoke Bomb",
	"Unstable Affliction",
	"Vampiric Touch",
}

CompactUnitFrame_UtilIsPriorityDebuff = function(unit, index, filter)
	local name = UnitDebuff(unit, index)

	for i=1, #PriorityDebuffs do
		if name == PriorityDebuffs[i] then
			return true
		end
	end

	return Blizzard.CompactUnitFrame_UtilIsPriorityDebuff(unit, index, filter)
end


hooksecurefunc("CompactUnitFrame_UpdateDebuffs", function(frame)
	if not UnitIsPlayer(frame.displayedUnit) then
		return
	end	

	local offset, duration, priority, debuff = 1, 0, 0
	for i=1,40 do
		local p = DispelList[UnitDebuff(frame.displayedUnit, i)]
		if frame.debuffFrames and p and p >= priority then
			local now, time = GetTime(), select(7, UnitDebuff(frame.displayedUnit, i))
			if time - now > duration then
				duration = time - now
				debuff = i
				priority = p
			end
		end
	end

	if debuff then

		for i = 1, #AdditionalDebuffs do
			if UnitDebuff(frame.displayedUnit, AdditionalDebuffs[i]) then
				for j = 1, 40 do
					if UnitDebuff(frame.displayedUnit, j) == AdditionalDebuffs[i] then
						local size = frame.debuffFrames[offset].baseSize * 2
						CompactUnitFrame_UtilSetDebuff(frame.debuffFrames[offset], frame.displayedUnit, j, nil, false, false)
						frame.debuffFrames[offset]:ClearAllPoints();
						frame.debuffFrames[offset]:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1)
						frame.debuffFrames[offset]:SetSize(size, size)

						offset = 2
						break
					end
				end
				break
			end
		end

		local size = frame.debuffFrames[offset].baseSize * 2
		CompactUnitFrame_UtilSetDebuff(frame.debuffFrames[offset], frame.displayedUnit, debuff, nil, false, false)
		frame.debuffFrames[offset]:ClearAllPoints();
		frame.debuffFrames[offset]:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1)
		frame.debuffFrames[offset]:SetSize(size, size)
	end

	if debuff then
		for i=offset+1, frame.maxDebuffs do
			local debuffFrame = frame.debuffFrames[i];
			debuffFrame:Hide();
		end
	end

end)
