local addonName, a = ...
local c = BittensGlobalTables.GetTable("BittensSpellFlashLibrary")

a.AddonName = addonName
c.Init(a)

a.SpellIDs = {
	["Blackout Kick"] = 100784,
	["Breath of Fire"] = 115181,
	["Brewmaster Training"] = 117967,
	["Chi Brew"] = 115399,
	["Chi Burst"] = 123986,
	["Chi Sphere"] = 121283,
	["Chi Torpedo"] = 115008,
	["Chi Wave"] = 115098,
	["Combo Breaker: Blackout Kick"] = 116768,
	["Combo Breaker: Tiger Palm"] = 118864,
	["Crackling Jade Lightning"] = 117952,
	["Dampen Harm"] = 122278,
	["Death Note"] = 121125,
	["Diffuse Magic"] = 122783,
	["Dizzying Haze"] = 123727,
	["Elusive Brew Stacker"] = 128939,
	["Elusive Brew"] = 115308,
	["Energizing Brew"] = 115288,
	["Enveloping Mist"] = 124682,
	["Expel Harm"] = 115072,
	["Fists of Fury"] = 113656,
	["Flying Serpent Kick 1"] = 101545,
	["Flying Serpent Kick 2"] = 115057,
	["Fortifying Brew"] = 115203,
	["Guard"] = 115295,
	["Healing Elixirs"] = 122280,
	["Heavy Stagger"] = 124273,
	["Invoke Xuen, the White Tiger"] = 123904,
	["Jab"] = 100780,
	["Keg Smash"] = 121253,
	["Legacy of the Emperor"] = 115921,
	["Legacy of the White Tiger"] = 116781,
	["Light Stagger"] = 124275,
	["Mana Tea"] = 123761,
	["Moderate Stagger"] = 124274,
	["Momentum"] = 119085,
	["Muscle Memory"] = 139598,
	["Power Guard"] = 118636,
	["Power Strikes"] = 129914,
	["Provoke"] = 115546,
	["Purifying Brew"] = 119582,
	["Renewing Mist"] = 115151,
	["Rising Sun Kick"] = 107428,
	["Roll"] = 109132,
	["Rushing Jade Wind"] = 116847,
	["Serpent's Zeal"] = 127722,
	["Shuffle"] = 115307,
	["Soothing Mist"] = 115175,
	["Spear Hand Strike"] = 116705,
	["Spinning Crane Kick"] = 101546,
	["Stance of the Fierce Tiger"] = 103985,
	["Stance of the Sturdy Ox"] = 115069,
	["Stance of the Wise Serpent"] = 115070,
	["Storm, Earth, and Fire"] = 137639,
	["Summon Black Ox Statue"] = 115315,
	["Summon Jade Serpent Statue"] = 115313,
	["Surging Mist"] = 116694,
	["Tiger Palm"] = 100787,
	["Tiger Power"] = 125359,
	["Tigereye Brew Stacker"] = 125195,
	["Tigereye Brew"] = 116740,
	["Touch of Death"] = 115080,
	["Uplift"] = 116670,
	["Vital Mists"] = 118674,
	["Zen Sphere"] = 124081,
	
	-- Items
	["Purifier"] = 138237,
	["Staggering"] = 138233,
}

a.TalentIDs = {
	["Momentum"] = 119085,
	["Power Strikes"] = 121817,
	["Healing Elixirs"] = 122280,
}

a.GlyphIDs = {
	["Uplift"] = 125669,
	["Fortifying Brew"] = 124997,
	["Mana Tea"] = 123763,
}

a.EquipmentSets = {
--	BMT15 = {
--	    HeadSlot = { 95907, 95277, 96651 },
--	    ShoulderSlot = { 95909, 95279, 96653 },
--	    ChestSlot = { 95905, 95275, 96649 },
--	    HandsSlot = { 95906, 95276, 96650 },
--	    LegsSlot = { 95908, 95278, 96652 },
--	},
	WWT15 = {
	    HeadSlot = { 95897, 95267, 96641 },
	    ShoulderSlot = { 95899, 95269, 96643 },
	    ChestSlot = { 95895, 95265, 96639 },
	    HandsSlot = { 95896, 95266, 96640 },
	    LegsSlot = { 95898, 95268, 96642 },
	},
	BrewmasterT16 = {
	    HeadSlot = { 99142, 99065, 99607, 99384 },
	    ShoulderSlot = { 99144, 99051, 99565, 99386 },
	    ChestSlot = { 99140, 99063, 99643, 99382 },
	    HandsSlot = { 99141, 99064, 99644, 99383 },
	    LegsSlot = { 99143, 99050, 99606, 99385 },
	},
}
