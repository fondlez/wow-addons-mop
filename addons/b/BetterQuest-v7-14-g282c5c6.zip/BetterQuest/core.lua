
local quixote = LibStub("LibQuixote-2.0")
local LSM3 = LibStub("LibSharedMedia-3.0")

local addon = LibStub("AceAddon-3.0"):NewAddon("BetterQuest", "AceConsole-3.0", "AceHook-3.0", "AceEvent-3.0")
local debugf = tekDebug and tekDebug:GetFrame("BetterQuest")
local function Debug(...) if debugf then debugf:AddMessage(string.join(", ", tostringall(...))) end end
addon.Debug = Debug

function addon:OnInitialize()
	local colors = {
		notstarted = {1,0,0,1},
		underway = {1,1,0,1},
		done = {0,1,0,1},
		title = {1,1,1,1},
		turnin = {0,0.5,1,1}
	}
	for k,v in pairs(QuestDifficultyColors) do
		colors[k] = {v.r,v.g,v.b,v.a}
	end
	-- (Gets us: trivial, standard, difficult, verydifficult, impossible, header.)

	self.db = LibStub("AceDB-3.0"):New("BetterQuestDB", {
		profile = {
			trackerNames = {
				full = true,
				tracked = true,
			},
			trackers = {
				['**'] = {
					frame = {
						position = {point="CENTER", x=0, y=0},
						lock = false,
						scale = 1,
						strata = "MEDIUM",
						fade = 1,
						opacity = 1,
						width = 250,
						border = {0.9, 0.82, 0, 1},
						background = {0, 0, 0, 1},
						min_height = 20,
						grow_up = false,
					},
					filters = {
						['*'] = -1,
						tag = {ANY = true},
						--zone = {ANY = true},
						--All 'bool' filters check for 1/0/-1
						--current_zone = bool
						--zone = string
						--tag = string
						--daily = bool
						--tracked = bool
						--complete = bool
					},
					header = {
						name = true,
						counts = true,
					},
					headers = true,
					colorTitles = true,
					colorObjectives = true,
					colorPartyObjectives = true,
					wrapTitles = false,
					wrapObjectives = false,
					levels = true,
					groupBy = 'zone',
					hideCompletedObjectives = false,
					descIfNoObjective = true,
					partyCount = true,
					partyObjectives = true,
					font = "Arial Narrow",
					font_size = select(2, GameFontNormal:GetFont()),
					hideWhenEmpty = true,
					items = false,
					achievements = false,
					scenarios = false,
				},
				full = {
					enabled = true,
					collapsed = true,
					frame = {
						scale = 0.8,
					},
				},
				tracked = {
					enabled = true,
					frame = {
						position = {
							point = "TOPLEFT",
							relpoint = "BOTTOMLEFT",
							x = 700,
							y = 550,
						},
						border = {0.9, 0.82, 0, 0},
						background = {0, 0, 0, 0},
						lock = true,
					},
					filters = {tracked = 1,},
					header = {name = false, counts = false},
					headers = false,
					groupby = 'level',
					items = true,
					timers = true,
					achievements = true,
					scenarios = true,
				},
			},
			colors = colors,
			hideDefault = true,
		},
		char = {
			hidden = {
				['*'] = {},
			},
			tracked = {},
		},
	}, DEFAULT)
	
	self.trackers = {}
	self:ConfigSetup()
end

function addon:OnEnable()
	quixote.RegisterCallback(self, "Update", "UpdateTrackers")
	quixote.RegisterCallback(self, "Party_Update", "UpdateTrackers")
	quixote.RegisterCallback(self, "Quest_Lost")
	self:RegisterEvent("TRACKED_ACHIEVEMENT_UPDATE", "UpdateTrackers")
	self:RegisterEvent("SCENARIO_CRITERIA_UPDATE", "UpdateTrackers")
	self:RegisterEvent("SCENARIO_UPDATE", "UpdateTrackers")
	self:SecureHook("AddQuestWatch")
	self:SecureHook("RemoveQuestWatch")
	self:SecureHook("QuestMapLogTitleButton_OnClick")
	self:SecureHook("QuestObjectiveTracker_UpdatePOIs")
end
function addon:OnDisable()
	quixote.UnregisterAll(self)
end

-- Tracked quests:

function addon:AddQuestWatch(id)
	local uid = select(8, GetQuestLogTitle(id))
	if uid then
		self.db.char.tracked[uid] = true
	end
	self:UpdateTrackers()
end
function addon:RemoveQuestWatch(id)
	local uid = quixote:GetQuestById(id)
	if uid then
		self.db.char.tracked[uid] = nil
	end
	self:UpdateTrackers()
end
function addon:QuestMapLogTitleButton_OnClick(button)
	if IsModifiedClick("QUESTWATCHTOGGLE") then
		local uid, _, _, _, _, objectives = quixote:GetQuestById(button:GetID() + FauxScrollFrame_GetOffset(QuestLogScrollFrame))
		if (not uid) or (objectives > 0) then return end
		if self.db.char.tracked[uid] then
			self.db.char.tracked[uid] = nil
		else
			-- possibly do a UIErrorsFrame:Clear() here to remove the error spam?
			self.db.char.tracked[uid] = true
		end
		self:UpdateTrackers()
	end
end
function addon:QuestObjectiveTracker_UpdatePOIs()
	if self.db.profile.hideDefault then
		ObjectiveTrackerFrame:Hide()
	end
end
function addon:Quest_Lost(event, title, uid, zone)
	self.db.char.tracked[uid] = nil
end

-- Frame creation:

function addon:CreateTracker(id)
	self.Debug("CreateTracker", id)
	self.trackers[id] = LibStub("LibSimpleFrame-1.0"):New("BetterQuest_"..id, self.db.profile.trackers[id].frame, id)
	self.db.profile.trackerNames[id] = true
	return self.trackers[id]
end
function addon:DeleteTracker(id)
	self.Debug("DeleteTracker", id)
	if self.trackers[id] then self.trackers[id]:Hide() end
	self.trackers[id] = nil
	self.db.profile.trackerNames[id] = nil
	return true
end

-- Item buttons

local get_button, recycle_button, recycle_all_buttons
do
	local cache = {}
	local button_count = 0
	local default_height, default_width = 0, 0
	local Button_OnEvent = function(self, event, ...)
		if event == "PLAYER_TARGET_CHANGED" then
			self.rangeTimer = -1
		elseif event == "BAG_UPDATE_COOLDOWN" then
			local start, duration, enable = GetQuestLogSpecialItemCooldown(self:GetID())
			if start and duration then
				QuestObjectiveItem_UpdateCooldown(self)
			end
		end
	end
	get_button = function()
		local button = next(cache)
		if button then
			cache[button] = nil
		else
			button_count = button_count + 1
			button = CreateFrame("Button", "BetterQuestItemButton" .. button_count, UIParent, "QuestObjectiveItemButtonTemplate")
			button:SetScale(0.85) -- this just happens to work nicely -- it makes it the height of a quest + 1 objective line
			button:SetScript("OnEvent", Button_OnEvent)
			default_height, default_width = button:GetHeight(), button:GetWidth()
		end
		return button
	end
	recycle_button = function(button)
		if not button then return end
		button:SetScale(0.85)
		button:SetHeight(default_height)
		button:SetWidth(default_width)
		button:SetParent(UIParent)
		button:ClearAllPoints()
		button:Hide()
		cache[button] = true
	end
	recycle_all_buttons = function()
		for i=1, button_count do
			recycle_button(_G["BetterQuestItemButton"..i])
		end
	end
end

-- Timers

local get_timer, recycle_timer, recycle_all_timers, build_timer_map, time_remaining
do
	local cache = {}
	local timer_count = 0
	local timers = {}
	local timer_update = function(self, t)
		local remaining = time_remaining(self.questid)
		if remaining <= 0 then
			self:Hide()
		else
			self.text:SetText(("%d:%02d"):format(math.floor(remaining / 60), math.ceil(remaining) % 60))
			self:SetWidth(self.text:GetWidth())
			self:SetHeight(self.text:GetHeight())
		end
	end
	get_timer = function()
		local timer = next(cache)
		if timer then
			cache[timer] = nil
		else
			timer_count = timer_count + 1
			timer = CreateFrame("Frame", "BetterQuestTimer"..timer_count, UIParent)
			timer:SetScript("OnUpdate", timer_update)
			timer:SetHeight(10)
			timer:SetWidth(40)
			timer.text = timer:CreateFontString(nil, "OVERLAY", "GameFontHighlightMedium")
			timer.text:SetAllPoints(timer)
			timer:Hide()
		end
		return timer
	end
	recycle_timer = function(timer)
		if not timer then return end
		timer:SetParent(UIParent)
		timer:ClearAllPoints()
		timer:Hide()
		cache[timer] = true
	end
	recycle_all_timers = function()
		for i=1, timer_count do
			recycle_timer(_G["BetterQuestTimer"..i])
		end
	end
	build_timer_map = function()
		wipe(timers)
		for i=1, select('#', GetQuestTimers()) do
			timers[GetQuestIndexForTimer(i)] = i
		end
	end
	time_remaining = function(index)
		if not timers[index] then return end
		return select(timers[index], GetQuestTimers())
	end
end

-- Trackers:

function addon:UpdateTrackers()
	recycle_all_buttons() -- get rid of 'em all
	recycle_all_timers()
	build_timer_map()
	for id, _ in pairs(self.db.profile.trackerNames) do
		local settings = self.db.profile.trackers[id]
		if settings then
			if settings.enabled then
				self:UpdateTracker(id)
			elseif settings.enabled == false and self.trackers[id] then
				self.trackers[id]:Hide()
			end
		end
	end
	for uid in pairs(self.db.char.tracked) do
		if not quixote:GetQuest(uid) then
			self.db.char.tracked[uid] = nil
		end
	end
end

-- texture code: |T<path>:<width>[:<height>:<xOffset>:<yOffset>]|t
local plus = [[|TInterface\Buttons\UI-PlusButton-Up:12|t]]
local minus = [[|TInterface\Buttons\UI-MinusButton-Up:12|t]]
local bigplus = [[|TInterface\Buttons\UI-PlusButton-Up:18|t]]
local bigminus = [[|TInterface\Buttons\UI-MinusButton-Up:18|t]]
local function zone_click(trackerid, zone)
	addon.db.char.hidden[trackerid][zone] = not addon.db.char.hidden[trackerid][zone]
	addon:UpdateTrackers()
end
local function header_click( trackerid, settings )
	settings.collapsed = not settings.collapsed
	addon:UpdateTrackers()
end
local function quest_click(trackerid, uid)
	local _, qid, title, level, _, objectives, complete = quixote:GetQuestByUid(uid)
	if complete == 1 and GetQuestLogIsAutoComplete(qid) then
		ShowQuestComplete(qid)
	elseif IsAltKeyDown() then
		addon:ToggleQuestWatch(uid)
		GameTooltip:Hide()
	elseif IsShiftKeyDown() then
		local edit_box = ChatEdit_ChooseBoxForSend()
		ChatEdit_ActivateChat(edit_box)
		if IsControlKeyDown() then
			-- Add the quest objectives to the chat editbox, if it's open.
			if objectives then
				for _, objective, got, need, t in quixote:IterateObjectivesForQuest(uid, true) do
					edit_box:Insert(string.format("{%s %s/%s} ", objective, got, need))
				end
			end
		else
			-- Add quest title to the chat editbox if it's open.
			edit_box:Insert(GetQuestLink(qid))
		end
	elseif IsControlKeyDown() then
		quixote:ShareQuestByUid(uid)
	else
		ItemRefTooltip:ClearLines()
		ShowUIPanel(ItemRefTooltip)
		if not ItemRefTooltip:IsVisible() then
			ItemRefTooltip:SetOwner(UIParent, "ANCHOR_PRESERVE")
		end
		local link = GetQuestLink(qid)
		if link then
			ItemRefTooltip:SetHyperlink(link)
		end
	end
end
local function abandon_quest(questid)
	local selected = GetQuestLogSelection()
	SelectQuestLogEntry(questid)
	SetAbandonQuest()
	local items = GetAbandonQuestItems()
	if items then
		StaticPopup_Hide("ABANDON_QUEST")
		StaticPopup_Show("ABANDON_QUEST_WITH_ITEMS", GetAbandonQuestName(), items)
	else
		StaticPopup_Hide("ABANDON_QUEST_WITH_ITEMS")
		StaticPopup_Show("ABANDON_QUEST", GetAbandonQuestName())
	end
	SelectQuestLogEntry(selected)
end
local function inargs(v,...)
	for i=1, select('#', ...) do
		if select(i, ...) == v then
			return true
		end
	end
end
local function achievement_click(trackerid, aid)
	if IsAltKeyDown() then
		if inargs(aid, GetTrackedAchievements()) then
			RemoveTrackedAchievement(aid)
		else
			SetTrackedAchievement(aid)
		end
		GameTooltip:Hide()
	elseif IsShiftKeyDown() then
		local edit_box = ChatEdit_ChooseBoxForSend()
		ChatEdit_ActivateChat(edit_box)
		edit_box:Insert(GetAchievementLink(aid))
		-- TODO: +ctrl to insert the objectives to chat
	else
		ItemRefTooltip:ClearLines()
		ShowUIPanel(ItemRefTooltip)
		if not ItemRefTooltip:IsVisible() then
			ItemRefTooltip:SetOwner(UIParent, "ANCHOR_PRESERVE")
		end
		local link = GetAchievementLink(aid)
		if link then
			ItemRefTooltip:SetHyperlink(link)
		end
	end
end

local dropdown_abandon = function(self, questid)
	abandon_quest(questid)
end
local dropdown_stoptracking = function(self, questid)
	RemoveQuestWatch(questid)
end
local dropdown_share = function(self, uid)
	quixote:ShareQuestByUid(uid)
end
local dropdown_showlog = function(self, uid)
	quixote:ShowQuestLog(uid)
end
local dropdown
local setup_dropdown = function()
	if dropdown then
		return dropdown
	end
	dropdown = CreateFrame("Frame", "BetterQuestTrackerDropdown", UIParent, "UIDropDownMenuTemplate")
	UIDropDownMenu_Initialize(dropdown, function(self)
		if self.type == 'quest' then
			local uid, questid = quixote:GetQuestByUid(self.uid)
			local info = UIDropDownMenu_CreateInfo()
			info.text = quixote:GetTaggedQuestName(uid)
			info.isTitle = true
			info.notCheckable = true
			UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)

			info = UIDropDownMenu_CreateInfo()
			info.notCheckable = true

			info.text = OBJECTIVES_VIEW_IN_QUESTLOG
			info.func = dropdown_showlog
			info.arg1 = uid
			UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)

			if quixote:IsQuestWatchedByUid(uid) then
				info.text = OBJECTIVES_STOP_TRACKING
				info.func = dropdown_stoptracking
				info.arg1 = questid
				UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)
			end

			if GetQuestLogPushable(questid) then
				info.text = SHARE_QUEST
				info.func = dropdown_share
				info.arg1 = uid
				UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)
			end

			info.text = ABANDON_QUEST
			info.func = dropdown_abandon
			info.arg1 = questid
			UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)
		elseif self.type == 'achievement' then
			local aid, name = GetAchievementInfo(self.aid)
			local info = UIDropDownMenu_CreateInfo()
			info.text = name
			info.isTitle = true
			info.notCheckable = true
			UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)
			
			info = UIDropDownMenu_CreateInfo()
			info.notCheckable = true

			info.text = OBJECTIVES_VIEW_ACHIEVEMENT
			info.func = WatchFrame_OpenAchievementFrame
			info.arg1 = aid
			UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)

			info.text = OBJECTIVES_STOP_TRACKING
			info.func = WatchFrame_StopTrackingAchievement
			info.arg1 = aid
			UIDropDownMenu_AddButton(info, UIDROPDOWN_MENU_LEVEL)
		end
	end, "MENU")
end
local function quest_rightclick(trackerid, uid)
	CloseDropDownMenus()
	setup_dropdown()
	dropdown.type = 'quest'
	dropdown.uid = uid
	ToggleDropDownMenu(1, nil, dropdown, 'cursor')
end
local function quest_enter(trackerid, uid)
	local _, qid, title, level, _, objectives, complete = quixote:GetQuestByUid(uid)
	local link = GetQuestLink(qid)
	if link then
		GameTooltip:SetOwner(addon.trackers[trackerid], "ANCHOR_LEFT")
		GameTooltip:SetHyperlink(link)
	end
end
local function quest_leave(trackerid) GameTooltip:Hide() end

local function achievement_rightclick(trackerid, aid)
	CloseDropDownMenus()
	setup_dropdown()
	dropdown.type = 'achievement'
	dropdown.aid = aid
	ToggleDropDownMenu(1, nil, dropdown, 'cursor')
end
local function achievement_enter(trackerid, aid)
	local link = GetAchievementLink(aid)
	if link then
		GameTooltip:SetOwner(addon.trackers[trackerid], "ANCHOR_LEFT")
		GameTooltip:SetHyperlink(link)
	end
end

local display_achievements, display_achievement, display_scenarios, display_grouped_quests, add_quest_to_tracker, quest_matches_filters

function addon:UpdateTracker(id)
	self.Debug("UpdateTracker", id)
	if not self.trackers[id] then self:CreateTracker(id) end
	local settings = self.db.profile.trackers[id]
	if not settings.enabled then settings.enabled = true end
	local tracker = self.trackers[id]:Clear()
	local header = settings.header.counts or settings.header.name
	if header then
		header = tracker:AddLine(UNKNOWN, settings.collapsed and bigplus or bigminus)
			:Color(unpack(addon.db.profile.colors.title))
			:Handler('OnLeftClick', header_click, settings)
			:Font(LSM3:Fetch("font", settings.font), 18, "OUTLINE")
	end
	local num_quests, num_complete = display_grouped_quests[settings.groupBy](id, tracker, settings)
	if settings.scenarios then
		display_scenarios(id, tracker, settings)
	end
	if settings.achievements then
		display_achievements(id, tracker, settings, GetTrackedAchievements())
	end
	if header then
		header.left:SetText(
			(settings.header.name and id or '') ..
			((settings.header.name and settings.header.counts) and ' : ' or '') ..
			(settings.header.counts and (tostring(num_complete)..'/'..tostring(num_quests)) or '')
		)
	end
	tracker:Size():SavePosition():SetPosition():Show()
end

local SCENARIO = GUILD_CHALLENGE_TYPE4 or "Scenario"
function display_scenarios(id, tracker, settings)
	if not (C_Scenario and C_Scenario.IsInScenario()) then
		return
	end
	local name, currentStage, numStages, flags, hasBonusStep, isBonusStepComplete = C_Scenario.GetInfo()
	local stageName, stageDescription, numCriteria = C_Scenario.GetStepInfo()

	if not name then
		return
	end

	local hidden = addon.db.char.hidden[id][SCENARIO]
	if settings.headers then
		tracker:AddLine((hidden and plus or minus)..name, nil) -- `SCENARIO..': '` ???
			:Color(unpack(addon.db.profile.colors.header))
			:Font(LSM3:Fetch("font", settings.font), settings.font_size, "OUTLINE")
			:Handler('OnLeftClick', zone_click, SCENARIO)
	end

	if hidden then
		return
	end

	if stageName then
		local stage = (currentStage == numStages) and SCENARIO_STAGE_FINAL or SCENARIO_STAGE:format(currentStage)
		local stage_line = tracker:AddLine(stageName, stage, settings.wrapTitles, 6)
			:Font(LSM3:Fetch("font", settings.font), settings.font_size)
		if settings.colorTitles then
			stage_line:Color(addon:GetColorFromCompletion(currentStage / numStages))
		end

		-- criteria
		for i = 1, numCriteria do
			local criteriaString, criteriaType, criteriaCompleted, quantity, totalQuantity, flags, assetID, quantityString, criteriaID = C_Scenario.GetCriteriaInfo(i)
			if (not criteriaCompleted) or (not settings.hideCompletedObjectives) then
				local crit_line = tracker:AddLine(criteriaString, criteriaCompleted and 'done' or (("%d/%d"):format(quantity, totalQuantity)), true, 12)
					:Font(LSM3:Fetch("font", settings.font), settings.font_size)
				if settings.colorObjectives then
					local r,g,b,a = addon:GetColorFromCompletion(quantity / totalQuantity)
					crit_line:Color(r,g,b,a, r,g,b,a)
				end
			end
		end
	end

	if hasBonusStep then
		local bonus_line = tracker:AddLine(SCENARIO_BONUS_LABEL, bonusStepFailed and SCENARIO_BONUS_FAILURE or SCENARIO_BONUS_SUCCESS, settings.wrapTitles, 6)
			:Font(LSM3:Fetch("font", settings.font), settings.font_size)

		local bonusName, bonusDescription, numBonusCriteria, bonusStepFailed = C_Scenario.GetBonusStepInfo()
		for i = 1, numBonusCriteria do
			local criteriaString, criteriaType, criteriaCompleted, quantity, totalQuantity, flags, assetID, quantityString, criteriaID, timeLeft, criteriaFailed = C_Scenario.GetBonusCriteriaInfo(i)
			local crit_line = tracker:AddLine(criteriaString, criteriaCompleted and 'done' or (("%d/%d"):format(quantity, totalQuantity)), true, 12)
				:Font(LSM3:Fetch("font", settings.font), settings.font_size)
			if settings.colorObjectives then
				local r,g,b,a = addon:GetColorFromCompletion(quantity / totalQuantity)
				crit_line:Color(r,g,b,a, r,g,b,a)
			end
		end
	end
end

function display_achievements(id, tracker, settings, ...)
	if settings.collapsed then
		return
	end
	local numAchievements = select('#', ...)
	if numAchievements == 0 then
		return
	end
	local hidden = addon.db.char.hidden[id][ACHIEVEMENTS]
	if settings.headers then
		tracker:AddLine((hidden and plus or minus)..ACHIEVEMENTS, numAchievements)
			:Color(unpack(addon.db.profile.colors.header))
			:Font(LSM3:Fetch("font", settings.font), settings.font_size, "OUTLINE")
			:Handler('OnLeftClick', zone_click, ACHIEVEMENTS)
	end
	if hidden then
		return
	end
	for i=1, numAchievements do
		display_achievement(id, tracker, settings, (select(i, ...)))
	end
end
function display_achievement(id, tracker, settings, aid)
	local aid, name, points, completed, month, day, year, description, flags, image, rewardtext = GetAchievementInfo(aid)
	if not (aid and name) then
		return
	end
	if settings.levels then
		name = '[A'..tostring(points)..'] '..name
	end
	local achievement_line = tracker:AddLine(name, nil, settings.wrapTitles, 6)
		:Font(LSM3:Fetch("font", settings.font), settings.font_size)
		:Handler('OnLeftClick', achievement_click, aid)
		:Handler('OnRightClick', achievement_rightclick, aid)
		:Handler('OnEnter', achievement_enter, aid):Handler('OnLeave', quest_leave)
	local r,g,b,a
	local num_criteria, completed_critera = GetAchievementNumCriteria(aid), 0
	if num_criteria == 0 then
		if settings.descIfNoObjective then
			if (not completed) or (not settings.hideCompletedObjectives) then
				tracker:AddLine(description, nil, true, 12)
					:Font(LSM3:Fetch("font", settings.font), settings.font_size)
					:Handler('OnLeftClick', achievement_click, aid)
					:Handler('OnRightClick', achievement_rightclick, aid)
					:Handler('OnEnter', achievement_enter, aid):Handler('OnLeave', quest_leave)
			end
		end
		r,g,b,a = addon:GetColorFromCompletion(completed and 1 or 0)
	else
		for ii=1, num_criteria do
			local critera, ctype, ccompleted, quantity, reqquantity, charname, flags, assetID, quantitystring, cid = GetAchievementCriteriaInfo(aid, ii)
			if ccompleted then completed_critera = completed_critera + 1 end
			if not ccompleted or not settings.hideCompletedObjectives then
				local r,g,b,a
				if settings.colorObjectives then
					r,g,b,a = addon:GetColorFromCompletion(quantity / reqquantity)
				end
				tracker:AddLine(critera, ccompleted and 'done' or (("%d/%d"):format(quantity, reqquantity)), settings.wrapObjectives, 12)
					:Font(LSM3:Fetch("font", settings.font), settings.font_size)
					:Color(r,g,b,a, r,g,b,a)
					:Handler('OnLeftClick', achievement_click, aid)
					:Handler('OnRightClick', achievement_rightclick, aid)
					:Handler('OnEnter', achievement_enter, aid):Handler('OnLeave', quest_leave)
			end
		end
		r,g,b,a = addon:GetColorFromCompletion(completed_critera / num_criteria)
	end
	if settings.colorTitles then
		achievement_line:Color(r,g,b,a, r,g,b,a)
	end
end

display_grouped_quests = {
	zone = function(trackerid, tracker, settings)
		Debug("display_grouped_quests zone", trackerid, tracker, settings)
		local num_quests, num_complete = 0, 0
		for _, zone, n in quixote:IterateZones() do
			Debug("quixote zone", zone, n)
			local header_added = false
			local hidden = addon.db.char.hidden[trackerid][zone]
			for _, uid, qid, title, level, tag, objectives, complete, group, daily, zone in quixote:IterateQuestsInZone(zone) do
				Debug("quixote quest", uid, qid, title, level, tag, objectives, complete, group, daily, zone)
				num_quests = num_quests + 1
				if complete == 1 then num_complete = num_complete + 1 end
				if quest_matches_filters(settings.filters, uid, qid, title, level, tag, objectives, complete, group, daily, zone) then
					if not settings.collapsed then
						if settings.headers and not header_added then
							-- This is *here*, beacuse otherwise the headers would still show for categories that are empty due to filters.
							Debug("adding header", trackerid, zone)
							tracker:AddLine((hidden and plus or minus)..zone, n)
								:Color(unpack(addon.db.profile.colors.header))
								:Handler('OnLeftClick', zone_click, zone)
								:Font(LSM3:Fetch("font", settings.font), settings.font_size, "OUTLINE")
							header_added = true
						end
						if not hidden then
							add_quest_to_tracker(tracker, settings, uid, qid, title, level, tag, objectives, complete, group, daily, zone)
						end
					end
				end
			end
		end
		return num_quests, num_complete
	end,
	level = function(trackerid, tracker, settings)
		Debug("display_grouped_quests level", trackerid, tracker, settings)
		local num_quests, num_complete = 0, 0
		local current_header
		for _, uid, qid, title, level, tag, objectives, complete, group, daily, zone in quixote:IterateQuestsByLevel() do
			num_quests = num_quests + 1
			if complete == 1 then num_complete = num_complete + 1 end
			if not settings.collapsed then
				if quest_matches_filters(settings.filters, uid, qid, title, level, tag, objectives, complete, group, daily, zone) then
					if settings.headers and level ~= current_header then
						tracker:AddLine(level)
							:Color(addon:GetColorFromLevel(level))
							:Font(LSM3:Fetch("font", settings.font), settings.font_size, "OUTLINE")
						current_header = level
					end
					add_quest_to_tracker(tracker, settings, uid, qid, title, level, tag, objectives, complete, group, daily, zone)
				end
			end
		end
		return num_quests, num_complete
	end,
}

local ternary = function(bool, if_true, if_false) if bool then return if_true else return if_false end end
local simple_filter = function(nth)
	return function(show, ...)
		local bool = select(nth, ...)
		return ternary(show == 1, bool, not bool)
	end
end
local filter_checks = {
	--zone = string
	zone = function(zone, ...)
		return select(9, ...) == zone
	end,
	--current_zone = bool
	current_zone = function(show, ...)
		local is_current = select(10, ...) == GetRealZoneText()
		return ternary(show == 1, is_current, not is_current)
	end,
	--tracked = bool
	tracked = function(show, uid, qid)
		local is_tracked = addon.db.char.tracked[uid]
		-- Make only scenario quests count as tracked if we're in a scenario, to mimic default UI behavior
		if C_Scenario and C_Scenario.IsInScenario() and GetQuestLogQuestType(qid) ~= QUEST_TYPE_SCENARIO then
			is_tracked = false
		end
		return ternary(show == 1, is_tracked, not is_tracked)
	end,
	--tag = string
	tag = function(tags, ...)
		if tags.ANY then return true end
		--if tags.NONE and quest_tag == nil then return true end
		return tags[(select(5, ...) or "NONE")]
	end,
	--daily = bool
	daily = simple_filter(9),
	--complete = bool
	complete = simple_filter(7),
}
function quest_matches_filters(filters, ...)
	-- Debug("quest_matches_filters", filters, ...)
	for id, value in pairs(filters) do
		-- Debug("filter", id, value)
		-- If any filter returns false, immediately return false for quest
		if value ~= -1 and filter_checks[id] and not filter_checks[id](value, ...) then
			-- Debug("failed filter")
			return false
		end
	end
	return true
end

local complained_already
function add_quest_to_tracker(tracker, settings, uid, qid, title, level, tag, objectives, complete, group, daily, zone)
	-- Debug("add_quest_to_tracker", tracker, settings, uid, qid, title, level, tag, objectives, complete, group, daily, zone)
	local r,g,b,a
	local count = (settings.partyCount or settings.partyObjectives) and quixote:GetNumPartyMembersWithQuest(uid)
	if settings.levels then
		title = quixote:GetTaggedQuestName(uid)
	end
	if settings.partyCount and count > 0 then
		-- Color? inprogress/completed
		title = title .. " <" .. count .. ">"
	end
	if settings.colorTitles then
		r,g,b,a = addon:GetColorFromLevel(level)
	end
	
	if complete == 1 then
		if GetQuestLogIsAutoComplete(qid) then
			complete = QUEST_WATCH_CLICK_TO_COMPLETE:gsub("[\(\)]", "")
			r,g,b,a = unpack(addon.db.profile.colors.turnin)
			r,g,b,a = 0,0.5,1,1
		else
			complete = 'done'
		end
	elseif complete == -1 then
		complete = 'fail'
	end
	
	local line = tracker:AddLine(title, complete, settings.wrapTitles, 6)
		:Color(r,g,b,a, r,g,b,a)
		:Font(LSM3:Fetch("font", settings.font), settings.font_size)
		:Handler('OnLeftClick', quest_click, uid)
		:Handler('OnRightClick', quest_rightclick, uid)
		:Handler('OnEnter', quest_enter, uid):Handler('OnLeave', quest_leave)
	local height = line:GetHeight()
	if objectives > 0 then
		for _, objective, got, need, t in quixote:IterateObjectivesForQuest(uid, true) do
			if got ~= need or not settings.hideCompletedObjectives then
				if not (got and need) and not complained_already then
					Debug("objective problem", objective, got, need, t)
					addon:Print("There was a problem with the objectives for ", title, "(", uid, ")", objective)
					complained_already = true
				end
				if not got then got = 0 end
				if not need then need = 1 end
				local status = got..'/'..need
				local r,g,b,a
				if settings.colorObjectives then
					if t == 'reputation' then
						r,g,b,a = addon:GetColorFromCompletion(quixote:GetReactionLevel(got)/quixote:GetReactionLevel(need))
					else
						r,g,b,a = addon:GetColorFromCompletion(got/need)
					end
				end
				if settings.partyObjectives then
					for i=1, GetNumGroupMembers() do
						local unit = "party"..i
						local s = ""
						local pgot = quixote:GetPartyQuestObjective(i, uid, objective)
						if pgot and type(pgot) == 'number' then
							s = (UnitName(unit)):sub(1,3) .. ":" .. (pgot == need and 'd' or pgot)
							if settings.colorPartyObjectives then
								local color = RAID_CLASS_COLORS[(select(2, UnitClass(unit)))]
								s = addon:Colorize(s, color.r, color.g, color.b)
							end
						end
						status = s .. " " .. status
					end
				end
				local objline = tracker:AddLine(objective, status, settings.wrapObjectives, 12)
					:Color(r,g,b,a, r,g,b,a)
					:Font(LSM3:Fetch("font", settings.font), settings.font_size)
					:Handler('OnLeftClick', quest_click, uid)
					:Handler('OnRightClick', quest_rightclick, uid)
					:Handler('OnEnter', quest_enter, uid):Handler('OnLeave', quest_leave)
				height = height + objline:GetHeight()
			end
		end
	elseif settings.descIfNoObjective and ((not complete or complete == 0) or not settings.hideCompletedObjectives) then
		local _, objectives = quixote:GetQuestText(uid)
		local objline = tracker:AddLine(objectives, '', true, 12)
			:Font(LSM3:Fetch("font", settings.font), settings.font_size)
			:Handler('OnLeftClick', quest_click, uid)
			:Handler('OnRightClick', quest_rightclick, uid)
			:Handler('OnEnter', quest_enter, uid):Handler('OnLeave', quest_leave)
		height = height + objline:GetHeight()
	end
	if settings.items then -- added in 3.1
		local link, item, charges = GetQuestLogSpecialItemInfo(qid)
		if item and not complete then
			local button = get_button()
			button.questLogIndex = qid
			button.charges = charges
			button.rangeTimer = -1
			button:Show()
			button:SetID(qid)
			button:SetParent(line)
			SetItemButtonTexture(button, item)
			SetItemButtonCount(button, charges)
			QuestObjectiveItem_UpdateCooldown(button)
			button:SetPoint("TOPRIGHT", line, "TOPLEFT")
			if height < button:GetHeight() then
				button:SetHeight(height)
				button:SetWidth(height)
			end
		end
	end
	if settings.timers and time_remaining(qid) then
		local timer = get_timer()
		timer.text:SetFont(LSM3:Fetch("font", settings.font), settings.font_size)
		timer.questid = qid
		timer:SetPoint("TOPLEFT", line, "TOPRIGHT", 5, 0)
		timer:Show()
	end
end

-- Handy utilities:

function addon:ToggleQuestWatch(uid)
	if self.db.char.tracked[uid] then
		quixote:RemoveQuestWatchByUid(uid)
	else
		quixote:AddQuestWatchByUid(uid)
	end
end

function addon:Colorize(s, r, g, b)
	return string.format("|c00%02X%02X%02X%s|r", r * 255, g * 255, b * 255, s)
end

function addon:GetColorFromLevel(level)
	local color = GetQuestDifficultyColor(level)
	-- Color should be the output of GetQuestDifficultyColor; a table.
	if color == QuestDifficultyColors.trivial then
		return unpack(self.db.profile.colors.trivial)
	elseif color == QuestDifficultyColors.standard then
		return unpack(self.db.profile.colors.standard)
	elseif color == QuestDifficultyColors.difficult then
		return unpack(self.db.profile.colors.difficult)
	elseif color == QuestDifficultyColors.verydifficult then
		return unpack(self.db.profile.colors.verydifficult)
	elseif color == QuestDifficultyColors.impossible then
		return unpack(self.db.profile.colors.impossible)
	end
end

function addon:GetColorFromCompletion(percent)
	if percent <= 0 then
		return unpack(self.db.profile.colors.notstarted)
	elseif percent >= 1 then
		return unpack(self.db.profile.colors.done)
	elseif percent == 0.5 then
		return unpack(self.db.profile.colors.underway)
	elseif percent < 0.5 then
		percent = percent / 0.5
		local r1,g1,b1 = unpack(self.db.profile.colors.notstarted)
		local r2,g2,b2 = unpack(self.db.profile.colors.underway)
		return r1+(r2-r1)*percent, g1+(g2-g1)*percent, b1+(b2-b1)*percent
	elseif percent < 1 then
		percent = (percent-0.5) / 0.5
		local r1,g1,b1 = unpack(self.db.profile.colors.underway)
		local r2,g2,b2 = unpack(self.db.profile.colors.done)
		return r1+(r2-r1)*percent, g1+(g2-g1)*percent, b1+(b2-b1)*percent
	end
end
