local quixote = LibStub("LibQuixote-2.0")
local core = LibStub("AceAddon-3.0"):GetAddon("BetterQuest")
local module = core:NewModule("Blizzard", "AceHook-3.0", "AceEvent-3.0")
local Debug = core.Debug

local db
function module:OnModuleInitialize()
	self.db = core.db:RegisterNamespace("Blizzard", {
		profile = {
			levels_log = true,
			levels_dialog = true,
			levels_tracker = true,
			colors_tracker = true,
			--levels_lfg = true,
			icons_dialog = true,
			enabled = true,
		},
	})
	db = self.db
	self.menu = {
		levels_log = {name = "Levels in questlog", type = "toggle",},
		levels_dialog = {name = "Levels in NPC dialogs", type = "toggle",},
		levels_tracker = {name = "Levels in quest tracker", type = "toggle",},
		colors_tracker = {name = "Colors in quest tracker", type = "toggle",},
		icons_dialog = {name = "Fade icons in NPC dialogs", type = "toggle",},
	}

	self:SetupEnvProxy()
end

function module:OnModuleEnable()
	self:SecureHook(QUEST_TRACKER_MODULE, "SetBlockHeader")
	self:SecureHook(QUEST_TRACKER_MODULE, "AddObjective")
	self:OnSettingsUpdate()
end

function module:OnSettingsUpdate()
	-- In dialogs
	if db.profile.levels_dialog or db.profile.icons_dialog then
		self:RegisterEvent("GOSSIP_SHOW")
		self:RegisterEvent("QUEST_GREETING")
	else
		self:UnregisterEvent("GOSSIP_SHOW")
		self:UnregisterEvent("QUEST_GREETING")
	end
end

-- Levels in NPC dialogs:

local function quest_icon_faded(title)
	local objectives, complete = select(6, quixote:GetQuest(title))
	-- if we don't have the quest, we don't fade it:
	if objectives == nil and complete == nil then return false end
	return not (complete == 1 or objectives == 0)
end

local function gossip_loop(jump, buttonindex, do_texture, ...)
	local numQuests = select('#', ...)
	for i=2, numQuests, jump do
		local button = _G["GossipTitleButton"..buttonindex]
		local level = select(i, ...)
		button:SetText(format('[%s] %s', level == -1 and '*' or level, button:GetText()))
		buttonindex = buttonindex + 1
	end
	return buttonindex + 1
end

function module:GOSSIP_SHOW()
	local buttonindex = 1
	if GetGossipAvailableQuests() then
		buttonindex = gossip_loop(6, buttonindex, false, GetGossipAvailableQuests())
	end
	if GetGossipActiveQuests() then
		buttonindex = gossip_loop(5, buttonindex, db.profile.icons_dialog, GetGossipActiveQuests())
	end
end

function module:QUEST_GREETING()
	local do_texture = db.profile.icons_dialog
	local numactive, numavailable = GetNumActiveQuests(), GetNumAvailableQuests()
	local title, level
	local o,GetTitle,GetLevel = 0,GetActiveTitle,GetActiveLevel
	for i=1, numactive + numavailable do
		if i == numactive + 1 then
			o,GetTitle,GetLevel = numactive,GetAvailableTitle,GetAvailableLevel
		end
		title, level = GetTitle(i-o), GetLevel(i-o)
		_G["QuestTitleButton"..i]:SetText(format('[%s] %s', level == -1 and '*' or level, title))
		if do_texture and quest_icon_faded(title) then
			_G["QuestTitleButton"..i.."QuestIcon"]:SetVertexColor(0.5, 0.5, 0.5, 0.5)
		else
			_G["QuestTitleButton"..i.."QuestIcon"]:SetVertexColor(1, 1, 1, 1)
		end
	end
end

-- levels in the objective tracker

function module:SetBlockHeader(tracker, block, text, questLogIndex, isQuestComplete)
	local title, level, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID, startEvent, displayQuestID, isOnMap, hasLocalPOI, isTask, isStory = GetQuestLogTitle(questLogIndex)
	if level and level > 0 then
		if module.db.profile.levels_tracker then
			title = quixote:GetTaggedQuestName(questID)
			Debug("adding levels", title)
		end
		if module.db.profile.colors_tracker then
			title = core:Colorize(title, core:GetColorFromLevel(level))
			Debug("adding colors", title)
		end
		local height = tracker:SetStringText(block.HeaderText, title, nil, OBJECTIVE_TRACKER_COLOR["Header"])
	end
end

-- colors in objective tracker

function module:AddObjective(tracker, block, objectiveKey, text, lineType, useFullHeight, hideDash, colorStyle)
	if not module.db.profile.colors_tracker then
		return
	end
	local questLogIndex = block.questLogIndex
	if not questLogIndex then
		return
	end
	local uid = quixote:GetQuestById(questLogIndex)
	if uid then
		local progress, needed, total, objtype = quixote:GetQuestObjective(uid, objectiveKey)
		Debug("Quixote says", uid, progress, needed, total, objtype)
		if progress then
			local completion
			if objtype == "reputation" then
				completion = (needed == total) and 1 or 0
			else
				completion = needed / total
			end
			local height = tracker:SetStringText(block.currentLine.Text, core:Colorize(text, core:GetColorFromCompletion(completion)), useFullHeight, colorStyle, block.isHighlighted)
			block.currentLine:SetHeight(height)
		end
	end
end

-- As payback for all the similar comments in SmoothQuest, this concept is totally stolen from there
function module:SetupEnvProxy()
	local env = setmetatable({
		GetQuestLogTitle = function(id)
			local title, level, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID, startEvent, displayQuestID, isOnMap, hasLocalPOI, isTask, isStory = GetQuestLogTitle(id)
			if level and level > 0 and module.db.profile.levels_log then
				title = quixote:GetTaggedQuestName(questID)
			end
			return title, level, suggestedGroup, isHeader, isCollapsed, isComplete, frequency, questID, startEvent, displayQuestID, isOnMap, hasLocalPOI, isTask, isStory
		end,
	}, {__index = _G})
	setfenv(QuestLogQuests_Update, env)
end
