local quixote = LibStub("LibQuixote-2.0")
local core = LibStub("AceAddon-3.0"):GetAddon("BetterQuest")

local LibQTip = LibStub("LibQTip-1.0")

local dataobject = LibStub("LibDataBroker-1.1"):NewDataObject("BetterQuest", {
	type = "data source",
	icon = [[Interface\Icons\INV_Misc_Shovel_01]],
	label = "Quests",
	text = "",
})

local tooltip
function dataobject:OnEnter()
	tooltip = LibQTip:Acquire("BetterQuestLDBTooltip", 2, "LEFT", "RIGHT")
	--tooltip:AddHeader("Name", "Level", "Type", "Count", "Last Seen")

	for _, zone, n in quixote:IterateZones() do
		tooltip:AddLine(zone)
		for _, uid, qid, title, level, tag, objectives, complete, group, daily, zone in quixote:IterateQuestsInZone(zone) do
			tooltip:AddLine(quixote:GetTaggedQuestName(uid), complete and 'done' or '')
		end
	end

	tooltip:SmartAnchorTo(self)
	tooltip:Show()
end
function dataobject:OnLeave()
	LibQTip:Release(tooltip)
	tooltip = nil
end

function dataobject:OnClick(button)
	if button == "LeftButton" then
		quixote:ShowQuestLog()
	elseif button == "RightButton" then
		core:ShowConfig()
		--LibStub("AceConfigDialog-3.0"):Open("BetterQuest")
	end
end

quixote.RegisterCallback("BetterQuestLDB", "Update", function()
	local quests, complete = quixote:GetNumQuests()
	dataobject.text = complete .. '/' .. quests
end)
