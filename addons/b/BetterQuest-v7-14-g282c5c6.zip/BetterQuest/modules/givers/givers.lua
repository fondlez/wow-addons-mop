local quixote = LibStub("LibQuixote-2.0")
local core = LibStub("AceAddon-3.0"):GetAddon("BetterQuest")
local module = core:NewModule("Givers", "AceHook-3.0")

function module:OnModuleInitialize()
	self.db = core.db:RegisterNamespace("Givers", {
		profile = {
			enabled = true,
		},
		char = {
			givers = {},
		},
	})
end

function module:OnModuleEnable()
	--self:Hook("AcceptQuest", true) -- TODO: This should probably be in Quixote
	self:SecureHook("QuestMapFrame_ShowQuestDetails")
	quixote.RegisterCallback(self, "Quest_Gained")
	quixote.RegisterCallback(self, "Quest_Lost")
	if quixote.firstDone then
		module:Cleanup()
	else
		quixote.RegisterCallback(self, "Ready", "Cleanup")
	end
end

function module:Cleanup()
	for uid in pairs(self.db.char.givers) do
		if not quixote:GetQuestByUid(uid) then
			self.db.char.givers[uid] = nil
		end
	end
end

function module:Quest_Gained(event, title, uid, objectives, zone, npc, npc_is_player)
	if (not npc) or npc_is_player then
		self.db.char.givers[uid] = "Item or other player"
	else
		local x,y = GetPlayerMapPosition("player")
		self.db.char.givers[uid] = ("%s in %s (%d,%d)"):format(npc, GetZoneText(), floor(x*100), floor(y*100))
	end
end

function module:Quest_Lost(title, uid)
	self.db.char.givers[uid] = nil
end

function module:QuestMapFrame_ShowQuestDetails(uid)
	local giver = self.db.char.givers[uid]
	if giver then
		QuestInfoObjectivesText:SetText(giver .. '\n\n' .. QuestInfoObjectivesText:GetText())
	end
end
