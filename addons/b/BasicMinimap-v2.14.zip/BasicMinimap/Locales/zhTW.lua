
if GetLocale() ~= "zhTW" then return end
local _, BM = ...
BM["AUTOZOOM"] = "自動放大"
BM["BORDERSIZE"] = "外框大小"
BM["BUTTONDESC"] = "選擇開啟行事曆和追蹤能力選單之按鈕"
BM["CALENDAR"] = "行事曆"
BM["CLASSCOLORED"] = "職業著色"
BM["SCALE"] = "大小比例"
BM["SHAPE"] = "形狀"
BM["STRATA"] = "層級"
BM["TOOLTIP"] = "提示"

