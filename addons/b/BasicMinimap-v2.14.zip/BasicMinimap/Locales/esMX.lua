
if GetLocale() ~= "esMX" then return end
local _, BM = ...
BM["AUTOZOOM"] = "Auto Alejar Zoom"
BM["BORDERSIZE"] = "Tamaño del Borde"
BM["BUTTONDESC"] = "Elije los botones para abrir el calendario y el menú de rastreo."
BM["CALENDAR"] = "Calendario"
BM["CLASSCOLORED"] = "Color de Clase" -- Needs review
BM["SCALE"] = "Tamaño"
BM["SHAPE"] = "Forma"
BM["STRATA"] = "Capa de la UI" -- Needs review
BM["TOOLTIP"] = "Herramientas" -- Needs review

