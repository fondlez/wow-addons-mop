
local _, BM = ...
BM.AUTOZOOM = "Auto Zoom Out"
BM.BORDERSIZE = "Border Size"
BM.BUTTONDESC = "Choose the buttons for opening the Calendar and Tracking menu."
BM.CALENDAR = "Calendar"
BM.CLASSCOLORED = "Class Colored"
BM.SCALE = "Scale"
BM.SHAPE = "Shape"
BM.STRATA = "Strata"
BM.TOOLTIP = "Tooltip"

