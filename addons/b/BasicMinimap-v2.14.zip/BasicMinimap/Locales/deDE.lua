
if GetLocale() ~= "deDE" then return end
local _, BM = ...
BM["AUTOZOOM"] = "Automatisch herauszoomen" -- Needs review
BM["BORDERSIZE"] = "Rahmengröße" -- Needs review
BM["BUTTONDESC"] = "Auswahl der Tasten zum Öffnen des Kalenders und der Aufspüroptionen." -- Needs review
BM["CALENDAR"] = "Kalender" -- Needs review
BM["CLASSCOLORED"] = "Nach Klasse gefärbt" -- Needs review
BM["SCALE"] = "Skalierung" -- Needs review
BM["SHAPE"] = "Form" -- Needs review
BM["STRATA"] = "Schicht" -- Needs review
BM["TOOLTIP"] = "Tooltip" -- Needs review

