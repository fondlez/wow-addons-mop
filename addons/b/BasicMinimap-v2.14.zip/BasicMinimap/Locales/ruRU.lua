
if GetLocale() ~= "ruRU" then return end
local _, BM = ...
BM["AUTOZOOM"] = "Авто уменьшение" -- Needs review
BM["BORDERSIZE"] = "Толщина каймы" -- Needs review
BM["BUTTONDESC"] = "Выберите кнопки для Календаря и Меню Слежения." -- Needs review
BM["CALENDAR"] = "Календарь" -- Needs review
BM["CLASSCOLORED"] = "По цвету класса" -- Needs review
BM["SCALE"] = "Масштаб" -- Needs review
BM["SHAPE"] = "Форма" -- Needs review
BM["STRATA"] = "Слой" -- Needs review
BM["TOOLTIP"] = "Подсказка" -- Needs review

