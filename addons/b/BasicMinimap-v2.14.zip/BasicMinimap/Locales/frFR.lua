
if GetLocale() ~= "frFR" then return end
local _, BM = ...
BM["AUTOZOOM"] = "Dézoom auto" -- Needs review
BM["BORDERSIZE"] = "Taille de la bordure" -- Needs review
BM["BUTTONDESC"] = "Choisissez les boutons permettant d'ouvrir le calendrier le menu de suivi." -- Needs review
BM["CALENDAR"] = "Calendrier" -- Needs review
BM["CLASSCOLORED"] = "Coloration par classe" -- Needs review
BM["SCALE"] = "Échelle" -- Needs review
BM["SHAPE"] = "Forme" -- Needs review
BM["STRATA"] = "Couche" -- Needs review
BM["TOOLTIP"] = "Bulle d'aide" -- Needs review

