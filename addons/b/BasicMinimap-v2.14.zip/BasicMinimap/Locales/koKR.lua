
if GetLocale() ~= "koKR" then return end
local _, BM = ...
BM["AUTOZOOM"] = "자동 줌아웃" -- Needs review
BM["BORDERSIZE"] = "외곽선 크기" -- Needs review
BM["BUTTONDESC"] = "달력과 추적메뉴를 여는 버튼을 설정합니다." -- Needs review
BM["CALENDAR"] = "달력" -- Needs review
BM["CLASSCOLORED"] = "직업 색상" -- Needs review
BM["SCALE"] = "크기" -- Needs review
BM["SHAPE"] = "모양" -- Needs review
BM["STRATA"] = "우선순위" -- Needs review
BM["TOOLTIP"] = "툴팁" -- Needs review

