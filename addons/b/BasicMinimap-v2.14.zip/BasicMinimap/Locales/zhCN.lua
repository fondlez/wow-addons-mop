
if GetLocale() ~= "zhCN" then return end
local _, BM = ...
BM["AUTOZOOM"] = "自动放大" -- Needs review
BM["BORDERSIZE"] = "边框大小" -- Needs review
BM["BUTTONDESC"] = "选择打开日历和追踪菜单的按钮." -- Needs review
BM["CALENDAR"] = "日历" -- Needs review
BM["CLASSCOLORED"] = "职业着色" -- Needs review
BM["SCALE"] = "缩放" -- Needs review
BM["SHAPE"] = "外形" -- Needs review
BM["STRATA"] = "层级" -- Needs review
BM["TOOLTIP"] = "提示信息" -- Needs review

