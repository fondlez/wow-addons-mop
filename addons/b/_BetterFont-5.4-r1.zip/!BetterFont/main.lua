--
-- Little tweak which enables a new default font to your UI.
--

DAMAGE_TEXT_FONT = "Interface\\AddOns\\!BetterFont\\Prototype.ttf";
UNIT_NAME_FONT   = "Interface\\AddOns\\!BetterFont\\Prototype.ttf";
NAMEPLATE_FONT   = "Interface\\AddOns\\!BetterFont\\Prototype.ttf";
STANDARD_TEXT_FONT = "Interface\\AddOns\\!BetterFont\\Prototype.ttf";