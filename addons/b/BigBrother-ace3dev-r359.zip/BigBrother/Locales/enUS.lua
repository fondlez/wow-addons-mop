local silent = true
--[===[@debug@
silent = nil
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("BigBrother", "enUS", true, silent)
--sed -n s/.*\(L\[.*\]\).*/\1/gp *.lua

-----------------------------
--Settings

L["Open settings."] = true


-----------------------------
--Checks

L["Buff Check"] = true
L["Report who is missing consumables and/or buffs."] = true

L["Checks"] = true

L["Set what is included in a buff check."] = true
L["Flasks/Elixirs"] = true
L["Include flasks and elixirs in checks."] = true
L["Food Buffs"] = true
L["Include food buffs in checks."] = true
L["Raid Buffs"] = true
L["Include raid buffs in checks."] = true
L["Check on Ready Check"] = true
L["Buff check on a ready check when in a non-LFG instance group.\n\n|cffffff33Checked|r: Report if started by you.\n|cffccccccGray|r: Report always."] = true
L["Max Quality Only"] = true
L["Only count consumables of the highest available stat value in checks."] = true

L["Checked Raid Groups"] = true
L["Set which raid groups are checked for buffs."] = true
L["Use Instance Difficulty"] = true
L["Use the currently selected instance difficulty to determine which groups to check."] = true

L["Default Output"] = true
L["Set the default check output."] = true
L["Self"] = true
L["Print to your chat window."] = true
L["Report to say."] = true
L["Report to yell."] = true
L["Report to party or raid chat."] = true
L["Report to party chat."] = true
L["Report to raid chat."] = true
L["Report as a raid warning."] = true
L["Report to guild chat."] = true
L["Report to officer chat."] = true
L["Report to a custom channel."] = true
L["Whisper Missing"] = true
L["Whisper players that are missing consumables on checks."] = true

L["One Elixir"] = true
L["No Flask"] = true
L["Not Well Fed"] = true
L["Missing Buffs"] = true


-----------------------------
--Alerts

L["Alerts"] = true

L["Combat Alerts"] = true
L["Set what is reported to chat."] = true
L["Crowd Control"] = true
L["Report when a player breaks a crowd control effect."] = true
L["Misdirects"] = true
L["Report who gains Misdirection."] = true
L["Taunts"] = true
L["Report taunts."] = true
L["Interrupts"] = true
L["Report interrupts."] = true
L["Dispels"] = true
L["Report dispels and Spellsteal."] = true
L["Combat Resurrections"] = true
L["Report combat resurrections."] = true

L["Noncombat Alerts"] = true
L["Consumables"] = true
L["Report when a player uses a feast or a cauldron."] = true
L["Repair Bots"] = true
L["Report when a player uses a repair bot."] = true
L["Portals"] = true
L["Report when a Mage opens a portal."] = true
L["Rituals"] = true
L["Report when a player needs assistance summoning an object."] = true
L["Resurrections"] = true
L["Report resurrections."] = true

L["Output"] = true
L["Set where the alert output is sent."] = true

L["Set where the alert output is sent if not set individually."] = true
L["Separate Outputs"] = true
L["Allow setting the output on a per-alert basis"] = true
L["Reset Outputs"] = true
L["Reset all individual alert outputs to use the default output."] = true
L["Enabled Zones"] = true
L["Select the type of zones that have alerts enabled."] = true
L["Enable alerts while in the open world."] = true
L["Enable alerts while in a battleground."] = true
L["Enable alerts while in an arena."] = true
L["Enable alerts while in a party instance."] = true
L["Enable alerts while in a raid instance."] = true
L["Enable alerts while in a looking for group instance."] = true

L["Use Spell Links"] = true
L["Display spell names as clickable spell links."] = true
L["Use Player Links"] = true
L["Display player names as clickable player links."] = true
L["Use Raid Target Icons"] = true
L["Show associated raid target icons as part of the alert."] = true
L["Group Only"] = true
L["Only report events from players in your group."] = true
L["No Spam in LFG"] = true
L["Don't send alerts to chat in looking for group instances."] = true
L["Fallback Output to Self"] = true
L["Print to the chat window if unable to send to the specified output."] = true

L["%s's %s"] = true
L["%s on %s removed by %s"] = true
L["%s on %s removed by %s's %s"] = true
L["%s used %s"] = true
L["%s is casting %s"] = true
L["%s cast %s"] = true
L["%s cast %s on %s"] = true
L["%s missed %s on %s (%s)"] = true
L["%s's %s interrupted %s's %s"] = true
L["Not casting"] = true


-----------------------------
--Buff Window

L["Buff Window"] = true
L["Opens the buff window (drag the bottom to resize)."] = true

L["Limit size"] = true
L["Limits the number of rows shown to the number of people in your group (minimum: %d, maximum: %d)."] = true
L["Open on Ready Check"] = true
L["Open the buff window on a ready check when you're in a non-LFG instance group."] = true
L["Close on Combat"] = true
L["Close the buff window when entering combat."] = true


-----------------------------
--LDB

L["|cffff8040Left Click|r to toggle the buff window"] = true
L["|cffff8040Shift-Left Click|r to run a buff check"] = true
L["|cffff8040Right Click|r to open the options window"] = true
L["Hide minimap button"] = true

