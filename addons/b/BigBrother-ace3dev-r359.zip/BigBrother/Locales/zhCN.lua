--Translation by BNS (TW@世界之树-三皈依)
local L = LibStub("AceLocale-3.0"):NewLocale("BigBrother", "zhCN")
if not L then return end

--@ localization(locale="zhCN", format="lua_additive_table") @

-----------------------------
--Settings

L["Open settings."] = "打开设置"


-----------------------------
--Checks

L["Buff Check"] = "BUFF检查"
L["Report who is missing consumables and/or buffs."] = "报告谁缺少消耗品或增益。"

L["Checks"] = "检查"

L["Set what is included in a buff check."] = "设定什么要包含在增益检查"
L["Flasks/Elixirs"] = "精链/药剂"
L["Include flasks and elixirs in checks."] = ""
L["Food Buffs"] = "食物饱足增益"
L["Include food buffs in checks."] = "包含食物增益在检查中"
L["Raid Buffs"] = "团队增益"
L["Include raid buffs in checks."] = "检查时包含团队的增益。"
L["Check on Ready Check"] = "在团确时一起检查"
L["Buff check on a ready check when in a non-LFG instance group.\n\n|cffffff33Checked|r: Report if started by you.\n|cffccccccGray|r: Report always."] = "如果不是在随机团队副本，在团确时检查增益。\n\n|cffffff33如勾选|r: 是你开始团确才报告。\n|cffcccccc灰色|r: 总是报告。"
L["Max Quality Only"] = "唯有最高品质"
L["Only count consumables of the highest available stat value in checks."] = "在检查时只有计算最高属性价值的消耗品"

L["Checked Raid Groups"] = "检查团队各小队"
L["Set which raid groups are checked for buffs."] = "设定哪个小队包含在检查"
L["Use Instance Difficulty"] = "使用副本难度"
L["Use the currently selected instance difficulty to determine which groups to check."] = "以副本难度(10/25)来确定检查的小队"

L["Default Output"] = "预设输出"
L["Set the default check output."] = "设定预设检查的输出"
L["Self"] = "自身"
L["Print to your chat window."] = "输出警报到聊天视窗"
L["Report to say."] = "报告到说"
L["Report to yell."] = "报告到大喊"
L["Report to party or raid chat."] = "报告到队伍/团队"
L["Report to party chat."] = "报告到队伍"
L["Report to raid chat."] = "报告到团队"
L["Report as a raid warning."] = "报告到团队警告"
L["Report to guild chat."] = "报告到公会"
L["Report to officer chat."] = "报告到干部"
L["Report to a custom channel."] = "报告到自定频道"
L["Whisper Missing"] = "密语缺少的"
L["Whisper players that are missing consumables on checks."] = "密语检查时缺少消耗品的玩家。"

L["One Elixir"] = "只有一种药剂"
L["No Flask"] = "无精链药剂"
L["Not Well Fed"] = "无充分进食效果"
L["Missing Buffs"] = "缺少增益"


-----------------------------
--Alerts

L["Alerts"] = "警报"

L["Combat Alerts"] = "战斗警报"
L["Set what is reported to chat."] = "设定哪个报告在聊天栏"
L["Crowd Control"] = "破控选项"
L["Report when a player breaks a crowd control effect."] = "报告哪位玩家破控"
L["Misdirects"] = "误导"
L["Report who gains Misdirection."] = "报告谁得到误导"
L["Taunts"] = "嘲讽"
L["Report taunts."] = "报告嘲讽"
L["Interrupts"] = "打断"
L["Report interrupts."] = "报告打断"
L["Dispels"] = "驱散"
L["Report dispels and Spellsteal."] = "报告驱散与法术窃取。"
L["Combat Resurrections"] = "战斗复活"
L["Report combat resurrections."] = "报告战斗复活"

L["Noncombat Alerts"] = "非战斗警报"
L["Consumables"] = "消耗品"
L["Report when a player uses a feast or a cauldron."] = "报告当玩家使用盛宴或是大锅时"
L["Repair Bots"] = "修理机器人"
L["Report when a player uses a repair bot."] = "报告玩家开启修理机器人"
L["Portals"] = "传送门"
L["Report when a Mage opens a portal."] = "报告法师开启一个传送门"
L["Rituals"] = "仪式(水包.灵魂石.传送门等)"
L["Report when a player needs assistance summoning an object."] = "报告哪位玩家需要仪式协助"
L["Resurrections"] = "复活"
L["Report resurrections."] = "报告复活"

L["Output"] = "输出"
L["Set where the alert output is sent."] = "设定哪个警报将会报告"

L["Set where the alert output is sent if not set individually."] = "如果没有独立设置，设定警报发送到哪。"
L["Separate Outputs"] = "独立的输出"
L["Allow setting the output on a per-alert basis"] = "允许在每个警报的基础设定输出"
L["Reset Outputs"] = "重置输出"
L["Reset all individual alert outputs to use the default output."] = "重置每个独立警报输出使用预设输出。"
L["Enabled Zones"] = "启用区域"
L["Select the type of zones that have alerts enabled."] = "选择启用警报的区域类型。"
L["Enable alerts while in the open world."] = "当在开放世界时启用警报。"
L["Enable alerts while in a battleground."] = "当在战场时启用警报。"
L["Enable alerts while in an arena."] = "当在竞技场时启用警报。"
L["Enable alerts while in a party instance."] = "当在地城副本时启用警报。"
L["Enable alerts while in a raid instance."] = "当在团队副本时启用警报。"
L["Enable alerts while in a looking for group instance."] = "当在寻求组队副本时启用警报。"

L["Use Spell Links"] = "使用法术连结"
L["Display spell names as clickable spell links."] = "显示法术名称为一个可点击的法术连结"
L["Use Player Links"] = "使用玩家连结"
L["Display player names as clickable player links."] = "显示玩家名称为可点击的连结。"
L["Use Raid Target Icons"] = "使用团队目标图标"
L["Show associated raid target icons as part of the alert."] = "显示关联的团队目标图示在警报中"
L["Group Only"] = "只有团体"
L["Only report events from players in your group."] = "只有报告在团体中玩家的事件"
L["No Spam in LFG"] = "在寻求团队中不报告"
L["Don't send alerts to chat in looking for group instances."] = "在寻求团队副本中不发送警报到聊天中。"
L["Fallback Output to Self"] = "回馈输出到自身"
L["Print to the chat window if unable to send to the specified output."] = "当无法输出特定讯息时列印在聊天栏"

L["%s's %s"] = "%s的s %s"
L["%s on %s removed by %s"] = "%s在%s被%s破除"
L["%s on %s removed by %s's %s"] = "%1$s在%2$s被%3$s的%4$s破除"
L["%s used %s"] = "%s使用%s"
L["%s is casting %s"] = "%s正施法在%s"
L["%s cast %s"] = "%s施放%s"
L["%s cast %s on %s"] = "%s施放%s在%s"
L["%s cast %s on %s (%s)"] = "%s施放%s在%s (%s)"
L["%s interrupted %s's %s with %s"] = "%1$s使用%4$s中断了%2$s的%3$s"
L["Not casting"] = "非施法"


-----------------------------
--Buff Window

L["Buff Window"] = "增益视窗"
L["Opens the buff window (drag the bottom to resize)."] = "开启增益视窗(拖动下面可以改变大小)。"

L["Limit size"] = "限制大小"
L["Limits the number of rows shown to the number of people in your group (minimum: %d, maximum: %d)."] = "限制在你的队伍中人员显示的行数(最小: %d, 最大: %d)"
L["Open on Ready Check"] = "在准备确认时开启"
L["Open the buff window on a ready check when you're in a non-LFG instance group."] = "除非你在寻求团队的地城队伍中，否则在准备确认时开启增益视窗。"
L["Close on Combat"] = "开始战斗后关闭"
L["Close the buff window when entering combat."] = "进入战斗后关闭增益视窗。"


-----------------------------
--LDB

L["|cffff8040Left Click|r to toggle the buff window"] = "|cffff8040左键点击|r 挂载BUFF视窗"
L["|cffff8040Shift-Left Click|r to run a buff check"] = "|cffff8040Shift-左键点击|r 运行增益检查"
L["|cffff8040Right Click|r to open the options window"] = "|cffff8040右键点击|r 打开设置视窗"
L["Hide minimap button"] = "隐藏小地图按钮"