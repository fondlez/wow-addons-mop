local _, BigBrother = ...

-- Shared Spells
local SpellData = {}

SpellData.flasks = {
	(GetSpellInfo(105689)), -- Flask of Spring Blossoms
	(GetSpellInfo(105691)), -- Flask of the Warm Sun
	(GetSpellInfo(105693)), -- Flask of Falling Leaves
	(GetSpellInfo(105694)), -- Flask of the Earth
	(GetSpellInfo(105696)), -- Flask of Winter's Bite
}

SpellData.elixirsGuardian = {
	(GetSpellInfo(79631)), -- Prismatic Elixir (Cata)
	(GetSpellInfo(105681)), -- Mantid Elixir
	(GetSpellInfo(105687)), -- Elixir of Mirrors
}

SpellData.elixirsBattle = {
	(GetSpellInfo(105682)), -- Mad Hozen Elixir
	(GetSpellInfo(105683)), -- Elixir of Weaponry
	(GetSpellInfo(105684)), -- Elixir of the Rapids
	(GetSpellInfo(105685)), -- Elixir of Peace
	(GetSpellInfo(105686)), -- Elixir of Perfection
	(GetSpellInfo(105688)), -- Monk's Elixir
}

SpellData.foods = {
	(GetSpellInfo(19705)), -- Well Fed
	(GetSpellInfo(433)),   -- Food
}

-- 300 stat food (Well Fed/Food)
SpellData.foodsMax = {
	[104272] = true,
	[104935] = true, -- str
	[104275] = true,
	[104935] = true, -- agi
	[104277] = true,
	[104935] = true, -- int
	[104280] = true,
	[104935] = true, -- spirit
	[104283] = true,
	[104935] = true, -- stamina
}

BigBrother.SpellData = SpellData
