--Translation by BNS (TW@世界之樹-三皈依)
local L = LibStub("AceLocale-3.0"):NewLocale("BigBrother", "zhTW")
if not L then return end

--@ localization(locale="zhTW", format="lua_additive_table") @

-----------------------------
--Settings

L["Open settings."] = "打開設置"


-----------------------------
--Checks

L["Buff Check"] = "BUFF檢查"
L["Report who is missing consumables and/or buffs."] = "報告誰缺少消耗品或增益。"

L["Checks"] = "檢查"

L["Set what is included in a buff check."] = "設定什麼要包含在增益檢查"
L["Flasks/Elixirs"] = "精鍊/藥劑"
L["Include flasks and elixirs in checks."] = ""
L["Food Buffs"] = "食物飽足增益"
L["Include food buffs in checks."] = "包含食物增益在檢查中"
L["Raid Buffs"] = "團隊增益"
L["Include raid buffs in checks."] = "檢查時包含團隊的增益。"
L["Check on Ready Check"] = "在團確時一起檢查"
L["Buff check on a ready check when in a non-LFG instance group.\n\n|cffffff33Checked|r: Report if started by you.\n|cffccccccGray|r: Report always."] = "如果不是在隨機團隊副本，在團確時檢查增益。\n\n|cffffff33如勾選|r: 是你開始團確才報告。\n|cffcccccc灰色|r: 總是報告。"
L["Max Quality Only"] = "唯有最高品質"
L["Only count consumables of the highest available stat value in checks."] = "在檢查時只有計算最高屬性價值的消耗品"

L["Checked Raid Groups"] = "檢查團隊各小隊"
L["Set which raid groups are checked for buffs."] = "設定哪個小隊包含在檢查"
L["Use Instance Difficulty"] = "使用副本難度"
L["Use the currently selected instance difficulty to determine which groups to check."] = "以副本難度(10/25)來確定檢查的小隊"

L["Default Output"] = "預設輸出"
L["Set the default check output."] = "設定預設檢查的輸出"
L["Self"] = "自身"
L["Print to your chat window."] = "輸出警報到聊天視窗"
L["Report to say."] = "報告到說"
L["Report to yell."] = "報告到大喊"
L["Report to party or raid chat."] = "報告到隊伍/團隊"
L["Report to party chat."] = "報告到隊伍"
L["Report to raid chat."] = "報告到團隊"
L["Report as a raid warning."] = "報告到團隊警告"
L["Report to guild chat."] = "報告到公會"
L["Report to officer chat."] = "報告到幹部"
L["Report to a custom channel."] = "報告到自定頻道"
L["Whisper Missing"] = "密語缺少的"
L["Whisper players that are missing consumables on checks."] = "密語檢查時缺少消耗品的玩家。"

L["One Elixir"] = "只有一種藥劑"
L["No Flask"] = "無精鍊藥劑"
L["Not Well Fed"] = "無充分進食效果"
L["Missing Buffs"] = "缺少增益"


-----------------------------
--Alerts

L["Alerts"] = "警報"

L["Combat Alerts"] = "戰鬥警報"
L["Set what is reported to chat."] = "設定哪個報告在聊天欄"
L["Crowd Control"] = "破控選項"
L["Report when a player breaks a crowd control effect."] = "報告哪位玩家破控"
L["Misdirects"] = "誤導"
L["Report who gains Misdirection."] = "報告誰得到誤導"
L["Taunts"] = "嘲諷"
L["Report taunts."] = "報告嘲諷"
L["Interrupts"] = "打斷"
L["Report interrupts."] = "報告打斷"
L["Dispels"] = "驅散"
L["Report dispels and Spellsteal."] = "報告驅散與法術竊取。"
L["Combat Resurrections"] = "戰鬥復活"
L["Report combat resurrections."] = "報告戰鬥復活"

L["Noncombat Alerts"] = "非戰鬥警報"
L["Consumables"] = "消耗品"
L["Report when a player uses a feast or a cauldron."] = "報告當玩家使用盛宴或是大鍋時"
L["Repair Bots"] = "修理機器人"
L["Report when a player uses a repair bot."] = "報告玩家開啟修理機器人"
L["Portals"] = "傳送門"
L["Report when a Mage opens a portal."] = "報告法師開啟一個傳送門"
L["Rituals"] = "儀式(水包.靈魂石.傳送門等)"
L["Report when a player needs assistance summoning an object."] = "報告哪位玩家需要儀式協助"
L["Resurrections"] = "復活"
L["Report resurrections."] = "報告復活"

L["Output"] = "輸出"
L["Set where the alert output is sent."] = "設定哪個警報將會報告"

L["Set where the alert output is sent if not set individually."] = "如果沒有獨立設置，設定警報發送到哪。"
L["Separate Outputs"] = "獨立的輸出"
L["Allow setting the output on a per-alert basis"] = "允許在每個警報的基礎設定輸出"
L["Reset Outputs"] = "重置輸出"
L["Reset all individual alert outputs to use the default output."] = "重置每個獨立警報輸出使用預設輸出。"
L["Enabled Zones"] = "啟用區域"
L["Select the type of zones that have alerts enabled."] = "選擇啟用警報的區域類型。"
L["Enable alerts while in the open world."] = "當在開放世界時啟用警報。"
L["Enable alerts while in a battleground."] = "當在戰場時啟用警報。"
L["Enable alerts while in an arena."] = "當在競技場時啟用警報。"
L["Enable alerts while in a party instance."] = "當在地城副本時啟用警報。"
L["Enable alerts while in a raid instance."] = "當在團隊副本時啟用警報。"
L["Enable alerts while in a looking for group instance."] = "當在尋求組隊副本時啟用警報。"

L["Use Spell Links"] = "使用法術連結"
L["Display spell names as clickable spell links."] = "顯示法術名稱為一個可點擊的法術連結"
L["Use Player Links"] = "使用玩家連結"
L["Display player names as clickable player links."] = "顯示玩家名稱為可點擊的連結。"
L["Use Raid Target Icons"] = "使用團隊目標圖標"
L["Show associated raid target icons as part of the alert."] = "顯示關聯的團隊目標圖示在警報中"
L["Group Only"] = "只有團體"
L["Only report events from players in your group."] = "只有報告在團體中玩家的事件"
L["No Spam in LFG"] = "在尋求團隊中不報告"
L["Don't send alerts to chat in looking for group instances."] = "在尋求團隊副本中不發送警報到聊天中。"
L["Fallback Output to Self"] = "回饋輸出到自身"
L["Print to the chat window if unable to send to the specified output."] = "當無法輸出特定訊息時列印在聊天欄"

L["%s's %s"] = "%s的s %s"
L["%s on %s removed by %s"] = "%s在%s被%s破除"
L["%s on %s removed by %s's %s"] = "%1$s在%2$s被%3$s的%4$s破除"
L["%s used %s"] = "%s使用%s"
L["%s is casting %s"] = "%s正施法在%s"
L["%s cast %s"] = "%s施放%s"
L["%s cast %s on %s"] = "%s施放%s在%s"
L["%s cast %s on %s (%s)"] = "%s施放%s在%s (%s)"
L["%s interrupted %s's %s with %s"] = "%1$s使用%4$s中斷了%2$s的%3$s"
L["Not casting"] = "非施法"


-----------------------------
--Buff Window

L["Buff Window"] = "增益視窗"
L["Opens the buff window (drag the bottom to resize)."] = "開啟增益視窗(拖動下面可以改變大小)。"

L["Limit size"] = "限制大小"
L["Limits the number of rows shown to the number of people in your group (minimum: %d, maximum: %d)."] = "限制在你的隊伍中人員顯示的行數(最小: %d, 最大: %d)"
L["Open on Ready Check"] = "在準備確認時開啟"
L["Open the buff window on a ready check when you're in a non-LFG instance group."] = "除非你在尋求團隊的地城隊伍中，否則在準備確認時開啟增益視窗。"
L["Close on Combat"] = "開始戰鬥後關閉"
L["Close the buff window when entering combat."] = "進入戰鬥後關閉增益視窗。"


-----------------------------
--LDB

L["|cffff8040Left Click|r to toggle the buff window"] = "|cffff8040左鍵點擊|r 掛載BUFF視窗"
L["|cffff8040Shift-Left Click|r to run a buff check"] = "|cffff8040Shift-左鍵點擊|r 運行增益檢查"
L["|cffff8040Right Click|r to open the options window"] = "|cffff8040右鍵點擊|r 打開設置視窗"
L["Hide minimap button"] = "隱藏小地圖按鈕"