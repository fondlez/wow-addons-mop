﻿if not BLTRCD then return end
local BLTRCD = BLTRCD

local cc = {
	DEATHKNIGHT																		=	"|cffC41F3B",
	DRUID																			=	"|cffFF7D0A",
	HUNTER																			=	"|cffABD473",
	MAGE																			=	"|cff69CCF0",
	MONK																			=	"|cff00FF96",
	PALADIN																			=	"|cffF58CBA",
	PRIEST																			=	"|cffFFFFFF",
	ROGUE																			=	"|cffFFF569",
	SHAMAN																			=	"|cff0070DE",
	WARLOCK																			=	"|cff9482C9",
	WARRIOR																			=	"|cffC79C6E",
	BLANK																			=	"|cffffffff",
	ALL																				=	"|cff768ca3",
	DEATHKNIGHT_DRUID_HUNTER_MAGE_MONK_PALADIN_PRIEST_ROGUE_SHAMAN_WARLOCK_WARRIOR	=	"|cff768ca3"
}

function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

function explode(div,str) -- credit: http://richard.warburton.it
  if (div=='') then return false end
  local pos,arr = 0,{}
  -- for each divider found
  for st,sp in function() return string.find(str,div,pos,true) end do
    table.insert(arr,string.sub(str,pos,st-1)) -- Attach chars left of current divider
    pos = sp + 1 -- Jump past current divider
  end
  table.insert(arr,string.sub(str,pos)) -- Attach chars right of last divider
  return arr
end

local currFight
local currFightNb = 1;
local count=0

local function clear()
	BLTRCD_MESSAGE:Clear()
	count=0
end

local function addmsg(msg)
	BLTRCD_MESSAGE:AddMessage(msg)
	count=count+1
end


function GENERAL_CHAT_DISPLAY_CAT(text, type) 
	if BLTRCD and BLTRCD.lastFights and BLTRCD.lastFights[currFightNb] then
		currFight=BLTRCD.lastFights[currFightNb]
		
		BLTRCD_ACTIVE_NAME:SetText("GLOBAL - Fight : "..round(currFight.duration, 2).." sec")
		clear()
		
		for cdname,cd in pairs(BLTRCD.categories[type].cdlist) do
			if next(currFight.categories[type][cdname].roster) then

				tmp = "=== ".. cc[cd.cooldown.class] .. cd.cooldown.class .. cc["BLANK"] .. " ==="
				tmp = tmp ..  " : \124cffffd000\124Hspell:".. cd.cooldown.spellID .."\124h["..cd.cooldown.real_name.."]\124h\124r"
				tmp = tmp .. " - \124cffff0000\124Hreport:"..cd.cooldown.name..":"..cd.cooldown.class..":"..cd.cooldown.real_name..":"..cd.cooldown.spellID.."\124h[Report]\124h\124r"

				addmsg(tmp)
				for name,cdusage in pairs(currFight.categories[type][cdname].roster) do
					addmsg(cc[cd.cooldown.class]..name.." : "..cdusage.value.."/"..cdusage.maxusage..cc["BLANK"])
				end
				addmsg(" ")
			end
		end
		
		if (count <= 30) then
			BLTRCD_SCROLLBAR:SetMinMaxValues(0, 0)
		else
			BLTRCD_SCROLLBAR:SetMinMaxValues(0, count-30)
		end

		BLTRCD_SCROLLBAR:SetValue(1)
		BLTRCD_SCROLLBAR:SetValue(0)
	else
		BLTRCD_ACTIVE_NAME:SetText("GLOBAL - Fight : No Last Fight")
	end
end

function BUTTON_GLOBAL_OnClick()
	if BLTRCD and BLTRCD.lastFights and BLTRCD.lastFights[currFightNb] then
		currFight=BLTRCD.lastFights[currFightNb]
		
		BLTRCD_ACTIVE_NAME:SetText("GLOBAL - Fight : "..round(currFight.duration, 2).." sec")
		clear()
		-- local tmp, tmp2, flag, flag2;
		-- for i,baseclass in pairs(BLTRCD.classes) do
			-- flag2 = 0
			-- for j, cd in ipairs(BLTRCD['cd_helper'][baseclass]) do
				-- flag = 0;
				-- tmp = cc[baseclass] ..baseclass
				-- tmp = tmp .. cc["BLANK"] .. " : \124cffffd000\124Hspell:".. cd[3].spellID .."\124h"..cd[3].real_name.."\124h\124r"
				-- tmp = tmp .. " - \124cffff0000\124Hreport:"..cd[3].name..":"..cd[3].class..":"..cd[3].real_name..":"..cd[3].spellID.."\124h[Report]\124h\124r"
				-- for guid, value in pairs(lastFight[2][cd[3].class][cd[3].name]) do
					-- if (flag < 1) then
						-- BLTRCD_MESSAGE:AddMessage("=== "..tmp.." ===")
						-- count = count + 1;
						-- flag = 1;
						-- flag2 = 1;
					-- end
					-- BLTRCD_MESSAGE:AddMessage("   ".. cc[baseclass] .. value)
					-- count = count + 1;
				-- end
				-- if (flag >= 1) then
					-- BLTRCD_MESSAGE:AddMessage(" ")
					-- count = count + 1
				-- end
			-- end
				-- if (flag2 >= 1) then
					-- BLTRCD_MESSAGE:AddMessage(" ")
					-- count = count + 1
				-- end
		-- end
		
		for catname,cat in pairs(BLTRCD.categories) do
			for cdname,cd in pairs(cat.cdlist) do
				if next(currFight.categories[catname][cdname].roster) then
					tmp = "=== ".. cc[cd.cooldown.class] .. cd.cooldown.class .. cc["BLANK"] .. " ==="
					tmp = tmp ..  " : \124cffffd000\124Hspell:".. cd.cooldown.spellID .."\124h["..cd.cooldown.real_name.."]\124h\124r"
					tmp = tmp .. " - \124cffff0000\124Hreport:"..cd.cooldown.name..":"..cd.cooldown.class..":"..cd.cooldown.real_name..":"..cd.cooldown.spellID.."\124h[Report]\124h\124r"
					addmsg(tmp)
					for name,cdusage in pairs(currFight.categories[catname][cdname].roster) do
						addmsg(cc[cd.cooldown.class]..name.." : "..cdusage.value.."/"..cdusage.maxusage..cc["BLANK"])
					end
					addmsg(" ")
				end
			end
			--addmsg(" ")
		end

		if (count <= 30) then
			BLTRCD_SCROLLBAR:SetMinMaxValues(0, 0)
		else
			BLTRCD_SCROLLBAR:SetMinMaxValues(0, count-30)
		end
		BLTRCD_SCROLLBAR:SetValue(1)
		BLTRCD_SCROLLBAR:SetValue(0)
	else
		BLTRCD_ACTIVE_NAME:SetText("GLOBAL - Fight : No Last Fight")
	end
end

function BUTTON_AOE_HEAL_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("AOE_HEAL", "AOE_HEAL")
end

function BUTTON_SINGLE_HEAL_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("SINGLE_HEAL", "SINGLE_HEAL")
end

function BUTTON_MANA_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("MANA_REGEN", "MANA_REGEN")
end

function BUTTON_DPS_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("DPS", "AOE_DPS")
end	

function BUTTON_REZ_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("REZ", "REZ")
end

function BUTTON_DEFENSIVE_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("DEFENSIVE", "DEFENSIVE")
end

function BUTTON_MISC_OnClick()
	GENERAL_CHAT_DISPLAY_CAT("MISC", "MISC")
end

function BLTRCD_MESSAGE_OnLoad()
	BLTRCD_MESSAGE:SetHyperlinksEnabled(true)
	BLTRCD_MESSAGE:SetScript("OnHyperlinkClick", function(self,link,text,button) 
		local tmp;
		tmp = explode(':', link)
		if (tmp[1] == "spell") then
			SetItemRef(link,text,button) 
		else
			for _,cat in pairs(BLTRCD.categories) do
				for _,cd in pairs(cat.cdlist) do
					if cd.cooldown.name == tmp[2] then
						BLTRCD.ReportUsageCD(currFight, cd)
					end
				end
			end
		end
	end)
	BLTRCD_MESSAGE:SetJustifyH("LEFT")
end	

function BLTRCD_SCROLLBAR_OnLoad()
	BLTRCD_SCROLLBAR:SetMinMaxValues(0, 45)
	BLTRCD_SCROLLBAR:SetValueStep(1)
	BLTRCD_SCROLLBAR.scrollStep = 1

	BLTRCD_SCROLLBAR:SetScript("OnValueChanged", function(self, value)
		BLTRCD_MESSAGE:SetScrollOffset(select(2, BLTRCD_SCROLLBAR:GetMinMaxValues()) - value)
	end)


	BLTRCD_SCROLLBAR:SetValue(0)

end	

function BLTRCD_DISPLAY_OnMouseWheel(self, delta)
	local cur_val = BLTRCD_SCROLLBAR:GetValue()
	local min_val, max_val = BLTRCD_SCROLLBAR:GetMinMaxValues()

	if delta < 0 and cur_val < max_val then
		cur_val = math.min(max_val, cur_val + 1)
		BLTRCD_SCROLLBAR:SetValue(cur_val)
	elseif delta > 0 and cur_val > min_val then
		cur_val = math.max(min_val, cur_val - 1)
		BLTRCD_SCROLLBAR:SetValue(cur_val)
	end
end

function BLTRCD_ENGAGE_OnClick()
	BLTRCD.ReinitCDUsage()
	BLTRCD.bossfight=true
	BLTRCD.pullTime=GetTime()
end

function BLTRCD_DISENGAGE_OnClick()
	BLTRCD.bossfight=false
	BLTRCD.snapshotCDusage()
	BLTRCD.resetlongCD()
	currFightNb = 1;
	UIDropDownMenu_Initialize(BUTTON_FIGHT, BLTRCD.BUTTON_FIGHT_OnLoad);
	BUTTON_GLOBAL_OnClick()
end

function tprint (tbl, indent)
  if not indent then indent = 0 end
  for k, v in pairs(tbl) do
    formatting = string.rep("  ", indent) .. k .. ": "
    if type(v) == "table" then
      print(formatting)
      tprint(v, indent+1)
    else
      print(formatting .. v)
    end
  end	
end

function BLTRCD_MESSAGE_OnShow()
	BUTTON_GLOBAL_OnClick()
end

local function OnClick(self)
	 UIDropDownMenu_SetSelectedID(BUTTON_FIGHT, self:GetID())
	currFightNb = self.value;
	BUTTON_GLOBAL_OnClick()
end

function BLTRCD:BUTTON_FIGHT_OnLoad()
	local info = UIDropDownMenu_CreateInfo()
	local i = 1;
	if BLTRCD and BLTRCD.lastFights[1] ~= nil then
		for k,v in pairs(BLTRCD.lastFights) do
			info = UIDropDownMenu_CreateInfo()
			info.text = "Fight #"..i.." - "..  tostring(round(v.duration,2)) .. "s"
			info.value = i
			info.func = OnClick
		    UIDropDownMenu_AddButton(info);
			i = i+1;
		end
	else
		info = UIDropDownMenu_CreateInfo()
		info.text = "No Last Fight"
		info.value = 1
		info.func = OnClick
		UIDropDownMenu_AddButton(info);
	end
  
	 UIDropDownMenu_SetSelectedID(BUTTON_FIGHT, currFightNb);
end

function BUTTON_FIGHT_OnClick()
    ToggleDropDownMenu(1, nil, BUTTON_FIGHT, BUTTON_FIGHT, 0, 0);
end