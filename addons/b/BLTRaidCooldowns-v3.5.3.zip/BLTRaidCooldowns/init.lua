local name = "BLTRaidCooldown"
BLTRCD = LibStub("AceAddon-3.0"):NewAddon(name, "AceEvent-3.0", "AceConsole-3.0", "AceTimer-3.0")
if not BLTRCD then return end

local frame = BLTRCD.frame
if (not frame) then
	frame = CreateFrame("Frame", name .. "_Frame", UIParent)
	BLTRCD.frame = frame
end
BLTRCD.frame:UnregisterAllEvents()