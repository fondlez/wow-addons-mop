if not BLTRCD then return end
local BLTRCD = BLTRCD
local DEFAULT_WIDTH = 800;
local DEFAULT_HEIGHT = 600;
local AceConfig = LibStub("AceConfig-3.0") -- For the options panel
local AceConfigDialog = LibStub("AceConfigDialog-3.0") -- Also for options panel
local AceDBOptions = LibStub("AceDBOptions-3.0") -- More database options
local LDB = LibStub("LibDataBroker-1.1")
local LDBIcon = LDB and LibStub("LibDBIcon-1.0")

local LDBlauncher = LDB:NewDataObject("BLTRCD", {
	type = "launcher",
	icon = "Interface\\Icons\\Ability_deathwing_assualtaspects",
	OnClick = function(clickedframe, button)
		if button == "RightButton" then
			BLTRCD:InitOptions()
		else
			if BLTRCD_MAIN:IsVisible() then
				BLTRCD_MAIN:Hide()
			else
				BLTRCD_MAIN:Show()
			end
		end
	end,
	OnTooltipShow = function(tt)
		tt:AddLine("|cffffff00" .. "Click|r to toggle the BLTRCD window")
		tt:AddLine("|cffffff00" .. "Right-click|r to open the options menu")
	end,
})
 
BLTRCD.defaults = {
	profile = {
		saveFight = 10,
		startCDannounce = "no",
		stopCDannounce = "no",
		readyCDannounce = "no",
		clickCDannounce = "raid",
		show = "raid",
		ELVUI_SKIN = true,
		filteradditionalpeople = false,
		d_enabled = true,
		b_enabled = true,
		readymode = true,
		minimap = {
			hide = false,
		},
		display = {
			scale = 1,
			activeX = 200,
			activeY = 16,
			nbActiveCD = 5,
			nbbar = 2,
			growth = "RIGHT",
			backdropcolor = true,
			baricon = true,
			catSorting = "class",
			category = {
				AOE_HEAL =  {
					enabled = true,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
					growth = "inherit",					
				},
				SINGLE_HEAL =  {
					enabled = true,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
			 		growth = "inherit",
				},
				AOE_DPS =  {
					enabled = true,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
					growth = "inherit",
				},
				REZ =  {
					enabled = true,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
					growth = "inherit",
				},
				MANA_REGEN =  {
					enabled = true,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
					growth = "inherit",
				},
				MISC =  {
					enabled = true,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
					growth = "inherit",
				},
				DEFENSIVE =  {
					enabled = false,
					d_enabled = "inherit",
					b_enabled = "inherit",
					startCDannounce = "inherit",
					stopCDannounce = "inherit",
					readyCDannounce = "inherit",
					readymode = "inherit",
					catSorting = "inherit",
					growth = "inherit",
				},
			},
		},
		cooldowns = BLTRCD.cooldowns,
		category = { },
	},
}
 
BLTRCD.options =  {
	type = "group",
	name = "BLT RaidCooldowns",
	args = {
        BLTRCD_Header = {
			order = 1,
			type = "header",
			name = "Version: |cff99ff33 3.0 |r",
			width = "full",        
        },
        general = {
			order = 1,
			type = "group",
			name = "General Settings",
			cmdInline = true,
			get = function(info, value)
				return BLTRCD.db.profile[info[3]]
			end,
			set = function(info, value)
				BLTRCD.db.profile[info[3]] = value
			end,
        },
        cooldowns = {
			order = 2,
			type = "group",
			name = "Cooldown Settings",
			get = function(info, value)
				local key = select(2, strsplit(':', info[3]))
				if info[4] == nil then
					return BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))].enabled
				else
					if type(BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))][info[4]]) == "number" then
						return  string.format("%d", BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))][info[4]])
					else
						return  BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))][info[4]]
					end
				end
            end,
            set = function(info, value)
				if info[4] == nil then
					BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))].enabled = value
				else
					if type(BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))][info[4]]) == "number" then
						BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))][info[4]] = tonumber(value)
					else
						BLTRCD.db.profile.cooldowns[tonumber(select(2, strsplit(':', info[3])))][info[4]] = value
					end
				end
				BLTRCD.DisplayCD()
            end,
		},
        category = {
            order = 4,
            type = "group",
            name = "Category Settings",
            get = function(info, value)
				if info[#info-1] == "category" then
					return BLTRCD.db.profile.display.category[info[#info]].enabled
				else
					return BLTRCD.db.profile.display.category[select(2, strsplit(':', info[#info-1]))][info[#info]]
				end
			end,
			set = function(info, value)
				if info[#info-1]  == "category" then
					BLTRCD.db.profile.display.category[info[#info]].enabled = value
				else
					BLTRCD.db.profile.display.category[select(2, strsplit(':', info[#info-1]))][info[#info]] = value
				end
				BLTRCD.DisplayCD()
			end,
        },
        create = {
                order = 4,
                type = "group",
                name = "Create Category/Cooldown",
                cmdInline = true,
        },
	},
}
 
function BLTRCD:BuildApplyExecute(group)
	group['cfg'] = {
		type = "execute",
		name = "Apply Changes",
		desc = "Apply the changes to the active cooldowns and reload the UI.",
		func = function()
			BLTRCD.DisplayCD()
			--ReloadUI()
		end,
		order = 1,
		width = "full",
	}
end
 
function BLTRCD:selectAnnounce(root)
	local opt = {}
	opt['no'] = 'no';
	opt['self'] = 'self';
	opt['say'] = 'say';
	opt['yell'] = 'yell';
	opt['raid'] = 'raid';
	opt['rw'] = 'raid warning';
	if root ~= 0 then
		opt['inherit'] = 'inherit';
	end
	return opt
end
 
local function BuildConfig()
	BLTRCD:BuildGeneral()
	BLTRCD:BuildCooldown()
	BLTRCD:BuildCategory()
	BLTRCD:BuildCreate()
end
 
local init = 0
function BLTRCD.InitOptions()
	if init == 0 then
		init = 1
		BuildConfig()
	end
	AceConfigDialog:Open("BLTRCD")
end
 
function BLTRCD.ShowMMIcon(value) 
	if value then LDBIcon:Show("BLTRCD") else LDBIcon:Hide("BLTRCD") end
end

function BLTRCD.SetupOptions()
	BLTRCD.options.args.profile = AceDBOptions:GetOptionsTable(BLTRCD.db)
	AceConfig:RegisterOptionsTable("BLTRCD", BLTRCD.options)
	AceConfigDialog:SetDefaultSize("BLTRCD", DEFAULT_WIDTH, DEFAULT_HEIGHT)
	LDBIcon:Register("BLTRCD", LDBlauncher, BLTRCD.db.profile.minimap)
end