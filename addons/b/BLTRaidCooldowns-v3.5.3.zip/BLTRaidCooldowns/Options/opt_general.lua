﻿if not BLTRCD then return end
local BLTRCD = BLTRCD

function BLTRCD:BuildGeneral()
BLTRCD.options.args.general.args = {
	configure = {
		order = 1,
		type = "execute",
		name = "Apply Changes",
		desc = "Apply the changes to the active cooldowns and reload the UI.",
		func = function()
				--BLTRCD.DisplayCD()
				ReloadUI()
		end,
		width = "full",
	},
	announceGroup = {
		order = 2,
		type = 'group',
		guiInline = true,
		name = "Announce",
		args = {
			startCDannounce = {
				type = "select",
				name = "Announce Casts",
				desc = "Ex: Alogon [Rallying Cry] START",
				order = 2,
				values = BLTRCD:selectAnnounce(0),
			},
			stopCDannounce = {
				type = "select",
				name = "Announce end casts",
				desc = "Ex: Alogon [Rallying Cry] END",
				order = 2,
				values = BLTRCD:selectAnnounce(0),
			},
			readyCDannounce = {
				type = "select",
				name = "Announce CD ready",
				desc = "Ex: Alogon [Rallying Cry] READY",
				order = 2,
				values = BLTRCD:selectAnnounce(0),
			},
			clickCDannounce = {
				type = "select",
				name = "Click to announce available",
				order = 2,
				values = BLTRCD:selectAnnounce(0),
			},
		},
	},
	bar_opt = {
		order = 3,
		type = 'group',
		guiInline = true,
		name = "Bar",
		get = function(info, value)
						return BLTRCD.db.profile.display[info[3]]
		end,
		set = function(info, value)
						BLTRCD.db.profile.display[info[3]] = value
						BLTRCD.DisplayCD()
		end,
		args = {
			scale = {
				order = 12,
				type = "range",
				name = 'Set Scale',
				desc = "Sets Scale of Raid Cooldowns",
				min = 0.3, max = 2, step = 0.01,
				set = function(info, value)
					BLTRCD.db.profile.display.scale = value;
					BLTRCD.DisplayCD()
				end,
			},
			activeX = {
				order = 13,
				type = "range",
				name = 'ActiveCD width',
				desc = "Set activeCD width",
				min = 50, max = 500, step = 1,
				set = function(info, value)
					BLTRCD.db.profile.display.activeX = value;
					BLTRCD.DisplayCD();
				end,
			},
			activeY = {
				order = 14,
				type = "range",
				name = 'ActiveCD height',
				desc = "Set activeCD height",
				min = 8, max = 96, step = 1,
				set = function(info, value)
					BLTRCD.db.profile.display.activeY = value;
					BLTRCD.DisplayCD();
				end,
			},
			nbActiveCD = {
				order = 15,
				type = "range",
				name = 'Max Active cd',
				desc = "Set max number of active cd",
				min = 0, max = 24, step = 1,
				set = function(info, value)
					BLTRCD.db.profile.display.nbActiveCD = value;
					BLTRCD.RearrangeActiveCD();
				end,
			},
			nbbar = {
				order = 16,
				type = "range",
				name = 'Max bar per cd',
				desc = "Set max number of bars per cd",
				min = 1, max = 10, step = 1,
				set = function(info, value)
					BLTRCD.db.profile.display.nbbar = value;
					BLTRCD.DisplayCD();
				end,
			},
			growth = {
				order = 17,
				name = "Bar Grow Direction",
				type = 'select',
				values = {
					['LEFT'] = "Left",
					['RIGHT'] = "Right",
				}, 
			},
			catSorting = {
				order = 18,
				name = "Category Sorting",
				type = "select",
				values = {
					['class'] = "class",
					['name'] = "name",
					['cooldown'] = "cooldown",
				},
			},
			backdropcolor = {
				type = "toggle",
				name = "Class color",
				order = 19,
			},
			baricon = {
				type = "toggle",
				name = "Icon on active bars",
				order = 20,
			},				
		},
	},
	otherGroup = {
		order = 3,
		type = 'group',
		guiInline = true,
		name = "Misc",
		args = {
			filteradditionalpeople = {
				type = "toggle",
				name = "Raid-10/Raid-25 Filter",
				desc = "Filter spare members (only show grp1-2 in 10man, grp1-5 in 25)",
				order = 1,
			},
			readymode = {
				type = "toggle",
				name = "Ready mode",
				desc = "Always show bars, putting READY on them when the CD is up",
				order = 2,
			},
			ELVUI_SKIN = {
				type = "toggle",
				name = "ElvUI Skin",
				desc = "ElvUI Skin for Report Frame",
				order = 3,
			},
			show = {
				order = 4,
				name = "Show",
				type = "select",
				get = function()
					return BLTRCD.db.profile.show
				end,
				set = function(info, value)
					BLTRCD.db.profile.show = value
					BLTRCD.DisplayFrame()
				end,
				values = {
					['none'] = "Never",
					['raid'] = "Raid/Party",
					['always'] = "Always",
				},
			},
			minimap = {
				type = "toggle",
				name = "Hide/Show minimap icon",
				desc = "Hide/Show minimap icon",
				order = 5,
				get = function()
					return not BLTRCD.db.profile.minimap.hide
				end,
				set = function(key, value)
					BLTRCD.db.profile.minimap.hide = not value
					if value then BLTRCD.ShowMMIcon(true) else BLTRCD.ShowMMIcon(false) end
				end,
			},
			saveFight = {
				type = "range",
				name = "Fight save",
				desc = "Number of fight saved",
				order = 6,
				min = 1,
				max = 20,
				softMin = 1,
				softMax = 20,
				step = 1,
				bigStep = 1,
			},
		},
	},
}
end