﻿if not BLTRCD then return end
local BLTRCD = BLTRCD

function BuildCategorySimple(group)
	group['category_mass'] = {
		order = 2,
		name = "Display Category",
		type = "header",
	}
	for category,value in pairs(BLTRCD.db.profile.display.category) do
		group[category] = {
			name = category,
			order = 3,
			type = "toggle",
			desc = "Enable/Disable "..category.." category",
		}
	end
end

function BuildCategoryAdvanced(group)
    for category,value in pairs(BLTRCD.db.profile.display.category) do
		group['CATEGORY:'..category] = {
			type = "group",
			name = category,
			order = 3,
			args = {
				enabled = {
					type = "toggle",
					order = 1,
					name = "Enabled",
				},
				d_enabled = {
					type = "select",
					order = 2,
					name = "Duration Enabled",
					values = {
						['yes'] = 'yes',
						['no'] = 'no',
						['inherit'] = 'inherit',
					},
				},
				b_enabled = {
					type = "select",
					order = 3,
					name = "Bar Enabled",
					values = {
						['yes'] = 'yes',
						['no'] = 'no',
						['inherit'] = 'inherit',
					},
				},
				startCDannounce = {
					type = "select",
					order = 4,
					name = "Announce Cast",
					desc = "Ex: Alogon [Rallying Cry] START",
					values = BLTRCD:selectAnnounce(),
				},
				stopCDannounce = {
					type = "select",
					order = 4,
					name = "Announce End Cast",
					desc = "Ex: Alogon [Rallying Cry] END",
					values = BLTRCD:selectAnnounce(),
				},
				readyCDannounce = {
					type = "select",
					order = 4,
					name = "Announce Cooldown Ready",
					desc = "Ex: Alogon [Rallying Cry] READY",
					values = BLTRCD:selectAnnounce(),
				},
				catSorting = {
					order = 17,
					name = "Sort by",
					type = "select",
					values = {
						['inherit'] = "inherit",
						['class'] = "class",
						['name'] = "name",
						['cooldown'] = "cooldown",
					},
				},
				growth = {
					type = "select",
					order = 18,
					name = "Bar direction",
					values = {
						['LEFT'] = 'LEFT',
						['RIGHT'] = 'RIGHT',
						['inherit'] = 'inherit',
					},
				},
				readymode = {
					order = 19,
					name = "Ready mode",
					type = "select",
					values = {
						['inherit'] = "inherit",
						['yes'] = "yes",
						['no'] = "no",
					},
				},				
			},
		}
    end
end

function BLTRCD:BuildCategory(group)
	local group;
	BLTRCD.options.args.category.args = { }
 
	group = BLTRCD.options.args.category.args
	BLTRCD:BuildApplyExecute(group)

	BuildCategorySimple(group)
	BuildCategoryAdvanced(group)
end