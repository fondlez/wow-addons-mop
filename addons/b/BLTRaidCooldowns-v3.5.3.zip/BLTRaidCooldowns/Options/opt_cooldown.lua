﻿if not BLTRCD then return end
local BLTRCD = BLTRCD

local function checkClass(info, value)
	for key,cd in pairs(BLTRCD.db.profile.cooldowns) do
		if cd.class == info[#info] then
			if cd.enabled == true then
				return true
			end
		end
	end
	return false
end

local function setClass(info, value)
	for key,cd in pairs(BLTRCD.db.profile.cooldowns) do
		if cd.class == info[#info] then
			cd.enabled = value
			BLTRCD.DisplayCD()
		end
	end
end

local function BuildClassCheck(group)
    local i = 0;
	group['mass_enabled'] = {
		order = 2,
		name = "Display Class",
		type = "header",
	}
    for key,class in pairs(BLTRCD.classes) do
        group[class] = {
			order = 3,
			name = class,
			type = "toggle",
			desc = "Enable/Disable "..class.." cooldowns",
			get = checkClass,
			set = setClass,
        }
    end
end

local function BuildClass(group)
	local i = 0;
	for key,value in pairs(BLTRCD.classes) do
		group['group_'..value] = {
			order = i,
			name = value,
			type = "group",
			args = { },
		}
		i = i+1;
	end
end
 
function BLTRCD:BuildClassSpell(group_cd, key2, cd)
	group_cd[cd.class..'_'..cd.name..':'..key2] = {
		type = "toggle",
		name = cd.real_name,
		order = 10,
		desc =  GetSpellDescription(cd.spellID),
	}
end
 
function BLTRCD:BuildClassSpellAdvanced(group_cd, key2, cd)
    group_cd[cd.class..'_'..cd.name..'_cfg:'..key2] = {
        type = "group",
        order = 1,
        name = cd.real_name,
        args = {
            DISPLAY_MSG = {
                order = 2,
                type = "header",
                name = "Advanced Configuration",
            },
            enabled = {
                type = "toggle",
                name = "Enabled",
                order = 3,
            },
            d_enabled = {
                type = "select",
                name = "Duration Enabled",
                order = 4,
                values = {
					['yes'] = 'yes',
					['no'] = 'no',
					['inherit'] = 'inherit',
				},
            },
            b_enabled = {
                type = "select",
                name = "Bar Enabled",
                order = 5,
                values = {
					['yes'] = 'yes',
					['no'] = 'no',
					['inherit'] = 'inherit',
				},
            },
			startCDannounce = {
				type = "select",
				order = 4,
				name = "Announce Cast",
				values = BLTRCD:selectAnnounce(),
			},
			stopCDannounce = {
				type = "select",
				order = 4,
				name = "Announce End Cast",
				values = BLTRCD:selectAnnounce(),
			},
			readyCDannounce = {
				type = "select",
				order = 4,
				name = "Announce Cooldown Ready",
				values = BLTRCD:selectAnnounce(),
			},
			readymode = {
				order = 5,
				name = "Ready mode",
				type = "select",
				values = {
					['inherit'] = "inherit",
					['yes'] = "yes",
					['no'] = "no",
				},
			},
            spellID = {
                order = 6,
                name = "Spell ID",
                type = "input",
            },
            real_name = {
                order = 7,
                name = "Spell Name",
                type = "input",
            },
            CD = {
                order = 8,
                name = "Spell Cooldown",
                type = "input",
            },
            duration = {
                order = 9,
                name = "Duration",
                type = "input",
            },
            class = {
                order = 10,
                name = "Class",
                type = "select",
                values = function()
                    local spellClass = {}
                    for key,class in pairs(BLTRCD.classes) do
                        spellClass[class] = class
                    end
                    return spellClass
                end,
            },
            category = {
                order = 11,
                name = "Category",
                type = "select",
                values = function()
                    local spellCategory = {}
                    for key,category in pairs(BLTRCD.db.profile.display.category) do
                            spellCategory[key] = key
                    end
                    return spellCategory
                end,
            },
			delete = {
				order = 12,
				name = "Delete cooldown",
				type = "execute",
				width = "full",
				func = function()
					BLTRCD:DoDeleteCooldown(nil, cd.spellID)
				end,
			},
        },
    }
end

function BLTRCD:BuildCooldown()
    local group;
    BLTRCD.options.args.cooldowns.args = { }
 
    group = BLTRCD.options.args.cooldowns.args
    BLTRCD:BuildApplyExecute(group)
 
	BuildClassCheck(group)
    BuildClass(group)
 
    local group_cd;
    local class = ""
    for key2,cd in pairs(BLTRCD.db.profile.cooldowns) do
        group_cd = BLTRCD.options.args.cooldowns.args['group_'..cd.class].args;
        BLTRCD:BuildApplyExecute(group_cd)
        if string.find(class, cd.class) == nil then
            group_cd["MSG_DISPLAY"] = {
                order = 1,
                type = "header",
                name = "Display Cooldowns",
            }
            class = class..":"..cd.class
        end
        BLTRCD:BuildClassSpellAdvanced(group_cd, key2, cd)
        BLTRCD:BuildApplyExecute(group_cd[cd.class..'_'..cd.name..'_cfg:'..key2].args)
        BLTRCD:BuildClassSpell(group_cd, key2, cd)
    end
end