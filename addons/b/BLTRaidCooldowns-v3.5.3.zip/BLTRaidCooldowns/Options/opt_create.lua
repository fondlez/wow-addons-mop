﻿if not BLTRCD then return end
local BLTRCD = BLTRCD

local create_cooldown = {
    enabled = true,
    d_enabled = "inherit",
    b_enabled = "inherit",
	startCDannounce = "inherit",
	stopCDannounce = "inherit",
	readyCDannounce = "inherit",
    spellID = 31821,
    name = "",
    real_name = "Devotion Aura",
    succ = "SPELL_CAST_SUCCESS",
    CD = 180,
    class = "PALADIN",
    category = "AOE_HEAL",
    duration = 10,
	growth = "inherit",
	spec = -1,
}

local class_spec = {
	ALL = {
	
	},
	DEATHKNIGHT = {
		Blood = "250",
		Frost = "251",
		Unholy = "252",
	},
	DRUID = {
		Balance = "102",
		Feral = "103",
		Guardian = "104",
		Restoration = "105",
	},
	HUNTER = {
		Beastmaster = "253",
		Marksman = "254",
		Survival = "255",
	},
	MAGE = {
		Arcane = "62",
		Fire = "63",
		Frost = "64",
	},
	MONK = {
		Brewmaster = "268",
		Windwalker = "269",
		Mistweaver = "270",
	},
	PALADIN = {
		Holy = "65",
		Protection = "66",
		Retribution = "70",
	},
	PRIEST = {
		Discipline = "256",
		Holy = "257",
		Shadow = "258",
	},
	ROGUE = {
		Assassionation = "259",
		Combat = "260",
		Subtlety = "261",
	},
	SHAMAN = {
		Elemental = "262",
		Enhancement = "263",
		Restoration = "264",
	},
	WARLOCK = {
		Affliction = "265",
		Demonology = "266",
		Destruction = "267",
	},
	WARRIOR = {
		Arms = "71",
		Fury = "72",
		Protection = "73",
	},
}

local function UpdateCategory(cmd, category)
	group = BLTRCD.options.args.category.args
	if cmd == "add" then
		group[category] = {
			name = category,
			order = 3,
			type = "toggle",
			desc = "Enable/Disable "..category.." category",
		}
		group['CATEGORY:'..category] = {
			type = "group",
			name = category,
			order = 3,
			args = {
				enabled = {
					type = "toggle",
					order = 1,
					name = "Enabled",
				},
				d_enabled = {
					type = "select",
					order = 2,
					name = "Duration Enabled",
					values = BLTRCD:selectAnnounce(),
				},
				b_enabled = {
					type = "select",
					order = 3,
					name = "Bar Enabled",
					values = BLTRCD:selectAnnounce(),
				},
				startCDannounce = {
					type = "select",
					order = 4,
					name = "Announce Cast",
					desc = "Ex: Alogon [Rallying Cry] START",
					values = BLTRCD:selectAnnounce(),
				},
				stopCDannounce = {
					type = "select",
					order = 4,
					name = "Announce End Cast",
					desc = "Ex: Alogon [Rallying Cry] END",
					values = BLTRCD:selectAnnounce(),
				},
				readyCDannounce = {
					type = "select",
					order = 4,
					name = "Announce Cooldown Ready",
					desc = "Ex: Alogon [Rallying Cry] READY",
					values = BLTRCD:selectAnnounce(),
				},
			},
		}
	else
		group[category] = nil
		group['CATEGORY:'..category] = nil
	end
end

local function BuildCreateCategory()
	BLTRCD.options.args.create.args.category.args = {
		NEW_CATEGORY = {
			order = 2,
			name = "Create Category",
			type = "input",
			get = function()
					return ""
			end,
			confirm = function()
				return "Do you really want to create this category ?"
			end,
			set = function(key, value)
				if value == nil or value == "" then
					print("[Create] Error: Category name is empty")
					return nil
				end
				if BLTRCD.db.profile.display.category[value] then
					print("A category with that name already exist.")
				else
					BLTRCD.db.profile.display.category[value]  = {
						enabled = true,
						d_enabled = "inherit",
						b_enabled = "inherit",
						startCDannounce = "inherit",
						stopCDannounce = "inherit",
						readyCDannounce = "inherit",
						}
						UpdateCategory("add", value)
						print("Category created")
				end
			end,
		},
		DELETE_CATEGORY = {
			order = 2,
			name = "Delete Category",
			type = "input",
			confirm = function()
				return "Do you really want to delete this category ?"
			end,
			get = function()
				return ""
			end,
			set = function(key, value)
				local f = 0
				if value == nil or value == "" then
					print("[Delete] Error: Category name is empty")
					return nil
				end
				if BLTRCD.defaults.profile.display.category[value] then
					print("You can't remove default category.")
				else
					for key,cd in pairs(BLTRCD.db.profile.cooldowns) do
						if cd.category == value then
							if f == 0 then
								print("You can't remove this category because you have this cooldown(s) associate : ");
							end
							print('spellID: '..cd.spellID..' - spellName: '..cd.real_name..' - class: '..cd.class..' - category: '..cd.category)
							f = f + 1
						end
					end
					if f > 0 then
						return nil
					end
					BLTRCD.db.profile.display.category[value]= nil
					UpdateCategory("del", value)
					print("Category deleted")
				end
			end,  
		},
	}
end
 
function BLTRCD:DoDeleteCooldown(info, value)
	for key,cd in pairs(BLTRCD.db.profile.cooldowns) do
		if tonumber(value) == tonumber(cd.spellID) then
			if BLTRCD.defaults.profile.cooldowns[key] then
				print("You can't remove default cooldown.")
				return
			else
				BLTRCD.options.args.cooldowns.args['group_'..cd.class].args[cd.class..'_'..cd.name..':'..key] = {  }
				BLTRCD.options.args.cooldowns.args['group_'..cd.class].args[cd.class..'_'..cd.name..'_cfg:'..key] =  { }
				BLTRCD.db.profile.cooldowns[key] = nil
				print("Cooldown deleted")
			end
			return
		end
	end
end
 
local function BuildDeleteCooldown()
	BLTRCD.options.args.create.args.d_cooldown.args = {
		DELETE_COOLDOWN = {
			order = 1,
			name = "Delete Cooldown",
			desc = "spellID of the cooldown",
			type = "input",
			confirm = function()
				return "Do you really want to delete this cooldown ?"
			end,
			get = function()
				return ""
			end,
			set = function(info, value)
				if value == nil or value == "" then
					print("[Delete] Error: Spell ID is empty")			
					return nil
				end
				BLTRCD:DoDeleteCooldown(info, value)
			end,
		}
	}
end
 
local function deepcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end
 
local function DoCreateCooldown()
	local i = 1
	for key,value in pairs(BLTRCD.db.profile.cooldowns) do
		if tonumber(create_cooldown.spellID) == value.spellID then
			print('This cooldown already exists. spellID: '..value.spellID..' - spellName: '..value.real_name..' - class: '..value.class..' - category: '..value.category)
			return
		end
		i = i+1;
	end
	local tmp
	tmp = deepcopy(create_cooldown)
	if tmp.spec == -1 then
        tmp.spec = nil
    end
	tinsert(BLTRCD.db.profile.cooldowns, tmp)
	for key,value in pairs(BLTRCD.db.profile.cooldowns) do
		if value.spellID == create_cooldown.spellID then
			BLTRCD:BuildClassSpell(BLTRCD.options.args.cooldowns.args['group_'..create_cooldown.class].args, key, create_cooldown)
			BLTRCD:BuildClassSpellAdvanced(BLTRCD.options.args.cooldowns.args['group_'..create_cooldown.class].args, key, create_cooldown)
			BLTRCD:BuildApplyExecute(BLTRCD.options.args.cooldowns.args['group_'..create_cooldown.class].args[create_cooldown.class..'_'..create_cooldown.name..'_cfg:'..key].args)
			print('Cooldown created');
		end
	end
end
 
local function BuildCreateCooldown()
	BLTRCD.options.args.create.args.c_cooldown.args = {
		enabled = {
			type = "toggle",
			name = "Enabled",
			order = 1,
		},
		spellID = {
			order = 4,
			name = "Spell ID",
			type = "input",
			set = function(info, value)
				local name, _ = GetSpellInfo(value)
				create_cooldown.spellID = tonumber(value)
				create_cooldown.real_name = name
			end,
		},
		real_name = {
			order = 5,
			name = "Spell Name",
			type = "input",
		},
		CD = {
			order = 6,
			name = "Spell Cooldown",
			type = "input",
		},
		duration = {
			order = 7,
			name = "Spell Duration",
			type = "input",
		},
		class = {
			order = 8,
			name = "Class",
			type = "select",
			values = function()
				local spellClass = {}
				for key,class in pairs(BLTRCD.classes) do
					spellClass[class] = class
				end
				return spellClass
			end,
		},
		spec = {
			order = 9,
			name = "Spec",
			type = "select",
			values = function()
				local spellClassCat = {}
				spellClassCat['-1'] = "All"
				for key,value in pairs(class_spec[create_cooldown.class]) do
					spellClassCat[value] = key
				end
				return spellClassCat
			end,
		},
		category = {
			order = 10,
			name = "Category",
			type = "select",
			values = function()
				local spellCategory = {}
				for key,category in pairs(BLTRCD.db.profile.display.category) do
					spellCategory[key] = key
				end
				return spellCategory
			end,
		},
		create = {
			order = 10,
			type = "execute",
			name = "Create Cooldown",
			width = "full",
			func = function()
				if create_cooldown.spellID == nil or create_cooldown.spellID == "" then
					print("[Create] Error: Spell ID is empty")
					return nil
				elseif create_cooldown.real_name == nil or create_cooldown.real_name == "" then
					print("[Create] Error: Spell Name is empty")
					return nil
				elseif create_cooldown.CD == nil or create_cooldown.CD == "" then
					print("[Create] Error: Spell Cooldown is empty")
					return nil
				elseif create_cooldown.duration == nil or create_cooldown.duration == "" then
					print("[Create] Error: Spell Duration is empty")
					return nil
				end
				DoCreateCooldown()
			end,
		},
	}
end
 
function BLTRCD:BuildCreate()  
    local group;
 
    BLTRCD.options.args.create.args = {
		category = {
			order = 2,
			type = "group",
			guiInline = true,
			name = "Category",
			args = {},
		},
		c_cooldown = {
			order = 3,
			type = "group",
			guiInline = true,
			name = "Create Cooldown",
			get = function(info, value)
				if type(create_cooldown[info[3]]) == "number" then
					return string.format("%d", create_cooldown[info[3]])
				else
					return create_cooldown[info[3]]
				end
			end,
			set = function(info, value)
				if type(create_cooldown[info[3]]) == "number" then
					create_cooldown[info[3]] = tonumber(value)
				else
					create_cooldown[info[3]] = value                      
				end
			end,
		},
		d_cooldown = {
			order = 3,
			type = "group",
			guiInline = true,
			name = "Delete Cooldown",
			args = {},
		},
    }

    BuildCreateCategory()
    BuildCreateCooldown()
    BuildDeleteCooldown()
end