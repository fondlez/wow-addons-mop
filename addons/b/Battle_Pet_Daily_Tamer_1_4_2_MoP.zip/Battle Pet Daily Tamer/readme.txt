Battle Pet Daily Tamer puts a familiar paw on the world map to mark where daily pet tamers are that you have not completed for the day.

New in 1.4.2
- Fix for Darkmoon Faire being recognized on a cold login.
- Fix for TomTom ctrl-right click support.

New in 1.4.1
- Updated for 6.0/WoD.
- Addon/tables trimmed and tidied.
- "Satchel Dailies" is renamed "Pet Reward Dailies".
- "Non-Satchel Dailies" is renamed "Normal Dailies".
- Draenor dailies added.
- Celestial Tournament added.

From the tracking menu on the world map you can choose to selectively disable/enable:
- Pet Reward Dailies (green paw): These are dailies that reward a pet supply satchel, pet charm or token to buy pet supplies.
- Normal Dailies (blue paw): These are dailies that reward xp but no extra rewards.
- Beasts of Fables (orange paw): These are the legendary pets to battle, if you have picked up the Book of Fables quests.
- On Flight Maps Too (flying boot): This setting will show paws on the flight map, so you can choose where to fly closest to a daily. It is off by default.
- Stable Masters (horseshoe): This setting will display a horseshoe on the zone map where stable masters are located. It is off by default.

Also:
- If you have an addon that prevents accessing the above options from the world map's tracking menu, you can set them in the Interface Options Panel: Escape to Game Menu -> Interface -> Addons -> Battle Pet Daily Tamer.
- Mousing over a paw on the map will show the level of the tamer's pets and their types.
- Left-click of a paw will zoom into the zone where the tamer is located.
- Right-click of a paw will zoom out.
- If you use the addon TomTom, ctrl+right click of a paw will set a waypoint to that paw.

10/05/2014 1.4.2 fix for DMF being recognized on cold login, tomtom support added back
10/04/2014 1.4.1 trimmed addon/tables, most WoD dailies, added celestial tournament, renamed satchel/non-satchel dailies to Pet Reward/Normal Dailies,
09/24/2014 1.4.0 update for WoD, fix for stable master tooltips
04/04/2014 1.3.0 added interface options panel as an alternate way to change settings, non-satchel and fable dailies enabled by default for new users
12/02/2013 1.2.10 added option to view stable masters
09/25/2013 1.2.9 fixed a couple pet types in tooltips for 5.4 changes
09/23/2013 1.2.8 adjusted Aki the Chosen and Courageous Yon coordinates
09/21/2013 1.2.7 adjusted Pandaria taxi coordinates
09/16/2013 1.2.6 moved Aki the Chosen to Mistfall Village
09/11/2013 1.2.5 added Little Tommy Newcomer pet daily in Timeless Isle
07/24/2013 1.2.4 added option to show paws on flight maps, paw resource pool
05/21/2013 1.2.3 tooltips display which book a beast of fable is for
05/21/2013 1.2.2 release version for 5.3
05/03/2013 1.2.1 added coordinates for book 2/book 3 paws on world map
05/01/2013 1.2.0 toggle window removed and default's "Show Pet Tamers" option commandeered. beasts of fable split into three different quests
03/14/2013 1.1.8 fix for fabled paws in all localizations (numbered quest objectives instead of by name)
03/08/2013 1.1.7 added paws for the 10 fabled beasts (while quest is active) and option to display them
03/06/2013 1.1.6 added Sara Finkleswitch and Gentle San (Beasts of Fable daily)
02/16/2013 1.1.5 added limited TomTom support (ctrl+right click paw to /way there)
01/06/2013 1.1.4 added Jeremy Feasel (Darkmoon Faire) daily
01/01/2013 1.1.3 changed Merda Stronghoof's quest id from 31817 to 31872
12/29/2012 1.1.2 removed pre-requisite system, added expansion to tooltip
12/29/2012 1.1.1 removed NR paws from EK map, MP paws from KL map, manually added Bordin Steadyfist to Maelstrom maps
12/28/2012 1.1.0 astrolabe replaced with static data, paws created on demand
12/22/2012 1.0.5 added toggle window onto worldmap for turning paws on/off, removed panel option
12/21/2012 1.0.4 code cleanup
12/20/2012 1.0.3 overhauled pre-req system to work with both factions
12/18/2012 1.0.2 added non-satchel dailies (default off), fix for tooltip on full-screen map, temporary option to ignore pre-req dailies until horde dailies confirmed, right-clicking paw will zoom map out
12/16/2012 1.0.1 temporary fix for alliance/horde pre-req wierdness for taming EK/kalimdor, pet type icons on tamer tooltips
12/15/2012 1.0.0 initial release
