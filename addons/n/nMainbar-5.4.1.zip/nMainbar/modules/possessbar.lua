
local _, nMainbar = ...
local cfg = nMainbar.Config

PossessBarFrame:SetScale(cfg.possessBar.scale)
PossessBarFrame:SetAlpha(cfg.possessBar.alpha)
