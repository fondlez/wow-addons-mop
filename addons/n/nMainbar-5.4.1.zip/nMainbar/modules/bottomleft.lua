
local _, nMainbar = ...
local cfg = nMainbar.Config

MultiBarBottomLeft:SetAlpha(cfg.multiBarBottomLeft.alpha)
