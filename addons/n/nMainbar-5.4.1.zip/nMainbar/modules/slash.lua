
SlashCmdList['GM'] = function()
    ToggleHelpFrame() 
end

SLASH_GM1 = '/gm'
SLASH_GM2 = '/ticket'
SLASH_GM3 = '/gamemaster'