DFBang by Natch (natch@valsta.nu)

This addon will play a sound file when the dungeon finder's accept
window pops up. There are a few configuration options for controlling
the volume of the playback, have a look in DFBang.lua for details.

4.0.1 patch update:
I have removed the ability to set your own soundfile in the configuration
until I can find a clean solution to a certain problem. If you really want
your own however you can still muck around in the code or overwrite bang.mp3.

