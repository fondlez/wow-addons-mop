----------------------------------------------------------------------------
-- DFBang by Natch (natch@valsta.nu)
----------------------------------------------------------------------------
-- Configuration

-- Set this to true if you want the addon to raise the volume for the sound
-- playback.
local wantLoudness   = false;
local loudnessVolume = 50; -- Volume in percent
----------------------------------------------------------------------------
-- Don't edit below unless you know what you're doing.
----------------------------------------------------------------------------
local f = CreateFrame("Frame", "DFBang");
f:RegisterEvent("LFG_PROPOSAL_SHOW");
f.tslu    = 0;
f.sndFile = "Interface\\AddOns\\Natch_DFBang\\bang.mp3";
f.sndLen  = 2.4;
f.cvSND   = "Sound_EnableAllSound";
f.cvBGS   = "Sound_EnableSoundWhenGameIsInBG";
f.cvVOL   = "Sound_MasterVolume";
f.cvSFX   = "Sound_EnableSFX";
f.cvFXV   = "Sound_SFXVolume";

f:SetScript("OnEvent", function(self, event, ...)
               self:PlaySound();
end)

f:SetScript("OnUpdate", function(self, elapsed)
               if(self.playing == true) then
                  self.tslu = self.tslu + elapsed;

                  if(self.tslu > self.sndLen) then
                     self:StopSound();
                     self.tslu = 0;
                  end
               end
end)

function f:PlaySound()
   -- Original mute/unmute code borrowed from NPCScan by Saiket
   if(not GetCVarBool(self.cvSND)) then
      self.SoundEnableChanged = true;
      SetCVar(self.cvSND, 1);
   end

   if(not GetCVarBool(self.cvBGS)) then
      self.SoundInBGChanged = true;
      SetCVar(self.cvBGS, 1);
   end

   if(not GetCVarBool(self.cvSFX)) then
      self.SoundSFXChanged = true;
      SetCVar(self.cvSFX, 1);
   end

   if(wantLoudness) then
      self.oldVol = GetCVar(self.cvVOL);
      SetCVar(self.cvVOL, loudnessVolume/100);

      self.oldVolSFX = tonumber(GetCVar(self.cvFXV));
      if(self.oldVolSFX < 0.1) then
         SetCVar(self.cvFXV, 0.1);
      end
   end

   self.tslu = 0;
   PlaySoundFile(self.sndFile, "Master");
   self.playing = true;
end

function f:StopSound()
   if(self.playing == false) then
      return;
   end

   if(wantLoudness == true) then
      SetCVar(self.cvVOL, self.oldVol);
      SetCVar(self.cvFXV, self.oldVolSFX);
   end

   if(self.SoundSFXChanged == true) then
      SetCVar(self.cvSFX, 0);
   end

   if(self.SoundInBGChanged == true) then
      SetCVar(self.cvBGS, 0);
   end

   if(self.SoundEnableChanged == true) then
      SetCVar(self.cvSND, 0);
   end

   self.playing = false;

   self:Reset();
end

function f:Reset()
   self.SoundSFXChanged    = false;
   self.SoundInBGChanged   = false;
   self.SoundEnableChanged = false;
end
