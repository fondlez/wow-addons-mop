
------------------------------------------------------------------------------------
-- Name : nUI_Plugin_TempMovers                                          
-- Copyright : Tina Kirby AKA Xrystal (C) 2009/2010 All Rights Reserved      
-- Contact : xrystal@swangen.co.uk                                           
-- Download Sites :                                                          
-- Version : 1.01.00 - New
-- Version : 1.02.00 - Added fake player frame functionality on target change
-- Version : 1.03.00 - also used fake player frame stuff on entering world
-- Version : 1.04.00 - Use Paladin and Warlock OnLoad and Update routines when initialising 
-- Version : 1.05.00 - Use Druid UpdateShown routine when initialising
-- Version : 1.06.00 - Hide Druid Eclipse Bar so as not to call OnShow too soon
-- Version : 1.07.00 - Make sure Druid Eclipse Bar is allowed to be moved
------------------------------------------------------------------------------------

--[[ Use Addon Wide Data Table ]]--
local addonName,addonData = ...

local PTM_Frame = CreateFrame("Frame","PTM_Frame",UIParent);
PTM_Frame:SetParent(UIParent);
PTM_Frame:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 12 );

-- 5.0.4 Change Start - New Priest and Monk Power Bars
local function PTM_MonkPBInit()
	if MonkHarmonyBar then
		MonkHarmonyBar:SetParent(nil);
		MonkHarmonyBar:SetParent(PTM_Frame);
		--MonkHarmonyBar:SetScale( 
		--	(40 * nUI.vScale) 
		--	/ (MonkHarmonyBar:GetTop()-MonkHarmonyBar:GetBottom()) 
		--	* 0.75
		--);
		MonkHarmonyBar:SetFrameStrata( "BACKGROUND" );
		MonkHarmonyBar:SetFrameLevel( 0 );
		MonkHarmonyBar:ClearAllPoints();
		MonkHarmonyBar:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 28 );
		nUI_Movers:lockFrame( MonkHarmonyBar, false, "nUI_XMonkHarmonyBar" );
		MonkHarmonyBar_OnLoad (MonkHarmonyBar);
		MonkHarmonyBar_Update(MonkHarmonyBar);
	end
end

local function PTM_PriestPBInit()
	if PriestBarFrame then
		PriestBarFrame:SetParent(nil);
		PriestBarFrame:SetParent(PTM_Frame);
		--PriestBarFrame:SetScale( 
		--	(40 * nUI.vScale) 
		--	/ (PriestBarFrame:GetTop()-PriestBarFrame:GetBottom()) 
		--	* 0.75
		--);
		PriestBarFrame:SetFrameStrata( "BACKGROUND" );
		PriestBarFrame:SetFrameLevel( 0 );
		PriestBarFrame:ClearAllPoints();
		PriestBarFrame:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 12 );
		nUI_Movers:lockFrame( PriestBarFrame, false, "nUI_XPriestBarFrame" );
		PriestBarFrame_OnLoad (PriestBarFrame);
		PriestBar_Update();
	end
end
-- 5.0.4 Change Start - New Priest and Monk Power Bars

local function PTM_WSSInit()
	-- 5.0.1 Change  Start - Frame Name Change
	-- if ShardBarFrame then
	--	ShardBarFrame:SetParent(nil);
	--	ShardBarFrame:SetParent(PTM_Frame);
	--	ShardBarFrame:SetScale( 
	--		(40 * nUI.vScale) 
	--		/ (ShardBarFrame:GetTop()-ShardBarFrame:GetBottom()) 
	--		* 0.75
	--	);
	--	ShardBarFrame:SetFrameStrata( "BACKGROUND" );
	--	ShardBarFrame:SetFrameLevel( 0 );
	--	ShardBarFrame:ClearAllPoints();
	--	ShardBarFrame:SetPoint( "CENTER", nUI_HUDLAYOUT_PLAYERTARGET.."Bottom", "TOP", 0, 150 );
	--	nUI_Movers:lockFrame( ShardBarFrame, false, "nUI_XShardBarFrame" );
	--	ShardBar_OnLoad (ShardBarFrame);
	--	ShardBar_Update();
	-- end

	if ShardBarFrame then
		ShardBarFrame:SetParent(nil);
		ShardBarFrame:SetParent(PTM_Frame);
		ShardBarFrame:SetScale( 
			(40 * nUI.vScale) 
			/ (ShardBarFrame:GetTop()-ShardBarFrame:GetBottom()) 
			* 0.75
		);
		ShardBarFrame:SetFrameStrata( "BACKGROUND" );
		ShardBarFrame:SetFrameLevel( 0 );
		ShardBarFrame:ClearAllPoints();
		ShardBarFrame:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 12 );
		nUI_Movers:lockFrame( ShardBarFrame, false, "nUI_XShardBarFrame" );
	end
	if WarlockPowerFrame then
		WarlockPowerFrame:SetParent(nil);
		WarlockPowerFrame:SetParent(PTM_Frame);
		WarlockPowerFrame:SetScale( 
			(40 * nUI.vScale) 
			/ (WarlockPowerFrame:GetTop()-WarlockPowerFrame:GetBottom()) 
			* 0.75
		);
		WarlockPowerFrame:SetFrameStrata( "BACKGROUND" );
		WarlockPowerFrame:SetFrameLevel( 0 );
		WarlockPowerFrame:ClearAllPoints();
		WarlockPowerFrame:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 12 );
		nUI_Movers:lockFrame( WarlockPowerFrame, false, "nUI_XWarlockPowerFrame" );
		WarlockPowerFrame_OnLoad (WarlockPowerFrame);
	end
	-- 5.0.1 Change end
end

local function PTM_STBInit()
	if TotemFrame then
		TotemFrame:SetParent(nil);
		TotemFrame:SetParent(MultiCastActionBarFrame);
		TotemFrameTotem1:SetPoint("TOPLEFT",MultiCastActionButton1,"BOTTOMLEFT");
		TotemFrameTotem2:SetPoint("TOPLEFT",MultiCastActionButton2,"BOTTOMLEFT");
		TotemFrameTotem3:SetPoint("TOPLEFT",MultiCastActionButton3,"BOTTOMLEFT");
		TotemFrameTotem4:SetPoint("TOPLEFT",MultiCastActionButton4,"BOTTOMLEFT");
	end
end

local function PTM_PPBInit()
	if PaladinPowerBar then 
		PaladinPowerBar:SetParent(nil);
		PaladinPowerBar:SetParent(PTM_Frame);
		PaladinPowerBar:SetScale( 
			(40 * nUI.vScale) 
			/ (PaladinPowerBar:GetTop()-PaladinPowerBar:GetBottom()) 
			* 1.2
		);
		PaladinPowerBar:SetFrameStrata( "BACKGROUND" );
		PaladinPowerBar:SetFrameLevel( 0 );
		PaladinPowerBar:ClearAllPoints();
		PaladinPowerBar:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 20 );
		nUI_Movers:lockFrame( PaladinPowerBar, true, "nUI_XPaladinPowerBar" ); 		
		PaladinPowerBar_OnLoad(PaladinPowerBar);
		PaladinPowerBar_Update(PaladinPowerBar);
	end	
end

local function PTM_DEBInit()
	if EclipseBarFrame then
		EclipseBarFrame:Hide();
		EclipseBarFrame:SetParent(nil);
		EclipseBarFrame:SetParent(PTM_Frame);
		EclipseBarFrame:SetScale( 
			(40 * nUI.vScale) 
			/ (EclipseBarFrame:GetTop()-EclipseBarFrame:GetBottom()) 
		);
		EclipseBarFrame:SetFrameStrata( "BACKGROUND" );
		EclipseBarFrame:SetFrameLevel( 0 );
		EclipseBarFrame:ClearAllPoints();
		EclipseBarFrame:SetPoint( "TOP", nUI_TopBars, "BOTTOM", 0, 12 );
		nUI_Movers:lockFrame( EclipseBarFrame, true, "nUI_XDruidEclipseBar" ); 
		EclipseBar_OnLoad(EclipseBarFrame);
		EclipseBar_UpdateShown(EclipseBarFrame);		
	end
end

local function PTM_Events(self,event,...)
	local arg1,arg2,arg3,arg4,arg5,arg6 = ...;
	if ( event == "ADDON_LOADED" and arg1 == addonName ) then
		self.unit = PlayerFrame.unit;		
	elseif ( event == "PLAYER_ENTERING_WORLD" ) then
		-- 5.0.4 Start		
		-- local _, class = UnitClass("player");
		local emptyVar, class = UnitClass("player");
		-- 5.0.4 End
		self.unit = PlayerFrame.unit;	
		-- 5.0.4 Change Start - New Priest and Monk Power Bars
		if class == "MONK" then PTM_MonkPBInit() end	
		if class == "PRIEST" then PTM_PriestPBInit() end
		-- 5.0.4 Change End - New Priest and Monk Power Bars
		if class == "PALADIN" then PTM_PPBInit(); end
		if class == "WARLOCK" then PTM_WSSInit(); end
		if class == "SHAMAN" then PTM_STBInit(); end
		if class == "DRUID" then PTM_DEBInit(); end
		self:UnregisterEvent(event);
	elseif ( event == "PLAYER_TARGET_CHANGED" ) then
		self.unit = PlayerFrame.unit;
	end
end

--[[ Register the events we want to watch ]]--
PTM_Frame:SetScript( "OnEvent", PTM_Events );
PTM_Frame:RegisterEvent( "ADDON_LOADED" );
PTM_Frame:RegisterEvent( "PLAYER_ENTERING_WORLD" );
PTM_Frame:RegisterEvent( "PLAYER_TARGET_CHANGED" );

