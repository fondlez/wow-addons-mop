﻿--[[---------------------------------------------------------------------------

Copyright (c) 2008, 2009 by K. Scott Piel 
All Rights Reserved

E-mail: < kscottpiel@gmail.com >
Web:    < http://www.scottpiel.com >

This file is part of nUI.

	The copyright for all material provided within the nUI software package 
	("nUI") is held by Kenneth Scott Piel. Except as stated herein, none of 
	the material may be copied, reproduced, distributed, republished, 
	downloaded, displayed, posted or transmitted in any form or by any means, 
	including, but not limited to, electronic, mechanical, photocopying, 
	recording, or otherwise, without the prior written permission of 
	the copyright holder. Permission is granted to display, copy, distribute 
	and download the materials on this Site for personal, non-commercial use 
	only provided you do not modify the materials and that you retain all 
	copyright and other proprietary notices contained in the materials. You 
	also may not, without the copyright holder's permission, "mirror" any 
	material contained in nUI on any other server. This permission terminates 
	automatically if you breach any of these terms or conditions. Upon 
	termination, you will immediately destroy any downloaded and printed 
	materials. Any unauthorized use of any material contained in nUI may 
	violate copyright laws, trademark laws, the laws of privacy and publicity, 
	and communications regulations and statutes.
	
	nUI is packaged in four distributable versions known as "nUI Release",
	"nUI+", "nUI Development" and "nUI PTR Beta" -- Redistribution for these
	versions is governed by the following terms...
	
	1) Redistribution of the nUI Release (aka nUI Lite) version is permitted under 
	   the following terms... Permission is hereby	granted for unlimited free 
	   and open distribution of "nUI Release" / "nUI Lite" by anyone in any 
	   form and by any means provided the nUI Release distribution contents 
	   are not altered in any way, are distributed in full with all copyright 
	   statements and licensing terms included and intact and that any 
	   interface the end user is provided for the purpose of downloading nUI 
	   includes a plainly visible and functioning link to nUI's official web 
	   site at http://www.nUIaddon.com and a plainly visible notice that nUI 
	   accepts user donations with a working link to nUI's donation page at 
	   http://www.nUIaddon.com/donate.html
	   
	2) Permission is hereby granted for distribution of the "nUI+", "nUI+
	   Development" and "nUI+ PTR Beta" versions of nUI via the online download
	   service at http://www.wowinterface.com and the copyright holder's own
	   web site http://www.nuiaddon.com -- The end user is granted permission
	   to download any nUI package from these two web sites for their personal
	   use under the same terms and conditions as nUI Release but are prohibited
	   from sharing the contents of these packages via any means in any form
	   with anyone other than via direct transfer with immediate friends and
	   family members. Distribution of nUI+, nUI+ Development or nUI+ PTR Beta
	   via any other means by any other entity in any other form is strictly 
	   prohibited without the copyright holder's express written permission
	   explicitly granting such distribution rights specifically to that entity.
	   
	3) Deep-linking and leeching of nUI distributions is strictly prohibited. 
	   Any individual or entity who wishes to offer downloads of nUI 
	   distributions must either host the legal and unmodified distribution 
	   on their own servers to be distributed at their own expense using their 
	   own bandwidth or they must link the user back to the official download 
	   page on the third party provider's servers from which the user can 
	   initiate the download. Use of any download link or mechanism which 
	   initiates a download of any nUI distribution from a third party 
	   distribtion site that bypasses the official content and download pages 
	   or advertisements of that third party site is strictly prohibited
       without the express written consent of that site.
       
    See the included files "nUI_RELEASE_LICENSE.txt" and "nUI_PLUS_LICENSE.txt"
    for the complete terms of nUI's licensing terms.
	   
    nUI is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    enclosed license for more details.
	
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--]]---------------------------------------------------------------------------

-- pet feeder constants

nUI_DEFAULT_FRAME_RATE   = 30;
nUI_FOOD_MEAT	         = "meat";
nUI_FOOD_FISH	         = "fish";
nUI_FOOD_BREAD	         = "bread";
nUI_FOOD_CHEESE          = "cheese";
nUI_FOOD_FRUIT	         = "fruit";
nUI_FOOD_FUNGUS          = "fungus";

-- default information HUD layouts

nUI_HUDMODE_PLAYERTARGET = 1;
nUI_HUDMODE_HEALTHPOWER  = 2;
nUI_HUDMODE_SIDEBYSIDE   = 3;
nUI_HUDMODE_NOBARS       = 4;
nUI_HUDMODE_NOHUD        = 5;

nUI_HUDLAYOUT_PLAYERTARGET = "nUI_HUDLayout_PlayerTarget";
nUI_HUDLAYOUT_HEALTHPOWER  = "nUI_HUDLayout_HealthPower";
nUI_HUDLAYOUT_SIDEBYSIDE   = "nUI_HUDLayout_SideBySide";
nUI_HUDLAYOUT_NOBARS       = "nUI_HUDLayout_NoBars";
nUI_HUDLAYOUT_NOHUD        = "nUI_HUDLayout_NoHUD";

nUI_HUDUNIT_PLAYERTARGET             = "nUI_HUDUnit_PlayerTarget";
nUI_HUDUNIT_PLAYERTARGET_CASTBAR     = nUI_HUDUNIT_PLAYERTARGET.."_Castbar";
nUI_HUDUNIT_PLAYERTARGET_PET         = nUI_HUDUNIT_PLAYERTARGET.."_Pet";
nUI_HUDUNIT_PLAYERTARGET_PLAYER      = nUI_HUDUNIT_PLAYERTARGET.."_Player";
nUI_HUDUNIT_PLAYERTARGET_TARGET      = nUI_HUDUNIT_PLAYERTARGET.."_Target";
nUI_HUDUNIT_PLAYERTARGET_FOCUS       = nUI_HUDUNIT_PLAYERTARGET.."_Focus";
nUI_HUDUNIT_PLAYERTARGET_TOT         = nUI_HUDUNIT_PLAYERTARGET.."_ToT";
nUI_HUDUNIT_PLAYERTARGET_FOCUSTARGET = nUI_HUDUNIT_PLAYERTARGET.."_FocusTarget";

nUI_HUDSKIN_PLAYERTARGET_PET        = nUI_HUDUNIT_PLAYERTARGET_PET.."Skin";
nUI_HUDSKIN_PLAYERTARGET_CASTBAR    = nUI_HUDUNIT_PLAYERTARGET_CASTBAR.."Skin";
nUI_HUDSKIN_PLAYERTARGET_PLAYER     = nUI_HUDUNIT_PLAYERTARGET_PLAYER.."Skin";
nUI_HUDSKIN_PLAYERTARGET_TARGET     = nUI_HUDUNIT_PLAYERTARGET_TARGET.."Skin";
nUI_HUDSKIN_PLAYERTARGET_TOT        = nUI_HUDUNIT_PLAYERTARGET_TOT.."Skin";

nUI_HUDUNIT_HEALTHPOWER             = "nUI_HUDUnit_HealthPower";
nUI_HUDUNIT_HEALTHPOWER_CASTBAR     = nUI_HUDUNIT_HEALTHPOWER.."_Castbar";
nUI_HUDUNIT_HEALTHPOWER_PET         = nUI_HUDUNIT_HEALTHPOWER.."_Pet";
nUI_HUDUNIT_HEALTHPOWER_PLAYER      = nUI_HUDUNIT_HEALTHPOWER.."_Player";
nUI_HUDUNIT_HEALTHPOWER_TARGET      = nUI_HUDUNIT_HEALTHPOWER.."_Target";
nUI_HUDUNIT_HEALTHPOWER_FOCUS       = nUI_HUDUNIT_HEALTHPOWER.."_Focus";
nUI_HUDUNIT_HEALTHPOWER_TOT         = nUI_HUDUNIT_HEALTHPOWER.."_ToT";
nUI_HUDUNIT_HEALTHPOWER_FOCUSTARGET = nUI_HUDUNIT_HEALTHPOWER.."_FocusTarget";

nUI_HUDSKIN_HEALTHPOWER_PET         = nUI_HUDUNIT_HEALTHPOWER_PET.."Skin";
nUI_HUDSKIN_HEALTHPOWER_CASTBAR     = nUI_HUDUNIT_HEALTHPOWER_CASTBAR.."Skin";
nUI_HUDSKIN_HEALTHPOWER_PLAYER      = nUI_HUDUNIT_HEALTHPOWER_PLAYER.."Skin";
nUI_HUDSKIN_HEALTHPOWER_TARGET      = nUI_HUDUNIT_HEALTHPOWER_TARGET.."Skin";
nUI_HUDSKIN_HEALTHPOWER_TOT         = nUI_HUDUNIT_HEALTHPOWER_TOT.."Skin";

nUI_HUDUNIT_SIDEBYSIDE          = "nUI_HUDUnit_SideBySide";
nUI_HUDUNIT_SIDEBYSIDE_PET      = nUI_HUDUNIT_SIDEBYSIDE.."_Pet";
nUI_HUDUNIT_SIDEBYSIDE_CASTBAR  = nUI_HUDUNIT_SIDEBYSIDE.."_Castbar";
nUI_HUDUNIT_SIDEBYSIDE_PLAYER   = nUI_HUDUNIT_SIDEBYSIDE.."_Player";
nUI_HUDUNIT_SIDEBYSIDE_TARGET   = nUI_HUDUNIT_SIDEBYSIDE.."_Target";
nUI_HUDUNIT_SIDEBYSIDE_TOT      = nUI_HUDUNIT_SIDEBYSIDE.."_ToT";

nUI_HUDSKIN_SIDEBYSIDE_PET      = nUI_HUDUNIT_SIDEBYSIDE_PET.."Skin";
nUI_HUDSKIN_SIDEBYSIDE_CASTBAR  = nUI_HUDUNIT_SIDEBYSIDE_CASTBAR.."Skin";
nUI_HUDSKIN_SIDEBYSIDE_PLAYER   = nUI_HUDUNIT_SIDEBYSIDE_PLAYER.."Skin";
nUI_HUDSKIN_SIDEBYSIDE_TARGET   = nUI_HUDUNIT_SIDEBYSIDE_TARGET.."Skin";
nUI_HUDSKIN_SIDEBYSIDE_TOT      = nUI_HUDUNIT_SIDEBYSIDE_TOT.."Skin";

nUI_HUDUNIT_NOBARS              = "nUI_HUDUnit_NoBars";
nUI_HUDUNIT_NOBARS_CASTBAR      = nUI_HUDUNIT_NOBARS.."_Casting";
nUI_HUDUNIT_NOBARS_PLAYER       = nUI_HUDUNIT_NOBARS.."_Player";
nUI_HUDUNIT_NOBARS_TARGET       = nUI_HUDUNIT_NOBARS.."_Target";
nUI_HUDUNIT_NOBARS_FOCUS        = nUI_HUDUNIT_NOBARS.."_Focus";

nUI_HUDSKIN_NOBARS_CASTBAR      = nUI_HUDUNIT_NOBARS_CASTBAR.."Skin";
nUI_HUDSKIN_NOBARS_PLAYER       = nUI_HUDUNIT_NOBARS_PLAYER.."Skin";
nUI_HUDSKIN_NOBARS_TARGET       = nUI_HUDUNIT_NOBARS_TARGET.."Skin";

-- default information panel modes

nUI_INFOMODE_COMBATLOG    = 2;
nUI_INFOMODE_BMM          = 3;
nUI_INFOMODE_RECOUNT      = 4;
nUI_INFOMODE_OMEN3KLH     = 5;
nUI_INFOMODE_OMEN3        = 6;
nUI_INFOMODE_KLH          = 8;
nUI_INFOMODE_KLHRECOUNT   = 9;
nUI_INFOMODE_SKADA        = 10;

nUI_INFOPANEL_COMBATLOG    = "nUI_InfoPanel_CombatLog";
nUI_INFOPANEL_BMM          = "nUI_InfoPanel_BattlefieldMinimap";
nUI_INFOPANEL_RECOUNT      = "nUI_InfoPanel_Recount";
nUI_INFOPANEL_OMEN3KLH     = "nUI_InfoPanel_Omen3KLH";
nUI_INFOPANEL_OMEN3        = "nUI_InfoPanel_Omen3";
nUI_INFOPANEL_KLH          = "nUI_InfoPanel_KLH";
nUI_INFOPANEL_KLHRECOUNT   = "nUI_InfoPanel_KLHRecount";
nUI_INFOPANEL_BUTTONBAG    = "nUI_InfoPanel_ButtonBag";
nUI_INFOPANEL_SKADA        = "nUI_InfoPanel_Skada";

-- default unit frame panel modes

nUI_UNITMODE_PLAYER      = 1;
nUI_UNITMODE_PARTY       = 2;
nUI_UNITMODE_RAID10      = 3;
nUI_UNITMODE_RAID15      = 4;
nUI_UNITMODE_RAID20      = 5;
nUI_UNITMODE_RAID25      = 6;
nUI_UNITMODE_RAID40      = 7;

nUI_UNITPANEL_PLAYER     = "nUI_UnitPanel_Player";
nUI_UNITPANEL_PARTY		 = "nUI_UnitPanel_Party";
nUI_UNITPANEL_RAID10	 = "nUI_UnitPanel_Raid10";
nUI_UNITPANEL_RAID15	 = "nUI_UnitPanel_Raid15";
nUI_UNITPANEL_RAID20	 = "nUI_UnitPanel_Raid20";
nUI_UNITPANEL_RAID25	 = "nUI_UnitPanel_Raid25";
nUI_UNITPANEL_RAID40	 = "nUI_UnitPanel_Raid40";

nUI_UNITFRAME_BOSSFRAME   = "nUI_BossUnit";

nUI_UNITFRAME_SOLO        = "nUI_SoloUnit";
nUI_UNITFRAME_SOLOFOCUS   = nUI_UNITFRAME_SOLO.."_Focus";
nUI_UNITFRAME_SOLOFOCUSP  = nUI_UNITFRAME_SOLO.."_FocusP";
nUI_UNITFRAME_SOLOFOCUST  = nUI_UNITFRAME_SOLO.."_FocusT";
nUI_UNITFRAME_SOLOMOUSE   = nUI_UNITFRAME_SOLO.."_Mouseover";
nUI_UNITFRAME_SOLOVEHICLE = nUI_UNITFRAME_SOLO.."_Vehicle";
nUI_UNITFRAME_SOLOPET     = nUI_UNITFRAME_SOLO.."_Pet";
nUI_UNITFRAME_SOLOPETT    = nUI_UNITFRAME_SOLO.."_PetTarget";
nUI_UNITFRAME_SOLOPLAYER  = nUI_UNITFRAME_SOLO.."_Player";
nUI_UNITFRAME_SOLOTARGET  = nUI_UNITFRAME_SOLO.."_Target";
nUI_UNITFRAME_SOLOTARGETP = nUI_UNITFRAME_SOLO.."_TargetP";
nUI_UNITFRAME_SOLOTOT     = nUI_UNITFRAME_SOLO.."_ToT";
nUI_UNITFRAME_SOLOTOTP    = nUI_UNITFRAME_SOLO.."_ToTP";
nUI_UNITFRAME_SOLOTOTT    = nUI_UNITFRAME_SOLO.."_ToTT";
nUI_UNITFRAME_SOLOBOSS    = nUI_UNITFRAME_SOLO.."_Boss";

nUI_UNITSKIN_BOSSFRAME     = nUI_UNITFRAME_BOSSFRAME.."Skin";

nUI_UNITSKIN_SOLOFOCUS     = nUI_UNITFRAME_SOLOFOCUS.."Skin";
nUI_UNITSKIN_SOLOMOUSE     = nUI_UNITFRAME_SOLOMOUSE.."Skin";
nUI_UNITSKIN_SOLOVEHICLE   = nUI_UNITFRAME_SOLOVEHICLE.."Skin";
nUI_UNITSKIN_SOLOPET       = nUI_UNITFRAME_SOLOPET.."Skin";
nUI_UNITSKIN_SOLOPETBUTTON = nUI_UNITFRAME_SOLO.."_PetButtonSkin";
nUI_UNITSKIN_SOLOPLAYER    = nUI_UNITFRAME_SOLOPLAYER.."Skin";
nUI_UNITSKIN_SOLOTARGET    = nUI_UNITFRAME_SOLOTARGET.."Skin";
nUI_UNITSKIN_SOLOTGTBUTTON = nUI_UNITFRAME_SOLO.."_TgtButtonSkin";
nUI_UNITSKIN_SOLOTOT       = nUI_UNITFRAME_SOLOTOT.."Skin";

nUI_UNITFRAME_PARTY         = "nUI_PartyUnit_Party";
nUI_UNITFRAME_PARTYFOCUS    = "nUI_PartyUnit_Focus";
nUI_UNITFRAME_PARTYFOCUSP   = "nUI_PartyUnit_FocusPet";
nUI_UNITFRAME_PARTYFOCUST   = "nUI_PartyUnit_FocusTarget";
nUI_UNITFRAME_PARTYP        = "nUI_PartyUnit_PartyPet";
nUI_UNITFRAME_PARTYT        = "nUI_PartyUnit_PartyTarget";
nUI_UNITFRAME_PARTYMOUSE    = "nUI_PartyUnit_Mouseover";
nUI_UNITFRAME_PARTYVEHICLE  = "nUI_PartyUnit_Vehicle";
nUI_UNITFRAME_PARTYPET      = "nUI_PartyUnit_Pet";
nUI_UNITFRAME_PARTYPETT     = "nUI_PartyUnit_PetTarget";
nUI_UNITFRAME_PARTYPLAYER   = "nUI_PartyUnit_Player";
nUI_UNITFRAME_PARTYTARGET   = "nUI_PartyUnit_Target";
nUI_UNITFRAME_PARTYTARGETP  = "nUI_PartyUnit_TargetPet";
nUI_UNITFRAME_PARTYTOT      = "nUI_PartyUnit_ToT";
nUI_UNITFRAME_PARTYTOTT     = "nUI_PartyUnit_ToTT";
nUI_UNITFRAME_PARTYBOSS     = "nUI_PartyUnit_Boss";

nUI_UNITSKIN_PARTYFOCUS     = nUI_UNITFRAME_PARTYFOCUS.."Skin";
nUI_UNITSKIN_PARTYLEFT      = nUI_UNITFRAME_PARTY.."LeftSkin";
nUI_UNITSKIN_PARTYMOUSE     = nUI_UNITFRAME_PARTYMOUSE.."Skin";
nUI_UNITSKIN_PARTYVEHICLE   = nUI_UNITFRAME_PARTYVEHICLE.."Skin";
nUI_UNITSKIN_PARTYPET       = nUI_UNITFRAME_PARTYPET.."Skin";
nUI_UNITSKIN_PARTYPETBUTTON = nUI_UNITFRAME_PARTYPET.."ButtonSkin";
nUI_UNITSKIN_PARTYPLAYER    = nUI_UNITFRAME_PARTYPLAYER.."Skin";
nUI_UNITSKIN_PARTYRIGHT     = nUI_UNITFRAME_PARTY.."RightSkin";
nUI_UNITSKIN_PARTYTARGET    = nUI_UNITFRAME_PARTYTARGET.."Skin";
nUI_UNITSKIN_PARTYTGTBUTTON = nUI_UNITFRAME_PARTYTARGET.."ButtonSkin";
nUI_UNITSKIN_PARTYTOT       = nUI_UNITFRAME_PARTYTOT.."Skin";

nUI_UNITFRAME_RAID10        = "nUI_Raid10Unit_Raid";
nUI_UNITFRAME_RAID10FOCUS   = "nUI_Raid10Unit_Focus";
nUI_UNITFRAME_RAID10FOCUSP  = "nUI_Raid10Unit_FocusPet";
nUI_UNITFRAME_RAID10FOCUST  = "nUI_Raid10Unit_FocusTarget";
nUI_UNITFRAME_RAID10P       = "nUI_Raid10Unit_PartyPet";
nUI_UNITFRAME_RAID10T       = "nUI_Raid10Unit_PartyTarget";
nUI_UNITFRAME_RAID10MOUSE   = "nUI_Raid10Unit_Mouseover";
nUI_UNITFRAME_RAID10VEHICLE = "nUI_Raid10Unit_Vehicle";
nUI_UNITFRAME_RAID10PET     = "nUI_Raid10Unit_Pet";
nUI_UNITFRAME_RAID10PETT    = "nUI_Raid10Unit_PetTarget";
nUI_UNITFRAME_RAID10PLAYER  = "nUI_Raid10Unit_Player";
nUI_UNITFRAME_RAID10TARGET  = "nUI_Raid10Unit_Target";
nUI_UNITFRAME_RAID10TARGETP = "nUI_Raid10Unit_TargetPet";
nUI_UNITFRAME_RAID10TOT     = "nUI_Raid10Unit_ToT";
nUI_UNITFRAME_RAID10TOTT    = "nUI_Raid10Unit_ToTT";
nUI_UNITFRAME_RAID10BOSS    = "nUI_Raid10Unit_Boss";

nUI_UNITSKIN_RAID10FOCUS     = nUI_UNITFRAME_RAID10FOCUS.."Skin";
nUI_UNITSKIN_RAID10LEFT      = nUI_UNITFRAME_RAID10.."LeftSkin";
nUI_UNITSKIN_RAID10MOUSE     = nUI_UNITFRAME_RAID10MOUSE.."Skin";
nUI_UNITSKIN_RAID10VEHICLE   = nUI_UNITFRAME_RAID10VEHICLE.."Skin";
nUI_UNITSKIN_RAID10PET       = nUI_UNITFRAME_RAID10PET.."Skin";
nUI_UNITSKIN_RAID10PETBUTTON = nUI_UNITFRAME_RAID10PET.."ButtonSkin";
nUI_UNITSKIN_RAID10PLAYER    = nUI_UNITFRAME_RAID10PLAYER.."Skin";
nUI_UNITSKIN_RAID10RIGHT     = nUI_UNITFRAME_RAID10.."RightSkin";
nUI_UNITSKIN_RAID10TARGET    = nUI_UNITFRAME_RAID10TARGET.."Skin";
nUI_UNITSKIN_RAID10TGTBUTTON = nUI_UNITFRAME_RAID10TARGET.."ButtonSkin";
nUI_UNITSKIN_RAID10TOT       = nUI_UNITFRAME_RAID10TOT.."Skin";

nUI_UNITFRAME_RAID15        = "nUI_Raid15Unit_Raid";
nUI_UNITFRAME_RAID15FOCUS   = "nUI_Raid15Unit_Focus";
nUI_UNITFRAME_RAID15FOCUSP  = "nUI_Raid15Unit_FocusPet";
nUI_UNITFRAME_RAID15FOCUST  = "nUI_Raid15Unit_FocusTarget";
nUI_UNITFRAME_RAID15P       = "nUI_Raid15Unit_PartyPet";
nUI_UNITFRAME_RAID15T       = "nUI_Raid15Unit_PartyTarget";
nUI_UNITFRAME_RAID15MOUSE   = "nUI_Raid15Unit_Mouseover";
nUI_UNITFRAME_RAID15VEHICLE = "nUI_Raid15Unit_Vehicle";
nUI_UNITFRAME_RAID15PET     = "nUI_Raid15Unit_Pet";
nUI_UNITFRAME_RAID15PETT    = "nUI_Raid15Unit_PetTarget";
nUI_UNITFRAME_RAID15PLAYER  = "nUI_Raid15Unit_Player";
nUI_UNITFRAME_RAID15TARGET  = "nUI_Raid15Unit_Target";
nUI_UNITFRAME_RAID15TARGETP = "nUI_Raid15Unit_TargetPet";
nUI_UNITFRAME_RAID15TOT     = "nUI_Raid15Unit_ToT";
nUI_UNITFRAME_RAID15TOTT    = "nUI_Raid15Unit_ToTT";
nUI_UNITFRAME_RAID15BOSS    = "nUI_Raid15Unit_Boss";

nUI_UNITSKIN_RAID15FOCUS     = nUI_UNITFRAME_RAID15FOCUS.."Skin";
nUI_UNITSKIN_RAID15LEFT      = nUI_UNITFRAME_RAID15.."LeftSkin";
nUI_UNITSKIN_RAID15MOUSE     = nUI_UNITFRAME_RAID15MOUSE.."Skin";
nUI_UNITSKIN_RAID15VEHICLE   = nUI_UNITFRAME_RAID15VEHICLE.."Skin";
nUI_UNITSKIN_RAID15PET       = nUI_UNITFRAME_RAID15PET.."Skin";
nUI_UNITSKIN_RAID15PETBUTTON = nUI_UNITFRAME_RAID15PET.."ButtonSkin";
nUI_UNITSKIN_RAID15PLAYER    = nUI_UNITFRAME_RAID15PLAYER.."Skin";
nUI_UNITSKIN_RAID15RIGHT     = nUI_UNITFRAME_RAID15.."RightSkin";
nUI_UNITSKIN_RAID15TARGET    = nUI_UNITFRAME_RAID15TARGET.."Skin";
nUI_UNITSKIN_RAID15TGTBUTTON = nUI_UNITFRAME_RAID15TARGET.."ButtonSkin";
nUI_UNITSKIN_RAID15TOT       = nUI_UNITFRAME_RAID15TOT.."Skin";

nUI_UNITFRAME_RAID20        = "nUI_Raid20Unit_Raid";
nUI_UNITFRAME_RAID20FOCUS   = "nUI_Raid20Unit_Focus";
nUI_UNITFRAME_RAID20FOCUSP  = "nUI_Raid20Unit_FocusPet";
nUI_UNITFRAME_RAID20FOCUST  = "nUI_Raid20Unit_FocusTarget";
nUI_UNITFRAME_RAID20P       = "nUI_Raid20Unit_PartyPet";
nUI_UNITFRAME_RAID20T       = "nUI_Raid20Unit_PartyTarget";
nUI_UNITFRAME_RAID20MOUSE   = "nUI_Raid20Unit_Mouseover";
nUI_UNITFRAME_RAID20VEHICLE = "nUI_Raid20Unit_Vehicle";
nUI_UNITFRAME_RAID20PET     = "nUI_Raid20Unit_Pet";
nUI_UNITFRAME_RAID20PETT    = "nUI_Raid20Unit_PetTarget";
nUI_UNITFRAME_RAID20PLAYER  = "nUI_Raid20Unit_Player";
nUI_UNITFRAME_RAID20TARGET  = "nUI_Raid20Unit_Target";
nUI_UNITFRAME_RAID20TARGETP = "nUI_Raid20Unit_TargetPet";
nUI_UNITFRAME_RAID20TOT     = "nUI_Raid20Unit_ToT";
nUI_UNITFRAME_RAID20TOTT    = "nUI_Raid20Unit_ToTT";
nUI_UNITFRAME_RAID20BOSS    = "nUI_Raid20Unit_Boss";

nUI_UNITSKIN_RAID20FOCUS     = nUI_UNITFRAME_RAID20FOCUS.."Skin";
nUI_UNITSKIN_RAID20LEFT      = nUI_UNITFRAME_RAID20.."LeftSkin";
nUI_UNITSKIN_RAID20MOUSE     = nUI_UNITFRAME_RAID20MOUSE.."Skin";
nUI_UNITSKIN_RAID20VEHICLE   = nUI_UNITFRAME_RAID20VEHICLE.."Skin";
nUI_UNITSKIN_RAID20PET       = nUI_UNITFRAME_RAID20PET.."Skin";
nUI_UNITSKIN_RAID20PETBUTTON = nUI_UNITFRAME_RAID20PET.."ButtonSkin";
nUI_UNITSKIN_RAID20PLAYER    = nUI_UNITFRAME_RAID20PLAYER.."Skin";
nUI_UNITSKIN_RAID20RIGHT     = nUI_UNITFRAME_RAID20.."RightSkin";
nUI_UNITSKIN_RAID20TARGET    = nUI_UNITFRAME_RAID20TARGET.."Skin";
nUI_UNITSKIN_RAID20TGTBUTTON = nUI_UNITFRAME_RAID20TARGET.."ButtonSkin";
nUI_UNITSKIN_RAID20TOT       = nUI_UNITFRAME_RAID20TOT.."Skin";

nUI_UNITFRAME_RAID25        = "nUI_Raid25Unit_Raid";
nUI_UNITFRAME_RAID25FOCUS   = "nUI_Raid25Unit_Focus";
nUI_UNITFRAME_RAID25FOCUSP  = "nUI_Raid25Unit_FocusPet";
nUI_UNITFRAME_RAID25FOCUST  = "nUI_Raid25Unit_FocusTarget";
nUI_UNITFRAME_RAID25P       = "nUI_Raid25Unit_PartyPet";
nUI_UNITFRAME_RAID25T       = "nUI_Raid25Unit_PartyTarget";
nUI_UNITFRAME_RAID25MOUSE   = "nUI_Raid25Unit_Mouseover";
nUI_UNITFRAME_RAID25VEHICLE = "nUI_Raid25Unit_Vehicle";
nUI_UNITFRAME_RAID25PET     = "nUI_Raid25Unit_Pet";
nUI_UNITFRAME_RAID25PETT    = "nUI_Raid25Unit_PetTarget";
nUI_UNITFRAME_RAID25PLAYER  = "nUI_Raid25Unit_Player";
nUI_UNITFRAME_RAID25TARGET  = "nUI_Raid25Unit_Target";
nUI_UNITFRAME_RAID25TARGETP = "nUI_Raid25Unit_TargetPet";
nUI_UNITFRAME_RAID25TOT     = "nUI_Raid25Unit_ToT";
nUI_UNITFRAME_RAID25TOTT    = "nUI_Raid25Unit_ToTT";
nUI_UNITFRAME_RAID25BOSS    = "nUI_Raid25Unit_Boss";

nUI_UNITSKIN_RAID25FOCUS     = nUI_UNITFRAME_RAID25FOCUS.."Skin";
nUI_UNITSKIN_RAID25LEFT      = nUI_UNITFRAME_RAID25.."LeftSkin";
nUI_UNITSKIN_RAID25MOUSE     = nUI_UNITFRAME_RAID25MOUSE.."Skin";
nUI_UNITSKIN_RAID25VEHICLE   = nUI_UNITFRAME_RAID25VEHICLE.."Skin";
nUI_UNITSKIN_RAID25PET       = nUI_UNITFRAME_RAID25PET.."Skin";
nUI_UNITSKIN_RAID25PETBUTTON = nUI_UNITFRAME_RAID25PET.."ButtonSkin";
nUI_UNITSKIN_RAID25PLAYER    = nUI_UNITFRAME_RAID25PLAYER.."Skin";
nUI_UNITSKIN_RAID25RIGHT     = nUI_UNITFRAME_RAID25.."RightSkin";
nUI_UNITSKIN_RAID25TARGET    = nUI_UNITFRAME_RAID25TARGET.."Skin";
nUI_UNITSKIN_RAID25TGTBUTTON = nUI_UNITFRAME_RAID25TARGET.."ButtonSkin";
nUI_UNITSKIN_RAID25TOT       = nUI_UNITFRAME_RAID25TOT.."Skin";

nUI_UNITFRAME_RAID40        = "nUI_Raid40Unit_Raid";
nUI_UNITFRAME_RAID40FOCUS   = "nUI_Raid40Unit_Focus";
nUI_UNITFRAME_RAID40FOCUSP  = "nUI_Raid40Unit_FocusPet";
nUI_UNITFRAME_RAID40FOCUST  = "nUI_Raid40Unit_FocusTarget";
nUI_UNITFRAME_RAID40P       = "nUI_Raid40Unit_PartyPet";
nUI_UNITFRAME_RAID40T       = "nUI_Raid40Unit_PartyTarget";
nUI_UNITFRAME_RAID40MOUSE   = "nUI_Raid40Unit_Mouseover";
nUI_UNITFRAME_RAID40VEHICLE = "nUI_Raid40Unit_Vehicle";
nUI_UNITFRAME_RAID40PET     = "nUI_Raid40Unit_Pet";
nUI_UNITFRAME_RAID40PETT    = "nUI_Raid40Unit_PetTarget";
nUI_UNITFRAME_RAID40PLAYER  = "nUI_Raid40Unit_Player";
nUI_UNITFRAME_RAID40TARGET  = "nUI_Raid40Unit_Target";
nUI_UNITFRAME_RAID40TARGETP = "nUI_Raid40Unit_TargetPet";
nUI_UNITFRAME_RAID40TOT     = "nUI_Raid40Unit_ToT";
nUI_UNITFRAME_RAID40TOTT    = "nUI_Raid40Unit_ToTT";
nUI_UNITFRAME_RAID40BOSS    = "nUI_Raid40Unit_Boss";

nUI_UNITSKIN_RAID40FOCUS     = nUI_UNITFRAME_RAID40FOCUS.."Skin";
nUI_UNITSKIN_RAID40LEFT      = nUI_UNITFRAME_RAID40.."LeftSkin";
nUI_UNITSKIN_RAID40MOUSE     = nUI_UNITFRAME_RAID40MOUSE.."Skin";
nUI_UNITSKIN_RAID40VEHICLE   = nUI_UNITFRAME_RAID40VEHICLE.."Skin";
nUI_UNITSKIN_RAID40PET       = nUI_UNITFRAME_RAID40PET.."Skin";
nUI_UNITSKIN_RAID40PETBUTTON = nUI_UNITFRAME_RAID40PET.."ButtonSkin";
nUI_UNITSKIN_RAID40PLAYER    = nUI_UNITFRAME_RAID40PLAYER.."Skin";
nUI_UNITSKIN_RAID40RIGHT     = nUI_UNITFRAME_RAID40.."RightSkin";
nUI_UNITSKIN_RAID40TARGET    = nUI_UNITFRAME_RAID40TARGET.."Skin";
nUI_UNITSKIN_RAID40TGTBUTTON = nUI_UNITFRAME_RAID40TARGET.."ButtonSkin";
nUI_UNITSKIN_RAID40TOT       = nUI_UNITFRAME_RAID40TOT.."Skin";

nUI_FACTION_UPDATE_START_STRING    = "Reputation with ";
nUI_FACTION_UPDATE_END_STRING      = " increased";
nUI_FACTION_UPDATE_INCREASE_STRING = "increased";

-- slash command processing constants

nUI_SLASHCMD_OPTIONS   = "nUI_SLASHCMD_OPTIONS";

nUI_SLASHCMD_CONFIG     = 0;
nUI_SLASHCMD_HELP       = 1;
nUI_SLASHCMD_RELOAD     = 2;
nUI_SLASHCMD_BUTTONBAG  = 3;
nUI_SLASHCMD_MOVERS     = 4;
nUI_SLASHCMD_CONSOLE    = 5;
nUI_SLASHCMD_TOOLTIPS   = 6;
nUI_SLASHCMD_COMBATTIPS = 7;
nUI_SLASHCMD_BAGSCALE   = 8;
nUI_SLASHCMD_BAGBAR     = 9;
nUI_SLASHCMD_CALENDAR   = 10;
nUI_SLASHCMD_ONEBAG     = 11;
nUI_SLASHCMD_FRAMERATE  = 12;
nUI_SLASHCMD_AUTOGROUP  = 13;
nUI_SLASHCMD_RAIDSORT   = 14;
nUI_SLASHCMD_SHOWANIM   = 15;
nUI_SLASHCMD_SHOWHITS   = 16;
nUI_SLASHCMD_FEEDBACK   = 17;
nUI_SLASHCMD_MAXAURAS   = 18;
nUI_SLASHCMD_HPLOST     = 19;
nUI_SLASHCMD_HUD        = 20;
nUI_SLASHCMD_BAR        = 21;
nUI_SLASHCMD_MOUNTSCALE = 22;
nUI_SLASHCMD_CLOCK      = 23;
nUI_SLASHCMD_MAPCOORDS  = 24;
nUI_SLASHCMD_ROUNDMAP   = 25;
nUI_SLASHCMD_MINIMAP    = 26;
nUI_SLASHCMD_WATCHFRAME = 27;
nUI_SLASHCMD_VIEWPORT   = 28;

nUI_SLASHCMD_LASTITEM  = nUI_SLASHCMD_VIEWPORT;

function nUI_SLASHCMD_OPTIONS( n, v ) return ("nUI_SHASHCMD_%d_%s"):format( n, v ); end

nUI_SLASHCMD_HUD_SCALE       = 1;
nUI_SLASHCMD_HUD_SHOWNPC     = 2;
nUI_SLASHCMD_HUD_FOCUS       = 3;
nUI_SLASHCMD_HUD_HEALTHRACE  = 4;
nUI_SLASHCMD_HUD_COOLDOWN    = 5;
nUI_SLASHCMD_HUD_CDALERT     = 6;
nUI_SLASHCMD_HUD_CDSOUND     = 7;
nUI_SLASHCMD_HUD_CDMIN       = 8;
nUI_SLASHCMD_HUD_HGAP        = 9;
nUI_SLASHCMD_HUD_VOFS        = 10;
nUI_SLASHCMD_HUD_IDLEALPHA   = 11;
nUI_SLASHCMD_HUD_REGENALPHA  = 12;
nUI_SLASHCMD_HUD_TARGETALPHA = 13;
nUI_SLASHCMD_HUD_COMBATALPHA = 14;

nUI_SLASHCMD_BAR_COOLDOWN    = 1;
nUI_SLASHCMD_BAR_DURATION    = 2;
nUI_SLASHCMD_BAR_MACRO       = 3;
nUI_SLASHCMD_BAR_STACKCOUNT  = 4;
nUI_SLASHCMD_BAR_KEYBIND     = 5;
nUI_SLASHCMD_BAR_DIMMING     = 6;
nUI_SLASHCMD_BAR_DIMALPHA    = 7;
nUI_SLASHCMD_BAR_MOUSEOVER   = 8;
nUI_SLASHCMD_BAR_TOTEMS      = 9;
nUI_SLASHCMD_BAR_BOOMKIN     = 10;
