﻿-- Author      : Linty
-- Create Date : 1/9/2010 6:52:04 PM

function hwm_Session_ClickHyperlink(source, arg)
	local sunit = hwm.vars.sessionddata[arg];
	if (sunit==nil) then
		return;
	end
	HWM_Rate_Show(sunit.Server, sunit.Name);
end

function hwm_Session_EnterHyperlink(source, arg)
	local sunit = hwm.vars.sessionddata[arg];
	-- hwm.utils:Chat(arg)
	if (sunit==nil) then
		GameTooltip_SetDefaultAnchor(GameTooltip, source);
		GameTooltip:SetText("|cffff0000Unit could not be found!!");
		GameTooltip:Show();
		return;
	end
	GameTooltip_SetDefaultAnchor(GameTooltip, source);
	GameTooltip:SetText(arg1);
	GameTooltip:AddLine(sunit.Race,1,1,1);
	GameTooltip:AddLine(sunit.Class,sunit.Color.r,sunit.Color.g,sunit.Color.b);
	
	hwm:AppendTooltip(sunit.Server, sunit.Name);
	GameTooltip:AddLine("____________________",1,1,1,true);
	GameTooltip:AddLine(hwm.lang.tt_sessioninstr,1,1,1,true);
	GameTooltip:Show();
	
end
function hwm_Session_ExitHyperlink(source, arg)
	GameTooltip:Hide();
end

