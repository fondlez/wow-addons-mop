﻿-- Author      : Linty Druid
-- Create Date : 09 Jan 2010

function HWM_OptionsFrame_OnLoad(panel)

	-- Register the Interface Options page.
	
	panel.name = "Have We Met";

	-- When the player clicks okay, set the Saved Variables to the current Check Box setting
	--
	panel.okay = function (self)  HWM_OptionsFrame_Close(); end;

	-- When the player clicks cancel, set the Check Box status to the Saved Variables.
	panel.cancel = function (self)   HWM_OptionsFrame_CancelOrLoad();  end;
	
	HWM_OptionsFrame_HideDetail:SetValue(HWM_Global.HideDetail);
	
	InterfaceOptions_AddCategory(panel)
	
	
	
end
function HWM_OptionsFrame_Close()
	local hidedetail = HWM_OptionsFrame_HideDetail:GetChecked();
	
	HWM_Global.HideDetail=(hidedetail~=nil)
	
end

function HWM_OptionsFrame_CancelOrLoad()
	HWM_OptionsFrame_HideDetail:SetValue(HWM_Global.HideDetail);
	
end




