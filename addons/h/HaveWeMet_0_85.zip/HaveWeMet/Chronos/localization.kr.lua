--------------------------------------------------
-- localization.kr.lua (Korean)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 22:41:28Z $
-- Translation:

if ( GetLocale() == "koKR" ) then

	-- Please submit your translation to everyone@cosmosui.org

end
