--------------------------------------------------
-- localization.de.lua (German)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 22:41:28Z $
-- Translation: pc, StarDust

if ( GetLocale() == "deDE" ) then

	-- Chat Configuration
	SCHEDULE_COMM		= {"/in","/pause","/verz\195\182gern"};
	SCHEDULE_DESC		= "/in <Sekunden> <Befehl> [<Param> ...]";
	SCHEDULE_USAGE1		= "Funktionsweise: /in <Sekunden> <Befehl> [<Param> ...] |cFFCC9966[Hinweis: /in KANN KEINE Zauber wirken um die Erstellung von Bots zu verhindern]|r";
	SCHEDULE_USAGE2		= "Startet <Befehl> mit den Parametern <Param> nach <Sekunden> Sekunden.";

end