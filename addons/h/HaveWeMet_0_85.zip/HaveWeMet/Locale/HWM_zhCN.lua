﻿-- Author      : LintyDruid

-- Localisation

function HWM_Locale_China()

end

