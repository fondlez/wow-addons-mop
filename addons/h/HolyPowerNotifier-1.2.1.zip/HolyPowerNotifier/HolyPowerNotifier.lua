--
-- Holy Power Notifier - Tells you when you've got Holy Power.
-- Gilbert@Tichondrius US / Susanne@Lightbringer US
--

-- Stop now if the player isn't a Paladin.
if select(2, UnitClass('player')) ~= "PALADIN" then
	DisableAddOn("HolyPowerNotifier")
	return
end

-- Set up our frame
local frame, events = CreateFrame("Frame"), {}
local texture = frame:CreateTexture()
frame:SetPoint("CENTER",0,80)
frame:SetWidth(128)
frame:SetHeight(128)
texture:SetAllPoints(frame)
texture:SetTexture("Interface\\Addons\\HolyPowerNotifier\\holypower.tga")
frame:Hide()

-- Create a frame for the counter graphics
local cframe, events = CreateFrame("Frame"), {}
local ctexture = cframe:CreateTexture()
cframe:SetPoint("CENTER",0,80)
cframe:SetWidth(128)
cframe:SetHeight(128)
ctexture:SetAllPoints(cframe)
ctexture:SetTexture("Interface\\Addons\\HolyPowerNotifier\\hp1.tga")
cframe:Hide()

-- Our command line option
function HolyPowerNotifier(input)
	if input == "counter" then
        if Counter == 1 then
            Counter = 0
            cframe:Hide();
            print ("|cffffff00Counter is |cffff0000OFF")
        else
            Counter = 1
            print ("|cffffff00Counter is |cff00ff00ON")
        end
    elseif input == "hide" then
        if HideBlizzardFrame == 1 then
            HideBlizzardFrame = 0
            PaladinPowerBar:Show();
            print ("|cffffff00Blizzard Holy Power frame is |cff00ff00ON")
        else
            PaladinPowerBar:Hide();
            HideBlizzardFrame = 1
            print ("|cffffff00Blizzard Holy Power frame is |cffff0000OFF")
        end
	else
        local value = tonumber(input)

        if not value or value < 1 or value > 5 then
            print ("|cffffff00Set Holy Power threshold: /hpn 1-5")
            print ("|cffffff00Sets the number of Holy Power you must have for the frame to be visible.")
            print (" ")
            print ("|cffffff00Toggle counter: /hpn count")
            print ("|cffffff00Toggle graphics for each point of Holy Power.")
            print ("|cffffff00Current threshold: "..HolyPowerCount)

            if Counter == 1 then
                print ("|cffffff00Counter is |cff00ff00ON")
            else
                print ("|cffffff00Counter is |cffff0000OFF")
            end

            print (" ")
            print ("|cffffff00Toggle Blizzard Frame: /hpn hide")
            print ("|cffffff00Turn the Blizzard Holy Power frame on or off.")
            
            if HideBlizzardFrame == 1 then
                print ("|cffffff00Blizzard Holy Power frame is |cffff0000OFF")
            else
                print ("|cffffff00Blizzard Holy Power frame is |cff00ff00ON")
            end
        else
            HolyPowerCount = value
            print ("|cffffff00Holy Power threshold set to "..value)
        end
	end
end

-- Blizzard resets Holy Power to 1 when zoning, but doesn't send
-- a UNIT_POWER event. We'll clear the frame on zoning.
function events:PLAYER_ENTERING_WORLD(...)
	frame:Hide()

    -- Hide the Blizzard Frame
    if HideBlizzardFrame == 1 then
        PaladinPowerBar:Hide();
    end
    
	-- Check if our variable is set
	if not HolyPowerCount then
        HolyPowerCount = 3
	end
end

-- Watch for UNIT_POWER events.
function events:UNIT_POWER(source,type)
	-- Make sure its our power, and that it's Holy Power
	if source == "player" and type == "HOLY_POWER" then
        local power = UnitPower("player",9)

        if Counter == 1 then
            if power > 0 then
                cframe:Show()

                ctexture:SetTexture("Interface\\Addons\\HolyPowerNotifier\\hp"..power..".tga")
            else
                cframe:Hide()
            end
        end

        -- Check if it's at the threshold
        if power >= HolyPowerCount then
            frame:Show()
            
            -- Even with the counter off, we still want to show the 5 holy power graphic
            -- to let people know they're capped.
            if power == 5 then
                texture:SetTexture("Interface\\Addons\\HolyPowerNotifier\\hp5.tga")
            else
                texture:SetTexture("Interface\\Addons\\HolyPowerNotifier\\holypower.tga")
            end           
        else
            frame:Hide()
        end
	end
end

-- Register our events
frame:SetScript("OnEvent", function(self,event,...) events[event](self,...) end)

for k,v in pairs(events) do
	frame:RegisterEvent(k)
end

-- Register our slash commands
SLASH_HOLYPOWERNOTIFIER1 = '/hpn'
SlashCmdList["HOLYPOWERNOTIFIER"] = HolyPowerNotifier