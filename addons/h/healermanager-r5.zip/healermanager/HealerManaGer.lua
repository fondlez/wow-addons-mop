-- -------------------------------------------------------------------------- --
-- HealerManaGer By Xulos ( EU ALLIANCE YSONDRE )      
-- -------------------------------------------------------------------------- --

UIPanelWindows["HealerManaGerFrame"] = { area = "doublewide", pushable = 0, width = 200, xoffset = 80, whileDead = 1 };

HealerManaGer = {};
HealerManaGer.version = GetAddOnMetadata("HealerManaGer", "Version");

-- L
local L = setmetatable({}, {
    __index = function(t, k)
		return k;
    end
});
if (GetLocale() == "frFR") then
	L["Track Current Energy"] = "Traquer l'energie actuelle";
	L["Track Mana"]="Traquer la Mana";
	L["Track Health"]="Traquer la Vie";
end
-- static
-- Mean
local GainMeanArray = {};
local LossMeanArray = {};
function InitMean(arr, c) -- array, nombre de valeurs
    arr.c = c; -- count
    for i=1,c do
        arr[i] = 0;
    end
    arr.s = 0; -- sum
    arr.cc = 0; -- current count
end
function PushAndMean(arr, v)
    if (arr.c == 0 ) then
        error("meanInit not call");
    else
        if (arr.cc < arr.c ) then
            arr.cc = arr.cc + 1;
        end
        
        arr.s = 0;
        for i=arr.cc,1,-1 do
            arr[i] = arr[i-1];
            if (arr[i] ) then arr.s = arr.s + arr[i]; end
        end
        arr[1] = v;
        arr.s = arr.s + v;

        return arr.s/arr.cc, arr.s, arr.cc;
    end
end
function HealerManaGerFrame_Init(self)
	HealerManaGerDB = HealerManaGerDB or {};
	HealerManaGerDB.Params = HealerManaGerDB.Params or {};
	HealerManaGerDB.Params.Width = 300;
	HealerManaGerDB.Params.Showed = HealerManaGerDB.Params.Showed or false;
	HealerManaGerDB.Params.SeuilLikeInfiniteInSeconds = 120;
			
	HealerManaGer.AddonPrefix = "HMG_5.4.0";
	--RegisterAddonMessagePrefix(HealerManaGer.AddonPrefix);
	
	local localizedClass = "";
	localizedClass, HealerManaGer.MyClass = UnitClass("player");
	
	HealerManaGerDB.PartyLst = {};
	
	HealerManaGerDB.Players = {};
	
	HealerManaGer.MyName = UnitName("player");
	
	HealerManaGerDB.MeanCountMana = HealerManaGerDB.MeanCountMana or 15;
	HealerManaGerDB.MeanCountHealth = HealerManaGerDB.MeanCountHealth or 30;

	HealerManaGerDB.TrackingMode = HealerManaGerDB.TrackingMode or "TCE"; -- TCE / TM / TH => Track Current Energy / Track Mana / Track Health

	HealerManaGer_SwitchMeanCount();
	
	if ( HealerManaGerDB.Params.Showed == true ) then HealerManaGerFrame:Show(); end
end
function HealerManaGer_SwitchMeanCount()
	local cE;
	if ( HealerManaGerDB.TrackingMode == "TM" or HealerManaGerDB.TrackingMode == "TCE" ) then
		cE = HealerManaGerDB.MeanCountMana;
	else
		cE = HealerManaGerDB.MeanCountHealth;
	end
	InitMean(GainMeanArray, cE);
	InitMean(LossMeanArray, cE);
end
function HealerManaGerMinimapButton_OnClick(self, button)
    if (HealerManaGerFrame) then
		if ( button == "LeftButton" ) then
			if(HealerManaGerFrame:IsVisible() ) then
				HealerManaGerFrame:Hide();
				HealerManaGerDB.Params.Showed = false;
			else
				HealerManaGerFrame:Show();
				HealerManaGerDB.Params.Showed = true;
			end
		elseif ( button == "RightButton" ) then
			ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, HealerManaGerMinimapButton, 15, 0);
		end
    end
end
function HealerManaGerMinimapButton_OnLoad(self)
	HealerManaGerMinimapButton.label:SetText("HMG");
end
function HealerManaGerMinimapButton_OnEnter(self)
	GameTooltip:SetOwner(self);
	GameTooltip:SetText("HealerManaGer "..HealerManaGer.version);
end
function HealerManaGerMinimapButton_OnLeave(self)
	GameTooltip:Hide();
end
function HealerManaGerBar_OnEnter(self)
	
end
function HealerManaGerBar_OnLeave(self)
	GameTooltip:Hide();
end
function HealerManaGerFrame_OnLoad(self)
	self:RegisterEvent("VARIABLES_LOADED");
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	--self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
end
function HealerManaGerFrame_OnEvent(self, event, arg1, arg2, ...)
	if ( event == "VARIABLES_LOADED" ) then
		HealerManaGerFrame_Init(self);
		self:UnregisterEvent("VARIABLES_LOADED");
	elseif ( event == "PLAYER_ENTERING_WORLD" ) then
		if ( UnitAffectingCombat("player") == nil ) then
			HealerManaGer:InitFrame();
			DEFAULT_CHAT_FRAME:AddMessage("HealerManaGer "..HealerManaGer.version.." LOADED");
			self:UnregisterEvent("PLAYER_ENTERING_WORLD");
		else
			DEFAULT_CHAT_FRAME:AddMessage("HealerManaGer "..HealerManaGer.version.." NOT LOADED");
			DEFAULT_CHAT_FRAME:AddMessage("PLEASE RELOAD INTERFACE AFTER THE END OF YOUR FIGHT");
		end
	elseif ( event == "COMBAT_LOG_EVENT_UNFILTERED" ) then
		HealerManaGerFrame_COMBAT_LOG_EVENT_UNFILTERED(self, ...);
	end
end
local HealerManaGerFrame_onUpdateCounter = 0;
local HealerManaGerFrame_UpdateEachNFrame = 20;
function HealerManaGerFrame_OnUpdate(self, elapsed)
	HealerManaGerFrame_onUpdateCounter = HealerManaGerFrame_onUpdateCounter + 1;
    if HealerManaGerFrame_onUpdateCounter % HealerManaGerFrame_UpdateEachNFrame == 0 then
        HealerManaGerFrame_onUpdateCounter = 0;
        HealerManaGerFrameRefresh();
    end
end 
local currentPower = UnitPower("player");
local currentPowerPerSecMax = 100;
local currentPowerGain = 0;
local currentPowerLoss = 0;
local lastEstimGain, lastEstimLoss;
local currentTime = debugprofilestop();
function HealerManaGerFrameRefresh()
-- maj de la valeurs des barres
	local cPower, cPowerMax;
	if ( HealerManaGerDB.TrackingMode == "TCE" ) then
		cPower = UnitPower("player");
		cPowerMax = UnitPowerMax("player");
	elseif ( HealerManaGerDB.TrackingMode == "TM" ) then
		cPower = UnitPower("player", 0);
		cPowerMax = UnitPowerMax("player", 0);
	elseif ( HealerManaGerDB.TrackingMode == "TH" ) then
		cPower = UnitHealth("player");
		cPowerMax = UnitHealthMax("player");
	end
	
	if ( cPower and cPowerMax ) then
		local cTime = debugprofilestop();

		local gain = 0;
		local loss = 0;
			
		if ( cPower ~= currentPower ) then
			local val = math.floor((cPower-currentPower)/(cTime-currentTime)*1000);
			if ( val > 0 ) then 
				gain = PushAndMean(GainMeanArray,val);
				loss = PushAndMean(LossMeanArray,0);
			elseif ( val < 0 ) then 
				gain = PushAndMean(GainMeanArray,0);
				loss = PushAndMean(LossMeanArray,val*-1);
			end
			currentPower = cPower;
			currentTime = cTime;
		end
		
		if ( gain > currentPowerPerSecMax ) then currentPowerPerSecMax = math.floor(gain); end
		if ( loss > currentPowerPerSecMax ) then currentPowerPerSecMax = math.floor(loss); end
			
		--print(string.format("%.2f",gain/currentPowerPerSecMax).." / "..string.format("%.2f",loss/currentPowerPerSecMax));
		local GainToDisp = math.floor(gain/currentPowerPerSecMax*100);
		local LossToDisp = math.floor(loss/currentPowerPerSecMax*100);
		
		if ( gain == 0 ) then GainPerSecLabel:SetText("   -");
		else GainPerSecLabel:SetText("  "..string.format("%.1f",gain).."u/s");
		end
		
		local estimGain = (cPowerMax-cPower)/gain;
		if ( estimGain == 0 ) then EstimGainLabel:SetText("- ");
		elseif ( gain > 0 ) then EstimGainLabel:SetText(string.format("%.1f",estimGain).."s "); lastEstimGain = estimGain;
		elseif ( lastEstimGain ) then EstimGainLabel:SetText(string.format("%.1f",lastEstimGain).."s ");
		else EstimGainLabel:SetText("- ");
		end
		
		if ( loss == 0 ) then LossPerSecLabel:SetText("-   ");
		else LossPerSecLabel:SetText(string.format("%.1f",loss).."u/s   ");
		end
		
		local estimLoss = cPower/loss;
		if ( estimLoss > HealerManaGerDB.Params.SeuilLikeInfiniteInSeconds or estimLoss == 0 ) then EstimLossLabel:SetText(" -");
		elseif ( loss > 0 ) then EstimLossLabel:SetText(" "..string.format("%.1f",estimLoss).."s"); lastEstimLoss = estimLoss; 
		elseif ( lastEstimLoss ) then EstimLossLabel:SetText(" "..string.format("%.1f",lastEstimLoss).."s");
		else EstimLossLabel:SetText("- ");
		end
		
		ManaGainBar:SetValue(GainToDisp);
		ManaLossBar:SetValue(100-LossToDisp);
		if ( GainToDisp >= LossToDisp ) then
			ManaGainBar2:SetValue(GainToDisp - LossToDisp);
			ManaLossBar2:SetValue(100);
		elseif ( GainToDisp < LossToDisp ) then
			ManaGainBar2:SetValue(0);
			ManaLossBar2:SetValue(100 - (LossToDisp - GainToDisp) );
		end
		
		local PowerToDisp = math.floor(cPower/cPowerMax*100);
		ManaPowerBarLabel:SetText(string.format("%.1f",PowerToDisp).."%");
		ManaPowerBar3:SetValue(PowerToDisp);
		
		if ( cPower == cPowerMax ) then currentPowerPerSecMax = 100; end -- remet a 0 la barre
	end
end  
function HealerManaGerFrame_COMBAT_LOG_EVENT_UNFILTERED(_,DATETIME, EVENTTYPE, hideCaster, GUIDSRC, SRC, SRCFLAG1, SRCFLAG2, GUIDDST, DST, DSTFLAG1, DSTFLAG2, ...)
	HealerManaGer:ProfilingUseFuncStart(HealerManaGerDB, "COMBAT_LOG_EVENT_UNFILTERED");
    
	local TargetType, GUID = nil, TargetName, SourceName, SourceType, SourceClass, TargetClass;
	
	local ret = nil;
	
	if ( string.match(EVENTTYPE, "ENERGIZE") ) then
		local spellName = select(2, ...);
		local powerType = select(5, ...);
		local amount = select(4,...);
		print(spellName,powerType, amount);
	end 
	
end
function HealerManaGer_AddDropDownItem(...)
  --[[
	List of button attributes
	======================================================
	info.text = [STRING]  --  The text of the button
	info.value = [ANYTHING]  --  The value that UIDROPDOWNMENU_MENU_VALUE is set to when the button is clicked
	info.func = [function()]  --  The function that is called when you click the button
	info.checked = [nil, true, function]  --  Check the button if true or function returns true
	info.isNotRadio = [nil, true]  --  Check the button uses radial image if false check box image if true
	info.isTitle = [nil, true]  --  If it's a title the button is disabled and the font color is set to yellow
	info.disabled = [nil, true]  --  Disable the button and show an invisible button that still traps the mouseover event so menu doesn't time out
	info.tooltipWhileDisabled = [nil, 1] -- Show the tooltip, even when the button is disabled.
	info.hasArrow = [nil, true]  --  Show the expand arrow for multilevel menus
	info.hasColorSwatch = [nil, true]  --  Show color swatch or not, for color selection
	info.r = [1 - 255]  --  Red color value of the color swatch
	info.g = [1 - 255]  --  Green color value of the color swatch
	info.b = [1 - 255]  --  Blue color value of the color swatch
	info.colorCode = [STRING] -- "|cAARRGGBB" embedded hex value of the button text color. Only used when button is enabled
	info.swatchFunc = [function()]  --  Function called by the color picker on color change
	info.hasOpacity = [nil, 1]  --  Show the opacity slider on the colorpicker frame
	info.opacity = [0.0 - 1.0]  --  Percentatge of the opacity, 1.0 is fully shown, 0 is transparent
	info.opacityFunc = [function()]  --  Function called by the opacity slider when you change its value
	info.cancelFunc = [function(previousValues)] -- Function called by the colorpicker when you click the cancel button (it takes the previous values as its argument)
	info.notClickable = [nil, 1]  --  Disable the button and color the font white
	info.notCheckable = [nil, 1]  --  Shrink the size of the buttons and don't display a check box
	info.owner = [Frame]  --  Dropdown frame that "owns" the current dropdownlist
	info.keepShownOnClick = [nil, 1]  --  Don't hide the dropdownlist after a button is clicked
	info.tooltipTitle = [nil, STRING] -- Title of the tooltip shown on mouseover
	info.tooltipText = [nil, STRING] -- Text of the tooltip shown on mouseover
	info.tooltipOnButton = [nil, 1] -- Show the tooltip attached to the button instead of as a Newbie tooltip.
	info.justifyH = [nil, "CENTER"] -- Justify button text
	info.arg1 = [ANYTHING] -- This is the first argument used by info.func
	info.arg2 = [ANYTHING] -- This is the second argument used by info.func
	info.fontObject = [FONT] -- font object replacement for Normal and Highlight
	info.menuTable = [TABLE] -- This contains an array of info tables to be displayed as a child menu
	info.noClickSound = [nil, 1]  --  Set to 1 to suppress the sound when clicking the button. The sound only plays if .func is set.
	info.padding = [nil, NUMBER] -- Number of pixels to pad the text on the right side
	]]
  it = {};
  level, it.text, it.value, it.checked, it.hasArrow, it.func, it.arg1 = ...;
  UIDropDownMenu_AddButton(it, level);
  wipe(it);
end
function HealerManaGer_DropDownMenu_Init() -- TARGET MENU
	HealerManaGer_DropDownMenu.displayMode = "MENU"
	
	HealerManaGer_DropDownMenu.initialize = function(self, level)
		if level == 1 then
			HealerManaGer_AddDropDownItem(level, L["Track Current Energy"], nil, (HealerManaGerDB.TrackingMode == "TCE"), nil, HealerManaGer_SwitchTracking, "TCE", nil);
			HealerManaGer_AddDropDownItem(level, L["Track Mana"], nil, (HealerManaGerDB.TrackingMode == "TM"), nil, HealerManaGer_SwitchTracking, "TM", nil);
			HealerManaGer_AddDropDownItem(level, L["Track Health"], nil, (HealerManaGerDB.TrackingMode == "TH"), nil, HealerManaGer_SwitchTracking, "TH", nil);
		end
	end
end
function HealerManaGer_SwitchTracking(mode)
	if ( mode.arg1 == "TCE" or mode.arg1 == "TM" or mode.arg1 == "TH"   ) then
		HealerManaGerDB.TrackingMode = mode.arg1;
		HealerManaGer_SwitchMeanCount();
		currentPowerPerSecMax = 100;
	end
end
function HealerManaGer:InitFrame() -- ok
	HealerManaGerFrame:SetWidth(HealerManaGerDB.Params.Width);
	HealerManaGerFrame:SetHeight(59);
	local mFrameParentLevel = HealerManaGerFrame:GetFrameLevel();
	
	-- 1er systeme de barres
	local SGBG = CreateFrame("StatusBar", "ManaGainBarBG", HealerManaGerFrame);
	if ( ManaGainBarBG ) then
		SGBG:SetFrameLevel(mFrameParentLevel + 1);
		SGBG:SetWidth(HealerManaGerDB.Params.Width/2);
		SGBG:SetHeight(20);
		SGBG:SetPoint("CENTER",0,15);
		SGBG:SetPoint("RIGHT",0,15);
		SGBG:SetMinMaxValues(0, 100);
		SGBG:SetValue(100);
		SGBG:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		SGBG:SetStatusBarColor(0,0,0,1);
	end
	local S1 = CreateFrame("StatusBar", "ManaGainBar", HealerManaGerFrame);
	if ( ManaGainBar ) then
		S1:SetFrameLevel(mFrameParentLevel + 2);
		S1:SetWidth(HealerManaGerDB.Params.Width/2);
		S1:SetHeight(20);
		S1:SetPoint("CENTER",0,15);
		S1:SetPoint("RIGHT",0,15);
		S1:SetMinMaxValues(0, 100);
		S1:SetValue(0);
		S1:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		S1:SetStatusBarColor(0.1,0.8,0,1);
		
		local fs2 = ManaGainBar:CreateFontString("GainPerSecLabel", "OVERLAY", "GameFontNormal");
		if ( GainPerSecLabel ) then
			fs2:SetPoint("LEFT",0,0);
			fs2:SetText("233u/s");
		end
	end
	local SLBG = CreateFrame("StatusBar", "ManaLossBarBG", HealerManaGerFrame);
	if ( ManaLossBarBG ) then
		SLBG:SetFrameLevel(mFrameParentLevel + 1);
		SLBG:SetWidth(HealerManaGerDB.Params.Width/2);
		SLBG:SetHeight(20);
		SLBG:SetPoint("CENTER",0,15);
		SLBG:SetPoint("LEFT",0,15);
		SLBG:SetMinMaxValues(0, 100);
		SLBG:SetValue(100);
		SLBG:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		SLBG:SetStatusBarColor(0.8,0.1,0,1);
	end
	local S2 = CreateFrame("StatusBar", "ManaLossBar", HealerManaGerFrame);
	if ( ManaLossBar ) then
		S2:SetFrameLevel(mFrameParentLevel + 2);
		S2:SetWidth(HealerManaGerDB.Params.Width/2);
		S2:SetHeight(20);
		S2:SetPoint("CENTER",0,15);
		S2:SetPoint("LEFT",0,15);
		S2:SetMinMaxValues(0, 100);
		S2:SetValue(100);
		S2:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		S2:SetStatusBarColor(0,0,0,1);
		
		local fs2 = ManaLossBar:CreateFontString("LossPerSecLabel", "OVERLAY", "GameFontNormal");
		if ( LossPerSecLabel ) then
			fs2:SetPoint("RIGHT",0,0);
			fs2:SetText("233u/s");
		end
	end
	-- 2eme systeme de barres
	local SGBG2 = CreateFrame("StatusBar", "ManaGainBarBG2", HealerManaGerFrame);
	if ( ManaGainBarBG2 ) then
		SGBG2:SetFrameLevel(mFrameParentLevel + 1);
		SGBG2:SetWidth(HealerManaGerDB.Params.Width/2);
		SGBG2:SetHeight(5);
		SGBG2:SetPoint("CENTER",0,0);
		SGBG2:SetPoint("RIGHT",0,0);
		SGBG2:SetMinMaxValues(0, 100);
		SGBG2:SetValue(100);
		SGBG2:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		SGBG2:SetStatusBarColor(0,0,0,1);
	end
	local S12 = CreateFrame("StatusBar", "ManaGainBar2", HealerManaGerFrame);
	if ( ManaGainBar2 ) then
		S12:SetFrameLevel(mFrameParentLevel + 2);
		S12:SetWidth(HealerManaGerDB.Params.Width/2);
		S12:SetHeight(5);
		S12:SetPoint("CENTER",0,0);
		S12:SetPoint("RIGHT",0,0);
		S12:SetMinMaxValues(0, 100);
		S12:SetValue(0);
		S12:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		S12:SetStatusBarColor(0.1,0.8,0,1);
	end
	local SLBG2 = CreateFrame("StatusBar", "ManaLossBarBG2", HealerManaGerFrame);
	if ( ManaLossBarBG2 ) then
		SLBG2:SetFrameLevel(mFrameParentLevel + 1);
		SLBG2:SetWidth(HealerManaGerDB.Params.Width/2);
		SLBG2:SetHeight(5);
		SLBG2:SetPoint("CENTER",0,0);
		SLBG2:SetPoint("LEFT",0,0);
		SLBG2:SetMinMaxValues(0, 100);
		SLBG2:SetValue(100);
		SLBG2:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		SLBG2:SetStatusBarColor(0.8,0.1,0,1);
	end
	local S22 = CreateFrame("StatusBar", "ManaLossBar2", HealerManaGerFrame);
	if ( ManaLossBar2 ) then
		S22:SetFrameLevel(mFrameParentLevel + 2);
		S22:SetWidth(HealerManaGerDB.Params.Width/2);
		S22:SetHeight(5);
		S22:SetPoint("CENTER",0,0);
		S22:SetPoint("LEFT",0,0);
		S22:SetMinMaxValues(0, 100);
		S22:SetValue(100);
		S22:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		S22:SetStatusBarColor(0,0,0,1);
	end
	-- 3eme systeme de barre
	local SGBG3 = CreateFrame("StatusBar", "ManaPowerBarBG3", HealerManaGerFrame);
	if ( ManaPowerBarBG3 ) then
		SGBG3:SetFrameLevel(mFrameParentLevel + 1);
		SGBG3:SetWidth(HealerManaGerDB.Params.Width);
		SGBG3:SetHeight(20);
		SGBG3:SetPoint("CENTER",HealerManaGerDB.Params.Width/2,-15);
		SGBG3:SetPoint("LEFT",0,-15);
		SGBG3:SetMinMaxValues(0, 100);
		SGBG3:SetValue(100);
		SGBG3:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		SGBG3:SetStatusBarColor(0,0,0,1);
	end
	local S13 = CreateFrame("StatusBar", "ManaPowerBar3", HealerManaGerFrame);
	if ( ManaPowerBar3 ) then
		S13:SetFrameLevel(mFrameParentLevel + 2);
		S13:SetWidth(HealerManaGerDB.Params.Width);
		S13:SetHeight(15);
		S13:SetPoint("CENTER",HealerManaGerDB.Params.Width/2,-15);
		S13:SetPoint("LEFT",0,-15);
		S13:SetMinMaxValues(0, 100);
		S13:SetValue(100);
		S13:SetStatusBarTexture("Interface\\Buttons\\UI-Listbox-Highlight2");
		S13:SetStatusBarColor(0.3,0.3,0.9,1);
		
		local fs1 = ManaPowerBar3:CreateFontString("ManaPowerBarLabel", "OVERLAY", "GameFontNormal");
		if ( ManaPowerBarLabel ) then
			fs1:SetPoint("CENTER",0,0);
			fs1:SetText("-");
		end
		
		local fs2 = ManaPowerBar3:CreateFontString("EstimLossLabel", "OVERLAY", "GameFontNormal");
		if ( EstimLossLabel ) then
			fs2:SetPoint("LEFT",0,0);
			fs2:SetText("-");
		end
		
		local fs3 = ManaPowerBar3:CreateFontString("EstimGainLabel", "OVERLAY", "GameFontNormal");
		if ( EstimGainLabel ) then
			fs3:SetPoint("RIGHT",0,0);
			fs3:SetText("-");
		end
	end
	--
	HealerManaGer_DropDownMenu_Init();
	--SGBG:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, SGBG, 0, 0); end);
	--S1:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, S1, 0, 0); end);
	--SLBG:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, SLBG, 0, 0); end);
	--S2:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, S2, 0, 0); end);
	--SGBG2:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, SGBG2, 0, 0); end);
	--S12:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, S12, 0, 0); end);
	--SLBG2:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, SLBG2, 0, 0); end);
	--S22:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, S22, 0, 0); end);
	--SGBG3:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, SGBG3, 0, 0); end);
	--S13:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, S13, 0, 0); end);
	--HealerManaGerMinimapButton:SetScript("OnClick", function() ToggleDropDownMenu(1, nil, HealerManaGer_DropDownMenu, HealerManaGerMinimapButton, 0, 0); end);
end
function HealerManaGer:ResetBar(GuiBar) -- ok
	if ( GuiBar ) then
	
	end
end
function HealerManaGer:UpdateFrame() -- ok
end
function HealerManaGer:FormatAmountToPercentValue(val, precision, total)
	if ( val and precision and total ) then
		local percentVal = (val*100)/total;
		return tonumber(string.format("%."..tostring(precision).."f", percentVal));
	else
		return -1;
	end
end
function HealerManaGer:GetColorCodeFromRGB(red, green, blue) -- de 0 � 1 en float
	local codeWow = nil;
	if ( red and green and blue ) then
		local redColor = string.format("%0.2X", math.ceil(string.format("%.2f", red)*255));
		local greenColor = string.format("%0.2X", math.ceil(string.format("%.2f", green)*255));
		local blueColor = string.format("%0.2X", math.ceil(string.format("%.2f", blue)*255));
		codeWow = "|cFA"..tostring(redColor)..tostring(greenColor)..tostring(blueColor);
	end
	return codeWow; 
end
function HealerManaGer:GetColorCodeFromRGBStruct(rgbStruct) -- de 0 � 1 en float
	local codeWow = HealerManaGer:GetColorCodeFromRGB(rgbStruct.r, rgbStruct.g, rgbStruct.b);
	return codeWow; 
end
function HealerManaGer:UpdateFrame() -- ok
	
end
