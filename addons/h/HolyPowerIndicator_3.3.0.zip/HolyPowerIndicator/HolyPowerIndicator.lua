if select(2, UnitClass("player")) ~= "PALADIN" then
	return DisableAddOn("HolyPowerIndicator")
end

HolyPowerIndicator = LibStub("AceAddon-3.0"):NewAddon("HolyPowerIndicator", "AceEvent-3.0")

local textures = {
		["number"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\number_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\number_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\number_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\number_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\number_5",			
		},
		["alliance"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\alliance_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\alliance_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\alliance_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\alliance_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\alliance_5",
			},
		["blizzard"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\blizzard_1",			
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\blizzard_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\blizzard_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\blizzard_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\blizzard_5",
			},			
		["horde"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\horde_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\horde_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\horde_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\horde_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\horde_5",
		},
		["dot"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\dot_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\dot_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\dot_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\dot_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\dot_5",
		},
		["bar"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\bar_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\bar_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\bar_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\bar_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\bar_5",
		},
		["pvprank"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\pvprank_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\pvprank_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\pvprank_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\pvprank_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\pvprank_5",
		},
		["tukbar"] = {
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\tukbar_1",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\tukbar_2",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\tukbar_3",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\tukbar_4",
			"Interface\\AddOns\\HolyPowerIndicator\\Images\\tukbar_5",
		},
}

do
	local frame = CreateFrame("Frame", "HolyPowerIndicatorFrame", UIParent)
	frame:SetMovable(true)
	frame:SetUserPlaced(true)
	frame:SetPoint("CENTER")
	frame:SetWidth(128)
	frame:SetHeight(128)

	local texture = frame:CreateTexture(nil, "ARTWORK")
	texture:SetAllPoints(frame)

	HolyPowerIndicator.frame = frame

	frame.texture = texture
end

function HolyPowerIndicator:OnInitialize()
	local defaults = {
		profile = {
			locked = true,
			alpha = 1,
			scale = 1,
			textureSelect = "tukbar",
		},
	}

	self.db = LibStub("AceDB-3.0"):New("HolyPowerIndicatorDB", defaults, "Default")

	local options = {
		name = "HolyPowerIndicator",
		type ="group",
		args = {
			descr = {
				type = "description",
				order = 1,
				name = " HolyPowerIndicator Addon \n\n Simple Holy Power monitor that shows you how many charges you have. \n\n \"/hpi\" to open options frame. \n \"/hpi lock\" to lock/unlock frame \n\n More options/textures will be added in the future. \n PM me on curse  for suggestions.\n",

			},
			locked = {
				type = "toggle",
				name = "Lock frame",
				desc = "Locks the Holy Power frame.",
				width = "full",
				order = 2,
				get = function() return HolyPowerIndicator.db.profile.locked end,
				set = function(_, value)
						HolyPowerIndicator.db.profile.locked = value
						HolyPowerIndicator:ToggleFrameLock(value)
					end,
			},			
			alpha = {
				type = "range",
				name = "Frame opacity",
				desc = "Set the frame's opacity.",
				width = "normal",
				min = 0.1,
				max = 1,
				step = 0.1,
				order = 3,
				get = function() return HolyPowerIndicator.db.profile.alpha end,
				set = function(_, value) 
						HolyPowerIndicator.db.profile.alpha = value
						HolyPowerIndicator.frame:SetAlpha(value)
					end,
			},
			scale = {
				type = "range",
				name = "Frame scale",
				desc = "Set the frame's scale.",
				width = "normal",
				min = 0.2,
				max = 5,
				step = 0.2,
				order = 4,
				get = function() return HolyPowerIndicator.db.profile.scale end,
				set = function(_, value) 
						HolyPowerIndicator.db.profile.scale = value
						HolyPowerIndicator.frame:SetScale(value) 
					end,
			},
			textureSelect = {
				type = "select",
				name = "Texture",
				desc = "Select the texture.",
				width = "normal",
				values = {
					["blizzard"] = "Blizzard",
					["alliance"] = "Alliance",
					["horde"] = "Horde",					
					["bar"] = "Bar",
					["dot"] = "Dot",
					["number"] = "Number",
					["pvprank"] = "PvP Rank",
					["tukbar"] = "TukBar",
				},
				get = function() return HolyPowerIndicator.db.profile.textureSelect end,
				set= function(_, value) 
						HolyPowerIndicator.db.profile.textureSelect = value
					end,
			},
		},
	}

	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("HolyPowerIndicator", options)
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HolyPowerIndicator", "HolyPowerIndicator")

	PaladinPowerBar:SetAlpha(0)

	self.frame:SetAlpha(self.db.profile.alpha)
	self.frame:SetScale(self.db.profile.scale)
	self:ToggleFrameLock(self.db.profile.locked)

	SLASH_HOLYPOWERINDICATOR1 = "/hpi"
	SlashCmdList["HOLYPOWERINDICATOR"] = function(msg)
		if msg == "lock" then
			self:ToggleFrameLock()
		else
			InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
		end
	end

	self:RegisterEvent("UNIT_POWER")
end

function HolyPowerIndicator:ToggleFrameLock(value)
	if value ~= nil then
		value = self.db.profile.locked
	end

	local frame = self.frame

	if value then
		
		frame:EnableMouse(false)
		frame:RegisterForDrag(nil)
		frame:SetScript("OnDragStart", nil)
		frame:SetScript("OnDragStop", nil)
		if UnitPower("player", 9) == 0 then
			frame:Hide()
			print("HolyPowerIndicator locked")
		end

	else

		frame:EnableMouse(true)
		frame:RegisterForDrag("LeftButton")
		frame:SetScript("OnDragStart", frame.StartMoving)
		frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
		if UnitPower("player", 9) == 0 then
			frame.texture:SetTexture(textures[self.db.profile.textureSelect][5])
			frame:Show()
			print("HolyPowerIndicator unlocked")
		end
	end

	self.db.profile.locked = value
end

function HolyPowerIndicator:UNIT_POWER(event, unit, powerType)
	if unit == "player" and powerType == "HOLY_POWER" then
		local power = UnitPower("player", 9)
		if power > 0 then
			self.frame.texture:SetTexture(textures[self.db.profile.textureSelect][power])
			self.frame:Show()
		else
			self.frame:Hide()
		end
	end
end
