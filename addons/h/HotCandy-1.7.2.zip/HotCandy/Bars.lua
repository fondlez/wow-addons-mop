--[[
  Copyright (c) 2010-2012, Hendrik "Nevcairiel" Leppkes < h.leppkes@gmail.com >
  All rights reserved.
]]
local _, HotCandy = ...

-- Lua APIs
local wipe, tinsert, sort, pairs = table.wipe, table.insert, table.sort, pairs

-- WoW APIs
local CreateFrame = CreateFrame

-- Global vars/functions that we don't upvalue since they might get hooked, or upgraded
-- List them here for Mikk's FindGlobals script
-- GLOBALS: GameTooltip, GameFontNormal, UIParent, InterfaceOptionsFrame_OpenToCategory

local media = LibStub("LibSharedMedia-3.0")
local window = LibStub("LibWindow-1.1")

local db
local barsgroup, bars, anchor = nil, {}, anchor

function HotCandy:StartBar(id, text, duration, icon)
	bars[id] = barsgroup:NewTimerBar(id, text, duration, nil, icon)
	bars[id].RegisterCallback(self, "TimerFinished")
end

function HotCandy:StopBar(id)
	if bars[id] then
		bars[id]:SetTimer(0.001)
	end
end

function HotCandy:TimerFinished(event, bar, id)
	bars[id] = nil
end

local createAnchor
do
	local function onDragStart(self) self:StartMoving() end
	local function onDragStop(self)
		self:StopMovingOrSizing()
		window.SavePosition(self)
	end

	local function onControlEnter(self)
		GameTooltip:ClearLines()
		GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
		GameTooltip:AddLine(self.tooltipHeader)
		GameTooltip:AddLine(self.tooltipText, 1, 1, 1, 1)
		GameTooltip:Show()
	end
	local function onControlLeave() GameTooltip:Hide() end

	function createAnchor()
		local display = CreateFrame("Frame", "HotCandyAnchor", UIParent)
		display:EnableMouse(true)
		display:SetMovable(true)
		display:SetResizable(true)
		display:RegisterForDrag("LeftButton")
		display:SetHeight(20)
		display:SetWidth(db.width)
		display:SetFrameStrata("DIALOG")
		local bg = display:CreateTexture(nil, "PARENT")
		bg:SetAllPoints(display)
		bg:SetBlendMode("BLEND")
		bg:SetTexture(0, 0, 0, 0.3)
		local header = display:CreateFontString(nil, "OVERLAY")
		header:SetFontObject(GameFontNormal)
		header:SetText("HotCandy")
		header:SetAllPoints(display)
		header:SetJustifyH("CENTER")
		header:SetJustifyV("MIDDLE")
		local test = CreateFrame("Button", nil, display)
		test:SetPoint("BOTTOMLEFT", display, "BOTTOMLEFT", 3, 3)
		test:SetHeight(14)
		test:SetWidth(14)
		test.tooltipHeader = "Test"
		test.tooltipText = "Creates a new test bar."
		test:SetScript("OnEnter", onControlEnter)
		test:SetScript("OnLeave", onControlLeave)
		test:SetScript("OnClick", function() HotCandy:TestBars() end)
		test:SetNormalTexture("Interface\\AddOns\\HotCandy\\icons\\test")
		local close = CreateFrame("Button", nil, display)
		close:SetPoint("BOTTOMRIGHT", display, "BOTTOMRIGHT", -3, 3)
		close:SetHeight(14)
		close:SetWidth(14)
		close.tooltipHeader = "Hide"
		close.tooltipText = "Hides the anchors."
		close:SetScript("OnEnter", onControlEnter)
		close:SetScript("OnLeave", onControlLeave)
		close:SetScript("OnClick", function() HotCandy:ToggleAnchor() end)
		close:SetNormalTexture("Interface\\AddOns\\HotCandy\\icons\\close")
		local settings = CreateFrame("Button", nil, display)
		settings:SetPoint("BOTTOMRIGHT", close, "BOTTOMLEFT", -2, -1)
		settings:SetHeight(16)
		settings:SetWidth(16)
		settings.tooltipHeader = "Settings"
		settings.tooltipText = "Open the HotCandy settings."
		settings:SetScript("OnEnter", onControlEnter)
		settings:SetScript("OnLeave", onControlLeave)
		settings:SetScript("OnClick", function() InterfaceOptionsFrame_OpenToCategory("HotCandy") end)
		settings:SetNormalTexture("Interface\\AddOns\\HotCandy\\icons\\config")
		display:SetScript("OnDragStart", onDragStart)
		display:SetScript("OnDragStop", onDragStop)
		--display:SetScript("OnMouseDown", displayOnMouseDown)
		display:Hide()
		return display
	end
end

-- custom sort function to sort by time remaining
local sortFunc = function(a,b)
	if a.isTimer ~= b.isTimer then
		return a.isTimer
	end

	local av, bv = a.value, b.value
	if av == bv then
		if a.maxValue == b.maxValue then
			return a.name < b.name
		else
			return a.maxValue < b.maxValue
		end
	else
		return av < bv
	end
end


function HotCandy:CreateAnchor()
	db = HotCandy.db.profile

	-- Setup LibBars-1.0 Group
	barsgroup = self:NewBarGroup("HotCandy", nil, db.width, db.height)
	barsgroup:SetSortFunction(sortFunc)
	barsgroup:HideAnchor()

	-- Start in Green
	barsgroup:SetColorAt(1, 0, 1, 0, 1)
	-- to Yellow
	barsgroup:SetColorAt(0.5, 1, 1, 0, 1)
	-- and finish in Red
	barsgroup:SetColorAt(0.15, 1, 0, 0, 1)

	anchor = createAnchor()

	media.RegisterCallback(self, "LibSharedMedia_SetGlobal", function(mtype, override)
		if mtype == "statusbar" then
			barsgroup:SetTexture(media:Fetch("statusbar", override))
		end
	end)

	media.RegisterCallback(self, "LibSharedMedia_Registered", function(mtype, key)
		if mtype == "statusbar" and key == db.texture then
			barsgroup:SetTexture(media:Fetch("statusbar", db.texture))
		end
	end)

	if db.unlocked then
		anchor:Show()
	end
end

function HotCandy:ToggleAnchor()
	db.unlocked = not db.unlocked
	if db.unlocked then
		anchor:Show()
	else
		anchor:Hide()
	end
end

function HotCandy:RefreshAnchor()
	db = HotCandy.db.profile
	window.RegisterConfig(anchor, db.position)
	window.RestorePosition(anchor)
	anchor:SetWidth(db.width)

	barsgroup:SetScale(db.scale)
	barsgroup:ReverseGrowth(db.growup)
	barsgroup:SetTexture(media:Fetch("statusbar", db.texture))
	barsgroup:SetWidth(db.width)
	barsgroup:SetHeight(db.height)
	barsgroup:SetFlashTrigger(db.flash)

	barsgroup:ClearAllPoints()
	if db.growup then
		barsgroup:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT")
	else
		barsgroup:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT")
	end
end

function HotCandy:TestBars()
	self:StartBar("HotCandyTestBar1", "Test Bar 1", 12, "Interface\\AddOns\\HotCandy\\icons\\test")
	self:StartBar("HotCandyTestBar2", "Test Bar 2", 7, "Interface\\AddOns\\HotCandy\\icons\\test")
	self:StartBar("HotCandyTestBar3", "Test Bar 3", 20, "Interface\\AddOns\\HotCandy\\icons\\test")
	self:StartBar("HotCandyTestBar4", "Test Bar 4", 15, "Interface\\AddOns\\HotCandy\\icons\\test")
end
