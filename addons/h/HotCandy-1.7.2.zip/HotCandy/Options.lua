--[[
  Copyright (c) 2010-2012, Hendrik "Nevcairiel" Leppkes < h.leppkes@gmail.com >
  All rights reserved.
]]
local _, HotCandy = ...

-- Lua APIs
local pairs = pairs

-- Global vars/functions that we don't upvalue since they might get hooked, or upgraded
-- List them here for Mikk's FindGlobals script
-- GLOBALS: LibStub, AceGUIWidgetLSMlists, InterfaceOptionsFrame_OpenToCategory

local media = LibStub("LibSharedMedia-3.0")

local db
local createOptionsTable
do
	local options
	local function optGet(info)
		return db[info.arg or info[#info]]
	end

	local function optSet(info, value)
		db[info.arg or info[#info]] = value
		HotCandy:Refresh()
	end

	local function getSpellMulti(info, key)
		return db.spells[key]
	end

	local function setSpellMulti(info, key, value)
		db.spells[key] = value
		HotCandy:Refresh()
	end

	function createOptionsTable()
		if not options then
			local spellNames = {}
			for k,v in pairs(HotCandy.nameLookup) do
				spellNames[v] = k
			end

			options = {
				name = "HotCandy",
				type = "group",
				get = optGet,
				set = optSet,
				handler = HotCandy,
				args = {
					intro = {
						cmdHidden = true,
						order = 1,
						type = "description",
						name = "You can control the behaviour and the style of HotCandy using the settings below.",
					},
					unlock = {
						order = 10,
						type = "execute",
						name = "Toggle Bar Anchor",
						desc = "Show/Hide the Bar Anchor to move the bars.",
						func = function() HotCandy:ToggleAnchor() end
					},
					br0 = {
						cmdHidden = true,
						order = 11,
						type = "description",
						name = "",
					},
					growup = {
						order = 15,
						name = "Grow Up",
						desc = "Toggle grow direction of the bars",
						type = "toggle",
					},
					texture = {
						order = 20,
						type = "select",
						name = "Texture",
						desc = "Set the texture for the bars.",
						values = media:HashTable("statusbar"),
						dialogControl = AceGUIWidgetLSMlists and "LSM30_Statusbar" or nil,
					},
					br1 = {
						cmdHidden = true,
						type = "description",
						order = 29,
						name = "",
					},
					width = {
						order = 30,
						type = "range",
						name = "Bar Width",
						desc = "Set the width of the bars.",
						min = 50, max = 500, step = 1,
					},
					height = {
						order = 31,
						type = "range",
						name = "Bar Height",
						desc = "Set the height of the bars.",
						min = 5, max = 50, step = 1,
					},
					scale = {
						order = 32,
						type = "range",
						name = "Bar Scale",
						desc = "Set the scale of the bars.",
						min = .1, max = 2, step = 0.01,
						isPercent = true,
					},
					br2 = {
						cmdHidden = true,
						type = "description",
						order = 34,
						name = "",
					},
					flash = {
						order = 35,
						type = "range",
						name = "Flash",
						desc = "Configure at which time-left the Bars should start flashing.",
						min = 0, max = 5, step = 0.2,
					},
					format = {
						order = 40,
						type = "group",
						name = "Text Format",
						desc = "Configure the format of the text on the timer bar.",
						dialogInline = true,
						args = {
							noname = {
								type = "toggle",
								name = "No HoT name",
								desc = "Do not show the name of the HoT.",
							},
							stackfirst = {
								type = "toggle",
								name = "Stack First",
								desc = "Show HoT stack count before the name.",
							},
						},
					},
					spells = {
						order = 50,
						type = "multiselect",
						name = "Tracked Spells",
						values = spellNames,
						get = getSpellMulti,
						set = setSpellMulti,
					},
				}
			}
		end
		return options
	end
end

function HotCandy:CreateOptions()
	db = HotCandy.db.profile

	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("HotCandy", createOptionsTable)
	local optFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HotCandy")

	local openFunc = function()
		InterfaceOptionsFrame_OpenToCategory(optFrame)
	end
	LibStub("AceConsole-3.0"):RegisterChatCommand("hot", openFunc)
	LibStub("AceConsole-3.0"):RegisterChatCommand("hotcandy", openFunc)
end

function HotCandy:RefreshOptions()
	db = HotCandy.db.profile
end
