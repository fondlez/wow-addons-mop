﻿HeyMon = LibStub("AceAddon-3.0"):NewAddon("HeyGratsMon", "AceConsole-3.0","AceTimer-3.0","AceEvent-3.0")

function HeyMon:PLAYER_LEVEL_UP()
	PlaySoundFile("sound\\CREATURE\\MANDOKIR\\VO_ZG2_MANDOKIR_LEVELUP_EVENT_01.ogg")
	HeyMon:ScheduleTimer("TimerFeedback", 1.2)
end

function HeyMon:TimerFeedback()
	PlaySoundFile("sound\\CREATURE\\JINDO\\VO_ZG2_JINDO_MANDOKIR_LEVELS_UP_01.ogg")
end

HeyMon:RegisterEvent("PLAYER_LEVEL_UP")