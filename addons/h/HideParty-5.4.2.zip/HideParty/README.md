﻿# HideParty

HideParty allows a user to hide various parts of the default WoW user interface.

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)][1]

### [Main Page][2]
The main page for HideParty on Curse.

### [Development Page][3]
The development page for HideParty on CurseForge.

### Addon Usage
HideParty has an interface options menu. Type /hp options to open the options menu.

 [1]: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VJ6HSZRRJXX5C
 [2]: http://www.curse.com/addons/wow/hideparty
 [3]: http://wow.curseforge.com/addons/hideparty
