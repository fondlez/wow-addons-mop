﻿local L = LibStub("AceLocale-3.0"):NewLocale("HideParty", "zhCN")
if not L then return end

L["BUFF"] = "Buff" -- Requires localization
L["BUFF_DESC"] = "Hide buffs." -- Requires localization
L["CAST"] = "Cast" -- Requires localization
L["CAST_DESC"] = "Hide cast bar." -- Requires localization
L["GENERAL"] = "General" -- Requires localization
L["GROUP"] = "Group" -- Requires localization
L["GROUP_DESC"] = "Hide 4.0 and later group and raid frames." -- Requires localization
L["PARTY"] = "Party" -- Requires localization
L["PARTY_DESC"] = "Hide legacy party frames." -- Requires localization
L["PLAYER"] = "Player" -- Requires localization
L["PLAYER_DESC"] = "Hide player frame." -- Requires localization
L["TARGET"] = "Target" -- Requires localization
L["TARGET_DESC"] = "Hide target frame." -- Requires localization

