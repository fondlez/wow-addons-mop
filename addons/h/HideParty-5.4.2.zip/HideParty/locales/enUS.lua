﻿local L = LibStub("AceLocale-3.0"):NewLocale("HideParty", "enUS")
if not L then return end

L["BUFF"] = "Buff"
L["BUFF_DESC"] = "Hide buffs."
L["CAST"] = "Cast"
L["CAST_DESC"] = "Hide cast bar."
L["GENERAL"] = "General"
L["GROUP"] = "Group"
L["GROUP_DESC"] = "Hide 4.0 and later group and raid frames."
L["PARTY"] = "Party"
L["PARTY_DESC"] = "Hide legacy party frames."
L["PLAYER"] = "Player"
L["PLAYER_DESC"] = "Hide player frame."
L["TARGET"] = "Target"
L["TARGET_DESC"] = "Hide target frame."

