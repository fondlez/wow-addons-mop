﻿local L = LibStub("AceLocale-3.0"):NewLocale("HideParty", "koKR")
if not L then return end

L["BUFF"] = "버프" -- Needs review
L["BUFF_DESC"] = "버프 숨깁니다." -- Needs review
L["CAST"] = "캐스트" -- Needs review
L["CAST_DESC"] = "캐스팅바를 숨깁니다." -- Needs review
L["GENERAL"] = "일반" -- Needs review
L["GROUP"] = "그룹" -- Needs review
L["GROUP_DESC"] = "4.0 이상 그룹와 레이드 프레임을 숨길 수 있습니다." -- Needs review
L["PARTY"] = "파티" -- Needs review
L["PARTY_DESC"] = "기존 파티 프레임을 숨깁니다." -- Needs review
L["PLAYER"] = "플레이어" -- Needs review
L["PLAYER_DESC"] = "플레이어 프레임을 숨깁니다." -- Needs review
L["TARGET"] = "타켓" -- Needs review
L["TARGET_DESC"] = "타켓 프레임을 숨깁니다." -- Needs review

