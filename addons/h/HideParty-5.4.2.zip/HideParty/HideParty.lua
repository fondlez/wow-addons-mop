﻿--[[
    HideParty.lua

    This file is part of HideParty. <http://www.curse.com/addons/wow/hideparty>
    Copyright (C) 2010-2014 Matthew Casey

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
]]

HideParty = LibStub("AceAddon-3.0"):NewAddon("HideParty", "AceConsole-3.0", "AceEvent-3.0")
local version = GetAddOnMetadata("HideParty", "Version")
local L = LibStub("AceLocale-3.0"):GetLocale("HideParty")
local options = {
	name = "HideParty",
	handler = HideParty,
	type = 'group',
	args = {
		hide = {
			name = L["GENERAL"],
			handler = HideParty,
			type = 'group',
			args = {
				buff = {
					type = 'toggle',
					name = L["BUFF"],
					desc = L["BUFF_DESC"],
					get = 'GetFrame',
					set = 'SetFrame'
				},
				cast = {
					type = 'toggle',
					name = L["CAST"],
					desc = L["CAST_DESC"],
					get = 'GetFrame',
					set = 'SetFrame'
				},
				group = {
					type = 'toggle',
					name = L["GROUP"],
					desc = L["GROUP_DESC"],
					get = 'GetFrame',
					set = 'SetFrame'
				},
				party = {
					type = 'toggle',
					name = L["PARTY"],
					desc = L["PARTY_DESC"],
					get = 'GetFrame',
					set = 'SetFrame'
				},
				player = {
					type = 'toggle',
					name = L["PLAYER"],
					desc = L["PLAYER_DESC"],
					get = 'GetFrame',
					set = 'SetFrame'
				},
				target = {
					type = 'toggle',
					name = L["TARGET"],
					desc = L["TARGET_DESC"],
					get = 'GetFrame',
					set = 'SetFrame'
				},
			},
		},
	},
}

local show = {
	buff,
	cast,
	group,
	party,
	player,
	target
}
local hide = {
	buff,
	cast,
	group,
	party,
	player,
	target
}
local hidden = {
	buff,
	cast,
	group,
	party,
	player,
	target
}

local defaults = {
	profile = {
		buff = false,
		cast = false,
		group = true,
		party = true,
		player = true,
		target = true
	},
}

local isPrinted = false

function HideParty:GetFrame(info, value)
	return self.db.profile[info[#info]]
end

function HideParty:SetFrame(info, value)
	self.db.profile[info[#info]] = value
	self:UpdateFrames()
end

local function hook_playerframe()
	hooksecurefunc("PlayerFrame_HideVehicleTexture",function()
		if hidden["runebar"] then
			hide["runebar"]()
		end
	end)
	hook_playerframe = nil
end

local function hook_raidmanager()
	hooksecurefunc("CompactRaidFrameManager_UpdateShown",function()
		if hidden["group"] then
			hide["group"]()
		end
	end)
	hook_raidmanager = nil
end

function hide:runebar()
	if hook_playerframe then
		hook_playerframe()
	end
	RuneFrame:UnregisterAllEvents()
	RuneFrame:Hide()
end

function show:runebar()
	local _,class = UnitClass("player")
	if class == "DEATHKNIGHT" then
		RuneFrame:Show()
	end
	RuneFrame:GetScript("OnLoad")(RuneFrame)
	RuneFrame:GetScript("OnEvent")(RuneFrame, "PLAYER_ENTERING_WORLD")
end

function hide:buff()
	BuffFrame:Hide()
	TemporaryEnchantFrame:Hide()
	ConsolidatedBuffs:Hide()
	BuffFrame:UnregisterAllEvents()
end

function show:buff()
	BuffFrame:Show()
	if GetCVarBool("consolidateBuffs") then
		ConsolidatedBuffs:Show()
	end
	TemporaryEnchantFrame:Show()
	BuffFrame:RegisterEvent("UNIT_AURA")
end

function hide:cast()
	CastingBarFrame:UnregisterAllEvents()
	PetCastingBarFrame:UnregisterAllEvents()
end

function show:cast()
	CastingBarFrame:GetScript("OnLoad")(CastingBarFrame)
	PetCastingBarFrame:GetScript("OnLoad")(PetCastingBarFrame)
end

function hide:player()
	PlayerFrame:Hide()
	hide:runebar()
end

function show:player()
	PlayerFrame:Show()
	show:runebar()
end

function hide:party()
	for i = 1, 4 do
		local frame = _G["PartyMemberFrame"..i]
		frame:UnregisterAllEvents()
		frame:Hide()
		frame.Show = function() end
	end
	UIParent:UnregisterEvent("GROUP_ROSTER_UPDATE")
end

function show:party()
	for i = 1, 4 do
		local frame = _G["PartyMemberFrame"..i]
		frame.Show = nil
		frame:GetScript("OnLoad")(frame)
		frame:GetScript("OnEvent")(frame, "GROUP_ROSTER_UPDATE")
		
		PartyMemberFrame_UpdateMember(frame)
	end

	UIParent:RegisterEvent("GROUP_ROSTER_UPDATE")
end

local compact_raid
function hide:group()
	if CompactRaidFrameManager ~= nil then
		CompactRaidFrameManager:UnregisterEvent("GROUP_ROSTER_UPDATE")
		CompactRaidFrameManager:UnregisterEvent("PLAYER_ENTERING_WORLD")
		CompactRaidFrameManager:Hide()
		compact_raid = CompactRaidFrameManager_GetSetting("IsShown")
		if compact_raid and compact_raid ~= "0" then
			CompactRaidFrameManager_SetSetting("IsShown", "0")
		end
		if hook_raidmanager then
			hook_raidmanager()
		end
	end
end

function show:group()
	if CompactRaidFrameManager ~= nil then
		CompactRaidFrameManager:RegisterEvent("GROUP_ROSTER_UPDATE")
		CompactRaidFrameManager:RegisterEvent("PLAYER_ENTERING_WORLD")
		if GetDisplayedAllyFrames then
			if GetDisplayedAllyFrames() == "raid" then
				CompactRaidFrameManager:Show()
			end
		elseif GetNumRaidMembers() > 0 then
			CompactRaidFrameManager:Show()
		end
		if compact_raid and compact_raid ~= "0" then
			CompactRaidFrameManager_SetSetting("IsShown", "1")
		end
	end
end

function hide:target()
	TargetFrame:UnregisterAllEvents()
	TargetFrame:Hide()
	ComboFrame:UnregisterAllEvents()
end

function show:target()
	TargetFrame:GetScript("OnLoad")(TargetFrame)
	ComboFrame:GetScript("OnLoad")(ComboFrame)
end

function HideParty:UpdateFrames()
	if InCombatLockdown() then
		if not isPrinted then
			self:Print("Disabled during combat")
			isPrinted = true;
		end
	else
		for frame in pairs(show) do
			if self:IsEnabled() and self.db.profile[frame] then
				if not hidden[frame] then
					hidden[frame] = true
					hide[frame](self)
				end
			else
				if hidden[frame] then
					hidden[frame] = nil
					show[frame](self)
				end
			end
		end
	end
end

function HideParty:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("HideParty5DB", defaults, "Default")
	self.db.RegisterCallback(self, "OnProfileChanged", "UpdateFrames")
	self.db.RegisterCallback(self, "OnProfileCopied", "UpdateFrames")
	self.db.RegisterCallback(self, "OnProfileReset", "UpdateFrames")
	options.args.profile = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
	LibStub("AceConfig-3.0"):RegisterOptionsTable("HideParty", options)
	self.Options = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HideParty")
end

function HideParty:OnEnable()
	self:RegisterChatCommand("HP", "SlashCommand")
	self:RegisterChatCommand("HIDEPARTY", "SlashCommand")
	self:ShowVersion()
	self:UpdateFrames()
end

function HideParty:ShowVersion()
	self:Print("HideParty version", version)
end

function HideParty:SlashCommand(input)
	if input == "version" then
		self:ShowVersion()
	elseif input == "options" then
		InterfaceOptionsFrame_OpenToCategory(self.Options)
	else
		self:Print("/hp options")
		self:Print("/hp version")
	end
end
