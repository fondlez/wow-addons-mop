local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5")

-- Locals
local DISPLAYMODE_STANDARD = 1
local DISPLAYMODE_STANDARD_NUMBERS_FIRST = 2
local DISPLAYMODE_NUMBERS_ONLY = 3
local DISPLAYMODE_CUSTOM = 4

local SPELLDISPLAYMODE_TEXT = 1
local SPELLDISPLAYMODE_ABBREVIATED_TEXT = 2
local SPELLDISPLAYMODE_LINK = 3
local SPELLDISPLAYMODE_ABBREVIATED_LINK = 4
local SPELLDISPLAYMODE_NONE = 5

local FLAG_CRITS = 1
local FLAG_HEALS = 2
local FLAG_PET_DAMAGE = 3
local FLAG_ENERGIZES = 4
local FLAG_EXP = 5
local FLAG_HONOR = 6
local FLAG_REP = 7

local UNITCOMPARISONMODE_OR = 1
local UNITCOMPARISONMODE_AND = 2



local newOrder
do
	local current = 0
	function newOrder()
		current = current + 1
		return current
	end
end


local function removeRemoveOptions(t)
 for k, v in pairs(t) do
		if k == "includeInReplay" then
			t[k] = nil
		else
			if type(v) == "table" then
					removeRemoveOptions(t[k], v)
			end
		end
 end
end


function HitsMode5.Filter:AddOptions(add)
	local db = self.db
	local thisFilter = self
	
	local options
	options = {
  type = "group",
		name = function() return db.name end,
		desc = function()
			if db.enabled then return L["Currently |cff20ff20enabled|r."] else return L["Currently |cffff2020disabled|r."] end
		end,
  args = {


--[[ Filter root menu ]] ------------------------------------------------------------------------------------------------------------

			enable = {
				type = "toggle",
				name = L["Enable filter"],
				desc = L["Enables the filter."],
				get = function() return db.enabled end,
				set = function(win, val) db.enabled = val end,
				order = newOrder(),
				includeInReplay = false,
			}, -- enable
			
			
			rename = {
				type = "input",
				name = L["Rename filter"],
				desc = L["Enter the name for the filter."],
				get = function() return db.name end,
				set = function(win, val) if val ~= db.name and val ~= "" then db.name = val end end,
				order = newOrder(),
				includeInReplay = false,
			}, -- rename
			
			
			copy = {
				type = "input",
				name = L["Copy filter"],
				desc = L["Create a copy of this filter by entering a new name and clicking Okay."],
				get = function() return "" end,
				set = function(self, val)
					if val and val ~= "" then
						if HitsMode5.options.args.filters.args[val] then
							StaticPopupDialogs["HitsMode5CopyDuplicate"] = {
												text = L["You entered a name that already exists. To copy a filter, enter a unique filter name."],
												button1 = ACCEPT,
												timeout = 30,
												whileDead = 0,
												hideOnEscape = 1,
											}
							StaticPopup_Show("HitsMode5CopyDuplicate")
						else
							local newFilter = {}
							HitsMode5:tcopy(newFilter, db)
							newFilter.name = val
							table.insert(HitsMode5.db.profile.filters, newFilter)
							HitsMode5:CreateFilter(val, newFilter)
						end
					end
				end,
				order = newOrder(),
				includeInReplay = false,
			}, -- copy
			
		
			delete = {
				type = "execute",
				name = L["Delete filter"],
				desc = L["Deletes this filter."],
				confirm = true,
				confirmText = L["Are you sure you want to delete this filter?"],
				func = function(s) HitsMode5:DeleteFilter(db.name) end,
				order = newOrder(),
				includeInReplay = false,
			}, -- delete
			
			
--[[ Display ]]----------------------------------------------------------------------------------------------------------------------

			display = {
				type = "group",
				name = L["Display"],
				desc = L["Options governing how the combat log text is rendered to your chat frame."],
				order = newOrder(),
				args = {
				
					-------- [[ Chat Window ]]--------
					head = {
						type = "header",
						name = L["Chat Window"],
						order = newOrder()
					},
					
					chatWindow = {
						includeInReplay = false,
						order = newOrder(),
						type = "select",
						name = L["Chat window"],
						desc = L["Select which chat window to use for this filter's combat log output. You cannot use chat window 2, which is the default Blizzard Combat Log."],
						values = function()
							local names = {}
							for i = 1, NUM_CHAT_WINDOWS do
								if i ~= 2 then
									local name, fontSize, r, g, b, alpha, shown, locked, docked, uninteractable = GetChatWindowInfo(i)
									local chatFrame = _G["ChatFrame"..i]
									local closed = "  |cffff2020[closed]|r"
									if chatFrame then
										if shown or chatFrame.isDocked then
											closed = ""
										end
									end
									names[i] = format("%d. %s%s", i, name, closed)
								end
							end
							return names
						end,
						get = function() return db.display.chatWindow or 7 end,
						set = function(self, val) db.display.chatWindow = val end,
					}, -- chatWindow
					
					chatWindowReminder = {
						includeInReplay = false,
						order = newOrder(),
						type = "execute",
						name = L["Chat window reminder"],
						desc = L["Prints some text into all open chat windows, to remind you which is which."],
						func = function()
							for i = 1, NUM_CHAT_WINDOWS do
								if i ~= 2 then
									local name, fontSize, r, g, b, alpha, shown, locked, docked, uninteractable = GetChatWindowInfo(i)
									local chatFrame = _G["ChatFrame"..i]
									if chatFrame then
										if shown or chatFrame.isDocked then
											chatFrame:AddMessage(format(L["This is chat window %d"], i))
										end
									end
								end
							end
						end,
					}, -- chatWindowReminder
					
					chatWindowOpen = {
						includeInReplay = false,
						order = newOrder(),
						type = "execute",
						name = L["Open chat window"],
						desc = L["Opens the selected chat window if it is closed."],
						func = function()
							local chatFrame = _G["ChatFrame"..db.display.chatWindow]
							if chatFrame then
								if shown or chatFrame.isDocked then
									return
								end
							end
							HitsMode5:OpenChatWindow(db.display.chatWindow)
						end,
					}, -- chatWindowOpen
					
					chatWindowOpenDesc = {
						includeInReplay = false,
						type = "description",
						name = L["If you can't find the chat window, it may have become docked next to another chat window."],
						order = newOrder()
					},
					
					valueThreshold = {
						order = newOrder(),
						type = "range",
						name = L["Value threshold"],
						desc = L["Combat log messages with a value below this setting will not be displayed. This can be useful to prevent spam from very small events."],
						min = 0,
						max = 5000,
						step = 1,
						get = function() return db.display.valueThreshold or 0 end,
						set = function(self, val) db.display.valueThreshold = val end,
					}, -- valueThreshold
					

					-------- [[ Text Layout ]]--------
					desc = {
						includeInReplay = false,
						type = "description",
						name = "\n",
						order = newOrder()
					},
					head2 = {
						type = "header",
						name = L["Text Layout"],
						order = newOrder()
					},
					
					displayMode = {
						order = newOrder(),
						type = "select",
						name = L["Display mode"],
						desc = format(L["Sets the display mode for this filter.\n\n|cffffff20%s|r:\n  [You] hit [Monster] for 12\n\n|cffffff20%s|r:\n  12 - [You] hit [Monster]\n\n|cffffff20%s|r:\n  12\n\n|cffffff20%s|r:\n  A custom format specified below."], L["Standard"], L["Standard (numbers first)"], L["Numbers only"], L["Custom"]),
						values = {
							[DISPLAYMODE_STANDARD] = L["Standard"],
							[DISPLAYMODE_STANDARD_NUMBERS_FIRST] = L["Standard (numbers first)"],
							[DISPLAYMODE_NUMBERS_ONLY] = L["Numbers only"],
							[DISPLAYMODE_CUSTOM] = L["Custom"],
						},
						get = function() return db.display.displayMode or 1 end,
						set = function(self, val) db.display.displayMode = val end,
					}, -- displayMode
					
					includeFor = {
						order = newOrder(),
						type = "toggle",
						name = L["Include the word \"for\""],
						desc = format(L["Includes the word \"for\" in most combat log output. This only applies to the |cffffff20%s|r display mode."], L["Standard"]),
						disabled = function()
							if db.display.displayMode == nil then return false end
							return db.display.displayMode ~= DISPLAYMODE_STANDARD and db.display.displayMode ~= DISPLAYMODE_CUSTOM
						end,
						get = function() return db.display.includeFor end,
						set = function(self, val) db.display.includeFor = val end,
					}, -- includeFor
					
					includeExtraValues = {
						order = newOrder(),
						type = "toggle",
						name = L["Include extra values"],
						desc = format(L["Defines whether resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values should be shown after regular damage. Also shows the energy type for energizes, and the miss type for misses.\n\nNot available for the |cffffff20%s|r display mode."], L["Numbers only"]),
						disabled = function()
							if db.display.displayMode == nil then return false end
							return db.display.displayMode == DISPLAYMODE_NUMBERS_ONLY
						end,
						get = function() return db.display.includeExtraValues end,
						set = function(self, val) db.display.includeExtraValues = val end,
					}, -- includeExtraValues

					abbreviateExtraValues = {
						order = newOrder(),
						type = "toggle",
						name = L["Abbreviate extra values"],
						desc = L["Resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values will be abbreviated to just their first letter. Does not affect energy types or miss types."],
						disabled = function()
							if db.display.displayMode == nil then return false end
							return db.display.displayMode == DISPLAYMODE_NUMBERS_ONLY or db.display.includeExtraValues == false
						end,
						get = function() return db.display.abbreviateExtraValues end,
						set = function(self, val) db.display.abbreviateExtraValues = val end,
					}, -- abbreviateExtraValues

					includeRestedExperience = {
						includeInReplay = false,
						order = newOrder(),
						type = "toggle",
						name = L["Include rested experience"],
						desc = L["When showing experience gain, separately show the amount of experience that was rested."],
						get = function() return db.display.includeRestedExperience end,
						set = function(self, val) db.display.includeRestedExperience = val end,
					}, -- includeRestedExperience
					
					combatSeparator = {
						includeInReplay = false,
						order = newOrder(),
						type = "input",
						name = L["Combat separator"],
						desc = L["Enter text to be placed in the chat window when you leave combat. This helps break up the combat log from fight to fight.\n\nDoes not affect replayed combat logs.\n\nTo disable this feature, empty this text box and click Okay."],
						get = function() return db.display.combatSeparator or "~~~~~" end,
						set = function(self, val) db.display.combatSeparator = val end,
					}, -- combatSeparator
					
					customFormat = {
						order = newOrder(),
						type = "input",
						width = "full",
						name = L["Custom display format"],
						desc = L["Uses a tag system to let you create your own combat log formats. Any tags not used in a given event will be removed. Tags are case sensitive. Extra whitespace will be removed from the string before it is displayed.\n\n|cffffff20$source|r - The source unit name.\n|cffffff20$dest|r - The destination unit name.\n|cffffff20$spell|r - The spell, skill, or enchant used.\n|cffffff20$action|r - The action text for the event (hit, missed, etc.)\n|cffffff20$for|r - The word \"for\" in some events; automatically removed if Include For is turned off.\n|cffffff20$amount|r - The numeric amount associated with the event, if any.\n|cffffff20$otherspell|r - The source's spell interacts with the destination's spell in certain events. $otherspell is the destination's spell.\n|cffffff20$extra|r - All extra information about the event, such as resists, overkill, miss type, failure reason, etc. Not shown if Include Extra Values is off.\n|cffffff20$amtsep|r - Replaced with a dash (-) if the $amount tag is also being filled with a number."],
						get = function() return db.display.customFormat or L["COMBATLOG_FORMAT_STANDARD_A"] end,
						set = function(self, val) db.display.customFormat = val end,
					}, -- customFormat
					
					flags = {
						type = "multiselect",
						name = L["Flag special values"],
						desc = L["Adds a flag to special value types in the combat log."],
						order = newOrder(),
						values = {
							["ALL"] = L["ALL"],
							["FLAG_CRITS"] = L["FLAG_CRITS"],
							["FLAG_HEALS"] = L["FLAG_HEALS"],
							["FLAG_PET_DAMAGE"] = L["FLAG_PET_DAMAGE"],
							["FLAG_ENERGIZES"] = L["FLAG_ENERGIZES"],
							["FLAG_EXP"] = L["FLAG_EXP"],
							["FLAG_HONOR"] = L["FLAG_HONOR"],
							["FLAG_REP"] = L["FLAG_REP"],
						},
						
						get = function(info, key)
							if key == "ALL" then
								for k, v in pairs(options.args.display.args.flags.values) do
									if (db.display.flags[k] == false or db.display.flags[k] == nil) and k ~= "ALL" then return false end
								end
								return true
							end
							return db.display.flags[key]
						end,
						
						set = function(info, key, state)
							if key == "ALL" then
								for k, v in pairs(options.args.display.args.flags.values) do
									db.display.flags[k] = state
								end
								return
							end
							db.display.flags[key] = state
						end

					}, -- flags multiselect control
					
					highlightCrits = {
						order = newOrder(),
						type = "toggle",
						name = L["Highlight crits"],
						desc = L["Critical damage values are highlighted (makes them brighter)."],
						get = function() return db.display.highlightCrits end,
						set = function(self, val) db.display.highlightCrits = val end,
					}, -- highlightCrits
					
					highlightPet = {
						order = newOrder(),
						type = "toggle",
						name = L["Highlight pet damage"],
						desc = L["Your pet damage values are highlighted (makes them brighter)."],
						get = function() return db.display.highlightPet end,
						set = function(self, val) db.display.highlightPet = val end,
					}, -- highlightPet

					
					-------- [[ Unit Names ]]--------
					desc2 = {
						includeInReplay = false,
						type = "description",
						name = "\n",
						order = newOrder()
					},
					head3 = {
						type = "header",
						name = L["Unit Names"],
						order = newOrder()
					},
					
					nameYou = {
						order = newOrder(),
						type = "toggle",
						name = L["Show \"you\" instead of your name"],
						desc = L["When selected, uses You and Your to indicate the player, rather than your name."],
						get = function() return db.display.nameYou end,
						set = function(self, val) db.display.nameYou = val end,
					}, -- nameYou
					
					nameBrackets = {
						order = newOrder(),
						type = "toggle",
						name = L["Brackets around names"],
						desc = L["When selected, square brackets will be placed around all unit names, for example:\n\n  [You] hit [Monster] for 16"],
						get = function() return db.display.nameBrackets end,
						set = function(self, val) db.display.nameBrackets = val end,
					}, -- nameBrackets
					
					nameAbbreviate = {
						order = newOrder(),
						type = "toggle",
						name = L["Abbreviate unit names"],
						desc = L["When selected, all unit names will be abbreviated to just the first letter of every word."],
						get = function() return db.display.nameAbbreviate end,
						set = function(self, val) db.display.nameAbbreviate = val end,
					}, -- nameAbbreviate
					
					nameColorByClass = {
						order = newOrder(),
						type = "toggle",
						name = L["Color by class"],
						desc = L["When selected, unit names will be colorized by their class (when their class is available). Replayed combat logs may not include this feature if you recently reloaded your UI. WoW does not return class information for all units in the game.\n\nDisable this feature to use the default color for various unit types."],
						get = function() return db.display.nameColorByClass end,
						set = function(self, val) db.display.nameColorByClass = val end,
					}, -- nameColorByClass
					
					nameShowRaidIcons = {
						order = newOrder(),
						type = "toggle",
						name = L["Include raid icons"],
						desc = L["When selected, raid icons will be shown next to unit names (if applicable). This will also work for replayed combat logs."],
						get = function() return db.display.nameShowRaidIcons end,
						set = function(self, val) db.display.nameShowRaidIcons = val end,
					}, -- nameShowRaidIcons

					-- nameShowLevel = {
						-- order = newOrder(),
						-- type = "toggle",
						-- name = L["Include level"],
						-- desc = L["When selected, a unit's level will be displayed next to their name. This will also work for replayed combat logs."],
						-- get = function() return db.display.nameShowLevel end,
						-- set = function(self, val) db.display.nameShowLevel = val end,
					-- }, -- nameShowLevel


					-------- [[ Spells ]]--------
					desc3 = {
						includeInReplay = false,
						type = "description",
						name = "\n",
						order = newOrder()
					},
					head4 = {
						type = "header",
						name = L["Spells"],
						order = newOrder()
					},
					
					spellDisplayMode = {
						order = newOrder(),
						type = "select",
						name = L["Display mode"],
						desc = L["Determines how spells and skills will be displayed in the combat log. Abbreviated spells will show just the first letter of every word in the spell."],
						values = {
							[SPELLDISPLAYMODE_TEXT] = L["Text"],
							[SPELLDISPLAYMODE_ABBREVIATED_TEXT] = L["Text (abbreviated)"],
							[SPELLDISPLAYMODE_LINK] = L["Link"],
							[SPELLDISPLAYMODE_ABBREVIATED_LINK] = L["Link (abbreviated)"],
							[SPELLDISPLAYMODE_NONE] = L["None"],
						},
						get = function() return db.display.spellDisplayMode or SPELLDISPLAYMODE_LINK end,
						set = function(self, val) db.display.spellDisplayMode = val end,
					}, -- spellDisplayMode

					spellShowIcons = {
						order = newOrder(),
						type = "toggle",
						name = L["Include spell icons"],
						desc = L["When selected, spell icons will be shown in the combat log. You can choose to show icons only (no text), by turning this on and selecting \"None\" for display mode above.\n\nDisable this feature if you encounter graphical corruption in your chat window."],
						get = function() return db.display.spellShowIcons end,
						set = function(self, val) db.display.spellShowIcons = val end,
					}, -- spellShowIcons
					
					spellColorBySchool = {
						order = newOrder(),
						type = "toggle",
						name = L["Color by spell school"],
						desc = L["When selected, spell damage values will be colorized based on the spell school. For hybrid spell schools, a priority system is used to choose the color."],
						get = function() return db.display.spellColorBySchool end,
						set = function(self, val) db.display.spellColorBySchool = val end,
					}, -- spellColorBySchool

					whiteList = {
						type = "input",
						name = L["Spell Name Whitelist"],
						desc = L["Enter a comma-separated list of spell names. Only events whose spells are on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."],
						order = newOrder(),
						get = function() return db.display.spellNameWhiteList or "" end,
						set = function(w, value)
							db.display.spellNameWhiteList = value
							self:UpdateWhiteBlackLists()
						end
					}, -- whiteList
					
					blackList = {
						type = "input",
						name = L["Spell Name Blacklist"],
						desc = L["Enter a comma-separated list of spell names. Only events whose spells are not on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."],
						order = newOrder(),
						get = function() return db.display.spellNameBlackList or "" end,
						set = function(w, value)
							db.display.spellNameBlackList = value
							self:UpdateWhiteBlackLists()
						end
					} -- blackList


				}
			}, -- display
			
			
--[[ Source units ]]-----------------------------------------------------------------------------------------------------------------

			sourceUnits = {
				type = "group",
				name = L["Source Units"],
				desc = L["Choose which source unit types to display events for."],
				order = newOrder(),
				args = {
					head = {
						type = "header",
						name = L["Source Units"],
						order = newOrder()
					},
					desc = {
						type = "description",
						name = L["Choose which source unit types to display events for."],
						order = newOrder()
					},
					
					unitComparisonMode = {
						order = newOrder(),
						type = "select",
						name = L["Unit comparison mode"],
						desc = L["Determines how your unit filters will be used.\n\n|cffffff20Or:|r\n  Events where the source filters OR the destination filters match your selections will be shown.\n\n|cffffff20And:|r\n  Events where the source filters AND the destination filters match your selections will be shown."],
						values = {
							[UNITCOMPARISONMODE_OR] = L["Or"],
							[UNITCOMPARISONMODE_AND] = L["And"],
						},
						get = function() return db.unitComparisonMode or UNITCOMPARISONMODE_OR end,
						set = function(self, val) db.unitComparisonMode = val end,
					}, -- unitComparisonMode

					showMissingSource = {
						order = newOrder(),
						type = "toggle",
						name = L["Show events with no source unit"],
						desc = L["When selected, events with no source unit will be shown in this filter."],
						get = function() return db.showMissingSource end,
						set = function(self, val) db.showMissingSource = val end,
					}, -- showMissingSource
					
					affiliation = {
						type = "multiselect",
						name = L["Affiliation"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_AFFILIATION_MINE"] = L["COMBATLOG_OBJECT_AFFILIATION_MINE"],
							["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = L["COMBATLOG_OBJECT_AFFILIATION_PARTY"],
							["COMBATLOG_OBJECT_AFFILIATION_RAID"] = L["COMBATLOG_OBJECT_AFFILIATION_RAID"],
							["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"]
						},
						
						get = function(info, key)
							return db.sourceFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.sourceUnits.args.affiliation.values) do
									if db.sourceFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.sourceFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- affiliation multiselect control
					
					reaction = {
						type = "multiselect",
						name = L["Reaction"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = L["COMBATLOG_OBJECT_REACTION_FRIENDLY"],
							["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = L["COMBATLOG_OBJECT_REACTION_NEUTRAL"],
							["COMBATLOG_OBJECT_REACTION_HOSTILE"] = L["COMBATLOG_OBJECT_REACTION_HOSTILE"],
						},
						
						get = function(info, key)
							return db.sourceFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.sourceUnits.args.reaction.values) do
									if db.sourceFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.sourceFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- reaction multiselect control

					ownership = {
						type = "multiselect",
						name = L["Ownership"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_CONTROL_PLAYER"] = L["COMBATLOG_OBJECT_CONTROL_PLAYER"],
							["COMBATLOG_OBJECT_CONTROL_NPC"] = L["COMBATLOG_OBJECT_CONTROL_NPC"],
						},
						
						get = function(info, key)
							return db.sourceFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.sourceUnits.args.ownership.values) do
									if db.sourceFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.sourceFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- ownership multiselect control

					unitType = {
						type = "multiselect",
						name = L["Unit Type"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_TYPE_PLAYER"] = L["COMBATLOG_OBJECT_TYPE_PLAYER"],
							["COMBATLOG_OBJECT_TYPE_NPC"] = L["COMBATLOG_OBJECT_TYPE_NPC"],
							["COMBATLOG_OBJECT_TYPE_PET"] = L["COMBATLOG_OBJECT_TYPE_PET"],
							["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = L["COMBATLOG_OBJECT_TYPE_GUARDIAN"],
							["COMBATLOG_OBJECT_TYPE_OBJECT"] = L["COMBATLOG_OBJECT_TYPE_OBJECT"]
						},
						
						get = function(info, key)
							return db.sourceFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.sourceUnits.args.unitType.values) do
									if db.sourceFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.sourceFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- unitType multiselect control
					
					specialCases = {
						type = "multiselect",
						name = L["Unit Type"],
						desc = L["These are optional. Select \"None\" to exclude all special cases."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_TARGET"] = L["COMBATLOG_OBJECT_TARGET"],
							["COMBATLOG_OBJECT_FOCUS"] = L["COMBATLOG_OBJECT_FOCUS"],
							["COMBATLOG_OBJECT_MAINTANK"] = L["COMBATLOG_OBJECT_MAINTANK"],
							["COMBATLOG_OBJECT_MAINASSIST"] = L["COMBATLOG_OBJECT_MAINASSIST"],
							["COMBATLOG_OBJECT_RAIDTARGET1"] = L["COMBATLOG_OBJECT_RAIDTARGET1"].." "..ICON_LIST[1].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET2"] = L["COMBATLOG_OBJECT_RAIDTARGET2"].." "..ICON_LIST[2].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET3"] = L["COMBATLOG_OBJECT_RAIDTARGET3"].." "..ICON_LIST[3].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET4"] = L["COMBATLOG_OBJECT_RAIDTARGET4"].." "..ICON_LIST[4].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET5"] = L["COMBATLOG_OBJECT_RAIDTARGET5"].." "..ICON_LIST[5].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET6"] = L["COMBATLOG_OBJECT_RAIDTARGET6"].." "..ICON_LIST[6].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET7"] = L["COMBATLOG_OBJECT_RAIDTARGET7"].." "..ICON_LIST[7].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET8"] = L["COMBATLOG_OBJECT_RAIDTARGET8"].." "..ICON_LIST[8].."0|t",
							["COMBATLOG_OBJECT_NONE"] = L["COMBATLOG_OBJECT_NONE"]
						},
						
						get = function(info, key)
							return db.sourceFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							db.sourceFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- specialCases multiselect control

					whiteList = {
						type = "input",
						name = L["Name Is"],
						desc = L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."],
						order = newOrder(),
						get = function() return db.sourceWhiteList or "" end,
						set = function(w, value)
							db.sourceWhiteList = value
							self:UpdateWhiteBlackLists()
						end
					}, -- whiteList
					
					blackList = {
						type = "input",
						name = L["Name Is Not"],
						desc = L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."],
						order = newOrder(),
						get = function() return db.sourceBlackList or "" end,
						set = function(w, value)
							db.sourceBlackList = value
							self:UpdateWhiteBlackLists()
						end
					} -- blackList
					
					
				}
			}, -- sourceUnits


--[[ Destination units ]]------------------------------------------------------------------------------------------------------------

			destUnits = {
				type = "group",
				name = L["Destination Units"],
				desc = L["Choose which destination unit types to display events for."],
				order = newOrder(),
				args = {
					head = {
						type = "header",
						name = L["Destination Units"],
						order = newOrder()
					},
					desc = {
						type = "description",
						name = L["Choose which destination unit types to display events for."],
						order = newOrder()
					},
					
					unitComparisonMode = {
						order = newOrder(),
						type = "select",
						name = L["Unit comparison mode"],
						desc = L["Determines how your unit filters will be used.\n\n|cffffff20Or:|r\n  Events where the source filters OR the destination filters match your selections will be shown.\n\n|cffffff20And:|r\n  Events where the source filters AND the destination filters match your selections will be shown."],
						values = {
							[UNITCOMPARISONMODE_OR] = L["Or"],
							[UNITCOMPARISONMODE_AND] = L["And"],
						},
						get = function() return db.unitComparisonMode or UNITCOMPARISONMODE_OR end,
						set = function(self, val) db.unitComparisonMode = val end,
					}, -- unitComparisonMode

					showMissingDest = {
						order = newOrder(),
						type = "toggle",
						name = L["Show events with no dest unit"],
						desc = L["When selected, events with no destination unit will be shown in this filter."],
						get = function() return db.showMissingDest end,
						set = function(self, val) db.showMissingDest = val end,
					}, -- showMissingDest
					
					affiliation = {
						type = "multiselect",
						name = L["Affiliation"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_AFFILIATION_MINE"] = L["COMBATLOG_OBJECT_AFFILIATION_MINE"],
							["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = L["COMBATLOG_OBJECT_AFFILIATION_PARTY"],
							["COMBATLOG_OBJECT_AFFILIATION_RAID"] = L["COMBATLOG_OBJECT_AFFILIATION_RAID"],
							["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"]
						},
						
						get = function(info, key)
							return db.destFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.destUnits.args.affiliation.values) do
									if db.destFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.destFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- affiliation multiselect control
					
					reaction = {
						type = "multiselect",
						name = L["Reaction"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = L["COMBATLOG_OBJECT_REACTION_FRIENDLY"],
							["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = L["COMBATLOG_OBJECT_REACTION_NEUTRAL"],
							["COMBATLOG_OBJECT_REACTION_HOSTILE"] = L["COMBATLOG_OBJECT_REACTION_HOSTILE"],
						},
						
						get = function(info, key)
							return db.destFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.destUnits.args.reaction.values) do
									if db.destFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.destFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- reaction multiselect control

					ownership = {
						type = "multiselect",
						name = L["Ownership"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_CONTROL_PLAYER"] = L["COMBATLOG_OBJECT_CONTROL_PLAYER"],
							["COMBATLOG_OBJECT_CONTROL_NPC"] = L["COMBATLOG_OBJECT_CONTROL_NPC"],
						},
						
						get = function(info, key)
							return db.destFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.destUnits.args.ownership.values) do
									if db.destFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.destFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- ownership multiselect control

					unitType = {
						type = "multiselect",
						name = L["Unit Type"],
						desc = L["You must choose at least one item from this category."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_TYPE_PLAYER"] = L["COMBATLOG_OBJECT_TYPE_PLAYER"],
							["COMBATLOG_OBJECT_TYPE_NPC"] = L["COMBATLOG_OBJECT_TYPE_NPC"],
							["COMBATLOG_OBJECT_TYPE_PET"] = L["COMBATLOG_OBJECT_TYPE_PET"],
							["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = L["COMBATLOG_OBJECT_TYPE_GUARDIAN"],
							["COMBATLOG_OBJECT_TYPE_OBJECT"] = L["COMBATLOG_OBJECT_TYPE_OBJECT"]
						},
						
						get = function(info, key)
							return db.destFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							if state == false then -- Must leave at least one selected at all times
								local count = 0
								for k, v in pairs(options.args.destUnits.args.unitType.values) do
									if db.destFlags[_G[k]] == true then count = count + 1 end
								end
								if count <= 1 then return end
							end
							db.destFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- unitType multiselect control
					
					specialCases = {
						type = "multiselect",
						name = L["Unit Type"],
						desc = L["These are optional. Select \"None\" to exclude all special cases."],
						order = newOrder(),
						values = {
							["COMBATLOG_OBJECT_TARGET"] = L["COMBATLOG_OBJECT_TARGET"],
							["COMBATLOG_OBJECT_FOCUS"] = L["COMBATLOG_OBJECT_FOCUS"],
							["COMBATLOG_OBJECT_MAINTANK"] = L["COMBATLOG_OBJECT_MAINTANK"],
							["COMBATLOG_OBJECT_MAINASSIST"] = L["COMBATLOG_OBJECT_MAINASSIST"],
							["COMBATLOG_OBJECT_RAIDTARGET1"] = L["COMBATLOG_OBJECT_RAIDTARGET1"].." "..ICON_LIST[1].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET2"] = L["COMBATLOG_OBJECT_RAIDTARGET2"].." "..ICON_LIST[2].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET3"] = L["COMBATLOG_OBJECT_RAIDTARGET3"].." "..ICON_LIST[3].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET4"] = L["COMBATLOG_OBJECT_RAIDTARGET4"].." "..ICON_LIST[4].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET5"] = L["COMBATLOG_OBJECT_RAIDTARGET5"].." "..ICON_LIST[5].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET6"] = L["COMBATLOG_OBJECT_RAIDTARGET6"].." "..ICON_LIST[6].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET7"] = L["COMBATLOG_OBJECT_RAIDTARGET7"].." "..ICON_LIST[7].."0|t",
							["COMBATLOG_OBJECT_RAIDTARGET8"] = L["COMBATLOG_OBJECT_RAIDTARGET8"].." "..ICON_LIST[8].."0|t",
							["COMBATLOG_OBJECT_NONE"] = L["COMBATLOG_OBJECT_NONE"]
						},
						
						get = function(info, key)
							return db.destFlags[_G[key]]
						end,
						
						set = function(info, key, state)
							db.destFlags[_G[key]] = state
							self:UpdateFlags()
						end
						
					}, -- specialCases multiselect control

					whiteList = {
						type = "input",
						name = L["Name Is"],
						desc = L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."],
						order = newOrder(),
						get = function() return db.destWhiteList or "" end,
						set = function(w, value)
							db.destWhiteList = value
							self:UpdateWhiteBlackLists()
						end
					}, -- whiteList
					
					blackList = {
						type = "input",
						name = L["Name Is Not"],
						desc = L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."],
						order = newOrder(),
						get = function() return db.destBlackList or "" end,
						set = function(w, value)
							db.destBlackList = value
							self:UpdateWhiteBlackLists()
						end
					} -- blackList
					
					
				}
			}, -- destUnits


--[[ Combat events ]]----------------------------------------------------------------------------------------------------------------

			events = {
				type = "group",
				name = L["Combat Events"],
				desc = L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."],
				order = newOrder(),
				args = {
					head = {
						type = "header",
						name = L["Combat Events"],
						order = newOrder()
					},
					desc = {
						type = "description",
						name = L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."],
						order = newOrder()
					},
					
					events = {
						type = "multiselect",
						name = "",
						order = newOrder(),
						values = {
							["ALL"] = L["ALL"],
							["ENVIRONMENTAL_DAMAGE"] = L["ENVIRONMENTAL_DAMAGE"],
							["SWING_DAMAGE"] = L["SWING_DAMAGE"],
							["SWING_MISSED"] = L["SWING_MISSED"],
							["RANGE_DAMAGE"] = L["RANGE_DAMAGE"],
							["RANGE_MISSED"] = L["RANGE_MISSED"],
							["SPELL_CAST_START"] = L["SPELL_CAST_START"],
							["SPELL_CAST_SUCCESS"] = L["SPELL_CAST_SUCCESS"],
							["SPELL_CAST_FAILED"] = L["SPELL_CAST_FAILED"],
							["SPELL_MISSED"] = L["SPELL_MISSED"],
							["SPELL_DAMAGE"] = L["SPELL_DAMAGE"],
							["SPELL_HEAL"] = L["SPELL_HEAL"],
							["SPELL_PERIODIC_HEAL"] = L["SPELL_PERIODIC_HEAL"],
							["SPELL_ENERGIZE"] = L["SPELL_ENERGIZE"],
							["SPELL_PERIODIC_ENERGIZE"] = L["SPELL_PERIODIC_ENERGIZE"],
							["SPELL_DRAIN"] = L["SPELL_DRAIN"],
							["SPELL_PERIODIC_DRAIN"] = L["SPELL_PERIODIC_DRAIN"],
							["SPELL_LEECH"] = L["SPELL_LEECH"],
							["SPELL_PERIODIC_LEECH"] = L["SPELL_PERIODIC_LEECH"],
							["SPELL_INTERRUPT"] = L["SPELL_INTERRUPT"],
							["SPELL_EXTRA_ATTACKS"] = L["SPELL_EXTRA_ATTACKS"],
							["SPELL_AURA_APPLIED"] = L["SPELL_AURA_APPLIED"],
							["SPELL_AURA_APPLIED_DOSE"] = L["SPELL_AURA_APPLIED_DOSE"],
							["SPELL_AURA_REMOVED"] = L["SPELL_AURA_REMOVED"],
							["SPELL_AURA_REMOVED_DOSE"] = L["SPELL_AURA_REMOVED_DOSE"],
							["SPELL_DISPEL"] = L["SPELL_DISPEL"],
							["SPELL_DISPEL_FAILED"] = L["SPELL_DISPEL_FAILED"],
							["SPELL_STOLEN"] = L["SPELL_STOLEN"],
							["ENCHANT_APPLIED"] = L["ENCHANT_APPLIED"],
							["ENCHANT_REMOVED"] = L["ENCHANT_REMOVED"],
							["SPELL_PERIODIC_DAMAGE"] = L["SPELL_PERIODIC_DAMAGE"],
							["SPELL_PERIODIC_MISSED"] = L["SPELL_PERIODIC_MISSED"],
							["DAMAGE_SHIELD"] = L["DAMAGE_SHIELD"],
							["DAMAGE_SHIELD_MISSED"] = L["DAMAGE_SHIELD_MISSED"],
							["DAMAGE_SPLIT"] = L["DAMAGE_SPLIT"],
							["SPELL_INSTAKILL"] = L["SPELL_INSTAKILL"],
							["PARTY_KILL"] = L["PARTY_KILL"],
							["UNIT_DIED"] = L["UNIT_DIED"],
							["UNIT_DESTROYED"] = L["UNIT_DESTROYED"],
							["UNIT_DISSIPATES"] = L["UNIT_DISSIPATES"],
							["SPELL_BUILDING_HEAL"] = L["SPELL_BUILDING_HEAL"],
							["SPELL_BUILDING_DAMAGE"] = L["SPELL_BUILDING_DAMAGE"],
							["SPELL_SUMMON"] = L["SPELL_SUMMON"],
							["SPELL_CREATE"] = L["SPELL_CREATE"],
							["SPELL_RESURRECT"] = L["SPELL_RESURRECT"],
							["SPELL_AURA_REFRESH"] = L["SPELL_AURA_REFRESH"],
							["SPELL_AURA_BROKEN"] = L["SPELL_AURA_BROKEN"],
							["SPELL_AURA_BROKEN_SPELL"] = L["SPELL_AURA_BROKEN_SPELL"],
						},
						
						get = function(info, key)
							if key == "ALL" then
								for k, v in pairs(options.args.events.args.events.values) do
									if (db.events[k] == false or db.events[k] == nil) and k ~= "ALL" then return false end
								end
								return true
							end
							return db.events[key]
						end,
						
						set = function(info, key, state)
							if key == "ALL" then
								for k, v in pairs(options.args.events.args.events.values) do
									db.events[k] = state
								end
								return
							end
							db.events[key] = state
						end
						
					} -- events multiselect control
				}
			}, -- combat events


--[[ Special events ]]---------------------------------------------------------------------------------------------------------------

			specialEvents = {
				includeInReplay = false,
				type = "group",
				name = L["Special Events"],
				desc = L["Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.\n\nThey will not show for replayed combat logs."],
				order = newOrder(),
				args = {
					head = {
						type = "header",
						name = L["Special Events"],
						order = newOrder()
					},
					desc = {
						type = "description",
						name = L["Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.\n\nThey will not show for replayed combat logs."],
						order = newOrder()
					},
					
					events = {
						type = "multiselect",
						name = "",
						order = newOrder(),
						values = {
							["ALL"] = L["ALL"],
							["CHAT_MSG_COMBAT_XP_GAIN"] = L["CHAT_MSG_COMBAT_XP_GAIN"],
							["CHAT_MSG_LOOT"] = L["CHAT_MSG_LOOT"],
							["CHAT_MSG_COMBAT_FACTION_CHANGE"] = L["CHAT_MSG_COMBAT_FACTION_CHANGE"],
							["CHAT_MSG_COMBAT_HONOR_GAIN"] = L["CHAT_MSG_COMBAT_HONOR_GAIN"],
							["CHAT_MSG_MONEY"] = L["CHAT_MSG_MONEY"],
							["CHAT_MSG_SKILL"] = L["CHAT_MSG_SKILL"],
						},
						
						get = function(info, key)
							if key == "ALL" then
								for k, v in pairs(options.args.specialEvents.args.events.values) do
									if (db.specialEvents[k] == false or db.specialEvents[k] == nil) and k ~= "ALL" then return false end
								end
								return true
							end
							return db.specialEvents[key]
						end,
						
						set = function(info, key, state)
							if key == "ALL" then
								for k, v in pairs(options.args.specialEvents.args.events.values) do
									db.specialEvents[k] = state
								end
								return
							end
							db.specialEvents[key] = state
						end
						
					} -- special events multiselect control
				}
			} -- special events

  
		} -- args
	} -- options

	if add == nil or add == true then
		removeRemoveOptions(options)
		HitsMode5.options.args.filters.args[db.name] = options
	else
		return options.args
	end
end



function HitsMode5.Filter:GetOptions()
	return self:AddOptions(false)
end

