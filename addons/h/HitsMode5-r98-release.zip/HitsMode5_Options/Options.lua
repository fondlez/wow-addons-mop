local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5", false)
local HitsMode5 = HitsMode5
local mod = HitsMode5:NewModule("Options", "AceConsole-3.0")




function mod:OnInitialize()
	-- Register options
	LibStub("AceConfig-3.0"):RegisterOptionsTable("HitsMode5", HitsMode5.options)
	HitsMode5.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HitsMode5", "HitsMode5")
	LibStub("AceConfig-3.0"):RegisterOptionsTable("HitsMode5-Profiles", LibStub("AceDBOptions-3.0"):GetOptionsTable(HitsMode5.db))
	HitsMode5.profilesFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("HitsMode5-Profiles", "Profiles", "HitsMode5")
	HitsMode5.modules.options.loaded = true
end


function mod:OnEnable()
--[===[@debug@
	self:Print(L["Loaded"])
--@end-debug@]===]
end
