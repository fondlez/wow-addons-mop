local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5")
local deletefilter = nil
local filters = HitsMode5.filters



local newOrder
do
	local current = 0
	function newOrder()
		current = current + 1
		return current
	end
end


HitsMode5.options = {
	name = "HitsMode5         r|cff20ff20"..HitsMode5.MINOR_VERSION.."|r",
	handler = HitsMode5,
	type = "group",
	args = {		
	
	
--[[ General ]]----------------------------------------------------------------------------------------------------------------------

		general = {
			type = "group",
			name = L["General Options"],
			order = newOrder(),
			args = {
			
				enable = {
					type = "toggle",
					name = L["Enable HitsMode5"],
					desc = L["Enables or disables HitsMode5 entirely. When disabled, HitsMode5 will not respond to any combat log events. You will still be able to enable HitsMode5 and replay the combat log to see what happened."],
					get = function() return HitsMode5.db.profile.enabled end,
					set = function(self, val)
						HitsMode5.db.profile.enabled = val
						if val then HitsMode5:Enable() else HitsMode5:Disable() end
					end,
					order = newOrder(),
				}, -- enable
				
				replayDuration = {
					order = newOrder(),
					type = "range",
					name = L["Combat log retention time"],
					desc = L["Determines how long your WoW client will retain combat log data (in seconds). This affects HitsMode5's ability to replay the combat log. Longer retention times will cause your client to use more of your RAM, but will allow you to evaluate a longer period of combat after it has happened. The default setting is 5 minutes (300 seconds). Note that this is a WoW setting, not a HitsMode5 setting. This WoW setting is normally hidden from users.\n\nWoW currently imposes a limit of 315 seconds for this value."],
					min = 0,
					max = 315,
					step = 1,
					get = function() return CombatLogGetRetentionTime() end,
					set = function(self, val) CombatLogSetRetentionTime(val) end,
				},
				
				replayLinesPerFrame = {
					order = newOrder(),
					type = "range",
					name = L["Replay lines per frame"],
					desc = L["When HitsMode5 replays your combat log, it replays a certain number of lines per frame. This prevents your client from locking up for an extended period of time while the combat log is replayed. You may wish to adjust this setting to a higher number if you have a very fast computer, need to replay a long combat log (particularly in a raid), and don't mind a little lag while it happens. The default Blizzard Combat Log replays one line per frame."],
					min = 1,
					max = 100,
					step = 1,
					get = function() return HitsMode5.db.replayLinesPerFrame or 10 end,
					set = function(self, val) HitsMode5.db.replayLinesPerFrame = val end,
				},
			
				chatWindowOpen = {
					order = newOrder(),
					type = "execute",
					name = L["Open chat windows"],
					desc = L["Opens all chat windows being used by HitsMode5 filters, if any are currently closed."],
					func = function()
						for filterKey, f in pairs(HitsMode5.filters) do
							local chatFrame = _G["ChatFrame"..f.db.display.chatWindow]
							if chatFrame then
								if shown or chatFrame.isDocked then
									return
								end
							end
							HitsMode5:OpenChatWindow(f.db.display.chatWindow)
						end
					end,
				}, -- chatWindowOpen
				
				chatWindowOpenDesc = {
					type = "description",
					name = L["If you can't find one or more chat windows, they may have become docked next to another chat window."],
					order = newOrder()
				},

				spacer1 = {
					type = "description",
					name = "\n\n",
					order = newOrder()
				},

				replay = {
					order = newOrder(),
					type = "execute",
					name = L["Replay combat"],
					desc = L["Clears all chat windows being used by filters, and replays all saved combat back to them. This is useful if you've changed your filter settings and want to see recent combat using the new settings.\n\nCombat is saved by the WoW client (not by HitsMode5). You can change the combat retention time above."],
					func = function()
						HitsMode5:Replay()
					end,
					-- disabled = function()
						-- return _G["HitsMode5ProgressBar"].progressing
					-- end,
				}, -- replay
				
				cancelReplay = {
					order = newOrder(),
					type = "execute",
					name = L["Cancel replay"],
					desc = L["Cancels a currently running combat replay."],
					func = function()
						HitsMode5:CancelReplay()
					end,
					-- disabled = function()
						-- return _G["HitsMode5ProgressBar"].progressing
					-- end,
				}, -- replay
				
			}
		},
	
		
--[[ Filters ]]----------------------------------------------------------------------------------------------------------------------

		filters = {
			type = "group",
			name = L["Filters"],
			desc = L["Filters are the basic building block of the HitsMode5 combat log. Each filter lets you choose which events to show, which chat window to show them in, and how you'd like them to look.\n\nYou can create an unlimited number of filters, all running at once.\n\nYou can also create filters and turn them off, saving them for a special occasion when you need to look something up."],
			order = newOrder(),
			args = {

				create = {
					type = "input",
					name = L["Create filter"],
					desc = L["Enter the name for the new filter."],
					set = function(self, val) if val and val ~= "" then HitsMode5:CreateFilter(val) end end,
					order = newOrder(),
				},

				delete = {
					type = "select",
					name = L["Delete filter"],
					desc = L["Choose the filter to be deleted."],
					values =	function()
						local filters = {}
						for k, v in ipairs(HitsMode5:GetFilters()) do
							filters[v.db.name] = v.db.name
						end
						return filters
					end,
					get = function() return deletefilter end,
					set = function(self, val) deletefilter = val end,
					order = newOrder(),
				},
				
				deleteexecute = {
					type = "execute",
					name = L["Delete filter"],
					desc = L["Deletes the chosen filter."],
					confirm = true,
					confirmText = L["Are you sure you want to delete this filter?"],
					func = function(self) if deletefilter then HitsMode5:DeleteFilter(deletefilter) end end,
					order = newOrder(),
				},

			},
		}, -- filters

		
--[[ Colors ]]-----------------------------------------------------------------------------------------------------------------------

		colors = {
			type = "group",
			name = L["Colors"],
			desc = L["Configure all the colors used throughout the HitsMode5 combat log. Colors are global for all filters."],
			order = newOrder(),
			args = {
			
				-------- [[ General ]]--------
				general = {
					type = "header",
					name = L["General"],
					order = newOrder(),
				},
					
				text = {
					order = newOrder(),
					type = "color",
					name = L["Normal text"],
					desc = L["The sentence structure portion of each combat log entry."],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.general.text = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.general.text.r, HitsMode5.db.profile.colors.general.text.g, HitsMode5.db.profile.colors.general.text.b
					end
				},

				spells = {
					order = newOrder(),
					type = "color",
					name = L["Spell names"],
					desc = L["Spell/skill names.\n\nOnly used when not displaying spell links."],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.general.spells = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.general.spells.r, HitsMode5.db.profile.colors.general.spells.g, HitsMode5.db.profile.colors.general.spells.b
					end
				},

				brackets = {
					order = newOrder(),
					type = "color",
					name = L["Brackets"],
					desc = L["The square brackets surrounding unit names."],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.general.brackets = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.general.brackets.r, HitsMode5.db.profile.colors.general.brackets.g, HitsMode5.db.profile.colors.general.brackets.b
					end
				},

				extraValues = {
					order = newOrder(),
					type = "color",
					name = L["Extra values"],
					desc = L["Extra values in the combat log (resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill damage, as well as energy types and miss types)."],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.general.extraValues = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.general.extraValues.r, HitsMode5.db.profile.colors.general.extraValues.g, HitsMode5.db.profile.colors.general.extraValues.b
					end
				},

				critFlag = {
					order = newOrder(),
					type = "color",
					name = L["Crit flag (*)"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.general.critFlag = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.general.critFlag.r, HitsMode5.db.profile.colors.general.critFlag.g, HitsMode5.db.profile.colors.general.critFlag.b
					end
				},
				
				
				-------- [[ Unit Names ]]--------
				unitNames = {
					type = "header",
					name = L["Unit Names"],
					order = newOrder(),
				},

				you = {
					order = newOrder(),
					type = "color",
					name = L["You"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.you = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.you.r, HitsMode5.db.profile.colors.unitNames.you.g, HitsMode5.db.profile.colors.unitNames.you.b
					end
				},

				pet = {
					order = newOrder(),
					type = "color",
					name = L["Your pet"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.pet = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.pet.r, HitsMode5.db.profile.colors.unitNames.pet.g, HitsMode5.db.profile.colors.unitNames.pet.b
					end
				},

				friends = {
					order = newOrder(),
					type = "color",
					name = L["Friends"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.friends = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.friends.r, HitsMode5.db.profile.colors.unitNames.friends.g, HitsMode5.db.profile.colors.unitNames.friends.b
					end
				},

				hostileUnits = {
					order = newOrder(),
					type = "color",
					name = L["Hostile units"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.hostileUnits = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.hostileUnits.r, HitsMode5.db.profile.colors.unitNames.hostileUnits.g, HitsMode5.db.profile.colors.unitNames.hostileUnits.b
					end
				},

				hostilePlayers = {
					order = newOrder(),
					type = "color",
					name = L["Hostile players"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.hostilePlayers = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.hostilePlayers.r, HitsMode5.db.profile.colors.unitNames.hostilePlayers.g, HitsMode5.db.profile.colors.unitNames.hostilePlayers.b
					end
				},

				neutral = {
					order = newOrder(),
					type = "color",
					name = L["Neutral"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.neutral = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.neutral.r, HitsMode5.db.profile.colors.unitNames.neutral.g, HitsMode5.db.profile.colors.unitNames.neutral.b
					end
				},

				unknown = {
					order = newOrder(),
					type = "color",
					name = L["Unknown"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.unitNames.unknown = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.unitNames.unknown.r, HitsMode5.db.profile.colors.unitNames.unknown.g, HitsMode5.db.profile.colors.unitNames.unknown.b
					end
				},
			
			
				-------- [[ Spell Schools ]]--------
				spellSchools = {
					type = "header",
					name = L["Spell Schools"],
					order = newOrder(),
				},
			
				arcane = {
					order = newOrder(),
					type = "color",
					name = STRING_SCHOOL_ARCANE,
					set = function(self, r, g, b) HitsMode5.db.profile.colors.spellSchools.arcane = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.spellSchools.arcane.r, HitsMode5.db.profile.colors.spellSchools.arcane.g, HitsMode5.db.profile.colors.spellSchools.arcane.b
					end
				},

				fire = {
					order = newOrder(),
					type = "color",
					name = STRING_SCHOOL_FIRE,
					set = function(self, r, g, b) HitsMode5.db.profile.colors.spellSchools.fire = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.spellSchools.fire.r, HitsMode5.db.profile.colors.spellSchools.fire.g, HitsMode5.db.profile.colors.spellSchools.fire.b
					end
				},

				frost = {
					order = newOrder(),
					type = "color",
					name = STRING_SCHOOL_FROST,
					set = function(self, r, g, b) HitsMode5.db.profile.colors.spellSchools.frost = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.spellSchools.frost.r, HitsMode5.db.profile.colors.spellSchools.frost.g, HitsMode5.db.profile.colors.spellSchools.frost.b
					end
				},

				holy = {
					order = newOrder(),
					type = "color",
					name = STRING_SCHOOL_HOLY,
					set = function(self, r, g, b) HitsMode5.db.profile.colors.spellSchools.holy = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.spellSchools.holy.r, HitsMode5.db.profile.colors.spellSchools.holy.g, HitsMode5.db.profile.colors.spellSchools.holy.b
					end
				},

				nature = {
					order = newOrder(),
					type = "color",
					name = STRING_SCHOOL_NATURE,
					set = function(self, r, g, b) HitsMode5.db.profile.colors.spellSchools.nature = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.spellSchools.nature.r, HitsMode5.db.profile.colors.spellSchools.nature.g, HitsMode5.db.profile.colors.spellSchools.nature.b
					end
				},

				shadow = {
					order = newOrder(),
					type = "color",
					name = STRING_SCHOOL_SHADOW,
					set = function(self, r, g, b) HitsMode5.db.profile.colors.spellSchools.shadow = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.spellSchools.shadow.r, HitsMode5.db.profile.colors.spellSchools.shadow.g, HitsMode5.db.profile.colors.spellSchools.shadow.b
					end
				},


				-------- [[ Combat Events ]]--------
				combatEvents = {
					type = "header",
					name = L["Combat Events"],
					order = newOrder(),
				},

				friendlyDamage = {
					order = newOrder(),
					type = "color",
					name = L["Friendly damage"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.friendlyDamage = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.friendlyDamage.r, HitsMode5.db.profile.colors.combatEvents.friendlyDamage.g, HitsMode5.db.profile.colors.combatEvents.friendlyDamage.b
					end
				},

				friendlySpellDamage = {
					order = newOrder(),
					type = "color",
					name = L["Friendly spell damage"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.friendlySpellDamage = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.friendlySpellDamage.r, HitsMode5.db.profile.colors.combatEvents.friendlySpellDamage.g, HitsMode5.db.profile.colors.combatEvents.friendlySpellDamage.b
					end
				},

				hostileDamage = {
					order = newOrder(),
					type = "color",
					name = L["Hostile damage"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.hostileDamage = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.hostileDamage.r, HitsMode5.db.profile.colors.combatEvents.hostileDamage.g, HitsMode5.db.profile.colors.combatEvents.hostileDamage.b
					end
				},

				hostileSpellDamage = {
					order = newOrder(),
					type = "color",
					name = L["Hostile spell damage"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.hostileSpellDamage = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.hostileSpellDamage.r, HitsMode5.db.profile.colors.combatEvents.hostileSpellDamage.g, HitsMode5.db.profile.colors.combatEvents.hostileSpellDamage.b
					end
				},

				energizes = {
					order = newOrder(),
					type = "color",
					name = L["Energizes and extra attacks"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.energizes = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.energizes.r, HitsMode5.db.profile.colors.combatEvents.energizes.g, HitsMode5.db.profile.colors.combatEvents.energizes.b
					end
				},

				friendlyHeals = {
					order = newOrder(),
					type = "color",
					name = L["Friendly heals"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.friendlyHeals = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.friendlyHeals.r, HitsMode5.db.profile.colors.combatEvents.friendlyHeals.g, HitsMode5.db.profile.colors.combatEvents.friendlyHeals.b
					end
				},

				hostileHeals = {
					order = newOrder(),
					type = "color",
					name = L["Hostile heals"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.combatEvents.hostileHeals = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.combatEvents.hostileHeals.r, HitsMode5.db.profile.colors.combatEvents.hostileHeals.g, HitsMode5.db.profile.colors.combatEvents.hostileHeals.b
					end
				},

			
				-------- [[ Special Events ]]--------
				specialEvents = {
					type = "header",
					name = L["Special Events"],
					order = newOrder(),
				},
			
				experience = {
					order = newOrder(),
					type = "color",
					name = L["Experience gained"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.specialEvents.experience = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.specialEvents.experience.r, HitsMode5.db.profile.colors.specialEvents.experience.g, HitsMode5.db.profile.colors.specialEvents.experience.b
					end
				},

				loot = {
					order = newOrder(),
					type = "color",
					name = L["Loot"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.specialEvents.loot = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.specialEvents.loot.r, HitsMode5.db.profile.colors.specialEvents.loot.g, HitsMode5.db.profile.colors.specialEvents.loot.b
					end
				},

				honor = {
					order = newOrder(),
					type = "color",
					name = L["Honor gained"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.specialEvents.honor = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.specialEvents.honor.r, HitsMode5.db.profile.colors.specialEvents.honor.g, HitsMode5.db.profile.colors.specialEvents.honor.b
					end
				},

				reputation = {
					order = newOrder(),
					type = "color",
					name = L["Reputation gained"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.specialEvents.reputation = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.specialEvents.reputation.r, HitsMode5.db.profile.colors.specialEvents.reputation.g, HitsMode5.db.profile.colors.specialEvents.reputation.b
					end
				},

				skill = {
					order = newOrder(),
					type = "color",
					name = L["Skill changed"],
					set = function(self, r, g, b) HitsMode5.db.profile.colors.specialEvents.skill = { r = r, g = g, b = b } end,
					get = function()
						return HitsMode5.db.profile.colors.specialEvents.skill.r, HitsMode5.db.profile.colors.specialEvents.skill.g, HitsMode5.db.profile.colors.specialEvents.skill.b
					end
				},


			}
		},
	
		
--[[ Help ]]-------------------------------------------------------------------------------------------------------------------------

		-- help = {
			-- type = "group",
			-- name = L["Help"],
			-- desc = L["Get help with HitsMode5."],
			-- order = newOrder(),
			-- 
			-- args = {
				-- help = {
					-- type = "execute",
					-- name = L["Help with HitsMode5"],
					-- desc = L["Click to open the HitsMode5 knowledge base, which is filled with frequently asked questions."],
					-- func = function()
						-- InterfaceOptionsFrame:Hide()
						-- ToggleHelpFrame()
						-- HitsMode5:ScheduleTimer("CheckHelpLoaded", 0.2)
					-- end,
					-- order = newOrder()
				-- }
			-- } -- args
		-- }, -- help
		
	} -- args
} -- options

