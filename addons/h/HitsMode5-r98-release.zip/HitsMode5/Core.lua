HitsMode5 = LibStub("AceAddon-3.0"):NewAddon("HitsMode5", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
HitsMode5.MINOR_VERSION = tonumber(("$Revision: 98 $"):match("%d+"))
local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5")
local HitsMode5 = HitsMode5
local ldb = LibStub:GetLibrary("LibDataBroker-1.1")
local dataobj = ldb:NewDataObject("HitsMode5", {label = "HitsMode5", type = "data source", icon = "Interface\\Icons\\Ability_CriticalStrike", text = ""})
---



--[[
      VARIABLES ----------------------------------------------------------------------------------------------------------------
  ]]

local isEnabled = false
local NUM_HELPARTICLES = 1
HitsMode5.filters = {}
local unitCache = {}
local cleanupTimer
HitsMode5.replaying = false

HitsMode5.modules = {
	options = {
		loaded = false,
	},
	replay = {
	 loaded = false,
	},
	summary = {
		loaded = false,
	},
}

local specialEvents = {
	"PLAYER_REGEN_DISABLED",
	"PLAYER_REGEN_ENABLED",
	"CHAT_MSG_COMBAT_XP_GAIN",
	"CHAT_MSG_LOOT",
	"CHAT_MSG_COMBAT_FACTION_CHANGE",
	"CHAT_MSG_COMBAT_HONOR_GAIN",
	"CHAT_MSG_MONEY",
	"CHAT_MSG_SKILL",
}

local DISPLAYMODE_STANDARD = 1
local DISPLAYMODE_STANDARD_NUMBERS_FIRST = 2
local DISPLAYMODE_NUMBERS_ONLY = 3
local DISPLAYMODE_CUSTOM = 4

local formats = {
	[DISPLAYMODE_STANDARD] = "COMBATLOG_FORMAT_STANDARD",
	[DISPLAYMODE_STANDARD_NUMBERS_FIRST] = "COMBATLOG_FORMAT_STANDARD_NUMBERS_FIRST",
	[DISPLAYMODE_NUMBERS_ONLY] = "COMBATLOG_FORMAT_NUMBERS_ONLY",
}

local SPELLDISPLAYMODE_TEXT = 1
local SPELLDISPLAYMODE_ABBREVIATED_TEXT = 2
local SPELLDISPLAYMODE_LINK = 3
local SPELLDISPLAYMODE_ABBREVIATED_LINK = 4
local SPELLDISPLAYMODE_NONE = 5

local FLAG_CRITS = 1
local FLAG_HEALS = 2
local FLAG_PET_DAMAGE = 3
local FLAG_ENERGIZES = 4
local FLAG_EXP = 5
local FLAG_HONOR = 6
local FLAG_REP = 7

local UNITCOMPARISONMODE_OR = 1
local UNITCOMPARISONMODE_AND = 2



--[[
      UPVALUES -----------------------------------------------------------------------------------------------------------------
  ]]
  
local _G = getfenv(0)
local ipairs = _G.ipairs
local next = _G.next
local pairs = _G.pairs
local select = _G.select
local tonumber = _G.tonumber
local tostring = _G.tostring
local type = _G.type
local unpack = _G.unpack
local bit_bor = _G.bit.bor
local bit_band = _G.bit.band
local tinsert = _G.tinsert
local tremove = _G.tremove
local math_floor = _G.math.floor
local format = _G.format
local gsub = _G.gsub
local strsub = _G.strsub
local strreplace = _G.string.gsub
local strsplit = _G.strsplit
local strlower = _G.strlower
local strgmatch = _G.string.gmatch
local strgsub = _G.string.gsub
local strmatch = _G.string.match
local strtrim = _G.string.trim
local strutf8sub = _G.string.utf8sub

local CombatLog_Object_IsA = CombatLog_Object_IsA
local GetTime = GetTime
local UnitClass = UnitClass
local UnitLevel = UnitLevel
local GetChatWindowInfo = GetChatWindowInfo
local GetSpellInfo = GetSpellInfo
local CombatLogGetCurrentEntry = CombatLogGetCurrentEntry

local COMBATLOG_OBJECT_AFFILIATION_MINE = COMBATLOG_OBJECT_AFFILIATION_MINE
local COMBATLOG_OBJECT_AFFILIATION_PARTY = COMBATLOG_OBJECT_AFFILIATION_PARTY
local COMBATLOG_OBJECT_AFFILIATION_RAID = COMBATLOG_OBJECT_AFFILIATION_RAID
local COMBATLOG_OBJECT_AFFILIATION_OUTSIDER = COMBATLOG_OBJECT_AFFILIATION_OUTSIDER
local COMBATLOG_OBJECT_AFFILIATION_MASK = COMBATLOG_OBJECT_AFFILIATION_MASK
local COMBATLOG_OBJECT_REACTION_FRIENDLY = COMBATLOG_OBJECT_REACTION_FRIENDLY
local COMBATLOG_OBJECT_REACTION_NEUTRAL = COMBATLOG_OBJECT_REACTION_NEUTRAL
local COMBATLOG_OBJECT_REACTION_HOSTILE = COMBATLOG_OBJECT_REACTION_HOSTILE
local COMBATLOG_OBJECT_REACTION_MASK = COMBATLOG_OBJECT_REACTION_MASK
local COMBATLOG_OBJECT_CONTROL_PLAYER = COMBATLOG_OBJECT_CONTROL_PLAYER
local COMBATLOG_OBJECT_CONTROL_NPC = COMBATLOG_OBJECT_CONTROL_NPC
local COMBATLOG_OBJECT_CONTROL_MASK = COMBATLOG_OBJECT_CONTROL_MASK
local COMBATLOG_OBJECT_TYPE_PLAYER = COMBATLOG_OBJECT_TYPE_PLAYER
local COMBATLOG_OBJECT_TYPE_NPC = COMBATLOG_OBJECT_TYPE_NPC
local COMBATLOG_OBJECT_TYPE_PET = COMBATLOG_OBJECT_TYPE_PET
local COMBATLOG_OBJECT_TYPE_GUARDIAN = COMBATLOG_OBJECT_TYPE_GUARDIAN
local COMBATLOG_OBJECT_TYPE_OBJECT = COMBATLOG_OBJECT_TYPE_OBJECT
local COMBATLOG_OBJECT_TYPE_MASK = COMBATLOG_OBJECT_TYPE_MASK
local COMBATLOG_OBJECT_TARGET = COMBATLOG_OBJECT_TARGET
local COMBATLOG_OBJECT_FOCUS = COMBATLOG_OBJECT_FOCUS
local COMBATLOG_OBJECT_MAINTANK = COMBATLOG_OBJECT_MAINTANK
local COMBATLOG_OBJECT_MAINASSIST = COMBATLOG_OBJECT_MAINASSIST
local COMBATLOG_OBJECT_RAIDTARGET1 = COMBATLOG_OBJECT_RAIDTARGET1
local COMBATLOG_OBJECT_RAIDTARGET2 = COMBATLOG_OBJECT_RAIDTARGET2
local COMBATLOG_OBJECT_RAIDTARGET3 = COMBATLOG_OBJECT_RAIDTARGET3
local COMBATLOG_OBJECT_RAIDTARGET4 = COMBATLOG_OBJECT_RAIDTARGET4
local COMBATLOG_OBJECT_RAIDTARGET5 = COMBATLOG_OBJECT_RAIDTARGET5
local COMBATLOG_OBJECT_RAIDTARGET6 = COMBATLOG_OBJECT_RAIDTARGET6
local COMBATLOG_OBJECT_RAIDTARGET7 = COMBATLOG_OBJECT_RAIDTARGET7
local COMBATLOG_OBJECT_RAIDTARGET8 = COMBATLOG_OBJECT_RAIDTARGET8
local COMBATLOG_OBJECT_NONE = COMBATLOG_OBJECT_NONE
local COMBATLOG_OBJECT_SPECIAL_MASK = COMBATLOG_OBJECT_SPECIAL_MASK
local COMBATLOG_FILTER_ME = COMBATLOG_FILTER_ME
local COMBATLOG_FILTER_MINE = COMBATLOG_FILTER_MINE
local COMBATLOG_FILTER_MY_PET = COMBATLOG_FILTER_MY_PET
local COMBATLOG_FILTER_FRIENDLY_UNITS = COMBATLOG_FILTER_FRIENDLY_UNITS
local COMBATLOG_FILTER_HOSTILE_UNITS = COMBATLOG_FILTER_HOSTILE_UNITS
local COMBATLOG_FILTER_HOSTILE_PLAYERS = COMBATLOG_FILTER_HOSTILE_PLAYERS
local COMBATLOG_FILTER_NEUTRAL_UNITS = COMBATLOG_FILTER_NEUTRAL_UNITS
local COMBATLOG_FILTER_UNKNOWN_UNITS = COMBATLOG_FILTER_UNKNOWN_UNITS
local COMBATLOG_FILTER_EVERYTHING = COMBATLOG_FILTER_EVERYTHING
local COMBATLOG = COMBATLOG
local AURA_TYPE_BUFF = AURA_TYPE_BUFF
local AURA_TYPE_DEBUFF = AURA_TYPE_DEBUFF
local SPELL_POWER_MANA = SPELL_POWER_MANA
local SPELL_POWER_RAGE = SPELL_POWER_RAGE
local SPELL_POWER_FOCUS = SPELL_POWER_FOCUS
local SPELL_POWER_ENERGY = SPELL_POWER_ENERGY
local SPELL_POWER_HAPPINESS = SPELL_POWER_HAPPINESS
local SPELL_POWER_RUNES = SPELL_POWER_RUNES
local SPELL_POWER_RUNIC_POWER = SPELL_POWER_RUNIC_POWER
local SCHOOL_MASK_NONE = SCHOOL_MASK_NONE
local SCHOOL_MASK_PHYSICAL = SCHOOL_MASK_PHYSICAL
local SCHOOL_MASK_HOLY = SCHOOL_MASK_HOLY
local SCHOOL_MASK_FIRE = SCHOOL_MASK_FIRE
local SCHOOL_MASK_NATURE = SCHOOL_MASK_NATURE
local SCHOOL_MASK_FROST = SCHOOL_MASK_FROST
local SCHOOL_MASK_SHADOW = SCHOOL_MASK_SHADOW
local SCHOOL_MASK_ARCANE = SCHOOL_MASK_ARCANE
local COMBATLOG_LIMIT_PER_FRAME = COMBATLOG_LIMIT_PER_FRAME
local COMBATLOG_HIGHLIGHT_MULTIPLIER = COMBATLOG_HIGHLIGHT_MULTIPLIER
local COMBATLOG_DEFAULT_COLORS = COMBATLOG_DEFAULT_COLORS
local COMBATLOG_DEFAULT_SETTINGS = COMBATLOG_DEFAULT_SETTINGS
local COMBATLOG_ICON_RAIDTARGET1 = COMBATLOG_ICON_RAIDTARGET1
local COMBATLOG_ICON_RAIDTARGET2 = COMBATLOG_ICON_RAIDTARGET2
local COMBATLOG_ICON_RAIDTARGET3 = COMBATLOG_ICON_RAIDTARGET3
local COMBATLOG_ICON_RAIDTARGET4 = COMBATLOG_ICON_RAIDTARGET4
local COMBATLOG_ICON_RAIDTARGET5 = COMBATLOG_ICON_RAIDTARGET5
local COMBATLOG_ICON_RAIDTARGET6 = COMBATLOG_ICON_RAIDTARGET6
local COMBATLOG_ICON_RAIDTARGET7 = COMBATLOG_ICON_RAIDTARGET7
local COMBATLOG_ICON_RAIDTARGET8 = COMBATLOG_ICON_RAIDTARGET8
local COMBATLOG_EVENT_LIST = COMBATLOG_EVENT_LIST
local UNIT_YOU_SOURCE = UNIT_YOU_SOURCE
local UNIT_YOU_DEST = UNIT_YOU_DEST
local UNIT_YOU_SOURCE_POSSESSIVE = UNIT_YOU_SOURCE_POSSESSIVE
local UNIT_YOU_DEST_POSSESSIVE = UNIT_YOU_DEST_POSSESSIVE
local TEXT_MODE_A_STRING_POSSESSIVE = TEXT_MODE_A_STRING_POSSESSIVE



--[[
      GLOBAL STRING OVERRIDES --------------------------------------------------------------------------------------------------
  ]]

ACTION_SPELL_CAST_START_POSSESSIVE = "1"
ACTION_SPELL_CAST_SUCCESS_POSSESSIVE = "1"




--[[
      UTILITIES ----------------------------------------------------------------------------------------------------------------
  ]]

function HitsMode5:tcopy(to, from)
 for k, v in pairs(from) do
  if type(v) == "table" then
   to[k] = {}
   HitsMode5:tcopy(to[k], v)
  else
   to[k] = v
  end
 end
end


function HitsMode5:Is(flags, expected)
	if flags == nil or expected == nil then return false end
 return bit.band(flags, expected) == expected
end


function boolToString(b)
	if b == true then return "true" end
	if b == false then return "false" end
	if b == nil then return "nil" end
end


-- Setup for string operations
-- do
	-- local stringFrame = CreateFrame("Frame")
	-- stringFrame:Hide()
	-- local fontString = stringFrame:CreateFontString(nil, nil, "GameFontNormal")
	-- format = function(s, ...)
		-- fontString:SetFormattedText(s, ...)
		-- return fontString:GetText()
	-- end
-- end


local function colorize(s, color, highlight)
	if color and s then
		if highlight then
			return string.format("|cff%02x%02x%02x%s|r", (color.r or 1) * 128 + 127, (color.g or 1) * 128 + 127, (color.b or 1) * 128 + 127, s)
		else
			return string.format("|cff%02x%02x%02x%s|r", (color.r or 1) * 255, (color.g or 1) * 255, (color.b or 1) * 255, s)
		end
	else
		return s
	end
end


local function abbreviate(name, doAbbreviate)
	if name == nil then return nil end
	if doAbbreviate == true or doAbbreviate == nil then
		local shortname = ""
		if strmatch(name, "[%(%)]") then
			name = strtrim(strgsub(strgsub(name, "%b()", ""), "  +", " "))
		end
		for word in strgmatch(name, "([^ ]+)") do
			local alpha, bravo = strutf8sub(word, 1, 1), strutf8sub(word, 2)
			if strmatch(bravo, ":") then
				shortname = shortname..alpha .. ":"
			else
				shortname = shortname..alpha
			end
		end
		return shortname
	else
		return name
	end
end


local function texture(t)
	return format("|T%s:0|t", t)
end


local function bracketize(f, s)
	if f.db.display.nameBrackets then
		return format("%s%s%s", colorize("[", HitsMode5.db.profile.colors.general.brackets), s, colorize("]", HitsMode5.db.profile.colors.general.brackets))
	else
		return s
	end
end



--[[
      INITIALIZATION -----------------------------------------------------------------------------------------------------------
  ]]

function HitsMode5:OnInitialize()
	-- Register database
 self.db = LibStub("AceDB-3.0"):New("HitsMode5DB", self.defaults, "Default")
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileDeleted", "OnProfileChanged")
	
	-- Register for slash commands
	self:RegisterChatCommand("hitsmode", "ChatCommand")
	self:RegisterChatCommand("hm", "ChatCommand")
end


function HitsMode5:OnEnable()
	if self.db.profile.enabled then

		-- Initialize settings
		self:UpgradeSettings()
		self:ReloadSettings()

		-- Register for events
		for k, v in pairs(specialEvents) do
			self:RegisterEvent(v, "OnSpecialEvent");
		end
		self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", "OnCombatEvent")
		
		-- Start a cleanup schedule
		cleanupTimer = self:ScheduleRepeatingTimer("CleanupUnitCache", 300)
	 
		-- Turn us on
		isEnabled = true

		--[===[@debug@
			self:Print(L["Loaded"])
		--@end-debug@]===]
		
	end
end


function HitsMode5:OnDisable()
	-- Unregister all events
	self:UnregisterAllEvents()
	
	-- Cancel all timers
	self:CancelAllTimers()

	-- Turn us off
	isEnabled = false
	
	--[===[@debug@
		self:Print(L["Disabled"])
	--@end-debug@]===]
end


function HitsMode5:ChatCommand(input)
	if not input or input:trim() == "" then
		if self.modules.options.loaded then InterfaceOptionsFrame_OpenToCategory(self.optionsFrame) end
	else
		LibStub("AceConfigCmd-3.0").HandleCommand(HitsMode5, "hm", "HitsMode5", input)
	end
end


function HitsMode5:OnProfileChanged(event, database, newProfileKey)
	--[===[@debug@
		self:Print(L["Profile modified, rebooting"])
	--@end-debug@]===]
 self:Disable()
 self:Enable() 
end


function HitsMode5:OpenChatWindow(i)
	local name, fontSize, r, g, b, alpha, shown, locked, docked, uninteractable = GetChatWindowInfo(i)
 local chatFrame = _G["ChatFrame"..i]
 local chatTab = _G["ChatFrame"..i.."Tab"]
 if not shown and not chatFrame.isDocked then
		if not name or strtrim(name) == "" then
			FCF_SetWindowName(chatFrame, format(L["Chat %d"], i))
		end
  --FCF_SetWindowColor(chatFrame, DEFAULT_CHATFRAME_COLOR.r, DEFAULT_CHATFRAME_COLOR.g, DEFAULT_CHATFRAME_COLOR.b)
  --FCF_SetWindowAlpha(chatFrame, DEFAULT_CHATFRAME_ALPHA)
  SetChatWindowLocked(i, nil)
  --ChatFrame_RemoveAllMessageGroups(chatFrame)
  chatFrame:Show()
  SetChatWindowShown(i, 1)
  --FCF_DockFrame(chatFrame, i)
 end
end



--[[
      HELP SYSTEM --------------------------------------------------------------------------------------------------------------
  ]]

-- do
	-- local i
	-- for i = 1, NUM_HELPARTICLES do
		-- HelpLib.AddQuestion({
			-- q = L["help_question_"..i],
			-- a = L["help_answer_"..i],
			-- cat = "HitsMode5",
		-- });
	-- end
-- end

--[[function HitsMode5:CheckHelpLoaded()
 if (KBSetup_IsLoaded()) then
  KnowledgeBaseFrameEditBox:SetText("")
  UIDropDownMenu_SetSelectedName(KnowledgeBaseFrameCategoryDropDown, "HitsMode5")
  KnowledgeBaseFrame_Search(1)
 else
		self:ScheduleTimer("CheckHelpLoaded", 0.2)
 end
end]]



--[[
      FILTERS ------------------------------------------------------------------------------------------------------------------
  ]]

-- Filter prototype
HitsMode5.Filter = {}
local mt = {__index = HitsMode5.Filter}


function HitsMode5.Filter:new()
 return setmetatable({
		someproperty = 1
 }, mt)
end


function HitsMode5.Filter:destroy()
	if HitsMode5.modules.options.loaded then
		HitsMode5.options.args.filters.args[self.db.name] = nil
	end
end


function HitsMode5.Filter:UpdateFlags()
	self.sourceFlags = 0
	for k, v in pairs(self.db.sourceFlags) do
		if v then self.sourceFlags = self.sourceFlags + k end
	end
	self.destFlags = 0
	for k, v in pairs(self.db.destFlags) do
		if v then self.destFlags = self.destFlags + k end
	end
end


local function stringToArray(s)
	local hasMembers = false
	local a = { strsplit(",", s) }
	local b = {}
	for k, v in pairs(a) do
		if strtrim(v) ~= "" then
			b[strlower(strtrim(v))] = true
			hasMembers = true
		end
	end
	return b, hasMembers
end


function HitsMode5.Filter:UpdateWhiteBlackLists()
	self.sourceNameWhiteList, self.sourceNameWhiteListEnabled = stringToArray(self.db.sourceWhiteList)
	self.sourceNameBlackList, self.sourceNameBlackListEnabled = stringToArray(self.db.sourceBlackList)
	self.destNameWhiteList, self.destNameWhiteListEnabled = stringToArray(self.db.destWhiteList)
	self.destNameBlackList, self.destNameBlackListEnabled = stringToArray(self.db.destBlackList)
	self.spellNameWhiteList, self.spellNameWhiteListEnabled = stringToArray(self.db.display.spellNameWhiteList)
	self.spellNameBlackList, self.spellNameBlackListEnabled = stringToArray(self.db.display.spellNameBlackList)
end


function HitsMode5:GetFilters()
	return self.filters
end


function HitsMode5:CreateFilter(name, db)
	if not db then
		db = {}
		self:tcopy(db, self.filterDefaults)
		table.insert(self.db.profile.filters, db)
	end

	local filter = HitsMode5.Filter:new()
	filter.db = db
	filter.db.name = name
	
	table.insert(self.filters, filter)
	if self.modules.options.loaded then filter:AddOptions() end
	
	filter:UpdateFlags()
	filter:UpdateWhiteBlackLists()
	self:ApplySettings()
end


function HitsMode5:DeleteFilter(name)
	for k, v in pairs(self.filters) do
		if v.db.name == name then
			v:destroy()
			wipe(table.remove(self.filters, k))
		end
	end
	for k, v in ipairs(self.db.profile.filters) do
		if v.name == name then
			table.remove(self.db.profile.filters, k)
		end
	end
	HitsMode5.options.args.filters.args[name] = nil
end



--[[
      SETTINGS -----------------------------------------------------------------------------------------------------------------
  ]]
  
function HitsMode5:UpgradeSettings()
	-- Placeholder function in case we have to do some tricky options upgrading in the future
	-- For now, just keep track of the version we used last
	self.db.profile.lastVersion = self.db.profile.currentVersion or self.MINOR_VERSION
	self.db.profile.currentVersion = self.MINOR_VERSION
end

function HitsMode5:ReloadSettings()
	for k, v in pairs(self.filters) do
		v:destroy()
	end
	self.filters = {}

	for k, v in ipairs(self.db.profile.filters) do
		self:CreateFilter(v.name, v)
	end
	
	if #self.db.profile.filters <= 0 then
		self:Print(L["You have no filters. Creating a default filter."])
		self:CreateFilter(L["Default"])
	end
	
	self:ApplySettings()
end


function HitsMode5:ApplySettings()
end


--[[
      EVENTS -------------------------------------------------------------------------------------------------------------------
  ]]

local function chatToMatch(s)
	return strreplace(strreplace(s, "%%s", "(.+)"), "%%d", "(%d+)")
end


local function writeSpecialEvent(f, s, c, possessive)
	local you
	if not f.db.display.nameYou then
		if possessive then you = format(TEXT_MODE_A_STRING_POSSESSIVE, UnitName("player")) else you = UnitName("player") end
	else
		if possessive then you = UNIT_YOU_SOURCE_POSSESSIVE else you = UNIT_YOU_SOURCE end
	end
	
	if f.db.display.nameAbbreviate then you = abbreviate(you) end
	
	if f.db.display.nameColorByClass then
		you = colorize(you, (RAID_CLASS_COLORS[({UnitClass("player")})[2]]))
	else
		you = colorize(you, HitsMode5.db.profile.colors.unitNames.you)
	end
	
	_G["ChatFrame"..f.db.display.chatWindow]:AddMessage(format("%s %s", bracketize(f, you), colorize(s, c)))
end


function HitsMode5:OnSpecialEvent(event, arg1, ...)
 if (isEnabled) then
 
		local a, b, _
		
		for filterKey, f in pairs(self.filters) do
			if f.db.enabled and (f.db.specialEvents[event] or event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_REGEN_DISABLED") then

				if event == "PLAYER_REGEN_ENABLED" then
					if f.db.display.combatSeparator and f.db.display.combatSeparator ~= "" then
						_G[format("ChatFrame%d", f.db.display.chatWindow)]:AddMessage(colorize(f.db.display.combatSeparator, self.db.profile.colors.general.text))
					end
					self:CleanupUnitCache()

				elseif event == "CHAT_MSG_COMBAT_FACTION_CHANGE" then
			 
					for a, b in string.gmatch(arg1, chatToMatch(FACTION_STANDING_INCREASED)) do -- Reputation with (.+) increased by (%d+).
						if f.db.display.flags["FLAG_REP"] then b = "+"..b end
						writeSpecialEvent(f, format(L["gain reputation %s %s"], bracketize(f, colorize(a, self.db.profile.colors.specialEvents.reputation)), colorize(b, self.db.profile.colors.specialEvents.reputation)), self.db.profile.colors.specialEvents.reputation)
						return
					end
					for a, b in string.gmatch(arg1, chatToMatch(FACTION_STANDING_DECREASED)) do -- Reputation with (.+) decreased by (%d+).
						if f.db.display.flags["FLAG_REP"] then b = "-"..b end
						writeSpecialEvent(f, format(L["lose reputation %s %s"], bracketize(f, colorize(a, self.db.profile.colors.specialEvents.reputation)), colorize(b, self.db.profile.colors.specialEvents.reputation)), self.db.profile.colors.specialEvents.reputation)
						return
					end

				elseif event == "CHAT_MSG_LOOT" or event == "CHAT_MSG_MONEY" then
			 
					for a in string.gmatch(arg1, chatToMatch(LOOT_ITEM_SELF)) do -- You receive loot: (.+).
						writeSpecialEvent(f, format(L["loot %s"], a), self.db.profile.colors.specialEvents.loot)
						return
					end
					for a in string.gmatch(arg1, chatToMatch(YOU_LOOT_MONEY)) do -- You loot (.+)
						writeSpecialEvent(f, format(L["loot %s"], a), self.db.profile.colors.specialEvents.loot)
						return
					end
					for a in string.gmatch(arg1, chatToMatch(LOOT_MONEY_SPLIT)) do -- Your share of the loot is (.+).
						writeSpecialEvent(f, format(L["share of the loot is %s"], a), self.db.profile.colors.specialEvents.loot, true)
						return
					end
					-- for a, b in string.gmatch(arg1, chatToMatch(LOOT_ITEM)) do -- (.+) receives loot: (.+).
						-- --self:Output("they_loot", a, HM_COMBATLOG_OBJECT_PARTYMEMBER, nil, nil, nil, "PLAYERLOOTS", { amount = b });
						-- return
					-- end
					for a in string.gmatch(arg1, chatToMatch(LOOT_ITEM_CREATED_SELF)) do -- You create: (.+).
						writeSpecialEvent(f, format(L["create %s"], a), self.db.profile.colors.specialEvents.loot)
						return
					end
			  
				elseif event == "CHAT_MSG_SKILL" then

					for a, b in string.gmatch(arg1, chatToMatch(SKILL_RANK_UP)) do -- Your skill in (.+) has increased to ([%d]+)
						writeSpecialEvent(f, format("%s"..colorize(L[" skill has increased to %s"], self.db.profile.colors.specialEvents.skill), bracketize(f, colorize(a, self.db.profile.colors.specialEvents.skill)), colorize(b, self.db.profile.colors.specialEvents.skill)), self.db.profile.colors.specialEvents.skill, true)
						return
					end

				elseif event == "CHAT_MSG_COMBAT_HONOR_GAIN" then

					for a in string.gmatch(arg1, "([%d]+)") do -- ([%d]+)
						if f.db.display.flags["FLAG_HONOR"] then a = "+"..a end
						writeSpecialEvent(f, format(L["create %s"], a), self.db.profile.colors.specialEvents.loot)
						return
					end

				elseif event == "CHAT_MSG_COMBAT_XP_GAIN" then
			 
					_, _, a = string.find(arg1, L["CHAT_MSG_COMBAT_XP_GAIN_1"]) -- .* gain (%d+).*
					_, _, b = string.find(arg1, L["CHAT_MSG_COMBAT_XP_GAIN_2"]) -- experience%. %(%+(%d+) exp Rested bonus
					if b and f.db.display.includeRestedExperience then a = (a or "").." (+"..b..L[" rested"]..")" end
					if f.db.display.flags["FLAG_EXP"] then a = "+"..a end
					writeSpecialEvent(f, format(L["gain experience %s"], a or "0"), self.db.profile.colors.specialEvents.experience)
					return
			
				end -- events
			end -- filter enabled
		end -- filter loop
 end -- addon enabled
end


function HitsMode5:OnCombatEvent(event, ...)
 if isEnabled and not self.replaying then
		self:Render(false, self.filters, ...)
 end
end



--[[
      DATA BROKER OBJECT -------------------------------------------------------------------------------------------------------
  ]]
  
function dataobj:OnEnter()
 GameTooltip:SetOwner(self, "ANCHOR_NONE")
 GameTooltip:SetPoint("TOPLEFT", self, "BOTTOMLEFT")
 GameTooltip:ClearLines()
 GameTooltip:AddLine("|cffffff20HitsMode5|r", 0, 1, 0)
	if _G["HitsMode5ProgressBar"].progressing or HitsMode5.replaying then
		GameTooltip:AddLine(L["HitsMode5 is currently replaying combat."], 0, 1, 0)
		GameTooltip:AddLine(L["|cfffbd284Shift-Click|r to cancel."], 0, 1, 0)
	else
		if HitsMode5.modules.replay.loaded then
			GameTooltip:AddLine(L["|cfffbd284Left-Click|r to start an Instant Replay."], 0, 1, 0)
		end
		GameTooltip:AddLine(format(L["|cfffbd284Shift-Click|r to replay %d lines of recent combat."], CombatLogGetNumEntries(true)), 0, 1, 0)
		if HitsMode5.modules.options.loaded then
			GameTooltip:AddLine(L["|cfffbd284Right-Click|r to open configuration."], 0, 1, 0)
		end
	end
 GameTooltip:Show()
end

function dataobj:OnLeave()
 GameTooltip:Hide()
end

function dataobj:OnClick(button)
	if button == "LeftButton" and IsShiftKeyDown() then
		if _G["HitsMode5ProgressBar"].progressing or HitsMode5.replaying then
			HitsMode5:CancelReplay()
		else
			HitsMode5:Replay()
		end
	elseif button == "LeftButton" then
		if HitsMode5.modules.replay.loaded then
			if _G["HitsMode5ProgressBar"].progressing or HitsMode5.replaying then
				self:Print(L["Replay is already running. Please wait for it to finish."])
			else
				if HitsMode5.modules.replay.replayFrame then HitsMode5.modules.replay.replayFrame:Hide() end
				HitsMode5:OpenInstantReplay()
			end
		end
	elseif button == "RightButton" then
		if HitsMode5.modules.options.loaded then
			if HitsMode5.modules.replay.replayFrame then HitsMode5.modules.replay.replayFrame:Hide() end
			InterfaceOptionsFrame_OpenToCategory(HitsMode5.optionsFrame)
		end
	end
end



--[[
      REPLAY -------------------------------------------------------------------------------------------------------------------
  ]]

function HitsMode5:Replay()
	if _G["HitsMode5ProgressBar"].progressing or HitsMode5.replaying then
		self:Print(L["Replay is already running. Please wait for it to finish."])
		return
	end
	HitsMode5.replaying = true

	-- Clear all chat windows
	for filterKey, f in pairs(self.filters) do
		local chatFrame = _G["ChatFrame"..f.db.display.chatWindow]
		if chatFrame then
			chatFrame:Clear()
		end
	end

	-- Set the combat log index
	local count = CombatLogGetNumEntries(true)
	CombatLogSetCurrentEntry(1, true)
	
	-- Start the progress bar
	self:ProgressBar_Start(count, self.ReplayUpdate)
end


function HitsMode5.ReplayUpdate(bar, elapsed, value, maxValue)
	if not bar.progressing then return end
	local valid = CombatLogGetCurrentEntry(true)
	
	-- Render a chunk of lines
	local total = 0
	while valid and total < HitsMode5.db.profile.replayLinesPerFrame do 
		HitsMode5:Render(true, HitsMode5.filters, CombatLogGetCurrentEntry(true))
		valid = CombatLogAdvanceEntry(1, true)
		total = total + 1
	end

	-- Update the progress bar
	HitsMode5:ProgressBar_Update(value + total)
	
	-- End replay if we're done
	if not valid then
		HitsMode5:ProgressBar_End()
		HitsMode5:CleanupUnitCache()
		HitsMode5.replaying = false
	end
end


function HitsMode5:CancelReplay()
	if _G["HitsMode5ProgressBar"].progressing or HitsMode5.replaying then
		self:ProgressBar_Cancel()
		CombatLogSetCurrentEntry(0, true)
		HitsMode5:CleanupUnitCache()
		HitsMode5.replaying = false
	end
end



--[[
      UNIT CACHE ---------------------------------------------------------------------------------------------------------------
  ]]
  
local function primeUnitCache(filter, name, flags)
	if (filter.db.display.nameColorByClass or filter.db.display.nameShowLevel) and name then
		if unitCache[name] then
			unitCache[name][1] = GetTime()
			--unitCache[name][3] = UnitLevel(name)
		else
			local localizedClass, englishClass = UnitClass(name)
			unitCache[name] = { [1] = GetTime(), [2] = englishClass --[[, [3] = UnitLevel(name)]] }
		end
	end
end


local cleaningCache = false
function HitsMode5:CleanupUnitCache()
	if not cleaningCache then
		cleaningCache = true
		--[===[@debug@
		local numTotal = 0
		local numRemoved = 0
		--@end-debug@]===]
		
		for k, v in pairs(unitCache) do
		--[===[@debug@
			numTotal = numTotal + 1
		--@end-debug@]===]
			if v[1] and (GetTime() - v[1]) > 900 then -- Remove cache items older than 15 minutes
				unitCache[k] = nil
		--[===[@debug@
				numRemoved = numRemoved + 1
		--@end-debug@]===]
			end
		end
		
		--[===[@debug@
		-- UpdateAddOnMemoryUsage()
		-- local mem = GetAddOnMemoryUsage("HitsMode5")
		-- self:Print(format("Removed %d items from unit cache out of %d total. Using %dk.", numRemoved, numTotal, mem))
		--@end-debug@]===]
		cleaningCache = false
	end
end



--[[
      RENDERER -----------------------------------------------------------------------------------------------------------------
  ]]

local function formatExtraValues(filter, spellId, resisted, blocked, absorbed, critical, glancing, crushing, overhealing, overkill)
	local resultStr = ""
	local useOverhealing = overhealing and overhealing > 0
	local useOverkill = overkill and overkill > 0
	local useAbsorbed = absorbed and absorbed > 0
	local abbr = filter.db.display.abbreviateExtraValues
	
	if resisted or blocked or critical or glancing or crushing or useOverhealing or useOverkill or useAbsorbed then
		if resisted then
			if resisted < 0 then
				if abbr then
					resultStr = resultStr..format(L[" (%d v)"], -resisted)
				else
					resultStr = resultStr..format(L[" (%d vulnerability damage)"], -resisted)
				end
			else
				if abbr then
					resultStr = resultStr..format(L[" (%d r)"], resisted)
				else
					resultStr = resultStr..format(L[" (%d resisted)"], resisted)
				end
			end
		end
		if blocked then
			if abbr then
				resultStr = resultStr..format(L[" (%d b)"], blocked)
			else
				resultStr = resultStr..format(L[" (%d blocked)"], blocked)
			end
		end
		if useAbsorbed then
			if abbr then
				resultStr = resultStr..format(L[" (%d a)"], absorbed)
			else
				resultStr = resultStr..format(L[" (%d absorbed)"], absorbed)
			end
		end
		if glancing then
			if abbr then
				resultStr = resultStr..L[" (g)"]
			else
				resultStr = resultStr..L[" (glancing)"]
			end
		end
		if crushing then
			if abbr then
				resultStr = resultStr..L[" (c)"]
			else
				resultStr = resultStr..L[" (crushing)"]
			end
		end
		if useOverhealing then
			if abbr then
				resultStr = resultStr..format(L[" (%d o)"], overhealing)
			else
				resultStr = resultStr..format(L[" (%d overheal)"], overhealing)
			end
		end
		if useOverkill then
			if abbr then
				resultStr = resultStr..format(L[" (%d o)"], overkill)
			else
				resultStr = resultStr..format(L[" (%d overkill)"], overkill)
			end
		end
 end

	if resultStr == "" then return nil else return resultStr end
end


local function chooseUnitColor(filter, name, flags)
	if not name or name == "" then return HitsMode5.db.profile.colors.unitNames.unknown end 
	if unitCache[name][2] and filter.db.display.nameColorByClass then
		return RAID_CLASS_COLORS[unitCache[name][2]]
	else
		if CombatLog_Object_IsA(flags, COMBATLOG_FILTER_ME) then return HitsMode5.db.profile.colors.unitNames.you
		elseif CombatLog_Object_IsA(flags, COMBATLOG_FILTER_MY_PET) then return HitsMode5.db.profile.colors.unitNames.pet
		elseif CombatLog_Object_IsA(flags, COMBATLOG_FILTER_FRIENDLY_UNITS) then return HitsMode5.db.profile.colors.unitNames.friends
		elseif CombatLog_Object_IsA(flags, COMBATLOG_FILTER_HOSTILE_UNITS) then return HitsMode5.db.profile.colors.unitNames.hostileUnits
		elseif CombatLog_Object_IsA(flags, COMBATLOG_FILTER_HOSTILE_PLAYERS) then return HitsMode5.db.profile.colors.unitNames.hostilePlayers
		elseif CombatLog_Object_IsA(flags, COMBATLOG_FILTER_NEUTRAL_UNITS) then return HitsMode5.db.profile.colors.unitNames.neutral
		else return HitsMode5.db.profile.colors.unitNames.unknown
		end
	end
end


local function getRaidIcon(flags)
 -- These only work in party/raid. If you're solo, the flags return 0.
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET1) == COMBATLOG_OBJECT_RAIDTARGET1 then return ICON_LIST[1].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET2) == COMBATLOG_OBJECT_RAIDTARGET2 then return ICON_LIST[2].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET3) == COMBATLOG_OBJECT_RAIDTARGET3 then return ICON_LIST[3].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET4) == COMBATLOG_OBJECT_RAIDTARGET4 then return ICON_LIST[4].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET5) == COMBATLOG_OBJECT_RAIDTARGET5 then return ICON_LIST[5].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET6) == COMBATLOG_OBJECT_RAIDTARGET6 then return ICON_LIST[6].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET7) == COMBATLOG_OBJECT_RAIDTARGET7 then return ICON_LIST[7].."0|t" end
 if bit_band(flags, COMBATLOG_OBJECT_RAIDTARGET8) == COMBATLOG_OBJECT_RAIDTARGET8 then return ICON_LIST[8].."0|t" end
 return ""
end


local function chooseAmountColor(filter, srcFlags, spellSchool, spellName, eventCat)
	if spellSchool and eventCat == "damage" and filter.db.display.spellColorBySchool then
		if bit_band(spellSchool, SCHOOL_MASK_ARCANE) == SCHOOL_MASK_ARCANE then return HitsMode5.db.profile.colors.spellSchools.arcane
		elseif bit_band(spellSchool, SCHOOL_MASK_FIRE) == SCHOOL_MASK_FIRE then return HitsMode5.db.profile.colors.spellSchools.fire
		elseif bit_band(spellSchool, SCHOOL_MASK_FROST) == SCHOOL_MASK_FROST then return HitsMode5.db.profile.colors.spellSchools.frost
		elseif bit_band(spellSchool, SCHOOL_MASK_HOLY) == SCHOOL_MASK_HOLY then return HitsMode5.db.profile.colors.spellSchools.holy
		elseif bit_band(spellSchool, SCHOOL_MASK_NATURE) == SCHOOL_MASK_NATURE then return HitsMode5.db.profile.colors.spellSchools.nature
		elseif bit_band(spellSchool, SCHOOL_MASK_SHADOW) == SCHOOL_MASK_SHADOW then return HitsMode5.db.profile.colors.spellSchools.shadow
		end
	end
	
	if bit_band(srcFlags, COMBATLOG_OBJECT_REACTION_FRIENDLY) == COMBATLOG_OBJECT_REACTION_FRIENDLY then
		if eventCat == "damage" and spellName then return HitsMode5.db.profile.colors.combatEvents.friendlySpellDamage
		elseif eventCat == "damage" then return HitsMode5.db.profile.colors.combatEvents.friendlyDamage
		elseif eventCat == "energize" then return HitsMode5.db.profile.colors.combatEvents.energizes
		elseif eventCat == "heal" then return HitsMode5.db.profile.colors.combatEvents.friendlyHeals
		end
	else
		if eventCat == "damage" and spellName then return HitsMode5.db.profile.colors.combatEvents.hostileSpellDamage
		elseif eventCat == "damage" then return HitsMode5.db.profile.colors.combatEvents.hostileDamage
		elseif eventCat == "energize" then return HitsMode5.db.profile.colors.combatEvents.energizes
		elseif eventCat == "heal" then return HitsMode5.db.profile.colors.combatEvents.hostileHeals
		end
	end
	
	return HitsMode5.db.profile.colors.general.text
end


local function formatExtraValuesEnergize(f, spellId, powerType)
	local resultStr = ""
	
	if powerType == SPELL_POWER_MANA then resultStr = MANA
	elseif powerType == SPELL_POWER_RAGE then resultStr = RAGE
	elseif powerType == SPELL_POWER_ENERGY then resultStr = ENERGY
	elseif powerType == SPELL_POWER_FOCUS then resultStr = FOCUS
	elseif powerType == SPELL_POWER_HAPPINESS then resultStr = HAPPINESS
	elseif powerType == SPELL_POWER_RUNES then resultStr = RUNES
	elseif powerType == SPELL_POWER_RUNIC_POWER then resultStr = RUNIC_POWER
	end
	
	if resultStr == "" then return nil else return format("(%s)", strlower(resultStr)) end
end


local function addDose(s, dose)
	if dose then return format("%s (%d)", s, dose) else return s end
end


local function formatSpell(f, spellId, spellName, spellSchool)
	local _, spellRank, spellIcon, spellNameStr

	-- Get some extra information about the spell
	if spellId then
			_, spellRank, spellIcon = GetSpellInfo(spellId)
	end
	
	-- Convert to spell display format
	if spellName then
		spellNameStr = spellName

		if f.db.display.spellDisplayMode == SPELLDISPLAYMODE_TEXT then
			spellNameStr = colorize(addDose(spellNameStr, dose), HitsMode5.db.profile.colors.general.spells)
			
		elseif f.db.display.spellDisplayMode == SPELLDISPLAYMODE_ABBREVIATED_TEXT then
			spellNameStr = colorize(addDose(abbreviate(spellNameStr), dose), HitsMode5.db.profile.colors.general.spells)

		elseif f.db.display.spellDisplayMode == SPELLDISPLAYMODE_LINK then
			if spellId then
				spellNameStr = format("|Hspell:%d|h|r|cff71d5ff[%s]|r|h", spellId, addDose(spellName, dose))
			else
				spellNameStr = colorize(addDose(spellNameStr, dose), HitsMode5.db.profile.colors.general.spells)
			end

		elseif f.db.display.spellDisplayMode == SPELLDISPLAYMODE_ABBREVIATED_LINK then
			if spellId then
					spellNameStr = format("|Hspell:%d|h|r|cff71d5ff[%s]|r|h", spellId, addDose(abbreviate(spellName), dose))
			else
				spellNameStr = colorize(addDose(abbreviate(spellNameStr), dose), HitsMode5.db.profile.colors.general.spells)
			end
		
		elseif f.db.display.spellDisplayMode == SPELLDISPLAYMODE_NONE then
			spellNameStr = ""
		
		end
	end

	-- Add spell icon
	if spellIcon and f.db.display.spellShowIcons then
		spellNameStr = texture(spellIcon)..spellNameStr
	end
	
	return spellNameStr
end


function HitsMode5:Render(isReplay, filters, timestamp, eventType, hideCaster, srcGuid, srcName, srcFlags, srcRaidFlags, dstGuid, dstName, dstFlags, dstRaidFlags, ...)

	--self:Print(eventType, srcName, dstName)

	-- Variables
	local spellId, spellName, spellSchool
	local extraSpellId, extraSpellName, extraSpellSchool
	local nameIsNotSpell, extraNameIsNotSpell
	local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, overhealing, dose
	local missType, amountMissed
	local auraType
	local itemId, itemName
	local extraAmount
	local powerType
	local environmentalType
	local finalString, messageFormat, formatType, extra, forEnabled
	local srcNameLower = strlower(srcName or "")
	local dstNameLower = strlower(dstName or "")
	local spellNameLower
	local action
	local srcNameStr, dstNameStr, spellNameStr, amountStr, extraSpellNameStr
	local _, spellRank, spellIcon
	local eventCat, extEvent


	-- Loop through all filters
	for filterKey, f in pairs(filters) do

		-- Filter enabled
		if f.db.enabled then

			-- Hash lookup to see if the combat event is needed
			if f.db.events[eventType] then
			
				-- Use the prebuilt flag bitfields to quickly check if the event passes the filter
				-- This comparison is entirely in C, so it should be speedy
				if (f.db.unitComparisonMode == UNITCOMPARISONMODE_AND and CombatLog_Object_IsA(srcFlags, f.sourceFlags) and CombatLog_Object_IsA(dstFlags, f.destFlags)) or
				   (f.db.unitComparisonMode == UNITCOMPARISONMODE_OR and (CombatLog_Object_IsA(srcFlags, f.sourceFlags) or CombatLog_Object_IsA(dstFlags, f.destFlags))) then
				
					-- Use prebuilt hash lookups to see if the units pass the black/white lists
					if ((f.sourceNameWhiteListEnabled and f.sourceNameWhiteList[srcNameLower]) or f.sourceNameWhiteListEnabled == false or srcNameLower == "") and
								((f.sourceNameBlackListEnabled and f.sourceNameBlackList[srcNameLower] == nil) or f.sourceNameBlackListEnabled == false or srcNameLower == "") and
								((f.destNameWhiteListEnabled and f.destNameWhiteList[dstNameLower]) or f.destNameWhiteListEnabled == false or dstNameLower == "") and
								((f.destNameBlackListEnabled and f.destNameBlackList[dstNameLower] == nil) or f.destNameBlackListEnabled == false or dstNameLower == "")
					then
					
						-- Check if missing units are allowed for this filter
						if (((not srcName or srcName == "") and f.db.showMissingSource) or srcName) and
						   (((not dstName or dstName == "") and f.db.showMissingDest) or dstName) then
						
							-- Start with an action string from Blizzard's global strings; we may override this below
							action = _G["ACTION_"..eventType]

							-- Get what we need from the event, and prepare our presentation
							if eventType == "RANGE_DAMAGE" or eventType == "SPELL_DAMAGE" or eventType == "SPELL_PERIODIC_DAMAGE" or eventType == "DAMAGE_SHIELD" or eventType == "DAMAGE_SPLIT" or eventType == "SPELL_BUILDING_DAMAGE" then
								spellId, spellName, spellSchool, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(1, ...)
								eventCat = "damage"
								formatType = "A"
								if eventType == "SPELL_PERIODIC_DAMAGE" and critical then action = L["crit damaged"]
								elseif critical then action = L["crit"]
								end
								forEnabled = true
								extra = formatExtraValues(f, spellId, resisted, blocked, absorbed, critical, glancing, crushing, overhealing, overkill)

							elseif eventType == "SWING_DAMAGE" then
								amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(1, ...)
								eventCat = "damage"
								formatType = "A"
								if critical then action = L["crit"] end
								forEnabled = true
								extra = formatExtraValues(f, spellId, resisted, blocked, absorbed, critical, glancing, crushing, overhealing, overkill)
								
							elseif eventType == "SPELL_HEAL" or eventType == "SPELL_PERIODIC_HEAL" or eventType == "SPELL_BUILDING_HEAL" then
								spellId, spellName, spellSchool, amount, overhealing, absorbed, critical = select(1, ...)
								eventCat = "heal"
								formatType = "A"
								if critical then action = L["crit healed"] end
								forEnabled = true
								extra = formatExtraValues(f, spellId, resisted, blocked, absorbed, critical, glancing, crushing, overhealing, overkill)
								
							elseif eventType == "SPELL_ENERGIZE" or eventType == "SPELL_PERIODIC_ENERGIZE" then
								spellId, spellName, spellSchool, amount, powerType = select(1, ...)
								eventCat = "energize"
								formatType = "A"
								forEnabled = true
								extra = formatExtraValuesEnergize(f, spellId, powerType)
								
							elseif eventType == "SPELL_AURA_APPLIED" or eventType == "SPELL_AURA_REFRESH" or eventType == "SPELL_AURA_REMOVED" then
								spellId, spellName, spellSchool, auraType = select(1, ...)
								eventCat = "aura"
								formatType = "A"
								if eventType == "SPELL_AURA_REMOVED" then action = L["faded"] end
								
							elseif eventType == "SPELL_AURA_APPLIED_DOSE" or eventType == "SPELL_AURA_REMOVED_DOSE" then
								spellId, spellName, spellSchool, auraType, dose = select(1, ...)
								eventCat = "aura"
								formatType = "A"
								if eventType == "SPELL_AURA_REMOVED_DOSE" then action = L["lost a stack"] end
								
							elseif eventType == "RANGE_MISSED" or eventType == "SPELL_MISSED" or eventType == "SPELL_PERIODIC_MISSED" or eventType == "DAMAGE_SHIELD_MISSED" then
								spellId, spellName, spellSchool, missType, amountMissed = select(1, ...)
								eventCat = "miss"
								formatType = "A"
								if missType ~= "MISS" then
									extra = strlower(_G["ACTION_"..eventType.."_"..missType])
									extra = strreplace(extra, "%(", "")
									extra = strreplace(extra, "%)", "")
									extra = "("..extra..")"
								end
								
							elseif eventType == "SWING_MISSED" then
								missType, amountMissed = select(1, ...)
								eventCat = "miss"
								formatType = "A"
								if missType ~= "MISS" then
									extra = strlower(_G["ACTION_"..eventType.."_"..missType])
									extra = strreplace(extra, "%(", "")
									extra = strreplace(extra, "%)", "")
									extra = "("..extra..")"
								end
								
							elseif eventType == "SPELL_DRAIN" or eventType == "SPELL_PERIODIC_DRAIN" then
								spellId, spellName, spellSchool, amount, powerType, extraAmount = select(1, ...)
								eventCat = "damage"
								formatType = "A"
								
							elseif eventType == "SPELL_LEECH" or eventType == "SPELL_PERIODIC_LEECH" then
								-- Amount is the gain for the source and extraAmount is the loss for the dest
								spellId, spellName, spellSchool, amount, powerType, extraAmount = select(1, ...)
								eventCat = "damage"
								formatType = "A"
			 
							elseif eventType == "SPELL_EXTRA_ATTACKS" then
								spellId, spellName, spellSchool, amount = select(1, ...)
								eventCat = "energize"
								formatType = "A"
								
							elseif eventType == "SPELL_DISPEL" then
								-- First spell is the one causing the aura to be dispelled or otherwise cancelled, and the second is the name of the aura that is being dispelled
								spellId, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool, auraType = select(1, ...)
								formatType = "A"
								eventCat = "spell_interaction"
								with = true

							elseif eventType == "SPELL_STOLEN" then
								-- First spell is the one that caused the spell steal. Second spell is the spell that was stolen.
								spellId, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool, auraType = select(1, ...)
								formatType = "A"
								eventCat = "spell_interaction"

							elseif eventType == "SPELL_AURA_BROKEN" then
								-- Only populate extra* for this, since we didn't break the crowd control with a spell
								-- Shows as: [You] broke [Mob's] CC_Spell
								extraSpellId, extraSpellName, extraSpellSchool, auraType = select(1, ...)
								formatType = "A"
								
							elseif eventType == "SPELL_AURA_BROKEN_SPELL" then
								-- Source is the unit breaking crowd control
								-- Dest is the unit who was being crowd controlled
								-- First spell is the crowd control spell
								-- Second spell is the spell that broke it
								-- So this event gets reversed; we want to say: [Your] Spell broke [Mob's] CC_Spell
								extraSpellId, extraSpellName, extraSpellSchool, spellId, spellName, spellSchool, auraType = select(1, ...)
								formatType = "A"
								eventCat = "spell_interaction"
								action = _G["ACTION_"..eventType.."_"..auraType]

							elseif eventType == "ENVIRONMENTAL_DAMAGE" then
								environmentalType, amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing = select(1, ...)
								formatType = "A"
								eventCat = "damage"
								forEnabled = true
								if not srcName then
									srcName = _G["ACTION_"..eventType.."_"..environmentalType]
									srcFlags = COMBATLOG_FILTER_HOSTILE_UNITS
								end
							
							elseif eventType == "SPELL_INTERRUPT" then
								-- SpellName does the interrupting, extraSpellName is what gets interrupted
								extraSpellId, extraSpellName, extraSpellSchool, spellId, spellName, spellSchool = select(1, ...)
								formatType = "A"
								eventCat = "spell_interaction"

							elseif eventType == "SPELL_CAST_START" then
								spellId, spellName, spellSchool = select(1, ...)
								formatType = "A"
								
							elseif eventType == "SPELL_CAST_SUCCESS" then
								spellId, spellName, spellSchool = select(1, ...)
								formatType = "A"
								
							elseif eventType == "SPELL_CAST_FAILED" then
								spellId, spellName, spellSchool, missType = select(1, ...)
								formatType = "A"
								extra = format("(%s)", strlower(missType))
								
							elseif eventType == "SPELL_DISPEL_FAILED" then
								spellId, spellName, spellSchool, extraSpellId, extraSpellName, extraSpellSchool = select(1, ...)
								formatType = "A"
								eventCat = "spell_interaction"
								
							elseif eventType == "SPELL_INSTAKILL" then
								spellId, spellName, spellSchool = select(1, ...)
								formatType = "A"
								
							elseif eventType == "PARTY_KILL" then
								-- No other parameters other than source/dest
								formatType = "A"
								
							elseif eventType == "UNIT_DIED" or eventType == "UNIT_DISSIPATES" then
								-- No other parameters other than source/dest
								if not srcName and dstName then
									srcName = dstName
									srcFlags = dstFlags
									dstName = nil
									dstFlags = nil
								end
								formatType = "A"
								
							elseif eventType == "UNIT_DESTROYED" then
								-- No other parameters other than source/dest
								if not srcName and dstName then
									srcName = dstName
									srcFlags = dstFlags
									dstName = nil
									dstFlags = nil
								end
								formatType = "A"
								
							elseif eventType == "SPELL_SUMMON" or eventType == "SPELL_CREATE" or eventType == "SPELL_RESURRECT" then
								spellId, spellName, spellSchool = select(1, ...)
								formatType = "A"
								
							elseif eventType == "ENCHANT_APPLIED" or eventType == "ENCHANT_REMOVED" then
								formatType = "A"
								spellName, itemId, itemName = select(1, ...)
								if itemId and itemName then
									local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(itemId)
									extra = itemLink
								end
								
							elseif eventType == "SPELL_DURABILITY_DAMAGE" or eventType == "SPELL_DURABILITY_DAMAGE_ALL" then
								spellId, spellName, spellSchool = select(1, ...)
								formatType = "A"
								
							end
							
							
							-- Use prebuilt hash lookups to see if the spell passes the black/white lists
							spellNameLower = strlower(spellName or "")
							if ((f.spellNameWhiteListEnabled and f.spellNameWhiteList[spellNameLower]) or f.spellNameWhiteListEnabled == false or spellNameLower == "") and
										((f.spellNameBlackListEnabled and f.spellNameBlackList[spellNameLower] == nil) or f.spellNameBlackListEnabled == false or spellNameLower == "")
							then
							
								-- Check message threshold
								if (amount and amount >= f.db.display.valueThreshold) or amount == nil then
							
								
									------[[ Setup and colorize the units ]]-------------------------------------------------------------------------------------
									
									srcNameStr = srcName
									dstNameStr = dstName
									extEvent = eventType
									if auraType then extEvent = extEvent.."_"..auraType
									elseif missType and eventType ~= "SPELL_CAST_FAILED" then extEvent = extEvent.."_"..missType
									end
									
									-- Replace with "you" and apply possessive form if necessary
									if srcName and CombatLog_Object_IsA(srcFlags, COMBATLOG_FILTER_MINE) and f.db.display.nameYou then
											srcNameStr = UNIT_YOU_SOURCE
									end
									if dstName and CombatLog_Object_IsA(dstFlags, COMBATLOG_FILTER_MINE) and f.db.display.nameYou then
											dstNameStr = UNIT_YOU_DEST
									end
									
									if srcName and spellName and _G["ACTION_"..extEvent.."_POSSESSIVE"] == "1" and f.db.display.spellDisplayMode ~= SPELLDISPLAYMODE_NONE then
										if srcName and CombatLog_Object_IsA(srcFlags, COMBATLOG_FILTER_MINE) and f.db.display.nameYou then
											srcNameStr = UNIT_YOU_SOURCE_POSSESSIVE
										else
											srcNameStr = format(TEXT_MODE_A_STRING_POSSESSIVE, srcNameStr)
										end
									end
									
									if dstName and (extraSpellName or itemName) and f.db.display.spellDisplayMode ~= SPELLDISPLAYMODE_NONE then
										if dstName and CombatLog_Object_IsA(dstFlags, COMBATLOG_FILTER_MINE) and f.db.display.nameYou then
											dstNameStr = UNIT_YOU_DEST_POSSESSIVE
										else
											dstNameStr = format(TEXT_MODE_A_STRING_POSSESSIVE, dstNameStr)
										end
									end
									
									-- Abbreviate
									if f.db.display.nameAbbreviate then
										if srcName then srcNameStr = abbreviate(srcNameStr) end
										if dstName then dstNameStr = abbreviate(dstNameStr) end
									end
									
									-- Prime unit cache
									if srcName then primeUnitCache(f, srcName, srcFlags) end
									if dstName then primeUnitCache(f, dstName, dstFlags) end
									
									-- Add levels
									-- if f.db.display.nameShowLevel then
										-- if unitCache[srcName] and unitCache[srcName][3] and unitCache[srcName][3] ~= 0 then srcNameStr = format("%s:%d", srcNameStr, unitCache[srcName][3]) end
										-- if unitCache[dstName] and unitCache[dstName][3] and unitCache[dstName][3] ~= 0 then dstNameStr = format("%s:%d", dstNameStr, unitCache[dstName][3]) end
									-- end
									
									-- Colorize
									if srcName then srcNameStr = colorize(srcNameStr, chooseUnitColor(f, srcName, srcFlags)) end
									if dstName then dstNameStr = colorize(dstNameStr, chooseUnitColor(f, dstName, dstFlags)) end
									
									-- Bracketize
									if srcName then srcNameStr = bracketize(f, srcNameStr) end
									if dstName then dstNameStr = bracketize(f, dstNameStr) end
									
									-- Add raid icon
									if f.db.display.nameShowRaidIcons then
										if srcName then srcNameStr = getRaidIcon(srcRaidFlags)..srcNameStr end
										if dstName then dstNameStr = getRaidIcon(dstRaidFlags)..dstNameStr end
									end


									------[[ Setup and colorize the spell ]]-------------------------------------------------------------------------------------
									
									spellNameStr = formatSpell(f, spellId, spellName, spellSchool)
									if extraSpellName then extraSpellNameStr = formatSpell(f, extraSpellId, extraSpellName, extraSpellSchool) end


									------[[ Setup and colorize the amount ]]------------------------------------------------------------------------------------

									if amount then
										amountStr = format("%d", amount)
										
										-- Flag pet damage, heals, energizes
										if eventCat == "damage" then
											if bit_band(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) == COMBATLOG_OBJECT_AFFILIATION_MINE and (bit_band(srcFlags, COMBATLOG_OBJECT_TYPE_PET) == COMBATLOG_OBJECT_TYPE_PET or bit_band(srcFlags, COMBATLOG_OBJECT_TYPE_GUARDIAN) == COMBATLOG_OBJECT_TYPE_GUARDIAN) and f.db.display.flags["FLAG_PET_DAMAGE"] then
												amountStr = format("~%s~", amountStr)
											end
										elseif eventCat == "heal" then
											if f.db.display.flags["FLAG_HEALS"] then amountStr = format("+%s", amountStr) end
										elseif eventCat == "energize" then
											if f.db.display.flags["FLAG_ENERGIZES"] then amountStr = format("+%s", amountStr) end
										end
										
										-- Colorize
										amountStr = colorize(amountStr, chooseAmountColor(f, srcFlags, spellSchool, spellName, eventCat),
											(critical and f.db.display.highlightCrits) or 
											(f.db.display.highlightPet and bit_band(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) == COMBATLOG_OBJECT_AFFILIATION_MINE and (bit_band(srcFlags, COMBATLOG_OBJECT_TYPE_PET) == COMBATLOG_OBJECT_TYPE_PET or bit_band(srcFlags, COMBATLOG_OBJECT_TYPE_GUARDIAN) == COMBATLOG_OBJECT_TYPE_GUARDIAN)))

										-- Flag crits
										if critical and f.db.display.flags["FLAG_CRITS"] then
											amountStr = format("%s%s%s", colorize("*", self.db.profile.colors.general.critFlag), amountStr, colorize("*", self.db.profile.colors.general.critFlag))
										end
									end


									------[[ Final message setup ]]----------------------------------------------------------------------------------------------
									
									if formatType then
										
										-- Colorize and trim extra values
										if extra and extra ~= "" then extra = colorize(strtrim(extra), self.db.profile.colors.general.extraValues) end
										
										-- Get the appropriate format string
										if f.db.display.displayMode == DISPLAYMODE_CUSTOM then
											messageFormat = f.db.display.customFormat or ""
										else
											messageFormat = L[formats[f.db.display.displayMode].."_"..formatType]
										end

										-- Do tag replacements
										finalString = strreplace(messageFormat, "$source", srcNameStr or "")
										finalString = strreplace(finalString, "$dest", dstNameStr or "")
										finalString = strreplace(finalString, "$spell", spellNameStr or "")
										finalString = strreplace(finalString, "$action", colorize(action or "", self.db.profile.colors.general.text))
										if forEnabled and f.db.display.includeFor then
											finalString = strreplace(finalString, "$for", colorize(L["for"], self.db.profile.colors.general.text))
										else
											finalString = strreplace(finalString, "$for", "")
										end
										if f.db.display.displayMode == DISPLAYMODE_NUMBERS_ONLY and not amount then
											finalString = strreplace(finalString, "$amount", action or "")
										else
											finalString = strreplace(finalString, "$amount", amountStr or "")
										end
										if f.db.display.includeExtraValues then
											finalString = strreplace(finalString, "$extra", extra or "")
										else
											finalString = strreplace(finalString, "$extra", "")
										end
										finalString = strreplace(finalString, "$otherspell", extraSpellNameStr or "")
										if amount then
											finalString = strreplace(finalString, "$amtsep", "-")
										else
											finalString = strreplace(finalString, "$amtsep", "")
										end
									
										-- Clean up the final string
										finalString = gsub(finalString, " [ ]+", " " ) -- Extra white spaces
										finalString = gsub(finalString, " ([.,])", "%1" ) -- Spaces before periods or comma
										finalString = gsub(finalString, "^([ .,]+)", "" ) -- Spaces, period or comma at the beginning of a line
										
										-- Colorize any leftover text
										finalString = finalString
										
										
										------[[ Output the message ]]-----------------------------------------------------------------------------------------------
										if f.chatFrameOverride then
											f.chatFrameOverride:AddMessage(finalString)
										else
											_G[format("ChatFrame%d", f.db.display.chatWindow)]:AddMessage(finalString)
										end
									
									
									end -- formatType was specified; we recognized the event
								end -- value threshold
							end -- spell name list check	
						end -- empty unit names allowed
					end -- unit name list check
				end -- unit flags check
			end -- event enabled check
		end -- filter enabled check
	end -- filter loop
	
end

