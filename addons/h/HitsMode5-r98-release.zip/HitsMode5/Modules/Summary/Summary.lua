local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5", false)
local HitsMode5 = HitsMode5
local mod = HitsMode5:NewModule("Summary", "AceConsole-3.0")




function mod:OnEnable()
--[===[@debug@
	self:Print(L["Loaded"])
--@end-debug@]===]
end
