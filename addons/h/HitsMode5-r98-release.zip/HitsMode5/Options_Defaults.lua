local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5")


-- Locals
local DISPLAYMODE_STANDARD = 1
local DISPLAYMODE_STANDARD_NUMBERS_FIRST = 2
local DISPLAYMODE_NUMBERS_ONLY = 3
local DISPLAYMODE_CUSTOM = 4

local SPELLDISPLAYMODE_TEXT = 1
local SPELLDISPLAYMODE_ABBREVIATED_TEXT = 2
local SPELLDISPLAYMODE_LINK = 3
local SPELLDISPLAYMODE_ABBREVIATED_LINK = 4
local SPELLDISPLAYMODE_NONE = 5

local FLAG_CRITS = 1
local FLAG_HEALS = 2
local FLAG_PET_DAMAGE = 3
local FLAG_ENERGIZES = 4
local FLAG_EXP = 5
local FLAG_HONOR = 6
local FLAG_REP = 7

local UNITCOMPARISONMODE_OR = 1
local UNITCOMPARISONMODE_AND = 2



--[[ CORE DEFAULTS ]]---------------------------------------------------------------------------------------------------------------

HitsMode5.defaults = {
 profile = {
		enabled = true,
		replayLinesPerFrame = 10,
		filters = {},
		colors = {
			general = {
				text =                                 { r = (255/255),  g = (255/255),  b = (255/255) },  -- White
				spells =                               { r = (202/255),  g = ( 76/255),  b = (217/255) },  -- Dark Pink
				brackets =                             { r = (255/255),  g = (255/255),  b = (255/255) },  -- White
				extraValues =                          { r = (172/255),  g = (172/255),  b = (172/255) },  -- Gray
				critFlag =                             { r = (255/255),  g = (255/255),  b = (  0/255) },  -- Yellow
			},
			unitNames = {
				you =                                  { r = (  0/255),  g = (192/255),  b = (255/255) },  -- Light Blue
				pet =                                  { r = ( 96/255),  g = (255/255),  b = ( 99/255) },  -- Light Green
				friends =                              { r = (  0/255),  g = ( 89/255),  b = (255/255) },  -- Medium Blue
				hostileUnits =                         { r = (255/255),  g = ( 59/255),  b = ( 18/255) },  -- Burnt Orange
				hostilePlayers =                       { r = (255/255),  g = ( 59/255),  b = ( 18/255) },  -- Burnt Orange
				neutral =                              { r = (255/255),  g = ( 59/255),  b = ( 18/255) },  -- Burnt Orange
				unknown =                              { r = (175/255),  g = (175/255),  b = (175/255) },  -- Gray
			},
			spellSchools = {
				arcane =                               { r = (  0/255),  g = (255/255),  b = (255/255) },  -- Turquoise
				fire =                                 { r = (255/255),  g = (  0/255),  b = (  0/255) },  -- Red
				frost =                                { r = (  0/255),  g = (  0/255),  b = (255/255) },  -- Blue
				holy =                                 { r = (255/255),  g = (128/255),  b = (128/255) },  -- Pink
				nature =                               { r = (  0/255),  g = (255/255),  b = (  0/255) },  -- Green
				shadow =                               { r = (185/255),  g = (  0/255),  b = (171/255) },  -- Purple
			},
			combatEvents = {
				friendlyDamage =                       { r = (  0/255),  g = (255/255),  b = ( 36/255) },  -- Green
				friendlySpellDamage =                  { r = (  0/255),  g = (255/255),  b = ( 36/255) },  -- Green
				hostileDamage =                        { r = (255/255),  g = ( 47/255),  b = ( 47/255) },  -- Red
				hostileSpellDamage =                   { r = (255/255),  g = ( 47/255),  b = ( 47/255) },  -- Red
				energizes =                            { r = (255/255),  g = (255/255),  b = (  0/255) },  -- Yellow
				friendlyHeals =                        { r = (255/255),  g = (255/255),  b = (  0/255) },  -- Yellow
				hostileHeals =                         { r = (255/255),  g = ( 59/255),  b = ( 18/255) },  -- Burnt Orange
			},
			specialEvents = {
				experience =                           { r = (111/255),  g = (111/255),  b = (255/255) },  -- Experience Purple
				loot =                                 { r = (255/255),  g = (255/255),  b = (  0/255) },  -- Yellow
				honor =                                { r = (255/255),  g = (255/255),  b = (  0/255) },  -- Yellow
				reputation =                           { r = (255/255),  g = (128/255),  b = (128/255) },  -- Pink
				skill =                                { r = (255/255),  g = (255/255),  b = (  0/255) },  -- Yellow
			},
		}
 },
}


--[[ FILTER DEFAULTS ]]-------------------------------------------------------------------------------------------------------------

HitsMode5.filterDefaults = {
	enabled = true,--
	unitComparisonMode = UNITCOMPARISONMODE_OR,
	showMissingSource = true,
	showMissingDest = true,
	display = {
		chatWindow = 7,--
		valueThreshold = 0,--
		displayMode = DISPLAYMODE_STANDARD,--
		includeFor = true,--
		includeRestedExperience = true,--
		includeExtraValues = true,--
		abbreviateExtraValues = false,--
		combatSeparator = "~~~~~",
		customFormat = L["COMBATLOG_FORMAT_STANDARD_A"],
		flags = {
			["FLAG_CRITS"] = true,--
			["FLAG_HEALS"] = true,--
			["FLAG_PET_DAMAGE"] = true,--
			["FLAG_ENERGIZES"] = true,--
			["FLAG_EXP"] = true,--
			["FLAG_HONOR"] = true,--
			["FLAG_REP"] = true,--
		},
		highlightCrits = true,--
		highlightPet = true,--
		nameYou = true,--
		nameBrackets = true,--
		nameAbbreviate = false,--
		nameColorByClass = true,--
		nameShowRaidIcons = false,--
		nameShowLevel = false,-- but commented out
		spellDisplayMode = SPELLDISPLAYMODE_LINK,--
		spellShowIcons = false,--
		spellColorBySchool = true,--
		spellNameWhiteList = "",--
		spellNameBlackList = "",--
	},
	events = {
  ["ENVIRONMENTAL_DAMAGE"] = true,
  ["SWING_DAMAGE"] = true,
  ["SWING_MISSED"] = true,
  ["RANGE_DAMAGE"] = true,
  ["RANGE_MISSED"] = true,
  --["SPELL_CAST_START"] = true,
  --["SPELL_CAST_SUCCESS"] = true,
  --["SPELL_CAST_FAILED"] = true,
  ["SPELL_MISSED"] = true,
  ["SPELL_DAMAGE"] = true,
  ["SPELL_HEAL"] = true,
  ["SPELL_ENERGIZE"] = true,
  ["SPELL_DRAIN"] = true,
  ["SPELL_LEECH"] = true,
  ["SPELL_INSTAKILL"] = true,
  ["SPELL_INTERRUPT"] = true,
  ["SPELL_EXTRA_ATTACKS"] = true,
  --["SPELL_DURABILITY_DAMAGE"] = true,
  --["SPELL_DURABILITY_DAMAGE_ALL"] = true,
  ["SPELL_AURA_APPLIED"] = true,
  ["SPELL_AURA_APPLIED_DOSE"] = true,
  ["SPELL_AURA_REMOVED"] = true,
  ["SPELL_AURA_REMOVED_DOSE"] = true,
  ["SPELL_DISPEL"] = true,
  ["SPELL_STOLEN"] = true,
  ["ENCHANT_APPLIED"] = true,
  ["ENCHANT_REMOVED"] = true,
  ["SPELL_PERIODIC_MISSED"] = true,
  ["SPELL_PERIODIC_DAMAGE"] = true,
  ["SPELL_PERIODIC_HEAL"] = true,
  ["SPELL_PERIODIC_ENERGIZE"] = true,
  ["SPELL_PERIODIC_DRAIN"] = true,
  ["SPELL_PERIODIC_LEECH"] = true,
  ["SPELL_DISPEL_FAILED"] = true,
  ["DAMAGE_SHIELD"] = true,
  ["DAMAGE_SHIELD_MISSED"] = true,
  ["DAMAGE_SPLIT"] = true,
  ["PARTY_KILL"] = true,
  --["UNIT_DIED"] = true,
  ["UNIT_DESTROYED"] = true,
  ["UNIT_DISSIPATES"] = true,
  -- Blizzard Combat Log doesn't handle events below
		["SPELL_BUILDING_HEAL"] = true,
		["SPELL_BUILDING_DAMAGE"] = true,
		["SPELL_SUMMON"] = true,
		["SPELL_CREATE"] = true,
		["SPELL_RESURRECT"] = true,
		--["SPELL_AURA_REFRESH"] = true,
		["SPELL_AURA_BROKEN"] = true,
		["SPELL_AURA_BROKEN_SPELL"] = true,
	},
	specialEvents = {
		["CHAT_MSG_COMBAT_XP_GAIN"] = true,
		["CHAT_MSG_LOOT"] = true,
		["CHAT_MSG_COMBAT_FACTION_CHANGE"] = true,
		["CHAT_MSG_COMBAT_HONOR_GAIN"] = true,
		["CHAT_MSG_MONEY"] = true,
		["CHAT_MSG_SKILL"] = true,
	},
	sourceFlags = {
		[COMBATLOG_OBJECT_AFFILIATION_MINE] = true,
		-- [COMBATLOG_OBJECT_AFFILIATION_PARTY] = true,
		-- [COMBATLOG_OBJECT_AFFILIATION_RAID] = true,
		-- [COMBATLOG_OBJECT_AFFILIATION_OUTSIDER] = true,
		[COMBATLOG_OBJECT_REACTION_FRIENDLY] = true,
		[COMBATLOG_OBJECT_REACTION_NEUTRAL] = true,
		[COMBATLOG_OBJECT_REACTION_HOSTILE] = true,
		[COMBATLOG_OBJECT_CONTROL_PLAYER] = true,
		[COMBATLOG_OBJECT_CONTROL_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PLAYER] = true,
		[COMBATLOG_OBJECT_TYPE_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PET] = true,
		[COMBATLOG_OBJECT_TYPE_GUARDIAN] = true,
		[COMBATLOG_OBJECT_TYPE_OBJECT] = true
	},
	destFlags = {
		[COMBATLOG_OBJECT_AFFILIATION_MINE] = true,
		-- [COMBATLOG_OBJECT_AFFILIATION_PARTY] = true,
		-- [COMBATLOG_OBJECT_AFFILIATION_RAID] = true,
		-- [COMBATLOG_OBJECT_AFFILIATION_OUTSIDER] = true,
		[COMBATLOG_OBJECT_REACTION_FRIENDLY] = true,
		[COMBATLOG_OBJECT_REACTION_NEUTRAL] = true,
		[COMBATLOG_OBJECT_REACTION_HOSTILE] = true,
		[COMBATLOG_OBJECT_CONTROL_PLAYER] = true,
		[COMBATLOG_OBJECT_CONTROL_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PLAYER] = true,
		[COMBATLOG_OBJECT_TYPE_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PET] = true,
		[COMBATLOG_OBJECT_TYPE_GUARDIAN] = true,
		[COMBATLOG_OBJECT_TYPE_OBJECT] = true
	},
	sourceWhiteList = "",
	sourceBlackList = "",
	destWhiteList = "",
	destBlackList = ""
}

-- tinsert(HitsMode5.defaults.profile.filters, HitsMode5.filterDefaults)
-- HitsMode5.defaults.profile.filters[1].name = "Default"
