local L = LibStub("AceLocale-3.0"):NewLocale("HitsMode5", "koKR")
if not L then return end
-- L["Abbreviate extra values"] = ""
-- L["Abbreviate unit names"] = ""
-- L["Adds a flag to special value types in the combat log."] = ""
-- L["Affiliation"] = ""
L["ALL"] = "모두 켜기/끄기"
-- L["Amount to replay"] = ""
-- L["And"] = ""
L["Are you sure you want to delete this filter?"] = "평판 변경"
-- L["Begins the Instant Replay. Combat is replayed into a dedicated window using the settings below."] = ""
-- L["Brackets"] = ""
-- L["Brackets around names"] = ""
L[" (c)"] = "(c)"
-- L["Cancel replay"] = ""
-- L["Cancels a currently running combat replay."] = ""
-- L["|cfffbd284Left-Click|r to start an Instant Replay."] = ""
-- L["|cfffbd284Right-Click|r to open configuration."] = ""
L["|cfffbd284Shift-Click|r to cancel."] = "|cfffbd284Shift-클릭|r하면 취소합니다."
-- L["|cfffbd284Shift-Click|r to replay %d lines of recent combat."] = ""
-- L["Chat %d"] = ""
L["CHAT_MSG_COMBAT_FACTION_CHANGE"] = "평판 변경"
L["CHAT_MSG_COMBAT_HONOR_GAIN"] = "명예 획득"
L["CHAT_MSG_COMBAT_XP_GAIN"] = "경험치 획득"
-- L["CHAT_MSG_COMBAT_XP_GAIN_1"] = ""
-- L["CHAT_MSG_COMBAT_XP_GAIN_2"] = ""
L["CHAT_MSG_LOOT"] = "아이템 획득"
L["CHAT_MSG_MONEY"] = "금전 획득"
-- L["CHAT_MSG_SKILL"] = ""
-- L["Chat window"] = ""
-- L["Chat Window"] = ""
-- L["Chat window reminder"] = ""
L["Choose the filter to be deleted."] = "선택한 분류가 삭제되었습니다."
-- L["Choose which destination unit types to display events for."] = ""
-- L["Choose which source unit types to display events for."] = ""
--[==[ L[ [=[Clears all chat windows being used by filters, and replays all saved combat back to them. This is useful if you've changed your filter settings and want to see recent combat using the new settings.

Combat is saved by the WoW client (not by HitsMode5). You can change the combat retention time above.]=] ] = "" ]==]
-- L["Click to open the HitsMode5 knowledge base, which is filled with frequently asked questions."] = ""
L["Color by class"] = "직업에 따른 색상"
L["Color by spell school"] = "주문 속성에 따른 색상"
L["Colors"] = "색상"
L["Combat Events"] = "전투 이벤트"
-- L["COMBATLOG_FORMAT_NUMBERS_ONLY_A"] = ""
-- L["COMBATLOG_FORMAT_STANDARD_A"] = ""
-- L["COMBATLOG_FORMAT_STANDARD_NUMBERS_FIRST_A"] = ""
-- L["Combat log messages with a value below this setting will not be displayed. This can be useful to prevent spam from very small events."] = ""
-- L["COMBATLOG_OBJECT_AFFILIATION_MINE"] = ""
-- L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = ""
L["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = "파티"
L["COMBATLOG_OBJECT_AFFILIATION_RAID"] = "공격대"
L["COMBATLOG_OBJECT_CONTROL_NPC"] = "NPC"
L["COMBATLOG_OBJECT_CONTROL_PLAYER"] = "플레이어"
L["COMBATLOG_OBJECT_FOCUS"] = "주시대상"
-- L["COMBATLOG_OBJECT_MAINASSIST"] = ""
L["COMBATLOG_OBJECT_MAINTANK"] = "메인 탱커"
L["COMBATLOG_OBJECT_NONE"] = "없음"
L["COMBATLOG_OBJECT_RAIDTARGET1"] = "공격대 대상 1"
L["COMBATLOG_OBJECT_RAIDTARGET2"] = "공격대 대상 2"
L["COMBATLOG_OBJECT_RAIDTARGET3"] = "공격대 대상 3"
L["COMBATLOG_OBJECT_RAIDTARGET4"] = "공격대 대상 4"
L["COMBATLOG_OBJECT_RAIDTARGET5"] = "공격대 대상 5"
L["COMBATLOG_OBJECT_RAIDTARGET6"] = "공격대 대상 6"
L["COMBATLOG_OBJECT_RAIDTARGET7"] = "공격대 대상 7"
L["COMBATLOG_OBJECT_RAIDTARGET8"] = "공격대 대상 8"
L["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = "우호적"
L["COMBATLOG_OBJECT_REACTION_HOSTILE"] = "적대적"
L["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = "중립적"
L["COMBATLOG_OBJECT_TARGET"] = "대상"
L["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = "경비병"
L["COMBATLOG_OBJECT_TYPE_NPC"] = "NPC"
-- L["COMBATLOG_OBJECT_TYPE_OBJECT"] = ""
L["COMBATLOG_OBJECT_TYPE_PET"] = "소환수"
L["COMBATLOG_OBJECT_TYPE_PLAYER"] = "플레이어"
-- L["Combat log retention time"] = ""
L["Combat separator"] = "전투 구분 기호" -- Needs review
-- L["Configure all the colors used throughout the HitsMode5 combat log. Colors are global for all filters."] = ""
L["Copy filter"] = "분류 복사"
-- L["Create a copy of this filter by entering a new name and clicking Okay."] = ""
L["Create filter"] = "분류 생성"
-- L["create %s"] = ""
L["crit"] = "치명타"
L["crit damaged"] = "치명타 공격력"
L["Crit flag (*)"] = "치명타 기호 (*)"
L["crit healed"] = "극대화 치유"
L["Critical damage values are highlighted (makes them brighter)."] = "치명타 공격력의 값을 강조합니다.(좀 더 밝게 표시)"
L[" (crushing)"] = "(강타)"
-- L["Currently |cff20ff20enabled|r."] = ""
-- L["Currently |cffff2020disabled|r."] = ""
-- L["Custom"] = ""
-- L["Custom display format"] = ""
L[" (%d a)"] = "(%d a)"
L[" (%d absorbed)"] = "(%d 흡수됨)"
-- L["DAMAGE_SHIELD"] = ""
-- L["DAMAGE_SHIELD_MISSED"] = ""
-- L["DAMAGE_SPLIT"] = ""
L[" (%d b)"] = "(%d b)"
L[" (%d blocked)"] = "(%d 방어함)"
-- L["Default"] = ""
--[==[ L[ [=[Defines whether resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values should be shown after regular damage. Also shows the energy type for energizes, and the miss type for misses.

Not available for the |cffffff20%s|r display mode.]=] ] = "" ]==]
L["Delete filter"] = "분류 삭제"
L["Deletes the chosen filter."] = "선택한 분류를 삭제합니다."
-- L["Deletes this filter."] = ""
-- L["Destination Units"] = ""
--[==[ L[ [=[Determines how long your WoW client will retain combat log data (in seconds). This affects HitsMode5's ability to replay the combat log. Longer retention times will cause your client to use more of your RAM, but will allow you to evaluate a longer period of combat after it has happened. The default setting is 5 minutes (300 seconds). Note that this is a WoW setting, not a HitsMode5 setting. This WoW setting is normally hidden from users.

WoW currently imposes a limit of 315 seconds for this value.]=] ] = "" ]==]
-- L["Determines how spells and skills will be displayed in the combat log. Abbreviated spells will show just the first letter of every word in the spell."] = ""
--[==[ L[ [=[Determines how your unit filters will be used.

|cffffff20Or:|r
  Events where the source filters OR the destination filters match your selections will be shown.

|cffffff20And:|r
  Events where the source filters AND the destination filters match your selections will be shown.]=] ] = "" ]==]
-- L["Determines the percentage of recent combat to replay. Replaying thousands of lines can take a long time. Since WoW doesn't reliably save combat based on time, we simply let you choose what percentage of saved combat to replay."] = ""
-- L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."] = ""
-- L["Disabled"] = ""
L["Display"] = "표시"
L["Display mode"] = "표시 모드"
L[" (%d o)"] = "(%d o)"
L[" (%d overheal)"] = "(%d 과도치유)"
-- L[" (%d overkill)"] = ""
L[" (%d r)"] = "(%d r)"
L[" (%d resisted)"] = "(%d 저항됨)"
-- L[" (%d v)"] = ""
-- L[" (%d vulnerability damage)"] = ""
L["Enable filter"] = "분류 사용"
L["Enable HitsMode5"] = "HitsMode5 사용"
-- L["Enables or disables HitsMode5 entirely. When disabled, HitsMode5 will not respond to any combat log events. You will still be able to enable HitsMode5 and replay the combat log to see what happened."] = ""
L["Enables the filter."] = "선택한 분류를 사용합니다."
L["ENCHANT_APPLIED"] = "마법부여 획득"
L["ENCHANT_REMOVED"] = "마법부여 삭제"
-- L["Energizes and extra attacks"] = ""
-- L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."] = ""
-- L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."] = ""
-- L["Enter a comma-separated list of spell names. Only events whose spells are not on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = ""
-- L["Enter a comma-separated list of spell names. Only events whose spells are on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = ""
--[==[ L[ [=[Enter text to be placed in the chat window when you leave combat. This helps break up the combat log from fight to fight.

Does not affect replayed combat logs.

To disable this feature, empty this text box and click Okay.]=] ] = "" ]==]
L["Enter the name for the filter."] = "분류의 이름을 입력하세요"
L["Enter the name for the new filter."] = "새로운 분류의 이름을 입력하세요"
L["ENVIRONMENTAL_DAMAGE"] = "환경 데미지"
-- L["Execute"] = ""
L["Experience gained"] = "경험치 획득"
-- L["Extra values"] = ""
-- L["Extra values in the combat log (resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill damage, as well as energy types and miss types)."] = ""
-- L["faded"] = ""
L["Filters"] = "분류"
--[==[ L[ [=[Filters are the basic building block of the HitsMode5 combat log. Each filter lets you choose which events to show, which chat window to show them in, and how you'd like them to look.

You can create an unlimited number of filters, all running at once.

You can also create filters and turn them off, saving them for a special occasion when you need to look something up.]=] ] = "" ]==]
L["FLAG_CRITS"] = "치명타 (*)"
-- L["FLAG_ENERGIZES"] = ""
L["FLAG_EXP"] = "경험치 (+)"
L["FLAG_HEALS"] = "치유 (+)"
L["FLAG_HONOR"] = "명예 (+)"
L["FLAG_PET_DAMAGE"] = "소환수 공격력(~)"
L["FLAG_REP"] = "평판 (+/-)"
-- L["Flag special values"] = ""
-- L["for"] = ""
-- L["Friendly damage"] = ""
-- L["Friendly heals"] = ""
-- L["Friendly spell damage"] = ""
-- L["Friends"] = ""
-- L[" (g)"] = ""
-- L["gain experience %s"] = ""
-- L["gain reputation %s %s"] = ""
L["General"] = "일반"
L["General Options"] = "일반 설정"
-- L["Get help with HitsMode5."] = ""
-- L[" (glancing)"] = ""
L["Help"] = "도움말"
L["Help with HitsMode5"] = "HitsMode5에 대한 도움말"
L["Highlight crits"] = "치명타 강조"
L["Highlight pet damage"] = "소환수 공격력 강조"
-- L["HitsMode5: Instant Replay"] = ""
-- L["HitsMode5 is currently replaying combat."] = ""
-- L["HitsMode5 is replaying combat..."] = ""
L["Honor gained"] = "명예 획득"
-- L["Hostile damage"] = ""
-- L["Hostile heals"] = ""
-- L["Hostile players"] = ""
-- L["Hostile spell damage"] = ""
-- L["Hostile units"] = ""
-- L["If you can't find one or more chat windows, they may have become docked next to another chat window."] = ""
-- L["If you can't find the chat window, it may have become docked next to another chat window."] = ""
-- L["Include extra values"] = ""
-- L["Include level"] = ""
L["Include raid icons"] = "공격대 아이콘 포함"
L["Include rested experience"] = "휴식 경험치 포함"
L["Include spell icons"] = "주문 아이콘 포함"
-- L["Includes the word \"for\" in most combat log output. This only applies to the |cffffff20%s|r display mode."] = ""
-- L["Include the word \"for\""] = ""
-- L["Instant Replay"] = ""
-- L["Link"] = ""
-- L["Link (abbreviated)"] = ""
L["Loaded"] = "불러옴"
-- L["Loot"] = ""
-- L["loot %s"] = ""
-- L["lose reputation %s %s"] = ""
-- L["lost a stack"] = ""
-- L["Mouse wheel scrolls. Ctrl scrolls faster. Shift scrolls to top or bottom."] = ""
-- L["Name Is"] = ""
-- L["Name Is Not"] = ""
L["Neutral"] = "중립"
L["None"] = "없음"
-- L["Normal text"] = ""
L["Numbers only"] = "숫자만"
-- L["Open chat window"] = ""
-- L["Open chat windows"] = ""
-- L["Opens all chat windows being used by HitsMode5 filters, if any are currently closed."] = ""
-- L["Opens the selected chat window if it is closed."] = ""
-- L["Options governing how the combat log text is rendered to your chat frame."] = ""
-- L["Or"] = ""
-- L["Ownership"] = ""
L["PARTY_KILL"] = "파티 죽임" -- Needs review
-- L["Prints some text into all open chat windows, to remind you which is which."] = ""
-- L["Profile modified, rebooting"] = ""
L["RANGE_DAMAGE"] = "원거리 공격력"
-- L["RANGE_MISSED"] = ""
-- L["Reaction"] = ""
L["Rename filter"] = "분류 이름 변경"
-- L["Replay combat"] = ""
-- L["Replay is already running. Please wait for it to finish."] = ""
-- L["Replay lines per frame"] = ""
-- L["Replay running..."] = ""
L["Reputation gained"] = "평판 획득"
L["Reset options"] = "초기화 설정"
-- L["Resets the Instant Replay options to their defaults. Your Instant Replay settings are saved until you log out or reload your UI. This button allows you to reset them quickly."] = ""
-- L["Resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values will be abbreviated to just their first letter. Does not affect energy types or miss types."] = ""
-- L[" rested"] = ""
-- L["Select which chat window to use for this filter's combat log output. You cannot use chat window 2, which is the default Blizzard Combat Log."] = ""
--[==[ L[ [=[Sets the display mode for this filter.

|cffffff20%s|r:
  [You] hit [Monster] for 12

|cffffff20%s|r:
  12 - [You] hit [Monster]

|cffffff20%s|r:
  12

|cffffff20%s|r:
  A custom format specified below.]=] ] = "" ]==]
-- L["share of the loot is %s"] = ""
-- L["Show events with no dest unit"] = ""
-- L["Show events with no source unit"] = ""
-- L["Show \"you\" instead of your name"] = ""
-- L["Skill changed"] = ""
-- L[" skill has increased to %s"] = ""
-- L["Source Units"] = ""
-- L["Special Cases"] = ""
-- L["Special Events"] = ""
--[==[ L[ [=[Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.

They will not show for replayed combat logs.]=] ] = "" ]==]
L["SPELL_AURA_APPLIED"] = "오라 적용" -- Needs review
-- L["SPELL_AURA_APPLIED_DOSE"] = ""
L["SPELL_AURA_BROKEN"] = "근접 공격에 의한 군중제어 해제"
L["SPELL_AURA_BROKEN_SPELL"] = "주문 공격에 의한 군중제어 해제" -- Needs review
-- L["SPELL_AURA_REFRESH"] = ""
L["SPELL_AURA_REMOVED"] = "오라 제거"
-- L["SPELL_AURA_REMOVED_DOSE"] = ""
-- L["SPELL_BUILDING_DAMAGE"] = ""
-- L["SPELL_BUILDING_HEAL"] = ""
L["SPELL_CAST_FAILED"] = "주문 시전 실패" -- Needs review
L["SPELL_CAST_START"] = "주문 시전 시작" -- Needs review
L["SPELL_CAST_SUCCESS"] = "주문 시전 성공" -- Needs review
L["SPELL_CREATE"] = "창조"
L["SPELL_DAMAGE"] = "주문 공격력"
L["SPELL_DISPEL"] = "주문 해제" -- Needs review
L["SPELL_DISPEL_FAILED"] = "해제 실패"
L["SPELL_DRAIN"] = "소모"
-- L["SPELL_ENERGIZE"] = ""
L["SPELL_EXTRA_ATTACKS"] = "추가 공격"
L["SPELL_HEAL"] = "치유"
L["SPELL_INSTAKILL"] = "즉시 죽임" -- Needs review
L["SPELL_INTERRUPT"] = "주문 중단"
-- L["SPELL_LEECH"] = ""
-- L["SPELL_MISSED"] = ""
-- L["Spell Name Blacklist"] = ""
L["Spell names"] = "주문 이름"
-- L["Spell Name Whitelist"] = ""
L["SPELL_PERIODIC_DAMAGE"] = "주기적인 주문 공격력" -- Needs review
-- L["SPELL_PERIODIC_DRAIN"] = ""
-- L["SPELL_PERIODIC_ENERGIZE"] = ""
L["SPELL_PERIODIC_HEAL"] = "주기적인 힐" -- Needs review
-- L["SPELL_PERIODIC_LEECH"] = ""
-- L["SPELL_PERIODIC_MISSED"] = ""
L["SPELL_RESURRECT"] = "부활"
L["Spells"] = "주문"
L["Spell Schools"] = "주문 속성"
--[==[ L[ [=[Spell/skill names.

Only used when not displaying spell links.]=] ] = "" ]==]
L["SPELL_STOLEN"] = "주문 훔치기"
L["SPELL_SUMMON"] = "소환"
-- L["Standard"] = ""
-- L["Standard (numbers first)"] = ""
L["SWING_DAMAGE"] = "근접 공격력"
-- L["SWING_MISSED"] = ""
-- L["Text"] = ""
-- L["Text (abbreviated)"] = ""
-- L["Text Layout"] = ""
-- L["These are optional. Select \"None\" to exclude all special cases."] = ""
-- L["The sentence structure portion of each combat log entry."] = ""
-- L["The square brackets surrounding unit names."] = ""
-- L["This is chat window %d"] = ""
-- L["Unable to load Blizzard Combat Log. HitsMode5 cannot be enabled. (Reason: %s)"] = ""
-- L["Unable to load Replay module; requires Options module"] = ""
-- L["Unit comparison mode"] = ""
L["UNIT_DESTROYED"] = "유닛 파괴"
L["UNIT_DIED"] = "유닛 죽음"
-- L["UNIT_DISSIPATES"] = ""
L["Unit Names"] = "유닛 이름"
-- L["Unit Type"] = ""
-- L["Unknown"] = ""
--[==[ L[ [=[Uses a tag system to let you create your own combat log formats. Any tags not used in a given event will be removed. Tags are case sensitive. Extra whitespace will be removed from the string before it is displayed.

|cffffff20$source|r - The source unit name.
|cffffff20$dest|r - The destination unit name.
|cffffff20$spell|r - The spell, skill, or enchant used.
|cffffff20$action|r - The action text for the event (hit, missed, etc.)
|cffffff20$for|r - The word "for" in some events; automatically removed if Include For is turned off.
|cffffff20$amount|r - The numeric amount associated with the event, if any.
|cffffff20$otherspell|r - The source's spell interacts with the destination's spell in certain events. $otherspell is the destination's spell.
|cffffff20$extra|r - All extra information about the event, such as resists, overkill, miss type, failure reason, etc. Not shown if Include Extra Values is off.
|cffffff20$amtsep|r - Replaced with a dash (-) if the $amount tag is also being filled with a number.]=] ] = "" ]==]
-- L["Value threshold"] = ""
-- L["When HitsMode5 replays your combat log, it replays a certain number of lines per frame. This prevents your client from locking up for an extended period of time while the combat log is replayed. You may wish to adjust this setting to a higher number if you have a very fast computer, need to replay a long combat log (particularly in a raid), and don't mind a little lag while it happens. The default Blizzard Combat Log replays one line per frame."] = ""
-- L["When selected, all unit names will be abbreviated to just the first letter of every word."] = ""
-- L["When selected, a unit's level will be displayed next to their name. This will also work for replayed combat logs."] = ""
-- L["When selected, events with no destination unit will be shown in this filter."] = ""
-- L["When selected, events with no source unit will be shown in this filter."] = ""
-- L["When selected, raid icons will be shown next to unit names (if applicable). This will also work for replayed combat logs."] = ""
-- L["When selected, spell damage values will be colorized based on the spell school. For hybrid spell schools, a priority system is used to choose the color."] = ""
--[==[ L[ [=[When selected, spell icons will be shown in the combat log. You can choose to show icons only (no text), by turning this on and selecting "None" for display mode above.

Disable this feature if you encounter graphical corruption in your chat window.]=] ] = "" ]==]
--[==[ L[ [=[When selected, square brackets will be placed around all unit names, for example:

  [You] hit [Monster] for 16]=] ] = "" ]==]
--[==[ L[ [=[When selected, unit names will be colorized by their class (when their class is available). Replayed combat logs may not include this feature if you recently reloaded your UI. WoW does not return class information for all units in the game.

Disable this feature to use the default color for various unit types.]=] ] = "" ]==]
-- L["When selected, uses You and Your to indicate the player, rather than your name."] = ""
-- L["When showing experience gain, separately show the amount of experience that was rested."] = ""
L["You"] = "당신"
-- L["You entered a name that already exists. To copy a filter, enter a unique filter name."] = ""
-- L["You have no filters. Creating a default filter."] = ""
-- L["You must choose at least one item from this category."] = ""
L["Your pet"] = "당신의 소환수"
L["Your pet damage values are highlighted (makes them brighter)."] = "당신의 소환수의 공격력 값을 강조합니다(좀 더 밝게 표시)."
L["Your target"] = "당신의 대상"
