local L = LibStub("AceLocale-3.0"):NewLocale("HitsMode5", "ruRU")
if not L then return end
L["Abbreviate extra values"] = "Сокращать дополнительные значения"
L["Abbreviate unit names"] = "Сокращать имена объектов"
L["Adds a flag to special value types in the combat log."] = "Добавляет флаг к особым типам значений в журнале боя"
L["Affiliation"] = "Принадлежность"
L["ALL"] = "|cff20ff20Все Вкл/Выкл|r"
L["Amount to replay"] = "Объем воспроизведения"
L["And"] = "И"
L["Are you sure you want to delete this filter?"] = "Вы действительно хотите удалить этот фильтр?"
L["Begins the Instant Replay. Combat is replayed into a dedicated window using the settings below."] = "Начинает проигрывание записанного боя. Бой показывается в отдельном окне, согласно настройкам."
L["Brackets"] = "Скобки"
L["Brackets around names"] = "Скобки вокруг имен"
L[" (c)"] = "(с)"
L["Cancel replay"] = "Отмена воспроизведения"
L["Cancels a currently running combat replay."] = "Отменяет текущее воспроизведение боя"
L["|cfffbd284Left-Click|r to start an Instant Replay."] = "|cfffbd284ЛКМ|r для запуска Воспроизведения."
L["|cfffbd284Right-Click|r to open configuration."] = "|cfffbd284ПКМ|r для открытия настроек."
L["|cfffbd284Shift-Click|r to cancel."] = "|cfffbd284Shift-ЛКМ|r для отмены."
L["|cfffbd284Shift-Click|r to replay %d lines of recent combat."] = "|cfffbd284Shift+ЛКМ|r для воспроизведения %d строк недавнего боя."
L["Chat %d"] = "Чат %d"
L["CHAT_MSG_COMBAT_FACTION_CHANGE"] = "Изменение репутации"
L["CHAT_MSG_COMBAT_HONOR_GAIN"] = "Получение чести"
L["CHAT_MSG_COMBAT_XP_GAIN"] = "Получение опыта"
L["CHAT_MSG_COMBAT_XP_GAIN_1"] = ".* получаете (%d+) .*"
L["CHAT_MSG_COMBAT_XP_GAIN_2"] = "опыта%. %(%+(%d+) exp бонус за отдых"
L["CHAT_MSG_LOOT"] = "Получение добычи"
L["CHAT_MSG_MONEY"] = "Получение денег"
L["CHAT_MSG_SKILL"] = "Изменение навыка"
L["Chat window"] = "Окно чата"
L["Chat Window"] = "Окно чата"
L["Chat window reminder"] = "Подсказка окна чата"
L["Choose the filter to be deleted."] = "Выберите фильтр для удаления"
L["Choose which destination unit types to display events for."] = "Выберите, для каких типов получателей будут показаны события"
L["Choose which source unit types to display events for."] = "Выберите, для каких типов отправителей будут показаны события"
L[ [=[Clears all chat windows being used by filters, and replays all saved combat back to them. This is useful if you've changed your filter settings and want to see recent combat using the new settings.

Combat is saved by the WoW client (not by HitsMode5). You can change the combat retention time above.]=] ] = [=[Очищает все окна чата, используемые фильтрами и воспроизводит в них весь сохраненный бой. Это полезно, если вы изменили настройки фильтров и хотите воспроизвести бой с новыми настройками.

Журнал боя хранится в WoW (не в HitsMode5). Время хранения журнала боя можно задать выше.]=]
L["Click to open the HitsMode5 knowledge base, which is filled with frequently asked questions."] = "Нажмите для открытия базы знаний HitsMode5, полной часто задаваемых вопросов."
L["Color by class"] = "Цвета классов"
L["Color by spell school"] = "Цвета школ заклинаний"
L["Colors"] = "Цвета"
L["Combat Events"] = "События боя"
L["COMBATLOG_FORMAT_NUMBERS_ONLY_A"] = "$amount"
L["COMBATLOG_FORMAT_STANDARD_A"] = "$source $spell $action $dest $for $amount $otherspell $extra"
L["COMBATLOG_FORMAT_STANDARD_NUMBERS_FIRST_A"] = "$amount $amtsep $source $spell $action $dest $otherspell $extra"
L["Combat log messages with a value below this setting will not be displayed. This can be useful to prevent spam from very small events."] = "Сообщения из журнала боя со значениями ниже указанного не будут показаны. Это может предотвратить спам от очень мелких событий"
L["COMBATLOG_OBJECT_AFFILIATION_MINE"] = "Мое"
L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = "Посторонний"
L["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = "Группа"
L["COMBATLOG_OBJECT_AFFILIATION_RAID"] = "Рейд"
L["COMBATLOG_OBJECT_CONTROL_NPC"] = "NPC"
L["COMBATLOG_OBJECT_CONTROL_PLAYER"] = "Игрок"
L["COMBATLOG_OBJECT_FOCUS"] = "Фокус"
L["COMBATLOG_OBJECT_MAINASSIST"] = "Главный помощник"
L["COMBATLOG_OBJECT_MAINTANK"] = "Главный Танк"
L["COMBATLOG_OBJECT_NONE"] = "Нет"
L["COMBATLOG_OBJECT_RAIDTARGET1"] = "Цель рейда 1"
L["COMBATLOG_OBJECT_RAIDTARGET2"] = "Цель рейда 2"
L["COMBATLOG_OBJECT_RAIDTARGET3"] = "Цель рейда 3"
L["COMBATLOG_OBJECT_RAIDTARGET4"] = "Цель рейда 4"
L["COMBATLOG_OBJECT_RAIDTARGET5"] = "Цель рейда 5"
L["COMBATLOG_OBJECT_RAIDTARGET6"] = "Цель рейда 6"
L["COMBATLOG_OBJECT_RAIDTARGET7"] = "Цель рейда 7"
L["COMBATLOG_OBJECT_RAIDTARGET8"] = "Цель рейда 8"
L["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = "Дружественная"
L["COMBATLOG_OBJECT_REACTION_HOSTILE"] = "Враждебная"
L["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = "Нейтральная"
L["COMBATLOG_OBJECT_TARGET"] = "Цель"
L["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = "Страж"
L["COMBATLOG_OBJECT_TYPE_NPC"] = "NPC"
L["COMBATLOG_OBJECT_TYPE_OBJECT"] = "Предмет"
L["COMBATLOG_OBJECT_TYPE_PET"] = "Питомец"
L["COMBATLOG_OBJECT_TYPE_PLAYER"] = "Игрок"
L["Combat log retention time"] = "Время хранения журнала боя"
L["Combat separator"] = "Разделитель боёв"
L["Configure all the colors used throughout the HitsMode5 combat log. Colors are global for all filters."] = "Настроить все цвета, используемые в журналах боя HitsMode5. Цвета глобальны для всех фильтров."
L["Copy filter"] = "Скопировать фильтр"
L["Create a copy of this filter by entering a new name and clicking Okay."] = "Создайте копию этого фильтра, указав новое название и нажав \"ОК\""
L["Create filter"] = "Создать фильтр"
L["create %s"] = "создание %s"
L["crit"] = "крит"
L["crit damaged"] = "критический урон"
L["Crit flag (*)"] = "Помечать криты (*)"
L["crit healed"] = "критическое исцеление"
L["Critical damage values are highlighted (makes them brighter)."] = "Критические значения урона подсвечиваются (становятся ярче)"
L[" (crushing)"] = "(сокрушающий)"
L["Currently |cff20ff20enabled|r."] = "Сейчас |cff20ff20включено|r."
L["Currently |cffff2020disabled|r."] = "Сейчас |cffff2020выключено|r."
L["Custom"] = "Особый"
L["Custom display format"] = "Особый формат вывода"
L[" (%d a)"] = "(%d пг)"
L[" (%d absorbed)"] = "(%d поглощено)"
L["DAMAGE_SHIELD"] = "Повреждающий щит"
L["DAMAGE_SHIELD_MISSED"] = "Промах повр. щита"
L["DAMAGE_SPLIT"] = "Урон разделён"
L[" (%d b)"] = "(%d б)"
L[" (%d blocked)"] = "(%d блокировано)"
L["Default"] = "По умолчанию"
L[ [=[Defines whether resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values should be shown after regular damage. Also shows the energy type for energizes, and the miss type for misses.

Not available for the |cffffff20%s|r display mode.]=] ] = [=[Определяет, следует ли показывать сопротивления, блокирование, скользящие удары, уязвимость, переисцеление и избыточный урон после обычного урона. Также показывает тип энергии для восполнений и тип промаха для промахов.

Недоступно в режиме отображения |cffffff20%s|r.]=]
L["Delete filter"] = "Удалить фильтр"
L["Deletes the chosen filter."] = "Удалить выбранный фильтр."
L["Deletes this filter."] = "Удаляет этот фильтр"
L["Destination Units"] = "Получатели"
L[ [=[Determines how long your WoW client will retain combat log data (in seconds). This affects HitsMode5's ability to replay the combat log. Longer retention times will cause your client to use more of your RAM, but will allow you to evaluate a longer period of combat after it has happened. The default setting is 5 minutes (300 seconds). Note that this is a WoW setting, not a HitsMode5 setting. This WoW setting is normally hidden from users.

WoW currently imposes a limit of 315 seconds for this value.]=] ] = [=[Определяет, как долго клиент WoW будет хранить журнал боя (в секундах). Этот параметр влияет на способность HitsMode5 воспроизводить журнал боя. Большее время хранения заставит клиент использовать больше памяти, но позволит оценивать более длительный отрезок боя после его завершения. Значение по умолчанию - 5 минут (300 секунд). Заметим, что это параметр WoW, а не HitsMode5. Этот параметр обычно скрыт от пользователя.

В настоящее время на данный параметр наложен предел в 315 секунд.]=]
L["Determines how spells and skills will be displayed in the combat log. Abbreviated spells will show just the first letter of every word in the spell."] = "Определяет способ отображения заклинаний и навыков в журнале боя. Сокращенные заклинания будут показаны как первые буквы каждого слова в их названии."
L[ [=[Determines how your unit filters will be used.

|cffffff20Or:|r
  Events where the source filters OR the destination filters match your selections will be shown.

|cffffff20And:|r
  Events where the source filters AND the destination filters match your selections will be shown.]=] ] = [=[Определяет, как будут использованы фильтры объектов.

|cffffff20Or:|r
  Будут показаны события, для которых фильтр отправителя ИЛИ фильтр источника соответствуют вашему выбору.

|cffffff20And:|r
  Будут показаны события, для которых фильтр отправителя И фильтр источника соответствуют вашему выбору.]=]
L["Determines the percentage of recent combat to replay. Replaying thousands of lines can take a long time. Since WoW doesn't reliably save combat based on time, we simply let you choose what percentage of saved combat to replay."] = "Определяет процент недавнего боя для воспроизведения. Воспроизведение тысяч строк может занять продолжительное время. Так как WoW недостаточно надёжно сохраняет бой в зависимости от времени, мы позволяем вам указать процент записанного боя для воспроизведения."
L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."] = "Определяет, какие события из журнала боя будут показаны. Список ограничен событиями из журнала боя Blizzard"
L["Disabled"] = "Отключено"
L["Display"] = "Отображение"
L["Display mode"] = "Метод отображения"
L[" (%d o)"] = "(%d и)"
L[" (%d overheal)"] = "(%d переисцеление)"
L[" (%d overkill)"] = "(%d избыточный урон)"
L[" (%d r)"] = "(%d с)"
L[" (%d resisted)"] = "(%d сопротивление)"
L[" (%d v)"] = "(%d у)"
L[" (%d vulnerability damage)"] = "(%d уязвимость)"
L["Enable filter"] = "Включить фильтр"
L["Enable HitsMode5"] = "Вкл. HitsMode5"
L["Enables or disables HitsMode5 entirely. When disabled, HitsMode5 will not respond to any combat log events. You will still be able to enable HitsMode5 and replay the combat log to see what happened."] = "Включает или выключает HitsMode5 полностью. В выключенном состоянии HitsMode5 не будет реагировать на события в журнале боя. Вы сможете включить HitsMode5 и воспроизвести журнал боя, чтобы увидеть, что произошло."
L["Enables the filter."] = "Включает фильтр"
L["ENCHANT_APPLIED"] = "Усиление наложено"
L["ENCHANT_REMOVED"] = "Усиление снято"
L["Energizes and extra attacks"] = "Восполнения и доп. атаки"
L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."] = "Введите разделенный запятой список названий. Будут показаны только события с названиями не из списка. Названия не чувствительны к регистру."
L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."] = "Введите разделенный запятой список названий. Будут показаны только события с названиями из списка. Названия не чувствительны к регистру."
L["Enter a comma-separated list of spell names. Only events whose spells are not on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = "Введите разделенный запятой список имён заклинаний. Будут показаны только события от заклинаний не из списка. Названия не чувствительны к регистру."
L["Enter a comma-separated list of spell names. Only events whose spells are on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = "Введите разделенный запятой список имён заклинаний. Будут показаны только события от заклинаний из списка. Названия не чувствительны к регистру."
L[ [=[Enter text to be placed in the chat window when you leave combat. This helps break up the combat log from fight to fight.

Does not affect replayed combat logs.

To disable this feature, empty this text box and click Okay.]=] ] = [=[Введите текст, который будет показан в окне чата при выходе из боя. Это позволяет разделить журнал боя на отдельные схватки.

Не влияет на воспроизхводимые журналы боя.

Для отключения этой функции очистите поле ввода и нажмите "ОК"]=]
L["Enter the name for the filter."] = "Введите имя фильтра."
L["Enter the name for the new filter."] = "Введите имя нового фильтра"
L["ENVIRONMENTAL_DAMAGE"] = "Урон от окружения"
L["Execute"] = "Выполнить"
L["Experience gained"] = "Получен опыт"
L["Extra values"] = "Доп. значения"
L["Extra values in the combat log (resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill damage, as well as energy types and miss types)."] = "Дополнительные значения в журнале боя (сопротивления, поглощения, блокирования, сокрушения, уязвимости, переисцеления и избыточный урон, а также типы энергии и типы промахов)"
L["faded"] = "кончается"
L["Filters"] = "Фильтры"
L[ [=[Filters are the basic building block of the HitsMode5 combat log. Each filter lets you choose which events to show, which chat window to show them in, and how you'd like them to look.

You can create an unlimited number of filters, all running at once.

You can also create filters and turn them off, saving them for a special occasion when you need to look something up.]=] ] = [=[Фильтры - основной строительный материал журнала боя HitsMode5. Каждый фильтр позволяет выбрать, какие события показывать, в каком окне чата и как они должны при этом выглядеть.

Вы можете задать сколько угодно фильтров, работающих одновременно.

Вы также можете создать фильтры и отключить их, сохранив до того момента, когда вам понадобится что-либо проверить.]=]
L["FLAG_CRITS"] = "Криты (*)"
L["FLAG_ENERGIZES"] = "Восполнения (+)"
L["FLAG_EXP"] = "Опыт (+)"
L["FLAG_HEALS"] = "Лечение (+)"
L["FLAG_HONOR"] = "Честь (+)"
L["FLAG_PET_DAMAGE"] = "Урон питомца (~)"
L["FLAG_REP"] = "Репутация (+/-)"
L["Flag special values"] = "Помечать особые значения"
L["for"] = "на"
L["Friendly damage"] = "Дружественный урон."
L["Friendly heals"] = "Дружественное лечение"
L["Friendly spell damage"] = "Дружественный урон заклинаниями"
L["Friends"] = "Друзья"
L[" (g)"] = "(ск)"
L["gain experience %s"] = "получение опыта %s"
L["gain reputation %s %s"] = "получение репутации %s %s"
L["General"] = "Общее"
L["General Options"] = "Общие настройки"
L["Get help with HitsMode5."] = "Получить помощь по HitsMode5"
L[" (glancing)"] = "(скользящий)"
L["Help"] = "Помощь"
L["Help with HitsMode5"] = "Помощь по HitsMode5"
L["Highlight crits"] = "Подсвечивать криты"
L["Highlight pet damage"] = "Подсвечивать урон питомца"
L["HitsMode5: Instant Replay"] = "HitsMode5: Воспроизведение"
L["HitsMode5 is currently replaying combat."] = "HitsMode5 в данный момент воспроизводит бой"
L["HitsMode5 is replaying combat..."] = "HitsMode5 воспроизводит бой..."
L["Honor gained"] = "Получена честь"
L["Hostile damage"] = "Враждебный урон"
L["Hostile heals"] = "Враждебное исцеление"
L["Hostile players"] = "Враждебные игроки"
L["Hostile spell damage"] = "Враждебный урон заклинаниями"
L["Hostile units"] = "Враждебные объекты"
L["If you can't find one or more chat windows, they may have become docked next to another chat window."] = "Если вы не можете найти одно или несколько окон чата, они могут быть привязаны к другим окнам."
L["If you can't find the chat window, it may have become docked next to another chat window."] = "Если вы не можете найти окно чата, возможно, оно присоединено к другому окну чата."
L["Include extra values"] = "Дополнительные значения"
L["Include level"] = "Включать уровень"
L["Include raid icons"] = "Метки целей рейда"
L["Include rested experience"] = "Опыт от отдыха"
L["Include spell icons"] = "Значки заклинаний"
L["Includes the word \"for\" in most combat log output. This only applies to the |cffffff20%s|r display mode."] = "Включает предлог \"на\" в большинство выводов журнала боя. Относится только к режиму отображения |cffffff20%s|r"
L["Include the word \"for\""] = "Предлог \"на\""
L["Instant Replay"] = "Воспроизведение"
L["Link"] = "Ссылка"
L["Link (abbreviated)"] = "Ссылка (сокращенная)"
L["Loaded"] = "Загружен"
L["Loot"] = "Добыча"
L["loot %s"] = "добыча %s"
L["lose reputation %s %s"] = "потеря репутации %s %s"
L["lost a stack"] = "теряет уровень эффекта"
L["Mouse wheel scrolls. Ctrl scrolls faster. Shift scrolls to top or bottom."] = "Колесо мыши прокручивает. Ctrl ускоряет прокрутку. Shift позволяет перейти к верху или низу."
L["Name Is"] = "Имя:"
L["Name Is Not"] = "Имя не"
L["Neutral"] = "Нейтральное"
L["None"] = "Ничего"
L["Normal text"] = "Обычный текст"
L["Numbers only"] = "Только числа"
L["Open chat window"] = "Открыть окно чата"
L["Open chat windows"] = "Открыть окна чата"
L["Opens all chat windows being used by HitsMode5 filters, if any are currently closed."] = "Открывает все окна чата, используемые фильтрами HitsMode5, если какие-либо из них закрыты."
L["Opens the selected chat window if it is closed."] = "Открыть выбранное окно чата, если оно закрыто."
L["Options governing how the combat log text is rendered to your chat frame."] = "Опции, управляющие показом журнала боя в окне чата"
L["Or"] = "ИЛИ"
L["Ownership"] = "Событие принадлежит"
L["PARTY_KILL"] = "Убийства группы"
L["Prints some text into all open chat windows, to remind you which is which."] = "Выводит текст во все открытые окна чата, чтобы напомнить, какое из них - какое."
L["Profile modified, rebooting"] = "Профиль изменён, перезагрузка"
L["RANGE_DAMAGE"] = "Урон дальнего боя"
L["RANGE_MISSED"] = "Промахи дальнего боя"
L["Reaction"] = "Реакция"
L["Rename filter"] = "Переименовать фильтр"
L["Replay combat"] = "Воспроизвести бой"
L["Replay is already running. Please wait for it to finish."] = "Воспроизведение уже запущено. Дождитесь его окончания."
L["Replay lines per frame"] = "Строк воспроизведения на кадр"
L["Replay running..."] = "Воспроизведение идёт..."
L["Reputation gained"] = "Получена репутация"
L["Reset options"] = "Сбросить настройки"
L["Resets the Instant Replay options to their defaults. Your Instant Replay settings are saved until you log out or reload your UI. This button allows you to reset them quickly."] = "Сбрасывает настройки Воспроизведения к значениям по умолчанию. Ваши настройки Воспроизведения сохранятся пока вы не выйдете из мира или не перезагрузите интерфейс пользователя. Эта кнопка позволяет быстро сбросить их."
L["Resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values will be abbreviated to just their first letter. Does not affect energy types or miss types."] = "Значения сопротивлений, блокирований, скользящих ударов, сокрушений, уязвимостей, переисцелений и избыточного урона будут сокращены до их первой буквы. Не влияет на типы энергии или промахов."
L[" rested"] = "отдых"
L["Select which chat window to use for this filter's combat log output. You cannot use chat window 2, which is the default Blizzard Combat Log."] = "Выберите окно чата, в которое будет направлен вывод этого фильтра. Вы не можете выбрать окно чата 2, так как это основной журнал боя Blizzard."
L[ [=[Sets the display mode for this filter.

|cffffff20%s|r:
  [You] hit [Monster] for 12

|cffffff20%s|r:
  12 - [You] hit [Monster]

|cffffff20%s|r:
  12

|cffffff20%s|r:
  A custom format specified below.]=] ] = [=[Задайте режим показа для этого фильтра

|cffffff20%s|r:
  [Вы] удар [Монстр] на 12

|cffffff20%s|r:
  12 - [Вы] удар [Монстр]

|cffffff20%s|r:
  12

|cffffff20%s|r:
Особый формат, заданный ниже.]=]
L["share of the loot is %s"] = "доля добычи - %s"
L["Show events with no dest unit"] = "Показывать события без получателя"
L["Show events with no source unit"] = "Показывать события без отправителя"
L["Show \"you\" instead of your name"] = "Показывать \"вы\" вместо вашего имени"
L["Skill changed"] = "Навык изменён"
L[" skill has increased to %s"] = "навык увеличен до %s"
L["Source Units"] = "Отправители"
L["Special Cases"] = "Особые случаи"
L["Special Events"] = "Особые события"
L[ [=[Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.

They will not show for replayed combat logs.]=] ] = [=[Особые события не являются частью нормального журнала событий, но вы всё равно можете показать их в HitsMode5. Они будут показаны только если относятся к вам и не будут ограничены фильтрами отправителей и получателей.

Они не будут показаны в воспроизводимых журналах боя.]=]
L["SPELL_AURA_APPLIED"] = "Аура получена"
L["SPELL_AURA_APPLIED_DOSE"] = "Получены уровни ауры"
L["SPELL_AURA_BROKEN"] = "CC снят (ближний)"
L["SPELL_AURA_BROKEN_SPELL"] = "CC снят (заклинание)"
L["SPELL_AURA_REFRESH"] = "Аура обновлена"
L["SPELL_AURA_REMOVED"] = "Аура снята"
L["SPELL_AURA_REMOVED_DOSE"] = "Потеряны уровни ауры"
L["SPELL_BUILDING_DAMAGE"] = "Осадный урон"
L["SPELL_BUILDING_HEAL"] = "Осадное лечение"
L["SPELL_CAST_FAILED"] = "Заклинание неудачно"
L["SPELL_CAST_START"] = "Начало заклинания"
L["SPELL_CAST_SUCCESS"] = "Заклинание удачно"
L["SPELL_CREATE"] = "Создание"
L["SPELL_DAMAGE"] = "Урон заклинанием"
L["SPELL_DISPEL"] = "Заклинание развеяно"
L["SPELL_DISPEL_FAILED"] = "Развеяние неудачно"
L["SPELL_DRAIN"] = "Истощение"
L["SPELL_ENERGIZE"] = "Восполнение"
L["SPELL_EXTRA_ATTACKS"] = "Дополнительные атаки"
L["SPELL_HEAL"] = "Лечение"
L["SPELL_INSTAKILL"] = "Мгновенное убийство"
L["SPELL_INTERRUPT"] = "Заклинание прервано"
L["SPELL_LEECH"] = "Похищение"
L["SPELL_MISSED"] = "Промах заклинанием"
L["Spell Name Blacklist"] = "Черный список заклинаний"
L["Spell names"] = "Названия заклинаний"
L["Spell Name Whitelist"] = "Белый список заклинаний"
L["SPELL_PERIODIC_DAMAGE"] = "Периодич. урон закл."
L["SPELL_PERIODIC_DRAIN"] = "Периодич. истощение"
L["SPELL_PERIODIC_ENERGIZE"] = "Периодич. восп."
L["SPELL_PERIODIC_HEAL"] = "Периодич. лечение"
L["SPELL_PERIODIC_LEECH"] = "Периодич. похищение"
L["SPELL_PERIODIC_MISSED"] = "Промахи периодич. закл."
L["SPELL_RESURRECT"] = "Воскрешение"
L["Spells"] = "Заклинания"
L["Spell Schools"] = "Школы заклинаний"
L[ [=[Spell/skill names.

Only used when not displaying spell links.]=] ] = [=[Названий заклинаний/навыков.

Используется только если не показываются ссылки]=]
L["SPELL_STOLEN"] = "Заклинание украдено"
L["SPELL_SUMMON"] = "Призыв"
L["Standard"] = "Стандартный"
L["Standard (numbers first)"] = "Стандартный (сначала числа)"
L["SWING_DAMAGE"] = "Ближний урон"
L["SWING_MISSED"] = "Промахи ближнего боя"
L["Text"] = "Текст"
L["Text (abbreviated)"] = "Текст (сокращенный)"
L["Text Layout"] = "Формат текста"
L["These are optional. Select \"None\" to exclude all special cases."] = "Необязательны. Выберите \"Нет\" чтобы исключить все особые случаи"
L["The sentence structure portion of each combat log entry."] = "Структура предложения каждой записи в журнале боя"
L["The square brackets surrounding unit names."] = "Квадратные скобки вокруг имен объектов"
L["This is chat window %d"] = "Это окно чата %d"
L["Unable to load Blizzard Combat Log. HitsMode5 cannot be enabled. (Reason: %s)"] = "Невозможно загрузить"
L["Unable to load Replay module; requires Options module"] = "Невозможно запустить модуль Воспроизведения. Требуется модуль Настроек."
L["Unit comparison mode"] = "Режим сравнения объектов"
L["UNIT_DESTROYED"] = "Объект уничтожен"
L["UNIT_DIED"] = "Объект умер"
L["UNIT_DISSIPATES"] = "Объект пропал"
L["Unit Names"] = "Имена объектов"
L["Unit Type"] = "Тип объекта"
L["Unknown"] = "Неведомо"
L[ [=[Uses a tag system to let you create your own combat log formats. Any tags not used in a given event will be removed. Tags are case sensitive. Extra whitespace will be removed from the string before it is displayed.

|cffffff20$source|r - The source unit name.
|cffffff20$dest|r - The destination unit name.
|cffffff20$spell|r - The spell, skill, or enchant used.
|cffffff20$action|r - The action text for the event (hit, missed, etc.)
|cffffff20$for|r - The word "for" in some events; automatically removed if Include For is turned off.
|cffffff20$amount|r - The numeric amount associated with the event, if any.
|cffffff20$otherspell|r - The source's spell interacts with the destination's spell in certain events. $otherspell is the destination's spell.
|cffffff20$extra|r - All extra information about the event, such as resists, overkill, miss type, failure reason, etc. Not shown if Include Extra Values is off.
|cffffff20$amtsep|r - Replaced with a dash (-) if the $amount tag is also being filled with a number.]=] ] = [=[Использует систему меток для создания вашего собственного формата журнала. Любые метки, не используемые в текущем событии будут удалены. Метки чувствительны к регистру. Дополнительные пробелы будут удалены из строки перед показом.

|cffffff20$source|r - Название объекта-отправителя.
|cffffff20$dest|r - Названия объекта-получателя.
|cffffff20$spell|r - Используемое заклинание, навык или усиление оружия.
|cffffff20$action|r - Текст действия для события (попадание, промах и т.д.)
|cffffff20$for|r - Предлог "на" в некоторых событиях; автоматически удаляется, если "Включать предлог "на"" выключено.
|cffffff20$amount|r - Числовое значение, связанное с событием, если оно существует.
|cffffff20$otherspell|r - В некоторых событиях заклинание отправителя взаимодействует с заклинанием получателя. $otherspell - заклинание получателя.
|cffffff20$extra|r - Вся дополнительная информация о событии, такая как сопротивления, избыточный урон, тип промаха, причина неудачи и т.д. Не показывается, если отключен показ дополнительных значений.
|cffffff20$amtsep|r - Заменяется дефисом (-), если метка $amount также заполняется числом.]=]
L["Value threshold"] = "Предел значения"
L["When HitsMode5 replays your combat log, it replays a certain number of lines per frame. This prevents your client from locking up for an extended period of time while the combat log is replayed. You may wish to adjust this setting to a higher number if you have a very fast computer, need to replay a long combat log (particularly in a raid), and don't mind a little lag while it happens. The default Blizzard Combat Log replays one line per frame."] = "Когда HitsMode5 воспроизводит журнал боя, он показыавет определенное количество строк за кадр. Это не позволяет клиенту зависать на долгое время во время воспроизведения журнала боя. Вы можете увеличить это значение, если у вас очень быстрый компьютер, вам нужно воспроизвести большой отрезок боя (особенно в рейде) и вы не возражаете против небольшого лага, пока это происходит. Журнал боя Blizzard воспроизводит по одной строке за кадр."
L["When selected, all unit names will be abbreviated to just the first letter of every word."] = "Когда установлено, все имена объектов будут сокращены до первой буквы каждого слова"
L["When selected, a unit's level will be displayed next to their name. This will also work for replayed combat logs."] = "Когда установлено, рядом с именем объекта будет показан его уровень. Это работает и для воспроизводимых журналов боя."
L["When selected, events with no destination unit will be shown in this filter."] = "Когда установлено, в этом фильтре будут показаны события без получателя."
L["When selected, events with no source unit will be shown in this filter."] = "Когда установлено, в этом фильтре будут показаны события без отправителя."
L["When selected, raid icons will be shown next to unit names (if applicable). This will also work for replayed combat logs."] = "Когда опция установлена, рядом с именами (при их наличии) будут показаны метки целей рейда. Это работает и для воспроизводимых журналов."
L["When selected, spell damage values will be colorized based on the spell school. For hybrid spell schools, a priority system is used to choose the color."] = "Когда опция установлена, значения урона заклинаний будут окрашены согласно школе заклинания. Для гибридных заклинаний используется система приоритетов."
L[ [=[When selected, spell icons will be shown in the combat log. You can choose to show icons only (no text), by turning this on and selecting "None" for display mode above.

Disable this feature if you encounter graphical corruption in your chat window.]=] ] = [=[Когда опция установлена, в журнале боя будут показаны значки заклинаний. Вы можете выбрать показ только значков (без текста) включив данную опцию и указав "Ничего" в качестве режима вывода.

Отключите эту опцию, если в окне чата возникают искажения графики.]=]
L[ [=[When selected, square brackets will be placed around all unit names, for example:

  [You] hit [Monster] for 16]=] ] = [=[Когда опция установлена, вокруг названий объектов будут установлены квадратные скобки, например:

[Халк] ломать [Всё подряд] на 214]=]
L[ [=[When selected, unit names will be colorized by their class (when their class is available). Replayed combat logs may not include this feature if you recently reloaded your UI. WoW does not return class information for all units in the game.

Disable this feature to use the default color for various unit types.]=] ] = [=[Когда опция установлена, имена объектов будут окрашены согласно их классу (когда их класс доступен). Воспроизводимые журналы боя могут не использовать эту функцию, если вы недавно перезагружали интерфейс. WoW не сохраняет информацию о классе объектов в игре.

Отключите эту опцию, чтобы использовать цвет по умолчанию для всех типов объектов.]=]
L["When selected, uses You and Your to indicate the player, rather than your name."] = "Когда установлено, использует \"вы\" и \"ваш\" для указания на игрока, вместо вашего имени."
L["When showing experience gain, separately show the amount of experience that was rested."] = "При показе получаемого опыта отдельно показывать количество опыта, полученное от отдыха."
L["You"] = "Вы"
L["You entered a name that already exists. To copy a filter, enter a unique filter name."] = "Вы ввели уже существующее название. Для копирования фильтра введите уникальное название."
L["You have no filters. Creating a default filter."] = "У вас нет фильтров. Создаётся фильтр по умолчанию."
L["You must choose at least one item from this category."] = "Вы должны выбрать не менее одного элемента в данной категории"
L["Your pet"] = "Ваш питомец"
L["Your pet damage values are highlighted (makes them brighter)."] = "Урон вашего питомца подсвечивается (становится ярче)"
L["Your target"] = "Ваша цель"
