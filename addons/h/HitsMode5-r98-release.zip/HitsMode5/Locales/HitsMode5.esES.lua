local L = LibStub("AceLocale-3.0"):NewLocale("HitsMode5", "esES")
if not L then return end
L["Abbreviate extra values"] = "Abreviar valores extra"
L["Abbreviate unit names"] = "Abreviar nombres de unidades"
L["Adds a flag to special value types in the combat log."] = "Añadir marcador a un valor especial en el registro de combate"
L["Affiliation"] = "Procedencia"
L["ALL"] = "|cff20ff20All activado/desactivado|r" -- Needs review
-- L["Amount to replay"] = ""
-- L["And"] = ""
L["Are you sure you want to delete this filter?"] = "Estás seguro de querer borrar este filtro?"
-- L["Begins the Instant Replay. Combat is replayed into a dedicated window using the settings below."] = ""
L["Brackets"] = "Corchetes"
L["Brackets around names"] = "Nombres con corchetes"
-- L[" (c)"] = ""
-- L["Cancel replay"] = ""
-- L["Cancels a currently running combat replay."] = ""
-- L["|cfffbd284Left-Click|r to start an Instant Replay."] = ""
-- L["|cfffbd284Right-Click|r to open configuration."] = ""
-- L["|cfffbd284Shift-Click|r to cancel."] = ""
-- L["|cfffbd284Shift-Click|r to replay %d lines of recent combat."] = ""
-- L["Chat %d"] = ""
L["CHAT_MSG_COMBAT_FACTION_CHANGE"] = "Reputación cambiada"
L["CHAT_MSG_COMBAT_HONOR_GAIN"] = "Honor ganado"
L["CHAT_MSG_COMBAT_XP_GAIN"] = "Experiencia ganada"
-- L["CHAT_MSG_COMBAT_XP_GAIN_1"] = ""
-- L["CHAT_MSG_COMBAT_XP_GAIN_2"] = ""
L["CHAT_MSG_LOOT"] = "Objeto despojado"
L["CHAT_MSG_MONEY"] = "Dinero despojado"
L["CHAT_MSG_SKILL"] = "Habilidad cambiada"
L["Chat window"] = "Ventana de Chat"
L["Chat Window"] = "Ventana de Chat"
L["Chat window reminder"] = "Recordatorio de ventana de chat"
L["Choose the filter to be deleted."] = "Elije el filtro a borrar"
L["Choose which destination unit types to display events for."] = "Mostrar hacia que tipo de unidad fueron dirigidas" -- Needs review
L["Choose which source unit types to display events for."] = "Mostrar desde que unidad fueron emitidas" -- Needs review
--[==[ L[ [=[Clears all chat windows being used by filters, and replays all saved combat back to them. This is useful if you've changed your filter settings and want to see recent combat using the new settings.

Combat is saved by the WoW client (not by HitsMode5). You can change the combat retention time above.]=] ] = "" ]==]
L["Click to open the HitsMode5 knowledge base, which is filled with frequently asked questions."] = "Has click para abrir la base de conocimiento de HitsMode5, que esta repleta de las preguntas más frecuentes."
L["Color by class"] = "Colores por clase"
L["Color by spell school"] = "Color por escuela de hechizo"
L["Colors"] = "Colores"
L["Combat Events"] = "Suceso del combate"
-- L["COMBATLOG_FORMAT_NUMBERS_ONLY_A"] = ""
-- L["COMBATLOG_FORMAT_STANDARD_A"] = ""
-- L["COMBATLOG_FORMAT_STANDARD_NUMBERS_FIRST_A"] = ""
L["Combat log messages with a value below this setting will not be displayed. This can be useful to prevent spam from very small events."] = "Los valores en el registro de combate inferiores a esta configuración no seran mostrados. Esto puede ser útil para prevenir spam por sucesos de muy poco valor."
L["COMBATLOG_OBJECT_AFFILIATION_MINE"] = "Mio"
L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = "No perteneciente al grupo/banda"
L["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = "Grupo"
L["COMBATLOG_OBJECT_AFFILIATION_RAID"] = "Banda"
L["COMBATLOG_OBJECT_CONTROL_NPC"] = "NPC-Personaje no Jugable"
L["COMBATLOG_OBJECT_CONTROL_PLAYER"] = "Jugador"
L["COMBATLOG_OBJECT_FOCUS"] = "Focus"
L["COMBATLOG_OBJECT_MAINASSIST"] = "Ayudante principal"
L["COMBATLOG_OBJECT_MAINTANK"] = "Tanque principal"
L["COMBATLOG_OBJECT_NONE"] = "Ninguno"
L["COMBATLOG_OBJECT_RAIDTARGET1"] = "Objetivo de banda 1"
L["COMBATLOG_OBJECT_RAIDTARGET2"] = "Objetivo de banda 2"
L["COMBATLOG_OBJECT_RAIDTARGET3"] = "Objetivo de banda 3"
L["COMBATLOG_OBJECT_RAIDTARGET4"] = "Objetivo de banda 4"
L["COMBATLOG_OBJECT_RAIDTARGET5"] = "Objetivo de banda 5"
L["COMBATLOG_OBJECT_RAIDTARGET6"] = "Objetivo de banda 6"
L["COMBATLOG_OBJECT_RAIDTARGET7"] = "Objetivo de banda 7"
L["COMBATLOG_OBJECT_RAIDTARGET8"] = "Objetivo de banda 8"
L["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = "Amistoso"
L["COMBATLOG_OBJECT_REACTION_HOSTILE"] = "Hostil"
L["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = "Neutral"
L["COMBATLOG_OBJECT_TARGET"] = "Objetivo"
L["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = "Guardián"
L["COMBATLOG_OBJECT_TYPE_NPC"] = "NPC-Personaje no Jugable"
L["COMBATLOG_OBJECT_TYPE_OBJECT"] = "Objeto"
L["COMBATLOG_OBJECT_TYPE_PET"] = "Mascota"
L["COMBATLOG_OBJECT_TYPE_PLAYER"] = "Jugador"
L["Combat log retention time"] = "tiempo de retraso en el registro de combate"
L["Combat separator"] = "Separador de combate"
L["Configure all the colors used throughout the HitsMode5 combat log. Colors are global for all filters."] = "Configurar todos los colores usados en todo el registro de combate de HitsMode5. Los colores son globales para todos los filtros."
L["Copy filter"] = "Copiar Filtro"
L["Create a copy of this filter by entering a new name and clicking Okay."] = "Crear una copia de este Filtro introduciendo un nuevo nombre y pulsando Aceptar"
L["Create filter"] = "Crear Filtro"
-- L["create %s"] = ""
-- L["crit"] = ""
-- L["crit damaged"] = ""
L["Crit flag (*)"] = "Marcar criítico"
-- L["crit healed"] = ""
L["Critical damage values are highlighted (makes them brighter)."] = "Los valores de daño Criíticos son remarcados ( hacerlos mas brillantes )"
-- L[" (crushing)"] = ""
L["Currently |cff20ff20enabled|r."] = "Actualmente |cff20ff20activado|r."
L["Currently |cffff2020disabled|r."] = "Actualmente |cff20ff20desactivado|r."
-- L["Custom"] = ""
-- L["Custom display format"] = ""
-- L[" (%d a)"] = ""
-- L[" (%d absorbed)"] = ""
L["DAMAGE_SHIELD"] = "Daño en Escudo" -- Needs review
L["DAMAGE_SHIELD_MISSED"] = "Daño en Escudo errado" -- Needs review
L["DAMAGE_SPLIT"] = "División de Daño" -- Needs review
-- L[" (%d b)"] = ""
-- L[" (%d blocked)"] = ""
-- L["Default"] = ""
--[==[ L[ [=[Defines whether resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values should be shown after regular damage. Also shows the energy type for energizes, and the miss type for misses.

Not available for the |cffffff20%s|r display mode.]=] ] = "" ]==]
L["Delete filter"] = "Borrar Filtro"
L["Deletes the chosen filter."] = "Borrar el Filtro elejido"
-- L["Deletes this filter."] = ""
L["Destination Units"] = "Unidades de Destino"
L[ [=[Determines how long your WoW client will retain combat log data (in seconds). This affects HitsMode5's ability to replay the combat log. Longer retention times will cause your client to use more of your RAM, but will allow you to evaluate a longer period of combat after it has happened. The default setting is 5 minutes (300 seconds). Note that this is a WoW setting, not a HitsMode5 setting. This WoW setting is normally hidden from users.

WoW currently imposes a limit of 315 seconds for this value.]=] ] = [=[Determina cuanto tiempo tu cliente de juego mantendrá el registro de combate ( en segundos ). Esto afecta a la habilidad de HitsMode5 para reproducir el registro de combate.Un tiempo prolongado hará mas uso de memoria RAM. pero permitira evaluar un periodo mas largo de combate despues de que este haya ocurido. El tiempo por defecto es 5 minutos ( 300 segs ). Ten en cuenta que esta es la configuración de Blizzard y no de HitsMode5. Esta configuración es ocultada generalmente a los usuarios.

Blizzard impone actualmente un limite de 315 segundos a este valor.]=]
L["Determines how spells and skills will be displayed in the combat log. Abbreviated spells will show just the first letter of every word in the spell."] = "Determina como las habilidades y hechizos serán mostrados en el registro de combate. Los hechizos abreviados serán monstrados con la primera letra de cada palabra en el nombre de hechizo"
--[==[ L[ [=[Determines how your unit filters will be used.

|cffffff20Or:|r
  Events where the source filters OR the destination filters match your selections will be shown.

|cffffff20And:|r
  Events where the source filters AND the destination filters match your selections will be shown.]=] ] = "" ]==]
-- L["Determines the percentage of recent combat to replay. Replaying thousands of lines can take a long time. Since WoW doesn't reliably save combat based on time, we simply let you choose what percentage of saved combat to replay."] = ""
L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."] = "Determina que sucesos del registro de combate serán mostrados. Esta lista esta restringida solo al registro de combate de Blizzard" -- Needs review
-- L["Disabled"] = ""
L["Display"] = "Mostrar"
L["Display mode"] = "Modo Mostrar"
-- L[" (%d o)"] = ""
-- L[" (%d overheal)"] = ""
-- L[" (%d overkill)"] = ""
-- L[" (%d r)"] = ""
-- L[" (%d resisted)"] = ""
-- L[" (%d v)"] = ""
-- L[" (%d vulnerability damage)"] = ""
L["Enable filter"] = "Activar Filtro"
L["Enable HitsMode5"] = "Activar HitsMode5"
L["Enables or disables HitsMode5 entirely. When disabled, HitsMode5 will not respond to any combat log events. You will still be able to enable HitsMode5 and replay the combat log to see what happened."] = "Activa o desactiva HitsMode5 completamente. CUando se desactiva, HitsMode5 no responderá a ningun suceso del registro de combate. Aun podrás activar HitsMode5 y repetir el registro de combate para ver que ha pasado"
L["Enables the filter."] = "Activar el Filtro"
L["ENCHANT_APPLIED"] = "Encantamiento aplicado"
L["ENCHANT_REMOVED"] = "Encantamiento quitado"
L["Energizes and extra attacks"] = [=[Energizamiento y valores extra

( After seen many times "Energizes" i start thinking you mean Buff events, if it is so, then use "Buff" as "energizes" translation, im shore al spanish readers will understund)]=]
-- L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."] = ""
-- L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."] = ""
-- L["Enter a comma-separated list of spell names. Only events whose spells are not on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = ""
-- L["Enter a comma-separated list of spell names. Only events whose spells are on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = ""
L[ [=[Enter text to be placed in the chat window when you leave combat. This helps break up the combat log from fight to fight.

Does not affect replayed combat logs.

To disable this feature, empty this text box and click Okay.]=] ] = [=[Introduce el texto que se colocará en la ventana de Chat cuando termines un combate. Esto ayudará visualizar el corte entre pelea y pelea.

No afectara a registros de combate reproducidos.

Para desactivar esta función deja vacio el campo de texto y pulsa Aceptar.]=]
L["Enter the name for the filter."] = "Introduzca el nombre del filtro" -- Needs review
L["Enter the name for the new filter."] = "Introduzca el nombre del nuevo flitro" -- Needs review
L["ENVIRONMENTAL_DAMAGE"] = "Daño Ambiental" -- Needs review
-- L["Execute"] = ""
L["Experience gained"] = "Experiencia ganada"
L["Extra values"] = "Vlores extra"
-- L["Extra values in the combat log (resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill damage, as well as energy types and miss types)."] = ""
-- L["faded"] = ""
L["Filters"] = "Filtros"
L[ [=[Filters are the basic building block of the HitsMode5 combat log. Each filter lets you choose which events to show, which chat window to show them in, and how you'd like them to look.

You can create an unlimited number of filters, all running at once.

You can also create filters and turn them off, saving them for a special occasion when you need to look something up.]=] ] = [=[Los Filtros son los ladrillos básicos del registro de combate de HitsMode5. Cada filtro te premite elejir que suceso monstrar, en que ventana de chat mostrarla y como quieres que se vean.

Puedes crear infinidad de Filtros, y pueden mostrarse a la vez.

Tambien puedes crear Filtros y desactivarlos, guardandolos para una ocasión especial cuando necesites verlo]=]
L["FLAG_CRITS"] = "Críticos"
L["FLAG_ENERGIZES"] = "Energizamiento" -- Needs review
L["FLAG_EXP"] = "Experiencia"
L["FLAG_HEALS"] = "Curas"
L["FLAG_HONOR"] = "Honor"
L["FLAG_PET_DAMAGE"] = "Daño de mascota"
L["FLAG_REP"] = "Reputación"
L["Flag special values"] = "Sobresaltar valores especiales"
-- L["for"] = ""
L["Friendly damage"] = "Daño amigo"
L["Friendly heals"] = "Curas amigas"
L["Friendly spell damage"] = "Daño de hechizo amigo"
L["Friends"] = "Amigos"
-- L[" (g)"] = ""
-- L["gain experience %s"] = ""
-- L["gain reputation %s %s"] = ""
L["General"] = true
L["General Options"] = "Opciones Generales"
L["Get help with HitsMode5."] = "Consigue ayuda con HitsMode5"
-- L[" (glancing)"] = ""
L["Help"] = "Ayuda"
L["Help with HitsMode5"] = "Ayuda con HitsMode5"
L["Highlight crits"] = "Resaltar Críticos"
L["Highlight pet damage"] = "Resaltar daño de mascota"
-- L["HitsMode5: Instant Replay"] = ""
-- L["HitsMode5 is currently replaying combat."] = ""
-- L["HitsMode5 is replaying combat..."] = ""
L["Honor gained"] = "Honor ganado"
L["Hostile damage"] = "Daño enemigo"
L["Hostile heals"] = "Curas enemigas"
L["Hostile players"] = "Jugadores enemigos"
L["Hostile spell damage"] = "Daño de hechizo enemigo"
L["Hostile units"] = "Unidades enemigas"
-- L["If you can't find one or more chat windows, they may have become docked next to another chat window."] = ""
-- L["If you can't find the chat window, it may have become docked next to another chat window."] = ""
L["Include extra values"] = "Incluir valores extras"
-- L["Include level"] = ""
L["Include raid icons"] = "Incluir iconos de banda"
L["Include rested experience"] = "Incluir experiencia restada"
L["Include spell icons"] = "Incluir iconos de hechizos"
L["Includes the word \"for\" in most combat log output. This only applies to the |cffffff20%s|r display mode."] = "Incluir la palabra \" para \" in la mayoria de los registros de combate. Esta opcion solo se aplica al modo mostrar |cffffff20%s|r" -- Needs review
L["Include the word \"for\""] = "incluir la palabra \" para \""
-- L["Instant Replay"] = ""
L["Link"] = "Enlace"
L["Link (abbreviated)"] = "Enlace ( Abreviado )"
L["Loaded"] = "Cargado"
L["Loot"] = "Botín"
-- L["loot %s"] = ""
-- L["lose reputation %s %s"] = ""
-- L["lost a stack"] = ""
-- L["Mouse wheel scrolls. Ctrl scrolls faster. Shift scrolls to top or bottom."] = ""
L["Name Is"] = "Nombre existe"
L["Name Is Not"] = "Nombre no existe"
L["Neutral"] = true
L["None"] = "Ninguno"
L["Normal text"] = "Texto Normal"
L["Numbers only"] = "Solo Números"
-- L["Open chat window"] = ""
-- L["Open chat windows"] = ""
-- L["Opens all chat windows being used by HitsMode5 filters, if any are currently closed."] = ""
-- L["Opens the selected chat window if it is closed."] = ""
L["Options governing how the combat log text is rendered to your chat frame."] = "Opciones que controlan como es renderizado en tu ventana de chat el registro de combate"
-- L["Or"] = ""
L["Ownership"] = "Propiedad"
L["PARTY_KILL"] = "Muerte de grupo"
L["Prints some text into all open chat windows, to remind you which is which."] = "Muestra algo de texto en todas las ventanas de chat abiertas, para recordarte cual es cual"
-- L["Profile modified, rebooting"] = ""
L["RANGE_DAMAGE"] = "Daño a distancia"
L["RANGE_MISSED"] = "Fallo a distancia"
L["Reaction"] = "Reacción"
L["Rename filter"] = "Renombrar Filtro"
-- L["Replay combat"] = ""
-- L["Replay is already running. Please wait for it to finish."] = ""
L["Replay lines per frame"] = "Repite lineas por fotograma" -- Needs review
-- L["Replay running..."] = ""
-- L["Reputation gained"] = ""
-- L["Reset options"] = ""
-- L["Resets the Instant Replay options to their defaults. Your Instant Replay settings are saved until you log out or reload your UI. This button allows you to reset them quickly."] = ""
-- L["Resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values will be abbreviated to just their first letter. Does not affect energy types or miss types."] = ""
-- L[" rested"] = ""
L["Select which chat window to use for this filter's combat log output. You cannot use chat window 2, which is the default Blizzard Combat Log."] = "Seleccionar que ventana de chat usar para la salida de este Filtro del registro de compate. No puedes usar ventana de chat 2, porque esta es la ventana por defecto de Blizzard para el registro de combate"
--[==[ L[ [=[Sets the display mode for this filter.

|cffffff20%s|r:
  [You] hit [Monster] for 12

|cffffff20%s|r:
  12 - [You] hit [Monster]

|cffffff20%s|r:
  12

|cffffff20%s|r:
  A custom format specified below.]=] ] = "" ]==]
-- L["share of the loot is %s"] = ""
-- L["Show events with no dest unit"] = ""
-- L["Show events with no source unit"] = ""
-- L["Show \"you\" instead of your name"] = ""
-- L["Skill changed"] = ""
-- L[" skill has increased to %s"] = ""
L["Source Units"] = "Fuentes"
L["Special Cases"] = "Casos Especiales"
L["Special Events"] = "Sucesos Especiales"
L[ [=[Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.

They will not show for replayed combat logs.]=] ] = "Los sucesos especiales no forman parte del registro de combate normal, pero aun puedes mostrarlos con HitsMode5. Ellos solo serán mostrados cuando te ocurran a ti ( no a otros ), y no respetaran filtros de unidades de destino o fuente."
L["SPELL_AURA_APPLIED"] = "Aura aplicada"
L["SPELL_AURA_APPLIED_DOSE"] = "Aura aplicada ( dosis )"
L["SPELL_AURA_BROKEN"] = "CC roto ( melee )"
L["SPELL_AURA_BROKEN_SPELL"] = "CC roto ( hechizo )"
L["SPELL_AURA_REFRESH"] = "Aura refrescada"
L["SPELL_AURA_REMOVED"] = "Aura quitada"
L["SPELL_AURA_REMOVED_DOSE"] = "Aura quitada ( dosis )"
L["SPELL_BUILDING_DAMAGE"] = "Daño en Construcciones/Edificios" -- Needs review
L["SPELL_BUILDING_HEAL"] = "Curas en Construcciones/Edificios" -- Needs review
L["SPELL_CAST_FAILED"] = "Hechizo lanzado fallido" -- Needs review
L["SPELL_CAST_START"] = "Hechizo lanzado iniciado" -- Needs review
L["SPELL_CAST_SUCCESS"] = "Hechizo Lanzado con éxito" -- Needs review
L["SPELL_CREATE"] = "Creación" -- Needs review
L["SPELL_DAMAGE"] = "Daño de Hechizo"
L["SPELL_DISPEL"] = "Hechizo Disipado"
L["SPELL_DISPEL_FAILED"] = "Hechizo Disipado Fallido"
L["SPELL_DRAIN"] = "Hechizo de Succión"
L["SPELL_ENERGIZE"] = "Hechizo Energizante" -- Needs review
L["SPELL_EXTRA_ATTACKS"] = "Ataques Extra"
L["SPELL_HEAL"] = "Cura"
L["SPELL_INSTAKILL"] = [=[Golpe Final
or
Muerte Instantanea]=] -- Needs review
L["SPELL_INTERRUPT"] = "Hechizo cortado"
L["SPELL_LEECH"] = "Hechizo parásito"
L["SPELL_MISSED"] = "Hechizo Fallido"
-- L["Spell Name Blacklist"] = ""
-- L["Spell names"] = ""
-- L["Spell Name Whitelist"] = ""
L["SPELL_PERIODIC_DAMAGE"] = "Daño de Hechizo periódico"
L["SPELL_PERIODIC_DRAIN"] = "Daño de Hechizo por succión"
L["SPELL_PERIODIC_ENERGIZE"] = "Hechizo Energizante periódico" -- Needs review
L["SPELL_PERIODIC_HEAL"] = "Hechizo de sanación periódico"
L["SPELL_PERIODIC_LEECH"] = "Parásito periódico"
L["SPELL_PERIODIC_MISSED"] = "Hechizo periódico Fallido"
L["SPELL_RESURRECT"] = "Resurreción"
L["Spells"] = "Hechizos"
-- L["Spell Schools"] = ""
--[==[ L[ [=[Spell/skill names.

Only used when not displaying spell links.]=] ] = "" ]==]
L["SPELL_STOLEN"] = "Hechizo Robado"
L["SPELL_SUMMON"] = "Invocación"
L["Standard"] = "Normal"
L["Standard (numbers first)"] = "Normal ( números primero )"
L["SWING_DAMAGE"] = "Daño Melee"
L["SWING_MISSED"] = "Daño Melee Fallido"
L["Text"] = "Texto"
L["Text (abbreviated)"] = "Texto ( abreviado )"
L["Text Layout"] = "Ventana de texo"
L["These are optional. Select \"None\" to exclude all special cases."] = "Estos son opcionales. Selecciona \"Ninguno\" para exlcuir todos los casos especiales."
-- L["The sentence structure portion of each combat log entry."] = ""
-- L["The square brackets surrounding unit names."] = ""
L["This is chat window %d"] = "Esta es la ventana de Chat %d"
L["Unable to load Blizzard Combat Log. HitsMode5 cannot be enabled. (Reason: %s)"] = "No se pudo cargar el Registro de Combate de Blizzard. HitsMode5 no puede ser activado."
-- L["Unable to load Replay module; requires Options module"] = ""
-- L["Unit comparison mode"] = ""
L["UNIT_DESTROYED"] = "Unidad Destruida"
L["UNIT_DIED"] = "Unidad Muerta"
L["UNIT_DISSIPATES"] = "Unidad Disipada"
L["Unit Names"] = "Nombres de unidades"
L["Unit Type"] = "Tipo de Unidad"
-- L["Unknown"] = ""
--[==[ L[ [=[Uses a tag system to let you create your own combat log formats. Any tags not used in a given event will be removed. Tags are case sensitive. Extra whitespace will be removed from the string before it is displayed.

|cffffff20$source|r - The source unit name.
|cffffff20$dest|r - The destination unit name.
|cffffff20$spell|r - The spell, skill, or enchant used.
|cffffff20$action|r - The action text for the event (hit, missed, etc.)
|cffffff20$for|r - The word "for" in some events; automatically removed if Include For is turned off.
|cffffff20$amount|r - The numeric amount associated with the event, if any.
|cffffff20$otherspell|r - The source's spell interacts with the destination's spell in certain events. $otherspell is the destination's spell.
|cffffff20$extra|r - All extra information about the event, such as resists, overkill, miss type, failure reason, etc. Not shown if Include Extra Values is off.
|cffffff20$amtsep|r - Replaced with a dash (-) if the $amount tag is also being filled with a number.]=] ] = "" ]==]
L["Value threshold"] = [=[Umbral de valoración

or

Valoración Umbral

( need to know the context to the right translation )]=] -- Needs review
L["When HitsMode5 replays your combat log, it replays a certain number of lines per frame. This prevents your client from locking up for an extended period of time while the combat log is replayed. You may wish to adjust this setting to a higher number if you have a very fast computer, need to replay a long combat log (particularly in a raid), and don't mind a little lag while it happens. The default Blizzard Combat Log replays one line per frame."] = "Cuando HitsMode5 reproduce un registro de combate, reproduce un cierto número de lineas por marco. Esto previene a tu cliente de juego de bloquearse durante un largo periodo mientras se esta reproduciendo un registro de combate. Es posible que desees ajustar este valor a un número mas alto si tienes un PC muy rápido si necesitas reproducir un registro de combate largo  ( de bandas en particular ) y no te importe un poco de lag mientras esto pasa. El registro de combate de Blizzard reprodce una linea por marco." -- Needs review
-- L["When selected, all unit names will be abbreviated to just the first letter of every word."] = ""
-- L["When selected, a unit's level will be displayed next to their name. This will also work for replayed combat logs."] = ""
-- L["When selected, events with no destination unit will be shown in this filter."] = ""
-- L["When selected, events with no source unit will be shown in this filter."] = ""
L["When selected, raid icons will be shown next to unit names (if applicable). This will also work for replayed combat logs."] = "Cuando este seleccionado, los iconos de banda serán mostrados al costado de los nombres de unidad ( si corresponde ).  Esto también se aplicará a los registros de combate ya reproducidos."
L["When selected, spell damage values will be colorized based on the spell school. For hybrid spell schools, a priority system is used to choose the color."] = "Cuando este seleccionado, los valores de daño de hechizos serán coloreados basados en su escuela de hechizo. Para escuelas hibridas, un sistema de prioridad escogerá el color."
L[ [=[When selected, spell icons will be shown in the combat log. You can choose to show icons only (no text), by turning this on and selecting "None" for display mode above.

Disable this feature if you encounter graphical corruption in your chat window.]=] ] = [=[Cuando este seleccionado, los iconos de los hechizos serán mostrados en el registro de combate. Puedes elejir mostrar solo los iconos activando esto y seleccionando " Ninguno " en el modo de muestra de arriba.

Desactiva esta función si observas graficos corruptos en tu ventada de chat.]=]
L[ [=[When selected, square brackets will be placed around all unit names, for example:

  [You] hit [Monster] for 16]=] ] = [=[Cuando este seleccionado,  los nombres aparecerán rodeados de corchetes, por ejemplo:

[Tu] golpeas a [Monstruo] por 16]=]
L[ [=[When selected, unit names will be colorized by their class (when their class is available). Replayed combat logs may not include this feature if you recently reloaded your UI. WoW does not return class information for all units in the game.

Disable this feature to use the default color for various unit types.]=] ] = "Cuando este seleccionado,  los nombres de unidades serán coloreados segun sus clases ( cuando la clase este permitida ). los registros de combate ya reproducidos puede que no incluyan esta función si has recargado tu interfaz recientemente. Blizzard no devuelve información de clase para todas ls unidades en el juego."
-- L["When selected, uses You and Your to indicate the player, rather than your name."] = ""
L["When showing experience gain, separately show the amount of experience that was rested."] = "Cuando se muestre ganancia de experiencia, mostrar por separado la cantidad de experiencia restada."
-- L["You"] = ""
-- L["You entered a name that already exists. To copy a filter, enter a unique filter name."] = ""
-- L["You have no filters. Creating a default filter."] = ""
L["You must choose at least one item from this category."] = "Debes elegir al menos un objeto de esta categoría"
-- L["Your pet"] = ""
-- L["Your pet damage values are highlighted (makes them brighter)."] = ""
-- L["Your target"] = ""
