local L = LibStub("AceLocale-3.0"):NewLocale("HitsMode5", "enUS", true)

-- Configuration UI and other messages
L["Loaded"] = true
L["Filters"] = true
L["Create filter"] = true
L["Enter the name for the new filter."] = true
L["Delete filter"] = true
L["Choose the filter to be deleted."] = true
L["Deletes the chosen filter."] = true
L["Rename filter"] = true
L["Enter the name for the filter."] = true
L["Display"] = true
L["Unable to load Blizzard Combat Log. HitsMode5 cannot be enabled. (Reason: %s)"] = true
L["Combat Events"] = true
L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."] = true
L["Are you sure you want to delete this filter?"] = true
L["Source Units"] = true
L["Choose which source unit types to display events for."] = true
L["You must choose at least one item from this category."] = true
L["Help"] = true
L["Help with HitsMode5"] = true
L["Affiliation"] = true
L["Reaction"] = true
L["Ownership"] = true
L["Unit Type"] = true
L["Special Cases"] = true
L["These are optional. Select \"None\" to exclude all special cases."] = true
L["Name Is"] = true
L["Name Is Not"] = true
L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."] = true
L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."] = true
L["Destination Units"] = true
L["Choose which destination unit types to display events for."] = true
L["Special Events"] = true
L["Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.\n\nThey will not show for replayed combat logs."] = true
L["Copy filter"] = true
L["Create a copy of this filter by entering a new name and clicking Okay."] = true
L["Enable filter"] = true
L["Enables the filter."] = true
L["Chat Window"] = true
L["Chat window"] = true
L["Select which chat window to use for this filter's combat log output. You cannot use chat window 2, which is the default Blizzard Combat Log."] = true
L["General Options"] = true
L["Enable HitsMode5"] = true
L["Enables or disables HitsMode5 entirely. When disabled, HitsMode5 will not respond to any combat log events. You will still be able to enable HitsMode5 and replay the combat log to see what happened."] = true
L["Combat log retention time"] = true
L["Determines how long your WoW client will retain combat log data (in seconds). This affects HitsMode5's ability to replay the combat log. Longer retention times will cause your client to use more of your RAM, but will allow you to evaluate a longer period of combat after it has happened. The default setting is 5 minutes (300 seconds). Note that this is a WoW setting, not a HitsMode5 setting. This WoW setting is normally hidden from users.\n\nWoW currently imposes a limit of 315 seconds for this value."] = true
L["Replay lines per frame"] = true
L["When HitsMode5 replays your combat log, it replays a certain number of lines per frame. This prevents your client from locking up for an extended period of time while the combat log is replayed. You may wish to adjust this setting to a higher number if you have a very fast computer, need to replay a long combat log (particularly in a raid), and don't mind a little lag while it happens. The default Blizzard Combat Log replays one line per frame."] = true
L["Chat window reminder"] = true
L["Prints some text into all open chat windows, to remind you which is which."] = true
L["This is chat window %d"] = true
L["Value threshold"] = true
L["Combat log messages with a value below this setting will not be displayed. This can be useful to prevent spam from very small events."] = true
L["Text Layout"] = true
L["Display mode"] = true
L["Sets the display mode for this filter.\n\n|cffffff20%s|r:\n  [You] hit [Monster] for 12\n\n|cffffff20%s|r:\n  12 - [You] hit [Monster]\n\n|cffffff20%s|r:\n  12\n\n|cffffff20%s|r:\n  A custom format specified below."] = true
L["Standard"] = true
L["Standard (numbers first)"] = true
L["Numbers only"] = true
L["Include the word \"for\""] = true
L["Includes the word \"for\" in most combat log output. This only applies to the |cffffff20%s|r display mode."] = true
L["Include rested experience"] = true
L["When showing experience gain, separately show the amount of experience that was rested."] = true
L["Include extra values"] = true
L["Defines whether resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values should be shown after regular damage. Also shows the energy type for energizes, and the miss type for misses.\n\nNot available for the |cffffff20%s|r display mode."] = true
L["Combat separator"] = true
L["Enter text to be placed in the chat window when you leave combat. This helps break up the combat log from fight to fight.\n\nDoes not affect replayed combat logs.\n\nTo disable this feature, empty this text box and click Okay."] = true
L["Flag special values"] = true
L["Adds a flag to special value types in the combat log."] = true
L["Unit Names"] = true
L["Brackets around names"] = true
L["When selected, square brackets will be placed around all unit names, for example:\n\n  [You] hit [Monster] for 16"] = true
L["Color by class"] = true
L["When selected, unit names will be colorized by their class (when their class is available). Replayed combat logs may not include this feature if you recently reloaded your UI. WoW does not return class information for all units in the game.\n\nDisable this feature to use the default color for various unit types."] = true
L["Include raid icons"] = true
L["When selected, raid icons will be shown next to unit names (if applicable). This will also work for replayed combat logs."] = true
L["Spells"] = true
L["Display mode"] = true
L["Determines how spells and skills will be displayed in the combat log. Abbreviated spells will show just the first letter of every word in the spell."] = true
L["Text"] = true
L["Text (abbreviated)"] = true
L["Link"] = true
L["Link (abbreviated)"] = true
L["None"] = true
L["Include spell icons"] = true
L["When selected, spell icons will be shown in the combat log. You can choose to show icons only (no text), by turning this on and selecting \"None\" for display mode above.\n\nDisable this feature if you encounter graphical corruption in your chat window."] = true
L["Color by spell school"] = true
L["When selected, spell damage values will be colorized based on the spell school. For hybrid spell schools, a priority system is used to choose the color."] = true
L["Colors"] = true
L["General"] = true
L["Unit Names"] = true
L["Spell Schools"] = true
L["Filters are the basic building block of the HitsMode5 combat log. Each filter lets you choose which events to show, which chat window to show them in, and how you'd like them to look.\n\nYou can create an unlimited number of filters, all running at once.\n\nYou can also create filters and turn them off, saving them for a special occasion when you need to look something up."] = true
L["Configure all the colors used throughout the HitsMode5 combat log. Colors are global for all filters."] = true
L["Get help with HitsMode5."] = true
L["Currently |cff20ff20enabled|r."] = true
L["Currently |cffff2020disabled|r."] = true
L["Options governing how the combat log text is rendered to your chat frame."] = true
L["Click to open the HitsMode5 knowledge base, which is filled with frequently asked questions."] = true
L["Normal text"] = true
L["The sentence structure portion of each combat log entry."] = true
L["Highlight crits"] = true
L["Critical damage values are highlighted (makes them brighter)."] = true
L["Highlight pet damage"] = true
L["Your pet damage values are highlighted (makes them brighter)."] = true
L["Spell names"] = true
L["Spell/skill names.\n\nOnly used when not displaying spell links."] = true
L["Brackets"] = true
L["The square brackets surrounding unit names."] = true
L["Extra values"] = true
L["Extra values in the combat log (resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill damage, as well as energy types and miss types)."] = true
L["Abbreviate extra values"] = true
L["Resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values will be abbreviated to just their first letter. Does not affect energy types or miss types."] = true
L["Show \"you\" instead of your name"] = true
L["When selected, uses You and Your to indicate the player, rather than your name."] = true
L["You"] = true
L["Your pet"] = true
L["Your target"] = true
L["Friends"] = true
L["Hostile units"] = true
L["Hostile players"] = true
L["Neutral"] = true
L["Unknown"] = true
L["Abbreviate unit names"] = true
L["When selected, all unit names will be abbreviated to just the first letter of every word."] = true
L["Crit flag (*)"] = true
L["Friendly damage"] = true
L["Friendly spell damage"] = true
L["Hostile damage"] = true
L["Hostile spell damage"] = true
L["Energizes and extra attacks"] = true
L["Friendly heals"] = true
L["Hostile heals"] = true
L["Experience gained"] = true
L["Loot"] = true
L["Honor gained"] = true
L["Reputation gained"] = true
L["Skill changed"] = true
L["Disabled"] = true
L["Profile modified, rebooting"] = true
L["Spell Name Whitelist"] = true
L["Enter a comma-separated list of spell names. Only events whose spells are on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = true
L["Spell Name Blacklist"] = true
L["Enter a comma-separated list of spell names. Only events whose spells are not on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = true
L["Open chat window"] = true
L["Opens the selected chat window if it is closed."] = true
L["Chat %d"] = true
L["If you can't find the chat window, it may have become docked next to another chat window."] = true
L["Open chat windows"] = true
L["Opens all chat windows being used by HitsMode5 filters, if any are currently closed."] = true
L["If you can't find one or more chat windows, they may have become docked next to another chat window."] = true
L["HitsMode5 is replaying combat..."] = true
L["Replay combat"] = true
L["Clears all chat windows being used by filters, and replays all saved combat back to them. This is useful if you've changed your filter settings and want to see recent combat using the new settings.\n\nCombat is saved by the WoW client (not by HitsMode5). You can change the combat retention time above."] = true
L["Replay is already running. Please wait for it to finish."] = true
L["|cfffbd284Left-Click|r to start an Instant Replay."] = true
L["|cfffbd284Shift-Click|r to replay %d lines of recent combat."] = true
L["|cfffbd284Right-Click|r to open configuration."] = true
L["Include level"] = true
L["When selected, a unit's level will be displayed next to their name. This will also work for replayed combat logs."] = true
L["HitsMode5 is currently replaying combat."] = true
L["|cfffbd284Shift-Click|r to cancel."] = true
L["Cancel replay"] = true
L["Cancels a currently running combat replay."] = true
L["Custom display format"] = true
L["Custom"] = true
L["Uses a tag system to let you create your own combat log formats. Any tags not used in a given event will be removed. Tags are case sensitive. Extra whitespace will be removed from the string before it is displayed.\n\n|cffffff20$source|r - The source unit name.\n|cffffff20$dest|r - The destination unit name.\n|cffffff20$spell|r - The spell, skill, or enchant used.\n|cffffff20$action|r - The action text for the event (hit, missed, etc.)\n|cffffff20$for|r - The word \"for\" in some events; automatically removed if Include For is turned off.\n|cffffff20$amount|r - The numeric amount associated with the event, if any.\n|cffffff20$otherspell|r - The source's spell interacts with the destination's spell in certain events. $otherspell is the destination's spell.\n|cffffff20$extra|r - All extra information about the event, such as resists, overkill, miss type, failure reason, etc. Not shown if Include Extra Values is off.\n|cffffff20$amtsep|r - Replaced with a dash (-) if the $amount tag is also being filled with a number."] = true
L["Unable to load Replay module; requires Options module"] = true
L["Instant Replay"] = true
L["HitsMode5: Instant Replay"] = true
L["Amount to replay"] = true
L["Execute"] = true
L["Reset options"] = true
L["Replay running..."] = true
L["Mouse wheel scrolls. Ctrl scrolls faster. Shift scrolls to top or bottom."] = true
L["Or"] = true
L["And"] = true
L["Unit comparison mode"] = true
L["Determines how your unit filters will be used.\n\n|cffffff20Or:|r\n  Events where the source filters OR the destination filters match your selections will be shown.\n\n|cffffff20And:|r\n  Events where the source filters AND the destination filters match your selections will be shown."] = true
L["Show events with no source unit"] = true
L["When selected, events with no source unit will be shown in this filter."] = true
L["Show events with no dest unit"] = true
L["When selected, events with no destination unit will be shown in this filter."] = true
L["You entered a name that already exists. To copy a filter, enter a unique filter name."] = true
L["You have no filters. Creating a default filter."] = true
L["Default"] = true
L["Deletes this filter."] = true
L["Begins the Instant Replay. Combat is replayed into a dedicated window using the settings below."] = true
L["Determines the percentage of recent combat to replay. Replaying thousands of lines can take a long time. Since WoW doesn't reliably save combat based on time, we simply let you choose what percentage of saved combat to replay."] = true
L["Resets the Instant Replay options to their defaults. Your Instant Replay settings are saved until you log out or reload your UI. This button allows you to reset them quickly."] = true















-- Combat log patterns
L["COMBATLOG_FORMAT_STANDARD_A"] = "$source $spell $action $dest $for $amount $otherspell $extra"
L["COMBATLOG_FORMAT_STANDARD_NUMBERS_FIRST_A"] = "$amount $amtsep $source $spell $action $dest $otherspell $extra"
L["COMBATLOG_FORMAT_NUMBERS_ONLY_A"] = "$amount"

-- Extra values
L[" (%d vulnerability damage)"] = true
L[" (%d v)"] = true
L[" (%d resisted)"] = true
L[" (%d r)"] = true
L[" (%d blocked)"] = true
L[" (%d b)"] = true
L[" (%d absorbed)"] = true
L[" (%d a)"] = true
L[" (glancing)"] = true
L[" (g)"] = true
L[" (crushing)"] = true
L[" (c)"] = true
L[" (%d overheal)"] = true
L[" (%d overkill)"] = true
L[" (%d o)"] = true

-- Action overrides
L["for"] = true
L["crit"] = true
L["crit healed"] = true
L["faded"] = true
L["lost a stack"] = true
L["crit damaged"] = true

-- Special events
L["gain reputation %s %s"] = true
L["lose reputation %s %s"] = true
L["loot %s"] = true
L["create %s"] = true
L[" skill has increased to %s"] = true
L["share of the loot is %s"] = true
L["gain experience %s"] = true
L[" rested"] = true

-- Chat messages; this must match to your locale's game exactly
L["CHAT_MSG_COMBAT_XP_GAIN_1"] = ".* gain (%d+).*"
L["CHAT_MSG_COMBAT_XP_GAIN_2"] = "experience%. %(%+(%d+) exp Rested bonus"

-- Combat Events
L["ALL"] = "|cff20ff20All on/off|r"
L["ENVIRONMENTAL_DAMAGE"] = "Environmental damage"
L["SWING_DAMAGE"] = "Melee damage"
L["SWING_MISSED"] = "Melee missed"
L["RANGE_DAMAGE"] = "Range damage"
L["RANGE_MISSED"] = "Range missed"
L["SPELL_CAST_START"] = "Spell cast start"
L["SPELL_CAST_SUCCESS"] = "Spell cast success"
L["SPELL_CAST_FAILED"] = "Spell cast failure"
L["SPELL_MISSED"] = "Spell missed"
L["SPELL_DAMAGE"] = "Spell damage"
L["SPELL_HEAL"] = "Heal"
L["SPELL_PERIODIC_HEAL"] = "Periodic heal"
L["SPELL_ENERGIZE"] = "Energize"
L["SPELL_PERIODIC_ENERGIZE"] = "Periodic energize"
L["SPELL_DRAIN"] = "Drain"
L["SPELL_PERIODIC_DRAIN"] = "Periodic drain"
L["SPELL_LEECH"] = "Leech" 
L["SPELL_PERIODIC_LEECH"] = "Periodic leech"
L["SPELL_INTERRUPT"] = "Spell interrupted"
L["SPELL_EXTRA_ATTACKS"] = "Extra attacks"
L["SPELL_AURA_APPLIED"] = "Aura applied"
L["SPELL_AURA_APPLIED_DOSE"] = "Aura applied (dose)"
L["SPELL_AURA_REMOVED"] = "Aura removed"
L["SPELL_AURA_REMOVED_DOSE"] = "Aura removed (dose)"
L["SPELL_DISPEL"] = "Spell dispelled"
L["SPELL_DISPEL_FAILED"] = "Dispel failed"
L["SPELL_STOLEN"] = "Spell stolen"
L["ENCHANT_APPLIED"] = "Enchant applied"
L["ENCHANT_REMOVED"] = "Enchant removed"
L["SPELL_PERIODIC_DAMAGE"] = "Periodic spell damage"
L["SPELL_PERIODIC_MISSED"] = "Periodic spell missed"
L["DAMAGE_SHIELD"] = "Damage shield"
L["DAMAGE_SHIELD_MISSED"] = "Damage shield missed"
L["DAMAGE_SPLIT"] = "Damage split"
L["SPELL_INSTAKILL"] = "Instant kill"
L["PARTY_KILL"] = "Party kill"
L["UNIT_DIED"] = "Unit died"
L["UNIT_DESTROYED"] = "Unit destroyed"
L["UNIT_DISSIPATES"] = "Unit dissipated"
L["SPELL_BUILDING_HEAL"] = "Building healed"
L["SPELL_BUILDING_DAMAGE"] = "Building damaged"
L["SPELL_SUMMON"] = "Summon"
L["SPELL_CREATE"] = "Create"
L["SPELL_RESURRECT"] = "Resurrect"
L["SPELL_AURA_REFRESH"] = "Aura refreshed"
L["SPELL_AURA_BROKEN"] = "CC break (melee)"
L["SPELL_AURA_BROKEN_SPELL"] = "CC break (spell)"

-- Special Events
L["CHAT_MSG_COMBAT_XP_GAIN"] = "Experienced gained"
L["CHAT_MSG_LOOT"] = "Item looted"
L["CHAT_MSG_COMBAT_FACTION_CHANGE"] = "Reputation changed"
L["CHAT_MSG_COMBAT_HONOR_GAIN"] = "Honor gained"
L["CHAT_MSG_MONEY"] = "Money looted"
L["CHAT_MSG_SKILL"] = "Skill changed"

-- Unit Flags
L["COMBATLOG_OBJECT_AFFILIATION_MINE"] = "Mine"
L["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = "Party"
L["COMBATLOG_OBJECT_AFFILIATION_RAID"] = "Raid"
L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = "Outsider"
L["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = "Friendly"
L["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = "Neutral"
L["COMBATLOG_OBJECT_REACTION_HOSTILE"] = "Hostile"
L["COMBATLOG_OBJECT_CONTROL_PLAYER"] = "Player"
L["COMBATLOG_OBJECT_CONTROL_NPC"] = "NPC"
L["COMBATLOG_OBJECT_TYPE_PLAYER"] = "Player"
L["COMBATLOG_OBJECT_TYPE_NPC"] = "NPC"
L["COMBATLOG_OBJECT_TYPE_PET"] = "Pet"
L["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = "Guardian"
L["COMBATLOG_OBJECT_TYPE_OBJECT"] = "Object"
L["COMBATLOG_OBJECT_TARGET"] = "Target"
L["COMBATLOG_OBJECT_FOCUS"] = "Focus"
L["COMBATLOG_OBJECT_MAINTANK"] = "Main Tank"
L["COMBATLOG_OBJECT_MAINASSIST"] = "Main Assist"
L["COMBATLOG_OBJECT_RAIDTARGET1"] = "Raid Target 1"
L["COMBATLOG_OBJECT_RAIDTARGET2"] = "Raid Target 2"
L["COMBATLOG_OBJECT_RAIDTARGET3"] = "Raid Target 3"
L["COMBATLOG_OBJECT_RAIDTARGET4"] = "Raid Target 4"
L["COMBATLOG_OBJECT_RAIDTARGET5"] = "Raid Target 5"
L["COMBATLOG_OBJECT_RAIDTARGET6"] = "Raid Target 6"
L["COMBATLOG_OBJECT_RAIDTARGET7"] = "Raid Target 7"
L["COMBATLOG_OBJECT_RAIDTARGET8"] = "Raid Target 8"
L["COMBATLOG_OBJECT_NONE"] = "None"

-- Value Flags
L["FLAG_CRITS"] = "Crits (*)"
L["FLAG_HEALS"] = "Heals (+)"
L["FLAG_PET_DAMAGE"] = "Pet damage (~)"
L["FLAG_ENERGIZES"] = "Energizes (+)"
L["FLAG_EXP"] = "Experience (+)"
L["FLAG_HONOR"] = "Honor (+)"
L["FLAG_REP"] = "Reputation (+/-)"







-- Help articles
L["help_question_1"] = "Sample question 1"
L["help_answer_1"] = "Sample answer 1"







