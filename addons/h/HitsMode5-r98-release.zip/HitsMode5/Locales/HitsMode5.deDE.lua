local L = LibStub("AceLocale-3.0"):NewLocale("HitsMode5", "deDE")
if not L then return end
L["Abbreviate extra values"] = "Weitere Werte abkürzen" -- Needs review
L["Abbreviate unit names"] = "Einheiten-Namen abkürzen" -- Needs review
L["Adds a flag to special value types in the combat log."] = "Fügt eine Markierung zu speziellen Wert-Typen im Kampf-Log hinzu." -- Needs review
L["Affiliation"] = "Zugehörigkeit"
L["ALL"] = "|cff20ff20Alle ein/aus|r"
L["Amount to replay"] = "Umfang zum Wiederholen" -- Needs review
L["And"] = "Und" -- Needs review
L["Are you sure you want to delete this filter?"] = "Bist du sicher dass du diesen Filter löschen möchtest?"
L["Begins the Instant Replay. Combat is replayed into a dedicated window using the settings below."] = "Startet die Sofort-Wiederholung. Das Kampfgeschehen wird mit den unten genannten Einstellungen in ein zugehöriges Fenster erneut eingespielt." -- Needs review
L["Brackets"] = "Klammern"
L["Brackets around names"] = "Klammern um Namen"
L[" (c)"] = "(s)" -- Needs review
L["Cancel replay"] = "Wiederholung abbrechen"
L["Cancels a currently running combat replay."] = "Bricht eine momentan laufende Wiederholung ab." -- Needs review
L["|cfffbd284Left-Click|r to start an Instant Replay."] = "|cfffbd284Linksklick|r um eine Sofort-Wiederholung zu starten."
L["|cfffbd284Right-Click|r to open configuration."] = "|cfffbd284Rechtsklick|r um das Konfigurationsmenü zu öffnen."
L["|cfffbd284Shift-Click|r to cancel."] = "|cfffbd284Shift-Klick|r um abzubrechen."
L["|cfffbd284Shift-Click|r to replay %d lines of recent combat."] = "|cfffbd284Shift und Linksklick|r um %d Zeilen des neusten Kampfes zu wiederholen." -- Needs review
L["Chat %d"] = true
L["CHAT_MSG_COMBAT_FACTION_CHANGE"] = "Ruf geändert"
L["CHAT_MSG_COMBAT_HONOR_GAIN"] = "Ehre erhalten" -- Needs review
L["CHAT_MSG_COMBAT_XP_GAIN"] = "Erfahrung erhalten"
L["CHAT_MSG_COMBAT_XP_GAIN_1"] = "* erhält (%d+).*" -- Needs review
L["CHAT_MSG_COMBAT_XP_GAIN_2"] = "experience%. %(%+(%d+) exp Erholungs-Bonus" -- Needs review
L["CHAT_MSG_LOOT"] = "Gegenstand erhalten"
L["CHAT_MSG_MONEY"] = "Gold erhalten"
L["CHAT_MSG_SKILL"] = "Fähigkeit verändert" -- Needs review
L["Chat window"] = "Sprachfenster"
L["Chat Window"] = "Sprachfenster"
L["Chat window reminder"] = "Sprachfenster Erinnerung"
L["Choose the filter to be deleted."] = "Wähle den Filter, der gelöscht werden soll." -- Needs review
L["Choose which destination unit types to display events for."] = "Wähle für welchen Typ von Ziel-Einheiten Ereignisse angezeigt werden sollen." -- Needs review
L["Choose which source unit types to display events for."] = "Wähle für welchen Typ von Quell-Einheiten Ereignisse angezeigt werden sollen." -- Needs review
L[ [=[Clears all chat windows being used by filters, and replays all saved combat back to them. This is useful if you've changed your filter settings and want to see recent combat using the new settings.

Combat is saved by the WoW client (not by HitsMode5). You can change the combat retention time above.]=] ] = [=[Leert alle Chat-Fenster, die von Filtern benutzt werden, und spielt den gespeicherten Kampf-Verlauf wieder in sie ein. Dies ist nützlich, wenn Filter-Einstellungen verändert wurden, und man das jüngste Kampf-Geschehen mit den neuen Einstellungen sehen will.

Der Kampf wird vom WoW Client gespeichert (nicht von HitsMode5). Die Speicherdauer des Kampfes kann man oben ändern.]=] -- Needs review
L["Click to open the HitsMode5 knowledge base, which is filled with frequently asked questions."] = "Klicken, um die HitsMode5 Wissensdatenbank zu öffnen, in welcher die \"Häufig gefragten Fragen\" zu finden sind." -- Needs review
L["Color by class"] = "Nach Klasse färben"
L["Color by spell school"] = "Nach Zauberschule färben"
L["Colors"] = "Farben"
L["Combat Events"] = "Kampfereignisse"
-- L["COMBATLOG_FORMAT_NUMBERS_ONLY_A"] = ""
-- L["COMBATLOG_FORMAT_STANDARD_A"] = ""
-- L["COMBATLOG_FORMAT_STANDARD_NUMBERS_FIRST_A"] = ""
L["Combat log messages with a value below this setting will not be displayed. This can be useful to prevent spam from very small events."] = "Kampf-Log Nachrichten mit einem Wert unterhalb dieser Einstellung werden nicht angezeigt. Dies kann Spam von sehr kleinen Ereignissen verhindern." -- Needs review
L["COMBATLOG_OBJECT_AFFILIATION_MINE"] = "Selbst"
L["COMBATLOG_OBJECT_AFFILIATION_OUTSIDER"] = "Außenseiter"
L["COMBATLOG_OBJECT_AFFILIATION_PARTY"] = "Gruppe"
L["COMBATLOG_OBJECT_AFFILIATION_RAID"] = "Schlachtzug"
L["COMBATLOG_OBJECT_CONTROL_NPC"] = "NPC"
L["COMBATLOG_OBJECT_CONTROL_PLAYER"] = "Spieler"
L["COMBATLOG_OBJECT_FOCUS"] = "Fokus"
L["COMBATLOG_OBJECT_MAINASSIST"] = "Hauptassistent" -- Needs review
L["COMBATLOG_OBJECT_MAINTANK"] = "Haupttank" -- Needs review
L["COMBATLOG_OBJECT_NONE"] = "Keiner"
L["COMBATLOG_OBJECT_RAIDTARGET1"] = "Schlachtzugziel 1"
L["COMBATLOG_OBJECT_RAIDTARGET2"] = "Schlachtzugziel 2"
L["COMBATLOG_OBJECT_RAIDTARGET3"] = "Schlachtzugziel 3"
L["COMBATLOG_OBJECT_RAIDTARGET4"] = "Schlachtzugziel 4"
L["COMBATLOG_OBJECT_RAIDTARGET5"] = "Schlachtzugziel 5"
L["COMBATLOG_OBJECT_RAIDTARGET6"] = "Schlachtzugziel 6"
L["COMBATLOG_OBJECT_RAIDTARGET7"] = "Schlachtzugziel 7"
L["COMBATLOG_OBJECT_RAIDTARGET8"] = "Schlachtzugziel 8"
L["COMBATLOG_OBJECT_REACTION_FRIENDLY"] = "Freundlich"
L["COMBATLOG_OBJECT_REACTION_HOSTILE"] = "Feindlich"
L["COMBATLOG_OBJECT_REACTION_NEUTRAL"] = "Neutral"
L["COMBATLOG_OBJECT_TARGET"] = "Ziel"
L["COMBATLOG_OBJECT_TYPE_GUARDIAN"] = "Wächter"
L["COMBATLOG_OBJECT_TYPE_NPC"] = "NPC"
L["COMBATLOG_OBJECT_TYPE_OBJECT"] = "Objekt"
L["COMBATLOG_OBJECT_TYPE_PET"] = "Tier"
L["COMBATLOG_OBJECT_TYPE_PLAYER"] = "Spieler"
L["Combat log retention time"] = "Kampf-Log Speicher-Dauer" -- Needs review
L["Combat separator"] = "Kampfseparator " -- Needs review
L["Configure all the colors used throughout the HitsMode5 combat log. Colors are global for all filters."] = "Konfiguriere alle Farben, die vom HitsMode5 Kampf-Log benutzt werden. Diese Farben gelten global bei allen Filtern." -- Needs review
L["Copy filter"] = "Filter kopieren"
L["Create a copy of this filter by entering a new name and clicking Okay."] = "Erstelle eine Kopie dieses Filters, indem du einen neuen Namen eingibts und OK klickst." -- Needs review
L["Create filter"] = "Filter erstellen"
L["create %s"] = "erstellen %s"
L["crit"] = "Kritisch"
L["crit damaged"] = "traf (kritisch)" -- Needs review
L["Crit flag (*)"] = "Crit-Markierung (*)" -- Needs review
L["crit healed"] = "heilte (kritisch)" -- Needs review
L["Critical damage values are highlighted (makes them brighter)."] = "Kritische Schadenswerte werden hervorgehoben (macht sie heller)." -- Needs review
L[" (crushing)"] = "(schmetternd)" -- Needs review
L["Currently |cff20ff20enabled|r."] = "Momentan |cff20ff20aktiviert|r."
L["Currently |cffff2020disabled|r."] = "Momentan |cffff2020ausgeschaltet|r."
L["Custom"] = "Benutzerdefiniert" -- Needs review
L["Custom display format"] = "Benutzerdefiniertes Anzeigeformat"
L[" (%d a)"] = "(%d a)"
L[" (%d absorbed)"] = "(%d absorbiert)"
L["DAMAGE_SHIELD"] = "Schadens Schild"
L["DAMAGE_SHIELD_MISSED"] = "Schadensschild vermisst" -- Needs review
L["DAMAGE_SPLIT"] = "Schaden aufgeteilt"
L[" (%d b)"] = "(%d g)"
L[" (%d blocked)"] = "(%d geblockt)"
L["Default"] = "Standard" -- Needs review
L[ [=[Defines whether resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values should be shown after regular damage. Also shows the energy type for energizes, and the miss type for misses.

Not available for the |cffffff20%s|r display mode.]=] ] = [=[Regelt, ob widerstandene, absorbierte, geblockte, gestreifte, schmetternde, verletzende, überheilende, und über-Tod Werte nach dem regulären Schaden angezeigt werden sollen. Zeigt auch die Energie-Art für Energetisierung, und die Art des Verfehlens.

Nicht verfügbar für den |cffffff20%s|r Anzeigemodus.]=] -- Needs review
L["Delete filter"] = "Filter löschen"
L["Deletes the chosen filter."] = "Den gewählten Filter löschen"
L["Deletes this filter."] = "Löscht diesen Filter."
L["Destination Units"] = "Ziel Einheiten" -- Needs review
L[ [=[Determines how long your WoW client will retain combat log data (in seconds). This affects HitsMode5's ability to replay the combat log. Longer retention times will cause your client to use more of your RAM, but will allow you to evaluate a longer period of combat after it has happened. The default setting is 5 minutes (300 seconds). Note that this is a WoW setting, not a HitsMode5 setting. This WoW setting is normally hidden from users.

WoW currently imposes a limit of 315 seconds for this value.]=] ] = [=[Bestimmt, wie lange dein WoW Client die Kampflogdaten speichert (in Sekunden). Dies beeinflusst die Fähigkeit von HitsMode5, das Kampflog zu wiederholen. Längere Rückhaltezeiten benutzen mehr Speicher, aber erlauben dir auch im Nachhinein eine längere Zeitspanne des Kampfes zu untersuchen. Die Standart-Einstellung beträgt 5 Minuten (300 Sekunden). Beachte, dass dies eine WoW-Einstellung ist und nicht von HitsMode5. Diese WoW-Einstellung ist normalerweise für Benutzer versteckt.

WoW verhängt momentan ein Limit von 315 Sekunden für diesen Wert.]=] -- Needs review
L["Determines how spells and skills will be displayed in the combat log. Abbreviated spells will show just the first letter of every word in the spell."] = "Bestimmt, wie Zauber und Fähigkeiten im Kampf-Log dargestellt werden. Abgekürzte Zaubernamen zeigen nur den ersten Buchstaben jedes Wortes des Zaubernamens." -- Needs review
L[ [=[Determines how your unit filters will be used.

|cffffff20Or:|r
  Events where the source filters OR the destination filters match your selections will be shown.

|cffffff20And:|r
  Events where the source filters AND the destination filters match your selections will be shown.]=] ] = [=[Bestimmt, wie deine Einheiten-Filter benutzt werden.

|cffffff20Oder:|r
  Zeigt Ereignisse, deren Quell-Filter ODER Ziel-Filter den gewählten Einstellungen entsprechen.

|cffffff20Und:|r
    Zeigt Ereignisse, deren Quell-Filter UND  Ziel-Filter den gewählten Einstellungen entsprechen.]=] -- Needs review
L["Determines the percentage of recent combat to replay. Replaying thousands of lines can take a long time. Since WoW doesn't reliably save combat based on time, we simply let you choose what percentage of saved combat to replay."] = "Bestimmt, wieviel Prozent des letzten Kampfgeschehens wiederholt wird. Tausende Zeilen zu wiederholen kann lange dauern. Da WoW den Verlauf nicht verlässlich zeit-bezogen speichert, lassen wir dich einfach wählen, wieviel Prozent des gespeicherten Kampfes wiederholt werden soll." -- Needs review
L["Determines which combat log events will be shown. This list is restricted to Blizzard combat log events only."] = "Bestimmt, welche Ereignisse des Kampf-Logs angezeigt werden. Diese Liste ist auf Ereignisse aus Blizzards Kampf-Log beschränkt." -- Needs review
L["Disabled"] = "Deaktiviert"
L["Display"] = "Anzeige"
L["Display mode"] = "Anzeigemodus" -- Needs review
L[" (%d o)"] = "(%d ü)"
L[" (%d overheal)"] = "(%d Überheilung)" -- Needs review
L[" (%d overkill)"] = "(%d über Tod)" -- Needs review
L[" (%d r)"] = "(%d w)"
L[" (%d resisted)"] = "(%d widerstanden)"
L[" (%d v)"] = "(%d V)" -- Needs review
L[" (%d vulnerability damage)"] = "(%d Verwundbarkeit Schaden)" -- Needs review
L["Enable filter"] = "Filter aktivieren"
L["Enable HitsMode5"] = "Aktiviere HitsMode5"
L["Enables or disables HitsMode5 entirely. When disabled, HitsMode5 will not respond to any combat log events. You will still be able to enable HitsMode5 and replay the combat log to see what happened."] = "Schaltet HitsMode5 komplett ein oder aus. Wenn es ausgeschaltet ist, reagiert HitsMode5 auf kein Ereignis im Kampf-Log. Du kannst HitsMode5 aber weiterhin aktivieren und das Kampflog wiederholen, um zu sehen was passiert ist." -- Needs review
L["Enables the filter."] = "Aktiviert den Filter" -- Needs review
L["ENCHANT_APPLIED"] = "Verzauberung angewendet"
L["ENCHANT_REMOVED"] = "Verzauberung aufgehoben"
L["Energizes and extra attacks"] = "Energetisierungen und Zusatzattacken" -- Needs review
L["Enter a comma-separated list of names. Only events with names that are not on this list will be shown. Names are not case sensitive."] = "Gib eine Liste von Namen ein, die per Komma getrennt sind. Es werden nur Ereignisse angezeigt mit Namen, die nicht in der Liste enthalten sind. Groß-/Kleinschreibung wird nicht unterschieden." -- Needs review
L["Enter a comma-separated list of names. Only events with names that are on this list will be shown. Names are not case sensitive."] = "Gib eine Liste von Namen ein, die per Komma getrennt sind. Es werden nur Ereignisse angezeigt mit Namen, die in der Liste enthalten sind. Groß-/Kleinschreibung wird nicht unterschieden." -- Needs review
L["Enter a comma-separated list of spell names. Only events whose spells are not on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = "Gib eine Liste von Namen von Zaubern ein, die per Komma getrennt sind. Es werden nur Ereignisse angezeigt, deren Zauber-Name nicht in der Liste enthalten sind. Ereignisse, die keine Zauber betreffen, werden nicht beeinflusst. Groß-/Kleinschreibung wird nicht unterschieden." -- Needs review
L["Enter a comma-separated list of spell names. Only events whose spells are on this list will be shown. Events not involving a spell will not be affected. Names are not case sensitive."] = "Gib eine Liste von Namen von Zaubern ein, die per Komma getrennt sind. Es werden nur Ereignisse angezeigt, deren Zauber-Name in der Liste enthalten sind. Ereignisse, die keine Zauber betreffen, werden nicht beeinflusst. Groß-/Kleinschreibung wird nicht unterschieden." -- Needs review
L[ [=[Enter text to be placed in the chat window when you leave combat. This helps break up the combat log from fight to fight.

Does not affect replayed combat logs.

To disable this feature, empty this text box and click Okay.]=] ] = [=[Gebe einen Text einm der im Chat-Fenster angezeigt wird, wenn du einen Kampf verlässt. Dies hilft, im Kampflog zwischen zwei Kämpfen zu unterscheiden.

Beeinträchtigt keine wiederholten Kampf-Logs.

Um diese Funktion abzuschalten, leere die Text-Box und drücke auf OK.]=] -- Needs review
L["Enter the name for the filter."] = "Trage den Namen für den Filter ein." -- Needs review
L["Enter the name for the new filter."] = "Trage den Namen für den neuen Filter ein." -- Needs review
L["ENVIRONMENTAL_DAMAGE"] = "Umgebungsschaden"
L["Execute"] = "Führe aus" -- Needs review
L["Experience gained"] = "Erfahrung erhalten."
L["Extra values"] = "Zusatzwerte" -- Needs review
L["Extra values in the combat log (resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill damage, as well as energy types and miss types)."] = "Weitere Werte im Kampf-Log (widerstanden, absorbiert, geblockt, gestreift, schmetternd, verletzend, überheilend, und über-Tod Schaden sowie Energie- und Verfehlens-Typen)." -- Needs review
L["faded"] = "verschwand" -- Needs review
L["Filters"] = "Filter"
L[ [=[Filters are the basic building block of the HitsMode5 combat log. Each filter lets you choose which events to show, which chat window to show them in, and how you'd like them to look.

You can create an unlimited number of filters, all running at once.

You can also create filters and turn them off, saving them for a special occasion when you need to look something up.]=] ] = [=[Filter sind der Grundbaustein des HitsMode5 Kampf-Log. Mit jedem Filter kann man wählen, welche Ereignisse in welchem Chat-Fenster auf welche Weise angezeigt werden sollen.

Man kann unbegrenzt viele Filter erzeugen und gleichzeitig laufen lassen.

Man kann auch Filter erzeugen und ausschalten, bis man in speziellen Situationen irgendwas nachschauen muss.]=] -- Needs review
L["FLAG_CRITS"] = "Kritische Treffer (*)"
L["FLAG_ENERGIZES"] = "Energetisierung (+)" -- Needs review
L["FLAG_EXP"] = "Erfahrung (+)"
L["FLAG_HEALS"] = "Heilung (+)"
L["FLAG_HONOR"] = "Ehre (+)"
L["FLAG_PET_DAMAGE"] = "Begleiter Schaden (~)"
L["FLAG_REP"] = "Ruf (+/-)"
L["Flag special values"] = "Markiere spezielle Werte " -- Needs review
L["for"] = "für"
L["Friendly damage"] = "Schaden von Freunden" -- Needs review
L["Friendly heals"] = "Heilung von Freunden" -- Needs review
L["Friendly spell damage"] = "Freundlicher Zauber Schaden" -- Needs review
L["Friends"] = "Freunde" -- Needs review
L[" (g)"] = "(st)" -- Needs review
L["gain experience %s"] = "erhalte Erfahrung %s" -- Needs review
L["gain reputation %s %s"] = "erhalte Ruf %s %s" -- Needs review
L["General"] = "Generell" -- Needs review
L["General Options"] = "Allgemeine Optionen"
L["Get help with HitsMode5."] = "Hilfe zu HitsMode5 bekommen." -- Needs review
L[" (glancing)"] = "(streifend)" -- Needs review
L["Help"] = "Hilfe"
L["Help with HitsMode5"] = "Hilfe für HitsMode5"
L["Highlight crits"] = "Kritische Treffer hervorheben" -- Needs review
L["Highlight pet damage"] = "Begleiterschaden hervorheben"
L["HitsMode5: Instant Replay"] = "HitsMode5: Sofort-Wiederholung"
L["HitsMode5 is currently replaying combat."] = "HitsMode5 wiederholt im Moment den Kampf."
L["HitsMode5 is replaying combat..."] = "HitsMode5 spielt den Kampf wieder ein..." -- Needs review
L["Honor gained"] = "Ehre erhalten"
L["Hostile damage"] = "Feindlicher Schaden" -- Needs review
L["Hostile heals"] = "Feindliche Heilung" -- Needs review
L["Hostile players"] = "Feindliche Spieler" -- Needs review
L["Hostile spell damage"] = "Feindlicher Zauberschaden" -- Needs review
L["Hostile units"] = "Gegnerische Einheiten"
L["If you can't find one or more chat windows, they may have become docked next to another chat window."] = "Falls du einige Chat-Fenster nicht finden kannst, könnten sie neben ein anderes Chat-Fenster eingedockt worden sein." -- Needs review
L["If you can't find the chat window, it may have become docked next to another chat window."] = "Falls du das Chat-Fenster nicht finden kannst, könnte es neben ein anderes Chat-Fenster eingedockt worden sein." -- Needs review
L["Include extra values"] = "Extra Werte anzeigen"
L["Include level"] = "Level inkludieren"
L["Include raid icons"] = "Schlachtzugsymbole anzeigen"
L["Include rested experience"] = "Erholung anzeigen"
L["Include spell icons"] = "Zauberspruchsymbole anzeigen"
L["Includes the word \"for\" in most combat log output. This only applies to the |cffffff20%s|r display mode."] = "Fügt das Wort \"für\" zu den meisten Ausgaben des Kampf-Logs hinzu. Dies betrifft nur den |cffffff20%s|r Anzeigemodus. " -- Needs review
L["Include the word \"for\""] = "Das Wort \"für\" anzeigen"
L["Instant Replay"] = "Sofort-Wiederholung"
L["Link"] = true
L["Link (abbreviated)"] = "Link (abgekürzt)"
L["Loaded"] = "Geladen"
L["Loot"] = "Beute"
L["loot %s"] = "erbeute %s" -- Needs review
L["lose reputation %s %s"] = "verliere Ruf %s %s" -- Needs review
L["lost a stack"] = "verlor eine Aufladung" -- Needs review
L["Mouse wheel scrolls. Ctrl scrolls faster. Shift scrolls to top or bottom."] = "Mausrad scrollt. Strg scrollt schneller. Shift scrollt zum Anfang oder Ende." -- Needs review
L["Name Is"] = "Name ist"
L["Name Is Not"] = "Name ist nicht"
L["Neutral"] = true -- Needs review
L["None"] = "Keine"
L["Normal text"] = "Normaler Text"
L["Numbers only"] = "nur Zahlen"
L["Open chat window"] = "Chat-Fenster öffnen" -- Needs review
L["Open chat windows"] = "Chat-Fenster öffnen" -- Needs review
L["Opens all chat windows being used by HitsMode5 filters, if any are currently closed."] = "Öffnet alle Chat-Fenster, die von HitsMode5 Filtern benutzt werden, falls sie momentan geschlossen sind." -- Needs review
L["Opens the selected chat window if it is closed."] = "Öffnet das ausgewählte Chat-Fenster, falls es geschlossen ist." -- Needs review
L["Options governing how the combat log text is rendered to your chat frame."] = "Einstellungen darüber, wie der Text des Kampf-Logs ins Chat-Fenster gerendert wird." -- Needs review
L["Or"] = "Oder" -- Needs review
L["Ownership"] = "Besitz"
L["PARTY_KILL"] = "Gruppenkill" -- Needs review
L["Prints some text into all open chat windows, to remind you which is which."] = "Schreibt in jedes offene Chatfenster etwas Text, um dich zu erinnern, welches Fenster welches ist." -- Needs review
L["Profile modified, rebooting"] = "Profil modifiziert, startet neu."
L["RANGE_DAMAGE"] = "Fernkampfschaden" -- Needs review
L["RANGE_MISSED"] = "Fernkampf verfehlt" -- Needs review
L["Reaction"] = "Reaktion"
L["Rename filter"] = "Filter umbenennen"
L["Replay combat"] = "Kampf wiederholen" -- Needs review
L["Replay is already running. Please wait for it to finish."] = "Wiederholung läuft schon. Bitte das Ende abwarten." -- Needs review
L["Replay lines per frame"] = "Zeige Zeilen pro Bild" -- Needs review
L["Replay running..."] = "Wiederholung läuft..."
L["Reputation gained"] = "Ruf erhalten"
L["Reset options"] = "Einstellungen zurücksetzen"
L["Resets the Instant Replay options to their defaults. Your Instant Replay settings are saved until you log out or reload your UI. This button allows you to reset them quickly."] = "Setzt die Einstellungen der Sofort-Wiederholung zurück auf ihren Standard. Deine Einstellungen werden gespeichert, bis du dich ausloggst oder dein UI neu lädst. Dieser Knopf erlaubt es dir, sie schnell zurückzusetzen." -- Needs review
L["Resisted, absorbed, blocked, glancing, crushing, vulnerability, overheal, and overkill values will be abbreviated to just their first letter. Does not affect energy types or miss types."] = "Widerstandene, absorbierte, geblockte, gestreifte, schmetternde, verletzende, überheilende, und über-Tod Werte werden mit ihren ersten Buchstaben abgekürzt. Betrifft nicht die Energie- oder Verfehlens-Typen." -- Needs review
L[" rested"] = "erholt" -- Needs review
L["Select which chat window to use for this filter's combat log output. You cannot use chat window 2, which is the default Blizzard Combat Log."] = "Wähle, welches Chat-Fenster für die Ausgabe von diesem Filter des Kampf-Logs benutzt werden soll. Du kannst Chat-Fenster 2 nicht wählen, da es das Standart-Fenster für das Blizzard Kampf-Log ist." -- Needs review
L[ [=[Sets the display mode for this filter.

|cffffff20%s|r:
  [You] hit [Monster] for 12

|cffffff20%s|r:
  12 - [You] hit [Monster]

|cffffff20%s|r:
  12

|cffffff20%s|r:
  A custom format specified below.]=] ] = [=[Regelt den Anzeigemodus für diesen Filter.

|cffffff20%s|r:
  [Du] triffst [Monster] für 12

|cffffff20%s|r:
  12 - [Du] triffst [Monster]

|cffffff20%s|r:
  12

|cffffff20%s|r:
  Ein benutzerdefiniertes Format, wie unten angegeben.
]=] -- Needs review
L["share of the loot is %s"] = "Anteil an der Beute ist %s" -- Needs review
L["Show events with no dest unit"] = "Zeige Ereignisse ohne Ziel-Einheit" -- Needs review
L["Show events with no source unit"] = "Zeige Ereignisse ohne Quell-Einheit" -- Needs review
L["Show \"you\" instead of your name"] = "Zeigt \"Du\" anstelle deines Namens"
L["Skill changed"] = "Fähigkeit verändert" -- Needs review
L[" skill has increased to %s"] = "Fähigkeit hat sich verbessert auf %s" -- Needs review
L["Source Units"] = "Quell Einheiten" -- Needs review
L["Special Cases"] = "Spezialfälle"
L["Special Events"] = "Spezialevents"
L[ [=[Special events are not part of the normal combat log, but you can still display these events with HitsMode5. They will only show when they happen to you (not others), and they will not respect any source or destination unit filters.

They will not show for replayed combat logs.]=] ] = [=[Spezial-Ereignisse sind nicht Teil des normalen Kampf-Logs, aber man kann sie trotzdem mit HitsMode5 anzeigen. Sie werden nur angezeigt, wenn sie dir passieren (nicht anderen), und sie werden keine Filter für Quell- oder Ziel-Einheiten berücksichtigen

Sie werden nicht in wiederholten Kampf-Logs erscheinen.]=] -- Needs review
L["SPELL_AURA_APPLIED"] = "Aura aufgetragen" -- Needs review
L["SPELL_AURA_APPLIED_DOSE"] = "Weitere Aura aufgetragen" -- Needs review
L["SPELL_AURA_BROKEN"] = "Aura gebrochen (Nahkampf)" -- Needs review
L["SPELL_AURA_BROKEN_SPELL"] = "Aura gebrochen (Zauber)" -- Needs review
L["SPELL_AURA_REFRESH"] = "Aura erneuert"
L["SPELL_AURA_REMOVED"] = "Aura entfernt"
L["SPELL_AURA_REMOVED_DOSE"] = "Aura aufgehoben" -- Needs review
L["SPELL_BUILDING_DAMAGE"] = "Gebäudeschaden"
L["SPELL_BUILDING_HEAL"] = "Gebäudeheilung"
L["SPELL_CAST_FAILED"] = "Zauberwirkung fehlgeschlagen"
L["SPELL_CAST_START"] = "Beginn Zauberwirkung"
L["SPELL_CAST_SUCCESS"] = "Zauberwirkung erfolgreich"
L["SPELL_CREATE"] = "Erschaffen"
L["SPELL_DAMAGE"] = "Zauberschaden"
L["SPELL_DISPEL"] = "Zauberspruch aufgehoben"
L["SPELL_DISPEL_FAILED"] = "Aufheben fehlgeschlagen"
L["SPELL_DRAIN"] = "Entziehen" -- Needs review
L["SPELL_ENERGIZE"] = "Energetisieren" -- Needs review
L["SPELL_EXTRA_ATTACKS"] = "Zusätzliche Attacken"
L["SPELL_HEAL"] = "Heilung"
L["SPELL_INSTAKILL"] = "Sofortiger Tod"
L["SPELL_INTERRUPT"] = "Zauberspruch unterbrochen"
L["SPELL_LEECH"] = "Saugen" -- Needs review
L["SPELL_MISSED"] = "Zauberspruch verfehlt"
L["Spell Name Blacklist"] = "Zauber-Name: schwarze Liste" -- Needs review
L["Spell names"] = "Zaubernamen"
L["Spell Name Whitelist"] = "Zauber-Name: weiße Liste" -- Needs review
L["SPELL_PERIODIC_DAMAGE"] = "Periodischer Zauberschaden"
L["SPELL_PERIODIC_DRAIN"] = "Periodisches Entziehen" -- Needs review
L["SPELL_PERIODIC_ENERGIZE"] = "Periodisches Energetisieren" -- Needs review
L["SPELL_PERIODIC_HEAL"] = "Periodische Heilung"
L["SPELL_PERIODIC_LEECH"] = "Periodisches Saugen"
L["SPELL_PERIODIC_MISSED"] = "Periodischer Zauber verfehlt"
L["SPELL_RESURRECT"] = "Wiederbelebt"
L["Spells"] = "Zauber"
L["Spell Schools"] = "Zauber Arten"
L[ [=[Spell/skill names.

Only used when not displaying spell links.]=] ] = [=[Zauber/Fähigkeits-Namen.

Werden nur benutzt, wenn keine Verknüpfung zum Zauber dargestellt wird.]=] -- Needs review
L["SPELL_STOLEN"] = "Zauberspruch gestohlen"
L["SPELL_SUMMON"] = "Beschwören"
L["Standard"] = "Normal"
L["Standard (numbers first)"] = "Normal (Zahlen zuerst)"
L["SWING_DAMAGE"] = "Nahkampfschaden"
L["SWING_MISSED"] = "verfehlt"
L["Text"] = true
L["Text (abbreviated)"] = "Text (verkürzt)"
L["Text Layout"] = true
L["These are optional. Select \"None\" to exclude all special cases."] = "Diese sind optional. Wähle \"Keine\" um alle Spezialfälle auszuschließen." -- Needs review
L["The sentence structure portion of each combat log entry."] = "Der Teil Satz-Struktur von jedem Kampf-Log-Eintrag." -- Needs review
L["The square brackets surrounding unit names."] = "Eckige Klammern umgeben Einheiten-Namen."
L["This is chat window %d"] = "Dies ist Chat-Fenster %d"
L["Unable to load Blizzard Combat Log. HitsMode5 cannot be enabled. (Reason: %s)"] = "Blizzard Kampf-Log kann nicht geladen werden. HitsMode5 kann nicht eingeschaltet werden. (Grund: %s)" -- Needs review
L["Unable to load Replay module; requires Options module"] = "Kann Wiederholungs-Modul nicht laden; benötigt Optionen-Modul" -- Needs review
L["Unit comparison mode"] = "Einheiten Vergleich Modus" -- Needs review
L["UNIT_DESTROYED"] = "Einheit zerstört"
L["UNIT_DIED"] = "Einheit stirbt"
L["UNIT_DISSIPATES"] = "Einheit löste sich auf" -- Needs review
L["Unit Names"] = "Einheiten Namen"
L["Unit Type"] = "Einheitentyp"
L["Unknown"] = "Unbekannt"
L[ [=[Uses a tag system to let you create your own combat log formats. Any tags not used in a given event will be removed. Tags are case sensitive. Extra whitespace will be removed from the string before it is displayed.

|cffffff20$source|r - The source unit name.
|cffffff20$dest|r - The destination unit name.
|cffffff20$spell|r - The spell, skill, or enchant used.
|cffffff20$action|r - The action text for the event (hit, missed, etc.)
|cffffff20$for|r - The word "for" in some events; automatically removed if Include For is turned off.
|cffffff20$amount|r - The numeric amount associated with the event, if any.
|cffffff20$otherspell|r - The source's spell interacts with the destination's spell in certain events. $otherspell is the destination's spell.
|cffffff20$extra|r - All extra information about the event, such as resists, overkill, miss type, failure reason, etc. Not shown if Include Extra Values is off.
|cffffff20$amtsep|r - Replaced with a dash (-) if the $amount tag is also being filled with a number.]=] ] = [=[Benutzt ein Schlagwort-System, damit du deine eigenen Kampf-Log-Formate erzeugen kannst. Alle Schlagworte, die nicht bei einem Ereignis benutzt werden, werden entfernt. Schlagworte beachten die Groß-/Kleinschreibung. Zusätzliche Leerzeichen werden entfernt, bevor der Text angezeigt wird.

|cffffff20$source|r - Der Name der Quell-Einheit.
|cffffff20$dest|r - Der Name der Ziel-Einheit.
|cffffff20$spell|r - Der benutzte Zauber, bzw. Fähigkeit.
|cffffff20$action|r - Der Aktionstext des Ereignisses (traf, verfehlte, usw.)
|cffffff20$for|r - Das Wort "für" in manchen Ereignissen; wird automatisch entfernt, falls die Option "Für mit anzeigen" ausgeschaltet ist.
|cffffff20$amount|r - Der mit dem Ereignis verbundene numerische Wert, falls vorhanden.
|cffffff20$otherspell|r - Bei bestimmten Ereignissen interagiert der Zauber der Quelle mit einem Zauber des Ziels. $otherspell ist der Zauber des Ziels.
|cffffff20$extra|r - Alle Zusatzinformationen des Ereignisses, wie z.B. widerstandene Schäden, Schäden über Tod, Verfehls-Typen, Gründe für Fehlschläge, usw. Wird nicht angezeigt, falls die Option "Zusätzliche Werte anzeigen" ausgeschaltet ist.
|cffffff20$amtsep|r - Wird durch ein Minus (-) ersetzt, falls das $amount Schlagwort auch mit einer Nummer befüllt wird.]=] -- Needs review
L["Value threshold"] = "Schwellwert" -- Needs review
L["When HitsMode5 replays your combat log, it replays a certain number of lines per frame. This prevents your client from locking up for an extended period of time while the combat log is replayed. You may wish to adjust this setting to a higher number if you have a very fast computer, need to replay a long combat log (particularly in a raid), and don't mind a little lag while it happens. The default Blizzard Combat Log replays one line per frame."] = "Wenn HitsMode5 das Kampf-Log wiederholt, gibt es eine bestimmte Anzahl an Zeilen pro Bild wieder. Dies verhindert, das dein Client sich einige Zeit aufhängt, während das Kampf-Log ausgegeben wird. Du könntest diesen Wert erhöhen wollen, falls du einen sehr schnellen Computer hast, ein langes Kampflog wiedergeben musst (meistens in einem Raid), und dir ein kleiner Lag nichts ausmacht. Das normale Blizzard Kampf-Log gibt 1 Zeile pro Bild aus." -- Needs review
L["When selected, all unit names will be abbreviated to just the first letter of every word."] = "Wenn aktiviert, werden alle Einheiten-Namen abgekürzt. (Nur der erste Buchstabe von jedem Wort)" -- Needs review
L["When selected, a unit's level will be displayed next to their name. This will also work for replayed combat logs."] = "Falls gewählt, wird die Stufe einer Einheit neben ihrem Namen angezeigt. Funktioniert auch in wiederholten Kampf-Logs." -- Needs review
L["When selected, events with no destination unit will be shown in this filter."] = "Falls aktiviert, werden Ereignisse ohne Ziel-Einheit in diesem Filter angezeigt." -- Needs review
L["When selected, events with no source unit will be shown in this filter."] = "Falls aktiviert, werden Ereignisse ohne Quell-Einheit in diesem Filter angezeigt." -- Needs review
L["When selected, raid icons will be shown next to unit names (if applicable). This will also work for replayed combat logs."] = "Falls gewählt, werden Raid-Zeichen neben den Einheitennamen ausgegeben (falls passend). Funktioniert auch in wiederholten Kampf-Logs." -- Needs review
L["When selected, spell damage values will be colorized based on the spell school. For hybrid spell schools, a priority system is used to choose the color."] = "Falls gewählt, werden die Werte von Zauberschäden in der Farbe der Zauberart eingefärbt. Für hybride Zauberarten wird ein Prioritäten-System benutzt, um die Farbe zu wählen." -- Needs review
L[ [=[When selected, spell icons will be shown in the combat log. You can choose to show icons only (no text), by turning this on and selecting "None" for display mode above.

Disable this feature if you encounter graphical corruption in your chat window.]=] ] = [=[Falls gewählt, werden Zauber-Icons im Kampf-Log angezeigt. Man kann wählen, dass nur Icons (kein Text) angezeigt wird, indem dies eingeschaltet wird und oben "Keine" für den Anzeige-Modus ausgewählt wird.

Schalte diese Funktion aus, wenn Grafik-Störungen in deinem Chat-Fenster auftauchen.]=] -- Needs review
L[ [=[When selected, square brackets will be placed around all unit names, for example:

  [You] hit [Monster] for 16]=] ] = [=[Falls gewählt, werden eckige Klammern um alle Einheiten-Namen angezeigt, zum Beispiel:

 [Du] triffst [Monster] für 16 Schaden.]=] -- Needs review
L[ [=[When selected, unit names will be colorized by their class (when their class is available). Replayed combat logs may not include this feature if you recently reloaded your UI. WoW does not return class information for all units in the game.

Disable this feature to use the default color for various unit types.]=] ] = [=[Falls gewählt, werden Einheiten-Namen ihrer Klasse entsprechend eingefärbt (wenn Ihre Klasse bekannt ist). Wiederholte Kampf-Logs könnten dies nicht anzeigen, falls kürzlich das Benutzerinterface neu geladen wurde. WoW zeigt diese Klassen-Info nicht bei allen Einheiten im Spiel.

Deaktiviere diese Funktion, um für verschiedene Einheiten-Typen die Standart-Farbe zu benutzen.]=] -- Needs review
L["When selected, uses You and Your to indicate the player, rather than your name."] = "Wenn aktiviert, wird nur Du oder Dein angezeigt, anstelle deines Namens."
L["When showing experience gain, separately show the amount of experience that was rested."] = "Wenn Erfahrung gewonnen wird, zeige zusätzlich den Teil der Erfahrung, der durch den Erholt-Bonus gewährt wurde." -- Needs review
L["You"] = "Du"
L["You entered a name that already exists. To copy a filter, enter a unique filter name."] = "Der eingegebene Name existiert bereits. Zum Kopieren bitte einen einzigartigen Filter-Namen eingeben." -- Needs review
L["You have no filters. Creating a default filter."] = "Du hast keine Filter. Erzeuge einen Standard-Filter." -- Needs review
L["You must choose at least one item from this category."] = "Du musst mindestens einen Punkt aus dieser Kategorie wählen." -- Needs review
L["Your pet"] = "Dein Begleiter"
L["Your pet damage values are highlighted (makes them brighter)."] = "Der Schaden deines Begleiters wird hervorgehoben (macht ihn heller)." -- Needs review
L["Your target"] = "Dein Ziel" -- Needs review
