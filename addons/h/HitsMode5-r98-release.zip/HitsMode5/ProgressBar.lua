local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5")


-- [[ Frame Scripts ]]--------------------------------------------------------------------------------------------------------

function HitsMode5:ProgressBar_OnUpdate(bar, elapsed)
	if not bar.progressing then return end
	if bar.updateFunction then bar.updateFunction(bar, elapsed, bar.value, bar.maxValue) end

	local barFlash = _G["HitsMode5ProgressBarFlash"]

	if bar.flash then
		local alpha = 0
		if barFlash then
			alpha = barFlash:GetAlpha() + CASTING_BAR_FLASH_STEP
		end
		if alpha < 1 then
			if barFlash then
				barFlash:SetAlpha(alpha)
			end
		else
			if barFlash then
				barFlash:SetAlpha(1.0)
			end
			bar.flash = nil
		end
	elseif bar.fadeOut then
		local alpha = bar:GetAlpha() - CASTING_BAR_ALPHA_STEP
		if alpha > 0 then
			bar:SetAlpha(alpha)
		else
			bar.fadeOut = nil
			bar:Hide()
			bar.progressing = nil
		end
	end
end



-- [[ API ]] -----------------------------------------------------------------------------------------------------------------

function HitsMode5:ProgressBar_Start(maxValue, updateFunction)
	local selfName = "HitsMode5ProgressBar"
	local barSpark = _G[selfName.."Spark"]
	local barText = _G[selfName.."Text"]
	local barFlash = _G[selfName.."Flash"]
	local barBorder = _G[selfName.."Border"]
	
	local bar = _G[selfName]

	bar:SetStatusBarColor(1.0, 0.7, 0.0)
	if barSpark then barSpark:Show() end
	if barFlash then barFlash:Hide() end
	bar:SetMinMaxValues(0, maxValue)
	bar:SetValue(0)
	if barText then barText:SetText(L["HitsMode5 is replaying combat..."]) end
	bar:SetAlpha(1.0)
	bar.fadeOut = nil
	bar.flash = nil
	bar.value = 0
	bar.maxValue = maxValue
	bar:SetFrameStrata("FULLSCREEN_DIALOG")
	bar:Show()
	bar.progressing = true
	bar.updateFunction = updateFunction
	self:ProgressBar_Update(0)
end


function HitsMode5:ProgressBar_Update(value)
	local selfName = "HitsMode5ProgressBar"
	local barSpark = _G[selfName.."Spark"]
	local bar = _G[selfName]

	bar:SetValue(value)
	bar.value = value
	if barSpark then
		local sparkPosition = (bar.value / bar.maxValue) * bar:GetWidth()
		barSpark:SetPoint("CENTER", bar, "LEFT", sparkPosition, 2)
	end
end


function HitsMode5:ProgressBar_End()
	local selfName = "HitsMode5ProgressBar"
	local barSpark = _G[selfName.."Spark"]
	local barText = _G[selfName.."Text"]
	local barFlash = _G[selfName.."Flash"]
	local barBorder = _G[selfName.."Border"]
	
	local bar = _G[selfName]
	
	bar:SetStatusBarColor(0.0, 1.0, 0.0)
	if barSpark then barSpark:Hide() end
	if barFlash then
		barFlash:SetAlpha(0.0)
		barFlash:Show()
	end
	bar.flash = true
	bar.fadeOut = true
	bar.progressing = true
	bar.updateFunction = nil
end


function HitsMode5:ProgressBar_Cancel()
	local selfName = "HitsMode5ProgressBar"
	local barSpark = _G[selfName.."Spark"]
	local barText = _G[selfName.."Text"]
	local barFlash = _G[selfName.."Flash"]
	local barBorder = _G[selfName.."Border"]
	
	local bar = _G[selfName]
	
	bar:SetStatusBarColor(1.0, 0.0, 0.0)
	if barSpark then barSpark:Hide() end
	bar.flash = false
	bar.fadeOut = true
	bar.progressing = true
	bar.updateFunction = nil
end

