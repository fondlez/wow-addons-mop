local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5")


-- Locals
local DISPLAYMODE_STANDARD = 1
local DISPLAYMODE_STANDARD_NUMBERS_FIRST = 2
local DISPLAYMODE_NUMBERS_ONLY = 3
local DISPLAYMODE_CUSTOM = 4

local SPELLDISPLAYMODE_TEXT = 1
local SPELLDISPLAYMODE_ABBREVIATED_TEXT = 2
local SPELLDISPLAYMODE_LINK = 3
local SPELLDISPLAYMODE_ABBREVIATED_LINK = 4
local SPELLDISPLAYMODE_NONE = 5

local FLAG_CRITS = 1
local FLAG_HEALS = 2
local FLAG_PET_DAMAGE = 3
local FLAG_ENERGIZES = 4
local FLAG_EXP = 5
local FLAG_HONOR = 6
local FLAG_REP = 7

local UNITCOMPARISONMODE_OR = 1
local UNITCOMPARISONMODE_AND = 2


--[[ INSTANT REPLAY FILTER DEFAULTS ]]----------------------------------------------------------------------------------------------

HitsMode5.modules.replay.filterDefaults = {
	logPercent = 1,
	enabled = true,--
	unitComparisonMode = UNITCOMPARISONMODE_OR,
	showMissingSource = true,
	showMissingDest = true,
	display = {
		chatWindow = 7,--
		valueThreshold = 0,--
		displayMode = DISPLAYMODE_STANDARD,--
		includeFor = true,--
		includeRestedExperience = true,--
		includeExtraValues = true,--
		abbreviateExtraValues = false,--
		combatSeparator = "~~~~~",
		customFormat = L["COMBATLOG_FORMAT_STANDARD_A"],
		flags = {
			["FLAG_CRITS"] = true,--
			["FLAG_HEALS"] = true,--
			["FLAG_PET_DAMAGE"] = true,--
			["FLAG_ENERGIZES"] = true,--
			["FLAG_EXP"] = true,--
			["FLAG_HONOR"] = true,--
			["FLAG_REP"] = true,--
		},
		highlightCrits = true,--
		highlightPet = true,--
		nameYou = true,--
		nameBrackets = true,--
		nameAbbreviate = false,--
		nameColorByClass = true,--
		nameShowRaidIcons = false,--
		nameShowLevel = false,-- but commented out
		spellDisplayMode = SPELLDISPLAYMODE_LINK,--
		spellShowIcons = false,--
		spellColorBySchool = true,--
		spellNameWhiteList = "",--
		spellNameBlackList = "",--
	},
	events = {
  ["ENVIRONMENTAL_DAMAGE"] = true,
  ["SWING_DAMAGE"] = true,
  ["SWING_MISSED"] = true,
  ["RANGE_DAMAGE"] = true,
  ["RANGE_MISSED"] = true,
  --["SPELL_CAST_START"] = true,
  --["SPELL_CAST_SUCCESS"] = true,
  --["SPELL_CAST_FAILED"] = true,
  ["SPELL_MISSED"] = true,
  ["SPELL_DAMAGE"] = true,
  ["SPELL_HEAL"] = true,
  ["SPELL_ENERGIZE"] = true,
  ["SPELL_DRAIN"] = true,
  ["SPELL_LEECH"] = true,
  ["SPELL_INSTAKILL"] = true,
  ["SPELL_INTERRUPT"] = true,
  ["SPELL_EXTRA_ATTACKS"] = true,
  --["SPELL_DURABILITY_DAMAGE"] = true,
  --["SPELL_DURABILITY_DAMAGE_ALL"] = true,
  ["SPELL_AURA_APPLIED"] = true,
  ["SPELL_AURA_APPLIED_DOSE"] = true,
  ["SPELL_AURA_REMOVED"] = true,
  ["SPELL_AURA_REMOVED_DOSE"] = true,
  ["SPELL_DISPEL"] = true,
  ["SPELL_STOLEN"] = true,
  ["ENCHANT_APPLIED"] = true,
  ["ENCHANT_REMOVED"] = true,
  ["SPELL_PERIODIC_MISSED"] = true,
  ["SPELL_PERIODIC_DAMAGE"] = true,
  ["SPELL_PERIODIC_HEAL"] = true,
  ["SPELL_PERIODIC_ENERGIZE"] = true,
  ["SPELL_PERIODIC_DRAIN"] = true,
  ["SPELL_PERIODIC_LEECH"] = true,
  ["SPELL_DISPEL_FAILED"] = true,
  ["DAMAGE_SHIELD"] = true,
  ["DAMAGE_SHIELD_MISSED"] = true,
  ["DAMAGE_SPLIT"] = true,
  ["PARTY_KILL"] = true,
  ["UNIT_DIED"] = true,
  ["UNIT_DESTROYED"] = true,
  ["UNIT_DISSIPATES"] = true,
  -- Blizzard Combat Log doesn't handle events below
		["SPELL_BUILDING_HEAL"] = true,
		["SPELL_BUILDING_DAMAGE"] = true,
		["SPELL_SUMMON"] = true,
		["SPELL_CREATE"] = true,
		["SPELL_RESURRECT"] = true,
		--["SPELL_AURA_REFRESH"] = true,
		["SPELL_AURA_BROKEN"] = true,
		["SPELL_AURA_BROKEN_SPELL"] = true,
	},
	specialEvents = {
		["CHAT_MSG_COMBAT_XP_GAIN"] = true,
		["CHAT_MSG_LOOT"] = true,
		["CHAT_MSG_COMBAT_FACTION_CHANGE"] = true,
		["CHAT_MSG_COMBAT_HONOR_GAIN"] = true,
		["CHAT_MSG_MONEY"] = true,
		["CHAT_MSG_SKILL"] = true,
	},
	sourceFlags = {
		[COMBATLOG_OBJECT_AFFILIATION_MINE] = true,
		[COMBATLOG_OBJECT_AFFILIATION_PARTY] = true,
		[COMBATLOG_OBJECT_AFFILIATION_RAID] = true,
		[COMBATLOG_OBJECT_AFFILIATION_OUTSIDER] = true,
		[COMBATLOG_OBJECT_REACTION_FRIENDLY] = true,
		[COMBATLOG_OBJECT_REACTION_NEUTRAL] = true,
		[COMBATLOG_OBJECT_REACTION_HOSTILE] = true,
		[COMBATLOG_OBJECT_CONTROL_PLAYER] = true,
		[COMBATLOG_OBJECT_CONTROL_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PLAYER] = true,
		[COMBATLOG_OBJECT_TYPE_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PET] = true,
		[COMBATLOG_OBJECT_TYPE_GUARDIAN] = true,
		[COMBATLOG_OBJECT_TYPE_OBJECT] = true
	},
	destFlags = {
		[COMBATLOG_OBJECT_AFFILIATION_MINE] = true,
		[COMBATLOG_OBJECT_AFFILIATION_PARTY] = true,
		[COMBATLOG_OBJECT_AFFILIATION_RAID] = true,
		[COMBATLOG_OBJECT_AFFILIATION_OUTSIDER] = true,
		[COMBATLOG_OBJECT_REACTION_FRIENDLY] = true,
		[COMBATLOG_OBJECT_REACTION_NEUTRAL] = true,
		[COMBATLOG_OBJECT_REACTION_HOSTILE] = true,
		[COMBATLOG_OBJECT_CONTROL_PLAYER] = true,
		[COMBATLOG_OBJECT_CONTROL_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PLAYER] = true,
		[COMBATLOG_OBJECT_TYPE_NPC] = true,
		[COMBATLOG_OBJECT_TYPE_PET] = true,
		[COMBATLOG_OBJECT_TYPE_GUARDIAN] = true,
		[COMBATLOG_OBJECT_TYPE_OBJECT] = true
	},
	sourceWhiteList = "",
	sourceBlackList = "",
	destWhiteList = "",
	destBlackList = ""
}
