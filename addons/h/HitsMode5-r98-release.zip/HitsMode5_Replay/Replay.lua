local L = LibStub("AceLocale-3.0"):GetLocale("HitsMode5", false)
local HitsMode5 = HitsMode5
local mod = HitsMode5:NewModule("Replay", "AceConsole-3.0")
local AceConfig = LibStub("AceConfig-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")



local function copyTable(t, lookup_table)
 local copy = {}
 for i, v in pairs(t) do
  if type(v) ~= "table" then
   copy[i] = v
  else
   lookup_table = lookup_table or {}
   lookup_table[t] = copy
   if lookup_table[v] then
    copy[i] = lookup_table[v] -- We already copied this table, reuse the copy
   else
    copy[i] = copyTable(v, lookup_table) -- Not yet copied, copy it
   end
  end
 end
 return copy
end


local function copyDefaults(to, from)
 for k, v in pairs(from) do
  if type(v) == "table" then
   copyDefaults(to[k], v)
  else
   to[k] = v
  end
 end
end



local function removeOptions(t)
 for k, v in pairs(t) do
  if type(v) == "table" then
			if v.includeInReplay == false then
				t[k] = nil
				v["includeInReplay"] = nil
			else
				removeOptions(t[k], v)
			end
  else
  end
 end
end


function mod:OnInitialize()
	-- Make sure Options module is loaded
	if not HitsMode5.modules.options.loaded then
		LoadAddOn("HitsMode5_Options")
		if not HitsMode5.modules.options.loaded then
			self:Print(L["Unable to load Replay module; requires Options module"])
			return
		end
	end
	
	-- Create the Instant Replay filter
	HitsMode5.modules.replay.filter = HitsMode5.Filter:new()
	HitsMode5.modules.replay.filter.db = copyTable(HitsMode5.modules.replay.filterDefaults)
	HitsMode5.modules.replay.filter.name = L["Instant Replay"]
	HitsMode5.modules.replay.filter:UpdateFlags()
	HitsMode5.modules.replay.filter:UpdateWhiteBlackLists()
	local db = HitsMode5.modules.replay.filter.db
	
	-- Setup the options
	local options = copyTable(HitsMode5.modules.replay.filter:GetOptions())
	options.display.args.head.name = L["General Options"]
	
	-- Remove options that don't apply to Instant Replay
	removeOptions(options)
	
	options.start = {
		order = 1,
		type = "execute",
		name = L["Execute"],
		desc = L["Begins the Instant Replay. Combat is replayed into a dedicated window using the settings below."],
		func = function()
			if _G["HitsMode5ProgressBar"].progressing or HitsMode5.replaying then
				self:Print(L["Replay is already running. Please wait for it to finish."])
			else
				HitsMode5.modules.replay.filter:UpdateFlags()
				HitsMode5.modules.replay.filter:UpdateWhiteBlackLists()
				AceConfigDialog:Close("HitsMode5_Replay")
				self:CreateReplayFrame()
				HitsMode5.replaying = true
				HitsMode5.modules.replay.scrollFrame:Clear()
				HitsMode5.modules.replay.filter.chatFrameOverride = HitsMode5.modules.replay.scrollFrame
				local count = floor(CombatLogGetNumEntries(true) * db.logPercent)
				local start = 1
				if db.logPercent < 1 then start = CombatLogGetNumEntries(true) - count end
				CombatLogSetCurrentEntry(start, true)
				HitsMode5.modules.replay.filterTable = { HitsMode5.modules.replay.filter }
				HitsMode5:ProgressBar_Start(count, self.ReplayUpdate)
			end
			
		end,
	}
	
	options.logPercent = {
		order = 2,
		type = "range",
		name = L["Amount to replay"],
		desc = L["Determines the percentage of recent combat to replay. Replaying thousands of lines can take a long time. Since WoW doesn't reliably save combat based on time, we simply let you choose what percentage of saved combat to replay."],
		min = 0,
		max = 1,
		isPercent = true,
		get = function() return db.logPercent or 1 end,
		set = function(self, val) db.logPercent = val end,
	}
	
	options.reset = {
		order = 3,
		type = "execute",
		name = L["Reset options"],
		desc = L["Resets the Instant Replay options to their defaults. Your Instant Replay settings are saved until you log out or reload your UI. This button allows you to reset them quickly."],
		func = function()
			copyDefaults(HitsMode5.modules.replay.filter.db, HitsMode5.modules.replay.filterDefaults)
			HitsMode5.modules.replay.filter:UpdateFlags()
			HitsMode5.modules.replay.filter:UpdateWhiteBlackLists()
			LibStub("AceConfigRegistry-3.0"):NotifyChange("HitsMode5_Replay")
		end,
	}
	
	HitsMode5.modules.replay.options = {
		name = L["HitsMode5: Instant Replay"],
		handler = HitsMode5,
		type = "group",
		childGroups = "tab",
  args = options
 }
	
	-- Register the options table	
	AceConfig:RegisterOptionsTable("HitsMode5_Replay", HitsMode5.modules.replay.options)
	AceConfigDialog:SetDefaultSize("HitsMode5_Replay", 835, 550)
	
	-- Set us as loaded
	HitsMode5.modules.replay.loaded = true
end

	
function mod:OnEnable()
--[===[@debug@
	self:Print(L["Loaded"])
--@end-debug@]===]
end


function HitsMode5:OpenInstantReplay()
	AceConfigDialog:Open("HitsMode5_Replay")
end


function mod.ReplayUpdate(bar, elapsed, value, maxValue)
	if not bar.progressing then return end
	local valid = CombatLogGetCurrentEntry(true)
	
	-- Render a chunk of lines
	local total = 0
	while valid and total < HitsMode5.db.profile.replayLinesPerFrame do 
		HitsMode5:Render(true, HitsMode5.modules.replay.filterTable, CombatLogGetCurrentEntry(true))
		valid = CombatLogAdvanceEntry(1, true)
		total = total + 1
	end

	-- Update the progress bar
	HitsMode5:ProgressBar_Update(value + total)
	HitsMode5.modules.replay.replayFrame:SetStatusText(format("%d / %d (%d%%)", value + total, bar.maxValue, ((value + total) * 100 / bar.maxValue)))
	
	-- End replay if we're done
	if not valid then
		HitsMode5:ProgressBar_End()
		HitsMode5.modules.replay.replayFrame:SetStatusText(L["Mouse wheel scrolls. Ctrl scrolls faster. Shift scrolls to top or bottom."])
		HitsMode5:CleanupUnitCache()
		HitsMode5.replaying = false
	end
end


local strmatch = _G.string.match
local linkTypes = {
	item = true,
	enchant = true,
	spell = true,
	quest = true,
	-- player = true
}


function mod:CreateReplayFrame()
	local AceGUI, f, scrollframe

	--if not HitsMode5.modules.replay.replayFrame then
		AceGUI = LibStub("AceGUI-3.0")
		f = AceGUI:Create("Frame")
		f:SetCallback("OnClose", function(widget) AceGUI:Release(widget) end)
		f:SetTitle(L["HitsMode5: Instant Replay"])
		f:SetStatusText(L["Replay running..."])
		HitsMode5.modules.replay.replayFrame = f
	--else
		--f = HitsMode5.modules.replay.replayFrame
	--end
	f:Show()

	if not HitsMode5.modules.replay.scrollFrame then
		scrollframe = CreateFrame("ScrollingMessageFrame", nil, f.frame)
		scrollframe:SetPoint("TOPLEFT", f.frame,"TOPLEFT",17,-27)
		scrollframe:SetPoint("BOTTOMRIGHT", f.frame,"BOTTOMRIGHT",-17,40)
		scrollframe:SetMaxLines(100000)
		scrollframe:SetFontObject(ChatFontSmall)
		scrollframe:SetJustifyH("LEFT")
		scrollframe:SetFading(false)
		scrollframe:EnableMouseWheel(true)
		scrollframe:SetScript("OnHide", scrollframe.ScrollToBottom)
		scrollframe:SetScript("OnMouseWheel", function(frame, delta)
			if delta > 0 then
				if IsShiftKeyDown() then frame:ScrollToTop()
				elseif IsControlKeyDown() then for i = 1, 10 do frame:ScrollUp() end
				else for i = 1, 4 do frame:ScrollUp() end end
			elseif delta < 0 then
				if IsShiftKeyDown() then frame:ScrollToBottom()
				elseif IsControlKeyDown() then for i = 1, 10 do frame:ScrollDown() end
				else for i = 1, 4 do frame:ScrollDown() end end
			end
		end)
		scrollframe:SetScript("OnHyperlinkEnter", function(f, link)
			local t = strmatch(link, "^(.-):")
			if linkTypes[t] then
				ShowUIPanel(GameTooltip)
				GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink(link)
				GameTooltip:Show()
			end			
		end)
		scrollframe:SetScript("OnHyperlinkLeave", function(f, link)
			local t = strmatch(link, "^(.-):")
			if linkTypes[t] then
				HideUIPanel(GameTooltip)
			end
		end)
		scrollframe:Show()
		HitsMode5.modules.replay.scrollFrame = scrollframe
	end
end

