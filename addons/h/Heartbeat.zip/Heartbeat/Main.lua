-- The addon namespace.
local addon, ns = ...

local manager = ns.Manager:new()
local console = ns.Console:new(manager)

console:RegisterSlashCommands()
manager:Start()