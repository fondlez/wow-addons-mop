-- The addon namespace.
local addon, ns = ...

-- Define the Text class and put it in the addon namespace.
local Text = {}
local TextMetatable = { __index = Text }
ns.Text = Text

-- Constructor.
function Text:new(parent)
	local self = {} 
	setmetatable(self, TextMetatable)
		
	self.Parent = parent
	
	-- Create 4 digits.
	self.Digits = {}
	for i = 1, 4 do
		self.Digits[i] = parent:CreateTexture(nil, "ARTWORK")
		self.Digits[i]:SetTexture(ns.Config.texturePath)
		self.Digits[i]:SetHeight(ns.Config.textureHeight)
		self.Digits[i]:Hide()
	end
	
	-- Place digits in succession.
	self.Digits[1]:SetPoint("RIGHT", self.Digits[2], "LEFT")
	self.Digits[2]:SetPoint("RIGHT", self.Digits[3], "LEFT")		
    self.Digits[3]:SetPoint("RIGHT", self.Digits[4] ,"LEFT")

	return self
end

-- Rounds numbers to the nearest integer.
function Text:Round(number)
	return math.floor(number + 0.5)
end

-- Truncates a decimal number to a given precision.
function Text:Truncate(number, precision)
	local shift = 10 ^ precision
    return self:Round(number * shift) / shift
end

-- Formats as a percentage
function Text:Format(percentage)
	if percentage >= 1 then
		return self:Round(percentage).."%"
	elseif percentage > 0 then
		return self:Truncate(percentage, 1).."%"
	else
		return nil
	end
end

-- Sets the text color.
function Text:SetColor(color)
	for i = 1, 4 do
		self.Digits[i]:SetVertexColor(color[1], color[2], color[3])
	end
end

-- Hides all digits in the text.
function Text:Hide()
	for i = 1, 4 do
		self.Digits[i]:Hide()
	end
end

-- Translates the text so that it is centred at the parent frame centre.
function Text:Center(x, y)
	local width = 0
	for i = 1, 4 do
		if self.Digits[i]:IsVisible() then
			width = width + self.Digits[i]:GetWidth()
		end
	end

	self.Digits[4]:SetPoint("RIGHT", self.Parent, "CENTER", 0.5 * width + x, y)
end

-- Sets a digit to a given character.
function Text:SetDigit(digit, character)
	digit:SetWidth(ns.Config.textureCoordinates[character][2] - ns.Config.textureCoordinates[character][1])
	digit:SetTexCoord(ns.Config.textureCoordinates[character][1] / ns.Config.textureWidth,	ns.Config.textureCoordinates[character][2] / ns.Config.textureWidth, 0, 1)	
	digit:Show()
end

-- Displays a given text string.
function Text:SetText(text)
	self:Hide()
	if text then
		local reversedText = text:reverse()
		for i = 1, math.min(#reversedText, 4) do
			local character = reversedText:sub(i,i)
			self:SetDigit(self.Digits[5 - i], character)
		end
	end
end

-- Displays a percentage.
function Text:SetPercentage(percentage)
	local text = self:Format(percentage)
	self:SetText(text)
end