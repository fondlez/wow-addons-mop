-- The addon namespace.
local addon, ns = ...
local cfg = ns.Config

-- Define the Manager class and put it in the addon namespace.
local Manager = {}
local ManagerMetatable = { __index = Manager }
ns.Manager = Manager

-- Constructor.
function Manager:new()
	local self = {}
	setmetatable(self, ManagerMetatable)
	
	-- Initialize variables.
	self.PlayerName = UnitName("player")
	self.HealthMax = 1
	self.AccumulatedDamage = 0
	self.AccumulatedSpellDamage = 0
	self.AccumulatedHealing = 0

	-- Damage event amount indexes.
	self.DamageEvents = {}
	self.DamageEvents["SWING_DAMAGE"] = 12
	self.DamageEvents["ENVIRONMENTAL_DAMAGE"] = 13
	self.DamageEvents["RANGE_DAMAGE"] = 15
	self.DamageEvents["SPELL_DAMAGE"] = 15
	self.DamageEvents["SPELL_PERIODIC_DAMAGE"] = 15
	self.DamageEvents["SPELL_BUILDING_DAMAGE"] = 15

	-- Healing event amount indexes.
	self.HealingEvents = {}
	self.HealingEvents["SWING_HEAL"] = 12
	self.HealingEvents["ENVIRONMENTAL_HEAL"] = 13
	self.HealingEvents["RANGE_HEAL"] = 15
	self.HealingEvents["SPELL_HEAL"] = 15
	self.HealingEvents["SPELL_PERIODIC_HEAL"] = 15
	self.HealingEvents["SPELL_BUILDING_HEAL"] = 15

	-- The base frame.
	self.Frame = CreateFrame("Frame", nil, UIParent)
	self.Frame:SetWidth(100)
	self.Frame:SetHeight(100)
	self.Frame:SetFrameStrata(cfg.strata)
	self.Frame:EnableMouse(false)
	self.Frame:SetMovable(false)

	-- Dragging.
	self.Frame:RegisterForDrag("LeftButton")
	self.Frame:SetScript("OnDragStart", self.Frame.StartMoving)
	self.Frame:SetScript("OnDragStop", self.OnDragStop)
	self.DragBackground = self.Frame:CreateTexture(nil, "ARTWORK")
	self.DragBackground:SetTexture(1, 1, 1, 0.5)
	self.DragBackground:SetAllPoints(self.Frame)
	self.DragBackground:Hide()
	self.DragText = self.Frame:CreateFontString(nil, "OVERLAY")
    self.DragText:SetJustifyH("CENTER")
    self.DragText:SetPoint("CENTER", 0, 0)
    self.DragText:SetFont("Fonts\\FRIZQT__.TTF", 14, "OUTLINE")	
    self.DragText:SetTextColor(1, 1, 1, 1)
    self.DragText:SetText("Drag me!") 
	self.DragText:Hide()
		
	-- The damage and healing text.
	self.DamageText = ns.Text:new(self.Frame)
	self.HealingText = ns.Text:new(self.Frame)
	self.HealingText:SetColor(cfg.healingColor)
	
	-- Animation.
	self.Animation = self.Frame:CreateAnimationGroup()
	self.Animation:SetLooping("REPEAT")
	self.Animation:SetScript("OnLoop", function() self:Tick() end)

	local alpha = self.Animation:CreateAnimation("Alpha")
	alpha:SetDuration(cfg.updateInterval)
	alpha:SetSmoothing("IN")
	alpha:SetChange(-1)
	
	return self
end

-- Reloads everything that depends on the per character configuration.
function Manager:Reload()
	self.Frame:SetScale(HeartbeatConfig.scale)
	self.Frame:ClearAllPoints()
	self.Frame:SetPoint(HeartbeatConfig.anchor, HeartbeatConfig.x, HeartbeatConfig.y)
end

-- Handler that stops dragging and saves the position to the saved variables.
-- Note that self is the icon frame and not the icon class.
function Manager:OnDragStop()
	self:StopMovingOrSizing()
	HeartbeatConfig.anchor, _, _, HeartbeatConfig.x, HeartbeatConfig.y = self:GetPoint(1)
end

-- Shows damage text
function Manager:ShowDamage()
	local percentage = (self.AccumulatedDamage / self.HealthMax) * 100
	local fraction = self.AccumulatedSpellDamage / self.AccumulatedDamage
	self.DamageText:SetPercentage(percentage)
	self.DamageText:Center(cfg.spacingX, cfg.spacingY)
	self.DamageText:SetColor(cfg.damageColor(fraction))
end

-- Shows healing text
function Manager:ShowHealing()
	local percentage = (self.AccumulatedHealing / self.HealthMax) * 100
	self.HealingText:SetPercentage(percentage)
	self.HealingText:Center(-cfg.spacingX, -cfg.spacingY)
end

-- Tick function that shows the text.
function Manager:Tick()
	self.HealthMax = UnitHealthMax("player");
	
	if cfg.testMode then
		self.AccumulatedDamage = random(0, self.HealthMax)
		self.AccumulatedSpellDamage = random(0, self.AccumulatedDamage)
		self.AccumulatedHealing = random(0, self.HealthMax)
	end
	
	self:ShowDamage()
	self:ShowHealing()
	
	self.AccumulatedDamage = 0
	self.AccumulatedSpellDamage = 0
	self.AccumulatedHealing = 0
end

-- Set the default configuration if no previous configuration has been saved.
function Manager:LoadDefaults()
	if not HeartbeatConfig then
		HeartbeatConfig = {}
	end

	for k, v in pairs(cfg.Default) do
		if HeartbeatConfig[k] == nil then
			HeartbeatConfig[k] = v
		end
	end
	
	self:Reload()
end

-- Resets configuration settings.
function Manager:Reset()
	HeartbeatConfig = {}
	for k, v in pairs(cfg.Default) do
		HeartbeatConfig[k] = v
	end
	
	self:Reload()
end

-- Locks the frame.
function Manager:Lock()
	self.DragBackground:Hide()
	self.DragText:Hide()
	self.Frame:SetMovable(false)
	self.Frame:EnableMouse(false)
	self.Animation:Play()
end

-- Unlocks the frame for dragging.
function Manager:Unlock()
	self.DragBackground:Show()
	self.DragText:Show()
	self.Frame:SetMovable(true)
	self.Frame:EnableMouse(true)
	self.Animation:Stop()
end

-- Sets the scale.
function Manager:SetScale(scale)
	HeartbeatConfig.scale = scale
	self.Frame:SetScale(scale)
end

-- Sets whether or not overhealing should be included.
function Manager:SetIncludeOverhealing(value)
	HeartbeatConfig.includeOverhealing = value
end

-- Handles damage events.
function Manager:OnDamage(damage, school)
	self.AccumulatedDamage = self.AccumulatedDamage + damage
	if bit.band(school, 1) == 0 then -- 00000001 is the bit mask for physical.
		self.AccumulatedSpellDamage = self.AccumulatedSpellDamage + damage
	end
end

-- Handles healing events.
function Manager:OnHealing(healing, overhealing)
	self.AccumulatedHealing = self.AccumulatedHealing + healing
	if not HeartbeatConfig.includeOverhealing then
		self.AccumulatedHealing = self.AccumulatedHealing - overhealing
	end
end

-- Handler for the ADDON_LOADED event.
function Manager:ADDON_LOADED(...)
	local name = select(1, ...)
	if name == addon then
		self:LoadDefaults()
	end
end

-- Handler for the COMBAT_LOG_EVENT_UNFILTERED event.
function Manager:COMBAT_LOG_EVENT_UNFILTERED(...)
	local event = select(2, ...)
	local target = select(9, ...)
	if self.DamageEvents[event] and target == self.PlayerName then
		local damage = select(self.DamageEvents[event], ...) or 0
		local school = select(self.DamageEvents[event] + 2, ...) or 0
		self:OnDamage(damage, school)
	elseif self.HealingEvents[event] and target == self.PlayerName then
		local healing = select(self.HealingEvents[event], ...) or 0
		local overhealing = select(self.HealingEvents[event] + 1, ...) or 0
		self:OnHealing(healing, overhealing)
	end
end

-- Event handler.
function Manager:OnEvent(sender, event, ...)
	if event == "ADDON_LOADED" then
		self:ADDON_LOADED(...)
	end
	if event == "COMBAT_LOG_EVENT_UNFILTERED" then
		self:COMBAT_LOG_EVENT_UNFILTERED(...)
	end
end

-- Starts the manager.
function Manager:Start()
	self.Frame:RegisterEvent("ADDON_LOADED");
	self.Frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	self.Frame:SetScript("OnEvent", function(...) self:OnEvent(...) end);
	self.Animation:Play()
end