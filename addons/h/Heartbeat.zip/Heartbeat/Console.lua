-- The addon namespace.
local addon, ns = ...

-- Define the console class and put it in the addon namespace.
local Console = {}
local ConsoleMetatable = { __index = Console }
ns.Console = Console

-- Constructor.
function Console:new(manager)
	local self = {}
	setmetatable(self, ConsoleMetatable)
	
	self.Manager = manager
	
	return self
end

-- Utility function for writing to the chat window.
function Console.Write(text)
	print("|c00FF647CHeartbeat:|r "..text)
end

-- Slash command handler
function Console:SlashCommandHandler(msg, editbox)
	local command, rest = msg:match("^(%S*)%s*(.-)$");
	if command == "" or command == "help" then
		Console.Write("Usage: /heartbeat <command>")
		Console.Write("Commands:")
		Console.Write("help")
		Console.Write("reset")
		Console.Write("lock")
		Console.Write("unlock")
		Console.Write("scale <number>")
		Console.Write("includeOverhealing true/false")
	elseif command == "reset" then
		self.Manager:Reset()	
		Console.Write("Configuration reset")
	elseif command == "lock" then
		self.Manager:Lock()
		Console.Write("Frames locked")
	elseif command == "unlock" then
		self.Manager:Unlock()
		Console.Write("Frames unlocked")
	elseif command == "scale" then
		local scale = tonumber(rest)
		if scale then
			self.Manager:SetScale(scale)
			Console.Write("Scale set to "..scale)
		else
			Console.Write("Unable to parse scale: "..rest)
		end
	elseif command == "includeOverhealing" then
		if rest == "true" then
			self.Manager:SetIncludeOverhealing(true)
			Console.Write("Overhealing will be included.")
		elseif rest == "false" then
			self.Manager:SetIncludeOverhealing(false)
			Console.Write("Overhealing will be excluded.")
		else
			Console.Write("Unable to parse boolean value: "..rest)
		end
	else
		Console.Write("Unknown command: "..command)
	end
end

-- Register slash command handler.
function Console:RegisterSlashCommands()
	SLASH_HEARTBEAT1 = "/heartbeat"
	SlashCmdList["HEARTBEAT"] = function(...) self:SlashCommandHandler(...) end
end


