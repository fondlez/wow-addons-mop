-- The addon namespace.
local addon, ns = ...

-- Define the config and put it in the addon namespace.
local cfg = {}
ns.Config = cfg

-- Slash command settings. These are defaults and will only be taken into account the first time the addon loads for each character.
cfg.Default = {}
cfg.Default.anchor				= "CENTER"  -- Frame anchor. Possible values are: See above.
cfg.Default.x      				= 0         -- x-offset for the Shield Barrier icon.
cfg.Default.y					= -100      -- y-offset for the Shield Barrier icon.
cfg.Default.scale               = 1         -- The scale.
cfg.Default.includeOverhealing  = true      -- Indicates whether overhealing is included.

-- General settings. Requires that you reload the addon before they take effect.
cfg.strata              = "HIGH"	-- Frame strata.
cfg.updateInterval      = 1			-- Time (in seconds) between updates.
cfg.testMode			= false		-- Sets the addon in test mode. Will display random numbers.
cfg.spacingX            = 0	        -- The number of pixels to translate each number in the X direction.
cfg.spacingY            = 40        -- The number of pixels to translate each number in the Y direction.
cfg.healingColor        = {0, 1, 0}	-- The rgb color-values for healing text.

-- Function that returns a damage color based on the fraction of spell damage received.
cfg.damageColor			= function(fraction)
							  return { 1 - 0.5 * fraction, 0, fraction }
						  end

-- Font settings. Requires that you reload the addon before they take effect.
cfg.texturePath 		= "Interface\\AddOns\\Heartbeat\\Textures\\digits.tga" -- Path to the texture file.
cfg.textureWidth 		= 512													-- Width of the texture.
cfg.textureHeight 		= 64													-- Height of the texture.
cfg.textureCoordinates 	= {														-- Coordinate intervals for each of the digits.
	["0"] = {0, 45},
	["1"] = {49, 93},
	["2"] = {94, 138},
	["3"] = {139, 187},
	["4"] = {187, 234},
	["5"] = {234, 281},
	["6"] = {281, 328},
	["7"] = {329, 373},
	["8"] = {375, 422},
	["9"] = {422, 468},
	["."] = {468, 479},
	["%"] = {479, 511}
}