-- get the addon namespace
local addon, ns = ...

-- generate a holder for the config data
local cfg = CreateFrame("Frame")

local version, build, date = GetBuildInfo()
cfg.release = tonumber(string.sub(version,0,1))

-- print(release)
cfg.isize=32
cfg.scale=8
cfg.point = {"TOPLEFT",UIParent,"CENTER",0,-20}
cfg.border=10
cfg.hiderunes=true
cfg.dk_Shadowfrost=nil
cfg.textfont="Fonts\\FRIZQT__.TTF"

cfg.shapes={}
cfg.shapes={
[1]="Cat",
[2]="Tree",
--[3]="Travel",
--[4]="Aquatic",
[5]="Bear",
--[16]="Spirit Wolf",
[17]="Battle",
[18]="Defensive",
[19]="Berserker",
[22]="Metamorphosis",
--[27]="Flight",
[28]="Shadow",
[30]="Stealth",
[31]="Moonkin"
}
cfg.shape=nil
cfg.shapeid=GetShapeshiftFormID()

ns.cfg = cfg