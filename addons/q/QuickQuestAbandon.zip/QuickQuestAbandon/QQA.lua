local enabled = true
local f = CreateFrame("frame",nil)
f.d = 0

local function AddQueue()
	if (f.d + 1) <= 1 then
		f.d = f.d + 1
		enabled = false
		f:SetScript("OnUpdate",function(self,elapsed)
			f.d = f.d - elapsed
			if f.d < 0 then
				f:SetScript("OnUpdate",nil)
				enabled = true
				f.d = 0
			end
		end)
	else
		return
	end
end

hooksecurefunc("QuestLogTitleButton_OnClick", function(self,button)
	local questIndex = self:GetID();
	local questName = self:GetText();
	if ( IsModifiedClick() ) then
		if ( self.isHeader ) then
			return;
		end
		if enabled then
			AddQueue()
			if IsControlKeyDown() then
				QuestLog_SetSelection(questIndex)
				print("|cffffff00Quest abandoned: "..GetQuestLink(questIndex))		
				AbandonQuest();
				QuestLog_Update();
				QuestLog_SetSelection(questIndex);
			elseif IsAltKeyDown() then
				QuestLog_SetSelection(questIndex)
				if GetQuestLogPushable() then
					QuestLogPushQuest();
				end
			end
		end
	end
end)