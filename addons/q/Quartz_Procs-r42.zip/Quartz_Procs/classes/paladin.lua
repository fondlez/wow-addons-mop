local _, cClass = UnitClass("player")
if (cClass ~= "PALADIN") then return end

local Quartz3 = LibStub("AceAddon-3.0"):GetAddon("Quartz3")
if not Quartz3 then error("Quartz3 not found!"); return end

local QuartzProcs = Quartz3:GetModule("Procs")
if not QuartzProcs then return end

function QuartzProcs:returnProcList()
	local tmplist = { }
	
	if (GetSpellInfo(84963) ~= nil) then
		-- Inquisition
		tmplist[string.lower(GetSpellInfo(84963))] = { color={1,0.5,0}, name=GetSpellInfo(84963), }
	end
	
	if (GetSpellInfo(59578) ~= nil) then
		-- Art of War
		tmplist[string.lower(GetSpellInfo(59578))] = { color={1,0.5,0}, name=GetSpellInfo(59578), }
	end
	
	if (GetSpellInfo(54428) ~= nil) then
		-- Divine Plea
		tmplist[string.lower(GetSpellInfo(54428))] = { color={0,0,1}, name=GetSpellInfo(54428), }
	end
	
	if (GetSpellInfo(642) ~= nil) then
		-- Divine Shield
		tmplist[string.lower(GetSpellInfo(642))]   = { color={1,0.5,1}, name=GetSpellInfo(642), }
	end
	
	if (GetSpellInfo(498) ~= nil) then
		-- Divine Protection 244;164;96
		tmplist[string.lower(GetSpellInfo(498))]   = { color={0.97,0.65,0.38}, name=GetSpellInfo(498), }
	end
	
	
	-- Divine Sacrifice 238;173;14
	--[string.lower(GetSpellInfo(64205))] = { color={0.93,0.68,0.05}, name=GetSpellInfo(64205), },
	
	if (GetSpellInfo(54149) ~= nil) then	
		-- Infusion of Light
		tmplist[string.lower(GetSpellInfo(54149))] = { color={1,0.5,0}, name=GetSpellInfo(54149), }
	end
	
	if (GetSpellInfo(31884) ~= nil) then
		-- Avenging Wrath
		tmplist[string.lower(GetSpellInfo(31884))] = { color={1,0.5,0}, name=GetSpellInfo(31884), }
	end
	
	if (GetSpellInfo(31850) ~= nil) then
		-- Ardent Defender
		tmplist[string.lower(GetSpellInfo(31850))] = { color={1,0.5,0}, name=GetSpellInfo(31850), }
	end

	-- Sacred Shield (self)
	--["58597"] = {
		--name=GetSpellInfo(58597), color={0.93,0.98,0.51} --, spellid=58597,
	--},
	
	if (GetSpellInfo(2812) ~= nil) then
		-- Denounce
		tmplist[string.lower(GetSpellInfo(2812))] = { color={0.93,0.98,0.51}, name=GetSpellInfo(2812), }
	end
		
	tmplist["combatlog"] = { }
	
	-- Sacred Shield (target)
	--["53601"] = {
		--name=GetSpellInfo(53601) .. " (target)", color={0.73,0.55,0.55}, dur=30, cast=true,
	--},
	
	if (GetSpellInfo(25771) ~= nil) then
		-- Forbearance (debuff)
		tmplist["combatlog"]["25771"] = {
			name=GetSpellInfo(25771), color={1,0,0}, dur=120,
		}
	end
	
	return tmplist
end