local _, cClass = UnitClass("player")
if (cClass ~= "SHAMAN") then return end

local Quartz3 = LibStub("AceAddon-3.0"):GetAddon("Quartz3")
if not Quartz3 then error("Quartz3 not found!"); return end

local QuartzProcs = Quartz3:GetModule("Procs")
if not QuartzProcs then return end

function QuartzProcs:returnProcList()
	local tmplist = {
		-- Maelstrom Weapon
		[string.lower(GetSpellInfo(53817))] = { color={0,0.5,1}, name=GetSpellInfo(53817), },
		-- Clearcasting
		[string.lower(GetSpellInfo(16246))] = { color={0,0,1}, name=GetSpellInfo(16246), },
		-- Elemental Mastery
		[string.lower(GetSpellInfo(16166))] = { color={0,0,1}, name=GetSpellInfo(16166), },
		-- Tidal Waves
		[string.lower(GetSpellInfo(53390))] = { color={0.25,0.5,0.75}, name=GetSpellInfo(53390), },
		-- Tidal Force
		--[string.lower(GetSpellInfo(55198))] = { color={0,0,1}, name=GetSpellInfo(55198), },
		-- Lava Surge
		[string.lower(GetSpellInfo(77762))] = { color={1,0,0}, name=GetSpellInfo(77762), },
		-- Ancestral Guidance
		[string.lower(GetSpellInfo(108281))] = { color={0,0,1}, name=GetSpellInfo(108281), },
		-- Ascendance
		[string.lower(GetSpellInfo(114050))] = { color={0.93,0.83,0.72}, name=GetSpellInfo(114050), },
		-- Spiritwalker's Grace
		[string.lower(GetSpellInfo(79206))] = { color={0.2,0.8,0.2}, name=GetSpellInfo(79206), },
	}
	return tmplist
end