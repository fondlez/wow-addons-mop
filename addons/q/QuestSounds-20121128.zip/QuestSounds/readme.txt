QuestSounds is a small addon to give audio cues on the following events:

 - you complete a quest

 - you complete an objective of a quest

 - you gain progress on one of the objectives of a quest

Each of these events will cause a distinct sound to be played (only the
'highest ranked' of these sounds will play, of course)

The idea for this addon was inspired by MonkeyQuest's quest completion
sounds; I wanted to have that feature without having to load that full
addon, as most other features of MonkeyQuest are now provided by blizzard's
built-in objectives tracker.

My goal is to keep this addon small. This has the following implications:
 - There is only little configuration flexibility, via commandline
   instructions (see below)
 - The sounds are sounds that are embedded in the game, they
   are not external sound files.
 - There is no localization support. As far as I can see, the addon will work
   in other languages as well, but the feedback messages will be printed in
   english and the commands are in english.

Known problems:
 - The sounds may not play the first time they should play (if they aren't
   cached yet).
 - For some quests the wrong 'rank' of sound may play (e.g. the objective
   complete sound when the quest complete sound should play)
   
Configuration:

There are a few configuration commands available via the "/qsnd" command
("/questsounds" is an alias for "/qsnd"). Sorry - no graphical configuration
yet.

There are a few "sound sets" built in that you can choose between. In this
version you can switch between these via:
  /qsnd set gong
  /qsnd set wacky
  /qsnd set creatures

The 'wacky' set is the default in this version. (In the previous version
the 'gong' set was the default)

You can test the sounds via the "/qsnd test" command:
  /qsnd test quest
    plays the "quest complete" sound
  /qsnd test objective
    plays the "objective complete" sound
  /qsnd test part
    plays the "progress" sound
    
You can tune the amount of messages printed to the chat pane via the
"/qsnd message" command:
  /qsnd message none
    Do not print quest progress messages
  /qsnd message completion
    Only print quest completion messages
  /qsnd message objectives
    Only print messages for quest completion and objective completion
  /qsnd message all
    Print messages for all forms of quest progress (default)


-----------------------------------------------------------------------------

ChangeLog:

2012.11.28:
  - TOC update for patch 5.1

2012.09.12:
  - Added an option to reduce the number of messages printed to the chat pane

2012.08.29:
  - Release for MoP.
  - Changed the default sound set back to 'wacky' as that stands out more from
    'everyday' sounds.

2011.05.01:
  - Bumped TOC for patch 4.1. No other changes.

2010.10.17:
  - Changed the default sound set
  - Changed the "objective complete" sound of the original 'wacky' sound set
    to a sound that works on the 4.0.1 client
  - Added a configuration option via the "/qsnd" command (or "/questsounds")

2010.10.09:
  - Original release
