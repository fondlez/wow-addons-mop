
local QuestAnnounce = LibStub("AceAddon-3.0"):NewAddon("QuestAnnounce", "AceEvent-3.0", "AceConsole-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("QuestAnnounce")

--[[ The defaults a user without a profile will get. ]]--
local defaults = {
	profile={
		settings = {
			enable = true,
			every = 1,
			sound = true,
			debug = false
		},
		announceTo = {
			chatFrame = true,
			raidWarningFrame = false,
			uiErrorsFrame = false,
		},
		announceIn = {
			say = false,
			party = true,
			guild = false,
			officer = false,
			whisper = false,
			whisperWho = nil
		}
	}
}

--[[ QuestAnnounce Initialize ]]--
function QuestAnnounce:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("QuestAnnounceDB", defaults, true)
	
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileReset")
	self.db.RegisterCallback(self, "OnNewProfile", "OnNewProfile")
	
	self:SetupOptions()
end

function QuestAnnounce:OnEnable()
	--[[ We're looking at the UI_INFO_MESSAGE for quest messages ]]--
	self:RegisterEvent("UI_INFO_MESSAGE")
	
	self:SendDebugMsg("Addon Enabled :: "..tostring(QuestAnnounce.db.profile.settings.enable))
end

--[[ Event handler ]]--
function QuestAnnounce:UI_INFO_MESSAGE(event, ...)
	local msg = ...
	local settings = self.db.profile.settings
	
	if (msg ~= nil) then
		if (settings.enable) then
			local questText = gsub(msg, "(.*):%s*([-%d]+)%s*/%s*([-%d]+)%s*$", "%1", 1)
			
			if (questText ~= msg) then
				local ii, jj, strItemName, iNumItems, iNumNeeded = string.find(msg, "(.*):%s*([-%d]+)%s*/%s*([-%d]+)%s*$")
				local stillNeeded = iNumNeeded - iNumItems
                
				QuestAnnounce:SendDebugMsg("Item Name: "..strItemName.." :: Num Items: "..iNumItems.." :: Num Needed: "..iNumNeeded.." :: Still Need: "..stillNeeded)

				if(stillNeeded == 0 and settings.every == 0) then
					QuestAnnounce:SendMsg(L["Completed: "]..msg)
				elseif(QuestAnnounce.db.profile.settings.every > 0) then
					local every = math.fmod(iNumItems, settings.every)
					QuestAnnounce:SendDebugMsg("Every fMod: "..every)
				
					if(every == 0 and stillNeeded > 0) then
						QuestAnnounce:SendMsg(L["Progress: "]..msg)
					elseif(stillNeeded == 0) then
						QuestAnnounce:SendMsg(L["Completed: "]..msg)
					end
				end
			end
		end
	end
end

function QuestAnnounce:OnProfileChanged(event, db)
 	self.db.profile = db.profile
end

function QuestAnnounce:OnProfileReset(event, db)
	for k, v in pairs(defaults) do
		db.profile[k] = v
	end
	self.db.profile = db.profile
end

function QuestAnnounce:OnNewProfile(event, db)
	for k, v in pairs(defaults) do
		db.profile[k] = v
	end
end

--[[ Sends a debugging message if debug is enabled and we have a message to send ]]--
function QuestAnnounce:SendDebugMsg(msg)
	if(msg ~= nil and self.db.profile.settings.debug) then
		QuestAnnounce:Print("DEBUG :: "..msg)
	end
end

--[[ Sends a chat message to the selected chat channels and frames where applicable,
	if we have a message to send; will also send a debugging message if debug is enabled ]]--
function QuestAnnounce:SendMsg(msg)	
	local announceIn = self.db.profile.announceIn
	local announceTo = self.db.profile.announceTo

	if (msg ~= nil and self.db.profile.settings.enable) then
		if(announceTo.chatFrame) then
			if(announceIn.say) then
				SendChatMessage(msg, "SAY")
				QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg :: Say")
			end
		
			--[[ GetNumGroupMembers is group-wide; GetNumSubgroupMembers is confined to your group of 5 ]]--
			--[[ Ref: http://www.wowpedia.org/API_GetNumSubgroupMembers or http://www.wowpedia.org/API_GetNumGroupMembers ]]--	
			if(announceIn.party and IsInGroup() and GetNumSubgroupMembers(LE_PARTY_CATEGORY_HOME) > 0) then
				SendChatMessage(msg, "PARTY")
				QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg :: Party")
			end				
		
			if(announceIn.instance and IsInInstance() and GetNumSubgroupMembers(LE_PARTY_CATEGORY_INSTANCE) > 0) then
				SendChatMessage(msg, "INSTANCE_CHAT")
				QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg :: Instance")
			end				
		
			if(IsInGuild()) then
				if(announceIn.guild) then
					SendChatMessage(msg, "GUILD")
					QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg :: Guild")
				end
		
				if(announceIn.officer) then
					SendChatMessage(msg, "OFFICER")
					QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg :: Officer")
				end
			end
				
			if(announceIn.whisper) then
				local who = announceIn.whisperWho
				if(who ~= nil and who ~= "") then
					SendChatMessage(msg, "WHISPER", nil, who)
					QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg :: Whisper")
				end
			end
		end
		
		if(announceTo.raidWarningFrame) then
			RaidNotice_AddMessage(RaidWarningFrame, msg, ChatTypeInfo["RAID_WARNING"])
		end
		
		if(announceTo.uiErrorsFrame) then
			UIErrorsFrame:AddMessage(msg, 1.0, 1.0, 0.0, 7)
		end
		
		if(self.db.profile.settings.sound) then
			PlaySound("RAIDWARNING", "Master")
		end
	end
	
	QuestAnnounce:SendDebugMsg("QuestAnnounce:SendMsg - "..msg)
end