---------------------------------------------------------------------------------------------
QHVERSION = "QuickHeal2 v5.4.1.0"
---------------------------------------------------------------------------------------------
-- Author
--
--	WakeZero
-- 
-- Description
--
--	This addon allows a player to quickly use spells/macros on their party and raid with 
--	single mouse clicks as well as providing customized unit frames for raids.
--
-- Example
--
--	When enabled, damage taken bars will appear beside each player and party
--	unit frame. These bars increase with the amount of damage a player in the
--	party receives, changing colors from green to yellow to red upon death. When
--	in a raid, damage taken bars will appear beside the name of everyone in the
--	raid for quick and easy monitoring. A range checking option also gives the
--	ability to focus on party and raid members within range.
--
--	By opening the options menu (/QH2 or assigned keybinding) the user may
--	choose spells from their spellbook to cast upon the corresponding party/raid
--	member when the bars are clicked. Currently all mouse buttons may be assigned
--	as well as their Shift, Ctrl and Alt variants.
--
--	Macros may also be assigned by prefixing the macro name with an exclamation mark (!).
--	In order to allow macros to function the way you would expect them to when 
--	clicking on a unit's damage bar, you may use the keyword 'unit' to tell 
--	Quick Heal that you want the spell cast on the bar's unit. To cast the spell
--	renew, you could therefore create a macro '/cast [target=unit] Renew'.
--
-- TODO
--
--	* Target and focus frame bars
--	* Localize for other languages
--	* Add class specific bindings and options
--	* Show incoming heals
--
-- Changelog
--
--	v5.4.1.0 [2013-10-29] : - Fix for patch 5.4.1 removal of GetCVar("realmName")
--
--	v5.2.0.0 [2013-05-10] : - Added Default Monk Spells
--
--				- Fixed Range Checking Spells
--
--				- Added Raid Frame Sorting By Role
--
--				- Added Option To Display Role Icons
--
--	v5.0.5.0 [2012-09-27] : - Added Monk Class Support
--
--				- Fixed Raid Frame Problems In Battlegrounds
--
--	v5.0.4.2 [2012-09-10] : - Fixed Buff Icons
--
--				- Fixed Arena Frames
--
--	v5.0.4.1 [2012-09-06] : - Fixed Glyph Execution Taint
--
--				- Fixed Raid Frame Not Showing/Updating
--
--	v5.0.4.0 [2012-08-30] : - Fixed LUA Raid Frame Error Bug
--
--				- Fixed Raid Frame Showing Up In Arena
--
--	v4.0.3.0 [2010-11-16] : - Fixed Priest Range Finding Bug
--
--				- Fixed Target Frame Bug
--
--				- Fixed Bar Background And Spark Bugs
--
--				- Fixed Party/Pet Bar Hide/Show Bug
--				
--				- Fixed Profile Memory Bug
--
--				- Fixed Profile Talent Swap Settings Bug
--
--				- Fixed Raid Frame Moving Background Bug
--
--	v4.0.1.0 [2010-10-26] : - Added Dual Spec Profile Swapping!
--
--				- Added Threat Warnings!
--
--				- Added Right-Click Menus to Raid Units!
--
--				- Improved Performance (No More Lag in Large Raids!)
--				
--				- Fixed Taint Problems
--
--	v3.3.3.0 [2010-06-04] : - Added Raid Icons To Raid Frames
--
--				- Added Debuff Warning Feature
--
--				- Added Version Number To Options Tab Label
--
--				- Added New Raid Frame Options
--
--				- Moved General And Raid Frame Options To Subcategories
--
--				- Option Subcategories Are Now Shown By Default
--
--	v3.2.2.1 [2009-11-23] : - Fixed Memory Leaks!
--
--				- Improved Performance!
--
--				- Fixed Raid Frame Disable Option
--
--				- Added Party Pet Frames
--
--	v3.2.2.0 [2009-10-22] : - Fixed Options Resetting... Really...
--
--				- Fixed Update Message Displaying Multiple Times
--
--				- Added Saving, Loading and Deleting Of Custom Profiles
--
--	v3.1.3.0 [2009-07-07] : - Hopefully fixed Options Resetting Unexpectedly
--
--				- Added Option To Throttle Raid Frame Updates
--
--				- Added Default Settings Button In Options Frame
--
--	v3.1.1.3 [2009-05-06] : - Fixed HoT Display Bugs
--
--				- Fixed Damage Bars Not Updating Properly
--
--	v3.1.1.2 [2009-05-05] : - Added HoT Display!
--
--				- Added Decurse Options Panel
--
--				- Fixed Options Not Saving Properly
--
--				- Fixed Options Resetting Between Panels
--
--	v3.1.1.1 [2009-04-30] : - Fixed Options Not Updating Damage Bar Spells
--
--				- Fixed Profile Variables Resetting
--
--				- Fixed Player/Party Frame Anchor Adjustments
--
--				- Fixed Raid Frame Not Being Moveable
--				
--				- Fixed Shift/Ctrl/Alt Macro Bindings
--
--				- Added Debuff Labels
--
--      v3.1.1.0 [2009-04-27] : - Beta Version Of QuickHeal2
--
--				- All New Code Base Allows For Better Maintainability
--
--				- Added New Bar Textures
--
--				- Added Clickable Debuff Icons
--
--				- Integrated Options Frame Into Interface Settings
--
--	v3.0.8.0 [2009-01-22] : - Fixed UIDROPDOWNMENU_INIT_MENU Bug
--
--	v3.0.3.1 [2008-12-28] : - Added Party Pet Frames!
--
--				- Raid Names Now Change Purple On Cureable Debuffs
--
--				- Cureable Debuffs Now More Accurate
--
--				- Fixed Damage Bar Text Transparency Bug
--
--				- Party Frame Combat Bugs Should Be Less Frequent
--
--	v3.0.3.0 [2008-11-25] : - Added French Translation (Thanks psykose!)
--
--				- Fixed Party Frame In Combat Bug
--
--				- Fixed Vehicle/Player Frame Bug
--
--				- Fixed Errors On Login/Console Reload
--
--	v3.0.2.0 [2008-10-13] : - Fixed For Patch 3.0
--
--	v2.4.1.0 [2008-04-13] : - Added Option To Display Cureable Debuffs (Changes Bar Purple)
--
--				- Added Option To Display Units Out Of Range (75% Transparency)
--
--				- Fixed Unit Names Rearranging In Combat
--
--				- Fixed Range Checking
--
--	v2.3.3.1 [2008-02-11] : - Added Confirm Button To Reset Option
--
--				- Reset Button Now Only Affects Current Tab
--
--				- Added Optional Background To Raid Frame
--
--				- Added Automatic Macro Refresh On Change
--
--				- Made Target Frame Moveable By Holding Shift
--
--				- Fixed Non-English Client Raid Bug
--
--	v2.3.3.0 [2008-01-29] : - Added Raid Functionality
--
--				- Added Macros To Spell List
--
--				- Added Range Checking Option
--
--				- Options Frame Is Now Moveable
--
--	v2.3.0.0 [2007-12-19] : - Added Mouse Button4 and Button5 bindings
--
--				- Added Option to Disable Target Frame Adjustment
--
--				- Added Width/Height Options For Player and Party Damage Bars
--
--	v2.2.3.1 [2007-10-29] : - Added Option Tabs
--
--				- Added Shift, Alt, and Control bindings
--
--				- Added Damage Bar Transparency Setting
--
--				- Added Damage Bar Value Display
--
--				- Added Resurrection to Left Click When Party Member Dies
--
--	v2.2.3.0 [2007-10-25] : - First Release
--
-- Shoutouts
--
--	Jesus Christ - For joy, life, eternal love and forgiveness of sins!
--
--	Curse (wow.curse.com) - For hosting my addon and many others.
--
--	WoWInterface (www.wowinterface.com) - For hosting this addon and many others.
--
--	Wowpedia (www.wowpedia.org) - Greatest resource and API for WoW addon developers.
--
--	QuickHeal Donors - Thank you for your support!
--
---------------------------------------------------------------------------------------------
-- QuickHeal Class
---------------------------------------------------------------------------------------------
QuickHeal = {}
QuickHeal.__index = QuickHeal;

function QuickHeal:new()

	-- Metatable
	local self = {};
	setmetatable(self, QuickHeal);
	
	-- Frame Variables
	self.name = "QHMain_Frame";
	self.frame = CreateFrame("Frame", self.name, UIParent);
	
	-- Options Variables
	self.options = QHOptions:new();
	self.profiles = {};
	self.backupsettings = {};
	self.macrosloaded = false;
	
	-- Update Variables
	self.updatestart = 0;
	self.updateend = 0;
	self.updateinterval = 0.25;
	self.updatelast = 0;
	self.updatetime = 0;
	
	-- Party/Raid Variables
	self.partyframe = nil;
	self.raidframe = nil;

	-- Reference Variables
	self.obj = self;
	self.parent = nil;
	self.frame.obj = self;

	-- Setup Slash Commands
	self:SetupSlashCommands();
	
	-- Register Events
	self:RegisterForEvents();
	
     	-- Report Status and Return
     	self:Report();
     	return self;
end 

local _;

---------------------------------------------------------------------------------------------
-- QuickHeal Methods
---------------------------------------------------------------------------------------------
function QuickHeal:GetGlobal(variable)

	if QHProfile2["GlobalSettings"] and variable then
		return QHProfile2["GlobalSettings"][variable];
	end
end

function QuickHeal:SetGlobal(variable, value)

	if not QHProfile2["GlobalSettings"] then
		QHProfile2["GlobalSettings"] = {};
	end
	
	if variable then
		if not value then QHProfile2["GlobalSettings"][variable] = false;
		else QHProfile2["GlobalSettings"][variable] = value; end
	end
end

function QuickHeal:GetSetting(variable)

	local profile = self:GetProfileName();
	
	if variable then
	
		-- Constants Override Variables
		if QHCONSTANTS[variable] then
			return QHCONSTANTS[variable];
		elseif QHProfile2[profile] then
			return QHProfile2[profile][variable];
		end
	end
end

function QuickHeal:SetSetting(variable, value)

	local profile = self:GetProfileName();
		
	if QHProfile2[profile] and variable then
		if not value then QHProfile2[profile][variable] = false;
		else QHProfile2[profile][variable] = value; end
	end
end

function QuickHeal:ResetSettings()
	QHProfile2[self:GetProfileName()] = {};
end

function QuickHeal:LoadDefaultSettings(class)

	local profile = self:GetProfileName();
	if not class then _,class = UnitClass("player"); end
	QHProfile2[profile] = {};
	self:CopyTable(QHProfile2[profile], QHDEFAULT[class]);
end

function QuickHeal:LoadProfile(name)

	if name then
		name = QH:Concat("!", name);
		local profile = self:GetProfileName();
		self:CopyTable(QHProfile2[profile], QHProfile2[name]);
	end
end

function QuickHeal:SaveProfile(name)
	
	if name then
		name = QH:Concat("!", name);
		local profile = self:GetProfileName();
		QHProfile2[name] = {};
		self:CopyTable(QHProfile2[name], QHProfile2[profile]);
	end
end

function QuickHeal:DeleteProfile(name)

	if name then
		name = QH:Concat("!", name);
		QHProfile2[name] = nil;
	end
end

function QuickHeal:GetProfileName()
	return self:Concat(UnitName("player"), "|", string.gsub(GetRealmName(), "^%s*(.-)%s*$", "%1"));
end

function QuickHeal:GetProfiles()
	
	wipe(self.profiles);
	for k,v in pairs(QHProfile2) do
		if string.find(k, "!") then tinsert(self.profiles, string.sub(k, 2)); end
	end
	return self.profiles;
end

function QuickHeal:SetupSlashCommands()

	-- Displays Options
	SlashCmdList["QuickHeal"] = self.ShowOptions;
	SLASH_QuickHeal1 = "/QH2";
	SLASH_QuickHeal2 = "/QHeal";
	SLASH_QuickHeal3 = "/QuickHeal";
end

function QuickHeal:Report()

	self:Print("QuickHeal2 is |cFF00FF00ON".."|cFFFFFFFF ["..QH_LOCALE_HELP.."]");
end

function QuickHeal:ShowOptions()

	-- Hack: Show Profile Panel First To Open Sub Categories
	InterfaceOptionsFrame_OpenToCategory(QH.options.decursepanel);
	InterfaceOptionsFrame_OpenToCategory(QH.options.panel);
end

function QuickHeal:GetLabel()
	return "Quick Heal 2";
end

function QuickHeal:GetVersion()
	local version = string.gsub(QHVERSION, "QuickHeal2 v", "");
	return version;
end

function QuickHeal:GetPrettyVersion()
	local pretty_version = self:Concat("Version ", self:GetVersion());
	return pretty_version;
end

function QuickHeal:CheckVersion()
	
	local pre_ver = self:GetGlobal("VERSION_NUM");
	local cur_ver = self:GetVersion();
	
	if not pre_ver or pre_ver ~= cur_ver then
		
		-- Display ThankYou Message
		self:ShowThankYouNotice();
	end
	
	-- Set Global Version Number
	self:SetGlobal("VERSION_NUM", cur_ver);
	
	-- Check For Newer Version
	local chatindex = GetChannelName("QuickHealMod");
	if chatindex then
	
		-- Send Version Information To Global Channel
		SendChatMessage(QHVERSION, "CHANNEL", nil, chatindex);
	end
end

function QuickHeal:CompareVersion(version)

	local a = string.gsub(QHVERSION, "QuickHeal2 v", "");
	local b = string.gsub(version, "QuickHeal2 v", "");
	
	-- This Is Latest Version
	if a > b then return -1;
		
	-- This Is Not Latest Version
	elseif a < b then return 1;
		
	-- Versions Are Equal
	else return 0; end
end

function QuickHeal:ShowThankYouNotice()
	
	if not QH.thankyoumessage then
		QH.thankyoumessage = true;
		local msg = QH:Concat(QH_LOCALE_THANKS, QHVERSION, string.char(13), QH_LOCALE_CONFIGURE, string.char(13,13), QH_LOCALE_SUPPORT);
		self:ShowNotice(350, 130, msg, QH_LOCALE_SUPPORTLINK);
	end
end

function QuickHeal:ShowUpdateNotice()

	if not QH.updatemessage then
		QH.updatemessage = true;
		local msg = QH:Concat(QH_LOCALE_UPDATENOTICE, string.char(13,13), QH_LOCALE_UPDATEINSTRUCT);
		self:ShowNotice(350, 115, msg, QH_LOCALE_SUPPORTLINK);
	end
end

function QuickHeal:ShowNotice(width, height, msg, link)

	local frame = CreateFrame("Frame", nil, UIParent);
	frame:SetFrameStrata("DIALOG");
	frame:SetWidth(width);
	frame:SetHeight(height);
	frame:SetPoint("TOP", 0, -230);
	frame:SetBackdrop({
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
		insets = {left = 11, right = 12, top = 12, bottom = 11},
	});
	local fontstring = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
	fontstring:SetWidth(410);
	fontstring:SetHeight(0);
	fontstring:SetPoint("TOP", 0, -16);
	fontstring:SetText(msg);
	
	if link then
		local editBox = CreateFrame("EditBox", nil, frame);
		do
			local editBoxLeft = editBox:CreateTexture(nil, "BACKGROUND");
			local editBoxRight = editBox:CreateTexture(nil, "BACKGROUND");
			local editBoxMiddle = editBox:CreateTexture(nil, "BACKGROUND");
			editBoxLeft:SetTexture("Interface\\ChatFrame\\UI-ChatInputBorder-Left");
			editBoxLeft:SetHeight(32);
			editBoxLeft:SetWidth(32);
			editBoxLeft:SetPoint("LEFT", -14, 0);
			editBoxLeft:SetTexCoord(0, 0.125, 0, 1);
			editBoxRight:SetTexture("Interface\\ChatFrame\\UI-ChatInputBorder-Right");
			editBoxRight:SetHeight(32);
			editBoxRight:SetWidth(32);
			editBoxRight:SetPoint("RIGHT", 6, 0);
			editBoxRight:SetTexCoord(0.875, 1, 0, 1);
			editBoxMiddle:SetTexture("Interface\\ChatFrame\\UI-ChatInputBorder-Right");
			editBoxMiddle:SetHeight(32);
			editBoxMiddle:SetWidth(1);
			editBoxMiddle:SetPoint("LEFT", editBoxLeft, "RIGHT");
			editBoxMiddle:SetPoint("RIGHT", editBoxRight, "LEFT");
			editBoxMiddle:SetTexCoord(0, 0.9375, 0, 1);
		end
		editBox:SetHeight(32);
		editBox:SetWidth(250);
		editBox:SetPoint("TOP", fontstring, "BOTTOM", 0, 2);
		editBox:SetFontObject("GameFontHighlight");
		editBox:SetTextInsets(0, 0, 0, 1);
		editBox:SetFocus();
		editBox:SetText(link);
		editBox:HighlightText();
		editBox:SetScript("OnHide", function(self)
			ChatEdit_FocusActiveWindow();
		end);
		editBox:SetScript("OnTextChanged", function(self)
			editBox:SetText(link);
			editBox:HighlightText();
		end);
	end
	local button = CreateFrame("Button", nil, frame);
	button:SetHeight(24);
	button:SetWidth(75);
	button:SetPoint("BOTTOM", 0, 13);
	button:SetNormalFontObject("GameFontNormal");
	button:SetHighlightFontObject("GameFontHighlight");
	button:SetNormalTexture(button:CreateTexture(nil, nil, "UIPanelButtonUpTexture"));
	button:SetPushedTexture(button:CreateTexture(nil, nil, "UIPanelButtonDownTexture"));
	button:SetHighlightTexture(button:CreateTexture(nil, nil, "UIPanelButtonHighlightTexture"));
	button:SetText(QH_LOCALE_OKAY);
	button:SetScript("OnClick", function(self)
		frame:Hide();
	end);
end

---------------------------------------------------------------------------------------------
-- QuickHeal Events
---------------------------------------------------------------------------------------------
function QuickHeal:RegisterForEvents()

	-- Register Event Handler
	self.frame:SetScript("OnEvent", self.OnEvent);
	self.frame:SetScript("OnUpdate", self.OnUpdate);

	-- System Events
	self:RegisterEvent("ADDON_LOADED");
	self:RegisterEvent("CHANNEL_UI_UPDATE");
	self:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE");
	self:RegisterEvent("CHAT_MSG_CHANNEL");
	self:RegisterEvent("CHAT_MSG_ADDON");
	self:RegisterEvent("PLAYER_LOGOUT");
	self:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED");
	
	-- Group Events
	self:RegisterEvent("PARTY_CONVERTED_TO_RAID");
	self:RegisterEvent("GROUP_ROSTER_UPDATE");
	self:RegisterEvent("ARENA_TEAM_UPDATE");
	
	-- Unit Events
	self:RegisterEvent("UNIT_NAME_UPDATE");
	--self:RegisterEvent("UNIT_COMBAT");
	--self:RegisterEvent("UNIT_PORTRAIT_UPDATE");
	--self:RegisterEvent("UNIT_CLASSIFICATION_CHANGED");
	self:RegisterEvent("UNIT_AURA");
	self:RegisterEvent("UNIT_AURASTATE");
	self:RegisterEvent("UNIT_HEALTH");
	self:RegisterEvent("UNIT_HEALTHMAX");
	self:RegisterEvent("UNIT_MAXHEALTH");
	self:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE");
	--self:RegisterEvent("UNIT_MANA");
	--self:RegisterEvent("UNIT_MAXMANA");
	--self:RegisterEvent("UNIT_RAGE");
	--self:RegisterEvent("UNIT_MAXRAGE");
	--self:RegisterEvent("UNIT_ENERGY");
	--self:RegisterEvent("UNIT_MAXENERGY");
	--self:RegisterEvent("UNIT_RUNIC_POWER");
	--self:RegisterEvent("UNIT_MAXRUNIC_POWER");
	--self:RegisterEvent("UNIT_DISPLAYPOWER");
	self:RegisterEvent("UNIT_PET");
	
	-- Macro Events
	self:RegisterEvent("UPDATE_MACROS");
	
	-- Player Events
	self:RegisterEvent("PLAYER_FOCUS_CHANGED");
	self:RegisterEvent("PLAYER_TARGET_CHANGED");
end

function QuickHeal:RegisterEvent(event)
	self.frame:RegisterEvent(event);
end

function QuickHeal:OnUpdate(elapsed)

	QH.updatelast = QH.updatelast + elapsed;
	if (QH.updatelast > QH.updateinterval) then
		QH:OnEvent("UPDATE");
		QH.updatelast = 0;
		QH.updatetime = 0;
	end
end

function QuickHeal:OnEvent(event, ...)

	-- DEBUG
	--if event ~= 'UPDATE' and event ~= 'CHAT_MSG_CHANNEL' then QH:PrintAll(1,1,1,event,...); end

	local estart = GetTime();
	if (type(self.obj[event]) == 'function') then
	
		
	
		-- Call Event Specific Function
		self.obj[event](self.obj, event, ...);
		
	else
		-- Call Unit Function
		QHUnit:OnEvent(event, ...);
	end
	QH.updatetime = QH.updatetime + (GetTime() - estart);
end

function QuickHeal:UPDATE(event, ...)
	
	-- Set Update Start Time
	QH.updatestart = GetTime();
	
	-- Update Party/Raid Frame
	QH.partyframe:Update();
	QH.raidframe:Update();
	
	-- Set Update End Time
	QH.updateend = GetTime();
	QH.updatetime = QH.updatetime + (QH.updateend - QH.updatestart);
	QH.fps = 1 / QH.updatetime;
	
	-- FOR DEBUG
	-- if QH.fps then --and QH.updatetime > 0.033 then
		-- getglobal(QH:Concat(QH.raidframe.globalframe:GetName(), "_FrameDebug")):SetText(QH.fps); --QH.updateend - QH.updatestart);
	-- end
end

function QuickHeal:ACTIVE_TALENT_GROUP_CHANGED(event, spec, ...)

	if QH:GetGlobal(QH:Concat(QH:GetProfileName(), "_SpecSwap")) then
	
		-- Swap Profiles
		local profile = QH:GetGlobal(QH:Concat(QH:GetProfileName(), "_Spec", spec));
		if profile then
			QH:LoadProfile(profile);
			QHOptions:SetupOptions(true);
			QHOptions:Update();
			QH:Print(QH:Concat("QuickHeal Profile '|cFF00FF00", profile, "|cFFFFFFFF' has been loaded."));
		end
	end
end

function QuickHeal:PARTY_CONVERTED_TO_RAID(event, ...)

	-- Update Raid Frames
	QH.raidframe:ForceUpdate();
end

function QuickHeal:GROUP_ROSTER_UPDATE(event, ...)

	-- Update Party/Raid Frames
	QH.partyframe:ForceUpdate();
	QH.raidframe:ForceUpdate();
end

function QuickHeal:ARENA_TEAM_UPDATE(event, ...)

	-- Update Party Frames
	QH.partyframe:ForceUpdate();
end

function QuickHeal:UPDATE_MACROS(event, ...)

	-- Set Macro Loaded Variable
	QH.macrosloaded = true;

	-- Update Party/Raid Frames
	QH.partyframe:ForceUpdate();
	QH.raidframe:ForceUpdate();
end

function QuickHeal:ADDON_LOADED(event, addon, ...)

	if addon == "QuickHeal" then

		-- Load Settings
		local profile = self:GetProfileName();
		if not QHProfile2[profile] then QHProfile2[profile] = {}; end

		-- Set Global Variable Count
		local _, englishClass = UnitClass("player");
		self:SetGlobal("VAR_COUNT", self:CountTable(QHDEFAULT[englishClass]));

		-- Verify Settings
		if self:CountTable(QHProfile2[profile]) ~= self:GetGlobal("VAR_COUNT") then

			-- self:Print("Loading New Settings");

			-- Backup Current Settings
			wipe(self.backupsettings); 
			self:CopyTable(self.backupsettings, QHProfile2[profile]);

			-- Load Default Settings
			self:LoadDefaultSettings(englishClass);

			-- Restore Backup Settings
			for index,value in pairs(self.backupsettings) do
				if value ~= nil then QHProfile2[profile][index] = value; end
			end
		end

		-- Initialize Options
		QHOptions:SetupOptions();

		-- Setup Player/Raid Frames
		self.partyframe = QHParty:new(1);
		self.raidframe = QHRaid:new(1);
	end
end

function QuickHeal:CHANNEL_UI_UPDATE(event, ...)
	
	-- Join Global QuickHeal Channel
	if GetChannelName("QuickHealMod") == 0 then
		JoinChannelByName("QuickHealMod", "i<3QuickHeal");
	else
		self:CheckVersion();
	end
end

function QuickHeal:CHAT_MSG_CHANNEL_NOTICE(event, msg, arg2, arg3, namenum, arg5, arg6, chantype, channum, channel, ...)

	-- Get Event Arguments
	local msg = arg1;
	local channel = arg9;

	-- Check QuickHealMod Global Channel
	if msg == "YOU_JOINED" and channel == "QuickHealMod" then
	
		-- Check QuickHeal Version
		self:CheckVersion();
	end
end

function QuickHeal:CHAT_MSG_CHANNEL(event, msg, author, language, namenum, target, flags, zoneid, num, channel, lineid, guid, ...)

	-- Check QuickHealMod Global Channel
	if author ~= UnitName("player") and channel == "QuickHealMod" then
	
		-- Check Reported Version
		local compare = self:CompareVersion(msg);
		if compare > 0 then
		
			-- Display Update Notice
			self:ShowUpdateNotice();
		
		elseif compare < 0 then
		
			-- Whisper New Version Notice
			SendAddonMessage("QH2", QHVERSION, "WHISPER", author);
		end
	end
end

function QuickHeal:CHAT_MSG_ADDON(event, addon, msg, distribution, author, ...)

	-- Check QuickHealMod Global Channel
	if addon == "QH2" and author ~= UnitName("player") then
	
		-- Check Reported Version
		local compare = self:CompareVersion(msg);
		if compare > 0 then
		
			-- Display Update Notice
			self:ShowUpdateNotice();
		
		elseif compare < 0 then
		
			-- Whisper New Version Notice
			SendAddonMessage("QH2", QHVERSION, "WHISPER", author);
		end
	end
end

function QuickHeal:PLAYER_LOGOUT(event, ...)

end

---------------------------------------------------------------------------------------------
-- Global Utility Functions
---------------------------------------------------------------------------------------------
function QuickHeal:Print(msg, red, green, blue)
	DEFAULT_CHAT_FRAME:AddMessage(msg, red, green, blue);
end

function QuickHeal:PrintAll(red, green, blue, ...)
	local msg = self:Concat(...);
	DEFAULT_CHAT_FRAME:AddMessage(msg, red, green, blue);
end

function QuickHeal:Concat(...)

	local s = "";
	for n = 1, select("#", ...) do
		local value = select(n, ...);
		if value == true then s = s .. "true";
		elseif value == false then s = s.."false";
		elseif type(value) == "table" then s = s;
		elseif value ~= nil then s = s..value; end
	end
	return s;
end

function QuickHeal:Wrap(min, max, value)

	if value > max then value = min + (value - max) - 1; end
	if value < min then value = max - (min - value) + 1; end
	return value;
end

function QuickHeal:CountTable(tab)
	
	local n = 0;
	for index,value in pairs(tab) do
		n = n + 1;
	end
	return n;
end

function QuickHeal:CopyTable(to, from)
	
	if not to then to = {}; end
	for k,v in pairs(from) do
		if type(v) == "table" then
			to[k] = {}
			QuickHeal:CopyTable(to[k], v);
		else
			to[k] = v;
		end
	end
end

function QuickHeal:CloneFrame(frame, name)

	-- Get Frame Info
	local align, anchor, relative, x, y = frame:GetPoint();
	local width = frame:GetWidth();
	local height = frame:GetHeight();

	-- Create Clone
	clone = CreateFrame("Frame", name, UIParent);
	clone:SetWidth(width);
	clone:SetHeight(height);
	clone:SetPoint(align, anchor, relative, x, y);
	return clone;
end

function QuickHeal:CopyFrame(frame, copy)

	-- Get Frame Info
	local align, anchor, relative, x, y = frame:GetPoint();
	local width = frame:GetWidth();
	local height = frame:GetHeight();
	
	-- Copy Frame
	copy:SetWidth(width);
	copy:SetHeight(height);
	copy:SetPoint(align, anchor, relative, x, y);
end

function QuickHeal:IsInArena()

	return IsActiveBattlefieldArena() or (UnitInBattleground("player") and GetCurrentMapAreaID() < 0)
end

function QuickHeal:DoesArena1Exist()

	if UnitExists("arena1") then QH:Print("Arena1 Exists", 0, 1, 0);
	else QH:Print("Arena1 Doesn't Exist", 1, 0, 0); end
end