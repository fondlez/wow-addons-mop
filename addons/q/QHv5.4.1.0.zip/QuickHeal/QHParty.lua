---------------------------------------------------------------------------------------------
-- QHParty Class
---------------------------------------------------------------------------------------------
QHParty = {};
QHParty.__index = QHParty;

function QHParty:new(id)

	-- Metatable
	local self = {};
     	setmetatable(self, QHParty);
     	
     	-- Position Variables
	self.x = 0;
	self.y = 0;
	self.align = "TOPLEFT";
	self.relative = "TOPLEFT";
	self.anchor = UIParent;
	self.width = 0;
	self.height = 0;
	self.moving = nil;
	
	-- Frame Variables
	self.id = id;
	self.name = QH:Concat("QHParty", id);
	self.frame = CreateFrame("Frame", self.name, UIParent);
	
	-- Unit Frame Anchors
	self.playeranchor = QH:CloneFrame(PlayerFrame, QH:Concat(self.name, "_Anchor_player"));
	self.petanchor = QH:CloneFrame(PetFrame, QH:Concat(self.name, "_Anchor_pet"));
	self.party1anchor = QH:CloneFrame(PartyMemberFrame1, QH:Concat(self.name, "_Anchor_party1"));
	self.partypet1anchor = QH:CloneFrame(PartyMemberFrame1PetFrame, QH:Concat(self.name, "_Anchor_partypet1"));
	self.party2anchor = QH:CloneFrame(PartyMemberFrame2, QH:Concat(self.name, "_Anchor_party2"));
	self.partypet2anchor = QH:CloneFrame(PartyMemberFrame2PetFrame, QH:Concat(self.name, "_Anchor_partypet2"));
	self.party3anchor = QH:CloneFrame(PartyMemberFrame3, QH:Concat(self.name, "_Anchor_party3"));
	self.partypet3anchor = QH:CloneFrame(PartyMemberFrame3PetFrame, QH:Concat(self.name, "_Anchor_partypet3"));
	self.party4anchor = QH:CloneFrame(PartyMemberFrame4, QH:Concat(self.name, "_Anchor_party4"));
	self.partypet4anchor = QH:CloneFrame(PartyMemberFrame4PetFrame, QH:Concat(self.name, "_Anchor_partypet4"));
	
	-- Unit Frames
	self.player = QHUnit:new("player");
	self.player:SetPosition(3, 5, "LEFT", "RIGHT", self.playeranchor);
	self.pet = QHUnit:new("pet");
	self.pet:SetPosition(0, 4, "LEFT", "RIGHT", self.petanchor);
	self.party1 = QHUnit:new("party1");
	self.party1:SetPosition(3, 5, "LEFT", "RIGHT", self.party1anchor);
	self.partypet1 = QHUnit:new("partypet1");
	self.partypet1:SetPosition(0, 4, "LEFT", "RIGHT", self.partypet1anchor);
	self.party2 = QHUnit:new("party2");
	self.party2:SetPosition(3, 5, "LEFT", "RIGHT", self.party2anchor);
	self.partypet2 = QHUnit:new("partypet2");
	self.partypet2:SetPosition(0, 4, "LEFT", "RIGHT", self.partypet2anchor);
	self.party3 = QHUnit:new("party3");
	self.party3:SetPosition(3, 5, "LEFT", "RIGHT", self.party3anchor);
	self.partypet3 = QHUnit:new("partypet3");
	self.partypet3:SetPosition(0, 4, "LEFT", "RIGHT", self.partypet3anchor);
	self.party4 = QHUnit:new("party4");
	self.party4:SetPosition(3, 5, "LEFT", "RIGHT", self.party4anchor);
	self.partypet4 = QHUnit:new("partypet4");
	self.partypet4:SetPosition(0, 4, "LEFT", "RIGHT", self.partypet4anchor);
	
	-- Target Frame 
	-- TODO: Create Target Class
	self.targetpoint, self.targetrelative, self.targetalign, self.targetx, self.targety = getglobal("TargetFrame"):GetPoint();
	
	-- Reference Variables
	self.obj = self;
	self.parent = nil;
	self.frame.obj = self;
	
	-- Call Initial Update Functions and Return
	self:UpdateSettings();
	return self;
end

---------------------------------------------------------------------------------------------
-- QHParty Methods
---------------------------------------------------------------------------------------------
function QHParty:Initialize()
	
end

---------------------------------------------------------------------------------------------
-- QHParty Events
---------------------------------------------------------------------------------------------
function QHParty:ForceUpdate(now)

	self.forceupdate = true;
	if now then self:Update(); end
end

function QHParty:UpdateSettings()

	self.player:UpdateSettings();
	self.pet:UpdateSettings();
	self.party1:UpdateSettings();
	self.partypet1:UpdateSettings();
	self.party2:UpdateSettings();
	self.partypet2:UpdateSettings();
	self.party3:UpdateSettings();
	self.partypet3:UpdateSettings();
	self.party4:UpdateSettings();
	self.partypet4:UpdateSettings();
	
	-- Force Secure Update
	self:ForceUpdate();
	self:Update();
end

function QHParty:Update()

	-- Update Ranges
	self.pet:UpdateRange();
	self.party1:UpdateRange();
	self.partypet1:UpdateRange();
	self.party2:UpdateRange();
	self.partypet2:UpdateRange();
	self.party3:UpdateRange();
	self.partypet3:UpdateRange();
	self.party4:UpdateRange();
	self.partypet4:UpdateRange();
	
	-- Secure Update
	if self.forceupdate then self:UpdateSecure(); end
end

local target_frame_adjusted = false;
function QHParty:UpdateSecure()

	-- Update Anchors
	if not InCombatLockdown() then
	
		self.forceupdate = false;

		-- Update Anchors
		self:UpdateAnchors();
		
		-- Update Secure
		self.player:ForceUpdate(true);
		self.pet:ForceUpdate(true);
		self.party1:ForceUpdate(true);
		self.partypet1:ForceUpdate(true);
		self.party2:ForceUpdate(true);
		self.partypet2:ForceUpdate(true);
		self.party3:ForceUpdate(true);
		self.partypet3:ForceUpdate(true);
		self.party4:ForceUpdate(true);
		self.partypet4:ForceUpdate(true);
		
		-- Adjust Target Frame 
		if QH:GetSetting("TargetFrame_Disable_Adjust") then
			if target_frame_adjusted then
				target_frame_adjusted = false;
				getglobal("TargetFrame"):SetClampedToScreen(true);
				if getglobal("TargetFrame"):IsMovable() then getglobal("TargetFrame"):SetUserPlaced(false); end
				getglobal("TargetFrame"):SetPoint(self.targetpoint, self.targetrelative, self.targetalign, self.targetx, self.targety);
			end
		else
			getglobal("TargetFrame"):SetClampedToScreen(true);
			getglobal("TargetFrame"):RegisterForDrag("LeftButton");
			getglobal("TargetFrame"):SetScript("OnDragStart", function() if(IsShiftKeyDown()) then getglobal("TargetFrame"):SetMovable(true); getglobal("TargetFrame"):StartMoving(); end end);
			getglobal("TargetFrame"):SetScript("OnDragStop", function() getglobal("TargetFrame"):StopMovingOrSizing(); getglobal("TargetFrame"):SetUserPlaced(true); getglobal("TargetFrame"):SetMovable(false); end);
			if not getglobal("TargetFrame"):IsUserPlaced() then
				getglobal("TargetFrame"):SetPoint(self.targetpoint, self.targetrelative, self.targetalign, self.targetx + self.player.width, self.targety);
			end
			target_frame_adjusted = true;
		end
	end
end

function QHParty:UpdateAnchors()

	QH:CopyFrame(PlayerFrame, self.playeranchor);
	QH:CopyFrame(PetFrame, self.petanchor);
	QH:CopyFrame(PartyMemberFrame1, self.party1anchor);
	QH:CopyFrame(PartyMemberFrame1PetFrame, self.partypet1anchor);
	QH:CopyFrame(PartyMemberFrame2, self.party2anchor);
	QH:CopyFrame(PartyMemberFrame2PetFrame, self.partypet2anchor);
	QH:CopyFrame(PartyMemberFrame3, self.party3anchor);
	QH:CopyFrame(PartyMemberFrame3PetFrame, self.partypet3anchor);
	QH:CopyFrame(PartyMemberFrame4, self.party4anchor);
	QH:CopyFrame(PartyMemberFrame4PetFrame, self.partypet4anchor);
end