---------------------------------------------------------------------------------------------
-- QuickHeal Constant And Default Variables
---------------------------------------------------------------------------------------------
QHDEFAULT = {};
QHDEFAULT["GLOBAL"] = {};
QHCONSTANTS = {};

-- TARGET FRAME SETTINGS
QHDEFAULT["GLOBAL"]["TargetFrame_Disable_Adjust"]	= false;

-- NAMEPLATE SETTINGS
QHCONSTANTS["Name_Background_Texture"]			= false;
QHCONSTANTS["Name_Range_Alpha"]				= 0.5;
QHCONSTANTS["Name_Background_Color"] 			= {r=0.0, g=0.0, b=0.0, a=0.0};

-- BAR SETTINGS
QHDEFAULT["GLOBAL"]["Bar_Label_Show"]			= true;
QHDEFAULT["GLOBAL"]["Bar_Range_Check"]			= true;
QHDEFAULT["GLOBAL"]["Bar_Always_Show_Spark"] 		= false;
QHDEFAULT["GLOBAL"]["Bar_Background_Show"] 		= false;
QHCONSTANTS["Bar_Range_Alpha"]				= 0.15;
QHCONSTANTS["Bar_Start_Color"] 				= {r=0.0, g=1.0, b=0.0, a=1.0};
QHCONSTANTS["Bar_Mid_Color"] 				= {r=1.0, g=1.0, b=0.0, a=1.0};
QHCONSTANTS["Bar_End_Color"] 				= {r=1.0, g=0.0, b=0.0, a=1.0};
QHCONSTANTS["Bar_Hot_Color"] 				= {r=0.0, g=1.0, b=1.0, a=0.75};
QHCONSTANTS["Bar_Background_Color"] 			= {r=0.0, g=0.0, b=0.0, a=0.5};
QHCONSTANTS["Bar_Label_Color"] 				= {r=1.0, g=1.0, b=1.0, a=1.0};

-- DECURSE BUTTON SETTINGS
QHDEFAULT["GLOBAL"]["Decurse_Show"]			= true;
QHDEFAULT["GLOBAL"]["Warnings_Show"]			= true;
QHDEFAULT["GLOBAL"]["Warnings_Flash"]			= true;
QHDEFAULT["GLOBAL"]["Warnings_Show_Standard"]		= true;
QHDEFAULT["GLOBAL"]["Warning_List"]			= "";
QHDEFAULT["GLOBAL"]["Warnings_Threat"]			= true;
QHCONSTANTS["Decurse_Range_Alpha"]			= 0.15;
QHCONSTANTS["Decurse_Background_Color"] 		= {r=0.0, g=0.0, b=0.0, a=0.0};

-- BUFF SETTINGS
QHDEFAULT["GLOBAL"]["Buff_Show"]			= true;
QHCONSTANTS["Buff_Row_Spacing"]				= 2;
QHCONSTANTS["Buff_Row_Offset"]				= 2;
QHCONSTANTS["Buff_Col_Spacing"]				= 2;
QHCONSTANTS["Buff_Col_Offset"]				= 2;

-- PLAYER FRAME SETTINGS
QHDEFAULT["GLOBAL"]["Player_Bar_Width"] 		= 100;
QHDEFAULT["GLOBAL"]["Player_Bar_Height"] 		= 40;
QHCONSTANTS["Player_Name_Position"] 			= false;
QHCONSTANTS["Player_Name_Width"] 			= 75;
QHCONSTANTS["Player_Name_Height"] 			= 40;
QHCONSTANTS["Player_Name_Text_Position"] 		= "RIGHT";
QHCONSTANTS["Player_Bar_Position"] 			= 2;
QHCONSTANTS["Player_Decurse_Position"] 			= 3;
QHCONSTANTS["Player_Decurse_Width"] 			= 40;
QHCONSTANTS["Player_Decurse_Height"] 			= 40;
QHCONSTANTS["Player_Buff_Width"] 			= 18;
QHCONSTANTS["Player_Buff_Height"] 			= 18;
QHCONSTANTS["Player_Raid_Icon_Width"] 			= 18;
QHCONSTANTS["Player_Raid_Icon_Height"] 			= 18;
QHCONSTANTS["Player_Raid_Icon_Offset"] 			= 5;

-- PARTY FRAME SETTINGS
QHDEFAULT["GLOBAL"]["Party_Bar_Width"] 			= 100;
QHDEFAULT["GLOBAL"]["Party_Bar_Height"] 		= 40;
QHCONSTANTS["Party_Name_Position"] 			= false;
QHCONSTANTS["Party_Name_Width"] 			= 75;
QHCONSTANTS["Party_Name_Height"] 			= 40;
QHCONSTANTS["Party_Name_Text_Position"] 		= "RIGHT";
QHCONSTANTS["Party_Bar_Position"] 			= 2;
QHCONSTANTS["Party_Decurse_Position"] 			= 3;
QHCONSTANTS["Party_Decurse_Width"] 			= 40;
QHCONSTANTS["Party_Decurse_Height"] 			= 40;
QHCONSTANTS["Party_Buff_Width"] 			= 18;
QHCONSTANTS["Party_Buff_Height"] 			= 18;
QHCONSTANTS["Party_Raid_Icon_Width"] 			= 18;
QHCONSTANTS["Party_Raid_Icon_Height"] 			= 18;
QHCONSTANTS["Party_Raid_Icon_Offset"] 			= 5;

-- PET FRAME SETTINGS
QHDEFAULT["GLOBAL"]["Pet_Bar_Width"] 			= 50;
QHDEFAULT["GLOBAL"]["Pet_Bar_Height"] 			= 20;
QHCONSTANTS["Pet_Name_Position"] 			= false;
QHCONSTANTS["Pet_Name_Width"] 				= 75;
QHCONSTANTS["Pet_Name_Height"] 				= 20;
QHCONSTANTS["Pet_Name_Text_Position"] 			= "RIGHT";
QHCONSTANTS["Pet_Bar_Position"] 			= 2;
QHCONSTANTS["Pet_Decurse_Position"] 			= 3;
QHCONSTANTS["Pet_Decurse_Width"] 			= 20;
QHCONSTANTS["Pet_Decurse_Height"] 			= 20;
QHCONSTANTS["Pet_Buff_Width"] 				= 9;
QHCONSTANTS["Pet_Buff_Height"] 				= 9;
QHCONSTANTS["Pet_Raid_Icon_Width"] 			= 9;
QHCONSTANTS["Pet_Raid_Icon_Height"] 			= 9;
QHCONSTANTS["Pet_Raid_Icon_Offset"] 			= 1;

-- RAID FRAME SETTINGS
QHDEFAULT["GLOBAL"]["Raid_Frame_Show"]			= true;
QHDEFAULT["GLOBAL"]["Raid_Position_X"] 			= 12;
QHDEFAULT["GLOBAL"]["Raid_Position_Y"] 			= -110;
QHDEFAULT["GLOBAL"]["Raid_Position_Align"] 		= "TOPLEFT";
QHDEFAULT["GLOBAL"]["Raid_Position_Relative"] 		= "TOPLEFT";
QHDEFAULT["GLOBAL"]["Raid_Position_Anchor"] 		= "UIParent";
QHDEFAULT["GLOBAL"]["Raid_Party_Hide"] 			= true;
QHDEFAULT["GLOBAL"]["Raid_Background_Show"] 		= true;
QHDEFAULT["GLOBAL"]["Raid_Default_Frame_Hide"]		= true;
QHDEFAULT["GLOBAL"]["Raid_Bar_Width"] 			= 40;
QHDEFAULT["GLOBAL"]["Raid_Bar_Height"] 			= 12;
QHDEFAULT["GLOBAL"]["Raid_Rows"] 			= 26;
QHDEFAULT["GLOBAL"]["Raid_Sort_By"] 			= "ROLE";
QHDEFAULT["GLOBAL"]["Raid_Background_Color"] 		= {r=0.0, g=0.0, b=0.0, a=0.75};
QHDEFAULT["GLOBAL"]["Raid_Icon_Show"]			= true;
QHDEFAULT["GLOBAL"]["Raid_Role_Show"]			= true;
QHDEFAULT["GLOBAL"]["Raid_Dynamic_Groups"]		= false;
QHDEFAULT["GLOBAL"]["Raid_Groups"]			= "1;2;3;4;5;6;7;8;";
QHCONSTANTS["Raid_Row_Spacing"] 			= 3;
QHCONSTANTS["Raid_Row_Offset"] 				= 8;
QHCONSTANTS["Raid_Col_Spacing"] 			= 25;
QHCONSTANTS["Raid_Col_Offset"] 				= 8;
QHCONSTANTS["Raid_Class_Order"] 			= "WARRIOR,DEATHKNIGHT,DRUID,PALADIN,PRIEST,SHAMAN,ROGUE,MAGE,WARLOCK,HUNTER,MONK";
QHCONSTANTS["Raid_Name_Position"] 			= 1;
QHCONSTANTS["Raid_Name_Width"] 				= 75;
QHCONSTANTS["Raid_Name_Height"] 			= 12;
QHCONSTANTS["Raid_Name_Text_Position"] 			= "RIGHT";
QHCONSTANTS["Raid_Role_Position"] 			= 2;
QHCONSTANTS["Raid_Bar_Position"] 			= 3;
QHCONSTANTS["Raid_Decurse_Position"] 			= 4;
QHCONSTANTS["Raid_Decurse_Width"] 			= 12;
QHCONSTANTS["Raid_Decurse_Height"] 			= 12;
QHCONSTANTS["Raid_Buff_Width"] 				= 12;
QHCONSTANTS["Raid_Buff_Height"] 			= 12;
QHCONSTANTS["Raid_Raid_Icon_Width"] 			= 12;
QHCONSTANTS["Raid_Raid_Icon_Height"] 			= 12;
QHCONSTANTS["Raid_Raid_Icon_Offset"] 			= 2;
QHCONSTANTS["Raid_Role_Icon_Width"] 			= 12;
QHCONSTANTS["Raid_Role_Icon_Height"] 			= 12;
QHCONSTANTS["Raid_Role_Icon_Offset"] 			= 2;

-- CLASS SETTINGS
QHDEFAULT["WARRIOR"] = {};
QuickHeal:CopyTable(QHDEFAULT["WARRIOR"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["DEATHKNIGHT"] = {};
QuickHeal:CopyTable(QHDEFAULT["DEATHKNIGHT"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["DRUID"] = {};
QuickHeal:CopyTable(QHDEFAULT["DRUID"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["PALADIN"] = {};
QuickHeal:CopyTable(QHDEFAULT["PALADIN"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["PRIEST"] = {};
QuickHeal:CopyTable(QHDEFAULT["PRIEST"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["SHAMAN"] = {};
QuickHeal:CopyTable(QHDEFAULT["SHAMAN"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["ROGUE"] = {};
QuickHeal:CopyTable(QHDEFAULT["ROGUE"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["MAGE"] = {};
QuickHeal:CopyTable(QHDEFAULT["MAGE"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["WARLOCK"] = {};
QuickHeal:CopyTable(QHDEFAULT["WARLOCK"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["HUNTER"] = {};
QuickHeal:CopyTable(QHDEFAULT["HUNTER"], QHDEFAULT["GLOBAL"]);

QHDEFAULT["MONK"] = {};
QuickHeal:CopyTable(QHDEFAULT["MONK"], QHDEFAULT["GLOBAL"]);

-- PRIEST SETTINGS
QHDEFAULT["PRIEST"]["Player_Left_Click"] 		= QH_LOCALE_FLASHHEAL;
QHDEFAULT["PRIEST"]["Player_Shift_Left_Click"] 		= QH_LOCALE_GREATERHEAL;
QHDEFAULT["PRIEST"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["PRIEST"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Left_Click"] 		= QH_LOCALE_FLASHHEAL;
QHDEFAULT["PRIEST"]["Party_Shift_Left_Click"] 		= QH_LOCALE_GREATERHEAL;
QHDEFAULT["PRIEST"]["Party_Ctrl_Left_Click"] 		= QH_LOCALE_BINDINGHEAL;
QHDEFAULT["PRIEST"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Left_Click"] 			= QH_LOCALE_FLASHHEAL;
QHDEFAULT["PRIEST"]["Raid_Shift_Left_Click"] 		= QH_LOCALE_GREATERHEAL;
QHDEFAULT["PRIEST"]["Raid_Ctrl_Left_Click"] 		= QH_LOCALE_BINDINGHEAL;
QHDEFAULT["PRIEST"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["PRIEST"]["Player_Right_Click"] 		= QH_LOCALE_PWSHIELD;
QHDEFAULT["PRIEST"]["Player_Shift_Right_Click"] 	= QH_LOCALE_GUARDIANSPIRIT;
QHDEFAULT["PRIEST"]["Player_Ctrl_Right_Click"] 		= "";
QHDEFAULT["PRIEST"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Right_Click"] 		= QH_LOCALE_PWSHIELD;
QHDEFAULT["PRIEST"]["Party_Shift_Right_Click"] 		= QH_LOCALE_GUARDIANSPIRIT;
QHDEFAULT["PRIEST"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Right_Click"] 		= QH_LOCALE_PWSHIELD;
QHDEFAULT["PRIEST"]["Raid_Shift_Right_Click"] 		= QH_LOCALE_GUARDIANSPIRIT;
QHDEFAULT["PRIEST"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["PRIEST"]["Player_Middle_Click"] 		= QH_LOCALE_PRAYEROFMEND;
QHDEFAULT["PRIEST"]["Player_Shift_Middle_Click"] 	= QH_LOCALE_RENEW;
QHDEFAULT["PRIEST"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["PRIEST"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Middle_Click"] 		= QH_LOCALE_PRAYEROFMEND;
QHDEFAULT["PRIEST"]["Party_Shift_Middle_Click"] 	= QH_LOCALE_RENEW;
QHDEFAULT["PRIEST"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Middle_Click"] 		= QH_LOCALE_PRAYEROFMEND;
QHDEFAULT["PRIEST"]["Raid_Shift_Middle_Click"] 		= QH_LOCALE_RENEW;
QHDEFAULT["PRIEST"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["PRIEST"]["Player_Button4_Click"] 		= "";
QHDEFAULT["PRIEST"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["PRIEST"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["PRIEST"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["PRIEST"]["Party_Button4_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["PRIEST"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["PRIEST"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["PRIEST"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["PRIEST"]["Player_Button5_Click"] 		= "";
QHDEFAULT["PRIEST"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["PRIEST"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["PRIEST"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["PRIEST"]["Party_Button5_Click"] 		= "";
QHDEFAULT["PRIEST"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["PRIEST"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["PRIEST"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["PRIEST"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["PRIEST"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["PRIEST"]["Decurse_Left_Click"] 		= QH_LOCALE_DISPELMAGIC;
QHDEFAULT["PRIEST"]["Decurse_Right_Click"] 		= QH_LOCALE_ABOLISHDISEASE;
QHDEFAULT["PRIEST"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["PRIEST"]["Buff_List"] 			= "Renew; Prayer of Mending; Power Word: Shield";

-- DRUID SETTINGS
QHDEFAULT["DRUID"]["Player_Left_Click"] 		= QH_LOCALE_REGROWTH;
QHDEFAULT["DRUID"]["Player_Shift_Left_Click"] 		= QH_LOCALE_HEALINGTOUCH;
QHDEFAULT["DRUID"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["DRUID"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Left_Click"] 			= QH_LOCALE_REGROWTH;
QHDEFAULT["DRUID"]["Party_Shift_Left_Click"] 		= QH_LOCALE_HEALINGTOUCH;
QHDEFAULT["DRUID"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Left_Click"] 			= QH_LOCALE_REGROWTH;
QHDEFAULT["DRUID"]["Raid_Shift_Left_Click"] 		= QH_LOCALE_HEALINGTOUCH;
QHDEFAULT["DRUID"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["DRUID"]["Player_Right_Click"] 		= QH_LOCALE_LIFEBLOOM;
QHDEFAULT["DRUID"]["Player_Shift_Right_Click"] 		= QH_LOCALE_WILDGROWTH;
QHDEFAULT["DRUID"]["Player_Ctrl_Right_Click"] 		= "";
QHDEFAULT["DRUID"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Right_Click"] 		= QH_LOCALE_LIFEBLOOM;
QHDEFAULT["DRUID"]["Party_Shift_Right_Click"] 		= QH_LOCALE_WILDGROWTH;
QHDEFAULT["DRUID"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Right_Click"] 			= QH_LOCALE_LIFEBLOOM;
QHDEFAULT["DRUID"]["Raid_Shift_Right_Click"] 		= QH_LOCALE_WILDGROWTH;
QHDEFAULT["DRUID"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["DRUID"]["Player_Middle_Click"] 		= QH_LOCALE_REJUVENATION;
QHDEFAULT["DRUID"]["Player_Shift_Middle_Click"] 	= QH_LOCALE_SWIFTMEND;
QHDEFAULT["DRUID"]["Player_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["DRUID"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Middle_Click"] 		= QH_LOCALE_REJUVENATION;
QHDEFAULT["DRUID"]["Party_Shift_Middle_Click"] 		= QH_LOCALE_SWIFTMEND;
QHDEFAULT["DRUID"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Middle_Click"] 		= QH_LOCALE_REJUVENATION;
QHDEFAULT["DRUID"]["Raid_Shift_Middle_Click"] 		= QH_LOCALE_SWIFTMEND;
QHDEFAULT["DRUID"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["DRUID"]["Player_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["DRUID"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["DRUID"]["Player_Alt_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["DRUID"]["Party_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Shift_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["DRUID"]["Player_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["DRUID"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["DRUID"]["Player_Alt_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["DRUID"]["Party_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Shift_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["DRUID"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["DRUID"]["Decurse_Left_Click"] 		= QH_LOCALE_ABOLISH_POISON;
QHDEFAULT["DRUID"]["Decurse_Right_Click"] 		= QH_LOCALE_REMOVE_CURSE;
QHDEFAULT["DRUID"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["DRUID"]["Buff_List"] 			= "Rejuvenation; Regrowth; Wild Growth; Lifebloom";

-- PALADIN SETTINGS
QHDEFAULT["PALADIN"]["Player_Left_Click"] 		= QH_LOCALE_FLASHOFLIGHT;
QHDEFAULT["PALADIN"]["Player_Shift_Left_Click"] 	= QH_LOCALE_HOLYLIGHT;
QHDEFAULT["PALADIN"]["Player_Ctrl_Left_Click"] 		= QH_LOCALE_LAYONHANDS;
QHDEFAULT["PALADIN"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["PALADIN"]["Party_Left_Click"] 		= QH_LOCALE_FLASHOFLIGHT;
QHDEFAULT["PALADIN"]["Party_Shift_Left_Click"] 		= QH_LOCALE_HOLYLIGHT;
QHDEFAULT["PALADIN"]["Party_Ctrl_Left_Click"] 		= QH_LOCALE_LAYONHANDS;
QHDEFAULT["PALADIN"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["PALADIN"]["Raid_Left_Click"] 		= QH_LOCALE_FLASHOFLIGHT;
QHDEFAULT["PALADIN"]["Raid_Shift_Left_Click"] 		= QH_LOCALE_HOLYLIGHT;
QHDEFAULT["PALADIN"]["Raid_Ctrl_Left_Click"] 		= QH_LOCALE_LAYONHANDS;
QHDEFAULT["PALADIN"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["PALADIN"]["Player_Right_Click"] 		= QH_LOCALE_HANDOFPROTECTION;
QHDEFAULT["PALADIN"]["Player_Shift_Right_Click"] 	= QH_LOCALE_HANDOFFREEDOM;
QHDEFAULT["PALADIN"]["Player_Ctrl_Right_Click"] 	= QH_LOCALE_HANDOFSALVATION;
QHDEFAULT["PALADIN"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["PALADIN"]["Party_Right_Click"] 		= QH_LOCALE_HANDOFPROTECTION;
QHDEFAULT["PALADIN"]["Party_Shift_Right_Click"] 	= QH_LOCALE_HANDOFFREEDOM;
QHDEFAULT["PALADIN"]["Party_Ctrl_Right_Click"] 		= QH_LOCALE_HANDOFSALVATION;
QHDEFAULT["PALADIN"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["PALADIN"]["Raid_Right_Click"] 		= QH_LOCALE_HANDOFPROTECTION;
QHDEFAULT["PALADIN"]["Raid_Shift_Right_Click"] 		= QH_LOCALE_HANDOFFREEDOM;
QHDEFAULT["PALADIN"]["Raid_Ctrl_Right_Click"] 		= QH_LOCALE_HANDOFSALVATION;
QHDEFAULT["PALADIN"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["PALADIN"]["Player_Middle_Click"] 		= QH_LOCALE_HOLYSHOCK;
QHDEFAULT["PALADIN"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["PALADIN"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["PALADIN"]["Player_Alt_Middle_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Middle_Click"] 		= QH_LOCALE_HOLYSHOCK;
QHDEFAULT["PALADIN"]["Party_Shift_Middle_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["PALADIN"]["Raid_Middle_Click"] 		= QH_LOCALE_HOLYSHOCK;
QHDEFAULT["PALADIN"]["Raid_Shift_Middle_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["PALADIN"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["PALADIN"]["Player_Button4_Click"] 		= "";
QHDEFAULT["PALADIN"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Button4_Click"] 		= "";
QHDEFAULT["PALADIN"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Alt_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["PALADIN"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["PALADIN"]["Player_Button5_Click"] 		= "";
QHDEFAULT["PALADIN"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Button5_Click"] 		= "";
QHDEFAULT["PALADIN"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Party_Alt_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["PALADIN"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["PALADIN"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["PALADIN"]["Decurse_Left_Click"] 		= QH_LOCALE_CLEANSE;
QHDEFAULT["PALADIN"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["PALADIN"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["PALADIN"]["Buff_List"] 			= "";

-- SHAMAN SETTINGS
QHDEFAULT["SHAMAN"]["Player_Left_Click"] 		= QH_LOCALE_CHAINHEAL;
QHDEFAULT["SHAMAN"]["Player_Shift_Left_Click"] 		= QH_LOCALE_HEALINGWAVE;
QHDEFAULT["SHAMAN"]["Player_Ctrl_Left_Click"] 		= QH_LOCALE_LESSER_HEALINGWAVE;
QHDEFAULT["SHAMAN"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Party_Left_Click"] 		= QH_LOCALE_CHAINHEAL;
QHDEFAULT["SHAMAN"]["Party_Shift_Left_Click"] 		= QH_LOCALE_HEALINGWAVE;
QHDEFAULT["SHAMAN"]["Party_Ctrl_Left_Click"] 		= QH_LOCALE_LESSER_HEALINGWAVE;
QHDEFAULT["SHAMAN"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Left_Click"] 			= QH_LOCALE_CHAINHEAL;
QHDEFAULT["SHAMAN"]["Raid_Shift_Left_Click"] 		= QH_LOCALE_HEALINGWAVE;
QHDEFAULT["SHAMAN"]["Raid_Ctrl_Left_Click"] 		= QH_LOCALE_LESSERHEALINGWAVE;
QHDEFAULT["SHAMAN"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["SHAMAN"]["Player_Right_Click"] 		= QH_LOCALE_EARTHSHIELD;
QHDEFAULT["SHAMAN"]["Player_Shift_Right_Click"] 	= QH_LOCALE_WATERBREATHING;
QHDEFAULT["SHAMAN"]["Player_Ctrl_Right_Click"] 		= QH_LOCALE_WATERWALKING;
QHDEFAULT["SHAMAN"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Party_Right_Click"] 		= QH_LOCALE_EARTHSHIELD;
QHDEFAULT["SHAMAN"]["Party_Shift_Right_Click"] 		= QH_LOCALE_WATERBREATHING;
QHDEFAULT["SHAMAN"]["Party_Ctrl_Right_Click"] 		= QH_LOCALE_WATERWALKING;
QHDEFAULT["SHAMAN"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Right_Click"] 		= QH_LOCALE_EARTHSHIELD;
QHDEFAULT["SHAMAN"]["Raid_Shift_Right_Click"] 		= QH_LOCALE_WATERBREATHING;
QHDEFAULT["SHAMAN"]["Raid_Ctrl_Right_Click"] 		= QH_LOCALE_WATERWALKING;
QHDEFAULT["SHAMAN"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["SHAMAN"]["Player_Middle_Click"] 		= QH_LOCALE_RIPTIDE;
QHDEFAULT["SHAMAN"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Party_Middle_Click"] 		= QH_LOCALE_RIPTIDE;
QHDEFAULT["SHAMAN"]["Party_Shift_Middle_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Middle_Click"] 		= QH_LOCALE_RIPTIDE;
QHDEFAULT["SHAMAN"]["Raid_Shift_Middle_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["SHAMAN"]["Player_Button4_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Button4_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["SHAMAN"]["Player_Button5_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Button5_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["SHAMAN"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["SHAMAN"]["Decurse_Left_Click"] 		= QH_LOCALE_CLEANSESPIRIT;
QHDEFAULT["SHAMAN"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["SHAMAN"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["SHAMAN"]["Buff_List"] 			= "Earth Shield";

-- DEATHKNIGHT SETTINGS
QHDEFAULT["DEATHKNIGHT"]["Player_Left_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Shift_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Ctrl_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Alt_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Left_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Shift_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Ctrl_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Alt_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Left_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Shift_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Ctrl_Left_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Alt_Left_Click"] 	= "";

QHDEFAULT["DEATHKNIGHT"]["Player_Right_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Shift_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Ctrl_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Alt_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Right_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Shift_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Ctrl_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Alt_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Right_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Shift_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Ctrl_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Alt_Right_Click"] 	= "";

QHDEFAULT["DEATHKNIGHT"]["Player_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Alt_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Middle_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Shift_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Alt_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Middle_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Shift_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Alt_Middle_Click"] 	= "";

QHDEFAULT["DEATHKNIGHT"]["Player_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Alt_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Alt_Button4_Click"] 	= "";

QHDEFAULT["DEATHKNIGHT"]["Player_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Party_Alt_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Raid_Alt_Button5_Click"] 	= "";

QHDEFAULT["DEATHKNIGHT"]["Decurse_Left_Click"] 		= "";
QHDEFAULT["DEATHKNIGHT"]["Decurse_Right_Click"] 	= "";
QHDEFAULT["DEATHKNIGHT"]["Decurse_Middle_Click"] 	= "";

QHDEFAULT["DEATHKNIGHT"]["Buff_List"] 			= "";

-- HUNTER SETTINGS
QHDEFAULT["HUNTER"]["Player_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Shift_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Shift_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Left_Click"] 			= "";
QHDEFAULT["HUNTER"]["Raid_Shift_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["HUNTER"]["Player_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Shift_Right_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Ctrl_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Shift_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Shift_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["HUNTER"]["Player_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Shift_Middle_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Shift_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["HUNTER"]["Player_Button4_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Button4_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["HUNTER"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["HUNTER"]["Player_Button5_Click"] 		= "";
QHDEFAULT["HUNTER"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["HUNTER"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Button5_Click"] 		= "";
QHDEFAULT["HUNTER"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["HUNTER"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["HUNTER"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["HUNTER"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["HUNTER"]["Decurse_Left_Click"] 		= "";
QHDEFAULT["HUNTER"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["HUNTER"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["HUNTER"]["Buff_List"] 			= "";

-- MAGE SETTINGS
QHDEFAULT["MAGE"]["Player_Left_Click"] 			= "";
QHDEFAULT["MAGE"]["Player_Shift_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Left_Click"] 			= "";
QHDEFAULT["MAGE"]["Party_Shift_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Left_Click"] 			= "";
QHDEFAULT["MAGE"]["Raid_Shift_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["MAGE"]["Player_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Shift_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Ctrl_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Right_Click"] 			= "";
QHDEFAULT["MAGE"]["Party_Shift_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Right_Click"] 			= "";
QHDEFAULT["MAGE"]["Raid_Shift_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["MAGE"]["Player_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Shift_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Shift_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Middle_Click"] 			= "";
QHDEFAULT["MAGE"]["Raid_Shift_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["MAGE"]["Player_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["MAGE"]["Player_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Alt_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Shift_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Shift_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["MAGE"]["Player_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["MAGE"]["Player_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Player_Alt_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Shift_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Shift_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["MAGE"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["MAGE"]["Decurse_Left_Click"] 		= "";
QHDEFAULT["MAGE"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["MAGE"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["MAGE"]["Buff_List"] 				= "";

-- ROGUE SETTINGS
QHDEFAULT["ROGUE"]["Player_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Shift_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Left_Click"] 			= "";
QHDEFAULT["ROGUE"]["Party_Shift_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Left_Click"] 			= "";
QHDEFAULT["ROGUE"]["Raid_Shift_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["ROGUE"]["Player_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Shift_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Ctrl_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Shift_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Right_Click"] 			= "";
QHDEFAULT["ROGUE"]["Raid_Shift_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["ROGUE"]["Player_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["ROGUE"]["Player_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Shift_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Shift_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["ROGUE"]["Player_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["ROGUE"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["ROGUE"]["Player_Alt_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["ROGUE"]["Party_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Shift_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["ROGUE"]["Player_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["ROGUE"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["ROGUE"]["Player_Alt_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["ROGUE"]["Party_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Shift_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["ROGUE"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["ROGUE"]["Decurse_Left_Click"] 		= "";
QHDEFAULT["ROGUE"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["ROGUE"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["ROGUE"]["Buff_List"] 			= "";

-- WARLOCK SETTINGS
QHDEFAULT["WARLOCK"]["Player_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Player_Shift_Left_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Shift_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Shift_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["WARLOCK"]["Player_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Player_Shift_Right_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Ctrl_Right_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Shift_Right_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Shift_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["WARLOCK"]["Player_Middle_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Alt_Middle_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Middle_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Shift_Middle_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Middle_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Shift_Middle_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["WARLOCK"]["Player_Button4_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Button4_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Alt_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["WARLOCK"]["Player_Button5_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Button5_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Party_Alt_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["WARLOCK"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["WARLOCK"]["Decurse_Left_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["WARLOCK"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["WARLOCK"]["Buff_List"] 			= "";

-- WARRIOR SETTINGS
QHDEFAULT["WARRIOR"]["Player_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Player_Shift_Left_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Shift_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Shift_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["WARRIOR"]["Player_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Player_Shift_Right_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Ctrl_Right_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Shift_Right_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Shift_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["WARRIOR"]["Player_Middle_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Player_Shift_Middle_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Alt_Middle_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Middle_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Shift_Middle_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Ctrl_Middle_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Middle_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Shift_Middle_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["WARRIOR"]["Player_Button4_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Alt_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Button4_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Shift_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Alt_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Shift_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Ctrl_Button4_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["WARRIOR"]["Player_Button5_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Player_Alt_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Button5_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Party_Shift_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Party_Alt_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Raid_Shift_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Ctrl_Button5_Click"] 	= "";
QHDEFAULT["WARRIOR"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["WARRIOR"]["Decurse_Left_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["WARRIOR"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["WARRIOR"]["Buff_List"] 			= "";

-- MONK SETTINGS
QHDEFAULT["MONK"]["Player_Left_Click"] 			= QH_LOCALE_SOOTHINGMIST;
QHDEFAULT["MONK"]["Player_Shift_Left_Click"] 		= QH_LOCALE_SURGINGMIST;
QHDEFAULT["MONK"]["Player_Ctrl_Left_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Alt_Left_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Left_Click"] 			= QH_LOCALE_SOOTHINGMIST;
QHDEFAULT["MONK"]["Party_Shift_Left_Click"] 		= QH_LOCALE_SURGINGMIST;
QHDEFAULT["MONK"]["Party_Ctrl_Left_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Alt_Left_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Left_Click"] 			= QH_LOCALE_SOOTHINGMIST;
QHDEFAULT["MONK"]["Raid_Shift_Left_Click"] 		= QH_LOCALE_SURGINGMIST;
QHDEFAULT["MONK"]["Raid_Ctrl_Left_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Alt_Left_Click"] 		= "";

QHDEFAULT["MONK"]["Player_Right_Click"] 		= QH_LOCALE_LIFECOCOON;
QHDEFAULT["MONK"]["Player_Shift_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Ctrl_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Alt_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Right_Click"] 			= QH_LOCALE_LIFECOCOON;
QHDEFAULT["MONK"]["Party_Shift_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Ctrl_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Alt_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Right_Click"] 			= QH_LOCALE_LIFECOCOON;
QHDEFAULT["MONK"]["Raid_Shift_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Ctrl_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Alt_Right_Click"] 		= "";

QHDEFAULT["MONK"]["Player_Middle_Click"] 		= QH_LOCALE_RENEWINGMIST;
QHDEFAULT["MONK"]["Player_Shift_Middle_Click"] 		= QH_LOCALE_ENVELOPINGMIST;
QHDEFAULT["MONK"]["Player_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Alt_Middle_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Middle_Click"] 		= QH_LOCALE_RENEWINGMIST;
QHDEFAULT["MONK"]["Party_Shift_Middle_Click"] 		= QH_LOCALE_ENVELOPINGMIST;
QHDEFAULT["MONK"]["Party_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Alt_Middle_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Middle_Click"] 			= QH_LOCALE_RENEWINGMIST;
QHDEFAULT["MONK"]["Raid_Shift_Middle_Click"] 		= QH_LOCALE_ENVELOPINGMIST;
QHDEFAULT["MONK"]["Raid_Ctrl_Middle_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Alt_Middle_Click"] 		= "";

QHDEFAULT["MONK"]["Player_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Shift_Button4_Click"] 	= "";
QHDEFAULT["MONK"]["Player_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Alt_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Shift_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Alt_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Shift_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Ctrl_Button4_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Alt_Button4_Click"] 		= "";

QHDEFAULT["MONK"]["Player_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Shift_Button5_Click"] 	= "";
QHDEFAULT["MONK"]["Player_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Player_Alt_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Shift_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Party_Alt_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Shift_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Ctrl_Button5_Click"] 		= "";
QHDEFAULT["MONK"]["Raid_Alt_Button5_Click"] 		= "";

QHDEFAULT["MONK"]["Decurse_Left_Click"] 		= QH_LOCALE_DETOX;
QHDEFAULT["MONK"]["Decurse_Right_Click"] 		= "";
QHDEFAULT["MONK"]["Decurse_Middle_Click"] 		= "";

QHDEFAULT["MONK"]["Buff_List"] 				= "Renewing Mist; Enveloping Mist; Life Cocoon;";

---------------------------------------------------------------------------------------------
-- QuickHeal Binding Variables
---------------------------------------------------------------------------------------------
BINDING_NAME_QUICKHEAL2 = QH_LOCALE_BINDING;
BINDING_HEADER_QUICKHEAL2 = QH_LOCALE_HEADER;

QHProfile2 = {};
QH = QuickHeal:new();