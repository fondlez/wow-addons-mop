﻿---------------------------------------------------------------------------------------------
-- QuickHeal Standard Instance and Raid Warnings
---------------------------------------------------------------------------------------------
QHWARNINGS = {};

-- English
QHWARNINGS["enUS"] = {};
QHWARNINGS["enUS"]["Naxxramas"] = "NAXX";
QHWARNINGS["enUS"]["The Obsidian Sanctum"] = "OS";
QHWARNINGS["enUS"]["The Ruby Sanctum"] = "RS";
QHWARNINGS["enUS"]["The Eye of Eternity"] = "EOE";
QHWARNINGS["enUS"]["Vault of Archavon"] = "VOA";
QHWARNINGS["enUS"]["Ulduar"] = "ULD";
QHWARNINGS["enUS"]["Trial of the Crusader"] = "TOC"; 
QHWARNINGS["enUS"]["Onyxia's Lair"] = "ONY";
QHWARNINGS["enUS"]["Icecrown Citadel"] = "ICC";

-- French
QHWARNINGS["frFR"] = {};
QHWARNINGS["frFR"]["Naxxramas"] = "NAXX";
QHWARNINGS["frFR"]["Le sanctum Obsidien"] = "OS";
QHWARNINGS["frFR"]["Le sanctum Obsidien"] = "RS";
QHWARNINGS["frFR"]["L'Œil de l'éternité"] = "EOE";
QHWARNINGS["frFR"]["Caveau d'Archavon"] = "VOA";
QHWARNINGS["frFR"]["Ulduar"] = "ULD"; 
QHWARNINGS["frFR"]["L'épreuve du croisé"] = "TOC"; 
QHWARNINGS["frFR"]["Repaire d'Onyxia"] = "ONY";
QHWARNINGS["frFR"]["Citadelle de la Couronne de glace"] = "ICC";

-- German
QHWARNINGS["deDE"] = {};
QHWARNINGS["deDE"]["Naxxramas"] = "NAXX";
QHWARNINGS["deDE"]["Das Obsidiansanktum"] = "OS";
QHWARNINGS["deDE"]["Das Rubinsanktum"] = "RS";
QHWARNINGS["deDE"]["Das Auge der Ewigkeit"] = "EOE";
QHWARNINGS["deDE"]["Archavons Kammer"] = "VOA";
QHWARNINGS["deDE"]["Ulduar"] = "ULD"; 
QHWARNINGS["deDE"]["Prüfung des Kreuzfahrers"] = "TOC"; 
QHWARNINGS["deDE"]["Onyxias Hort"] = "ONY";
QHWARNINGS["deDE"]["Eiskronenzitadelle"] = "ICC";

-- Korean
QHWARNINGS["koKR"] = {};
QHWARNINGS["koKR"]["Naxxramas"] = "NAXX";
QHWARNINGS["koKR"]["흑요석 성소"] = "OS";
QHWARNINGS["koKR"]["루비 성소"] = "RS";
QHWARNINGS["koKR"]["영원의 눈"] = "EOE";
QHWARNINGS["koKR"]["아카본 석실"] = "VOA";
QHWARNINGS["koKR"]["울두아르"] = "ULD"; 
QHWARNINGS["koKR"]["Trial of the Crusader"] = "TOC"; 
QHWARNINGS["koKR"]["오닉시아의 둥지"] = "ONY";
QHWARNINGS["koKR"]["얼음왕관 성채"] = "ICC";

-- Chinese (Simplified)
QHWARNINGS["zhCN"] = {};
QHWARNINGS["zhCN"]["Naxxramas"] = "NAXX";
QHWARNINGS["zhCN"]["The Obsidian Sanctum"] = "OS";
QHWARNINGS["zhCN"]["The Ruby Sanctum"] = "RS";
QHWARNINGS["zhCN"]["永恆之眼"] = "EOE";
QHWARNINGS["zhCN"]["风暴之眼"] = "VOA";
QHWARNINGS["zhCN"]["Ulduar"] = "ULD"; 
QHWARNINGS["zhCN"]["Trial of the Crusader"] = "TOC"; 
QHWARNINGS["zhCN"]["Onyxia's Lair"] = "ONY";
QHWARNINGS["zhCN"]["Icecrown Citadel"] = "ICC";

-- Chinese (Traditional)
QHWARNINGS["zhTW"] = {};
QHWARNINGS["zhTW"]["Naxxramas"] = "NAXX";
QHWARNINGS["zhTW"]["黑曜聖所"] = "OS";
QHWARNINGS["zhTW"]["晶紅聖所"] = "RS";
QHWARNINGS["zhTW"]["永恆之眼"] = "EOE";
QHWARNINGS["zhTW"]["亞夏梵穹殿"] = "VOA";
QHWARNINGS["zhTW"]["奧杜亞"] = "ULD"; 
QHWARNINGS["zhTW"]["Trial of the Crusader"] = "TOC"; 
QHWARNINGS["zhTW"]["奧妮克希亞的巢穴"] = "ONY";
QHWARNINGS["zhTW"]["冰冠城塞"] = "ICC";

-- Russian
QHWARNINGS["ruRU"] = {};
QHWARNINGS["ruRU"]["Наксрамас"] = "NAXX";
QHWARNINGS["ruRU"]["Обсидиановое святилище"] = "OS";
QHWARNINGS["ruRU"]["Рубиновое святилище"] = "RS";
QHWARNINGS["ruRU"]["Око Вечности"] = "EOE";
QHWARNINGS["ruRU"]["Склеп Аркавона"] = "VOA";
QHWARNINGS["ruRU"]["Ульдуар"] = "ULD"; 
QHWARNINGS["ruRU"]["Испытание крестоносца"] = "TOC"; 
QHWARNINGS["ruRU"]["Логово Ониксии"] = "ONY";
QHWARNINGS["ruRU"]["Цитадель Ледяной Короны"] = "ICC";

-- Spanish (Spain)
QHWARNINGS["esES"] = {};
QHWARNINGS["esES"]["Naxxramas"] = "NAXX";
QHWARNINGS["esES"]["El Sagrario Obsidiana"] = "OS";
QHWARNINGS["esES"]["El Sagrario Obsidiana"] = "RS";
QHWARNINGS["esES"]["El Ojo de la Eternidad"] = "EOE";
QHWARNINGS["esES"]["La Cámara de Archavon"] = "VOA";
QHWARNINGS["esES"]["Ulduar"] = "ULD"; 
QHWARNINGS["esES"]["Prueba del Cruzado"] = "TOC"; 
QHWARNINGS["esES"]["Guarida de Onyxia"] = "ONY";
QHWARNINGS["esES"]["Ciudadela de la Corona de Hielo"] = "ICC";

-- Spanish (Mexico)
QHWARNINGS["esMX"] = {};
QHWARNINGS["esMX"]["Naxxramas"] = "NAXX";
QHWARNINGS["esMX"]["El Sagrario Obsidiana"] = "OS";
QHWARNINGS["esMX"]["El Sagrario Obsidiana"] = "RS";
QHWARNINGS["esMX"]["El Ojo de la Eternidad"] = "EOE";
QHWARNINGS["esMX"]["La Cámara de Archavon"] = "VOA";
QHWARNINGS["esMX"]["Ulduar"] = "ULD"; 
QHWARNINGS["esMX"]["Prueba del Cruzado"] = "TOC"; 
QHWARNINGS["esMX"]["Guarida de Onyxia"] = "ONY";
QHWARNINGS["esMX"]["Ciudadela de la Corona de Hielo"] = "ICC";

---------------------------------------------------------------------------------------------
-- Naxxramas
---------------------------------------------------------------------------------------------
QHWARNINGS["NAXX"] = {};
QHWARNINGS["NAXX"]["enUS"] = "Naxxramas";
QHWARNINGS["NAXX"]["frFR"] = "Naxxramas";
QHWARNINGS["NAXX"]["deDE"] = "Naxxramas";
QHWARNINGS["NAXX"]["koKR"] = "Naxxramas";
QHWARNINGS["NAXX"]["zhCN"] = "Naxxramas";
QHWARNINGS["NAXX"]["zhTW"] = "Naxxramas";
QHWARNINGS["NAXX"]["ruRU"] = "Naxxramas";
QHWARNINGS["NAXX"]["esES"] = "Naxxramas";
QHWARNINGS["NAXX"]["esMX"] = "Naxxramas";
QHWARNINGS["NAXX"]["Warning_List"] = 
[=[
Locust Swarm; 
Poison Bolt Volley; 
Web Wrap; 
Decrepit Fever; 
Mutating Injection; 
Life Drain; 
Frost Blast;
]=];

---------------------------------------------------------------------------------------------
-- The Obsidian Sanctum
---------------------------------------------------------------------------------------------
QHWARNINGS["OS"] = {};
QHWARNINGS["OS"]["enUS"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["frFR"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["deDE"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["koKR"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["zhCN"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["zhTW"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["ruRU"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["esES"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["esMX"] = "The Obsidian Sanctum";
QHWARNINGS["OS"]["Warning_List"] = 
[=[
]=];

---------------------------------------------------------------------------------------------
-- The Eye of Eternity
---------------------------------------------------------------------------------------------
QHWARNINGS["EOE"] = {};
QHWARNINGS["EOE"]["enUS"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["frFR"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["deDE"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["koKR"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["zhCN"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["zhTW"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["ruRU"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["esES"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["esMX"] = "The Eye of Eternity";
QHWARNINGS["EOE"]["Warning_List"] = 
[=[
]=];

---------------------------------------------------------------------------------------------
-- Vault of Archavon
---------------------------------------------------------------------------------------------
QHWARNINGS["VOA"] = {};
QHWARNINGS["VOA"]["enUS"] = "Vault of Archavon";
QHWARNINGS["VOA"]["frFR"] = "Vault of Archavon";
QHWARNINGS["VOA"]["deDE"] = "Vault of Archavon";
QHWARNINGS["VOA"]["koKR"] = "Vault of Archavon";
QHWARNINGS["VOA"]["zhCN"] = "Vault of Archavon";
QHWARNINGS["VOA"]["zhTW"] = "Vault of Archavon";
QHWARNINGS["VOA"]["ruRU"] = "Vault of Archavon";
QHWARNINGS["VOA"]["esES"] = "Vault of Archavon";
QHWARNINGS["VOA"]["esMX"] = "Vault of Archavon";
QHWARNINGS["VOA"]["Warning_List"] = 
[=[
]=];

---------------------------------------------------------------------------------------------
-- Ulduar
---------------------------------------------------------------------------------------------
QHWARNINGS["ULD"] = {};
QHWARNINGS["ULD"]["enUS"] = "Ulduar";
QHWARNINGS["ULD"]["frFR"] = "Ulduar";
QHWARNINGS["ULD"]["deDE"] = "Ulduar";
QHWARNINGS["ULD"]["koKR"] = "Ulduar";
QHWARNINGS["ULD"]["zhCN"] = "Ulduar";
QHWARNINGS["ULD"]["zhTW"] = "Ulduar";
QHWARNINGS["ULD"]["ruRU"] = "Ulduar";
QHWARNINGS["ULD"]["esES"] = "Ulduar";
QHWARNINGS["ULD"]["esMX"] = "Ulduar";
QHWARNINGS["ULD"]["Warning_List"] = 
[=[
Slag Pot; 
Searing Light; 
Fusion Punch; 
Stone Grip; 
Savage Pounce; 
Rip Flesh; 
Unbalancing Strike; 
Flash Freeze; 
Nature’s Fury; 
Strengthened Iron Roots; 
Napalm Shell; 
Plasma Blast; 
Mark of the Faceless; 
Sara's Fervor; 
Malady of the Mind; 
Squeeze; Apathy; 
Black Plague; 
Curse of Doom; 
Draining Poison;
]=];

---------------------------------------------------------------------------------------------
-- Trial of the Crusader
---------------------------------------------------------------------------------------------
QHWARNINGS["TOC"] = {};
QHWARNINGS["TOC"]["enUS"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["frFR"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["deDE"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["koKR"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["zhCN"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["zhTW"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["ruRU"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["esES"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["esMX"] = "Trial of the Crusader";
QHWARNINGS["TOC"]["Warning_List"] = 
[=[
Impale; 
Paralytic Toxin; 
Burning Bile; 
Arctic Breath; 
Incinerate Flesh; 
Legion Flame; 
Spinning Pain Spike; 
Mistress' Kiss; 
Mortal Strike; 
Penetrating Cold; 
Acid-Drenched Mandibles;
]=];

---------------------------------------------------------------------------------------------
-- Onyxia's Lair
---------------------------------------------------------------------------------------------
QHWARNINGS["ONY"] = {};
QHWARNINGS["ONY"]["enUS"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["frFR"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["deDE"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["koKR"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["zhCN"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["zhTW"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["ruRU"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["esES"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["esMX"] = "Onyxia's Lair";
QHWARNINGS["ONY"]["Warning_List"] = 
[=[
Pierce Armor;
]=];

---------------------------------------------------------------------------------------------
-- Icecrown Citadel
---------------------------------------------------------------------------------------------
QHWARNINGS["ICC"] = {};
QHWARNINGS["ICC"]["enUS"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["frFR"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["deDE"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["koKR"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["zhCN"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["zhTW"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["ruRU"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["esES"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["esMX"] = "Icecrown Citadel";
QHWARNINGS["ICC"]["Warning_List"] = 
[=[
Impaled; 
Boiling Blood; 
Mark of the Fallen Champion;
Gas Spore;
Mutated Infection;
Gaseous Bloat;
Pact of the Darkfallen;
Ice Tomb;
Necrotic Plague;
Harvest Soul;
]=];