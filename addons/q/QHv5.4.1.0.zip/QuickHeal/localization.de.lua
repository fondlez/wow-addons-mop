-- German
if ( GetLocale() == "deDE" ) then
---------------------------------------------------------------------------------------------
-- Localization Translations
---------------------------------------------------------------------------------------------
QH_LOCALE_FLASHHEAL =		"Blitzheilung";
QH_LOCALE_GREATERHEAL =		"Gro�e Heilung";
QH_LOCALE_BINDINGHEAL =		"Verbindende Heilung";
QH_LOCALE_PRAYEROFMEND =	"Gebet der Besserung";
QH_LOCALE_RENEW =		"Erneuerung";
QH_LOCALE_PWSHIELD =		"Machtwort: Schild";
QH_LOCALE_GUARDIANSPIRIT =	"Schutzgeist";
QH_LOCALE_CIRCLEHEAL =		"Kreis der Heilung";
QH_LOCALE_PENANCE =		"S�hne";
QH_LOCALE_DISPELMAGIC =		"Magiebannung";
QH_LOCALE_ABOLISHDISEASE =	"Krankheit aufheben";

QH_LOCALE_HEALINGTOUCH =	"Heilende Ber�hrung";
QH_LOCALE_REGROWTH =		"Nachwachsen";
QH_LOCALE_REJUVENATION = 	"Verj�ngung";
QH_LOCALE_LIFEBLOOM = 		"Bl�hendes Leben";
QH_LOCALE_WILDGROWTH =		"Wildwuchs";
QH_LOCALE_NOURISH =		"Pflege";
QH_LOCALE_TRANQUILITY =		"Gelassenheit";
QH_LOCALE_SWIFTMEND =		"Rasche Heilung";
QH_LOCALE_ABOLISH_POISON =	"Vergiftung aufheben";
QH_LOCALE_REMOVE_CURSE =	"Fluch aufheben";

QH_LOCALE_HOLYLIGHT = 		"Heiliges Licht";
QH_LOCALE_FLASHOFLIGHT = 	"Lichtblitz";
QH_LOCALE_LAYONHANDS =		"Handauflegung";
QH_LOCALE_DIVINESHIELD =	"Gottesschild";
QH_LOCALE_DIVINEPROTECTION =	"G�ttlicher Schutz";
QH_LOCALE_DIVINEINTERVENTION =	"G�ttliches Eingreifen";
QH_LOCALE_HANDOFFREEDOM =	"Hand der Freiheit";
QH_LOCALE_HANDOFPROTECTION =	"Hand des Schutzes";
QH_LOCALE_HANDOFSACRIFICE =	"Hand der Aufopferung";
QH_LOCALE_HANDOFSALVATION =	"Hand der Erl�sung";
QH_LOCALE_RIGHTEOUSDEFENSE = 	"Rechtschaffene Verteidigung";
QH_LOCALE_CLEANSE = 		"Reinigung des Glaubens";

QH_LOCALE_HEALINGWAVE =		"Welle der Heilung";
QH_LOCALE_LESSERHEALINGWAVE =	"Geringe Welle der Heilung";
QH_LOCALE_CHAINHEAL =		"Kettenheilung";
QH_LOCALE_RIPTIDE =		"Springflut";
QH_LOCALE_EARTHSHIELD =		"Erdschild";
QH_LOCALE_WATERWALKING =	"Wasserwandeln";
QH_LOCALE_WATERBREATHING =	"Wasseratmung";
QH_LOCALE_CLEANSESPIRIT =	"Geistl�uterung";

QH_LOCALE_DRUIDRES =		"Wiederbelebung";
QH_LOCALE_DRUIDBATTLERES =	"Wiedergeburt";
QH_LOCALE_PALADINRES =		"Erl\195\182sung";
QH_LOCALE_PRIESTRES =		"Auferstehung";
QH_LOCALE_SHAMANSELFRES	=	"Reinkarnation";
QH_LOCALE_SHAMANRES =		"Geist der Ahnen";
QH_LOCALE_MONKRES =		"Wiederbeleben";
QH_LOCALE_DEATHKNIGHTRES = 	"Verb�ndeten erwecken";
QH_LOCALE_DRUIDRANGE =		"Verj�ngung";
QH_LOCALE_PALADINRANGE =	"Wort der Herrlichkeit";
QH_LOCALE_SHAMANRANGE =		"Heilende Woge";
QH_LOCALE_PRIESTRANGE =		"Blitzheilung";
QH_LOCALE_MONKRANGE = 		"Beruhigender Nebel";

QH_LOCALE_SOOTHINGMIST =	"Beruhigender Nebel";
QH_LOCALE_SURGINGMIST =		"Wallender Nebel";
QH_LOCALE_RENEWINGMIST = 	"Erneuernder Nebel";
QH_LOCALE_ENVELOPINGMIST =	"Einh�llender Nebel";
QH_LOCALE_LIFECOCOON =		"Lebenskokon";
QH_LOCALE_EXPELHARM =		"Schadensumleitung";
QH_LOCALE_DETOX = 		"Entgiftung";

QH_LOCALE_LEFT =		"Left Click";
QH_LOCALE_LEFTSHIFT =		"Shift-Left Click";
QH_LOCALE_LEFTCTRL =		"Ctrl-Left Click";
QH_LOCALE_LEFTALT =		"Alt-Left Click";
QH_LOCALE_MIDDLE =		"Middle Click";
QH_LOCALE_MIDDLESHIFT =		"Shift-Middle Click";
QH_LOCALE_MIDDLECTRL =		"Ctrl-Middle Click";
QH_LOCALE_MIDDLEALT =		"Alt-Middle Click";
QH_LOCALE_RIGHT =		"Right Click";
QH_LOCALE_RIGHTSHIFT =		"Shift-Right Click";
QH_LOCALE_RIGHTCTRL =		"Ctrl-Right Click";
QH_LOCALE_RIGHTALT =		"Alt-Right Click";
QH_LOCALE_BUTTON4 =		"Button4 Click";
QH_LOCALE_BUTTON4SHIFT =	"Button4-Shift Click";
QH_LOCALE_BUTTON4CTRL =		"Button4-Ctrl Click";
QH_LOCALE_BUTTON4ALT =		"Button4-Alt Click";
QH_LOCALE_BUTTON5 =		"Button5 Click";
QH_LOCALE_BUTTON5SHIFT =	"Button5-Shift Click";
QH_LOCALE_BUTTON5CTRL =		"Button5-Ctrl Click";
QH_LOCALE_BUTTON5ALT =		"Button5-Alt Click";

QH_LOCALE_RAIDTAB =		"RAID";
QH_LOCALE_SUBOPTIONS1 =		"RAID FRAME";
QH_LOCALE_PARTYTAB =		"PARTY";
QH_LOCALE_PLAYERTAB =		"PLAYER";
QH_LOCALE_OPTIONSTAB =		"OPTIONS";
QH_LOCALE_BINDING =		"�ffnen Sie Wahlen"
QH_LOCALE_HEADER =		"QuickHeal2";
QH_LOCALE_DECURSETAB =		"DECURSE";
QH_LOCALE_BUFFTAB =		"HOTS";
QH_LOCALE_PROFILETAB =		"PROFILE";
QH_LOCALE_PLAYERBAR =		"Spieler-Stab";
QH_LOCALE_PARTYBARS =		"Partei-St�be";
QH_LOCALE_RAIDBARS =		"�berfall-St�be";
QH_LOCALE_DECURSEBUTTON =	"Decurse/Warnungen";
QH_LOCALE_BUFFBARS =		"HoT Anzeige";
QH_LOCALE_PROFILES =		"Profile";

QH_LOCALE_OKAY = 		"OK";
QH_LOCALE_DEFAULT = 		"Zur�ckstellen";
QH_LOCALE_LOAD = 		"Last";
QH_LOCALE_SAVE = 		"Au\67er";
QH_LOCALE_DELETE =		"L�schung";
QH_LOCALE_LOADLABEL =		"Last speicherte Profil-Einstellungen";
QH_LOCALE_SAVELABEL =		"Verursachen Sie neue Profil-Einstellungen";
QH_LOCALE_HELP = 		"Verwenden Sie /QH2, um Wahlen zu �ffnen";
QH_LOCALE_THANKS = 		"Danke f�r Downloading ";
QH_LOCALE_CONFIGURE =		"Verwenden Sie /QH2, um Ihre Benutzereinstellungen zusammenzubauen.";
QH_LOCALE_SUPPORT = 		"St�tzen Sie uns bitte an:";
QH_LOCALE_SUPPORTLINK =		"http://quickhealmod.blogspot.com";
QH_LOCALE_UPDATENOTICE = 	"Es gibt eine neue Version von vorhandenem QuickHeal2!";
QH_LOCALE_UPDATEINSTRUCT =	"Laden Sie bitte die sp�teste Version hier herunter:";
QH_LOCALE_CHANGES =		"[Anmerkung: Etwas �nderungen treten bis nicht aus Kampf heraus in Kraft]";

QH_LOCALE_TRANSPARENCY =	"Schaden-Stab-Transparent";
QH_LOCALE_ROWCOUNT =		"Reihen";
QH_LOCALE_BARTEXT =		"Anzeigen-Schaden-Stab-Werte";
QH_LOCALE_BARHEIGHT =		"Schaden-Stab-H�he";
QH_LOCALE_BARWIDTH =		"Schaden-Stab-Breite";
QH_LOCALE_TARGETADJUST = 	"Sperrungs-Ziel-Rahmen-Justage";
QH_LOCALE_RAIDSORT =		"Art vorbei";
QH_LOCALE_RANGECHECK =		"Erm�glichen Sie der Strecken-Pr�fung [40 yards]";
QH_LOCALE_PARTYHIDE =		"Fell-Partei-Schnittstelle im �berfall";
QH_LOCALE_RAIDENABLED =		"Erm�glichen Sie QuickHeal2 �berfall-Rahmen";
QH_LOCALE_RFBACKDROP =		"Zeigen Sie �berfall-Rahmen-Hintergrund";
QH_LOCALE_BARBACKDROP =		"Zeigen Sie Stab-Hintergrund";
QH_LOCALE_RFBACKDROPTRANS =	"Transparent";
QH_LOCALE_SHOWDEBUFFS =		"Anzeigenheilungkrankheit";
QH_LOCALE_HIDENOTINRANGE =	"Display-Units aus Strecke [75% Transparent] heraus";
QH_LOCALE_ALWAYSSHOWSPARK =	"Zeigen Sie immer Schaden-Stab-Funken";
QH_LOCALE_THROTTLERAID =	"�berfall erneuert, mehr erneuert = niedrigeres fps";

QH_LOCALE_HIDERAIDFRAME =	"Fell-R�ckstellungs-�berfall-Rahmen";
QH_LOCALE_SHOWTHREAT =		"Zeigen Sie Drohung-Status";
QH_LOCALE_SPECLABEL =		"PROFIL-TALENT-SPEZIALISIERUNG-ABWECHSELNDES EIN- UND AUSLAGERN";
QH_LOCALE_SPECSWAP =		"Tauschen-Profile auf Talent-Spezialisierung-�nderung";
QH_LOCALE_SPEC1LABEL =		"Prim�rtalent-Profil";
QH_LOCALE_SPEC2LABEL =		"Sekund�rtalent-Profil";

-- NOT USED
QH_LOCALE_RUNNING = 		"Quick Heal Enabled";
QH_LOCALE_RESURRECTION = 	"Use Left Click to Resurrect Dead Party Members";
QH_LOCALE_MOVERAID =		"[To Move Raid Frame Hold Shift and Drag]";
QH_LOCALE_RESETCONFIRM =	"Are you sure you want to reset settings?";

end
