-- French
if ( GetLocale() == "frFR" ) then
---------------------------------------------------------------------------------------------
-- Localization Translations
---------------------------------------------------------------------------------------------
QH_LOCALE_FLASHHEAL =		"Soins rapides";
QH_LOCALE_GREATERHEAL =		"Soins supérieurs";
QH_LOCALE_BINDINGHEAL =		"Soins de lien";
QH_LOCALE_PRAYEROFMEND =	"Prière de guérison";
QH_LOCALE_RENEW =		"Rénovation";
QH_LOCALE_PWSHIELD =		"Mot de pouvoir : Bouclier";
QH_LOCALE_GUARDIANSPIRIT =	"Esprit gardien";
QH_LOCALE_CIRCLEHEAL =		"Cercle de soins";
QH_LOCALE_PENANCE =		"Pénitence";
QH_LOCALE_DISPELMAGIC =		"Dissipation de la magie";
QH_LOCALE_ABOLISHDISEASE =	"Abolir maladie";

QH_LOCALE_HEALINGTOUCH =	"Toucher guérisseur";
QH_LOCALE_REGROWTH =		"Rétablissement";
QH_LOCALE_REJUVENATION = 	"Récupération";
QH_LOCALE_LIFEBLOOM = 		"Fleur de vie";
QH_LOCALE_WILDGROWTH =		"Croissance sauvage";
QH_LOCALE_NOURISH =		"Nourrir";
QH_LOCALE_TRANQUILITY =		"Tranquillité";
QH_LOCALE_SWIFTMEND =		"Prompte guérison";
QH_LOCALE_ABOLISH_POISON =	"Abolir le poison";
QH_LOCALE_REMOVE_CURSE =	"Délivrance de la malédiction";

QH_LOCALE_HOLYLIGHT = 		"Lumière sacrée";
QH_LOCALE_FLASHOFLIGHT = 	"Eclair lumineux";
QH_LOCALE_LAYONHANDS =		"Imposition des mains";
QH_LOCALE_DIVINESHIELD =	"Bouclier divin";
QH_LOCALE_DIVINEPROTECTION =	"Protection divine";
QH_LOCALE_DIVINEINTERVENTION =	"Intervention divine";
QH_LOCALE_HANDOFFREEDOM =	"Main de liberté";
QH_LOCALE_HANDOFPROTECTION =	"Main de protection";
QH_LOCALE_HANDOFSACRIFICE =	"Main de sacrifice";
QH_LOCALE_HANDOFSALVATION =	"Main de salut";
QH_LOCALE_RIGHTEOUSDEFENSE = 	"Défense vertueuse";
QH_LOCALE_CLEANSE = 		"Epuration";

QH_LOCALE_HEALINGWAVE =		"Vague de soins";
QH_LOCALE_LESSERHEALINGWAVE =	"Vague de soins inférieurs";
QH_LOCALE_CHAINHEAL =		"Salve de guérison";
QH_LOCALE_RIPTIDE =		"Remous";
QH_LOCALE_EARTHSHIELD =		"Bouclier de terre";
QH_LOCALE_WATERWALKING =	"Marche sur l’eau";
QH_LOCALE_WATERBREATHING =	"Respiration aquatique";
QH_LOCALE_CLEANSESPIRIT =	"Purifier l'esprit";

QH_LOCALE_DRUIDRES =		"Ressusciter";
QH_LOCALE_DRUIDBATTLERES = 	"Renaissance";
QH_LOCALE_PALADINRES = 		"Rédemption";
QH_LOCALE_PRIESTRES = 		"Résurrection";
QH_LOCALE_SHAMANSELFRES	=	"Réincarnation";
QH_LOCALE_SHAMANRES = 		"Esprit ancestral";
QH_LOCALE_MONKRES =		"Ranimer";
QH_LOCALE_DEATHKNIGHTRES = 	"Réanimation d'un allié";
QH_LOCALE_DRUIDRANGE = 		"Récupération";
QH_LOCALE_PALADINRANGE = 	"Mot de gloire";
QH_LOCALE_SHAMANRANGE = 	"Afflux de soins";
QH_LOCALE_PRIESTRANGE = 	"Soins rapides";
QH_LOCALE_MONKRANGE = 		"Brume apaisante";

QH_LOCALE_SOOTHINGMIST =	"Brume apaisante";
QH_LOCALE_SURGINGMIST =		"Déferlante de brume";
QH_LOCALE_RENEWINGMIST = 	"Brume de rénovation";
QH_LOCALE_ENVELOPINGMIST =	"Brume enveloppante";
QH_LOCALE_LIFECOCOON =		"Cocon de vie";
QH_LOCALE_EXPELHARM =		"Extraction du mal";
QH_LOCALE_DETOX = 		"Détoxification";

QH_LOCALE_LEFT = 		"Click gauche";
QH_LOCALE_LEFTSHIFT = 		"Shift-Click Gauche";
QH_LOCALE_LEFTCTRL = 		"Ctrl-Click Gauche";
QH_LOCALE_LEFTALT = 		"Alt-Click Gauche";
QH_LOCALE_MIDDLE = 		"Click du milieu";
QH_LOCALE_MIDDLESHIFT = 	"Shift-Click du milieu";
QH_LOCALE_MIDDLECTRL = 		"Ctrl-Click du milieu";
QH_LOCALE_MIDDLEALT = 		"Alt-Click du milieu";
QH_LOCALE_RIGHT = 		"Click Droit";
QH_LOCALE_RIGHTSHIFT = 		"Shift-Click Droit";
QH_LOCALE_RIGHTCTRL = 		"Ctrl-Click Droit";
QH_LOCALE_RIGHTALT = 		"Alt-Click Droit";
QH_LOCALE_FOUR = 		"Bouton 4-Click";
QH_LOCALE_FOURSHIFT = 		"Bouton 4-Shift Click";
QH_LOCALE_FOURCTRL = 		"Bouton 4-Ctrl Click";
QH_LOCALE_FOURALT = 		"Bouton 4-Alt Click";
QH_LOCALE_FIVE = 		"Bouton 5-Click";
QH_LOCALE_FIVESHIFT = 		"Bouton 5-Shift Click";
QH_LOCALE_FIVECTRL = 		"Bouton 5-Ctrl Click";
QH_LOCALE_FIVEALT = 		"Bouton 5-Alt Click"; 

QH_LOCALE_RAIDTAB =		"INCURSION";
QH_LOCALE_SUBOPTIONS1 =		"ARMATURE DE RAID";
QH_LOCALE_PARTYTAB =		"GROUPE";
QH_LOCALE_PLAYERTAB =		"JOUEUR";
QH_LOCALE_OPTIONSTAB =		"OPTIONS";
QH_LOCALE_BINDING =		"Ouvrez les options"
QH_LOCALE_HEADER =		"QuickHeal2";
QH_LOCALE_DECURSETAB =		"DECURSE";
QH_LOCALE_BUFFTAB =		"HOTS";
QH_LOCALE_PROFILETAB =		"PROFILS";
QH_LOCALE_PLAYERBAR =		"Barre de joueur";
QH_LOCALE_PARTYBARS =		"Barres de partie";
QH_LOCALE_RAIDBARS =		"Barres d'incursion";
QH_LOCALE_DECURSEBUTTON =	"Decurse/Avertissements";
QH_LOCALE_BUFFBARS =		"Affichage HoT";
QH_LOCALE_PROFILES =		"Profils";

QH_LOCALE_OKAY = 		"Ok";
QH_LOCALE_DEFAULT = 		"Reset";
QH_LOCALE_LOAD = 		"Charge";
QH_LOCALE_SAVE = 		"Sauf";
QH_LOCALE_DELETE =		"Suppression";
QH_LOCALE_LOADLABEL =		"La charge a sauvé des arrangements de profil";
QH_LOCALE_SAVELABEL =		"Créez les nouveaux arrangements de profil";
QH_LOCALE_HELP = 		"Tapez /QH2 pour ouvrir les options";
QH_LOCALE_THANKS = 		"Merci pour le téléchargement ";
QH_LOCALE_CONFIGURE =		"Tapez /QH2 pour configurer vos arrangements d'utilisateur.";
QH_LOCALE_SUPPORT = 		"Veuillez nous soutenir à:";
QH_LOCALE_SUPPORTLINK =		"http://quickhealmod.blogspot.com";
QH_LOCALE_UPDATENOTICE = 	"Il y a une nouvelle version de QuickHeal2 disponible!";
QH_LOCALE_UPDATEINSTRUCT =	"Veuillez télécharger la dernière version ici:";
QH_LOCALE_CHANGES = 		"[Note: Certains changements ne prennent pas fin à la fin du combat]";

QH_LOCALE_TRANSPARENCY = 	"Bar de dégats Transparency";
QH_LOCALE_ROWCOUNT = 		"Lignes";
QH_LOCALE_BARTEXT = 		"Montrer le texte sur la barre de dégats";
QH_LOCALE_BARHEIGHT = 		"Hauteur de la barre";
QH_LOCALE_BARWIDTH = 		"Largeur de la barre";
QH_LOCALE_TARGETADJUST = 	"Désactiver les ajustements de la fenêtre de cible";
QH_LOCALE_RAIDSORT = 		"Treier par";
QH_LOCALE_RANGECHECK = 		"Activer la vérification de portée [40 yards]";
QH_LOCALE_PARTYHIDE = 		"Désactiver l'interface de groupe dans les raids";
QH_LOCALE_RAIDENABLED = 	"Activer la fenêtre de raid QuickHeal2";
QH_LOCALE_RFBACKDROP = 		"Montrer le relâchement arrière de la fenêtre de raid";
QH_LOCALE_BARBACKDROP =		"Montrez le fond de barre";
QH_LOCALE_RFBACKDROPTRANS = 	"Transparence";
QH_LOCALE_SHOWDEBUFFS = 	"Montrer les Cureables Debuffs";
QH_LOCALE_HIDENOTINRANGE = 	"Montrer les unités hors de portée [75% tranparent]";
QH_LOCALE_ALWAYSSHOWSPARK =	"Montrez toujours l'étincelle de barre de dommages";
QH_LOCALE_THROTTLERAID =	"Mises à jour d'incursion, plus de mises à jour = fps inférieur";

QH_LOCALE_HIDERAIDFRAME =	"Armatures d'incursion de défaut de peau";
QH_LOCALE_SHOWTHREAT =		"Montrez le statut de menace";
QH_LOCALE_SPECLABEL =		"PERMUTATION DE SPÉCIALISATION DE TALENT DE PROFIL";
QH_LOCALE_SPECSWAP =		"Profils d'échange sur le changement de spécialisation de talent";
QH_LOCALE_SPEC1LABEL =		"Profil primaire de talents";
QH_LOCALE_SPEC2LABEL =		"Profil secondaire de talents";

-- NOT USED
QH_LOCALE_RUNNING = 		"Quick Heal Activé";
QH_LOCALE_RESURRECTION = 	"Click gauche pour résurecter les membres du groupe morts";
QH_LOCALE_MOVERAID = 		"[Pour bouger la fenêtre de raid garder shift enfoncé et faites glissez]";
QH_LOCALE_RESETCONFIRM =	"Êtes-vous sûr de vouloir modifier les paramètres ?";

end
