
-- English
---------------------------------------------------------------------------------------------
-- Localization Translations
---------------------------------------------------------------------------------------------
QH_LOCALE_FLASHHEAL =		"Flash Heal";
QH_LOCALE_GREATERHEAL =		"Greater Heal";
QH_LOCALE_BINDINGHEAL =		"Binding Heal";
QH_LOCALE_PRAYEROFMEND =	"Prayer Of Mending";
QH_LOCALE_RENEW =		"Renew";
QH_LOCALE_PWSHIELD =		"Power Word: Shield";
QH_LOCALE_GUARDIANSPIRIT =	"Guardian Spirit";
QH_LOCALE_CIRCLEHEAL =		"Circle Of Healing";
QH_LOCALE_PENANCE =		"Penance";
QH_LOCALE_DISPELMAGIC =		"Dispel Magic";
QH_LOCALE_ABOLISHDISEASE =	"Abolish Disease";

QH_LOCALE_HEALINGTOUCH =	"Healing Touch";
QH_LOCALE_REGROWTH =		"Regrowth";
QH_LOCALE_REJUVENATION = 	"Rejuvenation";
QH_LOCALE_LIFEBLOOM =		"Lifebloom";
QH_LOCALE_WILDGROWTH =		"Wild Growth";
QH_LOCALE_NOURISH =		"Nourish";
QH_LOCALE_TRANQUILITY =		"Tranquility";
QH_LOCALE_SWIFTMEND =		"Swiftmend";
QH_LOCALE_ABOLISH_POISON =	"Abolish Poison";
QH_LOCALE_REMOVE_CURSE =	"Remove Curse";

QH_LOCALE_HOLYSHOCK =		"Holy Shock";
QH_LOCALE_HOLYLIGHT = 		"Holy Light";
QH_LOCALE_FLASHOFLIGHT = 	"Flash of Light";
QH_LOCALE_LAYONHANDS =		"Lay on Hands";
QH_LOCALE_DIVINESHIELD =	"Divine Shield";
QH_LOCALE_DIVINEPROTECTION =	"Divine Protection";
QH_LOCALE_DIVINEINTERVENTION =	"Divine Intervention";
QH_LOCALE_HANDOFFREEDOM =	"Hand of Freedom";
QH_LOCALE_HANDOFPROTECTION =	"Hand of Protection";
QH_LOCALE_HANDOFSACRIFICE =	"Hand of Sacrifice";
QH_LOCALE_HANDOFSALVATION =	"Hand of Salvation";
QH_LOCALE_RIGHTEOUSDEFENSE = 	"Righteous Defense";
QH_LOCALE_CLEANSE = 		"Cleanse";

QH_LOCALE_HEALINGWAVE =		"Healing Wave";
QH_LOCALE_LESSERHEALINGWAVE =	"Lesser Healing Wave";
QH_LOCALE_CHAINHEAL =		"Chain Heal";
QH_LOCALE_RIPTIDE =		"Riptide";
QH_LOCALE_EARTHSHIELD =		"Earth Shield";
QH_LOCALE_WATERWALKING =	"Water Walking";
QH_LOCALE_WATERBREATHING =	"Water Breathing";
QH_LOCALE_CLEANSESPIRIT =	"Cleanse Spirit";

QH_LOCALE_DRUIDRES =		"Revive";
QH_LOCALE_DRUIDBATTLERES =	"Rebirth";
QH_LOCALE_PALADINRES =		"Redemption";
QH_LOCALE_PRIESTRES =		"Resurrection";
QH_LOCALE_SHAMANSELFRES	=	"Reincarnation";
QH_LOCALE_SHAMANRES =		"Ancestral Spirit";
QH_LOCALE_MONKRES =		"Resuscitate";
QH_LOCALE_DEATHKNIGHTRES = 	"Raise Ally";
QH_LOCALE_DRUIDRANGE =		"Rejuvenation";
QH_LOCALE_PALADINRANGE =	"Word of Glory";
QH_LOCALE_SHAMANRANGE =		"Healing Surge";
QH_LOCALE_PRIESTRANGE =		"Flash Heal";
QH_LOCALE_MONKRANGE = 		"Soothing Mist";

QH_LOCALE_SOOTHINGMIST =	"Soothing Mist";
QH_LOCALE_SURGINGMIST =		"Surging Mist";
QH_LOCALE_RENEWINGMIST = 	"Renewing Mist";
QH_LOCALE_ENVELOPINGMIST =	"Enveloping Mist";
QH_LOCALE_LIFECOCOON =		"Life Cocoon";
QH_LOCALE_EXPELHARM =		"Expel Harm";
QH_LOCALE_DETOX = 		"Detox";

QH_LOCALE_LEFT =		"Left Click";
QH_LOCALE_LEFTSHIFT =		"Shift-Left Click";
QH_LOCALE_LEFTCTRL =		"Ctrl-Left Click";
QH_LOCALE_LEFTALT =		"Alt-Left Click";
QH_LOCALE_MIDDLE =		"Middle Click";
QH_LOCALE_MIDDLESHIFT =		"Shift-Middle Click";
QH_LOCALE_MIDDLECTRL =		"Ctrl-Middle Click";
QH_LOCALE_MIDDLEALT =		"Alt-Middle Click";
QH_LOCALE_RIGHT =		"Right Click";
QH_LOCALE_RIGHTSHIFT =		"Shift-Right Click";
QH_LOCALE_RIGHTCTRL =		"Ctrl-Right Click";
QH_LOCALE_RIGHTALT =		"Alt-Right Click";
QH_LOCALE_BUTTON4 =		"Button4 Click";
QH_LOCALE_BUTTON4SHIFT =	"Button4-Shift Click";
QH_LOCALE_BUTTON4CTRL =		"Button4-Ctrl Click";
QH_LOCALE_BUTTON4ALT =		"Button4-Alt Click";
QH_LOCALE_BUTTON5 =		"Button5 Click";
QH_LOCALE_BUTTON5SHIFT =	"Button5-Shift Click";
QH_LOCALE_BUTTON5CTRL =		"Button5-Ctrl Click";
QH_LOCALE_BUTTON5ALT =		"Button5-Alt Click";

QH_LOCALE_GROUP1 =		"Group 1";
QH_LOCALE_GROUP2 =		"Group 2";
QH_LOCALE_GROUP3 =		"Group 3";
QH_LOCALE_GROUP4 =		"Group 4";
QH_LOCALE_GROUP5 =		"Group 5";
QH_LOCALE_GROUP6 =		"Group 6";
QH_LOCALE_GROUP7 =		"Group 7";
QH_LOCALE_GROUP8 =		"Group 8";

QH_LOCALE_RAIDTAB =		"RAID SPELLS";
QH_LOCALE_RAIDFRAMETAB =	"RAID FRAME";
QH_LOCALE_PARTYTAB =		"PARTY SPELLS";
QH_LOCALE_PLAYERTAB =		"PLAYER SPELLS";
QH_LOCALE_OPTIONSTAB =		"OPTIONS";
QH_LOCALE_DECURSETAB =		"DECURSE";
QH_LOCALE_WARNINGTAB = 		"WARNINGS";
QH_LOCALE_BUFFTAB =		"BUFFS";
QH_LOCALE_PROFILETAB =		"PROFILES";
QH_LOCALE_BINDING =		"Open Options"
QH_LOCALE_HEADER =		"QuickHeal2";
QH_LOCALE_RAIDFRAME =		"Raid Frame";
QH_LOCALE_PLAYERBAR =		"Player Bar Spells";
QH_LOCALE_PARTYBARS =		"Party Bar Spells";
QH_LOCALE_RAIDBARS =		"Raid Bar Spells";
QH_LOCALE_DECURSEBUTTON =	"Decurse & Warnings";
QH_LOCALE_BUFFBARS =		"Buff Display";
QH_LOCALE_PROFILES =		"Profiles";
QH_LOCALE_GENERAL =		"General";

QH_LOCALE_OKAY = 		"Okay";
QH_LOCALE_DEFAULT = 		"Reset";
QH_LOCALE_LOAD = 		"Load";
QH_LOCALE_SAVE = 		"Save";
QH_LOCALE_DELETE =		"Delete";
QH_LOCALE_LOADLABEL =		"Load Saved Profile Settings";
QH_LOCALE_SAVELABEL =		"Create New Profile Settings";
QH_LOCALE_HELP = 		"Use /QH2 to open options";
QH_LOCALE_THANKS = 		"Thank you for downloading ";
QH_LOCALE_CONFIGURE =		"Use /QH2 to configure your user settings.";
QH_LOCALE_SUPPORT = 		"Please support us at:";
QH_LOCALE_SUPPORTLINK =		"http://quickhealmod.blogspot.com";
QH_LOCALE_UPDATENOTICE = 	"There is a new version of QuickHeal2 available!";
QH_LOCALE_UPDATEINSTRUCT =	"Please download the latest version here:";
QH_LOCALE_CHANGES =		"[Note: Some changes do not take effect until out of combat]";

QH_LOCALE_TRANSPARENCY =	"Damage Bar Transparency";
QH_LOCALE_ROWCOUNT =		"Rows";
QH_LOCALE_BARTEXT =		"Display Damage Bar Values";
QH_LOCALE_BARHEIGHT =		"Damage Bar Height";
QH_LOCALE_BARWIDTH =		"Damage Bar Width";
QH_LOCALE_TARGETADJUST = 	"Disable Target Frame Adjustment";
QH_LOCALE_RAIDSORT =		"Sort By";
QH_LOCALE_RANGECHECK =		"Enable Range Checking [40 yards]";
QH_LOCALE_PARTYHIDE =		"Hide Party Interface In Raid";
QH_LOCALE_RAIDENABLED =		"Enable QuickHeal2 Raid Frames";
QH_LOCALE_RFBACKDROP =		"Show Raid Frame Backdrop";
QH_LOCALE_BARBACKDROP =		"Show Bar Background";
QH_LOCALE_RFBACKDROPTRANS =	"Transparency";
QH_LOCALE_SHOWDEBUFFS =		"Display Cureable Debuffs";
QH_LOCALE_SHOWWARNINGS =	"Display Debuff Warnings";
QH_LOCALE_FLASHWARNINGS = 	"Flash Debuff Warnings";
QH_LOCALE_SHOWSTANDARDDEBUFFS =	"Show Standard Raid Debuffs";
QH_LOCALE_WARNINGS =		"Custom Debuff Warning List [seperated by ';']";
QH_LOCALE_HIDENOTINRANGE =	"Display Units Out Of Range [75% Transparency]";
QH_LOCALE_ALWAYSSHOWSPARK =	"Always Show Damage Bar Spark";
QH_LOCALE_SHOWBUFFS =		"Display Buffs You Cast";
QH_LOCALE_BUFFLIST = 		"Buff Filter [max of four, seperated by ';']";
QH_LOCALE_DYNAMICGROUPS = 	"Limit Groups By Instance [Overrides Group Settings]";
QH_LOCALE_SHOWROLEICON = 	"Show Role Icons";

QH_LOCALE_HIDERAIDFRAME =	"Hide Default Raid Frames";
QH_LOCALE_SHOWTHREAT =		"Show Threat Status";
QH_LOCALE_SPECLABEL =		"PROFILE TALENT SPEC SWAPPING";
QH_LOCALE_SPECSWAP =		"Swap Profiles on Talent Spec Change";
QH_LOCALE_SPEC1LABEL =		"Primary Talents Profile";
QH_LOCALE_SPEC2LABEL =		"Secondary Talents Profile";

-- NOT USED
QH_LOCALE_RUNNING = 		"Quick Heal Enabled";
QH_LOCALE_RESURRECTION = 	"Use Left Click to Resurrect Dead Party Members";
QH_LOCALE_MOVERAID =		"[To Move Raid Frame Hold Shift and Drag]";
QH_LOCALE_RESETCONFIRM =	"Are you sure you want to reset settings?";
QH_LOCALE_THROTTLERAID =	"Raid Updates, More Updates = Lower FPS";

-- Quick Heal Description

QH_LOCALE_DESCRIPTION =
[=[
When enabled, damage taken bars will appear beside each player
and party unit frame. These bars increase with the amount of 
damage a player in the party receives, changing colors from 
green to yellow to red upon death. When in a raid, damage taken
bars will appear beside the name of everyone in the raid for 
quick and easy monitoring. A range checking option also gives 
the ability to focus on party and raid members within range.

By opening the options menu (/QH2 or assigned keybinding) the 
user may choose spells from their spellbook to cast upon the 
corresponding party/raid member when the bars are clicked. 
Currently all mouse buttons may be assigned as well as their 
Shift, Ctrl and Alt variants.

Macros may also be assigned by prefixing the macro name with an 
exclamation mark (!). In order to allow macros to function the 
way you would expect them to when clicking on a unit's damage 
bar, you may use the keyword 'unit' to tell Quick Heal that you 
want the spell cast on the bar's unit. To cast the spell renew, 
you could therefore create a macro '/cast [target=unit] Renew'.
]=];











