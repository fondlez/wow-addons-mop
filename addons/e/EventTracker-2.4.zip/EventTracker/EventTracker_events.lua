--[[ =================================================================
    Description:
        Use this file to specify which events need to be tracked.

    Revision:
        $Id: EventTracker_events.lua 772 2013-02-05 15:32:54Z fmeus_lgs $
    ================================================================= --]]

-- Events to be tracked
    ET_TRACKED_EVENTS = {
        "GUILDBANK_UPDATE_MONEY",
        "CHAT_MSG_MONEY"
    };