local GlobalAddonName, ExRT = ...

local max = max
local ceil = ceil
local UnitCombatlogname = ExRT.mds.UnitCombatlogname
local UnitHealth = UnitHealth
local UnitPower = UnitPower
local UnitGUID = UnitGUID
local AntiSpam = ExRT.mds.AntiSpam
local GetUnitInfoByUnitFlag = ExRT.mds.GetUnitInfoByUnitFlag
local UnitInRaid = UnitInRaid
local UnitIsPlayerOrPet = ExRT.mds.UnitIsPlayerOrPet
local GUIDtoID = ExRT.mds.GUIDtoID
local GetUnitTypeByGUID = ExRT.mds.GetUnitTypeByGUID
local pairs = pairs
local GetTime = GetTime
local UnitIsFriendlyByUnitFlag = ExRT.mds.UnitIsFriendlyByUnitFlag

local VExRT = nil

local module = ExRT.mod:New("BossWatcher",ExRT.L.BossWatcher)

module.db.data = {
	{
		guids = {},
		reaction = {},
		fight = {},
		encounterName = nil,
		encounterStartGlobal = time(),
		encounterStart = GetTime(),
		encounterEnd = GetTime()+1,
		graphData = {},
		fightID = 0,
	},
}
module.db.nowData = {}
module.db.nowNum = 1
local fightData,guidData,graphData,reactionData = nil

module.db.lastFightID = 0
module.db.timeFix = nil

module.db.spellsSchool = {}
local spellsSchool = module.db.spellsSchool

local heal_shields = {}

module.db.buffsFilters = {
[1] = {[-1]=ExRT.L.BossWatcherFilterOnlyBuffs,}, --> Only buffs
[2] = {[-1]=ExRT.L.BossWatcherFilterOnlyDebuffs,}, --> Only debuffs
[3] = {[-1]=ExRT.L.BossWatcherFilterBySpellID,}, --> By spellID
[4] = {[-1]=ExRT.L.BossWatcherFilterBySpellName,}, --> By spellName
[5] = {
	[-1]=ExRT.L.BossWatcherFilterTaunts,
	[-2]={62124,130793,17735,97827,56222,51399,49560,6795,355,115546,116189},
},
[6] = {
	[-1]=ExRT.L.BossWatcherFilterStun,
	[-2]={853,105593,91797,408,119381,89766,118345,46968,107570,5211,44572,119392,122057,113656,108200,108194,30283,118905,20549,119072,115750},
},
[7] = {
	[-1]=ExRT.L.BossWatcherFilterPersonal,
	[-2]={148467,31224,110788,55694,47585,31850,115610,122783,642,5277,118038,104773,115176,48707,1966,61336,120954,871,106922,30823,6229,22812,498},
},
[8] = {
	[-1]=ExRT.L.BossWatcherFilterRaidSaves,
	[-2]={145629,114192,114198,81782,108281,97463,31821,15286,115213,44203,64843,76577},
},
[9] = {
	[-1]=ExRT.L.BossWatcherFilterPotions,
	[-2]={105702,105697,105706,105701,105707,105698,125282},
},
[10] = {
	[-1]=ExRT.L.BossWatcherFilterPandaria,
	[-2]={148010,146194,146198,146200,137593,137596,137590,137288,137323,137326,137247,137331},
},
[11] = {
	[-1]=ExRT.L.BossWatcherFilterTier16,
	[-2]={143524,143460,143459,143198,143434,143023,143840,143564,143959,146022,144452,144351,144358,146594,144359,144364,145215,144574,144683,144684,144636,146822,147029,147068,146899,
		144467,144459,146325,144330,144089,143494,143638,143480,143882,143589,143594,143593,143536,142990,143919,142913,143385,144236,143856,144466,145987,145747,143442,143411,143445,
		143791,146589,142534,142532,142533,142671,142948,143337,143701,143735,145213,147235,147209,144762,148994,148983,144817,145171,145065,147324},
},
}
module.db.buffsFilterStatus = {}

if ExRT.WOD then
	ExRT.mds.table_add(module.db.buffsFilters[9][-2],{156426,156423,156428,156432,156430})
end

module.db.raidIDs = {
	[543]=true, 	--wotlk
	[535]=true, 	--wotlk
	[529]=true, 	--wotlk
	[527]=true, 	--wotlk
	[532]=true, 	--wotlk
	[531]=true, 	--wotlk
	[604]=true, 	--wotlk
	[609]=true, 	--wotlk
	[718]=true,	--wotlk

	[752]=true,	--BH
	[754]=true,	--BD
	[758]=true,	--BoT
	[774]=true,	--TotFW
	[800]=true,	--FL
	[824]=true,	--DS
	
	[896]=true,	--MV
	[897]=true,	--HoF
	[886]=true,	--ToES
	[930]=true,	--ToT
	[953]=true,	--SoO
	
	[988]=true,	--BF
	[994]=true,	--H
}

module.db.autoSegmentEvents = {"UNIT_SPELLCAST_SUCCEEDED","SPELL_AURA_REMOVED","SPELL_AURA_APPLIED","UNIT_DIED","CHAT_MSG_RAID_BOSS_EMOTE"}
module.db.autoSegmentEventsL = {
	["UNIT_SPELLCAST_SUCCEEDED"] = ExRT.L.BossWatcherSegmentEventsUSS,
	["SPELL_AURA_REMOVED"] = ExRT.L.BossWatcherSegmentEventsSAR,
	["SPELL_AURA_APPLIED"] = ExRT.L.BossWatcherSegmentEventsSAA,
	["UNIT_DIED"] = ExRT.L.BossWatcherSegmentEventsUD,
	["CHAT_MSG_RAID_BOSS_EMOTE"] = ExRT.L.BossWatcherSegmentEventsCMRBE,
}
module.db.autoSegments = {
	["UNIT_DIED"] = {},
	["SPELL_AURA_APPLIED"] = {},
	["SPELL_AURA_REMOVED"] = {},
	["UNIT_SPELLCAST_SUCCEEDED"] = {},
	["CHAT_MSG_RAID_BOSS_EMOTE"] = {},
}
module.db.segmentsLNames = {
	["UNIT_SPELLCAST_SUCCEEDED"] = ExRT.L.BossWatcherSegmentNamesUSS,
	["SPELL_AURA_REMOVED"] = ExRT.L.BossWatcherSegmentNamesSAR,
	["SPELL_AURA_APPLIED"] = ExRT.L.BossWatcherSegmentNamesSAA,
	["UNIT_DIED"] = ExRT.L.BossWatcherSegmentNamesUD,
	['ENCOUNTER_START'] = ExRT.L.BossWatcherSegmentNamesES,
	["SLASH"] = ExRT.L.BossWatcherSegmentNamesSC,
	["CHAT_MSG_RAID_BOSS_EMOTE"] = ExRT.L.BossWatcherSegmentNamesCMRBE,
}
module.db.registerOtherEvents = {}

module.db.raidTargets = {0x1,0x2,0x4,0x8,0x10,0x20,0x40,0x80}
module.db.energyLocale = {
	[0] = "|cff69ccf0"..ExRT.L.BossWatcherEnergyType0,
	[1] = "|cffedc294"..ExRT.L.BossWatcherEnergyType1,
	[2] = "|cffd1fa99"..ExRT.L.BossWatcherEnergyType2,
	[3] = "|cffffff8f"..ExRT.L.BossWatcherEnergyType3,
	[5] = "|cffeb4561"..ExRT.L.BossWatcherEnergyType5,
	[6] = "|cffeb4561"..ExRT.L.BossWatcherEnergyType6,
	[7] = "|cff9482c9"..ExRT.L.BossWatcherEnergyType7,
	[8] = "|cffffa330"..ExRT.L.BossWatcherEnergyType8,
	[9] = "|cffffb3e0"..ExRT.L.BossWatcherEnergyType9,
	[10] = "|cffffffff"..ExRT.L.BossWatcherEnergyType10,
	[12] = "|cff4DbB98"..ExRT.L.BossWatcherEnergyType12,
	[13] = "|cffd9d9d9"..ExRT.L.BossWatcherEnergyType13,
	[14] = "|cffeb4561"..ExRT.L.BossWatcherEnergyType14,
	[15] = "|cff9482c9"..ExRT.L.BossWatcherEnergyType15,
}

module.db.schoolsDefault = {0x1,0x2,0x4,0x8,0x10,0x20,0x40}
module.db.schoolsColors = {
	[SCHOOL_MASK_NONE]	= {r=.8,g=.8,b=.8},
	[SCHOOL_MASK_PHYSICAL]	= {r=1,g=.64,b=.19},
	[SCHOOL_MASK_HOLY] 	= {r=1,g=1,b=.56},
	[SCHOOL_MASK_FIRE] 	= {r=.92,g=.27,b=.38},
	[SCHOOL_MASK_NATURE] 	= {r=.6,g=1,b=.4},	--r=.82,g=.98,b=.6
	[SCHOOL_MASK_FROST] 	= {r=.29,g=.50,b=1},
	[SCHOOL_MASK_SHADOW] 	= {r=.72,g=.66,b=.94},
	[SCHOOL_MASK_ARCANE] 	= {r=.56,g=.95,b=1},
	
	[0x1C] = {r=1,g=.3,b=1},	--Elemental
	[0x7C] = {r=.6,g=0,b=0},	--Chromatic
	[0x7E] = {r=1,g=0,b=0},		--Magic
	[0x7F] = {r=.25,g=.25,b=.25},	--Chaos
}

local function UpdateNewSegmentEvents()
	table.wipe(module.db.autoSegments.UNIT_DIED)
	table.wipe(module.db.autoSegments.SPELL_AURA_APPLIED)
	table.wipe(module.db.autoSegments.SPELL_AURA_REMOVED)
	table.wipe(module.db.autoSegments.UNIT_SPELLCAST_SUCCEEDED)
	table.wipe(module.db.autoSegments.CHAT_MSG_RAID_BOSS_EMOTE)
	table.wipe(module.db.registerOtherEvents)
	for i=1,10 do
		if VExRT.BossWatcher.autoSegments[i] and VExRT.BossWatcher.autoSegments[i][1] and VExRT.BossWatcher.autoSegments[i][2] then
			module.db.autoSegments[ VExRT.BossWatcher.autoSegments[i][2] ][ VExRT.BossWatcher.autoSegments[i][1] ] = true
			if VExRT.BossWatcher.autoSegments[i][2] == 'UNIT_SPELLCAST_SUCCEEDED' then
				module.db.registerOtherEvents['UNIT_SPELLCAST_SUCCEEDED'] = true
			end
			if VExRT.BossWatcher.autoSegments[i][2] == 'CHAT_MSG_RAID_BOSS_EMOTE' then
				module.db.registerOtherEvents['CHAT_MSG_RAID_BOSS_EMOTE'] = true
			end
		end
	end
end

local graphDataMetaTable = {__index = function(self, index)
	local new = {
		dps={
			_total = 0
		},
		health={},
		power={},
		name={},
	}
	self[index] = new
	return new
end}

local AddSegmentToData = nil
local _graphSectionTimer,_graphSectionTimerRounded,_graphRaidSnapshot = 0,0,{}

function module:Enable()
	VExRT.BossWatcher.enabled = true
	
	module:RegisterEvents('ZONE_CHANGED_NEW_AREA')
	module.main:ZONE_CHANGED_NEW_AREA()
	module:RegisterSlash()
	
	UpdateNewSegmentEvents()
end

function module:Disable()
	VExRT.BossWatcher.enabled = nil
	
	if fightData then
		module.main.ENCOUNTER_END()
	end
	
	module.main:UnregisterAllEvents()
	module:UnregisterSlash()
end

local BWInterfaceFrame = nil
local BWInterfaceFrameLoad,isBWInterfaceFrameLoaded,BWInterfaceFrameLoadFunc = nil
do
	local isAdded = nil
	function BWInterfaceFrameLoadFunc()
		if not isBWInterfaceFrameLoaded then
			BWInterfaceFrameLoad()
		end
		if isBWInterfaceFrameLoaded then
			InterfaceOptionsFrame:Hide()
			BWInterfaceFrame:Show()
		end
		CloseDropDownMenus() 
	end
	function module:miniMapMenu()
		if isAdded then
			return
		end
		ExRT.mds.MinimapMenuAdd(ExRT.L.BossWatcher, BWInterfaceFrameLoadFunc)
	end
	module:RegisterMiniMapMenu()
end

function module.options:Load()			
	self.checkEnabled = ExRT.lib.CreateCheckBox(nil,self,nil,10,-10,ExRT.L.senable,VExRT.BossWatcher.enabled)
	self.checkEnabled:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			module:Enable()
		else
			module:Disable()
		end
	end)
	
	self.checkShowGUIDs = ExRT.lib.CreateCheckBox(nil,self,nil,10,-35,ExRT.L.BossWatcherChkShowGUIDs,VExRT.BossWatcher.GUIDs)
	self.checkShowGUIDs:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			VExRT.BossWatcher.GUIDs = true
		else
			VExRT.BossWatcher.GUIDs = nil
		end
	end)
	
	self.checkSpellID = ExRT.lib.CreateCheckBox(nil,self,nil,10,-60,ExRT.L.BossWatcherOptionSpellID,VExRT.BossWatcher.timeLineSpellID)
	self.checkSpellID:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			VExRT.BossWatcher.timeLineSpellID = true
		else
			VExRT.BossWatcher.timeLineSpellID = nil
		end
	end)
	
	self.checkNoGraphic = ExRT.lib.CreateCheckBox(nil,self,nil,10,-85,ExRT.L.BossWatcherOptionNoGraphic,VExRT.BossWatcher.noGraphics)
	self.checkNoGraphic:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			VExRT.BossWatcher.noGraphics = true
		else
			VExRT.BossWatcher.noGraphics = nil
		end
	end)
	self.checkNoBuffs = ExRT.lib.CreateCheckBox(nil,self,nil,10,-110,ExRT.L.BossWatcherOptionNoBuffs,VExRT.BossWatcher.noBuffs,ExRT.L.BossWatcherOptionNoBuffsTooltip)
	self.checkNoBuffs:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			VExRT.BossWatcher.noBuffs = true
		else
			VExRT.BossWatcher.noBuffs = nil
		end
	end)
	
	self.sliderNum = ExRT.lib.CreateSlider(self:GetName().."SliderNum",self,300,15,20,-155,1,10,ExRT.L.BossWatcherOptionsFightsSave,VExRT.BossWatcher.fightsNum or 1)
	self.sliderNum:SetScript("OnValueChanged", function(self,event) 
		event = ExRT.mds.Round(event)
		VExRT.BossWatcher.fightsNum = event
		self.tooltipText = event
		self:tooltipReload(self)
	end)
	self.warningText = ExRT.lib.CreateText(self,570,25,nil,15,-190,"LEFT","TOP",nil,11,ExRT.L.BossWatcherOptionsFightsWarning,nil,1,1,1,1)
	
	self.showButton = ExRT.lib.CreateButton(nil,self,550,22,"TOP",0,-240,ExRT.L.BossWatcherGoToBossWatcher)
	self.showButton:SetScript("OnClick",function ()
		InterfaceOptionsFrame:Hide()
		BWInterfaceFrameLoadFunc()
	end)
	self.buttonChecker = CreateFrame("Frame",nil,self)
	self.buttonChecker:SetScript("OnShow",function (self)
		if not InterfaceOptionsFrame:IsShown() then
			module.options.showButton:Hide()
		else
			module.options.showButton:Show()
		end
	end)
	
	self.chatText = ExRT.lib.CreateText(self,600,250,nil,10,-275,"LEFT","TOP",nil,12,ExRT.L.BossWatcherOptionsHelp,nil,1,1,1,1)
end

function module.main:ADDON_LOADED()
	VExRT = _G.VExRT
	VExRT.BossWatcher = VExRT.BossWatcher or {}
	VExRT.BossWatcher.autoSegments = VExRT.BossWatcher.autoSegments or {}
	
	if VExRT.BossWatcher.enabled then
		module:Enable(true)
	end
	VExRT.BossWatcher.fightsNum = VExRT.BossWatcher.fightsNum or 1
end

--[[
amount;
count;
overkill;
blocked;
absorbed;
critical;
critical-count;
critical-max;
ms;
ms-count;
ms-max;
hit-max;
parry;
dodge;
miss;
]]

local function addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,spellID,overkill,school,blocked,absorbed,critical,multistrike)
	local destTable = fightData.damage[destGUID]
	if not destTable then
		fightData.damage_seen[destGUID] = timestamp
		destTable = {}
		fightData.damage[destGUID] = destTable
	end
	local sourceTable = destTable[sourceGUID]
	if not sourceTable then
		sourceTable = {}
		destTable[sourceGUID] = sourceTable
	end
	local spellTable = sourceTable[spellID]
	if not spellTable then
		spellTable = {
			amount = 0,
			count = 0,
			overkill = 0,
			blocked = 0,
			absorbed = 0,
			crit = 0,
			critcount = 0,
			critmax = 0,
			ms = 0,
			mscount = 0,
			msmax = 0,
			hitmax = 0,
			parry = 0,
			dodge = 0,
			miss = 0,
		}
		sourceTable[spellID] = spellTable
		if school then
			spellsSchool[spellID] = school
		end
	end
	spellTable.amount = spellTable.amount + amount
	spellTable.count = spellTable.count + 1
	if overkill > 0 then
		spellTable.overkill = spellTable.overkill + overkill
	end
	if blocked then
		spellTable.blocked = spellTable.blocked + blocked
	end
	if absorbed then
		spellTable.absorbed = spellTable.absorbed + absorbed
	end
	if critical then
		spellTable.crit = spellTable.crit + amount
		spellTable.critcount = spellTable.critcount + 1
		spellTable.critmax = max(spellTable.critmax,amount)
	end
	if multistrike then
		spellTable.ms = spellTable.ms + amount
		spellTable.mscount = spellTable.mscount + 1
		spellTable.msmax = max(spellTable.msmax,amount)
	end
	if not critical and not multistrike then
		spellTable.hitmax = max(spellTable.hitmax,amount)
	end
end
local function addDamage_graphics(sourceGUID,destGUID,amount,timestamp,spellID,overkill,school,blocked,absorbed,critical,multistrike)
	local destTable = fightData.damage[destGUID]
	if not destTable then
		fightData.damage_seen[destGUID] = timestamp
		destTable = {}
		fightData.damage[destGUID] = destTable
	end
	local sourceTable = destTable[sourceGUID]
	if not sourceTable then
		sourceTable = {}
		destTable[sourceGUID] = sourceTable
	end
	local spellTable = sourceTable[spellID]
	if not spellTable then
		spellTable = {
			amount = 0,
			count = 0,
			overkill = 0,
			blocked = 0,
			absorbed = 0,
			crit = 0,
			critcount = 0,
			critmax = 0,
			ms = 0,
			mscount = 0,
			msmax = 0,
			hitmax = 0,
			parry = 0,
			dodge = 0,
			miss = 0,
		}
		sourceTable[spellID] = spellTable
		if school then
			spellsSchool[spellID] = school
		end
	end
	spellTable.amount = spellTable.amount + amount
	spellTable.count = spellTable.count + 1
	if overkill > 0 then
		spellTable.overkill = spellTable.overkill + overkill
	end
	if blocked then
		spellTable.blocked = spellTable.blocked + blocked
	end
	if absorbed then
		spellTable.absorbed = spellTable.absorbed + absorbed
	end
	if critical then
		spellTable.crit = spellTable.crit + amount
		spellTable.critcount = spellTable.critcount + 1
		spellTable.critmax = max(spellTable.critmax,amount)
	end
	if multistrike then
		spellTable.ms = spellTable.ms + amount
		spellTable.mscount = spellTable.mscount + 1
		spellTable.msmax = max(spellTable.msmax,amount)
	end
	if not critical and not multistrike then
		spellTable.hitmax = max(spellTable.hitmax,amount)
	end
	
	local graphData = graphData[_graphSectionTimerRounded].dps
	if not graphData[sourceGUID] then
		graphData[sourceGUID] = amount
	else
		graphData[sourceGUID] = graphData[sourceGUID] + amount
	end
	graphData._total = graphData._total + amount
end
local addDamage = addDamage_noGraphics

local function AddMiss(sourceGUID,destGUID,timestamp,spellId,missType,amountMissed,multistrike,school)
	if missType == "ABSORB" then
		addDamage(sourceGUID,destGUID,0,timestamp,spellId,0,school,nil,amountMissed,school)
	elseif missType == "BLOCK" then
		addDamage(sourceGUID,destGUID,0,timestamp,spellId,0,school,amountMissed,nil,school)
	elseif missType == "PARRY" then
		addDamage(sourceGUID,destGUID,0,timestamp,spellId,0,school)
		local spellTable = fightData.damage[destGUID][sourceGUID][spellId]
		spellTable.parry = spellTable.parry + 1
	elseif missType == "DODGE" then
		addDamage(sourceGUID,destGUID,0,timestamp,spellId,0,school)
		local spellTable = fightData.damage[destGUID][sourceGUID][spellId]
		spellTable.dodge = spellTable.dodge + 1
	else
		addDamage(sourceGUID,destGUID,0,timestamp,spellId,0,school)
		local spellTable = fightData.damage[destGUID][sourceGUID][spellId]
		spellTable.miss = spellTable.miss + 1	
	end
end

local function AddEnvironmentalDamage(sourceGUID,destGUID,timestamp,environmentalType,amount,overkill,school,resisted,blocked,absorbed,critical,multistrike)
	if environmentalType == "Falling" then
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,110122,overkill,school,blocked,absorbed,critical,multistrike)
	elseif environmentalType == "Drowning" then
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,68730,overkill,school,blocked,absorbed,critical,multistrike)
	elseif environmentalType == "Fatigue" then
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,125024,overkill,school,blocked,absorbed,critical,multistrike)
	elseif environmentalType == "Fire" then
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,103795,overkill,school,blocked,absorbed,critical,multistrike)
	elseif environmentalType == "Lava" then
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,119741,overkill,school,blocked,absorbed,critical,multistrike)
	elseif environmentalType == "Slime" then
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,16456,overkill,school,blocked,absorbed,critical,multistrike)
	else
		addDamage_noGraphics(sourceGUID,destGUID,amount,timestamp,48360,overkill,school,blocked,absorbed,critical,multistrike)
	end
end

--[[
amount;
overhealing;
absorbed;
count;
critical;
critical-count;
critical-max;
ms;
ms-count;
ms-max;
hit-max;
critical-overhealing;
ms-overhealing;
]]

local function addHeal(sourceGUID,destGUID,spellId,amount,overhealing,absorbed,critical,multistrike,school)
	local sourceTable = fightData.heal[sourceGUID]
	if not sourceTable then
		sourceTable = {}
		fightData.heal[sourceGUID] = sourceTable
	end
	local destTable = sourceTable[destGUID]
	if not destTable then
		destTable = {}
		sourceTable[destGUID] = destTable
	end
	local spellTable = destTable[spellId]
	if not spellTable then
		spellTable = {
			amount = 0,
			over = 0,
			absorbed = 0,
			count = 0,
			crit = 0,
			critcount = 0,
			critmax = 0,
			critover = 0,
			ms = 0,
			mscount = 0,
			msmax = 0,
			msover = 0,
			hitmax = 0,
		}
		destTable[spellId] = spellTable
		spellsSchool[spellId] = school
	end
	spellTable.amount = spellTable.amount + amount
	spellTable.over = spellTable.over + overhealing
	spellTable.absorbed = spellTable.absorbed + absorbed
	spellTable.count = spellTable.count + 1
	if critical then
		spellTable.crit = spellTable.crit + amount + absorbed
		spellTable.critcount = spellTable.critcount + 1
		spellTable.critmax = max(spellTable.critmax,amount)
		spellTable.critover = spellTable.critover + overhealing
	end
	if multistrike then
		spellTable.ms = spellTable.ms + amount + absorbed
		spellTable.mscount = spellTable.mscount + 1
		spellTable.msmax = max(spellTable.msmax,amount)
		spellTable.msover = spellTable.msover + overhealing		
	end
	if not critical and not multistrike then
		spellTable.hitmax = max(spellTable.hitmax,amount)
	end
end

local function addShield(sourceGUID,destGUID,spellId,amount)
	local sourceTable = heal_shields[sourceGUID]
	if not sourceTable then
		sourceTable = {}
		heal_shields[sourceGUID] = sourceTable
	end
	local spellTable = sourceTable[spellId]
	if not spellTable then
		spellTable = {}
		sourceTable[spellId] = spellTable
	end
	spellTable[destGUID] = amount
end
local function refreshShield(sourceGUID,destGUID,spellId,amount,school)
	local sourceTable = heal_shields[sourceGUID]
	if not sourceTable then
		return
	end
	local spellTable = sourceTable[spellId]
	if not spellTable then
		return
	end
	local prev = spellTable[destGUID]
	if prev and prev > amount then
		addHeal(sourceGUID,destGUID,spellId,prev-amount,0,0,nil,nil,school)
	end
	spellTable[destGUID] = amount
end
local function removeShield(sourceGUID,destGUID,spellId,amount,school)
	local sourceTable = heal_shields[sourceGUID]
	if not sourceTable then
		return
	end
	local spellTable = sourceTable[spellId]
	if not spellTable then
		return
	end
	local prev = spellTable[destGUID]
	if prev and prev > amount then
		addHeal(sourceGUID,destGUID,spellId,prev,amount,0,nil,nil,school)
	end
	spellTable[destGUID] = amount
end

local function addSwitch(sourceGUID,targetGUID,timestamp,_type,spellId)
	local targetTable = fightData.switch[targetGUID]
	if not targetTable then
		targetTable = {
			[1]={},	--cast
			[2]={},	--target
		}
		fightData.switch[targetGUID] = targetTable
	end
	if not targetTable[_type][sourceGUID] then
		targetTable[_type][sourceGUID] = {timestamp,spellId}
	end
end

local function addCast(sourceGUID,destGUID,spellID,_type,timestamp)
	local sourceTable = fightData.cast[sourceGUID]
	if not sourceTable then
		sourceTable = {}
		fightData.cast[sourceGUID] = sourceTable
	end
	sourceTable[ #sourceTable + 1 ] = {timestamp,spellID,_type,destGUID}
end

local function addGUID(GUID,name)
	if not guidData[GUID] then
		guidData[GUID] = name or "nil"
	end
end

local function updateReaction(GUID,flags)
	reactionData[GUID] = flags
end

local function addBuff_disabled()
end
local function addBuff_enabled(timestamp,sourceGUID,destGUID,sourceFriendly,destFriendly,spellID,type_1,subeventID,stack)
	fightData.auras[ #fightData.auras + 1 ] = {timestamp,sourceGUID,destGUID,sourceFriendly,destFriendly,spellID,type_1,subeventID,stack}
end
local addBuff = addBuff_enabled

local function addChatMessage(sender,msg,spellID,time)
	fightData.chat[ #fightData.chat + 1 ] = {sender,msg,spellID,time}
end

local function addPower(sourceGUID,spellId,powerType,amount)
	local sourceData = fightData.power[sourceGUID]
	if not sourceData then
		sourceData = {}
		fightData.power[sourceGUID] = sourceData
	end
	local powerData = sourceData[powerType]
	if not powerData then
		powerData = {}
		sourceData[powerType] = powerData
	end
	local spellData = powerData[spellId]
	if not spellData then
		spellData = {0,0}
		powerData[spellId] = spellData
	end
	spellData[1] = spellData[1] + amount
	spellData[2] = spellData[2] + 1
end

function AddSegmentToData(seg)
	local segmentData = module.db.data[module.db.nowNum].fight[seg]
	for destGUID,destData in pairs(segmentData.damage) do
		local _now = module.db.nowData.damage[destGUID]
		if not _now then
			_now = {}
			module.db.nowData.damage[destGUID] = _now
		end
		for sourceGUID,sourceData in pairs(destData) do
			local _source = _now[sourceGUID]
			if not _source then
				_source = {}
				_now[sourceGUID] = _source
			end
			for spellID,spellData in pairs(sourceData) do
				local _spell = _source[spellID]
				if not _spell then
					_spell = {
						amount = 0,
						count = 0,
						overkill = 0,
						blocked = 0,
						absorbed = 0,
						crit = 0,
						critcount = 0,
						critmax = 0,
						ms = 0,
						mscount = 0,
						msmax = 0,
						hitmax = 0,
						parry = 0,
						dodge = 0,
						miss = 0,
					}
					_source[spellID] = _spell
				end
				for dataName,dataAmount in pairs(spellData) do
					if dataName:find("max") then
						_spell[dataName] = max(_spell[dataName],dataAmount)
					else
						_spell[dataName] = _spell[dataName] + dataAmount
					end				
				end
			end
		end		
	end
	for destGUID,seen in pairs(segmentData.damage_seen) do
		if module.db.nowData.damage_seen[destGUID] then
			module.db.nowData.damage_seen[destGUID] = min(module.db.nowData.damage_seen[destGUID],seen)
		else
			module.db.nowData.damage_seen[destGUID] = seen
		end
	end
	for sourceGUID,sourceData in pairs(segmentData.heal) do
		local _source = module.db.nowData.heal[sourceGUID]
		if not _source then
			_source = {}
			module.db.nowData.heal[sourceGUID] = _source
		end
		for destGUID,destData in pairs(sourceData) do
			local _dest = _source[destGUID]
			if not _dest then
				_dest = {}
				_source[destGUID] = _dest
			end
			for spellID,spellData in pairs(destData) do
				local _spell = _dest[spellID]
				if not _spell then
					_spell = {
						amount = 0,
						over = 0,
						absorbed = 0,
						count = 0,
						crit = 0,
						critcount = 0,
						critmax = 0,
						critover = 0,
						ms = 0,
						mscount = 0,
						msmax = 0,
						msover = 0,
						hitmax = 0,
					}
					_dest[spellID] = _spell
				end
				for dataName,dataAmount in pairs(spellData) do
					if dataName:find("max") then
						_spell[dataName] = max(_spell[dataName],dataAmount)
					else
						_spell[dataName] = _spell[dataName] + dataAmount
					end				
				end
			end
		end
	end
	for targetGUID,destData in pairs(segmentData.switch) do
		if not module.db.nowData.switch[targetGUID] then
			module.db.nowData.switch[targetGUID] = {
				[1]={},	--cast
				[2]={},	--target
			}
		end
		for _type=1,2 do
			for unitN,t in pairs(destData[_type]) do
				if not module.db.nowData.switch[targetGUID][_type][unitN] then
					module.db.nowData.switch[targetGUID][_type][unitN] = {t[1],t[2]}
				end
				if t[1] < module.db.nowData.switch[targetGUID][_type][unitN][1] then
					module.db.nowData.switch[targetGUID][_type][unitN][1] = t[1]
					module.db.nowData.switch[targetGUID][_type][unitN][2] = t[2]
				end
			end
		end
	end
	for sourceGUID,destData in pairs(segmentData.cast) do
		if not module.db.nowData.cast[sourceGUID] then
			module.db.nowData.cast[sourceGUID] = {}
		end
		for i=1,#destData do
			local added_index = #module.db.nowData.cast[sourceGUID] + 1
			module.db.nowData.cast[sourceGUID][added_index] = {}
			for j=1,#destData[i] do
				module.db.nowData.cast[sourceGUID][added_index][j] = destData[i][j]
			end
		end
	end
	for i=1,#segmentData.auras do
		local added_index = #module.db.nowData.auras + 1
		module.db.nowData.auras[added_index] = {}
		for j=1,#segmentData.auras[i] do
			module.db.nowData.auras[added_index][j] = segmentData.auras[i][j]
		end
	end
	for i=1,#segmentData.dies do
		local added_index = #module.db.nowData.dies + 1
		module.db.nowData.dies[added_index] = {}
		for j=1,#segmentData.dies[i] do
			module.db.nowData.dies[added_index][j] = segmentData.dies[i][j]
		end
	end
	for i=1,#segmentData.dispels do
		local added_index = #module.db.nowData.dispels + 1
		module.db.nowData.dispels[added_index] = {}
		for j=1,#segmentData.dispels[i] do
			module.db.nowData.dispels[added_index][j] = segmentData.dispels[i][j]
		end
	end
	for i=1,#segmentData.interrupts do
		local added_index = #module.db.nowData.interrupts + 1
		module.db.nowData.interrupts[added_index] = {}
		for j=1,#segmentData.interrupts[i] do
			module.db.nowData.interrupts[added_index][j] = segmentData.interrupts[i][j]
		end
	end
	for i=1,#segmentData.chat do
		local added_index = #module.db.nowData.chat + 1
		module.db.nowData.chat[added_index] = {}
		for j=1,#segmentData.chat[i] do
			module.db.nowData.chat[added_index][j] = segmentData.chat[i][j]
		end
	end
	for sourceGUID,sourceData in pairs(segmentData.power) do
		local _sourceGUID = module.db.nowData.power[sourceGUID]
		if not _sourceGUID then
			_sourceGUID = {}
			module.db.nowData.power[sourceGUID] = _sourceGUID
		end
		for powerType,powerData in pairs(sourceData) do
			local _powerType = _sourceGUID[powerType]
			if not _powerType then
				_powerType = {}
				_sourceGUID[powerType] = _powerType
			end
			for spellID,spellData in pairs(powerData) do
				local _spellData = _powerType[spellID]
				if not _spellData then
					_spellData = {0,0}
					_powerType[spellID] = _spellData
				end
				_spellData[1] = _spellData[1] + spellData[1]
				_spellData[2] = _spellData[2] + spellData[2]
			end			
		end
	end
end

local function StartSegment(name,subEvent)
	fightData = {
		damage = {},
		damage_seen = {},
		heal = {},
		switch = {},
		cast = {},
		interrupts = {},
		dispels = {},
		auras = {},
		power = {},
		dies = {},
		chat = {},
		resurrests = {},
		time = time(),
		timeEx = GetTime(),
		name = name,
		subEvent = subEvent,
	}
	module.db.data[1].fight[ #module.db.data[1].fight + 1 ] = fightData
end

function module.main:ENCOUNTER_START(encounterID,encounterName)
	module.db.lastFightID = module.db.lastFightID + 1

	local maxFights = (VExRT.BossWatcher.fightsNum or 10)
	for i=maxFights,2,-1 do
		module.db.data[i] = module.db.data[i-1]
	end
	module.db.data[1] = {
		guids = {},
		reaction = {},
		fight = {},
		encounterName = encounterName,
		encounterStartGlobal = time(),
		encounterStart = GetTime(),
		encounterEnd = 0,
		graphData = {},
		fightID = module.db.lastFightID,
	}
	setmetatable(module.db.data[1].graphData,graphDataMetaTable)
	
	wipe(heal_shields)	
	guidData = module.db.data[1].guids
	graphData = module.db.data[1].graphData
	reactionData = module.db.data[1].reaction
	StartSegment("ENCOUNTER_START")
	
	
	for event,_ in pairs(module.db.registerOtherEvents) do
		module:RegisterEvents(event)
	end
	module:RegisterEvents('COMBAT_LOG_EVENT_UNFILTERED','UNIT_TARGET','RAID_BOSS_EMOTE','RAID_BOSS_WHISPER')
	
	_graphSectionTimer = 0
	_graphSectionTimerRounded = 0
	_graphRaidSnapshot = {"boss1","boss2","boss3","boss4","boss5"}
	if IsInRaid() then
		local gMax = ExRT.mds.GetRaidDiffMaxGroup()
		for i=1,40 do
			local name,_,subgroup = GetRaidRosterInfo(i)
			if name and subgroup <= gMax then
				_graphRaidSnapshot[#_graphRaidSnapshot + 1] = name
			end
		end
	else
		_graphRaidSnapshot[#_graphRaidSnapshot + 1] = UnitName("player")
		for i=1,4 do
			local partyMember = UnitCombatlogname("party"..i)
			if partyMember then
				_graphRaidSnapshot[#_graphRaidSnapshot + 1] = partyMember
			end
		end
	end

	if not VExRT.BossWatcher.noGraphics then
		module:RegisterTimer()
		addDamage = addDamage_graphics
	else
		addDamage = addDamage_noGraphics
	end
	if VExRT.BossWatcher.noBuffs then
		addBuff = addBuff_disabled
	else
		addBuff = addBuff_enabled
	end
end
module.main.PLAYER_REGEN_DISABLED = module.main.ENCOUNTER_START

function module.main:ENCOUNTER_END()
	if fightData then
		module.db.data[1].encounterEnd = GetTime()
	end

	module:UnregisterEvents('COMBAT_LOG_EVENT_UNFILTERED','UNIT_TARGET','RAID_BOSS_EMOTE','RAID_BOSS_WHISPER')
	for event,_ in pairs(module.db.registerOtherEvents) do
		module:UnregisterEvents(event)
	end
	module:UnregisterTimer()
	fightData = nil
	guidData = nil
	graphData = nil
	reactionData = nil
end
module.main.PLAYER_REGEN_ENABLED = module.main.ENCOUNTER_END

function module.main:ZONE_CHANGED_NEW_AREA()
	ExRT.mds.dprint('ZONE_CHANGED_NEW_AREA')
	local zoneID = GetCurrentMapAreaID()
	if fightData then
		module.main:ENCOUNTER_END()
	end

	module:UnregisterEvents('PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED','ENCOUNTER_START','ENCOUNTER_END')
	if module.db.raidIDs[zoneID] then
		module:RegisterEvents('ENCOUNTER_START','ENCOUNTER_END')
	else
		module:RegisterEvents('PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED')
	end
end

do
	function module:timer(elapsed)
		_graphSectionTimer = _graphSectionTimer + elapsed
		local nowTimer = ceil(_graphSectionTimer)
		if _graphSectionTimerRounded ~= nowTimer then
			_graphSectionTimerRounded = nowTimer
			for i=1,#_graphRaidSnapshot do
				local name = _graphRaidSnapshot[i]
				local _name = UnitCombatlogname(name)
				if _name then
					local data = graphData[_graphSectionTimerRounded]
					if _name ~= name then
						data.name[name] = _name
					end
					local health = UnitHealth(name)
					if health ~= 0 then
						data.health[name] = health
					end
					local power = UnitPower(name)
					if power ~= 0 then
						data.power[name] = power
					end
				end
			end
		end
	end
end

local autoSegmentsUPValue = module.db.autoSegments
function module.main:UNIT_SPELLCAST_SUCCEEDED(unitID,_,_,_,spellID)
	if autoSegmentsUPValue.UNIT_SPELLCAST_SUCCEEDED[spellID] then
		local guid = UnitGUID(unitID)
		if AntiSpam("BossWatcherUSS"..(guid or "0x0")..(spellID or "0"),0.5) then
			StartSegment("UNIT_SPELLCAST_SUCCEEDED",spellID)
		end
	end
end

function module.main:CHAT_MSG_RAID_BOSS_EMOTE(msg,sender)
	for emote,_ in pairs(autoSegmentsUPValue.CHAT_MSG_RAID_BOSS_EMOTE) do
		if msg:find(emote, nil, true) or msg:find(emote) then
			StartSegment("CHAT_MSG_RAID_BOSS_EMOTE",emote)
		end
	end
end

function module.main:RAID_BOSS_EMOTE(msg,sender)
	local spellID = msg:match("spell:(%d+)")
	if spellID then
		addChatMessage(sender,msg,spellID,GetTime())
	end
end
module.main.RAID_BOSS_WHISPER = module.main.RAID_BOSS_EMOTE

function module.main:SPELL_DAMAGE(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,_,amount,overkill,school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand, multistrike)
	--amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand, multistrike
	addDamage(sourceGUID,destGUID,amount,timestamp,spellId,overkill,school,blocked,absorbed,critical,multistrike)
	
	addSwitch(sourceGUID,destGUID,timestamp,1,spellId)
end
module.main.SPELL_PERIODIC_DAMAGE = module.main.SPELL_DAMAGE
module.main.RANGE_DAMAGE = module.main.SPELL_DAMAGE

function module.main:SWING_DAMAGE(timestamp,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,amount,overkill,school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand, multistrike)
	--amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand, multistrike
	addDamage(sourceGUID,destGUID,amount,timestamp,6603,overkill,school,blocked,absorbed,critical,multistrike)
	
	addSwitch(sourceGUID,destGUID,timestamp,1,6603)
end

function module.main:SPELL_HEAL(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,school,amount,overhealing,absorbed,critical,multistrike)
	addHeal(sourceGUID,destGUID,spellId,amount,overhealing,absorbed,critical,multistrike,school)
end
module.main.SPELL_PERIODIC_HEAL = module.main.SPELL_HEAL

function module.main:SPELL_AURA_APPLIED(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,_,_type,amount)
	addBuff(timestamp,sourceGUID,destGUID,UnitIsFriendlyByUnitFlag(sourceFlags),UnitIsFriendlyByUnitFlag(destFlags),spellId,_type,1,1)
	
	if autoSegmentsUPValue.SPELL_AURA_APPLIED[spellId] then
		StartSegment("SPELL_AURA_APPLIED",spellId)
	end
	
	if amount then
		addShield(sourceGUID,destGUID,spellId,amount)
	end
end

function module.main:SPELL_AURA_REMOVED(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,school,_type,amount)
	addBuff(timestamp,sourceGUID,destGUID,UnitIsFriendlyByUnitFlag(sourceFlags),UnitIsFriendlyByUnitFlag(destFlags),spellId,_type,2,1)
	
	if autoSegmentsUPValue.SPELL_AURA_REMOVED[spellId] then
		StartSegment("SPELL_AURA_REMOVED",spellId)
	end
	
	if amount then
		removeShield(sourceGUID,destGUID,spellId,amount,school)
	end
end

function module.main:SPELL_AURA_REFRESH(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,school,_type,amount)
	if amount then
		refreshShield(sourceGUID,destGUID,spellId,amount,school)
	end
end

function module.main:SPELL_AURA_APPLIED_DOSE(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,_,_type,stack)
	addBuff(timestamp,sourceGUID,destGUID,UnitIsFriendlyByUnitFlag(sourceFlags),UnitIsFriendlyByUnitFlag(destFlags),spellId,_type,3,stack)
end

function module.main:SPELL_AURA_REMOVED_DOSE(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,_,_type,stack)
	addBuff(timestamp,sourceGUID,destGUID,UnitIsFriendlyByUnitFlag(sourceFlags),UnitIsFriendlyByUnitFlag(destFlags),spellId,_type,4,stack)
end

function module.main:SPELL_CAST_SUCCESS(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId)
	addSwitch(sourceGUID,destGUID,timestamp,1,spellId)
	
	addCast(sourceGUID,destGUID,spellId,1,timestamp)
end

function module.main:SPELL_CAST_START(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId)
	--> npc cast
	addCast(sourceGUID,destGUID,spellId,2,timestamp)
	
	--> switch
	if sourceName and GetUnitInfoByUnitFlag(sourceFlags,1) == 1024 then
		local unitID = UnitInRaid(sourceName)
		if unitID then
			unitID = "raid"..unitID
			local targetGUID = UnitGUID(unitID.."target")
			if targetGUID and not UnitIsPlayerOrPet(targetGUID) then
				addSwitch(sourceGUID,targetGUID,timestamp,1,spellId)
			end
		end
	end
end

function module.main:UNIT_DIED(timestamp,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId)
	fightData.dies[#fightData.dies+1] = {destGUID,destFlags,timestamp,destFlags2}
	
	local uID = GUIDtoID(destGUID)
	if autoSegmentsUPValue.UNIT_DIED[ uID ] then
		StartSegment("UNIT_DIED",uID)
	end
end
module.main.UNIT_DESTROYED = module.main.UNIT_DIED

function module.main:SPELL_INTERRUPT(timestamp,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId,_,_,destSpell)
	fightData.interrupts[#fightData.interrupts+1]={sourceGUID,destGUID,spellId,destSpell,timestamp}
end

function module.main:SPELL_DISPEL(timestamp,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId,_,_,destSpell)
	fightData.dispels[#fightData.dispels+1]={sourceGUID,destGUID,spellId,destSpell,timestamp}
end
module.main.SPELL_STOLEN = module.main.SPELL_DISPEL

function module.main:SPELL_RESURRECT(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId)
	fightData.resurrests[#fightData.resurrests+1]={sourceGUID,destGUID,spellId,timestamp}
end

function module.main:SPELL_ENERGIZE(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,_,amount,powerType)
	addPower(destGUID,spellId,powerType,amount)
end

function module.main:SPELL_MISSED(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,school,missType,isOffHand,amountMissed)
	AddMiss(sourceGUID,destGUID,timestamp,spellId,missType,amountMissed,school)
end
function module.main:SWING_MISSED(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,missType,isOffHand,amountMissed)
	AddMiss(sourceGUID,destGUID,timestamp,6603,missType,amountMissed,0x1)
end
if ExRT.WOD then
	function module.main:SPELL_MISSED(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,spellId,_,school,missType,isOffHand,multistrike,amountMissed)
		AddMiss(sourceGUID,destGUID,timestamp,spellId,missType,amountMissed,school)
	end
	function module.main:SWING_MISSED(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,missType,isOffHand,multistrike,amountMissed)
		AddMiss(sourceGUID,destGUID,timestamp,6603,missType,amountMissed,0x1)
	end
end
module.main.SPELL_PERIODIC_MISSED = module.main.SPELL_MISSED
module.main.RANGE_MISSED = module.main.SPELL_MISSED

function module.main:ENVIRONMENTAL_DAMAGE(timestamp,sourceGUID,sourceName,sourceFlags,_,destGUID,destName,destFlags,_,environmentalType,amount,overkill,school,resisted,blocked,absorbed,critical,glancing,crushing,isOffHand,multistrike)
	AddEnvironmentalDamage(sourceGUID,destGUID,timestamp,environmentalType,amount,overkill,school,resisted,blocked,absorbed,critical,multistrike)
end

local CLEUEvents = {
	SPELL_HEAL = module.main.SPELL_HEAL,
	SPELL_PERIODIC_HEAL = module.main.SPELL_PERIODIC_HEAL,
	SPELL_PERIODIC_DAMAGE = module.main.SPELL_PERIODIC_DAMAGE,
	RANGE_DAMAGE = module.main.RANGE_DAMAGE,
	SPELL_DAMAGE = module.main.SPELL_DAMAGE,
	SWING_DAMAGE = module.main.SWING_DAMAGE,
	SPELL_AURA_APPLIED = module.main.SPELL_AURA_APPLIED,
	SPELL_AURA_REMOVED = module.main.SPELL_AURA_REMOVED,
	SPELL_AURA_REFRESH = module.main.SPELL_AURA_REFRESH,
	SPELL_AURA_APPLIED_DOSE = module.main.SPELL_AURA_APPLIED_DOSE,
	SPELL_AURA_REMOVED_DOSE = module.main.SPELL_AURA_REMOVED_DOSE,
	SPELL_CAST_SUCCESS = module.main.SPELL_CAST_SUCCESS,
	SPELL_CAST_START = module.main.SPELL_CAST_START,
	UNIT_DIED = module.main.UNIT_DIED,
	UNIT_DESTROYED = module.main.UNIT_DESTROYED,
	SPELL_INTERRUPT = module.main.SPELL_INTERRUPT,
	SPELL_DISPEL = module.main.SPELL_DISPEL,
	SPELL_STOLEN = module.main.SPELL_STOLEN,
	SPELL_RESURRECT = module.main.SPELL_RESURRECT,
	SPELL_ENERGIZE = module.main.SPELL_ENERGIZE,
	SPELL_PERIODIC_ENERGIZE = module.main.SPELL_ENERGIZE,
	SPELL_MISSED = module.main.SPELL_MISSED,
	SPELL_PERIODIC_MISSED = module.main.SPELL_PERIODIC_MISSED,
	RANGE_MISSED = module.main.RANGE_MISSED,
	SWING_MISSED = module.main.SWING_MISSED,
	ENVIRONMENTAL_DAMAGE = module.main.ENVIRONMENTAL_DAMAGE,
}

local function CLEUafterTimeFix(self,timestamp,event,hideCaster,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId,...)
	local eventFunc = CLEUEvents[event]
	if eventFunc then
		eventFunc(self,timestamp,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId,...)
	end
	
	addGUID(sourceGUID,sourceName)
	addGUID(destGUID,destName)
	
	updateReaction(sourceGUID,sourceFlags)
	updateReaction(destGUID,destFlags)
end

function module.main:COMBAT_LOG_EVENT_UNFILTERED(timestamp,event,hideCaster,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId,...)
	if not module.db.timeFix then
		module.db.timeFix = {GetTime(),timestamp}
		module.main.COMBAT_LOG_EVENT_UNFILTERED = CLEUafterTimeFix
		CLEUafterTimeFix(self,timestamp,event,hideCaster,sourceGUID,sourceName,sourceFlags,sourceFlags2,destGUID,destName,destFlags,destFlags2,spellId,...)
		module:RegisterEvents('COMBAT_LOG_EVENT_UNFILTERED')
	end
end

function module.main:UNIT_TARGET(unitID)
	local targetGUID = UnitGUID(unitID.."target")
	if targetGUID and not UnitIsPlayerOrPet(targetGUID) then
		local sourceGUID = UnitGUID(unitID)
		if GetUnitTypeByGUID(sourceGUID) == 0 then
			addSwitch(sourceGUID,targetGUID,GetTime(),2)
		end
	end
end

local function GlobalRecordStart()
	if not VExRT.BossWatcher.enabled then
		return
	end
	if fightData then
		module.main.ENCOUNTER_END()
	end
	module:UnregisterEvents('ENCOUNTER_START','ENCOUNTER_END','PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED')
	module.main.ENCOUNTER_START()
	
	print(ExRT.L.BossWatcherRecordStart)
end

local function GlobalRecordEnd()
	if not VExRT.BossWatcher.enabled then
		return
	end
	module.main.ENCOUNTER_END()
	module.main.ZONE_CHANGED_NEW_AREA()
	
	print(ExRT.L.BossWatcherRecordStop)
end

function module:slash(arg)
	if arg == "seg" then
		if not fightData or not VExRT.BossWatcher.enabled then
			return
		end
		StartSegment("SLASH")
	elseif arg == "bw s" or arg == "bw start" then
		GlobalRecordStart()
		print( ExRT.mds.CreateChatLink("BWGlobalRecordEnd",GlobalRecordEnd,ExRT.L.BossWatcherStopRecord), ExRT.L.BossWatcherStopRecord2 )
	elseif arg == "bw e" or arg == "bw end" then
		GlobalRecordEnd()
	elseif arg == "bw" then
		BWInterfaceFrameLoadFunc()
	end
end
ExRT.mds.BWNS = StartSegment

function BWInterfaceFrameLoad()
	if InCombatLockdown() then
		print(ExRT.L.SetErrorInCombat)
		return
	end
	isBWInterfaceFrameLoaded = true
	
	local BWInterfaceFrame_Name = 'GExRTBWInterfaceFrame'
	BWInterfaceFrame = CreateFrame('Frame',BWInterfaceFrame_Name,UIParent,"ExRTBWInterfaceFrame")
	BWInterfaceFrame:SetPoint("CENTER",0,0)
	BWInterfaceFrame.HeaderText:SetText(ExRT.L.BossWatcher)
	BWInterfaceFrame.backToInterface:SetText("<<")
	BWInterfaceFrame:SetMovable(true)
	BWInterfaceFrame:RegisterForDrag("LeftButton")
	BWInterfaceFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
	BWInterfaceFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
	BWInterfaceFrame:SetDontSavePosition(true)
	
	BWInterfaceFrame.backToInterface.tooltipText = ExRT.L.BossWatcherBackToInterface
	BWInterfaceFrame.buttonClose.tooltipText = ExRT.L.BossWatcherButtonClose
	
	BWInterfaceFrame:Hide()
	
	BWInterfaceFrame.bossButton:SetText(ExRT.L.BossWatcherLastFight)
	BWInterfaceFrame.bossButton:SetWidth(BWInterfaceFrame.bossButton:GetTextWidth()+30)
	
	local reportData = {{},{},{},{},{},{},{},{},{}}
	BWInterfaceFrame.report = ExRT.lib.CreateButton(nil,BWInterfaceFrame,150,22,nil,0,0,ExRT.L.BossWatcherCreateReport,nil,ExRT.L.BossWatcherCreateReport)
	ExRT.lib.SetPoint(BWInterfaceFrame.report,"TOPRIGHT",BWInterfaceFrame.backToInterface,"TOPLEFT",0,0)
	BWInterfaceFrame.report:SetScript("OnClick",function ()
		local activeTab = BWInterfaceFrame.tab.selected	
			
		---Tab with mobs fix
		if activeTab == 4 then
			local activeTabOnPage = BWInterfaceFrame.tab.tabs[4].infoTabs.selected
			if activeTabOnPage == 1 then
				local lines = {strsplit("\n", BWInterfaceFrame.tab.tabs[4].switchSpellBox.EditBox:GetText())}
				reportData[4] = lines
			elseif activeTabOnPage == 1 then
				local lines = {strsplit("\n", BWInterfaceFrame.tab.tabs[4].switchTargetBox.EditBox:GetText())}
				reportData[4] = lines
			else
				local lines = {strsplit("\n", BWInterfaceFrame.tab.tabs[4].infoBoxText:GetText())}
				reportData[4] = lines
			end			
		end
		
		ExRT.mds.toChatWindow(reportData[activeTab])
	end)
	BWInterfaceFrame.report:Hide()
	
	---- Some updates
	for i=5,#module.db.buffsFilters do
		for _,sID in ipairs(module.db.buffsFilters[i][-2]) do
			module.db.buffsFilters[i][sID] = true
		end
	end
	
	
	---- Helpful functions
	local function GetGUID(GUID)
		if GUID and module.db.data[module.db.nowNum].guids[GUID] and module.db.data[module.db.nowNum].guids[GUID] ~= "nil" then
			return module.db.data[module.db.nowNum].guids[GUID]
		else
			return ExRT.L.BossWatcherUnknown
		end
	end
	
	local function CloseDropDownMenus_fix()
		CloseDropDownMenus()
	end
	
	local function timestampToFightTime(time)
		if not module.db.timeFix then
			return 0
		end
		local res = time - (module.db.timeFix[2] - module.db.timeFix[1] + module.db.data[module.db.nowNum].encounterStart) 
		return max(res,0)
	end
	
	local function GUIDtoText(patt,GUID)
		if VExRT.BossWatcher.GUIDs and GUID and GUID ~= "" then
			patt = patt or "%s"
			local _type = ExRT.mds.GetUnitTypeByGUID(GUID)
			if _type == 0 then
				return ""
			elseif _type == 3 or _type == 5 then
				local mobSpawnID = nil
				if not ExRT.WOD then
					mobSpawnID = tonumber(GUID:sub(-8), 16)
				else
					local spawnID = GUID:match(":([^:]+)$")
					if spawnID then
						mobSpawnID = tonumber(spawnID, 16)
					end
				end
				if mobSpawnID then
					return format(patt,tostring(mobSpawnID))
				else
					return format(patt,GUID)
				end
			else
				return format(patt,GUID)
			end
		else
			return ""
		end
	end
	
	local function TimeLineShowSpellID(spellid)
		if VExRT.BossWatcher.timeLineSpellID then
			return " ["..spellid.."]"
		else
			return ""
		end
	end
	
	local function SetSchoolColorsToLine(self,school)
		local isNotGradient = ExRT.mds.table_find(module.db.schoolsDefault,school) or school == 0
		if isNotGradient then
			self:SetVertexColor(module.db.schoolsColors[school].r,module.db.schoolsColors[school].g,module.db.schoolsColors[school].b, 1)
		else
			if module.db.schoolsColors[school] then
				self:SetVertexColor(module.db.schoolsColors[school].r,module.db.schoolsColors[school].g,module.db.schoolsColors[school].b,1)
			else
				local school1,school2 = nil
				for i=1,#module.db.schoolsDefault do
					local isSchool = bit.band(school,module.db.schoolsDefault[i]) > 0
					if isSchool and not school1 then
						school1 = module.db.schoolsDefault[i]
					elseif isSchool and not school2 then
						school2 = module.db.schoolsDefault[i]
					end
				end
				if school1 and school2 then
					self:SetVertexColor(1,1,1,1)
					self:SetGradientAlpha("HORIZONTAL", module.db.schoolsColors[school1].r,module.db.schoolsColors[school1].g,module.db.schoolsColors[school1].b,1,module.db.schoolsColors[school2].r,module.db.schoolsColors[school2].g,module.db.schoolsColors[school2].b,1)
				elseif school1 and not school2 then
					self:SetVertexColor(module.db.schoolsColors[school1].r,module.db.schoolsColors[school1].g,module.db.schoolsColors[school1].b, 1)
				else
					self:SetVertexColor(0.8,0.8,0.8, 1)
				end
			end
		end
	end
	
	---- Bugfix functions
	local _GetSpellLink = GetSpellLink
	local function GetSpellLink(spellID)
		local link = _GetSpellLink(spellID)
		if link then
			return link
		end
		local spellName = GetSpellInfo(spellID)
		return spellName or "Unk"
	end
	
	---- Update functions
	local function ClearAndReloadData(isSegmentReload)
		module.db.nowData = {
			damage = {},
			damage_seen = {},
			heal = {},
			switch = {},
			cast = {},
			interrupts = {},
			dispels = {},
			auras = {},
			power = {},
			dies = {},
			chat = {},
			resurrests = {},
		}
		if not module.db.data[module.db.nowNum] or isSegmentReload then
			return
		end
		for i=1,#module.db.data[module.db.nowNum].fight do
			AddSegmentToData(i)
		end
	end
	
	BWInterfaceFrame:SetScript("OnShow",function (self)
		if self.nowFightID ~= module.db.data[module.db.nowNum].fightID then
			if module.db.data[module.db.nowNum].encounterEnd == 0 then
				print(ExRT.L.BossWatcherCombatError)
				return
			end
			ClearAndReloadData()
			self.nowFightID = module.db.data[module.db.nowNum].fightID
			self.bossButton:SetText( (module.db.data[module.db.nowNum].encounterName or ExRT.L.BossWatcherLastFight)..date(": %H:%M - ", module.db.data[module.db.nowNum].encounterStartGlobal )..date("%H:%M", module.db.data[module.db.nowNum].encounterStartGlobal + (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart) ) )
			self.bossButton:SetWidth(self.bossButton:GetTextWidth()+30)
			for i=1,#reportData do
				wipe(reportData[i])
			end
			self:Hide()
			self:Show()
		end
	end)
	
	BWInterfaceFrame.bossButtonDropDown = CreateFrame("Frame", BWInterfaceFrame_Name.."BossButtonDropDown", nil, "UIDropDownMenuTemplate")
	BWInterfaceFrame.bossButton:SetScript("OnClick",function (self)
		local fightsList = {
			{
				text = ExRT.L.BossWatcherSelectFight, 
				isTitle = true, 
				notCheckable = true, 
				notClickable = true 
			},
		}
		for i=1,#module.db.data do
			local colorCode = ""
			if i == module.db.nowNum then
				colorCode = "|cff00ff00"
			end
			fightsList[#fightsList + 1] = {
				text = i..". "..colorCode..(module.db.data[i].encounterName or ExRT.L.BossWatcherLastFight)..date(": %H:%M - ", module.db.data[i].encounterStartGlobal )..date("%H:%M", module.db.data[i].encounterStartGlobal + (module.db.data[i].encounterEnd - module.db.data[i].encounterStart) ),
				notCheckable = true,
				func = function() 
					module.db.nowNum = i
					self:SetText( (module.db.data[i].encounterName or ExRT.L.BossWatcherLastFight)..date(": %H:%M - ", module.db.data[i].encounterStartGlobal )..date("%H:%M", module.db.data[i].encounterStartGlobal + (module.db.data[i].encounterEnd - module.db.data[i].encounterStart) ) )
					self:SetWidth(self:GetTextWidth()+30)
					BWInterfaceFrame:Hide()
					BWInterfaceFrame:Show()
				end,
			}
		end
		fightsList[#fightsList + 1] = {
			text = ExRT.L.BossWatcherSelectFightClose,
			notCheckable = true,
			func = CloseDropDownMenus_fix,
		}
		EasyMenu(fightsList, BWInterfaceFrame.bossButtonDropDown, "cursor", 10 , -15, "MENU")
	end)
	BWInterfaceFrame.bossButton.tooltipText = ExRT.L.BossWatcherSelectFight
	
	
	---- Tabs
	BWInterfaceFrame.tab = ExRT.lib.CreateTabFrame(BWInterfaceFrame_Name.."Tab",BWInterfaceFrame,835,590,0,0,10,1,ExRT.L.BossWatcherTabMobs,ExRT.L.BossWatcherTabHeal,ExRT.L.BossWatcherTabBuffsAndDebuffs,ExRT.L.BossWatcherTabEnemy,ExRT.L.BossWatcherTabPlayersSpells,ExRT.L.BossWatcherTabEnergy,ExRT.L.BossWatcherTabInterruptAndDispel,ExRT.L.BossWatcherTabGraphics,ExRT.L.BossWatcherSegments,ExRT.L.BossWatcherTabSettings)
	ExRT.lib.SetPoint(BWInterfaceFrame.tab,"TOP",BWInterfaceFrame,0,-60)	


	
	---- Settings tab-button
	BWInterfaceFrame.tab.tabs[10]:SetScript("OnShow",function (self)
		if not module.options.isLoaded then
			if InCombatLockdown() then
				print(ExRT.L.SetErrorInCombat)
				return
			end
			module.options:Load()
			module.options:SetScript("OnShow",nil)
			module.options.isLoaded = true
		end
		module.options:SetParent(self)
		module.options:ClearAllPoints()
		module.options:SetAllPoints(self)
		module.options:Show()
	end)
	
		

	---- TimeLine Frame
	BWInterfaceFrame.timeLineFrame = CreateFrame('Frame',nil,BWInterfaceFrame.tab)
	BWInterfaceFrame.timeLineFrame.width = 820
	BWInterfaceFrame.timeLineFrame:SetSize(BWInterfaceFrame.timeLineFrame.width,60)
	
	local TimeLine_Pieces = 60
	local function TimeLinePieceOnEnter(self)
		if self.tooltip and #self.tooltip > 0 then
			ExRT.lib.TooltipShow(self,"ANCHOR_RIGHT",ExRT.L.BossWatcherTimeLineTooltipTitle..":",unpack(self.tooltip))
		end
	end
	BWInterfaceFrame.timeLineFrame.timeLine = CreateFrame("Frame",nil,BWInterfaceFrame.timeLineFrame)
	BWInterfaceFrame.timeLineFrame.timeLine:SetSize(BWInterfaceFrame.timeLineFrame.width,30)
	BWInterfaceFrame.timeLineFrame.timeLine:SetPoint("TOP",0,0)
	for i=1,TimeLine_Pieces do
		local tlWidth = BWInterfaceFrame.timeLineFrame.width/TimeLine_Pieces
		BWInterfaceFrame.timeLineFrame.timeLine[i] = CreateFrame("Button",nil,BWInterfaceFrame.timeLineFrame.timeLine)
		BWInterfaceFrame.timeLineFrame.timeLine[i]:SetSize(tlWidth,30)
		BWInterfaceFrame.timeLineFrame.timeLine[i]:SetPoint("TOPLEFT",(i-1)*tlWidth,0)
		BWInterfaceFrame.timeLineFrame.timeLine[i]:SetScript("OnEnter",TimeLinePieceOnEnter)
		BWInterfaceFrame.timeLineFrame.timeLine[i]:SetScript("OnLeave",ExRT.lib.TooltipHide)	
	end
	BWInterfaceFrame.timeLineFrame.timeLine.texture = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND",nil,0)
	BWInterfaceFrame.timeLineFrame.timeLine.texture:SetTexture("Interface\\AddOns\\ExRT\\media\\bar9.tga")
	BWInterfaceFrame.timeLineFrame.timeLine.texture:SetVertexColor(0.3, 1, 0.3, 1)
	BWInterfaceFrame.timeLineFrame.timeLine.texture:SetAllPoints()
	
	BWInterfaceFrame.timeLineFrame.timeLine.textLeft = ExRT.lib.CreateText(BWInterfaceFrame.timeLineFrame.timeLine,200,16,nil,0,0,"LEFT","TOP",nil,12,"",nil,1,1,1,1)
	ExRT.lib.SetPoint(BWInterfaceFrame.timeLineFrame.timeLine.textLeft,"BOTTOMLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOMLEFT", 2, 2)
	
	BWInterfaceFrame.timeLineFrame.timeLine.textCenter = ExRT.lib.CreateText(BWInterfaceFrame.timeLineFrame.timeLine,200,16,nil,0,0,"CENTER","TOP",nil,12,"",nil,1,1,1,1)
	ExRT.lib.SetPoint(BWInterfaceFrame.timeLineFrame.timeLine.textCenter,"BOTTOM",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOM", 0, 2)
	
	BWInterfaceFrame.timeLineFrame.timeLine.textRight = ExRT.lib.CreateText(BWInterfaceFrame.timeLineFrame.timeLine,200,16,nil,0,0,"RIGHT","TOP",nil,12,"",nil,1,1,1,1)
	ExRT.lib.SetPoint(BWInterfaceFrame.timeLineFrame.timeLine.textRight,"BOTTOMRIGHT",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOMRIGHT", -2, 2)
	
	BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND")
	BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine:SetTexture(1,1,1,1)
	BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine:SetGradientAlpha("VERTICAL", 1,0.2,0.2, 0, 1,0.2,0.2, 0.7)
	BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine._SetPoint = BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine.SetPoint
	BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine.SetPoint = function(self,_start,_end)
		self:ClearAllPoints()
		self:_SetPoint("TOPLEFT",self:GetParent(),"BOTTOMLEFT",_start*BWInterfaceFrame.timeLineFrame.width,0)
		self:SetSize((_end-_start)*BWInterfaceFrame.timeLineFrame.width,16)
		self:Show()
	end
	
	BWInterfaceFrame.timeLineFrame.timeLine.arrow = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND")
	BWInterfaceFrame.timeLineFrame.timeLine.arrow:SetTexture("Interface\\CURSOR\\Quest")
	BWInterfaceFrame.timeLineFrame.timeLine.arrow:Hide()

	BWInterfaceFrame.timeLineFrame.timeLine.arrowNow = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND")
	BWInterfaceFrame.timeLineFrame.timeLine.arrowNow:SetTexture("Interface\\CURSOR\\Inspect")	
	BWInterfaceFrame.timeLineFrame.timeLine.arrowNow:Hide()
	
	BWInterfaceFrame.timeLineFrame.timeLine.redLine = {}
	local function CreateRedLine(i)
		BWInterfaceFrame.timeLineFrame.timeLine.redLine[i] = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND",nil,5)
		BWInterfaceFrame.timeLineFrame.timeLine.redLine[i]:SetTexture(0.7, 0.1, 0.1, 0.5)
		BWInterfaceFrame.timeLineFrame.timeLine.redLine[i]:SetSize(2,30)
	end
	
	BWInterfaceFrame.timeLineFrame.timeLine.blueLine = {}
	local function CreateBlueLine(i)
		BWInterfaceFrame.timeLineFrame.timeLine.blueLine[i] = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND",nil,6)
		BWInterfaceFrame.timeLineFrame.timeLine.blueLine[i]:SetTexture(0.1, 0.1, 0.7, 0.5)
		BWInterfaceFrame.timeLineFrame.timeLine.blueLine[i]:SetSize(3,30)
	end
	
	local function UpdateTimeLine()
		local fight_dur = module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart
		BWInterfaceFrame.timeLineFrame.timeLine.textLeft:SetText( date("%H:%M:%S", module.db.data[module.db.nowNum].encounterStartGlobal) )
		BWInterfaceFrame.timeLineFrame.timeLine.textRight:SetText( date("%M:%S", fight_dur) )
		BWInterfaceFrame.timeLineFrame.timeLine.textCenter:SetText( date("%M:%S", fight_dur / 2) )

		local redLineNum = 0
		for i=1,TimeLine_Pieces do
			if not BWInterfaceFrame.timeLineFrame.timeLine[i].tooltip then
				BWInterfaceFrame.timeLineFrame.timeLine[i].tooltip = {}
			end
			wipe(BWInterfaceFrame.timeLineFrame.timeLine[i].tooltip)
		end
		local addToToolipTable = {}
		for mobGUID,mobData in pairs(module.db.nowData.cast) do
			--if ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[mobGUID],2) == 512 then
			if ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[mobGUID],3) == 64 then
				for i=1,#mobData do
					local _time = timestampToFightTime(mobData[i][1])
					
					local tooltipIndex = _time / fight_dur
					
					redLineNum = redLineNum + 1
					if not BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum] then
						CreateRedLine(redLineNum)
					end
					BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum]:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"TOPLEFT",BWInterfaceFrame.timeLineFrame.width*tooltipIndex,0)
					BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum]:Show()
					
					tooltipIndex = min( floor( (TimeLine_Pieces - 0.01)*tooltipIndex + 1 ) , TimeLine_Pieces)
					
					local spellName,_,spellTexture = GetSpellInfo(mobData[i][2])
					
					local targetInfo = ""
					if mobData[i][4] and mobData[i][4] ~= "" then
						targetInfo = " "..ExRT.L.BossWatcherTimeLineOnText.." |c"..ExRT.mds.classColorByGUID(mobData[i][4])..GetGUID(mobData[i][4]).."|r"
					end
					
					addToToolipTable[#addToToolipTable + 1] = {tooltipIndex,_time,"[" .. date("%M:%S", _time )  .. "] |c"..ExRT.mds.classColorByGUID(mobGUID) .. GetGUID(mobGUID) .."|r" .. GUIDtoText("(%s)",mobGUID) .. ( mobData[i][3] == 1 and " "..ExRT.L.BossWatcherTimeLineCast.." " or " "..ExRT.L.BossWatcherTimeLineCastStart.." " ) .. format("%s%s%s",spellTexture and "|T"..spellTexture..":0|t " or "",spellName or "???",TimeLineShowSpellID(mobData[i][2])) .. targetInfo }
				end
			end
		end
		for _,chatData in ipairs(module.db.nowData.chat) do
			local _time = min( max(chatData[4] - module.db.data[module.db.nowNum].encounterStart,0) , module.db.data[module.db.nowNum].encounterEnd)
			
			local tooltipIndex = _time / fight_dur
			redLineNum = redLineNum + 1
			if not BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum] then
				CreateRedLine(redLineNum)
			end
			BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum]:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"TOPLEFT",BWInterfaceFrame.timeLineFrame.width*tooltipIndex,0)
			BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum]:Show()
			
			tooltipIndex = min( floor( (TimeLine_Pieces - 0.01)*tooltipIndex + 1 ) , TimeLine_Pieces)
			
			local spellName,_,spellTexture = GetSpellInfo(chatData[3])
						
			addToToolipTable[#addToToolipTable + 1] = {tooltipIndex,_time,"[" .. date("%M:%S", _time )  .. "] "..  ExRT.L.BossWatcherChatSpellMsg .. " " .. format("%s%s%s",spellTexture and "|T"..spellTexture..":0|t " or "",spellName or "???",TimeLineShowSpellID(chatData[3])) }
		end
		for _,resData in ipairs(module.db.nowData.resurrests) do
			local _time = timestampToFightTime(resData[4])
			
			local tooltipIndex = _time / fight_dur
			redLineNum = redLineNum + 1
			if not BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum] then
				CreateRedLine(redLineNum)
			end
			BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum]:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"TOPLEFT",BWInterfaceFrame.timeLineFrame.width*tooltipIndex,0)
			BWInterfaceFrame.timeLineFrame.timeLine.redLine[redLineNum]:Show()
			
			tooltipIndex = min( floor( (TimeLine_Pieces - 0.01)*tooltipIndex + 1 ) , TimeLine_Pieces)
			local spellName,_,spellTexture = GetSpellInfo(resData[3])
			
			addToToolipTable[#addToToolipTable + 1] = {tooltipIndex,_time,"[" .. date("%M:%S", _time )  .. "] |c"..ExRT.mds.classColorByGUID(resData[1]) .. GetGUID(resData[1]) .."|r" ..  GUIDtoText("(%s)",resData[1]) .. " ".. ExRT.L.BossWatcherTimeLineCast.. " " .. format("%s%s%s",spellTexture and "|T"..spellTexture..":0|t " or "",spellName or "???",TimeLineShowSpellID(resData[3])) .. " "..ExRT.L.BossWatcherTimeLineOnText.." |c"..ExRT.mds.classColorByGUID(resData[2])..GetGUID(resData[2]).."|r" }
		end
		for i=(redLineNum+1),#BWInterfaceFrame.timeLineFrame.timeLine.redLine do
			BWInterfaceFrame.timeLineFrame.timeLine.redLine[i]:Hide()
		end
		
		local blueLineNum = 0
		for i=1,#module.db.nowData.dies do
			if ExRT.mds.GetUnitInfoByUnitFlag(module.db.nowData.dies[i][2],1) == 1024 then
				local _time = timestampToFightTime(module.db.nowData.dies[i][3])
				
				local tooltipIndex = _time / fight_dur
				
				blueLineNum = blueLineNum + 1
				if not BWInterfaceFrame.timeLineFrame.timeLine.blueLine[blueLineNum] then
					CreateBlueLine(blueLineNum)
				end
				BWInterfaceFrame.timeLineFrame.timeLine.blueLine[blueLineNum]:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"TOPLEFT",BWInterfaceFrame.timeLineFrame.width*tooltipIndex,0)
				BWInterfaceFrame.timeLineFrame.timeLine.blueLine[blueLineNum]:Show()
				
				tooltipIndex = min ( floor( (TimeLine_Pieces - 0.01)*tooltipIndex + 1 ) , TimeLine_Pieces)
				
				addToToolipTable[#addToToolipTable + 1] = {tooltipIndex,_time,"[" .. date("%M:%S", _time )  .. "] |cffee5555" .. GetGUID(module.db.nowData.dies[i][1]) .. GUIDtoText("(%s)",module.db.nowData.dies[i][1])  .. " "..ExRT.L.BossWatcherTimeLineDies.."|r"}
			end
		end
		for i=(blueLineNum+1),#BWInterfaceFrame.timeLineFrame.timeLine.blueLine do
			BWInterfaceFrame.timeLineFrame.timeLine.blueLine[i]:Hide()
		end
		
		table.sort(addToToolipTable,function (a,b) return a[2] < b[2] end)
		for i=1,#addToToolipTable do
			table.insert(BWInterfaceFrame.timeLineFrame.timeLine[ addToToolipTable[i][1] ].tooltip,{addToToolipTable[i][3],1,1,1})
		end
	end
	
	BWInterfaceFrame.timeLineFrame:SetScript("OnShow",function (self)
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdateTimeLine()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)

	
	
	local tab,tabName = nil
	---- Damage Tab
	tab = BWInterfaceFrame.tab.tabs[1]
	tabName = BWInterfaceFrame_Name.."DamageTab"
	
	local sourceVar,destVar = nil
	local DamageTab_SetLine = nil
	local DamageShowAll = false
	local Damage_Last_Func = nil
	local Damage_Last_doEnemy = nil
	
	local function DamageTab_UpdateLinesPlayers(doEnemy)
		Damage_Last_Func = DamageTab_UpdateLinesPlayers
		Damage_Last_doEnemy = doEnemy
		local damage = {}
		local total = 0
		local totalOver = 0
		for destGUID,destData in pairs(module.db.nowData.damage) do
			if not destVar or destVar == destGUID then
				local isEnemy = false
				if ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[destGUID],2) == 512 then
					isEnemy = true
				end
				for sourceGUID,sourceData in pairs(destData) do
					local owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
					if owner then
						sourceGUID = owner
					end
					if not sourceVar or sourceVar == sourceGUID then
						if (isEnemy and doEnemy) or (not isEnemy and not doEnemy) then
							local inDamagePos = ExRT.mds.table_find(damage,sourceGUID,1)
							if not inDamagePos then
								inDamagePos = #damage + 1
								damage[inDamagePos] = {sourceGUID,0,0,0,0,0,0}
							end
							for spellID,spellAmount in pairs(sourceData) do
								damage[inDamagePos][2] = damage[inDamagePos][2] + spellAmount.amount - spellAmount.overkill
								damage[inDamagePos][3] = damage[inDamagePos][3] + spellAmount.overkill	--overkill
								damage[inDamagePos][4] = damage[inDamagePos][4] + spellAmount.blocked	--blocked
								damage[inDamagePos][5] = damage[inDamagePos][5] + spellAmount.absorbed	--absorbed
								damage[inDamagePos][6] = damage[inDamagePos][6] + spellAmount.crit	--crit
								damage[inDamagePos][7] = damage[inDamagePos][7] + spellAmount.ms	--ms
								total = total + spellAmount.amount - spellAmount.overkill
								totalOver = totalOver + spellAmount.overkill + spellAmount.blocked + spellAmount.absorbed
							end
						end
					end
				end
			end
		end
		local totalIsFull = 1
		total = max(total,1)
		if total == 1 and #damage == 0 then
			total = 0
			totalIsFull = 0
		end
		
		local _max = nil
		wipe(reportData[1])
		reportData[1][1] = (sourceVar and GetGUID(sourceVar) or ExRT.L.BossWatcherAllSources).." > "..(destVar and GetGUID(destVar) or ExRT.L.BossWatcherAllTargets)
		if not DamageShowAll then
			reportData[1][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total)
			sort(damage,function(a,b) return a[2]>b[2] end)
			_max = damage[1] and damage[1][2] or 0
			DamageTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total,total / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart))
		else
			reportData[1][2] = "Всего - "..ExRT.mds.shortNumber(total + totalOver)
			sort(damage,function(a,b) return (a[2]+a[3]+a[4]+a[5])>(b[2]+b[3]+b[4]+b[5]) end)
			_max = damage[1] and (damage[1][2]+damage[1][3]+damage[1][4]+damage[1][5]) or 0
			DamageTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total + totalOver,(total + totalOver) / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,nil,nil,nil,totalOver / max(total + totalOver,1))		
		end
		for i=1,#damage do
			local class = nil
			if damage[i][1] and damage[i][1] ~= "" then
				class = select(2,GetPlayerInfoByGUID(damage[i][1]))
			end
			local icon = ""
			if class and CLASS_ICON_TCOORDS[class] then
				icon = {"Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES",unpack(CLASS_ICON_TCOORDS[class])}
			end
			local tooltipData = {GetGUID(damage[i][1]),
				{ExRT.L.BossWatcherDamageTooltipOverkill,ExRT.mds.shortNumber(damage[i][3])},
				{ExRT.L.BossWatcherDamageTooltipBlocked,ExRT.mds.shortNumber(damage[i][4])},
				{ExRT.L.BossWatcherDamageTooltipAbsorbed,ExRT.mds.shortNumber(damage[i][5])},
				{ExRT.L.BossWatcherDamageTooltipTotal,ExRT.mds.shortNumber(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])},
				{" "," "},
				{ExRT.L.BossWatcherDamageTooltipFromCrit,format("%s (%.1f%%)",ExRT.mds.shortNumber(damage[i][6]),damage[i][6]/max(1,damage[i][2]+damage[i][3])*100)},
				{ExRT.L.BossWatcherDamageTooltipFromMs,format("%s (%.1f%%)",ExRT.mds.shortNumber(damage[i][7]),damage[i][7]/max(1,damage[i][2]+damage[i][3])*100)},
			}
			if not DamageShowAll then
				DamageTab_SetLine(i+1,icon,GetGUID(damage[i][1])..GUIDtoText(" [%s]",damage[i][1]),damage[i][2]/total,damage[i][2]/max(_max,1),damage[i][2],damage[i][2]/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,damage[i][1],doEnemy,nil,tooltipData)
				reportData[1][#reportData[1]+1] = i..". "..GetGUID(damage[i][1]).." - "..ExRT.mds.shortNumber(damage[i][2])
			else
				DamageTab_SetLine(i+1,icon,GetGUID(damage[i][1])..GUIDtoText(" [%s]",damage[i][1]),(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/(total + totalOver),(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/max(_max,1),damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5],(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,damage[i][1],doEnemy,nil,tooltipData,nil,(damage[i][3]+damage[i][4]+damage[i][5])/max(1,damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5]))
				reportData[1][#reportData[1]+1] = i..". "..GetGUID(damage[i][1]).." - "..ExRT.mds.shortNumber(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])			
			end
		end
		for i=#damage+2,#BWInterfaceFrame.tab.tabs[1].lines do
			BWInterfaceFrame.tab.tabs[1].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[1].scroll.SetNewHeight(BWInterfaceFrame.tab.tabs[1].scroll,(#damage+1) * 20)
	end
	local function DamageTab_UpdateLinesSpells(doEnemy)
		Damage_Last_Func = DamageTab_UpdateLinesSpells
		Damage_Last_doEnemy = doEnemy
		local damage = {}
		local total = 0
		local totalOver = 0
		for destGUID,destData in pairs(module.db.nowData.damage) do
			if not destVar or destVar == destGUID then
				local isEnemy = false
				if ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[destGUID],2) == 512 then
					isEnemy = true
				end
				for sourceGUID,sourceData in pairs(destData) do
					local owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
					if owner then
						sourceGUID = owner
					end
					if not sourceVar or sourceVar == sourceGUID then
						if (isEnemy and doEnemy) or (not isEnemy and not doEnemy) then
							for spellID,spellAmount in pairs(sourceData) do
								if owner then
									spellID = -spellID
								end
								local inDamagePos = ExRT.mds.table_find(damage,spellID,1)
								if not inDamagePos then
									inDamagePos = #damage + 1
									damage[inDamagePos] = {spellID,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
								end
								damage[inDamagePos][2] = damage[inDamagePos][2] + spellAmount.amount - spellAmount.overkill	--amount
								damage[inDamagePos][3] = damage[inDamagePos][3] + spellAmount.count	--count
								damage[inDamagePos][4] = damage[inDamagePos][4] + spellAmount.overkill	--overkill
								damage[inDamagePos][5] = damage[inDamagePos][5] + spellAmount.blocked	--blocked
								damage[inDamagePos][6] = damage[inDamagePos][6] + spellAmount.absorbed	--absorbed
								damage[inDamagePos][7] = damage[inDamagePos][7] + spellAmount.crit	--crit
								damage[inDamagePos][8] = damage[inDamagePos][8] + spellAmount.critcount	--crit count
								damage[inDamagePos][9] = max(damage[inDamagePos][9],spellAmount.critmax)--crit max
								damage[inDamagePos][10] = damage[inDamagePos][10] + spellAmount.ms	--ms
								damage[inDamagePos][11] = damage[inDamagePos][11] + spellAmount.mscount	--ms count
								damage[inDamagePos][12] = max(damage[inDamagePos][12],spellAmount.msmax)--ms max
								damage[inDamagePos][13] = max(damage[inDamagePos][13],spellAmount.hitmax)--hit max
								damage[inDamagePos][14] = damage[inDamagePos][14] + spellAmount.parry	--parry
								damage[inDamagePos][15] = damage[inDamagePos][15] + spellAmount.dodge	--dodge
								damage[inDamagePos][16] = damage[inDamagePos][16] + spellAmount.miss	--other miss
								total = total + spellAmount.amount - spellAmount.overkill
								totalOver = totalOver + spellAmount.overkill + spellAmount.blocked + spellAmount.absorbed
							end
						end
					end
				end
			end
		end
		local totalIsFull = 1
		total = max(total,1)
		if total == 1 and #damage == 0 then
			total = 0
			totalIsFull = 0
		end
		local _max = nil
		wipe(reportData[1])
		reportData[1][1] = (sourceVar and GetGUID(sourceVar) or ExRT.L.BossWatcherAllSources).." > "..(destVar and GetGUID(destVar) or ExRT.L.BossWatcherAllTargets)
		if not DamageShowAll then
			reportData[1][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total)
			sort(damage,function(a,b) return a[2]>b[2] end)
			_max = damage[1] and damage[1][2] or 0
			DamageTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total,total / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart))
		else
			reportData[1][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total + totalOver)
			sort(damage,function(a,b) return (a[2]+a[3]+a[4]+a[5])>(b[2]+b[3]+b[4]+b[5]) end)
			_max = damage[1] and (damage[1][2]+damage[1][3]+damage[1][4]+damage[1][5]) or 0
			DamageTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total + totalOver,(total + totalOver) / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,nil,nil,nil,totalOver / max(total + totalOver,1))		
		end
		for i=1,#damage do
			local isPetAbility = damage[i][1] < 0
			if isPetAbility then
				damage[i][1] = -damage[i][1]
			end
			local spellName,_,spellIcon = GetSpellInfo(damage[i][1])
			if isPetAbility then
				spellName = ExRT.L.BossWatcherPetText..": "..spellName
			end
			local tooltipData = {spellName,
				{ExRT.L.BossWatcherDamageTooltipCount,damage[i][3]-damage[i][11]},
				{ExRT.L.BossWatcherDamageTooltipMaxHit,damage[i][13]},
				{ExRT.L.BossWatcherDamageTooltipMidHit,ExRT.mds.Round((damage[i][2]-damage[i][7]-damage[i][10]+damage[i][4])/max(damage[i][3]-damage[i][8]-damage[i][11],1))},
				{ExRT.L.BossWatcherDamageTooltiCritCount,format("%d (%.1f%%)",damage[i][8],damage[i][8]/damage[i][3]*100)},
				{ExRT.L.BossWatcherDamageTooltiCritAmount,ExRT.mds.shortNumber(damage[i][7])},
				{ExRT.L.BossWatcherDamageTooltiMaxCrit,damage[i][9]},
				{ExRT.L.BossWatcherDamageTooltiMidCrit,ExRT.mds.Round(damage[i][7]/max(damage[i][8],1))},
				{ExRT.L.BossWatcherDamageTooltiMsCount,format("%d (%.1f%%)",damage[i][11],damage[i][11]/damage[i][3]*100)},
				{ExRT.L.BossWatcherDamageTooltiMsAmount,ExRT.mds.shortNumber(damage[i][10])},
				{ExRT.L.BossWatcherDamageTooltiMaxMs,damage[i][12]},				
				{ExRT.L.BossWatcherDamageTooltiMidMs,ExRT.mds.Round(damage[i][10]/max(damage[i][11],1))},
				{ExRT.L.BossWatcherDamageTooltipParry,format("%d (%.1f%%)",damage[i][14],damage[i][14]/damage[i][3]*100)},
				{ExRT.L.BossWatcherDamageTooltipDodge,format("%d (%.1f%%)",damage[i][15],damage[i][15]/damage[i][3]*100)},
				{ExRT.L.BossWatcherDamageTooltipMiss,format("%d (%.1f%%)",damage[i][16],damage[i][16]/damage[i][3]*100)},
				{ExRT.L.BossWatcherDamageTooltipOverkill,ExRT.mds.shortNumber(damage[i][4])},
				{ExRT.L.BossWatcherDamageTooltipBlocked,ExRT.mds.shortNumber(damage[i][5])},
				{ExRT.L.BossWatcherDamageTooltipAbsorbed,ExRT.mds.shortNumber(damage[i][6])},
				{ExRT.L.BossWatcherDamageTooltipTotal,ExRT.mds.shortNumber(damage[i][4]+damage[i][5]+damage[i][6]+damage[i][2])},
			}
			local school = module.db.spellsSchool[ damage[i][1] ] or 0
			if not DamageShowAll then
				DamageTab_SetLine(i+1,spellIcon,spellName,damage[i][2]/total,damage[i][2]/max(_max,1),damage[i][2],damage[i][2]/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,"spell:"..damage[i][1],tooltipData,school)
				reportData[1][#reportData[1]+1] = i..". "..(isPetAbility and ExRT.L.BossWatcherPetText..": " or "")..GetSpellLink(damage[i][1]).." - "..ExRT.mds.shortNumber(damage[i][2])
			else
				DamageTab_SetLine(i+1,spellIcon,spellName,(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/(total + totalOver),(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/max(_max,1),damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5],(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,"spell:"..damage[i][1],tooltipData,school,(damage[i][3]+damage[i][4]+damage[i][5])/max(1,damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5]))
				reportData[1][#reportData[1]+1] = i..". "..(isPetAbility and ExRT.L.BossWatcherPetText..": " or "")..GetSpellLink(damage[i][1]).." - "..ExRT.mds.shortNumber(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])			
			end
		end
		for i=#damage+2,#BWInterfaceFrame.tab.tabs[1].lines do
			BWInterfaceFrame.tab.tabs[1].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[1].scroll.SetNewHeight(BWInterfaceFrame.tab.tabs[1].scroll,(#damage+1) * 20)
	end
	local function DamageTab_UpdateLinesTargets(doEnemy)
		Damage_Last_Func = DamageTab_UpdateLinesTargets
		Damage_Last_doEnemy = doEnemy
		local damage = {}
		local total = 0
		local totalOver = 0
		for destGUID,destData in pairs(module.db.nowData.damage) do
			local isEnemy = ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[destGUID],2) == 512
			if (not destVar or destVar == destGUID) and ((doEnemy and isEnemy) or (not doEnemy and not isEnemy)) then
				for sourceGUID,sourceData in pairs(destData) do
					if not sourceVar or sourceVar == sourceGUID then
						local inDamagePos = ExRT.mds.table_find(damage,destGUID,1)
						if not inDamagePos then
							inDamagePos = #damage + 1
							damage[inDamagePos] = {destGUID,0,0,0,0,0,0}
						end
						for spellID,spellAmount in pairs(sourceData) do
							damage[inDamagePos][2] = damage[inDamagePos][2] + spellAmount.amount - spellAmount.overkill
							damage[inDamagePos][3] = damage[inDamagePos][3] + spellAmount.overkill	--overkill
							damage[inDamagePos][4] = damage[inDamagePos][4] + spellAmount.blocked	--blocked
							damage[inDamagePos][5] = damage[inDamagePos][5] + spellAmount.absorbed	--absorbed
							damage[inDamagePos][6] = damage[inDamagePos][6] + spellAmount.crit	--crit
							damage[inDamagePos][7] = damage[inDamagePos][7] + spellAmount.ms	--ms
							total = total + spellAmount.amount - spellAmount.overkill
							totalOver = totalOver + spellAmount.overkill + spellAmount.blocked + spellAmount.absorbed
						end
					end
				end
			end
		end
		local totalIsFull = 1
		total = max(total,1)
		if total == 1 and #damage == 0 then
			total = 0
			totalIsFull = 0
		end
		local _max = nil
		wipe(reportData[1])
		reportData[1][1] = (sourceVar and GetGUID(sourceVar) or ExRT.L.BossWatcherAllSources).." > "..(destVar and GetGUID(destVar) or ExRT.L.BossWatcherAllTargets)
		if not DamageShowAll then
			reportData[1][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total)
			sort(damage,function(a,b) return a[2]>b[2] end)
			_max = damage[1] and damage[1][2] or 0
			DamageTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total,total / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart))
		else
			reportData[1][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total + totalOver)
			sort(damage,function(a,b) return (a[2]+a[3]+a[4]+a[5])>(b[2]+b[3]+b[4]+b[5]) end)
			_max = damage[1] and (damage[1][2]+damage[1][3]+damage[1][4]+damage[1][5]) or 0
			DamageTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total + totalOver,(total + totalOver) / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,nil,nil,nil,totalOver / max(total + totalOver,1))		
		end
		for i=1,#damage do
			local class = nil
			if damage[i][1] and damage[i][1] ~= "" then
				class = select(2,GetPlayerInfoByGUID(damage[i][1]))
			end
			local icon = ""
			if class and CLASS_ICON_TCOORDS[class] then
				icon = {"Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES",unpack(CLASS_ICON_TCOORDS[class])}
			end
			local tooltipData = {GetGUID(damage[i][1]),
				{ExRT.L.BossWatcherDamageTooltipOverkill,ExRT.mds.shortNumber(damage[i][3])},
				{ExRT.L.BossWatcherDamageTooltipBlocked,ExRT.mds.shortNumber(damage[i][4])},
				{ExRT.L.BossWatcherDamageTooltipAbsorbed,ExRT.mds.shortNumber(damage[i][5])},
				{ExRT.L.BossWatcherDamageTooltipTotal,ExRT.mds.shortNumber(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])},
				{" "," "},
				{ExRT.L.BossWatcherDamageTooltipFromCrit,format("%s (%.1f%%)",ExRT.mds.shortNumber(damage[i][6]),damage[i][6]/max(1,damage[i][2]+damage[i][3])*100)},
				{ExRT.L.BossWatcherDamageTooltipFromMs,format("%s (%.1f%%)",ExRT.mds.shortNumber(damage[i][7]),damage[i][7]/max(1,damage[i][2]+damage[i][3])*100)},
			}
			if not DamageShowAll then
				DamageTab_SetLine(i+1,icon,GetGUID(damage[i][1])..GUIDtoText(" [%s]",damage[i][1]),damage[i][2]/total,damage[i][2]/max(_max,1),damage[i][2],damage[i][2]/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,nil,nil,nil,tooltipData)
				reportData[1][#reportData[1]+1] = i..". "..GetGUID(damage[i][1]).." - "..ExRT.mds.shortNumber(damage[i][2])
			else
				DamageTab_SetLine(i+1,icon,GetGUID(damage[i][1])..GUIDtoText(" [%s]",damage[i][1]),(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/(total + totalOver),(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/max(_max,1),damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5],(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,nil,nil,nil,tooltipData,nil,(damage[i][3]+damage[i][4]+damage[i][5])/max(1,damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5]))
				reportData[1][#reportData[1]+1] = i..". "..GetGUID(damage[i][1]).." - "..ExRT.mds.shortNumber(damage[i][2]+damage[i][3]+damage[i][4]+damage[i][5])			
			end
		end
		for i=#damage+2,#BWInterfaceFrame.tab.tabs[1].lines do
			BWInterfaceFrame.tab.tabs[1].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[1].scroll.SetNewHeight(BWInterfaceFrame.tab.tabs[1].scroll,(#damage+1) * 20)
	end
	
	local function DamageTab_DPS_SelectDropDownSource(self,arg,arg2,doEnemy,doSpells)
		sourceVar = arg
		if not doSpells then
			if not destVar then
				if sourceVar then
					DamageTab_UpdateLinesTargets(doEnemy)
				else
					DamageTab_UpdateLinesPlayers(doEnemy)
				end
			else
				if sourceVar then
					DamageTab_UpdateLinesSpells(doEnemy)
				else
					DamageTab_UpdateLinesPlayers(doEnemy)
				end
			end
		else
			DamageTab_UpdateLinesSpells(doEnemy)
		end
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].sourceDropDown, arg2)
		ExRT.lib.ScrollDropDown.Close()
	end
	local function DamageTab_DPS_SelectDropDownDest(self,arg,arg2,doEnemy,doSpells)
		destVar = arg
		if not doSpells then
			if not sourceVar then
				DamageTab_UpdateLinesPlayers(doEnemy)
			else
				if not destVar then
					DamageTab_UpdateLinesTargets(doEnemy)
				else
					DamageTab_UpdateLinesSpells(doEnemy)
				end
			end
		else
			DamageTab_UpdateLinesSpells(doEnemy)
		end
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].targetDropDown, arg2)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function DamageTab_HideArrow()
		BWInterfaceFrame.timeLineFrame.timeLine.arrow:Hide()
	end
	local function DamageTab_ShowArrow(self,pos)
		if pos then
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOMLEFT",BWInterfaceFrame.timeLineFrame.width*pos,0)
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Show()
		end
	end

	local function DamageTab_DPS(doEnemy,doSpells)
		local reaction = 512
		if not doEnemy then
			reaction = 256
		end
		
		if not module.db.nowData.damage then	--First load fix
			return
		end
	
		local sourceTable = {}
		local destTable = {}
		for destGUID,destData in pairs(module.db.nowData.damage) do
			if ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[destGUID],2) == reaction then
				destTable[#destTable + 1] = {destGUID,module.db.nowData.damage_seen[destGUID] or 0}
				for sourceGUID,sourceData in pairs(destData) do
					local owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
					if owner then
						sourceGUID = owner
					end
					if not ExRT.mds.table_find(sourceTable,sourceGUID,1) then
						sourceTable[#sourceTable + 1] = {sourceGUID,GetGUID(sourceGUID)}
					end
				end
			end
		end
		sort(sourceTable,function(a,b) return a[2]<b[2] end)
		sort(destTable,function(a,b) return a[2]<b[2] end)
		wipe(BWInterfaceFrame.tab.tabs[1].sourceDropDown.List)
		wipe(BWInterfaceFrame.tab.tabs[1].targetDropDown.List)
		BWInterfaceFrame.tab.tabs[1].sourceDropDown.List[1] = {text = ExRT.L.BossWatcherAll,func = DamageTab_DPS_SelectDropDownSource,arg2 = ExRT.L.BossWatcherAll,arg3=doEnemy,arg4=doSpells,}
		BWInterfaceFrame.tab.tabs[1].targetDropDown.List[1] = {text = ExRT.L.BossWatcherAll,func = DamageTab_DPS_SelectDropDownDest,arg2 = ExRT.L.BossWatcherAll,arg3=doEnemy,arg4=doSpells,}
		for i=1,#sourceTable do
			local isPlayer = ExRT.mds.GetUnitTypeByGUID(sourceTable[i][1]) == 0
			local classColor = ""
			if isPlayer then
				classColor = "|c"..ExRT.mds.classColorByGUID(sourceTable[i][1])
			end
			BWInterfaceFrame.tab.tabs[1].sourceDropDown.List[i+1] = {
				text = classColor..sourceTable[i][2]..GUIDtoText(" [%s]",sourceTable[i][1]),
				arg1 = sourceTable[i][1],
				arg2 = classColor..sourceTable[i][2],
				func = DamageTab_DPS_SelectDropDownSource,
				arg3 = doEnemy,
				arg4 = doSpells,
			}
		end
		for i=1,#destTable do
			local isPlayer = ExRT.mds.GetUnitTypeByGUID(destTable[i][1]) == 0
			local classColor = ""
			if isPlayer then
				classColor = "|c"..ExRT.mds.classColorByGUID(destTable[i][1])
			end
			BWInterfaceFrame.tab.tabs[1].targetDropDown.List[i+1] = {
				text = classColor..GetGUID(destTable[i][1]) .. date(" %M:%S", timestampToFightTime( module.db.nowData.damage_seen[destTable[i][1]] ))..GUIDtoText(" [%s]",destTable[i][1]),
				arg1 = destTable[i][1],
				arg2 = classColor..GetGUID(destTable[i][1]) .. date(" %M:%S", timestampToFightTime( module.db.nowData.damage_seen[destTable[i][1]] )),
				func = DamageTab_DPS_SelectDropDownDest,
				arg3 = doEnemy,
				arg4 = doSpells,
				hoverFunc = DamageTab_ShowArrow,
				leaveFunc = DamageTab_HideArrow,
				hoverArg = timestampToFightTime( module.db.nowData.damage_seen[destTable[i][1]] ) / ( module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart ),
			}
		end
		sourceVar = nil
		destVar = nil
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].sourceDropDown, ExRT.L.BossWatcherAll)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].targetDropDown, ExRT.L.BossWatcherAll)
		if doSpells then
			DamageTab_UpdateLinesSpells(doEnemy)		
		else
			DamageTab_UpdateLinesPlayers(doEnemy)
		end
	end
	
	local function DamageTab_FDPS(self,arg)
		DamageTab_DPS(true,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function DamageTab_EDPS(self,arg)
		DamageTab_DPS(false,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function DamageTab_EDTPS(self,arg)
		DamageTab_DPS(true,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].typeDropDown, arg)
		DamageTab_UpdateLinesTargets(true)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function DamageTab_EDTPSbyName(self,arg)
		DamageTab_DPS(false,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].typeDropDown, arg)
		DamageTab_UpdateLinesTargets()
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function DamageTab_FSPS(self,arg)
		DamageTab_DPS(true,true)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function DamageTab_ESPS(self,arg)
		DamageTab_DPS(false,true)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	tab.typeDropDown = ExRT.lib.CreateScrollDropDown(tabName.."TypeDropDown",tab,"TOPLEFT",45,-75,150,200,6,ExRT.L.BossWatcherDamageDamageDone)
	tab.typeText = ExRT.lib.CreateText(tab,100,20,nil,0,0,"RIGHT","TOP",nil,12,ExRT.L.BossWatcherType..":",nil,1,1,1,1)
	ExRT.lib.SetPoint(tab.typeText,"TOPRIGHT",tab.typeDropDown,"TOPLEFT",12,-8)
	tab.typeDropDown.List = {
		{text = ExRT.L.BossWatcherDamageDamageDone,func = DamageTab_FDPS,arg1=ExRT.L.BossWatcherDamageDamageDone},
		{text = ExRT.L.BossWatcherDamageDamageTaken,func = DamageTab_EDPS,arg1=ExRT.L.BossWatcherDamageDamageTaken},
		{text = ExRT.L.BossWatcherDamageDamageTakenByEnemy,func = DamageTab_EDTPS,arg1=ExRT.L.BossWatcherDamageDamageTakenByEnemy},
		{text = ExRT.L.BossWatcherDamageDamageTakenByPlayers,func = DamageTab_EDTPSbyName,arg1=ExRT.L.BossWatcherDamageDamageTakenByPlayers},
		{text = ExRT.L.BossWatcherDamageDamageDoneBySpell,func = DamageTab_FSPS,arg1=ExRT.L.BossWatcherDamageDamageDoneBySpell},
		{text = ExRT.L.BossWatcherDamageDamageTakenBySpell,func = DamageTab_ESPS,arg1=ExRT.L.BossWatcherDamageDamageTakenBySpell},
	}
	
	tab.sourceDropDown = ExRT.lib.CreateScrollDropDown(tabName.."SourceDropDown",tab,"TOPLEFT",310,-75,180,250,20,ExRT.L.BossWatcherAll)
	tab.sourceText = ExRT.lib.CreateText(tab,100,20,nil,0,0,"RIGHT","TOP",nil,12,ExRT.L.BossWatcherSource..":",nil,1,1,1,1)
	ExRT.lib.SetPoint(tab.sourceText,"TOPRIGHT",tab.sourceDropDown,"TOPLEFT",12,-8)

	tab.targetDropDown = ExRT.lib.CreateScrollDropDown(tabName.."TargetDropDown",tab,"TOPLEFT",580,-75,180,250,20,ExRT.L.BossWatcherAll)
	tab.targetText = ExRT.lib.CreateText(tab,100,20,nil,0,0,"RIGHT","TOP",nil,12,ExRT.L.BossWatcherTarget..":",nil,1,1,1,1)
	ExRT.lib.SetPoint(tab.targetText,"TOPRIGHT",tab.targetDropDown,"TOPLEFT",12,-8)
	
	tab.showOverallChk = ExRT.lib.CreateCheckBox(nil,tab,"TOPLEFT",795,-73,"",nil,ExRT.L.BossWatcherDamageShowOver)
	tab.showOverallChk:SetScript("OnClick",function (self)
		if self:GetChecked() then
			DamageShowAll = true
		else
			DamageShowAll = false
		end
		Damage_Last_Func(Damage_Last_doEnemy)
	end)
	
	tab.scroll = ExRT.lib.CreateScrollFrame(tabName.."ScrollFrame",tab,810,467,"TOP",0,-110,600)
	tab.lines = {}
	local function DamageTab_Line_OnClick(self)
		local GUID = self.sourceGUID
		local doEnemy = self.doEnemy
		if self:GetParent().sourceGUID then
			GUID = self:GetParent().sourceGUID
			doEnemy = self:GetParent().doEnemy
		end
		if GUID then
			sourceVar = GUID
			UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[1].sourceDropDown, GetGUID(GUID))
			DamageTab_UpdateLinesSpells(doEnemy)
		end
	end
	local function DamageTab_LineOnEnter(self)
		if self.tooltip then
			GameTooltip:SetOwner(self,"ANCHOR_LEFT")
			GameTooltip:SetText(self.tooltip[1])
			for i=2,#self.tooltip do
				if type(self.tooltip[i]) == "table" then
					GameTooltip:AddDoubleLine(self.tooltip[i][1],self.tooltip[i][2],1,1,1,1,1,1,1,1)
				else
					GameTooltip:AddLine(self.tooltip[i])
				end
			end
			GameTooltip:Show()
		end
	end
	local function DamageTab_Line_OnEnter(self)
		local parent = self:GetParent()
		if parent.spellLink then
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:SetHyperlink(parent.spellLink)
			GameTooltip:Show()
		elseif parent.name:IsTruncated() then
			GameTooltip:SetOwner(self,"ANCHOR_LEFT")
			GameTooltip:SetText(parent.name:GetText())
			GameTooltip:Show()	
		elseif parent.tooltip then
			DamageTab_LineOnEnter(parent)
		end
	end
	function DamageTab_SetLine(i,icon,name,overall_num,overall,total,dps,class,sourceGUID,doEnemy,spellLink,tooltip,school,overall_black)
		if not BWInterfaceFrame.tab.tabs[1].lines[i] then
			local line = CreateFrame("Button",nil,BWInterfaceFrame.tab.tabs[1].scroll.C)
			BWInterfaceFrame.tab.tabs[1].lines[i] = line
			line:SetSize(790,20)
			line:SetPoint("TOPLEFT",0,-(i-1)*20)
			
			line.icon = ExRT.lib.CreateIcon(nil,line,18,"TOPLEFT",5,-1)
			line.name = ExRT.lib.CreateText(line,200,20,nil,25,0,"LEFT","MIDDLE",nil,12,"name",nil,1,1,1,1)
			line.name_tooltip = CreateFrame('Button',nil,line)
			line.name_tooltip:SetAllPoints(line.name)
			line.overall_num = ExRT.lib.CreateText(line,70,20,nil,225,0,"RIGHT","MIDDLE",nil,12,"45.76%",nil,1,1,1,1)
			line.overall = line:CreateTexture(nil, "BACKGROUND")
			--line.overall:SetTexture(0.7, 0.1, 0.1, 1)
			line.overall:SetTexture("Interface\\AddOns\\ExRT\\media\\bar24.tga")
			line.overall:SetSize(300,16)
			line.overall:SetPoint("TOPLEFT",300,-2)
			line.overall_black = line:CreateTexture(nil, "BACKGROUND")
			line.overall_black:SetTexture("Interface\\AddOns\\ExRT\\media\\bar24b.tga")
			line.overall_black:SetSize(300,16)
			line.overall_black:SetPoint("LEFT",line.overall,"RIGHT",0,0)
			
			line.total = ExRT.lib.CreateText(line,95,20,nil,605,0,"LEFT","MIDDLE",nil,12,"125.46M",nil,1,1,1,1)
			line.dps = ExRT.lib.CreateText(line,100,20,nil,700,0,"LEFT","MIDDLE",nil,12,"34576.43",nil,1,1,1,1)
			
			line.back = line:CreateTexture(nil, "BACKGROUND")
			line.back:SetAllPoints()
			if i%2==0 then
				line.back:SetTexture(0.3, 0.3, 0.3, 0.1)
			end
			line:SetScript("OnClick",DamageTab_Line_OnClick)
			line.name_tooltip:SetScript("OnEnter",DamageTab_Line_OnEnter)
			line.name_tooltip:SetScript("OnLeave",GameTooltip_Hide)
			line.name_tooltip:SetScript("OnClick",DamageTab_Line_OnClick)
			line:SetScript("OnEnter",DamageTab_LineOnEnter)
			line:SetScript("OnLeave",GameTooltip_Hide)
		end
		local line = BWInterfaceFrame.tab.tabs[1].lines[i]
		if type(icon) == "table" then
			line.icon.texture:SetTexture(icon[1] or "Interface\\Icons\\INV_MISC_QUESTIONMARK")
			line.icon.texture:SetTexCoord(unpack(icon,2,5))
		else
			line.icon.texture:SetTexture(icon or "Interface\\Icons\\INV_MISC_QUESTIONMARK")
			line.icon.texture:SetTexCoord(0,1,0,1)
		end
		line.name:SetText(name or "")
		line.overall_num:SetFormattedText("%.2f%%",overall_num and overall_num * 100 or 0)
		if overall_black and overall_black > 0 then
			local width = 300*(overall or 1)
			local normal_width = width * (1 - overall_black)
			line.overall:SetWidth(max(normal_width,1))
			line.overall_black:SetWidth(max(width-normal_width,1))
			line.overall_black:Show()
		else
			line.overall_black:Hide()
			line.overall:SetWidth(max(300*(overall or 1),1))
		end
		line.total:SetText(total and ExRT.mds.shortNumber(total) or "")
		line.dps:SetFormattedText("%.2f",dps or 0)
		line.overall:SetGradientAlpha("HORIZONTAL", 0,0,0,0,0,0,0,0)
		line.overall_black:SetGradientAlpha("HORIZONTAL", 0,0,0,0,0,0,0,0)
		if class then
			local classColorArray = RAID_CLASS_COLORS[class]
			if classColorArray then
				line.overall:SetVertexColor(classColorArray.r,classColorArray.g,classColorArray.b, 1)
				line.overall_black:SetVertexColor(classColorArray.r,classColorArray.g,classColorArray.b, 1)
			else
				line.overall:SetVertexColor(0.8,0.8,0.8, 1)
				line.overall_black:SetVertexColor(0.8,0.8,0.8, 1)
			end
		else
			line.overall:SetVertexColor(0.8,0.8,0.8, 1)
			line.overall_black:SetVertexColor(0.8,0.8,0.8, 1)
		end
		if school then
			SetSchoolColorsToLine(line.overall,school)
			SetSchoolColorsToLine(line.overall_black,school)
		end
		line.sourceGUID = sourceGUID
		line.doEnemy = doEnemy
		line.spellLink = spellLink
		line.tooltip = tooltip
		line:Show()
	end
	
	tab:SetScript("OnShow",function (self)
		BWInterfaceFrame.timeLineFrame:ClearAllPoints()
		BWInterfaceFrame.timeLineFrame:SetPoint("TOP",self,"TOP",0,-10)
		BWInterfaceFrame.timeLineFrame:Show()
		
		BWInterfaceFrame.report:Show()
		
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			DamageTab_FDPS(nil,ExRT.L.BossWatcherDamageDamageDone)
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	tab:SetScript("OnHide",function (self)
		BWInterfaceFrame.timeLineFrame:Hide()
		BWInterfaceFrame.report:Hide()
	end)
	
	
	
	
	---- Auras Tab
	tab = BWInterfaceFrame.tab.tabs[3]
	tabName = BWInterfaceFrame_Name.."AurasTab"
	
	tab.timeLine = {}
	
	local buffsNameWidth = 150
	local buffsWorkWidth = 650
	local buffsTotalWidth = buffsNameWidth + buffsWorkWidth
	local buffsTotalLines = 29
	for i=1,11 do
		tab.timeLine[i] = CreateFrame("Frame",nil,tab)
		tab.timeLine[i]:SetPoint("TOPLEFT",buffsNameWidth+(i-1)*(buffsWorkWidth/10)-1,-42)
		tab.timeLine[i]:SetSize(2,buffsTotalLines * 18 + 14)
		
		tab.timeLine[i].texture = tab.timeLine[i]:CreateTexture(nil, "BACKGROUND")
		tab.timeLine[i].texture:SetTexture(1, 1, 1, 0.3)
		tab.timeLine[i].texture:SetAllPoints()		
		
		tab.timeLine[i].timeText = ExRT.lib.CreateText(tab.timeLine[i],200,12,"TOPLEFT",4,-2,"RIGHT","TOP",nil,11,"",nil,1,1,1)
		ExRT.lib.SetPoint(tab.timeLine[i].timeText,"TOPRIGHT",tab.timeLine[i],"TOPLEFT",-1,-1)
	end
	
	tab.redDeathLine = {}
	local function CreateRedDeathLine(i)
		if not BWInterfaceFrame.tab.tabs[3].redDeathLine[i] then
			BWInterfaceFrame.tab.tabs[3].redDeathLine[i] = BWInterfaceFrame.tab.tabs[3]:CreateTexture(nil, "BACKGROUND",0,-4)
			BWInterfaceFrame.tab.tabs[3].redDeathLine[i]:SetTexture(1, 0.3, 0.3, 1)
			BWInterfaceFrame.tab.tabs[3].redDeathLine[i]:SetSize(2,374)
			BWInterfaceFrame.tab.tabs[3].redDeathLine[i]:Hide()
		end
	end
	
	tab.linesRightClickMenu = {
		{ text = "Spell", isTitle = true, notCheckable = true, notClickable = true },
		{ text = ExRT.L.BossWatcherSendToChat, func = function() 
			if BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData then
				local chat_type = ExRT.mds.chatType(true)
				SendChatMessage(BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData[1],chat_type)
				for i=2,#BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData do
					SendChatMessage(ExRT.mds.clearTextTag(BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData[i]),chat_type)
				end
			end
		end, notCheckable = true },
		{ text = ExRT.L.minimapmenuclose, func = function() CloseDropDownMenus() end, notCheckable = true },
	}
	tab.linesRightClickMenuDropDown = CreateFrame("Frame", tabName.."LinesRightClickMenuDropDown", nil, "UIDropDownMenuTemplate")
	
	local BuffsLineUptimeTempTable = {}
	local function BuffsLinesOnUpdate(self)
		local x,y = ExRT.mds.GetCursorPos(self)
		if ExRT.mds.IsInFocus(self,x,y) then
			for j=1,buffsTotalLines do
				if BWInterfaceFrame.tab.tabs[3].lines[j] ~= self then
					BWInterfaceFrame.tab.tabs[3].lines[j].hl:Hide()
				end
			end
			self.hl:Show()
			if x <= buffsNameWidth then
				if GameTooltip:IsShown() then
					local _,_,spellID = GameTooltip:GetSpell()
					if spellID == self.spellID then
						return
					end
				end
				GameTooltip:SetOwner(self, "ANCHOR_RIGHT", -buffsWorkWidth, 0)
				GameTooltip:SetHyperlink(self.spellLink)
				
				local greenCount = #self.greenTooltips
				for i=1,greenCount do
					BuffsLineUptimeTempTable[(i-1)*2+1] = self.greenTooltips[i][1]
					BuffsLineUptimeTempTable[(i-1)*2+2] = self.greenTooltips[i][2]
				end
				for i=1,greenCount do
					local iPos = (i-1)*2+1
					if BuffsLineUptimeTempTable[iPos] then
						for j=1,greenCount do
							local jPos = (j-1)*2+1
							if i~=j and BuffsLineUptimeTempTable[jPos] then
								if BuffsLineUptimeTempTable[jPos] <= BuffsLineUptimeTempTable[iPos] and BuffsLineUptimeTempTable[jPos+1] > BuffsLineUptimeTempTable[iPos] then
									BuffsLineUptimeTempTable[iPos] = BuffsLineUptimeTempTable[jPos]
									BuffsLineUptimeTempTable[iPos+1] = max(BuffsLineUptimeTempTable[jPos+1],BuffsLineUptimeTempTable[iPos+1])
									BuffsLineUptimeTempTable[jPos] = nil
									BuffsLineUptimeTempTable[jPos+1] = nil
								end
								if BuffsLineUptimeTempTable[jPos] and BuffsLineUptimeTempTable[jPos+1] >= BuffsLineUptimeTempTable[iPos+1] and BuffsLineUptimeTempTable[jPos] < BuffsLineUptimeTempTable[iPos+1] then
									BuffsLineUptimeTempTable[iPos] = min(BuffsLineUptimeTempTable[jPos],BuffsLineUptimeTempTable[iPos])
									BuffsLineUptimeTempTable[iPos+1] = BuffsLineUptimeTempTable[jPos+1]
									BuffsLineUptimeTempTable[jPos] = nil
									BuffsLineUptimeTempTable[jPos+1] = nil
								end
							end
						end
					end
				end
				local uptime = 0
				for i=1,greenCount do
					local iPos = (i-1)*2+1
					if BuffsLineUptimeTempTable[iPos] then
						uptime = uptime + (BuffsLineUptimeTempTable[iPos+1] - BuffsLineUptimeTempTable[iPos])
					end
				end
				uptime = uptime / buffsWorkWidth
				
				GameTooltip:AddLine(ExRT.L.BossWatcherBuffsAndDebuffsTooltipUptimeText..": "..format("%.2f%% (%.1f %s)",uptime*100,uptime*(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),ExRT.L.BossWatcherBuffsAndDebuffsSecondsText))
				GameTooltip:AddLine(ExRT.L.BossWatcherBuffsAndDebuffsTooltipCountText..": "..(self.greenCount or 0))
				GameTooltip:Show()
			else
				if not self.tooltip then
					self.tooltip = {}
				end
				table.wipe(self.tooltip)
				local owner = nil
				local _min,_max = buffsNameWidth+buffsWorkWidth,buffsNameWidth
				for j = 1,#self.greenTooltips do
					local rightPos = self.greenTooltips[j][2]
					local leftPos = self.greenTooltips[j][1]
					if rightPos - leftPos < 2 then
						rightPos = leftPos + 2
					end
					if x >= leftPos and x <= rightPos then
						local sourceClass = ExRT.mds.classColorByGUID(self.greenTooltips[j][5])
						local destClass = ExRT.mds.classColorByGUID(self.greenTooltips[j][6])
						local duration = (self.greenTooltips[j][4] - self.greenTooltips[j][3])
						table.insert(self.tooltip, date("[%M:%S", self.greenTooltips[j][3] ) .. format(".%03d",(self.greenTooltips[j][3]*1000)%1000).. "] " .. "|c" .. sourceClass .. GetGUID(self.greenTooltips[j][5])..GUIDtoText(" (%s)",self.greenTooltips[j][5]).."|r "..ExRT.L.BossWatcherBuffsAndDebuffsTextOn.." |c".. destClass .. GetGUID(self.greenTooltips[j][6])..GUIDtoText(" (%s)",self.greenTooltips[j][6]).."|r")
						if self.greenTooltips[j][7] and self.greenTooltips[j][7] ~= 1 then
							self.tooltip[#self.tooltip] = self.tooltip[#self.tooltip] .. " (".. self.greenTooltips[j][7] ..")"
						end
						self.tooltip[#self.tooltip] = self.tooltip[#self.tooltip] .. format(" <%.1f%s>",duration,ExRT.L.BossWatcherBuffsAndDebuffsSecondsText)
						owner = self.greenTooltips[j][1]
						
						_min = min(_min,leftPos)
						_max = max(_max,rightPos)
					end
				end
				if #self.tooltip > 0 then
					table.sort(self.tooltip,function(a,b) return a < b end)
					ExRT.lib.TooltipShow(self,{"ANCHOR_LEFT",owner or 0,0},ExRT.L.BossWatcherBuffsAndDebuffsTooltipTitle..":",unpack(self.tooltip))
				else
					GameTooltip_Hide()
				end
			end
		end
	end
	local function BuffsLinesOnLeave(self)
		GameTooltip_Hide()
		self.hl:Hide()
	end
	local function BuffsLinesOnClick(self,button)
		local x,y = ExRT.mds.GetCursorPos(self)
		if x > 0 and x < buffsTotalWidth and y > 0 and y < 18 then
			if x <= buffsNameWidth then
				ExRT.mds.LinkSpell(nil,self.spellLink)
			elseif button == "RightButton" and GameTooltip:IsShown() then
				if BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData then
					wipe(BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData)
				else
					BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData = {}
				end
				table.insert(BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData , self.spellLink)
				for j=2, GameTooltip:NumLines() do
					table.insert(BWInterfaceFrame.tab.tabs[3].linesRightClickMenuData , _G["GameTooltipTextLeft"..j]:GetText())
				end
				BWInterfaceFrame.tab.tabs[3].linesRightClickMenu[1].text = self.spellName
				EasyMenu(BWInterfaceFrame.tab.tabs[3].linesRightClickMenu, BWInterfaceFrame.tab.tabs[3].linesRightClickMenuDropDown, "cursor", 10 , -15, "MENU")
			end
		end
	end
			
	tab.lines = {}
	for i=1,buffsTotalLines do
		tab.lines[i] = CreateFrame("Button",nil,tab)
		tab.lines[i]:SetSize(buffsTotalWidth,18)
		tab.lines[i]:SetPoint("TOPLEFT", 0, -18*(i-1)-54)
		
		tab.lines[i].spellIcon = tab.lines[i]:CreateTexture(nil, "BACKGROUND")
		tab.lines[i].spellIcon:SetSize(16,16)
		tab.lines[i].spellIcon:SetPoint("TOPLEFT", 5, -1)
		
		tab.lines[i].spellText = ExRT.lib.CreateText(tab.lines[i],(buffsNameWidth-23),18,"TOPLEFT",23,0,"LEFT","MIDDLE",nil,11,"",nil,1,1,1)
		
		tab.lines[i].green = {}
		tab.lines[i].greenFrame = {}
		tab.lines[i].greenCount = 0
		
		tab.lines[i].greenTooltips = {}
		
		ExRT.lib.CreateHoverHighlight(tab.lines[i])
		tab.lines[i].hl:SetAlpha(.5)
		
		tab.lines[i]:SetScript("OnUpdate", BuffsLinesOnUpdate) 
		tab.lines[i]:SetScript("OnLeave", BuffsLinesOnLeave)
		tab.lines[i]:RegisterForClicks("RightButtonUp","LeftButtonUp")
		tab.lines[i]:SetScript("OnClick", BuffsLinesOnClick)
	end
	
	tab.scrollBar = ExRT.lib.CreateScrollBar2(tabName.."ScrollBar",tab,16,buffsTotalLines*18,-4,-54,1,2,"TOPRIGHT")
	
	local function CreateBuffGreen(i,j)
		BWInterfaceFrame.tab.tabs[3].lines[i].green[j] = BWInterfaceFrame.tab.tabs[3].lines[i]:CreateTexture(nil, "BACKGROUND",nil,5)
		BWInterfaceFrame.tab.tabs[3].lines[i].green[j]:SetTexture(0.1, 0.7, 0.1, 0.7)
		BWInterfaceFrame.tab.tabs[3].lines[i].greenFrame[j] = CreateFrame("Frame",nil,BWInterfaceFrame.tab.tabs[3].lines[i])
	end
	
	local function CreateFilterText()
		local result = ExRT.L.BossWatcherBuffsAndDebuffsFilterSource..": "
		if not BWInterfaceFrame.tab.tabs[3].filterS then
			result = result .. ExRT.L.BossWatcherBuffsAndDebuffsFilterAll
		elseif BWInterfaceFrame.tab.tabs[3].filterS == 1 then
			result = result .. ExRT.L.BossWatcherBuffsAndDebuffsFilterFriendly
		elseif BWInterfaceFrame.tab.tabs[3].filterS == 2 then
			result = result .. ExRT.L.BossWatcherBuffsAndDebuffsFilterHostile
		else 
			result = result .. (GetGUID(BWInterfaceFrame.tab.tabs[3].filterS))
		end
		result = result .. "; "..ExRT.L.BossWatcherBuffsAndDebuffsFilterTarget..": "
		if not BWInterfaceFrame.tab.tabs[3].filterD then
			result = result .. ExRT.L.BossWatcherBuffsAndDebuffsFilterAll
		elseif BWInterfaceFrame.tab.tabs[3].filterD == 1 then
			result = result .. ExRT.L.BossWatcherBuffsAndDebuffsFilterFriendly
		elseif BWInterfaceFrame.tab.tabs[3].filterD == 2 then
			result = result .. ExRT.L.BossWatcherBuffsAndDebuffsFilterHostile
		else 
			result = result .. (GetGUID(BWInterfaceFrame.tab.tabs[3].filterD))
		end			
		result = result .. ";"
		
		local isSpecial = nil
		for i=1,#module.db.buffsFilters do
			if module.db.buffsFilterStatus[i] then
				isSpecial = true
				break
			end
		end
		if isSpecial then
			result = result .. " "..ExRT.L.BossWatcherBuffsAndDebuffsFilterSpecial..":"
			for i=1,#module.db.buffsFilters do
				if module.db.buffsFilterStatus[i] then
					result = result .. " " .. strlower(module.db.buffsFilters[i][-1]) .. ";"
				end
			end
		end
		BWInterfaceFrame.tab.tabs[3].filterText:SetText(result)
	end
	
	local function UpdateBuffPageDB()
		local fightDuration = (module.db.data[module.db.nowNum].encounterEnd -module.db.data[module.db.nowNum].encounterStart)
		for i=1,10 do
			BWInterfaceFrame.tab.tabs[3].timeLine[i+1].timeText:SetText( date("%M:%S", fightDuration*(i/10) ) )
		end
		
		local buffTable = {}
		for i,sourceData in ipairs(module.db.nowData.auras) do 
			local spellID = sourceData[6]
			local spellName,_,spellTexture = GetSpellInfo(spellID)
			if (not BWInterfaceFrame.tab.tabs[3].filterS or (BWInterfaceFrame.tab.tabs[3].filterS == 1 and sourceData[4]) or (BWInterfaceFrame.tab.tabs[3].filterS == 2 and not sourceData[4]) or BWInterfaceFrame.tab.tabs[3].filterS == sourceData[2]) and 
				(not BWInterfaceFrame.tab.tabs[3].filterD or (BWInterfaceFrame.tab.tabs[3].filterD == 1 and sourceData[5]) or (BWInterfaceFrame.tab.tabs[3].filterD == 2 and not sourceData[5]) or BWInterfaceFrame.tab.tabs[3].filterD == sourceData[3]) and 
				(not module.db.buffsFilterStatus[1] or sourceData[7] == 'BUFF') and
				(not module.db.buffsFilterStatus[2] or sourceData[7] == 'DEBUFF') and
				(not module.db.buffsFilterStatus[3] or module.db.buffsFilters[3][spellID]) and
				(not module.db.buffsFilterStatus[4] or module.db.buffsFilters[4][strlower(spellName)]) and
				(not module.db.buffsFilterStatus[5] or module.db.buffsFilters[5][spellID]) and 
				(not module.db.buffsFilterStatus[6] or module.db.buffsFilters[6][spellID]) and
				(not module.db.buffsFilterStatus[7] or module.db.buffsFilters[7][spellID]) and
				(not module.db.buffsFilterStatus[8] or module.db.buffsFilters[8][spellID]) and
				(not module.db.buffsFilterStatus[9] or module.db.buffsFilters[9][spellID]) and
				(not module.db.buffsFilterStatus[10] or module.db.buffsFilters[10][spellID]) and
				(not module.db.buffsFilterStatus[11] or module.db.buffsFilters[11][spellID]) then
				
				local time_ = timestampToFightTime( sourceData[1] )
				local time_postion = time_ / fightDuration
				local type_ = sourceData[8]
				
				local buffTablePos
				for j=1,#buffTable do
					if buffTable[j][1] == spellID then
						buffTablePos = j
						break
					end
				end
				if not buffTablePos then
					buffTablePos = #buffTable + 1
					buffTable[buffTablePos] = {spellID,spellName,spellTexture,{},{}}
				end
				
				local sourceGUID = sourceData[2] or 0
				local destGUID = sourceData[3] or 0
				local sourceDest = sourceGUID .. destGUID
				local buffTableBuffPos
				for j=1,#buffTable[buffTablePos][4] do
					if buffTable[buffTablePos][4][j][1] == sourceDest then
						buffTableBuffPos = j
						break
					end
				end
				if not buffTableBuffPos then
					buffTableBuffPos = #buffTable[buffTablePos][4] + 1
					buffTable[buffTablePos][4][buffTableBuffPos] = {sourceDest,sourceGUID,destGUID,{}}
				end
				
				local eventPos = #buffTable[buffTablePos][4][buffTableBuffPos][4] + 1
				
				if type_ == 3 or type_ == 4 then
					buffTable[buffTablePos][4][buffTableBuffPos][4][eventPos] = {0,time_,time_postion,sourceData[9] or 1}
					type_ = 1
					eventPos = eventPos + 1
				end
				buffTable[buffTablePos][4][buffTableBuffPos][4][eventPos] = {type_ % 2,time_,time_postion,sourceData[9] or 1}
			end
		end
		
		table.sort(buffTable,function(a,b) return a[2] < b[2] end)
		
		for i=1,#buffTable do 
			for j=1,#buffTable[i][4] do
				local maxEvents = #buffTable[i][4][j][4]
				if maxEvents > 0 and buffTable[i][4][j][4][1][1] == 0 then
					local newLine = #buffTable[i][5] + 1
					buffTable[i][5][newLine] = {
						buffsNameWidth,
						buffsNameWidth+buffsWorkWidth*buffTable[i][4][j][4][1][3],
						0,
						buffTable[i][4][j][4][1][2],
						buffTable[i][4][j][2],
						buffTable[i][4][j][3],
						1,
					}
				end
				for k=1,maxEvents do
					if buffTable[i][4][j][4][k][1] == 1 then
						local endOfTime = nil
						for n=(k+1),maxEvents do
							if buffTable[i][4][j][4][n][1] == 0 and not endOfTime then
								endOfTime = n
								--break
							end
						end
						local newLine = #buffTable[i][5] + 1
						buffTable[i][5][newLine] = {
							buffsNameWidth+buffsWorkWidth*buffTable[i][4][j][4][k][3],
							buffsNameWidth+buffsWorkWidth*(endOfTime and buffTable[i][4][j][4][endOfTime][3] or 1),
							buffTable[i][4][j][4][k][2],
							endOfTime and buffTable[i][4][j][4][endOfTime][2] or fightDuration,
							buffTable[i][4][j][2],
							buffTable[i][4][j][3],
							buffTable[i][4][j][4][k][4],
						}
						--startPos,endPos,startTime,endTime,sourceGUID,destGUID,stacks
					end
				end
			end
		end
		
		--> Death Line
		for i=1,#BWInterfaceFrame.tab.tabs[3].redDeathLine do
			BWInterfaceFrame.tab.tabs[3].redDeathLine[i]:Hide()
		end
		if type(BWInterfaceFrame.tab.tabs[3].filterD) == "string" and BWInterfaceFrame.tab.tabs[3].filterD ~= "" then
			local j = 0
			for i=1,#module.db.nowData.dies do
				if module.db.nowData.dies[i][1] == BWInterfaceFrame.tab.tabs[3].filterD then
					j = j + 1
					CreateRedDeathLine(j)
					local time_ = timestampToFightTime( module.db.nowData.dies[i][3] )
					local pos = buffsNameWidth + time_/fightDuration*buffsWorkWidth - 1
					BWInterfaceFrame.tab.tabs[3].redDeathLine[j]:SetPoint("TOPLEFT",pos,-42)
					BWInterfaceFrame.tab.tabs[3].redDeathLine[j]:Show()
				end
			end
		end
		
		BWInterfaceFrame.tab.tabs[3].scrollBar:SetValue(1)
		BWInterfaceFrame.tab.tabs[3].scrollBar:SetMinMaxValues(1,max(#buffTable-buffsTotalLines,1))		
		BWInterfaceFrame.tab.tabs[3].db = buffTable
		
		ExRT.mds.ScheduleTimer(collectgarbage, 1, "collect")
	end
	
	local function UpdateBuffsPage()
		CreateFilterText()
		if not BWInterfaceFrame.tab.tabs[3].db then
			return
		end
		
		local minVal = ExRT.mds.Round(BWInterfaceFrame.tab.tabs[3].scrollBar:GetValue())
		local buffTable2 = BWInterfaceFrame.tab.tabs[3].db
		
		local linesCount = 0
		for i=1,buffsTotalLines do
			for j=1,BWInterfaceFrame.tab.tabs[3].lines[i].greenCount do
				BWInterfaceFrame.tab.tabs[3].lines[i].green[j]:Hide()
			end
			BWInterfaceFrame.tab.tabs[3].lines[i].greenCount = 0
			table.wipe(BWInterfaceFrame.tab.tabs[3].lines[i].greenTooltips)
		end
		for i=minVal,#buffTable2 do
			linesCount = linesCount + 1
			local Line = BWInterfaceFrame.tab.tabs[3].lines[linesCount]
			Line.spellIcon:SetTexture(buffTable2[i][3])
			Line.spellText:SetText(buffTable2[i][2] or "???")
			Line.spellLink = GetSpellLink(buffTable2[i][1])
			Line.spellName = buffTable2[i][2] or "Spell"
			Line.spellID = buffTable2[i][1]
			
			for j=1,#buffTable2[i][5] do
				Line.greenCount = Line.greenCount + 1
				local n = Line.greenCount

				if not Line.green[n] then
					CreateBuffGreen(linesCount,n)
				end
				
				Line.green[n]:SetPoint("TOPLEFT",buffTable2[i][5][j][1],0)
				Line.green[n]:SetSize(max(buffTable2[i][5][j][2]-buffTable2[i][5][j][1],0.1),18)
				Line.green[n]:Show()
				
				Line.greenTooltips[#Line.greenTooltips+1] = buffTable2[i][5][j]
			end

			Line:Show()
			if linesCount >= buffsTotalLines then
				break
			end
		end
		for i=(linesCount+1),buffsTotalLines do
			BWInterfaceFrame.tab.tabs[3].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[3].scrollBar.reButtonsState(BWInterfaceFrame.tab.tabs[3].scrollBar)
	end

	tab.scrollBar:SetScript("OnValueChanged",UpdateBuffsPage)
	tab:SetScript("OnMouseWheel",function (self,delta)
		if delta > 0 then
			BWInterfaceFrame.tab.tabs[3].scrollBar.buttonUP:Click("LeftButton")
		else
			BWInterfaceFrame.tab.tabs[3].scrollBar.buttonDown:Click("LeftButton")
		end
	end)

	tab.filterFrame = ExRT.lib.CreatePopupFrame(tabName.."FilterFrame",570,430,ExRT.L.BossWatcherBuffsAndDebuffsFilterFilter)
	
	local function UpdateTargetsList(self,isSourceFrame,friendly,hostile)
		table.wipe(self.L)
		table.wipe(self.LGUID)
		if isSourceFrame then
			isSourceFrame = 4
		else
			isSourceFrame = 5
		end
		local list = {}
		for i=1,#module.db.nowData.auras do
			local sourceData = module.db.nowData.auras[i]
			local sourceGUID
			if isSourceFrame == 4 then
				sourceGUID = (friendly and sourceData[isSourceFrame] and sourceData[2]) or (hostile and not sourceData[isSourceFrame] and sourceData[2])
			elseif isSourceFrame == 5 then
				sourceGUID = (friendly and sourceData[isSourceFrame] and sourceData[3]) or (hostile and not sourceData[isSourceFrame] and sourceData[3])
			end
			if sourceGUID then
				local inList = nil
				for j=1,#list do
					if list[j][1] == sourceGUID then
						inList = true
						break
					end
				end
				if not inList then
					list[#list+1] = {sourceGUID,GetGUID(sourceGUID),"|c"..ExRT.mds.classColorByGUID(sourceGUID)}
				end
			end
		end

		table.sort(list,function(a,b) 
			if a[2] == b[2] then
				return a[1] < b[1]
			else
				return a[2] < b[2] 
			end
		end)
		
		for i=1,#list do
			self.L[i] = list[i][3] .. list[i][2] 
			self.LGUID[i] = list[i][1]
		end
		self.Update()
	end
	
	tab.filterFrame:SetScript("OnShow",function()
		UpdateTargetsList(BWInterfaceFrame.tab.tabs[3].filterFrame.sourceScroll,true,BWInterfaceFrame.tab.tabs[3].filterFrame.sourceFriendly:GetChecked(),BWInterfaceFrame.tab.tabs[3].filterFrame.sourceHostile:GetChecked())
		UpdateTargetsList(BWInterfaceFrame.tab.tabs[3].filterFrame.targetScroll,nil,BWInterfaceFrame.tab.tabs[3].filterFrame.targetFriendly:GetChecked(),BWInterfaceFrame.tab.tabs[3].filterFrame.targetHostile:GetChecked())
	end)
	
	tab.filterFrame.sourceScroll = ExRT.lib.CreateScrollList(tabName.."FilterFrameSourceScroll",tab.filterFrame,nil,10,-62,190,19)
	tab.filterFrame.sourceScroll.LGUID = {}
	tab.filterFrame.sourceScroll.dontDisable = true
	
	tab.filterFrame.sourceClear = ExRT.lib.CreateButton(nil,tab.filterFrame,190,16,nil,10,-30,ExRT.L.BossWatcherBuffsAndDebuffsFilterClear)
	tab.filterFrame.sourceClear:SetScript("OnClick",function ()
		BWInterfaceFrame.tab.tabs[3].filterS = nil
		BWInterfaceFrame.tab.tabs[3].filterFrame.sourceFriendly:SetChecked(true)
		BWInterfaceFrame.tab.tabs[3].filterFrame.sourceFriendly:SetChecked(true)
		UpdateTargetsList(BWInterfaceFrame.tab.tabs[3].filterFrame.sourceScroll,true,BWInterfaceFrame.tab.tabs[3].filterFrame.sourceFriendly:GetChecked(),BWInterfaceFrame.tab.tabs[3].filterFrame.sourceHostile:GetChecked())
		BWInterfaceFrame.tab.tabs[3].filterFrame.sourceText:SetText(ExRT.L.BossWatcherBuffsAndDebuffsFilterNone)
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end)
	tab.filterFrame.sourceText = ExRT.lib.CreateText(tab.filterFrame,180,16,nil,15,-46,"LEFT","MIDDLE",nil,11,ExRT.L.BossWatcherBuffsAndDebuffsFilterNone,nil,1,1,1)
	
	tab.filterFrame.sourceFriendly = ExRT.lib.CreateCheckBox(tabName.."FilterFrameSourceCheckFriendly",tab.filterFrame,nil,10,-338,ExRT.L.BossWatcherBuffsAndDebuffsFilterFriendly,true)
	tab.filterFrame.sourceHostile = ExRT.lib.CreateCheckBox(tabName.."FilterFrameSourceCheckHostile",tab.filterFrame,nil,10,-363,ExRT.L.BossWatcherBuffsAndDebuffsFilterHostile,true)
	tab.filterFrame.sourceFriendly:SetScript("OnClick",function ()
		UpdateTargetsList(BWInterfaceFrame.tab.tabs[3].filterFrame.sourceScroll,true,BWInterfaceFrame.tab.tabs[3].filterFrame.sourceFriendly:GetChecked(),BWInterfaceFrame.tab.tabs[3].filterFrame.sourceHostile:GetChecked())
		if BWInterfaceFrame.tab.tabs[3].filterFrame.sourceFriendly:GetChecked() then
			BWInterfaceFrame.tab.tabs[3].filterS = 1
		end
		if BWInterfaceFrame.tab.tabs[3].filterFrame.sourceHostile:GetChecked() then
			if BWInterfaceFrame.tab.tabs[3].filterS == 1 then
				BWInterfaceFrame.tab.tabs[3].filterS = nil
			else
				BWInterfaceFrame.tab.tabs[3].filterS = 2
			end
		end
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end)
	tab.filterFrame.sourceHostile:SetScript("OnClick",tab.filterFrame.sourceFriendly:GetScript("OnClick"))
	ExRT.lib.SetPoint(tab.filterFrame.sourceFriendly,"TOPLEFT",tab.filterFrame.sourceScroll,"BOTTOMLEFT",0,4)
	ExRT.lib.SetPoint(tab.filterFrame.sourceHostile,"TOPLEFT",tab.filterFrame.sourceFriendly,"BOTTOMLEFT",0,8)
	
	function tab.filterFrame.sourceScroll:SetListValue(index)
		BWInterfaceFrame.tab.tabs[3].filterS = BWInterfaceFrame.tab.tabs[3].filterFrame.sourceScroll.LGUID[index]
		BWInterfaceFrame.tab.tabs[3].filterFrame.sourceText:SetText(BWInterfaceFrame.tab.tabs[3].filterFrame.sourceScroll.L[index])
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end
	
	function tab.filterFrame.sourceScroll:HoverListValue(isHover,index)
		if not isHover then
			GameTooltip_Hide()
		else
			local owner,ownerGUID,thisGUID
			if ExRT.mds.Pets then
				owner = ExRT.mds.Pets:getOwnerNameByGUID(self.LGUID[index])
			end		
			if VExRT.BossWatcher.GUIDs then
				thisGUID = self.LGUID[index]
				if ExRT.mds.Pets then
					ownerGUID = ExRT.mds.Pets:getOwnerGUID(self.LGUID[index])
				end
			end
			if owner or thisGUID then
				GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
				if thisGUID then
					GameTooltip:AddLine(GUIDtoText("%s",thisGUID))
				end
				if owner then
					GameTooltip:AddLine( format(ExRT.L.BossWatcherPetOwner,owner) .. GUIDtoText(" (%s)",ownerGUID) )
				end
				GameTooltip:Show()
			end
		end
	end

	tab.filterFrame.targetScroll = ExRT.lib.CreateScrollList(tabName.."FilterFrameTargetScroll",tab.filterFrame,nil,210,-62,190,19)
	tab.filterFrame.targetScroll.LGUID = {}
	tab.filterFrame.targetScroll.dontDisable = true
	
	tab.filterFrame.targetClear = ExRT.lib.CreateButton(nil,tab.filterFrame,190,16,nil,210,-30,ExRT.L.BossWatcherBuffsAndDebuffsFilterClear)
	tab.filterFrame.targetClear:SetScript("OnClick",function ()
		BWInterfaceFrame.tab.tabs[3].filterD = nil
		BWInterfaceFrame.tab.tabs[3].filterFrame.targetFriendly:SetChecked(true)
		BWInterfaceFrame.tab.tabs[3].filterFrame.targetFriendly:SetChecked(true)
		UpdateTargetsList(BWInterfaceFrame.tab.tabs[3].filterFrame.targetScroll,nil,BWInterfaceFrame.tab.tabs[3].filterFrame.targetFriendly:GetChecked(),BWInterfaceFrame.tab.tabs[3].filterFrame.targetHostile:GetChecked())
		BWInterfaceFrame.tab.tabs[3].filterFrame.targetText:SetText(ExRT.L.BossWatcherBuffsAndDebuffsFilterNone)
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end)
	tab.filterFrame.targetText = ExRT.lib.CreateText(tab.filterFrame,180,16,nil,215,-46,"LEFT","MIDDLE",nil,11,ExRT.L.BossWatcherBuffsAndDebuffsFilterNone,nil,1,1,1)

	tab.filterFrame.targetFriendly = ExRT.lib.CreateCheckBox(tabName.."FilterFrameTargetCheckFriendly",tab.filterFrame,nil,210,-338,ExRT.L.BossWatcherBuffsAndDebuffsFilterFriendly,true)
	tab.filterFrame.targetHostile = ExRT.lib.CreateCheckBox(tabName.."FilterFrameTargetCheckHostile",tab.filterFrame,nil,210,-363,ExRT.L.BossWatcherBuffsAndDebuffsFilterHostile,true)
	tab.filterFrame.targetFriendly:SetScript("OnClick",function ()
		UpdateTargetsList(BWInterfaceFrame.tab.tabs[3].filterFrame.targetScroll,nil,BWInterfaceFrame.tab.tabs[3].filterFrame.targetFriendly:GetChecked(),BWInterfaceFrame.tab.tabs[3].filterFrame.targetHostile:GetChecked())
		if BWInterfaceFrame.tab.tabs[3].filterFrame.targetFriendly:GetChecked() then
			BWInterfaceFrame.tab.tabs[3].filterD = 1
		end
		if BWInterfaceFrame.tab.tabs[3].filterFrame.targetHostile:GetChecked() then
			if BWInterfaceFrame.tab.tabs[3].filterD == 1 then
				BWInterfaceFrame.tab.tabs[3].filterD = nil
			else
				BWInterfaceFrame.tab.tabs[3].filterD = 2
			end
		end
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end)
	tab.filterFrame.targetHostile:SetScript("OnClick",tab.filterFrame.targetFriendly:GetScript("OnClick"))
	ExRT.lib.SetPoint(tab.filterFrame.targetFriendly,"TOPLEFT",tab.filterFrame.targetScroll,"BOTTOMLEFT",0,4)
	ExRT.lib.SetPoint(tab.filterFrame.targetHostile,"TOPLEFT",tab.filterFrame.targetFriendly,"BOTTOMLEFT",0,8)

	function tab.filterFrame.targetScroll:SetListValue(index)
		BWInterfaceFrame.tab.tabs[3].filterD = BWInterfaceFrame.tab.tabs[3].filterFrame.targetScroll.LGUID[index]
		BWInterfaceFrame.tab.tabs[3].filterFrame.targetText:SetText(BWInterfaceFrame.tab.tabs[3].filterFrame.targetScroll.L[index])
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end
	
 	tab.filterFrame.targetScroll.HoverListValue = tab.filterFrame.sourceScroll.HoverListValue
	
	local function BuffsFilterFrameChkHover(self)
		local i = self.frameNum
		if i == 4 then
			return
		end
		local sList = module.db.buffsFilters[i][-2]
		if not sList then
			sList = {}
			for sid,_ in pairs(module.db.buffsFilters[i]) do
				if sid > 0 then
					sList[#sList + 1] = sid
				end
			end
		end
		if #sList == 0 then
			return
		end
		local sList2 = {}
		if #sList <= 35 then
			for j=1,#sList do
				local sID,_,sT=GetSpellInfo(sList[j])
				if sID then
					sList2[#sList2 + 1] = "|T"..sT..":0|t |cffffffff"..sID.."|r"
				end
			end
		else
			local count = 1
			for j=1,#sList do
				local sID,_,sT=GetSpellInfo(sList[j])
				if sID then
					if not sList2[count] then
						sList2[count] = {"|T"..sT..":0|t |cffffffff"..sID.."|r"}
					elseif not sList2[count].right then
						sList2[count].right = "|cffffffff"..sID.."|r |T"..sT..":0|t"
						count = count + 1
					end
				end
			end
		end
		ExRT.lib.TooltipShow(self,"ANCHOR_LEFT",ExRT.L.BossWatcherFilterTooltip..":",unpack(sList2))
	end
	local function BuffsFilterFrameResetEditBoxBuff(i)
		local resetTable = {}
		for sID,_ in pairs(module.db.buffsFilters[i]) do
			if sID > 0 then
				resetTable[#resetTable + 1] = sID
			end
		end
		for _,sID in ipairs(resetTable) do
			module.db.buffsFilters[i][sID] = nil
		end
	end
	
	local function BuffsFilterFrameChkSpecialClick(self)
		if self:GetChecked() then
			module.db.buffsFilterStatus[self._i] = true
		else
			module.db.buffsFilterStatus[self._i] = nil
		end
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end
	
	tab.filterFrame.chkSpecial = {}
	for i=1,#module.db.buffsFilters do
		local topPosFix = -30-(i-1)*25
		if i > 4 then
			topPosFix = -30-(i+3)*25
		elseif i > 3 then
			topPosFix = -30-(i+1)*25
		end
		tab.filterFrame.chkSpecial[i] = ExRT.lib.CreateCheckBox(nil,tab.filterFrame,nil,400,topPosFix,module.db.buffsFilters[i][-1])
		tab.filterFrame.chkSpecial[i]._i = i
		tab.filterFrame.chkSpecial[i]:SetScript("OnClick",BuffsFilterFrameChkSpecialClick)
		tab.filterFrame.chkSpecial[i].hover = CreateFrame("Frame",nil,tab.filterFrame)
		tab.filterFrame.chkSpecial[i].hover:SetPoint("TOPLEFT",430,topPosFix-5)
		tab.filterFrame.chkSpecial[i].hover:SetSize(125,25)
		tab.filterFrame.chkSpecial[i].hover:SetScript("OnEnter",BuffsFilterFrameChkHover)
		tab.filterFrame.chkSpecial[i].hover:SetScript("OnLeave",GameTooltip_Hide)
		tab.filterFrame.chkSpecial[i].hover.frameNum = i
	end
	
	local BuffsFilterFrameSceludedUpdateDB = nil
	local function BuffsFilterFrameSceludedUpdateDBFunc()
		BuffsFilterFrameSceludedUpdateDB = nil
		UpdateBuffPageDB()
		UpdateBuffsPage()
	end
	
	tab.filterFrame.chkSpecial[3].ebox = ExRT.lib.CreateMultiEditBox(tabName.."FilterFrameCheckSpecial3eBox",tab.filterFrame.chkSpecial[3],145,42,nil,0,0)
	ExRT.lib.SetPoint(tab.filterFrame.chkSpecial[3].ebox,"TOPLEFT",tab.filterFrame.chkSpecial[3],"BOTTOMLEFT",10,0)
	tab.filterFrame.chkSpecial[3].ebox.EditBox:SetScript("OnTextChanged",function (self,isUser)
		local text = self:GetText()
		if isUser then
			if text:match("[^0-9\n]") then
				text = string.gsub(text,"[^0-9\n]","")
			end
			self:SetText(text)
		else
			return
		end
		BuffsFilterFrameResetEditBoxBuff(3)
		local lines = {strsplit("\n", text)}
		local isExists = nil
		for i=1,#lines do
			lines[i] = tonumber(lines[i]) or 0
			module.db.buffsFilters[3][ lines[i] ] = true
			isExists = true
		end		
		if isExists then
			if BWInterfaceFrame.tab.tabs[3].filterFrame.chkSpecial[3]:GetChecked() then
				BuffsFilterFrameSceludedUpdateDB = ExRT.mds.ScheduleETimer(BuffsFilterFrameSceludedUpdateDB, BuffsFilterFrameSceludedUpdateDBFunc, 0.8)
			end
		end
	end)
	local function BuffsFilterFrameEditBoxOnEnter(self)
		GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
		GameTooltip:SetText(ExRT.L.BossWatcherBuffsAndDebuffsFilterEditBoxTooltip)
		GameTooltip:Show()
	end
	tab.filterFrame.chkSpecial[3].ebox.FocusButton:SetScript("OnEnter",BuffsFilterFrameEditBoxOnEnter)
	tab.filterFrame.chkSpecial[3].ebox.FocusButton:SetScript("OnLeave",GameTooltip_Hide)
	tab.filterFrame.chkSpecial[3].ebox.EditBox:SetScript("OnEnter",BuffsFilterFrameEditBoxOnEnter)
	tab.filterFrame.chkSpecial[3].ebox.EditBox:SetScript("OnLeave",GameTooltip_Hide)
	
	tab.filterFrame.chkSpecial[4].ebox = ExRT.lib.CreateMultiEditBox(tabName.."FilterFrameCheckSpecial4eBox",tab.filterFrame.chkSpecial[4],145,42,nil,0,0)
	ExRT.lib.SetPoint(tab.filterFrame.chkSpecial[4].ebox,"TOPLEFT",tab.filterFrame.chkSpecial[4],"BOTTOMLEFT",10,0)
	tab.filterFrame.chkSpecial[4].ebox.EditBox:SetScript("OnTextChanged",function (self,isUser)
		local text = self:GetText()
		for key,val in pairs(module.db.buffsFilters[4]) do
			if key ~= -1 then
				module.db.buffsFilters[4][key] = nil
			end
		end
		local lines = {strsplit("\n", text)}
		for i=1,#lines do
			if lines[i] ~= "" then
				module.db.buffsFilters[4][ strlower(lines[i]) ] = true
			end
		end		
		if BWInterfaceFrame.tab.tabs[3].filterFrame.chkSpecial[4]:GetChecked() then
			BuffsFilterFrameSceludedUpdateDB = ExRT.mds.ScheduleETimer(BuffsFilterFrameSceludedUpdateDB, BuffsFilterFrameSceludedUpdateDBFunc, 0.8)
		end
	end)
	tab.filterFrame.chkSpecial[4].ebox.FocusButton:SetScript("OnEnter",BuffsFilterFrameEditBoxOnEnter)
	tab.filterFrame.chkSpecial[4].ebox.FocusButton:SetScript("OnLeave",GameTooltip_Hide)
	tab.filterFrame.chkSpecial[4].ebox.EditBox:SetScript("OnEnter",BuffsFilterFrameEditBoxOnEnter)
	tab.filterFrame.chkSpecial[4].ebox.EditBox:SetScript("OnLeave",GameTooltip_Hide)
	
	tab.filterButton = ExRT.lib.CreateButton(nil,tab,100,22,nil,5,-10,ExRT.L.BossWatcherBuffsAndDebuffsFilterFilter)
	tab.filterButton:SetScript("OnClick",function ()
		BWInterfaceFrame.tab.tabs[3].filterFrame:Show()
	end)
	
	tab.filterText = ExRT.lib.CreateText(tab,650,22,nil,110,-10,"LEFT","CENTER",nil,nil,"",nil,1,1,1,1)
	CreateFilterText()

	tab:SetScript("OnShow",function (self)
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdateBuffPageDB()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
		UpdateBuffsPage()
	end)
	
	
	
	---- Mobs Info & Switch
	tab = BWInterfaceFrame.tab.tabs[4]
	tabName = BWInterfaceFrame_Name.."MobsTab"
	
	tab.targetsList = ExRT.lib.CreateScrollList(tabName.."TargetsList",tab,"TOPLEFT",5,-75,290,31)
	tab.targetsList.GUIDs = {}
	
	tab.selectedMob = ExRT.lib.CreateText(tab,530,12,"TOPLEFT",305,-80,"LEFT","TOP",nil,11,"",nil,1,1,1)
	tab.infoTabs = ExRT.lib.CreateTabFrame(BWInterfaceFrame_Name.."InfoTabs",tab,530,465,295,-115,3,1,ExRT.L.BossWatcherSwitchBySpell,ExRT.L.BossWatcherSwitchBySpell,ExRT.L.BossWatcherDamageSwitchTabInfo)
	
	tab.switchSpellBox = ExRT.lib.CreateMultiEditBox(BWInterfaceFrame_Name.."SwitchSpellBox",tab.infoTabs.tabs[1],510,445,"TOP",0,-10)
	tab.switchTargetBox = ExRT.lib.CreateMultiEditBox(BWInterfaceFrame_Name.."SwitchTargetBox",tab.infoTabs.tabs[2],510,445,"TOP",0,-10)
	tab.infoBoxText = ExRT.lib.CreateText(tab.infoTabs.tabs[3],510,310,"TOP",0,-15,"LEFT","TOP",nil,12,ExRT.L.BossWatcherDamageSwitchTabInfoNoInfo,nil,1,1,1)
	
	tab.switchSpellBox.EditBox:SetHyperlinksEnabled(true)
	tab.switchSpellBox.EditBox:SetScript("OnHyperlinkEnter",ExRT.lib.EditBoxOnEnterHyperLinkTooltip)
	tab.switchSpellBox.EditBox:SetScript("OnHyperlinkLeave",ExRT.lib.EditBoxOnLeaveHyperLinkTooltip)
	
	function tab.targetsList:SetListValue(index)
		local destGUID = BWInterfaceFrame.tab.tabs[4].targetsList.GUIDs[index]
		
		local _time = timestampToFightTime(module.db.nowData.damage_seen[destGUID])
		local fight_dur = module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart
		
		BWInterfaceFrame.tab.tabs[4].selectedMob:SetText(GetGUID(destGUID).." "..date("%M:%S", _time )..GUIDtoText(" (%s)",destGUID))
		
		_time = _time / fight_dur
		
		local textResult = ""
		local textResult2 = ""
		if module.db.nowData.switch[destGUID] then
			local switchTable = {}

			for sourceGUID,sourceData in pairs(module.db.nowData.switch[destGUID][1]) do
				if ExRT.mds.GetUnitTypeByGUID(sourceGUID) == 0 then
					table.insert(switchTable,{GetGUID(sourceGUID),timestampToFightTime(sourceData[1]),sourceGUID,sourceData[2]})
				end
			end
			table.sort(switchTable,function(a,b) return a[2] < b[2] end)
			if #switchTable > 0 then
				textResult = ExRT.L.BossWatcherReportCast.." [" .. date("%M:%S", switchTable[1][2] ) .."]:|n"
				for i=1,#switchTable do
					local spellName = GetSpellInfo(switchTable[i][4] or 0)
					textResult = textResult .."|c".. ExRT.mds.classColorByGUID(switchTable[i][3]).. switchTable[i][1] .. GUIDtoText(" <%s>",switchTable[i][3]) .. "|r (".. format("%.3f",switchTable[i][2]-switchTable[1][2])..", |Hspell:"..(switchTable[i][4] or 0).."|h"..(spellName or "?").."|h)"
					if i ~= #switchTable then
						textResult = textResult .. "|n"
					end
				end
				textResult = textResult .. "\n\n"
			end
			
			wipe(switchTable)
			for sourceGUID,sourceData in pairs(module.db.nowData.switch[destGUID][2]) do
				if ExRT.mds.GetUnitTypeByGUID(sourceGUID) == 0 then
					table.insert(switchTable,{GetGUID(sourceGUID),sourceData[1] - module.db.data[module.db.nowNum].encounterStart,sourceGUID,sourceData[2]})
				end
			end
			table.sort(switchTable,function(a,b) return a[2] < b[2] end)
			if #switchTable > 0 then
				textResult2 = textResult2 .. ExRT.L.BossWatcherReportSwitch.." [" .. date("%M:%S", switchTable[1][2] ) .."]:|n"
				for i=1,#switchTable do
					textResult2 = textResult2 .. "|c".. ExRT.mds.classColorByGUID(switchTable[i][3]).. switchTable[i][1] .. GUIDtoText(" <%s>",switchTable[i][3]) .. "|r (".. format("%.3f",switchTable[i][2]-switchTable[1][2])..")"
					if i ~= #switchTable then
						textResult2 = textResult2 .. "|n"
					end
				end
			end
		end		
		BWInterfaceFrame.tab.tabs[4].switchSpellBox.EditBox:SetText(textResult)
		BWInterfaceFrame.tab.tabs[4].switchTargetBox.EditBox:SetText(textResult2)
		
		--> Other Info
		textResult = ""
		for i=1,#module.db.nowData.dies do
			if module.db.nowData.dies[i][1]==destGUID then
				textResult = textResult .. ExRT.L.BossWatcherDamageSwitchTabInfoRIP..": ".. date("%M:%S", timestampToFightTime(module.db.nowData.dies[i][3]) ) .. date(" (%H:%M:%S)", module.db.nowData.dies[i][3] ) .. "\n"
				for j=1,#module.db.raidTargets do
					if module.db.raidTargets[j] == module.db.nowData.dies[i][4] then
						textResult = textResult .. ExRT.L.BossWatcherMarkOnDeath..": |TInterface\\TargetingFrame\\UI-RaidTargetingIcon_".. j  ..":0|t ".. string.gsub( ExRT.L["raidtargeticon"..j] , "[{}]", "" ) .."\n"
						break
					end
				end
			end
		end
		local mobID = ExRT.mds.GUIDtoID(destGUID)
		local mobSpawnID = tonumber(destGUID:sub(-8), 16) or 0
		if ExRT.WOD then
			mobSpawnID = tonumber(destGUID:match(":([^:]+)$"), 16) or 0
		end
		textResult = textResult .. "Mob ID: ".. mobID .. "\n"
		textResult = textResult .. "Spawn ID: ".. mobSpawnID .. "\n"
		textResult = textResult .. "GUID: ".. destGUID .. "\n"
		BWInterfaceFrame.tab.tabs[4].infoBoxText:SetText(textResult)
	end
	
	function tab.targetsList:HoverListValue(isHover,index)
		if not isHover then
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Hide()
			BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine:Hide()
			GameTooltip_Hide()
		else
			local mobGUID = BWInterfaceFrame.tab.tabs[4].targetsList.GUIDs[index]
			local mobSeen = timestampToFightTime( module.db.nowData.damage_seen[mobGUID] )
			local fight_dur = module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart
			local _time = mobSeen / fight_dur
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOMLEFT",BWInterfaceFrame.timeLineFrame.width*_time,0)
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Show()
			
			local dieTime = 1
			for i=1,#module.db.nowData.dies do
				if module.db.nowData.dies[i][1]==mobGUID then
					dieTime = timestampToFightTime(module.db.nowData.dies[i][3]) / fight_dur
					break
				end
			end
			BWInterfaceFrame.timeLineFrame.timeLine.lifeUnderLine:SetPoint(_time,dieTime)
			
			GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
			if VExRT.BossWatcher.GUIDs then
				GameTooltip:AddLine(GUIDtoText("%s",mobGUID))
			end
			local scrollPos = ExRT.mds.Round( BWInterfaceFrame.tab.tabs[4].targetsList.ScrollBar:GetValue())
			if  BWInterfaceFrame.tab.tabs[4].targetsList.List[index - scrollPos + 1].text:IsTruncated() then
				GameTooltip:AddLine(GetGUID(mobGUID) .. date(" %M:%S", mobSeen) )
			end
			GameTooltip:Show()
		end
	end

	local function UpdateMobsPage()
		table.wipe(BWInterfaceFrame.tab.tabs[4].targetsList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[4].targetsList.GUIDs)
		
		local mobsList = {}
		for mobGUID,mobData in pairs(module.db.nowData.damage) do
			local mobID = ExRT.mds.GUIDtoID(mobGUID)
			if ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[mobGUID],2) == 512 and mobID ~= 76933 then	--76933 = Mage T100 talent Prismatic Crystal fix
				mobsList[#mobsList+1] = {GetGUID(mobGUID),module.db.nowData.damage_seen[mobGUID],mobGUID}
			end
		end
		table.sort(mobsList,function(a,b) return a[2] < b[2] end)
		for i=1,#mobsList do
			BWInterfaceFrame.tab.tabs[4].targetsList.L[i] =  date("%M:%S ", timestampToFightTime(mobsList[i][2]))..mobsList[i][1]
			BWInterfaceFrame.tab.tabs[4].targetsList.GUIDs[i] = mobsList[i][3]
		end
		BWInterfaceFrame.tab.tabs[4].targetsList.Update()
	end

	tab:SetScript("OnShow",function (self)
		BWInterfaceFrame.timeLineFrame:ClearAllPoints()
		BWInterfaceFrame.timeLineFrame:SetPoint("TOP",self,"TOP",0,-10)
		BWInterfaceFrame.timeLineFrame:Show()
		
		BWInterfaceFrame.report:Show()
		
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdateMobsPage()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	tab:SetScript("OnHide",function (self)
		BWInterfaceFrame.timeLineFrame:Hide()
		BWInterfaceFrame.report:Hide()
	end)
	
	
	
	
	---- Spells
	tab = BWInterfaceFrame.tab.tabs[5]
	tabName = BWInterfaceFrame_Name.."SpellsTab"
	
	local SpellsTab_isFriendly = true

	tab.playersList = ExRT.lib.CreateScrollList(tabName.."PlayersList",tab,"TOPLEFT",5,-110,180,29)
	tab.playersCastsList = ExRT.lib.CreateScrollList(tabName.."PlayersCastsList",tab,"TOPLEFT",185,-79,644,31)
	tab.playersList.IndexToGUID = {}
	tab.playersCastsList.IndexToGUID = {}
	
	function tab.playersList:HoverListValue(isHover,index)
		if not isHover then
			GameTooltip_Hide()
		else
			GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
			if VExRT.BossWatcher.GUIDs then
				GameTooltip:AddLine(GUIDtoText("%s",BWInterfaceFrame.tab.tabs[5].playersList.IndexToGUID[index]))
			end
			GameTooltip:Show()
		end
	end
	function tab.playersCastsList:HoverListValue(isHover,index)
		if not isHover then
			GameTooltip_Hide()
			ExRT.lib.HideAdditionalTooltips()
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Hide()
		else
			local scrollPos = ExRT.mds.Round(BWInterfaceFrame.tab.tabs[5].playersCastsList.ScrollBar:GetValue())
			local this = BWInterfaceFrame.tab.tabs[5].playersCastsList.List[index - scrollPos + 1]
			
			GameTooltip:SetOwner(this or self,"ANCHOR_BOTTOMLEFT")
			GameTooltip:SetHyperlink(BWInterfaceFrame.tab.tabs[5].playersCastsList.IndexToGUID[index][1])
			GameTooltip:Show()
			
			if this.text:IsTruncated() then
				ExRT.lib.AdditionalTooltip(nil,{this.text:GetText()})
			end
			
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOMLEFT",BWInterfaceFrame.timeLineFrame.width*BWInterfaceFrame.tab.tabs[5].playersCastsList.IndexToGUID[index][2],0)
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Show()
		end
	end
	
	function tab.playersList:SetListValue(index)
		table.wipe(BWInterfaceFrame.tab.tabs[5].playersCastsList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[5].playersCastsList.IndexToGUID)
		
		local selfGUID = BWInterfaceFrame.tab.tabs[5].playersList.IndexToGUID[index]
		local fight_dur = module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart
		
		for i,PlayerCastData in ipairs(module.db.nowData.cast[selfGUID]) do
			local spellName,_,spellTexture = GetSpellInfo(PlayerCastData[2])
			local time_ = timestampToFightTime(PlayerCastData[1])
			local isCast = ""
			if PlayerCastData[3] == 2 then
				isCast = ExRT.L.BossWatcherBeginCasting.." "
			end
			BWInterfaceFrame.tab.tabs[5].playersCastsList.L[#BWInterfaceFrame.tab.tabs[5].playersCastsList.L + 1] = format("[%02d:%06.3f] ",time_ / 60,time_ % 60)..isCast..format("%s%s",spellTexture and "|T"..spellTexture..":0|t " or "",spellName or "???")
			BWInterfaceFrame.tab.tabs[5].playersCastsList.IndexToGUID[#BWInterfaceFrame.tab.tabs[5].playersCastsList.IndexToGUID + 1] = {"spell:"..PlayerCastData[2],time_ / fight_dur,PlayerCastData[2]}
			
			if PlayerCastData[4] and PlayerCastData[4] ~= "" then
				BWInterfaceFrame.tab.tabs[5].playersCastsList.L[#BWInterfaceFrame.tab.tabs[5].playersCastsList.L] = BWInterfaceFrame.tab.tabs[5].playersCastsList.L[#BWInterfaceFrame.tab.tabs[5].playersCastsList.L] .. " > |c"..ExRT.mds.classColorByGUID(PlayerCastData[4])..GetGUID( PlayerCastData[4] )..GUIDtoText(" <%s>",PlayerCastData[4]).."|r"
			end
		end
		
		BWInterfaceFrame.tab.tabs[5].playersCastsList.Update()		
	end
	function tab.playersCastsList:SetListValue(index)
		for j=1,self.linesNum do
			self.List[j]:SetEnabled(true)
		end
		self.selected = nil
		
		local sID = self.IndexToGUID[index][3]
		if self.redSpell == sID then
			self.redSpell = nil
		else
			self.redSpell = sID
		end
		self.Update()
	end
	function tab.playersCastsList:UpdateAdditional(scrollPos)
		for j=1,self.linesNum do
			local index = self.List[j].index
			if self.redSpell and index and self.IndexToGUID[index] and self.IndexToGUID[index][3] == self.redSpell then
				self.List[j].text:SetTextColor(1,0.2,0.2,1)
			else
				self.List[j].text:SetTextColor(1,1,1,1)
			end
		end
	end	
	
	local function UpdateSpellsPage()
		table.wipe(BWInterfaceFrame.tab.tabs[5].playersList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[5].playersList.IndexToGUID)
		table.wipe(BWInterfaceFrame.tab.tabs[5].playersCastsList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[5].playersCastsList.IndexToGUID)
		local playersListTable = {}
		for sourceGUID,sourceData in pairs(module.db.nowData.cast) do
			if not ExRT.mds.table_find(playersListTable,sourceGUID,1) and ((SpellsTab_isFriendly and ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[sourceGUID],1) == 1024) or (not SpellsTab_isFriendly and ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[sourceGUID],2) == 512)) then
				playersListTable[#playersListTable + 1] = {sourceGUID,GetGUID( sourceGUID ),"|c"..ExRT.mds.classColorByGUID(sourceGUID)}
			end
		end
		table.sort(playersListTable,function (a,b) return a[2] < b[2] end)
		for i,playersListTableData in ipairs(playersListTable) do
			BWInterfaceFrame.tab.tabs[5].playersList.L[i] = playersListTableData[3]..playersListTableData[2]
			BWInterfaceFrame.tab.tabs[5].playersList.IndexToGUID[i] = playersListTableData[1]
		end
		
		BWInterfaceFrame.tab.tabs[5].playersList.selected = nil
		
		BWInterfaceFrame.tab.tabs[5].playersList.Update()
		BWInterfaceFrame.tab.tabs[5].playersCastsList.Update()
	end
	
	tab.chkFriendly = CreateFrame("CheckButton",tabName.."ChkFriendly",tab,"UIRadioButtonTemplate")  
	tab.chkFriendly:SetPoint("TOPLEFT", 10, -78)
	tab.chkFriendly.text:SetText(ExRT.L.BossWatcherFriendly)
	tab.chkFriendly:SetScript("OnClick", function(self,event) 
		BWInterfaceFrame.tab.tabs[5].chkEnemy:SetChecked(not self:GetChecked())
		if self:GetChecked() then
			SpellsTab_isFriendly = true
		else
			SpellsTab_isFriendly = nil
		end
		UpdateSpellsPage()
	end)
	tab.chkFriendly:SetChecked(true)
	tab.chkEnemy = CreateFrame("CheckButton",tabName.."ChkEnemy",tab,"UIRadioButtonTemplate")  
	tab.chkEnemy:SetPoint("TOPLEFT", 10, -93)
	tab.chkEnemy.text:SetText(ExRT.L.BossWatcherHostile)
	tab.chkEnemy:SetScript("OnClick", function(self,event) 
		BWInterfaceFrame.tab.tabs[5].chkFriendly:SetChecked(not self:GetChecked())
		if self:GetChecked() then
			SpellsTab_isFriendly = nil
		else
			SpellsTab_isFriendly = true
		end
		UpdateSpellsPage()
	end)

	tab:SetScript("OnShow",function (self)
		BWInterfaceFrame.timeLineFrame:ClearAllPoints()
		BWInterfaceFrame.timeLineFrame:SetPoint("TOP",self,"TOP",0,-10)
		BWInterfaceFrame.timeLineFrame:Show()
		
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdateSpellsPage()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	tab:SetScript("OnHide",function (self)
		BWInterfaceFrame.timeLineFrame:Hide()
	end)
	
	
	
	---- Power
	tab = BWInterfaceFrame.tab.tabs[6]
	tabName = BWInterfaceFrame_Name.."PowerTab"
	
	local PowerTab_isFriendly = true

	tab.sourceList = ExRT.lib.CreateScrollList(tabName.."SourceList",tab,"TOPLEFT",5,-50,180,24)
	tab.sourceList.IndexToGUID = {}
	tab.powerTypeList = ExRT.lib.CreateScrollList(tabName.."PowerTypeList",tab,"TOPLEFT",0,0,180,8)
	ExRT.lib.SetPoint(tab.powerTypeList,"TOPLEFT",tab.sourceList,"BOTTOMLEFT",0,-3)
	tab.powerTypeList.IndexToGUID = {}
	
	local function EnergyLineOnEnter(self)
		if self.spellID then
			GameTooltip:SetOwner(self, "ANCHOR_LEFT")
			GameTooltip:SetHyperlink("spell:"..self.spellID)
			GameTooltip:Show()
		end
	end
	
	tab.text = ExRT.lib.CreateText(tab,420,tab:GetHeight()-10,nil,185,-5,"LEFT","TOP",nil,11,nil,nil,1,1,1,1)
	tab.spells = {}
	for i=1,20 do
		tab.spells[i] = CreateFrame("Frame",nil,tab)
		tab.spells[i]:SetPoint("TOPLEFT",190,-10-28*(i-1))
		tab.spells[i]:SetSize(420,28)
		
		tab.spells[i].texture = tab.spells[i]:CreateTexture(nil,"BACKGROUND")
		tab.spells[i].texture:SetSize(24,24)
		tab.spells[i].texture:SetPoint("TOPLEFT",0,-2)
		
		tab.spells[i].spellName = ExRT.lib.CreateText(tab.spells[i],225,28,nil,26,0,"LEFT","MIDDLE",nil,13,nil,nil,1,1,1,1)
		tab.spells[i].amount = ExRT.lib.CreateText(tab.spells[i],90,28,nil,250,0,"LEFT","MIDDLE",nil,12,nil,nil,1,1,1,1)
		tab.spells[i].count = ExRT.lib.CreateText(tab.spells[i],80,28,nil,340,0,"LEFT","MIDDLE",nil,12,nil,nil,1,1,1,1)
		
		tab.spells[i]:SetScript("OnEnter",EnergyLineOnEnter)
		tab.spells[i]:SetScript("OnLeave",GameTooltip_Hide)
	end
	
	local function EnergyClearLines()
		for i=1,#BWInterfaceFrame.tab.tabs[6].spells do
			BWInterfaceFrame.tab.tabs[6].spells[i]:Hide()
		end
	end
	
	function tab.sourceList:SetListValue(index)
		table.wipe(BWInterfaceFrame.tab.tabs[6].powerTypeList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[6].powerTypeList.IndexToGUID)

		local sourceGUID = BWInterfaceFrame.tab.tabs[6].sourceList.IndexToGUID[index]
		BWInterfaceFrame.tab.tabs[6].sourceGUID = sourceGUID
		local powerList = {}
		for powerType,powerData in pairs(module.db.nowData.power[sourceGUID]) do
			powerList[#powerList + 1] = {powerType,module.db.energyLocale[ powerType ] or ExRT.L.BossWatcherEnergyTypeUnknown..powerType}
		end
		table.sort(powerList,function (a,b) return a[1] < b[1] end)
		for i,powerData in ipairs(powerList) do
			BWInterfaceFrame.tab.tabs[6].powerTypeList.L[i] = powerData[2]
			BWInterfaceFrame.tab.tabs[6].powerTypeList.IndexToGUID[i] = powerData[1]
		end
		
		BWInterfaceFrame.tab.tabs[6].powerTypeList.selected = nil
		BWInterfaceFrame.tab.tabs[6].powerTypeList.Update()
		EnergyClearLines()
	end
	function tab.powerTypeList:SetListValue(index)
		local powerType = BWInterfaceFrame.tab.tabs[6].powerTypeList.IndexToGUID[index]
		local sourceGUID = BWInterfaceFrame.tab.tabs[6].sourceGUID
		
		local spellList = {}
		for spellID,spellData in pairs(module.db.nowData.power[sourceGUID][powerType]) do
			local spellName,_,spellTexture = GetSpellInfo(spellID)
			spellList[#spellList + 1] = {spellID,spellName,spellTexture,spellData[1],spellData[2]}
		end
		table.sort(spellList,function (a,b) return a[4] > b[4] end)
		EnergyClearLines()
		for i,spellData in ipairs(spellList) do
			local line = BWInterfaceFrame.tab.tabs[6].spells[i]
			if line then
				line.texture:SetTexture(spellData[3])
				line.spellName:SetText(spellData[2])
				line.amount:SetText(spellData[4])
				line.count:SetText(spellData[5].." |4"..ExRT.L.BossWatcherEnergyOnce1..":"..ExRT.L.BossWatcherEnergyOnce2..":"..ExRT.L.BossWatcherEnergyOnce1)
				line.spellID = spellData[1]
				line:Show()
			end
		end
	end

	local function UpdatePowerPage()
		table.wipe(BWInterfaceFrame.tab.tabs[6].sourceList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[6].sourceList.IndexToGUID)
		table.wipe(BWInterfaceFrame.tab.tabs[6].powerTypeList.L)
		table.wipe(BWInterfaceFrame.tab.tabs[6].powerTypeList.IndexToGUID)
		local sourceListTable = {}
		for sourceGUID,sourceData in pairs(module.db.nowData.power) do
			if (PowerTab_isFriendly and ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[sourceGUID],1) == 1024) or (not PowerTab_isFriendly and ExRT.mds.GetUnitInfoByUnitFlag(module.db.data[module.db.nowNum].reaction[sourceGUID],2) == 512) then
				sourceListTable[#sourceListTable + 1] = {sourceGUID,GetGUID( sourceGUID ),"|c"..ExRT.mds.classColorByGUID(sourceGUID)}
			end
		end
		table.sort(sourceListTable,function (a,b) return a[2] < b[2] end)
		for i,sourceData in ipairs(sourceListTable) do
			BWInterfaceFrame.tab.tabs[6].sourceList.L[i] = sourceData[3]..sourceData[2]
			BWInterfaceFrame.tab.tabs[6].sourceList.IndexToGUID[i] = sourceData[1]
		end
		
		BWInterfaceFrame.tab.tabs[6].sourceList.selected = nil
		BWInterfaceFrame.tab.tabs[6].powerTypeList.selected = nil
		
		BWInterfaceFrame.tab.tabs[6].sourceList.Update()
		BWInterfaceFrame.tab.tabs[6].powerTypeList.Update()
		EnergyClearLines()
	end
	
	tab.chkFriendly = CreateFrame("CheckButton",tabName.."ChkFriendly",tab,"UIRadioButtonTemplate")  
	tab.chkFriendly:SetPoint("TOPLEFT", 10, -10)
	tab.chkFriendly.text:SetText(ExRT.L.BossWatcherFriendly)
	tab.chkFriendly:SetScript("OnClick", function(self,event) 
		BWInterfaceFrame.tab.tabs[6].chkEnemy:SetChecked(not self:GetChecked())
		if self:GetChecked() then
			PowerTab_isFriendly = true
		else
			PowerTab_isFriendly = nil
		end
		UpdatePowerPage()
	end)
	tab.chkFriendly:SetChecked(true)
	tab.chkEnemy = CreateFrame("CheckButton",tabName.."ChkEnemy",tab,"UIRadioButtonTemplate")  
	tab.chkEnemy:SetPoint("TOPLEFT", 10, -25)
	tab.chkEnemy.text:SetText(ExRT.L.BossWatcherHostile)
	tab.chkEnemy:SetScript("OnClick", function(self,event) 
		BWInterfaceFrame.tab.tabs[6].chkFriendly:SetChecked(not self:GetChecked())
		if self:GetChecked() then
			PowerTab_isFriendly = nil
		else
			PowerTab_isFriendly = true
		end
		UpdatePowerPage()
	end)

	tab:SetScript("OnShow",function (self)
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdatePowerPage()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	
	
	
	---- Graphics
	tab = BWInterfaceFrame.tab.tabs[8]
	tabName = BWInterfaceFrame_Name.."GraphicsTab"

	tab.graphicsTab = ExRT.lib.CreateTabFrame(tabName.."Tabs",tab,825,555,0,0,3,1,ExRT.L.BossWatcherGraphicsDPS,ExRT.L.BossWatcherGraphicsHealth,ExRT.L.BossWatcherGraphicsPower)
	ExRT.lib.SetPoint(tab.graphicsTab,"TOP",0,-27)
	
	tab.graphicsTab.dropDown = ExRT.lib.CreateScrollDropDown(BWInterfaceFrame_Name.."DropDown",tab.graphicsTab,"TOPLEFT",15,-5,200,200,10)
	tab.graph = ExRT.lib.CreateGraph(tab.graphicsTab,760,485,"TOP",0,-50)
	
	tab.graphicsTab.stepSlider = ExRT.lib.CreateSlider(BWInterfaceFrame_Name.."StepSlider",tab.graphicsTab,250,15,270,-15,1,1,ExRT.L.BossWatcherGraphicsStep,1)
	tab.graphicsTab.stepSlider:SetScript("OnValueChanged",function (self,value)
		value = ExRT.mds.Round(value)
		BWInterfaceFrame.tab.tabs[8].graph.step = value
		self.tooltipText = value
		self:tooltipReload(self)
		BWInterfaceFrame.tab.tabs[8].graph:Reload()
	end)
	tab.graphicsTab.stepSlider:SetScript("OnMinMaxChanged",function (self)
		local _min,_max = self:GetMinMaxValues()
		self.textLow:SetText(_min)
		self.textHigh:SetText(_max)
	end)
	
	tab.graph:SetScript("OnLeave",function ()
		GameTooltip_Hide()
	end)
	
	local function GraphGetFightMax()
		local i = 0
		for sec,data in pairs(module.db.data[module.db.nowNum].graphData) do
			i=max(sec,i)
		end
		return i
	end
	local function GraphDPSSelect(self,GUID)
		local myGraphData = {}
		local maxFight = GraphGetFightMax()
		for sec=1,maxFight do
			local dpsNow = 0
			for sourceGUID,sourceDPS in pairs(module.db.data[module.db.nowNum].graphData[sec].dps) do
				local owner = nil
				if ExRT.mds.Pets then
					owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
				end
				if sourceGUID == GUID or owner == GUID then
					dpsNow = dpsNow + sourceDPS
				end
			end
			myGraphData[#myGraphData + 1] = {sec,dpsNow}
		end
		table.sort(myGraphData,function(a,b)return a[1]<b[1] end)
		BWInterfaceFrame.tab.tabs[8].graph.data = myGraphData
		BWInterfaceFrame.tab.tabs[8].graph:Reload()
		
		BWInterfaceFrame.tab.tabs[8].graphicsTab.stepSlider:SetMinMaxValues(1,max(1,maxFight))
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown,GUID == "_total" and ExRT.L.BossWatcherGraphicsTotal or GetGUID( GUID ))	
		ExRT.lib.ScrollDropDown.Close()
	end
	local function GraphHealthSelect(self,name)
		local myGraphData = {}
		local maxFight = GraphGetFightMax()
		for sec,data in pairs(module.db.data[module.db.nowNum].graphData) do
			if data.health[name] then
				myGraphData[#myGraphData + 1] = {sec,data.health[name],data.name[name]}
			else
				myGraphData[#myGraphData + 1] = {sec,0,data.name[name]}
			end
		end
		table.sort(myGraphData,function(a,b)return a[1]<b[1] end)
		BWInterfaceFrame.tab.tabs[8].graph.data = myGraphData
		BWInterfaceFrame.tab.tabs[8].graph:Reload()
		
		BWInterfaceFrame.tab.tabs[8].graphicsTab.stepSlider:SetMinMaxValues(1,max(1,maxFight))
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown,name)	
		ExRT.lib.ScrollDropDown.Close()
	end
	local function GraphPowerSelect(self,name)
		local myGraphData = {}
		local maxFight = GraphGetFightMax()
		for sec,data in pairs(module.db.data[module.db.nowNum].graphData) do
			if data.power[name] then
				myGraphData[#myGraphData + 1] = {sec,data.power[name],data.name[name]}
			else
				myGraphData[#myGraphData + 1] = {sec,0,data.name[name]}
			end
		end
		table.sort(myGraphData,function(a,b)return a[1]<b[1] end)
		BWInterfaceFrame.tab.tabs[8].graph.data = myGraphData
		BWInterfaceFrame.tab.tabs[8].graph:Reload()
		
		BWInterfaceFrame.tab.tabs[8].graphicsTab.stepSlider:SetMinMaxValues(1,max(1,maxFight))
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown,name)	
		ExRT.lib.ScrollDropDown.Close()
	end

	local function GraphTabLoad()
		ExRT.lib.ScrollDropDown.Close()
		BWInterfaceFrame.tab.tabs[8].graph.data = {}
		BWInterfaceFrame.tab.tabs[8].graph:Reload()
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown,ExRT.L.BossWatcherGraphicsSelect)	
		table.wipe(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List)
		BWInterfaceFrame.tab.tabs[8].graphicsTab.stepSlider:SetMinMaxValues(1,1)
		BWInterfaceFrame.tab.tabs[8].graphicsTab.stepSlider:SetValue(1)
	end
	tab.graphicsTab.tabs[1]:SetScript("OnShow",function (self)
		GraphTabLoad()
		if not module.db.data[module.db.nowNum].graphData then
			return
		end
		local units = {}
		for i,data in pairs(module.db.data[module.db.nowNum].graphData) do
			for sourceGUID,_ in pairs(data.dps) do
				local GUID = sourceGUID
				if ExRT.mds.Pets then
					local owner = ExRT.mds.Pets:getOwnerGUID(GUID)
					if owner then
						GUID = owner
					end
				end
				if not ExRT.mds.table_find(units,GUID) and ExRT.mds.GetUnitTypeByGUID(GUID) == 0 then
					units[#units+1] = GUID
				end
			end
		end
		for i=1,#units do
			local info = {}
			BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List[i] = info
			local name = GetGUID( units[i] )
			local color = ""
			local GUIDpatt = ""
			if units[i] == "_total" then
				name = ExRT.L.BossWatcherGraphicsTotal
			else
				color = "|c"..ExRT.mds.classColorByGUID(units[i])
				GUIDpatt = " <%s>"
			end
			info.text = color..name..GUIDtoText(GUIDpatt,units[i])
			info.arg1 = units[i]
			info.func = GraphDPSSelect
			info.justifyH = "CENTER"
			info._sort = (units[i] == "_total" and "_total") or name
		end
		table.sort(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List,function(a,b)return a._sort < b._sort end)
	end)
	tab.graphicsTab.tabs[2]:SetScript("OnShow",function (self)
		GraphTabLoad()
		if not module.db.data[module.db.nowNum].graphData then
			return
		end
		local units = {}
		for i,data in pairs(module.db.data[module.db.nowNum].graphData) do
			for sourceName,_ in pairs(data.health) do
				if not ExRT.mds.table_find(units,sourceName) then
					units[#units+1] = sourceName
				end
			end
		end
		for i=1,#units do
			local info = {}
			BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List[i] = info
			info.text = units[i]
			info.arg1 = units[i]
			info.func = GraphHealthSelect
			info.justifyH = "CENTER" 
		end
		table.sort(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List,function(a,b)return a.text < b.text end)
	end)
	tab.graphicsTab.tabs[3]:SetScript("OnShow",function (self)
		GraphTabLoad()
		if not module.db.data[module.db.nowNum].graphData then
			return
		end
		local units = {}
		for i,data in pairs(module.db.data[module.db.nowNum].graphData) do
			for sourceName,_ in pairs(data.power) do
				if not ExRT.mds.table_find(units,sourceName) then
					units[#units+1] = sourceName
				end
			end
		end
		for i=1,#units do
			local info = {}
			BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List[i] = info
			info.text = units[i]
			info.arg1 = units[i]
			info.func = GraphPowerSelect
			info.justifyH = "CENTER" 
		end
		table.sort(BWInterfaceFrame.tab.tabs[8].graphicsTab.dropDown.List,function(a,b)return a.text < b.text end)
	end)

	
	
	
	---- Segments
	tab = BWInterfaceFrame.tab.tabs[9]
	tabName = BWInterfaceFrame_Name.."SegmentsTab"

	BWInterfaceFrame.tab.tabs[3].timeSegments = {}
	BWInterfaceFrame.timeLineFrame.timeLine.timeSegments = {}
	local function CreateBuffSegmentBack(i)
		if not BWInterfaceFrame.tab.tabs[3].timeSegments[i] then
		  	BWInterfaceFrame.tab.tabs[3].timeSegments[i] = CreateFrame("Frame",nil,BWInterfaceFrame.tab.tabs[3])
			BWInterfaceFrame.tab.tabs[3].timeSegments[i].texture = BWInterfaceFrame.tab.tabs[3].timeSegments[i]:CreateTexture(nil, "BACKGROUND",0,-5)
			BWInterfaceFrame.tab.tabs[3].timeSegments[i].texture:SetTexture(1, 1, 0.5, 0.2)
			BWInterfaceFrame.tab.tabs[3].timeSegments[i].texture:SetAllPoints()
		end
		if not BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i] then
			BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i] = BWInterfaceFrame.timeLineFrame.timeLine:CreateTexture(nil, "BACKGROUND",nil,1)
			BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:SetTexture("Interface\\AddOns\\ExRT\\media\\bar9.tga")
			BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:SetVertexColor(0.8, 0.8, 0.8, 1)
		end
	end
	
	local function Segments_UpdateBuffAndTimeLine()
		local count = 0
		for i=1,#BWInterfaceFrame.tab.tabs[9].segmentsList.L do
			if BWInterfaceFrame.tab.tabs[9].segmentsList.C[i] then
				count = count + 1
			end
		end

		if count == #BWInterfaceFrame.tab.tabs[9].segmentsList.L then
			for i=1,#BWInterfaceFrame.tab.tabs[3].timeSegments do
				BWInterfaceFrame.tab.tabs[3].timeSegments[i]:Hide()
			end
			for i=1,#BWInterfaceFrame.timeLineFrame.timeLine.timeSegments do
				BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:Hide()
			end
		else
			local fightDuration = (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart)
			for i=1,#BWInterfaceFrame.tab.tabs[9].segmentsList.L do
				CreateBuffSegmentBack(i)
				if BWInterfaceFrame.tab.tabs[9].segmentsList.C[i] then
					local timeStart = max(module.db.data[module.db.nowNum].fight[i].timeEx - module.db.data[module.db.nowNum].encounterStart,0)
					local timeEnd = max(module.db.data[module.db.nowNum].fight[i+1] and (module.db.data[module.db.nowNum].fight[i+1].timeEx - module.db.data[module.db.nowNum].encounterStart) or fightDuration,0)
					local startPos = buffsNameWidth+timeStart/fightDuration*buffsWorkWidth
					local endPos = buffsNameWidth+timeEnd/fightDuration*buffsWorkWidth
					BWInterfaceFrame.tab.tabs[3].timeSegments[i]:SetPoint("TOPLEFT",startPos,-42)
					BWInterfaceFrame.tab.tabs[3].timeSegments[i]:SetSize(max(endPos-startPos,0.5),buffsTotalLines * 18 + 14)
					BWInterfaceFrame.tab.tabs[3].timeSegments[i]:Show()
					
					BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:Hide()
				else
					BWInterfaceFrame.tab.tabs[3].timeSegments[i]:Hide()
					
					local timeStart = max(module.db.data[module.db.nowNum].fight[i].timeEx - module.db.data[module.db.nowNum].encounterStart,0)
					local timeEnd = max(module.db.data[module.db.nowNum].fight[i+1] and (module.db.data[module.db.nowNum].fight[i+1].timeEx - module.db.data[module.db.nowNum].encounterStart) or fightDuration,0)
					local tlWidth = BWInterfaceFrame.timeLineFrame.timeLine:GetWidth()
					local startPos = timeStart/fightDuration*tlWidth
					local endPos = timeEnd/fightDuration*tlWidth
					BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:SetPoint("TOPLEFT",startPos,0)
					BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:SetSize(max(endPos-startPos,0.5),BWInterfaceFrame.timeLineFrame.timeLine:GetHeight())
					BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:Show()
				end
			end
			for i=(#BWInterfaceFrame.tab.tabs[9].segmentsList.L + 1),#BWInterfaceFrame.tab.tabs[3].timeSegments do
				BWInterfaceFrame.tab.tabs[3].timeSegments[i]:Hide()
			end
			for i=(#BWInterfaceFrame.tab.tabs[9].segmentsList.L + 1),#BWInterfaceFrame.timeLineFrame.timeLine.timeSegments do
				BWInterfaceFrame.timeLineFrame.timeLine.timeSegments[i]:Hide()
			end
		end
	end
	
	tab.segmentsText = ExRT.lib.CreateText(tab,240,15,nil,17,-53,"LEFT","TOP",nil,11,ExRT.L.BossWatcherSegments..":",nil,1,1,1,1)
	tab.segmentsList = ExRT.lib.CreateScrollCheckList(tabName.."SegmentsList",tab,nil,7,-70,340,10)
	tab.segmentsList.Update()
	function tab.segmentsList:ValueChanged()
		ClearAndReloadData(true)
		local count = 0
		for i=1,#self.L do
			if self.C[i] then
				AddSegmentToData(i)
				count = count + 1
			end
		end
		module.db.lastFightID = module.db.lastFightID + 1
		module.db.data[module.db.nowNum].fightID = module.db.lastFightID
		BWInterfaceFrame.nowFightID = module.db.lastFightID
		BWInterfaceFrame.tab.tabs[9].lastFightID = module.db.lastFightID
		Segments_UpdateBuffAndTimeLine()
	end
	function tab.segmentsList:HoverListValue(isHover,index)
		if not isHover then
			GameTooltip_Hide()
		else
			local scrollPos = ExRT.mds.Round(BWInterfaceFrame.tab.tabs[9].segmentsList.ScrollBar:GetValue())
			local textObj = BWInterfaceFrame.tab.tabs[9].segmentsList.List[index - scrollPos + 1].text
			if textObj:IsTruncated() then
				GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
				GameTooltip:AddLine( textObj:GetText() )
				GameTooltip:Show()
			end
		end
	end	
	
	tab.segmentsButtonAll = ExRT.lib.CreateButton(nil,tab,130,18,nil,80,-50,ExRT.L.BossWatcherSegmentSelectAll)
	tab.segmentsButtonAll:SetScript("OnClick",function ()
		for i=1,#BWInterfaceFrame.tab.tabs[9].segmentsList.L do
			BWInterfaceFrame.tab.tabs[9].segmentsList.C[i] = true
		end
		BWInterfaceFrame.tab.tabs[9].segmentsList.Update()
		BWInterfaceFrame.tab.tabs[9].segmentsList.ValueChanged(BWInterfaceFrame.tab.tabs[9].segmentsList)
	end)
	tab.segmentsButtonNone = ExRT.lib.CreateButton(nil,tab,130,18,nil,215,-50,ExRT.L.BossWatcherSegmentSelectNothing)
	tab.segmentsButtonNone:SetScript("OnClick",function ()
		for i=1,#BWInterfaceFrame.tab.tabs[9].segmentsList.L do
			BWInterfaceFrame.tab.tabs[9].segmentsList.C[i] = nil
		end
		BWInterfaceFrame.tab.tabs[9].segmentsList.Update()
		BWInterfaceFrame.tab.tabs[9].segmentsList.ValueChanged(BWInterfaceFrame.tab.tabs[9].segmentsList)
	end)
	
	tab.segmentsTooltip = ExRT.lib.CreateText(tab,395,250,nil,357,-50,"LEFT","TOP",nil,12,ExRT.L.BossWatcherSegmentsTooltip,nil,nil,nil,nil,1)
	
	tab.segmentsPreSetList = {
		{ExRT.L.BossWatcherSegmentClear,},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss1,143469,"CHAT_MSG_RAID_BOSS_EMOTE"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss2,143546,"SPELL_AURA_APPLIED",143546,"SPELL_AURA_REMOVED",143812,"SPELL_AURA_APPLIED",143812,"SPELL_AURA_REMOVED",143955,"SPELL_AURA_APPLIED",143955,"SPELL_AURA_REMOVED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss4,144832,"UNIT_SPELLCAST_SUCCEEDED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss6,144483,"SPELL_AURA_APPLIED",144483,"SPELL_AURA_REMOVED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss7,144302,"UNIT_SPELLCAST_SUCCEEDED",},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss8,143593,"SPELL_AURA_APPLIED",143589,"SPELL_AURA_APPLIED",143594,"SPELL_AURA_APPLIED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss9,142842,"UNIT_SPELLCAST_SUCCEEDED",142879,"SPELL_AURA_APPLIED",142879,"SPELL_AURA_REMOVED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss11,143440,"SPELL_AURA_APPLIED",143440,"SPELL_AURA_REMOVED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss13,71161,"UNIT_DIED",71157,"UNIT_DIED",71156,"UNIT_DIED",71155,"UNIT_DIED",71160,"UNIT_DIED",71154,"UNIT_DIED",71152,"UNIT_DIED",71158,"UNIT_DIED",71153,"UNIT_DIED"},
		{ExRT.L.sooitemst16.." - "..ExRT.L.sooitemssooboss14,145235,"UNIT_SPELLCAST_SUCCEEDED",144956,"UNIT_SPELLCAST_SUCCEEDED",146984,"UNIT_SPELLCAST_SUCCEEDED"},
	}
	local function SegmentsSetPreSet(self)
		local id = self.id
		for i=2,27,2 do
			local j = i / 2
			VExRT.BossWatcher.autoSegments[j] = VExRT.BossWatcher.autoSegments[j] or {}
		
			BWInterfaceFrame.tab.tabs[9].autoSegments[j]:SetText( BWInterfaceFrame.tab.tabs[9].segmentsPreSetList[id][i] or "" )
			VExRT.BossWatcher.autoSegments[j][1] = tonumber( BWInterfaceFrame.tab.tabs[9].segmentsPreSetList[id][i] or "" )
			
			local event = BWInterfaceFrame.tab.tabs[9].segmentsPreSetList[id][i+1]
			VExRT.BossWatcher.autoSegments[j][2] = event
			event = event or "UNIT_SPELLCAST_SUCCEEDED"
			local slider = BWInterfaceFrame.tab.tabs[9].autoSegments[j].slider
			local inList = ExRT.mds.table_find(slider.List,event,2)
			slider.text:SetText( slider.List[inList][1] )
			slider.tooltipText = slider.List[inList][2]
			slider.selected = inList
		end
		UpdateNewSegmentEvents()
		BWInterfaceFrame.tab.tabs[9].segmentsPreSet.HideByTimer(BWInterfaceFrame.tab.tabs[9].segmentsPreSet)
	end
	tab.segmentsPreSet = ExRT.lib.CreateListFrame(tabName.."SegmentsPreSet",tab,350,#tab.segmentsPreSetList,"RIGHT",nil,810,-225,ExRT.L.BossWatcherSegmentPreSet..":",SegmentsSetPreSet)
	local function SegmentsPreSetButtonEnter(self)
		local id = self.id
		local sList = {}
		for i=2,21,2 do
			local spellID = BWInterfaceFrame.tab.tabs[9].segmentsPreSetList[id][i]
			local event = BWInterfaceFrame.tab.tabs[9].segmentsPreSetList[id][i+1]
			if spellID and event then
				local sID,_,sT=GetSpellInfo(spellID)
				if sID and event ~= "UNIT_DIED" then
					table.insert(sList,"|cffffffff"..module.db.autoSegmentEventsL[event].." |T"..sT..":0|t"..sID.."|r")
				elseif event == "UNIT_DIED" then
					table.insert(sList,"|cffffffff"..module.db.autoSegmentEventsL[event].." "..spellID.."|r")
				end
			end
		end
		if #sList > 0 then
			ExRT.lib.TooltipShow(self,"ANCHOR_LEFT",ExRT.L.cd2fastSetupTooltip..":",unpack(sList))
		end
	end
	for i=1,#tab.segmentsPreSetList do
		tab.segmentsPreSet.buttons[i].text:SetText(tab.segmentsPreSetList[i][1])
		tab.segmentsPreSet.buttons[i]:SetScript("OnEnter", SegmentsPreSetButtonEnter)
		tab.segmentsPreSet.buttons[i]:SetScript("OnLeave", ExRT.lib.TooltipHide)
	end

	local Segments_SliderList = {}
	for i,event in ipairs(module.db.autoSegmentEvents) do
		Segments_SliderList[i] = {module.db.autoSegmentEventsL[event],event}
	end
	
	local function Segments_SliderBoxFunc(self)
		local i = self._i
		local selected = self.selected
		if not VExRT.BossWatcher.autoSegments[i] then
			VExRT.BossWatcher.autoSegments[i] = {}
		end
		VExRT.BossWatcher.autoSegments[i][2] = Segments_SliderList[selected][2]	
		UpdateNewSegmentEvents()  
	end
	
	local function EditSliderBoxOnEnterEditBox(self)
		local i = self._i
		local sID = self:GetText()
		sID = tonumber(sID)
		GameTooltip:SetOwner(self, "ANCHOR_LEFT")
		GameTooltip:SetText(ExRT.L.BossWatcherSegmentsSpellTooltip)
		if VExRT.BossWatcher.autoSegments[i] and VExRT.BossWatcher.autoSegments[i][2] ~= "UNIT_DIED" and sID and GetSpellInfo(sID) then
			GameTooltip:AddLine(ExRT.L.BossWatcherSegmentNowTooltip)
			GameTooltip:AddSpellByID(sID)
		end			
		GameTooltip:Show()
	end
	
	local function AutoSegmentsEditBoxOnTextChanged(self,isUser)
		if not isUser then
			return
		end
		VExRT.BossWatcher.autoSegments[self._i] = VExRT.BossWatcher.autoSegments[self._i] or {}
		VExRT.BossWatcher.autoSegments[self._i][1] = tonumber(self:GetText())
		VExRT.BossWatcher.autoSegments[self._i][2] = VExRT.BossWatcher.autoSegments[self._i][2] or "UNIT_SPELLCAST_SUCCEEDED" 
		UpdateNewSegmentEvents()
	end

	tab.autoSegments = {}
	for i=1,13 do
		tab.autoSegments[i] = ExRT.lib.CreateEditBox(nil,tab,335,24,nil,10,-250-(i-1)*24,ExRT.L.BossWatcherSegmentsSpellTooltip,6,true,nil,VExRT.BossWatcher.autoSegments[i] and VExRT.BossWatcher.autoSegments[i][1] or "")
		tab.autoSegments[i]:SetScript("OnTextChanged",AutoSegmentsEditBoxOnTextChanged)
		tab.autoSegments[i]._i = i
		tab.autoSegments[i]:SetScript("OnEnter",EditSliderBoxOnEnterEditBox)

		local selected = 1
		if VExRT.BossWatcher.autoSegments[i] and VExRT.BossWatcher.autoSegments[i][2] then
			selected = ExRT.mds.table_find(module.db.autoSegmentEvents,VExRT.BossWatcher.autoSegments[i][2]) or 1
		end
		tab.autoSegments[i].slider = ExRT.lib.CreateSliderBox(tab,460,24,356,-250-(i-1)*24,Segments_SliderList,selected)
		tab.autoSegments[i].slider.func = Segments_SliderBoxFunc
		tab.autoSegments[i].slider._i = i
	end
	
	local function UpdateSegmentsPage()
		wipe(BWInterfaceFrame.tab.tabs[9].segmentsList.L)
		wipe(BWInterfaceFrame.tab.tabs[9].segmentsList.C)
		for i=1,#module.db.data[module.db.nowNum].fight do
			local time = module.db.data[module.db.nowNum].fight[i].time - module.db.data[module.db.nowNum].encounterStartGlobal
			local name = module.db.data[module.db.nowNum].fight[i].name
			local subEvent = module.db.data[module.db.nowNum].fight[i].subEvent
			if name then
				local event = name
				name = " "..(module.db.segmentsLNames[name] or name)
				if subEvent then
					name = name.." <"..subEvent..">"
					if (event == "UNIT_SPELLCAST_SUCCEEDED" or event == "SPELL_AURA_REMOVED" or event == "SPELL_AURA_APPLIED") and tonumber(subEvent) then
						local spellName = GetSpellInfo( tonumber(subEvent) )
						if spellName then
							name = name .. ": " ..spellName
						end
					elseif event == "UNIT_DIED" and tonumber(subEvent) then
						local mobID = tonumber(subEvent)
						for guid,mobName in pairs(module.db.data[module.db.nowNum].guids) do
							if string.len(guid) > 3 then
								local thisID = ExRT.mds.GUIDtoID(guid)
								if thisID == mobID and mobName then
									name = name .. ": " ..mobName
									break
								end
							end
						end
					end
				end
			end
			BWInterfaceFrame.tab.tabs[9].segmentsList.L[i] = date("%M:%S", max(time,0)) .. (name or "")
			BWInterfaceFrame.tab.tabs[9].segmentsList.C[i] = true
		end
		BWInterfaceFrame.tab.tabs[9].segmentsList.Update()
	end
	
	tab:SetScript("OnShow",function (self)
		BWInterfaceFrame.timeLineFrame:ClearAllPoints()
		BWInterfaceFrame.timeLineFrame:SetPoint("TOP",self,"TOP",0,-10)
		BWInterfaceFrame.timeLineFrame:Show()
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdateSegmentsPage()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	tab:SetScript("OnHide",function (self)
		BWInterfaceFrame.timeLineFrame:Hide()
	end)
	
	
	
	
	---- Interrupt & dispels
	tab = BWInterfaceFrame.tab.tabs[7]
	tabName = BWInterfaceFrame_Name.."InterruptTab"

	tab.tabs = ExRT.lib.CreateTabFrame(tabName.."Tabs",tab,825,485,0,0,2,1,ExRT.L.BossWatcherInterrupts,ExRT.L.BossWatcherDispels)
	ExRT.lib.SetPoint(tab.tabs,"TOP",0,-100)
	
	local Intterupt_Type = 1
	local UpdateInterruptPage = nil
	
	function tab.tabs:buttonAdditionalFunc()
		UpdateInterruptPage()
	end
	
	tab.bySource = CreateFrame("CheckButton",tabName.."ChkBySource",tab.tabs,"UIRadioButtonTemplate")  
	tab.bySource:SetPoint("TOPLEFT", 10, -10)
	tab.bySource.text:SetText(ExRT.L.BossWatcherBySource)
	tab.bySource:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			BWInterfaceFrame.tab.tabs[7].byTarget:SetChecked(false)
			BWInterfaceFrame.tab.tabs[7].bySpell:SetChecked(false)
			Intterupt_Type = 1
		end
		UpdateInterruptPage()
	end)
	tab.byTarget = CreateFrame("CheckButton",tabName.."ChkByTarget",tab.tabs,"UIRadioButtonTemplate")  
	tab.byTarget:SetPoint("TOPLEFT", 10, -25)
	tab.byTarget.text:SetText(ExRT.L.BossWatcherByTarget)
	tab.byTarget:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			BWInterfaceFrame.tab.tabs[7].bySource:SetChecked(false)
			BWInterfaceFrame.tab.tabs[7].bySpell:SetChecked(false)
			Intterupt_Type = 2
		end
		UpdateInterruptPage()
	end)
	tab.bySpell = CreateFrame("CheckButton",tabName.."ChkBySpell",tab.tabs,"UIRadioButtonTemplate")  
	tab.bySpell:SetPoint("TOPLEFT", 10, -40)
	tab.bySpell.text:SetText(ExRT.L.BossWatcherBySpell)
	tab.bySpell:SetScript("OnClick", function(self,event) 
		if self:GetChecked() then
			BWInterfaceFrame.tab.tabs[7].byTarget:SetChecked(false)
			BWInterfaceFrame.tab.tabs[7].bySource:SetChecked(false)
			Intterupt_Type = 3
		end
		UpdateInterruptPage()
	end)
	tab.bySource:SetChecked(true)
	
	tab.list = ExRT.lib.CreateScrollList(tabName.."List",tab.tabs,"TOPLEFT",5,-55,180,26)
	tab.list.GUIDs = {}
	
	tab.events = ExRT.lib.CreateScrollList(tabName.."List",tab.tabs,"TOPLEFT",185,-7,634,29)
	tab.events.DATA = {}
	
	function tab.list:SetListValue(index)
		local filter = BWInterfaceFrame.tab.tabs[7].list.GUIDs[index]
		local isInterrupt = BWInterfaceFrame.tab.tabs[7].tabs.selected == 1
		local workTable = module.db.nowData.interrupts
		if not isInterrupt then
			workTable = module.db.nowData.dispels
		end
		local data = {}
		table.wipe(BWInterfaceFrame.tab.tabs[7].events.L)
		table.wipe(BWInterfaceFrame.tab.tabs[7].events.DATA)
		for i,line in ipairs(workTable) do
			local isOkay = false
			if (Intterupt_Type == 1 and (not filter or line[1] == filter)) or
			   (Intterupt_Type == 2 and (not filter or line[2] == filter)) or
			   (Intterupt_Type == 3 and (not filter or line[4] == filter)) then
				isOkay = true
			end
			if isOkay then
				local spellSourceName,_,spellSourceTexture = GetSpellInfo(line[3])
				local spellDestName,_,spellDestTexture = GetSpellInfo(line[4])
				local dispelOrInterrupt = ExRT.L.BossWatcherDispelText
				if isInterrupt then
					dispelOrInterrupt = ExRT.L.BossWatcherInterruptText
				end
				BWInterfaceFrame.tab.tabs[7].events.L[#BWInterfaceFrame.tab.tabs[7].events.L + 1] = "[".. date("%M:%S", timestampToFightTime(line[5])).."] |c".. ExRT.mds.classColorByGUID(line[1]) .. GetGUID(line[1]) .. GUIDtoText(" (%s)",line[1]) .. "|r "..dispelOrInterrupt.." |c" ..  ExRT.mds.classColorByGUID(line[2]).. GetGUID(line[2]) .. "'s" .. GUIDtoText(" (%s)",line[2]) .. "|r |Hspell:" .. (line[4] or 0) .. "|h" .. format("%s%s",spellDestTexture and "|T"..spellDestTexture..":0|t " or "",spellDestName or "???") .. "|h "..ExRT.L.BossWatcherByText.." |Hspell:" .. (line[3] or 0) .. "|h" .. format("%s%s",spellSourceTexture and "|T"..spellSourceTexture..":0|t " or "",spellSourceName or "???") .. "|h"
				BWInterfaceFrame.tab.tabs[7].events.DATA[#BWInterfaceFrame.tab.tabs[7].events.L] = line
			end
		end
		BWInterfaceFrame.tab.tabs[7].events.Update()
	end
	function tab.events:SetListValue(index)
		self.selected = nil
		self.Update()
	end
	function tab.events:HoverListValue(isHover,index)
		if not isHover then
			GameTooltip_Hide()
			ExRT.lib.HideAdditionalTooltips()
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Hide()
		else
			local scrollPos = ExRT.mds.Round(BWInterfaceFrame.tab.tabs[7].events.ScrollBar:GetValue())
			local this = BWInterfaceFrame.tab.tabs[7].events.List[index - scrollPos + 1]
			local line = BWInterfaceFrame.tab.tabs[7].events.DATA[index]
			
			GameTooltip:SetOwner(this or self,"ANCHOR_BOTTOMLEFT")
			GameTooltip:SetHyperlink("spell:"..line[4])
			GameTooltip:Show()
			
			ExRT.lib.AdditionalTooltip("spell:"..line[3])
			
			if this.text:IsTruncated() then
				ExRT.lib.AdditionalTooltip(nil,{this.text:GetText()})
			end
			
			local _time = timestampToFightTime(line[5]) / ( module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart )
			
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:SetPoint("TOPLEFT",BWInterfaceFrame.timeLineFrame.timeLine,"BOTTOMLEFT",BWInterfaceFrame.timeLineFrame.width*_time,0)
			BWInterfaceFrame.timeLineFrame.timeLine.arrow:Show()
		end
	end

	function UpdateInterruptPage()
		table.wipe(BWInterfaceFrame.tab.tabs[7].list.L)
		table.wipe(BWInterfaceFrame.tab.tabs[7].list.GUIDs)
		table.wipe(BWInterfaceFrame.tab.tabs[7].events.L)
		
		local workTable = module.db.nowData.interrupts
		if BWInterfaceFrame.tab.tabs[7].tabs.selected == 2 then
			workTable = module.db.nowData.dispels
		end
		local data = {}
		for i,line in ipairs(workTable) do
			if Intterupt_Type == 1 then
				if not ExRT.mds.table_find(data,line[1]) then
					data[#data + 1] = line[1]
				end
			elseif Intterupt_Type == 2 then
				if not ExRT.mds.table_find(data,line[2]) then
					data[#data + 1] = line[2]
				end
			else
				if not ExRT.mds.table_find(data,line[4]) then
					data[#data + 1] = line[4]
				end
			end
		end
		local data2 = {}
		for i=1,#data do
			if Intterupt_Type ~= 3 then
				data2[i] = {data[i],GetGUID(data[i])}
			else
				local spellName = GetSpellInfo(data[i])
				data2[i] = {data[i],spellName}
			end
		end
		sort(data2,function(a,b)return a[2]>b[2] end)
		for i=1,#data2 do
			BWInterfaceFrame.tab.tabs[7].list.L[i+1] = data2[i][2]
			BWInterfaceFrame.tab.tabs[7].list.GUIDs[i+1] = data2[i][1]
		end
		BWInterfaceFrame.tab.tabs[7].list.L[1] = ExRT.L.BossWatcherAll
		
		BWInterfaceFrame.tab.tabs[7].list.selected = nil
		
		BWInterfaceFrame.tab.tabs[7].list.Update()
		BWInterfaceFrame.tab.tabs[7].events.Update()
	end

	tab:SetScript("OnShow",function (self)
		BWInterfaceFrame.timeLineFrame:ClearAllPoints()
		BWInterfaceFrame.timeLineFrame:SetPoint("TOP",self,"TOP",0,-10)
		BWInterfaceFrame.timeLineFrame:Show()
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			UpdateInterruptPage()
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	tab:SetScript("OnHide",function (self)
		BWInterfaceFrame.timeLineFrame:Hide()
	end)


	
	
	---- Heal
	tab = BWInterfaceFrame.tab.tabs[2]
	tabName = BWInterfaceFrame_Name.."HealingTab"
	
	local HsourceVar,HdestVar = nil
	local HealingTab_SetLine = nil
	local HealingShowOverheal = false
	local Healing_Last_Func = nil
	local Healing_Last_doEnemy = nil
	
	local function HealingTab_UpdateLinesPlayers(doEnemy)
		Healing_Last_Func = HealingTab_UpdateLinesPlayers
		Healing_Last_doEnemy = doEnemy
		local heal = {}
		local total = 0
		local totalOver = 0
		for sourceGUID,sourceData in pairs(module.db.nowData.heal) do
			local owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
			if owner then
				sourceGUID = owner
			end
			if not HsourceVar or HsourceVar == sourceGUID then
				for destGUID,destData in pairs(sourceData) do
					local isEnemy = not ExRT.mds.UnitIsFriendlyByUnitFlag2(module.db.data[module.db.nowNum].reaction[destGUID])
					if not HdestVar or HdestVar == destGUID then
						if (isEnemy and doEnemy) or (not isEnemy and not doEnemy) then
							local inDamagePos = ExRT.mds.table_find(heal,sourceGUID,1)
							if not inDamagePos then
								inDamagePos = #heal + 1
								heal[inDamagePos] = {sourceGUID,0,0,0,0,0,0}
							end
							for spellID,spellAmount in pairs(destData) do
								heal[inDamagePos][2] = heal[inDamagePos][2] + spellAmount.amount - spellAmount.over + spellAmount.absorbed
								heal[inDamagePos][3] = heal[inDamagePos][3] + spellAmount.amount 						--total
								heal[inDamagePos][4] = heal[inDamagePos][4] + spellAmount.over 							--overheal
								heal[inDamagePos][5] = heal[inDamagePos][5] + spellAmount.absorbed 						--absorbed
								if HealingShowOverheal then
									heal[inDamagePos][6] = heal[inDamagePos][6] + spellAmount.crit
									heal[inDamagePos][7] = heal[inDamagePos][7] + spellAmount.ms
								else
									heal[inDamagePos][6] = heal[inDamagePos][6] + spellAmount.crit - spellAmount.critover
									heal[inDamagePos][7] = heal[inDamagePos][7] + spellAmount.ms - spellAmount.msover					
								end
								total = total + spellAmount.amount - spellAmount.over + spellAmount.absorbed
								totalOver = totalOver + spellAmount.over
							end
						end
					end
				end
			end
		end
		local totalIsFull = 1
		total = max(total,1)
		if total == 1 and #heal == 0 then
			total = 0
			totalIsFull = 0
		end
		local _max = nil
		wipe(reportData[2])
		reportData[2][1] = (HsourceVar and GetGUID(HsourceVar) or ExRT.L.BossWatcherAllSources).." > "..(HdestVar and GetGUID(HdestVar) or ExRT.L.BossWatcherAllTargets)
		if not HealingShowOverheal then
			reportData[2][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total)
			sort(heal,function(a,b) return a[2]>b[2] end)
			_max = heal[1] and heal[1][2] or 0
			HealingTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total,total / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart))
		else
			reportData[2][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total + totalOver)
			sort(heal,function(a,b) return (a[2]+a[4])>(b[2]+b[4]) end)
			_max = heal[1] and (heal[1][2]+heal[1][4]) or 0
			HealingTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total + totalOver,(total + totalOver) / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,nil,nil,nil,totalOver / max(total + totalOver,1))
		end
		for i=1,#heal do
			local class = nil
			if heal[i][1] and heal[i][1] ~= "" then
				class = select(2,GetPlayerInfoByGUID(heal[i][1]))
			end
			local icon = ""
			if class and CLASS_ICON_TCOORDS[class] then
				icon = {"Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES",unpack(CLASS_ICON_TCOORDS[class])}
			end
			local tooltipData = {GetGUID(heal[i][1]),
				{ExRT.L.BossWatcherHealTooltipOver,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][4]),heal[i][4]/max(heal[i][2]+heal[i][4],1)*100)},
				{ExRT.L.BossWatcherHealTooltipAbsorbed,ExRT.mds.shortNumber(heal[i][5])},
				{ExRT.L.BossWatcherHealTooltipTotal,ExRT.mds.shortNumber(heal[i][3])},
				{" "," "},
				{ExRT.L.BossWatcherHealTooltipFromCrit,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][6]),heal[i][6]/max(1,heal[i][2]+(HealingShowOverheal and heal[i][4] or 0))*100)},
				{ExRT.L.BossWatcherHealTooltipFromMs,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][7]),heal[i][7]/max(1,heal[i][2]+(HealingShowOverheal and heal[i][4] or 0))*100)},
			}
			if not HealingShowOverheal then
				HealingTab_SetLine(i+1,icon,GetGUID(heal[i][1])..GUIDtoText(" [%s]",heal[i][1]),heal[i][2]/total,heal[i][2]/max(_max,1),heal[i][2],heal[i][2]/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,heal[i][1],doEnemy,nil,tooltipData)
				reportData[2][#reportData[2]+1] = i..". "..GetGUID(heal[i][1]).." - "..ExRT.mds.shortNumber(heal[i][2])
			else
				HealingTab_SetLine(i+1,icon,GetGUID(heal[i][1])..GUIDtoText(" [%s]",heal[i][1]),(heal[i][2]+heal[i][4])/(total+totalOver),(heal[i][2]+heal[i][4])/max(_max,1),(heal[i][2]+heal[i][4]),(heal[i][2]+heal[i][4])/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,heal[i][1],doEnemy,nil,tooltipData,nil,heal[i][4] / max(heal[i][2]+heal[i][4],1))			
				reportData[2][#reportData[2]+1] = i..". "..GetGUID(heal[i][1]).." - "..ExRT.mds.shortNumber(heal[i][2]+heal[i][4])
			end
		end
		for i=#heal+2,#BWInterfaceFrame.tab.tabs[2].lines do
			BWInterfaceFrame.tab.tabs[2].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[2].scroll.SetNewHeight(BWInterfaceFrame.tab.tabs[2].scroll,(#heal+1) * 20)
	end
	local function HealingTab_UpdateLinesSpell(doEnemy)
		Healing_Last_Func = HealingTab_UpdateLinesSpell
		Healing_Last_doEnemy = doEnemy
		local heal = {}
		local total = 0
		local totalOver = 0
		for sourceGUID,sourceData in pairs(module.db.nowData.heal) do
			local owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
			if owner then
				sourceGUID = owner
			end
			if not HsourceVar or HsourceVar == sourceGUID then
				for destGUID,destData in pairs(sourceData) do
					local isEnemy = not ExRT.mds.UnitIsFriendlyByUnitFlag2(module.db.data[module.db.nowNum].reaction[destGUID])
					if not HdestVar or HdestVar == destGUID then
						if (isEnemy and doEnemy) or (not isEnemy and not doEnemy) then
							for spellID,spellAmount in pairs(destData) do
								if owner then
									spellID = -spellID
								end							
								local inDamagePos = ExRT.mds.table_find(heal,spellID,1)
								if not inDamagePos then
									inDamagePos = #heal + 1
									heal[inDamagePos] = {spellID,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
								end
								heal[inDamagePos][2] = heal[inDamagePos][2] + spellAmount.amount - spellAmount.over + spellAmount.absorbed	--ef
								heal[inDamagePos][3] = heal[inDamagePos][3] + spellAmount.amount 						--total
								heal[inDamagePos][4] = heal[inDamagePos][4] + spellAmount.over 							--overheal
								heal[inDamagePos][5] = heal[inDamagePos][5] + spellAmount.absorbed 						--absorbed
								heal[inDamagePos][6] = heal[inDamagePos][6] + spellAmount.count 						--count
								heal[inDamagePos][7] = heal[inDamagePos][7] + spellAmount.crit 							--crit
								heal[inDamagePos][8] = heal[inDamagePos][8] + spellAmount.critcount						--crit-count
								heal[inDamagePos][9] = max(heal[inDamagePos][9],spellAmount.critmax)						--crit-max
								heal[inDamagePos][10] = heal[inDamagePos][10] + spellAmount.ms							--ms
								heal[inDamagePos][11] = heal[inDamagePos][11] + spellAmount.mscount						--ms-count
								heal[inDamagePos][12] = max(heal[inDamagePos][12],spellAmount.msmax) 						--ms-max
								heal[inDamagePos][13] = max(heal[inDamagePos][13],spellAmount.hitmax)						--hit-max
								heal[inDamagePos][14] = heal[inDamagePos][14] + spellAmount.critover						--crit overheal
								heal[inDamagePos][15] = heal[inDamagePos][15] + spellAmount.msover						--ms overheal
								total = total + spellAmount.amount - spellAmount.over + spellAmount.absorbed
								totalOver = totalOver + spellAmount.over
							end
						end
					end
				end
			end
		end
		local totalIsFull = 1
		total = max(total,1)
		if total == 1 and #heal == 0 then
			total = 0
			totalIsFull = 0
		end
		local _max = nil
		wipe(reportData[2])
		reportData[2][1] = (HsourceVar and GetGUID(HsourceVar) or ExRT.L.BossWatcherAllSources).." > "..(HdestVar and GetGUID(HdestVar) or ExRT.L.BossWatcherAllTargets)
		if not HealingShowOverheal then
			reportData[2][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total)
			sort(heal,function(a,b) return a[2]>b[2] end)
			_max = heal[1] and heal[1][2] or 0
			HealingTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total,total / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart))
		else
			reportData[2][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total + totalOver)
			sort(heal,function(a,b) return (a[2]+a[4])>(b[2]+b[4]) end)
			_max = heal[1] and (heal[1][2]+heal[1][4]) or 0
			HealingTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total + totalOver,(total + totalOver) / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,nil,nil,nil,totalOver / max(total + totalOver,1))		
		end
		for i=1,#heal do
			local isPetAbility = heal[i][1] < 0
			if isPetAbility then
				heal[i][1] = -heal[i][1]
			end
			local spellName,_,spellIcon = GetSpellInfo(heal[i][1])
			if isPetAbility then
				spellName = ExRT.L.BossWatcherPetText..": "..spellName
			end
			local tooltipData = {spellName,
				{ExRT.L.BossWatcherHealTooltipCount,heal[i][6]},
				{ExRT.L.BossWatcherHealTooltipHitMax,heal[i][13]},
				{ExRT.L.BossWatcherHealTooltipHitMid,ExRT.mds.Round(max(heal[i][3]-heal[i][10]-heal[i][7]-(heal[i][4]-heal[i][14]-heal[i][15]),0)/max(heal[i][6]-heal[i][8]-heal[i][11],1))},
				{ExRT.L.BossWatcherHealTooltipCritCount,format("%d (%.1f%%)",heal[i][8],heal[i][8]/heal[i][6]*100)},
				{ExRT.L.BossWatcherHealTooltipCritAmount,ExRT.mds.shortNumber(heal[i][7]-heal[i][14])},
				{ExRT.L.BossWatcherHealTooltipCritMax,heal[i][9]},
				{ExRT.L.BossWatcherHealTooltipCritMid,ExRT.mds.Round((heal[i][7]-heal[i][14])/max(heal[i][8],1))},
				{ExRT.L.BossWatcherHealTooltipMsCount,format("%d (%.1f%%)",heal[i][11],heal[i][11]/heal[i][6]*100)},
				{ExRT.L.BossWatcherHealTooltipMsAmount,ExRT.mds.shortNumber(heal[i][10]-heal[i][15])},
				{ExRT.L.BossWatcherHealTooltipMsMax,heal[i][12]},
				{ExRT.L.BossWatcherHealTooltipMsMid,ExRT.mds.Round((heal[i][10]-heal[i][15])/max(heal[i][11],1))},
				{ExRT.L.BossWatcherHealTooltipOver,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][4]),heal[i][4]/max(heal[i][2]+heal[i][4],1)*100)},
				{ExRT.L.BossWatcherHealTooltipAbsorbed,ExRT.mds.shortNumber(heal[i][5])},
				{ExRT.L.BossWatcherHealTooltipTotal,ExRT.mds.shortNumber(heal[i][3])},
			}
			local school = module.db.spellsSchool[ heal[i][1] ] or 0
			if not HealingShowOverheal then
				HealingTab_SetLine(i+1,spellIcon,spellName,heal[i][2]/total,heal[i][2]/max(_max,1),heal[i][2],heal[i][2]/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,"spell:"..heal[i][1],tooltipData,school)
				reportData[2][#reportData[2]+1] = i..". "..(isPetAbility and ExRT.L.BossWatcherPetText..": " or "")..GetSpellLink(heal[i][1]).." - "..ExRT.mds.shortNumber(heal[i][2])
			else
				HealingTab_SetLine(i+1,spellIcon,spellName,(heal[i][2]+heal[i][4])/(total+totalOver),(heal[i][2]+heal[i][4])/max(_max,1),(heal[i][2]+heal[i][4]),(heal[i][2]+heal[i][4])/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,"spell:"..heal[i][1],tooltipData,school,heal[i][4] / max(heal[i][2]+heal[i][4],1))			
				reportData[2][#reportData[2]+1] = i..". "..(isPetAbility and ExRT.L.BossWatcherPetText..": " or "")..GetSpellLink(heal[i][1]).." - "..ExRT.mds.shortNumber(heal[i][2]+heal[i][4])
			end
		end
		for i=#heal+2,#BWInterfaceFrame.tab.tabs[2].lines do
			BWInterfaceFrame.tab.tabs[2].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[2].scroll.SetNewHeight(BWInterfaceFrame.tab.tabs[2].scroll,(#heal+1) * 20)
	end
	local function HealingTab_UpdateLinesTargets(doEnemy)
		Healing_Last_Func = HealingTab_UpdateLinesTargets
		Healing_Last_doEnemy = doEnemy
		local heal = {}
		local total = 0
		local totalOver = 0
		for sourceGUID,sourceData in pairs(module.db.nowData.heal) do
			if not HsourceVar or HsourceVar == sourceGUID then
				for destGUID,destData in pairs(sourceData) do
					local isEnemy = not ExRT.mds.UnitIsFriendlyByUnitFlag2(module.db.data[module.db.nowNum].reaction[destGUID])
					if not HdestVar or HdestVar == destGUID then
						if (isEnemy and doEnemy) or (not isEnemy and not doEnemy) then
							local inDamagePos = ExRT.mds.table_find(heal,destGUID,1)
							if not inDamagePos then
								inDamagePos = #heal + 1
								heal[inDamagePos] = {destGUID,0,0,0,0,0,0}
							end
							for spellID,spellAmount in pairs(destData) do
								heal[inDamagePos][2] = heal[inDamagePos][2] + spellAmount.amount - spellAmount.over + spellAmount.absorbed
								heal[inDamagePos][3] = heal[inDamagePos][3] + spellAmount.amount 						--total
								heal[inDamagePos][4] = heal[inDamagePos][4] + spellAmount.over 							--overheal
								heal[inDamagePos][5] = heal[inDamagePos][5] + spellAmount.absorbed 						--absorbed
								if HealingShowOverheal then
									heal[inDamagePos][6] = heal[inDamagePos][6] + spellAmount.crit
									heal[inDamagePos][7] = heal[inDamagePos][7] + spellAmount.ms
								else
									heal[inDamagePos][6] = heal[inDamagePos][6] + spellAmount.crit - spellAmount.critover
									heal[inDamagePos][7] = heal[inDamagePos][7] + spellAmount.ms - spellAmount.msover					
								end
								total = total + spellAmount.amount - spellAmount.over + spellAmount.absorbed
								totalOver = totalOver + spellAmount.over
							end
						end
					end
				end
			end
		end
		local totalIsFull = 1
		total = max(total,1)
		if total == 1 and #heal == 0 then
			total = 0
			totalIsFull = 0
		end
		local _max = nil
		wipe(reportData[2])
		reportData[2][1] = (HsourceVar and GetGUID(HsourceVar) or ExRT.L.BossWatcherAllSources).." > "..(HdestVar and GetGUID(HdestVar) or ExRT.L.BossWatcherAllTargets)
		if not HealingShowOverheal then
			reportData[2][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total)
			sort(heal,function(a,b) return a[2]>b[2] end)
			_max = heal[1] and heal[1][2] or 0
			HealingTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total,total / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart))
		else
			reportData[2][2] = ExRT.L.BossWatcherReportTotal.." - "..ExRT.mds.shortNumber(total + totalOver)
			sort(heal,function(a,b) return (a[2]+a[4])>(b[2]+b[4]) end)
			_max = heal[1] and (heal[1][2]+heal[1][4]) or 0
			HealingTab_SetLine(1,"",ExRT.L.BossWatcherReportTotal,totalIsFull,totalIsFull,total + totalOver,(total + totalOver) / (module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),nil,nil,nil,nil,nil,nil,totalOver / max(total + totalOver,1))		
		end
		for i=1,#heal do
			local class = nil
			if heal[i][1] and heal[i][1] ~= "" then
				class = select(2,GetPlayerInfoByGUID(heal[i][1]))
			end
			local icon = ""
			if class and CLASS_ICON_TCOORDS[class] then
				icon = {"Interface\\GLUES\\CHARACTERCREATE\\UI-CHARACTERCREATE-CLASSES",unpack(CLASS_ICON_TCOORDS[class])}
			end
			local tooltipData = {GetGUID(heal[i][1]),
				{ExRT.L.BossWatcherHealTooltipOver,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][4]),heal[i][4]/max(heal[i][2]+heal[i][4],1)*100)},
				{ExRT.L.BossWatcherHealTooltipAbsorbed,ExRT.mds.shortNumber(heal[i][5])},
				{ExRT.L.BossWatcherHealTooltipTotal,ExRT.mds.shortNumber(heal[i][3])},
				{" "," "},
				{ExRT.L.BossWatcherHealTooltipFromCrit,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][6]),heal[i][6]/max(1,heal[i][2]+(HealingShowOverheal and heal[i][4] or 0))*100)},
				{ExRT.L.BossWatcherHealTooltipFromMs,format("%s (%.1f%%)",ExRT.mds.shortNumber(heal[i][7]),heal[i][7]/max(1,heal[i][2]+(HealingShowOverheal and heal[i][4] or 0))*100)},
			}
			if not HealingShowOverheal then
				HealingTab_SetLine(i+1,icon,GetGUID(heal[i][1])..GUIDtoText(" [%s]",heal[i][1]),heal[i][2]/total,heal[i][2]/max(_max,1),heal[i][2],heal[i][2]/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,nil,nil,nil,tooltipData)
				reportData[2][#reportData[2]+1] = i..". "..GetGUID(heal[i][1]).." - "..ExRT.mds.shortNumber(heal[i][2])
			else
				HealingTab_SetLine(i+1,icon,GetGUID(heal[i][1])..GUIDtoText(" [%s]",heal[i][1]),(heal[i][2]+heal[i][4])/(total+totalOver),(heal[i][2]+heal[i][4])/max(_max,1),(heal[i][2]+heal[i][4]),(heal[i][2]+heal[i][4])/(module.db.data[module.db.nowNum].encounterEnd - module.db.data[module.db.nowNum].encounterStart),class,nil,nil,nil,tooltipData,nil,heal[i][4] / max(heal[i][2]+heal[i][4],1))			
				reportData[2][#reportData[2]+1] = i..". "..GetGUID(heal[i][1]).." - "..ExRT.mds.shortNumber(heal[i][2]+heal[i][4])
			end
		end
		for i=#heal+2,#BWInterfaceFrame.tab.tabs[2].lines do
			BWInterfaceFrame.tab.tabs[2].lines[i]:Hide()
		end
		BWInterfaceFrame.tab.tabs[2].scroll.SetNewHeight(BWInterfaceFrame.tab.tabs[2].scroll,(#heal+1) * 20)
	end
	
	local function HealingTab_SelectDropDownSource(self,arg,arg2,doEnemy,doSpells)
		HsourceVar = arg
		if not doSpells then
			if not HdestVar then
				if HsourceVar then
					HealingTab_UpdateLinesTargets(doEnemy)
				else
					HealingTab_UpdateLinesPlayers(doEnemy)
				end
			else
				if HsourceVar then
					HealingTab_UpdateLinesSpell(doEnemy)
				else
					HealingTab_UpdateLinesPlayers(doEnemy)
				end
			end
		else
			HealingTab_UpdateLinesSpell(doEnemy)
		end
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].sourceDropDown, arg2)
		ExRT.lib.ScrollDropDown.Close()
	end
	local function HealingTab_SelectDropDownDest(self,arg,arg2,doEnemy,doSpells)
		HdestVar = arg
		if not doSpells then
			HealingTab_UpdateLinesPlayers(doEnemy)
			if not HsourceVar then
				HealingTab_UpdateLinesPlayers(doEnemy)
			else
				if HdestVar then
					HealingTab_UpdateLinesSpell(doEnemy)
				else
					HealingTab_UpdateLinesTargets(doEnemy)
				end
			end
		else
			HealingTab_UpdateLinesSpell(doEnemy)
		end
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].targetDropDown, arg2)
		ExRT.lib.ScrollDropDown.Close()
	end

	local function HealingTab_HPS(doEnemy,doSpells)		
		local sourceTable = {}
		local destTable = {}
		for sourceGUID,sourceData in pairs(module.db.nowData.heal) do	
			local owner = ExRT.mds.Pets:getOwnerGUID(sourceGUID)
			if owner then
				sourceGUID = owner
			end
			for destGUID,destData in pairs(sourceData) do
				local isFriendly = ExRT.mds.UnitIsFriendlyByUnitFlag2(module.db.data[module.db.nowNum].reaction[destGUID])
				if (isFriendly and not doEnemy) or (not isFriendly and doEnemy) then
					if not ExRT.mds.table_find(destTable,destGUID,1) then
						destTable[#destTable + 1] = {destGUID,GetGUID(destGUID)}
					end
					if not ExRT.mds.table_find(sourceTable,sourceGUID,1) then
						sourceTable[#sourceTable + 1] = {sourceGUID,GetGUID(sourceGUID)}
					end
				end
			end
		end
		sort(sourceTable,function(a,b) return a[2]<b[2] end)
		sort(destTable,function(a,b) return a[2]<b[2] end)
		wipe(BWInterfaceFrame.tab.tabs[2].sourceDropDown.List)
		wipe(BWInterfaceFrame.tab.tabs[2].targetDropDown.List)
		BWInterfaceFrame.tab.tabs[2].sourceDropDown.List[1] = {text = ExRT.L.BossWatcherAll,func = HealingTab_SelectDropDownSource,arg2 = ExRT.L.BossWatcherAll,arg3=doEnemy,arg4=doSpells,}
		BWInterfaceFrame.tab.tabs[2].targetDropDown.List[1] = {text = ExRT.L.BossWatcherAll,func = HealingTab_SelectDropDownDest,arg2 = ExRT.L.BossWatcherAll,arg3=doEnemy,arg4=doSpells,}
		for i=1,#sourceTable do
			local isPlayer = ExRT.mds.GetUnitTypeByGUID(sourceTable[i][1]) == 0
			local classColor = ""
			if isPlayer then
				classColor = "|c"..ExRT.mds.classColorByGUID(sourceTable[i][1])
			end
			BWInterfaceFrame.tab.tabs[2].sourceDropDown.List[i+1] = {
				text = classColor..sourceTable[i][2]..GUIDtoText(" [%s]",sourceTable[i][1]),
				arg1 = sourceTable[i][1],
				arg2 = classColor..sourceTable[i][2],
				func = HealingTab_SelectDropDownSource,
				arg3 = doEnemy,
				arg4 = doSpells,
			}
		end
		for i=1,#destTable do
			local isPlayer = ExRT.mds.GetUnitTypeByGUID(destTable[i][1]) == 0
			local classColor = ""
			if isPlayer then
				classColor = "|c"..ExRT.mds.classColorByGUID(destTable[i][1])
			end
			BWInterfaceFrame.tab.tabs[2].targetDropDown.List[i+1] = {
				text = classColor..destTable[i][2]..GUIDtoText(" [%s]",destTable[i][1]),
				arg1 = destTable[i][1],
				arg2 = classColor..destTable[i][2],
				func = HealingTab_SelectDropDownDest,
				arg3 = doEnemy,
				arg4 = doSpells,
			}
		end
		HsourceVar = nil
		HdestVar = nil
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].sourceDropDown, ExRT.L.BossWatcherAll)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].targetDropDown, ExRT.L.BossWatcherAll)
		if doSpells then
			HealingTab_UpdateLinesSpell(doEnemy)		
		else
			HealingTab_UpdateLinesPlayers(doEnemy)
		end
	end
	
	local function HealingTab_Friendly(self,arg)
		HealingTab_HPS(false,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function HealingTab_Enemy(self,arg)
		HealingTab_HPS(true,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function HealingTab_FriendlyTarget(self,arg)
		HealingTab_HPS(false,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].typeDropDown, arg)
		HealingTab_UpdateLinesTargets(false)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function HealingTab_EnemyTarget(self,arg)
		HealingTab_HPS(false,false)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].typeDropDown, arg)
		HealingTab_UpdateLinesTargets(true)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function HealingTab_FriendlySpell(self,arg)
		HealingTab_HPS(false,true)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	local function HealingTab_EnemySpell(self,arg)
		HealingTab_HPS(true,true)
		UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].typeDropDown, arg)
		ExRT.lib.ScrollDropDown.Close()
	end
	
	tab.typeDropDown = ExRT.lib.CreateScrollDropDown(tabName.."TypeDropDown",tab,"TOPLEFT",45,-10,150,200,6,ExRT.L.BossWatcherHealFriendly)
	tab.typeText = ExRT.lib.CreateText(tab,100,20,nil,0,0,"RIGHT","TOP",nil,12,ExRT.L.BossWatcherType..":",nil,1,1,1,1)
	ExRT.lib.SetPoint(tab.typeText,"TOPRIGHT",tab.typeDropDown,"TOPLEFT",12,-8)
	tab.typeDropDown.List = {
		{text = ExRT.L.BossWatcherHealFriendly,func = HealingTab_Friendly,arg1=ExRT.L.BossWatcherHealFriendly},
		{text = ExRT.L.BossWatcherHealHostile,func = HealingTab_Enemy,arg1=ExRT.L.BossWatcherHealHostile},
		{text = ExRT.L.BossWatcherHealFriendlyByTarget,func = HealingTab_FriendlyTarget,arg1=ExRT.L.BossWatcherHealFriendlyByTarget},
		{text = ExRT.L.BossWatcherHealHostileByTarget,func = HealingTab_EnemyTarget,arg1=ExRT.L.BossWatcherHealHostileByTarget},
		{text = ExRT.L.BossWatcherHealFriendlyBySpell,func = HealingTab_FriendlySpell,arg1=ExRT.L.BossWatcherHealFriendlyBySpell},
		{text = ExRT.L.BossWatcherHealHostileBySpell,func = HealingTab_EnemySpell,arg1=ExRT.L.BossWatcherHealHostileBySpell},
	}
	
	tab.sourceDropDown = ExRT.lib.CreateScrollDropDown(tabName.."SourceDropDown",tab,"TOPLEFT",310,-10,180,250,20,ExRT.L.BossWatcherAll)
	tab.sourceText = ExRT.lib.CreateText(tab,100,20,nil,0,0,"RIGHT","TOP",nil,12,ExRT.L.BossWatcherSource..":",nil,1,1,1,1)
	ExRT.lib.SetPoint(tab.sourceText,"TOPRIGHT",tab.sourceDropDown,"TOPLEFT",12,-8)

	tab.targetDropDown = ExRT.lib.CreateScrollDropDown(tabName.."TargetDropDown",tab,"TOPLEFT",580,-10,180,250,20,ExRT.L.BossWatcherAll)
	tab.targetText = ExRT.lib.CreateText(tab,100,20,nil,0,0,"RIGHT","TOP",nil,12,ExRT.L.BossWatcherTarget..":",nil,1,1,1,1)
	ExRT.lib.SetPoint(tab.targetText,"TOPRIGHT",tab.targetDropDown,"TOPLEFT",12,-8)
	
	tab.showOverhealChk = ExRT.lib.CreateCheckBox(nil,tab,"TOPLEFT",795,-8,"",nil,ExRT.L.BossWatcherHealShowOver)
	tab.showOverhealChk:SetScript("OnClick",function (self)
		if self:GetChecked() then
			HealingShowOverheal = true
		else
			HealingShowOverheal = false
		end
		Healing_Last_Func(Healing_Last_doEnemy)
	end)
	
	tab.scroll = ExRT.lib.CreateScrollFrame(tabName.."ScrollFrame",tab,810,467+65,"TOP",0,-45,600)
	tab.lines = {}
	local function HealingTab_Line_OnClick(self)
		local GUID = self.sourceGUID
		local doEnemy = self.doEnemy
		if self:GetParent().sourceGUID then
			GUID = self:GetParent().sourceGUID
			doEnemy = self:GetParent().doEnemy
		end
		if GUID then
			HsourceVar = GUID
			UIDropDownMenu_SetText(BWInterfaceFrame.tab.tabs[2].sourceDropDown, GetGUID(GUID))
			HealingTab_UpdateLinesSpell(doEnemy)
		end
	end
	local function HealingTab_LineOnEnter(self)
		if self.tooltip then
			GameTooltip:SetOwner(self,"ANCHOR_LEFT")
			GameTooltip:SetText(self.tooltip[1])
			for i=2,#self.tooltip do
				if type(self.tooltip[i]) == "table" then
					GameTooltip:AddDoubleLine(self.tooltip[i][1],self.tooltip[i][2],1,1,1,1,1,1,1,1)
				else
					GameTooltip:AddLine(self.tooltip[i])
				end
			end
			GameTooltip:Show()
		end
	end
	local function HealingTab_Line_OnEnter(self)
		local parent = self:GetParent()
		if parent.spellLink then
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:SetHyperlink(parent.spellLink)
			GameTooltip:Show()
		elseif parent.name:IsTruncated() then
			GameTooltip:SetOwner(self,"ANCHOR_LEFT")
			GameTooltip:SetText(parent.name:GetText())
			GameTooltip:Show()	
		elseif parent.tooltip then
			HealingTab_LineOnEnter(parent)
		end
	end
	function HealingTab_SetLine(i,icon,name,overall_num,overall,total,dps,class,sourceGUID,doEnemy,spellLink,tooltip,school,overall_black)
		if not BWInterfaceFrame.tab.tabs[2].lines[i] then
			local line = CreateFrame("Button",nil,BWInterfaceFrame.tab.tabs[2].scroll.C)
			BWInterfaceFrame.tab.tabs[2].lines[i] = line
			line:SetSize(790,20)
			line:SetPoint("TOPLEFT",0,-(i-1)*20)
			
			line.icon = ExRT.lib.CreateIcon(nil,line,18,"TOPLEFT",5,-1)
			line.name = ExRT.lib.CreateText(line,200,20,nil,25,0,"LEFT","MIDDLE",nil,12,"name",nil,1,1,1,1)
			line.name_tooltip = CreateFrame('Button',nil,line)
			line.name_tooltip:SetAllPoints(line.name)
			line.overall_num = ExRT.lib.CreateText(line,70,20,nil,225,0,"RIGHT","MIDDLE",nil,12,"45.76%",nil,1,1,1,1)
			line.overall = line:CreateTexture(nil, "BACKGROUND")
			--line.overall:SetTexture(0.7, 0.1, 0.1, 1)
			line.overall:SetTexture("Interface\\AddOns\\ExRT\\media\\bar24.tga")
			line.overall:SetSize(300,16)
			line.overall:SetPoint("TOPLEFT",300,-2)
			line.overall_black = line:CreateTexture(nil, "BACKGROUND")
			line.overall_black:SetTexture("Interface\\AddOns\\ExRT\\media\\bar24b.tga")
			line.overall_black:SetSize(300,16)
			line.overall_black:SetPoint("LEFT",line.overall,"RIGHT",0,0)

			line.total = ExRT.lib.CreateText(line,95,20,nil,605,0,"LEFT","MIDDLE",nil,12,"125.46M",nil,1,1,1,1)
			line.dps = ExRT.lib.CreateText(line,100,20,nil,700,0,"LEFT","MIDDLE",nil,12,"34576.43",nil,1,1,1,1)
			
			line.back = line:CreateTexture(nil, "BACKGROUND")
			line.back:SetAllPoints()
			if i%2==0 then
				line.back:SetTexture(0.3, 0.3, 0.3, 0.1)
			end
			line:SetScript("OnClick",HealingTab_Line_OnClick)
			line.name_tooltip:SetScript("OnEnter",HealingTab_Line_OnEnter)
			line.name_tooltip:SetScript("OnLeave",GameTooltip_Hide)
			line.name_tooltip:SetScript("OnClick",HealingTab_Line_OnClick)
			line:SetScript("OnEnter",HealingTab_LineOnEnter)
			line:SetScript("OnLeave",GameTooltip_Hide)
		end
		local line = BWInterfaceFrame.tab.tabs[2].lines[i]
		if type(icon) == "table" then
			line.icon.texture:SetTexture(icon[1] or "Interface\\Icons\\INV_MISC_QUESTIONMARK")
			line.icon.texture:SetTexCoord(unpack(icon,2,5))
		else
			line.icon.texture:SetTexture(icon or "Interface\\Icons\\INV_MISC_QUESTIONMARK")
			line.icon.texture:SetTexCoord(0,1,0,1)
		end
		line.name:SetText(name or "")
		line.overall_num:SetFormattedText("%.2f%%",overall_num and overall_num * 100 or 0)
		if overall_black and overall_black > 0 then
			local width = 300*(overall or 1)
			local normal_width = width * (1 - overall_black)
			line.overall:SetWidth(max(normal_width,1))
			line.overall_black:SetWidth(max(width-normal_width,1))
			line.overall_black:Show()
		else
			line.overall_black:Hide()
			line.overall:SetWidth(max(300*(overall or 1),1))
		end
		line.total:SetText(total and ExRT.mds.shortNumber(total) or "")
		line.dps:SetFormattedText("%.2f",dps or 0)
		line.overall:SetGradientAlpha("HORIZONTAL", 0,0,0,0,0,0,0,0)
		line.overall_black:SetGradientAlpha("HORIZONTAL", 0,0,0,0,0,0,0,0)
		if class then
			local classColorArray = RAID_CLASS_COLORS[class]
			if classColorArray then
				line.overall:SetVertexColor(classColorArray.r,classColorArray.g,classColorArray.b, 1)
				line.overall_black:SetVertexColor(classColorArray.r,classColorArray.g,classColorArray.b, 1)
			else
				line.overall:SetVertexColor(0.8,0.8,0.8, 1)
				line.overall_black:SetVertexColor(0.8,0.8,0.8, 1)
			end
		else
			line.overall:SetVertexColor(0.8,0.8,0.8, 1)
			line.overall_black:SetVertexColor(0.8,0.8,0.8, 1)
		end
		if school then
			SetSchoolColorsToLine(line.overall,school)
			SetSchoolColorsToLine(line.overall_black,school)
		end
		line.sourceGUID = sourceGUID
		line.doEnemy = doEnemy
		line.spellLink = spellLink
		line.tooltip = tooltip
		line:Show()
	end
	
	tab:SetScript("OnShow",function (self)
		BWInterfaceFrame.report:Show()
		if BWInterfaceFrame.nowFightID ~= self.lastFightID then
			HealingTab_Friendly(nil,ExRT.L.BossWatcherHealFriendly)
			self.lastFightID = BWInterfaceFrame.nowFightID
		end
	end)
	tab:SetScript("OnHide",function (self)
		BWInterfaceFrame.report:Hide()
	end)
end