--[[ Ember: Equipment Manager Banker

1.0.6, 10/14/2014: 6.0 patch
1.0.5, 09/11/2013: toc update for 5.4 patch
1.0.4, 05/22/2013: fix for new return of EquipmentManager_UnpackLocation
1.0.3, 05/21/2013: toc update for 5.3 patch
1.0.2, 10/11/2012: removed range slot from set tooltip
1.0.1, 06/30/2012: tested with MoP beta and updated toc
1.0.0, 01/13/2012: initial release

]]

local ember = CreateFrame("Frame","Ember")

ember.atBank = nil
ember.inCombat = nil

ember.freeSpace = {
	bank = {[-1]={},[5]={},[6]={},[7]={},[8]={},[9]={},[10]={},[11]={}},
	bags = {[0]={},[1]={},[2]={},[3]={},[4]={}}
}
ember.bagOrder = {
	bank = {-1,5,6,7,8,9,10,11},
	bags = {4,3,2,1,0}
}
ember.reverseBagOrder = { -- hold SHIFT to move stuff in reverse bag order
	bank = {-1,11,10,9,8,7,6,5},
	bags = {0,1,2,3,4}
}

ember.locationsToIgnore = { -- we'll never overlay these buttons
	[EQUIPMENTFLYOUT_IGNORESLOT_LOCATION] = 1,
	[EQUIPMENTFLYOUT_UNIGNORESLOT_LOCATION] = 1
}

ember.slotName = {
	"Head", "Neck", "Shoulder", "Shirt", "Chest", "Waist", "Legs", "Feet",
	"Wrist", "Hands", "Top Finger", "Bottom Finger", "Top Trinket",
	"Bottom Trinket", "Cloak", "Main Hand", "Off Hand", "Ranged", "Tabard"
}

ember.WORN = 1
ember.MISSING = 2
ember.BAGGED = 3
ember.BANKED = 4

ember.reusableSetTable = {} -- GetEquipmentSetLocations reuses this

--[[ Free space management ]]

-- returns a bag,slot that's Pickup'able (safe for normal bags too)
function ember:ConvertBankToPickup(bag,slot)
	if not bag then
		bag = -1 -- the main bank area is bag -1
		slot = slot - 39 -- and offset by 39
	end
	return bag,slot
end

function ember:NotEnoughSpace()
	UIErrorsFrame:AddMessage("Not enough space to perform that swap.",1,.1,.1,1)
end

-- populates ember.freeSpace with available empty bag,slots
function ember:ScanFreeSpace(bank)
	local free = bank and ember.freeSpace.bank or ember.freeSpace.bags
	local numSlots
	local total = 0
	for bag in pairs(free) do
		numSlots = GetContainerNumSlots(bag)
		if select(2,GetContainerNumFreeSlots(bag))~=0 then
			numSlots = 0 -- if this is a special bag (ore, gem, herb, etc bag) pretend it has no room
		end
		for slot in pairs(free[bag]) do
			free[bag][slot] = nil -- assume full (cleanly wipe all empties)
		end
		for slot=1,numSlots do
			if not GetContainerItemLink(bag,slot) then
				free[bag][slot] = 1
				total = total + 1
			end
		end
	end
end

-- returns Pickup'able bag,slot of next free spot in bags (or bank if true)
-- run ember:ScanFreeSpace before running this, especially on multi-item swaps
function ember:GetFreeSpace(bank)
	local free = bank and ember.freeSpace.bank or ember.freeSpace.bags
	local orderDirection = IsShiftKeyDown() and "reverseBagOrder" or "bagOrder"
	local order = bank and ember[orderDirection].bank or ember[orderDirection].bags
	local slot
	for _,bag in pairs(order) do
		for slotCandidate in pairs(free[bag]) do
			if not slot or slotCandidate<slot then
				slot = slotCandidate
			end
		end
		if slot then
			free[bag][slot] = nil -- found a space, fill it
			return bag,slot -- and return it
		end
	end
	return nil
end

--[[ Flyout overlay buttons ]]

-- only happens when at the bank, move flyout item to bags or bank
function ember:FlyoutButtonOnClick()
	local parent = GetMouseFocus():GetParent()
	local player, bank, bags, _, slot, bag = EquipmentManager_UnpackLocation(parent.location)
	local freeBag,freeSlot
	ClearCursor()
	if parent.location == EQUIPMENTFLYOUT_PLACEINBAGS_LOCATION then -- clicked "Place in Bags" button
		bag = nil
		slot = parent.id -- pretend this is on person at slot parent.id
	end
	if player and not bag then -- on person
		ember:ScanFreeSpace(1)
		freeBag,freeSlot = ember:GetFreeSpace(1)
		if freeBag then
			PickupInventoryItem(slot)
			PickupContainerItem(freeBag,freeSlot)
		end
	else -- in bank or bags, bank is true if item is in bank
		ember:ScanFreeSpace(not bank)
		bag,slot = ember:ConvertBankToPickup(bag,slot)
		freeBag,freeSlot = ember:GetFreeSpace(not bank)
		if freeBag then
			PickupContainerItem(bag,slot)
			PickupContainerItem(freeBag,freeSlot)
		end
	end
	if not freeBag then
		ember:NotEnoughSpace()
	end
end

-- hooksecurefunc of EquipmentFlyout_CreateButton
-- we never create contents of the buttons, only an overlay that's
-- only clickable while at the bank and out of combat
function ember:CreateFlyoutBorders()
	local i = 1
	local button,parent,border
	while _G["EquipmentFlyoutFrameButton"..i] do
		parent = _G["EquipmentFlyoutFrameButton"..i]
		if not _G["EmberFlyoutButton"..i] then
			button = CreateFrame("Button","EmberFlyoutButton"..i,parent)
			button:SetAllPoints(parent)
			button:SetScript("OnEnter",ember.FlyoutButtonOnEnter)
			button:SetScript("OnLeave",ember.FlyoutButtonOnLeave)
			button:SetScript("OnClick",ember.FlyoutButtonOnClick)
			button:EnableMouse(ember.atBank and not ember.inCombat)
			border = button:CreateTexture("EmberFlyoutButton"..i.."Border","ARTWORK")
			border:SetAllPoints(button)
			border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
			border:SetTexCoord(0.2,0.8,0.2,0.8)
			border:SetBlendMode("ADD")
			highlight = button:CreateTexture(nil,"HIGHLIGHT")
			highlight:SetAllPoints(button)
			highlight:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
			highlight:SetBlendMode("ADD")
			button:Show()
		end
		i = i + 1
	end
end

-- hooksecurefunc of EquipmentFlyout_Show
function ember:ShowBorders()
	local i = 1
	local parent,button,border
	while _G["EquipmentFlyoutFrameButton"..i] do
		parent = _G["EquipmentFlyoutFrameButton"..i]
		button = _G["EmberFlyoutButton"..i]
		border = _G["EmberFlyoutButton"..i.."Border"]
		local player, bank, bags, _, slot, bag = EquipmentManager_UnpackLocation(parent.location)
		if player and not bag then
			border:SetVertexColor(0,.8,0,1)
			button:Show()
		elseif parent.location == EQUIPMENTFLYOUT_PLACEINBAGS_LOCATION then
			border:SetVertexColor(0,0,0,0)
			button:Show()
		elseif ember.locationsToIgnore[parent.location] then
			button:Hide() -- let clicks to ignored buttons pass through
		elseif bank then
			border:SetVertexColor(.1,.65,1,1)
			button:Show()
		else
			border:SetVertexColor(0,0,0,0)
			button:Show()
		end
		i = i + 1
	end
end

-- display tooltip of the contents of the button beneath the overlay
function ember:FlyoutButtonOnEnter()
	local parent = self:GetParent()
	local location = parent.location
	GameTooltip:SetOwner(EquipmentFlyoutFrameButtons, "ANCHOR_RIGHT", 6, -EquipmentFlyoutFrameButtons:GetHeight() - 6)
	if location == EQUIPMENTFLYOUT_PLACEINBAGS_LOCATION then
		GameTooltip:SetText(EQUIPMENT_MANAGER_PLACE_IN_BAGS, 1.0, 1.0, 1.0)
	else
		select(12,EquipmentManager_GetItemInfoByLocation(location))() -- setTooltip
	end
end

function ember:FlyoutButtonOnLeave()
	GameTooltip:Hide()
end

-- when at bank (and not in combat), overlays are clickable; unclickable otherwise
function ember:SetOverlayOpacity()
	local buttonNum = 1
	while _G["EmberFlyoutButton"..buttonNum] do
		_G["EmberFlyoutButton"..buttonNum]:EnableMouse(ember.atBank and not ember.inCombat)
		buttonNum = buttonNum + 1
	end
end

--[[ Paperdoll set tweaks ]]

function ember:SetTooltip(setName)
	GetEquipmentSetLocations(setName,ember.reusableSetTable)
	local set = ember.reusableSetTable
	GameTooltip:ClearLines()
	GameTooltip:AddLine("|cFFCCCCCCSet: |cFFF8F8F8"..setName)
	local slotName,itemID,itemName,itemIcon,loc = ""
	local red,green,blue,white = "|cFFFF2020","|cFF20FF20","|cFF40C0FF","|cFFFFD200"
	for i=0,19 do
		loc = set[i]
		if loc and loc~=1 and i~=18 then
			slotName = "|cFFCCCCCC"..ember.slotName[i]..": "
			local player, bank, bags, _, slot, bag = EquipmentManager_UnpackLocation(loc)
			if loc==EQUIPMENT_SET_EMPTY_SLOT then
				GameTooltip:AddLine("\124TInterface\\PaperDoll\\UI-Backpack-EmptySlot:16\124t "..slotName..(GetInventoryItemLink("player",i) and white or green).."(empty)")
			elseif loc==EQUIPMENT_SET_ITEM_MISSING then
				GameTooltip:AddLine("\124TInterface\\RAIDFRAME\\ReadyCheck-NotReady:16\124t "..slotName..red.."(missing)")
			else
				itemID,itemName,itemIcon = EquipmentManager_GetItemInfoByLocation(loc)
				itemName = itemName or ""
				itemIcon = itemIcon and ("\124T"..itemIcon..":16\124t ") or " "
				if bank then
					GameTooltip:AddLine(itemIcon..slotName..blue..itemName)
				elseif bags then
					GameTooltip:AddLine(itemIcon..slotName..white..itemName)
				else
					GameTooltip:AddLine(itemIcon..slotName..green..itemName)
				end
			end
		end
	end
	GameTooltip:Show()
end

function ember:DisplaySetTooltip(setName)
	GameTooltip:SetEquipmentSet(setName)
end

-- returns a numerical status of a set
-- returns ember.MISSING if any piece is unavailable regardless rest
-- set ignoreMissing to see if any items are banked (bank set swaps)
function ember:GetSetStatus(setName,ignoreMissing)
	local worn,valid,_,_,missing = select(3,GetEquipmentSetInfoByName(setName))
	if not valid then
		return nil
	elseif worn then
		return ember.WORN
	elseif missing>0 and not ignoreMissing then
		return ember.MISSING
	elseif not ember.atBank then
		return ember.BAGGED
	else
		GetEquipmentSetLocations(setName,ember.reusableSetTable)
		for _,location in pairs(ember.reusableSetTable) do
			if location and select(2,EquipmentManager_UnpackLocation(location)) then
				return ember.BANKED
			end
		end
		return ember.BAGGED
	end
end

-- Complete mystery how a hybrid scroll window re-applies SetTextColor
-- Our solution is to hook each buttonText:SetTextColor and apply
-- a new color afterwards if needed.
function ember:PaperDollEquipmentManagerPaneButtonXText_SetTextColor(...)
	if select(5,...)==-1 then
		-- since we may be doing a SetTextColor also, avoid a
		-- recursive loop by passing -1 as a 5th argument when
		-- we do it, and immediately leave then.
		return
	else
		local parent = self:GetParent()
		local setStatus = ember:GetSetStatus(parent.name or "")
		if setStatus == ember.WORN then
			parent.text:SetTextColor(.125,1,.125,1,-1)
		elseif (setStatus==ember.MISSING) or (setStatus==ember.BANKED and not ember.atBank) then
			parent.text:SetTextColor(1,.125,.125,1,-1)
		elseif setStatus == ember.BANKED then
			parent.text:SetTextColor(.25,.75,1,1,-1)
		end
	end
end

function ember:PaperDollEquipmentManagerPane_OnShow()
	if not ember.colorsHooked then
		ember.colorsHooked = {}
	end
	local buttonStub = "PaperDollEquipmentManagerPaneButton"
	local buttonNum = 1
	local button
	while _G[buttonStub..buttonNum] do
		button = _G[buttonStub..buttonNum.."Text"]
		if not ember.colorsHooked[buttonNum] then
			hooksecurefunc(button,"SetTextColor",ember.PaperDollEquipmentManagerPaneButtonXText_SetTextColor)
			ember.PaperDollEquipmentManagerPaneButtonXText_SetTextColor(button,1,.82,0,1)
			ember.colorsHooked[buttonNum] = 1
			button:GetParent():HookScript("OnClick",ember.ShowInterceptor)
			button:GetParent():SetScript("OnLeave",function() if not EmberInterceptor:IsVisible() then GameTooltip:Hide() end end)
		end
		buttonNum = buttonNum + 1
	end
	ember:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
end

function ember:PaperDollEquipmentManagerPane_OnHide()
	ember:UnregisterEvent("PLAYER_EQUIPMENT_CHANGED")
end

-- default UI doesn't set colors when bank opens/closes, so we have to
function ember:UpdateAllSetColors()
	local buttonStub = "PaperDollEquipmentManagerPaneButton"
	local buttonNum = 1
	while _G[buttonStub..buttonNum.."Text"] do
		ember.PaperDollEquipmentManagerPaneButtonXText_SetTextColor(_G[buttonStub..buttonNum.."Text"],1,.82,0,1)
		buttonNum = buttonNum + 1
	end
end

--[[ EmberBankButton ]]

function ember:CreateBankButton()
	local button = CreateFrame("Button","EmberBankButton",PaperDollEquipmentManagerPane,"UIPanelButtonTemplate")
	button:SetWidth(87)
	button:SetHeight(22)
	button:SetPoint("TOPLEFT")
	button:SetText("Bank")
	button:SetScript("OnClick",ember.BankButtonOnClick)
	button:SetFrameLevel(button:GetParent():GetFrameLevel()+3)
	local back = button:CreateTexture("EmberBankButtonBackground","BACKGROUND")
	back:SetPoint("TOPLEFT") -- this simply blacks out top for neatness when PaneButton is underneat
	back:SetPoint("BOTTOMRIGHT",PaperDollEquipmentManagerPane,"TOPRIGHT",0,-2)
	back:SetTexture("Interface\\ChatFrame\\ChatFrameBackground")
	back:SetVertexColor(0,0,0,1)
	button:Hide()

end

function ember:UpdateBankButton()
	if ember.atBank then
		PaperDollEquipmentManagerPaneEquipSet:Hide()
		EmberBankButton:Show()
		local setName = PaperDollEquipmentManagerPane.selectedSetName
		local button = EmberBankButton
		if not setName then
			button:Disable()
		elseif ember:GetSetStatus(setName,1)==ember.BANKED then
			button:Enable()
			button:SetText("Withdraw")
		else
			button:Enable()
			button:SetText("Bank")
		end
	else
		EmberBankButton:Hide()
		PaperDollEquipmentManagerPaneEquipSet:Show()
	end
end

function ember:BankButtonOnClick()
	local setName = PaperDollEquipmentManagerPane.selectedSetName
	local setStatus = ember:GetSetStatus(setName,1)
	ClearCursor()
	if setStatus == ember.BANKED then
		ember:PullFromBankToBags(setName)
	elseif (setStatus==ember.BAGGED) or (setStatus==ember.WORN) then
		ember:PushFromBagsToBank(setName)
	end
end

function ember:PullFromBankToBags(setName)
	GetEquipmentSetLocations(setName,ember.reusableSetTable)
	local set = ember.reusableSetTable
	local player, bank, bags, slot, bag, freeBag, freeSlot
	ember:ScanFreeSpace()
	for _,location in pairs(set) do
		player, bank, bags, _, slot, bag = EquipmentManager_UnpackLocation(location)
		if bank then
			bag, slot = ember:ConvertBankToPickup(bag,slot)
			freeBag, freeSlot = ember:GetFreeSpace()
			if freeBag then
				PickupContainerItem(bag,slot)
				PickupContainerItem(freeBag,freeSlot)
			else
				ember:NotEnoughSpace()
				return
			end
		end
	end
end

function ember:HowManyUnbankedSetsContainThisLocation(location)
	local setName, setStatus
	local total = 0
	local setTable = ember.reusableSetTable

	if IsControlKeyDown() then
		return 1 -- if CTRL is down, bank regardless of how many sets share this
	end

	for setIndex=1,GetNumEquipmentSets() do
		setName = GetEquipmentSetInfo(setIndex)
		setStatus = ember:GetSetStatus(setName,1)
		if setStatus==ember.BAGGED or setStatus==ember.WORN then
			-- if set is bagged or worn (no banked items) then
			-- look for the location and increment if found
			GetEquipmentSetLocations(setName,setTable)
			for slot,loc in pairs(setTable) do
				if loc==location then
					total = total + 1
					break
				end
			end
		end
	end
	return total
end

function ember:PushFromBagsToBank(setName)
	local setTable = GetEquipmentSetLocations(setName) -- don't use reusable table here!
	local player, bank, bags, slot, bag, freeBag, freeSlot
	ember:ScanFreeSpace(1)
	for _,location in pairs(setTable) do
		if location>1 and ember:HowManyUnbankedSetsContainThisLocation(location)==1 then
			player, bank, bags, _, slot, bag = EquipmentManager_UnpackLocation(location)
			if player and not bank and not bag then -- if worn
				freeBag, freeSlot = ember:GetFreeSpace(1)
				if freeBag then
					PickupInventoryItem(slot)
					PickupContainerItem(freeBag,freeSlot)
				else
					ember:NotEnoughSpace()
					return
				end
			elseif not bank and bag and slot then -- if in bags
				freeBag, freeSlot = ember:GetFreeSpace(1)
				if freeBag then
					PickupContainerItem(bag,slot)
					PickupContainerItem(freeBag,freeSlot)
				else
					ember:NotEnoughSpace()
					return
				end
			end
		end
	end
end

--[[ EmberInterceptor ]]

-- We want double-clicks of sets to consistently bank, but we can't
-- get involved in clicking the equip pane or equips taint.
-- Solution: let first clicks go through and make a clickable
-- overlay appear for a second to intercept what would be a double click.

function ember:CreateInterceptor()
	local interceptor = CreateFrame("Button","EmberInterceptor",ember)
	interceptor:Hide()
	interceptor:SetScript("OnClick",function() ember:BankButtonOnClick() interceptor:Hide() end)
	interceptor:SetScript("OnShow",function() interceptor.timer = 0 end)
	interceptor:SetScript("OnLeave",function()
		interceptor:Hide()
		if not MouseIsOver(PaperDollEquipmentManagerPane) then
			GameTooltip:Hide() -- if interceptor was going up we aborted the parent's OnLeave
		end
	end)
	interceptor:SetScript("OnUpdate",function(self,elapsed)
		interceptor.timer = interceptor.timer + elapsed
		if interceptor.timer > 1 then
			interceptor:Hide() -- show for one second then disappear
		end
	end)
end

function ember:ShowInterceptor()
	if not ember.atBank then
		return -- the interceptor is only used at the bank
	end
	local focus = GetMouseFocus()
	local interceptor = EmberInterceptor
	if focus.name then
		interceptor:SetParent(focus)
		interceptor:SetAllPoints(focus)
		interceptor:Show()
	end
end

--[[ Throttle handlers ]]

-- in a couple places we get multiple events and only want to act on them
-- once when they're done.
-- ember:ThrottleEmberFunc("func",optional_arg) will wait until 0.1 secs
-- after the last event fires and run all queued ember[func](arg)

local throttle = CreateFrame("Frame","EmberThrottle",ember)

function ember:InitializeThrottle()
	ember.throttleQueue = {}
	throttle:Hide()
	throttle:SetScript("OnUpdate",throttle.OnUpdate)
end

function throttle:OnUpdate(elapsed)
	throttle.timer = throttle.timer + elapsed
	if throttle.timer > .1 then
		for func,arg in pairs(ember.throttleQueue) do
			ember[func](self,(arg=="nil" and nil or arg)) -- run all funcs in ember.throttleQueue
			ember.throttleQueue[func] = nil
		end
		throttle:Hide()
	end
end

-- throttle ember[func](arg)
function ember:ThrottleEmberFunction(func,arg)
	throttle.timer = 0
	ember.throttleQueue[func] = arg or "nil"
	throttle:Show()
end

--[[ Event Handlers ]]

function ember:PLAYER_LOGIN()
	hooksecurefunc("EquipmentFlyout_CreateButton",ember.CreateFlyoutBorders)
	hooksecurefunc("EquipmentFlyout_Show",ember.ShowBorders)
	ember.oldSetEquipmentSet = GameTooltip.SetEquipmentSet -- safe to unsecurely hook
	GameTooltip.SetEquipmentSet = ember.SetTooltip

	PaperDollEquipmentManagerPane:HookScript("OnShow",ember.PaperDollEquipmentManagerPane_OnShow)
	PaperDollEquipmentManagerPane:HookScript("OnHide",ember.PaperDollEquipmentManagerPane_OnHide)
	hooksecurefunc("PaperDollEquipmentManagerPane_Update",ember.UpdateBankButton)
	ember:CreateBankButton()
	ember:InitializeThrottle()
	ember:CreateInterceptor()
end

function ember:BANKFRAME_OPENED()
	ember.atBank = 1
	ember:SetOverlayOpacity()
	ember:UpdateBankButton()
	ember:UpdateAllSetColors()
	ember:RegisterEvent("BAG_UPDATE")
end

function ember:BANKFRAME_CLOSED()
	ember:UnregisterEvent("BAG_UPDATE")
	ember.atBank = nil
	-- event called twice when bank closes, just run this stuff once
	ember:ThrottleEmberFunction("SetOverlayOpacity")
	ember:ThrottleEmberFunction("UpdateBankButton")
	ember:ThrottleEmberFunction("UpdateAllSetColors")
end

function ember:PLAYER_REGEN_DISABLED()
	ember.inCombat = 1 -- entering combat
	ember:BANKFRAME_CLOSED() -- make overlay buttons click-through
end

function ember:PLAYER_REGEN_ENABLED()
	ember.inCombat = nil -- leaving combat
	if ember.atBank then
		ember:BANKFRAME_OPENED() -- if at the bank, make overlay clickable
	end
end

-- PLAYER_EQUIPMENT_CHANGED and BAG_UPDATE can fire many times at once
-- The two events call this to queue up updates once the events stop
function ember:ItemsHaveMoved()
	if PaperDollEquipmentManagerPane:IsVisible() then
		local focus = GetMouseFocus()
		if focus.name and (focus:GetName() or ""):match("^PaperDollEquipmentManagerPaneButton") then
			ember:ThrottleEmberFunction("DisplaySetTooltip",focus.name)
		end
		if ember.atBank then
			ember:ThrottleEmberFunction("UpdateBankButton")
		end
	end
end

function ember:PLAYER_EQUIPMENT_CHANGED() -- registered on EquipmentManagerPane OnShow
	ember:ItemsHaveMoved()
end

function ember:BAG_UPDATE() -- registered when bank open
	ember:ItemsHaveMoved()
end

ember:SetScript("OnEvent",function(self,event,...)
	if ember[event] then
		ember[event](self,...)
	end
end)
ember:RegisterEvent("PLAYER_LOGIN")
ember:RegisterEvent("BANKFRAME_OPENED")
ember:RegisterEvent("BANKFRAME_CLOSED")
ember:RegisterEvent("PLAYER_REGEN_DISABLED")
ember:RegisterEvent("PLAYER_REGEN_ENABLED")
