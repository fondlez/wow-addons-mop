-- -------------------------------------------------------------------------- --
-- EnhancedStackSplit koKR Localization (Thanks talkswind)                    --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "koKR" then return end
EnhancedStackSplit_Locales:CreateLocaleTable({

	["Original WoW Mode"] = "WoW 원래 모드",
	["1-Click Mode"] = "1-클릭 모드",
	["Auto Split Mode"] = "자동 분리 모드",
	["M"] = "M",
	["Auto"] = "자동",
	["Free Bag Slots"] = "빈 가방 칸",
	["leftover"] = "나머지",

})