-- -------------------------------------------------------------------------- --
-- EnhancedStackSplit deDE Localization                                       --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "deDE" then return end
EnhancedStackSplit_Locales:CreateLocaleTable({

	["Original WoW Mode"] = "Original WoW Modus",
	["1-Click Mode"] = "1-Klick Modus",
	["Auto Split Mode"] = "Auto Split Modus",
	["M"] = "M",
	["Auto"] = "Auto",
	["Free Bag Slots"] = "Freie Taschenplätze",
	["leftover"] = "rest",

})