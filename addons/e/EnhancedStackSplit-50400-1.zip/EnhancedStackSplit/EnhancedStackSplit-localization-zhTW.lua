-- -------------------------------------------------------------------------- --
-- EnhancedStackSplit zhTW Localization (by whocare and NightOwl)             --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "zhTW" then return end
EnhancedStackSplit_Locales:CreateLocaleTable({

	["Original WoW Mode"] = "原始WoW格式",
	["1-Click Mode"] = "單鍵點擊模式",
	["Auto Split Mode"] = "自動分拆模式",
--["M"] = true, -- uppercase short for Mode -- NEEDS TRANSLATION
	["Auto"] = "自動",
	["Free Bag Slots"] = "剩餘背包空格",
	["leftover"] = "剩餘",

})