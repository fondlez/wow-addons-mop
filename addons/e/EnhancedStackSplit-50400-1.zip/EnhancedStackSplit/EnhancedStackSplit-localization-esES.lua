-- -------------------------------------------------------------------------- --
-- EnhancedStackSplit esES Localization (by fili)                             --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "esES" then return end
EnhancedStackSplit_Locales:CreateLocaleTable({

	["Original WoW Mode"] = "Modo original del WOW",
	["1-Click Mode"] = "Modo 1-Clic",
--["Auto Split Mode"] = true, -- NEEDS TRANSLATION
	["M"] = "M",
--["Auto"] = true, -- NEEDS TRANSLATION
--["Free Bag Slots"] = true, -- NEEDS TRANSLATION
--["leftover"] = true, -- NEEDS TRANSLATION

})