-- -------------------------------------------------------------------------- --
-- EnhancedStackSplit zhCN Localization                                       --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "zhCN" then return end
EnhancedStackSplit_Locales:CreateLocaleTable({

	["Original WoW Mode"] = "原始WoW格式",
	["1-Click Mode"] = "单键点击模式",
	["Auto Split Mode"] = "自动分拆模式",
	--["M"] = true, -- uppercase short for Mode -- NEEDS TRANSLATION
	["Auto"] = "自动",
	["Free Bag Slots"] = "剩余背包空格",
	["leftover"] = "剩余",

})
