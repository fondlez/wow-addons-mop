-- -------------------------------------------------------------------------- --
-- EnhancedStackSplit DEFAULT (english) Localization                          --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --

EnhancedStackSplit_Locales = {

	["Original WoW Mode"] = true,
	["1-Click Mode"] = true,
	["Auto Split Mode"] = true,
	["M"] = true, -- uppercase short for Mode
	["Auto"] = true,
	["Free Bag Slots"] = true,
	["leftover"] = true,

}

function EnhancedStackSplit_Locales:CreateLocaleTable(t)
	for k,v in pairs(t) do
		self[k] = (v == true and k) or v
	end
end

EnhancedStackSplit_Locales:CreateLocaleTable(EnhancedStackSplit_Locales)