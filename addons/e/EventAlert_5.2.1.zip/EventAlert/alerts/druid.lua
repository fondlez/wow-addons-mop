function EventAlert_LoadAlerts_Druid()

-- Custom
	if EA_CustomItems[EA_CLASS_DRUID] == nil then EA_CustomItems[EA_CLASS_DRUID] = {} end;

-- Normal
	if EA_Items[EA_CLASS_DRUID] == nil then EA_Items[EA_CLASS_DRUID] = {} end;
    
        -- Mangle
            if EA_Items[EA_CLASS_DRUID][93622] == nil then EA_Items[EA_CLASS_DRUID][93622] = true end;
            
		-- Eclipse
			if EA_Items[EA_CLASS_DRUID][48517] == nil then EA_Items[EA_CLASS_DRUID][48517] = true end;
			if EA_Items[EA_CLASS_DRUID][48518] == nil then EA_Items[EA_CLASS_DRUID][48518] = true end;

		-- Nature's Grace
			if EA_Items[EA_CLASS_DRUID][16886] == nil then EA_Items[EA_CLASS_DRUID][16886] = true end;

		-- Predatory Swiftness
			if EA_Items[EA_CLASS_DRUID][69369] == nil then EA_Items[EA_CLASS_DRUID][69369] = true end;

	    -- Clearcasting (Omen of Clarity)
			if EA_Items[EA_CLASS_DRUID][16870] == nil then EA_Items[EA_CLASS_DRUID][16870] = true end;

	   	-- Owlkin Frenzy
			if EA_Items[EA_CLASS_DRUID][48391] == nil then EA_Items[EA_CLASS_DRUID][48391] = true end;

	   	-- Shooting Stars
			if EA_Items[EA_CLASS_DRUID][93400] == nil then EA_Items[EA_CLASS_DRUID][93400] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_DRUID] == nil then EA_AltItems[EA_CLASS_DRUID] = {} end;
		
		-- Mangle
			if EA_AltItems[EA_CLASS_DRUID][93622] ~= nil then EA_AltItems[EA_CLASS_DRUID][93622] = nil end;
			
-- Stacking
	if EA_StackingItems[EA_CLASS_DRUID] == nil then EA_StackingItems[EA_CLASS_DRUID] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_DRUID] == nil then EA_StackingItemsCounts[EA_CLASS_DRUID] = {} end;

		-- Combo Points
			if EA_StackingItems[EA_CLASS_DRUID][64385] == nil then EA_StackingItems[EA_CLASS_DRUID][64385] = true end;
			if EA_StackingItemsCounts[EA_CLASS_DRUID][64385] == nil then EA_StackingItemsCounts[EA_CLASS_DRUID][64385] = 5 end;
			
--All credit goes to the original author, CurtisTheGreat
end