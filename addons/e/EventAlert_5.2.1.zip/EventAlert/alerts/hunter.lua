function EventAlert_LoadAlerts_Hunter()

-- Custom
	if EA_CustomItems[EA_CLASS_HUNTER] == nil then EA_CustomItems[EA_CLASS_HUNTER] = {} end;

-- Normal
	if EA_Items[EA_CLASS_HUNTER] == nil then EA_Items[EA_CLASS_HUNTER] = {} end;

		-- Fire!
			if EA_Items[EA_CLASS_HUNTER][82926] == nil then EA_Items[EA_CLASS_HUNTER][82926] = true end;

-- Alternate
	if EA_AltItems[EA_CLASS_HUNTER] == nil then EA_AltItems[EA_CLASS_HUNTER] = {} end;

		-- Kill Shot
			if EA_AltItems[EA_CLASS_HUNTER][53351] == nil then EA_AltItems[EA_CLASS_HUNTER][53351] = true end;

-- Stacking
	if EA_StackingItems[EA_CLASS_HUNTER] == nil then EA_StackingItems[EA_CLASS_HUNTER] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_HUNTER] == nil then EA_StackingItemsCounts[EA_CLASS_HUNTER] = {} end;

		-- Thrill of the Hunt
    		if EA_StackingItems[EA_CLASS_HUNTER][34720] == nil then EA_StackingItems[EA_CLASS_HUNTER][34720] = true end;
			if EA_StackingItemsCounts[EA_CLASS_HUNTER][34720] == nil then EA_StackingItemsCounts[EA_CLASS_HUNTER][34720] = 3 end;
		
    	-- Master Marksman
    		if EA_StackingItems[EA_CLASS_HUNTER][82925] == nil then EA_StackingItems[EA_CLASS_HUNTER][82925] = false end;
			if EA_StackingItemsCounts[EA_CLASS_HUNTER][82925] == nil then EA_StackingItemsCounts[EA_CLASS_HUNTER][82925] = 3 end;

		-- Lock and Load
    		if EA_StackingItems[EA_CLASS_HUNTER][56453] == nil then EA_StackingItems[EA_CLASS_HUNTER][56453] = true end;
			if EA_StackingItemsCounts[EA_CLASS_HUNTER][56453] == nil then EA_StackingItemsCounts[EA_CLASS_HUNTER][56453] = 1 end;

--All credit goes to the original author, CurtisTheGreat
end