function EventAlert_LoadAlerts_Priest()

-- Custom
    if EA_CustomItems[EA_CLASS_PRIEST] == nil then EA_CustomItems[EA_CLASS_PRIEST] = {} end;

-- Normal
    if EA_Items[EA_CLASS_PRIEST] == nil then EA_Items[EA_CLASS_PRIEST] = {} end;

        -- Borrowed Time
            if EA_Items[EA_CLASS_PRIEST][59889] == nil then EA_Items[EA_CLASS_PRIEST][59889] = true end;

        -- Divine Insight
            if EA_Items[EA_CLASS_PRIEST][124430] == nil then EA_Items[EA_CLASS_PRIEST][124430] = true end;
            if EA_Items[EA_CLASS_PRIEST][123267] == nil then EA_Items[EA_CLASS_PRIEST][123267] = true end;        

-- Alternate
    if EA_AltItems[EA_CLASS_PRIEST] == nil then EA_AltItems[EA_CLASS_PRIEST] = {} end;

        -- Shadow Word: Death
            if EA_AltItems[EA_CLASS_PRIEST][32379] == nil then EA_AltItems[EA_CLASS_PRIEST][32379] = true end;

-- Stacking
    if EA_StackingItems[EA_CLASS_PRIEST] == nil then EA_StackingItems[EA_CLASS_PRIEST] = {} end;
    if EA_StackingItemsCounts[EA_CLASS_PRIEST] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST] = {} end;

        -- Evangelism
            if EA_StackingItems[EA_CLASS_PRIEST][81661] == nil then EA_StackingItems[EA_CLASS_PRIEST][81661] = true end;
            if EA_StackingItemsCounts[EA_CLASS_PRIEST][81661] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][81661] = 5 end;

        -- Serendipity
            if EA_StackingItems[EA_CLASS_PRIEST][63735] == nil then EA_StackingItems[EA_CLASS_PRIEST][63735] = true end;
            if EA_StackingItemsCounts[EA_CLASS_PRIEST][63735] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][63735] = 2 end;

         -- Surge of Light
            if EA_StackingItems[EA_CLASS_PRIEST][114255] == nil then EA_StackingItems[EA_CLASS_PRIEST][114255] = true end;
            if EA_StackingItemsCounts[EA_CLASS_PRIEST][114255] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][114255] = 1 end;
            
        -- Surge of Darkness
            if EA_StackingItems[EA_CLASS_PRIEST][87160] == nil then EA_StackingItems[EA_CLASS_PRIEST][87160] = true end;
            if EA_StackingItemsCounts[EA_CLASS_PRIEST][87160] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][87160] = 1 end;

        -- Glyph of Mind Spike
            if EA_StackingItems[EA_CLASS_PRIEST][81292] == nil then EA_StackingItems[EA_CLASS_PRIEST][81292] = true end;
            if EA_StackingItemsCounts[EA_CLASS_PRIEST][81292] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][81292] = 2 end;

        -- Shadow Orb
            if EA_StackingItems[EA_CLASS_PRIEST][77487] == nil then EA_StackingItems[EA_CLASS_PRIEST][77487] = true end;
            if EA_StackingItemsCounts[EA_CLASS_PRIEST][77487] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][77487] = 3 end;

--All credit goes to the Original Author, CurtisTheGreat
end