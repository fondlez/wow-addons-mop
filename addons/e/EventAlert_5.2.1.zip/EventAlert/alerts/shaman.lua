function EventAlert_LoadAlerts_Shaman()

-- Custom
	if EA_CustomItems[EA_CLASS_SHAMAN] == nil then EA_CustomItems[EA_CLASS_SHAMAN] = {} end;

-- Normal
	if EA_Items[EA_CLASS_SHAMAN] == nil then EA_Items[EA_CLASS_SHAMAN] = {} end;
			
		-- Lava Surge
			if EA_Items[EA_CLASS_SHAMAN][77762] == nil then EA_Items[EA_CLASS_SHAMAN][77762] = true end;

-- Alternate
	if EA_AltItems[EA_CLASS_SHAMAN] == nil then EA_AltItems[EA_CLASS_SHAMAN] = {} end;

-- Stacking
	if EA_StackingItems[EA_CLASS_SHAMAN] == nil then EA_StackingItems[EA_CLASS_SHAMAN] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_SHAMAN] == nil then EA_StackingItemsCounts[EA_CLASS_SHAMAN] = {} end;
		
		-- Searing Flames
			if EA_StackingItems[EA_CLASS_SHAMAN][77661] == nil then EA_StackingItems[EA_CLASS_SHAMAN][77661] = true end;
			if EA_StackingItemsCounts[EA_CLASS_SHAMAN][77661] == nil then EA_StackingItemsCounts[EA_CLASS_SHAMAN][77661] = 5 end;

		-- Elemental Focus
			if EA_StackingItems[EA_CLASS_SHAMAN][16246] == nil then EA_StackingItems[EA_CLASS_SHAMAN][16246] = true end;
			if EA_StackingItemsCounts[EA_CLASS_SHAMAN][16246] == nil then EA_StackingItemsCounts[EA_CLASS_SHAMAN][16246] = 1 end;

        -- Lightning Shield
			if EA_StackingItems[EA_CLASS_SHAMAN][324] == nil then EA_StackingItems[EA_CLASS_SHAMAN][324] = true end;
	        if EA_StackingItemsCounts[EA_CLASS_SHAMAN][324] == nil then EA_StackingItemsCounts[EA_CLASS_SHAMAN][324] = 6 end;

		-- Maelstrom Weapon
			if EA_StackingItems[EA_CLASS_SHAMAN][53817] == nil then EA_StackingItems[EA_CLASS_SHAMAN][53817] = true end;
			if EA_StackingItemsCounts[EA_CLASS_SHAMAN][53817] == nil then EA_StackingItemsCounts[EA_CLASS_SHAMAN][53817] = 5 end;

		-- Tidal Waves
			if EA_StackingItems[EA_CLASS_SHAMAN][53390] == nil then EA_StackingItems[EA_CLASS_SHAMAN][53390] = true end;
			if EA_StackingItemsCounts[EA_CLASS_SHAMAN][53390] == nil then EA_StackingItemsCounts[EA_CLASS_SHAMAN][53390] = 1 end;

--All credit goes to the original author, CurtisTheGreat
end