function EventAlert_LoadAlerts_Warlock()

-- Custom
	if EA_CustomItems[EA_CLASS_WARLOCK] == nil then EA_CustomItems[EA_CLASS_WARLOCK] = {} end;

-- Normal
	if EA_Items[EA_CLASS_WARLOCK] == nil then EA_Items[EA_CLASS_WARLOCK] = {} end;

		-- Backlash
			if EA_Items[EA_CLASS_WARLOCK][34936] == nil then EA_Items[EA_CLASS_WARLOCK][34936] = true end;

		-- Nightfall
			if EA_Items[EA_CLASS_WARLOCK][17941] == nil then EA_Items[EA_CLASS_WARLOCK][17941] = true end;

		-- Demonic Rebirth
			if EA_Items[EA_CLASS_WARLOCK][88448] == nil then EA_Items[EA_CLASS_WARLOCK][88448] = true end;
		
-- Alternate
	if EA_AltItems[EA_CLASS_WARLOCK] == nil then EA_AltItems[EA_CLASS_WARLOCK] = {} end;

		-- Shadowburn
			if EA_AltItems[EA_CLASS_WARLOCK][17877] == nil then EA_AltItems[EA_CLASS_WARLOCK][17877] = true end;

-- Stacking
	if EA_StackingItems[EA_CLASS_WARLOCK] == nil then EA_StackingItems[EA_CLASS_WARLOCK] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_WARLOCK] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK] = {} end;

		-- Molten Core
			if EA_StackingItems[EA_CLASS_WARLOCK][122355] == nil then EA_StackingItems[EA_CLASS_WARLOCK][122355] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARLOCK][122355] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK][122355] = 1 end;

		-- Havoc
			if EA_StackingItems[EA_CLASS_WARLOCK][80240] == nil then EA_StackingItems[EA_CLASS_WARLOCK][80240] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARLOCK][80240] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK][80240] = 1 end;
		
		-- Backdraft
			if EA_StackingItems[EA_CLASS_WARLOCK][117828] == nil then EA_StackingItems[EA_CLASS_WARLOCK][117828] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARLOCK][117828] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK][117828] = 1 end;
	
		-- Soul Shards
			if EA_StackingItems[EA_CLASS_WARLOCK][87388] == nil then EA_StackingItems[EA_CLASS_WARLOCK][87388] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARLOCK][87388] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK][87388] = 3 end;

		-- Burning Embers
			if EA_StackingItems[EA_CLASS_WARLOCK][108647] == nil then EA_StackingItems[EA_CLASS_WARLOCK][108647] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARLOCK][108647] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK][108647] = 3 end;

		-- Demonic Fury
			if EA_StackingItems[EA_CLASS_WARLOCK][104314] == nil then EA_StackingItems[EA_CLASS_WARLOCK][104314] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARLOCK][104314] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK][104314] = 1000 end;

--All credit goes to the original author, CurtisTheGreat
end