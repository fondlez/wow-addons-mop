function EventAlert_LoadAlerts_Paladin()

-- Custom
	if EA_CustomItems[EA_CLASS_PALADIN] == nil then EA_CustomItems[EA_CLASS_PALADIN] = {} end;

-- Normal
	if EA_Items[EA_CLASS_PALADIN] == nil then EA_Items[EA_CLASS_PALADIN] = {} end;

  		-- Daybreak
			if EA_Items[EA_CLASS_PALADIN][88819] == nil then EA_Items[EA_CLASS_PALADIN][88819] = true end;

		-- Denounce
			if EA_Items[EA_CLASS_PALADIN][115654] == nil then EA_Items[EA_CLASS_PALADIN][115654] = true end;

  		-- Grand Crusader
			if EA_Items[EA_CLASS_PALADIN][85416] == nil then EA_Items[EA_CLASS_PALADIN][85416] = true end;

  		-- Divine Purpose
			if EA_Items[EA_CLASS_PALADIN][90174] == nil then EA_Items[EA_CLASS_PALADIN][90174] = true end;

		-- Infusion of Light
			if EA_Items[EA_CLASS_PALADIN][54149] == nil then EA_Items[EA_CLASS_PALADIN][54149] = true end;

		-- Double Jeopardy
			if EA_Items[EA_CLASS_PALADIN][121027] == nil then EA_Items[EA_CLASS_PALADIN][121027] = false end;

-- Alternate
	if EA_AltItems[EA_CLASS_PALADIN] == nil then EA_AltItems[EA_CLASS_PALADIN] = {} end;

		-- Art of War
			if EA_AltItems[EA_CLASS_PALADIN][59578] == nil then EA_AltItems[EA_CLASS_PALADIN][59578] = true end;
        -- Hammer of Wrath
			if EA_AltItems[EA_CLASS_PALADIN][24275] == nil then EA_AltItems[EA_CLASS_PALADIN][24275] = true end;

-- Stacking
	if EA_StackingItems[EA_CLASS_PALADIN] == nil then EA_StackingItems[EA_CLASS_PALADIN] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_PALADIN] == nil then EA_StackingItemsCounts[EA_CLASS_PALADIN] = {} end;
		
		-- Bastion of Glory
			if EA_StackingItems[EA_CLASS_PALADIN][114637] == nil then EA_StackingItems[EA_CLASS_PALADIN][114637] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PALADIN][114637] == nil then EA_StackingItemsCounts[EA_CLASS_PALADIN][114637] = 5 end;
			
		-- Selfless Healer
			if EA_StackingItems[EA_CLASS_PALADIN][114250] == nil then EA_StackingItems[EA_CLASS_PALADIN][114250] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PALADIN][114250] == nil then EA_StackingItemsCounts[EA_CLASS_PALADIN][114250] = 3 end;

    	-- Holy Power
			if EA_StackingItems[EA_CLASS_PALADIN][85247] == nil then EA_StackingItems[EA_CLASS_PALADIN][85247] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PALADIN][85247] == nil then EA_StackingItemsCounts[EA_CLASS_PALADIN][85247] = 3 end;

--All credit goes to the original author, CurtisTheGreat
end