function EventAlert_LoadAlerts_Warrior()

-- Custom
	if EA_CustomItems[EA_CLASS_WARRIOR] == nil then EA_CustomItems[EA_CLASS_WARRIOR] = {} end;

-- Normal
	if EA_Items[EA_CLASS_WARRIOR] == nil then EA_Items[EA_CLASS_WARRIOR] = {} end;

		-- Victory Rush
			if EA_Items[EA_CLASS_WARRIOR][32216] == nil then EA_Items[EA_CLASS_WARRIOR][32216] = true end;

		-- Incite
			if EA_Items[EA_CLASS_WARRIOR][122016] == nil then EA_Items[EA_CLASS_WARRIOR][122016] = true end;

		-- Sudden Death
			if EA_Items[EA_CLASS_WARRIOR][52437] == nil then EA_Items[EA_CLASS_WARRIOR][52437] = true end;

		-- Sword and Board
			if EA_Items[EA_CLASS_WARRIOR][50227] == nil then EA_Items[EA_CLASS_WARRIOR][50227] = true end;

		-- Ultimatum
			if EA_Items[EA_CLASS_WARRIOR][122510] == nil then EA_Items[EA_CLASS_WARRIOR][122510] = true end;

		-- Glyph of Hamstring
			if EA_Items[EA_CLASS_WARRIOR][115945] == nil then EA_Items[EA_CLASS_WARRIOR][115945] = false end;

-- Alternate
	if EA_AltItems[EA_CLASS_WARRIOR] == nil then EA_AltItems[EA_CLASS_WARRIOR] = {} end;

		-- Overpower
	    	if EA_AltItems[EA_CLASS_WARRIOR][7384] == nil then EA_AltItems[EA_CLASS_WARRIOR][7384] = true end;

		-- Execute
	    	if EA_AltItems[EA_CLASS_WARRIOR][5308] == nil then EA_AltItems[EA_CLASS_WARRIOR][5308] = true end;

		-- Revenge
	    	if EA_AltItems[EA_CLASS_WARRIOR][6572] == nil then EA_AltItems[EA_CLASS_WARRIOR][6572] = true end;

--Stacking
	if EA_StackingItems[EA_CLASS_WARRIOR] == nil then EA_StackingItems[EA_CLASS_WARRIOR] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_WARRIOR] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR] = {} end;

		-- Taste for Blood (Deprecated with 5.2)
			if EA_StackingItems[EA_CLASS_WARRIOR][125831] ~= nil then EA_StackingItems[EA_CLASS_WARRIOR][125831] = nil end;
			if EA_StackingItemsCounts[EA_CLASS_WARRIOR][125831] ~= nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][125831] = nil end;

		-- Taste for Blood (New buff)
			if EA_StackingItems[EA_CLASS_WARRIOR][60503] == nil then EA_StackingItems[EA_CLASS_WARRIOR][60503] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARRIOR][60503] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][60503] = 1 end;

		-- Raging Blow!
			if EA_StackingItems[EA_CLASS_WARRIOR][131116] == nil then EA_StackingItems[EA_CLASS_WARRIOR][131116] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARRIOR][131116] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][131116] = 1 end;

		-- Blood Surge
			if EA_StackingItems[EA_CLASS_WARRIOR][46916] == nil then EA_StackingItems[EA_CLASS_WARRIOR][46916] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARRIOR][46916] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][46916] = 1 end;

		-- Meat Cleaver
			if EA_StackingItems[EA_CLASS_WARRIOR][85739] == nil then EA_StackingItems[EA_CLASS_WARRIOR][85739] = true end;
			if EA_StackingItemsCounts[EA_CLASS_WARRIOR][85739] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][85739] = 3 end;

--All credit goes to the original author, CurtisTheGreat
end