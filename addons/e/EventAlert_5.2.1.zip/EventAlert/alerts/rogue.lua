function EventAlert_LoadAlerts_Rogue()

-- Custom
	if EA_CustomItems[EA_CLASS_ROGUE] == nil then EA_CustomItems[EA_CLASS_ROGUE] = {} end;

-- Normal
	if EA_Items[EA_CLASS_ROGUE] == nil then EA_Items[EA_CLASS_ROGUE] = {} end;

		-- Blindside
			if EA_Items[EA_CLASS_ROGUE][121153] == nil then EA_Items[EA_CLASS_ROGUE][121153] = true end;
		
-- Alternate
	if EA_AltItems[EA_CLASS_ROGUE] == nil then EA_AltItems[EA_CLASS_ROGUE] = {} end;

		-- Dispatch
	    	if EA_AltItems[EA_CLASS_ROGUE][111240] == nil then EA_AltItems[EA_CLASS_ROGUE][111240] = true end;

-- Stacking
	if EA_StackingItems[EA_CLASS_ROGUE] == nil then EA_StackingItems[EA_CLASS_ROGUE] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_ROGUE] == nil then EA_StackingItemsCounts[EA_CLASS_ROGUE] = {} end;

		-- Combo Points
			if EA_StackingItems[EA_CLASS_ROGUE][64385] == nil then EA_StackingItems[EA_CLASS_ROGUE][64385] = true end;
			if EA_StackingItemsCounts[EA_CLASS_ROGUE][64385] == nil then EA_StackingItemsCounts[EA_CLASS_ROGUE][64385] = 5 end;

		-- Anticipation
			if EA_StackingItems[EA_CLASS_ROGUE][115189] == nil then EA_StackingItems[EA_CLASS_ROGUE][115189] = true end;
			if EA_StackingItemsCounts[EA_CLASS_ROGUE][115189] == nil then EA_StackingItemsCounts[EA_CLASS_ROGUE][115189] = 5 end;

--All credit goes to the original author, CurtisTheGreat
end