local E, L, V, P, G = unpack(ElvUI)

V.enhanced = {
	animatedAchievementBars = false,
	datatextColors = false,
	deathRecap = false,
	farmer = {
		enabled = false
	}
}