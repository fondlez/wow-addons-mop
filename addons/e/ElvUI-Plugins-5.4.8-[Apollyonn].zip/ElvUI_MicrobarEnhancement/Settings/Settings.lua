﻿local E, L, V, P, G = unpack(ElvUI)

P.actionbar.microbar.symbolic = false
P.actionbar.microbar.classColor = false
P.actionbar.microbar.transparentButtons = false
P.actionbar.microbar.colorS = {r = 1, g = 1, b = 1}