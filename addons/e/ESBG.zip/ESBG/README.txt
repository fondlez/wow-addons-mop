

Get rid of all those annoying pesky GCD error sounds so you can enjoy the nice sound of battle instead.

Enjoy
Install Guide READ ME FIRST

Extract the \Sound folder into your <DIR>\World of Warcraft\

Example

H:\World of Warcraft\Sound\

    * enUS or any other language 


