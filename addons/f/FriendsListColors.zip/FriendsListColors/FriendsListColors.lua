local format = format
local pairs = pairs
local print = print
local table = table
local tostring = tostring
local type = type

local GRAY_FONT_COLOR_CODE = GRAY_FONT_COLOR_CODE
local GREEN_FONT_COLOR_CODE = GREEN_FONT_COLOR_CODE
local ORANGE_FONT_COLOR_CODE = ORANGE_FONT_COLOR_CODE
local RED_FONT_COLOR_CODE = RED_FONT_COLOR_CODE
local YELLOW_FONT_COLOR_CODE = YELLOW_FONT_COLOR_CODE

local FONT_COLOR_CODE_CLOSE = FONT_COLOR_CODE_CLOSE
local FRIENDS_BUTTON_TYPE_BNET = FRIENDS_BUTTON_TYPE_BNET
local FRIENDS_BUTTON_TYPE_WOW = FRIENDS_BUTTON_TYPE_WOW
local FRIENDS_FRIENDS_TO_DISPLAY = FRIENDS_FRIENDS_TO_DISPLAY
local LEVEL = LEVEL

local FriendsFrameFriendsScrollFrameScrollBar = FriendsFrameFriendsScrollFrameScrollBar
local FriendsList_Update = FriendsList_Update
local GetFriendInfo = GetFriendInfo
local hooksecurefunc = hooksecurefunc
local UnitLevel = UnitLevel

local BattleTagColor = format("%02x%02x%02x", FRIENDS_BNET_NAME_COLOR.r*255, FRIENDS_BNET_NAME_COLOR.g*255, FRIENDS_BNET_NAME_COLOR.b*255)

-- create addon frame (hidden) and declare default variables
local addonName = ...
local f, cfg, db = CreateFrame("Frame"), {
  name="FriendsListColors",
  sname="FLC",
  slash={"/flc", "/friendslistcolors"},
  syntaxes={
    {"N", "C", "L", "Z", "S", "O", "B"},
    {"NC", "CC", "LC", "ZC", "SC", "OC", "BC"},
    {"ND", "CD", "LD", "ZD", "SD", "OD", "BD"},
    {"NT", "CT", "LT", "ZT", "ST", "OT", "BT"},
    {"Name", "Class", "Level", "Zone", "AFK/DNS", "Note", "BattleTag"},
  },
  ccolors={},
  gray=GRAY_FONT_COLOR_CODE:sub(5),
  dummy={"Vladinator", "Druid", 85, "Good tank", "Stormwind City"},
  -- default configuration values if unconfigured
  defaults={
    syntax="$BT, $NC, {D!LEVEL} $LD $C", -- "BattleTag Name, Level 80, Shaman" where name is colored by class, level is colored by difficulty and class without specific color
    syntax2="$B $N", -- "BattleTag Name"
  },
}

-- populate ccolors table
for k, v in pairs(CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)do cfg.ccolors[k] = (v.colorStr or format("ff%02x%02x%02x", v.r*255, v.g*255, v.b*255)):sub(3) end

-- localized classes, i.e. locclasses["Magier"] returns "Mage"
local locclasses = {}
for k,v in pairs(LOCALIZED_CLASS_NAMES_MALE)do locclasses[v] = k end
for k,v in pairs(LOCALIZED_CLASS_NAMES_FEMALE)do locclasses[v] = k end

-- output
local function out(msg)
  print(format("|cff00ffff%s|r: %s", cfg.sname, tostring(msg)))
end

-- returns hex color (xxyyzz) using player level and an argument as "target level"
local function getDiff(tar)
  local diff, col = tar - UnitLevel("player")
  if diff > 4 then
    col = RED_FONT_COLOR_CODE
  elseif diff > 2 then
    col = ORANGE_FONT_COLOR_CODE -- need more orange, this is like /emote
  elseif diff >= 0 then
    col = YELLOW_FONT_COLOR_CODE
  elseif diff >= -4 then
    col = GREEN_FONT_COLOR_CODE -- too bright green
  else
    col = GRAY_FONT_COLOR_CODE
  end
  return col:sub(0,4) == "|cff" and col:sub(5) or col -- remove "|cff" if present (don't know what will happen in the future with these constants)
end

-- format entries by special syntax I've defined for this addon
local function form(str, ...) -- ... = 1:name, 2:class, 3:level, 4:zone, 5:status, 6:note, 7:battletag
  if type(str) ~= "string" or str:len() == 0 then
    return "Fatal error in "..cfg.sname..", what have you done?" -- something fatal happen, oh no!
  end
  local values, code = {...}
  if #values > 0 then
    local dcolor = getDiff(tonumber(values[3]) or 0) -- with fallback value
    local ccolor = cfg.ccolors[(locclasses[values[2] or ""] or ""):gsub(" ",""):upper()] or cfg.gray -- with fallback value
    local syntaxes = cfg.syntaxes
    -- handle double chars like $XY
    for code in str:gmatch("%$%u%u") do
      -- color by class
      for k,v in pairs(syntaxes[2]) do
        if code == "$"..v then
          str = str:gsub(code, format("|cff%s%s%s", ccolor, values[k] or "", FONT_COLOR_CODE_CLOSE))
          break
        end
      end
      -- color by difficulty
      for k,v in pairs(syntaxes[3]) do
        if code == "$"..v then
          str = str:gsub(code, format("|cff%s%s%s", dcolor, values[k] or "", FONT_COLOR_CODE_CLOSE))
          break
        end
      end
      -- color by realid color
      for k,v in pairs(syntaxes[4]) do
        if code == "$"..v then
          if (values[k] or ""):len() == 0 then
            str = str:gsub(code, "")
            str = str:gsub("^%p%s", "") -- if no realid and a separator is found, strip it away for the sake of beauty!
          else
            str = str:gsub(code, format("|cff%s%s%s", BattleTagColor, values[k] or "", FONT_COLOR_CODE_CLOSE))
          end
          break
        end
      end
    end
    -- handle single chars like $X
    for code in str:gmatch("%$%u") do
      for k,v in pairs(syntaxes[1]) do
        if code == "$"..v then
          str = str:gsub(code, values[k] or "")
          break
        end
      end
    end
    -- global variables {!LEVEL} becomes "Level" localized or just pure string if it's not found in _G
    for code in str:gmatch("%{%!(.+)%}") do
      str = str:gsub("%{%!"..code.."%}", _G[code] and tostring(_G[code]) or code)
    end
    -- global variables {X!LEVEL} (where X is C or D) becomes "Level" localized or just pure string if it's not found in _G. it's also colored by class or difficulty color
    for code1, code2 in str:gmatch("%{(%u)%!(.+)%}") do
      if code1 == "C" then
        str = str:gsub("%{"..code1.."%!"..code2.."%}", format("|cff%s%s%s", ccolor, _G[code2] and tostring(_G[code2]) or code2, FONT_COLOR_CODE_CLOSE))
      elseif code1 == "D" then
        str = str:gsub("%{"..code1.."%!"..code2.."%}", format("|cff%s%s%s", dcolor, _G[code2] and tostring(_G[code2]) or code2, FONT_COLOR_CODE_CLOSE))
      else
        str = str:gsub("%{"..code1.."%!"..code2.."%}", _G[code2] and tostring(_G[code2]) or code2) -- fallback, no coloring
      end
    end
  end
  return str:trim()
end

-- function will be referenced by the hook on the bottom and called when the friend list is updated by scrolling or the event is fired to update it
local function updFunc()
  for index = 1, FRIENDS_FRIENDS_TO_DISPLAY do
    local friend = _G["FriendsFrameFriendsScrollFrameButton"..index]
    if friend and (friend.buttonType == FRIENDS_BUTTON_TYPE_BNET or friend.buttonType == FRIENDS_BUTTON_TYPE_WOW) and type(friend.id) == "number" then
      if friend.buttonType == FRIENDS_BUTTON_TYPE_BNET then
        local _, realName, _, _, _, _, client, connected, _, status1, status2, _, note, _, _ = BNGetFriendInfo(friend.id)
        local alias = (note or ""):match("%^(.-)%$")
        if connected and client == BNET_CLIENT_WOW then -- we only care if they play wow
          local numToons = BNGetNumFriendToons(friend.id)
          local client2, name, class, zone, level
          for i = 1, numToons or 0 do
            _, name, client2, _, _, _, _, class, _, zone, level = BNGetFriendToonInfo(friend.id, i)
            if name and client2 == BNET_CLIENT_WOW then -- can be on several "toons" on various clients
              if status1 then
                status = "<"..AFK..">"
              elseif status2 then
                status = "<"..DND..">"
              else
                status = ""
              end
              friend.name:SetText(form(db.syntax, name, class, level or 0, zone or "", status or "", note or "", alias or realName or ""))
              friend.name:SetTextColor(FRIENDS_WOW_NAME_COLOR.r, FRIENDS_WOW_NAME_COLOR.g, FRIENDS_WOW_NAME_COLOR.b)
              friend.name.antiAlias = realName
            end
          end
        elseif not connected then -- append note at the end, like normal friends are shown when offline
          friend.name:SetText(form(db.syntax2, "", "", 0, "", "", note or "", alias or realName or ""))
          friend.name:SetTextColor(FRIENDS_GRAY_COLOR.r, FRIENDS_GRAY_COLOR.g, FRIENDS_GRAY_COLOR.b)
          friend.name.antiAlias = realName
        end
      else
        local name, level, class, zone, connected, status, note = GetFriendInfo(friend.id)
        if name then
          local alias = (note or ""):match("%^(.-)%$")
          friend.name:SetText(form(connected and db.syntax or db.syntax2, alias or name, class, level, zone or "", status or "", note or "", ""))
          friend.name.antiAlias = name
        end
      end
    end
  end
end

-- once addon loads, load settings and hook Blizzards functions
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, event, addon)
  if addon == cfg.name or addon == addonName then -- support loading when embedded
    FriendsListColorsDB = FriendsListColorsDB or cfg.defaults
    db = FriendsListColorsDB
    FriendsFrameFriendsScrollFrameScrollBar:HookScript("OnValueChanged", function(self, pos, ...)
      -- trying to avoid overloading it when scrolling up/down but it's not easy to avoid RAM usage from sky-rocketing if user scrolls up and down like crazy in a short time, the RAM will go up to ~2MB at max before being garbage collected -the idle I am happy with, 20KB and 40KB when the list is shown, simple drag to the bottom and back up leaves it around 500KB at max, can't avoid that either...
      self.FLClastPos = self.FLClastPos or -1
      local dig = format("%d", pos)
      if self.FLClastPos-dig > 2 or self.FLClastPos-dig < -2 then
        self.FLClastPos = dig
        updFunc()
      end
    end)
    for _, v in pairs({"FriendsList_Update", "FriendsFrame_UpdateFriends", "FriendsFramePendingScrollFrame_AdjustScroll"}) do
      hooksecurefunc(v, updFunc)
    end
    -- handle slash commands
    for k, v in pairs(cfg.slash) do _G["SLASH_"..cfg.name:upper()..k] = v end
    SlashCmdList[cfg.name:upper()] = function(msg, editbox)
      local param1, param2, nohelp = (" "):split(msg, 2)
      param1 = param1:lower() or ""
      param2 = param2 or ""
      if param1 == "syntax" and param2:len() > 0 then
        param2 = param2:gsub("||", "|") -- support saving color codes from the chat
        db.syntax = param2 -- store the new syntax in the database for usage right away!
        out(format("The new syntax is: |cff00cc88%s|r", db.syntax:gsub("|", "||")))
        nohelp = 1
      elseif param1 == "syntax2" and param2:len() > 0 then
        param2 = param2:gsub("||", "|") -- support saving color codes from the chat
        db.syntax2 = param2 -- store the new syntax in the database for usage right away!
        out(format("The new syntax for offliners is: |cff00cc88%s|r", db.syntax2:gsub("|", "||")))
        nohelp = 1
      elseif param1 == "vars" then
        local tmp
        if param2 == "basic" then
          tmp = ""
          for k,v in pairs(cfg.syntaxes[1]) do
            tmp = tmp.."|cff00ff00$"..v.."|r |cff999999("..cfg.syntaxes[5][k]:lower()..")|r, "
          end
          tmp = tmp:sub(0,tmp:len()-2)
          out("The basic variables are on the format |cff00ff00$X|r where |cff00ff00X|r is a letter. The full list is: "..tmp..".")
        elseif param2 == "cbasic" then
          out(format("You can color the basic variables in a simple way by adding another letter at the end, that is either |cff00ff00C|r |cff999999(for class color)|r, |cff00ff00D|r |cff999999(for difficulty, level difference)|r or |cff00ff00T|r |cff999999(for BattleTag color)|r. For example |cff00ff00$NC|r would color the name by class color, |cff00ff00$LD|r would color the level by difficulty."))
        elseif param2 == "adv" then
          out(format("You can use global variables like |cff00ff00{!LEVEL}|r and the addon will turn that into the value of \"LEVEL\" |cff999999(LEVEL equals \""..(LEVEL or "").."\" but on another locale it would adapt)|r. You can color it by using either |cff00ff00C|r, |cff00ff00D|r or |cff00ff00T|r, by using this syntax |cff00ff00{D!LEVEL}|r. If it does not exist it will simply print is as message and color it if color flag is present."))
        elseif param2 == "cadv" then
          out(format("You can use |cff00ff00{!X}|r for many tricks, for example you could write |cff00ff00{!||cffff0000$N}|r and it would color the name in red text. |cff00ff00{C!$N}|r would color the name by class color, this is an alias to |cff00ff00$NC|r that is. Now that you get the pattern I am sure you can handle the rest."))
        elseif param2 == "ex" then
          out("Here you have some examples of what you can do:")
          out(format("|cff00ff55/flc syntax {D!L}$LD $NC $O|r = |cff"..getDiff(cfg.dummy[3]).."L"..cfg.dummy[3].."|r |cff"..cfg.ccolors[cfg.dummy[2]:upper()]..cfg.dummy[1].."|r "..cfg.dummy[4]))
          out(format("|cff00ff55/flc syntax $NC, {D!LEVEL} $LD {!||cff555555$O||r}|r = |cff"..cfg.ccolors[cfg.dummy[2]:upper()]..cfg.dummy[1].."|r, |cff"..getDiff(cfg.dummy[3]).."Level "..cfg.dummy[3].."|r |cff555555"..cfg.dummy[4].."|r"))
          out(format("|cff00ff55/flc syntax {C!$N $C} {D!$L} $Z|r = |cff"..cfg.ccolors[cfg.dummy[2]:upper()]..cfg.dummy[1].." "..cfg.dummy[2].."|r |cff"..getDiff(cfg.dummy[3])..cfg.dummy[3].."|r "..cfg.dummy[5]))
        else
          out("Pick a sub-category:")
          out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "vars", "basic", "basic variable usage"))
          out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "vars", "cbasic", "how to color basic variables"))
          out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "vars", "adv", "advance usage of custom text and variables"))
          out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "vars", "cadv", "how to color advanced variables"))
          out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "vars", "ex", "show some examples"))
        end
        nohelp = 1
      elseif param1 == "reset" then
        local backup1, backup2 = db.backup or "", db.backup2 or ""
        table.wipe(db)
        db.syntax = cfg.defaults.syntax
        db.syntax2 = cfg.defaults.syntax2
        if backup1:len() > 0 or backup2:len() > 0 then
          db.backup, db.backup2 = backup1, backup2
        end
        out(format("The syntaxes were reset back to |cff00cc88%s|r and |cff00cc88%s|r for offliners.", (db.syntax or ""):gsub("|", "||"), (db.syntax2 or ""):gsub("|", "||")))
        nohelp = 1
      elseif param1 == "backup" then
        db.backup = db.syntax or ""
        db.backup2 = db.syntax2 or ""
        out(format("Made a backup of the syntax |cff00cc88%s|r and |cff00cc88%s|r for offliners.", (db.backup or ""):gsub("|", "||"), (db.backup2 or ""):gsub("|", "||")))
        nohelp = 1
      elseif param1 == "restore" then
        if (db.backup or ""):len() > 0 or (db.backup2 or ""):len() > 0 then
          db.syntax = db.backup
          db.syntax2 = db.backup2
          out(format("Restored syntaxes from backup: |cff00cc88%s|r and |cff00cc88%s|r for offliners.", db.syntax:gsub("|", "||"), db.syntax2:gsub("|", "||")))
        else
          out("Couldn't restore because your backup is empty.")
        end
        nohelp = 1
      end
      if not nohelp then
        out(cfg.name.." available commands:")
        --out(format("%s |cff00ff55%s|r %s", cfg.slash[1], "help", "this list of commands"))
        out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "syntax", db.syntax:gsub("|", "||") or "", "|rchange how friends are shown"))
        out(format("%s |cff00ff55%s|r |cff00cc88%s|r %s", cfg.slash[1], "syntax2", db.syntax2:gsub("|", "||") or "", "|rchange how offline friends are shown"))
        out(format("%s |cff00ff55%s|r %s", cfg.slash[1], "vars", "list of variables you can use in |cff00ff55syntax|r"))
        out(format("%s |cff00ff55%s|r %s", cfg.slash[1], "backup", "backup the current |cff00ff55syntax|res"))
        out(format("%s |cff00ff55%s|r %s", cfg.slash[1], "restore", "restore the |cff00ff55syntax|res from the |cff00ff55backup|r storage"))
        out(format("%s |cff00ff55%s|r %s", cfg.slash[1], "reset", "reset the addon back to default (keeps |cff00ff55backup|r if any)"))
        if FriendsListColors_Alias then
          out("The |cffeda55fAlias|r module allows you to add |cff00cc88^Name$|r to a persons note to use that as their name. You can put this anywhere in the note.")
        end
      end
      FriendsList_Update()
    end
    -- unregister the script because the addon has loaded
    self:UnregisterEvent(event)
    self:SetScript("OnEvent", nil)
  end
end)
