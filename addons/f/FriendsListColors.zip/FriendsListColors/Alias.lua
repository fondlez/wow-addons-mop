local pairs = pairs
local table = table
local tonumber = tonumber
local type = type
local unpack = unpack

local format = format
local gsub = string.gsub
local find = string.find
local match = string.match
local trim = string.trim

local BNGetFriendInfo = BNGetFriendInfo
local BNGetFriendInfoByID = BNGetFriendInfoByID
local BNGetNumFriends = BNGetNumFriends
local BN_CONVERSATION_INVITE_NUM_DISPLAYED = BN_CONVERSATION_INVITE_NUM_DISPLAYED
local FRIENDS_BUTTON_TYPE_BNET = FRIENDS_BUTTON_TYPE_BNET
local FRIENDS_FRIENDS_TO_DISPLAY = FRIENDS_FRIENDS_TO_DISPLAY
local GetFriendInfo = GetFriendInfo
local GetNumFriends = GetNumFriends

local db = {}

local function ReplaceText(frame)
  if type(frame) == "table" and frame.SetText and frame.GetText then
    local text = frame:GetText()
    if text and text ~= "" then
      for name, alias in pairs(db) do
        if find(text, name, nil, true) then
          frame:SetText(gsub(text, name, alias))
          break
        end
      end
    end
  end
end

local function GetAliasFromNote(pid, isFriend)
  if not pid then
    return
  end
  if isFriend then
    return trim(db[pid] or pid), pid
  end
  local _, name, _, _, _, _, _, _, _, _, _, _, text = BNGetFriendInfoByID(pid)
  if name and text then
    text = match(text, "%^(.-)%$")
    if text then
      return trim(text), name
    end
  end
end

local function Database_Update(noUpdate)
  table.wipe(db)
  for i = 1, BNGetNumFriends() do
    local alias, name = GetAliasFromNote(BNGetFriendInfo(i), nil)
    if alias and name then
      db[name] = alias
    end
  end
  for i = 1, GetNumFriends() do
    local name, _, _, _, _, _, note = GetFriendInfo(i)
    if name and note then
      local alias = match(note, "%^(.-)%$")
      if alias then
        db[name] = alias
      end
    end
  end
  if not noUpdate then
    FriendsFriendsList_Update()
  end
end

local function GetAliasByPID(raw)
  if type(raw) == "string" then
    return GetAliasFromNote(tonumber(match(raw, "|Kf(%d+)|k")))
  elseif type(raw) == "number" then
    return GetAliasFromNote(raw)
  end
end

local function GetAliasByFriendName(raw)
  if type(raw) == "string" then
    return GetAliasFromNote(raw, 1)
  end
end

local ReplaceLink
do
  local temp, pid, suffix, name

  local function Gsub_BNPlayer(...)
    temp = {...}
    pid, suffix = match(temp[6], "|Kf(.-)|k(.-)|k")
    if pid and suffix then
      name = GetAliasByPID(tonumber(pid))
      if name then
        temp[6] = gsub(temp[6], "|Kf"..pid.."|k"..suffix.."|k", name)
      end
    end
    return format("|HBNplayer:%s:%s:%s:%s:%s|h%s|h", unpack(temp))
  end

  local function Gsub_Player(...)
    temp = {...}
    temp[5] = gsub(temp[5], temp[1], GetAliasByFriendName(temp[1]) or temp[1])
    return format("|Hplayer:%s:%s:%s:%s|h%s|h", unpack(temp))
  end

  local function Gsub_PlayerPlain1(target, name)
    name = GetAliasByFriendName(name) or name
    return format(ERR_FRIEND_ONLINE_SS, target, name)
  end

  local function Gsub_PlayerPlain2(name)
    name = GetAliasByFriendName(name) or name
    return format(ERR_FRIEND_OFFLINE_S, name)
  end

  function ReplaceLink(text)
    text = gsub(text, "|HBNplayer:(.-):(.-):(.-):(.-):(.-)|h(.-)|h", Gsub_BNPlayer)
    text = gsub(text, "|Hplayer:(.-):(.-):(.-):(.-)|h(.-)|h", Gsub_Player)
    text = gsub(text, gsub(gsub(gsub(gsub(ERR_FRIEND_ONLINE_SS, "%.", "%%%."), "%%s", "(.-)"), "%[", "%%%["), "%]", "%%%]"), Gsub_PlayerPlain1)
    text = gsub(text, gsub(gsub(gsub(gsub(ERR_FRIEND_OFFLINE_S, "%.", "%%%."), "%%s", "(.+)"), "%[", "%%%["), "%]", "%%%]"), Gsub_PlayerPlain2)
    return text
  end
end

do
  BNToastFrame:HookScript("OnShow", function(self) ReplaceText(BNToastFrameTopLine) end)
  FriendsTooltip:HookScript("OnShow", function(self) ReplaceText(FriendsTooltipHeader) end)
	hooksecurefunc("FriendsFrameTooltip_Show", function(self) ReplaceText(FriendsTooltipHeader) end)
	hooksecurefunc("FriendsFrame_ShowBNDropdown", function() ReplaceText(DropDownList1Button1) end)
  hooksecurefunc("FriendsFrame_ShowDropdown", function() ReplaceText(DropDownList1Button1) end)
  hooksecurefunc(StaticPopupDialogs["SET_BNFRIENDNOTE"], "OnShow", function(self) ReplaceText(self.text) end)
  hooksecurefunc(StaticPopupDialogs["SET_FRIENDNOTE"], "OnShow", function(self) ReplaceText(self.text) end)

  hooksecurefunc("HybridScrollFrame_Update", function(self)
    if self == FriendsFrameFriendsScrollFrame then
      local buttons = FriendsFrameFriendsScrollFrame.buttons
      for i, button in pairs(buttons) do
        if button.buttonType == FRIENDS_BUTTON_TYPE_BNET then
          ReplaceText(button.name)
        end
      end
    end
  end)

  hooksecurefunc("FriendsFriendsList_Update", function()
    ReplaceText(FriendsFriendsFrameTitle)
    for i = 1, FRIENDS_FRIENDS_TO_DISPLAY do
      ReplaceText((_G["FriendsFriendsButton"..i] or {}).name)
    end
  end)

  hooksecurefunc("BNConversationInvite_Update", function()
    for i = 1, BN_CONVERSATION_INVITE_NUM_DISPLAYED do
      ReplaceText((_G["BNConversationInviteDialogListFriend"..i] or {}).name)
    end
  end)

  hooksecurefunc("ChatEdit_UpdateHeader", function(editBox)
    local type = editBox:GetAttribute("chatType")
    if not type then
      return
    end
    local info = ChatTypeInfo[type]
    local header = _G[editBox:GetName().."Header"]
    local headerSuffix = _G[editBox:GetName().."HeaderSuffix"]
    if not header then
      return
    end
    local whisper
    if type == "BN_WHISPER" then
      header:SetWidth(0)
      alias = editBox:GetAttribute("tellTarget")
      alias = GetAliasByPID(alias) or alias
      header:SetFormattedText(CHAT_BN_WHISPER_SEND, alias)
      whisper = 1
    elseif type == "WHISPER" then
      header:SetWidth(0)
      alias = editBox:GetAttribute("tellTarget")
      alias = GetAliasByFriendName(alias) or alias
      header:SetFormattedText(CHAT_WHISPER_SEND, alias)
      whisper = 1
    end
    if whisper then
      local headerWidth = header:GetRight() - header:GetLeft()
      local editBoxWidth = editBox:GetRight() - editBox:GetLeft()
      if headerWidth > editBoxWidth / 2 then
        header:SetWidth(editBoxWidth / 2)
        headerSuffix:Show()
      else
        headerSuffix:Hide()
      end
      header:SetTextColor(info.r, info.g, info.b)
      headerSuffix:SetTextColor(info.r, info.g, info.b)
      editBox:SetTextInsets(15 + header:GetWidth() + (headerSuffix:IsShown() and headerSuffix:GetWidth() or 0), 13, 0, 0)
      editBox:SetTextColor(info.r, info.g, info.b)
      editBox.focusLeft:SetVertexColor(info.r, info.g, info.b)
      editBox.focusRight:SetVertexColor(info.r, info.g, info.b)
      editBox.focusMid:SetVertexColor(info.r, info.g, info.b)
    end
  end)
end

do
  local AddMessage = DEFAULT_CHAT_FRAME.AddMessage

  local function SmartAddMessage(self, msg, ...)
    (EasyCopy_AddMessage or AddMessage)(self, ReplaceLink(msg), ...)
  end

  hooksecurefunc("FCF_SetWindowName", function(self, name, ...)
    self.AddMessage = SmartAddMessage
    ReplaceText(_G[self:GetName().."Tab"])
  end)

  for i = 1, NUM_CHAT_WINDOWS do
    local chat = _G["ChatFrame"..i]
    if chat then
      chat.AddMessage = SmartAddMessage
    end
  end
end

do
  local addon = CreateFrame("Frame", "FriendsListColors_Alias")
  addon:RegisterEvent("BN_FRIEND_INFO_CHANGED")
  addon:RegisterEvent("FRIENDLIST_UPDATE")
  local function OnEvent(addon, event)
    if event == "BN_FRIEND_INFO_CHANGED" then
      Database_Update()
    elseif event == "FRIENDLIST_UPDATE" then
      Database_Update(1)
    end
  end
  addon:SetScript("OnEvent", OnEvent)
  OnEvent(addon, "BN_FRIEND_INFO_CHANGED")
end
