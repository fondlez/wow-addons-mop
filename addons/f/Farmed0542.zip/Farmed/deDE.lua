﻿-- Author      : LintyDruid

-- Localisation

function farmed_Locale_German()

---Application messages
farmed_lang_loaded="Farmed ist geladen, tippe /farmed für Zugang zu den Optionen";
farmed_lang_optmain="Farmed Kommandos:";

--Dialog Titles
farmed_lang_bags="Taschenplätze frei:";
farmed_lang_money="Geld:";
farmed_lang_gathered="Gesammelt";

farmed_lang_ore="Metall & Stein";
farmed_lang_meat="Fleisch";
farmed_lang_gem="Edelstein";
farmed_lang_herb="Kräuter";
farmed_lang_cloth="Stoff";
farmed_lang_leather="Leder";
farmed_lang_element="Elementar";
farmed_lang_enchanting="Verzauberkunst";
farmed_lang_other="Andere Items";
farmed_lang_othercat="Handwerkswaren";
farmed_lang_othercat1="Materialien";
farmed_lang_othercat2="Teile";
farmed_lang_items="Items";
farmed_lang_quest="Quest";
farmed_lang_consumable="Verbrauchbar";


--Inventory Item Filter
farmed_lang_ItemFilter="Rüstung,Behälter,Verschiedenes,Rezept,Waffe";

----Option Window Text

farmed_opt_general="General Option";
farmed_opt_show="Zeige Farmed";
farmed_opt_money="Zeige Geld";
farmed_opt_bags="Zeige Taschenplätze";

farmed_opt_items="Item Options";
farmed_opt_uncommon="Zeige Unbekannt";
farmed_opt_rare="Zeige Rare/Epic";

farmed_opt_materials="Material Options";
farmed_opt_ore="Zeige Metall/Steine";
farmed_opt_meat="Zeige Fleisch";
farmed_opt_herbs="Zeige Kräuter";
farmed_opt_elements="Zeige Elemente";
farmed_opt_gems="Zeige Edelsteine";
farmed_opt_enchanting="Zeige Entzauberungen";
farmed_opt_cloth="Zeige Stoffe";
farmed_opt_leather="Zeige Leder";
farmed_opt_other="Zeige andere Items";
farmed_opt_consumable="Zeige Verbrauchbares";
farmed_opt_announce="Annouce Loot";
farmed_opt_announcechat="Annouce Loot in Chat";
farmed_opt_quest="Zeige Quest Items";


----Key Binding

BINDING_HEADER_FARMED_TITLE = "Farmed Keypress";
BINDING_NAME_FARMED_TOGGLE = "Schalte Farmed";

farmed_lang_optcom1=" zeige - Farmed Fenster anzeigen"; --- can be changed because command lines can be chnaged to locale
farmed_lang_optcom2=" verstecken - Farmed Fenster verstecken";--- can be changed because command lines can be chnaged to locale
farmed_lang_optcom3=" optionen - einstellen farmed";--- can be changed because command lines can be chnaged to locale

farmed_lang_opterr="Unrecognised command."; -- new -- message for incorrect command line option.

farmed_lang_optshow="zeige" -- new - command line option for show ... must be lower case
farmed_lang_opthide="verstecken" -- new - command line option for hide ... must be lower case
farmed_lang_optconfig="optionen" -- new - command line option to display options/config ... must be lower case


farmed_lang_ic_uncommon="nicht selten" -- new -- uncommon summary text have i hard translate
farmed_lang_ic_rare="Rare" -- new -- uncommon summary text german rare too
farmed_lang_ic_epic="Epic" -- new -- uncommon summary text german epic too

farmed_lang_none="keine" -- new -- not items found

--Broker Menu Text
farmed_lang_bkr_open="Open" -- new -- not items found
farmed_lang_bkr_config="Configure" -- new -- not items found

 

farmed_opt_itemcount="Zeige Zähler nur."; -- New

farmed_opt_announce_header="Zeige Loot an" -- New

-- Farmed Option Descriptions
farmed_opt_show_desc="Zeige/verstecke das farmed floating window."; -- New
farmed_opt_money_desc="Zeige/verstecke Gesamtgold."; -- New
farmed_opt_bags_desc="Zeige/verstecke Taschenplatz."; -- New

farmed_opt_uncommon_desc="Zeige auch nicht seltenes in farmed."; -- New
farmed_opt_rare_desc="Zeige auch rare/epic in farmed."; -- New
farmed_opt_itemcount_desc="Zeige gesamt an items nach seltenheit." -- New

farmed_opt_ore_desc="Einschliessen Metall/Steine in farmed."; -- New
farmed_opt_meat_desc="Einschliessen Fleisch in farmed."; -- New
farmed_opt_herbs_desc="Einschliessen Kräuter in farmed."; -- New
farmed_opt_elements_desc="Einschliessen Elementmaterial in farmed."; -- New
farmed_opt_gems_desc="Einschliessen Edelsteine in farmed."; -- New
farmed_opt_enchanting_desc="Einschliessen Verzauberungmaterial in farmed."; -- New
farmed_opt_cloth_desc="Einschliessen Stoffe in farmed."; -- New
farmed_opt_leather_desc="Einschliessen Leder in farmed."; -- New
farmed_opt_other_desc="Einschliessen andere Items in farmed."; -- New
farmed_opt_consumable_desc="Verbrauchbares in farmed."; -- New

end