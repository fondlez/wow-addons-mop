﻿-- Author      : LintyDruid

-- Localisation

function farmed_Locale_French()

end
