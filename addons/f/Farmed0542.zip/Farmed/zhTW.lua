﻿-- Author      : LintyDruid

-- Localisation

function farmed_Locale_Taiwan()

end