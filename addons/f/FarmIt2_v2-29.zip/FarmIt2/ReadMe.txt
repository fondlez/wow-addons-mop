﻿Title: FarmIt
Description: A customizable inventory tracker for World of Warcraft.
Author: CHiLLZ <chillz@gmail.com>
License: Copyright 2006-2013, Chillz Media. All rights reserved.
Website: http://www.curse.com/addons/wow/farm-it


----------------------------------------------------------------------------------------------------
 About FarmIt
----------------------------------------------------------------------------------------------------

FarmIt helps WoW players to actively monitor how much they have of ANY ITEM. This is especially helpful when you want to keep an eye on items that cannot be placed on the standard action bars. For example: I use FarmIt while mining, so I always know exactly how much ore I have, without having to dig through my bags and count them.

This addon has been written to be as light and fast as possible. FarmIt employs optimized item count methods via effective use of the World of Warcraft API, this allows for many powerful and convenient features while remaining a small and simple addon. 

General feedback is welcome here: http://www.curse.com/addons/wow/farm-it
Please submit feature requests or bug reports as tickets on CurseForge:  http://wow.curseforge.com/addons/farm-it/


----------------------------------------------------------------------------------------------------
 Features
----------------------------------------------------------------------------------------------------

FarmIt offers "set it and forget it" farming objectives. 

Current item count is displayed in the bottom-right corner of each slot, and your goal amount in the top-left corner. Optionally, you will be notified each time you loot an item that you are tracking. When you reach your farming objective for a given item, the goal amount turns green and you will receive an "objective completed" notification. You can hide some or all parts of FarmIt and your farming items will still be monitored.

FarmIt is able to include your current bank inventory in real-time, without needing to visit the bank! 

Bar orientation can be switched between vertical and horizontal. The direction the bar "grows" (up, down, left, right) can also be changed, and bar length can be adjusted. Bar visibility can be toggled individually, or all at once.

You can save a set of items from any FarmIt bar as a "farming template" for use again later. FarmIt includes some built-in templates for each of the standard gathering professions.


----------------------------------------------------------------------------------------------------
 User Guide
----------------------------------------------------------------------------------------------------

For in game help, type:  /farmit
Complete command-line documentation can be found at:  http://wow.curseforge.com/addons/farm-it/pages/commands/

Due to the nature of FarmIt's purpose, most settings are saved on a per-character basis since different characters will have different professions, etc. Statistical data and item related information such as farming templates (saved sets of items) are shared between all characters. 


[ Item Buttons ]

Place any item from your inventory into one of FarmIt's bar slots to keep track of how many you have. Click on an occupied slot to select its contents and move them to another slot. If the destination slot has an item in it already, the items will trade places.

Shift+Click the slot to have it include your bank inventory in that item count. You do *not* need to be at the bank for this to work! When 'include bank' is enabled, a four-point gold border will appear around the item button. The "bank included" state is also visible by mousing over the item slot.

Right-Click a slot to "use" the item. (For combining motes into primals, etc.)

Shift+Right-Click a slot to clear it.

Ctrl+Click a slot to set a farming objective for that item. This works similar to WoW quest tracking. FarmIt will notify you each time you progress toward your objective, and upon reaching your goal. The goal number will turn green once it has been reached.

Ctrl+Right-Click any bar slot to manually type in a numeric "Item ID". This works great with addons like iTip which add extra information to all item tooltips.


[ Bars ]

To move a bar, click and drag the anchor (numbered tab) at the end of the bar. To lock it in place, Shift-click the bar anchor. To lock all bars at once, type: "/farmit lock"

Right-Click the bar anchor to open FarmIt's help/configuration panel.

Shift+Right-Click the bar anchor to go directly to the command reference page.

To grow/shrink the number of *visible* slots on a bar, click the 'quick size' buttons (-/+). To permanently add or remove bar slots, see the "group size" documentation on the "Commands" help page.

FarmIt bars can be scaled, made transparent, or hidden completely. See the "Commands" page of FarmIt's in-game help for more information.


[ Templates ]

You can save all the items on a FarmIt bar as a "farming template" to easily track those items again later. Saved farming templates can be loaded onto any FarmIt bar. If there is a difference between the amount of items in the template, and the size of the bar, the bar will automatically adjust to accommodate the template. 

For details on how to save/load your own templates, please refer to the "Commands" page of FarmIt's in-game help.


[ Currency Tracking ]

When you use WoW's built-in "Show on Backpack" feature to watch a currency, FarmIt will automatically track the selected currencies and (optionally) display a "Currency HUD" on screen. You can use this currency bar to set farming objectives and monitor your progress. Use the command "/farmit currency hud" to toggle display of the on-screen currency bar, or just "/farmit currency" to turn currency tracking on/off entirely.

To set a farming goal for a currency, simply right-click the currency amount on FarmIt's currency bar (or at the bottom of your backpack). Once a currency objective has been set, the goal amount will appear in the currency bar tooltips, and the currency tooltips at the bottom of your backpack.

Currency objectives follow the same color scheme as regular item objectives, ie: the objective turns green when the goal has been reached.

To move the currency bar, hold the Shift key and then drag the bar where you want it.

----------------------------------------------------------------------------------------------------
 Credits
----------------------------------------------------------------------------------------------------

Designed and developed by CHiLLZ (aka: Somnifer of Icecrown). Copyright 2006-2013, Chillz Media. ALL RIGHTS RESERVED.
FarmIt has evolved a lot over the years through great feedback from its users. Thanks everyone!  :)
