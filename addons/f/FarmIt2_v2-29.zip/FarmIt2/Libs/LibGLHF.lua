﻿--------------------------------------------------------------------------------
--  Generic Lua Helper Functions
--  Author: CHiLLZ <chillz@gmail.com>
--  Version: 1.0
--
--  Helper functions meant to make life a little easier when coding in Lua.
--------------------------------------------------------------------------------

-- declare the main library "object"
LIB = {};

--------------------------------------------------------------------------------

LIB.table = {};

-- print() wrapper. Builds a recursive view of a table.
-- First argument is the target table to be viewed.
-- Second argument allows custom indentation.
LIB.table.print = function( tab, indent )
	if tab and (type(tab) == "table") then
		local pad = "  ";
		
		if indent then indent = indent..pad; else indent = ""; end

		for key,val in pairs(tab) do
			local t = type(val);
			
			print(indent..key.." ("..t..") = "..tostring(val));
			
			if (t == "table") then
				LIB.table.print(val, indent);
			end
		end
	
	else
		-- some light validation
		return "Input error. Expected table, got "..type(tab)..".";
	end
end

-- Copy a table by value, not by reference. *sigh*
LIB.table.copy = function( tab )
	local result = {};
	
	for key,val in pairs(tab) do
		if (type(val) == "table") then
			-- recursive call. why? because we love having to do this crap, thats why.
			result[key] = LIB.table.copy(val);
		else
			result[key] = val;
		end
	end
	
	-- uncomment if metatables are needed:
	--result = setmetatable(result, getmetatable(tab));
	
	return result;
end

-- Returns a sorted array of table keys.
LIB.table.keys = function( tab, ordered )
	local results = {};
	
	for key,val in pairs(tab) do
		table.insert(results, key);
	end
	
	if ordered then
		table.sort(results);
	end
	
	return results;
end

--------------------------------------------------------------------------------

-- Expects a decimal number. Second argument sets the precision.
-- If no second argument, rounds up to the nearest whole.
LIB.round = function( n, p )
	if (p) then
		return math.floor( (n * 10^p) + 0.5) / (10^p);
	else
		return math.floor(n + 0.5);
	end
end

-- Expects a value that works as a boolean, returns opposite value.
LIB.toggle = function( value )
	if value then
		return false;
	else
		return true;
	end
end

-- strsplit() wrapper that behaves more like PHP's explode()
LIB.explode = function( needle, haystack, ... )
	local results = {};
	
	if needle and haystack then
		needle,haystack = tostring(needle),tostring(haystack);
		
		if (strlen(haystack) > 2) then
			LIB.explode(nil, nil, strsplit(needle, haystack));
		else
			results = false;
		end
	
	elseif (#arg > 0) then
		for i,chunk in ipairs(arg) do
			table.insert(results, chunk);
		end
	
	else
		results = false;
	end
	
	return results;
end
