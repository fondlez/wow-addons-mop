--- ########## Options dialog for Farmed - Uses Ace ###########

farmed_config = {} -- Global Var holding all config releated objects


function farmed_CreateConfig()
	
	if (farmed_config.AceConfig ~= nil) then
		return;
	end

	farmed_config.AceConfig = {
		name = "Farmed",
		handler = nil,
		type = 'group',
		args = {
		
			--------------- General Options ----------------
		
			a = {
				type = 'header',
				name = farmed_opt_general,
				order=100,
				
			},
			
			aa = {
				type = 'toggle',
				name = farmed_opt_show,
				desc = farmed_opt_show_desc,
				set = function(info,val) farmed_show_set(val) end,
				get = function(info) return farmed_options.show end,
				order=101,
			},
			
			 ab = {
				type = 'toggle',
				name = farmed_opt_money,
				desc = farmed_opt_money_desc,
				set = function(info,val) farmed_options.money=val;farmed_gen(); end,
				get = function(info) return farmed_options.money end,
				order=102,
			},
			
			ac = {
				type = 'toggle',
				name = farmed_opt_bags,
				desc = farmed_opt_bags_desc,
				set = function(info,val) farmed_options.slotcount=val;farmed_gen(); end,
				get = function(info) return farmed_options.slotcount end,
				order=103,
			},
			
			
			--------------- Item Options ----------------
		
			b = {
				type = 'header',
				name = farmed_opt_items,
				order=200,
				
			},
			
			ba = {
				type = 'toggle',
				name = farmed_opt_uncommon,
				desc = farmed_opt_uncommon_desc,
				set = function(info,val) farmed_options.uncommon=val;farmed_gen(); end,
				get = function(info) return farmed_options.uncommon end,
				order=201,
			},
			
			 bb = {
				type = 'toggle',
				name = farmed_opt_rare,
				desc = farmed_opt_rare_desc,
				set = function(info,val) farmed_options.rare=val;farmed_gen(); end,
				get = function(info) return farmed_options.rare end,
				order=202,
			},
			
			 bc = {
				type = 'toggle',
				name = farmed_opt_itemcount,
				desc = farmed_opt_itemcount_desc,
				set = function(info,val) farmed_options.itemcount=val;farmed_gen(); end,
				get = function(info) return farmed_options.itemcount end,
				order=203,
			},
			
			
			--------------- Material Options ----------------
		
			c = {
				type = 'header',
				name = farmed_opt_materials,
				order=300,
				
			},
			
			ca = {
				type = 'toggle',
				name = farmed_opt_ore,
				desc = farmed_opt_ore_desc,
				set = function(info,val) farmed_options.ore=val;farmed_gen(); end,
				get = function(info) return farmed_options.ore end,
				order=301,
			},
			
			 cb = {
				type = 'toggle',
				name = farmed_opt_meat,
				desc = farmed_opt_meat_desc,
				set = function(info,val) farmed_options.meat=val;farmed_gen(); end,
				get = function(info) return farmed_options.meat end,
				order=302,
			},
			
			cb1 = {
				type = 'toggle',
				name = farmed_opt_herbs,
				desc = farmed_opt_herbs_desc,
				set = function(info,val) farmed_options.herb=val;farmed_gen(); end,
				get = function(info) return farmed_options.herb end,
				order=303,
			},
			
			 cc = {
				type = 'toggle',
				name = farmed_opt_elements,
				desc = farmed_opt_elements_desc,
				set = function(info,val) farmed_options.element=val;farmed_gen(); end,
				get = function(info) return farmed_options.element end,
				order=304,
			},
			cd = {
				type = 'toggle',
				name = farmed_opt_gems,
				desc = farmed_opt_gems_desc,
				set = function(info,val) farmed_options.gems=val;farmed_gen(); end,
				get = function(info) return farmed_options.gems end,
				order=305,
			},
			
			 ce = {
				type = 'toggle',
				name = farmed_opt_enchanting,
				desc = farmed_opt_enchanting_desc,
				set = function(info,val) farmed_options.enchanting=val;farmed_gen(); end,
				get = function(info) return farmed_options.enchanting end,
				order=306,
			},
			
			 cf = {
				type = 'toggle',
				name = farmed_opt_cloth,
				desc = farmed_opt_cloth_desc,
				set = function(info,val) farmed_options.cloth=val;farmed_gen(); end,
				get = function(info) return farmed_options.cloth end,
				order=307,
			},
			cg = {
				type = 'toggle',
				name = farmed_opt_leather,
				desc = farmed_opt_leather_desc,
				set = function(info,val) farmed_options.leather=val;farmed_gen(); end,
				get = function(info) return farmed_options.leather end,
				order=308,
			},
			
			 ch = {
				type = 'toggle',
				name = farmed_opt_other,
				desc = farmed_opt_other_desc,
				set = function(info,val) farmed_options.other=val;farmed_gen(); end,
				get = function(info) return farmed_options.other end,
				order=309,
			},
			
			cj = {
				type = 'toggle',
				name = farmed_opt_consumable,
				desc = farmed_opt_consumable_desc,
				set = function(info,val) farmed_options.consumable=val;farmed_gen(); end,
				get = function(info) return farmed_options.consumable end,
				order=310,
			},
			
			 ck = {
				type = 'toggle',
				name = farmed_opt_quest,
				desc = farmed_opt_quest_desc,
				set = function(info,val) farmed_options.quest=val;farmed_gen(); end,
				get = function(info) return farmed_options.quest end,
				order=311,
			},
			
			cl = {
				type = 'toggle',
				name = farmed_opt_cooking,
				desc = farmed_opt_cooking_desc,
				set = function(info,val) farmed_options.cooking=val;farmed_gen(); end,
				get = function(info) return farmed_options.cooking end,
				order=312,
			},
		
						
			--------------- Announcements Options ----------------
		
			d = {
				type = 'header',
				name = farmed_opt_announce_header,
				order=400,
				
			},
			
			da = {
				type = 'toggle',
				name = farmed_opt_announce,
				desc = farmed_opt_announce_desc,
				set = function(info,val) farmed_options.announce=val end,
				get = function(info) return farmed_options.announce end,
				order=401,
			},
			
			 db = {
				type = 'toggle',
				name = farmed_opt_announcechat,
				desc = farmed_opt_announcechat_desc,
				set = function(info,val) farmed_options.announcechat=val end,
				get = function(info) return farmed_options.announcechat end,
				order=402,
			},
			
			
			
			
		},
	}

	 farmed_config.AceOptionsTable= LibStub("AceConfig-3.0")

	 farmed_config.AceOptionsTable:RegisterOptionsTable("FarmedOpt", farmed_config.AceConfig)
	 farmed_config.AceDialog= LibStub("AceConfigDialog-3.0")
	 farmed_config.optdlg=farmed_config.AceDialog:AddToBlizOptions("FarmedOpt","Farmed")
end


