--- Default Language -----
---Application messages
farmed_lang_loaded="Farmed is loaded, type /farmed to access options";
farmed_lang_optmain="Farmed Commands:";
farmed_lang_optcom1="     show - show farmed window";
farmed_lang_optcom2="     hide - hide farmed window";
farmed_lang_optcom3="     options - configure farmed";

farmed_lang_opterr="Unrecognised command."; -- new -- message for incorrect command line option.

farmed_lang_optshow="show" -- new - command line option for show ... must be lower case
farmed_lang_opthide="hide" -- new - command line option for hide ... must be lower case
farmed_lang_optconfig="options" -- new - command line option to display options/config ... must be lower case

--Dialog Titles
farmed_lang_bags="Bag slots free:";
farmed_lang_money="Money:";
farmed_lang_gathered="Gathered";
farmed_lang_ore="Metal & Stone";
farmed_lang_meat="Meat";
farmed_lang_gem="Gem";
farmed_lang_herb="Herb";
farmed_lang_cloth="Cloth";
farmed_lang_leather="Leather";
farmed_lang_element="Elemental";
farmed_lang_enchanting="Enchanting";
farmed_lang_other="Other Items";
farmed_lang_othercat="Trade Goods";
farmed_lang_othercat1="Materials";
farmed_lang_othercat2="Parts";
farmed_lang_othercatIDs="#88165;"; --- added 5.4 to support custom other items
farmed_lang_items="Items";
farmed_lang_quest="Quest";
farmed_lang_cooking="Cooking"; --- added for padaria
farmed_lang_consumable="Consumable";

farmed_lang_ic_uncommon="Uncommon" -- new -- uncommon summary text
farmed_lang_ic_rare="Rare" -- new -- uncommon summary text
farmed_lang_ic_epic="Epic" -- new -- uncommon summary text

farmed_lang_none="None" -- new -- not items found

--Broker Menu Text
farmed_lang_bkr_open="Open" -- new -- not items found
farmed_lang_bkr_config="Configure" -- new -- not items found
farmed_lang_bkr_config="Configure" -- new -- not items found
farmed_lang_bkr_refresh="Refresh" -- new -- not items found


--Inventory Item Filter
farmed_lang_ItemFilter="Armor,Container,Miscellaneous,Recipe,Weapon";

----Option Window Text

farmed_opt_general="General Option";
farmed_opt_show="Show Farmed";
farmed_opt_money="Show Money";
farmed_opt_bags="Show Bag Summary";

farmed_opt_items="Item Options";
farmed_opt_uncommon="Show Uncommon";
farmed_opt_rare="Show Rare/Epic";
farmed_opt_itemcount="Show count only."; -- New 

farmed_opt_materials="Material Options";
farmed_opt_ore="Show Metal/Stone";
farmed_opt_meat="Show Meat";
farmed_opt_herbs="Show Herbs";
farmed_opt_elements="Show Elementals";
farmed_opt_gems="Show Gems";
farmed_opt_enchanting="Show Enchanting";
farmed_opt_cloth="Show Cloth";
farmed_opt_leather="Show Leather";
farmed_opt_other="Show Other Items";
farmed_opt_consumable="Show Consumables";
farmed_opt_cooking="Show Cooking Ingr."; -- new for pandaria

farmed_opt_announce_header="Annouce loot" -- New 
farmed_opt_announce="On Screen";
farmed_opt_announcechat="In Chat";

farmed_opt_quest="Show Quest Items";

-- Farmed Option Descriptions
farmed_opt_show_desc="Show/hide the farmed floating window."; -- New 
farmed_opt_money_desc="Show/hide money summary."; -- New 
farmed_opt_bags_desc="Show/hide the bag space summary."; -- New 

farmed_opt_uncommon_desc="Include uncommon items in farmed."; -- New 
farmed_opt_rare_desc="Include rare/epic in farmed."; -- New 
farmed_opt_itemcount_desc="Show a summary of items by rarity." -- New 

farmed_opt_ore_desc="Include Metal/Stone in farmed."; -- New 
farmed_opt_meat_desc="Include Meat in farmed."; -- New 
farmed_opt_herbs_desc="Include Herbs in farmed."; -- New 
farmed_opt_elements_desc="Include elemental materisals in farmed."; -- New 
farmed_opt_gems_desc="Include Gems  in farmed."; -- New 
farmed_opt_enchanting_desc="Include Enchanting materials in farmed."; -- New 
farmed_opt_cloth_desc="Include Cloth  in farmed."; -- New 
farmed_opt_leather_desc="Include Leather in farmed."; -- New 
farmed_opt_cooking_desc="Include cooking ingredients in farmed."; -- New 
farmed_opt_other_desc="Include Other Items in farmed."; -- New 
farmed_opt_consumable_desc=" in farmed. Consumables in farmed."; -- New 


farmed_opt_announce_desc="Annouce looted matrials in the default alert frame.";
farmed_opt_announcechat_desc="Annouce looted matrials in the default chat window.";
farmed_opt_quest_desc="Include Quest Items in farmed.";



----Key Binding

BINDING_HEADER_FARMED_TITLE = "Farmed Bindings";
BINDING_NAME_FARMED_TOGGLE = "Toggle Farmed";




