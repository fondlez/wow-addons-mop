
local function SetTexture(frame, name, type)
   local texture = frame:CreateTexture(name, type)
   texture:SetTexture(name)
   texture:SetAllPoints(true)
   return(texture)
end

local function UpdateStatus(game)
   game.leftCornerButton.textures[game.player]:Show()
   game.leftCornerButton.textures[game.opponent]:Hide()
   if (game.player == game.winner) then
      game.leftCornerButton:SetText(":)")
      game.messageButton:SetText("You Win")
   elseif (game.opponent == game.winner) then
      game.leftCornerButton:SetText(":(")
      game.messageButton:SetText(game.playerNames[game.opponent] .. " Wins")
   elseif (game.player == game.currentPlayer) then
      game.leftCornerButton:SetText("GO")
      game.messageButton:SetText("Your Turn")
   else
      game.leftCornerButton:SetText("...")
      game.messageButton:SetText(game.playerNames[game.opponent] .. "'s Turn")
   end
end

local function DropChecker(checker)
   local game = checker.game
   if (game.currentPlayer == 0) then
      return
   end
   local col = checker.col
   if (game.checkers[col].height == game.columns) then
      return
   end
   game.checkers[col].height = game.checkers[col].height + 1
   local row = game.checkers[col].height
   local checker = game.checkers[col][row]
   checker.player = game.currentPlayer
   point, relativeTo, relativePoint, xOfs, yOfs = checker.frame:GetPoint()
   checker.frame:ClearAllPoints()
   checker.frame:SetPoint("BOTTOMLEFT", game.frame, "BOTTOMLEFT", xOfs, game.height - 64)
   checker.falling = true
   game.checkers[col][row].textures[game.currentPlayer]:Show()
   local vectorX = { 1, 0, 1,  1 }
   local vectorY = { 0, 1, 1, -1 }
   local count = 0
   for dir = 1, 4 do
      local checkers = { }
      count = 1
      checkers[count] = checker
      for dir2 = 1, 2 do
         local nextCol = checker.col + vectorX[dir] 
         local nextRow = checker.row + vectorY[dir] 
         while(true) do
            if (nextCol < 1) then
               break
            elseif (nextCol > game.columns) then
               break
            elseif (nextRow < 1) then
               break
            elseif (nextRow > game.rows) then
               break
            elseif (game.checkers[nextCol][nextRow].player ~= game.currentPlayer) then
               break
            end
            count = count + 1
            checkers[count] = game.checkers[nextCol][nextRow]
            nextCol = nextCol + vectorX[dir] 
            nextRow = nextRow + vectorY[dir] 
         end
         vectorX[dir] = -vectorX[dir]
         vectorY[dir] = -vectorY[dir] 
      end
      if (count >= checker.game.scoreNeededToWin) then
         game.winner = game.currentPlayer 
      end
   end
   if (game.winner ~= nil) then
      if (game.currentPlayer == game.player) then
         DoEmote("CHEER", false)
      else
         DoEmote("CRY", false)
      end
      game.winner = game.currentPlayer
      game.currentPlayer = 0
      UpdateStatus(game);
   else
      if (game.currentPlayer == 1) then
         game.currentPlayer = 2
      else
         game.currentPlayer = 1
      end
      if (game.playerNames[1] == game.playerNames[2]) then
         game.player = game.currentPlayer
         if (game.player == 1) then
            game.opponent = 2
         else
            game.opponent = 1
         end
      end
      UpdateStatus(game);
   end
end

local function NewGame(game)
   game.currentPlayer = 1
   game.winner = nil
   for col = 1, game.columns do
      game.checkers[col].height = 0
      for row = 1, game.rows do
         game.checkers[col][row].player = 0
         game.checkers[col][row].falling = false
         game.checkers[col][row].y = row * game.checkerSize - 24
         game.checkers[col][row].frame:SetPoint("BOTTOMLEFT",
            col * game.checkerSize - 8, row * game.checkerSize - 24)
         game.checkers[col][row].textures[1]:Hide()
         game.checkers[col][row].textures[2]:Hide()
      end
   end
   UpdateStatus(game)
   game.frame:Show()
end

local function MouseClicked(checker)
   game = checker.game
   if (game.player ~= game.currentPlayer) then
      return
   end
   if (game.playerNames[1] ~= game.playerNames[2]) then
      SendAddonMessage("friarDropChecker", checker.col .. "",
         "WHISPER", game.playerNames[game.opponent])
   end
   DropChecker(checker)
end

local function Rematch(game)
   SendAddonMessage("friarInvite", game.playerNames[game.player],
      "WHISPER", game.playerNames[game.opponent])
   for col = 1, game.columns do
      for row = 1, game.rows do
         if (game.checkers[col][row].player ~= 0) then
            game.checkers[col][row].falling = true
            game.checkers[col][row].y = -(25 + random(100))
         end
      end
   end
end

local function Close(game, sender)
   if (game.winner == nil) then
      StaticPopupDialogs["FourRocksInARowCloseDialog"] = {}
      StaticPopupDialogs["FourRocksInARowCloseDialog"].text =
         sender .. " has exited the game"
      StaticPopupDialogs["FourRocksInARowCloseDialog"].button1 = "OK"
      StaticPopupDialogs["FourRocksInARowCloseDialog"].timeout = 60
      StaticPopup_Show("FourRocksInARowCloseDialog") 
   end
end

local function InvitationAccepted(game, sender)
   game.player = 2
   game.opponent = 1
   game.playerNames[game.player] = UnitName("player")
   game.playerNames[game.opponent] = sender
   NewGame(game)
end

local function InvitationDeclined(game, sender)
   StaticPopupDialogs["FourRocksInARowDeclineDialog"] = {}
   StaticPopupDialogs["FourRocksInARowDeclineDialog"].text =
      sender .. " has declined your challenge"
   StaticPopupDialogs["FourRocksInARowDeclineDialog"].button1 = "OK"
   StaticPopupDialogs["FourRocksInARowDeclineDialog"].timeout = 60
   StaticPopup_Show("FourRocksInARowDeclineDialog") 
end

local function AcceptInvitation(game, sender)
   if (game.playerNames[1] ~= game.playerNames[2]) then
      SendAddonMessage("friarAccept", UnitName("player"), "WHISPER", sender)
   end
   game.player = 1
   game.opponent = 2
   game.playerNames[game.player] = UnitName("player")
   game.playerNames[game.opponent] = sender
   NewGame(game)
end

local function DeclineInvitation(game, sender)
   SendAddonMessage("friarDecline", UnitName("player"), "WHISPER", sender)
end

local function ReceiveInviteMessage(game, sender)
   StaticPopupDialogs["friarInviteDialog"] = {}
   StaticPopupDialogs["friarInviteDialog"].text =
      sender .. " has challenged you to a game of\nFour Rocks In A Row"
   StaticPopupDialogs["friarInviteDialog"].button1 = "OK"
   StaticPopupDialogs["friarInviteDialog"].button2 = "CANCEL"
   StaticPopupDialogs["friarInviteDialog"].OnAccept =
      function() AcceptInvitation(game, sender) end
   StaticPopupDialogs["friarInviteDialog"].OnCancel =
      function() DeclineInvitation(game, sender) end
   StaticPopupDialogs["friarInviteDialog"].timeout = 60
   StaticPopup_Show("friarInviteDialog") 
end

local function ReceiveMessage(game, event, prefix, message, channel, sender)
   if (prefix == "friarInvite") then
      ReceiveInviteMessage(game, sender)
   elseif (prefix == "friarAccept") then
      InvitationAccepted(game, sender)
   elseif (prefix == "friarDecline") then
      InvitationDeclined(game, sender)
   elseif (prefix == "friarBegin") then
      Begin(game, sender)
   elseif (prefix == "friarDropChecker") then
      local which = tonumber(message)
      local checker = game.checkers[which][1]
      DropChecker(checker)
   elseif (prefix == "friarClose") then
      Close(game, sender)
   end
end

local function SelectOpponent(opponent)
   opponent = opponent:sub(1,1):upper() .. opponent:sub(2):lower()
   _G.FourRocksInARowOpponent = opponent
   SendAddonMessage("friarInvite", UnitName("player"), "WHISPER", opponent)
   DEFAULT_CHAT_FRAME:AddMessage("You have challenged " .. opponent ..
      " to a game of Four Rocks In A Row")
end

local function Draw(game, elapsed)
   game.time = game.time + elapsed
   for col = 1, game.columns do
      for row = 1, game.rows do
         local checker = game.checkers[col][row]
         if (checker.falling == true) then
            point, relativeTo, relativePoint, xOfs, yOfs = checker.frame:GetPoint()
            yOfs = yOfs - elapsed * 500
            if (yOfs > checker.y) then
               checker.frame:ClearAllPoints()
               checker.frame:SetPoint("BOTTOMLEFT", game.frame, "BOTTOMLEFT", xOfs, yOfs)
            else
               yOfs = checker.y
               PlaySound("LOOTWINDOWCOINSOUND")
               checker.falling = false
               checker.frame:ClearAllPoints()
               checker.frame:SetPoint("BOTTOMLEFT", game.frame, "BOTTOMLEFT", xOfs, yOfs)
               if (yOfs < 0) then
                  checker.textures[1]:Hide()
                  checker.textures[2]:Hide()
               end
            end
         end
      end
   end
end

local function CreateGame()
   
   local game = {}
   
   game.columns = 7
   game.rows = 6
   game.checkerSize = 32
   game.border = 16
   game.height = 8 * game.checkerSize
   game.width = 8 * game.checkerSize
   game.currentPlayer = 0
   game.scoreNeededToWin = 4
   game.playerNames = {}
   game.time = 0

   game.textureNames = {}
   game.textureNames[0] = "Interface\\AddOns\\FourRocksInARow\\FullGrid.tga"
   game.textureNames[1] = "Interface\\AddOns\\FourRocksInARow\\BlackChecker.tga"
   game.textureNames[2] = "Interface\\AddOns\\FourRocksInARow\\RedChecker.tga"

   game.frame = CreateFrame("Frame", "Connect Four", UIParent)
   game.frame:Hide()
   game.frame:EnableMouse(true)
   game.frame:SetHeight(game.height)
   game.frame:SetMovable(true)
   game.frame:SetPoint("CENTER", 0, 0)
   game.frame:SetWidth(game.width)
   game.frame:SetScript("OnMouseDown", function() game.frame:StartMoving() end)
   game.frame:SetScript("OnMouseUp", function() game.frame:StopMovingOrSizing() end)
   game.frame:RegisterEvent("CHAT_MSG_ADDON")
   game.frame:SetScript("OnEvent", function(self, event, prefix, message, channel, sender)
      ReceiveMessage(game, event, prefix, message, channel, sender) end)
   game.frame:SetScript("OnUpdate", function(self, elapsed) Draw(game, elapsed) end)
   SetTexture(game.frame, game.textureNames[0], "OVERLAY")

   game.leftCornerButton = CreateFrame("button", "LeftCornerButton",
      game.frame, "UIPanelButtonGrayTemplate")
   game.leftCornerButton:SetPoint("TOPLEFT", game.frame, "TOPLEFT", 4, -4)
   game.leftCornerButton:SetHeight(game.checkerSize)
   game.leftCornerButton:SetWidth(game.checkerSize)
   game.leftCornerButton:SetText("GO")
   game.leftCornerButton:SetHighlightTexture(nil)
   game.leftCornerButton:SetNormalTexture(nil)
   game.leftCornerButton:SetPushedTexture(nil)
   game.leftCornerButton.textures = {}
   game.leftCornerButton.textures[1] = 
      SetTexture(game.leftCornerButton, game.textureNames[1], "ARTWORK")
   game.leftCornerButton.textures[2] = 
      SetTexture(game.leftCornerButton, game.textureNames[2], "ARTWORK")
   game.leftCornerButton.textures[1]:Hide()
   game.leftCornerButton.textures[2]:Hide()

   game.rematchButton = CreateFrame("button", "RematchButton",
      game.frame, "UIPanelButtonGrayTemplate")
   game.rematchButton:SetPoint("TOPRIGHT", game.frame, "TOPRIGHT", -24, -16)
   game.rematchButton:SetHeight(25)
   game.rematchButton:SetWidth(16)
   game.rematchButton:SetScript("OnClick", function() Rematch(game) end)
   game.rematchButton:SetScript("OnEnter", function() game.messageButton:SetText("Rematch") end);
   game.rematchButton:SetScript("OnLeave", function() UpdateStatus(game) end);
   game.rematchButton:SetText("O")
   game.rematchButton:SetHighlightTexture(nil)
   game.rematchButton:SetNormalTexture(nil)
   game.rematchButton:SetPushedTexture(nil)

   game.closeButton = CreateFrame("button", "CloseButton",
      game.frame, "UIPanelButtonGrayTemplate")
   game.closeButton:SetPoint("TOPRIGHT", game.frame, "TOPRIGHT", -8, -16)
   game.closeButton:SetHeight(25)
   game.closeButton:SetWidth(16)
   game.closeButton:SetScript("OnClick", function()
      SendAddonMessage("friarClose", game.playerNames[game.player],
         "WHISPER", game.playerNames[game.opponent]) game.frame:Hide() end)
   game.closeButton:SetScript("OnEnter", function() game.messageButton:SetText("Exit") end);
   game.closeButton:SetScript("OnLeave", function() UpdateStatus(game) end);
   game.closeButton:SetText("X")
   game.closeButton:SetHighlightTexture(nil)
   game.closeButton:SetNormalTexture(nil)
   game.closeButton:SetPushedTexture(nil)

   game.messageButton = CreateFrame("button", "MessageButton",
      game.frame, "UIPanelButtonGrayTemplate")
   game.messageButton:SetPoint("TOP", game.frame, "TOP", 0, -16)
   game.messageButton:SetHeight(25)
   game.messageButton:SetWidth(game.width)
   game.messageButton:SetScript("OnEnter", function()
      game.messageButton:SetText("Four Rocks In A Row") end);
   game.messageButton:SetScript("OnLeave", function() UpdateStatus(game) end);
   game.messageButton:SetScript("OnMouseDown", function() game.frame:StartMoving() end)
   game.messageButton:SetScript("OnMouseUp", function() game.frame:StopMovingOrSizing() end)
   game.messageButton:SetHighlightTexture(nil)
   game.messageButton:SetNormalTexture(nil)
   game.messageButton:SetPushedTexture(nil)

   game.checkers = {}
   for col = 1, game.columns do
      game.checkers[col] = {}
      game.checkers[col].height = 0
      for row = 1, game.rows do
         game.checkers[col][row] = {}
         game.checkers[col][row].game = game
         game.checkers[col][row].col = col
         game.checkers[col][row].row = row
         game.checkers[col][row].player = 0
         game.checkers[col][row].y = row * game.checkerSize - 24
         game.checkers[col][row].falling = false

         game.checkers[col][row].frame = CreateFrame("Frame", "Checker", game.frame)
         game.checkers[col][row].frame:SetHeight(game.checkerSize)
         game.checkers[col][row].frame:SetWidth(game.checkerSize)
         game.checkers[col][row].frame:SetPoint("BOTTOMLEFT",
            col * game.checkerSize - 8, row * game.checkerSize - 24)
         game.checkers[col][row].frame:EnableMouse(true)
         game.checkers[col][row].frame:SetScript("OnMouseDown",
            function() MouseClicked(game.checkers[col][row] ) end)
         
         game.checkers[col][row].textures = {}
         game.checkers[col][row].textures[1] =
            SetTexture(game.checkers[col][row].frame, game.textureNames[1], "BACKGROUND")
         game.checkers[col][row].textures[2] =
            SetTexture(game.checkers[col][row].frame, game.textureNames[2], "BACKGROUND")
         game.checkers[col][row].textures[1]:Hide()
         game.checkers[col][row].textures[2]:Hide()
      end
   end

   return(game)
end

RegisterAddonMessagePrefix("friarInvite")
RegisterAddonMessagePrefix("friarAccept")
RegisterAddonMessagePrefix("friarDecline")
RegisterAddonMessagePrefix("friarBegin")
RegisterAddonMessagePrefix("friarDropChecker")
RegisterAddonMessagePrefix("friarClose")

local game = CreateGame()

SLASH_FOURROCKSINAROW1 = "/friar"
SLASH_FOURROCKSINAROW2 = "/4riar"
SLASH_FOURROCKSINAROW3 = "/c4"
SlashCmdList["FOURROCKSINAROW"] = function(name)
   if (strlen(name) == 0) then
      StaticPopupDialogs["friarOpponentDialog"] = {}
      StaticPopupDialogs["friarOpponentDialog"].hasEditBox = true
      StaticPopupDialogs["friarOpponentDialog"].text =
         "Who do you wish to challenge to a game of\nFour Rocks In A Row?"
      StaticPopupDialogs["friarOpponentDialog"].button1 = "OK"
      StaticPopupDialogs["friarOpponentDialog"].button2 = "CANCEL"
      StaticPopupDialogs["friarOpponentDialog"].OnShow = function (self)
         if (_G.FourRocksInARowOpponent ~= nil) then
            self.editBox:SetText(_G.FourRocksInARowOpponent) 
         end 
      end
      StaticPopupDialogs["friarOpponentDialog"].OnAccept =
         function(self) SelectOpponent(self.editBox:GetText()) end
      StaticPopupDialogs["friarOpponentDialog"].OnCancel =
         function() end
      StaticPopupDialogs["friarOpponentDialog"].timeout = 60
      StaticPopup_Show("friarOpponentDialog") 
   else
      SelectOpponent(name)
   end
end
