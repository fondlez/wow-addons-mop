--[[ 
classbarframe created

set up basic frame
location
texture

frame objects:
	debuff object 	-> countdown timer
	buff object 	-> countdown timer
	holy power		-> texture
*	runes 			-> countdown timer 
					-> texture
					-> rune type
	soulshard obj.	-> texture
	combo pt. obj.	-> text
	eclipse bar		-> texture 
	
--]]

-- Initialize Class Bar Object Tables and set __index tables
FusionHUDRuneObject = {};
FusionHUDCooldownObject = {};
FusionHUDThreeCountObject = {};
FusionHUDShardObject = {};
FusionHUDHolyPowerObject = {};
FusionHUDComboPointObject = {};
FusionHUDEclipseObject = {};

FusionHUDRuneObject.__index = FusionHUDRuneObject;
FusionHUDCooldownObject.__index = FusionHUDCooldownObject;
FusionHUDThreeCountObject.__index = FusionHUDThreeCountObject;
FusionHUDShardObject.__index = FusionHUDShardObject;
FusionHUDHolyPowerObject.__index = FusionHUDHolyPowerObject;
FusionHUDComboPointObject.__index = FusionHUDComboPointObject;
FusionHUDEclipseObject.__index = FusionHUDEclipseObject;

-- Death Knight Rune Objects
function FusionHUDRuneObject:New()
	local self = {};
	setmetatable(self, FusionHUDRuneObject);
	self = CreateFrame("Frame", nil, FusionHUDClassBar.frame);
	self:SetHeight(FusionHUDClassBar.height);
	self:SetWidth(FusionHUDClassBar.height);
	self.runeID = 0;
	self.onCooldown = false;
	self.cooldownFrame = FusionHUDCooldownObject:New(self);
	self.texture = self:CreateTexture(nil, "BACKGROUND");
	self.texture:SetAllPoints(self);
	return self
end

-- Cooldown Counter Text Object
function FusionHUDCooldownObject:New(parent)
	local self = {};
	setmetatable(self, FusionHUDCooldownObject);
	self = CreateFrame("Frame", nil, parent);
	self.text = self:CreateFontString(nil, "HIGH");
	self.text:SetFont("Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf", math.floor(parent:GetHeight() * .6), "OUTLINE");
	self.text:SetPoint("CENTER", parent, "CENTER", 0, 0);
	self.text:SetHeight(FusionHUDClassBar.height);
	self.text:SetWidth(FusionHUDClassBar.width);
	self.text:SetJustifyH("CENTER");
	self.text:SetJustifyV("CENTER");
	self.lastUpdateClock = 0;
	return self
end

function FusionHUDHolyPowerObject:New()
	local self  = {};
	setmetatable(self, FusionHUDHolyPowerObject);
	self = CreateFrame("Frame", nil, FusionHUDClassBar.frame);
	self:SetAllPoints(FusionHUDClassBar.frame);
	self.texture = self:CreateTexture(nil, "OVERLAY");
	self.fillTexture = self:CreateTexture(nil, "BACKGROUND");
	self.texture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Five Count Frame", true);
	self.texture:SetAllPoints(self);
	self.fillTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Five Count Fill Paladin", true);
	self.fillTexture:SetHeight(FusionHUDClassBar.height);
	self.fillTexture:SetPoint("TOPLEFT", self, "TOPLEFT");
	self.fillTexture:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT");
	return self
end
	
-- Object for 3-part counter bars (Warlocks)
function FusionHUDThreeCountObject:New()
	local self = {};
	local spec = GetSpecialization();
	local i;
	local numShards = UnitPowerMax("player", 7, true)/10
	setmetatable(self, FusionHUDThreeCountObject);
	self = CreateFrame("Frame", nil, FusionHUDClassBar.frame);
	self:SetAllPoints(FusionHUDClassBar.frame);
	if select(2, UnitClass("player")) == "WARLOCK" then
		self.texture = self:CreateTexture(nil, "BACKGROUND");
		self.fillTexture = self:CreateTexture(nil, "OVERLAY");
		self.texture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\One Count Frame", true);
	end
	self.texture:SetAllPoints(self);
	self.fillTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\whitebackdropbase", true);
	self.fillTexture:SetHeight(FusionHUDClassBar.height);
	self.fillTexture:SetPoint("TOPLEFT", self, "TOPLEFT");
	self.fillTexture:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT");
	return self
end

function FusionHUDShardObject:New(spec)
	local self = {};
	local localClass, englishClass = UnitClass("player");
	setmetatable(self, FusionHUDShardObject);
	self = CreateFrame("Frame", nil, FusionHUDClassBar.frame);
	self:SetHeight(FusionHUDClassBar.height);
	self.shardID = 0;
	self.containerTexture = self:CreateTexture(nil, "BACKGROUND");
	self.containerTexture:SetPoint("BOTTOM", self, "BOTTOM");
	self.containerTexture:SetPoint("TOP", self, "TOP");
	self.fillTexture = self:CreateTexture(nil, "BACKGROUND");
	self.glowTexture = self:CreateTexture(nil, "BACKGROUND");
	if englishClass == "WARLOCK" then
		if spec == 1 then
			local numShards = UnitPowerMax("player", 7, true)/100
			self:SetWidth(FusionHUDClassBar.width/numShards);
			self.containerTexture:SetWidth(FusionHUDClassBar.height);
			self.containerTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Three Count Affliction Warlock Container", true);
			self.fillTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Three Count Affliction Warlock Fill", true);
			self.fillTexture:SetAllPoints(self.containerTexture);
			self.containerTexture:SetDrawLayer("ARTWORK", -1);
			self.fillTexture:SetDrawLayer("ARTWORK", 1);
		elseif spec == 3 then
			local numEmbers = UnitPowerMax("player", 14)
			self:SetWidth(FusionHUDClassBar.width/numEmbers);
			self.containerTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Three Count Destruction Warlock Container", true);
			self.containerTexture:SetWidth(FusionHUDClassBar.height);
			self.fillTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Three Count Destruction Warlock Fill", true);
			self.fillTexture:SetHeight(FusionHUDClassBar.height);
			self.fillTexture:SetWidth(FusionHUDClassBar.height);
			self.fillTexture:SetPoint("BOTTOM", self, "BOTTOM");
			self.glowTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Three Count Destruction Warlock Glow", true);
			self.glowTexture:SetHeight(FusionHUDClassBar.height * 1.1);
			self.glowTexture:SetWidth((FusionHUDClassBar.height)*1.1);
			self.glowTexture:SetPoint("CENTER", self, "CENTER");
			self.containerTexture:SetDrawLayer("ARTWORK", -1);
			self.fillTexture:SetDrawLayer("ARTWORK", 2);
			self.glowTexture:SetDrawLayer("ARTWORK", 1);
			self.glowTexture:Hide();
		end
	elseif englishClass == "MONK" then
		local numChi = UnitPowerMax("player", 12)
		self:SetWidth(FusionHUDClassBar.width/numChi);
		self.containerTexture:SetWidth(FusionHUDClassBar.height);
		self.containerTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Monk Chi Counter Frame", true);
		self.fillTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Monk Chi Counter Fill", true);
		self.fillTexture:SetAllPoints(self.containerTexture);
		self.containerTexture:SetDrawLayer("ARTWORK", -1);
		self.fillTexture:SetDrawLayer("ARTWORK", 1);
	end
	return self
end

-- Object for Combo Point counter (Rogues/Druids)
function FusionHUDComboPointObject:New()
	local self = {};
	setmetatable(self, FusionHUDComboPointObject);
	self = CreateFrame("Frame", nil, FusionHUDClassBar.frame);
	self:SetAllPoints(FusionHUDClassBar.frame);
	FusionHUDClassBar.frame:SetWidth(FusionHUDClassBar.height);
	self.texture = self:CreateTexture(nil, "OVERLAY");
	self.texture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\Combo Point Frame", true);
	self.texture:SetAllPoints(self);
	self.text = self:CreateFontString(nil, "HIGH");
	self.text:SetFont("Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf", math.floor(FusionHUDClassBar.frame:GetHeight() * .8), "OUTLINE");
	self.text:SetPoint("CENTER", FusionHUDClassBar.frame, "CENTER", 0, 0);
	self.text:SetHeight(FusionHUDClassBar.height);
	self.text:SetWidth(FusionHUDClassBar.width);
	self.text:SetJustifyH("CENTER");
	self.text:SetJustifyV("CENTER");
	return self
end

-- Object for the Eclipse Bar (Moonkin)
function FusionHUDEclipseObject:New()
	local self = {};
	local eclipseLunar, eclipseSolar, name, i = false, false, "", 1;
	setmetatable(self, FusionHUDEclipseObject);
	self = CreateFrame("Frame", nil, FusionHUDClassBar.frame);
	self:SetAllPoints(FusionHUDClassBar.frame);
	self.texture = self:CreateTexture(nil, "LOW");
	self.texture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\One Count Frame", false);
	self.texture:SetAllPoints(self);
	self.flashFrame = CreateFrame("Frame", "flashFrame", self);
	self.flashFrame:SetAllPoints(self);
	self.flashFrame.texture = self.flashFrame:CreateTexture(nil, "MEDIUM");
	self.flashFrame.texture:SetAllPoints(self);		
	self.flashFrame.texture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\One Count Fill Druid Flash.tga", false);
	self.flashFrame.texture.animGroup = self.flashFrame.texture:CreateAnimationGroup("Flash");
	self.flashFrame.texture.animGroup:SetLooping("NONE");
	self.flashFrame.texture.animGroup.anim1 = self.flashFrame.texture.animGroup:CreateAnimation("Alpha");
	self.flashFrame.texture.animGroup.anim1:SetOrder(1);
	self.flashFrame.texture.animGroup:SetScript("OnPlay", function()
			FusionHUDClassBar.frame.eclipseFrame.flashFrame:Show();
			FusionHUDClassBar.frame.eclipseFrame.flashFrame:SetAlpha(1);
		end)
	self.flashFrame.texture.animGroup:SetScript("OnFinished", function()
			FusionHUDClassBar.frame.eclipseFrame.flashFrame:Hide();
		end)
	self.flashFrame:Hide();
	
	self.backgroundTexture = self:CreateTexture(nil, "BACKGROUND");
	while name ~= nil do
		name = UnitBuff("player", i, "PLAYER");
		if name == "Eclipse (Solar)" then
			eclipseSolar = true
			break
		elseif name == "Eclipse (Lunar)" then
			eclipseLunar = true
			break
		end
		i = i + 1;
	end
	if eclipseSolar then
		self.backgroundTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\One Count Fill Druid Solar", false);
	elseif eclipseLunar then
		self.backgroundTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\One Count Fill Druid Lunar", false);
	else
		self.backgroundTexture:SetTexture("Interface\\AddOns\\FusionHUD\\Graphics\\One Count Fill Druid", false);
	end
	self.backgroundTexture:SetAllPoints(self);
	self.arrowFrame = CreateFrame("Frame", nil, self);
	self.arrowFrame:SetHeight(FusionHUDClassBar.height * 4 / 5);
	self.arrowFrame:SetWidth(FusionHUDClassBar.height * .3);
	self.arrowFrame.texture = self:CreateTexture(nil, "OVERLAY");
	self.arrowFrame.texture:SetAllPoints(self.arrowFrame);
	self.midPoint = FusionHUDClassBar.width / 2;
	self.arrowTextureName = "Interface\\AddOns\\FusionHUD\\Graphics\\Eclipse Arrow";
	return self
end
	
