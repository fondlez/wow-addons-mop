FusionHUDBarType = { 
	"Health", 
	"Power",
	"Threat",
	"Alternate"
};

FusionHUDWarnColor = {
	yellowR = 0.9,
	yellowG = 0.9,
	yellowB = 0,
	redR = 0.9,
	redG = 0,
	refB = 0,
}

FusionHUDModSettings = {
	isUnlocked = false,
	transparency = 1,
	multiTransparency = false,
	loVis = 0,
	midVis = 0.5,
	hiVis = 1,
	classBarToggle = false,
	hideBlizzardPlayerFrame = false,
	hideBlizzardPetFrame = false,
	hideBlizzardTargetFrame = false,
	hideFusionHUDMinimapIcon = false,
	hidePlayerPowerBarAlt = false,
	isSet = true;
};

runeTextures = {
	"Interface\\AddOns\\FusionHUD\\Graphics\\Blood",
	"Interface\\AddOns\\FusionHUD\\Graphics\\Unholy",
	"Interface\\AddOns\\FusionHUD\\Graphics\\Frost",
	"Interface\\AddOns\\FusionHUD\\Graphics\\Death"
};

FusionHUDClassBar = {
	height = 20,
	width = 120,
	myPoint = "CENTER",
	parentFrame = "FusionHUDMasterFrame",
	parentPoint = "CENTER",
	offsetX = 0,
	offsetY = 0,
	textureName = "",
	draggable = false,
};

FusionHUDPowerType = {
	"Mana",
	"Rage",
	"Focus",
	"Energy",
	"Happiness",
	"Runes",
	"Runic Power",
	"Alternate"
};

FusionHUDAvailableProfiles = {};

FusionHUDCurrentProfile = {};

FusionHUDDefaultSetup = {
	["bars"] = {
		["bar3"] = {
			["textIsDocked"] = true,
			["textPoint"] = "TOP",
			["barG"] = 1,
			["textOffsetX"] = 0,
			["lastValue"] = -99999999999,
			["barB"] = 1,
			["totals"] = true,
			["isHorizontal"] = false,
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 200,
			["height"] = 200,
			["offsetY"] = 37.13434077097215,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Curved Symmetric",
			["lastDruidValue"] = -1e+017,
			["offsetX"] = -309.4504383234445,
			["barIndex"] = 3,
			["numLabels"] = 2,
			["fontKey"] = "FrizQuadrata",
			["showValueText"] = true,
			["parentPoint"] = "CENTER",
			["draggable"] = false,
			["lastOrientation"] = "Right",
			["textParentPoint"] = "BOTTOM",
			["showPercentText"] = false,
			["textOffsetY"] = 0,
			["parentFrame"] = {
			},
			["showLabelText"] = true,
			["width"] = 30,
			["lastValueMax"] = -99999999999,
			["barTarget"] = "pet",
			["barName"] = "pet Health",
			["lastWidth"] = 30,
			["orientation"] = "Right",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["barType"] = "Health",
		},
		["bar6"] = {
			["textIsDocked"] = false,
			["textPoint"] = "CENTER",
			["barG"] = 1,
			["textOffsetX"] = 309.451086103508,
			["lastValue"] = -99999999999,
			["barB"] = 1,
			["offsetX"] = 299.3232427437,
			["textParentPoint"] = "CENTER",
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 160,
			["height"] = 160,
			["offsetY"] = 38.25915462030747,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["parentPoint"] = "CENTER",
			["barName"] = "playertarget Power",
			["lastDruidValue"] = 0,
			["barType"] = "Power",
			["barIndex"] = 6,
			["textParentName"] = "table: 1CB066A8",
			["fontKey"] = "FrizQuadrata",
			["showValueText"] = true,
			["numLabels"] = 1,
			["draggable"] = false,
			["lastOrientation"] = "Left",
			["isHorizontal"] = false,
			["showPercentText"] = false,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Curved Symmetric",
			["parentFrame"] = {
			},
			["showLabelText"] = false,
			["width"] = 26,
			["lastValueMax"] = -99999999999,
			["barTarget"] = "playertarget",
			["totals"] = true,
			["lastWidth"] = 26,
			["orientation"] = "Left",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["textOffsetY"] = -112.50144812161,
		},
		["bar2"] = {
			["textIsDocked"] = true,
			["textPoint"] = "TOP",
			["barG"] = 1,
			["textOffsetX"] = 0,
			["lastValue"] = 100,
			["barB"] = 1,
			["totals"] = true,
			["isHorizontal"] = false,
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 500,
			["height"] = 500,
			["offsetY"] = -5.626053073121057,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Vee Bar",
			["barName"] = "Player Power",
			["lastDruidValue"] = 0,
			["textParentPoint"] = "BOTTOM",
			["barIndex"] = 2,
			["numLabels"] = 1,
			["straight"] = false,
			["showValueText"] = true,
			["barType"] = "Power",
			["draggable"] = false,
			["lastOrientation"] = "Left",
			["offsetX"] = 185.6704465317514,
			["showPercentText"] = false,
			["parentPoint"] = "CENTER",
			["parentFrame"] = {
			},
			["showLabelText"] = false,
			["width"] = 100,
			["lastValueMax"] = 100,
			["barTarget"] = "player",
			["fontKey"] = "FrizQuadrata",
			["lastWidth"] = 100,
			["orientation"] = "Left",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["textOffsetY"] = 0,
		},
		["bar1"] = {
			["textIsDocked"] = true,
			["textPoint"] = "CENTER",
			["barG"] = 1,
			["textOffsetX"] = -66.39048387469758,
			["lastValue"] = 119991,
			["fontKey"] = "FrizQuadrata",
			["totals"] = true,
			["angle"] = 0,
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 500,
			["height"] = 500,
			["offsetY"] = -6.751064855253559,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textOffsetY"] = -232.7553481041152,
			["textParentPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["parentPoint"] = "CENTER",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastDruidValue"] = -1e+017,
			["orientation"] = "Right",
			["barIndex"] = 1,
			["barB"] = 1,
			["numLabels"] = 1,
			["showValueText"] = true,
			["offsetX"] = -182.2928313112816,
			["draggable"] = false,
			["lastOrientation"] = "Right",
			["barType"] = "Health",
			["showPercentText"] = false,
			["showLabelText"] = false,
			["parentFrame"] = {
			},
			["isHorizontal"] = false,
			["width"] = 100,
			["lastValueMax"] = 119991,
			["barTarget"] = "player",
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Vee Bar",
			["lastWidth"] = 100,
			["straight"] = false,
			["textParentName"] = "nil",
			["barR"] = 1,
			["barName"] = "player Health",
		},
		["bar8"] = {
			["textIsDocked"] = true,
			["textPoint"] = "TOP",
			["barG"] = 1,
			["textOffsetX"] = 0,
			["lastValue"] = -99999999999,
			["barB"] = 1,
			["offsetX"] = 311.7010781784644,
			["isHorizontal"] = true,
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 15,
			["height"] = 15,
			["offsetY"] = -142.9099267304236,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Rectangular Horizontal",
			["lastDruidValue"] = -1e+017,
			["barType"] = "Health",
			["barIndex"] = 8,
			["numLabels"] = 3,
			["fontKey"] = "FrizQuadrata",
			["showValueText"] = true,
			["parentPoint"] = "CENTER",
			["draggable"] = false,
			["lastOrientation"] = "Left",
			["totals"] = true,
			["showPercentText"] = true,
			["textParentPoint"] = "BOTTOM",
			["parentFrame"] = {
			},
			["showLabelText"] = true,
			["width"] = 125,
			["lastValueMax"] = -99999999999,
			["barTarget"] = "focus",
			["barName"] = "focus Health",
			["lastWidth"] = 125,
			["orientation"] = "Left",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["textOffsetY"] = 0,
		},
		["bar5"] = {
			["textIsDocked"] = true,
			["textPoint"] = "TOP",
			["barG"] = 1,
			["textOffsetX"] = 0,
			["lastValue"] = -99999999999,
			["barB"] = 1,
			["totals"] = true,
			["isHorizontal"] = false,
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 200,
			["height"] = 200,
			["offsetY"] = 38.25948750728454,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Curved Symmetric",
			["lastDruidValue"] = -1e+017,
			["offsetX"] = 309.4509061646015,
			["barIndex"] = 5,
			["numLabels"] = 3,
			["fontKey"] = "FrizQuadrata",
			["showValueText"] = true,
			["parentPoint"] = "CENTER",
			["draggable"] = false,
			["lastOrientation"] = "Left",
			["textParentPoint"] = "BOTTOM",
			["showPercentText"] = true,
			["textOffsetY"] = 0,
			["parentFrame"] = {
			},
			["showLabelText"] = true,
			["width"] = 30,
			["lastValueMax"] = -99999999999,
			["barTarget"] = "playertarget",
			["barName"] = "playertarget Health",
			["lastWidth"] = 30,
			["orientation"] = "Left",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["barType"] = "Health",
		},
		["bar7"] = {
			["textIsDocked"] = true,
			["textPoint"] = "TOP",
			["barG"] = 1,
			["textOffsetX"] = 0,
			["lastValue"] = -99999999999,
			["barB"] = 1,
			["totals"] = true,
			["isHorizontal"] = true,
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 400,
			["height"] = 15,
			["offsetY"] = -86.64633253932948,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = "0x04000000005CD096",
			["parentPoint"] = "CENTER",
			["lastDruidValue"] = -1e+017,
			["barName"] = "player Threat",
			["barIndex"] = 7,
			["fontKey"] = "FrizQuadrata",
			["numLabels"] = 1,
			["showValueText"] = true,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Rectangular Horizontal",
			["draggable"] = false,
			["lastOrientation"] = "Left",
			["offsetX"] = 2.251417950213294,
			["showPercentText"] = false,
			["textOffsetY"] = 0,
			["parentFrame"] = {
			},
			["showLabelText"] = false,
			["width"] = 240,
			["lastValueMax"] = -99999999999,
			["barTarget"] = "player",
			["barType"] = "Threat",
			["lastWidth"] = 15,
			["orientation"] = "Left",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["textParentPoint"] = "BOTTOM",
		},
		["bar9"] = {
			["textIsDocked"] = true,
			["textPoint"] = "TOP",
			["barG"] = 0.08627450980392157,
			["textOffsetX"] = 0,
			["lastValue"] = -99999999999,
			["fontKey"] = "FrizQuadrata",
			["numLabels"] = 3,
			["textParentPoint"] = "BOTTOM",
			["showTotalText"] = true,
			["debug"] = false,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 400,
			["height"] = 15,
			["offsetY"] = -137.2834080653819,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["parentPoint"] = "CENTER",
			["lastDruidValue"] = -1e+017,
			["barIndex"] = 9,
			["barType"] = "Alternate",
			["isHorizontal"] = true,
			["showValueText"] = true,
			["offsetX"] = 312.8261641853958,
			["draggable"] = false,
			["lastOrientation"] = "Left",
			["barB"] = 0.592156862745098,
			["showPercentText"] = true,
			["totals"] = true,
			["textOffsetY"] = 0,
			["width"] = 140,
			["showLabelText"] = true,
			["lastValueMax"] = -99999999,
			["barTarget"] = "player",
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Rectangular Horizontal",
			["lastWidth"] = 15,
			["orientation"] = "Left",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["barName"] = "Alt Power",
		},
		["bar4"] = {
			["textIsDocked"] = false,
			["textPoint"] = "CENTER",
			["barG"] = 1,
			["textOffsetX"] = -307.1997624806434,
			["lastValue"] = -99999999999,
			["barB"] = 1,
			["offsetX"] = -299.3228108903244,
			["textParentPoint"] = "CENTER",
			["showTotalText"] = true,
			["warningColor"] = false,
			["font"] = "Interface\\AddOns\\FusionHUD\\Fonts\\DroidSans.ttf",
			["lastHeight"] = 160,
			["height"] = 160,
			["offsetY"] = 36.00926601022236,
			["fontSize"] = 14,
			["myPoint"] = "CENTER",
			["textParent"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["lastTarget"] = 0,
			["parentPoint"] = "CENTER",
			["barName"] = "pet Power",
			["lastDruidValue"] = 0,
			["barType"] = "Power",
			["barIndex"] = 4,
			["textParentName"] = "table: 1CB066A8",
			["fontKey"] = "FrizQuadrata",
			["showValueText"] = true,
			["numLabels"] = 1,
			["draggable"] = false,
			["lastOrientation"] = "Right",
			["isHorizontal"] = false,
			["showPercentText"] = false,
			["textureName"] = "Interface\\AddOns\\FusionHUD\\Graphics\\Curved Symmetric",
			["parentFrame"] = {
			},
			["showLabelText"] = false,
			["width"] = 26,
			["lastValueMax"] = -99999999999,
			["barTarget"] = "pet",
			["totals"] = true,
			["lastWidth"] = 26,
			["orientation"] = "Right",
			["frame"] = {
				["druidText"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["backdropTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["titleRegion"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["containerTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["druidBar"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["barTexture"] = {
					[0] = nil --[[ skipped userdata ]],
				},
				["textFrame"] = {
					[0] = nil --[[ skipped userdata ]],
					["titleRegion"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["backdropTexture"] = {
						[0] = nil --[[ skipped userdata ]],
					},
					["label"] = {
						[0] = nil --[[ skipped userdata ]],
					},
				},
				[0] = nil --[[ skipped userdata ]],
			},
			["barR"] = 1,
			["textOffsetY"] = -100.122712992313,
		},
	},
	["settings"] = {
		["midVis"] = 0.2,
		["hideBlizzardTargetFrame"] = false,
		["hidePlayerPowerBarAlt"] = false,
		["hiVis"] = 1,
		["classBarToggle"] = false,
		["hideFusionHUDMinimapIcon"] = false,
		["isUnlocked"] = false,
		["hideBlizzardPetFrame"] = false,
		["hideBlizzardPlayerFrame"] = false,
		["transparency"] = 1,
		["hideBlizzTargetFrame"] = true,
		["hideBlizzPlayerFrame"] = true,
		["hideBlizzPetFrame"] = true,
		["multiTransparency"] = true,
		["loVis"] = 0,
		["isSet"] = true,
	},
	["classBar"] = {
		["draggable"] = false,
		["myPoint"] = "CENTER",
		["parentFrame"] = {
		},
		["width"] = 120,
		["parentPoint"] = "CENTER",
		["offsetX"] = 0,
		["barIndex"] = "Class",
		["height"] = 20,
		["frame"] = {
			["titleRegion"] = {
			},
			["backdropTexture"] = {
			},
		},
		["textureName"] = "",
		["offsetY"] = 0,
	},
}