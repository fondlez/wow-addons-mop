
if GetLocale() ~= "ruRU" then return end
local _, BCM = ...
BCM["GENERAL"] = "Общий"
BCM["GUILDRECRUIT"] = "Гильдии"
BCM["LFG"] = "Поиск спутников"
BCM["LOCALDEFENSE"] = "Оборона"
BCM["TRADE"] = "Торговля"
BCM["WORLDDEFENSE"] = "Оборона: глобальный"

