
if GetLocale() ~= "ptBR" then return end
local _, BCM = ...

