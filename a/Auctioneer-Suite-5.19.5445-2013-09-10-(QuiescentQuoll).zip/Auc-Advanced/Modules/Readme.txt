This direcory contains embeddable modules for Auctioneer.
Auctioneer embeddable modules may be either installed as fully fledged
AddOns in you main AddOns folder, or if you prefer, added into this folder
and have the Active modules list updated.

To update you active modules list, you must either:
  * Run the luae executable in this folder, which will automatically
    generate a Active.xml, activating all valid installed modules.
  * If you have a perl interpreter on your system (eg ActivePerl for
    Windows, or perl on Unix/OSX) you may simply run rebuild.pl instead.
  * You may manually edit the existing Active.xml and add/remove entries
    to your taste.




