local L = LibStub("AceLocale-3.0"):NewLocale("ShaAssist", "ruRU")
if not L then return end

L["Assistance to the dance during Dread Spray"] = "Помощь в перемещении при использовании боссом Залпа ужаса" -- Needs review
L["Change the display pattern utilized by Sha of Fear Assist."] = "Изменить место расположения окна Sha Assist на экране" -- Needs review
L["Change the style of the Sha of Fear Assist display"] = "Изменить стиль отображения окна Sha Assist" -- Needs review
L["Close"] = "Закрыть" -- Needs review
L["Closes the Sha Assist display."] = "Закрывает окно Sha Assist" -- Needs review
L["Color my pie"] = "Закрасить мой сектор" -- Needs review
L["Colors"] = "Цвета" -- Needs review
L["Color the pie you are currently in differently"] = "Окрасить сектор в котором вы находитесь в другой цвет" -- Needs review
L["Current pie color"] = "Текущий цвет сектора" -- Needs review
L["defaultPattern"] = "по умолчанию" -- Needs review
L["Display style"] = "Стиль отображение" -- Needs review
L["fixed"] = "исправлено" -- Needs review
L["Fourth next sprayed area color"] = "Цвет четвертого по счету сектора куда будет применено заклинание" -- Needs review
L["Full color"] = "Полный цвет" -- Needs review
L["General"] = "Общие" -- Needs review
L["minimalMovement"] = "Минимальное перемещение" -- Needs review
L["My blip scale"] = "Размер моей метки" -- Needs review
L["Next sprayed area color"] = "Цвет следующей зоны куда будет применено заклинание" -- Needs review
L["Pattern"] = "Часть" -- Needs review
L["Reset display"] = "Сбросить параметры отображения" -- Needs review
L["Reset the scale and position of the display"] = "Сбросить размер и позицию окна Sha Assist" -- Needs review
L["Second next sprayed area color"] = "Цвет второго по счету сектора куда будет применено заклинание" -- Needs review
L["Set the scale of the arrow indicating your own position on the display"] = "Установить размер стрелки отображающей вашу позицию в окне" -- Needs review
L["spinning"] = "вращение" -- Needs review
L["Sprayed area color"] = "Цвет зоны применения заклинания" -- Needs review
L["Suggested safe area color"] = "Цвет предполагаемой безопасной зоны" -- Needs review
L["Test"] = "Тест" -- Needs review
L["The color of the pie you are currently inside"] = "Цвет сектора в котором вы находитесь" -- Needs review
L["Third next sprayed area color"] = "Цвет третьего по счету сектора куда будет применено заклинание" -- Needs review
L["Toggle if every pie should get colored, or just the very relevant ones"] = "Отметить, должны ли быть окрашены все сектора, либо только значимые в данный момент" -- Needs review
L["Toggle lock"] = "Зафиксировать" -- Needs review
L["Toggle whether or not the Sha Assist window should be locked or not."] = "Включить или выключить фиксацию окна Sha Assist на экране" -- Needs review

