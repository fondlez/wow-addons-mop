Nx.GuideData["Void Storage"] = {
     ["Mode"] = 32,
     [301] = "1,50.6,60.5",
     [321] = "2,57.9,65.5",
}
