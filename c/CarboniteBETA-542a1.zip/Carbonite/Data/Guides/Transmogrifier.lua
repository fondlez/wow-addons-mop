Nx.GuideData["Transmogrifier"] = {
     ["Mode"] = 32,
     [301] = "1,50.8,60.8",
     [321] = "2,58,65.4",
}
