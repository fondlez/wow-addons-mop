Nx.GuideData["Mana Loom"] = {
     ["Mode"] = 32,
}
