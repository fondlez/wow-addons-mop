
=> GLOBAL IGNORE LIST

GIL is used to synchronize ignore lists across characters and across servers too.  Finally you can ignore a person on one character and they will be ignored on all of your characters!

The Blizzard UI and chat commands can be used as you normally would to manage the list while GIL will keep everything in sync for you automatically!  Additional chat commands are available too, allowing you to prune the list by days and other functions.

If the maximum of 50 ignored players per character is reached, GIL will optionally filter chat messages from players on the global ignore list, simulating the ignore effect to work around the limitation of 50 people.


=> CHAT COMMANDS

The following commands are accessible by typing /gignore or /gi in the chat box:

/gi - Show a list of available chat commands

/gi list [days] - Show a list of all players on the global ignore list, along with their server, faction, and the date they were added to the list.  An optional number of days can be added if you'd like to only show people who have been on the list for [days] or more days

/gi clear - Clear the global ignore list.  Please understand that clearing this list means that you are clearing everything on all characters that you've previous logged in as!  You will need to provide a follow up confirmation command before the clear will work

/gi add player_name - This provides a way to add a player to the list, but the Blizzard UI and /ignore works too!

/gi remove player_name - This provides a way to remove a player from the list, but the Blizzard UI and /unignore works too!

/gi filter on|off - If on, GIL will check all incoming chat messages and compare them to the ignore list.  If a message is found from someone on the ignore list, the chat message will be filtered.  This provides a "simulated" ignore effect if the ignore list grows beyond 50 characters.

/gi showmsg on|off - GIL will synchronize the list upon logging into a character, and any actions taken will be printed into the chat window unless this option is turned off.  For example, if a person is added or removed from the ignore list a message will be printed in the chat.

/gi server on|off - Synchronize only with same-server characters.  If on, only characters on the same server and faction will share ignore lists.  If off, characters on the same faction but on different servers will share ignore lists.  Remember!  There is a limit of 50 ignored players, so using cross-server ignore lists can really make you hit the limit quickly if you have an itchy ignore finger!

/gi prune days - This will remove all persons from the list that have been on the list more than [days] days.  For example "/gi prune 90" would remove anyone who has been ignored for 90 or more days.  You will need to provide a follow up confirmation command before the clear will work



=> VERSION HISTORY

=> 6.0.4
The /gi list command will now round the number of days a person has been on the ignore list to the nearest whole number

If you try to ignore yourself, you will now get a message telling you that you can't!

GIL should now be able to ignore login and logout messages even when you have more than 50 people on your ignore list!

The /gi list command now assigns a number to each person in the list and the /gi remove command can now remove people by number making things much easier when you have to deal with people using special characters in their name.  Removing by name should still work too!

=> 6.0.3
Added a chat filtering option which (if enabled) will filter chat messages and remove people on the ignore list if a message from them is found.  This allows a way to get around the 50 player ignore limit per character!  This feature will be on my default but it can be turned off by typing /gi filter off.

=> 6.0.2
When ignoring a player by right clicking their name in chat and selecting ignore on a server that has a space in the server name, the addon would fail to synchronize and ignore the player.  Sorry :(

The gi list chat command can now have the server name passed to it.  Here are some examples:

/gi list : Shows all people on the ignore list
/gi list 90 : Shows a list of all people on the list for 90 or more days
/gi list Area 52 : Shows a list of all people on the list from server Area 52
/gi list server : Shows a list of all people on the list on the current server

=> 6.0.1
The list command now shows the number of days the person has been on the ignore list instead of a date

The list command now optionally can take a number of days and it will only list players on ignore for that many days or longer.  For example "/gi list 30" would list only people who have been on the list for 30 or more days while "/gi list" would show all people on the list.

Added a new command called prune.  This will allow you to remove people in bulk who have been ignored for a specified number of days.  For example "/gi prune 30" removes all people who have been ignored for 30 or more days.


=> 6.0.0
First release of Global Ignore List
