-- GLOBAL IGNORE LIST written by Kristina aka IceyPop
-- My first WoW addon created entirely by me! :)

----------------------------------
-- Global Ignore List Variables --
----------------------------------

local serverName    = GetCVar("realmName");
local faction       = nil
local maxIgnoreSize = 50
local firstClear    = false
local firstPrune    = false
local pruneDays     = 0

local BlizzardAddIgnore      = nil
local BlizzardDelIgnore      = nil
local BlizzardAddOrDelIgnore = nil

----------------------------------
-- Global Ignore List Functions --
----------------------------------

local function ShowMsg (msg)

	print ("|cff33ff99Global Ignore: |cffffffff" .. msg)

end

local function Debug (msg)

	if GlobalIgnoreDB ~= nil and GlobalIgnoreDB.debugmsg == true then
		print ("|cffff0000DEBUG:" .. msg)
	end
end

local function OnOff (value)

	if value == nil or value == false then
		return "|cffffff00off|cffffffff"
	elseif value == true then
		return "|cffffff00on|cffffffff"
	else
		return "|cffff0000nil"
	end
end

local function noSpaces (name)

	local result = ""

	for word in name:gmatch("%w+") do
		result = result .. word
	end
	
	return result
end

local function Proper (name)

	--Debug ("Proper start is " .. name)

	local index  = string.find(name, "%-")
	local suffix = ""
	local result = name
	
	if index ~= nil then
		suffix = string.sub(name, index + 1, string.len(name))
		name   = string.sub(name, 1, index - 1)
	        suffix = "-"..string.upper(string.sub(suffix, 1, 1)) .. string.lower(string.sub(suffix, 2, string.len(suffix)))
	end
	
	result = string.upper(string.sub(name,   1, 1)) .. string.lower(string.sub(name,   2, string.len(name))) .. suffix
	
	--Debug ("Proper result is " .. result)
	
	return result
end

local function dateToJulianDate (dateStr)

	local monthList = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }
	local words     = {}

	for word in dateStr:gmatch("%w+") do
		table.insert(words, word)
	end
	
	local day   = tonumber(words[1])
	local year  = tonumber(words[3])
	local month = 0

	for key, value in pairs(monthList) do
	
		if value == words[2] then
			month = tonumber(key)
			
			break
		end
	end

	--print ("monthStr="..monthStr.." month="..month.." day="..day.." year="..year)

	if (not month) or (not day) or (not year) or (month < 1) or (month > 12) or (day < 1) or (day > 31) or (year < 2014) then
		return 0
	end
	
	local calc1 = (month - 14) / 12
	local calc2 = day - 32075 + (1461 * (year + 4800 + calc1) / 4)
	
	calc2 = calc2 + (367 * (month - 2 - calc1 * 12) / 12)
	calc2 = calc2 - (3 * ((year + 4900 + calc1) / 100) / 4)
	
	return calc2
end

local function daysFromToday (dateStr)

	local addDate = dateToJulianDate(dateStr)
	local today   = dateToJulianDate(date("%d %b %Y"))
	
	if addDate == 0 then
		return -1
	else
	
		if addDate < today then
			return math.floor(today - addDate)
		else
			return math.floor(addDate - today)
		end
	end
end

local function AddToList(newname, newfaction)

	local index = #GlobalIgnoreDB.ignoreList+1
	
	GlobalIgnoreDB.ignoreList[index] = newname
	GlobalIgnoreDB.factionList[index] = newfaction
	GlobalIgnoreDB.dateList[index] = date("%d %b %Y")
	GlobalIgnoreDB.notes[index] = "None"
	
end

local function RemoveFromList(index)

	if index <= #GlobalIgnoreDB.ignoreList then
		table.remove(GlobalIgnoreDB.ignoreList, index)
		table.remove(GlobalIgnoreDB.factionList, index)
		table.remove(GlobalIgnoreDB.dateList, index)
		table.remove(GlobalIgnoreDB.notes, index)
	end
end

local function addServer (name)

	--Debug ("addServer start " .. name)

	local result = name

	if string.find(name, "%-") == nil then
		result = name .. "-" .. serverName	
	end
	
	--Debug ("addServer result " .. result)
	
	return result
end

local function getServer (name)

	result = serverName

	local index = string.find(name, "%-");
	
	if index ~= nil then
		result = string.sub(name, index + 1, string.len(name));
	end
	
	return result
end

local function removeServer (name, strict)

	result = name	
	
	local index = string.find(name, "%-");
	
	if strict == nil then
		strict = false
	end
	
	if index ~= nil then
		local server = string.sub(name, index + 1, string.len(name));
		
		if server == serverName or strict == true then
			result = string.sub(name, 1, index - 1)
		end
	end
	
	--Debug ("removeServer result " .. result)
	
	return result	
end

local function isServerMatch (server1, server2)

	local result = (string.upper(noSpaces(server1)) == string.upper(noSpaces(server2)))
	
	return result
end

local function isPlayerMatch (name1, name2)

--	Debug("isPlayerMatch "..name1.."/"..name2)

	local server1 = string.upper(noSpaces(getServer(name1)))
	local server2 = string.upper(noSpaces(getServer(name2)))
	
	name1 = string.upper(removeServer(name1, true))
	name2 = string.upper(removeServer(name2, true))
	
	local result = (server1 == server2) and (name1 == name2)
	
--	if result then
--		Debug ("isPlayerMatch("..name1..","..name2..")("..server1..","..server2..")=true")
--	else
--		Debug ("isPlayerMatch("..name1..","..name2..")("..server1..","..server2..")=false")
--	end
	
	return result
end

local function hasIgnored (name)

	local result = 0
	
	name = addServer(name)
	
	for count = 1, GetNumIgnores() do
	
		if isPlayerMatch(name, addServer(GetIgnoreName(count))) then
			result = count
			break
		end
	end
	
	Debug ("WoW ignored check of " .. name .. " is ".. result)
	
	return result
end

local function hasGlobalIgnored (name)
	
	local result = 0
	
	name = addServer(name)
	
	for key,value in pairs(GlobalIgnoreDB.ignoreList) do
	
		if isPlayerMatch(value, name) then	
		--if string.upper(value) == string.upper(name) then
			result = key
			break
		end
	end
	
	Debug ("Global ignore check "..name.. " is "..result)
	
	return result
end

local function ShowIgnoreList (param)

	local days  = tonumber(param)
	local sName = ""
	
	if not days then
	
		days  = 0
		sName = param
		
		if not sName then
			sName = ""
		end
	end
	
	Debug("ShowIgnore sName="..sName.." days="..days)
	
	if days > 0 then
		ShowMsg("|cffffff00Characters on ignore for " .. days.. " or more days:")
	else
		if sName ~= "" then
			sName = Proper(sName)
			
			if string.upper(sName) == "SERVER" then
				sName = serverName
			end
			
			ShowMsg("|cffffff00All ignored players on server "..sName..":");
		else
			ShowMsg("|cffffff00All characters on global ignore:")
		end
	end
	
	local count = 0
	
	for key,value in pairs(GlobalIgnoreDB.ignoreList) do
	
		local ok = true
	
		if days > 0 then
		
			ok = daysFromToday(GlobalIgnoreDB.dateList[key]) >= days
			
		elseif sName ~= "" then
		
			ok = isServerMatch(serverName, getServer(value))

		end
		
		if ok then
			--ShowMsg ("     " .. value .. " (" .. GlobalIgnoreDB.factionList[key] .. ") " .. "[Added " .. GlobalIgnoreDB.dateList[key] .. "]")
			ShowMsg ("  (" .. key .. ") " .. value .. " (" .. GlobalIgnoreDB.factionList[key] .. ") " .. "[Added ".. daysFromToday(GlobalIgnoreDB.dateList[key]) .. " days ago]")

			count = count + 1			
		end
		
	end
	
	ShowMsg("|cffffff00Listed " .. count .. " character(s)")
end

local function ResetIgnoreDB()

	GlobalIgnoreDB = {
		debugmsg    = false,
		chatmsg     = true,
		sameserver  = true,
		samefaction = true,
		chatfilter  = true,
		ignoreList  = {},
		factionList = {},
		dateList    = {},
		notes       = {}
	}
	
	GlobalIgnoreImported = false
end

local function SyncIgnoreList(silent)

	if silent == nil then
		silent = false
	end

	Debug ("Sync ignore list for server " .. serverName)
	Debug ("Checking for characters to remove")
	
	for count = 1, GetNumIgnores() do
	
		local name = addServer(GetIgnoreName(count))
	
		if hasGlobalIgnored(name) == 0 then
			name = removeServer(name)
			
			if not silent then
				ShowMsg ("Removing " ..  name .. " from character's ignore list")
			end			
			
			BlizzardDelIgnore (hasIgnored(name))
			--BlizzardDelIgnore (name)
			--BlizzardAddOrDelIgnore (name)
			
			Debug ("WoW remove " .. name .. " index "..hasIgnored(name))
		end
	end
	
	Debug ("Checking for characters to add")
	
	for key,value in pairs(GlobalIgnoreDB.ignoreList) do
	
		local name = addServer(value)

		--Debug ("target name is @" .. name .. "@")
	
		if hasIgnored(name) == 0 then
		
			--local ok = (GlobalIgnoreDB.factionList[key] == faction) or (GlobalIgnoreDB.samefaction == false)

			local ok = (GlobalIgnoreDB.factionList[key] == faction)
			
			if ok then
				Debug ("Faction check ok")
				
				--ok = (getServer(name) == serverName) or (GlobalIgnoreDB.sameserver == false)
				ok = (isServerMatch(serverName, getServer(name))) or (GlobalIgnoreDB.sameserver == false)
				
			else
				Debug ("Faction check failed; do not add")
			end
			
			if ok then
				Debug ("Server check ok, adding " .. name)
			
				name = removeServer(name)
			
				if not silent then
					ShowMsg ("Adding " .. name .. " to character's ignore list")
				end
			
				BlizzardAddIgnore(name)
			else
				Debug ("Server check failed; do not add")
			end
		else
			Debug("Already ignored")
		end
	end	
end

local function PruneIgnoreList (days, doit)

	if days == nil or days <= 0 then		
		return 0
	end

	local targets = 0
	local count   = 0
	
	while count < #GlobalIgnoreDB.dateList do
		count = count + 1
	
		if daysFromToday(GlobalIgnoreDB.dateList[count]) >= days then
			targets = targets + 1
			
			local name = addServer(GlobalIgnoreDB.ignoreList[count])
					
			if doit == true then
				Debug ("Deleting player "..name)
				DelIgnore(name)
				count = 0
			end
		end
	end
	
	return targets
end

local function EventHandler (self, event, sender, ...)

	if event == "PLAYER_LOGIN" then
	
		ShowMsg("Type /gignore or /gi for help and options")
		
		faction = UnitFactionGroup("player")
		
		Debug("Faction:"..faction)
		
		if GlobalIgnoreDB == nil then
		
			Debug ("Resetting database")
		
			ResetIgnoreDB()	
		end
		
		if GlobalIgnoreImported == nil or GlobalIgnoreImported ~= true then
	
			local ignores = GetNumIgnores()	
			local added   = 0
			
			if (ignores > 0) and (GlobalIgnoreDB.chatmsg == nil or GlobalIgnoreDB.chatmsg == true) then
				ShowMsg("New character found: Importing ignored players")
			end
			
			for count = 1, ignores do
			
				local name = GetIgnoreName(count)
				
				--Debug ("Checking character " .. name)
				
				if removeServer(name, true) ~= "Unknown" then
				
					name = addServer(name)

					if hasGlobalIgnored(name) == 0 then
						added = added + 1
						
						AddToList(name, faction)
										
						if GlobalIgnoreDB.chatmsg == nil or GlobalIgnoreDB.chatmsg == true then
							ShowMsg ("Adding " .. name .. " to global ignore list")
						end
					end
				else
					Debug ("Skipping Unknown character")
				end
				
			end
			
			GlobalIgnoreImported = true
		end
						
		-- Check for GlobalIgnoreDB nil values and set defaults here if needed
		
		if GlobalIgnoreDB.chatfilter == nil then
			GlobalIgnoreDB.chatfilter = true
		end

		SyncIgnoreList(GlobalIgnoreDB.chatmsg == nil or GlobalIgnoreDB.chatmsg == false)

		if GetNumIgnores() >= maxIgnoreSize then
			ShowMsg("NOTE: Ignore list has reached its limit of " .. maxIgnoreSize .. ", however, chat can still be filtered.")
		end
		
	end
end

function SlashCmdList.GIGNORE (msg)

	Debug("Slash command:"..msg)

	msg = msg:lower()
	
	local args    = {}
	local argStr = ""
	local count  = 0
	
	for word in msg:gmatch("%w+") do
		table.insert(args, word)
		
		count = count + 1
		
		if count == 2 then
			argStr = word
		elseif count > 2 then
			argStr = argStr .. " ".. word
		end
	end
	
	if args[1] == "clear" then
	
		if firstClear and args[2] ~= nil and args[2] == "confirm" then	
			ResetIgnoreDB()
			ShowMsg("Database cleared.")
			SyncIgnoreList(GlobalIgnoreDB.chatmsg == nil or GlobalIgnoreDB.chatmsg == false)
			firstClear = false
		else
			ShowMsg("|cffff0000WARNING: This will remove all ignores on all characters on all servers. Type \"/gi clear confirm\" to clear the list")
			firstClear = true
		end
		
	elseif msg == "showmsg true" or msg == "showmsg on" then
	
		GlobalIgnoreDB.chatmsg = true
		ShowMsg ("Synchronization messages are now |cffffff00on")

	elseif msg == "showmsg false" or msg == "showmsg off" then
	
		GlobalIgnoreDB.chatmsg = false	
		ShowMsg ("Synchronization messages are now |cffffff00off")

	elseif msg == "debug true" or msg == "debug on" then
	
		GlobalIgnoreDB.debugmsg = true
		ShowMsg("Debug messages |cffffff00on")
		
	elseif msg == "debug false" or msg == "debug off" then
	
		GlobalIgnoreDB.debugmsg = false
		ShowMsg("Debug messages |cffffff00off")

	elseif msg == "filter true" or msg == "filter on" then

		GlobalIgnoreDB.chatfilter = true
		ShowMsg("Chat filtering |cffffff00on")

	elseif msg == "filter false" or msg == "filter off" then

		GlobalIgnoreDB.chatfilter = false
		ShowMsg("Chat filtering |cffffff00off")
	
	elseif msg == "server true" or msg == "server on" then
	
		GlobalIgnoreDB.sameserver = true
		ShowMsg("Only sync same server characters is now |cffffff00on")

	elseif msg == "server false" or msg == "server off" then
	
		GlobalIgnoreDB.sameserver = false
		ShowMsg("Only sync same server characters is now |cffffff00off")
		
	elseif args[1] == "list" then
	
		ShowIgnoreList(argStr)
		
	elseif args[1] == "add" and args[2] ~= nil and args[2] ~= "" then
	
		AddIgnore (args[2])
		
	elseif args[1] == "remove" and args[2] ~= nil and args[2] ~= "" then
	
		DelIgnore (args[2], true)
		
	elseif args[1] == "sync" then
	
		SyncIgnoreList()
		
	elseif args[1] == "prune" then
	
		if args[2] == "confirm" and firstPrune == true then
		
			PruneIgnoreList(pruneDays, true)
			
			firstPrune = false
		elseif args[2] == nil or tonumber(args[2]) == nil then
		
			ShowMsg("Number of days not supplied")
		else
			if firstPrune == false then

				pruneDays = tonumber(args[2])
				
				ShowMsg("Remove players that have been ignored for |cffffff00" .. pruneDays.. "|cffffffff+ days")
				ShowMsg("Type \"|cffffff00/gi prune confirm|cffffffff\" to prune |cffffff00".. PruneIgnoreList(pruneDays, false) .. " |cffffffffplayers")
				
				firstPrune = true
			end
		end

	else
		ShowMsg ("|cffff99ffTYPE: |cffffffff/gi [command], where [command] is one of:")
		ShowMsg ("")			
		ShowMsg ("  |cffffff00list|cffffffff: List all players on global ignore list")
		ShowMsg ("  |cffffff00clear|cffffffff: Clear all names from global ignore list")
		ShowMsg ("  |cffffff00add player|cffffffff: Add [player] to ignore list")
		ShowMsg ("  |cffffff00remove player|cffffffff: Remove [player] from ignore list")
		ShowMsg ("  |cffffff00prune days|cffffffff: Remove those on list for [days] or more days")
		ShowMsg ("")
		ShowMsg ("  |cffffff00filter on|off|cffffffff: Perform extra chat filtering (".. OnOff(GlobalIgnoreDB.chatfilter) .. ")")
		ShowMsg ("  |cffffff00showmsg on|off|cffffffff: Show actions during synchronization (".. OnOff(GlobalIgnoreDB.chatmsg) .. ")")
		ShowMsg ("  |cffffff00server on|off|cffffffff: Sync same-server characters only (" .. OnOff(GlobalIgnoreDB.sameserver) .. ")")
		--ShowMsg ("  |cffffff00debug on|off|cffffffff: Show debug messages (" .. OnOff(GlobalIgnoreDB.debugmsg) .. ")")		
		ShowMsg ("")
		ShowMsg ("|cffff99ffNOTE: |cffffffffUse /ignore, and UI as usual to add/remove players!")
	end
end

------------------------
-- Function Pre Hooks --
------------------------

BlizzardAddIgnore      = AddIgnore
BlizzardDelIgnore      = DelIgnore
BlizzardAddOrDelIgnore = AddOrDelIgnore

AddIgnore = function(name)

	name = Proper(addServer(name))
	
	Debug ("AddIgnore name="..name)
	
	if Proper(addServer(UnitName("player"))) ~= name then

		local index = hasGlobalIgnored(name)
	
		if index == 0 then
			AddToList(name, faction)
		
			ShowMsg(name .. " added to global ignore")
			
			BlizzardAddIgnore(removeServer(name))
		else
			if hasIgnored(name) > 0 then
				ShowMsg(name .. " is already ignored")
			end
		
			BlizzardAddIgnore(removeServer(name))		
		end
	else
		ShowMsg("You try to ignore yourself, but its just not working!")
	end	
end

DelIgnore = function(idxpos, isGIL)

	local name = ""
	
	if isGIL then
		if tonumber(idxpos) ~= nil then
			name = GlobalIgnoreDB.ignoreList[tonumber(idxpos)]
			
			if name == nil then
				return
			end
		else
			name = idxpos
		end
	else
		if tonumber(idxpos) ~= nil then			
			name = GetIgnoreName(idxpos)
		else
			name   = idxpos
			idxpos = hasIgnored(name)
		end
	end
	
	name = Proper(addServer(name))
	
	local index = hasGlobalIgnored(name)
	
	if index > 0 then
		ShowMsg(name .. " removed from global ignore")
		
		RemoveFromList(index)		
		--BlizzardDelIgnore(removeServer(name))
		BlizzardDelIgnore(idxpos)
	else
		--ShowMsg(name .. " is not in global ignore list")
		BlizzardDelIgnore(idxpos)
	end
end

AddOrDelIgnore = function(name)

	local index = hasGlobalIgnored(name)

	Debug ("AddOrDel name="..name.." index="..index)
	
	if index == 0 then
		AddIgnore(name)
	else
		DelIgnore(hasIgnored(name))
	end	
end

-----------------------------
-- Global Ignore List Main --
-----------------------------

local frame = CreateFrame("FRAME")

frame:RegisterEvent("PLAYER_LOGIN")

SLASH_GIGNORE1 = "/gignore"
SLASH_GIGNORE2 = "/gi"

frame:SetScript("OnEvent", EventHandler)

--------------------
-- Chat Filtering --
--------------------

local function chatMessageFilter (self, event, message, from, ...)

	--print ("chatMsg evt=" .. (event or "nil") .. " msg=".. (message or "nil") .. " from=" .. (from or "nil"))
	
	if GlobalIgnoreDB.chatfilter == true then
	
		if (from ~= nil) and (from ~= "") then
		
			if hasGlobalIgnored(from) > 0 then
				return true
			else
				return false
			end
			
		elseif event == "CHAT_MSG_SYSTEM" then
	
		  	for key, value in pairs(GlobalIgnoreDB.ignoreList) do
		  	
		  		if isServerMatch(serverName, getServer(value)) then
		  		
		  			local pName      = removeServer(value)
					local msgOffline = string.upper(string.format(ERR_FRIEND_OFFLINE_S, pName))
					local msgOnline  = string.upper(string.format(ERR_FRIEND_ONLINE_SS, pName, pName))
					
					if (string.upper(message) == msgOffline) or (string.upper(message) == msgOnline) then
						return true
					end
		  		end		  		
		  	end
		end	  	
	end
	
	return false
end

local chatEvents = (
		{
		"CHAT_MSG_ACHIEVEMENT",
		"CHAT_MSG_BATTLEGROUND",
		"CHAT_MSG_BATTLEGROUND_LEADER",
		"CHAT_MSG_CHANNEL",
		"CHAT_MSG_CHANNEL_JOIN",
		"CHAT_MSG_CHANNEL_LEAVE",
		"CHAT_MSG_EMOTE",
		"CHAT_MSG_GUILD",
		"CHAT_MSG_GUILD_ACHIEVEMENT",
		"CHAT_MSG_OFFICER",
		"CHAT_MSG_PARTY",
		"CHAT_MSG_RAID",
		"CHAT_MSG_RAID_LEADER",
		"CHAT_MSG_RAID_WARNING",
		"CHAT_MSG_SAY",
		"CHAT_MSG_SYSTEM",
		"CHAT_MSG_TEXT_EMOTE",
		"CHAT_MSG_WHISPER",
		"CHAT_MSG_WHISPER_INFORM",
		"CHAT_MSG_YELL"
		}
	)

for key, value in pairs (chatEvents) do
	ChatFrame_AddMessageEventFilter(value, chatMessageFilter)
end
