local FilterOff = CreateFrame("Frame")
function SetFilterOff()
	BNSetMatureLanguageFilter(false)
end
FilterOff:SetScript("OnEvent", SetFilterOff)
FilterOff:RegisterEvent("PLAYER_ENTERING_WORLD")